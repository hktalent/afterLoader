/*     */ package org.eclipse.swt.internal;
/*     */ 
/*     */ import org.eclipse.swt.internal.gtk.OS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Converter
/*     */ {
/*  43 */   public static final byte[] NullByteArray = new byte[1];
/*  44 */   public static final byte[] EmptyByteArray = new byte[0];
/*  45 */   public static final char[] EmptyCharArray = new char[0];
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static char[] mbcsToWcs(byte[] buffer)
/*     */   {
/*  55 */     long[] items_written = new long[1];
/*  56 */     long ptr = OS.g_utf8_to_utf16(buffer, buffer.length, null, items_written, null);
/*  57 */     if (ptr == 0L) return EmptyCharArray;
/*  58 */     int length = (int)items_written[0];
/*  59 */     char[] chars = new char[length];
/*  60 */     C.memmove(chars, ptr, length * 2);
/*  61 */     OS.g_free(ptr);
/*  62 */     return chars;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static byte[] wcsToMbcs(String string, boolean terminate)
/*     */   {
/*  77 */     int length = string.length();
/*  78 */     char[] buffer = new char[length];
/*  79 */     string.getChars(0, length, buffer, 0);
/*  80 */     return wcsToMbcs(buffer, terminate);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static byte[] javaStringToCString(String string)
/*     */   {
/*  90 */     return wcsToMbcs(string, true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String cCharPtrToJavaString(long cCharPtr, boolean freecCharPtr)
/*     */   {
/* 109 */     int length = C.strlen(cCharPtr);
/* 110 */     byte[] buffer = new byte[length];
/* 111 */     C.memmove(buffer, cCharPtr, length);
/* 112 */     if (freecCharPtr) {
/* 113 */       OS.g_free(cCharPtr);
/*     */     }
/* 115 */     return new String(mbcsToWcs(buffer));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static byte[] wcsToMbcs(char[] chars, boolean terminate)
/*     */   {
/* 129 */     long[] items_read = new long[1];long[] items_written = new long[1];
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 134 */     long ptr = OS.g_utf16_to_utf8(chars, chars.length, items_read, items_written, null);
/* 135 */     if (ptr == 0L) return terminate ? NullByteArray : EmptyByteArray;
/* 136 */     int written = (int)items_written[0];
/* 137 */     byte[] bytes = new byte[written + (terminate ? 1 : 0)];
/* 138 */     C.memmove(bytes, ptr, written);
/* 139 */     OS.g_free(ptr);
/* 140 */     return bytes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static char wcsToMbcs(char ch)
/*     */   {
/* 152 */     int key = ch & 0xFFFF;
/* 153 */     if (key <= 127) return ch;
/* 154 */     byte[] buffer = wcsToMbcs(new char[] { ch }, false);
/* 155 */     if (buffer.length == 1) return (char)buffer[0];
/* 156 */     if (buffer.length == 2) {
/* 157 */       return (char)((buffer[0] & 0xFF) << 8 | buffer[1] & 0xFF);
/*     */     }
/* 159 */     return '\000';
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static char mbcsToWcs(char ch)
/*     */   {
/* 169 */     int key = ch & 0xFFFF;
/* 170 */     if (key <= 127) return ch;
/*     */     byte[] buffer;
/* 172 */     if (key <= 255) {
/* 173 */       byte[] buffer = new byte[1];
/* 174 */       buffer[0] = ((byte)key);
/*     */     } else {
/* 176 */       buffer = new byte[2];
/* 177 */       buffer[0] = ((byte)(key >> 8 & 0xFF));
/* 178 */       buffer[1] = ((byte)(key & 0xFF));
/*     */     }
/* 180 */     char[] result = mbcsToWcs(buffer);
/* 181 */     if (result.length == 0) return '\000';
/* 182 */     return result[0];
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/internal/Converter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */