/*     */ package org.eclipse.swt.widgets;
/*     */ 
/*     */ import org.eclipse.swt.internal.SWTEventListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class EventTable
/*     */ {
/*     */   int[] types;
/*     */   Listener[] listeners;
/*     */   int level;
/*     */   static final int GROW_SIZE = 4;
/*     */   
/*     */   public Listener[] getListeners(int eventType)
/*     */   {
/*  31 */     if (this.types == null) return new Listener[0];
/*  32 */     int count = 0;
/*  33 */     for (int i = 0; i < this.types.length; i++) {
/*  34 */       if (this.types[i] == eventType) count++;
/*     */     }
/*  36 */     if (count == 0) return new Listener[0];
/*  37 */     Listener[] result = new Listener[count];
/*  38 */     count = 0;
/*  39 */     for (int i = 0; i < this.types.length; i++) {
/*  40 */       if (this.types[i] == eventType) {
/*  41 */         result[(count++)] = this.listeners[i];
/*     */       }
/*     */     }
/*  44 */     return result;
/*     */   }
/*     */   
/*     */   public void hook(int eventType, Listener listener) {
/*  48 */     if (this.types == null) this.types = new int[4];
/*  49 */     if (this.listeners == null) this.listeners = new Listener[4];
/*  50 */     int length = this.types.length;int index = length - 1;
/*  51 */     while ((index >= 0) && 
/*  52 */       (this.types[index] == 0)) {
/*  53 */       index--;
/*     */     }
/*  55 */     index++;
/*  56 */     if (index == length) {
/*  57 */       int[] newTypes = new int[length + 4];
/*  58 */       System.arraycopy(this.types, 0, newTypes, 0, length);
/*  59 */       this.types = newTypes;
/*  60 */       Listener[] newListeners = new Listener[length + 4];
/*  61 */       System.arraycopy(this.listeners, 0, newListeners, 0, length);
/*  62 */       this.listeners = newListeners;
/*     */     }
/*  64 */     this.types[index] = eventType;
/*  65 */     this.listeners[index] = listener;
/*     */   }
/*     */   
/*     */   public boolean hooks(int eventType) {
/*  69 */     if (this.types == null) return false;
/*  70 */     for (int i = 0; i < this.types.length; i++) {
/*  71 */       if (this.types[i] == eventType) return true;
/*     */     }
/*  73 */     return false;
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public void sendEvent(Event event)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield 2	org/eclipse/swt/widgets/EventTable:types	[I
/*     */     //   4: ifnonnull +4 -> 8
/*     */     //   7: return
/*     */     //   8: aload_0
/*     */     //   9: dup
/*     */     //   10: getfield 7	org/eclipse/swt/widgets/EventTable:level	I
/*     */     //   13: aload_0
/*     */     //   14: getfield 7	org/eclipse/swt/widgets/EventTable:level	I
/*     */     //   17: iflt +7 -> 24
/*     */     //   20: iconst_1
/*     */     //   21: goto +4 -> 25
/*     */     //   24: iconst_m1
/*     */     //   25: iadd
/*     */     //   26: putfield 7	org/eclipse/swt/widgets/EventTable:level	I
/*     */     //   29: iconst_0
/*     */     //   30: istore_2
/*     */     //   31: iload_2
/*     */     //   32: aload_0
/*     */     //   33: getfield 2	org/eclipse/swt/widgets/EventTable:types	[I
/*     */     //   36: arraylength
/*     */     //   37: if_icmpge +252 -> 289
/*     */     //   40: aload_1
/*     */     //   41: getfield 8	org/eclipse/swt/widgets/Event:type	I
/*     */     //   44: ifne +148 -> 192
/*     */     //   47: aload_0
/*     */     //   48: getfield 7	org/eclipse/swt/widgets/EventTable:level	I
/*     */     //   51: ifge +7 -> 58
/*     */     //   54: iconst_1
/*     */     //   55: goto +4 -> 59
/*     */     //   58: iconst_0
/*     */     //   59: istore_3
/*     */     //   60: aload_0
/*     */     //   61: dup
/*     */     //   62: getfield 7	org/eclipse/swt/widgets/EventTable:level	I
/*     */     //   65: aload_0
/*     */     //   66: getfield 7	org/eclipse/swt/widgets/EventTable:level	I
/*     */     //   69: iflt +7 -> 76
/*     */     //   72: iconst_1
/*     */     //   73: goto +4 -> 77
/*     */     //   76: iconst_m1
/*     */     //   77: isub
/*     */     //   78: putfield 7	org/eclipse/swt/widgets/EventTable:level	I
/*     */     //   81: iload_3
/*     */     //   82: ifeq +109 -> 191
/*     */     //   85: aload_0
/*     */     //   86: getfield 7	org/eclipse/swt/widgets/EventTable:level	I
/*     */     //   89: ifne +102 -> 191
/*     */     //   92: iconst_0
/*     */     //   93: istore 4
/*     */     //   95: iconst_0
/*     */     //   96: istore 5
/*     */     //   98: iload 5
/*     */     //   100: aload_0
/*     */     //   101: getfield 2	org/eclipse/swt/widgets/EventTable:types	[I
/*     */     //   104: arraylength
/*     */     //   105: if_icmpge +50 -> 155
/*     */     //   108: aload_0
/*     */     //   109: getfield 2	org/eclipse/swt/widgets/EventTable:types	[I
/*     */     //   112: iload 5
/*     */     //   114: iaload
/*     */     //   115: ifeq +34 -> 149
/*     */     //   118: aload_0
/*     */     //   119: getfield 2	org/eclipse/swt/widgets/EventTable:types	[I
/*     */     //   122: iload 4
/*     */     //   124: aload_0
/*     */     //   125: getfield 2	org/eclipse/swt/widgets/EventTable:types	[I
/*     */     //   128: iload 5
/*     */     //   130: iaload
/*     */     //   131: iastore
/*     */     //   132: aload_0
/*     */     //   133: getfield 4	org/eclipse/swt/widgets/EventTable:listeners	[Lorg/eclipse/swt/widgets/Listener;
/*     */     //   136: iload 4
/*     */     //   138: aload_0
/*     */     //   139: getfield 4	org/eclipse/swt/widgets/EventTable:listeners	[Lorg/eclipse/swt/widgets/Listener;
/*     */     //   142: iload 5
/*     */     //   144: aaload
/*     */     //   145: aastore
/*     */     //   146: iinc 4 1
/*     */     //   149: iinc 5 1
/*     */     //   152: goto -54 -> 98
/*     */     //   155: iload 4
/*     */     //   157: istore 5
/*     */     //   159: iload 5
/*     */     //   161: aload_0
/*     */     //   162: getfield 2	org/eclipse/swt/widgets/EventTable:types	[I
/*     */     //   165: arraylength
/*     */     //   166: if_icmpge +25 -> 191
/*     */     //   169: aload_0
/*     */     //   170: getfield 2	org/eclipse/swt/widgets/EventTable:types	[I
/*     */     //   173: iload 5
/*     */     //   175: iconst_0
/*     */     //   176: iastore
/*     */     //   177: aload_0
/*     */     //   178: getfield 4	org/eclipse/swt/widgets/EventTable:listeners	[Lorg/eclipse/swt/widgets/Listener;
/*     */     //   181: iload 5
/*     */     //   183: aconst_null
/*     */     //   184: aastore
/*     */     //   185: iinc 5 1
/*     */     //   188: goto -29 -> 159
/*     */     //   191: return
/*     */     //   192: aload_0
/*     */     //   193: getfield 2	org/eclipse/swt/widgets/EventTable:types	[I
/*     */     //   196: iload_2
/*     */     //   197: iaload
/*     */     //   198: aload_1
/*     */     //   199: getfield 8	org/eclipse/swt/widgets/Event:type	I
/*     */     //   202: if_icmpne +81 -> 283
/*     */     //   205: aload_0
/*     */     //   206: getfield 4	org/eclipse/swt/widgets/EventTable:listeners	[Lorg/eclipse/swt/widgets/Listener;
/*     */     //   209: iload_2
/*     */     //   210: aaload
/*     */     //   211: astore_3
/*     */     //   212: aload_3
/*     */     //   213: ifnull +70 -> 283
/*     */     //   216: aload_3
/*     */     //   217: aload_1
/*     */     //   218: invokeinterface 9 2 0
/*     */     //   223: goto +60 -> 283
/*     */     //   226: astore 4
/*     */     //   228: invokestatic 11	org/eclipse/swt/widgets/Display:getCurrent	()Lorg/eclipse/swt/widgets/Display;
/*     */     //   231: astore 5
/*     */     //   233: aload 5
/*     */     //   235: ifnonnull +6 -> 241
/*     */     //   238: aload 4
/*     */     //   240: athrow
/*     */     //   241: aload 5
/*     */     //   243: invokevirtual 12	org/eclipse/swt/widgets/Display:getRuntimeExceptionHandler	()Ljava/util/function/Consumer;
/*     */     //   246: aload 4
/*     */     //   248: invokeinterface 13 2 0
/*     */     //   253: goto +30 -> 283
/*     */     //   256: astore 4
/*     */     //   258: invokestatic 11	org/eclipse/swt/widgets/Display:getCurrent	()Lorg/eclipse/swt/widgets/Display;
/*     */     //   261: astore 5
/*     */     //   263: aload 5
/*     */     //   265: ifnonnull +6 -> 271
/*     */     //   268: aload 4
/*     */     //   270: athrow
/*     */     //   271: aload 5
/*     */     //   273: invokevirtual 15	org/eclipse/swt/widgets/Display:getErrorHandler	()Ljava/util/function/Consumer;
/*     */     //   276: aload 4
/*     */     //   278: invokeinterface 13 2 0
/*     */     //   283: iinc 2 1
/*     */     //   286: goto -255 -> 31
/*     */     //   289: aload_0
/*     */     //   290: getfield 7	org/eclipse/swt/widgets/EventTable:level	I
/*     */     //   293: ifge +7 -> 300
/*     */     //   296: iconst_1
/*     */     //   297: goto +4 -> 301
/*     */     //   300: iconst_0
/*     */     //   301: istore_2
/*     */     //   302: aload_0
/*     */     //   303: dup
/*     */     //   304: getfield 7	org/eclipse/swt/widgets/EventTable:level	I
/*     */     //   307: aload_0
/*     */     //   308: getfield 7	org/eclipse/swt/widgets/EventTable:level	I
/*     */     //   311: iflt +7 -> 318
/*     */     //   314: iconst_1
/*     */     //   315: goto +4 -> 319
/*     */     //   318: iconst_m1
/*     */     //   319: isub
/*     */     //   320: putfield 7	org/eclipse/swt/widgets/EventTable:level	I
/*     */     //   323: iload_2
/*     */     //   324: ifeq +105 -> 429
/*     */     //   327: aload_0
/*     */     //   328: getfield 7	org/eclipse/swt/widgets/EventTable:level	I
/*     */     //   331: ifne +98 -> 429
/*     */     //   334: iconst_0
/*     */     //   335: istore_3
/*     */     //   336: iconst_0
/*     */     //   337: istore 4
/*     */     //   339: iload 4
/*     */     //   341: aload_0
/*     */     //   342: getfield 2	org/eclipse/swt/widgets/EventTable:types	[I
/*     */     //   345: arraylength
/*     */     //   346: if_icmpge +48 -> 394
/*     */     //   349: aload_0
/*     */     //   350: getfield 2	org/eclipse/swt/widgets/EventTable:types	[I
/*     */     //   353: iload 4
/*     */     //   355: iaload
/*     */     //   356: ifeq +32 -> 388
/*     */     //   359: aload_0
/*     */     //   360: getfield 2	org/eclipse/swt/widgets/EventTable:types	[I
/*     */     //   363: iload_3
/*     */     //   364: aload_0
/*     */     //   365: getfield 2	org/eclipse/swt/widgets/EventTable:types	[I
/*     */     //   368: iload 4
/*     */     //   370: iaload
/*     */     //   371: iastore
/*     */     //   372: aload_0
/*     */     //   373: getfield 4	org/eclipse/swt/widgets/EventTable:listeners	[Lorg/eclipse/swt/widgets/Listener;
/*     */     //   376: iload_3
/*     */     //   377: aload_0
/*     */     //   378: getfield 4	org/eclipse/swt/widgets/EventTable:listeners	[Lorg/eclipse/swt/widgets/Listener;
/*     */     //   381: iload 4
/*     */     //   383: aaload
/*     */     //   384: aastore
/*     */     //   385: iinc 3 1
/*     */     //   388: iinc 4 1
/*     */     //   391: goto -52 -> 339
/*     */     //   394: iload_3
/*     */     //   395: istore 4
/*     */     //   397: iload 4
/*     */     //   399: aload_0
/*     */     //   400: getfield 2	org/eclipse/swt/widgets/EventTable:types	[I
/*     */     //   403: arraylength
/*     */     //   404: if_icmpge +25 -> 429
/*     */     //   407: aload_0
/*     */     //   408: getfield 2	org/eclipse/swt/widgets/EventTable:types	[I
/*     */     //   411: iload 4
/*     */     //   413: iconst_0
/*     */     //   414: iastore
/*     */     //   415: aload_0
/*     */     //   416: getfield 4	org/eclipse/swt/widgets/EventTable:listeners	[Lorg/eclipse/swt/widgets/Listener;
/*     */     //   419: iload 4
/*     */     //   421: aconst_null
/*     */     //   422: aastore
/*     */     //   423: iinc 4 1
/*     */     //   426: goto -29 -> 397
/*     */     //   429: goto +154 -> 583
/*     */     //   432: astore 6
/*     */     //   434: aload_0
/*     */     //   435: getfield 7	org/eclipse/swt/widgets/EventTable:level	I
/*     */     //   438: ifge +7 -> 445
/*     */     //   441: iconst_1
/*     */     //   442: goto +4 -> 446
/*     */     //   445: iconst_0
/*     */     //   446: istore 7
/*     */     //   448: aload_0
/*     */     //   449: dup
/*     */     //   450: getfield 7	org/eclipse/swt/widgets/EventTable:level	I
/*     */     //   453: aload_0
/*     */     //   454: getfield 7	org/eclipse/swt/widgets/EventTable:level	I
/*     */     //   457: iflt +7 -> 464
/*     */     //   460: iconst_1
/*     */     //   461: goto +4 -> 465
/*     */     //   464: iconst_m1
/*     */     //   465: isub
/*     */     //   466: putfield 7	org/eclipse/swt/widgets/EventTable:level	I
/*     */     //   469: iload 7
/*     */     //   471: ifeq +109 -> 580
/*     */     //   474: aload_0
/*     */     //   475: getfield 7	org/eclipse/swt/widgets/EventTable:level	I
/*     */     //   478: ifne +102 -> 580
/*     */     //   481: iconst_0
/*     */     //   482: istore 8
/*     */     //   484: iconst_0
/*     */     //   485: istore 9
/*     */     //   487: iload 9
/*     */     //   489: aload_0
/*     */     //   490: getfield 2	org/eclipse/swt/widgets/EventTable:types	[I
/*     */     //   493: arraylength
/*     */     //   494: if_icmpge +50 -> 544
/*     */     //   497: aload_0
/*     */     //   498: getfield 2	org/eclipse/swt/widgets/EventTable:types	[I
/*     */     //   501: iload 9
/*     */     //   503: iaload
/*     */     //   504: ifeq +34 -> 538
/*     */     //   507: aload_0
/*     */     //   508: getfield 2	org/eclipse/swt/widgets/EventTable:types	[I
/*     */     //   511: iload 8
/*     */     //   513: aload_0
/*     */     //   514: getfield 2	org/eclipse/swt/widgets/EventTable:types	[I
/*     */     //   517: iload 9
/*     */     //   519: iaload
/*     */     //   520: iastore
/*     */     //   521: aload_0
/*     */     //   522: getfield 4	org/eclipse/swt/widgets/EventTable:listeners	[Lorg/eclipse/swt/widgets/Listener;
/*     */     //   525: iload 8
/*     */     //   527: aload_0
/*     */     //   528: getfield 4	org/eclipse/swt/widgets/EventTable:listeners	[Lorg/eclipse/swt/widgets/Listener;
/*     */     //   531: iload 9
/*     */     //   533: aaload
/*     */     //   534: aastore
/*     */     //   535: iinc 8 1
/*     */     //   538: iinc 9 1
/*     */     //   541: goto -54 -> 487
/*     */     //   544: iload 8
/*     */     //   546: istore 9
/*     */     //   548: iload 9
/*     */     //   550: aload_0
/*     */     //   551: getfield 2	org/eclipse/swt/widgets/EventTable:types	[I
/*     */     //   554: arraylength
/*     */     //   555: if_icmpge +25 -> 580
/*     */     //   558: aload_0
/*     */     //   559: getfield 2	org/eclipse/swt/widgets/EventTable:types	[I
/*     */     //   562: iload 9
/*     */     //   564: iconst_0
/*     */     //   565: iastore
/*     */     //   566: aload_0
/*     */     //   567: getfield 4	org/eclipse/swt/widgets/EventTable:listeners	[Lorg/eclipse/swt/widgets/Listener;
/*     */     //   570: iload 9
/*     */     //   572: aconst_null
/*     */     //   573: aastore
/*     */     //   574: iinc 9 1
/*     */     //   577: goto -29 -> 548
/*     */     //   580: aload 6
/*     */     //   582: athrow
/*     */     //   583: return
/*     */     // Line number table:
/*     */     //   Java source line #77	-> byte code offset #0
/*     */     //   Java source line #78	-> byte code offset #8
/*     */     //   Java source line #80	-> byte code offset #29
/*     */     //   Java source line #81	-> byte code offset #40
/*     */     //   Java source line #108	-> byte code offset #47
/*     */     //   Java source line #109	-> byte code offset #60
/*     */     //   Java source line #110	-> byte code offset #81
/*     */     //   Java source line #111	-> byte code offset #92
/*     */     //   Java source line #112	-> byte code offset #95
/*     */     //   Java source line #113	-> byte code offset #108
/*     */     //   Java source line #114	-> byte code offset #118
/*     */     //   Java source line #115	-> byte code offset #132
/*     */     //   Java source line #116	-> byte code offset #146
/*     */     //   Java source line #112	-> byte code offset #149
/*     */     //   Java source line #119	-> byte code offset #155
/*     */     //   Java source line #120	-> byte code offset #169
/*     */     //   Java source line #121	-> byte code offset #177
/*     */     //   Java source line #119	-> byte code offset #185
/*     */     //   Java source line #81	-> byte code offset #191
/*     */     //   Java source line #82	-> byte code offset #192
/*     */     //   Java source line #83	-> byte code offset #205
/*     */     //   Java source line #84	-> byte code offset #212
/*     */     //   Java source line #86	-> byte code offset #216
/*     */     //   Java source line #103	-> byte code offset #223
/*     */     //   Java source line #87	-> byte code offset #226
/*     */     //   Java source line #88	-> byte code offset #228
/*     */     //   Java source line #90	-> byte code offset #233
/*     */     //   Java source line #91	-> byte code offset #238
/*     */     //   Java source line #94	-> byte code offset #241
/*     */     //   Java source line #103	-> byte code offset #253
/*     */     //   Java source line #95	-> byte code offset #256
/*     */     //   Java source line #96	-> byte code offset #258
/*     */     //   Java source line #98	-> byte code offset #263
/*     */     //   Java source line #99	-> byte code offset #268
/*     */     //   Java source line #102	-> byte code offset #271
/*     */     //   Java source line #80	-> byte code offset #283
/*     */     //   Java source line #108	-> byte code offset #289
/*     */     //   Java source line #109	-> byte code offset #302
/*     */     //   Java source line #110	-> byte code offset #323
/*     */     //   Java source line #111	-> byte code offset #334
/*     */     //   Java source line #112	-> byte code offset #336
/*     */     //   Java source line #113	-> byte code offset #349
/*     */     //   Java source line #114	-> byte code offset #359
/*     */     //   Java source line #115	-> byte code offset #372
/*     */     //   Java source line #116	-> byte code offset #385
/*     */     //   Java source line #112	-> byte code offset #388
/*     */     //   Java source line #119	-> byte code offset #394
/*     */     //   Java source line #120	-> byte code offset #407
/*     */     //   Java source line #121	-> byte code offset #415
/*     */     //   Java source line #119	-> byte code offset #423
/*     */     //   Java source line #124	-> byte code offset #429
/*     */     //   Java source line #108	-> byte code offset #432
/*     */     //   Java source line #109	-> byte code offset #448
/*     */     //   Java source line #110	-> byte code offset #469
/*     */     //   Java source line #111	-> byte code offset #481
/*     */     //   Java source line #112	-> byte code offset #484
/*     */     //   Java source line #113	-> byte code offset #497
/*     */     //   Java source line #114	-> byte code offset #507
/*     */     //   Java source line #115	-> byte code offset #521
/*     */     //   Java source line #116	-> byte code offset #535
/*     */     //   Java source line #112	-> byte code offset #538
/*     */     //   Java source line #119	-> byte code offset #544
/*     */     //   Java source line #120	-> byte code offset #558
/*     */     //   Java source line #121	-> byte code offset #566
/*     */     //   Java source line #119	-> byte code offset #574
/*     */     //   Java source line #124	-> byte code offset #580
/*     */     //   Java source line #125	-> byte code offset #583
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	584	0	this	EventTable
/*     */     //   0	584	1	event	Event
/*     */     //   30	254	2	i	int
/*     */     //   301	23	2	compact	boolean
/*     */     //   59	23	3	compact	boolean
/*     */     //   211	6	3	listener	Listener
/*     */     //   335	60	3	index	int
/*     */     //   93	63	4	index	int
/*     */     //   226	21	4	runtimeException	RuntimeException
/*     */     //   256	21	4	error	Error
/*     */     //   337	52	4	i	int
/*     */     //   395	29	4	i	int
/*     */     //   96	54	5	i	int
/*     */     //   157	29	5	i	int
/*     */     //   231	11	5	display	Display
/*     */     //   261	11	5	display	Display
/*     */     //   432	149	6	localObject	Object
/*     */     //   446	24	7	compact	boolean
/*     */     //   482	63	8	index	int
/*     */     //   485	54	9	i	int
/*     */     //   546	29	9	i	int
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   216	223	226	java/lang/RuntimeException
/*     */     //   216	223	256	java/lang/Error
/*     */     //   29	47	432	finally
/*     */     //   192	289	432	finally
/*     */     //   432	434	432	finally
/*     */   }
/*     */   
/*     */   public int size()
/*     */   {
/* 128 */     if (this.types == null) return 0;
/* 129 */     int count = 0;
/* 130 */     for (int i = 0; i < this.types.length; i++) {
/* 131 */       if (this.types[i] != 0) count++;
/*     */     }
/* 133 */     return count;
/*     */   }
/*     */   
/*     */   void remove(int index) {
/* 137 */     if (this.level == 0) {
/* 138 */       int end = this.types.length - 1;
/* 139 */       System.arraycopy(this.types, index + 1, this.types, index, end - index);
/* 140 */       System.arraycopy(this.listeners, index + 1, this.listeners, index, end - index);
/* 141 */       index = end;
/*     */     }
/* 143 */     else if (this.level > 0) { this.level = (-this.level);
/*     */     }
/* 145 */     this.types[index] = 0;
/* 146 */     this.listeners[index] = null;
/*     */   }
/*     */   
/*     */   public void unhook(int eventType, Listener listener) {
/* 150 */     if (this.types == null) return;
/* 151 */     for (int i = 0; i < this.types.length; i++) {
/* 152 */       if ((this.types[i] == eventType) && (this.listeners[i] == listener)) {
/* 153 */         remove(i);
/* 154 */         return;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void unhook(int eventType, SWTEventListener listener) {
/* 160 */     if (this.types == null) return;
/* 161 */     for (int i = 0; i < this.types.length; i++) {
/* 162 */       if ((this.types[i] == eventType) && 
/* 163 */         ((this.listeners[i] instanceof TypedListener))) {
/* 164 */         TypedListener typedListener = (TypedListener)this.listeners[i];
/* 165 */         if (typedListener.getEventListener() == listener) {
/* 166 */           remove(i);
/* 167 */           return;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/widgets/EventTable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */