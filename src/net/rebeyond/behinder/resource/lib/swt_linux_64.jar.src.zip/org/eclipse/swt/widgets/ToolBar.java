/*     */ package org.eclipse.swt.widgets;
/*     */ 
/*     */ import org.eclipse.swt.SWT;
/*     */ import org.eclipse.swt.graphics.Color;
/*     */ import org.eclipse.swt.graphics.Font;
/*     */ import org.eclipse.swt.graphics.Point;
/*     */ import org.eclipse.swt.graphics.Rectangle;
/*     */ import org.eclipse.swt.internal.Callback;
/*     */ import org.eclipse.swt.internal.Converter;
/*     */ import org.eclipse.swt.internal.DPIUtil;
/*     */ import org.eclipse.swt.internal.ImageList;
/*     */ import org.eclipse.swt.internal.gtk.GTK;
/*     */ import org.eclipse.swt.internal.gtk.GdkColor;
/*     */ import org.eclipse.swt.internal.gtk.GdkRGBA;
/*     */ import org.eclipse.swt.internal.gtk.GtkAllocation;
/*     */ import org.eclipse.swt.internal.gtk.OS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ToolBar
/*     */   extends Composite
/*     */ {
/*     */   ToolItem currentFocusItem;
/*     */   ToolItem[] tabItemList;
/*     */   ImageList imageList;
/*     */   boolean hasChildFocus;
/*     */   static Callback menuItemSelectedFunc;
/*     */   String cssBackground;
/*     */   
/*     */   static
/*     */   {
/*  54 */     menuItemSelectedFunc = new Callback(ToolBar.class, "MenuItemSelectedProc", 2);
/*  55 */     if (menuItemSelectedFunc.getAddress() == 0L) SWT.error(3); }
/*     */   
/*  57 */   String cssForeground = " ";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ToolBar(Composite parent, int style)
/*     */   {
/*  93 */     super(parent, checkStyle(style));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 102 */     if ((style & 0x200) != 0) {
/* 103 */       this.style |= 0x200;
/*     */     } else {
/* 105 */       this.style |= 0x100;
/*     */     }
/* 107 */     int orientation = (style & 0x200) != 0 ? 1 : 0;
/* 108 */     GTK.gtk_orientable_set_orientation(this.handle, orientation);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static int checkStyle(int style)
/*     */   {
/* 119 */     return style & 0xFCFF;
/*     */   }
/*     */   
/*     */   protected void checkSubclass()
/*     */   {
/* 124 */     if (!isValidSubclass()) error(43);
/*     */   }
/*     */   
/*     */   void createHandle(int index)
/*     */   {
/* 129 */     this.state |= 0x10008;
/* 130 */     this.fixedHandle = OS.g_object_new(this.display.gtk_fixed_get_type(), 0L);
/* 131 */     if (this.fixedHandle == 0L) error(2);
/* 132 */     GTK.gtk_widget_set_has_window(this.fixedHandle, true);
/* 133 */     this.handle = GTK.gtk_toolbar_new();
/* 134 */     if (this.handle == 0L) error(2);
/* 135 */     GTK.gtk_container_add(this.fixedHandle, this.handle);
/* 136 */     if (((this.style & 0x800000) != 0) && (!GTK.GTK3)) {
/* 137 */       byte[] swt_toolbar_flat = Converter.wcsToMbcs("swt-toolbar-flat", true);
/* 138 */       GTK.gtk_widget_set_name(this.handle, swt_toolbar_flat);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 151 */     GTK.gtk_toolbar_set_icon_size(this.handle, GTK.GTK3 ? 2 : 3);
/*     */     
/*     */ 
/*     */ 
/* 155 */     if (GTK.GTK3) {
/* 156 */       setFontDescription(defaultFont().handle);
/*     */     }
/*     */   }
/*     */   
/*     */   int applyThemeBackground()
/*     */   {
/* 162 */     return -1;
/*     */   }
/*     */   
/*     */   Point computeSizeInPixels(int wHint, int hHint, boolean changed)
/*     */   {
/* 167 */     checkWidget();
/* 168 */     if ((wHint != -1) && (wHint < 0)) wHint = 0;
/* 169 */     if ((hHint != -1) && (hHint < 0)) { hHint = 0;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 176 */     GTK.gtk_toolbar_set_show_arrow(this.handle, false);
/* 177 */     Point size = computeNativeSize(this.handle, wHint, hHint, changed);
/* 178 */     if ((this.style & 0x40) != 0) GTK.gtk_toolbar_set_show_arrow(this.handle, true);
/* 179 */     return size;
/*     */   }
/*     */   
/*     */   Widget computeTabGroup()
/*     */   {
/* 184 */     ToolItem[] items = _getItems();
/* 185 */     if (this.tabItemList == null) {
/* 186 */       int i = 0;
/* 187 */       while ((i < items.length) && (items[i].control == null)) i++;
/* 188 */       if (i == items.length) return super.computeTabGroup();
/*     */     }
/* 190 */     int index = indexOf(this.currentFocusItem);
/* 191 */     if (index == -1) index = items.length - 1;
/* 192 */     while (index >= 0) {
/* 193 */       ToolItem item = items[index];
/* 194 */       if (item.isTabGroup()) return item;
/* 195 */       index--;
/*     */     }
/* 197 */     return super.computeTabGroup();
/*     */   }
/*     */   
/*     */   Widget[] computeTabList()
/*     */   {
/* 202 */     ToolItem[] items = _getItems();
/* 203 */     if (this.tabItemList == null) {
/* 204 */       int i = 0;
/* 205 */       while ((i < items.length) && (items[i].control == null)) i++;
/* 206 */       if (i == items.length) return super.computeTabList();
/*     */     }
/* 208 */     Widget[] result = new Widget[0];
/* 209 */     if ((!isTabGroup()) || (!isEnabled()) || (!isVisible())) return result;
/* 210 */     ToolItem[] list = this.tabList != null ? _getTabItemList() : items;
/* 211 */     for (int i = 0; i < list.length; i++) {
/* 212 */       ToolItem child = list[i];
/* 213 */       Widget[] childList = child.computeTabList();
/* 214 */       if (childList.length != 0) {
/* 215 */         Widget[] newResult = new Widget[result.length + childList.length];
/* 216 */         System.arraycopy(result, 0, newResult, 0, result.length);
/* 217 */         System.arraycopy(childList, 0, newResult, result.length, childList.length);
/* 218 */         result = newResult;
/*     */       }
/*     */     }
/* 221 */     if (result.length == 0) result = new Widget[] { this };
/* 222 */     return result;
/*     */   }
/*     */   
/*     */   long eventHandle()
/*     */   {
/* 227 */     return this.fixedHandle;
/*     */   }
/*     */   
/*     */   long enterExitHandle()
/*     */   {
/* 232 */     return this.handle;
/*     */   }
/*     */   
/*     */   void fixChildren(Shell newShell, Shell oldShell, Decorations newDecorations, Decorations oldDecorations, Menu[] menus)
/*     */   {
/* 237 */     super.fixChildren(newShell, oldShell, newDecorations, oldDecorations, menus);
/* 238 */     ToolItem[] items = getItems();
/* 239 */     if (this.toolTipText == null) {
/* 240 */       for (int i = 0; i < items.length; i++) {
/* 241 */         ToolItem item = items[i];
/* 242 */         if (item.toolTipText != null) {
/* 243 */           item.setToolTipText(oldShell, null);
/* 244 */           item.setToolTipText(newShell, item.toolTipText);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   boolean forceFocus(long focusHandle)
/*     */   {
/* 252 */     int dir = 0;
/* 253 */     if ((this.style & 0x8000000) != 0) dir = 1;
/* 254 */     long childHandle = this.handle;
/* 255 */     if (this.currentFocusItem != null) { childHandle = this.currentFocusItem.handle;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 260 */     if (GTK.gtk_widget_child_focus(childHandle, dir)) return true;
/* 261 */     return super.forceFocus(focusHandle);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ToolItem getItem(int index)
/*     */   {
/* 280 */     checkWidget();
/* 281 */     if ((0 > index) || (index >= getItemCount())) error(6);
/* 282 */     return getItems()[index];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ToolItem getItem(Point point)
/*     */   {
/* 302 */     checkWidget();
/* 303 */     return getItemInPixels(DPIUtil.autoScaleUp(point));
/*     */   }
/*     */   
/*     */   ToolItem getItemInPixels(Point point)
/*     */   {
/* 308 */     if (point == null) error(4);
/* 309 */     ToolItem[] items = getItems();
/* 310 */     for (int i = 0; i < items.length; i++) {
/* 311 */       if (items[i].getBoundsInPixels().contains(point)) return items[i];
/*     */     }
/* 313 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getItemCount()
/*     */   {
/* 327 */     checkWidget();
/* 328 */     long list = GTK.gtk_container_get_children(this.handle);
/* 329 */     if (list == 0L) return 0;
/* 330 */     int itemCount = OS.g_list_length(list);
/* 331 */     OS.g_list_free(list);
/* 332 */     return itemCount;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ToolItem[] getItems()
/*     */   {
/* 352 */     checkWidget();
/* 353 */     return _getItems();
/*     */   }
/*     */   
/*     */   ToolItem[] _getItems() {
/* 357 */     long list = GTK.gtk_container_get_children(this.handle);
/* 358 */     if (list == 0L) return new ToolItem[0];
/* 359 */     int count = OS.g_list_length(list);
/* 360 */     ToolItem[] items = new ToolItem[count];
/* 361 */     long originalList = list;
/* 362 */     int index = 0;
/* 363 */     for (int i = 0; i < count; i++) {
/* 364 */       long data = OS.g_list_data(list);
/* 365 */       Widget widget = this.display.getWidget(data);
/* 366 */       if (widget != null) items[(index++)] = ((ToolItem)widget);
/* 367 */       list = OS.g_list_next(list);
/*     */     }
/* 369 */     OS.g_list_free(originalList);
/* 370 */     if (index != items.length) {
/* 371 */       ToolItem[] newItems = new ToolItem[index];
/* 372 */       System.arraycopy(items, 0, newItems, 0, index);
/* 373 */       items = newItems;
/*     */     }
/* 375 */     return items;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getRowCount()
/*     */   {
/* 392 */     checkWidget();
/*     */     
/* 394 */     return 1;
/*     */   }
/*     */   
/*     */   ToolItem[] _getTabItemList() {
/* 398 */     if (this.tabItemList == null) return this.tabItemList;
/* 399 */     int count = 0;
/* 400 */     for (int i = 0; i < this.tabItemList.length; i++) {
/* 401 */       if (!this.tabItemList[i].isDisposed()) count++;
/*     */     }
/* 403 */     if (count == this.tabItemList.length) return this.tabItemList;
/* 404 */     ToolItem[] newList = new ToolItem[count];
/* 405 */     int index = 0;
/* 406 */     for (int i = 0; i < this.tabItemList.length; i++) {
/* 407 */       if (!this.tabItemList[i].isDisposed()) {
/* 408 */         newList[(index++)] = this.tabItemList[i];
/*     */       }
/*     */     }
/* 411 */     this.tabItemList = newList;
/* 412 */     return this.tabItemList;
/*     */   }
/*     */   
/*     */   long gtk_key_press_event(long widget, long eventPtr)
/*     */   {
/* 417 */     if (!hasFocus()) return 0L;
/* 418 */     long result = super.gtk_key_press_event(widget, eventPtr);
/* 419 */     return result;
/*     */   }
/*     */   
/*     */   long gtk_focus(long widget, long directionType)
/*     */   {
/* 424 */     return 0L;
/*     */   }
/*     */   
/*     */   boolean hasFocus()
/*     */   {
/* 429 */     if (this.hasChildFocus) return true;
/* 430 */     return super.hasFocus();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int indexOf(ToolItem item)
/*     */   {
/* 452 */     checkWidget();
/* 453 */     if (item == null) error(4);
/* 454 */     ToolItem[] items = getItems();
/* 455 */     for (int i = 0; i < items.length; i++) {
/* 456 */       if (item == items[i]) return i;
/*     */     }
/* 458 */     return -1;
/*     */   }
/*     */   
/*     */   static long MenuItemSelectedProc(long widget, long user_data) {
/* 462 */     Display display = Display.getCurrent();
/* 463 */     ToolItem item = (ToolItem)display.getWidget(user_data);
/* 464 */     if (item != null) {
/* 465 */       return item.getParent().menuItemSelected(widget, item);
/*     */     }
/* 467 */     return 0L;
/*     */   }
/*     */   
/*     */   long menuItemSelected(long widget, ToolItem item) {
/* 471 */     Event event = new Event();
/* 472 */     switch (item.style)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     case 4: 
/* 481 */       event.detail = 4;
/* 482 */       GtkAllocation allocation = new GtkAllocation();
/* 483 */       GTK.gtk_widget_get_allocation(widget, allocation);
/* 484 */       event.x = DPIUtil.autoScaleDown(allocation.x);
/* 485 */       if ((this.style & 0x8000000) != 0) event.x = (DPIUtil.autoScaleDown(getClientWidth() - allocation.width) - event.x);
/* 486 */       event.y = DPIUtil.autoScaleDown(allocation.y + allocation.height);
/* 487 */       break;
/*     */     case 16: 
/* 489 */       if ((this.style & 0x400000) == 0) item.selectRadio();
/*     */       break;
/*     */     case 32: 
/* 492 */       boolean currentSelection = item.getSelection();
/* 493 */       item.setSelection(!currentSelection); }
/*     */     
/* 495 */     item.sendSelectionEvent(13, event, false);
/* 496 */     return 0L;
/*     */   }
/*     */   
/*     */   boolean mnemonicHit(char key)
/*     */   {
/* 501 */     ToolItem[] items = getItems();
/* 502 */     for (int i = 0; i < items.length; i++) {
/* 503 */       long labelHandle = items[i].labelHandle;
/* 504 */       if ((labelHandle != 0L) && (mnemonicHit(labelHandle, key))) return true;
/*     */     }
/* 506 */     return false;
/*     */   }
/*     */   
/*     */   boolean mnemonicMatch(char key)
/*     */   {
/* 511 */     ToolItem[] items = getItems();
/* 512 */     for (int i = 0; i < items.length; i++) {
/* 513 */       long labelHandle = items[i].labelHandle;
/* 514 */       if ((labelHandle != 0L) && (mnemonicMatch(labelHandle, key))) return true;
/*     */     }
/* 516 */     return false;
/*     */   }
/*     */   
/*     */   void relayout() {
/* 520 */     ToolItem[] items = getItems();
/* 521 */     boolean hasText = false;boolean hasImage = false;
/* 522 */     for (int i = 0; i < items.length; i++) {
/* 523 */       ToolItem item = items[i];
/* 524 */       if (item != null) {
/* 525 */         item.resizeControl();
/* 526 */         hasText |= ((item.text != null) && (item.text.length() > 0));
/* 527 */         hasImage |= item.image != null;
/*     */       }
/*     */     }
/* 530 */     int type = 0;
/* 531 */     if ((hasText) && (hasImage)) {
/* 532 */       if ((this.style & 0x20000) != 0) {
/* 533 */         type = 3;
/*     */       } else {
/* 535 */         type = 2;
/*     */       }
/* 537 */     } else if (hasText) {
/* 538 */       type = 1;
/* 539 */     } else if (hasImage) {
/* 540 */       type = 0;
/*     */     }
/* 542 */     GTK.gtk_toolbar_set_style(this.handle, type);
/*     */   }
/*     */   
/*     */   void releaseChildren(boolean destroy)
/*     */   {
/* 547 */     ToolItem[] items = getItems();
/* 548 */     for (int i = 0; i < items.length; i++) {
/* 549 */       ToolItem item = items[i];
/* 550 */       if ((item != null) && (!item.isDisposed())) {
/* 551 */         item.release(false);
/*     */       }
/*     */     }
/* 554 */     super.releaseChildren(destroy);
/*     */   }
/*     */   
/*     */   void releaseWidget()
/*     */   {
/* 559 */     super.releaseWidget();
/* 560 */     if (this.imageList != null) this.imageList.dispose();
/* 561 */     this.imageList = null;
/*     */   }
/*     */   
/*     */   void removeControl(Control control)
/*     */   {
/* 566 */     super.removeControl(control);
/* 567 */     ToolItem[] items = getItems();
/* 568 */     for (int i = 0; i < items.length; i++) {
/* 569 */       ToolItem item = items[i];
/* 570 */       if (item.control == control) item.setControl(null);
/*     */     }
/*     */   }
/*     */   
/*     */   void reskinChildren(int flags)
/*     */   {
/* 576 */     ToolItem[] items = _getItems();
/* 577 */     if (items != null) {
/* 578 */       for (int i = 0; i < items.length; i++) {
/* 579 */         ToolItem item = items[i];
/* 580 */         if (item != null) item.reskin(flags);
/*     */       }
/*     */     }
/* 583 */     super.reskinChildren(flags);
/*     */   }
/*     */   
/*     */   int setBounds(int x, int y, int width, int height, boolean move, boolean resize)
/*     */   {
/* 588 */     GTK.gtk_toolbar_set_show_arrow(this.handle, false);
/* 589 */     int result = super.setBounds(x, y, width, height, move, resize);
/* 590 */     if ((result & 0x100) != 0) relayout();
/* 591 */     if ((this.style & 0x40) != 0) GTK.gtk_toolbar_set_show_arrow(this.handle, true);
/* 592 */     return result;
/*     */   }
/*     */   
/*     */   void setBackgroundGdkRGBA(long context, long handle, GdkRGBA rgba)
/*     */   {
/* 597 */     assert (GTK.GTK3) : "GTK3 code was run by GTK2";
/* 598 */     if (GTK.GTK_VERSION >= OS.VERSION(3, 14, 0))
/*     */     {
/* 600 */       String name = GTK.GTK_VERSION >= OS.VERSION(3, 20, 0) ? "toolbar" : "GtkToolbar";
/* 601 */       String css = name + " {background-color: " + this.display.gtk_rgba_to_css_string(rgba) + "}";
/*     */       
/*     */ 
/* 604 */       this.cssBackground = css;
/*     */       
/*     */ 
/* 607 */       String finalCss = this.display.gtk_css_create_css_color_string(this.cssBackground, this.cssForeground, 8);
/* 608 */       gtk_css_provider_load_from_css(context, finalCss);
/*     */     } else {
/* 610 */       super.setBackgroundGdkRGBA(context, handle, rgba);
/*     */     }
/*     */   }
/*     */   
/*     */   void setParentBackground()
/*     */   {
/* 616 */     if (GTK.GTK3) {
/* 617 */       setBackgroundGdkRGBA(this.handle, this.display.getSystemColor(37).handleRGBA);
/*     */     }
/* 619 */     super.setParentBackground();
/*     */   }
/*     */   
/*     */   void setForegroundGdkRGBA(long handle, GdkRGBA rgba)
/*     */   {
/* 624 */     assert (GTK.GTK3) : "GTK3 code was run by GTK2";
/* 625 */     if (GTK.GTK_VERSION >= OS.VERSION(3, 14, 0)) {
/* 626 */       GdkRGBA toSet = new GdkRGBA();
/* 627 */       if (rgba != null) {
/* 628 */         toSet = rgba;
/*     */       } else {
/* 630 */         toSet = this.display.COLOR_WIDGET_FOREGROUND_RGBA;
/*     */       }
/* 632 */       long context = GTK.gtk_widget_get_style_context(handle);
/*     */       
/* 634 */       String color = this.display.gtk_rgba_to_css_string(toSet);
/*     */       
/* 636 */       String name = GTK.GTK_VERSION >= OS.VERSION(3, 20, 0) ? this.display.gtk_widget_class_get_css_name(handle) : this.display.gtk_widget_get_name(handle);
/* 637 */       GdkRGBA selectedForeground = this.display.COLOR_LIST_SELECTION_TEXT_RGBA;
/* 638 */       String selection = GTK.GTK_VERSION >= OS.VERSION(3, 20, 0) ? " selection" : ":selected";
/*     */       
/* 640 */       String css = "* {color: " + color + ";}\n" + name + selection + " {color: " + this.display.gtk_rgba_to_css_string(selectedForeground) + ";}";
/*     */       
/*     */ 
/* 643 */       this.cssForeground = css;
/*     */       
/*     */ 
/* 646 */       String finalCss = this.display.gtk_css_create_css_color_string(this.cssBackground, this.cssForeground, 16);
/* 647 */       gtk_css_provider_load_from_css(context, finalCss);
/*     */     } else {
/* 649 */       super.setForegroundGdkRGBA(handle, rgba);
/*     */     }
/*     */   }
/*     */   
/*     */   void setFontDescription(long font)
/*     */   {
/* 655 */     super.setFontDescription(font);
/* 656 */     ToolItem[] items = getItems();
/* 657 */     for (int i = 0; i < items.length; i++) {
/* 658 */       items[i].setFontDescription(font);
/*     */     }
/* 660 */     relayout();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void restoreBackground()
/*     */   {
/* 669 */     long context = GTK.gtk_widget_get_style_context(this.handle);
/* 670 */     String finalCss = this.display.gtk_css_create_css_color_string(this.cssBackground, this.cssForeground, 8);
/* 671 */     gtk_css_provider_load_from_css(context, finalCss);
/*     */   }
/*     */   
/*     */   void setForegroundGdkRGBA(GdkRGBA rgba)
/*     */   {
/* 676 */     assert (GTK.GTK3) : "GTK3 code was run by GTK2";
/* 677 */     super.setForegroundGdkRGBA(rgba);
/* 678 */     ToolItem[] items = getItems();
/* 679 */     for (int i = 0; i < items.length; i++) {
/* 680 */       items[i].setForegroundRGBA(rgba);
/*     */     }
/*     */   }
/*     */   
/*     */   void setForegroundGdkColor(GdkColor color)
/*     */   {
/* 686 */     assert (!GTK.GTK3) : "GTK2 code was run by GTK3";
/* 687 */     super.setForegroundGdkColor(color);
/* 688 */     ToolItem[] items = getItems();
/* 689 */     for (int i = 0; i < items.length; i++) {
/* 690 */       items[i].setForegroundColor(color);
/*     */     }
/*     */   }
/*     */   
/*     */   void setOrientation(boolean create)
/*     */   {
/* 696 */     super.setOrientation(create);
/* 697 */     ToolItem[] items = _getItems();
/* 698 */     for (int i = 0; i < items.length; i++) {
/* 699 */       items[i].setOrientation(create);
/*     */     }
/*     */   }
/*     */   
/*     */   void setTabItemList(ToolItem[] tabList) {
/* 704 */     checkWidget();
/* 705 */     if (tabList != null) {
/* 706 */       for (int i = 0; i < tabList.length; i++) {
/* 707 */         ToolItem item = tabList[i];
/* 708 */         if (item == null) error(5);
/* 709 */         if (item.isDisposed()) error(5);
/* 710 */         if (item.parent != this) error(32);
/*     */       }
/* 712 */       ToolItem[] newList = new ToolItem[tabList.length];
/* 713 */       System.arraycopy(tabList, 0, newList, 0, tabList.length);
/* 714 */       tabList = newList;
/*     */     }
/* 716 */     this.tabItemList = tabList;
/*     */   }
/*     */   
/*     */   public void setToolTipText(String string)
/*     */   {
/* 721 */     checkWidget();
/* 722 */     super.setToolTipText(string);
/* 723 */     Shell shell = _getShell();
/* 724 */     ToolItem[] items = getItems();
/* 725 */     for (int i = 0; i < items.length; i++) {
/* 726 */       String newString = string != null ? null : items[i].toolTipText;
/* 727 */       shell.setToolTipText(items[i].handle, newString);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/widgets/ToolBar.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */