package org.eclipse.swt.accessibility;

public class AccessibleValueAdapter
  implements AccessibleValueListener
{
  public void getCurrentValue(AccessibleValueEvent e) {}
  
  public void setCurrentValue(AccessibleValueEvent e) {}
  
  public void getMaximumValue(AccessibleValueEvent e) {}
  
  public void getMinimumValue(AccessibleValueEvent e) {}
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/accessibility/AccessibleValueAdapter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */