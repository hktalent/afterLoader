/*     */ package org.eclipse.swt.widgets;
/*     */ 
/*     */ import org.eclipse.swt.accessibility.Accessible;
/*     */ import org.eclipse.swt.graphics.Font;
/*     */ import org.eclipse.swt.graphics.Image;
/*     */ import org.eclipse.swt.graphics.Point;
/*     */ import org.eclipse.swt.internal.Converter;
/*     */ import org.eclipse.swt.internal.ImageList;
/*     */ import org.eclipse.swt.internal.gtk.GTK;
/*     */ import org.eclipse.swt.internal.gtk.GdkColor;
/*     */ import org.eclipse.swt.internal.gtk.GdkRGBA;
/*     */ import org.eclipse.swt.internal.gtk.GtkAllocation;
/*     */ import org.eclipse.swt.internal.gtk.GtkRequisition;
/*     */ import org.eclipse.swt.internal.gtk.OS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Label
/*     */   extends Control
/*     */ {
/*     */   long frameHandle;
/*     */   long labelHandle;
/*     */   long imageHandle;
/*     */   long boxHandle;
/*     */   ImageList imageList;
/*     */   Image image;
/*     */   String text;
/*     */   
/*     */   public Label(Composite parent, int style)
/*     */   {
/*  96 */     super(parent, checkStyle(style));
/*     */   }
/*     */   
/*     */   static int checkStyle(int style) {
/* 100 */     style |= 0x80000;
/* 101 */     if ((style & 0x2) != 0) {
/* 102 */       style = checkBits(style, 512, 256, 0, 0, 0, 0);
/* 103 */       return checkBits(style, 8, 4, 32, 0, 0, 0);
/*     */     }
/* 105 */     return checkBits(style, 16384, 16777216, 131072, 0, 0, 0);
/*     */   }
/*     */   
/*     */   void addRelation(Control control)
/*     */   {
/* 110 */     if (!control.isDescribedByLabel()) return;
/* 111 */     if (this.labelHandle == 0L) return;
/* 112 */     control._getAccessible().addRelation(9, _getAccessible());
/* 113 */     control.labelRelation = this;
/*     */   }
/*     */   
/*     */   Point computeSizeInPixels(int wHint, int hHint, boolean changed)
/*     */   {
/* 118 */     checkWidget();
/* 119 */     if ((wHint != -1) && (wHint < 0)) wHint = 0;
/* 120 */     if ((hHint != -1) && (hHint < 0)) hHint = 0;
/* 121 */     if ((this.style & 0x2) != 0) {
/* 122 */       if ((this.style & 0x100) != 0) {
/* 123 */         if (wHint == -1) wHint = 64;
/*     */       }
/* 125 */       else if (hHint == -1) { hHint = 64;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 134 */     boolean fixWrap = (this.labelHandle != 0L) && ((this.style & 0x40) != 0) && (GTK.gtk_widget_get_visible(this.labelHandle));
/* 135 */     if ((fixWrap) || (this.frameHandle != 0L)) forceResize();
/* 136 */     Point size; if (fixWrap) {
/* 137 */       long labelLayout = GTK.gtk_label_get_layout(this.labelHandle);
/* 138 */       int pangoWidth = OS.pango_layout_get_width(labelLayout);
/* 139 */       if (wHint != -1) {
/* 140 */         OS.pango_layout_set_width(labelLayout, wHint * 1024);
/*     */       } else {
/* 142 */         OS.pango_layout_set_width(labelLayout, -1);
/*     */       }
/* 144 */       int[] w = new int[1];int[] h = new int[1];
/* 145 */       OS.pango_layout_get_pixel_size(labelLayout, w, h);
/* 146 */       OS.pango_layout_set_width(labelLayout, pangoWidth);
/* 147 */       Point size; if (this.frameHandle != 0L) {
/* 148 */         int[] labelWidth = new int[1];int[] labelHeight = new int[1];
/* 149 */         GTK.gtk_widget_get_size_request(this.labelHandle, labelWidth, labelHeight);
/* 150 */         GTK.gtk_widget_set_size_request(this.labelHandle, 1, 1);
/* 151 */         Point size = computeNativeSize(this.frameHandle, -1, -1, changed);
/* 152 */         GTK.gtk_widget_set_size_request(this.labelHandle, labelWidth[0], labelHeight[0]);
/* 153 */         size.x -= 1;
/* 154 */         size.y -= 1;
/*     */       } else {
/* 156 */         size = new Point(0, 0);
/*     */       }
/* 158 */       size.x += (wHint == -1 ? w[0] : wHint);
/* 159 */       size.y += (hHint == -1 ? h[0] : hHint);
/*     */     }
/* 161 */     else if (this.frameHandle != 0L) {
/* 162 */       int[] reqWidth = new int[1];int[] reqHeight = new int[1];
/* 163 */       GTK.gtk_widget_get_size_request(this.handle, reqWidth, reqHeight);
/* 164 */       GTK.gtk_widget_set_size_request(this.handle, wHint, hHint);
/* 165 */       Point size = computeNativeSize(this.frameHandle, -1, -1, changed);
/* 166 */       GTK.gtk_widget_set_size_request(this.handle, reqWidth[0], reqHeight[0]);
/*     */     } else {
/* 168 */       size = computeNativeSize(this.handle, wHint, hHint, changed);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 180 */     if ((hHint == -1) && (this.labelHandle != 0L)) {
/* 181 */       long layout = GTK.gtk_label_get_layout(this.labelHandle);
/* 182 */       long context = OS.pango_layout_get_context(layout);
/* 183 */       long lang = OS.pango_context_get_language(context);
/* 184 */       long font = getFontDescription();
/* 185 */       long metrics = OS.pango_context_get_metrics(context, font, lang);
/* 186 */       int ascent = OS.PANGO_PIXELS(OS.pango_font_metrics_get_ascent(metrics));
/* 187 */       int descent = OS.PANGO_PIXELS(OS.pango_font_metrics_get_descent(metrics));
/* 188 */       OS.pango_font_metrics_unref(metrics);
/* 189 */       int fontHeight = ascent + descent;
/* 190 */       if (GTK.GTK3) {
/* 191 */         int[] bufferBottom = new int[1];
/* 192 */         int[] bufferTop = new int[1];
/* 193 */         OS.g_object_get(this.labelHandle, OS.margin_bottom, bufferBottom, 0L);
/* 194 */         OS.g_object_get(this.labelHandle, OS.margin_top, bufferTop, 0L);
/* 195 */         fontHeight += bufferBottom[0] + bufferTop[0];
/*     */       } else {
/* 197 */         int[] bufferYpad = new int[1];
/* 198 */         OS.g_object_get(this.labelHandle, OS.ypad, bufferYpad, 0L);
/* 199 */         fontHeight += 2 * bufferYpad[0];
/*     */       }
/* 201 */       if (this.frameHandle != 0L) {
/* 202 */         fontHeight += 2 * getThickness(this.frameHandle).y;
/* 203 */         fontHeight += 2 * GTK.gtk_container_get_border_width(this.frameHandle);
/*     */       }
/* 205 */       size.y = Math.max(size.y, fontHeight);
/*     */     }
/* 207 */     return size;
/*     */   }
/*     */   
/*     */   void createHandle(int index)
/*     */   {
/* 212 */     this.state |= 0x10008;
/* 213 */     this.fixedHandle = OS.g_object_new(this.display.gtk_fixed_get_type(), 0L);
/* 214 */     if (this.fixedHandle == 0L) error(2);
/* 215 */     GTK.gtk_widget_set_has_window(this.fixedHandle, true);
/* 216 */     if ((this.style & 0x2) != 0) {
/* 217 */       if ((this.style & 0x100) != 0) {
/* 218 */         this.handle = gtk_separator_new(0);
/*     */       } else {
/* 220 */         this.handle = gtk_separator_new(1);
/*     */       }
/* 222 */       if (this.handle == 0L) error(2);
/*     */     } else {
/* 224 */       this.handle = GTK.gtk_event_box_new();
/* 225 */       if (this.handle == 0L) error(2);
/* 226 */       this.boxHandle = gtk_box_new(0, false, 0);
/* 227 */       if (this.boxHandle == 0L) error(2);
/* 228 */       this.labelHandle = GTK.gtk_label_new_with_mnemonic(null);
/* 229 */       if (this.labelHandle == 0L) error(2);
/* 230 */       this.imageHandle = GTK.gtk_image_new();
/* 231 */       if (this.imageHandle == 0L) error(2);
/* 232 */       GTK.gtk_container_add(this.handle, this.boxHandle);
/* 233 */       GTK.gtk_container_add(this.boxHandle, this.labelHandle);
/* 234 */       GTK.gtk_container_add(this.boxHandle, this.imageHandle);
/* 235 */       GTK.gtk_box_set_child_packing(this.boxHandle, this.labelHandle, true, true, 0, 0);
/* 236 */       GTK.gtk_box_set_child_packing(this.boxHandle, this.imageHandle, true, true, 0, 0);
/*     */     }
/* 238 */     if ((this.style & 0x800) != 0) {
/* 239 */       this.frameHandle = GTK.gtk_frame_new(null);
/* 240 */       if (this.frameHandle == 0L) error(2);
/* 241 */       GTK.gtk_container_add(this.fixedHandle, this.frameHandle);
/* 242 */       GTK.gtk_container_add(this.frameHandle, this.handle);
/* 243 */       GTK.gtk_frame_set_shadow_type(this.frameHandle, 3);
/*     */     } else {
/* 245 */       GTK.gtk_container_add(this.fixedHandle, this.handle);
/*     */     }
/* 247 */     if ((this.style & 0x2) != 0) return;
/* 248 */     if ((this.style & 0x40) != 0) {
/* 249 */       GTK.gtk_label_set_line_wrap(this.labelHandle, true);
/* 250 */       GTK.gtk_label_set_line_wrap_mode(this.labelHandle, 2);
/*     */     }
/*     */     
/*     */ 
/* 254 */     if (GTK.GTK3) {
/* 255 */       setFontDescription(defaultFont().handle);
/*     */     }
/* 257 */     setAlignment();
/*     */   }
/*     */   
/*     */   void createWidget(int index)
/*     */   {
/* 262 */     super.createWidget(index);
/* 263 */     this.text = "";
/*     */   }
/*     */   
/*     */   void deregister()
/*     */   {
/* 268 */     super.deregister();
/* 269 */     if (this.frameHandle != 0L) this.display.removeWidget(this.frameHandle);
/* 270 */     if (this.labelHandle != 0L) this.display.removeWidget(this.labelHandle);
/* 271 */     if (this.imageHandle != 0L) this.display.removeWidget(this.imageHandle);
/* 272 */     if (this.boxHandle != 0L) this.display.removeWidget(this.boxHandle);
/*     */   }
/*     */   
/*     */   long eventHandle()
/*     */   {
/* 277 */     return this.fixedHandle;
/*     */   }
/*     */   
/*     */   long cssHandle()
/*     */   {
/* 282 */     if ((this.style & 0x2) == 0) {
/* 283 */       return this.labelHandle;
/*     */     }
/* 285 */     return this.handle;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getAlignment()
/*     */   {
/* 303 */     checkWidget();
/* 304 */     if ((this.style & 0x2) != 0) return 0;
/* 305 */     if ((this.style & 0x4000) != 0) return 16384;
/* 306 */     if ((this.style & 0x1000000) != 0) return 16777216;
/* 307 */     if ((this.style & 0x20000) != 0) return 131072;
/* 308 */     return 16384;
/*     */   }
/*     */   
/*     */   int getBorderWidthInPixels()
/*     */   {
/* 313 */     checkWidget();
/* 314 */     if (this.frameHandle != 0L) {
/* 315 */       return getThickness(this.frameHandle).x;
/*     */     }
/* 317 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Image getImage()
/*     */   {
/* 332 */     checkWidget();
/* 333 */     return this.image;
/*     */   }
/*     */   
/*     */   String getNameText()
/*     */   {
/* 338 */     return getText();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getText()
/*     */   {
/* 354 */     checkWidget();
/* 355 */     if ((this.style & 0x2) != 0) return "";
/* 356 */     return this.text;
/*     */   }
/*     */   
/*     */   void hookEvents()
/*     */   {
/* 361 */     super.hookEvents();
/* 362 */     if (this.labelHandle != 0L) {
/* 363 */       OS.g_signal_connect_closure_by_id(this.labelHandle, this.display.signalIds[32], 0, this.display.getClosure(32), false);
/*     */     }
/*     */   }
/*     */   
/*     */   boolean isDescribedByLabel()
/*     */   {
/* 369 */     return false;
/*     */   }
/*     */   
/*     */   boolean mnemonicHit(char key)
/*     */   {
/* 374 */     if (this.labelHandle == 0L) return false;
/* 375 */     boolean result = super.mnemonicHit(this.labelHandle, key);
/* 376 */     if (result) {
/* 377 */       Control control = this;
/* 378 */       while (control.parent != null) {
/* 379 */         Control[] children = control.parent._getChildren();
/* 380 */         int index = 0;
/* 381 */         while ((index < children.length) && 
/* 382 */           (children[index] != control)) {
/* 383 */           index++;
/*     */         }
/* 385 */         index++;
/* 386 */         if ((index < children.length) && 
/* 387 */           (children[index].setFocus())) { return result;
/*     */         }
/* 389 */         control = control.parent;
/*     */       }
/*     */     }
/* 392 */     return result;
/*     */   }
/*     */   
/*     */   boolean mnemonicMatch(char key)
/*     */   {
/* 397 */     if (this.labelHandle == 0L) return false;
/* 398 */     return mnemonicMatch(this.labelHandle, key);
/*     */   }
/*     */   
/*     */   void register()
/*     */   {
/* 403 */     super.register();
/* 404 */     if (this.boxHandle != 0L) this.display.addWidget(this.boxHandle, this);
/* 405 */     if (this.frameHandle != 0L) this.display.addWidget(this.frameHandle, this);
/* 406 */     if (this.labelHandle != 0L) this.display.addWidget(this.labelHandle, this);
/* 407 */     if (this.imageHandle != 0L) this.display.addWidget(this.imageHandle, this);
/*     */   }
/*     */   
/*     */   void releaseHandle()
/*     */   {
/* 412 */     super.releaseHandle();
/* 413 */     this.frameHandle = (this.imageHandle = this.labelHandle = this.boxHandle = 0L);
/*     */   }
/*     */   
/*     */   void releaseWidget()
/*     */   {
/* 418 */     super.releaseWidget();
/* 419 */     if (this.imageList != null) this.imageList.dispose();
/* 420 */     this.imageList = null;
/* 421 */     this.image = null;
/* 422 */     this.text = null;
/*     */   }
/*     */   
/*     */   void resizeHandle(int width, int height)
/*     */   {
/* 427 */     if (GTK.GTK3) {
/* 428 */       OS.swt_fixed_resize(GTK.gtk_widget_get_parent(this.fixedHandle), this.fixedHandle, width, height);
/* 429 */       long child = this.frameHandle != 0L ? this.frameHandle : this.handle;
/* 430 */       Point sizes = resizeCalculationsGTK3(child, width, height);
/* 431 */       width = sizes.x;
/* 432 */       height = sizes.y;
/* 433 */       OS.swt_fixed_resize(GTK.gtk_widget_get_parent(child), child, width, height);
/*     */     } else {
/* 435 */       GTK.gtk_widget_set_size_request(this.fixedHandle, width, height);
/* 436 */       GTK.gtk_widget_set_size_request(this.frameHandle != 0L ? this.frameHandle : this.handle, width, height);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAlignment(int alignment)
/*     */   {
/* 454 */     checkWidget();
/* 455 */     if ((this.style & 0x2) != 0) return;
/* 456 */     if ((alignment & 0x1024000) == 0) return;
/* 457 */     this.style &= 0xFEFDBFFF;
/* 458 */     this.style |= alignment & 0x1024000;
/* 459 */     setAlignment();
/*     */   }
/*     */   
/*     */   void setAlignment() {
/* 463 */     if ((this.style & 0x4000) != 0) {
/* 464 */       if (GTK.GTK_VERSION >= OS.VERSION(3, 16, 0)) {
/* 465 */         gtk_widget_set_align(this.labelHandle, 1, 1);
/* 466 */         gtk_label_set_align(0.0F, 0.0F);
/* 467 */         gtk_widget_set_align(this.imageHandle, 1, 3);
/*     */       } else {
/* 469 */         GTK.gtk_misc_set_alignment(this.labelHandle, 0.0F, 0.0F);
/* 470 */         GTK.gtk_misc_set_alignment(this.imageHandle, 0.0F, 0.5F);
/*     */       }
/* 472 */       GTK.gtk_label_set_justify(this.labelHandle, 0);
/* 473 */       return;
/*     */     }
/* 475 */     if ((this.style & 0x1000000) != 0) {
/* 476 */       if (GTK.GTK_VERSION >= OS.VERSION(3, 16, 0)) {
/* 477 */         gtk_widget_set_align(this.labelHandle, 3, 1);
/* 478 */         gtk_label_set_align(0.5F, 0.0F);
/* 479 */         gtk_widget_set_align(this.imageHandle, 3, 3);
/*     */       } else {
/* 481 */         GTK.gtk_misc_set_alignment(this.labelHandle, 0.5F, 0.0F);
/* 482 */         GTK.gtk_misc_set_alignment(this.imageHandle, 0.5F, 0.5F);
/*     */       }
/*     */       
/* 485 */       GTK.gtk_label_set_justify(this.labelHandle, 2);
/* 486 */       return;
/*     */     }
/* 488 */     if ((this.style & 0x20000) != 0) {
/* 489 */       if (GTK.GTK_VERSION >= OS.VERSION(3, 16, 0)) {
/* 490 */         gtk_widget_set_align(this.labelHandle, 2, 1);
/* 491 */         gtk_label_set_align(1.0F, 0.0F);
/* 492 */         gtk_widget_set_align(this.imageHandle, 2, 3);
/*     */       } else {
/* 494 */         GTK.gtk_misc_set_alignment(this.labelHandle, 1.0F, 0.0F);
/* 495 */         GTK.gtk_misc_set_alignment(this.imageHandle, 1.0F, 0.5F);
/*     */       }
/* 497 */       GTK.gtk_label_set_justify(this.labelHandle, 1);
/* 498 */       return;
/*     */     }
/*     */   }
/*     */   
/*     */   private void gtk_label_set_align(float xalign, float yalign) {
/* 503 */     GTK.gtk_label_set_xalign(this.labelHandle, xalign);
/* 504 */     GTK.gtk_label_set_yalign(this.labelHandle, yalign);
/*     */   }
/*     */   
/*     */   void setBackgroundGdkColor(GdkColor color)
/*     */   {
/* 509 */     assert (!GTK.GTK3) : "GTK2 code was run by GTK3";
/* 510 */     super.setBackgroundGdkColor(color);
/* 511 */     setBackgroundGdkColor(this.fixedHandle, color);
/* 512 */     if (this.labelHandle != 0L) setBackgroundGdkColor(this.labelHandle, color);
/* 513 */     if (this.imageHandle != 0L) { setBackgroundGdkColor(this.imageHandle, color);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   int setBounds(int x, int y, int width, int height, boolean move, boolean resize)
/*     */   {
/* 530 */     boolean fixWrap = (resize) && (this.labelHandle != 0L) && ((this.style & 0x40) != 0);
/* 531 */     if (fixWrap) GTK.gtk_widget_set_size_request(this.labelHandle, -1, -1);
/* 532 */     int result = super.setBounds(x, y, width, height, move, resize);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 544 */     if (fixWrap) {
/* 545 */       GtkAllocation allocation = new GtkAllocation();
/* 546 */       GTK.gtk_widget_get_allocation(this.handle, allocation);
/* 547 */       int labelWidth = allocation.width;
/* 548 */       int labelHeight = allocation.height;
/* 549 */       GTK.gtk_widget_set_size_request(this.labelHandle, labelWidth, labelHeight);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 554 */       GtkRequisition requisition = new GtkRequisition();
/* 555 */       gtk_widget_get_preferred_size(this.labelHandle, requisition);
/* 556 */       GTK.gtk_widget_get_allocation(this.labelHandle, allocation);
/* 557 */       allocation.width = labelWidth;
/* 558 */       allocation.height = labelHeight;
/* 559 */       GTK.gtk_widget_size_allocate(this.labelHandle, allocation);
/*     */     }
/* 561 */     return result;
/*     */   }
/*     */   
/*     */   void setFontDescription(long font)
/*     */   {
/* 566 */     super.setFontDescription(font);
/* 567 */     if (this.labelHandle != 0L) setFontDescription(this.labelHandle, font);
/* 568 */     if (this.imageHandle != 0L) { setFontDescription(this.imageHandle, font);
/*     */     }
/*     */     
/*     */ 
/* 572 */     if (GTK.GTK3)
/*     */     {
/* 574 */       int originalDirection = (this.style & 0x4000000) != 0 ? 2 : 1;
/* 575 */       int tempDirection = (this.style & 0x4000000) != 0 ? 1 : 2;
/* 576 */       GTK.gtk_widget_set_direction(this.labelHandle, tempDirection);
/* 577 */       GTK.gtk_widget_set_direction(this.labelHandle, originalDirection);
/*     */     }
/*     */   }
/*     */   
/*     */   void setForegroundGdkColor(GdkColor color)
/*     */   {
/* 583 */     assert (!GTK.GTK3) : "GTK2 code was run by GTK3";
/* 584 */     super.setForegroundGdkColor(color);
/* 585 */     setForegroundColor(this.fixedHandle, color);
/* 586 */     if (this.labelHandle != 0L) setForegroundColor(this.labelHandle, color);
/* 587 */     if (this.imageHandle != 0L) setForegroundColor(this.imageHandle, color);
/*     */   }
/*     */   
/*     */   void setForegroundGdkRGBA(GdkRGBA rgba)
/*     */   {
/* 592 */     assert (GTK.GTK3) : "GTK3 code was run by GTK2";
/* 593 */     super.setForegroundGdkRGBA(rgba);
/* 594 */     setForegroundGdkRGBA(this.fixedHandle, rgba);
/* 595 */     if (this.labelHandle != 0L) setForegroundGdkRGBA(this.labelHandle, rgba);
/* 596 */     if (this.imageHandle != 0L) setForegroundGdkRGBA(this.imageHandle, rgba);
/*     */   }
/*     */   
/*     */   void setOrientation(boolean create)
/*     */   {
/* 601 */     super.setOrientation(create);
/* 602 */     if (((this.style & 0x4000000) != 0) || (!create)) {
/* 603 */       int dir = (this.style & 0x4000000) != 0 ? 2 : 1;
/* 604 */       if (this.labelHandle != 0L) GTK.gtk_widget_set_direction(this.labelHandle, dir);
/* 605 */       if (this.imageHandle != 0L) { GTK.gtk_widget_set_direction(this.imageHandle, dir);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setImage(Image image)
/*     */   {
/* 624 */     checkWidget();
/* 625 */     if ((image != null) && (image.isDisposed())) {
/* 626 */       error(5);
/*     */     }
/* 628 */     if ((this.style & 0x2) != 0) return;
/* 629 */     this.image = image;
/* 630 */     if (this.imageList != null) this.imageList.dispose();
/* 631 */     this.imageList = null;
/* 632 */     if (image != null) {
/* 633 */       this.imageList = new ImageList();
/* 634 */       int imageIndex = this.imageList.add(image);
/* 635 */       long pixbuf = this.imageList.getPixbuf(imageIndex);
/* 636 */       gtk_image_set_from_pixbuf(this.imageHandle, pixbuf);
/* 637 */       GTK.gtk_widget_hide(this.labelHandle);
/* 638 */       GTK.gtk_widget_show(this.imageHandle);
/*     */     } else {
/* 640 */       gtk_image_set_from_pixbuf(this.imageHandle, 0L);
/* 641 */       GTK.gtk_widget_show(this.labelHandle);
/* 642 */       GTK.gtk_widget_hide(this.imageHandle);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setText(String string)
/*     */   {
/* 678 */     checkWidget();
/* 679 */     if (string == null) error(4);
/* 680 */     if ((this.style & 0x2) != 0) return;
/* 681 */     this.text = string;
/* 682 */     char[] chars = fixMnemonic(string);
/* 683 */     byte[] buffer = Converter.wcsToMbcs(chars, true);
/* 684 */     GTK.gtk_label_set_text_with_mnemonic(this.labelHandle, buffer);
/* 685 */     GTK.gtk_widget_hide(this.imageHandle);
/* 686 */     GTK.gtk_widget_show(this.labelHandle);
/*     */   }
/*     */   
/*     */   void setWidgetBackground()
/*     */   {
/* 691 */     if (GTK.GTK_VERSION >= OS.VERSION(3, 14, 0)) {
/* 692 */       GdkRGBA rgba = (this.state & 0x2000) != 0 ? getBackgroundGdkRGBA() : null;
/* 693 */       super.setBackgroundGdkRGBA(this.handle, rgba);
/*     */     } else {
/* 695 */       super.setWidgetBackground();
/*     */     }
/*     */   }
/*     */   
/*     */   void showWidget()
/*     */   {
/* 701 */     super.showWidget();
/* 702 */     if (this.frameHandle != 0L) GTK.gtk_widget_show(this.frameHandle);
/* 703 */     if (this.labelHandle != 0L) GTK.gtk_widget_show(this.labelHandle);
/* 704 */     if (this.boxHandle != 0L) GTK.gtk_widget_show(this.boxHandle);
/*     */   }
/*     */   
/*     */   long gtk_separator_new(int orientation) {
/* 708 */     long separator = 0L;
/* 709 */     if (GTK.GTK3) {
/* 710 */       separator = GTK.gtk_separator_new(orientation);
/*     */     }
/* 712 */     else if (orientation == 0) {
/* 713 */       separator = GTK.gtk_hseparator_new();
/*     */     } else {
/* 715 */       separator = GTK.gtk_vseparator_new();
/*     */     }
/*     */     
/* 718 */     return separator;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   long windowProc(long handle, long arg0, long user_data)
/*     */   {
/* 729 */     switch ((int)user_data) {
/*     */     case 18: 
/* 731 */       if ((GTK.GTK_VERSION >= OS.VERSION(3, 9, 0)) && (paintHandle() == handle)) {
/* 732 */         return gtk_draw(handle, arg0);
/*     */       }
/*     */       break;
/*     */     }
/* 736 */     return super.windowProc(handle, arg0, user_data);
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/widgets/Label.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */