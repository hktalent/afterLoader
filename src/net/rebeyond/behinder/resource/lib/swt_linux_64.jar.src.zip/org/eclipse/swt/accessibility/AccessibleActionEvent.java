/*    */ package org.eclipse.swt.accessibility;
/*    */ 
/*    */ import java.util.EventObject;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AccessibleActionEvent
/*    */   extends EventObject
/*    */ {
/*    */   public String result;
/*    */   public int count;
/*    */   public int index;
/*    */   public boolean localized;
/*    */   static final long serialVersionUID = 2849066792640153087L;
/*    */   
/*    */   public AccessibleActionEvent(Object source)
/*    */   {
/* 43 */     super(source);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String toString()
/*    */   {
/* 54 */     return "AccessibleActionEvent {string=" + this.result + " count=" + this.count + " index=" + this.index + "}";
/*    */   }
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/accessibility/AccessibleActionEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */