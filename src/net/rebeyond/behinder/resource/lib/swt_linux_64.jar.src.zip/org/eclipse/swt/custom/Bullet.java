/*     */ package org.eclipse.swt.custom;
/*     */ 
/*     */ import org.eclipse.swt.SWT;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Bullet
/*     */ {
/*     */   public int type;
/*     */   public StyleRange style;
/*     */   public String text;
/*     */   int[] linesIndices;
/*     */   int count;
/*     */   
/*     */   public Bullet(StyleRange style)
/*     */   {
/*  72 */     this(1, style);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Bullet(int type, StyleRange style)
/*     */   {
/*  86 */     if (style == null) SWT.error(4);
/*  87 */     if (style.metrics == null) SWT.error(4);
/*  88 */     this.type = type;
/*  89 */     this.style = style;
/*     */   }
/*     */   
/*  92 */   void addIndices(int startLine, int lineCount) { if (this.linesIndices == null) {
/*  93 */       this.linesIndices = new int[lineCount];
/*  94 */       this.count = lineCount;
/*  95 */       for (int i = 0; i < lineCount; i++) this.linesIndices[i] = (startLine + i);
/*     */     } else {
/*  97 */       int modifyStart = 0;
/*  98 */       while ((modifyStart < this.count) && 
/*  99 */         (startLine > this.linesIndices[modifyStart])) {
/* 100 */         modifyStart++;
/*     */       }
/* 102 */       int modifyEnd = modifyStart;
/* 103 */       while ((modifyEnd < this.count) && 
/* 104 */         (startLine + lineCount > this.linesIndices[modifyEnd])) {
/* 105 */         modifyEnd++;
/*     */       }
/* 107 */       int newSize = modifyStart + lineCount + this.count - modifyEnd;
/* 108 */       if (newSize > this.linesIndices.length) {
/* 109 */         int[] newLinesIndices = new int[newSize];
/* 110 */         System.arraycopy(this.linesIndices, 0, newLinesIndices, 0, this.count);
/* 111 */         this.linesIndices = newLinesIndices;
/*     */       }
/* 113 */       System.arraycopy(this.linesIndices, modifyEnd, this.linesIndices, modifyStart + lineCount, this.count - modifyEnd);
/* 114 */       for (int i = 0; i < lineCount; i++) this.linesIndices[(modifyStart + i)] = (startLine + i);
/* 115 */       this.count = newSize;
/*     */     }
/*     */   }
/*     */   
/* 119 */   int indexOf(int lineIndex) { for (int i = 0; i < this.count; i++) {
/* 120 */       if (this.linesIndices[i] == lineIndex) return i;
/*     */     }
/* 122 */     return -1;
/*     */   }
/*     */   
/*     */ 
/* 126 */   public int hashCode() { return this.style.hashCode() ^ this.type; }
/*     */   
/*     */   int[] removeIndices(int startLine, int replaceLineCount, int newLineCount, boolean update) {
/* 129 */     if (this.count == 0) return null;
/* 130 */     if (startLine > this.linesIndices[(this.count - 1)]) return null;
/* 131 */     int endLine = startLine + replaceLineCount;
/* 132 */     int delta = newLineCount - replaceLineCount;
/* 133 */     for (int i = 0; i < this.count; i++) {
/* 134 */       int index = this.linesIndices[i];
/* 135 */       if (startLine <= index) {
/* 136 */         int j = i;
/* 137 */         while ((j < this.count) && 
/* 138 */           (this.linesIndices[j] < endLine)) {
/* 139 */           j++;
/*     */         }
/* 141 */         if (update) {
/* 142 */           for (int k = j; k < this.count; k++) this.linesIndices[k] += delta;
/*     */         }
/* 144 */         int[] redrawLines = new int[this.count - j];
/* 145 */         System.arraycopy(this.linesIndices, j, redrawLines, 0, this.count - j);
/* 146 */         System.arraycopy(this.linesIndices, j, this.linesIndices, i, this.count - j);
/* 147 */         this.count -= j - i;
/* 148 */         return redrawLines;
/*     */       }
/*     */     }
/* 151 */     for (int i = 0; i < this.count; i++) this.linesIndices[i] += delta;
/* 152 */     return null;
/*     */   }
/*     */   
/* 155 */   int size() { return this.count; }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/custom/Bullet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */