/*      */ package org.eclipse.swt.browser;
/*      */ 
/*      */ import java.io.PrintStream;
/*      */ import org.eclipse.swt.SWT;
/*      */ import org.eclipse.swt.SWTException;
/*      */ import org.eclipse.swt.widgets.Composite;
/*      */ import org.eclipse.swt.widgets.Display;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class Browser
/*      */   extends Composite
/*      */ {
/*      */   WebBrowser webBrowser;
/*      */   int userStyle;
/*      */   boolean isClosing;
/*   50 */   static int DefaultType = -1;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final String NO_INPUT_METHOD = "org.eclipse.swt.internal.gtk.noInputMethod";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final String PACKAGE_PREFIX = "org.eclipse.swt.browser.";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final String PROPERTY_DEFAULTTYPE = "org.eclipse.swt.browser.DefaultType";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Browser(Composite parent, int style)
/*      */   {
/*   87 */     super(checkParent(parent), checkStyle(style));
/*   88 */     this.userStyle = style;
/*      */     
/*   90 */     String platform = SWT.getPlatform();
/*   91 */     if ("gtk".equals(platform)) {
/*   92 */       parent.getDisplay().setData("org.eclipse.swt.internal.gtk.noInputMethod", null);
/*      */     }
/*      */     
/*   95 */     style = getStyle();
/*   96 */     this.webBrowser = new BrowserFactory().createWebBrowser(style);
/*   97 */     if (this.webBrowser != null) {
/*   98 */       this.webBrowser.setBrowser(this);
/*   99 */       this.webBrowser.create(parent, style);
/*  100 */       return;
/*      */     }
/*  102 */     dispose();
/*      */     
/*  104 */     String errMsg = " because no underlying browser available.\n";
/*  105 */     switch (SWT.getPlatform()) {
/*      */     case "gtk": 
/*  107 */       String gtkVersion = System.getProperty("org.eclipse.swt.internal.gtk.version");
/*  108 */       boolean isGtk2 = Integer.parseInt(gtkVersion.substring(0, 1)) == 2;
/*  109 */       if (isGtk2) {
/*  110 */         errMsg = errMsg + "   SWT on GTK 2.x detected. It is reccomended to use SWT on GTK 3.x and Webkit2 API.\n";
/*      */       } else {
/*  112 */         errMsg = errMsg + "   Please ensure Webkit with its Gtk 3.x bindings installed. Webkit2 API level preferred.\n";
/*      */       }
/*  114 */       break;
/*      */     case "cocoa": 
/*  116 */       errMsg = errMsg + " SWT failed to load webkit library.\n";
/*  117 */       break;
/*      */     case "win32": 
/*  119 */       errMsg = errMsg + " SWT uses either IE or Webkit. Either SWT.WEBKIT flag is passed and Webkit library was not loaded properly by SWT or SWT failed to load IE.\n";
/*      */       
/*  121 */       break;
/*      */     }
/*      */     
/*      */     
/*  125 */     SWT.error(2, null, errMsg);
/*      */   }
/*      */   
/*      */   static Composite checkParent(Composite parent) {
/*  129 */     String platform = SWT.getPlatform();
/*  130 */     if (!"gtk".equals(platform)) { return parent;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  138 */     if ((parent != null) && (!parent.isDisposed())) {
/*  139 */       Display display = parent.getDisplay();
/*  140 */       if ((display != null) && 
/*  141 */         (display.getThread() == Thread.currentThread())) {
/*  142 */         display.setData("org.eclipse.swt.internal.gtk.noInputMethod", "true");
/*      */       }
/*      */     }
/*      */     
/*  146 */     return parent;
/*      */   }
/*      */   
/*      */   static int checkStyle(int style)
/*      */   {
/*  151 */     String platform = SWT.getPlatform();
/*  152 */     if (DefaultType == -1)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       try
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  174 */         Class.forName("org.eclipse.swt.browser.BrowserInitializer");
/*      */       }
/*      */       catch (ClassNotFoundException localClassNotFoundException) {}
/*      */       
/*      */ 
/*  179 */       String value = System.getProperty("org.eclipse.swt.browser.DefaultType");
/*  180 */       if (value != null) {
/*  181 */         int index = 0;
/*  182 */         int length = value.length();
/*      */         do {
/*  184 */           int newIndex = value.indexOf(',', index);
/*  185 */           if (newIndex == -1) {
/*  186 */             newIndex = length;
/*      */           }
/*  188 */           String current = value.substring(index, newIndex).trim();
/*  189 */           if (current.equalsIgnoreCase("webkit")) {
/*  190 */             DefaultType = 65536;
/*  191 */             break; }
/*  192 */           if ((current.equalsIgnoreCase("ie")) && ("win32".equals(platform))) {
/*  193 */             DefaultType = 0;
/*  194 */             break;
/*      */           }
/*  196 */           index = newIndex + 1;
/*  197 */         } while (index < length);
/*      */       }
/*  199 */       if (DefaultType == -1) {
/*  200 */         DefaultType = 0;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  205 */     if ((style & 0x8000) != 0) {
/*  206 */       System.err.println("Unsupported Browser Type: SWT.MOZILLA style is deprecated.\nIt'll be removed from the user specified style. Browser will be created with the modified style and if no other style bit is specified, browser with SWT.NONE style will be created");
/*      */       
/*      */ 
/*  209 */       style &= 0xFFFF7FFF;
/*      */     }
/*      */     
/*  212 */     if ((style & 0x10000) == 0) {
/*  213 */       style |= DefaultType;
/*      */     }
/*  215 */     if ((style & 0x10000) != 0) {
/*  216 */       return style;
/*      */     }
/*  218 */     if ("win32".equals(platform))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*  223 */       return style & 0xF7FF;
/*      */     }
/*  225 */     return style;
/*      */   }
/*      */   
/*      */   protected void checkWidget()
/*      */   {
/*  230 */     super.checkWidget();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void clearSessions() {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String getCookie(String name, String url)
/*      */   {
/*  258 */     if (name == null) SWT.error(4);
/*  259 */     if (url == null) SWT.error(4);
/*  260 */     return WebBrowser.GetCookie(name, url);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean setCookie(String value, String url)
/*      */   {
/*  288 */     if (value == null) SWT.error(4);
/*  289 */     if (url == null) SWT.error(4);
/*  290 */     return WebBrowser.SetCookie(value, url, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addAuthenticationListener(AuthenticationListener listener)
/*      */   {
/*  315 */     checkWidget();
/*  316 */     if (listener == null) SWT.error(4);
/*  317 */     this.webBrowser.addAuthenticationListener(listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addCloseWindowListener(CloseWindowListener listener)
/*      */   {
/*  342 */     checkWidget();
/*  343 */     if (listener == null) SWT.error(4);
/*  344 */     this.webBrowser.addCloseWindowListener(listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addLocationListener(LocationListener listener)
/*      */   {
/*  370 */     checkWidget();
/*  371 */     if (listener == null) SWT.error(4);
/*  372 */     this.webBrowser.addLocationListener(listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addOpenWindowListener(OpenWindowListener listener)
/*      */   {
/*  397 */     checkWidget();
/*  398 */     if (listener == null) SWT.error(4);
/*  399 */     this.webBrowser.addOpenWindowListener(listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addProgressListener(ProgressListener listener)
/*      */   {
/*  421 */     checkWidget();
/*  422 */     if (listener == null) SWT.error(4);
/*  423 */     this.webBrowser.addProgressListener(listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addStatusTextListener(StatusTextListener listener)
/*      */   {
/*  448 */     checkWidget();
/*  449 */     if (listener == null) SWT.error(4);
/*  450 */     this.webBrowser.addStatusTextListener(listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addTitleListener(TitleListener listener)
/*      */   {
/*  472 */     checkWidget();
/*  473 */     if (listener == null) SWT.error(4);
/*  474 */     this.webBrowser.addTitleListener(listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addVisibilityWindowListener(VisibilityWindowListener listener)
/*      */   {
/*  496 */     checkWidget();
/*  497 */     if (listener == null) SWT.error(4);
/*  498 */     this.webBrowser.addVisibilityWindowListener(listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean back()
/*      */   {
/*  516 */     checkWidget();
/*  517 */     return this.webBrowser.back();
/*      */   }
/*      */   
/*      */   protected void checkSubclass()
/*      */   {
/*  522 */     String name = getClass().getName();
/*  523 */     int index = name.lastIndexOf('.');
/*  524 */     if (!name.substring(0, index + 1).equals("org.eclipse.swt.browser.")) {
/*  525 */       SWT.error(43);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean execute(String script)
/*      */   {
/*  555 */     checkWidget();
/*  556 */     if (script == null) SWT.error(4);
/*  557 */     return this.webBrowser.execute(script);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean close()
/*      */   {
/*  577 */     checkWidget();
/*  578 */     if (this.webBrowser.close()) {
/*  579 */       this.isClosing = true;
/*  580 */       dispose();
/*  581 */       this.isClosing = false;
/*  582 */       return true;
/*      */     }
/*  584 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object evaluate(String script)
/*      */     throws SWTException
/*      */   {
/*  632 */     checkWidget();
/*  633 */     return evaluate(script, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object evaluate(String script, boolean trusted)
/*      */     throws SWTException
/*      */   {
/*  684 */     checkWidget();
/*  685 */     if (script == null) SWT.error(4);
/*  686 */     return this.webBrowser.evaluate(script, trusted);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean forward()
/*      */   {
/*  704 */     checkWidget();
/*  705 */     return this.webBrowser.forward();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getBrowserType()
/*      */   {
/*  717 */     checkWidget();
/*  718 */     return this.webBrowser.getBrowserType();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getJavascriptEnabled()
/*      */   {
/*  740 */     checkWidget();
/*  741 */     return this.webBrowser.jsEnabledOnNextPage;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getStyle()
/*      */   {
/*  750 */     return super.getStyle() | this.userStyle & 0x800;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getText()
/*      */   {
/*  772 */     checkWidget();
/*  773 */     return this.webBrowser.getText();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getUrl()
/*      */   {
/*  791 */     checkWidget();
/*  792 */     return this.webBrowser.getUrl();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public Object getWebBrowser()
/*      */   {
/*  811 */     checkWidget();
/*  812 */     return this.webBrowser.getWebBrowser();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isBackEnabled()
/*      */   {
/*  829 */     checkWidget();
/*  830 */     return this.webBrowser.isBackEnabled();
/*      */   }
/*      */   
/*      */   public boolean isFocusControl()
/*      */   {
/*  835 */     checkWidget();
/*  836 */     if (this.webBrowser.isFocusControl()) return true;
/*  837 */     return super.isFocusControl();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isForwardEnabled()
/*      */   {
/*  854 */     checkWidget();
/*  855 */     return this.webBrowser.isForwardEnabled();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void refresh()
/*      */   {
/*  869 */     checkWidget();
/*  870 */     this.webBrowser.refresh();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeAuthenticationListener(AuthenticationListener listener)
/*      */   {
/*  891 */     checkWidget();
/*  892 */     if (listener == null) SWT.error(4);
/*  893 */     this.webBrowser.removeAuthenticationListener(listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeCloseWindowListener(CloseWindowListener listener)
/*      */   {
/*  914 */     checkWidget();
/*  915 */     if (listener == null) SWT.error(4);
/*  916 */     this.webBrowser.removeCloseWindowListener(listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeLocationListener(LocationListener listener)
/*      */   {
/*  937 */     checkWidget();
/*  938 */     if (listener == null) SWT.error(4);
/*  939 */     this.webBrowser.removeLocationListener(listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeOpenWindowListener(OpenWindowListener listener)
/*      */   {
/*  960 */     checkWidget();
/*  961 */     if (listener == null) SWT.error(4);
/*  962 */     this.webBrowser.removeOpenWindowListener(listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeProgressListener(ProgressListener listener)
/*      */   {
/*  984 */     checkWidget();
/*  985 */     if (listener == null) SWT.error(4);
/*  986 */     this.webBrowser.removeProgressListener(listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeStatusTextListener(StatusTextListener listener)
/*      */   {
/* 1007 */     checkWidget();
/* 1008 */     if (listener == null) SWT.error(4);
/* 1009 */     this.webBrowser.removeStatusTextListener(listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeTitleListener(TitleListener listener)
/*      */   {
/* 1031 */     checkWidget();
/* 1032 */     if (listener == null) SWT.error(4);
/* 1033 */     this.webBrowser.removeTitleListener(listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeVisibilityWindowListener(VisibilityWindowListener listener)
/*      */   {
/* 1055 */     checkWidget();
/* 1056 */     if (listener == null) SWT.error(4);
/* 1057 */     this.webBrowser.removeVisibilityWindowListener(listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setJavascriptEnabled(boolean enabled)
/*      */   {
/* 1075 */     checkWidget();
/* 1076 */     this.webBrowser.jsEnabledOnNextPage = enabled;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean setText(String html)
/*      */   {
/* 1107 */     checkWidget();
/* 1108 */     return setText(html, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean setText(String html, boolean trusted)
/*      */   {
/* 1148 */     checkWidget();
/* 1149 */     if (html == null) SWT.error(4);
/* 1150 */     return this.webBrowser.setText(html, trusted);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean setUrl(String url)
/*      */   {
/* 1175 */     checkWidget();
/* 1176 */     return setUrl(url, null, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean setUrl(String url, String postData, String[] headers)
/*      */   {
/* 1206 */     checkWidget();
/* 1207 */     if (url == null) SWT.error(4);
/* 1208 */     return this.webBrowser.setUrl(url, postData, headers);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void stop()
/*      */   {
/* 1222 */     checkWidget();
/* 1223 */     this.webBrowser.stop();
/*      */   }
/*      */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/browser/Browser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */