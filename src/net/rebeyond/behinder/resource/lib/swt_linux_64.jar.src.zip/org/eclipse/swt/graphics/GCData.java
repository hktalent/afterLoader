/*    */ package org.eclipse.swt.graphics;
/*    */ 
/*    */ import org.eclipse.swt.internal.gtk.GdkColor;
/*    */ import org.eclipse.swt.internal.gtk.GdkRGBA;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class GCData
/*    */ {
/*    */   public Device device;
/*    */   public int style;
/* 31 */   public int state = -1;
/*    */   
/*    */ 
/*    */ 
/*    */   public GdkColor foreground;
/*    */   
/*    */ 
/*    */ 
/*    */   public GdkColor background;
/*    */   
/*    */ 
/*    */ 
/*    */   public GdkRGBA foregroundRGBA;
/*    */   
/*    */ 
/*    */   public GdkRGBA backgroundRGBA;
/*    */   
/*    */ 
/*    */   public Font font;
/*    */   
/*    */ 
/*    */   public Pattern foregroundPattern;
/*    */   
/*    */ 
/*    */   public Pattern backgroundPattern;
/*    */   
/*    */ 
/*    */   public float lineWidth;
/*    */   
/*    */ 
/* 61 */   public int lineStyle = 1;
/*    */   public float[] lineDashes;
/*    */   public float lineDashesOffset;
/* 64 */   public float lineMiterLimit = 10.0F;
/* 65 */   public int lineCap = 1;
/* 66 */   public int lineJoin = 1;
/*    */   public boolean xorMode;
/* 68 */   public int alpha = 255;
/* 69 */   public int interpolation = -1;
/*    */   public Image image;
/*    */   public long clipRgn;
/*    */   public long context;
/*    */   public long layout;
/*    */   public long damageRgn;
/*    */   public long drawable;
/*    */   public long cairo;
/* 77 */   public double cairoXoffset; public double cairoYoffset; public boolean disposeCairo; public double[] identity; public double[] clippingTransform; public String string; public int stringWidth = -1;
/* 78 */   public int stringHeight = -1;
/*    */   public int drawFlags;
/*    */   public boolean realDrawable;
/* 81 */   public int width = -1; public int height = -1;
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/graphics/GCData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */