/*    */ package org.eclipse.swt.internal.image;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class JPEGSegment
/*    */ {
/*    */   public byte[] reference;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   JPEGSegment() {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public JPEGSegment(byte[] reference)
/*    */   {
/* 21 */     this.reference = reference;
/*    */   }
/*    */   
/*    */   public int signature() {
/* 25 */     return 0;
/*    */   }
/*    */   
/*    */   public boolean verify() {
/* 29 */     return getSegmentMarker() == signature();
/*    */   }
/*    */   
/*    */   public int getSegmentMarker() {
/* 33 */     return (this.reference[0] & 0xFF) << 8 | this.reference[1] & 0xFF;
/*    */   }
/*    */   
/*    */   public void setSegmentMarker(int marker) {
/* 37 */     this.reference[0] = ((byte)((marker & 0xFF00) >> 8));
/* 38 */     this.reference[1] = ((byte)(marker & 0xFF));
/*    */   }
/*    */   
/*    */   public int getSegmentLength() {
/* 42 */     return (this.reference[2] & 0xFF) << 8 | this.reference[3] & 0xFF;
/*    */   }
/*    */   
/*    */   public void setSegmentLength(int length) {
/* 46 */     this.reference[2] = ((byte)((length & 0xFF00) >> 8));
/* 47 */     this.reference[3] = ((byte)(length & 0xFF));
/*    */   }
/*    */   
/*    */   public boolean writeToStream(LEDataOutputStream byteStream) {
/*    */     try {
/* 52 */       byteStream.write(this.reference);
/* 53 */       return true;
/*    */     } catch (Exception e) {}
/* 55 */     return false;
/*    */   }
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/internal/image/JPEGSegment.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */