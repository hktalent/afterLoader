/*     */ package org.eclipse.swt.graphics;
/*     */ 
/*     */ import org.eclipse.swt.SWT;
/*     */ import org.eclipse.swt.internal.DPIUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class GlyphMetrics
/*     */ {
/*     */   public int ascent;
/*     */   public int descent;
/*     */   public int width;
/*     */   
/*     */   public GlyphMetrics(int ascent, int descent, int width)
/*     */   {
/*  66 */     if ((ascent < 0) || (descent < 0) || (width < 0)) {
/*  67 */       SWT.error(5);
/*     */     }
/*  69 */     this.ascent = ascent;
/*  70 */     this.descent = descent;
/*  71 */     this.width = width;
/*     */   }
/*     */   
/*     */   int getAscentInPixels() {
/*  75 */     return DPIUtil.autoScaleUp(this.ascent);
/*     */   }
/*     */   
/*     */   int getDescentInPixels() {
/*  79 */     return DPIUtil.autoScaleUp(this.descent);
/*     */   }
/*     */   
/*     */   int getWidthInPixels() {
/*  83 */     return DPIUtil.autoScaleUp(this.width);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object object)
/*     */   {
/*  98 */     if (object == this) return true;
/*  99 */     if (!(object instanceof GlyphMetrics)) return false;
/* 100 */     GlyphMetrics metrics = (GlyphMetrics)object;
/* 101 */     return (metrics.ascent == this.ascent) && (metrics.descent == this.descent) && (metrics.width == this.width);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 116 */     return this.ascent ^ this.descent ^ this.width;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 127 */     return "GlyphMetrics {" + this.ascent + ", " + this.descent + ", " + this.width + "}";
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/graphics/GlyphMetrics.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */