/*     */ package org.eclipse.swt.dnd;
/*     */ 
/*     */ import org.eclipse.swt.internal.C;
/*     */ import org.eclipse.swt.internal.Converter;
/*     */ import org.eclipse.swt.internal.gtk.GDK;
/*     */ import org.eclipse.swt.internal.gtk.GTK;
/*     */ import org.eclipse.swt.internal.gtk.OS;
/*     */ import org.eclipse.swt.widgets.Display;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Clipboard
/*     */ {
/*     */   private Display display;
/*  39 */   static long GTKCLIPBOARD = GTK.gtk_clipboard_get(0L);
/*  40 */   static { byte[] buffer = Converter.wcsToMbcs("PRIMARY", true);
/*  41 */     long primary = GDK.gdk_atom_intern(buffer, false);
/*  42 */     GTKPRIMARYCLIPBOARD = GTK.gtk_clipboard_get(primary);
/*  43 */     buffer = Converter.wcsToMbcs("TARGETS", true);
/*  44 */     TARGET = GDK.gdk_atom_intern(buffer, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Clipboard(Display display)
/*     */   {
/*  63 */     checkSubclass();
/*  64 */     if (display == null) {
/*  65 */       display = Display.getCurrent();
/*  66 */       if (display == null) {
/*  67 */         display = Display.getDefault();
/*     */       }
/*     */     }
/*  70 */     if (display.getThread() != Thread.currentThread()) {
/*  71 */       DND.error(22);
/*     */     }
/*  73 */     this.display = display;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void checkSubclass()
/*     */   {
/* 104 */     String name = getClass().getName();
/* 105 */     String validName = Clipboard.class.getName();
/* 106 */     if (!validName.equals(name)) {
/* 107 */       DND.error(43);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void checkWidget()
/*     */   {
/* 133 */     Display display = this.display;
/* 134 */     if (display == null) DND.error(24);
/* 135 */     if (display.getThread() != Thread.currentThread()) DND.error(22);
/* 136 */     if (display.isDisposed()) { DND.error(24);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void clearContents()
/*     */   {
/* 154 */     clearContents(1);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void clearContents(int clipboards)
/*     */   {
/* 184 */     checkWidget();
/* 185 */     ClipboardProxy proxy = ClipboardProxy._getInstance(this.display);
/* 186 */     proxy.clear(this, clipboards);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void dispose()
/*     */   {
/* 202 */     if (isDisposed()) return;
/* 203 */     if (this.display.getThread() != Thread.currentThread()) DND.error(22);
/* 204 */     this.display = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getContents(Transfer transfer)
/*     */   {
/* 240 */     return getContents(transfer, 1);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getContents(Transfer transfer, int clipboards)
/*     */   {
/* 287 */     checkWidget();
/* 288 */     if (transfer == null) DND.error(4);
/* 289 */     long selection_data = 0L;
/* 290 */     int[] typeIds = transfer.getTypeIds();
/* 291 */     for (int i = 0; i < typeIds.length; i++) {
/* 292 */       if ((clipboards & 0x1) != 0) {
/* 293 */         selection_data = gtk_clipboard_wait_for_contents(GTKCLIPBOARD, typeIds[i]);
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 300 */         GDK.gdk_threads_leave();
/*     */       }
/* 302 */       if (selection_data != 0L) break;
/* 303 */       if ((clipboards & 0x2) != 0) {
/* 304 */         selection_data = gtk_clipboard_wait_for_contents(GTKPRIMARYCLIPBOARD, typeIds[i]);
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 311 */         GDK.gdk_threads_leave();
/*     */       }
/*     */     }
/* 314 */     if (selection_data == 0L) return null;
/* 315 */     TransferData tdata = new TransferData();
/* 316 */     tdata.type = GTK.gtk_selection_data_get_data_type(selection_data);
/* 317 */     tdata.pValue = GTK.gtk_selection_data_get_data(selection_data);
/* 318 */     tdata.length = GTK.gtk_selection_data_get_length(selection_data);
/* 319 */     tdata.format = GTK.gtk_selection_data_get_format(selection_data);
/* 320 */     Object result = transfer.nativeToJava(tdata);
/* 321 */     GTK.gtk_selection_data_free(selection_data);
/* 322 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isDisposed()
/*     */   {
/* 339 */     return this.display == null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static long GTKPRIMARYCLIPBOARD;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setContents(Object[] data, Transfer[] dataTypes)
/*     */   {
/* 390 */     setContents(data, dataTypes, 1);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static long TARGET;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setContents(Object[] data, Transfer[] dataTypes, int clipboards)
/*     */   {
/* 453 */     checkWidget();
/* 454 */     if ((data == null) || (dataTypes == null) || (data.length != dataTypes.length) || (data.length == 0)) {
/* 455 */       DND.error(5);
/*     */     }
/* 457 */     for (int i = 0; i < data.length; i++) {
/* 458 */       if ((data[i] == null) || (dataTypes[i] == null) || (!dataTypes[i].validate(data[i]))) {
/* 459 */         DND.error(5);
/*     */       }
/*     */     }
/* 462 */     ClipboardProxy proxy = ClipboardProxy._getInstance(this.display);
/* 463 */     if (!proxy.setData(this, data, dataTypes, clipboards)) {
/* 464 */       DND.error(2002);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TransferData[] getAvailableTypes()
/*     */   {
/* 484 */     return getAvailableTypes(1);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TransferData[] getAvailableTypes(int clipboards)
/*     */   {
/* 511 */     checkWidget();
/* 512 */     TransferData[] result = null;
/* 513 */     if ((clipboards & 0x1) != 0) {
/* 514 */       int[] types = getAvailableClipboardTypes();
/* 515 */       result = new TransferData[types.length];
/* 516 */       for (int i = 0; i < types.length; i++) {
/* 517 */         result[i] = new TransferData();
/* 518 */         result[i].type = types[i];
/*     */       }
/*     */     }
/* 521 */     if ((clipboards & 0x2) != 0) {
/* 522 */       int[] types = getAvailablePrimaryTypes();
/* 523 */       int offset = 0;
/* 524 */       if (result != null) {
/* 525 */         TransferData[] newResult = new TransferData[result.length + types.length];
/* 526 */         System.arraycopy(result, 0, newResult, 0, result.length);
/* 527 */         offset = result.length;
/* 528 */         result = newResult;
/*     */       } else {
/* 530 */         result = new TransferData[types.length];
/*     */       }
/* 532 */       for (int i = 0; i < types.length; i++) {
/* 533 */         result[(offset + i)] = new TransferData();
/* 534 */         result[(offset + i)].type = types[i];
/*     */       }
/*     */     }
/* 537 */     return result == null ? new TransferData[0] : result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] getAvailableTypeNames()
/*     */   {
/* 557 */     checkWidget();
/* 558 */     int[] types1 = getAvailableClipboardTypes();
/* 559 */     int[] types2 = getAvailablePrimaryTypes();
/* 560 */     String[] result = new String[types1.length + types2.length];
/* 561 */     int count = 0;
/* 562 */     for (int i = 0; i < types1.length; i++) {
/* 563 */       long pName = GDK.gdk_atom_name(types1[i]);
/* 564 */       if (pName != 0L)
/*     */       {
/*     */ 
/* 567 */         byte[] buffer = new byte[C.strlen(pName)];
/* 568 */         C.memmove(buffer, pName, buffer.length);
/* 569 */         OS.g_free(pName);
/* 570 */         result[(count++)] = ("GTKCLIPBOARD " + new String(Converter.mbcsToWcs(buffer)));
/*     */       } }
/* 572 */     for (int i = 0; i < types2.length; i++) {
/* 573 */       long pName = GDK.gdk_atom_name(types2[i]);
/* 574 */       if (pName != 0L)
/*     */       {
/*     */ 
/* 577 */         byte[] buffer = new byte[C.strlen(pName)];
/* 578 */         C.memmove(buffer, pName, buffer.length);
/* 579 */         OS.g_free(pName);
/* 580 */         result[(count++)] = ("GTKPRIMARYCLIPBOARD " + new String(Converter.mbcsToWcs(buffer)));
/*     */       } }
/* 582 */     if (count < result.length) {
/* 583 */       String[] temp = new String[count];
/* 584 */       System.arraycopy(result, 0, temp, 0, count);
/* 585 */       result = temp;
/*     */     }
/* 587 */     return result;
/*     */   }
/*     */   
/*     */   private int[] getAvailablePrimaryTypes() {
/* 591 */     int[] types = new int[0];
/* 592 */     long selection_data = gtk_clipboard_wait_for_contents(GTKPRIMARYCLIPBOARD, TARGET);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 599 */     GDK.gdk_threads_leave();
/* 600 */     if (selection_data != 0L) {
/*     */       try {
/* 602 */         int length = GTK.gtk_selection_data_get_length(selection_data);
/* 603 */         int format = GTK.gtk_selection_data_get_format(selection_data);
/* 604 */         long data = GTK.gtk_selection_data_get_data(selection_data);
/* 605 */         if (length != 0) {
/* 606 */           types = new int[length * 8 / format];
/* 607 */           C.memmove(types, data, length);
/*     */         }
/*     */       } finally {
/* 610 */         GTK.gtk_selection_data_free(selection_data);
/*     */       }
/*     */     }
/* 613 */     return types;
/*     */   }
/*     */   
/* 616 */   private int[] getAvailableClipboardTypes() { int[] types = new int[0];
/* 617 */     long selection_data = gtk_clipboard_wait_for_contents(GTKCLIPBOARD, TARGET);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 624 */     GDK.gdk_threads_leave();
/* 625 */     if (selection_data != 0L) {
/*     */       try {
/* 627 */         int length = GTK.gtk_selection_data_get_length(selection_data);
/* 628 */         int format = GTK.gtk_selection_data_get_format(selection_data);
/* 629 */         long data = GTK.gtk_selection_data_get_data(selection_data);
/* 630 */         if (length != 0) {
/* 631 */           types = new int[length * 8 / format];
/* 632 */           C.memmove(types, data, length);
/*     */         }
/*     */       } finally {
/* 635 */         GTK.gtk_selection_data_free(selection_data);
/*     */       }
/*     */     }
/* 638 */     return types;
/*     */   }
/*     */   
/*     */   long gtk_clipboard_wait_for_contents(long clipboard, long target) {
/* 642 */     long startTime = System.currentTimeMillis();
/* 643 */     String key = "org.eclipse.swt.internal.gtk.dispatchEvent";
/* 644 */     Display display = this.display;
/* 645 */     display.setData(key, new int[] { 16, 17, 18, 19 });
/* 646 */     long selection_data = GTK.gtk_clipboard_wait_for_contents(clipboard, target);
/* 647 */     display.setData(key, null);
/* 648 */     long duration = System.currentTimeMillis() - startTime;
/* 649 */     if ((selection_data == 0L) && (duration > 5000L))
/*     */     {
/* 651 */       ClipboardProxy._getInstance(display).setData(this, new String[] { " " }, new Transfer[] {
/* 652 */         TextTransfer.getInstance() }, clipboard == GTKCLIPBOARD ? 1 : 2);
/*     */     }
/*     */     
/* 655 */     return selection_data;
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/dnd/Clipboard.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */