/*     */ package org.eclipse.swt.graphics;
/*     */ 
/*     */ import org.eclipse.swt.SWT;
/*     */ import org.eclipse.swt.internal.DPIUtil;
/*     */ import org.eclipse.swt.internal.cairo.Cairo;
/*     */ import org.eclipse.swt.internal.cairo.cairo_path_data_t;
/*     */ import org.eclipse.swt.internal.cairo.cairo_path_t;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Path
/*     */   extends Resource
/*     */ {
/*     */   public long handle;
/*     */   boolean moved;
/*  54 */   boolean closed = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Path(Device device)
/*     */   {
/*  82 */     super(device);
/*  83 */     long surface = Cairo.cairo_image_surface_create(0, 1, 1);
/*  84 */     if (surface == 0L) SWT.error(2);
/*  85 */     this.handle = Cairo.cairo_create(surface);
/*  86 */     Cairo.cairo_surface_destroy(surface);
/*  87 */     if (this.handle == 0L) SWT.error(2);
/*  88 */     init();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Path(Device device, Path path, float flatness)
/*     */   {
/* 126 */     super(device);
/* 127 */     if (path == null) SWT.error(4);
/* 128 */     if (path.isDisposed()) SWT.error(5);
/* 129 */     long surface = Cairo.cairo_image_surface_create(0, 1, 1);
/* 130 */     if (surface == 0L) SWT.error(2);
/* 131 */     this.handle = Cairo.cairo_create(surface);
/* 132 */     Cairo.cairo_surface_destroy(surface);
/* 133 */     if (this.handle == 0L) { SWT.error(2);
/*     */     }
/* 135 */     flatness = Math.max(0.0F, flatness);
/* 136 */     long copy; long copy; if (flatness == 0.0F) {
/* 137 */       copy = Cairo.cairo_copy_path(path.handle);
/*     */     } else {
/* 139 */       double tolerance = Cairo.cairo_get_tolerance(path.handle);
/* 140 */       Cairo.cairo_set_tolerance(path.handle, flatness);
/* 141 */       copy = Cairo.cairo_copy_path_flat(path.handle);
/* 142 */       Cairo.cairo_set_tolerance(path.handle, tolerance);
/*     */     }
/* 144 */     if (copy == 0L) {
/* 145 */       Cairo.cairo_destroy(this.handle);
/* 146 */       SWT.error(2);
/*     */     }
/* 148 */     Cairo.cairo_append_path(this.handle, copy);
/* 149 */     Cairo.cairo_path_destroy(copy);
/* 150 */     init();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Path(Device device, PathData data)
/*     */   {
/* 182 */     this(device);
/* 183 */     if (data == null) SWT.error(4);
/* 184 */     init(data);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addArc(float x, float y, float width, float height, float startAngle, float arcAngle)
/*     */   {
/* 217 */     if (isDisposed()) SWT.error(44);
/* 218 */     x = DPIUtil.autoScaleUp(x);
/* 219 */     y = DPIUtil.autoScaleUp(y);
/* 220 */     width = DPIUtil.autoScaleUp(width);
/* 221 */     height = DPIUtil.autoScaleUp(height);
/* 222 */     addArcInPixels(x, y, width, height, startAngle, arcAngle);
/*     */   }
/*     */   
/*     */   void addArcInPixels(float x, float y, float width, float height, float startAngle, float arcAngle) {
/* 226 */     this.moved = true;
/* 227 */     if (width == height) {
/* 228 */       float angle = -startAngle * 3.1415927F / 180.0F;
/* 229 */       if (this.closed) Cairo.cairo_move_to(this.handle, x + width / 2.0F + width / 2.0F * Math.cos(angle), y + height / 2.0F + height / 2.0F * Math.sin(angle));
/* 230 */       if (arcAngle >= 0.0F) {
/* 231 */         Cairo.cairo_arc_negative(this.handle, x + width / 2.0F, y + height / 2.0F, width / 2.0F, angle, -(startAngle + arcAngle) * 3.1415927F / 180.0F);
/*     */       } else {
/* 233 */         Cairo.cairo_arc(this.handle, x + width / 2.0F, y + height / 2.0F, width / 2.0F, angle, -(startAngle + arcAngle) * 3.1415927F / 180.0F);
/*     */       }
/*     */     } else {
/* 236 */       Cairo.cairo_save(this.handle);
/* 237 */       Cairo.cairo_translate(this.handle, x + width / 2.0F, y + height / 2.0F);
/* 238 */       Cairo.cairo_scale(this.handle, width / 2.0F, height / 2.0F);
/* 239 */       float angle = -startAngle * 3.1415927F / 180.0F;
/* 240 */       if (this.closed) Cairo.cairo_move_to(this.handle, Math.cos(angle), Math.sin(angle));
/* 241 */       if (arcAngle >= 0.0F) {
/* 242 */         Cairo.cairo_arc_negative(this.handle, 0.0D, 0.0D, 1.0D, angle, -(startAngle + arcAngle) * 3.1415927F / 180.0F);
/*     */       } else {
/* 244 */         Cairo.cairo_arc(this.handle, 0.0D, 0.0D, 1.0D, angle, -(startAngle + arcAngle) * 3.1415927F / 180.0F);
/*     */       }
/* 246 */       Cairo.cairo_restore(this.handle);
/*     */     }
/* 248 */     this.closed = false;
/* 249 */     if (Math.abs(arcAngle) >= 360.0F) { close();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addPath(Path path)
/*     */   {
/* 266 */     if (isDisposed()) SWT.error(44);
/* 267 */     if (path == null) SWT.error(4);
/* 268 */     if (path.isDisposed()) SWT.error(5);
/* 269 */     this.moved = false;
/* 270 */     long copy = Cairo.cairo_copy_path(path.handle);
/* 271 */     if (copy == 0L) SWT.error(2);
/* 272 */     Cairo.cairo_append_path(this.handle, copy);
/* 273 */     Cairo.cairo_path_destroy(copy);
/* 274 */     this.closed = path.closed;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addRectangle(float x, float y, float width, float height)
/*     */   {
/* 290 */     if (isDisposed()) SWT.error(44);
/* 291 */     x = DPIUtil.autoScaleUp(x);
/* 292 */     y = DPIUtil.autoScaleUp(y);
/* 293 */     width = DPIUtil.autoScaleUp(width);
/* 294 */     height = DPIUtil.autoScaleUp(height);
/* 295 */     addRectangleInPixels(x, y, width, height);
/*     */   }
/*     */   
/*     */   void addRectangleInPixels(float x, float y, float width, float height) {
/* 299 */     this.moved = false;
/* 300 */     Cairo.cairo_rectangle(this.handle, x, y, width, height);
/* 301 */     this.closed = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addString(String string, float x, float y, Font font)
/*     */   {
/* 322 */     if (isDisposed()) SWT.error(44);
/* 323 */     if (font == null) SWT.error(4);
/* 324 */     if (font.isDisposed()) SWT.error(5);
/* 325 */     x = DPIUtil.autoScaleUp(x);
/* 326 */     y = DPIUtil.autoScaleUp(y);
/*     */     
/* 328 */     FontData fd = font.getFontData()[0];
/* 329 */     fd.setHeight(DPIUtil.autoScaleUp(fd.getHeight()));
/* 330 */     Font scaledFont = new Font(font.getDevice(), fd);
/* 331 */     addStringInPixels(string, x, y, scaledFont);
/* 332 */     scaledFont.dispose();
/*     */   }
/*     */   
/* 335 */   void addStringInPixels(String string, float x, float y, Font font) { this.moved = false;
/* 336 */     GC.addCairoString(this.handle, string, x, y, font);
/* 337 */     this.closed = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void close()
/*     */   {
/* 350 */     if (isDisposed()) SWT.error(44);
/* 351 */     Cairo.cairo_close_path(this.handle);
/* 352 */     this.moved = false;
/* 353 */     this.closed = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean contains(float x, float y, GC gc, boolean outline)
/*     */   {
/* 380 */     if (isDisposed()) SWT.error(44);
/* 381 */     if (gc == null) SWT.error(4);
/* 382 */     if (gc.isDisposed()) SWT.error(5);
/* 383 */     x = DPIUtil.autoScaleUp(x);
/* 384 */     y = DPIUtil.autoScaleUp(y);
/* 385 */     return containsInPixels(x, y, gc, outline);
/*     */   }
/*     */   
/*     */   boolean containsInPixels(float x, float y, GC gc, boolean outline) {
/* 389 */     gc.initCairo();
/* 390 */     gc.checkGC(120);
/* 391 */     boolean result = false;
/* 392 */     long cairo = gc.data.cairo;
/* 393 */     long copy = Cairo.cairo_copy_path(this.handle);
/* 394 */     if (copy == 0L) SWT.error(2);
/* 395 */     Cairo.cairo_append_path(cairo, copy);
/* 396 */     Cairo.cairo_path_destroy(copy);
/* 397 */     if (outline) {
/* 398 */       result = Cairo.cairo_in_stroke(cairo, x, y) != 0;
/*     */     } else {
/* 400 */       result = Cairo.cairo_in_fill(cairo, x, y) != 0;
/*     */     }
/* 402 */     Cairo.cairo_new_path(cairo);
/* 403 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void cubicTo(float cx1, float cy1, float cx2, float cy2, float x, float y)
/*     */   {
/* 421 */     if (isDisposed()) SWT.error(44);
/* 422 */     cx1 = DPIUtil.autoScaleUp(cx1);
/* 423 */     cy1 = DPIUtil.autoScaleUp(cy1);
/* 424 */     cx2 = DPIUtil.autoScaleUp(cx2);
/* 425 */     cy2 = DPIUtil.autoScaleUp(cy2);
/* 426 */     x = DPIUtil.autoScaleUp(x);
/* 427 */     y = DPIUtil.autoScaleUp(y);
/* 428 */     cubicToInPixels(cx1, cy1, cx2, cy2, x, y);
/*     */   }
/*     */   
/* 431 */   void cubicToInPixels(float cx1, float cy1, float cx2, float cy2, float x, float y) { if (!this.moved) {
/* 432 */       double[] currentX = new double[1];double[] currentY = new double[1];
/* 433 */       Cairo.cairo_get_current_point(this.handle, currentX, currentY);
/* 434 */       Cairo.cairo_move_to(this.handle, currentX[0], currentY[0]);
/* 435 */       this.moved = true;
/*     */     }
/* 437 */     Cairo.cairo_curve_to(this.handle, cx1, cy1, cx2, cy2, x, y);
/* 438 */     this.closed = false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void getBounds(float[] bounds)
/*     */   {
/* 457 */     if (isDisposed()) SWT.error(44);
/* 458 */     if (bounds == null) SWT.error(4);
/* 459 */     if (bounds.length < 4) SWT.error(5);
/* 460 */     getBoundsInPixels(bounds);
/* 461 */     for (int i = 0; i < bounds.length; i++)
/* 462 */       bounds[i] = DPIUtil.autoScaleDown(bounds[i]);
/*     */   }
/*     */   
/*     */   void getBoundsInPixels(float[] bounds) {
/* 466 */     long copy = Cairo.cairo_copy_path(this.handle);
/* 467 */     if (copy == 0L) SWT.error(2);
/* 468 */     cairo_path_t path = new cairo_path_t();
/* 469 */     Cairo.memmove(path, copy, cairo_path_t.sizeof);
/* 470 */     double minX = 0.0D;double minY = 0.0D;double maxX = 0.0D;double maxY = 0.0D;
/* 471 */     if (path.num_data > 0) {
/* 472 */       minX = minY = Double.POSITIVE_INFINITY;
/* 473 */       maxX = maxY = Double.NEGATIVE_INFINITY;
/* 474 */       int i = 0;
/* 475 */       double[] points = new double[6];
/* 476 */       cairo_path_data_t data = new cairo_path_data_t();
/* 477 */       while (i < path.num_data) {
/* 478 */         long offset = path.data + i * cairo_path_data_t.sizeof;
/* 479 */         Cairo.memmove(data, offset, cairo_path_data_t.sizeof);
/* 480 */         switch (data.type) {
/*     */         case 0: 
/* 482 */           Cairo.memmove(points, offset + cairo_path_data_t.sizeof, cairo_path_data_t.sizeof);
/* 483 */           minX = Math.min(minX, points[0]);
/* 484 */           minY = Math.min(minY, points[1]);
/* 485 */           maxX = Math.max(maxX, points[0]);
/* 486 */           maxY = Math.max(maxY, points[1]);
/* 487 */           break;
/*     */         case 1: 
/* 489 */           Cairo.memmove(points, offset + cairo_path_data_t.sizeof, cairo_path_data_t.sizeof);
/* 490 */           minX = Math.min(minX, points[0]);
/* 491 */           minY = Math.min(minY, points[1]);
/* 492 */           maxX = Math.max(maxX, points[0]);
/* 493 */           maxY = Math.max(maxY, points[1]);
/* 494 */           break;
/*     */         case 2: 
/* 496 */           Cairo.memmove(points, offset + cairo_path_data_t.sizeof, cairo_path_data_t.sizeof * 3);
/* 497 */           minX = Math.min(minX, points[0]);
/* 498 */           minY = Math.min(minY, points[1]);
/* 499 */           maxX = Math.max(maxX, points[0]);
/* 500 */           maxY = Math.max(maxY, points[1]);
/* 501 */           minX = Math.min(minX, points[2]);
/* 502 */           minY = Math.min(minY, points[3]);
/* 503 */           maxX = Math.max(maxX, points[2]);
/* 504 */           maxY = Math.max(maxY, points[3]);
/* 505 */           minX = Math.min(minX, points[4]);
/* 506 */           minY = Math.min(minY, points[5]);
/* 507 */           maxX = Math.max(maxX, points[4]);
/* 508 */           maxY = Math.max(maxY, points[5]);
/* 509 */           break;
/*     */         }
/*     */         
/* 512 */         i += data.length;
/*     */       }
/*     */     }
/* 515 */     bounds[0] = ((float)minX);
/* 516 */     bounds[1] = ((float)minY);
/* 517 */     bounds[2] = ((float)(maxX - minX));
/* 518 */     bounds[3] = ((float)(maxY - minY));
/* 519 */     Cairo.cairo_path_destroy(copy);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void getCurrentPoint(float[] point)
/*     */   {
/* 537 */     if (isDisposed()) SWT.error(44);
/* 538 */     getCurrentPointInPixels(point);
/* 539 */     for (int i = 0; i < point.length; i++) {
/* 540 */       point[i] = DPIUtil.autoScaleDown(point[i]);
/*     */     }
/*     */   }
/*     */   
/*     */   void getCurrentPointInPixels(float[] point) {
/* 545 */     if (point == null) SWT.error(4);
/* 546 */     if (point.length < 2) SWT.error(5);
/* 547 */     double[] x = new double[1];double[] y = new double[1];
/* 548 */     Cairo.cairo_get_current_point(this.handle, x, y);
/* 549 */     point[0] = ((float)x[0]);
/* 550 */     point[1] = ((float)y[0]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PathData getPathData()
/*     */   {
/* 565 */     if (isDisposed()) SWT.error(44);
/* 566 */     PathData result = getPathDataInPixels();
/* 567 */     result.points = DPIUtil.autoScaleDown(result.points);
/* 568 */     return result;
/*     */   }
/*     */   
/*     */   PathData getPathDataInPixels() {
/* 572 */     long copy = Cairo.cairo_copy_path(this.handle);
/* 573 */     if (copy == 0L) SWT.error(2);
/* 574 */     cairo_path_t path = new cairo_path_t();
/* 575 */     Cairo.memmove(path, copy, cairo_path_t.sizeof);
/* 576 */     byte[] types = new byte[path.num_data];
/* 577 */     float[] pts = new float[path.num_data * 6];
/* 578 */     int typeIndex = 0;int ptsIndex = 0;
/* 579 */     if (path.num_data > 0) {
/* 580 */       int i = 0;
/* 581 */       double[] points = new double[6];
/* 582 */       cairo_path_data_t data = new cairo_path_data_t();
/* 583 */       while (i < path.num_data) {
/* 584 */         long offset = path.data + i * cairo_path_data_t.sizeof;
/* 585 */         Cairo.memmove(data, offset, cairo_path_data_t.sizeof);
/* 586 */         switch (data.type) {
/*     */         case 0: 
/* 588 */           types[(typeIndex++)] = 1;
/* 589 */           Cairo.memmove(points, offset + cairo_path_data_t.sizeof, cairo_path_data_t.sizeof);
/* 590 */           pts[(ptsIndex++)] = ((float)points[0]);
/* 591 */           pts[(ptsIndex++)] = ((float)points[1]);
/* 592 */           break;
/*     */         case 1: 
/* 594 */           types[(typeIndex++)] = 2;
/* 595 */           Cairo.memmove(points, offset + cairo_path_data_t.sizeof, cairo_path_data_t.sizeof);
/* 596 */           pts[(ptsIndex++)] = ((float)points[0]);
/* 597 */           pts[(ptsIndex++)] = ((float)points[1]);
/* 598 */           break;
/*     */         case 2: 
/* 600 */           types[(typeIndex++)] = 4;
/* 601 */           Cairo.memmove(points, offset + cairo_path_data_t.sizeof, cairo_path_data_t.sizeof * 3);
/* 602 */           pts[(ptsIndex++)] = ((float)points[0]);
/* 603 */           pts[(ptsIndex++)] = ((float)points[1]);
/* 604 */           pts[(ptsIndex++)] = ((float)points[2]);
/* 605 */           pts[(ptsIndex++)] = ((float)points[3]);
/* 606 */           pts[(ptsIndex++)] = ((float)points[4]);
/* 607 */           pts[(ptsIndex++)] = ((float)points[5]);
/* 608 */           break;
/*     */         case 3: 
/* 610 */           types[(typeIndex++)] = 5;
/*     */         }
/*     */         
/* 613 */         i += data.length;
/*     */       }
/*     */     }
/* 616 */     if (typeIndex != types.length) {
/* 617 */       byte[] newTypes = new byte[typeIndex];
/* 618 */       System.arraycopy(types, 0, newTypes, 0, typeIndex);
/* 619 */       types = newTypes;
/*     */     }
/* 621 */     if (ptsIndex != pts.length) {
/* 622 */       float[] newPts = new float[ptsIndex];
/* 623 */       System.arraycopy(pts, 0, newPts, 0, ptsIndex);
/* 624 */       pts = newPts;
/*     */     }
/* 626 */     Cairo.cairo_path_destroy(copy);
/* 627 */     PathData result = new PathData();
/* 628 */     result.types = types;
/* 629 */     result.points = pts;
/* 630 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void lineTo(float x, float y)
/*     */   {
/* 645 */     if (isDisposed()) SWT.error(44);
/* 646 */     x = DPIUtil.autoScaleUp(x);
/* 647 */     y = DPIUtil.autoScaleUp(y);
/* 648 */     lineToInPixels(x, y);
/*     */   }
/*     */   
/* 651 */   void lineToInPixels(float x, float y) { if (!this.moved) {
/* 652 */       double[] currentX = new double[1];double[] currentY = new double[1];
/* 653 */       Cairo.cairo_get_current_point(this.handle, currentX, currentY);
/* 654 */       Cairo.cairo_move_to(this.handle, currentX[0], currentY[0]);
/* 655 */       this.moved = true;
/*     */     }
/* 657 */     Cairo.cairo_line_to(this.handle, x, y);
/* 658 */     this.closed = false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void moveTo(float x, float y)
/*     */   {
/* 674 */     if (isDisposed()) SWT.error(44);
/* 675 */     x = DPIUtil.autoScaleUp(x);
/* 676 */     y = DPIUtil.autoScaleUp(y);
/* 677 */     moveToInPixels(x, y);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void moveToInPixels(float x, float y)
/*     */   {
/* 687 */     this.moved = true;
/* 688 */     Cairo.cairo_move_to(this.handle, x, y);
/* 689 */     this.closed = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void quadTo(float cx, float cy, float x, float y)
/*     */   {
/* 705 */     if (isDisposed()) SWT.error(44);
/* 706 */     x = DPIUtil.autoScaleUp(x);
/* 707 */     y = DPIUtil.autoScaleUp(y);
/* 708 */     cx = DPIUtil.autoScaleUp(cx);
/* 709 */     cy = DPIUtil.autoScaleUp(cy);
/* 710 */     quadToInPixels(cx, cy, x, y);
/*     */   }
/*     */   
/* 713 */   void quadToInPixels(float cx, float cy, float x, float y) { double[] currentX = new double[1];double[] currentY = new double[1];
/* 714 */     Cairo.cairo_get_current_point(this.handle, currentX, currentY);
/* 715 */     if (!this.moved) {
/* 716 */       Cairo.cairo_move_to(this.handle, currentX[0], currentY[0]);
/* 717 */       this.moved = true;
/*     */     }
/* 719 */     float x0 = (float)currentX[0];
/* 720 */     float y0 = (float)currentY[0];
/* 721 */     float cx1 = x0 + 2.0F * (cx - x0) / 3.0F;
/* 722 */     float cy1 = y0 + 2.0F * (cy - y0) / 3.0F;
/* 723 */     float cx2 = cx1 + (x - x0) / 3.0F;
/* 724 */     float cy2 = cy1 + (y - y0) / 3.0F;
/* 725 */     Cairo.cairo_curve_to(this.handle, cx1, cy1, cx2, cy2, x, y);
/* 726 */     this.closed = false;
/*     */   }
/*     */   
/*     */   void destroy()
/*     */   {
/* 731 */     Cairo.cairo_destroy(this.handle);
/* 732 */     this.handle = 0L;
/*     */   }
/*     */   
/*     */   void init(PathData data) {
/* 736 */     byte[] types = data.types;
/* 737 */     float[] points = data.points;
/* 738 */     int i = 0; for (int j = 0; i < types.length; i++) {
/* 739 */       switch (types[i]) {
/*     */       case 1: 
/* 741 */         moveTo(points[(j++)], points[(j++)]);
/* 742 */         break;
/*     */       case 2: 
/* 744 */         lineTo(points[(j++)], points[(j++)]);
/* 745 */         break;
/*     */       case 4: 
/* 747 */         cubicTo(points[(j++)], points[(j++)], points[(j++)], points[(j++)], points[(j++)], points[(j++)]);
/* 748 */         break;
/*     */       case 3: 
/* 750 */         quadTo(points[(j++)], points[(j++)], points[(j++)], points[(j++)]);
/* 751 */         break;
/*     */       case 5: 
/* 753 */         close();
/* 754 */         break;
/*     */       default: 
/* 756 */         dispose();
/* 757 */         SWT.error(5);
/*     */       }
/*     */       
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isDisposed()
/*     */   {
/* 774 */     return this.handle == 0L;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 785 */     if (isDisposed()) return "Path {*DISPOSED*}";
/* 786 */     return "Path {" + this.handle + "}";
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/graphics/Path.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */