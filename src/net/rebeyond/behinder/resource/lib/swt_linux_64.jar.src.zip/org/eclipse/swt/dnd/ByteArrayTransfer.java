/*     */ package org.eclipse.swt.dnd;
/*     */ 
/*     */ import org.eclipse.swt.internal.C;
/*     */ import org.eclipse.swt.internal.gtk.OS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ByteArrayTransfer
/*     */   extends Transfer
/*     */ {
/*     */   public TransferData[] getSupportedTypes()
/*     */   {
/* 125 */     int[] types = getTypeIds();
/* 126 */     TransferData[] data = new TransferData[types.length];
/* 127 */     for (int i = 0; i < types.length; i++) {
/* 128 */       data[i] = new TransferData();
/* 129 */       data[i].type = types[i];
/*     */     }
/* 131 */     return data;
/*     */   }
/*     */   
/*     */   public boolean isSupportedType(TransferData transferData)
/*     */   {
/* 136 */     if (transferData == null) return false;
/* 137 */     int[] types = getTypeIds();
/* 138 */     for (int i = 0; i < types.length; i++) {
/* 139 */       if (transferData.type == types[i]) return true;
/*     */     }
/* 141 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void javaToNative(Object object, TransferData transferData)
/*     */   {
/* 156 */     transferData.result = 0;
/* 157 */     if ((!checkByteArray(object)) || (!isSupportedType(transferData))) {
/* 158 */       DND.error(2003);
/*     */     }
/* 160 */     byte[] buffer = (byte[])object;
/* 161 */     if (buffer.length == 0) return;
/* 162 */     long pValue = OS.g_malloc(buffer.length);
/* 163 */     if (pValue == 0L) return;
/* 164 */     C.memmove(pValue, buffer, buffer.length);
/* 165 */     transferData.length = buffer.length;
/* 166 */     transferData.format = 8;
/* 167 */     transferData.pValue = pValue;
/* 168 */     transferData.result = 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Object nativeToJava(TransferData transferData)
/*     */   {
/* 183 */     if ((!isSupportedType(transferData)) || (transferData.pValue == 0L)) return null;
/* 184 */     int size = transferData.format * transferData.length / 8;
/* 185 */     if (size == 0) return null;
/* 186 */     byte[] buffer = new byte[size];
/* 187 */     C.memmove(buffer, transferData.pValue, size);
/* 188 */     return buffer;
/*     */   }
/*     */   
/*     */   boolean checkByteArray(Object object) {
/* 192 */     return (object != null) && ((object instanceof byte[])) && (((byte[])object).length > 0);
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/dnd/ByteArrayTransfer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */