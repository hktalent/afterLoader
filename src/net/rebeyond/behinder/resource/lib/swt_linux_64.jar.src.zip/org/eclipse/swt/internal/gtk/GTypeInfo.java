/*    */ package org.eclipse.swt.internal.gtk;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GTypeInfo
/*    */ {
/*    */   public short class_size;
/*    */   
/*    */ 
/*    */ 
/*    */   public long base_init;
/*    */   
/*    */ 
/*    */   public long base_finalize;
/*    */   
/*    */ 
/*    */   public long class_init;
/*    */   
/*    */ 
/*    */   public long class_finalize;
/*    */   
/*    */ 
/*    */   public long class_data;
/*    */   
/*    */ 
/*    */   public short instance_size;
/*    */   
/*    */ 
/*    */   public short n_preallocs;
/*    */   
/*    */ 
/*    */   public long instance_init;
/*    */   
/*    */ 
/*    */   public long value_table;
/*    */   
/*    */ 
/* 39 */   public static final int sizeof = ;
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/internal/gtk/GTypeInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */