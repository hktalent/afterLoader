/*     */ package org.eclipse.swt.widgets;
/*     */ 
/*     */ import org.eclipse.swt.SWT;
/*     */ import org.eclipse.swt.accessibility.Accessible;
/*     */ import org.eclipse.swt.accessibility.AccessibleAdapter;
/*     */ import org.eclipse.swt.accessibility.AccessibleControlAdapter;
/*     */ import org.eclipse.swt.accessibility.AccessibleControlEvent;
/*     */ import org.eclipse.swt.accessibility.AccessibleEvent;
/*     */ import org.eclipse.swt.events.SelectionListener;
/*     */ import org.eclipse.swt.graphics.Color;
/*     */ import org.eclipse.swt.graphics.Font;
/*     */ import org.eclipse.swt.graphics.GC;
/*     */ import org.eclipse.swt.graphics.Point;
/*     */ import org.eclipse.swt.graphics.RGB;
/*     */ import org.eclipse.swt.graphics.Rectangle;
/*     */ import org.eclipse.swt.graphics.TextLayout;
/*     */ import org.eclipse.swt.graphics.TextStyle;
/*     */ import org.eclipse.swt.internal.DPIUtil;
/*     */ import org.eclipse.swt.internal.gtk.GTK;
/*     */ import org.eclipse.swt.internal.gtk.GdkEvent;
/*     */ import org.eclipse.swt.internal.gtk.GdkEventButton;
/*     */ import org.eclipse.swt.internal.gtk.GdkEventKey;
/*     */ import org.eclipse.swt.internal.gtk.GdkEventMotion;
/*     */ import org.eclipse.swt.internal.gtk.GtkAllocation;
/*     */ import org.eclipse.swt.internal.gtk.OS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Link
/*     */   extends Control
/*     */ {
/*     */   String text;
/*     */   TextLayout layout;
/*     */   Color linkColor;
/*     */   Color disabledColor;
/*     */   Point[] offsets;
/*     */   Point selection;
/*     */   String[] ids;
/*     */   int[] mnemonics;
/*     */   int focusIndex;
/*  53 */   static final RGB LINK_DISABLED_FOREGROUND = new RGB(172, 168, 153);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Link(Composite parent, int style)
/*     */   {
/*  83 */     super(parent, style);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addSelectionListener(SelectionListener listener)
/*     */   {
/* 111 */     checkWidget();
/* 112 */     if (listener == null) error(4);
/* 113 */     TypedListener typedListener = new TypedListener(listener);
/* 114 */     addListener(13, typedListener);
/* 115 */     addListener(14, typedListener);
/*     */   }
/*     */   
/*     */   Point computeSizeInPixels(int wHint, int hHint, boolean changed)
/*     */   {
/* 120 */     checkWidget();
/* 121 */     if ((wHint != -1) && (wHint < 0)) wHint = 0;
/* 122 */     if ((hHint != -1) && (hHint < 0)) { hHint = 0;
/*     */     }
/* 124 */     int layoutWidth = this.layout.getWidth();
/*     */     int height;
/* 126 */     int width; int height; if (wHint == 0) {
/* 127 */       this.layout.setWidth(1);
/* 128 */       Rectangle rect = DPIUtil.autoScaleUp(this.layout.getBounds());
/* 129 */       int width = 0;
/* 130 */       height = rect.height;
/*     */     } else {
/* 132 */       this.layout.setWidth(DPIUtil.autoScaleDown(wHint));
/* 133 */       Rectangle rect = DPIUtil.autoScaleUp(this.layout.getBounds());
/* 134 */       width = rect.width;
/* 135 */       height = rect.height;
/*     */     }
/* 137 */     this.layout.setWidth(layoutWidth);
/* 138 */     if (wHint != -1) width = wHint;
/* 139 */     if (hHint != -1) height = hHint;
/* 140 */     int border = getBorderWidthInPixels();
/* 141 */     width += border * 2;
/* 142 */     height += border * 2;
/* 143 */     return new Point(width, height);
/*     */   }
/*     */   
/*     */   void createHandle(int index)
/*     */   {
/* 148 */     this.state |= 0x10008;
/* 149 */     this.handle = OS.g_object_new(this.display.gtk_fixed_get_type(), 0L);
/* 150 */     if (this.handle == 0L) error(2);
/* 151 */     GTK.gtk_widget_set_has_window(this.handle, true);
/* 152 */     GTK.gtk_widget_set_can_focus(this.handle, true);
/* 153 */     this.layout = new TextLayout(this.display);
/* 154 */     this.disabledColor = new Color(this.display, LINK_DISABLED_FOREGROUND);
/* 155 */     this.offsets = new Point[0];
/* 156 */     this.ids = new String[0];
/* 157 */     this.mnemonics = new int[0];
/* 158 */     this.selection = new Point(-1, -1);
/* 159 */     this.focusIndex = -1;
/*     */   }
/*     */   
/*     */   void createWidget(int index)
/*     */   {
/* 164 */     super.createWidget(index);
/* 165 */     this.layout.setFont(getFont());
/* 166 */     this.text = "";
/* 167 */     initAccessible();
/*     */   }
/*     */   
/*     */   void drawWidget(GC gc)
/*     */   {
/* 172 */     int selStart = this.selection.x;
/* 173 */     int selEnd = this.selection.y;
/* 174 */     if (selStart > selEnd) {
/* 175 */       selStart = this.selection.y;
/* 176 */       selEnd = this.selection.x;
/*     */     }
/*     */     
/* 179 */     selStart = selEnd = -1;
/* 180 */     if ((this.state & 0x10) != 0) gc.setForeground(this.disabledColor);
/* 181 */     this.layout.draw(gc, 0, 0, selStart, selEnd, null, null);
/* 182 */     if ((hasFocus()) && (this.focusIndex != -1)) {
/* 183 */       Rectangle[] rects = getRectanglesInPixels(this.focusIndex);
/* 184 */       for (int i = 0; i < rects.length; i++) {
/* 185 */         Rectangle rect = DPIUtil.autoScaleDown(rects[i]);
/* 186 */         gc.drawFocus(rect.x, rect.y, rect.width, rect.height);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   void enableWidget(boolean enabled)
/*     */   {
/* 193 */     super.enableWidget(enabled);
/* 194 */     if (isDisposed()) return;
/* 195 */     styleLinkParts();
/* 196 */     redraw();
/*     */   }
/*     */   
/*     */   void fixStyle()
/*     */   {
/* 201 */     fixStyle(this.handle);
/*     */   }
/*     */   
/*     */   void initAccessible() {
/* 205 */     Accessible accessible = getAccessible();
/* 206 */     accessible.addAccessibleListener(new AccessibleAdapter()
/*     */     {
/*     */       public void getName(AccessibleEvent e) {
/* 209 */         e.result = Link.this.parse(Link.this.text);
/*     */       }
/*     */       
/* 212 */     });
/* 213 */     accessible.addAccessibleControlListener(new AccessibleControlAdapter()
/*     */     {
/*     */       public void getChildAtPoint(AccessibleControlEvent e) {
/* 216 */         e.childID = -1;
/*     */       }
/*     */       
/*     */       public void getLocation(AccessibleControlEvent e)
/*     */       {
/* 221 */         Rectangle rect = Link.this.display.map(Link.this.getParent(), null, Link.this.getBounds());
/* 222 */         e.x = rect.x;
/* 223 */         e.y = rect.y;
/* 224 */         e.width = rect.width;
/* 225 */         e.height = rect.height;
/*     */       }
/*     */       
/*     */       public void getChildCount(AccessibleControlEvent e)
/*     */       {
/* 230 */         e.detail = 0;
/*     */       }
/*     */       
/*     */       public void getRole(AccessibleControlEvent e)
/*     */       {
/* 235 */         e.detail = 30;
/*     */       }
/*     */       
/*     */       public void getState(AccessibleControlEvent e)
/*     */       {
/* 240 */         e.detail = 1048576;
/* 241 */         if (Link.this.hasFocus()) e.detail |= 0x4;
/*     */       }
/*     */       
/*     */       public void getDefaultAction(AccessibleControlEvent e)
/*     */       {
/* 246 */         e.result = SWT.getMessage("SWT_Press");
/*     */       }
/*     */       
/*     */       public void getSelection(AccessibleControlEvent e)
/*     */       {
/* 251 */         if (Link.this.hasFocus()) e.childID = -1;
/*     */       }
/*     */       
/*     */       public void getFocus(AccessibleControlEvent e)
/*     */       {
/* 256 */         if (Link.this.hasFocus()) { e.childID = -1;
/*     */         }
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Color getLinkForeground()
/*     */   {
/* 273 */     checkWidget();
/* 274 */     return this.linkColor != null ? this.linkColor : this.display.getSystemColor(36);
/*     */   }
/*     */   
/*     */   String getNameText()
/*     */   {
/* 279 */     return getText();
/*     */   }
/*     */   
/*     */   Rectangle[] getRectanglesInPixels(int linkIndex) {
/* 283 */     int lineCount = this.layout.getLineCount();
/* 284 */     Rectangle[] rects = new Rectangle[lineCount];
/* 285 */     int[] lineOffsets = this.layout.getLineOffsets();
/* 286 */     Point point = this.offsets[linkIndex];
/* 287 */     int lineStart = 1;
/* 288 */     while (point.x > lineOffsets[lineStart]) lineStart++;
/* 289 */     int lineEnd = 1;
/* 290 */     while (point.y > lineOffsets[lineEnd]) lineEnd++;
/* 291 */     int index = 0;
/* 292 */     if (lineStart == lineEnd) {
/* 293 */       rects[(index++)] = DPIUtil.autoScaleUp(this.layout.getBounds(point.x, point.y));
/*     */     } else {
/* 295 */       rects[(index++)] = DPIUtil.autoScaleUp(this.layout.getBounds(point.x, lineOffsets[lineStart] - 1));
/* 296 */       rects[(index++)] = DPIUtil.autoScaleUp(this.layout.getBounds(lineOffsets[(lineEnd - 1)], point.y));
/* 297 */       if (lineEnd - lineStart > 1) {
/* 298 */         for (int i = lineStart; i < lineEnd - 1; i++) {
/* 299 */           rects[(index++)] = DPIUtil.autoScaleUp(this.layout.getLineBounds(i));
/*     */         }
/*     */       }
/*     */     }
/* 303 */     if (rects.length != index) {
/* 304 */       Rectangle[] tmp = new Rectangle[index];
/* 305 */       System.arraycopy(rects, 0, tmp, 0, index);
/* 306 */       rects = tmp;
/*     */     }
/* 308 */     return rects;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getText()
/*     */   {
/* 323 */     checkWidget();
/* 324 */     return this.text;
/*     */   }
/*     */   
/*     */   long gtk_button_press_event(long widget, long event)
/*     */   {
/* 329 */     long result = super.gtk_button_press_event(widget, event);
/* 330 */     if (result != 0L) return result;
/* 331 */     GdkEventButton gdkEvent = new GdkEventButton();
/* 332 */     OS.memmove(gdkEvent, event, GdkEventButton.sizeof);
/* 333 */     if ((gdkEvent.button == 1) && (gdkEvent.type == 4)) {
/* 334 */       if (this.focusIndex != -1) setFocus();
/* 335 */       int x = (int)gdkEvent.x;
/* 336 */       int y = (int)gdkEvent.y;
/* 337 */       if ((this.style & 0x8000000) != 0) x = getClientWidth() - x;
/* 338 */       int offset = DPIUtil.autoScaleUp(this.layout.getOffset(x, y, null));
/* 339 */       int oldSelectionX = this.selection.x;
/* 340 */       int oldSelectionY = this.selection.y;
/* 341 */       this.selection.x = offset;
/* 342 */       this.selection.y = -1;
/* 343 */       if ((oldSelectionX != -1) && (oldSelectionY != -1)) {
/* 344 */         if (oldSelectionX > oldSelectionY) {
/* 345 */           int temp = oldSelectionX;
/* 346 */           oldSelectionX = oldSelectionY;
/* 347 */           oldSelectionY = temp;
/*     */         }
/* 349 */         Rectangle rect = DPIUtil.autoScaleUp(this.layout.getBounds(oldSelectionX, oldSelectionY));
/* 350 */         redrawInPixels(rect.x, rect.y, rect.width, rect.height, false);
/*     */       }
/* 352 */       for (int j = 0; j < this.offsets.length; j++) {
/* 353 */         Rectangle[] rects = getRectanglesInPixels(j);
/* 354 */         for (int i = 0; i < rects.length; i++) {
/* 355 */           Rectangle rect = rects[i];
/* 356 */           if (rect.contains(x, y)) {
/* 357 */             this.focusIndex = j;
/* 358 */             redraw();
/* 359 */             return result;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 364 */     return result;
/*     */   }
/*     */   
/*     */   long gtk_button_release_event(long widget, long event)
/*     */   {
/* 369 */     long result = super.gtk_button_release_event(widget, event);
/* 370 */     if (result != 0L) return result;
/* 371 */     if (this.focusIndex == -1) return result;
/* 372 */     GdkEventButton gdkEvent = new GdkEventButton();
/* 373 */     OS.memmove(gdkEvent, event, GdkEventButton.sizeof);
/* 374 */     if (gdkEvent.button == 1) {
/* 375 */       int x = (int)gdkEvent.x;
/* 376 */       int y = (int)gdkEvent.y;
/* 377 */       if ((this.style & 0x8000000) != 0) x = getClientWidth() - x;
/* 378 */       Rectangle[] rects = getRectanglesInPixels(this.focusIndex);
/* 379 */       for (int i = 0; i < rects.length; i++) {
/* 380 */         Rectangle rect = rects[i];
/* 381 */         if (rect.contains(x, y)) {
/* 382 */           Event ev = new Event();
/* 383 */           ev.text = this.ids[this.focusIndex];
/* 384 */           sendSelectionEvent(13, ev, true);
/* 385 */           return result;
/*     */         }
/*     */       }
/*     */     }
/* 389 */     return result;
/*     */   }
/*     */   
/*     */   long gtk_draw(long widget, long cairo)
/*     */   {
/* 394 */     if (GTK.GTK_VERSION >= OS.VERSION(3, 14, 0)) {
/* 395 */       long context = GTK.gtk_widget_get_style_context(widget);
/* 396 */       GtkAllocation allocation = new GtkAllocation();
/* 397 */       GTK.gtk_widget_get_allocation(widget, allocation);
/* 398 */       int width = (this.state & 0x200) != 0 ? 0 : allocation.width;
/* 399 */       int height = (this.state & 0x400) != 0 ? 0 : allocation.height;
/*     */       
/*     */ 
/* 402 */       GTK.gtk_render_background(context, cairo, 0.0D, 0.0D, width, height);
/*     */     }
/* 404 */     return super.gtk_draw(widget, cairo);
/*     */   }
/*     */   
/*     */   long gtk_event_after(long widget, long gdkEvent)
/*     */   {
/* 409 */     long result = super.gtk_event_after(widget, gdkEvent);
/* 410 */     GdkEvent event = new GdkEvent();
/* 411 */     OS.memmove(event, gdkEvent, GdkEvent.sizeof);
/* 412 */     switch (event.type) {
/*     */     case 12: 
/* 414 */       redraw();
/*     */     }
/*     */     
/* 417 */     return result;
/*     */   }
/*     */   
/*     */   long gtk_key_press_event(long widget, long eventPtr)
/*     */   {
/* 422 */     long result = super.gtk_key_press_event(widget, eventPtr);
/* 423 */     if (result != 0L) return result;
/* 424 */     if (this.focusIndex == -1) return result;
/* 425 */     GdkEventKey gdkEvent = new GdkEventKey();
/* 426 */     OS.memmove(gdkEvent, eventPtr, GdkEventKey.sizeof);
/* 427 */     switch (gdkEvent.keyval) {
/*     */     case 32: 
/*     */     case 65293: 
/*     */     case 65421: 
/* 431 */       Event event = new Event();
/* 432 */       event.text = this.ids[this.focusIndex];
/* 433 */       sendSelectionEvent(13, event, true);
/* 434 */       break;
/*     */     case 65289: 
/* 436 */       if (this.focusIndex < this.offsets.length - 1) {
/* 437 */         this.focusIndex += 1;
/* 438 */         redraw();
/*     */       }
/*     */       break;
/*     */     case 65056: 
/* 442 */       if (this.focusIndex > 0) {
/* 443 */         this.focusIndex -= 1;
/* 444 */         redraw();
/*     */       }
/*     */       break;
/*     */     }
/* 448 */     return result;
/*     */   }
/*     */   
/*     */   long gtk_motion_notify_event(long widget, long event)
/*     */   {
/* 453 */     long result = super.gtk_motion_notify_event(widget, event);
/* 454 */     if (result != 0L) return result;
/* 455 */     GdkEventMotion gdkEvent = new GdkEventMotion();
/* 456 */     OS.memmove(gdkEvent, event, GdkEventMotion.sizeof);
/* 457 */     int x = (int)gdkEvent.x;
/* 458 */     int y = (int)gdkEvent.y;
/* 459 */     if ((this.style & 0x8000000) != 0) x = getClientWidth() - x;
/* 460 */     if ((gdkEvent.state & 0x100) != 0) {
/* 461 */       int oldSelection = this.selection.y;
/* 462 */       this.selection.y = DPIUtil.autoScaleUp(this.layout.getOffset(x, y, null));
/* 463 */       if (this.selection.y != oldSelection) {
/* 464 */         int newSelection = this.selection.y;
/* 465 */         if (oldSelection > newSelection) {
/* 466 */           int temp = oldSelection;
/* 467 */           oldSelection = newSelection;
/* 468 */           newSelection = temp;
/*     */         }
/* 470 */         Rectangle rect = this.layout.getBounds(oldSelection, newSelection);
/* 471 */         redrawInPixels(rect.x, rect.y, rect.width, rect.height, false);
/*     */       }
/*     */     } else {
/* 474 */       for (int j = 0; j < this.offsets.length; j++) {
/* 475 */         Rectangle[] rects = getRectanglesInPixels(j);
/* 476 */         for (int i = 0; i < rects.length; i++) {
/* 477 */           Rectangle rect = rects[i];
/* 478 */           if (rect.contains(x, y)) {
/* 479 */             setCursor(this.display.getSystemCursor(21));
/* 480 */             return result;
/*     */           }
/*     */         }
/*     */       }
/* 484 */       setCursor(null);
/*     */     }
/* 486 */     return result;
/*     */   }
/*     */   
/*     */   boolean hooksPaint()
/*     */   {
/* 491 */     return true;
/*     */   }
/*     */   
/*     */   boolean mnemonicHit(char key)
/*     */   {
/* 496 */     char uckey = Character.toUpperCase(key);
/* 497 */     String parsedText = this.layout.getText();
/* 498 */     for (int i = 0; i < this.mnemonics.length - 1; i++) {
/* 499 */       if (this.mnemonics[i] != -1) {
/* 500 */         char mnemonic = parsedText.charAt(this.mnemonics[i]);
/* 501 */         if (uckey == Character.toUpperCase(mnemonic)) {
/* 502 */           if (!setFocus()) return false;
/* 503 */           this.focusIndex = i;
/* 504 */           redraw();
/* 505 */           return true;
/*     */         }
/*     */       }
/*     */     }
/* 509 */     return false;
/*     */   }
/*     */   
/*     */   boolean mnemonicMatch(char key)
/*     */   {
/* 514 */     char uckey = Character.toUpperCase(key);
/* 515 */     String parsedText = this.layout.getText();
/* 516 */     for (int i = 0; i < this.mnemonics.length - 1; i++) {
/* 517 */       if (this.mnemonics[i] != -1) {
/* 518 */         char mnemonic = parsedText.charAt(this.mnemonics[i]);
/* 519 */         if (uckey == Character.toUpperCase(mnemonic)) {
/* 520 */           return true;
/*     */         }
/*     */       }
/*     */     }
/* 524 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   void releaseWidget()
/*     */   {
/* 530 */     super.releaseWidget();
/* 531 */     if (this.layout != null) this.layout.dispose();
/* 532 */     this.layout = null;
/* 533 */     this.linkColor = null;
/* 534 */     if (this.disabledColor != null) this.disabledColor.dispose();
/* 535 */     this.disabledColor = null;
/* 536 */     this.offsets = null;
/* 537 */     this.ids = null;
/* 538 */     this.mnemonics = null;
/* 539 */     this.text = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeSelectionListener(SelectionListener listener)
/*     */   {
/* 560 */     checkWidget();
/* 561 */     if (listener == null) error(4);
/* 562 */     if (this.eventTable == null) return;
/* 563 */     this.eventTable.unhook(13, listener);
/* 564 */     this.eventTable.unhook(14, listener);
/*     */   }
/*     */   
/*     */   String parse(String string) {
/* 568 */     int length = string.length();
/* 569 */     this.offsets = new Point[length / 4];
/* 570 */     this.ids = new String[length / 4];
/* 571 */     this.mnemonics = new int[length / 4 + 1];
/* 572 */     StringBuilder result = new StringBuilder();
/* 573 */     char[] buffer = new char[length];
/* 574 */     string.getChars(0, string.length(), buffer, 0);
/* 575 */     int index = 0;int state = 0;int linkIndex = 0;
/* 576 */     int start = 0;int tagStart = 0;int linkStart = 0;int endtagStart = 0;int refStart = 0;
/* 577 */     while (index < length) {
/* 578 */       char c = Character.toLowerCase(buffer[index]);
/* 579 */       switch (state) {
/*     */       case 0: 
/* 581 */         if (c == '<') {
/* 582 */           tagStart = index;
/* 583 */           state++;
/*     */         }
/*     */         break;
/*     */       case 1: 
/* 587 */         if (c == 'a') state++;
/*     */         break;
/*     */       case 2: 
/* 590 */         switch (c) {
/*     */         case 'h': 
/* 592 */           state = 7;
/* 593 */           break;
/*     */         case '>': 
/* 595 */           linkStart = index + 1;
/* 596 */           state++;
/* 597 */           break;
/*     */         default: 
/* 599 */           if (!Character.isWhitespace(c))
/* 600 */             state = 13;
/*     */           break; }
/* 602 */         break;
/*     */       case 3: 
/* 604 */         if (c == '<') {
/* 605 */           endtagStart = index;
/* 606 */           state++;
/*     */         }
/*     */         break;
/*     */       case 4: 
/* 610 */         state = c == '/' ? state + 1 : 3;
/* 611 */         break;
/*     */       case 5: 
/* 613 */         state = c == 'a' ? state + 1 : 3;
/* 614 */         break;
/*     */       case 6: 
/* 616 */         if (c == '>') {
/* 617 */           this.mnemonics[linkIndex] = parseMnemonics(buffer, start, tagStart, result);
/* 618 */           int offset = result.length();
/* 619 */           parseMnemonics(buffer, linkStart, endtagStart, result);
/* 620 */           this.offsets[linkIndex] = new Point(offset, result.length() - 1);
/* 621 */           if (this.ids[linkIndex] == null) {
/* 622 */             this.ids[linkIndex] = new String(buffer, linkStart, endtagStart - linkStart);
/*     */           }
/* 624 */           linkIndex++;
/* 625 */           start = tagStart = linkStart = endtagStart = refStart = index + 1;
/* 626 */           state = 0;
/*     */         } else {
/* 628 */           state = 3;
/*     */         }
/* 630 */         break;
/*     */       case 7: 
/* 632 */         state = c == 'r' ? state + 1 : 0;
/* 633 */         break;
/*     */       case 8: 
/* 635 */         state = c == 'e' ? state + 1 : 0;
/* 636 */         break;
/*     */       case 9: 
/* 638 */         state = c == 'f' ? state + 1 : 0;
/* 639 */         break;
/*     */       case 10: 
/* 641 */         state = c == '=' ? state + 1 : 0;
/* 642 */         break;
/*     */       case 11: 
/* 644 */         if (c == '"') {
/* 645 */           state++;
/* 646 */           refStart = index + 1;
/*     */         } else {
/* 648 */           state = 0;
/*     */         }
/* 650 */         break;
/*     */       case 12: 
/* 652 */         if (c == '"') {
/* 653 */           this.ids[linkIndex] = new String(buffer, refStart, index - refStart);
/* 654 */           state = 2;
/*     */         }
/*     */         break;
/*     */       case 13: 
/* 658 */         if (Character.isWhitespace(c)) {
/* 659 */           state = 0;
/* 660 */         } else if (c == '=') {
/* 661 */           state++;
/*     */         }
/*     */         break;
/*     */       case 14: 
/* 665 */         state = c == '"' ? state + 1 : 0;
/* 666 */         break;
/*     */       case 15: 
/* 668 */         if (c == '"') state = 2;
/*     */         break;
/*     */       default: 
/* 671 */         state = 0;
/*     */       }
/*     */       
/* 674 */       index++;
/*     */     }
/* 676 */     if (start < length) {
/* 677 */       int tmp = parseMnemonics(buffer, start, tagStart, result);
/* 678 */       int mnemonic = parseMnemonics(buffer, Math.max(tagStart, linkStart), length, result);
/* 679 */       if (mnemonic == -1) mnemonic = tmp;
/* 680 */       this.mnemonics[linkIndex] = mnemonic;
/*     */     } else {
/* 682 */       this.mnemonics[linkIndex] = -1;
/*     */     }
/* 684 */     if (this.offsets.length != linkIndex) {
/* 685 */       Point[] newOffsets = new Point[linkIndex];
/* 686 */       System.arraycopy(this.offsets, 0, newOffsets, 0, linkIndex);
/* 687 */       this.offsets = newOffsets;
/* 688 */       String[] newIDs = new String[linkIndex];
/* 689 */       System.arraycopy(this.ids, 0, newIDs, 0, linkIndex);
/* 690 */       this.ids = newIDs;
/* 691 */       int[] newMnemonics = new int[linkIndex + 1];
/* 692 */       System.arraycopy(this.mnemonics, 0, newMnemonics, 0, linkIndex + 1);
/* 693 */       this.mnemonics = newMnemonics;
/*     */     }
/* 695 */     return result.toString();
/*     */   }
/*     */   
/*     */   int parseMnemonics(char[] buffer, int start, int end, StringBuilder result) {
/* 699 */     int mnemonic = -1;int index = start;
/* 700 */     while (index < end) {
/* 701 */       if (buffer[index] == '&') {
/* 702 */         if ((index + 1 < end) && (buffer[(index + 1)] == '&')) {
/* 703 */           result.append(buffer[index]);
/* 704 */           index++;
/*     */         } else {
/* 706 */           mnemonic = result.length();
/*     */         }
/*     */       } else {
/* 709 */         result.append(buffer[index]);
/*     */       }
/* 711 */       index++;
/*     */     }
/* 713 */     return mnemonic;
/*     */   }
/*     */   
/*     */   int setBounds(int x, int y, int width, int height, boolean move, boolean resize)
/*     */   {
/* 718 */     int result = super.setBounds(x, y, width, height, move, resize);
/* 719 */     if ((result & 0x100) != 0) {
/* 720 */       this.layout.setWidth(DPIUtil.autoScaleDown(width > 0 ? width : -1));
/* 721 */       redraw();
/*     */     }
/* 723 */     return result;
/*     */   }
/*     */   
/*     */   void setFontDescription(long font)
/*     */   {
/* 728 */     super.setFontDescription(font);
/* 729 */     this.layout.setFont(Font.gtk_new(this.display, font));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLinkForeground(Color color)
/*     */   {
/* 751 */     checkWidget();
/* 752 */     if (color != null) {
/* 753 */       if (color.isDisposed()) error(5);
/* 754 */       if (!color.equals(this.linkColor)) {}
/* 755 */     } else if (this.linkColor == null) { return; }
/* 756 */     this.linkColor = color;
/* 757 */     if (getEnabled()) {
/* 758 */       styleLinkParts();
/* 759 */       redraw();
/*     */     }
/*     */   }
/*     */   
/*     */   void setOrientation(boolean create)
/*     */   {
/* 765 */     super.setOrientation(create);
/* 766 */     this.layout.setOrientation(this.style & 0x6000000);
/* 767 */     if (!create) { redraw(true);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setText(String string)
/*     */   {
/* 807 */     checkWidget();
/* 808 */     if (string == null) error(4);
/* 809 */     if (string.equals(this.text)) return;
/* 810 */     this.text = string;
/* 811 */     this.layout.setText(parse(string));
/* 812 */     this.focusIndex = (this.offsets.length > 0 ? 0 : -1);
/* 813 */     this.selection.x = (this.selection.y = -1);
/* 814 */     styleLinkParts();
/* 815 */     int[] bidiSegments = new int[this.offsets.length * 2];
/* 816 */     for (int i = 0; i < this.offsets.length; i++) {
/* 817 */       Point point = this.offsets[i];
/* 818 */       bidiSegments[(i * 2)] = point.x;
/* 819 */       bidiSegments[(i * 2 + 1)] = (point.y + 1);
/*     */     }
/* 821 */     this.layout.setSegments(bidiSegments);
/* 822 */     TextStyle mnemonicStyle = new TextStyle(null, null, null);
/* 823 */     mnemonicStyle.underline = true;
/* 824 */     for (int i = 0; i < this.mnemonics.length; i++) {
/* 825 */       int mnemonic = this.mnemonics[i];
/* 826 */       if (mnemonic != -1) {
/* 827 */         this.layout.setStyle(mnemonicStyle, mnemonic, mnemonic);
/*     */       }
/*     */     }
/* 830 */     redraw();
/*     */   }
/*     */   
/*     */   void showWidget()
/*     */   {
/* 835 */     super.showWidget();
/* 836 */     fixStyle(this.handle);
/*     */   }
/*     */   
/*     */   void styleLinkParts() {
/* 840 */     boolean enabled = (this.state & 0x10) == 0;
/* 841 */     TextStyle linkStyle = new TextStyle(null, enabled ? getLinkForeground() : this.disabledColor, null);
/* 842 */     linkStyle.underline = true;
/* 843 */     for (int i = 0; i < this.offsets.length; i++) {
/* 844 */       Point point = this.offsets[i];
/* 845 */       this.layout.setStyle(linkStyle, point.x, point.y);
/*     */     }
/*     */   }
/*     */   
/*     */   int traversalCode(int key, GdkEventKey event)
/*     */   {
/* 851 */     if (this.offsets.length == 0) return 0;
/* 852 */     int bits = super.traversalCode(key, event);
/* 853 */     if ((key == 65289) && (this.focusIndex < this.offsets.length - 1)) {
/* 854 */       return bits & 0xFFFFFFEF;
/*     */     }
/* 856 */     if ((key == 65056) && (this.focusIndex > 0)) {
/* 857 */       return bits & 0xFFFFFFF7;
/*     */     }
/* 859 */     return bits;
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/widgets/Link.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */