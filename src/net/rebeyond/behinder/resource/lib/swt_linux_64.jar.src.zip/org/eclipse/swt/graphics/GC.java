/*      */ package org.eclipse.swt.graphics;
/*      */ 
/*      */ import org.eclipse.swt.SWT;
/*      */ import org.eclipse.swt.internal.C;
/*      */ import org.eclipse.swt.internal.Converter;
/*      */ import org.eclipse.swt.internal.DPIUtil;
/*      */ import org.eclipse.swt.internal.cairo.Cairo;
/*      */ import org.eclipse.swt.internal.gtk.GDK;
/*      */ import org.eclipse.swt.internal.gtk.GTK;
/*      */ import org.eclipse.swt.internal.gtk.GdkColor;
/*      */ import org.eclipse.swt.internal.gtk.GdkRGBA;
/*      */ import org.eclipse.swt.internal.gtk.GdkRectangle;
/*      */ import org.eclipse.swt.internal.gtk.OS;
/*      */ import org.eclipse.swt.internal.gtk.PangoAttribute;
/*      */ import org.eclipse.swt.widgets.Table;
/*      */ import org.eclipse.swt.widgets.Tree;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class GC
/*      */   extends Resource
/*      */ {
/*      */   public long handle;
/*      */   Drawable drawable;
/*      */   GCData data;
/*      */   private double[] cairoTransformationMatrix;
/*      */   private double[] currentTransform;
/*      */   private Rectangle clipping;
/*      */   static final int FOREGROUND = 1;
/*      */   static final int BACKGROUND = 2;
/*      */   static final int FONT = 4;
/*      */   static final int LINE_STYLE = 8;
/*      */   static final int LINE_CAP = 16;
/*      */   static final int LINE_JOIN = 32;
/*      */   static final int LINE_WIDTH = 64;
/*      */   static final int LINE_MITERLIMIT = 128;
/*      */   static final int BACKGROUND_BG = 256;
/*      */   static final int DRAW_OFFSET = 512;
/*      */   static final int DRAW = 761;
/*      */   static final int FILL = 2;
/*  107 */   static final float[] LINE_DOT = { 1.0F, 1.0F };
/*  108 */   static final float[] LINE_DASH = { 3.0F, 1.0F };
/*  109 */   static final float[] LINE_DASHDOT = { 3.0F, 1.0F, 1.0F, 1.0F };
/*  110 */   static final float[] LINE_DASHDOTDOT = { 3.0F, 1.0F, 1.0F, 1.0F, 1.0F, 1.0F };
/*  111 */   static final float[] LINE_DOT_ZERO = { 3.0F, 3.0F };
/*  112 */   static final float[] LINE_DASH_ZERO = { 18.0F, 6.0F };
/*  113 */   static final float[] LINE_DASHDOT_ZERO = { 9.0F, 6.0F, 3.0F, 6.0F };
/*  114 */   static final float[] LINE_DASHDOTDOT_ZERO = { 9.0F, 3.0F, 3.0F, 3.0F, 3.0F, 3.0F };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   GC() {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public GC(Drawable drawable)
/*      */   {
/*  143 */     this(drawable, 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public GC(Drawable drawable, int style)
/*      */   {
/*  176 */     if (drawable == null) SWT.error(4);
/*  177 */     GCData data = new GCData();
/*  178 */     data.style = checkStyle(style);
/*  179 */     long gdkGC = drawable.internal_new_GC(data);
/*  180 */     Device device = data.device;
/*  181 */     if (device == null) device = Device.getDevice();
/*  182 */     if (device == null) SWT.error(4);
/*  183 */     this.device = (data.device = device);
/*  184 */     init(drawable, data, gdkGC);
/*  185 */     init();
/*      */   }
/*      */   
/*      */   static void addCairoString(long cairo, String string, float x, float y, Font font) {
/*  189 */     byte[] buffer = Converter.wcsToMbcs(string, true);
/*  190 */     long layout = OS.pango_cairo_create_layout(cairo);
/*  191 */     if (layout == 0L) SWT.error(2);
/*  192 */     OS.pango_layout_set_text(layout, buffer, -1);
/*  193 */     OS.pango_layout_set_font_description(layout, font.handle);
/*  194 */     double[] currentX = new double[1];double[] currentY = new double[1];
/*  195 */     Cairo.cairo_get_current_point(cairo, currentX, currentY);
/*  196 */     if ((currentX[0] != x) || (currentY[0] != y)) {
/*  197 */       Cairo.cairo_move_to(cairo, x, y);
/*      */     }
/*  199 */     OS.pango_cairo_layout_path(cairo, layout);
/*  200 */     OS.g_object_unref(layout);
/*      */   }
/*      */   
/*      */   static int checkStyle(int style) {
/*  204 */     if ((style & 0x2000000) != 0) style &= 0xFBFFFFFF;
/*  205 */     return style & 0x6000000;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static GC gtk_new(long handle, GCData data)
/*      */   {
/*  226 */     GC gc = new GC();
/*  227 */     gc.device = data.device;
/*  228 */     gc.init(null, data, handle);
/*  229 */     return gc;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static GC gtk_new(Drawable drawable, GCData data)
/*      */   {
/*  250 */     GC gc = new GC();
/*  251 */     long gdkGC = drawable.internal_new_GC(data);
/*  252 */     gc.device = data.device;
/*  253 */     gc.init(drawable, data, gdkGC);
/*  254 */     return gc;
/*      */   }
/*      */   
/*      */   void checkGC(int mask) {
/*  258 */     int state = this.data.state;
/*  259 */     if ((state & mask) == mask) return;
/*  260 */     state = (state ^ mask) & mask;
/*  261 */     this.data.state |= mask;
/*  262 */     long cairo = this.data.cairo;
/*  263 */     if ((state & 0x3) != 0) {
/*  264 */       GdkColor color = null;
/*  265 */       GdkRGBA colorRGBA = null;
/*      */       Pattern pattern;
/*  267 */       if ((state & 0x1) != 0) {
/*  268 */         if (GTK.GTK3) {
/*  269 */           colorRGBA = this.data.foregroundRGBA;
/*      */         } else {
/*  271 */           color = this.data.foreground;
/*      */         }
/*  273 */         Pattern pattern = this.data.foregroundPattern;
/*  274 */         this.data.state &= 0xFFFFFFFD;
/*      */       } else {
/*  276 */         if (GTK.GTK3) {
/*  277 */           colorRGBA = this.data.backgroundRGBA;
/*      */         } else {
/*  279 */           color = this.data.background;
/*      */         }
/*  281 */         pattern = this.data.backgroundPattern;
/*  282 */         this.data.state &= 0xFFFFFFFE;
/*      */       }
/*  284 */       if (pattern != null) {
/*  285 */         if (((this.data.style & 0x8000000) != 0) && (pattern.surface != 0L)) {
/*  286 */           long newPattern = Cairo.cairo_pattern_create_for_surface(pattern.surface);
/*  287 */           if (newPattern == 0L) SWT.error(2);
/*  288 */           Cairo.cairo_pattern_set_extend(newPattern, 1);
/*  289 */           double[] matrix = { -1.0D, 0.0D, 0.0D, 1.0D, 0.0D, 0.0D };
/*  290 */           Cairo.cairo_pattern_set_matrix(newPattern, matrix);
/*  291 */           Cairo.cairo_set_source(cairo, newPattern);
/*  292 */           Cairo.cairo_pattern_destroy(newPattern);
/*      */         } else {
/*  294 */           Cairo.cairo_set_source(cairo, pattern.handle);
/*      */         }
/*      */       }
/*  297 */       else if (GTK.GTK3) {
/*  298 */         Cairo.cairo_set_source_rgba(cairo, colorRGBA.red, colorRGBA.green, colorRGBA.blue, this.data.alpha / 255.0F);
/*      */       } else {
/*  300 */         Cairo.cairo_set_source_rgba(cairo, (color.red & 0xFFFF) / 65535.0F, (color.green & 0xFFFF) / 65535.0F, (color.blue & 0xFFFF) / 65535.0F, this.data.alpha / 255.0F);
/*      */       }
/*      */     }
/*      */     
/*  304 */     if (((state & 0x4) != 0) && 
/*  305 */       (this.data.layout != 0L)) {
/*  306 */       Font font = this.data.font;
/*  307 */       OS.pango_layout_set_font_description(this.data.layout, font.handle);
/*      */     }
/*      */     
/*  310 */     if ((state & 0x10) != 0) {
/*  311 */       int cap_style = 0;
/*  312 */       switch (this.data.lineCap) {
/*  313 */       case 2:  cap_style = 1; break;
/*  314 */       case 1:  cap_style = 0; break;
/*  315 */       case 3:  cap_style = 2;
/*      */       }
/*  317 */       Cairo.cairo_set_line_cap(cairo, cap_style);
/*      */     }
/*  319 */     if ((state & 0x20) != 0) {
/*  320 */       int join_style = 0;
/*  321 */       switch (this.data.lineJoin) {
/*  322 */       case 1:  join_style = 0; break;
/*  323 */       case 2:  join_style = 1; break;
/*  324 */       case 3:  join_style = 2;
/*      */       }
/*  326 */       Cairo.cairo_set_line_join(cairo, join_style);
/*      */     }
/*  328 */     if ((state & 0x40) != 0) {
/*  329 */       Cairo.cairo_set_line_width(cairo, this.data.lineWidth == 0.0F ? DPIUtil.autoScaleUp(this.drawable, 1) : this.data.lineWidth);
/*  330 */       switch (this.data.lineStyle) {
/*      */       case 2: 
/*      */       case 3: 
/*      */       case 4: 
/*      */       case 5: 
/*  335 */         state |= 0x8;
/*      */       }
/*      */     }
/*  338 */     if ((state & 0x8) != 0) {
/*  339 */       float dashesOffset = 0.0F;
/*  340 */       float[] dashes = null;
/*  341 */       float width = this.data.lineWidth;
/*  342 */       switch (this.data.lineStyle) {
/*      */       case 1: 
/*      */         break; case 2:  dashes = width != 0.0F ? LINE_DASH : LINE_DASH_ZERO; break;
/*  345 */       case 3:  dashes = width != 0.0F ? LINE_DOT : LINE_DOT_ZERO; break;
/*  346 */       case 4:  dashes = width != 0.0F ? LINE_DASHDOT : LINE_DASHDOT_ZERO; break;
/*  347 */       case 5:  dashes = width != 0.0F ? LINE_DASHDOTDOT : LINE_DASHDOTDOT_ZERO; break;
/*  348 */       case 6:  dashes = this.data.lineDashes;
/*      */       }
/*  350 */       if (dashes != null) {
/*  351 */         dashesOffset = this.data.lineDashesOffset;
/*  352 */         double[] cairoDashes = new double[dashes.length];
/*  353 */         for (int i = 0; i < cairoDashes.length; i++) {
/*  354 */           cairoDashes[i] = ((width == 0.0F) || (this.data.lineStyle == 6) ? dashes[i] : dashes[i] * width);
/*      */         }
/*  356 */         Cairo.cairo_set_dash(cairo, cairoDashes, cairoDashes.length, dashesOffset);
/*      */       } else {
/*  358 */         Cairo.cairo_set_dash(cairo, null, 0, 0.0D);
/*      */       }
/*      */     }
/*  361 */     if ((state & 0x80) != 0) {
/*  362 */       Cairo.cairo_set_miter_limit(cairo, this.data.lineMiterLimit);
/*      */     }
/*  364 */     if ((state & 0x200) != 0) {
/*  365 */       this.data.cairoXoffset = (this.data.cairoYoffset = 0.0D);
/*  366 */       double[] matrix = new double[6];
/*  367 */       Cairo.cairo_get_matrix(cairo, matrix);
/*  368 */       double[] dx = { 1.0D };
/*  369 */       double[] dy = { 1.0D };
/*  370 */       Cairo.cairo_user_to_device_distance(cairo, dx, dy);
/*  371 */       double scaling = dx[0];
/*  372 */       if (scaling < 0.0D) scaling = -scaling;
/*  373 */       double strokeWidth = this.data.lineWidth * scaling;
/*  374 */       if ((strokeWidth == 0.0D) || ((int)strokeWidth % 2 == 1)) {
/*  375 */         this.data.cairoXoffset = (0.5D / scaling);
/*      */       }
/*  377 */       scaling = dy[0];
/*  378 */       if (scaling < 0.0D) scaling = -scaling;
/*  379 */       strokeWidth = this.data.lineWidth * scaling;
/*  380 */       if ((strokeWidth == 0.0D) || ((int)strokeWidth % 2 == 1)) {
/*  381 */         this.data.cairoYoffset = (0.5D / scaling);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   long convertRgn(long rgn, double[] matrix) {
/*  387 */     long newRgn = GDK.gdk_region_new();
/*  388 */     if (isIdentity(matrix)) {
/*  389 */       GDK.gdk_region_union(newRgn, rgn);
/*  390 */       return newRgn;
/*      */     }
/*  392 */     int[] nRects = new int[1];
/*  393 */     long[] rects = new long[1];
/*  394 */     Region.gdk_region_get_rectangles(rgn, rects, nRects);
/*  395 */     GdkRectangle rect = new GdkRectangle();
/*  396 */     int[] pointArray = new int[8];
/*  397 */     double[] x = new double[1];double[] y = new double[1];
/*  398 */     for (int i = 0; i < nRects[0]; i++) {
/*  399 */       OS.memmove(rect, rects[0] + i * GdkRectangle.sizeof, GdkRectangle.sizeof);
/*  400 */       x[0] = rect.x;
/*  401 */       y[0] = rect.y;
/*  402 */       Cairo.cairo_matrix_transform_point(matrix, x, y);
/*  403 */       pointArray[0] = ((int)x[0]);
/*  404 */       pointArray[1] = ((int)y[0]);
/*  405 */       x[0] = (rect.x + rect.width);
/*  406 */       y[0] = rect.y;
/*  407 */       Cairo.cairo_matrix_transform_point(matrix, x, y);
/*  408 */       pointArray[2] = ((int)Math.round(x[0]));
/*  409 */       pointArray[3] = ((int)y[0]);
/*  410 */       x[0] = (rect.x + rect.width);
/*  411 */       y[0] = (rect.y + rect.height);
/*  412 */       Cairo.cairo_matrix_transform_point(matrix, x, y);
/*  413 */       pointArray[4] = ((int)Math.round(x[0]));
/*  414 */       pointArray[5] = ((int)Math.round(y[0]));
/*  415 */       x[0] = rect.x;
/*  416 */       y[0] = (rect.y + rect.height);
/*  417 */       Cairo.cairo_matrix_transform_point(matrix, x, y);
/*  418 */       pointArray[6] = ((int)x[0]);
/*  419 */       pointArray[7] = ((int)Math.round(y[0]));
/*  420 */       long polyRgn = Region.gdk_region_polygon(pointArray, pointArray.length / 2, 0);
/*  421 */       GDK.gdk_region_union(newRgn, polyRgn);
/*  422 */       GDK.gdk_region_destroy(polyRgn);
/*      */     }
/*  424 */     if (rects[0] != 0L) OS.g_free(rects[0]);
/*  425 */     return newRgn;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void copyArea(Image image, int x, int y)
/*      */   {
/*  445 */     if (this.handle == 0L) SWT.error(44);
/*  446 */     if (image == null) SWT.error(4);
/*  447 */     if ((image.type != 0) || (image.isDisposed())) SWT.error(5);
/*  448 */     Point loc = DPIUtil.autoScaleUp(this.drawable, new Point(x, y));
/*  449 */     copyAreaInPixels(image, loc.x, loc.y);
/*      */   }
/*      */   
/*  452 */   void copyAreaInPixels(Image image, int x, int y) { long cairo = Cairo.cairo_create(image.surface);
/*  453 */     if (cairo == 0L) SWT.error(2);
/*  454 */     Cairo.cairo_translate(cairo, -x, -y);
/*  455 */     Cairo.cairo_push_group(cairo);
/*  456 */     if (this.data.image != null) {
/*  457 */       Cairo.cairo_set_source_surface(cairo, this.data.image.surface, 0.0D, 0.0D);
/*  458 */     } else if (this.data.drawable != 0L) {
/*  459 */       GDK.gdk_cairo_set_source_window(cairo, this.data.drawable, 0, 0);
/*      */     } else {
/*  461 */       Cairo.cairo_destroy(cairo);
/*  462 */       return;
/*      */     }
/*  464 */     Cairo.cairo_set_operator(cairo, 1);
/*  465 */     Cairo.cairo_paint(cairo);
/*  466 */     Cairo.cairo_pop_group_to_source(cairo);
/*  467 */     Cairo.cairo_paint(cairo);
/*  468 */     Cairo.cairo_destroy(cairo);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void copyArea(int srcX, int srcY, int width, int height, int destX, int destY)
/*      */   {
/*  487 */     if (this.handle == 0L) SWT.error(44);
/*  488 */     Rectangle src = DPIUtil.autoScaleUp(this.drawable, new Rectangle(srcX, srcY, width, height));
/*  489 */     Point dest = DPIUtil.autoScaleUp(this.drawable, new Point(destX, destY));
/*  490 */     copyAreaInPixels(src.x, src.y, src.width, src.height, dest.x, dest.y);
/*      */   }
/*      */   
/*      */   void copyAreaInPixels(int srcX, int srcY, int width, int height, int destX, int destY) {
/*  494 */     copyAreaInPixels(srcX, srcY, width, height, destX, destY, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void copyArea(int srcX, int srcY, int width, int height, int destX, int destY, boolean paint)
/*      */   {
/*  515 */     if (this.handle == 0L) SWT.error(44);
/*  516 */     Rectangle srcLoc = DPIUtil.autoScaleUp(this.drawable, new Rectangle(srcX, srcY, width, height));
/*  517 */     Point destLoc = DPIUtil.autoScaleUp(this.drawable, new Point(destX, destY));
/*  518 */     copyAreaInPixels(srcLoc.x, srcLoc.y, srcLoc.width, srcLoc.height, destLoc.x, destLoc.y, paint);
/*      */   }
/*      */   
/*  521 */   void copyAreaInPixels(int srcX, int srcY, int width, int height, int destX, int destY, boolean paint) { if ((width <= 0) || (height <= 0)) return;
/*  522 */     int deltaX = destX - srcX;int deltaY = destY - srcY;
/*  523 */     if ((deltaX == 0) && (deltaY == 0)) return;
/*  524 */     long drawable = this.data.drawable;
/*  525 */     if (this.data.image != null) {
/*  526 */       Cairo.cairo_set_source_surface(this.handle, this.data.image.surface, deltaX, deltaY);
/*  527 */       Cairo.cairo_rectangle(this.handle, destX, destY, width, height);
/*  528 */       Cairo.cairo_set_operator(this.handle, 1);
/*  529 */       Cairo.cairo_fill(this.handle);
/*  530 */     } else if (drawable != 0L) {
/*  531 */       Cairo.cairo_save(this.handle);
/*  532 */       Cairo.cairo_rectangle(this.handle, destX, destY, width, height);
/*  533 */       Cairo.cairo_clip(this.handle);
/*  534 */       Cairo.cairo_translate(this.handle, deltaX, deltaY);
/*  535 */       Cairo.cairo_set_operator(this.handle, 1);
/*  536 */       Cairo.cairo_push_group(this.handle);
/*  537 */       GDK.gdk_cairo_set_source_window(this.handle, drawable, 0, 0);
/*  538 */       Cairo.cairo_paint(this.handle);
/*  539 */       Cairo.cairo_pop_group_to_source(this.handle);
/*  540 */       Cairo.cairo_rectangle(this.handle, destX - deltaX, destY - deltaY, width, height);
/*  541 */       Cairo.cairo_clip(this.handle);
/*  542 */       Cairo.cairo_paint(this.handle);
/*  543 */       Cairo.cairo_restore(this.handle);
/*  544 */       if (paint) { long visibleRegion;
/*      */         long visibleRegion;
/*  546 */         if (GTK.GTK3) {
/*  547 */           visibleRegion = GDK.gdk_window_get_visible_region(drawable);
/*      */         } else {
/*  549 */           visibleRegion = GDK.gdk_drawable_get_visible_region(drawable);
/*      */         }
/*  551 */         GdkRectangle srcRect = new GdkRectangle();
/*  552 */         srcRect.x = srcX;
/*  553 */         srcRect.y = srcY;
/*  554 */         srcRect.width = width;
/*  555 */         srcRect.height = height;
/*  556 */         long copyRegion = GDK.gdk_region_rectangle(srcRect);
/*  557 */         GDK.gdk_region_intersect(copyRegion, visibleRegion);
/*  558 */         long invalidateRegion = GDK.gdk_region_rectangle(srcRect);
/*  559 */         GDK.gdk_region_subtract(invalidateRegion, visibleRegion);
/*  560 */         GDK.gdk_region_offset(invalidateRegion, deltaX, deltaY);
/*  561 */         GDK.gdk_window_invalidate_region(drawable, invalidateRegion, false);
/*  562 */         GDK.gdk_region_destroy(visibleRegion);
/*  563 */         GDK.gdk_region_destroy(copyRegion);
/*  564 */         GDK.gdk_region_destroy(invalidateRegion);
/*      */       }
/*      */     }
/*  567 */     if ((this.data.image == null & paint)) {
/*  568 */       boolean disjoint = (destX + width < srcX) || (srcX + width < destX) || (destY + height < srcY) || (srcY + height < destY);
/*  569 */       GdkRectangle rect = new GdkRectangle();
/*  570 */       if (disjoint) {
/*  571 */         rect.x = srcX;
/*  572 */         rect.y = srcY;
/*  573 */         rect.width = Math.max(0, width);
/*  574 */         rect.height = Math.max(0, height);
/*  575 */         GDK.gdk_window_invalidate_rect(drawable, rect, false);
/*      */       }
/*      */       else {
/*  578 */         if (deltaX != 0) {
/*  579 */           int newX = destX - deltaX;
/*  580 */           if (deltaX < 0) newX = destX + width;
/*  581 */           rect.x = newX;
/*  582 */           rect.y = srcY;
/*  583 */           rect.width = Math.abs(deltaX);
/*  584 */           rect.height = Math.max(0, height);
/*  585 */           GDK.gdk_window_invalidate_rect(drawable, rect, false);
/*      */         }
/*      */         
/*  588 */         if (deltaY != 0) {
/*  589 */           int newY = destY - deltaY;
/*  590 */           if (deltaY < 0) newY = destY + height;
/*  591 */           rect.x = srcX;
/*  592 */           rect.y = newY;
/*  593 */           rect.width = Math.max(0, width);
/*  594 */           rect.height = Math.abs(deltaY);
/*  595 */           GDK.gdk_window_invalidate_rect(drawable, rect, false);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   void createLayout()
/*      */   {
/*  603 */     long context = GDK.gdk_pango_context_get();
/*  604 */     if (context == 0L) SWT.error(2);
/*  605 */     this.data.context = context;
/*  606 */     long layout = OS.pango_layout_new(context);
/*  607 */     if (layout == 0L) SWT.error(2);
/*  608 */     this.data.layout = layout;
/*  609 */     OS.pango_context_set_language(context, GTK.gtk_get_default_language());
/*  610 */     OS.pango_context_set_base_dir(context, (this.data.style & 0x8000000) != 0 ? 1 : 0);
/*  611 */     OS.pango_layout_set_auto_dir(layout, false);
/*      */   }
/*      */   
/*      */   void disposeLayout() {
/*  615 */     this.data.string = null;
/*  616 */     if (this.data.context != 0L) OS.g_object_unref(this.data.context);
/*  617 */     if (this.data.layout != 0L) OS.g_object_unref(this.data.layout);
/*  618 */     this.data.layout = (this.data.context = 0L);
/*      */   }
/*      */   
/*      */   void destroy()
/*      */   {
/*  623 */     if (this.data.disposeCairo) {
/*  624 */       long cairo = this.data.cairo;
/*  625 */       Cairo.cairo_destroy(cairo);
/*      */     }
/*  627 */     this.data.cairo = 0L;
/*      */     
/*      */ 
/*  630 */     long clipRgn = this.data.clipRgn;
/*  631 */     if (clipRgn != 0L) GDK.gdk_region_destroy(clipRgn);
/*  632 */     Image image = this.data.image;
/*  633 */     if (image != null) {
/*  634 */       image.memGC = null;
/*  635 */       if (image.transparentPixel != -1) { image.createMask();
/*      */       }
/*      */     }
/*  638 */     disposeLayout();
/*      */     
/*      */ 
/*  641 */     if (this.drawable != null) {
/*  642 */       this.drawable.internal_dispose_GC(this.handle, this.data);
/*      */     }
/*  644 */     this.data.drawable = (this.data.clipRgn = 0L);
/*  645 */     this.drawable = null;
/*  646 */     this.handle = 0L;
/*  647 */     this.data.image = null;
/*  648 */     this.data.string = null;
/*  649 */     this.data = null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void drawArc(int x, int y, int width, int height, int startAngle, int arcAngle)
/*      */   {
/*  682 */     if (this.handle == 0L) SWT.error(44);
/*  683 */     Rectangle loc = DPIUtil.autoScaleUp(this.drawable, new Rectangle(x, y, width, height));
/*  684 */     drawArcInPixels(loc.x, loc.y, loc.width, loc.height, startAngle, arcAngle);
/*      */   }
/*      */   
/*  687 */   void drawArcInPixels(int x, int y, int width, int height, int startAngle, int arcAngle) { checkGC(761);
/*  688 */     if (width < 0) {
/*  689 */       x += width;
/*  690 */       width = -width;
/*      */     }
/*  692 */     if (height < 0) {
/*  693 */       y += height;
/*  694 */       height = -height;
/*      */     }
/*  696 */     if ((width == 0) || (height == 0) || (arcAngle == 0)) return;
/*  697 */     long cairo = this.data.cairo;
/*  698 */     double xOffset = this.data.cairoXoffset;double yOffset = this.data.cairoYoffset;
/*  699 */     if (width == height) {
/*  700 */       if (arcAngle >= 0) {
/*  701 */         Cairo.cairo_arc_negative(cairo, x + xOffset + width / 2.0F, y + yOffset + height / 2.0F, width / 2.0F, -startAngle * 3.1415927F / 180.0F, -(startAngle + arcAngle) * 3.1415927F / 180.0F);
/*      */       } else {
/*  703 */         Cairo.cairo_arc(cairo, x + xOffset + width / 2.0F, y + yOffset + height / 2.0F, width / 2.0F, -startAngle * 3.1415927F / 180.0F, -(startAngle + arcAngle) * 3.1415927F / 180.0F);
/*      */       }
/*      */     } else {
/*  706 */       Cairo.cairo_save(cairo);
/*  707 */       Cairo.cairo_translate(cairo, x + xOffset + width / 2.0F, y + yOffset + height / 2.0F);
/*  708 */       Cairo.cairo_scale(cairo, width / 2.0F, height / 2.0F);
/*  709 */       if (arcAngle >= 0) {
/*  710 */         Cairo.cairo_arc_negative(cairo, 0.0D, 0.0D, 1.0D, -startAngle * 3.1415927F / 180.0F, -(startAngle + arcAngle) * 3.1415927F / 180.0F);
/*      */       } else {
/*  712 */         Cairo.cairo_arc(cairo, 0.0D, 0.0D, 1.0D, -startAngle * 3.1415927F / 180.0F, -(startAngle + arcAngle) * 3.1415927F / 180.0F);
/*      */       }
/*  714 */       Cairo.cairo_restore(cairo);
/*      */     }
/*  716 */     Cairo.cairo_stroke(cairo);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void drawFocus(int x, int y, int width, int height)
/*      */   {
/*  737 */     if (this.handle == 0L) SWT.error(44);
/*  738 */     Rectangle loc = DPIUtil.autoScaleUp(this.drawable, new Rectangle(x, y, width, height));
/*  739 */     drawFocusInPixels(loc.x, loc.y, loc.width, loc.height);
/*      */   }
/*      */   
/*  742 */   void drawFocusInPixels(int x, int y, int width, int height) { long cairo = this.data.cairo;
/*  743 */     checkGC(1);
/*  744 */     if (GTK.GTK3) {
/*  745 */       long context = GTK.gtk_widget_get_style_context(this.data.device.shellHandle);
/*  746 */       GTK.gtk_render_focus(context, cairo, x, y, width, height);
/*      */     } else {
/*  748 */       int[] lineWidth = new int[1];
/*  749 */       GTK.gtk_widget_style_get(this.data.device.shellHandle, OS.focus_line_width, lineWidth, 0L);
/*  750 */       Cairo.cairo_save(cairo);
/*  751 */       Cairo.cairo_set_line_width(cairo, lineWidth[0]);
/*  752 */       double[] dashes = { 1.0D, 1.0D };
/*  753 */       double dash_offset = -lineWidth[0] / 2.0F;
/*  754 */       while (dash_offset < 0.0D) dash_offset += 2.0D;
/*  755 */       Cairo.cairo_set_dash(cairo, dashes, dashes.length, dash_offset);
/*  756 */       Cairo.cairo_rectangle(cairo, x + lineWidth[0] / 2.0F, y + lineWidth[0] / 2.0F, width, height);
/*  757 */       Cairo.cairo_stroke(cairo);
/*  758 */       Cairo.cairo_restore(cairo);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void drawImage(Image image, int x, int y)
/*      */   {
/*  782 */     if (this.handle == 0L) SWT.error(44);
/*  783 */     if (image == null) SWT.error(4);
/*  784 */     if (image.isDisposed()) SWT.error(5);
/*  785 */     Point loc = DPIUtil.autoScaleUp(this.drawable, new Point(x, y));
/*  786 */     drawImageInPixels(image, loc.x, loc.y);
/*      */   }
/*      */   
/*  789 */   void drawImageInPixels(Image image, int x, int y) { drawImage(image, 0, 0, -1, -1, x, y, -1, -1, true); }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void drawImage(Image image, int srcX, int srcY, int srcWidth, int srcHeight, int destX, int destY, int destWidth, int destHeight)
/*      */   {
/*  825 */     if (this.handle == 0L) SWT.error(44);
/*  826 */     if ((srcWidth == 0) || (srcHeight == 0) || (destWidth == 0) || (destHeight == 0)) return;
/*  827 */     if ((srcX < 0) || (srcY < 0) || (srcWidth < 0) || (srcHeight < 0) || (destWidth < 0) || (destHeight < 0)) {
/*  828 */       SWT.error(5);
/*      */     }
/*  830 */     if (image == null) SWT.error(4);
/*  831 */     if (image.isDisposed()) SWT.error(5);
/*  832 */     Rectangle srcRect = DPIUtil.autoScaleUp(this.drawable, new Rectangle(srcX, srcY, srcWidth, srcHeight));
/*  833 */     Rectangle destRect = DPIUtil.autoScaleUp(this.drawable, new Rectangle(destX, destY, destWidth, destHeight));
/*  834 */     drawImage(image, srcRect.x, srcRect.y, srcRect.width, srcRect.height, destRect.x, destRect.y, destRect.width, destRect.height, false);
/*      */   }
/*      */   
/*      */   void drawImage(Image srcImage, int srcX, int srcY, int srcWidth, int srcHeight, int destX, int destY, int destWidth, int destHeight, boolean simple) {
/*  838 */     srcImage.refreshImageForZoom();
/*      */     
/*  840 */     int imgWidth = srcImage.width;
/*  841 */     int imgHeight = srcImage.height;
/*  842 */     if (simple) {
/*  843 */       srcWidth = destWidth = imgWidth;
/*  844 */       srcHeight = destHeight = imgHeight;
/*      */     } else {
/*  846 */       simple = (srcX == 0) && (srcY == 0) && (srcWidth == destWidth) && (destWidth == imgWidth) && (srcHeight == destHeight) && (destHeight == imgHeight);
/*      */       
/*      */ 
/*  849 */       if ((srcX + srcWidth > imgWidth + 1) || (srcY + srcHeight > imgHeight + 1)) {
/*  850 */         SWT.error(5);
/*      */       }
/*      */     }
/*  853 */     long cairo = this.data.cairo;
/*  854 */     if (this.data.alpha != 0) {
/*  855 */       srcImage.createSurface();
/*  856 */       Cairo.cairo_save(cairo);
/*  857 */       if ((this.data.style & 0x8000000) != 0) {
/*  858 */         Cairo.cairo_scale(cairo, -1.0D, 1.0D);
/*  859 */         Cairo.cairo_translate(cairo, -2 * destX - destWidth, 0.0D);
/*      */       }
/*  861 */       Cairo.cairo_rectangle(cairo, destX, destY, destWidth, destHeight);
/*  862 */       Cairo.cairo_clip(cairo);
/*  863 */       if ((srcWidth != destWidth) || (srcHeight != destHeight)) {
/*  864 */         float scaleX = destWidth / srcWidth;
/*  865 */         float scaleY = destHeight / srcHeight;
/*  866 */         Cairo.cairo_translate(cairo, destX - (int)(srcX * scaleX), destY - (int)(srcY * scaleY));
/*  867 */         Cairo.cairo_scale(cairo, scaleX, scaleY);
/*      */       } else {
/*  869 */         Cairo.cairo_translate(cairo, destX - srcX, destY - srcY);
/*      */       }
/*  871 */       int filter = 1;
/*  872 */       switch (this.data.interpolation) {
/*  873 */       case -1:  filter = 1; break;
/*  874 */       case 0:  filter = 3; break;
/*  875 */       case 1:  filter = 0; break;
/*  876 */       case 2:  filter = 2;
/*      */       }
/*  878 */       long pattern = Cairo.cairo_pattern_create_for_surface(srcImage.surface);
/*  879 */       if (pattern == 0L) SWT.error(2);
/*  880 */       if ((srcWidth != destWidth) || (srcHeight != destHeight)) {
/*  881 */         Cairo.cairo_pattern_set_extend(pattern, 3);
/*      */       }
/*  883 */       Cairo.cairo_pattern_set_filter(pattern, filter);
/*  884 */       Cairo.cairo_set_source(cairo, pattern);
/*  885 */       if (this.data.alpha != 255) {
/*  886 */         Cairo.cairo_paint_with_alpha(cairo, this.data.alpha / 255.0F);
/*      */       } else {
/*  888 */         Cairo.cairo_paint(cairo);
/*      */       }
/*  890 */       Cairo.cairo_restore(cairo);
/*  891 */       Cairo.cairo_pattern_destroy(pattern);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void drawLine(int x1, int y1, int x2, int y2)
/*      */   {
/*  909 */     if (this.handle == 0L) SWT.error(44);
/*  910 */     Point loc1 = DPIUtil.autoScaleUp(this.drawable, new Point(x1, y1));
/*  911 */     Point loc2 = DPIUtil.autoScaleUp(this.drawable, new Point(x2, y2));
/*  912 */     drawLineInPixels(loc1.x, loc1.y, loc2.x, loc2.y);
/*      */   }
/*      */   
/*  915 */   void drawLineInPixels(int x1, int y1, int x2, int y2) { checkGC(761);
/*  916 */     long cairo = this.data.cairo;
/*  917 */     double xOffset = this.data.cairoXoffset;double yOffset = this.data.cairoYoffset;
/*  918 */     if (Cairo.cairo_version() >= Cairo.CAIRO_VERSION_ENCODE(1, 12, 0)) {
/*  919 */       Cairo.cairo_set_antialias(cairo, 6);
/*      */     }
/*  921 */     Cairo.cairo_move_to(cairo, x1 + xOffset, y1 + yOffset);
/*  922 */     Cairo.cairo_line_to(cairo, x2 + xOffset, y2 + yOffset);
/*  923 */     Cairo.cairo_stroke(cairo);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void drawOval(int x, int y, int width, int height)
/*      */   {
/*  948 */     if (this.handle == 0L) SWT.error(44);
/*  949 */     Rectangle rect = DPIUtil.autoScaleUp(this.drawable, new Rectangle(x, y, width, height));
/*  950 */     drawOvalInPixels(rect.x, rect.y, rect.width, rect.height);
/*      */   }
/*      */   
/*  953 */   void drawOvalInPixels(int x, int y, int width, int height) { checkGC(761);
/*  954 */     if (width < 0) {
/*  955 */       x += width;
/*  956 */       width = -width;
/*      */     }
/*  958 */     if (height < 0) {
/*  959 */       y += height;
/*  960 */       height = -height;
/*      */     }
/*  962 */     long cairo = this.data.cairo;
/*  963 */     double xOffset = this.data.cairoXoffset;double yOffset = this.data.cairoYoffset;
/*  964 */     if (width == height) {
/*  965 */       Cairo.cairo_arc_negative(cairo, x + xOffset + width / 2.0F, y + yOffset + height / 2.0F, width / 2.0F, 0.0D, -6.2831854820251465D);
/*      */     } else {
/*  967 */       Cairo.cairo_save(cairo);
/*  968 */       Cairo.cairo_translate(cairo, x + xOffset + width / 2.0F, y + yOffset + height / 2.0F);
/*  969 */       Cairo.cairo_scale(cairo, width / 2.0F, height / 2.0F);
/*  970 */       Cairo.cairo_arc_negative(cairo, 0.0D, 0.0D, 1.0D, 0.0D, -6.2831854820251465D);
/*  971 */       Cairo.cairo_restore(cairo);
/*      */     }
/*  973 */     Cairo.cairo_stroke(cairo);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void drawPath(Path path)
/*      */   {
/* 1000 */     if (this.handle == 0L) SWT.error(44);
/* 1001 */     if (path == null) SWT.error(4);
/* 1002 */     if (path.handle == 0L) SWT.error(5);
/* 1003 */     initCairo();
/* 1004 */     checkGC(761);
/* 1005 */     long cairo = this.data.cairo;
/* 1006 */     Cairo.cairo_save(cairo);
/* 1007 */     double xOffset = this.data.cairoXoffset;double yOffset = this.data.cairoYoffset;
/* 1008 */     Cairo.cairo_translate(cairo, xOffset, yOffset);
/* 1009 */     long copy = Cairo.cairo_copy_path(path.handle);
/* 1010 */     if (copy == 0L) SWT.error(2);
/* 1011 */     Cairo.cairo_append_path(cairo, copy);
/* 1012 */     Cairo.cairo_path_destroy(copy);
/* 1013 */     Cairo.cairo_stroke(cairo);
/* 1014 */     Cairo.cairo_restore(cairo);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void drawPoint(int x, int y)
/*      */   {
/* 1035 */     if (this.handle == 0L) SWT.error(44);
/* 1036 */     Point loc = DPIUtil.autoScaleUp(this.drawable, new Point(x, y));
/* 1037 */     drawPointInPixels(loc.x, loc.y);
/*      */   }
/*      */   
/* 1040 */   void drawPointInPixels(int x, int y) { checkGC(761);
/* 1041 */     long cairo = this.data.cairo;
/* 1042 */     Cairo.cairo_rectangle(cairo, x, y, 1.0D, 1.0D);
/* 1043 */     Cairo.cairo_fill(cairo);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void drawPolygon(int[] pointArray)
/*      */   {
/* 1064 */     if (this.handle == 0L) SWT.error(44);
/* 1065 */     if (pointArray == null) SWT.error(4);
/* 1066 */     int[] scaledPointArray = DPIUtil.autoScaleUp(this.drawable, pointArray);
/* 1067 */     drawPolygonInPixels(scaledPointArray);
/*      */   }
/*      */   
/* 1070 */   void drawPolygonInPixels(int[] pointArray) { checkGC(761);
/* 1071 */     long cairo = this.data.cairo;
/* 1072 */     drawPolyline(cairo, pointArray, true);
/* 1073 */     Cairo.cairo_stroke(cairo);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void drawPolyline(int[] pointArray)
/*      */   {
/* 1094 */     if (this.handle == 0L) SWT.error(44);
/* 1095 */     if (pointArray == null) SWT.error(4);
/* 1096 */     int[] scaledPointArray = DPIUtil.autoScaleUp(this.drawable, pointArray);
/* 1097 */     drawPolylineInPixels(scaledPointArray);
/*      */   }
/*      */   
/* 1100 */   void drawPolylineInPixels(int[] pointArray) { checkGC(761);
/* 1101 */     long cairo = this.data.cairo;
/* 1102 */     drawPolyline(cairo, pointArray, false);
/* 1103 */     Cairo.cairo_stroke(cairo);
/*      */   }
/*      */   
/*      */   void drawPolyline(long cairo, int[] pointArray, boolean close) {
/* 1107 */     int count = pointArray.length / 2;
/* 1108 */     if (count == 0) return;
/* 1109 */     double xOffset = this.data.cairoXoffset;double yOffset = this.data.cairoYoffset;
/* 1110 */     Cairo.cairo_move_to(cairo, pointArray[0] + xOffset, pointArray[1] + yOffset);
/* 1111 */     int i = 1; for (int j = 2; i < count; j += 2) {
/* 1112 */       Cairo.cairo_line_to(cairo, pointArray[j] + xOffset, pointArray[(j + 1)] + yOffset);i++;
/*      */     }
/* 1114 */     if (close) { Cairo.cairo_close_path(cairo);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void drawRectangle(int x, int y, int width, int height)
/*      */   {
/* 1133 */     if (this.handle == 0L) SWT.error(44);
/* 1134 */     drawRectangle(new Rectangle(x, y, width, height));
/*      */   }
/*      */   
/* 1137 */   void drawRectangleInPixels(int x, int y, int width, int height) { checkGC(761);
/* 1138 */     if (width < 0) {
/* 1139 */       x += width;
/* 1140 */       width = -width;
/*      */     }
/* 1142 */     if (height < 0) {
/* 1143 */       y += height;
/* 1144 */       height = -height;
/*      */     }
/* 1146 */     long cairo = this.data.cairo;
/* 1147 */     double xOffset = this.data.cairoXoffset;double yOffset = this.data.cairoYoffset;
/* 1148 */     Cairo.cairo_rectangle(cairo, x + xOffset, y + yOffset, width, height);
/* 1149 */     Cairo.cairo_stroke(cairo);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void drawRectangle(Rectangle rect)
/*      */   {
/* 1169 */     if (rect == null) SWT.error(4);
/* 1170 */     drawRectangleInPixels(DPIUtil.autoScaleUp(this.drawable, rect));
/*      */   }
/*      */   
/* 1173 */   void drawRectangleInPixels(Rectangle rect) { drawRectangleInPixels(rect.x, rect.y, rect.width, rect.height); }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void drawRoundRectangle(int x, int y, int width, int height, int arcWidth, int arcHeight)
/*      */   {
/* 1197 */     if (this.handle == 0L) SWT.error(44);
/* 1198 */     Rectangle rect = DPIUtil.autoScaleUp(this.drawable, new Rectangle(x, y, width, height));
/* 1199 */     Point arcSize = DPIUtil.autoScaleUp(this.drawable, new Point(arcWidth, arcHeight));
/* 1200 */     drawRoundRectangleInPixels(rect.x, rect.y, rect.width, rect.height, arcSize.x, arcSize.y);
/*      */   }
/*      */   
/* 1203 */   void drawRoundRectangleInPixels(int x, int y, int width, int height, int arcWidth, int arcHeight) { checkGC(761);
/* 1204 */     int nx = x;
/* 1205 */     int ny = y;
/* 1206 */     int nw = width;
/* 1207 */     int nh = height;
/* 1208 */     int naw = arcWidth;
/* 1209 */     int nah = arcHeight;
/* 1210 */     if (nw < 0) {
/* 1211 */       nw = 0 - nw;
/* 1212 */       nx -= nw;
/*      */     }
/* 1214 */     if (nh < 0) {
/* 1215 */       nh = 0 - nh;
/* 1216 */       ny -= nh;
/*      */     }
/* 1218 */     if (naw < 0) naw = 0 - naw;
/* 1219 */     if (nah < 0) nah = 0 - nah;
/* 1220 */     long cairo = this.data.cairo;
/* 1221 */     double xOffset = this.data.cairoXoffset;double yOffset = this.data.cairoYoffset;
/* 1222 */     if ((naw == 0) || (nah == 0)) {
/* 1223 */       Cairo.cairo_rectangle(cairo, x + xOffset, y + yOffset, width, height);
/*      */     } else {
/* 1225 */       float naw2 = naw / 2.0F;
/* 1226 */       float nah2 = nah / 2.0F;
/* 1227 */       float fw = nw / naw2;
/* 1228 */       float fh = nh / nah2;
/* 1229 */       Cairo.cairo_save(cairo);
/* 1230 */       Cairo.cairo_translate(cairo, nx + xOffset, ny + yOffset);
/* 1231 */       Cairo.cairo_scale(cairo, naw2, nah2);
/* 1232 */       Cairo.cairo_move_to(cairo, fw - 1.0F, 0.0D);
/* 1233 */       Cairo.cairo_arc(cairo, fw - 1.0F, 1.0D, 1.0D, 4.71238898038469D, 6.283185307179586D);
/* 1234 */       Cairo.cairo_arc(cairo, fw - 1.0F, fh - 1.0F, 1.0D, 0.0D, 1.5707963267948966D);
/* 1235 */       Cairo.cairo_arc(cairo, 1.0D, fh - 1.0F, 1.0D, 1.5707963267948966D, 3.141592653589793D);
/* 1236 */       Cairo.cairo_arc(cairo, 1.0D, 1.0D, 1.0D, 3.141592653589793D, 4.71238898038469D);
/* 1237 */       Cairo.cairo_close_path(cairo);
/* 1238 */       Cairo.cairo_restore(cairo);
/*      */     }
/* 1240 */     Cairo.cairo_stroke(cairo);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void drawString(String string, int x, int y)
/*      */   {
/* 1262 */     if (this.handle == 0L) SWT.error(44);
/* 1263 */     if (string == null) SWT.error(4);
/* 1264 */     drawString(string, x, y, false);
/*      */   }
/*      */   
/*      */   void drawStringInPixels(String string, int x, int y) {
/* 1268 */     drawStringInPixels(string, x, y, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void drawString(String string, int x, int y, boolean isTransparent)
/*      */   {
/* 1291 */     if (this.handle == 0L) SWT.error(44);
/* 1292 */     if (string == null) SWT.error(4);
/* 1293 */     Point loc = DPIUtil.autoScaleUp(this.drawable, new Point(x, y));
/* 1294 */     drawStringInPixels(string, loc.x, loc.y, isTransparent);
/*      */   }
/*      */   
/*      */   void drawStringInPixels(String string, int x, int y, boolean isTransparent) {
/* 1298 */     drawTextInPixels(string, x, y, isTransparent ? 1 : 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void drawText(String string, int x, int y)
/*      */   {
/* 1320 */     drawText(string, x, y, 6);
/*      */   }
/*      */   
/* 1323 */   void drawTextInPixels(String string, int x, int y) { drawTextInPixels(string, x, y, 6); }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void drawText(String string, int x, int y, boolean isTransparent)
/*      */   {
/* 1347 */     Point loc = DPIUtil.autoScaleUp(this.drawable, new Point(x, y));
/* 1348 */     drawTextInPixels(string, loc.x, loc.y, isTransparent);
/*      */   }
/*      */   
/* 1351 */   void drawTextInPixels(String string, int x, int y, boolean isTransparent) { int flags = 6;
/* 1352 */     if (isTransparent) flags |= 0x1;
/* 1353 */     drawTextInPixels(string, x, y, flags);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void drawText(String string, int x, int y, int flags)
/*      */   {
/* 1391 */     Point loc = DPIUtil.autoScaleUp(this.drawable, new Point(x, y));
/* 1392 */     drawTextInPixels(string, loc.x, loc.y, flags);
/*      */   }
/*      */   
/* 1395 */   void drawTextInPixels(String string, int x, int y, int flags) { if (this.handle == 0L) SWT.error(44);
/* 1396 */     if (string == null) SWT.error(4);
/* 1397 */     if (string.length() == 0) return;
/* 1398 */     long cairo = this.data.cairo;
/* 1399 */     setString(string, flags);
/* 1400 */     checkGC(4);
/* 1401 */     if ((flags & 0x1) == 0) {
/* 1402 */       checkGC(2);
/* 1403 */       if (this.data.stringWidth == -1) {
/* 1404 */         computeStringSize();
/*      */       }
/* 1406 */       Cairo.cairo_rectangle(cairo, x, y, this.data.stringWidth, this.data.stringHeight);
/* 1407 */       Cairo.cairo_fill(cairo);
/*      */     }
/* 1409 */     checkGC(1);
/* 1410 */     if ((this.data.style & 0x8000000) != 0) {
/* 1411 */       Cairo.cairo_save(cairo);
/* 1412 */       if (this.data.stringWidth == -1) {
/* 1413 */         computeStringSize();
/*      */       }
/* 1415 */       Cairo.cairo_scale(cairo, -1.0D, 1.0D);
/* 1416 */       Cairo.cairo_translate(cairo, -2 * x - this.data.stringWidth, 0.0D);
/*      */     }
/* 1418 */     Cairo.cairo_move_to(cairo, x, y);
/* 1419 */     OS.pango_cairo_show_layout(cairo, this.data.layout);
/* 1420 */     if ((this.data.style & 0x8000000) != 0) {
/* 1421 */       Cairo.cairo_restore(cairo);
/*      */     }
/* 1423 */     Cairo.cairo_new_path(cairo);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean equals(Object object)
/*      */   {
/* 1438 */     if (object == this) return true;
/* 1439 */     if (!(object instanceof GC)) return false;
/* 1440 */     return this.handle == ((GC)object).handle;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void fillArc(int x, int y, int width, int height, int startAngle, int arcAngle)
/*      */   {
/* 1476 */     if (this.handle == 0L) SWT.error(44);
/* 1477 */     Rectangle rect = DPIUtil.autoScaleUp(this.drawable, new Rectangle(x, y, width, height));
/* 1478 */     fillArcInPixels(rect.x, rect.y, rect.width, rect.height, startAngle, arcAngle);
/*      */   }
/*      */   
/* 1481 */   void fillArcInPixels(int x, int y, int width, int height, int startAngle, int arcAngle) { checkGC(2);
/* 1482 */     if (width < 0) {
/* 1483 */       x += width;
/* 1484 */       width = -width;
/*      */     }
/* 1486 */     if (height < 0) {
/* 1487 */       y += height;
/* 1488 */       height = -height;
/*      */     }
/* 1490 */     if ((width == 0) || (height == 0) || (arcAngle == 0)) return;
/* 1491 */     long cairo = this.data.cairo;
/* 1492 */     if (width == height) {
/* 1493 */       if (arcAngle >= 0) {
/* 1494 */         Cairo.cairo_arc_negative(cairo, x + width / 2.0F, y + height / 2.0F, width / 2.0F, -startAngle * 3.1415927F / 180.0F, -(startAngle + arcAngle) * 3.1415927F / 180.0F);
/*      */       } else {
/* 1496 */         Cairo.cairo_arc(cairo, x + width / 2.0F, y + height / 2.0F, width / 2.0F, -startAngle * 3.1415927F / 180.0F, -(startAngle + arcAngle) * 3.1415927F / 180.0F);
/*      */       }
/* 1498 */       Cairo.cairo_line_to(cairo, x + width / 2.0F, y + height / 2.0F);
/*      */     } else {
/* 1500 */       Cairo.cairo_save(cairo);
/* 1501 */       Cairo.cairo_translate(cairo, x + width / 2.0F, y + height / 2.0F);
/* 1502 */       Cairo.cairo_scale(cairo, width / 2.0F, height / 2.0F);
/* 1503 */       if (arcAngle >= 0) {
/* 1504 */         Cairo.cairo_arc_negative(cairo, 0.0D, 0.0D, 1.0D, -startAngle * 3.1415927F / 180.0F, -(startAngle + arcAngle) * 3.1415927F / 180.0F);
/*      */       } else {
/* 1506 */         Cairo.cairo_arc(cairo, 0.0D, 0.0D, 1.0D, -startAngle * 3.1415927F / 180.0F, -(startAngle + arcAngle) * 3.1415927F / 180.0F);
/*      */       }
/* 1508 */       Cairo.cairo_line_to(cairo, 0.0D, 0.0D);
/* 1509 */       Cairo.cairo_restore(cairo);
/*      */     }
/* 1511 */     Cairo.cairo_fill(cairo);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void fillGradientRectangle(int x, int y, int width, int height, boolean vertical)
/*      */   {
/* 1535 */     if (this.handle == 0L) SWT.error(44);
/* 1536 */     Rectangle rect = DPIUtil.autoScaleUp(this.drawable, new Rectangle(x, y, width, height));
/* 1537 */     fillGradientRectangleInPixels(rect.x, rect.y, rect.width, rect.height, vertical);
/*      */   }
/*      */   
/*      */   void fillGradientRectangleInPixels(int x, int y, int width, int height, boolean vertical) {
/* 1541 */     if ((width == 0) || (height == 0)) { return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1546 */     RGB backgroundRGB = getBackground().getRGB();
/* 1547 */     RGB foregroundRGB = getForeground().getRGB();
/*      */     
/*      */ 
/* 1550 */     RGB fromRGB = foregroundRGB;
/* 1551 */     RGB toRGB = backgroundRGB;
/* 1552 */     boolean swapColors = false;
/* 1553 */     if (width < 0) {
/* 1554 */       x += width;width = -width;
/* 1555 */       if (!vertical) swapColors = true;
/*      */     }
/* 1557 */     if (height < 0) {
/* 1558 */       y += height;height = -height;
/* 1559 */       if (vertical) swapColors = true;
/*      */     }
/* 1561 */     if (swapColors) {
/* 1562 */       fromRGB = backgroundRGB;
/* 1563 */       toRGB = foregroundRGB;
/*      */     }
/* 1565 */     long cairo = this.data.cairo;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1573 */     long surface = Cairo.cairo_get_target(cairo);
/* 1574 */     if ((GTK.GTK3) && (surface != 0L)) {
/* 1575 */       float scaleFactor = DPIUtil.getDeviceZoom() / 100.0F;
/* 1576 */       Cairo.cairo_surface_set_device_scale(surface, scaleFactor, scaleFactor);
/*      */     }
/*      */     
/* 1579 */     if (fromRGB.equals(toRGB)) {
/* 1580 */       fillRectangleInPixels(x, y, width, height); return;
/*      */     }
/*      */     long pattern;
/*      */     long pattern;
/* 1584 */     if (vertical) {
/* 1585 */       pattern = Cairo.cairo_pattern_create_linear(0.0D, 0.0D, 0.0D, 1.0D);
/*      */     } else {
/* 1587 */       pattern = Cairo.cairo_pattern_create_linear(0.0D, 0.0D, 1.0D, 0.0D);
/*      */     }
/* 1589 */     Cairo.cairo_pattern_add_color_stop_rgba(pattern, 0.0D, fromRGB.red / 255.0F, fromRGB.green / 255.0F, fromRGB.blue / 255.0F, this.data.alpha / 255.0F);
/* 1590 */     Cairo.cairo_pattern_add_color_stop_rgba(pattern, 1.0D, toRGB.red / 255.0F, toRGB.green / 255.0F, toRGB.blue / 255.0F, this.data.alpha / 255.0F);
/* 1591 */     Cairo.cairo_save(cairo);
/* 1592 */     Cairo.cairo_translate(cairo, x, y);
/* 1593 */     Cairo.cairo_scale(cairo, width, height);
/* 1594 */     Cairo.cairo_rectangle(cairo, 0.0D, 0.0D, 1.0D, 1.0D);
/* 1595 */     Cairo.cairo_set_source(cairo, pattern);
/* 1596 */     Cairo.cairo_fill(cairo);
/* 1597 */     Cairo.cairo_restore(cairo);
/* 1598 */     Cairo.cairo_pattern_destroy(pattern);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void fillOval(int x, int y, int width, int height)
/*      */   {
/* 1618 */     if (this.handle == 0L) SWT.error(44);
/* 1619 */     Rectangle rect = DPIUtil.autoScaleUp(this.drawable, new Rectangle(x, y, width, height));
/* 1620 */     fillOvalInPixels(rect.x, rect.y, rect.width, rect.height);
/*      */   }
/*      */   
/* 1623 */   void fillOvalInPixels(int x, int y, int width, int height) { checkGC(2);
/* 1624 */     if (width < 0) {
/* 1625 */       x += width;
/* 1626 */       width = -width;
/*      */     }
/* 1628 */     if (height < 0) {
/* 1629 */       y += height;
/* 1630 */       height = -height;
/*      */     }
/* 1632 */     long cairo = this.data.cairo;
/* 1633 */     if (width == height) {
/* 1634 */       Cairo.cairo_arc_negative(cairo, x + width / 2.0F, y + height / 2.0F, width / 2.0F, 0.0D, 6.2831854820251465D);
/*      */     } else {
/* 1636 */       Cairo.cairo_save(cairo);
/* 1637 */       Cairo.cairo_translate(cairo, x + width / 2.0F, y + height / 2.0F);
/* 1638 */       Cairo.cairo_scale(cairo, width / 2.0F, height / 2.0F);
/* 1639 */       Cairo.cairo_arc_negative(cairo, 0.0D, 0.0D, 1.0D, 0.0D, 6.2831854820251465D);
/* 1640 */       Cairo.cairo_restore(cairo);
/*      */     }
/* 1642 */     Cairo.cairo_fill(cairo);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void fillPath(Path path)
/*      */   {
/* 1669 */     if (this.handle == 0L) SWT.error(44);
/* 1670 */     if (path == null) SWT.error(4);
/* 1671 */     if (path.handle == 0L) SWT.error(5);
/* 1672 */     initCairo();
/* 1673 */     checkGC(2);
/* 1674 */     long cairo = this.data.cairo;
/* 1675 */     long copy = Cairo.cairo_copy_path(path.handle);
/* 1676 */     if (copy == 0L) SWT.error(2);
/* 1677 */     Cairo.cairo_append_path(cairo, copy);
/* 1678 */     Cairo.cairo_path_destroy(copy);
/* 1679 */     Cairo.cairo_fill(cairo);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void fillPolygon(int[] pointArray)
/*      */   {
/* 1702 */     if (this.handle == 0L) SWT.error(44);
/* 1703 */     if (pointArray == null) SWT.error(4);
/* 1704 */     int[] scaledPointArray = DPIUtil.autoScaleUp(this.drawable, pointArray);
/* 1705 */     fillPolygonInPixels(scaledPointArray);
/*      */   }
/*      */   
/* 1708 */   void fillPolygonInPixels(int[] pointArray) { checkGC(2);
/* 1709 */     long cairo = this.data.cairo;
/* 1710 */     drawPolyline(cairo, pointArray, true);
/* 1711 */     Cairo.cairo_fill(cairo);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void fillRectangle(int x, int y, int width, int height)
/*      */   {
/* 1730 */     if (this.handle == 0L) SWT.error(44);
/* 1731 */     fillRectangle(new Rectangle(x, y, width, height));
/*      */   }
/*      */   
/* 1734 */   void fillRectangleInPixels(int x, int y, int width, int height) { checkGC(2);
/* 1735 */     if (width < 0) {
/* 1736 */       x += width;
/* 1737 */       width = -width;
/*      */     }
/* 1739 */     if (height < 0) {
/* 1740 */       y += height;
/* 1741 */       height = -height;
/*      */     }
/* 1743 */     long cairo = this.data.cairo;
/* 1744 */     Cairo.cairo_rectangle(cairo, x, y, width, height);
/* 1745 */     Cairo.cairo_fill(cairo);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void fillRectangle(Rectangle rect)
/*      */   {
/* 1764 */     if (this.handle == 0L) SWT.error(44);
/* 1765 */     if (rect == null) SWT.error(4);
/* 1766 */     fillRectangleInPixels(DPIUtil.autoScaleUp(this.drawable, rect));
/*      */   }
/*      */   
/* 1769 */   void fillRectangleInPixels(Rectangle rect) { fillRectangleInPixels(rect.x, rect.y, rect.width, rect.height); }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void fillRoundRectangle(int x, int y, int width, int height, int arcWidth, int arcHeight)
/*      */   {
/* 1790 */     if (this.handle == 0L) SWT.error(44);
/* 1791 */     Rectangle rect = DPIUtil.autoScaleUp(this.drawable, new Rectangle(x, y, width, height));
/* 1792 */     Point arcSize = DPIUtil.autoScaleUp(this.drawable, new Point(arcWidth, arcHeight));
/* 1793 */     fillRoundRectangleInPixels(rect.x, rect.y, rect.width, rect.height, arcSize.x, arcSize.y);
/*      */   }
/*      */   
/* 1796 */   void fillRoundRectangleInPixels(int x, int y, int width, int height, int arcWidth, int arcHeight) { checkGC(2);
/* 1797 */     int nx = x;
/* 1798 */     int ny = y;
/* 1799 */     int nw = width;
/* 1800 */     int nh = height;
/* 1801 */     int naw = arcWidth;
/* 1802 */     int nah = arcHeight;
/* 1803 */     if (nw < 0) {
/* 1804 */       nw = 0 - nw;
/* 1805 */       nx -= nw;
/*      */     }
/* 1807 */     if (nh < 0) {
/* 1808 */       nh = 0 - nh;
/* 1809 */       ny -= nh;
/*      */     }
/* 1811 */     if (naw < 0) naw = 0 - naw;
/* 1812 */     if (nah < 0) nah = 0 - nah;
/* 1813 */     long cairo = this.data.cairo;
/* 1814 */     if ((naw == 0) || (nah == 0)) {
/* 1815 */       Cairo.cairo_rectangle(cairo, x, y, width, height);
/*      */     } else {
/* 1817 */       float naw2 = naw / 2.0F;
/* 1818 */       float nah2 = nah / 2.0F;
/* 1819 */       float fw = nw / naw2;
/* 1820 */       float fh = nh / nah2;
/* 1821 */       Cairo.cairo_save(cairo);
/* 1822 */       Cairo.cairo_translate(cairo, nx, ny);
/* 1823 */       Cairo.cairo_scale(cairo, naw2, nah2);
/* 1824 */       Cairo.cairo_move_to(cairo, fw - 1.0F, 0.0D);
/* 1825 */       Cairo.cairo_arc(cairo, fw - 1.0F, 1.0D, 1.0D, 4.71238898038469D, 6.283185307179586D);
/* 1826 */       Cairo.cairo_arc(cairo, fw - 1.0F, fh - 1.0F, 1.0D, 0.0D, 1.5707963267948966D);
/* 1827 */       Cairo.cairo_arc(cairo, 1.0D, fh - 1.0F, 1.0D, 1.5707963267948966D, 3.141592653589793D);
/* 1828 */       Cairo.cairo_arc(cairo, 1.0D, 1.0D, 1.0D, 3.141592653589793D, 4.71238898038469D);
/* 1829 */       Cairo.cairo_close_path(cairo);
/* 1830 */       Cairo.cairo_restore(cairo);
/*      */     }
/* 1832 */     Cairo.cairo_fill(cairo);
/*      */   }
/*      */   
/*      */   int fixMnemonic(char[] buffer) {
/* 1836 */     int i = 0;int j = 0;
/* 1837 */     int mnemonic = -1;
/* 1838 */     while (i < buffer.length) {
/* 1839 */       if (((buffer[(j++)] = buffer[(i++)]) == '&') && 
/* 1840 */         (i != buffer.length))
/* 1841 */         if (buffer[i] == '&') { i++;
/* 1842 */         } else { if (mnemonic == -1) mnemonic = j;
/* 1843 */           j--;
/*      */         }
/*      */     }
/* 1846 */     while (j < buffer.length) buffer[(j++)] = '\000';
/* 1847 */     return mnemonic;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getAdvanceWidth(char ch)
/*      */   {
/* 1866 */     if (this.handle == 0L) { SWT.error(44);
/*      */     }
/* 1868 */     return stringExtentInPixels(new String(new char[] { ch })).x;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getAdvanced()
/*      */   {
/* 1897 */     if (this.handle == 0L) SWT.error(44);
/* 1898 */     return this.data.cairo != 0L;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getAlpha()
/*      */   {
/* 1914 */     if (this.handle == 0L) SWT.error(44);
/* 1915 */     return this.data.alpha;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getAntialias()
/*      */   {
/* 1935 */     if (this.handle == 0L) SWT.error(44);
/* 1936 */     if (this.data.cairo == 0L) return -1;
/* 1937 */     int antialias = Cairo.cairo_get_antialias(this.data.cairo);
/* 1938 */     switch (antialias) {
/* 1939 */     case 0:  return -1;
/* 1940 */     case 1:  return 0;
/*      */     case 2: case 3: 
/* 1942 */       return 1;
/*      */     }
/* 1944 */     return -1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Color getBackground()
/*      */   {
/* 1957 */     if (this.handle == 0L) SWT.error(44);
/* 1958 */     if (GTK.GTK3) {
/* 1959 */       return Color.gtk_new(this.data.device, this.data.backgroundRGBA);
/*      */     }
/* 1961 */     return Color.gtk_new(this.data.device, this.data.background);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Pattern getBackgroundPattern()
/*      */   {
/* 1980 */     if (this.handle == 0L) SWT.error(44);
/* 1981 */     return this.data.backgroundPattern;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getCharWidth(char ch)
/*      */   {
/* 2001 */     if (this.handle == 0L) { SWT.error(44);
/*      */     }
/* 2003 */     return stringExtentInPixels(new String(new char[] { ch })).x;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Rectangle getClipping()
/*      */   {
/* 2019 */     if (this.handle == 0L) SWT.error(44);
/* 2020 */     return DPIUtil.autoScaleDown(this.drawable, getClippingInPixels());
/*      */   }
/*      */   
/*      */   Rectangle getClippingInPixels() {
/* 2024 */     int x = 0;int y = 0;int width = 0;int height = 0;
/* 2025 */     int[] w = new int[1];int[] h = new int[1];
/* 2026 */     getSize(w, h);
/* 2027 */     width = w[0];
/* 2028 */     height = h[0];
/*      */     
/* 2030 */     long cairo = this.data.cairo;
/* 2031 */     long clipRgn = this.data.clipRgn;
/* 2032 */     long damageRgn = this.data.damageRgn;
/* 2033 */     if ((clipRgn != 0L) || (damageRgn != 0L) || (cairo != 0L)) {
/* 2034 */       long rgn = GDK.gdk_region_new();
/* 2035 */       GdkRectangle rect = new GdkRectangle();
/* 2036 */       rect.width = width;
/* 2037 */       rect.height = height;
/* 2038 */       GDK.gdk_region_union_with_rect(rgn, rect);
/* 2039 */       if (damageRgn != 0L) {
/* 2040 */         GDK.gdk_region_intersect(rgn, damageRgn);
/*      */       }
/*      */       
/* 2043 */       if (clipRgn != 0L)
/*      */       {
/* 2045 */         if ((this.data.clippingTransform != null) && ((GTK.GTK_VERSION < OS.VERSION(3, 14, 0)) || (!OS.CAIRO_CONTEXT_REUSE))) {
/* 2046 */           clipRgn = convertRgn(clipRgn, this.data.clippingTransform);
/* 2047 */           GDK.gdk_region_intersect(rgn, clipRgn);
/* 2048 */           GDK.gdk_region_destroy(clipRgn);
/*      */         } else {
/* 2050 */           GDK.gdk_region_intersect(rgn, clipRgn);
/*      */         }
/*      */       }
/*      */       
/* 2054 */       if ((cairo != 0L) && ((GTK.GTK_VERSION < OS.VERSION(3, 14, 0)) || (!OS.CAIRO_CONTEXT_REUSE))) {
/* 2055 */         double[] matrix = new double[6];
/* 2056 */         Cairo.cairo_get_matrix(cairo, matrix);
/* 2057 */         Cairo.cairo_matrix_invert(matrix);
/* 2058 */         clipRgn = convertRgn(rgn, matrix);
/* 2059 */         GDK.gdk_region_destroy(rgn);
/* 2060 */         rgn = clipRgn;
/*      */       }
/* 2062 */       GDK.gdk_region_get_clipbox(rgn, rect);
/* 2063 */       GDK.gdk_region_destroy(rgn);
/* 2064 */       x = rect.x;
/* 2065 */       y = rect.y;
/* 2066 */       width = rect.width;
/* 2067 */       height = rect.height;
/*      */     }
/* 2069 */     return new Rectangle(x, y, width, height);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void getClipping(Region region)
/*      */   {
/* 2087 */     if (this.handle == 0L) SWT.error(44);
/* 2088 */     if (region == null) SWT.error(4);
/* 2089 */     if (region.isDisposed()) SWT.error(5);
/* 2090 */     long clipping = region.handle;
/* 2091 */     GDK.gdk_region_subtract(clipping, clipping);
/* 2092 */     long cairo = this.data.cairo;
/* 2093 */     long clipRgn = this.data.clipRgn;
/* 2094 */     if (clipRgn == 0L) {
/* 2095 */       GdkRectangle rect = new GdkRectangle();
/* 2096 */       int[] width = new int[1];int[] height = new int[1];
/* 2097 */       getSize(width, height);
/* 2098 */       rect.width = width[0];
/* 2099 */       rect.height = height[0];
/* 2100 */       GDK.gdk_region_union_with_rect(clipping, rect);
/*      */ 
/*      */     }
/* 2103 */     else if ((this.data.clippingTransform != null) && ((GTK.GTK_VERSION < OS.VERSION(3, 14, 0)) || (!OS.CAIRO_CONTEXT_REUSE))) {
/* 2104 */       long rgn = convertRgn(clipRgn, this.data.clippingTransform);
/* 2105 */       GDK.gdk_region_union(clipping, rgn);
/* 2106 */       GDK.gdk_region_destroy(rgn);
/*      */     } else {
/* 2108 */       GDK.gdk_region_union(clipping, clipRgn);
/*      */     }
/*      */     
/* 2111 */     if (this.data.damageRgn != 0L) {
/* 2112 */       GDK.gdk_region_intersect(clipping, this.data.damageRgn);
/*      */     }
/*      */     
/* 2115 */     if ((cairo != 0L) && ((GTK.GTK_VERSION < OS.VERSION(3, 14, 0)) || (!OS.CAIRO_CONTEXT_REUSE))) {
/* 2116 */       double[] matrix = new double[6];
/* 2117 */       Cairo.cairo_get_matrix(cairo, matrix);
/* 2118 */       Cairo.cairo_matrix_invert(matrix);
/* 2119 */       long rgn = convertRgn(clipping, matrix);
/* 2120 */       GDK.gdk_region_subtract(clipping, clipping);
/* 2121 */       GDK.gdk_region_union(clipping, rgn);
/* 2122 */       GDK.gdk_region_destroy(rgn);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getFillRule()
/*      */   {
/* 2139 */     if (this.handle == 0L) SWT.error(44);
/* 2140 */     long cairo = this.data.cairo;
/* 2141 */     if (cairo == 0L) return 1;
/* 2142 */     return Cairo.cairo_get_fill_rule(cairo) == 0 ? 2 : 1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Font getFont()
/*      */   {
/* 2156 */     if (this.handle == 0L) SWT.error(44);
/* 2157 */     return this.data.font;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public FontMetrics getFontMetrics()
/*      */   {
/* 2172 */     if (this.handle == 0L) SWT.error(44);
/* 2173 */     if (this.data.context == 0L) createLayout();
/* 2174 */     checkGC(4);
/* 2175 */     Font font = this.data.font;
/* 2176 */     long context = this.data.context;
/* 2177 */     long lang = OS.pango_context_get_language(context);
/* 2178 */     long metrics = OS.pango_context_get_metrics(context, font.handle, lang);
/* 2179 */     FontMetrics fm = new FontMetrics();
/* 2180 */     int ascent = OS.pango_font_metrics_get_ascent(metrics);
/* 2181 */     int descent = OS.pango_font_metrics_get_descent(metrics);
/* 2182 */     int ascentInPoints = DPIUtil.autoScaleDown(this.drawable, OS.PANGO_PIXELS(ascent));
/* 2183 */     fm.ascentInPoints = ascentInPoints;
/* 2184 */     int heightInPoints = DPIUtil.autoScaleDown(this.drawable, OS.PANGO_PIXELS(ascent + descent));
/* 2185 */     fm.descentInPoints = (heightInPoints - ascentInPoints);
/* 2186 */     fm.averageCharWidthInPoints = DPIUtil.autoScaleDown(this.drawable, OS.PANGO_PIXELS(OS.pango_font_metrics_get_approximate_char_width(metrics)));
/* 2187 */     OS.pango_font_metrics_unref(metrics);
/* 2188 */     return fm;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Color getForeground()
/*      */   {
/* 2201 */     if (this.handle == 0L) SWT.error(24);
/* 2202 */     if (GTK.GTK3) {
/* 2203 */       return Color.gtk_new(this.data.device, this.data.foregroundRGBA);
/*      */     }
/* 2205 */     return Color.gtk_new(this.data.device, this.data.foreground);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Pattern getForegroundPattern()
/*      */   {
/* 2224 */     if (this.handle == 0L) SWT.error(44);
/* 2225 */     return this.data.foregroundPattern;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public GCData getGCData()
/*      */   {
/* 2251 */     if (this.handle == 0L) SWT.error(44);
/* 2252 */     return this.data;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getInterpolation()
/*      */   {
/* 2269 */     if (this.handle == 0L) SWT.error(44);
/* 2270 */     return this.data.interpolation;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public LineAttributes getLineAttributes()
/*      */   {
/* 2285 */     if (this.handle == 0L) SWT.error(44);
/* 2286 */     LineAttributes attributes = getLineAttributesInPixels();
/* 2287 */     attributes.width = DPIUtil.autoScaleDown(this.drawable, attributes.width);
/* 2288 */     return attributes;
/*      */   }
/*      */   
/* 2291 */   LineAttributes getLineAttributesInPixels() { float[] dashes = null;
/* 2292 */     if (this.data.lineDashes != null) {
/* 2293 */       dashes = new float[this.data.lineDashes.length];
/* 2294 */       System.arraycopy(this.data.lineDashes, 0, dashes, 0, dashes.length);
/*      */     }
/* 2296 */     return new LineAttributes(this.data.lineWidth, this.data.lineCap, this.data.lineJoin, this.data.lineStyle, dashes, this.data.lineDashesOffset, this.data.lineMiterLimit);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getLineCap()
/*      */   {
/* 2313 */     if (this.handle == 0L) SWT.error(44);
/* 2314 */     return this.data.lineCap;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int[] getLineDash()
/*      */   {
/* 2330 */     if (this.handle == 0L) SWT.error(44);
/* 2331 */     if (this.data.lineDashes == null) return null;
/* 2332 */     int[] lineDashes = new int[this.data.lineDashes.length];
/* 2333 */     for (int i = 0; i < lineDashes.length; i++) {
/* 2334 */       lineDashes[i] = ((int)this.data.lineDashes[i]);
/*      */     }
/* 2336 */     return lineDashes;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getLineJoin()
/*      */   {
/* 2353 */     if (this.handle == 0L) SWT.error(44);
/* 2354 */     return this.data.lineJoin;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getLineStyle()
/*      */   {
/* 2370 */     if (this.handle == 0L) SWT.error(44);
/* 2371 */     return this.data.lineStyle;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getLineWidth()
/*      */   {
/* 2387 */     if (this.handle == 0L) SWT.error(44);
/* 2388 */     return (int)DPIUtil.autoScaleDown(this.drawable, this.data.lineWidth);
/*      */   }
/*      */   
/* 2391 */   int getLineWidthInPixels() { return (int)this.data.lineWidth; }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getStyle()
/*      */   {
/* 2413 */     if (this.handle == 0L) SWT.error(44);
/* 2414 */     return this.data.style;
/*      */   }
/*      */   
/*      */   void getSize(int[] width, int[] height) {
/* 2418 */     if ((this.data.width != -1) && (this.data.height != -1)) {
/* 2419 */       width[0] = this.data.width;
/* 2420 */       height[0] = this.data.height;
/* 2421 */       return;
/*      */     }
/* 2423 */     if (this.data.drawable != 0L) {
/* 2424 */       width[0] = GDK.gdk_window_get_width(this.data.drawable);
/* 2425 */       height[0] = GDK.gdk_window_get_height(this.data.drawable);
/* 2426 */       return;
/*      */     }
/* 2428 */     long surface = Cairo.cairo_get_target(this.handle);
/* 2429 */     switch (Cairo.cairo_surface_get_type(surface)) {
/*      */     case 0: 
/* 2431 */       width[0] = Cairo.cairo_image_surface_get_width(surface);
/* 2432 */       height[0] = Cairo.cairo_image_surface_get_height(surface);
/* 2433 */       break;
/*      */     case 3: 
/* 2435 */       width[0] = Cairo.cairo_xlib_surface_get_width(surface);
/* 2436 */       height[0] = Cairo.cairo_xlib_surface_get_height(surface);
/*      */     }
/*      */     
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getTextAntialias()
/*      */   {
/* 2458 */     if (this.handle == 0L) SWT.error(44);
/* 2459 */     if (this.data.cairo == 0L) return -1;
/* 2460 */     int antialias = 0;
/* 2461 */     if (this.data.context != 0L) {
/* 2462 */       long options = OS.pango_cairo_context_get_font_options(this.data.context);
/* 2463 */       if (options != 0L) antialias = Cairo.cairo_font_options_get_antialias(options);
/*      */     }
/* 2465 */     switch (antialias) {
/* 2466 */     case 0:  return -1;
/* 2467 */     case 1:  return 0;
/*      */     case 2: case 3: 
/* 2469 */       return 1;
/*      */     }
/* 2471 */     return -1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void getTransform(Transform transform)
/*      */   {
/* 2493 */     if (this.handle == 0L) SWT.error(44);
/* 2494 */     if (transform == null) SWT.error(4);
/* 2495 */     if (transform.isDisposed()) SWT.error(5);
/* 2496 */     long cairo = this.data.cairo;
/* 2497 */     if (cairo != 0L)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2503 */       if ((GTK.GTK_VERSION >= OS.VERSION(3, 14, 0)) && (OS.CAIRO_CONTEXT_REUSE)) {
/* 2504 */         if (this.currentTransform != null) {
/* 2505 */           transform.handle = ((double[])this.currentTransform.clone());
/*      */         } else {
/* 2507 */           transform.handle = new double[] { 1.0D, 0.0D, 0.0D, 1.0D, 0.0D, 0.0D };
/*      */         }
/*      */       } else {
/* 2510 */         Cairo.cairo_get_matrix(cairo, transform.handle);
/* 2511 */         double[] identity = identity();
/* 2512 */         Cairo.cairo_matrix_invert(identity);
/* 2513 */         Cairo.cairo_matrix_multiply(transform.handle, transform.handle, identity);
/*      */       }
/*      */     } else {
/* 2516 */       transform.setElements(1.0F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getXORMode()
/*      */   {
/* 2535 */     if (this.handle == 0L) SWT.error(44);
/* 2536 */     return this.data.xorMode;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int hashCode()
/*      */   {
/* 2555 */     return (int)this.handle;
/*      */   }
/*      */   
/*      */   double[] identity() {
/* 2559 */     double[] identity = new double[6];
/* 2560 */     if ((this.data.style & 0x8000000) != 0) {
/* 2561 */       int[] w = new int[1];int[] h = new int[1];
/* 2562 */       getSize(w, h);
/* 2563 */       Cairo.cairo_matrix_init(identity, -1.0D, 0.0D, 0.0D, 1.0D, w[0], 0.0D);
/*      */     } else {
/* 2565 */       Cairo.cairo_matrix_init_identity(identity);
/*      */     }
/* 2567 */     if (this.data.identity != null) {
/* 2568 */       Cairo.cairo_matrix_multiply(identity, this.data.identity, identity);
/*      */     }
/* 2570 */     return identity;
/*      */   }
/*      */   
/*      */   void init(Drawable drawable, GCData data, long gdkGC) {
/* 2574 */     if (GTK.GTK3) {
/* 2575 */       if (data.foregroundRGBA != null) data.state &= 0xFFFFFFFE;
/* 2576 */       if (data.backgroundRGBA != null) data.state &= 0xFEFD;
/*      */     } else {
/* 2578 */       if (data.foreground != null) data.state &= 0xFFFFFFFE;
/* 2579 */       if (data.background != null) data.state &= 0xFEFD;
/*      */     }
/* 2581 */     if (data.font != null) data.state &= 0xFFFFFFFB;
/* 2582 */     Image image = data.image;
/* 2583 */     if (image != null) {
/* 2584 */       image.memGC = this;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2590 */       if (image.transparentPixel != -1) image.destroyMask();
/*      */     }
/* 2592 */     this.drawable = drawable;
/* 2593 */     this.data = data;
/* 2594 */     this.handle = gdkGC;
/* 2595 */     long cairo = data.cairo = this.handle;
/* 2596 */     Cairo.cairo_set_fill_rule(cairo, 1);
/* 2597 */     data.state &= 0xFD80;
/* 2598 */     setClipping(data.clipRgn);
/* 2599 */     initCairo();
/* 2600 */     if ((data.style & 0x8000000) != 0)
/*      */     {
/* 2602 */       if ((GTK.GTK_VERSION >= OS.VERSION(3, 14, 0)) && (OS.CAIRO_CONTEXT_REUSE)) {
/* 2603 */         int[] w = new int[1];int[] h = new int[1];
/* 2604 */         getSize(w, h);
/* 2605 */         Cairo.cairo_translate(cairo, w[0], 0.0D);
/* 2606 */         Cairo.cairo_scale(cairo, -1.0D, 1.0D);
/*      */       } else {
/* 2608 */         Cairo.cairo_set_matrix(data.cairo, identity());
/*      */       }
/*      */     }
/* 2611 */     if (OS.CAIRO_CONTEXT_REUSE) {
/* 2612 */       if (this.cairoTransformationMatrix == null) this.cairoTransformationMatrix = new double[6];
/* 2613 */       Cairo.cairo_get_matrix(data.cairo, this.cairoTransformationMatrix);
/* 2614 */       this.clipping = getClipping();
/*      */     }
/*      */   }
/*      */   
/*      */   void initCairo() {
/* 2619 */     long cairo = this.data.cairo;
/* 2620 */     if (cairo != 0L) return;
/* 2621 */     this.data.cairo = (cairo = GDK.gdk_cairo_create(this.data.drawable));
/* 2622 */     if (cairo == 0L) SWT.error(2);
/* 2623 */     this.data.disposeCairo = true;
/* 2624 */     Cairo.cairo_set_fill_rule(cairo, 1);
/* 2625 */     this.data.state &= 0xFD80;
/* 2626 */     setCairoClip(this.data.damageRgn, this.data.clipRgn);
/*      */   }
/*      */   
/*      */   void computeStringSize() {
/* 2630 */     int[] width = new int[1];int[] height = new int[1];
/* 2631 */     OS.pango_layout_get_pixel_size(this.data.layout, width, height);
/* 2632 */     this.data.stringHeight = height[0];
/* 2633 */     this.data.stringWidth = width[0];
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isClipped()
/*      */   {
/* 2651 */     if (this.handle == 0L) SWT.error(44);
/* 2652 */     return this.data.clipRgn != 0L;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isDisposed()
/*      */   {
/* 2667 */     return this.handle == 0L;
/*      */   }
/*      */   
/*      */   boolean isIdentity(double[] matrix) {
/* 2671 */     if (matrix == null) return true;
/* 2672 */     return (matrix[0] == 1.0D) && (matrix[1] == 0.0D) && (matrix[2] == 0.0D) && (matrix[3] == 1.0D) && (matrix[4] == 0.0D) && (matrix[5] == 0.0D);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAdvanced(boolean advanced)
/*      */   {
/* 2718 */     if (this.handle == 0L) SWT.error(44);
/* 2719 */     if (!advanced) {
/* 2720 */       setAlpha(255);
/* 2721 */       setAntialias(-1);
/* 2722 */       setBackgroundPattern(null);
/* 2723 */       resetClipping();
/* 2724 */       setForegroundPattern(null);
/* 2725 */       setInterpolation(-1);
/* 2726 */       setTextAntialias(-1);
/* 2727 */       setTransform(null);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAlpha(int alpha)
/*      */   {
/* 2752 */     if (this.handle == 0L) SWT.error(44);
/* 2753 */     if ((this.data.cairo == 0L) && ((alpha & 0xFF) == 255)) return;
/* 2754 */     initCairo();
/* 2755 */     this.data.alpha = (alpha & 0xFF);
/* 2756 */     this.data.state &= 0xFEFC;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAntialias(int antialias)
/*      */   {
/* 2788 */     if (this.handle == 0L) SWT.error(44);
/* 2789 */     if ((this.data.cairo == 0L) && (antialias == -1)) return;
/* 2790 */     int mode = 0;
/* 2791 */     switch (antialias) {
/* 2792 */     case -1:  mode = 0; break;
/* 2793 */     case 0:  mode = 1; break;
/* 2794 */     case 1:  mode = 2;
/* 2795 */       break;
/*      */     default: 
/* 2797 */       SWT.error(5);
/*      */     }
/* 2799 */     initCairo();
/* 2800 */     long cairo = this.data.cairo;
/* 2801 */     Cairo.cairo_set_antialias(cairo, mode);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBackground(Color color)
/*      */   {
/* 2820 */     if (this.handle == 0L) SWT.error(44);
/* 2821 */     if (color == null) SWT.error(4);
/* 2822 */     if (color.isDisposed()) SWT.error(5);
/* 2823 */     if (GTK.GTK3) {
/* 2824 */       this.data.backgroundRGBA = color.handleRGBA;
/*      */     } else {
/* 2826 */       this.data.background = color.handle;
/*      */     }
/* 2828 */     this.data.backgroundPattern = null;
/* 2829 */     this.data.state &= 0xFEFD;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBackgroundPattern(Pattern pattern)
/*      */   {
/* 2857 */     if (this.handle == 0L) SWT.error(44);
/* 2858 */     if ((pattern != null) && (pattern.isDisposed())) SWT.error(5);
/* 2859 */     if ((this.data.cairo == 0L) && (pattern == null)) return;
/* 2860 */     initCairo();
/* 2861 */     if (this.data.backgroundPattern == pattern) return;
/* 2862 */     this.data.backgroundPattern = pattern;
/* 2863 */     this.data.state &= 0xFFFFFFFD;
/*      */   }
/*      */   
/*      */   static void setCairoFont(long cairo, Font font) {
/* 2867 */     if ((font == null) || (font.isDisposed())) return;
/* 2868 */     setCairoFont(cairo, font.handle);
/*      */   }
/*      */   
/*      */   static void setCairoFont(long cairo, long font) {
/* 2872 */     long family = OS.pango_font_description_get_family(font);
/* 2873 */     int length = C.strlen(family);
/* 2874 */     byte[] buffer = new byte[length + 1];
/* 2875 */     C.memmove(buffer, family, length);
/*      */     
/* 2877 */     double height = OS.PANGO_PIXELS(OS.pango_font_description_get_size(font)) * 96 / 72;
/* 2878 */     int pangoStyle = OS.pango_font_description_get_style(font);
/* 2879 */     int pangoWeight = OS.pango_font_description_get_weight(font);
/* 2880 */     int slant = 0;
/* 2881 */     if (pangoStyle == 2) slant = 1;
/* 2882 */     if (pangoStyle == 1) slant = 2;
/* 2883 */     int weight = 0;
/* 2884 */     if (pangoWeight == 700) weight = 1;
/* 2885 */     Cairo.cairo_select_font_face(cairo, buffer, slant, weight);
/* 2886 */     Cairo.cairo_set_font_size(cairo, height);
/*      */   }
/*      */   
/*      */   static void setCairoRegion(long cairo, long rgn) {
/* 2890 */     GDK.gdk_cairo_region(cairo, rgn);
/*      */   }
/*      */   
/*      */   static void setCairoPatternColor(long pattern, int offset, Color c, int alpha) {
/* 2894 */     if (GTK.GTK3) {
/* 2895 */       GdkRGBA rgba = c.handleRGBA;
/* 2896 */       Cairo.cairo_pattern_add_color_stop_rgba(pattern, offset, rgba.red, rgba.green, rgba.blue, alpha / 255.0F);
/*      */     } else {
/* 2898 */       GdkColor color = c.handle;
/* 2899 */       double aa = (alpha & 0xFF) / 255.0D;
/* 2900 */       double red = (color.red & 0xFFFF) / 65535.0D;
/* 2901 */       double green = (color.green & 0xFFFF) / 65535.0D;
/* 2902 */       double blue = (color.blue & 0xFFFF) / 65535.0D;
/* 2903 */       Cairo.cairo_pattern_add_color_stop_rgba(pattern, offset, red, green, blue, aa);
/*      */     }
/*      */   }
/*      */   
/*      */   void setCairoClip(long damageRgn, long clipRgn) {
/* 2908 */     long cairo = this.data.cairo;
/* 2909 */     if ((this.data.drawable != 0L) && (!GTK.GTK3)) {
/* 2910 */       GDK.gdk_cairo_reset_clip(cairo, this.data.drawable);
/*      */     } else {
/* 2912 */       Cairo.cairo_reset_clip(cairo);
/*      */     }
/* 2914 */     if (damageRgn != 0L) {
/* 2915 */       double[] matrix = new double[6];
/* 2916 */       Cairo.cairo_get_matrix(cairo, matrix);
/* 2917 */       double[] identity = new double[6];
/* 2918 */       Cairo.cairo_matrix_init_identity(identity);
/* 2919 */       Cairo.cairo_set_matrix(cairo, identity);
/* 2920 */       setCairoRegion(cairo, damageRgn);
/* 2921 */       Cairo.cairo_clip(cairo);
/* 2922 */       Cairo.cairo_set_matrix(cairo, matrix);
/*      */     }
/* 2924 */     if (clipRgn != 0L) {
/* 2925 */       long clipRgnCopy = GDK.gdk_region_new();
/* 2926 */       GDK.gdk_region_union(clipRgnCopy, clipRgn);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2934 */       if ((GTK.GTK_VERSION >= OS.VERSION(3, 14, 0)) && (OS.CAIRO_CONTEXT_REUSE)) {
/* 2935 */         limitClipping(clipRgnCopy);
/*      */       }
/*      */       
/* 2938 */       setCairoRegion(cairo, clipRgnCopy);
/* 2939 */       Cairo.cairo_clip(cairo);
/* 2940 */       GDK.gdk_region_destroy(clipRgnCopy);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void limitClipping(long gcClipping)
/*      */   {
/* 2949 */     Region clippingRegion = new Region();
/* 2950 */     if (this.currentTransform != null)
/*      */     {
/* 2952 */       double[] invertedCurrentTransform = (double[])this.currentTransform.clone();
/* 2953 */       Cairo.cairo_matrix_invert(invertedCurrentTransform);
/* 2954 */       int[] clippingWithoutUserTransform = transformRectangle(invertedCurrentTransform, this.clipping);
/* 2955 */       clippingRegion.add(clippingWithoutUserTransform);
/* 2956 */       GDK.gdk_region_intersect(gcClipping, clippingRegion.handle);
/*      */     } else {
/* 2958 */       clippingRegion.add(this.clipping);
/*      */     }
/* 2960 */     GDK.gdk_region_intersect(gcClipping, clippingRegion.handle);
/* 2961 */     clippingRegion.dispose();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static int[] transformRectangle(double[] affineTransformation, Rectangle rectangle)
/*      */   {
/* 2970 */     Point[] endPoints = { new Point(rectangle.x, rectangle.y), new Point(rectangle.x + rectangle.width, rectangle.y), new Point(rectangle.x + rectangle.width, rectangle.y + rectangle.height), new Point(rectangle.x, rectangle.y + rectangle.height) };
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2976 */     return transformPoints(affineTransformation, endPoints);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static int[] transformPoints(double[] transformation, Point[] points)
/*      */   {
/* 2985 */     int[] transformedPoints = new int[points.length * 2];
/* 2986 */     double[] px = new double[1];double[] py = new double[1];
/* 2987 */     for (int i = 0; i < points.length; i++) {
/* 2988 */       px[0] = points[i].x;
/* 2989 */       py[0] = points[i].y;
/* 2990 */       Cairo.cairo_matrix_transform_point(transformation, px, py);
/* 2991 */       transformedPoints[(i * 2 + 0)] = ((int)Math.round(px[0]));
/* 2992 */       transformedPoints[(i * 2 + 1)] = ((int)Math.round(py[0]));
/*      */     }
/* 2994 */     return transformedPoints;
/*      */   }
/*      */   
/*      */   void setClipping(long clipRgn) {
/* 2998 */     long cairo = this.data.cairo;
/* 2999 */     if (clipRgn == 0L) {
/* 3000 */       if (this.data.clipRgn != 0L) {
/* 3001 */         GDK.gdk_region_destroy(this.data.clipRgn);
/* 3002 */         this.data.clipRgn = 0L;
/*      */       }
/* 3004 */       this.data.clippingTransform = null;
/* 3005 */       setCairoClip(this.data.damageRgn, 0L);
/*      */     } else {
/* 3007 */       if (this.data.clipRgn == 0L) this.data.clipRgn = GDK.gdk_region_new();
/* 3008 */       GDK.gdk_region_subtract(this.data.clipRgn, this.data.clipRgn);
/* 3009 */       GDK.gdk_region_union(this.data.clipRgn, clipRgn);
/* 3010 */       if ((GTK.GTK_VERSION < OS.VERSION(3, 14, 0)) || (!OS.CAIRO_CONTEXT_REUSE)) {
/* 3011 */         if (this.data.clippingTransform == null) this.data.clippingTransform = new double[6];
/* 3012 */         Cairo.cairo_get_matrix(cairo, this.data.clippingTransform);
/*      */       }
/* 3014 */       setCairoClip(this.data.damageRgn, clipRgn);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setClipping(int x, int y, int width, int height)
/*      */   {
/* 3033 */     if (this.handle == 0L) SWT.error(44);
/* 3034 */     setClippingInPixels(DPIUtil.autoScaleUp(this.drawable, x), DPIUtil.autoScaleUp(this.drawable, y), DPIUtil.autoScaleUp(this.drawable, width), DPIUtil.autoScaleUp(this.drawable, height));
/*      */   }
/*      */   
/* 3037 */   void setClippingInPixels(int x, int y, int width, int height) { if (width < 0) {
/* 3038 */       x += width;
/* 3039 */       width = -width;
/*      */     }
/* 3041 */     if (height < 0) {
/* 3042 */       y += height;
/* 3043 */       height = -height;
/*      */     }
/* 3045 */     GdkRectangle rect = new GdkRectangle();
/* 3046 */     rect.x = x;
/* 3047 */     rect.y = y;
/* 3048 */     rect.width = width;
/* 3049 */     rect.height = height;
/* 3050 */     long clipRgn = GDK.gdk_region_new();
/* 3051 */     GDK.gdk_region_union_with_rect(clipRgn, rect);
/* 3052 */     setClipping(clipRgn);
/* 3053 */     GDK.gdk_region_destroy(clipRgn);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setClipping(Path path)
/*      */   {
/* 3083 */     if (this.handle == 0L) SWT.error(44);
/* 3084 */     if ((path != null) && (path.isDisposed())) SWT.error(44);
/* 3085 */     resetClipping();
/* 3086 */     if (path != null) {
/* 3087 */       initCairo();
/* 3088 */       long cairo = this.data.cairo;
/* 3089 */       long copy = Cairo.cairo_copy_path(path.handle);
/* 3090 */       if (copy == 0L) SWT.error(2);
/* 3091 */       Cairo.cairo_append_path(cairo, copy);
/* 3092 */       Cairo.cairo_path_destroy(copy);
/* 3093 */       Cairo.cairo_clip(cairo);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setClipping(Rectangle rect)
/*      */   {
/* 3111 */     if (this.handle == 0L) SWT.error(44);
/* 3112 */     setClippingInPixels(DPIUtil.autoScaleUp(this.drawable, rect));
/*      */   }
/*      */   
/* 3115 */   void setClippingInPixels(Rectangle rect) { if ((GTK.GTK_VERSION >= OS.VERSION(3, 9, 0)) && (((this.drawable instanceof Tree)) || ((this.drawable instanceof Table)))) {
/* 3116 */       return;
/*      */     }
/* 3118 */     if (rect == null) {
/* 3119 */       resetClipping();
/*      */     } else {
/* 3121 */       setClippingInPixels(rect.x, rect.y, rect.width, rect.height);
/*      */     }
/*      */   }
/*      */   
/*      */   private void resetClipping() {
/* 3126 */     if ((GTK.GTK_VERSION >= OS.VERSION(3, 14, 0)) && (OS.CAIRO_CONTEXT_REUSE))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3133 */       setClipping(this.clipping);
/*      */     } else {
/* 3135 */       setClipping(0L);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setClipping(Region region)
/*      */   {
/* 3156 */     if (this.handle == 0L) SWT.error(44);
/* 3157 */     if ((region != null) && (region.isDisposed())) SWT.error(5);
/* 3158 */     if (region != null) {
/* 3159 */       setClipping(region.handle);
/*      */     } else {
/* 3161 */       resetClipping();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setFont(Font font)
/*      */   {
/* 3181 */     if (this.handle == 0L) SWT.error(44);
/* 3182 */     if ((font != null) && (font.isDisposed())) SWT.error(5);
/* 3183 */     this.data.font = (font != null ? font : this.data.device.systemFont);
/* 3184 */     this.data.state &= 0xFFFFFFFB;
/* 3185 */     this.data.stringWidth = (this.data.stringHeight = -1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setFillRule(int rule)
/*      */   {
/* 3205 */     if (this.handle == 0L) SWT.error(44);
/* 3206 */     int cairo_mode = 1;
/* 3207 */     switch (rule) {
/*      */     case 2: 
/* 3209 */       cairo_mode = 0; break;
/*      */     case 1: 
/* 3211 */       cairo_mode = 1; break;
/*      */     default: 
/* 3213 */       SWT.error(5);
/*      */     }
/* 3215 */     initCairo();
/* 3216 */     Cairo.cairo_set_fill_rule(this.data.cairo, cairo_mode);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setForeground(Color color)
/*      */   {
/* 3234 */     if (this.handle == 0L) SWT.error(44);
/* 3235 */     if (color == null) SWT.error(4);
/* 3236 */     if (color.isDisposed()) SWT.error(5);
/* 3237 */     if (GTK.GTK3) {
/* 3238 */       this.data.foregroundRGBA = color.handleRGBA;
/*      */     } else {
/* 3240 */       this.data.foreground = color.handle;
/*      */     }
/* 3242 */     this.data.foregroundPattern = null;
/* 3243 */     this.data.state &= 0xFFFFFFFE;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setForegroundPattern(Pattern pattern)
/*      */   {
/* 3270 */     if (this.handle == 0L) SWT.error(44);
/* 3271 */     if ((pattern != null) && (pattern.isDisposed())) SWT.error(5);
/* 3272 */     if ((this.data.cairo == 0L) && (pattern == null)) return;
/* 3273 */     initCairo();
/* 3274 */     if (this.data.foregroundPattern == pattern) return;
/* 3275 */     this.data.foregroundPattern = pattern;
/* 3276 */     this.data.state &= 0xFFFFFFFE;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setInterpolation(int interpolation)
/*      */   {
/* 3306 */     if (this.handle == 0L) SWT.error(44);
/* 3307 */     if ((this.data.cairo == 0L) && (interpolation == -1)) return;
/* 3308 */     switch (interpolation) {
/*      */     case -1: 
/*      */     case 0: 
/*      */     case 1: 
/*      */     case 2: 
/*      */       break;
/*      */     default: 
/* 3315 */       SWT.error(5);
/*      */     }
/* 3317 */     initCairo();
/* 3318 */     this.data.interpolation = interpolation;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setLineAttributes(LineAttributes attributes)
/*      */   {
/* 3346 */     if (this.handle == 0L) SWT.error(44);
/* 3347 */     if (attributes == null) SWT.error(4);
/* 3348 */     attributes.width = DPIUtil.autoScaleUp(this.drawable, attributes.width);
/* 3349 */     setLineAttributesInPixels(attributes);
/*      */   }
/*      */   
/* 3352 */   void setLineAttributesInPixels(LineAttributes attributes) { int mask = 0;
/* 3353 */     float lineWidth = attributes.width;
/* 3354 */     if (lineWidth != this.data.lineWidth) {
/* 3355 */       mask |= 0x240;
/*      */     }
/* 3357 */     int lineStyle = attributes.style;
/* 3358 */     if (lineStyle != this.data.lineStyle) {
/* 3359 */       mask |= 0x8;
/* 3360 */       switch (lineStyle) {
/*      */       case 1: 
/*      */       case 2: 
/*      */       case 3: 
/*      */       case 4: 
/*      */       case 5: 
/*      */         break;
/*      */       case 6: 
/* 3368 */         if (attributes.dash == null) lineStyle = 1;
/*      */         break;
/*      */       default: 
/* 3371 */         SWT.error(5);
/*      */       }
/*      */     }
/* 3374 */     int join = attributes.join;
/* 3375 */     if (join != this.data.lineJoin) {
/* 3376 */       mask |= 0x20;
/* 3377 */       switch (join) {
/*      */       case 1: 
/*      */       case 2: 
/*      */       case 3: 
/*      */         break;
/*      */       default: 
/* 3383 */         SWT.error(5);
/*      */       }
/*      */     }
/* 3386 */     int cap = attributes.cap;
/* 3387 */     if (cap != this.data.lineCap) {
/* 3388 */       mask |= 0x10;
/* 3389 */       switch (cap) {
/*      */       case 1: 
/*      */       case 2: 
/*      */       case 3: 
/*      */         break;
/*      */       default: 
/* 3395 */         SWT.error(5);
/*      */       }
/*      */     }
/* 3398 */     float[] dashes = attributes.dash;
/* 3399 */     float[] lineDashes = this.data.lineDashes;
/* 3400 */     if ((dashes != null) && (dashes.length > 0)) {
/* 3401 */       boolean changed = (lineDashes == null) || (lineDashes.length != dashes.length);
/* 3402 */       for (int i = 0; i < dashes.length; i++) {
/* 3403 */         float dash = dashes[i];
/* 3404 */         if (dash <= 0.0F) SWT.error(5);
/* 3405 */         if ((!changed) && (lineDashes[i] != dash)) changed = true;
/*      */       }
/* 3407 */       if (changed) {
/* 3408 */         float[] newDashes = new float[dashes.length];
/* 3409 */         System.arraycopy(dashes, 0, newDashes, 0, dashes.length);
/* 3410 */         dashes = newDashes;
/* 3411 */         mask |= 0x8;
/*      */       } else {
/* 3413 */         dashes = lineDashes;
/*      */       }
/*      */     }
/* 3416 */     else if ((lineDashes != null) && (lineDashes.length > 0)) {
/* 3417 */       mask |= 0x8;
/*      */     } else {
/* 3419 */       dashes = lineDashes;
/*      */     }
/*      */     
/* 3422 */     float dashOffset = attributes.dashOffset;
/* 3423 */     if (dashOffset != this.data.lineDashesOffset) {
/* 3424 */       mask |= 0x8;
/*      */     }
/* 3426 */     float miterLimit = attributes.miterLimit;
/* 3427 */     if (miterLimit != this.data.lineMiterLimit) {
/* 3428 */       mask |= 0x80;
/*      */     }
/* 3430 */     initCairo();
/* 3431 */     if (mask == 0) return;
/* 3432 */     this.data.lineWidth = lineWidth;
/* 3433 */     this.data.lineStyle = lineStyle;
/* 3434 */     this.data.lineCap = cap;
/* 3435 */     this.data.lineJoin = join;
/* 3436 */     this.data.lineDashes = dashes;
/* 3437 */     this.data.lineDashesOffset = dashOffset;
/* 3438 */     this.data.lineMiterLimit = miterLimit;
/* 3439 */     this.data.state &= (mask ^ 0xFFFFFFFF);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setLineCap(int cap)
/*      */   {
/* 3459 */     if (this.handle == 0L) SWT.error(44);
/* 3460 */     if (this.data.lineCap == cap) return;
/* 3461 */     switch (cap) {
/*      */     case 1: 
/*      */     case 2: 
/*      */     case 3: 
/*      */       break;
/*      */     default: 
/* 3467 */       SWT.error(5);
/*      */     }
/* 3469 */     this.data.lineCap = cap;
/* 3470 */     this.data.state &= 0xFFFFFFEF;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setLineDash(int[] dashes)
/*      */   {
/* 3491 */     if (this.handle == 0L) SWT.error(44);
/* 3492 */     float[] lineDashes = this.data.lineDashes;
/* 3493 */     if ((dashes != null) && (dashes.length > 0)) {
/* 3494 */       boolean changed = (this.data.lineStyle != 6) || (lineDashes == null) || (lineDashes.length != dashes.length);
/* 3495 */       for (int i = 0; i < dashes.length; i++) {
/* 3496 */         int dash = dashes[i];
/* 3497 */         if (dash <= 0) SWT.error(5);
/* 3498 */         if ((!changed) && (lineDashes[i] != dash)) changed = true;
/*      */       }
/* 3500 */       if (!changed) return;
/* 3501 */       this.data.lineDashes = new float[dashes.length];
/* 3502 */       for (int i = 0; i < dashes.length; i++) {
/* 3503 */         this.data.lineDashes[i] = dashes[i];
/*      */       }
/* 3505 */       this.data.lineStyle = 6;
/*      */     } else {
/* 3507 */       if ((this.data.lineStyle == 1) && ((lineDashes == null) || (lineDashes.length == 0))) return;
/* 3508 */       this.data.lineDashes = null;
/* 3509 */       this.data.lineStyle = 1;
/*      */     }
/* 3511 */     this.data.state &= 0xFFFFFFF7;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setLineJoin(int join)
/*      */   {
/* 3531 */     if (this.handle == 0L) SWT.error(44);
/* 3532 */     if (this.data.lineJoin == join) return;
/* 3533 */     switch (join) {
/*      */     case 1: 
/*      */     case 2: 
/*      */     case 3: 
/*      */       break;
/*      */     default: 
/* 3539 */       SWT.error(5);
/*      */     }
/* 3541 */     this.data.lineJoin = join;
/* 3542 */     this.data.state &= 0xFFFFFFDF;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setLineStyle(int lineStyle)
/*      */   {
/* 3561 */     if (this.handle == 0L) SWT.error(44);
/* 3562 */     if (this.data.lineStyle == lineStyle) return;
/* 3563 */     switch (lineStyle) {
/*      */     case 1: 
/*      */     case 2: 
/*      */     case 3: 
/*      */     case 4: 
/*      */     case 5: 
/*      */       break;
/*      */     case 6: 
/* 3571 */       if (this.data.lineDashes == null) lineStyle = 1;
/*      */       break;
/*      */     default: 
/* 3574 */       SWT.error(5);
/*      */     }
/* 3576 */     this.data.lineStyle = lineStyle;
/* 3577 */     this.data.state &= 0xFFFFFFF7;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setLineWidth(int lineWidth)
/*      */   {
/* 3601 */     if (this.handle == 0L) SWT.error(44);
/* 3602 */     setLineWidthInPixels(DPIUtil.autoScaleUp(this.drawable, lineWidth));
/*      */   }
/*      */   
/* 3605 */   void setLineWidthInPixels(int lineWidth) { if (this.data.lineWidth == lineWidth) return;
/* 3606 */     this.data.lineWidth = lineWidth;
/* 3607 */     this.data.state &= 0xFDBF;
/*      */   }
/*      */   
/*      */   void setString(String string, int flags) {
/* 3611 */     if (this.data.layout == 0L) createLayout();
/* 3612 */     if ((string == this.data.string) && ((flags & 0xFFFFFFFE) == (this.data.drawFlags & 0xFFFFFFFE))) {
/* 3613 */       return;
/*      */     }
/*      */     
/* 3616 */     int length = string.length();
/* 3617 */     long layout = this.data.layout;
/* 3618 */     char[] text = new char[length];
/* 3619 */     string.getChars(0, length, text, 0);
/* 3620 */     int mnemonic; byte[] buffer; if (((flags & 0x8) != 0) && ((mnemonic = fixMnemonic(text)) != -1)) {
/* 3621 */       char[] text1 = new char[mnemonic - 1];
/* 3622 */       System.arraycopy(text, 0, text1, 0, text1.length);
/* 3623 */       byte[] buffer1 = Converter.wcsToMbcs(text1, false);
/* 3624 */       char[] text2 = new char[text.length - mnemonic];
/* 3625 */       System.arraycopy(text, mnemonic - 1, text2, 0, text2.length);
/* 3626 */       byte[] buffer2 = Converter.wcsToMbcs(text2, false);
/* 3627 */       byte[] buffer = new byte[buffer1.length + buffer2.length];
/* 3628 */       System.arraycopy(buffer1, 0, buffer, 0, buffer1.length);
/* 3629 */       System.arraycopy(buffer2, 0, buffer, buffer1.length, buffer2.length);
/* 3630 */       long attr_list = OS.pango_attr_list_new();
/* 3631 */       long attr = OS.pango_attr_underline_new(3);
/* 3632 */       PangoAttribute attribute = new PangoAttribute();
/* 3633 */       OS.memmove(attribute, attr, PangoAttribute.sizeof);
/* 3634 */       attribute.start_index = buffer1.length;
/* 3635 */       attribute.end_index = (buffer1.length + 1);
/* 3636 */       OS.memmove(attr, attribute, PangoAttribute.sizeof);
/* 3637 */       OS.pango_attr_list_insert(attr_list, attr);
/* 3638 */       OS.pango_layout_set_attributes(layout, attr_list);
/* 3639 */       OS.pango_attr_list_unref(attr_list);
/*      */     } else {
/* 3641 */       buffer = Converter.wcsToMbcs(text, false);
/* 3642 */       OS.pango_layout_set_attributes(layout, 0L);
/*      */     }
/* 3644 */     OS.pango_layout_set_text(layout, buffer, buffer.length);
/* 3645 */     OS.pango_layout_set_single_paragraph_mode(layout, (flags & 0x2) == 0);
/* 3646 */     OS.pango_layout_set_tabs(layout, (flags & 0x4) != 0 ? 0L : this.data.device.emptyTab);
/* 3647 */     this.data.string = string;
/* 3648 */     this.data.stringWidth = (this.data.stringHeight = -1);
/* 3649 */     this.data.drawFlags = flags;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTextAntialias(int antialias)
/*      */   {
/* 3681 */     if (this.handle == 0L) SWT.error(44);
/* 3682 */     if ((this.data.cairo == 0L) && (antialias == -1)) return;
/* 3683 */     int mode = 0;
/* 3684 */     switch (antialias) {
/* 3685 */     case -1:  mode = 0; break;
/* 3686 */     case 0:  mode = 1; break;
/* 3687 */     case 1:  mode = 2;
/* 3688 */       break;
/*      */     default: 
/* 3690 */       SWT.error(5);
/*      */     }
/* 3692 */     initCairo();
/* 3693 */     long options = Cairo.cairo_font_options_create();
/* 3694 */     Cairo.cairo_font_options_set_antialias(options, mode);
/* 3695 */     if (this.data.context == 0L) createLayout();
/* 3696 */     OS.pango_cairo_context_set_font_options(this.data.context, options);
/* 3697 */     Cairo.cairo_font_options_destroy(options);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTransform(Transform transform)
/*      */   {
/* 3727 */     if (this.handle == 0L) SWT.error(44);
/* 3728 */     if ((transform != null) && (transform.isDisposed())) SWT.error(5);
/* 3729 */     if ((this.data.cairo == 0L) && (transform == null)) return;
/* 3730 */     initCairo();
/* 3731 */     long cairo = this.data.cairo;
/* 3732 */     if ((GTK.GTK_VERSION >= OS.VERSION(3, 14, 0)) && (OS.CAIRO_CONTEXT_REUSE))
/*      */     {
/* 3734 */       if (this.currentTransform != null) {
/* 3735 */         Cairo.cairo_set_matrix(cairo, this.cairoTransformationMatrix);
/* 3736 */         this.currentTransform = null;
/*      */       }
/*      */       
/* 3739 */       if (transform != null) {
/* 3740 */         this.currentTransform = ((double[])transform.handle.clone());
/* 3741 */         double[] transformMatrix = identity();
/* 3742 */         Cairo.cairo_matrix_multiply(transformMatrix, transform.handle, transformMatrix);
/* 3743 */         Cairo.cairo_transform(cairo, transformMatrix);
/*      */       }
/*      */     } else {
/* 3746 */       double[] identity = identity();
/* 3747 */       if (transform != null) {
/* 3748 */         Cairo.cairo_matrix_multiply(identity, transform.handle, identity);
/*      */       }
/* 3750 */       Cairo.cairo_set_matrix(cairo, identity);
/*      */     }
/* 3752 */     this.data.state &= 0xFDFF;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public void setXORMode(boolean xor)
/*      */   {
/* 3778 */     if (this.handle == 0L) SWT.error(44);
/* 3779 */     if (Cairo.cairo_version() >= Cairo.CAIRO_VERSION_ENCODE(1, 10, 0)) {
/* 3780 */       Cairo.cairo_set_operator(this.handle, xor ? 23 : 2);
/*      */     }
/* 3782 */     this.data.xorMode = xor;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Point stringExtent(String string)
/*      */   {
/* 3804 */     return DPIUtil.autoScaleDown(this.drawable, stringExtentInPixels(string));
/*      */   }
/*      */   
/* 3807 */   Point stringExtentInPixels(String string) { return textExtentInPixels(string, 0); }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Point textExtent(String string)
/*      */   {
/* 3830 */     return DPIUtil.autoScaleDown(this.drawable, textExtentInPixels(string));
/*      */   }
/*      */   
/*      */   Point textExtentInPixels(String string) {
/* 3834 */     return textExtentInPixels(string, 6);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Point textExtent(String string, int flags)
/*      */   {
/* 3869 */     if (this.handle == 0L) SWT.error(44);
/* 3870 */     if (string == null) SWT.error(4);
/* 3871 */     return DPIUtil.autoScaleDown(this.drawable, textExtentInPixels(string, flags));
/*      */   }
/*      */   
/* 3874 */   Point textExtentInPixels(String string, int flags) { setString(string, flags);
/* 3875 */     checkGC(4);
/* 3876 */     if (this.data.stringWidth == -1) {
/* 3877 */       computeStringSize();
/*      */     }
/* 3879 */     return new Point(this.data.stringWidth, this.data.stringHeight);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String toString()
/*      */   {
/* 3890 */     if (isDisposed()) return "GC {*DISPOSED*}";
/* 3891 */     return "GC {" + this.handle + "}";
/*      */   }
/*      */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/graphics/GC.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */