/*    */ package org.eclipse.swt.events;
/*    */ 
/*    */ import java.util.function.Consumer;
/*    */ import org.eclipse.swt.internal.SWTEventListener;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract interface KeyListener
/*    */   extends SWTEventListener
/*    */ {
/*    */   public abstract void keyPressed(KeyEvent paramKeyEvent);
/*    */   
/*    */   public abstract void keyReleased(KeyEvent paramKeyEvent);
/*    */   
/*    */   public static KeyListener keyPressedAdapter(Consumer<KeyEvent> c)
/*    */   {
/* 60 */     new KeyAdapter()
/*    */     {
/*    */       public void keyPressed(KeyEvent e) {
/* 63 */         this.val$c.accept(e);
/*    */       }
/*    */     };
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static KeyListener keyReleasedAdapter(Consumer<KeyEvent> c)
/*    */   {
/* 77 */     new KeyAdapter()
/*    */     {
/*    */       public void keyReleased(KeyEvent e) {
/* 80 */         this.val$c.accept(e);
/*    */       }
/*    */     };
/*    */   }
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/events/KeyListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */