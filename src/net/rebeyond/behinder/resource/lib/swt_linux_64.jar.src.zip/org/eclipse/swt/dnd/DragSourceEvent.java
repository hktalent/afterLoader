/*     */ package org.eclipse.swt.dnd;
/*     */ 
/*     */ import org.eclipse.swt.events.TypedEvent;
/*     */ import org.eclipse.swt.graphics.Image;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DragSourceEvent
/*     */   extends TypedEvent
/*     */ {
/*     */   public int detail;
/*     */   public boolean doit;
/*     */   public int x;
/*     */   public int y;
/*     */   public TransferData dataType;
/*     */   public Image image;
/*     */   public int offsetX;
/*     */   public int offsetY;
/*     */   static final long serialVersionUID = 3257002142513770808L;
/*     */   
/*     */   public DragSourceEvent(DNDEvent e)
/*     */   {
/* 103 */     super(e);
/* 104 */     this.data = e.data;
/* 105 */     this.detail = e.detail;
/* 106 */     this.doit = e.doit;
/* 107 */     this.dataType = e.dataType;
/* 108 */     this.x = e.x;
/* 109 */     this.y = e.y;
/* 110 */     this.image = e.image;
/* 111 */     this.offsetX = e.offsetX;
/* 112 */     this.offsetY = e.offsetY;
/*     */   }
/*     */   
/* 115 */   void updateEvent(DNDEvent e) { e.widget = this.widget;
/* 116 */     e.time = this.time;
/* 117 */     e.data = this.data;
/* 118 */     e.detail = this.detail;
/* 119 */     e.doit = this.doit;
/* 120 */     e.dataType = this.dataType;
/* 121 */     e.x = this.x;
/* 122 */     e.y = this.y;
/* 123 */     e.image = this.image;
/* 124 */     e.offsetX = this.offsetX;
/* 125 */     e.offsetY = this.offsetY;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 135 */     String string = super.toString();
/* 136 */     return string.substring(0, string.length() - 1) + " operation=" + this.detail + " type=" + (this.dataType != null ? this.dataType.type : 0L) + " doit=" + this.doit + "}";
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/dnd/DragSourceEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */