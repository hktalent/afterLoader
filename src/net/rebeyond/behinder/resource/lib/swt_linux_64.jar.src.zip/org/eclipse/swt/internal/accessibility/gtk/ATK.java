/*     */ package org.eclipse.swt.internal.accessibility.gtk;
/*     */ 
/*     */ import org.eclipse.swt.internal.Lock;
/*     */ 
/*     */ public class ATK extends org.eclipse.swt.internal.gtk.OS {
/*     */   public static final int ATK_RELATION_NULL = 0;
/*     */   public static final int ATK_RELATION_CONTROLLED_BY = 1;
/*     */   public static final int ATK_RELATION_CONTROLLER_FOR = 2;
/*     */   public static final int ATK_RELATION_LABEL_FOR = 3;
/*     */   public static final int ATK_RELATION_LABELLED_BY = 4;
/*     */   public static final int ATK_RELATION_MEMBER_OF = 5;
/*     */   public static final int ATK_RELATION_NODE_CHILD_OF = 6;
/*     */   public static final int ATK_RELATION_FLOWS_TO = 7;
/*     */   public static final int ATK_RELATION_FLOWS_FROM = 8;
/*     */   public static final int ATK_RELATION_SUBWINDOW_OF = 9;
/*     */   public static final int ATK_RELATION_EMBEDS = 10;
/*     */   public static final int ATK_RELATION_EMBEDDED_BY = 11;
/*     */   public static final int ATK_RELATION_POPUP_FOR = 12;
/*     */   public static final int ATK_RELATION_PARENT_WINDOW_OF = 13;
/*     */   public static final int ATK_RELATION_DESCRIBED_BY = 14;
/*     */   public static final int ATK_RELATION_DESCRIPTION_FOR = 15;
/*     */   
/*  23 */   static { org.eclipse.swt.internal.Library.loadLibrary("swt-atk"); }
/*     */   
/*     */ 
/*     */   public static final int ATK_ROLE_ALERT = 2;
/*     */   
/*     */   public static final int ATK_ROLE_ANIMATION = 3;
/*     */   
/*     */   public static final int ATK_ROLE_CALENDAR = 4;
/*     */   
/*     */   public static final int ATK_ROLE_CANVAS = 6;
/*     */   
/*     */   public static final int ATK_ROLE_CHECK_BOX = 7;
/*     */   
/*     */   public static final int ATK_ROLE_CHECK_MENU_ITEM = 8;
/*     */   
/*     */   public static final int ATK_ROLE_COMBO_BOX = 11;
/*     */   
/*     */   public static final int ATK_ROLE_DATE_EDITOR = 12;
/*     */   
/*     */   public static final int ATK_ROLE_DIALOG = 16;
/*     */   
/*     */   public static final int ATK_ROLE_DRAWING_AREA = 18;
/*     */   
/*     */   public static final int ATK_ROLE_WINDOW = 68;
/*     */   
/*     */   public static final int ATK_ROLE_LABEL = 28;
/*     */   
/*     */   public static final int ATK_ROLE_LIST = 30;
/*     */   
/*     */   public static final int ATK_ROLE_LIST_ITEM = 31;
/*     */   
/*     */   public static final int ATK_ROLE_MENU = 32;
/*     */   
/*     */   public static final int ATK_ROLE_MENU_BAR = 33;
/*     */   
/*     */   public static final int ATK_ROLE_MENU_ITEM = 34;
/*     */   
/*     */   public static final int ATK_ROLE_PAGE_TAB = 36;
/*     */   
/*     */   public static final int ATK_ROLE_PAGE_TAB_LIST = 37;
/*     */   
/*     */   public static final int ATK_ROLE_PANEL = 38;
/*     */   
/*     */   public static final int ATK_ROLE_PROGRESS_BAR = 41;
/*     */   
/*     */   public static final int ATK_ROLE_PUSH_BUTTON = 42;
/*     */   
/*     */   public static final int ATK_ROLE_RADIO_BUTTON = 43;
/*     */   public static final int ATK_ROLE_RADIO_MENU_ITEM = 44;
/*     */   public static final int ATK_ROLE_SCROLL_BAR = 47;
/*     */   public static final int ATK_ROLE_SEPARATOR = 49;
/*     */   public static final int ATK_ROLE_SLIDER = 50;
/*     */   public static final int ATK_ROLE_SPIN_BUTTON = 52;
/*     */   public static final int ATK_ROLE_STATUSBAR = 53;
/*     */   public static final int ATK_ROLE_TABLE = 54;
/*     */   public static final int ATK_ROLE_TABLE_CELL = 55;
/*     */   public static final int ATK_ROLE_TABLE_COLUMN_HEADER = 56;
/*     */   public static final int ATK_ROLE_TABLE_ROW_HEADER = 57;
/*     */   public static final int ATK_ROLE_TEXT = 60;
/*     */   public static final int ATK_ROLE_TOOL_BAR = 62;
/*     */   public static final int ATK_ROLE_TOOL_TIP = 63;
/*     */   public static final int ATK_ROLE_TREE = 64;
/*     */   public static final int ATK_ROLE_HEADER = 69;
/*     */   public static final int ATK_ROLE_FOOTER = 70;
/*     */   public static final int ATK_ROLE_PARAGRAPH = 71;
/*     */   public static final int ATK_ROLE_FORM = 85;
/*     */   public static final int ATK_ROLE_HEADING = 81;
/*     */   public static final int ATK_ROLE_DOCUMENT_FRAME = 80;
/*     */   public static final int ATK_ROLE_TABLE_ROW = 88;
/*     */   public static final int ATK_ROLE_IMAGE = 26;
/*     */   public static final int ATK_ROLE_PAGE = 82;
/*     */   public static final int ATK_ROLE_SECTION = 83;
/*     */   public static final int ATK_ROLE_UNKNOWN = 66;
/*     */   public static final int ATK_STATE_ACTIVE = 1;
/*     */   public static final int ATK_STATE_ARMED = 2;
/*     */   public static final int ATK_STATE_BUSY = 3;
/*     */   public static final int ATK_STATE_CHECKED = 4;
/*     */   public static final int ATK_STATE_DEFUNCT = 5;
/*     */   public static final int ATK_STATE_EDITABLE = 6;
/*     */   public static final int ATK_STATE_ENABLED = 7;
/*     */   public static final int ATK_STATE_EXPANDED = 9;
/*     */   public static final int ATK_STATE_FOCUSABLE = 10;
/*     */   public static final int ATK_STATE_FOCUSED = 11;
/*     */   public static final int ATK_STATE_MULTI_LINE = 15;
/*     */   public static final int ATK_STATE_MULTISELECTABLE = 16;
/*     */   public static final int ATK_STATE_PRESSED = 18;
/*     */   public static final int ATK_STATE_RESIZABLE = 19;
/*     */   public static final int ATK_STATE_SELECTABLE = 20;
/*     */   public static final int ATK_STATE_SELECTED = 21;
/*     */   public static final int ATK_STATE_SHOWING = 23;
/*     */   public static final int ATK_STATE_SINGLE_LINE = 24;
/*     */   public static final int ATK_STATE_TRANSIENT = 26;
/*     */   public static final int ATK_STATE_REQUIRED = 32;
/*     */   public static final int ATK_STATE_INVALID_ENTRY = 33;
/*     */   public static final int ATK_STATE_SUPPORTS_AUTOCOMPLETION = 34;
/*     */   public static final int ATK_STATE_VISIBLE = 28;
/*     */   public static final int ATK_TEXT_BOUNDARY_CHAR = 0;
/*     */   public static final int ATK_TEXT_BOUNDARY_WORD_START = 1;
/*     */   public static final int ATK_TEXT_BOUNDARY_WORD_END = 2;
/*     */   public static final int ATK_TEXT_BOUNDARY_SENTENCE_START = 3;
/*     */   public static final int ATK_TEXT_BOUNDARY_SENTENCE_END = 4;
/*     */   public static final int ATK_TEXT_BOUNDARY_LINE_START = 5;
/*     */   public static final int ATK_TEXT_BOUNDARY_LINE_END = 6;
/*     */   public static final int ATK_TEXT_GRANULARITY_CHAR = 0;
/*     */   public static final int ATK_TEXT_GRANULARITY_WORD = 1;
/*     */   public static final int ATK_TEXT_GRANULARITY_SENTENCE = 2;
/*     */   public static final int ATK_TEXT_GRANULARITY_LINE = 3;
/*     */   public static final int ATK_TEXT_GRANULARITY_PARAGRAPH = 4;
/*     */   public static final int ATK_TEXT_CLIP_NONE = 0;
/*     */   public static final int ATK_TEXT_CLIP_MIN = 1;
/*     */   public static final int ATK_TEXT_CLIP_MAX = 2;
/*     */   public static final int ATK_TEXT_CLIP_BOTH = 3;
/*     */   public static final int ATK_TEXT_ATTR_LEFT_MARGIN = 1;
/*     */   public static final int ATK_TEXT_ATTR_RIGHT_MARGIN = 2;
/*     */   public static final int ATK_TEXT_ATTR_INDENT = 3;
/*     */   public static final int ATK_TEXT_ATTR_INVISIBLE = 4;
/*     */   public static final int ATK_TEXT_ATTR_EDITABLE = 5;
/*     */   public static final int ATK_TEXT_ATTR_PIXELS_ABOVE_LINES = 6;
/*     */   public static final int ATK_TEXT_ATTR_PIXELS_BELOW_LINES = 7;
/*     */   public static final int ATK_TEXT_ATTR_PIXELS_INSIDE_WRAP = 8;
/*     */   public static final int ATK_TEXT_ATTR_BG_FULL_HEIGHT = 9;
/*     */   public static final int ATK_TEXT_ATTR_RISE = 10;
/*     */   public static final int ATK_TEXT_ATTR_UNDERLINE = 11;
/*     */   public static final int ATK_TEXT_ATTR_STRIKETHROUGH = 12;
/*     */   public static final int ATK_TEXT_ATTR_SIZE = 13;
/*     */   public static final int ATK_TEXT_ATTR_SCALE = 14;
/*     */   public static final int ATK_TEXT_ATTR_WEIGHT = 15;
/*     */   public static final int ATK_TEXT_ATTR_LANGUAGE = 16;
/*     */   public static final int ATK_TEXT_ATTR_FAMILY_NAME = 17;
/*     */   public static final int ATK_TEXT_ATTR_BG_COLOR = 18;
/*     */   public static final int ATK_TEXT_ATTR_FG_COLOR = 19;
/*     */   public static final int ATK_TEXT_ATTR_BG_STIPPLE = 20;
/*     */   public static final int ATK_TEXT_ATTR_FG_STIPPLE = 21;
/*     */   public static final int ATK_TEXT_ATTR_WRAP_MODE = 22;
/*     */   public static final int ATK__TEXT_ATTR_DIRECTION = 23;
/*     */   public static final int ATK_TEXT_ATTR_JUSTIFICATION = 24;
/*     */   public static final int ATK_TEXT_ATTR_STRETCH = 25;
/*     */   public static final int ATK_TEXT_ATTR_VARIANT = 26;
/*     */   public static final int ATK_TEXT_ATTR_STYLE = 27;
/*     */   public static final int ATK_XY_WINDOW = 1;
/* 163 */   public static final byte[] selection_changed = org.eclipse.swt.internal.gtk.OS.ascii("selection_changed");
/* 164 */   public static final byte[] active_descendant_changed = org.eclipse.swt.internal.gtk.OS.ascii("active_descendant_changed");
/* 165 */   public static final byte[] text_changed_insert = org.eclipse.swt.internal.gtk.OS.ascii("text_changed::insert");
/* 166 */   public static final byte[] text_changed_delete = org.eclipse.swt.internal.gtk.OS.ascii("text_changed::delete");
/* 167 */   public static final byte[] text_caret_moved = org.eclipse.swt.internal.gtk.OS.ascii("text_caret_moved");
/* 168 */   public static final byte[] text_selection_changed = org.eclipse.swt.internal.gtk.OS.ascii("text_selection_changed");
/* 169 */   public static final byte[] load_complete = org.eclipse.swt.internal.gtk.OS.ascii("load-complete");
/* 170 */   public static final byte[] load_stopped = org.eclipse.swt.internal.gtk.OS.ascii("load-stopped");
/* 171 */   public static final byte[] reload = org.eclipse.swt.internal.gtk.OS.ascii("reload");
/* 172 */   public static final byte[] state_change = org.eclipse.swt.internal.gtk.OS.ascii("state-change");
/* 173 */   public static final byte[] bounds_changed = org.eclipse.swt.internal.gtk.OS.ascii("bounds-changed");
/* 174 */   public static final byte[] link_activated = org.eclipse.swt.internal.gtk.OS.ascii("link-activated");
/* 175 */   public static final byte[] link_selected = org.eclipse.swt.internal.gtk.OS.ascii("link-selected");
/* 176 */   public static final byte[] attributes_changed = org.eclipse.swt.internal.gtk.OS.ascii("attributes-changed");
/* 177 */   public static final byte[] text_attributes_changed = org.eclipse.swt.internal.gtk.OS.ascii("text-attributes-changed");
/* 178 */   public static final byte[] column_deleted = org.eclipse.swt.internal.gtk.OS.ascii("column-deleted");
/* 179 */   public static final byte[] column_inserted = org.eclipse.swt.internal.gtk.OS.ascii("column-inserted");
/* 180 */   public static final byte[] row_deleted = org.eclipse.swt.internal.gtk.OS.ascii("row-deleted");
/* 181 */   public static final byte[] row_inserted = org.eclipse.swt.internal.gtk.OS.ascii("row-inserted");
/* 182 */   public static final byte[] focus_event = org.eclipse.swt.internal.gtk.OS.ascii("focus-event");
/*     */   
/*     */ 
/* 185 */   public static final byte[] accessible_name = org.eclipse.swt.internal.gtk.OS.ascii("accessible-name");
/* 186 */   public static final byte[] accessible_description = org.eclipse.swt.internal.gtk.OS.ascii("accessible-description");
/* 187 */   public static final byte[] accessible_value = org.eclipse.swt.internal.gtk.OS.ascii("accessible-value");
/* 188 */   public static final byte[] end_index = org.eclipse.swt.internal.gtk.OS.ascii("end-index");
/* 189 */   public static final byte[] number_of_anchors = org.eclipse.swt.internal.gtk.OS.ascii("number-of-anchors");
/* 190 */   public static final byte[] selected_link = org.eclipse.swt.internal.gtk.OS.ascii("selected-link");
/* 191 */   public static final byte[] start_index = org.eclipse.swt.internal.gtk.OS.ascii("start-index");
/* 192 */   public static final byte[] accessible_hypertext_nlinks = org.eclipse.swt.internal.gtk.OS.ascii("accessible-hypertext-nlinks");
/* 193 */   public static final byte[] accessible_table_caption_object = org.eclipse.swt.internal.gtk.OS.ascii("accessible-table-caption-object");
/* 194 */   public static final byte[] accessible_table_column_description = org.eclipse.swt.internal.gtk.OS.ascii("accessible-table-column-description");
/* 195 */   public static final byte[] accessible_table_column_header = org.eclipse.swt.internal.gtk.OS.ascii("accessible-table-column-header");
/* 196 */   public static final byte[] accessible_table_row_description = org.eclipse.swt.internal.gtk.OS.ascii("accessible-table-row-description");
/* 197 */   public static final byte[] accessible_table_row_header = org.eclipse.swt.internal.gtk.OS.ascii("accessible-table-row-header");
/* 198 */   public static final byte[] accessible_table_summary = org.eclipse.swt.internal.gtk.OS.ascii("accessible-table-summary");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final long ATK_ACTION_GET_IFACE(long obj)
/*     */   {
/* 230 */     lock.lock();
/*     */     try {
/* 232 */       return _ATK_ACTION_GET_IFACE(obj);
/*     */     } finally {
/* 234 */       lock.unlock();
/*     */     }
/*     */   }
/*     */   
/*     */   public static final long ATK_COMPONENT_GET_IFACE(long atkHandle) {
/* 239 */     lock.lock();
/*     */     try {
/* 241 */       return _ATK_COMPONENT_GET_IFACE(atkHandle);
/*     */     } finally {
/* 243 */       lock.unlock();
/*     */     }
/*     */   }
/*     */   
/*     */   public static final long ATK_SELECTION_GET_IFACE(long obj)
/*     */   {
/* 249 */     lock.lock();
/*     */     try {
/* 251 */       return _ATK_SELECTION_GET_IFACE(obj);
/*     */     } finally {
/* 253 */       lock.unlock();
/*     */     }
/*     */   }
/*     */   
/*     */   public static final long ATK_EDITABLE_TEXT_GET_IFACE(long handle) {
/* 258 */     lock.lock();
/*     */     try {
/* 260 */       return _ATK_EDITABLE_TEXT_GET_IFACE(handle);
/*     */     } finally {
/* 262 */       lock.unlock();
/*     */     }
/*     */   }
/*     */   
/*     */   public static final long ATK_HYPERTEXT_GET_IFACE(long handle) {
/* 267 */     lock.lock();
/*     */     try {
/* 269 */       return _ATK_HYPERTEXT_GET_IFACE(handle);
/*     */     } finally {
/* 271 */       lock.unlock();
/*     */     }
/*     */   }
/*     */   
/*     */   public static final long ATK_TABLE_GET_IFACE(long handle) {
/* 276 */     lock.lock();
/*     */     try {
/* 278 */       return _ATK_TABLE_GET_IFACE(handle);
/*     */     } finally {
/* 280 */       lock.unlock();
/*     */     }
/*     */   }
/*     */   
/*     */   public static final long ATK_TEXT_GET_IFACE(long handle) {
/* 285 */     lock.lock();
/*     */     try {
/* 287 */       return _ATK_TEXT_GET_IFACE(handle);
/*     */     } finally {
/* 289 */       lock.unlock();
/*     */     }
/*     */   }
/*     */   
/*     */   public static final long ATK_VALUE_GET_IFACE(long handle) {
/* 294 */     lock.lock();
/*     */     try {
/* 296 */       return _ATK_VALUE_GET_IFACE(handle);
/*     */     } finally {
/* 298 */       lock.unlock();
/*     */     }
/*     */   }
/*     */   
/*     */   public static final long atk_get_default_registry() {
/* 303 */     lock.lock();
/*     */     try {
/* 305 */       return _atk_get_default_registry();
/*     */     } finally {
/* 307 */       lock.unlock();
/*     */     }
/*     */   }
/*     */   
/*     */   public static final long atk_object_factory_get_accessible_type(long factory)
/*     */   {
/* 313 */     lock.lock();
/*     */     try {
/* 315 */       return _atk_object_factory_get_accessible_type(factory);
/*     */     } finally {
/* 317 */       lock.unlock();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final void atk_object_initialize(long accessible, long data)
/*     */   {
/* 326 */     lock.lock();
/*     */     try {
/* 328 */       _atk_object_initialize(accessible, data);
/*     */     } finally {
/* 330 */       lock.unlock();
/*     */     }
/*     */   }
/*     */   
/*     */   public static final void atk_object_notify_state_change(long accessible, int state, boolean value)
/*     */   {
/* 336 */     lock.lock();
/*     */     try {
/* 338 */       _atk_object_notify_state_change(accessible, state, value);
/*     */     } finally {
/* 340 */       lock.unlock();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final boolean atk_object_add_relationship(long object, int relationship, long target)
/*     */   {
/* 350 */     lock.lock();
/*     */     try {
/* 352 */       return _atk_object_add_relationship(object, relationship, target);
/*     */     } finally {
/* 354 */       lock.unlock();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final boolean atk_object_remove_relationship(long object, int relationship, long target)
/*     */   {
/* 364 */     lock.lock();
/*     */     try {
/* 366 */       return _atk_object_remove_relationship(object, relationship, target);
/*     */     } finally {
/* 368 */       lock.unlock();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int atk_role_register(byte[] name)
/*     */   {
/* 377 */     lock.lock();
/*     */     try {
/* 379 */       return _atk_role_register(name);
/*     */     } finally {
/* 381 */       lock.unlock();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final long atk_registry_get_factory(long registry, long type)
/*     */   {
/* 390 */     lock.lock();
/*     */     try {
/* 392 */       return _atk_registry_get_factory(registry, type);
/*     */     } finally {
/* 394 */       lock.unlock();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final void atk_registry_set_factory_type(long registry, long type, long factory_type)
/*     */   {
/* 404 */     lock.lock();
/*     */     try {
/* 406 */       _atk_registry_set_factory_type(registry, type, factory_type);
/*     */     } finally {
/* 408 */       lock.unlock();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final boolean atk_state_set_add_state(long set, int type)
/*     */   {
/* 417 */     lock.lock();
/*     */     try {
/* 419 */       return _atk_state_set_add_state(set, type);
/*     */     } finally {
/* 421 */       lock.unlock();
/*     */     }
/*     */   }
/*     */   
/*     */   public static final long atk_text_attribute_get_name(int attr) {
/* 426 */     lock.lock();
/*     */     try {
/* 428 */       return _atk_text_attribute_get_name(attr);
/*     */     } finally {
/* 430 */       lock.unlock();
/*     */     }
/*     */   }
/*     */   
/*     */   public static final long atk_text_attribute_get_value(int attr, int index) {
/* 435 */     lock.lock();
/*     */     try {
/* 437 */       return _atk_text_attribute_get_value(attr, index);
/*     */     } finally {
/* 439 */       lock.unlock();
/*     */     }
/*     */   }
/*     */   
/*     */   public static final long call(long function, long arg0) {
/* 444 */     lock.lock();
/*     */     try {
/* 446 */       return _call(function, arg0);
/*     */     } finally {
/* 448 */       lock.unlock();
/*     */     }
/*     */   }
/*     */   
/*     */   public static final long call(long function, long arg0, long arg1) {
/* 453 */     lock.lock();
/*     */     try {
/* 455 */       return _call(function, arg0, arg1);
/*     */     } finally {
/* 457 */       lock.unlock();
/*     */     }
/*     */   }
/*     */   
/*     */   public static final long call(long function, long arg0, long arg1, long arg2) {
/* 462 */     lock.lock();
/*     */     try {
/* 464 */       return _call(function, arg0, arg1, arg2);
/*     */     } finally {
/* 466 */       lock.unlock();
/*     */     }
/*     */   }
/*     */   
/*     */   public static final long call(long function, long arg0, long arg1, long arg2, long arg3, long arg4) {
/* 471 */     lock.lock();
/*     */     try {
/* 473 */       return _call(function, arg0, arg1, arg2, arg3, arg4);
/*     */     } finally {
/* 475 */       lock.unlock();
/*     */     }
/*     */   }
/*     */   
/*     */   public static final native int AtkObjectFactory_sizeof();
/*     */   
/*     */   public static final native int AtkObjectFactoryClass_sizeof();
/*     */   
/*     */   public static final native int AtkAttribute_sizeof();
/*     */   
/*     */   public static final native int AtkTextRange_sizeof();
/*     */   
/*     */   public static final native int AtkTextRectangle_sizeof();
/*     */   
/*     */   public static final native long ATK_TYPE_ACTION();
/*     */   
/*     */   public static final native long ATK_TYPE_COMPONENT();
/*     */   
/*     */   public static final native long ATK_TYPE_EDITABLE_TEXT();
/*     */   
/*     */   public static final native long ATK_TYPE_HYPERTEXT();
/*     */   
/*     */   public static final native long ATK_TYPE_SELECTION();
/*     */   
/*     */   public static final native long ATK_TYPE_TABLE();
/*     */   
/*     */   public static final native long ATK_TYPE_TEXT();
/*     */   
/*     */   public static final native long ATK_TYPE_VALUE();
/*     */   
/*     */   public static final native long ATK_TYPE_OBJECT_FACTORY();
/*     */   
/*     */   public static final native boolean ATK_IS_NO_OP_OBJECT_FACTORY(long paramLong);
/*     */   
/*     */   public static final native long _ATK_ACTION_GET_IFACE(long paramLong);
/*     */   
/*     */   public static final native long _ATK_COMPONENT_GET_IFACE(long paramLong);
/*     */   
/*     */   public static final native long _ATK_OBJECT_FACTORY_CLASS(long paramLong);
/*     */   
/*     */   public static final native long _ATK_SELECTION_GET_IFACE(long paramLong);
/*     */   
/*     */   public static final native long _ATK_EDITABLE_TEXT_GET_IFACE(long paramLong);
/*     */   
/*     */   public static final native long _ATK_HYPERTEXT_GET_IFACE(long paramLong);
/*     */   
/*     */   public static final native long _ATK_TABLE_GET_IFACE(long paramLong);
/*     */   
/*     */   public static final native long _ATK_TEXT_GET_IFACE(long paramLong);
/*     */   
/*     */   public static final native long _ATK_VALUE_GET_IFACE(long paramLong);
/*     */   
/*     */   public static final native long _atk_get_default_registry();
/*     */   
/*     */   public static final native long _atk_object_factory_get_accessible_type(long paramLong);
/*     */   
/*     */   public static final native void _atk_object_initialize(long paramLong1, long paramLong2);
/*     */   
/*     */   public static final native void _atk_object_notify_state_change(long paramLong, int paramInt, boolean paramBoolean);
/*     */   
/*     */   public static final native boolean _atk_object_add_relationship(long paramLong1, int paramInt, long paramLong2);
/*     */   
/*     */   public static final native boolean _atk_object_remove_relationship(long paramLong1, int paramInt, long paramLong2);
/*     */   
/*     */   public static final native int _atk_role_register(byte[] paramArrayOfByte);
/*     */   
/*     */   public static final native long _atk_registry_get_factory(long paramLong1, long paramLong2);
/*     */   
/*     */   public static final native void _atk_registry_set_factory_type(long paramLong1, long paramLong2, long paramLong3);
/*     */   
/*     */   public static final native boolean _atk_state_set_add_state(long paramLong, int paramInt);
/*     */   
/*     */   public static final native long _atk_text_attribute_get_name(int paramInt);
/*     */   
/*     */   public static final native long _atk_text_attribute_get_value(int paramInt1, int paramInt2);
/*     */   
/*     */   public static final native long _call(long paramLong1, long paramLong2);
/*     */   
/*     */   public static final native long _call(long paramLong1, long paramLong2, long paramLong3);
/*     */   
/*     */   public static final native long _call(long paramLong1, long paramLong2, long paramLong3, long paramLong4);
/*     */   
/*     */   public static final native long _call(long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5, long paramLong6);
/*     */   
/*     */   public static final native void memmove(AtkActionIface paramAtkActionIface, long paramLong);
/*     */   
/*     */   public static final native void memmove(AtkComponentIface paramAtkComponentIface, long paramLong);
/*     */   
/*     */   public static final native void memmove(AtkEditableTextIface paramAtkEditableTextIface, long paramLong);
/*     */   
/*     */   public static final native void memmove(AtkHypertextIface paramAtkHypertextIface, long paramLong);
/*     */   
/*     */   public static final native void memmove(AtkObjectClass paramAtkObjectClass, long paramLong);
/*     */   
/*     */   public static final native void memmove(AtkObjectFactoryClass paramAtkObjectFactoryClass, long paramLong);
/*     */   
/*     */   public static final native void memmove(AtkSelectionIface paramAtkSelectionIface, long paramLong);
/*     */   
/*     */   public static final native void memmove(AtkTableIface paramAtkTableIface, long paramLong);
/*     */   
/*     */   public static final native void memmove(AtkTextIface paramAtkTextIface, long paramLong);
/*     */   
/*     */   public static final native void memmove(AtkValueIface paramAtkValueIface, long paramLong);
/*     */   
/*     */   public static final native void memmove(long paramLong, AtkActionIface paramAtkActionIface);
/*     */   
/*     */   public static final native void memmove(long paramLong, AtkComponentIface paramAtkComponentIface);
/*     */   
/*     */   public static final native void memmove(long paramLong, AtkEditableTextIface paramAtkEditableTextIface);
/*     */   
/*     */   public static final native void memmove(long paramLong, AtkHypertextIface paramAtkHypertextIface);
/*     */   
/*     */   public static final native void memmove(long paramLong, AtkObjectClass paramAtkObjectClass);
/*     */   
/*     */   public static final native void memmove(long paramLong, AtkObjectFactoryClass paramAtkObjectFactoryClass);
/*     */   
/*     */   public static final native void memmove(long paramLong, AtkSelectionIface paramAtkSelectionIface);
/*     */   
/*     */   public static final native void memmove(long paramLong, AtkTableIface paramAtkTableIface);
/*     */   
/*     */   public static final native void memmove(long paramLong, AtkTextIface paramAtkTextIface);
/*     */   
/*     */   public static final native void memmove(long paramLong, AtkValueIface paramAtkValueIface);
/*     */   
/*     */   public static final native void memmove(long paramLong, AtkTextRectangle paramAtkTextRectangle, int paramInt);
/*     */   
/*     */   public static final native void memmove(AtkTextRectangle paramAtkTextRectangle, long paramLong, int paramInt);
/*     */   
/*     */   public static final native void memmove(long paramLong, AtkTextRange paramAtkTextRange, int paramInt);
/*     */   
/*     */   public static final native void memmove(AtkTextRange paramAtkTextRange, long paramLong, int paramInt);
/*     */   
/*     */   public static final native void memmove(long paramLong, AtkAttribute paramAtkAttribute, int paramInt);
/*     */   
/*     */   public static final native void memmove(AtkAttribute paramAtkAttribute, long paramLong, int paramInt);
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/internal/accessibility/gtk/ATK.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */