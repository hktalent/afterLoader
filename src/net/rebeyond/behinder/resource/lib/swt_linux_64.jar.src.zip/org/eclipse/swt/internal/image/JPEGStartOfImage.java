/*    */ package org.eclipse.swt.internal.image;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class JPEGStartOfImage
/*    */   extends JPEGFixedSizeSegment
/*    */ {
/*    */   public JPEGStartOfImage() {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public JPEGStartOfImage(byte[] reference)
/*    */   {
/* 21 */     super(reference);
/*    */   }
/*    */   
/*    */   public JPEGStartOfImage(LEDataInputStream byteStream) {
/* 25 */     super(byteStream);
/*    */   }
/*    */   
/*    */   public int signature()
/*    */   {
/* 30 */     return 65496;
/*    */   }
/*    */   
/*    */   public int fixedSize()
/*    */   {
/* 35 */     return 2;
/*    */   }
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/internal/image/JPEGStartOfImage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */