/*    */ package org.eclipse.swt.events;
/*    */ 
/*    */ import org.eclipse.swt.widgets.Event;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ShellEvent
/*    */   extends TypedEvent
/*    */ {
/*    */   public boolean doit;
/*    */   static final long serialVersionUID = 3257569490479888441L;
/*    */   
/*    */   public ShellEvent(Event e)
/*    */   {
/* 41 */     super(e);
/* 42 */     this.doit = e.doit;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String toString()
/*    */   {
/* 53 */     String string = super.toString();
/* 54 */     return string.substring(0, string.length() - 1) + " doit=" + this.doit + "}";
/*    */   }
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/events/ShellEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */