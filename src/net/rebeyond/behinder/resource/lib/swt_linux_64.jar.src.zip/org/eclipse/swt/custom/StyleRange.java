/*     */ package org.eclipse.swt.custom;
/*     */ 
/*     */ import org.eclipse.swt.graphics.Color;
/*     */ import org.eclipse.swt.graphics.GlyphMetrics;
/*     */ import org.eclipse.swt.graphics.TextStyle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StyleRange
/*     */   extends TextStyle
/*     */   implements Cloneable
/*     */ {
/*     */   public int start;
/*     */   public int length;
/*  47 */   public int fontStyle = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public StyleRange() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public StyleRange(TextStyle style)
/*     */   {
/*  65 */     super(style);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public StyleRange(int start, int length, Color foreground, Color background)
/*     */   {
/*  77 */     super(null, foreground, background);
/*  78 */     this.start = start;
/*  79 */     this.length = length;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public StyleRange(int start, int length, Color foreground, Color background, int fontStyle)
/*     */   {
/*  92 */     this(start, length, foreground, background);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object object)
/*     */   {
/* 108 */     if (object == this) return true;
/* 109 */     if ((object instanceof StyleRange)) {
/* 110 */       StyleRange style = (StyleRange)object;
/* 111 */       if (this.start != style.start) return false;
/* 112 */       if (this.length != style.length) return false;
/* 113 */       return similarTo(style);
/*     */     }
/* 115 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 130 */     return super.hashCode() ^ this.fontStyle;
/*     */   }
/*     */   
/* 133 */   boolean isVariableHeight() { return (this.font != null) || ((this.metrics != null) && ((this.metrics.ascent != 0) || (this.metrics.descent != 0))) || (this.rise != 0); }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isUnstyled()
/*     */   {
/* 142 */     if (this.font != null) return false;
/* 143 */     if (this.rise != 0) return false;
/* 144 */     if (this.metrics != null) return false;
/* 145 */     if (this.foreground != null) return false;
/* 146 */     if (this.background != null) return false;
/* 147 */     if (this.fontStyle != 0) return false;
/* 148 */     if (this.underline) return false;
/* 149 */     if (this.strikeout) return false;
/* 150 */     if (this.borderStyle != 0) return false;
/* 151 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean similarTo(StyleRange style)
/*     */   {
/* 163 */     if (!super.equals(style)) return false;
/* 164 */     if (this.fontStyle != style.fontStyle) return false;
/* 165 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object clone()
/*     */   {
/*     */     try
/*     */     {
/* 176 */       return super.clone();
/*     */     } catch (CloneNotSupportedException e) {}
/* 178 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 190 */     StringBuilder buffer = new StringBuilder();
/* 191 */     buffer.append("StyleRange {");
/* 192 */     buffer.append(this.start);
/* 193 */     buffer.append(", ");
/* 194 */     buffer.append(this.length);
/* 195 */     buffer.append(", fontStyle=");
/* 196 */     switch (this.fontStyle) {
/*     */     case 1: 
/* 198 */       buffer.append("bold");
/* 199 */       break;
/*     */     case 2: 
/* 201 */       buffer.append("italic");
/* 202 */       break;
/*     */     case 3: 
/* 204 */       buffer.append("bold-italic");
/* 205 */       break;
/*     */     default: 
/* 207 */       buffer.append("normal");
/*     */     }
/* 209 */     String str = super.toString();
/* 210 */     int index = str.indexOf('{');
/* 211 */     str = str.substring(index + 1);
/* 212 */     if (str.length() > 1) buffer.append(", ");
/* 213 */     buffer.append(str);
/* 214 */     return buffer.toString();
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/custom/StyleRange.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */