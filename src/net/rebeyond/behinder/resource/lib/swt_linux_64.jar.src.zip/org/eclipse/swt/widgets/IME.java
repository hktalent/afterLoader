/*     */ package org.eclipse.swt.widgets;
/*     */ 
/*     */ import org.eclipse.swt.graphics.Color;
/*     */ import org.eclipse.swt.graphics.TextStyle;
/*     */ import org.eclipse.swt.internal.C;
/*     */ import org.eclipse.swt.internal.Converter;
/*     */ import org.eclipse.swt.internal.gtk.GTK;
/*     */ import org.eclipse.swt.internal.gtk.GdkColor;
/*     */ import org.eclipse.swt.internal.gtk.GdkRGBA;
/*     */ import org.eclipse.swt.internal.gtk.OS;
/*     */ import org.eclipse.swt.internal.gtk.PangoAttrColor;
/*     */ import org.eclipse.swt.internal.gtk.PangoAttrInt;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IME
/*     */   extends Widget
/*     */ {
/*     */   Canvas parent;
/*     */   int caretOffset;
/*     */   int startOffset;
/*     */   int commitCount;
/*     */   String text;
/*     */   int[] ranges;
/*     */   TextStyle[] styles;
/*     */   boolean inComposition;
/*     */   
/*     */   IME() {}
/*     */   
/*     */   public IME(Canvas parent, int style)
/*     */   {
/*  85 */     super(parent, style);
/*  86 */     this.parent = parent;
/*  87 */     createWidget();
/*     */   }
/*     */   
/*     */   void createWidget() {
/*  91 */     this.text = "";
/*  92 */     this.startOffset = -1;
/*  93 */     if (this.parent.getIME() == null) {
/*  94 */       this.parent.setIME(this);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getCaretOffset()
/*     */   {
/* 110 */     checkWidget();
/* 111 */     return this.startOffset + this.caretOffset;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getCommitCount()
/*     */   {
/* 130 */     checkWidget();
/* 131 */     return this.commitCount;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getCompositionOffset()
/*     */   {
/* 148 */     checkWidget();
/* 149 */     return this.startOffset;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int[] getRanges()
/*     */   {
/* 171 */     checkWidget();
/* 172 */     if (this.ranges == null) return new int[0];
/* 173 */     int[] result = new int[this.ranges.length];
/* 174 */     for (int i = 0; i < result.length; i++) {
/* 175 */       result[i] = (this.ranges[i] + this.startOffset);
/*     */     }
/* 177 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TextStyle[] getStyles()
/*     */   {
/* 199 */     checkWidget();
/* 200 */     if (this.styles == null) return new TextStyle[0];
/* 201 */     TextStyle[] result = new TextStyle[this.styles.length];
/* 202 */     System.arraycopy(this.styles, 0, result, 0, this.styles.length);
/* 203 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getText()
/*     */   {
/* 223 */     checkWidget();
/* 224 */     return this.text;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getWideCaret()
/*     */   {
/* 241 */     checkWidget();
/* 242 */     return false;
/*     */   }
/*     */   
/*     */   long gtk_button_press_event(long widget, long event)
/*     */   {
/* 247 */     if (!isInlineEnabled()) return 0L;
/* 248 */     long imHandle = imHandle();
/* 249 */     if (imHandle != 0L) GTK.gtk_im_context_reset(imHandle);
/* 250 */     return 0L;
/*     */   }
/*     */   
/*     */   long gtk_commit(long imcontext, long textPtr)
/*     */   {
/* 255 */     if (!isInlineEnabled()) return 0L;
/* 256 */     boolean doit = true;
/* 257 */     this.ranges = null;
/* 258 */     this.styles = null;
/* 259 */     this.caretOffset = (this.commitCount = 0);
/* 260 */     if ((textPtr != 0L) && (this.inComposition)) {
/* 261 */       int length = C.strlen(textPtr);
/* 262 */       if (length != 0) {
/* 263 */         byte[] buffer = new byte[length];
/* 264 */         C.memmove(buffer, textPtr, length);
/* 265 */         char[] chars = Converter.mbcsToWcs(buffer);
/* 266 */         Event event = new Event();
/* 267 */         event.detail = 1;
/* 268 */         event.start = this.startOffset;
/* 269 */         event.end = (this.startOffset + this.text.length());
/* 270 */         event.text = (this.text = chars != null ? new String(chars) : "");
/* 271 */         this.commitCount = this.text.length();
/* 272 */         sendEvent(43, event);
/* 273 */         doit = event.doit;
/* 274 */         this.text = "";
/* 275 */         this.startOffset = -1;
/* 276 */         this.commitCount = 0;
/*     */       }
/*     */     }
/* 279 */     this.inComposition = false;
/* 280 */     return doit ? 0L : 1L;
/*     */   }
/*     */   
/*     */   long gtk_preedit_changed(long imcontext)
/*     */   {
/* 285 */     if (!isInlineEnabled()) return 0L;
/* 286 */     this.ranges = null;
/* 287 */     this.styles = null;
/* 288 */     this.commitCount = 0;
/* 289 */     long imHandle = imHandle();
/* 290 */     long[] preeditString = new long[1];
/* 291 */     long[] pangoAttrs = new long[1];
/* 292 */     int[] cursorPos = new int[1];
/* 293 */     GTK.gtk_im_context_get_preedit_string(imHandle, preeditString, pangoAttrs, cursorPos);
/* 294 */     this.caretOffset = cursorPos[0];
/* 295 */     char[] chars = null;
/* 296 */     if (preeditString[0] != 0L) {
/* 297 */       int length = C.strlen(preeditString[0]);
/* 298 */       byte[] buffer = new byte[length];
/* 299 */       C.memmove(buffer, preeditString[0], length);
/* 300 */       chars = Converter.mbcsToWcs(buffer);
/* 301 */       if (pangoAttrs[0] != 0L) {
/* 302 */         int count = 0;
/* 303 */         long iterator = OS.pango_attr_list_get_iterator(pangoAttrs[0]);
/* 304 */         while (OS.pango_attr_iterator_next(iterator)) count++;
/* 305 */         OS.pango_attr_iterator_destroy(iterator);
/* 306 */         this.ranges = new int[count * 2];
/* 307 */         this.styles = new TextStyle[count];
/* 308 */         iterator = OS.pango_attr_list_get_iterator(pangoAttrs[0]);
/* 309 */         PangoAttrColor attrColor = new PangoAttrColor();
/* 310 */         PangoAttrInt attrInt = new PangoAttrInt();
/* 311 */         int[] start = new int[1];
/* 312 */         int[] end = new int[1];
/* 313 */         for (int i = 0; i < count; i++) {
/* 314 */           OS.pango_attr_iterator_range(iterator, start, end);
/* 315 */           this.ranges[(i * 2)] = ((int)OS.g_utf16_pointer_to_offset(preeditString[0], preeditString[0] + start[0]));
/* 316 */           this.ranges[(i * 2 + 1)] = ((int)OS.g_utf16_pointer_to_offset(preeditString[0], preeditString[0] + end[0]) - 1);
/* 317 */           this.styles[i] = new TextStyle(null, null, null);
/* 318 */           long attr = OS.pango_attr_iterator_get(iterator, 9);
/* 319 */           if (attr != 0L) {
/* 320 */             OS.memmove(attrColor, attr, PangoAttrColor.sizeof);
/* 321 */             if (GTK.GTK3) {
/* 322 */               GdkRGBA rgba = new GdkRGBA();
/* 323 */               rgba.alpha = 1.0D;
/*     */               
/*     */ 
/* 326 */               rgba.red = ((attrColor.color_red & 0xFFFF) / 65535.0F);
/* 327 */               rgba.green = ((attrColor.color_green & 0xFFFF) / 65535.0F);
/* 328 */               rgba.blue = ((attrColor.color_blue & 0xFFFF) / 65535.0F);
/* 329 */               this.styles[i].foreground = Color.gtk_new(this.display, rgba);
/*     */             } else {
/* 331 */               GdkColor color = new GdkColor();
/* 332 */               color.red = attrColor.color_red;
/* 333 */               color.green = attrColor.color_green;
/* 334 */               color.blue = attrColor.color_blue;
/* 335 */               this.styles[i].foreground = Color.gtk_new(this.display, color);
/*     */             }
/*     */           }
/* 338 */           attr = OS.pango_attr_iterator_get(iterator, 10);
/* 339 */           if (attr != 0L) {
/* 340 */             OS.memmove(attrColor, attr, PangoAttrColor.sizeof);
/* 341 */             if (GTK.GTK3) {
/* 342 */               GdkRGBA rgba = new GdkRGBA();
/* 343 */               rgba.alpha = 1.0D;
/*     */               
/*     */ 
/* 346 */               rgba.red = ((attrColor.color_red & 0xFFFF) / 65535.0F);
/* 347 */               rgba.green = ((attrColor.color_green & 0xFFFF) / 65535.0F);
/* 348 */               rgba.blue = ((attrColor.color_blue & 0xFFFF) / 65535.0F);
/* 349 */               this.styles[i].background = Color.gtk_new(this.display, rgba);
/*     */             } else {
/* 351 */               GdkColor color = new GdkColor();
/* 352 */               color.red = attrColor.color_red;
/* 353 */               color.green = attrColor.color_green;
/* 354 */               color.blue = attrColor.color_blue;
/* 355 */               this.styles[i].background = Color.gtk_new(this.display, color);
/*     */             }
/*     */           }
/* 358 */           attr = OS.pango_attr_iterator_get(iterator, 11);
/* 359 */           if (attr != 0L) {
/* 360 */             OS.memmove(attrInt, attr, PangoAttrInt.sizeof);
/* 361 */             this.styles[i].underline = (attrInt.value != 0);
/* 362 */             this.styles[i].underlineStyle = 0;
/* 363 */             switch (attrInt.value) {
/*     */             case 2: 
/* 365 */               this.styles[i].underlineStyle = 1;
/* 366 */               break;
/*     */             case 4: 
/* 368 */               this.styles[i].underlineStyle = 2;
/*     */             }
/*     */             
/* 371 */             if (this.styles[i].underline) {
/* 372 */               attr = OS.pango_attr_iterator_get(iterator, 18);
/* 373 */               if (attr != 0L) {
/* 374 */                 OS.memmove(attrColor, attr, PangoAttrColor.sizeof);
/* 375 */                 GdkColor color = new GdkColor();
/* 376 */                 color.red = attrColor.color_red;
/* 377 */                 color.green = attrColor.color_green;
/* 378 */                 color.blue = attrColor.color_blue;
/* 379 */                 this.styles[i].underlineColor = Color.gtk_new(this.display, color);
/*     */               }
/*     */             }
/*     */           }
/* 383 */           OS.pango_attr_iterator_next(iterator);
/*     */         }
/* 385 */         OS.pango_attr_iterator_destroy(iterator);
/* 386 */         OS.pango_attr_list_unref(pangoAttrs[0]);
/*     */       }
/* 388 */       OS.g_free(preeditString[0]);
/*     */     }
/* 390 */     if (chars != null) {
/* 391 */       if (this.text.length() == 0)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 401 */         if (chars.length == 0) return 0L;
/* 402 */         this.startOffset = -1;
/*     */       }
/* 404 */       int end = this.startOffset + this.text.length();
/* 405 */       if (this.startOffset == -1) {
/* 406 */         Event event = new Event();
/* 407 */         event.detail = 3;
/* 408 */         sendEvent(43, event);
/* 409 */         this.startOffset = event.start;
/* 410 */         end = event.end;
/*     */       }
/* 412 */       this.inComposition = true;
/* 413 */       Event event = new Event();
/* 414 */       event.detail = 1;
/* 415 */       event.start = this.startOffset;
/* 416 */       event.end = end;
/* 417 */       event.text = (this.text = chars != null ? new String(chars) : "");
/* 418 */       sendEvent(43, event);
/*     */     }
/* 420 */     return 1L;
/*     */   }
/*     */   
/*     */   long imHandle() {
/* 424 */     return this.parent.imHandle();
/*     */   }
/*     */   
/*     */   boolean isInlineEnabled() {
/* 428 */     return hooks(43);
/*     */   }
/*     */   
/*     */   void releaseParent()
/*     */   {
/* 433 */     super.releaseParent();
/* 434 */     if (this == this.parent.getIME()) this.parent.setIME(null);
/*     */   }
/*     */   
/*     */   void releaseWidget()
/*     */   {
/* 439 */     super.releaseWidget();
/* 440 */     this.parent = null;
/* 441 */     this.text = null;
/* 442 */     this.styles = null;
/* 443 */     this.ranges = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCompositionOffset(int offset)
/*     */   {
/* 463 */     checkWidget();
/* 464 */     if (offset < 0) return;
/* 465 */     if (this.startOffset != -1) {
/* 466 */       this.startOffset = offset;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/widgets/IME.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */