/*     */ package org.eclipse.swt.browser;
/*     */ 
/*     */ import java.util.Random;
/*     */ import org.eclipse.swt.SWT;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BrowserFunction
/*     */ {
/*     */   Browser browser;
/*     */   String name;
/*     */   String functionString;
/*     */   int index;
/*     */   boolean isEvaluate;
/*     */   boolean top;
/*     */   String token;
/*     */   String[] frameNames;
/*     */   
/*     */   public BrowserFunction(Browser browser, String name)
/*     */   {
/*  84 */     this(browser, name, true, null, true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public BrowserFunction(Browser browser, String name, boolean top, String[] frameNames)
/*     */   {
/* 125 */     this(browser, name, top, frameNames, true);
/*     */   }
/*     */   
/*     */   BrowserFunction(Browser browser, String name, boolean top, String[] frameNames, boolean create)
/*     */   {
/* 130 */     if (browser == null) SWT.error(4);
/* 131 */     if (name == null) SWT.error(4);
/* 132 */     if (browser.isDisposed()) SWT.error(24);
/* 133 */     browser.checkWidget();
/* 134 */     this.browser = browser;
/* 135 */     this.name = name;
/* 136 */     this.top = top;
/* 137 */     this.frameNames = frameNames;
/*     */     
/* 139 */     Random random = new Random();
/* 140 */     byte[] bytes = new byte[16];
/* 141 */     random.nextBytes(bytes);
/* 142 */     StringBuilder buffer = new StringBuilder();
/* 143 */     for (int i = 0; i < bytes.length; i++) {
/* 144 */       buffer.append(Integer.toHexString(bytes[i] & 0xFF));
/*     */     }
/* 146 */     this.token = buffer.toString();
/* 147 */     if (create) { browser.webBrowser.createFunction(this);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void dispose()
/*     */   {
/* 159 */     dispose(true);
/*     */   }
/*     */   
/*     */   void dispose(boolean remove) {
/* 163 */     if (this.index < 0) return;
/* 164 */     if (remove) this.browser.webBrowser.destroyFunction(this);
/* 165 */     this.browser = null;
/* 166 */     this.name = (this.functionString = null);
/* 167 */     this.index = -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object function(Object[] arguments)
/*     */   {
/* 201 */     if (this.index < 0) SWT.error(49);
/* 202 */     this.browser.checkWidget();
/* 203 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Browser getBrowser()
/*     */   {
/* 217 */     if (this.index < 0) SWT.error(49);
/* 218 */     this.browser.checkWidget();
/* 219 */     return this.browser;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getName()
/*     */   {
/* 233 */     if (this.index < 0) SWT.error(49);
/* 234 */     this.browser.checkWidget();
/* 235 */     return this.name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isDisposed()
/*     */   {
/* 253 */     return this.index < 0;
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/browser/BrowserFunction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */