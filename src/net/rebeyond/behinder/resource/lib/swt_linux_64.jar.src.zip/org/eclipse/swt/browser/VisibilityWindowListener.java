/*     */ package org.eclipse.swt.browser;
/*     */ 
/*     */ import java.util.function.Consumer;
/*     */ import org.eclipse.swt.internal.SWTEventListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract interface VisibilityWindowListener
/*     */   extends SWTEventListener
/*     */ {
/*     */   public abstract void hide(WindowEvent paramWindowEvent);
/*     */   
/*     */   public abstract void show(WindowEvent paramWindowEvent);
/*     */   
/*     */   public static VisibilityWindowListener hideAdapter(Consumer<WindowEvent> c)
/*     */   {
/* 102 */     new VisibilityWindowAdapter()
/*     */     {
/*     */       public void hide(WindowEvent e) {
/* 105 */         this.val$c.accept(e);
/*     */       }
/*     */     };
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static VisibilityWindowListener showAdapter(Consumer<WindowEvent> c)
/*     */   {
/* 119 */     new VisibilityWindowAdapter()
/*     */     {
/*     */       public void show(WindowEvent e) {
/* 122 */         this.val$c.accept(e);
/*     */       }
/*     */     };
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/browser/VisibilityWindowListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */