package org.eclipse.swt.browser;

public abstract class VisibilityWindowAdapter
  implements VisibilityWindowListener
{
  public void hide(WindowEvent event) {}
  
  public void show(WindowEvent event) {}
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/browser/VisibilityWindowAdapter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */