/*     */ package org.eclipse.swt.widgets;
/*     */ 
/*     */ import org.eclipse.swt.graphics.Font;
/*     */ import org.eclipse.swt.graphics.Point;
/*     */ import org.eclipse.swt.graphics.Rectangle;
/*     */ import org.eclipse.swt.internal.Converter;
/*     */ import org.eclipse.swt.internal.gtk.GTK;
/*     */ import org.eclipse.swt.internal.gtk.GdkColor;
/*     */ import org.eclipse.swt.internal.gtk.GdkRGBA;
/*     */ import org.eclipse.swt.internal.gtk.GtkAllocation;
/*     */ import org.eclipse.swt.internal.gtk.GtkRequisition;
/*     */ import org.eclipse.swt.internal.gtk.OS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Group
/*     */   extends Composite
/*     */ {
/*     */   long clientHandle;
/*     */   long labelHandle;
/*  45 */   String text = "";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   GdkRGBA foreground;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Group(Composite parent, int style)
/*     */   {
/*  82 */     super(parent, checkStyle(style));
/*     */   }
/*     */   
/*     */   static int checkStyle(int style) {
/*  86 */     style |= 0x80000;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  94 */     return style & 0xFCFF;
/*     */   }
/*     */   
/*     */   protected void checkSubclass()
/*     */   {
/*  99 */     if (!isValidSubclass()) error(43);
/*     */   }
/*     */   
/*     */   long clientHandle()
/*     */   {
/* 104 */     return this.clientHandle;
/*     */   }
/*     */   
/*     */   Point computeSizeInPixels(int wHint, int hHint, boolean changed)
/*     */   {
/* 109 */     Point size = super.computeSizeInPixels(wHint, hHint, changed);
/*     */     int width;
/* 111 */     int width; if (GTK.GTK3) {
/* 112 */       width = computeNativeSize(this.handle, -1, -1, false).x;
/*     */     }
/*     */     else {
/* 115 */       int x_thickness = GTK.gtk_style_get_xthickness(GTK.gtk_widget_get_style(this.handle));
/*     */       
/*     */ 
/* 118 */       int minimalSizeAroundLabel = 2 * (3 + x_thickness);
/* 119 */       width = computeNativeSize(this.labelHandle, -1, -1, false).x + minimalSizeAroundLabel;
/*     */     }
/* 121 */     size.x = Math.max(size.x, width);
/* 122 */     return size;
/*     */   }
/*     */   
/*     */   Rectangle computeTrimInPixels(int x, int y, int width, int height) {
/* 126 */     checkWidget();
/* 127 */     forceResize();
/* 128 */     GtkAllocation allocation = new GtkAllocation();
/* 129 */     GTK.gtk_widget_get_allocation(this.clientHandle, allocation);
/* 130 */     int clientX = allocation.x;
/* 131 */     int clientY = allocation.y;
/* 132 */     x -= clientX;
/* 133 */     y -= clientY;
/* 134 */     width += clientX + clientX;
/* 135 */     height += clientX + clientY;
/* 136 */     return new Rectangle(x, y, width, height);
/*     */   }
/*     */   
/*     */   Rectangle getClientAreaInPixels()
/*     */   {
/* 141 */     Rectangle clientRectangle = super.getClientAreaInPixels();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 155 */     clientRectangle.x = 0;
/* 156 */     clientRectangle.y = 0;
/* 157 */     return clientRectangle;
/*     */   }
/*     */   
/*     */   GdkRGBA getContextColorGdkRGBA()
/*     */   {
/* 162 */     assert (GTK.GTK3) : "GTK3 code was run by GTK2";
/* 163 */     if (GTK.GTK_VERSION >= OS.VERSION(3, 14, 0)) {
/* 164 */       if (this.foreground != null) {
/* 165 */         return this.foreground;
/*     */       }
/* 167 */       return this.display.COLOR_WIDGET_FOREGROUND_RGBA;
/*     */     }
/*     */     
/* 170 */     return super.getContextColorGdkRGBA();
/*     */   }
/*     */   
/*     */ 
/*     */   GdkRGBA getContextBackgroundGdkRGBA()
/*     */   {
/* 176 */     assert (GTK.GTK3) : "GTK3 code was run by GTK2";
/* 177 */     if (GTK.GTK_VERSION >= OS.VERSION(3, 14, 0)) {
/* 178 */       return super.getContextBackgroundGdkRGBA();
/*     */     }
/* 180 */     long context = GTK.gtk_widget_get_style_context(this.fixedHandle);
/* 181 */     GdkRGBA rgba = new GdkRGBA();
/* 182 */     GTK.gtk_style_context_get_background_color(context, 0, rgba);
/* 183 */     if ((this.state & 0x2000) == 0) {
/* 184 */       return defaultBackground();
/*     */     }
/* 186 */     return rgba;
/*     */   }
/*     */   
/*     */ 
/*     */   void createHandle(int index)
/*     */   {
/* 192 */     this.state |= 0x10008;
/*     */     
/* 194 */     this.fixedHandle = OS.g_object_new(this.display.gtk_fixed_get_type(), 0L);
/* 195 */     if (this.fixedHandle == 0L) error(2);
/* 196 */     GTK.gtk_widget_set_has_window(this.fixedHandle, true);
/*     */     
/* 198 */     this.handle = GTK.gtk_frame_new(null);
/* 199 */     if (this.handle == 0L) { error(2);
/*     */     }
/* 201 */     this.labelHandle = GTK.gtk_label_new(null);
/* 202 */     if (this.labelHandle == 0L) error(2);
/* 203 */     OS.g_object_ref(this.labelHandle);
/* 204 */     OS.g_object_ref_sink(this.labelHandle);
/*     */     
/* 206 */     this.clientHandle = OS.g_object_new(this.display.gtk_fixed_get_type(), 0L);
/* 207 */     if (this.clientHandle == 0L) { error(2);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 213 */     GTK.gtk_widget_set_has_window(this.clientHandle, true);
/*     */     
/* 215 */     GTK.gtk_container_add(this.fixedHandle, this.handle);
/* 216 */     GTK.gtk_container_add(this.handle, this.clientHandle);
/* 217 */     if ((this.style & 0x4) != 0) {
/* 218 */       GTK.gtk_frame_set_shadow_type(this.handle, 1);
/*     */     }
/* 220 */     if ((this.style & 0x8) != 0) {
/* 221 */       GTK.gtk_frame_set_shadow_type(this.handle, 2);
/*     */     }
/* 223 */     if ((this.style & 0x10) != 0) {
/* 224 */       GTK.gtk_frame_set_shadow_type(this.handle, 3);
/*     */     }
/* 226 */     if ((this.style & 0x40) != 0) {
/* 227 */       GTK.gtk_frame_set_shadow_type(this.handle, 4);
/*     */     }
/*     */     
/*     */ 
/* 231 */     if (GTK.GTK3) {
/* 232 */       setFontDescription(defaultFont().handle);
/*     */     }
/*     */   }
/*     */   
/*     */   int applyThemeBackground()
/*     */   {
/* 238 */     return 1;
/*     */   }
/*     */   
/*     */   void deregister()
/*     */   {
/* 243 */     super.deregister();
/* 244 */     this.display.removeWidget(this.clientHandle);
/* 245 */     this.display.removeWidget(this.labelHandle);
/*     */   }
/*     */   
/*     */   void enableWidget(boolean enabled)
/*     */   {
/* 250 */     GTK.gtk_widget_set_sensitive(this.labelHandle, enabled);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   long eventHandle()
/*     */   {
/* 260 */     return this.clientHandle;
/*     */   }
/*     */   
/*     */   String getNameText()
/*     */   {
/* 265 */     return getText();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getText()
/*     */   {
/* 281 */     checkWidget();
/* 282 */     return this.text;
/*     */   }
/*     */   
/*     */   void hookEvents()
/*     */   {
/* 287 */     super.hookEvents();
/* 288 */     if (this.labelHandle != 0L) {
/* 289 */       OS.g_signal_connect_closure_by_id(this.labelHandle, this.display.signalIds[32], 0, this.display.getClosure(32), false);
/*     */     }
/*     */   }
/*     */   
/*     */   boolean mnemonicHit(char key)
/*     */   {
/* 295 */     if (this.labelHandle == 0L) return false;
/* 296 */     boolean result = super.mnemonicHit(this.labelHandle, key);
/* 297 */     if (result) setFocus();
/* 298 */     return result;
/*     */   }
/*     */   
/*     */   boolean mnemonicMatch(char key)
/*     */   {
/* 303 */     if (this.labelHandle == 0L) return false;
/* 304 */     return mnemonicMatch(this.labelHandle, key);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   long parentingHandle()
/*     */   {
/* 313 */     return this.clientHandle;
/*     */   }
/*     */   
/*     */   void register()
/*     */   {
/* 318 */     super.register();
/* 319 */     this.display.addWidget(this.clientHandle, this);
/* 320 */     this.display.addWidget(this.labelHandle, this);
/*     */   }
/*     */   
/*     */   void releaseHandle()
/*     */   {
/* 325 */     super.releaseHandle();
/* 326 */     this.clientHandle = (this.labelHandle = 0L);
/*     */   }
/*     */   
/*     */   void releaseWidget()
/*     */   {
/* 331 */     super.releaseWidget();
/* 332 */     if (this.labelHandle != 0L) OS.g_object_unref(this.labelHandle);
/* 333 */     this.text = null;
/*     */   }
/*     */   
/*     */   void setBackgroundGdkRGBA(long handle, GdkRGBA rgba)
/*     */   {
/* 338 */     assert (GTK.GTK3) : "GTK3 code was run by GTK2";
/* 339 */     super.setBackgroundGdkRGBA(this.fixedHandle, rgba);
/*     */   }
/*     */   
/*     */   void setBackgroundGdkColor(GdkColor color)
/*     */   {
/* 344 */     assert (!GTK.GTK3) : "GTK2 code was run by GTK3";
/* 345 */     super.setBackgroundGdkColor(color);
/* 346 */     setBackgroundGdkColor(this.fixedHandle, color);
/*     */     
/* 348 */     setBackgroundGdkColor(this.clientHandle, color);
/*     */   }
/*     */   
/*     */   void setFontDescription(long font)
/*     */   {
/* 353 */     super.setFontDescription(font);
/* 354 */     setFontDescription(this.labelHandle, font);
/*     */   }
/*     */   
/*     */   void setForegroundGdkRGBA(long handle, GdkRGBA rgba)
/*     */   {
/* 359 */     assert (GTK.GTK3) : "GTK3 code was run by GTK2";
/* 360 */     if (GTK.GTK_VERSION < OS.VERSION(3, 14, 0)) {
/* 361 */       super.setForegroundGdkRGBA(handle, rgba);
/* 362 */       return;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 370 */     if ((this.text != null) && (!this.text.isEmpty())) {
/* 371 */       super.setForegroundGdkRGBA(this.labelHandle, rgba);
/*     */     }
/* 373 */     this.foreground = rgba;
/*     */   }
/*     */   
/*     */   void setForegroundGdkColor(GdkColor color)
/*     */   {
/* 378 */     assert (!GTK.GTK3) : "GTK2 code was run by GTK3";
/* 379 */     super.setForegroundGdkColor(color);
/* 380 */     setForegroundColor(this.labelHandle, color);
/*     */   }
/*     */   
/*     */   void setForegroundGdkRGBA(GdkRGBA rgba)
/*     */   {
/* 385 */     assert (GTK.GTK3) : "GTK3 code was run by GTK2";
/* 386 */     super.setForegroundGdkRGBA(rgba);
/* 387 */     setForegroundGdkRGBA(this.labelHandle, rgba);
/*     */   }
/*     */   
/*     */   void setOrientation(boolean create)
/*     */   {
/* 392 */     super.setOrientation(create);
/* 393 */     if (((this.style & 0x4000000) != 0) || (!create)) {
/* 394 */       int dir = (this.style & 0x4000000) != 0 ? 2 : 1;
/* 395 */       GTK.gtk_widget_set_direction(this.labelHandle, dir);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setText(String string)
/*     */   {
/* 427 */     checkWidget();
/* 428 */     if (string == null) error(4);
/* 429 */     this.text = string;
/* 430 */     char[] chars = fixMnemonic(string);
/* 431 */     byte[] buffer = Converter.wcsToMbcs(chars, true);
/* 432 */     GTK.gtk_label_set_text_with_mnemonic(this.labelHandle, buffer);
/* 433 */     if (string.length() != 0) {
/* 434 */       if (GTK.gtk_frame_get_label_widget(this.handle) == 0L) {
/* 435 */         GTK.gtk_frame_set_label_widget(this.handle, this.labelHandle);
/*     */       }
/*     */     } else {
/* 438 */       GTK.gtk_frame_set_label_widget(this.handle, 0L);
/*     */     }
/*     */     
/* 441 */     if ((GTK.GTK_VERSION >= OS.VERSION(3, 16, 0)) && (this.foreground != null)) {
/* 442 */       setForegroundGdkRGBA(this.labelHandle, this.foreground);
/*     */     }
/*     */   }
/*     */   
/*     */   void showWidget()
/*     */   {
/* 448 */     super.showWidget();
/* 449 */     if (this.clientHandle != 0L) GTK.gtk_widget_show(this.clientHandle);
/* 450 */     if (this.labelHandle != 0L) GTK.gtk_widget_show(this.labelHandle);
/*     */   }
/*     */   
/*     */   int setBounds(int x, int y, int width, int height, boolean move, boolean resize)
/*     */   {
/* 455 */     if (GTK.GTK3)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 461 */       GtkRequisition requisition = new GtkRequisition();
/* 462 */       GTK.gtk_widget_get_preferred_size(this.handle, requisition, null);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 468 */       if (GTK.GTK_VERSION >= OS.VERSION(3, 20, 0)) {
/* 469 */         width = width - (requisition.width - width) < 0 ? requisition.width : width;
/* 470 */         height = height - (requisition.height - height) < 0 ? requisition.height : height;
/*     */       } else {
/* 472 */         width = Math.max(requisition.width, width);
/*     */       }
/*     */     }
/* 475 */     return super.setBounds(x, y, width, height, move, resize);
/*     */   }
/*     */   
/*     */   long paintHandle()
/*     */   {
/* 480 */     if ((GTK.GTK3) && (GTK.GTK_VERSION < OS.VERSION(3, 14, 0))) {
/* 481 */       return super.paintHandle();
/*     */     }
/*     */     
/* 484 */     long topHandle = topHandle();
/*     */     
/* 486 */     long paintHandle = this.clientHandle;
/* 487 */     while ((paintHandle != topHandle) && 
/* 488 */       (!GTK.gtk_widget_get_has_window(paintHandle))) {
/* 489 */       paintHandle = GTK.gtk_widget_get_parent(paintHandle);
/*     */     }
/* 491 */     return paintHandle;
/*     */   }
/*     */   
/*     */ 
/*     */   long paintWindow()
/*     */   {
/* 497 */     long paintHandle = this.clientHandle;
/* 498 */     GTK.gtk_widget_realize(paintHandle);
/* 499 */     return gtk_widget_get_window(paintHandle);
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/widgets/Group.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */