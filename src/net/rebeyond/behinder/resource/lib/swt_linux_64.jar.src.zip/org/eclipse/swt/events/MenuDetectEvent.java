/*    */ package org.eclipse.swt.events;
/*    */ 
/*    */ import org.eclipse.swt.widgets.Event;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class MenuDetectEvent
/*    */   extends TypedEvent
/*    */ {
/*    */   public int x;
/*    */   public int y;
/*    */   public boolean doit;
/*    */   public int detail;
/*    */   private static final long serialVersionUID = -3061660596590828941L;
/*    */   
/*    */   public MenuDetectEvent(Event e)
/*    */   {
/* 74 */     super(e);
/* 75 */     this.x = e.x;
/* 76 */     this.y = e.y;
/* 77 */     this.doit = e.doit;
/* 78 */     this.detail = e.detail;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String toString()
/*    */   {
/* 89 */     String string = super.toString();
/* 90 */     return string.substring(0, string.length() - 1) + " x=" + this.x + " y=" + this.y + " doit=" + this.doit + " detail=" + this.detail + "}";
/*    */   }
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/events/MenuDetectEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */