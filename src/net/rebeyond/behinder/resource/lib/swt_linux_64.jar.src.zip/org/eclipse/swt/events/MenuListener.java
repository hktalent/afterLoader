/*    */ package org.eclipse.swt.events;
/*    */ 
/*    */ import java.util.function.Consumer;
/*    */ import org.eclipse.swt.internal.SWTEventListener;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract interface MenuListener
/*    */   extends SWTEventListener
/*    */ {
/*    */   public abstract void menuHidden(MenuEvent paramMenuEvent);
/*    */   
/*    */   public abstract void menuShown(MenuEvent paramMenuEvent);
/*    */   
/*    */   public static MenuListener menuHiddenAdapter(Consumer<MenuEvent> c)
/*    */   {
/* 58 */     new MenuAdapter()
/*    */     {
/*    */       public void menuHidden(MenuEvent e) {
/* 61 */         this.val$c.accept(e);
/*    */       }
/*    */     };
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static MenuListener menuShownAdapter(Consumer<MenuEvent> c)
/*    */   {
/* 75 */     new MenuAdapter()
/*    */     {
/*    */       public void menuShown(MenuEvent e) {
/* 78 */         this.val$c.accept(e);
/*    */       }
/*    */     };
/*    */   }
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/events/MenuListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */