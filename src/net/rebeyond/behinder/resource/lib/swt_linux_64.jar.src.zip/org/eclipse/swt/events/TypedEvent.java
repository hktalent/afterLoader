/*     */ package org.eclipse.swt.events;
/*     */ 
/*     */ import java.util.EventObject;
/*     */ import org.eclipse.swt.widgets.Display;
/*     */ import org.eclipse.swt.widgets.Event;
/*     */ import org.eclipse.swt.widgets.Widget;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TypedEvent
/*     */   extends EventObject
/*     */ {
/*     */   public Display display;
/*     */   public Widget widget;
/*     */   public int time;
/*     */   public Object data;
/*     */   static final long serialVersionUID = 3257285846578377524L;
/*     */   
/*     */   public TypedEvent(Object object)
/*     */   {
/*  62 */     super(object);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TypedEvent(Event e)
/*     */   {
/*  72 */     super(e.widget);
/*  73 */     this.display = e.display;
/*  74 */     this.widget = e.widget;
/*  75 */     this.time = e.time;
/*  76 */     this.data = e.data;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   String getName()
/*     */   {
/*  86 */     String string = getClass().getName();
/*  87 */     int index = string.lastIndexOf('.');
/*  88 */     if (index == -1) return string;
/*  89 */     return string.substring(index + 1, string.length());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 100 */     return getName() + "{" + this.widget + " time=" + this.time + " data=" + this.data + "}";
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/events/TypedEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */