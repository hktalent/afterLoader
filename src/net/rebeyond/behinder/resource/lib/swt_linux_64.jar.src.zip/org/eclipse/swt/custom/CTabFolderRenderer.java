/*      */ package org.eclipse.swt.custom;
/*      */ 
/*      */ import org.eclipse.swt.SWT;
/*      */ import org.eclipse.swt.graphics.Color;
/*      */ import org.eclipse.swt.graphics.Font;
/*      */ import org.eclipse.swt.graphics.FontData;
/*      */ import org.eclipse.swt.graphics.GC;
/*      */ import org.eclipse.swt.graphics.Image;
/*      */ import org.eclipse.swt.graphics.Point;
/*      */ import org.eclipse.swt.graphics.RGB;
/*      */ import org.eclipse.swt.graphics.Rectangle;
/*      */ import org.eclipse.swt.graphics.Region;
/*      */ import org.eclipse.swt.graphics.TextLayout;
/*      */ import org.eclipse.swt.widgets.Composite;
/*      */ import org.eclipse.swt.widgets.Display;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class CTabFolderRenderer
/*      */ {
/*      */   protected CTabFolder parent;
/*      */   int[] curve;
/*      */   int[] topCurveHighlightStart;
/*      */   int[] topCurveHighlightEnd;
/*   33 */   int curveWidth = 0;
/*   34 */   int curveIndent = 0;
/*   35 */   int lastTabHeight = -1;
/*      */   
/*      */   Color fillColor;
/*      */   
/*   39 */   Color selectionHighlightGradientBegin = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*   46 */   Color[] selectionHighlightGradientColorsCache = null;
/*      */   
/*   48 */   Color selectedOuterColor = null;
/*   49 */   Color selectedInnerColor = null;
/*   50 */   Color tabAreaColor = null;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*   55 */   Color lastBorderColor = null;
/*      */   
/*      */ 
/*      */ 
/*   59 */   static final int[] TOP_LEFT_CORNER_HILITE = { 5, 2, 4, 2, 3, 3, 2, 4, 2, 5, 1, 6 };
/*      */   
/*   61 */   static final int[] TOP_LEFT_CORNER = { 0, 6, 1, 5, 1, 4, 4, 1, 5, 1, 6, 0 };
/*   62 */   static final int[] TOP_RIGHT_CORNER = { -6, 0, -5, 1, -4, 1, -1, 4, -1, 5, 0, 6 };
/*   63 */   static final int[] BOTTOM_LEFT_CORNER = { 0, -6, 1, -5, 1, -4, 4, -1, 5, -1, 6, 0 };
/*   64 */   static final int[] BOTTOM_RIGHT_CORNER = { -6, 0, -5, -1, -4, -1, -1, -4, -1, -5, 0, -6 };
/*      */   
/*   66 */   static final int[] SIMPLE_TOP_LEFT_CORNER = { 0, 2, 1, 1, 2, 0 };
/*   67 */   static final int[] SIMPLE_TOP_RIGHT_CORNER = { -2, 0, -1, 1, 0, 2 };
/*   68 */   static final int[] SIMPLE_BOTTOM_LEFT_CORNER = { 0, -2, 1, -1, 2, 0 };
/*   69 */   static final int[] SIMPLE_BOTTOM_RIGHT_CORNER = { -2, 0, -1, -1, 0, -2 };
/*   70 */   static final int[] SIMPLE_UNSELECTED_INNER_CORNER = { 0, 0 };
/*      */   
/*   72 */   static final int[] TOP_LEFT_CORNER_BORDERLESS = { 0, 6, 1, 5, 1, 4, 4, 1, 5, 1, 6, 0 };
/*   73 */   static final int[] TOP_RIGHT_CORNER_BORDERLESS = { -7, 0, -6, 1, -5, 1, -2, 4, -2, 5, -1, 6 };
/*   74 */   static final int[] BOTTOM_LEFT_CORNER_BORDERLESS = { 0, -6, 1, -6, 1, -5, 2, -4, 4, -2, 5, -1, 6, -1, 6, 0 };
/*   75 */   static final int[] BOTTOM_RIGHT_CORNER_BORDERLESS = { -7, 0, -7, -1, -6, -1, -5, -2, -3, -4, -2, -5, -2, -6, -1, -6 };
/*      */   
/*   77 */   static final int[] SIMPLE_TOP_LEFT_CORNER_BORDERLESS = { 0, 2, 1, 1, 2, 0 };
/*   78 */   static final int[] SIMPLE_TOP_RIGHT_CORNER_BORDERLESS = { -3, 0, -2, 1, -1, 2 };
/*   79 */   static final int[] SIMPLE_BOTTOM_LEFT_CORNER_BORDERLESS = { 0, -3, 1, -2, 2, -1, 3, 0 };
/*   80 */   static final int[] SIMPLE_BOTTOM_RIGHT_CORNER_BORDERLESS = { -4, 0, -3, -1, -2, -2, -1, -3 };
/*      */   
/*   82 */   static final RGB CLOSE_FILL = new RGB(252, 160, 160);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int BUTTON_SIZE = 16;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int BUTTON_TRIM = 1;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int BUTTON_BORDER = 17;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int BUTTON_FILL = 25;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int BORDER1_COLOR = 18;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int ITEM_TOP_MARGIN = 2;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int ITEM_BOTTOM_MARGIN = 2;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int ITEM_LEFT_MARGIN = 4;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int ITEM_RIGHT_MARGIN = 4;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int INTERNAL_SPACING = 4;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int FLAGS = 11;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   static final String ELLIPSIS = "...";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int PART_BODY = -1;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int PART_HEADER = -2;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int PART_BORDER = -3;
/*      */   
/*      */ 
/*      */ 
/*      */   public static final int PART_BACKGROUND = -4;
/*      */   
/*      */ 
/*      */ 
/*      */   public static final int PART_MAX_BUTTON = -5;
/*      */   
/*      */ 
/*      */ 
/*      */   public static final int PART_MIN_BUTTON = -6;
/*      */   
/*      */ 
/*      */ 
/*      */   public static final int PART_CHEVRON_BUTTON = -7;
/*      */   
/*      */ 
/*      */ 
/*      */   public static final int PART_CLOSE_BUTTON = -8;
/*      */   
/*      */ 
/*      */ 
/*      */   public static final int MINIMUM_SIZE = 16777216;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected CTabFolderRenderer(CTabFolder parent)
/*      */   {
/*  188 */     if (parent == null) return;
/*  189 */     if (parent.isDisposed()) SWT.error(5);
/*  190 */     this.parent = parent;
/*      */   }
/*      */   
/*      */ 
/*      */   void antialias(int[] shape, Color innerColor, Color outerColor, GC gc)
/*      */   {
/*  196 */     if (this.parent.simple) return;
/*  197 */     String platform = SWT.getPlatform();
/*  198 */     if ("cocoa".equals(platform)) { return;
/*      */     }
/*  200 */     if (this.parent.getDisplay().getDepth() < 15) return;
/*  201 */     if (outerColor != null) {
/*  202 */       int index = 0;
/*  203 */       boolean left = true;
/*  204 */       int oldY = this.parent.onBottom ? 0 : this.parent.getSize().y;
/*  205 */       int[] outer = new int[shape.length];
/*  206 */       for (int i = 0; i < shape.length / 2; i++) {
/*  207 */         if ((left) && (index + 3 < shape.length)) {
/*  208 */           left = oldY <= shape[(index + 3)];
/*  209 */           oldY = shape[(index + 1)];
/*      */         }
/*  211 */         outer[index] = (shape[(index++)] + (left ? -1 : 1));
/*  212 */         outer[index] = shape[(index++)];
/*      */       }
/*  214 */       gc.setForeground(outerColor);
/*  215 */       gc.drawPolyline(outer);
/*      */     }
/*  217 */     if (innerColor != null) {
/*  218 */       int[] inner = new int[shape.length];
/*  219 */       int index = 0;
/*  220 */       boolean left = true;
/*  221 */       int oldY = this.parent.onBottom ? 0 : this.parent.getSize().y;
/*  222 */       for (int i = 0; i < shape.length / 2; i++) {
/*  223 */         if ((left) && (index + 3 < shape.length)) {
/*  224 */           left = oldY <= shape[(index + 3)];
/*  225 */           oldY = shape[(index + 1)];
/*      */         }
/*  227 */         inner[index] = (shape[(index++)] + (left ? 1 : -1));
/*  228 */         inner[index] = shape[(index++)];
/*      */       }
/*  230 */       gc.setForeground(innerColor);
/*  231 */       gc.drawPolyline(inner);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Point computeSize(int part, int state, GC gc, int wHint, int hHint)
/*      */   {
/*  276 */     int width = 0;int height = 0;
/*  277 */     switch (part) {
/*      */     case -2: 
/*  279 */       if (this.parent.fixedTabHeight != -1) {
/*  280 */         height = this.parent.fixedTabHeight == 0 ? 0 : this.parent.fixedTabHeight + 1;
/*      */       } else {
/*  282 */         CTabItem[] items = this.parent.items;
/*  283 */         if (items.length == 0) {
/*  284 */           height = gc.textExtent("Default", 11).y + 2 + 2;
/*      */         } else {
/*  286 */           for (int i = 0; i < items.length; i++) {
/*  287 */             height = Math.max(height, computeSize(i, 0, gc, wHint, hHint).y);
/*      */           }
/*      */         }
/*  290 */         gc.dispose();
/*      */       }
/*  292 */       break;
/*      */     case -8: 
/*      */     case -6: 
/*      */     case -5: 
/*  296 */       width = height = 16;
/*  297 */       break;
/*      */     case -7: 
/*  299 */       width = 24;
/*  300 */       height = 16;
/*  301 */       break;
/*      */     case -4: case -3: default: 
/*  303 */       if ((0 <= part) && (part < this.parent.getItemCount())) {
/*  304 */         updateCurves();
/*  305 */         CTabItem item = this.parent.items[part];
/*  306 */         if (item.isDisposed()) return new Point(0, 0);
/*  307 */         Image image = item.getImage();
/*  308 */         if ((image != null) && (!image.isDisposed())) {
/*  309 */           Rectangle bounds = image.getBounds();
/*  310 */           if (((state & 0x2) != 0) || (this.parent.showUnselectedImage)) {
/*  311 */             width += bounds.width;
/*      */           }
/*  313 */           height = bounds.height;
/*      */         }
/*  315 */         String text = null;
/*  316 */         if ((state & 0x1000000) != 0) {
/*  317 */           int minChars = this.parent.minChars;
/*  318 */           text = minChars == 0 ? null : item.getText();
/*  319 */           if ((text != null) && (text.length() > minChars)) {
/*  320 */             if (useEllipses()) {
/*  321 */               int end = minChars < "...".length() + 1 ? minChars : minChars - "...".length();
/*  322 */               text = text.substring(0, end);
/*  323 */               if (minChars > "...".length() + 1) text = text + "...";
/*      */             } else {
/*  325 */               int end = minChars;
/*  326 */               text = text.substring(0, end);
/*      */             }
/*      */           }
/*      */         } else {
/*  330 */           text = item.getText();
/*      */         }
/*  332 */         if (text != null) {
/*  333 */           if (width > 0) width += 4;
/*  334 */           if (item.font == null) {
/*  335 */             Point size = gc.textExtent(text, 11);
/*  336 */             width += size.x;
/*  337 */             height = Math.max(height, size.y);
/*      */           } else {
/*  339 */             Font gcFont = gc.getFont();
/*  340 */             gc.setFont(item.font);
/*  341 */             Point size = gc.textExtent(text, 11);
/*  342 */             width += size.x;
/*  343 */             height = Math.max(height, size.y);
/*  344 */             gc.setFont(gcFont);
/*      */           }
/*      */         }
/*  347 */         if (((this.parent.showClose) || (item.showClose)) && (
/*  348 */           ((state & 0x2) != 0) || (this.parent.showUnselectedClose))) {
/*  349 */           if (width > 0) width += 4;
/*  350 */           width += computeSize(-8, 0, gc, -1, -1).x;
/*      */         }
/*      */       }
/*      */       break;
/*      */     }
/*      */     
/*  356 */     Rectangle trim = computeTrim(part, state, 0, 0, width, height);
/*  357 */     width = trim.width;
/*  358 */     height = trim.height;
/*  359 */     return new Point(width, height);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected Rectangle computeTrim(int part, int state, int x, int y, int width, int height)
/*      */   {
/*  389 */     int borderLeft = this.parent.borderVisible ? 1 : 0;
/*  390 */     int borderRight = borderLeft;
/*  391 */     int borderTop = this.parent.onBottom ? borderLeft : 0;
/*  392 */     int borderBottom = this.parent.onBottom ? 0 : borderLeft;
/*  393 */     int tabHeight = this.parent.tabHeight;
/*  394 */     switch (part) {
/*      */     case -1: 
/*  396 */       int style = this.parent.getStyle();
/*  397 */       int highlight_header = (style & 0x800000) != 0 ? 1 : 3;
/*  398 */       int highlight_margin = (style & 0x800000) != 0 ? 0 : 2;
/*  399 */       if ((this.parent.fixedTabHeight == 0) && ((style & 0x800000) != 0) && ((style & 0x800) == 0)) {
/*  400 */         highlight_header = 0;
/*      */       }
/*  402 */       int marginWidth = this.parent.marginWidth;
/*  403 */       int marginHeight = this.parent.marginHeight;
/*  404 */       x = x - marginWidth - highlight_margin - borderLeft;
/*  405 */       width = width + borderLeft + borderRight + 2 * marginWidth + 2 * highlight_margin;
/*  406 */       if (this.parent.minimized) {
/*  407 */         y = this.parent.onBottom ? y - borderTop : y - highlight_header - tabHeight - borderTop;
/*  408 */         height = borderTop + borderBottom + tabHeight + highlight_header;
/*      */       } else {
/*  410 */         y = this.parent.onBottom ? y - marginHeight - highlight_margin - borderTop : y - marginHeight - highlight_header - tabHeight - borderTop;
/*  411 */         height = height + borderTop + borderBottom + 2 * marginHeight + tabHeight + highlight_header + highlight_margin;
/*      */       }
/*  413 */       break;
/*      */     case -2: 
/*      */       break;
/*      */     
/*      */     case -8: 
/*      */     case -7: 
/*      */     case -6: 
/*      */     case -5: 
/*  421 */       x--;
/*  422 */       y--;
/*  423 */       width += 2;
/*  424 */       height += 2;
/*  425 */       break;
/*      */     case -3: 
/*  427 */       x -= borderLeft;
/*  428 */       width = width + borderLeft + borderRight;
/*  429 */       if (!this.parent.simple) width += 2;
/*  430 */       y -= borderTop;
/*  431 */       height = height + borderTop + borderBottom;
/*  432 */       break;
/*      */     case -4: default: 
/*  434 */       if ((0 <= part) && (part < this.parent.getItemCount())) {
/*  435 */         updateCurves();
/*  436 */         x -= 4;
/*  437 */         width = width + 4 + 4;
/*  438 */         if ((!this.parent.simple) && (!this.parent.single) && ((state & 0x2) != 0)) {
/*  439 */           width += this.curveWidth - this.curveIndent;
/*      */         }
/*  441 */         y -= 2;
/*  442 */         height = height + 2 + 2;
/*      */       }
/*      */       break;
/*      */     }
/*  446 */     return new Rectangle(x, y, width, height);
/*      */   }
/*      */   
/*      */   void createAntialiasColors() {
/*  450 */     disposeAntialiasColors();
/*  451 */     this.lastBorderColor = this.parent.getDisplay().getSystemColor(18);
/*  452 */     RGB lineRGB = this.lastBorderColor.getRGB();
/*      */     
/*  454 */     RGB innerRGB = this.parent.selectionBackground.getRGB();
/*  455 */     if ((this.parent.selectionBgImage != null) || ((this.parent.selectionGradientColors != null) && (this.parent.selectionGradientColors.length > 1)))
/*      */     {
/*  457 */       innerRGB = null;
/*      */     }
/*  459 */     RGB outerRGB = this.parent.getBackground().getRGB();
/*  460 */     if ((this.parent.gradientColors != null) && (this.parent.gradientColors.length > 1)) {
/*  461 */       outerRGB = null;
/*      */     }
/*  463 */     if (outerRGB != null) {
/*  464 */       RGB from = lineRGB;
/*  465 */       RGB to = outerRGB;
/*  466 */       int red = from.red + 2 * (to.red - from.red) / 3;
/*  467 */       int green = from.green + 2 * (to.green - from.green) / 3;
/*  468 */       int blue = from.blue + 2 * (to.blue - from.blue) / 3;
/*  469 */       this.selectedOuterColor = new Color(this.parent.getDisplay(), red, green, blue);
/*      */     }
/*  471 */     if (innerRGB != null) {
/*  472 */       RGB from = lineRGB;
/*  473 */       RGB to = innerRGB;
/*  474 */       int red = from.red + 2 * (to.red - from.red) / 3;
/*  475 */       int green = from.green + 2 * (to.green - from.green) / 3;
/*  476 */       int blue = from.blue + 2 * (to.blue - from.blue) / 3;
/*  477 */       this.selectedInnerColor = new Color(this.parent.getDisplay(), red, green, blue);
/*      */     }
/*      */     
/*  480 */     outerRGB = this.parent.getParent().getBackground().getRGB();
/*  481 */     if (outerRGB != null) {
/*  482 */       RGB from = lineRGB;
/*  483 */       RGB to = outerRGB;
/*  484 */       int red = from.red + 2 * (to.red - from.red) / 3;
/*  485 */       int green = from.green + 2 * (to.green - from.green) / 3;
/*  486 */       int blue = from.blue + 2 * (to.blue - from.blue) / 3;
/*  487 */       this.tabAreaColor = new Color(this.parent.getDisplay(), red, green, blue);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void createSelectionHighlightGradientColors(Color start)
/*      */   {
/*  499 */     disposeSelectionHighlightGradientColors();
/*      */     
/*  501 */     if (start == null) {
/*  502 */       return;
/*      */     }
/*      */     
/*  505 */     int fadeGradientSize = this.parent.tabHeight;
/*      */     
/*  507 */     RGB from = start.getRGB();
/*  508 */     RGB to = this.parent.selectionBackground.getRGB();
/*      */     
/*  510 */     this.selectionHighlightGradientColorsCache = new Color[fadeGradientSize];
/*  511 */     int denom = fadeGradientSize - 1;
/*      */     
/*  513 */     for (int i = 0; i < fadeGradientSize; i++) {
/*  514 */       int propFrom = denom - i;
/*  515 */       int propTo = i;
/*  516 */       int red = (to.red * propTo + from.red * propFrom) / denom;
/*  517 */       int green = (to.green * propTo + from.green * propFrom) / denom;
/*  518 */       int blue = (to.blue * propTo + from.blue * propFrom) / denom;
/*  519 */       this.selectionHighlightGradientColorsCache[i] = new Color(this.parent.getDisplay(), red, green, blue);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void dispose()
/*      */   {
/*  531 */     disposeAntialiasColors();
/*  532 */     disposeSelectionHighlightGradientColors();
/*  533 */     if (this.fillColor != null) {
/*  534 */       this.fillColor.dispose();
/*  535 */       this.fillColor = null;
/*      */     }
/*      */   }
/*      */   
/*      */   void disposeAntialiasColors() {
/*  540 */     if (this.tabAreaColor != null) this.tabAreaColor.dispose();
/*  541 */     if (this.selectedInnerColor != null) this.selectedInnerColor.dispose();
/*  542 */     if (this.selectedOuterColor != null) this.selectedOuterColor.dispose();
/*  543 */     this.tabAreaColor = (this.selectedInnerColor = this.selectedOuterColor = null);
/*      */   }
/*      */   
/*      */   void disposeSelectionHighlightGradientColors() {
/*  547 */     if (this.selectionHighlightGradientColorsCache == null)
/*  548 */       return;
/*  549 */     for (Color element : this.selectionHighlightGradientColorsCache) {
/*  550 */       element.dispose();
/*      */     }
/*  552 */     this.selectionHighlightGradientColorsCache = null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void draw(int part, int state, Rectangle bounds, GC gc)
/*      */   {
/*  588 */     switch (part) {
/*      */     case -4: 
/*  590 */       drawBackground(gc, bounds, state);
/*  591 */       break;
/*      */     case -1: 
/*  593 */       drawBody(gc, bounds, state);
/*  594 */       break;
/*      */     case -2: 
/*  596 */       drawTabArea(gc, bounds, state);
/*  597 */       break;
/*      */     case -5: 
/*  599 */       drawMaximize(gc, bounds, state);
/*  600 */       break;
/*      */     case -6: 
/*  602 */       drawMinimize(gc, bounds, state);
/*  603 */       break;
/*      */     case -7: 
/*  605 */       drawChevron(gc, bounds, state);
/*  606 */       break;
/*      */     case -3: default: 
/*  608 */       if ((0 <= part) && (part < this.parent.getItemCount())) {
/*  609 */         if ((bounds.width == 0) || (bounds.height == 0)) return;
/*  610 */         if ((state & 0x2) != 0) {
/*  611 */           drawSelected(part, gc, bounds, state);
/*      */         } else {
/*  613 */           drawUnselected(part, gc, bounds, state);
/*      */         }
/*      */       }
/*      */       break;
/*      */     }
/*      */   }
/*      */   
/*      */   void drawBackground(GC gc, Rectangle bounds, int state) {
/*  621 */     boolean selected = (state & 0x2) != 0;
/*  622 */     Color defaultBackground = (selected) && (this.parent.shouldHighlight()) ? this.parent.selectionBackground : this.parent.getBackground();
/*  623 */     Image image = selected ? this.parent.selectionBgImage : null;
/*  624 */     Color[] colors = (selected & this.parent.shouldHighlight()) ? this.parent.selectionGradientColors : this.parent.gradientColors;
/*  625 */     int[] percents = selected ? this.parent.selectionGradientPercents : this.parent.gradientPercents;
/*  626 */     boolean vertical = selected ? this.parent.selectionGradientVertical : this.parent.gradientVertical;
/*      */     
/*  628 */     drawBackground(gc, null, bounds.x, bounds.y, bounds.width, bounds.height, defaultBackground, image, colors, percents, vertical);
/*      */   }
/*      */   
/*      */   void drawBackground(GC gc, int[] shape, boolean selected) {
/*  632 */     Color defaultBackground = (selected) && (this.parent.shouldHighlight()) ? this.parent.selectionBackground : this.parent.getBackground();
/*  633 */     Image image = selected ? this.parent.selectionBgImage : null;
/*  634 */     Color[] colors = (selected) && (this.parent.shouldHighlight()) ? this.parent.selectionGradientColors : this.parent.gradientColors;
/*  635 */     int[] percents = selected ? this.parent.selectionGradientPercents : this.parent.gradientPercents;
/*  636 */     boolean vertical = selected ? this.parent.selectionGradientVertical : this.parent.gradientVertical;
/*  637 */     Point size = this.parent.getSize();
/*  638 */     int width = size.x;
/*  639 */     int height = this.parent.tabHeight + ((this.parent.getStyle() & 0x800000) != 0 ? 1 : 3);
/*  640 */     int x = 0;
/*      */     
/*  642 */     int borderLeft = this.parent.borderVisible ? 1 : 0;
/*  643 */     int borderTop = this.parent.onBottom ? borderLeft : 0;
/*  644 */     int borderBottom = this.parent.onBottom ? 0 : borderLeft;
/*      */     
/*  646 */     if (borderLeft > 0) {
/*  647 */       x++;width -= 2;
/*      */     }
/*  649 */     int y = this.parent.onBottom ? size.y - borderBottom - height : borderTop;
/*  650 */     drawBackground(gc, shape, x, y, width, height, defaultBackground, image, colors, percents, vertical);
/*      */   }
/*      */   
/*      */   void drawBackground(GC gc, int[] shape, int x, int y, int width, int height, Color defaultBackground, Image image, Color[] colors, int[] percents, boolean vertical) {
/*  654 */     Region clipping = null;Region region = null;
/*  655 */     if (shape != null) {
/*  656 */       clipping = new Region();
/*  657 */       gc.getClipping(clipping);
/*  658 */       region = new Region();
/*  659 */       region.add(shape);
/*  660 */       region.intersect(clipping);
/*  661 */       gc.setClipping(region);
/*      */     }
/*  663 */     if (image != null)
/*      */     {
/*  665 */       gc.setBackground(defaultBackground);
/*  666 */       gc.fillRectangle(x, y, width, height);
/*  667 */       Rectangle imageRect = image.getBounds();
/*  668 */       gc.drawImage(image, imageRect.x, imageRect.y, imageRect.width, imageRect.height, x, y, width, height);
/*  669 */     } else if (colors != null)
/*      */     {
/*  671 */       if (colors.length == 1) {
/*  672 */         Color background = colors[0] != null ? colors[0] : defaultBackground;
/*  673 */         gc.setBackground(background);
/*  674 */         gc.fillRectangle(x, y, width, height);
/*      */       }
/*  676 */       else if (vertical) {
/*  677 */         if (this.parent.onBottom) {
/*  678 */           int pos = 0;
/*  679 */           if (percents[(percents.length - 1)] < 100) {
/*  680 */             pos = (100 - percents[(percents.length - 1)]) * height / 100;
/*  681 */             gc.setBackground(defaultBackground);
/*  682 */             gc.fillRectangle(x, y, width, pos);
/*      */           }
/*  684 */           Color lastColor = colors[(colors.length - 1)];
/*  685 */           if (lastColor == null) lastColor = defaultBackground;
/*  686 */           for (int i = percents.length - 1; i >= 0; i--) {
/*  687 */             gc.setForeground(lastColor);
/*  688 */             lastColor = colors[i];
/*  689 */             if (lastColor == null) lastColor = defaultBackground;
/*  690 */             gc.setBackground(lastColor);
/*  691 */             int percentage = i > 0 ? percents[i] - percents[(i - 1)] : percents[i];
/*  692 */             int gradientHeight = percentage * height / 100;
/*  693 */             gc.fillGradientRectangle(x, y + pos, width, gradientHeight, true);
/*  694 */             pos += gradientHeight;
/*      */           }
/*      */         } else {
/*  697 */           Color lastColor = colors[0];
/*  698 */           if (lastColor == null) lastColor = defaultBackground;
/*  699 */           int pos = 0;
/*  700 */           for (int i = 0; i < percents.length; i++) {
/*  701 */             gc.setForeground(lastColor);
/*  702 */             lastColor = colors[(i + 1)];
/*  703 */             if (lastColor == null) lastColor = defaultBackground;
/*  704 */             gc.setBackground(lastColor);
/*  705 */             int percentage = i > 0 ? percents[i] - percents[(i - 1)] : percents[i];
/*  706 */             int gradientHeight = percentage * height / 100;
/*  707 */             gc.fillGradientRectangle(x, y + pos, width, gradientHeight, true);
/*  708 */             pos += gradientHeight;
/*      */           }
/*  710 */           if (pos < height) {
/*  711 */             gc.setBackground(defaultBackground);
/*  712 */             gc.fillRectangle(x, pos, width, height - pos + 1);
/*      */           }
/*      */         }
/*      */       } else {
/*  716 */         y = 0;
/*  717 */         height = this.parent.getSize().y;
/*  718 */         Color lastColor = colors[0];
/*  719 */         if (lastColor == null) lastColor = defaultBackground;
/*  720 */         int pos = 0;
/*  721 */         for (int i = 0; i < percents.length; i++) {
/*  722 */           gc.setForeground(lastColor);
/*  723 */           lastColor = colors[(i + 1)];
/*  724 */           if (lastColor == null) lastColor = defaultBackground;
/*  725 */           gc.setBackground(lastColor);
/*  726 */           int gradientWidth = percents[i] * width / 100 - pos;
/*  727 */           gc.fillGradientRectangle(x + pos, y, gradientWidth, height, false);
/*  728 */           pos += gradientWidth;
/*      */         }
/*  730 */         if (pos < width) {
/*  731 */           gc.setBackground(defaultBackground);
/*  732 */           gc.fillRectangle(x + pos, y, width - pos, height);
/*      */         }
/*      */         
/*      */       }
/*      */       
/*      */     }
/*  738 */     else if (((this.parent.getStyle() & 0x40000) != 0) || (!defaultBackground.equals(this.parent.getBackground()))) {
/*  739 */       gc.setBackground(defaultBackground);
/*  740 */       gc.fillRectangle(x, y, width, height);
/*      */     }
/*      */     
/*  743 */     if (shape != null) {
/*  744 */       gc.setClipping(clipping);
/*  745 */       clipping.dispose();
/*  746 */       region.dispose();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void drawBorder(GC gc, int[] shape)
/*      */   {
/*  758 */     gc.setForeground(this.parent.getDisplay().getSystemColor(18));
/*  759 */     gc.drawPolyline(shape);
/*      */   }
/*      */   
/*      */   void drawBody(GC gc, Rectangle bounds, int state) {
/*  763 */     Point size = new Point(bounds.width, bounds.height);
/*  764 */     int selectedIndex = this.parent.selectedIndex;
/*  765 */     int tabHeight = this.parent.tabHeight;
/*      */     
/*  767 */     int borderLeft = this.parent.borderVisible ? 1 : 0;
/*  768 */     int borderRight = borderLeft;
/*  769 */     int borderTop = this.parent.onBottom ? borderLeft : 0;
/*  770 */     int borderBottom = this.parent.onBottom ? 0 : borderLeft;
/*      */     
/*  772 */     int style = this.parent.getStyle();
/*  773 */     int highlight_header = (style & 0x800000) != 0 ? 1 : 3;
/*  774 */     int highlight_margin = (style & 0x800000) != 0 ? 0 : 2;
/*      */     
/*      */ 
/*  777 */     if (!this.parent.minimized) {
/*  778 */       int width = size.x - borderLeft - borderRight - 2 * highlight_margin;
/*  779 */       int height = size.y - borderTop - borderBottom - tabHeight - highlight_header - highlight_margin;
/*      */       
/*  781 */       if (highlight_margin > 0) {
/*  782 */         int[] shape = null;
/*  783 */         if (this.parent.onBottom) {
/*  784 */           int x1 = borderLeft;
/*  785 */           int y1 = borderTop;
/*  786 */           int x2 = size.x - borderRight;
/*  787 */           int y2 = size.y - borderBottom - tabHeight - highlight_header;
/*  788 */           shape = new int[] { x1, y1, x2, y1, x2, y2, x2 - highlight_margin, y2, x2 - highlight_margin, y1 + highlight_margin, x1 + highlight_margin, y1 + highlight_margin, x1 + highlight_margin, y2, x1, y2 };
/*      */         }
/*      */         else
/*      */         {
/*  792 */           int x1 = borderLeft;
/*  793 */           int y1 = borderTop + tabHeight + highlight_header;
/*  794 */           int x2 = size.x - borderRight;
/*  795 */           int y2 = size.y - borderBottom;
/*  796 */           shape = new int[] { x1, y1, x1 + highlight_margin, y1, x1 + highlight_margin, y2 - highlight_margin, x2 - highlight_margin, y2 - highlight_margin, x2 - highlight_margin, y1, x2, y1, x2, y2, x1, y2 };
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*  801 */         if ((selectedIndex != -1) && (this.parent.selectionGradientColors != null) && (this.parent.selectionGradientColors.length > 1) && (!this.parent.selectionGradientVertical)) {
/*  802 */           drawBackground(gc, shape, true);
/*  803 */         } else if ((selectedIndex == -1) && (this.parent.gradientColors != null) && (this.parent.gradientColors.length > 1) && (!this.parent.gradientVertical)) {
/*  804 */           drawBackground(gc, shape, false);
/*      */         } else {
/*  806 */           gc.setBackground(selectedIndex == -1 ? this.parent.getBackground() : this.parent.selectionBackground);
/*  807 */           gc.fillPolygon(shape);
/*      */         }
/*      */       }
/*      */       
/*  811 */       if ((this.parent.getStyle() & 0x40000) != 0) {
/*  812 */         gc.setBackground(this.parent.getBackground());
/*  813 */         int marginWidth = this.parent.marginWidth;
/*  814 */         int marginHeight = this.parent.marginHeight;
/*  815 */         int xClient = borderLeft + marginWidth + highlight_margin;
/*  816 */         int yClient; int yClient; if (this.parent.onBottom) {
/*  817 */           yClient = borderTop + highlight_margin + marginHeight;
/*      */         } else {
/*  819 */           yClient = borderTop + tabHeight + highlight_header + marginHeight;
/*      */         }
/*  821 */         gc.fillRectangle(xClient - marginWidth, yClient - marginHeight, width, height);
/*      */       }
/*      */     }
/*  824 */     else if ((this.parent.getStyle() & 0x40000) != 0) {
/*  825 */       int height = borderTop + tabHeight + highlight_header + borderBottom;
/*  826 */       if (size.y > height) {
/*  827 */         gc.setBackground(this.parent.getParent().getBackground());
/*  828 */         gc.fillRectangle(0, height, size.x, size.y - height);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  834 */     if (borderLeft > 0) {
/*  835 */       gc.setForeground(this.parent.getDisplay().getSystemColor(18));
/*  836 */       int x1 = borderLeft - 1;
/*  837 */       int x2 = size.x - borderRight;
/*  838 */       int y1 = this.parent.onBottom ? borderTop - 1 : borderTop + tabHeight;
/*  839 */       int y2 = this.parent.onBottom ? size.y - tabHeight - borderBottom - 1 : size.y - borderBottom;
/*  840 */       gc.drawLine(x1, y1, x1, y2);
/*  841 */       gc.drawLine(x2, y1, x2, y2);
/*  842 */       if (this.parent.onBottom) {
/*  843 */         gc.drawLine(x1, y1, x2, y1);
/*      */       } else {
/*  845 */         gc.drawLine(x1, y2, x2, y2);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   void drawClose(GC gc, Rectangle closeRect, int closeImageState) {
/*  851 */     if ((closeRect.width == 0) || (closeRect.height == 0)) return;
/*  852 */     Display display = this.parent.getDisplay();
/*      */     
/*      */ 
/*  855 */     int x = closeRect.x + Math.max(1, (closeRect.width - 9) / 2);
/*  856 */     int y = closeRect.y + Math.max(1, (closeRect.height - 9) / 2);
/*  857 */     y += (this.parent.onBottom ? -1 : 1);
/*      */     
/*  859 */     Color closeBorder = display.getSystemColor(17);
/*  860 */     switch (closeImageState & 0x2A) {
/*      */     case 0: 
/*  862 */       int[] shape = { x, y, x + 2, y, x + 4, y + 2, x + 5, y + 2, x + 7, y, x + 9, y, x + 9, y + 2, x + 7, y + 4, x + 7, y + 5, x + 9, y + 7, x + 9, y + 9, x + 7, y + 9, x + 5, y + 7, x + 4, y + 7, x + 2, y + 9, x, y + 9, x, y + 7, x + 2, y + 5, x + 2, y + 4, x, y + 2 };
/*      */       
/*      */ 
/*      */ 
/*  866 */       gc.setBackground(display.getSystemColor(25));
/*  867 */       gc.fillPolygon(shape);
/*  868 */       gc.setForeground(closeBorder);
/*  869 */       gc.drawPolygon(shape);
/*  870 */       break;
/*      */     
/*      */     case 32: 
/*  873 */       int[] shape = { x, y, x + 2, y, x + 4, y + 2, x + 5, y + 2, x + 7, y, x + 9, y, x + 9, y + 2, x + 7, y + 4, x + 7, y + 5, x + 9, y + 7, x + 9, y + 9, x + 7, y + 9, x + 5, y + 7, x + 4, y + 7, x + 2, y + 9, x, y + 9, x, y + 7, x + 2, y + 5, x + 2, y + 4, x, y + 2 };
/*      */       
/*      */ 
/*      */ 
/*  877 */       gc.setBackground(getFillColor());
/*  878 */       gc.fillPolygon(shape);
/*  879 */       gc.setForeground(closeBorder);
/*  880 */       gc.drawPolygon(shape);
/*  881 */       break;
/*      */     
/*      */     case 2: 
/*  884 */       int[] shape = { x + 1, y + 1, x + 3, y + 1, x + 5, y + 3, x + 6, y + 3, x + 8, y + 1, x + 10, y + 1, x + 10, y + 3, x + 8, y + 5, x + 8, y + 6, x + 10, y + 8, x + 10, y + 10, x + 8, y + 10, x + 6, y + 8, x + 5, y + 8, x + 3, y + 10, x + 1, y + 10, x + 1, y + 8, x + 3, y + 6, x + 3, y + 5, x + 1, y + 3 };
/*      */       
/*      */ 
/*      */ 
/*  888 */       gc.setBackground(getFillColor());
/*  889 */       gc.fillPolygon(shape);
/*  890 */       gc.setForeground(closeBorder);
/*  891 */       gc.drawPolygon(shape);
/*  892 */       break;
/*      */     
/*      */     case 8: 
/*  895 */       int[] shape = { x, y, x + 10, y, x + 10, y + 10, x, y + 10 };
/*  896 */       drawBackground(gc, shape, false);
/*  897 */       break;
/*      */     }
/*      */   }
/*      */   
/*      */   void drawChevron(GC gc, Rectangle chevronRect, int chevronImageState)
/*      */   {
/*  903 */     if ((chevronRect.width == 0) || (chevronRect.height == 0)) return;
/*  904 */     int selectedIndex = this.parent.selectedIndex;
/*      */     
/*  906 */     Display display = this.parent.getDisplay();
/*  907 */     Point dpi = display.getDPI();
/*  908 */     int fontHeight = 720 / dpi.y;
/*  909 */     FontData fd = this.parent.getFont().getFontData()[0];
/*  910 */     fd.setHeight(fontHeight);
/*  911 */     Font f = new Font(display, fd);
/*  912 */     int fHeight = f.getFontData()[0].getHeight() * dpi.y / 72;
/*  913 */     int indent = Math.max(2, (chevronRect.height - fHeight - 4) / 2);
/*  914 */     int x = chevronRect.x + 2;
/*  915 */     int y = chevronRect.y + indent;
/*      */     
/*  917 */     int itemCount = this.parent.getItemCount();
/*  918 */     int count; int count; if (this.parent.single) {
/*  919 */       count = selectedIndex == -1 ? itemCount : itemCount - 1;
/*      */     } else {
/*  921 */       int showCount = 0;
/*  922 */       while ((showCount < this.parent.priority.length) && (this.parent.items[this.parent.priority[showCount]].showing)) {
/*  923 */         showCount++;
/*      */       }
/*  925 */       count = itemCount - showCount;
/*      */     }
/*  927 */     String chevronString = count > 99 ? "99+" : String.valueOf(count);
/*  928 */     switch (chevronImageState & 0x22) {
/*      */     case 0: 
/*  930 */       Color chevronBorder = this.parent.single ? this.parent.getSelectionForeground() : this.parent.getForeground();
/*  931 */       gc.setForeground(chevronBorder);
/*  932 */       gc.setFont(f);
/*  933 */       gc.drawLine(x, y, x + 2, y + 2);
/*  934 */       gc.drawLine(x + 2, y + 2, x, y + 4);
/*  935 */       gc.drawLine(x + 1, y, x + 3, y + 2);
/*  936 */       gc.drawLine(x + 3, y + 2, x + 1, y + 4);
/*  937 */       gc.drawLine(x + 4, y, x + 6, y + 2);
/*  938 */       gc.drawLine(x + 6, y + 2, x + 4, y + 4);
/*  939 */       gc.drawLine(x + 5, y, x + 7, y + 2);
/*  940 */       gc.drawLine(x + 7, y + 2, x + 5, y + 4);
/*  941 */       gc.drawString(chevronString, x + 7, y + 3, true);
/*  942 */       break;
/*      */     
/*      */     case 32: 
/*  945 */       gc.setForeground(display.getSystemColor(17));
/*  946 */       gc.setBackground(display.getSystemColor(25));
/*  947 */       gc.setFont(f);
/*  948 */       gc.fillRoundRectangle(chevronRect.x, chevronRect.y, chevronRect.width, chevronRect.height, 6, 6);
/*  949 */       gc.drawRoundRectangle(chevronRect.x, chevronRect.y, chevronRect.width - 1, chevronRect.height - 1, 6, 6);
/*  950 */       gc.drawLine(x, y, x + 2, y + 2);
/*  951 */       gc.drawLine(x + 2, y + 2, x, y + 4);
/*  952 */       gc.drawLine(x + 1, y, x + 3, y + 2);
/*  953 */       gc.drawLine(x + 3, y + 2, x + 1, y + 4);
/*  954 */       gc.drawLine(x + 4, y, x + 6, y + 2);
/*  955 */       gc.drawLine(x + 6, y + 2, x + 4, y + 4);
/*  956 */       gc.drawLine(x + 5, y, x + 7, y + 2);
/*  957 */       gc.drawLine(x + 7, y + 2, x + 5, y + 4);
/*  958 */       gc.drawString(chevronString, x + 7, y + 3, true);
/*  959 */       break;
/*      */     
/*      */     case 2: 
/*  962 */       gc.setForeground(display.getSystemColor(17));
/*  963 */       gc.setBackground(display.getSystemColor(25));
/*  964 */       gc.setFont(f);
/*  965 */       gc.fillRoundRectangle(chevronRect.x, chevronRect.y, chevronRect.width, chevronRect.height, 6, 6);
/*  966 */       gc.drawRoundRectangle(chevronRect.x, chevronRect.y, chevronRect.width - 1, chevronRect.height - 1, 6, 6);
/*  967 */       gc.drawLine(x + 1, y + 1, x + 3, y + 3);
/*  968 */       gc.drawLine(x + 3, y + 3, x + 1, y + 5);
/*  969 */       gc.drawLine(x + 2, y + 1, x + 4, y + 3);
/*  970 */       gc.drawLine(x + 4, y + 3, x + 2, y + 5);
/*  971 */       gc.drawLine(x + 5, y + 1, x + 7, y + 3);
/*  972 */       gc.drawLine(x + 7, y + 3, x + 5, y + 5);
/*  973 */       gc.drawLine(x + 6, y + 1, x + 8, y + 3);
/*  974 */       gc.drawLine(x + 8, y + 3, x + 6, y + 5);
/*  975 */       gc.drawString(chevronString, x + 8, y + 4, true);
/*      */     }
/*      */     
/*      */     
/*  979 */     f.dispose();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void drawHighlight(GC gc, Rectangle bounds, int state, int rightEdge)
/*      */   {
/*  989 */     if ((this.parent.simple) || (this.parent.onBottom)) {
/*  990 */       return;
/*      */     }
/*  992 */     if (this.selectionHighlightGradientBegin == null) {
/*  993 */       return;
/*      */     }
/*  995 */     Color[] gradients = this.selectionHighlightGradientColorsCache;
/*  996 */     if (gradients == null)
/*  997 */       return;
/*  998 */     int gradientsSize = gradients.length;
/*  999 */     if (gradientsSize == 0) {
/* 1000 */       return;
/*      */     }
/* 1002 */     int x = bounds.x;
/* 1003 */     int y = bounds.y;
/*      */     
/* 1005 */     gc.setForeground(gradients[0]);
/*      */     
/*      */ 
/* 1008 */     gc.drawLine(TOP_LEFT_CORNER_HILITE[0] + x + 1, 1 + y, rightEdge - this.curveIndent, 1 + y);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1014 */     int[] leftHighlightCurve = TOP_LEFT_CORNER_HILITE;
/*      */     
/* 1016 */     int d = this.parent.tabHeight - this.topCurveHighlightEnd.length / 2;
/*      */     
/* 1018 */     int lastX = 0;
/* 1019 */     int lastY = 0;
/* 1020 */     int lastColorIndex = 0;
/*      */     
/*      */ 
/* 1023 */     for (int i = 0; i < leftHighlightCurve.length / 2; i++) {
/* 1024 */       int rawX = leftHighlightCurve[(i * 2)];
/* 1025 */       int rawY = leftHighlightCurve[(i * 2 + 1)];
/* 1026 */       lastX = rawX + x;
/* 1027 */       lastY = rawY + y;
/* 1028 */       lastColorIndex = rawY - 1;
/* 1029 */       gc.setForeground(gradients[lastColorIndex]);
/* 1030 */       gc.drawPoint(lastX, lastY);
/*      */     }
/*      */     
/* 1033 */     for (int i = lastColorIndex; i < gradientsSize; i++) {
/* 1034 */       gc.setForeground(gradients[i]);
/* 1035 */       gc.drawPoint(lastX, 1 + lastY++);
/*      */     }
/*      */     
/* 1038 */     int rightEdgeOffset = rightEdge - this.curveIndent;
/*      */     
/*      */ 
/* 1041 */     for (int i = 0; i < this.topCurveHighlightStart.length / 2; i++) {
/* 1042 */       int rawX = this.topCurveHighlightStart[(i * 2)];
/* 1043 */       int rawY = this.topCurveHighlightStart[(i * 2 + 1)];
/* 1044 */       lastX = rawX + rightEdgeOffset;
/* 1045 */       lastY = rawY + y;
/* 1046 */       lastColorIndex = rawY - 1;
/* 1047 */       if (lastColorIndex >= gradientsSize)
/*      */         break;
/* 1049 */       gc.setForeground(gradients[lastColorIndex]);
/* 1050 */       gc.drawPoint(lastX, lastY);
/*      */     }
/*      */     
/* 1053 */     for (int i = lastColorIndex; i < lastColorIndex + d; i++) {
/* 1054 */       if (i >= gradientsSize)
/*      */         break;
/* 1056 */       gc.setForeground(gradients[i]);
/* 1057 */       gc.drawPoint(1 + lastX++, 1 + lastY++);
/*      */     }
/*      */     
/*      */ 
/* 1061 */     for (int i = 0; i < this.topCurveHighlightEnd.length / 2; i++) {
/* 1062 */       int rawX = this.topCurveHighlightEnd[(i * 2)];
/* 1063 */       int rawY = this.topCurveHighlightEnd[(i * 2 + 1)];
/* 1064 */       lastX = rawX + rightEdgeOffset;
/* 1065 */       lastY = rawY + y;
/* 1066 */       lastColorIndex = rawY - 1;
/* 1067 */       if (lastColorIndex >= gradientsSize)
/*      */         break;
/* 1069 */       gc.setForeground(gradients[lastColorIndex]);
/* 1070 */       gc.drawPoint(lastX, lastY);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void drawLeftUnselectedBorder(GC gc, Rectangle bounds, int state)
/*      */   {
/* 1080 */     int x = bounds.x;
/* 1081 */     int y = bounds.y;
/* 1082 */     int height = bounds.height;
/*      */     
/* 1084 */     int[] shape = null;
/* 1085 */     if (this.parent.onBottom) {
/* 1086 */       int[] left = this.parent.simple ? SIMPLE_UNSELECTED_INNER_CORNER : BOTTOM_LEFT_CORNER;
/*      */       
/*      */ 
/*      */ 
/* 1090 */       shape = new int[left.length + 2];
/* 1091 */       int index = 0;
/* 1092 */       shape[(index++)] = x;
/* 1093 */       shape[(index++)] = (y - 1);
/* 1094 */       for (int i = 0; i < left.length / 2; i++) {
/* 1095 */         shape[(index++)] = (x + left[(2 * i)]);
/* 1096 */         shape[(index++)] = (y + height + left[(2 * i + 1)] - 1);
/*      */       }
/*      */     } else {
/* 1099 */       int[] left = this.parent.simple ? SIMPLE_UNSELECTED_INNER_CORNER : TOP_LEFT_CORNER;
/*      */       
/*      */ 
/*      */ 
/* 1103 */       shape = new int[left.length + 2];
/* 1104 */       int index = 0;
/* 1105 */       shape[(index++)] = x;
/* 1106 */       shape[(index++)] = (y + height);
/* 1107 */       for (int i = 0; i < left.length / 2; i++) {
/* 1108 */         shape[(index++)] = (x + left[(2 * i)]);
/* 1109 */         shape[(index++)] = (y + left[(2 * i + 1)]);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1114 */     drawBorder(gc, shape);
/*      */   }
/*      */   
/*      */   void drawMaximize(GC gc, Rectangle maxRect, int maxImageState) {
/* 1118 */     if ((maxRect.width == 0) || (maxRect.height == 0)) return;
/* 1119 */     Display display = this.parent.getDisplay();
/*      */     
/* 1121 */     int x = maxRect.x + (maxRect.width - 10) / 2;
/* 1122 */     int y = maxRect.y + 3;
/*      */     
/* 1124 */     gc.setForeground(display.getSystemColor(17));
/* 1125 */     gc.setBackground(display.getSystemColor(25));
/*      */     
/* 1127 */     switch (maxImageState & 0x22) {
/*      */     case 0: 
/* 1129 */       if (!this.parent.getMaximized()) {
/* 1130 */         gc.fillRectangle(x, y, 9, 9);
/* 1131 */         gc.drawRectangle(x, y, 9, 9);
/* 1132 */         gc.drawLine(x, y + 2, x + 9, y + 2);
/*      */       } else {
/* 1134 */         gc.fillRectangle(x, y + 3, 5, 4);
/* 1135 */         gc.fillRectangle(x + 2, y, 5, 4);
/* 1136 */         gc.drawRectangle(x, y + 3, 5, 4);
/* 1137 */         gc.drawRectangle(x + 2, y, 5, 4);
/* 1138 */         gc.drawLine(x + 2, y + 1, x + 7, y + 1);
/* 1139 */         gc.drawLine(x, y + 4, x + 5, y + 4);
/*      */       }
/* 1141 */       break;
/*      */     
/*      */     case 32: 
/* 1144 */       gc.fillRoundRectangle(maxRect.x, maxRect.y, maxRect.width, maxRect.height, 6, 6);
/* 1145 */       gc.drawRoundRectangle(maxRect.x, maxRect.y, maxRect.width - 1, maxRect.height - 1, 6, 6);
/* 1146 */       if (!this.parent.getMaximized()) {
/* 1147 */         gc.fillRectangle(x, y, 9, 9);
/* 1148 */         gc.drawRectangle(x, y, 9, 9);
/* 1149 */         gc.drawLine(x, y + 2, x + 9, y + 2);
/*      */       } else {
/* 1151 */         gc.fillRectangle(x, y + 3, 5, 4);
/* 1152 */         gc.fillRectangle(x + 2, y, 5, 4);
/* 1153 */         gc.drawRectangle(x, y + 3, 5, 4);
/* 1154 */         gc.drawRectangle(x + 2, y, 5, 4);
/* 1155 */         gc.drawLine(x + 2, y + 1, x + 7, y + 1);
/* 1156 */         gc.drawLine(x, y + 4, x + 5, y + 4);
/*      */       }
/* 1158 */       break;
/*      */     
/*      */     case 2: 
/* 1161 */       gc.fillRoundRectangle(maxRect.x, maxRect.y, maxRect.width, maxRect.height, 6, 6);
/* 1162 */       gc.drawRoundRectangle(maxRect.x, maxRect.y, maxRect.width - 1, maxRect.height - 1, 6, 6);
/* 1163 */       if (!this.parent.getMaximized()) {
/* 1164 */         gc.fillRectangle(x + 1, y + 1, 9, 9);
/* 1165 */         gc.drawRectangle(x + 1, y + 1, 9, 9);
/* 1166 */         gc.drawLine(x + 1, y + 3, x + 10, y + 3);
/*      */       } else {
/* 1168 */         gc.fillRectangle(x + 1, y + 4, 5, 4);
/* 1169 */         gc.fillRectangle(x + 3, y + 1, 5, 4);
/* 1170 */         gc.drawRectangle(x + 1, y + 4, 5, 4);
/* 1171 */         gc.drawRectangle(x + 3, y + 1, 5, 4);
/* 1172 */         gc.drawLine(x + 3, y + 2, x + 8, y + 2);
/* 1173 */         gc.drawLine(x + 1, y + 5, x + 6, y + 5);
/*      */       }
/*      */       break;
/*      */     }
/*      */   }
/*      */   
/*      */   void drawMinimize(GC gc, Rectangle minRect, int minImageState) {
/* 1180 */     if ((minRect.width == 0) || (minRect.height == 0)) return;
/* 1181 */     Display display = this.parent.getDisplay();
/*      */     
/* 1183 */     int x = minRect.x + (minRect.width - 10) / 2;
/* 1184 */     int y = minRect.y + 3;
/*      */     
/* 1186 */     gc.setForeground(display.getSystemColor(17));
/* 1187 */     gc.setBackground(display.getSystemColor(25));
/*      */     
/* 1189 */     switch (minImageState & 0x22) {
/*      */     case 0: 
/* 1191 */       if (!this.parent.getMinimized()) {
/* 1192 */         gc.fillRectangle(x, y, 9, 3);
/* 1193 */         gc.drawRectangle(x, y, 9, 3);
/*      */       } else {
/* 1195 */         gc.fillRectangle(x, y + 3, 5, 4);
/* 1196 */         gc.fillRectangle(x + 2, y, 5, 4);
/* 1197 */         gc.drawRectangle(x, y + 3, 5, 4);
/* 1198 */         gc.drawRectangle(x + 2, y, 5, 4);
/* 1199 */         gc.drawLine(x + 3, y + 1, x + 6, y + 1);
/* 1200 */         gc.drawLine(x + 1, y + 4, x + 4, y + 4);
/*      */       }
/* 1202 */       break;
/*      */     
/*      */     case 32: 
/* 1205 */       gc.fillRoundRectangle(minRect.x, minRect.y, minRect.width, minRect.height, 6, 6);
/* 1206 */       gc.drawRoundRectangle(minRect.x, minRect.y, minRect.width - 1, minRect.height - 1, 6, 6);
/* 1207 */       if (!this.parent.getMinimized()) {
/* 1208 */         gc.fillRectangle(x, y, 9, 3);
/* 1209 */         gc.drawRectangle(x, y, 9, 3);
/*      */       } else {
/* 1211 */         gc.fillRectangle(x, y + 3, 5, 4);
/* 1212 */         gc.fillRectangle(x + 2, y, 5, 4);
/* 1213 */         gc.drawRectangle(x, y + 3, 5, 4);
/* 1214 */         gc.drawRectangle(x + 2, y, 5, 4);
/* 1215 */         gc.drawLine(x + 3, y + 1, x + 6, y + 1);
/* 1216 */         gc.drawLine(x + 1, y + 4, x + 4, y + 4);
/*      */       }
/* 1218 */       break;
/*      */     
/*      */     case 2: 
/* 1221 */       gc.fillRoundRectangle(minRect.x, minRect.y, minRect.width, minRect.height, 6, 6);
/* 1222 */       gc.drawRoundRectangle(minRect.x, minRect.y, minRect.width - 1, minRect.height - 1, 6, 6);
/* 1223 */       if (!this.parent.getMinimized()) {
/* 1224 */         gc.fillRectangle(x + 1, y + 1, 9, 3);
/* 1225 */         gc.drawRectangle(x + 1, y + 1, 9, 3);
/*      */       } else {
/* 1227 */         gc.fillRectangle(x + 1, y + 4, 5, 4);
/* 1228 */         gc.fillRectangle(x + 3, y + 1, 5, 4);
/* 1229 */         gc.drawRectangle(x + 1, y + 4, 5, 4);
/* 1230 */         gc.drawRectangle(x + 3, y + 1, 5, 4);
/* 1231 */         gc.drawLine(x + 4, y + 2, x + 7, y + 2);
/* 1232 */         gc.drawLine(x + 2, y + 5, x + 5, y + 5);
/*      */       }
/*      */       
/*      */ 
/*      */       break;
/*      */     }
/*      */     
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   void drawRightUnselectedBorder(GC gc, Rectangle bounds, int state)
/*      */   {
/* 1245 */     int x = bounds.x;
/* 1246 */     int y = bounds.y;
/* 1247 */     int width = bounds.width;
/* 1248 */     int height = bounds.height;
/*      */     
/* 1250 */     int[] shape = null;
/* 1251 */     int startX = x + width - 1;
/*      */     
/* 1253 */     if (this.parent.onBottom) {
/* 1254 */       int[] right = this.parent.simple ? SIMPLE_UNSELECTED_INNER_CORNER : BOTTOM_RIGHT_CORNER;
/*      */       
/*      */ 
/*      */ 
/* 1258 */       shape = new int[right.length + 2];
/* 1259 */       int index = 0;
/*      */       
/* 1261 */       for (int i = 0; i < right.length / 2; i++) {
/* 1262 */         shape[(index++)] = (startX + right[(2 * i)]);
/* 1263 */         shape[(index++)] = (y + height + right[(2 * i + 1)] - 1);
/*      */       }
/* 1265 */       shape[(index++)] = startX;
/* 1266 */       shape[(index++)] = (y - 1);
/*      */     } else {
/* 1268 */       int[] right = this.parent.simple ? SIMPLE_UNSELECTED_INNER_CORNER : TOP_RIGHT_CORNER;
/*      */       
/*      */ 
/*      */ 
/* 1272 */       shape = new int[right.length + 2];
/* 1273 */       int index = 0;
/*      */       
/* 1275 */       for (int i = 0; i < right.length / 2; i++) {
/* 1276 */         shape[(index++)] = (startX + right[(2 * i)]);
/* 1277 */         shape[(index++)] = (y + right[(2 * i + 1)]);
/*      */       }
/*      */       
/* 1280 */       shape[(index++)] = startX;
/* 1281 */       shape[(index++)] = (y + height);
/*      */     }
/*      */     
/*      */ 
/* 1285 */     drawBorder(gc, shape);
/*      */   }
/*      */   
/*      */   void drawSelected(int itemIndex, GC gc, Rectangle bounds, int state)
/*      */   {
/* 1290 */     CTabItem item = this.parent.items[itemIndex];
/* 1291 */     int x = bounds.x;
/* 1292 */     int y = bounds.y;
/* 1293 */     int height = bounds.height;
/* 1294 */     int width = bounds.width;
/* 1295 */     if ((!this.parent.simple) && (!this.parent.single)) width -= this.curveWidth - this.curveIndent;
/* 1296 */     int borderLeft = this.parent.borderVisible ? 1 : 0;
/* 1297 */     int borderRight = borderLeft;
/* 1298 */     int borderTop = this.parent.onBottom ? borderLeft : 0;
/* 1299 */     int borderBottom = this.parent.onBottom ? 0 : borderLeft;
/*      */     
/* 1301 */     Point size = this.parent.getSize();
/*      */     
/* 1303 */     int rightEdge = Math.min(x + width, this.parent.getRightItemEdge(gc));
/*      */     
/*      */ 
/* 1306 */     if ((state & 0x8) != 0) {
/* 1307 */       int highlight_header = (this.parent.getStyle() & 0x800000) != 0 ? 1 : 3;
/* 1308 */       int xx = borderLeft;
/* 1309 */       int yy = this.parent.onBottom ? size.y - borderBottom - this.parent.tabHeight - highlight_header : borderTop + this.parent.tabHeight + 1;
/* 1310 */       int ww = size.x - borderLeft - borderRight;
/* 1311 */       int hh = highlight_header - 1;
/* 1312 */       int[] shape = { xx, yy, xx + ww, yy, xx + ww, yy + hh, xx, yy + hh };
/* 1313 */       if ((this.parent.selectionGradientColors != null) && (!this.parent.selectionGradientVertical)) {
/* 1314 */         drawBackground(gc, shape, this.parent.shouldHighlight());
/*      */       } else {
/* 1316 */         gc.setBackground(this.parent.shouldHighlight() ? this.parent.selectionBackground : this.parent.getBackground());
/* 1317 */         gc.fillRectangle(xx, yy, ww, hh);
/*      */       }
/*      */       
/* 1320 */       if (this.parent.single) {
/* 1321 */         if (item.showing) {}
/*      */       }
/*      */       else
/*      */       {
/* 1325 */         if (!item.showing) {
/* 1326 */           int x1 = Math.max(0, borderLeft - 1);
/* 1327 */           int y1 = this.parent.onBottom ? y - 1 : y + height;
/* 1328 */           int x2 = size.x - borderRight;
/* 1329 */           gc.setForeground(this.parent.getDisplay().getSystemColor(18));
/* 1330 */           gc.drawLine(x1, y1, x2, y1);
/* 1331 */           return;
/*      */         }
/*      */         
/*      */ 
/* 1335 */         shape = null;
/* 1336 */         if (this.parent.onBottom) {
/* 1337 */           int[] left = this.parent.simple ? SIMPLE_BOTTOM_LEFT_CORNER : BOTTOM_LEFT_CORNER;
/* 1338 */           int[] right = this.parent.simple ? SIMPLE_BOTTOM_RIGHT_CORNER : this.curve;
/* 1339 */           if ((borderLeft == 0) && (itemIndex == this.parent.firstIndex)) {
/* 1340 */             left = new int[] { x, y + height };
/*      */           }
/* 1342 */           shape = new int[left.length + right.length + 8];
/* 1343 */           int index = 0;
/* 1344 */           shape[(index++)] = x;
/* 1345 */           shape[(index++)] = (y - 1);
/* 1346 */           shape[(index++)] = x;
/* 1347 */           shape[(index++)] = (y - 1);
/* 1348 */           for (int i = 0; i < left.length / 2; i++) {
/* 1349 */             shape[(index++)] = (x + left[(2 * i)]);
/* 1350 */             shape[(index++)] = (y + height + left[(2 * i + 1)] - 1);
/*      */           }
/* 1352 */           for (int i = 0; i < right.length / 2; i++) {
/* 1353 */             shape[(index++)] = (this.parent.simple ? rightEdge - 1 + right[(2 * i)] : rightEdge - this.curveIndent + right[(2 * i)]);
/* 1354 */             shape[(index++)] = (this.parent.simple ? y + height + right[(2 * i + 1)] - 1 : y + right[(2 * i + 1)] - 2);
/*      */           }
/* 1356 */           shape[(index++)] = (this.parent.simple ? rightEdge - 1 : rightEdge + this.curveWidth - this.curveIndent);
/* 1357 */           shape[(index++)] = (y - 1);
/* 1358 */           shape[(index++)] = (this.parent.simple ? rightEdge - 1 : rightEdge + this.curveWidth - this.curveIndent);
/* 1359 */           shape[(index++)] = (y - 1);
/*      */         } else {
/* 1361 */           int[] left = this.parent.simple ? SIMPLE_TOP_LEFT_CORNER : TOP_LEFT_CORNER;
/* 1362 */           int[] right = this.parent.simple ? SIMPLE_TOP_RIGHT_CORNER : this.curve;
/* 1363 */           if ((borderLeft == 0) && (itemIndex == this.parent.firstIndex)) {
/* 1364 */             left = new int[] { x, y };
/*      */           }
/* 1366 */           shape = new int[left.length + right.length + 8];
/* 1367 */           int index = 0;
/* 1368 */           shape[(index++)] = x;
/* 1369 */           shape[(index++)] = (y + height + 1);
/* 1370 */           shape[(index++)] = x;
/* 1371 */           shape[(index++)] = (y + height + 1);
/* 1372 */           for (int i = 0; i < left.length / 2; i++) {
/* 1373 */             shape[(index++)] = (x + left[(2 * i)]);
/* 1374 */             shape[(index++)] = (y + left[(2 * i + 1)]);
/*      */           }
/* 1376 */           for (int i = 0; i < right.length / 2; i++) {
/* 1377 */             shape[(index++)] = (this.parent.simple ? rightEdge - 1 + right[(2 * i)] : rightEdge - this.curveIndent + right[(2 * i)]);
/* 1378 */             shape[(index++)] = (y + right[(2 * i + 1)]);
/*      */           }
/* 1380 */           shape[(index++)] = (this.parent.simple ? rightEdge - 1 : rightEdge + this.curveWidth - this.curveIndent);
/* 1381 */           shape[(index++)] = (y + height + 1);
/* 1382 */           shape[(index++)] = (this.parent.simple ? rightEdge - 1 : rightEdge + this.curveWidth - this.curveIndent);
/* 1383 */           shape[(index++)] = (y + height + 1);
/*      */         }
/*      */         
/* 1386 */         Rectangle clipping = gc.getClipping();
/* 1387 */         Rectangle clipBounds = item.getBounds();
/* 1388 */         clipBounds.height += 1;
/* 1389 */         if (this.parent.onBottom) clipBounds.y -= 1;
/* 1390 */         boolean tabInPaint = clipping.intersects(clipBounds);
/*      */         
/* 1392 */         if (tabInPaint)
/*      */         {
/* 1394 */           if ((this.parent.selectionGradientColors != null) && (!this.parent.selectionGradientVertical)) {
/* 1395 */             drawBackground(gc, shape, true);
/*      */           } else {
/* 1397 */             Color defaultBackground = this.parent.shouldHighlight() ? this.parent.selectionBackground : this.parent.getBackground();
/* 1398 */             Image image = this.parent.selectionBgImage;
/* 1399 */             Color[] colors = this.parent.selectionGradientColors;
/* 1400 */             int[] percents = this.parent.selectionGradientPercents;
/* 1401 */             boolean vertical = this.parent.selectionGradientVertical;
/* 1402 */             xx = x;
/* 1403 */             yy = this.parent.onBottom ? y - 1 : y + 1;
/* 1404 */             ww = width;
/* 1405 */             hh = height;
/* 1406 */             if ((!this.parent.single) && (!this.parent.simple)) ww += this.curveWidth - this.curveIndent;
/* 1407 */             drawBackground(gc, shape, xx, yy, ww, hh, defaultBackground, image, colors, percents, vertical);
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 1413 */         drawHighlight(gc, bounds, state, rightEdge);
/*      */         
/*      */ 
/* 1416 */         shape[0] = Math.max(0, borderLeft - 1);
/* 1417 */         if ((borderLeft == 0) && (itemIndex == this.parent.firstIndex)) {
/* 1418 */           shape[1] = (this.parent.onBottom ? y + height - 1 : y);
/* 1419 */           shape[5] = (shape[3] = shape[1]);
/*      */         }
/* 1421 */         shape[(shape.length - 2)] = (size.x - borderRight + 1);
/* 1422 */         for (int i = 0; i < shape.length / 2; i++) {
/* 1423 */           if (shape[(2 * i + 1)] == y + height + 1) shape[(2 * i + 1)] -= 1;
/*      */         }
/* 1425 */         Color borderColor = this.parent.getDisplay().getSystemColor(18);
/* 1426 */         if (!borderColor.equals(this.lastBorderColor)) createAntialiasColors();
/* 1427 */         antialias(shape, this.selectedInnerColor, this.selectedOuterColor, gc);
/* 1428 */         gc.setForeground(borderColor);
/* 1429 */         gc.drawPolyline(shape);
/*      */         
/* 1431 */         if (!tabInPaint) { return;
/*      */         }
/*      */       }
/*      */     }
/* 1435 */     if ((state & 0x10) != 0)
/*      */     {
/* 1437 */       Rectangle trim = computeTrim(itemIndex, 0, 0, 0, 0, 0);
/* 1438 */       int xDraw = x - trim.x;
/* 1439 */       if ((this.parent.single) && ((this.parent.showClose) || (item.showClose))) xDraw += item.closeRect.width;
/* 1440 */       Image image = item.getImage();
/* 1441 */       if ((image != null) && (!image.isDisposed())) {
/* 1442 */         Rectangle imageBounds = image.getBounds();
/*      */         
/* 1444 */         int maxImageWidth = rightEdge - xDraw - (trim.width + trim.x);
/* 1445 */         if ((!this.parent.single) && (item.closeRect.width > 0)) maxImageWidth -= item.closeRect.width + 4;
/* 1446 */         if (imageBounds.width < maxImageWidth) {
/* 1447 */           int imageX = xDraw;
/* 1448 */           int imageY = y + (height - imageBounds.height) / 2;
/* 1449 */           imageY += (this.parent.onBottom ? -1 : 1);
/* 1450 */           gc.drawImage(image, imageX, imageY);
/* 1451 */           xDraw += imageBounds.width + 4;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 1456 */       int textWidth = rightEdge - xDraw - (trim.width + trim.x);
/* 1457 */       if ((!this.parent.single) && (item.closeRect.width > 0)) textWidth -= item.closeRect.width + 4;
/* 1458 */       if (textWidth > 0) {
/* 1459 */         Font gcFont = gc.getFont();
/* 1460 */         gc.setFont(item.font == null ? this.parent.getFont() : item.font);
/*      */         
/* 1462 */         if ((item.shortenedText == null) || (item.shortenedTextWidth != textWidth)) {
/* 1463 */           item.shortenedText = shortenText(gc, item.getText(), textWidth);
/* 1464 */           item.shortenedTextWidth = textWidth;
/*      */         }
/* 1466 */         Point extent = gc.textExtent(item.shortenedText, 11);
/* 1467 */         int textY = y + (height - extent.y) / 2;
/* 1468 */         textY += (this.parent.onBottom ? -1 : 1);
/*      */         
/* 1470 */         gc.setForeground(this.parent.selectionForeground);
/* 1471 */         gc.drawText(item.shortenedText, xDraw, textY, 11);
/* 1472 */         gc.setFont(gcFont);
/*      */         
/*      */ 
/* 1475 */         if (this.parent.isFocusControl()) {
/* 1476 */           Display display = this.parent.getDisplay();
/* 1477 */           if ((this.parent.simple) || (this.parent.single)) {
/* 1478 */             gc.setBackground(display.getSystemColor(2));
/* 1479 */             gc.setForeground(display.getSystemColor(1));
/* 1480 */             gc.drawFocus(xDraw - 1, textY - 1, extent.x + 2, extent.y + 2);
/*      */           } else {
/* 1482 */             gc.setForeground(display.getSystemColor(17));
/* 1483 */             gc.drawLine(xDraw, textY + extent.y + 1, xDraw + extent.x + 1, textY + extent.y + 1);
/*      */           }
/*      */         }
/*      */       }
/* 1487 */       if ((this.parent.showClose) || (item.showClose)) drawClose(gc, item.closeRect, item.closeImageState);
/*      */     }
/*      */   }
/*      */   
/*      */   void drawTabArea(GC gc, Rectangle bounds, int state) {
/* 1492 */     Point size = this.parent.getSize();
/* 1493 */     int[] shape = null;
/* 1494 */     Color borderColor = this.parent.getDisplay().getSystemColor(18);
/* 1495 */     int tabHeight = this.parent.tabHeight;
/* 1496 */     int style = this.parent.getStyle();
/*      */     
/* 1498 */     int borderLeft = this.parent.borderVisible ? 1 : 0;
/* 1499 */     int borderRight = borderLeft;
/* 1500 */     int borderTop = this.parent.onBottom ? borderLeft : 0;
/* 1501 */     int borderBottom = this.parent.onBottom ? 0 : borderLeft;
/*      */     
/* 1503 */     int selectedIndex = this.parent.selectedIndex;
/* 1504 */     int highlight_header = (style & 0x800000) != 0 ? 1 : 3;
/* 1505 */     if (tabHeight == 0) {
/* 1506 */       if (((style & 0x800000) != 0) && ((style & 0x800) == 0)) return;
/* 1507 */       int x1 = borderLeft - 1;
/* 1508 */       int x2 = size.x - borderRight;
/* 1509 */       int y1 = this.parent.onBottom ? size.y - borderBottom - highlight_header - 1 : borderTop + highlight_header;
/* 1510 */       int y2 = this.parent.onBottom ? size.y - borderBottom : borderTop;
/* 1511 */       if ((borderLeft > 0) && (this.parent.onBottom)) { y2--;
/*      */       }
/* 1513 */       shape = new int[] { x1, y1, x1, y2, x2, y2, x2, y1 };
/*      */       
/*      */ 
/* 1516 */       if ((selectedIndex != -1) && (this.parent.selectionGradientColors != null) && (this.parent.selectionGradientColors.length > 1) && (!this.parent.selectionGradientVertical)) {
/* 1517 */         drawBackground(gc, shape, true);
/* 1518 */       } else if ((selectedIndex == -1) && (this.parent.gradientColors != null) && (this.parent.gradientColors.length > 1) && (!this.parent.gradientVertical)) {
/* 1519 */         drawBackground(gc, shape, false);
/*      */       } else {
/* 1521 */         gc.setBackground(selectedIndex == -1 ? this.parent.getBackground() : this.parent.selectionBackground);
/* 1522 */         gc.fillPolygon(shape);
/*      */       }
/*      */       
/*      */ 
/* 1526 */       if (borderLeft > 0) {
/* 1527 */         gc.setForeground(borderColor);
/* 1528 */         gc.drawPolyline(shape);
/*      */       }
/* 1530 */       return;
/*      */     }
/*      */     
/* 1533 */     int x = Math.max(0, borderLeft - 1);
/* 1534 */     int y = this.parent.onBottom ? size.y - borderBottom - tabHeight : borderTop;
/* 1535 */     int width = size.x - borderLeft - borderRight + 1;
/* 1536 */     int height = tabHeight - 1;
/* 1537 */     boolean simple = this.parent.simple;
/*      */     
/* 1539 */     if (this.parent.onBottom) { int[] right;
/*      */       int[] left;
/* 1541 */       int[] right; if ((style & 0x800) != 0) {
/* 1542 */         int[] left = simple ? SIMPLE_BOTTOM_LEFT_CORNER : BOTTOM_LEFT_CORNER;
/* 1543 */         right = simple ? SIMPLE_BOTTOM_RIGHT_CORNER : BOTTOM_RIGHT_CORNER;
/*      */       } else {
/* 1545 */         left = simple ? SIMPLE_BOTTOM_LEFT_CORNER_BORDERLESS : BOTTOM_LEFT_CORNER_BORDERLESS;
/* 1546 */         right = simple ? SIMPLE_BOTTOM_RIGHT_CORNER_BORDERLESS : BOTTOM_RIGHT_CORNER_BORDERLESS;
/*      */       }
/* 1548 */       shape = new int[left.length + right.length + 4];
/* 1549 */       int index = 0;
/* 1550 */       shape[(index++)] = x;
/* 1551 */       shape[(index++)] = (y - highlight_header);
/* 1552 */       for (int i = 0; i < left.length / 2; i++) {
/* 1553 */         shape[(index++)] = (x + left[(2 * i)]);
/* 1554 */         shape[(index++)] = (y + height + left[(2 * i + 1)]);
/* 1555 */         if (borderLeft == 0) shape[(index - 1)] += 1;
/*      */       }
/* 1557 */       for (int i = 0; i < right.length / 2; i++) {
/* 1558 */         shape[(index++)] = (x + width + right[(2 * i)]);
/* 1559 */         shape[(index++)] = (y + height + right[(2 * i + 1)]);
/* 1560 */         if (borderLeft == 0) shape[(index - 1)] += 1;
/*      */       }
/* 1562 */       shape[(index++)] = (x + width);
/* 1563 */       shape[(index++)] = (y - highlight_header); } else { int[] right;
/*      */       int[] left;
/*      */       int[] right;
/* 1566 */       if ((style & 0x800) != 0) {
/* 1567 */         int[] left = simple ? SIMPLE_TOP_LEFT_CORNER : TOP_LEFT_CORNER;
/* 1568 */         right = simple ? SIMPLE_TOP_RIGHT_CORNER : TOP_RIGHT_CORNER;
/*      */       } else {
/* 1570 */         left = simple ? SIMPLE_TOP_LEFT_CORNER_BORDERLESS : TOP_LEFT_CORNER_BORDERLESS;
/* 1571 */         right = simple ? SIMPLE_TOP_RIGHT_CORNER_BORDERLESS : TOP_RIGHT_CORNER_BORDERLESS;
/*      */       }
/* 1573 */       shape = new int[left.length + right.length + 4];
/* 1574 */       int index = 0;
/* 1575 */       shape[(index++)] = x;
/* 1576 */       shape[(index++)] = (y + height + highlight_header + 1);
/* 1577 */       for (int i = 0; i < left.length / 2; i++) {
/* 1578 */         shape[(index++)] = (x + left[(2 * i)]);
/* 1579 */         shape[(index++)] = (y + left[(2 * i + 1)]);
/*      */       }
/* 1581 */       for (int i = 0; i < right.length / 2; i++) {
/* 1582 */         shape[(index++)] = (x + width + right[(2 * i)]);
/* 1583 */         shape[(index++)] = (y + right[(2 * i + 1)]);
/*      */       }
/* 1585 */       shape[(index++)] = (x + width);
/* 1586 */       shape[(index++)] = (y + height + highlight_header + 1);
/*      */     }
/*      */     
/* 1589 */     boolean single = this.parent.single;
/* 1590 */     boolean bkSelected = (single) && (selectedIndex != -1);
/* 1591 */     drawBackground(gc, shape, bkSelected);
/*      */     
/* 1593 */     Region r = new Region();
/* 1594 */     r.add(new Rectangle(x, y, width + 1, height + 1));
/* 1595 */     r.subtract(shape);
/* 1596 */     gc.setBackground(this.parent.getParent().getBackground());
/* 1597 */     fillRegion(gc, r);
/* 1598 */     r.dispose();
/*      */     
/*      */ 
/* 1601 */     if (selectedIndex == -1)
/*      */     {
/* 1603 */       int x1 = borderLeft;
/* 1604 */       int y1 = this.parent.onBottom ? size.y - borderBottom - tabHeight - 1 : borderTop + tabHeight;
/* 1605 */       int x2 = size.x - borderRight;
/* 1606 */       gc.setForeground(borderColor);
/* 1607 */       gc.drawLine(x1, y1, x2, y1);
/*      */     }
/*      */     
/*      */ 
/* 1611 */     if (borderLeft > 0) {
/* 1612 */       if (!borderColor.equals(this.lastBorderColor)) createAntialiasColors();
/* 1613 */       antialias(shape, null, this.tabAreaColor, gc);
/* 1614 */       gc.setForeground(borderColor);
/* 1615 */       gc.drawPolyline(shape);
/*      */     }
/*      */   }
/*      */   
/*      */   void drawUnselected(int index, GC gc, Rectangle bounds, int state) {
/* 1620 */     CTabItem item = this.parent.items[index];
/* 1621 */     int x = bounds.x;
/* 1622 */     int y = bounds.y;
/* 1623 */     int height = bounds.height;
/* 1624 */     int width = bounds.width;
/*      */     
/*      */ 
/* 1627 */     if (!item.showing) { return;
/*      */     }
/* 1629 */     Rectangle clipping = gc.getClipping();
/* 1630 */     if (!clipping.intersects(bounds)) { return;
/*      */     }
/* 1632 */     if ((state & 0x8) != 0) {
/* 1633 */       if ((index > 0) && (index < this.parent.selectedIndex)) {
/* 1634 */         drawLeftUnselectedBorder(gc, bounds, state);
/*      */       }
/* 1636 */       if (index > this.parent.selectedIndex) {
/* 1637 */         drawRightUnselectedBorder(gc, bounds, state);
/*      */       }
/*      */     }
/* 1640 */     if ((state & 0x10) != 0)
/*      */     {
/* 1642 */       Rectangle trim = computeTrim(index, 0, 0, 0, 0, 0);
/* 1643 */       int xDraw = x - trim.x;
/* 1644 */       Image image = item.getImage();
/* 1645 */       if ((image != null) && (!image.isDisposed()) && (this.parent.showUnselectedImage)) {
/* 1646 */         Rectangle imageBounds = image.getBounds();
/*      */         
/* 1648 */         int maxImageWidth = x + width - xDraw - (trim.width + trim.x);
/* 1649 */         if ((this.parent.showUnselectedClose) && ((this.parent.showClose) || (item.showClose))) {
/* 1650 */           maxImageWidth -= item.closeRect.width + 4;
/*      */         }
/* 1652 */         if (imageBounds.width < maxImageWidth) {
/* 1653 */           int imageX = xDraw;
/* 1654 */           int imageHeight = imageBounds.height;
/* 1655 */           int imageY = y + (height - imageHeight) / 2;
/* 1656 */           imageY += (this.parent.onBottom ? -1 : 1);
/* 1657 */           int imageWidth = imageBounds.width * imageHeight / imageBounds.height;
/* 1658 */           gc.drawImage(image, imageBounds.x, imageBounds.y, imageBounds.width, imageBounds.height, imageX, imageY, imageWidth, imageHeight);
/*      */           
/*      */ 
/* 1661 */           xDraw += imageWidth + 4;
/*      */         }
/*      */       }
/*      */       
/* 1665 */       int textWidth = x + width - xDraw - (trim.width + trim.x);
/* 1666 */       if ((this.parent.showUnselectedClose) && ((this.parent.showClose) || (item.showClose))) {
/* 1667 */         textWidth -= item.closeRect.width + 4;
/*      */       }
/* 1669 */       if (textWidth > 0) {
/* 1670 */         Font gcFont = gc.getFont();
/* 1671 */         gc.setFont(item.font == null ? this.parent.getFont() : item.font);
/* 1672 */         if ((item.shortenedText == null) || (item.shortenedTextWidth != textWidth)) {
/* 1673 */           item.shortenedText = shortenText(gc, item.getText(), textWidth);
/* 1674 */           item.shortenedTextWidth = textWidth;
/*      */         }
/* 1676 */         Point extent = gc.textExtent(item.shortenedText, 11);
/* 1677 */         int textY = y + (height - extent.y) / 2;
/* 1678 */         textY += (this.parent.onBottom ? -1 : 1);
/* 1679 */         gc.setForeground(this.parent.getForeground());
/* 1680 */         gc.drawText(item.shortenedText, xDraw, textY, 11);
/* 1681 */         gc.setFont(gcFont);
/*      */       }
/*      */       
/* 1684 */       if ((this.parent.showUnselectedClose) && ((this.parent.showClose) || (item.showClose))) drawClose(gc, item.closeRect, item.closeImageState);
/*      */     }
/*      */   }
/*      */   
/*      */   void fillRegion(GC gc, Region region)
/*      */   {
/* 1690 */     Region clipping = new Region();
/* 1691 */     gc.getClipping(clipping);
/* 1692 */     region.intersect(clipping);
/* 1693 */     gc.setClipping(region);
/* 1694 */     gc.fillRectangle(region.getBounds());
/* 1695 */     gc.setClipping(clipping);
/* 1696 */     clipping.dispose();
/*      */   }
/*      */   
/*      */   Color getFillColor() {
/* 1700 */     if (this.fillColor == null) {
/* 1701 */       this.fillColor = new Color(this.parent.getDisplay(), CLOSE_FILL);
/*      */     }
/* 1703 */     return this.fillColor;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   boolean isSelectionHighlightColorsCacheHit(Color start)
/*      */   {
/* 1712 */     if (this.selectionHighlightGradientColorsCache == null) {
/* 1713 */       return false;
/*      */     }
/*      */     
/* 1716 */     if (this.selectionHighlightGradientColorsCache.length < 2) {
/* 1717 */       return false;
/*      */     }
/* 1719 */     Color highlightBegin = this.selectionHighlightGradientColorsCache[0];
/* 1720 */     Color highlightEnd = this.selectionHighlightGradientColorsCache[(this.selectionHighlightGradientColorsCache.length - 1)];
/*      */     
/* 1722 */     if (!highlightBegin.equals(start)) {
/* 1723 */       return false;
/*      */     }
/*      */     
/* 1726 */     if (this.selectionHighlightGradientColorsCache.length != this.parent.tabHeight) {
/* 1727 */       return false;
/*      */     }
/*      */     
/* 1730 */     if (!highlightEnd.equals(this.parent.selectionBackground)) {
/* 1731 */       return false;
/*      */     }
/* 1733 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   void setSelectionHighlightGradientColor(Color start)
/*      */   {
/* 1740 */     this.selectionHighlightGradientBegin = null;
/*      */     
/* 1742 */     if (start == null) {
/* 1743 */       return;
/*      */     }
/*      */     
/* 1746 */     if (this.parent.getDisplay().getDepth() < 15) {
/* 1747 */       return;
/*      */     }
/*      */     
/* 1750 */     if (this.parent.selectionGradientColors.length < 2) {
/* 1751 */       return;
/*      */     }
/*      */     
/* 1754 */     this.selectionHighlightGradientBegin = start;
/*      */     
/* 1756 */     if (!isSelectionHighlightColorsCacheHit(start))
/* 1757 */       createSelectionHighlightGradientColors(start);
/*      */   }
/*      */   
/*      */   String shortenText(GC gc, String text, int width) {
/* 1761 */     return useEllipses() ? 
/* 1762 */       shortenText(gc, text, width, "...") : 
/* 1763 */       shortenText(gc, text, width, "");
/*      */   }
/*      */   
/*      */   String shortenText(GC gc, String text, int width, String ellipses) {
/* 1767 */     if (gc.textExtent(text, 11).x <= width) return text;
/* 1768 */     int ellipseWidth = gc.textExtent(ellipses, 11).x;
/* 1769 */     int length = text.length();
/* 1770 */     TextLayout layout = new TextLayout(this.parent.getDisplay());
/* 1771 */     layout.setText(text);
/* 1772 */     int end = layout.getPreviousOffset(length, 2);
/* 1773 */     while (end > 0) {
/* 1774 */       text = text.substring(0, end);
/* 1775 */       int l = gc.textExtent(text, 11).x;
/* 1776 */       if (l + ellipseWidth <= width) {
/*      */         break;
/*      */       }
/* 1779 */       end = layout.getPreviousOffset(end, 2);
/*      */     }
/* 1781 */     layout.dispose();
/* 1782 */     return text + ellipses;
/*      */   }
/*      */   
/*      */   void updateCurves()
/*      */   {
/* 1787 */     if (getClass().getName().equals("org.eclipse.e4.ui.workbench.renderers.swt.CTabRendering")) return;
/* 1788 */     int tabHeight = this.parent.tabHeight;
/* 1789 */     if (tabHeight == this.lastTabHeight) return;
/* 1790 */     if (this.parent.onBottom) {
/* 1791 */       int d = tabHeight - 12;
/* 1792 */       this.curve = new int[] { 0, 13 + d, 0, 12 + d, 2, 12 + d, 3, 11 + d, 5, 11 + d, 6, 10 + d, 7, 10 + d, 9, 8 + d, 10, 8 + d, 11, 7 + d, 11 + d, 7, 12 + d, 6, 13 + d, 6, 15 + d, 4, 16 + d, 4, 17 + d, 3, 19 + d, 3, 20 + d, 2, 22 + d, 2, 23 + d, 1 };
/*      */       
/*      */ 
/* 1795 */       this.curveWidth = (26 + d);
/* 1796 */       this.curveIndent = (this.curveWidth / 3);
/*      */     } else {
/* 1798 */       int d = tabHeight - 12;
/* 1799 */       this.curve = new int[] { 0, 0, 0, 1, 2, 1, 3, 2, 5, 2, 6, 3, 7, 3, 9, 5, 10, 5, 11, 6, 11 + d, 6 + d, 12 + d, 7 + d, 13 + d, 7 + d, 15 + d, 9 + d, 16 + d, 9 + d, 17 + d, 10 + d, 19 + d, 10 + d, 20 + d, 11 + d, 22 + d, 11 + d, 23 + d, 12 + d };
/*      */       
/*      */ 
/* 1802 */       this.curveWidth = (26 + d);
/* 1803 */       this.curveIndent = (this.curveWidth / 3);
/*      */       
/*      */ 
/* 1806 */       this.topCurveHighlightStart = new int[] { 0, 2, 1, 2, 2, 2, 3, 3, 4, 3, 5, 3, 6, 4, 7, 4, 8, 5, 9, 6, 10, 6 };
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1814 */       this.topCurveHighlightEnd = new int[] { 10 + d, 6 + d, 11 + d, 7 + d, 12 + d, 8 + d, 13 + d, 8 + d, 14 + d, 9 + d, 15 + d, 10 + d, 16 + d, 10 + d, 17 + d, 11 + d, 18 + d, 11 + d, 19 + d, 11 + d, 20 + d, 12 + d, 21 + d, 12 + d, 22 + d, 12 + d };
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   boolean useEllipses()
/*      */   {
/* 1829 */     return this.parent.simple;
/*      */   }
/*      */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/custom/CTabFolderRenderer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */