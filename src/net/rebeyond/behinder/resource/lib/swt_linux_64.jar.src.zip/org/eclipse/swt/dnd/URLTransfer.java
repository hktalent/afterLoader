/*     */ package org.eclipse.swt.dnd;
/*     */ 
/*     */ import org.eclipse.swt.internal.C;
/*     */ import org.eclipse.swt.internal.gtk.OS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class URLTransfer
/*     */   extends ByteArrayTransfer
/*     */ {
/*  33 */   static URLTransfer _instance = new URLTransfer();
/*     */   private static final String TEXT_UNICODE = "text/unicode";
/*     */   private static final String TEXT_XMOZURL = "text/x-moz-url";
/*  36 */   private static final int TEXT_UNICODE_ID = registerType("text/unicode");
/*  37 */   private static final int TEXT_XMOZURL_ID = registerType("text/x-moz-url");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static URLTransfer getInstance()
/*     */   {
/*  47 */     return _instance;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void javaToNative(Object object, TransferData transferData)
/*     */   {
/*  62 */     transferData.result = 0;
/*  63 */     if ((!checkURL(object)) || (!isSupportedType(transferData))) {
/*  64 */       DND.error(2003);
/*     */     }
/*  66 */     String string = (String)object;
/*  67 */     int charCount = string.length();
/*  68 */     char[] chars = new char[charCount + 1];
/*  69 */     string.getChars(0, charCount, chars, 0);
/*  70 */     int byteCount = chars.length * 2;
/*  71 */     long pValue = OS.g_malloc(byteCount);
/*  72 */     if (pValue == 0L) return;
/*  73 */     C.memmove(pValue, chars, byteCount);
/*  74 */     transferData.length = byteCount;
/*  75 */     transferData.format = 8;
/*  76 */     transferData.pValue = pValue;
/*  77 */     transferData.result = 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object nativeToJava(TransferData transferData)
/*     */   {
/*  92 */     if ((!isSupportedType(transferData)) || (transferData.pValue == 0L)) { return null;
/*     */     }
/*  94 */     int size = transferData.format * transferData.length / 8 / 2 * 2;
/*  95 */     if (size <= 0) return null;
/*  96 */     char[] chars = new char[size / 2];
/*  97 */     C.memmove(chars, transferData.pValue, size);
/*  98 */     String string = new String(chars);
/*  99 */     int end = string.indexOf(0);
/* 100 */     return end == -1 ? string : string.substring(0, end);
/*     */   }
/*     */   
/*     */   protected int[] getTypeIds()
/*     */   {
/* 105 */     return new int[] { TEXT_XMOZURL_ID, TEXT_UNICODE_ID };
/*     */   }
/*     */   
/*     */   protected String[] getTypeNames()
/*     */   {
/* 110 */     return new String[] { "text/x-moz-url", "text/unicode" };
/*     */   }
/*     */   
/*     */   boolean checkURL(Object object) {
/* 114 */     return (object != null) && ((object instanceof String)) && (((String)object).length() > 0);
/*     */   }
/*     */   
/*     */   protected boolean validate(Object object)
/*     */   {
/* 119 */     return checkURL(object);
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/dnd/URLTransfer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */