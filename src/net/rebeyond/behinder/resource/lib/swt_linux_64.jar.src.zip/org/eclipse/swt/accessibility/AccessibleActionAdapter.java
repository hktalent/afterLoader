package org.eclipse.swt.accessibility;

public class AccessibleActionAdapter
  implements AccessibleActionListener
{
  public void getActionCount(AccessibleActionEvent e) {}
  
  public void doAction(AccessibleActionEvent e) {}
  
  public void getDescription(AccessibleActionEvent e) {}
  
  public void getKeyBinding(AccessibleActionEvent e) {}
  
  public void getName(AccessibleActionEvent e) {}
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/accessibility/AccessibleActionAdapter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */