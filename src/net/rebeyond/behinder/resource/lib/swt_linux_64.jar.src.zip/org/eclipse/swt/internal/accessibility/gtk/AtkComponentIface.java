package org.eclipse.swt.internal.accessibility.gtk;

public class AtkComponentIface
{
  public long add_focus_handler;
  public long contains;
  public long ref_accessible_at_point;
  public long get_extents;
  public long get_position;
  public long get_size;
  public long grab_focus;
  public long remove_focus_handler;
  public long set_extents;
  public long set_position;
  public long set_size;
  public long get_layer;
  public long get_mdi_zorder;
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/internal/accessibility/gtk/AtkComponentIface.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */