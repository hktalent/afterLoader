/*     */ package org.eclipse.swt.widgets;
/*     */ 
/*     */ import java.util.function.Consumer;
/*     */ import org.eclipse.swt.SWT;
/*     */ import org.eclipse.swt.graphics.Device;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Synchronizer
/*     */ {
/*     */   Display display;
/*     */   int messageCount;
/*     */   RunnableLock[] messages;
/*  38 */   Object messageLock = new Object();
/*     */   
/*     */   Thread syncThread;
/*     */   
/*     */   static final int GROW_SIZE = 4;
/*     */   static final int MESSAGE_LIMIT = 64;
/*  44 */   static final boolean IS_COCOA = "cocoa".equals(SWT.getPlatform());
/*  45 */   static final boolean IS_GTK = "gtk".equals(SWT.getPlatform());
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Synchronizer(Display display)
/*     */   {
/*  53 */     this.display = display;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void moveAllEventsTo(Synchronizer toReceiveTheEvents)
/*     */   {
/*  65 */     synchronized (this.messageLock) {
/*  66 */       RunnableLock[] oldMessages = this.messages;
/*  67 */       this.messages = null;
/*  68 */       int oldMessageCount = this.messageCount;
/*  69 */       this.messageCount = 0; }
/*     */     int oldMessageCount;
/*  71 */     RunnableLock[] oldMessages; toReceiveTheEvents.addFirst(oldMessages, oldMessageCount);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void addFirst(RunnableLock[] toAdd, int numToAdd)
/*     */   {
/*  82 */     if (numToAdd <= 0) {
/*  83 */       return;
/*     */     }
/*  85 */     boolean wake = false;
/*  86 */     synchronized (this.messageLock) {
/*  87 */       int nextSize = this.messageCount + Math.max(numToAdd, 4);
/*  88 */       if (this.messages == null)
/*  89 */         this.messages = new RunnableLock[nextSize];
/*  90 */       if (this.messages.length < this.messageCount + numToAdd) {
/*  91 */         RunnableLock[] newMessages = new RunnableLock[nextSize];
/*  92 */         System.arraycopy(this.messages, 0, newMessages, numToAdd, this.messageCount);
/*  93 */         this.messages = newMessages;
/*     */       } else {
/*  95 */         System.arraycopy(this.messages, 0, this.messages, numToAdd, this.messageCount);
/*     */       }
/*  97 */       System.arraycopy(toAdd, 0, this.messages, 0, numToAdd);
/*  98 */       wake = this.messageCount == 0;
/*  99 */       this.messageCount += numToAdd;
/*     */     }
/* 101 */     if (wake)
/* 102 */       this.display.wakeThread();
/*     */   }
/*     */   
/*     */   void addLast(RunnableLock lock) {
/* 106 */     boolean wake = false;
/* 107 */     synchronized (this.messageLock) {
/* 108 */       if (this.messages == null) this.messages = new RunnableLock[4];
/* 109 */       if (this.messageCount == this.messages.length) {
/* 110 */         RunnableLock[] newMessages = new RunnableLock[this.messageCount + 4];
/* 111 */         System.arraycopy(this.messages, 0, newMessages, 0, this.messageCount);
/* 112 */         this.messages = newMessages;
/*     */       }
/* 114 */       this.messages[(this.messageCount++)] = lock;
/* 115 */       wake = this.messageCount == 1;
/*     */     }
/* 117 */     if (wake) { this.display.wakeThread();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void asyncExec(Runnable runnable)
/*     */   {
/* 132 */     if (runnable == null)
/*     */     {
/* 134 */       if ((!IS_GTK) && (!IS_COCOA)) {
/* 135 */         this.display.wake();
/* 136 */         return;
/*     */       }
/*     */     }
/* 139 */     addLast(new RunnableLock(runnable));
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   int getMessageCount()
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield 3	org/eclipse/swt/widgets/Synchronizer:messageLock	Ljava/lang/Object;
/*     */     //   4: dup
/*     */     //   5: astore_1
/*     */     //   6: monitorenter
/*     */     //   7: aload_0
/*     */     //   8: getfield 6	org/eclipse/swt/widgets/Synchronizer:messageCount	I
/*     */     //   11: aload_1
/*     */     //   12: monitorexit
/*     */     //   13: ireturn
/*     */     //   14: astore_2
/*     */     //   15: aload_1
/*     */     //   16: monitorexit
/*     */     //   17: aload_2
/*     */     //   18: athrow
/*     */     // Line number table:
/*     */     //   Java source line #143	-> byte code offset #0
/*     */     //   Java source line #144	-> byte code offset #7
/*     */     //   Java source line #145	-> byte code offset #14
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	19	0	this	Synchronizer
/*     */     //   5	11	1	Ljava/lang/Object;	Object
/*     */     //   14	4	2	localObject1	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   7	13	14	finally
/*     */     //   14	17	14	finally
/*     */   }
/*     */   
/*     */   void releaseSynchronizer()
/*     */   {
/* 149 */     this.display = null;
/* 150 */     this.messages = null;
/* 151 */     this.messageLock = null;
/* 152 */     this.syncThread = null;
/*     */   }
/*     */   
/*     */   RunnableLock removeFirst() {
/* 156 */     synchronized (this.messageLock) {
/* 157 */       if (this.messageCount == 0) return null;
/* 158 */       RunnableLock lock = this.messages[0];
/* 159 */       System.arraycopy(this.messages, 1, this.messages, 0, --this.messageCount);
/* 160 */       this.messages[this.messageCount] = null;
/* 161 */       if ((this.messageCount == 0) && 
/* 162 */         (this.messages.length > 64)) { this.messages = null;
/*     */       }
/* 164 */       return lock;
/*     */     }
/*     */   }
/*     */   
/*     */   boolean runAsyncMessages() {
/* 169 */     return runAsyncMessages(false);
/*     */   }
/*     */   
/*     */   boolean runAsyncMessages(boolean all) {
/* 173 */     boolean run = false;
/*     */     do {
/* 175 */       RunnableLock lock = removeFirst();
/* 176 */       if (lock == null) return run;
/* 177 */       run = true;
/* 178 */       synchronized (lock) {
/* 179 */         this.syncThread = lock.thread;
/* 180 */         this.display.sendPreEvent(0);
/*     */         try {
/* 182 */           lock.run(this.display);
/*     */         } catch (Throwable t) {
/* 184 */           lock.throwable = t;
/* 185 */           SWT.error(46, t);
/*     */         } finally {
/* 187 */           if ((this.display != null) && (!this.display.isDisposed())) {
/* 188 */             this.display.sendPostEvent(0);
/*     */           }
/* 190 */           this.syncThread = null;
/* 191 */           lock.notifyAll();
/*     */         }
/*     */       }
/* 194 */     } while (all);
/* 195 */     return run;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void syncExec(Runnable runnable)
/*     */   {
/* 213 */     RunnableLock lock = null;
/* 214 */     synchronized (Device.class) {
/* 215 */       if ((this.display == null) || (this.display.isDisposed())) SWT.error(45);
/* 216 */       if (!this.display.isValidThread()) {
/* 217 */         if (runnable == null) {
/* 218 */           this.display.wake();
/* 219 */           return;
/*     */         }
/* 221 */         lock = new RunnableLock(runnable);
/*     */         
/*     */ 
/*     */ 
/* 225 */         lock.thread = Thread.currentThread();
/* 226 */         addLast(lock);
/*     */       }
/*     */     }
/* 229 */     if (lock == null) {
/* 230 */       if (runnable != null) {
/* 231 */         this.display.sendPreEvent(0);
/*     */         try {
/* 233 */           runnable.run();
/*     */         } catch (RuntimeException exception) {
/* 235 */           this.display.getRuntimeExceptionHandler().accept(exception);
/*     */         } catch (Error error) {
/* 237 */           this.display.getErrorHandler().accept(error);
/*     */         } finally {
/* 239 */           if ((this.display != null) && (!this.display.isDisposed())) {
/* 240 */             this.display.sendPostEvent(0);
/*     */           }
/*     */         }
/*     */       }
/* 244 */       return;
/*     */     }
/* 246 */     synchronized (lock) {
/* 247 */       boolean interrupted = false;
/* 248 */       while (!lock.done()) {
/*     */         try {
/* 250 */           lock.wait();
/*     */         } catch (InterruptedException e) {
/* 252 */           interrupted = true;
/*     */         }
/*     */       }
/* 255 */       if (interrupted) {
/* 256 */         Thread.currentThread().interrupt();
/*     */       }
/* 258 */       if (lock.throwable != null) {
/* 259 */         SWT.error(46, lock.throwable);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/widgets/Synchronizer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */