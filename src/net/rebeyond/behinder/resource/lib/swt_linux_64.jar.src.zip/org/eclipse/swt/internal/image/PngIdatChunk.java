/*    */ package org.eclipse.swt.internal.image;
/*    */ 
/*    */ import org.eclipse.swt.SWT;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class PngIdatChunk
/*    */   extends PngChunk
/*    */ {
/*    */   static final int HEADER_BYTES_LENGTH = 2;
/*    */   static final int ADLER_FIELD_LENGTH = 4;
/*    */   static final int HEADER_BYTE1_DATA_OFFSET = 8;
/*    */   static final int HEADER_BYTE2_DATA_OFFSET = 9;
/*    */   static final int ADLER_DATA_OFFSET = 10;
/*    */   
/*    */   PngIdatChunk(byte headerByte1, byte headerByte2, byte[] data, int adler)
/*    */   {
/* 25 */     super(data.length + 2 + 4);
/* 26 */     setType(TYPE_IDAT);
/* 27 */     this.reference[8] = headerByte1;
/* 28 */     this.reference[9] = headerByte2;
/* 29 */     System.arraycopy(data, 0, this.reference, 8, data.length);
/* 30 */     setInt32(10, adler);
/* 31 */     setCRC(computeCRC());
/*    */   }
/*    */   
/*    */   PngIdatChunk(byte[] reference) {
/* 35 */     super(reference);
/*    */   }
/*    */   
/*    */   int getChunkType()
/*    */   {
/* 40 */     return 2;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   void validate(PngFileReadState readState, PngIhdrChunk headerChunk)
/*    */   {
/* 48 */     if ((!readState.readIHDR) || 
/* 49 */       ((headerChunk.getMustHavePalette()) && (!readState.readPLTE)) || (readState.readIEND))
/*    */     {
/*    */ 
/* 52 */       SWT.error(40);
/*    */     } else {
/* 54 */       readState.readIDAT = true;
/*    */     }
/*    */     
/* 57 */     super.validate(readState, headerChunk);
/*    */   }
/*    */   
/*    */   byte getDataByteAtOffset(int offset) {
/* 61 */     return this.reference[(8 + offset)];
/*    */   }
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/internal/image/PngIdatChunk.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */