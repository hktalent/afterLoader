/*     */ package org.eclipse.swt.internal.image;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import org.eclipse.swt.SWT;
/*     */ import org.eclipse.swt.graphics.ImageData;
/*     */ import org.eclipse.swt.graphics.ImageLoader;
/*     */ import org.eclipse.swt.graphics.PaletteData;
/*     */ import org.eclipse.swt.graphics.RGB;
/*     */ 
/*     */ 
/*     */ public final class OS2BMPFileFormat
/*     */   extends FileFormat
/*     */ {
/*     */   static final int BMPFileHeaderSize = 14;
/*     */   static final int BMPHeaderFixedSize = 12;
/*     */   int width;
/*     */   int height;
/*     */   int bitCount;
/*     */   
/*     */   boolean isFileFormat(LEDataInputStream stream)
/*     */   {
/*     */     try
/*     */     {
/*  26 */       byte[] header = new byte[18];
/*  27 */       stream.read(header);
/*  28 */       stream.unread(header);
/*  29 */       int infoHeaderSize = header[14] & 0xFF | (header[15] & 0xFF) << 8 | (header[16] & 0xFF) << 16 | (header[17] & 0xFF) << 24;
/*  30 */       return (header[0] == 66) && (header[1] == 77) && (infoHeaderSize == 12);
/*     */     } catch (Exception e) {}
/*  32 */     return false;
/*     */   }
/*     */   
/*     */   byte[] loadData(byte[] infoHeader) {
/*  36 */     int stride = (this.width * this.bitCount + 7) / 8;
/*  37 */     stride = (stride + 3) / 4 * 4;
/*  38 */     byte[] data = loadData(infoHeader, stride);
/*  39 */     flipScanLines(data, stride, this.height);
/*  40 */     return data;
/*     */   }
/*     */   
/*  43 */   byte[] loadData(byte[] infoHeader, int stride) { int dataSize = this.height * stride;
/*  44 */     byte[] data = new byte[dataSize];
/*     */     try {
/*  46 */       if (this.inputStream.read(data) != dataSize)
/*  47 */         SWT.error(40);
/*     */     } catch (IOException e) {
/*  49 */       SWT.error(39, e);
/*     */     }
/*  51 */     return data;
/*     */   }
/*     */   
/*  54 */   int[] loadFileHeader() { int[] header = new int[5];
/*     */     try {
/*  56 */       header[0] = this.inputStream.readShort();
/*  57 */       header[1] = this.inputStream.readInt();
/*  58 */       header[2] = this.inputStream.readShort();
/*  59 */       header[3] = this.inputStream.readShort();
/*  60 */       header[4] = this.inputStream.readInt();
/*     */     } catch (IOException e) {
/*  62 */       SWT.error(39, e);
/*     */     }
/*  64 */     if (header[0] != 19778)
/*  65 */       SWT.error(40);
/*  66 */     return header;
/*     */   }
/*     */   
/*     */   ImageData[] loadFromByteStream() {
/*  70 */     int[] fileHeader = loadFileHeader();
/*  71 */     byte[] infoHeader = new byte[12];
/*     */     try {
/*  73 */       this.inputStream.read(infoHeader);
/*     */     } catch (Exception e) {
/*  75 */       SWT.error(39, e);
/*     */     }
/*  77 */     this.width = (infoHeader[4] & 0xFF | (infoHeader[5] & 0xFF) << 8);
/*  78 */     this.height = (infoHeader[6] & 0xFF | (infoHeader[7] & 0xFF) << 8);
/*  79 */     this.bitCount = (infoHeader[10] & 0xFF | (infoHeader[11] & 0xFF) << 8);
/*  80 */     PaletteData palette = loadPalette(infoHeader);
/*  81 */     if (this.inputStream.getPosition() < fileHeader[4]) {
/*     */       try
/*     */       {
/*  84 */         this.inputStream.skip(fileHeader[4] - this.inputStream.getPosition());
/*     */       } catch (IOException e) {
/*  86 */         SWT.error(39, e);
/*     */       }
/*     */     }
/*  89 */     byte[] data = loadData(infoHeader);
/*  90 */     int type = 7;
/*  91 */     return new ImageData[] {
/*  92 */       ImageData.internal_new(this.width, this.height, this.bitCount, palette, 4, data, 0, null, null, -1, -1, type, 0, 0, 0, 0) };
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   PaletteData loadPalette(byte[] infoHeader)
/*     */   {
/* 112 */     if (this.bitCount <= 8) {
/* 113 */       int numColors = 1 << this.bitCount;
/* 114 */       byte[] buf = new byte[numColors * 3];
/*     */       try {
/* 116 */         if (this.inputStream.read(buf) != buf.length)
/* 117 */           SWT.error(40);
/*     */       } catch (IOException e) {
/* 119 */         SWT.error(39, e);
/*     */       }
/* 121 */       return paletteFromBytes(buf, numColors);
/*     */     }
/* 123 */     if (this.bitCount == 16) return new PaletteData(31744, 992, 31);
/* 124 */     if (this.bitCount == 24) return new PaletteData(255, 65280, 16711680);
/* 125 */     return new PaletteData(65280, 16711680, -16777216);
/*     */   }
/*     */   
/* 128 */   PaletteData paletteFromBytes(byte[] bytes, int numColors) { int bytesOffset = 0;
/* 129 */     RGB[] colors = new RGB[numColors];
/* 130 */     for (int i = 0; i < numColors; i++) {
/* 131 */       colors[i] = new RGB(bytes[(bytesOffset + 2)] & 0xFF, bytes[(bytesOffset + 1)] & 0xFF, bytes[bytesOffset] & 0xFF);
/*     */       
/*     */ 
/* 134 */       bytesOffset += 3;
/*     */     }
/* 136 */     return new PaletteData(colors);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   static byte[] paletteToBytes(PaletteData pal)
/*     */   {
/* 143 */     int n = pal.colors.length < 256 ? pal.colors.length : pal.colors == null ? 0 : 256;
/* 144 */     byte[] bytes = new byte[n * 3];
/* 145 */     int offset = 0;
/* 146 */     for (int i = 0; i < n; i++) {
/* 147 */       RGB col = pal.colors[i];
/* 148 */       bytes[offset] = ((byte)col.blue);
/* 149 */       bytes[(offset + 1)] = ((byte)col.green);
/* 150 */       bytes[(offset + 2)] = ((byte)col.red);
/* 151 */       offset += 3;
/*     */     }
/* 153 */     return bytes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   int unloadData(ImageData image, OutputStream out)
/*     */   {
/* 160 */     int bmpBpl = 0;
/*     */     try {
/* 162 */       int bpl = (image.width * image.depth + 7) / 8;
/* 163 */       bmpBpl = (bpl + 3) / 4 * 4;
/* 164 */       int linesPerBuf = 32678 / bmpBpl;
/* 165 */       byte[] buf = new byte[linesPerBuf * bmpBpl];
/* 166 */       byte[] data = image.data;
/* 167 */       int imageBpl = image.bytesPerLine;
/* 168 */       int dataIndex = imageBpl * (image.height - 1);
/* 169 */       if (image.depth == 16) {
/* 170 */         for (int y = 0; y < image.height; y += linesPerBuf) {
/* 171 */           int count = image.height - y;
/* 172 */           if (linesPerBuf < count) count = linesPerBuf;
/* 173 */           int bufOffset = 0;
/* 174 */           for (int i = 0; i < count; i++) {
/* 175 */             for (int wIndex = 0; wIndex < bpl; wIndex += 2) {
/* 176 */               buf[(bufOffset + wIndex + 1)] = data[(dataIndex + wIndex + 1)];
/* 177 */               buf[(bufOffset + wIndex)] = data[(dataIndex + wIndex)];
/*     */             }
/* 179 */             bufOffset += bmpBpl;
/* 180 */             dataIndex -= imageBpl;
/*     */           }
/* 182 */           out.write(buf, 0, bufOffset);
/*     */         }
/*     */       } else {
/* 185 */         for (int y = 0; y < image.height; y += linesPerBuf) {
/* 186 */           int tmp = image.height - y;
/* 187 */           int count = tmp < linesPerBuf ? tmp : linesPerBuf;
/* 188 */           int bufOffset = 0;
/* 189 */           for (int i = 0; i < count; i++) {
/* 190 */             System.arraycopy(data, dataIndex, buf, bufOffset, bpl);
/* 191 */             bufOffset += bmpBpl;
/* 192 */             dataIndex -= imageBpl;
/*     */           }
/* 194 */           out.write(buf, 0, bufOffset);
/*     */         }
/*     */       }
/*     */     } catch (IOException e) {
/* 198 */       SWT.error(39, e);
/*     */     }
/* 200 */     return bmpBpl * image.height;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   void unloadIntoByteStream(ImageLoader loader)
/*     */   {
/* 208 */     ImageData image = loader.data[0];
/*     */     
/*     */ 
/* 211 */     if ((image.depth != 1) && (image.depth != 4) && (image.depth != 8) && (image.depth != 16) && (image.depth != 24) && (image.depth != 32))
/*     */     {
/* 213 */       SWT.error(38); }
/* 214 */     PaletteData pal = image.palette;
/* 215 */     byte[] rgbs; int numCols; byte[] rgbs; if ((image.depth == 16) || (image.depth == 24) || (image.depth == 32)) {
/* 216 */       if (!pal.isDirect)
/* 217 */         SWT.error(40);
/* 218 */       int numCols = 0;
/* 219 */       rgbs = null;
/*     */     } else {
/* 221 */       if (pal.isDirect)
/* 222 */         SWT.error(40);
/* 223 */       numCols = pal.colors.length;
/* 224 */       rgbs = paletteToBytes(pal);
/*     */     }
/*     */     
/* 227 */     int headersSize = 26;
/* 228 */     int[] fileHeader = new int[5];
/* 229 */     fileHeader[0] = 19778;
/* 230 */     fileHeader[1] = 0;
/* 231 */     fileHeader[2] = 0;
/* 232 */     fileHeader[3] = 0;
/* 233 */     fileHeader[4] = headersSize;
/* 234 */     if (rgbs != null) {
/* 235 */       fileHeader[4] += rgbs.length;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 240 */     ByteArrayOutputStream out = new ByteArrayOutputStream();
/* 241 */     unloadData(image, out);
/* 242 */     byte[] data = out.toByteArray();
/*     */     
/*     */ 
/* 245 */     fileHeader[1] = (fileHeader[4] + data.length);
/*     */     
/*     */     try
/*     */     {
/* 249 */       this.outputStream.writeShort(fileHeader[0]);
/* 250 */       this.outputStream.writeInt(fileHeader[1]);
/* 251 */       this.outputStream.writeShort(fileHeader[2]);
/* 252 */       this.outputStream.writeShort(fileHeader[3]);
/* 253 */       this.outputStream.writeInt(fileHeader[4]);
/*     */     } catch (IOException e) {
/* 255 */       SWT.error(39, e);
/*     */     }
/*     */     try {
/* 258 */       this.outputStream.writeInt(12);
/* 259 */       this.outputStream.writeShort(image.width);
/* 260 */       this.outputStream.writeShort(image.height);
/* 261 */       this.outputStream.writeShort(1);
/* 262 */       this.outputStream.writeShort((short)image.depth);
/*     */     } catch (IOException e) {
/* 264 */       SWT.error(39, e);
/*     */     }
/*     */     
/*     */ 
/* 268 */     if (numCols > 0) {
/*     */       try {
/* 270 */         this.outputStream.write(rgbs);
/*     */       } catch (IOException e) {
/* 272 */         SWT.error(39, e);
/*     */       }
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 278 */       this.outputStream.write(data);
/*     */     } catch (IOException e) {
/* 280 */       SWT.error(39, e);
/*     */     }
/*     */   }
/*     */   
/* 284 */   void flipScanLines(byte[] data, int stride, int height) { int i1 = 0;
/* 285 */     int i2 = (height - 1) * stride;
/* 286 */     for (int i = 0; i < height / 2; i++) {
/* 287 */       for (int index = 0; index < stride; index++) {
/* 288 */         byte b = data[(index + i1)];
/* 289 */         data[(index + i1)] = data[(index + i2)];
/* 290 */         data[(index + i2)] = b;
/*     */       }
/* 292 */       i1 += stride;
/* 293 */       i2 -= stride;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/internal/image/OS2BMPFileFormat.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */