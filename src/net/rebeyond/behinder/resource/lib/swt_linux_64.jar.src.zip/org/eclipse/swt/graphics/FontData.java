/*     */ package org.eclipse.swt.graphics;
/*     */ 
/*     */ import org.eclipse.swt.SWT;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class FontData
/*     */ {
/*     */   public String name;
/*     */   public float height;
/*     */   public int style;
/*     */   public byte[] string;
/*     */   String lang;
/*     */   String country;
/*     */   String variant;
/*     */   
/*     */   public FontData()
/*     */   {
/* 107 */     this("", 12, 0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FontData(String string)
/*     */   {
/* 130 */     if (string == null) SWT.error(4);
/* 131 */     int start = 0;
/* 132 */     int end = string.indexOf('|');
/* 133 */     if (end == -1) SWT.error(5);
/* 134 */     String version1 = string.substring(start, end);
/*     */     try {
/* 136 */       if (Integer.parseInt(version1) != 1) SWT.error(5);
/*     */     } catch (NumberFormatException e) {
/* 138 */       SWT.error(5);
/*     */     }
/*     */     
/* 141 */     start = end + 1;
/* 142 */     end = string.indexOf('|', start);
/* 143 */     if (end == -1) SWT.error(5);
/* 144 */     String name = string.substring(start, end);
/*     */     
/* 146 */     start = end + 1;
/* 147 */     end = string.indexOf('|', start);
/* 148 */     if (end == -1) SWT.error(5);
/* 149 */     float height = 0.0F;
/*     */     try {
/* 151 */       height = Float.parseFloat(string.substring(start, end));
/*     */     } catch (NumberFormatException e) {
/* 153 */       SWT.error(5);
/*     */     }
/*     */     
/* 156 */     start = end + 1;
/* 157 */     end = string.indexOf('|', start);
/* 158 */     if (end == -1) SWT.error(5);
/* 159 */     int style = 0;
/*     */     try {
/* 161 */       style = Integer.parseInt(string.substring(start, end));
/*     */     } catch (NumberFormatException e) {
/* 163 */       SWT.error(5);
/*     */     }
/*     */     
/* 166 */     start = end + 1;
/* 167 */     end = string.indexOf('|', start);
/* 168 */     setName(name);
/* 169 */     setHeight(height);
/* 170 */     setStyle(style);
/* 171 */     if (end == -1) return;
/* 172 */     String platform = string.substring(start, end);
/*     */     
/* 174 */     start = end + 1;
/* 175 */     end = string.indexOf('|', start);
/* 176 */     if (end == -1) return;
/* 177 */     String version2 = string.substring(start, end);
/*     */     
/* 179 */     if ((platform.equals("GTK")) && (version2.equals("1"))) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FontData(String name, int height, int style)
/*     */   {
/* 199 */     setName(name);
/* 200 */     setHeight(height);
/* 201 */     setStyle(style);
/*     */   }
/*     */   
/*     */   FontData(String name, float height, int style) {
/* 205 */     setName(name);
/* 206 */     setHeight(height);
/* 207 */     setStyle(style);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object object)
/*     */   {
/* 222 */     if (object == this) return true;
/* 223 */     if (!(object instanceof FontData)) return false;
/* 224 */     FontData data = (FontData)object;
/* 225 */     return (this.name.equals(data.name)) && (this.height == data.height) && (this.style == data.style);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getHeight()
/*     */   {
/* 236 */     return (int)(0.5F + this.height);
/*     */   }
/*     */   
/*     */   float getHeightF() {
/* 240 */     return this.height;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getLocale()
/*     */   {
/* 261 */     StringBuilder buffer = new StringBuilder();
/* 262 */     char sep = '_';
/* 263 */     if (this.lang != null) {
/* 264 */       buffer.append(this.lang);
/* 265 */       buffer.append(sep);
/*     */     }
/* 267 */     if (this.country != null) {
/* 268 */       buffer.append(this.country);
/* 269 */       buffer.append(sep);
/*     */     }
/* 271 */     if (this.variant != null) {
/* 272 */       buffer.append(this.variant);
/*     */     }
/*     */     
/* 275 */     String result = buffer.toString();
/* 276 */     int length = result.length();
/* 277 */     if ((length > 0) && 
/* 278 */       (result.charAt(length - 1) == sep)) {
/* 279 */       result = result.substring(0, length - 1);
/*     */     }
/*     */     
/* 282 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getName()
/*     */   {
/* 295 */     return this.name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getStyle()
/*     */   {
/* 308 */     return this.style;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 323 */     return this.name.hashCode() ^ getHeight() << 8 ^ this.style;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setHeight(int height)
/*     */   {
/* 340 */     if (height < 0) SWT.error(5);
/* 341 */     this.height = height;
/* 342 */     this.string = null;
/*     */   }
/*     */   
/*     */   void setHeight(float height) {
/* 346 */     if (height < 0.0F) SWT.error(5);
/* 347 */     this.height = height;
/* 348 */     this.string = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLocale(String locale)
/*     */   {
/* 369 */     this.lang = (this.country = this.variant = null);
/* 370 */     if (locale != null) {
/* 371 */       char sep = '_';
/* 372 */       int length = locale.length();
/*     */       
/*     */ 
/* 375 */       int firstSep = locale.indexOf(sep);
/* 376 */       int secondSep; if (firstSep == -1) { int secondSep;
/* 377 */         firstSep = secondSep = length;
/*     */       } else {
/* 379 */         secondSep = locale.indexOf(sep, firstSep + 1);
/* 380 */         if (secondSep == -1) secondSep = length;
/*     */       }
/* 382 */       if (firstSep > 0) this.lang = locale.substring(0, firstSep);
/* 383 */       if (secondSep > firstSep + 1) this.country = locale.substring(firstSep + 1, secondSep);
/* 384 */       if (length > secondSep + 1) { this.variant = locale.substring(secondSep + 1);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setName(String name)
/*     */   {
/* 414 */     if (name == null) SWT.error(4);
/* 415 */     this.name = name;
/* 416 */     this.string = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setStyle(int style)
/*     */   {
/* 430 */     this.style = style;
/* 431 */     this.string = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 445 */     StringBuilder buffer = new StringBuilder(128);
/* 446 */     buffer.append("1|");
/* 447 */     buffer.append(getName());
/* 448 */     buffer.append("|");
/* 449 */     buffer.append(getHeightF());
/* 450 */     buffer.append("|");
/* 451 */     buffer.append(getStyle());
/* 452 */     buffer.append("|");
/* 453 */     buffer.append("GTK|1|");
/* 454 */     return buffer.toString();
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/graphics/FontData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */