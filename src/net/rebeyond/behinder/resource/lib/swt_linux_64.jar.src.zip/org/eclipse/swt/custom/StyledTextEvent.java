/*    */ package org.eclipse.swt.custom;
/*    */ 
/*    */ import org.eclipse.swt.graphics.Color;
/*    */ import org.eclipse.swt.widgets.Event;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class StyledTextEvent
/*    */   extends Event
/*    */ {
/*    */   int[] ranges;
/*    */   StyleRange[] styles;
/*    */   int alignment;
/*    */   int indent;
/*    */   int wrapIndent;
/*    */   boolean justify;
/*    */   Bullet bullet;
/*    */   int bulletIndex;
/*    */   int[] tabStops;
/*    */   Color lineBackground;
/*    */   int replaceCharCount;
/*    */   int newCharCount;
/*    */   int replaceLineCount;
/*    */   int newLineCount;
/*    */   int x;
/*    */   int y;
/*    */   int ascent;
/*    */   int descent;
/*    */   StyleRange style;
/*    */   
/*    */   StyledTextEvent(StyledTextContent content)
/*    */   {
/* 46 */     this.data = content;
/*    */   }
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/custom/StyledTextEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */