/*    */ package org.eclipse.swt.browser;
/*    */ 
/*    */ import org.eclipse.swt.events.TypedEvent;
/*    */ import org.eclipse.swt.widgets.Widget;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AuthenticationEvent
/*    */   extends TypedEvent
/*    */ {
/*    */   public String location;
/*    */   public String user;
/*    */   public String password;
/* 40 */   public boolean doit = true;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   static final long serialVersionUID = -8322331206780057921L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public AuthenticationEvent(Widget widget)
/*    */   {
/* 52 */     super(widget);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String toString()
/*    */   {
/* 63 */     String string = super.toString();
/* 64 */     return string.substring(0, string.length() - 1) + " name=" + this.user + " password=" + this.password + " location=" + this.location + "}";
/*    */   }
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/browser/AuthenticationEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */