/*    */ package org.eclipse.swt.internal.image;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class JPEGAppn
/*    */   extends JPEGVariableSizeSegment
/*    */ {
/*    */   public JPEGAppn(byte[] reference)
/*    */   {
/* 17 */     super(reference);
/*    */   }
/*    */   
/*    */   public JPEGAppn(LEDataInputStream byteStream) {
/* 21 */     super(byteStream);
/*    */   }
/*    */   
/*    */   public boolean verify()
/*    */   {
/* 26 */     int marker = getSegmentMarker();
/* 27 */     return (marker >= 65504) && (marker <= 65519);
/*    */   }
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/internal/image/JPEGAppn.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */