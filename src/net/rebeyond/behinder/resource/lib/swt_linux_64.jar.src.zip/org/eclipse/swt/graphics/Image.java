/*      */ package org.eclipse.swt.graphics;
/*      */ 
/*      */ import java.io.InputStream;
/*      */ import org.eclipse.swt.SWT;
/*      */ import org.eclipse.swt.SWTException;
/*      */ import org.eclipse.swt.internal.C;
/*      */ import org.eclipse.swt.internal.Converter;
/*      */ import org.eclipse.swt.internal.DPIUtil;
/*      */ import org.eclipse.swt.internal.ImageList;
/*      */ import org.eclipse.swt.internal.cairo.Cairo;
/*      */ import org.eclipse.swt.internal.gtk.GDK;
/*      */ import org.eclipse.swt.internal.gtk.GTK;
/*      */ import org.eclipse.swt.internal.gtk.OS;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class Image
/*      */   extends Resource
/*      */   implements Drawable
/*      */ {
/*      */   public int type;
/*      */   public long pixmap;
/*      */   public long mask;
/*      */   public long surface;
/*  132 */   int transparentPixel = -1;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   GC memGC;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   byte[] alphaData;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  147 */   int alpha = -1;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  152 */   int width = -1;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  157 */   int height = -1;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final int DEFAULT_SCANLINE_PAD = 4;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private ImageFileNameProvider imageFileNameProvider;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private ImageDataProvider imageDataProvider;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  179 */   private int styleFlag = 0;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  184 */   private int currentDeviceZoom = 100;
/*      */   
/*      */   Image(Device device) {
/*  187 */     super(device);
/*  188 */     this.currentDeviceZoom = DPIUtil.getDeviceZoom();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Image(Device device, int width, int height)
/*      */   {
/*  227 */     super(device);
/*  228 */     Point size = DPIUtil.autoScaleUp(new Point(width, height));
/*  229 */     this.currentDeviceZoom = DPIUtil.getDeviceZoom();
/*  230 */     init(size.x, size.y);
/*  231 */     init();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Image(Device device, Image srcImage, int flag)
/*      */   {
/*  271 */     super(device);
/*  272 */     if (srcImage == null) SWT.error(4);
/*  273 */     if (srcImage.isDisposed()) SWT.error(5);
/*  274 */     switch (flag) {
/*      */     case 0: 
/*      */     case 1: 
/*      */     case 2: 
/*      */       break;
/*      */     default: 
/*  280 */       SWT.error(5);
/*      */     }
/*  282 */     device = this.device;
/*  283 */     this.type = srcImage.type;
/*  284 */     this.imageDataProvider = srcImage.imageDataProvider;
/*  285 */     this.imageFileNameProvider = srcImage.imageFileNameProvider;
/*  286 */     srcImage.styleFlag |= flag;
/*  287 */     this.currentDeviceZoom = srcImage.currentDeviceZoom;
/*      */     
/*  289 */     if (flag != 1) this.transparentPixel = srcImage.transparentPixel;
/*  290 */     this.alpha = srcImage.alpha;
/*  291 */     if (srcImage.alphaData != null) {
/*  292 */       this.alphaData = new byte[srcImage.alphaData.length];
/*  293 */       System.arraycopy(srcImage.alphaData, 0, this.alphaData, 0, this.alphaData.length);
/*      */     }
/*      */     
/*  296 */     long imageSurface = srcImage.surface;
/*  297 */     int width = this.width = srcImage.width;
/*  298 */     int height = this.height = srcImage.height;
/*  299 */     int format = Cairo.cairo_surface_get_content(imageSurface) == 4096 ? 1 : 0;
/*  300 */     boolean hasAlpha = format == 0;
/*  301 */     this.surface = Cairo.cairo_image_surface_create(format, width, height);
/*  302 */     if (this.surface == 0L) SWT.error(2);
/*  303 */     if (GTK.GTK3) {
/*  304 */       double scaleFactor = DPIUtil.getDeviceZoom() / 100.0F;
/*  305 */       Cairo.cairo_surface_set_device_scale(this.surface, scaleFactor, scaleFactor);
/*      */     }
/*  307 */     long cairo = Cairo.cairo_create(this.surface);
/*  308 */     if (cairo == 0L) SWT.error(2);
/*  309 */     Cairo.cairo_set_operator(cairo, 1);
/*  310 */     Cairo.cairo_set_source_surface(cairo, imageSurface, 0.0D, 0.0D);
/*  311 */     Cairo.cairo_paint(cairo);
/*  312 */     Cairo.cairo_destroy(cairo);
/*  313 */     if (flag != 0) {
/*  314 */       int stride = Cairo.cairo_image_surface_get_stride(this.surface);
/*  315 */       long data = Cairo.cairo_image_surface_get_data(this.surface);
/*      */       int ob;
/*  317 */       int oa; int or; int og; int ob; if (OS.BIG_ENDIAN) {
/*  318 */         int oa = 0;int or = 1;int og = 2;ob = 3;
/*      */       } else {
/*  320 */         oa = 3;or = 2;og = 1;ob = 0;
/*      */       }
/*  322 */       switch (flag) {
/*      */       case 1: 
/*  324 */         Color zeroColor = device.getSystemColor(18);
/*  325 */         RGB zeroRGB = zeroColor.getRGB();
/*  326 */         int zeroRed = zeroRGB.red;
/*  327 */         int zeroGreen = zeroRGB.green;
/*  328 */         int zeroBlue = zeroRGB.blue;
/*  329 */         Color oneColor = device.getSystemColor(22);
/*  330 */         RGB oneRGB = oneColor.getRGB();
/*  331 */         int oneRed = oneRGB.red;
/*  332 */         int oneGreen = oneRGB.green;
/*  333 */         int oneBlue = oneRGB.blue;
/*  334 */         byte[] line = new byte[stride];
/*  335 */         for (int y = 0; y < height; y++) {
/*  336 */           C.memmove(line, data + y * stride, stride);
/*  337 */           int x = 0; for (int offset = 0; x < width; offset += 4) {
/*  338 */             int a = line[(offset + oa)] & 0xFF;
/*  339 */             int r = line[(offset + or)] & 0xFF;
/*  340 */             int g = line[(offset + og)] & 0xFF;
/*  341 */             int b = line[(offset + ob)] & 0xFF;
/*  342 */             if ((hasAlpha) && (a != 0)) {
/*  343 */               r = (r * 255 + a / 2) / a;
/*  344 */               g = (g * 255 + a / 2) / a;
/*  345 */               b = (b * 255 + a / 2) / a;
/*      */             }
/*  347 */             int intensity = r * r + g * g + b * b;
/*  348 */             if (intensity < 98304) {
/*  349 */               r = zeroRed;
/*  350 */               g = zeroGreen;
/*  351 */               b = zeroBlue;
/*      */             } else {
/*  353 */               r = oneRed;
/*  354 */               g = oneGreen;
/*  355 */               b = oneBlue;
/*      */             }
/*  357 */             if (hasAlpha)
/*      */             {
/*  359 */               r = r * a + 128;
/*  360 */               r = r + (r >> 8) >> 8;
/*  361 */               g = g * a + 128;
/*  362 */               g = g + (g >> 8) >> 8;
/*  363 */               b = b * a + 128;
/*  364 */               b = b + (b >> 8) >> 8;
/*      */             }
/*  366 */             line[(offset + or)] = ((byte)r);
/*  367 */             line[(offset + og)] = ((byte)g);
/*  368 */             line[(offset + ob)] = ((byte)b);x++;
/*      */           }
/*      */           
/*      */ 
/*  370 */           C.memmove(data + y * stride, line, stride);
/*      */         }
/*  372 */         break;
/*      */       
/*      */       case 2: 
/*  375 */         byte[] line = new byte[stride];
/*  376 */         for (int y = 0; y < height; y++) {
/*  377 */           C.memmove(line, data + y * stride, stride);
/*  378 */           int x = 0; for (int offset = 0; x < width; offset += 4) {
/*  379 */             int a = line[(offset + oa)] & 0xFF;
/*  380 */             int r = line[(offset + or)] & 0xFF;
/*  381 */             int g = line[(offset + og)] & 0xFF;
/*  382 */             int b = line[(offset + ob)] & 0xFF;
/*  383 */             if ((hasAlpha) && (a != 0)) {
/*  384 */               r = (r * 255 + a / 2) / a;
/*  385 */               g = (g * 255 + a / 2) / a;
/*  386 */               b = (b * 255 + a / 2) / a;
/*      */             }
/*  388 */             int intensity = r + r + g + g + g + g + g + b >> 3;
/*  389 */             if (hasAlpha)
/*      */             {
/*  391 */               intensity = intensity * a + 128;
/*  392 */               intensity = intensity + (intensity >> 8) >> 8;
/*      */             }
/*  394 */             line[(offset + or)] = (line[(offset + og)] = line[(offset + ob)] = (byte)intensity);x++;
/*      */           }
/*  396 */           C.memmove(data + y * stride, line, stride);
/*      */         }
/*  398 */         break;
/*      */       }
/*      */       
/*      */     }
/*  402 */     init();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Image(Device device, Rectangle bounds)
/*      */   {
/*  441 */     super(device);
/*  442 */     if (bounds == null) SWT.error(4);
/*  443 */     this.currentDeviceZoom = DPIUtil.getDeviceZoom();
/*  444 */     Rectangle bounds1 = DPIUtil.autoScaleUp(bounds);
/*  445 */     init(bounds1.width, bounds1.height);
/*  446 */     init();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Image(Device device, ImageData data)
/*      */   {
/*  473 */     super(device);
/*  474 */     if (data == null) SWT.error(4);
/*  475 */     this.currentDeviceZoom = DPIUtil.getDeviceZoom();
/*  476 */     data = DPIUtil.autoScaleUp(device, data);
/*  477 */     init(data);
/*  478 */     init();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Image(Device device, ImageData source, ImageData mask)
/*      */   {
/*  512 */     super(device);
/*  513 */     if (source == null) SWT.error(4);
/*  514 */     if (mask == null) SWT.error(4);
/*  515 */     if ((source.width != mask.width) || (source.height != mask.height)) {
/*  516 */       SWT.error(5);
/*      */     }
/*  518 */     this.currentDeviceZoom = DPIUtil.getDeviceZoom();
/*  519 */     source = DPIUtil.autoScaleUp(device, source);
/*  520 */     mask = DPIUtil.autoScaleUp(device, mask);
/*  521 */     mask = ImageData.convertMask(mask);
/*  522 */     ImageData image = new ImageData(source.width, source.height, source.depth, source.palette, source.scanlinePad, source.data);
/*  523 */     image.maskPad = mask.scanlinePad;
/*  524 */     image.maskData = mask.data;
/*  525 */     init(image);
/*  526 */     init();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Image(Device device, InputStream stream)
/*      */   {
/*  583 */     super(device);
/*  584 */     ImageData data = new ImageData(stream);
/*  585 */     this.currentDeviceZoom = DPIUtil.getDeviceZoom();
/*  586 */     data = DPIUtil.autoScaleUp(device, data);
/*  587 */     init(data);
/*  588 */     init();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Image(Device device, String filename)
/*      */   {
/*  624 */     super(device);
/*  625 */     if (filename == null) { SWT.error(4);
/*      */     }
/*  627 */     ImageData data = new ImageData(filename);
/*  628 */     this.currentDeviceZoom = DPIUtil.getDeviceZoom();
/*  629 */     data = DPIUtil.autoScaleUp(device, data);
/*  630 */     init(data);
/*  631 */     init();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Image(Device device, ImageFileNameProvider imageFileNameProvider)
/*      */   {
/*  664 */     super(device);
/*  665 */     this.imageFileNameProvider = imageFileNameProvider;
/*  666 */     this.currentDeviceZoom = DPIUtil.getDeviceZoom();
/*  667 */     boolean[] found = new boolean[1];
/*  668 */     String filename = DPIUtil.validateAndGetImagePathAtZoom(imageFileNameProvider, this.currentDeviceZoom, found);
/*  669 */     if (found[0] != 0) {
/*  670 */       initNative(filename);
/*  671 */       if ((this.pixmap == 0L) && (this.surface == 0L)) {
/*  672 */         ImageData data = new ImageData(filename);
/*  673 */         init(data);
/*      */       }
/*      */     } else {
/*  676 */       ImageData imageData = new ImageData(filename);
/*  677 */       ImageData resizedData = DPIUtil.autoScaleUp(device, imageData);
/*  678 */       init(resizedData);
/*      */     }
/*  680 */     init();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Image(Device device, ImageDataProvider imageDataProvider)
/*      */   {
/*  713 */     super(device);
/*  714 */     this.imageDataProvider = imageDataProvider;
/*  715 */     this.currentDeviceZoom = DPIUtil.getDeviceZoom();
/*  716 */     boolean[] found = new boolean[1];
/*  717 */     ImageData data = DPIUtil.validateAndGetImageDataAtZoom(imageDataProvider, this.currentDeviceZoom, found);
/*  718 */     if (found[0] != 0) {
/*  719 */       init(data);
/*      */     } else {
/*  721 */       ImageData resizedData = DPIUtil.autoScaleUp(device, data);
/*  722 */       init(resizedData);
/*      */     }
/*  724 */     init();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   boolean refreshImageForZoom()
/*      */   {
/*  733 */     boolean refreshed = false;
/*  734 */     int deviceZoom = DPIUtil.getDeviceZoom();
/*  735 */     if (this.imageFileNameProvider != null) {
/*  736 */       int deviceZoomLevel = deviceZoom;
/*  737 */       if (deviceZoomLevel != this.currentDeviceZoom) {
/*  738 */         boolean[] found = new boolean[1];
/*  739 */         String filename = DPIUtil.validateAndGetImagePathAtZoom(this.imageFileNameProvider, deviceZoomLevel, found);
/*      */         
/*  741 */         if ((found[0] != 0) || (this.currentDeviceZoom != 100))
/*      */         {
/*  743 */           destroy();
/*  744 */           initNative(filename);
/*  745 */           if ((this.pixmap == 0L) && (this.surface == 0L)) {
/*  746 */             ImageData data = new ImageData(filename);
/*  747 */             init(data);
/*      */           }
/*  749 */           init();
/*  750 */           refreshed = true;
/*      */         }
/*  752 */         if (found[0] == 0)
/*      */         {
/*  754 */           destroy();
/*  755 */           ImageData imageData = new ImageData(filename);
/*  756 */           ImageData resizedData = DPIUtil.autoScaleUp(this.device, imageData);
/*  757 */           init(resizedData);
/*  758 */           init();
/*  759 */           refreshed = true;
/*      */         }
/*  761 */         this.currentDeviceZoom = deviceZoomLevel;
/*      */       }
/*  763 */     } else if (this.imageDataProvider != null) {
/*  764 */       int deviceZoomLevel = deviceZoom;
/*  765 */       if (deviceZoomLevel != this.currentDeviceZoom) {
/*  766 */         boolean[] found = new boolean[1];
/*  767 */         ImageData data = DPIUtil.validateAndGetImageDataAtZoom(this.imageDataProvider, deviceZoomLevel, found);
/*      */         
/*  769 */         if ((found[0] != 0) || (this.currentDeviceZoom != 100))
/*      */         {
/*  771 */           destroy();
/*  772 */           init(data);
/*  773 */           init();
/*  774 */           refreshed = true;
/*      */         }
/*  776 */         if (found[0] == 0)
/*      */         {
/*  778 */           destroy();
/*  779 */           ImageData resizedData = DPIUtil.autoScaleImageData(this.device, data, deviceZoomLevel, 100);
/*  780 */           init(resizedData);
/*  781 */           init();
/*  782 */           refreshed = true;
/*      */         }
/*  784 */         this.currentDeviceZoom = deviceZoomLevel;
/*      */       }
/*      */     } else {
/*  787 */       int deviceZoomLevel = deviceZoom;
/*  788 */       if (deviceZoomLevel != this.currentDeviceZoom) {
/*  789 */         ImageData data = getImageDataAtCurrentZoom();
/*  790 */         destroy();
/*  791 */         ImageData resizedData = DPIUtil.autoScaleImageData(this.device, data, deviceZoomLevel, this.currentDeviceZoom);
/*  792 */         init(resizedData);
/*  793 */         init();
/*  794 */         refreshed = true;
/*  795 */         this.currentDeviceZoom = deviceZoomLevel;
/*      */       }
/*      */     }
/*  798 */     return refreshed;
/*      */   }
/*      */   
/*      */   void initNative(String filename) {
/*      */     try {
/*  803 */       int length = filename.length();
/*  804 */       char[] chars = new char[length];
/*  805 */       filename.getChars(0, length, chars, 0);
/*  806 */       byte[] buffer = Converter.wcsToMbcs(chars, true);
/*  807 */       long pixbuf = GDK.gdk_pixbuf_new_from_file(buffer, null);
/*  808 */       if (pixbuf != 0L) {
/*      */         try {
/*  810 */           createFromPixbuf(0, pixbuf);
/*      */         } finally {
/*  812 */           if (pixbuf != 0L) OS.g_object_unref(pixbuf);
/*      */         }
/*      */       }
/*      */     } catch (SWTException localSWTException) {}
/*      */   }
/*      */   
/*      */   void createFromPixbuf(int type, long pixbuf) {
/*  819 */     this.type = type;
/*  820 */     boolean hasAlpha = GDK.gdk_pixbuf_get_has_alpha(pixbuf);
/*  821 */     int width = this.width = GDK.gdk_pixbuf_get_width(pixbuf);
/*  822 */     int height = this.height = GDK.gdk_pixbuf_get_height(pixbuf);
/*  823 */     int stride = GDK.gdk_pixbuf_get_rowstride(pixbuf);
/*  824 */     long pixels = GDK.gdk_pixbuf_get_pixels(pixbuf);
/*  825 */     int format = hasAlpha ? 0 : 1;
/*  826 */     this.surface = Cairo.cairo_image_surface_create(format, width, height);
/*  827 */     if (this.surface == 0L) SWT.error(2);
/*  828 */     if (GTK.GTK3) {
/*  829 */       double scaleFactor = DPIUtil.getDeviceZoom() / 100.0F;
/*  830 */       Cairo.cairo_surface_set_device_scale(this.surface, scaleFactor, scaleFactor);
/*      */     }
/*  832 */     long data = Cairo.cairo_image_surface_get_data(this.surface);
/*  833 */     int cairoStride = Cairo.cairo_image_surface_get_stride(this.surface);
/*  834 */     int oa = 0;int or = 0;int og = 0;int ob = 0;
/*  835 */     if (OS.BIG_ENDIAN) {
/*  836 */       oa = 0;or = 1;og = 2;ob = 3;
/*      */     } else {
/*  838 */       oa = 3;or = 2;og = 1;ob = 0;
/*      */     }
/*  840 */     byte[] line = new byte[stride];
/*  841 */     if (hasAlpha) {
/*  842 */       this.alphaData = new byte[width * height];
/*  843 */       int y = 0; for (int alphaOffset = 0; y < height; y++) {
/*  844 */         C.memmove(line, pixels + y * stride, stride);
/*  845 */         int x = 0; for (int offset = 0; x < width; offset += 4) {
/*  846 */           int a = line[(offset + 3)] & 0xFF;
/*  847 */           int r = (line[(offset + 0)] & 0xFF) * a + 128;
/*  848 */           r = r + (r >> 8) >> 8;
/*  849 */           int g = (line[(offset + 1)] & 0xFF) * a + 128;
/*  850 */           g = g + (g >> 8) >> 8;
/*  851 */           int b = (line[(offset + 2)] & 0xFF) * a + 128;
/*  852 */           b = b + (b >> 8) >> 8;
/*  853 */           line[(offset + oa)] = ((byte)a);
/*  854 */           line[(offset + or)] = ((byte)r);
/*  855 */           line[(offset + og)] = ((byte)g);
/*  856 */           line[(offset + ob)] = ((byte)b);
/*  857 */           this.alphaData[(alphaOffset++)] = ((byte)a);x++;
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  859 */         C.memmove(data + y * stride, line, stride);
/*      */       }
/*      */     } else {
/*  862 */       byte[] cairoLine = new byte[cairoStride];
/*  863 */       for (int y = 0; y < height; y++) {
/*  864 */         C.memmove(line, pixels + y * stride, stride);
/*  865 */         int x = 0;int offset = 0; for (int cairoOffset = 0; x < width; cairoOffset += 4) {
/*  866 */           int r = line[(offset + 0)] & 0xFF;
/*  867 */           int g = line[(offset + 1)] & 0xFF;
/*  868 */           int b = line[(offset + 2)] & 0xFF;
/*  869 */           cairoLine[(cairoOffset + or)] = ((byte)r);
/*  870 */           cairoLine[(cairoOffset + og)] = ((byte)g);
/*  871 */           cairoLine[(cairoOffset + ob)] = ((byte)b);x++;offset += 3;
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  873 */         C.memmove(data + y * cairoStride, cairoLine, cairoStride);
/*      */       }
/*      */     }
/*  876 */     Cairo.cairo_surface_mark_dirty(this.surface);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   void createMask()
/*      */   {
/*  883 */     int width = this.width;
/*  884 */     int height = this.height;
/*  885 */     int stride = Cairo.cairo_image_surface_get_stride(this.surface);
/*  886 */     long surfaceData = Cairo.cairo_image_surface_get_data(this.surface);
/*      */     int tb;
/*  888 */     int oa; int or; int og; int ob; int tr; int tg; int tb; if (OS.BIG_ENDIAN) {
/*  889 */       int oa = 0;int or = 1;int og = 2;int ob = 3;
/*  890 */       int tr = this.transparentPixel >> 24 & 0xFF;
/*  891 */       int tg = this.transparentPixel >> 16 & 0xFF;
/*  892 */       tb = this.transparentPixel >> 8 & 0xFF;
/*      */     } else {
/*  894 */       oa = 3;or = 2;og = 1;ob = 0;
/*  895 */       tr = this.transparentPixel >> 16 & 0xFF;
/*  896 */       tg = this.transparentPixel >> 8 & 0xFF;
/*  897 */       tb = this.transparentPixel >> 0 & 0xFF;
/*      */     }
/*  899 */     byte[] srcData = new byte[stride * height];
/*  900 */     C.memmove(srcData, surfaceData, srcData.length);
/*  901 */     int offset = 0;
/*  902 */     for (int y = 0; y < height; y++) {
/*  903 */       for (int x = 0; x < width; offset += 4) {
/*  904 */         int a = srcData[(offset + oa)] & 0xFF;
/*  905 */         int r = srcData[(offset + or)] & 0xFF;
/*  906 */         int g = srcData[(offset + og)] & 0xFF;
/*  907 */         int b = srcData[(offset + ob)] & 0xFF;
/*  908 */         if ((r == tr) && (g == tg) && (b == tb)) {
/*  909 */           a = r = g = b = 0;
/*      */         } else {
/*  911 */           a = 255;
/*      */         }
/*  913 */         srcData[(offset + oa)] = ((byte)a);
/*  914 */         srcData[(offset + or)] = ((byte)r);
/*  915 */         srcData[(offset + og)] = ((byte)g);
/*  916 */         srcData[(offset + ob)] = ((byte)b);x++;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  919 */     C.memmove(surfaceData, srcData, srcData.length);
/*      */   }
/*      */   
/*      */   void createSurface() {
/*  923 */     if (this.surface != 0L) { return;
/*      */     }
/*  925 */     if (GTK.GTK3) { return;
/*      */     }
/*  927 */     if (this.transparentPixel != -1) createMask();
/*  928 */     int[] w = new int[1];int[] h = new int[1];
/*  929 */     GDK.gdk_pixmap_get_size(this.pixmap, w, h);
/*  930 */     int width = w[0];int height = h[0];
/*  931 */     this.width = width;
/*  932 */     this.height = height;
/*  933 */     if ((this.mask != 0L) || (this.alpha != -1) || (this.alphaData != null)) {
/*  934 */       long pixbuf = GDK.gdk_pixbuf_new(0, true, 8, width, height);
/*  935 */       if (pixbuf == 0L) SWT.error(2);
/*  936 */       long colormap = GDK.gdk_colormap_get_system();
/*  937 */       GDK.gdk_pixbuf_get_from_drawable(pixbuf, this.pixmap, colormap, 0, 0, 0, 0, width, height);
/*  938 */       int stride = GDK.gdk_pixbuf_get_rowstride(pixbuf);
/*  939 */       long pixels = GDK.gdk_pixbuf_get_pixels(pixbuf);
/*  940 */       byte[] line = new byte[stride];
/*      */       int ob;
/*  942 */       int oa; int or; int og; int ob; if (OS.BIG_ENDIAN) {
/*  943 */         int oa = 0;int or = 1;int og = 2;ob = 3;
/*      */       } else {
/*  945 */         oa = 3;or = 2;og = 1;ob = 0;
/*      */       }
/*  947 */       if ((this.mask != 0L) && (GDK.gdk_drawable_get_depth(this.mask) == 1)) {
/*  948 */         long maskPixbuf = GDK.gdk_pixbuf_new(0, false, 8, width, height);
/*  949 */         if (maskPixbuf == 0L) SWT.error(2);
/*  950 */         GDK.gdk_pixbuf_get_from_drawable(maskPixbuf, this.mask, 0L, 0, 0, 0, 0, width, height);
/*  951 */         int maskStride = GDK.gdk_pixbuf_get_rowstride(maskPixbuf);
/*  952 */         long maskPixels = GDK.gdk_pixbuf_get_pixels(maskPixbuf);
/*  953 */         byte[] maskLine = new byte[maskStride];
/*  954 */         long offset = pixels;long maskOffset = maskPixels;
/*  955 */         for (int y = 0; y < height; y++) {
/*  956 */           C.memmove(line, offset, stride);
/*  957 */           C.memmove(maskLine, maskOffset, maskStride);
/*  958 */           int x = 0; for (int offset1 = 0; x < width; offset1 += 4) {
/*  959 */             if (maskLine[(x * 3)] == 0) {
/*  960 */               line[(offset1 + 0)] = (line[(offset1 + 1)] = line[(offset1 + 2)] = line[(offset1 + 3)] = 0);
/*      */             } else {
/*  962 */               byte r = line[(offset1 + 0)];
/*  963 */               byte g = line[(offset1 + 1)];
/*  964 */               byte b = line[(offset1 + 2)];
/*  965 */               line[(offset1 + oa)] = -1;
/*  966 */               line[(offset1 + or)] = r;
/*  967 */               line[(offset1 + og)] = g;
/*  968 */               line[(offset1 + ob)] = b;
/*      */             }
/*  958 */             x++;
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  971 */           C.memmove(offset, line, stride);
/*  972 */           offset += stride;
/*  973 */           maskOffset += maskStride;
/*      */         }
/*  975 */         OS.g_object_unref(maskPixbuf);
/*  976 */       } else if (this.alpha != -1) {
/*  977 */         long offset = pixels;
/*  978 */         for (int y = 0; y < height; y++) {
/*  979 */           C.memmove(line, offset, stride);
/*  980 */           int x = 0; for (int offset1 = 0; x < width; offset1 += 4)
/*      */           {
/*  982 */             int r = (line[(offset1 + 0)] & 0xFF) * this.alpha + 128;
/*  983 */             r = r + (r >> 8) >> 8;
/*  984 */             int g = (line[(offset1 + 1)] & 0xFF) * this.alpha + 128;
/*  985 */             g = g + (g >> 8) >> 8;
/*  986 */             int b = (line[(offset1 + 2)] & 0xFF) * this.alpha + 128;
/*  987 */             b = b + (b >> 8) >> 8;
/*  988 */             line[(offset1 + oa)] = ((byte)this.alpha);
/*  989 */             line[(offset1 + or)] = ((byte)r);
/*  990 */             line[(offset1 + og)] = ((byte)g);
/*  991 */             line[(offset1 + ob)] = ((byte)b);x++;
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  993 */           C.memmove(offset, line, stride);
/*  994 */           offset += stride;
/*      */         }
/*  996 */       } else if (this.alphaData != null) {
/*  997 */         long offset = pixels;
/*  998 */         for (int y = 0; y < h[0]; y++) {
/*  999 */           C.memmove(line, offset, stride);
/* 1000 */           int x = 0; for (int offset1 = 0; x < width; offset1 += 4) {
/* 1001 */             int alpha = this.alphaData[(y * w[0] + x)] & 0xFF;
/*      */             
/* 1003 */             int r = (line[(offset1 + 0)] & 0xFF) * alpha + 128;
/* 1004 */             r = r + (r >> 8) >> 8;
/* 1005 */             int g = (line[(offset1 + 1)] & 0xFF) * alpha + 128;
/* 1006 */             g = g + (g >> 8) >> 8;
/* 1007 */             int b = (line[(offset1 + 2)] & 0xFF) * alpha + 128;
/* 1008 */             b = b + (b >> 8) >> 8;
/* 1009 */             line[(offset1 + oa)] = ((byte)alpha);
/* 1010 */             line[(offset1 + or)] = ((byte)r);
/* 1011 */             line[(offset1 + og)] = ((byte)g);
/* 1012 */             line[(offset1 + ob)] = ((byte)b);x++;
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1014 */           C.memmove(offset, line, stride);
/* 1015 */           offset += stride;
/*      */         }
/*      */       } else {
/* 1018 */         long offset = pixels;
/* 1019 */         for (int y = 0; y < h[0]; y++) {
/* 1020 */           C.memmove(line, offset, stride);
/* 1021 */           int x = 0; for (int offset1 = 0; x < width; offset1 += 4) {
/* 1022 */             byte r = line[(offset1 + 0)];
/* 1023 */             byte g = line[(offset1 + 1)];
/* 1024 */             byte b = line[(offset1 + 2)];
/* 1025 */             line[(offset1 + oa)] = -1;
/* 1026 */             line[(offset1 + or)] = r;
/* 1027 */             line[(offset1 + og)] = g;
/* 1028 */             line[(offset1 + ob)] = b;x++;
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1030 */           C.memmove(offset, line, stride);
/* 1031 */           offset += stride;
/*      */         }
/*      */       }
/* 1034 */       this.surface = Cairo.cairo_image_surface_create(0, width, height);
/* 1035 */       long data = Cairo.cairo_image_surface_get_data(this.surface);
/* 1036 */       C.memmove(data, pixels, stride * height);
/* 1037 */       Cairo.cairo_surface_mark_dirty(this.surface);
/* 1038 */       OS.g_object_unref(pixbuf);
/*      */     } else {
/* 1040 */       long xDisplay = GDK.gdk_x11_display_get_xdisplay(GDK.gdk_display_get_default());
/* 1041 */       long xDrawable = GDK.GDK_PIXMAP_XID(this.pixmap);
/* 1042 */       long xVisual = GDK.gdk_x11_visual_get_xvisual(GDK.gdk_visual_get_system());
/* 1043 */       this.surface = Cairo.cairo_xlib_surface_create(xDisplay, xDrawable, xVisual, width, height);
/*      */     }
/*      */     
/* 1046 */     if ((this.transparentPixel != -1) && (this.memGC != null)) { destroyMask();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   void destroyMask()
/*      */   {
/* 1053 */     if (this.mask == 0L) return;
/* 1054 */     OS.g_object_unref(this.mask);
/* 1055 */     this.mask = 0L;
/*      */   }
/*      */   
/*      */   void destroy()
/*      */   {
/* 1060 */     if (this.memGC != null) this.memGC.dispose();
/* 1061 */     if (this.pixmap != 0L) OS.g_object_unref(this.pixmap);
/* 1062 */     if (this.mask != 0L) OS.g_object_unref(this.mask);
/* 1063 */     if (this.surface != 0L) Cairo.cairo_surface_destroy(this.surface);
/* 1064 */     this.surface = (this.pixmap = this.mask = 0L);
/* 1065 */     this.memGC = null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean equals(Object object)
/*      */   {
/* 1080 */     if (object == this) return true;
/* 1081 */     if (!(object instanceof Image)) return false;
/* 1082 */     Image image = (Image)object;
/* 1083 */     if ((this.device != image.device) || (this.transparentPixel != image.transparentPixel)) return false;
/* 1084 */     if ((this.imageDataProvider != null) && (image.imageDataProvider != null))
/* 1085 */       return (this.styleFlag == image.styleFlag) && (this.imageDataProvider.equals(image.imageDataProvider));
/* 1086 */     if ((this.imageFileNameProvider != null) && (image.imageFileNameProvider != null)) {
/* 1087 */       return (this.styleFlag == image.styleFlag) && (this.imageFileNameProvider.equals(image.imageFileNameProvider));
/*      */     }
/* 1089 */     return this.surface == image.surface;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Color getBackground()
/*      */   {
/* 1112 */     if (isDisposed()) SWT.error(44);
/* 1113 */     if (this.transparentPixel == -1) { return null;
/*      */     }
/* 1115 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Rectangle getBounds()
/*      */   {
/* 1130 */     if (isDisposed()) SWT.error(44);
/* 1131 */     return DPIUtil.autoScaleBounds(getBoundsInPixels(), 100, this.currentDeviceZoom);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public Rectangle getBoundsInPixels()
/*      */   {
/* 1151 */     if (isDisposed()) SWT.error(44);
/* 1152 */     if ((this.width != -1) && (this.height != -1)) {
/* 1153 */       return new Rectangle(0, 0, this.width, this.height);
/*      */     }
/* 1155 */     int[] w = new int[1];int[] h = new int[1];
/* 1156 */     GDK.gdk_pixmap_get_size(this.pixmap, w, h);
/* 1157 */     return new Rectangle(0, 0, this.width = w[0], this.height = h[0]);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ImageData getImageData()
/*      */   {
/* 1176 */     if (isDisposed()) SWT.error(44);
/* 1177 */     return getImageData(100);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public ImageData getImageDataAtCurrentZoom()
/*      */   {
/* 1202 */     if (isDisposed()) { SWT.error(44);
/*      */     }
/* 1204 */     long surface = ImageList.convertSurface(this);
/* 1205 */     int format = Cairo.cairo_image_surface_get_format(surface);
/* 1206 */     int width = Cairo.cairo_image_surface_get_width(surface);
/* 1207 */     int height = Cairo.cairo_image_surface_get_height(surface);
/* 1208 */     int stride = Cairo.cairo_image_surface_get_stride(surface);
/* 1209 */     long surfaceData = Cairo.cairo_image_surface_get_data(surface);
/* 1210 */     boolean hasAlpha = format == 0;
/*      */     int ob;
/* 1212 */     int oa; int or; int og; int ob; if (OS.BIG_ENDIAN) {
/* 1213 */       int oa = 0;int or = 1;int og = 2;ob = 3;
/*      */     } else {
/* 1215 */       oa = 3;or = 2;og = 1;ob = 0;
/*      */     }
/* 1217 */     byte[] srcData = new byte[stride * height];
/* 1218 */     C.memmove(srcData, surfaceData, srcData.length);
/* 1219 */     PaletteData palette = new PaletteData(16711680, 65280, 255);
/* 1220 */     ImageData data = new ImageData(width, height, 32, palette, 4, srcData);
/* 1221 */     if (hasAlpha) {
/* 1222 */       byte[] alphaData = data.alphaData = new byte[width * height];
/* 1223 */       int y = 0;int offset = 0; for (int alphaOffset = 0; y < height; y++) {
/* 1224 */         for (int x = 0; x < width; offset += 4) {
/* 1225 */           int a = srcData[(offset + oa)] & 0xFF;
/* 1226 */           int r = srcData[(offset + or)] & 0xFF;
/* 1227 */           int g = srcData[(offset + og)] & 0xFF;
/* 1228 */           int b = srcData[(offset + ob)] & 0xFF;
/* 1229 */           srcData[(offset + 0)] = 0;
/* 1230 */           alphaData[(alphaOffset++)] = ((byte)a);
/* 1231 */           if (a != 0) {
/* 1232 */             srcData[(offset + 1)] = ((byte)((r * 255 + a / 2) / a));
/* 1233 */             srcData[(offset + 2)] = ((byte)((g * 255 + a / 2) / a));
/* 1234 */             srcData[(offset + 3)] = ((byte)((b * 255 + a / 2) / a));
/*      */           }
/* 1224 */           x++;
/*      */ 
/*      */ 
/*      */         }
/*      */         
/*      */ 
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/*      */ 
/*      */ 
/* 1239 */       int y = 0; for (int offset = 0; y < height; y++) {
/* 1240 */         for (int x = 0; x < width; offset += 4) {
/* 1241 */           byte r = srcData[(offset + or)];
/* 1242 */           byte g = srcData[(offset + og)];
/* 1243 */           byte b = srcData[(offset + ob)];
/* 1244 */           srcData[(offset + 0)] = 0;
/* 1245 */           srcData[(offset + 1)] = r;
/* 1246 */           srcData[(offset + 2)] = g;
/* 1247 */           srcData[(offset + 3)] = b;x++;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1251 */     Cairo.cairo_surface_destroy(surface);
/* 1252 */     return data;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ImageData getImageData(int zoom)
/*      */   {
/* 1285 */     if (isDisposed()) { SWT.error(44);
/*      */     }
/* 1287 */     if (zoom == this.currentDeviceZoom)
/* 1288 */       return getImageDataAtCurrentZoom();
/* 1289 */     if (this.imageDataProvider != null) {
/* 1290 */       boolean[] found = new boolean[1];
/* 1291 */       ImageData data = DPIUtil.validateAndGetImageDataAtZoom(this.imageDataProvider, zoom, found);
/*      */       
/* 1293 */       if (found[0] != 0) {
/* 1294 */         return data;
/*      */       }
/*      */       
/* 1297 */       return DPIUtil.autoScaleUp(this.device, data); }
/* 1298 */     if (this.imageFileNameProvider != null) {
/* 1299 */       boolean[] found = new boolean[1];
/* 1300 */       String fileName = DPIUtil.validateAndGetImagePathAtZoom(this.imageFileNameProvider, zoom, found);
/*      */       
/* 1302 */       if (found[0] != 0) {
/* 1303 */         return new ImageData(fileName);
/*      */       }
/*      */       
/* 1306 */       return DPIUtil.autoScaleUp(this.device, new ImageData(fileName));
/*      */     }
/* 1308 */     return DPIUtil.autoScaleImageData(this.device, getImageDataAtCurrentZoom(), zoom, this.currentDeviceZoom);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Image gtk_new(Device device, int type, long imageHandle, long mask)
/*      */   {
/* 1330 */     Image image = new Image(device);
/* 1331 */     image.type = type;
/* 1332 */     if (GTK.GTK3) {
/* 1333 */       image.surface = imageHandle;
/*      */     } else {
/* 1335 */       image.pixmap = imageHandle;
/* 1336 */       image.createSurface();
/*      */     }
/* 1338 */     image.mask = mask;
/* 1339 */     return image;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Image gtk_new_from_pixbuf(Device device, int type, long pixbuf)
/*      */   {
/* 1359 */     Image image = new Image(device);
/* 1360 */     image.createFromPixbuf(type, pixbuf);
/* 1361 */     image.type = type;
/* 1362 */     return image;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int hashCode()
/*      */   {
/* 1377 */     if (this.imageDataProvider != null)
/* 1378 */       return this.imageDataProvider.hashCode();
/* 1379 */     if (this.imageFileNameProvider != null) {
/* 1380 */       return this.imageFileNameProvider.hashCode();
/*      */     }
/* 1382 */     return (int)this.surface;
/*      */   }
/*      */   
/*      */   void init(int width, int height)
/*      */   {
/* 1387 */     if ((width <= 0) || (height <= 0)) {
/* 1388 */       SWT.error(5);
/*      */     }
/* 1390 */     this.type = 0;
/*      */     
/*      */ 
/* 1393 */     this.surface = GDK.gdk_window_create_similar_surface(GDK.gdk_get_default_root_window(), 4096, width, height);
/* 1394 */     if (this.surface == 0L) { SWT.error(2);
/*      */     }
/*      */     
/* 1397 */     if (!GTK.GTK3) {
/* 1398 */       this.currentDeviceZoom = DPIUtil.getDeviceZoom();
/*      */     } else {
/* 1400 */       this.currentDeviceZoom = 100;
/* 1401 */       Cairo.cairo_surface_set_device_scale(this.surface, 1.0D, 1.0D);
/*      */     }
/* 1403 */     long cairo = Cairo.cairo_create(this.surface);
/* 1404 */     if (cairo == 0L) SWT.error(2);
/* 1405 */     Cairo.cairo_set_source_rgb(cairo, 1.0D, 1.0D, 1.0D);
/* 1406 */     Cairo.cairo_rectangle(cairo, 0.0D, 0.0D, width, height);
/* 1407 */     Cairo.cairo_fill(cairo);
/* 1408 */     Cairo.cairo_destroy(cairo);
/* 1409 */     this.width = width;
/* 1410 */     this.height = height;
/*      */   }
/*      */   
/*      */   void init(ImageData image) {
/* 1414 */     if (image == null) SWT.error(4);
/* 1415 */     int width = this.width = image.width;
/* 1416 */     int height = this.height = image.height;
/* 1417 */     PaletteData palette = image.palette;
/* 1418 */     if (((image.depth != 1) && (image.depth != 2) && (image.depth != 4) && (image.depth != 8)) || ((palette.isDirect) && (image.depth != 8) && (((image.depth != 16) && (image.depth != 24) && (image.depth != 32)) || (!palette.isDirect))))
/*      */     {
/* 1420 */       SWT.error(38); }
/* 1421 */     boolean hasAlpha = (image.transparentPixel != -1) || (image.alpha != -1) || (image.maskData != null) || (image.alphaData != null);
/* 1422 */     int format = hasAlpha ? 0 : 1;
/* 1423 */     this.surface = Cairo.cairo_image_surface_create(format, width, height);
/* 1424 */     if (this.surface == 0L) SWT.error(2);
/* 1425 */     if (GTK.GTK3) {
/* 1426 */       double scaleFactor = DPIUtil.getDeviceZoom() / 100.0F;
/* 1427 */       Cairo.cairo_surface_set_device_scale(this.surface, scaleFactor, scaleFactor);
/*      */     }
/* 1429 */     int stride = Cairo.cairo_image_surface_get_stride(this.surface);
/* 1430 */     long data = Cairo.cairo_image_surface_get_data(this.surface);
/* 1431 */     int oa = 0;int or = 0;int og = 0;int ob = 0;
/* 1432 */     int destDepth = 32;
/* 1433 */     int destOrder; int redMask; int greenMask; int blueMask; int destOrder; if (OS.BIG_ENDIAN) {
/* 1434 */       oa = 0;or = 1;og = 2;ob = 3;
/* 1435 */       int redMask = 65280;
/* 1436 */       int greenMask = 16711680;
/* 1437 */       int blueMask = -16777216;
/* 1438 */       destOrder = 1;
/*      */     } else {
/* 1440 */       oa = 3;or = 2;og = 1;ob = 0;
/* 1441 */       redMask = 16711680;
/* 1442 */       greenMask = 65280;
/* 1443 */       blueMask = 255;
/* 1444 */       destOrder = 0;
/*      */     }
/* 1446 */     byte[] buffer = image.data;
/* 1447 */     if ((!palette.isDirect) || (image.depth != destDepth) || (stride != image.bytesPerLine) || (palette.redMask != redMask) || (palette.greenMask != greenMask) || (palette.blueMask != blueMask) || (destOrder != image.getByteOrder())) {
/* 1448 */       buffer = new byte[stride * height];
/* 1449 */       if (palette.isDirect) {
/* 1450 */         ImageData.blit(1, image.data, image.depth, image.bytesPerLine, image
/* 1451 */           .getByteOrder(), 0, 0, width, height, palette.redMask, palette.greenMask, palette.blueMask, 255, null, 0, 0, 0, buffer, destDepth, stride, destOrder, 0, 0, width, height, redMask, greenMask, blueMask, false, false);
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/* 1456 */         RGB[] rgbs = palette.getRGBs();
/* 1457 */         int length = rgbs.length;
/* 1458 */         byte[] srcReds = new byte[length];
/* 1459 */         byte[] srcGreens = new byte[length];
/* 1460 */         byte[] srcBlues = new byte[length];
/* 1461 */         for (int i = 0; i < rgbs.length; i++) {
/* 1462 */           RGB rgb = rgbs[i];
/* 1463 */           if (rgb != null) {
/* 1464 */             srcReds[i] = ((byte)rgb.red);
/* 1465 */             srcGreens[i] = ((byte)rgb.green);
/* 1466 */             srcBlues[i] = ((byte)rgb.blue);
/*      */           } }
/* 1468 */         ImageData.blit(1, image.data, image.depth, image.bytesPerLine, image
/* 1469 */           .getByteOrder(), 0, 0, width, height, srcReds, srcGreens, srcBlues, 255, null, 0, 0, 0, buffer, destDepth, stride, destOrder, 0, 0, width, height, redMask, greenMask, blueMask, false, false);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1475 */     boolean isIcon = image.getTransparencyType() == 2;
/* 1476 */     this.type = (isIcon ? 1 : 0);
/* 1477 */     if ((isIcon) || (image.transparentPixel != -1)) {
/* 1478 */       if (image.transparentPixel != -1) {
/* 1479 */         RGB rgb = null;
/* 1480 */         if (palette.isDirect) {
/* 1481 */           rgb = palette.getRGB(image.transparentPixel);
/*      */         }
/* 1483 */         else if (image.transparentPixel < palette.colors.length) {
/* 1484 */           rgb = palette.getRGB(image.transparentPixel);
/*      */         }
/*      */         
/* 1487 */         if (rgb != null) {
/* 1488 */           this.transparentPixel = (rgb.red << 16 | rgb.green << 8 | rgb.blue);
/*      */         }
/*      */       }
/* 1491 */       ImageData mask = image.getTransparencyMask();
/* 1492 */       int y = 0; for (int offset = 0; y < height; y++) {
/* 1493 */         for (int x = 0; x < width; offset += 4) {
/* 1494 */           int alpha = mask.getPixel(x, y) == 0 ? 0 : 255;
/*      */           
/* 1496 */           int r = (buffer[(offset + or)] & 0xFF) * alpha + 128;
/* 1497 */           r = r + (r >> 8) >> 8;
/* 1498 */           int g = (buffer[(offset + og)] & 0xFF) * alpha + 128;
/* 1499 */           g = g + (g >> 8) >> 8;
/* 1500 */           int b = (buffer[(offset + ob)] & 0xFF) * alpha + 128;
/* 1501 */           b = b + (b >> 8) >> 8;
/* 1502 */           buffer[(offset + oa)] = ((byte)alpha);
/* 1503 */           buffer[(offset + or)] = ((byte)r);
/* 1504 */           buffer[(offset + og)] = ((byte)g);
/* 1505 */           buffer[(offset + ob)] = ((byte)b);x++;
/*      */ 
/*      */ 
/*      */         }
/*      */         
/*      */ 
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/*      */ 
/*      */ 
/* 1509 */       this.alpha = image.alpha;
/* 1510 */       if ((image.alpha == -1) && (image.alphaData != null)) {
/* 1511 */         this.alphaData = new byte[image.alphaData.length];
/* 1512 */         System.arraycopy(image.alphaData, 0, this.alphaData, 0, this.alphaData.length);
/*      */       }
/* 1514 */       if (this.alpha != -1) {
/* 1515 */         int y = 0; for (int offset = 0; y < height; y++) {
/* 1516 */           for (int x = 0; x < width; offset += 4) {
/* 1517 */             int alpha = this.alpha;
/*      */             
/* 1519 */             int r = (buffer[(offset + or)] & 0xFF) * alpha + 128;
/* 1520 */             r = r + (r >> 8) >> 8;
/* 1521 */             int g = (buffer[(offset + og)] & 0xFF) * alpha + 128;
/* 1522 */             g = g + (g >> 8) >> 8;
/* 1523 */             int b = (buffer[(offset + ob)] & 0xFF) * alpha + 128;
/* 1524 */             b = b + (b >> 8) >> 8;
/* 1525 */             buffer[(offset + oa)] = ((byte)alpha);
/* 1526 */             buffer[(offset + or)] = ((byte)r);
/* 1527 */             buffer[(offset + og)] = ((byte)g);
/* 1528 */             buffer[(offset + ob)] = ((byte)b);x++;
/*      */ 
/*      */ 
/*      */ 
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */       }
/* 1531 */       else if (this.alphaData != null) {
/* 1532 */         int y = 0; for (int offset = 0; y < height; y++) {
/* 1533 */           for (int x = 0; x < width; offset += 4) {
/* 1534 */             int alpha = this.alphaData[(y * width + x)] & 0xFF;
/*      */             
/* 1536 */             int r = (buffer[(offset + or)] & 0xFF) * alpha + 128;
/* 1537 */             r = r + (r >> 8) >> 8;
/* 1538 */             int g = (buffer[(offset + og)] & 0xFF) * alpha + 128;
/* 1539 */             g = g + (g >> 8) >> 8;
/* 1540 */             int b = (buffer[(offset + ob)] & 0xFF) * alpha + 128;
/* 1541 */             b = b + (b >> 8) >> 8;
/* 1542 */             buffer[(offset + oa)] = ((byte)alpha);
/* 1543 */             buffer[(offset + or)] = ((byte)r);
/* 1544 */             buffer[(offset + og)] = ((byte)g);
/* 1545 */             buffer[(offset + ob)] = ((byte)b);x++;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1550 */     C.memmove(data, buffer, stride * height);
/* 1551 */     Cairo.cairo_surface_mark_dirty(this.surface);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public long internal_new_GC(GCData data)
/*      */   {
/* 1571 */     if (isDisposed()) SWT.error(44);
/* 1572 */     if ((this.type != 0) || (this.memGC != null)) {
/* 1573 */       SWT.error(5);
/*      */     }
/* 1575 */     long gc = Cairo.cairo_create(this.surface);
/* 1576 */     if (data != null) {
/* 1577 */       int mask = 100663296;
/* 1578 */       if ((data.style & mask) == 0) {
/* 1579 */         data.style |= 0x2000000;
/*      */       }
/* 1581 */       else if ((data.style & 0x4000000) != 0) {
/* 1582 */         data.style |= 0x8000000;
/*      */       }
/*      */       
/* 1585 */       data.device = this.device;
/* 1586 */       data.drawable = this.pixmap;
/* 1587 */       if (GTK.GTK3) {
/* 1588 */         data.foregroundRGBA = this.device.COLOR_BLACK.handleRGBA;
/* 1589 */         data.backgroundRGBA = this.device.COLOR_WHITE.handleRGBA;
/*      */       } else {
/* 1591 */         data.background = this.device.COLOR_WHITE.handle;
/* 1592 */         data.foreground = this.device.COLOR_BLACK.handle;
/*      */       }
/* 1594 */       data.font = this.device.systemFont;
/* 1595 */       data.image = this;
/*      */     }
/* 1597 */     return gc;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void internal_dispose_GC(long hDC, GCData data)
/*      */   {
/* 1617 */     Cairo.cairo_destroy(hDC);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isDisposed()
/*      */   {
/* 1632 */     return this.surface == 0L;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBackground(Color color)
/*      */   {
/* 1670 */     if (isDisposed()) SWT.error(44);
/* 1671 */     if (color == null) SWT.error(4);
/* 1672 */     if (color.isDisposed()) SWT.error(5);
/* 1673 */     if (this.transparentPixel == -1) {}
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String toString()
/*      */   {
/* 1685 */     if (isDisposed()) return "Image {*DISPOSED*}";
/* 1686 */     return "Image {" + this.surface + "}";
/*      */   }
/*      */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/graphics/Image.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */