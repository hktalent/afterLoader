/*      */ package org.eclipse.swt.widgets;
/*      */ 
/*      */ import org.eclipse.swt.events.SelectionListener;
/*      */ import org.eclipse.swt.graphics.Color;
/*      */ import org.eclipse.swt.graphics.Font;
/*      */ import org.eclipse.swt.graphics.GC;
/*      */ import org.eclipse.swt.graphics.GCData;
/*      */ import org.eclipse.swt.graphics.Image;
/*      */ import org.eclipse.swt.graphics.Point;
/*      */ import org.eclipse.swt.graphics.Rectangle;
/*      */ import org.eclipse.swt.internal.C;
/*      */ import org.eclipse.swt.internal.Converter;
/*      */ import org.eclipse.swt.internal.DPIUtil;
/*      */ import org.eclipse.swt.internal.ImageList;
/*      */ import org.eclipse.swt.internal.cairo.Cairo;
/*      */ import org.eclipse.swt.internal.gtk.GDK;
/*      */ import org.eclipse.swt.internal.gtk.GTK;
/*      */ import org.eclipse.swt.internal.gtk.GdkColor;
/*      */ import org.eclipse.swt.internal.gtk.GdkEventButton;
/*      */ import org.eclipse.swt.internal.gtk.GdkEventExpose;
/*      */ import org.eclipse.swt.internal.gtk.GdkEventKey;
/*      */ import org.eclipse.swt.internal.gtk.GdkRGBA;
/*      */ import org.eclipse.swt.internal.gtk.GdkRectangle;
/*      */ import org.eclipse.swt.internal.gtk.GtkAllocation;
/*      */ import org.eclipse.swt.internal.gtk.GtkCellRendererClass;
/*      */ import org.eclipse.swt.internal.gtk.GtkRequisition;
/*      */ import org.eclipse.swt.internal.gtk.OS;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class Table
/*      */   extends Composite
/*      */ {
/*      */   long modelHandle;
/*      */   long checkRenderer;
/*      */   int itemCount;
/*      */   int columnCount;
/*      */   int lastIndexOf;
/*      */   int sortDirection;
/*      */   int selectionCountOnPress;
/*      */   int selectionCountOnRelease;
/*      */   long ignoreCell;
/*      */   TableItem[] items;
/*      */   TableColumn[] columns;
/*      */   TableItem currentItem;
/*      */   TableColumn sortColumn;
/*      */   ImageList imageList;
/*      */   ImageList headerImageList;
/*      */   boolean firstCustomDraw;
/*      */   int drawState;
/*      */   int drawFlags;
/*      */   GdkColor drawForeground;
/*      */   GdkRGBA background;
/*      */   GdkRGBA foreground;
/*      */   GdkRGBA drawForegroundRGBA;
/*      */   Color headerBackground;
/*      */   Color headerForeground;
/*      */   String headerCSSBackground;
/*      */   String headerCSSForeground;
/*      */   boolean ownerDraw;
/*      */   boolean ignoreSize;
/*      */   boolean ignoreAccessibility;
/*      */   boolean pixbufSizeSet;
/*      */   boolean hasChildren;
/*   89 */   int maxWidth = 0;
/*      */   
/*      */ 
/*      */   int topIndex;
/*      */   
/*      */ 
/*      */   double cachedAdjustment;
/*      */   
/*      */ 
/*      */   double currentAdjustment;
/*      */   
/*      */ 
/*      */   int pixbufHeight;
/*      */   
/*      */ 
/*      */   int pixbufWidth;
/*      */   
/*      */ 
/*      */   static final int CHECKED_COLUMN = 0;
/*      */   
/*      */ 
/*      */   static final int GRAYED_COLUMN = 1;
/*      */   
/*      */ 
/*      */   static final int FOREGROUND_COLUMN = 2;
/*      */   
/*      */ 
/*      */   static final int BACKGROUND_COLUMN = 3;
/*      */   
/*      */ 
/*      */   static final int FONT_COLUMN = 4;
/*      */   
/*      */ 
/*      */   static final int FIRST_COLUMN = 5;
/*      */   
/*      */ 
/*      */   static final int CELL_PIXBUF = 0;
/*      */   
/*      */ 
/*      */   static final int CELL_TEXT = 1;
/*      */   
/*      */   static final int CELL_FOREGROUND = 2;
/*      */   
/*      */   static final int CELL_BACKGROUND = 3;
/*      */   
/*      */   static final int CELL_FONT = 4;
/*      */   
/*      */   static final int CELL_TYPES = 5;
/*      */   
/*      */ 
/*      */   public Table(Composite parent, int style)
/*      */   {
/*  141 */     super(parent, checkStyle(style));
/*      */   }
/*      */   
/*      */   void _addListener(int eventType, Listener listener)
/*      */   {
/*  146 */     super._addListener(eventType, listener);
/*  147 */     if (!this.ownerDraw) {
/*  148 */       switch (eventType) {
/*      */       case 40: 
/*      */       case 41: 
/*      */       case 42: 
/*  152 */         this.ownerDraw = true;
/*  153 */         recreateRenderers();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   TableItem _getItem(int index)
/*      */   {
/*  160 */     if ((this.style & 0x10000000) == 0) return this.items[index];
/*  161 */     if (this.items[index] != null) return this.items[index];
/*  162 */     return this.items[index] = new TableItem(this, 0, index, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static int checkStyle(int style)
/*      */   {
/*  175 */     if ((style & 0x10) == 0) {
/*  176 */       style |= 0x300;
/*      */     }
/*      */     
/*  179 */     style |= 0x10000;
/*  180 */     return checkBits(style, 4, 2, 0, 0, 0, 0);
/*      */   }
/*      */   
/*      */   long cellDataProc(long tree_column, long cell, long tree_model, long iter, long data)
/*      */   {
/*  185 */     if (cell == this.ignoreCell) return 0L;
/*  186 */     long path = GTK.gtk_tree_model_get_path(tree_model, iter);
/*  187 */     int[] index = new int[1];
/*  188 */     C.memmove(index, GTK.gtk_tree_path_get_indices(path), 4L);
/*  189 */     TableItem item = _getItem(index[0]);
/*  190 */     GTK.gtk_tree_path_free(path);
/*  191 */     if (item != null) OS.g_object_set_qdata(cell, Display.SWT_OBJECT_INDEX2, item.handle);
/*  192 */     boolean isPixbuf = GTK.GTK_IS_CELL_RENDERER_PIXBUF(cell);
/*  193 */     boolean isText = GTK.GTK_IS_CELL_RENDERER_TEXT(cell);
/*  194 */     if ((isText) && (GTK.GTK3)) {
/*  195 */       GTK.gtk_cell_renderer_set_fixed_size(cell, -1, -1);
/*      */     }
/*  197 */     if ((!isPixbuf) && (!isText)) return 0L;
/*  198 */     int modelIndex = -1;
/*  199 */     boolean customDraw = false;
/*  200 */     if (this.columnCount == 0) {
/*  201 */       modelIndex = 5;
/*  202 */       customDraw = this.firstCustomDraw;
/*      */     } else {
/*  204 */       TableColumn column = (TableColumn)this.display.getWidget(tree_column);
/*  205 */       if (column != null) {
/*  206 */         modelIndex = column.modelIndex;
/*  207 */         customDraw = column.customDraw;
/*      */       }
/*      */     }
/*  210 */     if (modelIndex == -1) return 0L;
/*  211 */     boolean setData = false;
/*  212 */     if (((this.style & 0x10000000) != 0) && 
/*  213 */       (!item.cached)) {
/*  214 */       this.lastIndexOf = index[0];
/*  215 */       setData = checkData(item);
/*      */     }
/*      */     
/*  218 */     long[] ptr = new long[1];
/*  219 */     if (setData) {
/*  220 */       ptr[0] = 0L;
/*  221 */       if (isPixbuf) {
/*  222 */         GTK.gtk_tree_model_get(tree_model, iter, modelIndex + 0, ptr, -1);
/*  223 */         OS.g_object_set(cell, GTK.GTK3 ? OS.gicon : OS.pixbuf, ptr[0], 0L);
/*  224 */         if (ptr[0] != 0L) OS.g_object_unref(ptr[0]);
/*      */       } else {
/*  226 */         GTK.gtk_tree_model_get(tree_model, iter, modelIndex + 1, ptr, -1);
/*  227 */         if (ptr[0] != 0L) {
/*  228 */           OS.g_object_set(cell, OS.text, ptr[0], 0L);
/*  229 */           OS.g_free(ptr[0]);
/*      */         }
/*      */       }
/*      */     }
/*  233 */     if (customDraw) {
/*  234 */       if (!this.ownerDraw) {
/*  235 */         ptr[0] = 0L;
/*  236 */         GTK.gtk_tree_model_get(tree_model, iter, modelIndex + 3, ptr, -1);
/*  237 */         if (ptr[0] != 0L) {
/*  238 */           if (GTK.GTK3) {
/*  239 */             OS.g_object_set(cell, OS.cell_background_rgba, ptr[0], 0L);
/*  240 */             GDK.gdk_rgba_free(ptr[0]);
/*      */           } else {
/*  242 */             OS.g_object_set(cell, OS.cell_background_gdk, ptr[0], 0L);
/*  243 */             GDK.gdk_color_free(ptr[0]);
/*      */           }
/*      */         }
/*      */       }
/*  247 */       if (!isPixbuf) {
/*  248 */         ptr[0] = 0L;
/*  249 */         GTK.gtk_tree_model_get(tree_model, iter, modelIndex + 2, ptr, -1);
/*  250 */         if (ptr[0] != 0L) {
/*  251 */           if (GTK.GTK3) {
/*  252 */             OS.g_object_set(cell, OS.foreground_rgba, ptr[0], 0L);
/*  253 */             GDK.gdk_rgba_free(ptr[0]);
/*      */           } else {
/*  255 */             OS.g_object_set(cell, OS.foreground_gdk, ptr[0], 0L);
/*  256 */             GDK.gdk_color_free(ptr[0]);
/*      */           }
/*      */         }
/*  259 */         ptr[0] = 0L;
/*  260 */         GTK.gtk_tree_model_get(tree_model, iter, modelIndex + 4, ptr, -1);
/*  261 */         if (ptr[0] != 0L) {
/*  262 */           OS.g_object_set(cell, OS.font_desc, ptr[0], 0L);
/*  263 */           OS.pango_font_description_free(ptr[0]);
/*      */         }
/*      */       }
/*      */     }
/*  267 */     if (setData) {
/*  268 */       this.ignoreCell = cell;
/*  269 */       setScrollWidth(tree_column, item);
/*  270 */       this.ignoreCell = 0L;
/*      */     }
/*  272 */     return 0L;
/*      */   }
/*      */   
/*      */   boolean checkData(TableItem item) {
/*  276 */     if (item.cached) return true;
/*  277 */     if ((this.style & 0x10000000) != 0) {
/*  278 */       item.cached = true;
/*  279 */       Event event = new Event();
/*  280 */       event.item = item;
/*  281 */       event.index = indexOf(item);
/*  282 */       int mask = 17;
/*  283 */       int signal_id = OS.g_signal_lookup(OS.row_changed, GTK.gtk_tree_model_get_type());
/*  284 */       OS.g_signal_handlers_block_matched(this.modelHandle, mask, signal_id, 0, 0L, 0L, this.handle);
/*  285 */       this.currentItem = item;
/*  286 */       sendEvent(36, event);
/*      */       
/*  288 */       this.currentItem = null;
/*  289 */       if (isDisposed()) return false;
/*  290 */       OS.g_signal_handlers_unblock_matched(this.modelHandle, mask, signal_id, 0, 0L, 0L, this.handle);
/*  291 */       if (item.isDisposed()) return false;
/*      */     }
/*  293 */     return true;
/*      */   }
/*      */   
/*      */   protected void checkSubclass()
/*      */   {
/*  298 */     if (!isValidSubclass()) { error(43);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addSelectionListener(SelectionListener listener)
/*      */   {
/*  329 */     checkWidget();
/*  330 */     if (listener == null) error(4);
/*  331 */     TypedListener typedListener = new TypedListener(listener);
/*  332 */     addListener(13, typedListener);
/*  333 */     addListener(14, typedListener);
/*      */   }
/*      */   
/*      */   int calculateWidth(long column, long iter) {
/*  337 */     GTK.gtk_tree_view_column_cell_set_cell_data(column, this.modelHandle, iter, false, false);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  346 */     if (GTK.GTK3) {
/*  347 */       int[] width = new int[1];
/*  348 */       GTK.gtk_tree_view_column_cell_get_size(column, null, null, null, width, null);
/*  349 */       return width[0];
/*      */     }
/*  351 */     int width = 0;
/*  352 */     int[] w = new int[1];
/*  353 */     GTK.gtk_widget_style_get(this.handle, OS.focus_line_width, w, 0L);
/*  354 */     width += 2 * w[0];
/*  355 */     long list = GTK.gtk_cell_layout_get_cells(column);
/*  356 */     if (list == 0L) return 0;
/*  357 */     long temp = list;
/*  358 */     while (temp != 0L) {
/*  359 */       long renderer = OS.g_list_data(temp);
/*  360 */       if (renderer != 0L) {
/*  361 */         gtk_cell_renderer_get_preferred_size(renderer, this.handle, w, null);
/*  362 */         width += w[0];
/*      */       }
/*  364 */       temp = OS.g_list_next(temp);
/*      */     }
/*  366 */     OS.g_list_free(list);
/*  367 */     if (GTK.gtk_tree_view_get_grid_lines(this.handle) > 0) {
/*  368 */       GTK.gtk_widget_style_get(this.handle, OS.grid_line_width, w, 0L);
/*  369 */       width += 2 * w[0];
/*      */     }
/*  371 */     return width;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void clear(int index)
/*      */   {
/*  397 */     checkWidget();
/*  398 */     if ((0 > index) || (index >= this.itemCount)) {
/*  399 */       error(6);
/*      */     }
/*  401 */     TableItem item = this.items[index];
/*  402 */     if (item != null) { item.clear();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void clear(int start, int end)
/*      */   {
/*  429 */     checkWidget();
/*  430 */     if (start > end) return;
/*  431 */     if ((0 > start) || (start > end) || (end >= this.itemCount)) {
/*  432 */       error(6);
/*      */     }
/*  434 */     if ((start == 0) && (end == this.itemCount - 1)) {
/*  435 */       clearAll();
/*      */     } else {
/*  437 */       for (int i = start; i <= end; i++) {
/*  438 */         TableItem item = this.items[i];
/*  439 */         if (item != null) { item.clear();
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void clear(int[] indices)
/*      */   {
/*  467 */     checkWidget();
/*  468 */     if (indices == null) error(4);
/*  469 */     if (indices.length == 0) return;
/*  470 */     for (int i = 0; i < indices.length; i++) {
/*  471 */       if ((0 > indices[i]) || (indices[i] >= this.itemCount)) {
/*  472 */         error(6);
/*      */       }
/*      */     }
/*  475 */     for (int i = 0; i < indices.length; i++) {
/*  476 */       TableItem item = this.items[indices[i]];
/*  477 */       if (item != null) { item.clear();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void clearAll()
/*      */   {
/*  498 */     checkWidget();
/*  499 */     for (int i = 0; i < this.itemCount; i++) {
/*  500 */       TableItem item = this.items[i];
/*  501 */       if (item != null) item.clear();
/*      */     }
/*      */   }
/*      */   
/*      */   Point computeSizeInPixels(int wHint, int hHint, boolean changed)
/*      */   {
/*  507 */     checkWidget();
/*  508 */     if ((wHint != -1) && (wHint < 0)) wHint = 0;
/*  509 */     if ((hHint != -1) && (hHint < 0)) hHint = 0;
/*  510 */     Point size = computeNativeSize(this.handle, wHint, hHint, changed);
/*  511 */     if (GTK.GTK3)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  517 */       if ((hHint == -1) && (size.y == getHeaderHeight())) {
/*  518 */         size.y = (getItemCount() * getItemHeight() + getHeaderHeight());
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  525 */       if ((wHint == -1) && (size.x == 0) && (this.columnCount == 0)) {
/*  526 */         size.x = this.maxWidth;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  535 */     if ((size.y == 0) && (hHint == -1)) size.y = 64;
/*  536 */     if ((size.x == 0) && (wHint == -1)) size.x = 64;
/*  537 */     Rectangle trim = computeTrimInPixels(0, 0, size.x, size.y);
/*  538 */     size.x = trim.width;
/*  539 */     size.y = trim.height;
/*  540 */     return size;
/*      */   }
/*      */   
/*      */   void createColumn(TableColumn column, int index) {
/*  544 */     int modelIndex = 5;
/*  545 */     if (this.columnCount != 0) {
/*  546 */       int modelLength = GTK.gtk_tree_model_get_n_columns(this.modelHandle);
/*  547 */       boolean[] usedColumns = new boolean[modelLength];
/*  548 */       for (int i = 0; i < this.columnCount; i++) {
/*  549 */         int columnIndex = this.columns[i].modelIndex;
/*  550 */         for (int j = 0; j < 5; j++) {
/*  551 */           usedColumns[(columnIndex + j)] = true;
/*      */         }
/*      */       }
/*  554 */       while ((modelIndex < modelLength) && 
/*  555 */         (usedColumns[modelIndex] != 0)) {
/*  556 */         modelIndex++;
/*      */       }
/*  558 */       if (modelIndex == modelLength) {
/*  559 */         long oldModel = this.modelHandle;
/*  560 */         long[] types = getColumnTypes(this.columnCount + 4);
/*  561 */         long newModel = GTK.gtk_list_store_newv(types.length, types);
/*  562 */         if (newModel == 0L) error(2);
/*  563 */         long[] ptr = new long[1];
/*  564 */         int[] ptr1 = new int[1];
/*  565 */         for (int i = 0; i < this.itemCount; i++) {
/*  566 */           long newItem = OS.g_malloc(GTK.GtkTreeIter_sizeof());
/*  567 */           if (newItem == 0L) error(2);
/*  568 */           GTK.gtk_list_store_append(newModel, newItem);
/*  569 */           TableItem item = this.items[i];
/*  570 */           if (item != null) {
/*  571 */             long oldItem = item.handle;
/*      */             
/*  573 */             for (int j = 0; j < 2; j++) {
/*  574 */               GTK.gtk_tree_model_get(oldModel, oldItem, j, ptr1, -1);
/*  575 */               GTK.gtk_list_store_set(newModel, newItem, j, ptr1[0], -1);
/*      */             }
/*  577 */             for (int j = 2; j < modelLength; j++) {
/*  578 */               GTK.gtk_tree_model_get(oldModel, oldItem, j, ptr, -1);
/*  579 */               GTK.gtk_list_store_set(newModel, newItem, j, ptr[0], -1);
/*  580 */               if (ptr[0] != 0L) {
/*  581 */                 if (GTK.GTK3) {
/*  582 */                   if (types[j] == GDK.GDK_TYPE_RGBA()) {
/*  583 */                     GDK.gdk_rgba_free(ptr[0]);
/*      */                   }
/*      */                 }
/*  586 */                 else if (types[j] == GDK.GDK_TYPE_COLOR()) {
/*  587 */                   GDK.gdk_color_free(ptr[0]);
/*      */                 }
/*      */                 
/*  590 */                 if (types[j] == OS.G_TYPE_STRING()) {
/*  591 */                   OS.g_free(ptr[0]);
/*  592 */                 } else if (types[j] == GDK.GDK_TYPE_PIXBUF()) {
/*  593 */                   OS.g_object_unref(ptr[0]);
/*  594 */                 } else if (types[j] == OS.PANGO_TYPE_FONT_DESCRIPTION()) {
/*  595 */                   OS.pango_font_description_free(ptr[0]);
/*      */                 }
/*      */               }
/*      */             }
/*  599 */             GTK.gtk_list_store_remove(oldModel, oldItem);
/*  600 */             OS.g_free(oldItem);
/*  601 */             item.handle = newItem;
/*      */           } else {
/*  603 */             OS.g_free(newItem);
/*      */           }
/*      */         }
/*  606 */         GTK.gtk_tree_view_set_model(this.handle, newModel);
/*  607 */         setModel(newModel);
/*      */       }
/*      */     }
/*  610 */     long columnHandle = GTK.gtk_tree_view_column_new();
/*  611 */     if (columnHandle == 0L) error(2);
/*  612 */     if ((index == 0) && (this.columnCount > 0)) {
/*  613 */       TableColumn checkColumn = this.columns[0];
/*  614 */       createRenderers(checkColumn.handle, checkColumn.modelIndex, false, checkColumn.style);
/*      */     }
/*  616 */     createRenderers(columnHandle, modelIndex, index == 0, column == null ? 0 : column.style);
/*  617 */     if (((this.style & 0x10000000) == 0) && (this.columnCount == 0)) {
/*  618 */       GTK.gtk_tree_view_column_set_sizing(columnHandle, 0);
/*      */     } else {
/*  620 */       GTK.gtk_tree_view_column_set_sizing(columnHandle, 2);
/*      */     }
/*  622 */     GTK.gtk_tree_view_column_set_resizable(columnHandle, true);
/*  623 */     GTK.gtk_tree_view_column_set_clickable(columnHandle, true);
/*  624 */     GTK.gtk_tree_view_column_set_min_width(columnHandle, 0);
/*  625 */     GTK.gtk_tree_view_insert_column(this.handle, columnHandle, index);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  631 */     if (this.columnCount != 0) GTK.gtk_tree_view_column_set_visible(columnHandle, false);
/*  632 */     if (column != null) {
/*  633 */       column.handle = columnHandle;
/*  634 */       column.modelIndex = modelIndex;
/*      */     }
/*  636 */     if (!searchEnabled()) {
/*  637 */       GTK.gtk_tree_view_set_search_column(this.handle, -1);
/*      */     }
/*      */     else {
/*  640 */       int firstColumn = this.columnCount == 0 ? 5 : this.columns[0].modelIndex;
/*  641 */       GTK.gtk_tree_view_set_search_column(this.handle, firstColumn + 1);
/*      */     }
/*      */   }
/*      */   
/*      */   void createHandle(int index)
/*      */   {
/*  647 */     this.state |= 0x8;
/*  648 */     this.fixedHandle = OS.g_object_new(this.display.gtk_fixed_get_type(), 0L);
/*  649 */     if (this.fixedHandle == 0L) error(2);
/*  650 */     GTK.gtk_widget_set_has_window(this.fixedHandle, true);
/*  651 */     this.scrolledHandle = GTK.gtk_scrolled_window_new(0L, 0L);
/*  652 */     if (this.scrolledHandle == 0L) error(2);
/*  653 */     long[] types = getColumnTypes(1);
/*  654 */     this.modelHandle = GTK.gtk_list_store_newv(types.length, types);
/*  655 */     if (this.modelHandle == 0L) error(2);
/*  656 */     this.handle = GTK.gtk_tree_view_new_with_model(this.modelHandle);
/*  657 */     if (this.handle == 0L) error(2);
/*  658 */     if ((this.style & 0x20) != 0) {
/*  659 */       this.checkRenderer = GTK.gtk_cell_renderer_toggle_new();
/*  660 */       if (this.checkRenderer == 0L) error(2);
/*  661 */       OS.g_object_ref(this.checkRenderer);
/*      */     }
/*  663 */     createColumn(null, 0);
/*  664 */     GTK.gtk_container_add(this.fixedHandle, this.scrolledHandle);
/*  665 */     GTK.gtk_container_add(this.scrolledHandle, this.handle);
/*      */     
/*  667 */     int mode = (this.style & 0x2) != 0 ? 3 : 2;
/*  668 */     long selectionHandle = GTK.gtk_tree_view_get_selection(this.handle);
/*  669 */     GTK.gtk_tree_selection_set_mode(selectionHandle, mode);
/*  670 */     GTK.gtk_tree_view_set_headers_visible(this.handle, false);
/*  671 */     int hsp = (this.style & 0x100) != 0 ? 1 : 2;
/*  672 */     int vsp = (this.style & 0x200) != 0 ? 1 : 2;
/*  673 */     GTK.gtk_scrolled_window_set_policy(this.scrolledHandle, hsp, vsp);
/*  674 */     if ((this.style & 0x800) != 0) { GTK.gtk_scrolled_window_set_shadow_type(this.scrolledHandle, 3);
/*      */     }
/*      */     
/*      */ 
/*  678 */     if ((this.style & 0x10000000) != 0) {
/*  679 */       OS.g_object_set(this.handle, OS.fixed_height_mode, true, 0L);
/*      */     }
/*  681 */     if (!searchEnabled()) {
/*  682 */       GTK.gtk_tree_view_set_search_column(this.handle, -1);
/*      */     }
/*      */   }
/*      */   
/*      */   void createItem(TableColumn column, int index) {
/*  687 */     if ((0 > index) || (index > this.columnCount)) error(6);
/*  688 */     if (this.columnCount == 0) {
/*  689 */       column.handle = GTK.gtk_tree_view_get_column(this.handle, 0);
/*  690 */       GTK.gtk_tree_view_column_set_sizing(column.handle, 2);
/*  691 */       GTK.gtk_tree_view_column_set_visible(column.handle, false);
/*  692 */       column.modelIndex = 5;
/*  693 */       createRenderers(column.handle, column.modelIndex, true, column.style);
/*  694 */       column.customDraw = this.firstCustomDraw;
/*  695 */       this.firstCustomDraw = false;
/*      */     } else {
/*  697 */       createColumn(column, index);
/*      */     }
/*  699 */     long boxHandle = gtk_box_new(0, false, 3);
/*  700 */     if (boxHandle == 0L) error(2);
/*  701 */     long labelHandle = GTK.gtk_label_new_with_mnemonic(null);
/*  702 */     if (labelHandle == 0L) error(2);
/*  703 */     long imageHandle = GTK.gtk_image_new();
/*  704 */     if (imageHandle == 0L) error(2);
/*  705 */     GTK.gtk_container_add(boxHandle, imageHandle);
/*  706 */     GTK.gtk_container_add(boxHandle, labelHandle);
/*  707 */     GTK.gtk_widget_show(boxHandle);
/*  708 */     GTK.gtk_widget_show(labelHandle);
/*  709 */     column.labelHandle = labelHandle;
/*  710 */     column.imageHandle = imageHandle;
/*  711 */     GTK.gtk_tree_view_column_set_widget(column.handle, boxHandle);
/*  712 */     if (GTK.GTK3) {
/*  713 */       column.buttonHandle = GTK.gtk_tree_view_column_get_button(column.handle);
/*      */     } else {
/*  715 */       long widget = GTK.gtk_widget_get_parent(boxHandle);
/*  716 */       while (widget != this.handle) {
/*  717 */         if (GTK.GTK_IS_BUTTON(widget)) {
/*  718 */           column.buttonHandle = widget;
/*  719 */           break;
/*      */         }
/*  721 */         widget = GTK.gtk_widget_get_parent(widget);
/*      */       }
/*      */     }
/*  724 */     if (this.columnCount == this.columns.length) {
/*  725 */       TableColumn[] newColumns = new TableColumn[this.columns.length + 4];
/*  726 */       System.arraycopy(this.columns, 0, newColumns, 0, this.columns.length);
/*  727 */       this.columns = newColumns;
/*      */     }
/*  729 */     System.arraycopy(this.columns, index, this.columns, index + 1, this.columnCount++ - index);
/*  730 */     this.columns[index] = column;
/*  731 */     if ((this.state & 0x4000) != 0) {
/*  732 */       column.setFontDescription(getFontDescription());
/*      */     }
/*  734 */     if (this.columnCount >= 1) {
/*  735 */       for (int i = 0; i < this.itemCount; i++) {
/*  736 */         TableItem item = this.items[i];
/*  737 */         if (item != null) {
/*  738 */           Font[] cellFont = item.cellFont;
/*  739 */           if (cellFont != null) {
/*  740 */             Font[] temp = new Font[this.columnCount];
/*  741 */             System.arraycopy(cellFont, 0, temp, 0, index);
/*  742 */             System.arraycopy(cellFont, index, temp, index + 1, this.columnCount - index - 1);
/*  743 */             item.cellFont = temp;
/*      */           }
/*  745 */           String[] strings = item.strings;
/*  746 */           if (strings != null) {
/*  747 */             String[] temp = new String[this.columnCount];
/*  748 */             System.arraycopy(strings, 0, temp, 0, index);
/*  749 */             System.arraycopy(strings, index, temp, index + 1, this.columnCount - index - 1);
/*  750 */             temp[index] = "";
/*  751 */             item.strings = temp;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  763 */     if (!isVisible()) {
/*  764 */       forceResize();
/*      */     }
/*      */   }
/*      */   
/*      */   void createItem(TableItem item, int index) {
/*  769 */     if ((0 > index) || (index > this.itemCount)) error(6);
/*  770 */     if (this.itemCount == this.items.length) {
/*  771 */       int length = this.drawCount <= 0 ? this.items.length + 4 : Math.max(4, this.items.length * 3 / 2);
/*  772 */       TableItem[] newItems = new TableItem[length];
/*  773 */       System.arraycopy(this.items, 0, newItems, 0, this.items.length);
/*  774 */       this.items = newItems;
/*      */     }
/*  776 */     item.handle = OS.g_malloc(GTK.GtkTreeIter_sizeof());
/*  777 */     if (item.handle == 0L) { error(2);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  782 */     if (index == this.itemCount) {
/*  783 */       GTK.gtk_list_store_append(this.modelHandle, item.handle);
/*      */     } else {
/*  785 */       GTK.gtk_list_store_insert(this.modelHandle, item.handle, index);
/*      */     }
/*  787 */     System.arraycopy(this.items, index, this.items, index + 1, this.itemCount++ - index);
/*  788 */     this.items[index] = item;
/*      */   }
/*      */   
/*      */   void createRenderers(long columnHandle, int modelIndex, boolean check, int columnStyle) {
/*  792 */     GTK.gtk_tree_view_column_clear(columnHandle);
/*  793 */     if (((this.style & 0x20) != 0) && (check)) {
/*  794 */       GTK.gtk_tree_view_column_pack_start(columnHandle, this.checkRenderer, false);
/*  795 */       GTK.gtk_tree_view_column_add_attribute(columnHandle, this.checkRenderer, OS.active, 0);
/*  796 */       GTK.gtk_tree_view_column_add_attribute(columnHandle, this.checkRenderer, OS.inconsistent, 1);
/*  797 */       if (this.ownerDraw) {
/*  798 */         GTK.gtk_tree_view_column_set_cell_data_func(columnHandle, this.checkRenderer, this.display.cellDataProc, this.handle, 0L);
/*  799 */         OS.g_object_set_qdata(this.checkRenderer, Display.SWT_OBJECT_INDEX1, columnHandle);
/*      */       }
/*  801 */       else if (GTK.GTK3) {
/*  802 */         GTK.gtk_tree_view_column_add_attribute(columnHandle, this.checkRenderer, OS.cell_background_rgba, 3);
/*      */       } else {
/*  804 */         GTK.gtk_tree_view_column_add_attribute(columnHandle, this.checkRenderer, OS.cell_background_gdk, 3);
/*      */       }
/*      */     }
/*      */     
/*  808 */     long pixbufRenderer = this.ownerDraw ? OS.g_object_new(this.display.gtk_cell_renderer_pixbuf_get_type(), 0L) : GTK.gtk_cell_renderer_pixbuf_new();
/*  809 */     if (pixbufRenderer == 0L) {
/*  810 */       error(2);
/*      */ 
/*      */     }
/*  813 */     else if ((!this.ownerDraw) && (GTK.GTK3))
/*      */     {
/*      */ 
/*  816 */       GTK.gtk_cell_renderer_set_fixed_size(pixbufRenderer, 0, 0);
/*      */     }
/*      */     
/*  819 */     long textRenderer = this.ownerDraw ? OS.g_object_new(this.display.gtk_cell_renderer_text_get_type(), 0L) : GTK.gtk_cell_renderer_text_new();
/*  820 */     if (textRenderer == 0L) { error(2);
/*      */     }
/*  822 */     if (this.ownerDraw) {
/*  823 */       OS.g_object_set_qdata(pixbufRenderer, Display.SWT_OBJECT_INDEX1, columnHandle);
/*  824 */       OS.g_object_set_qdata(textRenderer, Display.SWT_OBJECT_INDEX1, columnHandle);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  833 */     if (((this.style & 0x20) != 0) && (check)) {
/*  834 */       OS.g_object_set(pixbufRenderer, OS.mode, 1, 0L);
/*      */     }
/*      */     
/*      */ 
/*  838 */     if ((columnStyle & 0x20000) != 0) {
/*  839 */       OS.g_object_set(textRenderer, OS.xalign, 1.0F, 0L);
/*  840 */       GTK.gtk_tree_view_column_pack_end(columnHandle, textRenderer, true);
/*  841 */       GTK.gtk_tree_view_column_pack_end(columnHandle, pixbufRenderer, false);
/*  842 */       GTK.gtk_tree_view_column_set_alignment(columnHandle, 1.0F);
/*  843 */     } else if ((columnStyle & 0x1000000) != 0) {
/*  844 */       OS.g_object_set(textRenderer, OS.xalign, 0.5F, 0L);
/*  845 */       GTK.gtk_tree_view_column_pack_start(columnHandle, pixbufRenderer, false);
/*  846 */       GTK.gtk_tree_view_column_pack_end(columnHandle, textRenderer, true);
/*  847 */       GTK.gtk_tree_view_column_set_alignment(columnHandle, 0.5F);
/*      */     } else {
/*  849 */       GTK.gtk_tree_view_column_pack_start(columnHandle, pixbufRenderer, false);
/*  850 */       GTK.gtk_tree_view_column_pack_start(columnHandle, textRenderer, true);
/*  851 */       GTK.gtk_tree_view_column_set_alignment(columnHandle, 0.0F);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  860 */     GTK.gtk_tree_view_column_add_attribute(columnHandle, pixbufRenderer, OS.pixbuf, modelIndex + 0);
/*  861 */     if (!this.ownerDraw) {
/*  862 */       if (GTK.GTK3) {
/*  863 */         GTK.gtk_tree_view_column_add_attribute(columnHandle, pixbufRenderer, OS.cell_background_rgba, 3);
/*  864 */         GTK.gtk_tree_view_column_add_attribute(columnHandle, textRenderer, OS.cell_background_rgba, 3);
/*      */       } else {
/*  866 */         GTK.gtk_tree_view_column_add_attribute(columnHandle, pixbufRenderer, OS.cell_background_gdk, 3);
/*  867 */         GTK.gtk_tree_view_column_add_attribute(columnHandle, textRenderer, OS.cell_background_gdk, 3);
/*      */       }
/*      */     }
/*  870 */     GTK.gtk_tree_view_column_add_attribute(columnHandle, textRenderer, OS.text, modelIndex + 1);
/*  871 */     if (GTK.GTK3) {
/*  872 */       GTK.gtk_tree_view_column_add_attribute(columnHandle, textRenderer, OS.foreground_rgba, 2);
/*      */     } else {
/*  874 */       GTK.gtk_tree_view_column_add_attribute(columnHandle, textRenderer, OS.foreground_gdk, 2);
/*      */     }
/*  876 */     GTK.gtk_tree_view_column_add_attribute(columnHandle, textRenderer, OS.font_desc, 4);
/*      */     
/*  878 */     boolean customDraw = this.firstCustomDraw;
/*  879 */     if (this.columnCount != 0) {
/*  880 */       for (int i = 0; i < this.columnCount; i++) {
/*  881 */         if (this.columns[i].handle == columnHandle) {
/*  882 */           customDraw = this.columns[i].customDraw;
/*  883 */           break;
/*      */         }
/*      */       }
/*      */     }
/*  887 */     if (((this.style & 0x10000000) != 0) || (customDraw) || (this.ownerDraw)) {
/*  888 */       GTK.gtk_tree_view_column_set_cell_data_func(columnHandle, textRenderer, this.display.cellDataProc, this.handle, 0L);
/*  889 */       GTK.gtk_tree_view_column_set_cell_data_func(columnHandle, pixbufRenderer, this.display.cellDataProc, this.handle, 0L);
/*      */     }
/*      */   }
/*      */   
/*      */   void createWidget(int index)
/*      */   {
/*  895 */     super.createWidget(index);
/*  896 */     this.items = new TableItem[4];
/*  897 */     this.columns = new TableColumn[4];
/*  898 */     this.itemCount = (this.columnCount = 0);
/*      */     
/*      */ 
/*  901 */     if (GTK.GTK3) {
/*  902 */       setFontDescription(defaultFont().handle);
/*      */     }
/*      */   }
/*      */   
/*      */   int applyThemeBackground()
/*      */   {
/*  908 */     return -1;
/*      */   }
/*      */   
/*      */   GdkRGBA defaultBackground()
/*      */   {
/*  913 */     return this.display.getSystemColor(25).handleRGBA;
/*      */   }
/*      */   
/*      */   void deregister()
/*      */   {
/*  918 */     super.deregister();
/*  919 */     this.display.removeWidget(GTK.gtk_tree_view_get_selection(this.handle));
/*  920 */     if (this.checkRenderer != 0L) this.display.removeWidget(this.checkRenderer);
/*  921 */     this.display.removeWidget(this.modelHandle);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void deselect(int index)
/*      */   {
/*  937 */     checkWidget();
/*  938 */     if ((index < 0) || (index >= this.itemCount)) return;
/*  939 */     boolean fixColumn = showFirstColumn();
/*  940 */     long selection = GTK.gtk_tree_view_get_selection(this.handle);
/*  941 */     OS.g_signal_handlers_block_matched(selection, 16, 0, 0, 0L, 0L, 6L);
/*  942 */     GTK.gtk_tree_selection_unselect_iter(selection, _getItem(index).handle);
/*  943 */     OS.g_signal_handlers_unblock_matched(selection, 16, 0, 0, 0L, 0L, 6L);
/*  944 */     if (fixColumn) { hideFirstColumn();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void deselect(int start, int end)
/*      */   {
/*  963 */     checkWidget();
/*  964 */     boolean fixColumn = showFirstColumn();
/*  965 */     long selection = GTK.gtk_tree_view_get_selection(this.handle);
/*  966 */     OS.g_signal_handlers_block_matched(selection, 16, 0, 0, 0L, 0L, 6L);
/*  967 */     for (int index = start; index <= end; index++) {
/*  968 */       if ((index >= 0) && (index < this.itemCount))
/*  969 */         GTK.gtk_tree_selection_unselect_iter(selection, _getItem(index).handle);
/*      */     }
/*  971 */     OS.g_signal_handlers_unblock_matched(selection, 16, 0, 0, 0L, 0L, 6L);
/*  972 */     if (fixColumn) { hideFirstColumn();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void deselect(int[] indices)
/*      */   {
/*  993 */     checkWidget();
/*  994 */     if (indices == null) error(4);
/*  995 */     boolean fixColumn = showFirstColumn();
/*  996 */     long selection = GTK.gtk_tree_view_get_selection(this.handle);
/*  997 */     OS.g_signal_handlers_block_matched(selection, 16, 0, 0, 0L, 0L, 6L);
/*  998 */     for (int i = 0; i < indices.length; i++) {
/*  999 */       int index = indices[i];
/* 1000 */       if ((index >= 0) && (index < this.itemCount))
/* 1001 */         GTK.gtk_tree_selection_unselect_iter(selection, _getItem(index).handle);
/*      */     }
/* 1003 */     OS.g_signal_handlers_unblock_matched(selection, 16, 0, 0, 0L, 0L, 6L);
/* 1004 */     if (fixColumn) { hideFirstColumn();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void deselectAll()
/*      */   {
/* 1016 */     checkWidget();
/* 1017 */     boolean fixColumn = showFirstColumn();
/* 1018 */     long selection = GTK.gtk_tree_view_get_selection(this.handle);
/* 1019 */     OS.g_signal_handlers_block_matched(selection, 16, 0, 0, 0L, 0L, 6L);
/* 1020 */     GTK.gtk_tree_selection_unselect_all(selection);
/* 1021 */     OS.g_signal_handlers_unblock_matched(selection, 16, 0, 0, 0L, 0L, 6L);
/* 1022 */     if (fixColumn) hideFirstColumn();
/*      */   }
/*      */   
/*      */   void destroyItem(TableColumn column) {
/* 1026 */     int index = 0;
/* 1027 */     while ((index < this.columnCount) && 
/* 1028 */       (this.columns[index] != column)) {
/* 1029 */       index++;
/*      */     }
/* 1031 */     if (index == this.columnCount) return;
/* 1032 */     long columnHandle = column.handle;
/* 1033 */     if (this.columnCount == 1) {
/* 1034 */       this.firstCustomDraw = column.customDraw;
/*      */     }
/* 1036 */     System.arraycopy(this.columns, index + 1, this.columns, index, --this.columnCount - index);
/* 1037 */     this.columns[this.columnCount] = null;
/* 1038 */     GTK.gtk_tree_view_remove_column(this.handle, columnHandle);
/* 1039 */     if (this.columnCount == 0) {
/* 1040 */       long oldModel = this.modelHandle;
/* 1041 */       long[] types = getColumnTypes(1);
/* 1042 */       long newModel = GTK.gtk_list_store_newv(types.length, types);
/* 1043 */       if (newModel == 0L) error(2);
/* 1044 */       long[] ptr = new long[1];
/* 1045 */       int[] ptr1 = new int[1];
/* 1046 */       for (int i = 0; i < this.itemCount; i++) {
/* 1047 */         long newItem = OS.g_malloc(GTK.GtkTreeIter_sizeof());
/* 1048 */         if (newItem == 0L) error(2);
/* 1049 */         GTK.gtk_list_store_append(newModel, newItem);
/* 1050 */         TableItem item = this.items[i];
/* 1051 */         if (item != null) {
/* 1052 */           long oldItem = item.handle;
/*      */           
/* 1054 */           for (int j = 0; j < 2; j++) {
/* 1055 */             GTK.gtk_tree_model_get(oldModel, oldItem, j, ptr1, -1);
/* 1056 */             GTK.gtk_list_store_set(newModel, newItem, j, ptr1[0], -1);
/*      */           }
/* 1058 */           for (int j = 2; j < 5; j++) {
/* 1059 */             GTK.gtk_tree_model_get(oldModel, oldItem, j, ptr, -1);
/* 1060 */             GTK.gtk_list_store_set(newModel, newItem, j, ptr[0], -1);
/* 1061 */             if (ptr[0] != 0L) {
/* 1062 */               if ((j == 2) || (j == 3)) {
/* 1063 */                 if (GTK.GTK3) {
/* 1064 */                   GDK.gdk_rgba_free(ptr[0]);
/*      */                 } else {
/* 1066 */                   GDK.gdk_color_free(ptr[0]);
/*      */                 }
/* 1068 */               } else if (j == 4) {
/* 1069 */                 OS.pango_font_description_free(ptr[0]);
/*      */               }
/*      */             }
/*      */           }
/* 1073 */           GTK.gtk_tree_model_get(oldModel, oldItem, column.modelIndex + 0, ptr, -1);
/* 1074 */           GTK.gtk_list_store_set(newModel, newItem, 5, ptr[0], -1);
/* 1075 */           if (ptr[0] != 0L) OS.g_object_unref(ptr[0]);
/* 1076 */           GTK.gtk_tree_model_get(oldModel, oldItem, column.modelIndex + 1, ptr, -1);
/* 1077 */           GTK.gtk_list_store_set(newModel, newItem, 6, ptr[0], -1);
/* 1078 */           OS.g_free(ptr[0]);
/* 1079 */           GTK.gtk_tree_model_get(oldModel, oldItem, column.modelIndex + 2, ptr, -1);
/* 1080 */           GTK.gtk_list_store_set(newModel, newItem, 7, ptr[0], -1);
/* 1081 */           if (ptr[0] != 0L) {
/* 1082 */             if (GTK.GTK3) {
/* 1083 */               GDK.gdk_rgba_free(ptr[0]);
/*      */             } else {
/* 1085 */               GDK.gdk_color_free(ptr[0]);
/*      */             }
/*      */           }
/* 1088 */           GTK.gtk_tree_model_get(oldModel, oldItem, column.modelIndex + 3, ptr, -1);
/* 1089 */           GTK.gtk_list_store_set(newModel, newItem, 8, ptr[0], -1);
/* 1090 */           if (ptr[0] != 0L) {
/* 1091 */             if (GTK.GTK3) {
/* 1092 */               GDK.gdk_rgba_free(ptr[0]);
/*      */             } else {
/* 1094 */               GDK.gdk_color_free(ptr[0]);
/*      */             }
/*      */           }
/* 1097 */           GTK.gtk_tree_model_get(oldModel, oldItem, column.modelIndex + 4, ptr, -1);
/* 1098 */           GTK.gtk_list_store_set(newModel, newItem, 9, ptr[0], -1);
/* 1099 */           if (ptr[0] != 0L) OS.pango_font_description_free(ptr[0]);
/* 1100 */           GTK.gtk_list_store_remove(oldModel, oldItem);
/* 1101 */           OS.g_free(oldItem);
/* 1102 */           item.handle = newItem;
/*      */         } else {
/* 1104 */           OS.g_free(newItem);
/*      */         }
/*      */       }
/* 1107 */       GTK.gtk_tree_view_set_model(this.handle, newModel);
/* 1108 */       setModel(newModel);
/* 1109 */       createColumn(null, 0);
/*      */     } else {
/* 1111 */       for (int i = 0; i < this.itemCount; i++) {
/* 1112 */         TableItem item = this.items[i];
/* 1113 */         if (item != null) {
/* 1114 */           long iter = item.handle;
/* 1115 */           int modelIndex = column.modelIndex;
/* 1116 */           GTK.gtk_list_store_set(this.modelHandle, iter, modelIndex + 0, 0L, -1);
/* 1117 */           GTK.gtk_list_store_set(this.modelHandle, iter, modelIndex + 1, 0L, -1);
/* 1118 */           GTK.gtk_list_store_set(this.modelHandle, iter, modelIndex + 2, 0L, -1);
/* 1119 */           GTK.gtk_list_store_set(this.modelHandle, iter, modelIndex + 3, 0L, -1);
/* 1120 */           GTK.gtk_list_store_set(this.modelHandle, iter, modelIndex + 4, 0L, -1);
/*      */           
/* 1122 */           Font[] cellFont = item.cellFont;
/* 1123 */           if (cellFont != null) {
/* 1124 */             if (this.columnCount == 0) {
/* 1125 */               item.cellFont = null;
/*      */             } else {
/* 1127 */               Font[] temp = new Font[this.columnCount];
/* 1128 */               System.arraycopy(cellFont, 0, temp, 0, index);
/* 1129 */               System.arraycopy(cellFont, index + 1, temp, index, this.columnCount - index);
/* 1130 */               item.cellFont = temp;
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/* 1135 */       if (index == 0) {
/* 1136 */         TableColumn checkColumn = this.columns[0];
/* 1137 */         createRenderers(checkColumn.handle, checkColumn.modelIndex, true, checkColumn.style);
/*      */       }
/*      */     }
/* 1140 */     if (!searchEnabled()) {
/* 1141 */       GTK.gtk_tree_view_set_search_column(this.handle, -1);
/*      */     }
/*      */     else {
/* 1144 */       int firstColumn = this.columnCount == 0 ? 5 : this.columns[0].modelIndex;
/* 1145 */       GTK.gtk_tree_view_set_search_column(this.handle, firstColumn + 1);
/*      */     }
/*      */   }
/*      */   
/*      */   void destroyItem(TableItem item) {
/* 1150 */     int index = 0;
/* 1151 */     while ((index < this.itemCount) && 
/* 1152 */       (this.items[index] != item)) {
/* 1153 */       index++;
/*      */     }
/* 1155 */     if (index == this.itemCount) return;
/* 1156 */     long selection = GTK.gtk_tree_view_get_selection(this.handle);
/* 1157 */     OS.g_signal_handlers_block_matched(selection, 16, 0, 0, 0L, 0L, 6L);
/* 1158 */     GTK.gtk_list_store_remove(this.modelHandle, item.handle);
/* 1159 */     OS.g_signal_handlers_unblock_matched(selection, 16, 0, 0, 0L, 0L, 6L);
/* 1160 */     System.arraycopy(this.items, index + 1, this.items, index, --this.itemCount - index);
/* 1161 */     this.items[this.itemCount] = null;
/* 1162 */     if (this.itemCount == 0) resetCustomDraw();
/*      */   }
/*      */   
/*      */   boolean dragDetect(int x, int y, boolean filter, boolean dragOnTimeout, boolean[] consume)
/*      */   {
/* 1167 */     boolean selected = false;
/* 1168 */     if (OS.isX11()) {
/* 1169 */       if (filter) {
/* 1170 */         long[] path = new long[1];
/* 1171 */         if (GTK.gtk_tree_view_get_path_at_pos(this.handle, x, y, path, null, null, null)) {
/* 1172 */           if (path[0] != 0L) {
/* 1173 */             long selection = GTK.gtk_tree_view_get_selection(this.handle);
/* 1174 */             if (GTK.gtk_tree_selection_path_is_selected(selection, path[0])) selected = true;
/* 1175 */             GTK.gtk_tree_path_free(path[0]);
/*      */           }
/*      */         } else {
/* 1178 */           return false;
/*      */         }
/*      */       }
/* 1181 */       boolean dragDetect = super.dragDetect(x, y, filter, false, consume);
/* 1182 */       if ((dragDetect) && (selected) && (consume != null)) consume[0] = true;
/* 1183 */       return dragDetect;
/*      */     }
/* 1185 */     double[] startX = new double[1];
/* 1186 */     double[] startY = new double[1];
/* 1187 */     long[] path = new long[1];
/* 1188 */     if (GTK.gtk_gesture_drag_get_start_point(this.dragGesture, startX, startY)) {
/* 1189 */       if (getHeaderVisible()) {
/* 1190 */         startY[0] -= getHeaderHeightInPixels();
/*      */       }
/* 1192 */       if (GTK.gtk_tree_view_get_path_at_pos(this.handle, (int)startX[0], (int)startY[0], path, null, null, null)) {
/* 1193 */         if (path[0] != 0L) {
/* 1194 */           boolean dragDetect = super.dragDetect(x, y, filter, false, consume);
/* 1195 */           if ((dragDetect) && (selected) && (consume != null)) consume[0] = true;
/* 1196 */           return dragDetect;
/*      */         }
/*      */       } else {
/* 1199 */         return false;
/*      */       }
/*      */     }
/*      */     
/* 1203 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */   long eventWindow()
/*      */   {
/* 1209 */     return paintWindow();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   boolean fixAccessibility()
/*      */   {
/* 1224 */     return true;
/*      */   }
/*      */   
/*      */   void fixChildren(Shell newShell, Shell oldShell, Decorations newDecorations, Decorations oldDecorations, Menu[] menus)
/*      */   {
/* 1229 */     super.fixChildren(newShell, oldShell, newDecorations, oldDecorations, menus);
/* 1230 */     for (int i = 0; i < this.columnCount; i++) {
/* 1231 */       TableColumn column = this.columns[i];
/* 1232 */       if (column.toolTipText != null) {
/* 1233 */         column.setToolTipText(oldShell, null);
/* 1234 */         column.setToolTipText(newShell, column.toolTipText);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   GdkColor getBackgroundGdkColor()
/*      */   {
/* 1241 */     return getBaseGdkColor();
/*      */   }
/*      */   
/*      */   Rectangle getClientAreaInPixels()
/*      */   {
/* 1246 */     checkWidget();
/* 1247 */     forceResize();
/* 1248 */     GTK.gtk_widget_realize(this.handle);
/* 1249 */     long fixedWindow = gtk_widget_get_window(this.fixedHandle);
/* 1250 */     long binWindow = GTK.gtk_tree_view_get_bin_window(this.handle);
/* 1251 */     int[] binX = new int[1];int[] binY = new int[1];
/* 1252 */     GDK.gdk_window_get_origin(binWindow, binX, binY);
/* 1253 */     int[] fixedX = new int[1];int[] fixedY = new int[1];
/* 1254 */     GDK.gdk_window_get_origin(fixedWindow, fixedX, fixedY);
/* 1255 */     long clientHandle = clientHandle();
/* 1256 */     GtkAllocation allocation = new GtkAllocation();
/* 1257 */     GTK.gtk_widget_get_allocation(clientHandle, allocation);
/* 1258 */     int width = (this.state & 0x200) != 0 ? 0 : allocation.width;
/* 1259 */     int height = (this.state & 0x400) != 0 ? 0 : allocation.height;
/* 1260 */     Rectangle rect = new Rectangle(fixedX[0] - binX[0], fixedY[0] - binY[0], width, height);
/* 1261 */     return rect;
/*      */   }
/*      */   
/*      */   int getClientWidth()
/*      */   {
/* 1266 */     int[] w = new int[1];int[] h = new int[1];
/* 1267 */     GTK.gtk_widget_realize(this.handle);
/* 1268 */     gdk_window_get_size(GTK.gtk_tree_view_get_bin_window(this.handle), w, h);
/* 1269 */     return w[0];
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public TableColumn getColumn(int index)
/*      */   {
/* 1300 */     checkWidget();
/* 1301 */     if ((0 > index) || (index >= this.columnCount)) error(6);
/* 1302 */     return this.columns[index];
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getColumnCount()
/*      */   {
/* 1320 */     checkWidget();
/* 1321 */     return this.columnCount;
/*      */   }
/*      */   
/*      */   long[] getColumnTypes(int columnCount) {
/* 1325 */     long[] types = new long[5 + columnCount * 5];
/*      */     
/* 1327 */     types[0] = OS.G_TYPE_BOOLEAN();
/* 1328 */     types[1] = OS.G_TYPE_BOOLEAN();
/* 1329 */     types[2] = (GTK.GTK3 ? GDK.GDK_TYPE_RGBA() : GDK.GDK_TYPE_COLOR());
/* 1330 */     types[3] = (GTK.GTK3 ? GDK.GDK_TYPE_RGBA() : GDK.GDK_TYPE_COLOR());
/* 1331 */     types[4] = OS.PANGO_TYPE_FONT_DESCRIPTION();
/*      */     
/* 1333 */     for (int i = 5; i < types.length; i += 5) {
/* 1334 */       types[(i + 0)] = GDK.GDK_TYPE_PIXBUF();
/* 1335 */       types[(i + 1)] = OS.G_TYPE_STRING();
/* 1336 */       types[(i + 2)] = (GTK.GTK3 ? GDK.GDK_TYPE_RGBA() : GDK.GDK_TYPE_COLOR());
/* 1337 */       types[(i + 3)] = (GTK.GTK3 ? GDK.GDK_TYPE_RGBA() : GDK.GDK_TYPE_COLOR());
/* 1338 */       types[(i + 4)] = OS.PANGO_TYPE_FONT_DESCRIPTION();
/*      */     }
/* 1340 */     return types;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int[] getColumnOrder()
/*      */   {
/* 1372 */     checkWidget();
/* 1373 */     if (this.columnCount == 0) return new int[0];
/* 1374 */     long list = GTK.gtk_tree_view_get_columns(this.handle);
/* 1375 */     if (list == 0L) return new int[0];
/* 1376 */     int i = 0;int count = OS.g_list_length(list);
/* 1377 */     int[] order = new int[count];
/* 1378 */     long temp = list;
/* 1379 */     while (temp != 0L) {
/* 1380 */       long column = OS.g_list_data(temp);
/* 1381 */       if (column != 0L) {
/* 1382 */         for (int j = 0; j < this.columnCount; j++) {
/* 1383 */           if (this.columns[j].handle == column) {
/* 1384 */             order[(i++)] = j;
/* 1385 */             break;
/*      */           }
/*      */         }
/*      */       }
/* 1389 */       temp = OS.g_list_next(temp);
/*      */     }
/* 1391 */     OS.g_list_free(list);
/* 1392 */     return order;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public TableColumn[] getColumns()
/*      */   {
/* 1423 */     checkWidget();
/* 1424 */     TableColumn[] result = new TableColumn[this.columnCount];
/* 1425 */     System.arraycopy(this.columns, 0, result, 0, this.columnCount);
/* 1426 */     return result;
/*      */   }
/*      */   
/*      */   GdkRGBA getContextBackgroundGdkRGBA()
/*      */   {
/* 1431 */     assert (GTK.GTK3) : "GTK3 code was run by GTK2";
/* 1432 */     if (this.background != null) {
/* 1433 */       return this.background;
/*      */     }
/*      */     
/*      */ 
/* 1437 */     return defaultBackground();
/*      */   }
/*      */   
/*      */ 
/*      */   GdkRGBA getContextColorGdkRGBA()
/*      */   {
/* 1443 */     assert (GTK.GTK3) : "GTK3 code was run by GTK2";
/* 1444 */     if (GTK.GTK_VERSION >= OS.VERSION(3, 14, 0)) {
/* 1445 */       if (this.foreground != null) {
/* 1446 */         return this.foreground;
/*      */       }
/* 1448 */       return this.display.COLOR_LIST_FOREGROUND_RGBA;
/*      */     }
/*      */     
/* 1451 */     return super.getContextColorGdkRGBA();
/*      */   }
/*      */   
/*      */   TableItem getFocusItem()
/*      */   {
/* 1456 */     long[] path = new long[1];
/* 1457 */     GTK.gtk_tree_view_get_cursor(this.handle, path, null);
/* 1458 */     if (path[0] == 0L) return null;
/* 1459 */     TableItem item = null;
/* 1460 */     long indices = GTK.gtk_tree_path_get_indices(path[0]);
/* 1461 */     if (indices != 0L) {
/* 1462 */       int[] index = { -1 };
/* 1463 */       C.memmove(index, indices, 4L);
/* 1464 */       item = _getItem(index[0]);
/*      */     }
/* 1466 */     GTK.gtk_tree_path_free(path[0]);
/* 1467 */     return item;
/*      */   }
/*      */   
/*      */   GdkColor getForegroundGdkColor()
/*      */   {
/* 1472 */     assert (!GTK.GTK3) : "GTK2 code was run by GTK3";
/* 1473 */     return getTextColor();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getGridLineWidth()
/*      */   {
/* 1487 */     checkWidget();
/* 1488 */     return DPIUtil.autoScaleDown(getGridLineWidthInPixels());
/*      */   }
/*      */   
/*      */   int getGridLineWidthInPixels() {
/* 1492 */     checkWidget();
/* 1493 */     return 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Color getHeaderBackground()
/*      */   {
/* 1508 */     checkWidget();
/* 1509 */     return this.headerBackground != null ? this.headerBackground : this.display.getSystemColor(25);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Color getHeaderForeground()
/*      */   {
/* 1524 */     checkWidget();
/* 1525 */     return this.headerForeground != null ? this.headerForeground : this.display.getSystemColor(24);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getHeaderHeight()
/*      */   {
/* 1541 */     checkWidget();
/* 1542 */     return DPIUtil.autoScaleDown(getHeaderHeightInPixels());
/*      */   }
/*      */   
/*      */   int getHeaderHeightInPixels() {
/* 1546 */     checkWidget();
/* 1547 */     if (!GTK.gtk_tree_view_get_headers_visible(this.handle)) return 0;
/* 1548 */     if (this.columnCount > 0) {
/* 1549 */       GtkRequisition requisition = new GtkRequisition();
/* 1550 */       int height = 0;
/* 1551 */       for (int i = 0; i < this.columnCount; i++) {
/* 1552 */         long buttonHandle = this.columns[i].buttonHandle;
/* 1553 */         if (buttonHandle != 0L) {
/* 1554 */           if ((GTK.GTK_VERSION >= OS.VERSION(3, 8, 0)) && (!GTK.gtk_widget_get_visible(buttonHandle))) {
/* 1555 */             GTK.gtk_widget_show(buttonHandle);
/* 1556 */             gtk_widget_get_preferred_size(buttonHandle, requisition);
/* 1557 */             GTK.gtk_widget_hide(buttonHandle);
/*      */           } else {
/* 1559 */             gtk_widget_get_preferred_size(buttonHandle, requisition);
/*      */           }
/* 1561 */           height = Math.max(height, requisition.height);
/*      */         }
/*      */       }
/* 1564 */       return height;
/*      */     }
/* 1566 */     GTK.gtk_widget_realize(this.handle);
/* 1567 */     long fixedWindow = gtk_widget_get_window(this.fixedHandle);
/* 1568 */     long binWindow = GTK.gtk_tree_view_get_bin_window(this.handle);
/* 1569 */     int[] binY = new int[1];
/* 1570 */     GDK.gdk_window_get_origin(binWindow, null, binY);
/* 1571 */     int[] fixedY = new int[1];
/* 1572 */     GDK.gdk_window_get_origin(fixedWindow, null, fixedY);
/* 1573 */     return binY[0] - fixedY[0];
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getHeaderVisible()
/*      */   {
/* 1594 */     checkWidget();
/* 1595 */     return GTK.gtk_tree_view_get_headers_visible(this.handle);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public TableItem getItem(int index)
/*      */   {
/* 1614 */     checkWidget();
/* 1615 */     if ((0 > index) || (index >= this.itemCount)) error(6);
/* 1616 */     return _getItem(index);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public TableItem getItem(Point point)
/*      */   {
/* 1643 */     checkWidget();
/* 1644 */     return getItemInPixels(DPIUtil.autoScaleUp(point));
/*      */   }
/*      */   
/*      */   TableItem getItemInPixels(Point point) {
/* 1648 */     checkWidget();
/* 1649 */     if (point == null) error(4);
/* 1650 */     long[] path = new long[1];
/* 1651 */     GTK.gtk_widget_realize(this.handle);
/* 1652 */     int y = point.y;
/* 1653 */     if (!GTK.gtk_tree_view_get_path_at_pos(this.handle, point.x, y, path, null, null, null)) return null;
/* 1654 */     if (path[0] == 0L) return null;
/* 1655 */     long indices = GTK.gtk_tree_path_get_indices(path[0]);
/* 1656 */     TableItem item = null;
/* 1657 */     if (indices != 0L) {
/* 1658 */       int[] index = new int[1];
/* 1659 */       C.memmove(index, indices, 4L);
/* 1660 */       item = _getItem(index[0]);
/*      */     }
/* 1662 */     GTK.gtk_tree_path_free(path[0]);
/* 1663 */     return item;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getItemCount()
/*      */   {
/* 1677 */     checkWidget();
/* 1678 */     return this.itemCount;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getItemHeight()
/*      */   {
/* 1693 */     checkWidget();
/* 1694 */     return DPIUtil.autoScaleDown(getItemHeightInPixels());
/*      */   }
/*      */   
/*      */   int getItemHeightInPixels() {
/* 1698 */     checkWidget();
/* 1699 */     if (this.itemCount == 0) {
/* 1700 */       long column = GTK.gtk_tree_view_get_column(this.handle, 0);
/* 1701 */       int[] w = new int[1];int[] h = new int[1];
/* 1702 */       this.ignoreSize = true;
/* 1703 */       GTK.gtk_tree_view_column_cell_get_size(column, null, null, null, w, h);
/* 1704 */       int height = h[0];
/* 1705 */       if (GTK.GTK3) {
/* 1706 */         long textRenderer = getTextRenderer(column);
/* 1707 */         GTK.gtk_cell_renderer_get_preferred_height_for_width(textRenderer, this.handle, 0, h, null);
/* 1708 */         height += h[0];
/*      */       }
/* 1710 */       this.ignoreSize = false;
/* 1711 */       return height;
/*      */     }
/* 1713 */     int height = 0;
/* 1714 */     long iter = OS.g_malloc(GTK.GtkTreeIter_sizeof());
/* 1715 */     GTK.gtk_tree_model_get_iter_first(this.modelHandle, iter);
/* 1716 */     int columnCount = Math.max(1, this.columnCount);
/* 1717 */     for (int i = 0; i < columnCount; i++) {
/* 1718 */       long column = GTK.gtk_tree_view_get_column(this.handle, i);
/* 1719 */       GTK.gtk_tree_view_column_cell_set_cell_data(column, this.modelHandle, iter, false, false);
/* 1720 */       int[] w = new int[1];int[] h = new int[1];
/* 1721 */       GTK.gtk_tree_view_column_cell_get_size(column, null, null, null, w, h);
/* 1722 */       height = Math.max(height, h[0]);
/*      */     }
/* 1724 */     OS.g_free(iter);
/* 1725 */     return height;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public TableItem[] getItems()
/*      */   {
/* 1746 */     checkWidget();
/* 1747 */     TableItem[] result = new TableItem[this.itemCount];
/* 1748 */     if ((this.style & 0x10000000) != 0) {
/* 1749 */       for (int i = 0; i < this.itemCount; i++) {
/* 1750 */         result[i] = _getItem(i);
/*      */       }
/*      */     } else {
/* 1753 */       System.arraycopy(this.items, 0, result, 0, this.itemCount);
/*      */     }
/* 1755 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getLinesVisible()
/*      */   {
/* 1777 */     checkWidget();
/* 1778 */     if (GTK.GTK3) {
/* 1779 */       return GTK.gtk_tree_view_get_grid_lines(this.handle) > 0;
/*      */     }
/* 1781 */     return GTK.gtk_tree_view_get_rules_hint(this.handle);
/*      */   }
/*      */   
/*      */   long getPixbufRenderer(long column)
/*      */   {
/* 1786 */     long list = GTK.gtk_cell_layout_get_cells(column);
/* 1787 */     if (list == 0L) return 0L;
/* 1788 */     long originalList = list;
/* 1789 */     long pixbufRenderer = 0L;
/* 1790 */     while (list != 0L) {
/* 1791 */       long renderer = OS.g_list_data(list);
/* 1792 */       if (GTK.GTK_IS_CELL_RENDERER_PIXBUF(renderer)) {
/* 1793 */         pixbufRenderer = renderer;
/* 1794 */         break;
/*      */       }
/* 1796 */       list = OS.g_list_next(list);
/*      */     }
/* 1798 */     OS.g_list_free(originalList);
/* 1799 */     return pixbufRenderer;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public TableItem[] getSelection()
/*      */   {
/* 1819 */     checkWidget();
/* 1820 */     long selection = GTK.gtk_tree_view_get_selection(this.handle);
/* 1821 */     long list = GTK.gtk_tree_selection_get_selected_rows(selection, null);
/* 1822 */     long originalList = list;
/* 1823 */     if (list != 0L) {
/* 1824 */       int count = OS.g_list_length(list);
/* 1825 */       int[] treeSelection = new int[count];
/* 1826 */       int length = 0;
/* 1827 */       for (int i = 0; i < count; i++) {
/* 1828 */         long data = OS.g_list_data(list);
/* 1829 */         long indices = GTK.gtk_tree_path_get_indices(data);
/* 1830 */         if (indices != 0L) {
/* 1831 */           int[] index = new int[1];
/* 1832 */           C.memmove(index, indices, 4L);
/* 1833 */           treeSelection[length] = index[0];
/* 1834 */           length++;
/*      */         }
/* 1836 */         GTK.gtk_tree_path_free(data);
/* 1837 */         list = OS.g_list_next(list);
/*      */       }
/* 1839 */       OS.g_list_free(originalList);
/* 1840 */       TableItem[] result = new TableItem[length];
/* 1841 */       for (int i = 0; i < result.length; i++) result[i] = _getItem(treeSelection[i]);
/* 1842 */       return result;
/*      */     }
/* 1844 */     return new TableItem[0];
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getSelectionCount()
/*      */   {
/* 1858 */     checkWidget();
/* 1859 */     long selection = GTK.gtk_tree_view_get_selection(this.handle);
/* 1860 */     return GTK.gtk_tree_selection_count_selected_rows(selection);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getSelectionIndex()
/*      */   {
/* 1875 */     checkWidget();
/* 1876 */     long selection = GTK.gtk_tree_view_get_selection(this.handle);
/* 1877 */     long list = GTK.gtk_tree_selection_get_selected_rows(selection, null);
/* 1878 */     long originalList = list;
/* 1879 */     if (list != 0L) {
/* 1880 */       int[] index = new int[1];
/* 1881 */       boolean foundIndex = false;
/* 1882 */       while (list != 0L) {
/* 1883 */         long data = OS.g_list_data(list);
/* 1884 */         if (!foundIndex) {
/* 1885 */           long indices = GTK.gtk_tree_path_get_indices(data);
/* 1886 */           if (indices != 0L) {
/* 1887 */             C.memmove(index, indices, 4L);
/* 1888 */             foundIndex = true;
/*      */           }
/*      */         }
/* 1891 */         list = OS.g_list_next(list);
/* 1892 */         GTK.gtk_tree_path_free(data);
/*      */       }
/* 1894 */       OS.g_list_free(originalList);
/* 1895 */       return index[0];
/*      */     }
/* 1897 */     return -1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int[] getSelectionIndices()
/*      */   {
/* 1917 */     checkWidget();
/* 1918 */     long selection = GTK.gtk_tree_view_get_selection(this.handle);
/* 1919 */     long list = GTK.gtk_tree_selection_get_selected_rows(selection, null);
/* 1920 */     long originalList = list;
/* 1921 */     if (list != 0L) {
/* 1922 */       int count = OS.g_list_length(list);
/* 1923 */       int[] treeSelection = new int[count];
/* 1924 */       int length = 0;
/* 1925 */       for (int i = 0; i < count; i++) {
/* 1926 */         long data = OS.g_list_data(list);
/* 1927 */         long indices = GTK.gtk_tree_path_get_indices(data);
/* 1928 */         if (indices != 0L) {
/* 1929 */           int[] index = new int[1];
/* 1930 */           C.memmove(index, indices, 4L);
/* 1931 */           treeSelection[length] = index[0];
/* 1932 */           length++;
/*      */         }
/* 1934 */         list = OS.g_list_next(list);
/* 1935 */         GTK.gtk_tree_path_free(data);
/*      */       }
/* 1937 */       OS.g_list_free(originalList);
/* 1938 */       int[] result = new int[length];
/* 1939 */       System.arraycopy(treeSelection, 0, result, 0, length);
/* 1940 */       return result;
/*      */     }
/* 1942 */     return new int[0];
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public TableColumn getSortColumn()
/*      */   {
/* 1962 */     checkWidget();
/* 1963 */     return this.sortColumn;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getSortDirection()
/*      */   {
/* 1983 */     checkWidget();
/* 1984 */     return this.sortDirection;
/*      */   }
/*      */   
/*      */   long getTextRenderer(long column) {
/* 1988 */     long list = GTK.gtk_cell_layout_get_cells(column);
/* 1989 */     if (list == 0L) return 0L;
/* 1990 */     long originalList = list;
/* 1991 */     long textRenderer = 0L;
/* 1992 */     while (list != 0L) {
/* 1993 */       long renderer = OS.g_list_data(list);
/* 1994 */       if (GTK.GTK_IS_CELL_RENDERER_TEXT(renderer)) {
/* 1995 */         textRenderer = renderer;
/* 1996 */         break;
/*      */       }
/* 1998 */       list = OS.g_list_next(list);
/*      */     }
/* 2000 */     OS.g_list_free(originalList);
/* 2001 */     return textRenderer;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getTopIndex()
/*      */   {
/* 2017 */     checkWidget();
/*      */     
/*      */ 
/*      */     long vAdjustment;
/*      */     
/*      */     long vAdjustment;
/*      */     
/* 2024 */     if (GTK.GTK3) {
/* 2025 */       vAdjustment = GTK.gtk_scrollable_get_vadjustment(this.handle);
/*      */     } else {
/* 2027 */       vAdjustment = GTK.gtk_tree_view_get_vadjustment(this.handle);
/*      */     }
/* 2029 */     this.currentAdjustment = GTK.gtk_adjustment_get_value(vAdjustment);
/* 2030 */     if (this.cachedAdjustment == this.currentAdjustment) {
/* 2031 */       return this.topIndex;
/*      */     }
/* 2033 */     long[] path = new long[1];
/* 2034 */     GTK.gtk_widget_realize(this.handle);
/* 2035 */     if (!GTK.gtk_tree_view_get_path_at_pos(this.handle, 1, 1, path, null, null, null)) return 0;
/* 2036 */     if (path[0] == 0L) return 0;
/* 2037 */     long indices = GTK.gtk_tree_path_get_indices(path[0]);
/* 2038 */     int[] index = new int[1];
/* 2039 */     if (indices != 0L) C.memmove(index, indices, 4L);
/* 2040 */     GTK.gtk_tree_path_free(path[0]);
/* 2041 */     return index[0];
/*      */   }
/*      */   
/*      */ 
/*      */   long gtk_button_press_event(long widget, long event)
/*      */   {
/* 2047 */     GdkEventButton gdkEvent = new GdkEventButton();
/* 2048 */     OS.memmove(gdkEvent, event, GdkEventButton.sizeof);
/* 2049 */     if (gdkEvent.window != GTK.gtk_tree_view_get_bin_window(this.handle)) return 0L;
/* 2050 */     long result = super.gtk_button_press_event(widget, event);
/* 2051 */     if (result != 0L) { return result;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2058 */     if (((this.state & 0x800000) != 0) && (hooks(29)) && 
/* 2059 */       (!OS.isX11()) && (gdkEvent.type == 4))
/*      */     {
/* 2061 */       long nextEvent = GDK.gdk_event_peek();
/* 2062 */       if (nextEvent == 0L) {
/* 2063 */         long[] path = new long[1];
/* 2064 */         long selection = GTK.gtk_tree_view_get_selection(this.handle);
/* 2065 */         if ((GTK.gtk_tree_view_get_path_at_pos(this.handle, (int)gdkEvent.x, (int)gdkEvent.y, path, null, null, null)) && (path[0] != 0L))
/*      */         {
/*      */ 
/* 2068 */           this.selectionCountOnPress = getSelectionCount();
/* 2069 */           if ((GTK.gtk_tree_selection_path_is_selected(selection, path[0])) && (
/* 2070 */             ((gdkEvent.state & 0x5) == 0) || ((gdkEvent.state & 0x4) != 0)))
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2079 */             long gtk_false_funcPtr = GTK.GET_FUNCTION_POINTER_gtk_false();
/* 2080 */             GTK.gtk_tree_selection_set_select_function(selection, gtk_false_funcPtr, 0L, 0L);
/*      */           }
/*      */         }
/*      */       }
/*      */       else {
/* 2085 */         GDK.gdk_event_free(nextEvent);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2096 */     int button = gdkEvent.button;
/* 2097 */     if ((button == 3) && (gdkEvent.type == 4)) {
/* 2098 */       long[] path = new long[1];
/* 2099 */       if ((GTK.gtk_tree_view_get_path_at_pos(this.handle, (int)gdkEvent.x, (int)gdkEvent.y, path, null, null, null)) && 
/* 2100 */         (path[0] != 0L)) {
/* 2101 */         long selection = GTK.gtk_tree_view_get_selection(this.handle);
/* 2102 */         if (GTK.gtk_tree_selection_path_is_selected(selection, path[0])) result = 1L;
/* 2103 */         GTK.gtk_tree_path_free(path[0]);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2115 */     if (((this.style & 0x4) != 0) && (getSelectionCount() == 0)) {
/* 2116 */       long[] path = new long[1];
/* 2117 */       if ((GTK.gtk_tree_view_get_path_at_pos(this.handle, (int)gdkEvent.x, (int)gdkEvent.y, path, null, null, null)) && 
/* 2118 */         (path[0] != 0L)) {
/* 2119 */         long selection = GTK.gtk_tree_view_get_selection(this.handle);
/* 2120 */         OS.g_signal_handlers_block_matched(selection, 16, 0, 0, 0L, 0L, 6L);
/* 2121 */         GTK.gtk_tree_view_set_cursor(this.handle, path[0], 0L, false);
/* 2122 */         OS.g_signal_handlers_unblock_matched(selection, 16, 0, 0, 0L, 0L, 6L);
/* 2123 */         GTK.gtk_tree_path_free(path[0]);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 2129 */     if (gdkEvent.type == 5) {
/* 2130 */       sendTreeDefaultSelection();
/*      */     }
/*      */     
/* 2133 */     return result;
/*      */   }
/*      */   
/*      */   long gtk_key_press_event(long widget, long event)
/*      */   {
/* 2138 */     GdkEventKey keyEvent = new GdkEventKey();
/* 2139 */     OS.memmove(keyEvent, event, GdkEventKey.sizeof);
/* 2140 */     int key = keyEvent.keyval;
/* 2141 */     keyPressDefaultSelectionHandler(event, key);
/* 2142 */     return super.gtk_key_press_event(widget, event);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   void keyPressDefaultSelectionHandler(long event, int key)
/*      */   {
/* 2150 */     int keymask = gdk_event_get_state(event);
/* 2151 */     switch (key)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */     case 65293: 
/* 2157 */       if ((keymask & 0x1C000008) == 0) {
/* 2158 */         sendTreeDefaultSelection();
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */       break;
/*      */     }
/*      */     
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   void sendTreeDefaultSelection()
/*      */   {
/* 2172 */     TableItem tableItem = getFocusItem();
/* 2173 */     if (tableItem == null) {
/* 2174 */       return;
/*      */     }
/* 2176 */     Event event = new Event();
/* 2177 */     event.item = tableItem;
/*      */     
/* 2179 */     sendSelectionEvent(14, event, false);
/*      */   }
/*      */   
/*      */ 
/*      */   long gtk_button_release_event(long widget, long event)
/*      */   {
/* 2185 */     GdkEventButton gdkEvent = new GdkEventButton();
/* 2186 */     OS.memmove(gdkEvent, event, GdkEventButton.sizeof);
/*      */     
/* 2188 */     this.lastInput.x = ((int)gdkEvent.x);
/* 2189 */     this.lastInput.y = ((int)gdkEvent.y);
/* 2190 */     if (containedInRegion(this.lastInput.x, this.lastInput.y)) return 0L;
/* 2191 */     if (gdkEvent.window != GTK.gtk_tree_view_get_bin_window(this.handle)) { return 0L;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2199 */     if (((this.state & 0x800000) != 0) && (hooks(29)) && (!OS.isX11())) {
/* 2200 */       long[] path = new long[1];
/* 2201 */       long selection = GTK.gtk_tree_view_get_selection(this.handle);
/*      */       
/* 2203 */       GTK.gtk_tree_selection_set_select_function(selection, 0L, 0L, 0L);
/* 2204 */       if ((GTK.gtk_tree_view_get_path_at_pos(this.handle, (int)gdkEvent.x, (int)gdkEvent.y, path, null, null, null)) && (path[0] != 0L) && 
/* 2205 */         (GTK.gtk_tree_selection_path_is_selected(selection, path[0]))) {
/* 2206 */         this.selectionCountOnRelease = getSelectionCount();
/* 2207 */         if ((gdkEvent.state & 0x5) == 0) {
/* 2208 */           GTK.gtk_tree_view_set_cursor(this.handle, path[0], 0L, false);
/*      */         }
/*      */         
/*      */ 
/* 2212 */         if (((gdkEvent.state & 0x4) != 0) && (this.selectionCountOnRelease == this.selectionCountOnPress)) {
/* 2213 */           GTK.gtk_tree_selection_unselect_path(selection, path[0]);
/*      */         }
/*      */       }
/*      */     }
/* 2217 */     return super.gtk_button_release_event(widget, event);
/*      */   }
/*      */   
/*      */   long gtk_changed(long widget)
/*      */   {
/* 2222 */     TableItem item = getFocusItem();
/* 2223 */     if (item != null) {
/* 2224 */       Event event = new Event();
/* 2225 */       event.item = item;
/* 2226 */       sendSelectionEvent(13, event, false);
/*      */     }
/* 2228 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_event_after(long widget, long gdkEvent)
/*      */   {
/* 2233 */     switch (GDK.GDK_EVENT_TYPE(gdkEvent))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 2: 
/* 2242 */       if (GTK.gtk_tree_model_iter_n_children(this.modelHandle, 0L) == 0) {
/* 2243 */         gtk_expose_event(widget, gdkEvent);
/*      */       }
/*      */       break;
/*      */     }
/*      */     
/* 2248 */     return super.gtk_event_after(widget, gdkEvent);
/*      */   }
/*      */   
/*      */   void drawInheritedBackground(long eventPtr, long cairo) {
/* 2252 */     if (((this.state & 0x8000) != 0) || (this.backgroundImage != null)) {
/* 2253 */       Control control = findBackgroundControl();
/* 2254 */       if (control != null) {
/* 2255 */         long window = GTK.gtk_tree_view_get_bin_window(this.handle);
/* 2256 */         long rgn = 0L;
/* 2257 */         if (eventPtr != 0L) {
/* 2258 */           GdkEventExpose gdkEvent = new GdkEventExpose();
/* 2259 */           OS.memmove(gdkEvent, eventPtr, GdkEventExpose.sizeof);
/* 2260 */           if (window != gdkEvent.window) return;
/* 2261 */           rgn = gdkEvent.region;
/*      */         }
/* 2263 */         int[] width = new int[1];int[] height = new int[1];
/* 2264 */         gdk_window_get_size(window, width, height);
/* 2265 */         int bottom = 0;
/* 2266 */         if (this.itemCount != 0) {
/* 2267 */           long iter = OS.g_malloc(GTK.GtkTreeIter_sizeof());
/* 2268 */           GTK.gtk_tree_model_iter_nth_child(this.modelHandle, iter, 0L, this.itemCount - 1);
/* 2269 */           long path = GTK.gtk_tree_model_get_path(this.modelHandle, iter);
/* 2270 */           GdkRectangle rect = new GdkRectangle();
/* 2271 */           GTK.gtk_tree_view_get_cell_area(this.handle, path, 0L, rect);
/* 2272 */           bottom = rect.y + rect.height;
/* 2273 */           GTK.gtk_tree_path_free(path);
/* 2274 */           OS.g_free(iter);
/*      */         }
/* 2276 */         if (height[0] > bottom) {
/* 2277 */           drawBackground(control, window, cairo, rgn, 0, bottom, width[0], height[0] - bottom);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   long gtk_draw(long widget, long cairo)
/*      */   {
/* 2285 */     if ((this.state & 0x40) != 0) return 0L;
/* 2286 */     drawInheritedBackground(0L, cairo);
/* 2287 */     return super.gtk_draw(widget, cairo);
/*      */   }
/*      */   
/*      */   long gtk_expose_event(long widget, long eventPtr)
/*      */   {
/* 2292 */     if ((this.state & 0x40) != 0) return 0L;
/* 2293 */     drawInheritedBackground(eventPtr, 0L);
/* 2294 */     return super.gtk_expose_event(widget, eventPtr);
/*      */   }
/*      */   
/*      */   long gtk_motion_notify_event(long widget, long event)
/*      */   {
/* 2299 */     long window = GDK.GDK_EVENT_WINDOW(event);
/* 2300 */     if (window != GTK.gtk_tree_view_get_bin_window(this.handle)) return 0L;
/* 2301 */     return super.gtk_motion_notify_event(widget, event);
/*      */   }
/*      */   
/*      */   long gtk_row_deleted(long model, long path)
/*      */   {
/* 2306 */     if (this.ignoreAccessibility) {
/* 2307 */       OS.g_signal_stop_emission_by_name(model, OS.row_deleted);
/*      */     }
/* 2309 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_row_inserted(long model, long path, long iter)
/*      */   {
/* 2314 */     if (this.ignoreAccessibility) {
/* 2315 */       OS.g_signal_stop_emission_by_name(model, OS.row_inserted);
/*      */     }
/* 2317 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_start_interactive_search(long widget) {
/* 2321 */     if (!searchEnabled()) {
/* 2322 */       OS.g_signal_stop_emission_by_name(widget, OS.start_interactive_search);
/* 2323 */       return 1L;
/*      */     }
/* 2325 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_toggled(long renderer, long pathStr) {
/* 2329 */     long path = GTK.gtk_tree_path_new_from_string(pathStr);
/* 2330 */     if (path == 0L) return 0L;
/* 2331 */     long indices = GTK.gtk_tree_path_get_indices(path);
/* 2332 */     if (indices != 0L) {
/* 2333 */       int[] index = new int[1];
/* 2334 */       C.memmove(index, indices, 4L);
/* 2335 */       TableItem item = _getItem(index[0]);
/* 2336 */       item.setChecked(!item.getChecked());
/* 2337 */       Event event = new Event();
/* 2338 */       event.detail = 32;
/* 2339 */       event.item = item;
/* 2340 */       sendSelectionEvent(13, event, false);
/*      */     }
/* 2342 */     GTK.gtk_tree_path_free(path);
/* 2343 */     return 0L;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void gtk_widget_size_request(long widget, GtkRequisition requisition)
/*      */   {
/* 2354 */     if (this.columnCount == 0) {
/* 2355 */       super.gtk_widget_size_request(widget, requisition);
/* 2356 */       return;
/*      */     }
/* 2358 */     long columns = GTK.gtk_tree_view_get_columns(this.handle);long list = columns;
/* 2359 */     boolean fixVisible = columns != 0L;
/* 2360 */     while (list != 0L) {
/* 2361 */       long column = OS.g_list_data(list);
/* 2362 */       if (GTK.gtk_tree_view_column_get_visible(column)) {
/* 2363 */         fixVisible = false;
/* 2364 */         break;
/*      */       }
/* 2366 */       list = OS.g_list_next(list);
/*      */     }
/* 2368 */     long columnHandle = 0L;
/* 2369 */     if (fixVisible) {
/* 2370 */       columnHandle = OS.g_list_data(columns);
/* 2371 */       GTK.gtk_tree_view_column_set_visible(columnHandle, true);
/*      */     }
/* 2373 */     super.gtk_widget_size_request(widget, requisition);
/* 2374 */     if (fixVisible) {
/* 2375 */       GTK.gtk_tree_view_column_set_visible(columnHandle, false);
/*      */     }
/* 2377 */     if (columns != 0L) OS.g_list_free(columns);
/*      */   }
/*      */   
/*      */   void hideFirstColumn() {
/* 2381 */     long firstColumn = GTK.gtk_tree_view_get_column(this.handle, 0);
/* 2382 */     GTK.gtk_tree_view_column_set_visible(firstColumn, false);
/*      */   }
/*      */   
/*      */   void hookEvents()
/*      */   {
/* 2387 */     super.hookEvents();
/* 2388 */     long selection = GTK.gtk_tree_view_get_selection(this.handle);
/* 2389 */     OS.g_signal_connect_closure(selection, OS.changed, this.display.getClosure(6), false);
/* 2390 */     OS.g_signal_connect_closure(this.handle, OS.row_activated, this.display.getClosure(41), false);
/* 2391 */     if (this.checkRenderer != 0L) {
/* 2392 */       OS.g_signal_connect_closure(this.checkRenderer, OS.toggled, this.display.getClosure(53), false);
/*      */     }
/* 2394 */     OS.g_signal_connect_closure(this.handle, OS.start_interactive_search, this.display.getClosure(69), false);
/* 2395 */     if (fixAccessibility()) {
/* 2396 */       OS.g_signal_connect_closure(this.modelHandle, OS.row_inserted, this.display.getClosure(64), true);
/* 2397 */       OS.g_signal_connect_closure(this.modelHandle, OS.row_deleted, this.display.getClosure(65), true);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int indexOf(TableColumn column)
/*      */   {
/* 2419 */     checkWidget();
/* 2420 */     if (column == null) error(4);
/* 2421 */     for (int i = 0; i < this.columnCount; i++) {
/* 2422 */       if (this.columns[i] == column) return i;
/*      */     }
/* 2424 */     return -1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int indexOf(TableItem item)
/*      */   {
/* 2445 */     checkWidget();
/* 2446 */     if (item == null) error(4);
/* 2447 */     if ((1 <= this.lastIndexOf) && (this.lastIndexOf < this.itemCount - 1)) {
/* 2448 */       if (this.items[this.lastIndexOf] == item) return this.lastIndexOf;
/* 2449 */       if (this.items[(this.lastIndexOf + 1)] == item) return ++this.lastIndexOf;
/* 2450 */       if (this.items[(this.lastIndexOf - 1)] == item) return --this.lastIndexOf;
/*      */     }
/* 2452 */     if (this.lastIndexOf < this.itemCount / 2) {
/* 2453 */       for (int i = 0; i < this.itemCount; i++) {
/* 2454 */         if (this.items[i] == item) return this.lastIndexOf = i;
/*      */       }
/*      */     } else {
/* 2457 */       for (int i = this.itemCount - 1; i >= 0; i--) {
/* 2458 */         if (this.items[i] == item) return this.lastIndexOf = i;
/*      */       }
/*      */     }
/* 2461 */     return -1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isSelected(int index)
/*      */   {
/* 2478 */     checkWidget();
/* 2479 */     long selection = GTK.gtk_tree_view_get_selection(this.handle);
/* 2480 */     byte[] buffer = Converter.wcsToMbcs(Integer.toString(index), true);
/* 2481 */     long path = GTK.gtk_tree_path_new_from_string(buffer);
/* 2482 */     boolean answer = GTK.gtk_tree_selection_path_is_selected(selection, path);
/* 2483 */     GTK.gtk_tree_path_free(path);
/* 2484 */     return answer;
/*      */   }
/*      */   
/*      */   boolean mnemonicHit(char key)
/*      */   {
/* 2489 */     for (int i = 0; i < this.columnCount; i++) {
/* 2490 */       long labelHandle = this.columns[i].labelHandle;
/* 2491 */       if ((labelHandle != 0L) && (mnemonicHit(labelHandle, key))) return true;
/*      */     }
/* 2493 */     return false;
/*      */   }
/*      */   
/*      */   boolean mnemonicMatch(char key)
/*      */   {
/* 2498 */     for (int i = 0; i < this.columnCount; i++) {
/* 2499 */       long labelHandle = this.columns[i].labelHandle;
/* 2500 */       if ((labelHandle != 0L) && (mnemonicMatch(labelHandle, key))) return true;
/*      */     }
/* 2502 */     return false;
/*      */   }
/*      */   
/*      */   long paintWindow()
/*      */   {
/* 2507 */     GTK.gtk_widget_realize(this.handle);
/* 2508 */     return GTK.gtk_tree_view_get_bin_window(this.handle);
/*      */   }
/*      */   
/*      */   void recreateRenderers() {
/* 2512 */     if (this.checkRenderer != 0L) {
/* 2513 */       this.display.removeWidget(this.checkRenderer);
/* 2514 */       OS.g_object_unref(this.checkRenderer);
/* 2515 */       this.checkRenderer = (this.ownerDraw ? OS.g_object_new(this.display.gtk_cell_renderer_toggle_get_type(), 0L) : GTK.gtk_cell_renderer_toggle_new());
/* 2516 */       if (this.checkRenderer == 0L) error(2);
/* 2517 */       OS.g_object_ref(this.checkRenderer);
/* 2518 */       this.display.addWidget(this.checkRenderer, this);
/* 2519 */       OS.g_signal_connect_closure(this.checkRenderer, OS.toggled, this.display.getClosure(53), false);
/*      */     }
/* 2521 */     if (this.columnCount == 0) {
/* 2522 */       createRenderers(GTK.gtk_tree_view_get_column(this.handle, 0), 5, true, 0);
/*      */     } else {
/* 2524 */       for (int i = 0; i < this.columnCount; i++) {
/* 2525 */         TableColumn column = this.columns[i];
/* 2526 */         createRenderers(column.handle, column.modelIndex, i == 0, column.style);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   void redrawBackgroundImage()
/*      */   {
/* 2533 */     Control control = findBackgroundControl();
/* 2534 */     if ((control != null) && (control.backgroundImage != null)) {
/* 2535 */       redrawWidget(0, 0, 0, 0, true, false, false);
/*      */     }
/*      */   }
/*      */   
/*      */   void register()
/*      */   {
/* 2541 */     super.register();
/* 2542 */     this.display.addWidget(GTK.gtk_tree_view_get_selection(this.handle), this);
/* 2543 */     if (this.checkRenderer != 0L) this.display.addWidget(this.checkRenderer, this);
/* 2544 */     this.display.addWidget(this.modelHandle, this);
/*      */   }
/*      */   
/*      */   void releaseChildren(boolean destroy)
/*      */   {
/* 2549 */     if (this.items != null) {
/* 2550 */       for (int i = 0; i < this.itemCount; i++) {
/* 2551 */         TableItem item = this.items[i];
/* 2552 */         if ((item != null) && (!item.isDisposed())) {
/* 2553 */           item.release(false);
/*      */         }
/*      */       }
/* 2556 */       this.items = null;
/*      */     }
/* 2558 */     if (this.columns != null) {
/* 2559 */       for (int i = 0; i < this.columnCount; i++) {
/* 2560 */         TableColumn column = this.columns[i];
/* 2561 */         if ((column != null) && (!column.isDisposed())) {
/* 2562 */           column.release(false);
/*      */         }
/*      */       }
/* 2565 */       this.columns = null;
/*      */     }
/* 2567 */     super.releaseChildren(destroy);
/*      */   }
/*      */   
/*      */   void releaseWidget()
/*      */   {
/* 2572 */     super.releaseWidget();
/* 2573 */     if (this.modelHandle != 0L) OS.g_object_unref(this.modelHandle);
/* 2574 */     this.modelHandle = 0L;
/* 2575 */     if (this.checkRenderer != 0L) OS.g_object_unref(this.checkRenderer);
/* 2576 */     this.checkRenderer = 0L;
/* 2577 */     if (this.imageList != null) this.imageList.dispose();
/* 2578 */     if (this.headerImageList != null) this.headerImageList.dispose();
/* 2579 */     this.imageList = (this.headerImageList = null);
/* 2580 */     this.currentItem = null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void remove(int index)
/*      */   {
/* 2598 */     checkWidget();
/* 2599 */     if ((0 > index) || (index >= this.itemCount)) error(15);
/* 2600 */     long iter = OS.g_malloc(GTK.GtkTreeIter_sizeof());
/* 2601 */     TableItem item = this.items[index];
/* 2602 */     boolean disposed = false;
/* 2603 */     if (item != null) {
/* 2604 */       disposed = item.isDisposed();
/* 2605 */       if (!disposed) {
/* 2606 */         C.memmove(iter, item.handle, GTK.GtkTreeIter_sizeof());
/* 2607 */         item.release(false);
/*      */       }
/*      */     } else {
/* 2610 */       GTK.gtk_tree_model_iter_nth_child(this.modelHandle, iter, 0L, index);
/*      */     }
/* 2612 */     if (!disposed) {
/* 2613 */       long selection = GTK.gtk_tree_view_get_selection(this.handle);
/* 2614 */       OS.g_signal_handlers_block_matched(selection, 16, 0, 0, 0L, 0L, 6L);
/* 2615 */       GTK.gtk_list_store_remove(this.modelHandle, iter);
/* 2616 */       OS.g_signal_handlers_unblock_matched(selection, 16, 0, 0, 0L, 0L, 6L);
/* 2617 */       System.arraycopy(this.items, index + 1, this.items, index, --this.itemCount - index);
/* 2618 */       this.items[this.itemCount] = null;
/*      */     }
/* 2620 */     OS.g_free(iter);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void remove(int start, int end)
/*      */   {
/* 2640 */     checkWidget();
/* 2641 */     if (start > end) return;
/* 2642 */     if ((0 > start) || (start > end) || (end >= this.itemCount)) {
/* 2643 */       error(6);
/*      */     }
/* 2645 */     long selection = GTK.gtk_tree_view_get_selection(this.handle);
/* 2646 */     long iter = OS.g_malloc(GTK.GtkTreeIter_sizeof());
/* 2647 */     if (iter == 0L) error(2);
/* 2648 */     if (fixAccessibility()) {
/* 2649 */       this.ignoreAccessibility = true;
/*      */     }
/* 2651 */     int index = end;
/* 2652 */     while (index >= start) {
/* 2653 */       GTK.gtk_tree_model_iter_nth_child(this.modelHandle, iter, 0L, index);
/* 2654 */       TableItem item = this.items[index];
/* 2655 */       if ((item != null) && (!item.isDisposed())) item.release(false);
/* 2656 */       OS.g_signal_handlers_block_matched(selection, 16, 0, 0, 0L, 0L, 6L);
/* 2657 */       GTK.gtk_list_store_remove(this.modelHandle, iter);
/* 2658 */       OS.g_signal_handlers_unblock_matched(selection, 16, 0, 0, 0L, 0L, 6L);
/* 2659 */       index--;
/*      */     }
/* 2661 */     if (fixAccessibility()) {
/* 2662 */       this.ignoreAccessibility = false;
/* 2663 */       OS.g_object_notify(this.handle, OS.model);
/*      */     }
/* 2665 */     OS.g_free(iter);
/* 2666 */     index = end + 1;
/* 2667 */     System.arraycopy(this.items, index, this.items, start, this.itemCount - index);
/* 2668 */     for (int i = this.itemCount - (index - start); i < this.itemCount; i++) this.items[i] = null;
/* 2669 */     this.itemCount -= index - start;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void remove(int[] indices)
/*      */   {
/* 2688 */     checkWidget();
/* 2689 */     if (indices == null) error(4);
/* 2690 */     if (indices.length == 0) return;
/* 2691 */     int[] newIndices = new int[indices.length];
/* 2692 */     System.arraycopy(indices, 0, newIndices, 0, indices.length);
/* 2693 */     sort(newIndices);
/* 2694 */     int start = newIndices[(newIndices.length - 1)];int end = newIndices[0];
/* 2695 */     if ((0 > start) || (start > end) || (end >= this.itemCount)) {
/* 2696 */       error(6);
/*      */     }
/* 2698 */     long selection = GTK.gtk_tree_view_get_selection(this.handle);
/* 2699 */     int last = -1;
/* 2700 */     long iter = OS.g_malloc(GTK.GtkTreeIter_sizeof());
/* 2701 */     if (iter == 0L) error(2);
/* 2702 */     if (fixAccessibility()) {
/* 2703 */       this.ignoreAccessibility = true;
/*      */     }
/* 2705 */     for (int i = 0; i < newIndices.length; i++) {
/* 2706 */       int index = newIndices[i];
/* 2707 */       if (index != last) {
/* 2708 */         TableItem item = this.items[index];
/* 2709 */         boolean disposed = false;
/* 2710 */         if (item != null) {
/* 2711 */           disposed = item.isDisposed();
/* 2712 */           if (!disposed) {
/* 2713 */             C.memmove(iter, item.handle, GTK.GtkTreeIter_sizeof());
/* 2714 */             item.release(false);
/*      */           }
/*      */         } else {
/* 2717 */           GTK.gtk_tree_model_iter_nth_child(this.modelHandle, iter, 0L, index);
/*      */         }
/* 2719 */         if (!disposed) {
/* 2720 */           OS.g_signal_handlers_block_matched(selection, 16, 0, 0, 0L, 0L, 6L);
/* 2721 */           GTK.gtk_list_store_remove(this.modelHandle, iter);
/* 2722 */           OS.g_signal_handlers_unblock_matched(selection, 16, 0, 0, 0L, 0L, 6L);
/* 2723 */           System.arraycopy(this.items, index + 1, this.items, index, --this.itemCount - index);
/* 2724 */           this.items[this.itemCount] = null;
/*      */         }
/* 2726 */         last = index;
/*      */       }
/*      */     }
/* 2729 */     if (fixAccessibility()) {
/* 2730 */       this.ignoreAccessibility = false;
/* 2731 */       OS.g_object_notify(this.handle, OS.model);
/*      */     }
/* 2733 */     OS.g_free(iter);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeAll()
/*      */   {
/* 2745 */     checkWidget();
/* 2746 */     int index = this.itemCount - 1;
/* 2747 */     while (index >= 0) {
/* 2748 */       TableItem item = this.items[index];
/* 2749 */       if ((item != null) && (!item.isDisposed())) item.release(false);
/* 2750 */       index--;
/*      */     }
/* 2752 */     this.items = new TableItem[4];
/* 2753 */     this.itemCount = 0;
/* 2754 */     long selection = GTK.gtk_tree_view_get_selection(this.handle);
/* 2755 */     OS.g_signal_handlers_block_matched(selection, 16, 0, 0, 0L, 0L, 6L);
/* 2756 */     if (fixAccessibility()) {
/* 2757 */       this.ignoreAccessibility = true;
/*      */     }
/* 2759 */     GTK.gtk_list_store_clear(this.modelHandle);
/* 2760 */     if (fixAccessibility()) {
/* 2761 */       this.ignoreAccessibility = false;
/* 2762 */       OS.g_object_notify(this.handle, OS.model);
/*      */     }
/* 2764 */     OS.g_signal_handlers_unblock_matched(selection, 16, 0, 0, 0L, 0L, 6L);
/*      */     
/* 2766 */     resetCustomDraw();
/* 2767 */     if (!searchEnabled()) {
/* 2768 */       GTK.gtk_tree_view_set_search_column(this.handle, -1);
/*      */     }
/*      */     else {
/* 2771 */       int firstColumn = this.columnCount == 0 ? 5 : this.columns[0].modelIndex;
/* 2772 */       GTK.gtk_tree_view_set_search_column(this.handle, firstColumn + 1);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeSelectionListener(SelectionListener listener)
/*      */   {
/* 2794 */     checkWidget();
/* 2795 */     if (listener == null) error(4);
/* 2796 */     if (this.eventTable == null) return;
/* 2797 */     this.eventTable.unhook(13, listener);
/* 2798 */     this.eventTable.unhook(14, listener);
/*      */   }
/*      */   
/*      */   void sendMeasureEvent(long cell, long width, long height) {
/* 2802 */     if ((!this.ignoreSize) && (GTK.GTK_IS_CELL_RENDERER_TEXT(cell)) && (hooks(41))) {
/* 2803 */       long iter = OS.g_object_get_qdata(cell, Display.SWT_OBJECT_INDEX2);
/* 2804 */       TableItem item = null;
/* 2805 */       boolean isSelected = false;
/* 2806 */       if (iter != 0L) {
/* 2807 */         long path = GTK.gtk_tree_model_get_path(this.modelHandle, iter);
/* 2808 */         int[] buffer = new int[1];
/* 2809 */         C.memmove(buffer, GTK.gtk_tree_path_get_indices(path), 4L);
/* 2810 */         int index = buffer[0];
/* 2811 */         item = _getItem(index);
/* 2812 */         long selection = GTK.gtk_tree_view_get_selection(this.handle);
/* 2813 */         isSelected = GTK.gtk_tree_selection_path_is_selected(selection, path);
/* 2814 */         GTK.gtk_tree_path_free(path);
/*      */       }
/* 2816 */       if (item != null) {
/* 2817 */         int columnIndex = 0;
/* 2818 */         if (this.columnCount > 0) {
/* 2819 */           long columnHandle = OS.g_object_get_qdata(cell, Display.SWT_OBJECT_INDEX1);
/* 2820 */           for (int i = 0; i < this.columnCount; i++) {
/* 2821 */             if (this.columns[i].handle == columnHandle) {
/* 2822 */               columnIndex = i;
/* 2823 */               break;
/*      */             }
/*      */           }
/*      */         }
/* 2827 */         int[] contentWidth = new int[1];int[] contentHeight = new int[1];
/* 2828 */         if (width != 0L) C.memmove(contentWidth, width, 4L);
/* 2829 */         if (height != 0L) C.memmove(contentHeight, height, 4L);
/* 2830 */         if (GTK.GTK3) {
/* 2831 */           GTK.gtk_cell_renderer_get_preferred_height_for_width(cell, this.handle, contentWidth[0], contentHeight, null);
/*      */         }
/* 2833 */         Image image = item.getImage(columnIndex);
/* 2834 */         int imageWidth = 0;
/* 2835 */         if (image != null) {
/* 2836 */           Rectangle bounds = image.getBounds();
/* 2837 */           imageWidth = bounds.width;
/*      */         }
/* 2839 */         contentWidth[0] += imageWidth;
/* 2840 */         GC gc = new GC(this);
/* 2841 */         gc.setFont(item.getFont(columnIndex));
/* 2842 */         Event event = new Event();
/* 2843 */         event.item = item;
/* 2844 */         event.index = columnIndex;
/* 2845 */         event.gc = gc;
/* 2846 */         Rectangle eventRect = new Rectangle(0, 0, contentWidth[0], contentHeight[0]);
/* 2847 */         event.setBounds(DPIUtil.autoScaleDown(eventRect));
/* 2848 */         if (isSelected) event.detail = 2;
/* 2849 */         sendEvent(41, event);
/* 2850 */         gc.dispose();
/* 2851 */         Rectangle rect = DPIUtil.autoScaleUp(event.getBounds());
/* 2852 */         contentWidth[0] = (rect.width - imageWidth);
/* 2853 */         if (contentHeight[0] < rect.height) contentHeight[0] = rect.height;
/* 2854 */         if (width != 0L) C.memmove(width, contentWidth, 4L);
/* 2855 */         if (height != 0L) C.memmove(height, contentHeight, 4L);
/* 2856 */         if (GTK.GTK3) {
/* 2857 */           GTK.gtk_cell_renderer_set_fixed_size(cell, contentWidth[0], contentHeight[0]);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   long rendererGetPreferredWidthProc(long cell, long handle, long minimun_size, long natural_size)
/*      */   {
/* 2865 */     long g_class = OS.g_type_class_peek_parent(OS.G_OBJECT_GET_CLASS(cell));
/* 2866 */     GtkCellRendererClass klass = new GtkCellRendererClass();
/* 2867 */     OS.memmove(klass, g_class);
/* 2868 */     OS.call(klass.get_preferred_width, cell, handle, minimun_size, natural_size);
/* 2869 */     sendMeasureEvent(cell, minimun_size, 0L);
/* 2870 */     return 0L;
/*      */   }
/*      */   
/*      */   long rendererGetSizeProc(long cell, long widget, long cell_area, long x_offset, long y_offset, long width, long height)
/*      */   {
/* 2875 */     long g_class = OS.g_type_class_peek_parent(OS.G_OBJECT_GET_CLASS(cell));
/* 2876 */     GtkCellRendererClass klass = new GtkCellRendererClass();
/* 2877 */     OS.memmove(klass, g_class);
/* 2878 */     OS.call_get_size(klass.get_size, cell, this.handle, cell_area, x_offset, y_offset, width, height);
/* 2879 */     sendMeasureEvent(cell, width, height);
/* 2880 */     return 0L;
/*      */   }
/*      */   
/*      */ 
/*      */   long rendererRenderProc(long cell, long cr, long widget, long background_area, long cell_area, long flags)
/*      */   {
/* 2886 */     rendererRender(cell, cr, 0L, widget, background_area, cell_area, 0L, flags);
/* 2887 */     return 0L;
/*      */   }
/*      */   
/*      */   long rendererRenderProc(long cell, long window, long widget, long background_area, long cell_area, long expose_area, long flags)
/*      */   {
/* 2892 */     rendererRender(cell, 0L, window, widget, background_area, cell_area, expose_area, flags);
/* 2893 */     return 0L;
/*      */   }
/*      */   
/*      */   void rendererRender(long cell, long cr, long window, long widget, long background_area, long cell_area, long expose_area, long flags) {
/* 2897 */     TableItem item = null;
/* 2898 */     boolean wasSelected = false;
/* 2899 */     long iter = OS.g_object_get_qdata(cell, Display.SWT_OBJECT_INDEX2);
/* 2900 */     if (iter != 0L) {
/* 2901 */       long path = GTK.gtk_tree_model_get_path(this.modelHandle, iter);
/* 2902 */       int[] buffer = new int[1];
/* 2903 */       C.memmove(buffer, GTK.gtk_tree_path_get_indices(path), 4L);
/* 2904 */       int index = buffer[0];
/* 2905 */       item = _getItem(index);
/* 2906 */       GTK.gtk_tree_path_free(path);
/*      */     }
/* 2908 */     long columnHandle = OS.g_object_get_qdata(cell, Display.SWT_OBJECT_INDEX1);
/* 2909 */     int columnIndex = 0;
/* 2910 */     if (this.columnCount > 0) {
/* 2911 */       for (int i = 0; i < this.columnCount; i++) {
/* 2912 */         if (this.columns[i].handle == columnHandle) {
/* 2913 */           columnIndex = i;
/* 2914 */           break;
/*      */         }
/*      */       }
/*      */     }
/* 2918 */     if ((item != null) && (
/* 2919 */       (GTK.GTK_IS_CELL_RENDERER_TOGGLE(cell)) || (
/* 2920 */       ((GTK.GTK_IS_CELL_RENDERER_PIXBUF(cell)) || (GTK.GTK_VERSION > OS.VERSION(3, 13, 0))) && ((columnIndex != 0) || ((this.style & 0x20) == 0))))) {
/* 2921 */       this.drawFlags = ((int)flags);
/* 2922 */       this.drawState = 16;
/* 2923 */       long[] ptr = new long[1];
/* 2924 */       GTK.gtk_tree_model_get(this.modelHandle, item.handle, 3, ptr, -1);
/* 2925 */       if (ptr[0] == 0L) {
/* 2926 */         int modelIndex = this.columnCount == 0 ? 5 : this.columns[columnIndex].modelIndex;
/* 2927 */         GTK.gtk_tree_model_get(this.modelHandle, item.handle, modelIndex + 3, ptr, -1);
/*      */       }
/* 2929 */       if (ptr[0] != 0L) {
/* 2930 */         this.drawState |= 0x8;
/* 2931 */         if (GTK.GTK3) {
/* 2932 */           GDK.gdk_rgba_free(ptr[0]);
/*      */         } else {
/* 2934 */           GDK.gdk_color_free(ptr[0]);
/*      */         }
/*      */       }
/* 2937 */       if ((flags & 1L) != 0L) this.drawState |= 0x2;
/* 2938 */       if (((!GTK.GTK3) || ((flags & 1L) == 0L)) && 
/* 2939 */         ((flags & 0x10) != 0L)) { this.drawState |= 0x4;
/*      */       }
/*      */       
/* 2942 */       GdkRectangle rect = new GdkRectangle();
/* 2943 */       long path = GTK.gtk_tree_model_get_path(this.modelHandle, iter);
/* 2944 */       GTK.gtk_tree_view_get_background_area(this.handle, path, columnHandle, rect);
/* 2945 */       GTK.gtk_tree_path_free(path);
/*      */       
/* 2947 */       if ((cr != 0L) && (GTK.GTK_VERSION > OS.VERSION(3, 9, 0)) && (GTK.GTK_VERSION <= OS.VERSION(3, 14, 8))) {
/* 2948 */         GdkRectangle r2 = new GdkRectangle();
/* 2949 */         GDK.gdk_cairo_get_clip_rectangle(cr, r2);
/* 2950 */         rect.x = r2.x;
/* 2951 */         rect.width = r2.width;
/*      */       }
/* 2953 */       if (((this.drawState & 0x2) == 0) && (
/* 2954 */         ((this.state & 0x8000) != 0) || (this.backgroundImage != null))) {
/* 2955 */         Control control = findBackgroundControl();
/* 2956 */         if (control != null) {
/* 2957 */           if (cr != 0L) {
/* 2958 */             Cairo.cairo_save(cr);
/* 2959 */             if (!GTK.GTK3) {
/* 2960 */               Cairo.cairo_reset_clip(cr);
/*      */             }
/*      */           }
/* 2963 */           drawBackground(control, window, cr, 0L, rect.x, rect.y, rect.width, rect.height);
/* 2964 */           if (cr != 0L) {
/* 2965 */             Cairo.cairo_restore(cr);
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 2972 */       long textRenderer = getTextRenderer(columnHandle);
/* 2973 */       if (textRenderer != 0L) { gtk_cell_renderer_get_preferred_size(textRenderer, this.handle, null, null);
/*      */       }
/*      */       
/* 2976 */       if (hooks(40))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2982 */         wasSelected = (this.drawState & 0x2) != 0;
/* 2983 */         if (wasSelected) {
/* 2984 */           Control control = findBackgroundControl();
/* 2985 */           if (control == null) control = this;
/* 2986 */           if (!GTK.GTK3) {
/* 2987 */             if (cr != 0L) {
/* 2988 */               Cairo.cairo_save(cr);
/* 2989 */               Cairo.cairo_reset_clip(cr);
/*      */             }
/* 2991 */             drawBackground(control, window, cr, 0L, rect.x, rect.y, rect.width, rect.height);
/* 2992 */             if (cr != 0L) {
/* 2993 */               Cairo.cairo_restore(cr);
/*      */             }
/*      */           }
/*      */         }
/* 2997 */         GC gc = getGC(cr);
/* 2998 */         if ((this.drawState & 0x2) != 0) {
/* 2999 */           gc.setBackground(this.display.getSystemColor(26));
/* 3000 */           gc.setForeground(this.display.getSystemColor(27));
/*      */         } else {
/* 3002 */           gc.setBackground(item.getBackground(columnIndex));
/* 3003 */           gc.setForeground(item.getForeground(columnIndex));
/*      */         }
/* 3005 */         gc.setFont(item.getFont(columnIndex));
/* 3006 */         if ((this.style & 0x8000000) != 0) rect.x = (getClientWidth() - rect.width - rect.x);
/* 3007 */         if ((GTK.GTK_VERSION >= OS.VERSION(3, 9, 0)) && (cr != 0L)) {
/* 3008 */           GdkRectangle r = new GdkRectangle();
/* 3009 */           GDK.gdk_cairo_get_clip_rectangle(cr, r);
/* 3010 */           Rectangle rect2 = DPIUtil.autoScaleDown(new Rectangle(rect.x, r.y, r.width, r.height));
/*      */           
/* 3012 */           gc.setClipping(rect2.x, rect2.y, rect2.width, rect2.height);
/*      */           
/* 3014 */           if (GTK.GTK_VERSION <= OS.VERSION(3, 14, 8)) {
/* 3015 */             rect.width = r.width;
/*      */           }
/*      */         } else {
/* 3018 */           Rectangle rect2 = DPIUtil.autoScaleDown(new Rectangle(rect.x, rect.y, rect.width, rect.height));
/*      */           
/* 3020 */           gc.setClipping(rect2.x, rect2.y, rect2.width, rect2.height);
/*      */         }
/*      */         
/* 3023 */         Event event = new Event();
/* 3024 */         event.item = item;
/* 3025 */         event.index = columnIndex;
/* 3026 */         event.gc = gc;
/* 3027 */         event.detail = this.drawState;
/* 3028 */         Rectangle eventRect = new Rectangle(rect.x, rect.y, rect.width, rect.height);
/* 3029 */         event.setBounds(DPIUtil.autoScaleDown(eventRect));
/* 3030 */         sendEvent(40, event);
/* 3031 */         if (GTK.GTK3) {
/* 3032 */           this.drawForegroundRGBA = null;
/*      */         } else {
/* 3034 */           this.drawForeground = null;
/*      */         }
/* 3036 */         this.drawState = (event.doit ? event.detail : 0);
/* 3037 */         this.drawFlags &= 0xFFFFFFEE;
/* 3038 */         if ((this.drawState & 0x2) != 0) this.drawFlags |= 0x1;
/* 3039 */         if ((this.drawState & 0x4) != 0) this.drawFlags |= 0x10;
/* 3040 */         if ((this.drawState & 0x2) != 0) {
/* 3041 */           if (GTK.GTK3) {
/* 3042 */             Cairo.cairo_save(cr);
/* 3043 */             Cairo.cairo_reset_clip(cr);
/* 3044 */             long context = GTK.gtk_widget_get_style_context(widget);
/* 3045 */             GTK.gtk_style_context_save(context);
/* 3046 */             GTK.gtk_style_context_add_class(context, GTK.GTK_STYLE_CLASS_CELL);
/* 3047 */             GTK.gtk_style_context_set_state(context, 4L);
/* 3048 */             GTK.gtk_render_background(context, cr, rect.x, rect.y, rect.width, rect.height);
/* 3049 */             GTK.gtk_style_context_restore(context);
/* 3050 */             Cairo.cairo_restore(cr);
/*      */           } else {
/* 3052 */             long style = GTK.gtk_widget_get_style(widget);
/*      */             
/* 3054 */             byte[] detail = Converter.wcsToMbcs("cell_odd", true);
/* 3055 */             GTK.gtk_paint_flat_box(style, window, 3, 0, rect, widget, detail, rect.x, rect.y, rect.width, rect.height);
/*      */           }
/*      */         }
/* 3058 */         else if (wasSelected) {
/* 3059 */           if (GTK.GTK3) {
/* 3060 */             this.drawForegroundRGBA = gc.getForeground().handleRGBA;
/*      */           } else {
/* 3062 */             this.drawForeground = gc.getForeground().handle;
/*      */           }
/*      */         }
/*      */         
/* 3066 */         gc.dispose();
/*      */       }
/*      */     }
/*      */     
/* 3070 */     if (((this.drawState & 0x8) != 0) && ((this.drawState & 0x2) == 0)) {
/* 3071 */       GC gc = getGC(cr);
/* 3072 */       gc.setBackground(item.getBackground(columnIndex));
/* 3073 */       GdkRectangle rect = new GdkRectangle();
/* 3074 */       OS.memmove(rect, background_area, GdkRectangle.sizeof);
/* 3075 */       gc.fillRectangle(DPIUtil.autoScaleDown(new Rectangle(rect.x, rect.y, rect.width, rect.height)));
/* 3076 */       gc.dispose();
/*      */     }
/* 3078 */     if (((this.drawState & 0x10) != 0) || (GTK.GTK_IS_CELL_RENDERER_TOGGLE(cell))) {
/* 3079 */       long g_class = OS.g_type_class_peek_parent(OS.G_OBJECT_GET_CLASS(cell));
/* 3080 */       GtkCellRendererClass klass = new GtkCellRendererClass();
/* 3081 */       OS.memmove(klass, g_class);
/* 3082 */       if ((this.drawForeground != null) && (GTK.GTK_IS_CELL_RENDERER_TEXT(cell)) && (!GTK.GTK3)) {
/* 3083 */         OS.g_object_set(cell, OS.foreground_gdk, this.drawForeground, 0L);
/* 3084 */       } else if ((this.drawForegroundRGBA != null) && (GTK.GTK_IS_CELL_RENDERER_TEXT(cell)) && (GTK.GTK3)) {
/* 3085 */         OS.g_object_set(cell, OS.foreground_rgba, this.drawForegroundRGBA, 0L);
/*      */       }
/* 3087 */       if (GTK.GTK3) {
/* 3088 */         OS.call(klass.render, cell, cr, widget, background_area, cell_area, this.drawFlags);
/*      */       } else {
/* 3090 */         OS.call(klass.render, cell, window, widget, background_area, cell_area, expose_area, this.drawFlags);
/*      */       }
/*      */     }
/* 3093 */     if ((item != null) && 
/* 3094 */       (GTK.GTK_IS_CELL_RENDERER_TEXT(cell)) && 
/* 3095 */       (hooks(42))) {
/* 3096 */       if (wasSelected) this.drawState |= 0x2;
/* 3097 */       GdkRectangle rect = new GdkRectangle();
/* 3098 */       long path = GTK.gtk_tree_model_get_path(this.modelHandle, iter);
/* 3099 */       GTK.gtk_tree_view_get_background_area(this.handle, path, columnHandle, rect);
/* 3100 */       GTK.gtk_tree_path_free(path);
/*      */       
/* 3102 */       if ((cr != 0L) && (GTK.GTK_VERSION > OS.VERSION(3, 9, 0)) && (GTK.GTK_VERSION <= OS.VERSION(3, 14, 8))) {
/* 3103 */         GdkRectangle r2 = new GdkRectangle();
/* 3104 */         GDK.gdk_cairo_get_clip_rectangle(cr, r2);
/* 3105 */         rect.x = r2.x;
/* 3106 */         rect.width = r2.width;
/*      */       }
/* 3108 */       this.ignoreSize = true;
/* 3109 */       int[] contentX = new int[1];int[] contentWidth = new int[1];
/* 3110 */       gtk_cell_renderer_get_preferred_size(cell, this.handle, contentWidth, null);
/* 3111 */       gtk_tree_view_column_cell_get_position(columnHandle, cell, contentX, null);
/* 3112 */       this.ignoreSize = false;
/* 3113 */       Image image = item.getImage(columnIndex);
/* 3114 */       int imageWidth = 0;
/* 3115 */       if (image != null) {
/* 3116 */         Rectangle bounds = image.getBounds();
/* 3117 */         imageWidth = bounds.width;
/*      */       }
/*      */       
/*      */ 
/* 3121 */       if ((cr != 0L) && (GTK.GTK_VERSION > OS.VERSION(3, 9, 0)) && (GTK.GTK_VERSION <= OS.VERSION(3, 14, 8))) {
/* 3122 */         rect.x -= imageWidth;
/* 3123 */         rect.width += imageWidth;
/*      */       }
/* 3125 */       contentX[0] -= imageWidth;
/* 3126 */       contentWidth[0] += imageWidth;
/* 3127 */       GC gc = getGC(cr);
/* 3128 */       if ((this.drawState & 0x2) != 0) { Color foreground;
/*      */         Color background;
/* 3130 */         Color foreground; if ((GTK.gtk_widget_has_focus(this.handle)) || (GTK.GTK3)) {
/* 3131 */           Color background = this.display.getSystemColor(26);
/* 3132 */           foreground = this.display.getSystemColor(27);
/*      */ 
/*      */ 
/*      */         }
/*      */         else
/*      */         {
/*      */ 
/* 3139 */           background = GTK.GTK3 ? Color.gtk_new(this.display, this.display.COLOR_LIST_SELECTION_INACTIVE_RGBA) : Color.gtk_new(this.display, this.display.COLOR_LIST_SELECTION_INACTIVE);
/* 3140 */           foreground = GTK.GTK3 ? Color.gtk_new(this.display, this.display.COLOR_LIST_SELECTION_TEXT_INACTIVE_RGBA) : Color.gtk_new(this.display, this.display.COLOR_LIST_SELECTION_TEXT_INACTIVE);
/*      */         }
/* 3142 */         gc.setBackground(background);
/* 3143 */         gc.setForeground(foreground);
/*      */       } else {
/* 3145 */         gc.setBackground(item.getBackground(columnIndex));
/*      */         Color foreground;
/* 3147 */         Color foreground; if (GTK.GTK3) {
/* 3148 */           foreground = this.drawForegroundRGBA != null ? Color.gtk_new(this.display, this.drawForegroundRGBA) : item.getForeground(columnIndex);
/*      */         } else {
/* 3150 */           foreground = this.drawForeground != null ? Color.gtk_new(this.display, this.drawForeground) : item.getForeground(columnIndex);
/*      */         }
/* 3152 */         gc.setForeground(foreground);
/*      */       }
/* 3154 */       gc.setFont(item.getFont(columnIndex));
/* 3155 */       if ((this.style & 0x8000000) != 0) { rect.x = (getClientWidth() - rect.width - rect.x);
/*      */       }
/* 3157 */       Rectangle rect2 = DPIUtil.autoScaleDown(new Rectangle(rect.x, rect.y, rect.width, rect.height));
/*      */       
/* 3159 */       gc.setClipping(rect2.x, rect2.y, rect2.width, rect2.height);
/*      */       
/* 3161 */       Event event = new Event();
/* 3162 */       event.item = item;
/* 3163 */       event.index = columnIndex;
/* 3164 */       event.gc = gc;
/* 3165 */       Rectangle eventRect = new Rectangle(rect.x + contentX[0], rect.y, contentWidth[0], rect.height);
/* 3166 */       event.setBounds(DPIUtil.autoScaleDown(eventRect));
/* 3167 */       event.detail = this.drawState;
/* 3168 */       sendEvent(42, event);
/* 3169 */       gc.dispose();
/*      */     }
/*      */   }
/*      */   
/*      */   private GC getGC(long cr)
/*      */   {
/*      */     GC gc;
/*      */     GC gc;
/* 3177 */     if (GTK.GTK3) {
/* 3178 */       GCData gcData = new GCData();
/* 3179 */       gcData.cairo = cr;
/* 3180 */       gc = GC.gtk_new(this, gcData);
/*      */     } else {
/* 3182 */       gc = new GC(this);
/*      */     }
/* 3184 */     return gc;
/*      */   }
/*      */   
/*      */   void resetCustomDraw() {
/* 3188 */     if (((this.style & 0x10000000) != 0) || (this.ownerDraw)) return;
/* 3189 */     int end = Math.max(1, this.columnCount);
/* 3190 */     for (int i = 0; i < end; i++) {
/* 3191 */       boolean customDraw = this.columnCount != 0 ? this.columns[i].customDraw : this.firstCustomDraw;
/* 3192 */       if (customDraw) {
/* 3193 */         long column = GTK.gtk_tree_view_get_column(this.handle, i);
/* 3194 */         long textRenderer = getTextRenderer(column);
/* 3195 */         GTK.gtk_tree_view_column_set_cell_data_func(column, textRenderer, 0L, 0L, 0L);
/* 3196 */         if (this.columnCount != 0) this.columns[i].customDraw = false;
/*      */       }
/*      */     }
/* 3199 */     this.firstCustomDraw = false;
/*      */   }
/*      */   
/*      */   void reskinChildren(int flags)
/*      */   {
/* 3204 */     if (this.items != null) {
/* 3205 */       for (int i = 0; i < this.itemCount; i++) {
/* 3206 */         TableItem item = this.items[i];
/* 3207 */         if (item != null) item.reskin(flags);
/*      */       }
/*      */     }
/* 3210 */     if (this.columns != null) {
/* 3211 */       for (int i = 0; i < this.columnCount; i++) {
/* 3212 */         TableColumn column = this.columns[i];
/* 3213 */         if (!column.isDisposed()) column.reskin(flags);
/*      */       }
/*      */     }
/* 3216 */     super.reskinChildren(flags);
/*      */   }
/*      */   
/*      */   boolean searchEnabled()
/*      */   {
/* 3221 */     if ((this.style & 0x10000000) != 0) return false;
/* 3222 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void select(int index)
/*      */   {
/* 3238 */     checkWidget();
/* 3239 */     if ((0 > index) || (index >= this.itemCount)) return;
/* 3240 */     boolean fixColumn = showFirstColumn();
/* 3241 */     long selection = GTK.gtk_tree_view_get_selection(this.handle);
/* 3242 */     OS.g_signal_handlers_block_matched(selection, 16, 0, 0, 0L, 0L, 6L);
/* 3243 */     TableItem item = _getItem(index);
/* 3244 */     GTK.gtk_tree_selection_select_iter(selection, item.handle);
/* 3245 */     OS.g_signal_handlers_unblock_matched(selection, 16, 0, 0, 0L, 0L, 6L);
/* 3246 */     if (fixColumn) { hideFirstColumn();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void select(int start, int end)
/*      */   {
/* 3273 */     checkWidget();
/* 3274 */     if ((end < 0) || (start > end) || (((this.style & 0x4) != 0) && (start != end))) return;
/* 3275 */     if ((this.itemCount == 0) || (start >= this.itemCount)) return;
/* 3276 */     start = Math.max(0, start);
/* 3277 */     end = Math.min(end, this.itemCount - 1);
/* 3278 */     boolean fixColumn = showFirstColumn();
/* 3279 */     long selection = GTK.gtk_tree_view_get_selection(this.handle);
/* 3280 */     OS.g_signal_handlers_block_matched(selection, 16, 0, 0, 0L, 0L, 6L);
/* 3281 */     for (int index = start; index <= end; index++) {
/* 3282 */       TableItem item = _getItem(index);
/* 3283 */       GTK.gtk_tree_selection_select_iter(selection, item.handle);
/*      */     }
/* 3285 */     OS.g_signal_handlers_unblock_matched(selection, 16, 0, 0, 0L, 0L, 6L);
/* 3286 */     if (fixColumn) { hideFirstColumn();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void select(int[] indices)
/*      */   {
/* 3313 */     checkWidget();
/* 3314 */     if (indices == null) error(4);
/* 3315 */     int length = indices.length;
/* 3316 */     if ((length == 0) || (((this.style & 0x4) != 0) && (length > 1))) return;
/* 3317 */     boolean fixColumn = showFirstColumn();
/* 3318 */     long selection = GTK.gtk_tree_view_get_selection(this.handle);
/* 3319 */     OS.g_signal_handlers_block_matched(selection, 16, 0, 0, 0L, 0L, 6L);
/* 3320 */     for (int i = 0; i < length; i++) {
/* 3321 */       int index = indices[i];
/* 3322 */       if ((0 <= index) && (index < this.itemCount)) {
/* 3323 */         TableItem item = _getItem(index);
/* 3324 */         GTK.gtk_tree_selection_select_iter(selection, item.handle);
/*      */       } }
/* 3326 */     OS.g_signal_handlers_unblock_matched(selection, 16, 0, 0, 0L, 0L, 6L);
/* 3327 */     if (fixColumn) { hideFirstColumn();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void selectAll()
/*      */   {
/* 3342 */     checkWidget();
/* 3343 */     if ((this.style & 0x4) != 0) return;
/* 3344 */     boolean fixColumn = showFirstColumn();
/* 3345 */     long selection = GTK.gtk_tree_view_get_selection(this.handle);
/* 3346 */     OS.g_signal_handlers_block_matched(selection, 16, 0, 0, 0L, 0L, 6L);
/* 3347 */     GTK.gtk_tree_selection_select_all(selection);
/* 3348 */     OS.g_signal_handlers_unblock_matched(selection, 16, 0, 0, 0L, 0L, 6L);
/* 3349 */     if (fixColumn) { hideFirstColumn();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   void selectFocusIndex(int index)
/*      */   {
/* 3358 */     if ((0 > index) || (index >= this.itemCount)) return;
/* 3359 */     TableItem item = _getItem(index);
/* 3360 */     long path = GTK.gtk_tree_model_get_path(this.modelHandle, item.handle);
/* 3361 */     long selection = GTK.gtk_tree_view_get_selection(this.handle);
/* 3362 */     OS.g_signal_handlers_block_matched(selection, 16, 0, 0, 0L, 0L, 6L);
/* 3363 */     GTK.gtk_tree_view_set_cursor(this.handle, path, 0L, false);
/* 3364 */     OS.g_signal_handlers_unblock_matched(selection, 16, 0, 0, 0L, 0L, 6L);
/* 3365 */     GTK.gtk_tree_path_free(path);
/*      */   }
/*      */   
/*      */   void setBackgroundGdkColor(GdkColor color)
/*      */   {
/* 3370 */     assert (!GTK.GTK3) : "GTK2 code was run by GTK3";
/* 3371 */     super.setBackgroundGdkColor(color);
/* 3372 */     GTK.gtk_widget_modify_base(this.handle, 0, color);
/*      */   }
/*      */   
/*      */   void setBackgroundGdkRGBA(long context, long handle, GdkRGBA rgba)
/*      */   {
/* 3377 */     assert (GTK.GTK3) : "GTK3 code was run by GTK2";
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3383 */     if (rgba == null) {
/* 3384 */       this.background = defaultBackground();
/*      */     } else {
/* 3386 */       this.background = rgba;
/*      */     }
/* 3388 */     GdkRGBA selectedBackground = this.display.getSystemColor(26).handleRGBA;
/* 3389 */     if (GTK.GTK_VERSION >= OS.VERSION(3, 14, 0)) {
/* 3390 */       String name = GTK.GTK_VERSION >= OS.VERSION(3, 20, 0) ? "treeview" : "GtkTreeView";
/*      */       
/* 3392 */       String css = name + " {background-color: " + this.display.gtk_rgba_to_css_string(this.background) + ";}\n" + name + ":selected {background-color: " + this.display.gtk_rgba_to_css_string(selectedBackground) + ";}";
/*      */       
/*      */ 
/* 3395 */       this.cssBackground = css;
/*      */       
/*      */ 
/* 3398 */       String finalCss = this.display.gtk_css_create_css_color_string(this.cssBackground, this.cssForeground, 8);
/* 3399 */       gtk_css_provider_load_from_css(context, finalCss);
/*      */     } else {
/* 3401 */       super.setBackgroundGdkRGBA(context, handle, rgba);
/* 3402 */       GTK.gtk_widget_override_background_color(handle, 4, selectedBackground);
/*      */     }
/*      */   }
/*      */   
/*      */   void setBackgroundPixmap(Image image)
/*      */   {
/* 3408 */     this.ownerDraw = true;
/* 3409 */     recreateRenderers();
/*      */   }
/*      */   
/*      */   int setBounds(int x, int y, int width, int height, boolean move, boolean resize)
/*      */   {
/* 3414 */     int result = super.setBounds(x, y, width, height, move, resize);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3423 */     GTK.gtk_widget_realize(this.handle);
/* 3424 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setColumnOrder(int[] order)
/*      */   {
/* 3452 */     checkWidget();
/* 3453 */     if (order == null) error(4);
/* 3454 */     if (this.columnCount == 0) {
/* 3455 */       if (order.length > 0) error(5);
/* 3456 */       return;
/*      */     }
/* 3458 */     if (order.length != this.columnCount) error(5);
/* 3459 */     boolean[] seen = new boolean[this.columnCount];
/* 3460 */     for (int i = 0; i < order.length; i++) {
/* 3461 */       int index = order[i];
/* 3462 */       if ((index < 0) || (index >= this.columnCount)) error(6);
/* 3463 */       if (seen[index] != 0) error(5);
/* 3464 */       seen[index] = true;
/*      */     }
/* 3466 */     for (int i = 0; i < order.length; i++) {
/* 3467 */       long column = this.columns[order[i]].handle;
/* 3468 */       long baseColumn = i == 0 ? 0L : this.columns[order[(i - 1)]].handle;
/* 3469 */       GTK.gtk_tree_view_move_column_after(this.handle, column, baseColumn);
/*      */     }
/*      */   }
/*      */   
/*      */   void setFontDescription(long font)
/*      */   {
/* 3475 */     super.setFontDescription(font);
/* 3476 */     TableColumn[] columns = getColumns();
/* 3477 */     for (int i = 0; i < columns.length; i++) {
/* 3478 */       if (columns[i] != null) {
/* 3479 */         columns[i].setFontDescription(font);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   void setForegroundGdkRGBA(GdkRGBA rgba)
/*      */   {
/* 3486 */     assert (GTK.GTK3) : "GTK3 code was run by GTK2";
/* 3487 */     if (GTK.GTK_VERSION >= OS.VERSION(3, 14, 0)) {
/* 3488 */       this.foreground = rgba;
/* 3489 */       GdkRGBA toSet = rgba == null ? this.display.COLOR_LIST_FOREGROUND_RGBA : rgba;
/* 3490 */       setForegroundGdkRGBA(this.handle, toSet);
/*      */     } else {
/* 3492 */       super.setForegroundGdkRGBA(rgba);
/*      */     }
/*      */   }
/*      */   
/*      */   void setForegroundGdkColor(GdkColor color)
/*      */   {
/* 3498 */     assert (!GTK.GTK3) : "GTK2 code was run by GTK3";
/* 3499 */     setForegroundColor(this.handle, color, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setHeaderBackground(Color color)
/*      */   {
/* 3522 */     checkWidget();
/* 3523 */     if (color != null) {
/* 3524 */       if (color.isDisposed())
/* 3525 */         error(5);
/* 3526 */       if (color.equals(this.headerBackground))
/* 3527 */         return;
/*      */     }
/* 3529 */     this.headerBackground = color;
/* 3530 */     if (GTK.GTK3) { GdkRGBA background;
/*      */       GdkRGBA background;
/* 3532 */       if (this.headerBackground != null) {
/* 3533 */         background = this.headerBackground.handleRGBA;
/*      */       } else {
/* 3535 */         background = defaultBackground();
/*      */       }
/* 3537 */       String name = GTK.GTK_VERSION >= OS.VERSION(3, 20, 0) ? "button" : "GtkButton";
/*      */       
/* 3539 */       String css = name + " {background: " + this.display.gtk_rgba_to_css_string(background) + ";}\n";
/* 3540 */       this.headerCSSBackground = css;
/* 3541 */       String finalCss = this.display.gtk_css_create_css_color_string(this.headerCSSBackground, this.headerCSSForeground, 8);
/* 3542 */       for (TableColumn column : this.columns) {
/* 3543 */         if (column != null) {
/* 3544 */           long context = GTK.gtk_widget_get_style_context(column.buttonHandle);
/*      */           
/* 3546 */           long provider = GTK.gtk_css_provider_new();
/* 3547 */           GTK.gtk_style_context_add_provider(context, provider, 600);
/* 3548 */           OS.g_object_unref(provider);
/* 3549 */           GTK.gtk_css_provider_load_from_data(provider, Converter.wcsToMbcs(finalCss, true), -1L, null);
/* 3550 */           GTK.gtk_style_context_invalidate(context);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setHeaderForeground(Color color)
/*      */   {
/* 3577 */     checkWidget();
/* 3578 */     if (color != null) {
/* 3579 */       if (color.isDisposed())
/* 3580 */         error(5);
/* 3581 */       if (color.equals(this.headerForeground))
/* 3582 */         return;
/*      */     }
/* 3584 */     this.headerForeground = color;
/* 3585 */     if (GTK.GTK3) { GdkRGBA foreground;
/*      */       GdkRGBA foreground;
/* 3587 */       if (this.headerForeground != null) {
/* 3588 */         foreground = this.headerForeground.handleRGBA;
/*      */       } else {
/* 3590 */         foreground = this.display.COLOR_LIST_FOREGROUND_RGBA;
/*      */       }
/* 3592 */       String name = GTK.GTK_VERSION >= OS.VERSION(3, 20, 0) ? "button" : "GtkButton";
/* 3593 */       String css = name + " {color: " + this.display.gtk_rgba_to_css_string(foreground) + ";}";
/* 3594 */       this.headerCSSForeground = css;
/* 3595 */       String finalCss = this.display.gtk_css_create_css_color_string(this.headerCSSBackground, this.headerCSSForeground, 16);
/* 3596 */       for (TableColumn column : this.columns) {
/* 3597 */         if (column != null) {
/* 3598 */           long context = GTK.gtk_widget_get_style_context(column.buttonHandle);
/*      */           
/* 3600 */           long provider = GTK.gtk_css_provider_new();
/* 3601 */           GTK.gtk_style_context_add_provider(context, provider, 600);
/* 3602 */           OS.g_object_unref(provider);
/* 3603 */           GTK.gtk_css_provider_load_from_data(provider, Converter.wcsToMbcs(finalCss, true), -1L, null);
/* 3604 */           GTK.gtk_style_context_invalidate(context);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setHeaderVisible(boolean show)
/*      */   {
/* 3628 */     checkWidget();
/* 3629 */     GTK.gtk_tree_view_set_headers_visible(this.handle, show);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setItemCount(int count)
/*      */   {
/* 3645 */     checkWidget();
/* 3646 */     count = Math.max(0, count);
/* 3647 */     if (count == this.itemCount) return;
/* 3648 */     boolean isVirtual = (this.style & 0x10000000) != 0;
/* 3649 */     if (!isVirtual) setRedraw(false);
/* 3650 */     remove(count, this.itemCount - 1);
/* 3651 */     int length = Math.max(4, (count + 3) / 4 * 4);
/* 3652 */     TableItem[] newItems = new TableItem[length];
/* 3653 */     System.arraycopy(this.items, 0, newItems, 0, this.itemCount);
/* 3654 */     this.items = newItems;
/* 3655 */     if (isVirtual) {
/* 3656 */       long iter = OS.g_malloc(GTK.GtkTreeIter_sizeof());
/* 3657 */       if (iter == 0L) error(2);
/* 3658 */       if (fixAccessibility()) {
/* 3659 */         this.ignoreAccessibility = true;
/*      */       }
/* 3661 */       for (int i = this.itemCount; i < count; i++) {
/* 3662 */         GTK.gtk_list_store_append(this.modelHandle, iter);
/*      */       }
/* 3664 */       if (fixAccessibility()) {
/* 3665 */         this.ignoreAccessibility = false;
/* 3666 */         OS.g_object_notify(this.handle, OS.model);
/*      */       }
/* 3668 */       OS.g_free(iter);
/* 3669 */       this.itemCount = count;
/*      */     } else {
/* 3671 */       for (int i = this.itemCount; i < count; i++) {
/* 3672 */         new TableItem(this, 0, i, true);
/*      */       }
/*      */     }
/* 3675 */     if (!isVirtual) { setRedraw(true);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setLinesVisible(boolean show)
/*      */   {
/* 3696 */     checkWidget();
/* 3697 */     if (!GTK.GTK3) {
/* 3698 */       GTK.gtk_tree_view_set_rules_hint(this.handle, show);
/*      */     }
/*      */     
/* 3701 */     GTK.gtk_tree_view_set_grid_lines(this.handle, show ? 2 : 0);
/*      */   }
/*      */   
/*      */   void setModel(long newModel) {
/* 3705 */     this.display.removeWidget(this.modelHandle);
/* 3706 */     OS.g_object_unref(this.modelHandle);
/* 3707 */     this.modelHandle = newModel;
/* 3708 */     this.display.addWidget(this.modelHandle, this);
/* 3709 */     if (fixAccessibility()) {
/* 3710 */       OS.g_signal_connect_closure(this.modelHandle, OS.row_inserted, this.display.getClosure(64), true);
/* 3711 */       OS.g_signal_connect_closure(this.modelHandle, OS.row_deleted, this.display.getClosure(65), true);
/*      */     }
/*      */   }
/*      */   
/*      */   void setOrientation(boolean create)
/*      */   {
/* 3717 */     super.setOrientation(create);
/* 3718 */     for (int i = 0; i < this.itemCount; i++) {
/* 3719 */       if (this.items[i] != null) this.items[i].setOrientation(create);
/*      */     }
/* 3721 */     for (int i = 0; i < this.columnCount; i++) {
/* 3722 */       if (this.columns[i] != null) this.columns[i].setOrientation(create);
/*      */     }
/*      */   }
/*      */   
/*      */   void setParentBackground()
/*      */   {
/* 3728 */     this.ownerDraw = true;
/* 3729 */     recreateRenderers();
/*      */   }
/*      */   
/*      */   void setParentGdkWindow(Control child)
/*      */   {
/* 3734 */     long parentGdkWindow = eventWindow();
/* 3735 */     GTK.gtk_widget_set_parent_window(child.topHandle(), parentGdkWindow);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3746 */     if (GTK.GTK_VERSION >= OS.VERSION(3, 10, 0)) {
/* 3747 */       this.hasChildren = true;
/* 3748 */       connectFixedHandleDraw();
/*      */     }
/*      */   }
/*      */   
/*      */   public void setRedraw(boolean redraw)
/*      */   {
/* 3754 */     checkWidget();
/* 3755 */     super.setRedraw(redraw);
/* 3756 */     if ((redraw) && (this.drawCount == 0))
/*      */     {
/* 3758 */       if ((this.items.length > 4) && (this.items.length - this.itemCount > 3)) {
/* 3759 */         int length = Math.max(4, (this.itemCount + 3) / 4 * 4);
/* 3760 */         TableItem[] newItems = new TableItem[length];
/* 3761 */         System.arraycopy(this.items, 0, newItems, 0, this.itemCount);
/* 3762 */         this.items = newItems;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   void setScrollWidth(long column, TableItem item) {
/* 3768 */     if ((this.columnCount != 0) || (this.currentItem == item)) return;
/* 3769 */     int width = GTK.gtk_tree_view_column_get_fixed_width(column);
/* 3770 */     int itemWidth = calculateWidth(column, item.handle);
/* 3771 */     if (width < itemWidth) {
/* 3772 */       GTK.gtk_tree_view_column_set_fixed_width(column, itemWidth);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSortColumn(TableColumn column)
/*      */   {
/* 3794 */     checkWidget();
/* 3795 */     if ((column != null) && (column.isDisposed())) error(5);
/* 3796 */     if ((this.sortColumn != null) && (!this.sortColumn.isDisposed())) {
/* 3797 */       GTK.gtk_tree_view_column_set_sort_indicator(this.sortColumn.handle, false);
/*      */     }
/* 3799 */     this.sortColumn = column;
/* 3800 */     if ((this.sortColumn != null) && (this.sortDirection != 0)) {
/* 3801 */       GTK.gtk_tree_view_column_set_sort_indicator(this.sortColumn.handle, true);
/* 3802 */       GTK.gtk_tree_view_column_set_sort_order(this.sortColumn.handle, this.sortDirection == 1024 ? 0 : 1);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSortDirection(int direction)
/*      */   {
/* 3820 */     checkWidget();
/* 3821 */     if ((direction != 128) && (direction != 1024) && (direction != 0)) return;
/* 3822 */     this.sortDirection = direction;
/* 3823 */     if ((this.sortColumn == null) || (this.sortColumn.isDisposed())) return;
/* 3824 */     if (this.sortDirection == 0) {
/* 3825 */       GTK.gtk_tree_view_column_set_sort_indicator(this.sortColumn.handle, false);
/*      */     } else {
/* 3827 */       GTK.gtk_tree_view_column_set_sort_indicator(this.sortColumn.handle, true);
/* 3828 */       GTK.gtk_tree_view_column_set_sort_order(this.sortColumn.handle, this.sortDirection == 1024 ? 0 : 1);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSelection(int index)
/*      */   {
/* 3848 */     checkWidget();
/* 3849 */     boolean fixColumn = showFirstColumn();
/* 3850 */     deselectAll();
/* 3851 */     selectFocusIndex(index);
/* 3852 */     showSelection();
/* 3853 */     if (fixColumn) { hideFirstColumn();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSelection(int start, int end)
/*      */   {
/* 3880 */     checkWidget();
/* 3881 */     deselectAll();
/* 3882 */     if ((end < 0) || (start > end) || (((this.style & 0x4) != 0) && (start != end))) return;
/* 3883 */     if ((this.itemCount == 0) || (start >= this.itemCount)) return;
/* 3884 */     boolean fixColumn = showFirstColumn();
/* 3885 */     start = Math.max(0, start);
/* 3886 */     end = Math.min(end, this.itemCount - 1);
/* 3887 */     selectFocusIndex(start);
/* 3888 */     if ((this.style & 0x2) != 0) {
/* 3889 */       select(start, end);
/*      */     }
/* 3891 */     showSelection();
/* 3892 */     if (fixColumn) { hideFirstColumn();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSelection(int[] indices)
/*      */   {
/* 3919 */     checkWidget();
/* 3920 */     if (indices == null) error(4);
/* 3921 */     deselectAll();
/* 3922 */     int length = indices.length;
/* 3923 */     if ((length == 0) || (((this.style & 0x4) != 0) && (length > 1))) return;
/* 3924 */     boolean fixColumn = showFirstColumn();
/* 3925 */     selectFocusIndex(indices[0]);
/* 3926 */     if ((this.style & 0x2) != 0) {
/* 3927 */       select(indices);
/*      */     }
/* 3929 */     showSelection();
/* 3930 */     if (fixColumn) { hideFirstColumn();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSelection(TableItem item)
/*      */   {
/* 3955 */     if (item == null) error(4);
/* 3956 */     setSelection(new TableItem[] { item });
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSelection(TableItem[] items)
/*      */   {
/* 3986 */     checkWidget();
/* 3987 */     if (items == null) error(4);
/* 3988 */     boolean fixColumn = showFirstColumn();
/* 3989 */     deselectAll();
/* 3990 */     int length = items.length;
/* 3991 */     if ((length != 0) && (((this.style & 0x4) == 0) || (length <= 1))) {
/* 3992 */       boolean first = true;
/* 3993 */       for (int i = 0; i < length; i++) {
/* 3994 */         int index = indexOf(items[i]);
/* 3995 */         if (index != -1) {
/* 3996 */           if (first) {
/* 3997 */             first = false;
/* 3998 */             selectFocusIndex(index);
/*      */           } else {
/* 4000 */             select(index);
/*      */           }
/*      */         }
/*      */       }
/* 4004 */       showSelection();
/*      */     }
/* 4006 */     if (fixColumn) { hideFirstColumn();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTopIndex(int index)
/*      */   {
/* 4022 */     checkWidget();
/* 4023 */     if ((0 > index) || (index >= this.itemCount)) {
/*      */       return;
/*      */     }
/*      */     
/*      */ 
/*      */     long vAdjustment;
/*      */     
/*      */     long vAdjustment;
/*      */     
/* 4032 */     if (GTK.GTK3) {
/* 4033 */       vAdjustment = GTK.gtk_scrollable_get_vadjustment(this.handle);
/*      */     } else {
/* 4035 */       vAdjustment = GTK.gtk_tree_view_get_vadjustment(this.handle);
/*      */     }
/* 4037 */     this.cachedAdjustment = GTK.gtk_adjustment_get_value(vAdjustment);
/* 4038 */     this.topIndex = index;
/* 4039 */     long path = GTK.gtk_tree_model_get_path(this.modelHandle, _getItem(index).handle);
/* 4040 */     GTK.gtk_tree_view_scroll_to_cell(this.handle, path, 0L, true, 0.0F, 0.0F);
/* 4041 */     GTK.gtk_tree_path_free(path);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void showColumn(TableColumn column)
/*      */   {
/* 4063 */     checkWidget();
/* 4064 */     if (column == null) error(4);
/* 4065 */     if (column.isDisposed()) error(5);
/* 4066 */     if (column.parent != this) { return;
/*      */     }
/* 4068 */     GTK.gtk_tree_view_scroll_to_cell(this.handle, 0L, column.handle, false, 0.0F, 0.0F);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   boolean showFirstColumn()
/*      */   {
/* 4076 */     int columnCount = Math.max(1, this.columnCount);
/* 4077 */     for (int i = 0; i < columnCount; i++) {
/* 4078 */       long column = GTK.gtk_tree_view_get_column(this.handle, i);
/* 4079 */       if (GTK.gtk_tree_view_column_get_visible(column)) return false;
/*      */     }
/* 4081 */     long firstColumn = GTK.gtk_tree_view_get_column(this.handle, 0);
/* 4082 */     GTK.gtk_tree_view_column_set_visible(firstColumn, true);
/* 4083 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void showItem(TableItem item)
/*      */   {
/* 4105 */     checkWidget();
/* 4106 */     if (item == null) error(4);
/* 4107 */     if (item.isDisposed()) error(5);
/* 4108 */     if (item.parent != this) return;
/* 4109 */     showItem(item.handle);
/*      */   }
/*      */   
/*      */   void showItem(long iter) {
/* 4113 */     long path = GTK.gtk_tree_model_get_path(this.modelHandle, iter);
/*      */     
/* 4115 */     GTK.gtk_tree_view_scroll_to_cell(this.handle, path, 0L, false, 0.0F, 0.0F);
/* 4116 */     GTK.gtk_tree_path_free(path);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void showSelection()
/*      */   {
/* 4132 */     checkWidget();
/* 4133 */     TableItem[] selection = getSelection();
/* 4134 */     if (selection.length == 0) return;
/* 4135 */     TableItem item = selection[0];
/* 4136 */     showItem(item.handle);
/*      */   }
/*      */   
/*      */   void updateScrollBarValue(ScrollBar bar)
/*      */   {
/* 4141 */     super.updateScrollBarValue(bar);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4149 */     long parentHandle = parentingHandle();
/* 4150 */     long list = GTK.gtk_container_get_children(parentHandle);
/* 4151 */     if (list == 0L) return;
/* 4152 */     long temp = list;
/* 4153 */     while (temp != 0L) {
/* 4154 */       long widget = OS.g_list_data(temp);
/* 4155 */       if (widget != 0L) GTK.gtk_widget_queue_resize(widget);
/* 4156 */       temp = OS.g_list_next(temp);
/*      */     }
/* 4158 */     OS.g_list_free(list);
/*      */   }
/*      */   
/*      */   long windowProc(long handle, long arg0, long user_data)
/*      */   {
/* 4163 */     switch ((int)user_data)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */     case 18: 
/* 4169 */       if ((GTK.GTK_VERSION >= OS.VERSION(3, 10, 0)) && (this.hasChildren)) {
/* 4170 */         propagateDraw(handle, arg0);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       break;
/*      */     case 19: 
/* 4180 */       if ((this.itemCount == 0) && ((this.state & 0x40) == 0) && (
/* 4181 */         ((this.state & 0x8000) != 0) || (this.backgroundImage != null))) {
/* 4182 */         Control control = findBackgroundControl();
/* 4183 */         if (control != null) {
/* 4184 */           GdkEventExpose gdkEvent = new GdkEventExpose();
/* 4185 */           OS.memmove(gdkEvent, arg0, GdkEventExpose.sizeof);
/* 4186 */           long window = GTK.gtk_tree_view_get_bin_window(handle);
/* 4187 */           if (window == gdkEvent.window) {
/* 4188 */             drawBackground(control, window, gdkEvent.region, gdkEvent.area_x, gdkEvent.area_y, gdkEvent.area_width, gdkEvent.area_height);
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */       break;
/*      */     }
/*      */     
/* 4196 */     return super.windowProc(handle, arg0, user_data);
/*      */   }
/*      */   
/*      */   Point resizeCalculationsGTK3(long widget, int width, int height)
/*      */   {
/* 4201 */     Point sizes = super.resizeCalculationsGTK3(widget, width, height);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4213 */     if ((widget == this.scrolledHandle) && (GTK.GTK_VERSION >= OS.VERSION(3, 14, 0)) && (getHeaderVisible())) {
/* 4214 */       int hScrollBarHeight = hScrollBarWidth();
/* 4215 */       if (hScrollBarHeight > 0) {
/* 4216 */         sizes.y = Math.max(sizes.y, getHeaderHeight() + hScrollBarHeight + getBorderWidth() * 2);
/*      */       }
/*      */     }
/* 4219 */     return sizes;
/*      */   }
/*      */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/widgets/Table.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */