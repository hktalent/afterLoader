/*      */ package org.eclipse.swt.widgets;
/*      */ 
/*      */ import org.eclipse.swt.events.SelectionListener;
/*      */ import org.eclipse.swt.graphics.Font;
/*      */ import org.eclipse.swt.graphics.Image;
/*      */ import org.eclipse.swt.graphics.Point;
/*      */ import org.eclipse.swt.internal.Converter;
/*      */ import org.eclipse.swt.internal.ImageList;
/*      */ import org.eclipse.swt.internal.gtk.GTK;
/*      */ import org.eclipse.swt.internal.gtk.GdkColor;
/*      */ import org.eclipse.swt.internal.gtk.GdkEventKey;
/*      */ import org.eclipse.swt.internal.gtk.GdkRGBA;
/*      */ import org.eclipse.swt.internal.gtk.GtkAllocation;
/*      */ import org.eclipse.swt.internal.gtk.GtkBorder;
/*      */ import org.eclipse.swt.internal.gtk.GtkRequisition;
/*      */ import org.eclipse.swt.internal.gtk.OS;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class Button
/*      */   extends Control
/*      */ {
/*      */   long boxHandle;
/*      */   long labelHandle;
/*      */   long imageHandle;
/*      */   long arrowHandle;
/*      */   long groupHandle;
/*      */   boolean selected;
/*      */   boolean grayed;
/*      */   ImageList imageList;
/*      */   Image image;
/*      */   String text;
/*      */   GdkRGBA background;
/*      */   static final int INNER_BORDER = 1;
/*      */   static final int DEFAULT_BORDER = 1;
/*      */   
/*      */   public Button(Composite parent, int style)
/*      */   {
/*   97 */     super(parent, checkStyle(style));
/*      */   }
/*      */   
/*      */   static int checkStyle(int style) {
/*  101 */     style = checkBits(style, 8, 4, 32, 16, 2, 0);
/*  102 */     if ((style & 0xA) != 0) {
/*  103 */       return checkBits(style, 16777216, 16384, 131072, 0, 0, 0);
/*      */     }
/*  105 */     if ((style & 0x30) != 0) {
/*  106 */       return checkBits(style, 16384, 131072, 16777216, 0, 0, 0);
/*      */     }
/*  108 */     if ((style & 0x4) != 0) {
/*  109 */       style |= 0x80000;
/*  110 */       return checkBits(style, 128, 1024, 16384, 131072, 0, 0);
/*      */     }
/*  112 */     return style;
/*      */   }
/*      */   
/*      */   static GtkBorder getBorder(byte[] border, long handle, int defaultBorder) {
/*  116 */     GtkBorder gtkBorder = new GtkBorder();
/*  117 */     long[] borderPtr = new long[1];
/*  118 */     GTK.gtk_widget_style_get(handle, border, borderPtr, 0L);
/*  119 */     if (borderPtr[0] != 0L) {
/*  120 */       OS.memmove(gtkBorder, borderPtr[0], GtkBorder.sizeof);
/*  121 */       GTK.gtk_border_free(borderPtr[0]);
/*  122 */       return gtkBorder;
/*      */     }
/*  124 */     gtkBorder.left = defaultBorder;
/*  125 */     gtkBorder.top = defaultBorder;
/*  126 */     gtkBorder.right = defaultBorder;
/*  127 */     gtkBorder.bottom = defaultBorder;
/*  128 */     return gtkBorder;
/*      */   }
/*      */   
/*      */   GdkRGBA getContextBackgroundGdkRGBA()
/*      */   {
/*  133 */     assert (GTK.GTK3) : "GTK3 code was run by GTK2";
/*  134 */     if ((this.background != null) && ((this.state & 0x2000) != 0)) {
/*  135 */       return this.background;
/*      */     }
/*  137 */     return defaultBackground();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addSelectionListener(SelectionListener listener)
/*      */   {
/*  171 */     checkWidget();
/*  172 */     if (listener == null) error(4);
/*  173 */     TypedListener typedListener = new TypedListener(listener);
/*  174 */     addListener(13, typedListener);
/*  175 */     addListener(14, typedListener);
/*      */   }
/*      */   
/*      */   Point computeSizeInPixels(int wHint, int hHint, boolean changed)
/*      */   {
/*  180 */     checkWidget();
/*  181 */     if ((wHint != -1) && (wHint < 0)) wHint = 0;
/*  182 */     if ((hHint != -1) && (hHint < 0)) { hHint = 0;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  189 */     forceResize();
/*  190 */     int[] reqWidth = null;int[] reqHeight = null;
/*  191 */     if ((this.style & 0x30) != 0) {
/*  192 */       reqWidth = new int[1];
/*  193 */       reqHeight = new int[1];
/*  194 */       GTK.gtk_widget_get_size_request(this.boxHandle, reqWidth, reqHeight);
/*  195 */       GTK.gtk_widget_set_size_request(this.boxHandle, -1, -1);
/*      */     }
/*      */     
/*  198 */     boolean wrap = (this.labelHandle != 0L) && ((this.style & 0x40) != 0) && (GTK.gtk_widget_get_visible(this.labelHandle));
/*  199 */     Point size; if (wrap) {
/*  200 */       int borderWidth = GTK.gtk_container_get_border_width(this.handle);
/*  201 */       int[] focusWidth = new int[1];
/*  202 */       GTK.gtk_widget_style_get(this.handle, OS.focus_line_width, focusWidth, 0L);
/*  203 */       int[] focusPadding = new int[1];
/*  204 */       GTK.gtk_widget_style_get(this.handle, OS.focus_padding, focusPadding, 0L);
/*  205 */       int trimWidth = 2 * (borderWidth + focusWidth[0] + focusPadding[0]);int trimHeight = trimWidth;
/*  206 */       int indicatorHeight = 0;
/*  207 */       if ((this.style & 0x30) != 0) {
/*  208 */         int[] indicatorSize = new int[1];
/*  209 */         GTK.gtk_widget_style_get(this.handle, OS.indicator_size, indicatorSize, 0L);
/*  210 */         int[] indicatorSpacing = new int[1];
/*  211 */         GTK.gtk_widget_style_get(this.handle, OS.indicator_spacing, indicatorSpacing, 0L);
/*  212 */         indicatorHeight = indicatorSize[0] + 2 * indicatorSpacing[0];
/*  213 */         trimWidth += indicatorHeight + indicatorSpacing[0];
/*      */       } else {
/*  215 */         Point thickness = getThickness(this.handle);
/*  216 */         trimWidth += thickness.x * 2;
/*  217 */         trimHeight += thickness.y * 2;
/*  218 */         GtkBorder innerBorder = getBorder(OS.inner_border, this.handle, 1);
/*  219 */         trimWidth += innerBorder.left + innerBorder.right;
/*  220 */         trimHeight += innerBorder.top + innerBorder.bottom;
/*  221 */         if (GTK.gtk_widget_get_can_default(this.handle)) {
/*  222 */           GtkBorder defaultBorder = getBorder(OS.default_border, this.handle, 1);
/*  223 */           trimWidth += defaultBorder.left + defaultBorder.right;
/*  224 */           trimHeight += defaultBorder.top + defaultBorder.bottom;
/*      */         }
/*      */       }
/*  227 */       int imageWidth = 0;int imageHeight = 0;
/*  228 */       if (GTK.gtk_widget_get_visible(this.imageHandle)) {
/*  229 */         GtkRequisition requisition = new GtkRequisition();
/*  230 */         gtk_widget_get_preferred_size(this.imageHandle, requisition);
/*  231 */         imageWidth = requisition.width;
/*  232 */         imageHeight = requisition.height;
/*  233 */         int[] spacing = new int[1];
/*  234 */         OS.g_object_get(this.boxHandle, OS.spacing, spacing, 0L);
/*  235 */         imageWidth += spacing[0];
/*      */       }
/*  237 */       long labelLayout = GTK.gtk_label_get_layout(this.labelHandle);
/*  238 */       int pangoWidth = OS.pango_layout_get_width(labelLayout);
/*  239 */       if (wHint != -1) {
/*  240 */         OS.pango_layout_set_width(labelLayout, Math.max(1, wHint - imageWidth - trimWidth) * 1024);
/*      */       } else {
/*  242 */         OS.pango_layout_set_width(labelLayout, -1);
/*      */       }
/*  244 */       int[] w = new int[1];int[] h = new int[1];
/*  245 */       OS.pango_layout_get_pixel_size(labelLayout, w, h);
/*  246 */       OS.pango_layout_set_width(labelLayout, pangoWidth);
/*  247 */       Point size = new Point(0, 0);
/*  248 */       size.x += (wHint == -1 ? w[0] + imageWidth + trimWidth : wHint);
/*  249 */       size.y += (hHint == -1 ? Math.max(Math.max(imageHeight, indicatorHeight), h[0]) + trimHeight : hHint);
/*      */     } else {
/*  251 */       size = computeNativeSize(this.handle, wHint, hHint, changed);
/*      */     }
/*  253 */     if ((this.style & 0x30) != 0) {
/*  254 */       GTK.gtk_widget_set_size_request(this.boxHandle, reqWidth[0], reqHeight[0]);
/*      */     }
/*  256 */     if (((wHint != -1) || (hHint != -1)) && 
/*  257 */       (GTK.gtk_widget_get_can_default(this.handle))) {
/*  258 */       GtkBorder border = getBorder(OS.default_border, this.handle, 1);
/*  259 */       if (wHint != -1) size.x += border.left + border.right;
/*  260 */       if (hHint != -1) { size.y += border.top + border.bottom;
/*      */       }
/*      */     }
/*  263 */     return size;
/*      */   }
/*      */   
/*      */   void createHandle(int index)
/*      */   {
/*  268 */     this.state |= 0x8;
/*  269 */     if ((this.style & 0xA) == 0) this.state |= 0x10000;
/*  270 */     int bits = 62;
/*  271 */     this.fixedHandle = OS.g_object_new(this.display.gtk_fixed_get_type(), 0L);
/*  272 */     if (this.fixedHandle == 0L) error(2);
/*  273 */     GTK.gtk_widget_set_has_window(this.fixedHandle, true);
/*  274 */     switch (this.style & bits) {
/*      */     case 4: 
/*  276 */       if (GTK.GTK3) {
/*  277 */         byte[] arrowType = GTK.GTK_NAMED_ICON_GO_UP;
/*  278 */         if ((this.style & 0x80) != 0) arrowType = GTK.GTK_NAMED_ICON_GO_UP;
/*  279 */         if ((this.style & 0x400) != 0) arrowType = GTK.GTK_NAMED_ICON_GO_DOWN;
/*  280 */         if ((this.style & 0x4000) != 0) arrowType = GTK.GTK_NAMED_ICON_GO_PREVIOUS;
/*  281 */         if ((this.style & 0x20000) != 0) arrowType = GTK.GTK_NAMED_ICON_GO_NEXT;
/*  282 */         this.arrowHandle = GTK.gtk_image_new_from_icon_name(arrowType, 1);
/*      */       } else {
/*  284 */         int arrowType = 0;
/*  285 */         if ((this.style & 0x80) != 0) arrowType = 0;
/*  286 */         if ((this.style & 0x400) != 0) arrowType = 1;
/*  287 */         if ((this.style & 0x4000) != 0) arrowType = 2;
/*  288 */         if ((this.style & 0x20000) != 0) arrowType = 3;
/*  289 */         this.arrowHandle = GTK.gtk_arrow_new(arrowType, 2);
/*      */       }
/*  291 */       if (this.arrowHandle == 0L) { error(2);
/*      */       }
/*  293 */       this.handle = GTK.gtk_button_new();
/*  294 */       if (this.handle == 0L) error(2);
/*      */       break;
/*      */     case 2: 
/*  297 */       this.handle = GTK.gtk_toggle_button_new();
/*  298 */       if (this.handle == 0L) error(2);
/*      */       break;
/*      */     case 32: 
/*  301 */       this.handle = GTK.gtk_check_button_new();
/*  302 */       if (this.handle == 0L) { error(2);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       break;
/*      */     case 16: 
/*  316 */       this.groupHandle = GTK.gtk_radio_button_new(0L);
/*  317 */       if (this.groupHandle == 0L) error(2);
/*  318 */       OS.g_object_ref(this.groupHandle);
/*  319 */       OS.g_object_ref_sink(this.groupHandle);
/*  320 */       this.handle = GTK.gtk_radio_button_new(GTK.gtk_radio_button_get_group(this.groupHandle));
/*  321 */       if (this.handle == 0L) error(2);
/*      */       break;
/*      */     case 8: 
/*      */     default: 
/*  325 */       this.handle = GTK.gtk_button_new();
/*  326 */       if (this.handle == 0L) error(2);
/*  327 */       GTK.gtk_widget_set_can_default(this.handle, true);
/*      */     }
/*      */     
/*  330 */     if ((this.style & 0x4) != 0)
/*      */     {
/*      */ 
/*  333 */       if (GTK.GTK3) {
/*  334 */         GTK.gtk_button_set_image(this.handle, this.arrowHandle);
/*      */       } else {
/*  336 */         GTK.gtk_container_add(this.handle, this.arrowHandle);
/*      */       }
/*      */     } else {
/*  339 */       this.boxHandle = gtk_box_new(0, false, 4);
/*  340 */       if (this.boxHandle == 0L) error(2);
/*  341 */       this.labelHandle = GTK.gtk_label_new_with_mnemonic(null);
/*  342 */       if (this.labelHandle == 0L) error(2);
/*  343 */       this.imageHandle = GTK.gtk_image_new();
/*  344 */       if (this.imageHandle == 0L) error(2);
/*  345 */       GTK.gtk_container_add(this.handle, this.boxHandle);
/*  346 */       GTK.gtk_container_add(this.boxHandle, this.imageHandle);
/*  347 */       GTK.gtk_container_add(this.boxHandle, this.labelHandle);
/*  348 */       if ((this.style & 0x40) != 0) {
/*  349 */         GTK.gtk_label_set_line_wrap(this.labelHandle, true);
/*  350 */         GTK.gtk_label_set_line_wrap_mode(this.labelHandle, 2);
/*      */       }
/*      */     }
/*  353 */     GTK.gtk_container_add(this.fixedHandle, this.handle);
/*      */     
/*  355 */     if ((this.style & 0x4) != 0) { return;
/*      */     }
/*      */     
/*  358 */     if (GTK.GTK3) {
/*  359 */       setFontDescription(defaultFont().handle);
/*      */     }
/*  361 */     _setAlignment(this.style & 0x1024000);
/*      */   }
/*      */   
/*      */   void createWidget(int index)
/*      */   {
/*  366 */     super.createWidget(index);
/*  367 */     this.text = "";
/*      */   }
/*      */   
/*      */   void deregister()
/*      */   {
/*  372 */     super.deregister();
/*  373 */     if (this.boxHandle != 0L) this.display.removeWidget(this.boxHandle);
/*  374 */     if (this.labelHandle != 0L) this.display.removeWidget(this.labelHandle);
/*  375 */     if (this.imageHandle != 0L) this.display.removeWidget(this.imageHandle);
/*  376 */     if (this.arrowHandle != 0L) this.display.removeWidget(this.arrowHandle);
/*      */   }
/*      */   
/*      */   long fontHandle()
/*      */   {
/*  381 */     if (this.labelHandle != 0L) return this.labelHandle;
/*  382 */     return super.fontHandle();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getAlignment()
/*      */   {
/*  402 */     checkWidget();
/*  403 */     if ((this.style & 0x4) != 0) {
/*  404 */       if ((this.style & 0x80) != 0) return 128;
/*  405 */       if ((this.style & 0x400) != 0) return 1024;
/*  406 */       if ((this.style & 0x4000) != 0) return 16384;
/*  407 */       if ((this.style & 0x20000) != 0) return 131072;
/*  408 */       return 128;
/*      */     }
/*  410 */     if ((this.style & 0x4000) != 0) return 16384;
/*  411 */     if ((this.style & 0x1000000) != 0) return 16777216;
/*  412 */     if ((this.style & 0x20000) != 0) return 131072;
/*  413 */     return 16384;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getGrayed()
/*      */   {
/*  431 */     checkWidget();
/*  432 */     if ((this.style & 0x20) == 0) return false;
/*  433 */     return this.grayed;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Image getImage()
/*      */   {
/*  448 */     checkWidget();
/*  449 */     return this.image;
/*      */   }
/*      */   
/*      */   String getNameText()
/*      */   {
/*  454 */     return getText();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getSelection()
/*      */   {
/*  474 */     checkWidget();
/*  475 */     if ((this.style & 0x32) == 0) return false;
/*  476 */     return GTK.gtk_toggle_button_get_active(this.handle);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getText()
/*      */   {
/*  492 */     checkWidget();
/*  493 */     if ((this.style & 0x4) != 0) return "";
/*  494 */     return this.text;
/*      */   }
/*      */   
/*      */   long gtk_button_press_event(long widget, long event)
/*      */   {
/*  499 */     long result = super.gtk_button_press_event(widget, event);
/*  500 */     if (result != 0L) return result;
/*  501 */     if ((this.style & 0x10) != 0) this.selected = getSelection();
/*  502 */     return result;
/*      */   }
/*      */   
/*      */   long gtk_clicked(long widget)
/*      */   {
/*  507 */     if (containedInRegion(this.lastInput.x, this.lastInput.y)) return 0L;
/*  508 */     if ((this.style & 0x10) != 0) {
/*  509 */       if ((this.parent.getStyle() & 0x400000) != 0) {
/*  510 */         setSelection(!this.selected);
/*      */       } else {
/*  512 */         selectRadio();
/*      */       }
/*      */     }
/*  515 */     else if (((this.style & 0x20) != 0) && 
/*  516 */       (this.grayed)) {
/*  517 */       if (GTK.gtk_toggle_button_get_active(this.handle)) {
/*  518 */         GTK.gtk_toggle_button_set_inconsistent(this.handle, true);
/*      */       } else {
/*  520 */         GTK.gtk_toggle_button_set_inconsistent(this.handle, false);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  525 */     sendSelectionEvent(13);
/*  526 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_focus_in_event(long widget, long event)
/*      */   {
/*  531 */     long result = super.gtk_focus_in_event(widget, event);
/*      */     
/*  533 */     if (this.handle == 0L) return 0L;
/*  534 */     if (((this.style & 0x8) != 0) && (GTK.gtk_widget_has_default(this.handle))) {
/*  535 */       Decorations menuShell = menuShell();
/*  536 */       menuShell.defaultButton = this;
/*      */     }
/*  538 */     return result;
/*      */   }
/*      */   
/*      */   long gtk_focus_out_event(long widget, long event)
/*      */   {
/*  543 */     long result = super.gtk_focus_out_event(widget, event);
/*      */     
/*  545 */     if (this.handle == 0L) return 0L;
/*  546 */     if ((this.style & 0x8) != 0) {
/*  547 */       Decorations menuShell = menuShell();
/*  548 */       if (menuShell.defaultButton == this) {
/*  549 */         menuShell.defaultButton = null;
/*      */       }
/*      */     }
/*  552 */     return result;
/*      */   }
/*      */   
/*      */   long gtk_key_press_event(long widget, long event)
/*      */   {
/*  557 */     long result = super.gtk_key_press_event(widget, event);
/*  558 */     if (result != 0L) return result;
/*  559 */     if ((this.style & 0x10) != 0) this.selected = getSelection();
/*  560 */     return result;
/*      */   }
/*      */   
/*      */   void hookEvents()
/*      */   {
/*  565 */     super.hookEvents();
/*  566 */     OS.g_signal_connect_closure(this.handle, OS.clicked, this.display.getClosure(8), false);
/*  567 */     if (this.labelHandle != 0L) {
/*  568 */       OS.g_signal_connect_closure_by_id(this.labelHandle, this.display.signalIds[32], 0, this.display.getClosure(32), false);
/*      */     }
/*      */   }
/*      */   
/*      */   boolean isDescribedByLabel()
/*      */   {
/*  574 */     return false;
/*      */   }
/*      */   
/*      */   boolean mnemonicHit(char key)
/*      */   {
/*  579 */     if (this.labelHandle == 0L) return false;
/*  580 */     boolean result = super.mnemonicHit(this.labelHandle, key);
/*  581 */     if (result) setFocus();
/*  582 */     return result;
/*      */   }
/*      */   
/*      */   boolean mnemonicMatch(char key)
/*      */   {
/*  587 */     if (this.labelHandle == 0L) return false;
/*  588 */     return mnemonicMatch(this.labelHandle, key);
/*      */   }
/*      */   
/*      */   void register()
/*      */   {
/*  593 */     super.register();
/*  594 */     if (this.boxHandle != 0L) this.display.addWidget(this.boxHandle, this);
/*  595 */     if (this.labelHandle != 0L) this.display.addWidget(this.labelHandle, this);
/*  596 */     if (this.imageHandle != 0L) this.display.addWidget(this.imageHandle, this);
/*  597 */     if (this.arrowHandle != 0L) this.display.addWidget(this.arrowHandle, this);
/*      */   }
/*      */   
/*      */   void releaseHandle()
/*      */   {
/*  602 */     super.releaseHandle();
/*  603 */     this.boxHandle = (this.imageHandle = this.labelHandle = this.arrowHandle = 0L);
/*      */   }
/*      */   
/*      */   void releaseWidget()
/*      */   {
/*  608 */     super.releaseWidget();
/*  609 */     if (this.groupHandle != 0L) OS.g_object_unref(this.groupHandle);
/*  610 */     this.groupHandle = 0L;
/*  611 */     if (this.imageList != null) this.imageList.dispose();
/*  612 */     this.imageList = null;
/*  613 */     this.image = null;
/*  614 */     this.text = null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeSelectionListener(SelectionListener listener)
/*      */   {
/*  635 */     checkWidget();
/*  636 */     if (listener == null) error(4);
/*  637 */     if (this.eventTable == null) return;
/*  638 */     this.eventTable.unhook(13, listener);
/*  639 */     this.eventTable.unhook(14, listener);
/*      */   }
/*      */   
/*      */   void resizeHandle(int width, int height)
/*      */   {
/*  644 */     super.resizeHandle(width, height);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  651 */     if ((!GTK.GTK3) && 
/*  652 */       ((this.style & 0x30) != 0)) {
/*  653 */       GTK.gtk_widget_set_size_request(this.boxHandle, width, -1);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void selectRadio()
/*      */   {
/*  675 */     Control[] children = this.parent._getChildren();
/*  676 */     for (int i = 0; i < children.length; i++) {
/*  677 */       Control child = children[i];
/*  678 */       if (this != child) child.setRadioSelection(false);
/*      */     }
/*  680 */     setSelection(true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAlignment(int alignment)
/*      */   {
/*  700 */     checkWidget();
/*  701 */     _setAlignment(alignment);
/*      */   }
/*      */   
/*      */   void _setAlignment(int alignment) {
/*  705 */     if ((this.style & 0x4) != 0) {
/*  706 */       if ((this.style & 0x24480) == 0) return;
/*  707 */       this.style &= 0xFFFDBB7F;
/*  708 */       this.style |= alignment & 0x24480;
/*  709 */       boolean isRTL = (this.style & 0x4000000) != 0;
/*  710 */       if (GTK.GTK3) {
/*  711 */         byte[] arrowType = GTK.GTK_NAMED_ICON_GO_UP;
/*  712 */         switch (alignment) {
/*  713 */         case 128:  arrowType = GTK.GTK_NAMED_ICON_GO_UP; break;
/*  714 */         case 1024:  arrowType = GTK.GTK_NAMED_ICON_GO_DOWN; break;
/*  715 */         case 16384:  arrowType = isRTL ? GTK.GTK_NAMED_ICON_GO_NEXT : GTK.GTK_NAMED_ICON_GO_PREVIOUS; break;
/*  716 */         case 131072:  arrowType = isRTL ? GTK.GTK_NAMED_ICON_GO_PREVIOUS : GTK.GTK_NAMED_ICON_GO_NEXT;
/*      */         }
/*  718 */         GTK.gtk_image_set_from_icon_name(this.arrowHandle, arrowType, 1);
/*      */       } else {
/*  720 */         int arrowType = 0;
/*  721 */         switch (alignment) {
/*  722 */         case 128:  arrowType = 0; break;
/*  723 */         case 1024:  arrowType = 1; break;
/*  724 */         case 16384:  arrowType = isRTL ? 3 : 2; break;
/*  725 */         case 131072:  arrowType = isRTL ? 2 : 3;
/*      */         }
/*  727 */         GTK.gtk_arrow_set(this.arrowHandle, arrowType, 2);
/*      */       }
/*  729 */       return;
/*      */     }
/*  731 */     if ((alignment & 0x1024000) == 0) return;
/*  732 */     this.style &= 0xFEFDBFFF;
/*  733 */     this.style |= alignment & 0x1024000;
/*      */     
/*  735 */     boolean bothVisible = (GTK.gtk_widget_get_visible(this.labelHandle)) && (GTK.gtk_widget_get_visible(this.imageHandle));
/*  736 */     if (bothVisible) {
/*  737 */       if ((this.style & 0x30) != 0) alignment = 16384;
/*  738 */       if ((this.style & 0xA) != 0) alignment = 16777216;
/*      */     }
/*  740 */     if ((alignment & 0x4000) != 0) {
/*  741 */       if (bothVisible) {
/*  742 */         GTK.gtk_box_set_child_packing(this.boxHandle, this.labelHandle, false, false, 0, 0);
/*  743 */         GTK.gtk_box_set_child_packing(this.boxHandle, this.imageHandle, false, false, 0, 0);
/*      */       }
/*  745 */       else if (GTK.GTK3) {
/*  746 */         GTK.gtk_box_set_child_packing(this.boxHandle, this.labelHandle, true, true, 0, 1);
/*  747 */         GTK.gtk_box_set_child_packing(this.boxHandle, this.imageHandle, true, true, 0, 0);
/*      */       }
/*      */       
/*      */ 
/*  751 */       if (GTK.GTK_VERSION >= OS.VERSION(3, 16, 0)) {
/*  752 */         gtk_label_set_align(this.labelHandle, 0.0F, 0.5F);
/*  753 */         gtk_widget_set_align(this.imageHandle, 1, 3);
/*      */       } else {
/*  755 */         GTK.gtk_misc_set_alignment(this.labelHandle, 0.0F, 0.5F);
/*  756 */         GTK.gtk_misc_set_alignment(this.imageHandle, 0.0F, 0.5F);
/*      */       }
/*      */       
/*  759 */       GTK.gtk_label_set_justify(this.labelHandle, 0);
/*  760 */       return;
/*      */     }
/*  762 */     if ((alignment & 0x1000000) != 0) {
/*  763 */       if (bothVisible) {
/*  764 */         GTK.gtk_box_set_child_packing(this.boxHandle, this.labelHandle, true, true, 0, 1);
/*  765 */         GTK.gtk_box_set_child_packing(this.boxHandle, this.imageHandle, true, true, 0, 0);
/*      */         
/*  767 */         if (GTK.GTK_VERSION >= OS.VERSION(3, 16, 0)) {
/*  768 */           gtk_label_set_align(this.labelHandle, 0.0F, 0.5F);
/*  769 */           gtk_widget_set_align(this.imageHandle, 2, 3);
/*      */         } else {
/*  771 */           GTK.gtk_misc_set_alignment(this.labelHandle, 0.0F, 0.5F);
/*  772 */           GTK.gtk_misc_set_alignment(this.imageHandle, 1.0F, 0.5F);
/*      */         }
/*      */       }
/*      */       else {
/*  776 */         if (GTK.GTK3) {
/*  777 */           GTK.gtk_box_set_child_packing(this.boxHandle, this.labelHandle, true, true, 0, 1);
/*  778 */           GTK.gtk_box_set_child_packing(this.boxHandle, this.imageHandle, true, true, 0, 0);
/*      */         }
/*      */         
/*  781 */         if (GTK.GTK_VERSION >= OS.VERSION(3, 16, 0)) {
/*  782 */           gtk_label_set_align(this.labelHandle, 0.5F, 0.5F);
/*  783 */           gtk_widget_set_align(this.imageHandle, 3, 3);
/*      */         } else {
/*  785 */           GTK.gtk_misc_set_alignment(this.labelHandle, 0.5F, 0.5F);
/*  786 */           GTK.gtk_misc_set_alignment(this.imageHandle, 0.5F, 0.5F);
/*      */         }
/*  788 */         GTK.gtk_label_set_justify(this.labelHandle, 2);
/*      */       }
/*  790 */       return;
/*      */     }
/*  792 */     if ((alignment & 0x20000) != 0) {
/*  793 */       if (bothVisible) {
/*  794 */         GTK.gtk_box_set_child_packing(this.boxHandle, this.labelHandle, false, false, 0, 1);
/*  795 */         GTK.gtk_box_set_child_packing(this.boxHandle, this.imageHandle, false, false, 0, 1);
/*      */       }
/*  797 */       else if (GTK.GTK3) {
/*  798 */         GTK.gtk_box_set_child_packing(this.boxHandle, this.labelHandle, true, true, 0, 1);
/*  799 */         GTK.gtk_box_set_child_packing(this.boxHandle, this.imageHandle, true, true, 0, 0);
/*      */       }
/*      */       
/*      */ 
/*  803 */       if (GTK.GTK_VERSION >= OS.VERSION(3, 16, 0)) {
/*  804 */         gtk_label_set_align(this.labelHandle, 1.0F, 0.5F);
/*  805 */         gtk_widget_set_align(this.imageHandle, 2, 3);
/*      */       } else {
/*  807 */         GTK.gtk_misc_set_alignment(this.labelHandle, 1.0F, 0.5F);
/*  808 */         GTK.gtk_misc_set_alignment(this.imageHandle, 1.0F, 0.5F);
/*      */       }
/*  810 */       GTK.gtk_label_set_justify(this.labelHandle, 1);
/*  811 */       return;
/*      */     }
/*      */   }
/*      */   
/*      */   void setBackgroundGdkRGBA(long context, long handle, GdkRGBA rgba)
/*      */   {
/*  817 */     assert (GTK.GTK3) : "GTK3 code was run by GTK2";
/*      */     
/*  819 */     this.background = rgba;
/*      */     
/*      */ 
/*  822 */     if ((GTK.GTK_VERSION < OS.VERSION(3, 10, 3)) && ((this.style & 0x30) != 0)) {
/*  823 */       super.setBackgroundGdkRGBA(context, handle, rgba);
/*  824 */       return;
/*      */     }
/*      */     
/*  827 */     String css = "* {background : ";
/*  828 */     String color = this.display.gtk_rgba_to_css_string(rgba);
/*  829 */     css = css + color + ";}";
/*      */     
/*      */ 
/*  832 */     this.cssBackground = css;
/*      */     
/*      */ 
/*  835 */     String finalCss = this.display.gtk_css_create_css_color_string(this.cssBackground, this.cssForeground, 8);
/*  836 */     gtk_css_provider_load_from_css(context, finalCss);
/*      */   }
/*      */   
/*      */   void setBackgroundGdkColor(GdkColor color)
/*      */   {
/*  841 */     assert (!GTK.GTK3) : "GTK2 code was run by GTK3";
/*  842 */     super.setBackgroundGdkColor(color);
/*  843 */     setBackgroundGdkColor(this.fixedHandle, color);
/*  844 */     if (this.labelHandle != 0L) setBackgroundGdkColor(this.labelHandle, color);
/*  845 */     if (this.imageHandle != 0L) { setBackgroundGdkColor(this.imageHandle, color);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   int setBounds(int x, int y, int width, int height, boolean move, boolean resize)
/*      */   {
/*  862 */     boolean wrap = (this.labelHandle != 0L) && ((this.style & 0x40) != 0) && (GTK.gtk_widget_get_visible(this.labelHandle));
/*  863 */     if (wrap) GTK.gtk_widget_set_size_request(this.boxHandle, -1, -1);
/*  864 */     int result = super.setBounds(x, y, width, height, move, resize);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  876 */     if (wrap) {
/*  877 */       GtkAllocation allocation = new GtkAllocation();
/*  878 */       GTK.gtk_widget_get_allocation(this.boxHandle, allocation);
/*  879 */       int boxWidth = allocation.width;
/*  880 */       int boxHeight = allocation.height;
/*  881 */       long labelLayout = GTK.gtk_label_get_layout(this.labelHandle);
/*  882 */       int pangoWidth = OS.pango_layout_get_width(labelLayout);
/*  883 */       OS.pango_layout_set_width(labelLayout, -1);
/*  884 */       int[] w = new int[1];int[] h = new int[1];
/*  885 */       OS.pango_layout_get_pixel_size(labelLayout, w, h);
/*  886 */       OS.pango_layout_set_width(labelLayout, pangoWidth);
/*  887 */       int imageWidth = 0;
/*  888 */       if (GTK.gtk_widget_get_visible(this.imageHandle)) {
/*  889 */         GtkRequisition requisition = new GtkRequisition();
/*  890 */         gtk_widget_get_preferred_size(this.imageHandle, requisition);
/*  891 */         imageWidth = requisition.width;
/*  892 */         int[] spacing = new int[1];
/*  893 */         OS.g_object_get(this.boxHandle, OS.spacing, spacing, 0L);
/*  894 */         imageWidth += spacing[0];
/*      */       }
/*  896 */       GTK.gtk_widget_set_size_request(this.labelHandle, Math.min(w[0], boxWidth - imageWidth), -1);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  901 */       GtkRequisition requisition = new GtkRequisition();
/*  902 */       gtk_widget_get_preferred_size(this.boxHandle, requisition);
/*  903 */       allocation.width = boxWidth;
/*  904 */       allocation.height = boxHeight;
/*  905 */       Point sizes = resizeCalculationsGTK3(this.boxHandle, boxWidth, boxHeight);
/*  906 */       allocation.width = sizes.x;
/*  907 */       allocation.height = sizes.y;
/*  908 */       GTK.gtk_widget_size_allocate(this.boxHandle, allocation);
/*      */     }
/*  910 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */   void setFontDescription(long fontDesc)
/*      */   {
/*  916 */     if ((GTK.GTK_VERSION >= OS.VERSION(3, 22, 0)) && (((this.text != null) && (this.text.isEmpty())) || (this.text == null))) {
/*  917 */       return;
/*      */     }
/*  919 */     super.setFontDescription(fontDesc);
/*  920 */     if (this.labelHandle != 0L) setFontDescription(this.labelHandle, fontDesc);
/*  921 */     if (this.imageHandle != 0L) { setFontDescription(this.imageHandle, fontDesc);
/*      */     }
/*      */   }
/*      */   
/*      */   boolean setRadioSelection(boolean value)
/*      */   {
/*  927 */     if ((this.style & 0x10) == 0) return false;
/*  928 */     if (getSelection() != value) {
/*  929 */       setSelection(value);
/*  930 */       sendSelectionEvent(13);
/*      */     }
/*  932 */     return true;
/*      */   }
/*      */   
/*      */   void setForegroundGdkRGBA(GdkRGBA rgba)
/*      */   {
/*  937 */     assert (GTK.GTK3) : "GTK3 code was run by GTK2";
/*  938 */     super.setForegroundGdkRGBA(rgba);
/*  939 */     setForegroundGdkRGBA(this.fixedHandle, rgba);
/*  940 */     if (this.labelHandle != 0L) setForegroundGdkRGBA(this.labelHandle, rgba);
/*  941 */     if (this.imageHandle != 0L) { setForegroundGdkRGBA(this.imageHandle, rgba);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  949 */     if ((GTK.GTK_VERSION >= OS.VERSION(3, 10, 0)) && (GTK.GTK_VERSION < OS.VERSION(3, 16, 0)) && ((this.style & 0x30) != 0))
/*      */     {
/*  951 */       gtk_swt_set_border_color(rgba);
/*      */     }
/*      */   }
/*      */   
/*      */   void setForegroundGdkColor(GdkColor color)
/*      */   {
/*  957 */     assert (!GTK.GTK3) : "GTK2 code was run by GTK3";
/*  958 */     super.setForegroundGdkColor(color);
/*  959 */     setForegroundColor(this.fixedHandle, color);
/*  960 */     if (this.labelHandle != 0L) setForegroundColor(this.labelHandle, color);
/*  961 */     if (this.imageHandle != 0L) setForegroundColor(this.imageHandle, color);
/*      */   }
/*      */   
/*      */   void setForegroundGdkRGBA(long handle, GdkRGBA rgba)
/*      */   {
/*  966 */     assert (GTK.GTK3) : "GTK3 code was run by GTK2";
/*  967 */     if (GTK.GTK_VERSION < OS.VERSION(3, 14, 0)) {
/*  968 */       super.setForegroundGdkRGBA(handle, rgba);
/*  969 */       return;
/*      */     }
/*  971 */     GdkRGBA toSet = rgba == null ? this.display.COLOR_WIDGET_FOREGROUND_RGBA : rgba;
/*  972 */     long context = GTK.gtk_widget_get_style_context(handle);
/*      */     
/*      */ 
/*  975 */     String color = this.display.gtk_rgba_to_css_string(toSet);
/*  976 */     String name = GTK.GTK_VERSION >= OS.VERSION(3, 20, 0) ? "button" : "GtkButton";
/*  977 */     String css = name + " {color: " + color + ";}";
/*      */     
/*      */ 
/*  980 */     this.cssForeground = css;
/*      */     
/*      */ 
/*  983 */     String finalCss = this.display.gtk_css_create_css_color_string(this.cssBackground, this.cssForeground, 16);
/*  984 */     gtk_css_provider_load_from_css(context, finalCss);
/*      */   }
/*      */   
/*      */   private void gtk_swt_set_border_color(GdkRGBA rgba) {
/*  988 */     assert (GTK.GTK3) : "GTK3 code was run by GTK2";
/*  989 */     String css_string = "* {\n";
/*  990 */     if (rgba != null) {
/*  991 */       String css_color = this.display.gtk_rgba_to_css_string(rgba);
/*  992 */       css_string = css_string + "border-color: " + css_color + ";\n";
/*      */     }
/*  994 */     css_string = css_string + "}\n";
/*      */     String finalCss;
/*      */     String finalCss;
/*  997 */     if (GTK.GTK_VERSION >= OS.VERSION(3, 14, 0))
/*      */     {
/*  999 */       this.cssForeground = (this.cssForeground + "\n" + css_string);
/* 1000 */       finalCss = this.display.gtk_css_create_css_color_string(this.cssBackground, this.cssForeground, 16);
/*      */     } else {
/* 1002 */       finalCss = css_string;
/*      */     }
/*      */     
/*      */ 
/* 1006 */     long context = GTK.gtk_widget_get_style_context(this.handle);
/* 1007 */     gtk_css_provider_load_from_css(context, finalCss);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setGrayed(boolean grayed)
/*      */   {
/* 1025 */     checkWidget();
/* 1026 */     if ((this.style & 0x20) == 0) return;
/* 1027 */     this.grayed = grayed;
/* 1028 */     if ((grayed) && (GTK.gtk_toggle_button_get_active(this.handle))) {
/* 1029 */       GTK.gtk_toggle_button_set_inconsistent(this.handle, true);
/*      */     } else {
/* 1031 */       GTK.gtk_toggle_button_set_inconsistent(this.handle, false);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setImage(Image image)
/*      */   {
/* 1055 */     checkWidget();
/* 1056 */     if ((this.style & 0x4) != 0) return;
/* 1057 */     if (this.imageList != null) this.imageList.dispose();
/* 1058 */     this.imageList = null;
/* 1059 */     if (image != null) {
/* 1060 */       if (image.isDisposed()) error(5);
/* 1061 */       this.imageList = new ImageList();
/* 1062 */       int imageIndex = this.imageList.add(image);
/* 1063 */       long pixbuf = this.imageList.getPixbuf(imageIndex);
/* 1064 */       gtk_image_set_from_pixbuf(this.imageHandle, pixbuf);
/*      */     } else {
/* 1066 */       gtk_image_set_from_pixbuf(this.imageHandle, 0L);
/*      */     }
/* 1068 */     this.image = image;
/* 1069 */     updateWidgetsVisibility();
/* 1070 */     _setAlignment(this.style);
/*      */   }
/*      */   
/*      */   void setOrientation(boolean create)
/*      */   {
/* 1075 */     super.setOrientation(create);
/* 1076 */     if (((this.style & 0x4000000) != 0) || (!create)) {
/* 1077 */       int dir = (this.style & 0x4000000) != 0 ? 2 : 1;
/* 1078 */       if (this.boxHandle != 0L) GTK.gtk_widget_set_direction(this.boxHandle, dir);
/* 1079 */       if (this.labelHandle != 0L) GTK.gtk_widget_set_direction(this.labelHandle, dir);
/* 1080 */       if (this.imageHandle != 0L) GTK.gtk_widget_set_direction(this.imageHandle, dir);
/* 1081 */       if (this.arrowHandle != 0L) {
/* 1082 */         if (GTK.GTK3) {
/* 1083 */           byte[] arrowType = (this.style & 0x4000000) != 0 ? GTK.GTK_NAMED_ICON_GO_NEXT : GTK.GTK_NAMED_ICON_GO_PREVIOUS;
/* 1084 */           switch (this.style & 0x24000) {
/* 1085 */           case 16384:  GTK.gtk_image_set_from_icon_name(this.arrowHandle, arrowType, 1); break;
/* 1086 */           case 131072:  GTK.gtk_image_set_from_icon_name(this.arrowHandle, arrowType, 1);
/*      */           }
/*      */         } else {
/* 1089 */           int arrowDir = (this.style & 0x4000000) != 0 ? 3 : 2;
/* 1090 */           switch (this.style & 0x24000) {
/* 1091 */           case 16384:  GTK.gtk_arrow_set(this.arrowHandle, arrowDir, 2); break;
/* 1092 */           case 131072:  GTK.gtk_arrow_set(this.arrowHandle, arrowDir, 2);
/*      */           }
/*      */           
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSelection(boolean selected)
/*      */   {
/* 1117 */     checkWidget();
/* 1118 */     if ((this.style & 0x32) == 0) return;
/* 1119 */     OS.g_signal_handlers_block_matched(this.handle, 16, 0, 0, 0L, 0L, 8L);
/* 1120 */     GTK.gtk_toggle_button_set_active(this.handle, selected);
/* 1121 */     if ((this.style & 0x20) != 0) {
/* 1122 */       if ((selected) && (this.grayed)) {
/* 1123 */         GTK.gtk_toggle_button_set_inconsistent(this.handle, true);
/*      */       } else {
/* 1125 */         GTK.gtk_toggle_button_set_inconsistent(this.handle, false);
/*      */       }
/*      */     }
/* 1128 */     if ((this.style & 0x10) != 0) GTK.gtk_toggle_button_set_active(this.groupHandle, !selected);
/* 1129 */     OS.g_signal_handlers_unblock_matched(this.handle, 16, 0, 0, 0L, 0L, 8L);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setText(String string)
/*      */   {
/* 1167 */     checkWidget();
/* 1168 */     if (string == null) error(4);
/* 1169 */     if ((this.style & 0x4) != 0) return;
/* 1170 */     this.text = string;
/* 1171 */     char[] chars = fixMnemonic(string);
/* 1172 */     byte[] buffer = Converter.wcsToMbcs(chars, true);
/* 1173 */     GTK.gtk_label_set_text_with_mnemonic(this.labelHandle, buffer);
/* 1174 */     updateWidgetsVisibility();
/* 1175 */     _setAlignment(this.style);
/*      */     
/*      */ 
/* 1178 */     if (GTK.GTK_VERSION >= OS.VERSION(3, 22, 0)) {
/* 1179 */       setFontDescription(this.font == null ? defaultFont().handle : this.font.handle);
/*      */     }
/*      */   }
/*      */   
/*      */   private void updateWidgetsVisibility() {
/* 1184 */     if ((this.text.length() == 0) && (this.image == null)) {
/* 1185 */       GTK.gtk_widget_hide(this.boxHandle);
/* 1186 */       GTK.gtk_widget_hide(this.labelHandle);
/* 1187 */       GTK.gtk_widget_hide(this.imageHandle);
/*      */     } else {
/* 1189 */       GTK.gtk_widget_show(this.boxHandle);
/* 1190 */       if (this.text.length() == 0) {
/* 1191 */         GTK.gtk_widget_hide(this.labelHandle);
/*      */       } else
/* 1193 */         GTK.gtk_widget_show(this.labelHandle);
/* 1194 */       if (this.image == null) {
/* 1195 */         GTK.gtk_widget_hide(this.imageHandle);
/*      */       } else {
/* 1197 */         GTK.gtk_widget_show(this.imageHandle);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   void showWidget() {
/* 1203 */     super.showWidget();
/* 1204 */     if ((this.boxHandle != 0L) && (((this.text != null) && (this.text.length() != 0)) || (this.image != null))) GTK.gtk_widget_show(this.boxHandle);
/* 1205 */     if ((this.labelHandle != 0L) && (this.text != null) && (this.text.length() != 0)) GTK.gtk_widget_show(this.labelHandle);
/* 1206 */     if (this.arrowHandle != 0L) GTK.gtk_widget_show(this.arrowHandle);
/*      */   }
/*      */   
/*      */   int traversalCode(int key, GdkEventKey event)
/*      */   {
/* 1211 */     int code = super.traversalCode(key, event);
/* 1212 */     if ((this.style & 0x4) != 0) code &= 0xFFFFFFE7;
/* 1213 */     if ((this.style & 0x10) != 0) code |= 0x60;
/* 1214 */     return code;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   long windowProc(long handle, long arg0, long user_data)
/*      */   {
/* 1225 */     switch ((int)user_data) {
/*      */     case 18: 
/* 1227 */       if ((GTK.GTK_VERSION >= OS.VERSION(3, 9, 0)) && (paintHandle() == handle)) {
/* 1228 */         return gtk_draw(handle, arg0);
/*      */       }
/*      */       break;
/*      */     }
/* 1232 */     return super.windowProc(handle, arg0, user_data);
/*      */   }
/*      */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/widgets/Button.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */