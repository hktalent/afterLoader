/*     */ package org.eclipse.swt.custom;
/*     */ 
/*     */ import org.eclipse.swt.graphics.Point;
/*     */ import org.eclipse.swt.graphics.Rectangle;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.swt.widgets.Control;
/*     */ import org.eclipse.swt.widgets.Layout;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StackLayout
/*     */   extends Layout
/*     */ {
/*  77 */   public int marginWidth = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  84 */   public int marginHeight = 0;
/*     */   
/*     */ 
/*     */ 
/*     */   public Control topControl;
/*     */   
/*     */ 
/*     */ 
/*     */   protected Point computeSize(Composite composite, int wHint, int hHint, boolean flushCache)
/*     */   {
/*  94 */     Control[] children = composite.getChildren();
/*  95 */     int maxWidth = 0;
/*  96 */     int maxHeight = 0;
/*  97 */     for (int i = 0; i < children.length; i++) {
/*  98 */       Point size = children[i].computeSize(wHint, hHint, flushCache);
/*  99 */       maxWidth = Math.max(size.x, maxWidth);
/* 100 */       maxHeight = Math.max(size.y, maxHeight);
/*     */     }
/* 102 */     int width = maxWidth + 2 * this.marginWidth;
/* 103 */     int height = maxHeight + 2 * this.marginHeight;
/* 104 */     if (wHint != -1) width = wHint;
/* 105 */     if (hHint != -1) height = hHint;
/* 106 */     return new Point(width, height);
/*     */   }
/*     */   
/*     */   protected boolean flushCache(Control control)
/*     */   {
/* 111 */     return true;
/*     */   }
/*     */   
/*     */   protected void layout(Composite composite, boolean flushCache)
/*     */   {
/* 116 */     Control[] children = composite.getChildren();
/* 117 */     Rectangle rect = composite.getClientArea();
/* 118 */     rect.x += this.marginWidth;
/* 119 */     rect.y += this.marginHeight;
/* 120 */     rect.width -= 2 * this.marginWidth;
/* 121 */     rect.height -= 2 * this.marginHeight;
/* 122 */     for (int i = 0; i < children.length; i++) {
/* 123 */       children[i].setBounds(rect);
/* 124 */       children[i].setVisible(children[i] == this.topControl);
/*     */     }
/*     */   }
/*     */   
/*     */   String getName() {
/* 129 */     String string = getClass().getName();
/* 130 */     int index = string.lastIndexOf('.');
/* 131 */     if (index == -1) return string;
/* 132 */     return string.substring(index + 1, string.length());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 143 */     String string = getName() + " {";
/* 144 */     if (this.marginWidth != 0) string = string + "marginWidth=" + this.marginWidth + " ";
/* 145 */     if (this.marginHeight != 0) string = string + "marginHeight=" + this.marginHeight + " ";
/* 146 */     if (this.topControl != null) string = string + "topControl=" + this.topControl + " ";
/* 147 */     string = string.trim();
/* 148 */     string = string + "}";
/* 149 */     return string;
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/custom/StackLayout.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */