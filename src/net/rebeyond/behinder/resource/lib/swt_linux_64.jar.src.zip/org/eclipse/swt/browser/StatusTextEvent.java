/*    */ package org.eclipse.swt.browser;
/*    */ 
/*    */ import org.eclipse.swt.events.TypedEvent;
/*    */ import org.eclipse.swt.widgets.Widget;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StatusTextEvent
/*    */   extends TypedEvent
/*    */ {
/*    */   public String text;
/*    */   static final long serialVersionUID = 3258407348371600439L;
/*    */   
/*    */   public StatusTextEvent(Widget widget)
/*    */   {
/* 40 */     super(widget);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String toString()
/*    */   {
/* 51 */     String string = super.toString();
/* 52 */     return string.substring(0, string.length() - 1) + " text=" + this.text + "}";
/*    */   }
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/browser/StatusTextEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */