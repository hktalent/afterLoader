/*      */ package org.eclipse.swt.widgets;
/*      */ 
/*      */ import java.util.Arrays;
/*      */ import org.eclipse.swt.events.ModifyListener;
/*      */ import org.eclipse.swt.events.SegmentListener;
/*      */ import org.eclipse.swt.events.SelectionListener;
/*      */ import org.eclipse.swt.events.VerifyListener;
/*      */ import org.eclipse.swt.graphics.Color;
/*      */ import org.eclipse.swt.graphics.Cursor;
/*      */ import org.eclipse.swt.graphics.Font;
/*      */ import org.eclipse.swt.graphics.Point;
/*      */ import org.eclipse.swt.graphics.Rectangle;
/*      */ import org.eclipse.swt.internal.C;
/*      */ import org.eclipse.swt.internal.Converter;
/*      */ import org.eclipse.swt.internal.DPIUtil;
/*      */ import org.eclipse.swt.internal.cairo.Cairo;
/*      */ import org.eclipse.swt.internal.gtk.GDK;
/*      */ import org.eclipse.swt.internal.gtk.GTK;
/*      */ import org.eclipse.swt.internal.gtk.GdkColor;
/*      */ import org.eclipse.swt.internal.gtk.GdkEvent;
/*      */ import org.eclipse.swt.internal.gtk.GdkEventButton;
/*      */ import org.eclipse.swt.internal.gtk.GdkEventFocus;
/*      */ import org.eclipse.swt.internal.gtk.GdkEventKey;
/*      */ import org.eclipse.swt.internal.gtk.GdkRGBA;
/*      */ import org.eclipse.swt.internal.gtk.GdkRectangle;
/*      */ import org.eclipse.swt.internal.gtk.GtkBorder;
/*      */ import org.eclipse.swt.internal.gtk.OS;
/*      */ import org.eclipse.swt.internal.gtk.PangoRectangle;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class Text
/*      */   extends Scrollable
/*      */ {
/*   64 */   int tabs = 8; int lastEventTime = 0;
/*   65 */   long gdkEventKey = 0L;
/*   66 */   int fixStart = -1; int fixEnd = -1;
/*      */   
/*   68 */   String message = "";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*   74 */   static final int ITER_SIZEOF = GTK.GtkTextIter_sizeof();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*   98 */   public static final int LIMIT = Integer.MAX_VALUE;
/*   99 */   public static final String DELIMITER = "\n";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  105 */   long indexMark = 0L;
/*      */   
/*      */ 
/*      */ 
/*      */   long bufferHandle;
/*      */   
/*      */ 
/*      */ 
/*      */   long imContext;
/*      */   
/*      */ 
/*      */ 
/*      */   boolean doubleClick;
/*      */   
/*      */ 
/*      */ 
/*      */   static final char LTR_MARK = '‎';
/*      */   
/*      */ 
/*      */ 
/*      */   static final char RTL_MARK = '‏';
/*      */   
/*      */ 
/*      */ 
/*      */   int[] segments;
/*      */   
/*      */ 
/*      */   static final int SPACE_FOR_CURSOR = 1;
/*      */   
/*      */ 
/*      */   GdkRGBA background;
/*      */   
/*      */ 
/*      */   double cachedAdjustment;
/*      */   
/*      */ 
/*      */   double currentAdjustment;
/*      */   
/*      */ 
/*      */ 
/*      */   public Text(Composite parent, int style)
/*      */   {
/*  147 */     super(parent, checkStyle(style));
/*  148 */     if ((style & 0x80) != 0)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  157 */       if ((style & 0x100) != 0) {
/*  158 */         this.style |= 0x100;
/*  159 */         GTK.gtk_entry_set_icon_from_icon_name(this.handle, 1, GTK.GTK_NAMED_ICON_CLEAR);
/*  160 */         GTK.gtk_entry_set_icon_sensitive(this.handle, 1, false);
/*      */       }
/*  162 */       if ((style & 0x200) != 0) {
/*  163 */         this.style |= 0x200;
/*  164 */         GTK.gtk_entry_set_icon_from_icon_name(this.handle, 0, GTK.GTK_NAMED_ICON_FIND);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   static int checkStyle(int style) {
/*  170 */     if ((style & 0x80) != 0) {
/*  171 */       style |= 0x804;
/*  172 */       style &= 0xFFBFFFFF;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  179 */     if (((style & 0x4) != 0) && ((style & 0x2) != 0)) {
/*  180 */       style &= 0xFFFFFFFD;
/*      */     }
/*  182 */     style = checkBits(style, 16384, 16777216, 131072, 0, 0, 0);
/*  183 */     if ((style & 0x4) != 0) style &= 0xFCBF;
/*  184 */     if ((style & 0x40) != 0) {
/*  185 */       style |= 0x2;
/*  186 */       style &= 0xFEFF;
/*      */     }
/*  188 */     if ((style & 0x2) != 0) style &= 0xFFBFFFFF;
/*  189 */     if ((style & 0x6) != 0) return style;
/*  190 */     if ((style & 0x300) != 0) return style | 0x2;
/*  191 */     return style | 0x4;
/*      */   }
/*      */   
/*      */   void createHandle(int index)
/*      */   {
/*  196 */     this.state |= 0x28;
/*  197 */     if (((this.style & 0x8) != 0) && 
/*  198 */       (applyThemeBackground() == 1)) {
/*  199 */       this.state |= 0x10000;
/*      */     }
/*      */     
/*  202 */     this.fixedHandle = OS.g_object_new(this.display.gtk_fixed_get_type(), 0L);
/*  203 */     if (this.fixedHandle == 0L) error(2);
/*  204 */     GTK.gtk_widget_set_has_window(this.fixedHandle, true);
/*  205 */     if ((this.style & 0x4) != 0) {
/*  206 */       this.handle = GTK.gtk_entry_new();
/*  207 */       if (this.handle == 0L) error(2);
/*  208 */       GTK.gtk_container_add(this.fixedHandle, this.handle);
/*  209 */       GTK.gtk_editable_set_editable(this.handle, (this.style & 0x8) == 0);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  214 */       if (GTK.GTK_VERSION >= OS.VERSION(3, 20, 0)) {
/*  215 */         if ((this.style & 0x800) == 0) {
/*  216 */           GTK.gtk_entry_set_has_frame(this.handle, false);
/*  217 */           long context = GTK.gtk_widget_get_style_context(this.handle);
/*  218 */           String background = this.display.gtk_rgba_to_css_string(this.display.COLOR_LIST_BACKGROUND_RGBA);
/*  219 */           gtk_css_provider_load_from_css(context, "entry {border: solid; background: " + background + ";}");
/*  220 */           GTK.gtk_style_context_invalidate(context);
/*      */         }
/*      */       } else {
/*  223 */         GTK.gtk_entry_set_has_frame(this.handle, (this.style & 0x800) != 0);
/*      */       }
/*  225 */       GTK.gtk_entry_set_visibility(this.handle, (this.style & 0x400000) == 0);
/*  226 */       float alignment = 0.0F;
/*  227 */       if ((this.style & 0x1000000) != 0) alignment = 0.5F;
/*  228 */       if ((this.style & 0x20000) != 0) alignment = 1.0F;
/*  229 */       if (alignment > 0.0F) {
/*  230 */         GTK.gtk_entry_set_alignment(this.handle, alignment);
/*      */       }
/*      */     } else {
/*  233 */       this.scrolledHandle = GTK.gtk_scrolled_window_new(0L, 0L);
/*  234 */       if (this.scrolledHandle == 0L) error(2);
/*  235 */       this.handle = GTK.gtk_text_view_new();
/*  236 */       if (this.handle == 0L) error(2);
/*  237 */       this.bufferHandle = GTK.gtk_text_view_get_buffer(this.handle);
/*  238 */       if (this.bufferHandle == 0L) error(2);
/*  239 */       GTK.gtk_container_add(this.fixedHandle, this.scrolledHandle);
/*  240 */       GTK.gtk_container_add(this.scrolledHandle, this.handle);
/*  241 */       GTK.gtk_text_view_set_editable(this.handle, (this.style & 0x8) == 0);
/*  242 */       if ((this.style & 0x40) != 0) GTK.gtk_text_view_set_wrap_mode(this.handle, 3);
/*  243 */       int hsp = (this.style & 0x100) != 0 ? 0 : 2;
/*  244 */       int vsp = (this.style & 0x200) != 0 ? 0 : 2;
/*  245 */       GTK.gtk_scrolled_window_set_policy(this.scrolledHandle, hsp, vsp);
/*  246 */       if ((this.style & 0x800) != 0) {
/*  247 */         GTK.gtk_scrolled_window_set_shadow_type(this.scrolledHandle, 3);
/*      */       }
/*  249 */       int just = 0;
/*  250 */       if ((this.style & 0x1000000) != 0) just = 2;
/*  251 */       if ((this.style & 0x20000) != 0) just = 1;
/*  252 */       GTK.gtk_text_view_set_justification(this.handle, just);
/*      */     }
/*  254 */     if (GTK.GTK3) {
/*  255 */       this.imContext = OS.imContextLast();
/*  256 */       if ((this.style & 0x4) != 0) {
/*  257 */         GTK.gtk_entry_set_width_chars(this.handle, 6);
/*      */       }
/*      */       
/*      */ 
/*  261 */       setFontDescription(defaultFont().handle);
/*      */     }
/*      */   }
/*      */   
/*      */   int applyThemeBackground()
/*      */   {
/*  267 */     return (this.backgroundAlpha == 0) || ((this.style & 0xB00) == 0) ? 1 : 0;
/*      */   }
/*      */   
/*      */   void createWidget(int index)
/*      */   {
/*  272 */     super.createWidget(index);
/*  273 */     this.doubleClick = true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addModifyListener(ModifyListener listener)
/*      */   {
/*  296 */     checkWidget();
/*  297 */     if (listener == null) error(4);
/*  298 */     TypedListener typedListener = new TypedListener(listener);
/*  299 */     addListener(24, typedListener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addSegmentListener(SegmentListener listener)
/*      */   {
/*  337 */     checkWidget();
/*  338 */     if (listener == null) error(4);
/*  339 */     addListener(49, new TypedListener(listener));
/*  340 */     clearSegments(true);
/*  341 */     applySegments();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addSelectionListener(SelectionListener listener)
/*      */   {
/*  373 */     checkWidget();
/*  374 */     if (listener == null) error(4);
/*  375 */     TypedListener typedListener = new TypedListener(listener);
/*  376 */     addListener(13, typedListener);
/*  377 */     addListener(14, typedListener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addVerifyListener(VerifyListener listener)
/*      */   {
/*  400 */     checkWidget();
/*  401 */     if (listener == null) error(4);
/*  402 */     TypedListener typedListener = new TypedListener(listener);
/*  403 */     addListener(25, typedListener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void append(String string)
/*      */   {
/*  424 */     checkWidget();
/*  425 */     if (string == null) error(4);
/*  426 */     byte[] buffer = Converter.wcsToMbcs(string, false);
/*  427 */     clearSegments(true);
/*  428 */     if ((this.style & 0x4) != 0) {
/*  429 */       GTK.gtk_editable_insert_text(this.handle, buffer, buffer.length, new int[] { -1 });
/*  430 */       GTK.gtk_editable_set_position(this.handle, -1);
/*      */     } else {
/*  432 */       byte[] position = new byte[ITER_SIZEOF];
/*  433 */       GTK.gtk_text_buffer_get_end_iter(this.bufferHandle, position);
/*  434 */       GTK.gtk_text_buffer_insert(this.bufferHandle, position, buffer, buffer.length);
/*  435 */       GTK.gtk_text_buffer_place_cursor(this.bufferHandle, position);
/*  436 */       long mark = GTK.gtk_text_buffer_get_insert(this.bufferHandle);
/*  437 */       GTK.gtk_text_view_scroll_to_mark(this.handle, mark, 0.0D, true, 0.0D, 0.0D);
/*      */     }
/*  439 */     applySegments();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void applySegments()
/*      */   {
/*  448 */     if ((isDisposed()) || ((!hooks(49)) && (!filters(49)))) return;
/*  449 */     Event event = new Event();
/*  450 */     String string = getText();
/*  451 */     event.text = string;
/*  452 */     event.segments = this.segments;
/*  453 */     sendEvent(49, event);
/*  454 */     this.segments = event.segments;
/*  455 */     if (this.segments == null) return;
/*  456 */     int nSegments = this.segments.length;
/*  457 */     if (nSegments == 0) { return;
/*      */     }
/*  459 */     int i = 1; for (int length = string == null ? 0 : string.length(); i < nSegments; i++) {
/*  460 */       if ((event.segments[i] < event.segments[(i - 1)]) || (event.segments[i] > length)) {
/*  461 */         error(5);
/*      */       }
/*      */     }
/*  464 */     char[] segmentsChars = event.segmentsChars;
/*  465 */     char[] separator = { getOrientation() == 67108864 ? '‏' : '‎' };
/*  466 */     if ((this.style & 0x4) != 0) {
/*  467 */       OS.g_signal_handlers_block_matched(this.handle, 16, 0, 0, 0L, 0L, 6L);
/*  468 */       OS.g_signal_handlers_block_matched(this.handle, 16, 0, 0, 0L, 0L, 26L);
/*  469 */       int limit = GTK.gtk_entry_get_max_length(this.handle);
/*  470 */       if (limit != 0) GTK.gtk_entry_set_max_length(this.handle, translateOffset(limit));
/*  471 */       int[] pos = new int[1];
/*  472 */       for (int i = 0; i < nSegments; i++) {
/*  473 */         pos[0] = (this.segments[i] + i);
/*  474 */         if ((segmentsChars != null) && (segmentsChars.length > i)) {
/*  475 */           separator[0] = segmentsChars[i];
/*      */         }
/*  477 */         byte[] buffer = Converter.wcsToMbcs(separator, false);
/*  478 */         long ptr = GTK.gtk_entry_get_text(this.handle);
/*  479 */         pos[0] = ((int)OS.g_utf16_offset_to_utf8_offset(ptr, pos[0]));
/*  480 */         GTK.gtk_editable_insert_text(this.handle, buffer, buffer.length, pos);
/*      */       }
/*  482 */       OS.g_signal_handlers_unblock_matched(this.handle, 16, 0, 0, 0L, 0L, 6L);
/*  483 */       OS.g_signal_handlers_unblock_matched(this.handle, 16, 0, 0, 0L, 0L, 26L);
/*      */     } else {
/*  485 */       OS.g_signal_handlers_block_matched(this.bufferHandle, 16, 0, 0, 0L, 0L, 6L);
/*  486 */       OS.g_signal_handlers_block_matched(this.bufferHandle, 16, 0, 0, 0L, 0L, 52L);
/*  487 */       byte[] pos = new byte[ITER_SIZEOF];
/*  488 */       byte[] startIter = new byte[ITER_SIZEOF];
/*  489 */       byte[] endIter = new byte[ITER_SIZEOF];
/*  490 */       for (int i = 0; i < nSegments; i++) {
/*  491 */         GTK.gtk_text_buffer_get_bounds(this.bufferHandle, startIter, endIter);
/*  492 */         long ptr = GTK.gtk_text_buffer_get_text(this.bufferHandle, startIter, endIter, true);
/*  493 */         GTK.gtk_text_buffer_get_iter_at_offset(this.bufferHandle, pos, (int)OS.g_utf16_offset_to_utf8_offset(ptr, this.segments[i] + i));
/*  494 */         OS.g_free(ptr);
/*  495 */         if ((segmentsChars != null) && (segmentsChars.length > i)) {
/*  496 */           separator[0] = segmentsChars[i];
/*      */         }
/*  498 */         byte[] buffer = Converter.wcsToMbcs(separator, false);
/*  499 */         GTK.gtk_text_buffer_insert(this.bufferHandle, pos, buffer, buffer.length);
/*      */       }
/*  501 */       OS.g_signal_handlers_unblock_matched(this.bufferHandle, 16, 0, 0, 0L, 0L, 6L);
/*  502 */       OS.g_signal_handlers_unblock_matched(this.bufferHandle, 16, 0, 0, 0L, 0L, 52L);
/*      */     }
/*      */   }
/*      */   
/*      */   void clearSegments(boolean applyText) {
/*  507 */     if (this.segments == null) return;
/*  508 */     int nSegments = this.segments.length;
/*  509 */     if (nSegments == 0) { return;
/*      */     }
/*  511 */     if ((this.style & 0x4) != 0) {
/*  512 */       OS.g_signal_handlers_block_matched(this.handle, 16, 0, 0, 0L, 0L, 6L);
/*  513 */       if (applyText) {
/*  514 */         OS.g_signal_handlers_block_matched(this.handle, 16, 0, 0, 0L, 0L, 13L);
/*  515 */         long ptr = GTK.gtk_entry_get_text(this.handle);
/*      */         
/*  517 */         for (int i = 0; i < nSegments; i++) {
/*  518 */           int start = (int)OS.g_utf16_offset_to_utf8_offset(ptr, this.segments[i]);
/*  519 */           int end = (int)OS.g_utf16_offset_to_utf8_offset(ptr, this.segments[i] + 1);
/*  520 */           GTK.gtk_editable_delete_text(this.handle, start, end);
/*      */         }
/*  522 */         OS.g_signal_handlers_unblock_matched(this.handle, 16, 0, 0, 0L, 0L, 13L);
/*      */       }
/*  524 */       int limit = GTK.gtk_entry_get_max_length(this.handle);
/*  525 */       if (limit != 0) GTK.gtk_entry_set_max_length(this.handle, untranslateOffset(limit));
/*  526 */       OS.g_signal_handlers_unblock_matched(this.handle, 16, 0, 0, 0L, 0L, 6L);
/*  527 */     } else if (applyText) {
/*  528 */       OS.g_signal_handlers_block_matched(this.bufferHandle, 16, 0, 0, 0L, 0L, 6L);
/*  529 */       OS.g_signal_handlers_block_matched(this.bufferHandle, 16, 0, 0, 0L, 0L, 12L);
/*  530 */       byte[] start = new byte[ITER_SIZEOF];byte[] end = new byte[ITER_SIZEOF];
/*  531 */       byte[] startIter = new byte[ITER_SIZEOF];byte[] endIter = new byte[ITER_SIZEOF];
/*  532 */       for (int i = 0; i < nSegments; i++) {
/*  533 */         GTK.gtk_text_buffer_get_bounds(this.bufferHandle, startIter, endIter);
/*  534 */         long ptr = GTK.gtk_text_buffer_get_text(this.bufferHandle, startIter, endIter, true);
/*  535 */         GTK.gtk_text_buffer_get_iter_at_offset(this.bufferHandle, start, (int)OS.g_utf16_offset_to_utf8_offset(ptr, this.segments[i]));
/*  536 */         GTK.gtk_text_buffer_get_iter_at_offset(this.bufferHandle, end, (int)OS.g_utf16_offset_to_utf8_offset(ptr, this.segments[i] + 1));
/*  537 */         GTK.gtk_text_buffer_delete(this.bufferHandle, start, end);
/*  538 */         OS.g_free(ptr);
/*      */       }
/*  540 */       OS.g_signal_handlers_unblock_matched(this.bufferHandle, 16, 0, 0, 0L, 0L, 12L);
/*  541 */       OS.g_signal_handlers_unblock_matched(this.bufferHandle, 16, 0, 0, 0L, 0L, 6L);
/*      */     }
/*  543 */     this.segments = null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void clearSelection()
/*      */   {
/*  555 */     checkWidget();
/*  556 */     if ((this.style & 0x4) != 0) {
/*  557 */       int position = GTK.gtk_editable_get_position(this.handle);
/*  558 */       GTK.gtk_editable_select_region(this.handle, position, position);
/*      */     } else {
/*  560 */       byte[] position = new byte[ITER_SIZEOF];
/*  561 */       long insertMark = GTK.gtk_text_buffer_get_insert(this.bufferHandle);
/*  562 */       GTK.gtk_text_buffer_get_iter_at_mark(this.bufferHandle, position, insertMark);
/*  563 */       GTK.gtk_text_buffer_select_range(this.bufferHandle, position, position);
/*      */     }
/*      */   }
/*      */   
/*      */   Point computeSizeInPixels(int wHint, int hHint, boolean changed)
/*      */   {
/*  569 */     checkWidget();
/*  570 */     if ((wHint != -1) && (wHint < 0)) wHint = 0;
/*  571 */     if ((hHint != -1) && (hHint < 0)) hHint = 0;
/*  572 */     int[] w = new int[1];int[] h = new int[1];
/*  573 */     if ((this.style & 0x4) != 0) {
/*  574 */       GTK.gtk_widget_realize(this.handle);
/*  575 */       long layout = GTK.gtk_entry_get_layout(this.handle);
/*  576 */       OS.pango_layout_get_pixel_size(layout, w, h);
/*      */     } else {
/*  578 */       byte[] start = new byte[ITER_SIZEOF];byte[] end = new byte[ITER_SIZEOF];
/*  579 */       GTK.gtk_text_buffer_get_bounds(this.bufferHandle, start, end);
/*  580 */       long text = GTK.gtk_text_buffer_get_text(this.bufferHandle, start, end, true);
/*  581 */       long layout = GTK.gtk_widget_create_pango_layout(this.handle, text);
/*  582 */       OS.g_free(text);
/*  583 */       OS.pango_layout_set_width(layout, wHint * 1024);
/*  584 */       OS.pango_layout_get_pixel_size(layout, w, h);
/*  585 */       OS.g_object_unref(layout);
/*      */     }
/*  587 */     int width = w[0];
/*  588 */     int height = h[0];
/*  589 */     if (((this.style & 0x4) != 0) && (this.message.length() > 0)) {
/*  590 */       byte[] buffer = Converter.wcsToMbcs(this.message, true);
/*  591 */       long layout = GTK.gtk_widget_create_pango_layout(this.handle, buffer);
/*  592 */       Arrays.fill(buffer, (byte)0);
/*  593 */       OS.pango_layout_get_pixel_size(layout, w, h);
/*  594 */       OS.g_object_unref(layout);
/*  595 */       width = Math.max(width, w[0]);
/*      */     }
/*  597 */     if (width == 0) width = 64;
/*  598 */     if (height == 0) height = 64;
/*  599 */     width = wHint == -1 ? width : wHint;
/*  600 */     height = hHint == -1 ? height : hHint;
/*  601 */     Rectangle trim = computeTrimInPixels(0, 0, width, height);
/*  602 */     return new Point(trim.width, trim.height);
/*      */   }
/*      */   
/*      */   Rectangle computeTrimInPixels(int x, int y, int width, int height)
/*      */   {
/*  607 */     checkWidget();
/*  608 */     Rectangle trim = super.computeTrimInPixels(x, y, width, height);
/*  609 */     int xborder = 0;int yborder = 0;
/*  610 */     if ((this.style & 0x4) != 0) {
/*  611 */       if (GTK.GTK3) {
/*  612 */         GtkBorder tmp = new GtkBorder();
/*  613 */         long context = GTK.gtk_widget_get_style_context(this.handle);
/*  614 */         if (GTK.GTK_VERSION < OS.VERSION(3, 18, 0)) {
/*  615 */           GTK.gtk_style_context_get_padding(context, 0, tmp);
/*      */         } else {
/*  617 */           GTK.gtk_style_context_get_padding(context, GTK.gtk_widget_get_state_flags(this.handle), tmp);
/*      */         }
/*  619 */         trim.x -= tmp.left;
/*  620 */         trim.y -= tmp.top;
/*  621 */         trim.width += tmp.left + tmp.right;
/*  622 */         if ((tmp.bottom == 0) && (tmp.top == 0)) {
/*  623 */           Point widthNative = computeNativeSize(this.handle, trim.width, -1, true);
/*  624 */           trim.height = widthNative.y;
/*      */         } else {
/*  626 */           trim.height += tmp.top + tmp.bottom;
/*      */         }
/*  628 */         if ((this.style & 0x800) != 0) {
/*  629 */           if (GTK.GTK_VERSION < OS.VERSION(3, 18, 0)) {
/*  630 */             GTK.gtk_style_context_get_border(context, 0, tmp);
/*      */           } else {
/*  632 */             GTK.gtk_style_context_get_border(context, GTK.gtk_widget_get_state_flags(this.handle), tmp);
/*      */           }
/*  634 */           trim.x -= tmp.left;
/*  635 */           trim.y -= tmp.top;
/*  636 */           trim.width += tmp.left + tmp.right;
/*  637 */           trim.height += tmp.top + tmp.bottom;
/*      */         }
/*  639 */         GdkRectangle icon_area = new GdkRectangle();
/*  640 */         GTK.gtk_entry_get_icon_area(this.handle, 0, icon_area);
/*  641 */         trim.x -= icon_area.width;
/*  642 */         trim.width += icon_area.width;
/*  643 */         GTK.gtk_entry_get_icon_area(this.handle, 1, icon_area);
/*  644 */         trim.width += icon_area.width;
/*      */       } else {
/*  646 */         if ((this.style & 0x800) != 0) {
/*  647 */           Point thickness = getThickness(this.handle);
/*  648 */           xborder += thickness.x;
/*  649 */           yborder += thickness.y;
/*      */         }
/*  651 */         GtkBorder innerBorder = Display.getEntryInnerBorder(this.handle);
/*  652 */         trim.x -= innerBorder.left;
/*  653 */         trim.y -= innerBorder.top;
/*  654 */         trim.width += innerBorder.left + innerBorder.right;
/*  655 */         trim.height += innerBorder.top + innerBorder.bottom;
/*      */       }
/*      */     } else {
/*  658 */       int borderWidth = GTK.gtk_container_get_border_width(this.handle);
/*  659 */       xborder += borderWidth;
/*  660 */       yborder += borderWidth;
/*      */     }
/*  662 */     int[] property = new int[1];
/*  663 */     GTK.gtk_widget_style_get(this.handle, OS.interior_focus, property, 0L);
/*  664 */     if (property[0] == 0) {
/*  665 */       GTK.gtk_widget_style_get(this.handle, OS.focus_line_width, property, 0L);
/*  666 */       xborder += property[0];
/*  667 */       yborder += property[0];
/*      */     }
/*  669 */     trim.x -= xborder;
/*  670 */     trim.y -= yborder;
/*  671 */     trim.width += 2 * xborder;
/*  672 */     trim.height += 2 * yborder;
/*  673 */     trim.width += 1;
/*  674 */     return new Rectangle(trim.x, trim.y, trim.width, trim.height);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void copy()
/*      */   {
/*  689 */     checkWidget();
/*  690 */     if ((this.style & 0x4) != 0) {
/*  691 */       GTK.gtk_editable_copy_clipboard(this.handle);
/*      */     } else {
/*  693 */       long clipboard = GTK.gtk_clipboard_get(0L);
/*  694 */       clearSegments(true);
/*  695 */       GTK.gtk_text_buffer_copy_clipboard(this.bufferHandle, clipboard);
/*  696 */       applySegments();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void cut()
/*      */   {
/*  713 */     checkWidget();
/*  714 */     if ((this.style & 0x4) != 0) {
/*  715 */       GTK.gtk_editable_cut_clipboard(this.handle);
/*      */     } else {
/*  717 */       long clipboard = GTK.gtk_clipboard_get(0L);
/*  718 */       clearSegments(true);
/*  719 */       GTK.gtk_text_buffer_cut_clipboard(this.bufferHandle, clipboard, GTK.gtk_text_view_get_editable(this.handle));
/*  720 */       applySegments();
/*      */     }
/*      */   }
/*      */   
/*      */   char[] deprocessText(char[] text, int start, int end) {
/*  725 */     if (text == null) return new char[0];
/*  726 */     if (start < 0) start = 0;
/*  727 */     int length = text.length;
/*  728 */     if (end == -1) end = start + length;
/*  729 */     if ((this.segments != null) && (end > this.segments[0])) {
/*  730 */       int nSegments = this.segments.length;
/*  731 */       if ((nSegments > 0) && (start <= this.segments[(nSegments - 1)])) {
/*  732 */         int nLeadSegments = 0;
/*  733 */         while (start - nLeadSegments > this.segments[nLeadSegments]) nLeadSegments++;
/*  734 */         int segmentCount = nLeadSegments;
/*  735 */         for (int i = start; i < end; i++) {
/*  736 */           if ((segmentCount < nSegments) && (i - segmentCount == this.segments[segmentCount])) {
/*  737 */             segmentCount++;
/*      */           } else {
/*  739 */             text[(i - segmentCount + nLeadSegments - start)] = text[(i - start)];
/*      */           }
/*      */         }
/*  742 */         length = end - start - segmentCount + nLeadSegments;
/*      */       }
/*      */     }
/*  745 */     if ((start != 0) || (end != start + length)) {
/*  746 */       char[] newText = new char[length];
/*  747 */       System.arraycopy(text, 0, newText, 0, length);
/*  748 */       return newText;
/*      */     }
/*  750 */     return text;
/*      */   }
/*      */   
/*      */   GdkRGBA defaultBackground()
/*      */   {
/*  755 */     return this.display.getSystemColor(25).handleRGBA;
/*      */   }
/*      */   
/*      */   void deregister()
/*      */   {
/*  760 */     super.deregister();
/*  761 */     if (this.bufferHandle != 0L) this.display.removeWidget(this.bufferHandle);
/*  762 */     long imContext = imContext();
/*  763 */     if (imContext != 0L) { this.display.removeWidget(imContext);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   boolean dragDetect(int x, int y, boolean filter, boolean dragOnTimeout, boolean[] consume)
/*      */   {
/*  774 */     boolean isDraggable = GTK.GTK_VERSION < OS.VERSION(3, 14, 0) ? insideBlockSelection(x, y) : false;
/*  775 */     if ((filter) && 
/*  776 */       (isDraggable) && (super.dragDetect(x, y, filter, dragOnTimeout, consume))) {
/*  777 */       if (consume != null) consume[0] = true;
/*  778 */       return true;
/*      */     }
/*      */     
/*  781 */     return false;
/*      */   }
/*      */   
/*      */   long eventWindow()
/*      */   {
/*  786 */     return paintWindow();
/*      */   }
/*      */   
/*      */   boolean filterKey(int keyval, long event)
/*      */   {
/*  791 */     int time = GDK.gdk_event_get_time(event);
/*  792 */     if (time != this.lastEventTime) {
/*  793 */       this.lastEventTime = time;
/*  794 */       long imContext = imContext();
/*  795 */       if (imContext != 0L) {
/*  796 */         return GTK.gtk_im_context_filter_keypress(imContext, event);
/*      */       }
/*      */     }
/*  799 */     this.gdkEventKey = event;
/*  800 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void fixIM()
/*      */   {
/*  812 */     if ((this.gdkEventKey != 0L) && (this.gdkEventKey != -1L)) {
/*  813 */       long imContext = imContext();
/*  814 */       if (imContext != 0L) {
/*  815 */         GTK.gtk_im_context_filter_keypress(imContext, this.gdkEventKey);
/*  816 */         this.gdkEventKey = -1L;
/*  817 */         return;
/*      */       }
/*      */     }
/*  820 */     this.gdkEventKey = 0L;
/*      */   }
/*      */   
/*      */   GdkColor getBackgroundGdkColor()
/*      */   {
/*  825 */     assert (!GTK.GTK3) : "GTK2 code was run by GTK3";
/*  826 */     return getBaseGdkColor();
/*      */   }
/*      */   
/*      */   int getBorderWidthInPixels()
/*      */   {
/*  831 */     checkWidget();
/*  832 */     if ((this.style & 0x2) != 0) return super.getBorderWidthInPixels();
/*  833 */     if ((this.style & 0x800) != 0) {
/*  834 */       return getThickness(this.handle).x;
/*      */     }
/*  836 */     return 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getCaretLineNumber()
/*      */   {
/*  853 */     checkWidget();
/*  854 */     if ((this.style & 0x4) != 0) return 0;
/*  855 */     byte[] position = new byte[ITER_SIZEOF];
/*  856 */     long mark = GTK.gtk_text_buffer_get_insert(this.bufferHandle);
/*  857 */     GTK.gtk_text_buffer_get_iter_at_mark(this.bufferHandle, position, mark);
/*  858 */     return GTK.gtk_text_iter_get_line(position);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Point getCaretLocation()
/*      */   {
/*  873 */     checkWidget();
/*  874 */     return DPIUtil.autoScaleDown(getCaretLocationInPixels());
/*      */   }
/*      */   
/*      */   Point getCaretLocationInPixels() {
/*  878 */     checkWidget();
/*  879 */     if ((this.style & 0x4) != 0) {
/*  880 */       int index = GTK.gtk_editable_get_position(this.handle);
/*  881 */       index = GTK.gtk_entry_text_index_to_layout_index(this.handle, index);
/*  882 */       int[] offset_x = new int[1];int[] offset_y = new int[1];
/*  883 */       GTK.gtk_entry_get_layout_offsets(this.handle, offset_x, offset_y);
/*  884 */       long layout = GTK.gtk_entry_get_layout(this.handle);
/*  885 */       PangoRectangle pos = new PangoRectangle();
/*  886 */       OS.pango_layout_index_to_pos(layout, index, pos);
/*  887 */       int x = offset_x[0] + OS.PANGO_PIXELS(pos.x) - getBorderWidthInPixels();
/*  888 */       int y = offset_y[0] + OS.PANGO_PIXELS(pos.y);
/*  889 */       return new Point(x, y);
/*      */     }
/*  891 */     byte[] position = new byte[ITER_SIZEOF];
/*  892 */     long mark = GTK.gtk_text_buffer_get_insert(this.bufferHandle);
/*  893 */     GTK.gtk_text_buffer_get_iter_at_mark(this.bufferHandle, position, mark);
/*  894 */     GdkRectangle rect = new GdkRectangle();
/*  895 */     GTK.gtk_text_view_get_iter_location(this.handle, position, rect);
/*  896 */     int[] x = new int[1];
/*  897 */     int[] y = new int[1];
/*  898 */     GTK.gtk_text_view_buffer_to_window_coords(this.handle, 2, rect.x, rect.y, x, y);
/*  899 */     return new Point(x[0], y[0]);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getCaretPosition()
/*      */   {
/*  916 */     checkWidget();
/*      */     int result;
/*  918 */     int result; if ((this.style & 0x4) != 0) {
/*  919 */       long ptr = GTK.gtk_entry_get_text(this.handle);
/*  920 */       result = (int)OS.g_utf8_offset_to_utf16_offset(ptr, GTK.gtk_editable_get_position(this.handle));
/*      */     } else {
/*  922 */       byte[] position = new byte[ITER_SIZEOF];
/*  923 */       long mark = GTK.gtk_text_buffer_get_insert(this.bufferHandle);
/*  924 */       GTK.gtk_text_buffer_get_iter_at_mark(this.bufferHandle, position, mark);
/*  925 */       byte[] zero = new byte[ITER_SIZEOF];
/*  926 */       GTK.gtk_text_buffer_get_iter_at_offset(this.bufferHandle, zero, 0);
/*  927 */       long ptr = GTK.gtk_text_buffer_get_text(this.bufferHandle, zero, position, true);
/*  928 */       result = (int)OS.g_utf8_offset_to_utf16_offset(ptr, GTK.gtk_text_iter_get_offset(position));
/*  929 */       OS.g_free(ptr);
/*      */     }
/*  931 */     return untranslateOffset(result);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getCharCount()
/*      */   {
/*  945 */     checkWidget();
/*      */     int result;
/*  947 */     int result; if ((this.style & 0x4) != 0) {
/*  948 */       long ptr = GTK.gtk_entry_get_text(this.handle);
/*  949 */       result = (int)OS.g_utf16_strlen(ptr, -1L);
/*      */     } else {
/*  951 */       byte[] startIter = new byte[ITER_SIZEOF];
/*  952 */       byte[] endIter = new byte[ITER_SIZEOF];
/*  953 */       GTK.gtk_text_buffer_get_bounds(this.bufferHandle, startIter, endIter);
/*  954 */       long ptr = GTK.gtk_text_buffer_get_text(this.bufferHandle, startIter, endIter, true);
/*  955 */       result = (int)OS.g_utf16_strlen(ptr, -1L);
/*  956 */       OS.g_free(ptr);
/*      */     }
/*  958 */     return untranslateOffset(result);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getDoubleClickEnabled()
/*      */   {
/*  977 */     checkWidget();
/*  978 */     return this.doubleClick;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public char getEchoChar()
/*      */   {
/*  999 */     checkWidget();
/* 1000 */     if (((this.style & 0x4) != 0) && 
/* 1001 */       (!GTK.gtk_entry_get_visibility(this.handle))) {
/* 1002 */       return GTK.gtk_entry_get_invisible_char(this.handle);
/*      */     }
/*      */     
/* 1005 */     return '\000';
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getEditable()
/*      */   {
/* 1019 */     checkWidget();
/* 1020 */     if ((this.style & 0x4) != 0) {
/* 1021 */       return GTK.gtk_editable_get_editable(this.handle);
/*      */     }
/* 1023 */     return GTK.gtk_text_view_get_editable(this.handle);
/*      */   }
/*      */   
/*      */   GdkColor getForegroundGdkColor()
/*      */   {
/* 1028 */     assert (!GTK.GTK3) : "GTK2 code was run by GTK3";
/* 1029 */     return getTextColor();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getLineCount()
/*      */   {
/* 1043 */     checkWidget();
/* 1044 */     if ((this.style & 0x4) != 0) return 1;
/* 1045 */     return GTK.gtk_text_buffer_get_line_count(this.bufferHandle);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getLineDelimiter()
/*      */   {
/* 1061 */     checkWidget();
/* 1062 */     return "\n";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getLineHeight()
/*      */   {
/* 1076 */     checkWidget();
/* 1077 */     return fontHeight(getFontDescription(), this.handle);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getMessage()
/*      */   {
/* 1097 */     checkWidget();
/* 1098 */     return this.message;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getOrientation()
/*      */   {
/* 1116 */     return super.getOrientation();
/*      */   }
/*      */   
/*      */   int getPosition(Point point) {
/* 1120 */     checkWidget();
/* 1121 */     if (point == null) error(4);
/* 1122 */     int position = -1;
/* 1123 */     if ((this.style & 0x4) != 0) {
/* 1124 */       int[] index = new int[1];
/* 1125 */       int[] trailing = new int[1];
/* 1126 */       long layout = GTK.gtk_entry_get_layout(this.handle);
/* 1127 */       OS.pango_layout_xy_to_index(layout, point.x * 1024, point.y * 1024, index, trailing);
/* 1128 */       long ptr = OS.pango_layout_get_text(layout);
/* 1129 */       position = (int)OS.g_utf16_pointer_to_offset(ptr, ptr + index[0]) + trailing[0];
/*      */     } else {
/* 1131 */       byte[] p = new byte[ITER_SIZEOF];
/* 1132 */       GTK.gtk_text_view_get_iter_at_location(this.handle, p, point.x, point.y);
/* 1133 */       byte[] zero = new byte[ITER_SIZEOF];
/* 1134 */       GTK.gtk_text_buffer_get_iter_at_offset(this.bufferHandle, zero, 0);
/* 1135 */       long ptr = GTK.gtk_text_buffer_get_text(this.bufferHandle, zero, p, true);
/* 1136 */       position = (int)OS.g_utf8_offset_to_utf16_offset(ptr, GTK.gtk_text_iter_get_offset(p));
/* 1137 */       OS.g_free(ptr);
/*      */     }
/* 1139 */     return untranslateOffset(position);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Point getSelection()
/*      */   {
/* 1161 */     checkWidget();
/*      */     Point selection;
/* 1163 */     Point selection; if ((this.style & 0x4) != 0) {
/* 1164 */       int[] start = new int[1];
/* 1165 */       int[] end = new int[1];
/* 1166 */       GTK.gtk_editable_get_selection_bounds(this.handle, start, end);
/* 1167 */       long ptr = GTK.gtk_entry_get_text(this.handle);
/* 1168 */       start[0] = ((int)OS.g_utf8_offset_to_utf16_offset(ptr, start[0]));
/* 1169 */       end[0] = ((int)OS.g_utf8_offset_to_utf16_offset(ptr, end[0]));
/* 1170 */       selection = new Point(start[0], end[0]);
/*      */     } else {
/* 1172 */       byte[] startIter = new byte[ITER_SIZEOF];
/* 1173 */       byte[] endIter = new byte[ITER_SIZEOF];
/* 1174 */       GTK.gtk_text_buffer_get_selection_bounds(this.bufferHandle, startIter, endIter);
/* 1175 */       byte[] zero = new byte[ITER_SIZEOF];
/* 1176 */       GTK.gtk_text_buffer_get_iter_at_offset(this.bufferHandle, zero, 0);
/* 1177 */       long ptr = GTK.gtk_text_buffer_get_text(this.bufferHandle, zero, endIter, true);
/* 1178 */       int start = (int)OS.g_utf8_offset_to_utf16_offset(ptr, GTK.gtk_text_iter_get_offset(startIter));
/* 1179 */       int end = (int)OS.g_utf8_offset_to_utf16_offset(ptr, GTK.gtk_text_iter_get_offset(endIter));
/* 1180 */       OS.g_free(ptr);
/* 1181 */       selection = new Point(start, end);
/*      */     }
/* 1183 */     selection.x = untranslateOffset(selection.x);
/* 1184 */     selection.y = untranslateOffset(selection.y);
/* 1185 */     return selection;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getSelectionCount()
/*      */   {
/* 1199 */     checkWidget();
/* 1200 */     Point selection = getSelection();
/* 1201 */     return Math.abs(selection.y - selection.x);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getSelectionText()
/*      */   {
/* 1215 */     checkWidget();
/* 1216 */     Point selection = getSelection();
/* 1217 */     return getText().substring(selection.x, selection.y);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getTabs()
/*      */   {
/* 1236 */     checkWidget();
/* 1237 */     return this.tabs;
/*      */   }
/*      */   
/*      */   int getTabWidth(int tabs) {
/* 1241 */     byte[] buffer = Converter.wcsToMbcs(" ", true);
/* 1242 */     long layout = GTK.gtk_widget_create_pango_layout(this.handle, buffer);
/* 1243 */     int[] width = new int[1];
/* 1244 */     int[] height = new int[1];
/* 1245 */     OS.pango_layout_get_size(layout, width, height);
/* 1246 */     OS.g_object_unref(layout);
/* 1247 */     return width[0] * tabs;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getText()
/*      */   {
/* 1265 */     return new String(getTextChars());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getText(int start, int end)
/*      */   {
/* 1287 */     checkWidget();
/* 1288 */     if ((start > end) || (0 > end)) return "";
/* 1289 */     String str = getText();
/* 1290 */     int length = str.length();
/* 1291 */     end = Math.min(end, length - 1);
/* 1292 */     if (start > end) return "";
/* 1293 */     start = Math.max(0, start);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1299 */     return str.substring(start, end + 1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public char[] getTextChars()
/*      */   {
/* 1328 */     checkWidget();
/*      */     long address;
/* 1330 */     long address; if ((this.style & 0x4) != 0) {
/* 1331 */       address = GTK.gtk_entry_get_text(this.handle);
/*      */     } else {
/* 1333 */       byte[] start = new byte[ITER_SIZEOF];
/* 1334 */       byte[] end = new byte[ITER_SIZEOF];
/* 1335 */       GTK.gtk_text_buffer_get_bounds(this.bufferHandle, start, end);
/* 1336 */       address = GTK.gtk_text_buffer_get_text(this.bufferHandle, start, end, true);
/*      */     }
/* 1338 */     if (address == 0L) return new char[0];
/* 1339 */     int length = C.strlen(address);
/* 1340 */     byte[] buffer = new byte[length];
/* 1341 */     C.memmove(buffer, address, length);
/* 1342 */     if ((this.style & 0x2) != 0) { OS.g_free(address);
/*      */     }
/* 1344 */     char[] result = Converter.mbcsToWcs(buffer);
/* 1345 */     Arrays.fill(buffer, (byte)0);
/* 1346 */     if (this.segments != null) {
/* 1347 */       result = deprocessText(result, 0, -1);
/*      */     }
/* 1349 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getTextLimit()
/*      */   {
/* 1369 */     checkWidget();
/* 1370 */     if ((this.style & 0x2) != 0) return LIMIT;
/* 1371 */     int limit = GTK.gtk_entry_get_max_length(this.handle);
/* 1372 */     return limit == 0 ? 65535 : untranslateOffset(limit);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getTopIndex()
/*      */   {
/* 1390 */     checkWidget();
/* 1391 */     if ((this.style & 0x4) != 0) return 0;
/* 1392 */     byte[] position = new byte[ITER_SIZEOF];
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1406 */     if (GTK.GTK3) {
/* 1407 */       long vAdjustment = GTK.gtk_scrollable_get_vadjustment(this.handle);
/* 1408 */       this.currentAdjustment = GTK.gtk_adjustment_get_value(vAdjustment);
/* 1409 */       if (this.cachedAdjustment == this.currentAdjustment)
/*      */       {
/* 1411 */         if (this.indexMark != 0L) {
/* 1412 */           GTK.gtk_text_buffer_get_iter_at_mark(this.bufferHandle, position, this.indexMark);
/* 1413 */           return GTK.gtk_text_iter_get_line(position);
/*      */         }
/*      */       }
/*      */     }
/* 1417 */     GdkRectangle rect = new GdkRectangle();
/* 1418 */     GTK.gtk_text_view_get_visible_rect(this.handle, rect);
/* 1419 */     GTK.gtk_text_view_get_line_at_y(this.handle, position, rect.y, null);
/* 1420 */     return GTK.gtk_text_iter_get_line(position);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getTopPixel()
/*      */   {
/* 1444 */     checkWidget();
/* 1445 */     return DPIUtil.autoScaleDown(getTopPixelInPixels());
/*      */   }
/*      */   
/*      */   int getTopPixelInPixels() {
/* 1449 */     checkWidget();
/* 1450 */     if ((this.style & 0x4) != 0) return 0;
/* 1451 */     byte[] position = new byte[ITER_SIZEOF];
/* 1452 */     GdkRectangle rect = new GdkRectangle();
/* 1453 */     GTK.gtk_text_view_get_visible_rect(this.handle, rect);
/* 1454 */     int[] lineTop = new int[1];
/* 1455 */     GTK.gtk_text_view_get_line_at_y(this.handle, position, rect.y, lineTop);
/* 1456 */     return lineTop[0];
/*      */   }
/*      */   
/*      */   long gtk_activate(long widget)
/*      */   {
/* 1461 */     sendSelectionEvent(14);
/* 1462 */     return 0L;
/*      */   }
/*      */   
/*      */ 
/*      */   long gtk_button_press_event(long widget, long event)
/*      */   {
/* 1468 */     long result = super.gtk_button_press_event(widget, event);
/* 1469 */     if (result != 0L) return result;
/* 1470 */     GdkEventButton gdkEvent = new GdkEventButton();
/* 1471 */     OS.memmove(gdkEvent, event, GdkEventButton.sizeof);
/* 1472 */     if (!this.doubleClick) {
/* 1473 */       switch (gdkEvent.type) {
/*      */       case 5: 
/*      */       case 6: 
/* 1476 */         return 1L;
/*      */       }
/*      */     }
/* 1479 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   long gtk_changed(long widget)
/*      */   {
/* 1491 */     boolean keyPress = false;
/* 1492 */     long eventPtr = GTK.gtk_get_current_event();
/* 1493 */     if (eventPtr != 0L) {
/* 1494 */       GdkEventKey gdkEvent = new GdkEventKey();
/* 1495 */       OS.memmove(gdkEvent, eventPtr, GdkEventKey.sizeof);
/* 1496 */       switch (gdkEvent.type) {
/*      */       case 8: 
/* 1498 */         keyPress = true;
/*      */       }
/*      */       
/* 1501 */       GDK.gdk_event_free(eventPtr);
/*      */     }
/* 1503 */     if (keyPress) {
/* 1504 */       postEvent(24);
/*      */     } else {
/* 1506 */       sendEvent(24);
/*      */     }
/* 1508 */     if (((this.style & 0x80) != 0) && 
/* 1509 */       ((this.style & 0x100) != 0)) {
/* 1510 */       long ptr = GTK.gtk_entry_get_text(this.handle);
/* 1511 */       GTK.gtk_entry_set_icon_sensitive(this.handle, 1, OS.g_utf16_strlen(ptr, -1L) > 0L);
/*      */     }
/*      */     
/* 1514 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_commit(long imContext, long text)
/*      */   {
/* 1519 */     if (text == 0L) return 0L;
/* 1520 */     if (((this.style & 0x4) != 0) && 
/* 1521 */       (!GTK.gtk_editable_get_editable(this.handle))) { return 0L;
/*      */     }
/* 1523 */     int length = C.strlen(text);
/* 1524 */     if (length == 0) return 0L;
/* 1525 */     byte[] buffer = new byte[length];
/* 1526 */     C.memmove(buffer, text, length);
/* 1527 */     char[] chars = Converter.mbcsToWcs(buffer);
/* 1528 */     Arrays.fill(buffer, (byte)0);
/* 1529 */     char[] newChars = sendIMKeyEvent(1, null, chars);
/* 1530 */     if (newChars == null) { return 0L;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1538 */     this.fixStart = (this.fixEnd = -1);
/* 1539 */     OS.g_signal_handlers_block_matched(imContext, 16, 0, 0, 0L, 0L, 9L);
/* 1540 */     int id = OS.g_signal_lookup(OS.commit, GTK.gtk_im_context_get_type());
/* 1541 */     int mask = 17;
/* 1542 */     OS.g_signal_handlers_unblock_matched(imContext, mask, id, 0, 0L, 0L, this.handle);
/* 1543 */     if (newChars == chars) {
/* 1544 */       OS.g_signal_emit_by_name(imContext, OS.commit, text);
/*      */     } else {
/* 1546 */       buffer = Converter.wcsToMbcs(newChars, true);
/* 1547 */       OS.g_signal_emit_by_name(imContext, OS.commit, buffer);
/* 1548 */       Arrays.fill(buffer, (byte)0);
/*      */     }
/* 1550 */     OS.g_signal_handlers_unblock_matched(imContext, 16, 0, 0, 0L, 0L, 9L);
/* 1551 */     OS.g_signal_handlers_block_matched(imContext, mask, id, 0, 0L, 0L, this.handle);
/* 1552 */     if (((this.style & 0x4) != 0) && 
/* 1553 */       (this.fixStart != -1) && (this.fixEnd != -1)) {
/* 1554 */       GTK.gtk_editable_set_position(this.handle, this.fixStart);
/* 1555 */       GTK.gtk_editable_select_region(this.handle, this.fixStart, this.fixEnd);
/*      */     }
/*      */     
/* 1558 */     this.fixStart = (this.fixEnd = -1);
/* 1559 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_delete_range(long widget, long iter1, long iter2)
/*      */   {
/* 1564 */     if ((!hooks(25)) && (!filters(25))) return 0L;
/* 1565 */     byte[] startIter = new byte[ITER_SIZEOF];
/* 1566 */     byte[] endIter = new byte[ITER_SIZEOF];
/* 1567 */     C.memmove(startIter, iter1, startIter.length);
/* 1568 */     C.memmove(endIter, iter2, endIter.length);
/* 1569 */     int start = GTK.gtk_text_iter_get_offset(startIter);
/* 1570 */     int end = GTK.gtk_text_iter_get_offset(endIter);
/* 1571 */     byte[] zero = new byte[ITER_SIZEOF];
/* 1572 */     GTK.gtk_text_buffer_get_iter_at_offset(this.bufferHandle, zero, 0);
/* 1573 */     long ptr = GTK.gtk_text_buffer_get_text(this.bufferHandle, zero, endIter, true);
/* 1574 */     start = (int)OS.g_utf8_offset_to_utf16_offset(ptr, start);
/* 1575 */     end = (int)OS.g_utf8_offset_to_utf16_offset(ptr, end);
/* 1576 */     OS.g_free(ptr);
/* 1577 */     String newText = verifyText("", start, end);
/* 1578 */     if (newText == null)
/*      */     {
/* 1580 */       GTK.gtk_text_buffer_get_selection_bounds(this.bufferHandle, startIter, endIter);
/* 1581 */       start = GTK.gtk_text_iter_get_offset(startIter);
/* 1582 */       end = GTK.gtk_text_iter_get_offset(endIter);
/* 1583 */       if (start != end) {
/* 1584 */         this.fixStart = start;
/* 1585 */         this.fixEnd = end;
/*      */       }
/* 1587 */       OS.g_signal_stop_emission_by_name(this.bufferHandle, OS.delete_range);
/*      */     }
/* 1589 */     else if (newText.length() > 0) {
/* 1590 */       byte[] buffer = Converter.wcsToMbcs(newText, false);
/* 1591 */       OS.g_signal_handlers_block_matched(this.bufferHandle, 16, 0, 0, 0L, 0L, 6L);
/* 1592 */       OS.g_signal_handlers_block_matched(this.bufferHandle, 16, 0, 0, 0L, 0L, 12L);
/* 1593 */       GTK.gtk_text_buffer_delete(this.bufferHandle, startIter, endIter);
/* 1594 */       OS.g_signal_handlers_unblock_matched(this.bufferHandle, 16, 0, 0, 0L, 0L, 12L);
/* 1595 */       OS.g_signal_handlers_unblock_matched(this.bufferHandle, 16, 0, 0, 0L, 0L, 6L);
/* 1596 */       OS.g_signal_handlers_block_matched(this.bufferHandle, 16, 0, 0, 0L, 0L, 52L);
/* 1597 */       GTK.gtk_text_buffer_insert(this.bufferHandle, startIter, buffer, buffer.length);
/* 1598 */       OS.g_signal_handlers_unblock_matched(this.bufferHandle, 16, 0, 0, 0L, 0L, 52L);
/* 1599 */       OS.g_signal_stop_emission_by_name(this.bufferHandle, OS.delete_range);
/* 1600 */       Arrays.fill(buffer, (byte)0);
/*      */     }
/*      */     
/* 1603 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_delete_text(long widget, long start_pos, long end_pos)
/*      */   {
/* 1608 */     if ((!hooks(25)) && (!filters(25))) return 0L;
/* 1609 */     long ptr = GTK.gtk_entry_get_text(this.handle);
/* 1610 */     if (end_pos == -1L) end_pos = OS.g_utf8_strlen(ptr, -1L);
/* 1611 */     int start = (int)OS.g_utf8_offset_to_utf16_offset(ptr, start_pos);
/* 1612 */     int end = (int)OS.g_utf8_offset_to_utf16_offset(ptr, end_pos);
/* 1613 */     String newText = verifyText("", start, end);
/* 1614 */     if (newText == null)
/*      */     {
/* 1616 */       int[] newStart = new int[1];int[] newEnd = new int[1];
/* 1617 */       GTK.gtk_editable_get_selection_bounds(this.handle, newStart, newEnd);
/* 1618 */       if (newStart[0] != newEnd[0]) {
/* 1619 */         this.fixStart = newStart[0];
/* 1620 */         this.fixEnd = newEnd[0];
/*      */       }
/* 1622 */       OS.g_signal_stop_emission_by_name(this.handle, OS.delete_text);
/*      */     }
/* 1624 */     else if (newText.length() > 0) {
/* 1625 */       int[] pos = new int[1];
/* 1626 */       pos[0] = ((int)end_pos);
/* 1627 */       byte[] buffer = Converter.wcsToMbcs(newText, false);
/* 1628 */       OS.g_signal_handlers_block_matched(this.handle, 16, 0, 0, 0L, 0L, 6L);
/* 1629 */       OS.g_signal_handlers_block_matched(this.handle, 16, 0, 0, 0L, 0L, 26L);
/* 1630 */       GTK.gtk_editable_insert_text(this.handle, buffer, buffer.length, pos);
/* 1631 */       OS.g_signal_handlers_unblock_matched(this.handle, 16, 0, 0, 0L, 0L, 26L);
/* 1632 */       OS.g_signal_handlers_unblock_matched(this.handle, 16, 0, 0, 0L, 0L, 6L);
/* 1633 */       GTK.gtk_editable_set_position(this.handle, pos[0]);
/* 1634 */       Arrays.fill(buffer, (byte)0);
/*      */     }
/*      */     
/* 1637 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_event_after(long widget, long gdkEvent)
/*      */   {
/* 1642 */     if (this.cursor != null) { setCursor(this.cursor.handle);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1649 */     if (((this.style & 0x4) != 0) && (this.display.entrySelectOnFocus)) {
/* 1650 */       GdkEvent event = new GdkEvent();
/* 1651 */       OS.memmove(event, gdkEvent, GdkEvent.sizeof);
/* 1652 */       switch (event.type) {
/*      */       case 12: 
/* 1654 */         GdkEventFocus gdkEventFocus = new GdkEventFocus();
/* 1655 */         OS.memmove(gdkEventFocus, gdkEvent, GdkEventFocus.sizeof);
/* 1656 */         if (gdkEventFocus.in == 0) {
/* 1657 */           long settings = GTK.gtk_settings_get_default();
/* 1658 */           OS.g_object_set(settings, GTK.gtk_entry_select_on_focus, true, 0L);
/*      */         }
/*      */         break;
/*      */       }
/*      */     }
/* 1663 */     return super.gtk_event_after(widget, gdkEvent);
/*      */   }
/*      */   
/*      */   void drawMessage(long cr) {
/* 1667 */     if (GTK.GTK_VERSION >= OS.VERSION(3, 2, 0)) return;
/* 1668 */     if (((this.style & 0x4) != 0) && (this.message.length() > 0)) {
/* 1669 */       long str = GTK.gtk_entry_get_text(this.handle);
/* 1670 */       if ((!GTK.gtk_widget_has_focus(this.handle)) && (C.strlen(str) == 0)) {
/* 1671 */         long window = paintWindow();
/* 1672 */         int[] w = new int[1];int[] h = new int[1];
/* 1673 */         gdk_window_get_size(window, w, h);
/* 1674 */         GtkBorder innerBorder = Display.getEntryInnerBorder(this.handle);
/* 1675 */         int width = w[0] - innerBorder.left - innerBorder.right;
/* 1676 */         int height = h[0] - innerBorder.top - innerBorder.bottom;
/* 1677 */         long context = GTK.gtk_widget_get_pango_context(this.handle);
/* 1678 */         long lang = OS.pango_context_get_language(context);
/* 1679 */         long metrics = OS.pango_context_get_metrics(context, getFontDescription(), lang);
/* 1680 */         int ascent = OS.PANGO_PIXELS(OS.pango_font_metrics_get_ascent(metrics));
/* 1681 */         int descent = OS.PANGO_PIXELS(OS.pango_font_metrics_get_descent(metrics));
/* 1682 */         OS.pango_font_metrics_unref(metrics);
/* 1683 */         byte[] buffer = Converter.wcsToMbcs(this.message, true);
/* 1684 */         long layout = GTK.gtk_widget_create_pango_layout(this.handle, buffer);
/* 1685 */         long line = OS.pango_layout_get_line(layout, 0);
/* 1686 */         PangoRectangle rect = new PangoRectangle();
/* 1687 */         OS.pango_layout_line_get_extents(line, null, rect);
/* 1688 */         rect.y = OS.PANGO_PIXELS(rect.y);
/* 1689 */         rect.height = OS.PANGO_PIXELS(rect.height);
/* 1690 */         rect.width = OS.PANGO_PIXELS(rect.width);
/* 1691 */         int y = (height - ascent - descent) / 2 + ascent + rect.y;
/* 1692 */         if (rect.height > height) {
/* 1693 */           y = (height - rect.height) / 2;
/* 1694 */         } else if (y < 0) {
/* 1695 */           y = 0;
/* 1696 */         } else if (y + rect.height > height) {
/* 1697 */           y = height - rect.height;
/*      */         }
/* 1699 */         y += innerBorder.top;
/* 1700 */         int x = innerBorder.left;
/* 1701 */         boolean rtl = (this.style & 0x4000000) != 0;
/* 1702 */         int alignment = this.style & 0x1024000;
/* 1703 */         switch (alignment) {
/* 1704 */         case 16384:  x = rtl ? width - rect.width : innerBorder.left; break;
/* 1705 */         case 16777216:  x = (width - rect.width) / 2; break;
/* 1706 */         case 131072:  x = rtl ? innerBorder.left : width - rect.width;
/*      */         }
/* 1708 */         GdkColor textColor = new GdkColor();
/* 1709 */         GdkColor baseColor = new GdkColor();
/* 1710 */         if (GTK.GTK3) {
/* 1711 */           long styleContext = GTK.gtk_widget_get_style_context(this.handle);
/*      */           
/* 1713 */           GdkRGBA textRGBA = this.display.styleContextGetColor(styleContext, 8);
/* 1714 */           Point thickness = getThickness(this.handle);
/* 1715 */           x += thickness.x;
/* 1716 */           y += thickness.y;
/* 1717 */           long cairo = cr != 0L ? cr : GDK.gdk_cairo_create(window);
/* 1718 */           Cairo.cairo_set_source_rgba(cairo, textRGBA.red, textRGBA.green, textRGBA.blue, textRGBA.alpha);
/*      */         } else {
/* 1720 */           long style = GTK.gtk_widget_get_style(this.handle);
/* 1721 */           GTK.gtk_style_get_text(style, 4, textColor);
/* 1722 */           GTK.gtk_style_get_base(style, 0, baseColor);
/* 1723 */           long cairo = cr != 0L ? cr : GDK.gdk_cairo_create(window);
/* 1724 */           Cairo.cairo_set_source_rgba_compatibility(cairo, textColor);
/* 1725 */           Cairo.cairo_move_to(cairo, x, y);
/* 1726 */           OS.pango_cairo_show_layout(cairo, layout);
/* 1727 */           if (cr != cairo) Cairo.cairo_destroy(cairo);
/*      */         }
/* 1729 */         OS.g_object_unref(layout);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   long gtk_draw(long widget, long cairo)
/*      */   {
/* 1736 */     if ((this.state & 0x40) != 0) return 0L;
/* 1737 */     long result = super.gtk_draw(widget, cairo);
/* 1738 */     drawMessage(cairo);
/* 1739 */     return result;
/*      */   }
/*      */   
/*      */   long gtk_expose_event(long widget, long event)
/*      */   {
/* 1744 */     if ((this.state & 0x40) != 0) return 0L;
/* 1745 */     long result = super.gtk_expose_event(widget, event);
/* 1746 */     drawMessage(0L);
/* 1747 */     return result;
/*      */   }
/*      */   
/*      */   long gtk_focus_out_event(long widget, long event)
/*      */   {
/* 1752 */     fixIM();
/* 1753 */     return super.gtk_focus_out_event(widget, event);
/*      */   }
/*      */   
/*      */   long gtk_grab_focus(long widget)
/*      */   {
/* 1758 */     long result = super.gtk_grab_focus(widget);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1766 */     if (((this.style & 0x4) != 0) && (this.display.entrySelectOnFocus)) {
/* 1767 */       long settings = GTK.gtk_settings_get_default();
/* 1768 */       OS.g_object_set(settings, GTK.gtk_entry_select_on_focus, false, 0L);
/*      */     }
/* 1770 */     return result;
/*      */   }
/*      */   
/*      */   long gtk_icon_release(long widget, long icon_pos, long event)
/*      */   {
/* 1775 */     Event e = new Event();
/* 1776 */     if (icon_pos == 0L) {
/* 1777 */       e.detail = 512;
/*      */     } else {
/* 1779 */       e.detail = 256;
/* 1780 */       GTK.gtk_editable_delete_text(this.handle, 0, -1);
/*      */     }
/* 1782 */     sendSelectionEvent(14, e, false);
/* 1783 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_insert_text(long widget, long new_text, long new_text_length, long position)
/*      */   {
/* 1788 */     if ((!hooks(25)) && (!filters(25))) return 0L;
/* 1789 */     if ((new_text == 0L) || (new_text_length == 0L)) return 0L;
/* 1790 */     byte[] buffer = new byte[(int)new_text_length];
/* 1791 */     C.memmove(buffer, new_text, buffer.length);
/* 1792 */     String oldText = new String(Converter.mbcsToWcs(buffer));
/* 1793 */     int[] pos = new int[1];
/* 1794 */     C.memmove(pos, position, 4L);
/* 1795 */     long ptr = GTK.gtk_entry_get_text(this.handle);
/* 1796 */     if (pos[0] == -1) { pos[0] = ((int)OS.g_utf8_strlen(ptr, -1L));
/*      */     }
/* 1798 */     int start = pos[0];int end = pos[0];
/* 1799 */     if ((this.fixStart != -1) && (this.fixEnd != -1)) {
/* 1800 */       start = pos[0] = this.fixStart;
/* 1801 */       end = this.fixEnd;
/* 1802 */       this.fixStart = (this.fixEnd = -1);
/*      */     }
/* 1804 */     start = (int)OS.g_utf8_offset_to_utf16_offset(ptr, start);
/* 1805 */     end = (int)OS.g_utf8_offset_to_utf16_offset(ptr, end);
/* 1806 */     String newText = verifyText(oldText, start, end);
/* 1807 */     if ((newText != oldText) && (this.handle != 0L)) {
/* 1808 */       int[] newStart = new int[1];int[] newEnd = new int[1];
/* 1809 */       GTK.gtk_editable_get_selection_bounds(this.handle, newStart, newEnd);
/* 1810 */       if (newText != null) {
/* 1811 */         if (newStart[0] != newEnd[0]) {
/* 1812 */           OS.g_signal_handlers_block_matched(this.handle, 16, 0, 0, 0L, 0L, 13L);
/* 1813 */           OS.g_signal_handlers_block_matched(this.handle, 16, 0, 0, 0L, 0L, 6L);
/* 1814 */           GTK.gtk_editable_delete_selection(this.handle);
/* 1815 */           OS.g_signal_handlers_unblock_matched(this.handle, 16, 0, 0, 0L, 0L, 13L);
/* 1816 */           OS.g_signal_handlers_unblock_matched(this.handle, 16, 0, 0, 0L, 0L, 6L);
/*      */         }
/* 1818 */         byte[] buffer3 = Converter.wcsToMbcs(newText, false);
/* 1819 */         OS.g_signal_handlers_block_matched(this.handle, 16, 0, 0, 0L, 0L, 26L);
/* 1820 */         GTK.gtk_editable_insert_text(this.handle, buffer3, buffer3.length, pos);
/* 1821 */         OS.g_signal_handlers_unblock_matched(this.handle, 16, 0, 0, 0L, 0L, 26L);
/* 1822 */         newStart[0] = (newEnd[0] = pos[0]);
/*      */       }
/* 1824 */       pos[0] = newEnd[0];
/* 1825 */       if (newStart[0] != newEnd[0]) {
/* 1826 */         this.fixStart = newStart[0];
/* 1827 */         this.fixEnd = newEnd[0];
/*      */       }
/* 1829 */       C.memmove(position, pos, 4L);
/* 1830 */       OS.g_signal_stop_emission_by_name(this.handle, OS.insert_text);
/*      */     }
/* 1832 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_key_press_event(long widget, long event)
/*      */   {
/* 1837 */     boolean handleSegments = false;boolean segmentsCleared = false;
/* 1838 */     if ((hooks(49)) || (filters(49))) {
/* 1839 */       GdkEventKey gdkEvent = new GdkEventKey();
/* 1840 */       OS.memmove(gdkEvent, event, GdkEventKey.sizeof);
/* 1841 */       if ((gdkEvent.length > 0) && ((gdkEvent.state & 0xC) == 0)) {
/* 1842 */         handleSegments = true;
/* 1843 */         if (this.segments != null) {
/* 1844 */           clearSegments(true);
/* 1845 */           segmentsCleared = true;
/*      */         }
/*      */       }
/*      */     }
/* 1849 */     long result = super.gtk_key_press_event(widget, event);
/* 1850 */     if (result != 0L) fixIM();
/* 1851 */     if (this.gdkEventKey == -1L) result = 1L;
/* 1852 */     this.gdkEventKey = 0L;
/* 1853 */     if ((handleSegments) && ((result != 0L) || (segmentsCleared))) {
/* 1854 */       applySegments();
/*      */     }
/* 1856 */     return result;
/*      */   }
/*      */   
/*      */   long gtk_populate_popup(long widget, long menu)
/*      */   {
/* 1861 */     if ((this.style & 0x4000000) != 0) {
/* 1862 */       GTK.gtk_widget_set_direction(menu, 2);
/* 1863 */       GTK.gtk_container_forall(menu, this.display.setDirectionProc, 2L);
/*      */     }
/* 1865 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_text_buffer_insert_text(long widget, long iter, long text, long length)
/*      */   {
/* 1870 */     if ((!hooks(25)) && (!filters(25))) return 0L;
/* 1871 */     byte[] position = new byte[ITER_SIZEOF];
/* 1872 */     C.memmove(position, iter, position.length);
/*      */     
/* 1874 */     int start = GTK.gtk_text_iter_get_offset(position);int end = start;
/* 1875 */     if ((this.fixStart != -1) && (this.fixEnd != -1)) {
/* 1876 */       start = this.fixStart;
/* 1877 */       end = this.fixEnd;
/* 1878 */       this.fixStart = (this.fixEnd = -1);
/*      */     }
/* 1880 */     byte[] zero = new byte[ITER_SIZEOF];
/* 1881 */     GTK.gtk_text_buffer_get_iter_at_offset(this.bufferHandle, zero, 0);
/* 1882 */     long ptr = GTK.gtk_text_buffer_get_text(this.bufferHandle, zero, position, true);
/* 1883 */     start = (int)OS.g_utf8_offset_to_utf16_offset(ptr, start);
/* 1884 */     end = (int)OS.g_utf8_offset_to_utf16_offset(ptr, end);
/* 1885 */     OS.g_free(ptr);
/* 1886 */     byte[] buffer = new byte[(int)length];
/* 1887 */     C.memmove(buffer, text, buffer.length);
/* 1888 */     String oldText = new String(Converter.mbcsToWcs(buffer));
/* 1889 */     String newText = verifyText(oldText, start, end);
/* 1890 */     if (newText == null) {
/* 1891 */       OS.g_signal_stop_emission_by_name(this.bufferHandle, OS.insert_text);
/*      */     }
/* 1893 */     else if (newText != oldText) {
/* 1894 */       byte[] buffer1 = Converter.wcsToMbcs(newText, false);
/* 1895 */       OS.g_signal_handlers_block_matched(this.bufferHandle, 16, 0, 0, 0L, 0L, 52L);
/* 1896 */       GTK.gtk_text_buffer_insert(this.bufferHandle, iter, buffer1, buffer1.length);
/* 1897 */       OS.g_signal_handlers_unblock_matched(this.bufferHandle, 16, 0, 0, 0L, 0L, 52L);
/* 1898 */       OS.g_signal_stop_emission_by_name(this.bufferHandle, OS.insert_text);
/*      */     }
/*      */     
/* 1901 */     return 0L;
/*      */   }
/*      */   
/*      */   void hookEvents()
/*      */   {
/* 1906 */     super.hookEvents();
/* 1907 */     if ((this.style & 0x4) != 0) {
/* 1908 */       OS.g_signal_connect_closure(this.handle, OS.changed, this.display.getClosure(6), true);
/* 1909 */       OS.g_signal_connect_closure(this.handle, OS.insert_text, this.display.getClosure(26), false);
/* 1910 */       OS.g_signal_connect_closure(this.handle, OS.delete_text, this.display.getClosure(13), false);
/* 1911 */       OS.g_signal_connect_closure(this.handle, OS.activate, this.display.getClosure(1), false);
/* 1912 */       OS.g_signal_connect_closure(this.handle, OS.grab_focus, this.display.getClosure(23), false);
/* 1913 */       OS.g_signal_connect_closure(this.handle, OS.populate_popup, this.display.getClosure(37), false);
/* 1914 */       if ((this.style & 0x80) != 0) {
/* 1915 */         OS.g_signal_connect_closure(this.handle, OS.icon_release, this.display.getClosure(67), false);
/*      */       }
/*      */     } else {
/* 1918 */       OS.g_signal_connect_closure(this.bufferHandle, OS.changed, this.display.getClosure(6), false);
/* 1919 */       OS.g_signal_connect_closure(this.bufferHandle, OS.insert_text, this.display.getClosure(52), false);
/* 1920 */       OS.g_signal_connect_closure(this.bufferHandle, OS.delete_range, this.display.getClosure(12), false);
/* 1921 */       OS.g_signal_connect_closure(this.handle, OS.populate_popup, this.display.getClosure(37), false);
/*      */     }
/* 1923 */     long imContext = imContext();
/* 1924 */     if (imContext != 0L) {
/* 1925 */       OS.g_signal_connect_closure(imContext, OS.commit, this.display.getClosure(9), false);
/* 1926 */       int id = OS.g_signal_lookup(OS.commit, GTK.gtk_im_context_get_type());
/* 1927 */       int mask = 17;
/* 1928 */       OS.g_signal_handlers_block_matched(imContext, mask, id, 0, 0L, 0L, this.handle);
/*      */     }
/* 1930 */     OS.g_signal_connect_closure(this.handle, OS.backspace, this.display.getClosure(70), false);
/* 1931 */     OS.g_signal_connect_closure(this.handle, OS.backspace, this.display.getClosure(71), true);
/* 1932 */     OS.g_signal_connect_closure(this.handle, OS.copy_clipboard, this.display.getClosure(72), false);
/* 1933 */     OS.g_signal_connect_closure(this.handle, OS.copy_clipboard, this.display.getClosure(73), true);
/* 1934 */     OS.g_signal_connect_closure(this.handle, OS.cut_clipboard, this.display.getClosure(74), false);
/* 1935 */     OS.g_signal_connect_closure(this.handle, OS.cut_clipboard, this.display.getClosure(75), true);
/* 1936 */     OS.g_signal_connect_closure(this.handle, OS.paste_clipboard, this.display.getClosure(76), false);
/* 1937 */     OS.g_signal_connect_closure(this.handle, OS.paste_clipboard, this.display.getClosure(77), true);
/* 1938 */     OS.g_signal_connect_closure(this.handle, OS.delete_from_cursor, this.display.getClosure(78), false);
/* 1939 */     OS.g_signal_connect_closure(this.handle, OS.delete_from_cursor, this.display.getClosure(79), true);
/* 1940 */     OS.g_signal_connect_closure(this.handle, OS.move_cursor, this.display.getClosure(80), false);
/* 1941 */     OS.g_signal_connect_closure(this.handle, OS.move_cursor, this.display.getClosure(81), true);
/* 1942 */     OS.g_signal_connect_closure(this.handle, OS.direction_changed, this.display.getClosure(82), true);
/*      */   }
/*      */   
/*      */   long imContext() {
/* 1946 */     if (this.imContext != 0L) return this.imContext;
/* 1947 */     if ((this.style & 0x4) != 0) {
/* 1948 */       return GTK.GTK_ENTRY_IM_CONTEXT(this.handle);
/*      */     }
/* 1950 */     return GTK.GTK_TEXTVIEW_IM_CONTEXT(this.handle);
/*      */   }
/*      */   
/*      */   private boolean insideBlockSelection(int x, int y)
/*      */   {
/* 1955 */     int start = 0;int end = 0;
/* 1956 */     if ((this.style & 0x4) != 0) {
/* 1957 */       int[] s = new int[1];int[] e = new int[1];
/* 1958 */       GTK.gtk_editable_get_selection_bounds(this.handle, s, e);
/* 1959 */       start = s[0];
/* 1960 */       end = e[0];
/*      */     } else {
/* 1962 */       byte[] s = new byte[ITER_SIZEOF];byte[] e = new byte[ITER_SIZEOF];
/* 1963 */       GTK.gtk_text_buffer_get_selection_bounds(this.bufferHandle, s, e);
/* 1964 */       start = GTK.gtk_text_iter_get_offset(s);
/* 1965 */       end = GTK.gtk_text_iter_get_offset(e);
/*      */     }
/* 1967 */     if (start != end) {
/* 1968 */       if (end < start) {
/* 1969 */         int temp = end;
/* 1970 */         end = start;
/* 1971 */         start = temp;
/*      */       }
/* 1973 */       int position = -1;
/* 1974 */       if ((this.style & 0x4) != 0) {
/* 1975 */         int[] index = new int[1];
/* 1976 */         int[] trailing = new int[1];
/* 1977 */         long layout = GTK.gtk_entry_get_layout(this.handle);
/* 1978 */         OS.pango_layout_xy_to_index(layout, x * 1024, y * 1024, index, trailing);
/* 1979 */         long ptr = OS.pango_layout_get_text(layout);
/* 1980 */         position = (int)OS.g_utf8_pointer_to_offset(ptr, ptr + index[0]) + trailing[0];
/*      */       } else {
/* 1982 */         byte[] p = new byte[ITER_SIZEOF];
/* 1983 */         GTK.gtk_text_view_get_iter_at_location(this.handle, p, x, y);
/* 1984 */         position = GTK.gtk_text_iter_get_offset(p);
/*      */       }
/* 1986 */       if ((start <= position) && (position < end)) {
/* 1987 */         return true;
/*      */       }
/*      */     }
/* 1990 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void insert(String string)
/*      */   {
/* 2012 */     checkWidget();
/* 2013 */     if (string == null) error(4);
/* 2014 */     clearSegments(true);
/* 2015 */     byte[] buffer = Converter.wcsToMbcs(string, false);
/* 2016 */     if ((this.style & 0x4) != 0) {
/* 2017 */       int[] start = new int[1];int[] end = new int[1];
/* 2018 */       GTK.gtk_editable_get_selection_bounds(this.handle, start, end);
/* 2019 */       GTK.gtk_editable_delete_selection(this.handle);
/* 2020 */       GTK.gtk_editable_insert_text(this.handle, buffer, buffer.length, start);
/* 2021 */       GTK.gtk_editable_set_position(this.handle, start[0]);
/*      */     } else {
/* 2023 */       byte[] start = new byte[ITER_SIZEOF];
/* 2024 */       byte[] end = new byte[ITER_SIZEOF];
/* 2025 */       if (GTK.gtk_text_buffer_get_selection_bounds(this.bufferHandle, start, end)) {
/* 2026 */         GTK.gtk_text_buffer_delete(this.bufferHandle, start, end);
/*      */       }
/* 2028 */       GTK.gtk_text_buffer_insert(this.bufferHandle, start, buffer, buffer.length);
/* 2029 */       GTK.gtk_text_buffer_place_cursor(this.bufferHandle, start);
/* 2030 */       scrollIfNotVisible(start, null, true);
/*      */     }
/* 2032 */     applySegments();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void scrollIfNotVisible(byte[] iter, byte[] scrollTo, boolean insert)
/*      */   {
/* 2051 */     GdkRectangle rect = new GdkRectangle();
/*      */     
/* 2053 */     int[] insertionCoordinates = new int[1];
/* 2054 */     int[] topIndexCoordinates = new int[1];
/* 2055 */     byte[] indexIter = new byte[ITER_SIZEOF];
/*      */     
/*      */ 
/* 2058 */     GTK.gtk_text_view_get_visible_rect(this.handle, rect);
/* 2059 */     int lineHeight = getLineHeight();
/* 2060 */     int numLinesVisible = rect.height / lineHeight;
/*      */     
/*      */ 
/* 2063 */     GTK.gtk_text_view_get_line_yrange(this.handle, iter, insertionCoordinates, null);
/*      */     
/*      */ 
/*      */ 
/* 2067 */     if (this.indexMark != 0L) {
/* 2068 */       GTK.gtk_text_buffer_get_iter_at_mark(this.bufferHandle, indexIter, this.indexMark);
/* 2069 */       GTK.gtk_text_view_get_line_yrange(this.handle, indexIter, topIndexCoordinates, null);
/* 2070 */       int distanceTopIndex = (insertionCoordinates[0] - topIndexCoordinates[0]) / lineHeight;
/*      */       
/*      */ 
/* 2073 */       if (distanceTopIndex >= numLinesVisible) {
/* 2074 */         if (insert) {
/* 2075 */           long mark = GTK.gtk_text_buffer_get_insert(this.bufferHandle);
/* 2076 */           GTK.gtk_text_view_scroll_to_mark(this.handle, mark, 0.0D, true, 0.0D, 0.0D);
/* 2077 */         } else if (scrollTo != null) {
/* 2078 */           GTK.gtk_text_view_scroll_to_iter(this.handle, scrollTo, 0.0D, true, 0.0D, 0.0D);
/*      */         }
/*      */       }
/*      */     }
/*      */     else {
/* 2083 */       topIndexCoordinates[0] = 0;
/* 2084 */       int distanceTopIndex = (insertionCoordinates[0] - topIndexCoordinates[0]) / lineHeight;
/* 2085 */       if (distanceTopIndex >= numLinesVisible) {
/* 2086 */         if ((scrollTo != null) && (!insert)) {
/* 2087 */           GTK.gtk_text_view_scroll_to_iter(this.handle, scrollTo, 0.0D, true, 0.0D, 0.0D);
/* 2088 */         } else if (insert) {
/* 2089 */           long mark = GTK.gtk_text_buffer_get_insert(this.bufferHandle);
/* 2090 */           GTK.gtk_text_view_scroll_to_mark(this.handle, mark, 0.0D, true, 0.0D, 0.0D);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   long paintWindow()
/*      */   {
/* 2098 */     if ((this.style & 0x4) != 0) {
/* 2099 */       long window = super.paintWindow();
/* 2100 */       long children = GDK.gdk_window_get_children(window);
/* 2101 */       if (children != 0L)
/*      */       {
/*      */ 
/*      */ 
/*      */         do
/*      */         {
/*      */ 
/*      */ 
/* 2109 */           window = OS.g_list_data(children);
/* 2110 */         } while ((children = OS.g_list_next(children)) != 0L);
/*      */       }
/* 2112 */       OS.g_list_free(children);
/* 2113 */       return window;
/*      */     }
/* 2115 */     GTK.gtk_widget_realize(this.handle);
/* 2116 */     return GTK.gtk_text_view_get_window(this.handle, 2);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void paste()
/*      */   {
/* 2132 */     checkWidget();
/* 2133 */     if ((this.style & 0x4) != 0) {
/* 2134 */       GTK.gtk_editable_paste_clipboard(this.handle);
/*      */     } else {
/* 2136 */       long clipboard = GTK.gtk_clipboard_get(0L);
/* 2137 */       clearSegments(true);
/* 2138 */       GTK.gtk_text_buffer_paste_clipboard(this.bufferHandle, clipboard, null, GTK.gtk_text_view_get_editable(this.handle));
/* 2139 */       applySegments();
/*      */     }
/*      */   }
/*      */   
/*      */   void register()
/*      */   {
/* 2145 */     super.register();
/* 2146 */     if (this.bufferHandle != 0L) this.display.addWidget(this.bufferHandle, this);
/* 2147 */     long imContext = imContext();
/* 2148 */     if (imContext != 0L) this.display.addWidget(imContext, this);
/*      */   }
/*      */   
/*      */   void releaseWidget()
/*      */   {
/* 2153 */     super.releaseWidget();
/* 2154 */     fixIM();
/* 2155 */     this.message = null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeModifyListener(ModifyListener listener)
/*      */   {
/* 2176 */     checkWidget();
/* 2177 */     if (listener == null) error(4);
/* 2178 */     if (this.eventTable == null) return;
/* 2179 */     this.eventTable.unhook(24, listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeSegmentListener(SegmentListener listener)
/*      */   {
/* 2203 */     checkWidget();
/* 2204 */     if (listener == null) error(4);
/* 2205 */     this.eventTable.unhook(49, listener);
/* 2206 */     clearSegments(true);
/* 2207 */     applySegments();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeSelectionListener(SelectionListener listener)
/*      */   {
/* 2228 */     checkWidget();
/* 2229 */     if (listener == null) error(4);
/* 2230 */     if (this.eventTable == null) return;
/* 2231 */     this.eventTable.unhook(13, listener);
/* 2232 */     this.eventTable.unhook(14, listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeVerifyListener(VerifyListener listener)
/*      */   {
/* 2253 */     checkWidget();
/* 2254 */     if (listener == null) error(4);
/* 2255 */     if (this.eventTable == null) return;
/* 2256 */     this.eventTable.unhook(25, listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void selectAll()
/*      */   {
/* 2268 */     checkWidget();
/* 2269 */     if ((this.style & 0x4) != 0) {
/* 2270 */       GTK.gtk_editable_select_region(this.handle, 0, -1);
/*      */     } else {
/* 2272 */       byte[] start = new byte[ITER_SIZEOF];
/* 2273 */       byte[] end = new byte[ITER_SIZEOF];
/* 2274 */       GTK.gtk_text_buffer_get_iter_at_offset(this.bufferHandle, start, 0);
/* 2275 */       GTK.gtk_text_buffer_get_end_iter(this.bufferHandle, end);
/* 2276 */       GTK.gtk_text_buffer_select_range(this.bufferHandle, start, end);
/*      */     }
/*      */   }
/*      */   
/*      */   void setBackgroundGdkColor(GdkColor color)
/*      */   {
/* 2282 */     assert (!GTK.GTK3) : "GTK2 code was run by GTK3";
/* 2283 */     super.setBackgroundGdkColor(color);
/* 2284 */     GTK.gtk_widget_modify_base(this.handle, 0, color);
/*      */   }
/*      */   
/*      */   GdkRGBA getContextBackgroundGdkRGBA()
/*      */   {
/* 2289 */     assert (GTK.GTK3) : "GTK3 code was run by GTK2";
/* 2290 */     if ((this.background != null) && ((this.state & 0x2000) != 0)) {
/* 2291 */       return this.background;
/*      */     }
/* 2293 */     return defaultBackground();
/*      */   }
/*      */   
/*      */   void setBackgroundGdkRGBA(long context, long handle, GdkRGBA rgba)
/*      */   {
/* 2298 */     assert (GTK.GTK3) : "GTK3 code was run by GTK2";
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2304 */     if (rgba == null) {
/* 2305 */       this.background = defaultBackground();
/*      */     } else {
/* 2307 */       this.background = rgba;
/*      */     }
/* 2309 */     GdkRGBA selectedBackground = this.display.getSystemColor(26).handleRGBA;
/* 2310 */     GdkRGBA selectedForeground = this.display.getSystemColor(27).handleRGBA;
/*      */     
/*      */ 
/*      */ 
/* 2314 */     String selection = GTK.GTK_VERSION >= OS.VERSION(3, 20, 0) ? " selection" : ":selected";
/* 2315 */     String properties; String name; String properties; if ((this.style & 0x4) != 0) {
/* 2316 */       String name = GTK.GTK_VERSION >= OS.VERSION(3, 20, 0) ? "entry" : "GtkEntry";
/*      */       
/*      */ 
/* 2319 */       properties = " {background: " + this.display.gtk_rgba_to_css_string(this.background) + ";}\n" + name + ":selected {background-color: " + this.display.gtk_rgba_to_css_string(selectedBackground) + ";}\n" + name + selection + " {color: " + this.display.gtk_rgba_to_css_string(selectedForeground) + ";}";
/*      */     } else {
/* 2321 */       name = GTK.GTK_VERSION >= OS.VERSION(3, 20, 0) ? "textview text" : "GtkTextView";
/*      */       
/*      */ 
/* 2324 */       properties = " {background-color: " + this.display.gtk_rgba_to_css_string(this.background) + ";}\n" + name + ":selected {background-color: " + this.display.gtk_rgba_to_css_string(selectedBackground) + ";}\n" + name + selection + " {color: " + this.display.gtk_rgba_to_css_string(selectedForeground) + ";}";
/*      */     }
/* 2326 */     String css = name + properties;
/*      */     
/*      */ 
/* 2329 */     this.cssBackground = css;
/*      */     
/*      */ 
/* 2332 */     String finalCss = this.display.gtk_css_create_css_color_string(this.cssBackground, this.cssForeground, 8);
/* 2333 */     gtk_css_provider_load_from_css(context, finalCss);
/*      */   }
/*      */   
/*      */   void setCursor(long cursor)
/*      */   {
/* 2338 */     long defaultCursor = 0L;
/* 2339 */     if (cursor == 0L) defaultCursor = GDK.gdk_cursor_new_for_display(GDK.gdk_display_get_default(), 152L);
/* 2340 */     super.setCursor(cursor != 0L ? cursor : defaultCursor);
/* 2341 */     if (cursor == 0L) { gdk_cursor_unref(defaultCursor);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDoubleClickEnabled(boolean doubleClick)
/*      */   {
/* 2363 */     checkWidget();
/* 2364 */     this.doubleClick = doubleClick;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setEchoChar(char echo)
/*      */   {
/* 2389 */     checkWidget();
/* 2390 */     if ((this.style & 0x4) != 0) {
/* 2391 */       GTK.gtk_entry_set_visibility(this.handle, echo == 0);
/* 2392 */       GTK.gtk_entry_set_invisible_char(this.handle, echo);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setEditable(boolean editable)
/*      */   {
/* 2407 */     checkWidget();
/* 2408 */     this.style &= 0xFFFFFFF7;
/* 2409 */     if (!editable) this.style |= 0x8;
/* 2410 */     if ((this.style & 0x4) != 0) {
/* 2411 */       GTK.gtk_editable_set_editable(this.handle, editable);
/*      */     } else {
/* 2413 */       GTK.gtk_text_view_set_editable(this.handle, editable);
/*      */     }
/*      */   }
/*      */   
/*      */   void setFontDescription(long font)
/*      */   {
/* 2419 */     super.setFontDescription(font);
/* 2420 */     setTabStops(this.tabs);
/*      */   }
/*      */   
/*      */   void setForegroundGdkColor(GdkColor color)
/*      */   {
/* 2425 */     assert (!GTK.GTK3) : "GTK2 code was run by GTK3";
/* 2426 */     setForegroundColor(this.handle, color, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setMessage(String message)
/*      */   {
/* 2449 */     checkWidget();
/* 2450 */     if (message == null) error(4);
/* 2451 */     this.message = message;
/* 2452 */     if ((GTK.GTK_VERSION >= OS.VERSION(3, 2, 0)) && 
/* 2453 */       ((this.style & 0x4) != 0)) {
/* 2454 */       byte[] buffer = Converter.wcsToMbcs(message, true);
/* 2455 */       GTK.gtk_entry_set_placeholder_text(this.handle, buffer);
/* 2456 */       return;
/*      */     }
/*      */     
/* 2459 */     redraw(false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setOrientation(int orientation)
/*      */   {
/* 2481 */     checkWidget();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSelection(int start)
/*      */   {
/* 2508 */     checkWidget();
/* 2509 */     start = translateOffset(start);
/* 2510 */     if ((this.style & 0x4) != 0) {
/* 2511 */       long ptr = GTK.gtk_entry_get_text(this.handle);
/* 2512 */       start = (int)OS.g_utf16_offset_to_utf8_offset(ptr, start);
/* 2513 */       GTK.gtk_editable_set_position(this.handle, start);
/*      */     } else {
/* 2515 */       byte[] startIter = new byte[ITER_SIZEOF];
/* 2516 */       byte[] endIter = new byte[ITER_SIZEOF];
/* 2517 */       GTK.gtk_text_buffer_get_bounds(this.bufferHandle, startIter, endIter);
/* 2518 */       long ptr = GTK.gtk_text_buffer_get_text(this.bufferHandle, startIter, endIter, true);
/* 2519 */       start = (int)OS.g_utf16_offset_to_utf8_offset(ptr, start);
/* 2520 */       OS.g_free(ptr);
/* 2521 */       GTK.gtk_text_buffer_get_iter_at_offset(this.bufferHandle, startIter, start);
/* 2522 */       GTK.gtk_text_buffer_place_cursor(this.bufferHandle, startIter);
/* 2523 */       scrollIfNotVisible(startIter, startIter, false);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSelection(int start, int end)
/*      */   {
/* 2553 */     checkWidget();
/* 2554 */     start = translateOffset(start);
/* 2555 */     end = translateOffset(end);
/* 2556 */     if ((this.style & 0x4) != 0) {
/* 2557 */       long ptr = GTK.gtk_entry_get_text(this.handle);
/* 2558 */       start = (int)OS.g_utf16_offset_to_utf8_offset(ptr, start);
/* 2559 */       end = (int)OS.g_utf16_offset_to_utf8_offset(ptr, end);
/* 2560 */       GTK.gtk_editable_set_position(this.handle, start);
/* 2561 */       GTK.gtk_editable_select_region(this.handle, start, end);
/*      */     } else {
/* 2563 */       byte[] startIter = new byte[ITER_SIZEOF];
/* 2564 */       byte[] endIter = new byte[ITER_SIZEOF];
/* 2565 */       GTK.gtk_text_buffer_get_bounds(this.bufferHandle, startIter, endIter);
/* 2566 */       long ptr = GTK.gtk_text_buffer_get_text(this.bufferHandle, startIter, endIter, true);
/* 2567 */       start = (int)OS.g_utf16_offset_to_utf8_offset(ptr, start);
/* 2568 */       end = (int)OS.g_utf16_offset_to_utf8_offset(ptr, end);
/* 2569 */       OS.g_free(ptr);
/* 2570 */       GTK.gtk_text_buffer_get_iter_at_offset(this.bufferHandle, startIter, start);
/* 2571 */       GTK.gtk_text_buffer_get_iter_at_offset(this.bufferHandle, endIter, end);
/* 2572 */       scrollIfNotVisible(startIter, startIter, false);
/* 2573 */       GTK.gtk_text_buffer_select_range(this.bufferHandle, startIter, endIter);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSelection(Point selection)
/*      */   {
/* 2607 */     checkWidget();
/* 2608 */     if (selection == null) error(4);
/* 2609 */     setSelection(selection.x, selection.y);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTabs(int tabs)
/*      */   {
/* 2629 */     checkWidget();
/* 2630 */     if (tabs < 0) return;
/* 2631 */     setTabStops(this.tabs = tabs);
/*      */   }
/*      */   
/*      */   void setTabStops(int tabs) {
/* 2635 */     if ((this.style & 0x4) != 0) return;
/* 2636 */     int tabWidth = getTabWidth(tabs);
/* 2637 */     long tabArray = OS.pango_tab_array_new(1, false);
/* 2638 */     OS.pango_tab_array_set_tab(tabArray, 0, 0L, tabWidth);
/* 2639 */     GTK.gtk_text_view_set_tabs(this.handle, tabArray);
/* 2640 */     OS.pango_tab_array_free(tabArray);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setText(String string)
/*      */   {
/* 2662 */     checkWidget();
/* 2663 */     if (string == null) { error(4);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 2669 */     if ((hooks(25)) || (filters(25))) {
/* 2670 */       string = verifyText(string, 0, getCharCount());
/* 2671 */       if (string == null) return;
/*      */     }
/* 2673 */     char[] text = new char[string.length()];
/* 2674 */     string.getChars(0, text.length, text, 0);
/* 2675 */     setText(text);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTextChars(char[] text)
/*      */   {
/* 2705 */     checkWidget();
/* 2706 */     if (text == null) { error(4);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 2712 */     if ((hooks(25)) || (filters(25))) {
/* 2713 */       String string = verifyText(new String(text), 0, getCharCount());
/* 2714 */       if (string == null) return;
/* 2715 */       text = new char[string.length()];
/* 2716 */       string.getChars(0, text.length, text, 0);
/*      */     }
/* 2718 */     setText(text);
/*      */   }
/*      */   
/*      */   void setText(char[] text) {
/* 2722 */     clearSegments(false);
/* 2723 */     if ((this.style & 0x4) != 0) {
/* 2724 */       byte[] buffer = Converter.wcsToMbcs(text, true);
/* 2725 */       OS.g_signal_handlers_block_matched(this.handle, 16, 0, 0, 0L, 0L, 6L);
/* 2726 */       OS.g_signal_handlers_block_matched(this.handle, 16, 0, 0, 0L, 0L, 13L);
/* 2727 */       OS.g_signal_handlers_block_matched(this.handle, 16, 0, 0, 0L, 0L, 26L);
/* 2728 */       GTK.gtk_entry_set_text(this.handle, buffer);
/* 2729 */       OS.g_signal_handlers_unblock_matched(this.handle, 16, 0, 0, 0L, 0L, 6L);
/* 2730 */       OS.g_signal_handlers_unblock_matched(this.handle, 16, 0, 0, 0L, 0L, 13L);
/* 2731 */       OS.g_signal_handlers_unblock_matched(this.handle, 16, 0, 0, 0L, 0L, 26L);
/* 2732 */       Arrays.fill(buffer, (byte)0);
/*      */     } else {
/* 2734 */       byte[] buffer = Converter.wcsToMbcs(text, false);
/* 2735 */       byte[] position = new byte[ITER_SIZEOF];
/* 2736 */       OS.g_signal_handlers_block_matched(this.bufferHandle, 16, 0, 0, 0L, 0L, 6L);
/* 2737 */       OS.g_signal_handlers_block_matched(this.bufferHandle, 16, 0, 0, 0L, 0L, 12L);
/* 2738 */       OS.g_signal_handlers_block_matched(this.bufferHandle, 16, 0, 0, 0L, 0L, 52L);
/* 2739 */       GTK.gtk_text_buffer_set_text(this.bufferHandle, buffer, buffer.length);
/* 2740 */       OS.g_signal_handlers_unblock_matched(this.bufferHandle, 16, 0, 0, 0L, 0L, 6L);
/* 2741 */       OS.g_signal_handlers_unblock_matched(this.bufferHandle, 16, 0, 0, 0L, 0L, 12L);
/* 2742 */       OS.g_signal_handlers_unblock_matched(this.bufferHandle, 16, 0, 0, 0L, 0L, 52L);
/* 2743 */       GTK.gtk_text_buffer_get_iter_at_offset(this.bufferHandle, position, 0);
/* 2744 */       GTK.gtk_text_buffer_place_cursor(this.bufferHandle, position);
/* 2745 */       long mark = GTK.gtk_text_buffer_get_insert(this.bufferHandle);
/* 2746 */       GTK.gtk_text_view_scroll_to_mark(this.handle, mark, 0.0D, true, 0.0D, 0.0D);
/* 2747 */       Arrays.fill(buffer, (byte)0);
/*      */     }
/* 2749 */     sendEvent(24);
/* 2750 */     if (((this.style & 0x80) != 0) && 
/* 2751 */       ((this.style & 0x100) != 0)) {
/* 2752 */       GTK.gtk_entry_set_icon_sensitive(this.handle, 1, true);
/*      */     }
/*      */     
/* 2755 */     applySegments();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTextLimit(int limit)
/*      */   {
/* 2783 */     checkWidget();
/* 2784 */     if (limit == 0) error(7);
/* 2785 */     if ((this.style & 0x4) != 0) {
/* 2786 */       GTK.gtk_entry_set_max_length(this.handle, this.segments != null ? Math.min(LIMIT, translateOffset(limit)) : limit);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTopIndex(int index)
/*      */   {
/* 2803 */     checkWidget();
/* 2804 */     if ((this.style & 0x4) != 0) return;
/* 2805 */     byte[] position = new byte[ITER_SIZEOF];
/* 2806 */     GTK.gtk_text_buffer_get_iter_at_line(this.bufferHandle, position, index);
/* 2807 */     if (GTK.GTK3)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2816 */       byte[] buffer = Converter.wcsToMbcs("index_mark", true);
/* 2817 */       this.indexMark = GTK.gtk_text_buffer_create_mark(this.bufferHandle, buffer, position, true);
/* 2818 */       GTK.gtk_text_view_scroll_to_mark(this.handle, this.indexMark, 0.0D, true, 0.0D, 0.0D);
/* 2819 */       long vAdjustment = GTK.gtk_scrollable_get_vadjustment(this.handle);
/* 2820 */       this.cachedAdjustment = GTK.gtk_adjustment_get_value(vAdjustment);
/*      */     } else {
/* 2822 */       GTK.gtk_text_view_scroll_to_iter(this.handle, position, 0.0D, true, 0.0D, 0.0D);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void showSelection()
/*      */   {
/* 2840 */     checkWidget();
/* 2841 */     if ((this.style & 0x4) != 0) return;
/* 2842 */     long mark = GTK.gtk_text_buffer_get_selection_bound(this.bufferHandle);
/* 2843 */     GTK.gtk_text_view_scroll_to_mark(this.handle, mark, 0.0D, true, 0.0D, 0.0D);
/* 2844 */     mark = GTK.gtk_text_buffer_get_insert(this.bufferHandle);
/* 2845 */     GTK.gtk_text_view_scroll_to_mark(this.handle, mark, 0.0D, true, 0.0D, 0.0D);
/*      */   }
/*      */   
/*      */   int translateOffset(int offset) {
/* 2849 */     if (this.segments == null) return offset;
/* 2850 */     int i = 0; for (int nSegments = this.segments.length; (i < nSegments) && (offset - i >= this.segments[i]); i++) {
/* 2851 */       offset++;
/*      */     }
/* 2853 */     return offset;
/*      */   }
/*      */   
/*      */   boolean translateTraversal(GdkEventKey keyEvent)
/*      */   {
/* 2858 */     int key = keyEvent.keyval;
/* 2859 */     switch (key) {
/*      */     case 65293: 
/*      */     case 65421: 
/* 2862 */       long imContext = imContext();
/* 2863 */       if (imContext != 0L) {
/* 2864 */         long[] preeditString = new long[1];
/* 2865 */         GTK.gtk_im_context_get_preedit_string(imContext, preeditString, null, null);
/* 2866 */         if (preeditString[0] != 0L) {
/* 2867 */           int length = C.strlen(preeditString[0]);
/* 2868 */           OS.g_free(preeditString[0]);
/* 2869 */           if (length != 0) return false;
/*      */         }
/*      */       }
/*      */       break;
/*      */     }
/* 2874 */     return super.translateTraversal(keyEvent);
/*      */   }
/*      */   
/*      */   int traversalCode(int key, GdkEventKey event)
/*      */   {
/* 2879 */     int bits = super.traversalCode(key, event);
/* 2880 */     if ((this.style & 0x8) != 0) return bits;
/* 2881 */     if ((this.style & 0x2) != 0) {
/* 2882 */       bits &= 0xFFFFFFFB;
/* 2883 */       if ((key == 65289) && (event != null)) {
/* 2884 */         boolean next = (event.state & 0x1) == 0;
/* 2885 */         if ((next) && ((event.state & 0x4) == 0)) {
/* 2886 */           bits &= 0xFFFFFFE7;
/*      */         }
/*      */       }
/*      */     }
/* 2890 */     return bits;
/*      */   }
/*      */   
/*      */   int untranslateOffset(int offset) {
/* 2894 */     if (this.segments == null) return offset;
/* 2895 */     int i = 0; for (int nSegments = this.segments.length; (i < nSegments) && (offset > this.segments[i]); i++) {
/* 2896 */       offset--;
/*      */     }
/* 2898 */     return offset;
/*      */   }
/*      */   
/*      */   String verifyText(String string, int start, int end) {
/* 2902 */     if ((string != null) && (string.length() == 0) && (start == end)) return null;
/* 2903 */     Event event = new Event();
/* 2904 */     event.text = string;
/* 2905 */     event.start = start;
/* 2906 */     event.end = end;
/* 2907 */     long eventPtr = GTK.gtk_get_current_event();
/* 2908 */     if (eventPtr != 0L) {
/* 2909 */       GdkEventKey gdkEvent = new GdkEventKey();
/* 2910 */       OS.memmove(gdkEvent, eventPtr, GdkEventKey.sizeof);
/* 2911 */       switch (gdkEvent.type) {
/*      */       case 8: 
/* 2913 */         setKeyState(event, gdkEvent);
/*      */       }
/*      */       
/* 2916 */       GDK.gdk_event_free(eventPtr);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2924 */     sendEvent(25, event);
/* 2925 */     if ((!event.doit) || (isDisposed())) return null;
/* 2926 */     return event.text;
/*      */   }
/*      */   
/*      */   long windowProc(long handle, long user_data)
/*      */   {
/* 2931 */     if ((hooks(49)) || (filters(49)) || (this.segments != null)) {
/* 2932 */       switch ((int)user_data) {
/*      */       case 70: 
/*      */       case 72: 
/*      */       case 74: 
/*      */       case 76: 
/* 2937 */         clearSegments(true);
/* 2938 */         break;
/*      */       
/*      */       case 71: 
/*      */       case 73: 
/*      */       case 75: 
/*      */       case 77: 
/* 2944 */         applySegments();
/*      */       }
/*      */       
/*      */     }
/*      */     
/* 2949 */     return super.windowProc(handle, user_data);
/*      */   }
/*      */   
/*      */   long windowProc(long handle, long arg0, long user_data)
/*      */   {
/* 2954 */     if ((hooks(49)) || (filters(49)) || (this.segments != null)) {
/* 2955 */       switch ((int)user_data) {
/*      */       case 82: 
/* 2957 */         clearSegments(true);
/* 2958 */         applySegments();
/*      */       }
/*      */       
/*      */     }
/*      */     
/* 2963 */     return super.windowProc(handle, arg0, user_data);
/*      */   }
/*      */   
/*      */   long windowProc(long handle, long arg0, long arg1, long user_data)
/*      */   {
/* 2968 */     if ((hooks(49)) || (filters(49)) || (this.segments != null)) {
/* 2969 */       switch ((int)user_data) {
/*      */       case 78: 
/* 2971 */         clearSegments(true);
/* 2972 */         break;
/*      */       
/*      */       case 79: 
/* 2975 */         applySegments();
/*      */       }
/*      */       
/*      */     }
/*      */     
/* 2980 */     return super.windowProc(handle, arg0, arg1, user_data);
/*      */   }
/*      */   
/*      */   long windowProc(long handle, long arg0, long arg1, long arg2, long user_data)
/*      */   {
/* 2985 */     if ((hooks(49)) || (filters(49)) || (this.segments != null)) {
/* 2986 */       switch ((int)user_data) {
/*      */       case 80: 
/* 2988 */         if (arg0 == 1L) {
/* 2989 */           clearSegments(true);
/*      */         }
/*      */         
/*      */         break;
/*      */       case 81: 
/* 2994 */         if (arg0 == 1L) {
/* 2995 */           applySegments();
/*      */         }
/*      */         break;
/*      */       }
/*      */       
/*      */     }
/* 3001 */     return super.windowProc(handle, arg0, arg1, arg2, user_data);
/*      */   }
/*      */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/widgets/Text.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */