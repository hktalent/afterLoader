/*     */ package org.eclipse.swt.widgets;
/*     */ 
/*     */ import org.eclipse.swt.events.ArmEvent;
/*     */ import org.eclipse.swt.events.ArmListener;
/*     */ import org.eclipse.swt.events.ControlEvent;
/*     */ import org.eclipse.swt.events.ControlListener;
/*     */ import org.eclipse.swt.events.DisposeEvent;
/*     */ import org.eclipse.swt.events.DisposeListener;
/*     */ import org.eclipse.swt.events.DragDetectListener;
/*     */ import org.eclipse.swt.events.ExpandEvent;
/*     */ import org.eclipse.swt.events.ExpandListener;
/*     */ import org.eclipse.swt.events.FocusEvent;
/*     */ import org.eclipse.swt.events.FocusListener;
/*     */ import org.eclipse.swt.events.GestureEvent;
/*     */ import org.eclipse.swt.events.GestureListener;
/*     */ import org.eclipse.swt.events.HelpListener;
/*     */ import org.eclipse.swt.events.KeyEvent;
/*     */ import org.eclipse.swt.events.KeyListener;
/*     */ import org.eclipse.swt.events.MenuDetectEvent;
/*     */ import org.eclipse.swt.events.MenuDetectListener;
/*     */ import org.eclipse.swt.events.MenuEvent;
/*     */ import org.eclipse.swt.events.MenuListener;
/*     */ import org.eclipse.swt.events.ModifyListener;
/*     */ import org.eclipse.swt.events.MouseEvent;
/*     */ import org.eclipse.swt.events.MouseListener;
/*     */ import org.eclipse.swt.events.MouseMoveListener;
/*     */ import org.eclipse.swt.events.MouseTrackListener;
/*     */ import org.eclipse.swt.events.MouseWheelListener;
/*     */ import org.eclipse.swt.events.PaintEvent;
/*     */ import org.eclipse.swt.events.PaintListener;
/*     */ import org.eclipse.swt.events.SegmentEvent;
/*     */ import org.eclipse.swt.events.SegmentListener;
/*     */ import org.eclipse.swt.events.SelectionEvent;
/*     */ import org.eclipse.swt.events.SelectionListener;
/*     */ import org.eclipse.swt.events.ShellEvent;
/*     */ import org.eclipse.swt.events.ShellListener;
/*     */ import org.eclipse.swt.events.TouchEvent;
/*     */ import org.eclipse.swt.events.TouchListener;
/*     */ import org.eclipse.swt.events.TraverseEvent;
/*     */ import org.eclipse.swt.events.TraverseListener;
/*     */ import org.eclipse.swt.events.TreeEvent;
/*     */ import org.eclipse.swt.events.TreeListener;
/*     */ import org.eclipse.swt.events.VerifyEvent;
/*     */ import org.eclipse.swt.events.VerifyListener;
/*     */ import org.eclipse.swt.internal.SWTEventListener;
/*     */ 
/*     */ public class TypedListener implements Listener
/*     */ {
/*     */   protected SWTEventListener eventListener;
/*     */   
/*     */   public TypedListener(SWTEventListener listener)
/*     */   {
/*  53 */     this.eventListener = listener;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SWTEventListener getEventListener()
/*     */   {
/*  70 */     return this.eventListener;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void handleEvent(Event e)
/*     */   {
/*  87 */     switch (e.type) {
/*     */     case 26: 
/*  89 */       ((ShellListener)this.eventListener).shellActivated(new ShellEvent(e));
/*  90 */       break;
/*     */     
/*     */     case 30: 
/*  93 */       ((ArmListener)this.eventListener).widgetArmed(new ArmEvent(e));
/*  94 */       break;
/*     */     
/*     */ 
/*     */     case 21: 
/*  98 */       ShellEvent event = new ShellEvent(e);
/*  99 */       ((ShellListener)this.eventListener).shellClosed(event);
/* 100 */       e.doit = event.doit;
/* 101 */       break;
/*     */     
/*     */     case 18: 
/* 104 */       if ((this.eventListener instanceof TreeListener)) {
/* 105 */         ((TreeListener)this.eventListener).treeCollapsed(new TreeEvent(e));
/*     */       } else {
/* 107 */         ((ExpandListener)this.eventListener).itemCollapsed(new ExpandEvent(e));
/*     */       }
/* 109 */       break;
/*     */     
/*     */     case 27: 
/* 112 */       ((ShellListener)this.eventListener).shellDeactivated(new ShellEvent(e));
/* 113 */       break;
/*     */     
/*     */     case 20: 
/* 116 */       ((ShellListener)this.eventListener).shellDeiconified(new ShellEvent(e));
/* 117 */       break;
/*     */     
/*     */     case 14: 
/* 120 */       ((SelectionListener)this.eventListener).widgetDefaultSelected(new SelectionEvent(e));
/* 121 */       break;
/*     */     
/*     */     case 12: 
/* 124 */       ((DisposeListener)this.eventListener).widgetDisposed(new DisposeEvent(e));
/* 125 */       break;
/*     */     
/*     */     case 29: 
/* 128 */       ((DragDetectListener)this.eventListener).dragDetected(new org.eclipse.swt.events.DragDetectEvent(e));
/* 129 */       break;
/*     */     
/*     */     case 17: 
/* 132 */       if ((this.eventListener instanceof TreeListener)) {
/* 133 */         ((TreeListener)this.eventListener).treeExpanded(new TreeEvent(e));
/*     */       } else {
/* 135 */         ((ExpandListener)this.eventListener).itemExpanded(new ExpandEvent(e));
/*     */       }
/* 137 */       break;
/*     */     
/*     */     case 15: 
/* 140 */       ((FocusListener)this.eventListener).focusGained(new FocusEvent(e));
/* 141 */       break;
/*     */     
/*     */     case 16: 
/* 144 */       ((FocusListener)this.eventListener).focusLost(new FocusEvent(e));
/* 145 */       break;
/*     */     
/*     */     case 48: 
/* 148 */       GestureEvent event = new GestureEvent(e);
/* 149 */       ((GestureListener)this.eventListener).gesture(event);
/* 150 */       e.doit = event.doit;
/* 151 */       break;
/*     */     
/*     */     case 28: 
/* 154 */       ((HelpListener)this.eventListener).helpRequested(new org.eclipse.swt.events.HelpEvent(e));
/* 155 */       break;
/*     */     
/*     */     case 23: 
/* 158 */       ((MenuListener)this.eventListener).menuHidden(new MenuEvent(e));
/* 159 */       break;
/*     */     
/*     */     case 19: 
/* 162 */       ((ShellListener)this.eventListener).shellIconified(new ShellEvent(e));
/* 163 */       break;
/*     */     
/*     */ 
/*     */     case 1: 
/* 167 */       KeyEvent event = new KeyEvent(e);
/* 168 */       ((KeyListener)this.eventListener).keyPressed(event);
/* 169 */       e.doit = event.doit;
/* 170 */       break;
/*     */     
/*     */ 
/*     */     case 2: 
/* 174 */       KeyEvent event = new KeyEvent(e);
/* 175 */       ((KeyListener)this.eventListener).keyReleased(event);
/* 176 */       e.doit = event.doit;
/* 177 */       break;
/*     */     
/*     */     case 24: 
/* 180 */       ((ModifyListener)this.eventListener).modifyText(new org.eclipse.swt.events.ModifyEvent(e));
/* 181 */       break;
/*     */     
/*     */     case 35: 
/* 184 */       MenuDetectEvent event = new MenuDetectEvent(e);
/* 185 */       ((MenuDetectListener)this.eventListener).menuDetected(event);
/* 186 */       e.x = event.x;
/* 187 */       e.y = event.y;
/* 188 */       e.doit = event.doit;
/* 189 */       e.detail = event.detail;
/* 190 */       break;
/*     */     
/*     */     case 3: 
/* 193 */       ((MouseListener)this.eventListener).mouseDown(new MouseEvent(e));
/* 194 */       break;
/*     */     
/*     */     case 8: 
/* 197 */       ((MouseListener)this.eventListener).mouseDoubleClick(new MouseEvent(e));
/* 198 */       break;
/*     */     
/*     */     case 6: 
/* 201 */       ((MouseTrackListener)this.eventListener).mouseEnter(new MouseEvent(e));
/* 202 */       break;
/*     */     
/*     */     case 7: 
/* 205 */       ((MouseTrackListener)this.eventListener).mouseExit(new MouseEvent(e));
/* 206 */       break;
/*     */     
/*     */     case 32: 
/* 209 */       ((MouseTrackListener)this.eventListener).mouseHover(new MouseEvent(e));
/* 210 */       break;
/*     */     
/*     */     case 5: 
/* 213 */       ((MouseMoveListener)this.eventListener).mouseMove(new MouseEvent(e));
/* 214 */       return;
/*     */     
/*     */     case 37: 
/* 217 */       ((MouseWheelListener)this.eventListener).mouseScrolled(new MouseEvent(e));
/* 218 */       return;
/*     */     
/*     */     case 4: 
/* 221 */       ((MouseListener)this.eventListener).mouseUp(new MouseEvent(e));
/* 222 */       break;
/*     */     
/*     */     case 10: 
/* 225 */       ((ControlListener)this.eventListener).controlMoved(new ControlEvent(e));
/* 226 */       break;
/*     */     
/*     */ 
/*     */     case 9: 
/* 230 */       PaintEvent event = new PaintEvent(e);
/* 231 */       ((PaintListener)this.eventListener).paintControl(event);
/* 232 */       e.gc = event.gc;
/* 233 */       break;
/*     */     
/*     */     case 11: 
/* 236 */       ((ControlListener)this.eventListener).controlResized(new ControlEvent(e));
/* 237 */       break;
/*     */     
/*     */     case 49: 
/* 240 */       SegmentEvent event = new SegmentEvent(e);
/* 241 */       ((SegmentListener)this.eventListener).getSegments(event);
/* 242 */       e.segments = event.segments;
/* 243 */       e.segmentsChars = event.segmentsChars;
/* 244 */       break;
/*     */     
/*     */ 
/*     */     case 13: 
/* 248 */       SelectionEvent event = new SelectionEvent(e);
/* 249 */       ((SelectionListener)this.eventListener).widgetSelected(event);
/* 250 */       e.x = event.x;
/* 251 */       e.y = event.y;
/* 252 */       e.doit = event.doit;
/* 253 */       break;
/*     */     
/*     */     case 22: 
/* 256 */       ((MenuListener)this.eventListener).menuShown(new MenuEvent(e));
/* 257 */       break;
/*     */     
/*     */     case 47: 
/* 260 */       ((TouchListener)this.eventListener).touch(new TouchEvent(e));
/* 261 */       break;
/*     */     
/*     */ 
/*     */     case 31: 
/* 265 */       TraverseEvent event = new TraverseEvent(e);
/* 266 */       ((TraverseListener)this.eventListener).keyTraversed(event);
/* 267 */       e.detail = event.detail;
/* 268 */       e.doit = event.doit;
/* 269 */       break;
/*     */     
/*     */ 
/*     */     case 25: 
/* 273 */       VerifyEvent event = new VerifyEvent(e);
/* 274 */       ((VerifyListener)this.eventListener).verifyText(event);
/* 275 */       e.text = event.text;
/* 276 */       e.doit = event.doit;
/* 277 */       break;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/widgets/TypedListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */