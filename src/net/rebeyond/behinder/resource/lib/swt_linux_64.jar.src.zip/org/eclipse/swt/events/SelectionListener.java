/*    */ package org.eclipse.swt.events;
/*    */ 
/*    */ import java.util.function.Consumer;
/*    */ import org.eclipse.swt.internal.SWTEventListener;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract interface SelectionListener
/*    */   extends SWTEventListener
/*    */ {
/*    */   public abstract void widgetSelected(SelectionEvent paramSelectionEvent);
/*    */   
/*    */   public abstract void widgetDefaultSelected(SelectionEvent paramSelectionEvent);
/*    */   
/*    */   public static SelectionListener widgetSelectedAdapter(Consumer<SelectionEvent> c)
/*    */   {
/* 78 */     new SelectionAdapter()
/*    */     {
/*    */       public void widgetSelected(SelectionEvent e) {
/* 81 */         this.val$c.accept(e);
/*    */       }
/*    */     };
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static SelectionListener widgetDefaultSelectedAdapter(Consumer<SelectionEvent> c)
/*    */   {
/* 96 */     new SelectionAdapter()
/*    */     {
/*    */       public void widgetDefaultSelected(SelectionEvent e) {
/* 99 */         this.val$c.accept(e);
/*    */       }
/*    */     };
/*    */   }
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/events/SelectionListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */