/*    */ package org.eclipse.swt.internal.image;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class LEDataOutputStream
/*    */   extends OutputStream
/*    */ {
/*    */   OutputStream out;
/*    */   
/*    */   public LEDataOutputStream(OutputStream output)
/*    */   {
/* 19 */     this.out = output;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void write(byte[] b, int off, int len)
/*    */     throws IOException
/*    */   {
/* 27 */     this.out.write(b, off, len);
/*    */   }
/*    */   
/*    */ 
/*    */   public void write(int b)
/*    */     throws IOException
/*    */   {
/* 34 */     this.out.write(b);
/*    */   }
/*    */   
/*    */   public void writeByte(byte b)
/*    */     throws IOException
/*    */   {
/* 40 */     this.out.write(b & 0xFF);
/*    */   }
/*    */   
/*    */ 
/*    */   public void writeInt(int theInt)
/*    */     throws IOException
/*    */   {
/* 47 */     this.out.write(theInt & 0xFF);
/* 48 */     this.out.write(theInt >> 8 & 0xFF);
/* 49 */     this.out.write(theInt >> 16 & 0xFF);
/* 50 */     this.out.write(theInt >> 24 & 0xFF);
/*    */   }
/*    */   
/*    */ 
/*    */   public void writeShort(int theShort)
/*    */     throws IOException
/*    */   {
/* 57 */     this.out.write(theShort & 0xFF);
/* 58 */     this.out.write(theShort >> 8 & 0xFF);
/*    */   }
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/internal/image/LEDataOutputStream.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */