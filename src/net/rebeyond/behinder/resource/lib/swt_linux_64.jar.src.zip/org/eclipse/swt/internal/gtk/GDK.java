/*      */ package org.eclipse.swt.internal.gtk;
/*      */ 
/*      */ import org.eclipse.swt.internal.Lock;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class GDK
/*      */   extends OS
/*      */ {
/*      */   public static final int GDK_2BUTTON_PRESS = 5;
/*      */   public static final int GDK_3BUTTON_PRESS = 6;
/*      */   public static final int GDK_ACTION_COPY = 2;
/*      */   public static final int GDK_ACTION_MOVE = 4;
/*      */   public static final int GDK_ACTION_LINK = 8;
/*      */   public static final int GDK_Alt_L = 65513;
/*      */   public static final int GDK_Alt_R = 65514;
/*      */   public static final int GDK_BackSpace = 65288;
/*      */   public static final int GDK_BOTTOM_LEFT_CORNER = 12;
/*      */   public static final int GDK_BOTTOM_RIGHT_CORNER = 14;
/*      */   public static final int GDK_BOTTOM_SIDE = 16;
/*      */   public static final int GDK_BUTTON1_MASK = 256;
/*      */   public static final int GDK_BUTTON2_MASK = 512;
/*      */   public static final int GDK_BUTTON3_MASK = 1024;
/*      */   public static final int GDK_BUTTON_MOTION_MASK = 16;
/*      */   public static final int GDK_BUTTON1_MOTION_MASK = 32;
/*      */   public static final int GDK_BUTTON2_MOTION_MASK = 64;
/*      */   public static final int GDK_BUTTON3_MOTION_MASK = 128;
/*      */   public static final int GDK_BUTTON_PRESS = 4;
/*      */   public static final int GDK_BUTTON_PRESS_MASK = 256;
/*      */   public static final int GDK_BUTTON_RELEASE = 7;
/*      */   public static final int GDK_BUTTON_RELEASE_MASK = 512;
/*      */   public static final int GDK_COLORSPACE_RGB = 0;
/*      */   public static final int GDK_CONFIGURE = 13;
/*      */   public static final int GDK_CONTROL_MASK = 4;
/*      */   public static final int GDK_CROSS = 30;
/*      */   public static final int GDK_CROSSING_NORMAL = 0;
/*      */   public static final int GDK_CROSSING_GRAB = 1;
/*      */   public static final int GDK_CROSSING_UNGRAB = 2;
/*      */   public static final int GDK_Break = 65387;
/*      */   public static final int GDK_Cancel = 65385;
/*      */   public static final int GDK_Caps_Lock = 65509;
/*      */   public static final int GDK_Clear = 65291;
/*      */   public static final int GDK_Control_L = 65507;
/*      */   public static final int GDK_Control_R = 65508;
/*      */   public static final int GDK_CURRENT_TIME = 0;
/*      */   public static final int GDK_DECOR_BORDER = 2;
/*      */   public static final int GDK_DECOR_MAXIMIZE = 64;
/*      */   public static final int GDK_DECOR_MENU = 16;
/*      */   public static final int GDK_DECOR_MINIMIZE = 32;
/*      */   public static final int GDK_DECOR_RESIZEH = 4;
/*      */   public static final int GDK_DECOR_TITLE = 8;
/*      */   public static final int GDK_DOUBLE_ARROW = 42;
/*      */   public static final int GDK_Delete = 65535;
/*      */   public static final int GDK_Down = 65364;
/*      */   public static final int GDK_ENTER_NOTIFY_MASK = 4096;
/*      */   public static final int GDK_ENTER_NOTIFY = 10;
/*      */   public static final int GDK_EVEN_ODD_RULE = 0;
/*      */   public static final int GDK_EXPOSE = 2;
/*      */   public static final int GDK_EXPOSURE_MASK = 2;
/*      */   public static final int GDK_End = 65367;
/*      */   public static final int GDK_Escape = 65307;
/*      */   public static final int GDK_ISO_Enter = 65076;
/*      */   public static final int GDK_F1 = 65470;
/*      */   public static final int GDK_F10 = 65479;
/*      */   public static final int GDK_F11 = 65480;
/*      */   public static final int GDK_F12 = 65481;
/*      */   public static final int GDK_F13 = 65482;
/*      */   public static final int GDK_F14 = 65483;
/*      */   public static final int GDK_F15 = 65484;
/*      */   public static final int GDK_F16 = 65485;
/*      */   public static final int GDK_F17 = 65486;
/*      */   public static final int GDK_F18 = 65487;
/*      */   public static final int GDK_F19 = 65488;
/*      */   public static final int GDK_F20 = 65489;
/*      */   public static final int GDK_F2 = 65471;
/*      */   public static final int GDK_F3 = 65472;
/*      */   public static final int GDK_F4 = 65473;
/*      */   public static final int GDK_F5 = 65474;
/*      */   public static final int GDK_F6 = 65475;
/*      */   public static final int GDK_F7 = 65476;
/*      */   public static final int GDK_F8 = 65477;
/*      */   public static final int GDK_F9 = 65478;
/*      */   public static final int GDK_KEY_a = 97;
/*      */   public static final int GDK_KEY_z = 122;
/*      */   public static final int GDK_FLEUR = 52;
/*      */   public static final int GDK_FOCUS_CHANGE = 12;
/*      */   public static final int GDK_FOCUS_CHANGE_MASK = 16384;
/*      */   public static final int GDK_FUNC_ALL = 1;
/*      */   public static final int GDK_FUNC_RESIZE = 2;
/*      */   public static final int GDK_FUNC_MOVE = 4;
/*      */   public static final int GDK_FUNC_MINIMIZE = 8;
/*      */   public static final int GDK_FUNC_MAXIMIZE = 16;
/*      */   public static final int GDK_FUNC_CLOSE = 32;
/*      */   public static final int GDK_GRAB_SUCCESS = 0;
/*      */   public static final int GDK_GRAVITY_NORTH_WEST = 1;
/*      */   public static final int GDK_GRAVITY_NORTH = 2;
/*      */   public static final int GDK_GRAVITY_NORTH_EAST = 3;
/*      */   public static final int GDK_GRAVITY_WEST = 4;
/*      */   public static final int GDK_GRAVITY_CENTER = 5;
/*      */   public static final int GDK_GRAVITY_EAST = 6;
/*      */   public static final int GDK_GRAVITY_SOUTH_WEST = 7;
/*      */   public static final int GDK_GRAVITY_SOUTH = 8;
/*      */   public static final int GDK_GRAVITY_SOUTH_EAST = 9;
/*      */   public static final int GDK_GRAVITY_STATIC = 10;
/*      */   public static final int GDK_HAND2 = 60;
/*      */   public static final int GDK_Help = 65386;
/*      */   public static final int GDK_HINT_MIN_SIZE = 2;
/*      */   public static final int GDK_Home = 65360;
/*      */   public static final int GDK_INCLUDE_INFERIORS = 1;
/*      */   public static final int GDK_INPUT_ONLY = 1;
/*      */   public static final int GDK_INTERP_BILINEAR = 2;
/*      */   public static final int GDK_Insert = 65379;
/*      */   public static final int GDK_ISO_Left_Tab = 65056;
/*      */   public static final int GDK_KEY_PRESS = 8;
/*      */   public static final int GDK_KEY_PRESS_MASK = 1024;
/*      */   public static final int GDK_KEY_RELEASE = 9;
/*      */   public static final int GDK_KEY_RELEASE_MASK = 2048;
/*      */   public static final int GDK_KP_0 = 65456;
/*      */   public static final int GDK_KP_1 = 65457;
/*      */   public static final int GDK_KP_2 = 65458;
/*      */   public static final int GDK_KP_3 = 65459;
/*      */   public static final int GDK_KP_4 = 65460;
/*      */   public static final int GDK_KP_5 = 65461;
/*      */   public static final int GDK_KP_6 = 65462;
/*      */   public static final int GDK_KP_7 = 65463;
/*      */   public static final int GDK_KP_8 = 65464;
/*      */   public static final int GDK_KP_9 = 65465;
/*      */   public static final int GDK_KP_Add = 65451;
/*      */   public static final int GDK_KP_Decimal = 65454;
/*      */   public static final int GDK_KP_Delete = 65439;
/*      */   public static final int GDK_KP_Divide = 65455;
/*      */   public static final int GDK_KP_Down = 65433;
/*      */   public static final int GDK_KP_End = 65436;
/*      */   public static final int GDK_KP_Enter = 65421;
/*      */   public static final int GDK_KP_Equal = 65469;
/*      */   public static final int GDK_KP_Home = 65429;
/*      */   public static final int GDK_KP_Insert = 65438;
/*      */   public static final int GDK_KP_Left = 65430;
/*      */   public static final int GDK_KP_Multiply = 65450;
/*      */   public static final int GDK_KP_Page_Down = 65435;
/*      */   public static final int GDK_KP_Page_Up = 65434;
/*      */   public static final int GDK_KP_Right = 65432;
/*      */   public static final int GDK_KP_Subtract = 65453;
/*      */   public static final int GDK_KP_Up = 65431;
/*      */   public static final int GDK_LEAVE_NOTIFY = 11;
/*      */   public static final int GDK_LEAVE_NOTIFY_MASK = 8192;
/*      */   public static final int GDK_LEFT_PTR = 68;
/*      */   public static final int GDK_LEFT_SIDE = 70;
/*      */   public static final int GDK_Linefeed = 65290;
/*      */   public static final int GDK_Left = 65361;
/*      */   public static final int GDK_Meta_L = 65511;
/*      */   public static final int GDK_Meta_R = 65512;
/*      */   public static final int GDK_MAP = 14;
/*      */   public static final int GDK_MOD1_MASK = 8;
/*      */   public static final int GDK_SUPER_MASK = 67108864;
/*      */   public static final int GDK_HYPER_MASK = 134217728;
/*      */   public static final int GDK_META_MASK = 268435456;
/*      */   public static final int GDK_MOTION_NOTIFY = 3;
/*      */   public static final int GDK_NO_EXPOSE = 30;
/*      */   public static final int GDK_NONE = 0;
/*      */   public static final int GDK_NOTIFY_INFERIOR = 2;
/*      */   public static final int GDK_Num_Lock = 65407;
/*      */   public static final int GDK_OVERLAP_RECTANGLE_OUT = 1;
/*      */   public static final int GDK_OWNERSHIP_NONE = 0;
/*      */   public static final int GDK_PIXBUF_ALPHA_BILEVEL = 0;
/*      */   public static final int GDK_POINTER_MOTION_HINT_MASK = 8;
/*      */   public static final int GDK_POINTER_MOTION_MASK = 4;
/*      */   public static final int GDK_PROPERTY_NOTIFY = 16;
/*      */   public static final int GDK_PROPERTY_CHANGE_MASK = 65536;
/*      */   public static final int GDK_Page_Down = 65366;
/*      */   public static final int GDK_Page_Up = 65365;
/*      */   public static final int GDK_Pause = 65299;
/*      */   public static final int GDK_Print = 65377;
/*      */   public static final int GDK_QUESTION_ARROW = 92;
/*      */   public static final int GDK_RIGHT_SIDE = 96;
/*      */   public static final int GDK_Return = 65293;
/*      */   public static final int GDK_Right = 65363;
/*      */   public static final int GDK_space = 32;
/*      */   public static final int GDK_SB_H_DOUBLE_ARROW = 108;
/*      */   public static final int GDK_SB_UP_ARROW = 114;
/*      */   public static final int GDK_SB_V_DOUBLE_ARROW = 116;
/*      */   public static final int GDK_SCROLL_UP = 0;
/*      */   public static final int GDK_SCROLL_DOWN = 1;
/*      */   public static final int GDK_SCROLL_LEFT = 2;
/*      */   public static final int GDK_SCROLL_RIGHT = 3;
/*      */   public static final int GDK_SCROLL_SMOOTH = 4;
/*      */   public static final int GDK_SCROLL_MASK = 2097152;
/*      */   public static final int GDK_SMOOTH_SCROLL_MASK = 8388608;
/*      */   public static final int GDK_SELECTION_CLEAR = 17;
/*      */   public static final int GDK_SELECTION_NOTIFY = 19;
/*      */   public static final int GDK_SELECTION_REQUEST = 18;
/*      */   public static final int GDK_SHIFT_MASK = 1;
/*      */   public static final int GDK_SIZING = 120;
/*      */   public static final int GDK_STIPPLED = 2;
/*      */   public static final int GDK_TILED = 1;
/*      */   public static final int GDK_Shift_L = 65505;
/*      */   public static final int GDK_Shift_R = 65506;
/*      */   public static final int GDK_SCROLL = 31;
/*      */   public static final int GDK_Scroll_Lock = 65300;
/*      */   public static final int GDK_TOP_LEFT_CORNER = 134;
/*      */   public static final int GDK_TOP_RIGHT_CORNER = 136;
/*      */   public static final int GDK_TOP_SIDE = 138;
/*      */   public static final int GDK_Tab = 65289;
/*      */   public static final int GDK_Up = 65362;
/*      */   public static final int GDK_WATCH = 150;
/*      */   public static final int GDK_XOR = 2;
/*      */   public static final int GDK_XTERM = 152;
/*      */   public static final int GDK_X_CURSOR = 0;
/*      */   public static final int GDK_WINDOW_CHILD = 2;
/*      */   public static final int GDK_WINDOW_STATE = 32;
/*      */   public static final int GDK_WINDOW_STATE_ICONIFIED = 2;
/*      */   public static final int GDK_WINDOW_STATE_MAXIMIZED = 4;
/*      */   public static final int GDK_WINDOW_STATE_FULLSCREEN = 16;
/*      */   public static final int GDK_UNMAP = 15;
/*      */   public static final int GDK_WA_X = 4;
/*      */   public static final int GDK_WA_Y = 8;
/*      */   public static final int GDK_WA_VISUAL = 64;
/*      */   public static final int GDK_WINDOW_TYPE_HINT_DIALOG = 1;
/*      */   public static final int GDK_WINDOW_TYPE_HINT_TOOLTIP = 10;
/*      */   
/*      */   public static final native int GdkColor_sizeof();
/*      */   
/*      */   public static final native int GdkKeymapKey_sizeof();
/*      */   
/*      */   public static final native int GdkRGBA_sizeof();
/*      */   
/*      */   public static final native int GdkDragContext_sizeof();
/*      */   
/*      */   public static final native int GdkEvent_sizeof();
/*      */   
/*      */   public static final native int GdkEventAny_sizeof();
/*      */   
/*      */   public static final native int GdkEventButton_sizeof();
/*      */   
/*      */   public static final native int GdkEventCrossing_sizeof();
/*      */   
/*      */   public static final native int GdkEventExpose_sizeof();
/*      */   
/*      */   public static final native int GdkEventFocus_sizeof();
/*      */   
/*      */   public static final native int GdkEventKey_sizeof();
/*      */   
/*      */   public static final native int GdkEventMotion_sizeof();
/*      */   
/*      */   public static final native int GdkEventScroll_sizeof();
/*      */   
/*      */   public static final native int GdkEventWindowState_sizeof();
/*      */   
/*      */   public static final native int GdkGeometry_sizeof();
/*      */   
/*      */   public static final native int GdkRectangle_sizeof();
/*      */   
/*      */   public static final native int GdkWindowAttr_sizeof();
/*      */   
/*      */   public static final native int GDK_EVENT_TYPE(long paramLong);
/*      */   
/*      */   public static final native long GDK_EVENT_WINDOW(long paramLong);
/*      */   
/*      */   public static final native boolean GDK_IS_X11_DISPLAY(long paramLong);
/*      */   
/*      */   public static final native long _GDK_PIXMAP_XID(long paramLong);
/*      */   
/*      */   public static final long GDK_PIXMAP_XID(long pixmap)
/*      */   {
/*  279 */     lock.lock();
/*      */     try {
/*  281 */       return _GDK_PIXMAP_XID(pixmap);
/*      */     } finally {
/*  283 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _GDK_TYPE_COLOR();
/*      */   
/*      */   public static final long GDK_TYPE_COLOR() {
/*  290 */     lock.lock();
/*      */     try {
/*  292 */       return _GDK_TYPE_COLOR();
/*      */     } finally {
/*  294 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _GDK_TYPE_RGBA();
/*      */   
/*  300 */   public static final long GDK_TYPE_RGBA() { lock.lock();
/*  301 */     assert (GTK.GTK3) : "GTK3 code was run by GTK2";
/*      */     try {
/*  303 */       return _GDK_TYPE_RGBA();
/*      */     } finally {
/*  305 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _GDK_TYPE_PIXBUF();
/*      */   
/*  311 */   public static final long GDK_TYPE_PIXBUF() { lock.lock();
/*      */     try {
/*  313 */       return _GDK_TYPE_PIXBUF();
/*      */     } finally {
/*  315 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gdk_x11_display_get_xdisplay(long paramLong);
/*      */   
/*      */   public static final long gdk_x11_display_get_xdisplay(long gdkdisplay) {
/*  322 */     lock.lock();
/*      */     try {
/*  324 */       return _gdk_x11_display_get_xdisplay(gdkdisplay);
/*      */     } finally {
/*  326 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gdk_x11_drawable_get_xid(long paramLong);
/*      */   
/*  332 */   public static final long gdk_x11_drawable_get_xid(long drawable) { lock.lock();
/*      */     try {
/*  334 */       return _gdk_x11_drawable_get_xid(drawable);
/*      */     } finally {
/*  336 */       lock.unlock();
/*      */     } }
/*      */   
/*      */   public static final native long _gdk_x11_get_default_xdisplay();
/*      */   
/*  341 */   public static final long gdk_x11_get_default_xdisplay() { lock.lock();
/*      */     try {
/*  343 */       return _gdk_x11_get_default_xdisplay();
/*      */     } finally {
/*  345 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native long _gdk_x11_screen_lookup_visual(long paramLong, int paramInt);
/*      */   
/*      */ 
/*      */   public static final long gdk_x11_screen_lookup_visual(long screen, int xvisualid)
/*      */   {
/*  355 */     lock.lock();
/*      */     try {
/*  357 */       return _gdk_x11_screen_lookup_visual(screen, xvisualid);
/*      */     } finally {
/*  359 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native long _gdk_x11_screen_get_window_manager_name(long paramLong);
/*      */   
/*      */   public static final long gdk_x11_screen_get_window_manager_name(long screen)
/*      */   {
/*  368 */     lock.lock();
/*      */     try {
/*  370 */       return _gdk_x11_screen_get_window_manager_name(screen);
/*      */     } finally {
/*  372 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gdk_x11_visual_get_xvisual(long paramLong);
/*      */   
/*  378 */   public static final long gdk_x11_visual_get_xvisual(long visual) { lock.lock();
/*      */     try {
/*  380 */       return _gdk_x11_visual_get_xvisual(visual);
/*      */     } finally {
/*  382 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native long _gdk_x11_window_get_xid(long paramLong);
/*      */   
/*      */   public static final long gdk_x11_window_get_xid(long gdkwindow)
/*      */   {
/*  391 */     lock.lock();
/*      */     try {
/*  393 */       return _gdk_x11_window_get_xid(gdkwindow);
/*      */     } finally {
/*  395 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native long _gdk_x11_window_lookup_for_display(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final long gdk_x11_window_lookup_for_display(long gdkdisplay, long xid)
/*      */   {
/*  404 */     lock.lock();
/*      */     try {
/*  406 */       return _gdk_x11_window_lookup_for_display(gdkdisplay, xid);
/*      */     } finally {
/*  408 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gdk_window_add_filter(long paramLong1, long paramLong2, long paramLong3);
/*      */   
/*      */ 
/*      */   public static final void gdk_window_add_filter(long window, long function, long data)
/*      */   {
/*  418 */     lock.lock();
/*      */     try {
/*  420 */       _gdk_window_add_filter(window, function, data);
/*      */     } finally {
/*  422 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gdk_window_remove_filter(long paramLong1, long paramLong2, long paramLong3);
/*      */   
/*      */ 
/*      */   public static final void gdk_window_remove_filter(long window, long function, long data)
/*      */   {
/*  432 */     lock.lock();
/*      */     try {
/*  434 */       _gdk_window_remove_filter(window, function, data);
/*      */     } finally {
/*  436 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gdk_atom_intern(byte[] paramArrayOfByte, boolean paramBoolean);
/*      */   
/*  442 */   public static final long gdk_atom_intern(byte[] atom_name, boolean only_if_exists) { lock.lock();
/*      */     try {
/*  444 */       return _gdk_atom_intern(atom_name, only_if_exists);
/*      */     } finally {
/*  446 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gdk_atom_name(long paramLong);
/*      */   
/*  452 */   public static final long gdk_atom_name(long atom) { lock.lock();
/*      */     try {
/*  454 */       return _gdk_atom_name(atom);
/*      */     } finally {
/*  456 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gdk_display_beep(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void gdk_display_beep(long display)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 26	org/eclipse/swt/internal/gtk/GDK:_gdk_display_beep	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #464	-> byte code offset #0
/*      */     //   Java source line #466	-> byte code offset #7
/*      */     //   Java source line #468	-> byte code offset #11
/*      */     //   Java source line #469	-> byte code offset #17
/*      */     //   Java source line #468	-> byte code offset #20
/*      */     //   Java source line #469	-> byte code offset #27
/*      */     //   Java source line #470	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	display	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native long _gdk_bitmap_create_from_data(long paramLong, byte[] paramArrayOfByte, int paramInt1, int paramInt2);
/*      */   
/*      */   public static final long gdk_bitmap_create_from_data(long window, byte[] data, int width, int height)
/*      */   {
/*  480 */     lock.lock();
/*      */     try {
/*  482 */       return _gdk_bitmap_create_from_data(window, data, width, height);
/*      */     } finally {
/*  484 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gdk_cairo_create(long paramLong);
/*      */   
/*  490 */   public static final long gdk_cairo_create(long drawable) { lock.lock();
/*      */     try {
/*  492 */       return _gdk_cairo_create(drawable);
/*      */     } finally {
/*  494 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native boolean _gdk_cairo_get_clip_rectangle(long paramLong, GdkRectangle paramGdkRectangle);
/*      */   
/*  500 */   public static final boolean gdk_cairo_get_clip_rectangle(long cr, GdkRectangle rect) { lock.lock();
/*      */     try {
/*  502 */       return _gdk_cairo_get_clip_rectangle(cr, rect);
/*      */     } finally {
/*  504 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gdk_cairo_region(long paramLong1, long paramLong2);
/*      */   
/*  510 */   public static final void gdk_cairo_region(long cairo, long region) { lock.lock();
/*      */     try {
/*  512 */       _gdk_cairo_region(cairo, region);
/*      */     } finally {
/*  514 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gdk_cairo_reset_clip(long paramLong1, long paramLong2);
/*      */   
/*  520 */   public static final void gdk_cairo_reset_clip(long cairo, long drawable) { lock.lock();
/*      */     try {
/*  522 */       _gdk_cairo_reset_clip(cairo, drawable);
/*      */     } finally {
/*  524 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gdk_cairo_set_source_color(long paramLong, GdkColor paramGdkColor);
/*      */   
/*      */   /* Error */
/*      */   public static final void gdk_cairo_set_source_color(long cairo, GdkColor color)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: aload_2
/*      */     //   9: invokestatic 32	org/eclipse/swt/internal/gtk/GDK:_gdk_cairo_set_source_color	(JLorg/eclipse/swt/internal/gtk/GdkColor;)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #530	-> byte code offset #0
/*      */     //   Java source line #532	-> byte code offset #7
/*      */     //   Java source line #534	-> byte code offset #12
/*      */     //   Java source line #535	-> byte code offset #18
/*      */     //   Java source line #534	-> byte code offset #21
/*      */     //   Java source line #535	-> byte code offset #28
/*      */     //   Java source line #536	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	cairo	long
/*      */     //   0	31	2	color	GdkColor
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gdk_cairo_set_source_rgba(long paramLong, GdkRGBA paramGdkRGBA);
/*      */   
/*      */   /* Error */
/*      */   public static final void gdk_cairo_set_source_rgba(long cairo, GdkRGBA rgba)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: aload_2
/*      */     //   9: invokestatic 33	org/eclipse/swt/internal/gtk/GDK:_gdk_cairo_set_source_rgba	(JLorg/eclipse/swt/internal/gtk/GdkRGBA;)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #540	-> byte code offset #0
/*      */     //   Java source line #542	-> byte code offset #7
/*      */     //   Java source line #544	-> byte code offset #12
/*      */     //   Java source line #545	-> byte code offset #18
/*      */     //   Java source line #544	-> byte code offset #21
/*      */     //   Java source line #545	-> byte code offset #28
/*      */     //   Java source line #546	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	cairo	long
/*      */     //   0	31	2	rgba	GdkRGBA
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native int _gdk_window_get_width(long paramLong);
/*      */   
/*      */   public static final int gdk_window_get_width(long window)
/*      */   {
/*  553 */     lock.lock();
/*      */     try {
/*  555 */       return _gdk_window_get_width(window);
/*      */     } finally {
/*  557 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native long _gdk_window_get_visible_region(long paramLong);
/*      */   
/*      */   public static final long gdk_window_get_visible_region(long window)
/*      */   {
/*  566 */     lock.lock();
/*      */     try {
/*  568 */       return _gdk_window_get_visible_region(window);
/*      */     } finally {
/*  570 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native int _gdk_window_get_height(long paramLong);
/*      */   
/*      */   public static final int gdk_window_get_height(long window)
/*      */   {
/*  579 */     lock.lock();
/*      */     try {
/*  581 */       return _gdk_window_get_height(window);
/*      */     } finally {
/*  583 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gdk_cairo_set_source_pixbuf(long paramLong1, long paramLong2, double paramDouble1, double paramDouble2);
/*      */   
/*      */   public static final void gdk_cairo_set_source_pixbuf(long cairo, long pixbuf, double pixbuf_x, double pixbuf_y)
/*      */   {
/*  592 */     lock.lock();
/*      */     try {
/*  594 */       _gdk_cairo_set_source_pixbuf(cairo, pixbuf, pixbuf_x, pixbuf_y);
/*      */     }
/*      */     finally {
/*  597 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gdk_cairo_set_source_pixmap(long paramLong1, long paramLong2, double paramDouble1, double paramDouble2);
/*      */   
/*      */   public static final void gdk_cairo_set_source_pixmap(long cairo, long pixmap, double pixbuf_x, double pixbuf_y)
/*      */   {
/*  605 */     lock.lock();
/*      */     try {
/*  607 */       _gdk_cairo_set_source_pixmap(cairo, pixmap, pixbuf_x, pixbuf_y);
/*      */     }
/*      */     finally {
/*  610 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gdk_cairo_set_source_window(long paramLong1, long paramLong2, int paramInt1, int paramInt2);
/*      */   
/*      */   public static final void gdk_cairo_set_source_window(long cairo, long window, int x, int y)
/*      */   {
/*  619 */     lock.lock();
/*      */     try {
/*  621 */       _gdk_cairo_set_source_window(cairo, window, x, y);
/*      */     }
/*      */     finally {
/*  624 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gdk_color_free(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void gdk_color_free(long color)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: getstatic 7	org/eclipse/swt/internal/gtk/GDK:$assertionsDisabled	Z
/*      */     //   10: ifne +19 -> 29
/*      */     //   13: getstatic 8	org/eclipse/swt/internal/gtk/GTK:GTK3	Z
/*      */     //   16: ifeq +13 -> 29
/*      */     //   19: new 9	java/lang/AssertionError
/*      */     //   22: dup
/*      */     //   23: ldc 40
/*      */     //   25: invokespecial 11	java/lang/AssertionError:<init>	(Ljava/lang/Object;)V
/*      */     //   28: athrow
/*      */     //   29: lload_0
/*      */     //   30: invokestatic 41	org/eclipse/swt/internal/gtk/GDK:_gdk_color_free	(J)V
/*      */     //   33: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   36: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   39: goto +12 -> 51
/*      */     //   42: astore_2
/*      */     //   43: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   46: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   49: aload_2
/*      */     //   50: athrow
/*      */     //   51: return
/*      */     // Line number table:
/*      */     //   Java source line #632	-> byte code offset #0
/*      */     //   Java source line #633	-> byte code offset #7
/*      */     //   Java source line #635	-> byte code offset #29
/*      */     //   Java source line #637	-> byte code offset #33
/*      */     //   Java source line #638	-> byte code offset #39
/*      */     //   Java source line #637	-> byte code offset #42
/*      */     //   Java source line #638	-> byte code offset #49
/*      */     //   Java source line #639	-> byte code offset #51
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	52	0	color	long
/*      */     //   42	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   29	33	42	finally
/*      */   }
/*      */   
/*      */   public static final native boolean _gdk_color_parse(byte[] paramArrayOfByte, GdkColor paramGdkColor);
/*      */   
/*      */   public static final boolean gdk_color_parse(byte[] spec, GdkColor color)
/*      */   {
/*  647 */     lock.lock();
/*  648 */     assert (!GTK.GTK3) : "GTK2 code was run by GTK3";
/*      */     try {
/*  650 */       return _gdk_color_parse(spec, color);
/*      */     } finally {
/*  652 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native boolean _gdk_color_white(long paramLong, GdkColor paramGdkColor);
/*      */   
/*      */   public static final boolean gdk_color_white(long colormap, GdkColor color)
/*      */   {
/*  661 */     lock.lock();
/*      */     try {
/*  663 */       return _gdk_color_white(colormap, color);
/*      */     } finally {
/*  665 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final native boolean _gdk_colormap_alloc_color(long paramLong, GdkColor paramGdkColor, boolean paramBoolean1, boolean paramBoolean2);
/*      */   
/*      */ 
/*      */   public static final boolean gdk_colormap_alloc_color(long colormap, GdkColor color, boolean writeable, boolean best_match)
/*      */   {
/*  676 */     lock.lock();
/*      */     try {
/*  678 */       return _gdk_colormap_alloc_color(colormap, color, writeable, best_match);
/*      */     } finally {
/*  680 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gdk_colormap_free_colors(long paramLong, GdkColor paramGdkColor, int paramInt);
/*      */   
/*      */ 
/*      */   public static final void gdk_colormap_free_colors(long colormap, GdkColor colors, int ncolors)
/*      */   {
/*  690 */     lock.lock();
/*      */     try {
/*  692 */       _gdk_colormap_free_colors(colormap, colors, ncolors);
/*      */     } finally {
/*  694 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gdk_colormap_get_system();
/*      */   
/*  700 */   public static final long gdk_colormap_get_system() { lock.lock();
/*      */     try {
/*  702 */       return _gdk_colormap_get_system();
/*      */     } finally {
/*  704 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gdk_cursor_unref(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void gdk_cursor_unref(long cursor)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 47	org/eclipse/swt/internal/gtk/GDK:_gdk_cursor_unref	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #710	-> byte code offset #0
/*      */     //   Java source line #712	-> byte code offset #7
/*      */     //   Java source line #714	-> byte code offset #11
/*      */     //   Java source line #715	-> byte code offset #17
/*      */     //   Java source line #714	-> byte code offset #20
/*      */     //   Java source line #715	-> byte code offset #27
/*      */     //   Java source line #716	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	cursor	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native long _gdk_cursor_new_for_display(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final long gdk_cursor_new_for_display(long display, long cursor_type)
/*      */   {
/*  722 */     lock.lock();
/*      */     try {
/*  724 */       return _gdk_cursor_new_for_display(display, cursor_type);
/*      */     } finally {
/*  726 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gdk_cursor_new_from_name(long paramLong, byte[] paramArrayOfByte);
/*      */   
/*      */   public static final long gdk_cursor_new_from_name(long display, byte[] cursor_name)
/*      */   {
/*  734 */     lock.lock();
/*      */     try {
/*  736 */       return _gdk_cursor_new_from_name(display, cursor_name);
/*      */     } finally {
/*  738 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final native long _gdk_cursor_new_from_pixmap(long paramLong1, long paramLong2, GdkColor paramGdkColor1, GdkColor paramGdkColor2, int paramInt1, int paramInt2);
/*      */   
/*      */ 
/*      */ 
/*      */   public static final long gdk_cursor_new_from_pixmap(long source, long mask, GdkColor fg, GdkColor bg, int x, int y)
/*      */   {
/*  750 */     lock.lock();
/*      */     try {
/*  752 */       return _gdk_cursor_new_from_pixmap(source, mask, fg, bg, x, y);
/*      */     } finally {
/*  754 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gdk_cursor_new_from_pixbuf(long paramLong1, long paramLong2, int paramInt1, int paramInt2);
/*      */   
/*  760 */   public static final long gdk_cursor_new_from_pixbuf(long display, long pixbuf, int x, int y) { lock.lock();
/*      */     try {
/*  762 */       return _gdk_cursor_new_from_pixbuf(display, pixbuf, x, y);
/*      */     } finally {
/*  764 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gdk_display_warp_pointer(long paramLong1, long paramLong2, int paramInt1, int paramInt2);
/*      */   
/*  770 */   public static final void gdk_display_warp_pointer(long device, long screen, int x, int y) { lock.lock();
/*      */     try {
/*  772 */       _gdk_display_warp_pointer(device, screen, x, y);
/*      */     } finally {
/*  774 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gdk_device_warp(long paramLong1, long paramLong2, int paramInt1, int paramInt2);
/*      */   
/*  780 */   public static final void gdk_device_warp(long device, long screen, int x, int y) { lock.lock();
/*      */     try {
/*  782 */       _gdk_device_warp(device, screen, x, y);
/*      */     } finally {
/*  784 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gdk_display_get_default();
/*      */   
/*  790 */   public static final long gdk_display_get_default() { lock.lock();
/*      */     try {
/*  792 */       return _gdk_display_get_default();
/*      */     } finally {
/*  794 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gdk_display_get_default_group(long paramLong);
/*      */   
/*      */   public static final long gdk_display_get_default_group(long display)
/*      */   {
/*  802 */     lock.lock();
/*      */     try {
/*  804 */       return _gdk_display_get_default_group(display);
/*      */     } finally {
/*  806 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gdk_display_get_default_seat(long paramLong);
/*      */   
/*      */   public static final long gdk_display_get_default_seat(long display)
/*      */   {
/*  814 */     lock.lock();
/*      */     try {
/*  816 */       return _gdk_display_get_default_seat(display);
/*      */     } finally {
/*  818 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native long _gdk_window_get_display(long paramLong);
/*      */   
/*      */   public static final long gdk_window_get_display(long window)
/*      */   {
/*  827 */     lock.lock();
/*      */     try {
/*  829 */       return _gdk_window_get_display(window);
/*      */     } finally {
/*  831 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native long _gdk_display_get_device_manager(long paramLong);
/*      */   
/*      */   public static final long gdk_display_get_device_manager(long display)
/*      */   {
/*  840 */     lock.lock();
/*      */     try {
/*  842 */       return _gdk_display_get_device_manager(display);
/*      */     } finally {
/*  844 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gdk_device_manager_get_client_pointer(long paramLong);
/*      */   
/*  850 */   public static final long gdk_device_manager_get_client_pointer(long device_manager) { lock.lock();
/*      */     try {
/*  852 */       return _gdk_device_manager_get_client_pointer(device_manager);
/*      */     } finally {
/*  854 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native long _gdk_device_get_window_at_position(long paramLong, int[] paramArrayOfInt1, int[] paramArrayOfInt2);
/*      */   
/*      */ 
/*      */   public static final long gdk_device_get_window_at_position(long device, int[] win_x, int[] win_y)
/*      */   {
/*  864 */     lock.lock();
/*      */     try {
/*  866 */       return _gdk_device_get_window_at_position(device, win_x, win_y);
/*      */     } finally {
/*  868 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native boolean _gdk_display_supports_cursor_color(long paramLong);
/*      */   
/*  874 */   public static final boolean gdk_display_supports_cursor_color(long display) { lock.lock();
/*      */     try {
/*  876 */       return _gdk_display_supports_cursor_color(display);
/*      */     } finally {
/*  878 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native int _gdk_drag_context_get_actions(long paramLong);
/*      */   
/*      */   public static final int gdk_drag_context_get_actions(long context)
/*      */   {
/*  887 */     lock.lock();
/*      */     try {
/*  889 */       return _gdk_drag_context_get_actions(context);
/*      */     } finally {
/*  891 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native long _gdk_drag_context_get_dest_window(long paramLong);
/*      */   
/*      */   public static final long gdk_drag_context_get_dest_window(long context)
/*      */   {
/*  900 */     lock.lock();
/*      */     try {
/*  902 */       return _gdk_drag_context_get_dest_window(context);
/*      */     } finally {
/*  904 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native int _gdk_drag_context_get_selected_action(long paramLong);
/*      */   
/*      */   public static final int gdk_drag_context_get_selected_action(long context)
/*      */   {
/*  913 */     lock.lock();
/*      */     try {
/*  915 */       return _gdk_drag_context_get_selected_action(context);
/*      */     } finally {
/*  917 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native long _gdk_drag_context_list_targets(long paramLong);
/*      */   
/*      */   public static final long gdk_drag_context_list_targets(long context)
/*      */   {
/*  926 */     lock.lock();
/*      */     try {
/*  928 */       return _gdk_drag_context_list_targets(context);
/*      */     } finally {
/*  930 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gdk_drag_status(long paramLong, int paramInt1, int paramInt2);
/*      */   
/*      */ 
/*      */   public static final void gdk_drag_status(long context, int action, int time)
/*      */   {
/*  940 */     lock.lock();
/*      */     try {
/*  942 */       _gdk_drag_status(context, action, time);
/*      */     } finally {
/*  944 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final native void _gdk_draw_arc(long paramLong1, long paramLong2, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void gdk_draw_arc(long drawable, long gc, int filled, int x, int y, int width, int height, int angle1, int angle2)
/*      */   {
/*  959 */     lock.lock();
/*      */     try {
/*  961 */       _gdk_draw_arc(drawable, gc, filled, x, y, width, height, angle1, angle2);
/*      */     } finally {
/*  963 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gdk_draw_image(long paramLong1, long paramLong2, long paramLong3, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6);
/*      */   
/*      */   public static final void gdk_draw_image(long drawable, long gc, long image, int xsrc, int ysrc, int xdest, int ydest, int width, int height)
/*      */   {
/*  971 */     lock.lock();
/*      */     try {
/*  973 */       _gdk_draw_image(drawable, gc, image, xsrc, ysrc, xdest, ydest, width, height);
/*      */     } finally {
/*  975 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final native void _gdk_draw_pixbuf(long paramLong1, long paramLong2, long paramLong3, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void gdk_draw_pixbuf(long drawable, long gc, long pixbuf, int xsrc, int ysrc, int xdest, int ydest, int width, int height, int dither, int x_dither, int y_dither)
/*      */   {
/*  991 */     lock.lock();
/*      */     try {
/*  993 */       _gdk_draw_pixbuf(drawable, gc, pixbuf, xsrc, ysrc, xdest, ydest, width, height, dither, x_dither, y_dither);
/*      */     } finally {
/*  995 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final native void _gdk_draw_rectangle(long paramLong1, long paramLong2, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5);
/*      */   
/*      */ 
/*      */ 
/*      */   public static final void gdk_draw_rectangle(long drawable, long gc, int filled, int x, int y, int width, int height)
/*      */   {
/* 1008 */     lock.lock();
/*      */     try {
/* 1010 */       _gdk_draw_rectangle(drawable, gc, filled, x, y, width, height);
/*      */     } finally {
/* 1012 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native int _gdk_drawable_get_depth(long paramLong);
/*      */   
/* 1018 */   public static final int gdk_drawable_get_depth(long drawable) { lock.lock();
/*      */     try {
/* 1020 */       return _gdk_drawable_get_depth(drawable);
/*      */     } finally {
/* 1022 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final native void _gdk_pixmap_get_size(long paramLong, int[] paramArrayOfInt1, int[] paramArrayOfInt2);
/*      */   
/*      */ 
/*      */   public static final void gdk_pixmap_get_size(long pixmap, int[] width, int[] height)
/*      */   {
/* 1033 */     lock.lock();
/*      */     try {
/* 1035 */       _gdk_pixmap_get_size(pixmap, width, height);
/*      */     } finally {
/* 1037 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final native long _gdk_drawable_get_image(long paramLong, int paramInt1, int paramInt2, int paramInt3, int paramInt4);
/*      */   
/*      */ 
/*      */ 
/*      */   public static final long gdk_drawable_get_image(long drawable, int x, int y, int width, int height)
/*      */   {
/* 1049 */     lock.lock();
/*      */     try {
/* 1051 */       return _gdk_drawable_get_image(drawable, x, y, width, height);
/*      */     } finally {
/* 1053 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gdk_drawable_get_visible_region(long paramLong);
/*      */   
/* 1059 */   public static final long gdk_drawable_get_visible_region(long drawable) { lock.lock();
/*      */     try {
/* 1061 */       return _gdk_drawable_get_visible_region(drawable);
/*      */     } finally {
/* 1063 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gdk_event_copy(long paramLong);
/*      */   
/* 1069 */   public static final long gdk_event_copy(long event) { lock.lock();
/*      */     try {
/* 1071 */       return _gdk_event_copy(event);
/*      */     } finally {
/* 1073 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gdk_event_free(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void gdk_event_free(long event)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 76	org/eclipse/swt/internal/gtk/GDK:_gdk_event_free	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #1079	-> byte code offset #0
/*      */     //   Java source line #1081	-> byte code offset #7
/*      */     //   Java source line #1083	-> byte code offset #11
/*      */     //   Java source line #1084	-> byte code offset #17
/*      */     //   Java source line #1083	-> byte code offset #20
/*      */     //   Java source line #1084	-> byte code offset #27
/*      */     //   Java source line #1085	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	event	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native long _gdk_event_get();
/*      */   
/*      */   public static final long gdk_event_get()
/*      */   {
/* 1088 */     lock.lock();
/*      */     try {
/* 1090 */       return _gdk_event_get();
/*      */     } finally {
/* 1092 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native boolean _gdk_event_get_coords(long paramLong, double[] paramArrayOfDouble1, double[] paramArrayOfDouble2);
/*      */   
/*      */ 
/*      */   public static final boolean gdk_event_get_coords(long event, double[] px, double[] py)
/*      */   {
/* 1102 */     lock.lock();
/*      */     try {
/* 1104 */       return _gdk_event_get_coords(event, px, py);
/*      */     } finally {
/* 1106 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native boolean _gdk_event_get_state(long paramLong, int[] paramArrayOfInt);
/*      */   
/*      */   public static final boolean gdk_event_get_state(long event, int[] pmod)
/*      */   {
/* 1115 */     lock.lock();
/*      */     try {
/* 1117 */       return _gdk_event_get_state(event, pmod);
/*      */     } finally {
/* 1119 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native boolean _gdk_event_get_scroll_deltas(long paramLong, double[] paramArrayOfDouble1, double[] paramArrayOfDouble2);
/*      */   
/*      */   public static final boolean gdk_event_get_scroll_deltas(long event, double[] delta_x, double[] delta_y)
/*      */   {
/* 1128 */     lock.lock();
/*      */     try {
/* 1130 */       return _gdk_event_get_scroll_deltas(event, delta_x, delta_y);
/*      */     } finally {
/* 1132 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gdk_event_get_seat(long paramLong);
/*      */   
/*      */   public static final long gdk_event_get_seat(long event)
/*      */   {
/* 1140 */     lock.lock();
/*      */     try {
/* 1142 */       return _gdk_event_get_seat(event);
/*      */     } finally {
/* 1144 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native int _gdk_event_get_time(long paramLong);
/*      */   
/* 1150 */   public static final int gdk_event_get_time(long event) { lock.lock();
/*      */     try {
/* 1152 */       return _gdk_event_get_time(event);
/*      */     } finally {
/* 1154 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native int _gdk_event_get_event_type(long paramLong);
/*      */   
/*      */ 
/*      */   public static final int gdk_event_get_event_type(long event)
/*      */   {
/* 1164 */     lock.lock();
/*      */     try {
/* 1166 */       return _gdk_event_get_event_type(event);
/*      */     } finally {
/* 1168 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gdk_event_handler_set(long paramLong1, long paramLong2, long paramLong3);
/*      */   
/*      */ 
/*      */   public static final void gdk_event_handler_set(long func, long data, long notify)
/*      */   {
/* 1178 */     lock.lock();
/*      */     try {
/* 1180 */       _gdk_event_handler_set(func, data, notify);
/*      */     } finally {
/* 1182 */       lock.unlock();
/*      */     } }
/*      */   
/*      */   public static final native long _gdk_event_new(int paramInt);
/*      */   
/* 1187 */   public static final long gdk_event_new(int type) { lock.lock();
/*      */     try {
/* 1189 */       return _gdk_event_new(type);
/*      */     } finally {
/* 1191 */       lock.unlock();
/*      */     } }
/*      */   
/*      */   public static final native long _gdk_event_peek();
/*      */   
/* 1196 */   public static final long gdk_event_peek() { lock.lock();
/*      */     try {
/* 1198 */       return _gdk_event_peek();
/*      */     } finally {
/* 1200 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gdk_event_put(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void gdk_event_put(long event)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 87	org/eclipse/swt/internal/gtk/GDK:_gdk_event_put	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #1206	-> byte code offset #0
/*      */     //   Java source line #1208	-> byte code offset #7
/*      */     //   Java source line #1210	-> byte code offset #11
/*      */     //   Java source line #1211	-> byte code offset #17
/*      */     //   Java source line #1210	-> byte code offset #20
/*      */     //   Java source line #1211	-> byte code offset #27
/*      */     //   Java source line #1212	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	event	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native void _gdk_x11_display_error_trap_push(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void gdk_x11_display_error_trap_push(long display)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 88	org/eclipse/swt/internal/gtk/GDK:_gdk_x11_display_error_trap_push	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #1219	-> byte code offset #0
/*      */     //   Java source line #1221	-> byte code offset #7
/*      */     //   Java source line #1223	-> byte code offset #11
/*      */     //   Java source line #1224	-> byte code offset #17
/*      */     //   Java source line #1223	-> byte code offset #20
/*      */     //   Java source line #1224	-> byte code offset #27
/*      */     //   Java source line #1225	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	display	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native void _gdk_error_trap_push();
/*      */   
/*      */   /* Error */
/*      */   public static final void gdk_error_trap_push()
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: invokestatic 89	org/eclipse/swt/internal/gtk/GDK:_gdk_error_trap_push	()V
/*      */     //   10: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   13: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   16: goto +12 -> 28
/*      */     //   19: astore_0
/*      */     //   20: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   23: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   26: aload_0
/*      */     //   27: athrow
/*      */     //   28: return
/*      */     // Line number table:
/*      */     //   Java source line #1231	-> byte code offset #0
/*      */     //   Java source line #1233	-> byte code offset #7
/*      */     //   Java source line #1235	-> byte code offset #10
/*      */     //   Java source line #1236	-> byte code offset #16
/*      */     //   Java source line #1235	-> byte code offset #19
/*      */     //   Java source line #1236	-> byte code offset #26
/*      */     //   Java source line #1237	-> byte code offset #28
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   19	8	0	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	10	19	finally
/*      */   }
/*      */   
/*      */   public static final native void _gdk_x11_display_error_trap_pop_ignored(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void gdk_x11_display_error_trap_pop_ignored(long display)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 90	org/eclipse/swt/internal/gtk/GDK:_gdk_x11_display_error_trap_pop_ignored	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #1244	-> byte code offset #0
/*      */     //   Java source line #1246	-> byte code offset #7
/*      */     //   Java source line #1248	-> byte code offset #11
/*      */     //   Java source line #1249	-> byte code offset #17
/*      */     //   Java source line #1248	-> byte code offset #20
/*      */     //   Java source line #1249	-> byte code offset #27
/*      */     //   Java source line #1250	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	display	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native int _gdk_error_trap_pop();
/*      */   
/*      */   public static final int gdk_error_trap_pop()
/*      */   {
/* 1256 */     lock.lock();
/*      */     try {
/* 1258 */       return _gdk_error_trap_pop();
/*      */     } finally {
/* 1260 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gdk_flush();
/*      */   
/*      */   /* Error */
/*      */   public static final void gdk_flush()
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: invokestatic 92	org/eclipse/swt/internal/gtk/GDK:_gdk_flush	()V
/*      */     //   10: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   13: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   16: goto +12 -> 28
/*      */     //   19: astore_0
/*      */     //   20: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   23: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   26: aload_0
/*      */     //   27: athrow
/*      */     //   28: return
/*      */     // Line number table:
/*      */     //   Java source line #1265	-> byte code offset #0
/*      */     //   Java source line #1267	-> byte code offset #7
/*      */     //   Java source line #1269	-> byte code offset #10
/*      */     //   Java source line #1270	-> byte code offset #16
/*      */     //   Java source line #1269	-> byte code offset #19
/*      */     //   Java source line #1270	-> byte code offset #26
/*      */     //   Java source line #1271	-> byte code offset #28
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   19	8	0	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	10	19	finally
/*      */   }
/*      */   
/*      */   public static final native long _gdk_gc_new(long paramLong);
/*      */   
/*      */   public static final long gdk_gc_new(long window)
/*      */   {
/* 1275 */     lock.lock();
/*      */     try {
/* 1277 */       return _gdk_gc_new(window);
/*      */     } finally {
/* 1279 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gdk_gc_set_fill(long paramLong, int paramInt);
/*      */   
/*      */   /* Error */
/*      */   public static final void gdk_gc_set_fill(long gc, int fill)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 94	org/eclipse/swt/internal/gtk/GDK:_gdk_gc_set_fill	(JI)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #1285	-> byte code offset #0
/*      */     //   Java source line #1287	-> byte code offset #7
/*      */     //   Java source line #1289	-> byte code offset #12
/*      */     //   Java source line #1290	-> byte code offset #18
/*      */     //   Java source line #1289	-> byte code offset #21
/*      */     //   Java source line #1290	-> byte code offset #28
/*      */     //   Java source line #1291	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	gc	long
/*      */     //   0	31	2	fill	int
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gdk_gc_set_foreground(long paramLong, GdkColor paramGdkColor);
/*      */   
/*      */   /* Error */
/*      */   public static final void gdk_gc_set_foreground(long gc, GdkColor color)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: aload_2
/*      */     //   9: invokestatic 95	org/eclipse/swt/internal/gtk/GDK:_gdk_gc_set_foreground	(JLorg/eclipse/swt/internal/gtk/GdkColor;)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #1298	-> byte code offset #0
/*      */     //   Java source line #1300	-> byte code offset #7
/*      */     //   Java source line #1302	-> byte code offset #12
/*      */     //   Java source line #1303	-> byte code offset #18
/*      */     //   Java source line #1302	-> byte code offset #21
/*      */     //   Java source line #1303	-> byte code offset #28
/*      */     //   Java source line #1304	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	gc	long
/*      */     //   0	31	2	color	GdkColor
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gdk_gc_set_function(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final void gdk_gc_set_function(long gc, long function)
/*      */   {
/* 1310 */     lock.lock();
/*      */     try {
/* 1312 */       _gdk_gc_set_function(gc, function);
/*      */     } finally {
/* 1314 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gdk_gc_set_stipple(long paramLong1, long paramLong2);
/*      */   
/* 1320 */   public static final void gdk_gc_set_stipple(long gc, long stipple) { lock.lock();
/*      */     try {
/* 1322 */       _gdk_gc_set_stipple(gc, stipple);
/*      */     } finally {
/* 1324 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gdk_gc_set_subwindow(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final void gdk_gc_set_subwindow(long gc, long mode)
/*      */   {
/* 1332 */     lock.lock();
/*      */     try {
/* 1334 */       _gdk_gc_set_subwindow(gc, mode);
/*      */     } finally {
/* 1336 */       lock.unlock();
/*      */     } }
/*      */   
/*      */   public static final native long _gdk_get_default_root_window();
/*      */   
/* 1341 */   public static final long gdk_get_default_root_window() { lock.lock();
/*      */     try {
/* 1343 */       return _gdk_get_default_root_window();
/*      */     } finally {
/* 1345 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gdk_keyboard_ungrab(int paramInt);
/*      */   
/*      */   /* Error */
/*      */   public static final void gdk_keyboard_ungrab(int time)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: iload_0
/*      */     //   8: invokestatic 100	org/eclipse/swt/internal/gtk/GDK:_gdk_keyboard_ungrab	(I)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_1
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_1
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #1351	-> byte code offset #0
/*      */     //   Java source line #1353	-> byte code offset #7
/*      */     //   Java source line #1355	-> byte code offset #11
/*      */     //   Java source line #1356	-> byte code offset #17
/*      */     //   Java source line #1355	-> byte code offset #20
/*      */     //   Java source line #1356	-> byte code offset #27
/*      */     //   Java source line #1357	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	time	int
/*      */     //   20	8	1	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native long _gdk_keymap_get_default();
/*      */   
/*      */   public static final long gdk_keymap_get_default()
/*      */   {
/* 1360 */     lock.lock();
/*      */     try {
/* 1362 */       return _gdk_keymap_get_default();
/*      */     } finally {
/* 1364 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final native boolean _gdk_keymap_get_entries_for_keyval(long paramLong1, long paramLong2, long[] paramArrayOfLong, int[] paramArrayOfInt);
/*      */   
/*      */ 
/*      */   public static final boolean gdk_keymap_get_entries_for_keyval(long keymap, long keyval, long[] keys, int[] n_keys)
/*      */   {
/* 1375 */     lock.lock();
/*      */     try {
/* 1377 */       return _gdk_keymap_get_entries_for_keyval(keymap, keyval, keys, n_keys);
/*      */     } finally {
/* 1379 */       lock.unlock();
/*      */     } }
/*      */   
/*      */   public static final native long _gdk_keyval_to_lower(long paramLong);
/*      */   
/* 1384 */   public static final long gdk_keyval_to_lower(long keyval) { lock.lock();
/*      */     try {
/* 1386 */       return _gdk_keyval_to_lower(keyval);
/*      */     } finally {
/* 1388 */       lock.unlock();
/*      */     } }
/*      */   
/*      */   public static final native long _gdk_keyval_to_unicode(long paramLong);
/*      */   
/* 1393 */   public static final long gdk_keyval_to_unicode(long keyval) { lock.lock();
/*      */     try {
/* 1395 */       return _gdk_keyval_to_unicode(keyval);
/*      */     } finally {
/* 1397 */       lock.unlock();
/*      */     } }
/*      */   
/*      */   public static final native long _gdk_pango_context_get();
/*      */   
/* 1402 */   public static final long gdk_pango_context_get() { lock.lock();
/*      */     try {
/* 1404 */       return _gdk_pango_context_get();
/*      */     } finally {
/* 1406 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native long _gdk_pango_layout_get_clip_region(long paramLong, int paramInt1, int paramInt2, int[] paramArrayOfInt, int paramInt3);
/*      */   
/*      */   public static final long gdk_pango_layout_get_clip_region(long layout, int x_origin, int y_origin, int[] index_ranges, int n_ranges)
/*      */   {
/* 1415 */     lock.lock();
/*      */     try {
/* 1417 */       return _gdk_pango_layout_get_clip_region(layout, x_origin, y_origin, index_ranges, n_ranges);
/*      */     } finally {
/* 1419 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gdk_pixbuf_copy_area(long paramLong1, int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong2, int paramInt5, int paramInt6);
/*      */   
/*      */   public static final void gdk_pixbuf_copy_area(long src_pixbuf, int src_x, int src_y, int width, int height, long dest_pixbuf, int dest_x, int dest_y)
/*      */   {
/* 1428 */     lock.lock();
/*      */     try {
/* 1430 */       _gdk_pixbuf_copy_area(src_pixbuf, src_x, src_y, width, height, dest_pixbuf, dest_x, dest_y);
/*      */     } finally {
/* 1432 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native long _gdk_pixbuf_get_from_drawable(long paramLong1, long paramLong2, long paramLong3, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6);
/*      */   
/*      */   public static final long gdk_pixbuf_get_from_drawable(long dest, long src, long cmap, int src_x, int src_y, int dest_x, int dest_y, int width, int height)
/*      */   {
/* 1441 */     lock.lock();
/*      */     try {
/* 1443 */       return _gdk_pixbuf_get_from_drawable(dest, src, cmap, src_x, src_y, dest_x, dest_y, width, height);
/*      */     } finally {
/* 1445 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final native long _gdk_pixbuf_get_from_window(long paramLong, int paramInt1, int paramInt2, int paramInt3, int paramInt4);
/*      */   
/*      */ 
/*      */ 
/*      */   public static final long gdk_pixbuf_get_from_window(long window, int src_x, int src_y, int width, int height)
/*      */   {
/* 1458 */     lock.lock();
/*      */     try {
/* 1460 */       return _gdk_pixbuf_get_from_window(window, src_x, src_y, width, height);
/*      */     } finally {
/* 1462 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native boolean _gdk_pixbuf_get_has_alpha(long paramLong);
/*      */   
/* 1468 */   public static final boolean gdk_pixbuf_get_has_alpha(long pixbuf) { lock.lock();
/*      */     try {
/* 1470 */       return _gdk_pixbuf_get_has_alpha(pixbuf);
/*      */     } finally {
/* 1472 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native int _gdk_pixbuf_get_height(long paramLong);
/*      */   
/* 1478 */   public static final int gdk_pixbuf_get_height(long pixbuf) { lock.lock();
/*      */     try {
/* 1480 */       return _gdk_pixbuf_get_height(pixbuf);
/*      */     } finally {
/* 1482 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gdk_pixbuf_get_pixels(long paramLong);
/*      */   
/* 1488 */   public static final long gdk_pixbuf_get_pixels(long pixbuf) { lock.lock();
/*      */     try {
/* 1490 */       return _gdk_pixbuf_get_pixels(pixbuf);
/*      */     } finally {
/* 1492 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native int _gdk_pixbuf_get_rowstride(long paramLong);
/*      */   
/* 1498 */   public static final int gdk_pixbuf_get_rowstride(long pixbuf) { lock.lock();
/*      */     try {
/* 1500 */       return _gdk_pixbuf_get_rowstride(pixbuf);
/*      */     } finally {
/* 1502 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native int _gdk_pixbuf_get_width(long paramLong);
/*      */   
/* 1508 */   public static final int gdk_pixbuf_get_width(long pixbuf) { lock.lock();
/*      */     try {
/* 1510 */       return _gdk_pixbuf_get_width(pixbuf);
/*      */     } finally {
/* 1512 */       lock.unlock();
/*      */     } }
/*      */   
/*      */   public static final native long _gdk_pixbuf_loader_new();
/*      */   
/* 1517 */   public static final long gdk_pixbuf_loader_new() { lock.lock();
/*      */     try {
/* 1519 */       return _gdk_pixbuf_loader_new();
/*      */     } finally {
/* 1521 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native boolean _gdk_pixbuf_loader_close(long paramLong, long[] paramArrayOfLong);
/*      */   
/*      */   public static final boolean gdk_pixbuf_loader_close(long loader, long[] error)
/*      */   {
/* 1530 */     lock.lock();
/*      */     try {
/* 1532 */       return _gdk_pixbuf_loader_close(loader, error);
/*      */     } finally {
/* 1534 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gdk_pixbuf_loader_get_pixbuf(long paramLong);
/*      */   
/* 1540 */   public static final long gdk_pixbuf_loader_get_pixbuf(long loader) { lock.lock();
/*      */     try {
/* 1542 */       return _gdk_pixbuf_loader_get_pixbuf(loader);
/*      */     } finally {
/* 1544 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final native boolean _gdk_pixbuf_loader_write(long paramLong1, long paramLong2, int paramInt, long[] paramArrayOfLong);
/*      */   
/*      */ 
/*      */   public static final boolean gdk_pixbuf_loader_write(long loader, long buffer, int count, long[] error)
/*      */   {
/* 1555 */     lock.lock();
/*      */     try {
/* 1557 */       return _gdk_pixbuf_loader_write(loader, buffer, count, error);
/*      */     } finally {
/* 1559 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native long _gdk_pixbuf_new(int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, int paramInt4);
/*      */   
/*      */   public static final long gdk_pixbuf_new(int colorspace, boolean has_alpha, int bits_per_sample, int width, int height)
/*      */   {
/* 1568 */     lock.lock();
/*      */     try {
/* 1570 */       return _gdk_pixbuf_new(colorspace, has_alpha, bits_per_sample, width, height);
/*      */     } finally {
/* 1572 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native long _gdk_pixbuf_new_from_file(byte[] paramArrayOfByte, long[] paramArrayOfLong);
/*      */   
/*      */   public static final long gdk_pixbuf_new_from_file(byte[] filename, long[] error)
/*      */   {
/* 1581 */     lock.lock();
/*      */     try {
/* 1583 */       return _gdk_pixbuf_new_from_file(filename, error);
/*      */     } finally {
/* 1585 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final native boolean _gdk_pixbuf_save_to_bufferv(long paramLong, long[] paramArrayOfLong1, long[] paramArrayOfLong2, byte[] paramArrayOfByte, long[] paramArrayOfLong3, long[] paramArrayOfLong4, long[] paramArrayOfLong5);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final boolean gdk_pixbuf_save_to_bufferv(long pixbuf, long[] buffer, long[] buffer_size, byte[] type, long[] option_keys, long[] option_values, long[] error)
/*      */   {
/* 1600 */     lock.lock();
/*      */     try {
/* 1602 */       return _gdk_pixbuf_save_to_bufferv(pixbuf, buffer, buffer_size, type, option_keys, option_values, error);
/*      */     } finally {
/* 1604 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native long _gdk_pixbuf_scale_simple(long paramLong, int paramInt1, int paramInt2, int paramInt3);
/*      */   
/*      */   public static final long gdk_pixbuf_scale_simple(long src, int dest_width, int dest_height, int interp_type)
/*      */   {
/* 1613 */     lock.lock();
/*      */     try {
/* 1615 */       return _gdk_pixbuf_scale_simple(src, dest_width, dest_height, interp_type);
/*      */     } finally {
/* 1617 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final native long _gdk_pixmap_new(long paramLong, int paramInt1, int paramInt2, int paramInt3);
/*      */   
/*      */ 
/*      */ 
/*      */   public static final long gdk_pixmap_new(long window, int width, int height, int depth)
/*      */   {
/* 1629 */     lock.lock();
/*      */     try {
/* 1631 */       return _gdk_pixmap_new(window, width, height, depth);
/*      */     } finally {
/* 1633 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final native int _gdk_pointer_grab(long paramLong1, boolean paramBoolean, int paramInt1, long paramLong2, long paramLong3, int paramInt2);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int gdk_pointer_grab(long window, boolean owner_events, int event_mask, long confine_to, long cursor, int time)
/*      */   {
/* 1647 */     lock.lock();
/*      */     try {
/* 1649 */       return _gdk_pointer_grab(window, owner_events, event_mask, confine_to, cursor, time);
/*      */     } finally {
/* 1651 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final native int _gdk_device_grab(long paramLong1, long paramLong2, int paramInt1, boolean paramBoolean, int paramInt2, long paramLong3, int paramInt3);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int gdk_device_grab(long device, long window, int grab_ownership, boolean owner_events, int event_mask, long cursor, int time_)
/*      */   {
/* 1665 */     lock.lock();
/*      */     try {
/* 1667 */       return _gdk_device_grab(device, window, grab_ownership, owner_events, event_mask, cursor, time_);
/*      */     } finally {
/* 1669 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gdk_pointer_ungrab(int paramInt);
/*      */   
/*      */   /* Error */
/*      */   public static final void gdk_pointer_ungrab(int time)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: iload_0
/*      */     //   8: invokestatic 126	org/eclipse/swt/internal/gtk/GDK:_gdk_pointer_ungrab	(I)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_1
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_1
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #1678	-> byte code offset #0
/*      */     //   Java source line #1680	-> byte code offset #7
/*      */     //   Java source line #1682	-> byte code offset #11
/*      */     //   Java source line #1683	-> byte code offset #17
/*      */     //   Java source line #1682	-> byte code offset #20
/*      */     //   Java source line #1683	-> byte code offset #27
/*      */     //   Java source line #1684	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	time	int
/*      */     //   20	8	1	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native void _gdk_device_ungrab(long paramLong, int paramInt);
/*      */   
/*      */   /* Error */
/*      */   public static final void gdk_device_ungrab(long device, int time_)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 127	org/eclipse/swt/internal/gtk/GDK:_gdk_device_ungrab	(JI)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #1692	-> byte code offset #0
/*      */     //   Java source line #1694	-> byte code offset #7
/*      */     //   Java source line #1696	-> byte code offset #12
/*      */     //   Java source line #1697	-> byte code offset #18
/*      */     //   Java source line #1696	-> byte code offset #21
/*      */     //   Java source line #1697	-> byte code offset #28
/*      */     //   Java source line #1698	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	device	long
/*      */     //   0	31	2	time_	int
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native long _gdk_device_get_associated_device(long paramLong);
/*      */   
/*      */   public static final long gdk_device_get_associated_device(long device)
/*      */   {
/* 1705 */     lock.lock();
/*      */     try {
/* 1707 */       return _gdk_device_get_associated_device(device);
/*      */     } finally {
/* 1709 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final native boolean _gdk_property_get(long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5, int paramInt, long[] paramArrayOfLong1, int[] paramArrayOfInt1, int[] paramArrayOfInt2, long[] paramArrayOfLong2);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final boolean gdk_property_get(long window, long property, long type, long offset, long length, int pdelete, long[] actual_property_type, int[] actual_format, int[] actual_length, long[] data)
/*      */   {
/* 1723 */     lock.lock();
/*      */     try {
/* 1725 */       return _gdk_property_get(window, property, type, offset, length, pdelete, actual_property_type, actual_format, actual_length, data);
/*      */     } finally {
/* 1727 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gdk_region_destroy(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void gdk_region_destroy(long region)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 130	org/eclipse/swt/internal/gtk/GDK:_gdk_region_destroy	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #1733	-> byte code offset #0
/*      */     //   Java source line #1735	-> byte code offset #7
/*      */     //   Java source line #1737	-> byte code offset #11
/*      */     //   Java source line #1738	-> byte code offset #17
/*      */     //   Java source line #1737	-> byte code offset #20
/*      */     //   Java source line #1738	-> byte code offset #27
/*      */     //   Java source line #1739	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	region	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native boolean _gdk_region_empty(long paramLong);
/*      */   
/*      */   public static final boolean gdk_region_empty(long region)
/*      */   {
/* 1743 */     lock.lock();
/*      */     try {
/* 1745 */       return _gdk_region_empty(region);
/*      */     } finally {
/* 1747 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gdk_region_get_clipbox(long paramLong, GdkRectangle paramGdkRectangle);
/*      */   
/*      */   /* Error */
/*      */   public static final void gdk_region_get_clipbox(long region, GdkRectangle rectangle)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: aload_2
/*      */     //   9: invokestatic 132	org/eclipse/swt/internal/gtk/GDK:_gdk_region_get_clipbox	(JLorg/eclipse/swt/internal/gtk/GdkRectangle;)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #1756	-> byte code offset #0
/*      */     //   Java source line #1758	-> byte code offset #7
/*      */     //   Java source line #1760	-> byte code offset #12
/*      */     //   Java source line #1761	-> byte code offset #18
/*      */     //   Java source line #1760	-> byte code offset #21
/*      */     //   Java source line #1761	-> byte code offset #28
/*      */     //   Java source line #1762	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	region	long
/*      */     //   0	31	2	rectangle	GdkRectangle
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gdk_region_get_rectangles(long paramLong, long[] paramArrayOfLong, int[] paramArrayOfInt);
/*      */   
/*      */   public static final void gdk_region_get_rectangles(long region, long[] rectangles, int[] n_rectangles)
/*      */   {
/* 1769 */     lock.lock();
/*      */     try {
/* 1771 */       _gdk_region_get_rectangles(region, rectangles, n_rectangles);
/*      */     } finally {
/* 1773 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gdk_region_intersect(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final void gdk_region_intersect(long source1, long source2)
/*      */   {
/* 1782 */     lock.lock();
/*      */     try {
/* 1784 */       _gdk_region_intersect(source1, source2);
/*      */     } finally {
/* 1786 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gdk_cairo_region_create_from_surface(long paramLong);
/*      */   
/* 1792 */   public static final long gdk_cairo_region_create_from_surface(long surface) { lock.lock();
/*      */     try {
/* 1794 */       return _gdk_cairo_region_create_from_surface(surface);
/*      */     } finally {
/* 1796 */       lock.unlock();
/*      */     } }
/*      */   
/*      */   public static final native long _gdk_region_new();
/*      */   
/* 1801 */   public static final long gdk_region_new() { lock.lock();
/*      */     try {
/* 1803 */       return _gdk_region_new();
/*      */     } finally {
/* 1805 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gdk_region_offset(long paramLong, int paramInt1, int paramInt2);
/*      */   
/*      */ 
/*      */   public static final void gdk_region_offset(long region, int dx, int dy)
/*      */   {
/* 1815 */     lock.lock();
/*      */     try {
/* 1817 */       _gdk_region_offset(region, dx, dy);
/*      */     } finally {
/* 1819 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native boolean _gdk_region_point_in(long paramLong, int paramInt1, int paramInt2);
/*      */   
/*      */ 
/*      */   public static final boolean gdk_region_point_in(long region, int x, int y)
/*      */   {
/* 1829 */     lock.lock();
/*      */     try {
/* 1831 */       return _gdk_region_point_in(region, x, y);
/*      */     } finally {
/* 1833 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gdk_region_polygon(int[] paramArrayOfInt, int paramInt1, int paramInt2);
/*      */   
/* 1839 */   public static final long gdk_region_polygon(int[] points, int npoints, int fill_rule) { lock.lock();
/*      */     try {
/* 1841 */       return _gdk_region_polygon(points, npoints, fill_rule);
/*      */     } finally {
/* 1843 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gdk_region_rectangle(GdkRectangle paramGdkRectangle);
/*      */   
/*      */   public static final long gdk_region_rectangle(GdkRectangle rectangle)
/*      */   {
/* 1851 */     lock.lock();
/*      */     try {
/* 1853 */       return _gdk_region_rectangle(rectangle);
/*      */     } finally {
/* 1855 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native long _gdk_region_rect_in(long paramLong, GdkRectangle paramGdkRectangle);
/*      */   
/*      */   public static final long gdk_region_rect_in(long region, GdkRectangle rect)
/*      */   {
/* 1864 */     lock.lock();
/*      */     try {
/* 1866 */       return _gdk_region_rect_in(region, rect);
/*      */     } finally {
/* 1868 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gdk_region_subtract(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final void gdk_region_subtract(long source1, long source2)
/*      */   {
/* 1877 */     lock.lock();
/*      */     try {
/* 1879 */       _gdk_region_subtract(source1, source2);
/*      */     } finally {
/* 1881 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gdk_region_union(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final void gdk_region_union(long source1, long source2)
/*      */   {
/* 1890 */     lock.lock();
/*      */     try {
/* 1892 */       _gdk_region_union(source1, source2);
/*      */     } finally {
/* 1894 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gdk_region_union_with_rect(long paramLong, GdkRectangle paramGdkRectangle);
/*      */   
/*      */   /* Error */
/*      */   public static final void gdk_region_union_with_rect(long region, GdkRectangle rect)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: aload_2
/*      */     //   9: invokestatic 144	org/eclipse/swt/internal/gtk/GDK:_gdk_region_union_with_rect	(JLorg/eclipse/swt/internal/gtk/GdkRectangle;)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #1903	-> byte code offset #0
/*      */     //   Java source line #1905	-> byte code offset #7
/*      */     //   Java source line #1907	-> byte code offset #12
/*      */     //   Java source line #1908	-> byte code offset #18
/*      */     //   Java source line #1907	-> byte code offset #21
/*      */     //   Java source line #1908	-> byte code offset #28
/*      */     //   Java source line #1909	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	region	long
/*      */     //   0	31	2	rect	GdkRectangle
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native long _gdk_rgba_to_string(GdkRGBA paramGdkRGBA);
/*      */   
/*      */   public static final long gdk_rgba_to_string(GdkRGBA rgba)
/*      */   {
/* 1916 */     lock.lock();
/* 1917 */     assert (GTK.GTK3) : "GTK3 code was run by GTK2";
/*      */     try {
/* 1919 */       return _gdk_rgba_to_string(rgba);
/*      */     } finally {
/* 1921 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gdk_rgba_free(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void gdk_rgba_free(long rgba)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: getstatic 7	org/eclipse/swt/internal/gtk/GDK:$assertionsDisabled	Z
/*      */     //   10: ifne +19 -> 29
/*      */     //   13: getstatic 8	org/eclipse/swt/internal/gtk/GTK:GTK3	Z
/*      */     //   16: ifne +13 -> 29
/*      */     //   19: new 9	java/lang/AssertionError
/*      */     //   22: dup
/*      */     //   23: ldc 10
/*      */     //   25: invokespecial 11	java/lang/AssertionError:<init>	(Ljava/lang/Object;)V
/*      */     //   28: athrow
/*      */     //   29: lload_0
/*      */     //   30: invokestatic 146	org/eclipse/swt/internal/gtk/GDK:_gdk_rgba_free	(J)V
/*      */     //   33: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   36: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   39: goto +12 -> 51
/*      */     //   42: astore_2
/*      */     //   43: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   46: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   49: aload_2
/*      */     //   50: athrow
/*      */     //   51: return
/*      */     // Line number table:
/*      */     //   Java source line #1930	-> byte code offset #0
/*      */     //   Java source line #1931	-> byte code offset #7
/*      */     //   Java source line #1933	-> byte code offset #29
/*      */     //   Java source line #1935	-> byte code offset #33
/*      */     //   Java source line #1936	-> byte code offset #39
/*      */     //   Java source line #1935	-> byte code offset #42
/*      */     //   Java source line #1936	-> byte code offset #49
/*      */     //   Java source line #1937	-> byte code offset #51
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	52	0	rgba	long
/*      */     //   42	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   29	33	42	finally
/*      */   }
/*      */   
/*      */   public static final native int _gdk_rgba_hash(GdkRGBA paramGdkRGBA);
/*      */   
/*      */   public static final int gdk_rgba_hash(GdkRGBA rgba)
/*      */   {
/* 1944 */     lock.lock();
/* 1945 */     assert (GTK.GTK3) : "GTK3 code was run by GTK2";
/*      */     try {
/* 1947 */       return _gdk_rgba_hash(rgba);
/*      */     } finally {
/* 1949 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native long _gdk_rgba_parse(GdkRGBA paramGdkRGBA, byte[] paramArrayOfByte);
/*      */   
/*      */ 
/*      */   public static final long gdk_rgba_parse(GdkRGBA rgba, byte[] property)
/*      */   {
/* 1959 */     lock.lock();
/* 1960 */     assert (GTK.GTK3) : "GTK3 code was run by GTK2";
/*      */     try {
/* 1962 */       return _gdk_rgba_parse(rgba, property);
/*      */     } finally {
/* 1964 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gdk_screen_get_default();
/*      */   
/* 1970 */   public static final long gdk_screen_get_default() { lock.lock();
/*      */     try {
/* 1972 */       return _gdk_screen_get_default();
/*      */     } finally {
/* 1974 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gdk_screen_get_active_window(long paramLong);
/*      */   
/* 1980 */   public static final long gdk_screen_get_active_window(long screen) { lock.lock();
/*      */     try {
/* 1982 */       return _gdk_screen_get_active_window(screen);
/*      */     } finally {
/* 1984 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native double _gdk_screen_get_resolution(long paramLong);
/*      */   
/*      */   public static final double gdk_screen_get_resolution(long screen)
/*      */   {
/* 1993 */     lock.lock();
/*      */     try {
/* 1995 */       return _gdk_screen_get_resolution(screen);
/*      */     } finally {
/* 1997 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native int _gdk_screen_get_monitor_scale_factor(long paramLong, int paramInt);
/*      */   
/*      */ 
/*      */   public static final int gdk_screen_get_monitor_scale_factor(long screen, int monitor_num)
/*      */   {
/* 2007 */     lock.lock();
/*      */     try {
/* 2009 */       return _gdk_screen_get_monitor_scale_factor(screen, monitor_num);
/*      */     } finally {
/* 2011 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native int _gdk_monitor_get_scale_factor(long paramLong);
/*      */   
/*      */   public static final int gdk_monitor_get_scale_factor(long window)
/*      */   {
/* 2019 */     lock.lock();
/*      */     try {
/* 2021 */       return _gdk_monitor_get_scale_factor(window);
/*      */     } finally {
/* 2023 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final native int _gdk_screen_get_monitor_at_point(long paramLong, int paramInt1, int paramInt2);
/*      */   
/*      */ 
/*      */   public static final int gdk_screen_get_monitor_at_point(long screen, int x, int y)
/*      */   {
/* 2034 */     lock.lock();
/*      */     try {
/* 2036 */       return _gdk_screen_get_monitor_at_point(screen, x, y);
/*      */     } finally {
/* 2038 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native int _gdk_screen_get_monitor_at_window(long paramLong1, long paramLong2);
/*      */   
/*      */ 
/*      */   public static final int gdk_screen_get_monitor_at_window(long screen, long window)
/*      */   {
/* 2048 */     lock.lock();
/*      */     try {
/* 2050 */       return _gdk_screen_get_monitor_at_window(screen, window);
/*      */     } finally {
/* 2052 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gdk_display_get_monitor(long paramLong, int paramInt);
/*      */   
/*      */   public static final long gdk_display_get_monitor(long display, int monitor_num)
/*      */   {
/* 2060 */     lock.lock();
/*      */     try {
/* 2062 */       return _gdk_display_get_monitor(display, monitor_num);
/*      */     } finally {
/* 2064 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gdk_screen_get_monitor_geometry(long paramLong, int paramInt, GdkRectangle paramGdkRectangle);
/*      */   
/*      */ 
/*      */   public static final void gdk_screen_get_monitor_geometry(long screen, int monitor_num, GdkRectangle dest)
/*      */   {
/* 2074 */     lock.lock();
/*      */     try {
/* 2076 */       _gdk_screen_get_monitor_geometry(screen, monitor_num, dest);
/*      */     } finally {
/* 2078 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gdk_screen_get_monitor_workarea(long paramLong, int paramInt, GdkRectangle paramGdkRectangle);
/*      */   
/*      */ 
/*      */   public static final void gdk_screen_get_monitor_workarea(long screen, int monitor_num, GdkRectangle dest)
/*      */   {
/* 2088 */     lock.lock();
/*      */     try {
/* 2090 */       _gdk_screen_get_monitor_workarea(screen, monitor_num, dest);
/*      */     } finally {
/* 2092 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native int _gdk_screen_get_n_monitors(long paramLong);
/*      */   
/*      */   public static final int gdk_screen_get_n_monitors(long screen)
/*      */   {
/* 2101 */     lock.lock();
/*      */     try {
/* 2103 */       return _gdk_screen_get_n_monitors(screen);
/*      */     } finally {
/* 2105 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native int _gdk_screen_get_primary_monitor(long paramLong);
/*      */   
/*      */   public static final int gdk_screen_get_primary_monitor(long screen)
/*      */   {
/* 2114 */     lock.lock();
/*      */     try {
/* 2116 */       return _gdk_screen_get_primary_monitor(screen);
/*      */     } finally {
/* 2118 */       lock.unlock();
/*      */     } }
/*      */   
/*      */   public static final native int _gdk_screen_height();
/*      */   
/* 2123 */   public static final int gdk_screen_height() { lock.lock();
/*      */     try {
/* 2125 */       return _gdk_screen_height();
/*      */     } finally {
/* 2127 */       lock.unlock();
/*      */     } }
/*      */   
/*      */   public static final native int _gdk_screen_width();
/*      */   
/* 2132 */   public static final int gdk_screen_width() { lock.lock();
/*      */     try {
/* 2134 */       return _gdk_screen_width();
/*      */     } finally {
/* 2136 */       lock.unlock();
/*      */     } }
/*      */   
/*      */   public static final native int _gdk_screen_width_mm();
/*      */   
/* 2141 */   public static final int gdk_screen_width_mm() { lock.lock();
/*      */     try {
/* 2143 */       return _gdk_screen_width_mm();
/*      */     } finally {
/* 2145 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native int _gdk_screen_get_monitor_width_mm(long paramLong, int paramInt);
/*      */   
/*      */   public static final int gdk_screen_get_monitor_width_mm(long screen, int monitor_num)
/*      */   {
/* 2154 */     lock.lock();
/*      */     try {
/* 2156 */       return _gdk_screen_get_monitor_width_mm(screen, monitor_num);
/*      */     } finally {
/* 2158 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native int _gdk_seat_grab(long paramLong1, long paramLong2, int paramInt, boolean paramBoolean, long paramLong3, long paramLong4, long paramLong5, long paramLong6);
/*      */   
/*      */   public static final int gdk_seat_grab(long seat, long window, int capabilities, boolean owner_events, long cursor, long event, long func, long func_data)
/*      */   {
/* 2166 */     lock.lock();
/*      */     try {
/* 2168 */       return _gdk_seat_grab(seat, window, capabilities, owner_events, cursor, event, func, func_data);
/*      */     } finally {
/* 2170 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gdk_seat_ungrab(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void gdk_seat_ungrab(long seat)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 166	org/eclipse/swt/internal/gtk/GDK:_gdk_seat_ungrab	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #2178	-> byte code offset #0
/*      */     //   Java source line #2180	-> byte code offset #7
/*      */     //   Java source line #2182	-> byte code offset #11
/*      */     //   Java source line #2183	-> byte code offset #17
/*      */     //   Java source line #2182	-> byte code offset #20
/*      */     //   Java source line #2183	-> byte code offset #27
/*      */     //   Java source line #2184	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	seat	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native long _gdk_seat_get_pointer(long paramLong);
/*      */   
/*      */   public static final long gdk_seat_get_pointer(long seat)
/*      */   {
/* 2190 */     lock.lock();
/*      */     try {
/* 2192 */       return _gdk_seat_get_pointer(seat);
/*      */     } finally {
/* 2194 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gdk_set_program_class(byte[] paramArrayOfByte);
/*      */   
/*      */   /* Error */
/*      */   public static final void gdk_set_program_class(byte[] program_class)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: aload_0
/*      */     //   8: invokestatic 168	org/eclipse/swt/internal/gtk/GDK:_gdk_set_program_class	([B)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_1
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_1
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #2200	-> byte code offset #0
/*      */     //   Java source line #2202	-> byte code offset #7
/*      */     //   Java source line #2204	-> byte code offset #11
/*      */     //   Java source line #2205	-> byte code offset #17
/*      */     //   Java source line #2204	-> byte code offset #20
/*      */     //   Java source line #2205	-> byte code offset #27
/*      */     //   Java source line #2206	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	program_class	byte[]
/*      */     //   20	8	1	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native void _gdk_selection_owner_get(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void gdk_selection_owner_get(long atom)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 169	org/eclipse/swt/internal/gtk/GDK:_gdk_selection_owner_get	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #2210	-> byte code offset #0
/*      */     //   Java source line #2212	-> byte code offset #7
/*      */     //   Java source line #2214	-> byte code offset #11
/*      */     //   Java source line #2215	-> byte code offset #17
/*      */     //   Java source line #2214	-> byte code offset #20
/*      */     //   Java source line #2215	-> byte code offset #27
/*      */     //   Java source line #2216	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	atom	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native void _gdk_selection_owner_set(long paramLong1, long paramLong2, int paramInt, boolean paramBoolean);
/*      */   
/*      */   public static final void gdk_selection_owner_set(long owner, long atom, int time, boolean send_event)
/*      */   {
/* 2225 */     lock.lock();
/*      */     try {
/* 2227 */       _gdk_selection_owner_set(owner, atom, time, send_event);
/*      */     } finally {
/* 2229 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native boolean _gdk_x11_display_utf8_to_compound_text(long paramLong, byte[] paramArrayOfByte, long[] paramArrayOfLong1, int[] paramArrayOfInt1, long[] paramArrayOfLong2, int[] paramArrayOfInt2);
/*      */   
/*      */   public static final boolean gdk_x11_display_utf8_to_compound_text(long display, byte[] str, long[] encoding, int[] format, long[] ctext, int[] length)
/*      */   {
/* 2238 */     lock.lock();
/*      */     try {
/* 2240 */       return _gdk_x11_display_utf8_to_compound_text(display, str, encoding, format, ctext, length);
/*      */     } finally {
/* 2242 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gdk_utf8_to_string_target(byte[] paramArrayOfByte);
/*      */   
/* 2248 */   public static final long gdk_utf8_to_string_target(byte[] str) { lock.lock();
/*      */     try {
/* 2250 */       return _gdk_utf8_to_string_target(str);
/*      */     } finally {
/* 2252 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final native boolean _gdk_test_simulate_button(long paramLong, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final boolean gdk_test_simulate_button(long window, int x, int y, int button, int modifiers, int button_pressrelease)
/*      */   {
/* 2267 */     lock.lock();
/*      */     try {
/* 2269 */       return _gdk_test_simulate_button(window, x, y, button, modifiers, button_pressrelease);
/*      */     } finally {
/* 2271 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final native int _gdk_text_property_to_utf8_list_for_display(long paramLong1, long paramLong2, int paramInt1, long paramLong3, int paramInt2, long[] paramArrayOfLong);
/*      */   
/*      */ 
/*      */   public static final int gdk_text_property_to_utf8_list_for_display(long display, long encoding, int format, long text, int length, long[] list)
/*      */   {
/* 2282 */     lock.lock();
/*      */     try {
/* 2284 */       return _gdk_text_property_to_utf8_list_for_display(display, encoding, format, text, length, list);
/*      */     } finally {
/* 2286 */       lock.unlock(); } }
/*      */   
/*      */   public static final native void gdk_threads_leave();
/*      */   
/*      */   public static final native int _gdk_unicode_to_keyval(int paramInt);
/*      */   
/* 2292 */   public static final int gdk_unicode_to_keyval(int wc) { lock.lock();
/*      */     try {
/* 2294 */       return _gdk_unicode_to_keyval(wc);
/*      */     } finally {
/* 2296 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native int _gdk_visual_get_depth(long paramLong);
/*      */   
/*      */   public static final int gdk_visual_get_depth(long visual)
/*      */   {
/* 2305 */     lock.lock();
/*      */     try {
/* 2307 */       return _gdk_visual_get_depth(visual);
/*      */     } finally {
/* 2309 */       lock.unlock();
/*      */     } }
/*      */   
/*      */   public static final native long _gdk_visual_get_system();
/*      */   
/* 2314 */   public static final long gdk_visual_get_system() { lock.lock();
/*      */     try {
/* 2316 */       return _gdk_visual_get_system();
/*      */     } finally {
/* 2318 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native long _gdk_window_at_pointer(int[] paramArrayOfInt1, int[] paramArrayOfInt2);
/*      */   
/*      */ 
/*      */   public static final long gdk_window_at_pointer(int[] win_x, int[] win_y)
/*      */   {
/* 2328 */     lock.lock();
/*      */     try {
/* 2330 */       return _gdk_window_at_pointer(win_x, win_y);
/*      */     } finally {
/* 2332 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gdk_window_begin_paint_rect(long paramLong, GdkRectangle paramGdkRectangle);
/*      */   
/*      */   /* Error */
/*      */   public static final void gdk_window_begin_paint_rect(long window, GdkRectangle rectangle)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: aload_2
/*      */     //   9: invokestatic 179	org/eclipse/swt/internal/gtk/GDK:_gdk_window_begin_paint_rect	(JLorg/eclipse/swt/internal/gtk/GdkRectangle;)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #2341	-> byte code offset #0
/*      */     //   Java source line #2343	-> byte code offset #7
/*      */     //   Java source line #2345	-> byte code offset #12
/*      */     //   Java source line #2346	-> byte code offset #18
/*      */     //   Java source line #2345	-> byte code offset #21
/*      */     //   Java source line #2346	-> byte code offset #28
/*      */     //   Java source line #2347	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	window	long
/*      */     //   0	31	2	rectangle	GdkRectangle
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native long _gdk_window_create_similar_surface(long paramLong, int paramInt1, int paramInt2, int paramInt3);
/*      */   
/*      */   public static final long gdk_window_create_similar_surface(long window, int content, int width, int height)
/*      */   {
/* 2354 */     lock.lock();
/*      */     try {
/* 2356 */       return _gdk_window_create_similar_surface(window, content, width, height);
/*      */     } finally {
/* 2358 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gdk_window_destroy(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void gdk_window_destroy(long window)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 181	org/eclipse/swt/internal/gtk/GDK:_gdk_window_destroy	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #2364	-> byte code offset #0
/*      */     //   Java source line #2366	-> byte code offset #7
/*      */     //   Java source line #2368	-> byte code offset #11
/*      */     //   Java source line #2369	-> byte code offset #17
/*      */     //   Java source line #2368	-> byte code offset #20
/*      */     //   Java source line #2369	-> byte code offset #27
/*      */     //   Java source line #2370	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	window	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native void _gdk_window_end_paint(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void gdk_window_end_paint(long window)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 182	org/eclipse/swt/internal/gtk/GDK:_gdk_window_end_paint	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #2374	-> byte code offset #0
/*      */     //   Java source line #2376	-> byte code offset #7
/*      */     //   Java source line #2378	-> byte code offset #11
/*      */     //   Java source line #2379	-> byte code offset #17
/*      */     //   Java source line #2378	-> byte code offset #20
/*      */     //   Java source line #2379	-> byte code offset #27
/*      */     //   Java source line #2380	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	window	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native long _gdk_window_get_children(long paramLong);
/*      */   
/*      */   public static final long gdk_window_get_children(long window)
/*      */   {
/* 2384 */     lock.lock();
/*      */     try {
/* 2386 */       return _gdk_window_get_children(window);
/*      */     } finally {
/* 2388 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native int _gdk_window_get_events(long paramLong);
/*      */   
/* 2394 */   public static final int gdk_window_get_events(long window) { lock.lock();
/*      */     try {
/* 2396 */       return _gdk_window_get_events(window);
/*      */     } finally {
/* 2398 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gdk_window_focus(long paramLong, int paramInt);
/*      */   
/*      */   /* Error */
/*      */   public static final void gdk_window_focus(long window, int timestamp)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 185	org/eclipse/swt/internal/gtk/GDK:_gdk_window_focus	(JI)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #2404	-> byte code offset #0
/*      */     //   Java source line #2406	-> byte code offset #7
/*      */     //   Java source line #2408	-> byte code offset #12
/*      */     //   Java source line #2409	-> byte code offset #18
/*      */     //   Java source line #2408	-> byte code offset #21
/*      */     //   Java source line #2409	-> byte code offset #28
/*      */     //   Java source line #2410	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	window	long
/*      */     //   0	31	2	timestamp	int
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gdk_window_get_frame_extents(long paramLong, GdkRectangle paramGdkRectangle);
/*      */   
/*      */   /* Error */
/*      */   public static final void gdk_window_get_frame_extents(long window, GdkRectangle rect)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: aload_2
/*      */     //   9: invokestatic 186	org/eclipse/swt/internal/gtk/GDK:_gdk_window_get_frame_extents	(JLorg/eclipse/swt/internal/gtk/GdkRectangle;)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #2417	-> byte code offset #0
/*      */     //   Java source line #2419	-> byte code offset #7
/*      */     //   Java source line #2421	-> byte code offset #12
/*      */     //   Java source line #2422	-> byte code offset #18
/*      */     //   Java source line #2421	-> byte code offset #21
/*      */     //   Java source line #2422	-> byte code offset #28
/*      */     //   Java source line #2423	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	window	long
/*      */     //   0	31	2	rect	GdkRectangle
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gdk_window_get_internal_paint_info(long paramLong, long[] paramArrayOfLong, int[] paramArrayOfInt1, int[] paramArrayOfInt2);
/*      */   
/*      */   public static final void gdk_window_get_internal_paint_info(long window, long[] real_drawable, int[] x_offset, int[] y_offset)
/*      */   {
/* 2432 */     lock.lock();
/*      */     try {
/* 2434 */       _gdk_window_get_internal_paint_info(window, real_drawable, x_offset, y_offset);
/*      */     } finally {
/* 2436 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native int _gdk_window_get_origin(long paramLong, int[] paramArrayOfInt1, int[] paramArrayOfInt2);
/*      */   
/*      */ 
/*      */   public static final int gdk_window_get_origin(long window, int[] x, int[] y)
/*      */   {
/* 2446 */     lock.lock();
/*      */     try {
/* 2448 */       return _gdk_window_get_origin(window, x, y);
/*      */     } finally {
/* 2450 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final native long _gdk_window_get_device_position(long paramLong1, long paramLong2, int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3);
/*      */   
/*      */ 
/*      */ 
/*      */   public static final long gdk_window_get_device_position(long window, long device, int[] x, int[] y, int[] mask)
/*      */   {
/* 2463 */     lock.lock();
/*      */     try {
/* 2465 */       return _gdk_window_get_device_position(window, device, x, y, mask);
/*      */     } finally {
/* 2467 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gdk_window_get_parent(long paramLong);
/*      */   
/* 2473 */   public static final long gdk_window_get_parent(long window) { lock.lock();
/*      */     try {
/* 2475 */       return _gdk_window_get_parent(window);
/*      */     } finally {
/* 2477 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final native long _gdk_window_get_pointer(long paramLong, int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3);
/*      */   
/*      */ 
/*      */ 
/*      */   public static final long gdk_window_get_pointer(long window, int[] x, int[] y, int[] mask)
/*      */   {
/* 2489 */     lock.lock();
/*      */     try {
/* 2491 */       return _gdk_window_get_pointer(window, x, y, mask);
/*      */     } finally {
/* 2493 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gdk_window_get_position(long paramLong, int[] paramArrayOfInt1, int[] paramArrayOfInt2);
/*      */   
/*      */ 
/*      */   public static final void gdk_window_get_position(long window, int[] x, int[] y)
/*      */   {
/* 2503 */     lock.lock();
/*      */     try {
/* 2505 */       _gdk_window_get_position(window, x, y);
/*      */     } finally {
/* 2507 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gdk_window_get_root_origin(long paramLong, int[] paramArrayOfInt1, int[] paramArrayOfInt2);
/*      */   
/*      */ 
/*      */   public static final void gdk_window_get_root_origin(long window, int[] x, int[] y)
/*      */   {
/* 2517 */     lock.lock();
/*      */     try {
/* 2519 */       _gdk_window_get_root_origin(window, x, y);
/*      */     } finally {
/* 2521 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gdk_window_get_user_data(long paramLong, long[] paramArrayOfLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void gdk_window_get_user_data(long window, long[] data)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: aload_2
/*      */     //   9: invokestatic 194	org/eclipse/swt/internal/gtk/GDK:_gdk_window_get_user_data	(J[J)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #2530	-> byte code offset #0
/*      */     //   Java source line #2532	-> byte code offset #7
/*      */     //   Java source line #2534	-> byte code offset #12
/*      */     //   Java source line #2535	-> byte code offset #18
/*      */     //   Java source line #2534	-> byte code offset #21
/*      */     //   Java source line #2535	-> byte code offset #28
/*      */     //   Java source line #2536	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	window	long
/*      */     //   0	31	2	data	long[]
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gdk_window_hide(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void gdk_window_hide(long window)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 195	org/eclipse/swt/internal/gtk/GDK:_gdk_window_hide	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #2540	-> byte code offset #0
/*      */     //   Java source line #2542	-> byte code offset #7
/*      */     //   Java source line #2544	-> byte code offset #11
/*      */     //   Java source line #2545	-> byte code offset #17
/*      */     //   Java source line #2544	-> byte code offset #20
/*      */     //   Java source line #2545	-> byte code offset #27
/*      */     //   Java source line #2546	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	window	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native void _gdk_window_invalidate_rect(long paramLong, GdkRectangle paramGdkRectangle, boolean paramBoolean);
/*      */   
/*      */   public static final void gdk_window_invalidate_rect(long window, GdkRectangle rectangle, boolean invalidate_children)
/*      */   {
/* 2554 */     lock.lock();
/*      */     try {
/* 2556 */       _gdk_window_invalidate_rect(window, rectangle, invalidate_children);
/*      */     } finally {
/* 2558 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gdk_window_invalidate_region(long paramLong1, long paramLong2, boolean paramBoolean);
/*      */   
/*      */ 
/*      */   public static final void gdk_window_invalidate_region(long window, long region, boolean invalidate_children)
/*      */   {
/* 2568 */     lock.lock();
/*      */     try {
/* 2570 */       _gdk_window_invalidate_region(window, region, invalidate_children);
/*      */     } finally {
/* 2572 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native boolean _gdk_window_is_visible(long paramLong);
/*      */   
/* 2578 */   public static final boolean gdk_window_is_visible(long window) { lock.lock();
/*      */     try {
/* 2580 */       return _gdk_window_is_visible(window);
/*      */     } finally {
/* 2582 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gdk_window_move(long paramLong, int paramInt1, int paramInt2);
/*      */   
/* 2588 */   public static final void gdk_window_move(long window, int x, int y) { lock.lock();
/*      */     try {
/* 2590 */       _gdk_window_move(window, x, y);
/*      */     } finally {
/* 2592 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gdk_window_move_resize(long paramLong, int paramInt1, int paramInt2, int paramInt3, int paramInt4);
/*      */   
/* 2598 */   public static final void gdk_window_move_resize(long window, int x, int y, int width, int height) { lock.lock();
/*      */     try {
/* 2600 */       _gdk_window_move_resize(window, x, y, width, height);
/*      */     } finally {
/* 2602 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native long _gdk_window_new(long paramLong, GdkWindowAttr paramGdkWindowAttr, int paramInt);
/*      */   
/*      */   public static final long gdk_window_new(long parent, GdkWindowAttr attributes, int attributes_mask)
/*      */   {
/* 2611 */     lock.lock();
/*      */     try {
/* 2613 */       return _gdk_window_new(parent, attributes, attributes_mask);
/*      */     } finally {
/* 2615 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gdk_window_lower(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void gdk_window_lower(long window)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 202	org/eclipse/swt/internal/gtk/GDK:_gdk_window_lower	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #2621	-> byte code offset #0
/*      */     //   Java source line #2623	-> byte code offset #7
/*      */     //   Java source line #2625	-> byte code offset #11
/*      */     //   Java source line #2626	-> byte code offset #17
/*      */     //   Java source line #2625	-> byte code offset #20
/*      */     //   Java source line #2626	-> byte code offset #27
/*      */     //   Java source line #2627	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	window	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native void _gdk_window_process_all_updates();
/*      */   
/*      */   /* Error */
/*      */   public static final void gdk_window_process_all_updates()
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: invokestatic 203	org/eclipse/swt/internal/gtk/GDK:_gdk_window_process_all_updates	()V
/*      */     //   10: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   13: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   16: goto +12 -> 28
/*      */     //   19: astore_0
/*      */     //   20: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   23: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   26: aload_0
/*      */     //   27: athrow
/*      */     //   28: return
/*      */     // Line number table:
/*      */     //   Java source line #2633	-> byte code offset #0
/*      */     //   Java source line #2635	-> byte code offset #7
/*      */     //   Java source line #2637	-> byte code offset #10
/*      */     //   Java source line #2638	-> byte code offset #16
/*      */     //   Java source line #2637	-> byte code offset #19
/*      */     //   Java source line #2638	-> byte code offset #26
/*      */     //   Java source line #2639	-> byte code offset #28
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   19	8	0	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	10	19	finally
/*      */   }
/*      */   
/*      */   public static final native void _gdk_window_process_updates(long paramLong, boolean paramBoolean);
/*      */   
/*      */   /* Error */
/*      */   public static final void gdk_window_process_updates(long window, boolean update_children)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 204	org/eclipse/swt/internal/gtk/GDK:_gdk_window_process_updates	(JZ)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #2647	-> byte code offset #0
/*      */     //   Java source line #2649	-> byte code offset #7
/*      */     //   Java source line #2651	-> byte code offset #12
/*      */     //   Java source line #2652	-> byte code offset #18
/*      */     //   Java source line #2651	-> byte code offset #21
/*      */     //   Java source line #2652	-> byte code offset #28
/*      */     //   Java source line #2653	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	window	long
/*      */     //   0	31	2	update_children	boolean
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gdk_window_raise(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void gdk_window_raise(long window)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 205	org/eclipse/swt/internal/gtk/GDK:_gdk_window_raise	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #2657	-> byte code offset #0
/*      */     //   Java source line #2659	-> byte code offset #7
/*      */     //   Java source line #2661	-> byte code offset #11
/*      */     //   Java source line #2662	-> byte code offset #17
/*      */     //   Java source line #2661	-> byte code offset #20
/*      */     //   Java source line #2662	-> byte code offset #27
/*      */     //   Java source line #2663	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	window	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native void _gdk_window_resize(long paramLong, int paramInt1, int paramInt2);
/*      */   
/*      */   public static final void gdk_window_resize(long window, int width, int height)
/*      */   {
/* 2667 */     lock.lock();
/*      */     try {
/* 2669 */       _gdk_window_resize(window, width, height);
/*      */     } finally {
/* 2671 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final native void _gdk_window_restack(long paramLong1, long paramLong2, boolean paramBoolean);
/*      */   
/*      */ 
/*      */   public static final void gdk_window_restack(long window, long sibling, boolean above)
/*      */   {
/* 2682 */     lock.lock();
/*      */     try {
/* 2684 */       _gdk_window_restack(window, sibling, above);
/*      */     } finally {
/* 2686 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gdk_window_set_background_pattern(long paramLong1, long paramLong2);
/*      */   
/* 2692 */   public static final void gdk_window_set_background_pattern(long window, long pattern) { lock.lock();
/*      */     try {
/* 2694 */       _gdk_window_set_background_pattern(window, pattern);
/*      */     } finally {
/* 2696 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gdk_window_set_back_pixmap(long paramLong1, long paramLong2, boolean paramBoolean);
/*      */   
/*      */ 
/*      */   public static final void gdk_window_set_back_pixmap(long window, long pixmap, boolean parent_relative)
/*      */   {
/* 2706 */     lock.lock();
/*      */     try {
/* 2708 */       _gdk_window_set_back_pixmap(window, pixmap, parent_relative);
/*      */     } finally {
/* 2710 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gdk_window_set_cursor(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final void gdk_window_set_cursor(long window, long cursor)
/*      */   {
/* 2719 */     lock.lock();
/*      */     try {
/* 2721 */       _gdk_window_set_cursor(window, cursor);
/*      */     } finally {
/* 2723 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gdk_window_set_decorations(long paramLong, int paramInt);
/*      */   
/*      */   /* Error */
/*      */   public static final void gdk_window_set_decorations(long window, int decorations)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 211	org/eclipse/swt/internal/gtk/GDK:_gdk_window_set_decorations	(JI)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #2732	-> byte code offset #0
/*      */     //   Java source line #2734	-> byte code offset #7
/*      */     //   Java source line #2736	-> byte code offset #12
/*      */     //   Java source line #2737	-> byte code offset #18
/*      */     //   Java source line #2736	-> byte code offset #21
/*      */     //   Java source line #2737	-> byte code offset #28
/*      */     //   Java source line #2738	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	window	long
/*      */     //   0	31	2	decorations	int
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gdk_window_set_functions(long paramLong, int paramInt);
/*      */   
/*      */   /* Error */
/*      */   public static final void gdk_window_set_functions(long window, int functions)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 212	org/eclipse/swt/internal/gtk/GDK:_gdk_window_set_functions	(JI)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #2745	-> byte code offset #0
/*      */     //   Java source line #2747	-> byte code offset #7
/*      */     //   Java source line #2749	-> byte code offset #12
/*      */     //   Java source line #2750	-> byte code offset #18
/*      */     //   Java source line #2749	-> byte code offset #21
/*      */     //   Java source line #2750	-> byte code offset #28
/*      */     //   Java source line #2751	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	window	long
/*      */     //   0	31	2	functions	int
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gdk_window_set_events(long paramLong, int paramInt);
/*      */   
/*      */   /* Error */
/*      */   public static final void gdk_window_set_events(long window, int event_mask)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 213	org/eclipse/swt/internal/gtk/GDK:_gdk_window_set_events	(JI)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #2755	-> byte code offset #0
/*      */     //   Java source line #2757	-> byte code offset #7
/*      */     //   Java source line #2759	-> byte code offset #12
/*      */     //   Java source line #2760	-> byte code offset #18
/*      */     //   Java source line #2759	-> byte code offset #21
/*      */     //   Java source line #2760	-> byte code offset #28
/*      */     //   Java source line #2761	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	window	long
/*      */     //   0	31	2	event_mask	int
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gdk_window_set_override_redirect(long paramLong, boolean paramBoolean);
/*      */   
/*      */   /* Error */
/*      */   public static final void gdk_window_set_override_redirect(long window, boolean override_redirect)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 214	org/eclipse/swt/internal/gtk/GDK:_gdk_window_set_override_redirect	(JZ)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #2768	-> byte code offset #0
/*      */     //   Java source line #2770	-> byte code offset #7
/*      */     //   Java source line #2772	-> byte code offset #12
/*      */     //   Java source line #2773	-> byte code offset #18
/*      */     //   Java source line #2772	-> byte code offset #21
/*      */     //   Java source line #2773	-> byte code offset #28
/*      */     //   Java source line #2774	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	window	long
/*      */     //   0	31	2	override_redirect	boolean
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gdk_window_set_user_data(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final void gdk_window_set_user_data(long window, long user_data)
/*      */   {
/* 2781 */     lock.lock();
/*      */     try {
/* 2783 */       _gdk_window_set_user_data(window, user_data);
/*      */     } finally {
/* 2785 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gdk_window_shape_combine_region(long paramLong1, long paramLong2, int paramInt1, int paramInt2);
/*      */   
/*      */   public static final void gdk_window_shape_combine_region(long window, long shape_region, int offset_x, int offset_y)
/*      */   {
/* 2794 */     lock.lock();
/*      */     try {
/* 2796 */       _gdk_window_shape_combine_region(window, shape_region, offset_x, offset_y);
/*      */     } finally {
/* 2798 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gdk_window_show(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void gdk_window_show(long window)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 217	org/eclipse/swt/internal/gtk/GDK:_gdk_window_show	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #2804	-> byte code offset #0
/*      */     //   Java source line #2806	-> byte code offset #7
/*      */     //   Java source line #2808	-> byte code offset #11
/*      */     //   Java source line #2809	-> byte code offset #17
/*      */     //   Java source line #2808	-> byte code offset #20
/*      */     //   Java source line #2809	-> byte code offset #27
/*      */     //   Java source line #2810	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	window	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native void _gdk_window_show_unraised(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void gdk_window_show_unraised(long window)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 218	org/eclipse/swt/internal/gtk/GDK:_gdk_window_show_unraised	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/gtk/GDK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #2814	-> byte code offset #0
/*      */     //   Java source line #2816	-> byte code offset #7
/*      */     //   Java source line #2818	-> byte code offset #11
/*      */     //   Java source line #2819	-> byte code offset #17
/*      */     //   Java source line #2818	-> byte code offset #20
/*      */     //   Java source line #2819	-> byte code offset #27
/*      */     //   Java source line #2820	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	window	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static long gdk_get_pointer(long display)
/*      */   {
/* 2823 */     if (GTK.GTK_VERSION >= OS.VERSION(3, 20, 0)) {
/* 2824 */       long default_seat = gdk_display_get_default_seat(display);
/* 2825 */       return gdk_seat_get_pointer(default_seat);
/*      */     }
/* 2827 */     long device_manager = gdk_display_get_device_manager(display);
/* 2828 */     return gdk_device_manager_get_client_pointer(device_manager);
/*      */   }
/*      */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/internal/gtk/GDK.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */