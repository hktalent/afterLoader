/*    */ package org.eclipse.swt.internal;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Platform
/*    */ {
/*    */   public static final String PLATFORM = "gtk";
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 20 */   public static final Lock lock = new Lock();
/*    */   
/*    */   public static boolean isLoadable() {
/* 23 */     return Library.isLoadable();
/*    */   }
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/internal/Platform.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */