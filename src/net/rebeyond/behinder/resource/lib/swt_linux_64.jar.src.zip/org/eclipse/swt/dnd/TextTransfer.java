/*     */ package org.eclipse.swt.dnd;
/*     */ 
/*     */ import org.eclipse.swt.internal.C;
/*     */ import org.eclipse.swt.internal.Converter;
/*     */ import org.eclipse.swt.internal.gtk.GDK;
/*     */ import org.eclipse.swt.internal.gtk.OS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TextTransfer
/*     */   extends ByteArrayTransfer
/*     */ {
/*  38 */   private static TextTransfer _instance = new TextTransfer();
/*     */   private static final String COMPOUND_TEXT = "COMPOUND_TEXT";
/*     */   private static final String UTF8_STRING = "UTF8_STRING";
/*     */   private static final String STRING = "STRING";
/*  42 */   private static final int COMPOUND_TEXT_ID = registerType("COMPOUND_TEXT");
/*  43 */   private static final int UTF8_STRING_ID = registerType("UTF8_STRING");
/*  44 */   private static final int STRING_ID = registerType("STRING");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static TextTransfer getInstance()
/*     */   {
/*  54 */     return _instance;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void javaToNative(Object object, TransferData transferData)
/*     */   {
/*  69 */     transferData.result = 0;
/*  70 */     if ((!checkText(object)) || (!isSupportedType(transferData))) {
/*  71 */       DND.error(2003);
/*     */     }
/*  73 */     String string = (String)object;
/*  74 */     byte[] utf8 = Converter.wcsToMbcs(string, true);
/*  75 */     if ((OS.isX11()) && (transferData.type == COMPOUND_TEXT_ID)) {
/*  76 */       long[] encoding = new long[1];
/*  77 */       int[] format = new int[1];
/*  78 */       long[] ctext = new long[1];
/*  79 */       int[] length = new int[1];
/*  80 */       boolean result = GDK.gdk_x11_display_utf8_to_compound_text(GDK.gdk_display_get_default(), utf8, encoding, format, ctext, length);
/*  81 */       if (!result) return;
/*  82 */       transferData.type = encoding[0];
/*  83 */       transferData.format = format[0];
/*  84 */       transferData.length = length[0];
/*  85 */       transferData.pValue = ctext[0];
/*  86 */       transferData.result = 1;
/*     */     }
/*  88 */     if (transferData.type == UTF8_STRING_ID) {
/*  89 */       long pValue = OS.g_malloc(utf8.length);
/*  90 */       if (pValue == 0L) return;
/*  91 */       C.memmove(pValue, utf8, utf8.length);
/*  92 */       transferData.type = UTF8_STRING_ID;
/*  93 */       transferData.format = 8;
/*  94 */       transferData.length = (utf8.length - 1);
/*  95 */       transferData.pValue = pValue;
/*  96 */       transferData.result = 1;
/*     */     }
/*  98 */     if (transferData.type == STRING_ID) {
/*  99 */       long string_target = GDK.gdk_utf8_to_string_target(utf8);
/* 100 */       if (string_target == 0L) return;
/* 101 */       transferData.type = STRING_ID;
/* 102 */       transferData.format = 8;
/* 103 */       transferData.length = C.strlen(string_target);
/* 104 */       transferData.pValue = string_target;
/* 105 */       transferData.result = 1;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object nativeToJava(TransferData transferData)
/*     */   {
/* 120 */     if ((!isSupportedType(transferData)) || (transferData.pValue == 0L)) return null;
/* 121 */     long[] list = new long[1];
/* 122 */     int count = GDK.gdk_text_property_to_utf8_list_for_display(GDK.gdk_display_get_default(), transferData.type, transferData.format, transferData.pValue, transferData.length, list);
/* 123 */     if (count == 0) return null;
/* 124 */     long[] ptr = new long[1];
/* 125 */     C.memmove(ptr, list[0], C.PTR_SIZEOF);
/* 126 */     int length = C.strlen(ptr[0]);
/* 127 */     byte[] utf8 = new byte[length];
/* 128 */     C.memmove(utf8, ptr[0], length);
/* 129 */     OS.g_strfreev(list[0]);
/*     */     
/* 131 */     char[] unicode = Converter.mbcsToWcs(utf8);
/* 132 */     String string = new String(unicode);
/* 133 */     int end = string.indexOf(0);
/* 134 */     return end == -1 ? string : string.substring(0, end);
/*     */   }
/*     */   
/*     */   protected int[] getTypeIds()
/*     */   {
/* 139 */     if (OS.isX11()) {
/* 140 */       return new int[] { UTF8_STRING_ID, COMPOUND_TEXT_ID, STRING_ID };
/*     */     }
/* 142 */     return new int[] { UTF8_STRING_ID, STRING_ID };
/*     */   }
/*     */   
/*     */   protected String[] getTypeNames()
/*     */   {
/* 147 */     if (OS.isX11()) {
/* 148 */       return new String[] { "UTF8_STRING", "COMPOUND_TEXT", "STRING" };
/*     */     }
/* 150 */     return new String[] { "UTF8_STRING", "STRING" };
/*     */   }
/*     */   
/*     */   boolean checkText(Object object) {
/* 154 */     return (object != null) && ((object instanceof String)) && (((String)object).length() > 0);
/*     */   }
/*     */   
/*     */   protected boolean validate(Object object)
/*     */   {
/* 159 */     return checkText(object);
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/dnd/TextTransfer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */