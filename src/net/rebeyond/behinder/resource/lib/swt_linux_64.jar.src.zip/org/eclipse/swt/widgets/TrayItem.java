/*     */ package org.eclipse.swt.widgets;
/*     */ 
/*     */ import org.eclipse.swt.events.MenuDetectListener;
/*     */ import org.eclipse.swt.events.SelectionListener;
/*     */ import org.eclipse.swt.graphics.Image;
/*     */ import org.eclipse.swt.graphics.Rectangle;
/*     */ import org.eclipse.swt.graphics.Region;
/*     */ import org.eclipse.swt.internal.C;
/*     */ import org.eclipse.swt.internal.Converter;
/*     */ import org.eclipse.swt.internal.DPIUtil;
/*     */ import org.eclipse.swt.internal.ImageList;
/*     */ import org.eclipse.swt.internal.gtk.GDK;
/*     */ import org.eclipse.swt.internal.gtk.GTK;
/*     */ import org.eclipse.swt.internal.gtk.GdkEventButton;
/*     */ import org.eclipse.swt.internal.gtk.GdkImage;
/*     */ import org.eclipse.swt.internal.gtk.GtkAllocation;
/*     */ import org.eclipse.swt.internal.gtk.OS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TrayItem
/*     */   extends Item
/*     */ {
/*     */   Tray parent;
/*     */   ToolTip toolTip;
/*     */   String toolTipText;
/*     */   long imageHandle;
/*     */   long tooltipsHandle;
/*     */   ImageList imageList;
/*     */   Image highlightImage;
/*     */   
/*     */   public TrayItem(Tray parent, int style)
/*     */   {
/*  79 */     super(parent, style);
/*  80 */     this.parent = parent;
/*  81 */     createWidget(parent.getItemCount());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addMenuDetectListener(MenuDetectListener listener)
/*     */   {
/* 106 */     checkWidget();
/* 107 */     if (listener == null) error(4);
/* 108 */     TypedListener typedListener = new TypedListener(listener);
/* 109 */     addListener(35, typedListener);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addSelectionListener(SelectionListener listener)
/*     */   {
/* 137 */     checkWidget();
/* 138 */     if (listener == null) error(4);
/* 139 */     TypedListener typedListener = new TypedListener(listener);
/* 140 */     addListener(13, typedListener);
/* 141 */     addListener(14, typedListener);
/*     */   }
/*     */   
/*     */   protected void checkSubclass()
/*     */   {
/* 146 */     if (!isValidSubclass()) error(43);
/*     */   }
/*     */   
/*     */   void createWidget(int index)
/*     */   {
/* 151 */     super.createWidget(index);
/* 152 */     this.parent.createItem(this, index);
/*     */   }
/*     */   
/*     */   void createHandle(int index)
/*     */   {
/* 157 */     this.state |= 0x8;
/* 158 */     this.handle = GTK.gtk_status_icon_new();
/* 159 */     if (this.handle == 0L) error(2);
/* 160 */     this.imageHandle = GTK.gtk_image_new();
/* 161 */     GTK.gtk_status_icon_set_visible(this.handle, true);
/*     */   }
/*     */   
/*     */   void deregister()
/*     */   {
/* 166 */     super.deregister();
/* 167 */     this.display.removeWidget(this.imageHandle);
/*     */   }
/*     */   
/*     */   void destroyWidget()
/*     */   {
/* 172 */     this.parent.destroyItem(this);
/* 173 */     releaseHandle();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Tray getParent()
/*     */   {
/* 189 */     checkWidget();
/* 190 */     return this.parent;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Image getHighlightImage()
/*     */   {
/* 207 */     checkWidget();
/* 208 */     return this.highlightImage;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ToolTip getToolTip()
/*     */   {
/* 225 */     checkWidget();
/* 226 */     return this.toolTip;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getToolTipText()
/*     */   {
/* 241 */     checkWidget();
/* 242 */     return this.toolTipText;
/*     */   }
/*     */   
/*     */   long gtk_activate(long widget)
/*     */   {
/* 247 */     sendSelectionEvent(13);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 254 */     long nextEvent = GDK.gdk_event_peek();
/* 255 */     if (nextEvent != 0L) {
/* 256 */       int nextEventType = GDK.GDK_EVENT_TYPE(nextEvent);
/* 257 */       long currEvent = GTK.gtk_get_current_event();
/* 258 */       int currEventType = 0;
/* 259 */       if (currEvent != 0L) {
/* 260 */         currEventType = GDK.GDK_EVENT_TYPE(currEvent);
/* 261 */         GDK.gdk_event_free(currEvent);
/*     */       }
/* 263 */       GDK.gdk_event_free(nextEvent);
/* 264 */       if ((currEventType == 4) && (nextEventType == 5)) {
/* 265 */         sendSelectionEvent(14);
/*     */       }
/*     */     }
/* 268 */     return 0L;
/*     */   }
/*     */   
/*     */   long gtk_button_press_event(long widget, long eventPtr)
/*     */   {
/* 273 */     GdkEventButton gdkEvent = new GdkEventButton();
/* 274 */     OS.memmove(gdkEvent, eventPtr, GdkEventButton.sizeof);
/* 275 */     if (gdkEvent.type == 6) return 0L;
/* 276 */     if ((gdkEvent.button == 3) && (gdkEvent.type == 4)) {
/* 277 */       sendEvent(35);
/* 278 */       return 0L;
/*     */     }
/* 280 */     if (gdkEvent.type == 5) {
/* 281 */       sendSelectionEvent(14);
/*     */     } else {
/* 283 */       sendSelectionEvent(13);
/*     */     }
/* 285 */     return 0L;
/*     */   }
/*     */   
/*     */   long gtk_size_allocate(long widget, long allocation)
/*     */   {
/* 290 */     if ((this.image != null) && (this.image.mask != 0L) && 
/* 291 */       (GDK.gdk_drawable_get_depth(this.image.mask) == 1)) {
/* 292 */       GtkAllocation widgetAllocation = new GtkAllocation();
/* 293 */       GTK.gtk_widget_get_allocation(widget, widgetAllocation);
/* 294 */       int xoffset = (int)Math.floor(widgetAllocation.x + (widgetAllocation.width - GTK.GTK_WIDGET_REQUISITION_WIDTH(widget)) * 0.5D + 0.5D);
/* 295 */       int yoffset = (int)Math.floor(widgetAllocation.y + (widgetAllocation.height - GTK.GTK_WIDGET_REQUISITION_HEIGHT(widget)) * 0.5D + 0.5D);
/* 296 */       Rectangle b = this.image.getBoundsInPixels();
/* 297 */       long gdkImagePtr = GDK.gdk_drawable_get_image(this.image.mask, 0, 0, b.width, b.height);
/* 298 */       if (gdkImagePtr == 0L) error(2);
/* 299 */       GdkImage gdkImage = new GdkImage();
/* 300 */       OS.memmove(gdkImage, gdkImagePtr);
/* 301 */       byte[] maskData = new byte[gdkImage.bpl * gdkImage.height];
/* 302 */       C.memmove(maskData, gdkImage.mem, maskData.length);
/* 303 */       OS.g_object_unref(gdkImagePtr);
/* 304 */       Region region = new Region(this.display);
/* 305 */       for (int y = 0; y < b.height; y++) {
/* 306 */         for (int x = 0; x < b.width; x++) {
/* 307 */           int index = y * gdkImage.bpl + (x >> 3);
/* 308 */           int theByte = maskData[index] & 0xFF;
/* 309 */           int mask = 1 << (x & 0x7);
/* 310 */           if ((theByte & mask) != 0) {
/* 311 */             Rectangle rect = DPIUtil.autoScaleDown(new Rectangle(xoffset + x, yoffset + y, 1, 1));
/* 312 */             region.add(rect.x, rect.y, rect.width, rect.height);
/*     */           }
/*     */         }
/*     */       }
/* 316 */       GTK.gtk_widget_realize(this.handle);
/* 317 */       long window = gtk_widget_get_window(this.handle);
/* 318 */       GDK.gdk_window_shape_combine_region(window, region.handle, 0, 0);
/* 319 */       region.dispose();
/*     */     }
/*     */     
/* 322 */     return 0L;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   long gtk_status_icon_popup_menu(long widget, long button, long activate_time)
/*     */   {
/* 331 */     Display display = this.display;
/* 332 */     display.currentTrayItem = this;
/* 333 */     sendEvent(35);
/* 334 */     if (!isDisposed()) display.runPopups();
/* 335 */     display.currentTrayItem = null;
/* 336 */     return 0L;
/*     */   }
/*     */   
/*     */   void hookEvents()
/*     */   {
/* 341 */     OS.g_signal_connect_closure(this.handle, OS.activate, this.display.getClosure(1), false);
/* 342 */     OS.g_signal_connect_closure(this.handle, OS.popup_menu, this.display.getClosure(63), false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getVisible()
/*     */   {
/* 357 */     checkWidget();
/* 358 */     return GTK.gtk_status_icon_get_visible(this.handle);
/*     */   }
/*     */   
/*     */   void register()
/*     */   {
/* 363 */     super.register();
/* 364 */     this.display.addWidget(this.imageHandle, this);
/*     */   }
/*     */   
/*     */   void releaseHandle()
/*     */   {
/* 369 */     if (this.handle != 0L) {
/* 370 */       OS.g_object_unref(this.handle);
/*     */     }
/* 372 */     this.handle = (this.imageHandle = 0L);
/* 373 */     super.releaseHandle();
/* 374 */     this.parent = null;
/*     */   }
/*     */   
/*     */   void releaseWidget()
/*     */   {
/* 379 */     super.releaseWidget();
/* 380 */     if (this.tooltipsHandle != 0L) OS.g_object_unref(this.tooltipsHandle);
/* 381 */     this.tooltipsHandle = 0L;
/* 382 */     if (this.imageList != null) this.imageList.dispose();
/* 383 */     this.imageList = null;
/* 384 */     this.toolTipText = null;
/* 385 */     this.highlightImage = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeMenuDetectListener(MenuDetectListener listener)
/*     */   {
/* 409 */     checkWidget();
/* 410 */     if (listener == null) error(4);
/* 411 */     if (this.eventTable == null) return;
/* 412 */     this.eventTable.unhook(35, listener);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeSelectionListener(SelectionListener listener)
/*     */   {
/* 433 */     checkWidget();
/* 434 */     if (listener == null) error(4);
/* 435 */     if (this.eventTable == null) return;
/* 436 */     this.eventTable.unhook(13, listener);
/* 437 */     this.eventTable.unhook(14, listener);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setHighlightImage(Image image)
/*     */   {
/* 456 */     checkWidget();
/* 457 */     if ((image != null) && (image.isDisposed())) error(5);
/* 458 */     this.highlightImage = image;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setImage(Image image)
/*     */   {
/* 476 */     checkWidget();
/* 477 */     if ((image != null) && (image.isDisposed())) error(5);
/* 478 */     this.image = image;
/* 479 */     if (image != null) {
/* 480 */       if (this.imageList == null) this.imageList = new ImageList();
/* 481 */       int imageIndex = this.imageList.indexOf(image);
/* 482 */       if (imageIndex == -1) {
/* 483 */         imageIndex = this.imageList.add(image);
/*     */       } else {
/* 485 */         this.imageList.put(imageIndex, image);
/*     */       }
/* 487 */       long pixbuf = this.imageList.getPixbuf(imageIndex);
/* 488 */       GTK.gtk_status_icon_set_from_pixbuf(this.handle, pixbuf);
/* 489 */       GTK.gtk_status_icon_set_visible(this.handle, true);
/*     */     } else {
/* 491 */       GTK.gtk_widget_set_size_request(this.handle, 1, 1);
/* 492 */       GTK.gtk_status_icon_set_from_pixbuf(this.handle, 0L);
/* 493 */       GTK.gtk_status_icon_set_visible(this.handle, false);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setToolTip(ToolTip toolTip)
/*     */   {
/* 511 */     checkWidget();
/* 512 */     ToolTip oldTip = this.toolTip;ToolTip newTip = toolTip;
/* 513 */     if (oldTip != null) oldTip.item = null;
/* 514 */     this.toolTip = newTip;
/* 515 */     if (newTip != null) { newTip.item = this;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setToolTipText(String string)
/*     */   {
/* 544 */     checkWidget();
/* 545 */     this.toolTipText = string;
/* 546 */     byte[] buffer = null;
/* 547 */     if ((string != null) && (string.length() > 0)) {
/* 548 */       buffer = Converter.wcsToMbcs(string, true);
/*     */     }
/* 550 */     GTK.gtk_status_icon_set_tooltip_text(this.handle, buffer);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setVisible(boolean visible)
/*     */   {
/* 565 */     checkWidget();
/* 566 */     if (GTK.gtk_status_icon_get_visible(this.handle) == visible) return;
/* 567 */     if (visible)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 573 */       sendEvent(22);
/* 574 */       if (isDisposed()) return;
/* 575 */       GTK.gtk_status_icon_set_visible(this.handle, visible);
/*     */     } else {
/* 577 */       GTK.gtk_status_icon_set_visible(this.handle, visible);
/* 578 */       sendEvent(23);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/widgets/TrayItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */