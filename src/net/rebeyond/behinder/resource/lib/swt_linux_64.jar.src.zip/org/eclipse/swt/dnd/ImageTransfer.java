/*     */ package org.eclipse.swt.dnd;
/*     */ 
/*     */ import org.eclipse.swt.SWT;
/*     */ import org.eclipse.swt.graphics.Image;
/*     */ import org.eclipse.swt.graphics.ImageData;
/*     */ import org.eclipse.swt.internal.Converter;
/*     */ import org.eclipse.swt.internal.ImageList;
/*     */ import org.eclipse.swt.internal.gtk.GDK;
/*     */ import org.eclipse.swt.internal.gtk.OS;
/*     */ import org.eclipse.swt.widgets.Display;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ImageTransfer
/*     */   extends ByteArrayTransfer
/*     */ {
/*  37 */   private static ImageTransfer _instance = new ImageTransfer();
/*     */   
/*     */   private static final String JPEG = "image/jpeg";
/*  40 */   private static final int JPEG_ID = registerType("image/jpeg");
/*     */   private static final String PNG = "image/png";
/*  42 */   private static final int PNG_ID = registerType("image/png");
/*     */   private static final String BMP = "image/bmp";
/*  44 */   private static final int BMP_ID = registerType("image/bmp");
/*     */   private static final String EPS = "image/eps";
/*  46 */   private static final int EPS_ID = registerType("image/eps");
/*     */   private static final String PCX = "image/pcx";
/*  48 */   private static final int PCX_ID = registerType("image/pcx");
/*     */   private static final String PPM = "image/ppm";
/*  50 */   private static final int PPM_ID = registerType("image/ppm");
/*     */   private static final String RGB = "image/ppm";
/*  52 */   private static final int RGB_ID = registerType("image/ppm");
/*     */   private static final String TGA = "image/tga";
/*  54 */   private static final int TGA_ID = registerType("image/tga");
/*     */   private static final String XBM = "image/xbm";
/*  56 */   private static final int XBM_ID = registerType("image/xbm");
/*     */   private static final String XPM = "image/xpm";
/*  58 */   private static final int XPM_ID = registerType("image/xpm");
/*     */   private static final String XV = "image/xv";
/*  60 */   private static final int XV_ID = registerType("image/xv");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ImageTransfer getInstance()
/*     */   {
/*  70 */     return _instance;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void javaToNative(Object object, TransferData transferData)
/*     */   {
/*  85 */     if ((!checkImage(object)) || (!isSupportedType(transferData))) {
/*  86 */       DND.error(2003);
/*     */     }
/*  88 */     ImageData imgData = (ImageData)object;
/*  89 */     if (imgData == null) SWT.error(4);
/*  90 */     Image image = new Image(Display.getCurrent(), imgData);
/*  91 */     long pixbuf = ImageList.createPixbuf(image);
/*  92 */     if (pixbuf != 0L) {
/*  93 */       String typeStr = "";
/*  94 */       if (transferData.type == JPEG_ID) { typeStr = "jpeg";
/*  95 */       } else if (transferData.type == PNG_ID) { typeStr = "png";
/*  96 */       } else if (transferData.type == BMP_ID) { typeStr = "bmp";
/*  97 */       } else if (transferData.type == EPS_ID) { typeStr = "eps";
/*  98 */       } else if (transferData.type == PCX_ID) { typeStr = "pcx";
/*  99 */       } else if (transferData.type == PPM_ID) { typeStr = "ppm";
/* 100 */       } else if (transferData.type == RGB_ID) { typeStr = "rgb";
/* 101 */       } else if (transferData.type == TGA_ID) { typeStr = "tga";
/* 102 */       } else if (transferData.type == XBM_ID) { typeStr = "xbm";
/* 103 */       } else if (transferData.type == XPM_ID) { typeStr = "xpm";
/* 104 */       } else if (transferData.type == XV_ID) typeStr = "xv";
/* 105 */       byte[] type = Converter.wcsToMbcs(typeStr, true);
/* 106 */       long[] buffer = new long[1];
/* 107 */       long[] len = new long[1];
/* 108 */       if (type == null) return;
/* 109 */       GDK.gdk_pixbuf_save_to_bufferv(pixbuf, buffer, len, type, null, null, null);
/* 110 */       OS.g_object_unref(pixbuf);
/* 111 */       transferData.pValue = buffer[0];
/* 112 */       transferData.length = ((int)(len[0] + 3L) / 4 * 4);
/* 113 */       transferData.result = 1;
/* 114 */       transferData.format = 32;
/*     */     }
/* 116 */     image.dispose();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object nativeToJava(TransferData transferData)
/*     */   {
/* 131 */     ImageData imgData = null;
/* 132 */     if (transferData.length > 0) {
/* 133 */       long loader = GDK.gdk_pixbuf_loader_new();
/*     */       try {
/* 135 */         GDK.gdk_pixbuf_loader_write(loader, transferData.pValue, transferData.length, null);
/* 136 */         GDK.gdk_pixbuf_loader_close(loader, null);
/* 137 */         long pixbuf = GDK.gdk_pixbuf_loader_get_pixbuf(loader);
/* 138 */         if (pixbuf != 0L) {
/* 139 */           Image img = Image.gtk_new_from_pixbuf(Display.getCurrent(), 0, pixbuf);
/* 140 */           imgData = img.getImageData();
/* 141 */           img.dispose();
/*     */         }
/*     */       } finally {
/* 144 */         OS.g_object_unref(loader);
/*     */       }
/*     */     }
/* 147 */     return imgData;
/*     */   }
/*     */   
/*     */   protected int[] getTypeIds()
/*     */   {
/* 152 */     return new int[] { PNG_ID, BMP_ID, EPS_ID, JPEG_ID, PCX_ID, PPM_ID, RGB_ID, TGA_ID, XBM_ID, XPM_ID, XV_ID };
/*     */   }
/*     */   
/*     */   protected String[] getTypeNames()
/*     */   {
/* 157 */     return new String[] { "image/png", "image/bmp", "image/eps", "image/jpeg", "image/pcx", "image/ppm", "image/ppm", "image/tga", "image/xbm", "image/xpm", "image/xv" };
/*     */   }
/*     */   
/*     */   boolean checkImage(Object object) {
/* 161 */     if ((object == null) || (!(object instanceof ImageData))) return false;
/* 162 */     return true;
/*     */   }
/*     */   
/*     */   protected boolean validate(Object object)
/*     */   {
/* 167 */     return checkImage(object);
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/dnd/ImageTransfer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */