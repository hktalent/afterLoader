/*    */ package org.eclipse.swt.internal;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Lock
/*    */ {
/*    */   int count;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   int waitCount;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   Thread owner;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public int lock()
/*    */   {
/* 28 */     synchronized (this) {
/* 29 */       Thread current = Thread.currentThread();
/* 30 */       if (this.owner != current) {
/* 31 */         this.waitCount += 1;
/* 32 */         while (this.count > 0) {
/*    */           try {
/* 34 */             wait();
/*    */           }
/*    */           catch (InterruptedException localInterruptedException) {}
/*    */         }
/*    */         
/* 39 */         this.waitCount -= 1;
/* 40 */         this.owner = current;
/*    */       }
/* 42 */       return ++this.count;
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void unlock()
/*    */   {
/* 51 */     synchronized (this) {
/* 52 */       Thread current = Thread.currentThread();
/* 53 */       if ((this.owner == current) && 
/* 54 */         (--this.count == 0)) {
/* 55 */         this.owner = null;
/* 56 */         if (this.waitCount > 0) notifyAll();
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/internal/Lock.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */