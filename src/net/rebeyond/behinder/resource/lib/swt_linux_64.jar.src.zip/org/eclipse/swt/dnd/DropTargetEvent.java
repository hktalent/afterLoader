/*     */ package org.eclipse.swt.dnd;
/*     */ 
/*     */ import org.eclipse.swt.events.TypedEvent;
/*     */ import org.eclipse.swt.widgets.Widget;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DropTargetEvent
/*     */   extends TypedEvent
/*     */ {
/*     */   public int x;
/*     */   public int y;
/*     */   public int detail;
/*     */   public int operations;
/*     */   public int feedback;
/*     */   public Widget item;
/*     */   public TransferData currentDataType;
/*     */   public TransferData[] dataTypes;
/*     */   static final long serialVersionUID = 3256727264573338678L;
/*     */   
/*     */   public DropTargetEvent(DNDEvent e)
/*     */   {
/*  95 */     super(e);
/*  96 */     this.data = e.data;
/*  97 */     this.x = e.x;
/*  98 */     this.y = e.y;
/*  99 */     this.detail = e.detail;
/* 100 */     this.currentDataType = e.dataType;
/* 101 */     this.dataTypes = e.dataTypes;
/* 102 */     this.operations = e.operations;
/* 103 */     this.feedback = e.feedback;
/* 104 */     this.item = e.item;
/*     */   }
/*     */   
/* 107 */   void updateEvent(DNDEvent e) { e.widget = this.widget;
/* 108 */     e.time = this.time;
/* 109 */     e.data = this.data;
/* 110 */     e.x = this.x;
/* 111 */     e.y = this.y;
/* 112 */     e.detail = this.detail;
/* 113 */     e.dataType = this.currentDataType;
/* 114 */     e.dataTypes = this.dataTypes;
/* 115 */     e.operations = this.operations;
/* 116 */     e.feedback = this.feedback;
/* 117 */     e.item = this.item;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 127 */     String string = super.toString();
/* 128 */     StringBuilder sb = new StringBuilder();
/* 129 */     sb.append(string.substring(0, string.length() - 1));
/* 130 */     sb.append(" x=");sb.append(this.x);
/* 131 */     sb.append(" y=");sb.append(this.y);
/* 132 */     sb.append(" item=");sb.append(this.item);
/* 133 */     sb.append(" operations=");sb.append(this.operations);
/* 134 */     sb.append(" operation=");sb.append(this.detail);
/* 135 */     sb.append(" feedback=");sb.append(this.feedback);
/* 136 */     sb.append(" dataTypes={ ");
/* 137 */     if (this.dataTypes != null) {
/* 138 */       for (int i = 0; i < this.dataTypes.length; i++) {
/* 139 */         sb.append(this.dataTypes[i].type);sb.append(' ');
/*     */       }
/*     */     }
/* 142 */     sb.append('}');
/* 143 */     sb.append(" currentDataType=");sb.append(this.currentDataType != null ? this.currentDataType.type : 48L);
/* 144 */     sb.append('}');
/* 145 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/dnd/DropTargetEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */