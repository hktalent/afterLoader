/*     */ package org.eclipse.swt.internal.dnd.gtk;
/*     */ 
/*     */ import org.eclipse.swt.SWT;
/*     */ import org.eclipse.swt.dnd.DragSourceEffect;
/*     */ import org.eclipse.swt.dnd.DragSourceEvent;
/*     */ import org.eclipse.swt.graphics.Image;
/*     */ import org.eclipse.swt.internal.cairo.Cairo;
/*     */ import org.eclipse.swt.internal.gtk.GDK;
/*     */ import org.eclipse.swt.internal.gtk.GTK;
/*     */ import org.eclipse.swt.internal.gtk.GdkRectangle;
/*     */ import org.eclipse.swt.internal.gtk.OS;
/*     */ import org.eclipse.swt.widgets.Display;
/*     */ import org.eclipse.swt.widgets.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ListDragSourceEffect
/*     */   extends DragSourceEffect
/*     */ {
/*  38 */   Image dragSourceImage = null;
/*     */   
/*     */ 
/*     */ 
/*     */   private List dragList;
/*     */   
/*     */ 
/*     */ 
/*     */   public ListDragSourceEffect(List list)
/*     */   {
/*  48 */     super(list);
/*  49 */     this.dragList = list;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void dragFinished(DragSourceEvent event)
/*     */   {
/*  63 */     if (this.dragSourceImage != null) this.dragSourceImage.dispose();
/*  64 */     this.dragSourceImage = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void dragStart(DragSourceEvent event)
/*     */   {
/*  80 */     event.image = getDragSourceImage(event);
/*     */   }
/*     */   
/*     */   Image getDragSourceImage(DragSourceEvent event) {
/*  84 */     if (this.dragSourceImage != null) this.dragSourceImage.dispose();
/*  85 */     this.dragSourceImage = null;
/*     */     
/*     */ 
/*  88 */     if ((this.dragList.isListening(40)) || (this.dragList.isListening(42))) { return null;
/*     */     }
/*  90 */     long handle = this.dragList.handle;
/*  91 */     long selection = GTK.gtk_tree_view_get_selection(handle);
/*  92 */     long[] model = null;
/*  93 */     long list = GTK.gtk_tree_selection_get_selected_rows(selection, model);
/*  94 */     if (list == 0L) return null;
/*  95 */     int count = Math.min(10, OS.g_list_length(list));
/*  96 */     long originalList = list;
/*     */     
/*  98 */     Display display = this.dragList.getDisplay();
/*  99 */     if (count == 1) {
/* 100 */       long path = OS.g_list_nth_data(list, 0);
/* 101 */       long icon = GTK.gtk_tree_view_create_row_drag_icon(handle, path);
/* 102 */       this.dragSourceImage = Image.gtk_new(display, 1, icon, 0L);
/* 103 */       GTK.gtk_tree_path_free(path);
/*     */     } else {
/* 105 */       int width = 0;int height = 0;
/* 106 */       int[] w = new int[1];int[] h = new int[1];
/* 107 */       int[] yy = new int[count];int[] hh = new int[count];
/* 108 */       long[] icons = new long[count];
/* 109 */       GdkRectangle rect = new GdkRectangle();
/* 110 */       for (int i = 0; i < count; i++) {
/* 111 */         long path = OS.g_list_data(list);
/* 112 */         GTK.gtk_tree_view_get_cell_area(handle, path, 0L, rect);
/* 113 */         icons[i] = GTK.gtk_tree_view_create_row_drag_icon(handle, path);
/* 114 */         if (GTK.GTK3) {
/* 115 */           switch (Cairo.cairo_surface_get_type(icons[i])) {
/*     */           case 0: 
/* 117 */             w[0] = Cairo.cairo_image_surface_get_width(icons[i]);
/* 118 */             h[0] = Cairo.cairo_image_surface_get_height(icons[i]);
/* 119 */             break;
/*     */           case 3: 
/* 121 */             w[0] = Cairo.cairo_xlib_surface_get_width(icons[i]);
/* 122 */             h[0] = Cairo.cairo_xlib_surface_get_height(icons[i]);
/*     */           }
/*     */           
/*     */         } else {
/* 126 */           GDK.gdk_pixmap_get_size(icons[i], w, h);
/*     */         }
/* 128 */         width = Math.max(width, w[0]);
/* 129 */         height = rect.y + h[0] - yy[0];
/* 130 */         yy[i] = rect.y;
/* 131 */         hh[i] = h[0];
/* 132 */         list = OS.g_list_next(list);
/* 133 */         GTK.gtk_tree_path_free(path); }
/*     */       long cairo;
/*     */       long surface;
/*     */       long cairo;
/* 137 */       if (GTK.GTK3) {
/* 138 */         long surface = Cairo.cairo_image_surface_create(0, width, height);
/* 139 */         if (surface == 0L) SWT.error(2);
/* 140 */         cairo = Cairo.cairo_create(surface);
/*     */       } else {
/* 142 */         surface = GDK.gdk_pixmap_new(GDK.gdk_get_default_root_window(), width, height, -1);
/* 143 */         if (surface == 0L) SWT.error(2);
/* 144 */         cairo = GDK.gdk_cairo_create(surface);
/*     */       }
/* 146 */       if (cairo == 0L) SWT.error(2);
/* 147 */       Cairo.cairo_set_operator(cairo, 1);
/* 148 */       for (int i = 0; i < count; i++) {
/* 149 */         if (GTK.GTK3) {
/* 150 */           Cairo.cairo_set_source_surface(cairo, icons[i], 2.0D, yy[i] - yy[0] + 2);
/*     */         } else {
/* 152 */           GDK.gdk_cairo_set_source_pixmap(cairo, icons[i], 0.0D, yy[i] - yy[0]);
/*     */         }
/* 154 */         Cairo.cairo_rectangle(cairo, 0.0D, yy[i] - yy[0], width, hh[i]);
/* 155 */         Cairo.cairo_fill(cairo);
/* 156 */         if (GTK.GTK3) {
/* 157 */           Cairo.cairo_surface_destroy(icons[i]);
/*     */         }
/*     */       }
/* 160 */       Cairo.cairo_destroy(cairo);
/* 161 */       if (GTK.GTK3) {
/* 162 */         this.dragSourceImage = Image.gtk_new(display, 1, surface, 0L);
/*     */       } else {
/* 164 */         long pixbuf = GDK.gdk_pixbuf_new(0, true, 8, width, height);
/* 165 */         if (pixbuf == 0L) SWT.error(2);
/* 166 */         long colormap = GDK.gdk_colormap_get_system();
/* 167 */         GDK.gdk_pixbuf_get_from_drawable(pixbuf, surface, colormap, 0, 0, 0, 0, width, height);
/* 168 */         this.dragSourceImage = Image.gtk_new_from_pixbuf(display, 1, pixbuf);
/*     */       }
/*     */     }
/* 171 */     OS.g_list_free(originalList);
/* 172 */     return this.dragSourceImage;
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/internal/dnd/gtk/ListDragSourceEffect.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */