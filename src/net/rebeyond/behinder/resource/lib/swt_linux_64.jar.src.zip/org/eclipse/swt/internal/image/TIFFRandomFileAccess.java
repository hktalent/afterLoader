/*    */ package org.eclipse.swt.internal.image;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class TIFFRandomFileAccess
/*    */ {
/*    */   LEDataInputStream inputStream;
/*    */   int start;
/*    */   int current;
/*    */   int next;
/*    */   byte[][] buffers;
/*    */   static final int CHUNK_SIZE = 8192;
/*    */   static final int LIST_SIZE = 128;
/*    */   
/*    */   public TIFFRandomFileAccess(LEDataInputStream stream)
/*    */   {
/* 25 */     this.inputStream = stream;
/* 26 */     this.start = (this.current = this.next = this.inputStream.getPosition());
/* 27 */     this.buffers = new byte[''][];
/*    */   }
/*    */   
/*    */   void seek(int pos) throws IOException {
/* 31 */     if (pos == this.current) return;
/* 32 */     if (pos < this.start) throw new IOException();
/* 33 */     this.current = pos;
/* 34 */     if (this.current > this.next) {
/* 35 */       int n = this.current - this.next;
/*    */       
/* 37 */       int index = this.next / 8192;
/* 38 */       int offset = this.next % 8192;
/* 39 */       while (n > 0) {
/* 40 */         if (index >= this.buffers.length) {
/* 41 */           byte[][] oldBuffers = this.buffers;
/* 42 */           this.buffers = new byte[Math.max(index + 1, oldBuffers.length + 128)][];
/* 43 */           System.arraycopy(oldBuffers, 0, this.buffers, 0, oldBuffers.length);
/*    */         }
/* 45 */         if (this.buffers[index] == null) this.buffers[index] = new byte[' '];
/* 46 */         int cnt = this.inputStream.read(this.buffers[index], offset, Math.min(n, 8192 - offset));
/* 47 */         n -= cnt;
/* 48 */         this.next += cnt;
/* 49 */         index++;
/* 50 */         offset = 0;
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   void read(byte[] b) throws IOException {
/* 56 */     int size = b.length;
/* 57 */     int nCached = Math.min(size, this.next - this.current);
/* 58 */     int nMissing = size - this.next + this.current;
/* 59 */     int destNext = 0;
/* 60 */     if (nCached > 0)
/*    */     {
/* 62 */       int index = this.current / 8192;
/* 63 */       int offset = this.current % 8192;
/* 64 */       while (nCached > 0) {
/* 65 */         int cnt = Math.min(nCached, 8192 - offset);
/* 66 */         System.arraycopy(this.buffers[index], offset, b, destNext, cnt);
/* 67 */         nCached -= cnt;
/* 68 */         destNext += cnt;
/* 69 */         index++;
/* 70 */         offset = 0;
/*    */       }
/*    */     }
/* 73 */     if (nMissing > 0)
/*    */     {
/* 75 */       int index = this.next / 8192;
/* 76 */       int offset = this.next % 8192;
/* 77 */       while (nMissing > 0) {
/* 78 */         if (index >= this.buffers.length) {
/* 79 */           byte[][] oldBuffers = this.buffers;
/* 80 */           this.buffers = new byte[Math.max(index, oldBuffers.length + 128)][];
/* 81 */           System.arraycopy(oldBuffers, 0, this.buffers, 0, oldBuffers.length);
/*    */         }
/* 83 */         if (this.buffers[index] == null) this.buffers[index] = new byte[' '];
/* 84 */         int cnt = this.inputStream.read(this.buffers[index], offset, Math.min(nMissing, 8192 - offset));
/* 85 */         System.arraycopy(this.buffers[index], offset, b, destNext, cnt);
/* 86 */         nMissing -= cnt;
/* 87 */         this.next += cnt;
/* 88 */         destNext += cnt;
/* 89 */         index++;
/* 90 */         offset = 0;
/*    */       }
/*    */     }
/* 93 */     this.current += size;
/*    */   }
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/internal/image/TIFFRandomFileAccess.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */