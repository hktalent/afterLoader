/*     */ package org.eclipse.swt.internal.image;
/*     */ 
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PngHuffmanTable
/*     */ {
/*     */   CodeLengthInfo[] codeLengthInfo;
/*     */   int[] codeValues;
/*     */   static final int MAX_CODE_LENGTH = 15;
/*     */   static final int BAD_CODE = 268435455;
/*  21 */   static final int[] incs = { 1391376, 463792, 198768, 86961, 33936, 13776, 4592, 1968, 861, 336, 112, 48, 21, 7, 3, 1 };
/*     */   
/*     */   PngHuffmanTable(int[] lengths)
/*     */   {
/*  25 */     initialize(lengths);
/*  26 */     generateTable(lengths);
/*     */   }
/*     */   
/*     */   private void initialize(int[] lengths) {
/*  30 */     this.codeValues = new int[lengths.length];
/*  31 */     for (int i = 0; i < this.codeValues.length; i++) {
/*  32 */       this.codeValues[i] = i;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  38 */     this.codeLengthInfo = new CodeLengthInfo[15];
/*  39 */     for (int i = 0; i < 15; i++) {
/*  40 */       this.codeLengthInfo[i] = new CodeLengthInfo();
/*  41 */       this.codeLengthInfo[i].length = i;
/*  42 */       this.codeLengthInfo[i].baseIndex = 0;
/*  43 */       this.codeLengthInfo[i].min = 268435455;
/*  44 */       this.codeLengthInfo[i].max = -1;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private void generateTable(int[] lengths)
/*     */   {
/*  51 */     for (int k = 0; k < 16; k++) {
/*  52 */       int h = incs[k]; for (int i = h; i < lengths.length; i++) {
/*  53 */         int v = lengths[i];
/*  54 */         int codeValuesTemp = this.codeValues[i];
/*  55 */         int j = i;
/*  56 */         while ((j >= h) && ((lengths[(j - h)] > v) || ((lengths[(j - h)] == v) && (this.codeValues[(j - h)] > codeValuesTemp)))) {
/*  57 */           lengths[j] = lengths[(j - h)];
/*  58 */           this.codeValues[j] = this.codeValues[(j - h)];
/*  59 */           j -= h;
/*     */         }
/*  61 */         lengths[j] = v;
/*  62 */         this.codeValues[j] = codeValuesTemp;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  69 */     int[] codes = new int[lengths.length];
/*  70 */     int lastLength = 0;
/*  71 */     int code = 0;
/*  72 */     for (int i = 0; i < lengths.length; i++) {
/*  73 */       while (lastLength != lengths[i]) {
/*  74 */         lastLength++;
/*  75 */         code <<= 1;
/*     */       }
/*  77 */       if (lastLength != 0) {
/*  78 */         codes[i] = code;
/*  79 */         code++;
/*     */       }
/*     */     }
/*     */     
/*  83 */     int last = 0;
/*  84 */     for (int i = 0; i < lengths.length; i++) {
/*  85 */       if (last != lengths[i]) {
/*  86 */         last = lengths[i];
/*  87 */         this.codeLengthInfo[(last - 1)].baseIndex = i;
/*  88 */         this.codeLengthInfo[(last - 1)].min = codes[i];
/*     */       }
/*  90 */       if (last != 0) this.codeLengthInfo[(last - 1)].max = codes[i];
/*     */     }
/*     */   }
/*     */   
/*     */   int getNextValue(PngDecodingDataStream stream) throws IOException {
/*  95 */     int code = stream.getNextIdatBit();
/*  96 */     int codelength = 0;
/*     */     
/*     */ 
/*     */ 
/* 100 */     while ((codelength < 15) && (code > this.codeLengthInfo[codelength].max)) {
/* 101 */       code = code << 1 | stream.getNextIdatBit();
/* 102 */       codelength++;
/*     */     }
/* 104 */     if (codelength >= 15) { stream.error();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 110 */     int offset = code - this.codeLengthInfo[codelength].min;
/*     */     
/*     */ 
/*     */ 
/* 114 */     int index = this.codeLengthInfo[codelength].baseIndex + offset;
/* 115 */     return this.codeValues[index];
/*     */   }
/*     */   
/*     */   static class CodeLengthInfo
/*     */   {
/*     */     int length;
/*     */     int max;
/*     */     int min;
/*     */     int baseIndex;
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/internal/image/PngHuffmanTable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */