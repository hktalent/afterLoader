/*     */ package org.eclipse.swt.internal.image;
/*     */ 
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PngHuffmanTables
/*     */ {
/*     */   PngHuffmanTable literalTable;
/*     */   PngHuffmanTable distanceTable;
/*     */   static PngHuffmanTable FixedLiteralTable;
/*     */   static PngHuffmanTable FixedDistanceTable;
/*     */   static final int LiteralTableSize = 288;
/*  23 */   static final int[] FixedLiteralLengths = { 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 8, 8, 8, 8, 8, 8, 8, 8 };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static final int DistanceTableSize = 32;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  39 */   static final int[] FixedDistanceLengths = { 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5 };
/*     */   
/*     */ 
/*     */   static final int LengthCodeTableSize = 19;
/*     */   
/*     */ 
/*  45 */   static final int[] LengthCodeOrder = { 16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15 };
/*     */   
/*     */ 
/*     */   static PngHuffmanTables getDynamicTables(PngDecodingDataStream stream)
/*     */     throws IOException
/*     */   {
/*  51 */     return new PngHuffmanTables(stream);
/*     */   }
/*     */   
/*  54 */   static PngHuffmanTables getFixedTables() { return new PngHuffmanTables(); }
/*     */   
/*     */   private PngHuffmanTable getFixedLiteralTable()
/*     */   {
/*  58 */     if (FixedLiteralTable == null) {
/*  59 */       FixedLiteralTable = new PngHuffmanTable(FixedLiteralLengths);
/*     */     }
/*  61 */     return FixedLiteralTable;
/*     */   }
/*     */   
/*     */   private PngHuffmanTable getFixedDistanceTable() {
/*  65 */     if (FixedDistanceTable == null) {
/*  66 */       FixedDistanceTable = new PngHuffmanTable(FixedDistanceLengths);
/*     */     }
/*  68 */     return FixedDistanceTable;
/*     */   }
/*     */   
/*     */   private PngHuffmanTables() {
/*  72 */     this.literalTable = getFixedLiteralTable();
/*  73 */     this.distanceTable = getFixedDistanceTable();
/*     */   }
/*     */   
/*     */   private PngHuffmanTables(PngDecodingDataStream stream) throws IOException
/*     */   {
/*  78 */     int literals = 257 + stream.getNextIdatBits(5);
/*     */     
/*  80 */     int distances = 1 + stream.getNextIdatBits(5);
/*     */     
/*  82 */     int codeLengthCodes = 4 + stream.getNextIdatBits(4);
/*     */     
/*  84 */     if (codeLengthCodes > 19) {
/*  85 */       stream.error();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  96 */     int[] lengthCodes = new int[19];
/*  97 */     for (int i = 0; i < codeLengthCodes; i++) {
/*  98 */       lengthCodes[LengthCodeOrder[i]] = stream.getNextIdatBits(3);
/*     */     }
/* 100 */     PngHuffmanTable codeLengthsTable = new PngHuffmanTable(lengthCodes);
/*     */     
/* 102 */     int[] literalLengths = readLengths(stream, literals, codeLengthsTable, 288);
/*     */     
/* 104 */     int[] distanceLengths = readLengths(stream, distances, codeLengthsTable, 32);
/*     */     
/*     */ 
/* 107 */     this.literalTable = new PngHuffmanTable(literalLengths);
/* 108 */     this.distanceTable = new PngHuffmanTable(distanceLengths);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private int[] readLengths(PngDecodingDataStream stream, int numLengths, PngHuffmanTable lengthsTable, int tableSize)
/*     */     throws IOException
/*     */   {
/* 116 */     int[] lengths = new int[tableSize];
/*     */     
/* 118 */     for (int index = 0; index < numLengths;) {
/* 119 */       int value = lengthsTable.getNextValue(stream);
/* 120 */       if (value < 16)
/*     */       {
/* 122 */         lengths[index] = value;
/* 123 */         index++;
/* 124 */       } else if (value == 16)
/*     */       {
/* 126 */         int count = stream.getNextIdatBits(2) + 3;
/* 127 */         for (int i = 0; i < count; i++) {
/* 128 */           lengths[index] = lengths[(index - 1)];
/* 129 */           index++;
/*     */         }
/* 131 */       } else if (value == 17)
/*     */       {
/* 133 */         int count = stream.getNextIdatBits(3) + 3;
/* 134 */         for (int i = 0; i < count; i++) {
/* 135 */           lengths[index] = 0;
/* 136 */           index++;
/*     */         }
/* 138 */       } else if (value == 18)
/*     */       {
/* 140 */         int count = stream.getNextIdatBits(7) + 11;
/* 141 */         for (int i = 0; i < count; i++) {
/* 142 */           lengths[index] = 0;
/* 143 */           index++;
/*     */         }
/*     */       } else {
/* 146 */         stream.error();
/*     */       }
/*     */     }
/* 149 */     return lengths;
/*     */   }
/*     */   
/*     */   int getNextLiteralValue(PngDecodingDataStream stream) throws IOException {
/* 153 */     return this.literalTable.getNextValue(stream);
/*     */   }
/*     */   
/*     */   int getNextDistanceValue(PngDecodingDataStream stream) throws IOException {
/* 157 */     return this.distanceTable.getNextValue(stream);
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/internal/image/PngHuffmanTables.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */