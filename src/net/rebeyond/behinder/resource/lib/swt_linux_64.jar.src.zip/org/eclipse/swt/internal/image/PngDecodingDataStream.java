/*     */ package org.eclipse.swt.internal.image;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import org.eclipse.swt.SWT;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PngDecodingDataStream
/*     */   extends InputStream
/*     */ {
/*     */   InputStream stream;
/*     */   byte currentByte;
/*     */   int nextBitIndex;
/*     */   PngLzBlockReader lzBlockReader;
/*     */   int adlerValue;
/*     */   static final int PRIME = 65521;
/*     */   static final int MAX_BIT = 7;
/*     */   
/*     */   PngDecodingDataStream(InputStream stream)
/*     */     throws IOException
/*     */   {
/*  31 */     this.stream = stream;
/*  32 */     this.nextBitIndex = 8;
/*  33 */     this.adlerValue = 1;
/*  34 */     this.lzBlockReader = new PngLzBlockReader(this);
/*  35 */     readCompressedDataHeader();
/*  36 */     this.lzBlockReader.readNextBlockHeader();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void assertImageDataAtEnd()
/*     */     throws IOException
/*     */   {
/*  47 */     this.lzBlockReader.assertCompressedDataAtEnd();
/*     */   }
/*     */   
/*     */   public void close() throws IOException
/*     */   {
/*  52 */     assertImageDataAtEnd();
/*  53 */     checkAdler();
/*     */   }
/*     */   
/*     */   int getNextIdatBits(int length) throws IOException {
/*  57 */     int value = 0;
/*  58 */     for (int i = 0; i < length; i++) {
/*  59 */       value |= getNextIdatBit() << i;
/*     */     }
/*  61 */     return value;
/*     */   }
/*     */   
/*     */   int getNextIdatBit() throws IOException {
/*  65 */     if (this.nextBitIndex > 7) {
/*  66 */       this.currentByte = getNextIdatByte();
/*  67 */       this.nextBitIndex = 0;
/*     */     }
/*  69 */     return (this.currentByte & 1 << this.nextBitIndex) >> this.nextBitIndex++;
/*     */   }
/*     */   
/*     */   byte getNextIdatByte() throws IOException {
/*  73 */     byte nextByte = (byte)this.stream.read();
/*  74 */     this.nextBitIndex = 8;
/*  75 */     return nextByte;
/*     */   }
/*     */   
/*     */   void updateAdler(byte value) {
/*  79 */     int low = this.adlerValue & 0xFFFF;
/*  80 */     int high = this.adlerValue >> 16 & 0xFFFF;
/*  81 */     int valueInt = value & 0xFF;
/*  82 */     low = (low + valueInt) % 65521;
/*  83 */     high = (low + high) % 65521;
/*  84 */     this.adlerValue = (high << 16 | low);
/*     */   }
/*     */   
/*     */   public int read() throws IOException
/*     */   {
/*  89 */     byte nextDecodedByte = this.lzBlockReader.getNextByte();
/*  90 */     updateAdler(nextDecodedByte);
/*  91 */     return nextDecodedByte & 0xFF;
/*     */   }
/*     */   
/*     */   public int read(byte[] buffer, int off, int len) throws IOException
/*     */   {
/*  96 */     for (int i = 0; i < len; i++) {
/*  97 */       int b = read();
/*  98 */       if (b == -1) return i;
/*  99 */       buffer[(off + i)] = ((byte)b);
/*     */     }
/* 101 */     return len;
/*     */   }
/*     */   
/*     */   void error() {
/* 105 */     SWT.error(40);
/*     */   }
/*     */   
/*     */   private void readCompressedDataHeader() throws IOException {
/* 109 */     byte headerByte1 = getNextIdatByte();
/* 110 */     byte headerByte2 = getNextIdatByte();
/*     */     
/* 112 */     int number = (headerByte1 & 0xFF) << 8 | headerByte2 & 0xFF;
/* 113 */     if (number % 31 != 0) { error();
/*     */     }
/* 115 */     int compressionMethod = headerByte1 & 0xF;
/* 116 */     if (compressionMethod != 8) { error();
/*     */     }
/* 118 */     int windowSizeHint = (headerByte1 & 0xF0) >> 4;
/* 119 */     if (windowSizeHint > 7) error();
/* 120 */     int windowSize = 1 << windowSizeHint + 8;
/* 121 */     this.lzBlockReader.setWindowSize(windowSize);
/*     */     
/* 123 */     int dictionary = headerByte2 & 0x20;
/* 124 */     if (dictionary != 0) { error();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   void checkAdler()
/*     */     throws IOException
/*     */   {
/* 133 */     int storedAdler = (getNextIdatByte() & 0xFF) << 24 | (getNextIdatByte() & 0xFF) << 16 | (getNextIdatByte() & 0xFF) << 8 | getNextIdatByte() & 0xFF;
/* 134 */     if (storedAdler != this.adlerValue) error();
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/internal/image/PngDecodingDataStream.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */