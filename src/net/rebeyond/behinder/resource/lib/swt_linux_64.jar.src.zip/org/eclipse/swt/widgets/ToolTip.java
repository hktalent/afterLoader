/*     */ package org.eclipse.swt.widgets;
/*     */ 
/*     */ import org.eclipse.swt.events.SelectionListener;
/*     */ import org.eclipse.swt.graphics.Color;
/*     */ import org.eclipse.swt.graphics.Point;
/*     */ import org.eclipse.swt.graphics.Region;
/*     */ import org.eclipse.swt.internal.Converter;
/*     */ import org.eclipse.swt.internal.DPIUtil;
/*     */ import org.eclipse.swt.internal.cairo.Cairo;
/*     */ import org.eclipse.swt.internal.gtk.GDK;
/*     */ import org.eclipse.swt.internal.gtk.GTK;
/*     */ import org.eclipse.swt.internal.gtk.GdkRGBA;
/*     */ import org.eclipse.swt.internal.gtk.GdkRectangle;
/*     */ import org.eclipse.swt.internal.gtk.GtkAllocation;
/*     */ import org.eclipse.swt.internal.gtk.OS;
/*     */ import org.eclipse.swt.internal.gtk.PangoAttribute;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ToolTip
/*     */   extends Widget
/*     */ {
/*     */   static final int DELAY = 8000;
/*     */   static final int IMAGE_SIZE = 16;
/*     */   static final int TIP_HEIGHT = 20;
/*     */   static final int INSET = 4;
/*     */   static final int PADDING = 5;
/*     */   static final int BORDER = 5;
/*     */   boolean autohide;
/*     */   boolean spikeAbove;
/*     */   int[] borderPolygon;
/*     */   long provider;
/*  50 */   long layoutMessage = 0L; long layoutText = 0L;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   int timerId;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   int y;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   int x;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   TrayItem item;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   String message;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   String text;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   Shell parent;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ToolTip(Shell parent, int style)
/*     */   {
/*  94 */     super(parent, checkStyle(style));
/*  95 */     this.parent = parent;
/*  96 */     createWidget(0);
/*  97 */     parent.addToolTip(this);
/*     */   }
/*     */   
/*     */   static int checkStyle(int style) {
/* 101 */     int mask = 11;
/* 102 */     if ((style & mask) == 0) return style;
/* 103 */     return checkBits(style, 2, 8, 1, 0, 0, 0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addSelectionListener(SelectionListener listener)
/*     */   {
/* 131 */     checkWidget();
/* 132 */     if (listener == null) error(4);
/* 133 */     TypedListener typedListener = new TypedListener(listener);
/* 134 */     addListener(13, typedListener);
/* 135 */     addListener(14, typedListener);
/*     */   }
/*     */   
/*     */   void configure() {
/* 139 */     long screen = GDK.gdk_screen_get_default();
/* 140 */     GTK.gtk_widget_realize(this.handle);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 146 */     Point point = getLocation();
/* 147 */     boolean multipleMonitors = GDK.gdk_screen_get_n_monitors(screen) > 1;
/* 148 */     int monitorNumber = GDK.gdk_screen_get_monitor_at_point(screen, point.x, point.y);
/* 149 */     GdkRectangle dest = new GdkRectangle();
/* 150 */     GDK.gdk_screen_get_monitor_geometry(screen, monitorNumber, dest);
/* 151 */     point = getSize(dest.width / 4);
/* 152 */     int w = point.x;
/* 153 */     int h = point.y;
/* 154 */     point = getLocation();
/* 155 */     int x = point.x;
/* 156 */     int y = point.y;
/* 157 */     GTK.gtk_window_resize(this.handle, w, h + 20);
/*     */     
/* 159 */     this.spikeAbove = (dest.height >= y + h + 20);
/* 160 */     int[] polyline; if ((dest.width >= x + w) || ((multipleMonitors) && (GDK.gdk_screen_width() >= x + w))) {
/* 161 */       if (dest.height >= y + h + 20) {
/* 162 */         int t = 20;
/* 163 */         int[] polyline = { 0, 5 + t, 1, 5 + t, 1, 3 + t, 3, 1 + t, 5, 1 + t, 5, t, 16, t, 16, 0, 35, t, w - 5, t, w - 5, 1 + t, w - 3, 1 + t, w - 1, 3 + t, w - 1, 5 + t, w, 5 + t, w, h - 5 + t, w - 1, h - 5 + t, w - 1, h - 3 + t, w - 2, h - 3 + t, w - 2, h - 2 + t, w - 3, h - 2 + t, w - 3, h - 1 + t, w - 5, h - 1 + t, w - 5, h + t, 5, h + t, 5, h - 1 + t, 3, h - 1 + t, 3, h - 2 + t, 2, h - 2 + t, 2, h - 3 + t, 1, h - 3 + t, 1, h - 5 + t, 0, h - 5 + t, 0, 5 + t };
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 170 */         this.borderPolygon = new int[] { 0, 5 + t, 1, 4 + t, 1, 3 + t, 3, 1 + t, 4, 1 + t, 5, t, 16, t, 16, 1, 35, t, w - 6, 0 + t, w - 5, 1 + t, w - 4, 1 + t, w - 2, 3 + t, w - 2, 4 + t, w - 1, 5 + t, w - 1, h - 6 + t, w - 2, h - 5 + t, w - 2, h - 4 + t, w - 4, h - 2 + t, w - 5, h - 2 + t, w - 6, h - 1 + t, 5, h - 1 + t, 4, h - 2 + t, 3, h - 2 + t, 1, h - 4 + t, 1, h - 5 + t, 0, h - 6 + t, 0, 5 + t };
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 177 */         if ((this.parent.style & 0x8000000) != 0) {
/* 178 */           x -= w - 36;
/* 179 */           polyline[12] = (w - 36);
/* 180 */           polyline[14] = (w - 16);
/* 181 */           polyline[16] = (w - 15);
/* 182 */           this.borderPolygon[12] = (w - 35);
/* 183 */           this.borderPolygon[14] = (this.borderPolygon[16] = w - 16);
/*     */         }
/* 185 */         GTK.gtk_window_move(this.handle, Math.max(0, x - 17), y);
/*     */       } else {
/* 187 */         int[] polyline = { 0, 5, 1, 5, 1, 3, 3, 1, 5, 1, 5, 0, w - 5, 0, w - 5, 1, w - 3, 1, w - 1, 3, w - 1, 5, w, 5, w, h - 5, w - 1, h - 5, w - 1, h - 3, w - 2, h - 3, w - 2, h - 2, w - 3, h - 2, w - 3, h - 1, w - 5, h - 1, w - 5, h, 35, h, 16, h + 20, 16, h, 5, h, 5, h - 1, 3, h - 1, 3, h - 2, 2, h - 2, 2, h - 3, 1, h - 3, 1, h - 5, 0, h - 5, 0, 5 };
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 194 */         this.borderPolygon = new int[] { 0, 5, 1, 4, 1, 3, 3, 1, 4, 1, 5, 0, w - 6, 0, w - 5, 1, w - 4, 1, w - 2, 3, w - 2, 4, w - 1, 5, w - 1, h - 6, w - 2, h - 5, w - 2, h - 4, w - 4, h - 2, w - 5, h - 2, w - 6, h - 1, 35, h - 1, 17, h + 20 - 2, 17, h - 1, 5, h - 1, 4, h - 2, 3, h - 2, 1, h - 4, 1, h - 5, 0, h - 6, 0, 5 };
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 201 */         if ((this.parent.style & 0x8000000) != 0) {
/* 202 */           x -= w - 36;
/* 203 */           polyline[42] = (polyline[44] = w - 16);
/* 204 */           polyline[46] = (w - 35);
/* 205 */           this.borderPolygon[36] = (this.borderPolygon[38] = w - 17);
/* 206 */           this.borderPolygon[40] = (w - 35);
/*     */         }
/* 208 */         GTK.gtk_window_move(this.handle, Math.max(0, x - 17), y - h - 20);
/*     */       }
/*     */     }
/* 211 */     else if (dest.height >= y + h + 20) {
/* 212 */       int t = 20;
/* 213 */       int[] polyline = { 0, 5 + t, 1, 5 + t, 1, 3 + t, 3, 1 + t, 5, 1 + t, 5, t, w - 35, t, w - 16, 0, w - 16, t, w - 5, t, w - 5, 1 + t, w - 3, 1 + t, w - 1, 3 + t, w - 1, 5 + t, w, 5 + t, w, h - 5 + t, w - 1, h - 5 + t, w - 1, h - 3 + t, w - 2, h - 3 + t, w - 2, h - 2 + t, w - 3, h - 2 + t, w - 3, h - 1 + t, w - 5, h - 1 + t, w - 5, h + t, 5, h + t, 5, h - 1 + t, 3, h - 1 + t, 3, h - 2 + t, 2, h - 2 + t, 2, h - 3 + t, 1, h - 3 + t, 1, h - 5 + t, 0, h - 5 + t, 0, 5 + t };
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 220 */       this.borderPolygon = new int[] { 0, 5 + t, 1, 4 + t, 1, 3 + t, 3, 1 + t, 4, 1 + t, 5, t, w - 35, t, w - 17, 2, w - 17, t, w - 6, t, w - 5, 1 + t, w - 4, 1 + t, w - 2, 3 + t, w - 2, 4 + t, w - 1, 5 + t, w - 1, h - 6 + t, w - 2, h - 5 + t, w - 2, h - 4 + t, w - 4, h - 2 + t, w - 5, h - 2 + t, w - 6, h - 1 + t, 5, h - 1 + t, 4, h - 2 + t, 3, h - 2 + t, 1, h - 4 + t, 1, h - 5 + t, 0, h - 6 + t, 0, 5 + t };
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 227 */       if ((this.parent.style & 0x8000000) != 0) {
/* 228 */         x += w - 35;
/* 229 */         polyline[12] = (polyline[14] = 16);
/* 230 */         polyline[16] = 35;
/* 231 */         this.borderPolygon[12] = (this.borderPolygon[14] = 16);
/* 232 */         this.borderPolygon[16] = 35;
/*     */       }
/* 234 */       GTK.gtk_window_move(this.handle, Math.max(dest.width - w, x - w + 17), y);
/*     */     } else {
/* 236 */       polyline = new int[] { 0, 5, 1, 5, 1, 3, 3, 1, 5, 1, 5, 0, w - 5, 0, w - 5, 1, w - 3, 1, w - 1, 3, w - 1, 5, w, 5, w, h - 5, w - 1, h - 5, w - 1, h - 3, w - 2, h - 3, w - 2, h - 2, w - 3, h - 2, w - 3, h - 1, w - 5, h - 1, w - 5, h, w - 16, h, w - 16, h + 20, w - 35, h, 5, h, 5, h - 1, 3, h - 1, 3, h - 2, 2, h - 2, 2, h - 3, 1, h - 3, 1, h - 5, 0, h - 5, 0, 5 };
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 243 */       this.borderPolygon = new int[] { 0, 5, 1, 4, 1, 3, 3, 1, 4, 1, 5, 0, w - 6, 0, w - 5, 1, w - 4, 1, w - 2, 3, w - 2, 4, w - 1, 5, w - 1, h - 6, w - 2, h - 5, w - 2, h - 4, w - 4, h - 2, w - 5, h - 2, w - 6, h - 1, w - 17, h - 1, w - 17, h + 20 - 2, w - 36, h - 1, 5, h - 1, 4, h - 2, 3, h - 2, 1, h - 4, 1, h - 5, 0, h - 6, 0, 5 };
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 250 */       if ((this.parent.style & 0x8000000) != 0) {
/* 251 */         x += w - 35;
/* 252 */         polyline[42] = 35;
/* 253 */         polyline[44] = (polyline[46] = 16);
/* 254 */         this.borderPolygon[36] = 35;
/* 255 */         this.borderPolygon[38] = (this.borderPolygon[40] = 17);
/*     */       }
/* 257 */       GTK.gtk_window_move(this.handle, Math.max(dest.width - w, x - w + 17), y - h - 20);
/*     */     }
/*     */     
/* 260 */     GTK.gtk_widget_realize(this.handle);
/* 261 */     Region region = new Region(this.display);
/* 262 */     region.add(DPIUtil.autoScaleDown(polyline));
/* 263 */     if (GTK.GTK3) {
/* 264 */       GTK.gtk_widget_shape_combine_region(this.handle, region.handle);
/*     */     } else {
/* 266 */       long window = gtk_widget_get_window(this.handle);
/* 267 */       GDK.gdk_window_shape_combine_region(window, region.handle, 0, 0);
/*     */     }
/* 269 */     region.dispose();
/*     */   }
/*     */   
/*     */   void createHandle(int index)
/*     */   {
/* 274 */     if ((this.style & 0x1000) != 0) {
/* 275 */       this.state |= 0x8;
/* 276 */       this.handle = GTK.gtk_window_new(1);
/* 277 */       Color background = this.display.getSystemColor(29);
/* 278 */       if (GTK.GTK3) {
/* 279 */         long context = GTK.gtk_widget_get_style_context(this.handle);
/* 280 */         GdkRGBA bgRGBA = background.handleRGBA;
/* 281 */         String name = GTK.GTK_VERSION >= OS.VERSION(3, 20, 0) ? "window" : "GtkWindow";
/* 282 */         String css = name + " {background-color: " + this.display.gtk_rgba_to_css_string(bgRGBA) + ";}";
/* 283 */         gtk_css_provider_load_from_css(context, css);
/* 284 */         GTK.gtk_style_context_invalidate(context);
/*     */       } else {
/* 286 */         GTK.gtk_widget_modify_bg(this.handle, 0, background.handle);
/*     */       }
/* 288 */       GTK.gtk_window_set_type_hint(this.handle, 10);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   void gtk_css_provider_load_from_css(long context, String css)
/*     */   {
/* 295 */     if (this.provider == 0L) {
/* 296 */       this.provider = GTK.gtk_css_provider_new();
/* 297 */       GTK.gtk_style_context_add_provider(context, this.provider, 600);
/* 298 */       OS.g_object_unref(this.provider);
/*     */     }
/* 300 */     GTK.gtk_css_provider_load_from_data(this.provider, Converter.wcsToMbcs(css, true), -1L, null);
/*     */   }
/*     */   
/*     */   void createWidget(int index)
/*     */   {
/* 305 */     super.createWidget(index);
/* 306 */     this.text = "";
/* 307 */     this.message = "";
/* 308 */     this.x = (this.y = -1);
/* 309 */     this.autohide = true;
/*     */   }
/*     */   
/*     */   void destroyWidget()
/*     */   {
/* 314 */     long topHandle = topHandle();
/* 315 */     if (this.parent != null) this.parent.removeTooTip(this);
/* 316 */     releaseHandle();
/* 317 */     if ((topHandle != 0L) && ((this.state & 0x8) != 0)) {
/* 318 */       if ((this.style & 0x1000) != 0) {
/* 319 */         GTK.gtk_widget_destroy(topHandle);
/*     */       } else {
/* 321 */         OS.g_object_unref(topHandle);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getAutoHide()
/*     */   {
/* 339 */     checkWidget();
/* 340 */     return this.autohide;
/*     */   }
/*     */   
/*     */   Point getLocation() {
/* 344 */     int x = this.x;
/* 345 */     int y = this.y;
/* 346 */     if (this.item != null) {
/* 347 */       long itemHandle = this.item.handle;
/* 348 */       GdkRectangle area = new GdkRectangle();
/* 349 */       GTK.gtk_status_icon_get_geometry(itemHandle, 0L, area, 0L);
/* 350 */       x = area.x + area.width / 2;
/* 351 */       y = area.y + area.height / 2;
/*     */     }
/* 353 */     if ((x == -1) || (y == -1)) {
/* 354 */       int[] px = new int[1];int[] py = new int[1];
/* 355 */       gdk_window_get_device_position(0L, px, py, null);
/* 356 */       x = px[0];
/* 357 */       y = py[0];
/*     */     }
/* 359 */     return new Point(x, y);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getMessage()
/*     */   {
/* 374 */     checkWidget();
/* 375 */     return this.message;
/*     */   }
/*     */   
/*     */   String getNameText()
/*     */   {
/* 380 */     return getText();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Shell getParent()
/*     */   {
/* 394 */     checkWidget();
/* 395 */     return this.parent;
/*     */   }
/*     */   
/*     */   Point getSize(int maxWidth) {
/* 399 */     int textWidth = 0;int messageWidth = 0;
/* 400 */     int[] w = new int[1];int[] h = new int[1];
/* 401 */     if (this.layoutText != 0L) {
/* 402 */       OS.pango_layout_set_width(this.layoutText, -1);
/* 403 */       OS.pango_layout_get_pixel_size(this.layoutText, w, h);
/* 404 */       textWidth = w[0];
/*     */     }
/* 406 */     if (this.layoutMessage != 0L) {
/* 407 */       OS.pango_layout_set_width(this.layoutMessage, -1);
/* 408 */       OS.pango_layout_get_pixel_size(this.layoutMessage, w, h);
/* 409 */       messageWidth = w[0];
/*     */     }
/* 411 */     int messageTrim = 28;
/* 412 */     boolean hasImage = (this.layoutText != 0L) && ((this.style & 0xB) != 0);
/* 413 */     int textTrim = messageTrim + (hasImage ? 16 : 0);
/* 414 */     int width = Math.min(maxWidth, Math.max(textWidth + textTrim, messageWidth + messageTrim));
/* 415 */     int textHeight = 0;int messageHeight = 0;
/* 416 */     if (this.layoutText != 0L) {
/* 417 */       OS.pango_layout_set_width(this.layoutText, (maxWidth - textTrim) * 1024);
/* 418 */       OS.pango_layout_get_pixel_size(this.layoutText, w, h);
/* 419 */       textHeight = h[0];
/*     */     }
/* 421 */     if (this.layoutMessage != 0L) {
/* 422 */       OS.pango_layout_set_width(this.layoutMessage, (maxWidth - messageTrim) * 1024);
/* 423 */       OS.pango_layout_get_pixel_size(this.layoutMessage, w, h);
/* 424 */       messageHeight = h[0];
/*     */     }
/* 426 */     int height = 20 + messageHeight;
/* 427 */     if (this.layoutText != 0L) height += Math.max(16, textHeight) + 10;
/* 428 */     return new Point(width, height);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getText()
/*     */   {
/* 443 */     checkWidget();
/* 444 */     return this.text;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getVisible()
/*     */   {
/* 465 */     checkWidget();
/* 466 */     if ((this.style & 0x1000) != 0) return GTK.gtk_widget_get_visible(this.handle);
/* 467 */     return false;
/*     */   }
/*     */   
/*     */   long gtk_button_press_event(long widget, long event)
/*     */   {
/* 472 */     sendSelectionEvent(13, null, true);
/* 473 */     setVisible(false);
/* 474 */     return 0L;
/*     */   }
/*     */   
/*     */   void drawTooltip(long cr) {
/* 478 */     long window = gtk_widget_get_window(this.handle);
/* 479 */     int x = 10;
/* 480 */     int y = 10;
/* 481 */     long cairo = cr != 0L ? cr : GDK.gdk_cairo_create(window);
/* 482 */     if (cairo == 0L) error(2);
/* 483 */     int count = this.borderPolygon.length / 2;
/* 484 */     if (count != 0) {
/* 485 */       Cairo.cairo_set_line_width(cairo, 1.0D);
/* 486 */       Cairo.cairo_move_to(cairo, this.borderPolygon[0], this.borderPolygon[1]);
/* 487 */       int i = 1; for (int j = 2; i < count; j += 2) {
/* 488 */         Cairo.cairo_line_to(cairo, this.borderPolygon[j] + 0.5D, this.borderPolygon[(j + 1)] + 0.5D);i++;
/*     */       }
/* 490 */       Cairo.cairo_close_path(cairo);
/* 491 */       Cairo.cairo_stroke(cairo);
/*     */     }
/* 493 */     if (this.spikeAbove) y += 20;
/* 494 */     if (this.layoutText != 0L) {
/* 495 */       byte[] buffer = null;
/* 496 */       int id = this.style & 0xB;
/* 497 */       switch (id) {
/* 498 */       case 1:  buffer = Converter.wcsToMbcs("dialog-error", true); break;
/* 499 */       case 2:  buffer = Converter.wcsToMbcs("dialog-information", true); break;
/* 500 */       case 8:  buffer = Converter.wcsToMbcs("dialog-warning", true);
/*     */       }
/* 502 */       if (buffer != null) {
/* 503 */         long pixbuf = GTK.gtk_icon_theme_load_icon(GTK.gtk_icon_theme_get_default(), buffer, 1, 0, 0L);
/* 504 */         GDK.gdk_cairo_set_source_pixbuf(cairo, pixbuf, x, y);
/* 505 */         Cairo.cairo_paint(cairo);
/* 506 */         OS.g_object_unref(pixbuf);
/* 507 */         x += 16;
/*     */       }
/* 509 */       x += 4;
/* 510 */       int[] w = new int[1];int[] h = new int[1];
/* 511 */       Color foreground = this.display.getSystemColor(28);
/* 512 */       if (GTK.GTK3) {
/* 513 */         GDK.gdk_cairo_set_source_rgba(cairo, foreground.handleRGBA);
/*     */       } else {
/* 515 */         GDK.gdk_cairo_set_source_color(cairo, foreground.handle);
/*     */       }
/* 517 */       Cairo.cairo_move_to(cairo, x, y);
/* 518 */       OS.pango_cairo_show_layout(cairo, this.layoutText);
/* 519 */       OS.pango_layout_get_pixel_size(this.layoutText, w, h);
/* 520 */       y += 10 + Math.max(16, h[0]);
/*     */     }
/* 522 */     if (this.layoutMessage != 0L) {
/* 523 */       x = 14;
/* 524 */       Color foreground = this.display.getSystemColor(28);
/* 525 */       if (GTK.GTK3) {
/* 526 */         GDK.gdk_cairo_set_source_rgba(cairo, foreground.handleRGBA);
/*     */       } else {
/* 528 */         GDK.gdk_cairo_set_source_color(cairo, foreground.handle);
/*     */       }
/* 530 */       Cairo.cairo_move_to(cairo, x, y);
/* 531 */       OS.pango_cairo_show_layout(cairo, this.layoutMessage);
/*     */     }
/* 533 */     if (cairo != cr) Cairo.cairo_destroy(cairo);
/*     */   }
/*     */   
/*     */   long gtk_draw(long widget, long cairo)
/*     */   {
/* 538 */     if ((this.state & 0x40) != 0) return 0L;
/* 539 */     drawTooltip(cairo);
/* 540 */     return 0L;
/*     */   }
/*     */   
/*     */   long gtk_expose_event(long widget, long eventPtr)
/*     */   {
/* 545 */     if ((this.state & 0x40) != 0) return 0L;
/* 546 */     drawTooltip(0L);
/* 547 */     return 0L;
/*     */   }
/*     */   
/*     */   long gtk_size_allocate(long widget, long allocation)
/*     */   {
/* 552 */     Point point = getLocation();
/* 553 */     int x = point.x;
/* 554 */     int y = point.y;
/* 555 */     long screen = GDK.gdk_screen_get_default();
/* 556 */     GTK.gtk_widget_realize(widget);
/* 557 */     int monitorNumber = GDK.gdk_screen_get_monitor_at_point(screen, point.x, point.y);
/* 558 */     GdkRectangle dest = new GdkRectangle();
/* 559 */     GDK.gdk_screen_get_monitor_geometry(screen, monitorNumber, dest);
/* 560 */     GtkAllocation widgetAllocation = new GtkAllocation();
/* 561 */     GTK.gtk_widget_get_allocation(widget, widgetAllocation);
/* 562 */     int w = widgetAllocation.width;
/* 563 */     int h = widgetAllocation.height;
/* 564 */     if (dest.height < y + h) y -= h;
/* 565 */     if (dest.width < x + w) x -= w;
/* 566 */     GTK.gtk_window_move(widget, x, y);
/* 567 */     return 0L;
/*     */   }
/*     */   
/*     */   void hookEvents()
/*     */   {
/* 572 */     if ((this.style & 0x1000) != 0) {
/* 573 */       OS.g_signal_connect_closure_by_id(this.handle, this.display.signalIds[18], 0, this.display.getClosure(18), true);
/* 574 */       if (GTK.GTK_VERSION >= OS.VERSION(3, 9, 0)) {
/* 575 */         OS.g_signal_connect_closure_by_id(this.handle, this.display.signalIds[19], 0, this.display.getClosure(19), true);
/*     */       }
/* 577 */       GTK.gtk_widget_add_events(this.handle, 256);
/* 578 */       OS.g_signal_connect_closure(this.handle, OS.button_press_event, this.display.getClosure(2), false);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isVisible()
/*     */   {
/* 597 */     checkWidget();
/* 598 */     return getVisible();
/*     */   }
/*     */   
/*     */   void releaseWidget()
/*     */   {
/* 603 */     super.releaseWidget();
/* 604 */     setVisible(false);
/* 605 */     if (this.layoutText != 0L) OS.g_object_unref(this.layoutText);
/* 606 */     this.layoutText = 0L;
/* 607 */     if (this.layoutMessage != 0L) OS.g_object_unref(this.layoutMessage);
/* 608 */     this.layoutMessage = 0L;
/* 609 */     if (this.timerId != 0) OS.g_source_remove(this.timerId);
/* 610 */     this.timerId = 0;
/* 611 */     this.text = null;
/* 612 */     this.message = null;
/* 613 */     this.borderPolygon = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeSelectionListener(SelectionListener listener)
/*     */   {
/* 634 */     checkWidget();
/* 635 */     if (listener == null) error(4);
/* 636 */     if (this.eventTable == null) return;
/* 637 */     this.eventTable.unhook(13, listener);
/* 638 */     this.eventTable.unhook(14, listener);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAutoHide(boolean autoHide)
/*     */   {
/* 656 */     checkWidget();
/* 657 */     this.autohide = autoHide;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLocation(int x, int y)
/*     */   {
/* 679 */     checkWidget();
/* 680 */     setLocation(new Point(x, y));
/*     */   }
/*     */   
/*     */   void setLocationInPixels(int x, int y) {
/* 684 */     checkWidget();
/* 685 */     this.x = x;
/* 686 */     this.y = y;
/* 687 */     if (((this.style & 0x1000) != 0) && 
/* 688 */       (GTK.gtk_widget_get_visible(this.handle))) { configure();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLocation(Point location)
/*     */   {
/* 714 */     checkWidget();
/* 715 */     setLocationInPixels(DPIUtil.autoScaleUp(location));
/*     */   }
/*     */   
/*     */   void setLocationInPixels(Point location) {
/* 719 */     checkWidget();
/* 720 */     if (location == null) error(4);
/* 721 */     setLocationInPixels(location.x, location.y);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMessage(String string)
/*     */   {
/* 738 */     checkWidget();
/* 739 */     if (string == null) error(4);
/* 740 */     this.message = string;
/* 741 */     if ((this.style & 0x1000) == 0) return;
/* 742 */     if (this.layoutMessage != 0L) OS.g_object_unref(this.layoutMessage);
/* 743 */     this.layoutMessage = 0L;
/* 744 */     if (this.message.length() != 0) {
/* 745 */       byte[] buffer = Converter.wcsToMbcs(this.message, true);
/* 746 */       this.layoutMessage = GTK.gtk_widget_create_pango_layout(this.handle, buffer);
/* 747 */       OS.pango_layout_set_auto_dir(this.layoutMessage, false);
/* 748 */       OS.pango_layout_set_wrap(this.layoutMessage, 2);
/*     */     }
/* 750 */     if (GTK.gtk_widget_get_visible(this.handle)) { configure();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setText(String string)
/*     */   {
/* 767 */     checkWidget();
/* 768 */     if (string == null) error(4);
/* 769 */     this.text = string;
/* 770 */     if ((this.style & 0x1000) == 0) return;
/* 771 */     if (this.layoutText != 0L) OS.g_object_unref(this.layoutText);
/* 772 */     this.layoutText = 0L;
/* 773 */     if (this.text.length() != 0) {
/* 774 */       byte[] buffer = Converter.wcsToMbcs(this.text, true);
/* 775 */       this.layoutText = GTK.gtk_widget_create_pango_layout(this.handle, buffer);
/* 776 */       OS.pango_layout_set_auto_dir(this.layoutText, false);
/* 777 */       long boldAttr = OS.pango_attr_weight_new(700);
/* 778 */       PangoAttribute attribute = new PangoAttribute();
/* 779 */       OS.memmove(attribute, boldAttr, PangoAttribute.sizeof);
/* 780 */       attribute.start_index = 0;
/* 781 */       attribute.end_index = buffer.length;
/* 782 */       OS.memmove(boldAttr, attribute, PangoAttribute.sizeof);
/* 783 */       long attrList = OS.pango_attr_list_new();
/* 784 */       OS.pango_attr_list_insert(attrList, boldAttr);
/* 785 */       OS.pango_layout_set_attributes(this.layoutText, attrList);
/* 786 */       OS.pango_attr_list_unref(attrList);
/* 787 */       OS.pango_layout_set_wrap(this.layoutText, 2);
/*     */     }
/* 789 */     if (GTK.gtk_widget_get_visible(this.handle)) { configure();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setVisible(boolean visible)
/*     */   {
/* 809 */     checkWidget();
/* 810 */     if (this.timerId != 0) OS.g_source_remove(this.timerId);
/* 811 */     this.timerId = 0;
/* 812 */     if (visible) {
/* 813 */       if ((this.style & 0x1000) != 0) {
/* 814 */         configure();
/* 815 */         GTK.gtk_widget_show(this.handle);
/*     */       } else {
/* 817 */         long vboxHandle = this.parent.vboxHandle;
/* 818 */         StringBuilder string = new StringBuilder(this.text);
/* 819 */         if (this.text.length() > 0) string.append("\n\n");
/* 820 */         string.append(this.message);
/* 821 */         byte[] buffer = Converter.wcsToMbcs(string.toString(), true);
/* 822 */         GTK.gtk_widget_set_tooltip_text(vboxHandle, buffer);
/*     */       }
/* 824 */       if (this.autohide) this.timerId = OS.g_timeout_add(8000, this.display.windowTimerProc, this.handle);
/*     */     }
/* 826 */     else if ((this.style & 0x1000) != 0) {
/* 827 */       GTK.gtk_widget_hide(this.handle);
/*     */     } else {
/* 829 */       long vboxHandle = this.parent.vboxHandle;
/* 830 */       byte[] buffer = Converter.wcsToMbcs("", true);
/* 831 */       GTK.gtk_widget_set_tooltip_text(vboxHandle, buffer);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   long timerProc(long widget)
/*     */   {
/* 838 */     if ((this.style & 0x1000) != 0) {
/* 839 */       GTK.gtk_widget_hide(this.handle);
/*     */     }
/* 841 */     return 0L;
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/widgets/ToolTip.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */