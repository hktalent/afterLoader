package org.eclipse.swt.internal.accessibility.gtk;

public class AtkTableIface
{
  public long ref_at;
  public long get_index_at;
  public long get_column_at_index;
  public long get_row_at_index;
  public long get_n_columns;
  public long get_n_rows;
  public long get_column_extent_at;
  public long get_row_extent_at;
  public long get_caption;
  public long get_column_description;
  public long get_column_header;
  public long get_row_description;
  public long get_row_header;
  public long get_summary;
  public long set_caption;
  public long set_column_description;
  public long set_column_header;
  public long set_row_description;
  public long set_row_header;
  public long set_summary;
  public long get_selected_columns;
  public long get_selected_rows;
  public long is_column_selected;
  public long is_row_selected;
  public long is_selected;
  public long add_row_selection;
  public long remove_row_selection;
  public long add_column_selection;
  public long remove_column_selection;
  public long row_inserted;
  public long column_inserted;
  public long row_deleted;
  public long column_deleted;
  public long row_reordered;
  public long column_reordered;
  public long model_changed;
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/internal/accessibility/gtk/AtkTableIface.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */