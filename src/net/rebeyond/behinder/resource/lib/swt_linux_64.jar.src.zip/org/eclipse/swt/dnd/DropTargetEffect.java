/*     */ package org.eclipse.swt.dnd;
/*     */ 
/*     */ import org.eclipse.swt.SWT;
/*     */ import org.eclipse.swt.graphics.Point;
/*     */ import org.eclipse.swt.graphics.Rectangle;
/*     */ import org.eclipse.swt.widgets.Control;
/*     */ import org.eclipse.swt.widgets.Table;
/*     */ import org.eclipse.swt.widgets.TableItem;
/*     */ import org.eclipse.swt.widgets.Tree;
/*     */ import org.eclipse.swt.widgets.TreeItem;
/*     */ import org.eclipse.swt.widgets.Widget;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DropTargetEffect
/*     */   extends DropTargetAdapter
/*     */ {
/*     */   Control control;
/*     */   
/*     */   public DropTargetEffect(Control control)
/*     */   {
/*  65 */     if (control == null) SWT.error(4);
/*  66 */     this.control = control;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Control getControl()
/*     */   {
/*  76 */     return this.control;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Widget getItem(int x, int y)
/*     */   {
/*  89 */     if ((this.control instanceof Table)) {
/*  90 */       return getItem((Table)this.control, x, y);
/*     */     }
/*  92 */     if ((this.control instanceof Tree)) {
/*  93 */       return getItem((Tree)this.control, x, y);
/*     */     }
/*  95 */     return null;
/*     */   }
/*     */   
/*     */   Widget getItem(Table table, int x, int y) {
/*  99 */     Point coordinates = new Point(x, y);
/* 100 */     coordinates = table.toControl(coordinates);
/* 101 */     TableItem item = table.getItem(coordinates);
/* 102 */     if (item != null) return item;
/* 103 */     Rectangle area = table.getClientArea();
/* 104 */     int tableBottom = area.y + area.height;
/* 105 */     int itemCount = table.getItemCount();
/* 106 */     for (int i = table.getTopIndex(); i < itemCount; i++) {
/* 107 */       item = table.getItem(i);
/* 108 */       Rectangle rect = item.getBounds();
/* 109 */       rect.x = area.x;
/* 110 */       rect.width = area.width;
/* 111 */       if (rect.contains(coordinates)) return item;
/* 112 */       if (rect.y > tableBottom) break;
/*     */     }
/* 114 */     return null;
/*     */   }
/*     */   
/*     */   Widget getItem(Tree tree, int x, int y) {
/* 118 */     Point point = new Point(x, y);
/* 119 */     point = tree.toControl(point);
/* 120 */     TreeItem item = tree.getItem(point);
/* 121 */     if (item == null) {
/* 122 */       Rectangle area = tree.getClientArea();
/* 123 */       if (area.contains(point)) {
/* 124 */         int treeBottom = area.y + area.height;
/* 125 */         item = tree.getTopItem();
/* 126 */         while (item != null) {
/* 127 */           Rectangle rect = item.getBounds();
/* 128 */           int itemBottom = rect.y + rect.height;
/* 129 */           if ((rect.y <= point.y) && (point.y < itemBottom)) return item;
/* 130 */           if (itemBottom > treeBottom) break;
/* 131 */           item = nextItem(tree, item);
/*     */         }
/* 133 */         return null;
/*     */       }
/*     */     }
/* 136 */     return item;
/*     */   }
/*     */   
/*     */   TreeItem nextItem(Tree tree, TreeItem item) {
/* 140 */     if (item == null) return null;
/* 141 */     if ((item.getExpanded()) && (item.getItemCount() > 0)) return item.getItem(0);
/* 142 */     TreeItem childItem = item;
/* 143 */     TreeItem parentItem = childItem.getParentItem();
/* 144 */     int index = parentItem == null ? tree.indexOf(childItem) : parentItem.indexOf(childItem);
/* 145 */     int count = parentItem == null ? tree.getItemCount() : parentItem.getItemCount();
/*     */     for (;;) {
/* 147 */       if (index + 1 < count) return parentItem == null ? tree.getItem(index + 1) : parentItem.getItem(index + 1);
/* 148 */       if (parentItem == null) return null;
/* 149 */       childItem = parentItem;
/* 150 */       parentItem = childItem.getParentItem();
/* 151 */       index = parentItem == null ? tree.indexOf(childItem) : parentItem.indexOf(childItem);
/* 152 */       count = parentItem == null ? tree.getItemCount() : parentItem.getItemCount();
/*     */     }
/*     */   }
/*     */   
/*     */   TreeItem previousItem(Tree tree, TreeItem item) {
/* 157 */     if (item == null) return null;
/* 158 */     TreeItem childItem = item;
/* 159 */     TreeItem parentItem = childItem.getParentItem();
/* 160 */     int index = parentItem == null ? tree.indexOf(childItem) : parentItem.indexOf(childItem);
/* 161 */     if (index == 0) return parentItem;
/* 162 */     TreeItem nextItem = parentItem == null ? tree.getItem(index - 1) : parentItem.getItem(index - 1);
/* 163 */     int count = nextItem.getItemCount();
/* 164 */     while ((count > 0) && (nextItem.getExpanded())) {
/* 165 */       nextItem = nextItem.getItem(count - 1);
/* 166 */       count = nextItem.getItemCount();
/*     */     }
/* 168 */     return nextItem;
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/dnd/DropTargetEffect.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */