/*      */ package org.eclipse.swt.widgets;
/*      */ 
/*      */ import org.eclipse.swt.events.ArmListener;
/*      */ import org.eclipse.swt.events.HelpListener;
/*      */ import org.eclipse.swt.events.SelectionListener;
/*      */ import org.eclipse.swt.graphics.Image;
/*      */ import org.eclipse.swt.graphics.Rectangle;
/*      */ import org.eclipse.swt.internal.C;
/*      */ import org.eclipse.swt.internal.Converter;
/*      */ import org.eclipse.swt.internal.ImageList;
/*      */ import org.eclipse.swt.internal.gtk.GDK;
/*      */ import org.eclipse.swt.internal.gtk.GTK;
/*      */ import org.eclipse.swt.internal.gtk.GtkAllocation;
/*      */ import org.eclipse.swt.internal.gtk.OS;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class MenuItem
/*      */   extends Item
/*      */ {
/*      */   Menu parent;
/*      */   Menu menu;
/*      */   long groupHandle;
/*      */   long labelHandle;
/*      */   long imageHandle;
/*      */   long boxHandle;
/*      */   int accelerator;
/*      */   int userId;
/*      */   String toolTipText;
/*      */   
/*      */   public MenuItem(Menu parent, int style)
/*      */   {
/*   94 */     super(parent, checkStyle(style));
/*   95 */     this.parent = parent;
/*   96 */     createWidget(parent.getItemCount());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public MenuItem(Menu parent, int style, int index)
/*      */   {
/*  136 */     super(parent, checkStyle(style));
/*  137 */     this.parent = parent;
/*  138 */     int count = parent.getItemCount();
/*  139 */     if ((0 > index) || (index > count)) {
/*  140 */       error(6);
/*      */     }
/*  142 */     createWidget(index);
/*      */   }
/*      */   
/*      */   void addAccelerator(long accelGroup) {
/*  146 */     updateAccelerator(accelGroup, true);
/*      */   }
/*      */   
/*      */   void addAccelerators(long accelGroup) {
/*  150 */     addAccelerator(accelGroup);
/*  151 */     if (this.menu != null) { this.menu.addAccelerators(accelGroup);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addArmListener(ArmListener listener)
/*      */   {
/*  174 */     checkWidget();
/*  175 */     if (listener == null) error(4);
/*  176 */     TypedListener typedListener = new TypedListener(listener);
/*  177 */     addListener(30, typedListener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addHelpListener(HelpListener listener)
/*      */   {
/*  200 */     checkWidget();
/*  201 */     if (listener == null) error(4);
/*  202 */     TypedListener typedListener = new TypedListener(listener);
/*  203 */     addListener(28, typedListener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addSelectionListener(SelectionListener listener)
/*      */   {
/*  237 */     checkWidget();
/*  238 */     if (listener == null) error(4);
/*  239 */     TypedListener typedListener = new TypedListener(listener);
/*  240 */     addListener(13, typedListener);
/*  241 */     addListener(14, typedListener);
/*      */   }
/*      */   
/*      */   static int checkStyle(int style) {
/*  245 */     return checkBits(style, 8, 32, 16, 2, 64, 0);
/*      */   }
/*      */   
/*      */   protected void checkSubclass()
/*      */   {
/*  250 */     if (!isValidSubclass()) error(43);
/*      */   }
/*      */   
/*      */   void createHandle(int index)
/*      */   {
/*  255 */     this.state |= 0x8;
/*  256 */     byte[] buffer = new byte[1];
/*  257 */     int bits = 122;
/*  258 */     switch (this.style & bits) {
/*      */     case 2: 
/*  260 */       this.handle = GTK.gtk_separator_menu_item_new();
/*  261 */       if (this.handle != 0L) break label658; error(2); break;
/*      */     
/*      */     case 16: 
/*  264 */       if (GTK.GTK_VERSION <= OS.VERSION(3, 10, 8))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  270 */         buffer = new byte[] { 32, 0 };
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  283 */       this.groupHandle = GTK.gtk_radio_menu_item_new(0L);
/*  284 */       if (this.groupHandle == 0L) error(2);
/*  285 */       OS.g_object_ref(this.groupHandle);
/*  286 */       OS.g_object_ref_sink(this.groupHandle);
/*  287 */       long group = GTK.gtk_radio_menu_item_get_group(this.groupHandle);
/*  288 */       if (GTK.GTK3) {
/*  289 */         this.handle = GTK.gtk_radio_menu_item_new(group);
/*  290 */         if (this.handle == 0L) { error(2);
/*      */         }
/*  292 */         this.labelHandle = GTK.gtk_accel_label_new(buffer);
/*  293 */         if (this.labelHandle == 0L) { error(2);
/*      */         }
/*  295 */         this.boxHandle = gtk_box_new(0, false, 6);
/*  296 */         if (this.boxHandle == 0L) { error(2);
/*      */         }
/*  298 */         if (OS.SWT_PADDED_MENU_ITEMS) {
/*  299 */           this.imageHandle = GTK.gtk_image_new();
/*  300 */           if (this.imageHandle == 0L) error(2);
/*      */         }
/*      */       } else {
/*  303 */         this.handle = GTK.gtk_radio_menu_item_new_with_label(group, buffer);
/*      */       }
/*  305 */       break;
/*      */     case 32: 
/*  307 */       if (GTK.GTK3) {
/*  308 */         this.handle = GTK.gtk_check_menu_item_new();
/*  309 */         if (this.handle == 0L) { error(2);
/*      */         }
/*  311 */         this.labelHandle = GTK.gtk_accel_label_new(buffer);
/*  312 */         if (this.labelHandle == 0L) { error(2);
/*      */         }
/*  314 */         this.boxHandle = gtk_box_new(0, false, 6);
/*  315 */         if (this.boxHandle == 0L) { error(2);
/*      */         }
/*  317 */         if (OS.SWT_PADDED_MENU_ITEMS) {
/*  318 */           this.imageHandle = GTK.gtk_image_new();
/*  319 */           if (this.imageHandle == 0L) error(2);
/*      */         }
/*      */       } else {
/*  322 */         this.handle = GTK.gtk_check_menu_item_new_with_label(buffer);
/*  323 */         if (this.handle == 0L) { error(2);
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */       break;
/*      */     case 64: 
/*  330 */       if (GTK.GTK3) {
/*  331 */         this.handle = GTK.gtk_menu_item_new();
/*  332 */         if (this.handle == 0L) { error(2);
/*      */         }
/*  334 */         this.labelHandle = GTK.gtk_accel_label_new(buffer);
/*  335 */         if (this.labelHandle == 0L) { error(2);
/*      */         }
/*  337 */         this.boxHandle = gtk_box_new(0, false, 6);
/*  338 */         if (this.boxHandle == 0L) error(2);
/*  339 */         if ((this.parent.style & bits) == 2) {
/*      */           break label658;
/*      */         }
/*  342 */         if (!OS.SWT_PADDED_MENU_ITEMS) break label658;
/*  343 */         this.imageHandle = GTK.gtk_image_new();
/*  344 */         if (this.imageHandle != 0L) break label658; error(2);
/*      */       }
/*      */       
/*      */       break;
/*      */     }
/*      */     
/*  350 */     if (GTK.GTK3) {
/*  351 */       this.handle = GTK.gtk_menu_item_new();
/*  352 */       if (this.handle == 0L) { error(2);
/*      */       }
/*  354 */       this.labelHandle = GTK.gtk_accel_label_new(buffer);
/*  355 */       if (this.labelHandle == 0L) { error(2);
/*      */       }
/*  357 */       this.boxHandle = gtk_box_new(0, false, 6);
/*  358 */       if (this.boxHandle == 0L) { error(2);
/*      */       }
/*  360 */       if (OS.SWT_PADDED_MENU_ITEMS) {
/*  361 */         this.imageHandle = GTK.gtk_image_new();
/*  362 */         if (this.imageHandle == 0L) error(2);
/*      */       }
/*      */     } else {
/*  365 */       this.handle = GTK.gtk_image_menu_item_new_with_label(buffer);
/*      */     }
/*      */     
/*      */     label658:
/*  369 */     if (this.imageHandle != 0L) {
/*  370 */       if (OS.SWT_PADDED_MENU_ITEMS) {
/*  371 */         GTK.gtk_image_set_pixel_size(this.imageHandle, 16);
/*      */       }
/*  373 */       GTK.gtk_container_add(this.boxHandle, this.imageHandle);
/*  374 */       GTK.gtk_widget_show(this.imageHandle);
/*      */     }
/*  376 */     if (this.labelHandle != 0L) {
/*  377 */       if (GTK.GTK_VERSION >= OS.VERSION(3, 16, 0)) {
/*  378 */         GTK.gtk_label_set_xalign(this.labelHandle, 0.0F);
/*  379 */         GTK.gtk_widget_set_halign(this.labelHandle, 0);
/*      */       } else {
/*  381 */         GTK.gtk_misc_set_alignment(this.labelHandle, 0.0F, 0.0F);
/*      */       }
/*  383 */       GTK.gtk_box_pack_end(this.boxHandle, this.labelHandle, true, true, 0);
/*  384 */       GTK.gtk_widget_show(this.labelHandle);
/*      */     }
/*  386 */     if (this.boxHandle != 0L) {
/*  387 */       GTK.gtk_container_add(this.handle, this.boxHandle);
/*  388 */       GTK.gtk_widget_show(this.boxHandle);
/*      */     }
/*  390 */     if ((this.style & 0x2) == 0) {
/*  391 */       if (this.boxHandle == 0L) {
/*  392 */         this.labelHandle = GTK.gtk_bin_get_child(this.handle);
/*      */       }
/*  394 */       GTK.gtk_accel_label_set_accel_widget(this.labelHandle, 0L);
/*      */     }
/*  396 */     long parentHandle = this.parent.handle;
/*  397 */     boolean enabled = GTK.gtk_widget_get_sensitive(parentHandle);
/*  398 */     if (!enabled) GTK.gtk_widget_set_sensitive(parentHandle, true);
/*  399 */     GTK.gtk_menu_shell_insert(parentHandle, this.handle, index);
/*  400 */     if (!enabled) GTK.gtk_widget_set_sensitive(parentHandle, false);
/*  401 */     GTK.gtk_widget_show(this.handle);
/*      */   }
/*      */   
/*      */   void fixMenus(Decorations newParent) {
/*  405 */     if ((this.menu != null) && (!this.menu.isDisposed()) && (!newParent.isDisposed())) { this.menu.fixMenus(newParent);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getAccelerator()
/*      */   {
/*  424 */     checkWidget();
/*  425 */     return this.accelerator;
/*      */   }
/*      */   
/*      */   long getAccelGroup() {
/*  429 */     Menu menu = this.parent;
/*  430 */     while ((menu != null) && (menu.cascade != null)) {
/*  431 */       menu = menu.cascade.parent;
/*      */     }
/*  433 */     if (menu == null) return 0L;
/*  434 */     Decorations shell = menu.parent;
/*  435 */     if (shell == null) return 0L;
/*  436 */     return shell.menuBar == menu ? shell.accelGroup : 0L;
/*      */   }
/*      */   
/*      */   Rectangle getBounds() {
/*  440 */     checkWidget();
/*  441 */     if (!GTK.gtk_widget_get_mapped(this.handle)) {
/*  442 */       return new Rectangle(0, 0, 0, 0);
/*      */     }
/*  444 */     GtkAllocation allocation = new GtkAllocation();
/*  445 */     GTK.gtk_widget_get_allocation(this.handle, allocation);
/*  446 */     int x = allocation.x;
/*  447 */     int y = allocation.y;
/*  448 */     int width = allocation.width;
/*  449 */     int height = allocation.height;
/*  450 */     return new Rectangle(x, y, width, height);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getEnabled()
/*      */   {
/*  469 */     checkWidget();
/*  470 */     return GTK.gtk_widget_get_sensitive(this.handle);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getID()
/*      */   {
/*  486 */     checkWidget();
/*  487 */     return this.userId;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Menu getMenu()
/*      */   {
/*  505 */     checkWidget();
/*  506 */     return this.menu;
/*      */   }
/*      */   
/*      */   String getNameText()
/*      */   {
/*  511 */     if ((this.style & 0x2) != 0) return "|";
/*  512 */     return super.getNameText();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Menu getParent()
/*      */   {
/*  526 */     checkWidget();
/*  527 */     return this.parent;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getSelection()
/*      */   {
/*  545 */     checkWidget();
/*  546 */     if ((this.style & 0x30) == 0) return false;
/*  547 */     return GTK.gtk_check_menu_item_get_active(this.handle);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getToolTipText()
/*      */   {
/*  563 */     checkWidget();
/*  564 */     return this.toolTipText;
/*      */   }
/*      */   
/*      */   long gtk_activate(long widget)
/*      */   {
/*  569 */     if (((this.style & 0x40) != 0) && (this.menu != null)) { return 0L;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  577 */     if (!isEnabled()) return 0L;
/*  578 */     if (((this.style & 0x10) != 0) && 
/*  579 */       ((this.parent.getStyle() & 0x400000) == 0)) {
/*  580 */       selectRadio();
/*      */     }
/*      */     
/*  583 */     sendSelectionEvent(13);
/*  584 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_select(long item)
/*      */   {
/*  589 */     this.parent.selectedItem = this;
/*  590 */     sendEvent(30);
/*  591 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_show_help(long widget, long helpType)
/*      */   {
/*  596 */     boolean handled = hooks(28);
/*  597 */     if (handled) {
/*  598 */       postEvent(28);
/*      */     } else {
/*  600 */       handled = this.parent.sendHelpEvent(helpType);
/*      */     }
/*  602 */     if (handled) {
/*  603 */       GTK.gtk_menu_shell_deactivate(this.parent.handle);
/*  604 */       return 1L;
/*      */     }
/*  606 */     return 0L;
/*      */   }
/*      */   
/*      */   void hookEvents()
/*      */   {
/*  611 */     super.hookEvents();
/*  612 */     OS.g_signal_connect_closure(this.handle, OS.activate, this.display.getClosure(1), false);
/*  613 */     OS.g_signal_connect_closure(this.handle, OS.select, this.display.getClosure(44), false);
/*  614 */     OS.g_signal_connect_closure_by_id(this.handle, this.display.signalIds[46], 0, this.display.getClosure(46), false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isEnabled()
/*      */   {
/*  633 */     return (getEnabled()) && (this.parent.isEnabled());
/*      */   }
/*      */   
/*      */   void releaseChildren(boolean destroy)
/*      */   {
/*  638 */     if (this.menu != null) {
/*  639 */       this.menu.release(false);
/*  640 */       this.menu = null;
/*      */     }
/*  642 */     super.releaseChildren(destroy);
/*      */   }
/*      */   
/*      */   void releaseParent()
/*      */   {
/*  647 */     super.releaseParent();
/*  648 */     if (this.menu != null) {
/*  649 */       if (this.menu.selectedItem == this) this.menu.selectedItem = null;
/*  650 */       this.menu.dispose();
/*      */     }
/*  652 */     this.menu = null;
/*      */   }
/*      */   
/*      */   void releaseWidget()
/*      */   {
/*  657 */     super.releaseWidget();
/*  658 */     long accelGroup = getAccelGroup();
/*  659 */     if (accelGroup != 0L) removeAccelerator(accelGroup);
/*  660 */     if (this.groupHandle != 0L) OS.g_object_unref(this.groupHandle);
/*  661 */     this.groupHandle = 0L;
/*  662 */     this.accelerator = 0;
/*  663 */     this.parent = null;
/*      */   }
/*      */   
/*      */   void removeAccelerator(long accelGroup) {
/*  667 */     updateAccelerator(accelGroup, false);
/*      */   }
/*      */   
/*      */   void removeAccelerators(long accelGroup) {
/*  671 */     removeAccelerator(accelGroup);
/*  672 */     if (this.menu != null) { this.menu.removeAccelerators(accelGroup);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeArmListener(ArmListener listener)
/*      */   {
/*  693 */     checkWidget();
/*  694 */     if (listener == null) error(4);
/*  695 */     if (this.eventTable == null) return;
/*  696 */     this.eventTable.unhook(30, listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeHelpListener(HelpListener listener)
/*      */   {
/*  717 */     checkWidget();
/*  718 */     if (listener == null) error(4);
/*  719 */     if (this.eventTable == null) return;
/*  720 */     this.eventTable.unhook(28, listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeSelectionListener(SelectionListener listener)
/*      */   {
/*  741 */     checkWidget();
/*  742 */     if (listener == null) error(4);
/*  743 */     if (this.eventTable == null) return;
/*  744 */     this.eventTable.unhook(13, listener);
/*  745 */     this.eventTable.unhook(14, listener);
/*      */   }
/*      */   
/*      */   void reskinChildren(int flags) {
/*  749 */     if (this.menu != null) {
/*  750 */       this.menu.reskin(flags);
/*      */     }
/*  752 */     super.reskinChildren(flags);
/*      */   }
/*      */   
/*  755 */   void selectRadio() { int index = 0;
/*  756 */     MenuItem[] items = this.parent.getItems();
/*  757 */     while ((index < items.length) && (items[index] != this)) index++;
/*  758 */     int i = index - 1;
/*  759 */     while ((i >= 0) && (items[i].setRadioSelection(false))) i--;
/*  760 */     int j = index + 1;
/*  761 */     while ((j < items.length) && (items[j].setRadioSelection(false))) j++;
/*  762 */     setSelection(true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAccelerator(int accelerator)
/*      */   {
/*  781 */     checkWidget();
/*  782 */     if (this.accelerator == accelerator) return;
/*  783 */     long accelGroup = getAccelGroup();
/*  784 */     if (accelGroup != 0L) removeAccelerator(accelGroup);
/*  785 */     this.accelerator = accelerator;
/*  786 */     if (accelGroup != 0L) { addAccelerator(accelGroup);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setEnabled(boolean enabled)
/*      */   {
/*  803 */     checkWidget();
/*  804 */     if (GTK.gtk_widget_get_sensitive(this.handle) == enabled) return;
/*  805 */     long accelGroup = getAccelGroup();
/*  806 */     if (accelGroup != 0L) removeAccelerator(accelGroup);
/*  807 */     GTK.gtk_widget_set_sensitive(this.handle, enabled);
/*  808 */     if (accelGroup != 0L) { addAccelerator(accelGroup);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setID(int id)
/*      */   {
/*  825 */     checkWidget();
/*  826 */     if (id < 0) error(5);
/*  827 */     this.userId = id;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setImage(Image image)
/*      */   {
/*  851 */     checkWidget();
/*  852 */     if ((this.style & 0x2) != 0) return;
/*  853 */     super.setImage(image);
/*  854 */     if (image != null) {
/*  855 */       ImageList imageList = this.parent.imageList;
/*  856 */       if (imageList == null) imageList = this.parent.imageList = new ImageList();
/*  857 */       int imageIndex = imageList.indexOf(image);
/*  858 */       if (imageIndex == -1) {
/*  859 */         imageIndex = imageList.add(image);
/*      */       } else {
/*  861 */         imageList.put(imageIndex, image);
/*      */       }
/*  863 */       long pixbuf = imageList.getPixbuf(imageIndex);
/*  864 */       if (GTK.GTK3) {
/*  865 */         Rectangle imgSize = image.getBounds();
/*  866 */         long scaledPixbuf = GDK.gdk_pixbuf_scale_simple(pixbuf, imgSize.width, imgSize.height, 2);
/*  867 */         if (scaledPixbuf != 0L) {
/*  868 */           pixbuf = scaledPixbuf;
/*      */         }
/*      */         
/*  871 */         if (!GTK.GTK_IS_MENU_ITEM(this.handle)) return;
/*  872 */         if ((OS.SWT_PADDED_MENU_ITEMS) && (this.imageHandle != 0L)) {
/*  873 */           GTK.gtk_image_set_from_pixbuf(this.imageHandle, pixbuf);
/*      */         } else {
/*  875 */           if ((this.imageHandle == 0L) && (this.boxHandle != 0L)) {
/*  876 */             this.imageHandle = GTK.gtk_image_new_from_pixbuf(pixbuf);
/*  877 */             GTK.gtk_container_add(this.boxHandle, this.imageHandle);
/*  878 */             GTK.gtk_box_reorder_child(this.boxHandle, this.imageHandle, 0);
/*      */           } else {
/*  880 */             GTK.gtk_image_set_from_pixbuf(this.imageHandle, pixbuf);
/*      */           }
/*  882 */           if (this.boxHandle == 0L) error(2);
/*      */         }
/*      */       } else {
/*  885 */         if (!GTK.GTK_IS_IMAGE_MENU_ITEM(this.handle)) return;
/*  886 */         this.imageHandle = GTK.gtk_image_new_from_pixbuf(pixbuf);
/*  887 */         GTK.gtk_image_menu_item_set_image(this.handle, this.imageHandle);
/*      */       }
/*  889 */       if (this.imageHandle == 0L) error(2);
/*  890 */       GTK.gtk_widget_show(this.imageHandle);
/*      */     }
/*  892 */     else if (GTK.GTK3) {
/*  893 */       if ((this.imageHandle != 0L) && (this.boxHandle != 0L)) {
/*  894 */         if (OS.SWT_PADDED_MENU_ITEMS) {
/*  895 */           GTK.gtk_container_remove(this.boxHandle, this.imageHandle);
/*  896 */           this.imageHandle = GTK.gtk_image_new();
/*  897 */           if (this.imageHandle == 0L) error(2);
/*  898 */           GTK.gtk_image_set_pixel_size(this.imageHandle, 16);
/*  899 */           GTK.gtk_container_add(this.boxHandle, this.imageHandle);
/*  900 */           GTK.gtk_widget_show(this.imageHandle);
/*      */         } else {
/*  902 */           GTK.gtk_container_remove(this.boxHandle, this.imageHandle);
/*  903 */           this.imageHandle = 0L;
/*      */         }
/*      */       }
/*      */     } else {
/*  907 */       if (!GTK.GTK_IS_IMAGE_MENU_ITEM(this.handle)) return;
/*  908 */       GTK.gtk_image_menu_item_set_image(this.handle, 0L);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setMenu(Menu menu)
/*      */   {
/*  939 */     checkWidget();
/*      */     
/*      */ 
/*  942 */     if ((this.style & 0x40) == 0) {
/*  943 */       error(27);
/*      */     }
/*  945 */     if (menu != null) {
/*  946 */       if ((menu.style & 0x4) == 0) {
/*  947 */         error(21);
/*      */       }
/*  949 */       if (menu.parent != this.parent.parent) {
/*  950 */         error(32);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  955 */     Menu oldMenu = this.menu;
/*  956 */     if (oldMenu == menu) return;
/*  957 */     long accelGroup = getAccelGroup();
/*  958 */     if (accelGroup != 0L) removeAccelerators(accelGroup);
/*  959 */     if (oldMenu != null) {
/*  960 */       oldMenu.cascade = null;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  965 */       OS.g_object_ref(oldMenu.handle);
/*  966 */       GTK.gtk_menu_item_set_submenu(this.handle, 0L);
/*      */     }
/*  968 */     if ((this.menu = menu) != null) {
/*  969 */       menu.cascade = this;
/*  970 */       GTK.gtk_menu_item_set_submenu(this.handle, menu.handle);
/*      */     }
/*  972 */     if (accelGroup != 0L) addAccelerators(accelGroup);
/*      */   }
/*      */   
/*      */   void setOrientation(boolean create)
/*      */   {
/*  977 */     super.setOrientation(create);
/*  978 */     if (((this.parent.style & 0x4000000) != 0) || (!create)) {
/*  979 */       int dir = (this.parent.style & 0x4000000) != 0 ? 2 : 1;
/*  980 */       GTK.gtk_widget_set_direction(this.handle, dir);
/*  981 */       GTK.gtk_container_forall(this.handle, this.display.setDirectionProc, dir);
/*  982 */       if (this.menu != null) this.menu._setOrientation(this.parent.style & 0x6000000);
/*      */     }
/*      */   }
/*      */   
/*      */   boolean setRadioSelection(boolean value) {
/*  987 */     if ((this.style & 0x10) == 0) return false;
/*  988 */     if (getSelection() != value) {
/*  989 */       setSelection(value);
/*  990 */       sendSelectionEvent(13);
/*      */     }
/*  992 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSelection(boolean selected)
/*      */   {
/* 1009 */     checkWidget();
/* 1010 */     if ((this.style & 0x30) == 0) return;
/* 1011 */     OS.g_signal_handlers_block_matched(this.handle, 16, 0, 0, 0L, 0L, 1L);
/* 1012 */     GTK.gtk_check_menu_item_set_active(this.handle, selected);
/* 1013 */     if ((this.style & 0x10) != 0) GTK.gtk_check_menu_item_set_active(this.groupHandle, !selected);
/* 1014 */     OS.g_signal_handlers_unblock_matched(this.handle, 16, 0, 0, 0L, 0L, 1L);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setText(String string)
/*      */   {
/* 1056 */     checkWidget();
/* 1057 */     if (string == null) error(4);
/* 1058 */     if ((this.style & 0x2) != 0) return;
/* 1059 */     if (this.text.equals(string)) return;
/* 1060 */     super.setText(string);
/* 1061 */     String accelString = "";
/* 1062 */     int index = string.indexOf('\t');
/* 1063 */     if (index != -1) {
/* 1064 */       boolean isRTL = (this.parent.style & 0x4000000) != 0;
/* 1065 */       accelString = (isRTL ? "" : "  ") + string.substring(index + 1, string.length()) + (isRTL ? "  " : "");
/* 1066 */       string = string.substring(0, index);
/*      */     }
/* 1068 */     char[] chars = fixMnemonic(string);
/* 1069 */     byte[] buffer = Converter.wcsToMbcs(chars, true);
/* 1070 */     if ((this.boxHandle == 0L) && (!GTK.GTK3)) {
/* 1071 */       this.labelHandle = GTK.gtk_bin_get_child(this.handle);
/*      */     }
/* 1073 */     if ((this.labelHandle != 0L) && (GTK.GTK_IS_LABEL(this.labelHandle))) {
/* 1074 */       GTK.gtk_label_set_text_with_mnemonic(this.labelHandle, buffer);
/* 1075 */       if (GTK.GTK_IS_ACCEL_LABEL(this.labelHandle)) {
/* 1076 */         if (GTK.GTK3) {
/* 1077 */           if (GTK.GTK_VERSION >= OS.VERSION(3, 6, 0)) {
/* 1078 */             MaskKeysym maskKeysym = getMaskKeysym();
/* 1079 */             if (maskKeysym != null) {
/* 1080 */               GTK.gtk_accel_label_set_accel_widget(this.labelHandle, this.handle);
/* 1081 */               GTK.gtk_accel_label_set_accel(this.labelHandle, maskKeysym.keysym, maskKeysym.mask);
/*      */             }
/*      */           }
/*      */           else {
/* 1085 */             setAccelLabel(this.labelHandle, accelString);
/*      */           }
/*      */         } else {
/* 1088 */           setAccelLabel(this.labelHandle, accelString);
/*      */         }
/*      */         
/* 1091 */         OS.g_signal_emit_by_name(this.handle, OS.accel_closures_changed);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void setAccelLabel(long label, String accelString) {
/* 1097 */     byte[] buffer = Converter.wcsToMbcs(accelString, true);
/* 1098 */     long ptr = OS.g_malloc(buffer.length);
/* 1099 */     C.memmove(ptr, buffer, buffer.length);
/* 1100 */     long oldPtr = GTK.GTK_ACCEL_LABEL_GET_ACCEL_STRING(label);
/* 1101 */     GTK.GTK_ACCEL_LABEL_SET_ACCEL_STRING(label, ptr);
/* 1102 */     if (oldPtr != 0L) { OS.g_free(oldPtr);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setToolTipText(String toolTip)
/*      */   {
/* 1136 */     checkWidget();
/* 1137 */     if ((toolTip != null) && ((toolTip.trim().length() == 0) || (toolTip.equals(this.toolTipText)))) { return;
/*      */     }
/* 1139 */     this.parent.getShell().setToolTipText(this.handle, this.toolTipText = toolTip);
/*      */   }
/*      */   
/*      */   void updateAccelerator(long accelGroup, boolean add) {
/* 1143 */     if ((this.accelerator == 0) || (!getEnabled())) return;
/* 1144 */     if ((this.accelerator & 0x400000) != 0) return;
/* 1145 */     int mask = 0;
/* 1146 */     if ((this.accelerator & 0x10000) != 0) mask |= 0x8;
/* 1147 */     if ((this.accelerator & 0x20000) != 0) mask |= 0x1;
/* 1148 */     if ((this.accelerator & 0x40000) != 0) mask |= 0x4;
/* 1149 */     int keysym = this.accelerator & 0x100FFFF;
/* 1150 */     int newKey = Display.untranslateKey(keysym);
/* 1151 */     if (newKey != 0) {
/* 1152 */       keysym = newKey;
/*      */     } else {
/* 1154 */       switch (keysym) {
/* 1155 */       case 13:  keysym = 65293; break;
/* 1156 */       default:  keysym = Converter.wcsToMbcs((char)keysym);
/*      */       }
/*      */       
/*      */     }
/* 1160 */     if (keysym != 0) {
/* 1161 */       if (add) {
/* 1162 */         GTK.gtk_widget_add_accelerator(this.handle, OS.activate, accelGroup, keysym, mask, 1);
/*      */       } else {
/* 1164 */         GTK.gtk_widget_remove_accelerator(this.handle, accelGroup, keysym, mask);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private class MaskKeysym {
/* 1170 */     int mask = 0;
/* 1171 */     int keysym = 0;
/*      */     
/*      */     private MaskKeysym() {} }
/*      */   
/* 1175 */   private MaskKeysym getMaskKeysym() { if (this.text == null) return null;
/* 1176 */     MaskKeysym maskKeysym = new MaskKeysym(null);
/* 1177 */     int accelIndex = this.text.indexOf('\t');
/* 1178 */     if (accelIndex == -1) return null;
/* 1179 */     int start = accelIndex + 1;
/* 1180 */     int plusIndex = this.text.indexOf('+', start);
/* 1181 */     while (plusIndex != -1) {
/* 1182 */       String maskStr = this.text.substring(start, plusIndex);
/* 1183 */       if (maskStr.equals("Ctrl")) maskKeysym.mask |= 0x4;
/* 1184 */       if (maskStr.equals("Shift")) maskKeysym.mask |= 0x1;
/* 1185 */       if (maskStr.equals("Alt")) maskKeysym.mask |= 0x8;
/* 1186 */       start = plusIndex + 1;
/* 1187 */       plusIndex = this.text.indexOf('+', start);
/*      */     }
/* 1189 */     if ("Enter".equals(this.text.substring(start))) {
/* 1190 */       maskKeysym.keysym = 65076;
/*      */     }
/* 1192 */     switch (this.text.length() - start) {
/*      */     case 1: 
/* 1194 */       maskKeysym.keysym = this.text.charAt(start);
/* 1195 */       maskKeysym.keysym = Converter.wcsToMbcs((char)maskKeysym.keysym);
/* 1196 */       break;
/*      */     case 2: 
/* 1198 */       if (this.text.charAt(start) == 'F') {
/* 1199 */         switch (this.text.charAt(start + 1)) {
/* 1200 */         case '1':  maskKeysym.keysym = 65470; break;
/* 1201 */         case '2':  maskKeysym.keysym = 65471; break;
/* 1202 */         case '3':  maskKeysym.keysym = 65472; break;
/* 1203 */         case '4':  maskKeysym.keysym = 65473; break;
/* 1204 */         case '5':  maskKeysym.keysym = 65474; break;
/* 1205 */         case '6':  maskKeysym.keysym = 65475; break;
/* 1206 */         case '7':  maskKeysym.keysym = 65476; break;
/* 1207 */         case '8':  maskKeysym.keysym = 65477; break;
/* 1208 */         case '9':  maskKeysym.keysym = 65478;
/*      */         }
/*      */       }
/*      */       break;
/*      */     case 3: 
/* 1213 */       if ((this.text.charAt(start) == 'F') && (this.text.charAt(start + 1) == '1')) {
/* 1214 */         switch (this.text.charAt(start + 2)) {
/* 1215 */         case '0':  maskKeysym.keysym = 65479; break;
/* 1216 */         case '1':  maskKeysym.keysym = 65480; break;
/* 1217 */         case '2':  maskKeysym.keysym = 65481; break;
/* 1218 */         case '3':  maskKeysym.keysym = 65482; break;
/* 1219 */         case '4':  maskKeysym.keysym = 65483; break;
/* 1220 */         case '5':  maskKeysym.keysym = 65484;
/*      */         }
/*      */       }
/*      */       break;
/*      */     }
/* 1225 */     return maskKeysym;
/*      */   }
/*      */   
/* 1228 */   boolean updateAcceleratorText(boolean show) { if (this.accelerator != 0) return false;
/* 1229 */     MaskKeysym maskKeysym = null;
/* 1230 */     if (show) {
/* 1231 */       maskKeysym = getMaskKeysym();
/*      */     }
/* 1233 */     if (maskKeysym == null) return true;
/* 1234 */     if (maskKeysym.keysym != 0) {
/* 1235 */       long accelGroup = getAccelGroup();
/* 1236 */       if (show) {
/* 1237 */         GTK.gtk_widget_add_accelerator(this.handle, OS.activate, accelGroup, maskKeysym.keysym, maskKeysym.mask, 1);
/*      */       } else {
/* 1239 */         GTK.gtk_widget_remove_accelerator(this.handle, accelGroup, maskKeysym.keysym, maskKeysym.mask);
/*      */       }
/*      */     }
/* 1242 */     return maskKeysym.keysym != 0;
/*      */   }
/*      */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/widgets/MenuItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */