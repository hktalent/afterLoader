/*     */ package org.eclipse.swt.dnd;
/*     */ 
/*     */ import org.eclipse.swt.graphics.Point;
/*     */ import org.eclipse.swt.internal.C;
/*     */ import org.eclipse.swt.internal.DPIUtil;
/*     */ import org.eclipse.swt.internal.gtk.GTK;
/*     */ import org.eclipse.swt.internal.gtk.GdkRectangle;
/*     */ import org.eclipse.swt.widgets.Tree;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TreeDropTargetEffect
/*     */   extends DropTargetEffect
/*     */ {
/*     */   static final int SCROLL_HYSTERESIS = 150;
/*     */   static final int EXPAND_HYSTERESIS = 1000;
/*  55 */   int scrollIndex = -1;
/*     */   
/*     */   long scrollBeginTime;
/*  58 */   int expandIndex = -1;
/*     */   
/*     */ 
/*     */ 
/*     */   long expandBeginTime;
/*     */   
/*     */ 
/*     */ 
/*     */   public TreeDropTargetEffect(Tree tree)
/*     */   {
/*  68 */     super(tree);
/*     */   }
/*     */   
/*     */   int checkEffect(int effect)
/*     */   {
/*  73 */     if ((effect & 0x1) != 0) effect = effect & 0xFFFFFFFB & 0xFFFFFFFD;
/*  74 */     if ((effect & 0x2) != 0) effect &= 0xFFFFFFFB;
/*  75 */     return effect;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void dragEnter(DropTargetEvent event)
/*     */   {
/*  94 */     this.expandBeginTime = 0L;
/*  95 */     this.expandIndex = -1;
/*  96 */     this.scrollBeginTime = 0L;
/*  97 */     this.scrollIndex = -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void dragLeave(DropTargetEvent event)
/*     */   {
/* 116 */     Tree tree = (Tree)this.control;
/* 117 */     long handle = tree.handle;
/* 118 */     GTK.gtk_tree_view_set_drag_dest_row(handle, 0L, 0);
/*     */     
/* 120 */     this.scrollBeginTime = 0L;
/* 121 */     this.scrollIndex = -1;
/* 122 */     this.expandBeginTime = 0L;
/* 123 */     this.expandIndex = -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void dragOver(DropTargetEvent event)
/*     */   {
/* 146 */     Tree tree = (Tree)this.control;
/* 147 */     int effect = checkEffect(event.feedback);
/*     */     
/* 149 */     long handle = tree.handle;
/* 150 */     Point coordinates = new Point(event.x, event.y);
/* 151 */     coordinates = DPIUtil.autoScaleUp(tree.toControl(coordinates));
/* 152 */     long[] path = new long[1];
/* 153 */     GTK.gtk_tree_view_get_path_at_pos(handle, coordinates.x, coordinates.y, path, null, null, null);
/* 154 */     int index = -1;
/* 155 */     if (path[0] != 0L) {
/* 156 */       long indices = GTK.gtk_tree_path_get_indices(path[0]);
/* 157 */       if (indices != 0L) {
/* 158 */         int depth = GTK.gtk_tree_path_get_depth(path[0]);
/* 159 */         int[] temp = new int[depth];
/* 160 */         C.memmove(temp, indices, temp.length * 4);
/* 161 */         index = temp[(temp.length - 1)];
/*     */       }
/*     */     }
/* 164 */     if ((effect & 0x8) == 0) {
/* 165 */       this.scrollBeginTime = 0L;
/* 166 */       this.scrollIndex = -1;
/*     */     }
/* 168 */     else if ((index != -1) && (this.scrollIndex == index) && (this.scrollBeginTime != 0L)) {
/* 169 */       if (System.currentTimeMillis() >= this.scrollBeginTime) {
/* 170 */         GdkRectangle cellRect = new GdkRectangle();
/* 171 */         GTK.gtk_tree_view_get_cell_area(handle, path[0], 0L, cellRect);
/* 172 */         if (cellRect.y < cellRect.height) {
/* 173 */           int[] tx = new int[1];int[] ty = new int[1];
/* 174 */           GTK.gtk_tree_view_convert_bin_window_to_tree_coords(handle, cellRect.x, cellRect.y - cellRect.height, tx, ty);
/* 175 */           GTK.gtk_tree_view_scroll_to_point(handle, -1, ty[0]);
/*     */         }
/*     */         else {
/* 178 */           GTK.gtk_tree_view_get_path_at_pos(handle, coordinates.x, coordinates.y + cellRect.height, path, null, null, null);
/* 179 */           if (path[0] != 0L) {
/* 180 */             GTK.gtk_tree_view_scroll_to_cell(handle, path[0], 0L, false, 0.0F, 0.0F);
/* 181 */             GTK.gtk_tree_path_free(path[0]);
/* 182 */             path[0] = 0L;
/*     */           }
/* 184 */           GTK.gtk_tree_view_get_path_at_pos(handle, coordinates.x, coordinates.y, path, null, null, null);
/*     */         }
/* 186 */         this.scrollBeginTime = 0L;
/* 187 */         this.scrollIndex = -1;
/*     */       }
/*     */     } else {
/* 190 */       this.scrollBeginTime = (System.currentTimeMillis() + 150L);
/* 191 */       this.scrollIndex = index;
/*     */     }
/*     */     
/* 194 */     if ((effect & 0x10) == 0) {
/* 195 */       this.expandBeginTime = 0L;
/* 196 */       this.expandIndex = -1;
/*     */     }
/* 198 */     else if ((index != -1) && (this.expandIndex == index) && (this.expandBeginTime != 0L)) {
/* 199 */       if (System.currentTimeMillis() >= this.expandBeginTime) {
/* 200 */         GTK.gtk_tree_view_expand_row(handle, path[0], false);
/* 201 */         this.expandBeginTime = 0L;
/* 202 */         this.expandIndex = -1;
/*     */       }
/*     */     } else {
/* 205 */       this.expandBeginTime = (System.currentTimeMillis() + 1000L);
/* 206 */       this.expandIndex = index;
/*     */     }
/*     */     
/* 209 */     if (path[0] != 0L) {
/* 210 */       int position = -1;
/* 211 */       if ((effect & 0x1) != 0) position = 2;
/* 212 */       if ((effect & 0x2) != 0) position = 0;
/* 213 */       if ((effect & 0x4) != 0) position = 1;
/* 214 */       if (position != -1) {
/* 215 */         GTK.gtk_tree_view_set_drag_dest_row(handle, path[0], position);
/*     */       } else {
/* 217 */         GTK.gtk_tree_view_set_drag_dest_row(handle, 0L, 0);
/*     */       }
/*     */     } else {
/* 220 */       GTK.gtk_tree_view_set_drag_dest_row(handle, 0L, 0);
/*     */     }
/*     */     
/* 223 */     if (path[0] != 0L) GTK.gtk_tree_path_free(path[0]);
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/dnd/TreeDropTargetEffect.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */