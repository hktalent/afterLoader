/*    */ package org.eclipse.swt.events;
/*    */ 
/*    */ import java.util.function.Consumer;
/*    */ import org.eclipse.swt.internal.SWTEventListener;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract interface ControlListener
/*    */   extends SWTEventListener
/*    */ {
/*    */   public abstract void controlMoved(ControlEvent paramControlEvent);
/*    */   
/*    */   public abstract void controlResized(ControlEvent paramControlEvent);
/*    */   
/*    */   public static ControlListener controlMovedAdapter(Consumer<ControlEvent> c)
/*    */   {
/* 60 */     new ControlAdapter()
/*    */     {
/*    */       public void controlMoved(ControlEvent e) {
/* 63 */         this.val$c.accept(e);
/*    */       }
/*    */     };
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static ControlListener controlResizedAdapter(Consumer<ControlEvent> c)
/*    */   {
/* 77 */     new ControlAdapter()
/*    */     {
/*    */       public void controlResized(ControlEvent e) {
/* 80 */         this.val$c.accept(e);
/*    */       }
/*    */     };
/*    */   }
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/events/ControlListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */