/*    */ package org.eclipse.swt.custom;
/*    */ 
/*    */ import org.eclipse.swt.events.TypedEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TextChangingEvent
/*    */   extends TypedEvent
/*    */ {
/*    */   public int start;
/*    */   public String newText;
/*    */   public int replaceCharCount;
/*    */   public int newCharCount;
/*    */   public int replaceLineCount;
/*    */   public int newLineCount;
/*    */   static final long serialVersionUID = 3257290210114352439L;
/*    */   
/* 59 */   public TextChangingEvent(StyledTextContent source) { super(source); }
/*    */   
/*    */   TextChangingEvent(StyledTextContent source, StyledTextEvent e) {
/* 62 */     super(source);
/* 63 */     this.start = e.start;
/* 64 */     this.replaceCharCount = e.replaceCharCount;
/* 65 */     this.newCharCount = e.newCharCount;
/* 66 */     this.replaceLineCount = e.replaceLineCount;
/* 67 */     this.newLineCount = e.newLineCount;
/* 68 */     this.newText = e.text;
/*    */   }
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/custom/TextChangingEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */