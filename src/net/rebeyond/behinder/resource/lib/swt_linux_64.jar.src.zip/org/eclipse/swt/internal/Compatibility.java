/*     */ package org.eclipse.swt.internal;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.MissingResourceException;
/*     */ import java.util.ResourceBundle;
/*     */ import org.eclipse.swt.SWT;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Compatibility
/*     */ {
/*     */   public static int ceil(int p, int q)
/*     */   {
/*  54 */     return (int)Math.ceil(p / q);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int round(int p, int q)
/*     */   {
/*  71 */     return Math.round(p / q);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int pow2(int n)
/*     */   {
/*  85 */     if ((n >= 1) && (n <= 30))
/*  86 */       return 2 << n - 1;
/*  87 */     if (n != 0) {
/*  88 */       SWT.error(6);
/*     */     }
/*  90 */     return 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void exec(String[] prog, String[] envp, String workingDir)
/*     */     throws IOException
/*     */   {
/* 116 */     Runtime.getRuntime().exec(prog, null, workingDir != null ? new File(workingDir) : null);
/*     */   }
/*     */   
/* 119 */   private static ResourceBundle msgs = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getMessage(String key)
/*     */   {
/* 131 */     String answer = key;
/*     */     
/* 133 */     if (key == null) {
/* 134 */       SWT.error(4);
/*     */     }
/* 136 */     if (msgs == null) {
/*     */       try {
/* 138 */         msgs = ResourceBundle.getBundle("org.eclipse.swt.internal.SWTMessages");
/*     */       } catch (MissingResourceException ex) {
/* 140 */         answer = key + " (no resource bundle)";
/*     */       }
/*     */     }
/* 143 */     if (msgs != null) {
/*     */       try {
/* 145 */         answer = msgs.getString(key);
/*     */       } catch (MissingResourceException localMissingResourceException1) {}
/*     */     }
/* 148 */     return answer;
/*     */   }
/*     */   
/*     */   public static String getMessage(String key, Object[] args) {
/* 152 */     String answer = key;
/*     */     
/* 154 */     if ((key == null) || (args == null)) {
/* 155 */       SWT.error(4);
/*     */     }
/* 157 */     if (msgs == null) {
/*     */       try {
/* 159 */         msgs = ResourceBundle.getBundle("org.eclipse.swt.internal.SWTMessages");
/*     */       } catch (MissingResourceException ex) {
/* 161 */         answer = key + " (no resource bundle)";
/*     */       }
/*     */     }
/* 164 */     if (msgs != null) {
/*     */       try {
/* 166 */         MessageFormat formatter = new MessageFormat("");
/* 167 */         formatter.applyPattern(msgs.getString(key));
/* 168 */         answer = formatter.format(args);
/*     */       } catch (MissingResourceException localMissingResourceException1) {}
/*     */     }
/* 171 */     return answer;
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/internal/Compatibility.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */