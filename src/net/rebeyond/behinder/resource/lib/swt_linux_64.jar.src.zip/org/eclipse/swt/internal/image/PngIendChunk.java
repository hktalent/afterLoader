/*    */ package org.eclipse.swt.internal.image;
/*    */ 
/*    */ import org.eclipse.swt.SWT;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class PngIendChunk
/*    */   extends PngChunk
/*    */ {
/*    */   PngIendChunk()
/*    */   {
/* 19 */     super(0);
/* 20 */     setType(TYPE_IEND);
/* 21 */     setCRC(computeCRC());
/*    */   }
/*    */   
/*    */   PngIendChunk(byte[] reference) {
/* 25 */     super(reference);
/*    */   }
/*    */   
/*    */   int getChunkType()
/*    */   {
/* 30 */     return 3;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   void validate(PngFileReadState readState, PngIhdrChunk headerChunk)
/*    */   {
/* 41 */     if ((!readState.readIHDR) || 
/* 42 */       ((headerChunk.getMustHavePalette()) && (!readState.readPLTE)) || (!readState.readIDAT) || (readState.readIEND))
/*    */     {
/*    */ 
/*    */ 
/* 46 */       SWT.error(40);
/*    */     } else {
/* 48 */       readState.readIEND = true;
/*    */     }
/*    */     
/* 51 */     super.validate(readState, headerChunk);
/*    */     
/*    */ 
/* 54 */     if (getLength() > 0) SWT.error(40);
/*    */   }
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/internal/image/PngIendChunk.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */