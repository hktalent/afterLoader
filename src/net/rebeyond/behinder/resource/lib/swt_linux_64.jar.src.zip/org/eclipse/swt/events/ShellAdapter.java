package org.eclipse.swt.events;

public abstract class ShellAdapter
  implements ShellListener
{
  public void shellActivated(ShellEvent e) {}
  
  public void shellClosed(ShellEvent e) {}
  
  public void shellDeactivated(ShellEvent e) {}
  
  public void shellDeiconified(ShellEvent e) {}
  
  public void shellIconified(ShellEvent e) {}
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/events/ShellAdapter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */