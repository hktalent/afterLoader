/*    */ package org.eclipse.swt.events;
/*    */ 
/*    */ import org.eclipse.swt.widgets.Event;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class DragDetectEvent
/*    */   extends MouseEvent
/*    */ {
/*    */   private static final long serialVersionUID = -7229172519733647232L;
/*    */   
/*    */   public DragDetectEvent(Event e)
/*    */   {
/* 36 */     super(e);
/*    */   }
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/events/DragDetectEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */