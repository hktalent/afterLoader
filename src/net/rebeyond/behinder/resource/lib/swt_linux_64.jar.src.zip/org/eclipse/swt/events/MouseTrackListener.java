/*     */ package org.eclipse.swt.events;
/*     */ 
/*     */ import java.util.function.Consumer;
/*     */ import org.eclipse.swt.internal.SWTEventListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract interface MouseTrackListener
/*     */   extends SWTEventListener
/*     */ {
/*     */   public abstract void mouseEnter(MouseEvent paramMouseEvent);
/*     */   
/*     */   public abstract void mouseExit(MouseEvent paramMouseEvent);
/*     */   
/*     */   public abstract void mouseHover(MouseEvent paramMouseEvent);
/*     */   
/*     */   public static MouseTrackListener mouseEnterAdapter(Consumer<MouseEvent> c)
/*     */   {
/*  71 */     new MouseTrackAdapter()
/*     */     {
/*     */       public void mouseEnter(MouseEvent e) {
/*  74 */         this.val$c.accept(e);
/*     */       }
/*     */     };
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static MouseTrackListener mouseExitAdapter(Consumer<MouseEvent> c)
/*     */   {
/*  88 */     new MouseTrackAdapter()
/*     */     {
/*     */       public void mouseExit(MouseEvent e) {
/*  91 */         this.val$c.accept(e);
/*     */       }
/*     */     };
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static MouseTrackListener mouseHoverAdapter(Consumer<MouseEvent> c)
/*     */   {
/* 105 */     new MouseTrackAdapter()
/*     */     {
/*     */       public void mouseHover(MouseEvent e) {
/* 108 */         this.val$c.accept(e);
/*     */       }
/*     */     };
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/events/MouseTrackListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */