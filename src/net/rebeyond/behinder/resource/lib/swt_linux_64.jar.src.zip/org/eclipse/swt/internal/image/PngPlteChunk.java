/*     */ package org.eclipse.swt.internal.image;
/*     */ 
/*     */ import org.eclipse.swt.SWT;
/*     */ import org.eclipse.swt.graphics.PaletteData;
/*     */ import org.eclipse.swt.graphics.RGB;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class PngPlteChunk
/*     */   extends PngChunk
/*     */ {
/*     */   int paletteSize;
/*     */   
/*     */   PngPlteChunk(PaletteData palette)
/*     */   {
/*  22 */     super(palette.getRGBs().length * 3);
/*  23 */     this.paletteSize = (this.length / 3);
/*  24 */     setType(TYPE_PLTE);
/*  25 */     setPaletteData(palette);
/*  26 */     setCRC(computeCRC());
/*     */   }
/*     */   
/*     */   PngPlteChunk(byte[] reference) {
/*  30 */     super(reference);
/*  31 */     this.paletteSize = (this.length / 3);
/*     */   }
/*     */   
/*     */   int getChunkType()
/*     */   {
/*  36 */     return 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   int getPaletteSize()
/*     */   {
/*  43 */     return this.paletteSize;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   PaletteData getPaletteData()
/*     */   {
/*  53 */     RGB[] rgbs = new RGB[this.paletteSize];
/*     */     
/*     */ 
/*  56 */     for (int i = 0; i < rgbs.length; i++) {
/*  57 */       int offset = 8 + i * 3;
/*  58 */       int red = this.reference[offset] & 0xFF;
/*  59 */       int green = this.reference[(offset + 1)] & 0xFF;
/*  60 */       int blue = this.reference[(offset + 2)] & 0xFF;
/*  61 */       rgbs[i] = new RGB(red, green, blue);
/*     */     }
/*  63 */     return new PaletteData(rgbs);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   void setPaletteData(PaletteData palette)
/*     */   {
/*  71 */     RGB[] rgbs = palette.getRGBs();
/*  72 */     for (int i = 0; i < rgbs.length; i++) {
/*  73 */       int offset = 8 + i * 3;
/*  74 */       this.reference[offset] = ((byte)rgbs[i].red);
/*  75 */       this.reference[(offset + 1)] = ((byte)rgbs[i].green);
/*  76 */       this.reference[(offset + 2)] = ((byte)rgbs[i].blue);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void validate(PngFileReadState readState, PngIhdrChunk headerChunk)
/*     */   {
/*  87 */     if ((!readState.readIHDR) || (readState.readPLTE) || (readState.readTRNS) || (readState.readIDAT) || (readState.readIEND))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  93 */       SWT.error(40);
/*     */     } else {
/*  95 */       readState.readPLTE = true;
/*     */     }
/*     */     
/*  98 */     super.validate(readState, headerChunk);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 107 */     if (getLength() % 3 != 0) { SWT.error(40);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 112 */     if (1 << headerChunk.getBitDepth() < this.paletteSize) {
/* 113 */       SWT.error(40);
/*     */     }
/*     */     
/*     */ 
/* 117 */     if (256 < this.paletteSize) SWT.error(40);
/*     */   }
/*     */   
/*     */   void contributeToString(StringBuilder buffer)
/*     */   {
/* 122 */     buffer.append("\n\tPalette size:");
/* 123 */     buffer.append(this.paletteSize);
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/internal/image/PngPlteChunk.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */