/*    */ package org.eclipse.swt.graphics;
/*    */ 
/*    */ import java.util.EventObject;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ImageLoaderEvent
/*    */   extends EventObject
/*    */ {
/*    */   public ImageData imageData;
/*    */   public int incrementCount;
/*    */   public boolean endOfImage;
/*    */   static final long serialVersionUID = 3257284738325558065L;
/*    */   
/*    */   public ImageLoaderEvent(ImageLoader source, ImageData imageData, int incrementCount, boolean endOfImage)
/*    */   {
/* 71 */     super(source);
/* 72 */     this.imageData = imageData;
/* 73 */     this.incrementCount = incrementCount;
/* 74 */     this.endOfImage = endOfImage;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String toString()
/*    */   {
/* 85 */     return "ImageLoaderEvent {source=" + this.source + " imageData=" + this.imageData + " incrementCount=" + this.incrementCount + " endOfImage=" + this.endOfImage + "}";
/*    */   }
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/graphics/ImageLoaderEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */