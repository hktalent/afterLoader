/*     */ package org.eclipse.swt.widgets;
/*     */ 
/*     */ import org.eclipse.swt.graphics.Image;
/*     */ import org.eclipse.swt.graphics.Rectangle;
/*     */ import org.eclipse.swt.internal.Converter;
/*     */ import org.eclipse.swt.internal.DPIUtil;
/*     */ import org.eclipse.swt.internal.ImageList;
/*     */ import org.eclipse.swt.internal.gtk.GTK;
/*     */ import org.eclipse.swt.internal.gtk.GdkColor;
/*     */ import org.eclipse.swt.internal.gtk.GdkRGBA;
/*     */ import org.eclipse.swt.internal.gtk.GtkAllocation;
/*     */ import org.eclipse.swt.internal.gtk.OS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TabItem
/*     */   extends Item
/*     */ {
/*     */   long labelHandle;
/*     */   long imageHandle;
/*     */   long pageHandle;
/*     */   long provider;
/*     */   Control control;
/*     */   TabFolder parent;
/*     */   String toolTipText;
/*     */   
/*     */   public TabItem(TabFolder parent, int style)
/*     */   {
/*  73 */     super(parent, style);
/*  74 */     this.parent = parent;
/*  75 */     createWidget(parent.getItemCount());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TabItem(TabFolder parent, int style, int index)
/*     */   {
/* 111 */     super(parent, style);
/* 112 */     this.parent = parent;
/* 113 */     createWidget(index);
/*     */   }
/*     */   
/*     */   protected void checkSubclass()
/*     */   {
/* 118 */     if (!isValidSubclass()) error(43);
/*     */   }
/*     */   
/*     */   void createWidget(int index)
/*     */   {
/* 123 */     this.parent.createItem(this, index);
/* 124 */     setOrientation(true);
/* 125 */     hookEvents();
/* 126 */     register();
/* 127 */     this.text = "";
/*     */   }
/*     */   
/*     */   void deregister()
/*     */   {
/* 132 */     super.deregister();
/* 133 */     if (this.labelHandle != 0L) this.display.removeWidget(this.labelHandle);
/*     */   }
/*     */   
/*     */   void destroyWidget()
/*     */   {
/* 138 */     this.parent.destroyItem(this);
/* 139 */     releaseHandle();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Rectangle getBounds()
/*     */   {
/* 156 */     checkWidget();
/* 157 */     return DPIUtil.autoScaleDown(getBoundsInPixels());
/*     */   }
/*     */   
/*     */   Rectangle getBoundsInPixels() {
/* 161 */     checkWidget();
/* 162 */     GtkAllocation allocation = new GtkAllocation();
/* 163 */     GTK.gtk_widget_get_allocation(this.handle, allocation);
/* 164 */     int x = allocation.x;
/* 165 */     int y = allocation.y;
/* 166 */     int width = (this.state & 0x200) != 0 ? 0 : allocation.width;
/* 167 */     int height = (this.state & 0x400) != 0 ? 0 : allocation.height;
/* 168 */     if ((this.parent.style & 0x8000000) != 0) x = this.parent.getClientWidth() - width - x;
/* 169 */     return new Rectangle(x, y, width, height);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Control getControl()
/*     */   {
/* 185 */     checkWidget();
/* 186 */     return this.control;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TabFolder getParent()
/*     */   {
/* 200 */     checkWidget();
/* 201 */     return this.parent;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getToolTipText()
/*     */   {
/* 216 */     checkWidget();
/* 217 */     return this.toolTipText;
/*     */   }
/*     */   
/*     */   long gtk_enter_notify_event(long widget, long event)
/*     */   {
/* 222 */     this.parent.gtk_enter_notify_event(widget, event);
/* 223 */     return 0L;
/*     */   }
/*     */   
/*     */   long gtk_mnemonic_activate(long widget, long arg1)
/*     */   {
/* 228 */     return this.parent.gtk_mnemonic_activate(widget, arg1);
/*     */   }
/*     */   
/*     */   void hookEvents()
/*     */   {
/* 233 */     super.hookEvents();
/* 234 */     if (this.labelHandle != 0L) OS.g_signal_connect_closure_by_id(this.labelHandle, this.display.signalIds[32], 0, this.display.getClosure(32), false);
/* 235 */     OS.g_signal_connect_closure_by_id(this.handle, this.display.signalIds[14], 0, this.display.getClosure(14), false);
/*     */   }
/*     */   
/*     */   void register()
/*     */   {
/* 240 */     super.register();
/* 241 */     if (this.labelHandle != 0L) { this.display.addWidget(this.labelHandle, this);
/*     */     }
/*     */   }
/*     */   
/*     */   void release(boolean destroy)
/*     */   {
/* 247 */     if (GTK.GTK3)
/*     */     {
/*     */ 
/* 250 */       if ((this.control != null) && (!this.control.isDisposed())) {
/* 251 */         this.control.release(destroy);
/*     */       }
/*     */     }
/* 254 */     super.release(destroy);
/*     */   }
/*     */   
/*     */   void releaseHandle()
/*     */   {
/* 259 */     super.releaseHandle();
/* 260 */     this.pageHandle = (this.labelHandle = this.imageHandle = 0L);
/* 261 */     this.parent = null;
/*     */   }
/*     */   
/*     */   void releaseParent()
/*     */   {
/* 266 */     super.releaseParent();
/* 267 */     int index = this.parent.indexOf(this);
/* 268 */     if ((index == this.parent.getSelectionIndex()) && 
/* 269 */       (this.control != null)) { this.control.setVisible(false);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setControl(Control control)
/*     */   {
/* 289 */     checkWidget();
/* 290 */     if (control != null) {
/* 291 */       if (control.isDisposed()) error(5);
/* 292 */       if (control.parent != this.parent) { error(32);
/*     */       }
/*     */     }
/* 295 */     if ((control != null) && (GTK.GTK3))
/*     */     {
/* 297 */       Control.gtk_widget_reparent(control, this.pageHandle);
/*     */     }
/*     */     
/* 300 */     Control oldControl = this.control;Control newControl = control;
/* 301 */     this.control = control;
/* 302 */     int index = this.parent.indexOf(this);int selectionIndex = this.parent.getSelectionIndex();
/* 303 */     if ((index != selectionIndex) && 
/* 304 */       (newControl != null)) {
/* 305 */       if (selectionIndex != -1) {
/* 306 */         Control selectedControl = this.parent.getItem(selectionIndex).getControl();
/* 307 */         if (selectedControl == newControl) return;
/*     */       }
/* 309 */       newControl.setVisible(false);
/* 310 */       return;
/*     */     }
/*     */     
/* 313 */     if (newControl != null) {
/* 314 */       newControl.setBoundsInPixels(this.parent.getClientAreaInPixels());
/* 315 */       newControl.setVisible(true);
/*     */     }
/*     */     
/* 318 */     if ((oldControl != null) && (newControl != null) && (oldControl != newControl))
/* 319 */       oldControl.setVisible(false);
/*     */   }
/*     */   
/*     */   void setFontDescription(long font) {
/* 323 */     setFontDescription(this.labelHandle, font);
/* 324 */     setFontDescription(this.imageHandle, font);
/*     */   }
/*     */   
/*     */   void setForegroundRGBA(GdkRGBA rgba) {
/* 328 */     assert (GTK.GTK3) : "GTK3 code was run by GTK2";
/* 329 */     setForegroundGdkRGBA(this.labelHandle, rgba);
/* 330 */     setForegroundGdkRGBA(this.imageHandle, rgba);
/*     */   }
/*     */   
/*     */   void setForegroundGdkColor(GdkColor color) {
/* 334 */     assert (!GTK.GTK3) : "GTK2 code was run by GTK3";
/*     */     
/* 336 */     setForegroundColor(this.labelHandle, color, false);
/* 337 */     setForegroundColor(this.imageHandle, color, false);
/*     */   }
/*     */   
/*     */   void setForegroundGdkRGBA(long handle, GdkRGBA rgba) {
/* 341 */     assert (GTK.GTK3) : "GTK3 code was run by GTK2";
/* 342 */     GdkRGBA toSet = new GdkRGBA();
/* 343 */     if (rgba != null) {
/* 344 */       toSet = rgba;
/*     */     } else {
/* 346 */       toSet = this.display.COLOR_WIDGET_FOREGROUND_RGBA;
/*     */     }
/* 348 */     long context = GTK.gtk_widget_get_style_context(handle);
/*     */     
/* 350 */     String color = this.display.gtk_rgba_to_css_string(toSet);
/* 351 */     String css = "* {color: " + color + ";}";
/*     */     
/*     */ 
/* 354 */     this.parent.cssForeground = css;
/* 355 */     gtk_css_provider_load_from_css(context, css);
/*     */   }
/*     */   
/*     */ 
/*     */   void gtk_css_provider_load_from_css(long context, String css)
/*     */   {
/* 361 */     if (this.provider == 0L) {
/* 362 */       this.provider = GTK.gtk_css_provider_new();
/* 363 */       GTK.gtk_style_context_add_provider(context, this.provider, 600);
/* 364 */       OS.g_object_unref(this.provider);
/*     */     }
/* 366 */     GTK.gtk_css_provider_load_from_data(this.provider, Converter.wcsToMbcs(css, true), -1L, null);
/*     */   }
/*     */   
/*     */   public void setImage(Image image)
/*     */   {
/* 371 */     checkWidget();
/* 372 */     super.setImage(image);
/* 373 */     if (image != null) {
/* 374 */       ImageList imageList = this.parent.imageList;
/* 375 */       if (imageList == null) imageList = this.parent.imageList = new ImageList();
/* 376 */       int imageIndex = imageList.indexOf(image);
/* 377 */       if (imageIndex == -1) {
/* 378 */         imageIndex = imageList.add(image);
/*     */       } else {
/* 380 */         imageList.put(imageIndex, image);
/*     */       }
/* 382 */       long pixbuf = imageList.getPixbuf(imageIndex);
/* 383 */       gtk_image_set_from_pixbuf(this.imageHandle, pixbuf);
/* 384 */       GTK.gtk_widget_show(this.imageHandle);
/*     */     } else {
/* 386 */       gtk_image_set_from_pixbuf(this.imageHandle, 0L);
/* 387 */       GTK.gtk_widget_hide(this.imageHandle);
/*     */     }
/*     */   }
/*     */   
/*     */   void setOrientation(boolean create)
/*     */   {
/* 393 */     if (((this.parent.style & 0x4000000) != 0) || (!create)) {
/* 394 */       int dir = (this.parent.style & 0x4000000) != 0 ? 2 : 1;
/* 395 */       if (this.handle != 0L) GTK.gtk_widget_set_direction(this.handle, dir);
/* 396 */       if (this.labelHandle != 0L) GTK.gtk_widget_set_direction(this.labelHandle, dir);
/* 397 */       if (this.imageHandle != 0L) GTK.gtk_widget_set_direction(this.imageHandle, dir);
/* 398 */       if (this.pageHandle != 0L) { GTK.gtk_widget_set_direction(this.pageHandle, dir);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setText(String string)
/*     */   {
/* 430 */     checkWidget();
/* 431 */     if (string == null) error(4);
/* 432 */     super.setText(string);
/* 433 */     char[] chars = fixMnemonic(string);
/* 434 */     byte[] buffer = Converter.wcsToMbcs(chars, true);
/* 435 */     GTK.gtk_label_set_text_with_mnemonic(this.labelHandle, buffer);
/* 436 */     if (string.length() != 0) {
/* 437 */       GTK.gtk_widget_show(this.labelHandle);
/*     */     } else {
/* 439 */       GTK.gtk_widget_hide(this.labelHandle);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setToolTipText(String string)
/*     */   {
/* 469 */     checkWidget();
/* 470 */     Shell shell = this.parent._getShell();
/* 471 */     shell.setToolTipText(this.handle, string);
/* 472 */     this.toolTipText = string;
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/widgets/TabItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */