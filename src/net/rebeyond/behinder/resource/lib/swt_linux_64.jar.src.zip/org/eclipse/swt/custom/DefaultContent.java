/*     */ package org.eclipse.swt.custom;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.eclipse.swt.SWT;
/*     */ import org.eclipse.swt.internal.Compatibility;
/*     */ import org.eclipse.swt.widgets.TypedListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DefaultContent
/*     */   implements StyledTextContent
/*     */ {
/*  21 */   private static final String LineDelimiter = System.getProperty("line.separator");
/*     */   
/*  23 */   List<StyledTextListener> textListeners = new ArrayList();
/*  24 */   char[] textStore = new char[0];
/*  25 */   int gapStart = -1;
/*  26 */   int gapEnd = -1;
/*  27 */   int gapLine = -1;
/*  28 */   int highWatermark = 300;
/*  29 */   int lowWatermark = 50;
/*     */   
/*  31 */   int[][] lines = new int[50][2];
/*  32 */   int lineCount = 0;
/*  33 */   int expandExp = 1;
/*  34 */   int replaceExpandExp = 1;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   DefaultContent()
/*     */   {
/*  42 */     setText("");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void addLineIndex(int start, int length)
/*     */   {
/*  53 */     int size = this.lines.length;
/*  54 */     if (this.lineCount == size)
/*     */     {
/*  56 */       int[][] newLines = new int[size + Compatibility.pow2(this.expandExp)][2];
/*  57 */       System.arraycopy(this.lines, 0, newLines, 0, size);
/*  58 */       this.lines = newLines;
/*  59 */       this.expandExp += 1;
/*     */     }
/*  61 */     int[] range = { start, length };
/*  62 */     this.lines[this.lineCount] = range;
/*  63 */     this.lineCount += 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   int[][] addLineIndex(int start, int length, int[][] linesArray, int count)
/*     */   {
/*  77 */     int size = linesArray.length;
/*  78 */     int[][] newLines = linesArray;
/*  79 */     if (count == size) {
/*  80 */       newLines = new int[size + Compatibility.pow2(this.replaceExpandExp)][2];
/*  81 */       this.replaceExpandExp += 1;
/*  82 */       System.arraycopy(linesArray, 0, newLines, 0, size);
/*     */     }
/*  84 */     int[] range = { start, length };
/*  85 */     newLines[count] = range;
/*  86 */     return newLines;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addTextChangeListener(TextChangeListener listener)
/*     */   {
/* 103 */     if (listener == null) error(4);
/* 104 */     StyledTextListener typedListener = new StyledTextListener(listener);
/* 105 */     this.textListeners.add(typedListener);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void adjustGap(int position, int sizeHint, int line)
/*     */   {
/* 116 */     if (position == this.gapStart)
/*     */     {
/* 118 */       int size = this.gapEnd - this.gapStart - sizeHint;
/* 119 */       if ((this.lowWatermark <= size) && (size <= this.highWatermark))
/* 120 */         return;
/* 121 */     } else if ((position + sizeHint == this.gapStart) && (sizeHint < 0))
/*     */     {
/* 123 */       int size = this.gapEnd - this.gapStart - sizeHint;
/* 124 */       if ((this.lowWatermark <= size) && (size <= this.highWatermark))
/* 125 */         return;
/*     */     }
/* 127 */     moveAndResizeGap(position, sizeHint, line);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   void indexLines()
/*     */   {
/* 134 */     int start = 0;
/* 135 */     this.lineCount = 0;
/* 136 */     int textLength = this.textStore.length;
/*     */     
/* 138 */     for (int i = start; i < textLength; i++) {
/* 139 */       char ch = this.textStore[i];
/* 140 */       if (ch == '\r')
/*     */       {
/* 142 */         if (i + 1 < textLength) {
/* 143 */           ch = this.textStore[(i + 1)];
/* 144 */           if (ch == '\n') {
/* 145 */             i++;
/*     */           }
/*     */         }
/* 148 */         addLineIndex(start, i - start + 1);
/* 149 */         start = i + 1;
/* 150 */       } else if (ch == '\n') {
/* 151 */         addLineIndex(start, i - start + 1);
/* 152 */         start = i + 1;
/*     */       }
/*     */     }
/* 155 */     addLineIndex(start, i - start);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   boolean isDelimiter(char ch)
/*     */   {
/* 166 */     if (ch == '\r') return true;
/* 167 */     if (ch == '\n') return true;
/* 168 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean isValidReplace(int start, int replaceLength, String newText)
/*     */   {
/* 181 */     if (replaceLength == 0)
/*     */     {
/* 183 */       if (start == 0) return true;
/* 184 */       if (start == getCharCount()) return true;
/* 185 */       char before = getTextRange(start - 1, 1).charAt(0);
/* 186 */       if (before == '\r') {
/* 187 */         char after = getTextRange(start, 1).charAt(0);
/* 188 */         if (after == '\n') return false;
/*     */       }
/*     */     }
/*     */     else {
/* 192 */       char startChar = getTextRange(start, 1).charAt(0);
/* 193 */       if (startChar == '\n')
/*     */       {
/* 195 */         if (start != 0) {
/* 196 */           char before = getTextRange(start - 1, 1).charAt(0);
/* 197 */           if (before == '\r') return false;
/*     */         }
/*     */       }
/* 200 */       char endChar = getTextRange(start + replaceLength - 1, 1).charAt(0);
/* 201 */       if (endChar == '\r')
/*     */       {
/* 203 */         if (start + replaceLength != getCharCount()) {
/* 204 */           char after = getTextRange(start + replaceLength, 1).charAt(0);
/* 205 */           if (after == '\n') return false;
/*     */         }
/*     */       }
/*     */     }
/* 209 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   int[][] indexLines(int offset, int length, int numLines)
/*     */   {
/* 223 */     int[][] indexedLines = new int[numLines][2];
/* 224 */     int start = 0;
/* 225 */     int lineCount = 0;
/*     */     
/* 227 */     this.replaceExpandExp = 1;
/* 228 */     for (int i = start; i < length; i++) {
/* 229 */       int location = i + offset;
/* 230 */       if ((location < this.gapStart) || (location >= this.gapEnd))
/*     */       {
/*     */ 
/* 233 */         char ch = this.textStore[location];
/* 234 */         if (ch == '\r')
/*     */         {
/* 236 */           if (location + 1 < this.textStore.length) {
/* 237 */             ch = this.textStore[(location + 1)];
/* 238 */             if (ch == '\n') {
/* 239 */               i++;
/*     */             }
/*     */           }
/* 242 */           indexedLines = addLineIndex(start, i - start + 1, indexedLines, lineCount);
/* 243 */           lineCount++;
/* 244 */           start = i + 1;
/* 245 */         } else if (ch == '\n') {
/* 246 */           indexedLines = addLineIndex(start, i - start + 1, indexedLines, lineCount);
/* 247 */           lineCount++;
/* 248 */           start = i + 1;
/*     */         }
/*     */       }
/*     */     }
/* 252 */     int[][] newLines = new int[lineCount + 1][2];
/* 253 */     System.arraycopy(indexedLines, 0, newLines, 0, lineCount);
/* 254 */     int[] range = { start, i - start };
/* 255 */     newLines[lineCount] = range;
/* 256 */     return newLines;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void insert(int position, String text)
/*     */   {
/* 266 */     if (text.length() == 0) { return;
/*     */     }
/* 268 */     int startLine = getLineAtOffset(position);
/* 269 */     int change = text.length();
/* 270 */     boolean endInsert = position == getCharCount();
/* 271 */     adjustGap(position, change, startLine);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 276 */     int startLineOffset = getOffsetAtLine(startLine);
/*     */     
/*     */ 
/* 279 */     int startLineLength = getPhysicalLine(startLine).length();
/*     */     
/* 281 */     if (change > 0)
/*     */     {
/* 283 */       this.gapStart += change;
/* 284 */       for (int i = 0; i < text.length(); i++) {
/* 285 */         this.textStore[(position + i)] = text.charAt(i);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 290 */     int[][] newLines = indexLines(startLineOffset, startLineLength, 10);
/*     */     
/* 292 */     int numNewLines = newLines.length - 1;
/* 293 */     if (newLines[numNewLines][1] == 0)
/*     */     {
/* 295 */       if (endInsert)
/*     */       {
/*     */ 
/*     */ 
/* 299 */         numNewLines++;
/*     */       } else {
/* 301 */         numNewLines--;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 306 */     expandLinesBy(numNewLines);
/*     */     
/* 308 */     for (int i = this.lineCount - 1; i > startLine; i--) {
/* 309 */       this.lines[(i + numNewLines)] = this.lines[i];
/*     */     }
/*     */     
/* 312 */     for (int i = 0; i < numNewLines; i++) {
/* 313 */       newLines[i][0] += startLineOffset;
/* 314 */       this.lines[(startLine + i)] = newLines[i];
/*     */     }
/*     */     
/* 317 */     if (numNewLines < newLines.length) {
/* 318 */       newLines[numNewLines][0] += startLineOffset;
/* 319 */       this.lines[(startLine + numNewLines)] = newLines[numNewLines];
/*     */     }
/*     */     
/* 322 */     this.lineCount += numNewLines;
/* 323 */     this.gapLine = getLineAtPhysicalOffset(this.gapStart);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void moveAndResizeGap(int position, int size, int newGapLine)
/*     */   {
/* 336 */     char[] content = null;
/* 337 */     int oldSize = this.gapEnd - this.gapStart;
/*     */     int newSize;
/* 339 */     int newSize; if (size > 0) {
/* 340 */       newSize = this.highWatermark + size;
/*     */     } else {
/* 342 */       newSize = this.lowWatermark - size;
/*     */     }
/*     */     
/* 345 */     if (gapExists())
/*     */     {
/* 347 */       this.lines[this.gapLine][1] -= oldSize;
/*     */       
/* 349 */       for (int i = this.gapLine + 1; i < this.lineCount; i++) {
/* 350 */         this.lines[i][0] -= oldSize;
/*     */       }
/*     */     }
/*     */     
/* 354 */     if (newSize < 0) {
/* 355 */       if (oldSize > 0)
/*     */       {
/* 357 */         content = new char[this.textStore.length - oldSize];
/* 358 */         System.arraycopy(this.textStore, 0, content, 0, this.gapStart);
/* 359 */         System.arraycopy(this.textStore, this.gapEnd, content, this.gapStart, content.length - this.gapStart);
/* 360 */         this.textStore = content;
/*     */       }
/* 362 */       this.gapStart = (this.gapEnd = position);
/* 363 */       return;
/*     */     }
/* 365 */     content = new char[this.textStore.length + (newSize - oldSize)];
/* 366 */     int newGapStart = position;
/* 367 */     int newGapEnd = newGapStart + newSize;
/* 368 */     if (oldSize == 0) {
/* 369 */       System.arraycopy(this.textStore, 0, content, 0, newGapStart);
/* 370 */       System.arraycopy(this.textStore, newGapStart, content, newGapEnd, content.length - newGapEnd);
/* 371 */     } else if (newGapStart < this.gapStart) {
/* 372 */       int delta = this.gapStart - newGapStart;
/* 373 */       System.arraycopy(this.textStore, 0, content, 0, newGapStart);
/* 374 */       System.arraycopy(this.textStore, newGapStart, content, newGapEnd, delta);
/* 375 */       System.arraycopy(this.textStore, this.gapEnd, content, newGapEnd + delta, this.textStore.length - this.gapEnd);
/*     */     } else {
/* 377 */       int delta = newGapStart - this.gapStart;
/* 378 */       System.arraycopy(this.textStore, 0, content, 0, this.gapStart);
/* 379 */       System.arraycopy(this.textStore, this.gapEnd, content, this.gapStart, delta);
/* 380 */       System.arraycopy(this.textStore, this.gapEnd + delta, content, newGapEnd, content.length - newGapEnd);
/*     */     }
/* 382 */     this.textStore = content;
/* 383 */     this.gapStart = newGapStart;
/* 384 */     this.gapEnd = newGapEnd;
/*     */     
/*     */ 
/* 387 */     if (gapExists()) {
/* 388 */       this.gapLine = newGapLine;
/*     */       
/* 390 */       int gapLength = this.gapEnd - this.gapStart;
/* 391 */       this.lines[this.gapLine][1] += gapLength;
/*     */       
/* 393 */       for (int i = this.gapLine + 1; i < this.lineCount; i++) {
/* 394 */         this.lines[i][0] += gapLength;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   int lineCount(int startOffset, int length)
/*     */   {
/* 407 */     if (length == 0) {
/* 408 */       return 0;
/*     */     }
/* 410 */     int lineCount = 0;
/* 411 */     int count = 0;
/* 412 */     int i = startOffset;
/* 413 */     if (i >= this.gapStart) {
/* 414 */       i += this.gapEnd - this.gapStart;
/*     */     }
/* 416 */     while (count < length) {
/* 417 */       if ((i < this.gapStart) || (i >= this.gapEnd))
/*     */       {
/*     */ 
/* 420 */         char ch = this.textStore[i];
/* 421 */         if (ch == '\r')
/*     */         {
/* 423 */           if (i + 1 < this.textStore.length) {
/* 424 */             ch = this.textStore[(i + 1)];
/* 425 */             if (ch == '\n') {
/* 426 */               i++;
/* 427 */               count++;
/*     */             }
/*     */           }
/* 430 */           lineCount++;
/* 431 */         } else if (ch == '\n') {
/* 432 */           lineCount++;
/*     */         }
/* 434 */         count++;
/*     */       }
/* 436 */       i++;
/*     */     }
/* 438 */     return lineCount;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   int lineCount(String text)
/*     */   {
/* 448 */     int lineCount = 0;
/* 449 */     int length = text.length();
/* 450 */     for (int i = 0; i < length; i++) {
/* 451 */       char ch = text.charAt(i);
/* 452 */       if (ch == '\r') {
/* 453 */         if ((i + 1 < length) && (text.charAt(i + 1) == '\n')) {
/* 454 */           i++;
/*     */         }
/* 456 */         lineCount++;
/* 457 */       } else if (ch == '\n') {
/* 458 */         lineCount++;
/*     */       }
/*     */     }
/* 461 */     return lineCount;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getCharCount()
/*     */   {
/* 468 */     int length = this.gapEnd - this.gapStart;
/* 469 */     return this.textStore.length - length;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getLine(int index)
/*     */   {
/* 483 */     if ((index >= this.lineCount) || (index < 0)) error(5);
/* 484 */     int start = this.lines[index][0];
/* 485 */     int length = this.lines[index][1];
/* 486 */     int end = start + length - 1;
/* 487 */     if ((!gapExists()) || (end < this.gapStart) || (start >= this.gapEnd))
/*     */     {
/* 489 */       while ((length - 1 >= 0) && (isDelimiter(this.textStore[(start + length - 1)]))) {
/* 490 */         length--;
/*     */       }
/* 492 */       return new String(this.textStore, start, length);
/*     */     }
/*     */     
/* 495 */     StringBuilder buf = new StringBuilder();
/* 496 */     int gapLength = this.gapEnd - this.gapStart;
/* 497 */     buf.append(this.textStore, start, this.gapStart - start);
/* 498 */     buf.append(this.textStore, this.gapEnd, length - gapLength - (this.gapStart - start));
/* 499 */     length = buf.length();
/* 500 */     while ((length - 1 >= 0) && (isDelimiter(buf.charAt(length - 1)))) {
/* 501 */       length--;
/*     */     }
/* 503 */     return buf.toString().substring(0, length);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getLineDelimiter()
/*     */   {
/* 517 */     return LineDelimiter;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   String getFullLine(int index)
/*     */   {
/* 526 */     int start = this.lines[index][0];
/* 527 */     int length = this.lines[index][1];
/* 528 */     int end = start + length - 1;
/* 529 */     if ((!gapExists()) || (end < this.gapStart) || (start >= this.gapEnd))
/*     */     {
/* 531 */       return new String(this.textStore, start, length);
/*     */     }
/*     */     
/* 534 */     StringBuilder buffer = new StringBuilder();
/* 535 */     int gapLength = this.gapEnd - this.gapStart;
/* 536 */     buffer.append(this.textStore, start, this.gapStart - start);
/* 537 */     buffer.append(this.textStore, this.gapEnd, length - gapLength - (this.gapStart - start));
/* 538 */     return buffer.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   String getPhysicalLine(int index)
/*     */   {
/* 549 */     int start = this.lines[index][0];
/* 550 */     int length = this.lines[index][1];
/* 551 */     return getPhysicalText(start, length);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getLineCount()
/*     */   {
/* 558 */     return this.lineCount;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getLineAtOffset(int charPosition)
/*     */   {
/* 572 */     if ((charPosition > getCharCount()) || (charPosition < 0)) error(5);
/*     */     int position;
/* 574 */     int position; if (charPosition < this.gapStart)
/*     */     {
/* 576 */       position = charPosition;
/*     */     }
/*     */     else {
/* 579 */       position = charPosition + (this.gapEnd - this.gapStart);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 585 */     if (this.lineCount > 0) {
/* 586 */       int lastLine = this.lineCount - 1;
/* 587 */       if (position == this.lines[lastLine][0] + this.lines[lastLine][1]) {
/* 588 */         return lastLine;
/*     */       }
/*     */     }
/* 591 */     int high = this.lineCount;
/* 592 */     int low = -1;
/* 593 */     int index = this.lineCount;
/* 594 */     while (high - low > 1) {
/* 595 */       index = (high + low) / 2;
/* 596 */       int lineStart = this.lines[index][0];
/* 597 */       int lineEnd = lineStart + this.lines[index][1] - 1;
/* 598 */       if (position <= lineStart) {
/* 599 */         high = index;
/* 600 */       } else { if (position <= lineEnd) {
/* 601 */           high = index;
/* 602 */           break;
/*     */         }
/* 604 */         low = index;
/*     */       }
/*     */     }
/* 607 */     return high;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   int getLineAtPhysicalOffset(int position)
/*     */   {
/* 617 */     int high = this.lineCount;
/* 618 */     int low = -1;
/* 619 */     int index = this.lineCount;
/* 620 */     while (high - low > 1) {
/* 621 */       index = (high + low) / 2;
/* 622 */       int lineStart = this.lines[index][0];
/* 623 */       int lineEnd = lineStart + this.lines[index][1] - 1;
/* 624 */       if (position <= lineStart) {
/* 625 */         high = index;
/* 626 */       } else { if (position <= lineEnd) {
/* 627 */           high = index;
/* 628 */           break;
/*     */         }
/* 630 */         low = index;
/*     */       }
/*     */     }
/* 633 */     return high;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getOffsetAtLine(int lineIndex)
/*     */   {
/* 648 */     if (lineIndex == 0) return 0;
/* 649 */     if ((lineIndex >= this.lineCount) || (lineIndex < 0)) error(5);
/* 650 */     int start = this.lines[lineIndex][0];
/* 651 */     if (start > this.gapEnd) {
/* 652 */       return start - (this.gapEnd - this.gapStart);
/*     */     }
/* 654 */     return start;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void expandLinesBy(int numLines)
/*     */   {
/* 664 */     int size = this.lines.length;
/* 665 */     if (size - this.lineCount >= numLines) {
/* 666 */       return;
/*     */     }
/* 668 */     int[][] newLines = new int[size + Math.max(10, numLines)][2];
/* 669 */     System.arraycopy(this.lines, 0, newLines, 0, size);
/* 670 */     this.lines = newLines;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void error(int code)
/*     */   {
/* 679 */     SWT.error(code);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   boolean gapExists()
/*     */   {
/* 688 */     return this.gapStart != this.gapEnd;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   String getPhysicalText(int start, int length)
/*     */   {
/* 700 */     return new String(this.textStore, start, length);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getTextRange(int start, int length)
/*     */   {
/* 713 */     if (this.textStore == null)
/* 714 */       return "";
/* 715 */     if (length == 0)
/* 716 */       return "";
/* 717 */     int end = start + length;
/* 718 */     if ((!gapExists()) || (end < this.gapStart))
/* 719 */       return new String(this.textStore, start, length);
/* 720 */     if (this.gapStart < start) {
/* 721 */       int gapLength = this.gapEnd - this.gapStart;
/* 722 */       return new String(this.textStore, start + gapLength, length);
/*     */     }
/* 724 */     StringBuilder buf = new StringBuilder();
/* 725 */     buf.append(this.textStore, start, this.gapStart - start);
/* 726 */     buf.append(this.textStore, this.gapEnd, end - this.gapStart);
/* 727 */     return buf.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeTextChangeListener(TextChangeListener listener)
/*     */   {
/* 741 */     if (listener == null) error(4);
/* 742 */     for (int i = 0; i < this.textListeners.size(); i++) {
/* 743 */       TypedListener typedListener = (TypedListener)this.textListeners.get(i);
/* 744 */       if (typedListener.getEventListener() == listener) {
/* 745 */         this.textListeners.remove(i);
/* 746 */         break;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void replaceTextRange(int start, int replaceLength, String newText)
/*     */   {
/* 780 */     if (!isValidReplace(start, replaceLength, newText)) { SWT.error(5);
/*     */     }
/*     */     
/* 783 */     StyledTextEvent event = new StyledTextEvent(this);
/* 784 */     event.type = 3003;
/* 785 */     event.start = start;
/* 786 */     event.replaceLineCount = lineCount(start, replaceLength);
/* 787 */     event.text = newText;
/* 788 */     event.newLineCount = lineCount(newText);
/* 789 */     event.replaceCharCount = replaceLength;
/* 790 */     event.newCharCount = newText.length();
/* 791 */     sendTextEvent(event);
/*     */     
/*     */ 
/* 794 */     delete(start, replaceLength, event.replaceLineCount + 1);
/*     */     
/* 796 */     insert(start, newText);
/*     */     
/* 798 */     event = new StyledTextEvent(this);
/* 799 */     event.type = 3006;
/* 800 */     sendTextEvent(event);
/*     */   }
/*     */   
/*     */ 
/*     */   void sendTextEvent(StyledTextEvent event)
/*     */   {
/* 806 */     for (int i = 0; i < this.textListeners.size(); i++) {
/* 807 */       ((StyledTextListener)this.textListeners.get(i)).handleEvent(event);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setText(String text)
/*     */   {
/* 819 */     this.textStore = text.toCharArray();
/* 820 */     this.gapStart = -1;
/* 821 */     this.gapEnd = -1;
/* 822 */     this.expandExp = 1;
/* 823 */     indexLines();
/* 824 */     StyledTextEvent event = new StyledTextEvent(this);
/* 825 */     event.type = 3004;
/* 826 */     event.text = "";
/* 827 */     sendTextEvent(event);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void delete(int position, int length, int numLines)
/*     */   {
/* 837 */     if (length == 0) { return;
/*     */     }
/* 839 */     int startLine = getLineAtOffset(position);
/* 840 */     int startLineOffset = getOffsetAtLine(startLine);
/* 841 */     int endLine = getLineAtOffset(position + length);
/*     */     
/* 843 */     String endText = "";
/* 844 */     boolean splittingDelimiter = false;
/* 845 */     if (position + length < getCharCount()) {
/* 846 */       endText = getTextRange(position + length - 1, 2);
/* 847 */       if ((endText.charAt(0) == '\r') && (endText.charAt(1) == '\n')) {
/* 848 */         splittingDelimiter = true;
/*     */       }
/*     */     }
/*     */     
/* 852 */     adjustGap(position + length, -length, startLine);
/* 853 */     int[][] oldLines = indexLines(position, length + (this.gapEnd - this.gapStart), numLines);
/*     */     
/*     */ 
/*     */ 
/* 857 */     if (position + length == this.gapStart) {
/* 858 */       this.gapStart -= length;
/*     */     } else {
/* 860 */       this.gapEnd += length;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 865 */     int j = position;
/* 866 */     boolean eol = false;
/* 867 */     while ((j < this.textStore.length) && (!eol)) {
/* 868 */       if ((j < this.gapStart) || (j >= this.gapEnd)) {
/* 869 */         char ch = this.textStore[j];
/* 870 */         if (isDelimiter(ch)) {
/* 871 */           if ((j + 1 < this.textStore.length) && 
/* 872 */             (ch == '\r') && (this.textStore[(j + 1)] == '\n')) {
/* 873 */             j++;
/*     */           }
/*     */           
/* 876 */           eol = true;
/*     */         }
/*     */       }
/* 879 */       j++;
/*     */     }
/*     */     
/* 882 */     this.lines[startLine][1] = (position - startLineOffset + (j - position));
/*     */     
/* 884 */     int numOldLines = oldLines.length - 1;
/* 885 */     if (splittingDelimiter) { numOldLines--;
/*     */     }
/*     */     
/* 888 */     for (int i = endLine + 1; i < this.lineCount; i++) {
/* 889 */       this.lines[(i - numOldLines)] = this.lines[i];
/*     */     }
/* 891 */     this.lineCount -= numOldLines;
/* 892 */     this.gapLine = getLineAtPhysicalOffset(this.gapStart);
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/custom/DefaultContent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */