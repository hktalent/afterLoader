/*     */ package org.eclipse.swt.widgets;
/*     */ 
/*     */ import java.io.File;
/*     */ import org.eclipse.swt.internal.C;
/*     */ import org.eclipse.swt.internal.Converter;
/*     */ import org.eclipse.swt.internal.gtk.GDK;
/*     */ import org.eclipse.swt.internal.gtk.GTK;
/*     */ import org.eclipse.swt.internal.gtk.OS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FileDialog
/*     */   extends Dialog
/*     */ {
/*  41 */   String[] filterNames = new String[0];
/*  42 */   String[] filterExtensions = new String[0];
/*  43 */   String filterPath = "";
/*  44 */   String fileName = "";
/*  45 */   String[] fileNames = new String[0];
/*  46 */   String fullPath = "";
/*  47 */   int filterIndex = -1;
/*  48 */   boolean overwrite = false;
/*     */   boolean uriMode;
/*     */   long handle;
/*  51 */   static final char SEPARATOR = File.separatorChar;
/*     */   
/*     */ 
/*     */ 
/*     */   static final char EXTENSION_SEPARATOR = ';';
/*     */   
/*     */ 
/*     */ 
/*     */   static final char FILE_EXTENSION_SEPARATOR = '.';
/*     */   
/*     */ 
/*     */ 
/*     */   private static final int PATH_MAX = 1024;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public FileDialog(Shell parent)
/*     */   {
/*  70 */     this(parent, 65536);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FileDialog(Shell parent, int style)
/*     */   {
/* 101 */     super(parent, checkStyle(parent, style));
/* 102 */     checkSubclass();
/*     */   }
/*     */   
/*     */   String computeResultChooserDialog() {
/* 106 */     this.fullPath = null;
/* 107 */     if ((this.style & 0x2) != 0) {
/* 108 */       long list = 0L;
/* 109 */       if (this.uriMode) {
/* 110 */         list = GTK.gtk_file_chooser_get_uris(this.handle);
/*     */       } else {
/* 112 */         list = GTK.gtk_file_chooser_get_filenames(this.handle);
/*     */       }
/* 114 */       int listLength = OS.g_slist_length(list);
/* 115 */       this.fileNames = new String[listLength];
/* 116 */       long current = list;
/* 117 */       int writePos = 0;
/* 118 */       for (int i = 0; i < listLength; i++) {
/* 119 */         long name = OS.g_slist_data(current);
/* 120 */         long utf8Ptr = 0L;
/* 121 */         if (this.uriMode) {
/* 122 */           utf8Ptr = name;
/*     */         } else {
/* 124 */           utf8Ptr = OS.g_filename_to_utf8(name, -1L, null, null, null);
/* 125 */           if (utf8Ptr == 0L) utf8Ptr = OS.g_filename_display_name(name);
/*     */         }
/* 127 */         if (name != utf8Ptr) OS.g_free(name);
/* 128 */         if (utf8Ptr != 0L) {
/* 129 */           long[] items_written = new long[1];
/* 130 */           long utf16Ptr = OS.g_utf8_to_utf16(utf8Ptr, -1L, null, items_written, null);
/* 131 */           OS.g_free(utf8Ptr);
/* 132 */           if (utf16Ptr != 0L) {
/* 133 */             int clength = (int)items_written[0];
/* 134 */             char[] chars = new char[clength];
/* 135 */             C.memmove(chars, utf16Ptr, clength * 2);
/* 136 */             OS.g_free(utf16Ptr);
/* 137 */             this.fullPath = new String(chars);
/* 138 */             this.fileNames[(writePos++)] = this.fullPath.substring(this.fullPath.lastIndexOf(SEPARATOR) + 1);
/*     */           }
/*     */         }
/* 141 */         current = OS.g_slist_next(current);
/*     */       }
/* 143 */       if ((writePos != 0) && (writePos != listLength)) {
/* 144 */         String[] validFileNames = new String[writePos];
/* 145 */         System.arraycopy(this.fileNames, 0, validFileNames, 0, writePos);
/* 146 */         this.fileNames = validFileNames;
/*     */       }
/* 148 */       OS.g_slist_free(list);
/*     */     } else {
/* 150 */       long utf8Ptr = 0L;
/* 151 */       if (this.uriMode) {
/* 152 */         utf8Ptr = GTK.gtk_file_chooser_get_uri(this.handle);
/*     */       } else {
/* 154 */         long path = GTK.gtk_file_chooser_get_filename(this.handle);
/* 155 */         if (path != 0L) {
/* 156 */           utf8Ptr = OS.g_filename_to_utf8(path, -1L, null, null, null);
/* 157 */           if (utf8Ptr == 0L) utf8Ptr = OS.g_filename_display_name(path);
/* 158 */           if (path != utf8Ptr) OS.g_free(path);
/*     */         }
/*     */       }
/* 161 */       if (utf8Ptr != 0L) {
/* 162 */         long[] items_written = new long[1];
/* 163 */         long utf16Ptr = OS.g_utf8_to_utf16(utf8Ptr, -1L, null, items_written, null);
/* 164 */         OS.g_free(utf8Ptr);
/* 165 */         if (utf16Ptr != 0L) {
/* 166 */           int clength = (int)items_written[0];
/* 167 */           char[] chars = new char[clength];
/* 168 */           C.memmove(chars, utf16Ptr, clength * 2);
/* 169 */           OS.g_free(utf16Ptr);
/* 170 */           this.fullPath = new String(chars);
/* 171 */           this.fileNames = new String[1];
/* 172 */           this.fileNames[0] = this.fullPath.substring(this.fullPath.lastIndexOf(SEPARATOR) + 1);
/*     */         }
/*     */       }
/*     */     }
/* 176 */     this.filterIndex = -1;
/* 177 */     long filter = GTK.gtk_file_chooser_get_filter(this.handle);
/* 178 */     if (filter != 0L) {
/* 179 */       long filterNamePtr = GTK.gtk_file_filter_get_name(filter);
/* 180 */       if (filterNamePtr != 0L) {
/* 181 */         int length = C.strlen(filterNamePtr);
/* 182 */         byte[] buffer = new byte[length];
/* 183 */         C.memmove(buffer, filterNamePtr, length);
/*     */         
/* 185 */         String filterName = new String(Converter.mbcsToWcs(buffer));
/* 186 */         for (int i = 0; i < this.filterExtensions.length; i++) {
/* 187 */           if (this.filterNames.length > 0) {
/* 188 */             if (this.filterNames[i].equals(filterName)) {
/* 189 */               this.filterIndex = i;
/* 190 */               break;
/*     */             }
/*     */           }
/* 193 */           else if (this.filterExtensions[i].equals(filterName)) {
/* 194 */             this.filterIndex = i;
/* 195 */             break;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 201 */     if (this.fullPath != null) {
/* 202 */       int separatorIndex = this.fullPath.lastIndexOf(SEPARATOR);
/* 203 */       this.fileName = this.fullPath.substring(separatorIndex + 1);
/* 204 */       this.filterPath = this.fullPath.substring(0, separatorIndex);
/*     */     }
/* 206 */     return this.fullPath;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getFileName()
/*     */   {
/* 217 */     return this.fileName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] getFileNames()
/*     */   {
/* 226 */     return this.fileNames;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] getFilterExtensions()
/*     */   {
/* 235 */     return this.filterExtensions;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getFilterIndex()
/*     */   {
/* 254 */     return this.filterIndex;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] getFilterNames()
/*     */   {
/* 263 */     return this.filterNames;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getFilterPath()
/*     */   {
/* 275 */     return this.filterPath;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getOverwrite()
/*     */   {
/* 287 */     return this.overwrite;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 302 */   public String open() { return openChooserDialog(); }
/*     */   
/*     */   String openChooserDialog() {
/* 305 */     byte[] titleBytes = Converter.wcsToMbcs(this.title, true);
/* 306 */     int action = (this.style & 0x2000) != 0 ? 1 : 0;
/*     */     
/*     */ 
/* 309 */     long shellHandle = this.parent.topHandle();
/* 310 */     Display display = this.parent != null ? this.parent.getDisplay() : Display.getCurrent();
/* 311 */     if (display.getDismissalAlignment() == 131072) {
/* 312 */       if (GTK.GTK3) {
/* 313 */         this.handle = GTK.gtk_file_chooser_dialog_new(titleBytes, shellHandle, action, GTK.GTK_NAMED_LABEL_CANCEL, -6, GTK.GTK_NAMED_LABEL_OK, -5, 0L);
/*     */       } else {
/* 315 */         this.handle = GTK.gtk_file_chooser_dialog_new(titleBytes, shellHandle, action, GTK.GTK_STOCK_CANCEL(), -6, GTK.GTK_STOCK_OK(), -5, 0L);
/*     */       }
/*     */     }
/* 318 */     else if (GTK.GTK3) {
/* 319 */       this.handle = GTK.gtk_file_chooser_dialog_new(titleBytes, shellHandle, action, GTK.GTK_NAMED_LABEL_OK, -5, GTK.GTK_NAMED_LABEL_CANCEL, -6, 0L);
/*     */     } else {
/* 321 */       this.handle = GTK.gtk_file_chooser_dialog_new(titleBytes, shellHandle, action, GTK.GTK_STOCK_OK(), -5, GTK.GTK_STOCK_CANCEL(), -6, 0L);
/*     */     }
/*     */     
/* 324 */     if (this.handle == 0L) error(2);
/* 325 */     GTK.gtk_window_set_modal(this.handle, true);
/* 326 */     long group = GTK.gtk_window_get_group(0L);
/* 327 */     GTK.gtk_window_group_add_window(group, this.handle);
/* 328 */     long pixbufs = GTK.gtk_window_get_icon_list(shellHandle);
/* 329 */     if (pixbufs != 0L) {
/* 330 */       GTK.gtk_window_set_icon_list(this.handle, pixbufs);
/* 331 */       OS.g_list_free(pixbufs);
/*     */     }
/* 333 */     if (this.uriMode) {
/* 334 */       GTK.gtk_file_chooser_set_local_only(this.handle, false);
/*     */     }
/* 336 */     presetChooserDialog();
/* 337 */     display.addIdleProc();
/* 338 */     String answer = null;
/* 339 */     Dialog oldModal = null;
/* 340 */     if (GTK.gtk_window_get_modal(this.handle)) {
/* 341 */       oldModal = display.getModalDialog();
/* 342 */       display.setModalDialog(this);
/*     */     }
/* 344 */     int signalId = 0;
/* 345 */     long hookId = 0L;
/* 346 */     if ((this.style & 0x4000000) != 0) {
/* 347 */       signalId = OS.g_signal_lookup(OS.map, GTK.GTK_TYPE_WIDGET());
/* 348 */       hookId = OS.g_signal_add_emission_hook(signalId, 0, display.emissionProc, this.handle, 0L);
/*     */     }
/* 350 */     display.sendPreExternalEventDispatchEvent();
/* 351 */     int response = GTK.gtk_dialog_run(this.handle);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 358 */     GDK.gdk_threads_leave();
/* 359 */     display.sendPostExternalEventDispatchEvent();
/* 360 */     if ((this.style & 0x4000000) != 0) {
/* 361 */       OS.g_signal_remove_emission_hook(signalId, hookId);
/*     */     }
/* 363 */     if (GTK.gtk_window_get_modal(this.handle)) {
/* 364 */       display.setModalDialog(oldModal);
/*     */     }
/* 366 */     if (response == -5) {
/* 367 */       answer = computeResultChooserDialog();
/*     */     }
/* 369 */     display.removeIdleProc();
/* 370 */     GTK.gtk_widget_destroy(this.handle);
/* 371 */     return answer;
/*     */   }
/*     */   
/*     */   void presetChooserDialog() {
/* 375 */     if ((this.style & 0x2002) == 2) {
/* 376 */       GTK.gtk_file_chooser_set_select_multiple(this.handle, true);
/*     */     }
/* 378 */     if (this.filterPath == null) this.filterPath = "";
/* 379 */     if (this.fileName == null) this.fileName = "";
/* 380 */     if ((this.style & 0x2000) != 0) {
/* 381 */       if (this.fileName.equals("")) {
/* 382 */         this.fileName = "Untitled";
/*     */       }
/* 384 */       if (this.filterPath.length() > 0) {
/* 385 */         if (this.uriMode) {
/* 386 */           byte[] buffer = Converter.wcsToMbcs(this.filterPath, true);
/* 387 */           GTK.gtk_file_chooser_set_current_folder_uri(this.handle, buffer);
/*     */         }
/*     */         else {
/* 390 */           byte[] buffer = Converter.wcsToMbcs(SEPARATOR + this.filterPath, true);
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 396 */           if (OS.IsAIX) {
/* 397 */             byte[] outputBuffer = new byte['Ѐ'];
/* 398 */             long ptr = OS.realpath(buffer, outputBuffer);
/* 399 */             if (ptr != 0L) {
/* 400 */               GTK.gtk_file_chooser_set_current_folder(this.handle, ptr);
/*     */             }
/*     */             
/*     */           }
/*     */           else
/*     */           {
/* 406 */             long ptr = OS.realpath(buffer, null);
/* 407 */             if (ptr != 0L) {
/* 408 */               GTK.gtk_file_chooser_set_current_folder(this.handle, ptr);
/* 409 */               OS.g_free(ptr);
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/* 414 */       if (this.fileName.length() > 0) {
/* 415 */         StringBuilder filenameWithExt = new StringBuilder();
/* 416 */         filenameWithExt.append(this.fileName);
/* 417 */         if ((this.fileName.lastIndexOf('.') == -1) && (this.filterExtensions.length != 0))
/*     */         {
/* 419 */           String selectedFilter = null;
/* 420 */           if (this.filterIndex == -1) {
/* 421 */             selectedFilter = this.filterExtensions[0];
/*     */           } else {
/* 423 */             selectedFilter = this.filterExtensions[this.filterIndex];
/*     */           }
/* 425 */           String extFilter = null;
/* 426 */           int index = selectedFilter.indexOf(';');
/* 427 */           if (index == -1) {
/* 428 */             extFilter = selectedFilter.trim();
/*     */           } else {
/* 430 */             extFilter = selectedFilter.substring(0, index).trim();
/*     */           }
/*     */           
/* 433 */           int separatorIndex = extFilter.lastIndexOf('.');
/* 434 */           String extension = extFilter.substring(separatorIndex);
/*     */           
/* 436 */           if (!isGlobPattern(extension)) {
/* 437 */             filenameWithExt.append(extension);
/*     */           }
/*     */         }
/* 440 */         byte[] buffer = Converter.wcsToMbcs(filenameWithExt.toString(), true);
/* 441 */         GTK.gtk_file_chooser_set_current_name(this.handle, buffer);
/*     */       }
/*     */     } else {
/* 444 */       StringBuilder stringBuilder = new StringBuilder();
/* 445 */       if (this.filterPath.length() > 0) {
/* 446 */         if (!this.uriMode)
/*     */         {
/* 448 */           stringBuilder.append(SEPARATOR);
/*     */         }
/* 450 */         stringBuilder.append(this.filterPath);
/* 451 */         stringBuilder.append(SEPARATOR);
/*     */       }
/* 453 */       if (this.fileName.length() > 0) {
/* 454 */         stringBuilder.append(this.fileName);
/*     */       }
/* 456 */       byte[] buffer = Converter.wcsToMbcs(stringBuilder.toString(), true);
/* 457 */       if (this.uriMode) {
/* 458 */         GTK.gtk_file_chooser_set_uri(this.handle, buffer);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       }
/* 465 */       else if (OS.IsAIX) {
/* 466 */         byte[] outputBuffer = new byte['Ѐ'];
/* 467 */         long ptr = OS.realpath(buffer, outputBuffer);
/* 468 */         if (ptr != 0L) {
/* 469 */           if (this.fileName.length() > 0) {
/* 470 */             GTK.gtk_file_chooser_set_filename(this.handle, ptr);
/*     */           } else {
/* 472 */             GTK.gtk_file_chooser_set_current_folder(this.handle, ptr);
/*     */           }
/*     */           
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 479 */         long ptr = OS.realpath(buffer, null);
/* 480 */         if (ptr != 0L) {
/* 481 */           if (this.fileName.length() > 0) {
/* 482 */             GTK.gtk_file_chooser_set_filename(this.handle, ptr);
/*     */           } else {
/* 484 */             GTK.gtk_file_chooser_set_current_folder(this.handle, ptr);
/*     */           }
/* 486 */           OS.g_free(ptr);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 493 */     if ((this.style & 0x2000) != 0) {
/* 494 */       GTK.gtk_file_chooser_set_do_overwrite_confirmation(this.handle, this.overwrite);
/*     */     }
/*     */     
/*     */ 
/* 498 */     if (this.filterNames == null) this.filterNames = new String[0];
/* 499 */     if (this.filterExtensions == null) this.filterExtensions = new String[0];
/* 500 */     long initialFilter = 0L;
/* 501 */     for (int i = 0; i < this.filterExtensions.length; i++) {
/* 502 */       if (this.filterExtensions[i] != null) {
/* 503 */         long filter = GTK.gtk_file_filter_new();
/* 504 */         if ((this.filterNames.length > i) && (this.filterNames[i] != null)) {
/* 505 */           byte[] name = Converter.wcsToMbcs(this.filterNames[i], true);
/* 506 */           GTK.gtk_file_filter_set_name(filter, name);
/*     */         } else {
/* 508 */           byte[] name = Converter.wcsToMbcs(this.filterExtensions[i], true);
/* 509 */           GTK.gtk_file_filter_set_name(filter, name);
/*     */         }
/* 511 */         int start = 0;
/* 512 */         int index = this.filterExtensions[i].indexOf(';');
/* 513 */         while (index != -1) {
/* 514 */           String current = this.filterExtensions[i].substring(start, index);
/* 515 */           byte[] filterString = Converter.wcsToMbcs(current, true);
/* 516 */           GTK.gtk_file_filter_add_pattern(filter, filterString);
/* 517 */           start = index + 1;
/* 518 */           index = this.filterExtensions[i].indexOf(';', start);
/*     */         }
/* 520 */         String current = this.filterExtensions[i].substring(start);
/* 521 */         byte[] filterString = Converter.wcsToMbcs(current, true);
/* 522 */         GTK.gtk_file_filter_add_pattern(filter, filterString);
/* 523 */         GTK.gtk_file_chooser_add_filter(this.handle, filter);
/* 524 */         if (i == this.filterIndex) {
/* 525 */           initialFilter = filter;
/*     */         }
/*     */       }
/*     */     }
/* 529 */     if (initialFilter != 0L) {
/* 530 */       GTK.gtk_file_chooser_set_filter(this.handle, initialFilter);
/*     */     }
/* 532 */     this.fullPath = null;
/* 533 */     this.fileNames = new String[0];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean isGlobPattern(String extension)
/*     */   {
/* 547 */     if ((extension.contains("*")) || 
/* 548 */       (extension.contains("?")) || (
/* 549 */       (extension.contains("[")) && (extension.contains("]")))) {
/* 550 */       return true;
/*     */     }
/* 552 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFileName(String string)
/*     */   {
/* 563 */     this.fileName = string;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFilterExtensions(String[] extensions)
/*     */   {
/* 591 */     this.filterExtensions = extensions;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFilterIndex(int index)
/*     */   {
/* 610 */     this.filterIndex = index;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFilterNames(String[] names)
/*     */   {
/* 627 */     this.filterNames = names;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFilterPath(String string)
/*     */   {
/* 647 */     this.filterPath = string;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setOverwrite(boolean overwrite)
/*     */   {
/* 660 */     this.overwrite = overwrite;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void setURIMode(boolean uriMode)
/*     */   {
/* 671 */     this.uriMode = uriMode;
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/widgets/FileDialog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */