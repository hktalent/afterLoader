/*    */ package org.eclipse.swt.browser;
/*    */ 
/*    */ import java.util.function.Consumer;
/*    */ import org.eclipse.swt.internal.SWTEventListener;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract interface ProgressListener
/*    */   extends SWTEventListener
/*    */ {
/*    */   public abstract void changed(ProgressEvent paramProgressEvent);
/*    */   
/*    */   public abstract void completed(ProgressEvent paramProgressEvent);
/*    */   
/*    */   public static ProgressListener changedAdapter(Consumer<ProgressEvent> c)
/*    */   {
/* 75 */     new ProgressAdapter()
/*    */     {
/*    */       public void changed(ProgressEvent e) {
/* 78 */         this.val$c.accept(e);
/*    */       }
/*    */     };
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static ProgressListener completedAdapter(Consumer<ProgressEvent> c)
/*    */   {
/* 92 */     new ProgressAdapter()
/*    */     {
/*    */       public void completed(ProgressEvent e) {
/* 95 */         this.val$c.accept(e);
/*    */       }
/*    */     };
/*    */   }
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/browser/ProgressListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */