/*    */ package org.eclipse.swt.events;
/*    */ 
/*    */ import org.eclipse.swt.widgets.Event;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class HelpEvent
/*    */   extends TypedEvent
/*    */ {
/*    */   static final long serialVersionUID = 3257001038606251315L;
/*    */   
/*    */   public HelpEvent(Event e)
/*    */   {
/* 35 */     super(e);
/*    */   }
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/events/HelpEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */