/*     */ package org.eclipse.swt.internal.image;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import org.eclipse.swt.SWT;
/*     */ import org.eclipse.swt.graphics.ImageData;
/*     */ import org.eclipse.swt.graphics.ImageLoader;
/*     */ import org.eclipse.swt.graphics.PaletteData;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class WinICOFileFormat
/*     */   extends FileFormat
/*     */ {
/*     */   byte[] bitInvertData(byte[] data, int startIndex, int endIndex)
/*     */   {
/*  22 */     for (int i = startIndex; i < endIndex; i++) {
/*  23 */       data[i] = ((byte)(255 - data[(i - startIndex)]));
/*     */     }
/*  25 */     return data;
/*     */   }
/*     */   
/*     */   static final byte[] convertPad(byte[] data, int width, int height, int depth, int pad, int newPad) {
/*  29 */     if (pad == newPad) return data;
/*  30 */     int stride = (width * depth + 7) / 8;
/*  31 */     int bpl = (stride + (pad - 1)) / pad * pad;
/*  32 */     int newBpl = (stride + (newPad - 1)) / newPad * newPad;
/*  33 */     byte[] newData = new byte[height * newBpl];
/*  34 */     int srcIndex = 0;int destIndex = 0;
/*  35 */     for (int y = 0; y < height; y++) {
/*  36 */       System.arraycopy(data, srcIndex, newData, destIndex, newBpl);
/*  37 */       srcIndex += bpl;
/*  38 */       destIndex += newBpl;
/*     */     }
/*  40 */     return newData;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   int iconSize(ImageData i)
/*     */   {
/*  47 */     int shapeDataStride = (i.width * i.depth + 31) / 32 * 4;
/*  48 */     int maskDataStride = (i.width + 31) / 32 * 4;
/*  49 */     int dataSize = (shapeDataStride + maskDataStride) * i.height;
/*  50 */     int paletteSize = i.palette.colors != null ? i.palette.colors.length * 4 : 0;
/*  51 */     return 40 + paletteSize + dataSize;
/*     */   }
/*     */   
/*     */   boolean isFileFormat(LEDataInputStream stream) {
/*     */     try {
/*  56 */       byte[] header = new byte[4];
/*  57 */       stream.read(header);
/*  58 */       stream.unread(header);
/*  59 */       return (header[0] == 0) && (header[1] == 0) && (header[2] == 1) && (header[3] == 0);
/*     */     } catch (Exception e) {}
/*  61 */     return false;
/*     */   }
/*     */   
/*     */   boolean isValidIcon(ImageData i) {
/*  65 */     switch (i.depth) {
/*     */     case 1: 
/*     */     case 4: 
/*     */     case 8: 
/*  69 */       if (i.palette.isDirect) return false;
/*  70 */       int size = i.palette.colors.length;
/*  71 */       return (size == 2) || (size == 16) || (size == 32) || (size == 256);
/*     */     case 24: 
/*     */     case 32: 
/*  74 */       return i.palette.isDirect;
/*     */     }
/*  76 */     return false;
/*     */   }
/*     */   
/*  79 */   int loadFileHeader(LEDataInputStream byteStream) { int[] fileHeader = new int[3];
/*     */     try {
/*  81 */       fileHeader[0] = byteStream.readShort();
/*  82 */       fileHeader[1] = byteStream.readShort();
/*  83 */       fileHeader[2] = byteStream.readShort();
/*     */     } catch (IOException e) {
/*  85 */       SWT.error(39, e);
/*     */     }
/*  87 */     if ((fileHeader[0] != 0) || (fileHeader[1] != 1))
/*  88 */       SWT.error(40);
/*  89 */     int numIcons = fileHeader[2];
/*  90 */     if (numIcons <= 0)
/*  91 */       SWT.error(40);
/*  92 */     return numIcons;
/*     */   }
/*     */   
/*  95 */   int loadFileHeader(LEDataInputStream byteStream, boolean hasHeader) { int[] fileHeader = new int[3];
/*     */     try {
/*  97 */       if (hasHeader) {
/*  98 */         fileHeader[0] = byteStream.readShort();
/*  99 */         fileHeader[1] = byteStream.readShort();
/*     */       } else {
/* 101 */         fileHeader[0] = 0;
/* 102 */         fileHeader[1] = 1;
/*     */       }
/* 104 */       fileHeader[2] = byteStream.readShort();
/*     */     } catch (IOException e) {
/* 106 */       SWT.error(39, e);
/*     */     }
/* 108 */     if ((fileHeader[0] != 0) || (fileHeader[1] != 1))
/* 109 */       SWT.error(40);
/* 110 */     int numIcons = fileHeader[2];
/* 111 */     if (numIcons <= 0)
/* 112 */       SWT.error(40);
/* 113 */     return numIcons;
/*     */   }
/*     */   
/*     */   ImageData[] loadFromByteStream() {
/* 117 */     int numIcons = loadFileHeader(this.inputStream);
/* 118 */     int[][] headers = loadIconHeaders(numIcons);
/* 119 */     ImageData[] icons = new ImageData[headers.length];
/* 120 */     for (int i = 0; i < icons.length; i++) {
/* 121 */       icons[i] = loadIcon(headers[i]);
/*     */     }
/* 123 */     return icons;
/*     */   }
/*     */   
/*     */   ImageData loadIcon(int[] iconHeader)
/*     */   {
/*     */     try
/*     */     {
/* 130 */       FileFormat png = getFileFormat(this.inputStream, "PNG");
/* 131 */       if (png != null) {
/* 132 */         png.loader = this.loader;
/* 133 */         return png.loadFromStream(this.inputStream)[0];
/*     */       }
/*     */     }
/*     */     catch (Exception localException) {}
/* 137 */     byte[] infoHeader = loadInfoHeader(iconHeader);
/* 138 */     WinBMPFileFormat bmpFormat = new WinBMPFileFormat();
/* 139 */     bmpFormat.inputStream = this.inputStream;
/* 140 */     PaletteData palette = bmpFormat.loadPalette(infoHeader);
/* 141 */     byte[] shapeData = bmpFormat.loadData(infoHeader);
/* 142 */     int width = infoHeader[4] & 0xFF | (infoHeader[5] & 0xFF) << 8 | (infoHeader[6] & 0xFF) << 16 | (infoHeader[7] & 0xFF) << 24;
/* 143 */     int height = infoHeader[8] & 0xFF | (infoHeader[9] & 0xFF) << 8 | (infoHeader[10] & 0xFF) << 16 | (infoHeader[11] & 0xFF) << 24;
/* 144 */     if (height < 0) height = -height;
/* 145 */     int depth = infoHeader[14] & 0xFF | (infoHeader[15] & 0xFF) << 8;
/* 146 */     infoHeader[14] = 1;
/* 147 */     infoHeader[15] = 0;
/* 148 */     byte[] maskData = bmpFormat.loadData(infoHeader);
/* 149 */     maskData = convertPad(maskData, width, height, 1, 4, 2);
/* 150 */     bitInvertData(maskData, 0, maskData.length);
/* 151 */     return ImageData.internal_new(width, height, depth, palette, 4, shapeData, 2, maskData, null, -1, -1, 3, 0, 0, 0, 0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   int[][] loadIconHeaders(int numIcons)
/*     */   {
/* 170 */     int[][] headers = new int[numIcons][7];
/*     */     try {
/* 172 */       for (int i = 0; i < numIcons; i++) {
/* 173 */         headers[i][0] = this.inputStream.read();
/* 174 */         headers[i][1] = this.inputStream.read();
/* 175 */         headers[i][2] = this.inputStream.readShort();
/* 176 */         headers[i][3] = this.inputStream.readShort();
/* 177 */         headers[i][4] = this.inputStream.readShort();
/* 178 */         headers[i][5] = this.inputStream.readInt();
/* 179 */         headers[i][6] = this.inputStream.readInt();
/*     */       }
/*     */     } catch (IOException e) {
/* 182 */       SWT.error(39, e);
/*     */     }
/* 184 */     return headers;
/*     */   }
/*     */   
/* 187 */   byte[] loadInfoHeader(int[] iconHeader) { int width = iconHeader[0];
/* 188 */     int height = iconHeader[1];
/* 189 */     int numColors = iconHeader[2];
/* 190 */     if (numColors == 0) numColors = 256;
/* 191 */     if ((numColors != 2) && (numColors != 8) && (numColors != 16) && (numColors != 32) && (numColors != 256))
/*     */     {
/* 193 */       SWT.error(40); }
/* 194 */     if (this.inputStream.getPosition() < iconHeader[6]) {
/*     */       try
/*     */       {
/* 197 */         this.inputStream.skip(iconHeader[6] - this.inputStream.getPosition());
/*     */       } catch (IOException e) {
/* 199 */         SWT.error(39, e);
/* 200 */         return null;
/*     */       }
/*     */     }
/* 203 */     byte[] infoHeader = new byte[40];
/*     */     try {
/* 205 */       this.inputStream.read(infoHeader);
/*     */     } catch (IOException e) {
/* 207 */       SWT.error(39, e);
/*     */     }
/* 209 */     if ((infoHeader[12] & 0xFF | (infoHeader[13] & 0xFF) << 8) != 1)
/* 210 */       SWT.error(40);
/* 211 */     int infoWidth = infoHeader[4] & 0xFF | (infoHeader[5] & 0xFF) << 8 | (infoHeader[6] & 0xFF) << 16 | (infoHeader[7] & 0xFF) << 24;
/* 212 */     int infoHeight = infoHeader[8] & 0xFF | (infoHeader[9] & 0xFF) << 8 | (infoHeader[10] & 0xFF) << 16 | (infoHeader[11] & 0xFF) << 24;
/* 213 */     int bitCount = infoHeader[14] & 0xFF | (infoHeader[15] & 0xFF) << 8;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 219 */     if (width == 0) width = infoWidth;
/* 220 */     if (height == 0) height = infoHeight / 2;
/* 221 */     if ((height == infoHeight) && (bitCount == 1)) height /= 2;
/* 222 */     if ((width != infoWidth) || (height * 2 != infoHeight) || ((bitCount != 1) && (bitCount != 4) && (bitCount != 8) && (bitCount != 24) && (bitCount != 32)))
/*     */     {
/* 224 */       SWT.error(40); }
/* 225 */     infoHeader[8] = ((byte)(height & 0xFF));
/* 226 */     infoHeader[9] = ((byte)(height >> 8 & 0xFF));
/* 227 */     infoHeader[10] = ((byte)(height >> 16 & 0xFF));
/* 228 */     infoHeader[11] = ((byte)(height >> 24 & 0xFF));
/* 229 */     return infoHeader;
/*     */   }
/*     */   
/*     */ 
/*     */   void unloadIcon(ImageData icon)
/*     */   {
/* 235 */     int sizeImage = ((icon.width * icon.depth + 31) / 32 * 4 + (icon.width + 31) / 32 * 4) * icon.height;
/*     */     try
/*     */     {
/* 238 */       this.outputStream.writeInt(40);
/* 239 */       this.outputStream.writeInt(icon.width);
/* 240 */       this.outputStream.writeInt(icon.height * 2);
/* 241 */       this.outputStream.writeShort(1);
/* 242 */       this.outputStream.writeShort((short)icon.depth);
/* 243 */       this.outputStream.writeInt(0);
/* 244 */       this.outputStream.writeInt(sizeImage);
/* 245 */       this.outputStream.writeInt(0);
/* 246 */       this.outputStream.writeInt(0);
/* 247 */       this.outputStream.writeInt(icon.palette.colors != null ? icon.palette.colors.length : 0);
/* 248 */       this.outputStream.writeInt(0);
/*     */     } catch (IOException e) {
/* 250 */       SWT.error(39, e);
/*     */     }
/*     */     
/* 253 */     byte[] rgbs = WinBMPFileFormat.paletteToBytes(icon.palette);
/*     */     try {
/* 255 */       this.outputStream.write(rgbs);
/*     */     } catch (IOException e) {
/* 257 */       SWT.error(39, e);
/*     */     }
/* 259 */     unloadShapeData(icon);
/* 260 */     unloadMaskData(icon);
/*     */   }
/*     */   
/*     */ 
/*     */   void unloadIconHeader(ImageData i)
/*     */   {
/* 266 */     int headerSize = 16;
/* 267 */     int offset = headerSize + 6;
/* 268 */     int iconSize = iconSize(i);
/*     */     try {
/* 270 */       this.outputStream.write(i.width);
/* 271 */       this.outputStream.write(i.height);
/* 272 */       this.outputStream.writeShort(i.palette.colors != null ? i.palette.colors.length : 0);
/* 273 */       this.outputStream.writeShort(0);
/* 274 */       this.outputStream.writeShort(0);
/* 275 */       this.outputStream.writeInt(iconSize);
/* 276 */       this.outputStream.writeInt(offset);
/*     */     } catch (IOException e) {
/* 278 */       SWT.error(39, e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   void unloadIntoByteStream(ImageLoader loader)
/*     */   {
/* 285 */     ImageData image = loader.data[0];
/* 286 */     if (!isValidIcon(image))
/* 287 */       SWT.error(40);
/*     */     try {
/* 289 */       this.outputStream.writeShort(0);
/* 290 */       this.outputStream.writeShort(1);
/* 291 */       this.outputStream.writeShort(1);
/*     */     } catch (IOException e) {
/* 293 */       SWT.error(39, e);
/*     */     }
/* 295 */     unloadIconHeader(image);
/* 296 */     unloadIcon(image);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   void unloadMaskData(ImageData icon)
/*     */   {
/* 303 */     ImageData mask = icon.getTransparencyMask();
/* 304 */     int bpl = (icon.width + 7) / 8;
/* 305 */     int pad = mask.scanlinePad;
/* 306 */     int srcBpl = (bpl + pad - 1) / pad * pad;
/* 307 */     int destBpl = (bpl + 3) / 4 * 4;
/* 308 */     byte[] buf = new byte[destBpl];
/* 309 */     int offset = (icon.height - 1) * srcBpl;
/* 310 */     byte[] data = mask.data;
/*     */     try {
/* 312 */       for (int i = 0; i < icon.height; i++) {
/* 313 */         System.arraycopy(data, offset, buf, 0, bpl);
/* 314 */         bitInvertData(buf, 0, bpl);
/* 315 */         this.outputStream.write(buf, 0, destBpl);
/* 316 */         offset -= srcBpl;
/*     */       }
/*     */     } catch (IOException e) {
/* 319 */       SWT.error(39, e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   void unloadShapeData(ImageData icon)
/*     */   {
/* 326 */     int bpl = (icon.width * icon.depth + 7) / 8;
/* 327 */     int pad = icon.scanlinePad;
/* 328 */     int srcBpl = (bpl + pad - 1) / pad * pad;
/* 329 */     int destBpl = (bpl + 3) / 4 * 4;
/* 330 */     byte[] buf = new byte[destBpl];
/* 331 */     int offset = (icon.height - 1) * srcBpl;
/* 332 */     byte[] data = icon.data;
/*     */     try {
/* 334 */       for (int i = 0; i < icon.height; i++) {
/* 335 */         System.arraycopy(data, offset, buf, 0, bpl);
/* 336 */         this.outputStream.write(buf, 0, destBpl);
/* 337 */         offset -= srcBpl;
/*     */       }
/*     */     } catch (IOException e) {
/* 340 */       SWT.error(39, e);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/internal/image/WinICOFileFormat.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */