/*     */ package org.eclipse.swt.events;
/*     */ 
/*     */ import org.eclipse.swt.widgets.Event;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GestureEvent
/*     */   extends TypedEvent
/*     */ {
/*     */   public int stateMask;
/*     */   public int detail;
/*     */   public int x;
/*     */   public int y;
/*     */   public double rotation;
/*     */   public int xDirection;
/*     */   public int yDirection;
/*     */   public double magnification;
/*     */   public boolean doit;
/*     */   static final long serialVersionUID = -8348741538373572182L;
/*     */   
/*     */   public GestureEvent(Event e)
/*     */   {
/* 127 */     super(e);
/* 128 */     this.stateMask = e.stateMask;
/* 129 */     this.x = e.x;
/* 130 */     this.y = e.y;
/* 131 */     this.detail = e.detail;
/* 132 */     this.rotation = e.rotation;
/* 133 */     this.xDirection = e.xDirection;
/* 134 */     this.yDirection = e.yDirection;
/* 135 */     this.magnification = e.magnification;
/* 136 */     this.doit = e.doit;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 147 */     String string = super.toString();
/* 148 */     return string.substring(0, string.length() - 1) + " stateMask=0x" + 
/* 149 */       Integer.toHexString(this.stateMask) + " detail=" + this.detail + " x=" + this.x + " y=" + this.y + " rotation=" + this.rotation + " xDirection=" + this.xDirection + " yDirection=" + this.yDirection + " magnification=" + this.magnification + "}";
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/events/GestureEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */