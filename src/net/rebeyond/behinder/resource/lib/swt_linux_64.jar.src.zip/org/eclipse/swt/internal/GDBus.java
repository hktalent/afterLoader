/*     */ package org.eclipse.swt.internal;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.function.Function;
/*     */ import org.eclipse.swt.SWT;
/*     */ import org.eclipse.swt.SWTException;
/*     */ import org.eclipse.swt.internal.gtk.OS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GDBus
/*     */ {
/*     */   static final String SWT_GDBUS_VERSION_INFO = "SWT_LIB GDbus firing up. Implementation v1.5";
/*     */   private static boolean initialized;
/*     */   private static List<GDBusMethod> gdbusMethods;
/*     */   private static final String DBUS_SERVICE_NAME = "org.eclipse.swt";
/*     */   private static final String DBUS_OBJECT_NAME = "/org/eclipse/swt";
/*     */   private static final String INTERFACE_NAME = "org.eclipse.swt";
/*     */   private static Callback onBusAcquired;
/*     */   private static Callback onNameAcquired;
/*     */   private static Callback onNameLost;
/*     */   private static Callback handleMethod;
/*     */   
/*     */   public static class GDBusMethod
/*     */   {
/*     */     private final String name;
/*     */     private final Function<Object[], Object[]> userFunction;
/*     */     private final String methodArgsXmlSignature;
/*     */     
/*     */     public GDBusMethod(String name, String[][] inputArgs, String[][] outputArgs, Function<Object[], Object[]> userFunction)
/*     */     {
/* 105 */       this.name = name;
/* 106 */       this.userFunction = userFunction;
/* 107 */       StringBuilder gdbBusArgsXml = new StringBuilder();
/* 108 */       for (String[] dataType : inputArgs) {
/* 109 */         gdbBusArgsXml.append("     <arg type='" + dataType[0] + "' name='" + dataType[1] + "' direction='in'/>\n");
/*     */       }
/* 111 */       for (String[] dataType : outputArgs) {
/* 112 */         gdbBusArgsXml.append("     <arg type='" + dataType[0] + "' name='" + dataType[1] + "' direction='out'/>\n");
/*     */       }
/* 114 */       this.methodArgsXmlSignature = gdbBusArgsXml.toString();
/*     */     }
/*     */     
/*     */     private String getName() {
/* 118 */       return this.name;
/*     */     }
/*     */     
/*     */     private Function<Object[], Object[]> getUserFunction() {
/* 122 */       return this.userFunction;
/*     */     }
/*     */     
/*     */     private String getMethodArgsXmlSignature() {
/* 126 */       return this.methodArgsXmlSignature;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void init(GDBusMethod[] methods)
/*     */   {
/* 138 */     if (!initialized) {
/* 139 */       initialized = true;
/*     */     } else {
/* 141 */       return;
/*     */     }
/* 143 */     if ((methods == null) || (methods.length == 0)) {
/* 144 */       System.err.println("SWT Error, no gdbus methods to initialize.");
/* 145 */       return;
/*     */     }
/*     */     
/* 148 */     gdbusMethods = Arrays.asList(methods);
/*     */     
/* 150 */     int owner_id = OS.g_bus_own_name(2, 
/* 151 */       Converter.javaStringToCString("org.eclipse.swt"), 3, onBusAcquired
/*     */       
/* 153 */       .getAddress(), onNameAcquired
/* 154 */       .getAddress(), onNameLost
/* 155 */       .getAddress(), 0L, 0L);
/*     */     
/*     */ 
/*     */ 
/* 159 */     if (owner_id == 0) {
/* 160 */       System.err.println("SWT GDBus: Failed to aquire bus name: org.eclipse.swt");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static
/*     */   {
/* 177 */     onBusAcquired = new Callback(GDBus.class, "onBusAcquired", 3);
/* 178 */     if (onBusAcquired.getAddress() == 0L) { SWT.error(3);
/*     */     }
/* 180 */     onNameAcquired = new Callback(GDBus.class, "onNameAcquired", 3);
/* 181 */     if (onNameAcquired.getAddress() == 0L) { SWT.error(3);
/*     */     }
/* 183 */     onNameLost = new Callback(GDBus.class, "onNameLost", 3);
/* 184 */     if (onNameLost.getAddress() == 0L) { SWT.error(3);
/*     */     }
/* 186 */     handleMethod = new Callback(GDBus.class, "handleMethod", 8);
/* 187 */     if (handleMethod.getAddress() == 0L) { SWT.error(3);
/*     */     }
/* 189 */     String swt_lib_versions = OS.getEnvironmentalVariable("SWT_LIB_VERSIONS");
/* 190 */     if ((swt_lib_versions != null) && (swt_lib_versions.equals("1"))) {
/* 191 */       System.out.println("SWT_LIB GDbus firing up. Implementation v1.5");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static long onBusAcquired(long gDBusConnection, long const_gchar_name, long user_data)
/*     */   {
/* 210 */     StringBuilder dbus_introspection_xml = new StringBuilder();
/* 211 */     dbus_introspection_xml.append("<node><interface name='org.eclipse.swt'>\n");
/* 212 */     for (GDBusMethod method : gdbusMethods)
/*     */     {
/* 214 */       dbus_introspection_xml.append("  <method name='" + method.name + "'>\n");
/* 215 */       dbus_introspection_xml.append("   " + method.getMethodArgsXmlSignature() + "\n");
/* 216 */       dbus_introspection_xml.append("  </method>\n");
/*     */     }
/* 218 */     dbus_introspection_xml.append("</interface></node>");
/*     */     
/* 220 */     long[] error = new long[1];
/* 221 */     long gdBusNodeInfo = OS.g_dbus_node_info_new_for_xml(Converter.javaStringToCString(dbus_introspection_xml.toString()), error);
/* 222 */     if ((gdBusNodeInfo == 0L) || (error[0] != 0L)) {
/* 223 */       System.err.println("SWT GDBus: Failed to get introspection data");
/*     */     }
/* 225 */     assert (gdBusNodeInfo != 0L) : "SWT GDBus: introspection data should not be 0";
/*     */     
/*     */ 
/*     */ 
/* 229 */     long[] error = new long[1];
/* 230 */     long interface_info = OS.g_dbus_node_info_lookup_interface(gdBusNodeInfo, Converter.javaStringToCString("org.eclipse.swt"));
/* 231 */     long[] vtable = { handleMethod.getAddress(), 0L, 0L };
/* 232 */     OS.g_dbus_connection_register_object(gDBusConnection, 
/*     */     
/* 234 */       Converter.javaStringToCString("/org/eclipse/swt"), interface_info, vtable, 0L, 0L, error);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 240 */     if (error[0] != 0L) {
/* 241 */       System.err.println("SWT GDBus: Failed to register object: /org/eclipse/swt");
/* 242 */       return 0L;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 253 */     return 0L;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static long onNameAcquired(long connection, long name, long user_data)
/*     */   {
/* 260 */     return 0L;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static long onNameLost(long connection, long name, long user_data)
/*     */   {
/* 267 */     return 0L;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static long handleMethod(long connection, long sender, long object_path, long interface_name, long method_name, long gvar_parameters, long invocation, long user_data)
/*     */   {
/* 296 */     long resultGVariant = 0L;
/*     */     try {
/* 298 */       java_method_name = Converter.cCharPtrToJavaString(method_name, false);
/* 299 */       for (GDBusMethod gdbusMethod : gdbusMethods)
/* 300 */         if (gdbusMethod.getName().equals(java_method_name)) {
/* 301 */           Object[] args = convertGVariantToJava(gvar_parameters);
/* 302 */           Object[] returnVal = (Object[])gdbusMethod.getUserFunction().apply(args);
/* 303 */           if ((returnVal == null) || ((returnVal instanceof Object[]))) {
/* 304 */             resultGVariant = convertJavaToGVariant(returnVal); break;
/*     */           }
/* 306 */           System.err.println("SWT GDBus error processing user return value: " + returnVal.toString() + ". Return value must be an Object[] or null.");
/*     */           
/* 308 */           break;
/*     */         }
/*     */     } catch (Exception e) {
/*     */       String java_method_name;
/* 312 */       System.err.println("SWT GDBUS ERROR: Error in handling method: \n" + e.getMessage());
/*     */     }
/*     */     finally
/*     */     {
/* 316 */       OS.g_dbus_method_invocation_return_value(invocation, resultGVariant);
/*     */     }
/* 318 */     return 0L;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Object[] convertGVariantToJava(long gVariant)
/*     */   {
/* 331 */     Object retVal = convertGVariantToJavaHelper(gVariant);
/* 332 */     if ((retVal instanceof Object[])) {
/* 333 */       return (Object[])retVal;
/*     */     }
/* 335 */     System.err.println("SWT GDBus Error converting arguments : Expecting object array, received Object.");
/* 336 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Object convertGVariantToJavaHelper(long gVariant)
/*     */   {
/* 350 */     if (OS.g_variant_is_of_type(gVariant, OS.G_VARIANT_TYPE_STRING)) {
/* 351 */       return Converter.cCharPtrToJavaString(OS.g_variant_get_string(gVariant, null), false);
/*     */     }
/*     */     
/* 354 */     if (OS.g_variant_is_of_type(gVariant, OS.G_VARIANT_TYPE_BOOLEAN)) {
/* 355 */       return Boolean.valueOf(OS.g_variant_get_boolean(gVariant));
/*     */     }
/*     */     
/* 358 */     if (OS._g_variant_is_of_type(gVariant, OS.G_VARIANT_TYPE_IN32)) {
/* 359 */       return Integer.valueOf(OS.g_variant_get_int32(gVariant));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 366 */     if (OS.g_variant_is_of_type(gVariant, OS.G_VARIANT_TYPE_TUPLE)) {
/* 367 */       int length = (int)OS.g_variant_n_children(gVariant);
/* 368 */       Object[] result = new Object[length];
/* 369 */       for (int i = 0; i < length; i++) {
/* 370 */         result[i] = convertGVariantToJavaHelper(OS.g_variant_get_child_value(gVariant, i));
/*     */       }
/* 372 */       return result;
/*     */     }
/*     */     
/*     */ 
/* 376 */     if (OS.g_variant_is_of_type(gVariant, OS.G_VARIANT_TYPE_STRING_ARRAY)) {
/* 377 */       int length = (int)OS.g_variant_n_children(gVariant);
/* 378 */       String[] result = new String[length];
/* 379 */       for (int i = 0; i < length; i++) {
/* 380 */         result[i] = ((String)convertGVariantToJavaHelper(OS.g_variant_get_child_value(gVariant, i)));
/*     */       }
/* 382 */       return result;
/*     */     }
/*     */     
/* 385 */     String typeString = Converter.cCharPtrToJavaString(OS.g_variant_get_type_string(gVariant), false);
/* 386 */     System.err.println("SWT GDBus: Error. Unhandled variant type (i.e DBus type):  " + typeString + "     You probably need to update  (SWT) GDBus.java:convertGVariantToJavaHelper() to support this type.");
/*     */     
/* 388 */     SWT.error(5);
/* 389 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static long convertJavaToGVariant(Object javaObject)
/*     */     throws SWTException
/*     */   {
/* 401 */     if (javaObject == null) {
/* 402 */       return 0L;
/*     */     }
/*     */     
/* 405 */     if ((javaObject instanceof String)) {
/* 406 */       return OS.g_variant_new_string(Converter.javaStringToCString((String)javaObject));
/*     */     }
/*     */     
/* 409 */     if ((javaObject instanceof Boolean)) {
/* 410 */       return OS.g_variant_new_boolean(((Boolean)javaObject).booleanValue());
/*     */     }
/*     */     
/* 413 */     if ((javaObject instanceof Integer)) {
/* 414 */       return OS.g_variant_new_int32(((Integer)javaObject).intValue());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 425 */     if ((javaObject instanceof Object[])) {
/* 426 */       Object[] arrayValue = (Object[])javaObject;
/* 427 */       int length = arrayValue.length;
/*     */       
/* 429 */       long[] variants = new long[length];
/* 430 */       for (int i = 0; i < length; i++) {
/* 431 */         variants[i] = convertJavaToGVariant(arrayValue[i]);
/*     */       }
/* 433 */       return OS.g_variant_new_tuple(variants, length);
/*     */     }
/*     */     
/* 436 */     System.err.println("SWT GDbus: Invalid object being returned to caller: " + javaObject.toString() + "   You probably need to update (SWT) GDBus.java:convertJavaToGVariant()");
/* 437 */     throw new SWTException(5);
/*     */   }
/*     */   
/*     */   static void teardown_gdbus() {}
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/internal/GDBus.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */