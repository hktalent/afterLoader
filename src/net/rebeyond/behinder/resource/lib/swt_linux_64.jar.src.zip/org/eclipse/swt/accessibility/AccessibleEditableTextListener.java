package org.eclipse.swt.accessibility;

import org.eclipse.swt.internal.SWTEventListener;

public abstract interface AccessibleEditableTextListener
  extends SWTEventListener
{
  public abstract void copyText(AccessibleEditableTextEvent paramAccessibleEditableTextEvent);
  
  public abstract void cutText(AccessibleEditableTextEvent paramAccessibleEditableTextEvent);
  
  public abstract void pasteText(AccessibleEditableTextEvent paramAccessibleEditableTextEvent);
  
  public abstract void replaceText(AccessibleEditableTextEvent paramAccessibleEditableTextEvent);
  
  public abstract void setTextAttributes(AccessibleTextAttributeEvent paramAccessibleTextAttributeEvent);
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/accessibility/AccessibleEditableTextListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */