/*     */ package org.eclipse.swt.printing;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import org.eclipse.swt.SWT;
/*     */ import org.eclipse.swt.graphics.Color;
/*     */ import org.eclipse.swt.graphics.Device;
/*     */ import org.eclipse.swt.graphics.DeviceData;
/*     */ import org.eclipse.swt.graphics.GCData;
/*     */ import org.eclipse.swt.graphics.Point;
/*     */ import org.eclipse.swt.graphics.Rectangle;
/*     */ import org.eclipse.swt.internal.C;
/*     */ import org.eclipse.swt.internal.Callback;
/*     */ import org.eclipse.swt.internal.Converter;
/*     */ import org.eclipse.swt.internal.cairo.Cairo;
/*     */ import org.eclipse.swt.internal.gtk.GDK;
/*     */ import org.eclipse.swt.internal.gtk.GTK;
/*     */ import org.eclipse.swt.internal.gtk.OS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Printer
/*     */   extends Device
/*     */ {
/*     */   static PrinterData[] printerList;
/*     */   static long findPrinter;
/*     */   static PrinterData findData;
/*     */   PrinterData data;
/*     */   long printer;
/*     */   long printJob;
/*     */   long settings;
/*     */   long pageSetup;
/*     */   long surface;
/*     */   long cairo;
/*  58 */   boolean isGCCreated = false;
/*     */   
/*     */   static byte[] settingsData;
/*     */   
/*     */   static int start;
/*     */   static int end;
/*     */   static final String GTK_LPR_BACKEND = "GtkPrintBackendLpr";
/*     */   static final String GTK_FILE_BACKEND = "GtkPrintBackendFile";
/*  66 */   static boolean disablePrinting = (OS.IsWin32) || (System.getProperty("org.eclipse.swt.internal.gtk.disablePrinting") != null);
/*     */   
/*     */   static void gtk_init() {
/*  69 */     if ((OS.GLIB_VERSION < OS.VERSION(2, 32, 0)) && 
/*  70 */       (!OS.g_thread_supported())) {
/*  71 */       OS.g_thread_init(0L);
/*     */     }
/*     */     
/*  74 */     if (!GTK.gtk_init_check(new long[] { 0L }, null)) {
/*  75 */       SWT.error(2, null, " [gtk_init_check() failed]");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static PrinterData[] getPrinterList()
/*     */   {
/*  87 */     printerList = new PrinterData[0];
/*  88 */     if (disablePrinting) {
/*  89 */       return printerList;
/*     */     }
/*  91 */     gtk_init();
/*  92 */     Callback printerCallback = new Callback(Printer.class, "GtkPrinterFunc_List", 2);
/*  93 */     long GtkPrinterFunc_List = printerCallback.getAddress();
/*  94 */     if (GtkPrinterFunc_List == 0L) SWT.error(3);
/*  95 */     GTK.gtk_enumerate_printers(GtkPrinterFunc_List, 0L, 0L, true);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 102 */     GDK.gdk_threads_leave();
/* 103 */     printerCallback.dispose();
/* 104 */     return printerList;
/*     */   }
/*     */   
/*     */   static long GtkPrinterFunc_List(long printer, long user_data) {
/* 108 */     int length = printerList.length;
/* 109 */     PrinterData[] newList = new PrinterData[length + 1];
/* 110 */     System.arraycopy(printerList, 0, newList, 0, length);
/* 111 */     printerList = newList;
/* 112 */     printerList[length] = printerDataFromGtkPrinter(printer);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 121 */     if (printerList[length].driver.equals("GtkPrintBackendLpr")) return 1L;
/* 122 */     return 0L;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static PrinterData getDefaultPrinterData()
/*     */   {
/* 135 */     findData = null;
/* 136 */     if (disablePrinting) {
/* 137 */       return null;
/*     */     }
/* 139 */     gtk_init();
/* 140 */     Callback printerCallback = new Callback(Printer.class, "GtkPrinterFunc_Default", 2);
/* 141 */     long GtkPrinterFunc_Default = printerCallback.getAddress();
/* 142 */     if (GtkPrinterFunc_Default == 0L) SWT.error(3);
/* 143 */     GTK.gtk_enumerate_printers(GtkPrinterFunc_Default, 0L, 0L, true);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 150 */     GDK.gdk_threads_leave();
/* 151 */     printerCallback.dispose();
/* 152 */     return findData;
/*     */   }
/*     */   
/*     */   static long GtkPrinterFunc_Default(long printer, long user_data) {
/* 156 */     if (GTK.gtk_printer_is_default(printer)) {
/* 157 */       findData = printerDataFromGtkPrinter(printer);
/* 158 */       return 1L;
/*     */     }
/* 160 */     return 0L;
/*     */   }
/*     */   
/*     */   static long gtkPrinterFromPrinterData(PrinterData data) {
/* 164 */     gtk_init();
/* 165 */     Callback printerCallback = new Callback(Printer.class, "GtkPrinterFunc_FindNamedPrinter", 2);
/* 166 */     long GtkPrinterFunc_FindNamedPrinter = printerCallback.getAddress();
/* 167 */     if (GtkPrinterFunc_FindNamedPrinter == 0L) SWT.error(3);
/* 168 */     findPrinter = 0L;
/* 169 */     findData = data;
/* 170 */     GTK.gtk_enumerate_printers(GtkPrinterFunc_FindNamedPrinter, 0L, 0L, true);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 177 */     GDK.gdk_threads_leave();
/* 178 */     printerCallback.dispose();
/* 179 */     return findPrinter;
/*     */   }
/*     */   
/*     */   static long GtkPrinterFunc_FindNamedPrinter(long printer, long user_data) {
/* 183 */     PrinterData pd = printerDataFromGtkPrinter(printer);
/* 184 */     if (((pd.driver.equals(findData.driver)) && (pd.name.equals(findData.name))) || (
/* 185 */       (pd.driver.equals("GtkPrintBackendFile")) && (findData.printToFile) && (findData.driver == null) && (findData.name == null)))
/*     */     {
/* 187 */       findPrinter = printer;
/* 188 */       OS.g_object_ref(printer);
/* 189 */       return 1L;
/*     */     }
/* 191 */     return 0L;
/*     */   }
/*     */   
/*     */   static PrinterData printerDataFromGtkPrinter(long printer) {
/* 195 */     long backend = GTK.gtk_printer_get_backend(printer);
/* 196 */     long address = OS.G_OBJECT_TYPE_NAME(backend);
/* 197 */     int length = C.strlen(address);
/* 198 */     byte[] buffer = new byte[length];
/* 199 */     C.memmove(buffer, address, length);
/* 200 */     String backendType = new String(Converter.mbcsToWcs(buffer));
/*     */     
/* 202 */     address = GTK.gtk_printer_get_name(printer);
/* 203 */     length = C.strlen(address);
/* 204 */     buffer = new byte[length];
/* 205 */     C.memmove(buffer, address, length);
/* 206 */     String name = new String(Converter.mbcsToWcs(buffer));
/*     */     
/* 208 */     return new PrinterData(backendType, name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   static void restore(byte[] data, long settings, long page_setup)
/*     */   {
/* 215 */     settingsData = data;
/* 216 */     start = end = 0;
/* 217 */     while ((end < settingsData.length) && (settingsData[end] != 0)) {
/* 218 */       start = end;
/* 219 */       while ((end < settingsData.length) && (settingsData[end] != 0)) end += 1;
/* 220 */       end += 1;
/* 221 */       byte[] keyBuffer = new byte[end - start];
/* 222 */       System.arraycopy(settingsData, start, keyBuffer, 0, keyBuffer.length);
/* 223 */       start = end;
/* 224 */       while ((end < settingsData.length) && (settingsData[end] != 0)) end += 1;
/* 225 */       end += 1;
/* 226 */       byte[] valueBuffer = new byte[end - start];
/* 227 */       System.arraycopy(settingsData, start, valueBuffer, 0, valueBuffer.length);
/* 228 */       GTK.gtk_print_settings_set(settings, keyBuffer, valueBuffer);
/* 229 */       if (DEBUG) System.out.println(new String(Converter.mbcsToWcs(keyBuffer)) + ": " + new String(Converter.mbcsToWcs(valueBuffer)));
/*     */     }
/* 231 */     end += 1;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 236 */     GTK.gtk_page_setup_set_orientation(page_setup, restoreInt("orientation"));
/* 237 */     GTK.gtk_page_setup_set_top_margin(page_setup, restoreDouble("top_margin"), 3);
/* 238 */     GTK.gtk_page_setup_set_bottom_margin(page_setup, restoreDouble("bottom_margin"), 3);
/* 239 */     GTK.gtk_page_setup_set_left_margin(page_setup, restoreDouble("left_margin"), 3);
/* 240 */     GTK.gtk_page_setup_set_right_margin(page_setup, restoreDouble("right_margin"), 3);
/* 241 */     byte[] name = restoreBytes("paper_size_name", true);
/* 242 */     byte[] display_name = restoreBytes("paper_size_display_name", true);
/* 243 */     byte[] ppd_name = restoreBytes("paper_size_ppd_name", true);
/* 244 */     double width = restoreDouble("paper_size_width");
/* 245 */     double height = restoreDouble("paper_size_height");
/* 246 */     boolean custom = restoreBoolean("paper_size_is_custom");
/* 247 */     long paper_size = 0L;
/* 248 */     if (custom) {
/* 249 */       if (ppd_name.length > 0) {
/* 250 */         paper_size = GTK.gtk_paper_size_new_from_ppd(ppd_name, display_name, width, height);
/*     */       } else {
/* 252 */         paper_size = GTK.gtk_paper_size_new_custom(name, display_name, width, height, 3);
/*     */       }
/*     */     } else {
/* 255 */       paper_size = GTK.gtk_paper_size_new(name);
/*     */     }
/* 257 */     GTK.gtk_page_setup_set_paper_size(page_setup, paper_size);
/* 258 */     GTK.gtk_paper_size_free(paper_size);
/*     */   }
/*     */   
/*     */   static byte[] uriFromFilename(String filename) {
/* 262 */     if (filename == null) return null;
/* 263 */     int length = filename.length();
/* 264 */     if (length == 0) return null;
/* 265 */     char[] chars = new char[length];
/* 266 */     filename.getChars(0, length, chars, 0);
/* 267 */     long[] error = new long[1];
/* 268 */     long utf8Ptr = OS.g_utf16_to_utf8(chars, chars.length, null, null, error);
/* 269 */     if ((error[0] != 0L) || (utf8Ptr == 0L)) return null;
/* 270 */     long localePtr = OS.g_filename_from_utf8(utf8Ptr, -1L, null, null, error);
/* 271 */     OS.g_free(utf8Ptr);
/* 272 */     if ((error[0] != 0L) || (localePtr == 0L)) return null;
/* 273 */     long uriPtr = OS.g_filename_to_uri(localePtr, 0L, error);
/* 274 */     OS.g_free(localePtr);
/* 275 */     if ((error[0] != 0L) || (uriPtr == 0L)) return null;
/* 276 */     length = C.strlen(uriPtr);
/* 277 */     byte[] uri = new byte[length + 1];
/* 278 */     C.memmove(uri, uriPtr, length);
/* 279 */     OS.g_free(uriPtr);
/* 280 */     return uri;
/*     */   }
/*     */   
/*     */   static DeviceData checkNull(PrinterData data) {
/* 284 */     if (data == null) data = new PrinterData();
/* 285 */     if ((data.driver == null) || (data.name == null)) {
/* 286 */       PrinterData defaultData = null;
/* 287 */       if (data.printToFile) {
/* 288 */         long filePrinter = gtkPrinterFromPrinterData(data);
/* 289 */         if (filePrinter != 0L) {
/* 290 */           defaultData = printerDataFromGtkPrinter(filePrinter);
/* 291 */           OS.g_object_unref(filePrinter);
/*     */         }
/*     */       }
/* 294 */       if (defaultData == null) {
/* 295 */         defaultData = getDefaultPrinterData();
/* 296 */         if (defaultData == null) SWT.error(2);
/*     */       }
/* 298 */       data.driver = defaultData.driver;
/* 299 */       data.name = defaultData.name;
/*     */     }
/* 301 */     return data;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Printer()
/*     */   {
/* 317 */     this(null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Printer(PrinterData data)
/*     */   {
/* 340 */     super(checkNull(data));
/*     */   }
/*     */   
/*     */   static int restoreInt(String key) {
/* 344 */     byte[] value = restoreBytes(key, false);
/* 345 */     return Integer.parseInt(new String(value));
/*     */   }
/*     */   
/*     */   static double restoreDouble(String key) {
/* 349 */     byte[] value = restoreBytes(key, false);
/* 350 */     return Double.parseDouble(new String(value));
/*     */   }
/*     */   
/*     */   static boolean restoreBoolean(String key) {
/* 354 */     byte[] value = restoreBytes(key, false);
/* 355 */     return Boolean.valueOf(new String(value)).booleanValue();
/*     */   }
/*     */   
/*     */   static byte[] restoreBytes(String key, boolean nullTerminate)
/*     */   {
/* 360 */     start = end;
/* 361 */     while ((end < settingsData.length) && (settingsData[end] != 0)) end += 1;
/* 362 */     end += 1;
/* 363 */     byte[] keyBuffer = new byte[end - start];
/* 364 */     System.arraycopy(settingsData, start, keyBuffer, 0, keyBuffer.length);
/*     */     
/*     */ 
/* 367 */     start = end;
/* 368 */     while ((end < settingsData.length) && (settingsData[end] != 0)) end += 1;
/* 369 */     int length = end - start;
/* 370 */     end += 1;
/* 371 */     if (nullTerminate) length++;
/* 372 */     byte[] valueBuffer = new byte[length];
/* 373 */     System.arraycopy(settingsData, start, valueBuffer, 0, length);
/*     */     
/* 375 */     if (DEBUG) { System.out.println(new String(Converter.mbcsToWcs(keyBuffer)) + ": " + new String(Converter.mbcsToWcs(valueBuffer)));
/*     */     }
/* 377 */     return valueBuffer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public long internal_new_GC(GCData data)
/*     */   {
/* 397 */     long drawable = 0L;
/* 398 */     long gc = this.cairo;
/* 399 */     if (gc == 0L) SWT.error(2);
/* 400 */     if (data != null) {
/* 401 */       if (this.isGCCreated) SWT.error(5);
/* 402 */       int mask = 100663296;
/* 403 */       if ((data.style & mask) == 0) {
/* 404 */         data.style |= 0x2000000;
/*     */       }
/* 406 */       data.device = this;
/* 407 */       data.drawable = drawable;
/* 408 */       if (GTK.GTK3) {
/* 409 */         data.backgroundRGBA = getSystemColor(1).handleRGBA;
/* 410 */         data.foregroundRGBA = getSystemColor(2).handleRGBA;
/*     */       } else {
/* 412 */         data.background = getSystemColor(1).handle;
/* 413 */         data.foreground = getSystemColor(2).handle;
/*     */       }
/* 415 */       data.font = getSystemFont();
/* 416 */       Point dpi = getDPI();Point screenDPI = getIndependentDPI();
/* 417 */       data.width = ((int)(GTK.gtk_page_setup_get_paper_width(this.pageSetup, 1) * dpi.x / screenDPI.x));
/* 418 */       data.height = ((int)(GTK.gtk_page_setup_get_paper_height(this.pageSetup, 1) * dpi.y / screenDPI.y));
/* 419 */       if (this.cairo == 0L) SWT.error(2);
/* 420 */       Cairo.cairo_identity_matrix(this.cairo);
/* 421 */       double printX = GTK.gtk_page_setup_get_left_margin(this.pageSetup, 1);
/* 422 */       double printY = GTK.gtk_page_setup_get_top_margin(this.pageSetup, 1);
/* 423 */       Cairo.cairo_translate(this.cairo, printX, printY);
/* 424 */       Cairo.cairo_scale(this.cairo, screenDPI.x / dpi.x, screenDPI.y / dpi.y);
/* 425 */       double[] matrix = new double[6];
/* 426 */       Cairo.cairo_get_matrix(this.cairo, matrix);
/* 427 */       data.identity = matrix;
/* 428 */       data.cairo = this.cairo;
/* 429 */       this.isGCCreated = true;
/*     */     }
/* 431 */     return gc;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void internal_dispose_GC(long hDC, GCData data)
/*     */   {
/* 451 */     if (data != null) { this.isGCCreated = false;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isAutoScalable()
/*     */   {
/* 459 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean startJob(String jobName)
/*     */   {
/* 484 */     checkDevice();
/* 485 */     byte[] buffer = Converter.wcsToMbcs(jobName, true);
/* 486 */     this.printJob = GTK.gtk_print_job_new(buffer, this.printer, this.settings, this.pageSetup);
/* 487 */     if (this.printJob == 0L) return false;
/* 488 */     this.surface = GTK.gtk_print_job_get_surface(this.printJob, null);
/* 489 */     if (this.surface == 0L) {
/* 490 */       OS.g_object_unref(this.printJob);
/* 491 */       this.printJob = 0L;
/* 492 */       return false;
/*     */     }
/* 494 */     this.cairo = Cairo.cairo_create(this.surface);
/* 495 */     if (this.cairo == 0L) {
/* 496 */       OS.g_object_unref(this.printJob);
/* 497 */       this.printJob = 0L;
/* 498 */       return false;
/*     */     }
/* 500 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void destroy()
/*     */   {
/* 510 */     if (this.printer != 0L) OS.g_object_unref(this.printer);
/* 511 */     if (this.settings != 0L) OS.g_object_unref(this.settings);
/* 512 */     if (this.pageSetup != 0L) OS.g_object_unref(this.pageSetup);
/* 513 */     if (this.cairo != 0L) Cairo.cairo_destroy(this.cairo);
/* 514 */     if (this.printJob != 0L) OS.g_object_unref(this.printJob);
/* 515 */     this.printer = (this.settings = this.pageSetup = this.cairo = this.printJob = 0L);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void endJob()
/*     */   {
/* 530 */     checkDevice();
/* 531 */     if (this.printJob == 0L) return;
/* 532 */     Cairo.cairo_surface_finish(this.surface);
/* 533 */     GTK.gtk_print_job_send(this.printJob, 0L, 0L, 0L);
/* 534 */     OS.g_object_unref(this.printJob);
/* 535 */     this.printJob = 0L;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void cancelJob()
/*     */   {
/* 546 */     checkDevice();
/* 547 */     if (this.printJob == 0L) { return;
/*     */     }
/* 549 */     Cairo.cairo_surface_finish(this.surface);
/* 550 */     OS.g_object_unref(this.printJob);
/* 551 */     this.printJob = 0L;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean startPage()
/*     */   {
/* 573 */     checkDevice();
/* 574 */     if (this.printJob == 0L) return false;
/* 575 */     double width = GTK.gtk_page_setup_get_paper_width(this.pageSetup, 1);
/* 576 */     double height = GTK.gtk_page_setup_get_paper_height(this.pageSetup, 1);
/* 577 */     int type = Cairo.cairo_surface_get_type(this.surface);
/* 578 */     switch (type) {
/*     */     case 2: 
/* 580 */       Cairo.cairo_ps_surface_set_size(this.surface, width, height);
/* 581 */       break;
/*     */     case 1: 
/* 583 */       Cairo.cairo_pdf_surface_set_size(this.surface, width, height);
/*     */     }
/*     */     
/* 586 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void endPage()
/*     */   {
/* 601 */     checkDevice();
/* 602 */     Cairo.cairo_show_page(this.cairo);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Point getDPI()
/*     */   {
/* 618 */     checkDevice();
/* 619 */     int resolution = GTK.gtk_print_settings_get_resolution(this.settings);
/* 620 */     if (DEBUG) { System.out.println("print_settings.resolution=" + resolution);
/*     */     }
/* 622 */     if (resolution == 0) return new Point(72, 72);
/* 623 */     return new Point(resolution, resolution);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Rectangle getBounds()
/*     */   {
/* 643 */     checkDevice();
/* 644 */     Point dpi = getDPI();Point screenDPI = getIndependentDPI();
/* 645 */     double width = GTK.gtk_page_setup_get_paper_width(this.pageSetup, 1) * dpi.x / screenDPI.x;
/* 646 */     double height = GTK.gtk_page_setup_get_paper_height(this.pageSetup, 1) * dpi.y / screenDPI.y;
/* 647 */     return new Rectangle(0, 0, (int)width, (int)height);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Rectangle getClientArea()
/*     */   {
/* 669 */     checkDevice();
/* 670 */     Point dpi = getDPI();Point screenDPI = getIndependentDPI();
/* 671 */     double width = GTK.gtk_page_setup_get_page_width(this.pageSetup, 1) * dpi.x / screenDPI.x;
/* 672 */     double height = GTK.gtk_page_setup_get_page_height(this.pageSetup, 1) * dpi.y / screenDPI.y;
/* 673 */     return new Rectangle(0, 0, (int)width, (int)height);
/*     */   }
/*     */   
/*     */   Point getIndependentDPI() {
/* 677 */     return new Point(72, 72);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Rectangle computeTrim(int x, int y, int width, int height)
/*     */   {
/* 716 */     checkDevice();
/* 717 */     Point dpi = getDPI();Point screenDPI = getIndependentDPI();
/* 718 */     double printWidth = GTK.gtk_page_setup_get_page_width(this.pageSetup, 1) * dpi.x / screenDPI.x;
/* 719 */     double printHeight = GTK.gtk_page_setup_get_page_height(this.pageSetup, 1) * dpi.y / screenDPI.y;
/* 720 */     double paperWidth = GTK.gtk_page_setup_get_paper_width(this.pageSetup, 1) * dpi.x / screenDPI.x;
/* 721 */     double paperHeight = GTK.gtk_page_setup_get_paper_height(this.pageSetup, 1) * dpi.y / screenDPI.y;
/* 722 */     double printX = -GTK.gtk_page_setup_get_left_margin(this.pageSetup, 1) * dpi.x / screenDPI.x;
/* 723 */     double printY = -GTK.gtk_page_setup_get_top_margin(this.pageSetup, 1) * dpi.y / screenDPI.y;
/* 724 */     double hTrim = paperWidth - printWidth;
/* 725 */     double vTrim = paperHeight - printHeight;
/* 726 */     return new Rectangle(x + (int)printX, y + (int)printY, width + (int)hTrim, height + (int)vTrim);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void create(DeviceData deviceData)
/*     */   {
/* 737 */     this.data = ((PrinterData)deviceData);
/* 738 */     if (disablePrinting) SWT.error(2);
/* 739 */     this.printer = gtkPrinterFromPrinterData(this.data);
/* 740 */     if (this.printer == 0L) { SWT.error(2);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void init()
/*     */   {
/* 757 */     this.settings = GTK.gtk_print_settings_new();
/* 758 */     this.pageSetup = GTK.gtk_page_setup_new();
/* 759 */     if (this.data.otherData != null) {
/* 760 */       restore(this.data.otherData, this.settings, this.pageSetup);
/*     */     }
/*     */     
/*     */ 
/* 764 */     if ((this.data.printToFile) && (this.data.fileName != null)) {
/* 765 */       byte[] uri = uriFromFilename(this.data.fileName);
/* 766 */       if (uri != null) {
/* 767 */         GTK.gtk_print_settings_set(this.settings, GTK.GTK_PRINT_SETTINGS_OUTPUT_URI, uri);
/*     */       }
/*     */     }
/* 770 */     GTK.gtk_print_settings_set_n_copies(this.settings, this.data.copyCount);
/* 771 */     GTK.gtk_print_settings_set_collate(this.settings, this.data.collate);
/* 772 */     if (this.data.duplex != -1) {
/* 773 */       int duplex = this.data.duplex == 2 ? 2 : this.data.duplex == 1 ? 1 : 0;
/*     */       
/*     */ 
/* 776 */       GTK.gtk_print_settings_set_duplex(this.settings, duplex);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 782 */       String cupsDuplexType = null;
/* 783 */       if (duplex == 1) { cupsDuplexType = "DuplexNoTumble";
/* 784 */       } else if (duplex == 2) cupsDuplexType = "DuplexTumble";
/* 785 */       if (cupsDuplexType != null) {
/* 786 */         byte[] keyBuffer = Converter.wcsToMbcs("cups-Duplex", true);
/* 787 */         byte[] valueBuffer = Converter.wcsToMbcs(cupsDuplexType, true);
/* 788 */         GTK.gtk_print_settings_set(this.settings, keyBuffer, valueBuffer);
/*     */       }
/*     */     }
/* 791 */     int orientation = this.data.orientation == 2 ? 1 : 0;
/* 792 */     GTK.gtk_page_setup_set_orientation(this.pageSetup, orientation);
/* 793 */     GTK.gtk_print_settings_set_orientation(this.settings, orientation);
/* 794 */     super.init();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PrinterData getPrinterData()
/*     */   {
/* 804 */     checkDevice();
/* 805 */     return this.data;
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/printing/Printer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */