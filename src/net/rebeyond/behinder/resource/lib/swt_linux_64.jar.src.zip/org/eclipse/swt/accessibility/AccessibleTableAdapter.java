package org.eclipse.swt.accessibility;

public class AccessibleTableAdapter
  implements AccessibleTableListener
{
  public void deselectColumn(AccessibleTableEvent e) {}
  
  public void deselectRow(AccessibleTableEvent e) {}
  
  @Deprecated
  public void getCaption(AccessibleTableEvent e) {}
  
  public void getCell(AccessibleTableEvent e) {}
  
  public void getColumn(AccessibleTableEvent e) {}
  
  public void getColumnCount(AccessibleTableEvent e) {}
  
  public void getColumnDescription(AccessibleTableEvent e) {}
  
  public void getColumnHeader(AccessibleTableEvent e) {}
  
  public void getColumnHeaderCells(AccessibleTableEvent e) {}
  
  public void getColumns(AccessibleTableEvent e) {}
  
  public void getRow(AccessibleTableEvent e) {}
  
  public void getRowCount(AccessibleTableEvent e) {}
  
  public void getRowDescription(AccessibleTableEvent e) {}
  
  public void getRowHeader(AccessibleTableEvent e) {}
  
  public void getRowHeaderCells(AccessibleTableEvent e) {}
  
  public void getRows(AccessibleTableEvent e) {}
  
  public void getSelectedCellCount(AccessibleTableEvent e) {}
  
  public void getSelectedCells(AccessibleTableEvent e) {}
  
  public void getSelectedColumnCount(AccessibleTableEvent e) {}
  
  public void getSelectedColumns(AccessibleTableEvent e) {}
  
  public void getSelectedRowCount(AccessibleTableEvent e) {}
  
  public void getSelectedRows(AccessibleTableEvent e) {}
  
  @Deprecated
  public void getSummary(AccessibleTableEvent e) {}
  
  public void getVisibleColumns(AccessibleTableEvent e) {}
  
  public void getVisibleRows(AccessibleTableEvent e) {}
  
  public void isColumnSelected(AccessibleTableEvent e) {}
  
  public void isRowSelected(AccessibleTableEvent e) {}
  
  public void selectColumn(AccessibleTableEvent e) {}
  
  public void selectRow(AccessibleTableEvent e) {}
  
  public void setSelectedColumn(AccessibleTableEvent e) {}
  
  public void setSelectedRow(AccessibleTableEvent e) {}
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/accessibility/AccessibleTableAdapter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */