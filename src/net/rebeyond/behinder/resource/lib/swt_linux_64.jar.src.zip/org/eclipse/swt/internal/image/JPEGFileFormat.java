/*      */ package org.eclipse.swt.internal.image;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import org.eclipse.swt.SWT;
/*      */ import org.eclipse.swt.graphics.ImageData;
/*      */ import org.eclipse.swt.graphics.ImageLoader;
/*      */ import org.eclipse.swt.graphics.ImageLoaderEvent;
/*      */ import org.eclipse.swt.graphics.PaletteData;
/*      */ import org.eclipse.swt.graphics.RGB;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class JPEGFileFormat
/*      */   extends FileFormat
/*      */ {
/*      */   int restartInterval;
/*      */   JPEGFrameHeader frameHeader;
/*      */   int imageWidth;
/*      */   int imageHeight;
/*      */   int interleavedMcuCols;
/*      */   int interleavedMcuRows;
/*      */   int maxV;
/*      */   int maxH;
/*      */   boolean progressive;
/*      */   int samplePrecision;
/*      */   int nComponents;
/*      */   int[][] frameComponents;
/*      */   int[] componentIds;
/*      */   byte[][] imageComponents;
/*      */   int[] dataUnit;
/*      */   int[][][] dataUnits;
/*      */   int[] precedingDCs;
/*      */   JPEGScanHeader scanHeader;
/*      */   byte[] dataBuffer;
/*      */   int currentBitCount;
/*      */   int bufferCurrentPosition;
/*      */   int restartsToGo;
/*      */   int nextRestartNumber;
/*      */   JPEGHuffmanTable[] acHuffmanTables;
/*      */   JPEGHuffmanTable[] dcHuffmanTables;
/*      */   int[][] quantizationTables;
/*      */   int currentByte;
/*   47 */   int encoderQFactor = 75;
/*   48 */   int eobrun = 0;
/*      */   
/*      */   public static final int DCTSIZE = 8;
/*      */   
/*      */   public static final int DCTSIZESQR = 64;
/*      */   
/*      */   public static final int FIX_0_899976223 = 7373;
/*      */   
/*      */   public static final int FIX_1_961570560 = 16069;
/*      */   
/*      */   public static final int FIX_2_053119869 = 16819;
/*      */   
/*      */   public static final int FIX_0_298631336 = 2446;
/*      */   public static final int FIX_1_847759065 = 15137;
/*      */   public static final int FIX_1_175875602 = 9633;
/*      */   public static final int FIX_3_072711026 = 25172;
/*      */   public static final int FIX_0_765366865 = 6270;
/*      */   public static final int FIX_2_562915447 = 20995;
/*      */   public static final int FIX_0_541196100 = 4433;
/*      */   public static final int FIX_0_390180644 = 3196;
/*      */   public static final int FIX_1_501321110 = 12299;
/*      */   public static final int APP0 = 65504;
/*      */   public static final int APP15 = 65519;
/*      */   public static final int COM = 65534;
/*      */   public static final int DAC = 65484;
/*      */   public static final int DHP = 65502;
/*      */   public static final int DHT = 65476;
/*      */   public static final int DNL = 65500;
/*      */   public static final int DRI = 65501;
/*      */   public static final int DQT = 65499;
/*      */   public static final int EOI = 65497;
/*      */   public static final int EXP = 65503;
/*      */   public static final int JPG = 65480;
/*      */   public static final int JPG0 = 65520;
/*      */   public static final int JPG13 = 65533;
/*      */   public static final int RST0 = 65488;
/*      */   public static final int RST1 = 65489;
/*      */   public static final int RST2 = 65490;
/*      */   public static final int RST3 = 65491;
/*      */   public static final int RST4 = 65492;
/*      */   public static final int RST5 = 65493;
/*      */   public static final int RST6 = 65494;
/*      */   public static final int RST7 = 65495;
/*      */   public static final int SOF0 = 65472;
/*      */   public static final int SOF1 = 65473;
/*      */   public static final int SOF2 = 65474;
/*      */   public static final int SOF3 = 65475;
/*      */   public static final int SOF5 = 65477;
/*      */   public static final int SOF6 = 65478;
/*      */   public static final int SOF7 = 65479;
/*      */   public static final int SOF9 = 65481;
/*      */   public static final int SOF10 = 65482;
/*      */   public static final int SOF11 = 65483;
/*      */   public static final int SOF13 = 65485;
/*      */   public static final int SOF14 = 65486;
/*      */   public static final int SOF15 = 65487;
/*      */   public static final int SOI = 65496;
/*      */   public static final int SOS = 65498;
/*      */   public static final int TEM = 65281;
/*      */   public static final int TQI = 0;
/*      */   public static final int HI = 1;
/*      */   public static final int VI = 2;
/*      */   public static final int CW = 3;
/*      */   public static final int CH = 4;
/*      */   public static final int DC = 0;
/*      */   public static final int AC = 1;
/*      */   public static final int ID_Y = 0;
/*      */   public static final int ID_CB = 1;
/*      */   public static final int ID_CR = 2;
/*  117 */   public static final RGB[] RGB16 = { new RGB(0, 0, 0), new RGB(128, 0, 0), new RGB(0, 128, 0), new RGB(128, 128, 0), new RGB(0, 0, 128), new RGB(128, 0, 128), new RGB(0, 128, 128), new RGB(192, 192, 192), new RGB(128, 128, 128), new RGB(255, 0, 0), new RGB(0, 255, 0), new RGB(255, 255, 0), new RGB(0, 0, 255), new RGB(255, 0, 255), new RGB(0, 255, 255), new RGB(255, 255, 255) };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  135 */   public static final int[] ExtendTest = { 0, 1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024, 2048, 4096, 8192, 16384, 32768, 65536, 131072, 262144 };
/*      */   
/*      */ 
/*      */ 
/*  139 */   public static final int[] ExtendOffset = { 0, -1, -3, -7, -15, -31, -63, -127, 65281, 65025, 64513, 63489, 61441, 57345, 49153, 32769, -65535, -131071, -262143 };
/*      */   
/*      */ 
/*      */ 
/*  143 */   public static final int[] ZigZag8x8 = { 0, 1, 8, 16, 9, 2, 3, 10, 17, 24, 32, 25, 18, 11, 4, 5, 12, 19, 26, 33, 40, 48, 41, 34, 27, 20, 13, 6, 7, 14, 21, 28, 35, 42, 49, 56, 57, 50, 43, 36, 29, 22, 15, 23, 30, 37, 44, 51, 58, 59, 52, 45, 38, 31, 39, 46, 53, 60, 61, 54, 47, 55, 62, 63 };
/*      */   public static final int[] CrRTable;
/*      */   public static final int[] CbBTable;
/*      */   public static final int[] CrGTable;
/*      */   public static final int[] CbGTable;
/*      */   public static final int[] RYTable;
/*      */   public static final int[] GYTable;
/*      */   public static final int[] BYTable;
/*      */   public static final int[] RCbTable;
/*      */   public static final int[] GCbTable;
/*      */   public static final int[] BCbTable;
/*      */   public static final int[] RCrTable;
/*      */   public static final int[] GCrTable;
/*      */   public static final int[] BCrTable;
/*      */   public static final int[] NBitsTable;
/*      */   
/*  159 */   static { int[] rYTable = new int['Ā'];
/*  160 */     int[] gYTable = new int['Ā'];
/*  161 */     int[] bYTable = new int['Ā'];
/*  162 */     int[] rCbTable = new int['Ā'];
/*  163 */     int[] gCbTable = new int['Ā'];
/*  164 */     int[] bCbTable = new int['Ā'];
/*  165 */     int[] gCrTable = new int['Ā'];
/*  166 */     int[] bCrTable = new int['Ā'];
/*  167 */     for (int i = 0; i < 256; i++) {
/*  168 */       rYTable[i] = (i * 19595);
/*  169 */       gYTable[i] = (i * 38470);
/*  170 */       bYTable[i] = (i * 7471 + 32768);
/*  171 */       rCbTable[i] = (i * 54477);
/*  172 */       gCbTable[i] = (i * 43827);
/*  173 */       bCbTable[i] = (i * 32768 + 8388608);
/*  174 */       gCrTable[i] = (i * 38097);
/*  175 */       bCrTable[i] = (i * 60207);
/*      */     }
/*  177 */     RYTable = rYTable;
/*  178 */     GYTable = gYTable;
/*  179 */     BYTable = bYTable;
/*  180 */     RCbTable = rCbTable;
/*  181 */     GCbTable = gCbTable;
/*  182 */     BCbTable = bCbTable;
/*  183 */     RCrTable = bCbTable;
/*  184 */     GCrTable = gCrTable;
/*  185 */     BCrTable = bCrTable;
/*      */     
/*      */ 
/*  188 */     int[] crRTable = new int['Ā'];
/*  189 */     int[] cbBTable = new int['Ā'];
/*  190 */     int[] crGTable = new int['Ā'];
/*  191 */     int[] cbGTable = new int['Ā'];
/*  192 */     for (int i = 0; i < 256; i++) {
/*  193 */       int x2 = 2 * i - 255;
/*  194 */       crRTable[i] = (45941 * x2 + 32768 >> 16);
/*  195 */       cbBTable[i] = (58065 * x2 + 32768 >> 16);
/*  196 */       crGTable[i] = (42135 * x2);
/*  197 */       cbGTable[i] = (54259 * x2 + 32768);
/*      */     }
/*  199 */     CrRTable = crRTable;
/*  200 */     CbBTable = cbBTable;
/*  201 */     CrGTable = crGTable;
/*  202 */     CbGTable = cbGTable;
/*      */     
/*      */ 
/*  205 */     int nBits = 1;
/*  206 */     int power2 = 2;
/*  207 */     int[] nBitsTable = new int['ࠀ'];
/*  208 */     nBitsTable[0] = 0;
/*  209 */     for (int i = 1; i < nBitsTable.length; i++) {
/*  210 */       if (i >= power2) {
/*  211 */         nBits++;
/*  212 */         power2 *= 2;
/*      */       }
/*  214 */       nBitsTable[i] = nBits;
/*      */     }
/*  216 */     NBitsTable = nBitsTable;
/*      */   }
/*      */   
/*  219 */   void compress(ImageData image, byte[] dataYComp, byte[] dataCbComp, byte[] dataCrComp) { int srcWidth = image.width;
/*  220 */     int srcHeight = image.height;
/*  221 */     int vhFactor = this.maxV * this.maxH;
/*      */     
/*  223 */     this.imageComponents = new byte[this.nComponents][];
/*  224 */     for (int i = 0; i < this.nComponents; i++) {
/*  225 */       int[] frameComponent = this.frameComponents[this.componentIds[i]];
/*  226 */       this.imageComponents[i] = new byte[frameComponent[3] * frameComponent[4]];
/*      */     }
/*  228 */     int[] frameComponent = this.frameComponents[this.componentIds[0]];
/*  229 */     for (int yPos = 0; yPos < srcHeight; yPos++) {
/*  230 */       int srcOfs = yPos * srcWidth;
/*  231 */       int dstOfs = yPos * frameComponent[3];
/*  232 */       System.arraycopy(dataYComp, srcOfs, this.imageComponents[0], dstOfs, srcWidth);
/*      */     }
/*  234 */     frameComponent = this.frameComponents[this.componentIds[1]];
/*  235 */     for (int yPos = 0; yPos < srcHeight / this.maxV; yPos++) {
/*  236 */       int destRowIndex = yPos * frameComponent[3];
/*  237 */       for (int xPos = 0; xPos < srcWidth / this.maxH; xPos++) {
/*  238 */         int sum = 0;
/*  239 */         for (int iv = 0; iv < this.maxV; iv++) {
/*  240 */           int srcIndex = (yPos * this.maxV + iv) * srcWidth + xPos * this.maxH;
/*  241 */           for (int ih = 0; ih < this.maxH; ih++) {
/*  242 */             sum += (dataCbComp[(srcIndex + ih)] & 0xFF);
/*      */           }
/*      */         }
/*  245 */         this.imageComponents[1][(destRowIndex + xPos)] = ((byte)(sum / vhFactor));
/*      */       }
/*      */     }
/*  248 */     frameComponent = this.frameComponents[this.componentIds[2]];
/*  249 */     for (int yPos = 0; yPos < srcHeight / this.maxV; yPos++) {
/*  250 */       int destRowIndex = yPos * frameComponent[3];
/*  251 */       for (int xPos = 0; xPos < srcWidth / this.maxH; xPos++) {
/*  252 */         int sum = 0;
/*  253 */         for (int iv = 0; iv < this.maxV; iv++) {
/*  254 */           int srcIndex = (yPos * this.maxV + iv) * srcWidth + xPos * this.maxH;
/*  255 */           for (int ih = 0; ih < this.maxH; ih++) {
/*  256 */             sum += (dataCrComp[(srcIndex + ih)] & 0xFF);
/*      */           }
/*      */         }
/*  259 */         this.imageComponents[2][(destRowIndex + xPos)] = ((byte)(sum / vhFactor));
/*      */       }
/*      */     }
/*  262 */     for (int iComp = 0; iComp < this.nComponents; iComp++) {
/*  263 */       byte[] imageComponent = this.imageComponents[iComp];
/*  264 */       frameComponent = this.frameComponents[this.componentIds[iComp]];
/*  265 */       int hFactor = frameComponent[1];
/*  266 */       int vFactor = frameComponent[2];
/*  267 */       int componentWidth = frameComponent[3];
/*  268 */       int componentHeight = frameComponent[4];
/*  269 */       int compressedWidth = srcWidth / (this.maxH / hFactor);
/*  270 */       int compressedHeight = srcHeight / (this.maxV / vFactor);
/*  271 */       if (compressedWidth < componentWidth) {
/*  272 */         int delta = componentWidth - compressedWidth;
/*  273 */         for (int yPos = 0; yPos < compressedHeight; yPos++) {
/*  274 */           int dstOfs = (yPos + 1) * componentWidth - delta;
/*  275 */           int dataValue = imageComponent[0] & 0xFF;
/*  276 */           for (int i = 0; i < delta; i++) {
/*  277 */             imageComponent[(dstOfs + i)] = ((byte)dataValue);
/*      */           }
/*      */         }
/*      */       }
/*  281 */       if (compressedHeight < componentHeight) {
/*  282 */         int srcOfs = compressedHeight > 0 ? (compressedHeight - 1) * componentWidth : 1;
/*  283 */         for (int yPos = compressedHeight > 0 ? compressedHeight : 1; yPos <= componentHeight; yPos++) {
/*  284 */           int dstOfs = (yPos - 1) * componentWidth;
/*  285 */           System.arraycopy(imageComponent, srcOfs, imageComponent, dstOfs, componentWidth);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*  291 */   void convert4BitRGBToYCbCr(ImageData image) { RGB[] rgbs = image.getRGBs();
/*  292 */     int paletteSize = rgbs.length;
/*  293 */     byte[] yComp = new byte[paletteSize];
/*  294 */     byte[] cbComp = new byte[paletteSize];
/*  295 */     byte[] crComp = new byte[paletteSize];
/*  296 */     int srcWidth = image.width;
/*  297 */     int srcHeight = image.height;
/*  298 */     for (int i = 0; i < paletteSize; i++) {
/*  299 */       RGB color = rgbs[i];
/*  300 */       int r = color.red;
/*  301 */       int g = color.green;
/*  302 */       int b = color.blue;
/*  303 */       int n = RYTable[r] + GYTable[g] + BYTable[b];
/*  304 */       yComp[i] = ((byte)(n >> 16));
/*  305 */       if ((n < 0) && ((n & 0xFFFF) != 0)) { int tmp121_119 = i; byte[] tmp121_117 = yComp;tmp121_117[tmp121_119] = ((byte)(tmp121_117[tmp121_119] - 1)); }
/*  306 */       n = RCbTable[r] + GCbTable[g] + BCbTable[b];
/*  307 */       cbComp[i] = ((byte)(n >> 16));
/*  308 */       if ((n < 0) && ((n & 0xFFFF) != 0)) { int tmp177_175 = i; byte[] tmp177_173 = cbComp;tmp177_173[tmp177_175] = ((byte)(tmp177_173[tmp177_175] - 1)); }
/*  309 */       n = RCrTable[r] + GCrTable[g] + BCrTable[b];
/*  310 */       crComp[i] = ((byte)(n >> 16));
/*  311 */       if ((n < 0) && ((n & 0xFFFF) != 0)) { int tmp233_231 = i; byte[] tmp233_229 = crComp;tmp233_229[tmp233_231] = ((byte)(tmp233_229[tmp233_231] - 1));
/*      */       } }
/*  313 */     int bSize = srcWidth * srcHeight;
/*  314 */     byte[] dataYComp = new byte[bSize];
/*  315 */     byte[] dataCbComp = new byte[bSize];
/*  316 */     byte[] dataCrComp = new byte[bSize];
/*  317 */     byte[] origData = image.data;
/*  318 */     int bytesPerLine = image.bytesPerLine;
/*  319 */     int maxScanlineByte = srcWidth >> 1;
/*  320 */     for (int yPos = 0; yPos < srcHeight; yPos++) {
/*  321 */       for (int xPos = 0; xPos < maxScanlineByte; xPos++) {
/*  322 */         int srcIndex = yPos * bytesPerLine + xPos;
/*  323 */         int dstIndex = yPos * srcWidth + xPos * 2;
/*  324 */         int value2 = origData[srcIndex] & 0xFF;
/*  325 */         int value1 = value2 >> 4;
/*  326 */         value2 &= 0xF;
/*  327 */         dataYComp[dstIndex] = yComp[value1];
/*  328 */         dataCbComp[dstIndex] = cbComp[value1];
/*  329 */         dataCrComp[dstIndex] = crComp[value1];
/*  330 */         dataYComp[(dstIndex + 1)] = yComp[value2];
/*  331 */         dataCbComp[(dstIndex + 1)] = cbComp[value2];
/*  332 */         dataCrComp[(dstIndex + 1)] = crComp[value2];
/*      */       }
/*      */     }
/*  335 */     compress(image, dataYComp, dataCbComp, dataCrComp);
/*      */   }
/*      */   
/*  338 */   void convert8BitRGBToYCbCr(ImageData image) { RGB[] rgbs = image.getRGBs();
/*  339 */     int paletteSize = rgbs.length;
/*  340 */     byte[] yComp = new byte[paletteSize];
/*  341 */     byte[] cbComp = new byte[paletteSize];
/*  342 */     byte[] crComp = new byte[paletteSize];
/*  343 */     int srcWidth = image.width;
/*  344 */     int srcHeight = image.height;
/*  345 */     for (int i = 0; i < paletteSize; i++) {
/*  346 */       RGB color = rgbs[i];
/*  347 */       int r = color.red;
/*  348 */       int g = color.green;
/*  349 */       int b = color.blue;
/*  350 */       int n = RYTable[r] + GYTable[g] + BYTable[b];
/*  351 */       yComp[i] = ((byte)(n >> 16));
/*  352 */       if ((n < 0) && ((n & 0xFFFF) != 0)) { int tmp121_119 = i; byte[] tmp121_117 = yComp;tmp121_117[tmp121_119] = ((byte)(tmp121_117[tmp121_119] - 1)); }
/*  353 */       n = RCbTable[r] + GCbTable[g] + BCbTable[b];
/*  354 */       cbComp[i] = ((byte)(n >> 16));
/*  355 */       if ((n < 0) && ((n & 0xFFFF) != 0)) { int tmp177_175 = i; byte[] tmp177_173 = cbComp;tmp177_173[tmp177_175] = ((byte)(tmp177_173[tmp177_175] - 1)); }
/*  356 */       n = RCrTable[r] + GCrTable[g] + BCrTable[b];
/*  357 */       crComp[i] = ((byte)(n >> 16));
/*  358 */       if ((n < 0) && ((n & 0xFFFF) != 0)) { int tmp233_231 = i; byte[] tmp233_229 = crComp;tmp233_229[tmp233_231] = ((byte)(tmp233_229[tmp233_231] - 1));
/*      */       } }
/*  360 */     int dstWidth = image.width;
/*  361 */     int dstHeight = srcHeight;
/*  362 */     int stride = srcWidth + 3 >> 2 << 2;
/*  363 */     int bSize = dstWidth * dstHeight;
/*  364 */     byte[] dataYComp = new byte[bSize];
/*  365 */     byte[] dataCbComp = new byte[bSize];
/*  366 */     byte[] dataCrComp = new byte[bSize];
/*  367 */     byte[] origData = image.data;
/*  368 */     for (int yPos = 0; yPos < srcHeight; yPos++) {
/*  369 */       int srcRowIndex = yPos * stride;
/*  370 */       int dstRowIndex = yPos * dstWidth;
/*  371 */       for (int xPos = 0; xPos < srcWidth; xPos++) {
/*  372 */         int value = origData[(srcRowIndex + xPos)] & 0xFF;
/*  373 */         int dstIndex = dstRowIndex + xPos;
/*  374 */         dataYComp[dstIndex] = yComp[value];
/*  375 */         dataCbComp[dstIndex] = cbComp[value];
/*  376 */         dataCrComp[dstIndex] = crComp[value];
/*      */       }
/*      */     }
/*  379 */     compress(image, dataYComp, dataCbComp, dataCrComp);
/*      */   }
/*      */   
/*      */ 
/*  383 */   byte[] convertCMYKToRGB() { return new byte[0]; }
/*      */   
/*      */   void convertImageToYCbCr(ImageData image) {
/*  386 */     switch (image.depth) {
/*      */     case 4: 
/*  388 */       convert4BitRGBToYCbCr(image);
/*  389 */       return;
/*      */     case 8: 
/*  391 */       convert8BitRGBToYCbCr(image);
/*  392 */       return;
/*      */     case 16: 
/*      */     case 24: 
/*      */     case 32: 
/*  396 */       convertMultiRGBToYCbCr(image);
/*  397 */       return;
/*      */     }
/*  399 */     SWT.error(38);
/*      */   }
/*      */   
/*      */   void convertMultiRGBToYCbCr(ImageData image)
/*      */   {
/*  404 */     int srcWidth = image.width;
/*  405 */     int srcHeight = image.height;
/*  406 */     int bSize = srcWidth * srcHeight;
/*  407 */     byte[] dataYComp = new byte[bSize];
/*  408 */     byte[] dataCbComp = new byte[bSize];
/*  409 */     byte[] dataCrComp = new byte[bSize];
/*  410 */     PaletteData palette = image.palette;
/*  411 */     int[] buffer = new int[srcWidth];
/*  412 */     if (palette.isDirect) {
/*  413 */       int redMask = palette.redMask;
/*  414 */       int greenMask = palette.greenMask;
/*  415 */       int blueMask = palette.blueMask;
/*  416 */       int redShift = palette.redShift;
/*  417 */       int greenShift = palette.greenShift;
/*  418 */       int blueShift = palette.blueShift;
/*  419 */       for (int yPos = 0; yPos < srcHeight; yPos++) {
/*  420 */         image.getPixels(0, yPos, srcWidth, buffer, 0);
/*  421 */         int dstRowIndex = yPos * srcWidth;
/*  422 */         for (int xPos = 0; xPos < srcWidth; xPos++) {
/*  423 */           int pixel = buffer[xPos];
/*  424 */           int dstDataIndex = dstRowIndex + xPos;
/*  425 */           int r = pixel & redMask;
/*  426 */           r = redShift < 0 ? r >>> -redShift : r << redShift;
/*  427 */           int g = pixel & greenMask;
/*  428 */           g = greenShift < 0 ? g >>> -greenShift : g << greenShift;
/*  429 */           int b = pixel & blueMask;
/*  430 */           b = blueShift < 0 ? b >>> -blueShift : b << blueShift;
/*  431 */           dataYComp[dstDataIndex] = ((byte)(RYTable[r] + GYTable[g] + BYTable[b] >> 16));
/*  432 */           dataCbComp[dstDataIndex] = ((byte)(RCbTable[r] + GCbTable[g] + BCbTable[b] >> 16));
/*  433 */           dataCrComp[dstDataIndex] = ((byte)(RCrTable[r] + GCrTable[g] + BCrTable[b] >> 16));
/*      */         }
/*      */       }
/*      */     } else {
/*  437 */       for (int yPos = 0; yPos < srcHeight; yPos++) {
/*  438 */         image.getPixels(0, yPos, srcWidth, buffer, 0);
/*  439 */         int dstRowIndex = yPos * srcWidth;
/*  440 */         for (int xPos = 0; xPos < srcWidth; xPos++) {
/*  441 */           int pixel = buffer[xPos];
/*  442 */           int dstDataIndex = dstRowIndex + xPos;
/*  443 */           RGB rgb = palette.getRGB(pixel);
/*  444 */           int r = rgb.red;
/*  445 */           int g = rgb.green;
/*  446 */           int b = rgb.blue;
/*  447 */           dataYComp[dstDataIndex] = ((byte)(RYTable[r] + GYTable[g] + BYTable[b] >> 16));
/*  448 */           dataCbComp[dstDataIndex] = ((byte)(RCbTable[r] + GCbTable[g] + BCbTable[b] >> 16));
/*  449 */           dataCrComp[dstDataIndex] = ((byte)(RCrTable[r] + GCrTable[g] + BCrTable[b] >> 16));
/*      */         }
/*      */       }
/*      */     }
/*  453 */     compress(image, dataYComp, dataCbComp, dataCrComp);
/*      */   }
/*      */   
/*  456 */   byte[] convertYToRGB() { int compWidth = this.frameComponents[this.componentIds[0]][3];
/*  457 */     int bytesPerLine = ((this.imageWidth * 8 + 7) / 8 + 3) / 4 * 4;
/*  458 */     byte[] data = new byte[bytesPerLine * this.imageHeight];
/*  459 */     byte[] yComp = this.imageComponents[0];
/*  460 */     int destIndex = 0;
/*  461 */     for (int i = 0; i < this.imageHeight; i++) {
/*  462 */       int srcIndex = i * compWidth;
/*  463 */       for (int j = 0; j < bytesPerLine; j++) {
/*  464 */         int y = yComp[srcIndex] & 0xFF;
/*  465 */         if (y < 0) {
/*  466 */           y = 0;
/*      */         }
/*  468 */         else if (y > 255) { y = 255;
/*      */         }
/*  470 */         if (j >= this.imageWidth) {
/*  471 */           y = 0;
/*      */         }
/*  473 */         data[destIndex] = ((byte)y);
/*  474 */         srcIndex++;
/*  475 */         destIndex++;
/*      */       }
/*      */     }
/*  478 */     return data;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   byte[] convertYCbCrToRGB()
/*      */   {
/*  508 */     int bSize = this.imageWidth * this.imageHeight * this.nComponents;
/*  509 */     byte[] rgbData = new byte[bSize];
/*  510 */     int destIndex = 0;
/*  511 */     expandImageComponents();
/*  512 */     byte[] yComp = this.imageComponents[0];
/*  513 */     byte[] cbComp = this.imageComponents[1];
/*  514 */     byte[] crComp = this.imageComponents[2];
/*  515 */     int compWidth = this.frameComponents[this.componentIds[0]][3];
/*  516 */     for (int v = 0; v < this.imageHeight; v++) {
/*  517 */       int srcIndex = v * compWidth;
/*  518 */       for (int i = 0; i < this.imageWidth; i++) {
/*  519 */         int y = yComp[srcIndex] & 0xFF;
/*  520 */         int cb = cbComp[srcIndex] & 0xFF;
/*  521 */         int cr = crComp[srcIndex] & 0xFF;
/*  522 */         int r = y + CrRTable[cr];
/*  523 */         int g = y + (CbGTable[cb] + CrGTable[cr] >> 16);
/*  524 */         int b = y + CbBTable[cb];
/*  525 */         if (r < 0) {
/*  526 */           r = 0;
/*      */         }
/*  528 */         else if (r > 255) { r = 255;
/*      */         }
/*  530 */         if (g < 0) {
/*  531 */           g = 0;
/*      */         }
/*  533 */         else if (g > 255) { g = 255;
/*      */         }
/*  535 */         if (b < 0) {
/*  536 */           b = 0;
/*      */         }
/*  538 */         else if (b > 255) { b = 255;
/*      */         }
/*  540 */         rgbData[destIndex] = ((byte)b);
/*  541 */         rgbData[(destIndex + 1)] = ((byte)g);
/*  542 */         rgbData[(destIndex + 2)] = ((byte)r);
/*  543 */         destIndex += 3;
/*  544 */         srcIndex++;
/*      */       }
/*      */     }
/*  547 */     return rgbData;
/*      */   }
/*      */   
/*  550 */   void decodeACCoefficients(int[] dataUnit, int iComp) { int[] sParams = this.scanHeader.componentParameters[this.componentIds[iComp]];
/*  551 */     JPEGHuffmanTable acTable = this.acHuffmanTables[sParams[1]];
/*  552 */     int k = 1;
/*  553 */     while (k < 64) {
/*  554 */       int rs = decodeUsingTable(acTable);
/*  555 */       int r = rs >> 4;
/*  556 */       int s = rs & 0xF;
/*  557 */       if (s == 0) {
/*  558 */         if (r != 15) break;
/*  559 */         k += 16;
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*  564 */         k += r;
/*  565 */         int bits = receive(s);
/*  566 */         dataUnit[ZigZag8x8[k]] = extendBy(bits, s);
/*  567 */         k++;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*  572 */   void decodeACFirstCoefficients(int[] dataUnit, int iComp, int start, int end, int approxBit) { if (this.eobrun > 0) {
/*  573 */       this.eobrun -= 1;
/*  574 */       return;
/*      */     }
/*  576 */     int[] sParams = this.scanHeader.componentParameters[this.componentIds[iComp]];
/*  577 */     JPEGHuffmanTable acTable = this.acHuffmanTables[sParams[1]];
/*  578 */     int k = start;
/*  579 */     while (k <= end) {
/*  580 */       int rs = decodeUsingTable(acTable);
/*  581 */       int r = rs >> 4;
/*  582 */       int s = rs & 0xF;
/*  583 */       if (s == 0) {
/*  584 */         if (r == 15) {
/*  585 */           k += 16;
/*      */         } else {
/*  587 */           this.eobrun = ((1 << r) + receive(r) - 1);
/*  588 */           break;
/*      */         }
/*      */       } else {
/*  591 */         k += r;
/*  592 */         int bits = receive(s);
/*  593 */         dataUnit[ZigZag8x8[k]] = (extendBy(bits, s) << approxBit);
/*  594 */         k++;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*  599 */   void decodeACRefineCoefficients(int[] dataUnit, int iComp, int start, int end, int approxBit) { int[] sParams = this.scanHeader.componentParameters[this.componentIds[iComp]];
/*  600 */     JPEGHuffmanTable acTable = this.acHuffmanTables[sParams[1]];
/*  601 */     int k = start;
/*  602 */     while (k <= end)
/*  603 */       if (this.eobrun > 0) {
/*  604 */         while (k <= end) {
/*  605 */           int zzIndex = ZigZag8x8[k];
/*  606 */           if (dataUnit[zzIndex] != 0) {
/*  607 */             dataUnit[zzIndex] = refineAC(dataUnit[zzIndex], approxBit);
/*      */           }
/*  609 */           k++;
/*      */         }
/*  611 */         this.eobrun -= 1;
/*      */       } else {
/*  613 */         int rs = decodeUsingTable(acTable);
/*  614 */         int r = rs >> 4;
/*  615 */         int s = rs & 0xF;
/*  616 */         if (s == 0) {
/*  617 */           if (r == 15) {
/*  618 */             int zeros = 0;
/*  619 */             while ((zeros < 16) && (k <= end)) {
/*  620 */               int zzIndex = ZigZag8x8[k];
/*  621 */               if (dataUnit[zzIndex] != 0) {
/*  622 */                 dataUnit[zzIndex] = refineAC(dataUnit[zzIndex], approxBit);
/*      */               } else {
/*  624 */                 zeros++;
/*      */               }
/*  626 */               k++;
/*      */             }
/*      */           } else {
/*  629 */             this.eobrun = ((1 << r) + receive(r));
/*      */           }
/*      */         } else {
/*  632 */           int bit = receive(s);
/*  633 */           int zeros = 0;
/*  634 */           int zzIndex = ZigZag8x8[k];
/*  635 */           while (((zeros < r) || (dataUnit[zzIndex] != 0)) && (k <= end)) {
/*  636 */             if (dataUnit[zzIndex] != 0) {
/*  637 */               dataUnit[zzIndex] = refineAC(dataUnit[zzIndex], approxBit);
/*      */             } else {
/*  639 */               zeros++;
/*      */             }
/*  641 */             k++;
/*  642 */             zzIndex = ZigZag8x8[k];
/*      */           }
/*  644 */           if (bit != 0) {
/*  645 */             dataUnit[zzIndex] = (1 << approxBit);
/*      */           } else {
/*  647 */             dataUnit[zzIndex] = (-1 << approxBit);
/*      */           }
/*  649 */           k++;
/*      */         }
/*      */       }
/*      */   }
/*      */   
/*      */   int refineAC(int ac, int approxBit) {
/*  655 */     if (ac > 0) {
/*  656 */       int bit = nextBit();
/*  657 */       if (bit != 0) {
/*  658 */         ac += (1 << approxBit);
/*      */       }
/*  660 */     } else if (ac < 0) {
/*  661 */       int bit = nextBit();
/*  662 */       if (bit != 0) {
/*  663 */         ac += (-1 << approxBit);
/*      */       }
/*      */     }
/*  666 */     return ac;
/*      */   }
/*      */   
/*  669 */   void decodeDCCoefficient(int[] dataUnit, int iComp, boolean first, int approxBit) { int[] sParams = this.scanHeader.componentParameters[this.componentIds[iComp]];
/*  670 */     JPEGHuffmanTable dcTable = this.dcHuffmanTables[sParams[0]];
/*  671 */     int lastDC = 0;
/*  672 */     if ((this.progressive) && (!first)) {
/*  673 */       int bit = nextBit();
/*  674 */       lastDC = dataUnit[0] + (bit << approxBit);
/*      */     } else {
/*  676 */       lastDC = this.precedingDCs[iComp];
/*  677 */       int nBits = decodeUsingTable(dcTable);
/*  678 */       if (nBits != 0) {
/*  679 */         int bits = receive(nBits);
/*  680 */         int diff = extendBy(bits, nBits);
/*  681 */         lastDC += diff;
/*  682 */         this.precedingDCs[iComp] = lastDC;
/*      */       }
/*  684 */       if (this.progressive) {
/*  685 */         lastDC <<= approxBit;
/*      */       }
/*      */     }
/*  688 */     dataUnit[0] = lastDC;
/*      */   }
/*      */   
/*  691 */   void dequantize(int[] dataUnit, int iComp) { int[] qTable = this.quantizationTables[this.frameComponents[this.componentIds[iComp]][0]];
/*  692 */     for (int i = 0; i < dataUnit.length; i++) {
/*  693 */       int zzIndex = ZigZag8x8[i];
/*  694 */       dataUnit[zzIndex] *= qTable[i];
/*      */     }
/*      */   }
/*      */   
/*  698 */   byte[] decodeImageComponents() { if (this.nComponents == 3) {
/*  699 */       return convertYCbCrToRGB();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  705 */     if (this.nComponents == 4) {
/*  706 */       return convertCMYKToRGB();
/*      */     }
/*  708 */     return convertYToRGB();
/*      */   }
/*      */   
/*  711 */   void decodeMCUAtXAndY(int xmcu, int ymcu, int nComponentsInScan, boolean first, int start, int end, int approxBit) { for (int iComp = 0; iComp < nComponentsInScan; iComp++) {
/*  712 */       int scanComponent = iComp;
/*  713 */       while (this.scanHeader.componentParameters[this.componentIds[scanComponent]] == null) {
/*  714 */         scanComponent++;
/*      */       }
/*  716 */       int[] frameComponent = this.frameComponents[this.componentIds[scanComponent]];
/*  717 */       int hi = frameComponent[1];
/*  718 */       int vi = frameComponent[2];
/*  719 */       if (nComponentsInScan == 1) {
/*  720 */         hi = 1;
/*  721 */         vi = 1;
/*      */       }
/*  723 */       int compWidth = frameComponent[3];
/*  724 */       for (int ivi = 0; ivi < vi; ivi++)
/*  725 */         for (int ihi = 0; ihi < hi; ihi++) {
/*  726 */           if (this.progressive)
/*      */           {
/*      */ 
/*  729 */             int index = (ymcu * vi + ivi) * compWidth + xmcu * hi + ihi;
/*  730 */             this.dataUnit = this.dataUnits[scanComponent][index];
/*  731 */             if (this.dataUnit == null) {
/*  732 */               this.dataUnit = new int[64];
/*  733 */               this.dataUnits[scanComponent][index] = this.dataUnit;
/*      */             }
/*      */           }
/*      */           else {
/*  737 */             for (int i = 0; i < this.dataUnit.length; i++) {
/*  738 */               this.dataUnit[i] = 0;
/*      */             }
/*      */           }
/*  741 */           if ((!this.progressive) || (this.scanHeader.isDCProgressiveScan())) {
/*  742 */             decodeDCCoefficient(this.dataUnit, scanComponent, first, approxBit);
/*      */           }
/*  744 */           if (!this.progressive) {
/*  745 */             decodeACCoefficients(this.dataUnit, scanComponent);
/*      */           } else {
/*  747 */             if (this.scanHeader.isACProgressiveScan()) {
/*  748 */               if (first) {
/*  749 */                 decodeACFirstCoefficients(this.dataUnit, scanComponent, start, end, approxBit);
/*      */               } else {
/*  751 */                 decodeACRefineCoefficients(this.dataUnit, scanComponent, start, end, approxBit);
/*      */               }
/*      */             }
/*  754 */             if (this.loader.hasListeners())
/*      */             {
/*      */ 
/*      */ 
/*  758 */               int[] temp = this.dataUnit;
/*  759 */               this.dataUnit = new int[64];
/*  760 */               System.arraycopy(temp, 0, this.dataUnit, 0, 64);
/*      */             }
/*      */           }
/*  763 */           if ((!this.progressive) || ((this.progressive) && (this.loader.hasListeners()))) {
/*  764 */             dequantize(this.dataUnit, scanComponent);
/*  765 */             inverseDCT(this.dataUnit);
/*  766 */             storeData(this.dataUnit, scanComponent, xmcu, ymcu, hi, ihi, vi, ivi);
/*      */           }
/*      */         }
/*      */     }
/*      */   }
/*      */   
/*      */   void decodeScan() {
/*  773 */     if ((this.progressive) && (!this.scanHeader.verifyProgressiveScan())) {
/*  774 */       SWT.error(40);
/*      */     }
/*  776 */     int nComponentsInScan = this.scanHeader.getNumberOfImageComponents();
/*  777 */     int mcuRowsInScan = this.interleavedMcuRows;
/*  778 */     int mcusPerRow = this.interleavedMcuCols;
/*  779 */     if (nComponentsInScan == 1)
/*      */     {
/*  781 */       int scanComponent = 0;
/*  782 */       while (this.scanHeader.componentParameters[this.componentIds[scanComponent]] == null) {
/*  783 */         scanComponent++;
/*      */       }
/*  785 */       int[] frameComponent = this.frameComponents[this.componentIds[scanComponent]];
/*  786 */       int hi = frameComponent[1];
/*  787 */       int vi = frameComponent[2];
/*  788 */       int mcuWidth = 8 * this.maxH / hi;
/*  789 */       int mcuHeight = 8 * this.maxV / vi;
/*  790 */       mcusPerRow = (this.imageWidth + mcuWidth - 1) / mcuWidth;
/*  791 */       mcuRowsInScan = (this.imageHeight + mcuHeight - 1) / mcuHeight;
/*      */     }
/*  793 */     boolean first = this.scanHeader.isFirstScan();
/*  794 */     int start = this.scanHeader.getStartOfSpectralSelection();
/*  795 */     int end = this.scanHeader.getEndOfSpectralSelection();
/*  796 */     int approxBit = this.scanHeader.getApproxBitPositionLow();
/*  797 */     this.restartsToGo = this.restartInterval;
/*  798 */     this.nextRestartNumber = 0;
/*  799 */     for (int ymcu = 0; ymcu < mcuRowsInScan; ymcu++)
/*  800 */       for (int xmcu = 0; xmcu < mcusPerRow; xmcu++) {
/*  801 */         if (this.restartInterval != 0) {
/*  802 */           if (this.restartsToGo == 0) processRestartInterval();
/*  803 */           this.restartsToGo -= 1;
/*      */         }
/*  805 */         decodeMCUAtXAndY(xmcu, ymcu, nComponentsInScan, first, start, end, approxBit);
/*      */       }
/*      */   }
/*      */   
/*      */   int decodeUsingTable(JPEGHuffmanTable huffmanTable) {
/*  810 */     int i = 0;
/*  811 */     int[] maxCodes = huffmanTable.getDhMaxCodes();
/*  812 */     int[] minCodes = huffmanTable.getDhMinCodes();
/*  813 */     int[] valPtrs = huffmanTable.getDhValPtrs();
/*  814 */     int[] huffVals = huffmanTable.getDhValues();
/*  815 */     int code = nextBit();
/*  816 */     while (code > maxCodes[i]) {
/*  817 */       code = code * 2 + nextBit();
/*  818 */       i++;
/*      */     }
/*  820 */     int j = valPtrs[i] + code - minCodes[i];
/*  821 */     return huffVals[j];
/*      */   }
/*      */   
/*  824 */   void emit(int huffCode, int nBits) { if (nBits == 0) {
/*  825 */       SWT.error(40);
/*      */     }
/*  827 */     int[] power2m1 = { 1, 3, 7, 15, 31, 63, 127, 255, 511, 1023, 2047, 4095, 8191, 16383, 32767, 65535, 131125 };
/*      */     
/*      */ 
/*      */ 
/*  831 */     int code = (huffCode & power2m1[(nBits - 1)]) << 24 - nBits - this.currentBitCount;
/*  832 */     byte[] codeBuffer = new byte[4];
/*  833 */     codeBuffer[0] = ((byte)(code & 0xFF));
/*  834 */     codeBuffer[1] = ((byte)(code >> 8 & 0xFF));
/*  835 */     codeBuffer[2] = ((byte)(code >> 16 & 0xFF));
/*  836 */     codeBuffer[3] = ((byte)(code >> 24 & 0xFF));
/*  837 */     int abs = nBits - (8 - this.currentBitCount);
/*  838 */     if (abs < 0) abs = -abs;
/*  839 */     if (abs >> 3 > 0) {
/*  840 */       this.currentByte += codeBuffer[2];
/*  841 */       emitByte((byte)this.currentByte);
/*  842 */       emitByte(codeBuffer[1]);
/*  843 */       this.currentByte = codeBuffer[0];
/*  844 */       this.currentBitCount += nBits - 16;
/*      */     } else {
/*  846 */       this.currentBitCount += nBits;
/*  847 */       if (this.currentBitCount >= 8) {
/*  848 */         this.currentByte += codeBuffer[2];
/*  849 */         emitByte((byte)this.currentByte);
/*  850 */         this.currentByte = codeBuffer[1];
/*  851 */         this.currentBitCount -= 8;
/*      */       } else {
/*  853 */         this.currentByte += codeBuffer[2];
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*  858 */   void emitByte(byte byteValue) { if (this.bufferCurrentPosition >= 512) {
/*  859 */       resetOutputBuffer();
/*      */     }
/*  861 */     this.dataBuffer[this.bufferCurrentPosition] = byteValue;
/*  862 */     this.bufferCurrentPosition += 1;
/*  863 */     if (byteValue == -1)
/*  864 */       emitByte((byte)0);
/*      */   }
/*      */   
/*      */   void encodeACCoefficients(int[] dataUnit, int iComp) {
/*  868 */     int[] sParams = this.scanHeader.componentParameters[iComp];
/*  869 */     JPEGHuffmanTable acTable = this.acHuffmanTables[sParams[1]];
/*  870 */     int[] ehCodes = acTable.ehCodes;
/*  871 */     byte[] ehSizes = acTable.ehCodeLengths;
/*  872 */     int r = 0;
/*  873 */     int k = 1;
/*  874 */     while (k < 64) {
/*  875 */       k++;
/*  876 */       int acValue = dataUnit[ZigZag8x8[(k - 1)]];
/*  877 */       if (acValue == 0) {
/*  878 */         if (k == 64) {
/*  879 */           emit(ehCodes[0], ehSizes[0] & 0xFF);
/*      */         } else {
/*  881 */           r++;
/*      */         }
/*      */       } else {
/*  884 */         while (r > 15) {
/*  885 */           emit(ehCodes['ð'], ehSizes['ð'] & 0xFF);
/*  886 */           r -= 16;
/*      */         }
/*  888 */         if (acValue < 0) {
/*  889 */           int absACValue = acValue;
/*  890 */           if (absACValue < 0) absACValue = -absACValue;
/*  891 */           int nBits = NBitsTable[absACValue];
/*  892 */           int rs = r * 16 + nBits;
/*  893 */           emit(ehCodes[rs], ehSizes[rs] & 0xFF);
/*  894 */           emit(16777215 - absACValue, nBits);
/*      */         } else {
/*  896 */           int nBits = NBitsTable[acValue];
/*  897 */           int rs = r * 16 + nBits;
/*  898 */           emit(ehCodes[rs], ehSizes[rs] & 0xFF);
/*  899 */           emit(acValue, nBits);
/*      */         }
/*  901 */         r = 0;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*  906 */   void encodeDCCoefficients(int[] dataUnit, int iComp) { int[] sParams = this.scanHeader.componentParameters[iComp];
/*  907 */     JPEGHuffmanTable dcTable = this.dcHuffmanTables[sParams[0]];
/*  908 */     int lastDC = this.precedingDCs[iComp];
/*  909 */     int dcValue = dataUnit[0];
/*  910 */     int diff = dcValue - lastDC;
/*  911 */     this.precedingDCs[iComp] = dcValue;
/*  912 */     if (diff < 0) {
/*  913 */       int absDiff = 0 - diff;
/*  914 */       int nBits = NBitsTable[absDiff];
/*  915 */       emit(dcTable.ehCodes[nBits], dcTable.ehCodeLengths[nBits]);
/*  916 */       emit(16777215 - absDiff, nBits);
/*      */     } else {
/*  918 */       int nBits = NBitsTable[diff];
/*  919 */       emit(dcTable.ehCodes[nBits], dcTable.ehCodeLengths[nBits]);
/*  920 */       if (nBits != 0)
/*  921 */         emit(diff, nBits);
/*      */     }
/*      */   }
/*      */   
/*      */   void encodeMCUAtXAndY(int xmcu, int ymcu) {
/*  926 */     int nComponentsInScan = this.scanHeader.getNumberOfImageComponents();
/*  927 */     this.dataUnit = new int[64];
/*  928 */     for (int iComp = 0; iComp < nComponentsInScan; iComp++) {
/*  929 */       int[] frameComponent = this.frameComponents[this.componentIds[iComp]];
/*  930 */       int hi = frameComponent[1];
/*  931 */       int vi = frameComponent[2];
/*  932 */       for (int ivi = 0; ivi < vi; ivi++)
/*  933 */         for (int ihi = 0; ihi < hi; ihi++) {
/*  934 */           extractData(this.dataUnit, iComp, xmcu, ymcu, ihi, ivi);
/*  935 */           forwardDCT(this.dataUnit);
/*  936 */           quantizeData(this.dataUnit, iComp);
/*  937 */           encodeDCCoefficients(this.dataUnit, iComp);
/*  938 */           encodeACCoefficients(this.dataUnit, iComp);
/*      */         }
/*      */     }
/*      */   }
/*      */   
/*      */   void encodeScan() {
/*  944 */     for (int ymcu = 0; ymcu < this.interleavedMcuRows; ymcu++) {
/*  945 */       for (int xmcu = 0; xmcu < this.interleavedMcuCols; xmcu++) {
/*  946 */         encodeMCUAtXAndY(xmcu, ymcu);
/*      */       }
/*      */     }
/*  949 */     if (this.currentBitCount != 0) {
/*  950 */       emitByte((byte)this.currentByte);
/*      */     }
/*  952 */     resetOutputBuffer();
/*      */   }
/*      */   
/*  955 */   void expandImageComponents() { for (int iComp = 0; iComp < this.nComponents; iComp++) {
/*  956 */       int[] frameComponent = this.frameComponents[this.componentIds[iComp]];
/*  957 */       int hi = frameComponent[1];
/*  958 */       int vi = frameComponent[2];
/*  959 */       int upH = this.maxH / hi;
/*  960 */       int upV = this.maxV / vi;
/*  961 */       if (upH * upV > 1) {
/*  962 */         byte[] component = this.imageComponents[iComp];
/*  963 */         int compWidth = frameComponent[3];
/*  964 */         int compHeight = frameComponent[4];
/*  965 */         int upCompWidth = compWidth * upH;
/*  966 */         int upCompHeight = compHeight * upV;
/*  967 */         ImageData src = new ImageData(compWidth, compHeight, 8, new PaletteData(RGB16), 4, component);
/*  968 */         ImageData dest = src.scaledTo(upCompWidth, upCompHeight);
/*  969 */         this.imageComponents[iComp] = dest.data;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*  974 */   int extendBy(int diff, int t) { if (diff < ExtendTest[t]) {
/*  975 */       return diff + ExtendOffset[t];
/*      */     }
/*  977 */     return diff;
/*      */   }
/*      */   
/*      */   void extractData(int[] dataUnit, int iComp, int xmcu, int ymcu, int ihi, int ivi) {
/*  981 */     byte[] compImage = this.imageComponents[iComp];
/*  982 */     int[] frameComponent = this.frameComponents[this.componentIds[iComp]];
/*  983 */     int hi = frameComponent[1];
/*  984 */     int vi = frameComponent[2];
/*  985 */     int compWidth = frameComponent[3];
/*  986 */     int srcIndex = (ymcu * vi + ivi) * compWidth * 8 + (xmcu * hi + ihi) * 8;
/*  987 */     int destIndex = 0;
/*  988 */     for (int i = 0; i < 8; i++) {
/*  989 */       for (int col = 0; col < 8; col++) {
/*  990 */         dataUnit[destIndex] = ((compImage[(srcIndex + col)] & 0xFF) - 128);
/*  991 */         destIndex++;
/*      */       }
/*  993 */       srcIndex += compWidth;
/*      */     }
/*      */   }
/*      */   
/*  997 */   void forwardDCT(int[] dataUnit) { for (int row = 0; row < 8; row++) {
/*  998 */       int rIndex = row * 8;
/*  999 */       int tmp0 = dataUnit[rIndex] + dataUnit[(rIndex + 7)];
/* 1000 */       int tmp7 = dataUnit[rIndex] - dataUnit[(rIndex + 7)];
/* 1001 */       int tmp1 = dataUnit[(rIndex + 1)] + dataUnit[(rIndex + 6)];
/* 1002 */       int tmp6 = dataUnit[(rIndex + 1)] - dataUnit[(rIndex + 6)];
/* 1003 */       int tmp2 = dataUnit[(rIndex + 2)] + dataUnit[(rIndex + 5)];
/* 1004 */       int tmp5 = dataUnit[(rIndex + 2)] - dataUnit[(rIndex + 5)];
/* 1005 */       int tmp3 = dataUnit[(rIndex + 3)] + dataUnit[(rIndex + 4)];
/* 1006 */       int tmp4 = dataUnit[(rIndex + 3)] - dataUnit[(rIndex + 4)];
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1012 */       int tmp10 = tmp0 + tmp3;
/* 1013 */       int tmp13 = tmp0 - tmp3;
/* 1014 */       int tmp11 = tmp1 + tmp2;
/* 1015 */       int tmp12 = tmp1 - tmp2;
/*      */       
/* 1017 */       dataUnit[rIndex] = ((tmp10 + tmp11) * 4);
/* 1018 */       dataUnit[(rIndex + 4)] = ((tmp10 - tmp11) * 4);
/*      */       
/* 1020 */       int z1 = (tmp12 + tmp13) * 4433;
/* 1021 */       int n = z1 + tmp13 * 6270 + 1024;
/* 1022 */       dataUnit[(rIndex + 2)] = (n >> 11);
/* 1023 */       if ((n < 0) && ((n & 0x7FF) != 0)) dataUnit[(rIndex + 2)] -= 1;
/* 1024 */       n = z1 + tmp12 * 50399 + 1024;
/* 1025 */       dataUnit[(rIndex + 6)] = (n >> 11);
/* 1026 */       if ((n < 0) && ((n & 0x7FF) != 0)) { dataUnit[(rIndex + 6)] -= 1;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1033 */       z1 = tmp4 + tmp7;
/* 1034 */       int z2 = tmp5 + tmp6;
/* 1035 */       int z3 = tmp4 + tmp6;
/* 1036 */       int z4 = tmp5 + tmp7;
/* 1037 */       int z5 = (z3 + z4) * 9633;
/*      */       
/* 1039 */       tmp4 *= 2446;
/* 1040 */       tmp5 *= 16819;
/* 1041 */       tmp6 *= 25172;
/* 1042 */       tmp7 *= 12299;
/* 1043 */       z1 *= 58163;
/* 1044 */       z2 *= 44541;
/* 1045 */       z3 *= 49467;
/* 1046 */       z4 *= 62340;
/*      */       
/* 1048 */       z3 += z5;
/* 1049 */       z4 += z5;
/*      */       
/* 1051 */       n = tmp4 + z1 + z3 + 1024;
/* 1052 */       dataUnit[(rIndex + 7)] = (n >> 11);
/* 1053 */       if ((n < 0) && ((n & 0x7FF) != 0)) dataUnit[(rIndex + 7)] -= 1;
/* 1054 */       n = tmp5 + z2 + z4 + 1024;
/* 1055 */       dataUnit[(rIndex + 5)] = (n >> 11);
/* 1056 */       if ((n < 0) && ((n & 0x7FF) != 0)) dataUnit[(rIndex + 5)] -= 1;
/* 1057 */       n = tmp6 + z2 + z3 + 1024;
/* 1058 */       dataUnit[(rIndex + 3)] = (n >> 11);
/* 1059 */       if ((n < 0) && ((n & 0x7FF) != 0)) dataUnit[(rIndex + 3)] -= 1;
/* 1060 */       n = tmp7 + z1 + z4 + 1024;
/* 1061 */       dataUnit[(rIndex + 1)] = (n >> 11);
/* 1062 */       if ((n < 0) && ((n & 0x7FF) != 0)) { dataUnit[(rIndex + 1)] -= 1;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1070 */     for (int col = 0; col < 8; col++) {
/* 1071 */       int c0 = col;
/* 1072 */       int c1 = col + 8;
/* 1073 */       int c2 = col + 16;
/* 1074 */       int c3 = col + 24;
/* 1075 */       int c4 = col + 32;
/* 1076 */       int c5 = col + 40;
/* 1077 */       int c6 = col + 48;
/* 1078 */       int c7 = col + 56;
/* 1079 */       int tmp0 = dataUnit[c0] + dataUnit[c7];
/* 1080 */       int tmp7 = dataUnit[c0] - dataUnit[c7];
/* 1081 */       int tmp1 = dataUnit[c1] + dataUnit[c6];
/* 1082 */       int tmp6 = dataUnit[c1] - dataUnit[c6];
/* 1083 */       int tmp2 = dataUnit[c2] + dataUnit[c5];
/* 1084 */       int tmp5 = dataUnit[c2] - dataUnit[c5];
/* 1085 */       int tmp3 = dataUnit[c3] + dataUnit[c4];
/* 1086 */       int tmp4 = dataUnit[c3] - dataUnit[c4];
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1092 */       int tmp10 = tmp0 + tmp3;
/* 1093 */       int tmp13 = tmp0 - tmp3;
/* 1094 */       int tmp11 = tmp1 + tmp2;
/* 1095 */       int tmp12 = tmp1 - tmp2;
/*      */       
/* 1097 */       int n = tmp10 + tmp11 + 16;
/* 1098 */       dataUnit[c0] = (n >> 5);
/* 1099 */       if ((n < 0) && ((n & 0x1F) != 0)) dataUnit[c0] -= 1;
/* 1100 */       n = tmp10 - tmp11 + 16;
/* 1101 */       dataUnit[c4] = (n >> 5);
/* 1102 */       if ((n < 0) && ((n & 0x1F) != 0)) { dataUnit[c4] -= 1;
/*      */       }
/* 1104 */       int z1 = (tmp12 + tmp13) * 4433;
/* 1105 */       n = z1 + tmp13 * 6270 + 131072;
/* 1106 */       dataUnit[c2] = (n >> 18);
/* 1107 */       if ((n < 0) && ((n & 0x3FFFF) != 0)) dataUnit[c2] -= 1;
/* 1108 */       n = z1 + tmp12 * 50399 + 131072;
/* 1109 */       dataUnit[c6] = (n >> 18);
/* 1110 */       if ((n < 0) && ((n & 0x3FFFF) != 0)) { dataUnit[c6] -= 1;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1117 */       z1 = tmp4 + tmp7;
/* 1118 */       int z2 = tmp5 + tmp6;
/* 1119 */       int z3 = tmp4 + tmp6;
/* 1120 */       int z4 = tmp5 + tmp7;
/* 1121 */       int z5 = (z3 + z4) * 9633;
/*      */       
/* 1123 */       tmp4 *= 2446;
/* 1124 */       tmp5 *= 16819;
/* 1125 */       tmp6 *= 25172;
/* 1126 */       tmp7 *= 12299;
/* 1127 */       z1 *= 58163;
/* 1128 */       z2 *= 44541;
/* 1129 */       z3 *= 49467;
/* 1130 */       z4 *= 62340;
/*      */       
/* 1132 */       z3 += z5;
/* 1133 */       z4 += z5;
/*      */       
/* 1135 */       n = tmp4 + z1 + z3 + 131072;
/* 1136 */       dataUnit[c7] = (n >> 18);
/* 1137 */       if ((n < 0) && ((n & 0x3FFFF) != 0)) dataUnit[c7] -= 1;
/* 1138 */       n = tmp5 + z2 + z4 + 131072;
/* 1139 */       dataUnit[c5] = (n >> 18);
/* 1140 */       if ((n < 0) && ((n & 0x3FFFF) != 0)) dataUnit[c5] -= 1;
/* 1141 */       n = tmp6 + z2 + z3 + 131072;
/* 1142 */       dataUnit[c3] = (n >> 18);
/* 1143 */       if ((n < 0) && ((n & 0x3FFFF) != 0)) dataUnit[c3] -= 1;
/* 1144 */       n = tmp7 + z1 + z4 + 131072;
/* 1145 */       dataUnit[c1] = (n >> 18);
/* 1146 */       if ((n < 0) && ((n & 0x3FFFF) != 0)) dataUnit[c1] -= 1;
/*      */     }
/*      */   }
/*      */   
/* 1150 */   void getAPP0() { JPEGAppn appn = new JPEGAppn(this.inputStream);
/* 1151 */     if (!appn.verify())
/* 1152 */       SWT.error(40);
/*      */   }
/*      */   
/*      */   void getCOM() {
/* 1156 */     new JPEGComment(this.inputStream);
/*      */   }
/*      */   
/* 1159 */   void getDAC() { new JPEGArithmeticConditioningTable(this.inputStream); }
/*      */   
/*      */   void getDHT() {
/* 1162 */     JPEGHuffmanTable dht = new JPEGHuffmanTable(this.inputStream);
/* 1163 */     if (!dht.verify()) {
/* 1164 */       SWT.error(40);
/*      */     }
/* 1166 */     if (this.acHuffmanTables == null) {
/* 1167 */       this.acHuffmanTables = new JPEGHuffmanTable[4];
/*      */     }
/* 1169 */     if (this.dcHuffmanTables == null) {
/* 1170 */       this.dcHuffmanTables = new JPEGHuffmanTable[4];
/*      */     }
/* 1172 */     JPEGHuffmanTable[] dhtTables = dht.getAllTables();
/* 1173 */     for (int i = 0; i < dhtTables.length; i++) {
/* 1174 */       JPEGHuffmanTable dhtTable = dhtTables[i];
/* 1175 */       if (dhtTable.getTableClass() == 0) {
/* 1176 */         this.dcHuffmanTables[dhtTable.getTableIdentifier()] = dhtTable;
/*      */       } else {
/* 1178 */         this.acHuffmanTables[dhtTable.getTableIdentifier()] = dhtTable;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/* 1183 */   void getDNL() { new JPEGRestartInterval(this.inputStream); }
/*      */   
/*      */   void getDQT() {
/* 1186 */     JPEGQuantizationTable dqt = new JPEGQuantizationTable(this.inputStream);
/* 1187 */     int[][] currentTables = this.quantizationTables;
/* 1188 */     if (currentTables == null) {
/* 1189 */       currentTables = new int[4][];
/*      */     }
/* 1191 */     int[] dqtTablesKeys = dqt.getQuantizationTablesKeys();
/* 1192 */     int[][] dqtTablesValues = dqt.getQuantizationTablesValues();
/* 1193 */     for (int i = 0; i < dqtTablesKeys.length; i++) {
/* 1194 */       int index = dqtTablesKeys[i];
/* 1195 */       currentTables[index] = dqtTablesValues[i];
/*      */     }
/* 1197 */     this.quantizationTables = currentTables;
/*      */   }
/*      */   
/* 1200 */   void getDRI() { JPEGRestartInterval dri = new JPEGRestartInterval(this.inputStream);
/* 1201 */     if (!dri.verify()) {
/* 1202 */       SWT.error(40);
/*      */     }
/* 1204 */     this.restartInterval = dri.getRestartInterval();
/*      */   }
/*      */   
/* 1207 */   void inverseDCT(int[] dataUnit) { for (int row = 0; row < 8; row++) {
/* 1208 */       int rIndex = row * 8;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1218 */       if (isZeroInRow(dataUnit, rIndex)) {
/* 1219 */         int dcVal = dataUnit[rIndex] << 2;
/* 1220 */         for (int i = rIndex + 7; i >= rIndex; i--) {
/* 1221 */           dataUnit[i] = dcVal;
/*      */         }
/*      */         
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/* 1228 */         int z2 = dataUnit[(rIndex + 2)];
/* 1229 */         int z3 = dataUnit[(rIndex + 6)];
/* 1230 */         int z1 = (z2 + z3) * 4433;
/* 1231 */         int tmp2 = z1 + z3 * 50399;
/* 1232 */         int tmp3 = z1 + z2 * 6270;
/* 1233 */         int tmp0 = dataUnit[rIndex] + dataUnit[(rIndex + 4)] << 13;
/* 1234 */         int tmp1 = dataUnit[rIndex] - dataUnit[(rIndex + 4)] << 13;
/* 1235 */         int tmp10 = tmp0 + tmp3;
/* 1236 */         int tmp13 = tmp0 - tmp3;
/* 1237 */         int tmp11 = tmp1 + tmp2;
/* 1238 */         int tmp12 = tmp1 - tmp2;
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 1243 */         tmp0 = dataUnit[(rIndex + 7)];
/* 1244 */         tmp1 = dataUnit[(rIndex + 5)];
/* 1245 */         tmp2 = dataUnit[(rIndex + 3)];
/* 1246 */         tmp3 = dataUnit[(rIndex + 1)];
/* 1247 */         z1 = tmp0 + tmp3;
/* 1248 */         z2 = tmp1 + tmp2;
/* 1249 */         z3 = tmp0 + tmp2;
/* 1250 */         int z4 = tmp1 + tmp3;
/* 1251 */         int z5 = (z3 + z4) * 9633;
/*      */         
/* 1253 */         tmp0 *= 2446;
/* 1254 */         tmp1 *= 16819;
/* 1255 */         tmp2 *= 25172;
/* 1256 */         tmp3 *= 12299;
/* 1257 */         z1 *= 58163;
/* 1258 */         z2 *= 44541;
/* 1259 */         z3 *= 49467;
/* 1260 */         z4 *= 62340;
/*      */         
/* 1262 */         z3 += z5;
/* 1263 */         z4 += z5;
/* 1264 */         tmp0 += z1 + z3;
/* 1265 */         tmp1 += z2 + z4;
/* 1266 */         tmp2 += z2 + z3;
/* 1267 */         tmp3 += z1 + z4;
/*      */         
/* 1269 */         dataUnit[rIndex] = (tmp10 + tmp3 + 1024 >> 11);
/* 1270 */         dataUnit[(rIndex + 7)] = (tmp10 - tmp3 + 1024 >> 11);
/* 1271 */         dataUnit[(rIndex + 1)] = (tmp11 + tmp2 + 1024 >> 11);
/* 1272 */         dataUnit[(rIndex + 6)] = (tmp11 - tmp2 + 1024 >> 11);
/* 1273 */         dataUnit[(rIndex + 2)] = (tmp12 + tmp1 + 1024 >> 11);
/* 1274 */         dataUnit[(rIndex + 5)] = (tmp12 - tmp1 + 1024 >> 11);
/* 1275 */         dataUnit[(rIndex + 3)] = (tmp13 + tmp0 + 1024 >> 11);
/* 1276 */         dataUnit[(rIndex + 4)] = (tmp13 - tmp0 + 1024 >> 11);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1284 */     for (int col = 0; col < 8; col++) {
/* 1285 */       int c0 = col;
/* 1286 */       int c1 = col + 8;
/* 1287 */       int c2 = col + 16;
/* 1288 */       int c3 = col + 24;
/* 1289 */       int c4 = col + 32;
/* 1290 */       int c5 = col + 40;
/* 1291 */       int c6 = col + 48;
/* 1292 */       int c7 = col + 56;
/* 1293 */       if (isZeroInColumn(dataUnit, col)) {
/* 1294 */         int dcVal = dataUnit[c0] + 16 >> 5;
/* 1295 */         dataUnit[c0] = dcVal;
/* 1296 */         dataUnit[c1] = dcVal;
/* 1297 */         dataUnit[c2] = dcVal;
/* 1298 */         dataUnit[c3] = dcVal;
/* 1299 */         dataUnit[c4] = dcVal;
/* 1300 */         dataUnit[c5] = dcVal;
/* 1301 */         dataUnit[c6] = dcVal;
/* 1302 */         dataUnit[c7] = dcVal;
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*      */ 
/* 1308 */         int z0 = dataUnit[c0];
/* 1309 */         int z2 = dataUnit[c2];
/* 1310 */         int z3 = dataUnit[c6];
/* 1311 */         int z4 = dataUnit[c4];
/* 1312 */         int z1 = (z2 + z3) * 4433;
/* 1313 */         int tmp2 = z1 + z3 * 50399;
/* 1314 */         int tmp3 = z1 + z2 * 6270;
/* 1315 */         int tmp0 = z0 + z4 << 13;
/* 1316 */         int tmp1 = z0 - z4 << 13;
/* 1317 */         int tmp10 = tmp0 + tmp3;
/* 1318 */         int tmp13 = tmp0 - tmp3;
/* 1319 */         int tmp11 = tmp1 + tmp2;
/* 1320 */         int tmp12 = tmp1 - tmp2;
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 1325 */         tmp0 = dataUnit[c7];
/* 1326 */         tmp1 = dataUnit[c5];
/* 1327 */         tmp2 = dataUnit[c3];
/* 1328 */         tmp3 = dataUnit[c1];
/* 1329 */         z1 = tmp0 + tmp3;
/* 1330 */         z2 = tmp1 + tmp2;
/* 1331 */         z3 = tmp0 + tmp2;
/* 1332 */         z4 = tmp1 + tmp3;
/* 1333 */         z0 = (z3 + z4) * 9633;
/*      */         
/* 1335 */         tmp0 *= 2446;
/* 1336 */         tmp1 *= 16819;
/* 1337 */         tmp2 *= 25172;
/* 1338 */         tmp3 *= 12299;
/* 1339 */         z1 *= 58163;
/* 1340 */         z2 *= 44541;
/* 1341 */         z3 *= 49467;
/* 1342 */         z4 *= 62340;
/*      */         
/* 1344 */         z3 += z0;
/* 1345 */         z4 += z0;
/*      */         
/* 1347 */         tmp0 += z1 + z3;
/* 1348 */         tmp1 += z2 + z4;
/* 1349 */         tmp2 += z2 + z3;
/* 1350 */         tmp3 += z1 + z4;
/*      */         
/*      */ 
/* 1353 */         dataUnit[c0] = (tmp10 + tmp3 + 131072 >> 18);
/* 1354 */         dataUnit[c7] = (tmp10 - tmp3 + 131072 >> 18);
/* 1355 */         dataUnit[c1] = (tmp11 + tmp2 + 131072 >> 18);
/* 1356 */         dataUnit[c6] = (tmp11 - tmp2 + 131072 >> 18);
/* 1357 */         dataUnit[c2] = (tmp12 + tmp1 + 131072 >> 18);
/* 1358 */         dataUnit[c5] = (tmp12 - tmp1 + 131072 >> 18);
/* 1359 */         dataUnit[c3] = (tmp13 + tmp0 + 131072 >> 18);
/* 1360 */         dataUnit[c4] = (tmp13 - tmp0 + 131072 >> 18);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   boolean isFileFormat(LEDataInputStream stream) {
/*      */     try {
/* 1367 */       JPEGStartOfImage soi = new JPEGStartOfImage(stream);
/* 1368 */       stream.unread(soi.reference);
/* 1369 */       return soi.verify();
/*      */     } catch (Exception e) {}
/* 1371 */     return false;
/*      */   }
/*      */   
/*      */   boolean isZeroInColumn(int[] dataUnit, int col) {
/* 1375 */     return (dataUnit[(col + 8)] == 0) && (dataUnit[(col + 16)] == 0) && (dataUnit[(col + 24)] == 0) && (dataUnit[(col + 32)] == 0) && (dataUnit[(col + 40)] == 0) && (dataUnit[(col + 48)] == 0) && (dataUnit[(col + 56)] == 0);
/*      */   }
/*      */   
/*      */ 
/*      */   boolean isZeroInRow(int[] dataUnit, int rIndex)
/*      */   {
/* 1381 */     return (dataUnit[(rIndex + 1)] == 0) && (dataUnit[(rIndex + 2)] == 0) && (dataUnit[(rIndex + 3)] == 0) && (dataUnit[(rIndex + 4)] == 0) && (dataUnit[(rIndex + 5)] == 0) && (dataUnit[(rIndex + 6)] == 0) && (dataUnit[(rIndex + 7)] == 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   ImageData[] loadFromByteStream()
/*      */   {
/* 1389 */     if (System.getProperty("org.eclipse.swt.internal.image.JPEGFileFormat_3.2") == null) {
/* 1390 */       return JPEGDecoder.loadFromByteStream(this.inputStream, this.loader);
/*      */     }
/* 1392 */     JPEGStartOfImage soi = new JPEGStartOfImage(this.inputStream);
/* 1393 */     if (!soi.verify()) SWT.error(40);
/* 1394 */     this.restartInterval = 0;
/*      */     
/*      */ 
/* 1397 */     processTables();
/*      */     
/*      */ 
/* 1400 */     this.frameHeader = new JPEGFrameHeader(this.inputStream);
/* 1401 */     if (!this.frameHeader.verify()) SWT.error(40);
/* 1402 */     this.imageWidth = this.frameHeader.getSamplesPerLine();
/* 1403 */     this.imageHeight = this.frameHeader.getNumberOfLines();
/* 1404 */     this.maxH = this.frameHeader.getMaxHFactor();
/* 1405 */     this.maxV = this.frameHeader.getMaxVFactor();
/* 1406 */     int mcuWidth = this.maxH * 8;
/* 1407 */     int mcuHeight = this.maxV * 8;
/* 1408 */     this.interleavedMcuCols = ((this.imageWidth + mcuWidth - 1) / mcuWidth);
/* 1409 */     this.interleavedMcuRows = ((this.imageHeight + mcuHeight - 1) / mcuHeight);
/* 1410 */     this.progressive = this.frameHeader.isProgressive();
/* 1411 */     this.samplePrecision = this.frameHeader.getSamplePrecision();
/* 1412 */     this.nComponents = this.frameHeader.getNumberOfImageComponents();
/* 1413 */     this.frameComponents = this.frameHeader.componentParameters;
/* 1414 */     this.componentIds = this.frameHeader.componentIdentifiers;
/* 1415 */     this.imageComponents = new byte[this.nComponents][];
/* 1416 */     if (this.progressive)
/*      */     {
/* 1418 */       this.dataUnits = new int[this.nComponents][][];
/*      */     }
/*      */     else {
/* 1421 */       this.dataUnit = new int[64];
/*      */     }
/* 1423 */     for (int i = 0; i < this.nComponents; i++) {
/* 1424 */       int[] frameComponent = this.frameComponents[this.componentIds[i]];
/* 1425 */       int bufferSize = frameComponent[3] * frameComponent[4];
/* 1426 */       this.imageComponents[i] = new byte[bufferSize];
/* 1427 */       if (this.progressive) {
/* 1428 */         this.dataUnits[i] = new int[bufferSize][];
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1433 */     processTables();
/*      */     
/*      */ 
/* 1436 */     this.scanHeader = new JPEGScanHeader(this.inputStream);
/* 1437 */     if (!this.scanHeader.verify()) { SWT.error(40);
/*      */     }
/*      */     
/* 1440 */     int progressiveScanCount = 0;
/* 1441 */     boolean done = false;
/* 1442 */     while (!done) {
/* 1443 */       resetInputBuffer();
/* 1444 */       this.precedingDCs = new int[4];
/* 1445 */       decodeScan();
/* 1446 */       if ((this.progressive) && (this.loader.hasListeners())) {
/* 1447 */         ImageData imageData = createImageData();
/* 1448 */         this.loader.notifyListeners(new ImageLoaderEvent(this.loader, imageData, progressiveScanCount, false));
/* 1449 */         progressiveScanCount++;
/*      */       }
/*      */       
/*      */ 
/* 1453 */       int delta = 512 - this.bufferCurrentPosition - 1;
/* 1454 */       if (delta > 0) {
/* 1455 */         byte[] unreadBuffer = new byte[delta];
/* 1456 */         System.arraycopy(this.dataBuffer, this.bufferCurrentPosition + 1, unreadBuffer, 0, delta);
/*      */         try {
/* 1458 */           this.inputStream.unread(unreadBuffer);
/*      */         } catch (IOException e) {
/* 1460 */           SWT.error(39, e);
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 1465 */       JPEGSegment jpegSegment = processTables();
/* 1466 */       if ((jpegSegment == null) || (jpegSegment.getSegmentMarker() == 65497)) {
/* 1467 */         done = true;
/*      */       } else {
/* 1469 */         this.scanHeader = new JPEGScanHeader(this.inputStream);
/* 1470 */         if (!this.scanHeader.verify()) { SWT.error(40);
/*      */         }
/*      */       }
/*      */     }
/* 1474 */     if (this.progressive) {
/* 1475 */       for (int ymcu = 0; ymcu < this.interleavedMcuRows; ymcu++) {
/* 1476 */         for (int xmcu = 0; xmcu < this.interleavedMcuCols; xmcu++) {
/* 1477 */           for (int iComp = 0; iComp < this.nComponents; iComp++) {
/* 1478 */             int[] frameComponent = this.frameComponents[this.componentIds[iComp]];
/* 1479 */             int hi = frameComponent[1];
/* 1480 */             int vi = frameComponent[2];
/* 1481 */             int compWidth = frameComponent[3];
/* 1482 */             for (int ivi = 0; ivi < vi; ivi++) {
/* 1483 */               for (int ihi = 0; ihi < hi; ihi++) {
/* 1484 */                 int index = (ymcu * vi + ivi) * compWidth + xmcu * hi + ihi;
/* 1485 */                 this.dataUnit = this.dataUnits[iComp][index];
/* 1486 */                 dequantize(this.dataUnit, iComp);
/* 1487 */                 inverseDCT(this.dataUnit);
/* 1488 */                 storeData(this.dataUnit, iComp, xmcu, ymcu, hi, ihi, vi, ivi);
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/* 1494 */       this.dataUnits = ((int[][][])null);
/*      */     }
/* 1496 */     ImageData imageData = createImageData();
/* 1497 */     if ((this.progressive) && (this.loader.hasListeners())) {
/* 1498 */       this.loader.notifyListeners(new ImageLoaderEvent(this.loader, imageData, progressiveScanCount, true));
/*      */     }
/* 1500 */     return new ImageData[] { imageData };
/*      */   }
/*      */   
/* 1503 */   ImageData createImageData() { return ImageData.internal_new(this.imageWidth, this.imageHeight, this.nComponents * this.samplePrecision, 
/*      */     
/*      */ 
/*      */ 
/* 1507 */       setUpPalette(), this.nComponents == 1 ? 4 : 1, 
/*      */       
/* 1509 */       decodeImageComponents(), 0, null, null, -1, -1, 4, 0, 0, 0, 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   int nextBit()
/*      */   {
/* 1522 */     if (this.currentBitCount != 0) {
/* 1523 */       this.currentBitCount -= 1;
/* 1524 */       this.currentByte *= 2;
/* 1525 */       if (this.currentByte > 255) {
/* 1526 */         this.currentByte -= 256;
/* 1527 */         return 1;
/*      */       }
/* 1529 */       return 0;
/*      */     }
/*      */     
/* 1532 */     this.bufferCurrentPosition += 1;
/* 1533 */     if (this.bufferCurrentPosition >= 512) {
/* 1534 */       resetInputBuffer();
/* 1535 */       this.bufferCurrentPosition = 0;
/*      */     }
/* 1537 */     this.currentByte = (this.dataBuffer[this.bufferCurrentPosition] & 0xFF);
/* 1538 */     this.currentBitCount = 8;
/*      */     byte nextByte;
/* 1540 */     byte nextByte; if (this.bufferCurrentPosition == 511) {
/* 1541 */       resetInputBuffer();
/* 1542 */       this.currentBitCount = 8;
/* 1543 */       nextByte = this.dataBuffer[0];
/*      */     } else {
/* 1545 */       nextByte = this.dataBuffer[(this.bufferCurrentPosition + 1)];
/*      */     }
/* 1547 */     if (this.currentByte == 255) {
/* 1548 */       if (nextByte == 0) {
/* 1549 */         this.bufferCurrentPosition += 1;
/* 1550 */         this.currentBitCount -= 1;
/* 1551 */         this.currentByte *= 2;
/* 1552 */         if (this.currentByte > 255) {
/* 1553 */           this.currentByte -= 256;
/* 1554 */           return 1;
/*      */         }
/* 1556 */         return 0;
/*      */       }
/*      */       
/* 1559 */       if ((nextByte & 0xFF) + 65280 == 65500) {
/* 1560 */         getDNL();
/* 1561 */         return 0;
/*      */       }
/* 1563 */       SWT.error(40);
/* 1564 */       return 0;
/*      */     }
/*      */     
/*      */ 
/* 1568 */     this.currentBitCount -= 1;
/* 1569 */     this.currentByte *= 2;
/* 1570 */     if (this.currentByte > 255) {
/* 1571 */       this.currentByte -= 256;
/* 1572 */       return 1;
/*      */     }
/* 1574 */     return 0;
/*      */   }
/*      */   
/*      */   void processRestartInterval()
/*      */   {
/*      */     do {
/* 1580 */       this.bufferCurrentPosition += 1;
/* 1581 */       if (this.bufferCurrentPosition > 511) {
/* 1582 */         resetInputBuffer();
/* 1583 */         this.bufferCurrentPosition = 0;
/*      */       }
/* 1585 */       this.currentByte = (this.dataBuffer[this.bufferCurrentPosition] & 0xFF);
/* 1586 */     } while (this.currentByte != 255);
/* 1587 */     while (this.currentByte == 255) {
/* 1588 */       this.bufferCurrentPosition += 1;
/* 1589 */       if (this.bufferCurrentPosition > 511) {
/* 1590 */         resetInputBuffer();
/* 1591 */         this.bufferCurrentPosition = 0;
/*      */       }
/* 1593 */       this.currentByte = (this.dataBuffer[this.bufferCurrentPosition] & 0xFF);
/*      */     }
/* 1595 */     if (this.currentByte != (65488 + this.nextRestartNumber & 0xFF)) {
/* 1596 */       SWT.error(40);
/*      */     }
/* 1598 */     this.bufferCurrentPosition += 1;
/* 1599 */     if (this.bufferCurrentPosition > 511) {
/* 1600 */       resetInputBuffer();
/* 1601 */       this.bufferCurrentPosition = 0;
/*      */     }
/* 1603 */     this.currentByte = (this.dataBuffer[this.bufferCurrentPosition] & 0xFF);
/* 1604 */     this.currentBitCount = 8;
/* 1605 */     this.restartsToGo = this.restartInterval;
/* 1606 */     this.nextRestartNumber = (this.nextRestartNumber + 1 & 0x7);
/* 1607 */     this.precedingDCs = new int[4];
/* 1608 */     this.eobrun = 0;
/*      */   }
/*      */   
/*      */   JPEGSegment processTables() {
/*      */     for (;;) {
/* 1613 */       JPEGSegment jpegSegment = seekUnspecifiedMarker(this.inputStream);
/* 1614 */       if (jpegSegment == null) return null;
/* 1615 */       JPEGFrameHeader sof = new JPEGFrameHeader(jpegSegment.reference);
/* 1616 */       if (sof.verify()) {
/* 1617 */         return jpegSegment;
/*      */       }
/* 1619 */       int marker = jpegSegment.getSegmentMarker();
/* 1620 */       switch (marker) {
/*      */       case 65496: 
/* 1622 */         SWT.error(40);
/*      */       case 65497: 
/*      */       case 65498: 
/* 1625 */         return jpegSegment;
/*      */       case 65499: 
/* 1627 */         getDQT();
/* 1628 */         break;
/*      */       case 65476: 
/* 1630 */         getDHT();
/* 1631 */         break;
/*      */       case 65484: 
/* 1633 */         getDAC();
/* 1634 */         break;
/*      */       case 65501: 
/* 1636 */         getDRI();
/* 1637 */         break;
/*      */       case 65504: 
/* 1639 */         getAPP0();
/* 1640 */         break;
/*      */       case 65534: 
/* 1642 */         getCOM();
/* 1643 */         break;
/*      */       default: 
/* 1645 */         skipSegmentFrom(this.inputStream);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   void quantizeData(int[] dataUnit, int iComp) {
/* 1651 */     int[] qTable = this.quantizationTables[this.frameComponents[this.componentIds[iComp]][0]];
/* 1652 */     for (int i = 0; i < dataUnit.length; i++) {
/* 1653 */       int zzIndex = ZigZag8x8[i];
/* 1654 */       int data = dataUnit[zzIndex];
/* 1655 */       int absData = data < 0 ? 0 - data : data;
/* 1656 */       int qValue = qTable[i];
/* 1657 */       int q2 = qValue >> 1;
/* 1658 */       absData += q2;
/* 1659 */       if (absData < qValue) {
/* 1660 */         dataUnit[zzIndex] = 0;
/*      */       } else {
/* 1662 */         absData /= qValue;
/* 1663 */         if (data >= 0) {
/* 1664 */           dataUnit[zzIndex] = absData;
/*      */         } else
/* 1666 */           dataUnit[zzIndex] = (0 - absData);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   int receive(int nBits) {
/* 1672 */     int v = 0;
/* 1673 */     for (int i = 0; i < nBits; i++) {
/* 1674 */       v = v * 2 + nextBit();
/*      */     }
/* 1676 */     return v;
/*      */   }
/*      */   
/* 1679 */   void resetInputBuffer() { if (this.dataBuffer == null) {
/* 1680 */       this.dataBuffer = new byte['Ȁ'];
/*      */     }
/*      */     try {
/* 1683 */       this.inputStream.read(this.dataBuffer);
/*      */     } catch (IOException e) {
/* 1685 */       SWT.error(39, e);
/*      */     }
/* 1687 */     this.currentBitCount = 0;
/* 1688 */     this.bufferCurrentPosition = -1;
/*      */   }
/*      */   
/* 1691 */   void resetOutputBuffer() { if (this.dataBuffer == null) {
/* 1692 */       this.dataBuffer = new byte['Ȁ'];
/*      */     } else {
/*      */       try {
/* 1695 */         this.outputStream.write(this.dataBuffer, 0, this.bufferCurrentPosition);
/*      */       } catch (IOException e) {
/* 1697 */         SWT.error(39, e);
/*      */       }
/*      */     }
/* 1700 */     this.bufferCurrentPosition = 0;
/*      */   }
/*      */   
/* 1703 */   static JPEGSegment seekUnspecifiedMarker(LEDataInputStream byteStream) { byte[] byteArray = new byte[2];
/*      */     try {
/*      */       do {
/* 1706 */         do { if (byteStream.read(byteArray, 0, 1) != 1) return null;
/* 1707 */         } while (byteArray[0] != -1);
/* 1708 */         if (byteStream.read(byteArray, 1, 1) != 1) return null;
/* 1709 */       } while ((byteArray[1] == -1) || (byteArray[1] == 0));
/* 1710 */       byteStream.unread(byteArray);
/* 1711 */       return new JPEGSegment(byteArray);
/*      */ 
/*      */     }
/*      */     catch (IOException e)
/*      */     {
/* 1716 */       SWT.error(39, e);
/*      */     }
/* 1718 */     return null;
/*      */   }
/*      */   
/* 1721 */   PaletteData setUpPalette() { if (this.nComponents == 1) {
/* 1722 */       RGB[] entries = new RGB['Ā'];
/* 1723 */       for (int i = 0; i < 256; i++) {
/* 1724 */         entries[i] = new RGB(i, i, i);
/*      */       }
/* 1726 */       return new PaletteData(entries);
/*      */     }
/* 1728 */     return new PaletteData(255, 65280, 16711680);
/*      */   }
/*      */   
/*      */   static void skipSegmentFrom(LEDataInputStream byteStream) {
/* 1732 */     try { byte[] byteArray = new byte[4];
/* 1733 */       JPEGSegment jpegSegment = new JPEGSegment(byteArray);
/*      */       
/* 1735 */       if (byteStream.read(byteArray) != byteArray.length) {
/* 1736 */         SWT.error(40);
/*      */       }
/* 1738 */       if ((byteArray[0] != -1) || (byteArray[1] == 0) || (byteArray[1] == -1)) {
/* 1739 */         SWT.error(40);
/*      */       }
/* 1741 */       int delta = jpegSegment.getSegmentLength() - 2;
/* 1742 */       byteStream.skip(delta);
/*      */     } catch (Exception e) {
/* 1744 */       SWT.error(39, e);
/*      */     }
/*      */   }
/*      */   
/* 1748 */   void storeData(int[] dataUnit, int iComp, int xmcu, int ymcu, int hi, int ihi, int vi, int ivi) { byte[] compImage = this.imageComponents[iComp];
/* 1749 */     int[] frameComponent = this.frameComponents[this.componentIds[iComp]];
/* 1750 */     int compWidth = frameComponent[3];
/* 1751 */     int destIndex = (ymcu * vi + ivi) * compWidth * 8 + (xmcu * hi + ihi) * 8;
/* 1752 */     int srcIndex = 0;
/* 1753 */     for (int i = 0; i < 8; i++) {
/* 1754 */       for (int col = 0; col < 8; col++) {
/* 1755 */         int x = dataUnit[srcIndex] + 128;
/* 1756 */         if (x < 0) {
/* 1757 */           x = 0;
/*      */         }
/* 1759 */         else if (x > 255) { x = 255;
/*      */         }
/* 1761 */         compImage[(destIndex + col)] = ((byte)x);
/* 1762 */         srcIndex++;
/*      */       }
/* 1764 */       destIndex += compWidth;
/*      */     }
/*      */   }
/*      */   
/*      */   void unloadIntoByteStream(ImageLoader loader) {
/* 1769 */     ImageData image = loader.data[0];
/* 1770 */     if (!new JPEGStartOfImage().writeToStream(this.outputStream)) {
/* 1771 */       SWT.error(39);
/*      */     }
/* 1773 */     JPEGAppn appn = new JPEGAppn(new byte[] { -1, -32, 0, 16, 74, 70, 73, 70, 0, 1, 1, 0, 0, 1, 0, 1, 0, 0 });
/* 1774 */     if (!appn.writeToStream(this.outputStream)) {
/* 1775 */       SWT.error(39);
/*      */     }
/* 1777 */     this.quantizationTables = new int[4][];
/* 1778 */     JPEGQuantizationTable chromDQT = JPEGQuantizationTable.defaultChrominanceTable();
/* 1779 */     int encoderQFactor = (loader.compression >= 1) && (loader.compression <= 100) ? loader.compression : 75;
/* 1780 */     chromDQT.scaleBy(encoderQFactor);
/* 1781 */     int[] jpegDQTKeys = chromDQT.getQuantizationTablesKeys();
/* 1782 */     int[][] jpegDQTValues = chromDQT.getQuantizationTablesValues();
/* 1783 */     for (int i = 0; i < jpegDQTKeys.length; i++) {
/* 1784 */       this.quantizationTables[jpegDQTKeys[i]] = jpegDQTValues[i];
/*      */     }
/* 1786 */     JPEGQuantizationTable lumDQT = JPEGQuantizationTable.defaultLuminanceTable();
/* 1787 */     lumDQT.scaleBy(encoderQFactor);
/* 1788 */     jpegDQTKeys = lumDQT.getQuantizationTablesKeys();
/* 1789 */     jpegDQTValues = lumDQT.getQuantizationTablesValues();
/* 1790 */     for (int i = 0; i < jpegDQTKeys.length; i++) {
/* 1791 */       this.quantizationTables[jpegDQTKeys[i]] = jpegDQTValues[i];
/*      */     }
/* 1793 */     if (!lumDQT.writeToStream(this.outputStream)) {
/* 1794 */       SWT.error(39);
/*      */     }
/* 1796 */     if (!chromDQT.writeToStream(this.outputStream))
/* 1797 */       SWT.error(39);
/*      */     int precision;
/*      */     int frameLength;
/*      */     int[][] frameParams;
/* 1801 */     int[][] scanParams; int scanLength; int precision; if (image.depth == 1) {
/* 1802 */       int frameLength = 11;
/* 1803 */       int[][] frameParams = new int[1][];
/* 1804 */       frameParams[0] = { 1, 1, 1, 0, 0 };
/* 1805 */       int[][] scanParams = new int[1][];
/* 1806 */       scanParams[0] = { 0, 0 };
/* 1807 */       int scanLength = 8;
/* 1808 */       this.nComponents = 1;
/* 1809 */       precision = 1;
/*      */     } else {
/* 1811 */       frameLength = 17;
/* 1812 */       frameParams = new int[3][];
/* 1813 */       frameParams[0] = { 0, 2, 2, 0, 0 };
/* 1814 */       frameParams[1] = { 1, 1, 1, 0, 0 };
/* 1815 */       frameParams[2] = { 1, 1, 1, 0, 0 };
/* 1816 */       scanParams = new int[3][];
/* 1817 */       scanParams[0] = { 0, 0 };
/* 1818 */       scanParams[1] = { 1, 1 };
/* 1819 */       scanParams[2] = { 1, 1 };
/* 1820 */       scanLength = 12;
/* 1821 */       this.nComponents = 3;
/* 1822 */       precision = 8;
/*      */     }
/* 1824 */     this.imageWidth = image.width;
/* 1825 */     this.imageHeight = image.height;
/* 1826 */     this.frameHeader = new JPEGFrameHeader(new byte[19]);
/* 1827 */     this.frameHeader.setSegmentMarker(65472);
/* 1828 */     this.frameHeader.setSegmentLength(frameLength);
/* 1829 */     this.frameHeader.setSamplePrecision(precision);
/* 1830 */     this.frameHeader.setSamplesPerLine(this.imageWidth);
/* 1831 */     this.frameHeader.setNumberOfLines(this.imageHeight);
/* 1832 */     this.frameHeader.setNumberOfImageComponents(this.nComponents);
/* 1833 */     this.frameHeader.componentParameters = frameParams;
/* 1834 */     this.frameHeader.componentIdentifiers = new int[] { 0, 1, 2 };
/* 1835 */     this.frameHeader.initializeContents();
/* 1836 */     if (!this.frameHeader.writeToStream(this.outputStream)) {
/* 1837 */       SWT.error(39);
/*      */     }
/* 1839 */     this.frameComponents = frameParams;
/* 1840 */     this.componentIds = this.frameHeader.componentIdentifiers;
/* 1841 */     this.maxH = this.frameHeader.getMaxHFactor();
/* 1842 */     this.maxV = this.frameHeader.getMaxVFactor();
/* 1843 */     int mcuWidth = this.maxH * 8;
/* 1844 */     int mcuHeight = this.maxV * 8;
/* 1845 */     this.interleavedMcuCols = ((this.imageWidth + mcuWidth - 1) / mcuWidth);
/* 1846 */     this.interleavedMcuRows = ((this.imageHeight + mcuHeight - 1) / mcuHeight);
/* 1847 */     this.acHuffmanTables = new JPEGHuffmanTable[4];
/* 1848 */     this.dcHuffmanTables = new JPEGHuffmanTable[4];
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1853 */     JPEGHuffmanTable[] dhtTables = {JPEGHuffmanTable.getDefaultDCLuminanceTable(), JPEGHuffmanTable.getDefaultDCChrominanceTable(), JPEGHuffmanTable.getDefaultACLuminanceTable(), JPEGHuffmanTable.getDefaultACChrominanceTable() };
/*      */     
/* 1855 */     for (int i = 0; i < dhtTables.length; i++) {
/* 1856 */       JPEGHuffmanTable dhtTable = dhtTables[i];
/* 1857 */       if (!dhtTable.writeToStream(this.outputStream)) {
/* 1858 */         SWT.error(39);
/*      */       }
/* 1860 */       JPEGHuffmanTable[] allTables = dhtTable.getAllTables();
/* 1861 */       for (int j = 0; j < allTables.length; j++) {
/* 1862 */         JPEGHuffmanTable huffmanTable = allTables[j];
/* 1863 */         if (huffmanTable.getTableClass() == 0) {
/* 1864 */           this.dcHuffmanTables[huffmanTable.getTableIdentifier()] = huffmanTable;
/*      */         } else {
/* 1866 */           this.acHuffmanTables[huffmanTable.getTableIdentifier()] = huffmanTable;
/*      */         }
/*      */       }
/*      */     }
/* 1870 */     this.precedingDCs = new int[4];
/* 1871 */     this.scanHeader = new JPEGScanHeader(new byte[14]);
/* 1872 */     this.scanHeader.setSegmentMarker(65498);
/* 1873 */     this.scanHeader.setSegmentLength(scanLength);
/* 1874 */     this.scanHeader.setNumberOfImageComponents(this.nComponents);
/* 1875 */     this.scanHeader.setStartOfSpectralSelection(0);
/* 1876 */     this.scanHeader.setEndOfSpectralSelection(63);
/* 1877 */     this.scanHeader.componentParameters = scanParams;
/* 1878 */     this.scanHeader.initializeContents();
/* 1879 */     if (!this.scanHeader.writeToStream(this.outputStream)) {
/* 1880 */       SWT.error(39);
/*      */     }
/* 1882 */     convertImageToYCbCr(image);
/* 1883 */     resetOutputBuffer();
/* 1884 */     this.currentByte = 0;
/* 1885 */     this.currentBitCount = 0;
/* 1886 */     encodeScan();
/* 1887 */     if (!new JPEGEndOfImage().writeToStream(this.outputStream)) {
/* 1888 */       SWT.error(39);
/*      */     }
/*      */   }
/*      */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/internal/image/JPEGFileFormat.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */