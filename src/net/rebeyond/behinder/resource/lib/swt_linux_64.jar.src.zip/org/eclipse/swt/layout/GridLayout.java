/*     */ package org.eclipse.swt.layout;
/*     */ 
/*     */ import org.eclipse.swt.graphics.Point;
/*     */ import org.eclipse.swt.graphics.Rectangle;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.swt.widgets.Control;
/*     */ import org.eclipse.swt.widgets.Layout;
/*     */ import org.eclipse.swt.widgets.Scrollable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class GridLayout
/*     */   extends Layout
/*     */ {
/*  56 */   public int numColumns = 1;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  64 */   public boolean makeColumnsEqualWidth = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  72 */   public int marginWidth = 5;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  80 */   public int marginHeight = 5;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  90 */   public int marginLeft = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 100 */   public int marginTop = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 110 */   public int marginRight = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 120 */   public int marginBottom = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 129 */   public int horizontalSpacing = 5;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 137 */   public int verticalSpacing = 5;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public GridLayout() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public GridLayout(int numColumns, boolean makeColumnsEqualWidth)
/*     */   {
/* 158 */     this.numColumns = numColumns;
/* 159 */     this.makeColumnsEqualWidth = makeColumnsEqualWidth;
/*     */   }
/*     */   
/*     */   protected Point computeSize(Composite composite, int wHint, int hHint, boolean flushCache)
/*     */   {
/* 164 */     Point size = layout(composite, false, 0, 0, wHint, hHint, flushCache);
/* 165 */     if (wHint != -1) size.x = wHint;
/* 166 */     if (hHint != -1) size.y = hHint;
/* 167 */     return size;
/*     */   }
/*     */   
/*     */   protected boolean flushCache(Control control)
/*     */   {
/* 172 */     Object data = control.getLayoutData();
/* 173 */     if (data != null) ((GridData)data).flushCache();
/* 174 */     return true;
/*     */   }
/*     */   
/*     */   GridData getData(Control[][] grid, int row, int column, int rowCount, int columnCount, boolean first) {
/* 178 */     Control control = grid[row][column];
/* 179 */     if (control != null) {
/* 180 */       GridData data = (GridData)control.getLayoutData();
/* 181 */       int hSpan = Math.max(1, Math.min(data.horizontalSpan, columnCount));
/* 182 */       int vSpan = Math.max(1, data.verticalSpan);
/* 183 */       int i = first ? row + vSpan - 1 : row - vSpan + 1;
/* 184 */       int j = first ? column + hSpan - 1 : column - hSpan + 1;
/* 185 */       if ((0 <= i) && (i < rowCount) && 
/* 186 */         (0 <= j) && (j < columnCount) && 
/* 187 */         (control == grid[i][j])) { return data;
/*     */       }
/*     */     }
/*     */     
/* 191 */     return null;
/*     */   }
/*     */   
/*     */   protected void layout(Composite composite, boolean flushCache)
/*     */   {
/* 196 */     Rectangle rect = composite.getClientArea();
/* 197 */     layout(composite, true, rect.x, rect.y, rect.width, rect.height, flushCache);
/*     */   }
/*     */   
/*     */   Point layout(Composite composite, boolean move, int x, int y, int width, int height, boolean flushCache) {
/* 201 */     if (this.numColumns < 1) {
/* 202 */       return new Point(this.marginLeft + this.marginWidth * 2 + this.marginRight, this.marginTop + this.marginHeight * 2 + this.marginBottom);
/*     */     }
/* 204 */     Control[] children = composite.getChildren();
/* 205 */     int count = 0;
/* 206 */     for (int i = 0; i < children.length; i++) {
/* 207 */       Control control = children[i];
/* 208 */       GridData data = (GridData)control.getLayoutData();
/* 209 */       if ((data == null) || (!data.exclude)) {
/* 210 */         children[(count++)] = children[i];
/*     */       }
/*     */     }
/* 213 */     if (count == 0) {
/* 214 */       return new Point(this.marginLeft + this.marginWidth * 2 + this.marginRight, this.marginTop + this.marginHeight * 2 + this.marginBottom);
/*     */     }
/* 216 */     for (int i = 0; i < count; i++) {
/* 217 */       Control child = children[i];
/* 218 */       GridData data = (GridData)child.getLayoutData();
/* 219 */       if (data == null) child.setLayoutData(data = new GridData());
/* 220 */       if (flushCache) data.flushCache();
/* 221 */       data.computeSize(child, data.widthHint, data.heightHint, flushCache);
/* 222 */       if ((data.grabExcessHorizontalSpace) && (data.minimumWidth > 0) && 
/* 223 */         (data.cacheWidth < data.minimumWidth)) {
/* 224 */         int trim = 0;
/*     */         
/* 226 */         if ((child instanceof Scrollable)) {
/* 227 */           Rectangle rect = ((Scrollable)child).computeTrim(0, 0, 0, 0);
/* 228 */           trim = rect.width;
/*     */         } else {
/* 230 */           trim = child.getBorderWidth() * 2;
/*     */         }
/* 232 */         data.cacheWidth = (data.cacheHeight = -1);
/* 233 */         data.computeSize(child, Math.max(0, data.minimumWidth - trim), data.heightHint, false);
/*     */       }
/*     */       
/* 236 */       if ((data.grabExcessVerticalSpace) && (data.minimumHeight > 0)) {
/* 237 */         data.cacheHeight = Math.max(data.cacheHeight, data.minimumHeight);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 242 */     int row = 0;int column = 0;int rowCount = 0;int columnCount = this.numColumns;
/* 243 */     Control[][] grid = new Control[4][columnCount];
/* 244 */     for (int i = 0; i < count; i++) {
/* 245 */       Control child = children[i];
/* 246 */       GridData data = (GridData)child.getLayoutData();
/* 247 */       int hSpan = Math.max(1, Math.min(data.horizontalSpan, columnCount));
/* 248 */       int vSpan = Math.max(1, data.verticalSpan);
/*     */       for (;;) {
/* 250 */         int lastRow = row + vSpan;
/* 251 */         if (lastRow >= grid.length) {
/* 252 */           Control[][] newGrid = new Control[lastRow + 4][columnCount];
/* 253 */           System.arraycopy(grid, 0, newGrid, 0, grid.length);
/* 254 */           grid = newGrid;
/*     */         }
/* 256 */         if (grid[row] == null) {
/* 257 */           grid[row] = new Control[columnCount];
/*     */         }
/* 259 */         while ((column < columnCount) && (grid[row][column] != null)) {
/* 260 */           column++;
/*     */         }
/* 262 */         int endCount = column + hSpan;
/* 263 */         if (endCount <= columnCount) {
/* 264 */           int index = column;
/* 265 */           while ((index < endCount) && (grid[row][index] == null)) {
/* 266 */             index++;
/*     */           }
/* 268 */           if (index == endCount) break;
/* 269 */           column = index;
/*     */         }
/* 271 */         if (column + hSpan >= columnCount) {
/* 272 */           column = 0;
/* 273 */           row++;
/*     */         }
/*     */       }
/* 276 */       for (int j = 0; j < vSpan; j++) {
/* 277 */         if (grid[(row + j)] == null) {
/* 278 */           grid[(row + j)] = new Control[columnCount];
/*     */         }
/* 280 */         for (int k = 0; k < hSpan; k++) {
/* 281 */           grid[(row + j)][(column + k)] = child;
/*     */         }
/*     */       }
/* 284 */       rowCount = Math.max(rowCount, row + vSpan);
/* 285 */       column += hSpan;
/*     */     }
/*     */     
/*     */ 
/* 289 */     int availableWidth = width - this.horizontalSpacing * (columnCount - 1) - (this.marginLeft + this.marginWidth * 2 + this.marginRight);
/* 290 */     int expandCount = 0;
/* 291 */     int[] widths = new int[columnCount];
/* 292 */     int[] minWidths = new int[columnCount];
/* 293 */     boolean[] expandColumn = new boolean[columnCount];
/* 294 */     for (int j = 0; j < columnCount; j++) {
/* 295 */       for (int i = 0; i < rowCount; i++) {
/* 296 */         GridData data = getData(grid, i, j, rowCount, columnCount, true);
/* 297 */         if (data != null) {
/* 298 */           int hSpan = Math.max(1, Math.min(data.horizontalSpan, columnCount));
/* 299 */           if (hSpan == 1) {
/* 300 */             int w = data.cacheWidth + data.horizontalIndent;
/* 301 */             widths[j] = Math.max(widths[j], w);
/* 302 */             if (data.grabExcessHorizontalSpace) {
/* 303 */               if (expandColumn[j] == 0) expandCount++;
/* 304 */               expandColumn[j] = true;
/*     */             }
/* 306 */             if ((!data.grabExcessHorizontalSpace) || (data.minimumWidth != 0)) {
/* 307 */               w = (!data.grabExcessHorizontalSpace) || (data.minimumWidth == -1) ? data.cacheWidth : data.minimumWidth;
/* 308 */               w += data.horizontalIndent;
/* 309 */               minWidths[j] = Math.max(minWidths[j], w);
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/* 314 */       for (int i = 0; i < rowCount; i++) {
/* 315 */         GridData data = getData(grid, i, j, rowCount, columnCount, false);
/* 316 */         if (data != null) {
/* 317 */           int hSpan = Math.max(1, Math.min(data.horizontalSpan, columnCount));
/* 318 */           if (hSpan > 1) {
/* 319 */             int spanWidth = 0;int spanMinWidth = 0;int spanExpandCount = 0;
/* 320 */             for (int k = 0; k < hSpan; k++) {
/* 321 */               spanWidth += widths[(j - k)];
/* 322 */               spanMinWidth += minWidths[(j - k)];
/* 323 */               if (expandColumn[(j - k)] != 0) spanExpandCount++;
/*     */             }
/* 325 */             if ((data.grabExcessHorizontalSpace) && (spanExpandCount == 0)) {
/* 326 */               expandCount++;
/* 327 */               expandColumn[j] = true;
/*     */             }
/* 329 */             int w = data.cacheWidth + data.horizontalIndent - spanWidth - (hSpan - 1) * this.horizontalSpacing;
/* 330 */             if (w > 0) {
/* 331 */               if (this.makeColumnsEqualWidth) {
/* 332 */                 int equalWidth = (w + spanWidth) / hSpan;
/* 333 */                 int remainder = (w + spanWidth) % hSpan;int last = -1;
/* 334 */                 for (int k = 0; k < hSpan; k++) {
/* 335 */                   widths[(last = j - k)] = Math.max(equalWidth, widths[(j - k)]);
/*     */                 }
/* 337 */                 if (last > -1) widths[last] += remainder;
/*     */               }
/* 339 */               else if (spanExpandCount == 0) {
/* 340 */                 widths[j] += w;
/*     */               } else {
/* 342 */                 int delta = w / spanExpandCount;
/* 343 */                 int remainder = w % spanExpandCount;int last = -1;
/* 344 */                 for (int k = 0; k < hSpan; k++) {
/* 345 */                   if (expandColumn[(j - k)] != 0) {
/* 346 */                     widths[(last = j - k)] += delta;
/*     */                   }
/*     */                 }
/* 349 */                 if (last > -1) { widths[last] += remainder;
/*     */                 }
/*     */               }
/*     */             }
/* 353 */             if ((!data.grabExcessHorizontalSpace) || (data.minimumWidth != 0)) {
/* 354 */               w = (!data.grabExcessHorizontalSpace) || (data.minimumWidth == -1) ? data.cacheWidth : data.minimumWidth;
/* 355 */               w += data.horizontalIndent - spanMinWidth - (hSpan - 1) * this.horizontalSpacing;
/* 356 */               if (w > 0) {
/* 357 */                 if (spanExpandCount == 0) {
/* 358 */                   minWidths[j] += w;
/*     */                 } else {
/* 360 */                   int delta = w / spanExpandCount;
/* 361 */                   int remainder = w % spanExpandCount;int last = -1;
/* 362 */                   for (int k = 0; k < hSpan; k++) {
/* 363 */                     if (expandColumn[(j - k)] != 0) {
/* 364 */                       minWidths[(last = j - k)] += delta;
/*     */                     }
/*     */                   }
/* 367 */                   if (last > -1) minWidths[last] += remainder;
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 375 */     if (this.makeColumnsEqualWidth) {
/* 376 */       int minColumnWidth = 0;
/* 377 */       int columnWidth = 0;
/* 378 */       for (int i = 0; i < columnCount; i++) {
/* 379 */         minColumnWidth = Math.max(minColumnWidth, minWidths[i]);
/* 380 */         columnWidth = Math.max(columnWidth, widths[i]);
/*     */       }
/* 382 */       columnWidth = (width == -1) || (expandCount == 0) ? columnWidth : Math.max(minColumnWidth, availableWidth / columnCount);
/* 383 */       for (int i = 0; i < columnCount; i++) {
/* 384 */         expandColumn[i] = (expandCount > 0 ? 1 : false);
/* 385 */         widths[i] = columnWidth;
/*     */       }
/*     */     }
/* 388 */     else if ((width != -1) && (expandCount > 0)) {
/* 389 */       int totalWidth = 0;
/* 390 */       for (int i = 0; i < columnCount; i++) {
/* 391 */         totalWidth += widths[i];
/*     */       }
/* 393 */       int c = expandCount;
/* 394 */       int delta = (availableWidth - totalWidth) / c;
/* 395 */       int remainder = (availableWidth - totalWidth) % c;
/* 396 */       int last = -1;
/* 397 */       while (totalWidth != availableWidth) {
/* 398 */         for (int j = 0; j < columnCount; j++) {
/* 399 */           if (expandColumn[j] != 0) {
/* 400 */             if (widths[j] + delta > minWidths[j]) {
/* 401 */               widths[(last = j)] = (widths[j] + delta);
/*     */             } else {
/* 403 */               widths[j] = minWidths[j];
/* 404 */               expandColumn[j] = false;
/* 405 */               c--;
/*     */             }
/*     */           }
/*     */         }
/* 409 */         if (last > -1) { widths[last] += remainder;
/*     */         }
/* 411 */         for (int j = 0; j < columnCount; j++) {
/* 412 */           for (int i = 0; i < rowCount; i++) {
/* 413 */             GridData data = getData(grid, i, j, rowCount, columnCount, false);
/* 414 */             if (data != null) {
/* 415 */               int hSpan = Math.max(1, Math.min(data.horizontalSpan, columnCount));
/* 416 */               if ((hSpan > 1) && (
/* 417 */                 (!data.grabExcessHorizontalSpace) || (data.minimumWidth != 0))) {
/* 418 */                 int spanWidth = 0;int spanExpandCount = 0;
/* 419 */                 for (int k = 0; k < hSpan; k++) {
/* 420 */                   spanWidth += widths[(j - k)];
/* 421 */                   if (expandColumn[(j - k)] != 0) spanExpandCount++;
/*     */                 }
/* 423 */                 int w = (!data.grabExcessHorizontalSpace) || (data.minimumWidth == -1) ? data.cacheWidth : data.minimumWidth;
/* 424 */                 w += data.horizontalIndent - spanWidth - (hSpan - 1) * this.horizontalSpacing;
/* 425 */                 if (w > 0) {
/* 426 */                   if (spanExpandCount == 0) {
/* 427 */                     widths[j] += w;
/*     */                   } else {
/* 429 */                     int delta2 = w / spanExpandCount;
/* 430 */                     int remainder2 = w % spanExpandCount;int last2 = -1;
/* 431 */                     for (int k = 0; k < hSpan; k++) {
/* 432 */                       if (expandColumn[(j - k)] != 0) {
/* 433 */                         widths[(last2 = j - k)] += delta2;
/*     */                       }
/*     */                     }
/* 436 */                     if (last2 > -1) { widths[last2] += remainder2;
/*     */                     }
/*     */                   }
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/* 444 */         if (c == 0) break;
/* 445 */         totalWidth = 0;
/* 446 */         for (int i = 0; i < columnCount; i++) {
/* 447 */           totalWidth += widths[i];
/*     */         }
/* 449 */         delta = (availableWidth - totalWidth) / c;
/* 450 */         remainder = (availableWidth - totalWidth) % c;
/* 451 */         last = -1;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 457 */     GridData[] flush = null;
/* 458 */     int flushLength = 0;
/* 459 */     if (width != -1) {
/* 460 */       for (int j = 0; j < columnCount; j++) {
/* 461 */         for (int i = 0; i < rowCount; i++) {
/* 462 */           GridData data = getData(grid, i, j, rowCount, columnCount, false);
/* 463 */           if ((data != null) && 
/* 464 */             (data.heightHint == -1)) {
/* 465 */             Control child = grid[i][j];
/*     */             
/* 467 */             int hSpan = Math.max(1, Math.min(data.horizontalSpan, columnCount));
/* 468 */             int currentWidth = 0;
/* 469 */             for (int k = 0; k < hSpan; k++) {
/* 470 */               currentWidth += widths[(j - k)];
/*     */             }
/* 472 */             currentWidth += (hSpan - 1) * this.horizontalSpacing - data.horizontalIndent;
/* 473 */             if (((currentWidth != data.cacheWidth) && (data.horizontalAlignment == 4)) || (data.cacheWidth > currentWidth)) {
/* 474 */               int trim = 0;
/* 475 */               if ((child instanceof Scrollable)) {
/* 476 */                 Rectangle rect = ((Scrollable)child).computeTrim(0, 0, 0, 0);
/* 477 */                 trim = rect.width;
/*     */               } else {
/* 479 */                 trim = child.getBorderWidth() * 2;
/*     */               }
/* 481 */               data.cacheWidth = (data.cacheHeight = -1);
/* 482 */               data.computeSize(child, Math.max(0, currentWidth - trim), data.heightHint, false);
/* 483 */               if ((data.grabExcessVerticalSpace) && (data.minimumHeight > 0)) {
/* 484 */                 data.cacheHeight = Math.max(data.cacheHeight, data.minimumHeight);
/*     */               }
/* 486 */               if (flush == null) flush = new GridData[count];
/* 487 */               flush[(flushLength++)] = data;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 496 */     int availableHeight = height - this.verticalSpacing * (rowCount - 1) - (this.marginTop + this.marginHeight * 2 + this.marginBottom);
/* 497 */     expandCount = 0;
/* 498 */     int[] heights = new int[rowCount];
/* 499 */     int[] minHeights = new int[rowCount];
/* 500 */     boolean[] expandRow = new boolean[rowCount];
/* 501 */     for (int i = 0; i < rowCount; i++) {
/* 502 */       for (int j = 0; j < columnCount; j++) {
/* 503 */         GridData data = getData(grid, i, j, rowCount, columnCount, true);
/* 504 */         if (data != null) {
/* 505 */           int vSpan = Math.max(1, Math.min(data.verticalSpan, rowCount));
/* 506 */           if (vSpan == 1) {
/* 507 */             int h = data.cacheHeight + data.verticalIndent;
/* 508 */             heights[i] = Math.max(heights[i], h);
/* 509 */             if (data.grabExcessVerticalSpace) {
/* 510 */               if (expandRow[i] == 0) expandCount++;
/* 511 */               expandRow[i] = true;
/*     */             }
/* 513 */             if ((!data.grabExcessVerticalSpace) || (data.minimumHeight != 0)) {
/* 514 */               h = (!data.grabExcessVerticalSpace) || (data.minimumHeight == -1) ? data.cacheHeight : data.minimumHeight;
/* 515 */               h += data.verticalIndent;
/* 516 */               minHeights[i] = Math.max(minHeights[i], h);
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/* 521 */       for (int j = 0; j < columnCount; j++) {
/* 522 */         GridData data = getData(grid, i, j, rowCount, columnCount, false);
/* 523 */         if (data != null) {
/* 524 */           int vSpan = Math.max(1, Math.min(data.verticalSpan, rowCount));
/* 525 */           if (vSpan > 1) {
/* 526 */             int spanHeight = 0;int spanMinHeight = 0;int spanExpandCount = 0;
/* 527 */             for (int k = 0; k < vSpan; k++) {
/* 528 */               spanHeight += heights[(i - k)];
/* 529 */               spanMinHeight += minHeights[(i - k)];
/* 530 */               if (expandRow[(i - k)] != 0) spanExpandCount++;
/*     */             }
/* 532 */             if ((data.grabExcessVerticalSpace) && (spanExpandCount == 0)) {
/* 533 */               expandCount++;
/* 534 */               expandRow[i] = true;
/*     */             }
/* 536 */             int h = data.cacheHeight + data.verticalIndent - spanHeight - (vSpan - 1) * this.verticalSpacing;
/* 537 */             if (h > 0) {
/* 538 */               if (spanExpandCount == 0) {
/* 539 */                 heights[i] += h;
/*     */               } else {
/* 541 */                 int delta = h / spanExpandCount;
/* 542 */                 int remainder = h % spanExpandCount;int last = -1;
/* 543 */                 for (int k = 0; k < vSpan; k++) {
/* 544 */                   if (expandRow[(i - k)] != 0) {
/* 545 */                     heights[(last = i - k)] += delta;
/*     */                   }
/*     */                 }
/* 548 */                 if (last > -1) heights[last] += remainder;
/*     */               }
/*     */             }
/* 551 */             if ((!data.grabExcessVerticalSpace) || (data.minimumHeight != 0)) {
/* 552 */               h = (!data.grabExcessVerticalSpace) || (data.minimumHeight == -1) ? data.cacheHeight : data.minimumHeight;
/* 553 */               h += data.verticalIndent - spanMinHeight - (vSpan - 1) * this.verticalSpacing;
/* 554 */               if (h > 0) {
/* 555 */                 if (spanExpandCount == 0) {
/* 556 */                   minHeights[i] += h;
/*     */                 } else {
/* 558 */                   int delta = h / spanExpandCount;
/* 559 */                   int remainder = h % spanExpandCount;int last = -1;
/* 560 */                   for (int k = 0; k < vSpan; k++) {
/* 561 */                     if (expandRow[(i - k)] != 0) {
/* 562 */                       minHeights[(last = i - k)] += delta;
/*     */                     }
/*     */                   }
/* 565 */                   if (last > -1) minHeights[last] += remainder;
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 573 */     if ((height != -1) && (expandCount > 0)) {
/* 574 */       int totalHeight = 0;
/* 575 */       for (int i = 0; i < rowCount; i++) {
/* 576 */         totalHeight += heights[i];
/*     */       }
/* 578 */       int c = expandCount;
/* 579 */       int delta = (availableHeight - totalHeight) / c;
/* 580 */       int remainder = (availableHeight - totalHeight) % c;
/* 581 */       int last = -1;
/* 582 */       while (totalHeight != availableHeight) {
/* 583 */         for (int i = 0; i < rowCount; i++) {
/* 584 */           if (expandRow[i] != 0) {
/* 585 */             if (heights[i] + delta > minHeights[i]) {
/* 586 */               heights[(last = i)] = (heights[i] + delta);
/*     */             } else {
/* 588 */               heights[i] = minHeights[i];
/* 589 */               expandRow[i] = false;
/* 590 */               c--;
/*     */             }
/*     */           }
/*     */         }
/* 594 */         if (last > -1) { heights[last] += remainder;
/*     */         }
/* 596 */         for (int i = 0; i < rowCount; i++) {
/* 597 */           for (int j = 0; j < columnCount; j++) {
/* 598 */             GridData data = getData(grid, i, j, rowCount, columnCount, false);
/* 599 */             if (data != null) {
/* 600 */               int vSpan = Math.max(1, Math.min(data.verticalSpan, rowCount));
/* 601 */               if ((vSpan > 1) && (
/* 602 */                 (!data.grabExcessVerticalSpace) || (data.minimumHeight != 0))) {
/* 603 */                 int spanHeight = 0;int spanExpandCount = 0;
/* 604 */                 for (int k = 0; k < vSpan; k++) {
/* 605 */                   spanHeight += heights[(i - k)];
/* 606 */                   if (expandRow[(i - k)] != 0) spanExpandCount++;
/*     */                 }
/* 608 */                 int h = (!data.grabExcessVerticalSpace) || (data.minimumHeight == -1) ? data.cacheHeight : data.minimumHeight;
/* 609 */                 h += data.verticalIndent - spanHeight - (vSpan - 1) * this.verticalSpacing;
/* 610 */                 if (h > 0) {
/* 611 */                   if (spanExpandCount == 0) {
/* 612 */                     heights[i] += h;
/*     */                   } else {
/* 614 */                     int delta2 = h / spanExpandCount;
/* 615 */                     int remainder2 = h % spanExpandCount;int last2 = -1;
/* 616 */                     for (int k = 0; k < vSpan; k++) {
/* 617 */                       if (expandRow[(i - k)] != 0) {
/* 618 */                         heights[(last2 = i - k)] += delta2;
/*     */                       }
/*     */                     }
/* 621 */                     if (last2 > -1) { heights[last2] += remainder2;
/*     */                     }
/*     */                   }
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/* 629 */         if (c == 0) break;
/* 630 */         totalHeight = 0;
/* 631 */         for (int i = 0; i < rowCount; i++) {
/* 632 */           totalHeight += heights[i];
/*     */         }
/* 634 */         delta = (availableHeight - totalHeight) / c;
/* 635 */         remainder = (availableHeight - totalHeight) % c;
/* 636 */         last = -1;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 641 */     if (move) {
/* 642 */       int gridY = y + this.marginTop + this.marginHeight;
/* 643 */       for (int i = 0; i < rowCount; i++) {
/* 644 */         int gridX = x + this.marginLeft + this.marginWidth;
/* 645 */         for (int j = 0; j < columnCount; j++) {
/* 646 */           GridData data = getData(grid, i, j, rowCount, columnCount, true);
/* 647 */           if (data != null) {
/* 648 */             int hSpan = Math.max(1, Math.min(data.horizontalSpan, columnCount));
/* 649 */             int vSpan = Math.max(1, data.verticalSpan);
/* 650 */             int cellWidth = 0;int cellHeight = 0;
/* 651 */             for (int k = 0; k < hSpan; k++) {
/* 652 */               cellWidth += widths[(j + k)];
/*     */             }
/* 654 */             for (int k = 0; k < vSpan; k++) {
/* 655 */               cellHeight += heights[(i + k)];
/*     */             }
/* 657 */             cellWidth += this.horizontalSpacing * (hSpan - 1);
/* 658 */             int childX = gridX + data.horizontalIndent;
/* 659 */             int childWidth = Math.min(data.cacheWidth, cellWidth);
/* 660 */             switch (data.horizontalAlignment) {
/*     */             case 2: 
/*     */             case 16777216: 
/* 663 */               childX += Math.max(0, (cellWidth - data.horizontalIndent - childWidth) / 2);
/* 664 */               break;
/*     */             case 3: 
/*     */             case 131072: 
/*     */             case 16777224: 
/* 668 */               childX += Math.max(0, cellWidth - data.horizontalIndent - childWidth);
/* 669 */               break;
/*     */             case 4: 
/* 671 */               childWidth = cellWidth - data.horizontalIndent;
/*     */             }
/*     */             
/* 674 */             cellHeight += this.verticalSpacing * (vSpan - 1);
/* 675 */             int childY = gridY + data.verticalIndent;
/* 676 */             int childHeight = Math.min(data.cacheHeight, cellHeight);
/* 677 */             switch (data.verticalAlignment) {
/*     */             case 2: 
/*     */             case 16777216: 
/* 680 */               childY += Math.max(0, (cellHeight - data.verticalIndent - childHeight) / 2);
/* 681 */               break;
/*     */             case 3: 
/*     */             case 1024: 
/*     */             case 16777224: 
/* 685 */               childY += Math.max(0, cellHeight - data.verticalIndent - childHeight);
/* 686 */               break;
/*     */             case 4: 
/* 688 */               childHeight = cellHeight - data.verticalIndent;
/*     */             }
/*     */             
/* 691 */             Control child = grid[i][j];
/* 692 */             if (child != null) {
/* 693 */               child.setBounds(childX, childY, childWidth, childHeight);
/*     */             }
/*     */           }
/* 696 */           gridX += widths[j] + this.horizontalSpacing;
/*     */         }
/* 698 */         gridY += heights[i] + this.verticalSpacing;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 703 */     for (int i = 0; i < flushLength; i++) {
/* 704 */       flush[i].cacheWidth = (flush[i].cacheHeight = -1);
/*     */     }
/*     */     
/* 707 */     int totalDefaultWidth = 0;
/* 708 */     int totalDefaultHeight = 0;
/* 709 */     for (int i = 0; i < columnCount; i++) {
/* 710 */       totalDefaultWidth += widths[i];
/*     */     }
/* 712 */     for (int i = 0; i < rowCount; i++) {
/* 713 */       totalDefaultHeight += heights[i];
/*     */     }
/* 715 */     totalDefaultWidth += this.horizontalSpacing * (columnCount - 1) + this.marginLeft + this.marginWidth * 2 + this.marginRight;
/* 716 */     totalDefaultHeight += this.verticalSpacing * (rowCount - 1) + this.marginTop + this.marginHeight * 2 + this.marginBottom;
/* 717 */     return new Point(totalDefaultWidth, totalDefaultHeight);
/*     */   }
/*     */   
/*     */   String getName() {
/* 721 */     String string = getClass().getName();
/* 722 */     int index = string.lastIndexOf('.');
/* 723 */     if (index == -1) return string;
/* 724 */     return string.substring(index + 1, string.length());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 735 */     String string = getName() + " {";
/* 736 */     if (this.numColumns != 1) string = string + "numColumns=" + this.numColumns + " ";
/* 737 */     if (this.makeColumnsEqualWidth) string = string + "makeColumnsEqualWidth=" + this.makeColumnsEqualWidth + " ";
/* 738 */     if (this.marginWidth != 0) string = string + "marginWidth=" + this.marginWidth + " ";
/* 739 */     if (this.marginHeight != 0) string = string + "marginHeight=" + this.marginHeight + " ";
/* 740 */     if (this.marginLeft != 0) string = string + "marginLeft=" + this.marginLeft + " ";
/* 741 */     if (this.marginRight != 0) string = string + "marginRight=" + this.marginRight + " ";
/* 742 */     if (this.marginTop != 0) string = string + "marginTop=" + this.marginTop + " ";
/* 743 */     if (this.marginBottom != 0) string = string + "marginBottom=" + this.marginBottom + " ";
/* 744 */     if (this.horizontalSpacing != 0) string = string + "horizontalSpacing=" + this.horizontalSpacing + " ";
/* 745 */     if (this.verticalSpacing != 0) string = string + "verticalSpacing=" + this.verticalSpacing + " ";
/* 746 */     string = string.trim();
/* 747 */     string = string + "}";
/* 748 */     return string;
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/layout/GridLayout.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */