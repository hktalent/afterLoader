package org.eclipse.swt.accessibility;

public class AccessibleHyperlinkAdapter
  implements AccessibleHyperlinkListener
{
  public void getAnchor(AccessibleHyperlinkEvent e) {}
  
  public void getAnchorTarget(AccessibleHyperlinkEvent e) {}
  
  public void getStartIndex(AccessibleHyperlinkEvent e) {}
  
  public void getEndIndex(AccessibleHyperlinkEvent e) {}
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/accessibility/AccessibleHyperlinkAdapter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */