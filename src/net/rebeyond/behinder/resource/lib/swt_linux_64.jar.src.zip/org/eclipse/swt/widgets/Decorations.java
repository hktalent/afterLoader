/*     */ package org.eclipse.swt.widgets;
/*     */ 
/*     */ import org.eclipse.swt.graphics.Image;
/*     */ import org.eclipse.swt.graphics.ImageData;
/*     */ import org.eclipse.swt.internal.C;
/*     */ import org.eclipse.swt.internal.ImageList;
/*     */ import org.eclipse.swt.internal.gtk.GTK;
/*     */ import org.eclipse.swt.internal.gtk.OS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Decorations
/*     */   extends Canvas
/*     */ {
/*     */   String text;
/*     */   Image image;
/* 100 */   Image[] images = new Image[0];
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   boolean minimized;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   boolean maximized;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   Menu menuBar;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   Menu[] menus;
/*     */   
/*     */ 
/*     */ 
/*     */   Control savedFocus;
/*     */   
/*     */ 
/*     */ 
/*     */   Button defaultButton;
/*     */   
/*     */ 
/*     */ 
/*     */   Button saveDefault;
/*     */   
/*     */ 
/*     */ 
/*     */   long accelGroup;
/*     */   
/*     */ 
/*     */ 
/*     */   long vboxHandle;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   Decorations() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Decorations(Composite parent, int style)
/*     */   {
/* 152 */     super(parent, checkStyle(style));
/*     */   }
/*     */   
/*     */   static int checkStyle(int style) {
/* 156 */     if ((style & 0x8) != 0) {
/* 157 */       style &= 0xF30F;
/* 158 */     } else if ((style & 0x800000) != 0) {
/* 159 */       style |= 0x20;
/*     */     }
/* 161 */     if ((style & 0x4C0) != 0) {
/* 162 */       style |= 0x20;
/*     */     }
/* 164 */     return style;
/*     */   }
/*     */   
/*     */   protected void checkSubclass()
/*     */   {
/* 169 */     if (!isValidSubclass()) error(43);
/*     */   }
/*     */   
/*     */   void _setImages(Image[] images) {
/* 173 */     if ((images != null) && (images.length > 1)) {
/* 174 */       Image[] bestImages = new Image[images.length];
/* 175 */       System.arraycopy(images, 0, bestImages, 0, images.length);
/* 176 */       sort(bestImages);
/* 177 */       images = bestImages;
/*     */     }
/* 179 */     long pixbufs = 0L;
/* 180 */     if (images != null) {
/* 181 */       for (int i = 0; i < images.length; i++) {
/* 182 */         Image image = images[i];
/* 183 */         long pixbuf = ImageList.createPixbuf(image);
/* 184 */         pixbufs = OS.g_list_append(pixbufs, pixbuf);
/*     */       }
/*     */     }
/* 187 */     GTK.gtk_window_set_icon_list(topHandle(), pixbufs);
/* 188 */     long[] data = new long[1];
/* 189 */     long temp = pixbufs;
/* 190 */     while (temp != 0L) {
/* 191 */       C.memmove(data, temp, C.PTR_SIZEOF);
/* 192 */       OS.g_object_unref(data[0]);
/* 193 */       temp = OS.g_list_next(temp);
/*     */     }
/* 195 */     if (pixbufs != 0L) OS.g_list_free(pixbufs);
/*     */   }
/*     */   
/*     */   void addMenu(Menu menu) {
/* 199 */     if (this.menus == null) this.menus = new Menu[4];
/* 200 */     for (int i = 0; i < this.menus.length; i++) {
/* 201 */       if (this.menus[i] == null) {
/* 202 */         this.menus[i] = menu;
/* 203 */         return;
/*     */       }
/*     */     }
/* 206 */     Menu[] newMenus = new Menu[this.menus.length + 4];
/* 207 */     newMenus[this.menus.length] = menu;
/* 208 */     System.arraycopy(this.menus, 0, newMenus, 0, this.menus.length);
/* 209 */     this.menus = newMenus;
/*     */   }
/*     */   
/*     */   int compare(ImageData data1, ImageData data2) {
/* 213 */     if ((data1.width == data2.width) && (data1.height == data2.height)) {
/* 214 */       int transparent1 = data1.getTransparencyType();
/* 215 */       int transparent2 = data2.getTransparencyType();
/* 216 */       if (transparent1 == 1) return -1;
/* 217 */       if (transparent2 == 1) return 1;
/* 218 */       if (transparent1 == 2) return -1;
/* 219 */       if (transparent2 == 2) return 1;
/* 220 */       if (transparent1 == 4) return -1;
/* 221 */       if (transparent2 == 4) return 1;
/* 222 */       return 0;
/*     */     }
/* 224 */     return (data1.width > data2.width) || (data1.height > data2.height) ? -1 : 1;
/*     */   }
/*     */   
/*     */   Widget computeTabGroup()
/*     */   {
/* 229 */     return this;
/*     */   }
/*     */   
/*     */   Control computeTabRoot()
/*     */   {
/* 234 */     return this;
/*     */   }
/*     */   
/*     */   void createAccelGroup() {
/* 238 */     if (this.accelGroup != 0L) return;
/* 239 */     this.accelGroup = GTK.gtk_accel_group_new();
/* 240 */     if (this.accelGroup == 0L) { error(2);
/*     */     }
/* 242 */     long shellHandle = topHandle();
/* 243 */     GTK.gtk_window_add_accel_group(shellHandle, this.accelGroup);
/*     */   }
/*     */   
/*     */   void createWidget(int index)
/*     */   {
/* 248 */     super.createWidget(index);
/* 249 */     this.text = "";
/*     */   }
/*     */   
/*     */   void destroyAccelGroup() {
/* 253 */     if (this.accelGroup == 0L) return;
/* 254 */     long shellHandle = topHandle();
/* 255 */     GTK.gtk_window_remove_accel_group(shellHandle, this.accelGroup);
/*     */     
/*     */ 
/* 258 */     this.accelGroup = 0L;
/*     */   }
/*     */   
/*     */   void fixAccelGroup() {
/* 262 */     if (this.menuBar == null) return;
/* 263 */     destroyAccelGroup();
/* 264 */     createAccelGroup();
/* 265 */     this.menuBar.addAccelerators(this.accelGroup);
/*     */   }
/*     */   
/*     */   void fixDecorations(Decorations newDecorations, Control control, Menu[] menus) {
/* 269 */     if (this == newDecorations) return;
/* 270 */     if (control == this.savedFocus) this.savedFocus = null;
/* 271 */     if (control == this.defaultButton) this.defaultButton = null;
/* 272 */     if (control == this.saveDefault) this.saveDefault = null;
/* 273 */     if (menus == null) return;
/* 274 */     Menu menu = control.menu;
/* 275 */     if (menu != null) {
/* 276 */       int index = 0;
/* 277 */       while (index < menus.length) {
/* 278 */         if (menus[index] == menu) {
/* 279 */           control.setMenu(null);
/* 280 */           return;
/*     */         }
/* 282 */         index++;
/*     */       }
/* 284 */       menu.fixMenus(newDecorations);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Button getDefaultButton()
/*     */   {
/* 302 */     checkWidget();
/* 303 */     Button button = this.defaultButton != null ? this.defaultButton : this.saveDefault;
/* 304 */     if ((button != null) && (button.isDisposed())) return null;
/* 305 */     return button;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Image getImage()
/*     */   {
/* 330 */     checkWidget();
/* 331 */     return this.image;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Image[] getImages()
/*     */   {
/* 362 */     checkWidget();
/* 363 */     if (this.images == null) return new Image[0];
/* 364 */     Image[] result = new Image[this.images.length];
/* 365 */     System.arraycopy(this.images, 0, result, 0, this.images.length);
/* 366 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getMaximized()
/*     */   {
/* 384 */     checkWidget();
/* 385 */     return this.maximized;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Menu getMenuBar()
/*     */   {
/* 400 */     checkWidget();
/* 401 */     return this.menuBar;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getMinimized()
/*     */   {
/* 419 */     checkWidget();
/* 420 */     return this.minimized;
/*     */   }
/*     */   
/*     */   String getNameText()
/*     */   {
/* 425 */     return getText();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getText()
/*     */   {
/* 442 */     checkWidget();
/* 443 */     return this.text;
/*     */   }
/*     */   
/*     */   public boolean isReparentable()
/*     */   {
/* 448 */     checkWidget();
/* 449 */     return false;
/*     */   }
/*     */   
/*     */   boolean isTabGroup()
/*     */   {
/* 454 */     return true;
/*     */   }
/*     */   
/*     */   boolean isTabItem()
/*     */   {
/* 459 */     return false;
/*     */   }
/*     */   
/*     */   Decorations menuShell()
/*     */   {
/* 464 */     return this;
/*     */   }
/*     */   
/*     */   void removeMenu(Menu menu) {
/* 468 */     if (this.menus == null) return;
/* 469 */     for (int i = 0; i < this.menus.length; i++) {
/* 470 */       if (this.menus[i] == menu) {
/* 471 */         this.menus[i] = null;
/* 472 */         return;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   void releaseChildren(boolean destroy)
/*     */   {
/* 479 */     if (this.menuBar != null) {
/* 480 */       this.menuBar.release(false);
/* 481 */       this.menuBar = null;
/*     */     }
/* 483 */     super.releaseChildren(destroy);
/* 484 */     if (this.menus != null) {
/* 485 */       for (int i = 0; i < this.menus.length; i++) {
/* 486 */         Menu menu = this.menus[i];
/* 487 */         if ((menu != null) && (!menu.isDisposed())) {
/* 488 */           menu.dispose();
/*     */         }
/*     */       }
/* 491 */       this.menus = null;
/*     */     }
/*     */   }
/*     */   
/*     */   void releaseHandle()
/*     */   {
/* 497 */     super.releaseHandle();
/* 498 */     this.vboxHandle = 0L;
/*     */   }
/*     */   
/*     */   void releaseWidget()
/*     */   {
/* 503 */     super.releaseWidget();
/* 504 */     this.image = null;
/* 505 */     this.images = null;
/* 506 */     this.savedFocus = null;
/* 507 */     this.defaultButton = (this.saveDefault = null);
/*     */   }
/*     */   
/*     */   void reskinChildren(int flags)
/*     */   {
/* 512 */     if (this.menuBar != null) this.menuBar.reskin(flags);
/* 513 */     if (this.menus != null) {
/* 514 */       for (int i = 0; i < this.menus.length; i++) {
/* 515 */         Menu menu = this.menus[i];
/* 516 */         if (menu != null) menu.reskin(flags);
/*     */       }
/*     */     }
/* 519 */     super.reskinChildren(flags);
/*     */   }
/*     */   
/*     */   boolean restoreFocus() {
/* 523 */     if ((this.savedFocus != null) && (this.savedFocus.isDisposed())) this.savedFocus = null;
/* 524 */     boolean restored = (this.savedFocus != null) && (this.savedFocus.setFocus());
/* 525 */     this.savedFocus = null;
/* 526 */     return restored;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDefaultButton(Button button)
/*     */   {
/* 555 */     checkWidget();
/* 556 */     long buttonHandle = 0L;
/* 557 */     if (button != null) {
/* 558 */       if (button.isDisposed()) error(5);
/* 559 */       if (button.menuShell() != this) error(32);
/* 560 */       buttonHandle = button.handle;
/*     */     }
/* 562 */     this.saveDefault = (this.defaultButton = button);
/* 563 */     GTK.gtk_window_set_default(topHandle(), buttonHandle);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setImage(Image image)
/*     */   {
/* 584 */     checkWidget();
/* 585 */     this.image = image;
/* 586 */     if ((image != null) && (image.isDisposed())) {
/* 587 */       error(5);
/*     */     }
/* 589 */     _setImages(image != null ? new Image[] { image } : null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setImages(Image[] images)
/*     */   {
/* 617 */     checkWidget();
/* 618 */     if (images == null) error(5);
/* 619 */     for (int i = 0; i < images.length; i++) {
/* 620 */       if ((images[i] == null) || (images[i].isDisposed())) error(5);
/*     */     }
/* 622 */     this.images = images;
/* 623 */     _setImages(images);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMaximized(boolean maximized)
/*     */   {
/* 650 */     checkWidget();
/* 651 */     this.maximized = maximized;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMenuBar(Menu menu)
/*     */   {
/* 670 */     checkWidget();
/* 671 */     if (this.menuBar == menu) return;
/* 672 */     if (menu != null) {
/* 673 */       if ((menu.style & 0x2) == 0) error(33);
/* 674 */       if (menu.parent != this) error(32);
/*     */     }
/* 676 */     this.menuBar = menu;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMinimized(boolean minimized)
/*     */   {
/* 703 */     checkWidget();
/* 704 */     this.minimized = minimized;
/*     */   }
/*     */   
/*     */   void setOrientation(boolean create)
/*     */   {
/* 709 */     super.setOrientation(create);
/* 710 */     if ((!create) && 
/* 711 */       (this.menuBar != null)) this.menuBar._setOrientation(this.style & 0x6000000);
/*     */   }
/*     */   
/*     */   void setSavedFocus(Control control)
/*     */   {
/* 716 */     if (this == control) return;
/* 717 */     this.savedFocus = control;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setText(String string)
/*     */   {
/* 740 */     checkWidget();
/* 741 */     if (string == null) error(4);
/* 742 */     this.text = string;
/*     */   }
/*     */   
/*     */   void sort(Image[] images)
/*     */   {
/* 747 */     int length = images.length;
/* 748 */     if (length <= 1) return;
/* 749 */     ImageData[] datas = new ImageData[length];
/* 750 */     for (int i = 0; i < length; i++) {
/* 751 */       datas[i] = images[i].getImageData();
/*     */     }
/* 753 */     for (int gap = length / 2; gap > 0; gap /= 2) {
/* 754 */       for (int i = gap; i < length; i++) {
/* 755 */         for (int j = i - gap; j >= 0; j -= gap) {
/* 756 */           if (compare(datas[j], datas[(j + gap)]) >= 0) {
/* 757 */             Image swap = images[j];
/* 758 */             images[j] = images[(j + gap)];
/* 759 */             images[(j + gap)] = swap;
/* 760 */             ImageData swapData = datas[j];
/* 761 */             datas[j] = datas[(j + gap)];
/* 762 */             datas[(j + gap)] = swapData;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   boolean traverseItem(boolean next)
/*     */   {
/* 771 */     return false;
/*     */   }
/*     */   
/*     */   boolean traverseReturn()
/*     */   {
/* 776 */     Button button = this.defaultButton != null ? this.defaultButton : this.saveDefault;
/* 777 */     if ((button == null) || (button.isDisposed())) { return false;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 784 */     if ((!button.isVisible()) || (!button.isEnabled())) return true;
/* 785 */     long shellHandle = _getShell().topHandle();
/* 786 */     return GTK.gtk_window_activate_default(shellHandle);
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/widgets/Decorations.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */