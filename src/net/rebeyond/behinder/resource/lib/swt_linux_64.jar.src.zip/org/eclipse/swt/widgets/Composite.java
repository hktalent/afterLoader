/*      */ package org.eclipse.swt.widgets;
/*      */ 
/*      */ import org.eclipse.swt.SWTError;
/*      */ import org.eclipse.swt.graphics.Device;
/*      */ import org.eclipse.swt.graphics.GC;
/*      */ import org.eclipse.swt.graphics.GCData;
/*      */ import org.eclipse.swt.graphics.Image;
/*      */ import org.eclipse.swt.graphics.Point;
/*      */ import org.eclipse.swt.graphics.Rectangle;
/*      */ import org.eclipse.swt.graphics.Region;
/*      */ import org.eclipse.swt.internal.C;
/*      */ import org.eclipse.swt.internal.DPIUtil;
/*      */ import org.eclipse.swt.internal.cairo.Cairo;
/*      */ import org.eclipse.swt.internal.gtk.GDK;
/*      */ import org.eclipse.swt.internal.gtk.GTK;
/*      */ import org.eclipse.swt.internal.gtk.GdkColor;
/*      */ import org.eclipse.swt.internal.gtk.GdkEventButton;
/*      */ import org.eclipse.swt.internal.gtk.GdkEventExpose;
/*      */ import org.eclipse.swt.internal.gtk.GdkEventKey;
/*      */ import org.eclipse.swt.internal.gtk.GdkRGBA;
/*      */ import org.eclipse.swt.internal.gtk.GdkRectangle;
/*      */ import org.eclipse.swt.internal.gtk.GtkAllocation;
/*      */ import org.eclipse.swt.internal.gtk.GtkFixed;
/*      */ import org.eclipse.swt.internal.gtk.GtkRequisition;
/*      */ import org.eclipse.swt.internal.gtk.OS;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class Composite
/*      */   extends Scrollable
/*      */ {
/*      */   public long embeddedHandle;
/*      */   long imHandle;
/*      */   long socketHandle;
/*      */   Layout layout;
/*      */   Control[] tabList;
/*      */   int layoutCount;
/*      */   int backgroundMode;
/*      */   long fixClipHandle;
/*   81 */   long[] fixClipHandleChildren = new long[0];
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final String NO_INPUT_METHOD = "org.eclipse.swt.internal.gtk.noInputMethod";
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   Composite() {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Composite(Composite parent, int style)
/*      */   {
/*  122 */     super(parent, checkStyle(style));
/*      */   }
/*      */   
/*      */   static int checkStyle(int style) {
/*  126 */     style &= 0xFFFBFFFF;
/*  127 */     style &= 0xBFFFFFFF;
/*  128 */     return style;
/*      */   }
/*      */   
/*      */   Control[] _getChildren() {
/*  132 */     long parentHandle = parentingHandle();
/*  133 */     long list = GTK.gtk_container_get_children(parentHandle);
/*  134 */     if (list == 0L) return new Control[0];
/*  135 */     int count = OS.g_list_length(list);
/*  136 */     Control[] children = new Control[count];
/*  137 */     int i = 0;
/*  138 */     long temp = list;
/*  139 */     while (temp != 0L) {
/*  140 */       long handle = OS.g_list_data(temp);
/*  141 */       if (handle != 0L) {
/*  142 */         Widget widget = this.display.getWidget(handle);
/*  143 */         if ((widget != null) && (widget != this) && 
/*  144 */           ((widget instanceof Control))) {
/*  145 */           children[(i++)] = ((Control)widget);
/*      */         }
/*      */       }
/*      */       
/*  149 */       temp = OS.g_list_next(temp);
/*      */     }
/*  151 */     OS.g_list_free(list);
/*  152 */     if (i == count) return children;
/*  153 */     Control[] newChildren = new Control[i];
/*  154 */     System.arraycopy(children, 0, newChildren, 0, i);
/*  155 */     return newChildren;
/*      */   }
/*      */   
/*      */   Control[] _getTabList() {
/*  159 */     if (this.tabList == null) return this.tabList;
/*  160 */     int count = 0;
/*  161 */     for (int i = 0; i < this.tabList.length; i++) {
/*  162 */       if (!this.tabList[i].isDisposed()) count++;
/*      */     }
/*  164 */     if (count == this.tabList.length) return this.tabList;
/*  165 */     Control[] newList = new Control[count];
/*  166 */     int index = 0;
/*  167 */     for (int i = 0; i < this.tabList.length; i++) {
/*  168 */       if (!this.tabList[i].isDisposed()) {
/*  169 */         newList[(index++)] = this.tabList[i];
/*      */       }
/*      */     }
/*  172 */     this.tabList = newList;
/*  173 */     return this.tabList;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public void changed(Control[] changed)
/*      */   {
/*  197 */     layout(changed, 4);
/*      */   }
/*      */   
/*      */   void checkBuffered()
/*      */   {
/*  202 */     if (((this.style & 0x20000000) == 0) && ((this.style & 0x40000) != 0)) {
/*  203 */       return;
/*      */     }
/*  205 */     super.checkBuffered();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected void checkSubclass() {}
/*      */   
/*      */ 
/*      */   long childStyle()
/*      */   {
/*  215 */     if (this.scrolledHandle != 0L) return 0L;
/*  216 */     return super.childStyle();
/*      */   }
/*      */   
/*      */   Point computeSizeInPixels(int wHint, int hHint, boolean changed)
/*      */   {
/*  221 */     checkWidget();
/*  222 */     this.display.runSkin();
/*  223 */     if ((wHint != -1) && (wHint < 0)) wHint = 0;
/*  224 */     if ((hHint != -1) && (hHint < 0)) hHint = 0;
/*      */     Point size;
/*  226 */     Point size; if (this.layout != null) {
/*  227 */       if ((wHint == -1) || (hHint == -1)) {
/*  228 */         changed |= (this.state & 0x40000) != 0;
/*  229 */         Point size = DPIUtil.autoScaleUp(this.layout.computeSize(this, DPIUtil.autoScaleDown(wHint), DPIUtil.autoScaleDown(hHint), changed));
/*  230 */         this.state &= 0xFFFBFFFF;
/*      */       } else {
/*  232 */         size = new Point(wHint, hHint);
/*      */       }
/*      */     } else {
/*  235 */       size = minimumSize(wHint, hHint, changed);
/*  236 */       if (size.x == 0) size.x = 64;
/*  237 */       if (size.y == 0) size.y = 64;
/*      */     }
/*  239 */     if (wHint != -1) size.x = wHint;
/*  240 */     if (hHint != -1) size.y = hHint;
/*  241 */     Rectangle trim = DPIUtil.autoScaleUp(computeTrim(0, 0, DPIUtil.autoScaleDown(size.x), DPIUtil.autoScaleDown(size.y)));
/*  242 */     return new Point(trim.width, trim.height);
/*      */   }
/*      */   
/*      */   Widget[] computeTabList()
/*      */   {
/*  247 */     Widget[] result = super.computeTabList();
/*  248 */     if (result.length == 0) return result;
/*  249 */     Control[] list = this.tabList != null ? _getTabList() : _getChildren();
/*  250 */     for (int i = 0; i < list.length; i++) {
/*  251 */       Control child = list[i];
/*  252 */       Widget[] childList = child.computeTabList();
/*  253 */       if (childList.length != 0) {
/*  254 */         Widget[] newResult = new Widget[result.length + childList.length];
/*  255 */         System.arraycopy(result, 0, newResult, 0, result.length);
/*  256 */         System.arraycopy(childList, 0, newResult, result.length, childList.length);
/*  257 */         result = newResult;
/*      */       }
/*      */     }
/*  260 */     return result;
/*      */   }
/*      */   
/*      */   void createHandle(int index)
/*      */   {
/*  265 */     this.state |= 0x200000A;
/*  266 */     boolean scrolled = (this.style & 0x300) != 0;
/*  267 */     if (!scrolled) this.state |= 0x10000;
/*  268 */     createHandle(index, true, (scrolled) || ((this.style & 0x800) != 0));
/*      */   }
/*      */   
/*      */   int applyThemeBackground()
/*      */   {
/*  273 */     return (this.backgroundAlpha == 0) || ((this.style & 0x300) == 0) ? 1 : 0;
/*      */   }
/*      */   
/*      */   void createHandle(int index, boolean fixed, boolean scrolled) {
/*  277 */     if (scrolled) {
/*  278 */       if (fixed) {
/*  279 */         this.fixedHandle = OS.g_object_new(this.display.gtk_fixed_get_type(), 0L);
/*  280 */         if (this.fixedHandle == 0L) error(2);
/*  281 */         GTK.gtk_widget_set_has_window(this.fixedHandle, true);
/*      */       }
/*  283 */       long vadj = GTK.gtk_adjustment_new(0.0D, 0.0D, 100.0D, 1.0D, 10.0D, 10.0D);
/*  284 */       if (vadj == 0L) error(2);
/*  285 */       long hadj = GTK.gtk_adjustment_new(0.0D, 0.0D, 100.0D, 1.0D, 10.0D, 10.0D);
/*  286 */       if (hadj == 0L) error(2);
/*  287 */       this.scrolledHandle = GTK.gtk_scrolled_window_new(hadj, vadj);
/*  288 */       if (this.scrolledHandle == 0L) error(2);
/*      */     }
/*  290 */     this.handle = OS.g_object_new(this.display.gtk_fixed_get_type(), 0L);
/*  291 */     if (this.handle == 0L) error(2);
/*  292 */     GTK.gtk_widget_set_has_window(this.handle, true);
/*  293 */     GTK.gtk_widget_set_can_focus(this.handle, true);
/*  294 */     if (((this.style & 0x1000000) == 0) && 
/*  295 */       ((this.state & 0x2) != 0))
/*      */     {
/*  297 */       if (this.display.getData("org.eclipse.swt.internal.gtk.noInputMethod") == null) {
/*  298 */         this.imHandle = GTK.gtk_im_multicontext_new();
/*  299 */         if (this.imHandle == 0L) { error(2);
/*      */         }
/*      */       }
/*      */     }
/*  303 */     if (scrolled) {
/*  304 */       if (fixed) { GTK.gtk_container_add(this.fixedHandle, this.scrolledHandle);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  310 */       boolean warnings = this.display.getWarnings();
/*  311 */       this.display.setWarnings(false);
/*  312 */       GTK.gtk_container_add(this.scrolledHandle, this.handle);
/*  313 */       this.display.setWarnings(warnings);
/*      */       
/*  315 */       int hsp = (this.style & 0x100) != 0 ? 0 : 2;
/*  316 */       int vsp = (this.style & 0x200) != 0 ? 0 : 2;
/*  317 */       GTK.gtk_scrolled_window_set_policy(this.scrolledHandle, hsp, vsp);
/*  318 */       if (hasBorder()) {
/*  319 */         GTK.gtk_scrolled_window_set_shadow_type(this.scrolledHandle, 3);
/*      */       }
/*      */     }
/*  322 */     if ((this.style & 0x1000000) != 0) {
/*  323 */       if (!OS.isX11()) {
/*  324 */         if (Device.DEBUG)
/*      */         {
/*  326 */           new SWTError(5, "SWT.EMBEDDED is currently not yet supported in Wayland. \nPlease refer to https://bugs.eclipse.org/bugs/show_bug.cgi?id=514487 for development status.").printStackTrace();
/*      */         }
/*      */       } else {
/*  329 */         this.socketHandle = GTK.gtk_socket_new();
/*  330 */         if (this.socketHandle == 0L) error(2);
/*  331 */         GTK.gtk_container_add(this.handle, this.socketHandle);
/*      */       }
/*      */     }
/*  334 */     if (((this.style & 0x100000) != 0) && ((this.style & 0x4000000) == 0)) {
/*  335 */       GTK.gtk_widget_set_redraw_on_allocate(this.handle, false);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  346 */     if (((this.style & 0x20000000) == 0) && ((this.style & 0x40000) != 0)) {
/*  347 */       GTK.gtk_widget_set_double_buffered(this.handle, false);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void fixChildClippings()
/*      */   {
/*  359 */     if (this.fixClipHandleChildren == null) {
/*  360 */       return;
/*      */     }
/*  362 */     GtkRequisition minimumSize = new GtkRequisition();
/*  363 */     GtkRequisition naturalSize = new GtkRequisition();
/*  364 */     GtkAllocation clip = new GtkAllocation();
/*  365 */     GtkAllocation allocation = new GtkAllocation();
/*  366 */     for (long widget : this.fixClipHandleChildren) {
/*  367 */       GTK.gtk_widget_get_allocation(widget, allocation);
/*  368 */       GTK.gtk_widget_get_clip(widget, clip);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  373 */       if (clip.x < 0) {
/*  374 */         clip.width += clip.x;
/*  375 */         clip.x = 0;
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  381 */         if ((allocation.x < -1) && ((allocation.width > 1) || (allocation.height > 1)))
/*      */         {
/*  383 */           allocation.width += allocation.x;
/*  384 */           allocation.x = 0;
/*      */           
/*  386 */           GTK.gtk_widget_get_preferred_size(widget, minimumSize, naturalSize);
/*      */           
/*  388 */           GTK.gtk_widget_size_allocate(widget, allocation);
/*  389 */           GTK.gtk_widget_queue_resize(widget);
/*      */         }
/*      */       }
/*      */       
/*  393 */       GTK.gtk_widget_set_clip(widget, allocation);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   long gtk_draw(long widget, long cairo)
/*      */   {
/*  400 */     if (GTK.GTK_VERSION >= OS.VERSION(3, 14, 0)) {
/*  401 */       long context = GTK.gtk_widget_get_style_context(widget);
/*  402 */       GtkAllocation allocation = new GtkAllocation();
/*  403 */       GTK.gtk_widget_get_allocation(widget, allocation);
/*  404 */       int width = (this.state & 0x200) != 0 ? 0 : allocation.width;
/*  405 */       int height = (this.state & 0x400) != 0 ? 0 : allocation.height;
/*      */       
/*      */ 
/*  408 */       GTK.gtk_render_background(context, cairo, 0.0D, 0.0D, width, height);
/*  409 */       if (GTK.GTK_VERSION >= OS.VERSION(3, 20, 0))
/*      */       {
/*      */ 
/*  412 */         if (widget == this.fixClipHandle) fixChildClippings();
/*      */       }
/*      */     }
/*  415 */     return super.gtk_draw(widget, cairo);
/*      */   }
/*      */   
/*      */   void deregister()
/*      */   {
/*  420 */     super.deregister();
/*  421 */     if (this.socketHandle != 0L) { this.display.removeWidget(this.socketHandle);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void drawBackground(GC gc, int x, int y, int width, int height, int offsetX, int offsetY)
/*      */   {
/*  452 */     checkWidget();
/*  453 */     Rectangle rect = DPIUtil.autoScaleUp(new Rectangle(x, y, width, height));
/*  454 */     offsetX = DPIUtil.autoScaleUp(offsetX);
/*  455 */     offsetY = DPIUtil.autoScaleUp(offsetY);
/*  456 */     drawBackgroundInPixels(gc, rect.x, rect.y, rect.width, rect.height, offsetX, offsetY);
/*      */   }
/*      */   
/*      */   void drawBackgroundInPixels(GC gc, int x, int y, int width, int height, int offsetX, int offsetY) {
/*  460 */     checkWidget();
/*  461 */     if (gc == null) error(4);
/*  462 */     if (gc.isDisposed()) error(5);
/*  463 */     Control control = findBackgroundControl();
/*  464 */     if (control != null) {
/*  465 */       GCData data = gc.getGCData();
/*  466 */       long cairo = data.cairo;
/*  467 */       Cairo.cairo_save(cairo);
/*  468 */       if (control.backgroundImage != null) {
/*  469 */         Point pt = this.display.mapInPixels(this, control, 0, 0);
/*  470 */         Cairo.cairo_translate(cairo, -pt.x - offsetX, -pt.y - offsetY);
/*  471 */         x += pt.x + offsetX;
/*  472 */         y += pt.y + offsetY;
/*  473 */         long surface = control.backgroundImage.surface;
/*  474 */         if (surface == 0L) {
/*  475 */           long drawable = control.backgroundImage.pixmap;
/*  476 */           int[] w = new int[1];int[] h = new int[1];
/*  477 */           GDK.gdk_pixmap_get_size(drawable, w, h);
/*  478 */           if (OS.isX11()) {
/*  479 */             long xDisplay = GDK.gdk_x11_display_get_xdisplay(GDK.gdk_display_get_default());
/*  480 */             long xVisual = GDK.gdk_x11_visual_get_xvisual(GDK.gdk_visual_get_system());
/*  481 */             long xDrawable = GDK.GDK_PIXMAP_XID(drawable);
/*  482 */             surface = Cairo.cairo_xlib_surface_create(xDisplay, xDrawable, xVisual, w[0], h[0]);
/*      */           } else {
/*  484 */             surface = Cairo.cairo_image_surface_create(0, w[0], h[0]);
/*      */           }
/*  486 */           if (surface == 0L) error(2);
/*      */         } else {
/*  488 */           Cairo.cairo_surface_reference(surface);
/*      */         }
/*  490 */         long pattern = Cairo.cairo_pattern_create_for_surface(surface);
/*  491 */         if (pattern == 0L) error(2);
/*  492 */         Cairo.cairo_pattern_set_extend(pattern, 1);
/*  493 */         if ((data.style & 0x8000000) != 0) {
/*  494 */           double[] matrix = { -1.0D, 0.0D, 0.0D, 1.0D, 0.0D, 0.0D };
/*  495 */           Cairo.cairo_pattern_set_matrix(pattern, matrix);
/*      */         }
/*  497 */         Cairo.cairo_set_source(cairo, pattern);
/*  498 */         Cairo.cairo_surface_destroy(surface);
/*  499 */         Cairo.cairo_pattern_destroy(pattern);
/*      */       }
/*  501 */       else if (GTK.GTK3) {
/*  502 */         GdkRGBA rgba = control.getBackgroundGdkRGBA();
/*  503 */         Cairo.cairo_set_source_rgba(cairo, rgba.red, rgba.green, rgba.blue, rgba.alpha);
/*      */       } else {
/*  505 */         GdkColor color = control.getBackgroundGdkColor();
/*  506 */         Cairo.cairo_set_source_rgba_compatibility(cairo, color);
/*      */       }
/*      */       
/*  509 */       Cairo.cairo_rectangle(cairo, x, y, width, height);
/*  510 */       Cairo.cairo_fill(cairo);
/*  511 */       Cairo.cairo_restore(cairo);
/*      */     } else {
/*  513 */       gc.fillRectangle(DPIUtil.autoScaleDown(new Rectangle(x, y, width, height)));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   void enableWidget(boolean enabled)
/*      */   {
/*  520 */     if ((this.state & 0x2) != 0) return;
/*  521 */     super.enableWidget(enabled);
/*      */   }
/*      */   
/*      */   Composite findDeferredControl() {
/*  525 */     return this.layoutCount > 0 ? this : this.parent.findDeferredControl();
/*      */   }
/*      */   
/*      */   Menu[] findMenus(Control control)
/*      */   {
/*  530 */     if (control == this) return new Menu[0];
/*  531 */     Menu[] result = super.findMenus(control);
/*  532 */     Control[] children = _getChildren();
/*  533 */     for (int i = 0; i < children.length; i++) {
/*  534 */       Control child = children[i];
/*  535 */       Menu[] menuList = child.findMenus(control);
/*  536 */       if (menuList.length != 0) {
/*  537 */         Menu[] newResult = new Menu[result.length + menuList.length];
/*  538 */         System.arraycopy(result, 0, newResult, 0, result.length);
/*  539 */         System.arraycopy(menuList, 0, newResult, result.length, menuList.length);
/*  540 */         result = newResult;
/*      */       }
/*      */     }
/*  543 */     return result;
/*      */   }
/*      */   
/*      */   void fixChildren(Shell newShell, Shell oldShell, Decorations newDecorations, Decorations oldDecorations, Menu[] menus)
/*      */   {
/*  548 */     super.fixChildren(newShell, oldShell, newDecorations, oldDecorations, menus);
/*  549 */     Control[] children = _getChildren();
/*  550 */     for (int i = 0; i < children.length; i++) {
/*  551 */       children[i].fixChildren(newShell, oldShell, newDecorations, oldDecorations, menus);
/*      */     }
/*      */   }
/*      */   
/*      */   void fixParentGdkWindow()
/*      */   {
/*  557 */     assert (GTK.GTK3);
/*      */     
/*      */ 
/*  560 */     for (Control child : _getChildren()) {
/*  561 */       child.fixParentGdkWindow();
/*      */     }
/*      */   }
/*      */   
/*      */   void fixModal(long group, long modalGroup)
/*      */   {
/*  567 */     Control[] controls = _getChildren();
/*  568 */     for (int i = 0; i < controls.length; i++) {
/*  569 */       controls[i].fixModal(group, modalGroup);
/*      */     }
/*      */   }
/*      */   
/*      */   void fixStyle()
/*      */   {
/*  575 */     super.fixStyle();
/*  576 */     if (this.scrolledHandle == 0L) fixStyle(this.handle);
/*  577 */     Control[] children = _getChildren();
/*  578 */     for (int i = 0; i < children.length; i++) {
/*  579 */       children[i].fixStyle();
/*      */     }
/*      */   }
/*      */   
/*      */   void fixTabList(Control control) {
/*  584 */     if (this.tabList == null) return;
/*  585 */     int count = 0;
/*  586 */     for (int i = 0; i < this.tabList.length; i++) {
/*  587 */       if (this.tabList[i] == control) count++;
/*      */     }
/*  589 */     if (count == 0) return;
/*  590 */     Control[] newList = null;
/*  591 */     int length = this.tabList.length - count;
/*  592 */     if (length != 0) {
/*  593 */       newList = new Control[length];
/*  594 */       int index = 0;
/*  595 */       for (int i = 0; i < this.tabList.length; i++) {
/*  596 */         if (this.tabList[i] != control) {
/*  597 */           newList[(index++)] = this.tabList[i];
/*      */         }
/*      */       }
/*      */     }
/*  601 */     this.tabList = newList;
/*      */   }
/*      */   
/*      */   void fixZOrder() {
/*  605 */     if ((this.state & 0x2) != 0) return;
/*  606 */     long parentHandle = parentingHandle();
/*  607 */     long parentWindow = gtk_widget_get_window(parentHandle);
/*  608 */     if (parentWindow == 0L) return;
/*  609 */     long[] userData = new long[1];
/*  610 */     long windowList = GDK.gdk_window_get_children(parentWindow);
/*  611 */     if (windowList != 0L) {
/*  612 */       long windows = windowList;
/*  613 */       while (windows != 0L) {
/*  614 */         long window = OS.g_list_data(windows);
/*  615 */         if (window != this.redrawWindow) {
/*  616 */           GDK.gdk_window_get_user_data(window, userData);
/*  617 */           if ((userData[0] == 0L) || (OS.G_OBJECT_TYPE(userData[0]) != this.display.gtk_fixed_get_type())) {
/*  618 */             GDK.gdk_window_lower(window);
/*      */           }
/*      */         }
/*  621 */         windows = OS.g_list_next(windows);
/*      */       }
/*  623 */       OS.g_list_free(windowList);
/*      */     }
/*      */   }
/*      */   
/*      */   long focusHandle()
/*      */   {
/*  629 */     if (this.socketHandle != 0L) return this.socketHandle;
/*  630 */     return super.focusHandle();
/*      */   }
/*      */   
/*      */   boolean forceFocus(long focusHandle)
/*      */   {
/*  635 */     if (this.socketHandle != 0L) GTK.gtk_widget_set_can_focus(focusHandle, true);
/*  636 */     boolean result = super.forceFocus(focusHandle);
/*  637 */     if (this.socketHandle != 0L) GTK.gtk_widget_set_can_focus(focusHandle, false);
/*  638 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getBackgroundMode()
/*      */   {
/*  660 */     checkWidget();
/*  661 */     return this.backgroundMode;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Control[] getChildren()
/*      */   {
/*  686 */     checkWidget();
/*  687 */     return _getChildren();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   int getChildrenCount()
/*      */   {
/*  695 */     long list = GTK.gtk_container_get_children(this.handle);
/*  696 */     if (list == 0L) return 0;
/*  697 */     int count = OS.g_list_length(list);
/*  698 */     OS.g_list_free(list);
/*  699 */     return count;
/*      */   }
/*      */   
/*      */   Rectangle getClientAreaInPixels()
/*      */   {
/*  704 */     checkWidget();
/*  705 */     if ((this.state & 0x2) != 0) {
/*  706 */       if (((this.state & 0x200) != 0) && ((this.state & 0x400) != 0)) {
/*  707 */         return new Rectangle(0, 0, 0, 0);
/*      */       }
/*  709 */       forceResize();
/*  710 */       long clientHandle = clientHandle();
/*  711 */       GtkAllocation allocation = new GtkAllocation();
/*  712 */       GTK.gtk_widget_get_allocation(clientHandle, allocation);
/*  713 */       int width = (this.state & 0x200) != 0 ? 0 : allocation.width;
/*  714 */       int height = (this.state & 0x400) != 0 ? 0 : allocation.height;
/*  715 */       return new Rectangle(0, 0, width, height);
/*      */     }
/*  717 */     return super.getClientAreaInPixels();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Layout getLayout()
/*      */   {
/*  732 */     checkWidget();
/*  733 */     return this.layout;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getLayoutDeferred()
/*      */   {
/*  753 */     checkWidget();
/*  754 */     return this.layoutCount > 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Control[] getTabList()
/*      */   {
/*  770 */     checkWidget();
/*  771 */     Control[] tabList = _getTabList();
/*  772 */     if (tabList == null) {
/*  773 */       int count = 0;
/*  774 */       Control[] list = _getChildren();
/*  775 */       for (int i = 0; i < list.length; i++) {
/*  776 */         if (list[i].isTabGroup()) count++;
/*      */       }
/*  778 */       tabList = new Control[count];
/*  779 */       int index = 0;
/*  780 */       for (int i = 0; i < list.length; i++) {
/*  781 */         if (list[i].isTabGroup()) {
/*  782 */           tabList[(index++)] = list[i];
/*      */         }
/*      */       }
/*      */     }
/*  786 */     return tabList;
/*      */   }
/*      */   
/*      */   long gtk_button_press_event(long widget, long event)
/*      */   {
/*  791 */     long result = super.gtk_button_press_event(widget, event);
/*  792 */     if (result != 0L) return result;
/*  793 */     if (((this.state & 0x2) != 0) && 
/*  794 */       ((this.style & 0x80000) == 0) && (hooksKeys())) {
/*  795 */       GdkEventButton gdkEvent = new GdkEventButton();
/*  796 */       OS.memmove(gdkEvent, event, GdkEventButton.sizeof);
/*  797 */       if ((gdkEvent.button == 1) && 
/*  798 */         (getChildrenCount() == 0)) { setFocus();
/*      */       }
/*      */     }
/*      */     
/*  802 */     return result;
/*      */   }
/*      */   
/*      */   long gtk_expose_event(long widget, long eventPtr)
/*      */   {
/*  807 */     if ((this.state & 0x40) != 0) return 0L;
/*  808 */     if ((this.state & 0x2) == 0) {
/*  809 */       return super.gtk_expose_event(widget, eventPtr);
/*      */     }
/*  811 */     if ((this.style & 0x200000) == 0) {
/*  812 */       return super.gtk_expose_event(widget, eventPtr);
/*      */     }
/*  814 */     if (!hooksPaint()) return 0L;
/*  815 */     GdkEventExpose gdkEvent = new GdkEventExpose();
/*  816 */     OS.memmove(gdkEvent, eventPtr, GdkEventExpose.sizeof);
/*  817 */     long[] rectangles = new long[1];
/*  818 */     int[] n_rectangles = new int[1];
/*  819 */     GDK.gdk_region_get_rectangles(gdkEvent.region, rectangles, n_rectangles);
/*  820 */     GdkRectangle rect = new GdkRectangle();
/*  821 */     for (int i = 0; i < n_rectangles[0]; i++) {
/*  822 */       Event event = new Event();
/*  823 */       OS.memmove(rect, rectangles[0] + i * GdkRectangle.sizeof, GdkRectangle.sizeof);
/*  824 */       event.setBounds(DPIUtil.autoScaleDown(new Rectangle(rect.x, rect.y, rect.width, rect.height)));
/*  825 */       if ((this.style & 0x8000000) != 0) event.x = (DPIUtil.autoScaleDown(getClientWidth()) - event.width - event.x);
/*  826 */       long damageRgn = GDK.gdk_region_new();
/*  827 */       GDK.gdk_region_union_with_rect(damageRgn, rect);
/*  828 */       GCData data = new GCData();
/*  829 */       data.damageRgn = damageRgn;
/*  830 */       GC gc = event.gc = GC.gtk_new(this, data);
/*  831 */       sendEvent(9, event);
/*  832 */       gc.dispose();
/*  833 */       GDK.gdk_region_destroy(damageRgn);
/*  834 */       event.gc = null;
/*      */     }
/*  836 */     OS.g_free(rectangles[0]);
/*  837 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_key_press_event(long widget, long event)
/*      */   {
/*  842 */     long result = super.gtk_key_press_event(widget, event);
/*  843 */     if (result != 0L) { return result;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  850 */     if (((this.state & 0x2) != 0) && (this.socketHandle == 0L)) {
/*  851 */       GdkEventKey keyEvent = new GdkEventKey();
/*  852 */       OS.memmove(keyEvent, event, GdkEventKey.sizeof);
/*  853 */       int key = keyEvent.keyval;
/*  854 */       switch (key) {
/*      */       case 65293: case 65421: 
/*  856 */         return 1L;
/*      */       }
/*      */     }
/*  859 */     return result;
/*      */   }
/*      */   
/*      */   long gtk_focus(long widget, long directionType)
/*      */   {
/*  864 */     if (widget == this.socketHandle) return 0L;
/*  865 */     return super.gtk_focus(widget, directionType);
/*      */   }
/*      */   
/*      */   long gtk_focus_in_event(long widget, long event)
/*      */   {
/*  870 */     long result = super.gtk_focus_in_event(widget, event);
/*  871 */     return (this.state & 0x2) != 0 ? 1L : result;
/*      */   }
/*      */   
/*      */   long gtk_focus_out_event(long widget, long event)
/*      */   {
/*  876 */     long result = super.gtk_focus_out_event(widget, event);
/*  877 */     return (this.state & 0x2) != 0 ? 1L : result;
/*      */   }
/*      */   
/*      */   long gtk_map(long widget)
/*      */   {
/*  882 */     fixZOrder();
/*  883 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_realize(long widget)
/*      */   {
/*  888 */     long result = super.gtk_realize(widget);
/*  889 */     if ((this.style & 0x40000) != 0) {
/*  890 */       long window = gtk_widget_get_window(paintHandle());
/*  891 */       if (window != 0L) {
/*  892 */         if (GTK.GTK3) {
/*  893 */           GDK.gdk_window_set_background_pattern(window, 0L);
/*      */         } else {
/*  895 */           GDK.gdk_window_set_back_pixmap(window, 0L, false);
/*      */         }
/*      */       }
/*      */     }
/*  899 */     if (this.socketHandle != 0L) {
/*  900 */       this.embeddedHandle = GTK.gtk_socket_get_id(this.socketHandle);
/*      */     }
/*  902 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */   long gtk_scroll_child(long widget, long scrollType, long horizontal)
/*      */   {
/*  908 */     OS.g_signal_stop_emission_by_name(widget, OS.scroll_child);
/*  909 */     return 1L;
/*      */   }
/*      */   
/*      */   long gtk_style_set(long widget, long previousStyle)
/*      */   {
/*  914 */     long result = super.gtk_style_set(widget, previousStyle);
/*  915 */     if ((this.style & 0x40000) != 0) {
/*  916 */       long window = gtk_widget_get_window(paintHandle());
/*  917 */       if (window != 0L) GDK.gdk_window_set_back_pixmap(window, 0L, false);
/*      */     }
/*  919 */     return result;
/*      */   }
/*      */   
/*      */   boolean hasBorder() {
/*  923 */     return (this.style & 0x800) != 0;
/*      */   }
/*      */   
/*      */   void hookEvents()
/*      */   {
/*  928 */     super.hookEvents();
/*  929 */     if ((this.state & 0x2) != 0) {
/*  930 */       GTK.gtk_widget_add_events(this.handle, 8);
/*  931 */       if (this.scrolledHandle != 0L) {
/*  932 */         OS.g_signal_connect_closure(this.scrolledHandle, OS.scroll_child, this.display.getClosure(42), false);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   boolean hooksKeys() {
/*  938 */     return (hooks(1)) || (hooks(2));
/*      */   }
/*      */   
/*      */   long imHandle()
/*      */   {
/*  943 */     return this.imHandle;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isLayoutDeferred()
/*      */   {
/*  965 */     checkWidget();
/*  966 */     return findDeferredControl() != null;
/*      */   }
/*      */   
/*      */   boolean isTabGroup()
/*      */   {
/*  971 */     if ((this.state & 0x2) != 0) return true;
/*  972 */     return super.isTabGroup();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void layout()
/*      */   {
/* 1003 */     checkWidget();
/* 1004 */     layout(true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void layout(boolean changed)
/*      */   {
/* 1046 */     checkWidget();
/* 1047 */     if (this.layout == null) return;
/* 1048 */     layout(changed, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void layout(boolean changed, boolean all)
/*      */   {
/* 1094 */     checkWidget();
/* 1095 */     if ((this.layout == null) && (!all)) return;
/* 1096 */     markLayout(changed, all);
/* 1097 */     updateLayout(all);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void layout(Control[] changed)
/*      */   {
/* 1136 */     checkWidget();
/* 1137 */     if (changed == null) error(5);
/* 1138 */     layout(changed, 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void layout(Control[] changed, int flags)
/*      */   {
/* 1200 */     checkWidget();
/* 1201 */     if (changed != null) {
/* 1202 */       for (int i = 0; i < changed.length; i++) {
/* 1203 */         Control control = changed[i];
/* 1204 */         if (control == null) error(5);
/* 1205 */         if (control.isDisposed()) error(5);
/* 1206 */         boolean ancestor = false;
/* 1207 */         Composite composite = control.parent;
/* 1208 */         while (composite != null) {
/* 1209 */           ancestor = composite == this;
/* 1210 */           if (ancestor) break;
/* 1211 */           composite = composite.parent;
/*      */         }
/* 1213 */         if (!ancestor) error(32);
/*      */       }
/* 1215 */       int updateCount = 0;
/* 1216 */       Composite[] update = new Composite[16];
/* 1217 */       for (int i = 0; i < changed.length; i++) {
/* 1218 */         Control child = changed[i];
/* 1219 */         Composite composite = child.parent;
/*      */         
/*      */ 
/* 1222 */         child.markLayout(false, false);
/* 1223 */         while (child != this) {
/* 1224 */           if (composite.layout != null) {
/* 1225 */             composite.state |= 0x20000;
/* 1226 */             if (!composite.layout.flushCache(child)) {
/* 1227 */               composite.state |= 0x40000;
/*      */             }
/*      */           }
/* 1230 */           if (updateCount == update.length) {
/* 1231 */             Composite[] newUpdate = new Composite[update.length + 16];
/* 1232 */             System.arraycopy(update, 0, newUpdate, 0, update.length);
/* 1233 */             update = newUpdate;
/*      */           }
/* 1235 */           child = update[(updateCount++)] = composite;
/* 1236 */           composite = child.parent;
/*      */         }
/*      */       }
/* 1239 */       if ((flags & 0x4) != 0) {
/* 1240 */         setLayoutDeferred(true);
/* 1241 */         this.display.addLayoutDeferred(this);
/*      */       }
/* 1243 */       for (int i = updateCount - 1; i >= 0; i--) {
/* 1244 */         update[i].updateLayout(false);
/*      */       }
/*      */     } else {
/* 1247 */       if ((this.layout == null) && ((flags & 0x1) == 0)) return;
/* 1248 */       markLayout((flags & 0x2) != 0, (flags & 0x1) != 0);
/* 1249 */       if ((flags & 0x4) != 0) {
/* 1250 */         setLayoutDeferred(true);
/* 1251 */         this.display.addLayoutDeferred(this);
/*      */       }
/* 1253 */       updateLayout((flags & 0x1) != 0);
/*      */     }
/*      */   }
/*      */   
/*      */   void markLayout(boolean changed, boolean all)
/*      */   {
/* 1259 */     if (this.layout != null) {
/* 1260 */       this.state |= 0x20000;
/* 1261 */       if (changed) this.state |= 0x40000;
/*      */     }
/* 1263 */     if (all) {
/* 1264 */       Control[] children = _getChildren();
/* 1265 */       for (int i = 0; i < children.length; i++) {
/* 1266 */         children[i].markLayout(changed, all);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   void moveAbove(long child, long sibling) {
/* 1272 */     if (child == sibling) return;
/* 1273 */     long parentHandle = parentingHandle();
/* 1274 */     if (GTK.GTK3) {
/* 1275 */       OS.swt_fixed_restack(parentHandle, child, sibling, true);
/* 1276 */       return;
/*      */     }
/* 1278 */     GtkFixed fixed = new GtkFixed();
/* 1279 */     OS.memmove(fixed, parentHandle);
/* 1280 */     long children = fixed.children;
/* 1281 */     if (children == 0L) return;
/* 1282 */     long[] data = new long[1];
/* 1283 */     long[] widget = new long[1];
/* 1284 */     long childData = 0L;long childLink = 0L;long siblingLink = 0L;long temp = children;
/* 1285 */     while (temp != 0L) {
/* 1286 */       C.memmove(data, temp, C.PTR_SIZEOF);
/* 1287 */       C.memmove(widget, data[0], C.PTR_SIZEOF);
/* 1288 */       if (child == widget[0]) {
/* 1289 */         childLink = temp;
/* 1290 */         childData = data[0];
/* 1291 */       } else if (sibling == widget[0]) {
/* 1292 */         siblingLink = temp;
/*      */       }
/* 1294 */       if ((childData != 0L) && ((sibling == 0L) || (siblingLink != 0L))) break;
/* 1295 */       temp = OS.g_list_next(temp);
/*      */     }
/* 1297 */     children = OS.g_list_remove_link(children, childLink);
/* 1298 */     if ((siblingLink == 0L) || (OS.g_list_previous(siblingLink) == 0L)) {
/* 1299 */       OS.g_list_free_1(childLink);
/* 1300 */       children = OS.g_list_prepend(children, childData);
/*      */     } else {
/* 1302 */       temp = OS.g_list_previous(siblingLink);
/* 1303 */       OS.g_list_set_previous(childLink, temp);
/* 1304 */       OS.g_list_set_next(temp, childLink);
/* 1305 */       OS.g_list_set_next(childLink, siblingLink);
/* 1306 */       OS.g_list_set_previous(siblingLink, childLink);
/*      */     }
/* 1308 */     fixed.children = children;
/* 1309 */     OS.memmove(parentHandle, fixed);
/*      */   }
/*      */   
/*      */   void moveBelow(long child, long sibling) {
/* 1313 */     if (child == sibling) return;
/* 1314 */     long parentHandle = parentingHandle();
/* 1315 */     if ((sibling == 0L) && (parentHandle == this.fixedHandle)) {
/* 1316 */       moveAbove(child, this.scrolledHandle != 0L ? this.scrolledHandle : this.handle);
/* 1317 */       return;
/*      */     }
/* 1319 */     if (GTK.GTK3) {
/* 1320 */       OS.swt_fixed_restack(parentHandle, child, sibling, false);
/* 1321 */       return;
/*      */     }
/* 1323 */     GtkFixed fixed = new GtkFixed();
/* 1324 */     OS.memmove(fixed, parentHandle);
/* 1325 */     long children = fixed.children;
/* 1326 */     if (children == 0L) return;
/* 1327 */     long[] data = new long[1];
/* 1328 */     long[] widget = new long[1];
/* 1329 */     long childData = 0L;long childLink = 0L;long siblingLink = 0L;long temp = children;
/* 1330 */     while (temp != 0L) {
/* 1331 */       C.memmove(data, temp, C.PTR_SIZEOF);
/* 1332 */       C.memmove(widget, data[0], C.PTR_SIZEOF);
/* 1333 */       if (child == widget[0]) {
/* 1334 */         childLink = temp;
/* 1335 */         childData = data[0];
/* 1336 */       } else if (sibling == widget[0]) {
/* 1337 */         siblingLink = temp;
/*      */       }
/* 1339 */       if ((childData != 0L) && ((sibling == 0L) || (siblingLink != 0L))) break;
/* 1340 */       temp = OS.g_list_next(temp);
/*      */     }
/* 1342 */     children = OS.g_list_remove_link(children, childLink);
/* 1343 */     if ((siblingLink == 0L) || (OS.g_list_next(siblingLink) == 0L)) {
/* 1344 */       OS.g_list_free_1(childLink);
/* 1345 */       children = OS.g_list_append(children, childData);
/*      */     } else {
/* 1347 */       temp = OS.g_list_next(siblingLink);
/* 1348 */       OS.g_list_set_next(childLink, temp);
/* 1349 */       OS.g_list_set_previous(temp, childLink);
/* 1350 */       OS.g_list_set_previous(childLink, siblingLink);
/* 1351 */       OS.g_list_set_next(siblingLink, childLink);
/*      */     }
/* 1353 */     fixed.children = children;
/* 1354 */     OS.memmove(parentHandle, fixed);
/*      */   }
/*      */   
/*      */   void moveChildren(int oldWidth)
/*      */   {
/* 1359 */     Control[] children = _getChildren();
/* 1360 */     for (int i = 0; i < children.length; i++) {
/* 1361 */       Control child = children[i];
/* 1362 */       long topHandle = child.topHandle();
/* 1363 */       GtkAllocation allocation = new GtkAllocation();
/* 1364 */       GTK.gtk_widget_get_allocation(topHandle, allocation);
/* 1365 */       int x = allocation.x;
/* 1366 */       int y = allocation.y;
/* 1367 */       int controlWidth = (child.state & 0x200) != 0 ? 0 : allocation.width;
/* 1368 */       if (oldWidth > 0) x = oldWidth - controlWidth - x;
/* 1369 */       int clientWidth = getClientWidth();
/* 1370 */       x = clientWidth - controlWidth - x;
/* 1371 */       if (child.enableWindow != 0L) {
/* 1372 */         GDK.gdk_window_move(child.enableWindow, x, y);
/*      */       }
/* 1374 */       child.moveHandle(x, y);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1380 */       GtkRequisition requisition = new GtkRequisition();
/* 1381 */       gtk_widget_size_request(topHandle, requisition);
/* 1382 */       allocation.x = x;
/* 1383 */       allocation.y = y;
/* 1384 */       GTK.gtk_widget_size_allocate(topHandle, allocation);
/* 1385 */       Control control = child.findBackgroundControl();
/* 1386 */       if ((control != null) && (control.backgroundImage != null) && 
/* 1387 */         (child.isVisible())) child.redrawWidget(0, 0, 0, 0, true, true, true);
/*      */     }
/*      */   }
/*      */   
/*      */   Point minimumSize(int wHint, int hHint, boolean changed)
/*      */   {
/* 1393 */     Control[] children = _getChildren();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1398 */     Rectangle clientArea = DPIUtil.autoScaleUp(getClientArea());
/* 1399 */     int width = 0;int height = 0;
/* 1400 */     for (int i = 0; i < children.length; i++) {
/* 1401 */       Rectangle rect = DPIUtil.autoScaleUp(children[i].getBounds());
/* 1402 */       width = Math.max(width, rect.x - clientArea.x + rect.width);
/* 1403 */       height = Math.max(height, rect.y - clientArea.y + rect.height);
/*      */     }
/* 1405 */     return new Point(width, height);
/*      */   }
/*      */   
/*      */   long parentingHandle() {
/* 1409 */     if ((this.state & 0x2) != 0) return this.handle;
/* 1410 */     return this.fixedHandle != 0L ? this.fixedHandle : this.handle;
/*      */   }
/*      */   
/*      */   void printWidget(GC gc, long drawable, int depth, int x, int y)
/*      */   {
/* 1415 */     Region oldClip = new Region(gc.getDevice());
/* 1416 */     Region newClip = new Region(gc.getDevice());
/* 1417 */     Point loc = DPIUtil.autoScaleDown(new Point(x, y));
/* 1418 */     gc.getClipping(oldClip);
/* 1419 */     Rectangle rect = getBounds();
/* 1420 */     newClip.add(oldClip);
/* 1421 */     newClip.intersect(loc.x, loc.y, rect.width, rect.height);
/* 1422 */     gc.setClipping(newClip);
/* 1423 */     super.printWidget(gc, drawable, depth, x, y);
/* 1424 */     Rectangle clientRect = getClientAreaInPixels();
/* 1425 */     Point pt = this.display.mapInPixels(this, this.parent, clientRect.x, clientRect.y);
/* 1426 */     clientRect.x = (x + pt.x - rect.x);
/* 1427 */     clientRect.y = (y + pt.y - rect.y);
/* 1428 */     newClip.intersect(DPIUtil.autoScaleDown(clientRect));
/* 1429 */     gc.setClipping(newClip);
/* 1430 */     Control[] children = _getChildren();
/* 1431 */     for (int i = children.length - 1; i >= 0; i--) {
/* 1432 */       Control child = children[i];
/* 1433 */       if (child.getVisible()) {
/* 1434 */         Point location = child.getLocationInPixels();
/* 1435 */         child.printWidget(gc, drawable, depth, x + location.x, y + location.y);
/*      */       }
/*      */     }
/* 1438 */     gc.setClipping(oldClip);
/* 1439 */     oldClip.dispose();
/* 1440 */     newClip.dispose();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   void connectFixedHandleDraw()
/*      */   {
/* 1448 */     long paintHandle = this.fixedHandle;
/* 1449 */     int paintMask = 2;
/* 1450 */     GTK.gtk_widget_add_events(paintHandle, paintMask);
/*      */     
/* 1452 */     OS.g_signal_connect_closure_by_id(paintHandle, this.display.signalIds[18], 0, this.display.getClosure(18), true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void propagateDraw(long container, long cairo)
/*      */   {
/* 1470 */     if ((container == this.fixedHandle) && (GTK.GTK3)) {
/* 1471 */       long list = GTK.gtk_container_get_children(container);
/* 1472 */       long temp = list;
/* 1473 */       while (temp != 0L) {
/* 1474 */         long child = OS.g_list_data(temp);
/* 1475 */         if (child != 0L) {
/* 1476 */           Widget widget = this.display.getWidget(child);
/* 1477 */           if (widget != this) {
/* 1478 */             GTK.gtk_container_propagate_draw(container, child, cairo);
/*      */           }
/*      */         }
/* 1481 */         temp = OS.g_list_next(temp);
/*      */       }
/* 1483 */       OS.g_list_free(list);
/*      */     }
/*      */   }
/*      */   
/*      */   void redrawChildren()
/*      */   {
/* 1489 */     super.redrawChildren();
/* 1490 */     Control[] children = _getChildren();
/* 1491 */     for (int i = 0; i < children.length; i++) {
/* 1492 */       Control child = children[i];
/* 1493 */       if ((child.state & 0x8000) != 0) {
/* 1494 */         child.redrawWidget(0, 0, 0, 0, true, false, true);
/* 1495 */         child.redrawChildren();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   void register()
/*      */   {
/* 1502 */     super.register();
/* 1503 */     if (this.socketHandle != 0L) this.display.addWidget(this.socketHandle, this);
/*      */   }
/*      */   
/*      */   void releaseChildren(boolean destroy)
/*      */   {
/* 1508 */     Control[] children = _getChildren();
/* 1509 */     for (int i = 0; i < children.length; i++) {
/* 1510 */       Control child = children[i];
/* 1511 */       if ((child != null) && (!child.isDisposed())) {
/* 1512 */         child.release(false);
/*      */       }
/*      */     }
/* 1515 */     super.releaseChildren(destroy);
/*      */   }
/*      */   
/*      */   void releaseHandle()
/*      */   {
/* 1520 */     super.releaseHandle();
/* 1521 */     this.socketHandle = (this.embeddedHandle = 0L);
/*      */   }
/*      */   
/*      */   void releaseWidget()
/*      */   {
/* 1526 */     super.releaseWidget();
/* 1527 */     if (this.imHandle != 0L) OS.g_object_unref(this.imHandle);
/* 1528 */     this.imHandle = 0L;
/* 1529 */     this.layout = null;
/* 1530 */     this.tabList = null;
/*      */   }
/*      */   
/*      */   void removeControl(Control control) {
/* 1534 */     fixTabList(control);
/*      */   }
/*      */   
/*      */   void reskinChildren(int flags)
/*      */   {
/* 1539 */     super.reskinChildren(flags);
/* 1540 */     Control[] children = _getChildren();
/* 1541 */     for (int i = 0; i < children.length; i++) {
/* 1542 */       Control child = children[i];
/* 1543 */       if (child != null) child.reskin(flags);
/*      */     }
/*      */   }
/*      */   
/*      */   void resizeHandle(int width, int height)
/*      */   {
/* 1549 */     super.resizeHandle(width, height);
/* 1550 */     if (this.socketHandle != 0L) {
/* 1551 */       if (GTK.GTK3) {
/* 1552 */         OS.swt_fixed_resize(this.handle, this.socketHandle, width, height);
/*      */       } else {
/* 1554 */         GTK.gtk_widget_set_size_request(this.socketHandle, width, height);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBackgroundMode(int mode)
/*      */   {
/* 1577 */     checkWidget();
/* 1578 */     this.backgroundMode = mode;
/* 1579 */     Control[] children = _getChildren();
/* 1580 */     for (int i = 0; i < children.length; i++) {
/* 1581 */       children[i].updateBackgroundMode();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   int setBounds(int x, int y, int width, int height, boolean move, boolean resize)
/*      */   {
/* 1604 */     long topHandle = topHandle();
/* 1605 */     if ((GTK.GTK_VERSION >= OS.VERSION(3, 8, 0)) && (this.fixedHandle != 0L) && (this.handle != 0L))
/*      */     {
/* 1607 */       if ((getVisible()) && (!GTK.gtk_widget_get_visible(topHandle)) && (topHandle == this.fixedHandle) && (width > 0) && (height > 0) && (resize))
/*      */       {
/* 1609 */         GTK.gtk_widget_show(topHandle);
/*      */       }
/*      */     }
/* 1612 */     int result = super.setBounds(x, y, width, height, move, resize);
/* 1613 */     if (((result & 0x100) != 0) && (this.layout != null)) {
/* 1614 */       markLayout(false, false);
/* 1615 */       updateLayout(false);
/*      */     }
/* 1617 */     return result;
/*      */   }
/*      */   
/*      */   public boolean setFocus()
/*      */   {
/* 1622 */     checkWidget();
/* 1623 */     Control[] children = _getChildren();
/* 1624 */     for (int i = 0; i < children.length; i++) {
/* 1625 */       Control child = children[i];
/* 1626 */       if ((child.getVisible()) && (child.setFocus())) return true;
/*      */     }
/* 1628 */     return super.setFocus();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setLayout(Layout layout)
/*      */   {
/* 1643 */     checkWidget();
/* 1644 */     this.layout = layout;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setLayoutDeferred(boolean defer)
/*      */   {
/* 1670 */     checkWidget();
/* 1671 */     if (!defer) {
/* 1672 */       if ((--this.layoutCount == 0) && (
/* 1673 */         ((this.state & 0x80000) != 0) || ((this.state & 0x20000) != 0))) {
/* 1674 */         updateLayout(true);
/*      */       }
/*      */     }
/*      */     else {
/* 1678 */       this.layoutCount += 1;
/*      */     }
/*      */   }
/*      */   
/*      */   void setOrientation(boolean create)
/*      */   {
/* 1684 */     super.setOrientation(create);
/* 1685 */     if (!create) {
/* 1686 */       int flags = 100663296;
/* 1687 */       int orientation = this.style & flags;
/* 1688 */       Control[] children = _getChildren();
/* 1689 */       for (int i = 0; i < children.length; i++) {
/* 1690 */         children[i].setOrientation(orientation);
/*      */       }
/* 1692 */       if (((this.style & 0x4000000) != 0 ? 1 : 0) != ((this.style & 0x8000000) != 0 ? 1 : 0)) {
/* 1693 */         moveChildren(-1);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   boolean setScrollBarVisible(ScrollBar bar, boolean visible)
/*      */   {
/* 1700 */     boolean changed = super.setScrollBarVisible(bar, visible);
/* 1701 */     if ((changed) && (this.layout != null)) {
/* 1702 */       markLayout(false, false);
/* 1703 */       updateLayout(false);
/*      */     }
/* 1705 */     return changed;
/*      */   }
/*      */   
/*      */   boolean setTabGroupFocus(boolean next)
/*      */   {
/* 1710 */     if (isTabItem()) return setTabItemFocus(next);
/* 1711 */     boolean takeFocus = (this.style & 0x80000) == 0;
/* 1712 */     if ((this.state & 0x2) != 0) takeFocus = hooksKeys();
/* 1713 */     if (this.socketHandle != 0L) takeFocus = true;
/* 1714 */     if ((takeFocus) && (setTabItemFocus(next))) return true;
/* 1715 */     Control[] children = _getChildren();
/* 1716 */     for (int i = 0; i < children.length; i++) {
/* 1717 */       Control child = children[i];
/* 1718 */       if ((child.isTabItem()) && (child.setTabItemFocus(next))) return true;
/*      */     }
/* 1720 */     return false;
/*      */   }
/*      */   
/*      */   boolean setTabItemFocus(boolean next)
/*      */   {
/* 1725 */     if (!super.setTabItemFocus(next)) return false;
/* 1726 */     if (this.socketHandle != 0L) {
/* 1727 */       int direction = next ? 0 : 1;
/* 1728 */       GTK.GTK_WIDGET_UNSET_FLAGS(this.socketHandle, 4096);
/* 1729 */       GTK.gtk_widget_child_focus(this.socketHandle, direction);
/* 1730 */       GTK.GTK_WIDGET_SET_FLAGS(this.socketHandle, 4096);
/*      */     }
/* 1732 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTabList(Control[] tabList)
/*      */   {
/* 1751 */     checkWidget();
/* 1752 */     if (tabList != null) {
/* 1753 */       for (int i = 0; i < tabList.length; i++) {
/* 1754 */         Control control = tabList[i];
/* 1755 */         if (control == null) error(5);
/* 1756 */         if (control.isDisposed()) error(5);
/* 1757 */         if (control.parent != this) error(32);
/*      */       }
/* 1759 */       Control[] newList = new Control[tabList.length];
/* 1760 */       System.arraycopy(tabList, 0, newList, 0, tabList.length);
/* 1761 */       tabList = newList;
/*      */     }
/* 1763 */     this.tabList = tabList;
/*      */   }
/*      */   
/*      */   void showWidget()
/*      */   {
/* 1768 */     super.showWidget();
/* 1769 */     if (this.socketHandle != 0L) {
/* 1770 */       GTK.gtk_widget_show(this.socketHandle);
/* 1771 */       this.embeddedHandle = GTK.gtk_socket_get_id(this.socketHandle);
/*      */     }
/* 1773 */     if (this.scrolledHandle == 0L) fixStyle(this.handle);
/*      */   }
/*      */   
/*      */   boolean checkSubwindow()
/*      */   {
/* 1778 */     return (this.state & 0x2000000) != 0;
/*      */   }
/*      */   
/*      */   boolean translateMnemonic(Event event, Control control)
/*      */   {
/* 1783 */     if (super.translateMnemonic(event, control)) return true;
/* 1784 */     if (control != null) {
/* 1785 */       Control[] children = _getChildren();
/* 1786 */       for (int i = 0; i < children.length; i++) {
/* 1787 */         Control child = children[i];
/* 1788 */         if (child.translateMnemonic(event, control)) return true;
/*      */       }
/*      */     }
/* 1791 */     return false;
/*      */   }
/*      */   
/*      */   int traversalCode(int key, GdkEventKey event)
/*      */   {
/* 1796 */     if ((this.state & 0x2) != 0) {
/* 1797 */       if ((this.style & 0x80000) != 0) return 0;
/* 1798 */       if (hooksKeys()) return 0;
/*      */     }
/* 1800 */     return super.traversalCode(key, event);
/*      */   }
/*      */   
/*      */   boolean translateTraversal(GdkEventKey keyEvent)
/*      */   {
/* 1805 */     if (this.socketHandle != 0L) return false;
/* 1806 */     return super.translateTraversal(keyEvent);
/*      */   }
/*      */   
/*      */   void updateBackgroundMode()
/*      */   {
/* 1811 */     super.updateBackgroundMode();
/* 1812 */     Control[] children = _getChildren();
/* 1813 */     for (int i = 0; i < children.length; i++) {
/* 1814 */       children[i].updateBackgroundMode();
/*      */     }
/*      */   }
/*      */   
/*      */   void updateLayout(boolean all)
/*      */   {
/* 1820 */     Composite parent = findDeferredControl();
/* 1821 */     if (parent != null) {
/* 1822 */       parent.state |= 0x80000;
/* 1823 */       return;
/*      */     }
/* 1825 */     if ((this.state & 0x20000) != 0) {
/* 1826 */       boolean changed = (this.state & 0x40000) != 0;
/* 1827 */       this.state &= 0xFFF9FFFF;
/* 1828 */       this.display.runSkin();
/* 1829 */       this.layout.layout(this, changed);
/*      */     }
/* 1831 */     if (all) {
/* 1832 */       this.state &= 0xFFF7FFFF;
/* 1833 */       Control[] children = _getChildren();
/* 1834 */       for (int i = 0; i < children.length; i++) {
/* 1835 */         children[i].updateLayout(all);
/*      */       }
/*      */     }
/*      */   }
/*      */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/widgets/Composite.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */