package org.eclipse.swt.internal.accessibility.gtk;

public class AtkObjectFactoryClass
{
  public long create_accessible;
  public long invalidate;
  public long get_accessible_type;
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/internal/accessibility/gtk/AtkObjectFactoryClass.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */