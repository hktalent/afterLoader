/*    */ package org.eclipse.swt.custom;
/*    */ 
/*    */ import org.eclipse.swt.events.TypedEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TextChangedEvent
/*    */   extends TypedEvent
/*    */ {
/*    */   static final long serialVersionUID = 3258696524257835065L;
/*    */   
/*    */   public TextChangedEvent(StyledTextContent source)
/*    */   {
/* 33 */     super(source);
/*    */   }
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/custom/TextChangedEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */