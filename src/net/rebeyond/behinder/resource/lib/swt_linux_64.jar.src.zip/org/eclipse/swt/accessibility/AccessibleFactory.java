/*     */ package org.eclipse.swt.accessibility;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.eclipse.swt.internal.C;
/*     */ import org.eclipse.swt.internal.Callback;
/*     */ import org.eclipse.swt.internal.Converter;
/*     */ import org.eclipse.swt.internal.LONG;
/*     */ import org.eclipse.swt.internal.accessibility.gtk.ATK;
/*     */ import org.eclipse.swt.internal.accessibility.gtk.AtkSelectionIface;
/*     */ import org.eclipse.swt.internal.accessibility.gtk.AtkTextIface;
/*     */ import org.eclipse.swt.internal.accessibility.gtk.AtkValueIface;
/*     */ import org.eclipse.swt.internal.gtk.GInterfaceInfo;
/*     */ import org.eclipse.swt.internal.gtk.GTK;
/*     */ import org.eclipse.swt.internal.gtk.GTypeInfo;
/*     */ import org.eclipse.swt.internal.gtk.GTypeQuery;
/*     */ import org.eclipse.swt.internal.gtk.OS;
/*     */ 
/*     */ class AccessibleFactory
/*     */ {
/*  22 */   static final Map<LONG, Accessible> Accessibles = new HashMap(9);
/*  23 */   static final Map<LONG, LONG> Factories = new HashMap(9);
/*     */   static final String SWT_TYPE_PREFIX = "SWTAccessible";
/*     */   static final String CHILD_TYPENAME = "Child";
/*     */   static final String FACTORY_TYPENAME = "SWTFactory";
/*  27 */   static final int[] actionRoles = { 44, 46, 30, 12, 43, 45, 62, 52, 1027, 1073 };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  33 */   static final int[] editableTextRoles = { 42, 46, 1054, 15 };
/*     */   
/*     */ 
/*  36 */   static final int[] hypertextRoles = { 42, 30, 1054 };
/*     */   
/*     */ 
/*  39 */   static final int[] selectionRoles = { 33, 60, 24, 35 };
/*     */   
/*     */ 
/*  42 */   static final int[] textRoles = { 46, 30, 41, 42, 23, 1054, 15 };
/*     */   
/*     */ 
/*     */ 
/*  46 */   static final int[] tableRoles = { 24, 35 };
/*     */   
/*     */ 
/*  49 */   static final int[] valueRoles = { 3, 52, 48 };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 170 */   static final Callback AtkActionCB_do_action = newCallback(AccessibleObject.class, "atkAction_do_action", 2);
/* 171 */   static final Callback AtkActionCB_get_n_actions = newCallback(AccessibleObject.class, "atkAction_get_n_actions", 1);
/* 172 */   static final Callback AtkActionCB_get_description = newCallback(AccessibleObject.class, "atkAction_get_description", 2);
/* 173 */   static final Callback AtkActionCB_get_keybinding = newCallback(AccessibleObject.class, "atkAction_get_keybinding", 2);
/* 174 */   static final Callback AtkActionCB_get_name = newCallback(AccessibleObject.class, "atkAction_get_name", 2);
/* 175 */   static final Callback AtkComponentCB_get_extents = newCallback(AccessibleObject.class, "atkComponent_get_extents", 6);
/* 176 */   static final Callback AtkComponentCB_get_position = newCallback(AccessibleObject.class, "atkComponent_get_position", 4);
/* 177 */   static final Callback AtkComponentCB_get_size = newCallback(AccessibleObject.class, "atkComponent_get_size", 4);
/* 178 */   static final Callback AtkComponentCB_ref_accessible_at_point = newCallback(AccessibleObject.class, "atkComponent_ref_accessible_at_point", 4);
/* 179 */   static final Callback AtkEditableTextCB_set_run_attributes = newCallback(AccessibleObject.class, "atkEditableText_set_run_attributes", 4);
/* 180 */   static final Callback AtkEditableTextCB_set_text_contents = newCallback(AccessibleObject.class, "atkEditableText_set_text_contents", 2);
/* 181 */   static final Callback AtkEditableTextCB_insert_text = newCallback(AccessibleObject.class, "atkEditableText_insert_text", 4);
/* 182 */   static final Callback AtkEditableTextCB_copy_text = newCallback(AccessibleObject.class, "atkEditableText_copy_text", 3);
/* 183 */   static final Callback AtkEditableTextCB_cut_text = newCallback(AccessibleObject.class, "atkEditableText_cut_text", 3);
/* 184 */   static final Callback AtkEditableTextCB_delete_text = newCallback(AccessibleObject.class, "atkEditableText_delete_text", 3);
/* 185 */   static final Callback AtkEditableTextCB_paste_text = newCallback(AccessibleObject.class, "atkEditableText_paste_text", 2);
/* 186 */   static final Callback AtkHypertextCB_get_link = newCallback(AccessibleObject.class, "atkHypertext_get_link", 2);
/* 187 */   static final Callback AtkHypertextCB_get_n_links = newCallback(AccessibleObject.class, "atkHypertext_get_n_links", 1);
/* 188 */   static final Callback AtkHypertextCB_get_link_index = newCallback(AccessibleObject.class, "atkHypertext_get_link_index", 2);
/* 189 */   static final Callback AtkObjectCB_get_description; static final Callback AtkObjectCB_get_index_in_parent; static final Callback AtkObjectCB_get_n_children; static final Callback AtkObjectCB_get_name = newCallback(AccessibleObject.class, "atkObject_get_name", 1); static final Callback AtkObjectCB_get_parent; static final Callback AtkObjectCB_get_role; static final Callback AtkObjectCB_ref_child; static final Callback AtkObjectCB_ref_state_set; static final Callback AtkObjectCB_get_attributes; static final Callback AtkSelectionCB_is_child_selected; static final Callback AtkSelectionCB_ref_selection; static final Callback AtkTableCB_ref_at; static final Callback AtkTableCB_get_index_at; static final Callback AtkTableCB_get_column_at_index; static final Callback AtkTableCB_get_row_at_index; static final Callback AtkTableCB_get_n_columns; static final Callback AtkTableCB_get_n_rows; static final Callback AtkTableCB_get_column_extent_at; static final Callback AtkTableCB_get_row_extent_at;
/* 190 */   static { AtkObjectCB_get_description = newCallback(AccessibleObject.class, "atkObject_get_description", 1);
/* 191 */     AtkObjectCB_get_n_children = newCallback(AccessibleObject.class, "atkObject_get_n_children", 1);
/* 192 */     AtkObjectCB_get_role = newCallback(AccessibleObject.class, "atkObject_get_role", 1);
/* 193 */     AtkObjectCB_get_parent = newCallback(AccessibleObject.class, "atkObject_get_parent", 1);
/* 194 */     AtkObjectCB_ref_state_set = newCallback(AccessibleObject.class, "atkObject_ref_state_set", 1);
/* 195 */     AtkObjectCB_get_index_in_parent = newCallback(AccessibleObject.class, "atkObject_get_index_in_parent", 1);
/* 196 */     AtkObjectCB_ref_child = newCallback(AccessibleObject.class, "atkObject_ref_child", 2);
/* 197 */     AtkObjectCB_get_attributes = newCallback(AccessibleObject.class, "atkObject_get_attributes", 1);
/* 198 */     AtkSelectionCB_is_child_selected = newCallback(AccessibleObject.class, "atkSelection_is_child_selected", 2);
/* 199 */     AtkSelectionCB_ref_selection = newCallback(AccessibleObject.class, "atkSelection_ref_selection", 2);
/* 200 */     AtkTableCB_ref_at = newCallback(AccessibleObject.class, "atkTable_ref_at", 3);
/* 201 */     AtkTableCB_get_index_at = newCallback(AccessibleObject.class, "atkTable_get_index_at", 3);
/* 202 */     AtkTableCB_get_column_at_index = newCallback(AccessibleObject.class, "atkTable_get_column_at_index", 2);
/* 203 */     AtkTableCB_get_row_at_index = newCallback(AccessibleObject.class, "atkTable_get_row_at_index", 2);
/* 204 */     AtkTableCB_get_n_columns = newCallback(AccessibleObject.class, "atkTable_get_n_columns", 1);
/* 205 */     AtkTableCB_get_n_rows = newCallback(AccessibleObject.class, "atkTable_get_n_rows", 1);
/* 206 */     AtkTableCB_get_column_extent_at = newCallback(AccessibleObject.class, "atkTable_get_column_extent_at", 3);
/* 207 */     AtkTableCB_get_row_extent_at = newCallback(AccessibleObject.class, "atkTable_get_row_extent_at", 3);
/* 208 */     AtkTableCB_get_caption = newCallback(AccessibleObject.class, "atkTable_get_caption", 1);
/* 209 */     AtkTableCB_get_summary = newCallback(AccessibleObject.class, "atkTable_get_summary", 1);
/* 210 */     AtkTableCB_get_column_description = newCallback(AccessibleObject.class, "atkTable_get_column_description", 2);
/* 211 */     AtkTableCB_get_row_description = newCallback(AccessibleObject.class, "atkTable_get_row_description", 2);
/* 212 */     AtkTableCB_get_column_header = newCallback(AccessibleObject.class, "atkTable_get_column_header", 2);
/* 213 */     AtkTableCB_get_row_header = newCallback(AccessibleObject.class, "atkTable_get_row_header", 2);
/* 214 */     AtkTableCB_get_selected_columns = newCallback(AccessibleObject.class, "atkTable_get_selected_columns", 2);
/* 215 */     AtkTableCB_get_selected_rows = newCallback(AccessibleObject.class, "atkTable_get_selected_rows", 2);
/* 216 */     AtkTableCB_is_column_selected = newCallback(AccessibleObject.class, "atkTable_is_column_selected", 2);
/* 217 */     AtkTableCB_is_row_selected = newCallback(AccessibleObject.class, "atkTable_is_row_selected", 2);
/* 218 */     AtkTableCB_is_selected = newCallback(AccessibleObject.class, "atkTable_is_selected", 3);
/* 219 */     AtkTableCB_add_column_selection = newCallback(AccessibleObject.class, "atkTable_add_column_selection", 2);
/* 220 */     AtkTableCB_add_row_selection = newCallback(AccessibleObject.class, "atkTable_add_row_selection", 2);
/* 221 */     AtkTableCB_remove_column_selection = newCallback(AccessibleObject.class, "atkTable_remove_column_selection", 2);
/* 222 */     AtkTableCB_remove_row_selection = newCallback(AccessibleObject.class, "atkTable_remove_row_selection", 2);
/* 223 */     AtkTextCB_get_character_extents = newCallback(AccessibleObject.class, "atkText_get_character_extents", 7);
/* 224 */     AtkTextCB_get_range_extents = newCallback(AccessibleObject.class, "atkText_get_range_extents", 5);
/* 225 */     AtkTextCB_get_run_attributes = newCallback(AccessibleObject.class, "atkText_get_run_attributes", 4);
/* 226 */     AtkTextCB_get_offset_at_point = newCallback(AccessibleObject.class, "atkText_get_offset_at_point", 4);
/* 227 */     AtkTextCB_add_selection = newCallback(AccessibleObject.class, "atkText_add_selection", 3);
/* 228 */     AtkTextCB_remove_selection = newCallback(AccessibleObject.class, "atkText_remove_selection", 2);
/* 229 */     AtkTextCB_set_selection = newCallback(AccessibleObject.class, "atkText_set_selection", 4);
/* 230 */     AtkTextCB_get_caret_offset = newCallback(AccessibleObject.class, "atkText_get_caret_offset", 1);
/* 231 */     AtkTextCB_set_caret_offset = newCallback(AccessibleObject.class, "atkText_set_caret_offset", 2);
/* 232 */     AtkTextCB_get_n_selections = newCallback(AccessibleObject.class, "atkText_get_n_selections", 1);
/* 233 */     AtkTextCB_get_selection = newCallback(AccessibleObject.class, "atkText_get_selection", 4);
/* 234 */     AtkTextCB_get_text = newCallback(AccessibleObject.class, "atkText_get_text", 3);
/* 235 */     AtkTextCB_get_text_after_offset = newCallback(AccessibleObject.class, "atkText_get_text_after_offset", 5);
/* 236 */     AtkTextCB_get_text_at_offset = newCallback(AccessibleObject.class, "atkText_get_text_at_offset", 5);
/* 237 */     AtkTextCB_get_text_before_offset = newCallback(AccessibleObject.class, "atkText_get_text_before_offset", 5);
/* 238 */     AtkTextCB_get_character_at_offset = newCallback(AccessibleObject.class, "atkText_get_character_at_offset", 2);
/* 239 */     AtkTextCB_get_character_count = newCallback(AccessibleObject.class, "atkText_get_character_count", 1);
/* 240 */     AtkTextCB_get_bounded_ranges = newCallback(AccessibleObject.class, "atkText_get_bounded_ranges", 5);
/* 241 */     AtkValueCB_get_current_value = newCallback(AccessibleObject.class, "atkValue_get_current_value", 2);
/* 242 */     AtkValueCB_get_maximum_value = newCallback(AccessibleObject.class, "atkValue_get_maximum_value", 2);
/* 243 */     AtkValueCB_get_minimum_value = newCallback(AccessibleObject.class, "atkValue_get_minimum_value", 2);
/* 244 */     AtkValueCB_set_current_value = newCallback(AccessibleObject.class, "atkValue_set_current_value", 2);
/* 245 */     GObjectClass_finalize = newCallback(AccessibleObject.class, "gObjectClass_finalize", 1);
/* 246 */     GTypeInfo_base_init_type = newCallback(AccessibleFactory.class, "gTypeInfo_base_init_type", 1);
/* 247 */     GTypeInfo_base_init_factory = newCallback(AccessibleFactory.class, "gTypeInfo_base_init_factory", 1);
/* 248 */     AtkObjectFactoryCB_create_accessible = newCallback(AccessibleFactory.class, "atkObjectFactory_create_accessible", 1);
/*     */     
/* 250 */     InitActionIfaceCB = newCallback(AccessibleFactory.class, "initActionIfaceCB", 1);
/* 251 */     GInterfaceInfo interfaceInfo = new GInterfaceInfo();
/* 252 */     interfaceInfo.interface_init = InitActionIfaceCB.getAddress();
/* 253 */     ActionIfaceDefinition = OS.g_malloc(GInterfaceInfo.sizeof);
/* 254 */     OS.memmove(ActionIfaceDefinition, interfaceInfo, GInterfaceInfo.sizeof);
/*     */     
/* 256 */     InitComponentIfaceCB = newCallback(AccessibleFactory.class, "initComponentIfaceCB", 1);
/* 257 */     interfaceInfo = new GInterfaceInfo();
/* 258 */     interfaceInfo.interface_init = InitComponentIfaceCB.getAddress();
/* 259 */     ComponentIfaceDefinition = OS.g_malloc(GInterfaceInfo.sizeof);
/* 260 */     OS.memmove(ComponentIfaceDefinition, interfaceInfo, GInterfaceInfo.sizeof);
/*     */     
/* 262 */     InitEditableTextIfaceCB = newCallback(AccessibleFactory.class, "initEditableTextIfaceCB", 1);
/* 263 */     interfaceInfo = new GInterfaceInfo();
/* 264 */     interfaceInfo.interface_init = InitEditableTextIfaceCB.getAddress();
/* 265 */     EditableTextIfaceDefinition = OS.g_malloc(GInterfaceInfo.sizeof);
/* 266 */     OS.memmove(EditableTextIfaceDefinition, interfaceInfo, GInterfaceInfo.sizeof);
/*     */     
/* 268 */     InitHypertextIfaceCB = newCallback(AccessibleFactory.class, "initHypertextIfaceCB", 1);
/* 269 */     interfaceInfo = new GInterfaceInfo();
/* 270 */     interfaceInfo.interface_init = InitHypertextIfaceCB.getAddress();
/* 271 */     HypertextIfaceDefinition = OS.g_malloc(GInterfaceInfo.sizeof);
/* 272 */     OS.memmove(HypertextIfaceDefinition, interfaceInfo, GInterfaceInfo.sizeof);
/*     */     
/* 274 */     InitSelectionIfaceCB = newCallback(AccessibleFactory.class, "initSelectionIfaceCB", 1);
/* 275 */     interfaceInfo = new GInterfaceInfo();
/* 276 */     interfaceInfo.interface_init = InitSelectionIfaceCB.getAddress();
/* 277 */     SelectionIfaceDefinition = OS.g_malloc(GInterfaceInfo.sizeof);
/* 278 */     OS.memmove(SelectionIfaceDefinition, interfaceInfo, GInterfaceInfo.sizeof);
/*     */     
/* 280 */     InitTableIfaceCB = newCallback(AccessibleFactory.class, "initTableIfaceCB", 1);
/* 281 */     interfaceInfo = new GInterfaceInfo();
/* 282 */     interfaceInfo.interface_init = InitTableIfaceCB.getAddress();
/* 283 */     TableIfaceDefinition = OS.g_malloc(GInterfaceInfo.sizeof);
/* 284 */     OS.memmove(TableIfaceDefinition, interfaceInfo, GInterfaceInfo.sizeof);
/*     */     
/* 286 */     InitTextIfaceCB = newCallback(AccessibleFactory.class, "initTextIfaceCB", 1);
/* 287 */     interfaceInfo = new GInterfaceInfo();
/* 288 */     interfaceInfo.interface_init = InitTextIfaceCB.getAddress();
/* 289 */     TextIfaceDefinition = OS.g_malloc(GInterfaceInfo.sizeof);
/* 290 */     OS.memmove(TextIfaceDefinition, interfaceInfo, GInterfaceInfo.sizeof);
/*     */     
/* 292 */     InitValueIfaceCB = newCallback(AccessibleFactory.class, "initValueIfaceCB", 1);
/* 293 */     interfaceInfo = new GInterfaceInfo();
/* 294 */     interfaceInfo.interface_init = InitValueIfaceCB.getAddress();
/* 295 */     ValueIfaceDefinition = OS.g_malloc(GInterfaceInfo.sizeof);
/* 296 */     OS.memmove(ValueIfaceDefinition, interfaceInfo, GInterfaceInfo.sizeof); }
/*     */   
/*     */   static final Callback AtkTableCB_get_summary;
/*     */   static final Callback AtkTableCB_get_caption; static final Callback AtkTableCB_get_column_description; static final Callback AtkTableCB_get_row_description; static final Callback AtkTableCB_get_column_header; static final Callback AtkTableCB_get_row_header; static final Callback AtkTableCB_get_selected_columns; static final Callback AtkTableCB_get_selected_rows; static final Callback AtkTableCB_is_column_selected; static final Callback AtkTableCB_is_row_selected; static final Callback AtkTableCB_is_selected; static final Callback AtkTableCB_add_column_selection; static final Callback AtkTableCB_add_row_selection; static final Callback AtkTableCB_remove_column_selection;
/* 300 */   private static Callback newCallback(Object object, String method, int argCount) { Callback callback = new Callback(object, method, argCount);
/* 301 */     if (callback.getAddress() == 0L) org.eclipse.swt.SWT.error(3);
/* 302 */     return callback; }
/*     */   
/*     */   static final Callback AtkTableCB_remove_row_selection;
/*     */   static final Callback AtkTextCB_get_character_extents; static final Callback AtkTextCB_get_range_extents; static final Callback AtkTextCB_get_run_attributes; static final Callback AtkTextCB_get_offset_at_point; static final Callback AtkTextCB_add_selection; static final Callback AtkTextCB_remove_selection; static final Callback AtkTextCB_set_selection; static final Callback AtkTextCB_get_caret_offset; static final Callback AtkTextCB_set_caret_offset; static final Callback AtkTextCB_get_n_selections; static final Callback AtkTextCB_get_selection; static final Callback AtkTextCB_get_text; static final Callback AtkTextCB_get_text_after_offset;
/* 306 */   static String getTypeName(long type) { long typeName = OS.g_type_name(type);
/* 307 */     int widgetTypeNameLength = C.strlen(typeName);
/* 308 */     byte[] buffer = new byte[widgetTypeNameLength];
/* 309 */     C.memmove(buffer, typeName, widgetTypeNameLength);
/* 310 */     return new String(Converter.mbcsToWcs(buffer)); }
/*     */   
/*     */   static final Callback AtkTextCB_get_text_at_offset;
/*     */   static final Callback AtkTextCB_get_text_before_offset; static final Callback AtkTextCB_get_character_at_offset; static final Callback AtkTextCB_get_character_count; static final Callback AtkTextCB_get_bounded_ranges; static final Callback AtkValueCB_get_current_value; static final Callback AtkValueCB_get_maximum_value; static final Callback AtkValueCB_get_minimum_value; static final Callback AtkValueCB_set_current_value; static final Callback GObjectClass_finalize; static final Callback AtkObjectFactoryCB_create_accessible;
/* 314 */   static long getParentType(long widgetType) { LONG type = null;
/* 315 */     while ((widgetType != 0L) && ((type = (LONG)Factories.get(new LONG(widgetType))) == null)) {
/* 316 */       widgetType = OS.g_type_parent(widgetType);
/*     */     }
/* 318 */     if (type == null) return 0L;
/* 319 */     return type.value; }
/*     */   
/*     */   static final Callback InitActionIfaceCB;
/*     */   static final Callback InitComponentIfaceCB; static final Callback InitEditableTextIfaceCB; static final Callback InitHypertextIfaceCB; static final Callback GTypeInfo_base_init_type;
/* 323 */   static long atkObjectFactory_create_accessible(long widget) { Accessible accessible = (Accessible)Accessibles.get(new LONG(widget));
/* 324 */     if (accessible == null)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 329 */       long result = OS.g_object_new(getParentType(OS.G_OBJECT_TYPE(widget)), 0L);
/* 330 */       ATK.atk_object_initialize(result, widget);
/* 331 */       return result;
/*     */     }
/*     */     
/* 334 */     if (accessible.accessibleObject != null) {
/* 335 */       return accessible.accessibleObject.atkHandle;
/*     */     }
/* 337 */     long widgetType = OS.G_OBJECT_TYPE(widget);
/* 338 */     long parentType = getParentType(widgetType);
/* 339 */     if (parentType == 0L) parentType = GTK.GTK_TYPE_ACCESSIBLE();
/* 340 */     long type = getType(getTypeName(widgetType), accessible, parentType, -1);
/* 341 */     AccessibleObject object = new AccessibleObject(type, widget, accessible, false);
/* 342 */     accessible.accessibleObject = object;
/* 343 */     accessible.addRelations();
/* 344 */     return object.atkHandle; }
/*     */   
/*     */   static final Callback InitSelectionIfaceCB;
/*     */   static final Callback InitTableIfaceCB; static final Callback InitTextIfaceCB; static final Callback InitValueIfaceCB;
/* 348 */   static AccessibleObject createChildAccessible(Accessible accessible, int childId) { long childType = getType("Child", accessible, GTK.GTK_TYPE_ACCESSIBLE(), childId);
/* 349 */     return new AccessibleObject(childType, 0L, accessible, true); }
/*     */   
/*     */   static final Callback GTypeInfo_base_init_factory;
/*     */   static final long ActionIfaceDefinition; static final long ComponentIfaceDefinition; static final long EditableTextIfaceDefinition;
/* 353 */   static void createAccessible(Accessible accessible) { long controlHandle = accessible.getControlHandle();
/* 354 */     GTK.gtk_widget_get_accessible(controlHandle); }
/*     */   
/*     */   static final long HypertextIfaceDefinition;
/*     */   static final long SelectionIfaceDefinition;
/* 358 */   static final long TableIfaceDefinition; static final long TextIfaceDefinition; static final long ValueIfaceDefinition; static long getType(String widgetTypeName, Accessible accessible, long parentType, int childId) { AccessibleControlEvent event = new AccessibleControlEvent(accessible);
/* 359 */     event.childID = childId;
/* 360 */     List<AccessibleControlListener> listeners = accessible.accessibleControlListeners;
/* 361 */     int i = 0; for (int length = listeners == null ? 0 : listeners.size(); i < length; i++) {
/* 362 */       AccessibleControlListener listener = (AccessibleControlListener)listeners.get(i);
/* 363 */       listener.getRole(event);
/*     */     }
/* 365 */     boolean action = false;boolean editableText = false;boolean hypertext = false;boolean selection = false;boolean table = false;boolean text = false;boolean value = false;
/* 366 */     if (event.detail != 0) {
/* 367 */       for (int i = 0; i < actionRoles.length; i++) {
/* 368 */         if (event.detail == actionRoles[i]) {
/* 369 */           action = true;
/* 370 */           break;
/*     */         }
/*     */       }
/* 373 */       for (int i = 0; i < editableTextRoles.length; i++) {
/* 374 */         if (event.detail == editableTextRoles[i]) {
/* 375 */           editableText = true;
/* 376 */           break;
/*     */         }
/*     */       }
/* 379 */       for (int i = 0; i < hypertextRoles.length; i++) {
/* 380 */         if (event.detail == hypertextRoles[i]) {
/* 381 */           hypertext = true;
/* 382 */           break;
/*     */         }
/*     */       }
/* 385 */       for (int i = 0; i < selectionRoles.length; i++) {
/* 386 */         if (event.detail == selectionRoles[i]) {
/* 387 */           selection = true;
/* 388 */           break;
/*     */         }
/*     */       }
/* 391 */       for (int i = 0; i < tableRoles.length; i++) {
/* 392 */         if (event.detail == tableRoles[i]) {
/* 393 */           table = true;
/* 394 */           break;
/*     */         }
/*     */       }
/* 397 */       for (int i = 0; i < textRoles.length; i++) {
/* 398 */         if (event.detail == textRoles[i]) {
/* 399 */           text = true;
/* 400 */           break;
/*     */         }
/*     */       }
/* 403 */       for (int i = 0; i < valueRoles.length; i++) {
/* 404 */         if (event.detail == valueRoles[i]) {
/* 405 */           value = true;
/* 406 */           break;
/*     */         }
/*     */       }
/*     */     } else {
/* 410 */       action = editableText = hypertext = selection = table = text = value = 1;
/*     */     }
/* 412 */     String swtTypeName = "SWTAccessible" + widgetTypeName;
/* 413 */     if (action) swtTypeName = swtTypeName + "Action";
/* 414 */     if (editableText) swtTypeName = swtTypeName + "EditableText";
/* 415 */     if (hypertext) swtTypeName = swtTypeName + "Hypertext";
/* 416 */     if (selection) swtTypeName = swtTypeName + "Selection";
/* 417 */     if (table) swtTypeName = swtTypeName + "Table";
/* 418 */     if (text) swtTypeName = swtTypeName + "Text";
/* 419 */     if (value) { swtTypeName = swtTypeName + "Value";
/*     */     }
/* 421 */     byte[] nameBytes = Converter.wcsToMbcs(swtTypeName, true);
/* 422 */     long type = OS.g_type_from_name(nameBytes);
/* 423 */     if (type == 0L) {
/* 424 */       if (AccessibleObject.DEBUG) { AccessibleObject.print("-->New Type=" + swtTypeName);
/*     */       }
/* 426 */       long queryPtr = OS.g_malloc(GTypeQuery.sizeof);
/* 427 */       OS.g_type_query(parentType, queryPtr);
/* 428 */       GTypeQuery query = new GTypeQuery();
/* 429 */       OS.memmove(query, queryPtr, GTypeQuery.sizeof);
/* 430 */       OS.g_free(queryPtr);
/* 431 */       GTypeInfo typeInfo = new GTypeInfo();
/* 432 */       typeInfo.base_init = GTypeInfo_base_init_type.getAddress();
/* 433 */       typeInfo.class_size = ((short)query.class_size);
/* 434 */       typeInfo.instance_size = ((short)query.instance_size);
/* 435 */       long definition = OS.g_malloc(GTypeInfo.sizeof);
/* 436 */       OS.memmove(definition, typeInfo, GTypeInfo.sizeof);
/* 437 */       type = OS.g_type_register_static(parentType, nameBytes, definition, 0);
/* 438 */       OS.g_type_add_interface_static(type, ATK.ATK_TYPE_COMPONENT(), ComponentIfaceDefinition);
/* 439 */       if (action) OS.g_type_add_interface_static(type, ATK.ATK_TYPE_ACTION(), ActionIfaceDefinition);
/* 440 */       if (editableText) OS.g_type_add_interface_static(type, ATK.ATK_TYPE_EDITABLE_TEXT(), EditableTextIfaceDefinition);
/* 441 */       if (hypertext) OS.g_type_add_interface_static(type, ATK.ATK_TYPE_HYPERTEXT(), HypertextIfaceDefinition);
/* 442 */       if (selection) OS.g_type_add_interface_static(type, ATK.ATK_TYPE_SELECTION(), SelectionIfaceDefinition);
/* 443 */       if (table) OS.g_type_add_interface_static(type, ATK.ATK_TYPE_TABLE(), TableIfaceDefinition);
/* 444 */       if (text) OS.g_type_add_interface_static(type, ATK.ATK_TYPE_TEXT(), TextIfaceDefinition);
/* 445 */       if (value) OS.g_type_add_interface_static(type, ATK.ATK_TYPE_VALUE(), ValueIfaceDefinition);
/*     */     }
/* 447 */     return type;
/*     */   }
/*     */   
/*     */   static long gTypeInfo_base_init_factory(long klass) {
/* 451 */     org.eclipse.swt.internal.accessibility.gtk.AtkObjectFactoryClass objectClass = new org.eclipse.swt.internal.accessibility.gtk.AtkObjectFactoryClass();
/* 452 */     ATK.memmove(objectClass, klass);
/* 453 */     objectClass.create_accessible = AtkObjectFactoryCB_create_accessible.getAddress();
/* 454 */     ATK.memmove(klass, objectClass);
/* 455 */     return 0L;
/*     */   }
/*     */   
/*     */   static long gTypeInfo_base_init_type(long klass) {
/* 459 */     org.eclipse.swt.internal.accessibility.gtk.AtkObjectClass objectClass = new org.eclipse.swt.internal.accessibility.gtk.AtkObjectClass();
/* 460 */     ATK.memmove(objectClass, klass);
/* 461 */     objectClass.get_name = AtkObjectCB_get_name.getAddress();
/* 462 */     objectClass.get_description = AtkObjectCB_get_description.getAddress();
/* 463 */     objectClass.get_n_children = AtkObjectCB_get_n_children.getAddress();
/* 464 */     objectClass.get_role = AtkObjectCB_get_role.getAddress();
/* 465 */     objectClass.get_parent = AtkObjectCB_get_parent.getAddress();
/* 466 */     objectClass.ref_state_set = AtkObjectCB_ref_state_set.getAddress();
/* 467 */     objectClass.get_index_in_parent = AtkObjectCB_get_index_in_parent.getAddress();
/* 468 */     objectClass.ref_child = AtkObjectCB_ref_child.getAddress();
/* 469 */     objectClass.get_attributes = AtkObjectCB_get_attributes.getAddress();
/* 470 */     long gObjectClass = OS.G_OBJECT_CLASS(klass);
/* 471 */     org.eclipse.swt.internal.gtk.GObjectClass objectClassStruct = new org.eclipse.swt.internal.gtk.GObjectClass();
/* 472 */     OS.memmove(objectClassStruct, gObjectClass);
/* 473 */     objectClassStruct.finalize = GObjectClass_finalize.getAddress();
/* 474 */     OS.memmove(gObjectClass, objectClassStruct);
/* 475 */     ATK.memmove(klass, objectClass);
/* 476 */     return 0L;
/*     */   }
/*     */   
/*     */   static long initActionIfaceCB(long iface) {
/* 480 */     org.eclipse.swt.internal.accessibility.gtk.AtkActionIface inter = new org.eclipse.swt.internal.accessibility.gtk.AtkActionIface();
/* 481 */     ATK.memmove(inter, iface);
/* 482 */     inter.do_action = AtkActionCB_do_action.getAddress();
/* 483 */     inter.get_n_actions = AtkActionCB_get_n_actions.getAddress();
/* 484 */     inter.get_description = AtkActionCB_get_description.getAddress();
/* 485 */     inter.get_keybinding = AtkActionCB_get_keybinding.getAddress();
/* 486 */     inter.get_name = AtkActionCB_get_name.getAddress();
/* 487 */     ATK.memmove(iface, inter);
/* 488 */     return 0L;
/*     */   }
/*     */   
/*     */   static long initComponentIfaceCB(long iface) {
/* 492 */     org.eclipse.swt.internal.accessibility.gtk.AtkComponentIface inter = new org.eclipse.swt.internal.accessibility.gtk.AtkComponentIface();
/* 493 */     ATK.memmove(inter, iface);
/* 494 */     inter.get_extents = AtkComponentCB_get_extents.getAddress();
/* 495 */     inter.get_position = AtkComponentCB_get_position.getAddress();
/* 496 */     inter.get_size = AtkComponentCB_get_size.getAddress();
/* 497 */     inter.ref_accessible_at_point = AtkComponentCB_ref_accessible_at_point.getAddress();
/* 498 */     ATK.memmove(iface, inter);
/* 499 */     return 0L;
/*     */   }
/*     */   
/*     */   static long initEditableTextIfaceCB(long iface) {
/* 503 */     org.eclipse.swt.internal.accessibility.gtk.AtkEditableTextIface inter = new org.eclipse.swt.internal.accessibility.gtk.AtkEditableTextIface();
/* 504 */     ATK.memmove(inter, iface);
/* 505 */     inter.set_run_attributes = AtkEditableTextCB_set_run_attributes.getAddress();
/* 506 */     inter.set_text_contents = AtkEditableTextCB_set_text_contents.getAddress();
/* 507 */     inter.insert_text = AtkEditableTextCB_insert_text.getAddress();
/* 508 */     inter.copy_text = AtkEditableTextCB_copy_text.getAddress();
/* 509 */     inter.cut_text = AtkEditableTextCB_cut_text.getAddress();
/* 510 */     inter.delete_text = AtkEditableTextCB_delete_text.getAddress();
/* 511 */     inter.paste_text = AtkEditableTextCB_paste_text.getAddress();
/* 512 */     ATK.memmove(iface, inter);
/* 513 */     return 0L;
/*     */   }
/*     */   
/*     */   static long initHypertextIfaceCB(long iface) {
/* 517 */     org.eclipse.swt.internal.accessibility.gtk.AtkHypertextIface inter = new org.eclipse.swt.internal.accessibility.gtk.AtkHypertextIface();
/* 518 */     ATK.memmove(inter, iface);
/* 519 */     inter.get_link = AtkHypertextCB_get_link.getAddress();
/* 520 */     inter.get_link_index = AtkHypertextCB_get_link_index.getAddress();
/* 521 */     inter.get_n_links = AtkHypertextCB_get_n_links.getAddress();
/* 522 */     ATK.memmove(iface, inter);
/* 523 */     return 0L;
/*     */   }
/*     */   
/*     */   static long initSelectionIfaceCB(long iface) {
/* 527 */     AtkSelectionIface inter = new AtkSelectionIface();
/* 528 */     ATK.memmove(inter, iface);
/* 529 */     inter.is_child_selected = AtkSelectionCB_is_child_selected.getAddress();
/* 530 */     inter.ref_selection = AtkSelectionCB_ref_selection.getAddress();
/* 531 */     ATK.memmove(iface, inter);
/* 532 */     return 0L;
/*     */   }
/*     */   
/*     */   static long initTableIfaceCB(long iface) {
/* 536 */     org.eclipse.swt.internal.accessibility.gtk.AtkTableIface inter = new org.eclipse.swt.internal.accessibility.gtk.AtkTableIface();
/* 537 */     ATK.memmove(inter, iface);
/* 538 */     inter.ref_at = AtkTableCB_ref_at.getAddress();
/* 539 */     inter.get_index_at = AtkTableCB_get_index_at.getAddress();
/* 540 */     inter.get_column_at_index = AtkTableCB_get_column_at_index.getAddress();
/* 541 */     inter.get_row_at_index = AtkTableCB_get_row_at_index.getAddress();
/* 542 */     inter.get_n_columns = AtkTableCB_get_n_columns.getAddress();
/* 543 */     inter.get_n_rows = AtkTableCB_get_n_rows.getAddress();
/* 544 */     inter.get_column_extent_at = AtkTableCB_get_column_extent_at.getAddress();
/* 545 */     inter.get_row_extent_at = AtkTableCB_get_row_extent_at.getAddress();
/* 546 */     inter.get_caption = AtkTableCB_get_caption.getAddress();
/* 547 */     inter.get_summary = AtkTableCB_get_summary.getAddress();
/* 548 */     inter.get_column_description = AtkTableCB_get_column_description.getAddress();
/* 549 */     inter.get_row_description = AtkTableCB_get_row_description.getAddress();
/* 550 */     inter.get_column_header = AtkTableCB_get_column_header.getAddress();
/* 551 */     inter.get_row_header = AtkTableCB_get_row_header.getAddress();
/* 552 */     inter.get_selected_columns = AtkTableCB_get_selected_columns.getAddress();
/* 553 */     inter.get_selected_rows = AtkTableCB_get_selected_rows.getAddress();
/* 554 */     inter.is_column_selected = AtkTableCB_is_column_selected.getAddress();
/* 555 */     inter.is_row_selected = AtkTableCB_is_row_selected.getAddress();
/* 556 */     inter.is_selected = AtkTableCB_is_selected.getAddress();
/* 557 */     inter.add_column_selection = AtkTableCB_add_column_selection.getAddress();
/* 558 */     inter.add_row_selection = AtkTableCB_add_row_selection.getAddress();
/* 559 */     inter.remove_column_selection = AtkTableCB_remove_column_selection.getAddress();
/* 560 */     inter.remove_row_selection = AtkTableCB_remove_row_selection.getAddress();
/* 561 */     ATK.memmove(iface, inter);
/* 562 */     return 0L;
/*     */   }
/*     */   
/*     */   static long initTextIfaceCB(long iface) {
/* 566 */     AtkTextIface inter = new AtkTextIface();
/* 567 */     ATK.memmove(inter, iface);
/* 568 */     inter.get_range_extents = AtkTextCB_get_range_extents.getAddress();
/* 569 */     inter.get_character_extents = AtkTextCB_get_character_extents.getAddress();
/* 570 */     inter.get_run_attributes = AtkTextCB_get_run_attributes.getAddress();
/* 571 */     inter.get_offset_at_point = AtkTextCB_get_offset_at_point.getAddress();
/* 572 */     inter.add_selection = AtkTextCB_add_selection.getAddress();
/* 573 */     inter.remove_selection = AtkTextCB_remove_selection.getAddress();
/* 574 */     inter.set_selection = AtkTextCB_set_selection.getAddress();
/* 575 */     inter.get_caret_offset = AtkTextCB_get_caret_offset.getAddress();
/* 576 */     inter.set_caret_offset = AtkTextCB_set_caret_offset.getAddress();
/* 577 */     inter.get_character_at_offset = AtkTextCB_get_character_at_offset.getAddress();
/* 578 */     inter.get_character_count = AtkTextCB_get_character_count.getAddress();
/* 579 */     inter.get_n_selections = AtkTextCB_get_n_selections.getAddress();
/* 580 */     inter.get_selection = AtkTextCB_get_selection.getAddress();
/* 581 */     inter.get_text = AtkTextCB_get_text.getAddress();
/* 582 */     inter.get_text_after_offset = AtkTextCB_get_text_after_offset.getAddress();
/* 583 */     inter.get_text_at_offset = AtkTextCB_get_text_at_offset.getAddress();
/* 584 */     inter.get_text_before_offset = AtkTextCB_get_text_before_offset.getAddress();
/* 585 */     inter.get_bounded_ranges = AtkTextCB_get_bounded_ranges.getAddress();
/* 586 */     ATK.memmove(iface, inter);
/* 587 */     return 0L;
/*     */   }
/*     */   
/*     */   static long initValueIfaceCB(long iface) {
/* 591 */     AtkValueIface inter = new AtkValueIface();
/* 592 */     ATK.memmove(inter, iface);
/* 593 */     inter.get_current_value = AtkValueCB_get_current_value.getAddress();
/* 594 */     inter.get_maximum_value = AtkValueCB_get_maximum_value.getAddress();
/* 595 */     inter.get_minimum_value = AtkValueCB_get_minimum_value.getAddress();
/* 596 */     inter.set_current_value = AtkValueCB_set_current_value.getAddress();
/* 597 */     ATK.memmove(iface, inter);
/* 598 */     return 0L;
/*     */   }
/*     */   
/*     */   static void registerAccessible(Accessible accessible) {
/* 602 */     long widget = accessible.getControlHandle();
/* 603 */     long widgetType = OS.G_OBJECT_TYPE(widget);
/* 604 */     long registry = ATK.atk_get_default_registry();
/* 605 */     long factory = ATK.atk_registry_get_factory(registry, widgetType);
/*     */     
/* 607 */     if (ATK.ATK_IS_NO_OP_OBJECT_FACTORY(factory)) return;
/* 608 */     String name = "SWTFactory" + getTypeName(widgetType);
/* 609 */     byte[] factoryName = Converter.wcsToMbcs(name, true);
/* 610 */     if (OS.g_type_from_name(factoryName) == 0L) {
/* 611 */       if (AccessibleObject.DEBUG) { AccessibleObject.print("-->New Factory=" + name);
/*     */       }
/* 613 */       GTypeInfo typeInfo = new GTypeInfo();
/* 614 */       typeInfo.base_init = GTypeInfo_base_init_factory.getAddress();
/* 615 */       typeInfo.class_size = ((short)ATK.AtkObjectFactoryClass_sizeof());
/* 616 */       typeInfo.instance_size = ((short)ATK.AtkObjectFactory_sizeof());
/* 617 */       long info = OS.g_malloc(GTypeInfo.sizeof);
/* 618 */       OS.memmove(info, typeInfo, GTypeInfo.sizeof);
/* 619 */       long swtFactoryType = OS.g_type_register_static(ATK.ATK_TYPE_OBJECT_FACTORY(), factoryName, info, 0);
/* 620 */       long parentType = ATK.atk_object_factory_get_accessible_type(factory);
/* 621 */       ATK.atk_registry_set_factory_type(registry, widgetType, swtFactoryType);
/* 622 */       Factories.put(new LONG(widgetType), new LONG(parentType));
/*     */     }
/* 624 */     if (AccessibleObject.DEBUG) AccessibleObject.print("-->Register=" + accessible.control + " " + widget);
/* 625 */     Accessibles.put(new LONG(widget), accessible);
/*     */   }
/*     */   
/*     */   static void unregisterAccessible(Accessible accessible) {
/* 629 */     long widget = accessible.getControlHandle();
/* 630 */     Accessibles.remove(new LONG(widget));
/* 631 */     if (AccessibleObject.DEBUG) AccessibleObject.print("-->Deregister=" + accessible.control + " " + widget);
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/accessibility/AccessibleFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */