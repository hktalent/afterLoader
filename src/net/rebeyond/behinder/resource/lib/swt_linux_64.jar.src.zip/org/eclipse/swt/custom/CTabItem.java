/*     */ package org.eclipse.swt.custom;
/*     */ 
/*     */ import org.eclipse.swt.SWT;
/*     */ import org.eclipse.swt.graphics.Font;
/*     */ import org.eclipse.swt.graphics.Image;
/*     */ import org.eclipse.swt.graphics.Rectangle;
/*     */ import org.eclipse.swt.widgets.Control;
/*     */ import org.eclipse.swt.widgets.Item;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CTabItem
/*     */   extends Item
/*     */ {
/*     */   CTabFolder parent;
/*     */   int x;
/*     */   int y;
/*     */   int width;
/*  38 */   int height = 0;
/*     */   
/*     */   Control control;
/*     */   
/*     */   String toolTipText;
/*     */   
/*     */   String shortenedText;
/*     */   
/*     */   int shortenedTextWidth;
/*     */   Font font;
/*     */   Image disabledImage;
/*  49 */   Rectangle closeRect = new Rectangle(0, 0, 0, 0);
/*  50 */   int closeImageState = 8;
/*  51 */   int state = 0;
/*  52 */   boolean showClose = false;
/*  53 */   boolean showing = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CTabItem(CTabFolder parent, int style)
/*     */   {
/*  84 */     this(parent, style, parent.getItemCount());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CTabItem(CTabFolder parent, int style, int index)
/*     */   {
/* 117 */     super(parent, style);
/* 118 */     this.showClose = ((style & 0x40) != 0);
/* 119 */     parent.createItem(this, index);
/*     */   }
/*     */   
/*     */ 
/*     */   public void dispose()
/*     */   {
/* 125 */     if (isDisposed()) { return;
/*     */     }
/* 127 */     this.parent.destroyItem(this);
/* 128 */     super.dispose();
/* 129 */     this.parent = null;
/* 130 */     this.control = null;
/* 131 */     this.toolTipText = null;
/* 132 */     this.shortenedText = null;
/* 133 */     this.font = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Rectangle getBounds()
/*     */   {
/* 153 */     this.parent.runUpdate();
/* 154 */     return new Rectangle(this.x, this.y, this.width, this.height);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Control getControl()
/*     */   {
/* 167 */     checkWidget();
/* 168 */     return this.control;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public Image getDisabledImage()
/*     */   {
/* 184 */     checkWidget();
/* 185 */     return this.disabledImage;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Font getFont()
/*     */   {
/* 200 */     checkWidget();
/* 201 */     if (this.font != null) return this.font;
/* 202 */     return this.parent.getFont();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CTabFolder getParent()
/*     */   {
/* 220 */     return this.parent;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getShowClose()
/*     */   {
/* 237 */     checkWidget();
/* 238 */     return this.showClose;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getToolTipText()
/*     */   {
/* 252 */     checkWidget();
/* 253 */     if ((this.toolTipText == null) && (this.shortenedText != null)) {
/* 254 */       String text = getText();
/* 255 */       if (!this.shortenedText.equals(text)) return text;
/*     */     }
/* 257 */     return this.toolTipText;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isShowing()
/*     */   {
/* 272 */     checkWidget();
/* 273 */     return this.showing;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setControl(Control control)
/*     */   {
/* 292 */     checkWidget();
/* 293 */     if (control != null) {
/* 294 */       if (control.isDisposed()) SWT.error(5);
/* 295 */       if (control.getParent() != this.parent) SWT.error(32);
/*     */     }
/* 297 */     if ((this.control != null) && (!this.control.isDisposed())) {
/* 298 */       this.control.setVisible(false);
/*     */     }
/* 300 */     this.control = control;
/* 301 */     if (this.control != null) {
/* 302 */       int index = this.parent.indexOf(this);
/* 303 */       if (index == this.parent.getSelectionIndex()) {
/* 304 */         this.control.setBounds(this.parent.getClientArea());
/* 305 */         this.control.setVisible(true);
/*     */       } else {
/* 307 */         int selectedIndex = this.parent.getSelectionIndex();
/* 308 */         Control selectedControl = null;
/* 309 */         if (selectedIndex != -1) {
/* 310 */           selectedControl = this.parent.getItem(selectedIndex).control;
/*     */         }
/* 312 */         if (this.control != selectedControl) {
/* 313 */           this.control.setVisible(false);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public void setDisabledImage(Image image)
/*     */   {
/* 333 */     checkWidget();
/* 334 */     if ((image != null) && (image.isDisposed())) {
/* 335 */       SWT.error(5);
/*     */     }
/* 337 */     this.disabledImage = image;
/*     */   }
/*     */   
/* 340 */   boolean setFocus() { return (this.control != null) && (!this.control.isDisposed()) && (this.control.setFocus()); }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFont(Font font)
/*     */   {
/* 360 */     checkWidget();
/* 361 */     if ((font != null) && (font.isDisposed())) {
/* 362 */       SWT.error(5);
/*     */     }
/* 364 */     if ((font == null) && (this.font == null)) return;
/* 365 */     if ((font != null) && (font.equals(this.font))) return;
/* 366 */     this.font = font;
/* 367 */     this.parent.updateFolder(12);
/*     */   }
/*     */   
/*     */   public void setImage(Image image) {
/* 371 */     checkWidget();
/* 372 */     if ((image != null) && (image.isDisposed())) {
/* 373 */       SWT.error(5);
/*     */     }
/* 375 */     Image oldImage = getImage();
/* 376 */     if ((image == null) && (oldImage == null)) return;
/* 377 */     if ((image != null) && (image.equals(oldImage))) return;
/* 378 */     super.setImage(image);
/* 379 */     this.parent.updateFolder(12);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setShowClose(boolean close)
/*     */   {
/* 396 */     checkWidget();
/* 397 */     if (this.showClose == close) return;
/* 398 */     this.showClose = close;
/* 399 */     this.parent.updateFolder(4);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setText(String string)
/*     */   {
/* 414 */     checkWidget();
/* 415 */     if (string == null) SWT.error(4);
/* 416 */     if (string.equals(getText())) return;
/* 417 */     super.setText(string);
/* 418 */     this.shortenedText = null;
/* 419 */     this.shortenedTextWidth = 0;
/* 420 */     this.parent.updateFolder(12);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setToolTipText(String string)
/*     */   {
/* 443 */     checkWidget();
/* 444 */     this.toolTipText = string;
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/custom/CTabItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */