/*     */ package org.eclipse.swt.layout;
/*     */ 
/*     */ import org.eclipse.swt.graphics.Point;
/*     */ import org.eclipse.swt.widgets.Control;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class GridData
/*     */ {
/*  70 */   public int verticalAlignment = 2;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  85 */   public int horizontalAlignment = 1;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  96 */   public int widthHint = -1;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 107 */   public int heightHint = -1;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 115 */   public int horizontalIndent = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 125 */   public int verticalIndent = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 133 */   public int horizontalSpan = 1;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 141 */   public int verticalSpan = 1;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 172 */   public boolean grabExcessHorizontalSpace = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 203 */   public boolean grabExcessVerticalSpace = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 218 */   public int minimumWidth = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 233 */   public int minimumHeight = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 246 */   public boolean exclude = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int BEGINNING = 1;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int CENTER = 2;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int END = 3;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int FILL = 4;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int VERTICAL_ALIGN_BEGINNING = 2;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int VERTICAL_ALIGN_CENTER = 4;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int VERTICAL_ALIGN_END = 8;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int VERTICAL_ALIGN_FILL = 16;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int HORIZONTAL_ALIGN_BEGINNING = 32;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int HORIZONTAL_ALIGN_CENTER = 64;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int HORIZONTAL_ALIGN_END = 128;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int HORIZONTAL_ALIGN_FILL = 256;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int GRAB_HORIZONTAL = 512;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int GRAB_VERTICAL = 1024;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int FILL_VERTICAL = 1040;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int FILL_HORIZONTAL = 768;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int FILL_BOTH = 1808;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 399 */   int cacheWidth = -1; int cacheHeight = -1;
/* 400 */   int defaultWhint; int defaultHhint; int defaultWidth = -1; int defaultHeight = -1;
/* 401 */   int currentWhint; int currentHhint; int currentWidth = -1; int currentHeight = -1;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public GridData() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public GridData(int style)
/*     */   {
/* 419 */     if ((style & 0x2) != 0) this.verticalAlignment = 1;
/* 420 */     if ((style & 0x4) != 0) this.verticalAlignment = 2;
/* 421 */     if ((style & 0x10) != 0) this.verticalAlignment = 4;
/* 422 */     if ((style & 0x8) != 0) this.verticalAlignment = 3;
/* 423 */     if ((style & 0x20) != 0) this.horizontalAlignment = 1;
/* 424 */     if ((style & 0x40) != 0) this.horizontalAlignment = 2;
/* 425 */     if ((style & 0x100) != 0) this.horizontalAlignment = 4;
/* 426 */     if ((style & 0x80) != 0) this.horizontalAlignment = 3;
/* 427 */     this.grabExcessHorizontalSpace = ((style & 0x200) != 0);
/* 428 */     this.grabExcessVerticalSpace = ((style & 0x400) != 0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public GridData(int horizontalAlignment, int verticalAlignment, boolean grabExcessHorizontalSpace, boolean grabExcessVerticalSpace)
/*     */   {
/* 444 */     this(horizontalAlignment, verticalAlignment, grabExcessHorizontalSpace, grabExcessVerticalSpace, 1, 1);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public GridData(int horizontalAlignment, int verticalAlignment, boolean grabExcessHorizontalSpace, boolean grabExcessVerticalSpace, int horizontalSpan, int verticalSpan)
/*     */   {
/* 463 */     this.horizontalAlignment = horizontalAlignment;
/* 464 */     this.verticalAlignment = verticalAlignment;
/* 465 */     this.grabExcessHorizontalSpace = grabExcessHorizontalSpace;
/* 466 */     this.grabExcessVerticalSpace = grabExcessVerticalSpace;
/* 467 */     this.horizontalSpan = horizontalSpan;
/* 468 */     this.verticalSpan = verticalSpan;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public GridData(int width, int height)
/*     */   {
/* 483 */     this.widthHint = width;
/* 484 */     this.heightHint = height;
/*     */   }
/*     */   
/*     */   void computeSize(Control control, int wHint, int hHint, boolean flushCache) {
/* 488 */     if ((this.cacheWidth != -1) && (this.cacheHeight != -1)) return;
/* 489 */     if ((wHint == this.widthHint) && (hHint == this.heightHint)) {
/* 490 */       if ((this.defaultWidth == -1) || (this.defaultHeight == -1) || (wHint != this.defaultWhint) || (hHint != this.defaultHhint)) {
/* 491 */         Point size = control.computeSize(wHint, hHint, flushCache);
/* 492 */         this.defaultWhint = wHint;
/* 493 */         this.defaultHhint = hHint;
/* 494 */         this.defaultWidth = size.x;
/* 495 */         this.defaultHeight = size.y;
/*     */       }
/* 497 */       this.cacheWidth = this.defaultWidth;
/* 498 */       this.cacheHeight = this.defaultHeight;
/* 499 */       return;
/*     */     }
/* 501 */     if ((this.currentWidth == -1) || (this.currentHeight == -1) || (wHint != this.currentWhint) || (hHint != this.currentHhint)) {
/* 502 */       Point size = control.computeSize(wHint, hHint, flushCache);
/* 503 */       this.currentWhint = wHint;
/* 504 */       this.currentHhint = hHint;
/* 505 */       this.currentWidth = size.x;
/* 506 */       this.currentHeight = size.y;
/*     */     }
/* 508 */     this.cacheWidth = this.currentWidth;
/* 509 */     this.cacheHeight = this.currentHeight;
/*     */   }
/*     */   
/*     */   void flushCache() {
/* 513 */     this.cacheWidth = (this.cacheHeight = -1);
/* 514 */     this.defaultWidth = (this.defaultHeight = -1);
/* 515 */     this.currentWidth = (this.currentHeight = -1);
/*     */   }
/*     */   
/*     */   String getName() {
/* 519 */     String string = getClass().getName();
/* 520 */     int index = string.lastIndexOf('.');
/* 521 */     if (index == -1) return string;
/* 522 */     return string.substring(index + 1, string.length());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 533 */     String hAlign = "";
/* 534 */     switch (this.horizontalAlignment) {
/* 535 */     case 4:  hAlign = "SWT.FILL"; break;
/* 536 */     case 1:  hAlign = "SWT.BEGINNING"; break;
/* 537 */     case 16384:  hAlign = "SWT.LEFT"; break;
/* 538 */     case 16777224:  hAlign = "SWT.END"; break;
/* 539 */     case 3:  hAlign = "GridData.END"; break;
/* 540 */     case 131072:  hAlign = "SWT.RIGHT"; break;
/* 541 */     case 16777216:  hAlign = "SWT.CENTER"; break;
/* 542 */     case 2:  hAlign = "GridData.CENTER"; break;
/* 543 */     default:  hAlign = "Undefined " + this.horizontalAlignment;
/*     */     }
/* 545 */     String vAlign = "";
/* 546 */     switch (this.verticalAlignment) {
/* 547 */     case 4:  vAlign = "SWT.FILL"; break;
/* 548 */     case 1:  vAlign = "SWT.BEGINNING"; break;
/* 549 */     case 128:  vAlign = "SWT.TOP"; break;
/* 550 */     case 16777224:  vAlign = "SWT.END"; break;
/* 551 */     case 3:  vAlign = "GridData.END"; break;
/* 552 */     case 1024:  vAlign = "SWT.BOTTOM"; break;
/* 553 */     case 16777216:  vAlign = "SWT.CENTER"; break;
/* 554 */     case 2:  vAlign = "GridData.CENTER"; break;
/* 555 */     default:  vAlign = "Undefined " + this.verticalAlignment;
/*     */     }
/* 557 */     String string = getName() + " {";
/* 558 */     string = string + "horizontalAlignment=" + hAlign + " ";
/* 559 */     if (this.horizontalIndent != 0) string = string + "horizontalIndent=" + this.horizontalIndent + " ";
/* 560 */     if (this.horizontalSpan != 1) string = string + "horizontalSpan=" + this.horizontalSpan + " ";
/* 561 */     if (this.grabExcessHorizontalSpace) string = string + "grabExcessHorizontalSpace=" + this.grabExcessHorizontalSpace + " ";
/* 562 */     if (this.widthHint != -1) string = string + "widthHint=" + this.widthHint + " ";
/* 563 */     if (this.minimumWidth != 0) string = string + "minimumWidth=" + this.minimumWidth + " ";
/* 564 */     string = string + "verticalAlignment=" + vAlign + " ";
/* 565 */     if (this.verticalIndent != 0) string = string + "verticalIndent=" + this.verticalIndent + " ";
/* 566 */     if (this.verticalSpan != 1) string = string + "verticalSpan=" + this.verticalSpan + " ";
/* 567 */     if (this.grabExcessVerticalSpace) string = string + "grabExcessVerticalSpace=" + this.grabExcessVerticalSpace + " ";
/* 568 */     if (this.heightHint != -1) string = string + "heightHint=" + this.heightHint + " ";
/* 569 */     if (this.minimumHeight != 0) string = string + "minimumHeight=" + this.minimumHeight + " ";
/* 570 */     if (this.exclude) string = string + "exclude=" + this.exclude + " ";
/* 571 */     string = string.trim();
/* 572 */     string = string + "}";
/* 573 */     return string;
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/layout/GridData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */