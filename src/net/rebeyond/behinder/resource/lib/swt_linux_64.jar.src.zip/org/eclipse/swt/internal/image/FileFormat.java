/*     */ package org.eclipse.swt.internal.image;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import org.eclipse.swt.SWT;
/*     */ import org.eclipse.swt.graphics.ImageData;
/*     */ import org.eclipse.swt.graphics.ImageLoader;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class FileFormat
/*     */ {
/*     */   static final String FORMAT_PACKAGE = "org.eclipse.swt.internal.image";
/*     */   static final String FORMAT_SUFFIX = "FileFormat";
/*  26 */   static final String[] FORMATS = { "WinBMP", "WinBMP", "GIF", "WinICO", "JPEG", "PNG", "TIFF", "OS2BMP" };
/*     */   LEDataInputStream inputStream;
/*     */   LEDataOutputStream outputStream;
/*     */   ImageLoader loader;
/*     */   int compression;
/*     */   
/*     */   static FileFormat getFileFormat(LEDataInputStream stream, String format) throws Exception
/*     */   {
/*  34 */     Class<?> clazz = Class.forName("org.eclipse.swt.internal.image." + format + "FileFormat");
/*  35 */     FileFormat fileFormat = (FileFormat)clazz.newInstance();
/*  36 */     if (fileFormat.isFileFormat(stream)) return fileFormat;
/*  37 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   abstract boolean isFileFormat(LEDataInputStream paramLEDataInputStream);
/*     */   
/*     */ 
/*     */ 
/*     */   abstract ImageData[] loadFromByteStream();
/*     */   
/*     */ 
/*     */ 
/*     */   public ImageData[] loadFromStream(LEDataInputStream stream)
/*     */   {
/*     */     try
/*     */     {
/*  54 */       this.inputStream = stream;
/*  55 */       return loadFromByteStream();
/*     */     } catch (Exception e) {
/*  57 */       if ((e instanceof IOException)) {
/*  58 */         SWT.error(39, e);
/*     */       } else
/*  60 */         SWT.error(40, e);
/*     */     }
/*  62 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ImageData[] load(InputStream is, ImageLoader loader)
/*     */   {
/*  71 */     FileFormat fileFormat = null;
/*  72 */     LEDataInputStream stream = new LEDataInputStream(is);
/*  73 */     for (int i = 1; i < FORMATS.length; i++) {
/*  74 */       if (FORMATS[i] != null) {
/*     */         try {
/*  76 */           fileFormat = getFileFormat(stream, FORMATS[i]);
/*  77 */           if (fileFormat != null)
/*     */             break;
/*  79 */         } catch (ClassNotFoundException e) { FORMATS[i] = null;
/*     */         }
/*     */         catch (Exception localException) {}
/*     */       }
/*     */     }
/*  84 */     if (fileFormat == null) SWT.error(42);
/*  85 */     fileFormat.loader = loader;
/*  86 */     return fileFormat.loadFromStream(stream);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void save(OutputStream os, int format, ImageLoader loader)
/*     */   {
/*  94 */     if ((format < 0) || (format >= FORMATS.length)) SWT.error(42);
/*  95 */     if (FORMATS[format] == null) SWT.error(42);
/*  96 */     if ((loader.data == null) || (loader.data.length < 1)) { SWT.error(5);
/*     */     }
/*  98 */     LEDataOutputStream stream = new LEDataOutputStream(os);
/*  99 */     FileFormat fileFormat = null;
/*     */     try {
/* 101 */       Class<?> clazz = Class.forName("org.eclipse.swt.internal.image." + FORMATS[format] + "FileFormat");
/* 102 */       fileFormat = (FileFormat)clazz.newInstance();
/*     */     } catch (Exception e) {
/* 104 */       SWT.error(42);
/*     */     }
/* 106 */     if (format == 1) {
/* 107 */       switch (loader.data[0].depth) {
/* 108 */       case 8:  fileFormat.compression = 1; break;
/* 109 */       case 4:  fileFormat.compression = 2;
/*     */       }
/*     */     }
/* 112 */     fileFormat.unloadIntoStream(loader, stream);
/*     */   }
/*     */   
/*     */ 
/*     */   abstract void unloadIntoByteStream(ImageLoader paramImageLoader);
/*     */   
/*     */ 
/*     */   public void unloadIntoStream(ImageLoader loader, LEDataOutputStream stream)
/*     */   {
/*     */     try
/*     */     {
/* 123 */       this.outputStream = stream;
/* 124 */       unloadIntoByteStream(loader);
/* 125 */       this.outputStream.flush();
/*     */     } catch (Exception e) {
/* 127 */       try { this.outputStream.flush(); } catch (Exception localException1) {}
/* 128 */       SWT.error(39, e);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/internal/image/FileFormat.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */