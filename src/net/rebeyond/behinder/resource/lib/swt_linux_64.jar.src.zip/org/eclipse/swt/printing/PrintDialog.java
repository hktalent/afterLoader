/*     */ package org.eclipse.swt.printing;
/*     */ 
/*     */ import org.eclipse.swt.SWT;
/*     */ import org.eclipse.swt.internal.C;
/*     */ import org.eclipse.swt.internal.Callback;
/*     */ import org.eclipse.swt.internal.Converter;
/*     */ import org.eclipse.swt.internal.LONG;
/*     */ import org.eclipse.swt.internal.gtk.GDK;
/*     */ import org.eclipse.swt.internal.gtk.GTK;
/*     */ import org.eclipse.swt.internal.gtk.OS;
/*     */ import org.eclipse.swt.widgets.Dialog;
/*     */ import org.eclipse.swt.widgets.Display;
/*     */ import org.eclipse.swt.widgets.Shell;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PrintDialog
/*     */   extends Dialog
/*     */ {
/*  33 */   PrinterData printerData = new PrinterData();
/*     */   
/*     */ 
/*     */   long handle;
/*     */   
/*     */ 
/*     */   int index;
/*     */   
/*     */ 
/*     */   byte[] settingsData;
/*     */   
/*     */ 
/*     */   static final String GET_MODAL_DIALOG = "org.eclipse.swt.internal.gtk.getModalDialog";
/*     */   
/*     */ 
/*     */   static final String SET_MODAL_DIALOG = "org.eclipse.swt.internal.gtk.setModalDialog";
/*     */   
/*     */ 
/*     */   static final String ADD_IDLE_PROC_KEY = "org.eclipse.swt.internal.gtk.addIdleProc";
/*     */   
/*     */ 
/*     */   static final String REMOVE_IDLE_PROC_KEY = "org.eclipse.swt.internal.gtk.removeIdleProc";
/*     */   
/*     */ 
/*     */   static final String GET_EMISSION_PROC_KEY = "org.eclipse.swt.internal.gtk.getEmissionProc";
/*     */   
/*     */ 
/*     */   public PrintDialog(Shell parent)
/*     */   {
/*  62 */     this(parent, 32768);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PrintDialog(Shell parent, int style)
/*     */   {
/*  94 */     super(parent, checkStyleBit(parent, style));
/*  95 */     checkSubclass();
/*  96 */     if (OS.IsWin32) { SWT.error(20);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPrinterData(PrinterData data)
/*     */   {
/* 112 */     if (data == null) data = new PrinterData();
/* 113 */     this.printerData = data;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PrinterData getPrinterData()
/*     */   {
/* 125 */     return this.printerData;
/*     */   }
/*     */   
/*     */   static int checkBits(int style, int int0, int int1, int int2, int int3, int int4, int int5) {
/* 129 */     int mask = int0 | int1 | int2 | int3 | int4 | int5;
/* 130 */     if ((style & mask) == 0) style |= int0;
/* 131 */     if ((style & int0) != 0) style = style & (mask ^ 0xFFFFFFFF) | int0;
/* 132 */     if ((style & int1) != 0) style = style & (mask ^ 0xFFFFFFFF) | int1;
/* 133 */     if ((style & int2) != 0) style = style & (mask ^ 0xFFFFFFFF) | int2;
/* 134 */     if ((style & int3) != 0) style = style & (mask ^ 0xFFFFFFFF) | int3;
/* 135 */     if ((style & int4) != 0) style = style & (mask ^ 0xFFFFFFFF) | int4;
/* 136 */     if ((style & int5) != 0) style = style & (mask ^ 0xFFFFFFFF) | int5;
/* 137 */     return style;
/*     */   }
/*     */   
/*     */   static int checkStyleBit(Shell parent, int style) {
/* 141 */     int mask = 229376;
/* 142 */     if ((style & 0x10000000) != 0) {
/* 143 */       style &= 0xEFFFFFFF;
/* 144 */       if ((style & mask) == 0) {
/* 145 */         style |= (parent == null ? 65536 : 32768);
/*     */       }
/*     */     }
/* 148 */     if ((style & mask) == 0) {
/* 149 */       style |= 0x10000;
/*     */     }
/* 151 */     style &= 0xF7FFFFFF;
/* 152 */     if (((style & 0x6000000) == 0) && 
/* 153 */       (parent != null)) {
/* 154 */       if ((parent.getStyle() & 0x2000000) != 0) style |= 0x2000000;
/* 155 */       if ((parent.getStyle() & 0x4000000) != 0) { style |= 0x4000000;
/*     */       }
/*     */     }
/* 158 */     return checkBits(style, 33554432, 67108864, 0, 0, 0, 0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void checkSubclass() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getScope()
/*     */   {
/* 181 */     return this.printerData.scope;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setScope(int scope)
/*     */   {
/* 200 */     this.printerData.scope = scope;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getStartPage()
/*     */   {
/* 214 */     return this.printerData.startPage;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setStartPage(int startPage)
/*     */   {
/* 228 */     this.printerData.startPage = startPage;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getEndPage()
/*     */   {
/* 242 */     return this.printerData.endPage;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setEndPage(int endPage)
/*     */   {
/* 256 */     this.printerData.endPage = endPage;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getPrintToFile()
/*     */   {
/* 266 */     return this.printerData.printToFile;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPrintToFile(boolean printToFile)
/*     */   {
/* 276 */     this.printerData.printToFile = printToFile;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PrinterData open()
/*     */   {
/* 292 */     byte[] titleBytes = Converter.wcsToMbcs(getText(), true);
/* 293 */     long topHandle = getParent().handle;
/* 294 */     while ((topHandle != 0L) && (!GTK.GTK_IS_WINDOW(topHandle))) {
/* 295 */       topHandle = GTK.gtk_widget_get_parent(topHandle);
/*     */     }
/* 297 */     this.handle = GTK.gtk_print_unix_dialog_new(titleBytes, topHandle);
/*     */     
/*     */ 
/* 300 */     GTK.gtk_print_unix_dialog_set_current_page(this.handle, -1);
/*     */     
/* 302 */     GTK.gtk_print_unix_dialog_set_manual_capabilities(this.handle, 7L);
/*     */     
/*     */ 
/*     */ 
/* 306 */     long settings = GTK.gtk_print_settings_new();
/* 307 */     long page_setup = GTK.gtk_page_setup_new();
/*     */     
/* 309 */     if (this.printerData.otherData != null) {
/* 310 */       Printer.restore(this.printerData.otherData, settings, page_setup);
/*     */     }
/*     */     
/*     */ 
/* 314 */     String printerName = this.printerData.name;
/* 315 */     if ((printerName == null) && (this.printerData.printToFile))
/*     */     {
/* 317 */       long printer = Printer.gtkPrinterFromPrinterData(this.printerData);
/* 318 */       if (printer != 0L) {
/* 319 */         PrinterData data = Printer.printerDataFromGtkPrinter(printer);
/* 320 */         printerName = data.name;
/* 321 */         OS.g_object_unref(printer);
/*     */       }
/*     */     }
/* 324 */     if (printerName != null) {
/* 325 */       byte[] nameBytes = Converter.wcsToMbcs(printerName, true);
/* 326 */       GTK.gtk_print_settings_set_printer(settings, nameBytes);
/*     */     }
/*     */     
/* 329 */     switch (this.printerData.scope) {
/*     */     case 0: 
/* 331 */       GTK.gtk_print_settings_set_print_pages(settings, 0);
/* 332 */       break;
/*     */     case 1: 
/* 334 */       GTK.gtk_print_settings_set_print_pages(settings, 2);
/* 335 */       int[] pageRange = new int[2];
/* 336 */       pageRange[0] = (this.printerData.startPage - 1);
/* 337 */       pageRange[1] = (this.printerData.endPage - 1);
/* 338 */       GTK.gtk_print_settings_set_page_ranges(settings, pageRange, 1);
/* 339 */       break;
/*     */     
/*     */     case 2: 
/* 342 */       GTK.gtk_print_settings_set_print_pages(settings, 0);
/*     */     }
/*     */     
/* 345 */     if (((this.printerData.printToFile) || ("GtkPrintBackendFile".equals(this.printerData.driver))) && (this.printerData.fileName != null))
/*     */     {
/* 347 */       byte[] uri = Printer.uriFromFilename(this.printerData.fileName);
/* 348 */       if (uri != null) {
/* 349 */         GTK.gtk_print_settings_set(settings, GTK.GTK_PRINT_SETTINGS_OUTPUT_URI, uri);
/*     */       }
/*     */     }
/* 352 */     GTK.gtk_print_settings_set_n_copies(settings, this.printerData.copyCount);
/* 353 */     GTK.gtk_print_settings_set_collate(settings, this.printerData.collate);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 359 */     byte[] keyBuffer = Converter.wcsToMbcs("cups-Duplex", true);
/* 360 */     GTK.gtk_print_settings_set(settings, keyBuffer, (byte[])null);
/* 361 */     if (this.printerData.duplex != -1) {
/* 362 */       int duplex = this.printerData.duplex == 2 ? 2 : this.printerData.duplex == 1 ? 1 : 0;
/*     */       
/*     */ 
/* 365 */       GTK.gtk_print_settings_set_duplex(settings, duplex);
/*     */     }
/* 367 */     int orientation = this.printerData.orientation == 2 ? 1 : 0;
/* 368 */     GTK.gtk_print_settings_set_orientation(settings, orientation);
/* 369 */     GTK.gtk_page_setup_set_orientation(page_setup, orientation);
/*     */     
/* 371 */     GTK.gtk_print_unix_dialog_set_settings(this.handle, settings);
/* 372 */     GTK.gtk_print_unix_dialog_set_page_setup(this.handle, page_setup);
/* 373 */     GTK.gtk_print_unix_dialog_set_embed_page_setup(this.handle, true);
/* 374 */     OS.g_object_unref(settings);
/* 375 */     OS.g_object_unref(page_setup);
/* 376 */     long group = GTK.gtk_window_get_group(0L);
/* 377 */     GTK.gtk_window_group_add_window(group, this.handle);
/* 378 */     GTK.gtk_window_set_modal(this.handle, true);
/* 379 */     PrinterData data = null;
/*     */     
/* 381 */     Display display = getParent() != null ? getParent().getDisplay() : Display.getCurrent();
/*     */     
/* 383 */     int signalId = 0;
/* 384 */     long hookId = 0L;
/* 385 */     if ((getStyle() & 0x4000000) != 0) {
/* 386 */       signalId = OS.g_signal_lookup(OS.map, GTK.GTK_TYPE_WIDGET());
/* 387 */       hookId = OS.g_signal_add_emission_hook(signalId, 0, ((LONG)display.getData("org.eclipse.swt.internal.gtk.getEmissionProc")).value, this.handle, 0L);
/*     */     }
/* 389 */     display.setData("org.eclipse.swt.internal.gtk.addIdleProc", null);
/* 390 */     Object oldModal = null;
/* 391 */     if (GTK.gtk_window_get_modal(this.handle)) {
/* 392 */       oldModal = display.getData("org.eclipse.swt.internal.gtk.getModalDialog");
/* 393 */       display.setData("org.eclipse.swt.internal.gtk.setModalDialog", this);
/*     */     }
/* 395 */     display.sendPreExternalEventDispatchEvent();
/* 396 */     int response = GTK.gtk_dialog_run(this.handle);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 403 */     GDK.gdk_threads_leave();
/* 404 */     display.sendPostExternalEventDispatchEvent();
/* 405 */     if (GTK.gtk_window_get_modal(this.handle)) {
/* 406 */       display.setData("org.eclipse.swt.internal.gtk.setModalDialog", oldModal);
/*     */     }
/* 408 */     if ((getStyle() & 0x4000000) != 0) {
/* 409 */       OS.g_signal_remove_emission_hook(signalId, hookId);
/*     */     }
/* 411 */     if (response == -5) {
/* 412 */       long printer = GTK.gtk_print_unix_dialog_get_selected_printer(this.handle);
/* 413 */       if (printer != 0L)
/*     */       {
/* 415 */         settings = GTK.gtk_print_unix_dialog_get_settings(this.handle);
/* 416 */         page_setup = GTK.gtk_print_unix_dialog_get_page_setup(this.handle);
/* 417 */         data = Printer.printerDataFromGtkPrinter(printer);
/* 418 */         int print_pages = GTK.gtk_print_settings_get_print_pages(settings);
/* 419 */         switch (print_pages) {
/*     */         case 0: 
/* 421 */           data.scope = 0;
/* 422 */           break;
/*     */         case 2: 
/* 424 */           data.scope = 1;
/* 425 */           int[] num_ranges = new int[1];
/* 426 */           long page_ranges = GTK.gtk_print_settings_get_page_ranges(settings, num_ranges);
/* 427 */           int[] pageRange = new int[2];
/* 428 */           int length = num_ranges[0];
/* 429 */           int min = Integer.MAX_VALUE;int max = 0;
/* 430 */           for (int i = 0; i < length; i++) {
/* 431 */             C.memmove(pageRange, page_ranges + i * pageRange.length * 4, pageRange.length * 4);
/* 432 */             min = Math.min(min, pageRange[0] + 1);
/* 433 */             max = Math.max(max, pageRange[1] + 1);
/*     */           }
/* 435 */           OS.g_free(page_ranges);
/* 436 */           data.startPage = (min == Integer.MAX_VALUE ? 1 : min);
/* 437 */           data.endPage = (max == 0 ? 1 : max);
/* 438 */           break;
/*     */         
/*     */         case 1: 
/* 441 */           data.scope = 2;
/* 442 */           data.startPage = (data.endPage = GTK.gtk_print_unix_dialog_get_current_page(this.handle));
/*     */         }
/*     */         
/*     */         
/* 446 */         data.printToFile = "GtkPrintBackendFile".equals(data.driver);
/* 447 */         if (data.printToFile) {
/* 448 */           long address = GTK.gtk_print_settings_get(settings, GTK.GTK_PRINT_SETTINGS_OUTPUT_URI);
/* 449 */           int length = C.strlen(address);
/* 450 */           byte[] buffer = new byte[length];
/* 451 */           C.memmove(buffer, address, length);
/* 452 */           data.fileName = new String(Converter.mbcsToWcs(buffer));
/*     */         }
/*     */         
/* 455 */         data.copyCount = GTK.gtk_print_settings_get_n_copies(settings);
/* 456 */         data.collate = GTK.gtk_print_settings_get_collate(settings);
/* 457 */         int duplex = GTK.gtk_print_settings_get_duplex(settings);
/* 458 */         data.duplex = (duplex == 2 ? 2 : duplex == 1 ? 1 : 0);
/*     */         
/*     */ 
/* 461 */         data.orientation = (GTK.gtk_page_setup_get_orientation(page_setup) == 1 ? 2 : 1);
/*     */         
/*     */ 
/* 464 */         Callback printSettingsCallback = new Callback(this, "GtkPrintSettingsFunc", 3);
/* 465 */         long GtkPrintSettingsFunc = printSettingsCallback.getAddress();
/* 466 */         if (GtkPrintSettingsFunc == 0L) SWT.error(3);
/* 467 */         this.index = 0;
/* 468 */         this.settingsData = new byte['Ѐ'];
/* 469 */         GTK.gtk_print_settings_foreach(settings, GtkPrintSettingsFunc, 0L);
/* 470 */         printSettingsCallback.dispose();
/* 471 */         this.index += 1;
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 476 */         store("orientation", GTK.gtk_page_setup_get_orientation(page_setup));
/* 477 */         store("top_margin", GTK.gtk_page_setup_get_top_margin(page_setup, 3));
/* 478 */         store("bottom_margin", GTK.gtk_page_setup_get_bottom_margin(page_setup, 3));
/* 479 */         store("left_margin", GTK.gtk_page_setup_get_left_margin(page_setup, 3));
/* 480 */         store("right_margin", GTK.gtk_page_setup_get_right_margin(page_setup, 3));
/* 481 */         long paper_size = GTK.gtk_page_setup_get_paper_size(page_setup);
/* 482 */         storeBytes("paper_size_name", GTK.gtk_paper_size_get_name(paper_size));
/* 483 */         storeBytes("paper_size_display_name", GTK.gtk_paper_size_get_display_name(paper_size));
/* 484 */         storeBytes("paper_size_ppd_name", GTK.gtk_paper_size_get_ppd_name(paper_size));
/* 485 */         store("paper_size_width", GTK.gtk_paper_size_get_width(paper_size, 3));
/* 486 */         store("paper_size_height", GTK.gtk_paper_size_get_height(paper_size, 3));
/* 487 */         store("paper_size_is_custom", GTK.gtk_paper_size_is_custom(paper_size));
/* 488 */         data.otherData = this.settingsData;
/* 489 */         OS.g_object_unref(settings);
/* 490 */         this.printerData = data;
/*     */       }
/*     */     }
/* 493 */     display.setData("org.eclipse.swt.internal.gtk.removeIdleProc", null);
/* 494 */     GTK.gtk_widget_destroy(this.handle);
/* 495 */     return data;
/*     */   }
/*     */   
/*     */   long GtkPrintSettingsFunc(long key, long value, long data) {
/* 499 */     int length = C.strlen(key);
/* 500 */     byte[] keyBuffer = new byte[length];
/* 501 */     C.memmove(keyBuffer, key, length);
/* 502 */     length = C.strlen(value);
/* 503 */     byte[] valueBuffer = new byte[length];
/* 504 */     C.memmove(valueBuffer, value, length);
/* 505 */     store(keyBuffer, valueBuffer);
/* 506 */     return 0L;
/*     */   }
/*     */   
/*     */   void store(String key, int value) {
/* 510 */     store(key, String.valueOf(value));
/*     */   }
/*     */   
/*     */   void store(String key, double value) {
/* 514 */     store(key, String.valueOf(value));
/*     */   }
/*     */   
/*     */   void store(String key, boolean value) {
/* 518 */     store(key, String.valueOf(value));
/*     */   }
/*     */   
/*     */   void storeBytes(String key, long value) {
/* 522 */     int length = C.strlen(value);
/* 523 */     byte[] valueBuffer = new byte[length];
/* 524 */     C.memmove(valueBuffer, value, length);
/* 525 */     store(key.getBytes(), valueBuffer);
/*     */   }
/*     */   
/*     */   void store(String key, String value) {
/* 529 */     store(key.getBytes(), value.getBytes());
/*     */   }
/*     */   
/*     */   void store(byte[] key, byte[] value) {
/* 533 */     int length = key.length + 1 + value.length + 1;
/* 534 */     if (this.index + length + 1 > this.settingsData.length) {
/* 535 */       byte[] newData = new byte[this.settingsData.length + Math.max(length + 1, 1024)];
/* 536 */       System.arraycopy(this.settingsData, 0, newData, 0, this.settingsData.length);
/* 537 */       this.settingsData = newData;
/*     */     }
/* 539 */     System.arraycopy(key, 0, this.settingsData, this.index, key.length);
/* 540 */     this.index += key.length + 1;
/* 541 */     System.arraycopy(value, 0, this.settingsData, this.index, value.length);
/* 542 */     this.index += value.length + 1;
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/printing/PrintDialog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */