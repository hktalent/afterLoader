/*     */ package org.eclipse.swt.layout;
/*     */ 
/*     */ import org.eclipse.swt.graphics.Point;
/*     */ import org.eclipse.swt.widgets.Control;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class FormData
/*     */ {
/*  56 */   public int width = -1;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  66 */   public int height = -1;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public FormAttachment left;
/*     */   
/*     */ 
/*     */ 
/*     */   public FormAttachment right;
/*     */   
/*     */ 
/*     */ 
/*     */   public FormAttachment top;
/*     */   
/*     */ 
/*     */ 
/*     */   public FormAttachment bottom;
/*     */   
/*     */ 
/*     */ 
/*  87 */   int cacheWidth = -1; int cacheHeight = -1;
/*  88 */   int defaultWhint; int defaultHhint; int defaultWidth = -1; int defaultHeight = -1;
/*  89 */   int currentWhint; int currentHhint; int currentWidth = -1; int currentHeight = -1;
/*     */   
/*     */   FormAttachment cacheLeft;
/*     */   
/*     */   FormAttachment cacheRight;
/*     */   
/*     */   FormAttachment cacheTop;
/*     */   
/*     */   FormAttachment cacheBottom;
/*     */   
/*     */   boolean isVisited;
/*     */   
/*     */   boolean needed;
/*     */   
/*     */ 
/*     */   public FormData() {}
/*     */   
/*     */ 
/*     */   public FormData(int width, int height)
/*     */   {
/* 109 */     this.width = width;
/* 110 */     this.height = height;
/*     */   }
/*     */   
/*     */   void computeSize(Control control, int wHint, int hHint, boolean flushCache) {
/* 114 */     if ((this.cacheWidth != -1) && (this.cacheHeight != -1)) return;
/* 115 */     if ((wHint == this.width) && (hHint == this.height)) {
/* 116 */       if ((this.defaultWidth == -1) || (this.defaultHeight == -1) || (wHint != this.defaultWhint) || (hHint != this.defaultHhint)) {
/* 117 */         Point size = control.computeSize(wHint, hHint, flushCache);
/* 118 */         this.defaultWhint = wHint;
/* 119 */         this.defaultHhint = hHint;
/* 120 */         this.defaultWidth = size.x;
/* 121 */         this.defaultHeight = size.y;
/*     */       }
/* 123 */       this.cacheWidth = this.defaultWidth;
/* 124 */       this.cacheHeight = this.defaultHeight;
/* 125 */       return;
/*     */     }
/* 127 */     if ((this.currentWidth == -1) || (this.currentHeight == -1) || (wHint != this.currentWhint) || (hHint != this.currentHhint)) {
/* 128 */       Point size = control.computeSize(wHint, hHint, flushCache);
/* 129 */       this.currentWhint = wHint;
/* 130 */       this.currentHhint = hHint;
/* 131 */       this.currentWidth = size.x;
/* 132 */       this.currentHeight = size.y;
/*     */     }
/* 134 */     this.cacheWidth = this.currentWidth;
/* 135 */     this.cacheHeight = this.currentHeight;
/*     */   }
/*     */   
/*     */   void flushCache() {
/* 139 */     this.cacheWidth = (this.cacheHeight = -1);
/* 140 */     this.defaultHeight = (this.defaultWidth = -1);
/* 141 */     this.currentHeight = (this.currentWidth = -1);
/*     */   }
/*     */   
/*     */   int getWidth(Control control, boolean flushCache) {
/* 145 */     this.needed = true;
/* 146 */     computeSize(control, this.width, this.height, flushCache);
/* 147 */     return this.cacheWidth;
/*     */   }
/*     */   
/*     */   int getHeight(Control control, boolean flushCache) {
/* 151 */     computeSize(control, this.width, this.height, flushCache);
/* 152 */     return this.cacheHeight;
/*     */   }
/*     */   
/*     */   FormAttachment getBottomAttachment(Control control, int spacing, boolean flushCache) {
/* 156 */     if (this.cacheBottom != null) return this.cacheBottom;
/* 157 */     if (this.isVisited) return this.cacheBottom = new FormAttachment(0, getHeight(control, flushCache));
/* 158 */     if (this.bottom == null) {
/* 159 */       if (this.top == null) return this.cacheBottom = new FormAttachment(0, getHeight(control, flushCache));
/* 160 */       return this.cacheBottom = getTopAttachment(control, spacing, flushCache).plus(getHeight(control, flushCache));
/*     */     }
/* 162 */     Control bottomControl = this.bottom.control;
/* 163 */     if (bottomControl != null) {
/* 164 */       if (bottomControl.isDisposed()) {
/* 165 */         this.bottom.control = (bottomControl = null);
/*     */       }
/* 167 */       else if (bottomControl.getParent() != control.getParent()) {
/* 168 */         bottomControl = null;
/*     */       }
/*     */     }
/*     */     
/* 172 */     if (bottomControl == null) return this.cacheBottom = this.bottom;
/* 173 */     this.isVisited = true;
/* 174 */     FormData bottomData = (FormData)bottomControl.getLayoutData();
/* 175 */     FormAttachment bottomAttachment = bottomData.getBottomAttachment(bottomControl, spacing, flushCache);
/* 176 */     switch (this.bottom.alignment) {
/*     */     case 1024: 
/* 178 */       this.cacheBottom = bottomAttachment.plus(this.bottom.offset);
/* 179 */       break;
/*     */     case 16777216: 
/* 181 */       FormAttachment topAttachment = bottomData.getTopAttachment(bottomControl, spacing, flushCache);
/* 182 */       FormAttachment bottomHeight = bottomAttachment.minus(topAttachment);
/* 183 */       this.cacheBottom = bottomAttachment.minus(bottomHeight.minus(getHeight(control, flushCache)).divide(2));
/* 184 */       break;
/*     */     
/*     */     default: 
/* 187 */       FormAttachment topAttachment = bottomData.getTopAttachment(bottomControl, spacing, flushCache);
/* 188 */       this.cacheBottom = topAttachment.plus(this.bottom.offset - spacing);
/* 189 */       break;
/*     */     }
/*     */     
/* 192 */     this.isVisited = false;
/* 193 */     return this.cacheBottom;
/*     */   }
/*     */   
/*     */   FormAttachment getLeftAttachment(Control control, int spacing, boolean flushCache) {
/* 197 */     if (this.cacheLeft != null) return this.cacheLeft;
/* 198 */     if (this.isVisited) return this.cacheLeft = new FormAttachment(0, 0);
/* 199 */     if (this.left == null) {
/* 200 */       if (this.right == null) return this.cacheLeft = new FormAttachment(0, 0);
/* 201 */       return this.cacheLeft = getRightAttachment(control, spacing, flushCache).minus(getWidth(control, flushCache));
/*     */     }
/* 203 */     Control leftControl = this.left.control;
/* 204 */     if (leftControl != null) {
/* 205 */       if (leftControl.isDisposed()) {
/* 206 */         this.left.control = (leftControl = null);
/*     */       }
/* 208 */       else if (leftControl.getParent() != control.getParent()) {
/* 209 */         leftControl = null;
/*     */       }
/*     */     }
/*     */     
/* 213 */     if (leftControl == null) return this.cacheLeft = this.left;
/* 214 */     this.isVisited = true;
/* 215 */     FormData leftData = (FormData)leftControl.getLayoutData();
/* 216 */     FormAttachment leftAttachment = leftData.getLeftAttachment(leftControl, spacing, flushCache);
/* 217 */     switch (this.left.alignment) {
/*     */     case 16384: 
/* 219 */       this.cacheLeft = leftAttachment.plus(this.left.offset);
/* 220 */       break;
/*     */     case 16777216: 
/* 222 */       FormAttachment rightAttachment = leftData.getRightAttachment(leftControl, spacing, flushCache);
/* 223 */       FormAttachment leftWidth = rightAttachment.minus(leftAttachment);
/* 224 */       this.cacheLeft = leftAttachment.plus(leftWidth.minus(getWidth(control, flushCache)).divide(2));
/* 225 */       break;
/*     */     
/*     */     default: 
/* 228 */       FormAttachment rightAttachment = leftData.getRightAttachment(leftControl, spacing, flushCache);
/* 229 */       this.cacheLeft = rightAttachment.plus(this.left.offset + spacing);
/*     */     }
/*     */     
/* 232 */     this.isVisited = false;
/* 233 */     return this.cacheLeft;
/*     */   }
/*     */   
/*     */   String getName() {
/* 237 */     String string = getClass().getName();
/* 238 */     int index = string.lastIndexOf('.');
/* 239 */     if (index == -1) return string;
/* 240 */     return string.substring(index + 1, string.length());
/*     */   }
/*     */   
/*     */   FormAttachment getRightAttachment(Control control, int spacing, boolean flushCache) {
/* 244 */     if (this.cacheRight != null) return this.cacheRight;
/* 245 */     if (this.isVisited) return this.cacheRight = new FormAttachment(0, getWidth(control, flushCache));
/* 246 */     if (this.right == null) {
/* 247 */       if (this.left == null) return this.cacheRight = new FormAttachment(0, getWidth(control, flushCache));
/* 248 */       return this.cacheRight = getLeftAttachment(control, spacing, flushCache).plus(getWidth(control, flushCache));
/*     */     }
/* 250 */     Control rightControl = this.right.control;
/* 251 */     if (rightControl != null) {
/* 252 */       if (rightControl.isDisposed()) {
/* 253 */         this.right.control = (rightControl = null);
/*     */       }
/* 255 */       else if (rightControl.getParent() != control.getParent()) {
/* 256 */         rightControl = null;
/*     */       }
/*     */     }
/*     */     
/* 260 */     if (rightControl == null) return this.cacheRight = this.right;
/* 261 */     this.isVisited = true;
/* 262 */     FormData rightData = (FormData)rightControl.getLayoutData();
/* 263 */     FormAttachment rightAttachment = rightData.getRightAttachment(rightControl, spacing, flushCache);
/* 264 */     switch (this.right.alignment) {
/*     */     case 131072: 
/* 266 */       this.cacheRight = rightAttachment.plus(this.right.offset);
/* 267 */       break;
/*     */     case 16777216: 
/* 269 */       FormAttachment leftAttachment = rightData.getLeftAttachment(rightControl, spacing, flushCache);
/* 270 */       FormAttachment rightWidth = rightAttachment.minus(leftAttachment);
/* 271 */       this.cacheRight = rightAttachment.minus(rightWidth.minus(getWidth(control, flushCache)).divide(2));
/* 272 */       break;
/*     */     
/*     */     default: 
/* 275 */       FormAttachment leftAttachment = rightData.getLeftAttachment(rightControl, spacing, flushCache);
/* 276 */       this.cacheRight = leftAttachment.plus(this.right.offset - spacing);
/* 277 */       break;
/*     */     }
/*     */     
/* 280 */     this.isVisited = false;
/* 281 */     return this.cacheRight;
/*     */   }
/*     */   
/*     */   FormAttachment getTopAttachment(Control control, int spacing, boolean flushCache) {
/* 285 */     if (this.cacheTop != null) return this.cacheTop;
/* 286 */     if (this.isVisited) return this.cacheTop = new FormAttachment(0, 0);
/* 287 */     if (this.top == null) {
/* 288 */       if (this.bottom == null) return this.cacheTop = new FormAttachment(0, 0);
/* 289 */       return this.cacheTop = getBottomAttachment(control, spacing, flushCache).minus(getHeight(control, flushCache));
/*     */     }
/* 291 */     Control topControl = this.top.control;
/* 292 */     if (topControl != null) {
/* 293 */       if (topControl.isDisposed()) {
/* 294 */         this.top.control = (topControl = null);
/*     */       }
/* 296 */       else if (topControl.getParent() != control.getParent()) {
/* 297 */         topControl = null;
/*     */       }
/*     */     }
/*     */     
/* 301 */     if (topControl == null) return this.cacheTop = this.top;
/* 302 */     this.isVisited = true;
/* 303 */     FormData topData = (FormData)topControl.getLayoutData();
/* 304 */     FormAttachment topAttachment = topData.getTopAttachment(topControl, spacing, flushCache);
/* 305 */     switch (this.top.alignment) {
/*     */     case 128: 
/* 307 */       this.cacheTop = topAttachment.plus(this.top.offset);
/* 308 */       break;
/*     */     case 16777216: 
/* 310 */       FormAttachment bottomAttachment = topData.getBottomAttachment(topControl, spacing, flushCache);
/* 311 */       FormAttachment topHeight = bottomAttachment.minus(topAttachment);
/* 312 */       this.cacheTop = topAttachment.plus(topHeight.minus(getHeight(control, flushCache)).divide(2));
/* 313 */       break;
/*     */     
/*     */     default: 
/* 316 */       FormAttachment bottomAttachment = topData.getBottomAttachment(topControl, spacing, flushCache);
/* 317 */       this.cacheTop = bottomAttachment.plus(this.top.offset + spacing);
/* 318 */       break;
/*     */     }
/*     */     
/* 321 */     this.isVisited = false;
/* 322 */     return this.cacheTop;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 333 */     String string = getName() + " {";
/* 334 */     if (this.width != -1) string = string + "width=" + this.width + " ";
/* 335 */     if (this.height != -1) string = string + "height=" + this.height + " ";
/* 336 */     if (this.left != null) string = string + "left=" + this.left + " ";
/* 337 */     if (this.right != null) string = string + "right=" + this.right + " ";
/* 338 */     if (this.top != null) string = string + "top=" + this.top + " ";
/* 339 */     if (this.bottom != null) string = string + "bottom=" + this.bottom + " ";
/* 340 */     string = string.trim();
/* 341 */     string = string + "}";
/* 342 */     return string;
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/layout/FormData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */