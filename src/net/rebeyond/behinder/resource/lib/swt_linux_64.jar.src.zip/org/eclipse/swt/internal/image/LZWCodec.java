/*     */ package org.eclipse.swt.internal.image;
/*     */ 
/*     */ import org.eclipse.swt.graphics.ImageData;
/*     */ 
/*     */ final class LZWCodec { int bitsPerPixel;
/*     */   int blockSize;
/*     */   int blockIndex;
/*     */   int currentByte;
/*     */   int bitsLeft;
/*     */   int codeSize;
/*     */   int clearCode;
/*     */   int endCode;
/*     */   int newCodes;
/*     */   int topSlot;
/*     */   int currentSlot;
/*     */   int imageWidth;
/*     */   int imageHeight;
/*     */   int imageX;
/*     */   int imageY;
/*     */   int pass;
/*     */   int line;
/*     */   int codeMask;
/*     */   byte[] block;
/*     */   byte[] lineArray;
/*     */   int[] stack;
/*     */   int[] suffix;
/*     */   int[] prefix;
/*     */   LZWNode[] nodeStack;
/*  29 */   LEDataInputStream inputStream; LEDataOutputStream outputStream; ImageData image; org.eclipse.swt.graphics.ImageLoader loader; boolean interlaced; static final int[] MASK_TABLE = { 1, 3, 7, 15, 31, 63, 127, 255, 511, 1023, 2047, 4095 };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void decode()
/*     */   {
/*  39 */     int oc = 0;
/*  40 */     int fc = 0;
/*  41 */     byte[] buf = new byte[this.imageWidth];
/*  42 */     int stackIndex = 0;
/*  43 */     int bufIndex = 0;
/*     */     int c;
/*  45 */     while ((c = nextCode()) != this.endCode) {
/*  46 */       if (c == this.clearCode) {
/*  47 */         this.codeSize = (this.bitsPerPixel + 1);
/*  48 */         this.codeMask = MASK_TABLE[this.bitsPerPixel];
/*  49 */         this.currentSlot = this.newCodes;
/*  50 */         this.topSlot = (1 << this.codeSize);
/*  51 */         while ((c = nextCode()) == this.clearCode) {}
/*  52 */         if (c != this.endCode) {
/*  53 */           oc = fc = c;
/*  54 */           buf[bufIndex] = ((byte)c);
/*  55 */           bufIndex++;
/*  56 */           if (bufIndex == this.imageWidth) {
/*  57 */             nextPutPixels(buf);
/*  58 */             bufIndex = 0;
/*     */           }
/*     */         }
/*     */       } else {
/*  62 */         int code = c;
/*  63 */         if (code >= this.currentSlot) {
/*  64 */           code = oc;
/*  65 */           this.stack[stackIndex] = fc;
/*  66 */           stackIndex++;
/*     */         }
/*  68 */         while (code >= this.newCodes) {
/*  69 */           this.stack[stackIndex] = this.suffix[code];
/*  70 */           stackIndex++;
/*  71 */           code = this.prefix[code];
/*     */         }
/*  73 */         this.stack[stackIndex] = code;
/*  74 */         stackIndex++;
/*  75 */         if (this.currentSlot < this.topSlot) {
/*  76 */           fc = code;
/*  77 */           this.suffix[this.currentSlot] = fc;
/*  78 */           this.prefix[this.currentSlot] = oc;
/*  79 */           this.currentSlot += 1;
/*  80 */           oc = c;
/*     */         }
/*  82 */         if ((this.currentSlot >= this.topSlot) && 
/*  83 */           (this.codeSize < 12)) {
/*  84 */           this.codeMask = MASK_TABLE[this.codeSize];
/*  85 */           this.codeSize += 1;
/*  86 */           this.topSlot += this.topSlot;
/*     */         }
/*     */         
/*  89 */         while (stackIndex > 0) {
/*  90 */           stackIndex--;
/*  91 */           buf[bufIndex] = ((byte)this.stack[stackIndex]);
/*  92 */           bufIndex++;
/*  93 */           if (bufIndex == this.imageWidth) {
/*  94 */             nextPutPixels(buf);
/*  95 */             bufIndex = 0;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 100 */     if ((bufIndex != 0) && (this.line < this.imageHeight)) {
/* 101 */       nextPutPixels(buf);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void decode(LEDataInputStream inputStream, org.eclipse.swt.graphics.ImageLoader loader, ImageData image, boolean interlaced, int depth)
/*     */   {
/* 109 */     this.inputStream = inputStream;
/* 110 */     this.loader = loader;
/* 111 */     this.image = image;
/* 112 */     this.interlaced = interlaced;
/* 113 */     this.bitsPerPixel = depth;
/* 114 */     initializeForDecoding();
/* 115 */     decode();
/*     */   }
/*     */   
/*     */ 
/*     */   void encode()
/*     */   {
/* 121 */     nextPutCode(this.clearCode);
/* 122 */     int lastPrefix = encodeLoop();
/* 123 */     nextPutCode(lastPrefix);
/* 124 */     nextPutCode(this.endCode);
/*     */     
/*     */ 
/* 127 */     if (this.bitsLeft == 8) {
/* 128 */       this.block[0] = ((byte)(this.blockIndex - 1));
/*     */     } else {
/* 130 */       this.block[0] = ((byte)this.blockIndex);
/*     */     }
/* 132 */     writeBlock();
/*     */     
/*     */ 
/* 135 */     if (this.block[0] != 0) {
/* 136 */       this.block[0] = 0;
/* 137 */       writeBlock();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void encode(LEDataOutputStream byteStream, ImageData image)
/*     */   {
/* 145 */     this.outputStream = byteStream;
/* 146 */     this.image = image;
/* 147 */     initializeForEncoding();
/* 148 */     encode();
/*     */   }
/*     */   
/*     */ 
/*     */   int encodeLoop()
/*     */   {
/* 154 */     int pixel = nextPixel();
/*     */     
/*     */     for (;;)
/*     */     {
/* 158 */       int currentPrefix = pixel;
/* 159 */       LZWNode node = this.nodeStack[currentPrefix];
/* 160 */       boolean found = true;
/* 161 */       pixel = nextPixel();
/* 162 */       if (pixel < 0)
/* 163 */         return currentPrefix;
/* 164 */       while ((found) && (node.children != null)) {
/* 165 */         node = node.children;
/* 166 */         while ((found) && (node.suffix != pixel)) {
/* 167 */           if (pixel < node.suffix) {
/* 168 */             if (node.left == null) {
/* 169 */               node.left = new LZWNode();
/* 170 */               found = false;
/*     */             }
/* 172 */             node = node.left;
/*     */           } else {
/* 174 */             if (node.right == null) {
/* 175 */               node.right = new LZWNode();
/* 176 */               found = false;
/*     */             }
/* 178 */             node = node.right;
/*     */           }
/*     */         }
/* 181 */         if (found) {
/* 182 */           currentPrefix = node.code;
/* 183 */           pixel = nextPixel();
/* 184 */           if (pixel < 0)
/* 185 */             return currentPrefix;
/*     */         }
/*     */       }
/* 188 */       if (found) {
/* 189 */         node.children = new LZWNode();
/* 190 */         node = node.children;
/*     */       }
/* 192 */       node.children = null;
/* 193 */       node.left = null;
/* 194 */       node.right = null;
/* 195 */       node.code = this.currentSlot;
/* 196 */       node.prefix = currentPrefix;
/* 197 */       node.suffix = pixel;
/* 198 */       nextPutCode(currentPrefix);
/* 199 */       this.currentSlot += 1;
/*     */       
/* 201 */       if (this.currentSlot < 4096) {
/* 202 */         if (this.currentSlot > this.topSlot) {
/* 203 */           this.codeSize += 1;
/* 204 */           this.codeMask = MASK_TABLE[(this.codeSize - 1)];
/* 205 */           this.topSlot *= 2;
/*     */         }
/*     */       } else {
/* 208 */         nextPutCode(this.clearCode);
/* 209 */         for (int i = 0; i < this.nodeStack.length; i++)
/* 210 */           this.nodeStack[i].children = null;
/* 211 */         this.codeSize = (this.bitsPerPixel + 1);
/* 212 */         this.codeMask = MASK_TABLE[(this.codeSize - 1)];
/* 213 */         this.currentSlot = this.newCodes;
/* 214 */         this.topSlot = (1 << this.codeSize);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   void initializeForDecoding()
/*     */   {
/* 223 */     this.pass = 1;
/* 224 */     this.line = 0;
/* 225 */     this.codeSize = (this.bitsPerPixel + 1);
/* 226 */     this.topSlot = (1 << this.codeSize);
/* 227 */     this.clearCode = (1 << this.bitsPerPixel);
/* 228 */     this.endCode = (this.clearCode + 1);
/* 229 */     this.newCodes = (this.currentSlot = this.endCode + 1);
/* 230 */     this.currentByte = -1;
/* 231 */     this.blockSize = (this.bitsLeft = 0);
/* 232 */     this.blockIndex = 0;
/* 233 */     this.codeMask = MASK_TABLE[(this.codeSize - 1)];
/* 234 */     this.stack = new int['က'];
/* 235 */     this.suffix = new int['က'];
/* 236 */     this.prefix = new int['က'];
/* 237 */     this.block = new byte['Ā'];
/* 238 */     this.imageWidth = this.image.width;
/* 239 */     this.imageHeight = this.image.height;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   void initializeForEncoding()
/*     */   {
/* 246 */     this.interlaced = false;
/* 247 */     this.bitsPerPixel = this.image.depth;
/* 248 */     this.codeSize = (this.bitsPerPixel + 1);
/* 249 */     this.topSlot = (1 << this.codeSize);
/* 250 */     this.clearCode = (1 << this.bitsPerPixel);
/* 251 */     this.endCode = (this.clearCode + 1);
/* 252 */     this.newCodes = (this.currentSlot = this.endCode + 1);
/* 253 */     this.bitsLeft = 8;
/* 254 */     this.currentByte = 0;
/* 255 */     this.blockIndex = 1;
/* 256 */     this.blockSize = 255;
/* 257 */     this.block = new byte[this.blockSize];
/* 258 */     this.block[0] = ((byte)(this.blockSize - 1));
/* 259 */     this.nodeStack = new LZWNode[1 << this.bitsPerPixel];
/* 260 */     for (int i = 0; i < this.nodeStack.length; i++) {
/* 261 */       LZWNode node = new LZWNode();
/* 262 */       node.code = (i + 1);
/* 263 */       node.prefix = -1;
/* 264 */       node.suffix = (i + 1);
/* 265 */       this.nodeStack[i] = node;
/*     */     }
/* 267 */     this.imageWidth = this.image.width;
/* 268 */     this.imageHeight = this.image.height;
/* 269 */     this.imageY = -1;
/* 270 */     this.lineArray = new byte[this.imageWidth];
/* 271 */     this.imageX = (this.imageWidth + 1);
/*     */   }
/*     */   
/*     */   int nextCode()
/*     */   {
/*     */     int code;
/*     */     int code;
/* 278 */     if (this.bitsLeft == 0) {
/* 279 */       if (this.blockIndex >= this.blockSize) {
/* 280 */         this.blockSize = readBlock();
/* 281 */         this.blockIndex = 0;
/* 282 */         if (this.blockSize == 0) return this.endCode;
/*     */       }
/* 284 */       this.blockIndex += 1;
/* 285 */       this.currentByte = (this.block[this.blockIndex] & 0xFF);
/* 286 */       this.bitsLeft = 8;
/* 287 */       code = this.currentByte;
/*     */     } else {
/* 289 */       int shift = this.bitsLeft - 8;
/* 290 */       int code; if (shift < 0) {
/* 291 */         code = this.currentByte >> 0 - shift;
/*     */       } else
/* 293 */         code = this.currentByte << shift;
/*     */     }
/* 295 */     while (this.codeSize > this.bitsLeft) {
/* 296 */       if (this.blockIndex >= this.blockSize) {
/* 297 */         this.blockSize = readBlock();
/* 298 */         this.blockIndex = 0;
/* 299 */         if (this.blockSize == 0) return this.endCode;
/*     */       }
/* 301 */       this.blockIndex += 1;
/* 302 */       this.currentByte = (this.block[this.blockIndex] & 0xFF);
/* 303 */       code += (this.currentByte << this.bitsLeft);
/* 304 */       this.bitsLeft += 8;
/*     */     }
/* 306 */     this.bitsLeft -= this.codeSize;
/* 307 */     return code & this.codeMask;
/*     */   }
/*     */   
/*     */ 
/*     */   int nextPixel()
/*     */   {
/* 313 */     this.imageX += 1;
/* 314 */     if (this.imageX > this.imageWidth) {
/* 315 */       this.imageY += 1;
/* 316 */       if (this.imageY >= this.imageHeight) {
/* 317 */         return -1;
/*     */       }
/* 319 */       nextPixels(this.lineArray, this.imageWidth);
/*     */       
/* 321 */       this.imageX = 1;
/*     */     }
/* 323 */     return this.lineArray[(this.imageX - 1)] & 0xFF;
/*     */   }
/*     */   
/*     */ 
/*     */   void nextPixels(byte[] buf, int lineWidth)
/*     */   {
/* 329 */     if (this.image.depth == 8) {
/* 330 */       System.arraycopy(this.image.data, this.imageY * this.image.bytesPerLine, buf, 0, lineWidth);
/*     */     } else {
/* 332 */       this.image.getPixels(0, this.imageY, lineWidth, buf, 0);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   void nextPutCode(int aCode)
/*     */   {
/* 339 */     int codeToDo = aCode;
/* 340 */     int codeBitsToDo = this.codeSize;
/*     */     
/*     */ 
/* 343 */     int c = codeToDo & MASK_TABLE[(this.bitsLeft - 1)];
/* 344 */     this.currentByte |= c << 8 - this.bitsLeft;
/* 345 */     this.block[this.blockIndex] = ((byte)this.currentByte);
/* 346 */     codeBitsToDo -= this.bitsLeft;
/* 347 */     if (codeBitsToDo < 1)
/*     */     {
/* 349 */       this.bitsLeft -= this.codeSize;
/* 350 */       if (this.bitsLeft == 0)
/*     */       {
/*     */ 
/* 353 */         this.bitsLeft = 8;
/* 354 */         this.blockIndex += 1;
/* 355 */         if (this.blockIndex >= this.blockSize) {
/* 356 */           writeBlock();
/* 357 */           this.blockIndex = 1;
/*     */         }
/* 359 */         this.currentByte = 0;
/*     */       }
/* 361 */       return;
/*     */     }
/* 363 */     codeToDo >>= this.bitsLeft;
/*     */     
/*     */ 
/* 366 */     this.blockIndex += 1;
/* 367 */     if (this.blockIndex >= this.blockSize) {
/* 368 */       writeBlock();
/* 369 */       this.blockIndex = 1;
/*     */     }
/* 371 */     while (codeBitsToDo >= 8) {
/* 372 */       this.currentByte = (codeToDo & 0xFF);
/* 373 */       this.block[this.blockIndex] = ((byte)this.currentByte);
/* 374 */       codeToDo >>= 8;
/* 375 */       codeBitsToDo -= 8;
/* 376 */       this.blockIndex += 1;
/* 377 */       if (this.blockIndex >= this.blockSize) {
/* 378 */         writeBlock();
/* 379 */         this.blockIndex = 1;
/*     */       }
/*     */     }
/*     */     
/* 383 */     this.bitsLeft = (8 - codeBitsToDo);
/* 384 */     this.currentByte = codeToDo;
/* 385 */     this.block[this.blockIndex] = ((byte)this.currentByte);
/*     */   }
/*     */   
/*     */ 
/*     */   void nextPutPixels(byte[] buf)
/*     */   {
/* 391 */     if (this.image.depth == 8)
/*     */     {
/* 393 */       int start = this.line * this.image.bytesPerLine;
/* 394 */       for (int i = 0; i < this.imageWidth; i++)
/* 395 */         this.image.data[(start + i)] = buf[i];
/*     */     } else {
/* 397 */       this.image.setPixels(0, this.line, this.imageWidth, buf, 0);
/*     */     }
/* 399 */     if (this.interlaced) {
/* 400 */       if (this.pass == 1) {
/* 401 */         copyRow(buf, 7);
/* 402 */         this.line += 8;
/* 403 */       } else if (this.pass == 2) {
/* 404 */         copyRow(buf, 3);
/* 405 */         this.line += 8;
/* 406 */       } else if (this.pass == 3) {
/* 407 */         copyRow(buf, 1);
/* 408 */         this.line += 4;
/* 409 */       } else if (this.pass == 4) {
/* 410 */         this.line += 2;
/* 411 */       } else if (this.pass == 5) {
/* 412 */         this.line += 0;
/*     */       }
/* 414 */       if (this.line >= this.imageHeight) {
/* 415 */         this.pass += 1;
/* 416 */         if (this.pass == 2) { this.line = 4;
/* 417 */         } else if (this.pass == 3) { this.line = 2;
/* 418 */         } else if (this.pass == 4) { this.line = 1;
/* 419 */         } else if (this.pass == 5) this.line = 0;
/* 420 */         if ((this.pass < 5) && 
/* 421 */           (this.loader.hasListeners())) {
/* 422 */           ImageData imageCopy = (ImageData)this.image.clone();
/* 423 */           this.loader.notifyListeners(new org.eclipse.swt.graphics.ImageLoaderEvent(this.loader, imageCopy, this.pass - 2, false));
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 428 */       if (this.line >= this.imageHeight) this.line = 0;
/*     */     } else {
/* 430 */       this.line += 1;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   void copyRow(byte[] buf, int copies)
/*     */   {
/* 438 */     for (int i = 1; i <= copies; i++) {
/* 439 */       if (this.line + i < this.imageHeight) {
/* 440 */         this.image.setPixels(0, this.line + i, this.imageWidth, buf, 0);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   int readBlock()
/*     */   {
/* 450 */     int size = -1;
/*     */     try {
/* 452 */       size = this.inputStream.read();
/* 453 */       if (size == -1) {
/* 454 */         org.eclipse.swt.SWT.error(40);
/*     */       }
/* 456 */       this.block[0] = ((byte)size);
/* 457 */       size = this.inputStream.read(this.block, 1, size);
/* 458 */       if (size == -1) {
/* 459 */         org.eclipse.swt.SWT.error(40);
/*     */       }
/*     */     } catch (Exception e) {
/* 462 */       org.eclipse.swt.SWT.error(39, e);
/*     */     }
/* 464 */     return size;
/*     */   }
/*     */   
/*     */ 
/*     */   void writeBlock()
/*     */   {
/*     */     try
/*     */     {
/* 472 */       this.outputStream.write(this.block, 0, (this.block[0] & 0xFF) + 1);
/*     */     } catch (Exception e) {
/* 474 */       org.eclipse.swt.SWT.error(39, e);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/internal/image/LZWCodec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */