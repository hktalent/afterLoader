/*    */ package org.eclipse.swt.internal.image;
/*    */ 
/*    */ import org.eclipse.swt.SWT;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PngChunkReader
/*    */ {
/*    */   LEDataInputStream inputStream;
/*    */   PngFileReadState readState;
/*    */   PngIhdrChunk headerChunk;
/*    */   PngPlteChunk paletteChunk;
/*    */   
/*    */   PngChunkReader(LEDataInputStream inputStream)
/*    */   {
/* 23 */     this.inputStream = inputStream;
/* 24 */     this.readState = new PngFileReadState();
/* 25 */     this.headerChunk = null;
/*    */   }
/*    */   
/*    */   PngIhdrChunk getIhdrChunk() {
/* 29 */     if (this.headerChunk == null) {
/*    */       try {
/* 31 */         PngChunk chunk = PngChunk.readNextFromStream(this.inputStream);
/* 32 */         if (chunk == null) SWT.error(40);
/* 33 */         this.headerChunk = ((PngIhdrChunk)chunk);
/* 34 */         this.headerChunk.validate(this.readState, null);
/*    */       } catch (ClassCastException e) {
/* 36 */         SWT.error(40);
/*    */       }
/*    */     }
/* 39 */     return this.headerChunk;
/*    */   }
/*    */   
/*    */   PngChunk readNextChunk() {
/* 43 */     if (this.headerChunk == null) { return getIhdrChunk();
/*    */     }
/* 45 */     PngChunk chunk = PngChunk.readNextFromStream(this.inputStream);
/* 46 */     if (chunk == null) SWT.error(40);
/* 47 */     switch (chunk.getChunkType()) {
/*    */     case 5: 
/* 49 */       ((PngTrnsChunk)chunk).validate(this.readState, this.headerChunk, this.paletteChunk);
/* 50 */       break;
/*    */     case 1: 
/* 52 */       chunk.validate(this.readState, this.headerChunk);
/* 53 */       this.paletteChunk = ((PngPlteChunk)chunk);
/* 54 */       break;
/*    */     default: 
/* 56 */       chunk.validate(this.readState, this.headerChunk);
/*    */     }
/* 58 */     if ((this.readState.readIDAT) && (chunk.getChunkType() != 2)) {
/* 59 */       this.readState.readPixelData = true;
/*    */     }
/* 61 */     return chunk;
/*    */   }
/*    */   
/*    */   boolean readPixelData() {
/* 65 */     return this.readState.readPixelData;
/*    */   }
/*    */   
/*    */   boolean hasMoreChunks() {
/* 69 */     return !this.readState.readIEND;
/*    */   }
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/internal/image/PngChunkReader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */