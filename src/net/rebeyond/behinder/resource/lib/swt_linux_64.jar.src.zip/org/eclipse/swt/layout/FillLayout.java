/*     */ package org.eclipse.swt.layout;
/*     */ 
/*     */ import org.eclipse.swt.graphics.Point;
/*     */ import org.eclipse.swt.graphics.Rectangle;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.swt.widgets.Control;
/*     */ import org.eclipse.swt.widgets.Layout;
/*     */ import org.eclipse.swt.widgets.Scrollable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class FillLayout
/*     */   extends Layout
/*     */ {
/*  58 */   public int type = 256;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  68 */   public int marginWidth = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  78 */   public int marginHeight = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  88 */   public int spacing = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FillLayout() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FillLayout(int type)
/*     */   {
/* 104 */     this.type = type;
/*     */   }
/*     */   
/*     */   protected Point computeSize(Composite composite, int wHint, int hHint, boolean flushCache)
/*     */   {
/* 109 */     Control[] children = composite.getChildren();
/* 110 */     int count = children.length;
/* 111 */     int maxWidth = 0;int maxHeight = 0;
/* 112 */     for (int i = 0; i < count; i++) {
/* 113 */       Control child = children[i];
/* 114 */       int w = wHint;int h = hHint;
/* 115 */       if (count > 0) {
/* 116 */         if ((this.type == 256) && (wHint != -1)) {
/* 117 */           w = Math.max(0, (wHint - (count - 1) * this.spacing) / count);
/*     */         }
/* 119 */         if ((this.type == 512) && (hHint != -1)) {
/* 120 */           h = Math.max(0, (hHint - (count - 1) * this.spacing) / count);
/*     */         }
/*     */       }
/* 123 */       Point size = computeChildSize(child, w, h, flushCache);
/* 124 */       maxWidth = Math.max(maxWidth, size.x);
/* 125 */       maxHeight = Math.max(maxHeight, size.y);
/*     */     }
/* 127 */     int width = 0;int height = 0;
/* 128 */     if (this.type == 256) {
/* 129 */       width = count * maxWidth;
/* 130 */       if (count != 0) width += (count - 1) * this.spacing;
/* 131 */       height = maxHeight;
/*     */     } else {
/* 133 */       width = maxWidth;
/* 134 */       height = count * maxHeight;
/* 135 */       if (count != 0) height += (count - 1) * this.spacing;
/*     */     }
/* 137 */     width += this.marginWidth * 2;
/* 138 */     height += this.marginHeight * 2;
/* 139 */     if (wHint != -1) width = wHint;
/* 140 */     if (hHint != -1) height = hHint;
/* 141 */     return new Point(width, height);
/*     */   }
/*     */   
/*     */   Point computeChildSize(Control control, int wHint, int hHint, boolean flushCache) {
/* 145 */     FillData data = (FillData)control.getLayoutData();
/* 146 */     if (data == null) {
/* 147 */       data = new FillData();
/* 148 */       control.setLayoutData(data);
/*     */     }
/* 150 */     Point size = null;
/* 151 */     if ((wHint == -1) && (hHint == -1)) {
/* 152 */       size = data.computeSize(control, wHint, hHint, flushCache);
/*     */     } else { int trimY;
/*     */       int trimY;
/*     */       int trimX;
/* 156 */       if ((control instanceof Scrollable)) {
/* 157 */         Rectangle rect = ((Scrollable)control).computeTrim(0, 0, 0, 0);
/* 158 */         int trimX = rect.width;
/* 159 */         trimY = rect.height;
/*     */       } else {
/* 161 */         trimX = trimY = control.getBorderWidth() * 2;
/*     */       }
/* 163 */       int w = wHint == -1 ? wHint : Math.max(0, wHint - trimX);
/* 164 */       int h = hHint == -1 ? hHint : Math.max(0, hHint - trimY);
/* 165 */       size = data.computeSize(control, w, h, flushCache);
/*     */     }
/* 167 */     return size;
/*     */   }
/*     */   
/*     */   protected boolean flushCache(Control control)
/*     */   {
/* 172 */     Object data = control.getLayoutData();
/* 173 */     if (data != null) ((FillData)data).flushCache();
/* 174 */     return true;
/*     */   }
/*     */   
/*     */   String getName() {
/* 178 */     String string = getClass().getName();
/* 179 */     int index = string.lastIndexOf('.');
/* 180 */     if (index == -1) return string;
/* 181 */     return string.substring(index + 1, string.length());
/*     */   }
/*     */   
/*     */   protected void layout(Composite composite, boolean flushCache)
/*     */   {
/* 186 */     Rectangle rect = composite.getClientArea();
/* 187 */     Control[] children = composite.getChildren();
/* 188 */     int count = children.length;
/* 189 */     if (count == 0) return;
/* 190 */     int width = rect.width - this.marginWidth * 2;
/* 191 */     int height = rect.height - this.marginHeight * 2;
/* 192 */     if (this.type == 256) {
/* 193 */       width -= (count - 1) * this.spacing;
/* 194 */       int x = rect.x + this.marginWidth;int extra = width % count;
/* 195 */       int y = rect.y + this.marginHeight;int cellWidth = width / count;
/* 196 */       for (int i = 0; i < count; i++) {
/* 197 */         Control child = children[i];
/* 198 */         int childWidth = cellWidth;
/* 199 */         if (i == 0) {
/* 200 */           childWidth += extra / 2;
/*     */         }
/* 202 */         else if (i == count - 1) { childWidth += (extra + 1) / 2;
/*     */         }
/* 204 */         child.setBounds(x, y, childWidth, height);
/* 205 */         x += childWidth + this.spacing;
/*     */       }
/*     */     } else {
/* 208 */       height -= (count - 1) * this.spacing;
/* 209 */       int x = rect.x + this.marginWidth;int cellHeight = height / count;
/* 210 */       int y = rect.y + this.marginHeight;int extra = height % count;
/* 211 */       for (int i = 0; i < count; i++) {
/* 212 */         Control child = children[i];
/* 213 */         int childHeight = cellHeight;
/* 214 */         if (i == 0) {
/* 215 */           childHeight += extra / 2;
/*     */         }
/* 217 */         else if (i == count - 1) { childHeight += (extra + 1) / 2;
/*     */         }
/* 219 */         child.setBounds(x, y, width, childHeight);
/* 220 */         y += childHeight + this.spacing;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 233 */     String string = getName() + " {";
/* 234 */     string = string + "type=" + (this.type == 512 ? "SWT.VERTICAL" : "SWT.HORIZONTAL") + " ";
/* 235 */     if (this.marginWidth != 0) string = string + "marginWidth=" + this.marginWidth + " ";
/* 236 */     if (this.marginHeight != 0) string = string + "marginHeight=" + this.marginHeight + " ";
/* 237 */     if (this.spacing != 0) string = string + "spacing=" + this.spacing + " ";
/* 238 */     string = string.trim();
/* 239 */     string = string + "}";
/* 240 */     return string;
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/layout/FillLayout.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */