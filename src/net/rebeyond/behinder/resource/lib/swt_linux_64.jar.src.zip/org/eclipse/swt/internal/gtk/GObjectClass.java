package org.eclipse.swt.internal.gtk;

public class GObjectClass
{
  public long constructor;
  public long set_property;
  public long get_property;
  public long dispose;
  public long finalize;
  public long dispatch_properties_changed;
  public long notify;
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/internal/gtk/GObjectClass.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */