/*      */ package org.eclipse.swt.widgets;
/*      */ 
/*      */ import org.eclipse.swt.events.ControlListener;
/*      */ import org.eclipse.swt.events.KeyListener;
/*      */ import org.eclipse.swt.graphics.Cursor;
/*      */ import org.eclipse.swt.graphics.Point;
/*      */ import org.eclipse.swt.graphics.Rectangle;
/*      */ import org.eclipse.swt.internal.Converter;
/*      */ import org.eclipse.swt.internal.DPIUtil;
/*      */ import org.eclipse.swt.internal.gtk.GDK;
/*      */ import org.eclipse.swt.internal.gtk.GTK;
/*      */ import org.eclipse.swt.internal.gtk.GdkColor;
/*      */ import org.eclipse.swt.internal.gtk.GdkEvent;
/*      */ import org.eclipse.swt.internal.gtk.GdkEventKey;
/*      */ import org.eclipse.swt.internal.gtk.GdkRGBA;
/*      */ import org.eclipse.swt.internal.gtk.GdkRectangle;
/*      */ import org.eclipse.swt.internal.gtk.OS;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class Tracker
/*      */   extends Widget
/*      */ {
/*   48 */   Rectangle[] rectangles = new Rectangle[0]; Rectangle[] proportions = this.rectangles;
/*      */   
/*   50 */   int cursorOrientation = 0;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*   55 */   Rectangle cachedCombinedDisplayResolution = Display.getDefault().getBounds();
/*   56 */   Rectangle cachedUnion = new Rectangle(0, 0, 0, 0);
/*      */   
/*      */ 
/*      */   Composite parent;
/*      */   
/*      */ 
/*      */   Cursor cursor;
/*      */   
/*      */   long lastCursor;
/*      */   
/*      */   long window;
/*      */   
/*      */   long overlay;
/*      */   
/*      */   boolean tracking;
/*      */   
/*      */   boolean cancelled;
/*      */   
/*      */   boolean grabbed;
/*      */   
/*      */   boolean stippled;
/*      */   
/*      */   Rectangle bounds;
/*      */   
/*      */   int oldX;
/*      */   
/*      */   int oldY;
/*      */   
/*      */   long provider;
/*      */   
/*      */   Boolean cachedBackgroundIsOpaque;
/*      */   
/*      */   static final int STEPSIZE_SMALL = 1;
/*      */   
/*      */   static final int STEPSIZE_LARGE = 9;
/*      */   
/*      */ 
/*      */   public Tracker(Composite parent, int style)
/*      */   {
/*   95 */     super(parent, checkStyle(style));
/*   96 */     this.parent = parent;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Tracker(Display display, int style)
/*      */   {
/*  135 */     if (display == null) display = Display.getCurrent();
/*  136 */     if (display == null) display = Display.getDefault();
/*  137 */     if (!display.isValidThread()) {
/*  138 */       error(22);
/*      */     }
/*  140 */     this.style = checkStyle(style);
/*  141 */     this.display = display;
/*  142 */     reskinWidget();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addControlListener(ControlListener listener)
/*      */   {
/*  165 */     checkWidget();
/*  166 */     if (listener == null) error(4);
/*  167 */     TypedListener typedListener = new TypedListener(listener);
/*  168 */     addListener(11, typedListener);
/*  169 */     addListener(10, typedListener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addKeyListener(KeyListener listener)
/*      */   {
/*  192 */     checkWidget();
/*  193 */     if (listener == null) error(4);
/*  194 */     TypedListener typedListener = new TypedListener(listener);
/*  195 */     addListener(2, typedListener);
/*  196 */     addListener(1, typedListener);
/*      */   }
/*      */   
/*      */   Point adjustMoveCursor() {
/*  200 */     if (this.bounds == null) return null;
/*  201 */     int newX = this.bounds.x + this.bounds.width / 2;
/*  202 */     int newY = this.bounds.y;
/*      */     
/*  204 */     Point point = this.display.mapInPixels(this.parent, null, newX, newY);
/*  205 */     this.display.setCursorLocation(point);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  212 */     int[] actualX = new int[1];int[] actualY = new int[1];int[] state = new int[1];
/*  213 */     gdk_window_get_device_position(this.window, actualX, actualY, state);
/*  214 */     return new Point(actualX[0], actualY[0]);
/*      */   }
/*      */   
/*      */   Point adjustResizeCursor() {
/*  218 */     if (this.bounds == null) return null;
/*      */     int newX;
/*      */     int newX;
/*  221 */     if ((this.cursorOrientation & 0x4000) != 0) {
/*  222 */       newX = this.bounds.x; } else { int newX;
/*  223 */       if ((this.cursorOrientation & 0x20000) != 0) {
/*  224 */         newX = this.bounds.x + this.bounds.width;
/*      */       } else
/*  226 */         newX = this.bounds.x + this.bounds.width / 2; }
/*      */     int newY;
/*      */     int newY;
/*  229 */     if ((this.cursorOrientation & 0x80) != 0) {
/*  230 */       newY = this.bounds.y; } else { int newY;
/*  231 */       if ((this.cursorOrientation & 0x400) != 0) {
/*  232 */         newY = this.bounds.y + this.bounds.height;
/*      */       } else {
/*  234 */         newY = this.bounds.y + this.bounds.height / 2;
/*      */       }
/*      */     }
/*  237 */     Point point = this.display.mapInPixels(this.parent, null, newX, newY);
/*  238 */     this.display.setCursorLocation(point);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  245 */     int[] actualX = new int[1];int[] actualY = new int[1];int[] state = new int[1];
/*  246 */     gdk_window_get_device_position(this.window, actualX, actualY, state);
/*  247 */     return new Point(actualX[0], actualY[0]);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void close()
/*      */   {
/*  261 */     checkWidget();
/*  262 */     this.tracking = false;
/*      */   }
/*      */   
/*      */   static int checkStyle(int style) {
/*  266 */     if ((style & 0x24480) == 0) {
/*  267 */       style |= 0x24480;
/*      */     }
/*  269 */     return style;
/*      */   }
/*      */   
/*      */   Rectangle computeBounds() {
/*  273 */     if (this.rectangles.length == 0) return null;
/*  274 */     int xMin = this.rectangles[0].x;
/*  275 */     int yMin = this.rectangles[0].y;
/*  276 */     int xMax = this.rectangles[0].x + this.rectangles[0].width;
/*  277 */     int yMax = this.rectangles[0].y + this.rectangles[0].height;
/*      */     
/*  279 */     for (int i = 1; i < this.rectangles.length; i++) {
/*  280 */       if (this.rectangles[i].x < xMin) xMin = this.rectangles[i].x;
/*  281 */       if (this.rectangles[i].y < yMin) yMin = this.rectangles[i].y;
/*  282 */       int rectRight = this.rectangles[i].x + this.rectangles[i].width;
/*  283 */       if (rectRight > xMax) xMax = rectRight;
/*  284 */       int rectBottom = this.rectangles[i].y + this.rectangles[i].height;
/*  285 */       if (rectBottom > yMax) { yMax = rectBottom;
/*      */       }
/*      */     }
/*  288 */     return new Rectangle(xMin, yMin, xMax - xMin, yMax - yMin);
/*      */   }
/*      */   
/*      */   Rectangle[] computeProportions(Rectangle[] rects) {
/*  292 */     Rectangle[] result = new Rectangle[rects.length];
/*  293 */     this.bounds = computeBounds();
/*  294 */     if (this.bounds != null) {
/*  295 */       for (int i = 0; i < rects.length; i++) {
/*  296 */         int x = 0;int y = 0;int width = 0;int height = 0;
/*  297 */         if (this.bounds.width != 0) {
/*  298 */           x = (rects[i].x - this.bounds.x) * 100 / this.bounds.width;
/*  299 */           width = rects[i].width * 100 / this.bounds.width;
/*      */         } else {
/*  301 */           width = 100;
/*      */         }
/*  303 */         if (this.bounds.height != 0) {
/*  304 */           y = (rects[i].y - this.bounds.y) * 100 / this.bounds.height;
/*  305 */           height = rects[i].height * 100 / this.bounds.height;
/*      */         } else {
/*  307 */           height = 100;
/*      */         }
/*  309 */         result[i] = new Rectangle(x, y, width, height);
/*      */       }
/*      */     }
/*  312 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void drawRectangles(Rectangle[] rects)
/*      */   {
/*  324 */     long window = GDK.gdk_get_default_root_window();
/*  325 */     if (this.parent != null) {
/*  326 */       window = gtk_widget_get_window(this.parent.paintHandle());
/*      */     }
/*  328 */     if (window == 0L) return;
/*  329 */     if (GTK.GTK3) {
/*  330 */       if (this.overlay == 0L) return;
/*  331 */       GTK.gtk_widget_shape_combine_region(this.overlay, 0L);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  338 */       boolean isOnScreen = true;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  343 */       this.cachedUnion.x = rects[0].x;
/*  344 */       this.cachedUnion.y = rects[0].y;
/*  345 */       this.cachedUnion.width = rects[0].width;
/*  346 */       this.cachedUnion.height = rects[0].height;
/*  347 */       if (rects.length > 1) {
/*  348 */         for (int i = 1; i < rects.length; i++) {
/*  349 */           this.cachedUnion.add(rects[i]);
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*  354 */       if (this.parent != null) {
/*  355 */         this.cachedUnion = this.display.mapInPixels(this.parent, null, this.cachedUnion);
/*      */       }
/*      */       
/*  358 */       if (!this.cachedCombinedDisplayResolution.intersects(this.cachedUnion)) {
/*  359 */         isOnScreen = false;
/*      */       }
/*      */       
/*      */ 
/*  363 */       long region = GDK.gdk_region_new();
/*  364 */       GdkRectangle rect = new GdkRectangle();
/*  365 */       if (isOnScreen)
/*      */       {
/*  367 */         for (int i = 0; i < rects.length; i++)
/*      */         {
/*  369 */           Rectangle r = this.parent != null ? this.display.mapInPixels(this.parent, null, rects[i]) : rects[i];
/*  370 */           rect.x = r.x;
/*  371 */           rect.y = r.y;
/*  372 */           rect.width = (r.width + 1);
/*  373 */           rect.height = 1;
/*  374 */           GDK.gdk_region_union_with_rect(region, rect);
/*  375 */           rect.width = 1;
/*  376 */           rect.height = (r.height + 1);
/*  377 */           GDK.gdk_region_union_with_rect(region, rect);
/*  378 */           rect.x = (r.x + r.width);
/*  379 */           GDK.gdk_region_union_with_rect(region, rect);
/*  380 */           rect.x = r.x;
/*  381 */           rect.y = (r.y + r.height);
/*  382 */           rect.width = (r.width + 1);
/*  383 */           rect.height = 1;
/*  384 */           GDK.gdk_region_union_with_rect(region, rect);
/*      */         }
/*  386 */         setTrackerBackground(true);
/*      */       }
/*      */       else {
/*  389 */         rect.x = 0;
/*  390 */         rect.y = 0;
/*  391 */         rect.height = 1;
/*  392 */         rect.width = 1;
/*  393 */         GDK.gdk_region_union_with_rect(region, rect);
/*  394 */         setTrackerBackground(false);
/*      */       }
/*      */       
/*  397 */       GTK.gtk_widget_shape_combine_region(this.overlay, region);
/*  398 */       GDK.gdk_region_destroy(region);
/*  399 */       long overlayWindow = GTK.gtk_widget_get_window(this.overlay);
/*  400 */       GDK.gdk_window_hide(overlayWindow);
/*  401 */       GDK.gdk_window_show(overlayWindow);
/*      */     } else {
/*  403 */       long gc = GDK.gdk_gc_new(window);
/*  404 */       if (gc == 0L) return;
/*  405 */       long colormap = GDK.gdk_colormap_get_system();
/*  406 */       GdkColor color = new GdkColor();
/*  407 */       GDK.gdk_color_white(colormap, color);
/*  408 */       GDK.gdk_gc_set_foreground(gc, color);
/*  409 */       GDK.gdk_gc_set_subwindow(gc, 1L);
/*  410 */       GDK.gdk_gc_set_function(gc, 2L);
/*  411 */       for (int i = 0; i < rects.length; i++) {
/*  412 */         Rectangle rect = rects[i];
/*  413 */         int x = rect.x;
/*  414 */         if ((this.parent != null) && ((this.parent.style & 0x8000000) != 0)) x = this.parent.getClientWidth() - rect.width - x;
/*  415 */         GDK.gdk_draw_rectangle(window, gc, 0, x, rect.y, rect.width, rect.height);
/*      */       }
/*  417 */       OS.g_object_unref(gc);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Rectangle[] getRectangles()
/*      */   {
/*  434 */     checkWidget();
/*  435 */     Rectangle[] result = new Rectangle[this.rectangles.length];
/*  436 */     for (int i = 0; i < this.rectangles.length; i++) {
/*  437 */       Rectangle current = this.rectangles[i];
/*  438 */       result[i] = DPIUtil.autoScaleDown(new Rectangle(current.x, current.y, current.width, current.height));
/*      */     }
/*  440 */     return result;
/*      */   }
/*      */   
/*      */   Rectangle[] getRectanglesInPixels() {
/*  444 */     checkWidget();
/*  445 */     Rectangle[] result = new Rectangle[this.rectangles.length];
/*  446 */     for (int i = 0; i < this.rectangles.length; i++) {
/*  447 */       Rectangle current = this.rectangles[i];
/*  448 */       result[i] = new Rectangle(current.x, current.y, current.width, current.height);
/*      */     }
/*  450 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getStippled()
/*      */   {
/*  464 */     checkWidget();
/*  465 */     return this.stippled;
/*      */   }
/*      */   
/*      */   boolean grab() {
/*  469 */     long cursor = this.cursor != null ? this.cursor.handle : 0L;
/*  470 */     int result = gdk_pointer_grab(this.window, 0, false, 516, 0L, cursor, 0);
/*  471 */     return result == 0;
/*      */   }
/*      */   
/*      */   long gtk_button_release_event(long widget, long event)
/*      */   {
/*  476 */     return gtk_mouse(7, widget, event);
/*      */   }
/*      */   
/*      */   long gtk_key_press_event(long widget, long eventPtr)
/*      */   {
/*  481 */     long result = super.gtk_key_press_event(widget, eventPtr);
/*  482 */     if (result != 0L) return result;
/*  483 */     GdkEventKey keyEvent = new GdkEventKey();
/*  484 */     OS.memmove(keyEvent, eventPtr, GdkEventKey.sizeof);
/*  485 */     int stepSize = (keyEvent.state & 0x4) != 0 ? 1 : 9;
/*  486 */     int xChange = 0;int yChange = 0;
/*  487 */     switch (keyEvent.keyval) {
/*      */     case 65307: 
/*  489 */       this.cancelled = true;
/*      */     
/*      */     case 65293: 
/*  492 */       this.tracking = false;
/*  493 */       break;
/*      */     case 65361: 
/*  495 */       xChange = -stepSize;
/*  496 */       break;
/*      */     case 65363: 
/*  498 */       xChange = stepSize;
/*  499 */       break;
/*      */     case 65362: 
/*  501 */       yChange = -stepSize;
/*  502 */       break;
/*      */     case 65364: 
/*  504 */       yChange = stepSize;
/*      */     }
/*      */     
/*  507 */     if ((xChange != 0) || (yChange != 0)) {
/*  508 */       Rectangle[] oldRectangles = this.rectangles;
/*  509 */       Rectangle[] rectsToErase = new Rectangle[this.rectangles.length];
/*  510 */       for (int i = 0; i < this.rectangles.length; i++) {
/*  511 */         Rectangle current = this.rectangles[i];
/*  512 */         rectsToErase[i] = new Rectangle(current.x, current.y, current.width, current.height);
/*      */       }
/*  514 */       Event event = new Event();
/*  515 */       Rectangle eventRect = new Rectangle(this.oldX + xChange, this.oldY + yChange, 0, 0);
/*  516 */       event.setBounds(DPIUtil.autoScaleDown(eventRect));
/*  517 */       if ((this.parent != null) && ((this.parent.style & 0x8000000) != 0)) {
/*  518 */         event.x = (DPIUtil.autoScaleDown(this.parent.getClientWidth()) - event.width - event.x);
/*      */       }
/*  520 */       if ((this.style & 0x10) != 0) {
/*  521 */         resizeRectangles(xChange, yChange);
/*  522 */         sendEvent(11, event);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  529 */         if (isDisposed()) {
/*  530 */           this.cancelled = true;
/*  531 */           return 1L;
/*      */         }
/*  533 */         boolean draw = false;
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  540 */         if (this.rectangles != oldRectangles) {
/*  541 */           int length = this.rectangles.length;
/*  542 */           if (length != rectsToErase.length) {
/*  543 */             draw = true;
/*      */           } else {
/*  545 */             for (int i = 0; i < length; i++) {
/*  546 */               if (!this.rectangles[i].equals(rectsToErase[i])) {
/*  547 */                 draw = true;
/*  548 */                 break;
/*      */               }
/*      */             }
/*      */           }
/*      */         } else {
/*  553 */           draw = true;
/*      */         }
/*  555 */         if (draw) {
/*  556 */           if (!GTK.GTK3) {
/*  557 */             drawRectangles(rectsToErase);
/*  558 */             update();
/*      */           }
/*  560 */           drawRectangles(this.rectangles);
/*      */         }
/*  562 */         Point cursorPos = adjustResizeCursor();
/*  563 */         if (cursorPos != null) {
/*  564 */           this.oldX = cursorPos.x;
/*  565 */           this.oldY = cursorPos.y;
/*      */         }
/*      */       } else {
/*  568 */         moveRectangles(xChange, yChange);
/*  569 */         sendEvent(10, event);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  576 */         if (isDisposed()) {
/*  577 */           this.cancelled = true;
/*  578 */           return 1L;
/*      */         }
/*  580 */         boolean draw = false;
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  587 */         if (this.rectangles != oldRectangles) {
/*  588 */           int length = this.rectangles.length;
/*  589 */           if (length != rectsToErase.length) {
/*  590 */             draw = true;
/*      */           } else {
/*  592 */             for (int i = 0; i < length; i++) {
/*  593 */               if (!this.rectangles[i].equals(rectsToErase[i])) {
/*  594 */                 draw = true;
/*  595 */                 break;
/*      */               }
/*      */             }
/*      */           }
/*      */         } else {
/*  600 */           draw = true;
/*      */         }
/*  602 */         if (draw) {
/*  603 */           drawRectangles(rectsToErase);
/*  604 */           update();
/*  605 */           drawRectangles(this.rectangles);
/*      */         }
/*  607 */         Point cursorPos = adjustMoveCursor();
/*  608 */         if (cursorPos != null) {
/*  609 */           this.oldX = cursorPos.x;
/*  610 */           this.oldY = cursorPos.y;
/*      */         }
/*      */       }
/*      */     }
/*  614 */     return result;
/*      */   }
/*      */   
/*      */   long gtk_motion_notify_event(long widget, long eventPtr)
/*      */   {
/*  619 */     long cursor = this.cursor != null ? this.cursor.handle : 0L;
/*  620 */     if (cursor != this.lastCursor) {
/*  621 */       ungrab();
/*  622 */       this.grabbed = grab();
/*  623 */       this.lastCursor = cursor;
/*      */     }
/*  625 */     return gtk_mouse(3, widget, eventPtr);
/*      */   }
/*      */   
/*      */   long gtk_mouse(int eventType, long widget, long eventPtr) {
/*  629 */     int[] newX = new int[1];int[] newY = new int[1];
/*  630 */     gdk_window_get_device_position(this.window, newX, newY, null);
/*  631 */     if ((this.oldX != newX[0]) || (this.oldY != newY[0])) {
/*  632 */       Rectangle[] oldRectangles = this.rectangles;
/*  633 */       Rectangle[] rectsToErase = new Rectangle[this.rectangles.length];
/*  634 */       for (int i = 0; i < this.rectangles.length; i++) {
/*  635 */         Rectangle current = this.rectangles[i];
/*  636 */         rectsToErase[i] = new Rectangle(current.x, current.y, current.width, current.height);
/*      */       }
/*  638 */       Event event = new Event();
/*  639 */       if (this.parent == null) {
/*  640 */         Rectangle eventRect = new Rectangle(newX[0], newY[0], 0, 0);
/*  641 */         event.setBounds(DPIUtil.autoScaleDown(eventRect));
/*      */       } else {
/*  643 */         Point screenCoord = this.display.mapInPixels(this.parent, null, newX[0], newY[0]);
/*  644 */         Rectangle eventRect = new Rectangle(screenCoord.x, screenCoord.y, 0, 0);
/*  645 */         event.setBounds(DPIUtil.autoScaleDown(eventRect));
/*      */       }
/*  647 */       if ((this.style & 0x10) != 0) {
/*  648 */         resizeRectangles(newX[0] - this.oldX, newY[0] - this.oldY);
/*  649 */         sendEvent(11, event);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  656 */         if (isDisposed()) {
/*  657 */           this.cancelled = true;
/*  658 */           return 1L;
/*      */         }
/*  660 */         boolean draw = false;
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  667 */         if (this.rectangles != oldRectangles) {
/*  668 */           int length = this.rectangles.length;
/*  669 */           if (length != rectsToErase.length) {
/*  670 */             draw = true;
/*      */           } else {
/*  672 */             for (int i = 0; i < length; i++) {
/*  673 */               if (!this.rectangles[i].equals(rectsToErase[i])) {
/*  674 */                 draw = true;
/*  675 */                 break;
/*      */               }
/*      */             }
/*      */           }
/*      */         } else {
/*  680 */           draw = true;
/*      */         }
/*  682 */         if (draw) {
/*  683 */           if (!GTK.GTK3) {
/*  684 */             drawRectangles(rectsToErase);
/*  685 */             update();
/*      */           }
/*  687 */           drawRectangles(this.rectangles);
/*      */         }
/*  689 */         Point cursorPos = adjustResizeCursor();
/*  690 */         if (cursorPos != null) {
/*  691 */           newX[0] = cursorPos.x;
/*  692 */           newY[0] = cursorPos.y;
/*      */         }
/*      */       } else {
/*  695 */         moveRectangles(newX[0] - this.oldX, newY[0] - this.oldY);
/*  696 */         sendEvent(10, event);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  703 */         if (isDisposed()) {
/*  704 */           this.cancelled = true;
/*  705 */           return 1L;
/*      */         }
/*  707 */         boolean draw = false;
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  714 */         if (this.rectangles != oldRectangles) {
/*  715 */           int length = this.rectangles.length;
/*  716 */           if (length != rectsToErase.length) {
/*  717 */             draw = true;
/*      */           } else {
/*  719 */             for (int i = 0; i < length; i++) {
/*  720 */               if (!this.rectangles[i].equals(rectsToErase[i])) {
/*  721 */                 draw = true;
/*  722 */                 break;
/*      */               }
/*      */             }
/*      */           }
/*      */         } else {
/*  727 */           draw = true;
/*      */         }
/*  729 */         if (draw) {
/*  730 */           if (!GTK.GTK3) {
/*  731 */             drawRectangles(rectsToErase);
/*  732 */             update();
/*      */           }
/*  734 */           drawRectangles(this.rectangles);
/*      */         }
/*      */       }
/*  737 */       this.oldX = newX[0];
/*  738 */       this.oldY = newY[0];
/*      */     }
/*  740 */     this.tracking = (eventType != 7);
/*  741 */     return 0L;
/*      */   }
/*      */   
/*      */   void moveRectangles(int xChange, int yChange) {
/*  745 */     if (this.bounds == null) return;
/*  746 */     if ((xChange < 0) && ((this.style & 0x4000) == 0)) xChange = 0;
/*  747 */     if ((xChange > 0) && ((this.style & 0x20000) == 0)) xChange = 0;
/*  748 */     if ((yChange < 0) && ((this.style & 0x80) == 0)) yChange = 0;
/*  749 */     if ((yChange > 0) && ((this.style & 0x400) == 0)) yChange = 0;
/*  750 */     if ((xChange == 0) && (yChange == 0)) return;
/*  751 */     if ((this.parent != null) && ((this.parent.style & 0x8000000) != 0)) xChange *= -1;
/*  752 */     this.bounds.x += xChange;this.bounds.y += yChange;
/*  753 */     for (int i = 0; i < this.rectangles.length; i++) {
/*  754 */       this.rectangles[i].x += xChange;
/*  755 */       this.rectangles[i].y += yChange;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean open()
/*      */   {
/*  772 */     checkWidget();
/*  773 */     this.window = GDK.gdk_get_default_root_window();
/*  774 */     if (this.parent != null) {
/*  775 */       this.window = gtk_widget_get_window(this.parent.paintHandle());
/*      */     }
/*  777 */     if (this.window == 0L) return false;
/*  778 */     this.cancelled = false;
/*  779 */     this.tracking = true;
/*  780 */     if (!GTK.GTK3) {
/*  781 */       update();
/*  782 */       drawRectangles(this.rectangles);
/*      */     }
/*  784 */     int[] oldX = new int[1];int[] oldY = new int[1];int[] state = new int[1];
/*  785 */     gdk_window_get_device_position(this.window, oldX, oldY, state);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  791 */     int vStyle = this.style & 0x480;
/*  792 */     if ((vStyle == 128) || (vStyle == 1024)) {
/*  793 */       this.cursorOrientation |= vStyle;
/*      */     }
/*  795 */     int hStyle = this.style & 0x24000;
/*  796 */     if ((hStyle == 16384) || (hStyle == 131072)) {
/*  797 */       this.cursorOrientation |= hStyle;
/*      */     }
/*      */     
/*  800 */     int mask = 1792;
/*  801 */     boolean mouseDown = (state[0] & mask) != 0;
/*  802 */     if (!mouseDown) {
/*  803 */       Point cursorPos = null;
/*  804 */       if ((this.style & 0x10) != 0) {
/*  805 */         cursorPos = adjustResizeCursor();
/*      */       } else {
/*  807 */         cursorPos = adjustMoveCursor();
/*      */       }
/*  809 */       if (cursorPos != null) {
/*  810 */         oldX[0] = cursorPos.x;
/*  811 */         oldY[0] = cursorPos.y;
/*      */       }
/*      */     }
/*  814 */     this.oldX = oldX[0];
/*  815 */     this.oldY = oldY[0];
/*      */     
/*  817 */     this.grabbed = grab();
/*  818 */     this.lastCursor = (this.cursor != null ? this.cursor.handle : 0L);
/*      */     
/*  820 */     if (GTK.GTK3) {
/*  821 */       this.cachedCombinedDisplayResolution = Display.getDefault().getBounds();
/*  822 */       this.overlay = GTK.gtk_window_new(1);
/*  823 */       GTK.gtk_window_set_skip_taskbar_hint(this.overlay, true);
/*  824 */       GTK.gtk_window_set_title(this.overlay, new byte[1]);
/*  825 */       GTK.gtk_widget_realize(this.overlay);
/*  826 */       long overlayWindow = GTK.gtk_widget_get_window(this.overlay);
/*  827 */       GDK.gdk_window_set_override_redirect(overlayWindow, true);
/*  828 */       setTrackerBackground(true);
/*  829 */       Rectangle bounds = this.display.getBoundsInPixels();
/*  830 */       GTK.gtk_window_move(this.overlay, bounds.x, bounds.y);
/*  831 */       GTK.gtk_window_resize(this.overlay, bounds.width, bounds.height);
/*  832 */       GTK.gtk_widget_show(this.overlay);
/*      */     }
/*      */     
/*      */ 
/*  836 */     Display display = this.display;
/*  837 */     Tracker oldTracker = display.tracker;
/*  838 */     display.tracker = this;
/*      */     try {
/*  840 */       while ((this.tracking) && (
/*  841 */         (this.parent == null) || (!this.parent.isDisposed()))) {
/*  842 */         display.runSkin();
/*  843 */         display.runDeferredLayouts();
/*  844 */         display.sendPreExternalEventDispatchEvent();
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  851 */         GDK.gdk_threads_leave();
/*  852 */         OS.g_main_context_iteration(0L, true);
/*  853 */         display.sendPostExternalEventDispatchEvent();
/*  854 */         display.runAsyncMessages(false);
/*      */       }
/*      */     } finally {
/*  857 */       display.tracker = oldTracker;
/*      */     }
/*  859 */     if ((!isDisposed()) && 
/*  860 */       (!GTK.GTK3)) {
/*  861 */       update();
/*  862 */       drawRectangles(this.rectangles);
/*      */     }
/*      */     
/*  865 */     ungrab();
/*  866 */     if (this.overlay != 0L) {
/*  867 */       GTK.gtk_widget_destroy(this.overlay);
/*  868 */       this.overlay = 0L;
/*      */     }
/*  870 */     this.window = 0L;
/*  871 */     return !this.cancelled;
/*      */   }
/*      */   
/*      */   private void setTrackerBackground(boolean opaque) {
/*  875 */     if ((this.cachedBackgroundIsOpaque == null) || (this.cachedBackgroundIsOpaque.booleanValue() != opaque)) {
/*  876 */       this.cachedBackgroundIsOpaque = Boolean.valueOf(opaque);
/*  877 */     } else if (opaque == this.cachedBackgroundIsOpaque.booleanValue()) {
/*  878 */       return;
/*      */     }
/*  880 */     if (GTK.GTK_VERSION < OS.VERSION(3, 14, 0)) {
/*  881 */       GTK.gtk_widget_override_background_color(this.overlay, 0, new GdkRGBA());
/*      */     } else {
/*  883 */       String name = GTK.GTK_VERSION >= OS.VERSION(3, 20, 0) ? "window" : "GtkWindow";
/*      */       String css;
/*  885 */       String css; if (opaque) {
/*  886 */         GTK.gtk_widget_set_opacity(this.overlay, 1.0D);
/*  887 */         css = name + " {background-color: rgb(0,0,0);}";
/*      */       } else {
/*  889 */         GTK.gtk_widget_set_opacity(this.overlay, 0.0D);
/*  890 */         css = name + " {  border-top-color: transparent;border-left-color: transparent;border-right-color: transparent;border-bottom-color: transparent;}";
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  896 */       long context = GTK.gtk_widget_get_style_context(this.overlay);
/*  897 */       if (this.provider == 0L) {
/*  898 */         this.provider = GTK.gtk_css_provider_new();
/*  899 */         GTK.gtk_style_context_add_provider(context, this.provider, 600);
/*  900 */         OS.g_object_unref(this.provider);
/*      */       }
/*  902 */       GTK.gtk_css_provider_load_from_data(this.provider, Converter.wcsToMbcs(css, true), -1L, null);
/*  903 */       GTK.gtk_style_context_invalidate(context);
/*      */     }
/*  905 */     long region = GDK.gdk_region_new();
/*  906 */     GTK.gtk_widget_shape_combine_region(this.overlay, region);
/*  907 */     GTK.gtk_widget_input_shape_combine_region(this.overlay, region);
/*  908 */     GDK.gdk_region_destroy(region);
/*      */   }
/*      */   
/*      */   boolean processEvent(long eventPtr) {
/*  912 */     GdkEvent gdkEvent = new GdkEvent();
/*  913 */     OS.memmove(gdkEvent, eventPtr, GdkEvent.sizeof);
/*  914 */     long widget = GTK.gtk_get_event_widget(eventPtr);
/*  915 */     switch (gdkEvent.type) {
/*  916 */     case 3:  gtk_motion_notify_event(widget, eventPtr); break;
/*  917 */     case 7:  gtk_button_release_event(widget, eventPtr); break;
/*  918 */     case 8:  gtk_key_press_event(widget, eventPtr); break;
/*  919 */     case 9:  gtk_key_release_event(widget, eventPtr); break;
/*      */     case 4: 
/*      */     case 5: 
/*      */     case 6: 
/*      */     case 10: 
/*      */     case 11: 
/*      */       break;
/*      */     
/*      */     case 2: 
/*  928 */       update();
/*  929 */       if (!GTK.GTK3) drawRectangles(this.rectangles);
/*  930 */       GTK.gtk_main_do_event(eventPtr);
/*  931 */       if (!GTK.GTK3) drawRectangles(this.rectangles);
/*      */       break;
/*      */     default: 
/*  934 */       return true;
/*      */     }
/*  936 */     return false;
/*      */   }
/*      */   
/*      */   void releaseWidget()
/*      */   {
/*  941 */     super.releaseWidget();
/*  942 */     this.parent = null;
/*  943 */     this.rectangles = (this.proportions = null);
/*  944 */     this.bounds = null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeControlListener(ControlListener listener)
/*      */   {
/*  965 */     checkWidget();
/*  966 */     if (listener == null) error(4);
/*  967 */     if (this.eventTable == null) return;
/*  968 */     this.eventTable.unhook(11, listener);
/*  969 */     this.eventTable.unhook(10, listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeKeyListener(KeyListener listener)
/*      */   {
/*  990 */     checkWidget();
/*  991 */     if (listener == null) error(4);
/*  992 */     if (this.eventTable == null) return;
/*  993 */     this.eventTable.unhook(2, listener);
/*  994 */     this.eventTable.unhook(1, listener);
/*      */   }
/*      */   
/*      */   void resizeRectangles(int xChange, int yChange) {
/*  998 */     if (this.bounds == null) return;
/*  999 */     if ((this.parent != null) && ((this.parent.style & 0x8000000) != 0)) { xChange *= -1;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1004 */     if ((xChange < 0) && ((this.style & 0x4000) != 0) && ((this.cursorOrientation & 0x20000) == 0)) {
/* 1005 */       this.cursorOrientation |= 0x4000;
/*      */     }
/* 1007 */     if ((xChange > 0) && ((this.style & 0x20000) != 0) && ((this.cursorOrientation & 0x4000) == 0)) {
/* 1008 */       this.cursorOrientation |= 0x20000;
/*      */     }
/* 1010 */     if ((yChange < 0) && ((this.style & 0x80) != 0) && ((this.cursorOrientation & 0x400) == 0)) {
/* 1011 */       this.cursorOrientation |= 0x80;
/*      */     }
/* 1013 */     if ((yChange > 0) && ((this.style & 0x400) != 0) && ((this.cursorOrientation & 0x80) == 0)) {
/* 1014 */       this.cursorOrientation |= 0x400;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1023 */     if ((this.cursorOrientation & 0x4000) != 0) {
/* 1024 */       if (xChange > this.bounds.width) {
/* 1025 */         if ((this.style & 0x20000) == 0) return;
/* 1026 */         this.cursorOrientation |= 0x20000;
/* 1027 */         this.cursorOrientation &= 0xBFFF;
/* 1028 */         this.bounds.x += this.bounds.width;
/* 1029 */         xChange -= this.bounds.width;
/* 1030 */         this.bounds.width = 0;
/* 1031 */         if (this.proportions.length > 1) {
/* 1032 */           for (int i = 0; i < this.proportions.length; i++) {
/* 1033 */             Rectangle proportion = this.proportions[i];
/* 1034 */             proportion.x = (100 - proportion.x - proportion.width);
/*      */           }
/*      */         }
/*      */       }
/* 1038 */     } else if (((this.cursorOrientation & 0x20000) != 0) && 
/* 1039 */       (this.bounds.width < -xChange)) {
/* 1040 */       if ((this.style & 0x4000) == 0) return;
/* 1041 */       this.cursorOrientation |= 0x4000;
/* 1042 */       this.cursorOrientation &= 0xFFFDFFFF;
/* 1043 */       xChange += this.bounds.width;
/* 1044 */       this.bounds.width = 0;
/* 1045 */       if (this.proportions.length > 1) {
/* 1046 */         for (int i = 0; i < this.proportions.length; i++) {
/* 1047 */           Rectangle proportion = this.proportions[i];
/* 1048 */           proportion.x = (100 - proportion.x - proportion.width);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 1053 */     if ((this.cursorOrientation & 0x80) != 0) {
/* 1054 */       if (yChange > this.bounds.height) {
/* 1055 */         if ((this.style & 0x400) == 0) return;
/* 1056 */         this.cursorOrientation |= 0x400;
/* 1057 */         this.cursorOrientation &= 0xFF7F;
/* 1058 */         this.bounds.y += this.bounds.height;
/* 1059 */         yChange -= this.bounds.height;
/* 1060 */         this.bounds.height = 0;
/* 1061 */         if (this.proportions.length > 1) {
/* 1062 */           for (int i = 0; i < this.proportions.length; i++) {
/* 1063 */             Rectangle proportion = this.proportions[i];
/* 1064 */             proportion.y = (100 - proportion.y - proportion.height);
/*      */           }
/*      */         }
/*      */       }
/* 1068 */     } else if (((this.cursorOrientation & 0x400) != 0) && 
/* 1069 */       (this.bounds.height < -yChange)) {
/* 1070 */       if ((this.style & 0x80) == 0) return;
/* 1071 */       this.cursorOrientation |= 0x80;
/* 1072 */       this.cursorOrientation &= 0xFBFF;
/* 1073 */       yChange += this.bounds.height;
/* 1074 */       this.bounds.height = 0;
/* 1075 */       if (this.proportions.length > 1) {
/* 1076 */         for (int i = 0; i < this.proportions.length; i++) {
/* 1077 */           Rectangle proportion = this.proportions[i];
/* 1078 */           proportion.y = (100 - proportion.y - proportion.height);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1085 */     if ((this.cursorOrientation & 0x4000) != 0) {
/* 1086 */       this.bounds.x += xChange;
/* 1087 */       this.bounds.width -= xChange;
/* 1088 */     } else if ((this.cursorOrientation & 0x20000) != 0) {
/* 1089 */       this.bounds.width += xChange;
/*      */     }
/* 1091 */     if ((this.cursorOrientation & 0x80) != 0) {
/* 1092 */       this.bounds.y += yChange;
/* 1093 */       this.bounds.height -= yChange;
/* 1094 */     } else if ((this.cursorOrientation & 0x400) != 0) {
/* 1095 */       this.bounds.height += yChange;
/*      */     }
/*      */     
/* 1098 */     Rectangle[] newRects = new Rectangle[this.rectangles.length];
/* 1099 */     for (int i = 0; i < this.rectangles.length; i++) {
/* 1100 */       Rectangle proportion = this.proportions[i];
/* 1101 */       newRects[i] = new Rectangle(proportion.x * this.bounds.width / 100 + this.bounds.x, proportion.y * this.bounds.height / 100 + this.bounds.y, proportion.width * this.bounds.width / 100, proportion.height * this.bounds.height / 100);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1107 */     this.rectangles = newRects;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCursor(Cursor newCursor)
/*      */   {
/* 1122 */     checkWidget();
/* 1123 */     this.cursor = newCursor;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRectangles(Rectangle[] rectangles)
/*      */   {
/* 1141 */     checkWidget();
/* 1142 */     if (rectangles == null) error(4);
/* 1143 */     int length = rectangles.length;
/* 1144 */     for (int i = 0; i < length; i++) {
/* 1145 */       rectangles[i] = DPIUtil.autoScaleUp(rectangles[i]);
/*      */     }
/* 1147 */     setRectanglesInPixels(rectangles);
/*      */   }
/*      */   
/*      */   void setRectanglesInPixels(Rectangle[] rectangles) {
/* 1151 */     checkWidget();
/* 1152 */     if (rectangles == null) error(4);
/* 1153 */     int length = rectangles.length;
/* 1154 */     this.rectangles = new Rectangle[length];
/* 1155 */     for (int i = 0; i < length; i++) {
/* 1156 */       Rectangle current = rectangles[i];
/* 1157 */       if (current == null) error(4);
/* 1158 */       this.rectangles[i] = new Rectangle(current.x, current.y, current.width, current.height);
/*      */     }
/* 1160 */     this.proportions = computeProportions(rectangles);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setStippled(boolean stippled)
/*      */   {
/* 1174 */     checkWidget();
/* 1175 */     this.stippled = stippled;
/*      */   }
/*      */   
/*      */   void ungrab() {
/* 1179 */     if (this.grabbed) gdk_pointer_ungrab(this.window, 0);
/*      */   }
/*      */   
/*      */   void update() {
/* 1183 */     if (this.parent != null) {
/* 1184 */       if (this.parent.isDisposed()) return;
/* 1185 */       this.parent.getShell().update();
/*      */     } else {
/* 1187 */       this.display.update();
/*      */     }
/*      */   }
/*      */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/widgets/Tracker.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */