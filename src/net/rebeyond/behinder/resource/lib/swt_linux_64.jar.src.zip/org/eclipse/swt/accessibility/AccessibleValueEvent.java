/*    */ package org.eclipse.swt.accessibility;
/*    */ 
/*    */ import java.util.EventObject;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AccessibleValueEvent
/*    */   extends EventObject
/*    */ {
/*    */   public Number value;
/*    */   static final long serialVersionUID = -465979079760740668L;
/*    */   
/*    */   public AccessibleValueEvent(Object source)
/*    */   {
/* 36 */     super(source);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String toString()
/*    */   {
/* 47 */     return "AccessibleValueEvent {value=" + this.value + "}";
/*    */   }
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/accessibility/AccessibleValueEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */