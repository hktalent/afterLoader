/*    */ package org.eclipse.swt.internal.gtk;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GTypeQuery
/*    */ {
/*    */   public int type;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public long type_name;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public int class_size;
/*    */   
/*    */ 
/*    */ 
/*    */   public int instance_size;
/*    */   
/*    */ 
/*    */ 
/* 27 */   public static final int sizeof = ;
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/internal/gtk/GTypeQuery.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */