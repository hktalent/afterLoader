/*     */ package org.eclipse.swt.widgets;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Tray
/*     */   extends Widget
/*     */ {
/*     */   int itemCount;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  39 */   TrayItem[] items = new TrayItem[4];
/*     */   
/*     */   Tray(Display display, int style) {
/*  42 */     this.display = display;
/*  43 */     reskinWidget();
/*     */   }
/*     */   
/*     */   void createItem(TrayItem item, int index) {
/*  47 */     if ((0 > index) || (index > this.itemCount)) error(6);
/*  48 */     if (this.itemCount == this.items.length) {
/*  49 */       TrayItem[] newItems = new TrayItem[this.items.length + 4];
/*  50 */       System.arraycopy(this.items, 0, newItems, 0, this.items.length);
/*  51 */       this.items = newItems;
/*     */     }
/*  53 */     System.arraycopy(this.items, index, this.items, index + 1, this.itemCount++ - index);
/*  54 */     this.items[index] = item;
/*     */   }
/*     */   
/*     */   void destroyItem(TrayItem item) {
/*  58 */     int index = 0;
/*  59 */     while ((index < this.itemCount) && 
/*  60 */       (this.items[index] != item)) {
/*  61 */       index++;
/*     */     }
/*  63 */     if (index == this.itemCount) return;
/*  64 */     System.arraycopy(this.items, index + 1, this.items, index, --this.itemCount - index);
/*  65 */     this.items[this.itemCount] = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TrayItem getItem(int index)
/*     */   {
/*  84 */     checkWidget();
/*  85 */     if ((0 > index) || (index >= this.itemCount)) error(6);
/*  86 */     return this.items[index];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getItemCount()
/*     */   {
/* 100 */     checkWidget();
/* 101 */     return this.itemCount;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TrayItem[] getItems()
/*     */   {
/* 121 */     checkWidget();
/* 122 */     TrayItem[] result = new TrayItem[this.itemCount];
/* 123 */     System.arraycopy(this.items, 0, result, 0, result.length);
/* 124 */     return result;
/*     */   }
/*     */   
/*     */   void releaseChildren(boolean destroy)
/*     */   {
/* 129 */     if (this.items != null) {
/* 130 */       for (int i = 0; i < this.items.length; i++) {
/* 131 */         TrayItem item = this.items[i];
/* 132 */         if ((item != null) && (!item.isDisposed())) {
/* 133 */           item.release(false);
/*     */         }
/*     */       }
/* 136 */       this.items = null;
/*     */     }
/* 138 */     super.releaseChildren(destroy);
/*     */   }
/*     */   
/*     */   void releaseParent()
/*     */   {
/* 143 */     super.releaseParent();
/* 144 */     if (this.display.tray == this) this.display.tray = null;
/*     */   }
/*     */   
/*     */   void reskinChildren(int flags)
/*     */   {
/* 149 */     if (this.items != null) {
/* 150 */       for (int i = 0; i < this.items.length; i++) {
/* 151 */         TrayItem item = this.items[i];
/* 152 */         if (item != null) item.reskin(flags);
/*     */       }
/*     */     }
/* 155 */     super.reskinChildren(flags);
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/widgets/Tray.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */