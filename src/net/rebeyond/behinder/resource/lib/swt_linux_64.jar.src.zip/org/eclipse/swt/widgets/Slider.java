/*     */ package org.eclipse.swt.widgets;
/*     */ 
/*     */ import org.eclipse.swt.events.SelectionListener;
/*     */ import org.eclipse.swt.graphics.Point;
/*     */ import org.eclipse.swt.internal.gtk.GTK;
/*     */ import org.eclipse.swt.internal.gtk.GdkEvent;
/*     */ import org.eclipse.swt.internal.gtk.GdkEventButton;
/*     */ import org.eclipse.swt.internal.gtk.GtkAdjustment;
/*     */ import org.eclipse.swt.internal.gtk.OS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Slider
/*     */   extends Control
/*     */ {
/*     */   int detail;
/*     */   boolean dragSent;
/*     */   
/*     */   public Slider(Composite parent, int style)
/*     */   {
/* 104 */     super(parent, checkStyle(style));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addSelectionListener(SelectionListener listener)
/*     */   {
/* 140 */     checkWidget();
/* 141 */     if (listener == null) error(4);
/* 142 */     TypedListener typedListener = new TypedListener(listener);
/* 143 */     addListener(13, typedListener);
/* 144 */     addListener(14, typedListener);
/*     */   }
/*     */   
/*     */   static int checkStyle(int style) {
/* 148 */     return checkBits(style, 256, 512, 0, 0, 0, 0);
/*     */   }
/*     */   
/*     */   void createHandle(int index)
/*     */   {
/* 153 */     this.state |= 0x8;
/* 154 */     this.fixedHandle = OS.g_object_new(this.display.gtk_fixed_get_type(), 0L);
/* 155 */     if (this.fixedHandle == 0L) error(2);
/* 156 */     GTK.gtk_widget_set_has_window(this.fixedHandle, true);
/* 157 */     long hAdjustment = GTK.gtk_adjustment_new(0.0D, 0.0D, 100.0D, 1.0D, 10.0D, 10.0D);
/* 158 */     if (hAdjustment == 0L) error(2);
/* 159 */     if ((this.style & 0x100) != 0) {
/* 160 */       this.handle = gtk_scrollbar_new(0, hAdjustment);
/*     */     } else {
/* 162 */       this.handle = gtk_scrollbar_new(1, hAdjustment);
/*     */     }
/* 164 */     if (this.handle == 0L) { error(2);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 173 */     if ((this.style & 0x200) != 0) {
/* 174 */       GTK.gtk_widget_set_can_focus(this.handle, true);
/*     */     }
/* 176 */     GTK.gtk_container_add(this.fixedHandle, this.handle);
/*     */   }
/*     */   
/*     */   long gtk_button_press_event(long widget, long eventPtr)
/*     */   {
/* 181 */     long result = super.gtk_button_press_event(widget, eventPtr);
/* 182 */     if (result != 0L) return result;
/* 183 */     this.detail = 0;
/* 184 */     this.dragSent = false;
/* 185 */     return result;
/*     */   }
/*     */   
/*     */   long gtk_change_value(long widget, long scroll, long value1, long value2)
/*     */   {
/* 190 */     this.detail = ((int)scroll);
/* 191 */     return 0L;
/*     */   }
/*     */   
/*     */   long gtk_value_changed(long adjustment)
/*     */   {
/* 196 */     Event event = new Event();
/* 197 */     this.dragSent = (this.detail == 1);
/* 198 */     switch (this.detail) {
/* 199 */     case 0:  event.detail = 0; break;
/* 200 */     case 1:  event.detail = 1; break;
/* 201 */     case 14:  event.detail = 16777223; break;
/* 202 */     case 15:  event.detail = 16777224; break;
/*     */     case 5: case 9: 
/*     */     case 13: 
/* 205 */       event.detail = 16777222; break;
/*     */     case 4: case 8: 
/*     */     case 12: 
/* 208 */       event.detail = 16777221; break;
/*     */     case 3: case 7: 
/*     */     case 11: 
/* 211 */       event.detail = 16777218; break;
/*     */     case 2: case 6: 
/*     */     case 10: 
/* 214 */       event.detail = 16777217;
/*     */     }
/* 216 */     if (!this.dragSent) this.detail = 0;
/* 217 */     sendSelectionEvent(13, event, false);
/* 218 */     return 0L;
/*     */   }
/*     */   
/*     */   long gtk_event_after(long widget, long gdkEvent)
/*     */   {
/* 223 */     GdkEvent gtkEvent = new GdkEvent();
/* 224 */     OS.memmove(gtkEvent, gdkEvent, GdkEvent.sizeof);
/* 225 */     switch (gtkEvent.type) {
/*     */     case 7: 
/* 227 */       GdkEventButton gdkEventButton = new GdkEventButton();
/* 228 */       OS.memmove(gdkEventButton, gdkEvent, GdkEventButton.sizeof);
/* 229 */       if ((gdkEventButton.button == 1) && (this.detail == 1)) {
/* 230 */         if (!this.dragSent) {
/* 231 */           Event event = new Event();
/* 232 */           event.detail = 1;
/* 233 */           sendSelectionEvent(13, event, false);
/*     */         }
/* 235 */         sendSelectionEvent(13);
/*     */       }
/* 237 */       this.detail = 0;
/* 238 */       this.dragSent = false;
/* 239 */       break;
/*     */     }
/*     */     
/* 242 */     return super.gtk_event_after(widget, gdkEvent);
/*     */   }
/*     */   
/*     */   void hookEvents()
/*     */   {
/* 247 */     super.hookEvents();
/* 248 */     OS.g_signal_connect_closure(this.handle, OS.change_value, this.display.getClosure(7), false);
/* 249 */     OS.g_signal_connect_closure(this.handle, OS.value_changed, this.display.getClosure(57), false);
/*     */   }
/*     */   
/*     */   void register()
/*     */   {
/* 254 */     super.register();
/* 255 */     long hAdjustment = GTK.gtk_range_get_adjustment(this.handle);
/* 256 */     this.display.addWidget(hAdjustment, this);
/*     */   }
/*     */   
/*     */   void deregister()
/*     */   {
/* 261 */     super.deregister();
/* 262 */     long hAdjustment = GTK.gtk_range_get_adjustment(this.handle);
/* 263 */     this.display.removeWidget(hAdjustment);
/*     */   }
/*     */   
/*     */   Point computeSizeInPixels(int wHint, int hHint, boolean changed)
/*     */   {
/* 268 */     checkWidget();
/* 269 */     GTK.gtk_widget_realize(this.handle);
/* 270 */     if ((wHint != -1) && (wHint < 0)) wHint = 0;
/* 271 */     if ((hHint != -1) && (hHint < 0)) hHint = 0;
/* 272 */     Point size = computeNativeSize(this.handle, wHint, hHint, changed);
/* 273 */     if ((this.style & 0x100) != 0) {
/* 274 */       if (wHint == -1) size.x = (2 * size.x);
/*     */     }
/* 276 */     else if (hHint == -1) { size.y = (2 * size.y);
/*     */     }
/* 278 */     return size;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getIncrement()
/*     */   {
/* 294 */     checkWidget();
/* 295 */     long hAdjustment = GTK.gtk_range_get_adjustment(this.handle);
/* 296 */     return (int)GTK.gtk_adjustment_get_step_increment(hAdjustment);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getMaximum()
/*     */   {
/* 310 */     checkWidget();
/* 311 */     long hAdjustment = GTK.gtk_range_get_adjustment(this.handle);
/* 312 */     return (int)GTK.gtk_adjustment_get_upper(hAdjustment);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getMinimum()
/*     */   {
/* 326 */     checkWidget();
/* 327 */     long hAdjustment = GTK.gtk_range_get_adjustment(this.handle);
/* 328 */     return (int)GTK.gtk_adjustment_get_lower(hAdjustment);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getPageIncrement()
/*     */   {
/* 344 */     checkWidget();
/* 345 */     long hAdjustment = GTK.gtk_range_get_adjustment(this.handle);
/* 346 */     return (int)GTK.gtk_adjustment_get_page_increment(hAdjustment);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getSelection()
/*     */   {
/* 360 */     checkWidget();
/* 361 */     long hAdjustment = GTK.gtk_range_get_adjustment(this.handle);
/* 362 */     return (int)GTK.gtk_adjustment_get_value(hAdjustment);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getThumb()
/*     */   {
/* 376 */     checkWidget();
/* 377 */     long hAdjustment = GTK.gtk_range_get_adjustment(this.handle);
/* 378 */     return (int)GTK.gtk_adjustment_get_page_size(hAdjustment);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeSelectionListener(SelectionListener listener)
/*     */   {
/* 399 */     checkWidget();
/* 400 */     if (listener == null) error(4);
/* 401 */     if (this.eventTable == null) return;
/* 402 */     this.eventTable.unhook(13, listener);
/* 403 */     this.eventTable.unhook(14, listener);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setIncrement(int value)
/*     */   {
/* 420 */     checkWidget();
/* 421 */     if (value < 1) return;
/* 422 */     OS.g_signal_handlers_block_matched(this.handle, 16, 0, 0, 0L, 0L, 57L);
/* 423 */     GTK.gtk_range_set_increments(this.handle, value, getPageIncrement());
/* 424 */     OS.g_signal_handlers_unblock_matched(this.handle, 16, 0, 0, 0L, 0L, 57L);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMaximum(int value)
/*     */   {
/* 441 */     checkWidget();
/* 442 */     long hAdjustment = GTK.gtk_range_get_adjustment(this.handle);
/* 443 */     GtkAdjustment adjustment = new GtkAdjustment();
/* 444 */     gtk_adjustment_get(hAdjustment, adjustment);
/* 445 */     int minimum = (int)adjustment.lower;
/* 446 */     if (value <= minimum) return;
/* 447 */     adjustment.upper = value;
/* 448 */     adjustment.page_size = Math.min((int)adjustment.page_size, value - minimum);
/* 449 */     adjustment.value = Math.min((int)adjustment.value, (int)(value - adjustment.page_size));
/* 450 */     OS.g_signal_handlers_block_matched(this.handle, 16, 0, 0, 0L, 0L, 57L);
/* 451 */     GTK.gtk_adjustment_configure(hAdjustment, adjustment.value, adjustment.lower, adjustment.upper, adjustment.step_increment, adjustment.page_increment, adjustment.page_size);
/*     */     
/* 453 */     OS.g_signal_handlers_unblock_matched(this.handle, 16, 0, 0, 0L, 0L, 57L);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMinimum(int value)
/*     */   {
/* 470 */     checkWidget();
/* 471 */     if (value < 0) return;
/* 472 */     long hAdjustment = GTK.gtk_range_get_adjustment(this.handle);
/* 473 */     GtkAdjustment adjustment = new GtkAdjustment();
/* 474 */     gtk_adjustment_get(hAdjustment, adjustment);
/* 475 */     int maximum = (int)adjustment.upper;
/* 476 */     if (value >= maximum) return;
/* 477 */     adjustment.lower = value;
/* 478 */     adjustment.page_size = Math.min((int)adjustment.page_size, maximum - value);
/* 479 */     adjustment.value = Math.max((int)adjustment.value, value);
/* 480 */     OS.g_signal_handlers_block_matched(this.handle, 16, 0, 0, 0L, 0L, 57L);
/* 481 */     GTK.gtk_adjustment_configure(hAdjustment, adjustment.value, adjustment.lower, adjustment.upper, adjustment.step_increment, adjustment.page_increment, adjustment.page_size);
/*     */     
/* 483 */     OS.g_signal_handlers_unblock_matched(this.handle, 16, 0, 0, 0L, 0L, 57L);
/*     */   }
/*     */   
/*     */   void setOrientation(boolean create)
/*     */   {
/* 488 */     super.setOrientation(create);
/* 489 */     if ((((this.style & 0x4000000) != 0) || (!create)) && 
/* 490 */       ((this.style & 0x100) != 0)) {
/* 491 */       GTK.gtk_range_set_inverted(this.handle, (this.style & 0x4000000) != 0);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPageIncrement(int value)
/*     */   {
/* 510 */     checkWidget();
/* 511 */     if (value < 1) return;
/* 512 */     OS.g_signal_handlers_block_matched(this.handle, 16, 0, 0, 0L, 0L, 57L);
/* 513 */     GTK.gtk_range_set_increments(this.handle, getIncrement(), value);
/* 514 */     OS.g_signal_handlers_unblock_matched(this.handle, 16, 0, 0, 0L, 0L, 57L);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSelection(int value)
/*     */   {
/* 530 */     checkWidget();
/* 531 */     OS.g_signal_handlers_block_matched(this.handle, 16, 0, 0, 0L, 0L, 57L);
/* 532 */     GTK.gtk_range_set_value(this.handle, value);
/* 533 */     OS.g_signal_handlers_unblock_matched(this.handle, 16, 0, 0, 0L, 0L, 57L);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setThumb(int value)
/*     */   {
/* 554 */     checkWidget();
/* 555 */     if (value < 1) return;
/* 556 */     long hAdjustment = GTK.gtk_range_get_adjustment(this.handle);
/* 557 */     GtkAdjustment adjustment = new GtkAdjustment();
/* 558 */     gtk_adjustment_get(hAdjustment, adjustment);
/* 559 */     value = Math.min(value, (int)(adjustment.upper - adjustment.lower));
/* 560 */     adjustment.page_size = value;
/* 561 */     adjustment.value = Math.min((int)adjustment.value, (int)(adjustment.upper - value));
/* 562 */     OS.g_signal_handlers_block_matched(this.handle, 16, 0, 0, 0L, 0L, 57L);
/* 563 */     GTK.gtk_adjustment_configure(hAdjustment, adjustment.value, adjustment.lower, adjustment.upper, adjustment.step_increment, adjustment.page_increment, adjustment.page_size);
/*     */     
/* 565 */     OS.g_signal_handlers_unblock_matched(this.handle, 16, 0, 0, 0L, 0L, 57L);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setValues(int selection, int minimum, int maximum, int thumb, int increment, int pageIncrement)
/*     */   {
/* 590 */     checkWidget();
/* 591 */     if (minimum < 0) return;
/* 592 */     if (maximum < 0) return;
/* 593 */     if (thumb < 1) return;
/* 594 */     if (increment < 1) return;
/* 595 */     if (pageIncrement < 1) return;
/* 596 */     thumb = Math.min(thumb, maximum - minimum);
/* 597 */     long hAdjustment = GTK.gtk_range_get_adjustment(this.handle);
/* 598 */     GtkAdjustment adjustment = new GtkAdjustment();
/* 599 */     adjustment.value = Math.min(Math.max(selection, minimum), maximum - thumb);
/* 600 */     adjustment.lower = minimum;
/* 601 */     adjustment.upper = maximum;
/* 602 */     adjustment.page_size = thumb;
/* 603 */     adjustment.step_increment = increment;
/* 604 */     adjustment.page_increment = pageIncrement;
/* 605 */     OS.g_signal_handlers_block_matched(this.handle, 16, 0, 0, 0L, 0L, 57L);
/* 606 */     GTK.gtk_adjustment_configure(hAdjustment, adjustment.value, adjustment.lower, adjustment.upper, adjustment.step_increment, adjustment.page_increment, adjustment.page_size);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 613 */     if (GTK.GTK_VERSION < OS.VERSION(3, 18, 0))
/* 614 */       GTK.gtk_adjustment_value_changed(hAdjustment);
/* 615 */     OS.g_signal_handlers_unblock_matched(this.handle, 16, 0, 0, 0L, 0L, 57L);
/*     */   }
/*     */   
/*     */   long gtk_scrollbar_new(int orientation, long adjustment) {
/* 619 */     long scrollbar = 0L;
/* 620 */     if (GTK.GTK3) {
/* 621 */       scrollbar = GTK.gtk_scrollbar_new(orientation, adjustment);
/*     */     }
/* 623 */     else if (orientation == 0) {
/* 624 */       scrollbar = GTK.gtk_hscrollbar_new(adjustment);
/*     */     } else {
/* 626 */       scrollbar = GTK.gtk_vscrollbar_new(adjustment);
/*     */     }
/*     */     
/* 629 */     return scrollbar;
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/widgets/Slider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */