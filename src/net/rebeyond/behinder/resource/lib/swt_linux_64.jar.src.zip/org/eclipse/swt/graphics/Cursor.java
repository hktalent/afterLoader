/*     */ package org.eclipse.swt.graphics;
/*     */ 
/*     */ import org.eclipse.swt.SWT;
/*     */ import org.eclipse.swt.internal.C;
/*     */ import org.eclipse.swt.internal.Converter;
/*     */ import org.eclipse.swt.internal.gtk.GDK;
/*     */ import org.eclipse.swt.internal.gtk.GTK;
/*     */ import org.eclipse.swt.internal.gtk.GdkColor;
/*     */ import org.eclipse.swt.internal.gtk.OS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Cursor
/*     */   extends Resource
/*     */ {
/*     */   public long handle;
/*  60 */   static final byte[] APPSTARTING_SRC = { 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 0, 0, 12, 0, 0, 0, 28, 0, 0, 0, 60, 0, 0, 0, 124, 0, 0, 0, -4, 0, 0, 0, -4, 1, 0, 0, -4, 59, 0, 0, 124, 56, 0, 0, 108, 84, 0, 0, -60, -36, 0, 0, -64, 68, 0, 0, Byte.MIN_VALUE, 57, 0, 0, Byte.MIN_VALUE, 57, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  73 */   static final byte[] APPSTARTING_MASK = { 0, 0, 0, 0, 6, 0, 0, 0, 14, 0, 0, 0, 30, 0, 0, 0, 62, 0, 0, 0, 126, 0, 0, 0, -2, 0, 0, 0, -2, 1, 0, 0, -2, 59, 0, 0, -2, Byte.MAX_VALUE, 0, 0, -2, Byte.MAX_VALUE, 0, 0, -2, -2, 0, 0, -18, -1, 1, 0, -28, -1, 0, 0, -64, Byte.MAX_VALUE, 0, 0, -64, Byte.MAX_VALUE, 0, 0, Byte.MIN_VALUE, 57, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   Cursor(Device device)
/*     */   {
/*  87 */     super(device);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Cursor(Device device, int style)
/*     */   {
/* 137 */     super(device);
/* 138 */     int shape = 0;
/* 139 */     byte[] name = null;
/* 140 */     switch (style) {
/* 141 */     case 3:  name = Converter.wcsToMbcs("progress", true); break;
/* 142 */     case 0:  shape = 68; break;
/* 143 */     case 1:  shape = 150; break;
/* 144 */     case 2:  shape = 30; break;
/* 145 */     case 21:  shape = 60; break;
/* 146 */     case 4:  shape = 92; break;
/* 147 */     case 5:  shape = 52; break;
/* 148 */     case 6:  shape = 120;name = Converter.wcsToMbcs("nesw-resize", true); break;
/* 149 */     case 7:  shape = 42; break;
/* 150 */     case 8:  shape = 120;name = Converter.wcsToMbcs("nwse-resize", true); break;
/* 151 */     case 9:  shape = 108; break;
/* 152 */     case 10:  shape = 138; break;
/* 153 */     case 11:  shape = 16; break;
/* 154 */     case 12:  shape = 96; break;
/* 155 */     case 13:  shape = 70; break;
/* 156 */     case 14:  shape = 136; break;
/* 157 */     case 15:  shape = 14; break;
/* 158 */     case 16:  shape = 12; break;
/* 159 */     case 17:  shape = 134; break;
/* 160 */     case 18:  shape = 114; break;
/* 161 */     case 19:  shape = 152; break;
/* 162 */     case 20:  shape = 0;name = Converter.wcsToMbcs("not-allowed", true); break;
/*     */     default: 
/* 164 */       SWT.error(5);
/*     */     }
/* 166 */     if (name != null) {
/* 167 */       this.handle = GDK.gdk_cursor_new_from_name(GDK.gdk_display_get_default(), name);
/*     */     }
/* 169 */     if (this.handle == 0L) {
/* 170 */       if ((shape == 0) && (style == 3)) {
/* 171 */         byte[] src = new byte[APPSTARTING_SRC.length];
/* 172 */         System.arraycopy(APPSTARTING_SRC, 0, src, 0, src.length);
/* 173 */         byte[] mask = new byte[APPSTARTING_MASK.length];
/* 174 */         System.arraycopy(APPSTARTING_MASK, 0, mask, 0, mask.length);
/* 175 */         this.handle = createCursor(src, mask, 32, 32, 2, 2, true);
/*     */       } else {
/* 177 */         this.handle = GDK.gdk_cursor_new_for_display(GDK.gdk_display_get_default(), shape);
/*     */       }
/*     */     }
/* 180 */     if (this.handle == 0L) SWT.error(2);
/* 181 */     init();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Cursor(Device device, ImageData source, ImageData mask, int hotspotX, int hotspotY)
/*     */   {
/* 218 */     super(device);
/* 219 */     if (source == null) SWT.error(4);
/* 220 */     if (mask == null) {
/* 221 */       if (source.getTransparencyType() != 2) SWT.error(4);
/* 222 */       mask = source.getTransparencyMask();
/*     */     }
/*     */     
/* 225 */     if ((mask.width != source.width) || (mask.height != source.height)) {
/* 226 */       SWT.error(5);
/*     */     }
/*     */     
/* 229 */     if ((hotspotX >= source.width) || (hotspotX < 0) || (hotspotY >= source.height) || (hotspotY < 0))
/*     */     {
/* 231 */       SWT.error(5);
/*     */     }
/*     */     
/* 234 */     source = ImageData.convertMask(source);
/* 235 */     mask = ImageData.convertMask(mask);
/*     */     
/*     */ 
/* 238 */     byte[] sourceData = new byte[source.data.length];
/* 239 */     byte[] maskData = new byte[mask.data.length];
/* 240 */     byte[] data = source.data;
/* 241 */     for (int i = 0; i < data.length; i++) {
/* 242 */       byte s = data[i];
/* 243 */       sourceData[i] = ((byte)((s & 0x80) >> 7 | (s & 0x40) >> 5 | (s & 0x20) >> 3 | (s & 0x10) >> 1 | (s & 0x8) << 1 | (s & 0x4) << 3 | (s & 0x2) << 5 | (s & 0x1) << 7));
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 251 */       sourceData[i] = ((byte)(sourceData[i] ^ 0xFFFFFFFF));
/*     */     }
/* 253 */     sourceData = ImageData.convertPad(sourceData, source.width, source.height, source.depth, source.scanlinePad, 1);
/* 254 */     data = mask.data;
/* 255 */     for (int i = 0; i < data.length; i++) {
/* 256 */       byte s = data[i];
/* 257 */       maskData[i] = ((byte)((s & 0x80) >> 7 | (s & 0x40) >> 5 | (s & 0x20) >> 3 | (s & 0x10) >> 1 | (s & 0x8) << 1 | (s & 0x4) << 3 | (s & 0x2) << 5 | (s & 0x1) << 7));
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 265 */       maskData[i] = ((byte)(maskData[i] ^ 0xFFFFFFFF));
/*     */     }
/* 267 */     maskData = ImageData.convertPad(maskData, mask.width, mask.height, mask.depth, mask.scanlinePad, 1);
/* 268 */     this.handle = createCursor(maskData, sourceData, source.width, source.height, hotspotX, hotspotY, true);
/* 269 */     if (this.handle == 0L) SWT.error(2);
/* 270 */     init();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Cursor(Device device, ImageData source, int hotspotX, int hotspotY)
/*     */   {
/* 303 */     super(device);
/* 304 */     if (source == null) SWT.error(4);
/* 305 */     if ((hotspotX >= source.width) || (hotspotX < 0) || (hotspotY >= source.height) || (hotspotY < 0))
/*     */     {
/* 307 */       SWT.error(5);
/*     */     }
/* 309 */     long display = 0L;
/* 310 */     if (GDK.gdk_display_supports_cursor_color(display = GDK.gdk_display_get_default())) {
/* 311 */       int width = source.width;
/* 312 */       int height = source.height;
/* 313 */       PaletteData palette = source.palette;
/* 314 */       long pixbuf = GDK.gdk_pixbuf_new(0, true, 8, width, height);
/* 315 */       if (pixbuf == 0L) SWT.error(2);
/* 316 */       int stride = GDK.gdk_pixbuf_get_rowstride(pixbuf);
/* 317 */       long data = GDK.gdk_pixbuf_get_pixels(pixbuf);
/* 318 */       byte[] buffer = source.data;
/* 319 */       if ((!palette.isDirect) || (source.depth != 24) || (stride != source.bytesPerLine) || (palette.redMask != -16777216) || (palette.greenMask != 16711680) || (palette.blueMask != 65280)) {
/* 320 */         buffer = new byte[source.width * source.height * 4];
/* 321 */         if (palette.isDirect) {
/* 322 */           ImageData.blit(1, source.data, source.depth, source.bytesPerLine, source
/* 323 */             .getByteOrder(), 0, 0, source.width, source.height, palette.redMask, palette.greenMask, palette.blueMask, 255, null, 0, 0, 0, buffer, 32, source.width * 4, 1, 0, 0, source.width, source.height, -16777216, 16711680, 65280, false, false);
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/* 328 */           RGB[] rgbs = palette.getRGBs();
/* 329 */           int length = rgbs.length;
/* 330 */           byte[] srcReds = new byte[length];
/* 331 */           byte[] srcGreens = new byte[length];
/* 332 */           byte[] srcBlues = new byte[length];
/* 333 */           for (int i = 0; i < rgbs.length; i++) {
/* 334 */             RGB rgb = rgbs[i];
/* 335 */             if (rgb != null) {
/* 336 */               srcReds[i] = ((byte)rgb.red);
/* 337 */               srcGreens[i] = ((byte)rgb.green);
/* 338 */               srcBlues[i] = ((byte)rgb.blue);
/*     */             } }
/* 340 */           ImageData.blit(1, source.data, source.depth, source.bytesPerLine, source
/* 341 */             .getByteOrder(), 0, 0, source.width, source.height, srcReds, srcGreens, srcBlues, 255, null, 0, 0, 0, buffer, 32, source.width * 4, 1, 0, 0, source.width, source.height, -16777216, 16711680, 65280, false, false);
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 346 */         if ((source.maskData != null) || (source.transparentPixel != -1)) {
/* 347 */           ImageData mask = source.getTransparencyMask();
/* 348 */           byte[] maskData = mask.data;
/* 349 */           int maskBpl = mask.bytesPerLine;
/* 350 */           int offset = 3;int maskOffset = 0;
/* 351 */           for (int y = 0; y < source.height; y++) {
/* 352 */             for (int x = 0; x < source.width; x++) {
/* 353 */               buffer[offset] = ((maskData[(maskOffset + (x >> 3))] & 1 << 7 - (x & 0x7)) != 0 ? -1 : 0);
/* 354 */               offset += 4;
/*     */             }
/* 356 */             maskOffset += maskBpl;
/*     */           }
/* 358 */         } else if (source.alpha != -1) {
/* 359 */           byte alpha = (byte)source.alpha;
/* 360 */           for (int i = 3; i < buffer.length; i += 4) {
/* 361 */             buffer[i] = alpha;
/*     */           }
/* 363 */         } else if (source.alphaData != null) {
/* 364 */           byte[] alphaData = source.alphaData;
/* 365 */           for (int i = 3; i < buffer.length; i += 4) {
/* 366 */             buffer[i] = alphaData[(i / 4)];
/*     */           }
/*     */         }
/*     */       }
/* 370 */       C.memmove(data, buffer, stride * height);
/* 371 */       this.handle = GDK.gdk_cursor_new_from_pixbuf(display, pixbuf, hotspotX, hotspotY);
/* 372 */       OS.g_object_unref(pixbuf);
/*     */     }
/*     */     else {
/* 375 */       ImageData mask = source.getTransparencyMask();
/*     */       
/*     */ 
/* 378 */       if (source.depth > 1)
/*     */       {
/*     */ 
/* 381 */         ImageData newSource = new ImageData(source.width, source.height, 1, ImageData.bwPalette(), 1, null, 0, null, null, -1, -1, 0, 0, 0, 0, 0);
/*     */         
/*     */ 
/* 384 */         byte[] newReds = { 0, -1 };byte[] newGreens = newReds;byte[] newBlues = newReds;
/*     */         
/*     */ 
/* 387 */         PaletteData palette = source.palette;
/* 388 */         if (palette.isDirect) {
/* 389 */           ImageData.blit(1, source.data, source.depth, source.bytesPerLine, source
/* 390 */             .getByteOrder(), 0, 0, source.width, source.height, palette.redMask, palette.greenMask, palette.blueMask, 255, null, 0, 0, 0, newSource.data, newSource.depth, newSource.bytesPerLine, newSource
/*     */             
/* 392 */             .getByteOrder(), 0, 0, newSource.width, newSource.height, newReds, newGreens, newBlues, false, false);
/*     */         }
/*     */         else {
/* 395 */           RGB[] rgbs = palette.getRGBs();
/* 396 */           int length = rgbs.length;
/* 397 */           byte[] srcReds = new byte[length];
/* 398 */           byte[] srcGreens = new byte[length];
/* 399 */           byte[] srcBlues = new byte[length];
/* 400 */           for (int i = 0; i < rgbs.length; i++) {
/* 401 */             RGB rgb = rgbs[i];
/* 402 */             if (rgb != null) {
/* 403 */               srcReds[i] = ((byte)rgb.red);
/* 404 */               srcGreens[i] = ((byte)rgb.green);
/* 405 */               srcBlues[i] = ((byte)rgb.blue);
/*     */             } }
/* 407 */           ImageData.blit(1, source.data, source.depth, source.bytesPerLine, source
/* 408 */             .getByteOrder(), 0, 0, source.width, source.height, srcReds, srcGreens, srcBlues, 255, null, 0, 0, 0, newSource.data, newSource.depth, newSource.bytesPerLine, newSource
/*     */             
/* 410 */             .getByteOrder(), 0, 0, newSource.width, newSource.height, newReds, newGreens, newBlues, false, false);
/*     */         }
/*     */         
/* 413 */         source = newSource;
/*     */       }
/*     */       
/*     */ 
/* 417 */       byte[] sourceData = new byte[source.data.length];
/* 418 */       byte[] maskData = new byte[mask.data.length];
/* 419 */       byte[] data = source.data;
/* 420 */       for (int i = 0; i < data.length; i++) {
/* 421 */         byte s = data[i];
/* 422 */         sourceData[i] = ((byte)((s & 0x80) >> 7 | (s & 0x40) >> 5 | (s & 0x20) >> 3 | (s & 0x10) >> 1 | (s & 0x8) << 1 | (s & 0x4) << 3 | (s & 0x2) << 5 | (s & 0x1) << 7));
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 431 */       sourceData = ImageData.convertPad(sourceData, source.width, source.height, source.depth, source.scanlinePad, 1);
/* 432 */       data = mask.data;
/* 433 */       for (int i = 0; i < data.length; i++) {
/* 434 */         byte s = data[i];
/* 435 */         maskData[i] = ((byte)((s & 0x80) >> 7 | (s & 0x40) >> 5 | (s & 0x20) >> 3 | (s & 0x10) >> 1 | (s & 0x8) << 1 | (s & 0x4) << 3 | (s & 0x2) << 5 | (s & 0x1) << 7));
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 444 */       maskData = ImageData.convertPad(maskData, mask.width, mask.height, mask.depth, mask.scanlinePad, 1);
/* 445 */       this.handle = createCursor(sourceData, maskData, source.width, source.height, hotspotX, hotspotY, false);
/*     */     }
/* 447 */     if (this.handle == 0L) SWT.error(2);
/* 448 */     init();
/*     */   }
/*     */   
/*     */   long createCursor(byte[] sourceData, byte[] maskData, int width, int height, int hotspotX, int hotspotY, boolean reverse) {
/* 452 */     if (GTK.GTK3) {
/* 453 */       for (int i = 0; i < sourceData.length; i++) {
/* 454 */         byte s = sourceData[i];
/* 455 */         sourceData[i] = ((byte)((s & 0x80) >> 7 | (s & 0x40) >> 5 | (s & 0x20) >> 3 | (s & 0x10) >> 1 | (s & 0x8) << 1 | (s & 0x4) << 3 | (s & 0x2) << 5 | (s & 0x1) << 7));
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 463 */         sourceData[i] = ((byte)(sourceData[i] ^ 0xFFFFFFFF));
/*     */       }
/* 465 */       for (int i = 0; i < maskData.length; i++) {
/* 466 */         byte s = maskData[i];
/* 467 */         maskData[i] = ((byte)((s & 0x80) >> 7 | (s & 0x40) >> 5 | (s & 0x20) >> 3 | (s & 0x10) >> 1 | (s & 0x8) << 1 | (s & 0x4) << 3 | (s & 0x2) << 5 | (s & 0x1) << 7));
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 475 */         maskData[i] = ((byte)(maskData[i] ^ 0xFFFFFFFF));
/*     */       }
/* 477 */       PaletteData palette = new PaletteData(new RGB[] { new RGB(0, 0, 0), new RGB(255, 255, 255) });
/* 478 */       ImageData source = new ImageData(width, height, 1, palette, 1, sourceData);
/* 479 */       ImageData mask = new ImageData(width, height, 1, palette, 1, maskData);
/* 480 */       byte[] data = new byte[source.width * source.height * 4];
/* 481 */       for (int y = 0; y < source.height; y++) {
/* 482 */         int offset = y * source.width * 4;
/* 483 */         for (int x = 0; x < source.width; x++) {
/* 484 */           int pixel = source.getPixel(x, y);
/* 485 */           int maskPixel = mask.getPixel(x, y);
/* 486 */           if ((pixel == 0) && (maskPixel == 0))
/*     */           {
/* 488 */             data[(offset + 3)] = -1;
/* 489 */           } else if ((pixel == 0) && (maskPixel == 1))
/*     */           {
/* 491 */             data[offset] = (data[(offset + 1)] = data[(offset + 2)] = data[(offset + 3)] = -1);
/* 492 */           } else if ((pixel != 1) || (maskPixel != 0)) {}
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 498 */           offset += 4;
/*     */         }
/*     */       }
/* 501 */       long pixbuf = GDK.gdk_pixbuf_new(0, true, 8, width, height);
/* 502 */       if (pixbuf == 0L) SWT.error(2);
/* 503 */       int stride = GDK.gdk_pixbuf_get_rowstride(pixbuf);
/* 504 */       long pixels = GDK.gdk_pixbuf_get_pixels(pixbuf);
/* 505 */       C.memmove(pixels, data, stride * height);
/* 506 */       long cursor = GDK.gdk_cursor_new_from_pixbuf(GDK.gdk_display_get_default(), pixbuf, hotspotX, hotspotY);
/* 507 */       OS.g_object_unref(pixbuf);
/* 508 */       return cursor;
/*     */     }
/* 510 */     long sourcePixmap = GDK.gdk_bitmap_create_from_data(0L, sourceData, width, height);
/* 511 */     long maskPixmap = GDK.gdk_bitmap_create_from_data(0L, maskData, width, height);
/* 512 */     long cursor = 0L;
/* 513 */     if ((sourcePixmap != 0L) && (maskPixmap != 0L)) {
/* 514 */       GdkColor foreground = new GdkColor();
/* 515 */       if (!reverse) foreground.red = (foreground.green = foreground.blue = -1);
/* 516 */       GdkColor background = new GdkColor();
/* 517 */       if (reverse) background.red = (background.green = background.blue = -1);
/* 518 */       cursor = GDK.gdk_cursor_new_from_pixmap(sourcePixmap, maskPixmap, foreground, background, hotspotX, hotspotY);
/*     */     }
/* 520 */     if (sourcePixmap != 0L) OS.g_object_unref(sourcePixmap);
/* 521 */     if (maskPixmap != 0L) OS.g_object_unref(maskPixmap);
/* 522 */     return cursor;
/*     */   }
/*     */   
/*     */   void destroy()
/*     */   {
/* 527 */     gdk_cursor_unref(this.handle);
/* 528 */     this.handle = 0L;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object object)
/*     */   {
/* 543 */     if (object == this) return true;
/* 544 */     if (!(object instanceof Cursor)) return false;
/* 545 */     Cursor cursor = (Cursor)object;
/* 546 */     return (this.device == cursor.device) && (this.handle == cursor.handle);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Cursor gtk_new(Device device, long handle)
/*     */   {
/* 565 */     Cursor cursor = new Cursor(device);
/* 566 */     cursor.handle = handle;
/* 567 */     return cursor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 582 */     return (int)this.handle;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isDisposed()
/*     */   {
/* 597 */     return this.handle == 0L;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 608 */     if (isDisposed()) return "Cursor {*DISPOSED*}";
/* 609 */     return "Cursor {" + this.handle + "}";
/*     */   }
/*     */   
/*     */   void gdk_cursor_unref(long cursor) {
/* 613 */     if (GTK.GTK3) {
/* 614 */       OS.g_object_unref(cursor);
/*     */     } else {
/* 616 */       GDK.gdk_cursor_unref(cursor);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/graphics/Cursor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */