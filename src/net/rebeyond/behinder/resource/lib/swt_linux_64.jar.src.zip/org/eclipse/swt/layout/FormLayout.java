/*     */ package org.eclipse.swt.layout;
/*     */ 
/*     */ import org.eclipse.swt.graphics.Point;
/*     */ import org.eclipse.swt.graphics.Rectangle;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.swt.widgets.Control;
/*     */ import org.eclipse.swt.widgets.Layout;
/*     */ import org.eclipse.swt.widgets.Scrollable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class FormLayout
/*     */   extends Layout
/*     */ {
/*  97 */   public int marginWidth = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 105 */   public int marginHeight = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 116 */   public int marginLeft = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 126 */   public int marginTop = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 136 */   public int marginRight = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 146 */   public int marginBottom = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 156 */   public int spacing = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   int computeHeight(Control control, FormData data, boolean flushCache)
/*     */   {
/* 225 */     FormAttachment top = data.getTopAttachment(control, this.spacing, flushCache);
/* 226 */     FormAttachment bottom = data.getBottomAttachment(control, this.spacing, flushCache);
/* 227 */     FormAttachment height = bottom.minus(top);
/* 228 */     if (height.numerator == 0) {
/* 229 */       if (bottom.numerator == 0) return bottom.offset;
/* 230 */       if (bottom.numerator == bottom.denominator) return -top.offset;
/* 231 */       if (bottom.offset <= 0) {
/* 232 */         return -top.offset * top.denominator / bottom.numerator;
/*     */       }
/* 234 */       int divider = bottom.denominator - bottom.numerator;
/* 235 */       return bottom.denominator * bottom.offset / divider;
/*     */     }
/* 237 */     return height.solveY(data.getHeight(control, flushCache));
/*     */   }
/*     */   
/*     */   protected Point computeSize(Composite composite, int wHint, int hHint, boolean flushCache)
/*     */   {
/* 242 */     Point size = layout(composite, false, 0, 0, wHint, hHint, flushCache);
/* 243 */     if (wHint != -1) size.x = wHint;
/* 244 */     if (hHint != -1) size.y = hHint;
/* 245 */     return size;
/*     */   }
/*     */   
/*     */   protected boolean flushCache(Control control)
/*     */   {
/* 250 */     Object data = control.getLayoutData();
/* 251 */     if (data != null) ((FormData)data).flushCache();
/* 252 */     return true;
/*     */   }
/*     */   
/*     */   String getName() {
/* 256 */     String string = getClass().getName();
/* 257 */     int index = string.lastIndexOf('.');
/* 258 */     if (index == -1) return string;
/* 259 */     return string.substring(index + 1, string.length());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   int computeWidth(Control control, FormData data, boolean flushCache)
/*     */   {
/* 267 */     FormAttachment left = data.getLeftAttachment(control, this.spacing, flushCache);
/* 268 */     FormAttachment right = data.getRightAttachment(control, this.spacing, flushCache);
/* 269 */     FormAttachment width = right.minus(left);
/* 270 */     if (width.numerator == 0) {
/* 271 */       if (right.numerator == 0) return right.offset;
/* 272 */       if (right.numerator == right.denominator) return -left.offset;
/* 273 */       if (right.offset <= 0) {
/* 274 */         return -left.offset * left.denominator / left.numerator;
/*     */       }
/* 276 */       int divider = right.denominator - right.numerator;
/* 277 */       return right.denominator * right.offset / divider;
/*     */     }
/* 279 */     return width.solveY(data.getWidth(control, flushCache));
/*     */   }
/*     */   
/*     */   protected void layout(Composite composite, boolean flushCache)
/*     */   {
/* 284 */     Rectangle rect = composite.getClientArea();
/* 285 */     int x = rect.x + this.marginLeft + this.marginWidth;
/* 286 */     int y = rect.y + this.marginTop + this.marginHeight;
/* 287 */     int width = Math.max(0, rect.width - this.marginLeft - 2 * this.marginWidth - this.marginRight);
/* 288 */     int height = Math.max(0, rect.height - this.marginTop - 2 * this.marginHeight - this.marginBottom);
/* 289 */     layout(composite, true, x, y, width, height, flushCache);
/*     */   }
/*     */   
/*     */   Point layout(Composite composite, boolean move, int x, int y, int width, int height, boolean flushCache) {
/* 293 */     Control[] children = composite.getChildren();
/* 294 */     for (int i = 0; i < children.length; i++) {
/* 295 */       Control child = children[i];
/* 296 */       FormData data = (FormData)child.getLayoutData();
/* 297 */       if (data == null) child.setLayoutData(data = new FormData());
/* 298 */       if (flushCache) data.flushCache();
/* 299 */       data.cacheLeft = (data.cacheRight = data.cacheTop = data.cacheBottom = null);
/*     */     }
/* 301 */     boolean[] flush = null;
/* 302 */     Rectangle[] bounds = null;
/* 303 */     int w = 0;int h = 0;
/* 304 */     for (int i = 0; i < children.length; i++) {
/* 305 */       Control child = children[i];
/* 306 */       FormData data = (FormData)child.getLayoutData();
/* 307 */       if (width != -1) {
/* 308 */         data.needed = false;
/* 309 */         FormAttachment left = data.getLeftAttachment(child, this.spacing, flushCache);
/* 310 */         FormAttachment right = data.getRightAttachment(child, this.spacing, flushCache);
/* 311 */         int x1 = left.solveX(width);int x2 = right.solveX(width);
/* 312 */         if ((data.height == -1) && (!data.needed)) {
/* 313 */           int trim = 0;
/*     */           
/* 315 */           if ((child instanceof Scrollable)) {
/* 316 */             Rectangle rect = ((Scrollable)child).computeTrim(0, 0, 0, 0);
/* 317 */             trim = rect.width;
/*     */           } else {
/* 319 */             trim = child.getBorderWidth() * 2;
/*     */           }
/* 321 */           data.cacheWidth = (data.cacheHeight = -1);
/* 322 */           int currentWidth = Math.max(0, x2 - x1 - trim);
/* 323 */           data.computeSize(child, currentWidth, data.height, flushCache);
/* 324 */           if (flush == null) flush = new boolean[children.length];
/* 325 */           flush[i] = true;
/*     */         }
/* 327 */         w = Math.max(x2, w);
/* 328 */         if (move) {
/* 329 */           if (bounds == null) bounds = new Rectangle[children.length];
/* 330 */           bounds[i] = new Rectangle(0, 0, 0, 0);
/* 331 */           bounds[i].x = (x + x1);
/* 332 */           bounds[i].width = (x2 - x1);
/*     */         }
/*     */       } else {
/* 335 */         w = Math.max(computeWidth(child, data, flushCache), w);
/*     */       }
/*     */     }
/* 338 */     for (int i = 0; i < children.length; i++) {
/* 339 */       Control child = children[i];
/* 340 */       FormData data = (FormData)child.getLayoutData();
/* 341 */       if (height != -1) {
/* 342 */         int y1 = data.getTopAttachment(child, this.spacing, flushCache).solveX(height);
/* 343 */         int y2 = data.getBottomAttachment(child, this.spacing, flushCache).solveX(height);
/* 344 */         h = Math.max(y2, h);
/* 345 */         if (move) {
/* 346 */           bounds[i].y = (y + y1);
/* 347 */           bounds[i].height = (y2 - y1);
/*     */         }
/*     */       } else {
/* 350 */         h = Math.max(computeHeight(child, data, flushCache), h);
/*     */       }
/*     */     }
/* 353 */     for (int i = 0; i < children.length; i++) {
/* 354 */       Control child = children[i];
/* 355 */       FormData data = (FormData)child.getLayoutData();
/* 356 */       if ((flush != null) && (flush[i] != 0)) data.cacheWidth = (data.cacheHeight = -1);
/* 357 */       data.cacheLeft = (data.cacheRight = data.cacheTop = data.cacheBottom = null);
/*     */     }
/* 359 */     if (move) {
/* 360 */       for (int i = 0; i < children.length; i++) {
/* 361 */         children[i].setBounds(bounds[i]);
/*     */       }
/*     */     }
/* 364 */     w += this.marginLeft + this.marginWidth * 2 + this.marginRight;
/* 365 */     h += this.marginTop + this.marginHeight * 2 + this.marginBottom;
/* 366 */     return new Point(w, h);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 377 */     String string = getName() + " {";
/* 378 */     if (this.marginWidth != 0) string = string + "marginWidth=" + this.marginWidth + " ";
/* 379 */     if (this.marginHeight != 0) string = string + "marginHeight=" + this.marginHeight + " ";
/* 380 */     if (this.marginLeft != 0) string = string + "marginLeft=" + this.marginLeft + " ";
/* 381 */     if (this.marginRight != 0) string = string + "marginRight=" + this.marginRight + " ";
/* 382 */     if (this.marginTop != 0) string = string + "marginTop=" + this.marginTop + " ";
/* 383 */     if (this.marginBottom != 0) string = string + "marginBottom=" + this.marginBottom + " ";
/* 384 */     if (this.spacing != 0) string = string + "spacing=" + this.spacing + " ";
/* 385 */     string = string.trim();
/* 386 */     string = string + "}";
/* 387 */     return string;
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/layout/FormLayout.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */