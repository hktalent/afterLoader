/*    */ package org.eclipse.swt.custom;
/*    */ 
/*    */ import org.eclipse.swt.events.TypedEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ExtendedModifyEvent
/*    */   extends TypedEvent
/*    */ {
/*    */   public int start;
/*    */   public int length;
/*    */   public String replacedText;
/*    */   static final long serialVersionUID = 3258696507027830832L;
/*    */   
/*    */   public ExtendedModifyEvent(StyledTextEvent e)
/*    */   {
/* 37 */     super(e);
/* 38 */     this.start = e.start;
/* 39 */     this.length = (e.end - e.start);
/* 40 */     this.replacedText = e.text;
/*    */   }
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/custom/ExtendedModifyEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */