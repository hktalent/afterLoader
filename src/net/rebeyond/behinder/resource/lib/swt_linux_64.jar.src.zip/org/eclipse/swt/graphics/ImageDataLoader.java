/*    */ package org.eclipse.swt.graphics;
/*    */ 
/*    */ import java.io.InputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ImageDataLoader
/*    */ {
/*    */   public static ImageData[] load(InputStream stream)
/*    */   {
/* 22 */     return new ImageLoader().load(stream);
/*    */   }
/*    */   
/*    */   public static ImageData[] load(String filename) {
/* 26 */     return new ImageLoader().load(filename);
/*    */   }
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/graphics/ImageDataLoader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */