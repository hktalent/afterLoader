package org.eclipse.swt.internal.accessibility.gtk;

public class AtkTextIface
{
  public long get_text;
  public long get_text_after_offset;
  public long get_text_at_offset;
  public long get_character_at_offset;
  public long get_text_before_offset;
  public long get_caret_offset;
  public long get_run_attributes;
  public long get_default_attributes;
  public long get_character_extents;
  public long get_character_count;
  public long get_offset_at_point;
  public long get_n_selections;
  public long get_selection;
  public long add_selection;
  public long remove_selection;
  public long set_selection;
  public long set_caret_offset;
  public long text_changed;
  public long text_caret_moved;
  public long text_selection_changed;
  public long get_range_extents;
  public long get_bounded_ranges;
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/internal/accessibility/gtk/AtkTextIface.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */