/*     */ package org.eclipse.swt.widgets;
/*     */ 
/*     */ import org.eclipse.swt.graphics.Image;
/*     */ import org.eclipse.swt.internal.BidiUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Item
/*     */   extends Widget
/*     */ {
/*     */   String text;
/*     */   Image image;
/*     */   static final int TEXT_LIMIT = 8192;
/*     */   static final String ELLIPSIS = "...";
/*     */   
/*     */   public Item(Widget parent, int style)
/*     */   {
/*  73 */     super(parent, style);
/*  74 */     this.text = "";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Item(Widget parent, int style, int index)
/*     */   {
/* 108 */     this(parent, style);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void checkSubclass() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Image getImage()
/*     */   {
/* 128 */     checkWidget();
/* 129 */     return this.image;
/*     */   }
/*     */   
/*     */   String getNameText()
/*     */   {
/* 134 */     return getText();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getText()
/*     */   {
/* 149 */     checkWidget();
/* 150 */     return this.text;
/*     */   }
/*     */   
/*     */   void releaseWidget()
/*     */   {
/* 155 */     super.releaseWidget();
/* 156 */     this.text = null;
/* 157 */     this.image = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setImage(Image image)
/*     */   {
/* 175 */     checkWidget();
/* 176 */     if ((image != null) && (image.isDisposed())) error(5);
/* 177 */     this.image = image;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setText(String string)
/*     */   {
/* 197 */     checkWidget();
/* 198 */     if (string == null) error(4);
/* 199 */     this.text = string;
/* 200 */     if ((this.state & 0x0) != 0) {
/* 201 */       updateTextDirection(100663296);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   boolean updateTextDirection(int textDirection)
/*     */   {
/* 210 */     if (textDirection == 100663296) {
/* 211 */       this.state |= 0x0;
/* 212 */       textDirection = (this.style ^ BidiUtil.resolveTextDirection(this.text)) == 0 ? 0 : Integer.MIN_VALUE;
/*     */     } else {
/* 214 */       this.state &= 0xFFFFFFFF;
/*     */     }
/* 216 */     if ((this.style & 0x80000000 ^ textDirection) != 0) {
/* 217 */       this.style ^= 0x80000000;
/* 218 */       return true;
/*     */     }
/* 220 */     return textDirection == 100663296;
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/widgets/Item.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */