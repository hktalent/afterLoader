/*     */ package org.eclipse.swt.internal.image;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class LEDataInputStream
/*     */   extends InputStream
/*     */ {
/*     */   int position;
/*     */   InputStream in;
/*     */   protected byte[] buf;
/*     */   protected int pos;
/*     */   
/*     */   public LEDataInputStream(InputStream input)
/*     */   {
/*  34 */     this(input, 512);
/*     */   }
/*     */   
/*     */   public LEDataInputStream(InputStream input, int bufferSize) {
/*  38 */     this.in = input;
/*  39 */     if (bufferSize > 0) {
/*  40 */       this.buf = new byte[bufferSize];
/*  41 */       this.pos = bufferSize;
/*     */     } else {
/*  43 */       throw new IllegalArgumentException();
/*     */     }
/*     */   }
/*     */   
/*     */   public void close() throws IOException {
/*  48 */     this.buf = null;
/*  49 */     if (this.in != null) {
/*  50 */       this.in.close();
/*  51 */       this.in = null;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getPosition()
/*     */   {
/*  59 */     return this.position;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int available()
/*     */     throws IOException
/*     */   {
/*  67 */     if (this.buf == null) throw new IOException();
/*  68 */     return this.buf.length - this.pos + this.in.available();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int read()
/*     */     throws IOException
/*     */   {
/*  76 */     if (this.buf == null) throw new IOException();
/*  77 */     if (this.pos < this.buf.length) {
/*  78 */       this.position += 1;
/*  79 */       return this.buf[(this.pos++)] & 0xFF;
/*     */     }
/*  81 */     int c = this.in.read();
/*  82 */     if (c != -1) this.position += 1;
/*  83 */     return c;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int read(byte[] b, int off, int len)
/*     */     throws IOException
/*     */   {
/*  92 */     int read = 0;
/*  93 */     int count; while ((read != len) && ((count = readData(b, off, len - read)) != -1)) {
/*  94 */       off += count;
/*  95 */       read += count;
/*     */     }
/*  97 */     this.position += read;
/*  98 */     if ((read == 0) && (read != len)) return -1;
/*  99 */     return read;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int readData(byte[] buffer, int offset, int length)
/*     */     throws IOException
/*     */   {
/* 120 */     if (this.buf == null) throw new IOException();
/* 121 */     if ((offset < 0) || (offset > buffer.length) || (length < 0) || (length > buffer.length - offset))
/*     */     {
/* 123 */       throw new ArrayIndexOutOfBoundsException();
/*     */     }
/*     */     
/* 126 */     int cacheCopied = 0;
/* 127 */     int newOffset = offset;
/*     */     
/*     */ 
/* 130 */     int available = this.buf.length - this.pos;
/* 131 */     if (available > 0) {
/* 132 */       cacheCopied = available >= length ? length : available;
/* 133 */       System.arraycopy(this.buf, this.pos, buffer, newOffset, cacheCopied);
/* 134 */       newOffset += cacheCopied;
/* 135 */       this.pos += cacheCopied;
/*     */     }
/*     */     
/*     */ 
/* 139 */     if (cacheCopied == length) { return length;
/*     */     }
/* 141 */     int inCopied = this.in.read(buffer, newOffset, length - cacheCopied);
/*     */     
/* 143 */     if (inCopied > 0) return inCopied + cacheCopied;
/* 144 */     if (cacheCopied == 0) return inCopied;
/* 145 */     return cacheCopied;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int readInt()
/*     */     throws IOException
/*     */   {
/* 153 */     byte[] buf = new byte[4];
/* 154 */     read(buf);
/* 155 */     return (buf[3] & 0xFF) << 24 | (buf[2] & 0xFF) << 16 | (buf[1] & 0xFF) << 8 | buf[0] & 0xFF;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public short readShort()
/*     */     throws IOException
/*     */   {
/* 166 */     byte[] buf = new byte[2];
/* 167 */     read(buf);
/* 168 */     return (short)((buf[1] & 0xFF) << 8 | buf[0] & 0xFF);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void unread(byte[] b)
/*     */     throws IOException
/*     */   {
/* 184 */     int length = b.length;
/* 185 */     if (length > this.pos) throw new IOException();
/* 186 */     this.position -= length;
/* 187 */     this.pos -= length;
/* 188 */     System.arraycopy(b, 0, this.buf, this.pos, length);
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/internal/image/LEDataInputStream.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */