/*     */ package org.eclipse.swt.widgets;
/*     */ 
/*     */ import org.eclipse.swt.graphics.Point;
/*     */ import org.eclipse.swt.internal.gtk.GDK;
/*     */ import org.eclipse.swt.internal.gtk.GTK;
/*     */ import org.eclipse.swt.internal.gtk.OS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ProgressBar
/*     */   extends Control
/*     */ {
/*     */   static final int DELAY = 100;
/*  40 */   int selection = 0; int maximum = 100; int minimum = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   int timerId;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ProgressBar(Composite parent, int style)
/*     */   {
/*  75 */     super(parent, checkStyle(style));
/*     */   }
/*     */   
/*     */   static int checkStyle(int style) {
/*  79 */     style |= 0x80000;
/*  80 */     return checkBits(style, 256, 512, 0, 0, 0, 0);
/*     */   }
/*     */   
/*     */   void createHandle(int index)
/*     */   {
/*  85 */     this.state |= 0x8;
/*  86 */     this.fixedHandle = OS.g_object_new(this.display.gtk_fixed_get_type(), 0L);
/*  87 */     if (this.fixedHandle == 0L) error(2);
/*  88 */     GTK.gtk_widget_set_has_window(this.fixedHandle, true);
/*  89 */     this.handle = GTK.gtk_progress_bar_new();
/*  90 */     if (this.handle == 0L) error(2);
/*  91 */     GTK.gtk_container_add(this.fixedHandle, this.handle);
/*  92 */     int orientation = (this.style & 0x200) != 0 ? 2 : 0;
/*  93 */     gtk_orientable_set_orientation(this.handle, orientation);
/*  94 */     if ((this.style & 0x2) != 0) {
/*  95 */       this.timerId = OS.g_timeout_add(100, this.display.windowTimerProc, this.handle);
/*     */     }
/*     */   }
/*     */   
/*     */   long eventHandle()
/*     */   {
/* 101 */     return GTK.GTK3 ? this.fixedHandle : super.eventHandle();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getMaximum()
/*     */   {
/* 115 */     checkWidget();
/* 116 */     return this.maximum;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getMinimum()
/*     */   {
/* 130 */     checkWidget();
/* 131 */     return this.minimum;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getSelection()
/*     */   {
/* 145 */     checkWidget();
/* 146 */     return this.selection;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getState()
/*     */   {
/* 167 */     checkWidget();
/* 168 */     return 0;
/*     */   }
/*     */   
/*     */   long gtk_realize(long widget)
/*     */   {
/* 173 */     long result = super.gtk_realize(widget);
/* 174 */     if (result != 0L) { return result;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 181 */     updateBar(this.selection, this.minimum, this.maximum);
/* 182 */     return 0L;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   Point resizeCalculationsGTK3(long widget, int width, int height)
/*     */   {
/* 192 */     if (GTK.GTK_VERSION >= OS.VERSION(3, 20, 0))
/*     */     {
/* 194 */       width = Math.max(2, width);
/*     */     }
/* 196 */     return new Point(width, height);
/*     */   }
/*     */   
/*     */   void releaseWidget()
/*     */   {
/* 201 */     super.releaseWidget();
/* 202 */     if (this.timerId != 0) OS.g_source_remove(this.timerId);
/* 203 */     this.timerId = 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void setParentBackground() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMaximum(int value)
/*     */   {
/* 230 */     checkWidget();
/* 231 */     if (value <= this.minimum) return;
/* 232 */     this.maximum = value;
/* 233 */     this.selection = Math.min(this.selection, this.maximum);
/* 234 */     updateBar(this.selection, this.minimum, this.maximum);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMinimum(int value)
/*     */   {
/* 251 */     checkWidget();
/* 252 */     if ((value < 0) || (value >= this.maximum)) return;
/* 253 */     this.minimum = value;
/* 254 */     this.selection = Math.max(this.selection, this.minimum);
/* 255 */     updateBar(this.selection, this.minimum, this.maximum);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSelection(int value)
/*     */   {
/* 271 */     checkWidget();
/* 272 */     this.selection = Math.max(this.minimum, Math.min(this.maximum, value));
/* 273 */     updateBar(this.selection, this.minimum, this.maximum);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setState(int state)
/*     */   {
/* 298 */     checkWidget();
/*     */   }
/*     */   
/*     */ 
/*     */   long timerProc(long widget)
/*     */   {
/* 304 */     if (isVisible()) GTK.gtk_progress_bar_pulse(this.handle);
/* 305 */     return 1L;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void updateBar(int selection, int minimum, int maximum)
/*     */   {
/* 315 */     if (!GTK.gtk_widget_get_realized(this.handle)) { return;
/*     */     }
/* 317 */     double fraction = minimum == maximum ? 1.0D : (selection - minimum) / (maximum - minimum);
/* 318 */     GTK.gtk_progress_bar_set_fraction(this.handle, fraction);
/* 319 */     if (!GTK.GTK3)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 327 */       long window = paintWindow();
/* 328 */       GDK.gdk_window_process_updates(window, false);
/* 329 */       GDK.gdk_flush();
/*     */     }
/*     */   }
/*     */   
/*     */   void gtk_orientable_set_orientation(long pbar, int orientation) {
/* 334 */     if (GTK.GTK3) {
/* 335 */       switch (orientation) {
/*     */       case 2: 
/* 337 */         GTK.gtk_orientable_set_orientation(pbar, 1);
/* 338 */         GTK.gtk_progress_bar_set_inverted(pbar, true);
/* 339 */         break;
/*     */       case 0: 
/* 341 */         GTK.gtk_orientable_set_orientation(pbar, 0);
/* 342 */         GTK.gtk_progress_bar_set_inverted(pbar, false);
/*     */       }
/*     */       
/*     */     } else {
/* 346 */       GTK.gtk_progress_bar_set_orientation(pbar, orientation);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/widgets/ProgressBar.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */