/*     */ package org.eclipse.swt.graphics;
/*     */ 
/*     */ import org.eclipse.swt.SWT;
/*     */ import org.eclipse.swt.internal.gtk.GDK;
/*     */ import org.eclipse.swt.internal.gtk.GTK;
/*     */ import org.eclipse.swt.internal.gtk.GdkColor;
/*     */ import org.eclipse.swt.internal.gtk.GdkRGBA;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Color
/*     */   extends Resource
/*     */ {
/*     */   public GdkColor handle;
/*     */   public GdkRGBA handleRGBA;
/*  62 */   int alpha = 0;
/*     */   
/*     */   Color(Device device) {
/*  65 */     super(device);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Color(Device device, int red, int green, int blue)
/*     */   {
/*  93 */     super(device);
/*  94 */     init(red, green, blue, 255);
/*  95 */     init();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Color(Device device, int red, int green, int blue, int alpha)
/*     */   {
/* 125 */     super(device);
/* 126 */     init(red, green, blue, alpha);
/* 127 */     init();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Color(Device device, RGB rgb)
/*     */   {
/* 153 */     super(device);
/* 154 */     if (rgb == null) SWT.error(4);
/* 155 */     init(rgb.red, rgb.green, rgb.blue, 255);
/* 156 */     init();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Color(Device device, RGBA rgba)
/*     */   {
/* 183 */     super(device);
/* 184 */     if (rgba == null) SWT.error(4);
/* 185 */     init(rgba.rgb.red, rgba.rgb.green, rgba.rgb.blue, rgba.alpha);
/* 186 */     init();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Color(Device device, RGB rgb, int alpha)
/*     */   {
/* 215 */     super(device);
/* 216 */     if (rgb == null) SWT.error(4);
/* 217 */     init(rgb.red, rgb.green, rgb.blue, alpha);
/* 218 */     init();
/*     */   }
/*     */   
/*     */   void destroy()
/*     */   {
/* 223 */     if (GTK.GTK3) {
/* 224 */       this.handleRGBA = null;
/*     */     } else {
/* 226 */       int pixel = this.handle.pixel;
/* 227 */       if (this.device.colorRefCount != null)
/*     */       {
/* 229 */         if (this.device.colorRefCount[pixel] -= 1 == 0) {
/* 230 */           this.device.gdkColors[pixel] = null;
/*     */         }
/*     */       }
/* 233 */       long colormap = GDK.gdk_colormap_get_system();
/* 234 */       GDK.gdk_colormap_free_colors(colormap, this.handle, 1);
/* 235 */       this.handle = null;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object object)
/*     */   {
/* 251 */     if (object == this) return true;
/* 252 */     if (!(object instanceof Color)) return false;
/* 253 */     Color color = (Color)object;
/* 254 */     if (GTK.GTK3) {
/* 255 */       GdkRGBA gdkRGBA = color.handleRGBA;
/* 256 */       if (this.handleRGBA == gdkRGBA) return true;
/* 257 */       return (this.device == color.device) && (Double.compare(this.handleRGBA.red, gdkRGBA.red) == 0) && 
/* 258 */         (Double.compare(this.handleRGBA.green, gdkRGBA.green) == 0) && (Double.compare(this.handleRGBA.blue, gdkRGBA.blue) == 0) && 
/* 259 */         (Double.compare(this.handleRGBA.alpha, gdkRGBA.alpha) == 0);
/*     */     }
/* 261 */     GdkColor gdkColor = color.handle;
/* 262 */     if (this.handle == gdkColor) return true;
/* 263 */     return (this.device == color.device) && (this.handle.red == gdkColor.red) && (this.handle.green == gdkColor.green) && (this.handle.blue == gdkColor.blue) && (this.alpha == color.alpha);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getAlpha()
/*     */   {
/* 280 */     if (isDisposed()) SWT.error(44);
/* 281 */     return this.alpha;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getBlue()
/*     */   {
/* 294 */     if (isDisposed()) SWT.error(44);
/* 295 */     if (GTK.GTK3) {
/* 296 */       return (int)(this.handleRGBA.blue * 255.0D) & 0xFF;
/*     */     }
/* 298 */     return this.handle.blue >> 8 & 0xFF;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getGreen()
/*     */   {
/* 312 */     if (isDisposed()) SWT.error(44);
/* 313 */     if (GTK.GTK3) {
/* 314 */       return (int)(this.handleRGBA.green * 255.0D) & 0xFF;
/*     */     }
/* 316 */     return this.handle.green >> 8 & 0xFF;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getRed()
/*     */   {
/* 330 */     if (isDisposed()) SWT.error(44);
/* 331 */     if (GTK.GTK3) {
/* 332 */       return (int)(this.handleRGBA.red * 255.0D) & 0xFF;
/*     */     }
/* 334 */     return this.handle.red >> 8 & 0xFF;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 350 */     if (isDisposed()) return 0;
/* 351 */     if (GTK.GTK3) {
/* 352 */       return 
/* 353 */         Double.hashCode(this.handleRGBA.red) ^ Double.hashCode(this.handleRGBA.green) ^ Double.hashCode(this.handleRGBA.blue) ^ Double.hashCode(this.handleRGBA.alpha);
/*     */     }
/* 355 */     return this.handle.red ^ this.handle.green ^ this.handle.blue ^ this.alpha;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RGB getRGB()
/*     */   {
/* 369 */     if (isDisposed()) SWT.error(44);
/* 370 */     return new RGB(getRed(), getGreen(), getBlue());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RGBA getRGBA()
/*     */   {
/* 384 */     if (isDisposed()) SWT.error(44);
/* 385 */     return new RGBA(getRed(), getGreen(), getBlue(), getAlpha());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Color gtk_new(Device device, GdkColor gdkColor)
/*     */   {
/* 404 */     assert (!GTK.GTK3) : "GTK2 code was run by GTK3";
/* 405 */     return gtk_new(device, gdkColor, 255);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Color gtk_new(Device device, GdkRGBA gdkRGBA)
/*     */   {
/* 424 */     assert (GTK.GTK3) : "GTK3 code was run by GTK2";
/* 425 */     Color color = new Color(device);
/* 426 */     color.handleRGBA = gdkRGBA;
/* 427 */     color.alpha = ((int)(gdkRGBA.alpha * 255.0D));
/* 428 */     return color;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Color gtk_new(Device device, GdkColor gdkColor, int alpha)
/*     */   {
/* 448 */     assert (!GTK.GTK3) : "GTK2 code was run by GTK3";
/* 449 */     Color color = new Color(device);
/* 450 */     color.handle = gdkColor;
/* 451 */     color.alpha = alpha;
/* 452 */     return color;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Color gtk_new(Device device, GdkRGBA gdkRGBA, int alpha)
/*     */   {
/* 472 */     assert (GTK.GTK3) : "GTK3 code was run by GTK2";
/* 473 */     Color color = new Color(device);
/* 474 */     color.handleRGBA = gdkRGBA;
/* 475 */     color.alpha = alpha;
/* 476 */     return color;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void init(int red, int green, int blue, int alpha)
/*     */   {
/* 496 */     if ((red > 255) || (red < 0) || (green > 255) || (green < 0) || (blue > 255) || (blue < 0) || (alpha > 255) || (alpha < 0))
/*     */     {
/*     */ 
/*     */ 
/* 500 */       SWT.error(5);
/*     */     }
/* 502 */     if (!GTK.GTK3) {
/* 503 */       GdkColor gdkColor = new GdkColor();
/* 504 */       gdkColor.red = ((short)(red & 0xFF | (red & 0xFF) << 8));
/* 505 */       gdkColor.green = ((short)(green & 0xFF | (green & 0xFF) << 8));
/* 506 */       gdkColor.blue = ((short)(blue & 0xFF | (blue & 0xFF) << 8));
/* 507 */       this.alpha = alpha;
/* 508 */       long colormap = GDK.gdk_colormap_get_system();
/* 509 */       if (!GDK.gdk_colormap_alloc_color(colormap, gdkColor, true, true))
/*     */       {
/* 511 */         gdkColor = new GdkColor();
/* 512 */         GDK.gdk_colormap_alloc_color(colormap, gdkColor, true, true);
/*     */       }
/* 514 */       this.handle = gdkColor;
/* 515 */       if (this.device.colorRefCount != null)
/*     */       {
/* 517 */         GdkColor colorCopy = new GdkColor();
/* 518 */         colorCopy.red = this.handle.red;
/* 519 */         colorCopy.green = this.handle.green;
/* 520 */         colorCopy.blue = this.handle.blue;
/* 521 */         colorCopy.pixel = this.handle.pixel;
/* 522 */         this.device.gdkColors[colorCopy.pixel] = colorCopy;
/* 523 */         this.device.colorRefCount[colorCopy.pixel] += 1;
/*     */       }
/*     */     }
/*     */     else {
/* 527 */       GdkRGBA rgba = new GdkRGBA();
/* 528 */       rgba.red = (red / 255.0D);
/* 529 */       rgba.green = (green / 255.0D);
/* 530 */       rgba.blue = (blue / 255.0D);
/* 531 */       rgba.alpha = (alpha / 255.0D);
/* 532 */       this.alpha = alpha;
/* 533 */       this.handleRGBA = rgba;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isDisposed()
/*     */   {
/* 550 */     if (GTK.GTK3) {
/* 551 */       return this.handleRGBA == null;
/*     */     }
/* 553 */     return this.handle == null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 565 */     if (isDisposed()) return "Color {*DISPOSED*}";
/* 566 */     return "Color {" + getRed() + ", " + getGreen() + ", " + getBlue() + ", " + getAlpha() + "}";
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/graphics/Color.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */