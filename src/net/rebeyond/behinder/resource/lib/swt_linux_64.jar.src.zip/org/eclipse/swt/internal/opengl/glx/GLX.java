/*     */ package org.eclipse.swt.internal.opengl.glx;
/*     */ 
/*     */ import org.eclipse.swt.internal.Library;
/*     */ import org.eclipse.swt.internal.Lock;
/*     */ 
/*     */ public class GLX extends org.eclipse.swt.internal.Platform
/*     */ {
/*     */   public static final int GLX_USE_GL = 1;
/*     */   public static final int GLX_BUFFER_SIZE = 2;
/*     */   public static final int GLX_LEVEL = 3;
/*     */   public static final int GLX_RGBA = 4;
/*     */   public static final int GLX_DOUBLEBUFFER = 5;
/*     */   public static final int GLX_STEREO = 6;
/*     */   
/*     */   static
/*     */   {
/*  17 */     Library.loadLibrary("swt-glx");
/*     */   }
/*     */   
/*     */ 
/*     */   public static final int GLX_AUX_BUFFERS = 7;
/*     */   
/*     */   public static final int GLX_RED_SIZE = 8;
/*     */   
/*     */   public static final int GLX_GREEN_SIZE = 9;
/*     */   
/*     */   public static final int GLX_BLUE_SIZE = 10;
/*     */   
/*     */   public static final int GLX_ALPHA_SIZE = 11;
/*     */   
/*     */   public static final int GLX_DEPTH_SIZE = 12;
/*     */   
/*     */   public static final int GLX_STENCIL_SIZE = 13;
/*     */   
/*     */   public static final int GLX_ACCUM_RED_SIZE = 14;
/*     */   
/*     */   public static final int GLX_ACCUM_GREEN_SIZE = 15;
/*     */   
/*     */   public static final int GLX_ACCUM_BLUE_SIZE = 16;
/*     */   
/*     */   public static final int GLX_ACCUM_ALPHA_SIZE = 17;
/*     */   
/*     */   public static final int GLX_X_VISUAL_TYPE = 34;
/*     */   
/*     */   public static final int GLX_CONFIG_CAVEAT = 32;
/*     */   
/*     */   public static final int GLX_TRANSPARENT_TYPE = 35;
/*     */   
/*     */   public static final int GLX_TRANSPARENT_INDEX_VALUE = 36;
/*     */   
/*     */   public static final int GLX_TRANSPARENT_RED_VALUE = 37;
/*     */   
/*     */   public static final int GLX_TRANSPARENT_GREEN_VALUE = 38;
/*     */   
/*     */   public static final int GLX_TRANSPARENT_BLUE_VALUE = 39;
/*     */   
/*     */   public static final int GLX_TRANSPARENT_ALPHA_VALUE = 40;
/*     */   
/*     */   public static final int GLX_DRAWABLE_TYPE = 32784;
/*     */   
/*     */   public static final int GLX_RENDER_TYPE = 32785;
/*     */   
/*     */   public static final int GLX_X_RENDERABLE = 32786;
/*     */   
/*     */   public static final int GLX_FBCONFIG_ID = 32787;
/*     */   
/*     */   public static final int GLX_MAX_PBUFFER_WIDTH = 32790;
/*     */   
/*     */   public static final int GLX_MAX_PBUFFER_HEIGHT = 32791;
/*     */   
/*     */   public static final int GLX_MAX_PBUFFER_PIXELS = 32792;
/*     */   
/*     */   public static final int GLX_VISUAL_ID = 32779;
/*     */   
/*     */   public static final int GLX_BAD_SCREEN = 1;
/*     */   
/*     */   public static final int GLX_BAD_ATTRIBUTE = 2;
/*     */   
/*     */   public static final int GLX_NO_EXTENSION = 3;
/*     */   
/*     */   public static final int GLX_BAD_VISUAL = 4;
/*     */   
/*     */   public static final int GLX_BAD_CONTEXT = 5;
/*     */   
/*     */   public static final int GLX_BAD_VALUE = 6;
/*     */   
/*     */   public static final int GLX_BAD_ENUM = 7;
/*     */   
/*     */   public static final int GLX_DONT_CARE = -1;
/*     */   
/*     */   public static final int GLX_RGBA_BIT = 1;
/*     */   
/*     */   public static final int GLX_COLOR_INDEX_BIT = 2;
/*     */   
/*     */   public static final int GLX_WINDOW_BIT = 1;
/*     */   
/*     */   public static final int GLX_PIXMAP_BIT = 2;
/*     */   
/*     */   public static final int GLX_PBUFFER_BIT = 4;
/*     */   
/*     */   public static final int GLX_NONE = 32768;
/*     */   
/*     */   public static final int GLX_SLOW_CONFIG = 32769;
/*     */   
/*     */   public static final int GLX_NON_CONFORMANT_CONFIG = 32781;
/*     */   
/*     */   public static final int GLX_TRUE_COLOR = 32770;
/*     */   
/*     */   public static final int GLX_DIRECT_COLOR = 32771;
/*     */   
/*     */   public static final int GLX_PSEUDO_COLOR = 32772;
/*     */   
/*     */   public static final int GLX_STATIC_COLOR = 32773;
/*     */   
/*     */   public static final int GLX_GRAY_SCALE = 32774;
/*     */   
/*     */   public static final int GLX_STATIC_GRAY = 32775;
/*     */   
/*     */   public static final int GLX_TRANSPARENT_RGB = 32776;
/*     */   
/*     */   public static final int GLX_TRANSPARENT_INDEX = 32777;
/*     */   
/*     */   public static final int GLX_PRESERVED_CONTENTS = 32795;
/*     */   
/*     */   public static final int GLX_LARGEST_PBUFFER = 32796;
/*     */   
/*     */   public static final int GLX_PBUFFER_HEIGHT = 32832;
/*     */   
/*     */   public static final int GLX_PBUFFER_WIDTH = 32833;
/*     */   
/*     */   public static final int GLX_WIDTH = 32797;
/*     */   
/*     */   public static final int GLX_HEIGHT = 32798;
/*     */   
/*     */   public static final int GLX_EVENT_MASK = 32799;
/*     */   
/*     */   public static final int GLX_RGBA_TYPE = 32788;
/*     */   
/*     */   public static final int GLX_COLOR_INDEX_TYPE = 32789;
/*     */   
/*     */   public static final int GLX_SCREEN = 32780;
/*     */   
/*     */   public static final int GLX_PBUFFER_CLOBBER_MASK = 134217728;
/*     */   
/*     */   public static final int GLX_DAMAGED = 32800;
/*     */   
/*     */   public static final int GLX_SAVED = 32801;
/*     */   
/*     */   public static final int GLX_WINDOW = 32802;
/*     */   
/*     */   public static final int GLX_PBUFFER = 32803;
/*     */   
/*     */   public static final int GLX_FRONT_LEFT_BUFFER_BIT = 1;
/*     */   
/*     */   public static final int GLX_FRONT_RIGHT_BUFFER_BIT = 2;
/*     */   
/*     */   public static final int GLX_BACK_LEFT_BUFFER_BIT = 4;
/*     */   
/*     */   public static final int GLX_BACK_RIGHT_BUFFER_BIT = 8;
/*     */   
/*     */   public static final int GLX_AUX_BUFFERS_BIT = 16;
/*     */   
/*     */   public static final int GLX_DEPTH_BUFFER_BIT = 32;
/*     */   
/*     */   public static final int GLX_STENCIL_BUFFER_BIT = 64;
/*     */   
/*     */   public static final int GLX_ACCUM_BUFFER_BIT = 128;
/*     */   
/*     */   public static final int GLX_X_VISUAL_TYPE_EXT = 34;
/*     */   
/*     */   public static final int GLX_TRANSPARENT_TYPE_EXT = 35;
/*     */   
/*     */   public static final int GLX_TRANSPARENT_INDEX_VALUE_EXT = 36;
/*     */   
/*     */   public static final int GLX_TRANSPARENT_RED_VALUE_EXT = 37;
/*     */   
/*     */   public static final int GLX_TRANSPARENT_GREEN_VALUE_EXT = 38;
/*     */   
/*     */   public static final int GLX_TRANSPARENT_BLUE_VALUE_EXT = 39;
/*     */   
/*     */   public static final int GLX_TRANSPARENT_ALPHA_VALUE_EXT = 40;
/*     */   
/*     */   public static final int GLX_TRUE_COLOR_EXT = 32770;
/*     */   
/*     */   public static final int GLX_DIRECT_COLOR_EXT = 32771;
/*     */   
/*     */   public static final int GLX_PSEUDO_COLOR_EXT = 32772;
/*     */   
/*     */   public static final int GLX_STATIC_COLOR_EXT = 32773;
/*     */   
/*     */   public static final int GLX_GRAY_SCALE_EXT = 32774;
/*     */   
/*     */   public static final int GLX_STATIC_GRAY_EXT = 32775;
/*     */   
/*     */   public static final int GLX_NONE_EXT = 32768;
/*     */   
/*     */   public static final int GLX_TRANSPARENT_RGB_EXT = 32776;
/*     */   
/*     */   public static final int GLX_TRANSPARENT_INDEX_EXT = 32777;
/*     */   
/*     */   public static final int GLX_VISUAL_CAVEAT_EXT = 32;
/*     */   
/*     */   public static final int GLX_SLOW_VISUAL_EXT = 32769;
/*     */   
/*     */   public static final int GLX_NON_CONFORMANT_VISUAL_EXT = 32781;
/*     */   
/*     */   public static final int GLX_VENDOR = 1;
/*     */   
/*     */   public static final int GLX_VERSION = 2;
/*     */   
/*     */   public static final int GLX_EXTENSIONS = 3;
/*     */   
/*     */   public static final int GLX_SHARE_CONTEXT_EXT = 32778;
/*     */   
/*     */   public static final int GLX_VISUAL_ID_EXT = 32779;
/*     */   
/*     */   public static final int GLX_SCREEN_EXT = 32780;
/*     */   
/*     */   public static final int GLX_SAMPLE_BUFFERS = 100000;
/*     */   
/*     */   public static final int GLX_SAMPLES = 100001;
/*     */   
/*     */   public static final int GL_VIEWPORT = 2978;
/*     */   public static final void glViewport(int x, int y, int width, int height)
/*     */   {
/* 226 */     lock.lock();
/*     */     try {
/* 228 */       _glViewport(x, y, width, height);
/*     */     } finally {
/* 230 */       lock.unlock();
/*     */     }
/*     */   }
/*     */   
/*     */   public static final long glXChooseVisual(long dpy, int screen, int[] attribList)
/*     */   {
/* 236 */     lock.lock();
/*     */     try {
/* 238 */       return _glXChooseVisual(dpy, screen, attribList);
/*     */     } finally {
/* 240 */       lock.unlock();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final long glXCreateContext(long dpy, XVisualInfo vis, long shareList, boolean direct)
/*     */   {
/* 249 */     lock.lock();
/*     */     try {
/* 251 */       return _glXCreateContext(dpy, vis, shareList, direct);
/*     */     } finally {
/* 253 */       lock.unlock();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final void glXDestroyContext(long dpy, long ctx)
/*     */   {
/* 262 */     lock.lock();
/*     */     try {
/* 264 */       _glXDestroyContext(dpy, ctx);
/*     */     } finally {
/* 266 */       lock.unlock();
/*     */     }
/*     */   }
/*     */   
/*     */   public static final int glXGetConfig(long dpy, XVisualInfo vis, int attrib, int[] value)
/*     */   {
/* 272 */     lock.lock();
/*     */     try {
/* 274 */       return _glXGetConfig(dpy, vis, attrib, value);
/*     */     } finally {
/* 276 */       lock.unlock();
/*     */     }
/*     */   }
/*     */   
/*     */   public static final long glXGetCurrentContext() {
/* 281 */     lock.lock();
/*     */     try {
/* 283 */       return _glXGetCurrentContext();
/*     */     } finally {
/* 285 */       lock.unlock();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final boolean glXMakeCurrent(long dpy, long drawable, long ctx)
/*     */   {
/* 295 */     lock.lock();
/*     */     try {
/* 297 */       return _glXMakeCurrent(dpy, drawable, ctx);
/*     */     } finally {
/* 299 */       lock.unlock();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final void glXSwapBuffers(long dpy, long drawable)
/*     */   {
/* 308 */     lock.lock();
/*     */     try {
/* 310 */       _glXSwapBuffers(dpy, drawable);
/*     */     } finally {
/* 312 */       lock.unlock();
/*     */     }
/*     */   }
/*     */   
/*     */   public static final native int XVisualInfo_sizeof();
/*     */   
/*     */   public static final native void _glGetIntegerv(int paramInt, int[] paramArrayOfInt);
/*     */   
/*     */   /* Error */
/*     */   public static final void glGetIntegerv(int pname, int[] params)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: getstatic 2	org/eclipse/swt/internal/opengl/glx/GLX:lock	Lorg/eclipse/swt/internal/Lock;
/*     */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*     */     //   6: pop
/*     */     //   7: iload_0
/*     */     //   8: aload_1
/*     */     //   9: invokestatic 4	org/eclipse/swt/internal/opengl/glx/GLX:_glGetIntegerv	(I[I)V
/*     */     //   12: getstatic 2	org/eclipse/swt/internal/opengl/glx/GLX:lock	Lorg/eclipse/swt/internal/Lock;
/*     */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*     */     //   18: goto +12 -> 30
/*     */     //   21: astore_2
/*     */     //   22: getstatic 2	org/eclipse/swt/internal/opengl/glx/GLX:lock	Lorg/eclipse/swt/internal/Lock;
/*     */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*     */     //   28: aload_2
/*     */     //   29: athrow
/*     */     //   30: return
/*     */     // Line number table:
/*     */     //   Java source line #211	-> byte code offset #0
/*     */     //   Java source line #213	-> byte code offset #7
/*     */     //   Java source line #215	-> byte code offset #12
/*     */     //   Java source line #216	-> byte code offset #18
/*     */     //   Java source line #215	-> byte code offset #21
/*     */     //   Java source line #216	-> byte code offset #28
/*     */     //   Java source line #217	-> byte code offset #30
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	31	0	pname	int
/*     */     //   0	31	1	params	int[]
/*     */     //   21	8	2	localObject	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   7	12	21	finally
/*     */   }
/*     */   
/*     */   public static final native void _glViewport(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
/*     */   
/*     */   public static final native long _glXChooseVisual(long paramLong, int paramInt, int[] paramArrayOfInt);
/*     */   
/*     */   public static final native long _glXCreateContext(long paramLong1, XVisualInfo paramXVisualInfo, long paramLong2, boolean paramBoolean);
/*     */   
/*     */   public static final native void _glXDestroyContext(long paramLong1, long paramLong2);
/*     */   
/*     */   public static final native int _glXGetConfig(long paramLong, XVisualInfo paramXVisualInfo, int paramInt, int[] paramArrayOfInt);
/*     */   
/*     */   public static final native long _glXGetCurrentContext();
/*     */   
/*     */   public static final native boolean _glXMakeCurrent(long paramLong1, long paramLong2, long paramLong3);
/*     */   
/*     */   public static final native void _glXSwapBuffers(long paramLong1, long paramLong2);
/*     */   
/*     */   public static final native void memmove(XVisualInfo paramXVisualInfo, long paramLong, int paramInt);
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/internal/opengl/glx/GLX.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */