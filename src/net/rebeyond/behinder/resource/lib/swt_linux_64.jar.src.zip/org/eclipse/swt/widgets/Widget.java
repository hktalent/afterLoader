/*      */ package org.eclipse.swt.widgets;
/*      */ 
/*      */ import org.eclipse.swt.SWT;
/*      */ import org.eclipse.swt.events.DisposeListener;
/*      */ import org.eclipse.swt.internal.C;
/*      */ import org.eclipse.swt.internal.Callback;
/*      */ import org.eclipse.swt.internal.Converter;
/*      */ import org.eclipse.swt.internal.SWTEventListener;
/*      */ import org.eclipse.swt.internal.gtk.GDK;
/*      */ import org.eclipse.swt.internal.gtk.GTK;
/*      */ import org.eclipse.swt.internal.gtk.GdkColor;
/*      */ import org.eclipse.swt.internal.gtk.GdkEvent;
/*      */ import org.eclipse.swt.internal.gtk.GdkEventExpose;
/*      */ import org.eclipse.swt.internal.gtk.GdkEventKey;
/*      */ import org.eclipse.swt.internal.gtk.GtkAdjustment;
/*      */ import org.eclipse.swt.internal.gtk.GtkRequisition;
/*      */ import org.eclipse.swt.internal.gtk.OS;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class Widget
/*      */ {
/*      */   public long handle;
/*      */   int style;
/*      */   int state;
/*      */   Display display;
/*      */   EventTable eventTable;
/*      */   Object data;
/*      */   static final int DISPOSED = 1;
/*      */   static final int CANVAS = 2;
/*      */   static final int KEYED_DATA = 4;
/*      */   static final int HANDLE = 8;
/*      */   static final int DISABLED = 16;
/*      */   static final int MENU = 32;
/*      */   static final int OBSCURED = 64;
/*      */   static final int MOVED = 128;
/*      */   static final int RESIZED = 256;
/*      */   static final int ZERO_WIDTH = 512;
/*      */   static final int ZERO_HEIGHT = 1024;
/*      */   static final int HIDDEN = 2048;
/*      */   static final int FOREGROUND = 4096;
/*      */   static final int BACKGROUND = 8192;
/*      */   static final int FONT = 16384;
/*      */   static final int PARENT_BACKGROUND = 32768;
/*      */   static final int THEME_BACKGROUND = 65536;
/*      */   static final int LAYOUT_NEEDED = 131072;
/*      */   static final int LAYOUT_CHANGED = 262144;
/*      */   static final int LAYOUT_CHILD = 524288;
/*      */   static final int RELEASED = 1048576;
/*      */   static final int DISPOSE_SENT = 2097152;
/*      */   static final int FOREIGN_HANDLE = 4194304;
/*      */   static final int DRAG_DETECT = 8388608;
/*      */   static final int SKIN_NEEDED = 16777216;
/*      */   static final int CHECK_SUBWINDOW = 33554432;
/*      */   static final int HAS_AUTO_DIRECTION = 0;
/*      */   static final int AUTO_TEXT_DIRECTION = 100663296;
/*      */   static final int DEFAULT_WIDTH = 64;
/*      */   static final int DEFAULT_HEIGHT = 64;
/*      */   static final int ACTIVATE = 1;
/*      */   static final int BUTTON_PRESS_EVENT = 2;
/*      */   static final int BUTTON_PRESS_EVENT_INVERSE = 3;
/*      */   static final int BUTTON_RELEASE_EVENT = 4;
/*      */   static final int BUTTON_RELEASE_EVENT_INVERSE = 5;
/*      */   static final int CHANGED = 6;
/*      */   static final int CHANGE_VALUE = 7;
/*      */   static final int CLICKED = 8;
/*      */   static final int COMMIT = 9;
/*      */   static final int CONFIGURE_EVENT = 10;
/*      */   static final int DELETE_EVENT = 11;
/*      */   static final int DELETE_RANGE = 12;
/*      */   static final int DELETE_TEXT = 13;
/*      */   static final int ENTER_NOTIFY_EVENT = 14;
/*      */   static final int EVENT = 15;
/*      */   static final int EVENT_AFTER = 16;
/*      */   static final int EXPAND_COLLAPSE_CURSOR_ROW = 17;
/*      */   static final int EXPOSE_EVENT = 18;
/*      */   static final int DRAW = 18;
/*      */   static final int EXPOSE_EVENT_INVERSE = 19;
/*      */   static final int FOCUS = 20;
/*      */   static final int FOCUS_IN_EVENT = 21;
/*      */   static final int FOCUS_OUT_EVENT = 22;
/*      */   static final int GRAB_FOCUS = 23;
/*      */   static final int HIDE = 24;
/*      */   static final int INPUT = 25;
/*      */   static final int INSERT_TEXT = 26;
/*      */   static final int KEY_PRESS_EVENT = 27;
/*      */   static final int KEY_RELEASE_EVENT = 28;
/*      */   static final int LEAVE_NOTIFY_EVENT = 29;
/*      */   static final int MAP = 30;
/*      */   static final int MAP_EVENT = 31;
/*      */   static final int MNEMONIC_ACTIVATE = 32;
/*      */   static final int MOTION_NOTIFY_EVENT = 33;
/*      */   static final int MOTION_NOTIFY_EVENT_INVERSE = 34;
/*      */   static final int MOVE_FOCUS = 35;
/*      */   static final int OUTPUT = 36;
/*      */   static final int POPULATE_POPUP = 37;
/*      */   static final int POPUP_MENU = 38;
/*      */   static final int PREEDIT_CHANGED = 39;
/*      */   static final int REALIZE = 40;
/*      */   static final int ROW_ACTIVATED = 41;
/*      */   static final int SCROLL_CHILD = 42;
/*      */   static final int SCROLL_EVENT = 43;
/*      */   static final int SELECT = 44;
/*      */   static final int SHOW = 45;
/*      */   static final int SHOW_HELP = 46;
/*      */   static final int SIZE_ALLOCATE = 47;
/*      */   static final int STYLE_SET = 48;
/*      */   static final int SWITCH_PAGE = 49;
/*      */   static final int TEST_COLLAPSE_ROW = 50;
/*      */   static final int TEST_EXPAND_ROW = 51;
/*      */   static final int TEXT_BUFFER_INSERT_TEXT = 52;
/*      */   static final int TOGGLED = 53;
/*      */   static final int UNMAP = 54;
/*      */   static final int UNMAP_EVENT = 55;
/*      */   static final int UNREALIZE = 56;
/*      */   static final int VALUE_CHANGED = 57;
/*      */   static final int WINDOW_STATE_EVENT = 59;
/*      */   static final int ACTIVATE_INVERSE = 60;
/*      */   static final int DAY_SELECTED = 61;
/*      */   static final int MONTH_CHANGED = 62;
/*      */   static final int STATUS_ICON_POPUP_MENU = 63;
/*      */   static final int ROW_INSERTED = 64;
/*      */   static final int ROW_DELETED = 65;
/*      */   static final int DAY_SELECTED_DOUBLE_CLICK = 66;
/*      */   static final int ICON_RELEASE = 67;
/*      */   static final int SELECTION_DONE = 68;
/*      */   static final int START_INTERACTIVE_SEARCH = 69;
/*      */   static final int BACKSPACE = 70;
/*      */   static final int BACKSPACE_INVERSE = 71;
/*      */   static final int COPY_CLIPBOARD = 72;
/*      */   static final int COPY_CLIPBOARD_INVERSE = 73;
/*      */   static final int CUT_CLIPBOARD = 74;
/*      */   static final int CUT_CLIPBOARD_INVERSE = 75;
/*      */   static final int PASTE_CLIPBOARD = 76;
/*      */   static final int PASTE_CLIPBOARD_INVERSE = 77;
/*      */   static final int DELETE_FROM_CURSOR = 78;
/*      */   static final int DELETE_FROM_CURSOR_INVERSE = 79;
/*      */   static final int MOVE_CURSOR = 80;
/*      */   static final int MOVE_CURSOR_INVERSE = 81;
/*      */   static final int DIRECTION_CHANGED = 82;
/*      */   static final int CREATE_MENU_PROXY = 83;
/*      */   static final int ROW_HAS_CHILD_TOGGLED = 84;
/*      */   static final int POPPED_UP = 85;
/*      */   static final int LAST_SIGNAL = 86;
/*      */   static final String IS_ACTIVE = "org.eclipse.swt.internal.control.isactive";
/*      */   static final String KEY_CHECK_SUBWINDOW = "org.eclipse.swt.internal.control.checksubwindow";
/*      */   static final String KEY_GTK_CSS = "org.eclipse.swt.internal.gtk.css";
/*      */   
/*      */   Widget() {}
/*      */   
/*      */   public Widget(Widget parent, int style)
/*      */   {
/*  257 */     checkSubclass();
/*  258 */     checkParent(parent);
/*  259 */     this.style = style;
/*  260 */     this.display = parent.display;
/*  261 */     reskinWidget();
/*      */   }
/*      */   
/*      */   void _addListener(int eventType, Listener listener) {
/*  265 */     if (this.eventTable == null) this.eventTable = new EventTable();
/*  266 */     this.eventTable.hook(eventType, listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addListener(int eventType, Listener listener)
/*      */   {
/*  294 */     checkWidget();
/*  295 */     if (listener == null) error(4);
/*  296 */     _addListener(eventType, listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addDisposeListener(DisposeListener listener)
/*      */   {
/*  319 */     checkWidget();
/*  320 */     if (listener == null) error(4);
/*  321 */     TypedListener typedListener = new TypedListener(listener);
/*  322 */     addListener(12, typedListener);
/*      */   }
/*      */   
/*      */   long paintWindow() {
/*  326 */     return 0L;
/*      */   }
/*      */   
/*      */   long cssHandle() {
/*  330 */     return this.handle;
/*      */   }
/*      */   
/*      */   static int checkBits(int style, int int0, int int1, int int2, int int3, int int4, int int5) {
/*  334 */     int mask = int0 | int1 | int2 | int3 | int4 | int5;
/*  335 */     if ((style & mask) == 0) style |= int0;
/*  336 */     if ((style & int0) != 0) style = style & (mask ^ 0xFFFFFFFF) | int0;
/*  337 */     if ((style & int1) != 0) style = style & (mask ^ 0xFFFFFFFF) | int1;
/*  338 */     if ((style & int2) != 0) style = style & (mask ^ 0xFFFFFFFF) | int2;
/*  339 */     if ((style & int3) != 0) style = style & (mask ^ 0xFFFFFFFF) | int3;
/*  340 */     if ((style & int4) != 0) style = style & (mask ^ 0xFFFFFFFF) | int4;
/*  341 */     if ((style & int5) != 0) style = style & (mask ^ 0xFFFFFFFF) | int5;
/*  342 */     return style;
/*      */   }
/*      */   
/*      */   long cellDataProc(long tree_column, long cell, long tree_model, long iter, long data) {
/*  346 */     return 0L;
/*      */   }
/*      */   
/*      */ 
/*      */   void checkOpen() {}
/*      */   
/*      */   void checkOrientation(Widget parent)
/*      */   {
/*  354 */     this.style &= 0xF7FFFFFF;
/*  355 */     if (((this.style & 0x6000000) == 0) && 
/*  356 */       (parent != null)) {
/*  357 */       if ((parent.style & 0x2000000) != 0) this.style |= 0x2000000;
/*  358 */       if ((parent.style & 0x4000000) != 0) { this.style |= 0x4000000;
/*      */       }
/*      */     }
/*  361 */     this.style = checkBits(this.style, 33554432, 67108864, 0, 0, 0, 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void checkParent(Widget parent)
/*      */   {
/*  377 */     if (parent == null) error(4);
/*  378 */     if (parent.isDisposed()) error(5);
/*  379 */     parent.checkWidget();
/*  380 */     parent.checkOpen();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void checkSubclass()
/*      */   {
/*  413 */     if (!isValidSubclass()) { error(43);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void checkWidget()
/*      */   {
/*  439 */     Display display = this.display;
/*  440 */     if (display == null) error(24);
/*  441 */     if (display.thread != Thread.currentThread()) error(22);
/*  442 */     if ((this.state & 0x1) != 0) error(24);
/*      */   }
/*      */   
/*      */   void createHandle(int index) {}
/*      */   
/*      */   void createWidget(int index)
/*      */   {
/*  449 */     createHandle(index);
/*  450 */     setOrientation(true);
/*  451 */     hookEvents();
/*  452 */     register();
/*      */   }
/*      */   
/*      */   void deregister() {
/*  456 */     if (this.handle == 0L) return;
/*  457 */     if ((this.state & 0x8) != 0) this.display.removeWidget(this.handle);
/*      */   }
/*      */   
/*      */   void destroyWidget() {
/*  461 */     long topHandle = topHandle();
/*  462 */     releaseHandle();
/*  463 */     if ((topHandle != 0L) && ((this.state & 0x8) != 0)) {
/*  464 */       GTK.gtk_widget_destroy(topHandle);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void dispose()
/*      */   {
/*  497 */     if (isDisposed()) return;
/*  498 */     if (!isValidThread()) error(22);
/*  499 */     release(true);
/*      */   }
/*      */   
/*      */   void error(int code) {
/*  503 */     SWT.error(code);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object getData()
/*      */   {
/*  529 */     checkWidget();
/*  530 */     return (this.state & 0x4) != 0 ? ((Object[])(Object[])this.data)[0] : this.data;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object getData(String key)
/*      */   {
/*  557 */     checkWidget();
/*  558 */     if (key == null) error(4);
/*  559 */     if (key.equals("org.eclipse.swt.internal.control.checksubwindow")) {
/*  560 */       return new Boolean((this.state & 0x2000000) != 0);
/*      */     }
/*  562 */     if (key.equals("org.eclipse.swt.internal.control.isactive")) return Boolean.valueOf(isActive());
/*  563 */     if ((this.state & 0x4) != 0) {
/*  564 */       Object[] table = (Object[])this.data;
/*  565 */       for (int i = 1; i < table.length; i += 2) {
/*  566 */         if (key.equals(table[i])) return table[(i + 1)];
/*      */       }
/*      */     }
/*  569 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Display getDisplay()
/*      */   {
/*  588 */     Display display = this.display;
/*  589 */     if (display == null) error(24);
/*  590 */     return display;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Listener[] getListeners(int eventType)
/*      */   {
/*  615 */     checkWidget();
/*  616 */     if (this.eventTable == null) return new Listener[0];
/*  617 */     return this.eventTable.getListeners(eventType);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   String getName()
/*      */   {
/*  624 */     String string = getClass().getName();
/*  625 */     int index = string.length();
/*  626 */     do { index--; } while ((index > 0) && (string.charAt(index) != '.'));
/*  627 */     return string.substring(index + 1, string.length());
/*      */   }
/*      */   
/*      */   String getNameText() {
/*  631 */     return "";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getStyle()
/*      */   {
/*  655 */     checkWidget();
/*  656 */     return this.style;
/*      */   }
/*      */   
/*      */   long gtk_activate(long widget)
/*      */   {
/*  661 */     return 0L;
/*      */   }
/*      */   
/*      */   void gtk_adjustment_get(long hAdjustment, GtkAdjustment adjustment) {
/*  665 */     adjustment.lower = GTK.gtk_adjustment_get_lower(hAdjustment);
/*  666 */     adjustment.upper = GTK.gtk_adjustment_get_upper(hAdjustment);
/*  667 */     adjustment.page_increment = GTK.gtk_adjustment_get_page_increment(hAdjustment);
/*  668 */     adjustment.step_increment = GTK.gtk_adjustment_get_step_increment(hAdjustment);
/*  669 */     adjustment.page_size = GTK.gtk_adjustment_get_page_size(hAdjustment);
/*  670 */     adjustment.value = GTK.gtk_adjustment_get_value(hAdjustment);
/*      */   }
/*      */   
/*      */   long gtk_button_press_event(long widget, long event) {
/*  674 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_button_release_event(long widget, long event) {
/*  678 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_changed(long widget) {
/*  682 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_change_value(long widget, long scroll, long value1, long value2) {
/*  686 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_clicked(long widget) {
/*  690 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_commit(long imcontext, long text) {
/*  694 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_configure_event(long widget, long event) {
/*  698 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_create_menu_proxy(long widget) {
/*  702 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_day_selected(long widget) {
/*  706 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_day_selected_double_click(long widget) {
/*  710 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_delete_event(long widget, long event) {
/*  714 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_delete_range(long widget, long iter1, long iter2) {
/*  718 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_delete_text(long widget, long start_pos, long end_pos) {
/*  722 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_enter_notify_event(long widget, long event) {
/*  726 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_event(long widget, long event) {
/*  730 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_event_after(long widget, long event) {
/*  734 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_expand_collapse_cursor_row(long widget, long logical, long expand, long open_all) {
/*  738 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_draw(long widget, long cairo) {
/*  742 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_expose_event(long widget, long event) {
/*  746 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_focus(long widget, long event) {
/*  750 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_focus_in_event(long widget, long event) {
/*  754 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_focus_out_event(long widget, long event) {
/*  758 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_grab_focus(long widget) {
/*  762 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_hide(long widget) {
/*  766 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_icon_release(long widget, long icon_pos, long event) {
/*  770 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_input(long widget, long arg1) {
/*  774 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_insert_text(long widget, long new_text, long new_text_length, long position) {
/*  778 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_key_press_event(long widget, long event) {
/*  782 */     GdkEventKey gdkEvent = new GdkEventKey();
/*  783 */     OS.memmove(gdkEvent, event, GdkEventKey.sizeof);
/*  784 */     return sendKeyEvent(1, gdkEvent) ? 0L : 1L;
/*      */   }
/*      */   
/*      */   long gtk_key_release_event(long widget, long event) {
/*  788 */     GdkEventKey gdkEvent = new GdkEventKey();
/*  789 */     OS.memmove(gdkEvent, event, GdkEventKey.sizeof);
/*  790 */     return sendKeyEvent(2, gdkEvent) ? 0L : 1L;
/*      */   }
/*      */   
/*      */   long gtk_leave_notify_event(long widget, long event) {
/*  794 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_map(long widget) {
/*  798 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_map_event(long widget, long event) {
/*  802 */     return 0L;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   long gtk_menu_popped_up(long widget, long flipped_rect, long final_rect, long flipped_x, long flipped_y)
/*      */   {
/*  823 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_mnemonic_activate(long widget, long arg1) {
/*  827 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_month_changed(long widget) {
/*  831 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_motion_notify_event(long widget, long event) {
/*  835 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_move_focus(long widget, long event) {
/*  839 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_output(long widget) {
/*  843 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_populate_popup(long widget, long menu) {
/*  847 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_popup_menu(long widget) {
/*  851 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_preedit_changed(long imcontext) {
/*  855 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_realize(long widget) {
/*  859 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_row_activated(long tree, long path, long column) {
/*  863 */     return 0L;
/*      */   }
/*      */   
/*      */ 
/*      */   long gtk_row_deleted(long model, long path)
/*      */   {
/*  869 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_row_inserted(long model, long path, long iter) {
/*  873 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_row_has_child_toggled(long model, long path, long iter) {
/*  877 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_scroll_child(long widget, long scrollType, long horizontal) {
/*  881 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_scroll_event(long widget, long event) {
/*  885 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_select(long item) {
/*  889 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_selection_done(long menushell) {
/*  893 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_show(long widget) {
/*  897 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_show_help(long widget, long helpType) {
/*  901 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_size_allocate(long widget, long allocation) {
/*  905 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_status_icon_popup_menu(long handle, long button, long activate_time) {
/*  909 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_start_interactive_search(long widget) {
/*  913 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_style_set(long widget, long previousStyle) {
/*  917 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_switch_page(long widget, long page, long page_num) {
/*  921 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_test_collapse_row(long tree, long iter, long path) {
/*  925 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_test_expand_row(long tree, long iter, long path) {
/*  929 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_text_buffer_insert_text(long widget, long iter, long text, long length) {
/*  933 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_timer() {
/*  937 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_toggled(long renderer, long pathStr) {
/*  941 */     return 0L;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   boolean gtk_tree_view_column_cell_get_position(long column, long cell_renderer, int[] start_pos, int[] width)
/*      */   {
/*  950 */     if (GTK.GTK3) {
/*  951 */       Callback.setEnabled(false);
/*  952 */       boolean result = GTK.gtk_tree_view_column_cell_get_position(column, cell_renderer, start_pos, width);
/*  953 */       Callback.setEnabled(true);
/*  954 */       return result;
/*      */     }
/*  956 */     return GTK.gtk_tree_view_column_cell_get_position(column, cell_renderer, start_pos, width);
/*      */   }
/*      */   
/*      */   long gtk_unmap(long widget)
/*      */   {
/*  961 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_unmap_event(long widget, long event) {
/*  965 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_unrealize(long widget) {
/*  969 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_value_changed(long adjustment) {
/*  973 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_window_state_event(long widget, long event) {
/*  977 */     return 0L;
/*      */   }
/*      */   
/*      */   int fontHeight(long font, long widgetHandle) {
/*  981 */     long context = GTK.gtk_widget_get_pango_context(widgetHandle);
/*  982 */     long lang = OS.pango_context_get_language(context);
/*  983 */     long metrics = OS.pango_context_get_metrics(context, font, lang);
/*  984 */     int ascent = OS.pango_font_metrics_get_ascent(metrics);
/*  985 */     int descent = OS.pango_font_metrics_get_descent(metrics);
/*  986 */     OS.pango_font_metrics_unref(metrics);
/*  987 */     return OS.PANGO_PIXELS(ascent + descent);
/*      */   }
/*      */   
/*      */   long filterProc(long xEvent, long gdkEvent, long data2) {
/*  991 */     return 0L;
/*      */   }
/*      */   
/*      */   boolean filters(int eventType) {
/*  995 */     return this.display.filters(eventType);
/*      */   }
/*      */   
/*      */   long fixedMapProc(long widget) {
/*  999 */     return 0L;
/*      */   }
/*      */   
/*      */   long fixedSizeAllocateProc(long widget, long allocationPtr) {
/* 1003 */     return OS.Call(Display.oldFixedSizeAllocateProc, widget, allocationPtr);
/*      */   }
/*      */   
/*      */   char[] fixMnemonic(String string) {
/* 1007 */     return fixMnemonic(string, true);
/*      */   }
/*      */   
/*      */   char[] fixMnemonic(String string, boolean replace) {
/* 1011 */     int length = string.length();
/* 1012 */     char[] text = new char[length];
/* 1013 */     string.getChars(0, length, text, 0);
/* 1014 */     int i = 0;int j = 0;
/* 1015 */     char[] result = new char[length * 2];
/* 1016 */     while (i < length) {
/* 1017 */       switch (text[i]) {
/*      */       case '&': 
/* 1019 */         if ((i + 1 < length) && (text[(i + 1)] == '&')) {
/* 1020 */           result[(j++)] = text[(i++)];
/*      */         }
/* 1022 */         else if (replace) { result[(j++)] = '_';
/*      */         }
/* 1024 */         i++;
/* 1025 */         break;
/*      */       case '_': 
/* 1027 */         if (replace) { result[(j++)] = '_';
/*      */         }
/*      */       default: 
/* 1030 */         result[(j++)] = text[(i++)];
/*      */       }
/*      */     }
/* 1033 */     return result;
/*      */   }
/*      */   
/*      */   boolean isActive() {
/* 1037 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isAutoDirection()
/*      */   {
/* 1051 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isDisposed()
/*      */   {
/* 1066 */     return (this.state & 0x1) != 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isListening(int eventType)
/*      */   {
/* 1086 */     checkWidget();
/* 1087 */     return hooks(eventType);
/*      */   }
/*      */   
/*      */   boolean isValidThread() {
/* 1091 */     return getDisplay().isValidThread();
/*      */   }
/*      */   
/*      */   boolean isValidSubclass() {
/* 1095 */     return Display.isValidClass(getClass());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void hookEvents() {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   boolean hooks(int eventType)
/*      */   {
/* 1115 */     if (this.eventTable == null) return false;
/* 1116 */     return this.eventTable.hooks(eventType);
/*      */   }
/*      */   
/*      */   long hoverProc(long widget) {
/* 1120 */     return 0L;
/*      */   }
/*      */   
/*      */   boolean mnemonicHit(long mnemonicHandle, char key) {
/* 1124 */     if (!mnemonicMatch(mnemonicHandle, key)) return false;
/* 1125 */     OS.g_signal_handlers_block_matched(mnemonicHandle, 16, 0, 0, 0L, 0L, 32L);
/* 1126 */     boolean result = GTK.gtk_widget_mnemonic_activate(mnemonicHandle, false);
/* 1127 */     OS.g_signal_handlers_unblock_matched(mnemonicHandle, 16, 0, 0, 0L, 0L, 32L);
/* 1128 */     return result;
/*      */   }
/*      */   
/*      */   boolean mnemonicMatch(long mnemonicHandle, char key) {
/* 1132 */     long keyval1 = GDK.gdk_keyval_to_lower(GDK.gdk_unicode_to_keyval(key));
/* 1133 */     long keyval2 = GDK.gdk_keyval_to_lower(GTK.gtk_label_get_mnemonic_keyval(mnemonicHandle));
/* 1134 */     return keyval1 == keyval2;
/*      */   }
/*      */   
/*      */   void modifyStyle(long handle, long style) {
/* 1138 */     GTK.gtk_widget_modify_style(handle, style);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void notifyListeners(int eventType, Event event)
/*      */   {
/* 1162 */     checkWidget();
/* 1163 */     if (event == null) event = new Event();
/* 1164 */     sendEvent(eventType, event);
/*      */   }
/*      */   
/*      */   void postEvent(int eventType) {
/* 1168 */     sendEvent(eventType, null, false);
/*      */   }
/*      */   
/*      */   void postEvent(int eventType, Event event) {
/* 1172 */     sendEvent(eventType, event, false);
/*      */   }
/*      */   
/*      */   void register() {
/* 1176 */     if (this.handle == 0L) return;
/* 1177 */     if ((this.state & 0x8) != 0) this.display.addWidget(this.handle, this);
/*      */   }
/*      */   
/*      */   void release(boolean destroy) {
/* 1181 */     if ((this.state & 0x200000) == 0) {
/* 1182 */       this.state |= 0x200000;
/* 1183 */       sendEvent(12);
/*      */     }
/* 1185 */     if ((this.state & 0x1) == 0) {
/* 1186 */       releaseChildren(destroy);
/*      */     }
/* 1188 */     if ((this.state & 0x100000) == 0) {
/* 1189 */       this.state |= 0x100000;
/* 1190 */       if (destroy) {
/* 1191 */         releaseParent();
/* 1192 */         releaseWidget();
/* 1193 */         destroyWidget();
/*      */       } else {
/* 1195 */         releaseWidget();
/* 1196 */         releaseHandle();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   void releaseChildren(boolean destroy) {}
/*      */   
/*      */   void releaseHandle()
/*      */   {
/* 1205 */     this.handle = 0L;
/* 1206 */     this.state |= 0x1;
/* 1207 */     this.display = null;
/*      */   }
/*      */   
/*      */ 
/*      */   void releaseParent() {}
/*      */   
/*      */   void releaseWidget()
/*      */   {
/* 1215 */     deregister();
/* 1216 */     this.eventTable = null;
/* 1217 */     this.data = null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeListener(int eventType, Listener listener)
/*      */   {
/* 1243 */     checkWidget();
/* 1244 */     if (listener == null) error(4);
/* 1245 */     if (this.eventTable == null) return;
/* 1246 */     this.eventTable.unhook(eventType, listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void removeListener(int eventType, SWTEventListener handler)
/*      */   {
/* 1277 */     checkWidget();
/* 1278 */     if (handler == null) error(4);
/* 1279 */     if (this.eventTable == null) return;
/* 1280 */     this.eventTable.unhook(eventType, handler);
/*      */   }
/*      */   
/*      */   long rendererGetPreferredWidthProc(long cell, long handle, long minimun_size, long natural_size) {
/* 1284 */     return 0L;
/*      */   }
/*      */   
/*      */   long rendererGetSizeProc(long cell, long handle, long cell_area, long x_offset, long y_offset, long width, long height) {
/* 1288 */     return 0L;
/*      */   }
/*      */   
/*      */   long rendererRenderProc(long cell, long cr, long handle, long background_area, long cell_area, long flags) {
/* 1292 */     return 0L;
/*      */   }
/*      */   
/*      */   long rendererRenderProc(long cell, long window, long handle, long background_area, long cell_area, long expose_area, long flags) {
/* 1296 */     return 0L;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void reskin(int flags)
/*      */   {
/* 1328 */     checkWidget();
/* 1329 */     reskinWidget();
/* 1330 */     if ((flags & 0x1) != 0) reskinChildren(flags);
/*      */   }
/*      */   
/*      */   void reskinChildren(int flags) {}
/*      */   
/*      */   void reskinWidget()
/*      */   {
/* 1337 */     if ((this.state & 0x1000000) != 16777216) {
/* 1338 */       this.state |= 0x1000000;
/* 1339 */       this.display.addSkinnableWidget(this);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeDisposeListener(DisposeListener listener)
/*      */   {
/* 1361 */     checkWidget();
/* 1362 */     if (listener == null) error(4);
/* 1363 */     if (this.eventTable == null) return;
/* 1364 */     this.eventTable.unhook(12, listener);
/*      */   }
/*      */   
/*      */   void sendEvent(Event event) {
/* 1368 */     Display display = event.display;
/* 1369 */     if ((!display.filterEvent(event)) && 
/* 1370 */       (this.eventTable != null)) display.sendEvent(this.eventTable, event);
/*      */   }
/*      */   
/*      */   void sendEvent(int eventType)
/*      */   {
/* 1375 */     sendEvent(eventType, null, true);
/*      */   }
/*      */   
/*      */   void sendEvent(int eventType, Event event) {
/* 1379 */     sendEvent(eventType, event, true);
/*      */   }
/*      */   
/*      */   void sendEvent(int eventType, Event event, boolean send) {
/* 1383 */     if ((this.eventTable == null) && (!this.display.filters(eventType))) {
/* 1384 */       return;
/*      */     }
/* 1386 */     if (event == null) {
/* 1387 */       event = new Event();
/*      */     }
/* 1389 */     event.type = eventType;
/* 1390 */     event.display = this.display;
/* 1391 */     event.widget = this;
/* 1392 */     if (event.time == 0) {
/* 1393 */       event.time = this.display.getLastEventTime();
/*      */     }
/* 1395 */     if (send) {
/* 1396 */       sendEvent(event);
/*      */     } else {
/* 1398 */       this.display.postEvent(event);
/*      */     }
/*      */   }
/*      */   
/*      */   boolean sendKeyEvent(int type, GdkEventKey keyEvent) {
/* 1403 */     int length = keyEvent.length;
/* 1404 */     if ((keyEvent.string == 0L) || (OS.g_utf16_strlen(keyEvent.string, length) <= 1L)) {
/* 1405 */       Event event = new Event();
/* 1406 */       event.time = keyEvent.time;
/* 1407 */       if (!setKeyState(event, keyEvent)) return true;
/* 1408 */       sendEvent(type, event);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1417 */       if (isDisposed()) return false;
/* 1418 */       return event.doit;
/*      */     }
/* 1420 */     byte[] buffer = new byte[length];
/* 1421 */     C.memmove(buffer, keyEvent.string, length);
/* 1422 */     char[] chars = Converter.mbcsToWcs(buffer);
/* 1423 */     return sendIMKeyEvent(type, keyEvent, chars) != null;
/*      */   }
/*      */   
/*      */   char[] sendIMKeyEvent(int type, GdkEventKey keyEvent, char[] chars) {
/* 1427 */     int index = 0;int count = 0;int state = 0;
/* 1428 */     long ptr = 0L;
/* 1429 */     if (keyEvent == null) {
/* 1430 */       ptr = GTK.gtk_get_current_event();
/* 1431 */       if (ptr != 0L) {
/* 1432 */         keyEvent = new GdkEventKey();
/* 1433 */         OS.memmove(keyEvent, ptr, GdkEventKey.sizeof);
/* 1434 */         switch (keyEvent.type) {
/*      */         case 8: 
/*      */         case 9: 
/* 1437 */           state = keyEvent.state;
/* 1438 */           break;
/*      */         default: 
/* 1440 */           keyEvent = null;
/*      */         }
/*      */         
/*      */       }
/*      */     }
/* 1445 */     if (keyEvent == null) {
/* 1446 */       int[] buffer = new int[1];
/* 1447 */       GTK.gtk_get_current_event_state(buffer);
/* 1448 */       state = buffer[0];
/*      */     }
/* 1450 */     while (index < chars.length) {
/* 1451 */       Event event = new Event();
/* 1452 */       if ((keyEvent != null) && (chars.length <= 1)) {
/* 1453 */         setKeyState(event, keyEvent);
/*      */       } else {
/* 1455 */         setInputState(event, state);
/*      */       }
/* 1457 */       event.character = chars[index];
/* 1458 */       sendEvent(type, event);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1466 */       if (isDisposed()) {
/* 1467 */         if (ptr != 0L) GDK.gdk_event_free(ptr);
/* 1468 */         return null;
/*      */       }
/* 1470 */       if (event.doit) chars[(count++)] = chars[index];
/* 1471 */       index++;
/*      */     }
/* 1473 */     if (ptr != 0L) GDK.gdk_event_free(ptr);
/* 1474 */     if (count == 0) return null;
/* 1475 */     if (index != count) {
/* 1476 */       char[] result = new char[count];
/* 1477 */       System.arraycopy(chars, 0, result, 0, count);
/* 1478 */       return result;
/*      */     }
/* 1480 */     return chars;
/*      */   }
/*      */   
/*      */   void sendSelectionEvent(int eventType) {
/* 1484 */     sendSelectionEvent(eventType, null, false);
/*      */   }
/*      */   
/*      */   void sendSelectionEvent(int eventType, Event event, boolean send) {
/* 1488 */     if ((this.eventTable == null) && (!this.display.filters(eventType))) {
/* 1489 */       return;
/*      */     }
/* 1491 */     if (event == null) event = new Event();
/* 1492 */     long ptr = GTK.gtk_get_current_event();
/* 1493 */     if (ptr != 0L) {
/* 1494 */       GdkEvent gdkEvent = new GdkEvent();
/* 1495 */       OS.memmove(gdkEvent, ptr, GdkEvent.sizeof);
/* 1496 */       switch (gdkEvent.type) {
/*      */       case 4: 
/*      */       case 5: 
/*      */       case 7: 
/*      */       case 8: 
/*      */       case 9: 
/* 1502 */         int[] state = new int[1];
/* 1503 */         GDK.gdk_event_get_state(ptr, state);
/* 1504 */         setInputState(event, state[0]);
/* 1505 */         break;
/*      */       }
/*      */       
/* 1508 */       GDK.gdk_event_free(ptr);
/*      */     }
/* 1510 */     sendEvent(eventType, event, send);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setData(Object data)
/*      */   {
/* 1536 */     checkWidget();
/* 1537 */     if ((this.state & 0x4) != 0) {
/* 1538 */       ((Object[])this.data)[0] = data;
/*      */     } else {
/* 1540 */       this.data = data;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setData(String key, Object value)
/*      */   {
/* 1569 */     checkWidget();
/* 1570 */     if (key == null) { error(4);
/*      */     }
/* 1572 */     if (key.equals("org.eclipse.swt.internal.control.checksubwindow")) {
/* 1573 */       if ((value != null) && ((value instanceof Boolean))) {
/* 1574 */         if (((Boolean)value).booleanValue()) {
/* 1575 */           this.state |= 0x2000000;
/*      */         } else {
/* 1577 */           this.state &= 0xFDFFFFFF;
/*      */         }
/*      */       }
/* 1580 */       return;
/*      */     }
/*      */     
/* 1583 */     int index = 1;
/* 1584 */     Object[] table = null;
/* 1585 */     if ((this.state & 0x4) != 0) {
/* 1586 */       table = (Object[])this.data;
/* 1587 */       while ((index < table.length) && 
/* 1588 */         (!key.equals(table[index]))) {
/* 1589 */         index += 2;
/*      */       }
/*      */     }
/* 1592 */     if (value != null) {
/* 1593 */       if ((this.state & 0x4) != 0) {
/* 1594 */         if (index == table.length) {
/* 1595 */           Object[] newTable = new Object[table.length + 2];
/* 1596 */           System.arraycopy(table, 0, newTable, 0, table.length);
/* 1597 */           this.data = (table = newTable);
/*      */         }
/*      */       } else {
/* 1600 */         table = new Object[3];
/* 1601 */         table[0] = this.data;
/* 1602 */         this.data = table;
/* 1603 */         this.state |= 0x4;
/*      */       }
/* 1605 */       table[index] = key;
/* 1606 */       table[(index + 1)] = value;
/*      */     }
/* 1608 */     else if (((this.state & 0x4) != 0) && 
/* 1609 */       (index != table.length)) {
/* 1610 */       int length = table.length - 2;
/* 1611 */       if (length == 1) {
/* 1612 */         this.data = table[0];
/* 1613 */         this.state &= 0xFFFFFFFB;
/*      */       } else {
/* 1615 */         Object[] newTable = new Object[length];
/* 1616 */         System.arraycopy(table, 0, newTable, 0, index);
/* 1617 */         System.arraycopy(table, index + 2, newTable, index, length - index);
/* 1618 */         this.data = newTable;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1623 */     if ((key.equals("org.eclipse.swt.skin.class")) || (key.equals("org.eclipse.swt.skin.id"))) reskin(1);
/* 1624 */     if ((GTK.GTK_VERSION >= OS.VERSION(3, 20, 0)) && (key.equals("org.eclipse.swt.internal.gtk.css")) && ((value instanceof String))) {
/* 1625 */       long context = GTK.gtk_widget_get_style_context(cssHandle());
/* 1626 */       long provider = GTK.gtk_css_provider_new();
/* 1627 */       if ((context != 0L) && (provider != 0L)) {
/* 1628 */         GTK.gtk_style_context_add_provider(context, provider, 800);
/* 1629 */         GTK.gtk_css_provider_load_from_data(provider, Converter.wcsToMbcs((String)value, true), -1L, null);
/* 1630 */         OS.g_object_unref(provider);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   void setFontDescription(long widget, long font) {
/* 1636 */     if (GTK.GTK3) {
/* 1637 */       GTK.gtk_widget_override_font(widget, font);
/* 1638 */       long context = GTK.gtk_widget_get_style_context(widget);
/* 1639 */       GTK.gtk_style_context_invalidate(context);
/*      */     } else {
/* 1641 */       GTK.gtk_widget_modify_font(widget, font);
/*      */     }
/*      */   }
/*      */   
/*      */   void setForegroundColor(long handle, GdkColor color) {
/* 1646 */     assert (!GTK.GTK3) : "GTK2 code was run by GTK3";
/* 1647 */     setForegroundColor(handle, color, true);
/*      */   }
/*      */   
/*      */   void setForegroundColor(long handle, GdkColor color, boolean setStateActive) {
/* 1651 */     assert (!GTK.GTK3) : "GTK2 code was run by GTK3";
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1659 */     long style = GTK.gtk_widget_get_modifier_style(handle);
/* 1660 */     GTK.gtk_rc_style_set_fg(style, 0, color);
/* 1661 */     if (setStateActive) GTK.gtk_rc_style_set_fg(style, 1, color);
/* 1662 */     GTK.gtk_rc_style_set_fg(style, 2, color);
/* 1663 */     int flags = GTK.gtk_rc_style_get_color_flags(style, 0);
/* 1664 */     flags = color == null ? flags & 0xFFFFFFFE : flags | 0x1;
/* 1665 */     GTK.gtk_rc_style_set_color_flags(style, 0, flags);
/* 1666 */     if (setStateActive) {
/* 1667 */       flags = GTK.gtk_rc_style_get_color_flags(style, 1);
/* 1668 */       flags = color == null ? flags & 0xFFFFFFFE : flags | 0x1;
/* 1669 */       GTK.gtk_rc_style_set_color_flags(style, 1, flags);
/*      */     }
/* 1671 */     flags = GTK.gtk_rc_style_get_color_flags(style, 2);
/* 1672 */     flags = color == null ? flags & 0xFFFFFFFE : flags | 0x1;
/* 1673 */     GTK.gtk_rc_style_set_color_flags(style, 2, flags);
/*      */     
/* 1675 */     GTK.gtk_rc_style_set_text(style, 0, color);
/* 1676 */     if (setStateActive) GTK.gtk_rc_style_set_text(style, 1, color);
/* 1677 */     GTK.gtk_rc_style_set_text(style, 2, color);
/* 1678 */     flags = GTK.gtk_rc_style_get_color_flags(style, 0);
/* 1679 */     flags = color == null ? flags & 0xFFFFFFFB : flags | 0x4;
/* 1680 */     GTK.gtk_rc_style_set_color_flags(style, 0, flags);
/* 1681 */     flags = GTK.gtk_rc_style_get_color_flags(style, 2);
/* 1682 */     flags = color == null ? flags & 0xFFFFFFFB : flags | 0x4;
/* 1683 */     GTK.gtk_rc_style_set_color_flags(style, 2, flags);
/* 1684 */     if (setStateActive) {
/* 1685 */       flags = GTK.gtk_rc_style_get_color_flags(style, 1);
/* 1686 */       flags = color == null ? flags & 0xFFFFFFFB : flags | 0x4;
/* 1687 */       GTK.gtk_rc_style_set_color_flags(style, 1, flags);
/*      */     }
/* 1689 */     modifyStyle(handle, style);
/*      */   }
/*      */   
/*      */   boolean setInputState(Event event, int state) {
/* 1693 */     if ((state & 0x8) != 0) event.stateMask |= 0x10000;
/* 1694 */     if ((state & 0x1) != 0) event.stateMask |= 0x20000;
/* 1695 */     if ((state & 0x4) != 0) event.stateMask |= 0x40000;
/* 1696 */     if ((state & 0x100) != 0) event.stateMask |= 0x80000;
/* 1697 */     if ((state & 0x200) != 0) event.stateMask |= 0x100000;
/* 1698 */     if ((state & 0x400) != 0) event.stateMask |= 0x200000;
/* 1699 */     return true;
/*      */   }
/*      */   
/*      */   boolean setKeyState(Event event, GdkEventKey keyEvent) {
/* 1703 */     if ((keyEvent.string != 0L) && (OS.g_utf16_strlen(keyEvent.string, keyEvent.length) > 1L)) return false;
/* 1704 */     boolean isNull = false;
/* 1705 */     event.keyCode = Display.translateKey(keyEvent.keyval);
/* 1706 */     switch (keyEvent.keyval) {
/* 1707 */     case 65288:  event.character = '\b'; break;
/* 1708 */     case 65290:  event.character = '\n'; break;
/*      */     case 65293: case 65421: 
/* 1710 */       event.character = '\r'; break;
/*      */     case 65439: case 65535: 
/* 1712 */       event.character = ''; break;
/* 1713 */     case 65307:  event.character = '\033'; break;
/*      */     case 65056: case 65289: 
/* 1715 */       event.character = '\t'; break;
/*      */     default: 
/* 1717 */       if (event.keyCode == 0) {
/* 1718 */         long[] keyval = new long[1];
/* 1719 */         int[] effective_group = new int[1];int[] level = new int[1];int[] consumed_modifiers = new int[1];
/* 1720 */         if (OS.gdk_keymap_translate_keyboard_state(GDK.gdk_keymap_get_default(), keyEvent.hardware_keycode, 0, this.display.getLatinKeyGroup(), keyval, effective_group, level, consumed_modifiers)) {
/* 1721 */           event.keyCode = ((int)GDK.gdk_keyval_to_unicode(keyval[0]));
/*      */         }
/*      */       }
/* 1724 */       int key = keyEvent.keyval;
/* 1725 */       if (((keyEvent.state & 0x4) != 0) && (0 <= key) && (key <= 127)) {
/* 1726 */         if ((97 <= key) && (key <= 122)) key -= 32;
/* 1727 */         if ((64 <= key) && (key <= 95)) key -= 64;
/* 1728 */         event.character = ((char)key);
/* 1729 */         isNull = (keyEvent.keyval == 64) && (key == 0);
/*      */       } else {
/* 1731 */         event.character = ((char)(int)GDK.gdk_keyval_to_unicode(key));
/*      */       }
/*      */       break;
/*      */     }
/* 1735 */     setLocationState(event, keyEvent);
/* 1736 */     if ((event.keyCode == 0) && (event.character == 0) && 
/* 1737 */       (!isNull)) { return false;
/*      */     }
/* 1739 */     return setInputState(event, keyEvent.state);
/*      */   }
/*      */   
/*      */   void setLocationState(Event event, GdkEventKey keyEvent) {
/* 1743 */     switch (keyEvent.keyval) {
/*      */     case 65505: 
/*      */     case 65507: 
/*      */     case 65513: 
/* 1747 */       event.keyLocation = 16384;
/* 1748 */       break;
/*      */     case 65506: 
/*      */     case 65508: 
/*      */     case 65514: 
/* 1752 */       event.keyLocation = 131072;
/* 1753 */       break;
/*      */     case 65407: 
/*      */     case 65421: 
/*      */     case 65429: 
/*      */     case 65430: 
/*      */     case 65431: 
/*      */     case 65432: 
/*      */     case 65433: 
/*      */     case 65434: 
/*      */     case 65435: 
/*      */     case 65436: 
/*      */     case 65438: 
/*      */     case 65439: 
/*      */     case 65450: 
/*      */     case 65451: 
/*      */     case 65453: 
/*      */     case 65454: 
/*      */     case 65455: 
/*      */     case 65456: 
/*      */     case 65457: 
/*      */     case 65458: 
/*      */     case 65459: 
/*      */     case 65460: 
/*      */     case 65461: 
/*      */     case 65462: 
/*      */     case 65463: 
/*      */     case 65464: 
/*      */     case 65465: 
/*      */     case 65469: 
/* 1782 */       event.keyLocation = 2;
/*      */     }
/*      */     
/*      */   }
/*      */   
/*      */   void setOrientation(boolean create) {}
/*      */   
/*      */   boolean setTabGroupFocus(boolean next)
/*      */   {
/* 1791 */     return setTabItemFocus(next);
/*      */   }
/*      */   
/*      */   boolean setTabItemFocus(boolean next) {
/* 1795 */     return false;
/*      */   }
/*      */   
/*      */   long shellMapProc(long handle, long arg0, long user_data) {
/* 1799 */     return 0L;
/*      */   }
/*      */   
/*      */   long sizeAllocateProc(long handle, long arg0, long user_data) {
/* 1803 */     return 0L;
/*      */   }
/*      */   
/*      */   long sizeRequestProc(long handle, long arg0, long user_data) {
/* 1807 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_widget_get_window(long widget) {
/* 1811 */     if (GTK.GTK3) {
/* 1812 */       GTK.gtk_widget_realize(widget);
/*      */     }
/* 1814 */     return GTK.gtk_widget_get_window(widget);
/*      */   }
/*      */   
/*      */   void gtk_widget_set_visible(long widget, boolean visible) {
/* 1818 */     if (GTK.GTK3) {
/* 1819 */       GTK.gtk_widget_set_visible(widget, visible);
/*      */     }
/* 1821 */     else if (visible) {
/* 1822 */       GTK.GTK_WIDGET_SET_FLAGS(widget, 256);
/*      */     } else {
/* 1824 */       GTK.GTK_WIDGET_UNSET_FLAGS(widget, 256);
/*      */     }
/*      */   }
/*      */   
/*      */   void gdk_window_get_size(long drawable, int[] width, int[] height)
/*      */   {
/* 1830 */     width[0] = GDK.gdk_window_get_width(drawable);
/* 1831 */     height[0] = GDK.gdk_window_get_height(drawable);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   int gdk_event_get_state(long event)
/*      */   {
/* 1841 */     int[] state = new int[1];
/* 1842 */     GDK.gdk_event_get_state(event, state);
/* 1843 */     return state[0];
/*      */   }
/*      */   
/*      */   long gtk_box_new(int orientation, boolean homogeneous, int spacing)
/*      */   {
/* 1848 */     long box = 0L;
/* 1849 */     if (GTK.GTK3) {
/* 1850 */       box = GTK.gtk_box_new(orientation, spacing);
/* 1851 */       GTK.gtk_box_set_homogeneous(box, homogeneous);
/*      */     }
/* 1853 */     else if (orientation == 0) {
/* 1854 */       box = GTK.gtk_hbox_new(homogeneous, spacing);
/*      */     } else {
/* 1856 */       box = GTK.gtk_vbox_new(homogeneous, spacing);
/*      */     }
/*      */     
/* 1859 */     return box;
/*      */   }
/*      */   
/*      */   int gdk_pointer_grab(long window, int grab_ownership, boolean owner_events, int event_mask, long confine_to, long cursor, int time_) {
/* 1863 */     if (GTK.GTK3) {
/* 1864 */       long display = 0L;
/* 1865 */       if (window != 0L) {
/* 1866 */         display = GDK.gdk_window_get_display(window);
/*      */       } else {
/* 1868 */         window = GDK.gdk_get_default_root_window();
/* 1869 */         display = GDK.gdk_window_get_display(window);
/*      */       }
/* 1871 */       long pointer = GDK.gdk_get_pointer(display);
/* 1872 */       return GDK.gdk_device_grab(pointer, window, grab_ownership, owner_events, event_mask, cursor, time_);
/*      */     }
/* 1874 */     return GDK.gdk_pointer_grab(window, owner_events, event_mask, confine_to, cursor, time_);
/*      */   }
/*      */   
/*      */   void gdk_pointer_ungrab(long window, int time_)
/*      */   {
/* 1879 */     if (GTK.GTK3) {
/* 1880 */       long display = GDK.gdk_window_get_display(window);
/* 1881 */       long pointer = GDK.gdk_get_pointer(display);
/* 1882 */       GDK.gdk_device_ungrab(pointer, time_);
/*      */     } else {
/* 1884 */       GDK.gdk_pointer_ungrab(time_);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String toString()
/*      */   {
/* 1896 */     String string = "*Disposed*";
/* 1897 */     if (!isDisposed()) {
/* 1898 */       string = "*Wrong Thread*";
/* 1899 */       if (isValidThread()) string = getNameText();
/*      */     }
/* 1901 */     return getName() + " {" + string + "}";
/*      */   }
/*      */   
/*      */   long topHandle() {
/* 1905 */     return this.handle;
/*      */   }
/*      */   
/*      */   long timerProc(long widget) {
/* 1909 */     return 0L;
/*      */   }
/*      */   
/*      */   boolean translateTraversal(int event) {
/* 1913 */     return false;
/*      */   }
/*      */   
/*      */   long windowProc(long handle, long user_data) {
/* 1917 */     switch ((int)user_data) {
/* 1918 */     case 1:  return gtk_activate(handle);
/* 1919 */     case 6:  return gtk_changed(handle);
/* 1920 */     case 8:  return gtk_clicked(handle);
/* 1921 */     case 83:  return gtk_create_menu_proxy(handle);
/* 1922 */     case 61:  return gtk_day_selected(handle);
/* 1923 */     case 66:  return gtk_day_selected_double_click(handle);
/* 1924 */     case 24:  return gtk_hide(handle);
/* 1925 */     case 23:  return gtk_grab_focus(handle);
/* 1926 */     case 30:  return gtk_map(handle);
/* 1927 */     case 62:  return gtk_month_changed(handle);
/* 1928 */     case 36:  return gtk_output(handle);
/* 1929 */     case 38:  return gtk_popup_menu(handle);
/* 1930 */     case 39:  return gtk_preedit_changed(handle);
/* 1931 */     case 40:  return gtk_realize(handle);
/* 1932 */     case 69:  return gtk_start_interactive_search(handle);
/* 1933 */     case 44:  return gtk_select(handle);
/* 1934 */     case 68:  return gtk_selection_done(handle);
/* 1935 */     case 45:  return gtk_show(handle);
/* 1936 */     case 57:  return gtk_value_changed(handle);
/* 1937 */     case 54:  return gtk_unmap(handle);
/* 1938 */     case 56:  return gtk_unrealize(handle); }
/* 1939 */     return 0L;
/*      */   }
/*      */   
/*      */   long windowProc(long handle, long arg0, long user_data)
/*      */   {
/* 1944 */     switch ((int)user_data) {
/*      */     case 19: 
/* 1946 */       if (GTK.GTK3) {
/* 1947 */         if ((GTK.GTK_VERSION >= OS.VERSION(3, 9, 0)) && (GTK.GTK_IS_CONTAINER(handle))) {
/* 1948 */           return gtk_draw(handle, arg0);
/*      */         }
/*      */       } else {
/* 1951 */         GdkEventExpose gdkEvent = new GdkEventExpose();
/* 1952 */         OS.memmove(gdkEvent, arg0, GdkEventExpose.sizeof);
/* 1953 */         long paintWindow = paintWindow();
/* 1954 */         long window = gdkEvent.window;
/* 1955 */         if (window != paintWindow) return 0L;
/* 1956 */         return (this.state & 0x40) != 0 ? 1L : 0L;
/*      */       }
/* 1958 */       return 0L;
/*      */     
/*      */     case 3: 
/*      */     case 5: 
/*      */     case 34: 
/* 1963 */       return 1L;
/*      */     case 2: 
/* 1965 */       return gtk_button_press_event(handle, arg0);
/* 1966 */     case 4:  return gtk_button_release_event(handle, arg0);
/* 1967 */     case 9:  return gtk_commit(handle, arg0);
/* 1968 */     case 10:  return gtk_configure_event(handle, arg0);
/* 1969 */     case 11:  return gtk_delete_event(handle, arg0);
/* 1970 */     case 14:  return gtk_enter_notify_event(handle, arg0);
/* 1971 */     case 15:  return gtk_event(handle, arg0);
/* 1972 */     case 16:  return gtk_event_after(handle, arg0);
/*      */     case 18: 
/* 1974 */       if (GTK.GTK3) {
/* 1975 */         if ((GTK.GTK_VERSION < OS.VERSION(3, 9, 0)) || (!GTK.GTK_IS_CONTAINER(handle))) {
/* 1976 */           return gtk_draw(handle, arg0);
/*      */         }
/*      */       } else {
/* 1979 */         return gtk_expose_event(handle, arg0);
/*      */       }
/* 1981 */       return 0L;
/*      */     case 20: 
/* 1983 */       return gtk_focus(handle, arg0);
/* 1984 */     case 21:  return gtk_focus_in_event(handle, arg0);
/* 1985 */     case 22:  return gtk_focus_out_event(handle, arg0);
/* 1986 */     case 27:  return gtk_key_press_event(handle, arg0);
/* 1987 */     case 28:  return gtk_key_release_event(handle, arg0);
/* 1988 */     case 25:  return gtk_input(handle, arg0);
/* 1989 */     case 29:  return gtk_leave_notify_event(handle, arg0);
/* 1990 */     case 31:  return gtk_map_event(handle, arg0);
/* 1991 */     case 32:  return gtk_mnemonic_activate(handle, arg0);
/* 1992 */     case 33:  return gtk_motion_notify_event(handle, arg0);
/* 1993 */     case 35:  return gtk_move_focus(handle, arg0);
/* 1994 */     case 37:  return gtk_populate_popup(handle, arg0);
/* 1995 */     case 43:  return gtk_scroll_event(handle, arg0);
/* 1996 */     case 46:  return gtk_show_help(handle, arg0);
/* 1997 */     case 47:  return gtk_size_allocate(handle, arg0);
/* 1998 */     case 48:  return gtk_style_set(handle, arg0);
/* 1999 */     case 53:  return gtk_toggled(handle, arg0);
/* 2000 */     case 55:  return gtk_unmap_event(handle, arg0);
/* 2001 */     case 59:  return gtk_window_state_event(handle, arg0);
/* 2002 */     case 65:  return gtk_row_deleted(handle, arg0); }
/* 2003 */     return 0L;
/*      */   }
/*      */   
/*      */   long windowProc(long handle, long arg0, long arg1, long user_data)
/*      */   {
/* 2008 */     switch ((int)user_data) {
/* 2009 */     case 12:  return gtk_delete_range(handle, arg0, arg1);
/* 2010 */     case 13:  return gtk_delete_text(handle, arg0, arg1);
/* 2011 */     case 67:  return gtk_icon_release(handle, arg0, arg1);
/* 2012 */     case 41:  return gtk_row_activated(handle, arg0, arg1);
/* 2013 */     case 42:  return gtk_scroll_child(handle, arg0, arg1);
/* 2014 */     case 63:  return gtk_status_icon_popup_menu(handle, arg0, arg1);
/* 2015 */     case 49:  return gtk_switch_page(handle, arg0, arg1);
/* 2016 */     case 50:  return gtk_test_collapse_row(handle, arg0, arg1);
/* 2017 */     case 51:  return gtk_test_expand_row(handle, arg0, arg1);
/* 2018 */     case 64:  return gtk_row_inserted(handle, arg0, arg1);
/* 2019 */     case 84:  return gtk_row_has_child_toggled(handle, arg0, arg1); }
/* 2020 */     return 0L;
/*      */   }
/*      */   
/*      */   long windowProc(long handle, long arg0, long arg1, long arg2, long user_data)
/*      */   {
/* 2025 */     switch ((int)user_data) {
/* 2026 */     case 7:  return gtk_change_value(handle, arg0, arg1, arg2);
/* 2027 */     case 17:  return gtk_expand_collapse_cursor_row(handle, arg0, arg1, arg2);
/* 2028 */     case 26:  return gtk_insert_text(handle, arg0, arg1, arg2);
/* 2029 */     case 52:  return gtk_text_buffer_insert_text(handle, arg0, arg1, arg2); }
/* 2030 */     return 0L;
/*      */   }
/*      */   
/*      */   long windowProc(long handle, long arg0, long arg1, long arg2, long arg3, long user_data)
/*      */   {
/* 2035 */     switch ((int)user_data) {
/* 2036 */     case 85:  return gtk_menu_popped_up(handle, arg0, arg1, arg2, arg3); }
/* 2037 */     return 0L;
/*      */   }
/*      */   
/*      */   void gdk_cursor_unref(long cursor)
/*      */   {
/* 2042 */     if (GTK.GTK3) {
/* 2043 */       OS.g_object_unref(cursor);
/*      */     } else {
/* 2045 */       GDK.gdk_cursor_unref(cursor);
/*      */     }
/*      */   }
/*      */   
/*      */   long gdk_window_get_device_position(long window, int[] x, int[] y, int[] mask) {
/* 2050 */     if (GTK.GTK3) {
/* 2051 */       long display = 0L;
/* 2052 */       if (window != 0L) {
/* 2053 */         display = GDK.gdk_window_get_display(window);
/*      */       } else {
/* 2055 */         window = GDK.gdk_get_default_root_window();
/* 2056 */         display = GDK.gdk_window_get_display(window);
/*      */       }
/* 2058 */       long pointer = GDK.gdk_get_pointer(display);
/* 2059 */       return GDK.gdk_window_get_device_position(window, pointer, x, y, mask);
/*      */     }
/* 2061 */     return GDK.gdk_window_get_pointer(window, x, y, mask);
/*      */   }
/*      */   
/*      */   void gtk_cell_renderer_get_preferred_size(long cell, long widget, int[] width, int[] height)
/*      */   {
/* 2066 */     if (GTK.GTK3) {
/* 2067 */       GtkRequisition minimum_size = new GtkRequisition();
/* 2068 */       GTK.gtk_cell_renderer_get_preferred_size(cell, widget, minimum_size, null);
/* 2069 */       if (width != null) width[0] = minimum_size.width;
/* 2070 */       if (height != null) height[0] = minimum_size.height;
/*      */     } else {
/* 2072 */       GTK.gtk_cell_renderer_get_size(cell, widget, null, null, null, width, height);
/*      */     }
/*      */   }
/*      */   
/*      */   void gtk_widget_get_preferred_size(long widget, GtkRequisition requisition) {
/* 2077 */     if (GTK.GTK3) {
/* 2078 */       GTK.gtk_widget_get_preferred_size(widget, requisition, null);
/*      */     } else {
/* 2080 */       GTK.gtk_widget_size_request(widget, requisition);
/*      */     }
/*      */   }
/*      */   
/*      */   void gtk_image_set_from_pixbuf(long imageHandle, long pixbuf) {
/* 2085 */     if (GTK.GTK3) {
/* 2086 */       GTK.gtk_image_set_from_gicon(imageHandle, pixbuf, 2);
/*      */     } else {
/* 2088 */       GTK.gtk_image_set_from_pixbuf(imageHandle, pixbuf);
/*      */     }
/*      */   }
/*      */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/widgets/Widget.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */