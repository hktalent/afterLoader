/*      */ package org.eclipse.swt.widgets;
/*      */ 
/*      */ import org.eclipse.swt.events.ModifyListener;
/*      */ import org.eclipse.swt.events.SelectionListener;
/*      */ import org.eclipse.swt.events.VerifyListener;
/*      */ import org.eclipse.swt.graphics.Color;
/*      */ import org.eclipse.swt.graphics.Cursor;
/*      */ import org.eclipse.swt.graphics.Font;
/*      */ import org.eclipse.swt.graphics.Point;
/*      */ import org.eclipse.swt.graphics.Rectangle;
/*      */ import org.eclipse.swt.internal.C;
/*      */ import org.eclipse.swt.internal.Converter;
/*      */ import org.eclipse.swt.internal.gtk.GDK;
/*      */ import org.eclipse.swt.internal.gtk.GTK;
/*      */ import org.eclipse.swt.internal.gtk.GdkColor;
/*      */ import org.eclipse.swt.internal.gtk.GdkEventKey;
/*      */ import org.eclipse.swt.internal.gtk.GdkRGBA;
/*      */ import org.eclipse.swt.internal.gtk.GtkAdjustment;
/*      */ import org.eclipse.swt.internal.gtk.GtkBorder;
/*      */ import org.eclipse.swt.internal.gtk.GtkRequisition;
/*      */ import org.eclipse.swt.internal.gtk.OS;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class Spinner
/*      */   extends Composite
/*      */ {
/*      */   static final int MIN_ARROW_WIDTH = 6;
/*   47 */   int lastEventTime = 0;
/*      */   long imContext;
/*   49 */   long gdkEventKey = 0L;
/*   50 */   int fixStart = -1; int fixEnd = -1;
/*   51 */   double climbRate = 1.0D;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*   66 */   public static final int LIMIT = 65535;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   GdkRGBA background;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Spinner(Composite parent, int style)
/*      */   {
/*  103 */     super(parent, checkStyle(style));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addModifyListener(ModifyListener listener)
/*      */   {
/*  126 */     checkWidget();
/*  127 */     if (listener == null) error(4);
/*  128 */     TypedListener typedListener = new TypedListener(listener);
/*  129 */     addListener(24, typedListener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addSelectionListener(SelectionListener listener)
/*      */   {
/*  157 */     checkWidget();
/*  158 */     if (listener == null) error(4);
/*  159 */     TypedListener typedListener = new TypedListener(listener);
/*  160 */     addListener(13, typedListener);
/*  161 */     addListener(14, typedListener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void addVerifyListener(VerifyListener listener)
/*      */   {
/*  184 */     checkWidget();
/*  185 */     if (listener == null) error(4);
/*  186 */     TypedListener typedListener = new TypedListener(listener);
/*  187 */     addListener(25, typedListener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static int checkStyle(int style)
/*      */   {
/*  198 */     return style & 0xFCFF;
/*      */   }
/*      */   
/*      */   protected void checkSubclass()
/*      */   {
/*  203 */     if (!isValidSubclass()) error(43);
/*      */   }
/*      */   
/*      */   Point computeSizeInPixels(int wHint, int hHint, boolean changed)
/*      */   {
/*  208 */     checkWidget();
/*  209 */     if ((wHint != -1) && (wHint < 0)) wHint = 0;
/*  210 */     if ((hHint != -1) && (hHint < 0)) hHint = 0;
/*  211 */     int[] w = new int[1];int[] h = new int[1];
/*  212 */     GTK.gtk_widget_realize(this.handle);
/*  213 */     long layout = GTK.gtk_entry_get_layout(this.handle);
/*  214 */     long hAdjustment = GTK.gtk_spin_button_get_adjustment(this.handle);
/*  215 */     double upper = GTK.gtk_adjustment_get_upper(hAdjustment);
/*  216 */     int digits = GTK.gtk_spin_button_get_digits(this.handle);
/*  217 */     for (int i = 0; i < digits; i++) upper *= 10.0D;
/*  218 */     String string = String.valueOf((int)upper);
/*  219 */     if (digits > 0) {
/*  220 */       StringBuilder buffer = new StringBuilder();
/*  221 */       buffer.append(string);
/*  222 */       buffer.append(getDecimalSeparator());
/*  223 */       int count = digits - string.length();
/*  224 */       while (count >= 0) {
/*  225 */         buffer.append("0");
/*  226 */         count--;
/*      */       }
/*  228 */       string = buffer.toString();
/*      */     }
/*  230 */     byte[] buffer1 = Converter.wcsToMbcs(string, false);
/*  231 */     long ptr = OS.pango_layout_get_text(layout);
/*  232 */     int length = C.strlen(ptr);
/*  233 */     byte[] buffer2 = new byte[length];
/*  234 */     C.memmove(buffer2, ptr, length);
/*  235 */     OS.pango_layout_set_text(layout, buffer1, buffer1.length);
/*  236 */     int height = 0;
/*  237 */     GTK.gtk_widget_realize(this.handle);
/*  238 */     int width; if (GTK.GTK3) {
/*  239 */       GTK.gtk_widget_set_size_request(this.handle, wHint, hHint);
/*  240 */       GtkRequisition requisition = new GtkRequisition();
/*  241 */       GTK.gtk_widget_get_preferred_size(this.handle, requisition, null);
/*  242 */       int width = wHint == -1 ? requisition.width : wHint;
/*  243 */       height = hHint == -1 ? requisition.height : hHint;
/*      */     } else {
/*  245 */       OS.pango_layout_get_pixel_size(layout, w, h);
/*  246 */       width = wHint == -1 ? w[0] : wHint;
/*  247 */       height = hHint == -1 ? h[0] : hHint;
/*      */     }
/*  249 */     OS.pango_layout_set_text(layout, buffer2, buffer2.length);
/*  250 */     Rectangle trim = computeTrimInPixels(0, 0, width, height);
/*  251 */     return new Point(trim.width, trim.height);
/*      */   }
/*      */   
/*      */   Rectangle computeTrimInPixels(int x, int y, int width, int height)
/*      */   {
/*  256 */     checkWidget();
/*  257 */     int xborder = 0;int yborder = 0;
/*  258 */     Rectangle trim = super.computeTrimInPixels(x, y, width, height);
/*  259 */     if (GTK.GTK3) {
/*  260 */       GtkBorder tmp = new GtkBorder();
/*  261 */       long context = GTK.gtk_widget_get_style_context(this.handle);
/*  262 */       if (GTK.GTK_VERSION < OS.VERSION(3, 18, 0)) {
/*  263 */         GTK.gtk_style_context_get_padding(context, 0, tmp);
/*      */       } else {
/*  265 */         GTK.gtk_style_context_get_padding(context, GTK.gtk_widget_get_state_flags(this.handle), tmp);
/*      */       }
/*  267 */       if ((this.style & 0x800) != 0) {
/*  268 */         if (GTK.GTK_VERSION < OS.VERSION(3, 18, 0)) {
/*  269 */           GTK.gtk_style_context_get_border(context, 0, tmp);
/*      */         } else {
/*  271 */           GTK.gtk_style_context_get_border(context, GTK.gtk_widget_get_state_flags(this.handle), tmp);
/*      */         }
/*  273 */         trim.x -= tmp.left;
/*  274 */         trim.y -= tmp.top;
/*  275 */         trim.width += tmp.left + tmp.right;
/*  276 */         trim.height += tmp.top + tmp.bottom;
/*      */       }
/*      */     } else {
/*  279 */       Point thickness = getThickness(this.handle);
/*  280 */       if ((this.style & 0x800) != 0) {
/*  281 */         xborder += thickness.x;
/*  282 */         yborder += thickness.y;
/*      */       }
/*  284 */       long fontDesc = getFontDescription();
/*  285 */       int fontSize = OS.pango_font_description_get_size(fontDesc);
/*  286 */       int arrowSize = Math.max(OS.PANGO_PIXELS(fontSize), 6);
/*  287 */       arrowSize -= arrowSize % 2;
/*  288 */       trim.width += arrowSize + 2 * thickness.x;
/*      */     }
/*  290 */     int[] property = new int[1];
/*  291 */     GTK.gtk_widget_style_get(this.handle, OS.interior_focus, property, 0L);
/*  292 */     if (property[0] == 0) {
/*  293 */       GTK.gtk_widget_style_get(this.handle, OS.focus_line_width, property, 0L);
/*  294 */       xborder += property[0];
/*  295 */       yborder += property[0];
/*      */     }
/*  297 */     trim.x -= xborder;
/*  298 */     trim.y -= yborder;
/*  299 */     trim.width += 2 * xborder;
/*  300 */     trim.height += 2 * yborder;
/*  301 */     GtkBorder innerBorder = Display.getEntryInnerBorder(this.handle);
/*  302 */     trim.x -= innerBorder.left;
/*  303 */     trim.y -= innerBorder.top;
/*  304 */     trim.width += innerBorder.left + innerBorder.right;
/*  305 */     trim.height += innerBorder.top + innerBorder.bottom;
/*  306 */     return new Rectangle(trim.x, trim.y, trim.width, trim.height);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void copy()
/*      */   {
/*  321 */     checkWidget();
/*  322 */     GTK.gtk_editable_copy_clipboard(this.handle);
/*      */   }
/*      */   
/*      */   void createHandle(int index)
/*      */   {
/*  327 */     this.state |= 0x28;
/*  328 */     this.fixedHandle = OS.g_object_new(this.display.gtk_fixed_get_type(), 0L);
/*  329 */     if (this.fixedHandle == 0L) error(2);
/*  330 */     GTK.gtk_widget_set_has_window(this.fixedHandle, true);
/*  331 */     long adjustment = GTK.gtk_adjustment_new(0.0D, 0.0D, 100.0D, 1.0D, 10.0D, 0.0D);
/*  332 */     if (adjustment == 0L) error(2);
/*  333 */     this.handle = GTK.gtk_spin_button_new(adjustment, this.climbRate, 0);
/*  334 */     if (this.handle == 0L) error(2);
/*  335 */     GTK.gtk_container_add(this.fixedHandle, this.handle);
/*  336 */     GTK.gtk_editable_set_editable(this.handle, (this.style & 0x8) == 0);
/*  337 */     if (GTK.GTK_VERSION <= OS.VERSION(3, 20, 0)) {
/*  338 */       GTK.gtk_entry_set_has_frame(this.handle, (this.style & 0x800) != 0);
/*      */     }
/*  340 */     GTK.gtk_spin_button_set_wrap(this.handle, (this.style & 0x40) != 0);
/*  341 */     if (GTK.GTK3) {
/*  342 */       this.imContext = OS.imContextLast();
/*      */     }
/*      */     
/*      */ 
/*  346 */     if (GTK.GTK3) {
/*  347 */       setFontDescription(defaultFont().handle);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void cut()
/*      */   {
/*  364 */     checkWidget();
/*  365 */     GTK.gtk_editable_cut_clipboard(this.handle);
/*      */   }
/*      */   
/*      */   GdkRGBA defaultBackground()
/*      */   {
/*  370 */     return this.display.getSystemColor(25).handleRGBA;
/*      */   }
/*      */   
/*      */   void deregister()
/*      */   {
/*  375 */     super.deregister();
/*  376 */     long imContext = imContext();
/*  377 */     if (imContext != 0L) this.display.removeWidget(imContext);
/*      */   }
/*      */   
/*      */   long eventWindow()
/*      */   {
/*  382 */     return paintWindow();
/*      */   }
/*      */   
/*      */   long enterExitHandle()
/*      */   {
/*  387 */     return this.fixedHandle;
/*      */   }
/*      */   
/*      */   boolean filterKey(int keyval, long event)
/*      */   {
/*  392 */     int time = GDK.gdk_event_get_time(event);
/*  393 */     if (time != this.lastEventTime) {
/*  394 */       this.lastEventTime = time;
/*  395 */       long imContext = imContext();
/*  396 */       if (imContext != 0L) {
/*  397 */         return GTK.gtk_im_context_filter_keypress(imContext, event);
/*      */       }
/*      */     }
/*  400 */     this.gdkEventKey = event;
/*  401 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void fixIM()
/*      */   {
/*  413 */     if ((this.gdkEventKey != 0L) && (this.gdkEventKey != -1L)) {
/*  414 */       long imContext = imContext();
/*  415 */       if (imContext != 0L) {
/*  416 */         GTK.gtk_im_context_filter_keypress(imContext, this.gdkEventKey);
/*  417 */         this.gdkEventKey = -1L;
/*  418 */         return;
/*      */       }
/*      */     }
/*  421 */     this.gdkEventKey = 0L;
/*      */   }
/*      */   
/*      */   GdkColor getBackgroundGdkColor()
/*      */   {
/*  426 */     assert (!GTK.GTK3) : "GTK2 code was run by GTK3";
/*  427 */     return getBaseGdkColor();
/*      */   }
/*      */   
/*      */   int getBorderWidthInPixels()
/*      */   {
/*  432 */     checkWidget();
/*  433 */     if ((this.style & 0x800) != 0) {
/*  434 */       return getThickness(this.handle).x;
/*      */     }
/*  436 */     return 0;
/*      */   }
/*      */   
/*      */   GdkColor getForegroundGdkColor()
/*      */   {
/*  441 */     assert (!GTK.GTK3) : "GTK2 code was run by GTK3";
/*  442 */     return getTextColor();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getIncrement()
/*      */   {
/*  457 */     checkWidget();
/*  458 */     long hAdjustment = GTK.gtk_spin_button_get_adjustment(this.handle);
/*  459 */     int digits = GTK.gtk_spin_button_get_digits(this.handle);
/*  460 */     double value = GTK.gtk_adjustment_get_step_increment(hAdjustment);
/*  461 */     for (int i = 0; i < digits; i++) value *= 10.0D;
/*  462 */     return (int)(value > 0.0D ? value + 0.5D : value - 0.5D);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getMaximum()
/*      */   {
/*  476 */     checkWidget();
/*  477 */     long hAdjustment = GTK.gtk_spin_button_get_adjustment(this.handle);
/*  478 */     int digits = GTK.gtk_spin_button_get_digits(this.handle);
/*  479 */     double value = GTK.gtk_adjustment_get_upper(hAdjustment);
/*  480 */     for (int i = 0; i < digits; i++) value *= 10.0D;
/*  481 */     return (int)(value > 0.0D ? value + 0.5D : value - 0.5D);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getMinimum()
/*      */   {
/*  495 */     checkWidget();
/*  496 */     long hAdjustment = GTK.gtk_spin_button_get_adjustment(this.handle);
/*  497 */     int digits = GTK.gtk_spin_button_get_digits(this.handle);
/*  498 */     double value = GTK.gtk_adjustment_get_lower(hAdjustment);
/*  499 */     for (int i = 0; i < digits; i++) value *= 10.0D;
/*  500 */     return (int)(value > 0.0D ? value + 0.5D : value - 0.5D);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getPageIncrement()
/*      */   {
/*  515 */     checkWidget();
/*  516 */     long hAdjustment = GTK.gtk_spin_button_get_adjustment(this.handle);
/*  517 */     int digits = GTK.gtk_spin_button_get_digits(this.handle);
/*  518 */     double value = GTK.gtk_adjustment_get_page_increment(hAdjustment);
/*  519 */     for (int i = 0; i < digits; i++) value *= 10.0D;
/*  520 */     return (int)(value > 0.0D ? value + 0.5D : value - 0.5D);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getSelection()
/*      */   {
/*  534 */     checkWidget();
/*  535 */     long hAdjustment = GTK.gtk_spin_button_get_adjustment(this.handle);
/*  536 */     int digits = GTK.gtk_spin_button_get_digits(this.handle);
/*  537 */     double value = GTK.gtk_adjustment_get_value(hAdjustment);
/*  538 */     for (int i = 0; i < digits; i++) value *= 10.0D;
/*  539 */     return (int)(value > 0.0D ? value + 0.5D : value - 0.5D);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getText()
/*      */   {
/*  557 */     checkWidget();
/*  558 */     long str = GTK.gtk_entry_get_text(this.handle);
/*  559 */     if (str == 0L) return "";
/*  560 */     int length = C.strlen(str);
/*  561 */     byte[] buffer = new byte[length];
/*  562 */     C.memmove(buffer, str, length);
/*  563 */     return new String(Converter.mbcsToWcs(buffer));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getTextLimit()
/*      */   {
/*  584 */     checkWidget();
/*  585 */     int limit = GTK.gtk_entry_get_max_length(this.handle);
/*  586 */     return limit == 0 ? LIMIT : limit;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getDigits()
/*      */   {
/*  600 */     checkWidget();
/*  601 */     return GTK.gtk_spin_button_get_digits(this.handle);
/*      */   }
/*      */   
/*      */   String getDecimalSeparator() {
/*  605 */     long ptr = OS.localeconv_decimal_point();
/*  606 */     int length = C.strlen(ptr);
/*  607 */     byte[] buffer = new byte[length];
/*  608 */     C.memmove(buffer, ptr, length);
/*  609 */     return new String(Converter.mbcsToWcs(buffer));
/*      */   }
/*      */   
/*      */   long gtk_activate(long widget)
/*      */   {
/*  614 */     sendSelectionEvent(14);
/*  615 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_changed(long widget)
/*      */   {
/*  620 */     long str = GTK.gtk_entry_get_text(this.handle);
/*  621 */     int length = C.strlen(str);
/*  622 */     if (length > 0) {
/*  623 */       long[] endptr = new long[1];
/*  624 */       double value = OS.g_strtod(str, endptr);
/*  625 */       int valueLength = getDigits() == 0 ? String.valueOf((int)value).length() : String.valueOf(value).length();
/*  626 */       if ((endptr[0] == str + length) && (valueLength == length)) {
/*  627 */         long hAdjustment = GTK.gtk_spin_button_get_adjustment(this.handle);
/*  628 */         GtkAdjustment adjustment = new GtkAdjustment();
/*  629 */         gtk_adjustment_get(hAdjustment, adjustment);
/*  630 */         if ((value != adjustment.value) && (adjustment.lower <= value) && (value <= adjustment.upper)) {
/*  631 */           GTK.gtk_spin_button_update(this.handle);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  643 */     boolean keyPress = false;
/*  644 */     long eventPtr = GTK.gtk_get_current_event();
/*  645 */     if (eventPtr != 0L) {
/*  646 */       GdkEventKey gdkEvent = new GdkEventKey();
/*  647 */       OS.memmove(gdkEvent, eventPtr, GdkEventKey.sizeof);
/*  648 */       switch (gdkEvent.type) {
/*      */       case 8: 
/*  650 */         keyPress = true;
/*      */       }
/*      */       
/*  653 */       GDK.gdk_event_free(eventPtr);
/*      */     }
/*  655 */     if (keyPress) {
/*  656 */       postEvent(24);
/*      */     } else {
/*  658 */       sendEvent(24);
/*      */     }
/*  660 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_commit(long imContext, long text)
/*      */   {
/*  665 */     if (text == 0L) return 0L;
/*  666 */     if (!GTK.gtk_editable_get_editable(this.handle)) return 0L;
/*  667 */     int length = C.strlen(text);
/*  668 */     if (length == 0) return 0L;
/*  669 */     byte[] buffer = new byte[length];
/*  670 */     C.memmove(buffer, text, length);
/*  671 */     char[] chars = Converter.mbcsToWcs(buffer);
/*  672 */     char[] newChars = sendIMKeyEvent(1, null, chars);
/*  673 */     if (newChars == null) { return 0L;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  681 */     this.fixStart = (this.fixEnd = -1);
/*  682 */     OS.g_signal_handlers_block_matched(imContext, 16, 0, 0, 0L, 0L, 9L);
/*  683 */     int id = OS.g_signal_lookup(OS.commit, GTK.gtk_im_context_get_type());
/*  684 */     int mask = 17;
/*  685 */     OS.g_signal_handlers_unblock_matched(imContext, mask, id, 0, 0L, 0L, this.handle);
/*  686 */     if (newChars == chars) {
/*  687 */       OS.g_signal_emit_by_name(imContext, OS.commit, text);
/*      */     } else {
/*  689 */       buffer = Converter.wcsToMbcs(newChars, true);
/*  690 */       OS.g_signal_emit_by_name(imContext, OS.commit, buffer);
/*      */     }
/*  692 */     OS.g_signal_handlers_unblock_matched(imContext, 16, 0, 0, 0L, 0L, 9L);
/*  693 */     OS.g_signal_handlers_block_matched(imContext, mask, id, 0, 0L, 0L, this.handle);
/*  694 */     if ((this.fixStart != -1) && (this.fixEnd != -1)) {
/*  695 */       GTK.gtk_editable_set_position(this.handle, this.fixStart);
/*  696 */       GTK.gtk_editable_select_region(this.handle, this.fixStart, this.fixEnd);
/*      */     }
/*  698 */     this.fixStart = (this.fixEnd = -1);
/*  699 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_delete_text(long widget, long start_pos, long end_pos)
/*      */   {
/*  704 */     if ((!hooks(25)) && (!filters(25))) return 0L;
/*  705 */     long ptr = GTK.gtk_entry_get_text(this.handle);
/*  706 */     if (end_pos == -1L) end_pos = OS.g_utf8_strlen(ptr, -1L);
/*  707 */     int start = (int)OS.g_utf8_offset_to_utf16_offset(ptr, start_pos);
/*  708 */     int end = (int)OS.g_utf8_offset_to_utf16_offset(ptr, end_pos);
/*  709 */     String newText = verifyText("", start, end);
/*  710 */     if (newText == null) {
/*  711 */       OS.g_signal_stop_emission_by_name(this.handle, OS.delete_text);
/*      */     }
/*  713 */     else if (newText.length() > 0) {
/*  714 */       int[] pos = new int[1];
/*  715 */       pos[0] = ((int)end_pos);
/*  716 */       byte[] buffer = Converter.wcsToMbcs(newText, false);
/*  717 */       OS.g_signal_handlers_block_matched(this.handle, 16, 0, 0, 0L, 0L, 6L);
/*  718 */       OS.g_signal_handlers_block_matched(this.handle, 16, 0, 0, 0L, 0L, 26L);
/*  719 */       GTK.gtk_editable_insert_text(this.handle, buffer, buffer.length, pos);
/*  720 */       OS.g_signal_handlers_unblock_matched(this.handle, 16, 0, 0, 0L, 0L, 26L);
/*  721 */       OS.g_signal_handlers_unblock_matched(this.handle, 16, 0, 0, 0L, 0L, 6L);
/*  722 */       GTK.gtk_editable_set_position(this.handle, pos[0]);
/*      */     }
/*      */     
/*  725 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_event_after(long widget, long gdkEvent)
/*      */   {
/*  730 */     if (this.cursor != null) setCursor(this.cursor.handle);
/*  731 */     return super.gtk_event_after(widget, gdkEvent);
/*      */   }
/*      */   
/*      */   long gtk_focus_out_event(long widget, long event)
/*      */   {
/*  736 */     fixIM();
/*  737 */     return super.gtk_focus_out_event(widget, event);
/*      */   }
/*      */   
/*      */ 
/*      */   long gtk_insert_text(long widget, long new_text, long new_text_length, long position)
/*      */   {
/*  743 */     if ((new_text == 0L) || (new_text_length == 0L)) return 0L;
/*  744 */     byte[] buffer = new byte[(int)new_text_length];
/*  745 */     C.memmove(buffer, new_text, buffer.length);
/*  746 */     String oldText = new String(Converter.mbcsToWcs(buffer));
/*  747 */     int[] pos = new int[1];
/*  748 */     C.memmove(pos, position, 4L);
/*  749 */     long ptr = GTK.gtk_entry_get_text(this.handle);
/*  750 */     if (pos[0] == -1) pos[0] = ((int)OS.g_utf8_strlen(ptr, -1L));
/*  751 */     int start = (int)OS.g_utf16_pointer_to_offset(ptr, pos[0]);
/*  752 */     String newText = verifyText(oldText, start, start);
/*  753 */     if (newText != oldText) {
/*  754 */       int[] newStart = new int[1];int[] newEnd = new int[1];
/*  755 */       GTK.gtk_editable_get_selection_bounds(this.handle, newStart, newEnd);
/*  756 */       if (newText != null) {
/*  757 */         if (newStart[0] != newEnd[0]) {
/*  758 */           OS.g_signal_handlers_block_matched(this.handle, 16, 0, 0, 0L, 0L, 13L);
/*  759 */           OS.g_signal_handlers_block_matched(this.handle, 16, 0, 0, 0L, 0L, 6L);
/*  760 */           GTK.gtk_editable_delete_selection(this.handle);
/*  761 */           OS.g_signal_handlers_unblock_matched(this.handle, 16, 0, 0, 0L, 0L, 13L);
/*  762 */           OS.g_signal_handlers_unblock_matched(this.handle, 16, 0, 0, 0L, 0L, 6L);
/*      */         }
/*  764 */         byte[] buffer3 = Converter.wcsToMbcs(newText, false);
/*  765 */         OS.g_signal_handlers_block_matched(this.handle, 16, 0, 0, 0L, 0L, 26L);
/*  766 */         GTK.gtk_editable_insert_text(this.handle, buffer3, buffer3.length, pos);
/*  767 */         OS.g_signal_handlers_unblock_matched(this.handle, 16, 0, 0, 0L, 0L, 26L);
/*  768 */         newStart[0] = (newEnd[0] = pos[0]);
/*      */       }
/*  770 */       pos[0] = newEnd[0];
/*  771 */       if (newStart[0] != newEnd[0]) {
/*  772 */         this.fixStart = newStart[0];
/*  773 */         this.fixEnd = newEnd[0];
/*      */       }
/*  775 */       C.memmove(position, pos, 4L);
/*  776 */       OS.g_signal_stop_emission_by_name(this.handle, OS.insert_text);
/*      */     }
/*  778 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_key_press_event(long widget, long event)
/*      */   {
/*  783 */     long result = super.gtk_key_press_event(widget, event);
/*  784 */     if (result != 0L) fixIM();
/*  785 */     if (this.gdkEventKey == -1L) result = 1L;
/*  786 */     this.gdkEventKey = 0L;
/*  787 */     return result;
/*      */   }
/*      */   
/*      */   long gtk_populate_popup(long widget, long menu)
/*      */   {
/*  792 */     if ((this.style & 0x4000000) != 0) {
/*  793 */       GTK.gtk_widget_set_direction(menu, 2);
/*  794 */       GTK.gtk_container_forall(menu, this.display.setDirectionProc, 2L);
/*      */     }
/*  796 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_value_changed(long widget)
/*      */   {
/*  801 */     sendSelectionEvent(13);
/*  802 */     return 0L;
/*      */   }
/*      */   
/*      */   void hookEvents()
/*      */   {
/*  807 */     super.hookEvents();
/*  808 */     OS.g_signal_connect_closure(this.handle, OS.changed, this.display.getClosure(6), true);
/*  809 */     OS.g_signal_connect_closure(this.handle, OS.insert_text, this.display.getClosure(26), false);
/*  810 */     OS.g_signal_connect_closure(this.handle, OS.delete_text, this.display.getClosure(13), false);
/*  811 */     OS.g_signal_connect_closure(this.handle, OS.value_changed, this.display.getClosure(57), false);
/*  812 */     OS.g_signal_connect_closure(this.handle, OS.activate, this.display.getClosure(1), false);
/*  813 */     OS.g_signal_connect_closure(this.handle, OS.populate_popup, this.display.getClosure(37), false);
/*  814 */     long imContext = imContext();
/*  815 */     if (imContext != 0L) {
/*  816 */       OS.g_signal_connect_closure(imContext, OS.commit, this.display.getClosure(9), false);
/*  817 */       int id = OS.g_signal_lookup(OS.commit, GTK.gtk_im_context_get_type());
/*  818 */       int mask = 17;
/*  819 */       OS.g_signal_handlers_block_matched(imContext, mask, id, 0, 0L, 0L, this.handle);
/*      */     }
/*      */   }
/*      */   
/*      */   long imContext() {
/*  824 */     if (this.imContext != 0L) return this.imContext;
/*  825 */     return GTK.GTK_ENTRY_IM_CONTEXT(this.handle);
/*      */   }
/*      */   
/*      */   long paintWindow()
/*      */   {
/*  830 */     long window = super.paintWindow();
/*  831 */     long children = GDK.gdk_window_get_children(window);
/*  832 */     if (children != 0L) window = OS.g_list_data(children);
/*  833 */     OS.g_list_free(children);
/*  834 */     return window;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void paste()
/*      */   {
/*  850 */     checkWidget();
/*  851 */     GTK.gtk_editable_paste_clipboard(this.handle);
/*      */   }
/*      */   
/*      */   void register()
/*      */   {
/*  856 */     super.register();
/*  857 */     long imContext = imContext();
/*  858 */     if (imContext != 0L) this.display.addWidget(imContext, this);
/*      */   }
/*      */   
/*      */   void releaseWidget()
/*      */   {
/*  863 */     super.releaseWidget();
/*  864 */     fixIM();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeModifyListener(ModifyListener listener)
/*      */   {
/*  885 */     checkWidget();
/*  886 */     if (listener == null) error(4);
/*  887 */     if (this.eventTable == null) return;
/*  888 */     this.eventTable.unhook(24, listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeSelectionListener(SelectionListener listener)
/*      */   {
/*  909 */     checkWidget();
/*  910 */     if (listener == null) error(4);
/*  911 */     if (this.eventTable == null) return;
/*  912 */     this.eventTable.unhook(13, listener);
/*  913 */     this.eventTable.unhook(14, listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void removeVerifyListener(VerifyListener listener)
/*      */   {
/*  934 */     checkWidget();
/*  935 */     if (listener == null) error(4);
/*  936 */     if (this.eventTable == null) return;
/*  937 */     this.eventTable.unhook(25, listener);
/*      */   }
/*      */   
/*      */   GdkRGBA getContextBackgroundGdkRGBA()
/*      */   {
/*  942 */     assert (GTK.GTK3) : "GTK3 code was run by GTK2";
/*  943 */     if ((this.background != null) && ((this.state & 0x2000) != 0)) {
/*  944 */       return this.background;
/*      */     }
/*  946 */     return defaultBackground();
/*      */   }
/*      */   
/*      */   void setBackgroundGdkRGBA(long context, long handle, GdkRGBA rgba)
/*      */   {
/*  951 */     assert (GTK.GTK3) : "GTK3 code was run by GTK2";
/*  952 */     this.background = rgba;
/*  953 */     setBackgroundGradientGdkRGBA(context, handle, rgba);
/*      */   }
/*      */   
/*      */   void setBackgroundGdkColor(GdkColor color)
/*      */   {
/*  958 */     assert (!GTK.GTK3) : "GTK2 code was run by GTK3";
/*  959 */     super.setBackgroundGdkColor(color);
/*  960 */     GTK.gtk_widget_modify_base(this.handle, 0, color);
/*      */   }
/*      */   
/*      */   void setCursor(long cursor)
/*      */   {
/*  965 */     long defaultCursor = 0L;
/*  966 */     if (cursor == 0L) defaultCursor = GDK.gdk_cursor_new_for_display(GDK.gdk_display_get_default(), 152L);
/*  967 */     super.setCursor(cursor != 0L ? cursor : defaultCursor);
/*  968 */     if (cursor == 0L) gdk_cursor_unref(defaultCursor);
/*      */   }
/*      */   
/*      */   void setForegroundGdkColor(GdkColor color)
/*      */   {
/*  973 */     assert (!GTK.GTK3) : "GTK2 code was run by GTK3";
/*  974 */     setForegroundColor(this.handle, color, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setIncrement(int value)
/*      */   {
/*  990 */     checkWidget();
/*  991 */     if (value < 1) return;
/*  992 */     long hAdjustment = GTK.gtk_spin_button_get_adjustment(this.handle);
/*  993 */     double page_increment = GTK.gtk_adjustment_get_page_increment(hAdjustment);
/*  994 */     double newValue = value;
/*  995 */     int digits = GTK.gtk_spin_button_get_digits(this.handle);
/*  996 */     for (int i = 0; i < digits; i++) newValue /= 10.0D;
/*  997 */     OS.g_signal_handlers_block_matched(this.handle, 16, 0, 0, 0L, 0L, 57L);
/*  998 */     GTK.gtk_spin_button_set_increments(this.handle, newValue, page_increment);
/*  999 */     OS.g_signal_handlers_unblock_matched(this.handle, 16, 0, 0, 0L, 0L, 57L);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setMaximum(int value)
/*      */   {
/* 1016 */     checkWidget();
/* 1017 */     long hAdjustment = GTK.gtk_spin_button_get_adjustment(this.handle);
/* 1018 */     double lower = GTK.gtk_adjustment_get_lower(hAdjustment);
/* 1019 */     double newValue = value;
/* 1020 */     int digits = GTK.gtk_spin_button_get_digits(this.handle);
/* 1021 */     for (int i = 0; i < digits; i++) newValue /= 10.0D;
/* 1022 */     if (newValue < lower) return;
/* 1023 */     OS.g_signal_handlers_block_matched(this.handle, 16, 0, 0, 0L, 0L, 57L);
/* 1024 */     GTK.gtk_spin_button_set_range(this.handle, lower, newValue);
/* 1025 */     OS.g_signal_handlers_unblock_matched(this.handle, 16, 0, 0, 0L, 0L, 57L);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setMinimum(int value)
/*      */   {
/* 1042 */     checkWidget();
/* 1043 */     long hAdjustment = GTK.gtk_spin_button_get_adjustment(this.handle);
/* 1044 */     double upper = GTK.gtk_adjustment_get_upper(hAdjustment);
/* 1045 */     double newValue = value;
/* 1046 */     int digits = GTK.gtk_spin_button_get_digits(this.handle);
/* 1047 */     for (int i = 0; i < digits; i++) newValue /= 10.0D;
/* 1048 */     if (newValue > upper) return;
/* 1049 */     OS.g_signal_handlers_block_matched(this.handle, 16, 0, 0, 0L, 0L, 57L);
/* 1050 */     GTK.gtk_spin_button_set_range(this.handle, newValue, upper);
/* 1051 */     OS.g_signal_handlers_unblock_matched(this.handle, 16, 0, 0, 0L, 0L, 57L);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPageIncrement(int value)
/*      */   {
/* 1067 */     checkWidget();
/* 1068 */     if (value < 1) return;
/* 1069 */     long hAdjustment = GTK.gtk_spin_button_get_adjustment(this.handle);
/* 1070 */     double step_increment = GTK.gtk_adjustment_get_step_increment(hAdjustment);
/* 1071 */     double newValue = value;
/* 1072 */     int digits = GTK.gtk_spin_button_get_digits(this.handle);
/* 1073 */     for (int i = 0; i < digits; i++) newValue /= 10.0D;
/* 1074 */     OS.g_signal_handlers_block_matched(this.handle, 16, 0, 0, 0L, 0L, 57L);
/* 1075 */     GTK.gtk_spin_button_set_increments(this.handle, step_increment, newValue);
/* 1076 */     OS.g_signal_handlers_unblock_matched(this.handle, 16, 0, 0, 0L, 0L, 57L);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSelection(int value)
/*      */   {
/* 1093 */     checkWidget();
/* 1094 */     double newValue = value;
/* 1095 */     int digits = GTK.gtk_spin_button_get_digits(this.handle);
/* 1096 */     for (int i = 0; i < digits; i++) newValue /= 10.0D;
/* 1097 */     OS.g_signal_handlers_block_matched(this.handle, 16, 0, 0, 0L, 0L, 57L);
/* 1098 */     GTK.gtk_spin_button_set_value(this.handle, newValue);
/* 1099 */     OS.g_signal_handlers_unblock_matched(this.handle, 16, 0, 0, 0L, 0L, 57L);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTextLimit(int limit)
/*      */   {
/* 1125 */     checkWidget();
/* 1126 */     if (limit == 0) error(7);
/* 1127 */     GTK.gtk_entry_set_max_length(this.handle, limit);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDigits(int value)
/*      */   {
/* 1151 */     checkWidget();
/* 1152 */     if (value < 0) error(5);
/* 1153 */     int digits = GTK.gtk_spin_button_get_digits(this.handle);
/* 1154 */     if (value == digits) return;
/* 1155 */     long hAdjustment = GTK.gtk_spin_button_get_adjustment(this.handle);
/* 1156 */     GtkAdjustment adjustment = new GtkAdjustment();
/* 1157 */     gtk_adjustment_get(hAdjustment, adjustment);
/* 1158 */     int diff = Math.abs(value - digits);
/* 1159 */     int factor = 1;
/* 1160 */     for (int i = 0; i < diff; i++) factor *= 10;
/* 1161 */     if (digits > value) {
/* 1162 */       adjustment.value *= factor;
/* 1163 */       adjustment.upper *= factor;
/* 1164 */       adjustment.lower *= factor;
/* 1165 */       adjustment.step_increment *= factor;
/* 1166 */       adjustment.page_increment *= factor;
/* 1167 */       this.climbRate *= factor;
/*      */     } else {
/* 1169 */       adjustment.value /= factor;
/* 1170 */       adjustment.upper /= factor;
/* 1171 */       adjustment.lower /= factor;
/* 1172 */       adjustment.step_increment /= factor;
/* 1173 */       adjustment.page_increment /= factor;
/* 1174 */       this.climbRate /= factor;
/*      */     }
/* 1176 */     GTK.gtk_adjustment_configure(hAdjustment, adjustment.value, adjustment.lower, adjustment.upper, adjustment.step_increment, adjustment.page_increment, adjustment.page_size);
/*      */     
/* 1178 */     OS.g_signal_handlers_block_matched(this.handle, 16, 0, 0, 0L, 0L, 57L);
/* 1179 */     GTK.gtk_spin_button_configure(this.handle, hAdjustment, this.climbRate, value);
/* 1180 */     OS.g_signal_handlers_unblock_matched(this.handle, 16, 0, 0, 0L, 0L, 57L);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setValues(int selection, int minimum, int maximum, int digits, int increment, int pageIncrement)
/*      */   {
/* 1207 */     checkWidget();
/* 1208 */     if (maximum < minimum) return;
/* 1209 */     if (digits < 0) return;
/* 1210 */     if (increment < 1) return;
/* 1211 */     if (pageIncrement < 1) return;
/* 1212 */     selection = Math.min(Math.max(minimum, selection), maximum);
/* 1213 */     double factor = 1.0D;
/* 1214 */     for (int i = 0; i < digits; i++) { factor *= 10.0D;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1221 */     OS.g_signal_handlers_block_matched(this.handle, 16, 0, 0, 0L, 0L, 57L);
/* 1222 */     this.climbRate = (1.0D / factor);
/* 1223 */     long adjustment = GTK.gtk_spin_button_get_adjustment(this.handle);
/* 1224 */     GTK.gtk_spin_button_configure(this.handle, adjustment, this.climbRate, digits);
/*      */     
/* 1226 */     GTK.gtk_spin_button_set_range(this.handle, minimum / factor, maximum / factor);
/* 1227 */     GTK.gtk_spin_button_set_increments(this.handle, increment / factor, pageIncrement / factor);
/* 1228 */     GTK.gtk_spin_button_set_value(this.handle, selection / factor);
/* 1229 */     OS.g_signal_handlers_unblock_matched(this.handle, 16, 0, 0, 0L, 0L, 57L);
/*      */   }
/*      */   
/*      */   boolean checkSubwindow()
/*      */   {
/* 1234 */     return false;
/*      */   }
/*      */   
/*      */   boolean translateTraversal(GdkEventKey keyEvent)
/*      */   {
/* 1239 */     int key = keyEvent.keyval;
/* 1240 */     switch (key) {
/*      */     case 65293: 
/*      */     case 65421: 
/* 1243 */       long imContext = imContext();
/* 1244 */       if (imContext != 0L) {
/* 1245 */         long[] preeditString = new long[1];
/* 1246 */         GTK.gtk_im_context_get_preedit_string(imContext, preeditString, null, null);
/* 1247 */         if (preeditString[0] != 0L) {
/* 1248 */           int length = C.strlen(preeditString[0]);
/* 1249 */           OS.g_free(preeditString[0]);
/* 1250 */           if (length != 0) return false;
/*      */         }
/*      */       }
/*      */       break;
/*      */     }
/* 1255 */     return super.translateTraversal(keyEvent);
/*      */   }
/*      */   
/*      */   String verifyText(String string, int start, int end) {
/* 1259 */     if ((string.length() == 0) && (start == end)) return null;
/* 1260 */     Event event = new Event();
/* 1261 */     event.text = string;
/* 1262 */     event.start = start;
/* 1263 */     event.end = end;
/* 1264 */     long eventPtr = GTK.gtk_get_current_event();
/* 1265 */     if (eventPtr != 0L) {
/* 1266 */       GdkEventKey gdkEvent = new GdkEventKey();
/* 1267 */       OS.memmove(gdkEvent, eventPtr, GdkEventKey.sizeof);
/* 1268 */       switch (gdkEvent.type) {
/*      */       case 8: 
/* 1270 */         setKeyState(event, gdkEvent);
/*      */       }
/*      */       
/* 1273 */       GDK.gdk_event_free(eventPtr);
/*      */     }
/* 1275 */     int index = 0;
/* 1276 */     if (GTK.gtk_spin_button_get_digits(this.handle) > 0) {
/* 1277 */       String decimalSeparator = getDecimalSeparator();
/* 1278 */       index = string.indexOf(decimalSeparator);
/* 1279 */       if (index != -1) {
/* 1280 */         string = string.substring(0, index) + string.substring(index + 1);
/*      */       }
/* 1282 */       index = 0;
/*      */     }
/* 1284 */     if (string.length() > 0) {
/* 1285 */       long hAdjustment = GTK.gtk_spin_button_get_adjustment(this.handle);
/* 1286 */       double lower = GTK.gtk_adjustment_get_lower(hAdjustment);
/* 1287 */       if ((lower < 0.0D) && (string.charAt(0) == '-')) index++;
/*      */     }
/* 1289 */     while ((index < string.length()) && 
/* 1290 */       (Character.isDigit(string.charAt(index)))) {
/* 1291 */       index++;
/*      */     }
/* 1293 */     event.doit = (index == string.length());
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1300 */     sendEvent(25, event);
/* 1301 */     if ((!event.doit) || (isDisposed())) return null;
/* 1302 */     return event.text;
/*      */   }
/*      */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/widgets/Spinner.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */