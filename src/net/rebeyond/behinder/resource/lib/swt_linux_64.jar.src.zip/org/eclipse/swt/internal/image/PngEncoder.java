/*     */ package org.eclipse.swt.internal.image;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.util.zip.Deflater;
/*     */ import java.util.zip.DeflaterOutputStream;
/*     */ import org.eclipse.swt.SWT;
/*     */ import org.eclipse.swt.graphics.ImageData;
/*     */ import org.eclipse.swt.graphics.ImageLoader;
/*     */ import org.eclipse.swt.graphics.PaletteData;
/*     */ import org.eclipse.swt.graphics.RGB;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class PngEncoder
/*     */ {
/*  21 */   static final byte[] SIGNATURE = { -119, 80, 78, 71, 13, 10, 26, 10 };
/*  22 */   static final byte[] TAG_IHDR = { 73, 72, 68, 82 };
/*  23 */   static final byte[] TAG_PLTE = { 80, 76, 84, 69 };
/*  24 */   static final byte[] TAG_TRNS = { 116, 82, 78, 83 };
/*  25 */   static final byte[] TAG_IDAT = { 73, 68, 65, 84 };
/*  26 */   static final byte[] TAG_IEND = { 73, 69, 78, 68 };
/*     */   
/*     */   static final int NO_COMPRESSION = 0;
/*     */   
/*     */   static final int BEST_SPEED = 1;
/*     */   static final int BEST_COMPRESSION = 9;
/*     */   static final int DEFAULT_COMPRESSION = -1;
/*  33 */   ByteArrayOutputStream bytes = new ByteArrayOutputStream(1024);
/*     */   PngChunk chunk;
/*     */   ImageLoader loader;
/*     */   ImageData data;
/*     */   int transparencyType;
/*     */   int width;
/*     */   int height;
/*     */   int bitDepth;
/*     */   int colorType;
/*  42 */   int compressionMethod = 0;
/*  43 */   int filterMethod = 0;
/*  44 */   int interlaceMethod = 0;
/*     */   
/*     */   public PngEncoder(ImageLoader loader)
/*     */   {
/*  48 */     this.loader = loader;
/*  49 */     this.data = loader.data[0];
/*  50 */     this.transparencyType = this.data.getTransparencyType();
/*     */     
/*  52 */     this.width = this.data.width;
/*  53 */     this.height = this.data.height;
/*     */     
/*  55 */     this.bitDepth = 8;
/*     */     
/*  57 */     this.colorType = 2;
/*     */     
/*  59 */     if (this.data.palette.isDirect) {
/*  60 */       if (this.transparencyType == 1) {
/*  61 */         this.colorType = 6;
/*     */       }
/*     */     }
/*     */     else {
/*  65 */       this.colorType = 3;
/*     */     }
/*     */     
/*  68 */     if ((this.colorType != 2) && (this.colorType != 3) && (this.colorType != 6)) { SWT.error(40);
/*     */     }
/*     */   }
/*     */   
/*     */   void writeShort(ByteArrayOutputStream baos, int theShort)
/*     */   {
/*  74 */     byte byte1 = (byte)(theShort >> 8 & 0xFF);
/*  75 */     byte byte2 = (byte)(theShort & 0xFF);
/*  76 */     byte[] temp = { byte1, byte2 };
/*  77 */     baos.write(temp, 0, 2);
/*     */   }
/*     */   
/*     */ 
/*     */   void writeInt(ByteArrayOutputStream baos, int theInt)
/*     */   {
/*  83 */     byte byte1 = (byte)(theInt >> 24 & 0xFF);
/*  84 */     byte byte2 = (byte)(theInt >> 16 & 0xFF);
/*  85 */     byte byte3 = (byte)(theInt >> 8 & 0xFF);
/*  86 */     byte byte4 = (byte)(theInt & 0xFF);
/*  87 */     byte[] temp = { byte1, byte2, byte3, byte4 };
/*  88 */     baos.write(temp, 0, 4);
/*     */   }
/*     */   
/*     */ 
/*     */   void writeChunk(byte[] tag, byte[] buffer)
/*     */   {
/*  94 */     int bufferLength = buffer != null ? buffer.length : 0;
/*     */     
/*  96 */     this.chunk = new PngChunk(bufferLength);
/*     */     
/*  98 */     writeInt(this.bytes, bufferLength);
/*  99 */     this.bytes.write(tag, 0, 4);
/* 100 */     this.chunk.setType(tag);
/* 101 */     if (bufferLength != 0) {
/* 102 */       this.bytes.write(buffer, 0, bufferLength);
/* 103 */       this.chunk.setData(buffer);
/*     */     }
/*     */     else {
/* 106 */       this.chunk.setCRC(this.chunk.computeCRC());
/*     */     }
/* 108 */     writeInt(this.bytes, this.chunk.getCRC());
/*     */   }
/*     */   
/*     */ 
/*     */   void writeSignature()
/*     */   {
/* 114 */     this.bytes.write(SIGNATURE, 0, 8);
/*     */   }
/*     */   
/*     */ 
/*     */   void writeHeader()
/*     */   {
/* 120 */     ByteArrayOutputStream baos = new ByteArrayOutputStream(13);
/*     */     
/* 122 */     writeInt(baos, this.width);
/* 123 */     writeInt(baos, this.height);
/* 124 */     baos.write(this.bitDepth);
/* 125 */     baos.write(this.colorType);
/* 126 */     baos.write(this.compressionMethod);
/* 127 */     baos.write(this.filterMethod);
/* 128 */     baos.write(this.interlaceMethod);
/*     */     
/* 130 */     writeChunk(TAG_IHDR, baos.toByteArray());
/*     */   }
/*     */   
/*     */ 
/*     */   void writePalette()
/*     */   {
/* 136 */     RGB[] RGBs = this.data.palette.getRGBs();
/*     */     
/* 138 */     if (RGBs.length > 256) { SWT.error(40);
/*     */     }
/* 140 */     ByteArrayOutputStream baos = new ByteArrayOutputStream(RGBs.length);
/*     */     
/* 142 */     for (int i = 0; i < RGBs.length; i++)
/*     */     {
/* 144 */       baos.write((byte)RGBs[i].red);
/* 145 */       baos.write((byte)RGBs[i].green);
/* 146 */       baos.write((byte)RGBs[i].blue);
/*     */     }
/*     */     
/*     */ 
/* 150 */     writeChunk(TAG_PLTE, baos.toByteArray());
/*     */   }
/*     */   
/*     */ 
/*     */   void writeTransparency()
/*     */   {
/* 156 */     ByteArrayOutputStream baos = new ByteArrayOutputStream();
/*     */     
/* 158 */     switch (this.transparencyType)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */     case 1: 
/* 164 */       byte[] alphas = new byte[this.data.palette.getRGBs().length];
/*     */       
/* 166 */       for (int y = 0; y < this.height; y++)
/*     */       {
/* 168 */         for (int x = 0; x < this.width; x++)
/*     */         {
/* 170 */           int pixelValue = this.data.getPixel(x, y);
/* 171 */           int alphaValue = this.data.getAlpha(x, y);
/*     */           
/* 173 */           alphas[pixelValue] = ((byte)alphaValue);
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 179 */       baos.write(alphas, 0, alphas.length);
/*     */       
/* 181 */       break;
/*     */     
/*     */ 
/*     */     case 4: 
/* 185 */       int pixel = this.data.transparentPixel;
/*     */       
/* 187 */       if (this.colorType == 2)
/*     */       {
/* 189 */         int redMask = this.data.palette.redMask;
/* 190 */         int redShift = this.data.palette.redShift;
/* 191 */         int greenMask = this.data.palette.greenMask;
/* 192 */         int greenShift = this.data.palette.greenShift;
/* 193 */         int blueShift = this.data.palette.blueShift;
/* 194 */         int blueMask = this.data.palette.blueMask;
/*     */         
/* 196 */         int r = pixel & redMask;
/* 197 */         r = redShift < 0 ? r >>> -redShift : r << redShift;
/* 198 */         int g = pixel & greenMask;
/* 199 */         g = greenShift < 0 ? g >>> -greenShift : g << greenShift;
/* 200 */         int b = pixel & blueMask;
/* 201 */         b = blueShift < 0 ? b >>> -blueShift : b << blueShift;
/*     */         
/* 203 */         writeShort(baos, r);
/* 204 */         writeShort(baos, g);
/* 205 */         writeShort(baos, b);
/*     */       }
/*     */       
/*     */ 
/* 209 */       if (this.colorType == 3)
/*     */       {
/* 211 */         byte[] padding = new byte[pixel + 1];
/*     */         
/* 213 */         for (int i = 0; i < pixel; i++)
/*     */         {
/* 215 */           padding[i] = -1;
/*     */         }
/*     */         
/*     */ 
/* 219 */         padding[pixel] = 0;
/*     */         
/* 221 */         baos.write(padding, 0, padding.length);
/*     */       }
/*     */       
/*     */ 
/*     */       break;
/*     */     }
/*     */     
/*     */     
/* 229 */     writeChunk(TAG_TRNS, baos.toByteArray());
/*     */   }
/*     */   
/*     */   void writeImageData()
/*     */     throws IOException
/*     */   {
/* 235 */     ByteArrayOutputStream baos = new ByteArrayOutputStream(1024);
/* 236 */     OutputStream os = null;
/* 237 */     switch (this.loader.compression) {
/*     */     case 0: 
/* 239 */       os = new DeflaterOutputStream(baos, new Deflater(0));
/* 240 */       break;
/*     */     case 1: 
/* 242 */       os = new DeflaterOutputStream(baos, new Deflater(1));
/* 243 */       break;
/*     */     case 3: 
/* 245 */       os = new DeflaterOutputStream(baos, new Deflater(9));
/* 246 */       break;
/*     */     case 2: default: 
/* 248 */       os = new DeflaterOutputStream(baos, new Deflater(-1));
/*     */     }
/*     */     
/*     */     
/* 252 */     if (this.colorType == 3)
/*     */     {
/* 254 */       byte[] lineData = new byte[this.width];
/*     */       
/* 256 */       for (int y = 0; y < this.height; y++)
/*     */       {
/* 258 */         int filter = 0;
/* 259 */         os.write(filter);
/*     */         
/* 261 */         this.data.getPixels(0, y, this.width, lineData, 0);
/*     */         
/* 263 */         os.write(lineData);
/*     */       }
/*     */       
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*     */ 
/* 271 */       int[] lineData = new int[this.width];
/* 272 */       byte[] alphaData = null;
/* 273 */       if (this.colorType == 6) {
/* 274 */         alphaData = new byte[this.width];
/*     */       }
/*     */       
/* 277 */       int redMask = this.data.palette.redMask;
/* 278 */       int redShift = this.data.palette.redShift;
/* 279 */       int greenMask = this.data.palette.greenMask;
/* 280 */       int greenShift = this.data.palette.greenShift;
/* 281 */       int blueShift = this.data.palette.blueShift;
/* 282 */       int blueMask = this.data.palette.blueMask;
/*     */       
/* 284 */       byte[] lineBytes = new byte[this.width * (this.colorType == 6 ? 4 : 3)];
/*     */       
/* 286 */       for (int y = 0; y < this.height; y++)
/*     */       {
/* 288 */         int filter = 0;
/* 289 */         os.write(filter);
/*     */         
/* 291 */         this.data.getPixels(0, y, this.width, lineData, 0);
/*     */         
/* 293 */         if (this.colorType == 6) {
/* 294 */           this.data.getAlphas(0, y, this.width, alphaData, 0);
/*     */         }
/*     */         
/* 297 */         int offset = 0;
/* 298 */         for (int x = 0; x < lineData.length; x++)
/*     */         {
/* 300 */           int pixel = lineData[x];
/*     */           
/* 302 */           int r = pixel & redMask;
/* 303 */           lineBytes[(offset++)] = ((byte)(redShift < 0 ? r >>> -redShift : r << redShift));
/*     */           
/* 305 */           int g = pixel & greenMask;
/* 306 */           lineBytes[(offset++)] = ((byte)(greenShift < 0 ? g >>> -greenShift : g << greenShift));
/*     */           
/* 308 */           int b = pixel & blueMask;
/* 309 */           lineBytes[(offset++)] = ((byte)(blueShift < 0 ? b >>> -blueShift : b << blueShift));
/*     */           
/*     */ 
/* 312 */           if (this.colorType == 6) {
/* 313 */             lineBytes[(offset++)] = alphaData[x];
/*     */           }
/*     */         }
/*     */         
/*     */ 
/* 318 */         os.write(lineBytes);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 324 */     os.flush();
/* 325 */     os.close();
/*     */     
/* 327 */     byte[] compressed = baos.toByteArray();
/* 328 */     if (os == baos)
/*     */     {
/* 330 */       PngDeflater deflater = new PngDeflater();
/* 331 */       compressed = deflater.deflate(compressed);
/*     */     }
/*     */     
/* 334 */     writeChunk(TAG_IDAT, compressed);
/*     */   }
/*     */   
/*     */ 
/*     */   void writeEnd()
/*     */   {
/* 340 */     writeChunk(TAG_IEND, null);
/*     */   }
/*     */   
/*     */ 
/*     */   public void encode(LEDataOutputStream outputStream)
/*     */   {
/*     */     try
/*     */     {
/* 348 */       writeSignature();
/* 349 */       writeHeader();
/*     */       
/* 351 */       if (this.colorType == 3) {
/* 352 */         writePalette();
/*     */       }
/*     */       
/* 355 */       boolean transparencyAlpha = this.transparencyType == 1;
/* 356 */       boolean transparencyPixel = this.transparencyType == 4;
/* 357 */       boolean type2Transparency = (this.colorType == 2) && (transparencyPixel);
/* 358 */       boolean type3Transparency = (this.colorType == 3) && ((transparencyAlpha) || (transparencyPixel));
/*     */       
/* 360 */       if ((type2Transparency) || (type3Transparency)) {
/* 361 */         writeTransparency();
/*     */       }
/*     */       
/* 364 */       writeImageData();
/* 365 */       writeEnd();
/*     */       
/* 367 */       outputStream.write(this.bytes.toByteArray());
/*     */ 
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/*     */ 
/* 373 */       SWT.error(39, e);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/internal/image/PngEncoder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */