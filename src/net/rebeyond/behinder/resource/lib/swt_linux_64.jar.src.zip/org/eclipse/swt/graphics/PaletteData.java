/*     */ package org.eclipse.swt.graphics;
/*     */ 
/*     */ import org.eclipse.swt.SWT;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class PaletteData
/*     */ {
/*     */   public boolean isDirect;
/*     */   public RGB[] colors;
/*     */   public int redMask;
/*     */   public int greenMask;
/*     */   public int blueMask;
/*     */   public int redShift;
/*     */   public int greenShift;
/*     */   public int blueShift;
/*     */   
/*     */   public PaletteData(RGB... colors)
/*     */   {
/* 111 */     if (colors == null) SWT.error(4);
/* 112 */     this.colors = colors;
/* 113 */     this.isDirect = false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PaletteData(int redMask, int greenMask, int blueMask)
/*     */   {
/* 124 */     this.redMask = redMask;
/* 125 */     this.greenMask = greenMask;
/* 126 */     this.blueMask = blueMask;
/* 127 */     this.isDirect = true;
/* 128 */     this.redShift = shiftForMask(redMask);
/* 129 */     this.greenShift = shiftForMask(greenMask);
/* 130 */     this.blueShift = shiftForMask(blueMask);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getPixel(RGB rgb)
/*     */   {
/* 145 */     if (rgb == null) SWT.error(4);
/* 146 */     if (this.isDirect) {
/* 147 */       int pixel = 0;
/* 148 */       pixel |= (this.redShift < 0 ? rgb.red << -this.redShift : rgb.red >>> this.redShift) & this.redMask;
/* 149 */       pixel |= (this.greenShift < 0 ? rgb.green << -this.greenShift : rgb.green >>> this.greenShift) & this.greenMask;
/* 150 */       pixel |= (this.blueShift < 0 ? rgb.blue << -this.blueShift : rgb.blue >>> this.blueShift) & this.blueMask;
/* 151 */       return pixel;
/*     */     }
/* 153 */     for (int i = 0; i < this.colors.length; i++) {
/* 154 */       if (this.colors[i].equals(rgb)) { return i;
/*     */       }
/*     */     }
/* 157 */     SWT.error(5);
/* 158 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RGB getRGB(int pixel)
/*     */   {
/* 174 */     if (this.isDirect) {
/* 175 */       int r = pixel & this.redMask;
/* 176 */       r = this.redShift < 0 ? r >>> -this.redShift : r << this.redShift;
/* 177 */       int g = pixel & this.greenMask;
/* 178 */       g = this.greenShift < 0 ? g >>> -this.greenShift : g << this.greenShift;
/* 179 */       int b = pixel & this.blueMask;
/* 180 */       b = this.blueShift < 0 ? b >>> -this.blueShift : b << this.blueShift;
/* 181 */       return new RGB(r, g, b);
/*     */     }
/* 183 */     if ((pixel < 0) || (pixel >= this.colors.length)) {
/* 184 */       SWT.error(5);
/*     */     }
/* 186 */     return this.colors[pixel];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RGB[] getRGBs()
/*     */   {
/* 197 */     return this.colors;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   int shiftForMask(int mask)
/*     */   {
/* 209 */     for (int i = 31; i >= 0; i--) {
/* 210 */       if ((mask >> i & 0x1) != 0) return 7 - i;
/*     */     }
/* 212 */     return 32;
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/graphics/PaletteData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */