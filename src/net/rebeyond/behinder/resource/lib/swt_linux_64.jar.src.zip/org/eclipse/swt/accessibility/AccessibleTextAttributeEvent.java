/*     */ package org.eclipse.swt.accessibility;
/*     */ 
/*     */ import java.util.EventObject;
/*     */ import org.eclipse.swt.graphics.TextStyle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AccessibleTextAttributeEvent
/*     */   extends EventObject
/*     */ {
/*     */   public int offset;
/*     */   public int start;
/*     */   public int end;
/*     */   public TextStyle textStyle;
/*     */   public String[] attributes;
/*     */   public String result;
/*     */   static final long serialVersionUID = 7131825608864332802L;
/*     */   
/*     */   public AccessibleTextAttributeEvent(Object source)
/*     */   {
/*  81 */     super(source);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/*  92 */     return 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  97 */       "AccessibleAttributeEvent { offset=" + this.offset + " start=" + this.start + " end=" + this.end + " textStyle=" + this.textStyle + " attributes=" + toAttributeString(this.attributes) + " result=" + this.result + "}";
/*     */   }
/*     */   
/*     */ 
/*     */   String toAttributeString(String[] attributes)
/*     */   {
/* 103 */     if ((attributes == null) || (attributes.length == 0)) return "" + attributes;
/* 104 */     StringBuilder attributeString = new StringBuilder();
/* 105 */     for (int i = 0; i < attributes.length; i++) {
/* 106 */       attributeString.append(attributes[i]);
/* 107 */       attributeString.append(i % 2 == 0 ? ":" : ";");
/*     */     }
/* 109 */     return attributeString.toString();
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/accessibility/AccessibleTextAttributeEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */