/*      */ package org.eclipse.swt.graphics;
/*      */ 
/*      */ import org.eclipse.swt.SWT;
/*      */ import org.eclipse.swt.internal.DPIUtil;
/*      */ import org.eclipse.swt.internal.cairo.Cairo;
/*      */ import org.eclipse.swt.internal.gtk.GDK;
/*      */ import org.eclipse.swt.internal.gtk.GdkColor;
/*      */ import org.eclipse.swt.internal.gtk.GdkRGBA;
/*      */ import org.eclipse.swt.internal.gtk.GdkRectangle;
/*      */ import org.eclipse.swt.internal.gtk.OS;
/*      */ import org.eclipse.swt.internal.gtk.PangoAttribute;
/*      */ import org.eclipse.swt.internal.gtk.PangoLayoutLine;
/*      */ import org.eclipse.swt.internal.gtk.PangoLogAttr;
/*      */ import org.eclipse.swt.internal.gtk.PangoRectangle;
/*      */ 
/*      */ public final class TextLayout extends Resource
/*      */ {
/*      */   Font font;
/*      */   String text;
/*      */   int ascentInPoints;
/*      */   int descentInPoints;
/*      */   int indent;
/*      */   int wrapIndent;
/*      */   int wrapWidth;
/*      */   int[] segments;
/*      */   char[] segmentsChars;
/*      */   int[] tabs;
/*      */   StyleItem[] styles;
/*      */   int stylesCount;
/*      */   long layout;
/*      */   long context;
/*      */   long attrList;
/*      */   long selAttrList;
/*      */   int[] invalidOffsets;
/*      */   static final char LTR_MARK = '‎';
/*      */   static final char RTL_MARK = '‏';
/*      */   static final char ZWS = '​';
/*      */   static final char ZWNBS = '﻿';
/*      */   
/*      */   static class StyleItem
/*      */   {
/*      */     TextStyle style;
/*      */     int start;
/*      */     
/*      */     public String toString()
/*      */     {
/*   47 */       return "StyleItem {" + this.start + ", " + this.style + "}";
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public TextLayout(Device device)
/*      */   {
/*   79 */     super(device);
/*   80 */     device = this.device;
/*   81 */     this.context = GDK.gdk_pango_context_get();
/*   82 */     if (this.context == 0L) SWT.error(2);
/*   83 */     OS.pango_context_set_language(this.context, org.eclipse.swt.internal.gtk.GTK.gtk_get_default_language());
/*   84 */     OS.pango_context_set_base_dir(this.context, 0);
/*   85 */     this.layout = OS.pango_layout_new(this.context);
/*   86 */     if (this.layout == 0L) SWT.error(2);
/*   87 */     OS.pango_layout_set_font_description(this.layout, device.systemFont.handle);
/*   88 */     OS.pango_layout_set_wrap(this.layout, 2);
/*   89 */     OS.pango_layout_set_tabs(this.layout, device.emptyTab);
/*   90 */     OS.pango_layout_set_auto_dir(this.layout, false);
/*   91 */     this.text = "";
/*   92 */     this.wrapWidth = (this.ascentInPoints = this.descentInPoints = -1);
/*   93 */     this.styles = new StyleItem[2];
/*   94 */     this.styles[0] = new StyleItem();
/*   95 */     this.styles[1] = new StyleItem();
/*   96 */     this.stylesCount = 2;
/*   97 */     init();
/*      */   }
/*      */   
/*      */   void checkLayout() {
/*  101 */     if (isDisposed()) SWT.error(44);
/*      */   }
/*      */   
/*      */   void computeRuns() {
/*  105 */     if (this.attrList != 0L) return;
/*  106 */     String segmentsText = getSegmentsText();
/*  107 */     byte[] buffer = org.eclipse.swt.internal.Converter.wcsToMbcs(segmentsText, false);
/*  108 */     OS.pango_layout_set_text(this.layout, buffer, buffer.length);
/*  109 */     if ((this.stylesCount == 2) && (this.styles[0].style == null) && (this.ascentInPoints == -1) && (this.descentInPoints == -1) && (this.segments == null)) return;
/*  110 */     long ptr = OS.pango_layout_get_text(this.layout);
/*  111 */     this.attrList = OS.pango_attr_list_new();
/*  112 */     this.selAttrList = OS.pango_attr_list_new();
/*  113 */     PangoAttribute attribute = new PangoAttribute();
/*  114 */     char[] chars = null;
/*  115 */     int segementsLength = segmentsText.length();
/*  116 */     int nSegments = segementsLength - this.text.length();
/*  117 */     int offsetCount = nSegments;
/*  118 */     int[] lineOffsets = null;
/*  119 */     if (((this.ascentInPoints != -1) || (this.descentInPoints != -1)) && (segementsLength > 0)) {
/*  120 */       PangoRectangle rect = new PangoRectangle();
/*  121 */       if (this.ascentInPoints != -1) rect.y = (-(DPIUtil.autoScaleUp(getDevice(), this.ascentInPoints) * 1024));
/*  122 */       rect.height = (DPIUtil.autoScaleUp(getDevice(), Math.max(0, this.ascentInPoints) + Math.max(0, this.descentInPoints)) * 1024);
/*  123 */       int lineCount = OS.pango_layout_get_line_count(this.layout);
/*  124 */       chars = new char[segementsLength + lineCount * 2];
/*  125 */       lineOffsets = new int[lineCount];
/*  126 */       int oldPos = 0;int lineIndex = 0;
/*  127 */       PangoLayoutLine line = new PangoLayoutLine();
/*  128 */       while (lineIndex < lineCount) {
/*  129 */         long linePtr = OS.pango_layout_get_line(this.layout, lineIndex);
/*  130 */         OS.memmove(line, linePtr, PangoLayoutLine.sizeof);
/*  131 */         int bytePos = line.start_index;
/*      */         
/*  133 */         int offset = lineIndex * 6;
/*  134 */         long attr = OS.pango_attr_shape_new(rect, rect);
/*  135 */         OS.memmove(attribute, attr, PangoAttribute.sizeof);
/*  136 */         attribute.start_index = (bytePos + offset);
/*  137 */         attribute.end_index = (bytePos + offset + 3);
/*  138 */         OS.memmove(attr, attribute, PangoAttribute.sizeof);
/*  139 */         OS.pango_attr_list_insert(this.attrList, attr);
/*  140 */         OS.pango_attr_list_insert(this.selAttrList, OS.pango_attribute_copy(attr));
/*  141 */         attr = OS.pango_attr_shape_new(rect, rect);
/*  142 */         OS.memmove(attribute, attr, PangoAttribute.sizeof);
/*  143 */         attribute.start_index = (bytePos + offset + 3);
/*  144 */         attribute.end_index = (bytePos + offset + 6);
/*  145 */         OS.memmove(attr, attribute, PangoAttribute.sizeof);
/*  146 */         OS.pango_attr_list_insert(this.attrList, attr);
/*  147 */         OS.pango_attr_list_insert(this.selAttrList, OS.pango_attribute_copy(attr));
/*  148 */         int pos = (int)OS.g_utf16_pointer_to_offset(ptr, ptr + bytePos);
/*  149 */         chars[(pos + lineIndex * 2)] = '​';
/*  150 */         chars[(pos + lineIndex * 2 + 1)] = 65279;
/*  151 */         segmentsText.getChars(oldPos, pos, chars, oldPos + lineIndex * 2);
/*  152 */         lineOffsets[lineIndex] = (pos + lineIndex * 2);
/*  153 */         oldPos = pos;
/*  154 */         lineIndex++;
/*      */       }
/*  156 */       segmentsText.getChars(oldPos, segementsLength, chars, oldPos + lineIndex * 2);
/*  157 */       buffer = org.eclipse.swt.internal.Converter.wcsToMbcs(chars, false);
/*  158 */       OS.pango_layout_set_text(this.layout, buffer, buffer.length);
/*  159 */       ptr = OS.pango_layout_get_text(this.layout);
/*  160 */       offsetCount += 2 * lineCount;
/*      */     } else {
/*  162 */       chars = new char[segementsLength];
/*  163 */       segmentsText.getChars(0, segementsLength, chars, 0);
/*      */     }
/*  165 */     this.invalidOffsets = new int[offsetCount];
/*  166 */     if (offsetCount > 0) {
/*  167 */       offsetCount = 0;
/*  168 */       int lineIndex = 0;
/*  169 */       int segmentCount = 0;
/*  170 */       for (int i = 0; i < chars.length; i++) {
/*  171 */         char c = chars[i];
/*  172 */         if ((c == '​') && (lineOffsets != null) && (lineIndex < lineOffsets.length) && (i == lineOffsets[lineIndex])) {
/*  173 */           this.invalidOffsets[(offsetCount++)] = i;
/*  174 */           this.invalidOffsets[(offsetCount++)] = (++i);
/*  175 */           lineIndex++;
/*  176 */         } else if ((segmentCount < nSegments) && (i - offsetCount == this.segments[segmentCount])) {
/*  177 */           this.invalidOffsets[(offsetCount++)] = i;
/*  178 */           segmentCount++;
/*      */         }
/*      */       }
/*      */     }
/*  182 */     int strlen = org.eclipse.swt.internal.C.strlen(ptr);
/*  183 */     Font defaultFont = this.font != null ? this.font : this.device.systemFont;
/*  184 */     for (int i = 0; i < this.stylesCount - 1; i++) {
/*  185 */       StyleItem styleItem = this.styles[i];
/*  186 */       TextStyle style = styleItem.style;
/*  187 */       if (style != null) {
/*  188 */         int start = translateOffset(styleItem.start);
/*  189 */         int end = translateOffset(this.styles[(i + 1)].start - 1);
/*  190 */         int byteStart = (int)(OS.g_utf16_offset_to_pointer(ptr, start) - ptr);
/*  191 */         int byteEnd = (int)(OS.g_utf16_offset_to_pointer(ptr, end + 1) - ptr);
/*  192 */         byteStart = Math.min(byteStart, strlen);
/*  193 */         byteEnd = Math.min(byteEnd, strlen);
/*  194 */         Font font = style.font;
/*  195 */         if ((font != null) && (!font.isDisposed()) && (!defaultFont.equals(font))) {
/*  196 */           long attr = OS.pango_attr_font_desc_new(font.handle);
/*  197 */           OS.memmove(attribute, attr, PangoAttribute.sizeof);
/*  198 */           attribute.start_index = byteStart;
/*  199 */           attribute.end_index = byteEnd;
/*  200 */           OS.memmove(attr, attribute, PangoAttribute.sizeof);
/*  201 */           OS.pango_attr_list_insert(this.attrList, attr);
/*  202 */           OS.pango_attr_list_insert(this.selAttrList, OS.pango_attribute_copy(attr));
/*      */         }
/*  204 */         if (style.underline) {
/*  205 */           int underlineStyle = 0;
/*  206 */           switch (style.underlineStyle) {
/*      */           case 0: 
/*  208 */             underlineStyle = 1;
/*  209 */             break;
/*      */           case 1: 
/*  211 */             underlineStyle = 2;
/*  212 */             break;
/*      */           case 2: 
/*      */           case 3: 
/*  215 */             underlineStyle = 4;
/*  216 */             break;
/*      */           case 4: 
/*  218 */             if (style.foreground == null) {
/*      */               long attr;
/*      */               long attr;
/*  221 */               if (org.eclipse.swt.internal.gtk.GTK.GTK3) {
/*  222 */                 GdkRGBA linkRGBA = this.device.getSystemColor(36).handleRGBA;
/*      */                 
/*      */ 
/*  225 */                 attr = OS.pango_attr_foreground_new((short)(int)(linkRGBA.red * 65535.0D), (short)(int)(linkRGBA.green * 65535.0D), (short)(int)(linkRGBA.blue * 65535.0D));
/*      */               }
/*      */               else {
/*  228 */                 GdkColor linkColor = this.device.getSystemColor(36).handle;
/*  229 */                 attr = OS.pango_attr_foreground_new(linkColor.red, linkColor.green, linkColor.blue);
/*      */               }
/*  231 */               OS.memmove(attribute, attr, PangoAttribute.sizeof);
/*  232 */               attribute.start_index = byteStart;
/*  233 */               attribute.end_index = byteEnd;
/*  234 */               OS.memmove(attr, attribute, PangoAttribute.sizeof);
/*  235 */               OS.pango_attr_list_insert(this.attrList, attr);
/*      */             }
/*  237 */             underlineStyle = 1;
/*      */           }
/*      */           
/*      */           
/*  241 */           long attr = OS.pango_attr_underline_new(underlineStyle);
/*  242 */           OS.memmove(attribute, attr, PangoAttribute.sizeof);
/*  243 */           attribute.start_index = byteStart;
/*  244 */           attribute.end_index = byteEnd;
/*  245 */           OS.memmove(attr, attribute, PangoAttribute.sizeof);
/*  246 */           OS.pango_attr_list_insert(this.attrList, attr);
/*  247 */           OS.pango_attr_list_insert(this.selAttrList, OS.pango_attribute_copy(attr));
/*  248 */           if (style.underlineColor != null) {
/*  249 */             if (org.eclipse.swt.internal.gtk.GTK.GTK3) {
/*  250 */               GdkRGBA rgba = style.underlineColor.handleRGBA;
/*  251 */               attr = OS.pango_attr_underline_color_new((short)(int)(rgba.red * 65535.0D), (short)(int)(rgba.green * 65535.0D), (short)(int)(rgba.blue * 65535.0D));
/*      */             }
/*      */             else {
/*  254 */               GdkColor fg = style.underlineColor.handle;
/*  255 */               attr = OS.pango_attr_underline_color_new(fg.red, fg.green, fg.blue);
/*      */             }
/*  257 */             if (attr != 0L) {
/*  258 */               OS.memmove(attribute, attr, PangoAttribute.sizeof);
/*  259 */               attribute.start_index = byteStart;
/*  260 */               attribute.end_index = byteEnd;
/*  261 */               OS.memmove(attr, attribute, PangoAttribute.sizeof);
/*  262 */               OS.pango_attr_list_insert(this.attrList, attr);
/*  263 */               OS.pango_attr_list_insert(this.selAttrList, OS.pango_attribute_copy(attr));
/*      */             }
/*      */           }
/*      */         }
/*  267 */         if (style.strikeout) {
/*  268 */           long attr = OS.pango_attr_strikethrough_new(true);
/*  269 */           OS.memmove(attribute, attr, PangoAttribute.sizeof);
/*  270 */           attribute.start_index = byteStart;
/*  271 */           attribute.end_index = byteEnd;
/*  272 */           OS.memmove(attr, attribute, PangoAttribute.sizeof);
/*  273 */           OS.pango_attr_list_insert(this.attrList, attr);
/*  274 */           OS.pango_attr_list_insert(this.selAttrList, OS.pango_attribute_copy(attr));
/*  275 */           if (style.strikeoutColor != null) {
/*  276 */             if (org.eclipse.swt.internal.gtk.GTK.GTK3) {
/*  277 */               GdkRGBA rgba = style.strikeoutColor.handleRGBA;
/*  278 */               attr = OS.pango_attr_strikethrough_color_new((short)(int)(rgba.red * 65535.0D), (short)(int)(rgba.green * 65535.0D), (short)(int)(rgba.blue * 65535.0D));
/*      */             }
/*      */             else {
/*  281 */               GdkColor fg = style.strikeoutColor.handle;
/*  282 */               attr = OS.pango_attr_strikethrough_color_new(fg.red, fg.green, fg.blue);
/*      */             }
/*  284 */             if (attr != 0L) {
/*  285 */               OS.memmove(attribute, attr, PangoAttribute.sizeof);
/*  286 */               attribute.start_index = byteStart;
/*  287 */               attribute.end_index = byteEnd;
/*  288 */               OS.memmove(attr, attribute, PangoAttribute.sizeof);
/*  289 */               OS.pango_attr_list_insert(this.attrList, attr);
/*  290 */               OS.pango_attr_list_insert(this.selAttrList, OS.pango_attribute_copy(attr));
/*      */             }
/*      */           }
/*      */         }
/*  294 */         Color foreground = style.foreground;
/*  295 */         if ((foreground != null) && (!foreground.isDisposed())) { long attr;
/*      */           long attr;
/*  297 */           if (org.eclipse.swt.internal.gtk.GTK.GTK3) {
/*  298 */             GdkRGBA rgba = foreground.handleRGBA;
/*  299 */             attr = OS.pango_attr_foreground_new((short)(int)(rgba.red * 65535.0D), (short)(int)(rgba.green * 65535.0D), (short)(int)(rgba.blue * 65535.0D));
/*      */           }
/*      */           else {
/*  302 */             GdkColor fg = foreground.handle;
/*  303 */             attr = OS.pango_attr_foreground_new(fg.red, fg.green, fg.blue);
/*      */           }
/*  305 */           OS.memmove(attribute, attr, PangoAttribute.sizeof);
/*  306 */           attribute.start_index = byteStart;
/*  307 */           attribute.end_index = byteEnd;
/*  308 */           OS.memmove(attr, attribute, PangoAttribute.sizeof);
/*  309 */           OS.pango_attr_list_insert(this.attrList, attr);
/*      */         }
/*  311 */         Color background = style.background;
/*  312 */         if ((background != null) && (!background.isDisposed())) { long attr;
/*      */           long attr;
/*  314 */           if (org.eclipse.swt.internal.gtk.GTK.GTK3) {
/*  315 */             GdkRGBA rgba = background.handleRGBA;
/*  316 */             attr = OS.pango_attr_background_new((short)(int)(rgba.red * 65535.0D), (short)(int)(rgba.green * 65535.0D), (short)(int)(rgba.blue * 65535.0D));
/*      */           }
/*      */           else {
/*  319 */             GdkColor bg = background.handle;
/*  320 */             attr = OS.pango_attr_background_new(bg.red, bg.green, bg.blue);
/*      */           }
/*  322 */           OS.memmove(attribute, attr, PangoAttribute.sizeof);
/*  323 */           attribute.start_index = byteStart;
/*  324 */           attribute.end_index = byteEnd;
/*  325 */           OS.memmove(attr, attribute, PangoAttribute.sizeof);
/*  326 */           OS.pango_attr_list_insert(this.attrList, attr);
/*      */         }
/*  328 */         GlyphMetrics metrics = style.metrics;
/*  329 */         if (metrics != null) {
/*  330 */           PangoRectangle rect = new PangoRectangle();
/*  331 */           rect.y = (-(DPIUtil.autoScaleUp(getDevice(), metrics.ascent) * 1024));
/*  332 */           rect.height = (DPIUtil.autoScaleUp(getDevice(), metrics.ascent + metrics.descent) * 1024);
/*  333 */           rect.width = (DPIUtil.autoScaleUp(getDevice(), metrics.width) * 1024);
/*  334 */           long attr = OS.pango_attr_shape_new(rect, rect);
/*  335 */           OS.memmove(attribute, attr, PangoAttribute.sizeof);
/*  336 */           attribute.start_index = byteStart;
/*  337 */           attribute.end_index = byteEnd;
/*  338 */           OS.memmove(attr, attribute, PangoAttribute.sizeof);
/*  339 */           OS.pango_attr_list_insert(this.attrList, attr);
/*  340 */           OS.pango_attr_list_insert(this.selAttrList, OS.pango_attribute_copy(attr));
/*      */         }
/*  342 */         int rise = style.rise;
/*  343 */         if (rise != 0) {
/*  344 */           long attr = OS.pango_attr_rise_new(DPIUtil.autoScaleUp(getDevice(), rise) * 1024);
/*  345 */           OS.memmove(attribute, attr, PangoAttribute.sizeof);
/*  346 */           attribute.start_index = byteStart;
/*  347 */           attribute.end_index = byteEnd;
/*  348 */           OS.memmove(attr, attribute, PangoAttribute.sizeof);
/*  349 */           OS.pango_attr_list_insert(this.attrList, attr);
/*  350 */           OS.pango_attr_list_insert(this.selAttrList, OS.pango_attribute_copy(attr));
/*      */         }
/*      */       } }
/*  353 */     OS.pango_layout_set_attributes(this.layout, this.attrList);
/*      */   }
/*      */   
/*      */   int[] computePolyline(int left, int top, int right, int bottom) {
/*  357 */     int height = bottom - top;
/*  358 */     int width = 2 * height;
/*  359 */     int peaks = org.eclipse.swt.internal.Compatibility.ceil(right - left, width);
/*  360 */     if ((peaks == 0) && (right - left > 2)) {
/*  361 */       peaks = 1;
/*      */     }
/*  363 */     int length = (2 * peaks + 1) * 2;
/*  364 */     if (length < 0) { return new int[0];
/*      */     }
/*  366 */     int[] coordinates = new int[length];
/*  367 */     for (int i = 0; i < peaks; i++) {
/*  368 */       int index = 4 * i;
/*  369 */       coordinates[index] = (left + width * i);
/*  370 */       coordinates[(index + 1)] = bottom;
/*  371 */       coordinates[(index + 2)] = (coordinates[index] + width / 2);
/*  372 */       coordinates[(index + 3)] = top;
/*      */     }
/*  374 */     coordinates[(length - 2)] = (left + width * peaks);
/*  375 */     coordinates[(length - 1)] = bottom;
/*  376 */     return coordinates;
/*      */   }
/*      */   
/*      */   void destroy()
/*      */   {
/*  381 */     this.font = null;
/*  382 */     this.text = null;
/*  383 */     this.styles = null;
/*  384 */     freeRuns();
/*  385 */     this.segments = null;
/*  386 */     this.segmentsChars = null;
/*  387 */     if (this.layout != 0L) OS.g_object_unref(this.layout);
/*  388 */     this.layout = 0L;
/*  389 */     if (this.context != 0L) OS.g_object_unref(this.context);
/*  390 */     this.context = 0L;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void draw(GC gc, int x, int y)
/*      */   {
/*  409 */     x = DPIUtil.autoScaleUp(getDevice(), x);
/*  410 */     y = DPIUtil.autoScaleUp(getDevice(), y);
/*  411 */     drawInPixels(gc, x, y);
/*      */   }
/*      */   
/*      */   void drawInPixels(GC gc, int x, int y) {
/*  415 */     drawInPixels(gc, x, y, -1, -1, null, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void draw(GC gc, int x, int y, int selectionStart, int selectionEnd, Color selectionForeground, Color selectionBackground)
/*      */   {
/*  438 */     checkLayout();
/*  439 */     x = DPIUtil.autoScaleUp(getDevice(), x);
/*  440 */     y = DPIUtil.autoScaleUp(getDevice(), y);
/*  441 */     drawInPixels(gc, x, y, selectionStart, selectionEnd, selectionForeground, selectionBackground);
/*      */   }
/*      */   
/*  444 */   void drawInPixels(GC gc, int x, int y, int selectionStart, int selectionEnd, Color selectionForeground, Color selectionBackground) { drawInPixels(gc, x, y, selectionStart, selectionEnd, selectionForeground, selectionBackground, 0); }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void draw(GC gc, int x, int y, int selectionStart, int selectionEnd, Color selectionForeground, Color selectionBackground, int flags)
/*      */   {
/*  475 */     checkLayout();
/*  476 */     x = DPIUtil.autoScaleUp(getDevice(), x);
/*  477 */     y = DPIUtil.autoScaleUp(getDevice(), y);
/*  478 */     drawInPixels(gc, x, y, selectionStart, selectionEnd, selectionForeground, selectionBackground, flags);
/*      */   }
/*      */   
/*  481 */   void drawInPixels(GC gc, int x, int y, int selectionStart, int selectionEnd, Color selectionForeground, Color selectionBackground, int flags) { checkLayout();
/*  482 */     computeRuns();
/*  483 */     if (gc == null) SWT.error(4);
/*  484 */     if (gc.isDisposed()) SWT.error(5);
/*  485 */     if ((selectionForeground != null) && (selectionForeground.isDisposed())) SWT.error(5);
/*  486 */     if ((selectionBackground != null) && (selectionBackground.isDisposed())) SWT.error(5);
/*  487 */     gc.checkGC(1);
/*  488 */     int length = this.text.length();
/*  489 */     x += Math.min(this.indent, this.wrapIndent);
/*  490 */     boolean hasSelection = (selectionStart <= selectionEnd) && (selectionStart != -1) && (selectionEnd != -1);
/*  491 */     GCData data = gc.data;
/*  492 */     long cairo = data.cairo;
/*  493 */     if (((flags & 0x30000) != 0) && ((hasSelection) || ((flags & 0x100000) != 0))) {
/*  494 */       long[] attrs = new long[1];
/*  495 */       int[] nAttrs = new int[1];
/*  496 */       PangoLogAttr logAttr = new PangoLogAttr();
/*  497 */       PangoRectangle rect = new PangoRectangle();
/*  498 */       int lineCount = OS.pango_layout_get_line_count(this.layout);
/*  499 */       long ptr = OS.pango_layout_get_text(this.layout);
/*  500 */       long iter = OS.pango_layout_get_iter(this.layout);
/*  501 */       if (selectionBackground == null) selectionBackground = this.device.getSystemColor(26);
/*  502 */       Cairo.cairo_save(cairo);
/*  503 */       if (org.eclipse.swt.internal.gtk.GTK.GTK3) {
/*  504 */         GdkRGBA rgba = selectionBackground.handleRGBA;
/*  505 */         Cairo.cairo_set_source_rgba(cairo, rgba.red, rgba.green, rgba.blue, rgba.alpha);
/*      */       } else {
/*  507 */         GdkColor color = selectionBackground.handle;
/*  508 */         Cairo.cairo_set_source_rgba(cairo, (color.red & 0xFFFF) / 65535.0F, (color.green & 0xFFFF) / 65535.0F, (color.blue & 0xFFFF) / 65535.0F, data.alpha / 255.0F);
/*      */       }
/*  510 */       int lineIndex = 0;
/*      */       do
/*      */       {
/*  513 */         OS.pango_layout_iter_get_line_extents(iter, null, rect);
/*  514 */         int lineEnd; int lineEnd; if (OS.pango_layout_iter_next_line(iter)) {
/*  515 */           int bytePos = OS.pango_layout_iter_get_index(iter);
/*  516 */           lineEnd = (int)OS.g_utf16_pointer_to_offset(ptr, ptr + bytePos);
/*      */         } else {
/*  518 */           lineEnd = (int)OS.g_utf16_strlen(ptr, -1L);
/*      */         }
/*  520 */         boolean extent = false;
/*  521 */         if ((lineIndex == lineCount - 1) && ((flags & 0x100000) != 0)) {
/*  522 */           extent = true;
/*      */         } else {
/*  524 */           if (attrs[0] == 0L) OS.pango_layout_get_log_attrs(this.layout, attrs, nAttrs);
/*  525 */           OS.memmove(logAttr, attrs[0] + lineEnd * PangoLogAttr.sizeof, PangoLogAttr.sizeof);
/*  526 */           if (!logAttr.is_line_break) {
/*  527 */             if ((selectionStart <= lineEnd) && (lineEnd <= selectionEnd)) extent = true;
/*      */           }
/*  529 */           else if ((selectionStart <= lineEnd) && (lineEnd < selectionEnd) && ((flags & 0x10000) != 0)) {
/*  530 */             extent = true;
/*      */           }
/*      */         }
/*      */         
/*  534 */         if (extent) {
/*  535 */           int lineX = x + OS.PANGO_PIXELS(rect.x) + OS.PANGO_PIXELS(rect.width);
/*  536 */           int lineY = y + OS.PANGO_PIXELS(rect.y);
/*  537 */           int height = OS.PANGO_PIXELS(rect.height);
/*  538 */           if ((this.ascentInPoints != -1) && (this.descentInPoints != -1)) {
/*  539 */             height = Math.max(height, DPIUtil.autoScaleUp(getDevice(), this.ascentInPoints + this.descentInPoints));
/*      */           }
/*  541 */           int width = (flags & 0x10000) != 0 ? 32767 : height / 3;
/*  542 */           Cairo.cairo_rectangle(cairo, lineX, lineY, width, height);
/*  543 */           Cairo.cairo_fill(cairo);
/*      */         }
/*  545 */         lineIndex++;
/*  546 */       } while (lineIndex < lineCount);
/*  547 */       OS.pango_layout_iter_free(iter);
/*  548 */       if (attrs[0] != 0L) OS.g_free(attrs[0]);
/*  549 */       Cairo.cairo_restore(cairo);
/*      */     }
/*  551 */     if (length == 0) return;
/*  552 */     if (!hasSelection) {
/*  553 */       if ((data.style & 0x8000000) != 0) {
/*  554 */         Cairo.cairo_save(cairo);
/*  555 */         Cairo.cairo_scale(cairo, -1.0D, 1.0D);
/*  556 */         Cairo.cairo_translate(cairo, -2 * x - width(), 0.0D);
/*      */       }
/*  558 */       Cairo.cairo_move_to(cairo, x, y);
/*  559 */       OS.pango_cairo_show_layout(cairo, this.layout);
/*  560 */       drawBorder(gc, x, y, null);
/*  561 */       if ((data.style & 0x8000000) != 0) {
/*  562 */         Cairo.cairo_restore(cairo);
/*      */       }
/*      */     } else {
/*  565 */       selectionStart = Math.min(Math.max(0, selectionStart), length - 1);
/*  566 */       selectionEnd = Math.min(Math.max(0, selectionEnd), length - 1);
/*  567 */       length = (int)OS.g_utf16_strlen(OS.pango_layout_get_text(this.layout), -1L);
/*  568 */       selectionStart = translateOffset(selectionStart);
/*  569 */       selectionEnd = translateOffset(selectionEnd);
/*  570 */       if (selectionForeground == null) selectionForeground = this.device.getSystemColor(27);
/*  571 */       if (selectionBackground == null) selectionBackground = this.device.getSystemColor(26);
/*  572 */       boolean fullSelection = (selectionStart == 0) && (selectionEnd == length - 1);
/*  573 */       if (fullSelection) {
/*  574 */         long ptr = OS.pango_layout_get_text(this.layout);
/*  575 */         if ((data.style & 0x8000000) != 0) {
/*  576 */           Cairo.cairo_save(cairo);
/*  577 */           Cairo.cairo_scale(cairo, -1.0D, 1.0D);
/*  578 */           Cairo.cairo_translate(cairo, -2 * x - width(), 0.0D);
/*      */         }
/*  580 */         drawWithCairo(gc, x, y, 0, org.eclipse.swt.internal.C.strlen(ptr), fullSelection, selectionForeground, selectionBackground);
/*  581 */         if ((data.style & 0x8000000) != 0) {
/*  582 */           Cairo.cairo_restore(cairo);
/*      */         }
/*      */       } else {
/*  585 */         long ptr = OS.pango_layout_get_text(this.layout);
/*  586 */         int byteSelStart = (int)(OS.g_utf16_offset_to_pointer(ptr, selectionStart) - ptr);
/*  587 */         int byteSelEnd = (int)(OS.g_utf16_offset_to_pointer(ptr, selectionEnd + 1) - ptr);
/*  588 */         int strlen = org.eclipse.swt.internal.C.strlen(ptr);
/*  589 */         byteSelStart = Math.min(byteSelStart, strlen);
/*  590 */         byteSelEnd = Math.min(byteSelEnd, strlen);
/*  591 */         if ((data.style & 0x8000000) != 0) {
/*  592 */           Cairo.cairo_save(cairo);
/*  593 */           Cairo.cairo_scale(cairo, -1.0D, 1.0D);
/*  594 */           Cairo.cairo_translate(cairo, -2 * x - width(), 0.0D);
/*      */         }
/*  596 */         drawWithCairo(gc, x, y, byteSelStart, byteSelEnd, fullSelection, selectionForeground, selectionBackground);
/*  597 */         if ((data.style & 0x8000000) != 0) {
/*  598 */           Cairo.cairo_restore(cairo);
/*      */         }
/*      */       }
/*      */     }
/*  602 */     Cairo.cairo_new_path(cairo);
/*      */   }
/*      */   
/*      */ 
/*      */   void drawWithCairo(GC gc, int x, int y, int start, int end, boolean fullSelection, Color fg, Color bg)
/*      */   {
/*  608 */     GCData data = gc.data;
/*  609 */     long cairo = data.cairo;
/*  610 */     Cairo.cairo_save(cairo);
/*  611 */     if (!fullSelection) {
/*  612 */       Cairo.cairo_move_to(cairo, x, y);
/*  613 */       OS.pango_cairo_show_layout(cairo, this.layout);
/*  614 */       drawBorder(gc, x, y, null);
/*      */     }
/*  616 */     int[] ranges = { start, end };
/*  617 */     long rgn = GDK.gdk_pango_layout_get_clip_region(this.layout, x, y, ranges, ranges.length / 2);
/*  618 */     if (rgn != 0L) {
/*  619 */       GDK.gdk_cairo_region(cairo, rgn);
/*  620 */       Cairo.cairo_clip(cairo);
/*  621 */       if (org.eclipse.swt.internal.gtk.GTK.GTK3) {
/*  622 */         Cairo.cairo_set_source_rgba(cairo, bg.handleRGBA.red, bg.handleRGBA.green, bg.handleRGBA.blue, bg.handleRGBA.alpha);
/*      */       } else {
/*  624 */         Cairo.cairo_set_source_rgba(cairo, (bg.handle.red & 0xFFFF) / 65535.0F, (bg.handle.green & 0xFFFF) / 65535.0F, (bg.handle.blue & 0xFFFF) / 65535.0F, data.alpha / 255.0F);
/*      */       }
/*  626 */       Cairo.cairo_paint(cairo);
/*  627 */       GDK.gdk_region_destroy(rgn);
/*      */     }
/*  629 */     if (org.eclipse.swt.internal.gtk.GTK.GTK3) {
/*  630 */       Cairo.cairo_set_source_rgba(cairo, fg.handleRGBA.red, fg.handleRGBA.green, fg.handleRGBA.blue, fg.handleRGBA.alpha);
/*      */     } else {
/*  632 */       Cairo.cairo_set_source_rgba(cairo, (fg.handle.red & 0xFFFF) / 65535.0F, (fg.handle.green & 0xFFFF) / 65535.0F, (fg.handle.blue & 0xFFFF) / 65535.0F, data.alpha / 255.0F);
/*      */     }
/*  634 */     Cairo.cairo_move_to(cairo, x, y);
/*  635 */     OS.pango_layout_set_attributes(this.layout, this.selAttrList);
/*  636 */     OS.pango_cairo_show_layout(cairo, this.layout);
/*  637 */     OS.pango_layout_set_attributes(this.layout, this.attrList);
/*  638 */     drawBorder(gc, x, y, fg);
/*  639 */     Cairo.cairo_restore(cairo);
/*      */   }
/*      */   
/*      */ 
/*      */   void drawBorder(GC gc, int x, int y, Color selectionColor)
/*      */   {
/*  645 */     GCData data = gc.data;
/*  646 */     long cairo = data.cairo;
/*  647 */     long ptr = OS.pango_layout_get_text(this.layout);
/*  648 */     Cairo.cairo_save(cairo);
/*  649 */     for (int i = 0; i < this.stylesCount - 1; i++) {
/*  650 */       TextStyle style = this.styles[i].style;
/*  651 */       if (style != null)
/*      */       {
/*  653 */         boolean drawBorder = style.borderStyle != 0;
/*  654 */         if ((drawBorder) && (!style.isAdherentBorder(this.styles[(i + 1)].style))) {
/*  655 */           int start = this.styles[i].start;
/*  656 */           for (int j = i; (j > 0) && (style.isAdherentBorder(this.styles[(j - 1)].style)); j--) {
/*  657 */             start = this.styles[(j - 1)].start;
/*      */           }
/*  659 */           start = translateOffset(start);
/*  660 */           int end = translateOffset(this.styles[(i + 1)].start - 1);
/*  661 */           int byteStart = (int)(OS.g_utf16_offset_to_pointer(ptr, start) - ptr);
/*  662 */           int byteEnd = (int)(OS.g_utf16_offset_to_pointer(ptr, end + 1) - ptr);
/*  663 */           int[] ranges = { byteStart, byteEnd };
/*  664 */           long rgn = GDK.gdk_pango_layout_get_clip_region(this.layout, x, y, ranges, ranges.length / 2);
/*  665 */           if (rgn != 0L) {
/*  666 */             int[] nRects = new int[1];
/*  667 */             long[] rects = new long[1];
/*  668 */             Region.gdk_region_get_rectangles(rgn, rects, nRects);
/*  669 */             GdkRectangle rect = new GdkRectangle();
/*  670 */             GdkRGBA colorRGBA = null;
/*  671 */             GdkColor color = null;
/*  672 */             if (org.eclipse.swt.internal.gtk.GTK.GTK3) {
/*  673 */               if ((colorRGBA == null) && (style.borderColor != null)) colorRGBA = style.borderColor.handleRGBA;
/*  674 */               if ((colorRGBA == null) && (selectionColor != null)) colorRGBA = selectionColor.handleRGBA;
/*  675 */               if ((colorRGBA == null) && (style.foreground != null)) colorRGBA = style.foreground.handleRGBA;
/*  676 */               if (colorRGBA == null) colorRGBA = data.foregroundRGBA;
/*      */             } else {
/*  678 */               if ((color == null) && (style.borderColor != null)) color = style.borderColor.handle;
/*  679 */               if ((color == null) && (selectionColor != null)) color = selectionColor.handle;
/*  680 */               if ((color == null) && (style.foreground != null)) color = style.foreground.handle;
/*  681 */               if (color == null) color = data.foreground;
/*      */             }
/*  683 */             int width = 1;
/*  684 */             float[] dashes = null;
/*  685 */             switch (style.borderStyle) {
/*      */             case 1: 
/*      */               break; case 2:  dashes = width != 0 ? GC.LINE_DASH : GC.LINE_DASH_ZERO; break;
/*  688 */             case 4:  dashes = width != 0 ? GC.LINE_DOT : GC.LINE_DOT_ZERO;
/*      */             }
/*  690 */             if (org.eclipse.swt.internal.gtk.GTK.GTK3) {
/*  691 */               Cairo.cairo_set_source_rgba(cairo, colorRGBA.red, colorRGBA.green, colorRGBA.blue, colorRGBA.alpha);
/*      */             } else {
/*  693 */               Cairo.cairo_set_source_rgba(cairo, (color.red & 0xFFFF) / 65535.0F, (color.green & 0xFFFF) / 65535.0F, (color.blue & 0xFFFF) / 65535.0F, data.alpha / 255.0F);
/*      */             }
/*  695 */             Cairo.cairo_set_line_width(cairo, width);
/*  696 */             if (dashes != null) {
/*  697 */               double[] cairoDashes = new double[dashes.length];
/*  698 */               for (int j = 0; j < cairoDashes.length; j++) {
/*  699 */                 cairoDashes[j] = ((width == 0) || (data.lineStyle == 6) ? dashes[j] : dashes[j] * width);
/*      */               }
/*  701 */               Cairo.cairo_set_dash(cairo, cairoDashes, cairoDashes.length, 0.0D);
/*      */             } else {
/*  703 */               Cairo.cairo_set_dash(cairo, null, 0, 0.0D);
/*      */             }
/*  705 */             for (int j = 0; j < nRects[0]; j++) {
/*  706 */               OS.memmove(rect, rects[0] + j * GdkRectangle.sizeof, GdkRectangle.sizeof);
/*  707 */               Cairo.cairo_rectangle(cairo, rect.x + 0.5D, rect.y + 0.5D, rect.width - 1, rect.height - 1);
/*      */             }
/*  709 */             Cairo.cairo_stroke(cairo);
/*  710 */             if (rects[0] != 0L) OS.g_free(rects[0]);
/*  711 */             GDK.gdk_region_destroy(rgn);
/*      */           }
/*      */         }
/*      */       } }
/*  715 */     Cairo.cairo_restore(cairo);
/*      */   }
/*      */   
/*      */   void freeRuns() {
/*  719 */     if (this.attrList == 0L) return;
/*  720 */     OS.pango_layout_set_attributes(this.layout, 0L);
/*  721 */     OS.pango_attr_list_unref(this.attrList);
/*  722 */     this.attrList = 0L;
/*  723 */     if (this.selAttrList != 0L) {
/*  724 */       OS.pango_attr_list_unref(this.selAttrList);
/*  725 */       this.selAttrList = 0L;
/*      */     }
/*  727 */     this.invalidOffsets = null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getAlignment()
/*      */   {
/*  742 */     checkLayout();
/*  743 */     int align = OS.pango_layout_get_alignment(this.layout);
/*  744 */     boolean rtl = OS.pango_context_get_base_dir(this.context) == 1;
/*  745 */     switch (align) {
/*  746 */     case 0:  return rtl ? 131072 : 16384;
/*  747 */     case 2:  return rtl ? 16384 : 131072;
/*      */     }
/*  749 */     return 16777216;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getAscent()
/*      */   {
/*  767 */     checkLayout();
/*  768 */     return this.ascentInPoints;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Rectangle getBounds()
/*      */   {
/*  786 */     checkLayout();
/*  787 */     Rectangle bounds = DPIUtil.autoScaleDown(getDevice(), getBoundsInPixels());
/*  788 */     int lineCount = OS.pango_layout_get_line_count(this.layout);
/*  789 */     int totalLineheight = 0;
/*  790 */     for (int i = 0; i < lineCount; i++) {
/*  791 */       totalLineheight += getLineBounds(i).height + OS.PANGO_PIXELS(OS.pango_layout_get_spacing(this.layout));
/*      */     }
/*  793 */     bounds.height = totalLineheight;
/*  794 */     return bounds;
/*      */   }
/*      */   
/*  797 */   Rectangle getBoundsInPixels() { checkLayout();
/*  798 */     computeRuns();
/*  799 */     int[] w = new int[1];int[] h = new int[1];
/*  800 */     OS.pango_layout_get_size(this.layout, w, h);
/*  801 */     int wrapWidth = OS.pango_layout_get_width(this.layout);
/*  802 */     w[0] = (wrapWidth != -1 ? wrapWidth : w[0] + OS.pango_layout_get_indent(this.layout));
/*  803 */     int width = OS.PANGO_PIXELS(w[0]);
/*  804 */     int height = OS.PANGO_PIXELS(h[0]);
/*  805 */     if ((this.ascentInPoints != -1) && (this.descentInPoints != -1)) {
/*  806 */       height = Math.max(height, DPIUtil.autoScaleUp(getDevice(), this.ascentInPoints + this.descentInPoints));
/*      */     }
/*  808 */     height += OS.PANGO_PIXELS(OS.pango_layout_get_spacing(this.layout));
/*  809 */     return new Rectangle(0, 0, width, height);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Rectangle getBounds(int start, int end)
/*      */   {
/*  827 */     checkLayout();
/*  828 */     return DPIUtil.autoScaleDown(getDevice(), getBoundsInPixels(start, end));
/*      */   }
/*      */   
/*      */   Rectangle getBoundsInPixels(int start, int end) {
/*  832 */     checkLayout();
/*  833 */     computeRuns();
/*  834 */     int length = this.text.length();
/*  835 */     if (length == 0) return new Rectangle(0, 0, 0, 0);
/*  836 */     if (start > end) return new Rectangle(0, 0, 0, 0);
/*  837 */     start = Math.min(Math.max(0, start), length - 1);
/*  838 */     end = Math.min(Math.max(0, end), length - 1);
/*  839 */     start = translateOffset(start);
/*  840 */     end = translateOffset(end);
/*  841 */     long ptr = OS.pango_layout_get_text(this.layout);
/*  842 */     int byteStart = (int)(OS.g_utf16_offset_to_pointer(ptr, start) - ptr);
/*  843 */     int byteEnd = (int)(OS.g_utf16_offset_to_pointer(ptr, end + 1) - ptr);
/*  844 */     int strlen = org.eclipse.swt.internal.C.strlen(ptr);
/*  845 */     byteStart = Math.min(byteStart, strlen);
/*  846 */     byteEnd = Math.min(byteEnd, strlen);
/*  847 */     int[] ranges = { byteStart, byteEnd };
/*  848 */     long clipRegion = GDK.gdk_pango_layout_get_clip_region(this.layout, 0, 0, ranges, 1);
/*  849 */     if (clipRegion == 0L) return new Rectangle(0, 0, 0, 0);
/*  850 */     GdkRectangle rect = new GdkRectangle();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  857 */     PangoRectangle pangoRect = new PangoRectangle();
/*  858 */     long iter = OS.pango_layout_get_iter(this.layout);
/*  859 */     if (iter == 0L) SWT.error(2);
/*  860 */     long linesRegion = GDK.gdk_region_new();
/*  861 */     if (linesRegion == 0L) SWT.error(2);
/*  862 */     int lineEnd = 0;
/*      */     do {
/*  864 */       OS.pango_layout_iter_get_line_extents(iter, null, pangoRect);
/*  865 */       if (OS.pango_layout_iter_next_line(iter)) {
/*  866 */         lineEnd = OS.pango_layout_iter_get_index(iter) - 1;
/*      */       } else {
/*  868 */         lineEnd = strlen;
/*      */       }
/*  870 */       if (byteStart <= lineEnd) {
/*  871 */         rect.x = OS.PANGO_PIXELS(pangoRect.x);
/*  872 */         rect.y = OS.PANGO_PIXELS(pangoRect.y);
/*  873 */         rect.width = OS.PANGO_PIXELS(pangoRect.width);
/*  874 */         rect.height = OS.PANGO_PIXELS(pangoRect.height);
/*  875 */         GDK.gdk_region_union_with_rect(linesRegion, rect);
/*  876 */       } } while (lineEnd + 1 <= byteEnd);
/*  877 */     GDK.gdk_region_intersect(clipRegion, linesRegion);
/*  878 */     GDK.gdk_region_destroy(linesRegion);
/*  879 */     OS.pango_layout_iter_free(iter);
/*      */     
/*  881 */     GDK.gdk_region_get_clipbox(clipRegion, rect);
/*  882 */     GDK.gdk_region_destroy(clipRegion);
/*  883 */     if (OS.pango_context_get_base_dir(this.context) == 1) {
/*  884 */       rect.x = (width() - rect.x - rect.width);
/*      */     }
/*  886 */     rect.x += Math.min(this.indent, this.wrapIndent);
/*  887 */     return new Rectangle(rect.x, rect.y, rect.width, rect.height);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getDescent()
/*      */   {
/*  905 */     checkLayout();
/*  906 */     return this.descentInPoints;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Font getFont()
/*      */   {
/*  920 */     checkLayout();
/*  921 */     return this.font;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getIndent()
/*      */   {
/*  936 */     checkLayout();
/*  937 */     return DPIUtil.autoScaleDown(getDevice(), getIndentInPixels());
/*      */   }
/*      */   
/*      */   int getIndentInPixels() {
/*  941 */     return this.indent;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getJustify()
/*      */   {
/*  956 */     checkLayout();
/*  957 */     return OS.pango_layout_get_justify(this.layout);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getLevel(int offset)
/*      */   {
/*  975 */     checkLayout();
/*  976 */     computeRuns();
/*  977 */     int length = this.text.length();
/*  978 */     if ((0 > offset) || (offset > length)) SWT.error(6);
/*  979 */     offset = translateOffset(offset);
/*  980 */     long iter = OS.pango_layout_get_iter(this.layout);
/*  981 */     if (iter == 0L) SWT.error(2);
/*  982 */     int level = 0;
/*  983 */     org.eclipse.swt.internal.gtk.PangoItem item = new org.eclipse.swt.internal.gtk.PangoItem();
/*  984 */     org.eclipse.swt.internal.gtk.PangoLayoutRun run = new org.eclipse.swt.internal.gtk.PangoLayoutRun();
/*  985 */     long ptr = OS.pango_layout_get_text(this.layout);
/*  986 */     long byteOffset = OS.g_utf16_offset_to_pointer(ptr, offset) - ptr;
/*  987 */     int strlen = org.eclipse.swt.internal.C.strlen(ptr);
/*  988 */     byteOffset = Math.min(byteOffset, strlen);
/*      */     do {
/*  990 */       long runPtr = OS.pango_layout_iter_get_run(iter);
/*  991 */       if (runPtr != 0L) {
/*  992 */         OS.memmove(run, runPtr, org.eclipse.swt.internal.gtk.PangoLayoutRun.sizeof);
/*  993 */         OS.memmove(item, run.item, org.eclipse.swt.internal.gtk.PangoItem.sizeof);
/*  994 */         if ((item.offset <= byteOffset) && (byteOffset < item.offset + item.length)) {
/*  995 */           level = item.analysis_level;
/*  996 */           break;
/*      */         }
/*      */       }
/*  999 */     } while (OS.pango_layout_iter_next_run(iter));
/* 1000 */     OS.pango_layout_iter_free(iter);
/* 1001 */     return level;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Rectangle getLineBounds(int lineIndex)
/*      */   {
/* 1018 */     checkLayout();
/* 1019 */     return DPIUtil.autoScaleDown(getDevice(), getLineBoundsInPixels(lineIndex));
/*      */   }
/*      */   
/*      */   Rectangle getLineBoundsInPixels(int lineIndex) {
/* 1023 */     computeRuns();
/* 1024 */     int lineCount = OS.pango_layout_get_line_count(this.layout);
/* 1025 */     if ((0 > lineIndex) || (lineIndex >= lineCount)) SWT.error(6);
/* 1026 */     long iter = OS.pango_layout_get_iter(this.layout);
/* 1027 */     if (iter == 0L) SWT.error(2);
/* 1028 */     for (int i = 0; i < lineIndex; i++) OS.pango_layout_iter_next_line(iter);
/* 1029 */     PangoRectangle rect = new PangoRectangle();
/* 1030 */     OS.pango_layout_iter_get_line_extents(iter, null, rect);
/* 1031 */     OS.pango_layout_iter_free(iter);
/* 1032 */     int x = OS.PANGO_PIXELS(rect.x);
/* 1033 */     int y = OS.PANGO_PIXELS(rect.y);
/* 1034 */     int width = OS.PANGO_PIXELS(rect.width);
/* 1035 */     int height = OS.PANGO_PIXELS(rect.height);
/* 1036 */     if ((this.ascentInPoints != -1) && (this.descentInPoints != -1)) {
/* 1037 */       height = Math.max(height, DPIUtil.autoScaleUp(getDevice(), this.ascentInPoints + this.descentInPoints));
/*      */     }
/* 1039 */     if (OS.pango_context_get_base_dir(this.context) == 1) {
/* 1040 */       x = width() - x - width;
/*      */     }
/* 1042 */     x += Math.min(this.indent, this.wrapIndent);
/* 1043 */     return new Rectangle(x, y, width, height);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getLineCount()
/*      */   {
/* 1057 */     checkLayout();
/* 1058 */     computeRuns();
/* 1059 */     return OS.pango_layout_get_line_count(this.layout);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getLineIndex(int offset)
/*      */   {
/* 1077 */     checkLayout();
/* 1078 */     computeRuns();
/* 1079 */     int length = this.text.length();
/* 1080 */     if ((0 > offset) || (offset > length)) SWT.error(5);
/* 1081 */     offset = translateOffset(offset);
/* 1082 */     int line = 0;
/* 1083 */     long ptr = OS.pango_layout_get_text(this.layout);
/* 1084 */     long byteOffset = OS.g_utf16_offset_to_pointer(ptr, offset) - ptr;
/* 1085 */     int strlen = org.eclipse.swt.internal.C.strlen(ptr);
/* 1086 */     byteOffset = Math.min(byteOffset, strlen);
/* 1087 */     long iter = OS.pango_layout_get_iter(this.layout);
/* 1088 */     if (iter == 0L) SWT.error(2);
/* 1089 */     while ((OS.pango_layout_iter_next_line(iter)) && 
/* 1090 */       (OS.pango_layout_iter_get_index(iter) <= byteOffset)) {
/* 1091 */       line++;
/*      */     }
/* 1093 */     OS.pango_layout_iter_free(iter);
/* 1094 */     return line;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public FontMetrics getLineMetrics(int lineIndex)
/*      */   {
/* 1111 */     checkLayout();
/* 1112 */     computeRuns();
/* 1113 */     int lineCount = OS.pango_layout_get_line_count(this.layout);
/* 1114 */     if ((0 > lineIndex) || (lineIndex >= lineCount)) SWT.error(6);
/* 1115 */     PangoLayoutLine line = new PangoLayoutLine();
/* 1116 */     OS.memmove(line, OS.pango_layout_get_line(this.layout, lineIndex), PangoLayoutLine.sizeof);
/*      */     
/*      */ 
/* 1119 */     if (line.runs == 0L) {
/* 1120 */       long font = this.font != null ? this.font.handle : this.device.systemFont.handle;
/* 1121 */       long lang = OS.pango_context_get_language(this.context);
/* 1122 */       long metrics = OS.pango_context_get_metrics(this.context, font, lang);
/* 1123 */       int ascent = OS.pango_font_metrics_get_ascent(metrics);
/* 1124 */       int descent = OS.pango_font_metrics_get_descent(metrics);
/* 1125 */       int ascentInPoints = DPIUtil.autoScaleDown(getDevice(), OS.PANGO_PIXELS(ascent));
/* 1126 */       int heightInPoints = DPIUtil.autoScaleDown(getDevice(), OS.PANGO_PIXELS(ascent + descent));
/* 1127 */       OS.pango_font_metrics_unref(metrics);
/*      */     } else {
/* 1129 */       PangoRectangle rect = new PangoRectangle();
/* 1130 */       OS.pango_layout_line_get_extents(OS.pango_layout_get_line(this.layout, lineIndex), null, rect);
/* 1131 */       ascentInPoints = DPIUtil.autoScaleDown(getDevice(), OS.PANGO_PIXELS(-rect.y));
/* 1132 */       heightInPoints = DPIUtil.autoScaleDown(getDevice(), OS.PANGO_PIXELS(rect.height));
/*      */     }
/* 1134 */     int heightInPoints = Math.max(this.ascentInPoints + this.descentInPoints, heightInPoints);
/* 1135 */     int ascentInPoints = Math.max(this.ascentInPoints, ascentInPoints);
/* 1136 */     int descentInPoints = heightInPoints - ascentInPoints;
/* 1137 */     return FontMetrics.gtk_new(ascentInPoints, descentInPoints, 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int[] getLineOffsets()
/*      */   {
/* 1152 */     checkLayout();
/* 1153 */     computeRuns();
/* 1154 */     int lineCount = OS.pango_layout_get_line_count(this.layout);
/* 1155 */     int[] offsets = new int[lineCount + 1];
/* 1156 */     long ptr = OS.pango_layout_get_text(this.layout);
/* 1157 */     PangoLayoutLine line = new PangoLayoutLine();
/* 1158 */     for (int i = 0; i < lineCount; i++) {
/* 1159 */       long linePtr = OS.pango_layout_get_line(this.layout, i);
/* 1160 */       OS.memmove(line, linePtr, PangoLayoutLine.sizeof);
/* 1161 */       int pos = (int)OS.g_utf16_pointer_to_offset(ptr, ptr + line.start_index);
/* 1162 */       offsets[i] = untranslateOffset(pos);
/*      */     }
/* 1164 */     offsets[lineCount] = this.text.length();
/* 1165 */     return offsets;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Point getLocation(int offset, boolean trailing)
/*      */   {
/* 1185 */     checkLayout();
/* 1186 */     return DPIUtil.autoScaleDown(getDevice(), getLocationInPixels(offset, trailing));
/*      */   }
/*      */   
/*      */   Point getLocationInPixels(int offset, boolean trailing) {
/* 1190 */     computeRuns();
/* 1191 */     int length = this.text.length();
/* 1192 */     if ((0 > offset) || (offset > length)) SWT.error(6);
/* 1193 */     offset = translateOffset(offset);
/* 1194 */     long ptr = OS.pango_layout_get_text(this.layout);
/* 1195 */     int byteOffset = (int)(OS.g_utf16_offset_to_pointer(ptr, offset) - ptr);
/* 1196 */     int strlen = org.eclipse.swt.internal.C.strlen(ptr);
/* 1197 */     byteOffset = Math.min(byteOffset, strlen);
/* 1198 */     PangoRectangle pos = new PangoRectangle();
/* 1199 */     OS.pango_layout_index_to_pos(this.layout, byteOffset, pos);
/* 1200 */     int x = trailing ? pos.x + pos.width : pos.x;
/* 1201 */     int y = pos.y;
/* 1202 */     x = OS.PANGO_PIXELS(x);
/* 1203 */     if (OS.pango_context_get_base_dir(this.context) == 1) {
/* 1204 */       x = width() - x;
/*      */     }
/* 1206 */     x += Math.min(this.indent, this.wrapIndent);
/* 1207 */     return new Point(x, OS.PANGO_PIXELS(y));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getNextOffset(int offset, int movement)
/*      */   {
/* 1230 */     return _getOffset(offset, movement, true);
/*      */   }
/*      */   
/*      */   int _getOffset(int offset, int movement, boolean forward) {
/* 1234 */     checkLayout();
/* 1235 */     computeRuns();
/* 1236 */     int length = this.text.length();
/* 1237 */     if ((0 > offset) || (offset > length)) SWT.error(6);
/* 1238 */     if (forward) {
/* 1239 */       if (offset == length) return length;
/*      */     }
/* 1241 */     else if (offset == 0) { return 0;
/*      */     }
/* 1243 */     int step = forward ? 1 : -1;
/* 1244 */     if ((movement & 0x1) != 0) return offset + step;
/* 1245 */     long[] attrs = new long[1];
/* 1246 */     int[] nAttrs = new int[1];
/* 1247 */     OS.pango_layout_get_log_attrs(this.layout, attrs, nAttrs);
/* 1248 */     if (attrs[0] == 0L) { return offset + step;
/*      */     }
/* 1250 */     long ptr = OS.pango_layout_get_text(this.layout);
/* 1251 */     int utf8Offset = (int)OS.g_utf16_offset_to_utf8_offset(ptr, translateOffset(offset));
/* 1252 */     int utf8Length = (int)OS.g_utf8_strlen(ptr, -1L);
/* 1253 */     utf8Offset += step;
/* 1254 */     PangoLogAttr logAttr = new PangoLogAttr();
/* 1255 */     while ((0 <= utf8Offset) && (utf8Offset <= utf8Length)) {
/* 1256 */       OS.memmove(logAttr, attrs[0] + utf8Offset * PangoLogAttr.sizeof, PangoLogAttr.sizeof);
/* 1257 */       boolean found = false;boolean limit = false;
/* 1258 */       if (((movement & 0x2) != 0) && (logAttr.is_cursor_position)) found = true;
/* 1259 */       if ((movement & 0x4) != 0) {
/* 1260 */         if (forward) {
/* 1261 */           if (logAttr.is_word_end) found = true;
/*      */         }
/* 1263 */         else if (logAttr.is_word_start) { found = true;
/*      */         }
/*      */       }
/* 1266 */       if ((movement & 0x10) != 0) {
/* 1267 */         if (logAttr.is_word_start) found = true;
/* 1268 */         if (logAttr.is_sentence_end) found = true;
/*      */       }
/* 1270 */       if ((movement & 0x8) != 0) {
/* 1271 */         if (logAttr.is_word_end) found = true;
/* 1272 */         if (logAttr.is_sentence_start) found = true;
/*      */       }
/* 1274 */       if (forward) {
/* 1275 */         if (utf8Offset == utf8Length) limit = true;
/*      */       }
/* 1277 */       else if (utf8Offset == 0) { limit = true;
/*      */       }
/* 1279 */       if ((found) || (limit)) {
/* 1280 */         int testOffset = (int)OS.g_utf8_offset_to_utf16_offset(ptr, utf8Offset);
/* 1281 */         if ((found) && (this.invalidOffsets != null)) {
/* 1282 */           for (int i = 0; i < this.invalidOffsets.length; i++) {
/* 1283 */             if (testOffset == this.invalidOffsets[i]) {
/* 1284 */               found = false;
/* 1285 */               break;
/*      */             }
/*      */           }
/*      */         }
/* 1289 */         if ((found) || (limit)) {
/* 1290 */           offset = untranslateOffset(testOffset);
/* 1291 */           break;
/*      */         }
/*      */       }
/* 1294 */       utf8Offset += step;
/*      */     }
/* 1296 */     OS.g_free(attrs[0]);
/* 1297 */     return Math.min(Math.max(0, offset), length);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getOffset(Point point, int[] trailing)
/*      */   {
/* 1324 */     checkLayout();
/* 1325 */     return getOffsetInPixels(DPIUtil.autoScaleUp(getDevice(), point), trailing);
/*      */   }
/*      */   
/*      */   int getOffsetInPixels(Point point, int[] trailing) {
/* 1329 */     if (point == null) SWT.error(4);
/* 1330 */     return getOffsetInPixels(point.x, point.y, trailing);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getOffset(int x, int y, int[] trailing)
/*      */   {
/* 1357 */     checkLayout();
/* 1358 */     return getOffset(new Point(x, y), trailing);
/*      */   }
/*      */   
/*      */   int getOffsetInPixels(int x, int y, int[] trailing) {
/* 1362 */     computeRuns();
/* 1363 */     if ((trailing != null) && (trailing.length < 1)) SWT.error(5);
/* 1364 */     x -= Math.min(this.indent, this.wrapIndent);
/* 1365 */     if (OS.pango_context_get_base_dir(this.context) == 1) {
/* 1366 */       x = width() - x;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1376 */     long iter = OS.pango_layout_get_iter(this.layout);
/* 1377 */     if (iter == 0L) SWT.error(2);
/* 1378 */     PangoRectangle rect = new PangoRectangle();
/*      */     do {
/* 1380 */       OS.pango_layout_iter_get_line_extents(iter, null, rect);
/* 1381 */       rect.y = OS.PANGO_PIXELS(rect.y);
/* 1382 */       rect.height = OS.PANGO_PIXELS(rect.height);
/* 1383 */       if ((rect.y <= y) && (y < rect.y + rect.height)) {
/* 1384 */         rect.x = OS.PANGO_PIXELS(rect.x);
/* 1385 */         rect.width = OS.PANGO_PIXELS(rect.width);
/* 1386 */         if (x >= rect.x + rect.width) x = rect.x + rect.width - 1;
/* 1387 */         if (x >= rect.x) break; x = rect.x; break;
/*      */       }
/*      */       
/* 1390 */     } while (OS.pango_layout_iter_next_line(iter));
/* 1391 */     OS.pango_layout_iter_free(iter);
/*      */     
/* 1393 */     int[] index = new int[1];
/* 1394 */     int[] piTrailing = new int[1];
/* 1395 */     OS.pango_layout_xy_to_index(this.layout, x * 1024, y * 1024, index, piTrailing);
/* 1396 */     long ptr = OS.pango_layout_get_text(this.layout);
/* 1397 */     int offset = (int)OS.g_utf16_pointer_to_offset(ptr, ptr + index[0]);
/* 1398 */     if (trailing != null) {
/* 1399 */       trailing[0] = piTrailing[0];
/* 1400 */       if (piTrailing[0] != 0) {
/* 1401 */         trailing[0] = ((int)OS.g_utf8_offset_to_utf16_offset(ptr, OS.g_utf8_pointer_to_offset(ptr, ptr + index[0]) + piTrailing[0]) - offset);
/*      */       }
/*      */     }
/* 1404 */     return untranslateOffset(offset);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getOrientation()
/*      */   {
/* 1417 */     checkLayout();
/* 1418 */     int baseDir = OS.pango_context_get_base_dir(this.context);
/* 1419 */     return baseDir == 1 ? 67108864 : 33554432;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getPreviousOffset(int offset, int movement)
/*      */   {
/* 1442 */     return _getOffset(offset, movement, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int[] getRanges()
/*      */   {
/* 1460 */     checkLayout();
/* 1461 */     int[] result = new int[this.stylesCount * 2];
/* 1462 */     int count = 0;
/* 1463 */     for (int i = 0; i < this.stylesCount - 1; i++) {
/* 1464 */       if (this.styles[i].style != null) {
/* 1465 */         result[(count++)] = this.styles[i].start;
/* 1466 */         result[(count++)] = (this.styles[(i + 1)].start - 1);
/*      */       }
/*      */     }
/* 1469 */     if (count != result.length) {
/* 1470 */       int[] newResult = new int[count];
/* 1471 */       System.arraycopy(result, 0, newResult, 0, count);
/* 1472 */       result = newResult;
/*      */     }
/* 1474 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int[] getSegments()
/*      */   {
/* 1487 */     checkLayout();
/* 1488 */     return this.segments;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public char[] getSegmentsChars()
/*      */   {
/* 1503 */     checkLayout();
/* 1504 */     return this.segmentsChars;
/*      */   }
/*      */   
/*      */   String getSegmentsText() {
/* 1508 */     int length = this.text.length();
/* 1509 */     if (length == 0) return this.text;
/* 1510 */     if (this.segments == null) return this.text;
/* 1511 */     int nSegments = this.segments.length;
/* 1512 */     if (nSegments == 0) return this.text;
/* 1513 */     if (this.segmentsChars == null) {
/* 1514 */       if (nSegments == 1) return this.text;
/* 1515 */       if ((nSegments == 2) && 
/* 1516 */         (this.segments[0] == 0) && (this.segments[1] == length)) { return this.text;
/*      */       }
/*      */     }
/* 1519 */     char[] oldChars = new char[length];
/* 1520 */     this.text.getChars(0, length, oldChars, 0);
/* 1521 */     char[] newChars = new char[length + nSegments];
/* 1522 */     int charCount = 0;int segmentCount = 0;
/* 1523 */     char defaultSeparator = getOrientation() == 67108864 ? '‏' : '‎';
/* 1524 */     while (charCount < length) {
/* 1525 */       if ((segmentCount < nSegments) && (charCount == this.segments[segmentCount])) {
/* 1526 */         char separator = (this.segmentsChars != null) && (this.segmentsChars.length > segmentCount) ? this.segmentsChars[segmentCount] : defaultSeparator;
/* 1527 */         newChars[(charCount + segmentCount++)] = separator;
/*      */       } else {
/* 1529 */         newChars[(charCount + segmentCount)] = oldChars[(charCount++)];
/*      */       }
/*      */     }
/* 1532 */     while (segmentCount < nSegments) {
/* 1533 */       this.segments[segmentCount] = charCount;
/* 1534 */       char separator = (this.segmentsChars != null) && (this.segmentsChars.length > segmentCount) ? this.segmentsChars[segmentCount] : defaultSeparator;
/* 1535 */       newChars[(charCount + segmentCount++)] = separator;
/*      */     }
/* 1537 */     return new String(newChars, 0, newChars.length);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getSpacing()
/*      */   {
/* 1550 */     checkLayout();
/* 1551 */     return DPIUtil.autoScaleDown(getDevice(), getSpacingInPixels());
/*      */   }
/*      */   
/*      */   int getSpacingInPixels() {
/* 1555 */     return OS.PANGO_PIXELS(OS.pango_layout_get_spacing(this.layout));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public TextStyle getStyle(int offset)
/*      */   {
/* 1572 */     checkLayout();
/* 1573 */     int length = this.text.length();
/* 1574 */     if ((0 > offset) || (offset >= length)) SWT.error(6);
/* 1575 */     for (int i = 1; i < this.stylesCount; i++) {
/* 1576 */       StyleItem item = this.styles[i];
/* 1577 */       if (item.start > offset) {
/* 1578 */         return this.styles[(i - 1)].style;
/*      */       }
/*      */     }
/* 1581 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public TextStyle[] getStyles()
/*      */   {
/* 1598 */     checkLayout();
/* 1599 */     TextStyle[] result = new TextStyle[this.stylesCount];
/* 1600 */     int count = 0;
/* 1601 */     for (int i = 0; i < this.stylesCount; i++) {
/* 1602 */       if (this.styles[i].style != null) {
/* 1603 */         result[(count++)] = this.styles[i].style;
/*      */       }
/*      */     }
/* 1606 */     if (count != result.length) {
/* 1607 */       TextStyle[] newResult = new TextStyle[count];
/* 1608 */       System.arraycopy(result, 0, newResult, 0, count);
/* 1609 */       result = newResult;
/*      */     }
/* 1611 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int[] getTabs()
/*      */   {
/* 1624 */     checkLayout();
/* 1625 */     return DPIUtil.autoScaleDown(getDevice(), getTabsInPixels());
/*      */   }
/*      */   
/*      */   int[] getTabsInPixels() {
/* 1629 */     return this.tabs;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getText()
/*      */   {
/* 1643 */     checkLayout();
/* 1644 */     return this.text;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getTextDirection()
/*      */   {
/* 1658 */     return getOrientation();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getWidth()
/*      */   {
/* 1671 */     checkLayout();
/* 1672 */     return DPIUtil.autoScaleDown(getDevice(), getWidthInPixels());
/*      */   }
/*      */   
/*      */   int getWidthInPixels() {
/* 1676 */     return this.wrapWidth;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getWrapIndent()
/*      */   {
/* 1691 */     checkLayout();
/* 1692 */     return DPIUtil.autoScaleDown(getDevice(), getWrapIndentInPixels());
/*      */   }
/*      */   
/* 1695 */   int getWrapIndentInPixels() { return this.wrapIndent; }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isDisposed()
/*      */   {
/* 1711 */     return this.layout == 0L;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAlignment(int alignment)
/*      */   {
/* 1733 */     checkLayout();
/* 1734 */     int mask = 16924672;
/* 1735 */     alignment &= mask;
/* 1736 */     if (alignment == 0) return;
/* 1737 */     if ((alignment & 0x4000) != 0) alignment = 16384;
/* 1738 */     if ((alignment & 0x20000) != 0) alignment = 131072;
/* 1739 */     boolean rtl = OS.pango_context_get_base_dir(this.context) == 1;
/* 1740 */     int align = 1;
/* 1741 */     switch (alignment) {
/*      */     case 16384: 
/* 1743 */       align = rtl ? 2 : 0;
/* 1744 */       break;
/*      */     case 131072: 
/* 1746 */       align = rtl ? 0 : 2;
/*      */     }
/*      */     
/* 1749 */     OS.pango_layout_set_alignment(this.layout, align);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAscent(int ascent)
/*      */   {
/* 1771 */     checkLayout();
/* 1772 */     if (ascent < -1) SWT.error(5);
/* 1773 */     if (this.ascentInPoints == ascent) return;
/* 1774 */     freeRuns();
/* 1775 */     this.ascentInPoints = ascent;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDescent(int descent)
/*      */   {
/* 1797 */     checkLayout();
/* 1798 */     if (descent < -1) SWT.error(5);
/* 1799 */     if (this.descentInPoints == descent) return;
/* 1800 */     freeRuns();
/* 1801 */     this.descentInPoints = descent;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setFont(Font font)
/*      */   {
/* 1821 */     checkLayout();
/* 1822 */     if ((font != null) && (font.isDisposed())) SWT.error(5);
/* 1823 */     Font oldFont = this.font;
/* 1824 */     if (oldFont == font) return;
/* 1825 */     freeRuns();
/* 1826 */     this.font = font;
/* 1827 */     if ((oldFont != null) && (oldFont.equals(font))) return;
/* 1828 */     OS.pango_layout_set_font_description(this.layout, font != null ? font.handle : this.device.systemFont.handle);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setIndent(int indent)
/*      */   {
/* 1846 */     checkLayout();
/* 1847 */     setIndentInPixels(DPIUtil.autoScaleUp(getDevice(), indent));
/*      */   }
/*      */   
/*      */   void setIndentInPixels(int indent) {
/* 1851 */     checkLayout();
/* 1852 */     if (indent < 0) return;
/* 1853 */     if (this.indent == indent) return;
/* 1854 */     this.indent = indent;
/* 1855 */     OS.pango_layout_set_indent(this.layout, (indent - this.wrapIndent) * 1024);
/* 1856 */     if (this.wrapWidth != -1) { setWidth();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setJustify(boolean justify)
/*      */   {
/* 1872 */     checkLayout();
/* 1873 */     OS.pango_layout_set_justify(this.layout, justify);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setOrientation(int orientation)
/*      */   {
/* 1887 */     checkLayout();
/* 1888 */     int mask = 100663296;
/* 1889 */     orientation &= mask;
/* 1890 */     if (orientation == 0) return;
/* 1891 */     if ((orientation & 0x2000000) != 0) orientation = 33554432;
/* 1892 */     int baseDir = orientation == 67108864 ? 1 : 0;
/* 1893 */     if (OS.pango_context_get_base_dir(this.context) == baseDir) return;
/* 1894 */     freeRuns();
/* 1895 */     OS.pango_context_set_base_dir(this.context, baseDir);
/* 1896 */     OS.pango_layout_context_changed(this.layout);
/* 1897 */     int align = OS.pango_layout_get_alignment(this.layout);
/* 1898 */     if (align != 1) {
/* 1899 */       align = align == 0 ? 2 : 0;
/* 1900 */       OS.pango_layout_set_alignment(this.layout, align);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSpacing(int spacing)
/*      */   {
/* 1918 */     checkLayout();
/* 1919 */     if (spacing < 0) SWT.error(5);
/* 1920 */     setSpacingInPixels(DPIUtil.autoScaleUp(getDevice(), spacing));
/*      */   }
/*      */   
/*      */   void setSpacingInPixels(int spacing) {
/* 1924 */     OS.pango_layout_set_spacing(this.layout, spacing * 1024);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSegments(int[] segments)
/*      */   {
/* 1952 */     checkLayout();
/* 1953 */     if ((this.segments == null) && (segments == null)) return;
/* 1954 */     if ((this.segments != null) && (segments != null) && 
/* 1955 */       (this.segments.length == segments.length))
/*      */     {
/* 1957 */       for (int i = 0; i < segments.length; i++)
/* 1958 */         if (this.segments[i] != segments[i])
/*      */           break;
/* 1960 */       if (i == segments.length) { return;
/*      */       }
/*      */     }
/* 1963 */     freeRuns();
/* 1964 */     this.segments = segments;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSegmentsChars(char[] segmentsChars)
/*      */   {
/* 1985 */     checkLayout();
/* 1986 */     if ((this.segmentsChars == null) && (segmentsChars == null)) return;
/* 1987 */     if ((this.segmentsChars != null) && (segmentsChars != null) && 
/* 1988 */       (this.segmentsChars.length == segmentsChars.length))
/*      */     {
/* 1990 */       for (int i = 0; i < segmentsChars.length; i++)
/* 1991 */         if (this.segmentsChars[i] != segmentsChars[i])
/*      */           break;
/* 1993 */       if (i == segmentsChars.length) { return;
/*      */       }
/*      */     }
/* 1996 */     freeRuns();
/* 1997 */     this.segmentsChars = segmentsChars;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setStyle(TextStyle style, int start, int end)
/*      */   {
/* 2014 */     checkLayout();
/* 2015 */     int length = this.text.length();
/* 2016 */     if (length == 0) return;
/* 2017 */     if (start > end) return;
/* 2018 */     start = Math.min(Math.max(0, start), length - 1);
/* 2019 */     end = Math.min(Math.max(0, end), length - 1);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2028 */     if ((start > 0) && (isAlef(this.text.charAt(start))) && (isLam(this.text.charAt(start - 1)))) {
/* 2029 */       start--;
/*      */     }
/* 2031 */     if ((end < length - 1) && (isLam(this.text.charAt(end))) && (isAlef(this.text.charAt(end + 1)))) {
/* 2032 */       end++;
/*      */     }
/*      */     
/* 2035 */     int low = -1;
/* 2036 */     int high = this.stylesCount;
/* 2037 */     while (high - low > 1) {
/* 2038 */       int index = (high + low) / 2;
/* 2039 */       if (this.styles[(index + 1)].start > start) {
/* 2040 */         high = index;
/*      */       } else {
/* 2042 */         low = index;
/*      */       }
/*      */     }
/* 2045 */     if ((0 <= high) && (high < this.stylesCount)) {
/* 2046 */       StyleItem item = this.styles[high];
/* 2047 */       if ((item.start == start) && (this.styles[(high + 1)].start - 1 == end)) {
/* 2048 */         if (style == null) {
/* 2049 */           if (item.style != null) {}
/*      */         }
/* 2051 */         else if (style.equals(item.style)) { return;
/*      */         }
/*      */       }
/*      */     }
/* 2055 */     freeRuns();
/* 2056 */     int modifyStart = high;
/* 2057 */     int modifyEnd = modifyStart;
/* 2058 */     while ((modifyEnd < this.stylesCount) && 
/* 2059 */       (this.styles[(modifyEnd + 1)].start <= end)) {
/* 2060 */       modifyEnd++;
/*      */     }
/* 2062 */     if (modifyStart == modifyEnd) {
/* 2063 */       int styleStart = this.styles[modifyStart].start;
/* 2064 */       int styleEnd = this.styles[(modifyEnd + 1)].start - 1;
/* 2065 */       if ((styleStart == start) && (styleEnd == end)) {
/* 2066 */         this.styles[modifyStart].style = style;
/* 2067 */         return;
/*      */       }
/* 2069 */       if ((styleStart != start) && (styleEnd != end)) {
/* 2070 */         int newLength = this.stylesCount + 2;
/* 2071 */         if (newLength > this.styles.length) {
/* 2072 */           int newSize = Math.min(newLength + 1024, Math.max(64, newLength * 2));
/* 2073 */           StyleItem[] newStyles = new StyleItem[newSize];
/* 2074 */           System.arraycopy(this.styles, 0, newStyles, 0, this.stylesCount);
/* 2075 */           this.styles = newStyles;
/*      */         }
/* 2077 */         System.arraycopy(this.styles, modifyEnd + 1, this.styles, modifyEnd + 3, this.stylesCount - modifyEnd - 1);
/* 2078 */         StyleItem item = new StyleItem();
/* 2079 */         item.start = start;
/* 2080 */         item.style = style;
/* 2081 */         this.styles[(modifyStart + 1)] = item;
/* 2082 */         item = new StyleItem();
/* 2083 */         item.start = (end + 1);
/* 2084 */         item.style = this.styles[modifyStart].style;
/* 2085 */         this.styles[(modifyStart + 2)] = item;
/* 2086 */         this.stylesCount = newLength;
/* 2087 */         return;
/*      */       }
/*      */     }
/* 2090 */     if (start == this.styles[modifyStart].start) modifyStart--;
/* 2091 */     if (end == this.styles[(modifyEnd + 1)].start - 1) modifyEnd++;
/* 2092 */     int newLength = this.stylesCount + 1 - (modifyEnd - modifyStart - 1);
/* 2093 */     if (newLength > this.styles.length) {
/* 2094 */       int newSize = Math.min(newLength + 1024, Math.max(64, newLength * 2));
/* 2095 */       StyleItem[] newStyles = new StyleItem[newSize];
/* 2096 */       System.arraycopy(this.styles, 0, newStyles, 0, this.stylesCount);
/* 2097 */       this.styles = newStyles;
/*      */     }
/* 2099 */     System.arraycopy(this.styles, modifyEnd, this.styles, modifyStart + 2, this.stylesCount - modifyEnd);
/* 2100 */     StyleItem item = new StyleItem();
/* 2101 */     item.start = start;
/* 2102 */     item.style = style;
/* 2103 */     this.styles[(modifyStart + 1)] = item;
/* 2104 */     this.styles[(modifyStart + 2)].start = (end + 1);
/* 2105 */     this.stylesCount = newLength;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTabs(int[] tabs)
/*      */   {
/* 2120 */     checkLayout();
/* 2121 */     if ((this.tabs == null) && (tabs == null)) return;
/* 2122 */     setTabsInPixels(DPIUtil.autoScaleUp(getDevice(), tabs));
/*      */   }
/*      */   
/*      */   void setTabsInPixels(int[] tabs) {
/* 2126 */     if (java.util.Arrays.equals(this.tabs, tabs)) return;
/* 2127 */     this.tabs = tabs;
/* 2128 */     if (tabs == null) {
/* 2129 */       OS.pango_layout_set_tabs(this.layout, this.device.emptyTab);
/*      */     } else {
/* 2131 */       long tabArray = OS.pango_tab_array_new(tabs.length, true);
/* 2132 */       if (tabArray != 0L) {
/* 2133 */         for (int i = 0; i < tabs.length; i++) {
/* 2134 */           OS.pango_tab_array_set_tab(tabArray, i, 0L, tabs[i]);
/*      */         }
/* 2136 */         OS.pango_layout_set_tabs(this.layout, tabArray);
/* 2137 */         OS.pango_tab_array_free(tabArray);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2145 */     OS.pango_layout_context_changed(this.layout);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setText(String text)
/*      */   {
/* 2166 */     checkLayout();
/* 2167 */     if (text == null) SWT.error(4);
/* 2168 */     if (text.equals(this.text)) return;
/* 2169 */     freeRuns();
/* 2170 */     this.text = text;
/* 2171 */     this.styles = new StyleItem[2];
/* 2172 */     this.styles[0] = new StyleItem();
/* 2173 */     this.styles[1] = new StyleItem();
/* 2174 */     this.styles[1].start = text.length();
/* 2175 */     this.stylesCount = 2;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTextDirection(int textDirection)
/*      */   {
/* 2196 */     checkLayout();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setWidth(int width)
/*      */   {
/* 2216 */     checkLayout();
/* 2217 */     if ((width < -1) || (width == 0)) SWT.error(5);
/* 2218 */     setWidthInPixels(DPIUtil.autoScaleUp(getDevice(), width));
/*      */   }
/*      */   
/*      */   void setWidthInPixels(int width) {
/* 2222 */     if (this.wrapWidth == width) return;
/* 2223 */     freeRuns();
/* 2224 */     this.wrapWidth = width;
/* 2225 */     setWidth();
/*      */   }
/*      */   
/*      */   void setWidth() {
/* 2229 */     if (this.wrapWidth == -1) {
/* 2230 */       OS.pango_layout_set_width(this.layout, -1);
/* 2231 */       boolean rtl = OS.pango_context_get_base_dir(this.context) == 1;
/* 2232 */       OS.pango_layout_set_alignment(this.layout, rtl ? 2 : 0);
/*      */     } else {
/* 2234 */       int margin = Math.min(this.indent, this.wrapIndent);
/* 2235 */       OS.pango_layout_set_width(this.layout, (this.wrapWidth - margin) * 1024);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setWrapIndent(int wrapIndent)
/*      */   {
/* 2254 */     checkLayout();
/* 2255 */     if (wrapIndent < 0) return;
/* 2256 */     setWrapIndentInPixels(DPIUtil.autoScaleUp(getDevice(), wrapIndent));
/*      */   }
/*      */   
/*      */   void setWrapIndentInPixels(int wrapIndent) {
/* 2260 */     if (this.wrapIndent == wrapIndent) return;
/* 2261 */     this.wrapIndent = wrapIndent;
/* 2262 */     OS.pango_layout_set_indent(this.layout, (this.indent - wrapIndent) * 1024);
/* 2263 */     if (this.wrapWidth != -1) setWidth();
/*      */   }
/*      */   
/*      */   static final boolean isLam(int ch) {
/* 2267 */     return ch == 1604;
/*      */   }
/*      */   
/*      */   static final boolean isAlef(int ch) {
/* 2271 */     switch (ch) {
/*      */     case 1570: 
/*      */     case 1571: 
/*      */     case 1573: 
/*      */     case 1575: 
/*      */     case 1609: 
/*      */     case 1648: 
/*      */     case 1649: 
/*      */     case 1650: 
/*      */     case 1651: 
/*      */     case 1653: 
/* 2282 */       return true;
/*      */     }
/* 2284 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String toString()
/*      */   {
/* 2295 */     if (isDisposed()) return "TextLayout {*DISPOSED*}";
/* 2296 */     return "TextLayout {" + this.layout + "}";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   int translateOffset(int offset)
/*      */   {
/* 2303 */     int length = this.text.length();
/* 2304 */     if (length == 0) return offset;
/* 2305 */     if (this.invalidOffsets == null) return offset;
/* 2306 */     for (int i = 0; i < this.invalidOffsets.length; i++) {
/* 2307 */       if (offset < this.invalidOffsets[i]) break;
/* 2308 */       offset++;
/*      */     }
/* 2310 */     return offset;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   int untranslateOffset(int offset)
/*      */   {
/* 2317 */     int length = this.text.length();
/* 2318 */     if (length == 0) return offset;
/* 2319 */     if (this.invalidOffsets == null) return offset;
/* 2320 */     int i = 0;
/* 2321 */     while ((i < this.invalidOffsets.length) && (offset > this.invalidOffsets[i])) {
/* 2322 */       i++;
/*      */     }
/* 2324 */     return offset - i;
/*      */   }
/*      */   
/*      */   int width() {
/* 2328 */     int wrapWidth = OS.pango_layout_get_width(this.layout);
/* 2329 */     if (wrapWidth != -1) return OS.PANGO_PIXELS(wrapWidth);
/* 2330 */     int[] w = new int[1];int[] h = new int[1];
/* 2331 */     OS.pango_layout_get_pixel_size(this.layout, w, h);
/* 2332 */     return w[0];
/*      */   }
/*      */   
/*      */   public void setDefaultTabWidth(int tabLength) {}
/*      */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/graphics/TextLayout.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */