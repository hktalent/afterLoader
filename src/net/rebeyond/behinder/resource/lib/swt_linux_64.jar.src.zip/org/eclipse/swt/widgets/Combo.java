/*      */ package org.eclipse.swt.widgets;
/*      */ 
/*      */ import org.eclipse.swt.events.ModifyListener;
/*      */ import org.eclipse.swt.events.SegmentListener;
/*      */ import org.eclipse.swt.events.SelectionListener;
/*      */ import org.eclipse.swt.events.VerifyListener;
/*      */ import org.eclipse.swt.graphics.Color;
/*      */ import org.eclipse.swt.graphics.Font;
/*      */ import org.eclipse.swt.graphics.Point;
/*      */ import org.eclipse.swt.internal.C;
/*      */ import org.eclipse.swt.internal.Converter;
/*      */ import org.eclipse.swt.internal.DPIUtil;
/*      */ import org.eclipse.swt.internal.gtk.GDK;
/*      */ import org.eclipse.swt.internal.gtk.GTK;
/*      */ import org.eclipse.swt.internal.gtk.GdkColor;
/*      */ import org.eclipse.swt.internal.gtk.GdkEvent;
/*      */ import org.eclipse.swt.internal.gtk.GdkEventButton;
/*      */ import org.eclipse.swt.internal.gtk.GdkEventFocus;
/*      */ import org.eclipse.swt.internal.gtk.GdkEventKey;
/*      */ import org.eclipse.swt.internal.gtk.GdkRGBA;
/*      */ import org.eclipse.swt.internal.gtk.GtkRequisition;
/*      */ import org.eclipse.swt.internal.gtk.OS;
/*      */ import org.eclipse.swt.internal.gtk.PangoRectangle;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class Combo
/*      */   extends Composite
/*      */ {
/*      */   long buttonHandle;
/*      */   long entryHandle;
/*      */   long textRenderer;
/*      */   long cellHandle;
/*      */   long popupHandle;
/*      */   long menuHandle;
/*      */   long buttonBoxHandle;
/*      */   long cellBoxHandle;
/*      */   int lastEventTime;
/*   62 */   int visibleCount = 10;
/*      */   long imContext;
/*   64 */   long gdkEventKey = 0L;
/*   65 */   int fixStart = -1; int fixEnd = -1;
/*   66 */   String[] items = new String[0];
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   int indexSelected;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   GdkRGBA background;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*   81 */   public static final int LIMIT = 65535;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Combo(Composite parent, int style)
/*      */   {
/*  115 */     super(parent, checkStyle(style));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void add(String string)
/*      */   {
/*  137 */     checkWidget();
/*  138 */     if (string == null) error(4);
/*  139 */     add(string, this.items.length);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void add(String string, int index)
/*      */   {
/*  169 */     checkWidget();
/*  170 */     if (string == null) error(4);
/*  171 */     if ((0 > index) || (index > this.items.length)) {
/*  172 */       error(6);
/*      */     }
/*  174 */     String[] newItems = new String[this.items.length + 1];
/*  175 */     System.arraycopy(this.items, 0, newItems, 0, index);
/*  176 */     newItems[index] = string;
/*  177 */     System.arraycopy(this.items, index, newItems, index + 1, this.items.length - index);
/*  178 */     this.items = newItems;
/*  179 */     byte[] buffer = Converter.wcsToMbcs(string, true);
/*  180 */     if (GTK.GTK3) {
/*  181 */       if (this.handle != 0L) GTK.gtk_combo_box_text_insert(this.handle, index, null, buffer);
/*      */     }
/*  183 */     else if (this.handle != 0L) { GTK.gtk_combo_box_text_insert_text(this.handle, index, buffer);
/*      */     }
/*  185 */     if (((this.style & 0x4000000) != 0) && (this.popupHandle != 0L)) {
/*  186 */       GTK.gtk_container_forall(this.popupHandle, this.display.setDirectionProc, 2L);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addModifyListener(ModifyListener listener)
/*      */   {
/*  210 */     checkWidget();
/*  211 */     if (listener == null) error(4);
/*  212 */     TypedListener typedListener = new TypedListener(listener);
/*  213 */     addListener(24, typedListener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addSegmentListener(SegmentListener listener)
/*      */   {
/*  251 */     checkWidget();
/*  252 */     if (listener == null) error(4);
/*  253 */     addListener(49, new TypedListener(listener));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addSelectionListener(SelectionListener listener)
/*      */   {
/*  281 */     checkWidget();
/*  282 */     if (listener == null) error(4);
/*  283 */     TypedListener typedListener = new TypedListener(listener);
/*  284 */     addListener(13, typedListener);
/*  285 */     addListener(14, typedListener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addVerifyListener(VerifyListener listener)
/*      */   {
/*  310 */     checkWidget();
/*  311 */     if (listener == null) error(4);
/*  312 */     TypedListener typedListener = new TypedListener(listener);
/*  313 */     addListener(25, typedListener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static int checkStyle(int style)
/*      */   {
/*  329 */     style &= 0xF7FF;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  338 */     style &= 0xFCFF;
/*  339 */     style = checkBits(style, 4, 64, 0, 0, 0, 0);
/*  340 */     if ((style & 0x40) != 0) return style & 0xFFFFFFF7;
/*  341 */     return style;
/*      */   }
/*      */   
/*      */   protected void checkSubclass()
/*      */   {
/*  346 */     if (!isValidSubclass()) { error(43);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void clearSelection()
/*      */   {
/*  367 */     checkWidget();
/*  368 */     if (this.entryHandle != 0L) {
/*  369 */       int position = GTK.gtk_editable_get_position(this.entryHandle);
/*  370 */       GTK.gtk_editable_select_region(this.entryHandle, position, position);
/*      */     }
/*      */   }
/*      */   
/*      */   void clearText() {
/*  375 */     OS.g_signal_handlers_block_matched(this.handle, 16, 0, 0, 0L, 0L, 6L);
/*  376 */     if ((this.style & 0x8) != 0) {
/*  377 */       int index = GTK.gtk_combo_box_get_active(this.handle);
/*  378 */       if (index != -1) {
/*  379 */         long modelHandle = GTK.gtk_combo_box_get_model(this.handle);
/*  380 */         long[] ptr = new long[1];
/*  381 */         long iter = OS.g_malloc(GTK.GtkTreeIter_sizeof());
/*  382 */         GTK.gtk_tree_model_iter_nth_child(modelHandle, iter, 0L, index);
/*  383 */         GTK.gtk_tree_model_get(modelHandle, iter, 0, ptr, -1);
/*  384 */         OS.g_free(iter);
/*  385 */         if ((ptr[0] != 0L) && (C.strlen(ptr[0]) > 0)) postEvent(24);
/*  386 */         OS.g_free(ptr[0]);
/*      */       }
/*      */     } else {
/*  389 */       GTK.gtk_entry_set_text(this.entryHandle, new byte[1]);
/*      */     }
/*  391 */     GTK.gtk_combo_box_set_active(this.handle, -1);
/*  392 */     OS.g_signal_handlers_unblock_matched(this.handle, 16, 0, 0, 0L, 0L, 6L);
/*      */   }
/*      */   
/*      */   Point computeSizeInPixels(int wHint, int hHint, boolean changed)
/*      */   {
/*  397 */     checkWidget();
/*  398 */     if (((this.style & 0x8) != 0) || (GTK.GTK3)) {
/*  399 */       return computeNativeSize(this.handle, wHint, hHint, changed);
/*      */     }
/*  401 */     if ((wHint != -1) && (wHint < 0)) wHint = 0;
/*  402 */     if ((hHint != -1) && (hHint < 0)) hHint = 0;
/*  403 */     int[] w = new int[1];int[] h = new int[1];
/*  404 */     GTK.gtk_widget_realize(this.entryHandle);
/*  405 */     long layout = GTK.gtk_entry_get_layout(this.entryHandle);
/*  406 */     OS.pango_layout_get_pixel_size(layout, w, h);
/*  407 */     int xborder = 2;int yborder = 2;
/*  408 */     Point thickness = getThickness(this.entryHandle);
/*  409 */     xborder += thickness.x;
/*  410 */     yborder += thickness.y;
/*  411 */     int[] property = new int[1];
/*  412 */     GTK.gtk_widget_style_get(this.entryHandle, OS.interior_focus, property, 0L);
/*  413 */     if (property[0] == 0) {
/*  414 */       GTK.gtk_widget_style_get(this.entryHandle, OS.focus_line_width, property, 0L);
/*  415 */       xborder += property[0];
/*  416 */       yborder += property[0];
/*      */     }
/*  418 */     int width = w[0] + xborder * 2;
/*  419 */     int height = h[0] + yborder * 2;
/*  420 */     GtkRequisition arrowRequesition = new GtkRequisition();
/*  421 */     gtk_widget_get_preferred_size(this.buttonHandle, arrowRequesition);
/*  422 */     GtkRequisition listRequesition = new GtkRequisition();
/*  423 */     long listParent = GTK.gtk_bin_get_child(this.popupHandle);
/*  424 */     gtk_widget_get_preferred_size(listParent, listRequesition);
/*  425 */     width = Math.max(listRequesition.width, width) + arrowRequesition.width;
/*  426 */     width = wHint == -1 ? width : wHint;
/*  427 */     height = hHint == -1 ? height : hHint;
/*  428 */     return new Point(width, height);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void copy()
/*      */   {
/*  445 */     checkWidget();
/*  446 */     if (this.entryHandle != 0L) GTK.gtk_editable_copy_clipboard(this.entryHandle);
/*      */   }
/*      */   
/*      */   void createHandle(int index)
/*      */   {
/*  451 */     this.state |= 0x28;
/*  452 */     this.fixedHandle = OS.g_object_new(this.display.gtk_fixed_get_type(), 0L);
/*  453 */     if (this.fixedHandle == 0L) error(2);
/*  454 */     GTK.gtk_widget_set_has_window(this.fixedHandle, true);
/*  455 */     long oldList = GTK.gtk_window_list_toplevels();
/*  456 */     if ((this.style & 0x8) != 0) {
/*  457 */       this.handle = GTK.gtk_combo_box_text_new();
/*  458 */       if (this.handle == 0L) error(2);
/*  459 */       this.cellHandle = GTK.gtk_bin_get_child(this.handle);
/*  460 */       if (this.cellHandle == 0L) { error(2);
/*      */       }
/*  462 */       GTK.gtk_combo_box_set_wrap_width(this.handle, 1);
/*      */     } else {
/*  464 */       this.handle = GTK.gtk_combo_box_text_new_with_entry();
/*  465 */       if (this.handle == 0L) error(2);
/*  466 */       this.entryHandle = GTK.gtk_bin_get_child(this.handle);
/*  467 */       if (this.entryHandle == 0L) error(2);
/*  468 */       if (GTK.GTK3) {
/*  469 */         this.imContext = OS.imContextLast();
/*      */       }
/*      */     }
/*  472 */     this.popupHandle = findPopupHandle(oldList);
/*  473 */     GTK.gtk_container_add(this.fixedHandle, this.handle);
/*  474 */     this.textRenderer = GTK.gtk_cell_renderer_text_new();
/*  475 */     if (this.textRenderer == 0L) { error(2);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  482 */     int pad = 0;
/*  483 */     OS.g_object_set(this.textRenderer, OS.ypad, pad, 0L);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  489 */     boolean warnings = this.display.getWarnings();
/*  490 */     this.display.setWarnings(false);
/*  491 */     GTK.gtk_cell_layout_clear(this.handle);
/*  492 */     this.display.setWarnings(warnings);
/*  493 */     GTK.gtk_cell_layout_pack_start(this.handle, this.textRenderer, true);
/*  494 */     GTK.gtk_cell_layout_set_attributes(this.handle, this.textRenderer, OS.text, 0, 0L);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  500 */     this.menuHandle = findMenuHandle();
/*  501 */     if (this.menuHandle != 0L) OS.g_object_ref(this.menuHandle);
/*  502 */     this.buttonHandle = findButtonHandle();
/*  503 */     if (this.buttonHandle != 0L) OS.g_object_ref(this.buttonHandle);
/*  504 */     if (this.buttonBoxHandle != 0L) OS.g_object_ref(this.buttonBoxHandle);
/*  505 */     if (this.cellHandle != 0L) this.cellBoxHandle = GTK.gtk_widget_get_parent(this.cellHandle);
/*  506 */     if (this.cellBoxHandle != 0L) { OS.g_object_ref(this.cellBoxHandle);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  513 */     if (((this.style & 0x8) != 0) && (this.buttonHandle != 0L)) {
/*  514 */       GTK.gtk_widget_set_receives_default(this.buttonHandle, false);
/*      */     }
/*      */     
/*      */ 
/*  518 */     if (GTK.GTK3) {
/*  519 */       setFontDescription(defaultFont().handle);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void cut()
/*      */   {
/*  538 */     checkWidget();
/*  539 */     if (this.entryHandle != 0L) GTK.gtk_editable_cut_clipboard(this.entryHandle);
/*      */   }
/*      */   
/*      */   GdkRGBA defaultBackground()
/*      */   {
/*  544 */     return this.display.getSystemColor(25).handleRGBA;
/*      */   }
/*      */   
/*      */   void deregister()
/*      */   {
/*  549 */     super.deregister();
/*  550 */     if (this.buttonHandle != 0L) this.display.removeWidget(this.buttonHandle);
/*  551 */     if (this.entryHandle != 0L) this.display.removeWidget(this.entryHandle);
/*  552 */     if (this.popupHandle != 0L) this.display.removeWidget(this.popupHandle);
/*  553 */     if (this.menuHandle != 0L) this.display.removeWidget(this.menuHandle);
/*  554 */     long imContext = imContext();
/*  555 */     if (imContext != 0L) this.display.removeWidget(imContext);
/*      */   }
/*      */   
/*      */   boolean filterKey(int keyval, long event)
/*      */   {
/*  560 */     int time = GDK.gdk_event_get_time(event);
/*  561 */     if (time != this.lastEventTime) {
/*  562 */       this.lastEventTime = time;
/*  563 */       long imContext = imContext();
/*  564 */       if (imContext != 0L) {
/*  565 */         return GTK.gtk_im_context_filter_keypress(imContext, event);
/*      */       }
/*      */     }
/*  568 */     this.gdkEventKey = event;
/*  569 */     return false;
/*      */   }
/*      */   
/*      */   long findPopupHandle(long oldList) {
/*  573 */     long result = 0L;
/*  574 */     long currentList = GTK.gtk_window_list_toplevels();
/*  575 */     long oldFromList = oldList;
/*  576 */     long newFromList = OS.g_list_last(currentList);
/*      */     
/*  578 */     while (newFromList != 0L) {
/*  579 */       long newToplevel = OS.g_list_data(newFromList);
/*  580 */       boolean isFound = false;
/*  581 */       oldFromList = oldList;
/*  582 */       while (oldFromList != 0L) {
/*  583 */         long oldToplevel = OS.g_list_data(oldFromList);
/*  584 */         if (newToplevel == oldToplevel) {
/*  585 */           isFound = true;
/*  586 */           break;
/*      */         }
/*  588 */         oldFromList = OS.g_list_next(oldFromList);
/*      */       }
/*  590 */       if (!isFound) {
/*  591 */         result = newToplevel;
/*  592 */         break;
/*      */       }
/*  594 */       newFromList = OS.g_list_previous(newFromList);
/*      */     }
/*  596 */     OS.g_list_free(oldList);
/*  597 */     OS.g_list_free(currentList);
/*  598 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   long findButtonHandle()
/*      */   {
/*  609 */     long result = 0L;
/*  610 */     long childHandle = this.handle;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  618 */     if (GTK.GTK_VERSION >= OS.VERSION(3, 20, 0)) {
/*  619 */       GTK.gtk_container_forall(this.handle, this.display.allChildrenProc, 0L);
/*  620 */       if (this.display.allChildren != 0L) {
/*  621 */         long list = this.display.allChildren;
/*  622 */         while (list != 0L) {
/*  623 */           long widget = OS.g_list_data(list);
/*  624 */           if (widget != 0L) {
/*  625 */             childHandle = widget;
/*  626 */             break;
/*      */           }
/*  628 */           list = OS.g_list_next(list);
/*      */         }
/*  630 */         OS.g_list_free(this.display.allChildren);
/*  631 */         this.display.allChildren = 0L;
/*      */       }
/*  633 */       this.buttonBoxHandle = childHandle;
/*      */     }
/*      */     
/*  636 */     GTK.gtk_container_forall(childHandle, this.display.allChildrenProc, 0L);
/*  637 */     if (this.display.allChildren != 0L) {
/*  638 */       long list = this.display.allChildren;
/*  639 */       while (list != 0L) {
/*  640 */         long widget = OS.g_list_data(list);
/*  641 */         if (GTK.GTK_IS_BUTTON(widget)) {
/*  642 */           result = widget;
/*  643 */           break;
/*      */         }
/*  645 */         list = OS.g_list_next(list);
/*      */       }
/*  647 */       OS.g_list_free(this.display.allChildren);
/*  648 */       this.display.allChildren = 0L;
/*      */     }
/*  650 */     return result;
/*      */   }
/*      */   
/*      */   long findMenuHandle() {
/*  654 */     if (this.popupHandle == 0L) return 0L;
/*  655 */     long result = 0L;
/*  656 */     GTK.gtk_container_forall(this.popupHandle, this.display.allChildrenProc, 0L);
/*  657 */     if (this.display.allChildren != 0L) {
/*  658 */       long list = this.display.allChildren;
/*  659 */       while (list != 0L) {
/*  660 */         long widget = OS.g_list_data(list);
/*  661 */         if (OS.G_OBJECT_TYPE(widget) == GTK.GTK_TYPE_MENU()) {
/*  662 */           result = widget;
/*  663 */           break;
/*      */         }
/*  665 */         list = OS.g_list_next(list);
/*      */       }
/*  667 */       OS.g_list_free(this.display.allChildren);
/*  668 */       this.display.allChildren = 0L;
/*      */     }
/*  670 */     return result;
/*      */   }
/*      */   
/*      */   void fixModal(long group, long modalGroup)
/*      */   {
/*  675 */     if (this.popupHandle != 0L) {
/*  676 */       if (group != 0L) {
/*  677 */         GTK.gtk_window_group_add_window(group, this.popupHandle);
/*      */       }
/*  679 */       else if (modalGroup != 0L) {
/*  680 */         GTK.gtk_window_group_remove_window(modalGroup, this.popupHandle);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void fixIM()
/*      */   {
/*  695 */     if ((this.gdkEventKey != 0L) && (this.gdkEventKey != -1L)) {
/*  696 */       long imContext = imContext();
/*  697 */       if (imContext != 0L) {
/*  698 */         GTK.gtk_im_context_filter_keypress(imContext, this.gdkEventKey);
/*  699 */         this.gdkEventKey = -1L;
/*  700 */         return;
/*      */       }
/*      */     }
/*  703 */     this.gdkEventKey = 0L;
/*      */   }
/*      */   
/*      */   long fontHandle()
/*      */   {
/*  708 */     if (this.entryHandle != 0L) return this.entryHandle;
/*  709 */     return super.fontHandle();
/*      */   }
/*      */   
/*      */   long focusHandle()
/*      */   {
/*  714 */     if (this.entryHandle != 0L) return this.entryHandle;
/*  715 */     return super.focusHandle();
/*      */   }
/*      */   
/*      */   boolean hasFocus()
/*      */   {
/*  720 */     if (super.hasFocus()) return true;
/*  721 */     if ((this.entryHandle != 0L) && (GTK.gtk_widget_has_focus(this.entryHandle))) return true;
/*  722 */     return false;
/*      */   }
/*      */   
/*      */   void hookEvents()
/*      */   {
/*  727 */     super.hookEvents();
/*  728 */     OS.g_signal_connect_closure(this.handle, OS.changed, this.display.getClosure(6), true);
/*      */     
/*  730 */     if (this.entryHandle != 0L) {
/*  731 */       OS.g_signal_connect_closure(this.entryHandle, OS.changed, this.display.getClosure(6), true);
/*  732 */       OS.g_signal_connect_closure(this.entryHandle, OS.insert_text, this.display.getClosure(26), false);
/*  733 */       OS.g_signal_connect_closure(this.entryHandle, OS.delete_text, this.display.getClosure(13), false);
/*  734 */       OS.g_signal_connect_closure(this.entryHandle, OS.activate, this.display.getClosure(1), false);
/*  735 */       OS.g_signal_connect_closure(this.entryHandle, OS.populate_popup, this.display.getClosure(37), false);
/*      */     }
/*      */     
/*  738 */     hookEvents(new long[] { this.buttonHandle, this.entryHandle, this.menuHandle });
/*      */     
/*  740 */     long imContext = imContext();
/*  741 */     if (imContext != 0L) {
/*  742 */       OS.g_signal_connect_closure(imContext, OS.commit, this.display.getClosure(9), false);
/*  743 */       int id = OS.g_signal_lookup(OS.commit, GTK.gtk_im_context_get_type());
/*  744 */       int blockMask = 17;
/*  745 */       OS.g_signal_handlers_block_matched(imContext, blockMask, id, 0, 0L, 0L, this.entryHandle);
/*      */     }
/*      */   }
/*      */   
/*      */   void hookEvents(long[] handles) {
/*  750 */     int eventMask = 772;
/*  751 */     for (int i = 0; i < handles.length; i++) {
/*  752 */       long eventHandle = handles[i];
/*  753 */       if (eventHandle != 0L)
/*      */       {
/*  755 */         GTK.gtk_widget_add_events(eventHandle, eventMask);
/*  756 */         OS.g_signal_connect_closure_by_id(eventHandle, this.display.signalIds[2], 0, this.display.getClosure(2), false);
/*  757 */         OS.g_signal_connect_closure_by_id(eventHandle, this.display.signalIds[4], 0, this.display.getClosure(4), false);
/*  758 */         OS.g_signal_connect_closure_by_id(eventHandle, this.display.signalIds[33], 0, this.display.getClosure(33), false);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  766 */         OS.g_signal_connect_closure_by_id(eventHandle, this.display.signalIds[2], 0, this.display.getClosure(3), true);
/*  767 */         OS.g_signal_connect_closure_by_id(eventHandle, this.display.signalIds[4], 0, this.display.getClosure(5), true);
/*  768 */         OS.g_signal_connect_closure_by_id(eventHandle, this.display.signalIds[33], 0, this.display.getClosure(34), true);
/*      */         
/*      */ 
/*  771 */         if (eventHandle != focusHandle()) {
/*  772 */           OS.g_signal_connect_closure_by_id(eventHandle, this.display.signalIds[16], 0, this.display.getClosure(16), false);
/*      */         }
/*  774 */         if (OS.G_OBJECT_TYPE(eventHandle) == GTK.GTK_TYPE_MENU()) {
/*  775 */           OS.g_signal_connect_closure(eventHandle, OS.selection_done, this.display.getClosure(68), true);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   long imContext() {
/*  782 */     if (this.imContext != 0L) return this.imContext;
/*  783 */     return this.entryHandle != 0L ? GTK.GTK_ENTRY_IM_CONTEXT(this.entryHandle) : 0L;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void deselect(int index)
/*      */   {
/*  799 */     checkWidget();
/*  800 */     if ((index < 0) || (index >= this.items.length)) return;
/*  801 */     if (GTK.gtk_combo_box_get_active(this.handle) == index) {
/*  802 */       clearText();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void deselectAll()
/*      */   {
/*  821 */     checkWidget();
/*  822 */     clearText();
/*      */   }
/*      */   
/*      */   boolean dragDetect(int x, int y, boolean filter, boolean dragOnTimeout, boolean[] consume)
/*      */   {
/*  827 */     if ((filter) && (this.entryHandle != 0L)) {
/*  828 */       int[] index = new int[1];
/*  829 */       int[] trailing = new int[1];
/*  830 */       long layout = GTK.gtk_entry_get_layout(this.entryHandle);
/*  831 */       OS.pango_layout_xy_to_index(layout, x * 1024, y * 1024, index, trailing);
/*  832 */       long ptr = OS.pango_layout_get_text(layout);
/*  833 */       int position = (int)OS.g_utf8_pointer_to_offset(ptr, ptr + index[0]) + trailing[0];
/*  834 */       int[] start = new int[1];
/*  835 */       int[] end = new int[1];
/*  836 */       GTK.gtk_editable_get_selection_bounds(this.entryHandle, start, end);
/*  837 */       if ((start[0] <= position) && (position < end[0]) && 
/*  838 */         (super.dragDetect(x, y, filter, dragOnTimeout, consume))) {
/*  839 */         if (consume != null) consume[0] = true;
/*  840 */         return true;
/*      */       }
/*      */       
/*  843 */       return false;
/*      */     }
/*  845 */     return super.dragDetect(x, y, filter, dragOnTimeout, consume);
/*      */   }
/*      */   
/*      */   long enterExitHandle()
/*      */   {
/*  850 */     return this.fixedHandle;
/*      */   }
/*      */   
/*      */   long eventWindow()
/*      */   {
/*  855 */     return paintWindow();
/*      */   }
/*      */   
/*      */   GdkColor getBackgroundGdkColor()
/*      */   {
/*  860 */     assert (!GTK.GTK3) : "GTK2 code was run by GTK3";
/*  861 */     return getBaseGdkColor();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Point getCaretLocation()
/*      */   {
/*  878 */     checkWidget();
/*  879 */     return DPIUtil.autoScaleDown(getCaretLocationInPixels());
/*      */   }
/*      */   
/*      */   Point getCaretLocationInPixels()
/*      */   {
/*  884 */     checkWidget();
/*  885 */     if ((this.style & 0x8) != 0) {
/*  886 */       return new Point(0, 0);
/*      */     }
/*  888 */     int index = GTK.gtk_editable_get_position(this.entryHandle);
/*  889 */     index = GTK.gtk_entry_text_index_to_layout_index(this.entryHandle, index);
/*  890 */     int[] offset_x = new int[1];int[] offset_y = new int[1];
/*  891 */     GTK.gtk_entry_get_layout_offsets(this.entryHandle, offset_x, offset_y);
/*  892 */     long layout = GTK.gtk_entry_get_layout(this.entryHandle);
/*  893 */     PangoRectangle pos = new PangoRectangle();
/*  894 */     OS.pango_layout_index_to_pos(layout, index, pos);
/*  895 */     int x = offset_x[0] + OS.PANGO_PIXELS(pos.x) - getBorderWidthInPixels();
/*  896 */     int y = offset_y[0] + OS.PANGO_PIXELS(pos.y);
/*  897 */     return new Point(x, y);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getCaretPosition()
/*      */   {
/*  916 */     checkWidget();
/*  917 */     if ((this.style & 0x8) != 0) {
/*  918 */       return 0;
/*      */     }
/*  920 */     long ptr = GTK.gtk_entry_get_text(this.entryHandle);
/*  921 */     return (int)OS.g_utf8_offset_to_utf16_offset(ptr, GTK.gtk_editable_get_position(this.entryHandle));
/*      */   }
/*      */   
/*      */   GdkRGBA getContextBackgroundGdkRGBA()
/*      */   {
/*  926 */     assert (GTK.GTK3) : "GTK3 code was run by GTK2";
/*  927 */     if ((this.background != null) && ((this.state & 0x2000) != 0)) {
/*  928 */       return this.background;
/*      */     }
/*  930 */     return defaultBackground();
/*      */   }
/*      */   
/*      */   GdkColor getForegroundGdkColor()
/*      */   {
/*  935 */     assert (!GTK.GTK3) : "GTK2 code was run by GTK3";
/*  936 */     return getTextColor();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getItem(int index)
/*      */   {
/*  956 */     checkWidget();
/*  957 */     if ((0 > index) || (index >= this.items.length)) {
/*  958 */       error(6);
/*      */     }
/*  960 */     return this.items[index];
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getItemCount()
/*      */   {
/*  974 */     checkWidget();
/*  975 */     return this.items.length;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getItemHeight()
/*      */   {
/*  990 */     checkWidget();
/*  991 */     return fontHeight(getFontDescription(), this.handle);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String[] getItems()
/*      */   {
/* 1011 */     checkWidget();
/* 1012 */     String[] result = new String[this.items.length];
/* 1013 */     System.arraycopy(this.items, 0, result, 0, this.items.length);
/* 1014 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getListVisible()
/*      */   {
/* 1037 */     checkWidget();
/* 1038 */     return (this.popupHandle != 0L) && (GTK.gtk_widget_get_visible(this.popupHandle));
/*      */   }
/*      */   
/*      */   String getNameText()
/*      */   {
/* 1043 */     return getText();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getOrientation()
/*      */   {
/* 1060 */     return super.getOrientation();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Point getSelection()
/*      */   {
/* 1083 */     checkWidget();
/* 1084 */     if ((this.style & 0x8) != 0) {
/* 1085 */       int length = 0;
/* 1086 */       int index = GTK.gtk_combo_box_get_active(this.handle);
/* 1087 */       if (index != -1) length = getItem(index).length();
/* 1088 */       return new Point(0, length);
/*      */     }
/* 1090 */     int[] start = new int[1];
/* 1091 */     int[] end = new int[1];
/* 1092 */     if (this.entryHandle != 0L) {
/* 1093 */       GTK.gtk_editable_get_selection_bounds(this.entryHandle, start, end);
/* 1094 */       long ptr = GTK.gtk_entry_get_text(this.entryHandle);
/* 1095 */       start[0] = ((int)OS.g_utf8_offset_to_utf16_offset(ptr, start[0]));
/* 1096 */       end[0] = ((int)OS.g_utf8_offset_to_utf16_offset(ptr, end[0]));
/*      */     }
/* 1098 */     return new Point(start[0], end[0]);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getSelectionIndex()
/*      */   {
/* 1113 */     checkWidget();
/* 1114 */     return GTK.gtk_combo_box_get_active(this.handle);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getText()
/*      */   {
/* 1130 */     checkWidget();
/* 1131 */     if (this.entryHandle != 0L) {
/* 1132 */       long str = GTK.gtk_entry_get_text(this.entryHandle);
/* 1133 */       if (str == 0L) return "";
/* 1134 */       int length = C.strlen(str);
/* 1135 */       byte[] buffer = new byte[length];
/* 1136 */       C.memmove(buffer, str, length);
/* 1137 */       return new String(Converter.mbcsToWcs(buffer));
/*      */     }
/* 1139 */     int index = GTK.gtk_combo_box_get_active(this.handle);
/* 1140 */     return index != -1 ? getItem(index) : "";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   String getText(int start, int stop)
/*      */   {
/* 1150 */     return getText().substring(start, stop - 1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getTextHeight()
/*      */   {
/* 1164 */     checkWidget();
/* 1165 */     return DPIUtil.autoScaleDown(getTextHeightInPixels());
/*      */   }
/*      */   
/*      */   int getTextHeightInPixels()
/*      */   {
/* 1170 */     checkWidget();
/* 1171 */     GtkRequisition requisition = new GtkRequisition();
/* 1172 */     gtk_widget_size_request(this.handle, requisition);
/* 1173 */     if (GTK.GTK3) {
/* 1174 */       return requisition.height;
/*      */     }
/* 1176 */     return GTK.GTK_WIDGET_REQUISITION_HEIGHT(this.handle);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getTextLimit()
/*      */   {
/* 1196 */     checkWidget();
/* 1197 */     int limit = this.entryHandle != 0L ? GTK.gtk_entry_get_max_length(this.entryHandle) : 0;
/* 1198 */     return limit == 0 ? LIMIT : limit;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getVisibleItemCount()
/*      */   {
/* 1219 */     checkWidget();
/* 1220 */     return this.visibleCount;
/*      */   }
/*      */   
/*      */   long gtk_activate(long widget)
/*      */   {
/* 1225 */     sendSelectionEvent(14);
/* 1226 */     return 0L;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   long gtk_button_press_event(long widget, long event)
/*      */   {
/* 1236 */     GdkEventButton gdkEvent = new GdkEventButton();
/* 1237 */     OS.memmove(gdkEvent, event, GdkEventButton.sizeof);
/* 1238 */     if ((gdkEvent.type == 4) && (gdkEvent.button == 1)) {
/* 1239 */       return gtk_button_press_event(widget, event, false);
/*      */     }
/* 1241 */     return super.gtk_button_press_event(widget, event);
/*      */   }
/*      */   
/*      */   long gtk_changed(long widget)
/*      */   {
/* 1246 */     if (widget == this.handle) {
/* 1247 */       if (this.entryHandle == 0L) {
/* 1248 */         sendEvent(24);
/* 1249 */         if (isDisposed()) { return 0L;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1262 */       int index = GTK.gtk_combo_box_get_active(this.handle);
/* 1263 */       if (index != -1) sendSelectionEvent(13);
/* 1264 */       this.indexSelected = -1;
/* 1265 */       return 0L;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1274 */     boolean keyPress = false;
/* 1275 */     long eventPtr = GTK.gtk_get_current_event();
/* 1276 */     if (eventPtr != 0L) {
/* 1277 */       GdkEventKey gdkEvent = new GdkEventKey();
/* 1278 */       OS.memmove(gdkEvent, eventPtr, GdkEventKey.sizeof);
/* 1279 */       switch (gdkEvent.type) {
/*      */       case 8: 
/* 1281 */         keyPress = true;
/*      */       }
/*      */       
/* 1284 */       GDK.gdk_event_free(eventPtr);
/*      */     }
/* 1286 */     if (keyPress) {
/* 1287 */       postEvent(24);
/*      */     } else {
/* 1289 */       sendEvent(24);
/*      */     }
/* 1291 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_commit(long imContext, long text)
/*      */   {
/* 1296 */     if (text == 0L) return 0L;
/* 1297 */     if (!GTK.gtk_editable_get_editable(this.entryHandle)) return 0L;
/* 1298 */     int length = C.strlen(text);
/* 1299 */     if (length == 0) return 0L;
/* 1300 */     byte[] buffer = new byte[length];
/* 1301 */     C.memmove(buffer, text, length);
/* 1302 */     char[] chars = Converter.mbcsToWcs(buffer);
/* 1303 */     char[] newChars = sendIMKeyEvent(1, null, chars);
/* 1304 */     if (newChars == null) { return 0L;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1312 */     this.fixStart = (this.fixEnd = -1);
/* 1313 */     OS.g_signal_handlers_block_matched(imContext, 16, 0, 0, 0L, 0L, 9L);
/* 1314 */     int id = OS.g_signal_lookup(OS.commit, GTK.gtk_im_context_get_type());
/* 1315 */     int mask = 17;
/* 1316 */     OS.g_signal_handlers_unblock_matched(imContext, mask, id, 0, 0L, 0L, this.entryHandle);
/* 1317 */     if (newChars == chars) {
/* 1318 */       OS.g_signal_emit_by_name(imContext, OS.commit, text);
/*      */     } else {
/* 1320 */       buffer = Converter.wcsToMbcs(newChars, true);
/* 1321 */       OS.g_signal_emit_by_name(imContext, OS.commit, buffer);
/*      */     }
/* 1323 */     OS.g_signal_handlers_unblock_matched(imContext, 16, 0, 0, 0L, 0L, 9L);
/* 1324 */     OS.g_signal_handlers_block_matched(imContext, mask, id, 0, 0L, 0L, this.entryHandle);
/* 1325 */     if ((this.fixStart != -1) && (this.fixEnd != -1)) {
/* 1326 */       GTK.gtk_editable_set_position(this.entryHandle, this.fixStart);
/* 1327 */       GTK.gtk_editable_select_region(this.entryHandle, this.fixStart, this.fixEnd);
/*      */     }
/* 1329 */     this.fixStart = (this.fixEnd = -1);
/* 1330 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_delete_text(long widget, long start_pos, long end_pos)
/*      */   {
/* 1335 */     if ((!hooks(25)) && (!filters(25))) return 0L;
/* 1336 */     long ptr = GTK.gtk_entry_get_text(this.entryHandle);
/* 1337 */     if (end_pos == -1L) end_pos = OS.g_utf8_strlen(ptr, -1L);
/* 1338 */     int start = (int)OS.g_utf8_offset_to_utf16_offset(ptr, start_pos);
/* 1339 */     int end = (int)OS.g_utf8_offset_to_utf16_offset(ptr, end_pos);
/* 1340 */     String newText = verifyText("", start, end);
/* 1341 */     if (newText == null) {
/* 1342 */       OS.g_signal_stop_emission_by_name(this.entryHandle, OS.delete_text);
/*      */     }
/* 1344 */     else if (newText.length() > 0) {
/* 1345 */       int[] pos = new int[1];
/* 1346 */       pos[0] = ((int)end_pos);
/* 1347 */       byte[] buffer = Converter.wcsToMbcs(newText, false);
/* 1348 */       OS.g_signal_handlers_block_matched(this.entryHandle, 16, 0, 0, 0L, 0L, 6L);
/* 1349 */       OS.g_signal_handlers_block_matched(this.entryHandle, 16, 0, 0, 0L, 0L, 26L);
/* 1350 */       GTK.gtk_editable_insert_text(this.entryHandle, buffer, buffer.length, pos);
/* 1351 */       OS.g_signal_handlers_unblock_matched(this.entryHandle, 16, 0, 0, 0L, 0L, 26L);
/* 1352 */       OS.g_signal_handlers_unblock_matched(this.entryHandle, 16, 0, 0, 0L, 0L, 6L);
/* 1353 */       GTK.gtk_editable_set_position(this.entryHandle, pos[0]);
/*      */     }
/*      */     
/* 1356 */     return 0L;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   long gtk_draw(long widget, long cairo)
/*      */   {
/* 1372 */     if ((GTK.GTK_VERSION >= OS.VERSION(3, 20, 0)) && ((this.style & 0x8) != 0) && 
/* 1373 */       (this.parent != null) && (this.parent.fixClipHandle == 0L)) {
/* 1374 */       long parentHandle = GTK.gtk_widget_get_parent(this.fixedHandle);
/* 1375 */       if (parentHandle != 0L) {
/* 1376 */         this.parent.fixClipHandle = parentHandle;
/* 1377 */         GTK.gtk_widget_queue_draw(parentHandle);
/* 1378 */         long[] array = { this.fixedHandle, this.handle, this.buttonBoxHandle, this.buttonHandle, this.cellBoxHandle, this.cellHandle };
/* 1379 */         this.parent.fixClipHandleChildren = new long[array.length];
/* 1380 */         System.arraycopy(array, 0, this.parent.fixClipHandleChildren, 0, array.length);
/*      */       }
/*      */     }
/*      */     
/* 1384 */     return super.gtk_draw(widget, cairo);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   long gtk_event_after(long widget, long gdkEvent)
/*      */   {
/* 1402 */     GdkEvent event = new GdkEvent();
/* 1403 */     OS.memmove(event, gdkEvent, GdkEvent.sizeof);
/* 1404 */     switch (event.type) {
/*      */     case 4: 
/* 1406 */       GdkEventButton gdkEventButton = new GdkEventButton();
/* 1407 */       OS.memmove(gdkEventButton, gdkEvent, GdkEventButton.sizeof);
/* 1408 */       if (gdkEventButton.button == 1) {
/* 1409 */         if (!sendMouseEvent(3, gdkEventButton.button, this.display.clickCount, 0, false, gdkEventButton.time, gdkEventButton.x_root, gdkEventButton.y_root, false, gdkEventButton.state)) {
/* 1410 */           return 1L;
/*      */         }
/* 1412 */         if (((this.style & 0x8) == 0) && (widget == this.buttonHandle)) {
/* 1413 */           GTK.gtk_widget_grab_focus(this.entryHandle);
/*      */         }
/*      */       }
/*      */       
/*      */       break;
/*      */     case 12: 
/* 1419 */       if ((this.style & 0x8) == 0) {
/* 1420 */         GdkEventFocus gdkEventFocus = new GdkEventFocus();
/* 1421 */         OS.memmove(gdkEventFocus, gdkEvent, GdkEventFocus.sizeof);
/* 1422 */         if (gdkEventFocus.in != 0) {
/* 1423 */           if (GTK.GTK_VERSION >= OS.VERSION(3, 20, 0)) {
/* 1424 */             GTK.gtk_widget_set_focus_on_click(this.handle, false);
/*      */           } else {
/* 1426 */             GTK.gtk_combo_box_set_focus_on_click(this.handle, false);
/*      */           }
/*      */         }
/* 1429 */         else if (GTK.GTK_VERSION >= OS.VERSION(3, 20, 0)) {
/* 1430 */           GTK.gtk_widget_set_focus_on_click(this.handle, true);
/*      */         } else {
/* 1432 */           GTK.gtk_combo_box_set_focus_on_click(this.handle, true);
/*      */         }
/*      */       }
/*      */       
/*      */       break;
/*      */     }
/*      */     
/* 1439 */     return super.gtk_event_after(widget, gdkEvent);
/*      */   }
/*      */   
/*      */   long gtk_focus_out_event(long widget, long event)
/*      */   {
/* 1444 */     fixIM();
/* 1445 */     return super.gtk_focus_out_event(widget, event);
/*      */   }
/*      */   
/*      */   long gtk_insert_text(long widget, long new_text, long new_text_length, long position)
/*      */   {
/* 1450 */     if ((!hooks(25)) && (!filters(25))) return 0L;
/* 1451 */     if ((new_text == 0L) || (new_text_length == 0L)) return 0L;
/* 1452 */     byte[] buffer = new byte[(int)new_text_length];
/* 1453 */     C.memmove(buffer, new_text, buffer.length);
/* 1454 */     String oldText = new String(Converter.mbcsToWcs(buffer));
/* 1455 */     int[] pos = new int[1];
/* 1456 */     C.memmove(pos, position, 4L);
/* 1457 */     long ptr = GTK.gtk_entry_get_text(this.entryHandle);
/* 1458 */     if (pos[0] == -1) pos[0] = ((int)OS.g_utf8_strlen(ptr, -1L));
/* 1459 */     int start = (int)OS.g_utf8_offset_to_utf16_offset(ptr, pos[0]);
/* 1460 */     String newText = verifyText(oldText, start, start);
/* 1461 */     if (newText != oldText) {
/* 1462 */       int[] newStart = new int[1];int[] newEnd = new int[1];
/* 1463 */       GTK.gtk_editable_get_selection_bounds(this.entryHandle, newStart, newEnd);
/* 1464 */       if (newText != null) {
/* 1465 */         if (newStart[0] != newEnd[0]) {
/* 1466 */           OS.g_signal_handlers_block_matched(this.entryHandle, 16, 0, 0, 0L, 0L, 13L);
/* 1467 */           OS.g_signal_handlers_block_matched(this.entryHandle, 16, 0, 0, 0L, 0L, 6L);
/* 1468 */           GTK.gtk_editable_delete_selection(this.entryHandle);
/* 1469 */           OS.g_signal_handlers_unblock_matched(this.entryHandle, 16, 0, 0, 0L, 0L, 13L);
/* 1470 */           OS.g_signal_handlers_unblock_matched(this.entryHandle, 16, 0, 0, 0L, 0L, 6L);
/*      */         }
/* 1472 */         byte[] buffer3 = Converter.wcsToMbcs(newText, false);
/* 1473 */         OS.g_signal_handlers_block_matched(this.entryHandle, 16, 0, 0, 0L, 0L, 26L);
/* 1474 */         GTK.gtk_editable_insert_text(this.entryHandle, buffer3, buffer3.length, pos);
/* 1475 */         OS.g_signal_handlers_unblock_matched(this.entryHandle, 16, 0, 0, 0L, 0L, 26L);
/* 1476 */         newStart[0] = (newEnd[0] = pos[0]);
/*      */       }
/* 1478 */       pos[0] = newEnd[0];
/* 1479 */       if (newStart[0] != newEnd[0]) {
/* 1480 */         this.fixStart = newStart[0];
/* 1481 */         this.fixEnd = newEnd[0];
/*      */       }
/* 1483 */       C.memmove(position, pos, 4L);
/* 1484 */       OS.g_signal_stop_emission_by_name(this.entryHandle, OS.insert_text);
/*      */     }
/* 1486 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_key_press_event(long widget, long event)
/*      */   {
/* 1491 */     long result = super.gtk_key_press_event(widget, event);
/* 1492 */     if (result != 0L) {
/* 1493 */       this.gdkEventKey = 0L;
/* 1494 */       fixIM();
/* 1495 */       return result;
/*      */     }
/* 1497 */     if (this.gdkEventKey == -1L) result = 1L;
/* 1498 */     this.gdkEventKey = 0L;
/* 1499 */     if ((this.style & 0x8) == 0) {
/* 1500 */       GdkEventKey keyEvent = new GdkEventKey();
/* 1501 */       OS.memmove(keyEvent, event, GdkEventKey.sizeof);
/* 1502 */       int oldIndex = GTK.gtk_combo_box_get_active(this.handle);
/* 1503 */       int newIndex = oldIndex;
/* 1504 */       int key = keyEvent.keyval;
/* 1505 */       switch (key) {
/*      */       case 65364: 
/*      */       case 65433: 
/* 1508 */         if (oldIndex != this.items.length - 1) {
/* 1509 */           newIndex = oldIndex + 1;
/*      */         }
/*      */         break;
/*      */       case 65362: 
/*      */       case 65431: 
/* 1514 */         if ((oldIndex != -1) && (oldIndex != 0)) {
/* 1515 */           newIndex = oldIndex - 1;
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         break;
/*      */       case 65365: 
/*      */       case 65434: 
/* 1526 */         newIndex = 0;
/* 1527 */         break;
/*      */       case 65366: 
/*      */       case 65435: 
/* 1530 */         newIndex = this.items.length - 1;
/*      */       }
/*      */       
/* 1533 */       if (newIndex != oldIndex) {
/* 1534 */         GTK.gtk_combo_box_set_active(this.handle, newIndex);
/* 1535 */         return 1L;
/*      */       }
/*      */     }
/* 1538 */     return result;
/*      */   }
/*      */   
/*      */   long gtk_populate_popup(long widget, long menu)
/*      */   {
/* 1543 */     if ((this.style & 0x4000000) != 0) {
/* 1544 */       GTK.gtk_widget_set_direction(menu, 2);
/* 1545 */       GTK.gtk_container_forall(menu, this.display.setDirectionProc, 2L);
/*      */     }
/* 1547 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_selection_done(long menushell)
/*      */   {
/* 1552 */     int index = GTK.gtk_combo_box_get_active(this.handle);
/* 1553 */     if (this.indexSelected == -1) {
/* 1554 */       this.indexSelected = index;
/*      */     }
/* 1556 */     else if ((index != -1) && (this.indexSelected == index)) {
/* 1557 */       sendSelectionEvent(13);
/*      */     }
/* 1559 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_style_set(long widget, long previousStyle)
/*      */   {
/* 1564 */     setButtonHandle(findButtonHandle());
/* 1565 */     setMenuHandle(findMenuHandle());
/* 1566 */     return super.gtk_style_set(widget, previousStyle);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int indexOf(String string)
/*      */   {
/* 1587 */     checkWidget();
/* 1588 */     return indexOf(string, 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int indexOf(String string, int start)
/*      */   {
/* 1611 */     checkWidget();
/* 1612 */     if (string == null) error(4);
/* 1613 */     if ((0 > start) || (start >= this.items.length)) return -1;
/* 1614 */     for (int i = start; i < this.items.length; i++) {
/* 1615 */       if (string.equals(this.items[i])) return i;
/*      */     }
/* 1617 */     return -1;
/*      */   }
/*      */   
/*      */   boolean isFocusHandle(long widget)
/*      */   {
/* 1622 */     if ((this.buttonHandle != 0L) && (widget == this.buttonHandle)) return true;
/* 1623 */     if ((this.entryHandle != 0L) && (widget == this.entryHandle)) return true;
/* 1624 */     return super.isFocusHandle(widget);
/*      */   }
/*      */   
/*      */   long paintWindow()
/*      */   {
/* 1629 */     long childHandle = this.entryHandle != 0L ? this.entryHandle : this.handle;
/* 1630 */     GTK.gtk_widget_realize(childHandle);
/* 1631 */     long window = gtk_widget_get_window(childHandle);
/* 1632 */     if ((this.style & 0x8) != 0) return window;
/* 1633 */     long children = GDK.gdk_window_get_children(window);
/* 1634 */     if (children != 0L)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 1639 */       if (GTK.GTK_VERSION >= OS.VERSION(3, 20, 0)) {
/*      */         do {
/* 1641 */           window = OS.g_list_data(children);
/* 1642 */         } while ((children = OS.g_list_next(children)) != 0L);
/*      */       } else {
/* 1644 */         window = OS.g_list_data(children);
/*      */       }
/*      */     }
/* 1647 */     OS.g_list_free(children);
/*      */     
/* 1649 */     return window;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void paste()
/*      */   {
/* 1667 */     checkWidget();
/* 1668 */     if (this.entryHandle != 0L) GTK.gtk_editable_paste_clipboard(this.entryHandle);
/*      */   }
/*      */   
/*      */   long parentingHandle()
/*      */   {
/* 1673 */     return this.fixedHandle;
/*      */   }
/*      */   
/*      */   void register()
/*      */   {
/* 1678 */     super.register();
/* 1679 */     if (this.buttonHandle != 0L) this.display.addWidget(this.buttonHandle, this);
/* 1680 */     if (this.entryHandle != 0L) this.display.addWidget(this.entryHandle, this);
/* 1681 */     if (this.popupHandle != 0L) this.display.addWidget(this.popupHandle, this);
/* 1682 */     if (this.menuHandle != 0L) this.display.addWidget(this.menuHandle, this);
/* 1683 */     long imContext = imContext();
/* 1684 */     if (imContext != 0L) this.display.addWidget(imContext, this);
/*      */   }
/*      */   
/*      */   void releaseHandle()
/*      */   {
/* 1689 */     super.releaseHandle();
/* 1690 */     if (this.menuHandle != 0L) {
/* 1691 */       OS.g_object_unref(this.menuHandle);
/*      */     }
/* 1693 */     if (this.buttonHandle != 0L) {
/* 1694 */       OS.g_object_unref(this.buttonHandle);
/*      */     }
/* 1696 */     if (this.buttonBoxHandle != 0L) {
/* 1697 */       OS.g_object_unref(this.buttonBoxHandle);
/*      */     }
/* 1699 */     if (this.cellBoxHandle != 0L) {
/* 1700 */       OS.g_object_unref(this.cellBoxHandle);
/*      */     }
/* 1702 */     this.cellBoxHandle = (this.buttonBoxHandle = this.menuHandle = this.buttonHandle = this.entryHandle = 0L);
/*      */   }
/*      */   
/*      */   void releaseWidget()
/*      */   {
/* 1707 */     super.releaseWidget();
/* 1708 */     this.textRenderer = 0L;
/* 1709 */     fixIM();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void remove(int index)
/*      */   {
/* 1727 */     checkWidget();
/* 1728 */     if ((0 > index) || (index >= this.items.length)) {
/* 1729 */       error(6);
/*      */     }
/* 1731 */     String[] oldItems = this.items;
/* 1732 */     String[] newItems = new String[oldItems.length - 1];
/* 1733 */     System.arraycopy(oldItems, 0, newItems, 0, index);
/* 1734 */     System.arraycopy(oldItems, index + 1, newItems, index, oldItems.length - index - 1);
/* 1735 */     this.items = newItems;
/* 1736 */     if (GTK.gtk_combo_box_get_active(this.handle) == index) clearText();
/* 1737 */     if (this.handle != 0L) { GTK.gtk_combo_box_text_remove(this.handle, index);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void remove(int start, int end)
/*      */   {
/* 1757 */     checkWidget();
/* 1758 */     if (start > end) return;
/* 1759 */     if ((0 > start) || (start > end) || (end >= this.items.length)) {
/* 1760 */       error(6);
/*      */     }
/* 1762 */     String[] oldItems = this.items;
/* 1763 */     String[] newItems = new String[oldItems.length - (end - start + 1)];
/* 1764 */     System.arraycopy(oldItems, 0, newItems, 0, start);
/* 1765 */     System.arraycopy(oldItems, end + 1, newItems, start, oldItems.length - end - 1);
/* 1766 */     this.items = newItems;
/* 1767 */     int index = GTK.gtk_combo_box_get_active(this.handle);
/* 1768 */     if ((start <= index) && (index <= end)) clearText();
/* 1769 */     for (int i = end; i >= start; i--) {
/* 1770 */       if (this.handle != 0L) { GTK.gtk_combo_box_text_remove(this.handle, i);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void remove(String string)
/*      */   {
/* 1791 */     checkWidget();
/* 1792 */     if (string == null) error(4);
/* 1793 */     int index = indexOf(string, 0);
/* 1794 */     if (index == -1) error(5);
/* 1795 */     remove(index);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeAll()
/*      */   {
/* 1808 */     checkWidget();
/* 1809 */     int count = this.items.length;
/* 1810 */     this.items = new String[0];
/* 1811 */     clearText();
/* 1812 */     if (GTK.GTK3) {
/* 1813 */       if (this.handle != 0L) GTK.gtk_combo_box_text_remove_all(this.handle);
/*      */     } else {
/* 1815 */       for (int i = count - 1; i >= 0; i--) {
/* 1816 */         if (this.handle != 0L) { GTK.gtk_combo_box_text_remove(this.handle, i);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeModifyListener(ModifyListener listener)
/*      */   {
/* 1839 */     checkWidget();
/* 1840 */     if (listener == null) error(4);
/* 1841 */     if (this.eventTable == null) return;
/* 1842 */     this.eventTable.unhook(24, listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeSegmentListener(SegmentListener listener)
/*      */   {
/* 1866 */     checkWidget();
/* 1867 */     if (listener == null) error(4);
/* 1868 */     this.eventTable.unhook(49, listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeSelectionListener(SelectionListener listener)
/*      */   {
/* 1889 */     checkWidget();
/* 1890 */     if (listener == null) error(4);
/* 1891 */     if (this.eventTable == null) return;
/* 1892 */     this.eventTable.unhook(13, listener);
/* 1893 */     this.eventTable.unhook(14, listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeVerifyListener(VerifyListener listener)
/*      */   {
/* 1916 */     checkWidget();
/* 1917 */     if (listener == null) error(4);
/* 1918 */     if (this.eventTable == null) return;
/* 1919 */     this.eventTable.unhook(25, listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void select(int index)
/*      */   {
/* 1935 */     checkWidget();
/* 1936 */     if ((index < 0) || (index >= this.items.length)) return;
/* 1937 */     int selected = GTK.gtk_combo_box_get_active(this.handle);
/* 1938 */     OS.g_signal_handlers_block_matched(this.handle, 16, 0, 0, 0L, 0L, 6L);
/* 1939 */     GTK.gtk_combo_box_set_active(this.handle, index);
/* 1940 */     OS.g_signal_handlers_unblock_matched(this.handle, 16, 0, 0, 0L, 0L, 6L);
/* 1941 */     if (((this.style & 0x8) != 0) && (selected != index))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1947 */       sendEvent(24);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   void setBackgroundGdkRGBA(long context, long handle, GdkRGBA rgba)
/*      */   {
/* 1954 */     assert (GTK.GTK3) : "GTK3 code was run by GTK2";
/*      */     
/* 1956 */     this.background = rgba;
/* 1957 */     String css = "* {\n";
/*      */     String color;
/* 1959 */     String color; if (rgba != null) {
/* 1960 */       color = this.display.gtk_rgba_to_css_string(rgba);
/*      */     } else { String color;
/* 1962 */       if ((this.style & 0x8) != 0) {
/* 1963 */         color = this.display.gtk_rgba_to_css_string(this.display.COLOR_WIDGET_BACKGROUND_RGBA);
/*      */       } else {
/* 1965 */         color = this.display.gtk_rgba_to_css_string(this.display.COLOR_LIST_BACKGROUND_RGBA);
/*      */       }
/*      */     }
/* 1968 */     css = css + "background: " + color + ";}";
/*      */     
/*      */ 
/* 1971 */     this.cssBackground = css;
/* 1972 */     String finalCss = this.display.gtk_css_create_css_color_string(this.cssBackground, this.cssForeground, 8);
/* 1973 */     if ((this.entryHandle == 0L) || ((this.style & 0x8) != 0))
/*      */     {
/* 1975 */       gtk_css_provider_load_from_css(GTK.gtk_widget_get_style_context(this.buttonHandle), finalCss);
/*      */     }
/* 1977 */     else if (GTK.GTK_VERSION >= OS.VERSION(3, 14, 0))
/*      */     {
/* 1979 */       gtk_css_provider_load_from_css(GTK.gtk_widget_get_style_context(this.entryHandle), finalCss);
/*      */     }
/*      */     else {
/* 1982 */       setBackgroundGradientGdkRGBA(GTK.gtk_widget_get_style_context(this.entryHandle), handle, rgba);
/* 1983 */       super.setBackgroundGdkRGBA(GTK.gtk_widget_get_style_context(this.entryHandle), this.entryHandle, rgba);
/*      */     }
/*      */     
/*      */ 
/* 1987 */     OS.g_object_set(this.textRenderer, OS.background_rgba, rgba, 0L);
/*      */   }
/*      */   
/*      */   void setBackgroundGdkRGBA(GdkRGBA rgba)
/*      */   {
/* 1992 */     assert (GTK.GTK3) : "GTK3 code was run by GTK2";
/* 1993 */     super.setBackgroundGdkRGBA(rgba);
/* 1994 */     if (this.entryHandle != 0L) setBackgroundGdkRGBA(this.entryHandle, rgba);
/* 1995 */     setBackgroundGdkRGBA(this.fixedHandle, rgba);
/*      */   }
/*      */   
/*      */   void setBackgroundGdkColor(GdkColor color)
/*      */   {
/* 2000 */     assert (!GTK.GTK3) : "GTK2 code was run by GTK3";
/* 2001 */     super.setBackgroundGdkColor(color);
/* 2002 */     if (this.entryHandle != 0L) GTK.gtk_widget_modify_base(this.entryHandle, 0, color);
/* 2003 */     if (this.cellHandle != 0L) OS.g_object_set(this.cellHandle, OS.background_gdk, color, 0L);
/* 2004 */     OS.g_object_set(this.textRenderer, OS.background_gdk, color, 0L);
/*      */     
/* 2006 */     if (this.entryHandle != 0L) setBackgroundGdkColor(this.entryHandle, color);
/* 2007 */     setBackgroundGdkColor(this.fixedHandle, color);
/*      */   }
/*      */   
/*      */   int setBounds(int x, int y, int width, int height, boolean move, boolean resize)
/*      */   {
/* 2012 */     int newHeight = height;
/* 2013 */     if (resize) newHeight = Math.max(getTextHeightInPixels(), height);
/* 2014 */     return super.setBounds(x, y, width, newHeight, move, resize);
/*      */   }
/*      */   
/*      */   void setButtonHandle(long widget) {
/* 2018 */     if (this.buttonHandle == widget) return;
/* 2019 */     if (this.buttonHandle != 0L) {
/* 2020 */       this.display.removeWidget(this.buttonHandle);
/* 2021 */       OS.g_object_unref(this.buttonHandle);
/*      */     }
/* 2023 */     this.buttonHandle = widget;
/* 2024 */     if (this.buttonHandle != 0L) {
/* 2025 */       OS.g_object_ref(this.buttonHandle);
/* 2026 */       this.display.addWidget(this.buttonHandle, this);
/* 2027 */       hookEvents(new long[] { this.buttonHandle });
/*      */     }
/*      */   }
/*      */   
/*      */   void setMenuHandle(long widget) {
/* 2032 */     if (this.menuHandle == widget) return;
/* 2033 */     if (this.menuHandle != 0L) {
/* 2034 */       this.display.removeWidget(this.menuHandle);
/* 2035 */       OS.g_object_unref(this.menuHandle);
/*      */     }
/* 2037 */     this.menuHandle = widget;
/* 2038 */     if (this.menuHandle != 0L) {
/* 2039 */       OS.g_object_ref(this.menuHandle);
/* 2040 */       this.display.addWidget(this.menuHandle, this);
/* 2041 */       hookEvents(new long[] { this.menuHandle });
/*      */     }
/*      */   }
/*      */   
/*      */   void setFontDescription(long font)
/*      */   {
/* 2047 */     super.setFontDescription(font);
/* 2048 */     if (this.entryHandle != 0L) setFontDescription(this.entryHandle, font);
/* 2049 */     OS.g_object_set(this.textRenderer, OS.font_desc, font, 0L);
/* 2050 */     if ((this.style & 0x8) != 0)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2056 */       int index = GTK.gtk_combo_box_get_active(this.handle);
/* 2057 */       OS.g_signal_handlers_block_matched(this.handle, 16, 0, 0, 0L, 0L, 6L);
/* 2058 */       GTK.gtk_combo_box_set_active(this.handle, -1);
/* 2059 */       GTK.gtk_combo_box_set_active(this.handle, index);
/* 2060 */       OS.g_signal_handlers_unblock_matched(this.handle, 16, 0, 0, 0L, 0L, 6L);
/*      */     }
/*      */   }
/*      */   
/*      */   void setForegroundGdkColor(GdkColor color)
/*      */   {
/* 2066 */     assert (!GTK.GTK3) : "GTK2 code was run by GTK3";
/* 2067 */     super.setForegroundColor(this.handle, color, false);
/* 2068 */     if (this.entryHandle != 0L) {
/* 2069 */       setForegroundColor(this.entryHandle, color, false);
/*      */     }
/* 2071 */     OS.g_object_set(this.textRenderer, OS.foreground_gdk, color, 0L);
/*      */   }
/*      */   
/*      */   void setForegroundGdkRGBA(GdkRGBA rgba)
/*      */   {
/* 2076 */     assert (GTK.GTK3) : "GTK3 code was run by GTK2";
/* 2077 */     if (this.entryHandle != 0L) {
/* 2078 */       setForegroundGdkRGBA(this.entryHandle, rgba);
/*      */     }
/* 2080 */     OS.g_object_set(this.textRenderer, OS.foreground_rgba, rgba, 0L);
/* 2081 */     super.setForegroundGdkRGBA(rgba);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setItem(int index, String string)
/*      */   {
/* 2102 */     checkWidget();
/* 2103 */     if (string == null) error(4);
/* 2104 */     if ((0 > index) || (index >= this.items.length)) {
/* 2105 */       error(5);
/*      */     }
/* 2107 */     this.items[index] = string;
/* 2108 */     byte[] buffer = Converter.wcsToMbcs(string, true);
/* 2109 */     if (GTK.GTK3) {
/* 2110 */       if (this.handle != 0L) GTK.gtk_combo_box_text_remove(this.handle, index);
/* 2111 */       if (this.handle != 0L) GTK.gtk_combo_box_text_insert(this.handle, index, null, buffer);
/*      */     } else {
/* 2113 */       if (this.handle != 0L) GTK.gtk_combo_box_text_remove(this.handle, index);
/* 2114 */       if (this.handle != 0L) GTK.gtk_combo_box_text_insert_text(this.handle, index, buffer);
/*      */     }
/* 2116 */     if (((this.style & 0x4000000) != 0) && (this.popupHandle != 0L)) {
/* 2117 */       GTK.gtk_container_forall(this.popupHandle, this.display.setDirectionProc, 2L);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setItems(String... items)
/*      */   {
/* 2136 */     checkWidget();
/* 2137 */     if (items == null) error(4);
/* 2138 */     for (int i = 0; i < items.length; i++) {
/* 2139 */       if (items[i] == null) error(5);
/*      */     }
/* 2141 */     int count = this.items.length;
/* 2142 */     this.items = new String[items.length];
/* 2143 */     System.arraycopy(items, 0, this.items, 0, items.length);
/* 2144 */     clearText();
/* 2145 */     if (GTK.GTK3) {
/* 2146 */       if (this.handle != 0L) GTK.gtk_combo_box_text_remove_all(this.handle);
/*      */     } else {
/* 2148 */       for (int i = count - 1; i >= 0; i--) {
/* 2149 */         if (this.handle != 0L) GTK.gtk_combo_box_text_remove(this.handle, i);
/*      */       }
/*      */     }
/* 2152 */     for (int i = 0; i < items.length; i++) {
/* 2153 */       String string = items[i];
/* 2154 */       byte[] buffer = Converter.wcsToMbcs(string, true);
/* 2155 */       if (GTK.GTK3) {
/* 2156 */         if (this.handle != 0L) GTK.gtk_combo_box_text_insert(this.handle, i, null, buffer);
/*      */       }
/* 2158 */       else if (this.handle != 0L) { GTK.gtk_combo_box_text_insert_text(this.handle, i, buffer);
/*      */       }
/* 2160 */       if (((this.style & 0x4000000) != 0) && (this.popupHandle != 0L)) {
/* 2161 */         GTK.gtk_container_forall(this.popupHandle, this.display.setDirectionProc, 2L);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setListVisible(boolean visible)
/*      */   {
/* 2185 */     checkWidget();
/* 2186 */     if (visible) {
/* 2187 */       GTK.gtk_combo_box_popup(this.handle);
/*      */     } else {
/* 2189 */       GTK.gtk_combo_box_popdown(this.handle);
/*      */     }
/*      */   }
/*      */   
/*      */   void setOrientation(boolean create)
/*      */   {
/* 2195 */     super.setOrientation(create);
/* 2196 */     if (((this.style & 0x4000000) != 0) || (!create)) {
/* 2197 */       int dir = (this.style & 0x4000000) != 0 ? 2 : 1;
/* 2198 */       if (this.entryHandle != 0L) GTK.gtk_widget_set_direction(this.entryHandle, dir);
/* 2199 */       if (this.cellHandle != 0L) GTK.gtk_widget_set_direction(this.cellHandle, dir);
/* 2200 */       if ((!create) && 
/* 2201 */         (this.popupHandle != 0L)) { GTK.gtk_container_forall(this.popupHandle, this.display.setDirectionProc, dir);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setOrientation(int orientation)
/*      */   {
/* 2222 */     super.setOrientation(orientation);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSelection(Point selection)
/*      */   {
/* 2242 */     checkWidget();
/* 2243 */     if (selection == null) error(4);
/* 2244 */     if ((this.style & 0x8) != 0) return;
/* 2245 */     if (this.entryHandle != 0L) {
/* 2246 */       long ptr = GTK.gtk_entry_get_text(this.entryHandle);
/* 2247 */       int start = (int)OS.g_utf16_offset_to_utf8_offset(ptr, selection.x);
/* 2248 */       int end = (int)OS.g_utf16_offset_to_utf8_offset(ptr, selection.y);
/* 2249 */       GTK.gtk_editable_set_position(this.entryHandle, start);
/* 2250 */       GTK.gtk_editable_select_region(this.entryHandle, start, end);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setText(String string)
/*      */   {
/* 2283 */     checkWidget();
/* 2284 */     if (string == null) error(4);
/* 2285 */     if ((this.style & 0x8) != 0) {
/* 2286 */       int index = indexOf(string);
/* 2287 */       if (index == -1) return;
/* 2288 */       select(index);
/* 2289 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2296 */     if ((hooks(25)) || (filters(25))) {
/* 2297 */       long ptr = GTK.gtk_entry_get_text(this.entryHandle);
/* 2298 */       string = verifyText(string, 0, (int)OS.g_utf16_strlen(ptr, -1L));
/* 2299 */       if (string == null) return;
/*      */     }
/* 2301 */     byte[] buffer = Converter.wcsToMbcs(string, true);
/* 2302 */     OS.g_signal_handlers_block_matched(this.handle, 16, 0, 0, 0L, 0L, 6L);
/* 2303 */     OS.g_signal_handlers_block_matched(this.entryHandle, 16, 0, 0, 0L, 0L, 6L);
/* 2304 */     OS.g_signal_handlers_block_matched(this.entryHandle, 16, 0, 0, 0L, 0L, 13L);
/* 2305 */     OS.g_signal_handlers_block_matched(this.entryHandle, 16, 0, 0, 0L, 0L, 26L);
/* 2306 */     GTK.gtk_entry_set_text(this.entryHandle, buffer);
/* 2307 */     OS.g_signal_handlers_unblock_matched(this.handle, 16, 0, 0, 0L, 0L, 6L);
/* 2308 */     OS.g_signal_handlers_unblock_matched(this.entryHandle, 16, 0, 0, 0L, 0L, 6L);
/* 2309 */     OS.g_signal_handlers_unblock_matched(this.entryHandle, 16, 0, 0, 0L, 0L, 13L);
/* 2310 */     OS.g_signal_handlers_unblock_matched(this.entryHandle, 16, 0, 0, 0L, 0L, 26L);
/* 2311 */     sendEvent(24);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTextLimit(int limit)
/*      */   {
/* 2335 */     checkWidget();
/* 2336 */     if (limit == 0) error(7);
/* 2337 */     if (this.entryHandle != 0L) GTK.gtk_entry_set_max_length(this.entryHandle, limit);
/*      */   }
/*      */   
/*      */   void setToolTipText(Shell shell, String newString)
/*      */   {
/* 2342 */     if (this.entryHandle != 0L) shell.setToolTipText(this.entryHandle, newString);
/* 2343 */     if (this.buttonHandle != 0L) { shell.setToolTipText(this.buttonHandle, newString);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setVisibleItemCount(int count)
/*      */   {
/* 2364 */     checkWidget();
/* 2365 */     if (count < 0) return;
/* 2366 */     this.visibleCount = count;
/*      */   }
/*      */   
/*      */   boolean checkSubwindow()
/*      */   {
/* 2371 */     return false;
/*      */   }
/*      */   
/*      */   boolean translateTraversal(GdkEventKey keyEvent)
/*      */   {
/* 2376 */     int key = keyEvent.keyval;
/* 2377 */     switch (key) {
/*      */     case 65293: 
/*      */     case 65421: 
/* 2380 */       long imContext = imContext();
/* 2381 */       if (imContext != 0L) {
/* 2382 */         long[] preeditString = new long[1];
/* 2383 */         GTK.gtk_im_context_get_preedit_string(imContext, preeditString, null, null);
/* 2384 */         if (preeditString[0] != 0L) {
/* 2385 */           int length = C.strlen(preeditString[0]);
/* 2386 */           OS.g_free(preeditString[0]);
/* 2387 */           if (length != 0) return false;
/*      */         }
/*      */       }
/*      */       break;
/*      */     }
/* 2392 */     return super.translateTraversal(keyEvent);
/*      */   }
/*      */   
/*      */   String verifyText(String string, int start, int end) {
/* 2396 */     if ((string.length() == 0) && (start == end)) return null;
/* 2397 */     Event event = new Event();
/* 2398 */     event.text = string;
/* 2399 */     event.start = start;
/* 2400 */     event.end = end;
/* 2401 */     long eventPtr = GTK.gtk_get_current_event();
/* 2402 */     if (eventPtr != 0L) {
/* 2403 */       GdkEventKey gdkEvent = new GdkEventKey();
/* 2404 */       OS.memmove(gdkEvent, eventPtr, GdkEventKey.sizeof);
/* 2405 */       switch (gdkEvent.type) {
/*      */       case 8: 
/* 2407 */         setKeyState(event, gdkEvent);
/*      */       }
/*      */       
/* 2410 */       GDK.gdk_event_free(eventPtr);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2418 */     sendEvent(25, event);
/* 2419 */     if ((!event.doit) || (isDisposed())) return null;
/* 2420 */     return event.text;
/*      */   }
/*      */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/widgets/Combo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */