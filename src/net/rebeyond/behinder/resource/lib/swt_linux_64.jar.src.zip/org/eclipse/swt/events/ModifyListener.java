package org.eclipse.swt.events;

import org.eclipse.swt.internal.SWTEventListener;

@FunctionalInterface
public abstract interface ModifyListener
  extends SWTEventListener
{
  public abstract void modifyText(ModifyEvent paramModifyEvent);
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/events/ModifyListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */