package org.eclipse.swt.custom;

public class ST
{
  public static final int LINE_UP = 16777217;
  public static final int LINE_DOWN = 16777218;
  public static final int LINE_START = 16777223;
  public static final int LINE_END = 16777224;
  public static final int COLUMN_PREVIOUS = 16777219;
  public static final int COLUMN_NEXT = 16777220;
  public static final int PAGE_UP = 16777221;
  public static final int PAGE_DOWN = 16777222;
  public static final int WORD_PREVIOUS = 17039363;
  public static final int WORD_NEXT = 17039364;
  public static final int TEXT_START = 17039367;
  public static final int TEXT_END = 17039368;
  public static final int WINDOW_START = 17039365;
  public static final int WINDOW_END = 17039366;
  public static final int SELECT_ALL = 262209;
  public static final int SELECT_LINE_UP = 16908289;
  public static final int SELECT_LINE_DOWN = 16908290;
  public static final int SELECT_LINE_START = 16908295;
  public static final int SELECT_LINE_END = 16908296;
  public static final int SELECT_COLUMN_PREVIOUS = 16908291;
  public static final int SELECT_COLUMN_NEXT = 16908292;
  public static final int SELECT_PAGE_UP = 16908293;
  public static final int SELECT_PAGE_DOWN = 16908294;
  public static final int SELECT_WORD_PREVIOUS = 17170435;
  public static final int SELECT_WORD_NEXT = 17170436;
  public static final int SELECT_TEXT_START = 17170439;
  public static final int SELECT_TEXT_END = 17170440;
  public static final int SELECT_WINDOW_START = 17170437;
  public static final int SELECT_WINDOW_END = 17170438;
  public static final int CUT = 131199;
  public static final int COPY = 17039369;
  public static final int PASTE = 16908297;
  public static final int DELETE_PREVIOUS = 8;
  public static final int DELETE_NEXT = 127;
  public static final int DELETE_WORD_PREVIOUS = 262152;
  public static final int DELETE_WORD_NEXT = 262271;
  public static final int TOGGLE_OVERWRITE = 16777225;
  public static final int TOGGLE_BLOCKSELECTION = 16777226;
  public static final int BULLET_DOT = 1;
  public static final int BULLET_NUMBER = 2;
  public static final int BULLET_LETTER_LOWER = 4;
  public static final int BULLET_LETTER_UPPER = 8;
  public static final int BULLET_TEXT = 16;
  public static final int BULLET_CUSTOM = 32;
  public static final int ExtendedModify = 3000;
  public static final int LineGetBackground = 3001;
  public static final int LineGetStyle = 3002;
  public static final int TextChanging = 3003;
  public static final int TextSet = 3004;
  public static final int VerifyKey = 3005;
  public static final int TextChanged = 3006;
  public static final int LineGetSegments = 3007;
  public static final int PaintObject = 3008;
  public static final int WordNext = 3009;
  public static final int WordPrevious = 3010;
  public static final int CaretMoved = 3011;
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/custom/ST.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */