/*     */ package org.eclipse.swt.custom;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StyledTextPrintOptions
/*     */ {
/*     */   public static final String PAGE_TAG = "<page>";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String SEPARATOR = "\t";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  56 */   public String header = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  67 */   public String footer = null;
/*     */   
/*     */ 
/*     */ 
/*  71 */   public String jobName = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  76 */   public boolean printTextForeground = false;
/*     */   
/*     */ 
/*     */ 
/*  80 */   public boolean printTextBackground = false;
/*     */   
/*     */ 
/*     */ 
/*  84 */   public boolean printTextFontStyle = false;
/*     */   
/*     */ 
/*     */ 
/*  88 */   public boolean printLineBackground = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  95 */   public boolean printLineNumbers = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 102 */   public String[] lineLabels = null;
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/custom/StyledTextPrintOptions.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */