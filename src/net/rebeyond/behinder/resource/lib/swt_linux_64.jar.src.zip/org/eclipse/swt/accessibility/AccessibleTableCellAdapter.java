package org.eclipse.swt.accessibility;

public class AccessibleTableCellAdapter
  implements AccessibleTableCellListener
{
  public void getColumnSpan(AccessibleTableCellEvent e) {}
  
  public void getColumnHeaders(AccessibleTableCellEvent e) {}
  
  public void getColumnIndex(AccessibleTableCellEvent e) {}
  
  public void getRowSpan(AccessibleTableCellEvent e) {}
  
  public void getRowHeaders(AccessibleTableCellEvent e) {}
  
  public void getRowIndex(AccessibleTableCellEvent e) {}
  
  public void getTable(AccessibleTableCellEvent e) {}
  
  public void isSelected(AccessibleTableCellEvent e) {}
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/accessibility/AccessibleTableCellAdapter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */