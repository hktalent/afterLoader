/*     */ package org.eclipse.swt.graphics;
/*     */ 
/*     */ import org.eclipse.swt.SWT;
/*     */ import org.eclipse.swt.internal.DPIUtil;
/*     */ import org.eclipse.swt.internal.cairo.Cairo;
/*     */ import org.eclipse.swt.internal.gtk.GDK;
/*     */ import org.eclipse.swt.internal.gtk.GTK;
/*     */ import org.eclipse.swt.internal.gtk.GdkRectangle;
/*     */ import org.eclipse.swt.internal.gtk.OS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Region
/*     */   extends Resource
/*     */ {
/*     */   public long handle;
/*     */   
/*     */   public Region()
/*     */   {
/*  60 */     this(null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Region(Device device)
/*     */   {
/*  83 */     super(device);
/*  84 */     this.handle = GDK.gdk_region_new();
/*  85 */     if (this.handle == 0L) SWT.error(2);
/*  86 */     init();
/*     */   }
/*     */   
/*     */   Region(Device device, long handle) {
/*  90 */     super(device);
/*  91 */     this.handle = handle;
/*     */   }
/*     */   
/*     */   static long gdk_region_polygon(int[] pointArray, int npoints, int fill_rule) {
/*  95 */     if (!GTK.GTK3) {
/*  96 */       return GDK.gdk_region_polygon(pointArray, npoints, fill_rule);
/*     */     }
/*     */     
/*  99 */     int minX = pointArray[0];int maxX = minX;
/* 100 */     int minY = pointArray[1];int maxY = minY;
/* 101 */     int count = npoints * 2;
/* 102 */     for (int i = 2; i < count; i += 2) {
/* 103 */       int x = pointArray[i];int y = pointArray[(i + 1)];
/* 104 */       if (x < minX) minX = x;
/* 105 */       if (x > maxX) maxX = x;
/* 106 */       if (y < minY) minY = y;
/* 107 */       if (y > maxY) maxY = y;
/*     */     }
/* 109 */     long surface = Cairo.cairo_image_surface_create(0, maxX - minX, maxY - minY);
/* 110 */     if (surface == 0L) SWT.error(2);
/* 111 */     long cairo = Cairo.cairo_create(surface);
/* 112 */     if (cairo == 0L) SWT.error(2);
/* 113 */     Cairo.cairo_move_to(cairo, pointArray[0] - minX, pointArray[1] - minY);
/* 114 */     for (int i = 2; i < count; i += 2) {
/* 115 */       Cairo.cairo_line_to(cairo, pointArray[i] - minX, pointArray[(i + 1)] - minY);
/*     */     }
/* 117 */     Cairo.cairo_close_path(cairo);
/* 118 */     Cairo.cairo_set_source_rgb(cairo, 1.0D, 1.0D, 1.0D);
/* 119 */     int cairo_rule = 0;
/* 120 */     if (fill_rule == 0) {
/* 121 */       cairo_rule = 1;
/*     */     }
/* 123 */     Cairo.cairo_set_fill_rule(cairo, cairo_rule);
/* 124 */     Cairo.cairo_fill(cairo);
/* 125 */     Cairo.cairo_destroy(cairo);
/* 126 */     long polyRgn = GDK.gdk_cairo_region_create_from_surface(surface);
/* 127 */     GDK.gdk_region_offset(polyRgn, minX, minY);
/* 128 */     Cairo.cairo_surface_destroy(surface);
/* 129 */     return polyRgn;
/*     */   }
/*     */   
/*     */   static void gdk_region_get_rectangles(long region, long[] rectangles, int[] n_rectangles) {
/* 133 */     if (!GTK.GTK3) {
/* 134 */       GDK.gdk_region_get_rectangles(region, rectangles, n_rectangles);
/* 135 */       return;
/*     */     }
/* 137 */     int num = Cairo.cairo_region_num_rectangles(region);
/* 138 */     if (n_rectangles != null) n_rectangles[0] = num;
/* 139 */     rectangles[0] = OS.g_malloc(GdkRectangle.sizeof * num);
/* 140 */     for (int n = 0; n < num; n++) {
/* 141 */       Cairo.cairo_region_get_rectangle(region, n, rectangles[0] + n * GdkRectangle.sizeof);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void add(int[] pointArray)
/*     */   {
/* 162 */     if (isDisposed()) SWT.error(44);
/* 163 */     if (pointArray == null) SWT.error(4);
/* 164 */     addInPixels(DPIUtil.autoScaleUp(pointArray));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   void addInPixels(int[] pointArray)
/*     */   {
/* 172 */     if (pointArray.length < 6) return;
/* 173 */     long polyRgn = gdk_region_polygon(pointArray, pointArray.length / 2, 0);
/* 174 */     GDK.gdk_region_union(this.handle, polyRgn);
/* 175 */     GDK.gdk_region_destroy(polyRgn);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void add(Rectangle rect)
/*     */   {
/* 193 */     if (isDisposed()) SWT.error(44);
/* 194 */     if (rect == null) SWT.error(4);
/* 195 */     addInPixels(DPIUtil.autoScaleUp(rect));
/*     */   }
/*     */   
/* 198 */   void addInPixels(Rectangle rect) { addInPixels(rect.x, rect.y, rect.width, rect.height); }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void add(int x, int y, int width, int height)
/*     */   {
/* 220 */     if (isDisposed()) SWT.error(44);
/* 221 */     if ((width < 0) || (height < 0)) SWT.error(5);
/* 222 */     add(new Rectangle(x, y, width, height));
/*     */   }
/*     */   
/* 225 */   void addInPixels(int x, int y, int width, int height) { GdkRectangle gdkRect = new GdkRectangle();
/* 226 */     gdkRect.x = x;
/* 227 */     gdkRect.y = y;
/* 228 */     gdkRect.width = width;
/* 229 */     gdkRect.height = height;
/* 230 */     GDK.gdk_region_union_with_rect(this.handle, gdkRect);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void add(Region region)
/*     */   {
/* 249 */     if (isDisposed()) SWT.error(44);
/* 250 */     if (region == null) SWT.error(4);
/* 251 */     if (region.isDisposed()) SWT.error(5);
/* 252 */     GDK.gdk_region_union(this.handle, region.handle);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean contains(int x, int y)
/*     */   {
/* 269 */     if (isDisposed()) SWT.error(44);
/* 270 */     return contains(new Point(x, y));
/*     */   }
/*     */   
/* 273 */   boolean containsInPixels(int x, int y) { return GDK.gdk_region_point_in(this.handle, x, y); }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean contains(Point pt)
/*     */   {
/* 292 */     if (isDisposed()) SWT.error(44);
/* 293 */     return containsInPixels(DPIUtil.autoScaleUp(pt));
/*     */   }
/*     */   
/* 296 */   boolean containsInPixels(Point pt) { if (pt == null) SWT.error(4);
/* 297 */     return containsInPixels(pt.x, pt.y);
/*     */   }
/*     */   
/*     */   void destroy()
/*     */   {
/* 302 */     GDK.gdk_region_destroy(this.handle);
/* 303 */     this.handle = 0L;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object object)
/*     */   {
/* 318 */     if (this == object) return true;
/* 319 */     if (!(object instanceof Region)) return false;
/* 320 */     Region region = (Region)object;
/* 321 */     return this.handle == region.handle;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Rectangle getBounds()
/*     */   {
/* 338 */     if (isDisposed()) SWT.error(44);
/* 339 */     return DPIUtil.autoScaleDown(getBoundsInPixels());
/*     */   }
/*     */   
/* 342 */   Rectangle getBoundsInPixels() { GdkRectangle gdkRect = new GdkRectangle();
/* 343 */     GDK.gdk_region_get_clipbox(this.handle, gdkRect);
/* 344 */     return new Rectangle(gdkRect.x, gdkRect.y, gdkRect.width, gdkRect.height);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Region gtk_new(Device device, long handle)
/*     */   {
/* 364 */     return new Region(device, handle);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 379 */     return (int)this.handle;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void intersect(Rectangle rect)
/*     */   {
/* 399 */     if (isDisposed()) SWT.error(44);
/* 400 */     if (rect == null) SWT.error(4);
/* 401 */     intersectInPixels(DPIUtil.autoScaleUp(rect));
/*     */   }
/*     */   
/*     */   void intersectInPixels(Rectangle rect) {
/* 405 */     intersectInPixels(rect.x, rect.y, rect.width, rect.height);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void intersect(int x, int y, int width, int height)
/*     */   {
/* 427 */     if (isDisposed()) SWT.error(44);
/* 428 */     if ((width < 0) || (height < 0)) SWT.error(5);
/* 429 */     intersect(new Rectangle(x, y, width, height));
/*     */   }
/*     */   
/*     */   void intersectInPixels(int x, int y, int width, int height) {
/* 433 */     GdkRectangle gdkRect = new GdkRectangle();
/* 434 */     gdkRect.x = x;
/* 435 */     gdkRect.y = y;
/* 436 */     gdkRect.width = width;
/* 437 */     gdkRect.height = height;
/* 438 */     long rectRgn = GDK.gdk_region_rectangle(gdkRect);
/* 439 */     GDK.gdk_region_intersect(this.handle, rectRgn);
/* 440 */     GDK.gdk_region_destroy(rectRgn);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void intersect(Region region)
/*     */   {
/* 461 */     if (isDisposed()) SWT.error(44);
/* 462 */     if (region == null) SWT.error(4);
/* 463 */     if (region.isDisposed()) SWT.error(5);
/* 464 */     GDK.gdk_region_intersect(this.handle, region.handle);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean intersects(int x, int y, int width, int height)
/*     */   {
/* 485 */     if (isDisposed()) SWT.error(44);
/* 486 */     return intersects(new Rectangle(x, y, width, height));
/*     */   }
/*     */   
/*     */   boolean intersectsInPixels(int x, int y, int width, int height) {
/* 490 */     GdkRectangle gdkRect = new GdkRectangle();
/* 491 */     gdkRect.x = x;
/* 492 */     gdkRect.y = y;
/* 493 */     gdkRect.width = width;
/* 494 */     gdkRect.height = height;
/* 495 */     return GDK.gdk_region_rect_in(this.handle, gdkRect) != 1L;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean intersects(Rectangle rect)
/*     */   {
/* 515 */     if (rect == null) SWT.error(4);
/* 516 */     if (isDisposed()) SWT.error(44);
/* 517 */     return intersectsInPixels(DPIUtil.autoScaleUp(rect));
/*     */   }
/*     */   
/*     */   boolean intersectsInPixels(Rectangle rect) {
/* 521 */     return intersectsInPixels(rect.x, rect.y, rect.width, rect.height);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isDisposed()
/*     */   {
/* 536 */     return this.handle == 0L;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isEmpty()
/*     */   {
/* 551 */     if (isDisposed()) SWT.error(44);
/* 552 */     return GDK.gdk_region_empty(this.handle);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void subtract(int[] pointArray)
/*     */   {
/* 571 */     if (isDisposed()) SWT.error(44);
/* 572 */     if (pointArray == null) SWT.error(4);
/* 573 */     subtractInPixels(DPIUtil.autoScaleUp(pointArray));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void subtractInPixels(int[] pointArray)
/*     */   {
/* 582 */     if (pointArray.length < 6) return;
/* 583 */     long polyRgn = gdk_region_polygon(pointArray, pointArray.length / 2, 0);
/* 584 */     GDK.gdk_region_subtract(this.handle, polyRgn);
/* 585 */     GDK.gdk_region_destroy(polyRgn);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void subtract(Rectangle rect)
/*     */   {
/* 604 */     if (isDisposed()) SWT.error(44);
/* 605 */     if (rect == null) SWT.error(4);
/* 606 */     subtractInPixels(DPIUtil.autoScaleUp(rect));
/*     */   }
/*     */   
/*     */   void subtractInPixels(Rectangle rect) {
/* 610 */     subtractInPixels(rect.x, rect.y, rect.width, rect.height);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void subtract(int x, int y, int width, int height)
/*     */   {
/* 632 */     if (isDisposed()) SWT.error(44);
/* 633 */     if ((width < 0) || (height < 0)) SWT.error(5);
/* 634 */     subtract(new Rectangle(x, y, width, height));
/*     */   }
/*     */   
/*     */   void subtractInPixels(int x, int y, int width, int height) {
/* 638 */     GdkRectangle gdkRect = new GdkRectangle();
/* 639 */     gdkRect.x = x;
/* 640 */     gdkRect.y = y;
/* 641 */     gdkRect.width = width;
/* 642 */     gdkRect.height = height;
/* 643 */     long rectRgn = GDK.gdk_region_rectangle(gdkRect);
/* 644 */     GDK.gdk_region_subtract(this.handle, rectRgn);
/* 645 */     GDK.gdk_region_destroy(rectRgn);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void subtract(Region region)
/*     */   {
/* 666 */     if (isDisposed()) SWT.error(44);
/* 667 */     if (region == null) SWT.error(4);
/* 668 */     if (region.isDisposed()) SWT.error(5);
/* 669 */     GDK.gdk_region_subtract(this.handle, region.handle);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void translate(int x, int y)
/*     */   {
/* 686 */     if (isDisposed()) SWT.error(44);
/* 687 */     translate(new Point(x, y));
/*     */   }
/*     */   
/*     */   void translateInPixels(int x, int y) {
/* 691 */     GDK.gdk_region_offset(this.handle, x, y);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void translate(Point pt)
/*     */   {
/* 710 */     if (isDisposed()) SWT.error(44);
/* 711 */     if (pt == null) SWT.error(4);
/* 712 */     pt = DPIUtil.autoScaleUp(pt);
/* 713 */     translateInPixels(pt.x, pt.y);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 724 */     if (isDisposed()) return "Region {*DISPOSED*}";
/* 725 */     return "Region {" + this.handle + "}";
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/graphics/Region.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */