package org.eclipse.swt.internal.accessibility.gtk;

public class AtkSelectionIface
{
  public long add_selection;
  public long clear_selection;
  public long ref_selection;
  public long get_selection_count;
  public long is_child_selected;
  public long remove_selection;
  public long select_all_selection;
  public long selection_changed;
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/internal/accessibility/gtk/AtkSelectionIface.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */