/*     */ package org.eclipse.swt.widgets;
/*     */ 
/*     */ import org.eclipse.swt.graphics.Rectangle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Monitor
/*     */ {
/*     */   long handle;
/*     */   int x;
/*     */   int y;
/*     */   int width;
/*     */   int height;
/*     */   int clientX;
/*     */   int clientY;
/*     */   int clientWidth;
/*     */   int clientHeight;
/*     */   int zoom;
/*     */   
/*     */   public boolean equals(Object object)
/*     */   {
/*  48 */     if (object == this) return true;
/*  49 */     if (!(object instanceof Monitor)) return false;
/*  50 */     Monitor monitor = (Monitor)object;
/*  51 */     return this.handle == monitor.handle;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Rectangle getBounds()
/*     */   {
/*  62 */     return new Rectangle(this.x, this.y, this.width, this.height);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Rectangle getClientArea()
/*     */   {
/*  72 */     return new Rectangle(this.clientX, this.clientY, this.clientWidth, this.clientHeight);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getZoom()
/*     */   {
/*  83 */     return this.zoom;
/*     */   }
/*     */   
/*     */   void setBounds(Rectangle rect) {
/*  87 */     this.x = rect.x;
/*  88 */     this.y = rect.y;
/*  89 */     this.width = rect.width;
/*  90 */     this.height = rect.height;
/*     */   }
/*     */   
/*     */   void setClientArea(Rectangle rect) {
/*  94 */     this.clientX = rect.x;
/*  95 */     this.clientY = rect.y;
/*  96 */     this.clientWidth = rect.width;
/*  97 */     this.clientHeight = rect.height;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 113 */     return (int)this.handle;
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/widgets/Monitor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */