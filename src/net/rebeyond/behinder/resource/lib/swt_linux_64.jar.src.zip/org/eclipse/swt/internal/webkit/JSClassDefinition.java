/*    */ package org.eclipse.swt.internal.webkit;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JSClassDefinition
/*    */ {
/*    */   public int version;
/*    */   
/*    */ 
/*    */   public int attributes;
/*    */   
/*    */ 
/*    */   public long className;
/*    */   
/*    */ 
/*    */   public long parentClass;
/*    */   
/*    */ 
/*    */   public long staticValues;
/*    */   
/*    */ 
/*    */   public long staticFunctions;
/*    */   
/*    */ 
/*    */   public long initialize;
/*    */   
/*    */ 
/*    */   public long finalize;
/*    */   
/*    */ 
/*    */   public long hasProperty;
/*    */   
/*    */ 
/*    */   public long getProperty;
/*    */   
/*    */ 
/*    */   public long setProperty;
/*    */   
/*    */ 
/*    */   public long deleteProperty;
/*    */   
/*    */   public long getPropertyNames;
/*    */   
/*    */   public long callAsFunction;
/*    */   
/*    */   public long callAsConstructor;
/*    */   
/*    */   public long hasInstance;
/*    */   
/*    */   public long convertToType;
/*    */   
/* 52 */   public static final int sizeof = ;
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/internal/webkit/JSClassDefinition.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */