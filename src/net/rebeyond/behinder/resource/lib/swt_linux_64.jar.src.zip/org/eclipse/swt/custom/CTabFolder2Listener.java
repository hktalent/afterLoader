/*     */ package org.eclipse.swt.custom;
/*     */ 
/*     */ import java.util.function.Consumer;
/*     */ import org.eclipse.swt.internal.SWTEventListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract interface CTabFolder2Listener
/*     */   extends SWTEventListener
/*     */ {
/*     */   public abstract void close(CTabFolderEvent paramCTabFolderEvent);
/*     */   
/*     */   public abstract void minimize(CTabFolderEvent paramCTabFolderEvent);
/*     */   
/*     */   public abstract void maximize(CTabFolderEvent paramCTabFolderEvent);
/*     */   
/*     */   public abstract void restore(CTabFolderEvent paramCTabFolderEvent);
/*     */   
/*     */   public abstract void showList(CTabFolderEvent paramCTabFolderEvent);
/*     */   
/*     */   public static CTabFolder2Listener closeAdapter(Consumer<CTabFolderEvent> c)
/*     */   {
/* 124 */     new CTabFolder2Adapter()
/*     */     {
/*     */       public void close(CTabFolderEvent e) {
/* 127 */         this.val$c.accept(e);
/*     */       }
/*     */     };
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static CTabFolder2Listener minimizeAdapter(Consumer<CTabFolderEvent> c)
/*     */   {
/* 141 */     new CTabFolder2Adapter()
/*     */     {
/*     */       public void minimize(CTabFolderEvent e) {
/* 144 */         this.val$c.accept(e);
/*     */       }
/*     */     };
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static CTabFolder2Listener maximizeAdapter(Consumer<CTabFolderEvent> c)
/*     */   {
/* 158 */     new CTabFolder2Adapter()
/*     */     {
/*     */       public void maximize(CTabFolderEvent e) {
/* 161 */         this.val$c.accept(e);
/*     */       }
/*     */     };
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static CTabFolder2Listener restoreAdapter(Consumer<CTabFolderEvent> c)
/*     */   {
/* 175 */     new CTabFolder2Adapter()
/*     */     {
/*     */       public void restore(CTabFolderEvent e) {
/* 178 */         this.val$c.accept(e);
/*     */       }
/*     */     };
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static CTabFolder2Listener showListAdapter(Consumer<CTabFolderEvent> c)
/*     */   {
/* 192 */     new CTabFolder2Adapter()
/*     */     {
/*     */       public void showList(CTabFolderEvent e) {
/* 195 */         this.val$c.accept(e);
/*     */       }
/*     */     };
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/custom/CTabFolder2Listener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */