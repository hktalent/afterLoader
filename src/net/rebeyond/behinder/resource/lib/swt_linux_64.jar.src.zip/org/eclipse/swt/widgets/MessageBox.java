/*     */ package org.eclipse.swt.widgets;
/*     */ 
/*     */ import org.eclipse.swt.SWT;
/*     */ import org.eclipse.swt.internal.Converter;
/*     */ import org.eclipse.swt.internal.gtk.GDK;
/*     */ import org.eclipse.swt.internal.gtk.GTK;
/*     */ import org.eclipse.swt.internal.gtk.OS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MessageBox
/*     */   extends Dialog
/*     */ {
/*  43 */   String message = "";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   long handle;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MessageBox(Shell parent)
/*     */   {
/*  59 */     this(parent, 65570);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MessageBox(Shell parent, int style)
/*     */   {
/*  99 */     super(parent, checkStyle(parent, checkStyle(style)));
/* 100 */     checkSubclass();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getMessage()
/*     */   {
/* 111 */     return this.message;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMessage(String string)
/*     */   {
/* 126 */     if (string == null) error(4);
/* 127 */     this.message = string;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int open()
/*     */   {
/* 143 */     long parentHandle = this.parent != null ? this.parent.topHandle() : 0L;
/* 144 */     int dialogFlags = 2;
/* 145 */     if ((this.style & 0x38000) != 0) {
/* 146 */       dialogFlags |= 0x1;
/*     */     }
/* 148 */     int messageType = 0;
/* 149 */     if ((this.style & 0x8) != 0) messageType = 1;
/* 150 */     if ((this.style & 0x4) != 0) messageType = 2;
/* 151 */     if ((this.style & 0x1) != 0) { messageType = 3;
/*     */     }
/* 153 */     byte[] format = Converter.wcsToMbcs("%s", true);
/* 154 */     byte[] buffer = Converter.wcsToMbcs(this.message, true);
/* 155 */     this.handle = GTK.gtk_message_dialog_new(parentHandle, dialogFlags, messageType, 0, format, buffer);
/* 156 */     if (this.handle == 0L) error(2);
/* 157 */     if (parentHandle != 0L) {
/* 158 */       long pixbufs = GTK.gtk_window_get_icon_list(parentHandle);
/* 159 */       if (pixbufs != 0L) {
/* 160 */         GTK.gtk_window_set_icon_list(this.handle, pixbufs);
/* 161 */         OS.g_list_free(pixbufs);
/*     */       }
/*     */     }
/* 164 */     Display display = this.parent != null ? this.parent.getDisplay() : Display.getCurrent();
/* 165 */     createButtons(display.getDismissalAlignment());
/* 166 */     buffer = Converter.wcsToMbcs(this.title, true);
/* 167 */     GTK.gtk_window_set_title(this.handle, buffer);
/* 168 */     display.addIdleProc();
/* 169 */     Dialog oldModal = null;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 175 */     long group = GTK.gtk_window_get_group(0L);
/* 176 */     GTK.gtk_window_group_add_window(group, this.handle);
/*     */     
/* 178 */     if (GTK.gtk_window_get_modal(this.handle)) {
/* 179 */       oldModal = display.getModalDialog();
/* 180 */       display.setModalDialog(this);
/*     */     }
/* 182 */     int signalId = 0;
/* 183 */     long hookId = 0L;
/* 184 */     if ((this.style & 0x4000000) != 0) {
/* 185 */       signalId = OS.g_signal_lookup(OS.map, GTK.GTK_TYPE_WIDGET());
/* 186 */       hookId = OS.g_signal_add_emission_hook(signalId, 0, display.emissionProc, this.handle, 0L);
/*     */     }
/* 188 */     display.sendPreExternalEventDispatchEvent();
/* 189 */     int response = GTK.gtk_dialog_run(this.handle);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 196 */     GDK.gdk_threads_leave();
/* 197 */     display.sendPostExternalEventDispatchEvent();
/* 198 */     if ((this.style & 0x4000000) != 0) {
/* 199 */       OS.g_signal_remove_emission_hook(signalId, hookId);
/*     */     }
/* 201 */     if (GTK.gtk_window_get_modal(this.handle)) {
/* 202 */       display.setModalDialog(oldModal);
/*     */     }
/* 204 */     display.removeIdleProc();
/* 205 */     GTK.gtk_widget_destroy(this.handle);
/* 206 */     return response;
/*     */   }
/*     */   
/*     */   private void createButtons(int alignment) {
/* 210 */     if (alignment == 16384) {
/* 211 */       if ((this.style & 0x20) != 0) GTK.gtk_dialog_add_button(this.handle, Converter.wcsToMbcs("gtk-ok", true), 32);
/* 212 */       if ((this.style & 0x200) != 0) GTK.gtk_dialog_add_button(this.handle, Converter.wcsToMbcs(SWT.getMessage("SWT_Abort"), true), 512);
/* 213 */       if ((this.style & 0x400) != 0) GTK.gtk_dialog_add_button(this.handle, Converter.wcsToMbcs(SWT.getMessage("SWT_Retry"), true), 1024);
/* 214 */       if ((this.style & 0x40) != 0) GTK.gtk_dialog_add_button(this.handle, Converter.wcsToMbcs("gtk-yes", true), 64);
/* 215 */       if ((this.style & 0x80) != 0) GTK.gtk_dialog_add_button(this.handle, Converter.wcsToMbcs("gtk-no", true), 128);
/* 216 */       if ((this.style & 0x800) != 0) GTK.gtk_dialog_add_button(this.handle, Converter.wcsToMbcs(SWT.getMessage("SWT_Ignore"), true), 2048);
/* 217 */       if ((this.style & 0x100) != 0) GTK.gtk_dialog_add_button(this.handle, Converter.wcsToMbcs("gtk-cancel", true), 256);
/*     */     } else {
/* 219 */       if ((this.style & 0x100) != 0) GTK.gtk_dialog_add_button(this.handle, Converter.wcsToMbcs("gtk-cancel", true), 256);
/* 220 */       if ((this.style & 0x20) != 0) GTK.gtk_dialog_add_button(this.handle, Converter.wcsToMbcs("gtk-ok", true), 32);
/* 221 */       if ((this.style & 0x80) != 0) GTK.gtk_dialog_add_button(this.handle, Converter.wcsToMbcs("gtk-no", true), 128);
/* 222 */       if ((this.style & 0x40) != 0) GTK.gtk_dialog_add_button(this.handle, Converter.wcsToMbcs("gtk-yes", true), 64);
/* 223 */       if ((this.style & 0x800) != 0) GTK.gtk_dialog_add_button(this.handle, Converter.wcsToMbcs(SWT.getMessage("SWT_Ignore"), true), 2048);
/* 224 */       if ((this.style & 0x400) != 0) GTK.gtk_dialog_add_button(this.handle, Converter.wcsToMbcs(SWT.getMessage("SWT_Retry"), true), 1024);
/* 225 */       if ((this.style & 0x200) != 0) GTK.gtk_dialog_add_button(this.handle, Converter.wcsToMbcs(SWT.getMessage("SWT_Abort"), true), 512);
/*     */     }
/*     */   }
/*     */   
/*     */   private static int checkStyle(int style) {
/* 230 */     int mask = 4064;
/* 231 */     int bits = style & mask;
/* 232 */     if ((bits == 32) || (bits == 256) || (bits == 288)) return style;
/* 233 */     if ((bits == 64) || (bits == 128) || (bits == 192) || (bits == 448)) return style;
/* 234 */     if ((bits == 1280) || (bits == 3584)) return style;
/* 235 */     style = style & (mask ^ 0xFFFFFFFF) | 0x20;
/* 236 */     return style;
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/widgets/MessageBox.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */