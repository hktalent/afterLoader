/*     */ package org.eclipse.swt.browser;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.eclipse.swt.SWTException;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.swt.widgets.Event;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class WebBrowser
/*     */ {
/*     */   Browser browser;
/*  21 */   Map<Integer, BrowserFunction> functions = new HashMap();
/*  22 */   AuthenticationListener[] authenticationListeners = new AuthenticationListener[0];
/*  23 */   CloseWindowListener[] closeWindowListeners = new CloseWindowListener[0];
/*  24 */   LocationListener[] locationListeners = new LocationListener[0];
/*  25 */   OpenWindowListener[] openWindowListeners = new OpenWindowListener[0];
/*  26 */   ProgressListener[] progressListeners = new ProgressListener[0];
/*  27 */   StatusTextListener[] statusTextListeners = new StatusTextListener[0];
/*  28 */   TitleListener[] titleListeners = new TitleListener[0];
/*  29 */   VisibilityWindowListener[] visibilityWindowListeners = new VisibilityWindowListener[0];
/*  30 */   boolean jsEnabledOnNextPage = true; boolean jsEnabled = true;
/*  31 */   int nextFunctionIndex = 1;
/*     */   
/*     */   Object evaluateResult;
/*     */   
/*     */   static final String ERROR_ID = "org.eclipse.swt.browser.error";
/*     */   static final String EXECUTE_ID = "SWTExecuteTemporaryFunction";
/*  37 */   static List<String[]> NativePendingCookies = new ArrayList();
/*     */   static String CookieName;
/*     */   static String CookieValue;
/*     */   static String CookieUrl;
/*     */   static boolean CookieResult;
/*     */   static Runnable NativeClearSessions;
/*     */   static Runnable NativeGetCookie;
/*     */   static Runnable NativeSetCookie;
/*  45 */   static final int[][] KeyTable = { { 18, 65536 }, { 16, 131072 }, { 17, 262144 }, { 224, 4194304 }, { 65, 97 }, { 66, 98 }, { 67, 99 }, { 68, 100 }, { 69, 101 }, { 70, 102 }, { 71, 103 }, { 72, 104 }, { 73, 105 }, { 74, 106 }, { 75, 107 }, { 76, 108 }, { 77, 109 }, { 78, 110 }, { 79, 111 }, { 80, 112 }, { 81, 113 }, { 82, 114 }, { 83, 115 }, { 84, 116 }, { 85, 117 }, { 86, 118 }, { 87, 119 }, { 88, 120 }, { 89, 121 }, { 90, 122 }, { 48, 48 }, { 49, 49 }, { 50, 50 }, { 51, 51 }, { 52, 52 }, { 53, 53 }, { 54, 54 }, { 55, 55 }, { 56, 56 }, { 57, 57 }, { 32, 32 }, { 59, 59 }, { 61, 61 }, { 188, 44 }, { 190, 46 }, { 191, 47 }, { 219, 91 }, { 221, 93 }, { 222, 39 }, { 192, 96 }, { 220, 92 }, { 108, 124 }, { 226, 60 }, { 37, 16777219 }, { 39, 16777220 }, { 38, 16777217 }, { 40, 16777218 }, { 45, 16777225 }, { 36, 16777223 }, { 35, 16777224 }, { 46, 127 }, { 33, 16777221 }, { 34, 16777222 }, { 8, 8 }, { 13, 13 }, { 9, 9 }, { 27, 27 }, { 12, 127 }, { 112, 16777226 }, { 113, 16777227 }, { 114, 16777228 }, { 115, 16777229 }, { 116, 16777230 }, { 117, 16777231 }, { 118, 16777232 }, { 119, 16777233 }, { 120, 16777234 }, { 121, 16777235 }, { 122, 16777236 }, { 123, 16777237 }, { 124, 16777238 }, { 125, 16777239 }, { 126, 16777240 }, { 127, 0 }, { 128, 0 }, { 129, 0 }, { 130, 0 }, { 131, 0 }, { 132, 0 }, { 133, 0 }, { 134, 0 }, { 135, 0 }, { 96, 16777264 }, { 97, 16777265 }, { 98, 16777266 }, { 99, 16777267 }, { 100, 16777268 }, { 101, 16777269 }, { 102, 16777270 }, { 103, 16777271 }, { 104, 16777272 }, { 105, 16777273 }, { 14, 16777296 }, { 107, 16777259 }, { 109, 16777261 }, { 106, 16777258 }, { 111, 16777263 }, { 110, 16777262 }, { 20, 16777298 }, { 144, 16777299 }, { 145, 16777300 }, { 44, 16777303 }, { 6, 16777297 }, { 19, 16777301 }, { 3, 16777302 }, { 186, 59 }, { 187, 61 }, { 189, 45 } };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public class EvaluateFunction
/*     */     extends BrowserFunction
/*     */   {
/*     */     public EvaluateFunction(Browser browser, String name)
/*     */     {
/* 183 */       super(name, true, new String[0], false);
/*     */     }
/*     */     
/*     */     public Object function(Object[] arguments) {
/* 187 */       if ((arguments[0] instanceof String)) {
/* 188 */         String string = (String)arguments[0];
/* 189 */         if (string.startsWith("org.eclipse.swt.browser.error")) {
/* 190 */           String errorString = WebBrowser.ExtractError(string);
/* 191 */           if (errorString.length() > 0) {
/* 192 */             WebBrowser.this.evaluateResult = new SWTException(50, errorString);
/*     */           } else {
/* 194 */             WebBrowser.this.evaluateResult = new SWTException(50);
/*     */           }
/* 196 */           return null;
/*     */         }
/*     */       }
/* 199 */       WebBrowser.this.evaluateResult = arguments[0];
/* 200 */       return null;
/*     */     }
/*     */   }
/*     */   
/*     */   public void addAuthenticationListener(AuthenticationListener listener) {
/* 205 */     AuthenticationListener[] newAuthenticationListeners = new AuthenticationListener[this.authenticationListeners.length + 1];
/* 206 */     System.arraycopy(this.authenticationListeners, 0, newAuthenticationListeners, 0, this.authenticationListeners.length);
/* 207 */     this.authenticationListeners = newAuthenticationListeners;
/* 208 */     this.authenticationListeners[(this.authenticationListeners.length - 1)] = listener;
/*     */   }
/*     */   
/*     */   public void addCloseWindowListener(CloseWindowListener listener) {
/* 212 */     CloseWindowListener[] newCloseWindowListeners = new CloseWindowListener[this.closeWindowListeners.length + 1];
/* 213 */     System.arraycopy(this.closeWindowListeners, 0, newCloseWindowListeners, 0, this.closeWindowListeners.length);
/* 214 */     this.closeWindowListeners = newCloseWindowListeners;
/* 215 */     this.closeWindowListeners[(this.closeWindowListeners.length - 1)] = listener;
/*     */   }
/*     */   
/*     */   public void addLocationListener(LocationListener listener) {
/* 219 */     LocationListener[] newLocationListeners = new LocationListener[this.locationListeners.length + 1];
/* 220 */     System.arraycopy(this.locationListeners, 0, newLocationListeners, 0, this.locationListeners.length);
/* 221 */     this.locationListeners = newLocationListeners;
/* 222 */     this.locationListeners[(this.locationListeners.length - 1)] = listener;
/*     */   }
/*     */   
/*     */   public void addOpenWindowListener(OpenWindowListener listener) {
/* 226 */     OpenWindowListener[] newOpenWindowListeners = new OpenWindowListener[this.openWindowListeners.length + 1];
/* 227 */     System.arraycopy(this.openWindowListeners, 0, newOpenWindowListeners, 0, this.openWindowListeners.length);
/* 228 */     this.openWindowListeners = newOpenWindowListeners;
/* 229 */     this.openWindowListeners[(this.openWindowListeners.length - 1)] = listener;
/*     */   }
/*     */   
/*     */   public void addProgressListener(ProgressListener listener) {
/* 233 */     ProgressListener[] newProgressListeners = new ProgressListener[this.progressListeners.length + 1];
/* 234 */     System.arraycopy(this.progressListeners, 0, newProgressListeners, 0, this.progressListeners.length);
/* 235 */     this.progressListeners = newProgressListeners;
/* 236 */     this.progressListeners[(this.progressListeners.length - 1)] = listener;
/*     */   }
/*     */   
/*     */   public void addStatusTextListener(StatusTextListener listener) {
/* 240 */     StatusTextListener[] newStatusTextListeners = new StatusTextListener[this.statusTextListeners.length + 1];
/* 241 */     System.arraycopy(this.statusTextListeners, 0, newStatusTextListeners, 0, this.statusTextListeners.length);
/* 242 */     this.statusTextListeners = newStatusTextListeners;
/* 243 */     this.statusTextListeners[(this.statusTextListeners.length - 1)] = listener;
/*     */   }
/*     */   
/*     */   public void addTitleListener(TitleListener listener) {
/* 247 */     TitleListener[] newTitleListeners = new TitleListener[this.titleListeners.length + 1];
/* 248 */     System.arraycopy(this.titleListeners, 0, newTitleListeners, 0, this.titleListeners.length);
/* 249 */     this.titleListeners = newTitleListeners;
/* 250 */     this.titleListeners[(this.titleListeners.length - 1)] = listener;
/*     */   }
/*     */   
/*     */   public void addVisibilityWindowListener(VisibilityWindowListener listener) {
/* 254 */     VisibilityWindowListener[] newVisibilityWindowListeners = new VisibilityWindowListener[this.visibilityWindowListeners.length + 1];
/* 255 */     System.arraycopy(this.visibilityWindowListeners, 0, newVisibilityWindowListeners, 0, this.visibilityWindowListeners.length);
/* 256 */     this.visibilityWindowListeners = newVisibilityWindowListeners;
/* 257 */     this.visibilityWindowListeners[(this.visibilityWindowListeners.length - 1)] = listener;
/*     */   }
/*     */   
/*     */   public abstract boolean back();
/*     */   
/*     */   public static void clearSessions() {
/* 263 */     if (NativeClearSessions != null) NativeClearSessions.run();
/*     */   }
/*     */   
/*     */   public static String GetCookie(String name, String url) {
/* 267 */     CookieName = name;CookieUrl = url;CookieValue = null;
/* 268 */     if (NativeGetCookie != null) NativeGetCookie.run();
/* 269 */     String result = CookieValue;
/* 270 */     CookieName = CookieValue = CookieUrl = null;
/* 271 */     return result;
/*     */   }
/*     */   
/*     */   public static boolean SetCookie(String value, String url, boolean addToPending) {
/* 275 */     CookieValue = value;CookieUrl = url;
/* 276 */     CookieResult = false;
/* 277 */     if (NativeSetCookie != null) {
/* 278 */       NativeSetCookie.run();
/*     */     }
/* 280 */     else if ((addToPending) && (NativePendingCookies != null)) {
/* 281 */       NativePendingCookies.add(new String[] { value, url });
/*     */     }
/*     */     
/* 284 */     CookieValue = CookieUrl = null;
/* 285 */     return CookieResult;
/*     */   }
/*     */   
/*     */   static void SetPendingCookies(List<String[]> pendingCookies) {
/* 289 */     for (String[] current : pendingCookies) {
/* 290 */       SetCookie(current[0], current[1], false);
/*     */     }
/*     */   }
/*     */   
/*     */   public abstract void create(Composite paramComposite, int paramInt);
/*     */   
/*     */   static String CreateErrorString(String error) {
/* 297 */     return "org.eclipse.swt.browser.error" + error;
/*     */   }
/*     */   
/*     */   static String ExtractError(String error) {
/* 301 */     return error.substring("org.eclipse.swt.browser.error".length());
/*     */   }
/*     */   
/*     */   public boolean close() {
/* 305 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void createFunction(BrowserFunction function)
/*     */   {
/* 314 */     for (BrowserFunction current : this.functions.values()) {
/* 315 */       if (current.name.equals(function.name)) {
/* 316 */         deregisterFunction(current);
/* 317 */         break;
/*     */       }
/*     */     }
/*     */     
/* 321 */     function.index = getNextFunctionIndex();
/* 322 */     registerFunction(function);
/*     */     
/* 324 */     StringBuilder functionBuffer = new StringBuilder(function.name);
/* 325 */     functionBuffer.append(" = function ");
/* 326 */     functionBuffer.append(function.name);
/* 327 */     functionBuffer.append("() {var result = callJava(");
/* 328 */     functionBuffer.append(function.index);
/* 329 */     functionBuffer.append(",'");
/* 330 */     functionBuffer.append(function.token);
/* 331 */     functionBuffer.append("',Array.prototype.slice.call(arguments)); if (typeof result == 'string' && result.indexOf('");
/* 332 */     functionBuffer.append("org.eclipse.swt.browser.error");
/* 333 */     functionBuffer.append("') == 0) {var error = new Error(result.substring(");
/* 334 */     functionBuffer.append("org.eclipse.swt.browser.error".length());
/* 335 */     functionBuffer.append(")); throw error;} return result;};");
/*     */     
/* 337 */     String javaCallDeclaration = getJavaCallDeclaration();
/*     */     
/* 339 */     StringBuilder buffer = new StringBuilder();
/* 340 */     buffer.append(javaCallDeclaration);
/* 341 */     if (function.top) {
/* 342 */       buffer.append(functionBuffer.toString());
/*     */     }
/*     */     
/* 345 */     buffer.append("var frameIds = null;");
/* 346 */     if (function.frameNames != null) {
/* 347 */       buffer.append("frameIds = {");
/* 348 */       for (int i = 0; i < function.frameNames.length; i++) {
/* 349 */         buffer.append('\'');
/* 350 */         buffer.append(function.frameNames[i]);
/* 351 */         buffer.append("':1,");
/*     */       }
/* 353 */       if (function.frameNames.length > 0) {
/* 354 */         buffer.deleteCharAt(buffer.length() - 1);
/*     */       }
/* 356 */       buffer.append("};");
/*     */     }
/*     */     
/* 359 */     buffer.append("for (var i = 0; i < frames.length; i++) {try {if (!frameIds || (frames[i].name && frameIds[frames[i].name])) {");
/* 360 */     buffer.append("if (!frames[i].callJava) {frames[i].callJava = window.callJava;} frames[i].");
/* 361 */     buffer.append(functionBuffer.toString());
/* 362 */     buffer.append("}} catch(e) {}};");
/*     */     
/* 364 */     function.functionString = buffer.toString();
/* 365 */     nonBlockingExecute(function.functionString);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   String getJavaCallDeclaration()
/*     */   {
/* 373 */     return "if (!window.callJava) {\n\t\twindow.callJava = function callJava(index, token, args) {\n\t\t\treturn external.callJava(index,token,args);\n\t\t}\n};\n";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   void deregisterFunction(BrowserFunction function)
/*     */   {
/* 381 */     this.functions.remove(Integer.valueOf(function.index));
/*     */   }
/*     */   
/*     */   public void destroyFunction(BrowserFunction function) {
/* 385 */     String deleteString = getDeleteFunctionString(function.name);
/* 386 */     StringBuilder buffer = new StringBuilder("for (var i = 0; i < frames.length; i++) {try {frames[i].eval(\"");
/* 387 */     buffer.append(deleteString);
/* 388 */     buffer.append("\");} catch (e) {}}");
/* 389 */     nonBlockingExecute(buffer.toString());
/* 390 */     nonBlockingExecute(deleteString);
/* 391 */     deregisterFunction(function);
/*     */   }
/*     */   
/*     */ 
/*     */   void nonBlockingExecute(String script)
/*     */   {
/* 397 */     execute(script);
/*     */   }
/*     */   
/*     */   public abstract boolean execute(String paramString);
/*     */   
/*     */   public Object evaluate(String script, boolean trusted) throws SWTException {
/* 403 */     return evaluate(script);
/*     */   }
/*     */   
/*     */ 
/*     */   public Object evaluate(String script)
/*     */     throws SWTException
/*     */   {
/* 410 */     BrowserFunction function = new EvaluateFunction(this.browser, "");
/* 411 */     int index = getNextFunctionIndex();
/* 412 */     function.index = index;
/* 413 */     function.isEvaluate = true;
/* 414 */     registerFunction(function);
/* 415 */     String functionName = "SWTExecuteTemporaryFunction" + index;
/*     */     
/* 417 */     StringBuilder buffer = new StringBuilder("window.");
/* 418 */     buffer.append(functionName);
/* 419 */     buffer.append(" = function ");
/* 420 */     buffer.append(functionName);
/* 421 */     buffer.append("() {\n");
/* 422 */     buffer.append(script);
/* 423 */     buffer.append("\n};");
/* 424 */     nonBlockingExecute(buffer.toString());
/*     */     
/* 426 */     buffer = new StringBuilder("if (window.");
/* 427 */     buffer.append(functionName);
/* 428 */     buffer.append(" == undefined) {window.external.callJava(");
/* 429 */     buffer.append(index);
/* 430 */     buffer.append(",'");
/* 431 */     buffer.append(function.token);
/* 432 */     buffer.append("', ['");
/* 433 */     buffer.append("org.eclipse.swt.browser.error");
/* 434 */     buffer.append("']);} else {try {var result = ");
/* 435 */     buffer.append(functionName);
/* 436 */     buffer.append("(); window.external.callJava(");
/* 437 */     buffer.append(index);
/* 438 */     buffer.append(",'");
/* 439 */     buffer.append(function.token);
/* 440 */     buffer.append("', [result]);} catch (e) {window.external.callJava(");
/* 441 */     buffer.append(index);
/* 442 */     buffer.append(",'");
/* 443 */     buffer.append(function.token);
/* 444 */     buffer.append("', ['");
/* 445 */     buffer.append("org.eclipse.swt.browser.error");
/* 446 */     buffer.append("' + e.message]);}}");
/* 447 */     nonBlockingExecute(buffer.toString());
/* 448 */     nonBlockingExecute(getDeleteFunctionString(functionName));
/* 449 */     deregisterFunction(function);
/*     */     
/* 451 */     Object result = this.evaluateResult;
/* 452 */     this.evaluateResult = null;
/* 453 */     if ((result instanceof SWTException)) throw ((SWTException)result);
/* 454 */     return result;
/*     */   }
/*     */   
/*     */   public abstract boolean forward();
/*     */   
/*     */   public abstract String getBrowserType();
/*     */   
/*     */   String getDeleteFunctionString(String functionName) {
/* 462 */     return "delete window." + functionName;
/*     */   }
/*     */   
/*     */   int getNextFunctionIndex() {
/* 466 */     return this.nextFunctionIndex++;
/*     */   }
/*     */   
/*     */   public abstract String getText();
/*     */   
/*     */   public abstract String getUrl();
/*     */   
/*     */   public Object getWebBrowser() {
/* 474 */     return null;
/*     */   }
/*     */   
/*     */   public abstract boolean isBackEnabled();
/*     */   
/*     */   public boolean isFocusControl() {
/* 480 */     return false;
/*     */   }
/*     */   
/*     */   public abstract boolean isForwardEnabled();
/*     */   
/*     */   public abstract void refresh();
/*     */   
/*     */   void registerFunction(BrowserFunction function) {
/* 488 */     this.functions.put(Integer.valueOf(function.index), function);
/*     */   }
/*     */   
/*     */   public void removeAuthenticationListener(AuthenticationListener listener) {
/* 492 */     if (this.authenticationListeners.length == 0) return;
/* 493 */     int index = -1;
/* 494 */     for (int i = 0; i < this.authenticationListeners.length; i++) {
/* 495 */       if (listener == this.authenticationListeners[i]) {
/* 496 */         index = i;
/* 497 */         break;
/*     */       }
/*     */     }
/* 500 */     if (index == -1) return;
/* 501 */     if (this.authenticationListeners.length == 1) {
/* 502 */       this.authenticationListeners = new AuthenticationListener[0];
/* 503 */       return;
/*     */     }
/* 505 */     AuthenticationListener[] newAuthenticationListeners = new AuthenticationListener[this.authenticationListeners.length - 1];
/* 506 */     System.arraycopy(this.authenticationListeners, 0, newAuthenticationListeners, 0, index);
/* 507 */     System.arraycopy(this.authenticationListeners, index + 1, newAuthenticationListeners, index, this.authenticationListeners.length - index - 1);
/* 508 */     this.authenticationListeners = newAuthenticationListeners;
/*     */   }
/*     */   
/*     */   public void removeCloseWindowListener(CloseWindowListener listener) {
/* 512 */     if (this.closeWindowListeners.length == 0) return;
/* 513 */     int index = -1;
/* 514 */     for (int i = 0; i < this.closeWindowListeners.length; i++) {
/* 515 */       if (listener == this.closeWindowListeners[i]) {
/* 516 */         index = i;
/* 517 */         break;
/*     */       }
/*     */     }
/* 520 */     if (index == -1) return;
/* 521 */     if (this.closeWindowListeners.length == 1) {
/* 522 */       this.closeWindowListeners = new CloseWindowListener[0];
/* 523 */       return;
/*     */     }
/* 525 */     CloseWindowListener[] newCloseWindowListeners = new CloseWindowListener[this.closeWindowListeners.length - 1];
/* 526 */     System.arraycopy(this.closeWindowListeners, 0, newCloseWindowListeners, 0, index);
/* 527 */     System.arraycopy(this.closeWindowListeners, index + 1, newCloseWindowListeners, index, this.closeWindowListeners.length - index - 1);
/* 528 */     this.closeWindowListeners = newCloseWindowListeners;
/*     */   }
/*     */   
/*     */   public void removeLocationListener(LocationListener listener) {
/* 532 */     if (this.locationListeners.length == 0) return;
/* 533 */     int index = -1;
/* 534 */     for (int i = 0; i < this.locationListeners.length; i++) {
/* 535 */       if (listener == this.locationListeners[i]) {
/* 536 */         index = i;
/* 537 */         break;
/*     */       }
/*     */     }
/* 540 */     if (index == -1) return;
/* 541 */     if (this.locationListeners.length == 1) {
/* 542 */       this.locationListeners = new LocationListener[0];
/* 543 */       return;
/*     */     }
/* 545 */     LocationListener[] newLocationListeners = new LocationListener[this.locationListeners.length - 1];
/* 546 */     System.arraycopy(this.locationListeners, 0, newLocationListeners, 0, index);
/* 547 */     System.arraycopy(this.locationListeners, index + 1, newLocationListeners, index, this.locationListeners.length - index - 1);
/* 548 */     this.locationListeners = newLocationListeners;
/*     */   }
/*     */   
/*     */   public void removeOpenWindowListener(OpenWindowListener listener) {
/* 552 */     if (this.openWindowListeners.length == 0) return;
/* 553 */     int index = -1;
/* 554 */     for (int i = 0; i < this.openWindowListeners.length; i++) {
/* 555 */       if (listener == this.openWindowListeners[i]) {
/* 556 */         index = i;
/* 557 */         break;
/*     */       }
/*     */     }
/* 560 */     if (index == -1) return;
/* 561 */     if (this.openWindowListeners.length == 1) {
/* 562 */       this.openWindowListeners = new OpenWindowListener[0];
/* 563 */       return;
/*     */     }
/* 565 */     OpenWindowListener[] newOpenWindowListeners = new OpenWindowListener[this.openWindowListeners.length - 1];
/* 566 */     System.arraycopy(this.openWindowListeners, 0, newOpenWindowListeners, 0, index);
/* 567 */     System.arraycopy(this.openWindowListeners, index + 1, newOpenWindowListeners, index, this.openWindowListeners.length - index - 1);
/* 568 */     this.openWindowListeners = newOpenWindowListeners;
/*     */   }
/*     */   
/*     */   public void removeProgressListener(ProgressListener listener) {
/* 572 */     if (this.progressListeners.length == 0) return;
/* 573 */     int index = -1;
/* 574 */     for (int i = 0; i < this.progressListeners.length; i++) {
/* 575 */       if (listener == this.progressListeners[i]) {
/* 576 */         index = i;
/* 577 */         break;
/*     */       }
/*     */     }
/* 580 */     if (index == -1) return;
/* 581 */     if (this.progressListeners.length == 1) {
/* 582 */       this.progressListeners = new ProgressListener[0];
/* 583 */       return;
/*     */     }
/* 585 */     ProgressListener[] newProgressListeners = new ProgressListener[this.progressListeners.length - 1];
/* 586 */     System.arraycopy(this.progressListeners, 0, newProgressListeners, 0, index);
/* 587 */     System.arraycopy(this.progressListeners, index + 1, newProgressListeners, index, this.progressListeners.length - index - 1);
/* 588 */     this.progressListeners = newProgressListeners;
/*     */   }
/*     */   
/*     */   public void removeStatusTextListener(StatusTextListener listener) {
/* 592 */     if (this.statusTextListeners.length == 0) return;
/* 593 */     int index = -1;
/* 594 */     for (int i = 0; i < this.statusTextListeners.length; i++) {
/* 595 */       if (listener == this.statusTextListeners[i]) {
/* 596 */         index = i;
/* 597 */         break;
/*     */       }
/*     */     }
/* 600 */     if (index == -1) return;
/* 601 */     if (this.statusTextListeners.length == 1) {
/* 602 */       this.statusTextListeners = new StatusTextListener[0];
/* 603 */       return;
/*     */     }
/* 605 */     StatusTextListener[] newStatusTextListeners = new StatusTextListener[this.statusTextListeners.length - 1];
/* 606 */     System.arraycopy(this.statusTextListeners, 0, newStatusTextListeners, 0, index);
/* 607 */     System.arraycopy(this.statusTextListeners, index + 1, newStatusTextListeners, index, this.statusTextListeners.length - index - 1);
/* 608 */     this.statusTextListeners = newStatusTextListeners;
/*     */   }
/*     */   
/*     */   public void removeTitleListener(TitleListener listener) {
/* 612 */     if (this.titleListeners.length == 0) return;
/* 613 */     int index = -1;
/* 614 */     for (int i = 0; i < this.titleListeners.length; i++) {
/* 615 */       if (listener == this.titleListeners[i]) {
/* 616 */         index = i;
/* 617 */         break;
/*     */       }
/*     */     }
/* 620 */     if (index == -1) return;
/* 621 */     if (this.titleListeners.length == 1) {
/* 622 */       this.titleListeners = new TitleListener[0];
/* 623 */       return;
/*     */     }
/* 625 */     TitleListener[] newTitleListeners = new TitleListener[this.titleListeners.length - 1];
/* 626 */     System.arraycopy(this.titleListeners, 0, newTitleListeners, 0, index);
/* 627 */     System.arraycopy(this.titleListeners, index + 1, newTitleListeners, index, this.titleListeners.length - index - 1);
/* 628 */     this.titleListeners = newTitleListeners;
/*     */   }
/*     */   
/*     */   public void removeVisibilityWindowListener(VisibilityWindowListener listener) {
/* 632 */     if (this.visibilityWindowListeners.length == 0) return;
/* 633 */     int index = -1;
/* 634 */     for (int i = 0; i < this.visibilityWindowListeners.length; i++) {
/* 635 */       if (listener == this.visibilityWindowListeners[i]) {
/* 636 */         index = i;
/* 637 */         break;
/*     */       }
/*     */     }
/* 640 */     if (index == -1) return;
/* 641 */     if (this.visibilityWindowListeners.length == 1) {
/* 642 */       this.visibilityWindowListeners = new VisibilityWindowListener[0];
/* 643 */       return;
/*     */     }
/* 645 */     VisibilityWindowListener[] newVisibilityWindowListeners = new VisibilityWindowListener[this.visibilityWindowListeners.length - 1];
/* 646 */     System.arraycopy(this.visibilityWindowListeners, 0, newVisibilityWindowListeners, 0, index);
/* 647 */     System.arraycopy(this.visibilityWindowListeners, index + 1, newVisibilityWindowListeners, index, this.visibilityWindowListeners.length - index - 1);
/* 648 */     this.visibilityWindowListeners = newVisibilityWindowListeners;
/*     */   }
/*     */   
/*     */   boolean sendKeyEvent(Event event) {
/* 652 */     int traversal = 0;
/* 653 */     boolean traverseDoit = true;
/* 654 */     switch (event.keyCode) {
/*     */     case 27: 
/* 656 */       traversal = 2;
/* 657 */       traverseDoit = true;
/* 658 */       break;
/*     */     
/*     */     case 13: 
/* 661 */       traversal = 4;
/* 662 */       traverseDoit = false;
/* 663 */       break;
/*     */     
/*     */     case 16777218: 
/*     */     case 16777220: 
/* 667 */       traversal = 64;
/* 668 */       traverseDoit = false;
/* 669 */       break;
/*     */     
/*     */     case 16777217: 
/*     */     case 16777219: 
/* 673 */       traversal = 32;
/* 674 */       traverseDoit = false;
/* 675 */       break;
/*     */     
/*     */     case 9: 
/* 678 */       traversal = (event.stateMask & 0x20000) != 0 ? 8 : 16;
/* 679 */       traverseDoit = (event.stateMask & 0x40000) != 0;
/* 680 */       break;
/*     */     
/*     */     case 16777222: 
/* 683 */       if ((event.stateMask & 0x40000) != 0) {
/* 684 */         traversal = 512;
/* 685 */         traverseDoit = true;
/*     */       }
/*     */       
/*     */       break;
/*     */     case 16777221: 
/* 690 */       if ((event.stateMask & 0x40000) != 0) {
/* 691 */         traversal = 256;
/* 692 */         traverseDoit = true;
/*     */       }
/*     */       
/*     */       break;
/*     */     default: 
/* 697 */       if ((translateMnemonics()) && 
/* 698 */         (event.character != 0) && ((event.stateMask & 0x50000) == 65536)) {
/* 699 */         traversal = 128;
/* 700 */         traverseDoit = true;
/*     */       }
/*     */       
/*     */       break;
/*     */     }
/*     */     
/*     */     
/* 707 */     boolean doit = true;
/* 708 */     if (traversal != 0) {
/* 709 */       boolean oldEventDoit = event.doit;
/* 710 */       event.doit = traverseDoit;
/* 711 */       doit = !this.browser.traverse(traversal, event);
/* 712 */       event.doit = oldEventDoit;
/*     */     }
/* 714 */     if (doit) {
/* 715 */       this.browser.notifyListeners(event.type, event);
/* 716 */       doit = event.doit;
/*     */     }
/* 718 */     return doit;
/*     */   }
/*     */   
/*     */   public void setBrowser(Browser browser) {
/* 722 */     this.browser = browser;
/*     */   }
/*     */   
/*     */   public abstract boolean setText(String paramString, boolean paramBoolean);
/*     */   
/*     */   public abstract boolean setUrl(String paramString1, String paramString2, String[] paramArrayOfString);
/*     */   
/*     */   public abstract void stop();
/*     */   
/*     */   int translateKey(int key) {
/* 732 */     for (int i = 0; i < KeyTable.length; i++) {
/* 733 */       if (KeyTable[i][0] == key) return KeyTable[i][1];
/*     */     }
/* 735 */     return 0;
/*     */   }
/*     */   
/*     */   boolean translateMnemonics() {
/* 739 */     return true;
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/browser/WebBrowser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */