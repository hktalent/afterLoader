/*    */ package org.eclipse.swt.graphics;
/*    */ 
/*    */ import org.eclipse.swt.SWT;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class Resource
/*    */ {
/*    */   Device device;
/*    */   
/*    */   public Resource() {}
/*    */   
/*    */   Resource(Device device)
/*    */   {
/* 49 */     if (device == null) device = Device.getDevice();
/* 50 */     if (device == null) SWT.error(4);
/* 51 */     this.device = device;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   void destroy() {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void dispose()
/*    */   {
/* 64 */     if (this.device == null) return;
/* 65 */     if (this.device.isDisposed()) return;
/* 66 */     destroy();
/* 67 */     if (this.device.tracking) this.device.dispose_Object(this);
/* 68 */     this.device = null;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Device getDevice()
/*    */   {
/* 80 */     Device device = this.device;
/* 81 */     if ((device == null) || (isDisposed())) SWT.error(44);
/* 82 */     return device;
/*    */   }
/*    */   
/*    */   void init() {
/* 86 */     if (this.device.tracking) this.device.new_Object(this);
/*    */   }
/*    */   
/*    */   public abstract boolean isDisposed();
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/graphics/Resource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */