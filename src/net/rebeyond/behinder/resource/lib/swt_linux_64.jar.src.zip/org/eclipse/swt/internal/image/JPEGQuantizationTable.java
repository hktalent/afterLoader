/*     */ package org.eclipse.swt.internal.image;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class JPEGQuantizationTable
/*     */   extends JPEGVariableSizeSegment
/*     */ {
/*  15 */   public static byte[] DefaultLuminanceQTable = { -1, -37, 0, 67, 0, 16, 11, 10, 16, 24, 40, 51, 61, 12, 12, 14, 19, 26, 58, 60, 55, 14, 13, 16, 24, 40, 57, 69, 56, 14, 17, 22, 29, 51, 87, 80, 62, 18, 22, 37, 56, 68, 109, 103, 77, 24, 35, 55, 64, 81, 104, 113, 92, 49, 64, 78, 87, 103, 121, 120, 101, 72, 92, 95, 98, 112, 100, 103, 99 };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  26 */   public static byte[] DefaultChrominanceQTable = { -1, -37, 0, 67, 1, 17, 18, 24, 47, 99, 99, 99, 99, 18, 21, 26, 66, 99, 99, 99, 99, 24, 26, 56, 99, 99, 99, 99, 99, 47, 66, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99 };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public JPEGQuantizationTable(byte[] reference)
/*     */   {
/*  39 */     super(reference);
/*     */   }
/*     */   
/*     */   public JPEGQuantizationTable(LEDataInputStream byteStream) {
/*  43 */     super(byteStream);
/*     */   }
/*     */   
/*     */   public static JPEGQuantizationTable defaultChrominanceTable() {
/*  47 */     byte[] data = new byte[DefaultChrominanceQTable.length];
/*  48 */     System.arraycopy(DefaultChrominanceQTable, 0, data, 0, data.length);
/*  49 */     return new JPEGQuantizationTable(data);
/*     */   }
/*     */   
/*     */   public static JPEGQuantizationTable defaultLuminanceTable() {
/*  53 */     byte[] data = new byte[DefaultLuminanceQTable.length];
/*  54 */     System.arraycopy(DefaultLuminanceQTable, 0, data, 0, data.length);
/*  55 */     return new JPEGQuantizationTable(data);
/*     */   }
/*     */   
/*     */   public int[] getQuantizationTablesKeys() {
/*  59 */     int[] keys = new int[4];
/*  60 */     int keysIndex = 0;
/*  61 */     int totalLength = getSegmentLength() - 2;
/*  62 */     int ofs = 4;
/*  63 */     while (totalLength > 64) {
/*  64 */       int tq = this.reference[ofs] & 0xF;
/*  65 */       int pq = (this.reference[ofs] & 0xFF) >> 4;
/*  66 */       if (pq == 0) {
/*  67 */         ofs += 65;
/*  68 */         totalLength -= 65;
/*     */       } else {
/*  70 */         ofs += 129;
/*  71 */         totalLength -= 129;
/*     */       }
/*  73 */       if (keysIndex >= keys.length) {
/*  74 */         int[] newKeys = new int[keys.length + 4];
/*  75 */         System.arraycopy(keys, 0, newKeys, 0, keys.length);
/*  76 */         keys = newKeys;
/*     */       }
/*  78 */       keys[keysIndex] = tq;
/*  79 */       keysIndex++;
/*     */     }
/*  81 */     int[] newKeys = new int[keysIndex];
/*  82 */     System.arraycopy(keys, 0, newKeys, 0, keysIndex);
/*  83 */     return newKeys;
/*     */   }
/*     */   
/*     */   public int[][] getQuantizationTablesValues() {
/*  87 */     int[][] values = new int[4][];
/*  88 */     int valuesIndex = 0;
/*  89 */     int totalLength = getSegmentLength() - 2;
/*  90 */     int ofs = 4;
/*  91 */     while (totalLength > 64) {
/*  92 */       int[] qk = new int[64];
/*  93 */       int pq = (this.reference[ofs] & 0xFF) >> 4;
/*  94 */       if (pq == 0) {
/*  95 */         for (int i = 0; i < qk.length; i++) {
/*  96 */           qk[i] = (this.reference[(ofs + i + 1)] & 0xFF);
/*     */         }
/*  98 */         ofs += 65;
/*  99 */         totalLength -= 65;
/*     */       } else {
/* 101 */         for (int i = 0; i < qk.length; i++) {
/* 102 */           int idx = (i - 1) * 2;
/* 103 */           qk[i] = ((this.reference[(ofs + idx + 1)] & 0xFF) * 256 + (this.reference[(ofs + idx + 2)] & 0xFF));
/*     */         }
/* 105 */         ofs += 129;
/* 106 */         totalLength -= 129;
/*     */       }
/* 108 */       if (valuesIndex >= values.length) {
/* 109 */         int[][] newValues = new int[values.length + 4][];
/* 110 */         System.arraycopy(values, 0, newValues, 0, values.length);
/* 111 */         values = newValues;
/*     */       }
/* 113 */       values[valuesIndex] = qk;
/* 114 */       valuesIndex++;
/*     */     }
/* 116 */     int[][] newValues = new int[valuesIndex][];
/* 117 */     System.arraycopy(values, 0, newValues, 0, valuesIndex);
/* 118 */     return newValues;
/*     */   }
/*     */   
/*     */   public void scaleBy(int qualityFactor) {
/* 122 */     int qFactor = qualityFactor;
/* 123 */     if (qFactor <= 0) {
/* 124 */       qFactor = 1;
/*     */     }
/* 126 */     if (qFactor > 100) {
/* 127 */       qFactor = 100;
/*     */     }
/* 129 */     if (qFactor < 50) {
/* 130 */       qFactor = 5000 / qFactor;
/*     */     } else {
/* 132 */       qFactor = 200 - qFactor * 2;
/*     */     }
/* 134 */     int totalLength = getSegmentLength() - 2;
/* 135 */     int ofs = 4;
/* 136 */     while (totalLength > 64)
/*     */     {
/* 138 */       int pq = (this.reference[ofs] & 0xFF) >> 4;
/* 139 */       if (pq == 0) {
/* 140 */         for (int i = ofs + 1; i <= ofs + 64; i++) {
/* 141 */           int temp = ((this.reference[i] & 0xFF) * qFactor + 50) / 100;
/* 142 */           if (temp <= 0) temp = 1;
/* 143 */           if (temp > 255) temp = 255;
/* 144 */           this.reference[i] = ((byte)temp);
/*     */         }
/* 146 */         ofs += 65;
/* 147 */         totalLength -= 65;
/*     */       } else {
/* 149 */         for (int i = ofs + 1; i <= ofs + 128; i += 2) {
/* 150 */           int temp = (((this.reference[i] & 0xFF) * 256 + (this.reference[(i + 1)] & 0xFF)) * qFactor + 50) / 100;
/* 151 */           if (temp <= 0) temp = 1;
/* 152 */           if (temp > 32767) temp = 32767;
/* 153 */           this.reference[i] = ((byte)(temp >> 8));
/* 154 */           this.reference[(i + 1)] = ((byte)(temp & 0xFF));
/*     */         }
/* 156 */         ofs += 129;
/* 157 */         totalLength -= 129;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public int signature()
/*     */   {
/* 164 */     return 65499;
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/internal/image/JPEGQuantizationTable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */