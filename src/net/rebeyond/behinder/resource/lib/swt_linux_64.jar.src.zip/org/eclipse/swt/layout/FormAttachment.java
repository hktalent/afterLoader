/*     */ package org.eclipse.swt.layout;
/*     */ 
/*     */ import org.eclipse.swt.SWT;
/*     */ import org.eclipse.swt.widgets.Control;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class FormAttachment
/*     */ {
/*     */   public int numerator;
/*  92 */   public int denominator = 100;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int offset;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Control control;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int alignment;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FormAttachment() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FormAttachment(int numerator)
/*     */   {
/* 156 */     this(numerator, 100, 0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FormAttachment(int numerator, int offset)
/*     */   {
/* 169 */     this(numerator, 100, offset);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FormAttachment(int numerator, int denominator, int offset)
/*     */   {
/* 183 */     if (denominator == 0) SWT.error(7);
/* 184 */     this.numerator = numerator;
/* 185 */     this.denominator = denominator;
/* 186 */     this.offset = offset;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FormAttachment(Control control)
/*     */   {
/* 199 */     this(control, 0, -1);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FormAttachment(Control control, int offset)
/*     */   {
/* 212 */     this(control, offset, -1);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FormAttachment(Control control, int offset, int alignment)
/*     */   {
/* 239 */     this.control = control;
/* 240 */     this.offset = offset;
/* 241 */     this.alignment = alignment;
/*     */   }
/*     */   
/*     */   FormAttachment divide(int value) {
/* 245 */     return new FormAttachment(this.numerator, this.denominator * value, this.offset / value);
/*     */   }
/*     */   
/*     */   int gcd(int m, int n)
/*     */   {
/* 250 */     m = Math.abs(m);
/* 251 */     n = Math.abs(n);
/* 252 */     if (m < n) {
/* 253 */       int temp = m;
/* 254 */       m = n;
/* 255 */       n = temp;
/*     */     }
/* 257 */     while (n != 0) {
/* 258 */       int temp = m;
/* 259 */       m = n;
/* 260 */       n = temp % n;
/*     */     }
/* 262 */     return m;
/*     */   }
/*     */   
/*     */   FormAttachment minus(FormAttachment attachment) {
/* 266 */     FormAttachment solution = new FormAttachment();
/* 267 */     solution.numerator = (this.numerator * attachment.denominator - this.denominator * attachment.numerator);
/* 268 */     this.denominator *= attachment.denominator;
/* 269 */     int gcd = gcd(solution.denominator, solution.numerator);
/* 270 */     solution.numerator /= gcd;
/* 271 */     solution.denominator /= gcd;
/* 272 */     this.offset -= attachment.offset;
/* 273 */     return solution;
/*     */   }
/*     */   
/*     */   FormAttachment minus(int value) {
/* 277 */     return new FormAttachment(this.numerator, this.denominator, this.offset - value);
/*     */   }
/*     */   
/*     */   FormAttachment plus(FormAttachment attachment) {
/* 281 */     FormAttachment solution = new FormAttachment();
/* 282 */     solution.numerator = (this.numerator * attachment.denominator + this.denominator * attachment.numerator);
/* 283 */     this.denominator *= attachment.denominator;
/* 284 */     int gcd = gcd(solution.denominator, solution.numerator);
/* 285 */     solution.numerator /= gcd;
/* 286 */     solution.denominator /= gcd;
/* 287 */     this.offset += attachment.offset;
/* 288 */     return solution;
/*     */   }
/*     */   
/*     */   FormAttachment plus(int value) {
/* 292 */     return new FormAttachment(this.numerator, this.denominator, this.offset + value);
/*     */   }
/*     */   
/*     */   int solveX(int value) {
/* 296 */     if (this.denominator == 0) SWT.error(7);
/* 297 */     return this.numerator * value / this.denominator + this.offset;
/*     */   }
/*     */   
/*     */   int solveY(int value) {
/* 301 */     if (this.numerator == 0) SWT.error(7);
/* 302 */     return (value - this.offset) * this.denominator / this.numerator;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 313 */     String string = this.numerator + "/" + this.denominator;
/* 314 */     return "{y = (" + string + (this.offset >= 0 ? ")x + " + this.offset : new StringBuilder().append(")x - ").append(-this.offset).toString()) + "}";
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/layout/FormAttachment.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */