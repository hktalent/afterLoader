package org.eclipse.swt.dnd;

public class DropTargetAdapter
  implements DropTargetListener
{
  public void dragEnter(DropTargetEvent event) {}
  
  public void dragLeave(DropTargetEvent event) {}
  
  public void dragOperationChanged(DropTargetEvent event) {}
  
  public void dragOver(DropTargetEvent event) {}
  
  public void drop(DropTargetEvent event) {}
  
  public void dropAccept(DropTargetEvent event) {}
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/dnd/DropTargetAdapter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */