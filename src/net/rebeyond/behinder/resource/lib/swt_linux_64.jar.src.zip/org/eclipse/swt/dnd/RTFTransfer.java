/*     */ package org.eclipse.swt.dnd;
/*     */ 
/*     */ import org.eclipse.swt.internal.C;
/*     */ import org.eclipse.swt.internal.Converter;
/*     */ import org.eclipse.swt.internal.gtk.OS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RTFTransfer
/*     */   extends ByteArrayTransfer
/*     */ {
/*  32 */   private static RTFTransfer _instance = new RTFTransfer();
/*     */   private static final String TEXT_RTF = "text/rtf";
/*  34 */   private static final int TEXT_RTF_ID = registerType("text/rtf");
/*     */   private static final String TEXT_RTF2 = "TEXT/RTF";
/*  36 */   private static final int TEXT_RTF2_ID = registerType("TEXT/RTF");
/*     */   private static final String APPLICATION_RTF = "application/rtf";
/*  38 */   private static final int APPLICATION_RTF_ID = registerType("application/rtf");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static RTFTransfer getInstance()
/*     */   {
/*  48 */     return _instance;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void javaToNative(Object object, TransferData transferData)
/*     */   {
/*  63 */     transferData.result = 0;
/*  64 */     if ((!checkRTF(object)) || (!isSupportedType(transferData))) {
/*  65 */       DND.error(2003);
/*     */     }
/*  67 */     String string = (String)object;
/*  68 */     byte[] buffer = Converter.wcsToMbcs(string, true);
/*  69 */     long pValue = OS.g_malloc(buffer.length);
/*  70 */     if (pValue == 0L) return;
/*  71 */     C.memmove(pValue, buffer, buffer.length);
/*  72 */     transferData.length = (buffer.length - 1);
/*  73 */     transferData.format = 8;
/*  74 */     transferData.pValue = pValue;
/*  75 */     transferData.result = 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object nativeToJava(TransferData transferData)
/*     */   {
/*  90 */     if ((!isSupportedType(transferData)) || (transferData.pValue == 0L)) return null;
/*  91 */     int size = transferData.format * transferData.length / 8;
/*  92 */     if (size == 0) return null;
/*  93 */     byte[] buffer = new byte[size];
/*  94 */     C.memmove(buffer, transferData.pValue, size);
/*  95 */     char[] chars = Converter.mbcsToWcs(buffer);
/*  96 */     String string = new String(chars);
/*  97 */     int end = string.indexOf(0);
/*  98 */     return end == -1 ? string : string.substring(0, end);
/*     */   }
/*     */   
/*     */   protected int[] getTypeIds()
/*     */   {
/* 103 */     return new int[] { TEXT_RTF_ID, TEXT_RTF2_ID, APPLICATION_RTF_ID };
/*     */   }
/*     */   
/*     */   protected String[] getTypeNames()
/*     */   {
/* 108 */     return new String[] { "text/rtf", "TEXT/RTF", "application/rtf" };
/*     */   }
/*     */   
/*     */   boolean checkRTF(Object object) {
/* 112 */     return (object != null) && ((object instanceof String)) && (((String)object).length() > 0);
/*     */   }
/*     */   
/*     */   protected boolean validate(Object object)
/*     */   {
/* 117 */     return checkRTF(object);
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/dnd/RTFTransfer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */