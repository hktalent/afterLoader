/*     */ package org.eclipse.swt.internal.image;
/*     */ 
/*     */ import org.eclipse.swt.SWT;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class JPEGScanHeader
/*     */   extends JPEGVariableSizeSegment
/*     */ {
/*     */   public int[][] componentParameters;
/*     */   
/*     */   public JPEGScanHeader(byte[] reference)
/*     */   {
/*  20 */     super(reference);
/*     */   }
/*     */   
/*     */   public JPEGScanHeader(LEDataInputStream byteStream) {
/*  24 */     super(byteStream);
/*  25 */     initializeComponentParameters();
/*     */   }
/*     */   
/*     */   public int getApproxBitPositionHigh() {
/*  29 */     return this.reference[(2 * getNumberOfImageComponents() + 7)] >> 4;
/*     */   }
/*     */   
/*     */   public int getApproxBitPositionLow() {
/*  33 */     return this.reference[(2 * getNumberOfImageComponents() + 7)] & 0xF;
/*     */   }
/*     */   
/*     */   public int getEndOfSpectralSelection() {
/*  37 */     return this.reference[(2 * getNumberOfImageComponents() + 6)];
/*     */   }
/*     */   
/*     */   public int getNumberOfImageComponents() {
/*  41 */     return this.reference[4];
/*     */   }
/*     */   
/*     */   public int getStartOfSpectralSelection() {
/*  45 */     return this.reference[(2 * getNumberOfImageComponents() + 5)];
/*     */   }
/*     */   
/*     */   void initializeComponentParameters()
/*     */   {
/*  50 */     int compCount = getNumberOfImageComponents();
/*  51 */     this.componentParameters = new int[0][];
/*  52 */     for (int i = 0; i < compCount; i++) {
/*  53 */       int ofs = 5 + i * 2;
/*  54 */       int cid = this.reference[ofs] & 0xFF;
/*  55 */       int dc = (this.reference[(ofs + 1)] & 0xFF) >> 4;
/*  56 */       int ac = this.reference[(ofs + 1)] & 0xF;
/*  57 */       if (this.componentParameters.length <= cid) {
/*  58 */         int[][] newParams = new int[cid + 1][];
/*  59 */         System.arraycopy(this.componentParameters, 0, newParams, 0, this.componentParameters.length);
/*  60 */         this.componentParameters = newParams;
/*     */       }
/*  62 */       this.componentParameters[cid] = { dc, ac };
/*     */     }
/*     */   }
/*     */   
/*     */   public void initializeContents()
/*     */   {
/*  68 */     int compCount = getNumberOfImageComponents();
/*  69 */     int[][] compSpecParams = this.componentParameters;
/*  70 */     if ((compCount == 0) || (compCount != compSpecParams.length)) {
/*  71 */       SWT.error(40);
/*     */     }
/*  73 */     for (int i = 0; i < compCount; i++) {
/*  74 */       int ofs = i * 2 + 5;
/*  75 */       int[] compParams = compSpecParams[i];
/*  76 */       this.reference[ofs] = ((byte)(i + 1));
/*  77 */       this.reference[(ofs + 1)] = ((byte)(compParams[0] * 16 + compParams[1]));
/*     */     }
/*     */   }
/*     */   
/*     */   public void setEndOfSpectralSelection(int anInteger) {
/*  82 */     this.reference[(2 * getNumberOfImageComponents() + 6)] = ((byte)anInteger);
/*     */   }
/*     */   
/*     */   public void setNumberOfImageComponents(int anInteger) {
/*  86 */     this.reference[4] = ((byte)(anInteger & 0xFF));
/*     */   }
/*     */   
/*     */   public void setStartOfSpectralSelection(int anInteger) {
/*  90 */     this.reference[(2 * getNumberOfImageComponents() + 5)] = ((byte)anInteger);
/*     */   }
/*     */   
/*     */   public int signature()
/*     */   {
/*  95 */     return 65498;
/*     */   }
/*     */   
/*     */   public boolean verifyProgressiveScan() {
/*  99 */     int start = getStartOfSpectralSelection();
/* 100 */     int end = getEndOfSpectralSelection();
/* 101 */     int low = getApproxBitPositionLow();
/* 102 */     int high = getApproxBitPositionHigh();
/* 103 */     int count = getNumberOfImageComponents();
/* 104 */     if (((start == 0) && (end == 0)) || ((start <= end) && (end <= 63) && 
/* 105 */       (low <= 13) && (high <= 13) && ((high == 0) || (high == low + 1)))) {
/* 106 */       return (start == 0) || ((start > 0) && (count == 1));
/*     */     }
/*     */     
/* 109 */     return false;
/*     */   }
/*     */   
/*     */   public boolean isACProgressiveScan() {
/* 113 */     return (getStartOfSpectralSelection() != 0) && (getEndOfSpectralSelection() != 0);
/*     */   }
/*     */   
/*     */   public boolean isDCProgressiveScan() {
/* 117 */     return (getStartOfSpectralSelection() == 0) && (getEndOfSpectralSelection() == 0);
/*     */   }
/*     */   
/*     */   public boolean isFirstScan() {
/* 121 */     return getApproxBitPositionHigh() == 0;
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/internal/image/JPEGScanHeader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */