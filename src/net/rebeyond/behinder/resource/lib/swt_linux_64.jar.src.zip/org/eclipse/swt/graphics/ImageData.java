/*      */ package org.eclipse.swt.graphics;
/*      */ 
/*      */ import java.io.InputStream;
/*      */ import org.eclipse.swt.SWT;
/*      */ import org.eclipse.swt.internal.DPIUtil;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class ImageData
/*      */   implements Cloneable
/*      */ {
/*      */   public int width;
/*      */   public int height;
/*      */   public int depth;
/*      */   public int scanlinePad;
/*      */   public int bytesPerLine;
/*      */   public byte[] data;
/*      */   public PaletteData palette;
/*      */   public int transparentPixel;
/*      */   public byte[] maskData;
/*      */   public int maskPad;
/*      */   public byte[] alphaData;
/*      */   public int alpha;
/*      */   public int type;
/*      */   public int x;
/*      */   public int y;
/*      */   public int disposalMethod;
/*      */   public int delayTime;
/*  214 */   static final byte[][] ANY_TO_EIGHT = new byte[9][];
/*      */   
/*  216 */   static { for (int b = 0; b < 9; b++) {
/*  217 */       byte[] data = ANY_TO_EIGHT[b] = new byte[1 << b];
/*  218 */       if (b != 0) {
/*  219 */         int inc = 0;
/*  220 */         for (int bit = 65536; bit >>= b != 0; inc |= bit) {}
/*  221 */         int v = 0; for (int p = 0; v < 65536; v += inc) data[(p++)] = ((byte)(v >> 8));
/*      */       } } }
/*      */   
/*  224 */   static final byte[] ONE_TO_ONE_MAPPING = ANY_TO_EIGHT[8];
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  229 */   static final int[][] DITHER_MATRIX = { { 16515072, 8126464, 14417920, 6029312, 15990784, 7602176, 13893632, 5505024 }, { 3932160, 12320768, 1835008, 10223616, 3407872, 11796480, 1310720, 9699328 }, { 13369344, 4980736, 15466496, 7077888, 12845056, 4456448, 14942208, 6553600 }, { 786432, 9175040, 2883584, 11272192, 262144, 8650752, 2359296, 10747904 }, { 15728640, 7340032, 13631488, 5242880, 16252928, 7864320, 14155776, 5767168 }, { 3145728, 11534336, 1048576, 9437184, 3670016, 12058624, 1572864, 9961472 }, { 12582912, 4194304, 14680064, 6291456, 13107200, 4718592, 15204352, 6815744 }, { 0, 8388608, 2097152, 10485760, 524288, 8912896, 2621440, 11010048 } };
/*      */   static final int BLIT_SRC = 1;
/*      */   static final int BLIT_ALPHA = 2;
/*      */   static final int BLIT_DITHER = 4;
/*      */   static final int ALPHA_OPAQUE = 255;
/*      */   static final int ALPHA_TRANSPARENT = 0;
/*      */   static final int ALPHA_CHANNEL_SEPARATE = -1;
/*      */   static final int ALPHA_CHANNEL_SOURCE = -2;
/*      */   static final int ALPHA_MASK_UNPACKED = -3;
/*      */   static final int ALPHA_MASK_PACKED = -4;
/*      */   static final int ALPHA_MASK_INDEX = -5;
/*      */   static final int ALPHA_MASK_RGB = -6;
/*      */   static final int LSB_FIRST = 0;
/*      */   static final int MSB_FIRST = 1;
/*      */   private static final int TYPE_GENERIC_8 = 0;
/*      */   private static final int TYPE_GENERIC_16_MSB = 1;
/*      */   private static final int TYPE_GENERIC_16_LSB = 2;
/*      */   private static final int TYPE_GENERIC_24 = 3;
/*      */   private static final int TYPE_GENERIC_32_MSB = 4;
/*      */   private static final int TYPE_GENERIC_32_LSB = 5;
/*      */   private static final int TYPE_INDEX_8 = 6;
/*      */   private static final int TYPE_INDEX_4 = 7;
/*      */   private static final int TYPE_INDEX_2 = 8;
/*      */   private static final int TYPE_INDEX_1_MSB = 9;
/*      */   private static final int TYPE_INDEX_1_LSB = 10;
/*      */   
/*      */   public ImageData(int width, int height, int depth, PaletteData palette)
/*      */   {
/*  257 */     this(width, height, depth, palette, 4, null, 0, null, null, -1, -1, -1, 0, 0, 0, 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ImageData(int width, int height, int depth, PaletteData palette, int scanlinePad, byte[] data)
/*      */   {
/*  282 */     this(width, height, depth, palette, scanlinePad, 
/*  283 */       checkData(data), 0, null, null, -1, -1, -1, 0, 0, 0, 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ImageData(InputStream stream)
/*      */   {
/*  332 */     ImageData[] data = ImageDataLoader.load(stream);
/*  333 */     if (data.length < 1) SWT.error(40);
/*  334 */     ImageData i = data[0];
/*  335 */     setAllFields(i.width, i.height, i.depth, i.scanlinePad, i.bytesPerLine, i.data, i.palette, i.transparentPixel, i.maskData, i.maskPad, i.alphaData, i.alpha, i.type, i.x, i.y, i.disposalMethod, i.delayTime);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ImageData(String filename)
/*      */   {
/*  378 */     ImageData[] data = ImageDataLoader.load(filename);
/*  379 */     if (data.length < 1) SWT.error(40);
/*  380 */     ImageData i = data[0];
/*  381 */     setAllFields(i.width, i.height, i.depth, i.scanlinePad, i.bytesPerLine, i.data, i.palette, i.transparentPixel, i.maskData, i.maskPad, i.alphaData, i.alpha, i.type, i.x, i.y, i.disposalMethod, i.delayTime);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   ImageData(int width, int height, int depth, PaletteData palette, int scanlinePad, byte[] data, int maskPad, byte[] maskData, byte[] alphaData, int alpha, int transparentPixel, int type, int x, int y, int disposalMethod, int delayTime)
/*      */   {
/*  420 */     if (palette == null) SWT.error(4);
/*  421 */     if ((depth != 1) && (depth != 2) && (depth != 4) && (depth != 8) && (depth != 16) && (depth != 24) && (depth != 32))
/*      */     {
/*  423 */       SWT.error(5);
/*      */     }
/*  425 */     if ((width <= 0) || (height <= 0)) {
/*  426 */       SWT.error(5);
/*      */     }
/*  428 */     if (scanlinePad == 0) { SWT.error(7);
/*      */     }
/*  430 */     int bytesPerLine = ((width * depth + 7) / 8 + (scanlinePad - 1)) / scanlinePad * scanlinePad;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  439 */     int minBytesPerLine = type == 5 ? ((width + 7) / 8 + 3) / 4 * 4 : bytesPerLine;
/*  440 */     if ((data != null) && (data.length < minBytesPerLine * height)) {
/*  441 */       SWT.error(5);
/*      */     }
/*  443 */     setAllFields(width, height, depth, scanlinePad, bytesPerLine, data != null ? data : new byte[bytesPerLine * height], palette, transparentPixel, maskData, maskPad, alphaData, alpha, type, x, y, disposalMethod, delayTime);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void setAllFields(int width, int height, int depth, int scanlinePad, int bytesPerLine, byte[] data, PaletteData palette, int transparentPixel, byte[] maskData, int maskPad, byte[] alphaData, int alpha, int type, int x, int y, int disposalMethod, int delayTime)
/*      */   {
/*  477 */     this.width = width;
/*  478 */     this.height = height;
/*  479 */     this.depth = depth;
/*  480 */     this.scanlinePad = scanlinePad;
/*  481 */     this.bytesPerLine = bytesPerLine;
/*  482 */     this.data = data;
/*  483 */     this.palette = palette;
/*  484 */     this.transparentPixel = transparentPixel;
/*  485 */     this.maskData = maskData;
/*  486 */     this.maskPad = maskPad;
/*  487 */     this.alphaData = alphaData;
/*  488 */     this.alpha = alpha;
/*  489 */     this.type = type;
/*  490 */     this.x = x;
/*  491 */     this.y = y;
/*  492 */     this.disposalMethod = disposalMethod;
/*  493 */     this.delayTime = delayTime;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static ImageData internal_new(int width, int height, int depth, PaletteData palette, int scanlinePad, byte[] data, int maskPad, byte[] maskData, byte[] alphaData, int alpha, int transparentPixel, int type, int x, int y, int disposalMethod, int delayTime)
/*      */   {
/*  518 */     return new ImageData(width, height, depth, palette, scanlinePad, data, maskPad, maskData, alphaData, alpha, transparentPixel, type, x, y, disposalMethod, delayTime);
/*      */   }
/*      */   
/*      */ 
/*      */   ImageData colorMaskImage(int pixel)
/*      */   {
/*  524 */     ImageData mask = new ImageData(this.width, this.height, 1, bwPalette(), 2, null, 0, null, null, -1, -1, -1, 0, 0, 0, 0);
/*      */     
/*      */ 
/*  527 */     int[] row = new int[this.width];
/*  528 */     for (int y = 0; y < this.height; y++) {
/*  529 */       getPixels(0, y, this.width, row, 0);
/*  530 */       for (int i = 0; i < this.width; i++) {
/*  531 */         if ((pixel != -1) && (row[i] == pixel)) {
/*  532 */           row[i] = 0;
/*      */         } else {
/*  534 */           row[i] = 1;
/*      */         }
/*      */       }
/*  537 */       mask.setPixels(0, y, this.width, row, 0);
/*      */     }
/*  539 */     return mask;
/*      */   }
/*      */   
/*      */   static byte[] checkData(byte[] data) {
/*  543 */     if (data == null) SWT.error(4);
/*  544 */     return data;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object clone()
/*      */   {
/*  557 */     byte[] cloneData = new byte[this.data.length];
/*  558 */     System.arraycopy(this.data, 0, cloneData, 0, this.data.length);
/*  559 */     byte[] cloneMaskData = null;
/*  560 */     if (this.maskData != null) {
/*  561 */       cloneMaskData = new byte[this.maskData.length];
/*  562 */       System.arraycopy(this.maskData, 0, cloneMaskData, 0, this.maskData.length);
/*      */     }
/*  564 */     byte[] cloneAlphaData = null;
/*  565 */     if (this.alphaData != null) {
/*  566 */       cloneAlphaData = new byte[this.alphaData.length];
/*  567 */       System.arraycopy(this.alphaData, 0, cloneAlphaData, 0, this.alphaData.length);
/*      */     }
/*  569 */     return new ImageData(this.width, this.height, this.depth, this.palette, this.scanlinePad, cloneData, this.maskPad, cloneMaskData, cloneAlphaData, this.alpha, this.transparentPixel, this.type, this.x, this.y, this.disposalMethod, this.delayTime);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getAlpha(int x, int y)
/*      */   {
/*  603 */     if ((x >= this.width) || (y >= this.height) || (x < 0) || (y < 0)) { SWT.error(5);
/*      */     }
/*  605 */     if (this.alphaData == null) return 255;
/*  606 */     return this.alphaData[(y * this.width + x)] & 0xFF;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void getAlphas(int x, int y, int getWidth, byte[] alphas, int startIndex)
/*      */   {
/*  630 */     if (alphas == null) SWT.error(4);
/*  631 */     if ((getWidth < 0) || (x >= this.width) || (y >= this.height) || (x < 0) || (y < 0)) SWT.error(5);
/*  632 */     if (getWidth == 0) { return;
/*      */     }
/*  634 */     if (this.alphaData == null) {
/*  635 */       int endIndex = startIndex + getWidth;
/*  636 */       for (int i = startIndex; i < endIndex; i++) {
/*  637 */         alphas[i] = -1;
/*      */       }
/*  639 */       return;
/*      */     }
/*      */     
/*  642 */     System.arraycopy(this.alphaData, y * this.width + x, alphas, startIndex, getWidth);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getPixel(int x, int y)
/*      */   {
/*  661 */     if ((x >= this.width) || (y >= this.height) || (x < 0) || (y < 0)) { SWT.error(5);
/*      */     }
/*      */     
/*      */ 
/*  665 */     switch (this.depth) {
/*      */     case 32: 
/*  667 */       int index = y * this.bytesPerLine + x * 4;
/*  668 */       return ((this.data[index] & 0xFF) << 24) + ((this.data[(index + 1)] & 0xFF) << 16) + ((this.data[(index + 2)] & 0xFF) << 8) + (this.data[(index + 3)] & 0xFF);
/*      */     
/*      */     case 24: 
/*  671 */       int index = y * this.bytesPerLine + x * 3;
/*  672 */       return ((this.data[index] & 0xFF) << 16) + ((this.data[(index + 1)] & 0xFF) << 8) + (this.data[(index + 2)] & 0xFF);
/*      */     
/*      */     case 16: 
/*  675 */       int index = y * this.bytesPerLine + x * 2;
/*  676 */       return ((this.data[(index + 1)] & 0xFF) << 8) + (this.data[index] & 0xFF);
/*      */     case 8: 
/*  678 */       int index = y * this.bytesPerLine + x;
/*  679 */       return this.data[index] & 0xFF;
/*      */     case 4: 
/*  681 */       int index = y * this.bytesPerLine + (x >> 1);
/*  682 */       int theByte = this.data[index] & 0xFF;
/*  683 */       if ((x & 0x1) == 0) {
/*  684 */         return theByte >> 4;
/*      */       }
/*  686 */       return theByte & 0xF;
/*      */     
/*      */     case 2: 
/*  689 */       int index = y * this.bytesPerLine + (x >> 2);
/*  690 */       int theByte = this.data[index] & 0xFF;
/*  691 */       int offset = 3 - x % 4;
/*  692 */       int mask = 3 << offset * 2;
/*  693 */       return (theByte & mask) >> offset * 2;
/*      */     case 1: 
/*  695 */       int index = y * this.bytesPerLine + (x >> 3);
/*  696 */       int theByte = this.data[index] & 0xFF;
/*  697 */       int mask = 1 << 7 - (x & 0x7);
/*  698 */       if ((theByte & mask) == 0) {
/*  699 */         return 0;
/*      */       }
/*  701 */       return 1;
/*      */     }
/*      */     
/*  704 */     SWT.error(38);
/*  705 */     return 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void getPixels(int x, int y, int getWidth, byte[] pixels, int startIndex)
/*      */   {
/*  731 */     if (pixels == null) SWT.error(4);
/*  732 */     if ((getWidth < 0) || (x >= this.width) || (y >= this.height) || (x < 0) || (y < 0)) SWT.error(5);
/*  733 */     if (getWidth == 0) { return;
/*      */     }
/*      */     
/*  736 */     int mask = 0;
/*  737 */     int n = getWidth;
/*  738 */     int i = startIndex;
/*  739 */     int srcX = x;int srcY = y;
/*  740 */     switch (this.depth) {
/*      */     case 8: 
/*  742 */       int index = y * this.bytesPerLine + x;
/*  743 */       for (int j = 0; j < getWidth; j++) {
/*  744 */         pixels[i] = this.data[index];
/*  745 */         i++;
/*  746 */         srcX++;
/*  747 */         if (srcX >= this.width) {
/*  748 */           srcY++;
/*  749 */           index = srcY * this.bytesPerLine;
/*  750 */           srcX = 0;
/*      */         } else {
/*  752 */           index++;
/*      */         }
/*      */       }
/*  755 */       return;
/*      */     case 4: 
/*  757 */       int index = y * this.bytesPerLine + (x >> 1);
/*  758 */       if ((x & 0x1) == 1) {
/*  759 */         int theByte = this.data[index] & 0xFF;
/*  760 */         pixels[i] = ((byte)(theByte & 0xF));
/*  761 */         i++;
/*  762 */         n--;
/*  763 */         srcX++;
/*  764 */         if (srcX >= this.width) {
/*  765 */           srcY++;
/*  766 */           index = srcY * this.bytesPerLine;
/*  767 */           srcX = 0;
/*      */         } else {
/*  769 */           index++;
/*      */         }
/*      */       }
/*  772 */       while (n > 1) {
/*  773 */         int theByte = this.data[index] & 0xFF;
/*  774 */         pixels[i] = ((byte)(theByte >> 4));
/*  775 */         i++;
/*  776 */         n--;
/*  777 */         srcX++;
/*  778 */         if (srcX >= this.width) {
/*  779 */           srcY++;
/*  780 */           index = srcY * this.bytesPerLine;
/*  781 */           srcX = 0;
/*      */         } else {
/*  783 */           pixels[i] = ((byte)(theByte & 0xF));
/*  784 */           i++;
/*  785 */           n--;
/*  786 */           srcX++;
/*  787 */           if (srcX >= this.width) {
/*  788 */             srcY++;
/*  789 */             index = srcY * this.bytesPerLine;
/*  790 */             srcX = 0;
/*      */           } else {
/*  792 */             index++;
/*      */           }
/*      */         }
/*      */       }
/*  796 */       if (n > 0) {
/*  797 */         int theByte = this.data[index] & 0xFF;
/*  798 */         pixels[i] = ((byte)(theByte >> 4));
/*      */       }
/*  800 */       return;
/*      */     case 2: 
/*  802 */       int index = y * this.bytesPerLine + (x >> 2);
/*  803 */       int theByte = this.data[index] & 0xFF;
/*      */       
/*  805 */       while (n > 0) {
/*  806 */         int offset = 3 - srcX % 4;
/*  807 */         mask = 3 << offset * 2;
/*  808 */         pixels[i] = ((byte)((theByte & mask) >> offset * 2));
/*  809 */         i++;
/*  810 */         n--;
/*  811 */         srcX++;
/*  812 */         if (srcX >= this.width) {
/*  813 */           srcY++;
/*  814 */           index = srcY * this.bytesPerLine;
/*  815 */           if (n > 0) theByte = this.data[index] & 0xFF;
/*  816 */           srcX = 0;
/*      */         }
/*  818 */         else if (offset == 0) {
/*  819 */           index++;
/*  820 */           theByte = this.data[index] & 0xFF;
/*      */         }
/*      */       }
/*      */       
/*  824 */       return;
/*      */     case 1: 
/*  826 */       int index = y * this.bytesPerLine + (x >> 3);
/*  827 */       int theByte = this.data[index] & 0xFF;
/*  828 */       while (n > 0) {
/*  829 */         mask = 1 << 7 - (srcX & 0x7);
/*  830 */         if ((theByte & mask) == 0) {
/*  831 */           pixels[i] = 0;
/*      */         } else {
/*  833 */           pixels[i] = 1;
/*      */         }
/*  835 */         i++;
/*  836 */         n--;
/*  837 */         srcX++;
/*  838 */         if (srcX >= this.width) {
/*  839 */           srcY++;
/*  840 */           index = srcY * this.bytesPerLine;
/*  841 */           if (n > 0) theByte = this.data[index] & 0xFF;
/*  842 */           srcX = 0;
/*      */         }
/*  844 */         else if (mask == 1) {
/*  845 */           index++;
/*  846 */           if (n > 0) { theByte = this.data[index] & 0xFF;
/*      */           }
/*      */         }
/*      */       }
/*  850 */       return;
/*      */     }
/*  852 */     SWT.error(38);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void getPixels(int x, int y, int getWidth, int[] pixels, int startIndex)
/*      */   {
/*  877 */     if (pixels == null) SWT.error(4);
/*  878 */     if ((getWidth < 0) || (x >= this.width) || (y >= this.height) || (x < 0) || (y < 0)) SWT.error(5);
/*  879 */     if (getWidth == 0) { return;
/*      */     }
/*      */     
/*      */ 
/*  883 */     int n = getWidth;
/*  884 */     int i = startIndex;
/*  885 */     int srcX = x;int srcY = y;
/*  886 */     switch (this.depth) {
/*      */     case 32: 
/*  888 */       int index = y * this.bytesPerLine + x * 4;
/*  889 */       i = startIndex;
/*  890 */       for (int j = 0; j < getWidth; j++) {
/*  891 */         pixels[i] = ((this.data[index] & 0xFF) << 24 | (this.data[(index + 1)] & 0xFF) << 16 | (this.data[(index + 2)] & 0xFF) << 8 | this.data[(index + 3)] & 0xFF);
/*      */         
/*  893 */         i++;
/*  894 */         srcX++;
/*  895 */         if (srcX >= this.width) {
/*  896 */           srcY++;
/*  897 */           index = srcY * this.bytesPerLine;
/*  898 */           srcX = 0;
/*      */         } else {
/*  900 */           index += 4;
/*      */         }
/*      */       }
/*  903 */       return;
/*      */     case 24: 
/*  905 */       int index = y * this.bytesPerLine + x * 3;
/*  906 */       for (int j = 0; j < getWidth; j++) {
/*  907 */         pixels[i] = ((this.data[index] & 0xFF) << 16 | (this.data[(index + 1)] & 0xFF) << 8 | this.data[(index + 2)] & 0xFF);
/*      */         
/*  909 */         i++;
/*  910 */         srcX++;
/*  911 */         if (srcX >= this.width) {
/*  912 */           srcY++;
/*  913 */           index = srcY * this.bytesPerLine;
/*  914 */           srcX = 0;
/*      */         } else {
/*  916 */           index += 3;
/*      */         }
/*      */       }
/*  919 */       return;
/*      */     case 16: 
/*  921 */       int index = y * this.bytesPerLine + x * 2;
/*  922 */       for (int j = 0; j < getWidth; j++) {
/*  923 */         pixels[i] = (((this.data[(index + 1)] & 0xFF) << 8) + (this.data[index] & 0xFF));
/*  924 */         i++;
/*  925 */         srcX++;
/*  926 */         if (srcX >= this.width) {
/*  927 */           srcY++;
/*  928 */           index = srcY * this.bytesPerLine;
/*  929 */           srcX = 0;
/*      */         } else {
/*  931 */           index += 2;
/*      */         }
/*      */       }
/*  934 */       return;
/*      */     case 8: 
/*  936 */       int index = y * this.bytesPerLine + x;
/*  937 */       for (int j = 0; j < getWidth; j++) {
/*  938 */         pixels[i] = (this.data[index] & 0xFF);
/*  939 */         i++;
/*  940 */         srcX++;
/*  941 */         if (srcX >= this.width) {
/*  942 */           srcY++;
/*  943 */           index = srcY * this.bytesPerLine;
/*  944 */           srcX = 0;
/*      */         } else {
/*  946 */           index++;
/*      */         }
/*      */       }
/*  949 */       return;
/*      */     case 4: 
/*  951 */       int index = y * this.bytesPerLine + (x >> 1);
/*  952 */       if ((x & 0x1) == 1) {
/*  953 */         int theByte = this.data[index] & 0xFF;
/*  954 */         pixels[i] = (theByte & 0xF);
/*  955 */         i++;
/*  956 */         n--;
/*  957 */         srcX++;
/*  958 */         if (srcX >= this.width) {
/*  959 */           srcY++;
/*  960 */           index = srcY * this.bytesPerLine;
/*  961 */           srcX = 0;
/*      */         } else {
/*  963 */           index++;
/*      */         }
/*      */       }
/*  966 */       while (n > 1) {
/*  967 */         int theByte = this.data[index] & 0xFF;
/*  968 */         pixels[i] = (theByte >> 4);
/*  969 */         i++;
/*  970 */         n--;
/*  971 */         srcX++;
/*  972 */         if (srcX >= this.width) {
/*  973 */           srcY++;
/*  974 */           index = srcY * this.bytesPerLine;
/*  975 */           srcX = 0;
/*      */         } else {
/*  977 */           pixels[i] = (theByte & 0xF);
/*  978 */           i++;
/*  979 */           n--;
/*  980 */           srcX++;
/*  981 */           if (srcX >= this.width) {
/*  982 */             srcY++;
/*  983 */             index = srcY * this.bytesPerLine;
/*  984 */             srcX = 0;
/*      */           } else {
/*  986 */             index++;
/*      */           }
/*      */         }
/*      */       }
/*  990 */       if (n > 0) {
/*  991 */         int theByte = this.data[index] & 0xFF;
/*  992 */         pixels[i] = (theByte >> 4);
/*      */       }
/*  994 */       return;
/*      */     case 2: 
/*  996 */       int index = y * this.bytesPerLine + (x >> 2);
/*  997 */       int theByte = this.data[index] & 0xFF;
/*      */       
/*  999 */       while (n > 0) {
/* 1000 */         int offset = 3 - srcX % 4;
/* 1001 */         int mask = 3 << offset * 2;
/* 1002 */         pixels[i] = ((byte)((theByte & mask) >> offset * 2));
/* 1003 */         i++;
/* 1004 */         n--;
/* 1005 */         srcX++;
/* 1006 */         if (srcX >= this.width) {
/* 1007 */           srcY++;
/* 1008 */           index = srcY * this.bytesPerLine;
/* 1009 */           if (n > 0) theByte = this.data[index] & 0xFF;
/* 1010 */           srcX = 0;
/*      */         }
/* 1012 */         else if (offset == 0) {
/* 1013 */           index++;
/* 1014 */           theByte = this.data[index] & 0xFF;
/*      */         }
/*      */       }
/*      */       
/* 1018 */       return;
/*      */     case 1: 
/* 1020 */       int index = y * this.bytesPerLine + (x >> 3);
/* 1021 */       int theByte = this.data[index] & 0xFF;
/* 1022 */       while (n > 0) {
/* 1023 */         int mask = 1 << 7 - (srcX & 0x7);
/* 1024 */         if ((theByte & mask) == 0) {
/* 1025 */           pixels[i] = 0;
/*      */         } else {
/* 1027 */           pixels[i] = 1;
/*      */         }
/* 1029 */         i++;
/* 1030 */         n--;
/* 1031 */         srcX++;
/* 1032 */         if (srcX >= this.width) {
/* 1033 */           srcY++;
/* 1034 */           index = srcY * this.bytesPerLine;
/* 1035 */           if (n > 0) theByte = this.data[index] & 0xFF;
/* 1036 */           srcX = 0;
/*      */         }
/* 1038 */         else if (mask == 1) {
/* 1039 */           index++;
/* 1040 */           if (n > 0) { theByte = this.data[index] & 0xFF;
/*      */           }
/*      */         }
/*      */       }
/* 1044 */       return;
/*      */     }
/* 1046 */     SWT.error(38);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public RGB[] getRGBs()
/*      */   {
/* 1059 */     return this.palette.getRGBs();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ImageData getTransparencyMask()
/*      */   {
/* 1071 */     if (getTransparencyType() == 2) {
/* 1072 */       return new ImageData(this.width, this.height, 1, bwPalette(), this.maskPad, this.maskData);
/*      */     }
/* 1074 */     return colorMaskImage(this.transparentPixel);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getTransparencyType()
/*      */   {
/* 1086 */     if (this.maskData != null) return 2;
/* 1087 */     if (this.transparentPixel != -1) return 4;
/* 1088 */     if (this.alphaData != null) return 1;
/* 1089 */     return 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   int getByteOrder()
/*      */   {
/* 1098 */     return this.depth != 16 ? 1 : 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ImageData scaledTo(int width, int height)
/*      */   {
/* 1113 */     boolean flipX = width < 0;
/* 1114 */     if (flipX) width = -width;
/* 1115 */     boolean flipY = height < 0;
/* 1116 */     if (flipY) { height = -height;
/*      */     }
/* 1118 */     ImageData dest = new ImageData(width, height, this.depth, this.palette, this.scanlinePad, null, 0, null, null, -1, this.transparentPixel, this.type, this.x, this.y, this.disposalMethod, this.delayTime);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1125 */     if (this.palette.isDirect) { blit(1, this.data, this.depth, this.bytesPerLine, 
/* 1126 */         getByteOrder(), 0, 0, this.width, this.height, 0, 0, 0, 255, null, 0, 0, 0, dest.data, dest.depth, dest.bytesPerLine, dest
/*      */         
/* 1128 */         .getByteOrder(), 0, 0, dest.width, dest.height, 0, 0, 0, flipX, flipY);
/*      */     } else {
/* 1130 */       blit(1, this.data, this.depth, this.bytesPerLine, 
/* 1131 */         getByteOrder(), 0, 0, this.width, this.height, null, null, null, 255, null, 0, 0, 0, dest.data, dest.depth, dest.bytesPerLine, dest
/*      */         
/* 1133 */         .getByteOrder(), 0, 0, dest.width, dest.height, null, null, null, flipX, flipY);
/*      */     }
/*      */     
/*      */ 
/* 1137 */     if (this.maskData != null) {
/* 1138 */       dest.maskPad = this.maskPad;
/* 1139 */       int destBpl = (dest.width + 7) / 8;
/* 1140 */       destBpl = (destBpl + (dest.maskPad - 1)) / dest.maskPad * dest.maskPad;
/* 1141 */       dest.maskData = new byte[destBpl * dest.height];
/* 1142 */       int srcBpl = (this.width + 7) / 8;
/* 1143 */       srcBpl = (srcBpl + (this.maskPad - 1)) / this.maskPad * this.maskPad;
/* 1144 */       blit(1, this.maskData, 1, srcBpl, 1, 0, 0, this.width, this.height, null, null, null, 255, null, 0, 0, 0, dest.maskData, 1, destBpl, 1, 0, 0, dest.width, dest.height, null, null, null, flipX, flipY);
/*      */ 
/*      */ 
/*      */ 
/*      */     }
/* 1149 */     else if (this.alpha != -1) {
/* 1150 */       dest.alpha = this.alpha;
/* 1151 */     } else if (this.alphaData != null) {
/* 1152 */       dest.alphaData = new byte[dest.width * dest.height];
/* 1153 */       blit(1, this.alphaData, 8, this.width, 1, 0, 0, this.width, this.height, null, null, null, 255, null, 0, 0, 0, dest.alphaData, 8, dest.width, 1, 0, 0, dest.width, dest.height, null, null, null, flipX, flipY);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1159 */     return dest;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAlpha(int x, int y, int alpha)
/*      */   {
/* 1177 */     if ((x >= this.width) || (y >= this.height) || (x < 0) || (y < 0) || (alpha < 0) || (alpha > 255)) {
/* 1178 */       SWT.error(5);
/*      */     }
/* 1180 */     if (this.alphaData == null) this.alphaData = new byte[this.width * this.height];
/* 1181 */     this.alphaData[(y * this.width + x)] = ((byte)alpha);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAlphas(int x, int y, int putWidth, byte[] alphas, int startIndex)
/*      */   {
/* 1205 */     if (alphas == null) SWT.error(4);
/* 1206 */     if ((putWidth < 0) || (x >= this.width) || (y >= this.height) || (x < 0) || (y < 0)) SWT.error(5);
/* 1207 */     if (putWidth == 0) { return;
/*      */     }
/* 1209 */     if (this.alphaData == null) { this.alphaData = new byte[this.width * this.height];
/*      */     }
/* 1211 */     System.arraycopy(alphas, startIndex, this.alphaData, y * this.width + x, putWidth);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPixel(int x, int y, int pixelValue)
/*      */   {
/* 1230 */     if ((x >= this.width) || (y >= this.height) || (x < 0) || (y < 0)) { SWT.error(5);
/*      */     }
/*      */     
/*      */ 
/* 1234 */     switch (this.depth) {
/*      */     case 32: 
/* 1236 */       int index = y * this.bytesPerLine + x * 4;
/* 1237 */       this.data[index] = ((byte)(pixelValue >> 24 & 0xFF));
/* 1238 */       this.data[(index + 1)] = ((byte)(pixelValue >> 16 & 0xFF));
/* 1239 */       this.data[(index + 2)] = ((byte)(pixelValue >> 8 & 0xFF));
/* 1240 */       this.data[(index + 3)] = ((byte)(pixelValue & 0xFF));
/* 1241 */       return;
/*      */     case 24: 
/* 1243 */       int index = y * this.bytesPerLine + x * 3;
/* 1244 */       this.data[index] = ((byte)(pixelValue >> 16 & 0xFF));
/* 1245 */       this.data[(index + 1)] = ((byte)(pixelValue >> 8 & 0xFF));
/* 1246 */       this.data[(index + 2)] = ((byte)(pixelValue & 0xFF));
/* 1247 */       return;
/*      */     case 16: 
/* 1249 */       int index = y * this.bytesPerLine + x * 2;
/* 1250 */       this.data[(index + 1)] = ((byte)(pixelValue >> 8 & 0xFF));
/* 1251 */       this.data[index] = ((byte)(pixelValue & 0xFF));
/* 1252 */       return;
/*      */     case 8: 
/* 1254 */       int index = y * this.bytesPerLine + x;
/* 1255 */       this.data[index] = ((byte)(pixelValue & 0xFF));
/* 1256 */       return;
/*      */     case 4: 
/* 1258 */       int index = y * this.bytesPerLine + (x >> 1);
/* 1259 */       if ((x & 0x1) == 0) {
/* 1260 */         this.data[index] = ((byte)(this.data[index] & 0xF | (pixelValue & 0xF) << 4));
/*      */       } else {
/* 1262 */         this.data[index] = ((byte)(this.data[index] & 0xF0 | pixelValue & 0xF));
/*      */       }
/* 1264 */       return;
/*      */     case 2: 
/* 1266 */       int index = y * this.bytesPerLine + (x >> 2);
/* 1267 */       byte theByte = this.data[index];
/* 1268 */       int offset = 3 - x % 4;
/* 1269 */       int mask = 0xFF ^ 3 << offset * 2;
/* 1270 */       this.data[index] = ((byte)(this.data[index] & mask | pixelValue << offset * 2));
/* 1271 */       return;
/*      */     case 1: 
/* 1273 */       int index = y * this.bytesPerLine + (x >> 3);
/* 1274 */       byte theByte = this.data[index];
/* 1275 */       int mask = 1 << 7 - (x & 0x7);
/* 1276 */       if ((pixelValue & 0x1) == 1) {
/* 1277 */         this.data[index] = ((byte)(theByte | mask));
/*      */       } else {
/* 1279 */         this.data[index] = ((byte)(theByte & (mask ^ 0xFFFFFFFF)));
/*      */       }
/* 1281 */       return;
/*      */     }
/* 1283 */     SWT.error(38);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPixels(int x, int y, int putWidth, byte[] pixels, int startIndex)
/*      */   {
/* 1310 */     if (pixels == null) SWT.error(4);
/* 1311 */     if ((putWidth < 0) || (x >= this.width) || (y >= this.height) || (x < 0) || (y < 0)) SWT.error(5);
/* 1312 */     if (putWidth == 0) { return;
/*      */     }
/*      */     
/*      */ 
/* 1316 */     int n = putWidth;
/* 1317 */     int i = startIndex;
/* 1318 */     int srcX = x;int srcY = y;
/* 1319 */     switch (this.depth) {
/*      */     case 8: 
/* 1321 */       int index = y * this.bytesPerLine + x;
/* 1322 */       for (int j = 0; j < putWidth; j++) {
/* 1323 */         this.data[index] = ((byte)(pixels[i] & 0xFF));
/* 1324 */         i++;
/* 1325 */         srcX++;
/* 1326 */         if (srcX >= this.width) {
/* 1327 */           srcY++;
/* 1328 */           index = srcY * this.bytesPerLine;
/* 1329 */           srcX = 0;
/*      */         } else {
/* 1331 */           index++;
/*      */         }
/*      */       }
/* 1334 */       return;
/*      */     case 4: 
/* 1336 */       int index = y * this.bytesPerLine + (x >> 1);
/* 1337 */       boolean high = (x & 0x1) == 0;
/* 1338 */       while (n > 0) {
/* 1339 */         int theByte = pixels[i] & 0xF;
/* 1340 */         if (high) {
/* 1341 */           this.data[index] = ((byte)(this.data[index] & 0xF | theByte << 4));
/*      */         } else {
/* 1343 */           this.data[index] = ((byte)(this.data[index] & 0xF0 | theByte));
/*      */         }
/* 1345 */         i++;
/* 1346 */         n--;
/* 1347 */         srcX++;
/* 1348 */         if (srcX >= this.width) {
/* 1349 */           srcY++;
/* 1350 */           index = srcY * this.bytesPerLine;
/* 1351 */           high = true;
/* 1352 */           srcX = 0;
/*      */         } else {
/* 1354 */           if (!high) index++;
/* 1355 */           high = !high;
/*      */         }
/*      */       }
/* 1358 */       return;
/*      */     case 2: 
/* 1360 */       byte[] masks = { -4, -13, -49, 63 };
/* 1361 */       int index = y * this.bytesPerLine + (x >> 2);
/* 1362 */       int offset = 3 - x % 4;
/* 1363 */       while (n > 0) {
/* 1364 */         int theByte = pixels[i] & 0x3;
/* 1365 */         this.data[index] = ((byte)(this.data[index] & masks[offset] | theByte << offset * 2));
/* 1366 */         i++;
/* 1367 */         n--;
/* 1368 */         srcX++;
/* 1369 */         if (srcX >= this.width) {
/* 1370 */           srcY++;
/* 1371 */           index = srcY * this.bytesPerLine;
/* 1372 */           offset = 0;
/* 1373 */           srcX = 0;
/*      */         }
/* 1375 */         else if (offset == 0) {
/* 1376 */           index++;
/* 1377 */           offset = 3;
/*      */         } else {
/* 1379 */           offset--;
/*      */         }
/*      */       }
/*      */       
/* 1383 */       return;
/*      */     case 1: 
/* 1385 */       int index = y * this.bytesPerLine + (x >> 3);
/* 1386 */       while (n > 0) {
/* 1387 */         int mask = 1 << 7 - (srcX & 0x7);
/* 1388 */         if ((pixels[i] & 0x1) == 1) {
/* 1389 */           this.data[index] = ((byte)(this.data[index] & 0xFF | mask));
/*      */         } else {
/* 1391 */           this.data[index] = ((byte)(this.data[index] & 0xFF & (mask ^ 0xFFFFFFFF)));
/*      */         }
/* 1393 */         i++;
/* 1394 */         n--;
/* 1395 */         srcX++;
/* 1396 */         if (srcX >= this.width) {
/* 1397 */           srcY++;
/* 1398 */           index = srcY * this.bytesPerLine;
/* 1399 */           srcX = 0;
/*      */         }
/* 1401 */         else if (mask == 1) {
/* 1402 */           index++;
/*      */         }
/*      */       }
/*      */       
/* 1406 */       return;
/*      */     }
/* 1408 */     SWT.error(38);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setPixels(int x, int y, int putWidth, int[] pixels, int startIndex)
/*      */   {
/* 1434 */     if (pixels == null) SWT.error(4);
/* 1435 */     if ((putWidth < 0) || (x >= this.width) || (y >= this.height) || (x < 0) || (y < 0)) SWT.error(5);
/* 1436 */     if (putWidth == 0) { return;
/*      */     }
/*      */     
/*      */ 
/* 1440 */     int n = putWidth;
/* 1441 */     int i = startIndex;
/*      */     
/* 1443 */     int srcX = x;int srcY = y;
/* 1444 */     switch (this.depth) {
/*      */     case 32: 
/* 1446 */       int index = y * this.bytesPerLine + x * 4;
/* 1447 */       for (int j = 0; j < putWidth; j++) {
/* 1448 */         int pixel = pixels[i];
/* 1449 */         this.data[index] = ((byte)(pixel >> 24 & 0xFF));
/* 1450 */         this.data[(index + 1)] = ((byte)(pixel >> 16 & 0xFF));
/* 1451 */         this.data[(index + 2)] = ((byte)(pixel >> 8 & 0xFF));
/* 1452 */         this.data[(index + 3)] = ((byte)(pixel & 0xFF));
/* 1453 */         i++;
/* 1454 */         srcX++;
/* 1455 */         if (srcX >= this.width) {
/* 1456 */           srcY++;
/* 1457 */           index = srcY * this.bytesPerLine;
/* 1458 */           srcX = 0;
/*      */         } else {
/* 1460 */           index += 4;
/*      */         }
/*      */       }
/* 1463 */       return;
/*      */     case 24: 
/* 1465 */       int index = y * this.bytesPerLine + x * 3;
/* 1466 */       for (int j = 0; j < putWidth; j++) {
/* 1467 */         int pixel = pixels[i];
/* 1468 */         this.data[index] = ((byte)(pixel >> 16 & 0xFF));
/* 1469 */         this.data[(index + 1)] = ((byte)(pixel >> 8 & 0xFF));
/* 1470 */         this.data[(index + 2)] = ((byte)(pixel & 0xFF));
/* 1471 */         i++;
/* 1472 */         srcX++;
/* 1473 */         if (srcX >= this.width) {
/* 1474 */           srcY++;
/* 1475 */           index = srcY * this.bytesPerLine;
/* 1476 */           srcX = 0;
/*      */         } else {
/* 1478 */           index += 3;
/*      */         }
/*      */       }
/* 1481 */       return;
/*      */     case 16: 
/* 1483 */       int index = y * this.bytesPerLine + x * 2;
/* 1484 */       for (int j = 0; j < putWidth; j++) {
/* 1485 */         int pixel = pixels[i];
/* 1486 */         this.data[index] = ((byte)(pixel & 0xFF));
/* 1487 */         this.data[(index + 1)] = ((byte)(pixel >> 8 & 0xFF));
/* 1488 */         i++;
/* 1489 */         srcX++;
/* 1490 */         if (srcX >= this.width) {
/* 1491 */           srcY++;
/* 1492 */           index = srcY * this.bytesPerLine;
/* 1493 */           srcX = 0;
/*      */         } else {
/* 1495 */           index += 2;
/*      */         }
/*      */       }
/* 1498 */       return;
/*      */     case 8: 
/* 1500 */       int index = y * this.bytesPerLine + x;
/* 1501 */       for (int j = 0; j < putWidth; j++) {
/* 1502 */         this.data[index] = ((byte)(pixels[i] & 0xFF));
/* 1503 */         i++;
/* 1504 */         srcX++;
/* 1505 */         if (srcX >= this.width) {
/* 1506 */           srcY++;
/* 1507 */           index = srcY * this.bytesPerLine;
/* 1508 */           srcX = 0;
/*      */         } else {
/* 1510 */           index++;
/*      */         }
/*      */       }
/* 1513 */       return;
/*      */     case 4: 
/* 1515 */       int index = y * this.bytesPerLine + (x >> 1);
/* 1516 */       boolean high = (x & 0x1) == 0;
/* 1517 */       while (n > 0) {
/* 1518 */         int theByte = pixels[i] & 0xF;
/* 1519 */         if (high) {
/* 1520 */           this.data[index] = ((byte)(this.data[index] & 0xF | theByte << 4));
/*      */         } else {
/* 1522 */           this.data[index] = ((byte)(this.data[index] & 0xF0 | theByte));
/*      */         }
/* 1524 */         i++;
/* 1525 */         n--;
/* 1526 */         srcX++;
/* 1527 */         if (srcX >= this.width) {
/* 1528 */           srcY++;
/* 1529 */           index = srcY * this.bytesPerLine;
/* 1530 */           high = true;
/* 1531 */           srcX = 0;
/*      */         } else {
/* 1533 */           if (!high) index++;
/* 1534 */           high = !high;
/*      */         }
/*      */       }
/* 1537 */       return;
/*      */     case 2: 
/* 1539 */       byte[] masks = { -4, -13, -49, 63 };
/* 1540 */       int index = y * this.bytesPerLine + (x >> 2);
/* 1541 */       int offset = 3 - x % 4;
/* 1542 */       while (n > 0) {
/* 1543 */         int theByte = pixels[i] & 0x3;
/* 1544 */         this.data[index] = ((byte)(this.data[index] & masks[offset] | theByte << offset * 2));
/* 1545 */         i++;
/* 1546 */         n--;
/* 1547 */         srcX++;
/* 1548 */         if (srcX >= this.width) {
/* 1549 */           srcY++;
/* 1550 */           index = srcY * this.bytesPerLine;
/* 1551 */           offset = 3;
/* 1552 */           srcX = 0;
/*      */         }
/* 1554 */         else if (offset == 0) {
/* 1555 */           index++;
/* 1556 */           offset = 3;
/*      */         } else {
/* 1558 */           offset--;
/*      */         }
/*      */       }
/*      */       
/* 1562 */       return;
/*      */     case 1: 
/* 1564 */       int index = y * this.bytesPerLine + (x >> 3);
/* 1565 */       while (n > 0) {
/* 1566 */         int mask = 1 << 7 - (srcX & 0x7);
/* 1567 */         if ((pixels[i] & 0x1) == 1) {
/* 1568 */           this.data[index] = ((byte)(this.data[index] & 0xFF | mask));
/*      */         } else {
/* 1570 */           this.data[index] = ((byte)(this.data[index] & 0xFF & (mask ^ 0xFFFFFFFF)));
/*      */         }
/* 1572 */         i++;
/* 1573 */         n--;
/* 1574 */         srcX++;
/* 1575 */         if (srcX >= this.width) {
/* 1576 */           srcY++;
/* 1577 */           index = srcY * this.bytesPerLine;
/* 1578 */           srcX = 0;
/*      */         }
/* 1580 */         else if (mask == 1) {
/* 1581 */           index++;
/*      */         }
/*      */       }
/*      */       
/* 1585 */       return;
/*      */     }
/* 1587 */     SWT.error(38);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   static PaletteData bwPalette()
/*      */   {
/* 1594 */     return new PaletteData(new RGB[] { new RGB(0, 0, 0), new RGB(255, 255, 255) });
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   static int getMSBOffset(int mask)
/*      */   {
/* 1602 */     for (int i = 31; i >= 0; i--) {
/* 1603 */       if ((mask >> i & 0x1) != 0) return i + 1;
/*      */     }
/* 1605 */     return 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   static int closestMatch(int depth, byte red, byte green, byte blue, int redMask, int greenMask, int blueMask, byte[] reds, byte[] greens, byte[] blues)
/*      */   {
/* 1612 */     if (depth > 8) {
/* 1613 */       int rshift = 32 - getMSBOffset(redMask);
/* 1614 */       int gshift = 32 - getMSBOffset(greenMask);
/* 1615 */       int bshift = 32 - getMSBOffset(blueMask);
/* 1616 */       return red << 24 >>> rshift & redMask | green << 24 >>> gshift & greenMask | blue << 24 >>> bshift & blueMask;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1621 */     int minDistance = Integer.MAX_VALUE;
/* 1622 */     int nearestPixel = 0;
/* 1623 */     int n = reds.length;
/* 1624 */     for (int j = 0; j < n; j++) {
/* 1625 */       int r = (reds[j] & 0xFF) - (red & 0xFF);
/* 1626 */       int g = (greens[j] & 0xFF) - (green & 0xFF);
/* 1627 */       int b = (blues[j] & 0xFF) - (blue & 0xFF);
/* 1628 */       int distance = r * r + g * g + b * b;
/* 1629 */       if (distance < minDistance) {
/* 1630 */         nearestPixel = j;
/* 1631 */         if (distance == 0) break;
/* 1632 */         minDistance = distance;
/*      */       }
/*      */     }
/* 1635 */     return nearestPixel;
/*      */   }
/*      */   
/*      */   static final ImageData convertMask(ImageData mask) {
/* 1639 */     if (mask.depth == 1) return mask;
/* 1640 */     PaletteData palette = new PaletteData(new RGB[] { new RGB(0, 0, 0), new RGB(255, 255, 255) });
/* 1641 */     ImageData newMask = new ImageData(mask.width, mask.height, 1, palette);
/*      */     
/* 1643 */     int blackIndex = 0;
/* 1644 */     RGB[] rgbs = mask.getRGBs();
/* 1645 */     if (rgbs != null) {
/* 1646 */       while ((blackIndex < rgbs.length) && 
/* 1647 */         (!rgbs[blackIndex].equals(palette.colors[0]))) {
/* 1648 */         blackIndex++;
/*      */       }
/*      */     }
/* 1651 */     int[] pixels = new int[mask.width];
/* 1652 */     for (int y = 0; y < mask.height; y++) {
/* 1653 */       mask.getPixels(0, y, mask.width, pixels, 0);
/* 1654 */       for (int i = 0; i < pixels.length; i++) {
/* 1655 */         if (pixels[i] == blackIndex) {
/* 1656 */           pixels[i] = 0;
/*      */         } else {
/* 1658 */           pixels[i] = 1;
/*      */         }
/*      */       }
/* 1661 */       newMask.setPixels(0, y, mask.width, pixels, 0);
/*      */     }
/* 1663 */     return newMask;
/*      */   }
/*      */   
/*      */   static final byte[] convertPad(byte[] data, int width, int height, int depth, int pad, int newPad) {
/* 1667 */     if (pad == newPad) return data;
/* 1668 */     int stride = (width * depth + 7) / 8;
/* 1669 */     int bpl = (stride + (pad - 1)) / pad * pad;
/* 1670 */     int newBpl = (stride + (newPad - 1)) / newPad * newPad;
/* 1671 */     byte[] newData = new byte[height * newBpl];
/* 1672 */     int srcIndex = 0;int destIndex = 0;
/* 1673 */     for (int y = 0; y < height; y++) {
/* 1674 */       System.arraycopy(data, srcIndex, newData, destIndex, stride);
/* 1675 */       srcIndex += bpl;
/* 1676 */       destIndex += newBpl;
/*      */     }
/* 1678 */     return newData;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static void blit(int op, byte[] srcData, int srcDepth, int srcStride, int srcOrder, int srcX, int srcY, int srcWidth, int srcHeight, int srcRedMask, int srcGreenMask, int srcBlueMask, int alphaMode, byte[] alphaData, int alphaStride, int alphaX, int alphaY, byte[] destData, int destDepth, int destStride, int destOrder, int destX, int destY, int destWidth, int destHeight, int destRedMask, int destGreenMask, int destBlueMask, boolean flipX, boolean flipY)
/*      */   {
/* 1782 */     if ((destWidth <= 0) || (destHeight <= 0) || (alphaMode == 0)) { return;
/*      */     }
/*      */     
/* 1785 */     int srcAlphaMask = 0;int destAlphaMask = 0;
/*      */     
/*      */ 
/* 1788 */     int dwm1 = destWidth - 1;
/* 1789 */     int sfxi = dwm1 != 0 ? (int)(((srcWidth << 16) - 1L) / dwm1) : 0;
/* 1790 */     int dhm1 = destHeight - 1;
/* 1791 */     int sfyi = dhm1 != 0 ? (int)(((srcHeight << 16) - 1L) / dhm1) : 0;
/*      */     int stype;
/*      */     int stype;
/*      */     int stype;
/* 1795 */     int stype; switch (srcDepth) {
/*      */     case 8: 
/* 1797 */       int sbpp = 1;
/* 1798 */       stype = 0;
/* 1799 */       break;
/*      */     case 16: 
/* 1801 */       int sbpp = 2;
/* 1802 */       stype = srcOrder == 1 ? 1 : 2;
/* 1803 */       break;
/*      */     case 24: 
/* 1805 */       int sbpp = 3;
/* 1806 */       stype = 3;
/* 1807 */       break;
/*      */     case 32: 
/* 1809 */       int sbpp = 4;
/* 1810 */       stype = srcOrder == 1 ? 4 : 5;
/* 1811 */       break;
/*      */     default: 
/*      */       return; }
/*      */     int stype;
/*      */     int sbpp;
/* 1816 */     int spr = srcY * srcStride + srcX * sbpp;
/*      */     int dtype;
/*      */     int dtype;
/*      */     int dtype;
/* 1820 */     int dtype; switch (destDepth) {
/*      */     case 8: 
/* 1822 */       int dbpp = 1;
/* 1823 */       dtype = 0;
/* 1824 */       break;
/*      */     case 16: 
/* 1826 */       int dbpp = 2;
/* 1827 */       dtype = destOrder == 1 ? 1 : 2;
/* 1828 */       break;
/*      */     case 24: 
/* 1830 */       int dbpp = 3;
/* 1831 */       dtype = 3;
/* 1832 */       break;
/*      */     case 32: 
/* 1834 */       int dbpp = 4;
/* 1835 */       dtype = destOrder == 1 ? 4 : 5;
/* 1836 */       break;
/*      */     default: 
/*      */       return; }
/*      */     int dtype;
/*      */     int dbpp;
/* 1841 */     int dpr = (flipY ? destY + dhm1 : destY) * destStride + (flipX ? destX + dwm1 : destX) * dbpp;
/* 1842 */     int dprxi = flipX ? -dbpp : dbpp;
/* 1843 */     int dpryi = flipY ? -destStride : destStride;
/*      */     
/*      */     int apr;
/*      */     
/* 1847 */     if ((op & 0x2) != 0) { int apr;
/* 1848 */       int apr; int apr; int apr; switch (alphaMode) {
/*      */       case -3: 
/*      */       case -1: 
/* 1851 */         if (alphaData == null) alphaMode = 65536;
/* 1852 */         apr = alphaY * alphaStride + alphaX;
/* 1853 */         break;
/*      */       case -4: 
/* 1855 */         if (alphaData == null) alphaMode = 65536;
/* 1856 */         alphaStride <<= 3;
/* 1857 */         apr = alphaY * alphaStride + alphaX;
/* 1858 */         break;
/*      */       
/*      */       case -5: 
/* 1861 */         return;
/*      */       case -6: 
/* 1863 */         if (alphaData == null) alphaMode = 65536;
/* 1864 */         apr = 0;
/* 1865 */         break;
/*      */       default: 
/* 1867 */         alphaMode = (alphaMode << 16) / 255;
/*      */       case -2: 
/* 1869 */         apr = 0;
/* 1870 */         break;
/*      */       }
/*      */     } else {
/* 1873 */       alphaMode = 65536;
/* 1874 */       apr = 0;
/*      */     }
/*      */     
/*      */ 
/* 1878 */     int dp = dpr;
/* 1879 */     int sp = spr;
/* 1880 */     if ((alphaMode == 65536) && (stype == dtype) && (srcRedMask == destRedMask) && (srcGreenMask == destGreenMask) && (srcBlueMask == destBlueMask) && (srcAlphaMask == destAlphaMask))
/*      */     {
/*      */ 
/*      */ 
/* 1884 */       switch (sbpp) {
/*      */       case 1: 
/* 1886 */         int dy = destHeight; for (int sfy = sfyi; dy > 0; dp = dpr += dpryi) {
/* 1887 */           int dx = destWidth; for (int sfx = sfxi; dx > 0; sfx = (sfx & 0xFFFF) + sfxi) {
/* 1888 */             destData[dp] = srcData[sp];
/* 1889 */             sp += (sfx >>> 16);dx--;dp += dprxi;
/*      */           }
/* 1886 */           dy--;sp = spr += (sfy >>> 16) * srcStride;sfy = (sfy & 0xFFFF) + sfyi;
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 1892 */         break;
/*      */       case 2: 
/* 1894 */         int dy = destHeight; for (int sfy = sfyi; dy > 0; dp = dpr += dpryi) {
/* 1895 */           int dx = destWidth; for (int sfx = sfxi; dx > 0; sfx = (sfx & 0xFFFF) + sfxi) {
/* 1896 */             destData[dp] = srcData[sp];
/* 1897 */             destData[(dp + 1)] = srcData[(sp + 1)];
/* 1898 */             sp += (sfx >>> 16) * 2;dx--;dp += dprxi;
/*      */           }
/* 1894 */           dy--;sp = spr += (sfy >>> 16) * srcStride;sfy = (sfy & 0xFFFF) + sfyi;
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1901 */         break;
/*      */       case 3: 
/* 1903 */         int dy = destHeight; for (int sfy = sfyi; dy > 0; dp = dpr += dpryi) {
/* 1904 */           int dx = destWidth; for (int sfx = sfxi; dx > 0; sfx = (sfx & 0xFFFF) + sfxi) {
/* 1905 */             destData[dp] = srcData[sp];
/* 1906 */             destData[(dp + 1)] = srcData[(sp + 1)];
/* 1907 */             destData[(dp + 2)] = srcData[(sp + 2)];
/* 1908 */             sp += (sfx >>> 16) * 3;dx--;dp += dprxi;
/*      */           }
/* 1903 */           dy--;sp = spr += (sfy >>> 16) * srcStride;sfy = (sfy & 0xFFFF) + sfyi;
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1911 */         break;
/*      */       case 4: 
/* 1913 */         int dy = destHeight; for (int sfy = sfyi; dy > 0; dp = dpr += dpryi) {
/* 1914 */           int dx = destWidth; for (int sfx = sfxi; dx > 0; sfx = (sfx & 0xFFFF) + sfxi) {
/* 1915 */             destData[dp] = srcData[sp];
/* 1916 */             destData[(dp + 1)] = srcData[(sp + 1)];
/* 1917 */             destData[(dp + 2)] = srcData[(sp + 2)];
/* 1918 */             destData[(dp + 3)] = srcData[(sp + 3)];
/* 1919 */             sp += (sfx >>> 16) * 4;dx--;dp += dprxi;
/*      */           }
/* 1913 */           dy--;sp = spr += (sfy >>> 16) * srcStride;sfy = (sfy & 0xFFFF) + sfyi;
/*      */         }
/*      */       }
/*      */       
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1924 */       return;
/*      */     }
/*      */     
/* 1927 */     if ((alphaMode == 65536) && (stype == 4) && (dtype == 4) && 
/* 1928 */       (srcRedMask == 65280) && (srcGreenMask == 16711680) && (srcBlueMask == -16777216) && (destRedMask == 16711680) && (destGreenMask == 65280) && (destBlueMask == 255)) {
/* 1929 */       int dy = destHeight; for (int sfy = sfyi; dy > 0; dp = dpr += dpryi) {
/* 1930 */         int dx = destWidth; for (int sfx = sfxi; dx > 0; sfx = (sfx & 0xFFFF) + sfxi) {
/* 1931 */           destData[dp] = srcData[(sp + 3)];
/* 1932 */           destData[(dp + 1)] = srcData[(sp + 2)];
/* 1933 */           destData[(dp + 2)] = srcData[(sp + 1)];
/* 1934 */           destData[(dp + 3)] = srcData[sp];
/* 1935 */           sp += (sfx >>> 16) * 4;dx--;dp += dprxi;
/*      */         }
/* 1929 */         dy--;sp = spr += (sfy >>> 16) * srcStride;sfy = (sfy & 0xFFFF) + sfyi;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1938 */       return;
/*      */     }
/*      */     
/*      */ 
/* 1942 */     if ((alphaMode == 65536) && (stype == 3) && (dtype == 4) && 
/* 1943 */       (srcRedMask == 255) && (srcGreenMask == 65280) && (srcBlueMask == 16711680) && (destRedMask == 16711680) && (destGreenMask == 65280) && (destBlueMask == 255)) {
/* 1944 */       int dy = destHeight; for (int sfy = sfyi; dy > 0; dp = dpr += dpryi) {
/* 1945 */         int dx = destWidth; for (int sfx = sfxi; dx > 0; sfx = (sfx & 0xFFFF) + sfxi) {
/* 1946 */           destData[dp] = 0;
/* 1947 */           destData[(dp + 1)] = srcData[(sp + 2)];
/* 1948 */           destData[(dp + 2)] = srcData[(sp + 1)];
/* 1949 */           destData[(dp + 3)] = srcData[sp];
/* 1950 */           sp += (sfx >>> 16) * 3;dx--;dp += dprxi;
/*      */         }
/* 1944 */         dy--;sp = spr += (sfy >>> 16) * srcStride;sfy = (sfy & 0xFFFF) + sfyi;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1953 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1958 */     int srcRedShift = getChannelShift(srcRedMask);
/* 1959 */     byte[] srcReds = ANY_TO_EIGHT[getChannelWidth(srcRedMask, srcRedShift)];
/* 1960 */     int srcGreenShift = getChannelShift(srcGreenMask);
/* 1961 */     byte[] srcGreens = ANY_TO_EIGHT[getChannelWidth(srcGreenMask, srcGreenShift)];
/* 1962 */     int srcBlueShift = getChannelShift(srcBlueMask);
/* 1963 */     byte[] srcBlues = ANY_TO_EIGHT[getChannelWidth(srcBlueMask, srcBlueShift)];
/* 1964 */     int srcAlphaShift = getChannelShift(srcAlphaMask);
/* 1965 */     byte[] srcAlphas = ANY_TO_EIGHT[getChannelWidth(srcAlphaMask, srcAlphaShift)];
/*      */     
/* 1967 */     int destRedShift = getChannelShift(destRedMask);
/* 1968 */     int destRedWidth = getChannelWidth(destRedMask, destRedShift);
/* 1969 */     byte[] destReds = ANY_TO_EIGHT[destRedWidth];
/* 1970 */     int destRedPreShift = 8 - destRedWidth;
/* 1971 */     int destGreenShift = getChannelShift(destGreenMask);
/* 1972 */     int destGreenWidth = getChannelWidth(destGreenMask, destGreenShift);
/* 1973 */     byte[] destGreens = ANY_TO_EIGHT[destGreenWidth];
/* 1974 */     int destGreenPreShift = 8 - destGreenWidth;
/* 1975 */     int destBlueShift = getChannelShift(destBlueMask);
/* 1976 */     int destBlueWidth = getChannelWidth(destBlueMask, destBlueShift);
/* 1977 */     byte[] destBlues = ANY_TO_EIGHT[destBlueWidth];
/* 1978 */     int destBluePreShift = 8 - destBlueWidth;
/* 1979 */     int destAlphaShift = getChannelShift(destAlphaMask);
/* 1980 */     int destAlphaWidth = getChannelWidth(destAlphaMask, destAlphaShift);
/* 1981 */     byte[] destAlphas = ANY_TO_EIGHT[destAlphaWidth];
/* 1982 */     int destAlphaPreShift = 8 - destAlphaWidth;
/*      */     
/* 1984 */     int ap = apr;int alpha = alphaMode;
/* 1985 */     int r = 0;int g = 0;int b = 0;int a = 0;
/* 1986 */     int rq = 0;int gq = 0;int bq = 0;int aq = 0;
/* 1987 */     int dy = destHeight; for (int sfy = sfyi; dy > 0;)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 1992 */       int dx = destWidth; for (int sfx = sfxi; dx > 0;)
/*      */       {
/*      */ 
/*      */ 
/* 1996 */         switch (stype) {
/*      */         case 0: 
/* 1998 */           int data = srcData[sp] & 0xFF;
/* 1999 */           sp += (sfx >>> 16);
/* 2000 */           r = srcReds[((data & srcRedMask) >>> srcRedShift)] & 0xFF;
/* 2001 */           g = srcGreens[((data & srcGreenMask) >>> srcGreenShift)] & 0xFF;
/* 2002 */           b = srcBlues[((data & srcBlueMask) >>> srcBlueShift)] & 0xFF;
/* 2003 */           a = srcAlphas[((data & srcAlphaMask) >>> srcAlphaShift)] & 0xFF;
/* 2004 */           break;
/*      */         case 1: 
/* 2006 */           int data = (srcData[sp] & 0xFF) << 8 | srcData[(sp + 1)] & 0xFF;
/* 2007 */           sp += (sfx >>> 16) * 2;
/* 2008 */           r = srcReds[((data & srcRedMask) >>> srcRedShift)] & 0xFF;
/* 2009 */           g = srcGreens[((data & srcGreenMask) >>> srcGreenShift)] & 0xFF;
/* 2010 */           b = srcBlues[((data & srcBlueMask) >>> srcBlueShift)] & 0xFF;
/* 2011 */           a = srcAlphas[((data & srcAlphaMask) >>> srcAlphaShift)] & 0xFF;
/* 2012 */           break;
/*      */         case 2: 
/* 2014 */           int data = (srcData[(sp + 1)] & 0xFF) << 8 | srcData[sp] & 0xFF;
/* 2015 */           sp += (sfx >>> 16) * 2;
/* 2016 */           r = srcReds[((data & srcRedMask) >>> srcRedShift)] & 0xFF;
/* 2017 */           g = srcGreens[((data & srcGreenMask) >>> srcGreenShift)] & 0xFF;
/* 2018 */           b = srcBlues[((data & srcBlueMask) >>> srcBlueShift)] & 0xFF;
/* 2019 */           a = srcAlphas[((data & srcAlphaMask) >>> srcAlphaShift)] & 0xFF;
/* 2020 */           break;
/*      */         case 3: 
/* 2022 */           int data = ((srcData[sp] & 0xFF) << 8 | srcData[(sp + 1)] & 0xFF) << 8 | srcData[(sp + 2)] & 0xFF;
/*      */           
/*      */ 
/* 2025 */           sp += (sfx >>> 16) * 3;
/* 2026 */           r = srcReds[((data & srcRedMask) >>> srcRedShift)] & 0xFF;
/* 2027 */           g = srcGreens[((data & srcGreenMask) >>> srcGreenShift)] & 0xFF;
/* 2028 */           b = srcBlues[((data & srcBlueMask) >>> srcBlueShift)] & 0xFF;
/* 2029 */           a = srcAlphas[((data & srcAlphaMask) >>> srcAlphaShift)] & 0xFF;
/* 2030 */           break;
/*      */         case 4: 
/* 2032 */           int data = (((srcData[sp] & 0xFF) << 8 | srcData[(sp + 1)] & 0xFF) << 8 | srcData[(sp + 2)] & 0xFF) << 8 | srcData[(sp + 3)] & 0xFF;
/*      */           
/*      */ 
/*      */ 
/* 2036 */           sp += (sfx >>> 16) * 4;
/* 2037 */           r = srcReds[((data & srcRedMask) >>> srcRedShift)] & 0xFF;
/* 2038 */           g = srcGreens[((data & srcGreenMask) >>> srcGreenShift)] & 0xFF;
/* 2039 */           b = srcBlues[((data & srcBlueMask) >>> srcBlueShift)] & 0xFF;
/* 2040 */           a = srcAlphas[((data & srcAlphaMask) >>> srcAlphaShift)] & 0xFF;
/* 2041 */           break;
/*      */         case 5: 
/* 2043 */           int data = (((srcData[(sp + 3)] & 0xFF) << 8 | srcData[(sp + 2)] & 0xFF) << 8 | srcData[(sp + 1)] & 0xFF) << 8 | srcData[sp] & 0xFF;
/*      */           
/*      */ 
/*      */ 
/* 2047 */           sp += (sfx >>> 16) * 4;
/* 2048 */           r = srcReds[((data & srcRedMask) >>> srcRedShift)] & 0xFF;
/* 2049 */           g = srcGreens[((data & srcGreenMask) >>> srcGreenShift)] & 0xFF;
/* 2050 */           b = srcBlues[((data & srcBlueMask) >>> srcBlueShift)] & 0xFF;
/* 2051 */           a = srcAlphas[((data & srcAlphaMask) >>> srcAlphaShift)] & 0xFF;
/*      */         }
/*      */         
/*      */         
/*      */ 
/* 2056 */         switch (alphaMode) {
/*      */         case -1: 
/* 2058 */           alpha = ((alphaData[ap] & 0xFF) << 16) / 255;
/* 2059 */           ap += (sfx >> 16);
/* 2060 */           break;
/*      */         case -2: 
/* 2062 */           alpha = (a << 16) / 255;
/* 2063 */           break;
/*      */         case -3: 
/* 2065 */           alpha = alphaData[ap] != 0 ? 65536 : 0;
/* 2066 */           ap += (sfx >> 16);
/* 2067 */           break;
/*      */         case -4: 
/* 2069 */           alpha = alphaData[(ap >> 3)] << (ap & 0x7) + 9 & 0x10000;
/* 2070 */           ap += (sfx >> 16);
/* 2071 */           break;
/*      */         case -6: 
/* 2073 */           alpha = 65536;
/* 2074 */           for (int i = 0; i < alphaData.length; i += 3) {
/* 2075 */             if ((r == alphaData[i]) && (g == alphaData[(i + 1)]) && (b == alphaData[(i + 2)])) {
/* 2076 */               alpha = 0;
/* 2077 */               break;
/*      */             }
/*      */           }
/*      */         }
/*      */         
/* 2082 */         if (alpha != 65536) {
/* 2083 */           if (alpha != 0) {
/* 2084 */             switch (dtype) {
/*      */             case 0: 
/* 2086 */               int data = destData[dp] & 0xFF;
/* 2087 */               rq = destReds[((data & destRedMask) >>> destRedShift)] & 0xFF;
/* 2088 */               gq = destGreens[((data & destGreenMask) >>> destGreenShift)] & 0xFF;
/* 2089 */               bq = destBlues[((data & destBlueMask) >>> destBlueShift)] & 0xFF;
/* 2090 */               aq = destAlphas[((data & destAlphaMask) >>> destAlphaShift)] & 0xFF;
/* 2091 */               break;
/*      */             case 1: 
/* 2093 */               int data = (destData[dp] & 0xFF) << 8 | destData[(dp + 1)] & 0xFF;
/* 2094 */               rq = destReds[((data & destRedMask) >>> destRedShift)] & 0xFF;
/* 2095 */               gq = destGreens[((data & destGreenMask) >>> destGreenShift)] & 0xFF;
/* 2096 */               bq = destBlues[((data & destBlueMask) >>> destBlueShift)] & 0xFF;
/* 2097 */               aq = destAlphas[((data & destAlphaMask) >>> destAlphaShift)] & 0xFF;
/* 2098 */               break;
/*      */             case 2: 
/* 2100 */               int data = (destData[(dp + 1)] & 0xFF) << 8 | destData[dp] & 0xFF;
/* 2101 */               rq = destReds[((data & destRedMask) >>> destRedShift)] & 0xFF;
/* 2102 */               gq = destGreens[((data & destGreenMask) >>> destGreenShift)] & 0xFF;
/* 2103 */               bq = destBlues[((data & destBlueMask) >>> destBlueShift)] & 0xFF;
/* 2104 */               aq = destAlphas[((data & destAlphaMask) >>> destAlphaShift)] & 0xFF;
/* 2105 */               break;
/*      */             case 3: 
/* 2107 */               int data = ((destData[dp] & 0xFF) << 8 | destData[(dp + 1)] & 0xFF) << 8 | destData[(dp + 2)] & 0xFF;
/*      */               
/*      */ 
/* 2110 */               rq = destReds[((data & destRedMask) >>> destRedShift)] & 0xFF;
/* 2111 */               gq = destGreens[((data & destGreenMask) >>> destGreenShift)] & 0xFF;
/* 2112 */               bq = destBlues[((data & destBlueMask) >>> destBlueShift)] & 0xFF;
/* 2113 */               aq = destAlphas[((data & destAlphaMask) >>> destAlphaShift)] & 0xFF;
/* 2114 */               break;
/*      */             case 4: 
/* 2116 */               int data = (((destData[dp] & 0xFF) << 8 | destData[(dp + 1)] & 0xFF) << 8 | destData[(dp + 2)] & 0xFF) << 8 | destData[(dp + 3)] & 0xFF;
/*      */               
/*      */ 
/*      */ 
/* 2120 */               rq = destReds[((data & destRedMask) >>> destRedShift)] & 0xFF;
/* 2121 */               gq = destGreens[((data & destGreenMask) >>> destGreenShift)] & 0xFF;
/* 2122 */               bq = destBlues[((data & destBlueMask) >>> destBlueShift)] & 0xFF;
/* 2123 */               aq = destAlphas[((data & destAlphaMask) >>> destAlphaShift)] & 0xFF;
/* 2124 */               break;
/*      */             case 5: 
/* 2126 */               int data = (((destData[(dp + 3)] & 0xFF) << 8 | destData[(dp + 2)] & 0xFF) << 8 | destData[(dp + 1)] & 0xFF) << 8 | destData[dp] & 0xFF;
/*      */               
/*      */ 
/*      */ 
/* 2130 */               rq = destReds[((data & destRedMask) >>> destRedShift)] & 0xFF;
/* 2131 */               gq = destGreens[((data & destGreenMask) >>> destGreenShift)] & 0xFF;
/* 2132 */               bq = destBlues[((data & destBlueMask) >>> destBlueShift)] & 0xFF;
/* 2133 */               aq = destAlphas[((data & destAlphaMask) >>> destAlphaShift)] & 0xFF;
/*      */             }
/*      */             
/*      */             
/* 2137 */             a = aq + ((a - aq) * alpha >> 16);
/* 2138 */             r = rq + ((r - rq) * alpha >> 16);
/* 2139 */             g = gq + ((g - gq) * alpha >> 16);
/* 2140 */             b = bq + ((b - bq) * alpha >> 16);
/*      */           }
/*      */         }
/*      */         else {
/* 2144 */           int data = r >>> destRedPreShift << destRedShift | g >>> destGreenPreShift << destGreenShift | b >>> destBluePreShift << destBlueShift | a >>> destAlphaPreShift << destAlphaShift;
/*      */           
/*      */ 
/*      */ 
/*      */ 
/* 2149 */           switch (dtype) {
/*      */           case 0: 
/* 2151 */             destData[dp] = ((byte)data);
/* 2152 */             break;
/*      */           case 1: 
/* 2154 */             destData[dp] = ((byte)(data >>> 8));
/* 2155 */             destData[(dp + 1)] = ((byte)(data & 0xFF));
/* 2156 */             break;
/*      */           case 2: 
/* 2158 */             destData[dp] = ((byte)(data & 0xFF));
/* 2159 */             destData[(dp + 1)] = ((byte)(data >>> 8));
/* 2160 */             break;
/*      */           case 3: 
/* 2162 */             destData[dp] = ((byte)(data >>> 16));
/* 2163 */             destData[(dp + 1)] = ((byte)(data >>> 8));
/* 2164 */             destData[(dp + 2)] = ((byte)(data & 0xFF));
/* 2165 */             break;
/*      */           case 4: 
/* 2167 */             destData[dp] = ((byte)(data >>> 24));
/* 2168 */             destData[(dp + 1)] = ((byte)(data >>> 16));
/* 2169 */             destData[(dp + 2)] = ((byte)(data >>> 8));
/* 2170 */             destData[(dp + 3)] = ((byte)(data & 0xFF));
/* 2171 */             break;
/*      */           case 5: 
/* 2173 */             destData[dp] = ((byte)(data & 0xFF));
/* 2174 */             destData[(dp + 1)] = ((byte)(data >>> 8));
/* 2175 */             destData[(dp + 2)] = ((byte)(data >>> 16));
/* 2176 */             destData[(dp + 3)] = ((byte)(data >>> 24));
/*      */           }
/*      */         }
/* 1992 */         dx--;
/* 1993 */         dp += dprxi;
/* 1994 */         sfx = (sfx & 0xFFFF) + sfxi;
/*      */       }
/* 1987 */       dy--;
/* 1988 */       sp = spr += (sfy >>> 16) * srcStride;
/* 1989 */       ap = apr += (sfy >>> 16) * alphaStride;
/* 1990 */       sfy = (sfy & 0xFFFF) + sfyi;
/* 1991 */       dp = dpr += dpryi;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static void blit(int op, byte[] srcData, int srcDepth, int srcStride, int srcOrder, int srcX, int srcY, int srcWidth, int srcHeight, byte[] srcReds, byte[] srcGreens, byte[] srcBlues, int alphaMode, byte[] alphaData, int alphaStride, int alphaX, int alphaY, byte[] destData, int destDepth, int destStride, int destOrder, int destX, int destY, int destWidth, int destHeight, byte[] destReds, byte[] destGreens, byte[] destBlues, boolean flipX, boolean flipY)
/*      */   {
/* 2238 */     if ((destWidth <= 0) || (destHeight <= 0) || (alphaMode == 0)) { return;
/*      */     }
/*      */     
/* 2241 */     int dwm1 = destWidth - 1;
/* 2242 */     int sfxi = dwm1 != 0 ? (int)(((srcWidth << 16) - 1L) / dwm1) : 0;
/* 2243 */     int dhm1 = destHeight - 1;
/* 2244 */     int sfyi = dhm1 != 0 ? (int)(((srcHeight << 16) - 1L) / dhm1) : 0;
/*      */     int stype;
/*      */     int stype;
/*      */     int stype;
/* 2248 */     int stype; switch (srcDepth) {
/*      */     case 8: 
/* 2250 */       stype = 6;
/* 2251 */       break;
/*      */     case 4: 
/* 2253 */       srcStride <<= 1;
/* 2254 */       stype = 7;
/* 2255 */       break;
/*      */     case 2: 
/* 2257 */       srcStride <<= 2;
/* 2258 */       stype = 8;
/* 2259 */       break;
/*      */     case 1: 
/* 2261 */       srcStride <<= 3;
/* 2262 */       stype = srcOrder == 1 ? 9 : 10;
/* 2263 */       break;
/*      */     case 3: case 5: case 6: case 7: default: 
/*      */       return;
/*      */     }
/*      */     int stype;
/* 2268 */     int spr = srcY * srcStride + srcX;
/*      */     int dtype;
/*      */     int dtype;
/*      */     int dtype;
/* 2272 */     int dtype; switch (destDepth) {
/*      */     case 8: 
/* 2274 */       dtype = 6;
/* 2275 */       break;
/*      */     case 4: 
/* 2277 */       destStride <<= 1;
/* 2278 */       dtype = 7;
/* 2279 */       break;
/*      */     case 2: 
/* 2281 */       destStride <<= 2;
/* 2282 */       dtype = 8;
/* 2283 */       break;
/*      */     case 1: 
/* 2285 */       destStride <<= 3;
/* 2286 */       dtype = destOrder == 1 ? 9 : 10;
/* 2287 */       break;
/*      */     case 3: case 5: case 6: case 7: default: 
/*      */       return;
/*      */     }
/*      */     int dtype;
/* 2292 */     int dpr = (flipY ? destY + dhm1 : destY) * destStride + (flipX ? destX + dwm1 : destX);
/* 2293 */     int dprxi = flipX ? -1 : 1;
/* 2294 */     int dpryi = flipY ? -destStride : destStride;
/*      */     
/*      */     int apr;
/*      */     
/* 2298 */     if ((op & 0x2) != 0) { int apr;
/* 2299 */       int apr; int apr; int apr; switch (alphaMode) {
/*      */       case -3: 
/*      */       case -1: 
/* 2302 */         if (alphaData == null) alphaMode = 65536;
/* 2303 */         apr = alphaY * alphaStride + alphaX;
/* 2304 */         break;
/*      */       case -4: 
/* 2306 */         if (alphaData == null) alphaMode = 65536;
/* 2307 */         alphaStride <<= 3;
/* 2308 */         apr = alphaY * alphaStride + alphaX;
/* 2309 */         break;
/*      */       case -6: 
/*      */       case -5: 
/* 2312 */         if (alphaData == null) alphaMode = 65536;
/* 2313 */         apr = 0;
/* 2314 */         break;
/*      */       default: 
/* 2316 */         alphaMode = (alphaMode << 16) / 255;
/*      */       case -2: 
/* 2318 */         apr = 0;
/* 2319 */         break;
/*      */       }
/*      */     } else {
/* 2322 */       alphaMode = 65536;
/* 2323 */       apr = 0;
/*      */     }
/* 2325 */     boolean ditherEnabled = (op & 0x4) != 0;
/*      */     
/*      */ 
/* 2328 */     int dp = dpr;
/* 2329 */     int sp = spr;
/* 2330 */     int ap = apr;
/* 2331 */     int destPaletteSize = 1 << destDepth;
/* 2332 */     if ((destReds != null) && (destReds.length < destPaletteSize)) destPaletteSize = destReds.length;
/* 2333 */     byte[] paletteMapping = null;
/* 2334 */     boolean isExactPaletteMapping = true;
/* 2335 */     switch (alphaMode)
/*      */     {
/*      */     case 65536: 
/* 2338 */       if ((stype == dtype) && (srcReds == destReds) && (srcGreens == destGreens) && (srcBlues == destBlues))
/*      */       {
/* 2340 */         paletteMapping = ONE_TO_ONE_MAPPING;
/*      */ 
/*      */       }
/* 2343 */       else if ((srcReds == null) || (destReds == null)) {
/* 2344 */         if (srcDepth <= destDepth) {
/* 2345 */           paletteMapping = ONE_TO_ONE_MAPPING;
/*      */           break label906; }
/* 2347 */         paletteMapping = new byte[1 << srcDepth];
/* 2348 */         int mask = 255 << destDepth >>> 8;
/* 2349 */         for (int i = 0; i < paletteMapping.length; i++) paletteMapping[i] = ((byte)(i & mask));
/*      */       }
/* 2351 */       break;
/*      */     
/*      */ 
/*      */     case -6: 
/*      */     case -5: 
/*      */     case -4: 
/*      */     case -3: 
/* 2358 */       int srcPaletteSize = 1 << srcDepth;
/* 2359 */       paletteMapping = new byte[srcPaletteSize];
/* 2360 */       if ((srcReds != null) && (srcReds.length < srcPaletteSize)) srcPaletteSize = srcReds.length;
/* 2361 */       for (int i = 0; i < srcPaletteSize; i++) {
/* 2362 */         int r = srcReds[i] & 0xFF;
/* 2363 */         int g = srcGreens[i] & 0xFF;
/* 2364 */         int b = srcBlues[i] & 0xFF;
/* 2365 */         int index = 0;
/* 2366 */         int minDistance = Integer.MAX_VALUE;
/* 2367 */         for (int j = 0; j < destPaletteSize; j++) {
/* 2368 */           int dr = (destReds[j] & 0xFF) - r;
/* 2369 */           int dg = (destGreens[j] & 0xFF) - g;
/* 2370 */           int db = (destBlues[j] & 0xFF) - b;
/* 2371 */           int distance = dr * dr + dg * dg + db * db;
/* 2372 */           if (distance < minDistance) {
/* 2373 */             index = j;
/* 2374 */             if (distance == 0) break;
/* 2375 */             minDistance = distance;
/*      */           }
/*      */         }
/* 2378 */         paletteMapping[i] = ((byte)index);
/* 2379 */         if (minDistance != 0) isExactPaletteMapping = false;
/*      */       }
/*      */     }
/*      */     label906:
/* 2383 */     if ((paletteMapping != null) && ((isExactPaletteMapping) || (!ditherEnabled))) { int dy;
/* 2384 */       int sfy; if ((stype == dtype) && (alphaMode == 65536))
/*      */       {
/* 2386 */         switch (stype) {
/*      */         case 6: 
/* 2388 */           int dy = destHeight; for (int sfy = sfyi; dy > 0; dp = dpr += dpryi) {
/* 2389 */             int dx = destWidth; for (int sfx = sfxi; dx > 0; sfx = (sfx & 0xFFFF) + sfxi) {
/* 2390 */               destData[dp] = paletteMapping[(srcData[sp] & 0xFF)];
/* 2391 */               sp += (sfx >>> 16);dx--;dp += dprxi;
/*      */             }
/* 2388 */             dy--;sp = spr += (sfy >>> 16) * srcStride;sfy = (sfy & 0xFFFF) + sfyi;
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/* 2394 */           break;
/*      */         case 7: 
/* 2396 */           int dy = destHeight; for (int sfy = sfyi; dy > 0; dp = dpr += dpryi) {
/* 2397 */             int dx = destWidth; for (int sfx = sfxi; dx > 0; sfx = (sfx & 0xFFFF) + sfxi) { int v;
/*      */               int v;
/* 2399 */               if ((sp & 0x1) != 0) v = paletteMapping[(srcData[(sp >> 1)] & 0xF)]; else
/* 2400 */                 v = srcData[(sp >> 1)] >>> 4 & 0xF;
/* 2401 */               sp += (sfx >>> 16);
/* 2402 */               if ((dp & 0x1) != 0) destData[(dp >> 1)] = ((byte)(destData[(dp >> 1)] & 0xF0 | v)); else {
/* 2403 */                 destData[(dp >> 1)] = ((byte)(destData[(dp >> 1)] & 0xF | v << 4));
/*      */               }
/* 2397 */               dx--;dp += dprxi;
/*      */             }
/* 2396 */             dy--;sp = spr += (sfy >>> 16) * srcStride;sfy = (sfy & 0xFFFF) + sfyi;
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2406 */           break;
/*      */         case 8: 
/* 2408 */           int dy = destHeight; for (int sfy = sfyi; dy > 0; dp = dpr += dpryi) {
/* 2409 */             int dx = destWidth; for (int sfx = sfxi; dx > 0; sfx = (sfx & 0xFFFF) + sfxi) {
/* 2410 */               int index = paletteMapping[(srcData[(sp >> 2)] >>> 6 - (sp & 0x3) * 2 & 0x3)];
/* 2411 */               sp += (sfx >>> 16);
/* 2412 */               int shift = 6 - (dp & 0x3) * 2;
/* 2413 */               destData[(dp >> 2)] = ((byte)(destData[(dp >> 2)] & (3 << shift ^ 0xFFFFFFFF) | index << shift));dx--;dp += dprxi;
/*      */             }
/* 2408 */             dy--;sp = spr += (sfy >>> 16) * srcStride;sfy = (sfy & 0xFFFF) + sfyi;
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2416 */           break;
/*      */         case 9: 
/* 2418 */           int dy = destHeight; for (int sfy = sfyi; dy > 0; dp = dpr += dpryi) {
/* 2419 */             int dx = destWidth; for (int sfx = sfxi; dx > 0; sfx = (sfx & 0xFFFF) + sfxi) {
/* 2420 */               int index = paletteMapping[(srcData[(sp >> 3)] >>> 7 - (sp & 0x7) & 0x1)];
/* 2421 */               sp += (sfx >>> 16);
/* 2422 */               int shift = 7 - (dp & 0x7);
/* 2423 */               destData[(dp >> 3)] = ((byte)(destData[(dp >> 3)] & (1 << shift ^ 0xFFFFFFFF) | index << shift));dx--;dp += dprxi;
/*      */             }
/* 2418 */             dy--;sp = spr += (sfy >>> 16) * srcStride;sfy = (sfy & 0xFFFF) + sfyi;
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2426 */           break;
/*      */         case 10: 
/* 2428 */           int dy = destHeight; for (int sfy = sfyi; dy > 0; dp = dpr += dpryi) {
/* 2429 */             int dx = destWidth; for (int sfx = sfxi; dx > 0; sfx = (sfx & 0xFFFF) + sfxi) {
/* 2430 */               int index = paletteMapping[(srcData[(sp >> 3)] >>> (sp & 0x7) & 0x1)];
/* 2431 */               sp += (sfx >>> 16);
/* 2432 */               int shift = dp & 0x7;
/* 2433 */               destData[(dp >> 3)] = ((byte)(destData[(dp >> 3)] & (1 << shift ^ 0xFFFFFFFF) | index << shift));dx--;dp += dprxi;
/*      */             }
/* 2428 */             dy--;sp = spr += (sfy >>> 16) * srcStride;sfy = (sfy & 0xFFFF) + sfyi;
/*      */           }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         }
/*      */         
/*      */       }
/*      */       else
/*      */       {
/* 2440 */         dy = destHeight; for (sfy = sfyi; dy > 0;)
/*      */         {
/*      */ 
/*      */ 
/* 2444 */           int dx = destWidth; for (int sfx = sfxi; dx > 0;)
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/* 2449 */             switch (stype) {
/*      */             case 6: 
/* 2451 */               int index = srcData[sp] & 0xFF;
/* 2452 */               sp += (sfx >>> 16);
/* 2453 */               break; case 7:  int index;
/*      */               int index;
/* 2455 */               if ((sp & 0x1) != 0) index = srcData[(sp >> 1)] & 0xF; else
/* 2456 */                 index = srcData[(sp >> 1)] >>> 4 & 0xF;
/* 2457 */               sp += (sfx >>> 16);
/* 2458 */               break;
/*      */             case 8: 
/* 2460 */               int index = srcData[(sp >> 2)] >>> 6 - (sp & 0x3) * 2 & 0x3;
/* 2461 */               sp += (sfx >>> 16);
/* 2462 */               break;
/*      */             case 9: 
/* 2464 */               int index = srcData[(sp >> 3)] >>> 7 - (sp & 0x7) & 0x1;
/* 2465 */               sp += (sfx >>> 16);
/* 2466 */               break;
/*      */             case 10: 
/* 2468 */               int index = srcData[(sp >> 3)] >>> (sp & 0x7) & 0x1;
/* 2469 */               sp += (sfx >>> 16);
/* 2470 */               break;
/*      */             default: 
/* 2472 */               return;
/*      */             }
/*      */             
/* 2475 */             switch (alphaMode) {
/*      */             case -3: 
/* 2477 */               byte mask = alphaData[ap];
/* 2478 */               ap += (sfx >> 16);
/* 2479 */               if (mask == 0) break label2455;
/* 2480 */               break;
/*      */             case -4: 
/* 2482 */               int mask = alphaData[(ap >> 3)] & 1 << (ap & 0x7);
/* 2483 */               ap += (sfx >> 16);
/* 2484 */               if (mask == 0) break label2455;
/* 2485 */               break;
/*      */             case -5: 
/* 2487 */               int i = 0;
/* 2488 */               while (i < alphaData.length)
/* 2489 */                 if (index == (alphaData[i] & 0xFF))
/*      */                   break;
/* 2491 */               if (i < alphaData.length) break label2455;
/* 2492 */               break;
/*      */             case -6: 
/* 2494 */               byte r = srcReds[index];byte g = srcGreens[index];byte b = srcBlues[index];
/* 2495 */               int i = 0;
/* 2496 */               while ((i < alphaData.length) && (
/* 2497 */                 (r != alphaData[i]) || (g != alphaData[(i + 1)]) || (b != alphaData[(i + 2)]))) {
/* 2498 */                 i += 3;
/*      */               }
/* 2500 */               if (i < alphaData.length)
/*      */                 break label2455;
/*      */             }
/* 2503 */             int index = paletteMapping[index] & 0xFF;
/*      */             
/*      */ 
/* 2506 */             switch (dtype) {
/*      */             case 6: 
/* 2508 */               destData[dp] = ((byte)index);
/* 2509 */               break;
/*      */             case 7: 
/* 2511 */               if ((dp & 0x1) != 0) destData[(dp >> 1)] = ((byte)(destData[(dp >> 1)] & 0xF0 | index)); else
/* 2512 */                 destData[(dp >> 1)] = ((byte)(destData[(dp >> 1)] & 0xF | index << 4));
/* 2513 */               break;
/*      */             case 8: 
/* 2515 */               int shift = 6 - (dp & 0x3) * 2;
/* 2516 */               destData[(dp >> 2)] = ((byte)(destData[(dp >> 2)] & (3 << shift ^ 0xFFFFFFFF) | index << shift));
/* 2517 */               break;
/*      */             case 9: 
/* 2519 */               int shift = 7 - (dp & 0x7);
/* 2520 */               destData[(dp >> 3)] = ((byte)(destData[(dp >> 3)] & (1 << shift ^ 0xFFFFFFFF) | index << shift));
/* 2521 */               break;
/*      */             case 10: 
/* 2523 */               int shift = dp & 0x7;
/* 2524 */               destData[(dp >> 3)] = ((byte)(destData[(dp >> 3)] & (1 << shift ^ 0xFFFFFFFF) | index << shift));
/*      */             }
/* 2444 */             dx--;
/* 2445 */             dp += dprxi;
/* 2446 */             sfx = (sfx & 0xFFFF) + sfxi;
/*      */           }
/* 2440 */           dy--;
/* 2441 */           sp = spr += (sfy >>> 16) * srcStride;
/* 2442 */           sfy = (sfy & 0xFFFF) + sfyi;
/* 2443 */           dp = dpr += dpryi;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       label2455:
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2530 */       return;
/*      */     }
/*      */     
/*      */ 
/* 2534 */     int alpha = alphaMode;
/* 2535 */     int index = 0;
/* 2536 */     int indexq = 0;
/* 2537 */     int lastindex = 0;int lastr = -1;int lastg = -1;int lastb = -1;
/*      */     int[] berr;
/* 2539 */     int[] rerr; int[] gerr; int[] berr; if (ditherEnabled) {
/* 2540 */       int[] rerr = new int[destWidth + 2];
/* 2541 */       int[] gerr = new int[destWidth + 2];
/* 2542 */       berr = new int[destWidth + 2];
/*      */     } else {
/* 2544 */       rerr = null;gerr = null;berr = null;
/*      */     }
/* 2546 */     int dy = destHeight; for (int sfy = sfyi; dy > 0;)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 2551 */       int lrerr = 0;int lgerr = 0;int lberr = 0;
/* 2552 */       int dx = destWidth; for (int sfx = sfxi; dx > 0;)
/*      */       {
/*      */ 
/*      */ 
/* 2556 */         switch (stype) {
/*      */         case 6: 
/* 2558 */           index = srcData[sp] & 0xFF;
/* 2559 */           sp += (sfx >>> 16);
/* 2560 */           break;
/*      */         case 7: 
/* 2562 */           if ((sp & 0x1) != 0) index = srcData[(sp >> 1)] & 0xF; else
/* 2563 */             index = srcData[(sp >> 1)] >>> 4 & 0xF;
/* 2564 */           sp += (sfx >>> 16);
/* 2565 */           break;
/*      */         case 8: 
/* 2567 */           index = srcData[(sp >> 2)] >>> 6 - (sp & 0x3) * 2 & 0x3;
/* 2568 */           sp += (sfx >>> 16);
/* 2569 */           break;
/*      */         case 9: 
/* 2571 */           index = srcData[(sp >> 3)] >>> 7 - (sp & 0x7) & 0x1;
/* 2572 */           sp += (sfx >>> 16);
/* 2573 */           break;
/*      */         case 10: 
/* 2575 */           index = srcData[(sp >> 3)] >>> (sp & 0x7) & 0x1;
/* 2576 */           sp += (sfx >>> 16);
/*      */         }
/*      */         
/*      */         
/*      */ 
/* 2581 */         int r = srcReds[index] & 0xFF;int g = srcGreens[index] & 0xFF;int b = srcBlues[index] & 0xFF;
/* 2582 */         switch (alphaMode) {
/*      */         case -1: 
/* 2584 */           alpha = ((alphaData[ap] & 0xFF) << 16) / 255;
/* 2585 */           ap += (sfx >> 16);
/* 2586 */           break;
/*      */         case -3: 
/* 2588 */           alpha = alphaData[ap] != 0 ? 65536 : 0;
/* 2589 */           ap += (sfx >> 16);
/* 2590 */           break;
/*      */         case -4: 
/* 2592 */           alpha = alphaData[(ap >> 3)] << (ap & 0x7) + 9 & 0x10000;
/* 2593 */           ap += (sfx >> 16);
/* 2594 */           break;
/*      */         case -5: 
/* 2596 */           int i = 0;
/* 2597 */           while (i < alphaData.length)
/* 2598 */             if (index == (alphaData[i] & 0xFF))
/*      */               break;
/* 2600 */           if (i < alphaData.length) break label4067;
/* 2601 */           break;
/*      */         case -6: 
/* 2603 */           int i = 0;
/* 2604 */           while ((i < alphaData.length) && (
/* 2605 */             (r != (alphaData[i] & 0xFF)) || (g != (alphaData[(i + 1)] & 0xFF)) || (b != (alphaData[(i + 2)] & 0xFF))))
/*      */           {
/*      */ 
/* 2608 */             i += 3;
/*      */           }
/* 2610 */           if (i < alphaData.length)
/*      */             break label4067;
/*      */         }
/* 2613 */         if (alpha != 65536) {
/* 2614 */           if (alpha != 0) {
/* 2615 */             switch (dtype) {
/*      */             case 6: 
/* 2617 */               indexq = destData[dp] & 0xFF;
/* 2618 */               break;
/*      */             case 7: 
/* 2620 */               if ((dp & 0x1) != 0) indexq = destData[(dp >> 1)] & 0xF; else
/* 2621 */                 indexq = destData[(dp >> 1)] >>> 4 & 0xF;
/* 2622 */               break;
/*      */             case 8: 
/* 2624 */               indexq = destData[(dp >> 2)] >>> 6 - (dp & 0x3) * 2 & 0x3;
/* 2625 */               break;
/*      */             case 9: 
/* 2627 */               indexq = destData[(dp >> 3)] >>> 7 - (dp & 0x7) & 0x1;
/* 2628 */               break;
/*      */             case 10: 
/* 2630 */               indexq = destData[(dp >> 3)] >>> (dp & 0x7) & 0x1;
/*      */             }
/*      */             
/*      */             
/* 2634 */             int rq = destReds[indexq] & 0xFF;
/* 2635 */             int gq = destGreens[indexq] & 0xFF;
/* 2636 */             int bq = destBlues[indexq] & 0xFF;
/* 2637 */             r = rq + ((r - rq) * alpha >> 16);
/* 2638 */             g = gq + ((g - gq) * alpha >> 16);
/* 2639 */             b = bq + ((b - bq) * alpha >> 16);
/*      */           }
/*      */         }
/*      */         else {
/* 2643 */           if (ditherEnabled)
/*      */           {
/* 2645 */             r += (rerr[dx] >> 4);
/* 2646 */             if (r < 0) r = 0; else if (r > 255) r = 255;
/* 2647 */             g += (gerr[dx] >> 4);
/* 2648 */             if (g < 0) g = 0; else if (g > 255) g = 255;
/* 2649 */             b += (berr[dx] >> 4);
/* 2650 */             if (b < 0) b = 0; else if (b > 255) b = 255;
/* 2651 */             rerr[dx] = lrerr;
/* 2652 */             gerr[dx] = lgerr;
/* 2653 */             berr[dx] = lberr;
/*      */           }
/* 2655 */           if ((r != lastr) || (g != lastg) || (b != lastb))
/*      */           {
/* 2657 */             int j = 0; for (int minDistance = Integer.MAX_VALUE; j < destPaletteSize; j++) {
/* 2658 */               int dr = (destReds[j] & 0xFF) - r;
/* 2659 */               int dg = (destGreens[j] & 0xFF) - g;
/* 2660 */               int db = (destBlues[j] & 0xFF) - b;
/* 2661 */               int distance = dr * dr + dg * dg + db * db;
/* 2662 */               if (distance < minDistance) {
/* 2663 */                 lastindex = j;
/* 2664 */                 if (distance == 0) break;
/* 2665 */                 minDistance = distance;
/*      */               }
/*      */             }
/* 2668 */             lastr = r;lastg = g;lastb = b;
/*      */           }
/* 2670 */           if (ditherEnabled)
/*      */           {
/* 2672 */             int dxm1 = dx - 1;int dxp1 = dx + 1;
/*      */             int acc;
/* 2674 */             rerr[dxp1] += (acc = (lrerr = r - (destReds[lastindex] & 0xFF)) + lrerr + lrerr);
/* 2675 */             rerr[dx] += acc += lrerr + lrerr;
/* 2676 */             rerr[dxm1] += acc + lrerr + lrerr;
/* 2677 */             gerr[dxp1] += (acc = (lgerr = g - (destGreens[lastindex] & 0xFF)) + lgerr + lgerr);
/* 2678 */             gerr[dx] += acc += lgerr + lgerr;
/* 2679 */             gerr[dxm1] += acc + lgerr + lgerr;
/* 2680 */             berr[dxp1] += (acc = (lberr = b - (destBlues[lastindex] & 0xFF)) + lberr + lberr);
/* 2681 */             berr[dx] += acc += lberr + lberr;
/* 2682 */             berr[dxm1] += acc + lberr + lberr;
/*      */           }
/*      */           
/*      */ 
/* 2686 */           switch (dtype) {
/*      */           case 6: 
/* 2688 */             destData[dp] = ((byte)lastindex);
/* 2689 */             break;
/*      */           case 7: 
/* 2691 */             if ((dp & 0x1) != 0) destData[(dp >> 1)] = ((byte)(destData[(dp >> 1)] & 0xF0 | lastindex)); else
/* 2692 */               destData[(dp >> 1)] = ((byte)(destData[(dp >> 1)] & 0xF | lastindex << 4));
/* 2693 */             break;
/*      */           case 8: 
/* 2695 */             int shift = 6 - (dp & 0x3) * 2;
/* 2696 */             destData[(dp >> 2)] = ((byte)(destData[(dp >> 2)] & (3 << shift ^ 0xFFFFFFFF) | lastindex << shift));
/* 2697 */             break;
/*      */           case 9: 
/* 2699 */             int shift = 7 - (dp & 0x7);
/* 2700 */             destData[(dp >> 3)] = ((byte)(destData[(dp >> 3)] & (1 << shift ^ 0xFFFFFFFF) | lastindex << shift));
/* 2701 */             break;
/*      */           case 10: 
/* 2703 */             int shift = dp & 0x7;
/* 2704 */             destData[(dp >> 3)] = ((byte)(destData[(dp >> 3)] & (1 << shift ^ 0xFFFFFFFF) | lastindex << shift));
/*      */           }
/*      */         }
/* 2552 */         dx--;
/* 2553 */         dp += dprxi;
/* 2554 */         sfx = (sfx & 0xFFFF) + sfxi;
/*      */       }
/* 2546 */       dy--;
/* 2547 */       sp = spr += (sfy >>> 16) * srcStride;
/* 2548 */       ap = apr += (sfy >>> 16) * alphaStride;
/* 2549 */       sfy = (sfy & 0xFFFF) + sfyi;
/* 2550 */       dp = dpr += dpryi;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     label4067:
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static void blit(int op, byte[] srcData, int srcDepth, int srcStride, int srcOrder, int srcX, int srcY, int srcWidth, int srcHeight, byte[] srcReds, byte[] srcGreens, byte[] srcBlues, int alphaMode, byte[] alphaData, int alphaStride, int alphaX, int alphaY, byte[] destData, int destDepth, int destStride, int destOrder, int destX, int destY, int destWidth, int destHeight, int destRedMask, int destGreenMask, int destBlueMask, boolean flipX, boolean flipY)
/*      */   {
/* 2765 */     if ((destWidth <= 0) || (destHeight <= 0) || (alphaMode == 0)) { return;
/*      */     }
/*      */     
/* 2768 */     if ((srcX == 0) && (srcY == 0) && (destX == 0) && (destY == 0) && (destWidth == srcWidth) && (destHeight == srcHeight)) {
/* 2769 */       if ((destDepth == 24) && (srcDepth == 8) && ((op & 0x2) == 0) && (destRedMask == 16711680) && (destGreenMask == 65280) && (destBlueMask == 255)) {
/* 2770 */         int y = 0;int sp = 0;int dp = 0;int spad = srcStride - srcWidth; for (int dpad = destStride - destWidth * 3; y < destHeight; dp += dpad) {
/* 2771 */           for (int x = 0; x < destWidth; x++) {
/* 2772 */             int index = srcData[(sp++)] & 0xFF;
/* 2773 */             destData[(dp++)] = srcReds[index];
/* 2774 */             destData[(dp++)] = srcGreens[index];
/* 2775 */             destData[(dp++)] = srcBlues[index];
/*      */           }
/* 2770 */           y++;sp += spad;
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2778 */         return;
/*      */       }
/* 2780 */       if ((destDepth == 32) && (destOrder == 1) && (srcDepth == 8) && ((op & 0x2) == 0) && (destRedMask == 16711680) && (destGreenMask == 65280) && (destBlueMask == 255)) {
/* 2781 */         int y = 0;int sp = 0;int dp = 0;int spad = srcStride - srcWidth; for (int dpad = destStride - destWidth * 4; y < destHeight; dp += dpad) {
/* 2782 */           for (int x = 0; x < destWidth; x++) {
/* 2783 */             int index = srcData[(sp++)] & 0xFF;
/* 2784 */             dp++;
/* 2785 */             destData[(dp++)] = srcReds[index];
/* 2786 */             destData[(dp++)] = srcGreens[index];
/* 2787 */             destData[(dp++)] = srcBlues[index];
/*      */           }
/* 2781 */           y++;sp += spad;
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2790 */         return;
/*      */       }
/*      */     }
/*      */     
/* 2794 */     int destAlphaMask = 0;
/*      */     
/*      */ 
/* 2797 */     int dwm1 = destWidth - 1;
/* 2798 */     int sfxi = dwm1 != 0 ? (int)(((srcWidth << 16) - 1L) / dwm1) : 0;
/* 2799 */     int dhm1 = destHeight - 1;
/* 2800 */     int sfyi = dhm1 != 0 ? (int)(((srcHeight << 16) - 1L) / dhm1) : 0;
/*      */     int stype;
/*      */     int stype;
/*      */     int stype;
/* 2804 */     int stype; switch (srcDepth) {
/*      */     case 8: 
/* 2806 */       stype = 6;
/* 2807 */       break;
/*      */     case 4: 
/* 2809 */       srcStride <<= 1;
/* 2810 */       stype = 7;
/* 2811 */       break;
/*      */     case 2: 
/* 2813 */       srcStride <<= 2;
/* 2814 */       stype = 8;
/* 2815 */       break;
/*      */     case 1: 
/* 2817 */       srcStride <<= 3;
/* 2818 */       stype = srcOrder == 1 ? 9 : 10;
/* 2819 */       break;
/*      */     case 3: case 5: case 6: case 7: default: 
/*      */       return;
/*      */     }
/*      */     int stype;
/* 2824 */     int spr = srcY * srcStride + srcX;
/*      */     int dtype;
/*      */     int dtype;
/*      */     int dtype;
/* 2828 */     int dtype; switch (destDepth) {
/*      */     case 8: 
/* 2830 */       int dbpp = 1;
/* 2831 */       dtype = 0;
/* 2832 */       break;
/*      */     case 16: 
/* 2834 */       int dbpp = 2;
/* 2835 */       dtype = destOrder == 1 ? 1 : 2;
/* 2836 */       break;
/*      */     case 24: 
/* 2838 */       int dbpp = 3;
/* 2839 */       dtype = 3;
/* 2840 */       break;
/*      */     case 32: 
/* 2842 */       int dbpp = 4;
/* 2843 */       dtype = destOrder == 1 ? 4 : 5;
/* 2844 */       break;
/*      */     default: 
/*      */       return; }
/*      */     int dtype;
/*      */     int dbpp;
/* 2849 */     int dpr = (flipY ? destY + dhm1 : destY) * destStride + (flipX ? destX + dwm1 : destX) * dbpp;
/* 2850 */     int dprxi = flipX ? -dbpp : dbpp;
/* 2851 */     int dpryi = flipY ? -destStride : destStride;
/*      */     
/*      */     int apr;
/*      */     
/* 2855 */     if ((op & 0x2) != 0) { int apr;
/* 2856 */       int apr; int apr; int apr; switch (alphaMode) {
/*      */       case -3: 
/*      */       case -1: 
/* 2859 */         if (alphaData == null) alphaMode = 65536;
/* 2860 */         apr = alphaY * alphaStride + alphaX;
/* 2861 */         break;
/*      */       case -4: 
/* 2863 */         if (alphaData == null) alphaMode = 65536;
/* 2864 */         alphaStride <<= 3;
/* 2865 */         apr = alphaY * alphaStride + alphaX;
/* 2866 */         break;
/*      */       case -6: 
/*      */       case -5: 
/* 2869 */         if (alphaData == null) alphaMode = 65536;
/* 2870 */         apr = 0;
/* 2871 */         break;
/*      */       default: 
/* 2873 */         alphaMode = (alphaMode << 16) / 255;
/*      */       case -2: 
/* 2875 */         apr = 0;
/* 2876 */         break;
/*      */       }
/*      */     } else {
/* 2879 */       alphaMode = 65536;
/* 2880 */       apr = 0;
/*      */     }
/*      */     
/*      */ 
/* 2884 */     int destRedShift = getChannelShift(destRedMask);
/* 2885 */     int destRedWidth = getChannelWidth(destRedMask, destRedShift);
/* 2886 */     byte[] destReds = ANY_TO_EIGHT[destRedWidth];
/* 2887 */     int destRedPreShift = 8 - destRedWidth;
/* 2888 */     int destGreenShift = getChannelShift(destGreenMask);
/* 2889 */     int destGreenWidth = getChannelWidth(destGreenMask, destGreenShift);
/* 2890 */     byte[] destGreens = ANY_TO_EIGHT[destGreenWidth];
/* 2891 */     int destGreenPreShift = 8 - destGreenWidth;
/* 2892 */     int destBlueShift = getChannelShift(destBlueMask);
/* 2893 */     int destBlueWidth = getChannelWidth(destBlueMask, destBlueShift);
/* 2894 */     byte[] destBlues = ANY_TO_EIGHT[destBlueWidth];
/* 2895 */     int destBluePreShift = 8 - destBlueWidth;
/* 2896 */     int destAlphaShift = getChannelShift(0);
/* 2897 */     int destAlphaWidth = getChannelWidth(0, destAlphaShift);
/* 2898 */     byte[] destAlphas = ANY_TO_EIGHT[destAlphaWidth];
/* 2899 */     int destAlphaPreShift = 8 - destAlphaWidth;
/*      */     
/* 2901 */     int dp = dpr;
/* 2902 */     int sp = spr;
/* 2903 */     int ap = apr;int alpha = alphaMode;
/* 2904 */     int r = 0;int g = 0;int b = 0;int a = 0;int index = 0;
/* 2905 */     int rq = 0;int gq = 0;int bq = 0;int aq = 0;
/* 2906 */     int dy = destHeight; for (int sfy = sfyi; dy > 0;)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 2911 */       int dx = destWidth; for (int sfx = sfxi; dx > 0;)
/*      */       {
/*      */ 
/*      */ 
/* 2915 */         switch (stype) {
/*      */         case 6: 
/* 2917 */           index = srcData[sp] & 0xFF;
/* 2918 */           sp += (sfx >>> 16);
/* 2919 */           break;
/*      */         case 7: 
/* 2921 */           if ((sp & 0x1) != 0) index = srcData[(sp >> 1)] & 0xF; else
/* 2922 */             index = srcData[(sp >> 1)] >>> 4 & 0xF;
/* 2923 */           sp += (sfx >>> 16);
/* 2924 */           break;
/*      */         case 8: 
/* 2926 */           index = srcData[(sp >> 2)] >>> 6 - (sp & 0x3) * 2 & 0x3;
/* 2927 */           sp += (sfx >>> 16);
/* 2928 */           break;
/*      */         case 9: 
/* 2930 */           index = srcData[(sp >> 3)] >>> 7 - (sp & 0x7) & 0x1;
/* 2931 */           sp += (sfx >>> 16);
/* 2932 */           break;
/*      */         case 10: 
/* 2934 */           index = srcData[(sp >> 3)] >>> (sp & 0x7) & 0x1;
/* 2935 */           sp += (sfx >>> 16);
/*      */         }
/*      */         
/*      */         
/*      */ 
/* 2940 */         r = srcReds[index] & 0xFF;
/* 2941 */         g = srcGreens[index] & 0xFF;
/* 2942 */         b = srcBlues[index] & 0xFF;
/* 2943 */         switch (alphaMode) {
/*      */         case -1: 
/* 2945 */           alpha = ((alphaData[ap] & 0xFF) << 16) / 255;
/* 2946 */           ap += (sfx >> 16);
/* 2947 */           break;
/*      */         case -3: 
/* 2949 */           alpha = alphaData[ap] != 0 ? 65536 : 0;
/* 2950 */           ap += (sfx >> 16);
/* 2951 */           break;
/*      */         case -4: 
/* 2953 */           alpha = alphaData[(ap >> 3)] << (ap & 0x7) + 9 & 0x10000;
/* 2954 */           ap += (sfx >> 16);
/* 2955 */           break;
/*      */         case -5: 
/* 2957 */           int i = 0;
/* 2958 */           while (i < alphaData.length)
/* 2959 */             if (index == (alphaData[i] & 0xFF))
/*      */               break;
/* 2961 */           if (i < alphaData.length) break label2577;
/* 2962 */           break;
/*      */         case -6: 
/* 2964 */           int i = 0;
/* 2965 */           while ((i < alphaData.length) && (
/* 2966 */             (r != (alphaData[i] & 0xFF)) || (g != (alphaData[(i + 1)] & 0xFF)) || (b != (alphaData[(i + 2)] & 0xFF))))
/*      */           {
/*      */ 
/* 2969 */             i += 3;
/*      */           }
/* 2971 */           if (i < alphaData.length)
/*      */             break label2577;
/*      */         }
/* 2974 */         if (alpha != 65536) {
/* 2975 */           if (alpha != 0) {
/* 2976 */             switch (dtype) {
/*      */             case 0: 
/* 2978 */               int data = destData[dp] & 0xFF;
/* 2979 */               rq = destReds[((data & destRedMask) >>> destRedShift)] & 0xFF;
/* 2980 */               gq = destGreens[((data & destGreenMask) >>> destGreenShift)] & 0xFF;
/* 2981 */               bq = destBlues[((data & destBlueMask) >>> destBlueShift)] & 0xFF;
/* 2982 */               aq = destAlphas[((data & 0x0) >>> destAlphaShift)] & 0xFF;
/* 2983 */               break;
/*      */             case 1: 
/* 2985 */               int data = (destData[dp] & 0xFF) << 8 | destData[(dp + 1)] & 0xFF;
/* 2986 */               rq = destReds[((data & destRedMask) >>> destRedShift)] & 0xFF;
/* 2987 */               gq = destGreens[((data & destGreenMask) >>> destGreenShift)] & 0xFF;
/* 2988 */               bq = destBlues[((data & destBlueMask) >>> destBlueShift)] & 0xFF;
/* 2989 */               aq = destAlphas[((data & 0x0) >>> destAlphaShift)] & 0xFF;
/* 2990 */               break;
/*      */             case 2: 
/* 2992 */               int data = (destData[(dp + 1)] & 0xFF) << 8 | destData[dp] & 0xFF;
/* 2993 */               rq = destReds[((data & destRedMask) >>> destRedShift)] & 0xFF;
/* 2994 */               gq = destGreens[((data & destGreenMask) >>> destGreenShift)] & 0xFF;
/* 2995 */               bq = destBlues[((data & destBlueMask) >>> destBlueShift)] & 0xFF;
/* 2996 */               aq = destAlphas[((data & 0x0) >>> destAlphaShift)] & 0xFF;
/* 2997 */               break;
/*      */             case 3: 
/* 2999 */               int data = ((destData[dp] & 0xFF) << 8 | destData[(dp + 1)] & 0xFF) << 8 | destData[(dp + 2)] & 0xFF;
/*      */               
/*      */ 
/* 3002 */               rq = destReds[((data & destRedMask) >>> destRedShift)] & 0xFF;
/* 3003 */               gq = destGreens[((data & destGreenMask) >>> destGreenShift)] & 0xFF;
/* 3004 */               bq = destBlues[((data & destBlueMask) >>> destBlueShift)] & 0xFF;
/* 3005 */               aq = destAlphas[((data & 0x0) >>> destAlphaShift)] & 0xFF;
/* 3006 */               break;
/*      */             case 4: 
/* 3008 */               int data = (((destData[dp] & 0xFF) << 8 | destData[(dp + 1)] & 0xFF) << 8 | destData[(dp + 2)] & 0xFF) << 8 | destData[(dp + 3)] & 0xFF;
/*      */               
/*      */ 
/*      */ 
/* 3012 */               rq = destReds[((data & destRedMask) >>> destRedShift)] & 0xFF;
/* 3013 */               gq = destGreens[((data & destGreenMask) >>> destGreenShift)] & 0xFF;
/* 3014 */               bq = destBlues[((data & destBlueMask) >>> destBlueShift)] & 0xFF;
/* 3015 */               aq = destAlphas[((data & 0x0) >>> destAlphaShift)] & 0xFF;
/* 3016 */               break;
/*      */             case 5: 
/* 3018 */               int data = (((destData[(dp + 3)] & 0xFF) << 8 | destData[(dp + 2)] & 0xFF) << 8 | destData[(dp + 1)] & 0xFF) << 8 | destData[dp] & 0xFF;
/*      */               
/*      */ 
/*      */ 
/* 3022 */               rq = destReds[((data & destRedMask) >>> destRedShift)] & 0xFF;
/* 3023 */               gq = destGreens[((data & destGreenMask) >>> destGreenShift)] & 0xFF;
/* 3024 */               bq = destBlues[((data & destBlueMask) >>> destBlueShift)] & 0xFF;
/* 3025 */               aq = destAlphas[((data & 0x0) >>> destAlphaShift)] & 0xFF;
/*      */             }
/*      */             
/*      */             
/* 3029 */             a = aq + ((a - aq) * alpha >> 16);
/* 3030 */             r = rq + ((r - rq) * alpha >> 16);
/* 3031 */             g = gq + ((g - gq) * alpha >> 16);
/* 3032 */             b = bq + ((b - bq) * alpha >> 16);
/*      */           }
/*      */         }
/*      */         else {
/* 3036 */           int data = r >>> destRedPreShift << destRedShift | g >>> destGreenPreShift << destGreenShift | b >>> destBluePreShift << destBlueShift | a >>> destAlphaPreShift << destAlphaShift;
/*      */           
/*      */ 
/*      */ 
/*      */ 
/* 3041 */           switch (dtype) {
/*      */           case 0: 
/* 3043 */             destData[dp] = ((byte)data);
/* 3044 */             break;
/*      */           case 1: 
/* 3046 */             destData[dp] = ((byte)(data >>> 8));
/* 3047 */             destData[(dp + 1)] = ((byte)(data & 0xFF));
/* 3048 */             break;
/*      */           case 2: 
/* 3050 */             destData[dp] = ((byte)(data & 0xFF));
/* 3051 */             destData[(dp + 1)] = ((byte)(data >>> 8));
/* 3052 */             break;
/*      */           case 3: 
/* 3054 */             destData[dp] = ((byte)(data >>> 16));
/* 3055 */             destData[(dp + 1)] = ((byte)(data >>> 8));
/* 3056 */             destData[(dp + 2)] = ((byte)(data & 0xFF));
/* 3057 */             break;
/*      */           case 4: 
/* 3059 */             destData[dp] = ((byte)(data >>> 24));
/* 3060 */             destData[(dp + 1)] = ((byte)(data >>> 16));
/* 3061 */             destData[(dp + 2)] = ((byte)(data >>> 8));
/* 3062 */             destData[(dp + 3)] = ((byte)(data & 0xFF));
/* 3063 */             break;
/*      */           case 5: 
/* 3065 */             destData[dp] = ((byte)(data & 0xFF));
/* 3066 */             destData[(dp + 1)] = ((byte)(data >>> 8));
/* 3067 */             destData[(dp + 2)] = ((byte)(data >>> 16));
/* 3068 */             destData[(dp + 3)] = ((byte)(data >>> 24));
/*      */           }
/*      */         }
/* 2911 */         dx--;
/* 2912 */         dp += dprxi;
/* 2913 */         sfx = (sfx & 0xFFFF) + sfxi;
/*      */       }
/* 2906 */       dy--;
/* 2907 */       sp = spr += (sfy >>> 16) * srcStride;
/* 2908 */       ap = apr += (sfy >>> 16) * alphaStride;
/* 2909 */       sfy = (sfy & 0xFFFF) + sfyi;
/* 2910 */       dp = dpr += dpryi;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     label2577:
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static void blit(int op, byte[] srcData, int srcDepth, int srcStride, int srcOrder, int srcX, int srcY, int srcWidth, int srcHeight, int srcRedMask, int srcGreenMask, int srcBlueMask, int alphaMode, byte[] alphaData, int alphaStride, int alphaX, int alphaY, byte[] destData, int destDepth, int destStride, int destOrder, int destX, int destY, int destWidth, int destHeight, byte[] destReds, byte[] destGreens, byte[] destBlues, boolean flipX, boolean flipY)
/*      */   {
/* 3129 */     if ((destWidth <= 0) || (destHeight <= 0) || (alphaMode == 0)) { return;
/*      */     }
/*      */     
/* 3132 */     int srcAlphaMask = 0;
/*      */     
/*      */ 
/* 3135 */     int dwm1 = destWidth - 1;
/* 3136 */     int sfxi = dwm1 != 0 ? (int)(((srcWidth << 16) - 1L) / dwm1) : 0;
/* 3137 */     int dhm1 = destHeight - 1;
/* 3138 */     int sfyi = dhm1 != 0 ? (int)(((srcHeight << 16) - 1L) / dhm1) : 0;
/*      */     int stype;
/*      */     int stype;
/*      */     int stype;
/* 3142 */     int stype; switch (srcDepth) {
/*      */     case 8: 
/* 3144 */       int sbpp = 1;
/* 3145 */       stype = 0;
/* 3146 */       break;
/*      */     case 16: 
/* 3148 */       int sbpp = 2;
/* 3149 */       stype = srcOrder == 1 ? 1 : 2;
/* 3150 */       break;
/*      */     case 24: 
/* 3152 */       int sbpp = 3;
/* 3153 */       stype = 3;
/* 3154 */       break;
/*      */     case 32: 
/* 3156 */       int sbpp = 4;
/* 3157 */       stype = srcOrder == 1 ? 4 : 5;
/* 3158 */       break;
/*      */     default: 
/*      */       return; }
/*      */     int stype;
/*      */     int sbpp;
/* 3163 */     int spr = srcY * srcStride + srcX * sbpp;
/*      */     int dtype;
/*      */     int dtype;
/*      */     int dtype;
/* 3167 */     int dtype; switch (destDepth) {
/*      */     case 8: 
/* 3169 */       dtype = 6;
/* 3170 */       break;
/*      */     case 4: 
/* 3172 */       destStride <<= 1;
/* 3173 */       dtype = 7;
/* 3174 */       break;
/*      */     case 2: 
/* 3176 */       destStride <<= 2;
/* 3177 */       dtype = 8;
/* 3178 */       break;
/*      */     case 1: 
/* 3180 */       destStride <<= 3;
/* 3181 */       dtype = destOrder == 1 ? 9 : 10;
/* 3182 */       break;
/*      */     case 3: case 5: case 6: case 7: default: 
/*      */       return;
/*      */     }
/*      */     int dtype;
/* 3187 */     int dpr = (flipY ? destY + dhm1 : destY) * destStride + (flipX ? destX + dwm1 : destX);
/* 3188 */     int dprxi = flipX ? -1 : 1;
/* 3189 */     int dpryi = flipY ? -destStride : destStride;
/*      */     
/*      */     int apr;
/*      */     
/* 3193 */     if ((op & 0x2) != 0) { int apr;
/* 3194 */       int apr; int apr; int apr; switch (alphaMode) {
/*      */       case -3: 
/*      */       case -1: 
/* 3197 */         if (alphaData == null) alphaMode = 65536;
/* 3198 */         apr = alphaY * alphaStride + alphaX;
/* 3199 */         break;
/*      */       case -4: 
/* 3201 */         if (alphaData == null) alphaMode = 65536;
/* 3202 */         alphaStride <<= 3;
/* 3203 */         apr = alphaY * alphaStride + alphaX;
/* 3204 */         break;
/*      */       
/*      */       case -5: 
/* 3207 */         return;
/*      */       case -6: 
/* 3209 */         if (alphaData == null) alphaMode = 65536;
/* 3210 */         apr = 0;
/* 3211 */         break;
/*      */       default: 
/* 3213 */         alphaMode = (alphaMode << 16) / 255;
/*      */       case -2: 
/* 3215 */         apr = 0;
/* 3216 */         break;
/*      */       }
/*      */     } else {
/* 3219 */       alphaMode = 65536;
/* 3220 */       apr = 0;
/*      */     }
/* 3222 */     boolean ditherEnabled = (op & 0x4) != 0;
/*      */     
/*      */ 
/* 3225 */     int srcRedShift = getChannelShift(srcRedMask);
/* 3226 */     byte[] srcReds = ANY_TO_EIGHT[getChannelWidth(srcRedMask, srcRedShift)];
/* 3227 */     int srcGreenShift = getChannelShift(srcGreenMask);
/* 3228 */     byte[] srcGreens = ANY_TO_EIGHT[getChannelWidth(srcGreenMask, srcGreenShift)];
/* 3229 */     int srcBlueShift = getChannelShift(srcBlueMask);
/* 3230 */     byte[] srcBlues = ANY_TO_EIGHT[getChannelWidth(srcBlueMask, srcBlueShift)];
/* 3231 */     int srcAlphaShift = getChannelShift(0);
/* 3232 */     byte[] srcAlphas = ANY_TO_EIGHT[getChannelWidth(0, srcAlphaShift)];
/*      */     
/* 3234 */     int dp = dpr;
/* 3235 */     int sp = spr;
/* 3236 */     int ap = apr;int alpha = alphaMode;
/* 3237 */     int r = 0;int g = 0;int b = 0;int a = 0;
/* 3238 */     int indexq = 0;
/* 3239 */     int lastindex = 0;int lastr = -1;int lastg = -1;int lastb = -1;
/*      */     
/* 3241 */     int destPaletteSize = 1 << destDepth;
/* 3242 */     if ((destReds != null) && (destReds.length < destPaletteSize)) destPaletteSize = destReds.length;
/* 3243 */     int[] berr; int[] rerr; int[] gerr; int[] berr; if (ditherEnabled) {
/* 3244 */       int[] rerr = new int[destWidth + 2];
/* 3245 */       int[] gerr = new int[destWidth + 2];
/* 3246 */       berr = new int[destWidth + 2];
/*      */     } else {
/* 3248 */       rerr = null;gerr = null;berr = null;
/*      */     }
/* 3250 */     int dy = destHeight; for (int sfy = sfyi; dy > 0;)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 3255 */       int lrerr = 0;int lgerr = 0;int lberr = 0;
/* 3256 */       int dx = destWidth; for (int sfx = sfxi; dx > 0;)
/*      */       {
/*      */ 
/*      */ 
/* 3260 */         switch (stype) {
/*      */         case 0: 
/* 3262 */           int data = srcData[sp] & 0xFF;
/* 3263 */           sp += (sfx >>> 16);
/* 3264 */           r = srcReds[((data & srcRedMask) >>> srcRedShift)] & 0xFF;
/* 3265 */           g = srcGreens[((data & srcGreenMask) >>> srcGreenShift)] & 0xFF;
/* 3266 */           b = srcBlues[((data & srcBlueMask) >>> srcBlueShift)] & 0xFF;
/* 3267 */           a = srcAlphas[((data & 0x0) >>> srcAlphaShift)] & 0xFF;
/* 3268 */           break;
/*      */         case 1: 
/* 3270 */           int data = (srcData[sp] & 0xFF) << 8 | srcData[(sp + 1)] & 0xFF;
/* 3271 */           sp += (sfx >>> 16) * 2;
/* 3272 */           r = srcReds[((data & srcRedMask) >>> srcRedShift)] & 0xFF;
/* 3273 */           g = srcGreens[((data & srcGreenMask) >>> srcGreenShift)] & 0xFF;
/* 3274 */           b = srcBlues[((data & srcBlueMask) >>> srcBlueShift)] & 0xFF;
/* 3275 */           a = srcAlphas[((data & 0x0) >>> srcAlphaShift)] & 0xFF;
/* 3276 */           break;
/*      */         case 2: 
/* 3278 */           int data = (srcData[(sp + 1)] & 0xFF) << 8 | srcData[sp] & 0xFF;
/* 3279 */           sp += (sfx >>> 16) * 2;
/* 3280 */           r = srcReds[((data & srcRedMask) >>> srcRedShift)] & 0xFF;
/* 3281 */           g = srcGreens[((data & srcGreenMask) >>> srcGreenShift)] & 0xFF;
/* 3282 */           b = srcBlues[((data & srcBlueMask) >>> srcBlueShift)] & 0xFF;
/* 3283 */           a = srcAlphas[((data & 0x0) >>> srcAlphaShift)] & 0xFF;
/* 3284 */           break;
/*      */         case 3: 
/* 3286 */           int data = ((srcData[sp] & 0xFF) << 8 | srcData[(sp + 1)] & 0xFF) << 8 | srcData[(sp + 2)] & 0xFF;
/*      */           
/*      */ 
/* 3289 */           sp += (sfx >>> 16) * 3;
/* 3290 */           r = srcReds[((data & srcRedMask) >>> srcRedShift)] & 0xFF;
/* 3291 */           g = srcGreens[((data & srcGreenMask) >>> srcGreenShift)] & 0xFF;
/* 3292 */           b = srcBlues[((data & srcBlueMask) >>> srcBlueShift)] & 0xFF;
/* 3293 */           a = srcAlphas[((data & 0x0) >>> srcAlphaShift)] & 0xFF;
/* 3294 */           break;
/*      */         case 4: 
/* 3296 */           int data = (((srcData[sp] & 0xFF) << 8 | srcData[(sp + 1)] & 0xFF) << 8 | srcData[(sp + 2)] & 0xFF) << 8 | srcData[(sp + 3)] & 0xFF;
/*      */           
/*      */ 
/*      */ 
/* 3300 */           sp += (sfx >>> 16) * 4;
/* 3301 */           r = srcReds[((data & srcRedMask) >>> srcRedShift)] & 0xFF;
/* 3302 */           g = srcGreens[((data & srcGreenMask) >>> srcGreenShift)] & 0xFF;
/* 3303 */           b = srcBlues[((data & srcBlueMask) >>> srcBlueShift)] & 0xFF;
/* 3304 */           a = srcAlphas[((data & 0x0) >>> srcAlphaShift)] & 0xFF;
/* 3305 */           break;
/*      */         case 5: 
/* 3307 */           int data = (((srcData[(sp + 3)] & 0xFF) << 8 | srcData[(sp + 2)] & 0xFF) << 8 | srcData[(sp + 1)] & 0xFF) << 8 | srcData[sp] & 0xFF;
/*      */           
/*      */ 
/*      */ 
/* 3311 */           sp += (sfx >>> 16) * 4;
/* 3312 */           r = srcReds[((data & srcRedMask) >>> srcRedShift)] & 0xFF;
/* 3313 */           g = srcGreens[((data & srcGreenMask) >>> srcGreenShift)] & 0xFF;
/* 3314 */           b = srcBlues[((data & srcBlueMask) >>> srcBlueShift)] & 0xFF;
/* 3315 */           a = srcAlphas[((data & 0x0) >>> srcAlphaShift)] & 0xFF;
/*      */         }
/*      */         
/*      */         
/*      */ 
/* 3320 */         switch (alphaMode) {
/*      */         case -1: 
/* 3322 */           alpha = ((alphaData[ap] & 0xFF) << 16) / 255;
/* 3323 */           ap += (sfx >> 16);
/* 3324 */           break;
/*      */         case -2: 
/* 3326 */           alpha = (a << 16) / 255;
/* 3327 */           break;
/*      */         case -3: 
/* 3329 */           alpha = alphaData[ap] != 0 ? 65536 : 0;
/* 3330 */           ap += (sfx >> 16);
/* 3331 */           break;
/*      */         case -4: 
/* 3333 */           alpha = alphaData[(ap >> 3)] << (ap & 0x7) + 9 & 0x10000;
/* 3334 */           ap += (sfx >> 16);
/* 3335 */           break;
/*      */         case -6: 
/* 3337 */           alpha = 65536;
/* 3338 */           for (int i = 0; i < alphaData.length; i += 3) {
/* 3339 */             if ((r == alphaData[i]) && (g == alphaData[(i + 1)]) && (b == alphaData[(i + 2)])) {
/* 3340 */               alpha = 0;
/* 3341 */               break;
/*      */             }
/*      */           }
/*      */         }
/*      */         
/* 3346 */         if (alpha != 65536) {
/* 3347 */           if (alpha != 0) {
/* 3348 */             switch (dtype) {
/*      */             case 6: 
/* 3350 */               indexq = destData[dp] & 0xFF;
/* 3351 */               break;
/*      */             case 7: 
/* 3353 */               if ((dp & 0x1) != 0) indexq = destData[(dp >> 1)] & 0xF; else
/* 3354 */                 indexq = destData[(dp >> 1)] >>> 4 & 0xF;
/* 3355 */               break;
/*      */             case 8: 
/* 3357 */               indexq = destData[(dp >> 2)] >>> 6 - (dp & 0x3) * 2 & 0x3;
/* 3358 */               break;
/*      */             case 9: 
/* 3360 */               indexq = destData[(dp >> 3)] >>> 7 - (dp & 0x7) & 0x1;
/* 3361 */               break;
/*      */             case 10: 
/* 3363 */               indexq = destData[(dp >> 3)] >>> (dp & 0x7) & 0x1;
/*      */             }
/*      */             
/*      */             
/* 3367 */             int rq = destReds[indexq] & 0xFF;
/* 3368 */             int gq = destGreens[indexq] & 0xFF;
/* 3369 */             int bq = destBlues[indexq] & 0xFF;
/* 3370 */             r = rq + ((r - rq) * alpha >> 16);
/* 3371 */             g = gq + ((g - gq) * alpha >> 16);
/* 3372 */             b = bq + ((b - bq) * alpha >> 16);
/*      */           }
/*      */         }
/*      */         else {
/* 3376 */           if (ditherEnabled)
/*      */           {
/* 3378 */             r += (rerr[dx] >> 4);
/* 3379 */             if (r < 0) r = 0; else if (r > 255) r = 255;
/* 3380 */             g += (gerr[dx] >> 4);
/* 3381 */             if (g < 0) g = 0; else if (g > 255) g = 255;
/* 3382 */             b += (berr[dx] >> 4);
/* 3383 */             if (b < 0) b = 0; else if (b > 255) b = 255;
/* 3384 */             rerr[dx] = lrerr;
/* 3385 */             gerr[dx] = lgerr;
/* 3386 */             berr[dx] = lberr;
/*      */           }
/* 3388 */           if ((r != lastr) || (g != lastg) || (b != lastb))
/*      */           {
/* 3390 */             int j = 0; for (int minDistance = Integer.MAX_VALUE; j < destPaletteSize; j++) {
/* 3391 */               int dr = (destReds[j] & 0xFF) - r;
/* 3392 */               int dg = (destGreens[j] & 0xFF) - g;
/* 3393 */               int db = (destBlues[j] & 0xFF) - b;
/* 3394 */               int distance = dr * dr + dg * dg + db * db;
/* 3395 */               if (distance < minDistance) {
/* 3396 */                 lastindex = j;
/* 3397 */                 if (distance == 0) break;
/* 3398 */                 minDistance = distance;
/*      */               }
/*      */             }
/* 3401 */             lastr = r;lastg = g;lastb = b;
/*      */           }
/* 3403 */           if (ditherEnabled)
/*      */           {
/* 3405 */             int dxm1 = dx - 1;int dxp1 = dx + 1;
/*      */             int acc;
/* 3407 */             rerr[dxp1] += (acc = (lrerr = r - (destReds[lastindex] & 0xFF)) + lrerr + lrerr);
/* 3408 */             rerr[dx] += acc += lrerr + lrerr;
/* 3409 */             rerr[dxm1] += acc + lrerr + lrerr;
/* 3410 */             gerr[dxp1] += (acc = (lgerr = g - (destGreens[lastindex] & 0xFF)) + lgerr + lgerr);
/* 3411 */             gerr[dx] += acc += lgerr + lgerr;
/* 3412 */             gerr[dxm1] += acc + lgerr + lgerr;
/* 3413 */             berr[dxp1] += (acc = (lberr = b - (destBlues[lastindex] & 0xFF)) + lberr + lberr);
/* 3414 */             berr[dx] += acc += lberr + lberr;
/* 3415 */             berr[dxm1] += acc + lberr + lberr;
/*      */           }
/*      */           
/*      */ 
/* 3419 */           switch (dtype) {
/*      */           case 6: 
/* 3421 */             destData[dp] = ((byte)lastindex);
/* 3422 */             break;
/*      */           case 7: 
/* 3424 */             if ((dp & 0x1) != 0) destData[(dp >> 1)] = ((byte)(destData[(dp >> 1)] & 0xF0 | lastindex)); else
/* 3425 */               destData[(dp >> 1)] = ((byte)(destData[(dp >> 1)] & 0xF | lastindex << 4));
/* 3426 */             break;
/*      */           case 8: 
/* 3428 */             int shift = 6 - (dp & 0x3) * 2;
/* 3429 */             destData[(dp >> 2)] = ((byte)(destData[(dp >> 2)] & (3 << shift ^ 0xFFFFFFFF) | lastindex << shift));
/* 3430 */             break;
/*      */           case 9: 
/* 3432 */             int shift = 7 - (dp & 0x7);
/* 3433 */             destData[(dp >> 3)] = ((byte)(destData[(dp >> 3)] & (1 << shift ^ 0xFFFFFFFF) | lastindex << shift));
/* 3434 */             break;
/*      */           case 10: 
/* 3436 */             int shift = dp & 0x7;
/* 3437 */             destData[(dp >> 3)] = ((byte)(destData[(dp >> 3)] & (1 << shift ^ 0xFFFFFFFF) | lastindex << shift));
/*      */           }
/*      */         }
/* 3256 */         dx--;
/* 3257 */         dp += dprxi;
/* 3258 */         sfx = (sfx & 0xFFFF) + sfxi;
/*      */       }
/* 3250 */       dy--;
/* 3251 */       sp = spr += (sfy >>> 16) * srcStride;
/* 3252 */       ap = apr += (sfy >>> 16) * alphaStride;
/* 3253 */       sfy = (sfy & 0xFFFF) + sfyi;
/* 3254 */       dp = dpr += dpryi;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static int getChannelShift(int mask)
/*      */   {
/* 3448 */     if (mask == 0) { return 0;
/*      */     }
/* 3450 */     for (int i = 0; ((mask & 0x1) == 0) && (i < 32); i++) {
/* 3451 */       mask >>>= 1;
/*      */     }
/* 3453 */     return i;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   static int getChannelWidth(int mask, int shift)
/*      */   {
/* 3460 */     if (mask == 0) { return 0;
/*      */     }
/* 3462 */     mask >>>= shift;
/* 3463 */     for (int i = shift; ((mask & 0x1) != 0) && (i < 32); i++) {
/* 3464 */       mask >>>= 1;
/*      */     }
/* 3466 */     return i - shift;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   static byte getChannelField(int data, int mask)
/*      */   {
/* 3473 */     int shift = getChannelShift(mask);
/* 3474 */     return ANY_TO_EIGHT[getChannelWidth(mask, shift)][((data & mask) >>> shift)];
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   static ImageData createGradientBand(int width, int height, boolean vertical, RGB fromRGB, RGB toRGB, int redBits, int greenBits, int blueBits)
/*      */   {
/*      */     PaletteData paletteData;
/*      */     
/*      */ 
/*      */ 
/*      */     int bitmapDepth;
/*      */     
/*      */ 
/*      */ 
/*      */     int bandWidth;
/*      */     
/*      */ 
/*      */ 
/*      */     int bandHeight;
/*      */     
/*      */ 
/*      */ 
/*      */     byte[] bitmapData;
/*      */     
/*      */ 
/*      */ 
/* 3502 */     if ((redBits != 0) && (greenBits != 0) && (blueBits != 0)) {
/* 3503 */       PaletteData paletteData = new PaletteData(65280, 16711680, -16777216);
/* 3504 */       int bitmapDepth = 32;
/* 3505 */       if ((redBits >= 8) && (greenBits >= 8) && (blueBits >= 8)) { int steps;
/*      */         int bandWidth;
/*      */         int bandHeight;
/* 3508 */         int steps; if (vertical) {
/* 3509 */           int bandWidth = 1;
/* 3510 */           int bandHeight = height;
/* 3511 */           steps = bandHeight > 1 ? bandHeight - 1 : 1;
/*      */         } else {
/* 3513 */           bandWidth = width;
/* 3514 */           bandHeight = 1;
/* 3515 */           steps = bandWidth > 1 ? bandWidth - 1 : 1;
/*      */         }
/* 3517 */         int bytesPerLine = bandWidth * 4;
/* 3518 */         byte[] bitmapData = new byte[bandHeight * bytesPerLine];
/* 3519 */         buildPreciseGradientChannel(fromRGB.blue, toRGB.blue, steps, bandWidth, bandHeight, vertical, bitmapData, 0, bytesPerLine);
/* 3520 */         buildPreciseGradientChannel(fromRGB.green, toRGB.green, steps, bandWidth, bandHeight, vertical, bitmapData, 1, bytesPerLine);
/* 3521 */         buildPreciseGradientChannel(fromRGB.red, toRGB.red, steps, bandWidth, bandHeight, vertical, bitmapData, 2, bytesPerLine); } else { int steps;
/*      */         int bandWidth;
/*      */         int bandHeight;
/*      */         int steps;
/* 3525 */         if (vertical) {
/* 3526 */           int bandWidth = width < 8 ? width : 8;
/* 3527 */           int bandHeight = height;
/* 3528 */           steps = bandHeight > 1 ? bandHeight - 1 : 1;
/*      */         } else {
/* 3530 */           bandWidth = width;
/* 3531 */           bandHeight = height < 8 ? height : 8;
/* 3532 */           steps = bandWidth > 1 ? bandWidth - 1 : 1;
/*      */         }
/* 3534 */         int bytesPerLine = bandWidth * 4;
/* 3535 */         byte[] bitmapData = new byte[bandHeight * bytesPerLine];
/* 3536 */         buildDitheredGradientChannel(fromRGB.blue, toRGB.blue, steps, bandWidth, bandHeight, vertical, bitmapData, 0, bytesPerLine, blueBits);
/* 3537 */         buildDitheredGradientChannel(fromRGB.green, toRGB.green, steps, bandWidth, bandHeight, vertical, bitmapData, 1, bytesPerLine, greenBits);
/* 3538 */         buildDitheredGradientChannel(fromRGB.red, toRGB.red, steps, bandWidth, bandHeight, vertical, bitmapData, 2, bytesPerLine, redBits);
/*      */       }
/*      */     }
/*      */     else {
/* 3542 */       paletteData = new PaletteData(new RGB[] { fromRGB, toRGB });
/* 3543 */       bitmapDepth = 8;
/*      */       int blendi;
/* 3545 */       int blendi; if (vertical) {
/* 3546 */         int bandWidth = width < 8 ? width : 8;
/* 3547 */         int bandHeight = height;
/* 3548 */         blendi = bandHeight > 1 ? 17039360 / (bandHeight - 1) + 1 : 1;
/*      */       } else {
/* 3550 */         bandWidth = width;
/* 3551 */         bandHeight = height < 8 ? height : 8;
/* 3552 */         blendi = bandWidth > 1 ? 17039360 / (bandWidth - 1) + 1 : 1;
/*      */       }
/* 3554 */       int bytesPerLine = bandWidth + 3 & 0xFFFFFFFC;
/* 3555 */       bitmapData = new byte[bandHeight * bytesPerLine];
/* 3556 */       if (vertical) {
/* 3557 */         int dy = 0;int blend = 0; for (int dp = 0; dy < bandHeight; 
/* 3558 */             dp += bytesPerLine) {
/* 3559 */           for (int dx = 0; dx < bandWidth; dx++) {
/* 3560 */             bitmapData[(dp + dx)] = (blend + DITHER_MATRIX[(dy & 0x7)][dx] < 16777216 ? 0 : 1);
/*      */           }
/* 3558 */           dy++;blend += blendi;
/*      */         }
/*      */         
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/* 3565 */         int dx = 0; for (int blend = 0; dx < bandWidth; blend += blendi) {
/* 3566 */           int dy = 0; for (int dptr = dx; dy < bandHeight; dptr += bytesPerLine) {
/* 3567 */             bitmapData[dptr] = (blend + DITHER_MATRIX[dy][(dx & 0x7)] < 16777216 ? 0 : 1);dy++;
/*      */           }
/* 3565 */           dx++;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 3573 */     return new ImageData(bandWidth, bandHeight, bitmapDepth, paletteData, 4, bitmapData);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final void buildPreciseGradientChannel(int from, int to, int steps, int bandWidth, int bandHeight, boolean vertical, byte[] bitmapData, int dp, int bytesPerLine)
/*      */   {
/* 3582 */     int val = from << 16;
/* 3583 */     int inc = ((to << 16) - val) / steps + 1;
/* 3584 */     if (vertical) {
/* 3585 */       for (int dy = 0; dy < bandHeight; dp += bytesPerLine) {
/* 3586 */         bitmapData[dp] = ((byte)(val >>> 16));
/* 3587 */         val += inc;dy++;
/*      */       }
/*      */       
/*      */     } else {
/* 3590 */       for (int dx = 0; dx < bandWidth; dp += 4) {
/* 3591 */         bitmapData[dp] = ((byte)(val >>> 16));
/* 3592 */         val += inc;dx++;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final void buildDitheredGradientChannel(int from, int to, int steps, int bandWidth, int bandHeight, boolean vertical, byte[] bitmapData, int dp, int bytesPerLine, int bits)
/*      */   {
/* 3603 */     int mask = 65280 >>> bits;
/* 3604 */     int val = from << 16;
/* 3605 */     int inc = ((to << 16) - val) / steps + 1;
/* 3606 */     if (vertical) {
/* 3607 */       for (int dy = 0; dy < bandHeight; dp += bytesPerLine) {
/* 3608 */         int dx = 0; for (int dptr = dp; dx < bandWidth; dptr += 4) {
/* 3609 */           int thresh = DITHER_MATRIX[(dy & 0x7)][dx] >>> bits;
/* 3610 */           int temp = val + thresh;
/* 3611 */           if (temp > 16777215) bitmapData[dptr] = -1; else {
/* 3612 */             bitmapData[dptr] = ((byte)(temp >>> 16 & mask));
/*      */           }
/* 3608 */           dx++;
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 3614 */         val += inc;dy++;
/*      */       }
/*      */     } else {
/* 3617 */       for (int dx = 0; dx < bandWidth; dp += 4) {
/* 3618 */         int dy = 0; for (int dptr = dp; dy < bandHeight; dptr += bytesPerLine) {
/* 3619 */           int thresh = DITHER_MATRIX[dy][(dx & 0x7)] >>> bits;
/* 3620 */           int temp = val + thresh;
/* 3621 */           if (temp > 16777215) bitmapData[dptr] = -1; else {
/* 3622 */             bitmapData[dptr] = ((byte)(temp >>> 16 & mask));
/*      */           }
/* 3618 */           dy++;
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 3624 */         val += inc;dx++;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static void fillGradientRectangle(GC gc, Device device, int x, int y, int width, int height, boolean vertical, RGB fromRGB, RGB toRGB, int redBits, int greenBits, int blueBits)
/*      */   {
/* 3654 */     ImageData band = createGradientBand(width, height, vertical, fromRGB, toRGB, redBits, greenBits, blueBits);
/*      */     
/* 3656 */     Image image = new Image(device, band);
/* 3657 */     if ((band.width == 1) || (band.height == 1)) {
/* 3658 */       gc.drawImage(image, 0, 0, DPIUtil.autoScaleDown(band.width), DPIUtil.autoScaleDown(band.height), 
/* 3659 */         DPIUtil.autoScaleDown(x), DPIUtil.autoScaleDown(y), DPIUtil.autoScaleDown(width), 
/* 3660 */         DPIUtil.autoScaleDown(height));
/*      */     }
/* 3662 */     else if (vertical) {
/* 3663 */       for (int dx = 0; dx < width; dx += band.width) {
/* 3664 */         int blitWidth = width - dx;
/* 3665 */         if (blitWidth > band.width) blitWidth = band.width;
/* 3666 */         gc.drawImage(image, 0, 0, DPIUtil.autoScaleDown(blitWidth), DPIUtil.autoScaleDown(band.height), 
/* 3667 */           DPIUtil.autoScaleDown(dx + x), DPIUtil.autoScaleDown(y), DPIUtil.autoScaleDown(blitWidth), 
/* 3668 */           DPIUtil.autoScaleDown(band.height));
/*      */       }
/*      */     } else {
/* 3671 */       for (int dy = 0; dy < height; dy += band.height) {
/* 3672 */         int blitHeight = height - dy;
/* 3673 */         if (blitHeight > band.height) blitHeight = band.height;
/* 3674 */         gc.drawImage(image, 0, 0, DPIUtil.autoScaleDown(band.width), DPIUtil.autoScaleDown(blitHeight), 
/* 3675 */           DPIUtil.autoScaleDown(x), DPIUtil.autoScaleDown(dy + y), DPIUtil.autoScaleDown(band.width), 
/* 3676 */           DPIUtil.autoScaleDown(blitHeight));
/*      */       }
/*      */     }
/*      */     
/* 3680 */     image.dispose();
/*      */   }
/*      */   
/*      */   ImageData() {}
/*      */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/graphics/ImageData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */