/*      */ package org.eclipse.swt.widgets;
/*      */ 
/*      */ import org.eclipse.swt.SWT;
/*      */ import org.eclipse.swt.events.ShellListener;
/*      */ import org.eclipse.swt.graphics.Cursor;
/*      */ import org.eclipse.swt.graphics.GC;
/*      */ import org.eclipse.swt.graphics.Point;
/*      */ import org.eclipse.swt.graphics.Rectangle;
/*      */ import org.eclipse.swt.graphics.Region;
/*      */ import org.eclipse.swt.internal.Callback;
/*      */ import org.eclipse.swt.internal.Converter;
/*      */ import org.eclipse.swt.internal.DPIUtil;
/*      */ import org.eclipse.swt.internal.cairo.Cairo;
/*      */ import org.eclipse.swt.internal.gtk.GDK;
/*      */ import org.eclipse.swt.internal.gtk.GTK;
/*      */ import org.eclipse.swt.internal.gtk.GdkColor;
/*      */ import org.eclipse.swt.internal.gtk.GdkEventButton;
/*      */ import org.eclipse.swt.internal.gtk.GdkEventCrossing;
/*      */ import org.eclipse.swt.internal.gtk.GdkEventExpose;
/*      */ import org.eclipse.swt.internal.gtk.GdkEventKey;
/*      */ import org.eclipse.swt.internal.gtk.GdkEventMotion;
/*      */ import org.eclipse.swt.internal.gtk.GdkEventWindowState;
/*      */ import org.eclipse.swt.internal.gtk.GdkGeometry;
/*      */ import org.eclipse.swt.internal.gtk.GdkRGBA;
/*      */ import org.eclipse.swt.internal.gtk.GdkRectangle;
/*      */ import org.eclipse.swt.internal.gtk.GdkWindowAttr;
/*      */ import org.eclipse.swt.internal.gtk.GtkAllocation;
/*      */ import org.eclipse.swt.internal.gtk.GtkRequisition;
/*      */ import org.eclipse.swt.internal.gtk.OS;
/*      */ import org.eclipse.swt.internal.gtk.XFocusChangeEvent;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class Shell
/*      */   extends Decorations
/*      */ {
/*      */   long shellHandle;
/*      */   long tooltipsHandle;
/*      */   long tooltipWindow;
/*      */   long group;
/*      */   long modalGroup;
/*      */   boolean mapped;
/*      */   boolean moved;
/*      */   boolean resized;
/*      */   boolean opened;
/*      */   boolean fullScreen;
/*      */   boolean showWithParent;
/*      */   boolean modified;
/*      */   boolean center;
/*      */   int oldX;
/*      */   int oldY;
/*      */   int oldWidth;
/*      */   int oldHeight;
/*      */   int minWidth;
/*      */   int minHeight;
/*      */   Control lastActive;
/*      */   ToolTip[] toolTips;
/*      */   boolean ignoreFocusOut;
/*      */   Region originalRegion;
/*      */   static final int MAXIMUM_TRIM = 128;
/*      */   static final int BORDER = 3;
/*      */   static Callback gdkSeatGrabCallback;
/*      */   
/*      */   public Shell()
/*      */   {
/*  146 */     this((Display)null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Shell(int style)
/*      */   {
/*  188 */     this((Display)null, style);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Shell(Display display)
/*      */   {
/*  211 */     this(display, 1264);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Shell(Display display, int style)
/*      */   {
/*  261 */     this(display, null, style, 0L, false);
/*      */   }
/*      */   
/*      */   Shell(Display display, Shell parent, int style, long handle, boolean embedded)
/*      */   {
/*  266 */     checkSubclass();
/*  267 */     if (display == null) display = Display.getCurrent();
/*  268 */     if (display == null) display = Display.getDefault();
/*  269 */     if (!display.isValidThread()) {
/*  270 */       error(22);
/*      */     }
/*  272 */     if ((parent != null) && (parent.isDisposed())) {
/*  273 */       error(5);
/*      */     }
/*  275 */     this.center = ((parent != null) && ((style & 0x10000000) != 0));
/*  276 */     this.style = checkStyle(parent, style);
/*  277 */     this.parent = parent;
/*  278 */     this.display = display;
/*  279 */     if (handle != 0L) {
/*  280 */       if (embedded) {
/*  281 */         this.handle = handle;
/*      */       } else {
/*  283 */         this.shellHandle = handle;
/*  284 */         this.state |= 0x400000;
/*      */       }
/*      */     }
/*  287 */     reskinWidget();
/*  288 */     createWidget(0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Shell(Shell parent)
/*      */   {
/*  314 */     this(parent, 2144);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Shell(Shell parent, int style)
/*      */   {
/*  367 */     this(parent != null ? parent.display : null, parent, style, 0L, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Shell gtk_new(Display display, long handle)
/*      */   {
/*  388 */     return new Shell(display, null, 8, handle, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Shell internal_new(Display display, long handle)
/*      */   {
/*  411 */     return new Shell(display, null, 8, handle, false);
/*      */   }
/*      */   
/*      */   static int checkStyle(Shell parent, int style) {
/*  415 */     style = Decorations.checkStyle(style);
/*  416 */     style &= 0xBFFFFFFF;
/*  417 */     if ((style & 0x4000) != 0) style &= 0xFB1F;
/*  418 */     int mask = 229376;
/*  419 */     if ((style & 0x10000000) != 0) {
/*  420 */       style &= 0xEFFFFFFF;
/*  421 */       style |= (parent == null ? 1264 : 2144);
/*  422 */       if ((style & mask) == 0) {
/*  423 */         style |= (parent == null ? 65536 : 32768);
/*      */       }
/*      */     }
/*  426 */     int bits = style & (mask ^ 0xFFFFFFFF);
/*  427 */     if ((style & 0x20000) != 0) return bits | 0x20000;
/*  428 */     if ((style & 0x10000) != 0) return bits | 0x10000;
/*  429 */     if ((style & 0x8000) != 0) return bits | 0x8000;
/*  430 */     return bits;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addShellListener(ShellListener listener)
/*      */   {
/*  453 */     checkWidget();
/*  454 */     if (listener == null) error(4);
/*  455 */     TypedListener typedListener = new TypedListener(listener);
/*  456 */     addListener(21, typedListener);
/*  457 */     addListener(19, typedListener);
/*  458 */     addListener(20, typedListener);
/*  459 */     addListener(26, typedListener);
/*  460 */     addListener(27, typedListener);
/*      */   }
/*      */   
/*      */   void addToolTip(ToolTip toolTip) {
/*  464 */     if (this.toolTips == null) this.toolTips = new ToolTip[4];
/*  465 */     for (int i = 0; i < this.toolTips.length; i++) {
/*  466 */       if (this.toolTips[i] == null) {
/*  467 */         this.toolTips[i] = toolTip;
/*  468 */         return;
/*      */       }
/*      */     }
/*  471 */     ToolTip[] newToolTips = new ToolTip[this.toolTips.length + 4];
/*  472 */     newToolTips[this.toolTips.length] = toolTip;
/*  473 */     System.arraycopy(this.toolTips, 0, newToolTips, 0, this.toolTips.length);
/*  474 */     this.toolTips = newToolTips;
/*      */   }
/*      */   
/*      */   void adjustTrim() {
/*  478 */     if (this.display.ignoreTrim) return;
/*  479 */     GtkAllocation allocation = new GtkAllocation();
/*  480 */     GTK.gtk_widget_get_allocation(this.shellHandle, allocation);
/*  481 */     int width = allocation.width;
/*  482 */     int height = allocation.height;
/*  483 */     long window = gtk_widget_get_window(this.shellHandle);
/*  484 */     GdkRectangle rect = new GdkRectangle();
/*  485 */     GDK.gdk_window_get_frame_extents(window, rect);
/*  486 */     int trimWidth = Math.max(0, rect.width - width);
/*  487 */     int trimHeight = Math.max(0, rect.height - height);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  493 */     if ((trimWidth > 128) || (trimHeight > 128)) {
/*  494 */       this.display.ignoreTrim = true;
/*  495 */       return;
/*      */     }
/*  497 */     boolean hasTitle = false;boolean hasResize = false;boolean hasBorder = false;
/*  498 */     if ((this.style & 0x8) == 0) {
/*  499 */       hasTitle = (this.style & 0x4E0) != 0;
/*  500 */       hasResize = (this.style & 0x10) != 0;
/*  501 */       hasBorder = (this.style & 0x800) != 0; }
/*      */     int trimStyle;
/*      */     int trimStyle;
/*  504 */     if (hasTitle) { int trimStyle;
/*  505 */       if (hasResize) {
/*  506 */         trimStyle = 4; } else { int trimStyle;
/*  507 */         if (hasBorder) {
/*  508 */           trimStyle = 3;
/*      */         } else
/*  510 */           trimStyle = 5;
/*      */       } } else { int trimStyle;
/*  512 */       if (hasResize) {
/*  513 */         trimStyle = 2; } else { int trimStyle;
/*  514 */         if (hasBorder) {
/*  515 */           trimStyle = 1;
/*      */         } else
/*  517 */           trimStyle = 0;
/*      */       } }
/*  519 */     if (GTK.GTK3)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  525 */       Rectangle bounds = getBoundsInPixels();
/*  526 */       int widthAdjustment = this.display.trimWidths[trimStyle] - trimWidth;
/*  527 */       int heightAdjustment = this.display.trimHeights[trimStyle] - trimHeight;
/*  528 */       if ((widthAdjustment == 0) && (heightAdjustment == 0)) { return;
/*      */       }
/*  530 */       bounds.width += widthAdjustment;
/*  531 */       bounds.height += heightAdjustment;
/*  532 */       this.oldWidth += widthAdjustment;
/*  533 */       this.oldHeight += heightAdjustment;
/*  534 */       if (!getMaximized()) {
/*  535 */         resizeBounds(width + widthAdjustment, height + heightAdjustment, false);
/*      */       }
/*      */     }
/*  538 */     this.display.trimWidths[trimStyle] = trimWidth;
/*  539 */     this.display.trimHeights[trimStyle] = trimHeight;
/*      */   }
/*      */   
/*      */   void bringToTop(boolean force) {
/*  543 */     if (!GTK.gtk_widget_get_visible(this.shellHandle)) return;
/*  544 */     Display display = this.display;
/*  545 */     Shell activeShell = display.activeShell;
/*  546 */     if (activeShell == this) return;
/*  547 */     if (!force) {
/*  548 */       if (activeShell == null) return;
/*  549 */       if (!display.activePending) {
/*  550 */         long focusHandle = GTK.gtk_window_get_focus(activeShell.shellHandle);
/*  551 */         if ((focusHandle != 0L) && (!GTK.gtk_widget_has_focus(focusHandle))) { return;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  564 */     boolean xFocus = false;
/*  565 */     if (activeShell != null) {
/*  566 */       display.activeShell = null;
/*  567 */       display.activePending = true;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  575 */     long window = gtk_widget_get_window(this.shellHandle);
/*  576 */     if ((xFocus) || ((this.style & 0x4000) != 0)) {
/*  577 */       if (OS.isX11()) {
/*  578 */         long gdkDisplay = GDK.gdk_window_get_display(window);
/*  579 */         long xDisplay = GDK.gdk_x11_display_get_xdisplay(gdkDisplay);
/*      */         long xWindow;
/*  581 */         if (GTK.GTK3) {
/*  582 */           long xWindow = GDK.gdk_x11_window_get_xid(window);
/*  583 */           GDK.gdk_x11_display_error_trap_push(gdkDisplay);
/*      */         } else {
/*  585 */           xWindow = GDK.gdk_x11_drawable_get_xid(window);
/*  586 */           GDK.gdk_error_trap_push();
/*      */         }
/*      */         
/*  589 */         OS.XSetInputFocus(xDisplay, xWindow, 2, 0);
/*  590 */         if (GTK.GTK3) {
/*  591 */           GDK.gdk_x11_display_error_trap_pop_ignored(gdkDisplay);
/*      */         } else {
/*  593 */           GDK.gdk_error_trap_pop();
/*      */         }
/*      */       }
/*  596 */       else if (GTK.GTK_VERSION >= OS.VERSION(3, 20, 0)) {
/*  597 */         if (gdkSeatGrabCallback == null) {
/*  598 */           gdkSeatGrabCallback = new Callback(Shell.class, "GdkSeatGrabPrepareFunc", 3);
/*      */         }
/*  600 */         long gdkSeatGrabPrepareFunc = gdkSeatGrabCallback.getAddress();
/*  601 */         if (gdkSeatGrabPrepareFunc == 0L) SWT.error(3);
/*  602 */         GTK.gtk_grab_add(this.shellHandle);
/*  603 */         long seat = GDK.gdk_display_get_default_seat(GDK.gdk_window_get_display(window));
/*  604 */         GDK.gdk_seat_grab(seat, window, 1, true, 0L, 0L, gdkSeatGrabPrepareFunc, this.shellHandle);
/*      */ 
/*      */ 
/*      */ 
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */     }
/*  614 */     else if (display.windowManager.toLowerCase().equals("metacity")) {
/*  615 */       GDK.gdk_window_focus(window, display.lastUserEventTime);
/*      */     } else {
/*  617 */       GDK.gdk_window_focus(window, 0);
/*      */     }
/*      */     
/*  620 */     display.activeShell = this;
/*  621 */     display.activePending = true;
/*      */   }
/*      */   
/*      */   void center() {
/*  625 */     if (this.parent == null) return;
/*  626 */     Rectangle rect = getBoundsInPixels();
/*  627 */     Rectangle parentRect = this.display.mapInPixels(this.parent, null, this.parent.getClientAreaInPixels());
/*  628 */     int x = Math.max(parentRect.x, parentRect.x + (parentRect.width - rect.width) / 2);
/*  629 */     int y = Math.max(parentRect.y, parentRect.y + (parentRect.height - rect.height) / 2);
/*  630 */     Rectangle monitorRect = DPIUtil.autoScaleUp(this.parent.getMonitor().getClientArea());
/*  631 */     if (x + rect.width > monitorRect.x + monitorRect.width) {
/*  632 */       x = Math.max(monitorRect.x, monitorRect.x + monitorRect.width - rect.width);
/*      */     } else {
/*  634 */       x = Math.max(x, monitorRect.x);
/*      */     }
/*  636 */     if (y + rect.height > monitorRect.y + monitorRect.height) {
/*  637 */       y = Math.max(monitorRect.y, monitorRect.y + monitorRect.height - rect.height);
/*      */     } else {
/*  639 */       y = Math.max(y, monitorRect.y);
/*      */     }
/*  641 */     setLocationInPixels(x, y);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   void checkBorder() {}
/*      */   
/*      */ 
/*      */   void checkOpen()
/*      */   {
/*  651 */     if (!this.opened) this.resized = false;
/*      */   }
/*      */   
/*      */   long childStyle()
/*      */   {
/*  656 */     return 0L;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void close()
/*      */   {
/*  675 */     checkWidget();
/*  676 */     closeWidget();
/*      */   }
/*      */   
/*  679 */   void closeWidget() { Event event = new Event();
/*  680 */     sendEvent(21, event);
/*  681 */     if ((event.doit) && (!isDisposed())) dispose();
/*      */   }
/*      */   
/*      */   Rectangle computeTrimInPixels(int x, int y, int width, int height)
/*      */   {
/*  686 */     checkWidget();
/*  687 */     Rectangle trim = super.computeTrimInPixels(x, y, width, height);
/*  688 */     int border = 0;
/*  689 */     if ((this.style & 0xCF8) == 0) {
/*  690 */       border = GTK.gtk_container_get_border_width(this.shellHandle);
/*      */     }
/*  692 */     if (isCustomResize()) {
/*  693 */       border = GTK.gtk_container_get_border_width(this.shellHandle);
/*      */     }
/*  695 */     int trimWidth = trimWidth();int trimHeight = trimHeight();
/*  696 */     trim.x -= trimWidth / 2 + border;
/*  697 */     trim.y -= trimHeight - trimWidth / 2 + border;
/*  698 */     trim.width += trimWidth + border * 2;
/*  699 */     trim.height += trimHeight + border * 2;
/*  700 */     if (this.menuBar != null) {
/*  701 */       forceResize();
/*  702 */       GtkAllocation allocation = new GtkAllocation();
/*  703 */       GTK.gtk_widget_get_allocation(this.menuBar.handle, allocation);
/*  704 */       int menuBarHeight = allocation.height;
/*  705 */       trim.y -= menuBarHeight;
/*  706 */       trim.height += menuBarHeight;
/*      */     }
/*  708 */     return trim;
/*      */   }
/*      */   
/*      */   void createHandle(int index)
/*      */   {
/*  713 */     this.state |= 0xA;
/*  714 */     if (this.shellHandle == 0L) {
/*  715 */       if (this.handle == 0L) {
/*  716 */         int type = 0;
/*  717 */         if ((this.style & 0x4000) != 0) type = 1;
/*  718 */         this.shellHandle = GTK.gtk_window_new(type);
/*      */       } else {
/*  720 */         this.shellHandle = GTK.gtk_plug_new(this.handle);
/*      */       }
/*  722 */       if (this.shellHandle == 0L) error(2);
/*  723 */       if (this.parent != null) {
/*  724 */         GTK.gtk_window_set_transient_for(this.shellHandle, this.parent.topHandle());
/*  725 */         GTK.gtk_window_set_destroy_with_parent(this.shellHandle, true);
/*      */         
/*      */ 
/*  728 */         if ((this.style & 0x80) == 0) {
/*  729 */           GTK.gtk_window_set_skip_taskbar_hint(this.shellHandle, true);
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  748 */       if ((this.style & 0x10) != 0) {
/*  749 */         GTK.gtk_widget_set_size_request(this.shellHandle, 0, 0);
/*  750 */         GTK.gtk_window_set_resizable(this.shellHandle, true);
/*      */       } else {
/*  752 */         GTK.gtk_window_set_resizable(this.shellHandle, false);
/*      */       }
/*  754 */       GTK.gtk_window_set_title(this.shellHandle, new byte[1]);
/*  755 */       if ((this.style & 0xCF8) == 0) {
/*  756 */         GTK.gtk_container_set_border_width(this.shellHandle, 1);
/*  757 */         if (GTK.GTK3) {
/*  758 */           if (GTK.GTK_VERSION < OS.VERSION(3, 14, 0)) {
/*  759 */             GTK.gtk_widget_override_background_color(this.shellHandle, 0, new GdkRGBA());
/*      */           }
/*      */         } else {
/*  762 */           GdkColor color = new GdkColor();
/*  763 */           GTK.gtk_style_get_black(GTK.gtk_widget_get_style(this.shellHandle), color);
/*  764 */           GTK.gtk_widget_modify_bg(this.shellHandle, 0, color);
/*      */         }
/*      */       }
/*  767 */       if ((this.style & 0x8) != 0) {
/*  768 */         GTK.gtk_window_set_decorated(this.shellHandle, false);
/*      */       }
/*  770 */       if (isCustomResize()) {
/*  771 */         GTK.gtk_container_set_border_width(this.shellHandle, 3);
/*      */       }
/*      */     }
/*  774 */     this.vboxHandle = gtk_box_new(1, false, 0);
/*  775 */     if (this.vboxHandle == 0L) error(2);
/*  776 */     createHandle(index, false, true);
/*  777 */     GTK.gtk_container_add(this.vboxHandle, this.scrolledHandle);
/*  778 */     GTK.gtk_box_set_child_packing(this.vboxHandle, this.scrolledHandle, true, true, 0, 1);
/*  779 */     this.group = GTK.gtk_window_group_new();
/*  780 */     if (this.group == 0L) { error(2);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  787 */     GTK.gtk_widget_realize(this.shellHandle);
/*      */   }
/*      */   
/*      */   long filterProc(long xEvent, long gdkEvent, long data2)
/*      */   {
/*  792 */     if (!OS.isX11()) return 0L;
/*  793 */     int eventType = OS.X_EVENT_TYPE(xEvent);
/*  794 */     if ((eventType != 10) && (eventType != 9)) return 0L;
/*  795 */     XFocusChangeEvent xFocusEvent = new XFocusChangeEvent();
/*  796 */     OS.memmove(xFocusEvent, xEvent, XFocusChangeEvent.sizeof);
/*  797 */     switch (eventType) {
/*      */     case 9: 
/*  799 */       if ((xFocusEvent.mode == 0) || (xFocusEvent.mode == 3))
/*  800 */         switch (xFocusEvent.detail) {
/*      */         case 0: 
/*      */         case 3: 
/*      */         case 4: 
/*  804 */           this.display.activeShell = this;
/*  805 */           this.display.activePending = false;
/*  806 */           sendEvent(26);
/*  807 */           if (isDisposed()) return 0L;
/*  808 */           if (isCustomResize())
/*  809 */             GDK.gdk_window_invalidate_rect(gtk_widget_get_window(this.shellHandle), null, false);
/*      */           break; }
/*  811 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */     case 10: 
/*  816 */       if ((xFocusEvent.mode == 0) || (xFocusEvent.mode == 3)) {
/*  817 */         switch (xFocusEvent.detail) {
/*      */         case 1: 
/*      */         case 3: 
/*      */         case 4: 
/*  821 */           Display display = this.display;
/*  822 */           sendEvent(27);
/*  823 */           setActiveControl(null);
/*  824 */           if (display.activeShell == this) {
/*  825 */             display.activeShell = null;
/*  826 */             display.activePending = false;
/*      */           }
/*  828 */           if (isDisposed()) return 0L;
/*  829 */           if (isCustomResize()) {
/*  830 */             GDK.gdk_window_invalidate_rect(gtk_widget_get_window(this.shellHandle), null, false);
/*      */           }
/*      */           break;
/*      */         }
/*      */       }
/*      */       break;
/*      */     }
/*  837 */     return 0L;
/*      */   }
/*      */   
/*      */   Control findBackgroundControl()
/*      */   {
/*  842 */     return ((this.state & 0x2000) != 0) || (this.backgroundImage != null) ? this : null;
/*      */   }
/*      */   
/*      */   Composite findDeferredControl()
/*      */   {
/*  847 */     return this.layoutCount > 0 ? this : null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ToolBar getToolBar()
/*      */   {
/*  867 */     checkWidget();
/*  868 */     return null;
/*      */   }
/*      */   
/*      */   boolean hasBorder()
/*      */   {
/*  873 */     return false;
/*      */   }
/*      */   
/*      */   void hookEvents()
/*      */   {
/*  878 */     super.hookEvents();
/*  879 */     OS.g_signal_connect_closure_by_id(this.shellHandle, this.display.signalIds[27], 0, this.display.getClosure(27), false);
/*  880 */     OS.g_signal_connect_closure_by_id(this.shellHandle, this.display.signalIds[59], 0, this.display.getClosure(59), false);
/*  881 */     OS.g_signal_connect_closure_by_id(this.shellHandle, this.display.signalIds[47], 0, this.display.getClosure(47), false);
/*  882 */     OS.g_signal_connect_closure_by_id(this.shellHandle, this.display.signalIds[10], 0, this.display.getClosure(10), false);
/*  883 */     OS.g_signal_connect_closure_by_id(this.shellHandle, this.display.signalIds[11], 0, this.display.getClosure(11), false);
/*  884 */     OS.g_signal_connect_closure_by_id(this.shellHandle, this.display.signalIds[31], 0, this.display.shellMapProcClosure, false);
/*  885 */     OS.g_signal_connect_closure_by_id(this.shellHandle, this.display.signalIds[14], 0, this.display.getClosure(14), false);
/*  886 */     OS.g_signal_connect_closure(this.shellHandle, OS.move_focus, this.display.getClosure(35), false);
/*  887 */     if (!GTK.GTK3) {
/*  888 */       long window = gtk_widget_get_window(this.shellHandle);
/*  889 */       GDK.gdk_window_add_filter(window, this.display.filterProc, this.shellHandle);
/*      */     } else {
/*  891 */       OS.g_signal_connect_closure_by_id(this.shellHandle, this.display.signalIds[21], 0, this.display.getClosure(21), false);
/*  892 */       OS.g_signal_connect_closure_by_id(this.shellHandle, this.display.signalIds[22], 0, this.display.getClosure(22), false);
/*      */     }
/*  894 */     if (isCustomResize()) {
/*  895 */       int mask = 13060;
/*  896 */       GTK.gtk_widget_add_events(this.shellHandle, mask);
/*  897 */       OS.g_signal_connect_closure_by_id(this.shellHandle, this.display.signalIds[18], 0, this.display.getClosure(18), false);
/*  898 */       OS.g_signal_connect_closure_by_id(this.shellHandle, this.display.signalIds[29], 0, this.display.getClosure(29), false);
/*  899 */       OS.g_signal_connect_closure_by_id(this.shellHandle, this.display.signalIds[33], 0, this.display.getClosure(33), false);
/*  900 */       OS.g_signal_connect_closure_by_id(this.shellHandle, this.display.signalIds[2], 0, this.display.getClosure(2), false);
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean isEnabled()
/*      */   {
/*  906 */     checkWidget();
/*  907 */     return getEnabled();
/*      */   }
/*      */   
/*      */   boolean isUndecorated() {
/*  911 */     return ((this.style & 0xCF0) == 0) || ((this.style & 0x4008) != 0);
/*      */   }
/*      */   
/*      */ 
/*      */   boolean isCustomResize()
/*      */   {
/*  917 */     return ((this.style & 0x8) == 0) && ((this.style & 0x4010) == 16400);
/*      */   }
/*      */   
/*      */   public boolean isVisible()
/*      */   {
/*  922 */     checkWidget();
/*  923 */     return getVisible();
/*      */   }
/*      */   
/*      */   void register()
/*      */   {
/*  928 */     super.register();
/*  929 */     this.display.addWidget(this.shellHandle, this);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   void releaseParent() {}
/*      */   
/*      */ 
/*      */   public void requestLayout()
/*      */   {
/*  939 */     layout(null, 4);
/*      */   }
/*      */   
/*      */   long topHandle()
/*      */   {
/*  944 */     return this.shellHandle;
/*      */   }
/*      */   
/*      */   void fixActiveShell() {
/*  948 */     if (this.display.activeShell == this) {
/*  949 */       Shell shell = null;
/*  950 */       if ((this.parent != null) && (this.parent.isVisible())) shell = this.parent.getShell();
/*  951 */       if ((shell == null) && (isUndecorated())) {
/*  952 */         Shell[] shells = this.display.getShells();
/*  953 */         for (int i = 0; i < shells.length; i++) {
/*  954 */           if ((shells[i] != null) && (shells[i].isVisible())) {
/*  955 */             shell = shells[i];
/*  956 */             break;
/*      */           }
/*      */         }
/*      */       }
/*  960 */       if (shell != null) shell.bringToTop(false);
/*      */     }
/*      */   }
/*      */   
/*      */   void fixShell(Shell newShell, Control control) {
/*  965 */     if (this == newShell) return;
/*  966 */     if (control == this.lastActive) setActiveControl(null);
/*  967 */     String toolTipText = control.toolTipText;
/*  968 */     if (toolTipText != null) {
/*  969 */       control.setToolTipText(this, null);
/*  970 */       control.setToolTipText(newShell, toolTipText);
/*      */     }
/*      */   }
/*      */   
/*      */   long fixedSizeAllocateProc(long widget, long allocationPtr)
/*      */   {
/*  976 */     int clientWidth = 0;
/*  977 */     if ((this.style & 0x8000000) != 0) clientWidth = getClientWidth();
/*  978 */     long result = super.fixedSizeAllocateProc(widget, allocationPtr);
/*  979 */     if ((this.style & 0x8000000) != 0) moveChildren(clientWidth);
/*  980 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */   void fixStyle(long handle) {}
/*      */   
/*      */ 
/*      */   void forceResize()
/*      */   {
/*  989 */     GtkAllocation allocation = new GtkAllocation();
/*  990 */     GTK.gtk_widget_get_allocation(this.vboxHandle, allocation);
/*  991 */     forceResize(allocation.width, allocation.height);
/*      */   }
/*      */   
/*      */   void forceResize(int width, int height) {
/*  995 */     int clientWidth = 0;
/*  996 */     if ((GTK.GTK3) && 
/*  997 */       ((this.style & 0x8000000) != 0)) { clientWidth = getClientWidth();
/*      */     }
/*  999 */     GtkAllocation allocation = new GtkAllocation();
/* 1000 */     int border = GTK.gtk_container_get_border_width(this.shellHandle);
/* 1001 */     allocation.x = border;
/* 1002 */     allocation.y = border;
/* 1003 */     allocation.width = width;
/* 1004 */     allocation.height = height;
/*      */     
/*      */ 
/* 1007 */     if (GTK.GTK_VERSION >= OS.VERSION(3, 20, 0)) {
/* 1008 */       GtkRequisition minimumSize = new GtkRequisition();
/* 1009 */       GtkRequisition naturalSize = new GtkRequisition();
/* 1010 */       GTK.gtk_widget_get_preferred_size(this.vboxHandle, minimumSize, naturalSize);
/*      */     }
/* 1012 */     GTK.gtk_widget_size_allocate(this.vboxHandle, allocation);
/* 1013 */     if ((GTK.GTK3) && 
/* 1014 */       ((this.style & 0x8000000) != 0)) { moveChildren(clientWidth);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getAlpha()
/*      */   {
/* 1032 */     checkWidget();
/* 1033 */     if (GTK.gtk_widget_is_composited(this.shellHandle))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 1038 */       return (int)(GTK.GTK_VERSION > OS.VERSION(3, 8, 0) ? GTK.gtk_widget_get_opacity(this.shellHandle) * 255.0D : GTK.gtk_window_get_opacity(this.shellHandle) * 255.0D);
/*      */     }
/* 1040 */     return 255;
/*      */   }
/*      */   
/*      */   int getResizeMode(double x, double y) {
/* 1044 */     GtkAllocation allocation = new GtkAllocation();
/* 1045 */     GTK.gtk_widget_get_allocation(this.shellHandle, allocation);
/* 1046 */     int width = allocation.width;
/* 1047 */     int height = allocation.height;
/* 1048 */     int border = GTK.gtk_container_get_border_width(this.shellHandle);
/* 1049 */     int mode = 0;
/* 1050 */     if (y >= height - border) {
/* 1051 */       mode = 16;
/* 1052 */       if (x >= width - border - 16) { mode = 14;
/* 1053 */       } else if (x <= border + 16) mode = 12;
/* 1054 */     } else if (x >= width - border) {
/* 1055 */       mode = 96;
/* 1056 */       if (y >= height - border - 16) { mode = 14;
/* 1057 */       } else if (y <= border + 16) mode = 136;
/* 1058 */     } else if (y <= border) {
/* 1059 */       mode = 138;
/* 1060 */       if (x <= border + 16) { mode = 134;
/* 1061 */       } else if (x >= width - border - 16) mode = 136;
/* 1062 */     } else if (x <= border) {
/* 1063 */       mode = 70;
/* 1064 */       if (y <= border + 16) { mode = 134;
/* 1065 */       } else if (y >= height - border - 16) mode = 12;
/*      */     }
/* 1067 */     return mode;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getFullScreen()
/*      */   {
/* 1085 */     checkWidget();
/* 1086 */     return this.fullScreen;
/*      */   }
/*      */   
/*      */   Point getLocationInPixels()
/*      */   {
/* 1091 */     checkWidget();
/* 1092 */     int[] x = new int[1];int[] y = new int[1];
/* 1093 */     GTK.gtk_window_get_position(this.shellHandle, x, y);
/* 1094 */     return new Point(x[0], y[0]);
/*      */   }
/*      */   
/*      */   public boolean getMaximized()
/*      */   {
/* 1099 */     checkWidget();
/* 1100 */     return (!this.fullScreen) && (super.getMaximized());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Point getMinimumSize()
/*      */   {
/* 1119 */     checkWidget();
/* 1120 */     return DPIUtil.autoScaleDown(getMinimumSizeInPixels());
/*      */   }
/*      */   
/*      */   Point getMinimumSizeInPixels() {
/* 1124 */     checkWidget();
/* 1125 */     int width = Math.max(1, this.minWidth + trimWidth());
/* 1126 */     int height = Math.max(1, this.minHeight + trimHeight());
/* 1127 */     return new Point(width, height);
/*      */   }
/*      */   
/*      */   Shell getModalShell() {
/* 1131 */     Shell shell = null;
/* 1132 */     Shell[] modalShells = this.display.modalShells;
/* 1133 */     if (modalShells != null) {
/* 1134 */       int bits = 196608;
/* 1135 */       int index = modalShells.length;
/* 1136 */       for (;;) { index--; if (index < 0) break;
/* 1137 */         Shell modal = modalShells[index];
/* 1138 */         if (modal != null) {
/* 1139 */           if ((modal.style & bits) != 0) {
/* 1140 */             Control control = this;
/* 1141 */             while ((control != null) && 
/* 1142 */               (control != modal)) {
/* 1143 */               control = control.parent;
/*      */             }
/* 1145 */             if (control == modal) break; return modal;
/*      */           }
/*      */           
/* 1148 */           if ((modal.style & 0x8000) != 0) {
/* 1149 */             if (shell == null) shell = getShell();
/* 1150 */             if (modal.parent == shell) return modal;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/* 1155 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getModified()
/*      */   {
/* 1171 */     checkWidget();
/* 1172 */     return this.modified;
/*      */   }
/*      */   
/*      */   Point getSizeInPixels()
/*      */   {
/* 1177 */     checkWidget();
/* 1178 */     GtkAllocation allocation = new GtkAllocation();
/* 1179 */     GTK.gtk_widget_get_allocation(this.vboxHandle, allocation);
/* 1180 */     int width = allocation.width;
/* 1181 */     int height = allocation.height;
/* 1182 */     int border = 0;
/* 1183 */     if ((this.style & 0xCF8) == 0) {
/* 1184 */       border = GTK.gtk_container_get_border_width(this.shellHandle);
/*      */     }
/* 1186 */     return new Point(width + trimWidth() + 2 * border, height + trimHeight() + 2 * border);
/*      */   }
/*      */   
/*      */   public boolean getVisible()
/*      */   {
/* 1191 */     checkWidget();
/* 1192 */     return GTK.gtk_widget_get_visible(this.shellHandle);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Region getRegion()
/*      */   {
/* 1212 */     checkWidget();
/* 1213 */     if (this.originalRegion != null) return this.originalRegion;
/* 1214 */     return this.region;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getImeInputMode()
/*      */   {
/* 1235 */     checkWidget();
/* 1236 */     return 0;
/*      */   }
/*      */   
/*      */   Shell _getShell()
/*      */   {
/* 1241 */     return this;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Shell[] getShells()
/*      */   {
/* 1255 */     checkWidget();
/* 1256 */     int count = 0;
/* 1257 */     Shell[] shells = this.display.getShells();
/* 1258 */     for (int i = 0; i < shells.length; i++) {
/* 1259 */       Control shell = shells[i];
/*      */       do {
/* 1261 */         shell = shell.getParent();
/* 1262 */       } while ((shell != null) && (shell != this));
/* 1263 */       if (shell == this) count++;
/*      */     }
/* 1265 */     int index = 0;
/* 1266 */     Shell[] result = new Shell[count];
/* 1267 */     for (int i = 0; i < shells.length; i++) {
/* 1268 */       Control shell = shells[i];
/*      */       do {
/* 1270 */         shell = shell.getParent();
/* 1271 */       } while ((shell != null) && (shell != this));
/* 1272 */       if (shell == this) {
/* 1273 */         result[(index++)] = shells[i];
/*      */       }
/*      */     }
/* 1276 */     return result;
/*      */   }
/*      */   
/*      */   long gtk_button_press_event(long widget, long event)
/*      */   {
/* 1281 */     if (widget == this.shellHandle) {
/* 1282 */       if (isCustomResize()) {
/* 1283 */         if ((OS.isX11()) && ((this.style & 0x4000) != 0) && ((this.style & 0x80000) == 0)) {
/* 1284 */           forceActive();
/*      */         }
/* 1286 */         GdkEventButton gdkEvent = new GdkEventButton();
/* 1287 */         OS.memmove(gdkEvent, event, GdkEventButton.sizeof);
/* 1288 */         if (gdkEvent.button == 1) {
/* 1289 */           this.display.resizeLocationX = gdkEvent.x_root;
/* 1290 */           this.display.resizeLocationY = gdkEvent.y_root;
/* 1291 */           int[] x = new int[1];int[] y = new int[1];
/* 1292 */           GTK.gtk_window_get_position(this.shellHandle, x, y);
/* 1293 */           this.display.resizeBoundsX = x[0];
/* 1294 */           this.display.resizeBoundsY = y[0];
/* 1295 */           GtkAllocation allocation = new GtkAllocation();
/* 1296 */           GTK.gtk_widget_get_allocation(this.shellHandle, allocation);
/* 1297 */           this.display.resizeBoundsWidth = allocation.width;
/* 1298 */           this.display.resizeBoundsHeight = allocation.height;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1305 */       if ((!OS.isX11()) && (GTK.GTK_VERSION >= OS.VERSION(3, 20, 0)) && 
/* 1306 */         ((this.style & 0x4000) != 0) && ((this.style & 0x80000) == 0)) {
/* 1307 */         GTK.gtk_grab_remove(this.shellHandle);
/* 1308 */         GDK.gdk_seat_ungrab(GDK.gdk_event_get_seat(event));
/* 1309 */         GTK.gtk_widget_hide(this.shellHandle);
/*      */       }
/*      */       
/* 1312 */       return 0L;
/*      */     }
/* 1314 */     return super.gtk_button_press_event(widget, event);
/*      */   }
/*      */   
/*      */   long gtk_configure_event(long widget, long event)
/*      */   {
/* 1319 */     int[] x = new int[1];int[] y = new int[1];
/* 1320 */     GTK.gtk_window_get_position(this.shellHandle, x, y);
/*      */     
/* 1322 */     if (!isVisible()) {
/* 1323 */       return 0L;
/*      */     }
/*      */     
/* 1326 */     if ((!this.moved) || (this.oldX != x[0]) || (this.oldY != y[0])) {
/* 1327 */       this.moved = true;
/* 1328 */       this.oldX = x[0];
/* 1329 */       this.oldY = y[0];
/* 1330 */       sendEvent(10);
/*      */     }
/*      */     
/* 1333 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_delete_event(long widget, long event)
/*      */   {
/* 1338 */     if (isEnabled()) closeWidget();
/* 1339 */     return 1L;
/*      */   }
/*      */   
/*      */   long gtk_enter_notify_event(long widget, long event)
/*      */   {
/* 1344 */     if (widget != this.shellHandle) {
/* 1345 */       return super.gtk_enter_notify_event(widget, event);
/*      */     }
/* 1347 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_draw(long widget, long cairo)
/*      */   {
/* 1352 */     if (widget == this.shellHandle) {
/* 1353 */       if (isCustomResize()) {
/* 1354 */         int[] width = new int[1];
/* 1355 */         int[] height = new int[1];
/* 1356 */         long window = gtk_widget_get_window(widget);
/* 1357 */         gdk_window_get_size(window, width, height);
/* 1358 */         int border = GTK.gtk_container_get_border_width(widget);
/* 1359 */         long context = GTK.gtk_widget_get_style_context(this.shellHandle);
/*      */         
/* 1361 */         GTK.gtk_style_context_save(context);
/* 1362 */         GTK.gtk_render_frame(context, cairo, 0.0D, 0.0D, width[0], border);
/* 1363 */         GTK.gtk_render_frame(context, cairo, 0.0D, height[0] - border, width[0], border);
/* 1364 */         GTK.gtk_render_frame(context, cairo, 0.0D, border, border, height[0] - border - border);
/* 1365 */         GTK.gtk_render_frame(context, cairo, width[0] - border, border, border, height[0] - border - border);
/* 1366 */         GTK.gtk_render_frame(context, cairo, 10.0D, 10.0D, width[0] - 20, height[0] - 20);
/* 1367 */         GTK.gtk_style_context_restore(context);
/* 1368 */         return 1L;
/*      */       }
/* 1370 */       return 0L;
/*      */     }
/* 1372 */     return super.gtk_draw(widget, cairo);
/*      */   }
/*      */   
/*      */   long gtk_expose_event(long widget, long event)
/*      */   {
/* 1377 */     if (widget == this.shellHandle) {
/* 1378 */       if (isCustomResize()) {
/* 1379 */         GdkEventExpose gdkEventExpose = new GdkEventExpose();
/* 1380 */         OS.memmove(gdkEventExpose, event, GdkEventExpose.sizeof);
/* 1381 */         long style = GTK.gtk_widget_get_style(widget);
/* 1382 */         long window = gtk_widget_get_window(widget);
/* 1383 */         int[] width = new int[1];
/* 1384 */         int[] height = new int[1];
/* 1385 */         gdk_window_get_size(window, width, height);
/* 1386 */         GdkRectangle area = new GdkRectangle();
/* 1387 */         area.x = gdkEventExpose.area_x;
/* 1388 */         area.y = gdkEventExpose.area_y;
/* 1389 */         area.width = gdkEventExpose.area_width;
/* 1390 */         area.height = gdkEventExpose.area_height;
/* 1391 */         byte[] detail = Converter.wcsToMbcs("base", true);
/* 1392 */         int border = GTK.gtk_container_get_border_width(widget);
/* 1393 */         int state = this.display.activeShell == this ? 3 : 2;
/* 1394 */         GTK.gtk_paint_flat_box(style, window, state, 0, area, widget, detail, 0, 0, width[0], border);
/* 1395 */         GTK.gtk_paint_flat_box(style, window, state, 0, area, widget, detail, 0, height[0] - border, width[0], border);
/* 1396 */         GTK.gtk_paint_flat_box(style, window, state, 0, area, widget, detail, 0, border, border, height[0] - border - border);
/* 1397 */         GTK.gtk_paint_flat_box(style, window, state, 0, area, widget, detail, width[0] - border, border, border, height[0] - border - border);
/* 1398 */         GTK.gtk_paint_box(style, window, state, 2, area, widget, detail, 0, 0, width[0], height[0]);
/* 1399 */         return 1L;
/*      */       }
/* 1401 */       return 0L;
/*      */     }
/* 1403 */     return super.gtk_expose_event(widget, event);
/*      */   }
/*      */   
/*      */   long gtk_focus(long widget, long directionType)
/*      */   {
/* 1408 */     switch ((int)directionType) {
/*      */     case 0: 
/*      */     case 1: 
/* 1411 */       Control control = this.display.getFocusControl();
/* 1412 */       if ((control != null) && 
/* 1413 */         ((control.state & 0x2) != 0) && ((control.style & 0x1000000) != 0) && (control.getShell() == this)) {
/* 1414 */         int traversal = directionType == 0L ? 16 : 8;
/* 1415 */         control.traverse(traversal);
/* 1416 */         return 1L;
/*      */       }
/*      */       break;
/*      */     }
/*      */     
/* 1421 */     return super.gtk_focus(widget, directionType);
/*      */   }
/*      */   
/*      */   long gtk_focus_in_event(long widget, long event)
/*      */   {
/* 1426 */     if (widget != this.shellHandle) {
/* 1427 */       return super.gtk_focus_in_event(widget, event);
/*      */     }
/* 1429 */     this.display.activeShell = this;
/* 1430 */     this.display.activePending = false;
/* 1431 */     sendEvent(26);
/* 1432 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_focus_out_event(long widget, long event)
/*      */   {
/* 1437 */     if (widget != this.shellHandle) {
/* 1438 */       return super.gtk_focus_out_event(widget, event);
/*      */     }
/* 1440 */     Display display = this.display;
/* 1441 */     sendEvent(27);
/* 1442 */     setActiveControl(null);
/* 1443 */     if ((display.activeShell == this) && (!this.ignoreFocusOut)) {
/* 1444 */       display.activeShell = null;
/* 1445 */       display.activePending = false;
/*      */     }
/* 1447 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_leave_notify_event(long widget, long event)
/*      */   {
/* 1452 */     if (widget == this.shellHandle) {
/* 1453 */       if (isCustomResize()) {
/* 1454 */         GdkEventCrossing gdkEvent = new GdkEventCrossing();
/* 1455 */         OS.memmove(gdkEvent, event, GdkEventCrossing.sizeof);
/* 1456 */         if ((gdkEvent.state & 0x100) == 0) {
/* 1457 */           long window = gtk_widget_get_window(this.shellHandle);
/* 1458 */           GDK.gdk_window_set_cursor(window, 0L);
/* 1459 */           this.display.resizeMode = 0;
/*      */         }
/*      */       }
/* 1462 */       return 0L;
/*      */     }
/* 1464 */     return super.gtk_leave_notify_event(widget, event);
/*      */   }
/*      */   
/*      */   long gtk_move_focus(long widget, long directionType)
/*      */   {
/* 1469 */     Control control = this.display.getFocusControl();
/* 1470 */     if (control != null) {
/* 1471 */       long focusHandle = control.focusHandle();
/* 1472 */       GTK.gtk_widget_child_focus(focusHandle, (int)directionType);
/*      */     }
/* 1474 */     OS.g_signal_stop_emission_by_name(this.shellHandle, OS.move_focus);
/* 1475 */     return 1L;
/*      */   }
/*      */   
/*      */   long gtk_motion_notify_event(long widget, long event)
/*      */   {
/* 1480 */     if (widget == this.shellHandle) {
/* 1481 */       if (isCustomResize()) {
/* 1482 */         GdkEventMotion gdkEvent = new GdkEventMotion();
/* 1483 */         OS.memmove(gdkEvent, event, GdkEventMotion.sizeof);
/* 1484 */         if ((gdkEvent.state & 0x100) != 0) {
/* 1485 */           int border = GTK.gtk_container_get_border_width(this.shellHandle);
/* 1486 */           int dx = (int)(gdkEvent.x_root - this.display.resizeLocationX);
/* 1487 */           int dy = (int)(gdkEvent.y_root - this.display.resizeLocationY);
/* 1488 */           int x = this.display.resizeBoundsX;
/* 1489 */           int y = this.display.resizeBoundsY;
/* 1490 */           int width = this.display.resizeBoundsWidth;
/* 1491 */           int height = this.display.resizeBoundsHeight;
/* 1492 */           int newWidth = Math.max(width - dx, Math.max(this.minWidth, border + border));
/* 1493 */           int newHeight = Math.max(height - dy, Math.max(this.minHeight, border + border));
/* 1494 */           switch (this.display.resizeMode) {
/*      */           case 70: 
/* 1496 */             x += width - newWidth;
/* 1497 */             width = newWidth;
/* 1498 */             break;
/*      */           case 134: 
/* 1500 */             x += width - newWidth;
/* 1501 */             width = newWidth;
/* 1502 */             y += height - newHeight;
/* 1503 */             height = newHeight;
/* 1504 */             break;
/*      */           case 138: 
/* 1506 */             y += height - newHeight;
/* 1507 */             height = newHeight;
/* 1508 */             break;
/*      */           case 136: 
/* 1510 */             width = Math.max(width + dx, Math.max(this.minWidth, border + border));
/* 1511 */             y += height - newHeight;
/* 1512 */             height = newHeight;
/* 1513 */             break;
/*      */           case 96: 
/* 1515 */             width = Math.max(width + dx, Math.max(this.minWidth, border + border));
/* 1516 */             break;
/*      */           case 14: 
/* 1518 */             width = Math.max(width + dx, Math.max(this.minWidth, border + border));
/* 1519 */             height = Math.max(height + dy, Math.max(this.minHeight, border + border));
/* 1520 */             break;
/*      */           case 16: 
/* 1522 */             height = Math.max(height + dy, Math.max(this.minHeight, border + border));
/* 1523 */             break;
/*      */           case 12: 
/* 1525 */             x += width - newWidth;
/* 1526 */             width = newWidth;
/* 1527 */             height = Math.max(height + dy, Math.max(this.minHeight, border + border));
/*      */           }
/*      */           
/* 1530 */           if ((x != this.display.resizeBoundsX) || (y != this.display.resizeBoundsY)) {
/* 1531 */             GDK.gdk_window_move_resize(gtk_widget_get_window(this.shellHandle), x, y, width, height);
/*      */           } else {
/* 1533 */             GTK.gtk_window_resize(this.shellHandle, width, height);
/*      */           }
/*      */         } else {
/* 1536 */           int mode = getResizeMode(gdkEvent.x, gdkEvent.y);
/* 1537 */           if (mode != this.display.resizeMode) {
/* 1538 */             long window = gtk_widget_get_window(this.shellHandle);
/* 1539 */             long cursor = GDK.gdk_cursor_new_for_display(GDK.gdk_display_get_default(), mode);
/* 1540 */             GDK.gdk_window_set_cursor(window, cursor);
/* 1541 */             gdk_cursor_unref(cursor);
/* 1542 */             this.display.resizeMode = mode;
/*      */           }
/*      */         }
/*      */       }
/* 1546 */       return 0L;
/*      */     }
/* 1548 */     return super.gtk_motion_notify_event(widget, event);
/*      */   }
/*      */   
/*      */   long gtk_key_press_event(long widget, long event)
/*      */   {
/* 1553 */     if (widget == this.shellHandle)
/*      */     {
/* 1555 */       if ((this.state & 0x10) != 0) { return 1L;
/*      */       }
/* 1557 */       if ((this.menuBar != null) && (!this.menuBar.isDisposed())) {
/* 1558 */         Control focusControl = this.display.getFocusControl();
/* 1559 */         if ((focusControl != null) && ((focusControl.hooks(1)) || (focusControl.filters(1)))) {
/* 1560 */           long[] accel = new long[1];
/* 1561 */           long setting = GTK.gtk_settings_get_default();
/* 1562 */           OS.g_object_get(setting, GTK.gtk_menu_bar_accel, accel, 0L);
/* 1563 */           if (accel[0] != 0L) {
/* 1564 */             int[] keyval = new int[1];
/* 1565 */             int[] mods = new int[1];
/* 1566 */             GTK.gtk_accelerator_parse(accel[0], keyval, mods);
/* 1567 */             OS.g_free(accel[0]);
/* 1568 */             if (keyval[0] != 0) {
/* 1569 */               GdkEventKey keyEvent = new GdkEventKey();
/* 1570 */               OS.memmove(keyEvent, event, GdkEventKey.sizeof);
/* 1571 */               int mask = GTK.gtk_accelerator_get_default_mod_mask();
/* 1572 */               if ((keyEvent.keyval == keyval[0]) && ((keyEvent.state & mask) == (mods[0] & mask))) {
/* 1573 */                 return focusControl.gtk_key_press_event(focusControl.focusHandle(), event);
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/* 1579 */       return 0L;
/*      */     }
/* 1581 */     return super.gtk_key_press_event(widget, event);
/*      */   }
/*      */   
/*      */   long gtk_size_allocate(long widget, long allocation) { int height;
/*      */     int width;
/*      */     int height;
/* 1587 */     if (GTK.GTK_VERSION >= OS.VERSION(3, 6, 0)) {
/* 1588 */       int[] widthA = new int[1];
/* 1589 */       int[] heightA = new int[1];
/* 1590 */       GTK.gtk_window_get_size(this.shellHandle, widthA, heightA);
/* 1591 */       int width = widthA[0];
/* 1592 */       height = heightA[0];
/*      */     } else {
/* 1594 */       GtkAllocation widgetAllocation = new GtkAllocation();
/* 1595 */       GTK.gtk_widget_get_allocation(this.shellHandle, widgetAllocation);
/* 1596 */       width = widgetAllocation.width;
/* 1597 */       height = widgetAllocation.height;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1603 */     if (((!this.resized) || (this.oldWidth != width) || (this.oldHeight != height)) && ((!GTK.GTK3) || 
/* 1604 */       (OS.isX11()) || ((this.style & 0x10) != 0))) {
/* 1605 */       this.oldWidth = width;
/* 1606 */       this.oldHeight = height;
/* 1607 */       resizeBounds(width, height, true);
/*      */     }
/* 1609 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_realize(long widget)
/*      */   {
/* 1614 */     long result = super.gtk_realize(widget);
/* 1615 */     long window = gtk_widget_get_window(this.shellHandle);
/* 1616 */     if ((this.style & 0x4F0) != 1264) {
/* 1617 */       int decorations = 0;
/* 1618 */       int functions = 0;
/* 1619 */       if ((this.style & 0x8) == 0) {
/* 1620 */         if ((this.style & 0x80) != 0) {
/* 1621 */           decorations |= 0x20;
/* 1622 */           functions |= 0x8;
/*      */         }
/* 1624 */         if ((this.style & 0x400) != 0) {
/* 1625 */           decorations |= 0x40;
/* 1626 */           functions |= 0x10;
/*      */         }
/* 1628 */         if ((this.style & 0x10) != 0) {
/* 1629 */           decorations |= 0x4;
/* 1630 */           functions |= 0x2;
/*      */         }
/* 1632 */         if ((this.style & 0x800) != 0) decorations |= 0x2;
/* 1633 */         if ((this.style & 0x40) != 0) decorations |= 0x10;
/* 1634 */         if ((this.style & 0x20) != 0) decorations |= 0x8;
/* 1635 */         if ((this.style & 0x40) != 0) { functions |= 0x20;
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1642 */         if ((this.style & 0x10) != 0) decorations |= 0x2;
/* 1643 */         if ((this.style & 0x800000) == 0) functions |= 0x4;
/*      */       }
/* 1645 */       GDK.gdk_window_set_decorations(window, decorations);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1653 */       GDK.gdk_window_set_functions(window, functions);
/* 1654 */     } else if ((this.style & 0x800000) != 0)
/*      */     {
/*      */ 
/* 1657 */       GDK.gdk_window_set_functions(window, 5);
/*      */     }
/* 1659 */     if ((this.style & 0x4000) != 0) {
/* 1660 */       GDK.gdk_window_set_override_redirect(window, true);
/*      */     }
/* 1662 */     return result;
/*      */   }
/*      */   
/*      */   long gtk_window_state_event(long widget, long event)
/*      */   {
/* 1667 */     GdkEventWindowState gdkEvent = new GdkEventWindowState();
/* 1668 */     OS.memmove(gdkEvent, event, GdkEventWindowState.sizeof);
/* 1669 */     this.minimized = ((gdkEvent.new_window_state & 0x2) != 0);
/* 1670 */     this.maximized = ((gdkEvent.new_window_state & 0x4) != 0);
/* 1671 */     this.fullScreen = ((gdkEvent.new_window_state & 0x10) != 0);
/* 1672 */     if ((gdkEvent.changed_mask & 0x2) != 0) {
/* 1673 */       if (this.minimized) {
/* 1674 */         sendEvent(19);
/*      */       } else {
/* 1676 */         sendEvent(20);
/*      */       }
/* 1678 */       updateMinimized(this.minimized);
/*      */     }
/* 1680 */     return 0L;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void open()
/*      */   {
/* 1705 */     checkWidget();
/* 1706 */     bringToTop(false);
/* 1707 */     if ((Shell.class.isInstance(getParent())) && (!getParent().isVisible())) {
/* 1708 */       ((Shell)Shell.class.cast(getParent())).open();
/*      */     }
/* 1710 */     setVisible(true);
/* 1711 */     if (isDisposed()) { return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1717 */     boolean restored = restoreFocus();
/* 1718 */     if (!restored) {
/* 1719 */       restored = traverseGroup(true);
/*      */     }
/* 1721 */     if (restored) {
/* 1722 */       Control focusControl = this.display.getFocusControl();
/* 1723 */       if (((focusControl instanceof Button)) && ((focusControl.style & 0x8) != 0)) {
/* 1724 */         restored = false;
/*      */       }
/*      */     }
/* 1727 */     if (!restored) {
/* 1728 */       if ((this.defaultButton != null) && (!this.defaultButton.isDisposed())) {
/* 1729 */         this.defaultButton.setFocus();
/*      */       } else {
/* 1731 */         setFocus();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean print(GC gc)
/*      */   {
/* 1738 */     checkWidget();
/* 1739 */     if (gc == null) error(4);
/* 1740 */     if (gc.isDisposed()) error(5);
/* 1741 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeShellListener(ShellListener listener)
/*      */   {
/* 1762 */     checkWidget();
/* 1763 */     if (listener == null) error(4);
/* 1764 */     if (this.eventTable == null) return;
/* 1765 */     this.eventTable.unhook(21, listener);
/* 1766 */     this.eventTable.unhook(19, listener);
/* 1767 */     this.eventTable.unhook(20, listener);
/* 1768 */     this.eventTable.unhook(26, listener);
/* 1769 */     this.eventTable.unhook(27, listener);
/*      */   }
/*      */   
/*      */   void removeTooTip(ToolTip toolTip) {
/* 1773 */     if (this.toolTips == null) return;
/* 1774 */     for (int i = 0; i < this.toolTips.length; i++) {
/* 1775 */       if (this.toolTips[i] == toolTip) {
/* 1776 */         this.toolTips[i] = null;
/* 1777 */         return;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   void reskinChildren(int flags)
/*      */   {
/* 1784 */     Shell[] shells = getShells();
/* 1785 */     for (int i = 0; i < shells.length; i++) {
/* 1786 */       Shell shell = shells[i];
/* 1787 */       if (shell != null) shell.reskin(flags);
/*      */     }
/* 1789 */     if (this.toolTips != null) {
/* 1790 */       for (int i = 0; i < this.toolTips.length; i++) {
/* 1791 */         ToolTip toolTip = this.toolTips[i];
/* 1792 */         if (toolTip != null) toolTip.reskin(flags);
/*      */       }
/*      */     }
/* 1795 */     super.reskinChildren(flags);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setActive()
/*      */   {
/* 1820 */     checkWidget();
/* 1821 */     bringToTop(false);
/*      */   }
/*      */   
/*      */   void setActiveControl(Control control) {
/* 1825 */     setActiveControl(control, 0);
/*      */   }
/*      */   
/*      */   void setActiveControl(Control control, int type) {
/* 1829 */     if ((control != null) && (control.isDisposed())) control = null;
/* 1830 */     if ((this.lastActive != null) && (this.lastActive.isDisposed())) this.lastActive = null;
/* 1831 */     if (this.lastActive == control) { return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1838 */     Control[] activate = control == null ? new Control[0] : control.getPath();
/* 1839 */     Control[] deactivate = this.lastActive == null ? new Control[0] : this.lastActive.getPath();
/* 1840 */     this.lastActive = control;
/* 1841 */     int index = 0;int length = Math.min(activate.length, deactivate.length);
/* 1842 */     while ((index < length) && 
/* 1843 */       (activate[index] == deactivate[index])) {
/* 1844 */       index++;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1853 */     for (int i = deactivate.length - 1; i >= index; i--) {
/* 1854 */       if (!deactivate[i].isDisposed()) {
/* 1855 */         deactivate[i].sendEvent(27);
/*      */       }
/*      */     }
/* 1858 */     for (int i = activate.length - 1; i >= index; i--) {
/* 1859 */       if (!activate[i].isDisposed()) {
/* 1860 */         Event event = new Event();
/* 1861 */         event.detail = type;
/* 1862 */         activate[i].sendEvent(26, event);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAlpha(int alpha)
/*      */   {
/* 1885 */     checkWidget();
/* 1886 */     if (GTK.gtk_widget_is_composited(this.shellHandle))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 1891 */       if (GTK.GTK_VERSION > OS.VERSION(3, 8, 0)) {
/* 1892 */         GTK.gtk_widget_set_opacity(this.shellHandle, alpha / 255.0D);
/*      */       } else {
/* 1894 */         alpha &= 0xFF;
/* 1895 */         GTK.gtk_window_set_opacity(this.shellHandle, alpha / 255.0F);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   void resizeBounds(int width, int height, boolean notify) {
/* 1901 */     if (this.redrawWindow != 0L) {
/* 1902 */       GDK.gdk_window_resize(this.redrawWindow, width, height);
/*      */     }
/* 1904 */     if (this.enableWindow != 0L) {
/* 1905 */       GDK.gdk_window_resize(this.enableWindow, width, height);
/*      */     }
/* 1907 */     int border = GTK.gtk_container_get_border_width(this.shellHandle);
/* 1908 */     int boxWidth = width - 2 * border;
/* 1909 */     int boxHeight = height - 2 * border;
/* 1910 */     if ((!GTK.GTK3) || ((this.style & 0x10) == 0)) {
/* 1911 */       GTK.gtk_widget_set_size_request(this.vboxHandle, boxWidth, boxHeight);
/*      */     }
/* 1913 */     forceResize(boxWidth, boxHeight);
/* 1914 */     if (notify) {
/* 1915 */       this.resized = true;
/* 1916 */       sendEvent(11);
/* 1917 */       if (isDisposed()) return;
/* 1918 */       if (this.layout != null) {
/* 1919 */         markLayout(false, false);
/* 1920 */         updateLayout(false);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   int setBounds(int x, int y, int width, int height, boolean move, boolean resize)
/*      */   {
/* 1928 */     width = Math.min(width, 32767);
/* 1929 */     height = Math.min(height, 32767);
/*      */     
/* 1931 */     if (this.fullScreen) { setFullScreen(false);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1939 */     if (getMaximized()) {
/* 1940 */       Rectangle rect = getBoundsInPixels();
/* 1941 */       boolean sameOrigin = (!move) || ((rect.x == x) && (rect.y == y));
/* 1942 */       boolean sameExtent = (!resize) || ((rect.width == width) && (rect.height == height));
/* 1943 */       if ((sameOrigin) && (sameExtent)) return 0;
/* 1944 */       setMaximized(false);
/*      */     }
/* 1946 */     int result = 0;
/* 1947 */     if (move) {
/* 1948 */       int[] x_pos = new int[1];int[] y_pos = new int[1];
/* 1949 */       GTK.gtk_window_get_position(this.shellHandle, x_pos, y_pos);
/* 1950 */       GTK.gtk_window_move(this.shellHandle, x, y);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1959 */       for (int i = 0; i < 1000; i++) {
/* 1960 */         int[] x2_pos = new int[1];int[] y2_pos = new int[1];
/* 1961 */         GTK.gtk_window_get_position(this.shellHandle, x2_pos, y2_pos);
/* 1962 */         if ((x2_pos[0] == x) && (y2_pos[0] == y)) {
/*      */           break;
/*      */         }
/*      */       }
/* 1966 */       if ((x_pos[0] != x) || (y_pos[0] != y)) {
/* 1967 */         this.moved = true;
/* 1968 */         this.oldX = x;
/* 1969 */         this.oldY = y;
/* 1970 */         sendEvent(10);
/* 1971 */         if (isDisposed()) return 0;
/* 1972 */         result |= 0x80;
/*      */       }
/*      */     }
/* 1975 */     if (resize) {
/* 1976 */       width = Math.max(1, Math.max(this.minWidth, width - trimWidth()));
/* 1977 */       height = Math.max(1, Math.max(this.minHeight, height - trimHeight()));
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1982 */       if (((this.style & 0x10) != 0) || (this.minHeight != 0) || (this.minWidth != 0)) GTK.gtk_window_resize(this.shellHandle, width, height);
/* 1983 */       boolean changed = (width != this.oldWidth) || (height != this.oldHeight);
/* 1984 */       if (changed) {
/* 1985 */         this.oldWidth = width;
/* 1986 */         this.oldHeight = height;
/* 1987 */         result |= 0x100;
/*      */       }
/* 1989 */       resizeBounds(width, height, changed);
/*      */     }
/* 1991 */     return result;
/*      */   }
/*      */   
/*      */   void setCursor(long cursor)
/*      */   {
/* 1996 */     if (this.enableWindow != 0L) {
/* 1997 */       GDK.gdk_window_set_cursor(this.enableWindow, cursor);
/* 1998 */       GDK.gdk_flush();
/*      */     }
/* 2000 */     super.setCursor(cursor);
/*      */   }
/*      */   
/*      */   public void setEnabled(boolean enabled)
/*      */   {
/* 2005 */     checkWidget();
/* 2006 */     if (((this.state & 0x10) == 0) == enabled) return;
/* 2007 */     Display display = this.display;
/* 2008 */     Control control = null;
/* 2009 */     boolean fixFocus = false;
/* 2010 */     if ((!enabled) && 
/* 2011 */       (display.focusEvent != 16)) {
/* 2012 */       control = display.getFocusControl();
/* 2013 */       fixFocus = isFocusAncestor(control);
/*      */     }
/*      */     
/* 2016 */     if (enabled) {
/* 2017 */       this.state &= 0xFFFFFFEF;
/*      */     } else {
/* 2019 */       this.state |= 0x10;
/*      */     }
/* 2021 */     enableWidget(enabled);
/* 2022 */     if (isDisposed()) return;
/* 2023 */     if (enabled) {
/* 2024 */       if (this.enableWindow != 0L) {
/* 2025 */         cleanupEnableWindow();
/*      */       }
/*      */     } else {
/* 2028 */       long parentHandle = this.shellHandle;
/* 2029 */       GTK.gtk_widget_realize(parentHandle);
/* 2030 */       long window = gtk_widget_get_window(parentHandle);
/* 2031 */       Rectangle rect = getBoundsInPixels();
/* 2032 */       GdkWindowAttr attributes = new GdkWindowAttr();
/* 2033 */       attributes.width = rect.width;
/* 2034 */       attributes.height = rect.height;
/* 2035 */       attributes.event_mask = -32769;
/* 2036 */       attributes.wclass = 1;
/* 2037 */       attributes.window_type = 2;
/* 2038 */       this.enableWindow = GDK.gdk_window_new(window, attributes, 0);
/* 2039 */       if (this.enableWindow != 0L) {
/* 2040 */         if (this.cursor != null) {
/* 2041 */           GDK.gdk_window_set_cursor(this.enableWindow, this.cursor.handle);
/* 2042 */           GDK.gdk_flush();
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 2048 */         if (enterNotifyEventFunc != null) {
/* 2049 */           this.enterNotifyEventId = OS.g_signal_add_emission_hook(enterNotifyEventSignalId, 0, enterNotifyEventFunc.getAddress(), this.enableWindow, 0L);
/*      */         }
/* 2051 */         GDK.gdk_window_set_user_data(this.enableWindow, parentHandle);
/* 2052 */         GDK.gdk_window_show(this.enableWindow);
/*      */       }
/*      */     }
/* 2055 */     if (fixFocus) fixFocus(control);
/* 2056 */     if ((enabled) && (display.activeShell == this) && 
/* 2057 */       (!restoreFocus())) { traverseGroup(false);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setFullScreen(boolean fullScreen)
/*      */   {
/* 2085 */     checkWidget();
/* 2086 */     if (fullScreen) {
/* 2087 */       GTK.gtk_window_fullscreen(this.shellHandle);
/*      */     } else {
/* 2089 */       GTK.gtk_window_unfullscreen(this.shellHandle);
/* 2090 */       if (this.maximized) {
/* 2091 */         setMaximized(true);
/*      */       }
/*      */     }
/* 2094 */     this.fullScreen = fullScreen;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2114 */   public void setImeInputMode(int mode) { checkWidget(); }
/*      */   
/*      */   void setInitialBounds() {
/*      */     int height;
/*      */     int width;
/*      */     int height;
/* 2120 */     if ((this.state & 0x400000) != 0) {
/* 2121 */       GtkAllocation allocation = new GtkAllocation();
/* 2122 */       GTK.gtk_widget_get_allocation(this.shellHandle, allocation);
/* 2123 */       int width = allocation.width;
/* 2124 */       height = allocation.height;
/*      */     } else {
/* 2126 */       width = GDK.gdk_screen_width() * 5 / 8;
/* 2127 */       height = GDK.gdk_screen_height() * 5 / 8;
/* 2128 */       long screen = GDK.gdk_screen_get_default();
/* 2129 */       if ((screen != 0L) && 
/* 2130 */         (GDK.gdk_screen_get_n_monitors(screen) > 1)) {
/* 2131 */         int monitorNumber = GDK.gdk_screen_get_monitor_at_window(screen, paintWindow());
/* 2132 */         GdkRectangle dest = new GdkRectangle();
/* 2133 */         GDK.gdk_screen_get_monitor_geometry(screen, monitorNumber, dest);
/* 2134 */         width = dest.width * 5 / 8;
/* 2135 */         height = dest.height * 5 / 8;
/*      */       }
/*      */       
/* 2138 */       if ((this.style & 0x10) != 0) {
/* 2139 */         GTK.gtk_window_resize(this.shellHandle, width, height);
/*      */       }
/*      */     }
/* 2142 */     resizeBounds(width, height, false);
/*      */   }
/*      */   
/*      */   public void setMaximized(boolean maximized)
/*      */   {
/* 2147 */     checkWidget();
/* 2148 */     super.setMaximized(maximized);
/* 2149 */     if (maximized) {
/* 2150 */       GTK.gtk_window_maximize(this.shellHandle);
/*      */     } else {
/* 2152 */       GTK.gtk_window_unmaximize(this.shellHandle);
/*      */     }
/*      */   }
/*      */   
/*      */   public void setMenuBar(Menu menu)
/*      */   {
/* 2158 */     checkWidget();
/* 2159 */     if (this.menuBar == menu) return;
/* 2160 */     boolean both = (menu != null) && (this.menuBar != null);
/* 2161 */     if (menu != null) {
/* 2162 */       if ((menu.style & 0x2) == 0) error(33);
/* 2163 */       if (menu.parent != this) error(32);
/*      */     }
/* 2165 */     if (this.menuBar != null) {
/* 2166 */       long menuHandle = this.menuBar.handle;
/* 2167 */       GTK.gtk_widget_hide(menuHandle);
/* 2168 */       destroyAccelGroup();
/*      */     }
/* 2170 */     this.menuBar = menu;
/* 2171 */     if (this.menuBar != null) {
/* 2172 */       long menuHandle = menu.handle;
/* 2173 */       GTK.gtk_widget_show(menuHandle);
/* 2174 */       createAccelGroup();
/* 2175 */       this.menuBar.addAccelerators(this.accelGroup);
/*      */     }
/* 2177 */     GtkAllocation allocation = new GtkAllocation();
/* 2178 */     GTK.gtk_widget_get_allocation(this.vboxHandle, allocation);
/* 2179 */     int width = allocation.width;
/* 2180 */     int height = allocation.height;
/* 2181 */     resizeBounds(width, height, !both);
/*      */   }
/*      */   
/*      */   public void setMinimized(boolean minimized)
/*      */   {
/* 2186 */     checkWidget();
/* 2187 */     if (this.minimized == minimized) return;
/* 2188 */     super.setMinimized(minimized);
/* 2189 */     if ((GTK.GTK_VERSION >= OS.VERSION(3, 8, 0)) && (!GTK.gtk_widget_get_visible(this.shellHandle))) {
/* 2190 */       GTK.gtk_widget_show(this.shellHandle);
/*      */     }
/* 2192 */     if (minimized) {
/* 2193 */       GTK.gtk_window_iconify(this.shellHandle);
/*      */     } else {
/* 2195 */       GTK.gtk_window_deiconify(this.shellHandle);
/* 2196 */       bringToTop(false);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setMinimumSize(int width, int height)
/*      */   {
/* 2216 */     checkWidget();
/* 2217 */     setMinimumSize(new Point(width, height));
/*      */   }
/*      */   
/*      */   void setMinimumSizeInPixels(int width, int height) {
/* 2221 */     checkWidget();
/* 2222 */     GdkGeometry geometry = new GdkGeometry();
/* 2223 */     this.minWidth = (geometry.min_width = Math.max(width, trimWidth()) - trimWidth());
/* 2224 */     this.minHeight = (geometry.min_height = Math.max(height, trimHeight()) - trimHeight());
/* 2225 */     GTK.gtk_window_set_geometry_hints(this.shellHandle, 0L, geometry, 2);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setMinimumSize(Point size)
/*      */   {
/* 2246 */     checkWidget();
/* 2247 */     setMinimumSizeInPixels(DPIUtil.autoScaleUp(size));
/*      */   }
/*      */   
/*      */   void setMinimumSizeInPixels(Point size) {
/* 2251 */     checkWidget();
/* 2252 */     if (size == null) error(4);
/* 2253 */     setMinimumSizeInPixels(size.x, size.y);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setModified(boolean modified)
/*      */   {
/* 2270 */     checkWidget();
/* 2271 */     this.modified = modified;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRegion(Region region)
/*      */   {
/* 2300 */     checkWidget();
/* 2301 */     if ((this.style & 0x8) == 0) { return;
/*      */     }
/* 2303 */     if (region != null) {
/* 2304 */       Rectangle bounds = region.getBounds();
/* 2305 */       setSize(bounds.x + bounds.width, bounds.y + bounds.height);
/*      */     }
/* 2307 */     Region regionToDispose = null;
/* 2308 */     if ((this.style & 0x4000000) != 0) {
/* 2309 */       if (this.originalRegion != null) regionToDispose = this.region;
/* 2310 */       this.originalRegion = region;
/* 2311 */       region = mirrorRegion(region);
/*      */     } else {
/* 2313 */       this.originalRegion = null;
/*      */     }
/* 2315 */     super.setRegion(region);
/* 2316 */     if (regionToDispose != null) regionToDispose.dispose();
/*      */   }
/*      */   
/*      */   static void gdk_region_get_rectangles(long region, long[] rectangles, int[] n_rectangles)
/*      */   {
/* 2321 */     if (!GTK.GTK3) {
/* 2322 */       GDK.gdk_region_get_rectangles(region, rectangles, n_rectangles);
/* 2323 */       return;
/*      */     }
/* 2325 */     int num = Cairo.cairo_region_num_rectangles(region);
/* 2326 */     if (n_rectangles != null) n_rectangles[0] = num;
/* 2327 */     rectangles[0] = OS.g_malloc(GdkRectangle.sizeof * num);
/* 2328 */     for (int n = 0; n < num; n++) {
/* 2329 */       Cairo.cairo_region_get_rectangle(region, n, rectangles[0] + n * GdkRectangle.sizeof);
/*      */     }
/*      */   }
/*      */   
/*      */   static Region mirrorRegion(Region region) {
/* 2334 */     if (region == null) { return null;
/*      */     }
/* 2336 */     Region mirrored = new Region(region.getDevice());
/*      */     
/* 2338 */     long rgn = region.handle;
/* 2339 */     int[] nRects = new int[1];
/* 2340 */     long[] rects = new long[1];
/* 2341 */     gdk_region_get_rectangles(rgn, rects, nRects);
/* 2342 */     Rectangle bounds = DPIUtil.autoScaleUp(region.getBounds());
/* 2343 */     GdkRectangle rect = new GdkRectangle();
/* 2344 */     for (int i = 0; i < nRects[0]; i++) {
/* 2345 */       OS.memmove(rect, rects[0] + i * GdkRectangle.sizeof, GdkRectangle.sizeof);
/* 2346 */       rect.x = (bounds.x + bounds.width - rect.x - rect.width);
/* 2347 */       GDK.gdk_region_union_with_rect(mirrored.handle, rect);
/*      */     }
/* 2349 */     if (rects[0] != 0L) OS.g_free(rects[0]);
/* 2350 */     return mirrored;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   void setRelations() {}
/*      */   
/*      */ 
/*      */ 
/*      */   public void setText(String string)
/*      */   {
/* 2362 */     super.setText(string);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2371 */     int length = string.length();
/* 2372 */     char[] chars = new char[Math.max(6, length) + 1];
/* 2373 */     string.getChars(0, length, chars, 0);
/* 2374 */     for (int i = length; i < chars.length; i++) chars[i] = ' ';
/* 2375 */     byte[] buffer = Converter.wcsToMbcs(chars, true);
/* 2376 */     GTK.gtk_window_set_title(this.shellHandle, buffer);
/*      */   }
/*      */   
/*      */   public void setVisible(boolean visible)
/*      */   {
/* 2381 */     checkWidget();
/*      */     
/* 2383 */     if (this.moved) {
/* 2384 */       setLocationInPixels(this.oldX, this.oldY);
/*      */     }
/* 2386 */     int mask = 229376;
/* 2387 */     if ((this.style & mask) != 0) {
/* 2388 */       if (visible) {
/* 2389 */         this.display.setModalShell(this);
/* 2390 */         GTK.gtk_window_set_modal(this.shellHandle, true);
/*      */       } else {
/* 2392 */         this.display.clearModal(this);
/* 2393 */         GTK.gtk_window_set_modal(this.shellHandle, false);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2400 */       if ((this.parent != null) && (this.parent.getShell().getFullScreen())) {
/* 2401 */         GTK.gtk_window_set_type_hint(this.shellHandle, 1);
/*      */       }
/*      */     } else {
/* 2404 */       updateModal();
/*      */     }
/* 2406 */     this.showWithParent = visible;
/* 2407 */     if (GTK.gtk_widget_get_mapped(this.shellHandle) == visible) return;
/* 2408 */     if (visible) {
/* 2409 */       if ((this.center) && (!this.moved)) {
/* 2410 */         center();
/* 2411 */         if (isDisposed()) return;
/*      */       }
/* 2413 */       sendEvent(22);
/* 2414 */       if (isDisposed()) { return;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2427 */       this.mapped = false;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 2432 */       GTK.gtk_widget_show(this.shellHandle);
/* 2433 */       if (this.enableWindow != 0L) GDK.gdk_window_raise(this.enableWindow);
/* 2434 */       if (isDisposed()) return;
/* 2435 */       if ((!OS.isX11()) || (!GTK.GTK_IS_PLUG(this.shellHandle))) {
/* 2436 */         this.display.dispatchEvents = new int[] { 2, 12, 13, 14, 15, 30, 32 };
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2445 */         Display display = this.display;
/* 2446 */         display.putGdkEvents();
/* 2447 */         boolean iconic = false;
/* 2448 */         Shell shell = this.parent != null ? this.parent.getShell() : null;
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         do
/*      */         {
/* 2456 */           GDK.gdk_threads_leave();
/* 2457 */           OS.g_main_context_iteration(0L, false);
/* 2458 */           if (isDisposed()) break;
/* 2459 */           iconic = (this.minimized) || ((shell != null) && (shell.minimized));
/* 2460 */         } while ((!this.mapped) && (!iconic));
/* 2461 */         display.dispatchEvents = null;
/* 2462 */         if (isDisposed()) return;
/* 2463 */         if (!iconic) {
/* 2464 */           update(true, true);
/* 2465 */           if (isDisposed()) return;
/* 2466 */           adjustTrim();
/*      */         }
/*      */       }
/* 2469 */       this.mapped = true;
/*      */       
/* 2471 */       if ((this.style & mask) != 0) {
/* 2472 */         gdk_pointer_ungrab(GTK.gtk_widget_get_window(this.shellHandle), 0);
/*      */       }
/* 2474 */       this.opened = true;
/* 2475 */       if (!this.moved) {
/* 2476 */         this.moved = true;
/* 2477 */         Point location = getLocationInPixels();
/* 2478 */         this.oldX = location.x;
/* 2479 */         this.oldY = location.y;
/* 2480 */         sendEvent(10);
/* 2481 */         if (isDisposed()) return;
/*      */       }
/* 2483 */       if (!this.resized) {
/* 2484 */         this.resized = true;
/* 2485 */         Point size = getSizeInPixels();
/* 2486 */         this.oldWidth = (size.x - trimWidth());
/* 2487 */         this.oldHeight = (size.y - trimHeight());
/* 2488 */         sendEvent(11);
/* 2489 */         if (isDisposed()) return;
/* 2490 */         if (this.layout != null) {
/* 2491 */           markLayout(false, false);
/* 2492 */           updateLayout(false);
/*      */         }
/*      */       }
/*      */     } else {
/* 2496 */       fixActiveShell();
/*      */       
/*      */ 
/* 2499 */       if ((!OS.isX11()) && (GTK.GTK_VERSION >= OS.VERSION(3, 20, 0)) && 
/* 2500 */         ((this.style & 0x4000) != 0) && ((this.style & 0x80000) == 0)) {
/* 2501 */         GTK.gtk_grab_remove(this.shellHandle);
/* 2502 */         GDK.gdk_seat_ungrab(GDK.gdk_display_get_default_seat(
/* 2503 */           GDK.gdk_window_get_display(GTK.gtk_widget_get_window(this.shellHandle))));
/*      */       }
/*      */       
/* 2506 */       GTK.gtk_widget_hide(this.shellHandle);
/* 2507 */       sendEvent(23);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void setZOrder(Control sibling, boolean above, boolean fixRelations)
/*      */   {
/* 2521 */     if (this.mapped) setZOrder(sibling, above, false, false);
/*      */   }
/*      */   
/*      */   long shellMapProc(long handle, long arg0, long user_data)
/*      */   {
/* 2526 */     this.mapped = true;
/* 2527 */     this.display.dispatchEvents = null;
/* 2528 */     return 0L;
/*      */   }
/*      */   
/*      */   void showWidget()
/*      */   {
/* 2533 */     if ((this.state & 0x400000) != 0)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2539 */       if (GTK.gtk_window_is_active(this.shellHandle)) {
/* 2540 */         this.display.activeShell = this;
/* 2541 */         this.display.activePending = true;
/*      */       }
/* 2543 */       long children = GTK.gtk_container_get_children(this.shellHandle);long list = children;
/* 2544 */       while (list != 0L) {
/* 2545 */         GTK.gtk_container_remove(this.shellHandle, OS.g_list_data(list));
/* 2546 */         list = OS.g_list_next(list);
/*      */       }
/* 2548 */       OS.g_list_free(list);
/*      */     }
/* 2550 */     GTK.gtk_container_add(this.shellHandle, this.vboxHandle);
/* 2551 */     if (this.scrolledHandle != 0L) GTK.gtk_widget_show(this.scrolledHandle);
/* 2552 */     if (this.handle != 0L) GTK.gtk_widget_show(this.handle);
/* 2553 */     if (this.vboxHandle != 0L) GTK.gtk_widget_show(this.vboxHandle);
/*      */   }
/*      */   
/*      */   long sizeAllocateProc(long handle, long arg0, long user_data)
/*      */   {
/* 2558 */     int offset = 16;
/* 2559 */     int[] x = new int[1];int[] y = new int[1];
/* 2560 */     gdk_window_get_device_position(0L, x, y, null);
/* 2561 */     y[0] += offset;
/* 2562 */     long screen = GDK.gdk_screen_get_default();
/* 2563 */     if (screen != 0L) {
/* 2564 */       int monitorNumber = GDK.gdk_screen_get_monitor_at_point(screen, x[0], y[0]);
/* 2565 */       GdkRectangle dest = new GdkRectangle();
/* 2566 */       GDK.gdk_screen_get_monitor_geometry(screen, monitorNumber, dest);
/* 2567 */       GtkAllocation allocation = new GtkAllocation();
/* 2568 */       GTK.gtk_widget_get_allocation(handle, allocation);
/* 2569 */       int width = allocation.width;
/* 2570 */       int height = allocation.height;
/* 2571 */       if (x[0] + width > dest.x + dest.width) {
/* 2572 */         x[0] = (dest.x + dest.width - width);
/*      */       }
/* 2574 */       if (y[0] + height > dest.y + dest.height) {
/* 2575 */         y[0] = (dest.y + dest.height - height);
/*      */       }
/*      */     }
/* 2578 */     GTK.gtk_window_move(handle, x[0], y[0]);
/* 2579 */     return 0L;
/*      */   }
/*      */   
/*      */   long sizeRequestProc(long handle, long arg0, long user_data)
/*      */   {
/* 2584 */     GTK.gtk_widget_hide(handle);
/* 2585 */     return 0L;
/*      */   }
/*      */   
/*      */   boolean traverseEscape()
/*      */   {
/* 2590 */     if (this.parent == null) return false;
/* 2591 */     if ((!isVisible()) || (!isEnabled())) return false;
/* 2592 */     close();
/* 2593 */     return true;
/*      */   }
/*      */   
/* 2596 */   int trimHeight() { if ((this.style & 0x8) != 0) return 0;
/* 2597 */     if (this.fullScreen) return 0;
/* 2598 */     boolean hasTitle = false;boolean hasResize = false;boolean hasBorder = false;
/* 2599 */     hasTitle = (this.style & 0x4E0) != 0;
/* 2600 */     hasResize = (this.style & 0x10) != 0;
/* 2601 */     hasBorder = (this.style & 0x800) != 0;
/* 2602 */     if (hasTitle) {
/* 2603 */       if (hasResize) return this.display.trimHeights[4];
/* 2604 */       if (hasBorder) return this.display.trimHeights[3];
/* 2605 */       return this.display.trimHeights[5];
/*      */     }
/* 2607 */     if (hasResize) return this.display.trimHeights[2];
/* 2608 */     if (hasBorder) return this.display.trimHeights[1];
/* 2609 */     return this.display.trimHeights[0];
/*      */   }
/*      */   
/*      */   int trimWidth() {
/* 2613 */     if ((this.style & 0x8) != 0) return 0;
/* 2614 */     if (this.fullScreen) return 0;
/* 2615 */     boolean hasTitle = false;boolean hasResize = false;boolean hasBorder = false;
/* 2616 */     hasTitle = (this.style & 0x4E0) != 0;
/* 2617 */     hasResize = (this.style & 0x10) != 0;
/* 2618 */     hasBorder = (this.style & 0x800) != 0;
/* 2619 */     if (hasTitle) {
/* 2620 */       if (hasResize) return this.display.trimWidths[4];
/* 2621 */       if (hasBorder) return this.display.trimWidths[3];
/* 2622 */       return this.display.trimWidths[5];
/*      */     }
/* 2624 */     if (hasResize) return this.display.trimWidths[2];
/* 2625 */     if (hasBorder) return this.display.trimWidths[1];
/* 2626 */     return this.display.trimWidths[0];
/*      */   }
/*      */   
/*      */   void updateModal() {
/* 2630 */     if ((OS.isX11()) && (GTK.GTK_IS_PLUG(this.shellHandle))) return;
/* 2631 */     long group = 0L;
/* 2632 */     boolean isModalShell = false;
/* 2633 */     if (this.display.getModalDialog() == null) {
/* 2634 */       Shell modal = getModalShell();
/* 2635 */       int mask = 229376;
/* 2636 */       Composite shell = null;
/* 2637 */       if (modal == null) {
/* 2638 */         if ((this.style & mask) != 0) {
/* 2639 */           shell = this;
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2648 */           isModalShell = GTK.gtk_window_get_modal(this.shellHandle);
/* 2649 */           if (isModalShell) GTK.gtk_window_set_modal(this.shellHandle, false);
/*      */         }
/*      */       } else {
/* 2652 */         shell = modal;
/*      */       }
/* 2654 */       Composite topModalShell = shell;
/* 2655 */       while (shell != null) {
/* 2656 */         if ((shell.style & mask) == 0) {
/* 2657 */           group = shell.getShell().group;
/* 2658 */           break;
/*      */         }
/* 2660 */         topModalShell = shell;
/* 2661 */         shell = shell.parent;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2671 */       if ((group == 0L) && (topModalShell != null)) group = topModalShell.getShell().group;
/*      */     }
/* 2673 */     if (group == 0L)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2680 */       group = GTK.gtk_window_get_group(0L);
/*      */     }
/* 2682 */     if (group != 0L) {
/* 2683 */       GTK.gtk_window_group_add_window(group, this.shellHandle);
/* 2684 */       if (isModalShell) GTK.gtk_window_set_modal(this.shellHandle, true);
/*      */     }
/* 2686 */     else if (this.modalGroup != 0L) {
/* 2687 */       GTK.gtk_window_group_remove_window(this.modalGroup, this.shellHandle);
/*      */     }
/*      */     
/* 2690 */     this.modalGroup = group;
/*      */   }
/*      */   
/*      */   void updateMinimized(boolean minimized) {
/* 2694 */     Shell[] shells = getShells();
/* 2695 */     for (int i = 0; i < shells.length; i++) {
/* 2696 */       boolean update = false;
/* 2697 */       Shell shell = shells[i];
/* 2698 */       while ((shell != null) && (shell != this) && (!shell.isUndecorated())) {
/* 2699 */         shell = (Shell)shell.getParent();
/*      */       }
/* 2701 */       if ((shell != null) && (shell != this)) update = true;
/* 2702 */       if (update) {
/* 2703 */         if (minimized) {
/* 2704 */           if (shells[i].isVisible()) {
/* 2705 */             shells[i].showWithParent = true;
/* 2706 */             GTK.gtk_widget_hide(shells[i].shellHandle);
/*      */           }
/*      */         }
/* 2709 */         else if (shells[i].showWithParent) {
/* 2710 */           shells[i].showWithParent = false;
/* 2711 */           GTK.gtk_widget_show(shells[i].shellHandle);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   void deregister()
/*      */   {
/* 2720 */     super.deregister();
/* 2721 */     this.display.removeWidget(this.shellHandle);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void dispose()
/*      */   {
/* 2730 */     if (isDisposed()) return;
/* 2731 */     fixActiveShell();
/* 2732 */     if ((!OS.isX11()) && (GTK.GTK_VERSION >= OS.VERSION(3, 20, 0)) && 
/* 2733 */       ((this.style & 0x4000) != 0) && ((this.style & 0x80000) == 0)) {
/* 2734 */       GTK.gtk_grab_remove(this.shellHandle);
/* 2735 */       GDK.gdk_seat_ungrab(GDK.gdk_display_get_default_seat(
/* 2736 */         GDK.gdk_window_get_display(GTK.gtk_widget_get_window(this.shellHandle))));
/*      */     }
/*      */     
/* 2739 */     GTK.gtk_widget_hide(this.shellHandle);
/* 2740 */     super.dispose();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void forceActive()
/*      */   {
/* 2765 */     checkWidget();
/* 2766 */     bringToTop(true);
/*      */   }
/*      */   
/*      */   Rectangle getBoundsInPixels()
/*      */   {
/* 2771 */     checkWidget();
/* 2772 */     int[] x = new int[1];int[] y = new int[1];
/* 2773 */     if ((this.state & 0x200000) == 0) {
/* 2774 */       GTK.gtk_window_get_position(this.shellHandle, x, y);
/*      */     } else {
/* 2776 */       GDK.gdk_window_get_root_origin(GTK.gtk_widget_get_window(this.shellHandle), x, y);
/*      */     }
/* 2778 */     GtkAllocation allocation = new GtkAllocation();
/* 2779 */     GTK.gtk_widget_get_allocation(this.vboxHandle, allocation);
/* 2780 */     int width = allocation.width;
/* 2781 */     int height = allocation.height;
/* 2782 */     int border = 0;
/* 2783 */     if ((this.style & 0xCF8) == 0) {
/* 2784 */       border = GTK.gtk_container_get_border_width(this.shellHandle);
/*      */     }
/* 2786 */     return new Rectangle(x[0], y[0], width + trimWidth() + 2 * border, height + trimHeight() + 2 * border);
/*      */   }
/*      */   
/*      */   void releaseHandle()
/*      */   {
/* 2791 */     super.releaseHandle();
/* 2792 */     this.shellHandle = 0L;
/*      */   }
/*      */   
/*      */   void releaseChildren(boolean destroy)
/*      */   {
/* 2797 */     Shell[] shells = getShells();
/* 2798 */     for (int i = 0; i < shells.length; i++) {
/* 2799 */       Shell shell = shells[i];
/* 2800 */       if ((shell != null) && (!shell.isDisposed())) {
/* 2801 */         shell.release(false);
/*      */       }
/*      */     }
/* 2804 */     if (this.toolTips != null) {
/* 2805 */       for (int i = 0; i < this.toolTips.length; i++) {
/* 2806 */         ToolTip toolTip = this.toolTips[i];
/* 2807 */         if ((toolTip != null) && (!toolTip.isDisposed())) {
/* 2808 */           toolTip.dispose();
/*      */         }
/*      */       }
/* 2811 */       this.toolTips = null;
/*      */     }
/* 2813 */     super.releaseChildren(destroy);
/*      */   }
/*      */   
/*      */   void releaseWidget()
/*      */   {
/* 2818 */     Region regionToDispose = null;
/* 2819 */     if (this.originalRegion != null) regionToDispose = this.region;
/* 2820 */     super.releaseWidget();
/* 2821 */     destroyAccelGroup();
/* 2822 */     this.display.clearModal(this);
/* 2823 */     if (this.display.activeShell == this) this.display.activeShell = null;
/* 2824 */     if (this.tooltipsHandle != 0L) OS.g_object_unref(this.tooltipsHandle);
/* 2825 */     this.tooltipsHandle = 0L;
/* 2826 */     if (this.group != 0L) OS.g_object_unref(this.group);
/* 2827 */     this.group = (this.modalGroup = 0L);
/* 2828 */     if (!GTK.GTK3) {
/* 2829 */       long window = gtk_widget_get_window(this.shellHandle);
/* 2830 */       GDK.gdk_window_remove_filter(window, this.display.filterProc, this.shellHandle);
/*      */     }
/* 2832 */     this.lastActive = null;
/* 2833 */     if (regionToDispose != null) {
/* 2834 */       regionToDispose.dispose();
/*      */     }
/*      */   }
/*      */   
/*      */   void setToolTipText(long tipWidget, String string) {
/* 2839 */     setToolTipText(tipWidget, tipWidget, string);
/*      */   }
/*      */   
/*      */   void setToolTipText(long rootWidget, long tipWidget, String string) {
/* 2843 */     byte[] buffer = null;
/* 2844 */     if ((string != null) && (string.length() > 0)) {
/* 2845 */       char[] chars = fixMnemonic(string, false);
/* 2846 */       buffer = Converter.wcsToMbcs(chars, true);
/*      */     }
/* 2848 */     long oldTooltip = GTK.gtk_widget_get_tooltip_text(rootWidget);
/* 2849 */     boolean same = false;
/* 2850 */     if ((buffer == null) && (oldTooltip == 0L)) {
/* 2851 */       same = true;
/* 2852 */     } else if ((buffer != null) && (oldTooltip != 0L)) {
/* 2853 */       same = OS.strcmp(oldTooltip, buffer) == 0;
/*      */     }
/* 2855 */     if (oldTooltip != 0L) OS.g_free(oldTooltip);
/* 2856 */     if (same) { return;
/*      */     }
/* 2858 */     GTK.gtk_widget_set_tooltip_text(rootWidget, buffer);
/*      */   }
/*      */   
/*      */   Point getWindowOrigin() {
/* 2862 */     if (!this.mapped)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2871 */       return getLocationInPixels();
/*      */     }
/* 2873 */     return super.getWindowOrigin();
/*      */   }
/*      */   
/*      */   static long GdkSeatGrabPrepareFunc(long gdkSeat, long gdkWindow, long userData_shellHandle) {
/* 2877 */     if (userData_shellHandle != 0L) {
/* 2878 */       GTK.gtk_widget_show(userData_shellHandle);
/*      */     }
/* 2880 */     return 0L;
/*      */   }
/*      */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/widgets/Shell.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */