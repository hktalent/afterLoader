/*    */ package org.eclipse.swt.internal.image;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PngInputStream
/*    */   extends InputStream
/*    */ {
/*    */   PngChunkReader reader;
/*    */   PngChunk chunk;
/*    */   int offset;
/*    */   int length;
/*    */   static final int DATA_OFFSET = 8;
/*    */   
/*    */   public PngInputStream(PngIdatChunk chunk, PngChunkReader reader)
/*    */   {
/* 23 */     this.chunk = chunk;
/* 24 */     this.reader = reader;
/* 25 */     this.length = chunk.getLength();
/* 26 */     this.offset = 0;
/*    */   }
/*    */   
/*    */   private boolean checkChunk() throws IOException {
/* 30 */     while (this.offset == this.length) {
/* 31 */       this.chunk = this.reader.readNextChunk();
/* 32 */       if (this.chunk == null) throw new IOException();
/* 33 */       if (this.chunk.getChunkType() == 3) return false;
/* 34 */       if (this.chunk.getChunkType() != 2) throw new IOException();
/* 35 */       this.length = this.chunk.getLength();
/* 36 */       this.offset = 0;
/*    */     }
/* 38 */     return true;
/*    */   }
/*    */   
/*    */   public void close() throws IOException
/*    */   {
/* 43 */     this.chunk = null;
/*    */   }
/*    */   
/*    */   public int read() throws IOException
/*    */   {
/* 48 */     if (this.chunk == null) throw new IOException();
/* 49 */     if ((this.offset == this.length) && (!checkChunk())) return -1;
/* 50 */     int b = this.chunk.reference[(8 + this.offset)] & 0xFF;
/* 51 */     this.offset += 1;
/* 52 */     return b;
/*    */   }
/*    */   
/*    */   public int read(byte[] b, int off, int len) throws IOException
/*    */   {
/* 57 */     if (this.chunk == null) throw new IOException();
/* 58 */     if ((this.offset == this.length) && (!checkChunk())) return -1;
/* 59 */     len = Math.min(len, this.length - this.offset);
/* 60 */     System.arraycopy(this.chunk.reference, 8 + this.offset, b, off, len);
/* 61 */     this.offset += len;
/* 62 */     return len;
/*    */   }
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/internal/image/PngInputStream.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */