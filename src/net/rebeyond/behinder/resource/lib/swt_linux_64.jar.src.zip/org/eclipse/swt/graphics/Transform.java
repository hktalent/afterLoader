/*     */ package org.eclipse.swt.graphics;
/*     */ 
/*     */ import org.eclipse.swt.SWT;
/*     */ import org.eclipse.swt.internal.DPIUtil;
/*     */ import org.eclipse.swt.internal.cairo.Cairo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Transform
/*     */   extends Resource
/*     */ {
/*     */   public double[] handle;
/*     */   
/*     */   public Transform(Device device)
/*     */   {
/*  76 */     this(device, 1.0F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Transform(Device device, float[] elements)
/*     */   {
/* 108 */     this(device, checkTransform(elements)[0], elements[1], elements[2], elements[3], elements[4], elements[5]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Transform(Device device, float m11, float m12, float m21, float m22, float dx, float dy)
/*     */   {
/* 144 */     super(device);
/* 145 */     this.handle = new double[6];
/* 146 */     if (this.handle == null) SWT.error(2);
/* 147 */     Cairo.cairo_matrix_init(this.handle, m11, m12, m21, m22, DPIUtil.autoScaleUp(dx), DPIUtil.autoScaleUp(dy));
/* 148 */     init();
/*     */   }
/*     */   
/*     */   static float[] checkTransform(float[] elements) {
/* 152 */     if (elements == null) SWT.error(4);
/* 153 */     if (elements.length < 6) SWT.error(5);
/* 154 */     return elements;
/*     */   }
/*     */   
/*     */   void destroy()
/*     */   {
/* 159 */     this.handle = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void getElements(float[] elements)
/*     */   {
/* 177 */     if (isDisposed()) SWT.error(44);
/* 178 */     if (elements == null) SWT.error(4);
/* 179 */     if (elements.length < 6) SWT.error(5);
/* 180 */     elements[0] = ((float)this.handle[0]);
/* 181 */     elements[1] = ((float)this.handle[1]);
/* 182 */     elements[2] = ((float)this.handle[2]);
/* 183 */     elements[3] = ((float)this.handle[3]);
/* 184 */     elements[4] = DPIUtil.autoScaleDown((float)this.handle[4]);
/* 185 */     elements[5] = DPIUtil.autoScaleDown((float)this.handle[5]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void identity()
/*     */   {
/* 199 */     if (isDisposed()) SWT.error(44);
/* 200 */     Cairo.cairo_matrix_init(this.handle, 1.0D, 0.0D, 0.0D, 1.0D, 0.0D, 0.0D);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void invert()
/*     */   {
/* 213 */     if (isDisposed()) SWT.error(44);
/* 214 */     if (Cairo.cairo_matrix_invert(this.handle) != 0) {
/* 215 */       SWT.error(10);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isDisposed()
/*     */   {
/* 231 */     return this.handle == null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isIdentity()
/*     */   {
/* 241 */     if (isDisposed()) SWT.error(44);
/* 242 */     float[] m = new float[6];
/* 243 */     getElements(m);
/* 244 */     return (m[0] == 1.0F) && (m[1] == 0.0F) && (m[2] == 0.0F) && (m[3] == 1.0F) && (m[4] == 0.0F) && (m[5] == 0.0F);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void multiply(Transform matrix)
/*     */   {
/* 263 */     if (isDisposed()) SWT.error(44);
/* 264 */     if (matrix == null) SWT.error(4);
/* 265 */     if (matrix.isDisposed()) SWT.error(5);
/* 266 */     Cairo.cairo_matrix_multiply(this.handle, matrix.handle, this.handle);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void rotate(float angle)
/*     */   {
/* 283 */     if (isDisposed()) SWT.error(44);
/* 284 */     Cairo.cairo_matrix_rotate(this.handle, angle * 3.1415927F / 180.0F);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void scale(float scaleX, float scaleY)
/*     */   {
/* 299 */     if (isDisposed()) SWT.error(44);
/* 300 */     Cairo.cairo_matrix_scale(this.handle, scaleX, scaleY);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setElements(float m11, float m12, float m21, float m22, float dx, float dy)
/*     */   {
/* 319 */     if (isDisposed()) SWT.error(44);
/* 320 */     Cairo.cairo_matrix_init(this.handle, m11, m12, m21, m22, DPIUtil.autoScaleUp(dx), DPIUtil.autoScaleUp(dy));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void shear(float shearX, float shearY)
/*     */   {
/* 337 */     if (isDisposed()) SWT.error(44);
/* 338 */     double[] matrix = { 1.0D, shearX, shearY, 1.0D, 0.0D, 0.0D };
/* 339 */     Cairo.cairo_matrix_multiply(this.handle, matrix, this.handle);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void transform(float[] pointArray)
/*     */   {
/* 357 */     if (isDisposed()) SWT.error(44);
/* 358 */     if (pointArray == null) SWT.error(4);
/* 359 */     double[] dx = new double[1];double[] dy = new double[1];
/* 360 */     int length = pointArray.length / 2;
/* 361 */     int i = 0; for (int j = 0; i < length; j += 2) {
/* 362 */       dx[0] = DPIUtil.autoScaleUp(pointArray[j]);
/* 363 */       dy[0] = DPIUtil.autoScaleUp(pointArray[(j + 1)]);
/* 364 */       Cairo.cairo_matrix_transform_point(this.handle, dx, dy);
/* 365 */       pointArray[j] = DPIUtil.autoScaleDown((float)dx[0]);
/* 366 */       pointArray[(j + 1)] = DPIUtil.autoScaleDown((float)dy[0]);i++;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void translate(float offsetX, float offsetY)
/*     */   {
/* 382 */     if (isDisposed()) SWT.error(44);
/* 383 */     Cairo.cairo_matrix_translate(this.handle, DPIUtil.autoScaleUp(offsetX), DPIUtil.autoScaleUp(offsetY));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 394 */     if (isDisposed()) return "Transform {*DISPOSED*}";
/* 395 */     float[] elements = new float[6];
/* 396 */     getElements(elements);
/* 397 */     return "Transform {" + elements[0] + "," + elements[1] + "," + elements[2] + "," + elements[3] + "," + elements[4] + "," + elements[5] + "}";
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/graphics/Transform.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */