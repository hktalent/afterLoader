/*      */ package org.eclipse.swt.custom;
/*      */ 
/*      */ import java.util.Set;
/*      */ import java.util.SortedSet;
/*      */ import java.util.TreeSet;
/*      */ import org.eclipse.swt.graphics.Color;
/*      */ import org.eclipse.swt.graphics.Device;
/*      */ import org.eclipse.swt.graphics.Font;
/*      */ import org.eclipse.swt.graphics.FontData;
/*      */ import org.eclipse.swt.graphics.FontMetrics;
/*      */ import org.eclipse.swt.graphics.GC;
/*      */ import org.eclipse.swt.graphics.GlyphMetrics;
/*      */ import org.eclipse.swt.graphics.Point;
/*      */ import org.eclipse.swt.graphics.Rectangle;
/*      */ import org.eclipse.swt.graphics.TextLayout;
/*      */ import org.eclipse.swt.graphics.TextStyle;
/*      */ import org.eclipse.swt.widgets.Display;
/*      */ import org.eclipse.swt.widgets.IME;
/*      */ import org.eclipse.swt.widgets.ScrollBar;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class StyledTextRenderer
/*      */ {
/*      */   Device device;
/*      */   StyledText styledText;
/*      */   StyledTextContent content;
/*      */   StyledTextLineSpacingProvider lineSpacingProvider;
/*      */   boolean lineSpacingComputing;
/*      */   Font regularFont;
/*      */   Font boldFont;
/*      */   Font italicFont;
/*      */   Font boldItalicFont;
/*      */   int tabWidth;
/*      */   int ascent;
/*      */   int descent;
/*      */   int averageCharWidth;
/*      */   int tabLength;
/*   43 */   int topIndex = -1;
/*      */   
/*      */   TextLayout[] layouts;
/*      */   
/*      */   int lineCount;
/*      */   
/*      */   LineSizeInfo[] lineSizes;
/*      */   
/*      */   LineInfo[] lines;
/*      */   int maxWidth;
/*      */   int maxWidthLineIndex;
/*      */   boolean idleRunning;
/*      */   Bullet[] bullets;
/*      */   int[] bulletsIndices;
/*      */   int[] redrawLines;
/*      */   int[] ranges;
/*      */   int styleCount;
/*      */   StyleRange[] styles;
/*      */   StyleRange[] stylesSet;
/*   62 */   int stylesSetCount = 0;
/*      */   
/*      */   boolean hasLinks;
/*      */   
/*      */   boolean fixedPitch;
/*      */   
/*      */   static final int BULLET_MARGIN = 8;
/*      */   static final boolean COMPACT_STYLES = true;
/*      */   static final boolean MERGE_STYLES = true;
/*      */   static final int GROW = 32;
/*      */   static final int IDLE_TIME = 50;
/*      */   static final int CACHE_SIZE = 128;
/*      */   static final int BACKGROUND = 1;
/*      */   static final int ALIGNMENT = 2;
/*      */   static final int INDENT = 4;
/*      */   static final int JUSTIFY = 8;
/*      */   static final int SEGMENTS = 32;
/*      */   static final int TABSTOPS = 64;
/*      */   static final int WRAP_INDENT = 128;
/*      */   static final int SEGMENT_CHARS = 256;
/*      */   
/*      */   static class LineSizeInfo
/*      */   {
/*      */     private static final int RESETED_SIZE = -1;
/*      */     int height;
/*      */     int width;
/*      */     
/*      */     public LineSizeInfo()
/*      */     {
/*   91 */       resetSize();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     void resetSize()
/*      */     {
/*   98 */       this.height = -1;
/*   99 */       this.width = -1;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     boolean canLayout()
/*      */     {
/*  110 */       return !needsRecalculateWidth();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     boolean needsRecalculateSize()
/*      */     {
/*  121 */       return (needsRecalculateWidth()) || (needsRecalculateHeight());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     boolean needsRecalculateWidth()
/*      */     {
/*  132 */       return this.width == -1;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     boolean needsRecalculateHeight()
/*      */     {
/*  143 */       return this.height == -1;
/*      */     }
/*      */   }
/*      */   
/*      */   static class LineInfo {
/*      */     int flags;
/*      */     Color background;
/*      */     int alignment;
/*      */     int indent;
/*      */     int wrapIndent;
/*      */     boolean justify;
/*      */     int[] segments;
/*      */     char[] segmentsChars;
/*      */     int[] tabStops;
/*      */     
/*      */     public LineInfo() {}
/*      */     
/*      */     public LineInfo(LineInfo info) {
/*  161 */       if (info != null) {
/*  162 */         this.flags = info.flags;
/*  163 */         this.background = info.background;
/*  164 */         this.alignment = info.alignment;
/*  165 */         this.indent = info.indent;
/*  166 */         this.wrapIndent = info.wrapIndent;
/*  167 */         this.justify = info.justify;
/*  168 */         this.segments = info.segments;
/*  169 */         this.segmentsChars = info.segmentsChars;
/*  170 */         this.tabStops = info.tabStops;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*  175 */   static int cap(TextLayout layout, int offset) { if (layout == null) return offset;
/*  176 */     return Math.min(layout.getText().length() - 1, Math.max(0, offset));
/*      */   }
/*      */   
/*      */   StyledTextRenderer(Device device, StyledText styledText) {
/*  180 */     this.device = device;
/*  181 */     this.styledText = styledText;
/*      */   }
/*      */   
/*  184 */   int addMerge(int[] mergeRanges, StyleRange[] mergeStyles, int mergeCount, int modifyStart, int modifyEnd) { int rangeCount = this.styleCount << 1;
/*  185 */     StyleRange endStyle = null;
/*  186 */     int endStart = 0;int endLength = 0;
/*  187 */     if (modifyEnd < rangeCount) {
/*  188 */       endStyle = this.styles[(modifyEnd >> 1)];
/*  189 */       endStart = this.ranges[modifyEnd];
/*  190 */       endLength = this.ranges[(modifyEnd + 1)];
/*      */     }
/*  192 */     int grow = mergeCount - (modifyEnd - modifyStart);
/*  193 */     if (rangeCount + grow >= this.ranges.length) {
/*  194 */       int[] tmpRanges = new int[this.ranges.length + grow + 64];
/*  195 */       System.arraycopy(this.ranges, 0, tmpRanges, 0, modifyStart);
/*  196 */       StyleRange[] tmpStyles = new StyleRange[this.styles.length + (grow >> 1) + 32];
/*  197 */       System.arraycopy(this.styles, 0, tmpStyles, 0, modifyStart >> 1);
/*  198 */       if (rangeCount > modifyEnd) {
/*  199 */         System.arraycopy(this.ranges, modifyEnd, tmpRanges, modifyStart + mergeCount, rangeCount - modifyEnd);
/*  200 */         System.arraycopy(this.styles, modifyEnd >> 1, tmpStyles, modifyStart + mergeCount >> 1, this.styleCount - (modifyEnd >> 1));
/*      */       }
/*  202 */       this.ranges = tmpRanges;
/*  203 */       this.styles = tmpStyles;
/*      */     }
/*  205 */     else if (rangeCount > modifyEnd) {
/*  206 */       System.arraycopy(this.ranges, modifyEnd, this.ranges, modifyStart + mergeCount, rangeCount - modifyEnd);
/*  207 */       System.arraycopy(this.styles, modifyEnd >> 1, this.styles, modifyStart + mergeCount >> 1, this.styleCount - (modifyEnd >> 1));
/*      */     }
/*      */     
/*      */ 
/*  211 */     int j = modifyStart;
/*  212 */     for (int i = 0; i < mergeCount; i += 2) {
/*  213 */       if ((j > 0) && (this.ranges[(j - 2)] + this.ranges[(j - 1)] == mergeRanges[i]) && (mergeStyles[(i >> 1)].similarTo(this.styles[(j - 2 >> 1)]))) {
/*  214 */         this.ranges[(j - 1)] += mergeRanges[(i + 1)];
/*      */       } else {
/*  216 */         this.styles[(j >> 1)] = mergeStyles[(i >> 1)];
/*  217 */         this.ranges[(j++)] = mergeRanges[i];
/*  218 */         this.ranges[(j++)] = mergeRanges[(i + 1)];
/*      */       }
/*      */     }
/*  221 */     if ((endStyle != null) && (this.ranges[(j - 2)] + this.ranges[(j - 1)] == endStart) && (endStyle.similarTo(this.styles[(j - 2 >> 1)]))) {
/*  222 */       this.ranges[(j - 1)] += endLength;
/*  223 */       modifyEnd += 2;
/*  224 */       mergeCount += 2;
/*      */     }
/*  226 */     if (rangeCount > modifyEnd) {
/*  227 */       System.arraycopy(this.ranges, modifyStart + mergeCount, this.ranges, j, rangeCount - modifyEnd);
/*  228 */       System.arraycopy(this.styles, modifyStart + mergeCount >> 1, this.styles, j >> 1, this.styleCount - (modifyEnd >> 1));
/*      */     }
/*  230 */     grow = j - modifyStart - (modifyEnd - modifyStart);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  235 */     this.styleCount += (grow >> 1);
/*  236 */     return grow;
/*      */   }
/*      */   
/*  239 */   int addMerge(StyleRange[] mergeStyles, int mergeCount, int modifyStart, int modifyEnd) { int grow = mergeCount - (modifyEnd - modifyStart);
/*  240 */     StyleRange endStyle = null;
/*  241 */     if (modifyEnd < this.styleCount) endStyle = this.styles[modifyEnd];
/*  242 */     if (this.styleCount + grow >= this.styles.length) {
/*  243 */       StyleRange[] tmpStyles = new StyleRange[this.styles.length + grow + 32];
/*  244 */       System.arraycopy(this.styles, 0, tmpStyles, 0, modifyStart);
/*  245 */       if (this.styleCount > modifyEnd) {
/*  246 */         System.arraycopy(this.styles, modifyEnd, tmpStyles, modifyStart + mergeCount, this.styleCount - modifyEnd);
/*      */       }
/*  248 */       this.styles = tmpStyles;
/*      */     }
/*  250 */     else if (this.styleCount > modifyEnd) {
/*  251 */       System.arraycopy(this.styles, modifyEnd, this.styles, modifyStart + mergeCount, this.styleCount - modifyEnd);
/*      */     }
/*      */     
/*      */ 
/*  255 */     int j = modifyStart;
/*  256 */     for (int i = 0; i < mergeCount; i++) {
/*  257 */       StyleRange newStyle = mergeStyles[i];
/*  258 */       StyleRange style; if ((j > 0) && ((style = this.styles[(j - 1)]).start + style.length == newStyle.start) && (newStyle.similarTo(style))) {
/*  259 */         style.length += newStyle.length;
/*      */       } else {
/*  261 */         this.styles[(j++)] = newStyle;
/*      */       }
/*      */     }
/*  264 */     StyleRange style = this.styles[(j - 1)];
/*  265 */     if ((endStyle != null) && (style.start + style.length == endStyle.start) && (endStyle.similarTo(style))) {
/*  266 */       style.length += endStyle.length;
/*  267 */       modifyEnd++;
/*  268 */       mergeCount++;
/*      */     }
/*  270 */     if (this.styleCount > modifyEnd) {
/*  271 */       System.arraycopy(this.styles, modifyStart + mergeCount, this.styles, j, this.styleCount - modifyEnd);
/*      */     }
/*  273 */     grow = j - modifyStart - (modifyEnd - modifyStart);
/*      */     
/*      */ 
/*      */ 
/*  277 */     this.styleCount += grow;
/*  278 */     return grow;
/*      */   }
/*      */   
/*  281 */   void calculate(int startLine, int lineCount) { int endLine = startLine + lineCount;
/*  282 */     if ((startLine < 0) || (endLine > this.lineSizes.length)) {
/*  283 */       return;
/*      */     }
/*  285 */     int hTrim = this.styledText.leftMargin + this.styledText.rightMargin + this.styledText.getCaretWidth();
/*  286 */     for (int i = startLine; i < endLine; i++) {
/*  287 */       LineSizeInfo line = getLineSize(i);
/*  288 */       if (line.needsRecalculateSize()) {
/*  289 */         TextLayout layout = getTextLayout(i);
/*  290 */         Rectangle rect = layout.getBounds();
/*  291 */         line.width = (rect.width + hTrim);
/*  292 */         line.height = rect.height;
/*  293 */         disposeTextLayout(layout);
/*      */       }
/*  295 */       if (line.width > this.maxWidth) {
/*  296 */         this.maxWidth = line.width;
/*  297 */         this.maxWidthLineIndex = i;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*  302 */   LineSizeInfo getLineSize(int i) { if (this.lineSizes[i] == null) {
/*  303 */       this.lineSizes[i] = new LineSizeInfo();
/*      */     }
/*  305 */     return this.lineSizes[i];
/*      */   }
/*      */   
/*  308 */   void calculateClientArea() { int index = Math.max(0, this.styledText.getTopIndex());
/*  309 */     int lineCount = this.content.getLineCount();
/*  310 */     int height = this.styledText.getClientArea().height;
/*  311 */     int y = 0;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  317 */     while ((height > y) && (lineCount > index) && (this.lineSizes.length > index)) {
/*  318 */       calculate(index, 1);
/*  319 */       y += this.lineSizes[(index++)].height;
/*      */     }
/*      */   }
/*      */   
/*  323 */   void calculateIdle() { if (this.idleRunning) return;
/*  324 */     Runnable runnable = new Runnable()
/*      */     {
/*      */       public void run() {
/*  327 */         if (StyledTextRenderer.this.styledText == null) { return;
/*      */         }
/*  329 */         long start = System.currentTimeMillis();
/*  330 */         for (int i = 0; i < StyledTextRenderer.this.lineCount; i++) {
/*  331 */           StyledTextRenderer.LineSizeInfo line = StyledTextRenderer.this.getLineSize(i);
/*  332 */           if (line.needsRecalculateSize()) {
/*  333 */             StyledTextRenderer.this.calculate(i, 1);
/*  334 */             if (System.currentTimeMillis() - start > 50L) break;
/*      */           }
/*      */         }
/*  337 */         if (i < StyledTextRenderer.this.lineCount) {
/*  338 */           Display display = StyledTextRenderer.this.styledText.getDisplay();
/*  339 */           display.asyncExec(this);
/*      */         } else {
/*  341 */           StyledTextRenderer.this.idleRunning = false;
/*  342 */           StyledTextRenderer.this.styledText.setScrollBars(true);
/*  343 */           ScrollBar bar = StyledTextRenderer.this.styledText.getVerticalBar();
/*  344 */           if (bar != null) {
/*  345 */             bar.setSelection(StyledTextRenderer.this.styledText.getVerticalScrollOffset());
/*      */           }
/*      */         }
/*      */       }
/*  349 */     };
/*  350 */     Display display = this.styledText.getDisplay();
/*  351 */     display.asyncExec(runnable);
/*  352 */     this.idleRunning = true;
/*      */   }
/*      */   
/*  355 */   void clearLineBackground(int startLine, int count) { if (this.lines == null) return;
/*  356 */     for (int i = startLine; i < startLine + count; i++) {
/*  357 */       LineInfo info = this.lines[i];
/*  358 */       if (info != null) {
/*  359 */         info.flags &= 0xFFFFFFFE;
/*  360 */         info.background = null;
/*  361 */         if (info.flags == 0) this.lines[i] = null;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*  366 */   void clearLineStyle(int startLine, int count) { if (this.lines == null) return;
/*  367 */     for (int i = startLine; i < startLine + count; i++) {
/*  368 */       LineInfo info = this.lines[i];
/*  369 */       if (info != null) {
/*  370 */         info.flags &= 0xFF31;
/*  371 */         if (info.flags == 0) this.lines[i] = null;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*  376 */   void copyInto(StyledTextRenderer renderer) { if (this.ranges != null) {
/*  377 */       int[] newRanges = renderer.ranges = new int[this.styleCount << 1];
/*  378 */       System.arraycopy(this.ranges, 0, newRanges, 0, newRanges.length);
/*      */     }
/*  380 */     if (this.styles != null) {
/*  381 */       StyleRange[] newStyles = renderer.styles = new StyleRange[this.styleCount];
/*  382 */       for (int i = 0; i < newStyles.length; i++) {
/*  383 */         newStyles[i] = ((StyleRange)this.styles[i].clone());
/*      */       }
/*  385 */       renderer.styleCount = this.styleCount;
/*      */     }
/*  387 */     if (this.lines != null) {
/*  388 */       LineInfo[] newLines = renderer.lines = new LineInfo[this.lineCount];
/*  389 */       for (int i = 0; i < newLines.length; i++) {
/*  390 */         newLines[i] = new LineInfo(this.lines[i]);
/*      */       }
/*  392 */       renderer.lineCount = this.lineCount;
/*      */     }
/*      */   }
/*      */   
/*  396 */   void dispose() { if (this.boldFont != null) this.boldFont.dispose();
/*  397 */     if (this.italicFont != null) this.italicFont.dispose();
/*  398 */     if (this.boldItalicFont != null) this.boldItalicFont.dispose();
/*  399 */     this.boldFont = (this.italicFont = this.boldItalicFont = null);
/*  400 */     reset();
/*  401 */     this.content = null;
/*  402 */     this.device = null;
/*  403 */     this.styledText = null;
/*      */   }
/*      */   
/*  406 */   void disposeTextLayout(TextLayout layout) { if (this.layouts != null) {
/*  407 */       for (int i = 0; i < this.layouts.length; i++) {
/*  408 */         if (this.layouts[i] == layout) return;
/*      */       }
/*      */     }
/*  411 */     layout.dispose();
/*      */   }
/*      */   
/*  414 */   void drawBullet(Bullet bullet, GC gc, int paintX, int paintY, int index, int lineAscent, int lineDescent) { StyleRange style = bullet.style;
/*  415 */     GlyphMetrics metrics = style.metrics;
/*  416 */     Color color = style.foreground;
/*  417 */     if (color != null) gc.setForeground(color);
/*  418 */     Font font = style.font;
/*  419 */     if (font != null) gc.setFont(font);
/*  420 */     String string = "";
/*  421 */     int type = bullet.type & 0xF;
/*  422 */     switch (type) {
/*  423 */     case 1:  string = "•"; break;
/*  424 */     case 2:  string = String.valueOf(index + 1); break;
/*  425 */     case 4:  string = String.valueOf((char)(index % 26 + 97)); break;
/*  426 */     case 8:  string = String.valueOf((char)(index % 26 + 65));
/*      */     }
/*  428 */     if ((bullet.type & 0x10) != 0) string = string + bullet.text;
/*  429 */     Display display = this.styledText.getDisplay();
/*  430 */     TextLayout layout = new TextLayout(display);
/*  431 */     layout.setText(string);
/*  432 */     layout.setAscent(lineAscent);
/*  433 */     layout.setDescent(lineDescent);
/*  434 */     style = (StyleRange)style.clone();
/*  435 */     style.metrics = null;
/*  436 */     if (style.font == null) style.font = getFont(style.fontStyle);
/*  437 */     layout.setStyle(style, 0, string.length());
/*  438 */     int x = paintX + Math.max(0, metrics.width - layout.getBounds().width - 8);
/*  439 */     layout.draw(gc, x, paintY);
/*  440 */     layout.dispose();
/*      */   }
/*      */   
/*  443 */   int drawLine(int lineIndex, int paintX, int paintY, GC gc, Color widgetBackground, Color widgetForeground) { TextLayout layout = getTextLayout(lineIndex);
/*  444 */     String line = this.content.getLine(lineIndex);
/*  445 */     int lineOffset = this.content.getOffsetAtLine(lineIndex);
/*  446 */     int lineLength = line.length();
/*  447 */     Point selection = this.styledText.getSelection();
/*  448 */     int selectionStart = selection.x - lineOffset;
/*  449 */     int selectionEnd = selection.y - lineOffset;
/*  450 */     if (this.styledText.getBlockSelection()) {
/*  451 */       selectionStart = selectionEnd = 0;
/*      */     }
/*  453 */     Rectangle client = this.styledText.getClientArea();
/*  454 */     Color lineBackground = getLineBackground(lineIndex, null);
/*  455 */     StyledTextEvent event = this.styledText.getLineBackgroundData(lineOffset, line);
/*  456 */     if ((event != null) && (event.lineBackground != null)) lineBackground = event.lineBackground;
/*  457 */     int height = layout.getBounds().height;
/*  458 */     if (lineBackground != null) {
/*  459 */       gc.setBackground(lineBackground);
/*  460 */       gc.fillRectangle(client.x, paintY, client.width, height);
/*      */     } else {
/*  462 */       gc.setBackground(widgetBackground);
/*  463 */       this.styledText.drawBackground(gc, client.x, paintY, client.width, height);
/*      */     }
/*  465 */     gc.setForeground(widgetForeground);
/*  466 */     if ((selectionStart == selectionEnd) || ((selectionEnd <= 0) && (selectionStart > lineLength - 1))) {
/*  467 */       layout.draw(gc, paintX, paintY);
/*      */     } else {
/*  469 */       int start = Math.max(0, selectionStart);
/*  470 */       int end = Math.min(lineLength, selectionEnd);
/*  471 */       Color selectionFg = this.styledText.getSelectionForeground();
/*  472 */       Color selectionBg = this.styledText.getSelectionBackground();
/*      */       int flags;
/*  474 */       int flags; if ((this.styledText.getStyle() & 0x10000) != 0) {
/*  475 */         flags = 65536;
/*      */       } else {
/*  477 */         flags = 131072;
/*      */       }
/*  479 */       if ((selectionStart <= lineLength) && (lineLength < selectionEnd)) {
/*  480 */         flags |= 0x100000;
/*      */       }
/*  482 */       layout.draw(gc, paintX, paintY, start, end - 1, selectionFg, selectionBg, flags);
/*      */     }
/*      */     
/*      */ 
/*  486 */     Bullet bullet = null;
/*  487 */     int bulletIndex = -1;
/*  488 */     if (this.bullets != null)
/*  489 */       if (this.bulletsIndices != null) {
/*  490 */         int index = lineIndex - this.topIndex;
/*  491 */         if ((0 <= index) && (index < 128)) {
/*  492 */           bullet = this.bullets[index];
/*  493 */           bulletIndex = this.bulletsIndices[index];
/*      */         }
/*      */       } else {
/*  496 */         for (int i = 0; i < this.bullets.length; i++) {
/*  497 */           bullet = this.bullets[i];
/*  498 */           bulletIndex = bullet.indexOf(lineIndex);
/*  499 */           if (bulletIndex != -1)
/*      */             break;
/*      */         }
/*      */       }
/*  503 */     if ((bulletIndex != -1) && (bullet != null)) {
/*  504 */       FontMetrics metrics = layout.getLineMetrics(0);
/*  505 */       int lineAscent = metrics.getAscent() + metrics.getLeading();
/*  506 */       if (bullet.type == 32) {
/*  507 */         bullet.style.start = lineOffset;
/*  508 */         this.styledText.paintObject(gc, paintX, paintY, lineAscent, metrics.getDescent(), bullet.style, bullet, bulletIndex);
/*      */       } else {
/*  510 */         drawBullet(bullet, gc, paintX, paintY, bulletIndex, lineAscent, metrics.getDescent());
/*      */       }
/*      */     }
/*  513 */     TextStyle[] styles = layout.getStyles();
/*  514 */     int[] ranges = null;
/*  515 */     for (int i = 0; i < styles.length; i++) {
/*  516 */       if (styles[i].metrics != null) {
/*  517 */         if (ranges == null) ranges = layout.getRanges();
/*  518 */         int start = ranges[(i << 1)];
/*  519 */         int length = ranges[((i << 1) + 1)] - start + 1;
/*  520 */         Point point = layout.getLocation(start, false);
/*  521 */         FontMetrics metrics = layout.getLineMetrics(layout.getLineIndex(start));
/*  522 */         StyleRange style = (StyleRange)((StyleRange)styles[i]).clone();
/*  523 */         style.start = (start + lineOffset);
/*  524 */         style.length = length;
/*  525 */         int lineAscent = metrics.getAscent() + metrics.getLeading();
/*  526 */         this.styledText.paintObject(gc, point.x + paintX, point.y + paintY, lineAscent, metrics.getDescent(), style, null, 0);
/*      */       }
/*      */     }
/*  529 */     disposeTextLayout(layout);
/*  530 */     return height;
/*      */   }
/*      */   
/*  533 */   int getBaseline() { return this.ascent; }
/*      */   
/*      */   Font getFont(int style) {
/*  536 */     switch (style) {
/*      */     case 1: 
/*  538 */       if (this.boldFont != null) return this.boldFont;
/*  539 */       return this.boldFont = new Font(this.device, getFontData(style));
/*      */     case 2: 
/*  541 */       if (this.italicFont != null) return this.italicFont;
/*  542 */       return this.italicFont = new Font(this.device, getFontData(style));
/*      */     case 3: 
/*  544 */       if (this.boldItalicFont != null) return this.boldItalicFont;
/*  545 */       return this.boldItalicFont = new Font(this.device, getFontData(style));
/*      */     }
/*  547 */     return this.regularFont;
/*      */   }
/*      */   
/*      */   FontData[] getFontData(int style) {
/*  551 */     FontData[] fontDatas = this.regularFont.getFontData();
/*  552 */     for (int i = 0; i < fontDatas.length; i++) {
/*  553 */       fontDatas[i].setStyle(style);
/*      */     }
/*  555 */     return fontDatas;
/*      */   }
/*      */   
/*  558 */   int getHeight() { int defaultLineHeight = getLineHeight();
/*  559 */     if (this.styledText.isFixedLineHeight()) {
/*  560 */       return this.lineCount * defaultLineHeight + this.styledText.topMargin + this.styledText.bottomMargin;
/*      */     }
/*  562 */     int totalHeight = 0;
/*  563 */     int width = this.styledText.getWrapWidth();
/*  564 */     for (int i = 0; i < this.lineCount; i++) {
/*  565 */       LineSizeInfo line = getLineSize(i);
/*  566 */       int height = line.height;
/*  567 */       if (line.needsRecalculateHeight()) {
/*  568 */         if (width > 0) {
/*  569 */           int length = this.content.getLine(i).length();
/*  570 */           height = (length * this.averageCharWidth / width + 1) * defaultLineHeight;
/*      */         } else {
/*  572 */           height = defaultLineHeight;
/*      */         }
/*      */       }
/*  575 */       totalHeight += height;
/*      */     }
/*  577 */     return totalHeight + this.styledText.topMargin + this.styledText.bottomMargin;
/*      */   }
/*      */   
/*  580 */   boolean hasLink(int offset) { if (offset == -1) return false;
/*  581 */     int lineIndex = this.content.getLineAtOffset(offset);
/*  582 */     int lineOffset = this.content.getOffsetAtLine(lineIndex);
/*  583 */     String line = this.content.getLine(lineIndex);
/*  584 */     StyledTextEvent event = this.styledText.getLineStyleData(lineOffset, line);
/*  585 */     if (event != null) {
/*  586 */       StyleRange[] styles = event.styles;
/*  587 */       if (styles != null) {
/*  588 */         int[] ranges = event.ranges;
/*  589 */         if (ranges != null) {
/*  590 */           for (int i = 0; i < ranges.length; i += 2) {
/*  591 */             if ((ranges[i] <= offset) && (offset < ranges[i] + ranges[(i + 1)]) && (styles[(i >> 1)].underline) && (styles[(i >> 1)].underlineStyle == 4)) {
/*  592 */               return true;
/*      */             }
/*      */           }
/*      */         } else {
/*  596 */           for (int i = 0; i < styles.length; i++) {
/*  597 */             StyleRange style = styles[i];
/*  598 */             if ((style.start <= offset) && (offset < style.start + style.length) && (style.underline) && (style.underlineStyle == 4)) {
/*  599 */               return true;
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*  605 */     else if (this.ranges != null) {
/*  606 */       int rangeCount = this.styleCount << 1;
/*  607 */       int index = getRangeIndex(offset, -1, rangeCount);
/*  608 */       if (index >= rangeCount) return false;
/*  609 */       int rangeStart = this.ranges[index];
/*  610 */       int rangeLength = this.ranges[(index + 1)];
/*  611 */       StyleRange rangeStyle = this.styles[(index >> 1)];
/*  612 */       if ((rangeStart <= offset) && (offset < rangeStart + rangeLength) && (rangeStyle.underline) && (rangeStyle.underlineStyle == 4)) {
/*  613 */         return true;
/*      */       }
/*      */     }
/*      */     
/*  617 */     return false;
/*      */   }
/*      */   
/*  620 */   int getLineAlignment(int index, int defaultAlignment) { if (this.lines == null) return defaultAlignment;
/*  621 */     LineInfo info = this.lines[index];
/*  622 */     if ((info != null) && ((info.flags & 0x2) != 0)) {
/*  623 */       return info.alignment;
/*      */     }
/*  625 */     return defaultAlignment;
/*      */   }
/*      */   
/*  628 */   Color getLineBackground(int index, Color defaultBackground) { if (this.lines == null) return defaultBackground;
/*  629 */     LineInfo info = this.lines[index];
/*  630 */     if ((info != null) && ((info.flags & 0x1) != 0)) {
/*  631 */       return info.background;
/*      */     }
/*  633 */     return defaultBackground;
/*      */   }
/*      */   
/*  636 */   Bullet getLineBullet(int index, Bullet defaultBullet) { if (this.bullets == null) return defaultBullet;
/*  637 */     if (this.bulletsIndices != null) return defaultBullet;
/*  638 */     for (int i = 0; i < this.bullets.length; i++) {
/*  639 */       Bullet bullet = this.bullets[i];
/*  640 */       if (bullet.indexOf(index) != -1) return bullet;
/*      */     }
/*  642 */     return defaultBullet;
/*      */   }
/*      */   
/*  645 */   int getLineHeight() { return this.ascent + this.descent; }
/*      */   
/*      */   int getLineHeight(int lineIndex) {
/*  648 */     LineSizeInfo line = getLineSize(lineIndex);
/*  649 */     if (line.needsRecalculateHeight())
/*      */     {
/*      */ 
/*  652 */       if (isVariableHeight(lineIndex)) {
/*  653 */         calculate(lineIndex, 1);
/*      */       } else {
/*  655 */         line.height = (getLineHeight() + getLineSpacing(lineIndex));
/*      */       }
/*      */     }
/*  658 */     return line.height;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean isVariableHeight(int lineIndex)
/*      */   {
/*  670 */     if (this.styledText.isWordWrap())
/*      */     {
/*  672 */       return true;
/*      */     }
/*  674 */     StyleRange[] styles = getStylesForLine(lineIndex);
/*  675 */     if (styles != null) {
/*  676 */       for (StyleRange style : styles) {
/*  677 */         if (style.isVariableHeight())
/*      */         {
/*  679 */           return true;
/*      */         }
/*      */       }
/*      */     }
/*  683 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int getLineSpacing(int lineIndex)
/*      */   {
/*  695 */     if (this.styledText.lineSpacing > 0)
/*  696 */       return this.styledText.lineSpacing;
/*  697 */     if (this.lineSpacingProvider != null) {
/*  698 */       Integer lineSpacing = this.lineSpacingProvider.getLineSpacing(lineIndex);
/*  699 */       if (lineSpacing != null) {
/*  700 */         return lineSpacing.intValue();
/*      */       }
/*      */     }
/*  703 */     return 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private StyleRange[] getStylesForLine(int lineIndex)
/*      */   {
/*  713 */     int start = this.styledText.getOffsetAtLine(lineIndex);
/*  714 */     int length = this.styledText.getLine(lineIndex).length();
/*  715 */     return getStyleRanges(start, length, false);
/*      */   }
/*      */   
/*  718 */   int getLineIndent(int index, int defaultIndent) { if (this.lines == null) return defaultIndent;
/*  719 */     LineInfo info = this.lines[index];
/*  720 */     if ((info != null) && ((info.flags & 0x4) != 0)) {
/*  721 */       return info.indent;
/*      */     }
/*  723 */     return defaultIndent;
/*      */   }
/*      */   
/*  726 */   int getLineWrapIndent(int index, int defaultWrapIndent) { if (this.lines == null) return defaultWrapIndent;
/*  727 */     LineInfo info = this.lines[index];
/*  728 */     if ((info != null) && ((info.flags & 0x80) != 0)) {
/*  729 */       return info.wrapIndent;
/*      */     }
/*  731 */     return defaultWrapIndent;
/*      */   }
/*      */   
/*  734 */   boolean getLineJustify(int index, boolean defaultJustify) { if (this.lines == null) return defaultJustify;
/*  735 */     LineInfo info = this.lines[index];
/*  736 */     if ((info != null) && ((info.flags & 0x8) != 0)) {
/*  737 */       return info.justify;
/*      */     }
/*  739 */     return defaultJustify;
/*      */   }
/*      */   
/*  742 */   int[] getLineTabStops(int index, int[] defaultTabStops) { if (this.lines == null) return defaultTabStops;
/*  743 */     LineInfo info = this.lines[index];
/*  744 */     if ((info != null) && ((info.flags & 0x40) != 0)) {
/*  745 */       return info.tabStops;
/*      */     }
/*  747 */     return defaultTabStops;
/*      */   }
/*      */   
/*  750 */   StyledTextLineSpacingProvider getLineSpacingProvider() { return this.lineSpacingProvider; }
/*      */   
/*      */   int getRangeIndex(int offset, int low, int high) {
/*  753 */     if (this.styleCount == 0) return 0;
/*  754 */     if (this.ranges != null) {
/*  755 */       while (high - low > 2) {
/*  756 */         int index = (high + low) / 2 / 2 * 2;
/*  757 */         int end = this.ranges[index] + this.ranges[(index + 1)];
/*  758 */         if (end > offset) {
/*  759 */           high = index;
/*      */         } else {
/*  761 */           low = index;
/*      */         }
/*      */       }
/*      */     }
/*  765 */     while (high - low > 1) {
/*  766 */       int index = (high + low) / 2;
/*  767 */       int end = this.styles[index].start + this.styles[index].length;
/*  768 */       if (end > offset) {
/*  769 */         high = index;
/*      */       } else {
/*  771 */         low = index;
/*      */       }
/*      */     }
/*      */     
/*  775 */     return high;
/*      */   }
/*      */   
/*  778 */   int[] getRanges(int start, int length) { if (length == 0) { return null;
/*      */     }
/*  780 */     int end = start + length - 1;
/*  781 */     int[] newRanges; if (this.ranges != null) {
/*  782 */       int rangeCount = this.styleCount << 1;
/*  783 */       int rangeStart = getRangeIndex(start, -1, rangeCount);
/*  784 */       if (rangeStart >= rangeCount) return null;
/*  785 */       if (this.ranges[rangeStart] > end) return null;
/*  786 */       int rangeEnd = Math.min(rangeCount - 2, getRangeIndex(end, rangeStart - 1, rangeCount));
/*  787 */       if (this.ranges[rangeEnd] > end) rangeEnd = Math.max(rangeStart, rangeEnd - 2);
/*  788 */       int[] newRanges = new int[rangeEnd - rangeStart + 2];
/*  789 */       System.arraycopy(this.ranges, rangeStart, newRanges, 0, newRanges.length);
/*      */     } else {
/*  791 */       int rangeStart = getRangeIndex(start, -1, this.styleCount);
/*  792 */       if (rangeStart >= this.styleCount) return null;
/*  793 */       if (this.styles[rangeStart].start > end) return null;
/*  794 */       int rangeEnd = Math.min(this.styleCount - 1, getRangeIndex(end, rangeStart - 1, this.styleCount));
/*  795 */       if (this.styles[rangeEnd].start > end) rangeEnd = Math.max(rangeStart, rangeEnd - 1);
/*  796 */       newRanges = new int[rangeEnd - rangeStart + 1 << 1];
/*  797 */       int i = rangeStart; for (int j = 0; i <= rangeEnd; j += 2) {
/*  798 */         StyleRange style = this.styles[i];
/*  799 */         newRanges[j] = style.start;
/*  800 */         newRanges[(j + 1)] = style.length;i++;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  803 */     if (start > newRanges[0]) {
/*  804 */       newRanges[1] = (newRanges[0] + newRanges[1] - start);
/*  805 */       newRanges[0] = start;
/*      */     }
/*  807 */     if (end < newRanges[(newRanges.length - 2)] + newRanges[(newRanges.length - 1)] - 1) {
/*  808 */       newRanges[(newRanges.length - 1)] = (end - newRanges[(newRanges.length - 2)] + 1);
/*      */     }
/*  810 */     return newRanges;
/*      */   }
/*      */   
/*  813 */   StyleRange[] getStyleRanges(int start, int length, boolean includeRanges) { if (length == 0) { return null;
/*      */     }
/*  815 */     int end = start + length - 1;
/*  816 */     StyleRange[] newStyles; if (this.ranges != null) {
/*  817 */       int rangeCount = this.styleCount << 1;
/*  818 */       int rangeStart = getRangeIndex(start, -1, rangeCount);
/*  819 */       if (rangeStart >= rangeCount) return null;
/*  820 */       if (this.ranges[rangeStart] > end) return null;
/*  821 */       int rangeEnd = Math.min(rangeCount - 2, getRangeIndex(end, rangeStart - 1, rangeCount));
/*  822 */       if (this.ranges[rangeEnd] > end) rangeEnd = Math.max(rangeStart, rangeEnd - 2);
/*  823 */       StyleRange[] newStyles = new StyleRange[(rangeEnd - rangeStart >> 1) + 1];
/*  824 */       if (includeRanges) {
/*  825 */         int i = rangeStart; for (int j = 0; i <= rangeEnd; j++) {
/*  826 */           newStyles[j] = ((StyleRange)this.styles[(i >> 1)].clone());
/*  827 */           newStyles[j].start = this.ranges[i];
/*  828 */           newStyles[j].length = this.ranges[(i + 1)];i += 2;
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/*  831 */         System.arraycopy(this.styles, rangeStart >> 1, newStyles, 0, newStyles.length);
/*      */       }
/*      */     } else {
/*  834 */       int rangeStart = getRangeIndex(start, -1, this.styleCount);
/*  835 */       if (rangeStart >= this.styleCount) return null;
/*  836 */       if (this.styles[rangeStart].start > end) return null;
/*  837 */       int rangeEnd = Math.min(this.styleCount - 1, getRangeIndex(end, rangeStart - 1, this.styleCount));
/*  838 */       if (this.styles[rangeEnd].start > end) rangeEnd = Math.max(rangeStart, rangeEnd - 1);
/*  839 */       newStyles = new StyleRange[rangeEnd - rangeStart + 1];
/*  840 */       System.arraycopy(this.styles, rangeStart, newStyles, 0, newStyles.length);
/*      */     }
/*  842 */     if ((includeRanges) || (this.ranges == null)) {
/*  843 */       StyleRange style = newStyles[0];
/*  844 */       if (start > style.start) {
/*  845 */         newStyles[0] = (style = (StyleRange)style.clone());
/*  846 */         style.length = (style.start + style.length - start);
/*  847 */         style.start = start;
/*      */       }
/*  849 */       style = newStyles[(newStyles.length - 1)];
/*  850 */       if (end < style.start + style.length - 1) {
/*  851 */         newStyles[(newStyles.length - 1)] = (style = (StyleRange)style.clone());
/*  852 */         style.length = (end - style.start + 1);
/*      */       }
/*      */     }
/*  855 */     return newStyles;
/*      */   }
/*      */   
/*  858 */   StyleRange getStyleRange(StyleRange style) { if ((style.underline) && (style.underlineStyle == 4)) this.hasLinks = true;
/*  859 */     if ((style.start == 0) && (style.length == 0) && (style.fontStyle == 0)) return style;
/*  860 */     StyleRange clone = (StyleRange)style.clone();
/*  861 */     clone.start = (clone.length = 0);
/*  862 */     clone.fontStyle = 0;
/*  863 */     if (clone.font == null) clone.font = getFont(style.fontStyle);
/*  864 */     return clone;
/*      */   }
/*      */   
/*  867 */   TextLayout getTextLayout(int lineIndex) { if (this.lineSpacingProvider == null) {
/*  868 */       return getTextLayout(lineIndex, this.styledText.getOrientation(), this.styledText.getWrapWidth(), this.styledText.lineSpacing);
/*      */     }
/*      */     
/*  871 */     int newLineSpacing = this.styledText.lineSpacing;
/*  872 */     Integer spacing = this.lineSpacingProvider.getLineSpacing(lineIndex);
/*  873 */     if ((spacing != null) && (spacing.intValue() >= 0)) {
/*  874 */       newLineSpacing = spacing.intValue();
/*      */     }
/*      */     
/*  877 */     if (isSameLineSpacing(lineIndex, newLineSpacing)) {
/*  878 */       return getTextLayout(lineIndex, this.styledText.getOrientation(), this.styledText.getWrapWidth(), newLineSpacing);
/*      */     }
/*      */     
/*  881 */     TextLayout layout = getTextLayout(lineIndex, this.styledText.getOrientation(), this.styledText.getWrapWidth(), this.styledText.lineSpacing);
/*      */     
/*  883 */     if (layout.getSpacing() != newLineSpacing) {
/*  884 */       layout.setSpacing(newLineSpacing);
/*  885 */       if (this.lineSpacingComputing) {
/*  886 */         return layout;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */       try
/*      */       {
/*  893 */         this.lineSpacingComputing = true;
/*  894 */         this.styledText.resetCache(lineIndex, 1);
/*  895 */         this.styledText.setVariableLineHeight();
/*  896 */         this.styledText.setCaretLocation();
/*  897 */         this.styledText.redraw();
/*      */       } finally {
/*  899 */         this.lineSpacingComputing = false;
/*      */       }
/*      */     }
/*  902 */     return layout;
/*      */   }
/*      */   
/*  905 */   boolean isSameLineSpacing(int lineIndex, int newLineSpacing) { if (this.layouts == null) {
/*  906 */       return false;
/*      */     }
/*  908 */     int layoutIndex = lineIndex - this.topIndex;
/*  909 */     if ((0 <= layoutIndex) && (layoutIndex < this.layouts.length)) {
/*  910 */       TextLayout layout = this.layouts[layoutIndex];
/*  911 */       return (layout != null) && (!layout.isDisposed()) && (layout.getSpacing() == newLineSpacing);
/*      */     }
/*  913 */     return false;
/*      */   }
/*      */   
/*  916 */   TextLayout getTextLayout(int lineIndex, int orientation, int width, int lineSpacing) { TextLayout layout = null;
/*  917 */     if (this.styledText != null) {
/*  918 */       int topIndex = this.styledText.topIndex > 0 ? this.styledText.topIndex - 1 : 0;
/*  919 */       if ((this.layouts == null) || (topIndex != this.topIndex)) {
/*  920 */         TextLayout[] newLayouts = new TextLayout[''];
/*  921 */         if (this.layouts != null) {
/*  922 */           for (int i = 0; i < this.layouts.length; i++) {
/*  923 */             if (this.layouts[i] != null) {
/*  924 */               int layoutIndex = i + this.topIndex - topIndex;
/*  925 */               if ((0 <= layoutIndex) && (layoutIndex < newLayouts.length)) {
/*  926 */                 newLayouts[layoutIndex] = this.layouts[i];
/*      */               } else {
/*  928 */                 this.layouts[i].dispose();
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*  933 */         if ((this.bullets != null) && (this.bulletsIndices != null) && (topIndex != this.topIndex)) {
/*  934 */           int delta = topIndex - this.topIndex;
/*  935 */           if (delta > 0) {
/*  936 */             if (delta < this.bullets.length) {
/*  937 */               System.arraycopy(this.bullets, delta, this.bullets, 0, this.bullets.length - delta);
/*  938 */               System.arraycopy(this.bulletsIndices, delta, this.bulletsIndices, 0, this.bulletsIndices.length - delta);
/*      */             }
/*  940 */             int startIndex = Math.max(0, this.bullets.length - delta);
/*  941 */             for (int i = startIndex; i < this.bullets.length; i++) this.bullets[i] = null;
/*      */           } else {
/*  943 */             if (-delta < this.bullets.length) {
/*  944 */               System.arraycopy(this.bullets, 0, this.bullets, -delta, this.bullets.length + delta);
/*  945 */               System.arraycopy(this.bulletsIndices, 0, this.bulletsIndices, -delta, this.bulletsIndices.length + delta);
/*      */             }
/*  947 */             int endIndex = Math.min(this.bullets.length, -delta);
/*  948 */             for (int i = 0; i < endIndex; i++) this.bullets[i] = null;
/*      */           }
/*      */         }
/*  951 */         this.topIndex = topIndex;
/*  952 */         this.layouts = newLayouts;
/*      */       }
/*  954 */       if (this.layouts != null) {
/*  955 */         int layoutIndex = lineIndex - topIndex;
/*  956 */         if ((0 <= layoutIndex) && (layoutIndex < this.layouts.length)) {
/*  957 */           layout = this.layouts[layoutIndex];
/*  958 */           if (layout != null)
/*      */           {
/*  960 */             if ((lineIndex < this.lineSizes.length) && (getLineSize(lineIndex).canLayout())) {
/*  961 */               return layout;
/*      */             }
/*      */           } else {
/*  964 */             layout = this.layouts[layoutIndex] = new TextLayout(this.device);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*  969 */     if (layout == null) layout = new TextLayout(this.device);
/*  970 */     String line = this.content.getLine(lineIndex);
/*  971 */     int lineOffset = this.content.getOffsetAtLine(lineIndex);
/*  972 */     int[] segments = null;
/*  973 */     char[] segmentChars = null;
/*  974 */     int indent = 0;
/*  975 */     int wrapIndent = 0;
/*  976 */     int alignment = 16384;
/*  977 */     int textDirection = orientation;
/*  978 */     boolean justify = false;
/*  979 */     int[] tabs = { this.tabWidth };
/*  980 */     Bullet bullet = null;
/*  981 */     int[] ranges = null;
/*  982 */     StyleRange[] styles = null;
/*  983 */     int rangeStart = 0;int styleCount = 0;
/*  984 */     StyledTextEvent event = null;
/*  985 */     if (this.styledText != null) {
/*  986 */       event = this.styledText.getBidiSegments(lineOffset, line);
/*  987 */       if (event != null) {
/*  988 */         segments = event.segments;
/*  989 */         segmentChars = event.segmentsChars;
/*      */       }
/*  991 */       event = this.styledText.getLineStyleData(lineOffset, line);
/*  992 */       indent = this.styledText.indent;
/*  993 */       wrapIndent = this.styledText.wrapIndent;
/*  994 */       alignment = this.styledText.alignment;
/*  995 */       if (this.styledText.isAutoDirection()) {
/*  996 */         textDirection = 100663296;
/*  997 */       } else if ((this.styledText.getStyle() & 0x80000000) != 0) {
/*  998 */         textDirection = orientation == 67108864 ? 33554432 : 67108864;
/*      */       }
/* 1000 */       justify = this.styledText.justify;
/* 1001 */       if (this.styledText.tabs != null) tabs = this.styledText.tabs;
/*      */     }
/* 1003 */     if (event != null) {
/* 1004 */       indent = event.indent;
/* 1005 */       wrapIndent = event.wrapIndent;
/* 1006 */       alignment = event.alignment;
/* 1007 */       justify = event.justify;
/* 1008 */       bullet = event.bullet;
/* 1009 */       ranges = event.ranges;
/* 1010 */       styles = event.styles;
/* 1011 */       if (event.tabStops != null) tabs = event.tabStops;
/* 1012 */       if (styles != null) {
/* 1013 */         styleCount = styles.length;
/* 1014 */         if (this.styledText.isFixedLineHeight()) {
/* 1015 */           for (int i = 0; i < styleCount; i++) {
/* 1016 */             if (styles[i].isVariableHeight()) {
/* 1017 */               this.styledText.verticalScrollOffset = -1;
/* 1018 */               this.styledText.setVariableLineHeight();
/* 1019 */               this.styledText.redraw();
/* 1020 */               break;
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/* 1025 */       if ((this.bullets == null) || (this.bulletsIndices == null)) {
/* 1026 */         this.bullets = new Bullet[''];
/* 1027 */         this.bulletsIndices = new int[''];
/*      */       }
/* 1029 */       int index = lineIndex - this.topIndex;
/* 1030 */       if ((0 <= index) && (index < 128)) {
/* 1031 */         this.bullets[index] = bullet;
/* 1032 */         this.bulletsIndices[index] = event.bulletIndex;
/*      */       }
/*      */     } else {
/* 1035 */       if (this.lines != null) {
/* 1036 */         LineInfo info = this.lines[lineIndex];
/* 1037 */         if (info != null) {
/* 1038 */           if ((info.flags & 0x4) != 0) indent = info.indent;
/* 1039 */           if ((info.flags & 0x80) != 0) wrapIndent = info.wrapIndent;
/* 1040 */           if ((info.flags & 0x2) != 0) alignment = info.alignment;
/* 1041 */           if ((info.flags & 0x8) != 0) justify = info.justify;
/* 1042 */           if ((info.flags & 0x20) != 0) segments = info.segments;
/* 1043 */           if ((info.flags & 0x100) != 0) segmentChars = info.segmentsChars;
/* 1044 */           if ((info.flags & 0x40) != 0) tabs = info.tabStops;
/*      */         }
/*      */       }
/* 1047 */       if (this.bulletsIndices != null) {
/* 1048 */         this.bullets = null;
/* 1049 */         this.bulletsIndices = null;
/*      */       }
/* 1051 */       if (this.bullets != null) {
/* 1052 */         for (int i = 0; i < this.bullets.length; i++) {
/* 1053 */           if (this.bullets[i].indexOf(lineIndex) != -1) {
/* 1054 */             bullet = this.bullets[i];
/* 1055 */             break;
/*      */           }
/*      */         }
/*      */       }
/* 1059 */       ranges = this.ranges;
/* 1060 */       styles = this.styles;
/* 1061 */       styleCount = this.styleCount;
/* 1062 */       if (ranges != null) {
/* 1063 */         rangeStart = getRangeIndex(lineOffset, -1, styleCount << 1);
/*      */       } else {
/* 1065 */         rangeStart = getRangeIndex(lineOffset, -1, styleCount);
/*      */       }
/*      */     }
/* 1068 */     if (bullet != null) {
/* 1069 */       StyleRange style = bullet.style;
/* 1070 */       GlyphMetrics metrics = style.metrics;
/* 1071 */       indent += metrics.width;
/*      */     }
/* 1073 */     layout.setFont(this.regularFont);
/* 1074 */     layout.setAscent(this.ascent);
/* 1075 */     layout.setDescent(this.descent);
/* 1076 */     layout.setText(line);
/* 1077 */     layout.setOrientation(orientation);
/* 1078 */     layout.setSegments(segments);
/* 1079 */     layout.setSegmentsChars(segmentChars);
/* 1080 */     layout.setWidth(width);
/* 1081 */     layout.setSpacing(lineSpacing);
/* 1082 */     layout.setTabs(tabs);
/* 1083 */     layout.setDefaultTabWidth(this.tabLength);
/* 1084 */     layout.setIndent(indent);
/* 1085 */     layout.setWrapIndent(wrapIndent);
/* 1086 */     layout.setAlignment(alignment);
/* 1087 */     layout.setJustify(justify);
/* 1088 */     layout.setTextDirection(textDirection);
/*      */     
/* 1090 */     int lastOffset = 0;
/* 1091 */     int length = line.length();
/* 1092 */     if (styles != null) {
/* 1093 */       if (ranges != null) {
/* 1094 */         int rangeCount = styleCount << 1;
/* 1095 */         for (int i = rangeStart; i < rangeCount; i += 2) { int end;
/*      */           int start;
/* 1097 */           int end; if (lineOffset > ranges[i]) {
/* 1098 */             int start = 0;
/* 1099 */             end = Math.min(length, ranges[(i + 1)] - lineOffset + ranges[i]);
/*      */           } else {
/* 1101 */             start = ranges[i] - lineOffset;
/* 1102 */             end = Math.min(length, start + ranges[(i + 1)]);
/*      */           }
/* 1104 */           if (start >= length) break;
/* 1105 */           if (lastOffset < start) {
/* 1106 */             layout.setStyle(null, lastOffset, start - 1);
/*      */           }
/* 1108 */           layout.setStyle(getStyleRange(styles[(i >> 1)]), start, end);
/* 1109 */           lastOffset = Math.max(lastOffset, end);
/*      */         }
/*      */       } else {
/* 1112 */         for (int i = rangeStart; i < styleCount; i++) { int end;
/*      */           int start;
/* 1114 */           int end; if (lineOffset > styles[i].start) {
/* 1115 */             int start = 0;
/* 1116 */             end = Math.min(length, styles[i].length - lineOffset + styles[i].start);
/*      */           } else {
/* 1118 */             start = styles[i].start - lineOffset;
/* 1119 */             end = Math.min(length, start + styles[i].length);
/*      */           }
/* 1121 */           if (start >= length) break;
/* 1122 */           if (lastOffset < start) {
/* 1123 */             layout.setStyle(null, lastOffset, start - 1);
/*      */           }
/* 1125 */           layout.setStyle(getStyleRange(styles[i]), start, end);
/* 1126 */           lastOffset = Math.max(lastOffset, end);
/*      */         }
/*      */       }
/*      */     }
/* 1130 */     if (lastOffset < length) layout.setStyle(null, lastOffset, length);
/* 1131 */     if ((this.styledText != null) && (this.styledText.ime != null)) {
/* 1132 */       IME ime = this.styledText.ime;
/* 1133 */       int compositionOffset = ime.getCompositionOffset();
/* 1134 */       if (compositionOffset != -1) {
/* 1135 */         int commitCount = ime.getCommitCount();
/* 1136 */         int compositionLength = ime.getText().length();
/* 1137 */         if (compositionLength != commitCount) {
/* 1138 */           int compositionLine = this.content.getLineAtOffset(compositionOffset);
/* 1139 */           if (compositionLine == lineIndex) {
/* 1140 */             int[] imeRanges = ime.getRanges();
/* 1141 */             TextStyle[] imeStyles = ime.getStyles();
/* 1142 */             if (imeRanges.length > 0) {
/* 1143 */               for (int i = 0; i < imeStyles.length; i++) {
/* 1144 */                 int start = imeRanges[(i * 2)] - lineOffset;
/* 1145 */                 int end = imeRanges[(i * 2 + 1)] - lineOffset;
/* 1146 */                 TextStyle imeStyle = imeStyles[i];
/* 1147 */                 for (int j = start; j <= end; j++) {
/* 1148 */                   if ((0 > j) || (j >= length)) break;
/* 1149 */                   TextStyle userStyle = layout.getStyle(cap(layout, j));
/* 1150 */                   if ((userStyle == null) && (j > 0)) userStyle = layout.getStyle(cap(layout, j - 1));
/* 1151 */                   if ((userStyle == null) && (j + 1 < length)) userStyle = layout.getStyle(cap(layout, j + 1));
/* 1152 */                   if (userStyle == null) {
/* 1153 */                     layout.setStyle(imeStyle, j, j);
/*      */                   } else {
/* 1155 */                     TextStyle newStyle = new TextStyle(imeStyle);
/* 1156 */                     if (newStyle.font == null) newStyle.font = userStyle.font;
/* 1157 */                     if (newStyle.foreground == null) newStyle.foreground = userStyle.foreground;
/* 1158 */                     if (newStyle.background == null) newStyle.background = userStyle.background;
/* 1159 */                     layout.setStyle(newStyle, j, j);
/*      */                   }
/*      */                 }
/*      */               }
/*      */             } else {
/* 1164 */               int start = compositionOffset - lineOffset;
/* 1165 */               int end = start + compositionLength - 1;
/* 1166 */               TextStyle userStyle = layout.getStyle(cap(layout, start));
/* 1167 */               if (userStyle == null) {
/* 1168 */                 if (start > 0) userStyle = layout.getStyle(cap(layout, start - 1));
/* 1169 */                 if ((userStyle == null) && (end + 1 < length)) userStyle = layout.getStyle(cap(layout, end + 1));
/* 1170 */                 if (userStyle != null) {
/* 1171 */                   TextStyle newStyle = new TextStyle();
/* 1172 */                   newStyle.font = userStyle.font;
/* 1173 */                   newStyle.foreground = userStyle.foreground;
/* 1174 */                   newStyle.background = userStyle.background;
/* 1175 */                   layout.setStyle(newStyle, start, end);
/*      */                 }
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 1184 */     if ((this.styledText != null) && (this.styledText.isFixedLineHeight())) {
/* 1185 */       int index = -1;
/* 1186 */       int lineCount = layout.getLineCount();
/* 1187 */       int height = getLineHeight();
/* 1188 */       for (int i = 0; i < lineCount; i++) {
/* 1189 */         int lineHeight = layout.getLineBounds(i).height;
/* 1190 */         if (lineHeight > height) {
/* 1191 */           height = lineHeight;
/* 1192 */           index = i;
/*      */         }
/*      */       }
/* 1195 */       if (index != -1) {
/* 1196 */         FontMetrics metrics = layout.getLineMetrics(index);
/* 1197 */         this.ascent = (metrics.getAscent() + metrics.getLeading());
/* 1198 */         this.descent = metrics.getDescent();
/* 1199 */         if (this.layouts != null) {
/* 1200 */           for (int i = 0; i < this.layouts.length; i++) {
/* 1201 */             if ((this.layouts[i] != null) && (this.layouts[i] != layout)) {
/* 1202 */               this.layouts[i].setAscent(this.ascent);
/* 1203 */               this.layouts[i].setDescent(this.descent);
/*      */             }
/*      */           }
/*      */         }
/* 1207 */         this.styledText.calculateScrollBars();
/* 1208 */         if (this.styledText.verticalScrollOffset != 0) {
/* 1209 */           int topIndex = this.styledText.topIndex;
/* 1210 */           int topIndexY = this.styledText.topIndexY;
/* 1211 */           int lineHeight = getLineHeight();
/*      */           int newVerticalScrollOffset;
/* 1213 */           int newVerticalScrollOffset; if (topIndexY >= 0) {
/* 1214 */             newVerticalScrollOffset = (topIndex - 1) * lineHeight + lineHeight - topIndexY;
/*      */           } else {
/* 1216 */             newVerticalScrollOffset = topIndex * lineHeight - topIndexY;
/*      */           }
/* 1218 */           this.styledText.scrollVertical(newVerticalScrollOffset - this.styledText.verticalScrollOffset, true);
/*      */         }
/* 1220 */         if (this.styledText.isBidiCaret()) this.styledText.createCaretBitmaps();
/* 1221 */         this.styledText.caretDirection = 0;
/* 1222 */         this.styledText.setCaretLocation();
/* 1223 */         this.styledText.redraw();
/*      */       }
/*      */     }
/* 1226 */     return layout;
/*      */   }
/*      */   
/* 1229 */   int getWidth() { return this.maxWidth; }
/*      */   
/*      */   void reset() {
/* 1232 */     if (this.layouts != null) {
/* 1233 */       for (int i = 0; i < this.layouts.length; i++) {
/* 1234 */         TextLayout layout = this.layouts[i];
/* 1235 */         if (layout != null) layout.dispose();
/*      */       }
/* 1237 */       this.layouts = null;
/*      */     }
/* 1239 */     this.topIndex = -1;
/* 1240 */     this.stylesSetCount = (this.styleCount = this.lineCount = 0);
/* 1241 */     this.ranges = null;
/* 1242 */     this.styles = null;
/* 1243 */     this.stylesSet = null;
/* 1244 */     this.lines = null;
/* 1245 */     this.lineSizes = null;
/* 1246 */     this.bullets = null;
/* 1247 */     this.bulletsIndices = null;
/* 1248 */     this.redrawLines = null;
/* 1249 */     this.hasLinks = false;
/*      */   }
/*      */   
/* 1252 */   void reset(int startLine, int lineCount) { int endLine = startLine + lineCount;
/* 1253 */     if ((startLine < 0) || (endLine > this.lineSizes.length)) return;
/* 1254 */     SortedSet<Integer> lines = new TreeSet();
/* 1255 */     for (int i = startLine; i < endLine; i++) {
/* 1256 */       lines.add(Integer.valueOf(i));
/*      */     }
/* 1258 */     reset(lines);
/*      */   }
/*      */   
/* 1261 */   void reset(Set<Integer> lines) { if ((lines == null) || (lines.isEmpty())) return;
/* 1262 */     int resetLineCount = 0;
/* 1263 */     for (Integer line : lines) {
/* 1264 */       if ((line.intValue() >= 0) || (line.intValue() < this.lineCount)) {
/* 1265 */         resetLineCount++;
/* 1266 */         getLineSize(line.intValue()).resetSize();
/*      */       }
/*      */     }
/* 1269 */     if (lines.contains(Integer.valueOf(this.maxWidthLineIndex))) {
/* 1270 */       this.maxWidth = 0;
/* 1271 */       this.maxWidthLineIndex = -1;
/* 1272 */       if (resetLineCount != this.lineCount)
/* 1273 */         for (int i = 0; i < this.lineCount; i++) {
/* 1274 */           LineSizeInfo lineSize = getLineSize(i);
/* 1275 */           if (lineSize.width > this.maxWidth) {
/* 1276 */             this.maxWidth = lineSize.width;
/* 1277 */             this.maxWidthLineIndex = i;
/*      */           }
/*      */         }
/*      */     }
/*      */   }
/*      */   
/*      */   void setContent(StyledTextContent content) {
/* 1284 */     reset();
/* 1285 */     this.content = content;
/* 1286 */     this.lineCount = content.getLineCount();
/* 1287 */     this.lineSizes = new LineSizeInfo[this.lineCount];
/* 1288 */     this.maxWidth = 0;
/* 1289 */     this.maxWidthLineIndex = -1;
/* 1290 */     reset(0, this.lineCount);
/*      */   }
/*      */   
/* 1293 */   void setFont(Font font, int tabs) { TextLayout layout = new TextLayout(this.device);
/* 1294 */     layout.setFont(this.regularFont);
/* 1295 */     this.tabLength = tabs;
/* 1296 */     if (font != null) {
/* 1297 */       if (this.boldFont != null) this.boldFont.dispose();
/* 1298 */       if (this.italicFont != null) this.italicFont.dispose();
/* 1299 */       if (this.boldItalicFont != null) this.boldItalicFont.dispose();
/* 1300 */       this.boldFont = (this.italicFont = this.boldItalicFont = null);
/* 1301 */       this.regularFont = font;
/* 1302 */       layout.setText("    ");
/* 1303 */       layout.setFont(font);
/* 1304 */       layout.setStyle(new TextStyle(getFont(0), null, null), 0, 0);
/* 1305 */       layout.setStyle(new TextStyle(getFont(1), null, null), 1, 1);
/* 1306 */       layout.setStyle(new TextStyle(getFont(2), null, null), 2, 2);
/* 1307 */       layout.setStyle(new TextStyle(getFont(3), null, null), 3, 3);
/* 1308 */       FontMetrics metrics = layout.getLineMetrics(0);
/* 1309 */       this.ascent = (metrics.getAscent() + metrics.getLeading());
/* 1310 */       this.descent = metrics.getDescent();
/* 1311 */       this.boldFont.dispose();
/* 1312 */       this.italicFont.dispose();
/* 1313 */       this.boldItalicFont.dispose();
/* 1314 */       this.boldFont = (this.italicFont = this.boldItalicFont = null);
/*      */     }
/* 1316 */     layout.dispose();
/* 1317 */     layout = new TextLayout(this.device);
/* 1318 */     layout.setFont(this.regularFont);
/* 1319 */     StringBuilder tabBuffer = new StringBuilder(tabs);
/* 1320 */     for (int i = 0; i < tabs; i++) {
/* 1321 */       tabBuffer.append(' ');
/*      */     }
/* 1323 */     layout.setText(tabBuffer.toString());
/* 1324 */     this.tabWidth = layout.getBounds().width;
/* 1325 */     layout.dispose();
/* 1326 */     if (this.styledText != null) {
/* 1327 */       GC gc = new GC(this.styledText);
/* 1328 */       this.averageCharWidth = ((int)gc.getFontMetrics().getAverageCharacterWidth());
/* 1329 */       this.fixedPitch = (gc.stringExtent("l").x == gc.stringExtent("W").x);
/* 1330 */       gc.dispose();
/*      */     }
/*      */   }
/*      */   
/* 1334 */   void setLineAlignment(int startLine, int count, int alignment) { if (this.lines == null) this.lines = new LineInfo[this.lineCount];
/* 1335 */     for (int i = startLine; i < startLine + count; i++) {
/* 1336 */       if (this.lines[i] == null) {
/* 1337 */         this.lines[i] = new LineInfo();
/*      */       }
/* 1339 */       this.lines[i].flags |= 0x2;
/* 1340 */       this.lines[i].alignment = alignment;
/*      */     }
/*      */   }
/*      */   
/* 1344 */   void setLineBackground(int startLine, int count, Color background) { if (this.lines == null) this.lines = new LineInfo[this.lineCount];
/* 1345 */     for (int i = startLine; i < startLine + count; i++) {
/* 1346 */       if (this.lines[i] == null) {
/* 1347 */         this.lines[i] = new LineInfo();
/*      */       }
/* 1349 */       this.lines[i].flags |= 0x1;
/* 1350 */       this.lines[i].background = background;
/*      */     }
/*      */   }
/*      */   
/* 1354 */   void setLineBullet(int startLine, int count, Bullet bullet) { if (this.bulletsIndices != null) {
/* 1355 */       this.bulletsIndices = null;
/* 1356 */       this.bullets = null;
/*      */     }
/* 1358 */     if (this.bullets == null) {
/* 1359 */       if (bullet == null) return;
/* 1360 */       this.bullets = new Bullet[1];
/* 1361 */       this.bullets[0] = bullet;
/*      */     }
/* 1363 */     int index = 0;
/* 1364 */     while ((index < this.bullets.length) && 
/* 1365 */       (bullet != this.bullets[index])) {
/* 1366 */       index++;
/*      */     }
/* 1368 */     if (bullet != null) {
/* 1369 */       if (index == this.bullets.length) {
/* 1370 */         Bullet[] newBulletsList = new Bullet[this.bullets.length + 1];
/* 1371 */         System.arraycopy(this.bullets, 0, newBulletsList, 0, this.bullets.length);
/* 1372 */         newBulletsList[index] = bullet;
/* 1373 */         this.bullets = newBulletsList;
/*      */       }
/* 1375 */       bullet.addIndices(startLine, count);
/*      */     } else {
/* 1377 */       updateBullets(startLine, count, 0, false);
/* 1378 */       this.styledText.redrawLinesBullet(this.redrawLines);
/* 1379 */       this.redrawLines = null;
/*      */     }
/*      */   }
/*      */   
/* 1383 */   void setLineIndent(int startLine, int count, int indent) { if (this.lines == null) this.lines = new LineInfo[this.lineCount];
/* 1384 */     for (int i = startLine; i < startLine + count; i++) {
/* 1385 */       if (this.lines[i] == null) {
/* 1386 */         this.lines[i] = new LineInfo();
/*      */       }
/* 1388 */       this.lines[i].flags |= 0x4;
/* 1389 */       this.lines[i].indent = indent;
/*      */     }
/*      */   }
/*      */   
/* 1393 */   void setLineWrapIndent(int startLine, int count, int wrapIndent) { if (this.lines == null) this.lines = new LineInfo[this.lineCount];
/* 1394 */     for (int i = startLine; i < startLine + count; i++) {
/* 1395 */       if (this.lines[i] == null) {
/* 1396 */         this.lines[i] = new LineInfo();
/*      */       }
/* 1398 */       this.lines[i].flags |= 0x80;
/* 1399 */       this.lines[i].wrapIndent = wrapIndent;
/*      */     }
/*      */   }
/*      */   
/* 1403 */   void setLineJustify(int startLine, int count, boolean justify) { if (this.lines == null) this.lines = new LineInfo[this.lineCount];
/* 1404 */     for (int i = startLine; i < startLine + count; i++) {
/* 1405 */       if (this.lines[i] == null) {
/* 1406 */         this.lines[i] = new LineInfo();
/*      */       }
/* 1408 */       this.lines[i].flags |= 0x8;
/* 1409 */       this.lines[i].justify = justify;
/*      */     }
/*      */   }
/*      */   
/* 1413 */   void setLineSegments(int startLine, int count, int[] segments) { if (this.lines == null) this.lines = new LineInfo[this.lineCount];
/* 1414 */     for (int i = startLine; i < startLine + count; i++) {
/* 1415 */       if (this.lines[i] == null) {
/* 1416 */         this.lines[i] = new LineInfo();
/*      */       }
/* 1418 */       this.lines[i].flags |= 0x20;
/* 1419 */       this.lines[i].segments = segments;
/*      */     }
/*      */   }
/*      */   
/* 1423 */   void setLineSegmentChars(int startLine, int count, char[] segmentChars) { if (this.lines == null) this.lines = new LineInfo[this.lineCount];
/* 1424 */     for (int i = startLine; i < startLine + count; i++) {
/* 1425 */       if (this.lines[i] == null) {
/* 1426 */         this.lines[i] = new LineInfo();
/*      */       }
/* 1428 */       this.lines[i].flags |= 0x100;
/* 1429 */       this.lines[i].segmentsChars = segmentChars;
/*      */     }
/*      */   }
/*      */   
/* 1433 */   void setLineTabStops(int startLine, int count, int[] tabStops) { if (this.lines == null) this.lines = new LineInfo[this.lineCount];
/* 1434 */     for (int i = startLine; i < startLine + count; i++) {
/* 1435 */       if (this.lines[i] == null) {
/* 1436 */         this.lines[i] = new LineInfo();
/*      */       }
/* 1438 */       this.lines[i].flags |= 0x40;
/* 1439 */       this.lines[i].tabStops = tabStops;
/*      */     }
/*      */   }
/*      */   
/* 1443 */   void setLineSpacingProvider(StyledTextLineSpacingProvider lineSpacingProvider) { this.lineSpacingProvider = lineSpacingProvider; }
/*      */   
/*      */   void setStyleRanges(int[] newRanges, StyleRange[] newStyles) {
/* 1446 */     if (newStyles == null) {
/* 1447 */       this.stylesSetCount = (this.styleCount = 0);
/* 1448 */       this.ranges = null;
/* 1449 */       this.styles = null;
/* 1450 */       this.stylesSet = null;
/* 1451 */       this.hasLinks = false;
/* 1452 */       return;
/*      */     }
/* 1454 */     if (newRanges == null) {
/* 1455 */       newRanges = new int[newStyles.length << 1];
/* 1456 */       StyleRange[] tmpStyles = new StyleRange[newStyles.length];
/* 1457 */       if (this.stylesSet == null) this.stylesSet = new StyleRange[4];
/* 1458 */       int i = 0; for (int j = 0; i < newStyles.length; i++) {
/* 1459 */         StyleRange newStyle = newStyles[i];
/* 1460 */         newRanges[(j++)] = newStyle.start;
/* 1461 */         newRanges[(j++)] = newStyle.length;
/* 1462 */         int index = 0;
/* 1463 */         while ((index < this.stylesSetCount) && 
/* 1464 */           (!this.stylesSet[index].similarTo(newStyle))) {
/* 1465 */           index++;
/*      */         }
/* 1467 */         if (index == this.stylesSetCount) {
/* 1468 */           if (this.stylesSetCount == this.stylesSet.length) {
/* 1469 */             StyleRange[] tmpStylesSet = new StyleRange[this.stylesSetCount + 4];
/* 1470 */             System.arraycopy(this.stylesSet, 0, tmpStylesSet, 0, this.stylesSetCount);
/* 1471 */             this.stylesSet = tmpStylesSet;
/*      */           }
/* 1473 */           this.stylesSet[(this.stylesSetCount++)] = newStyle;
/*      */         }
/* 1475 */         tmpStyles[i] = this.stylesSet[index];
/*      */       }
/* 1477 */       newStyles = tmpStyles;
/*      */     }
/*      */     
/* 1480 */     if (this.styleCount == 0) {
/* 1481 */       if (newRanges != null) {
/* 1482 */         this.ranges = new int[newRanges.length];
/* 1483 */         System.arraycopy(newRanges, 0, this.ranges, 0, this.ranges.length);
/*      */       }
/* 1485 */       this.styles = new StyleRange[newStyles.length];
/* 1486 */       System.arraycopy(newStyles, 0, this.styles, 0, this.styles.length);
/* 1487 */       this.styleCount = newStyles.length;
/* 1488 */       return;
/*      */     }
/* 1490 */     if ((newRanges != null) && (this.ranges == null)) {
/* 1491 */       this.ranges = new int[this.styles.length << 1];
/* 1492 */       int i = 0; for (int j = 0; i < this.styleCount; i++) {
/* 1493 */         this.ranges[(j++)] = this.styles[i].start;
/* 1494 */         this.ranges[(j++)] = this.styles[i].length;
/*      */       }
/*      */     }
/* 1497 */     if ((newRanges == null) && (this.ranges != null)) {
/* 1498 */       newRanges = new int[newStyles.length << 1];
/* 1499 */       int i = 0; for (int j = 0; i < newStyles.length; i++) {
/* 1500 */         newRanges[(j++)] = newStyles[i].start;
/* 1501 */         newRanges[(j++)] = newStyles[i].length;
/*      */       }
/*      */     }
/* 1504 */     if (this.ranges != null) {
/* 1505 */       int rangeCount = this.styleCount << 1;
/* 1506 */       int start = newRanges[0];
/* 1507 */       int modifyStart = getRangeIndex(start, -1, rangeCount);
/* 1508 */       boolean insert = modifyStart == rangeCount;
/* 1509 */       if (!insert) {
/* 1510 */         int end = newRanges[(newRanges.length - 2)] + newRanges[(newRanges.length - 1)];
/* 1511 */         int modifyEnd = getRangeIndex(end, modifyStart - 1, rangeCount);
/* 1512 */         insert = (modifyStart == modifyEnd) && (this.ranges[modifyStart] >= end);
/*      */       }
/* 1514 */       if (insert) {
/* 1515 */         addMerge(newRanges, newStyles, newRanges.length, modifyStart, modifyStart);
/* 1516 */         return;
/*      */       }
/* 1518 */       int modifyEnd = modifyStart;
/* 1519 */       int[] mergeRanges = new int[6];
/* 1520 */       StyleRange[] mergeStyles = new StyleRange[3];
/* 1521 */       for (int i = 0; i < newRanges.length; i += 2) {
/* 1522 */         int newStart = newRanges[i];
/* 1523 */         int newEnd = newStart + newRanges[(i + 1)];
/* 1524 */         if (newStart != newEnd) {
/* 1525 */           int modifyLast = 0;int mergeCount = 0;
/* 1526 */           while (modifyEnd < rangeCount) {
/* 1527 */             if (newStart >= this.ranges[modifyStart] + this.ranges[(modifyStart + 1)]) modifyStart += 2;
/* 1528 */             if (this.ranges[modifyEnd] + this.ranges[(modifyEnd + 1)] > newEnd) break;
/* 1529 */             modifyEnd += 2;
/*      */           }
/* 1531 */           if ((this.ranges[modifyStart] < newStart) && (newStart < this.ranges[modifyStart] + this.ranges[(modifyStart + 1)])) {
/* 1532 */             mergeStyles[(mergeCount >> 1)] = this.styles[(modifyStart >> 1)];
/* 1533 */             mergeRanges[mergeCount] = this.ranges[modifyStart];
/* 1534 */             mergeRanges[(mergeCount + 1)] = (newStart - this.ranges[modifyStart]);
/* 1535 */             mergeCount += 2;
/*      */           }
/* 1537 */           mergeStyles[(mergeCount >> 1)] = newStyles[(i >> 1)];
/* 1538 */           mergeRanges[mergeCount] = newStart;
/* 1539 */           mergeRanges[(mergeCount + 1)] = newRanges[(i + 1)];
/* 1540 */           mergeCount += 2;
/* 1541 */           if ((modifyEnd < rangeCount) && (this.ranges[modifyEnd] < newEnd) && (newEnd < this.ranges[modifyEnd] + this.ranges[(modifyEnd + 1)])) {
/* 1542 */             mergeStyles[(mergeCount >> 1)] = this.styles[(modifyEnd >> 1)];
/* 1543 */             mergeRanges[mergeCount] = newEnd;
/* 1544 */             mergeRanges[(mergeCount + 1)] = (this.ranges[modifyEnd] + this.ranges[(modifyEnd + 1)] - newEnd);
/* 1545 */             mergeCount += 2;
/* 1546 */             modifyLast = 2;
/*      */           }
/* 1548 */           int grow = addMerge(mergeRanges, mergeStyles, mergeCount, modifyStart, modifyEnd + modifyLast);
/* 1549 */           rangeCount += grow;
/* 1550 */           modifyStart = modifyEnd += grow;
/*      */         }
/*      */       }
/* 1553 */     } else { int start = newStyles[0].start;
/* 1554 */       int modifyStart = getRangeIndex(start, -1, this.styleCount);
/* 1555 */       boolean insert = modifyStart == this.styleCount;
/* 1556 */       if (!insert) {
/* 1557 */         int end = newStyles[(newStyles.length - 1)].start + newStyles[(newStyles.length - 1)].length;
/* 1558 */         int modifyEnd = getRangeIndex(end, modifyStart - 1, this.styleCount);
/* 1559 */         insert = (modifyStart == modifyEnd) && (this.styles[modifyStart].start >= end);
/*      */       }
/* 1561 */       if (insert) {
/* 1562 */         addMerge(newStyles, newStyles.length, modifyStart, modifyStart);
/* 1563 */         return;
/*      */       }
/* 1565 */       int modifyEnd = modifyStart;
/* 1566 */       StyleRange[] mergeStyles = new StyleRange[3];
/* 1567 */       for (int i = 0; i < newStyles.length; i++) {
/* 1568 */         StyleRange newStyle = newStyles[i];
/* 1569 */         int newStart = newStyle.start;
/* 1570 */         int newEnd = newStart + newStyle.length;
/* 1571 */         if (newStart != newEnd) {
/* 1572 */           int modifyLast = 0;int mergeCount = 0;
/* 1573 */           while (modifyEnd < this.styleCount) {
/* 1574 */             if (newStart >= this.styles[modifyStart].start + this.styles[modifyStart].length) modifyStart++;
/* 1575 */             if (this.styles[modifyEnd].start + this.styles[modifyEnd].length > newEnd) break;
/* 1576 */             modifyEnd++;
/*      */           }
/* 1578 */           StyleRange style = this.styles[modifyStart];
/* 1579 */           if ((style.start < newStart) && (newStart < style.start + style.length)) {
/* 1580 */             style = mergeStyles[(mergeCount++)] = (StyleRange)style.clone();
/* 1581 */             style.length = (newStart - style.start);
/*      */           }
/* 1583 */           mergeStyles[(mergeCount++)] = newStyle;
/* 1584 */           if (modifyEnd < this.styleCount) {
/* 1585 */             style = this.styles[modifyEnd];
/* 1586 */             if ((style.start < newEnd) && (newEnd < style.start + style.length)) {
/* 1587 */               style = mergeStyles[(mergeCount++)] = (StyleRange)style.clone();
/* 1588 */               style.length += style.start - newEnd;
/* 1589 */               style.start = newEnd;
/* 1590 */               modifyLast = 1;
/*      */             }
/*      */           }
/* 1593 */           int grow = addMerge(mergeStyles, mergeCount, modifyStart, modifyEnd + modifyLast);
/* 1594 */           modifyStart = modifyEnd += grow;
/*      */         }
/*      */       }
/*      */     } }
/*      */   
/* 1599 */   void textChanging(TextChangingEvent event) { int start = event.start;
/* 1600 */     int newCharCount = event.newCharCount;int replaceCharCount = event.replaceCharCount;
/* 1601 */     int newLineCount = event.newLineCount;int replaceLineCount = event.replaceLineCount;
/*      */     
/* 1603 */     updateRanges(start, replaceCharCount, newCharCount);
/*      */     
/* 1605 */     int startLine = this.content.getLineAtOffset(start);
/* 1606 */     if (replaceCharCount == this.content.getCharCount()) this.lines = null;
/* 1607 */     if (replaceLineCount == this.lineCount) {
/* 1608 */       this.lineCount = newLineCount;
/* 1609 */       this.lineSizes = new LineSizeInfo[this.lineCount];
/* 1610 */       reset(0, this.lineCount);
/*      */     } else {
/* 1612 */       int delta = newLineCount - replaceLineCount;
/* 1613 */       if (this.lineCount + delta > this.lineSizes.length) {
/* 1614 */         LineSizeInfo[] newLineSizes = new LineSizeInfo[this.lineCount + delta + 32];
/* 1615 */         System.arraycopy(this.lineSizes, 0, newLineSizes, 0, this.lineCount);
/* 1616 */         this.lineSizes = newLineSizes;
/*      */       }
/* 1618 */       if ((this.lines != null) && 
/* 1619 */         (this.lineCount + delta > this.lines.length)) {
/* 1620 */         LineInfo[] newLines = new LineInfo[this.lineCount + delta + 32];
/* 1621 */         System.arraycopy(this.lines, 0, newLines, 0, this.lineCount);
/* 1622 */         this.lines = newLines;
/*      */       }
/*      */       
/* 1625 */       int startIndex = startLine + replaceLineCount + 1;
/* 1626 */       int endIndex = startLine + newLineCount + 1;
/* 1627 */       System.arraycopy(this.lineSizes, startIndex, this.lineSizes, endIndex, this.lineCount - startIndex);
/* 1628 */       for (int i = startLine; i < endIndex; i++) {
/* 1629 */         this.lineSizes[i] = null;
/*      */       }
/* 1631 */       for (int i = this.lineCount + delta; i < this.lineCount; i++) {
/* 1632 */         this.lineSizes[i] = null;
/*      */       }
/* 1634 */       if (this.layouts != null) {
/* 1635 */         int layoutStartLine = startLine - this.topIndex;
/* 1636 */         int layoutEndLine = layoutStartLine + replaceLineCount + 1;
/* 1637 */         for (int i = layoutStartLine; i < layoutEndLine; i++) {
/* 1638 */           if ((0 <= i) && (i < this.layouts.length)) {
/* 1639 */             if (this.layouts[i] != null) this.layouts[i].dispose();
/* 1640 */             this.layouts[i] = null;
/* 1641 */             if ((this.bullets != null) && (this.bulletsIndices != null)) this.bullets[i] = null;
/*      */           }
/*      */         }
/* 1644 */         if (delta > 0) {
/* 1645 */           for (int i = this.layouts.length - 1; i >= layoutEndLine; i--) {
/* 1646 */             if ((0 <= i) && (i < this.layouts.length)) {
/* 1647 */               endIndex = i + delta;
/* 1648 */               if ((0 <= endIndex) && (endIndex < this.layouts.length)) {
/* 1649 */                 this.layouts[endIndex] = this.layouts[i];
/* 1650 */                 this.layouts[i] = null;
/* 1651 */                 if ((this.bullets != null) && (this.bulletsIndices != null)) {
/* 1652 */                   this.bullets[endIndex] = this.bullets[i];
/* 1653 */                   this.bulletsIndices[endIndex] = this.bulletsIndices[i];
/* 1654 */                   this.bullets[i] = null;
/*      */                 }
/*      */               } else {
/* 1657 */                 if (this.layouts[i] != null) this.layouts[i].dispose();
/* 1658 */                 this.layouts[i] = null;
/* 1659 */                 if ((this.bullets != null) && (this.bulletsIndices != null)) this.bullets[i] = null;
/*      */               }
/*      */             }
/*      */           }
/* 1663 */         } else if (delta < 0) {
/* 1664 */           for (int i = layoutEndLine; i < this.layouts.length; i++) {
/* 1665 */             if ((0 <= i) && (i < this.layouts.length)) {
/* 1666 */               endIndex = i + delta;
/* 1667 */               if ((0 <= endIndex) && (endIndex < this.layouts.length)) {
/* 1668 */                 this.layouts[endIndex] = this.layouts[i];
/* 1669 */                 this.layouts[i] = null;
/* 1670 */                 if ((this.bullets != null) && (this.bulletsIndices != null)) {
/* 1671 */                   this.bullets[endIndex] = this.bullets[i];
/* 1672 */                   this.bulletsIndices[endIndex] = this.bulletsIndices[i];
/* 1673 */                   this.bullets[i] = null;
/*      */                 }
/*      */               } else {
/* 1676 */                 if (this.layouts[i] != null) this.layouts[i].dispose();
/* 1677 */                 this.layouts[i] = null;
/* 1678 */                 if ((this.bullets != null) && (this.bulletsIndices != null)) this.bullets[i] = null;
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/* 1684 */       if ((replaceLineCount != 0) || (newLineCount != 0)) {
/* 1685 */         int startLineOffset = this.content.getOffsetAtLine(startLine);
/* 1686 */         if (startLineOffset != start) startLine++;
/* 1687 */         updateBullets(startLine, replaceLineCount, newLineCount, true);
/* 1688 */         if (this.lines != null) {
/* 1689 */           startIndex = startLine + replaceLineCount;
/* 1690 */           endIndex = startLine + newLineCount;
/* 1691 */           System.arraycopy(this.lines, startIndex, this.lines, endIndex, this.lineCount - startIndex);
/* 1692 */           for (int i = startLine; i < endIndex; i++) {
/* 1693 */             this.lines[i] = null;
/*      */           }
/* 1695 */           for (int i = this.lineCount + delta; i < this.lineCount; i++) {
/* 1696 */             this.lines[i] = null;
/*      */           }
/*      */         }
/*      */       }
/* 1700 */       this.lineCount += delta;
/* 1701 */       if ((this.maxWidthLineIndex != -1) && (startLine <= this.maxWidthLineIndex) && (this.maxWidthLineIndex <= startLine + replaceLineCount)) {
/* 1702 */         this.maxWidth = 0;
/* 1703 */         this.maxWidthLineIndex = -1;
/* 1704 */         for (int i = 0; i < this.lineCount; i++) {
/* 1705 */           LineSizeInfo lineSize = getLineSize(i);
/* 1706 */           if (lineSize.width > this.maxWidth) {
/* 1707 */             this.maxWidth = lineSize.width;
/* 1708 */             this.maxWidthLineIndex = i;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/* 1715 */   void updateBullets(int startLine, int replaceLineCount, int newLineCount, boolean update) { if (this.bullets == null) return;
/* 1716 */     if (this.bulletsIndices != null) return;
/* 1717 */     for (int i = 0; i < this.bullets.length; i++) {
/* 1718 */       Bullet bullet = this.bullets[i];
/* 1719 */       int[] lines = bullet.removeIndices(startLine, replaceLineCount, newLineCount, update);
/* 1720 */       if (lines != null) {
/* 1721 */         if (this.redrawLines == null) {
/* 1722 */           this.redrawLines = lines;
/*      */         } else {
/* 1724 */           int[] newRedrawBullets = new int[this.redrawLines.length + lines.length];
/* 1725 */           System.arraycopy(this.redrawLines, 0, newRedrawBullets, 0, this.redrawLines.length);
/* 1726 */           System.arraycopy(lines, 0, newRedrawBullets, this.redrawLines.length, lines.length);
/* 1727 */           this.redrawLines = newRedrawBullets;
/*      */         }
/*      */       }
/*      */     }
/* 1731 */     int removed = 0;
/* 1732 */     for (int i = 0; i < this.bullets.length; i++) {
/* 1733 */       if (this.bullets[i].size() == 0) removed++;
/*      */     }
/* 1735 */     if (removed > 0)
/* 1736 */       if (removed == this.bullets.length) {
/* 1737 */         this.bullets = null;
/*      */       } else {
/* 1739 */         Bullet[] newBulletsList = new Bullet[this.bullets.length - removed];
/* 1740 */         int i = 0; for (int j = 0; i < this.bullets.length; i++) {
/* 1741 */           Bullet bullet = this.bullets[i];
/* 1742 */           if (bullet.size() > 0) newBulletsList[(j++)] = bullet;
/*      */         }
/* 1744 */         this.bullets = newBulletsList;
/*      */       }
/*      */   }
/*      */   
/*      */   void updateRanges(int start, int replaceCharCount, int newCharCount) {
/* 1749 */     if ((this.styleCount == 0) || ((replaceCharCount == 0) && (newCharCount == 0))) return;
/* 1750 */     if (this.ranges != null) {
/* 1751 */       int rangeCount = this.styleCount << 1;
/* 1752 */       int modifyStart = getRangeIndex(start, -1, rangeCount);
/* 1753 */       if (modifyStart == rangeCount) return;
/* 1754 */       int end = start + replaceCharCount;
/* 1755 */       int modifyEnd = getRangeIndex(end, modifyStart - 1, rangeCount);
/* 1756 */       int offset = newCharCount - replaceCharCount;
/* 1757 */       if ((modifyStart == modifyEnd) && (this.ranges[modifyStart] < start) && (end < this.ranges[modifyEnd] + this.ranges[(modifyEnd + 1)])) {
/* 1758 */         if (newCharCount == 0) {
/* 1759 */           this.ranges[(modifyStart + 1)] -= replaceCharCount;
/* 1760 */           modifyEnd += 2;
/*      */         } else {
/* 1762 */           if (rangeCount + 2 > this.ranges.length) {
/* 1763 */             int[] newRanges = new int[this.ranges.length + 64];
/* 1764 */             System.arraycopy(this.ranges, 0, newRanges, 0, rangeCount);
/* 1765 */             this.ranges = newRanges;
/* 1766 */             StyleRange[] newStyles = new StyleRange[this.styles.length + 32];
/* 1767 */             System.arraycopy(this.styles, 0, newStyles, 0, this.styleCount);
/* 1768 */             this.styles = newStyles;
/*      */           }
/* 1770 */           System.arraycopy(this.ranges, modifyStart + 2, this.ranges, modifyStart + 4, rangeCount - (modifyStart + 2));
/* 1771 */           System.arraycopy(this.styles, modifyStart + 2 >> 1, this.styles, modifyStart + 4 >> 1, this.styleCount - (modifyStart + 2 >> 1));
/* 1772 */           this.ranges[(modifyStart + 3)] = (this.ranges[modifyStart] + this.ranges[(modifyStart + 1)] - end);
/* 1773 */           this.ranges[(modifyStart + 2)] = (start + newCharCount);
/* 1774 */           this.ranges[(modifyStart + 1)] = (start - this.ranges[modifyStart]);
/* 1775 */           this.styles[((modifyStart >> 1) + 1)] = this.styles[(modifyStart >> 1)];
/* 1776 */           rangeCount += 2;
/* 1777 */           this.styleCount += 1;
/* 1778 */           modifyEnd += 4;
/*      */         }
/* 1780 */         if (offset != 0) {
/* 1781 */           for (int i = modifyEnd; i < rangeCount; i += 2) {
/* 1782 */             this.ranges[i] += offset;
/*      */           }
/*      */         }
/*      */       } else {
/* 1786 */         if ((this.ranges[modifyStart] < start) && (start < this.ranges[modifyStart] + this.ranges[(modifyStart + 1)])) {
/* 1787 */           this.ranges[(modifyStart + 1)] = (start - this.ranges[modifyStart]);
/* 1788 */           modifyStart += 2;
/*      */         }
/* 1790 */         if ((modifyEnd < rangeCount) && (this.ranges[modifyEnd] < end) && (end < this.ranges[modifyEnd] + this.ranges[(modifyEnd + 1)])) {
/* 1791 */           this.ranges[(modifyEnd + 1)] = (this.ranges[modifyEnd] + this.ranges[(modifyEnd + 1)] - end);
/* 1792 */           this.ranges[modifyEnd] = end;
/*      */         }
/* 1794 */         if (offset != 0) {
/* 1795 */           for (int i = modifyEnd; i < rangeCount; i += 2) {
/* 1796 */             this.ranges[i] += offset;
/*      */           }
/*      */         }
/* 1799 */         System.arraycopy(this.ranges, modifyEnd, this.ranges, modifyStart, rangeCount - modifyEnd);
/* 1800 */         System.arraycopy(this.styles, modifyEnd >> 1, this.styles, modifyStart >> 1, this.styleCount - (modifyEnd >> 1));
/* 1801 */         this.styleCount -= (modifyEnd - modifyStart >> 1);
/*      */       }
/*      */     } else {
/* 1804 */       int modifyStart = getRangeIndex(start, -1, this.styleCount);
/* 1805 */       if (modifyStart == this.styleCount) return;
/* 1806 */       int end = start + replaceCharCount;
/* 1807 */       int modifyEnd = getRangeIndex(end, modifyStart - 1, this.styleCount);
/* 1808 */       int offset = newCharCount - replaceCharCount;
/* 1809 */       if ((modifyStart == modifyEnd) && (this.styles[modifyStart].start < start) && (end < this.styles[modifyEnd].start + this.styles[modifyEnd].length)) {
/* 1810 */         if (newCharCount == 0) {
/* 1811 */           this.styles[modifyStart].length -= replaceCharCount;
/* 1812 */           modifyEnd++;
/*      */         } else {
/* 1814 */           if (this.styleCount + 1 > this.styles.length) {
/* 1815 */             StyleRange[] newStyles = new StyleRange[this.styles.length + 32];
/* 1816 */             System.arraycopy(this.styles, 0, newStyles, 0, this.styleCount);
/* 1817 */             this.styles = newStyles;
/*      */           }
/* 1819 */           System.arraycopy(this.styles, modifyStart + 1, this.styles, modifyStart + 2, this.styleCount - (modifyStart + 1));
/* 1820 */           this.styles[(modifyStart + 1)] = ((StyleRange)this.styles[modifyStart].clone());
/* 1821 */           this.styles[(modifyStart + 1)].length = (this.styles[modifyStart].start + this.styles[modifyStart].length - end);
/* 1822 */           this.styles[(modifyStart + 1)].start = (start + newCharCount);
/* 1823 */           this.styles[modifyStart].length = (start - this.styles[modifyStart].start);
/* 1824 */           this.styleCount += 1;
/* 1825 */           modifyEnd += 2;
/*      */         }
/* 1827 */         if (offset != 0) {
/* 1828 */           for (int i = modifyEnd; i < this.styleCount; i++) {
/* 1829 */             this.styles[i].start += offset;
/*      */           }
/*      */         }
/*      */       } else {
/* 1833 */         if ((this.styles[modifyStart].start < start) && (start < this.styles[modifyStart].start + this.styles[modifyStart].length)) {
/* 1834 */           this.styles[modifyStart].length = (start - this.styles[modifyStart].start);
/* 1835 */           modifyStart++;
/*      */         }
/* 1837 */         if ((modifyEnd < this.styleCount) && (this.styles[modifyEnd].start < end) && (end < this.styles[modifyEnd].start + this.styles[modifyEnd].length)) {
/* 1838 */           this.styles[modifyEnd].length = (this.styles[modifyEnd].start + this.styles[modifyEnd].length - end);
/* 1839 */           this.styles[modifyEnd].start = end;
/*      */         }
/* 1841 */         if (offset != 0) {
/* 1842 */           for (int i = modifyEnd; i < this.styleCount; i++) {
/* 1843 */             this.styles[i].start += offset;
/*      */           }
/*      */         }
/* 1846 */         System.arraycopy(this.styles, modifyEnd, this.styles, modifyStart, this.styleCount - modifyEnd);
/* 1847 */         this.styleCount -= modifyEnd - modifyStart;
/*      */       }
/*      */     }
/*      */   }
/*      */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/custom/StyledTextRenderer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */