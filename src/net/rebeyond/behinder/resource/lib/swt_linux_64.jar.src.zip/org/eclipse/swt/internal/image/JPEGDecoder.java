/*      */ package org.eclipse.swt.internal.image;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import org.eclipse.swt.SWT;
/*      */ import org.eclipse.swt.graphics.ImageData;
/*      */ import org.eclipse.swt.graphics.ImageLoader;
/*      */ import org.eclipse.swt.graphics.ImageLoaderEvent;
/*      */ import org.eclipse.swt.graphics.PaletteData;
/*      */ import org.eclipse.swt.graphics.RGB;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class JPEGDecoder
/*      */ {
/*      */   static final int DCTSIZE = 8;
/*      */   static final int DCTSIZE2 = 64;
/*      */   static final int NUM_QUANT_TBLS = 4;
/*      */   static final int NUM_HUFF_TBLS = 4;
/*      */   static final int NUM_ARITH_TBLS = 16;
/*      */   static final int MAX_COMPS_IN_SCAN = 4;
/*      */   static final int MAX_COMPONENTS = 10;
/*      */   static final int MAX_SAMP_FACTOR = 4;
/*      */   static final int D_MAX_BLOCKS_IN_MCU = 10;
/*      */   static final int HUFF_LOOKAHEAD = 8;
/*      */   static final int MAX_Q_COMPS = 4;
/*      */   static final int IFAST_SCALE_BITS = 2;
/*      */   static final int MAXJSAMPLE = 255;
/*      */   static final int CENTERJSAMPLE = 128;
/*      */   static final int MIN_GET_BITS = 25;
/*      */   static final int INPUT_BUFFER_SIZE = 4096;
/*      */   static final int SCALEBITS = 16;
/*      */   static final int ONE_HALF = 32768;
/*      */   static final int RGB_RED = 2;
/*      */   static final int RGB_GREEN = 1;
/*      */   static final int RGB_BLUE = 0;
/*      */   static final int RGB_PIXELSIZE = 3;
/*      */   static final int JBUF_PASS_THRU = 0;
/*      */   static final int JBUF_SAVE_SOURCE = 1;
/*      */   static final int JBUF_CRANK_DEST = 2;
/*      */   static final int JBUF_SAVE_AND_PASS = 3;
/*      */   static final int JPEG_MAX_DIMENSION = 65500;
/*      */   static final int BITS_IN_JSAMPLE = 8;
/*      */   static final int JDITHER_NONE = 0;
/*      */   static final int JDITHER_ORDERED = 1;
/*      */   static final int JDITHER_FS = 2;
/*      */   static final int JDCT_ISLOW = 0;
/*      */   static final int JDCT_IFAST = 1;
/*      */   static final int JDCT_FLOAT = 2;
/*      */   static final int JDCT_DEFAULT = 0;
/*      */   static final int JCS_UNKNOWN = 0;
/*      */   static final int JCS_GRAYSCALE = 1;
/*      */   static final int JCS_RGB = 2;
/*      */   static final int JCS_YCbCr = 3;
/*      */   static final int JCS_CMYK = 4;
/*      */   static final int JCS_YCCK = 5;
/*      */   static final int SAVED_COEFS = 6;
/*      */   static final int Q01_POS = 1;
/*      */   static final int Q10_POS = 8;
/*      */   static final int Q20_POS = 16;
/*      */   static final int Q11_POS = 9;
/*      */   static final int Q02_POS = 2;
/*      */   static final int CTX_PREPARE_FOR_IMCU = 0;
/*      */   static final int CTX_PROCESS_IMCU = 1;
/*      */   static final int CTX_POSTPONED_ROW = 2;
/*      */   static final int APP0_DATA_LEN = 14;
/*      */   static final int APP14_DATA_LEN = 12;
/*      */   static final int APPN_DATA_LEN = 14;
/*      */   static final int M_SOF0 = 192;
/*      */   static final int M_SOF1 = 193;
/*      */   static final int M_SOF2 = 194;
/*      */   static final int M_SOF3 = 195;
/*      */   static final int M_SOF5 = 197;
/*      */   static final int M_SOF6 = 198;
/*      */   static final int M_SOF7 = 199;
/*      */   static final int M_JPG = 200;
/*      */   static final int M_SOF9 = 201;
/*      */   static final int M_SOF10 = 202;
/*      */   static final int M_SOF11 = 203;
/*      */   static final int M_SOF13 = 205;
/*      */   static final int M_SOF14 = 206;
/*      */   static final int M_SOF15 = 207;
/*      */   static final int M_DHT = 196;
/*      */   static final int M_DAC = 204;
/*      */   static final int M_RST0 = 208;
/*      */   static final int M_RST1 = 209;
/*      */   static final int M_RST2 = 210;
/*      */   static final int M_RST3 = 211;
/*      */   static final int M_RST4 = 212;
/*      */   static final int M_RST5 = 213;
/*      */   static final int M_RST6 = 214;
/*      */   static final int M_RST7 = 215;
/*      */   static final int M_SOI = 216;
/*      */   static final int M_EOI = 217;
/*      */   static final int M_SOS = 218;
/*      */   static final int M_DQT = 219;
/*      */   static final int M_DNL = 220;
/*      */   static final int M_DRI = 221;
/*      */   static final int M_DHP = 222;
/*      */   static final int M_EXP = 223;
/*      */   static final int M_APP0 = 224;
/*      */   static final int M_APP1 = 225;
/*      */   static final int M_APP2 = 226;
/*      */   static final int M_APP3 = 227;
/*      */   static final int M_APP4 = 228;
/*      */   static final int M_APP5 = 229;
/*      */   static final int M_APP6 = 230;
/*      */   static final int M_APP7 = 231;
/*      */   static final int M_APP8 = 232;
/*      */   static final int M_APP9 = 233;
/*      */   static final int M_APP10 = 234;
/*      */   static final int M_APP11 = 235;
/*      */   static final int M_APP12 = 236;
/*      */   static final int M_APP13 = 237;
/*      */   static final int M_APP14 = 238;
/*      */   static final int M_APP15 = 239;
/*      */   static final int M_JPG0 = 240;
/*      */   static final int M_JPG13 = 253;
/*      */   static final int M_COM = 254;
/*      */   static final int M_TEM = 1;
/*      */   static final int M_ERROR = 256;
/*      */   static final int CSTATE_START = 100;
/*      */   static final int CSTATE_SCANNING = 101;
/*      */   static final int CSTATE_RAW_OK = 102;
/*      */   static final int CSTATE_WRCOEFS = 103;
/*      */   static final int DSTATE_START = 200;
/*      */   static final int DSTATE_INHEADER = 201;
/*      */   static final int DSTATE_READY = 202;
/*      */   static final int DSTATE_PRELOAD = 203;
/*      */   static final int DSTATE_PRESCAN = 204;
/*      */   static final int DSTATE_SCANNING = 205;
/*      */   static final int DSTATE_RAW_OK = 206;
/*      */   static final int DSTATE_BUFIMAGE = 207;
/*      */   static final int DSTATE_BUFPOST = 208;
/*      */   static final int DSTATE_RDCOEFS = 209;
/*      */   static final int DSTATE_STOPPING = 210;
/*      */   static final int JPEG_REACHED_SOS = 1;
/*      */   static final int JPEG_REACHED_EOI = 2;
/*      */   static final int JPEG_ROW_COMPLETED = 3;
/*      */   static final int JPEG_SCAN_COMPLETED = 4;
/*      */   static final int JPEG_SUSPENDED = 0;
/*      */   static final int JPEG_HEADER_OK = 1;
/*      */   static final int JPEG_HEADER_TABLES_ONLY = 2;
/*      */   static final int DECOMPRESS_DATA = 0;
/*      */   static final int DECOMPRESS_SMOOTH_DATA = 1;
/*      */   static final int DECOMPRESS_ONEPASS = 2;
/*      */   static final int CONSUME_DATA = 0;
/*      */   static final int DUMMY_CONSUME_DATA = 1;
/*      */   static final int PROCESS_DATA_SIMPLE_MAIN = 0;
/*      */   static final int PROCESS_DATA_CONTEXT_MAIN = 1;
/*      */   static final int PROCESS_DATA_CRANK_POST = 2;
/*      */   static final int POST_PROCESS_1PASS = 0;
/*      */   static final int POST_PROCESS_DATA_UPSAMPLE = 1;
/*      */   static final int NULL_CONVERT = 0;
/*      */   static final int GRAYSCALE_CONVERT = 1;
/*      */   static final int YCC_RGB_CONVERT = 2;
/*      */   static final int GRAY_RGB_CONVERT = 3;
/*      */   static final int YCCK_CMYK_CONVERT = 4;
/*      */   static final int NOOP_UPSAMPLE = 0;
/*      */   static final int FULLSIZE_UPSAMPLE = 1;
/*      */   static final int H2V1_FANCY_UPSAMPLE = 2;
/*      */   static final int H2V1_UPSAMPLE = 3;
/*      */   static final int H2V2_FANCY_UPSAMPLE = 4;
/*      */   static final int H2V2_UPSAMPLE = 5;
/*      */   static final int INT_UPSAMPLE = 6;
/*      */   static final int INPUT_CONSUME_INPUT = 0;
/*      */   static final int COEF_CONSUME_INPUT = 1;
/*  201 */   static int[] extend_test = { 0, 1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024, 2048, 4096, 8192, 16384 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  207 */   static int[] extend_offset = { 0, -1, -3, -7, -15, -31, -63, -127, 65281, 65025, 64513, 63489, 61441, 57345, 49153, 32769 };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  215 */   static int[] jpeg_natural_order = { 0, 1, 8, 16, 9, 2, 3, 10, 17, 24, 32, 25, 18, 11, 4, 5, 12, 19, 26, 33, 40, 48, 41, 34, 27, 20, 13, 6, 7, 14, 21, 28, 35, 42, 49, 56, 57, 50, 43, 36, 29, 22, 15, 23, 30, 37, 44, 51, 58, 59, 52, 45, 38, 31, 39, 46, 53, 60, 61, 54, 47, 55, 62, 63, 63, 63, 63, 63, 63, 63, 63, 63, 63, 63, 63, 63, 63, 63, 63, 63 };
/*      */   
/*      */ 
/*      */ 
/*      */   static final int CONST_BITS = 13;
/*      */   
/*      */ 
/*      */ 
/*      */   static final int PASS1_BITS = 2;
/*      */   
/*      */ 
/*      */ 
/*      */   static final int RANGE_MASK = 1023;
/*      */   
/*      */ 
/*      */ 
/*      */   static final class JQUANT_TBL
/*      */   {
/*  233 */     short[] quantval = new short[64];
/*      */     
/*      */ 
/*      */ 
/*      */     boolean sent_table;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   static final class JHUFF_TBL
/*      */   {
/*  244 */     byte[] bits = new byte[17];
/*      */     
/*  246 */     byte[] huffval = new byte['Ā'];
/*      */     
/*      */     boolean sent_table;
/*      */   }
/*      */   
/*      */ 
/*      */   static final class bitread_perm_state
/*      */   {
/*      */     int get_buffer;
/*      */     
/*      */     int bits_left;
/*      */   }
/*      */   
/*      */ 
/*      */   static final class bitread_working_state
/*      */   {
/*      */     byte[] buffer;
/*      */     
/*      */     int bytes_offset;
/*      */     
/*      */     int bytes_in_buffer;
/*      */     
/*      */     int get_buffer;
/*      */     
/*      */     int bits_left;
/*      */     JPEGDecoder.jpeg_decompress_struct cinfo;
/*      */   }
/*      */   
/*      */   static final class savable_state
/*      */   {
/*      */     int EOBRUN;
/*  277 */     int[] last_dc_val = new int[4];
/*      */   }
/*      */   
/*      */   static final class d_derived_tbl
/*      */   {
/*  282 */     int[] maxcode = new int[18];
/*      */     
/*  284 */     int[] valoffset = new int[17];
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     JPEGDecoder.JHUFF_TBL pub;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  298 */     int[] look_nbits = new int['Ā'];
/*  299 */     byte[] look_sym = new byte['Ā'];
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   static final class jpeg_d_coef_controller
/*      */   {
/*      */     int consume_data;
/*      */     
/*      */ 
/*      */ 
/*      */     int decompress_data;
/*      */     
/*      */ 
/*      */     short[][][] coef_arrays;
/*      */     
/*      */ 
/*      */     int MCU_ctr;
/*      */     
/*      */ 
/*      */     int MCU_vert_offset;
/*      */     
/*      */ 
/*      */     int MCU_rows_per_iMCU_row;
/*      */     
/*      */ 
/*  326 */     short[][] MCU_buffer = new short[10][];
/*      */     
/*      */ 
/*  329 */     short[][][][] whole_image = new short[10][][][];
/*      */     
/*      */     int[] coef_bits_latch;
/*      */     
/*      */     short[] workspace;
/*      */     
/*      */     void start_input_pass(JPEGDecoder.jpeg_decompress_struct cinfo)
/*      */     {
/*  337 */       cinfo.input_iMCU_row = 0;
/*  338 */       start_iMCU_row(cinfo);
/*      */     }
/*      */     
/*      */     void start_iMCU_row(JPEGDecoder.jpeg_decompress_struct cinfo)
/*      */     {
/*  343 */       jpeg_d_coef_controller coef = cinfo.coef;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  349 */       if (cinfo.comps_in_scan > 1) {
/*  350 */         coef.MCU_rows_per_iMCU_row = 1;
/*      */       }
/*  352 */       else if (cinfo.input_iMCU_row < cinfo.total_iMCU_rows - 1) {
/*  353 */         coef.MCU_rows_per_iMCU_row = cinfo.cur_comp_info[0].v_samp_factor;
/*      */       } else {
/*  355 */         coef.MCU_rows_per_iMCU_row = cinfo.cur_comp_info[0].last_row_height;
/*      */       }
/*      */       
/*  358 */       coef.MCU_ctr = 0;
/*  359 */       coef.MCU_vert_offset = 0;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   static abstract class jpeg_entropy_decoder
/*      */   {
/*      */     boolean insufficient_data;
/*      */     
/*      */ 
/*      */     abstract void start_pass(JPEGDecoder.jpeg_decompress_struct paramjpeg_decompress_struct);
/*      */     
/*      */ 
/*  372 */     JPEGDecoder.bitread_working_state br_state_local = new JPEGDecoder.bitread_working_state();
/*  373 */     JPEGDecoder.savable_state state_local = new JPEGDecoder.savable_state();
/*      */     
/*      */     abstract boolean decode_mcu(JPEGDecoder.jpeg_decompress_struct paramjpeg_decompress_struct, short[][] paramArrayOfShort); }
/*      */   
/*  377 */   static final class huff_entropy_decoder extends JPEGDecoder.jpeg_entropy_decoder { JPEGDecoder.bitread_perm_state bitstate = new JPEGDecoder.bitread_perm_state();
/*  378 */     JPEGDecoder.savable_state saved = new JPEGDecoder.savable_state();
/*      */     
/*      */ 
/*      */     int restarts_to_go;
/*      */     
/*      */ 
/*  384 */     JPEGDecoder.d_derived_tbl[] dc_derived_tbls = new JPEGDecoder.d_derived_tbl[4];
/*  385 */     JPEGDecoder.d_derived_tbl[] ac_derived_tbls = new JPEGDecoder.d_derived_tbl[4];
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  390 */     JPEGDecoder.d_derived_tbl[] dc_cur_tbls = new JPEGDecoder.d_derived_tbl[10];
/*  391 */     JPEGDecoder.d_derived_tbl[] ac_cur_tbls = new JPEGDecoder.d_derived_tbl[10];
/*      */     
/*  393 */     boolean[] dc_needed = new boolean[10];
/*  394 */     boolean[] ac_needed = new boolean[10];
/*      */     
/*      */     void start_pass(JPEGDecoder.jpeg_decompress_struct cinfo)
/*      */     {
/*  398 */       start_pass_huff_decoder(cinfo);
/*      */     }
/*      */     
/*      */     boolean decode_mcu(JPEGDecoder.jpeg_decompress_struct cinfo, short[][] MCU_data)
/*      */     {
/*  403 */       huff_entropy_decoder entropy = this;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  410 */       JPEGDecoder.bitread_working_state br_state = this.br_state_local;
/*  411 */       JPEGDecoder.savable_state state = this.state_local;
/*      */       
/*      */ 
/*  414 */       if ((cinfo.restart_interval != 0) && 
/*  415 */         (entropy.restarts_to_go == 0) && 
/*  416 */         (!process_restart(cinfo))) {
/*  417 */         return false;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  423 */       if (!entropy.insufficient_data)
/*      */       {
/*      */ 
/*      */ 
/*  427 */         br_state.cinfo = cinfo;
/*  428 */         br_state.buffer = cinfo.buffer;
/*  429 */         br_state.bytes_in_buffer = cinfo.bytes_in_buffer;
/*  430 */         br_state.bytes_offset = cinfo.bytes_offset;
/*  431 */         int get_buffer = entropy.bitstate.get_buffer;
/*  432 */         int bits_left = entropy.bitstate.bits_left;
/*      */         
/*      */ 
/*  435 */         state.last_dc_val[0] = entropy.saved.last_dc_val[0];
/*  436 */         state.last_dc_val[1] = entropy.saved.last_dc_val[1];
/*  437 */         state.last_dc_val[2] = entropy.saved.last_dc_val[2];
/*  438 */         state.last_dc_val[3] = entropy.saved.last_dc_val[3];
/*      */         
/*      */ 
/*      */ 
/*  442 */         for (int blkn = 0; blkn < cinfo.blocks_in_MCU; blkn++) {
/*  443 */           short[] block = MCU_data[blkn];
/*  444 */           JPEGDecoder.d_derived_tbl dctbl = entropy.dc_cur_tbls[blkn];
/*  445 */           JPEGDecoder.d_derived_tbl actbl = entropy.ac_cur_tbls[blkn];
/*  446 */           int s = 0;
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  453 */           int nb = 0;
/*  454 */           if (bits_left < 8) {
/*  455 */             if (!JPEGDecoder.jpeg_fill_bit_buffer(br_state, get_buffer, bits_left, 0)) {
/*  456 */               return false;
/*      */             }
/*  458 */             get_buffer = br_state.get_buffer;bits_left = br_state.bits_left;
/*  459 */             if (bits_left < 8) {
/*  460 */               nb = 1;
/*      */               
/*  462 */               if ((s = JPEGDecoder.jpeg_huff_decode(br_state, get_buffer, bits_left, dctbl, nb)) < 0) {
/*  463 */                 return false;
/*      */               }
/*  465 */               get_buffer = br_state.get_buffer;bits_left = br_state.bits_left;
/*      */             }
/*      */           }
/*      */           
/*  469 */           if (nb != 1) {
/*  470 */             int look = get_buffer >> bits_left - 8 & 0xFF;
/*  471 */             if ((nb = dctbl.look_nbits[look]) != 0)
/*      */             {
/*  473 */               bits_left -= nb;
/*  474 */               s = dctbl.look_sym[look] & 0xFF;
/*      */             } else {
/*  476 */               nb = 9;
/*      */               
/*  478 */               if ((s = JPEGDecoder.jpeg_huff_decode(br_state, get_buffer, bits_left, dctbl, nb)) < 0) {
/*  479 */                 return false;
/*      */               }
/*  481 */               get_buffer = br_state.get_buffer;bits_left = br_state.bits_left;
/*      */             }
/*      */           }
/*      */           
/*      */ 
/*  486 */           if (s != 0)
/*      */           {
/*      */ 
/*  489 */             if (bits_left < s) {
/*  490 */               if (!JPEGDecoder.jpeg_fill_bit_buffer(br_state, get_buffer, bits_left, s)) {
/*  491 */                 return false;
/*      */               }
/*  493 */               get_buffer = br_state.get_buffer;bits_left = br_state.bits_left;
/*      */             }
/*      */             
/*      */ 
/*  497 */             int r = get_buffer >> bits_left -= s & (1 << s) - 1;
/*      */             
/*  499 */             s = r < JPEGDecoder.extend_test[s] ? r + JPEGDecoder.extend_offset[s] : r;
/*      */           }
/*      */           
/*  502 */           if (entropy.dc_needed[blkn] != 0)
/*      */           {
/*  504 */             int ci = cinfo.MCU_membership[blkn];
/*  505 */             s += state.last_dc_val[ci];
/*  506 */             state.last_dc_val[ci] = s;
/*      */             
/*  508 */             block[0] = ((short)s);
/*      */           }
/*      */           
/*  511 */           if (entropy.ac_needed[blkn] != 0)
/*      */           {
/*      */ 
/*      */ 
/*  515 */             for (int k = 1; k < 64; k++)
/*      */             {
/*      */ 
/*  518 */               int nb = 0;
/*  519 */               if (bits_left < 8) {
/*  520 */                 if (!JPEGDecoder.jpeg_fill_bit_buffer(br_state, get_buffer, bits_left, 0)) {
/*  521 */                   return false;
/*      */                 }
/*  523 */                 get_buffer = br_state.get_buffer;bits_left = br_state.bits_left;
/*  524 */                 if (bits_left < 8) {
/*  525 */                   nb = 1;
/*      */                   
/*  527 */                   if ((s = JPEGDecoder.jpeg_huff_decode(br_state, get_buffer, bits_left, actbl, nb)) < 0) {
/*  528 */                     return false;
/*      */                   }
/*  530 */                   get_buffer = br_state.get_buffer;bits_left = br_state.bits_left;
/*      */                 }
/*      */               }
/*  533 */               if (nb != 1)
/*      */               {
/*  535 */                 int look = get_buffer >> bits_left - 8 & 0xFF;
/*  536 */                 if ((nb = actbl.look_nbits[look]) != 0)
/*      */                 {
/*  538 */                   bits_left -= nb;
/*  539 */                   s = actbl.look_sym[look] & 0xFF;
/*      */                 } else {
/*  541 */                   nb = 9;
/*      */                   
/*  543 */                   if ((s = JPEGDecoder.jpeg_huff_decode(br_state, get_buffer, bits_left, actbl, nb)) < 0) {
/*  544 */                     return false;
/*      */                   }
/*  546 */                   get_buffer = br_state.get_buffer;bits_left = br_state.bits_left;
/*      */                 }
/*      */               }
/*      */               
/*  550 */               int r = s >> 4;
/*  551 */               s &= 0xF;
/*      */               
/*  553 */               if (s != 0) {
/*  554 */                 k += r;
/*      */                 
/*      */ 
/*  557 */                 if (bits_left < s) {
/*  558 */                   if (!JPEGDecoder.jpeg_fill_bit_buffer(br_state, get_buffer, bits_left, s)) {
/*  559 */                     return false;
/*      */                   }
/*  561 */                   get_buffer = br_state.get_buffer;
/*  562 */                   bits_left = br_state.bits_left;
/*      */                 }
/*      */                 
/*      */ 
/*  566 */                 r = get_buffer >> bits_left -= s & (1 << s) - 1;
/*      */                 
/*  568 */                 s = r < JPEGDecoder.extend_test[s] ? r + JPEGDecoder.extend_offset[s] : r;
/*      */                 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  576 */                 block[JPEGDecoder.jpeg_natural_order[k]] = ((short)s);
/*      */               } else {
/*  578 */                 if (r != 15)
/*      */                   break;
/*  580 */                 k += 15;
/*      */               }
/*      */             }
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*  588 */           for (int k = 1; k < 64; k++)
/*      */           {
/*      */ 
/*  591 */             int nb = 0;
/*  592 */             if (bits_left < 8) {
/*  593 */               if (!JPEGDecoder.jpeg_fill_bit_buffer(br_state, get_buffer, bits_left, 0)) {
/*  594 */                 return false;
/*      */               }
/*  596 */               get_buffer = br_state.get_buffer;bits_left = br_state.bits_left;
/*  597 */               if (bits_left < 8) {
/*  598 */                 nb = 1;
/*      */                 
/*  600 */                 if ((s = JPEGDecoder.jpeg_huff_decode(br_state, get_buffer, bits_left, actbl, nb)) < 0) {
/*  601 */                   return false;
/*      */                 }
/*  603 */                 get_buffer = br_state.get_buffer;bits_left = br_state.bits_left;
/*      */               }
/*      */             }
/*  606 */             if (nb != 1)
/*      */             {
/*  608 */               int look = get_buffer >> bits_left - 8 & 0xFF;
/*  609 */               if ((nb = actbl.look_nbits[look]) != 0)
/*      */               {
/*  611 */                 bits_left -= nb;
/*  612 */                 s = actbl.look_sym[look] & 0xFF;
/*      */               } else {
/*  614 */                 nb = 9;
/*      */                 
/*  616 */                 if ((s = JPEGDecoder.jpeg_huff_decode(br_state, get_buffer, bits_left, actbl, nb)) < 0) {
/*  617 */                   return false;
/*      */                 }
/*  619 */                 get_buffer = br_state.get_buffer;bits_left = br_state.bits_left;
/*      */               }
/*      */             }
/*      */             
/*  623 */             int r = s >> 4;
/*  624 */             s &= 0xF;
/*      */             
/*  626 */             if (s != 0) {
/*  627 */               k += r;
/*      */               
/*      */ 
/*  630 */               if (bits_left < s) {
/*  631 */                 if (!JPEGDecoder.jpeg_fill_bit_buffer(br_state, get_buffer, bits_left, s)) {
/*  632 */                   return false;
/*      */                 }
/*  634 */                 get_buffer = br_state.get_buffer;bits_left = br_state.bits_left;
/*      */               }
/*      */               
/*      */ 
/*  638 */               bits_left -= s;
/*      */             } else {
/*  640 */               if (r != 15)
/*      */                 break;
/*  642 */               k += 15;
/*      */             }
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  651 */         cinfo.buffer = br_state.buffer;
/*  652 */         cinfo.bytes_in_buffer = br_state.bytes_in_buffer;
/*  653 */         cinfo.bytes_offset = br_state.bytes_offset;
/*  654 */         entropy.bitstate.get_buffer = get_buffer;
/*  655 */         entropy.bitstate.bits_left = bits_left;
/*      */         
/*  657 */         entropy.saved.last_dc_val[0] = state.last_dc_val[0];
/*  658 */         entropy.saved.last_dc_val[1] = state.last_dc_val[1];
/*  659 */         entropy.saved.last_dc_val[2] = state.last_dc_val[2];
/*  660 */         entropy.saved.last_dc_val[3] = state.last_dc_val[3];
/*      */       }
/*      */       
/*      */ 
/*  664 */       entropy.restarts_to_go -= 1;
/*      */       
/*  666 */       return true;
/*      */     }
/*      */     
/*      */     void start_pass_huff_decoder(JPEGDecoder.jpeg_decompress_struct cinfo) {
/*  670 */       huff_entropy_decoder entropy = this;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  678 */       if ((cinfo.Ss == 0) && (cinfo.Se == 63) && (cinfo.Ah == 0) && (cinfo.Al != 0)) {}
/*      */       
/*      */ 
/*      */ 
/*  682 */       for (int ci = 0; ci < cinfo.comps_in_scan; ci++) {
/*  683 */         JPEGDecoder.jpeg_component_info compptr = cinfo.cur_comp_info[ci];
/*  684 */         int dctbl = compptr.dc_tbl_no;
/*  685 */         int actbl = compptr.ac_tbl_no;
/*      */         
/*      */ 
/*  688 */         JPEGDecoder.jpeg_make_d_derived_tbl(cinfo, true, dctbl, entropy.dc_derived_tbls[dctbl] = new JPEGDecoder.d_derived_tbl());
/*  689 */         JPEGDecoder.jpeg_make_d_derived_tbl(cinfo, false, actbl, entropy.ac_derived_tbls[actbl] = new JPEGDecoder.d_derived_tbl());
/*      */         
/*  691 */         entropy.saved.last_dc_val[ci] = 0;
/*      */       }
/*      */       
/*      */ 
/*  695 */       for (int blkn = 0; blkn < cinfo.blocks_in_MCU; blkn++) {
/*  696 */         ci = cinfo.MCU_membership[blkn];
/*  697 */         JPEGDecoder.jpeg_component_info compptr = cinfo.cur_comp_info[ci];
/*      */         
/*  699 */         entropy.dc_cur_tbls[blkn] = entropy.dc_derived_tbls[compptr.dc_tbl_no];
/*  700 */         entropy.ac_cur_tbls[blkn] = entropy.ac_derived_tbls[compptr.ac_tbl_no];
/*      */         
/*  702 */         if (compptr.component_needed) {
/*  703 */           entropy.dc_needed[blkn] = true;
/*      */           
/*  705 */           entropy.ac_needed[blkn] = (compptr.DCT_scaled_size > 1 ? 1 : false);
/*      */         } else {
/*  707 */           entropy.dc_needed[blkn] = (entropy.ac_needed[blkn] = 0);
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*  712 */       entropy.bitstate.bits_left = 0;
/*  713 */       entropy.bitstate.get_buffer = 0;
/*  714 */       entropy.insufficient_data = false;
/*      */       
/*      */ 
/*  717 */       entropy.restarts_to_go = cinfo.restart_interval;
/*      */     }
/*      */     
/*      */     boolean process_restart(JPEGDecoder.jpeg_decompress_struct cinfo) {
/*  721 */       huff_entropy_decoder entropy = this;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  726 */       cinfo.marker.discarded_bytes += entropy.bitstate.bits_left / 8;
/*  727 */       entropy.bitstate.bits_left = 0;
/*      */       
/*      */ 
/*  730 */       if (!JPEGDecoder.read_restart_marker(cinfo)) {
/*  731 */         return false;
/*      */       }
/*      */       
/*  734 */       for (int ci = 0; ci < cinfo.comps_in_scan; ci++) {
/*  735 */         entropy.saved.last_dc_val[ci] = 0;
/*      */       }
/*      */       
/*  738 */       entropy.restarts_to_go = cinfo.restart_interval;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  745 */       if (cinfo.unread_marker == 0) {
/*  746 */         entropy.insufficient_data = false;
/*      */       }
/*  748 */       return true;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   static final class phuff_entropy_decoder
/*      */     extends JPEGDecoder.jpeg_entropy_decoder
/*      */   {
/*  757 */     JPEGDecoder.bitread_perm_state bitstate = new JPEGDecoder.bitread_perm_state();
/*  758 */     JPEGDecoder.savable_state saved = new JPEGDecoder.savable_state();
/*      */     
/*      */ 
/*      */     int restarts_to_go;
/*      */     
/*      */ 
/*  764 */     JPEGDecoder.d_derived_tbl[] derived_tbls = new JPEGDecoder.d_derived_tbl[4];
/*      */     
/*      */     JPEGDecoder.d_derived_tbl ac_derived_tbl;
/*      */     
/*  768 */     int[] newnz_pos = new int[64];
/*      */     
/*      */     void start_pass(JPEGDecoder.jpeg_decompress_struct cinfo)
/*      */     {
/*  772 */       start_pass_phuff_decoder(cinfo);
/*      */     }
/*      */     
/*      */     boolean decode_mcu(JPEGDecoder.jpeg_decompress_struct cinfo, short[][] MCU_data)
/*      */     {
/*  777 */       boolean is_DC_band = cinfo.Ss == 0;
/*  778 */       if (cinfo.Ah == 0) {
/*  779 */         if (is_DC_band) {
/*  780 */           return decode_mcu_DC_first(cinfo, MCU_data);
/*      */         }
/*  782 */         return decode_mcu_AC_first(cinfo, MCU_data);
/*      */       }
/*  784 */       if (is_DC_band) {
/*  785 */         return decode_mcu_DC_refine(cinfo, MCU_data);
/*      */       }
/*  787 */       return decode_mcu_AC_refine(cinfo, MCU_data);
/*      */     }
/*      */     
/*      */     boolean decode_mcu_DC_refine(JPEGDecoder.jpeg_decompress_struct cinfo, short[][] MCU_data)
/*      */     {
/*  792 */       phuff_entropy_decoder entropy = this;
/*  793 */       int p1 = 1 << cinfo.Al;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  800 */       JPEGDecoder.bitread_working_state br_state = this.br_state_local;
/*      */       
/*      */ 
/*  803 */       if ((cinfo.restart_interval != 0) && 
/*  804 */         (entropy.restarts_to_go == 0) && 
/*  805 */         (!process_restart(cinfo))) {
/*  806 */         return false;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  815 */       br_state.cinfo = cinfo;
/*  816 */       br_state.buffer = cinfo.buffer;
/*  817 */       br_state.bytes_in_buffer = cinfo.bytes_in_buffer;
/*  818 */       br_state.bytes_offset = cinfo.bytes_offset;
/*  819 */       int get_buffer = entropy.bitstate.get_buffer;
/*  820 */       int bits_left = entropy.bitstate.bits_left;
/*      */       
/*      */ 
/*      */ 
/*  824 */       for (int blkn = 0; blkn < cinfo.blocks_in_MCU; blkn++) {
/*  825 */         short[] block = MCU_data[blkn];
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*  830 */         if (bits_left < 1) {
/*  831 */           if (!JPEGDecoder.jpeg_fill_bit_buffer(br_state, get_buffer, bits_left, 1)) {
/*  832 */             return false;
/*      */           }
/*  834 */           get_buffer = br_state.get_buffer;bits_left = br_state.bits_left;
/*      */         }
/*      */         
/*      */ 
/*  838 */         if ((get_buffer >> --bits_left & 0x1) != 0) {
/*  839 */           int tmp160_159 = 0; short[] tmp160_157 = block;tmp160_157[tmp160_159] = ((short)(tmp160_157[tmp160_159] | p1));
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  845 */       cinfo.buffer = br_state.buffer;
/*  846 */       cinfo.bytes_in_buffer = br_state.bytes_in_buffer;
/*  847 */       cinfo.bytes_offset = br_state.bytes_offset;
/*  848 */       entropy.bitstate.get_buffer = get_buffer;
/*  849 */       entropy.bitstate.bits_left = bits_left;
/*      */       
/*      */ 
/*  852 */       entropy.restarts_to_go -= 1;
/*      */       
/*  854 */       return true;
/*      */     }
/*      */     
/*      */     boolean decode_mcu_AC_refine(JPEGDecoder.jpeg_decompress_struct cinfo, short[][] MCU_data)
/*      */     {
/*  859 */       phuff_entropy_decoder entropy = this;
/*  860 */       int Se = cinfo.Se;
/*  861 */       int p1 = 1 << cinfo.Al;
/*  862 */       int m1 = -1 << cinfo.Al;
/*  863 */       int s = 0;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  871 */       JPEGDecoder.bitread_working_state br_state = this.br_state_local;
/*      */       
/*      */ 
/*      */ 
/*  875 */       int[] newnz_pos = entropy.newnz_pos;
/*      */       
/*      */ 
/*  878 */       if ((cinfo.restart_interval != 0) && 
/*  879 */         (entropy.restarts_to_go == 0) && 
/*  880 */         (!process_restart(cinfo))) {
/*  881 */         return false;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*  886 */       if (!entropy.insufficient_data)
/*      */       {
/*      */ 
/*      */ 
/*  890 */         br_state.cinfo = cinfo;
/*  891 */         br_state.buffer = cinfo.buffer;
/*  892 */         br_state.bytes_in_buffer = cinfo.bytes_in_buffer;
/*  893 */         br_state.bytes_offset = cinfo.bytes_offset;
/*  894 */         int get_buffer = entropy.bitstate.get_buffer;
/*  895 */         int bits_left = entropy.bitstate.bits_left;
/*      */         
/*  897 */         int EOBRUN = entropy.saved.EOBRUN;
/*      */         
/*      */ 
/*  900 */         short[] block = MCU_data[0];
/*  901 */         JPEGDecoder.d_derived_tbl tbl = entropy.ac_derived_tbl;
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  909 */         int num_newnz = 0;
/*      */         
/*      */ 
/*  912 */         int k = cinfo.Ss;
/*      */         
/*  914 */         if (EOBRUN == 0) {
/*  915 */           for (; k <= Se; k++)
/*      */           {
/*      */ 
/*  918 */             int nb = 0;
/*  919 */             if (bits_left < 8) {
/*  920 */               if (!JPEGDecoder.jpeg_fill_bit_buffer(br_state, get_buffer, bits_left, 0))
/*      */               {
/*  922 */                 while (num_newnz > 0) {
/*  923 */                   block[newnz_pos[(--num_newnz)]] = 0;
/*      */                 }
/*  925 */                 return false;
/*      */               }
/*  927 */               get_buffer = br_state.get_buffer;bits_left = br_state.bits_left;
/*  928 */               if (bits_left < 8) {
/*  929 */                 nb = 1;
/*      */                 
/*  931 */                 if ((s = JPEGDecoder.jpeg_huff_decode(br_state, get_buffer, bits_left, tbl, nb)) < 0)
/*      */                 {
/*  933 */                   while (num_newnz > 0) {
/*  934 */                     block[newnz_pos[(--num_newnz)]] = 0;
/*      */                   }
/*  936 */                   return false;
/*      */                 }
/*  938 */                 get_buffer = br_state.get_buffer;bits_left = br_state.bits_left;
/*      */               }
/*      */             }
/*  941 */             if (nb != 1)
/*      */             {
/*  943 */               int look = get_buffer >> bits_left - 8 & 0xFF;
/*  944 */               if ((nb = tbl.look_nbits[look]) != 0)
/*      */               {
/*  946 */                 bits_left -= nb;
/*  947 */                 s = tbl.look_sym[look] & 0xFF;
/*      */               } else {
/*  949 */                 nb = 9;
/*      */                 
/*  951 */                 if ((s = JPEGDecoder.jpeg_huff_decode(br_state, get_buffer, bits_left, tbl, nb)) < 0)
/*      */                 {
/*  953 */                   while (num_newnz > 0) {
/*  954 */                     block[newnz_pos[(--num_newnz)]] = 0;
/*      */                   }
/*  956 */                   return false;
/*      */                 }
/*  958 */                 get_buffer = br_state.get_buffer;bits_left = br_state.bits_left;
/*      */               }
/*      */             }
/*      */             
/*  962 */             int r = s >> 4;
/*  963 */             s &= 0xF;
/*  964 */             if (s != 0) {
/*  965 */               if ((s == 1) || 
/*      */               
/*      */ 
/*      */ 
/*      */ 
/*  970 */                 (bits_left < 1)) {
/*  971 */                 if (!JPEGDecoder.jpeg_fill_bit_buffer(br_state, get_buffer, bits_left, 1))
/*      */                 {
/*  973 */                   while (num_newnz > 0) {
/*  974 */                     block[newnz_pos[(--num_newnz)]] = 0;
/*      */                   }
/*  976 */                   return false;
/*      */                 }
/*  978 */                 get_buffer = br_state.get_buffer;bits_left = br_state.bits_left;
/*      */               }
/*      */               
/*      */ 
/*  982 */               if ((get_buffer >> --bits_left & 0x1) != 0) {
/*  983 */                 s = p1;
/*      */               } else {
/*  985 */                 s = m1;
/*      */               }
/*  987 */             } else if (r != 15) {
/*  988 */               EOBRUN = 1 << r;
/*  989 */               if (r == 0) {
/*      */                 break;
/*      */               }
/*  992 */               if (bits_left < r) {
/*  993 */                 if (!JPEGDecoder.jpeg_fill_bit_buffer(br_state, get_buffer, bits_left, r))
/*      */                 {
/*  995 */                   while (num_newnz > 0) {
/*  996 */                     block[newnz_pos[(--num_newnz)]] = 0;
/*      */                   }
/*  998 */                   return false;
/*      */                 }
/* 1000 */                 get_buffer = br_state.get_buffer;bits_left = br_state.bits_left;
/*      */               }
/*      */               
/*      */ 
/* 1004 */               r = get_buffer >> bits_left -= r & (1 << r) - 1;
/* 1005 */               EOBRUN += r; break;
/*      */             }
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             do
/*      */             {
/* 1016 */               short[] thiscoef = block;
/* 1017 */               int thiscoef_offset = JPEGDecoder.jpeg_natural_order[k];
/* 1018 */               if (thiscoef[thiscoef_offset] != 0)
/*      */               {
/*      */ 
/* 1021 */                 if (bits_left < 1) {
/* 1022 */                   if (!JPEGDecoder.jpeg_fill_bit_buffer(br_state, get_buffer, bits_left, 1))
/*      */                   {
/* 1024 */                     while (num_newnz > 0) {
/* 1025 */                       block[newnz_pos[(--num_newnz)]] = 0;
/*      */                     }
/* 1027 */                     return false;
/*      */                   }
/* 1029 */                   get_buffer = br_state.get_buffer;bits_left = br_state.bits_left;
/*      */                 }
/*      */                 
/*      */ 
/* 1033 */                 if (((get_buffer >> --bits_left & 0x1) != 0) && 
/* 1034 */                   ((thiscoef[thiscoef_offset] & p1) == 0)) {
/* 1035 */                   if (thiscoef[thiscoef_offset] >= 0) {
/* 1036 */                     int tmp725_723 = thiscoef_offset; short[] tmp725_721 = thiscoef;tmp725_721[tmp725_723] = ((short)(tmp725_721[tmp725_723] + p1));
/*      */                   } else {
/* 1038 */                     int tmp739_737 = thiscoef_offset; short[] tmp739_735 = thiscoef;tmp739_735[tmp739_737] = ((short)(tmp739_735[tmp739_737] + m1));
/*      */                   }
/*      */                 }
/*      */               } else {
/* 1042 */                 r--; if (r < 0)
/*      */                   break;
/*      */               }
/* 1045 */               k++;
/* 1046 */             } while (k <= Se);
/* 1047 */             if (s != 0) {
/* 1048 */               int pos = JPEGDecoder.jpeg_natural_order[k];
/*      */               
/* 1050 */               block[pos] = ((short)s);
/*      */               
/* 1052 */               newnz_pos[(num_newnz++)] = pos;
/*      */             }
/*      */           }
/*      */         }
/*      */         
/* 1057 */         if (EOBRUN > 0)
/*      */         {
/* 1063 */           for (; 
/*      */               
/*      */ 
/*      */ 
/* 1063 */               k <= Se; k++) {
/* 1064 */             short[] thiscoef = block;
/* 1065 */             int thiscoef_offset = JPEGDecoder.jpeg_natural_order[k];
/* 1066 */             if (thiscoef[thiscoef_offset] != 0)
/*      */             {
/*      */ 
/* 1069 */               if (bits_left < 1) {
/* 1070 */                 if (!JPEGDecoder.jpeg_fill_bit_buffer(br_state, get_buffer, bits_left, 1))
/*      */                 {
/* 1072 */                   while (num_newnz > 0) {
/* 1073 */                     block[newnz_pos[(--num_newnz)]] = 0;
/*      */                   }
/* 1075 */                   return false;
/*      */                 }
/* 1077 */                 get_buffer = br_state.get_buffer;bits_left = br_state.bits_left;
/*      */               }
/*      */               
/*      */ 
/* 1081 */               if (((get_buffer >> --bits_left & 0x1) != 0) && 
/* 1082 */                 ((thiscoef[thiscoef_offset] & p1) == 0)) {
/* 1083 */                 if (thiscoef[thiscoef_offset] >= 0) {
/* 1084 */                   int tmp930_928 = thiscoef_offset; short[] tmp930_926 = thiscoef;tmp930_926[tmp930_928] = ((short)(tmp930_926[tmp930_928] + p1));
/*      */                 } else {
/* 1086 */                   int tmp944_942 = thiscoef_offset; short[] tmp944_940 = thiscoef;tmp944_940[tmp944_942] = ((short)(tmp944_940[tmp944_942] + m1));
/*      */                 }
/*      */               }
/*      */             }
/*      */           }
/*      */           
/* 1092 */           EOBRUN--;
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 1097 */         cinfo.buffer = br_state.buffer;
/* 1098 */         cinfo.bytes_in_buffer = br_state.bytes_in_buffer;
/* 1099 */         cinfo.bytes_offset = br_state.bytes_offset;
/* 1100 */         entropy.bitstate.get_buffer = get_buffer;
/* 1101 */         entropy.bitstate.bits_left = bits_left;
/*      */         
/* 1103 */         entropy.saved.EOBRUN = EOBRUN;
/*      */       }
/*      */       
/*      */ 
/* 1107 */       entropy.restarts_to_go -= 1;
/*      */       
/* 1109 */       return true;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     boolean decode_mcu_AC_first(JPEGDecoder.jpeg_decompress_struct cinfo, short[][] MCU_data)
/*      */     {
/* 1121 */       phuff_entropy_decoder entropy = this;
/* 1122 */       int Se = cinfo.Se;
/* 1123 */       int Al = cinfo.Al;
/* 1124 */       int s = 0;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1131 */       JPEGDecoder.bitread_working_state br_state = this.br_state_local;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1136 */       if ((cinfo.restart_interval != 0) && 
/* 1137 */         (entropy.restarts_to_go == 0) && 
/* 1138 */         (!process_restart(cinfo))) {
/* 1139 */         return false;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1145 */       if (!entropy.insufficient_data)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/* 1150 */         int EOBRUN = entropy.saved.EOBRUN;
/*      */         
/*      */ 
/*      */ 
/* 1154 */         if (EOBRUN > 0) {
/* 1155 */           EOBRUN--;
/*      */         }
/*      */         else {
/* 1158 */           br_state.cinfo = cinfo;
/* 1159 */           br_state.buffer = cinfo.buffer;
/* 1160 */           br_state.bytes_in_buffer = cinfo.bytes_in_buffer;
/* 1161 */           br_state.bytes_offset = cinfo.bytes_offset;
/* 1162 */           int get_buffer = entropy.bitstate.get_buffer;
/* 1163 */           int bits_left = entropy.bitstate.bits_left;
/*      */           
/* 1165 */           short[] block = MCU_data[0];
/* 1166 */           JPEGDecoder.d_derived_tbl tbl = entropy.ac_derived_tbl;
/*      */           
/* 1168 */           for (int k = cinfo.Ss; k <= Se; k++)
/*      */           {
/*      */ 
/* 1171 */             int nb = 0;
/* 1172 */             if (bits_left < 8) {
/* 1173 */               if (!JPEGDecoder.jpeg_fill_bit_buffer(br_state, get_buffer, bits_left, 0)) {
/* 1174 */                 return false;
/*      */               }
/* 1176 */               get_buffer = br_state.get_buffer;bits_left = br_state.bits_left;
/* 1177 */               if (bits_left < 8) {
/* 1178 */                 nb = 1;
/*      */                 
/* 1180 */                 if ((s = JPEGDecoder.jpeg_huff_decode(br_state, get_buffer, bits_left, tbl, nb)) < 0) {
/* 1181 */                   return false;
/*      */                 }
/* 1183 */                 get_buffer = br_state.get_buffer;bits_left = br_state.bits_left;
/*      */               }
/*      */             }
/* 1186 */             if (nb != 1)
/*      */             {
/* 1188 */               int look = get_buffer >> bits_left - 8 & 0xFF;
/*      */               
/* 1190 */               if ((nb = tbl.look_nbits[look]) != 0)
/*      */               {
/* 1192 */                 bits_left -= nb;
/* 1193 */                 s = tbl.look_sym[look] & 0xFF;
/*      */               } else {
/* 1195 */                 nb = 9;
/*      */                 
/* 1197 */                 if ((s = JPEGDecoder.jpeg_huff_decode(br_state, get_buffer, bits_left, tbl, nb)) < 0) {
/* 1198 */                   return false;
/*      */                 }
/* 1200 */                 get_buffer = br_state.get_buffer;bits_left = br_state.bits_left;
/*      */               }
/*      */             }
/*      */             
/* 1204 */             int r = s >> 4;
/* 1205 */             s &= 0xF;
/* 1206 */             if (s != 0) {
/* 1207 */               k += r;
/*      */               
/*      */ 
/* 1210 */               if (bits_left < s) {
/* 1211 */                 if (!JPEGDecoder.jpeg_fill_bit_buffer(br_state, get_buffer, bits_left, s)) {
/* 1212 */                   return false;
/*      */                 }
/* 1214 */                 get_buffer = br_state.get_buffer;bits_left = br_state.bits_left;
/*      */               }
/*      */               
/*      */ 
/* 1218 */               r = get_buffer >> bits_left -= s & (1 << s) - 1;
/*      */               
/* 1220 */               s = r < JPEGDecoder.extend_test[s] ? r + JPEGDecoder.extend_offset[s] : r;
/*      */               
/* 1222 */               block[JPEGDecoder.jpeg_natural_order[k]] = ((short)(s << Al));
/*      */             }
/* 1224 */             else if (r == 15) {
/* 1225 */               k += 15;
/*      */             } else {
/* 1227 */               EOBRUN = 1 << r;
/* 1228 */               if (r != 0)
/*      */               {
/*      */ 
/* 1231 */                 if (bits_left < r) {
/* 1232 */                   if (!JPEGDecoder.jpeg_fill_bit_buffer(br_state, get_buffer, bits_left, r)) {
/* 1233 */                     return false;
/*      */                   }
/* 1235 */                   get_buffer = br_state.get_buffer;bits_left = br_state.bits_left;
/*      */                 }
/*      */                 
/*      */ 
/* 1239 */                 r = get_buffer >> bits_left -= r & (1 << r) - 1;
/* 1240 */                 EOBRUN += r;
/*      */               }
/* 1242 */               EOBRUN--;
/* 1243 */               break;
/*      */             }
/*      */           }
/*      */           
/*      */ 
/*      */ 
/* 1249 */           cinfo.buffer = br_state.buffer;
/* 1250 */           cinfo.bytes_in_buffer = br_state.bytes_in_buffer;
/* 1251 */           cinfo.bytes_offset = br_state.bytes_offset;
/* 1252 */           entropy.bitstate.get_buffer = get_buffer;
/* 1253 */           entropy.bitstate.bits_left = bits_left;
/*      */         }
/*      */         
/*      */ 
/* 1257 */         entropy.saved.EOBRUN = EOBRUN;
/*      */       }
/*      */       
/*      */ 
/* 1261 */       entropy.restarts_to_go -= 1;
/*      */       
/* 1263 */       return true;
/*      */     }
/*      */     
/*      */     boolean decode_mcu_DC_first(JPEGDecoder.jpeg_decompress_struct cinfo, short[][] MCU_data) {
/* 1267 */       phuff_entropy_decoder entropy = this;
/* 1268 */       int Al = cinfo.Al;
/* 1269 */       int s = 0;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1276 */       JPEGDecoder.bitread_working_state br_state = this.br_state_local;
/*      */       
/*      */ 
/* 1279 */       JPEGDecoder.savable_state state = this.state_local;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1284 */       if ((cinfo.restart_interval != 0) && 
/* 1285 */         (entropy.restarts_to_go == 0) && 
/* 1286 */         (!process_restart(cinfo))) {
/* 1287 */         return false;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1293 */       if (!entropy.insufficient_data)
/*      */       {
/*      */ 
/*      */ 
/* 1297 */         br_state.cinfo = cinfo;
/* 1298 */         br_state.buffer = cinfo.buffer;
/* 1299 */         br_state.bytes_in_buffer = cinfo.bytes_in_buffer;
/* 1300 */         br_state.bytes_offset = cinfo.bytes_offset;
/* 1301 */         int get_buffer = entropy.bitstate.get_buffer;
/* 1302 */         int bits_left = entropy.bitstate.bits_left;
/*      */         
/*      */ 
/* 1305 */         state.EOBRUN = entropy.saved.EOBRUN;
/* 1306 */         state.last_dc_val[0] = entropy.saved.last_dc_val[0];
/* 1307 */         state.last_dc_val[1] = entropy.saved.last_dc_val[1];
/* 1308 */         state.last_dc_val[2] = entropy.saved.last_dc_val[2];
/* 1309 */         state.last_dc_val[3] = entropy.saved.last_dc_val[3];
/*      */         
/*      */ 
/*      */ 
/* 1313 */         for (int blkn = 0; blkn < cinfo.blocks_in_MCU; blkn++) {
/* 1314 */           short[] block = MCU_data[blkn];
/* 1315 */           int ci = cinfo.MCU_membership[blkn];
/* 1316 */           JPEGDecoder.jpeg_component_info compptr = cinfo.cur_comp_info[ci];
/* 1317 */           JPEGDecoder.d_derived_tbl tbl = entropy.derived_tbls[compptr.dc_tbl_no];
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1324 */           int nb = 0;
/* 1325 */           if (bits_left < 8) {
/* 1326 */             if (!JPEGDecoder.jpeg_fill_bit_buffer(br_state, get_buffer, bits_left, 0)) {
/* 1327 */               return false;
/*      */             }
/* 1329 */             get_buffer = br_state.get_buffer;bits_left = br_state.bits_left;
/* 1330 */             if (bits_left < 8) {
/* 1331 */               nb = 1;
/*      */               
/* 1333 */               if ((s = JPEGDecoder.jpeg_huff_decode(br_state, get_buffer, bits_left, tbl, nb)) < 0) {
/* 1334 */                 return false;
/*      */               }
/* 1336 */               get_buffer = br_state.get_buffer;bits_left = br_state.bits_left;
/*      */             }
/*      */           }
/* 1339 */           if (nb != 1)
/*      */           {
/* 1341 */             int look = get_buffer >> bits_left - 8 & 0xFF;
/*      */             
/* 1343 */             if ((nb = tbl.look_nbits[look]) != 0)
/*      */             {
/* 1345 */               bits_left -= nb;
/* 1346 */               s = tbl.look_sym[look] & 0xFF;
/*      */             } else {
/* 1348 */               nb = 9;
/*      */               
/* 1350 */               if ((s = JPEGDecoder.jpeg_huff_decode(br_state, get_buffer, bits_left, tbl, nb)) < 0) {
/* 1351 */                 return false;
/*      */               }
/* 1353 */               get_buffer = br_state.get_buffer;bits_left = br_state.bits_left;
/*      */             }
/*      */           }
/*      */           
/* 1357 */           if (s != 0)
/*      */           {
/*      */ 
/* 1360 */             if (bits_left < s) {
/* 1361 */               if (!JPEGDecoder.jpeg_fill_bit_buffer(br_state, get_buffer, bits_left, s)) {
/* 1362 */                 return false;
/*      */               }
/* 1364 */               get_buffer = br_state.get_buffer;bits_left = br_state.bits_left;
/*      */             }
/*      */             
/*      */ 
/* 1368 */             int r = get_buffer >> bits_left -= s & (1 << s) - 1;
/*      */             
/* 1370 */             s = r < JPEGDecoder.extend_test[s] ? r + JPEGDecoder.extend_offset[s] : r;
/*      */           }
/*      */           
/*      */ 
/* 1374 */           s += state.last_dc_val[ci];
/* 1375 */           state.last_dc_val[ci] = s;
/*      */           
/* 1377 */           block[0] = ((short)(s << Al));
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 1382 */         cinfo.buffer = br_state.buffer;
/* 1383 */         cinfo.bytes_in_buffer = br_state.bytes_in_buffer;
/* 1384 */         cinfo.bytes_offset = br_state.bytes_offset;
/* 1385 */         entropy.bitstate.get_buffer = get_buffer;
/* 1386 */         entropy.bitstate.bits_left = bits_left;
/*      */         
/* 1388 */         entropy.saved.EOBRUN = state.EOBRUN;
/* 1389 */         entropy.saved.last_dc_val[0] = state.last_dc_val[0];
/* 1390 */         entropy.saved.last_dc_val[1] = state.last_dc_val[1];
/* 1391 */         entropy.saved.last_dc_val[2] = state.last_dc_val[2];
/* 1392 */         entropy.saved.last_dc_val[3] = state.last_dc_val[3];
/*      */       }
/*      */       
/*      */ 
/* 1396 */       entropy.restarts_to_go -= 1;
/*      */       
/* 1398 */       return true;
/*      */     }
/*      */     
/*      */     boolean process_restart(JPEGDecoder.jpeg_decompress_struct cinfo) {
/* 1402 */       phuff_entropy_decoder entropy = this;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1407 */       cinfo.marker.discarded_bytes += entropy.bitstate.bits_left / 8;
/* 1408 */       entropy.bitstate.bits_left = 0;
/*      */       
/*      */ 
/* 1411 */       if (!JPEGDecoder.read_restart_marker(cinfo)) {
/* 1412 */         return false;
/*      */       }
/*      */       
/* 1415 */       for (int ci = 0; ci < cinfo.comps_in_scan; ci++) {
/* 1416 */         entropy.saved.last_dc_val[ci] = 0;
/*      */       }
/* 1418 */       entropy.saved.EOBRUN = 0;
/*      */       
/*      */ 
/* 1421 */       entropy.restarts_to_go = cinfo.restart_interval;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1428 */       if (cinfo.unread_marker == 0) {
/* 1429 */         entropy.insufficient_data = false;
/*      */       }
/* 1431 */       return true;
/*      */     }
/*      */     
/*      */     void start_pass_phuff_decoder(JPEGDecoder.jpeg_decompress_struct cinfo) {
/* 1435 */       phuff_entropy_decoder entropy = this;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1441 */       boolean is_DC_band = cinfo.Ss == 0;
/*      */       
/*      */ 
/* 1444 */       boolean bad = false;
/* 1445 */       if (is_DC_band) {
/* 1446 */         if (cinfo.Se != 0) {
/* 1447 */           bad = true;
/*      */         }
/*      */       } else {
/* 1450 */         if ((cinfo.Ss > cinfo.Se) || (cinfo.Se >= 64)) {
/* 1451 */           bad = true;
/*      */         }
/* 1453 */         if (cinfo.comps_in_scan != 1)
/* 1454 */           bad = true;
/*      */       }
/* 1456 */       if (cinfo.Ah != 0)
/*      */       {
/* 1458 */         if (cinfo.Al != cinfo.Ah - 1)
/* 1459 */           bad = true;
/*      */       }
/* 1461 */       if (cinfo.Al > 13) {
/* 1462 */         bad = true;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1469 */       if (bad) {
/* 1470 */         JPEGDecoder.error();
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1476 */       for (int ci = 0; ci < cinfo.comps_in_scan; ci++) {
/* 1477 */         int cindex = cinfo.cur_comp_info[ci].component_index;
/* 1478 */         int[] coef_bit_ptr = cinfo.coef_bits[cindex];
/* 1479 */         if ((!is_DC_band) && (coef_bit_ptr[0] < 0)) {}
/*      */         
/*      */ 
/* 1482 */         for (int coefi = cinfo.Ss; coefi <= cinfo.Se; coefi++) {
/* 1483 */           int expected = coef_bit_ptr[coefi] < 0 ? 0 : coef_bit_ptr[coefi];
/* 1484 */           if (cinfo.Ah != expected) {}
/*      */           
/*      */ 
/* 1487 */           coef_bit_ptr[coefi] = cinfo.Al;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1504 */       for (ci = 0; ci < cinfo.comps_in_scan; ci++) {
/* 1505 */         JPEGDecoder.jpeg_component_info compptr = cinfo.cur_comp_info[ci];
/*      */         
/*      */ 
/*      */ 
/* 1509 */         if (is_DC_band) {
/* 1510 */           if (cinfo.Ah == 0) {
/* 1511 */             int tbl = compptr.dc_tbl_no;
/* 1512 */             JPEGDecoder.jpeg_make_d_derived_tbl(cinfo, true, tbl, entropy.derived_tbls[tbl] = new JPEGDecoder.d_derived_tbl());
/*      */           }
/*      */         } else {
/* 1515 */           int tbl = compptr.ac_tbl_no;
/* 1516 */           JPEGDecoder.jpeg_make_d_derived_tbl(cinfo, false, tbl, entropy.derived_tbls[tbl] = new JPEGDecoder.d_derived_tbl());
/*      */           
/* 1518 */           entropy.ac_derived_tbl = entropy.derived_tbls[tbl];
/*      */         }
/*      */         
/* 1521 */         entropy.saved.last_dc_val[ci] = 0;
/*      */       }
/*      */       
/*      */ 
/* 1525 */       entropy.bitstate.bits_left = 0;
/* 1526 */       entropy.bitstate.get_buffer = 0;
/* 1527 */       entropy.insufficient_data = false;
/*      */       
/*      */ 
/* 1530 */       entropy.saved.EOBRUN = 0;
/*      */       
/*      */ 
/* 1533 */       entropy.restarts_to_go = cinfo.restart_interval;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   static final class jpeg_component_info
/*      */   {
/*      */     int component_id;
/*      */     
/*      */ 
/*      */ 
/*      */     int component_index;
/*      */     
/*      */ 
/*      */     int h_samp_factor;
/*      */     
/*      */ 
/*      */     int v_samp_factor;
/*      */     
/*      */ 
/*      */     int quant_tbl_no;
/*      */     
/*      */ 
/*      */     int dc_tbl_no;
/*      */     
/*      */ 
/*      */     int ac_tbl_no;
/*      */     
/*      */ 
/*      */     int width_in_blocks;
/*      */     
/*      */ 
/*      */     int height_in_blocks;
/*      */     
/*      */ 
/*      */     int DCT_scaled_size;
/*      */     
/*      */ 
/*      */     int downsampled_width;
/*      */     
/*      */ 
/*      */     int downsampled_height;
/*      */     
/*      */ 
/*      */     boolean component_needed;
/*      */     
/*      */ 
/*      */     int MCU_width;
/*      */     
/*      */ 
/*      */     int MCU_height;
/*      */     
/*      */ 
/*      */     int MCU_blocks;
/*      */     
/*      */ 
/*      */     int MCU_sample_width;
/*      */     
/*      */ 
/*      */     int last_col_width;
/*      */     
/*      */ 
/*      */     int last_row_height;
/*      */     
/*      */ 
/*      */     JPEGDecoder.JQUANT_TBL quant_table;
/*      */     
/*      */ 
/*      */     int[] dct_table;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   static final class jpeg_color_quantizer
/*      */   {
/*      */     int[][] sv_colormap;
/*      */     
/*      */ 
/*      */     int sv_actual;
/*      */     
/*      */ 
/*      */     int[][] colorindex;
/*      */     
/*      */ 
/*      */     boolean is_padded;
/*      */     
/*      */ 
/* 1622 */     int[] Ncolors = new int[4];
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     int row_index;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     boolean on_odd_row;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     void start_pass(JPEGDecoder.jpeg_decompress_struct cinfo, boolean is_pre_scan) {}
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final class jpeg_upsampler
/*      */   {
/*      */     boolean need_context_rows;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1656 */     byte[][][] color_buf = new byte[10][][];
/* 1657 */     int[] color_buf_offset = new int[10];
/*      */     
/*      */ 
/* 1660 */     int[] methods = new int[10];
/*      */     
/*      */     int next_row_out;
/*      */     
/*      */     int rows_to_go;
/*      */     
/* 1666 */     int[] rowgroup_height = new int[10];
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1671 */     byte[] h_expand = new byte[10];
/* 1672 */     byte[] v_expand = new byte[10];
/*      */     
/*      */     void start_pass(JPEGDecoder.jpeg_decompress_struct cinfo) {
/* 1675 */       jpeg_upsampler upsample = cinfo.upsample;
/*      */       
/*      */ 
/* 1678 */       upsample.next_row_out = cinfo.max_v_samp_factor;
/*      */       
/* 1680 */       upsample.rows_to_go = cinfo.output_height;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   static final class jpeg_marker_reader
/*      */   {
/*      */     boolean saw_SOI;
/*      */     
/*      */ 
/*      */     boolean saw_SOF;
/*      */     
/*      */ 
/*      */     int next_restart_num;
/*      */     
/*      */ 
/*      */     int discarded_bytes;
/*      */     
/*      */ 
/*      */     int length_limit_COM;
/*      */     
/*      */ 
/* 1703 */     int[] length_limit_APPn = new int[16];
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static final class jpeg_d_main_controller
/*      */   {
/*      */     int process_data;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1717 */     byte[][][] buffer = new byte[10][][];
/* 1718 */     int[] buffer_offset = new int[10];
/*      */     
/*      */     boolean buffer_full;
/* 1721 */     int[] rowgroup_ctr = new int[1];
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1726 */     byte[][][][] xbuffer = new byte[2][][][];
/* 1727 */     int[][] xbuffer_offset = new int[2][];
/*      */     int whichptr;
/*      */     int context_state;
/*      */     int rowgroups_avail;
/*      */     int iMCU_row_ctr;
/*      */     
/*      */     void start_pass(JPEGDecoder.jpeg_decompress_struct cinfo, int pass_mode)
/*      */     {
/* 1735 */       jpeg_d_main_controller main = cinfo.main;
/*      */       
/* 1737 */       switch (pass_mode) {
/*      */       case 0: 
/* 1739 */         if (cinfo.upsample.need_context_rows) {
/* 1740 */           main.process_data = 1;
/* 1741 */           JPEGDecoder.make_funny_pointers(cinfo);
/* 1742 */           main.whichptr = 0;
/* 1743 */           main.context_state = 0;
/* 1744 */           main.iMCU_row_ctr = 0;
/*      */         }
/*      */         else {
/* 1747 */           main.process_data = 0;
/*      */         }
/* 1749 */         main.buffer_full = false;
/* 1750 */         main.rowgroup_ctr[0] = 0;
/* 1751 */         break;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       default: 
/* 1759 */         JPEGDecoder.error();
/*      */       }
/*      */       
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   static final class jpeg_decomp_master
/*      */   {
/*      */     boolean is_dummy_pass;
/*      */     
/*      */ 
/*      */     int pass_number;
/*      */     
/*      */ 
/*      */     boolean using_merged_upsample;
/*      */     
/*      */ 
/*      */     JPEGDecoder.jpeg_color_quantizer quantizer_1pass;
/*      */     
/*      */ 
/*      */     JPEGDecoder.jpeg_color_quantizer quantizer_2pass;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   static final class jpeg_inverse_dct
/*      */   {
/* 1789 */     int[] cur_method = new int[10];
/*      */     
/*      */     void start_pass(JPEGDecoder.jpeg_decompress_struct cinfo) {
/* 1792 */       jpeg_inverse_dct idct = cinfo.idct;
/*      */       
/*      */ 
/* 1795 */       int method = 0;
/*      */       
/*      */ 
/*      */ 
/* 1799 */       for (int ci = 0; ci < cinfo.num_components; ci++) {
/* 1800 */         JPEGDecoder.jpeg_component_info compptr = cinfo.comp_info[ci];
/*      */         
/* 1802 */         switch (compptr.DCT_scaled_size)
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         case 8: 
/* 1818 */           switch (cinfo.dct_method)
/*      */           {
/*      */ 
/*      */           case 0: 
/* 1822 */             method = 0;
/* 1823 */             break;
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           default: 
/* 1838 */             JPEGDecoder.error(); }
/*      */           
/* 1840 */           break;
/*      */         
/*      */ 
/*      */         default: 
/* 1844 */           JPEGDecoder.error();
/*      */         }
/*      */         
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1856 */         if ((compptr.component_needed) && (idct.cur_method[ci] != method))
/*      */         {
/* 1858 */           JPEGDecoder.JQUANT_TBL qtbl = compptr.quant_table;
/* 1859 */           if (qtbl != null)
/*      */           {
/* 1861 */             idct.cur_method[ci] = method;
/* 1862 */             switch (method)
/*      */             {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             case 0: 
/* 1869 */               int[] ismtbl = compptr.dct_table;
/* 1870 */               for (int i = 0; i < 64; i++) {
/* 1871 */                 ismtbl[i] = qtbl.quantval[i];
/*      */               }
/*      */               
/* 1874 */               break;
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             default: 
/* 1934 */               JPEGDecoder.error();
/*      */             }
/*      */             
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   static final class jpeg_input_controller
/*      */   {
/*      */     int consume_input;
/*      */     
/*      */     boolean has_multiple_scans;
/*      */     
/*      */     boolean eoi_reached;
/*      */     
/*      */     boolean inheaders;
/*      */   }
/*      */   
/*      */ 
/*      */   static final class jpeg_color_deconverter
/*      */   {
/*      */     int color_convert;
/*      */     
/*      */     int[] Cr_r_tab;
/*      */     
/*      */     int[] Cb_b_tab;
/*      */     
/*      */     int[] Cr_g_tab;
/*      */     
/*      */     int[] Cb_g_tab;
/*      */     
/*      */ 
/*      */     void start_pass(JPEGDecoder.jpeg_decompress_struct cinfo) {}
/*      */   }
/*      */   
/*      */   static final class jpeg_d_post_controller
/*      */   {
/*      */     int post_process_data;
/*      */     int[] whole_image;
/*      */     int[][] buffer;
/*      */     int strip_height;
/*      */     int starting_row;
/*      */     int next_row;
/*      */     
/*      */     void start_pass(JPEGDecoder.jpeg_decompress_struct cinfo, int pass_mode)
/*      */     {
/* 1983 */       jpeg_d_post_controller post = cinfo.post;
/*      */       
/* 1985 */       switch (pass_mode) {
/*      */       case 0: 
/* 1987 */         if (cinfo.quantize_colors) {
/* 1988 */           JPEGDecoder.error(20);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         }
/*      */         else
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2004 */           post.post_process_data = 1;
/*      */         }
/* 2006 */         break;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       default: 
/* 2022 */         JPEGDecoder.error();
/*      */       }
/*      */       
/*      */       
/* 2026 */       post.starting_row = (post.next_row = 0);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   static final class jpeg_decompress_struct
/*      */   {
/*      */     boolean is_decompressor;
/*      */     
/*      */ 
/*      */     int global_state;
/*      */     
/*      */ 
/*      */     InputStream inputStream;
/*      */     
/*      */ 
/*      */     byte[] buffer;
/*      */     
/*      */ 
/*      */     int bytes_in_buffer;
/*      */     
/*      */ 
/*      */     int bytes_offset;
/*      */     
/*      */ 
/*      */     boolean start_of_file;
/*      */     
/*      */ 
/*      */     int image_width;
/*      */     
/*      */ 
/*      */     int image_height;
/*      */     
/*      */ 
/*      */     int num_components;
/*      */     
/*      */ 
/*      */     int jpeg_color_space;
/*      */     
/*      */ 
/*      */     int out_color_space;
/*      */     
/*      */ 
/*      */     int scale_num;
/*      */     
/*      */ 
/*      */     int scale_denom;
/*      */     
/*      */ 
/*      */     double output_gamma;
/*      */     
/*      */ 
/*      */     boolean buffered_image;
/*      */     
/*      */ 
/*      */     boolean raw_data_out;
/*      */     
/*      */ 
/*      */     int dct_method;
/*      */     
/*      */ 
/*      */     boolean do_fancy_upsampling;
/*      */     
/*      */ 
/*      */     boolean do_block_smoothing;
/*      */     
/*      */ 
/*      */     boolean quantize_colors;
/*      */     
/*      */ 
/*      */     int dither_mode;
/*      */     
/*      */ 
/*      */     boolean two_pass_quantize;
/*      */     
/*      */ 
/*      */     int desired_number_of_colors;
/*      */     
/*      */ 
/*      */     boolean enable_1pass_quant;
/*      */     
/*      */ 
/*      */     boolean enable_external_quant;
/*      */     
/*      */ 
/*      */     boolean enable_2pass_quant;
/*      */     
/*      */ 
/*      */     int output_width;
/*      */     
/*      */ 
/*      */     int output_height;
/*      */     
/*      */ 
/*      */     int out_color_components;
/*      */     
/*      */ 
/*      */     int output_components;
/*      */     
/*      */ 
/*      */     int rec_outbuf_height;
/*      */     
/*      */ 
/*      */     int actual_number_of_colors;
/*      */     
/*      */ 
/*      */     int[] colormap;
/*      */     
/*      */ 
/*      */     int output_scanline;
/*      */     
/*      */ 
/*      */     int input_scan_number;
/*      */     
/*      */ 
/*      */     int input_iMCU_row;
/*      */     
/*      */ 
/*      */     int output_scan_number;
/*      */     
/*      */ 
/*      */     int output_iMCU_row;
/*      */     
/*      */     int[][] coef_bits;
/*      */     
/* 2152 */     JPEGDecoder.JQUANT_TBL[] quant_tbl_ptrs = new JPEGDecoder.JQUANT_TBL[4];
/*      */     
/*      */ 
/* 2155 */     JPEGDecoder.JHUFF_TBL[] dc_huff_tbl_ptrs = new JPEGDecoder.JHUFF_TBL[4];
/* 2156 */     JPEGDecoder.JHUFF_TBL[] ac_huff_tbl_ptrs = new JPEGDecoder.JHUFF_TBL[4];
/*      */     
/*      */ 
/*      */     int data_precision;
/*      */     
/*      */ 
/*      */     JPEGDecoder.jpeg_component_info[] comp_info;
/*      */     
/*      */ 
/*      */     boolean progressive_mode;
/*      */     
/*      */ 
/*      */     boolean arith_code;
/*      */     
/*      */ 
/* 2171 */     byte[] arith_dc_L = new byte[16];
/* 2172 */     byte[] arith_dc_U = new byte[16];
/* 2173 */     byte[] arith_ac_K = new byte[16];
/*      */     
/*      */ 
/*      */     int restart_interval;
/*      */     
/*      */ 
/*      */     boolean saw_JFIF_marker;
/*      */     
/*      */ 
/*      */     byte JFIF_major_version;
/*      */     
/*      */ 
/*      */     byte JFIF_minor_version;
/*      */     
/*      */ 
/*      */     byte density_unit;
/*      */     
/*      */ 
/*      */     short X_density;
/*      */     
/*      */ 
/*      */     short Y_density;
/*      */     
/*      */ 
/*      */     boolean saw_Adobe_marker;
/*      */     
/*      */ 
/*      */     byte Adobe_transform;
/*      */     
/*      */ 
/*      */     boolean CCIR601_sampling;
/*      */     
/*      */ 
/*      */     JPEGDecoder.jpeg_marker_reader marker_list;
/*      */     
/*      */ 
/*      */     int max_h_samp_factor;
/*      */     
/*      */ 
/*      */     int max_v_samp_factor;
/*      */     
/*      */ 
/*      */     int min_DCT_scaled_size;
/*      */     
/*      */ 
/*      */     int total_iMCU_rows;
/*      */     
/*      */ 
/*      */     byte[] sample_range_limit;
/*      */     
/*      */ 
/*      */     int sample_range_limit_offset;
/*      */     
/*      */     int comps_in_scan;
/*      */     
/* 2228 */     JPEGDecoder.jpeg_component_info[] cur_comp_info = new JPEGDecoder.jpeg_component_info[4];
/*      */     
/*      */     int MCUs_per_row;
/*      */     
/*      */     int MCU_rows_in_scan;
/*      */     
/*      */     int blocks_in_MCU;
/* 2235 */     int[] MCU_membership = new int[10];
/*      */     
/*      */     int Ss;
/*      */     
/*      */     int Se;
/*      */     
/*      */     int Ah;
/*      */     
/*      */     int Al;
/*      */     
/*      */     int unread_marker;
/*      */     
/* 2247 */     int[] workspace = new int[64];
/* 2248 */     int[] row_ctr = new int[1];
/*      */     
/*      */     JPEGDecoder.jpeg_decomp_master master;
/*      */     
/*      */     JPEGDecoder.jpeg_d_main_controller main;
/*      */     
/*      */     JPEGDecoder.jpeg_d_coef_controller coef;
/*      */     JPEGDecoder.jpeg_d_post_controller post;
/*      */     JPEGDecoder.jpeg_input_controller inputctl;
/*      */     JPEGDecoder.jpeg_marker_reader marker;
/*      */     JPEGDecoder.jpeg_entropy_decoder entropy;
/*      */     JPEGDecoder.jpeg_inverse_dct idct;
/*      */     JPEGDecoder.jpeg_upsampler upsample;
/*      */     JPEGDecoder.jpeg_color_deconverter cconvert;
/*      */     JPEGDecoder.jpeg_color_quantizer cquantize;
/*      */   }
/*      */   
/*      */   static void error()
/*      */   {
/* 2267 */     SWT.error(40);
/*      */   }
/*      */   
/*      */   static void error(int code) {
/* 2271 */     SWT.error(code);
/*      */   }
/*      */   
/*      */   static void error(String msg) {
/* 2275 */     SWT.error(40, null, msg);
/*      */   }
/*      */   
/*      */   static void jinit_marker_reader(jpeg_decompress_struct cinfo) {
/* 2279 */     jpeg_marker_reader marker = cinfo.marker = new jpeg_marker_reader();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2287 */     marker.length_limit_COM = 0;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2295 */     reset_marker_reader(cinfo);
/*      */   }
/*      */   
/*      */   static void jinit_d_coef_controller(jpeg_decompress_struct cinfo, boolean need_full_buffer) {
/* 2299 */     jpeg_d_coef_controller coef = new jpeg_d_coef_controller();
/* 2300 */     cinfo.coef = coef;
/*      */     
/*      */ 
/* 2303 */     coef.coef_bits_latch = null;
/*      */     
/*      */ 
/* 2306 */     if (need_full_buffer)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2314 */       for (int ci = 0; ci < cinfo.num_components; ci++) {
/* 2315 */         jpeg_component_info compptr = cinfo.comp_info[ci];
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2322 */         coef.whole_image[ci] = 
/*      */         
/*      */ 
/* 2325 */           new short[(int)jround_up(compptr.height_in_blocks, compptr.v_samp_factor)][(int)jround_up(compptr.width_in_blocks, compptr.h_samp_factor)][64];
/*      */       }
/*      */       
/*      */ 
/* 2329 */       coef.decompress_data = 0;
/* 2330 */       coef.coef_arrays = coef.whole_image[0];
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/*      */ 
/* 2336 */       coef.MCU_buffer = new short[10][64];
/*      */       
/* 2338 */       coef.decompress_data = 2;
/* 2339 */       coef.coef_arrays = ((short[][][])null);
/*      */     }
/*      */   }
/*      */   
/*      */   static void start_output_pass(jpeg_decompress_struct cinfo)
/*      */   {
/* 2345 */     jpeg_d_coef_controller coef = cinfo.coef;
/*      */     
/*      */ 
/* 2348 */     if (coef.coef_arrays != null) {
/* 2349 */       if ((cinfo.do_block_smoothing) && (smoothing_ok(cinfo))) {
/* 2350 */         coef.decompress_data = 1;
/*      */       } else {
/* 2352 */         coef.decompress_data = 0;
/*      */       }
/*      */     }
/* 2355 */     cinfo.output_iMCU_row = 0;
/*      */   }
/*      */   
/*      */   static void jpeg_create_decompress(jpeg_decompress_struct cinfo) {
/* 2359 */     cinfo.is_decompressor = true;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2365 */     cinfo.marker_list = null;
/* 2366 */     jinit_marker_reader(cinfo);
/*      */     
/*      */ 
/* 2369 */     jinit_input_controller(cinfo);
/*      */     
/*      */ 
/* 2372 */     cinfo.global_state = 200;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static void jpeg_calc_output_dimensions(jpeg_decompress_struct cinfo)
/*      */   {
/* 2384 */     if (cinfo.global_state != 202) {
/* 2385 */       error();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2452 */     cinfo.output_width = cinfo.image_width;
/* 2453 */     cinfo.output_height = cinfo.image_height;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2462 */     switch (cinfo.out_color_space) {
/*      */     case 1: 
/* 2464 */       cinfo.out_color_components = 1;
/* 2465 */       break;
/*      */     case 2: 
/*      */     case 3: 
/* 2468 */       cinfo.out_color_components = 3;
/* 2469 */       break;
/*      */     case 4: 
/*      */     case 5: 
/* 2472 */       cinfo.out_color_components = 4;
/* 2473 */       break;
/*      */     default: 
/* 2475 */       cinfo.out_color_components = cinfo.num_components;
/*      */     }
/*      */     
/* 2478 */     cinfo.output_components = (cinfo.quantize_colors ? 1 : cinfo.out_color_components);
/*      */     
/*      */ 
/* 2481 */     if (use_merged_upsample(cinfo)) {
/* 2482 */       cinfo.rec_outbuf_height = cinfo.max_v_samp_factor;
/*      */     } else {
/* 2484 */       cinfo.rec_outbuf_height = 1;
/*      */     }
/*      */   }
/*      */   
/*      */   static boolean use_merged_upsample(jpeg_decompress_struct cinfo)
/*      */   {
/* 2490 */     if ((cinfo.do_fancy_upsampling) || (cinfo.CCIR601_sampling)) {
/* 2491 */       return false;
/*      */     }
/* 2493 */     if ((cinfo.jpeg_color_space != 3) || (cinfo.num_components != 3) || (cinfo.out_color_space != 2) || (cinfo.out_color_components != 3))
/*      */     {
/*      */ 
/* 2496 */       return false;
/*      */     }
/* 2498 */     if ((cinfo.comp_info[0].h_samp_factor != 2) || (cinfo.comp_info[1].h_samp_factor != 1) || (cinfo.comp_info[2].h_samp_factor != 1) || (cinfo.comp_info[0].v_samp_factor > 2) || (cinfo.comp_info[1].v_samp_factor != 1) || (cinfo.comp_info[2].v_samp_factor != 1))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2504 */       return false;
/*      */     }
/* 2506 */     if ((cinfo.comp_info[0].DCT_scaled_size != cinfo.min_DCT_scaled_size) || (cinfo.comp_info[1].DCT_scaled_size != cinfo.min_DCT_scaled_size) || (cinfo.comp_info[2].DCT_scaled_size != cinfo.min_DCT_scaled_size))
/*      */     {
/*      */ 
/* 2509 */       return false;
/*      */     }
/* 2511 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static void prepare_range_limit_table(jpeg_decompress_struct cinfo)
/*      */   {
/* 2523 */     byte[] table = new byte['ր'];
/* 2524 */     int offset = 256;
/* 2525 */     cinfo.sample_range_limit_offset = offset;
/* 2526 */     cinfo.sample_range_limit = table;
/*      */     
/*      */ 
/* 2529 */     for (int i = 0; i <= 255; i++)
/* 2530 */       table[(i + offset)] = ((byte)i);
/* 2531 */     offset += 128;
/*      */     
/* 2533 */     for (i = 128; i < 512; i++) {
/* 2534 */       table[(i + offset)] = -1;
/*      */     }
/* 2536 */     System.arraycopy(cinfo.sample_range_limit, cinfo.sample_range_limit_offset, table, offset + 896, 128);
/*      */   }
/*      */   
/*      */   static void build_ycc_rgb_table(jpeg_decompress_struct cinfo) {
/* 2540 */     jpeg_color_deconverter cconvert = cinfo.cconvert;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 2545 */     cconvert.Cr_r_tab = new int['Ā'];
/* 2546 */     cconvert.Cb_b_tab = new int['Ā'];
/* 2547 */     cconvert.Cr_g_tab = new int['Ā'];
/* 2548 */     cconvert.Cb_g_tab = new int['Ā'];
/*      */     
/* 2550 */     int i = 0; for (int x = -128; i <= 255; x++)
/*      */     {
/*      */ 
/*      */ 
/* 2554 */       cconvert.Cr_r_tab[i] = (91881 * x + 32768 >> 16);
/*      */       
/* 2556 */       cconvert.Cb_b_tab[i] = (116130 * x + 32768 >> 16);
/*      */       
/* 2558 */       cconvert.Cr_g_tab[i] = (-46802 * x);
/*      */       
/*      */ 
/* 2561 */       cconvert.Cb_g_tab[i] = (42982 * x + 32768);i++;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static void jinit_color_deconverter(jpeg_decompress_struct cinfo)
/*      */   {
/* 2566 */     jpeg_color_deconverter cconvert = cinfo.cconvert = new jpeg_color_deconverter();
/*      */     
/*      */ 
/*      */ 
/* 2570 */     switch (cinfo.jpeg_color_space) {
/*      */     case 1: 
/* 2572 */       if (cinfo.num_components != 1) {
/* 2573 */         error();
/*      */       }
/*      */       
/*      */       break;
/*      */     case 2: 
/*      */     case 3: 
/* 2579 */       if (cinfo.num_components != 3) {
/* 2580 */         error();
/*      */       }
/*      */       
/*      */       break;
/*      */     case 4: 
/*      */     case 5: 
/* 2586 */       if (cinfo.num_components != 4) {
/* 2587 */         error();
/*      */       }
/*      */       
/*      */       break;
/*      */     default: 
/* 2592 */       if (cinfo.num_components < 1) {
/* 2593 */         error();
/*      */       }
/*      */       
/*      */ 
/*      */       break;
/*      */     }
/*      */     
/*      */     
/*      */ 
/*      */     int ci;
/*      */     
/* 2604 */     switch (cinfo.out_color_space) {
/*      */     case 1: 
/* 2606 */       cinfo.out_color_components = 1;
/* 2607 */       if ((cinfo.jpeg_color_space == 1) || (cinfo.jpeg_color_space == 3)) {
/* 2608 */         cconvert.color_convert = 1;
/*      */         
/* 2610 */         for (ci = 1; ci < cinfo.num_components;) {
/* 2611 */           cinfo.comp_info[ci].component_needed = false;ci++; continue;
/*      */           
/* 2613 */           error();
/*      */           
/* 2615 */           break;
/*      */           
/*      */ 
/* 2618 */           cinfo.out_color_components = 3;
/* 2619 */           if (cinfo.jpeg_color_space == 3) {
/* 2620 */             cconvert.color_convert = 2;
/* 2621 */             build_ycc_rgb_table(cinfo);
/* 2622 */           } else if (cinfo.jpeg_color_space == 1) {
/* 2623 */             cconvert.color_convert = 3;
/* 2624 */           } else if (cinfo.jpeg_color_space == 2) {
/* 2625 */             cconvert.color_convert = 0;
/*      */           } else {
/* 2627 */             error();
/*      */             
/* 2629 */             break;
/*      */             
/*      */ 
/* 2632 */             cinfo.out_color_components = 4;
/* 2633 */             if (cinfo.jpeg_color_space == 5) {
/* 2634 */               cconvert.color_convert = 4;
/* 2635 */               build_ycc_rgb_table(cinfo);
/* 2636 */             } else if (cinfo.jpeg_color_space == 4) {
/* 2637 */               cconvert.color_convert = 0;
/*      */             } else {
/* 2639 */               error();
/*      */               
/* 2641 */               break;
/*      */               
/*      */ 
/*      */ 
/* 2645 */               if (cinfo.out_color_space == cinfo.jpeg_color_space) {
/* 2646 */                 cinfo.out_color_components = cinfo.num_components;
/* 2647 */                 cconvert.color_convert = 0;
/*      */               } else {
/* 2649 */                 error();
/*      */               }
/*      */             }
/*      */           } } }
/*      */       break; }
/* 2654 */     if (cinfo.quantize_colors) {
/* 2655 */       cinfo.output_components = 1;
/*      */     } else
/* 2657 */       cinfo.output_components = cinfo.out_color_components;
/*      */   }
/*      */   
/*      */   static void jinit_d_post_controller(jpeg_decompress_struct cinfo, boolean need_full_buffer) {
/* 2661 */     jpeg_d_post_controller post = cinfo.post = new jpeg_d_post_controller();
/*      */     
/* 2663 */     post.whole_image = null;
/* 2664 */     post.buffer = ((int[][])null);
/*      */     
/*      */ 
/* 2667 */     if (cinfo.quantize_colors) {
/* 2668 */       error(20);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static void make_funny_pointers(jpeg_decompress_struct cinfo)
/*      */   {
/* 2705 */     jpeg_d_main_controller main = cinfo.main;
/*      */     
/* 2707 */     int M = cinfo.min_DCT_scaled_size;
/*      */     
/*      */ 
/*      */ 
/* 2711 */     for (int ci = 0; ci < cinfo.num_components; ci++) {
/* 2712 */       jpeg_component_info compptr = cinfo.comp_info[ci];
/* 2713 */       int rgroup = compptr.v_samp_factor * compptr.DCT_scaled_size / cinfo.min_DCT_scaled_size;
/*      */       
/* 2715 */       byte[][] xbuf0 = main.xbuffer[0][ci];
/* 2716 */       int xbuf0_offset = main.xbuffer_offset[0][ci];
/* 2717 */       byte[][] xbuf1 = main.xbuffer[1][ci];
/* 2718 */       int xbuf1_offset = main.xbuffer_offset[1][ci];
/*      */       
/* 2720 */       byte[][] buf = main.buffer[ci];
/* 2721 */       for (int i = 0; i < rgroup * (M + 2); i++) {
/* 2722 */         xbuf0[(i + xbuf0_offset)] = (xbuf1[(i + xbuf1_offset)] = buf[i]);
/*      */       }
/*      */       
/* 2725 */       for (i = 0; i < rgroup * 2; i++) {
/* 2726 */         xbuf1[(rgroup * (M - 2) + i + xbuf1_offset)] = buf[(rgroup * M + i)];
/* 2727 */         xbuf1[(rgroup * M + i + xbuf1_offset)] = buf[(rgroup * (M - 2) + i)];
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2734 */       for (i = 0; i < rgroup; i++) {
/* 2735 */         xbuf0[(i - rgroup + xbuf0_offset)] = xbuf0[(0 + xbuf0_offset)];
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   static void alloc_funny_pointers(jpeg_decompress_struct cinfo)
/*      */   {
/* 2745 */     jpeg_d_main_controller main = cinfo.main;
/*      */     
/* 2747 */     int M = cinfo.min_DCT_scaled_size;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2754 */     main.xbuffer[0] = new byte[cinfo.num_components][][];
/* 2755 */     main.xbuffer[1] = new byte[cinfo.num_components][][];
/* 2756 */     main.xbuffer_offset[0] = new int[cinfo.num_components];
/* 2757 */     main.xbuffer_offset[1] = new int[cinfo.num_components];
/*      */     
/* 2759 */     for (int ci = 0; ci < cinfo.num_components; ci++) {
/* 2760 */       jpeg_component_info compptr = cinfo.comp_info[ci];
/* 2761 */       int rgroup = compptr.v_samp_factor * compptr.DCT_scaled_size / cinfo.min_DCT_scaled_size;
/*      */       
/*      */ 
/*      */ 
/* 2765 */       byte[][] xbuf = new byte[2 * (rgroup * (M + 4))][];
/* 2766 */       int offset = rgroup;
/* 2767 */       main.xbuffer_offset[0][ci] = offset;
/* 2768 */       main.xbuffer[0][ci] = xbuf;
/* 2769 */       offset += rgroup * (M + 4);
/* 2770 */       main.xbuffer_offset[1][ci] = offset;
/* 2771 */       main.xbuffer[1][ci] = xbuf;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   static void jinit_d_main_controller(jpeg_decompress_struct cinfo, boolean need_full_buffer)
/*      */   {
/* 2780 */     jpeg_d_main_controller main = cinfo.main = new jpeg_d_main_controller();
/*      */     
/*      */ 
/* 2783 */     if (need_full_buffer) {
/* 2784 */       error();
/*      */     }
/*      */     
/*      */     int ngroups;
/*      */     
/*      */     int ngroups;
/* 2790 */     if (cinfo.upsample.need_context_rows) {
/* 2791 */       if (cinfo.min_DCT_scaled_size < 2) {
/* 2792 */         error();
/*      */       }
/* 2794 */       alloc_funny_pointers(cinfo);
/* 2795 */       ngroups = cinfo.min_DCT_scaled_size + 2;
/*      */     } else {
/* 2797 */       ngroups = cinfo.min_DCT_scaled_size;
/*      */     }
/*      */     
/* 2800 */     for (int ci = 0; ci < cinfo.num_components; ci++) {
/* 2801 */       jpeg_component_info compptr = cinfo.comp_info[ci];
/* 2802 */       int rgroup = compptr.v_samp_factor * compptr.DCT_scaled_size / cinfo.min_DCT_scaled_size;
/* 2803 */       main.buffer[ci] = new byte[rgroup * ngroups][compptr.width_in_blocks * compptr.DCT_scaled_size];
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   static long jround_up(long a, long b)
/*      */   {
/* 2811 */     a += b - 1L;
/* 2812 */     return a - a % b;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static void jinit_upsampler(jpeg_decompress_struct cinfo)
/*      */   {
/* 2821 */     jpeg_upsampler upsample = new jpeg_upsampler();
/* 2822 */     cinfo.upsample = upsample;
/*      */     
/*      */ 
/* 2825 */     upsample.need_context_rows = false;
/*      */     
/* 2827 */     if (cinfo.CCIR601_sampling) {
/* 2828 */       error();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 2834 */     boolean do_fancy = (cinfo.do_fancy_upsampling) && (cinfo.min_DCT_scaled_size > 1);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 2839 */     for (int ci = 0; ci < cinfo.num_components; ci++) {
/* 2840 */       jpeg_component_info compptr = cinfo.comp_info[ci];
/*      */       
/*      */ 
/*      */ 
/* 2844 */       int h_in_group = compptr.h_samp_factor * compptr.DCT_scaled_size / cinfo.min_DCT_scaled_size;
/*      */       
/* 2846 */       int v_in_group = compptr.v_samp_factor * compptr.DCT_scaled_size / cinfo.min_DCT_scaled_size;
/*      */       
/* 2848 */       int h_out_group = cinfo.max_h_samp_factor;
/* 2849 */       int v_out_group = cinfo.max_v_samp_factor;
/* 2850 */       upsample.rowgroup_height[ci] = v_in_group;
/* 2851 */       boolean need_buffer = true;
/* 2852 */       if (!compptr.component_needed)
/*      */       {
/* 2854 */         upsample.methods[ci] = 0;
/* 2855 */         need_buffer = false;
/* 2856 */       } else if ((h_in_group == h_out_group) && (v_in_group == v_out_group))
/*      */       {
/* 2858 */         upsample.methods[ci] = 1;
/* 2859 */         need_buffer = false;
/* 2860 */       } else if ((h_in_group * 2 == h_out_group) && (v_in_group == v_out_group))
/*      */       {
/* 2862 */         if ((do_fancy) && (compptr.downsampled_width > 2)) {
/* 2863 */           upsample.methods[ci] = 2;
/*      */         } else
/* 2865 */           upsample.methods[ci] = 3;
/* 2866 */       } else if ((h_in_group * 2 == h_out_group) && (v_in_group * 2 == v_out_group))
/*      */       {
/* 2868 */         if ((do_fancy) && (compptr.downsampled_width > 2)) {
/* 2869 */           upsample.methods[ci] = 4;
/* 2870 */           upsample.need_context_rows = true;
/*      */         } else {
/* 2872 */           upsample.methods[ci] = 5;
/* 2873 */         } } else if ((h_out_group % h_in_group == 0) && (v_out_group % v_in_group == 0))
/*      */       {
/* 2875 */         upsample.methods[ci] = 6;
/* 2876 */         upsample.h_expand[ci] = ((byte)(h_out_group / h_in_group));
/* 2877 */         upsample.v_expand[ci] = ((byte)(v_out_group / v_in_group));
/*      */       } else {
/* 2879 */         error();
/*      */       }
/* 2881 */       if (need_buffer)
/*      */       {
/* 2883 */         upsample.color_buf[ci] = new byte[cinfo.max_v_samp_factor][(int)jround_up(cinfo.output_width, cinfo.max_h_samp_factor)];
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   static void jinit_phuff_decoder(jpeg_decompress_struct cinfo)
/*      */   {
/* 2892 */     cinfo.entropy = new phuff_entropy_decoder();
/*      */     
/*      */ 
/*      */ 
/* 2896 */     cinfo.coef_bits = new int[cinfo.num_components][64];
/* 2897 */     int[][] coef_bit_ptr = cinfo.coef_bits;
/* 2898 */     for (int ci = 0; ci < cinfo.num_components; ci++) {
/* 2899 */       for (int i = 0; i < 64; i++) {
/* 2900 */         coef_bit_ptr[ci][i] = -1;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   static void jinit_huff_decoder(jpeg_decompress_struct cinfo) {
/* 2906 */     cinfo.entropy = new huff_entropy_decoder();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static void jinit_inverse_dct(jpeg_decompress_struct cinfo)
/*      */   {
/* 2916 */     jpeg_inverse_dct idct = cinfo.idct = new jpeg_inverse_dct();
/*      */     
/*      */ 
/* 2919 */     for (int ci = 0; ci < cinfo.num_components; ci++) {
/* 2920 */       jpeg_component_info compptr = cinfo.comp_info[ci];
/*      */       
/* 2922 */       compptr.dct_table = new int[64];
/*      */       
/* 2924 */       idct.cur_method[ci] = -1;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static void jpeg_idct_islow(jpeg_decompress_struct cinfo, jpeg_component_info compptr, short[] coef_block, byte[][] output_buf, int output_buf_offset, int output_col)
/*      */   {
/* 2942 */     byte[] range_limit = cinfo.sample_range_limit;
/* 2943 */     int range_limit_offset = cinfo.sample_range_limit_offset + 128;
/*      */     
/* 2945 */     int[] workspace = cinfo.workspace;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2952 */     short[] inptr = coef_block;
/* 2953 */     int[] quantptr = compptr.dct_table;
/* 2954 */     int[] wsptr = workspace;
/* 2955 */     int inptr_offset = 0;int quantptr_offset = 0;int wsptr_offset = 0;
/* 2956 */     for (int ctr = 8; ctr > 0; ctr--)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2966 */       if ((inptr[(8 + inptr_offset)] == 0) && (inptr[(16 + inptr_offset)] == 0) && (inptr[(24 + inptr_offset)] == 0) && (inptr[(32 + inptr_offset)] == 0) && (inptr[(40 + inptr_offset)] == 0) && (inptr[(48 + inptr_offset)] == 0) && (inptr[(56 + inptr_offset)] == 0))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2972 */         int dcval = inptr[(0 + inptr_offset)] * quantptr[(0 + quantptr_offset)] << 2;
/*      */         
/* 2974 */         wsptr[(0 + wsptr_offset)] = dcval;
/* 2975 */         wsptr[(8 + wsptr_offset)] = dcval;
/* 2976 */         wsptr[(16 + wsptr_offset)] = dcval;
/* 2977 */         wsptr[(24 + wsptr_offset)] = dcval;
/* 2978 */         wsptr[(32 + wsptr_offset)] = dcval;
/* 2979 */         wsptr[(40 + wsptr_offset)] = dcval;
/* 2980 */         wsptr[(48 + wsptr_offset)] = dcval;
/* 2981 */         wsptr[(56 + wsptr_offset)] = dcval;
/*      */         
/* 2983 */         inptr_offset++;
/* 2984 */         quantptr_offset++;
/* 2985 */         wsptr_offset++;
/*      */ 
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*      */ 
/* 2992 */         int z2 = inptr[(16 + inptr_offset)] * quantptr[(16 + quantptr_offset)];
/* 2993 */         int z3 = inptr[(48 + inptr_offset)] * quantptr[(48 + quantptr_offset)];
/*      */         
/* 2995 */         int z1 = (z2 + z3) * 4433;
/* 2996 */         int tmp2 = z1 + z3 * 50399;
/* 2997 */         int tmp3 = z1 + z2 * 6270;
/*      */         
/* 2999 */         z2 = inptr[(0 + inptr_offset)] * quantptr[(0 + quantptr_offset)];
/* 3000 */         z3 = inptr[(32 + inptr_offset)] * quantptr[(32 + quantptr_offset)];
/*      */         
/* 3002 */         int tmp0 = z2 + z3 << 13;
/* 3003 */         int tmp1 = z2 - z3 << 13;
/*      */         
/* 3005 */         int tmp10 = tmp0 + tmp3;
/* 3006 */         int tmp13 = tmp0 - tmp3;
/* 3007 */         int tmp11 = tmp1 + tmp2;
/* 3008 */         int tmp12 = tmp1 - tmp2;
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3014 */         tmp0 = inptr[(56 + inptr_offset)] * quantptr[(56 + quantptr_offset)];
/* 3015 */         tmp1 = inptr[(40 + inptr_offset)] * quantptr[(40 + quantptr_offset)];
/* 3016 */         tmp2 = inptr[(24 + inptr_offset)] * quantptr[(24 + quantptr_offset)];
/* 3017 */         tmp3 = inptr[(8 + inptr_offset)] * quantptr[(8 + quantptr_offset)];
/*      */         
/* 3019 */         z1 = tmp0 + tmp3;
/* 3020 */         z2 = tmp1 + tmp2;
/* 3021 */         z3 = tmp0 + tmp2;
/* 3022 */         int z4 = tmp1 + tmp3;
/* 3023 */         int z5 = (z3 + z4) * 9633;
/*      */         
/* 3025 */         tmp0 *= 2446;
/* 3026 */         tmp1 *= 16819;
/* 3027 */         tmp2 *= 25172;
/* 3028 */         tmp3 *= 12299;
/* 3029 */         z1 *= 58163;
/* 3030 */         z2 *= 44541;
/* 3031 */         z3 *= 49467;
/* 3032 */         z4 *= 62340;
/*      */         
/* 3034 */         z3 += z5;
/* 3035 */         z4 += z5;
/*      */         
/* 3037 */         tmp0 += z1 + z3;
/* 3038 */         tmp1 += z2 + z4;
/* 3039 */         tmp2 += z2 + z3;
/* 3040 */         tmp3 += z1 + z4;
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 3045 */         wsptr[(0 + wsptr_offset)] = (tmp10 + tmp3 + 1024 >> 11);
/* 3046 */         wsptr[(56 + wsptr_offset)] = (tmp10 - tmp3 + 1024 >> 11);
/* 3047 */         wsptr[(8 + wsptr_offset)] = (tmp11 + tmp2 + 1024 >> 11);
/* 3048 */         wsptr[(48 + wsptr_offset)] = (tmp11 - tmp2 + 1024 >> 11);
/* 3049 */         wsptr[(16 + wsptr_offset)] = (tmp12 + tmp1 + 1024 >> 11);
/* 3050 */         wsptr[(40 + wsptr_offset)] = (tmp12 - tmp1 + 1024 >> 11);
/* 3051 */         wsptr[(24 + wsptr_offset)] = (tmp13 + tmp0 + 1024 >> 11);
/* 3052 */         wsptr[(32 + wsptr_offset)] = (tmp13 - tmp0 + 1024 >> 11);
/*      */         
/* 3054 */         inptr_offset++;
/* 3055 */         quantptr_offset++;
/* 3056 */         wsptr_offset++;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3064 */     int outptr_offset = 0;
/* 3065 */     wsptr = workspace;
/* 3066 */     wsptr_offset = 0;
/* 3067 */     for (ctr = 0; ctr < 8; ctr++) {
/* 3068 */       byte[] outptr = output_buf[(ctr + output_buf_offset)];
/* 3069 */       outptr_offset = output_col;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3079 */       if ((wsptr[(1 + wsptr_offset)] == 0) && (wsptr[(2 + wsptr_offset)] == 0) && (wsptr[(3 + wsptr_offset)] == 0) && (wsptr[(4 + wsptr_offset)] == 0) && (wsptr[(5 + wsptr_offset)] == 0) && (wsptr[(6 + wsptr_offset)] == 0) && (wsptr[(7 + wsptr_offset)] == 0))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/* 3084 */         byte dcval = range_limit[(range_limit_offset + (wsptr[(0 + wsptr_offset)] + 16 >> 5 & 0x3FF))];
/*      */         
/*      */ 
/* 3087 */         outptr[(0 + outptr_offset)] = dcval;
/* 3088 */         outptr[(1 + outptr_offset)] = dcval;
/* 3089 */         outptr[(2 + outptr_offset)] = dcval;
/* 3090 */         outptr[(3 + outptr_offset)] = dcval;
/* 3091 */         outptr[(4 + outptr_offset)] = dcval;
/* 3092 */         outptr[(5 + outptr_offset)] = dcval;
/* 3093 */         outptr[(6 + outptr_offset)] = dcval;
/* 3094 */         outptr[(7 + outptr_offset)] = dcval;
/*      */         
/* 3096 */         wsptr_offset += 8;
/*      */ 
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*      */ 
/*      */ 
/* 3104 */         int z2 = wsptr[(2 + wsptr_offset)];
/* 3105 */         int z3 = wsptr[(6 + wsptr_offset)];
/*      */         
/* 3107 */         int z1 = (z2 + z3) * 4433;
/* 3108 */         int tmp2 = z1 + z3 * 50399;
/* 3109 */         int tmp3 = z1 + z2 * 6270;
/*      */         
/* 3111 */         int tmp0 = wsptr[(0 + wsptr_offset)] + wsptr[(4 + wsptr_offset)] << 13;
/* 3112 */         int tmp1 = wsptr[(0 + wsptr_offset)] - wsptr[(4 + wsptr_offset)] << 13;
/*      */         
/* 3114 */         int tmp10 = tmp0 + tmp3;
/* 3115 */         int tmp13 = tmp0 - tmp3;
/* 3116 */         int tmp11 = tmp1 + tmp2;
/* 3117 */         int tmp12 = tmp1 - tmp2;
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3123 */         tmp0 = wsptr[(7 + wsptr_offset)];
/* 3124 */         tmp1 = wsptr[(5 + wsptr_offset)];
/* 3125 */         tmp2 = wsptr[(3 + wsptr_offset)];
/* 3126 */         tmp3 = wsptr[(1 + wsptr_offset)];
/*      */         
/* 3128 */         z1 = tmp0 + tmp3;
/* 3129 */         z2 = tmp1 + tmp2;
/* 3130 */         z3 = tmp0 + tmp2;
/* 3131 */         int z4 = tmp1 + tmp3;
/* 3132 */         int z5 = (z3 + z4) * 9633;
/*      */         
/* 3134 */         tmp0 *= 2446;
/* 3135 */         tmp1 *= 16819;
/* 3136 */         tmp2 *= 25172;
/* 3137 */         tmp3 *= 12299;
/* 3138 */         z1 *= 58163;
/* 3139 */         z2 *= 44541;
/* 3140 */         z3 *= 49467;
/* 3141 */         z4 *= 62340;
/*      */         
/* 3143 */         z3 += z5;
/* 3144 */         z4 += z5;
/*      */         
/* 3146 */         tmp0 += z1 + z3;
/* 3147 */         tmp1 += z2 + z4;
/* 3148 */         tmp2 += z2 + z3;
/* 3149 */         tmp3 += z1 + z4;
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3155 */         outptr[(0 + outptr_offset)] = range_limit[(range_limit_offset + (tmp10 + tmp3 + 131072 >> 18 & 0x3FF))];
/*      */         
/*      */ 
/* 3158 */         outptr[(7 + outptr_offset)] = range_limit[(range_limit_offset + (tmp10 - tmp3 + 131072 >> 18 & 0x3FF))];
/*      */         
/*      */ 
/* 3161 */         outptr[(1 + outptr_offset)] = range_limit[(range_limit_offset + (tmp11 + tmp2 + 131072 >> 18 & 0x3FF))];
/*      */         
/*      */ 
/* 3164 */         outptr[(6 + outptr_offset)] = range_limit[(range_limit_offset + (tmp11 - tmp2 + 131072 >> 18 & 0x3FF))];
/*      */         
/*      */ 
/* 3167 */         outptr[(2 + outptr_offset)] = range_limit[(range_limit_offset + (tmp12 + tmp1 + 131072 >> 18 & 0x3FF))];
/*      */         
/*      */ 
/* 3170 */         outptr[(5 + outptr_offset)] = range_limit[(range_limit_offset + (tmp12 - tmp1 + 131072 >> 18 & 0x3FF))];
/*      */         
/*      */ 
/* 3173 */         outptr[(3 + outptr_offset)] = range_limit[(range_limit_offset + (tmp13 + tmp0 + 131072 >> 18 & 0x3FF))];
/*      */         
/*      */ 
/* 3176 */         outptr[(4 + outptr_offset)] = range_limit[(range_limit_offset + (tmp13 - tmp0 + 131072 >> 18 & 0x3FF))];
/*      */         
/*      */ 
/*      */ 
/* 3180 */         wsptr_offset += 8;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   static void upsample(jpeg_decompress_struct cinfo, byte[][][] input_buf, int[] input_buf_offset, int[] in_row_group_ctr, int in_row_groups_avail, byte[][] output_buf, int[] out_row_ctr, int out_rows_avail)
/*      */   {
/* 3190 */     sep_upsample(cinfo, input_buf, input_buf_offset, in_row_group_ctr, in_row_groups_avail, output_buf, out_row_ctr, out_rows_avail);
/*      */   }
/*      */   
/*      */   static boolean smoothing_ok(jpeg_decompress_struct cinfo) {
/* 3194 */     jpeg_d_coef_controller coef = cinfo.coef;
/* 3195 */     boolean smoothing_useful = false;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3202 */     if ((!cinfo.progressive_mode) || (cinfo.coef_bits == null)) {
/* 3203 */       return false;
/*      */     }
/*      */     
/* 3206 */     if (coef.coef_bits_latch == null)
/* 3207 */       coef.coef_bits_latch = new int[cinfo.num_components * 6];
/* 3208 */     int[] coef_bits_latch = coef.coef_bits_latch;
/* 3209 */     int coef_bits_latch_offset = 0;
/*      */     
/* 3211 */     for (int ci = 0; ci < cinfo.num_components; ci++) {
/* 3212 */       jpeg_component_info compptr = cinfo.comp_info[ci];
/*      */       JQUANT_TBL qtable;
/* 3214 */       if ((qtable = compptr.quant_table) == null) {
/* 3215 */         return false;
/*      */       }
/* 3217 */       if ((qtable.quantval[0] == 0) || (qtable.quantval[1] == 0) || (qtable.quantval[8] == 0) || (qtable.quantval[16] == 0) || (qtable.quantval[9] == 0) || (qtable.quantval[2] == 0))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3223 */         return false;
/*      */       }
/* 3225 */       int[] coef_bits = cinfo.coef_bits[ci];
/* 3226 */       if (coef_bits[0] < 0) {
/* 3227 */         return false;
/*      */       }
/* 3229 */       for (int coefi = 1; coefi <= 5; coefi++) {
/* 3230 */         coef_bits_latch[(coefi + coef_bits_latch_offset)] = coef_bits[coefi];
/* 3231 */         if (coef_bits[coefi] != 0)
/* 3232 */           smoothing_useful = true;
/*      */       }
/* 3234 */       coef_bits_latch_offset += 6;
/*      */     }
/*      */     
/* 3237 */     return smoothing_useful;
/*      */   }
/*      */   
/*      */   static void master_selection(jpeg_decompress_struct cinfo) {
/* 3241 */     jpeg_decomp_master master = cinfo.master;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3247 */     jpeg_calc_output_dimensions(cinfo);
/* 3248 */     prepare_range_limit_table(cinfo);
/*      */     
/*      */ 
/* 3251 */     long samplesperrow = cinfo.output_width * cinfo.out_color_components;
/* 3252 */     int jd_samplesperrow = (int)samplesperrow;
/* 3253 */     if (jd_samplesperrow != samplesperrow) {
/* 3254 */       error();
/*      */     }
/*      */     
/*      */ 
/* 3258 */     master.pass_number = 0;
/* 3259 */     master.using_merged_upsample = use_merged_upsample(cinfo);
/*      */     
/*      */ 
/* 3262 */     master.quantizer_1pass = null;
/* 3263 */     master.quantizer_2pass = null;
/*      */     
/* 3265 */     if ((!cinfo.quantize_colors) || (!cinfo.buffered_image)) {
/* 3266 */       cinfo.enable_1pass_quant = false;
/* 3267 */       cinfo.enable_external_quant = false;
/* 3268 */       cinfo.enable_2pass_quant = false;
/*      */     }
/* 3270 */     if (cinfo.quantize_colors) {
/* 3271 */       error(20);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3312 */     if (!cinfo.raw_data_out) {
/* 3313 */       if (master.using_merged_upsample)
/*      */       {
/*      */ 
/*      */ 
/* 3317 */         error();
/*      */       }
/*      */       else
/*      */       {
/* 3321 */         jinit_color_deconverter(cinfo);
/* 3322 */         jinit_upsampler(cinfo);
/*      */       }
/* 3324 */       jinit_d_post_controller(cinfo, cinfo.enable_2pass_quant);
/*      */     }
/*      */     
/* 3327 */     jinit_inverse_dct(cinfo);
/*      */     
/* 3329 */     if (cinfo.arith_code) {
/* 3330 */       error();
/*      */ 
/*      */     }
/* 3333 */     else if (cinfo.progressive_mode)
/*      */     {
/* 3335 */       jinit_phuff_decoder(cinfo);
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/* 3340 */       jinit_huff_decoder(cinfo);
/*      */     }
/*      */     
/*      */ 
/* 3344 */     boolean use_c_buffer = (cinfo.inputctl.has_multiple_scans) || (cinfo.buffered_image);
/* 3345 */     jinit_d_coef_controller(cinfo, use_c_buffer);
/*      */     
/* 3347 */     if (!cinfo.raw_data_out) {
/* 3348 */       jinit_d_main_controller(cinfo, false);
/*      */     }
/*      */     
/* 3351 */     start_input_pass(cinfo);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static void jinit_master_decompress(jpeg_decompress_struct cinfo)
/*      */   {
/* 3380 */     jpeg_decomp_master master = new jpeg_decomp_master();
/* 3381 */     cinfo.master = master;
/*      */     
/*      */ 
/*      */ 
/* 3385 */     master.is_dummy_pass = false;
/*      */     
/* 3387 */     master_selection(cinfo);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static void jcopy_sample_rows(byte[][] input_array, int source_row, byte[][] output_array, int dest_row, int num_rows, int num_cols)
/*      */   {
/* 3401 */     int count = num_cols;
/*      */     
/*      */ 
/* 3404 */     int input_array_offset = source_row;
/* 3405 */     int output_array_offset = dest_row;
/*      */     
/* 3407 */     for (int row = num_rows; row > 0; row--) {
/* 3408 */       byte[] inptr = input_array[(input_array_offset++)];
/* 3409 */       byte[] outptr = output_array[(output_array_offset++)];
/* 3410 */       System.arraycopy(inptr, 0, outptr, 0, count);
/*      */     }
/*      */   }
/*      */   
/*      */   static boolean jpeg_start_decompress(jpeg_decompress_struct cinfo) {
/* 3415 */     if (cinfo.global_state == 202)
/*      */     {
/* 3417 */       jinit_master_decompress(cinfo);
/* 3418 */       if (cinfo.buffered_image)
/*      */       {
/* 3420 */         cinfo.global_state = 207;
/* 3421 */         return true;
/*      */       }
/* 3423 */       cinfo.global_state = 203;
/*      */     }
/* 3425 */     if (cinfo.global_state == 203)
/*      */     {
/* 3427 */       if (cinfo.inputctl.has_multiple_scans)
/*      */       {
/*      */ 
/*      */ 
/*      */         for (;;)
/*      */         {
/*      */ 
/*      */ 
/* 3435 */           int retcode = consume_input(cinfo);
/* 3436 */           if (retcode == 0)
/* 3437 */             return false;
/* 3438 */           if (retcode == 2) {
/*      */             break;
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3452 */       cinfo.output_scan_number = cinfo.input_scan_number;
/* 3453 */     } else if (cinfo.global_state != 204) {
/* 3454 */       error();
/*      */     }
/*      */     
/* 3457 */     return output_pass_setup(cinfo);
/*      */   }
/*      */   
/*      */   static void prepare_for_output_pass(jpeg_decompress_struct cinfo) {
/* 3461 */     jpeg_decomp_master master = cinfo.master;
/*      */     
/* 3463 */     if (master.is_dummy_pass)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3471 */       error(20);
/*      */     }
/*      */     else
/*      */     {
/* 3475 */       if ((cinfo.quantize_colors) && (cinfo.colormap == null))
/*      */       {
/* 3477 */         if ((cinfo.two_pass_quantize) && (cinfo.enable_2pass_quant)) {
/* 3478 */           cinfo.cquantize = master.quantizer_2pass;
/* 3479 */           master.is_dummy_pass = true;
/* 3480 */         } else if (cinfo.enable_1pass_quant) {
/* 3481 */           cinfo.cquantize = master.quantizer_1pass;
/*      */         } else {
/* 3483 */           error();
/*      */         }
/*      */       }
/*      */       
/* 3487 */       cinfo.idct.start_pass(cinfo);
/* 3488 */       start_output_pass(cinfo);
/* 3489 */       if (!cinfo.raw_data_out) {
/* 3490 */         if (!master.using_merged_upsample)
/* 3491 */           cinfo.cconvert.start_pass(cinfo);
/* 3492 */         cinfo.upsample.start_pass(cinfo);
/* 3493 */         if (cinfo.quantize_colors)
/* 3494 */           cinfo.cquantize.start_pass(cinfo, master.is_dummy_pass);
/* 3495 */         cinfo.post.start_pass(cinfo, master.is_dummy_pass ? 3 : 0);
/* 3496 */         cinfo.main.start_pass(cinfo, 0);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static boolean jpeg_resync_to_restart(jpeg_decompress_struct cinfo, int desired)
/*      */   {
/* 3516 */     int marker = cinfo.unread_marker;
/* 3517 */     int action = 1;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     for (;;)
/*      */     {
/* 3524 */       if (marker < 192) {
/* 3525 */         action = 2;
/* 3526 */       } else if ((marker < 208) || (marker > 215)) {
/* 3527 */         action = 3;
/*      */       }
/* 3529 */       else if ((marker == 208 + (desired + 1 & 0x7)) || (marker == 208 + (desired + 2 & 0x7))) {
/* 3530 */         action = 3;
/* 3531 */       } else if ((marker == 208 + (desired - 1 & 0x7)) || (marker == 208 + (desired - 2 & 0x7))) {
/* 3532 */         action = 2;
/*      */       } else {
/* 3534 */         action = 1;
/*      */       }
/*      */       
/* 3537 */       switch (action)
/*      */       {
/*      */       case 1: 
/* 3540 */         cinfo.unread_marker = 0;
/* 3541 */         return true;
/*      */       
/*      */       case 2: 
/* 3544 */         if (!next_marker(cinfo))
/* 3545 */           return false;
/* 3546 */         marker = cinfo.unread_marker;
/* 3547 */         break;
/*      */       
/*      */ 
/*      */       case 3: 
/* 3551 */         return true;
/*      */       }
/*      */       
/*      */     }
/*      */   }
/*      */   
/*      */   static boolean read_restart_marker(jpeg_decompress_struct cinfo)
/*      */   {
/* 3559 */     if ((cinfo.unread_marker == 0) && 
/* 3560 */       (!next_marker(cinfo))) {
/* 3561 */       return false;
/*      */     }
/*      */     
/* 3564 */     if (cinfo.unread_marker == 208 + cinfo.marker.next_restart_num)
/*      */     {
/*      */ 
/* 3567 */       cinfo.unread_marker = 0;
/*      */ 
/*      */ 
/*      */     }
/* 3571 */     else if (!jpeg_resync_to_restart(cinfo, cinfo.marker.next_restart_num)) {
/* 3572 */       return false;
/*      */     }
/*      */     
/*      */ 
/* 3576 */     cinfo.marker.next_restart_num = (cinfo.marker.next_restart_num + 1 & 0x7);
/*      */     
/* 3578 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   static boolean jpeg_fill_bit_buffer(bitread_working_state state, int get_buffer, int bits_left, int nbits)
/*      */   {
/* 3585 */     byte[] buffer = state.buffer;
/* 3586 */     int bytes_in_buffer = state.bytes_in_buffer;
/* 3587 */     int bytes_offset = state.bytes_offset;
/* 3588 */     jpeg_decompress_struct cinfo = state.cinfo;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3594 */     if (cinfo.unread_marker == 0) {
/* 3595 */       while (bits_left < 25)
/*      */       {
/*      */ 
/*      */ 
/* 3599 */         if (bytes_offset == bytes_in_buffer) {
/* 3600 */           if (!fill_input_buffer(cinfo))
/* 3601 */             return false;
/* 3602 */           buffer = cinfo.buffer;
/* 3603 */           bytes_in_buffer = cinfo.bytes_in_buffer;
/* 3604 */           bytes_offset = cinfo.bytes_offset;
/*      */         }
/* 3606 */         int c = buffer[(bytes_offset++)] & 0xFF;
/*      */         
/*      */ 
/* 3609 */         if (c == 255)
/*      */         {
/*      */ 
/*      */ 
/*      */           do
/*      */           {
/*      */ 
/* 3616 */             if (bytes_offset == bytes_in_buffer) {
/* 3617 */               if (!fill_input_buffer(cinfo))
/* 3618 */                 return false;
/* 3619 */               buffer = cinfo.buffer;
/* 3620 */               bytes_in_buffer = cinfo.bytes_in_buffer;
/* 3621 */               bytes_offset = cinfo.bytes_offset;
/*      */             }
/* 3623 */             c = buffer[(bytes_offset++)] & 0xFF;
/* 3624 */           } while (c == 255);
/*      */           
/* 3626 */           if (c == 0)
/*      */           {
/* 3628 */             c = 255;
/*      */ 
/*      */ 
/*      */ 
/*      */           }
/*      */           else
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/* 3638 */             cinfo.unread_marker = c;
/*      */             
/*      */ 
/* 3641 */             if (nbits > bits_left)
/*      */             {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3647 */               if (!cinfo.entropy.insufficient_data)
/*      */               {
/* 3649 */                 cinfo.entropy.insufficient_data = true;
/*      */               }
/*      */               
/* 3652 */               get_buffer <<= 25 - bits_left;
/* 3653 */               bits_left = 25;
/*      */             }
/*      */             
/*      */ 
/* 3657 */             state.buffer = buffer;
/* 3658 */             state.bytes_in_buffer = bytes_in_buffer;
/* 3659 */             state.bytes_offset = bytes_offset;
/* 3660 */             state.get_buffer = get_buffer;
/* 3661 */             state.bits_left = bits_left;
/*      */             
/* 3663 */             return true;
/*      */           }
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 3669 */         get_buffer = get_buffer << 8 | c;
/* 3670 */         bits_left += 8;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3678 */     if (nbits > bits_left)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3684 */       if (!cinfo.entropy.insufficient_data)
/*      */       {
/* 3686 */         cinfo.entropy.insufficient_data = true;
/*      */       }
/*      */       
/* 3689 */       get_buffer <<= 25 - bits_left;
/* 3690 */       bits_left = 25;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 3695 */     state.buffer = buffer;
/* 3696 */     state.bytes_in_buffer = bytes_in_buffer;
/* 3697 */     state.bytes_offset = bytes_offset;
/* 3698 */     state.get_buffer = get_buffer;
/* 3699 */     state.bits_left = bits_left;
/*      */     
/* 3701 */     return true;
/*      */   }
/*      */   
/*      */   static int jpeg_huff_decode(bitread_working_state state, int get_buffer, int bits_left, d_derived_tbl htbl, int min_bits) {
/* 3705 */     int l = min_bits;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3713 */     if (bits_left < l) {
/* 3714 */       if (!jpeg_fill_bit_buffer(state, get_buffer, bits_left, l)) {
/* 3715 */         return -1;
/*      */       }
/* 3717 */       get_buffer = state.get_buffer;bits_left = state.bits_left;
/*      */     }
/*      */     
/*      */ 
/* 3721 */     int code = get_buffer >> bits_left -= l & (1 << l) - 1;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 3726 */     while (code > htbl.maxcode[l]) {
/* 3727 */       code <<= 1;
/*      */       
/*      */ 
/* 3730 */       if (bits_left < 1) {
/* 3731 */         if (!jpeg_fill_bit_buffer(state, get_buffer, bits_left, 1)) {
/* 3732 */           return -1;
/*      */         }
/* 3734 */         get_buffer = state.get_buffer;bits_left = state.bits_left;
/*      */       }
/*      */       
/*      */ 
/* 3738 */       code |= get_buffer >> --bits_left & 0x1;
/* 3739 */       l++;
/*      */     }
/*      */     
/*      */ 
/* 3743 */     state.get_buffer = get_buffer;
/* 3744 */     state.bits_left = bits_left;
/*      */     
/*      */ 
/*      */ 
/* 3748 */     if (l > 16)
/*      */     {
/* 3750 */       return 0;
/*      */     }
/*      */     
/* 3753 */     return htbl.pub.huffval[(code + htbl.valoffset[l])] & 0xFF;
/*      */   }
/*      */   
/*      */   static int decompress_onepass(jpeg_decompress_struct cinfo, byte[][][] output_buf, int[] output_buf_offset) {
/* 3757 */     jpeg_d_coef_controller coef = cinfo.coef;
/*      */     
/* 3759 */     int last_MCU_col = cinfo.MCUs_per_row - 1;
/* 3760 */     int last_iMCU_row = cinfo.total_iMCU_rows - 1;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3768 */     for (int yoffset = coef.MCU_vert_offset; yoffset < coef.MCU_rows_per_iMCU_row; yoffset++) {
/* 3769 */       for (int MCU_col_num = coef.MCU_ctr; MCU_col_num <= last_MCU_col; MCU_col_num++)
/*      */       {
/* 3771 */         for (int i = 0; i < cinfo.blocks_in_MCU; i++) {
/* 3772 */           short[] blk = coef.MCU_buffer[i];
/* 3773 */           for (int j = 0; j < blk.length; j++) {
/* 3774 */             blk[j] = 0;
/*      */           }
/*      */         }
/* 3777 */         if (!cinfo.entropy.decode_mcu(cinfo, coef.MCU_buffer))
/*      */         {
/* 3779 */           coef.MCU_vert_offset = yoffset;
/* 3780 */           coef.MCU_ctr = MCU_col_num;
/* 3781 */           return 0;
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3788 */         int blkn = 0;
/* 3789 */         for (int ci = 0; ci < cinfo.comps_in_scan; ci++) {
/* 3790 */           jpeg_component_info compptr = cinfo.cur_comp_info[ci];
/*      */           
/* 3792 */           if (!compptr.component_needed) {
/* 3793 */             blkn += compptr.MCU_blocks;
/*      */           }
/*      */           else
/*      */           {
/* 3797 */             int useful_width = MCU_col_num < last_MCU_col ? compptr.MCU_width : compptr.last_col_width;
/* 3798 */             byte[][] output_ptr = output_buf[compptr.component_index];
/* 3799 */             int output_ptr_offset = output_buf_offset[compptr.component_index] + yoffset * compptr.DCT_scaled_size;
/* 3800 */             int start_col = MCU_col_num * compptr.MCU_sample_width;
/* 3801 */             for (int yindex = 0; yindex < compptr.MCU_height; yindex++) {
/* 3802 */               if ((cinfo.input_iMCU_row < last_iMCU_row) || (yoffset + yindex < compptr.last_row_height)) {
/* 3803 */                 int output_col = start_col;
/* 3804 */                 for (int xindex = 0; xindex < useful_width; xindex++) {
/* 3805 */                   jpeg_idct_islow(cinfo, compptr, coef.MCU_buffer[(blkn + xindex)], output_ptr, output_ptr_offset, output_col);
/* 3806 */                   output_col += compptr.DCT_scaled_size;
/*      */                 }
/*      */               }
/* 3809 */               blkn += compptr.MCU_width;
/* 3810 */               output_ptr_offset += compptr.DCT_scaled_size;
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/* 3815 */       coef.MCU_ctr = 0;
/*      */     }
/*      */     
/* 3818 */     cinfo.output_iMCU_row += 1;
/* 3819 */     if (++cinfo.input_iMCU_row < cinfo.total_iMCU_rows) {
/* 3820 */       coef.start_iMCU_row(cinfo);
/* 3821 */       return 3;
/*      */     }
/*      */     
/* 3824 */     finish_input_pass(cinfo);
/* 3825 */     return 4;
/*      */   }
/*      */   
/*      */   static int decompress_smooth_data(jpeg_decompress_struct cinfo, byte[][][] output_buf, int[] output_buf_offset) {
/* 3829 */     jpeg_d_coef_controller coef = cinfo.coef;
/* 3830 */     int last_iMCU_row = cinfo.total_iMCU_rows - 1;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3840 */     short[] workspace = coef.workspace;
/* 3841 */     if (workspace == null) { workspace = coef.workspace = new short[64];
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3849 */     while ((cinfo.input_scan_number <= cinfo.output_scan_number) && (!cinfo.inputctl.eoi_reached)) {
/* 3850 */       if (cinfo.input_scan_number == cinfo.output_scan_number)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3856 */         int delta = cinfo.Ss == 0 ? 1 : 0;
/* 3857 */         if (cinfo.input_iMCU_row > cinfo.output_iMCU_row + delta) {
/*      */           break;
/*      */         }
/* 3860 */       } else if (consume_input(cinfo) == 0) {
/* 3861 */         return 0;
/*      */       }
/*      */     }
/*      */     
/* 3865 */     for (int ci = 0; ci < cinfo.num_components; ci++) {
/* 3866 */       jpeg_component_info compptr = cinfo.comp_info[ci];
/*      */       
/* 3868 */       if (compptr.component_needed) { boolean last_row;
/*      */         int block_rows;
/*      */         boolean last_row;
/* 3871 */         if (cinfo.output_iMCU_row < last_iMCU_row) {
/* 3872 */           int block_rows = compptr.v_samp_factor;
/*      */           
/* 3874 */           last_row = false;
/*      */         }
/*      */         else {
/* 3877 */           block_rows = compptr.height_in_blocks % compptr.v_samp_factor;
/* 3878 */           if (block_rows == 0) { block_rows = compptr.v_samp_factor;
/*      */           }
/* 3880 */           last_row = true; }
/*      */         boolean first_row;
/*      */         short[][][] buffer;
/*      */         int buffer_offset;
/* 3884 */         boolean first_row; if (cinfo.output_iMCU_row > 0)
/*      */         {
/* 3886 */           short[][][] buffer = coef.whole_image[ci];
/* 3887 */           int buffer_offset = (cinfo.output_iMCU_row - 1) * compptr.v_samp_factor;
/* 3888 */           buffer_offset += compptr.v_samp_factor;
/* 3889 */           first_row = false;
/*      */         } else {
/* 3891 */           buffer = coef.whole_image[ci];
/* 3892 */           buffer_offset = 0;
/* 3893 */           first_row = true;
/*      */         }
/*      */         
/* 3896 */         int[] coef_bits = coef.coef_bits_latch;
/* 3897 */         int coef_offset = ci * 6;
/* 3898 */         JQUANT_TBL quanttbl = compptr.quant_table;
/* 3899 */         int Q00 = quanttbl.quantval[0];
/* 3900 */         int Q01 = quanttbl.quantval[1];
/* 3901 */         int Q10 = quanttbl.quantval[8];
/* 3902 */         int Q20 = quanttbl.quantval[16];
/* 3903 */         int Q11 = quanttbl.quantval[9];
/* 3904 */         int Q02 = quanttbl.quantval[2];
/*      */         
/* 3906 */         byte[][] output_ptr = output_buf[ci];
/* 3907 */         int output_ptr_offset = output_buf_offset[ci];
/*      */         
/* 3909 */         for (int block_row = 0; block_row < block_rows; block_row++) {
/* 3910 */           short[][] buffer_ptr = buffer[(block_row + buffer_offset)];
/* 3911 */           int buffer_ptr_offset = 0;int prev_block_row_offset = 0;int next_block_row_offset = 0;
/* 3912 */           short[][] prev_block_row; if ((first_row) && (block_row == 0)) {
/* 3913 */             short[][] prev_block_row = buffer_ptr;
/* 3914 */             prev_block_row_offset = buffer_ptr_offset;
/*      */           } else {
/* 3916 */             prev_block_row = buffer[(block_row - 1 + buffer_offset)];
/* 3917 */             prev_block_row_offset = 0; }
/*      */           short[][] next_block_row;
/* 3919 */           if ((last_row) && (block_row == block_rows - 1)) {
/* 3920 */             short[][] next_block_row = buffer_ptr;
/* 3921 */             next_block_row_offset = buffer_ptr_offset;
/*      */           } else {
/* 3923 */             next_block_row = buffer[(block_row + 1 + buffer_offset)];
/* 3924 */             next_block_row_offset = 0;
/*      */           }
/*      */           
/*      */           int DC3;
/*      */           int DC2;
/* 3929 */           int DC1 = DC2 = DC3 = prev_block_row[(0 + prev_block_row_offset)][0];
/* 3930 */           int DC6; int DC5; int DC4 = DC5 = DC6 = buffer_ptr[(0 + buffer_ptr_offset)][0];
/* 3931 */           int DC9; int DC8; int DC7 = DC8 = DC9 = next_block_row[(0 + next_block_row_offset)][0];
/* 3932 */           int output_col = 0;
/* 3933 */           int last_block_column = compptr.width_in_blocks - 1;
/* 3934 */           for (int block_num = 0; block_num <= last_block_column; block_num++)
/*      */           {
/*      */ 
/* 3937 */             System.arraycopy(buffer_ptr[buffer_ptr_offset], 0, workspace, 0, workspace.length);
/*      */             
/* 3939 */             if (block_num < last_block_column) {
/* 3940 */               DC3 = prev_block_row[(1 + prev_block_row_offset)][0];
/* 3941 */               DC6 = buffer_ptr[(1 + buffer_ptr_offset)][0];
/* 3942 */               DC9 = next_block_row[(1 + next_block_row_offset)][0];
/*      */             }
/*      */             
/*      */ 
/*      */             int Al;
/*      */             
/*      */ 
/* 3949 */             if (((Al = coef_bits[(1 + coef_offset)]) != 0) && (workspace[1] == 0)) {
/* 3950 */               int num = 36 * Q00 * (DC4 - DC6);
/* 3951 */               int pred; if (num >= 0) {
/* 3952 */                 int pred = ((Q01 << 7) + num) / (Q01 << 8);
/* 3953 */                 if ((Al > 0) && (pred >= 1 << Al))
/* 3954 */                   pred = (1 << Al) - 1;
/*      */               } else {
/* 3956 */                 pred = ((Q01 << 7) - num) / (Q01 << 8);
/* 3957 */                 if ((Al > 0) && (pred >= 1 << Al))
/* 3958 */                   pred = (1 << Al) - 1;
/* 3959 */                 pred = -pred;
/*      */               }
/* 3961 */               workspace[1] = ((short)pred);
/*      */             }
/*      */             
/* 3964 */             if (((Al = coef_bits[(2 + coef_offset)]) != 0) && (workspace[8] == 0)) {
/* 3965 */               int num = 36 * Q00 * (DC2 - DC8);
/* 3966 */               int pred; if (num >= 0) {
/* 3967 */                 int pred = ((Q10 << 7) + num) / (Q10 << 8);
/* 3968 */                 if ((Al > 0) && (pred >= 1 << Al))
/* 3969 */                   pred = (1 << Al) - 1;
/*      */               } else {
/* 3971 */                 pred = ((Q10 << 7) - num) / (Q10 << 8);
/* 3972 */                 if ((Al > 0) && (pred >= 1 << Al))
/* 3973 */                   pred = (1 << Al) - 1;
/* 3974 */                 pred = -pred;
/*      */               }
/* 3976 */               workspace[8] = ((short)pred);
/*      */             }
/*      */             
/* 3979 */             if (((Al = coef_bits[(3 + coef_offset)]) != 0) && (workspace[16] == 0)) {
/* 3980 */               int num = 9 * Q00 * (DC2 + DC8 - 2 * DC5);
/* 3981 */               int pred; if (num >= 0) {
/* 3982 */                 int pred = ((Q20 << 7) + num) / (Q20 << 8);
/* 3983 */                 if ((Al > 0) && (pred >= 1 << Al))
/* 3984 */                   pred = (1 << Al) - 1;
/*      */               } else {
/* 3986 */                 pred = ((Q20 << 7) - num) / (Q20 << 8);
/* 3987 */                 if ((Al > 0) && (pred >= 1 << Al))
/* 3988 */                   pred = (1 << Al) - 1;
/* 3989 */                 pred = -pred;
/*      */               }
/* 3991 */               workspace[16] = ((short)pred);
/*      */             }
/*      */             
/* 3994 */             if (((Al = coef_bits[(4 + coef_offset)]) != 0) && (workspace[9] == 0)) {
/* 3995 */               int num = 5 * Q00 * (DC1 - DC3 - DC7 + DC9);
/* 3996 */               int pred; if (num >= 0) {
/* 3997 */                 int pred = ((Q11 << 7) + num) / (Q11 << 8);
/* 3998 */                 if ((Al > 0) && (pred >= 1 << Al))
/* 3999 */                   pred = (1 << Al) - 1;
/*      */               } else {
/* 4001 */                 pred = ((Q11 << 7) - num) / (Q11 << 8);
/* 4002 */                 if ((Al > 0) && (pred >= 1 << Al))
/* 4003 */                   pred = (1 << Al) - 1;
/* 4004 */                 pred = -pred;
/*      */               }
/* 4006 */               workspace[9] = ((short)pred);
/*      */             }
/*      */             
/* 4009 */             if (((Al = coef_bits[(5 + coef_offset)]) != 0) && (workspace[2] == 0)) {
/* 4010 */               int num = 9 * Q00 * (DC4 + DC6 - 2 * DC5);
/* 4011 */               int pred; if (num >= 0) {
/* 4012 */                 int pred = ((Q02 << 7) + num) / (Q02 << 8);
/* 4013 */                 if ((Al > 0) && (pred >= 1 << Al))
/* 4014 */                   pred = (1 << Al) - 1;
/*      */               } else {
/* 4016 */                 pred = ((Q02 << 7) - num) / (Q02 << 8);
/* 4017 */                 if ((Al > 0) && (pred >= 1 << Al))
/* 4018 */                   pred = (1 << Al) - 1;
/* 4019 */                 pred = -pred;
/*      */               }
/* 4021 */               workspace[2] = ((short)pred);
/*      */             }
/*      */             
/* 4024 */             jpeg_idct_islow(cinfo, compptr, workspace, output_ptr, output_ptr_offset, output_col);
/*      */             
/* 4026 */             DC1 = DC2;DC2 = DC3;
/* 4027 */             DC4 = DC5;DC5 = DC6;
/* 4028 */             DC7 = DC8;DC8 = DC9;
/* 4029 */             buffer_ptr_offset++;prev_block_row_offset++;next_block_row_offset++;
/* 4030 */             output_col += compptr.DCT_scaled_size;
/*      */           }
/* 4032 */           output_ptr_offset += compptr.DCT_scaled_size;
/*      */         }
/*      */       }
/*      */     }
/* 4036 */     if (++cinfo.output_iMCU_row < cinfo.total_iMCU_rows)
/* 4037 */       return 3;
/* 4038 */     return 4;
/*      */   }
/*      */   
/*      */   static int decompress_data(jpeg_decompress_struct cinfo, byte[][][] output_buf, int[] output_buf_offset) {
/* 4042 */     jpeg_d_coef_controller coef = cinfo.coef;
/* 4043 */     int last_iMCU_row = cinfo.total_iMCU_rows - 1;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4054 */     while ((cinfo.input_scan_number < cinfo.output_scan_number) || ((cinfo.input_scan_number == cinfo.output_scan_number) && (cinfo.input_iMCU_row <= cinfo.output_iMCU_row)))
/*      */     {
/*      */ 
/*      */ 
/* 4058 */       if (consume_input(cinfo) == 0) {
/* 4059 */         return 0;
/*      */       }
/*      */     }
/*      */     
/* 4063 */     for (int ci = 0; ci < cinfo.num_components; ci++) {
/* 4064 */       jpeg_component_info compptr = cinfo.comp_info[ci];
/*      */       
/* 4066 */       if (compptr.component_needed)
/*      */       {
/*      */ 
/* 4069 */         short[][][] buffer = coef.whole_image[ci];
/* 4070 */         int buffer_offset = cinfo.output_iMCU_row * compptr.v_samp_factor;
/*      */         int block_rows;
/* 4072 */         int block_rows; if (cinfo.output_iMCU_row < last_iMCU_row) {
/* 4073 */           block_rows = compptr.v_samp_factor;
/*      */         }
/*      */         else {
/* 4076 */           block_rows = compptr.height_in_blocks % compptr.v_samp_factor;
/* 4077 */           if (block_rows == 0) { block_rows = compptr.v_samp_factor;
/*      */           }
/*      */         }
/* 4080 */         byte[][] output_ptr = output_buf[ci];
/* 4081 */         int output_ptr_offset = output_buf_offset[ci];
/*      */         
/* 4083 */         for (int block_row = 0; block_row < block_rows; block_row++) {
/* 4084 */           short[][] buffer_ptr = buffer[(block_row + buffer_offset)];
/* 4085 */           int buffer_ptr_offset = 0;
/* 4086 */           int output_col = 0;
/* 4087 */           for (int block_num = 0; block_num < compptr.width_in_blocks; block_num++) {
/* 4088 */             jpeg_idct_islow(cinfo, compptr, buffer_ptr[buffer_ptr_offset], output_ptr, output_ptr_offset, output_col);
/*      */             
/* 4090 */             buffer_ptr_offset++;
/* 4091 */             output_col += compptr.DCT_scaled_size;
/*      */           }
/* 4093 */           output_ptr_offset += compptr.DCT_scaled_size;
/*      */         }
/*      */       }
/*      */     }
/* 4097 */     if (++cinfo.output_iMCU_row < cinfo.total_iMCU_rows)
/* 4098 */       return 3;
/* 4099 */     return 4;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static void post_process_data(jpeg_decompress_struct cinfo, byte[][][] input_buf, int[] input_buf_offset, int[] in_row_group_ctr, int in_row_groups_avail, byte[][] output_buf, int[] out_row_ctr, int out_rows_avail)
/*      */   {
/* 4108 */     upsample(cinfo, input_buf, input_buf_offset, in_row_group_ctr, in_row_groups_avail, output_buf, out_row_ctr, out_rows_avail);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static void set_bottom_pointers(jpeg_decompress_struct cinfo)
/*      */   {
/* 4117 */     jpeg_d_main_controller main = cinfo.main;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 4122 */     for (int ci = 0; ci < cinfo.num_components; ci++) {
/* 4123 */       jpeg_component_info compptr = cinfo.comp_info[ci];
/*      */       
/* 4125 */       int iMCUheight = compptr.v_samp_factor * compptr.DCT_scaled_size;
/* 4126 */       int rgroup = iMCUheight / cinfo.min_DCT_scaled_size;
/*      */       
/* 4128 */       int rows_left = compptr.downsampled_height % iMCUheight;
/* 4129 */       if (rows_left == 0) { rows_left = iMCUheight;
/*      */       }
/*      */       
/*      */ 
/* 4133 */       if (ci == 0) {
/* 4134 */         main.rowgroups_avail = ((rows_left - 1) / rgroup + 1);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 4139 */       byte[][] xbuf = main.xbuffer[main.whichptr][ci];
/* 4140 */       int xbuf_offset = main.xbuffer_offset[main.whichptr][ci];
/* 4141 */       for (int i = 0; i < rgroup * 2; i++) {
/* 4142 */         xbuf[(rows_left + i + xbuf_offset)] = xbuf[(rows_left - 1 + xbuf_offset)];
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   static void set_wraparound_pointers(jpeg_decompress_struct cinfo)
/*      */   {
/* 4152 */     jpeg_d_main_controller main = cinfo.main;
/*      */     
/* 4154 */     int M = cinfo.min_DCT_scaled_size;
/*      */     
/*      */ 
/*      */ 
/* 4158 */     for (int ci = 0; ci < cinfo.num_components; ci++) {
/* 4159 */       jpeg_component_info compptr = cinfo.comp_info[ci];
/* 4160 */       int rgroup = compptr.v_samp_factor * compptr.DCT_scaled_size / cinfo.min_DCT_scaled_size;
/* 4161 */       byte[][] xbuf0 = main.xbuffer[0][ci];
/* 4162 */       int xbuf0_offset = main.xbuffer_offset[0][ci];
/* 4163 */       byte[][] xbuf1 = main.xbuffer[1][ci];
/* 4164 */       int xbuf1_offset = main.xbuffer_offset[1][ci];
/* 4165 */       for (int i = 0; i < rgroup; i++) {
/* 4166 */         xbuf0[(i - rgroup + xbuf0_offset)] = xbuf0[(rgroup * (M + 1) + i + xbuf0_offset)];
/* 4167 */         xbuf1[(i - rgroup + xbuf1_offset)] = xbuf1[(rgroup * (M + 1) + i + xbuf1_offset)];
/* 4168 */         xbuf0[(rgroup * (M + 2) + i + xbuf0_offset)] = xbuf0[(i + xbuf0_offset)];
/* 4169 */         xbuf1[(rgroup * (M + 2) + i + xbuf1_offset)] = xbuf1[(i + xbuf1_offset)];
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static void process_data_crank_post(jpeg_decompress_struct cinfo, byte[][] output_buf, int[] out_row_ctr, int out_rows_avail) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   static void process_data_context_main(jpeg_decompress_struct cinfo, byte[][] output_buf, int[] out_row_ctr, int out_rows_avail)
/*      */   {
/* 4185 */     jpeg_d_main_controller main = cinfo.main;
/*      */     
/*      */ 
/* 4188 */     if (!main.buffer_full) { int result;
/*      */       int result;
/* 4190 */       int result; int result; switch (cinfo.coef.decompress_data) {
/*      */       case 0: 
/* 4192 */         result = decompress_data(cinfo, main.xbuffer[main.whichptr], main.xbuffer_offset[main.whichptr]);
/* 4193 */         break;
/*      */       case 1: 
/* 4195 */         result = decompress_smooth_data(cinfo, main.xbuffer[main.whichptr], main.xbuffer_offset[main.whichptr]);
/* 4196 */         break;
/*      */       case 2: 
/* 4198 */         result = decompress_onepass(cinfo, main.xbuffer[main.whichptr], main.xbuffer_offset[main.whichptr]);
/* 4199 */         break;
/* 4200 */       default:  result = 0;
/*      */       }
/* 4202 */       if (result == 0)
/* 4203 */         return;
/* 4204 */       main.buffer_full = true;
/* 4205 */       main.iMCU_row_ctr += 1;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4213 */     switch (main.context_state)
/*      */     {
/*      */     case 2: 
/* 4216 */       post_process_data(cinfo, main.xbuffer[main.whichptr], main.xbuffer_offset[main.whichptr], main.rowgroup_ctr, main.rowgroups_avail, output_buf, out_row_ctr, out_rows_avail);
/* 4217 */       if (main.rowgroup_ctr[0] < main.rowgroups_avail)
/* 4218 */         return;
/* 4219 */       main.context_state = 0;
/* 4220 */       if (out_row_ctr[0] >= out_rows_avail) {
/* 4221 */         return;
/*      */       }
/*      */     
/*      */     case 0: 
/* 4225 */       main.rowgroup_ctr[0] = 0;
/* 4226 */       main.rowgroups_avail = (cinfo.min_DCT_scaled_size - 1);
/*      */       
/*      */ 
/*      */ 
/* 4230 */       if (main.iMCU_row_ctr == cinfo.total_iMCU_rows)
/* 4231 */         set_bottom_pointers(cinfo);
/* 4232 */       main.context_state = 1;
/*      */     
/*      */ 
/*      */     case 1: 
/* 4236 */       post_process_data(cinfo, main.xbuffer[main.whichptr], main.xbuffer_offset[main.whichptr], main.rowgroup_ctr, main.rowgroups_avail, output_buf, out_row_ctr, out_rows_avail);
/* 4237 */       if (main.rowgroup_ctr[0] < main.rowgroups_avail) {
/* 4238 */         return;
/*      */       }
/* 4240 */       if (main.iMCU_row_ctr == 1) {
/* 4241 */         set_wraparound_pointers(cinfo);
/*      */       }
/* 4243 */       main.whichptr ^= 0x1;
/* 4244 */       main.buffer_full = false;
/*      */       
/*      */ 
/* 4247 */       main.rowgroup_ctr[0] = (cinfo.min_DCT_scaled_size + 1);
/* 4248 */       main.rowgroups_avail = (cinfo.min_DCT_scaled_size + 2);
/* 4249 */       main.context_state = 2;
/*      */     }
/*      */   }
/*      */   
/*      */   static void process_data_simple_main(jpeg_decompress_struct cinfo, byte[][] output_buf, int[] out_row_ctr, int out_rows_avail) {
/* 4254 */     jpeg_d_main_controller main = cinfo.main;
/*      */     
/*      */ 
/*      */ 
/* 4258 */     if (!main.buffer_full) { int result;
/*      */       int result;
/* 4260 */       int result; int result; switch (cinfo.coef.decompress_data) {
/*      */       case 0: 
/* 4262 */         result = decompress_data(cinfo, main.buffer, main.buffer_offset);
/* 4263 */         break;
/*      */       case 1: 
/* 4265 */         result = decompress_smooth_data(cinfo, main.buffer, main.buffer_offset);
/* 4266 */         break;
/*      */       case 2: 
/* 4268 */         result = decompress_onepass(cinfo, main.buffer, main.buffer_offset);
/* 4269 */         break;
/* 4270 */       default:  result = 0;
/*      */       }
/* 4272 */       if (result == 0)
/* 4273 */         return;
/* 4274 */       main.buffer_full = true;
/*      */     }
/*      */     
/*      */ 
/* 4278 */     int rowgroups_avail = cinfo.min_DCT_scaled_size;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4285 */     post_process_data(cinfo, main.buffer, main.buffer_offset, main.rowgroup_ctr, rowgroups_avail, output_buf, out_row_ctr, out_rows_avail);
/*      */     
/*      */ 
/* 4288 */     if (main.rowgroup_ctr[0] >= rowgroups_avail) {
/* 4289 */       main.buffer_full = false;
/* 4290 */       main.rowgroup_ctr[0] = 0;
/*      */     }
/*      */   }
/*      */   
/*      */   static int jpeg_read_scanlines(jpeg_decompress_struct cinfo, byte[][] scanlines, int max_lines)
/*      */   {
/* 4296 */     if (cinfo.global_state != 205) {
/* 4297 */       error();
/*      */     }
/* 4299 */     if (cinfo.output_scanline >= cinfo.output_height)
/*      */     {
/* 4301 */       return 0;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4312 */     cinfo.row_ctr[0] = 0;
/* 4313 */     switch (cinfo.main.process_data) {
/*      */     case 0: 
/* 4315 */       process_data_simple_main(cinfo, scanlines, cinfo.row_ctr, max_lines);
/* 4316 */       break;
/*      */     case 1: 
/* 4318 */       process_data_context_main(cinfo, scanlines, cinfo.row_ctr, max_lines);
/* 4319 */       break;
/*      */     case 2: 
/* 4321 */       process_data_crank_post(cinfo, scanlines, cinfo.row_ctr, max_lines);
/* 4322 */       break;
/* 4323 */     default:  error();
/*      */     }
/* 4325 */     cinfo.output_scanline += cinfo.row_ctr[0];
/* 4326 */     return cinfo.row_ctr[0];
/*      */   }
/*      */   
/*      */   static boolean output_pass_setup(jpeg_decompress_struct cinfo)
/*      */   {
/* 4331 */     if (cinfo.global_state != 204)
/*      */     {
/* 4333 */       prepare_for_output_pass(cinfo);
/* 4334 */       cinfo.output_scanline = 0;
/* 4335 */       cinfo.global_state = 204;
/*      */     }
/*      */     
/* 4338 */     while (cinfo.master.is_dummy_pass) {
/* 4339 */       error();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4368 */     cinfo.global_state = (cinfo.raw_data_out ? 206 : 205);
/* 4369 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   static boolean get_dht(jpeg_decompress_struct cinfo)
/*      */   {
/* 4376 */     byte[] bits = new byte[17];
/* 4377 */     byte[] huffval = new byte['Ā'];
/*      */     
/*      */ 
/*      */ 
/* 4381 */     if (cinfo.bytes_offset == cinfo.bytes_in_buffer) fill_input_buffer(cinfo);
/* 4382 */     int length = (cinfo.buffer[(cinfo.bytes_offset++)] & 0xFF) << 8;
/* 4383 */     if (cinfo.bytes_offset == cinfo.bytes_in_buffer) fill_input_buffer(cinfo);
/* 4384 */     length |= cinfo.buffer[(cinfo.bytes_offset++)] & 0xFF;
/* 4385 */     length -= 2;
/*      */     
/* 4387 */     while (length > 16) {
/* 4388 */       if (cinfo.bytes_offset == cinfo.bytes_in_buffer) fill_input_buffer(cinfo);
/* 4389 */       int index = cinfo.buffer[(cinfo.bytes_offset++)] & 0xFF;
/*      */       
/*      */ 
/*      */ 
/* 4393 */       bits[0] = 0;
/* 4394 */       int count = 0;
/* 4395 */       for (int i = 1; i <= 16; i++) {
/* 4396 */         if (cinfo.bytes_offset == cinfo.bytes_in_buffer) fill_input_buffer(cinfo);
/* 4397 */         bits[i] = cinfo.buffer[(cinfo.bytes_offset++)];
/* 4398 */         count += (bits[i] & 0xFF);
/*      */       }
/*      */       
/* 4401 */       length -= 17;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4413 */       if ((count > 256) || (count > length)) {
/* 4414 */         error();
/*      */       }
/*      */       
/* 4417 */       for (i = 0; i < count; i++) {
/* 4418 */         if (cinfo.bytes_offset == cinfo.bytes_in_buffer) fill_input_buffer(cinfo);
/* 4419 */         huffval[i] = cinfo.buffer[(cinfo.bytes_offset++)];
/*      */       }
/*      */       
/* 4422 */       length -= count;
/*      */       JHUFF_TBL htblptr;
/* 4424 */       JHUFF_TBL htblptr; if ((index & 0x10) != 0) {
/* 4425 */         index -= 16;
/* 4426 */         htblptr = cinfo.ac_huff_tbl_ptrs[index] = new JHUFF_TBL();
/*      */       } else {
/* 4428 */         htblptr = cinfo.dc_huff_tbl_ptrs[index] = new JHUFF_TBL();
/*      */       }
/*      */       
/* 4431 */       if ((index < 0) || (index >= 4)) {
/* 4432 */         error();
/*      */       }
/*      */       
/* 4435 */       System.arraycopy(bits, 0, htblptr.bits, 0, bits.length);
/* 4436 */       System.arraycopy(huffval, 0, htblptr.huffval, 0, huffval.length);
/*      */     }
/*      */     
/* 4439 */     if (length != 0) {
/* 4440 */       error();
/*      */     }
/*      */     
/* 4443 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static boolean get_dqt(jpeg_decompress_struct cinfo)
/*      */   {
/* 4455 */     if (cinfo.bytes_offset == cinfo.bytes_in_buffer) fill_input_buffer(cinfo);
/* 4456 */     int length = (cinfo.buffer[(cinfo.bytes_offset++)] & 0xFF) << 8;
/* 4457 */     if (cinfo.bytes_offset == cinfo.bytes_in_buffer) fill_input_buffer(cinfo);
/* 4458 */     length |= cinfo.buffer[(cinfo.bytes_offset++)] & 0xFF;
/* 4459 */     length -= 2;
/*      */     
/* 4461 */     while (length > 0) {
/* 4462 */       if (cinfo.bytes_offset == cinfo.bytes_in_buffer) fill_input_buffer(cinfo);
/* 4463 */       int n = cinfo.buffer[(cinfo.bytes_offset++)] & 0xFF;
/* 4464 */       int prec = n >> 4;
/* 4465 */       n &= 0xF;
/*      */       
/*      */ 
/*      */ 
/* 4469 */       if (n >= 4) {
/* 4470 */         error();
/*      */       }
/*      */       
/* 4473 */       if (cinfo.quant_tbl_ptrs[n] == null)
/* 4474 */         cinfo.quant_tbl_ptrs[n] = new JQUANT_TBL();
/* 4475 */       JQUANT_TBL quant_ptr = cinfo.quant_tbl_ptrs[n];
/*      */       
/* 4477 */       for (int i = 0; i < 64; i++) { int tmp;
/* 4478 */         if (prec != 0) {
/* 4479 */           if (cinfo.bytes_offset == cinfo.bytes_in_buffer) fill_input_buffer(cinfo);
/* 4480 */           int tmp = (cinfo.buffer[(cinfo.bytes_offset++)] & 0xFF) << 8;
/* 4481 */           if (cinfo.bytes_offset == cinfo.bytes_in_buffer) fill_input_buffer(cinfo);
/* 4482 */           tmp |= cinfo.buffer[(cinfo.bytes_offset++)] & 0xFF;
/*      */         } else {
/* 4484 */           if (cinfo.bytes_offset == cinfo.bytes_in_buffer) fill_input_buffer(cinfo);
/* 4485 */           tmp = cinfo.buffer[(cinfo.bytes_offset++)] & 0xFF;
/*      */         }
/*      */         
/* 4488 */         quant_ptr.quantval[jpeg_natural_order[i]] = ((short)tmp);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4501 */       length -= 65;
/* 4502 */       if (prec != 0) { length -= 64;
/*      */       }
/*      */     }
/* 4505 */     if (length != 0) {
/* 4506 */       error();
/*      */     }
/*      */     
/* 4509 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static boolean get_dri(jpeg_decompress_struct cinfo)
/*      */   {
/* 4518 */     if (cinfo.bytes_offset == cinfo.bytes_in_buffer) fill_input_buffer(cinfo);
/* 4519 */     int length = (cinfo.buffer[(cinfo.bytes_offset++)] & 0xFF) << 8;
/* 4520 */     if (cinfo.bytes_offset == cinfo.bytes_in_buffer) fill_input_buffer(cinfo);
/* 4521 */     length |= cinfo.buffer[(cinfo.bytes_offset++)] & 0xFF;
/*      */     
/* 4523 */     if (length != 4) {
/* 4524 */       error();
/*      */     }
/*      */     
/* 4527 */     if (cinfo.bytes_offset == cinfo.bytes_in_buffer) fill_input_buffer(cinfo);
/* 4528 */     int tmp = (cinfo.buffer[(cinfo.bytes_offset++)] & 0xFF) << 8;
/* 4529 */     if (cinfo.bytes_offset == cinfo.bytes_in_buffer) fill_input_buffer(cinfo);
/* 4530 */     tmp |= cinfo.buffer[(cinfo.bytes_offset++)] & 0xFF;
/*      */     
/*      */ 
/*      */ 
/* 4534 */     cinfo.restart_interval = tmp;
/*      */     
/* 4536 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   static boolean get_dac(jpeg_decompress_struct cinfo)
/*      */   {
/* 4544 */     if (cinfo.bytes_offset == cinfo.bytes_in_buffer) fill_input_buffer(cinfo);
/* 4545 */     int length = (cinfo.buffer[(cinfo.bytes_offset++)] & 0xFF) << 8;
/* 4546 */     if (cinfo.bytes_offset == cinfo.bytes_in_buffer) fill_input_buffer(cinfo);
/* 4547 */     length |= cinfo.buffer[(cinfo.bytes_offset++)] & 0xFF;
/* 4548 */     length -= 2;
/*      */     
/* 4550 */     while (length > 0) {
/* 4551 */       if (cinfo.bytes_offset == cinfo.bytes_in_buffer) fill_input_buffer(cinfo);
/* 4552 */       int index = cinfo.buffer[(cinfo.bytes_offset++)] & 0xFF;
/* 4553 */       if (cinfo.bytes_offset == cinfo.bytes_in_buffer) fill_input_buffer(cinfo);
/* 4554 */       int val = cinfo.buffer[(cinfo.bytes_offset++)] & 0xFF;
/*      */       
/* 4556 */       length -= 2;
/*      */       
/*      */ 
/*      */ 
/* 4560 */       if ((index < 0) || (index >= 32)) {
/* 4561 */         error();
/*      */       }
/*      */       
/* 4564 */       if (index >= 16) {
/* 4565 */         cinfo.arith_ac_K[(index - 16)] = ((byte)val);
/*      */       } else {
/* 4567 */         cinfo.arith_dc_L[index] = ((byte)(val & 0xF));
/* 4568 */         cinfo.arith_dc_U[index] = ((byte)(val >> 4));
/* 4569 */         if (cinfo.arith_dc_L[index] > cinfo.arith_dc_U[index]) {
/* 4570 */           error();
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 4575 */     if (length != 0) {
/* 4576 */       error();
/*      */     }
/*      */     
/* 4579 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static boolean get_sos(jpeg_decompress_struct cinfo)
/*      */   {
/* 4588 */     jpeg_component_info compptr = null;
/*      */     
/* 4590 */     if (!cinfo.marker.saw_SOF) {
/* 4591 */       error();
/*      */     }
/*      */     
/* 4594 */     if (cinfo.bytes_offset == cinfo.bytes_in_buffer) fill_input_buffer(cinfo);
/* 4595 */     int length = (cinfo.buffer[(cinfo.bytes_offset++)] & 0xFF) << 8;
/* 4596 */     if (cinfo.bytes_offset == cinfo.bytes_in_buffer) fill_input_buffer(cinfo);
/* 4597 */     length |= cinfo.buffer[(cinfo.bytes_offset++)] & 0xFF;
/*      */     
/* 4599 */     if (cinfo.bytes_offset == cinfo.bytes_in_buffer) fill_input_buffer(cinfo);
/* 4600 */     int n = cinfo.buffer[(cinfo.bytes_offset++)] & 0xFF;
/*      */     
/*      */ 
/*      */ 
/* 4604 */     if ((length != n * 2 + 6) || (n < 1) || (n > 4)) {
/* 4605 */       error();
/*      */     }
/*      */     
/* 4608 */     cinfo.comps_in_scan = n;
/*      */     
/*      */ 
/*      */ 
/* 4612 */     for (int i = 0; i < n; i++) {
/* 4613 */       if (cinfo.bytes_offset == cinfo.bytes_in_buffer) fill_input_buffer(cinfo);
/* 4614 */       int cc = cinfo.buffer[(cinfo.bytes_offset++)] & 0xFF;
/* 4615 */       if (cinfo.bytes_offset == cinfo.bytes_in_buffer) fill_input_buffer(cinfo);
/* 4616 */       int c = cinfo.buffer[(cinfo.bytes_offset++)] & 0xFF;
/*      */       
/* 4618 */       for (int ci = 0; ci < cinfo.num_components; ci++) {
/* 4619 */         compptr = cinfo.comp_info[ci];
/* 4620 */         if (cc == compptr.component_id) {
/*      */           break;
/*      */         }
/*      */       }
/* 4624 */       if (ci == cinfo.num_components) {
/* 4625 */         error();
/*      */       }
/*      */       
/* 4628 */       cinfo.cur_comp_info[i] = compptr;
/* 4629 */       compptr.dc_tbl_no = (c >> 4 & 0xF);
/* 4630 */       compptr.ac_tbl_no = (c & 0xF);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 4636 */     if (cinfo.bytes_offset == cinfo.bytes_in_buffer) fill_input_buffer(cinfo);
/* 4637 */     int c = cinfo.buffer[(cinfo.bytes_offset++)] & 0xFF;
/* 4638 */     cinfo.Ss = c;
/* 4639 */     if (cinfo.bytes_offset == cinfo.bytes_in_buffer) fill_input_buffer(cinfo);
/* 4640 */     c = cinfo.buffer[(cinfo.bytes_offset++)] & 0xFF;
/* 4641 */     cinfo.Se = c;
/* 4642 */     if (cinfo.bytes_offset == cinfo.bytes_in_buffer) fill_input_buffer(cinfo);
/* 4643 */     c = cinfo.buffer[(cinfo.bytes_offset++)] & 0xFF;
/* 4644 */     cinfo.Ah = (c >> 4 & 0xF);
/* 4645 */     cinfo.Al = (c & 0xF);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 4650 */     cinfo.marker.next_restart_num = 0;
/*      */     
/*      */ 
/* 4653 */     cinfo.input_scan_number += 1;
/*      */     
/* 4655 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   static boolean get_sof(jpeg_decompress_struct cinfo, boolean is_prog, boolean is_arith)
/*      */   {
/* 4662 */     cinfo.progressive_mode = is_prog;
/* 4663 */     cinfo.arith_code = is_arith;
/*      */     
/* 4665 */     if (cinfo.bytes_offset == cinfo.bytes_in_buffer) fill_input_buffer(cinfo);
/* 4666 */     int length = (cinfo.buffer[(cinfo.bytes_offset++)] & 0xFF) << 8;
/* 4667 */     if (cinfo.bytes_offset == cinfo.bytes_in_buffer) fill_input_buffer(cinfo);
/* 4668 */     length |= cinfo.buffer[(cinfo.bytes_offset++)] & 0xFF;
/*      */     
/* 4670 */     if (cinfo.bytes_offset == cinfo.bytes_in_buffer) fill_input_buffer(cinfo);
/* 4671 */     cinfo.data_precision = (cinfo.buffer[(cinfo.bytes_offset++)] & 0xFF);
/*      */     
/* 4673 */     if (cinfo.bytes_offset == cinfo.bytes_in_buffer) fill_input_buffer(cinfo);
/* 4674 */     cinfo.image_height = ((cinfo.buffer[(cinfo.bytes_offset++)] & 0xFF) << 8);
/* 4675 */     if (cinfo.bytes_offset == cinfo.bytes_in_buffer) fill_input_buffer(cinfo);
/* 4676 */     cinfo.image_height |= cinfo.buffer[(cinfo.bytes_offset++)] & 0xFF;
/*      */     
/* 4678 */     if (cinfo.bytes_offset == cinfo.bytes_in_buffer) fill_input_buffer(cinfo);
/* 4679 */     cinfo.image_width = ((cinfo.buffer[(cinfo.bytes_offset++)] & 0xFF) << 8);
/* 4680 */     if (cinfo.bytes_offset == cinfo.bytes_in_buffer) fill_input_buffer(cinfo);
/* 4681 */     cinfo.image_width |= cinfo.buffer[(cinfo.bytes_offset++)] & 0xFF;
/*      */     
/* 4683 */     if (cinfo.bytes_offset == cinfo.bytes_in_buffer) fill_input_buffer(cinfo);
/* 4684 */     cinfo.num_components = (cinfo.buffer[(cinfo.bytes_offset++)] & 0xFF);
/*      */     
/* 4686 */     length -= 8;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4692 */     if (cinfo.marker.saw_SOF) {
/* 4693 */       error();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 4699 */     if ((cinfo.image_height <= 0) || (cinfo.image_width <= 0) || (cinfo.num_components <= 0)) {
/* 4700 */       error();
/*      */     }
/*      */     
/* 4703 */     if (length != cinfo.num_components * 3) {
/* 4704 */       error();
/*      */     }
/*      */     
/* 4707 */     if (cinfo.comp_info == null) {
/* 4708 */       cinfo.comp_info = new jpeg_component_info[cinfo.num_components];
/*      */     }
/* 4710 */     for (int ci = 0; ci < cinfo.num_components; ci++) {
/* 4711 */       jpeg_component_info compptr = cinfo.comp_info[ci] = new jpeg_component_info();
/* 4712 */       compptr.component_index = ci;
/* 4713 */       if (cinfo.bytes_offset == cinfo.bytes_in_buffer) fill_input_buffer(cinfo);
/* 4714 */       compptr.component_id = (cinfo.buffer[(cinfo.bytes_offset++)] & 0xFF);
/* 4715 */       if (cinfo.bytes_offset == cinfo.bytes_in_buffer) fill_input_buffer(cinfo);
/* 4716 */       int c = cinfo.buffer[(cinfo.bytes_offset++)] & 0xFF;
/* 4717 */       compptr.h_samp_factor = (c >> 4 & 0xF);
/* 4718 */       compptr.v_samp_factor = (c & 0xF);
/* 4719 */       if (cinfo.bytes_offset == cinfo.bytes_in_buffer) fill_input_buffer(cinfo);
/* 4720 */       compptr.quant_tbl_no = (cinfo.buffer[(cinfo.bytes_offset++)] & 0xFF);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4727 */     cinfo.marker.saw_SOF = true;
/*      */     
/* 4729 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   static void sep_upsample(jpeg_decompress_struct cinfo, byte[][][] input_buf, int[] input_buf_offset, int[] in_row_group_ctr, int in_row_groups_avail, byte[][] output_buf, int[] out_row_ctr, int out_rows_avail)
/*      */   {
/* 4736 */     jpeg_upsampler upsample = cinfo.upsample;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4742 */     if (upsample.next_row_out >= cinfo.max_v_samp_factor) {
/* 4743 */       for (int ci = 0; ci < cinfo.num_components; ci++) {
/* 4744 */         jpeg_component_info compptr = cinfo.comp_info[ci];
/*      */         
/*      */ 
/*      */ 
/* 4748 */         int offset = input_buf_offset[ci] + in_row_group_ctr[0] * upsample.rowgroup_height[ci];
/* 4749 */         switch (upsample.methods[ci]) {
/* 4750 */         case 0:  noop_upsample(cinfo, compptr, input_buf[ci], offset, upsample.color_buf, upsample.color_buf_offset, ci); break;
/* 4751 */         case 1:  fullsize_upsample(cinfo, compptr, input_buf[ci], offset, upsample.color_buf, upsample.color_buf_offset, ci); break;
/* 4752 */         case 2:  h2v1_fancy_upsample(cinfo, compptr, input_buf[ci], offset, upsample.color_buf, upsample.color_buf_offset, ci); break;
/* 4753 */         case 3:  h2v1_upsample(cinfo, compptr, input_buf[ci], offset, upsample.color_buf, upsample.color_buf_offset, ci); break;
/* 4754 */         case 4:  h2v2_fancy_upsample(cinfo, compptr, input_buf[ci], offset, upsample.color_buf, upsample.color_buf_offset, ci); break;
/* 4755 */         case 5:  h2v2_upsample(cinfo, compptr, input_buf[ci], offset, upsample.color_buf, upsample.color_buf_offset, ci); break;
/* 4756 */         case 6:  int_upsample(cinfo, compptr, input_buf[ci], offset, upsample.color_buf, upsample.color_buf_offset, ci);
/*      */         }
/*      */       }
/* 4759 */       upsample.next_row_out = 0;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 4765 */     int num_rows = cinfo.max_v_samp_factor - upsample.next_row_out;
/*      */     
/*      */ 
/*      */ 
/* 4769 */     if (num_rows > upsample.rows_to_go) {
/* 4770 */       num_rows = upsample.rows_to_go;
/*      */     }
/* 4772 */     out_rows_avail -= out_row_ctr[0];
/* 4773 */     if (num_rows > out_rows_avail) {
/* 4774 */       num_rows = out_rows_avail;
/*      */     }
/* 4776 */     switch (cinfo.cconvert.color_convert) {
/* 4777 */     case 0:  null_convert(cinfo, upsample.color_buf, upsample.color_buf_offset, upsample.next_row_out, output_buf, out_row_ctr[0], num_rows); break;
/* 4778 */     case 1:  grayscale_convert(cinfo, upsample.color_buf, upsample.color_buf_offset, upsample.next_row_out, output_buf, out_row_ctr[0], num_rows); break;
/* 4779 */     case 2:  ycc_rgb_convert(cinfo, upsample.color_buf, upsample.color_buf_offset, upsample.next_row_out, output_buf, out_row_ctr[0], num_rows); break;
/* 4780 */     case 3:  gray_rgb_convert(cinfo, upsample.color_buf, upsample.color_buf_offset, upsample.next_row_out, output_buf, out_row_ctr[0], num_rows); break;
/* 4781 */     case 4:  error();
/*      */     }
/*      */     
/*      */     
/* 4785 */     out_row_ctr[0] += num_rows;
/* 4786 */     upsample.rows_to_go -= num_rows;
/* 4787 */     upsample.next_row_out += num_rows;
/*      */     
/* 4789 */     if (upsample.next_row_out >= cinfo.max_v_samp_factor) {
/* 4790 */       in_row_group_ctr[0] += 1;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   static void noop_upsample(jpeg_decompress_struct cinfo, jpeg_component_info compptr, byte[][] input_data, int input_data_offset, byte[][][] output_data_ptr, int[] output_data_offset, int output_data_index)
/*      */   {
/* 4797 */     output_data_ptr[output_data_index] = ((byte[][])null);
/*      */   }
/*      */   
/*      */ 
/*      */   static void fullsize_upsample(jpeg_decompress_struct cinfo, jpeg_component_info compptr, byte[][] input_data, int input_data_offset, byte[][][] output_data_ptr, int[] output_data_offset, int output_data_index)
/*      */   {
/* 4803 */     output_data_ptr[output_data_index] = input_data;
/* 4804 */     output_data_offset[output_data_index] = input_data_offset;
/*      */   }
/*      */   
/*      */ 
/*      */   static void h2v1_upsample(jpeg_decompress_struct cinfo, jpeg_component_info compptr, byte[][] input_data, int input_data_offset, byte[][][] output_data_ptr, int[] output_data_offset, int output_data_index)
/*      */   {
/* 4810 */     byte[][] output_data = output_data_ptr[output_data_index];
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 4815 */     output_data_offset[output_data_index] = 0;
/*      */     
/* 4817 */     for (int inrow = 0; inrow < cinfo.max_v_samp_factor; inrow++) {
/* 4818 */       byte[] inptr = input_data[(inrow + input_data_offset)];
/* 4819 */       byte[] outptr = output_data[inrow];
/* 4820 */       int inptr_offset = 0;int outptr_offset = 0;
/* 4821 */       int outend = outptr_offset + cinfo.output_width;
/* 4822 */       while (outptr_offset < outend) {
/* 4823 */         byte invalue = inptr[(inptr_offset++)];
/* 4824 */         outptr[(outptr_offset++)] = invalue;
/* 4825 */         outptr[(outptr_offset++)] = invalue;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   static void h2v2_upsample(jpeg_decompress_struct cinfo, jpeg_component_info compptr, byte[][] input_data, int input_data_offset, byte[][][] output_data_ptr, int[] output_data_offset, int output_data_index)
/*      */   {
/* 4833 */     byte[][] output_data = output_data_ptr[output_data_index];
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 4838 */     output_data_offset[output_data_index] = 0;
/*      */     int outrow;
/* 4840 */     int inrow = outrow = 0;
/* 4841 */     while (outrow < cinfo.max_v_samp_factor) {
/* 4842 */       byte[] inptr = input_data[(inrow + input_data_offset)];
/* 4843 */       byte[] outptr = output_data[outrow];
/* 4844 */       int inptr_offset = 0;int outptr_offset = 0;
/* 4845 */       int outend = outptr_offset + cinfo.output_width;
/* 4846 */       while (outptr_offset < outend) {
/* 4847 */         byte invalue = inptr[(inptr_offset++)];
/* 4848 */         outptr[(outptr_offset++)] = invalue;
/* 4849 */         outptr[(outptr_offset++)] = invalue;
/*      */       }
/* 4851 */       jcopy_sample_rows(output_data, outrow, output_data, outrow + 1, 1, cinfo.output_width);
/* 4852 */       inrow++;
/* 4853 */       outrow += 2;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   static void h2v1_fancy_upsample(jpeg_decompress_struct cinfo, jpeg_component_info compptr, byte[][] input_data, int input_data_offset, byte[][][] output_data_ptr, int[] output_data_offset, int output_data_index)
/*      */   {
/* 4860 */     byte[][] output_data = output_data_ptr[output_data_index];
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 4865 */     output_data_offset[output_data_index] = 0;
/*      */     
/* 4867 */     for (int inrow = 0; inrow < cinfo.max_v_samp_factor; inrow++) {
/* 4868 */       byte[] inptr = input_data[(inrow + input_data_offset)];
/* 4869 */       byte[] outptr = output_data[inrow];
/* 4870 */       int inptr_offset = 0;int outptr_offset = 0;
/*      */       
/* 4872 */       int invalue = inptr[(inptr_offset++)] & 0xFF;
/* 4873 */       outptr[(outptr_offset++)] = ((byte)invalue);
/* 4874 */       outptr[(outptr_offset++)] = ((byte)(invalue * 3 + (inptr[inptr_offset] & 0xFF) + 2 >> 2));
/*      */       
/* 4876 */       for (int colctr = compptr.downsampled_width - 2; colctr > 0; colctr--)
/*      */       {
/* 4878 */         invalue = (inptr[(inptr_offset++)] & 0xFF) * 3;
/* 4879 */         outptr[(outptr_offset++)] = ((byte)(invalue + (inptr[(inptr_offset - 2)] & 0xFF) + 1 >> 2));
/* 4880 */         outptr[(outptr_offset++)] = ((byte)(invalue + (inptr[inptr_offset] & 0xFF) + 2 >> 2));
/*      */       }
/*      */       
/*      */ 
/* 4884 */       invalue = inptr[inptr_offset] & 0xFF;
/* 4885 */       outptr[(outptr_offset++)] = ((byte)(invalue * 3 + (inptr[(inptr_offset - 1)] & 0xFF) + 1 >> 2));
/* 4886 */       outptr[(outptr_offset++)] = ((byte)invalue);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   static void h2v2_fancy_upsample(jpeg_decompress_struct cinfo, jpeg_component_info compptr, byte[][] input_data, int input_data_offset, byte[][][] output_data_ptr, int[] output_data_offset, int output_data_index)
/*      */   {
/* 4893 */     byte[][] output_data = output_data_ptr[output_data_index];
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 4898 */     output_data_offset[output_data_index] = 0;
/*      */     int outrow;
/* 4900 */     int inrow = outrow = 0;
/* 4901 */     while (outrow < cinfo.max_v_samp_factor) {
/* 4902 */       for (int v = 0; v < 2; v++)
/*      */       {
/* 4904 */         byte[] inptr0 = input_data[(inrow + input_data_offset)];
/* 4905 */         byte[] inptr1; byte[] inptr1; if (v == 0) {
/* 4906 */           inptr1 = input_data[(inrow - 1 + input_data_offset)];
/*      */         } else
/* 4908 */           inptr1 = input_data[(inrow + 1 + input_data_offset)];
/* 4909 */         byte[] outptr = output_data[(outrow++)];
/*      */         
/* 4911 */         int inptr0_offset = 0;int inptr1_offset = 0;int outptr_offset = 0;
/*      */         
/*      */ 
/* 4914 */         int thiscolsum = (inptr0[(inptr0_offset++)] & 0xFF) * 3 + (inptr1[(inptr1_offset++)] & 0xFF);
/* 4915 */         int nextcolsum = (inptr0[(inptr0_offset++)] & 0xFF) * 3 + (inptr1[(inptr1_offset++)] & 0xFF);
/* 4916 */         outptr[(outptr_offset++)] = ((byte)(thiscolsum * 4 + 8 >> 4));
/* 4917 */         outptr[(outptr_offset++)] = ((byte)(thiscolsum * 3 + nextcolsum + 7 >> 4));
/* 4918 */         int lastcolsum = thiscolsum;thiscolsum = nextcolsum;
/*      */         
/* 4920 */         for (int colctr = compptr.downsampled_width - 2; colctr > 0; colctr--)
/*      */         {
/*      */ 
/* 4923 */           nextcolsum = (inptr0[(inptr0_offset++)] & 0xFF) * 3 + (inptr1[(inptr1_offset++)] & 0xFF);
/* 4924 */           outptr[(outptr_offset++)] = ((byte)(thiscolsum * 3 + lastcolsum + 8 >> 4));
/* 4925 */           outptr[(outptr_offset++)] = ((byte)(thiscolsum * 3 + nextcolsum + 7 >> 4));
/* 4926 */           lastcolsum = thiscolsum;thiscolsum = nextcolsum;
/*      */         }
/*      */         
/*      */ 
/* 4930 */         outptr[(outptr_offset++)] = ((byte)(thiscolsum * 3 + lastcolsum + 8 >> 4));
/* 4931 */         outptr[(outptr_offset++)] = ((byte)(thiscolsum * 4 + 7 >> 4));
/*      */       }
/* 4933 */       inrow++;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   static void int_upsample(jpeg_decompress_struct cinfo, jpeg_component_info compptr, byte[][] input_data, int input_data_offset, byte[][][] output_data_ptr, int[] output_data_offset, int output_data_index)
/*      */   {
/* 4940 */     jpeg_upsampler upsample = cinfo.upsample;
/* 4941 */     byte[][] output_data = output_data_ptr[output_data_index];
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4948 */     output_data_offset[output_data_index] = 0;
/*      */     
/* 4950 */     int h_expand = upsample.h_expand[compptr.component_index];
/* 4951 */     int v_expand = upsample.v_expand[compptr.component_index];
/*      */     int outrow;
/* 4953 */     int inrow = outrow = 0;
/* 4954 */     while (outrow < cinfo.max_v_samp_factor)
/*      */     {
/* 4956 */       byte[] inptr = input_data[(inrow + input_data_offset)];
/* 4957 */       int inptr_offset = 0;
/* 4958 */       byte[] outptr = output_data[outrow];
/* 4959 */       int outptr_offset = 0;
/* 4960 */       int outend = outptr_offset + cinfo.output_width;
/* 4961 */       while (outptr_offset < outend) {
/* 4962 */         byte invalue = inptr[(inptr_offset++)];
/* 4963 */         for (int h = h_expand; h > 0; h--) {
/* 4964 */           outptr[(outptr_offset++)] = invalue;
/*      */         }
/*      */       }
/*      */       
/* 4968 */       if (v_expand > 1) {
/* 4969 */         jcopy_sample_rows(output_data, outrow, output_data, outrow + 1, v_expand - 1, cinfo.output_width);
/*      */       }
/* 4971 */       inrow++;
/* 4972 */       outrow += v_expand;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static void null_convert(jpeg_decompress_struct cinfo, byte[][][] input_buf, int[] input_buf_offset, int input_row, byte[][] output_buf, int output_buf_offset, int num_rows)
/*      */   {
/* 4982 */     int num_components = cinfo.num_components;
/* 4983 */     int num_cols = cinfo.output_width;
/*      */     for (;;)
/*      */     {
/* 4986 */       num_rows--; if (num_rows < 0) break;
/* 4987 */       for (int ci = 0; ci < num_components; ci++) {
/* 4988 */         byte[] inptr = input_buf[ci][(input_row + input_buf_offset[0])];
/* 4989 */         byte[] outptr = output_buf[output_buf_offset];
/*      */         
/* 4991 */         int offset = 0;
/* 4992 */         switch (ci) {
/* 4993 */         case 2:  offset = 0; break;
/* 4994 */         case 1:  offset = 1; break;
/* 4995 */         case 0:  offset = 2;
/*      */         }
/* 4997 */         int outptr_offset = offset;int inptr_offset = 0;
/* 4998 */         for (int count = num_cols; count > 0; count--) {
/* 4999 */           outptr[outptr_offset] = inptr[(inptr_offset++)];
/* 5000 */           outptr_offset += num_components;
/*      */         }
/*      */       }
/* 5003 */       input_row++;
/* 5004 */       output_buf_offset++;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   static void grayscale_convert(jpeg_decompress_struct cinfo, byte[][][] input_buf, int[] input_buf_offset, int input_row, byte[][] output_buf, int output_buf_offset, int num_rows)
/*      */   {
/* 5012 */     jcopy_sample_rows(input_buf[0], input_row + input_buf_offset[0], output_buf, output_buf_offset, num_rows, cinfo.output_width);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static void gray_rgb_convert(jpeg_decompress_struct cinfo, byte[][][] input_buf, int[] input_buf_offset, int input_row, byte[][] output_buf, int output_buf_offset, int num_rows)
/*      */   {
/* 5022 */     int num_cols = cinfo.output_width;
/*      */     for (;;) {
/* 5024 */       num_rows--; if (num_rows < 0) break;
/* 5025 */       byte[] inptr = input_buf[0][(input_row++ + input_buf_offset[0])];
/* 5026 */       byte[] outptr = output_buf[(output_buf_offset++)];
/* 5027 */       int outptr_offset = 0;
/* 5028 */       for (int col = 0; col < num_cols; col++)
/*      */       {
/* 5030 */         outptr[(2 + outptr_offset)] = (outptr[(1 + outptr_offset)] = outptr[(0 + outptr_offset)] = inptr[col]);
/* 5031 */         outptr_offset += 3;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   static void ycc_rgb_convert(jpeg_decompress_struct cinfo, byte[][][] input_buf, int[] input_buf_offset, int input_row, byte[][] output_buf, int output_buf_offset, int num_rows)
/*      */   {
/* 5040 */     jpeg_color_deconverter cconvert = cinfo.cconvert;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 5045 */     int num_cols = cinfo.output_width;
/*      */     
/* 5047 */     byte[] range_limit = cinfo.sample_range_limit;
/* 5048 */     int range_limit_offset = cinfo.sample_range_limit_offset;
/* 5049 */     int[] Crrtab = cconvert.Cr_r_tab;
/* 5050 */     int[] Cbbtab = cconvert.Cb_b_tab;
/* 5051 */     int[] Crgtab = cconvert.Cr_g_tab;
/* 5052 */     int[] Cbgtab = cconvert.Cb_g_tab;
/*      */     for (;;)
/*      */     {
/* 5055 */       num_rows--; if (num_rows < 0) break;
/* 5056 */       byte[] inptr0 = input_buf[0][(input_row + input_buf_offset[0])];
/* 5057 */       byte[] inptr1 = input_buf[1][(input_row + input_buf_offset[1])];
/* 5058 */       byte[] inptr2 = input_buf[2][(input_row + input_buf_offset[2])];
/* 5059 */       input_row++;
/* 5060 */       byte[] outptr = output_buf[(output_buf_offset++)];
/* 5061 */       int outptr_offset = 0;
/* 5062 */       for (int col = 0; col < num_cols; col++) {
/* 5063 */         int y = inptr0[col] & 0xFF;
/* 5064 */         int cb = inptr1[col] & 0xFF;
/* 5065 */         int cr = inptr2[col] & 0xFF;
/*      */         
/* 5067 */         outptr[(outptr_offset + 2)] = range_limit[(y + Crrtab[cr] + range_limit_offset)];
/* 5068 */         outptr[(outptr_offset + 1)] = range_limit[(y + (Cbgtab[cb] + Crgtab[cr] >> 16) + range_limit_offset)];
/* 5069 */         outptr[(outptr_offset + 0)] = range_limit[(y + Cbbtab[cb] + range_limit_offset)];
/* 5070 */         outptr_offset += 3;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   static boolean process_APPn(int n, jpeg_decompress_struct cinfo) {
/* 5076 */     if ((n == 0) || (n == 14)) {
/* 5077 */       return get_interesting_appn(cinfo);
/*      */     }
/* 5079 */     return skip_variable(cinfo);
/*      */   }
/*      */   
/*      */   static boolean process_COM(jpeg_decompress_struct cinfo) {
/* 5083 */     return skip_variable(cinfo);
/*      */   }
/*      */   
/*      */   static void skip_input_data(jpeg_decompress_struct cinfo, int num_bytes) {
/* 5087 */     if (num_bytes > 0) {
/* 5088 */       while (num_bytes > cinfo.bytes_in_buffer - cinfo.bytes_offset) {
/* 5089 */         num_bytes -= cinfo.bytes_in_buffer - cinfo.bytes_offset;
/* 5090 */         if (!fill_input_buffer(cinfo)) { error();
/*      */         }
/*      */       }
/*      */       
/*      */ 
/* 5095 */       cinfo.bytes_offset += num_bytes;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   static boolean skip_variable(jpeg_decompress_struct cinfo)
/*      */   {
/* 5104 */     if (cinfo.bytes_offset == cinfo.bytes_in_buffer) fill_input_buffer(cinfo);
/* 5105 */     int length = (cinfo.buffer[(cinfo.bytes_offset++)] & 0xFF) << 8;
/* 5106 */     if (cinfo.bytes_offset == cinfo.bytes_in_buffer) fill_input_buffer(cinfo);
/* 5107 */     length |= cinfo.buffer[(cinfo.bytes_offset++)] & 0xFF;
/*      */     
/* 5109 */     length -= 2;
/*      */     
/*      */ 
/*      */ 
/* 5113 */     if (length > 0) {
/* 5114 */       skip_input_data(cinfo, length);
/*      */     }
/*      */     
/* 5117 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   static boolean get_interesting_appn(jpeg_decompress_struct cinfo)
/*      */   {
/* 5124 */     byte[] b = new byte[14];
/*      */     
/*      */ 
/* 5127 */     if (cinfo.bytes_offset == cinfo.bytes_in_buffer) fill_input_buffer(cinfo);
/* 5128 */     int length = (cinfo.buffer[(cinfo.bytes_offset++)] & 0xFF) << 8;
/* 5129 */     if (cinfo.bytes_offset == cinfo.bytes_in_buffer) fill_input_buffer(cinfo);
/* 5130 */     length |= cinfo.buffer[(cinfo.bytes_offset++)] & 0xFF;
/* 5131 */     length -= 2;
/*      */     int numtoread;
/*      */     int numtoread;
/* 5134 */     if (length >= 14) {
/* 5135 */       numtoread = 14; } else { int numtoread;
/* 5136 */       if (length > 0) {
/* 5137 */         numtoread = length;
/*      */       } else
/* 5139 */         numtoread = 0; }
/* 5140 */     for (int i = 0; i < numtoread; i++) {
/* 5141 */       if (cinfo.bytes_offset == cinfo.bytes_in_buffer) fill_input_buffer(cinfo);
/* 5142 */       b[i] = cinfo.buffer[(cinfo.bytes_offset++)];
/*      */     }
/* 5144 */     length -= numtoread;
/*      */     
/*      */ 
/* 5147 */     switch (cinfo.unread_marker) {
/*      */     case 224: 
/* 5149 */       examine_app0(cinfo, b, numtoread, length);
/* 5150 */       break;
/*      */     case 238: 
/* 5152 */       examine_app14(cinfo, b, numtoread, length);
/* 5153 */       break;
/*      */     
/*      */     default: 
/* 5156 */       error();
/*      */     }
/*      */     
/*      */     
/*      */ 
/*      */ 
/* 5162 */     if (length > 0) {
/* 5163 */       skip_input_data(cinfo, length);
/*      */     }
/* 5165 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static void examine_app0(jpeg_decompress_struct cinfo, byte[] data, int datalen, int remaining)
/*      */   {
/* 5174 */     int totallen = datalen + remaining;
/*      */     
/* 5176 */     if ((datalen >= 14) && ((data[0] & 0xFF) == 74) && ((data[1] & 0xFF) == 70) && ((data[2] & 0xFF) == 73) && ((data[3] & 0xFF) == 70) && ((data[4] & 0xFF) == 0))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5184 */       cinfo.saw_JFIF_marker = true;
/* 5185 */       cinfo.JFIF_major_version = data[5];
/* 5186 */       cinfo.JFIF_minor_version = ((byte)(data[6] & 0xFF));
/* 5187 */       cinfo.density_unit = ((byte)(data[7] & 0xFF));
/* 5188 */       cinfo.X_density = ((short)(((data[8] & 0xFF) << 8) + (data[9] & 0xFF)));
/* 5189 */       cinfo.Y_density = ((short)(((data[10] & 0xFF) << 8) + (data[11] & 0xFF)));
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5196 */       if ((cinfo.JFIF_major_version == 1) || 
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5205 */         ((data[12] & 0xFF | data[13] & 0xFF) != 0)) {}
/*      */       
/*      */ 
/*      */ 
/* 5209 */       totallen -= 14;
/* 5210 */       if (totallen == (data[12] & 0xFF) * (data[13] & 0xFF) * 3) {}
/*      */ 
/*      */     }
/* 5213 */     else if ((datalen >= 6) && ((data[0] & 0xFF) == 74) && ((data[1] & 0xFF) == 70) && ((data[2] & 0xFF) == 88) && ((data[3] & 0xFF) == 88) && ((data[4] & 0xFF) == 0))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5224 */       switch (data[5] & 0xFF)
/*      */       {
/*      */       case 16: 
/*      */         break;
/*      */       case 17: 
/*      */         break;
/*      */       case 19: 
/*      */         break;
/*      */       }
/*      */       
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static void examine_app14(jpeg_decompress_struct cinfo, byte[] data, int datalen, int remaining)
/*      */   {
/* 5252 */     if ((datalen >= 12) && ((data[0] & 0xFF) == 65) && ((data[1] & 0xFF) == 100) && ((data[2] & 0xFF) == 111) && ((data[3] & 0xFF) == 98) && ((data[4] & 0xFF) == 101))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5263 */       int transform = data[11] & 0xFF;
/*      */       
/* 5265 */       cinfo.saw_Adobe_marker = true;
/* 5266 */       cinfo.Adobe_transform = ((byte)transform);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static boolean get_soi(jpeg_decompress_struct cinfo)
/*      */   {
/* 5278 */     if (cinfo.marker.saw_SOI) {
/* 5279 */       error();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 5284 */     for (int i = 0; i < 16; i++) {
/* 5285 */       cinfo.arith_dc_L[i] = 0;
/* 5286 */       cinfo.arith_dc_U[i] = 1;
/* 5287 */       cinfo.arith_ac_K[i] = 5;
/*      */     }
/* 5289 */     cinfo.restart_interval = 0;
/*      */     
/*      */ 
/*      */ 
/* 5293 */     cinfo.jpeg_color_space = 0;
/* 5294 */     cinfo.CCIR601_sampling = false;
/*      */     
/* 5296 */     cinfo.saw_JFIF_marker = false;
/* 5297 */     cinfo.JFIF_major_version = 1;
/* 5298 */     cinfo.JFIF_minor_version = 1;
/* 5299 */     cinfo.density_unit = 0;
/* 5300 */     cinfo.X_density = 1;
/* 5301 */     cinfo.Y_density = 1;
/* 5302 */     cinfo.saw_Adobe_marker = false;
/* 5303 */     cinfo.Adobe_transform = 0;
/*      */     
/* 5305 */     cinfo.marker.saw_SOI = true;
/*      */     
/* 5307 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   static void jinit_input_controller(jpeg_decompress_struct cinfo)
/*      */   {
/* 5315 */     jpeg_input_controller inputctl = cinfo.inputctl = new jpeg_input_controller();
/* 5316 */     inputctl.has_multiple_scans = false;
/* 5317 */     inputctl.eoi_reached = false;
/* 5318 */     inputctl.inheaders = true;
/*      */   }
/*      */   
/*      */   static void reset_marker_reader(jpeg_decompress_struct cinfo) {
/* 5322 */     jpeg_marker_reader marker = cinfo.marker;
/*      */     
/* 5324 */     cinfo.comp_info = null;
/* 5325 */     cinfo.input_scan_number = 0;
/* 5326 */     cinfo.unread_marker = 0;
/* 5327 */     marker.saw_SOI = false;
/* 5328 */     marker.saw_SOF = false;
/* 5329 */     marker.discarded_bytes = 0;
/*      */   }
/*      */   
/*      */   static void reset_input_controller(jpeg_decompress_struct cinfo)
/*      */   {
/* 5334 */     jpeg_input_controller inputctl = cinfo.inputctl;
/*      */     
/* 5336 */     inputctl.has_multiple_scans = false;
/* 5337 */     inputctl.eoi_reached = false;
/* 5338 */     inputctl.inheaders = true;
/*      */     
/* 5340 */     reset_marker_reader(cinfo);
/*      */     
/* 5342 */     cinfo.coef_bits = ((int[][])null);
/*      */   }
/*      */   
/*      */   static void finish_output_pass(jpeg_decompress_struct cinfo) {
/* 5346 */     jpeg_decomp_master master = cinfo.master;
/*      */     
/* 5348 */     if (cinfo.quantize_colors) {
/* 5349 */       error(20);
/*      */     }
/*      */     
/* 5352 */     master.pass_number += 1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static void jpeg_destroy(jpeg_decompress_struct cinfo)
/*      */   {
/* 5361 */     cinfo.global_state = 0;
/*      */   }
/*      */   
/*      */   static void jpeg_destroy_decompress(jpeg_decompress_struct cinfo) {
/* 5365 */     jpeg_destroy(cinfo);
/*      */   }
/*      */   
/*      */   static boolean jpeg_input_complete(jpeg_decompress_struct cinfo)
/*      */   {
/* 5370 */     if ((cinfo.global_state < 200) || (cinfo.global_state > 210)) {
/* 5371 */       error();
/*      */     }
/* 5373 */     return cinfo.inputctl.eoi_reached;
/*      */   }
/*      */   
/*      */   static boolean jpeg_start_output(jpeg_decompress_struct cinfo, int scan_number) {
/* 5377 */     if ((cinfo.global_state != 207) && (cinfo.global_state != 204)) {
/* 5378 */       error();
/*      */     }
/*      */     
/* 5381 */     if (scan_number <= 0)
/* 5382 */       scan_number = 1;
/* 5383 */     if ((cinfo.inputctl.eoi_reached) && (scan_number > cinfo.input_scan_number))
/* 5384 */       scan_number = cinfo.input_scan_number;
/* 5385 */     cinfo.output_scan_number = scan_number;
/*      */     
/* 5387 */     return output_pass_setup(cinfo);
/*      */   }
/*      */   
/*      */   static boolean jpeg_finish_output(jpeg_decompress_struct cinfo) {
/* 5391 */     if (((cinfo.global_state == 205) || (cinfo.global_state == 206)) && (cinfo.buffered_image))
/*      */     {
/*      */ 
/* 5394 */       finish_output_pass(cinfo);
/* 5395 */       cinfo.global_state = 208;
/* 5396 */     } else if (cinfo.global_state != 208)
/*      */     {
/* 5398 */       error();
/*      */     }
/*      */     
/*      */ 
/* 5402 */     while ((cinfo.input_scan_number <= cinfo.output_scan_number) && (!cinfo.inputctl.eoi_reached)) {
/* 5403 */       if (consume_input(cinfo) == 0)
/* 5404 */         return false;
/*      */     }
/* 5406 */     cinfo.global_state = 207;
/* 5407 */     return true;
/*      */   }
/*      */   
/*      */   static boolean jpeg_finish_decompress(jpeg_decompress_struct cinfo) {
/* 5411 */     if (((cinfo.global_state == 205) || (cinfo.global_state == 206)) && (!cinfo.buffered_image))
/*      */     {
/* 5413 */       if (cinfo.output_scanline < cinfo.output_height) {
/* 5414 */         error();
/*      */       }
/* 5416 */       finish_output_pass(cinfo);
/* 5417 */       cinfo.global_state = 210;
/* 5418 */     } else if (cinfo.global_state == 207)
/*      */     {
/* 5420 */       cinfo.global_state = 210;
/* 5421 */     } else if (cinfo.global_state != 210)
/*      */     {
/* 5423 */       error();
/*      */     }
/*      */     
/*      */ 
/* 5427 */     while (!cinfo.inputctl.eoi_reached) {
/* 5428 */       if (consume_input(cinfo) == 0) {
/* 5429 */         return false;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 5434 */     jpeg_abort(cinfo);
/* 5435 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   static int jpeg_read_header(jpeg_decompress_struct cinfo, boolean require_image)
/*      */   {
/* 5442 */     if ((cinfo.global_state != 200) && (cinfo.global_state != 201)) {
/* 5443 */       error();
/*      */     }
/*      */     
/* 5446 */     int retcode = jpeg_consume_input(cinfo);
/*      */     
/* 5448 */     switch (retcode) {
/*      */     case 1: 
/* 5450 */       retcode = 1;
/* 5451 */       break;
/*      */     case 2: 
/* 5453 */       if (require_image) {
/* 5454 */         error();
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 5460 */       jpeg_abort(cinfo);
/* 5461 */       retcode = 2;
/* 5462 */       break;
/*      */     }
/*      */     
/*      */     
/*      */ 
/*      */ 
/* 5468 */     return retcode;
/*      */   }
/*      */   
/*      */   static int dummy_consume_data(jpeg_decompress_struct cinfo) {
/* 5472 */     return 0;
/*      */   }
/*      */   
/*      */   static int consume_data(jpeg_decompress_struct cinfo) {
/* 5476 */     jpeg_d_coef_controller coef = cinfo.coef;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5495 */     for (int yoffset = coef.MCU_vert_offset; yoffset < coef.MCU_rows_per_iMCU_row; yoffset++) {
/* 5496 */       for (int MCU_col_num = coef.MCU_ctr; MCU_col_num < cinfo.MCUs_per_row; MCU_col_num++)
/*      */       {
/* 5498 */         int blkn = 0;
/* 5499 */         for (int ci = 0; ci < cinfo.comps_in_scan; ci++) {
/* 5500 */           jpeg_component_info compptr = cinfo.cur_comp_info[ci];
/* 5501 */           int start_col = MCU_col_num * compptr.MCU_width;
/* 5502 */           for (int yindex = 0; yindex < compptr.MCU_height; yindex++)
/*      */           {
/* 5504 */             short[][] buffer_ptr = coef.whole_image[compptr.component_index][(yindex + yoffset + cinfo.input_iMCU_row * compptr.v_samp_factor)];
/* 5505 */             int buffer_ptr_offset = start_col;
/* 5506 */             for (int xindex = 0; xindex < compptr.MCU_width; xindex++) {
/* 5507 */               coef.MCU_buffer[(blkn++)] = buffer_ptr[(buffer_ptr_offset++)];
/*      */             }
/*      */           }
/*      */         }
/*      */         
/* 5512 */         if (!cinfo.entropy.decode_mcu(cinfo, coef.MCU_buffer))
/*      */         {
/* 5514 */           coef.MCU_vert_offset = yoffset;
/* 5515 */           coef.MCU_ctr = MCU_col_num;
/* 5516 */           return 0;
/*      */         }
/*      */       }
/*      */       
/* 5520 */       coef.MCU_ctr = 0;
/*      */     }
/*      */     
/* 5523 */     if (++cinfo.input_iMCU_row < cinfo.total_iMCU_rows) {
/* 5524 */       coef.start_iMCU_row(cinfo);
/* 5525 */       return 3;
/*      */     }
/*      */     
/* 5528 */     finish_input_pass(cinfo);
/* 5529 */     return 4;
/*      */   }
/*      */   
/*      */   static int consume_input(jpeg_decompress_struct cinfo) {
/* 5533 */     switch (cinfo.inputctl.consume_input) {
/*      */     case 1: 
/* 5535 */       switch (cinfo.coef.consume_data) {
/* 5536 */       case 0:  return consume_data(cinfo);
/* 5537 */       case 1:  return dummy_consume_data(cinfo); }
/* 5538 */       error();
/*      */       
/* 5540 */       break;
/*      */     case 0: 
/* 5542 */       return consume_markers(cinfo);
/*      */     default: 
/* 5544 */       error();
/*      */     }
/* 5546 */     return 0;
/*      */   }
/*      */   
/*      */   static boolean fill_input_buffer(jpeg_decompress_struct cinfo) {
/*      */     try {
/* 5551 */       InputStream inputStream = cinfo.inputStream;
/* 5552 */       int nbytes = inputStream.read(cinfo.buffer);
/* 5553 */       if (nbytes <= 0) {
/* 5554 */         if (cinfo.start_of_file) {
/* 5555 */           error();
/*      */         }
/*      */         
/*      */ 
/* 5559 */         cinfo.buffer[0] = -1;
/* 5560 */         cinfo.buffer[1] = -39;
/* 5561 */         nbytes = 2;
/*      */       }
/* 5563 */       cinfo.bytes_in_buffer = nbytes;
/* 5564 */       cinfo.bytes_offset = 0;
/* 5565 */       cinfo.start_of_file = false;
/*      */     } catch (IOException e) {
/* 5567 */       error(39);
/* 5568 */       return false;
/*      */     }
/* 5570 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static boolean first_marker(jpeg_decompress_struct cinfo)
/*      */   {
/* 5582 */     if (cinfo.bytes_offset == cinfo.bytes_in_buffer) fill_input_buffer(cinfo);
/* 5583 */     int c = cinfo.buffer[(cinfo.bytes_offset++)] & 0xFF;
/* 5584 */     if (cinfo.bytes_offset == cinfo.bytes_in_buffer) fill_input_buffer(cinfo);
/* 5585 */     int c2 = cinfo.buffer[(cinfo.bytes_offset++)] & 0xFF;
/* 5586 */     if ((c != 255) || (c2 != 216)) {
/* 5587 */       error();
/*      */     }
/*      */     
/* 5590 */     cinfo.unread_marker = c2;
/*      */     
/* 5592 */     return true;
/*      */   }
/*      */   
/*      */   static boolean next_marker(jpeg_decompress_struct cinfo)
/*      */   {
/*      */     int c;
/*      */     for (;;) {
/* 5599 */       if (cinfo.bytes_offset == cinfo.bytes_in_buffer) fill_input_buffer(cinfo);
/* 5600 */       c = cinfo.buffer[(cinfo.bytes_offset++)] & 0xFF;
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5606 */       while (c != 255) {
/* 5607 */         cinfo.marker.discarded_bytes += 1;
/* 5608 */         if (cinfo.bytes_offset == cinfo.bytes_in_buffer) fill_input_buffer(cinfo);
/* 5609 */         c = cinfo.buffer[(cinfo.bytes_offset++)] & 0xFF;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */       do
/*      */       {
/* 5617 */         if (cinfo.bytes_offset == cinfo.bytes_in_buffer) fill_input_buffer(cinfo);
/* 5618 */         c = cinfo.buffer[(cinfo.bytes_offset++)] & 0xFF;
/* 5619 */       } while (c == 255);
/* 5620 */       if (c != 0) {
/*      */         break;
/*      */       }
/*      */       
/*      */ 
/* 5625 */       cinfo.marker.discarded_bytes += 2;
/*      */     }
/*      */     
/* 5628 */     if (cinfo.marker.discarded_bytes != 0)
/*      */     {
/* 5630 */       cinfo.marker.discarded_bytes = 0;
/*      */     }
/*      */     
/* 5633 */     cinfo.unread_marker = c;
/*      */     
/* 5635 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */   static int read_markers(jpeg_decompress_struct cinfo)
/*      */   {
/*      */     for (;;)
/*      */     {
/* 5643 */       if (cinfo.unread_marker == 0) {
/* 5644 */         if (!cinfo.marker.saw_SOI) {
/* 5645 */           if (!first_marker(cinfo)) {
/* 5646 */             return 0;
/*      */           }
/* 5648 */         } else if (!next_marker(cinfo)) {
/* 5649 */           return 0;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 5656 */       switch (cinfo.unread_marker) {
/*      */       case 216: 
/* 5658 */         if (!get_soi(cinfo)) {
/* 5659 */           return 0;
/*      */         }
/*      */         break;
/*      */       case 192: 
/*      */       case 193: 
/* 5664 */         if (!get_sof(cinfo, false, false)) {
/* 5665 */           return 0;
/*      */         }
/*      */         break;
/*      */       case 194: 
/* 5669 */         if (!get_sof(cinfo, true, false)) {
/* 5670 */           return 0;
/*      */         }
/*      */         break;
/*      */       case 201: 
/* 5674 */         if (!get_sof(cinfo, false, true)) {
/* 5675 */           return 0;
/*      */         }
/*      */         break;
/*      */       case 202: 
/* 5679 */         if (!get_sof(cinfo, true, true)) {
/* 5680 */           return 0;
/*      */         }
/*      */         
/*      */         break;
/*      */       case 195: 
/*      */       case 197: 
/*      */       case 198: 
/*      */       case 199: 
/*      */       case 200: 
/*      */       case 203: 
/*      */       case 205: 
/*      */       case 206: 
/*      */       case 207: 
/* 5693 */         error();
/*      */         
/* 5695 */         break;
/*      */       
/*      */       case 218: 
/* 5698 */         if (!get_sos(cinfo))
/* 5699 */           return 0;
/* 5700 */         cinfo.unread_marker = 0;
/* 5701 */         return 1;
/*      */       
/*      */ 
/*      */       case 217: 
/* 5705 */         cinfo.unread_marker = 0;
/* 5706 */         return 2;
/*      */       
/*      */       case 204: 
/* 5709 */         if (!get_dac(cinfo)) {
/* 5710 */           return 0;
/*      */         }
/*      */         break;
/*      */       case 196: 
/* 5714 */         if (!get_dht(cinfo)) {
/* 5715 */           return 0;
/*      */         }
/*      */         break;
/*      */       case 219: 
/* 5719 */         if (!get_dqt(cinfo)) {
/* 5720 */           return 0;
/*      */         }
/*      */         break;
/*      */       case 221: 
/* 5724 */         if (!get_dri(cinfo)) {
/* 5725 */           return 0;
/*      */         }
/*      */         break;
/*      */       case 224: 
/*      */       case 225: 
/*      */       case 226: 
/*      */       case 227: 
/*      */       case 228: 
/*      */       case 229: 
/*      */       case 230: 
/*      */       case 231: 
/*      */       case 232: 
/*      */       case 233: 
/*      */       case 234: 
/*      */       case 235: 
/*      */       case 236: 
/*      */       case 237: 
/*      */       case 238: 
/*      */       case 239: 
/* 5744 */         if (!process_APPn(cinfo.unread_marker - 224, cinfo)) {
/* 5745 */           return 0;
/*      */         }
/*      */         break;
/*      */       case 254: 
/* 5749 */         if (!process_COM(cinfo)) {
/* 5750 */           return 0;
/*      */         }
/*      */         
/*      */ 
/*      */         break;
/*      */       case 1: 
/*      */       case 208: 
/*      */       case 209: 
/*      */       case 210: 
/*      */       case 211: 
/*      */       case 212: 
/*      */       case 213: 
/*      */       case 214: 
/*      */       case 215: 
/*      */         break;
/*      */       case 220: 
/* 5766 */         if (!skip_variable(cinfo)) {
/* 5767 */           return 0;
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         break;
/*      */       default: 
/* 5776 */         error();
/*      */       }
/*      */       
/*      */       
/*      */ 
/* 5781 */       cinfo.unread_marker = 0;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   static long jdiv_round_up(long a, long b)
/*      */   {
/* 5789 */     return (a + b - 1L) / b;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static void initial_setup(jpeg_decompress_struct cinfo)
/*      */   {
/* 5799 */     if ((cinfo.image_height > 65500) || (cinfo.image_width > 65500)) {
/* 5800 */       error();
/*      */     }
/*      */     
/*      */ 
/* 5804 */     if (cinfo.data_precision != 8) {
/* 5805 */       error(" [data precision=" + cinfo.data_precision + "]");
/*      */     }
/*      */     
/*      */ 
/* 5809 */     if (cinfo.num_components > 10) {
/* 5810 */       error();
/*      */     }
/*      */     
/*      */ 
/* 5814 */     cinfo.max_h_samp_factor = 1;
/* 5815 */     cinfo.max_v_samp_factor = 1;
/* 5816 */     for (int ci = 0; ci < cinfo.num_components; ci++) {
/* 5817 */       jpeg_component_info compptr = cinfo.comp_info[ci];
/* 5818 */       if ((compptr.h_samp_factor <= 0) || (compptr.h_samp_factor > 4) || (compptr.v_samp_factor <= 0) || (compptr.v_samp_factor > 4)) {
/* 5819 */         error();
/*      */       }
/* 5821 */       cinfo.max_h_samp_factor = Math.max(cinfo.max_h_samp_factor, compptr.h_samp_factor);
/* 5822 */       cinfo.max_v_samp_factor = Math.max(cinfo.max_v_samp_factor, compptr.v_samp_factor);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5829 */     cinfo.min_DCT_scaled_size = 8;
/*      */     
/*      */ 
/* 5832 */     for (ci = 0; ci < cinfo.num_components; ci++) {
/* 5833 */       jpeg_component_info compptr = cinfo.comp_info[ci];
/* 5834 */       compptr.DCT_scaled_size = 8;
/*      */       
/* 5836 */       compptr.width_in_blocks = ((int)jdiv_round_up(cinfo.image_width * compptr.h_samp_factor, cinfo.max_h_samp_factor * 8));
/* 5837 */       compptr.height_in_blocks = ((int)jdiv_round_up(cinfo.image_height * compptr.v_samp_factor, cinfo.max_v_samp_factor * 8));
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5843 */       compptr.downsampled_width = ((int)jdiv_round_up(cinfo.image_width * compptr.h_samp_factor, cinfo.max_h_samp_factor));
/* 5844 */       compptr.downsampled_height = ((int)jdiv_round_up(cinfo.image_height * compptr.v_samp_factor, cinfo.max_v_samp_factor));
/*      */       
/* 5846 */       compptr.component_needed = true;
/*      */       
/* 5848 */       compptr.quant_table = null;
/*      */     }
/*      */     
/*      */ 
/* 5852 */     cinfo.total_iMCU_rows = ((int)jdiv_round_up(cinfo.image_height, cinfo.max_v_samp_factor * 8));
/*      */     
/*      */ 
/* 5855 */     if ((cinfo.comps_in_scan < cinfo.num_components) || (cinfo.progressive_mode)) {
/* 5856 */       cinfo.inputctl.has_multiple_scans = true;
/*      */     } else {
/* 5858 */       cinfo.inputctl.has_multiple_scans = false;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   static void per_scan_setup(jpeg_decompress_struct cinfo)
/*      */   {
/* 5866 */     int tmp = 0;
/*      */     
/*      */ 
/* 5869 */     if (cinfo.comps_in_scan == 1)
/*      */     {
/*      */ 
/* 5872 */       jpeg_component_info compptr = cinfo.cur_comp_info[0];
/*      */       
/*      */ 
/* 5875 */       cinfo.MCUs_per_row = compptr.width_in_blocks;
/* 5876 */       cinfo.MCU_rows_in_scan = compptr.height_in_blocks;
/*      */       
/*      */ 
/* 5879 */       compptr.MCU_width = 1;
/* 5880 */       compptr.MCU_height = 1;
/* 5881 */       compptr.MCU_blocks = 1;
/* 5882 */       compptr.MCU_sample_width = compptr.DCT_scaled_size;
/* 5883 */       compptr.last_col_width = 1;
/*      */       
/*      */ 
/*      */ 
/* 5887 */       tmp = compptr.height_in_blocks % compptr.v_samp_factor;
/* 5888 */       if (tmp == 0) tmp = compptr.v_samp_factor;
/* 5889 */       compptr.last_row_height = tmp;
/*      */       
/*      */ 
/* 5892 */       cinfo.blocks_in_MCU = 1;
/* 5893 */       cinfo.MCU_membership[0] = 0;
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/* 5898 */       if ((cinfo.comps_in_scan <= 0) || (cinfo.comps_in_scan > 4)) {
/* 5899 */         error();
/*      */       }
/*      */       
/*      */ 
/* 5903 */       cinfo.MCUs_per_row = ((int)jdiv_round_up(cinfo.image_width, cinfo.max_h_samp_factor * 8));
/* 5904 */       cinfo.MCU_rows_in_scan = ((int)jdiv_round_up(cinfo.image_height, cinfo.max_v_samp_factor * 8));
/*      */       
/* 5906 */       cinfo.blocks_in_MCU = 0;
/*      */       
/* 5908 */       for (int ci = 0; ci < cinfo.comps_in_scan; ci++) {
/* 5909 */         jpeg_component_info compptr = cinfo.cur_comp_info[ci];
/*      */         
/* 5911 */         compptr.MCU_width = compptr.h_samp_factor;
/* 5912 */         compptr.MCU_height = compptr.v_samp_factor;
/* 5913 */         compptr.MCU_blocks = (compptr.MCU_width * compptr.MCU_height);
/* 5914 */         compptr.MCU_sample_width = (compptr.MCU_width * compptr.DCT_scaled_size);
/*      */         
/* 5916 */         tmp = compptr.width_in_blocks % compptr.MCU_width;
/* 5917 */         if (tmp == 0) tmp = compptr.MCU_width;
/* 5918 */         compptr.last_col_width = tmp;
/* 5919 */         tmp = compptr.height_in_blocks % compptr.MCU_height;
/* 5920 */         if (tmp == 0) tmp = compptr.MCU_height;
/* 5921 */         compptr.last_row_height = tmp;
/*      */         
/* 5923 */         int mcublks = compptr.MCU_blocks;
/* 5924 */         if (cinfo.blocks_in_MCU + mcublks > 10) {
/* 5925 */           error();
/*      */         }
/* 5927 */         while (mcublks-- > 0) {
/* 5928 */           cinfo.MCU_membership[(cinfo.blocks_in_MCU++)] = ci;
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static void latch_quant_tables(jpeg_decompress_struct cinfo)
/*      */   {
/* 5940 */     for (int ci = 0; ci < cinfo.comps_in_scan; ci++) {
/* 5941 */       jpeg_component_info compptr = cinfo.cur_comp_info[ci];
/*      */       
/* 5943 */       if (compptr.quant_table == null)
/*      */       {
/*      */ 
/* 5946 */         int qtblno = compptr.quant_tbl_no;
/* 5947 */         if ((qtblno < 0) || (qtblno >= 4) || (cinfo.quant_tbl_ptrs[qtblno] == null)) {
/* 5948 */           error();
/*      */         }
/*      */         
/* 5951 */         JQUANT_TBL qtbl = new JQUANT_TBL();
/* 5952 */         System.arraycopy(cinfo.quant_tbl_ptrs[qtblno].quantval, 0, qtbl.quantval, 0, qtbl.quantval.length);
/* 5953 */         qtbl.sent_table = cinfo.quant_tbl_ptrs[qtblno].sent_table;
/* 5954 */         compptr.quant_table = qtbl;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   static void jpeg_make_d_derived_tbl(jpeg_decompress_struct cinfo, boolean isDC, int tblno, d_derived_tbl dtbl) {
/* 5960 */     int i = 0;
/*      */     
/* 5962 */     byte[] huffsize = new byte['ā'];
/* 5963 */     int[] huffcode = new int['ā'];
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 5971 */     if ((tblno < 0) || (tblno >= 4)) {
/* 5972 */       error();
/*      */     }
/* 5974 */     JHUFF_TBL htbl = isDC ? cinfo.dc_huff_tbl_ptrs[tblno] : cinfo.ac_huff_tbl_ptrs[tblno];
/* 5975 */     if (htbl == null) {
/* 5976 */       error();
/*      */     }
/*      */     
/*      */ 
/* 5980 */     dtbl.pub = htbl;
/*      */     
/*      */ 
/*      */ 
/* 5984 */     int p = 0;
/* 5985 */     for (int l = 1; l <= 16; l++) {
/* 5986 */       i = htbl.bits[l] & 0xFF;
/* 5987 */       if ((i < 0) || (p + i > 256)) {
/* 5988 */         error();
/*      */       }
/* 5990 */       while (i-- != 0)
/* 5991 */         huffsize[(p++)] = ((byte)l);
/*      */     }
/* 5993 */     huffsize[p] = 0;
/* 5994 */     int numsymbols = p;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 5999 */     int code = 0;
/* 6000 */     int si = huffsize[0];
/* 6001 */     p = 0;
/* 6002 */     while (huffsize[p] != 0) {
/* 6003 */       while (huffsize[p] == si) {
/* 6004 */         huffcode[(p++)] = code;
/* 6005 */         code++;
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 6010 */       if (code >= 1 << si) {
/* 6011 */         error();
/*      */       }
/* 6013 */       code <<= 1;
/* 6014 */       si++;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 6019 */     p = 0;
/* 6020 */     for (l = 1; l <= 16; l++) {
/* 6021 */       if ((htbl.bits[l] & 0xFF) != 0)
/*      */       {
/*      */ 
/*      */ 
/* 6025 */         dtbl.valoffset[l] = (p - huffcode[p]);
/* 6026 */         p += (htbl.bits[l] & 0xFF);
/* 6027 */         dtbl.maxcode[l] = huffcode[(p - 1)];
/*      */       } else {
/* 6029 */         dtbl.maxcode[l] = -1;
/*      */       }
/*      */     }
/* 6032 */     dtbl.maxcode[17] = 1048575;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 6041 */     for (int j = 0; j < dtbl.look_nbits.length; j++) {
/* 6042 */       dtbl.look_nbits[j] = 0;
/*      */     }
/*      */     
/* 6045 */     p = 0;
/* 6046 */     for (l = 1; l <= 8; l++) {
/* 6047 */       for (i = 1; i <= (htbl.bits[l] & 0xFF); p++)
/*      */       {
/*      */ 
/* 6050 */         int lookbits = huffcode[p] << 8 - l;
/* 6051 */         for (int ctr = 1 << 8 - l; ctr > 0; ctr--) {
/* 6052 */           dtbl.look_nbits[lookbits] = l;
/* 6053 */           dtbl.look_sym[lookbits] = htbl.huffval[p];
/* 6054 */           lookbits++;
/*      */         }
/* 6047 */         i++;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 6065 */     if (isDC) {
/* 6066 */       for (i = 0; i < numsymbols; i++) {
/* 6067 */         int sym = htbl.huffval[i] & 0xFF;
/* 6068 */         if ((sym < 0) || (sym > 15)) {
/* 6069 */           error();
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   static void start_input_pass(jpeg_decompress_struct cinfo) {
/* 6076 */     per_scan_setup(cinfo);
/* 6077 */     latch_quant_tables(cinfo);
/* 6078 */     cinfo.entropy.start_pass(cinfo);
/* 6079 */     cinfo.coef.start_input_pass(cinfo);
/* 6080 */     cinfo.inputctl.consume_input = 1;
/*      */   }
/*      */   
/*      */   static void finish_input_pass(jpeg_decompress_struct cinfo) {
/* 6084 */     cinfo.inputctl.consume_input = 0;
/*      */   }
/*      */   
/*      */   static int consume_markers(jpeg_decompress_struct cinfo) {
/* 6088 */     jpeg_input_controller inputctl = cinfo.inputctl;
/*      */     
/*      */ 
/* 6091 */     if (inputctl.eoi_reached) {
/* 6092 */       return 2;
/*      */     }
/* 6094 */     int val = read_markers(cinfo);
/*      */     
/* 6096 */     switch (val) {
/*      */     case 1: 
/* 6098 */       if (inputctl.inheaders) {
/* 6099 */         initial_setup(cinfo);
/* 6100 */         inputctl.inheaders = false;
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*      */ 
/* 6106 */         if (!inputctl.has_multiple_scans) {
/* 6107 */           error();
/*      */         }
/* 6109 */         start_input_pass(cinfo);
/*      */       }
/* 6111 */       break;
/*      */     case 2: 
/* 6113 */       inputctl.eoi_reached = true;
/* 6114 */       if (inputctl.inheaders) {
/* 6115 */         if (cinfo.marker.saw_SOF) {
/* 6116 */           error();
/*      */ 
/*      */         }
/*      */         
/*      */ 
/*      */       }
/* 6122 */       else if (cinfo.output_scan_number > cinfo.input_scan_number) {
/* 6123 */         cinfo.output_scan_number = cinfo.input_scan_number;
/*      */       }
/*      */       
/*      */       break;
/*      */     }
/*      */     
/*      */     
/* 6130 */     return val;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   static void default_decompress_parms(jpeg_decompress_struct cinfo)
/*      */   {
/* 6137 */     switch (cinfo.num_components) {
/*      */     case 1: 
/* 6139 */       cinfo.jpeg_color_space = 1;
/* 6140 */       cinfo.out_color_space = 1;
/* 6141 */       break;
/*      */     
/*      */     case 3: 
/* 6144 */       if (cinfo.saw_JFIF_marker) {
/* 6145 */         cinfo.jpeg_color_space = 3;
/* 6146 */       } else if (cinfo.saw_Adobe_marker) {
/* 6147 */         switch (cinfo.Adobe_transform) {
/*      */         case 0: 
/* 6149 */           cinfo.jpeg_color_space = 2;
/* 6150 */           break;
/*      */         case 1: 
/* 6152 */           cinfo.jpeg_color_space = 3;
/* 6153 */           break;
/*      */         
/*      */         default: 
/* 6156 */           cinfo.jpeg_color_space = 3;
/* 6157 */           break;
/*      */         }
/*      */       }
/*      */       else {
/* 6161 */         int cid0 = cinfo.comp_info[0].component_id;
/* 6162 */         int cid1 = cinfo.comp_info[1].component_id;
/* 6163 */         int cid2 = cinfo.comp_info[2].component_id;
/*      */         
/* 6165 */         if ((cid0 == 1) && (cid1 == 2) && (cid2 == 3)) {
/* 6166 */           cinfo.jpeg_color_space = 3;
/* 6167 */         } else if ((cid0 == 82) && (cid1 == 71) && (cid2 == 66)) {
/* 6168 */           cinfo.jpeg_color_space = 2;
/*      */         }
/*      */         else {
/* 6171 */           cinfo.jpeg_color_space = 3;
/*      */         }
/*      */       }
/*      */       
/* 6175 */       cinfo.out_color_space = 2;
/* 6176 */       break;
/*      */     
/*      */     case 4: 
/* 6179 */       if (cinfo.saw_Adobe_marker) {
/* 6180 */         switch (cinfo.Adobe_transform) {
/*      */         case 0: 
/* 6182 */           cinfo.jpeg_color_space = 4;
/* 6183 */           break;
/*      */         case 2: 
/* 6185 */           cinfo.jpeg_color_space = 5;
/* 6186 */           break;
/*      */         
/*      */         default: 
/* 6189 */           cinfo.jpeg_color_space = 5;
/* 6190 */           break;
/*      */         }
/*      */         
/*      */       } else {
/* 6194 */         cinfo.jpeg_color_space = 4;
/*      */       }
/* 6196 */       cinfo.out_color_space = 4;
/* 6197 */       break;
/*      */     case 2: 
/*      */     default: 
/* 6200 */       cinfo.jpeg_color_space = 0;
/* 6201 */       cinfo.out_color_space = 0;
/*      */     }
/*      */     
/*      */     
/*      */ 
/* 6206 */     cinfo.scale_num = 1;
/* 6207 */     cinfo.scale_denom = 1;
/* 6208 */     cinfo.output_gamma = 1.0D;
/* 6209 */     cinfo.buffered_image = false;
/* 6210 */     cinfo.raw_data_out = false;
/* 6211 */     cinfo.dct_method = 0;
/* 6212 */     cinfo.do_fancy_upsampling = true;
/* 6213 */     cinfo.do_block_smoothing = true;
/* 6214 */     cinfo.quantize_colors = false;
/*      */     
/* 6216 */     cinfo.dither_mode = 2;
/* 6217 */     cinfo.two_pass_quantize = true;
/* 6218 */     cinfo.desired_number_of_colors = 256;
/* 6219 */     cinfo.colormap = null;
/*      */     
/* 6221 */     cinfo.enable_1pass_quant = false;
/* 6222 */     cinfo.enable_external_quant = false;
/* 6223 */     cinfo.enable_2pass_quant = false;
/*      */   }
/*      */   
/*      */   static void init_source(jpeg_decompress_struct cinfo) {
/* 6227 */     cinfo.buffer = new byte['က'];
/* 6228 */     cinfo.bytes_in_buffer = 0;
/* 6229 */     cinfo.bytes_offset = 0;
/* 6230 */     cinfo.start_of_file = true;
/*      */   }
/*      */   
/*      */   static int jpeg_consume_input(jpeg_decompress_struct cinfo) {
/* 6234 */     int retcode = 0;
/*      */     
/*      */ 
/* 6237 */     switch (cinfo.global_state)
/*      */     {
/*      */     case 200: 
/* 6240 */       reset_input_controller(cinfo);
/*      */       
/* 6242 */       init_source(cinfo);
/* 6243 */       cinfo.global_state = 201;
/*      */     
/*      */     case 201: 
/* 6246 */       retcode = consume_input(cinfo);
/* 6247 */       if (retcode == 1)
/*      */       {
/* 6249 */         default_decompress_parms(cinfo);
/*      */         
/* 6251 */         cinfo.global_state = 202;
/*      */       }
/*      */       
/*      */       break;
/*      */     case 202: 
/* 6256 */       retcode = 1;
/* 6257 */       break;
/*      */     case 203: 
/*      */     case 204: 
/*      */     case 205: 
/*      */     case 206: 
/*      */     case 207: 
/*      */     case 208: 
/*      */     case 210: 
/* 6265 */       retcode = consume_input(cinfo);
/* 6266 */       break;
/*      */     case 209: default: 
/* 6268 */       error();
/*      */     }
/*      */     
/* 6271 */     return retcode;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static void jpeg_abort(jpeg_decompress_struct cinfo)
/*      */   {
/* 6286 */     if (cinfo.is_decompressor) {
/* 6287 */       cinfo.global_state = 200;
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/*      */ 
/* 6293 */       cinfo.global_state = 100;
/*      */     }
/*      */   }
/*      */   
/*      */   static boolean isFileFormat(LEDataInputStream stream)
/*      */   {
/*      */     try {
/* 6300 */       byte[] buffer = new byte[2];
/* 6301 */       stream.read(buffer);
/* 6302 */       stream.unread(buffer);
/* 6303 */       return ((buffer[0] & 0xFF) == 255) && ((buffer[1] & 0xFF) == 216);
/*      */     } catch (Exception e) {}
/* 6305 */     return false;
/*      */   }
/*      */   
/*      */   static ImageData[] loadFromByteStream(InputStream inputStream, ImageLoader loader)
/*      */   {
/* 6310 */     jpeg_decompress_struct cinfo = new jpeg_decompress_struct();
/* 6311 */     cinfo.inputStream = inputStream;
/* 6312 */     jpeg_create_decompress(cinfo);
/* 6313 */     jpeg_read_header(cinfo, true);
/* 6314 */     cinfo.buffered_image = ((cinfo.progressive_mode) && (loader.hasListeners()));
/* 6315 */     jpeg_start_decompress(cinfo);
/* 6316 */     PaletteData palette = null;
/* 6317 */     switch (cinfo.out_color_space) {
/*      */     case 2: 
/* 6319 */       palette = new PaletteData(255, 65280, 16711680);
/* 6320 */       break;
/*      */     case 1: 
/* 6322 */       RGB[] colors = new RGB['Ā'];
/* 6323 */       for (int i = 0; i < colors.length; i++) {
/* 6324 */         colors[i] = new RGB(i, i, i);
/*      */       }
/* 6326 */       palette = new PaletteData(colors);
/* 6327 */       break;
/*      */     default: 
/* 6329 */       error();
/*      */     }
/* 6331 */     int scanlinePad = 4;
/* 6332 */     int row_stride = ((cinfo.output_width * cinfo.out_color_components * 8 + 7) / 8 + (scanlinePad - 1)) / scanlinePad * scanlinePad;
/* 6333 */     byte[][] buffer = new byte[1][row_stride];
/* 6334 */     byte[] data = new byte[row_stride * cinfo.output_height];
/* 6335 */     ImageData imageData = ImageData.internal_new(cinfo.output_width, cinfo.output_height, palette.isDirect ? 24 : 8, palette, scanlinePad, data, 0, null, null, -1, -1, 4, 0, 0, 0, 0);
/*      */     
/*      */ 
/* 6338 */     if (cinfo.buffered_image) {
/*      */       boolean done;
/*      */       do {
/* 6341 */         int incrementCount = cinfo.input_scan_number - 1;
/* 6342 */         jpeg_start_output(cinfo, cinfo.input_scan_number);
/* 6343 */         while (cinfo.output_scanline < cinfo.output_height) {
/* 6344 */           int offset = row_stride * cinfo.output_scanline;
/* 6345 */           jpeg_read_scanlines(cinfo, buffer, 1);
/* 6346 */           System.arraycopy(buffer[0], 0, data, offset, row_stride);
/*      */         }
/* 6348 */         jpeg_finish_output(cinfo);
/* 6349 */         loader.notifyListeners(new ImageLoaderEvent(loader, (ImageData)imageData.clone(), incrementCount, done = jpeg_input_complete(cinfo)));
/* 6350 */       } while (!done);
/*      */     } else {
/* 6352 */       while (cinfo.output_scanline < cinfo.output_height) {
/* 6353 */         int offset = row_stride * cinfo.output_scanline;
/* 6354 */         jpeg_read_scanlines(cinfo, buffer, 1);
/* 6355 */         System.arraycopy(buffer[0], 0, data, offset, row_stride);
/*      */       }
/*      */     }
/* 6358 */     jpeg_finish_decompress(cinfo);
/* 6359 */     jpeg_destroy_decompress(cinfo);
/* 6360 */     return new ImageData[] { imageData };
/*      */   }
/*      */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/internal/image/JPEGDecoder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */