/*     */ package org.eclipse.swt.widgets;
/*     */ 
/*     */ import org.eclipse.swt.events.SelectionListener;
/*     */ import org.eclipse.swt.graphics.Cursor;
/*     */ import org.eclipse.swt.graphics.Point;
/*     */ import org.eclipse.swt.graphics.Rectangle;
/*     */ import org.eclipse.swt.internal.DPIUtil;
/*     */ import org.eclipse.swt.internal.gtk.GDK;
/*     */ import org.eclipse.swt.internal.gtk.GTK;
/*     */ import org.eclipse.swt.internal.gtk.GdkColor;
/*     */ import org.eclipse.swt.internal.gtk.GdkEventButton;
/*     */ import org.eclipse.swt.internal.gtk.GdkEventKey;
/*     */ import org.eclipse.swt.internal.gtk.GdkEventMotion;
/*     */ import org.eclipse.swt.internal.gtk.GtkAllocation;
/*     */ import org.eclipse.swt.internal.gtk.OS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Sash
/*     */   extends Control
/*     */ {
/*     */   boolean dragging;
/*     */   int startX;
/*     */   int startY;
/*     */   int lastX;
/*     */   int lastY;
/*     */   long defaultCursor;
/*     */   private static final int INCREMENT = 1;
/*     */   private static final int PAGE_INCREMENT = 9;
/*     */   
/*     */   public Sash(Composite parent, int style)
/*     */   {
/*  80 */     super(parent, checkStyle(style));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addSelectionListener(SelectionListener listener)
/*     */   {
/* 109 */     checkWidget();
/* 110 */     if (listener == null) error(4);
/* 111 */     TypedListener typedListener = new TypedListener(listener);
/* 112 */     addListener(13, typedListener);
/* 113 */     addListener(14, typedListener);
/*     */   }
/*     */   
/*     */   static int checkStyle(int style) {
/* 117 */     style |= 0x10000;
/* 118 */     return checkBits(style, 256, 512, 0, 0, 0, 0);
/*     */   }
/*     */   
/*     */   Point computeSizeInPixels(int wHint, int hHint, boolean changed)
/*     */   {
/* 123 */     checkWidget();
/* 124 */     if ((wHint != -1) && (wHint < 0)) wHint = 0;
/* 125 */     if ((hHint != -1) && (hHint < 0)) hHint = 0;
/* 126 */     int border = getBorderWidthInPixels();
/* 127 */     int width = border * 2;int height = border * 2;
/* 128 */     if ((this.style & 0x100) != 0) {
/* 129 */       width += 64;height += 3;
/*     */     } else {
/* 131 */       width += 3;height += 64;
/*     */     }
/* 133 */     if (wHint != -1) width = wHint + border * 2;
/* 134 */     if (hHint != -1) height = hHint + border * 2;
/* 135 */     return new Point(width, height);
/*     */   }
/*     */   
/*     */   void createHandle(int index)
/*     */   {
/* 140 */     this.state |= 0x10008;
/* 141 */     this.handle = OS.g_object_new(this.display.gtk_fixed_get_type(), 0L);
/* 142 */     if (this.handle == 0L) error(2);
/* 143 */     GTK.gtk_widget_set_has_window(this.handle, true);
/* 144 */     GTK.gtk_widget_set_can_focus(this.handle, true);
/* 145 */     int type = (this.style & 0x200) != 0 ? 108 : 116;
/* 146 */     this.defaultCursor = GDK.gdk_cursor_new_for_display(GDK.gdk_display_get_default(), type);
/*     */   }
/*     */   
/*     */   void drawBand(int x, int y, int width, int height) {
/* 150 */     if ((this.style & 0x10000) != 0) return;
/* 151 */     long window = gtk_widget_get_window(this.parent.paintHandle());
/* 152 */     if (window == 0L) return;
/* 153 */     byte[] bits = { -86, 85, -86, 85, -86, 85, -86, 85 };
/* 154 */     long stipplePixmap = GDK.gdk_bitmap_create_from_data(window, bits, 8, 8);
/* 155 */     long gc = GDK.gdk_gc_new(window);
/* 156 */     long colormap = GDK.gdk_colormap_get_system();
/* 157 */     GdkColor color = new GdkColor();
/* 158 */     GDK.gdk_color_white(colormap, color);
/* 159 */     GDK.gdk_gc_set_foreground(gc, color);
/* 160 */     GDK.gdk_gc_set_stipple(gc, stipplePixmap);
/* 161 */     GDK.gdk_gc_set_subwindow(gc, 1L);
/* 162 */     GDK.gdk_gc_set_fill(gc, 2);
/* 163 */     GDK.gdk_gc_set_function(gc, 2L);
/* 164 */     GDK.gdk_draw_rectangle(window, gc, 1, x, y, width, height);
/* 165 */     OS.g_object_unref(stipplePixmap);
/* 166 */     OS.g_object_unref(gc);
/*     */   }
/*     */   
/*     */   long gtk_button_press_event(long widget, long eventPtr)
/*     */   {
/* 171 */     long result = super.gtk_button_press_event(widget, eventPtr);
/* 172 */     if (result != 0L) return result;
/* 173 */     GdkEventButton gdkEvent = new GdkEventButton();
/* 174 */     OS.memmove(gdkEvent, eventPtr, GdkEventButton.sizeof);
/* 175 */     int button = gdkEvent.button;
/* 176 */     if (button != 1) return 0L;
/* 177 */     if (gdkEvent.type == 5) return 0L;
/* 178 */     if (gdkEvent.type == 6) return 0L;
/* 179 */     long window = gtk_widget_get_window(widget);
/* 180 */     int[] origin_x = new int[1];int[] origin_y = new int[1];
/* 181 */     GDK.gdk_window_get_origin(window, origin_x, origin_y);
/* 182 */     this.startX = ((int)(gdkEvent.x_root - origin_x[0]));
/* 183 */     this.startY = ((int)(gdkEvent.y_root - origin_y[0]));
/* 184 */     GtkAllocation allocation = new GtkAllocation();
/* 185 */     GTK.gtk_widget_get_allocation(this.handle, allocation);
/* 186 */     int x = allocation.x;
/* 187 */     int y = allocation.y;
/* 188 */     int width = allocation.width;
/* 189 */     int height = allocation.height;
/* 190 */     this.lastX = x;
/* 191 */     this.lastY = y;
/* 192 */     Event event = new Event();
/* 193 */     event.time = gdkEvent.time;
/* 194 */     Rectangle eventRect = new Rectangle(this.lastX, this.lastY, width, height);
/* 195 */     event.setBounds(DPIUtil.autoScaleDown(eventRect));
/* 196 */     if ((this.style & 0x10000) == 0) {
/* 197 */       event.detail = 1;
/*     */     }
/* 199 */     if ((this.parent.style & 0x8000000) != 0) event.x = (DPIUtil.autoScaleDown(this.parent.getClientWidth() - width) - event.x);
/* 200 */     sendSelectionEvent(13, event, true);
/* 201 */     if (isDisposed()) return 0L;
/* 202 */     if (event.doit) {
/* 203 */       this.dragging = true;
/* 204 */       Rectangle rect = DPIUtil.autoScaleUp(event.getBounds());
/* 205 */       this.lastX = rect.x;
/* 206 */       this.lastY = rect.y;
/* 207 */       if ((this.parent.style & 0x8000000) != 0) this.lastX = (this.parent.getClientWidth() - width - this.lastX);
/* 208 */       this.parent.update(true, (this.style & 0x10000) == 0);
/* 209 */       drawBand(this.lastX, rect.y, width, height);
/* 210 */       if ((this.style & 0x10000) != 0) {
/* 211 */         setBoundsInPixels(rect.x, rect.y, width, height);
/*     */       }
/*     */     }
/*     */     
/* 215 */     return result;
/*     */   }
/*     */   
/*     */   long gtk_button_release_event(long widget, long eventPtr)
/*     */   {
/* 220 */     long result = super.gtk_button_release_event(widget, eventPtr);
/* 221 */     if (result != 0L) return result;
/* 222 */     GdkEventButton gdkEvent = new GdkEventButton();
/* 223 */     OS.memmove(gdkEvent, eventPtr, GdkEventButton.sizeof);
/* 224 */     int button = gdkEvent.button;
/* 225 */     if (button != 1) return 0L;
/* 226 */     if (!this.dragging) return 0L;
/* 227 */     this.dragging = false;
/* 228 */     GtkAllocation allocation = new GtkAllocation();
/* 229 */     GTK.gtk_widget_get_allocation(this.handle, allocation);
/* 230 */     int width = allocation.width;
/* 231 */     int height = allocation.height;
/* 232 */     Event event = new Event();
/* 233 */     event.time = gdkEvent.time;
/* 234 */     Rectangle eventRect = new Rectangle(this.lastX, this.lastY, width, height);
/* 235 */     event.setBounds(DPIUtil.autoScaleDown(eventRect));
/* 236 */     drawBand(this.lastX, this.lastY, width, height);
/* 237 */     if ((this.parent.style & 0x8000000) != 0) event.x = (DPIUtil.autoScaleDown(this.parent.getClientWidth() - width) - event.x);
/* 238 */     sendSelectionEvent(13, event, true);
/* 239 */     if (isDisposed()) return result;
/* 240 */     if ((event.doit) && 
/* 241 */       ((this.style & 0x10000) != 0)) {
/* 242 */       Rectangle rect = DPIUtil.autoScaleUp(event.getBounds());
/* 243 */       setBoundsInPixels(rect.x, rect.y, width, height);
/*     */     }
/*     */     
/*     */ 
/* 247 */     return result;
/*     */   }
/*     */   
/*     */   long gtk_draw(long widget, long cairo)
/*     */   {
/* 252 */     if (GTK.GTK_VERSION >= OS.VERSION(3, 14, 0)) {
/* 253 */       long context = GTK.gtk_widget_get_style_context(widget);
/* 254 */       GtkAllocation allocation = new GtkAllocation();
/* 255 */       GTK.gtk_widget_get_allocation(widget, allocation);
/* 256 */       int width = (this.state & 0x200) != 0 ? 0 : allocation.width;
/* 257 */       int height = (this.state & 0x400) != 0 ? 0 : allocation.height;
/*     */       
/*     */ 
/* 260 */       GTK.gtk_render_background(context, cairo, 0.0D, 0.0D, width, height);
/*     */     }
/* 262 */     return super.gtk_draw(widget, cairo);
/*     */   }
/*     */   
/*     */   long gtk_focus_in_event(long widget, long event)
/*     */   {
/* 267 */     long result = super.gtk_focus_in_event(widget, event);
/* 268 */     if (result != 0L) { return result;
/*     */     }
/* 270 */     if (this.handle != 0L) {
/* 271 */       GtkAllocation allocation = new GtkAllocation();
/* 272 */       GTK.gtk_widget_get_allocation(this.handle, allocation);
/* 273 */       this.lastX = allocation.x;
/* 274 */       this.lastY = allocation.y;
/*     */     }
/* 276 */     return 0L;
/*     */   }
/*     */   
/*     */   long gtk_key_press_event(long widget, long eventPtr)
/*     */   {
/* 281 */     long result = super.gtk_key_press_event(widget, eventPtr);
/* 282 */     if (result != 0L) return result;
/* 283 */     GdkEventKey gdkEvent = new GdkEventKey();
/* 284 */     OS.memmove(gdkEvent, eventPtr, GdkEventKey.sizeof);
/* 285 */     int keyval = gdkEvent.keyval;
/* 286 */     switch (keyval) {
/*     */     case 65361: 
/*     */     case 65362: 
/*     */     case 65363: 
/*     */     case 65364: 
/* 291 */       int xChange = 0;int yChange = 0;
/* 292 */       int stepSize = 9;
/* 293 */       if ((gdkEvent.state & 0x4) != 0) stepSize = 1;
/* 294 */       if ((this.style & 0x200) != 0) {
/* 295 */         if ((keyval == 65362) || (keyval == 65364)) break;
/* 296 */         xChange = keyval == 65361 ? -stepSize : stepSize;
/*     */       } else {
/* 298 */         if ((keyval == 65361) || (keyval == 65363)) break;
/* 299 */         yChange = keyval == 65362 ? -stepSize : stepSize;
/*     */       }
/* 301 */       int parentBorder = 0;
/* 302 */       GtkAllocation allocation = new GtkAllocation();
/* 303 */       GTK.gtk_widget_get_allocation(this.handle, allocation);
/* 304 */       int width = allocation.width;
/* 305 */       int height = allocation.height;
/* 306 */       GTK.gtk_widget_get_allocation(this.parent.handle, allocation);
/* 307 */       int parentWidth = allocation.width;
/* 308 */       int parentHeight = allocation.height;
/* 309 */       int newX = this.lastX;int newY = this.lastY;
/* 310 */       if ((this.style & 0x200) != 0) {
/* 311 */         newX = Math.min(Math.max(0, this.lastX + xChange - parentBorder - this.startX), parentWidth - width);
/*     */       } else {
/* 313 */         newY = Math.min(Math.max(0, this.lastY + yChange - parentBorder - this.startY), parentHeight - height);
/*     */       }
/* 315 */       if ((newX == this.lastX) && (newY == this.lastY)) { return result;
/*     */       }
/*     */       
/* 318 */       long window = gtk_widget_get_window(this.handle);
/* 319 */       int grabMask = 516;
/* 320 */       long gdkCursor = this.cursor != null ? this.cursor.handle : this.defaultCursor;
/* 321 */       int ptrGrabResult = gdk_pointer_grab(window, 0, false, grabMask, window, gdkCursor, 0);
/*     */       
/*     */ 
/* 324 */       Event event = new Event();
/* 325 */       event.time = gdkEvent.time;
/* 326 */       Rectangle eventRect = new Rectangle(newX, newY, width, height);
/* 327 */       event.setBounds(DPIUtil.autoScaleDown(eventRect));
/* 328 */       if ((this.parent.style & 0x8000000) != 0) event.x = (DPIUtil.autoScaleDown(this.parent.getClientWidth() - width) - event.x);
/* 329 */       sendSelectionEvent(13, event, true);
/* 330 */       if (ptrGrabResult == 0) gdk_pointer_ungrab(window, 0);
/* 331 */       if (!isDisposed())
/*     */       {
/* 333 */         if (event.doit) {
/* 334 */           Rectangle rect = DPIUtil.autoScaleUp(event.getBounds());
/* 335 */           this.lastX = rect.x;
/* 336 */           this.lastY = rect.y;
/* 337 */           if ((this.parent.style & 0x8000000) != 0) this.lastX = (this.parent.getClientWidth() - width - this.lastX);
/* 338 */           if ((this.style & 0x10000) != 0) {
/* 339 */             setBoundsInPixels(rect.x, rect.y, width, height);
/* 340 */             if (isDisposed())
/*     */               break;
/* 342 */           } else { int cursorX = rect.x;int cursorY = rect.y;
/* 343 */             if ((this.style & 0x200) != 0) {
/* 344 */               cursorY += height / 2;
/*     */             } else {
/* 346 */               cursorX += width / 2;
/*     */             }
/* 348 */             this.display.setCursorLocation(this.parent.toDisplayInPixels(cursorX, cursorY));
/*     */           }
/*     */         } }
/*     */       break;
/*     */     }
/* 353 */     return result;
/*     */   }
/*     */   
/*     */   long gtk_motion_notify_event(long widget, long eventPtr)
/*     */   {
/* 358 */     long result = super.gtk_motion_notify_event(widget, eventPtr);
/* 359 */     if (result != 0L) return result;
/* 360 */     if (!this.dragging) return 0L;
/* 361 */     GdkEventMotion gdkEvent = new GdkEventMotion();
/* 362 */     OS.memmove(gdkEvent, eventPtr, GdkEventButton.sizeof);
/*     */     int eventState;
/* 364 */     int eventX; int eventY; int eventState; if (gdkEvent.is_hint != 0) {
/* 365 */       int[] pointer_x = new int[1];int[] pointer_y = new int[1];int[] mask = new int[1];
/* 366 */       gdk_window_get_device_position(gdkEvent.window, pointer_x, pointer_y, mask);
/* 367 */       int eventX = pointer_x[0];
/* 368 */       int eventY = pointer_y[0];
/* 369 */       eventState = mask[0];
/*     */     } else {
/* 371 */       int[] origin_x = new int[1];int[] origin_y = new int[1];
/* 372 */       GDK.gdk_window_get_origin(gdkEvent.window, origin_x, origin_y);
/* 373 */       eventX = (int)(gdkEvent.x_root - origin_x[0]);
/* 374 */       eventY = (int)(gdkEvent.y_root - origin_y[0]);
/* 375 */       eventState = gdkEvent.state;
/*     */     }
/* 377 */     if ((eventState & 0x100) == 0) return 0L;
/* 378 */     GtkAllocation allocation = new GtkAllocation();
/* 379 */     GTK.gtk_widget_get_allocation(this.handle, allocation);
/* 380 */     int x = allocation.x;
/* 381 */     int y = allocation.y;
/* 382 */     int width = allocation.width;
/* 383 */     int height = allocation.height;
/* 384 */     int parentBorder = 0;
/* 385 */     GTK.gtk_widget_get_allocation(this.parent.handle, allocation);
/* 386 */     int parentWidth = allocation.width;
/* 387 */     int parentHeight = allocation.height;
/* 388 */     int newX = this.lastX;int newY = this.lastY;
/* 389 */     if ((this.style & 0x200) != 0) {
/* 390 */       newX = Math.min(Math.max(0, eventX + x - this.startX - parentBorder), parentWidth - width);
/*     */     } else {
/* 392 */       newY = Math.min(Math.max(0, eventY + y - this.startY - parentBorder), parentHeight - height);
/*     */     }
/* 394 */     if ((newX == this.lastX) && (newY == this.lastY)) return 0L;
/* 395 */     drawBand(this.lastX, this.lastY, width, height);
/*     */     
/* 397 */     Event event = new Event();
/* 398 */     event.time = gdkEvent.time;
/* 399 */     Rectangle eventRect = new Rectangle(newX, newY, width, height);
/* 400 */     event.setBounds(DPIUtil.autoScaleDown(eventRect));
/* 401 */     if ((this.style & 0x10000) == 0) {
/* 402 */       event.detail = 1;
/*     */     }
/* 404 */     if ((this.parent.style & 0x8000000) != 0) event.x = (DPIUtil.autoScaleDown(this.parent.getClientWidth() - width) - event.x);
/* 405 */     sendSelectionEvent(13, event, true);
/* 406 */     if (isDisposed()) return 0L;
/* 407 */     Rectangle rect = DPIUtil.autoScaleUp(event.getBounds());
/* 408 */     if (event.doit) {
/* 409 */       this.lastX = rect.x;
/* 410 */       this.lastY = rect.y;
/* 411 */       if ((this.parent.style & 0x8000000) != 0) this.lastX = (this.parent.getClientWidth() - width - this.lastX);
/*     */     }
/* 413 */     this.parent.update(true, (this.style & 0x10000) == 0);
/* 414 */     drawBand(this.lastX, this.lastY, width, height);
/* 415 */     if ((this.style & 0x10000) != 0)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 420 */       setBoundsInPixels(this.lastX, this.lastY, width, height);
/*     */     }
/*     */     
/* 423 */     return result;
/*     */   }
/*     */   
/*     */   long gtk_realize(long widget)
/*     */   {
/* 428 */     setCursor(this.cursor != null ? this.cursor.handle : 0L);
/* 429 */     return super.gtk_realize(widget);
/*     */   }
/*     */   
/*     */   void hookEvents()
/*     */   {
/* 434 */     super.hookEvents();
/* 435 */     GTK.gtk_widget_add_events(this.handle, 8);
/*     */   }
/*     */   
/*     */   void releaseWidget()
/*     */   {
/* 440 */     super.releaseWidget();
/* 441 */     if (this.defaultCursor != 0L) gdk_cursor_unref(this.defaultCursor);
/* 442 */     this.defaultCursor = 0L;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeSelectionListener(SelectionListener listener)
/*     */   {
/* 463 */     checkWidget();
/* 464 */     if (listener == null) error(4);
/* 465 */     if (this.eventTable == null) return;
/* 466 */     this.eventTable.unhook(13, listener);
/* 467 */     this.eventTable.unhook(14, listener);
/*     */   }
/*     */   
/*     */   void setCursor(long cursor)
/*     */   {
/* 472 */     super.setCursor(cursor != 0L ? cursor : this.defaultCursor);
/*     */   }
/*     */   
/*     */   int traversalCode(int key, GdkEventKey event)
/*     */   {
/* 477 */     return 0;
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/widgets/Sash.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */