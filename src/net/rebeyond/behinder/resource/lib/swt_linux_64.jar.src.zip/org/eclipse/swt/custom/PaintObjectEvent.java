/*    */ package org.eclipse.swt.custom;
/*    */ 
/*    */ import org.eclipse.swt.events.TypedEvent;
/*    */ import org.eclipse.swt.graphics.GC;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PaintObjectEvent
/*    */   extends TypedEvent
/*    */ {
/*    */   public GC gc;
/*    */   public int x;
/*    */   public int y;
/*    */   public int ascent;
/*    */   public int descent;
/*    */   public StyleRange style;
/*    */   public Bullet bullet;
/*    */   public int bulletIndex;
/*    */   static final long serialVersionUID = 3906081274027192855L;
/*    */   
/*    */   public PaintObjectEvent(StyledTextEvent e)
/*    */   {
/* 74 */     super(e);
/* 75 */     this.gc = e.gc;
/* 76 */     this.x = e.x;
/* 77 */     this.y = e.y;
/* 78 */     this.ascent = e.ascent;
/* 79 */     this.descent = e.descent;
/* 80 */     this.style = e.style;
/* 81 */     this.bullet = e.bullet;
/* 82 */     this.bulletIndex = e.bulletIndex;
/*    */   }
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/custom/PaintObjectEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */