/*     */ package org.eclipse.swt.dnd;
/*     */ 
/*     */ import org.eclipse.swt.internal.C;
/*     */ import org.eclipse.swt.internal.Converter;
/*     */ import org.eclipse.swt.internal.gtk.OS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HTMLTransfer
/*     */   extends ByteArrayTransfer
/*     */ {
/*  32 */   private static HTMLTransfer _instance = new HTMLTransfer();
/*     */   private static final String TEXT_HTML = "text/html";
/*  34 */   private static final int TEXT_HTML_ID = registerType("text/html");
/*     */   private static final String TEXT_HTML2 = "TEXT/HTML";
/*  36 */   private static final int TEXT_HTML2_ID = registerType("TEXT/HTML");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static HTMLTransfer getInstance()
/*     */   {
/*  46 */     return _instance;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void javaToNative(Object object, TransferData transferData)
/*     */   {
/*  61 */     transferData.result = 0;
/*  62 */     if ((!checkHTML(object)) || (!isSupportedType(transferData))) {
/*  63 */       DND.error(2003);
/*     */     }
/*  65 */     String string = (String)object;
/*  66 */     byte[] utf8 = Converter.wcsToMbcs(string, true);
/*  67 */     int byteCount = utf8.length;
/*  68 */     long pValue = OS.g_malloc(byteCount);
/*  69 */     if (pValue == 0L) return;
/*  70 */     C.memmove(pValue, utf8, byteCount);
/*  71 */     transferData.length = byteCount;
/*  72 */     transferData.format = 8;
/*  73 */     transferData.pValue = pValue;
/*  74 */     transferData.result = 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object nativeToJava(TransferData transferData)
/*     */   {
/*  89 */     if ((!isSupportedType(transferData)) || (transferData.pValue == 0L)) { return null;
/*     */     }
/*  91 */     int size = transferData.format * transferData.length / 8 / 2 * 2;
/*  92 */     if (size <= 0) return null;
/*  93 */     char[] bom = new char[1];
/*  94 */     if (size > 1) C.memmove(bom, transferData.pValue, 2L);
/*     */     String string;
/*  96 */     String string; if ((bom[0] == 65279) || (bom[0] == 65534))
/*     */     {
/*  98 */       char[] chars = new char[size / 2];
/*  99 */       C.memmove(chars, transferData.pValue, size);
/* 100 */       string = new String(chars);
/*     */     } else {
/* 102 */       byte[] utf8 = new byte[size];
/* 103 */       C.memmove(utf8, transferData.pValue, size);
/*     */       
/* 105 */       char[] unicode = Converter.mbcsToWcs(utf8);
/* 106 */       string = new String(unicode);
/*     */     }
/* 108 */     int end = string.indexOf(0);
/* 109 */     return end == -1 ? string : string.substring(0, end);
/*     */   }
/*     */   
/*     */   protected int[] getTypeIds() {
/* 113 */     return new int[] { TEXT_HTML_ID, TEXT_HTML2_ID };
/*     */   }
/*     */   
/*     */   protected String[] getTypeNames()
/*     */   {
/* 118 */     return new String[] { "text/html", "TEXT/HTML" };
/*     */   }
/*     */   
/*     */   boolean checkHTML(Object object) {
/* 122 */     return (object != null) && ((object instanceof String)) && (((String)object).length() > 0);
/*     */   }
/*     */   
/*     */   protected boolean validate(Object object)
/*     */   {
/* 127 */     return checkHTML(object);
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/dnd/HTMLTransfer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */