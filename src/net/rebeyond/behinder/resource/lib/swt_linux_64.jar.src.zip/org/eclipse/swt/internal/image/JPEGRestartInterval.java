/*    */ package org.eclipse.swt.internal.image;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class JPEGRestartInterval
/*    */   extends JPEGFixedSizeSegment
/*    */ {
/*    */   public JPEGRestartInterval(LEDataInputStream byteStream)
/*    */   {
/* 17 */     super(byteStream);
/*    */   }
/*    */   
/*    */   public int signature()
/*    */   {
/* 22 */     return 65501;
/*    */   }
/*    */   
/*    */   public int getRestartInterval() {
/* 26 */     return (this.reference[4] & 0xFF) << 8 | this.reference[5] & 0xFF;
/*    */   }
/*    */   
/*    */   public int fixedSize()
/*    */   {
/* 31 */     return 6;
/*    */   }
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/internal/image/JPEGRestartInterval.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */