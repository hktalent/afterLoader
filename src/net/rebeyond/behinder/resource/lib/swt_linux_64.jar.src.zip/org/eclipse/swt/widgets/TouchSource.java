/*    */ package org.eclipse.swt.widgets;
/*    */ 
/*    */ import org.eclipse.swt.graphics.Rectangle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class TouchSource
/*    */ {
/*    */   long handle;
/*    */   boolean direct;
/*    */   Rectangle bounds;
/*    */   
/*    */   TouchSource(long handle, boolean direct, Rectangle bounds)
/*    */   {
/* 53 */     this.handle = handle;
/* 54 */     this.direct = direct;
/* 55 */     this.bounds = bounds;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean isDirect()
/*    */   {
/* 64 */     return this.direct;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Rectangle getBounds()
/*    */   {
/* 76 */     return new Rectangle(this.bounds.x, this.bounds.y, this.bounds.width, this.bounds.height);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String toString()
/*    */   {
/* 87 */     return "TouchSource {handle=" + this.handle + " direct=" + this.direct + " bounds=" + this.bounds + "}";
/*    */   }
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/widgets/TouchSource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */