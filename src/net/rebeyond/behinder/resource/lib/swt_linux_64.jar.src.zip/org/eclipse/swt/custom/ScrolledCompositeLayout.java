/*     */ package org.eclipse.swt.custom;
/*     */ 
/*     */ import org.eclipse.swt.graphics.FontMetrics;
/*     */ import org.eclipse.swt.graphics.GC;
/*     */ import org.eclipse.swt.graphics.Point;
/*     */ import org.eclipse.swt.graphics.Rectangle;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.swt.widgets.Control;
/*     */ import org.eclipse.swt.widgets.Layout;
/*     */ import org.eclipse.swt.widgets.ScrollBar;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ScrolledCompositeLayout
/*     */   extends Layout
/*     */ {
/*  24 */   boolean inLayout = false;
/*     */   static final int DEFAULT_WIDTH = 64;
/*     */   static final int DEFAULT_HEIGHT = 64;
/*     */   
/*     */   protected Point computeSize(Composite composite, int wHint, int hHint, boolean flushCache)
/*     */   {
/*  30 */     ScrolledComposite sc = (ScrolledComposite)composite;
/*  31 */     Point size = new Point(64, 64);
/*  32 */     if (sc.content != null) {
/*  33 */       Point preferredSize = sc.content.computeSize(wHint, hHint, flushCache);
/*  34 */       Point currentSize = sc.content.getSize();
/*  35 */       size.x = (sc.getExpandHorizontal() ? preferredSize.x : currentSize.x);
/*  36 */       size.y = (sc.getExpandVertical() ? preferredSize.y : currentSize.y);
/*     */     }
/*  38 */     size.x = Math.max(size.x, sc.minWidth);
/*  39 */     size.y = Math.max(size.y, sc.minHeight);
/*  40 */     if (wHint != -1) size.x = wHint;
/*  41 */     if (hHint != -1) size.y = hHint;
/*  42 */     return size;
/*     */   }
/*     */   
/*     */   protected boolean flushCache(Control control)
/*     */   {
/*  47 */     return true;
/*     */   }
/*     */   
/*     */   protected void layout(Composite composite, boolean flushCache)
/*     */   {
/*  52 */     if (this.inLayout) return;
/*  53 */     ScrolledComposite sc = (ScrolledComposite)composite;
/*  54 */     if (sc.content == null) return;
/*  55 */     ScrollBar hBar = sc.getHorizontalBar();
/*  56 */     ScrollBar vBar = sc.getVerticalBar();
/*  57 */     if ((hBar != null) && 
/*  58 */       (hBar.getSize().y >= sc.getSize().y)) {
/*  59 */       return;
/*     */     }
/*     */     
/*  62 */     if ((vBar != null) && 
/*  63 */       (vBar.getSize().x >= sc.getSize().x)) {
/*  64 */       return;
/*     */     }
/*     */     
/*  67 */     this.inLayout = true;
/*  68 */     Rectangle contentRect = sc.content.getBounds();
/*  69 */     if (!sc.alwaysShowScroll) {
/*  70 */       boolean hVisible = sc.needHScroll(contentRect, false);
/*  71 */       boolean vVisible = sc.needVScroll(contentRect, hVisible);
/*  72 */       if ((!hVisible) && (vVisible)) hVisible = sc.needHScroll(contentRect, vVisible);
/*  73 */       if (hBar != null) hBar.setVisible(hVisible);
/*  74 */       if (vBar != null) vBar.setVisible(vVisible);
/*     */     }
/*  76 */     Rectangle hostRect = sc.getClientArea();
/*  77 */     if (sc.expandHorizontal) {
/*  78 */       contentRect.width = Math.max(sc.minWidth, hostRect.width);
/*     */     }
/*  80 */     if (sc.expandVertical) {
/*  81 */       contentRect.height = Math.max(sc.minHeight, hostRect.height);
/*     */     }
/*     */     
/*  84 */     GC gc = new GC(sc);
/*  85 */     if (hBar != null) {
/*  86 */       hBar.setMaximum(contentRect.width);
/*  87 */       hBar.setThumb(Math.min(contentRect.width, hostRect.width));
/*  88 */       hBar.setIncrement((int)gc.getFontMetrics().getAverageCharacterWidth());
/*  89 */       hBar.setPageIncrement(hostRect.width);
/*  90 */       int hPage = contentRect.width - hostRect.width;
/*  91 */       int hSelection = hBar.getSelection();
/*  92 */       if (hSelection >= hPage) {
/*  93 */         if (hPage <= 0) {
/*  94 */           hSelection = 0;
/*  95 */           hBar.setSelection(0);
/*     */         }
/*  97 */         contentRect.x = (-hSelection);
/*     */       }
/*     */     }
/*     */     
/* 101 */     if (vBar != null) {
/* 102 */       vBar.setMaximum(contentRect.height);
/* 103 */       vBar.setThumb(Math.min(contentRect.height, hostRect.height));
/* 104 */       vBar.setIncrement(gc.getFontMetrics().getHeight());
/* 105 */       vBar.setPageIncrement(hostRect.height);
/* 106 */       int vPage = contentRect.height - hostRect.height;
/* 107 */       int vSelection = vBar.getSelection();
/* 108 */       if (vSelection >= vPage) {
/* 109 */         if (vPage <= 0) {
/* 110 */           vSelection = 0;
/* 111 */           vBar.setSelection(0);
/*     */         }
/* 113 */         contentRect.y = (-vSelection);
/*     */       }
/*     */     }
/* 116 */     gc.dispose();
/*     */     
/* 118 */     sc.content.setBounds(contentRect);
/* 119 */     this.inLayout = false;
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/custom/ScrolledCompositeLayout.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */