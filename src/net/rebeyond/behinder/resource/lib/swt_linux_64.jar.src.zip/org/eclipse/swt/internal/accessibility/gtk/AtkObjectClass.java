package org.eclipse.swt.internal.accessibility.gtk;

public class AtkObjectClass
{
  public long get_name;
  public long get_description;
  public long get_parent;
  public long get_n_children;
  public long ref_child;
  public long get_index_in_parent;
  public long ref_relation_set;
  public long get_role;
  public long get_layer;
  public long get_mdi_zorder;
  public long ref_state_set;
  public long set_name;
  public long set_description;
  public long set_parent;
  public long set_role;
  public long connect_property_change_handler;
  public long remove_property_change_handler;
  public long initialize;
  public long children_changed;
  public long focus_event;
  public long property_change;
  public long state_change;
  public long visible_data_changed;
  public long get_attributes;
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/internal/accessibility/gtk/AtkObjectClass.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */