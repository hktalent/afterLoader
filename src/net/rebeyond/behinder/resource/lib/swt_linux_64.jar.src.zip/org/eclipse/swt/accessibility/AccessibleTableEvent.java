/*    */ package org.eclipse.swt.accessibility;
/*    */ 
/*    */ import java.util.EventObject;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AccessibleTableEvent
/*    */   extends EventObject
/*    */ {
/*    */   public Accessible accessible;
/*    */   public Accessible[] accessibles;
/*    */   public String result;
/*    */   public int column;
/*    */   public int row;
/*    */   public int count;
/*    */   public boolean isSelected;
/*    */   public int[] selected;
/*    */   static final long serialVersionUID = 1624586163666270447L;
/*    */   
/*    */   public AccessibleTableEvent(Object source)
/*    */   {
/* 49 */     super(source);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String toString()
/*    */   {
/* 60 */     return "AccessibleTableEvent {accessible=" + this.accessible + " accessibles=" + this.accessibles + " string=" + this.result + " isSelected=" + this.isSelected + " column=" + this.column + " count=" + this.count + " row=" + this.row + " selected=" + this.selected + "}";
/*    */   }
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/accessibility/AccessibleTableEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */