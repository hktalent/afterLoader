/*     */ package org.eclipse.swt.internal;
/*     */ 
/*     */ import org.eclipse.swt.graphics.GC;
/*     */ import org.eclipse.swt.widgets.Control;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BidiUtil
/*     */ {
/*     */   public static final int KEYBOARD_NON_BIDI = 0;
/*     */   public static final int KEYBOARD_BIDI = 1;
/*     */   public static final int CLASSIN = 1;
/*     */   public static final int LINKBEFORE = 2;
/*     */   public static final int LINKAFTER = 4;
/*     */   public static final int CLASS_HEBREW = 2;
/*     */   public static final int CLASS_ARABIC = 2;
/*     */   public static final int CLASS_LOCALNUMBER = 4;
/*     */   public static final int CLASS_LATINNUMBER = 5;
/*     */   public static final int REORDER = 0;
/*     */   public static final int LIGATE = 0;
/*     */   public static final int GLYPHSHAPE = 0;
/*     */   
/*     */   public static void addLanguageListener(long hwnd, Runnable runnable) {}
/*     */   
/*     */   public static void addLanguageListener(Control control, Runnable runnable) {}
/*     */   
/*     */   public static void drawGlyphs(GC gc, char[] renderBuffer, int[] renderDx, int x, int y) {}
/*     */   
/*     */   public static boolean isBidiPlatform()
/*     */   {
/*  61 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   public static boolean isKeyboardBidi()
/*     */   {
/*  67 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   public static int getFontBidiAttributes(GC gc)
/*     */   {
/*  73 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void getOrderInfo(GC gc, String text, int[] order, byte[] classBuffer, int flags, int[] offsets) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static char[] getRenderInfo(GC gc, String text, int[] order, byte[] classBuffer, int[] dx, int flags, int[] offsets)
/*     */   {
/*  86 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public static int getKeyboardLanguage()
/*     */   {
/*  92 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static void removeLanguageListener(long hwnd) {}
/*     */   
/*     */ 
/*     */   public static void removeLanguageListener(Control control) {}
/*     */   
/*     */ 
/*     */   public static int resolveTextDirection(String text)
/*     */   {
/* 105 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static void setKeyboardLanguage(int language) {}
/*     */   
/*     */ 
/*     */ 
/*     */   public static boolean setOrientation(long hwnd, int orientation)
/*     */   {
/* 116 */     return false;
/*     */   }
/*     */   
/* 119 */   public static boolean setOrientation(Control control, int orientation) { return false; }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/internal/BidiUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */