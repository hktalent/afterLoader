/*    */ package org.eclipse.swt.internal.gtk;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GdkRGBA
/*    */ {
/*    */   public double red;
/*    */   
/*    */ 
/*    */ 
/*    */   public double green;
/*    */   
/*    */ 
/*    */ 
/*    */   public double blue;
/*    */   
/*    */ 
/*    */ 
/*    */   public double alpha;
/*    */   
/*    */ 
/* 23 */   public static final int sizeof = ;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String toString()
/*    */   {
/* 33 */     return "GdkRGBA {" + (int)(this.red * 255.0D) + ", " + (int)(this.green * 255.0D) + ", " + (int)(this.blue * 255.0D) + ", " + (int)(this.alpha * 255.0D) + "}";
/*    */   }
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/internal/gtk/GdkRGBA.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */