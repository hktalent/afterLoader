/*    */ package org.eclipse.swt.custom;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class SashFormData
/*    */ {
/*    */   long weight;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   String getName()
/*    */   {
/* 18 */     String string = getClass().getName();
/* 19 */     int index = string.lastIndexOf('.');
/* 20 */     if (index == -1) return string;
/* 21 */     return string.substring(index + 1, string.length());
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String toString()
/*    */   {
/* 32 */     return getName() + " {weight=" + this.weight + "}";
/*    */   }
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/custom/SashFormData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */