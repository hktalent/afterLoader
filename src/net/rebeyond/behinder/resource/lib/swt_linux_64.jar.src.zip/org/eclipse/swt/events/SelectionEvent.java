/*     */ package org.eclipse.swt.events;
/*     */ 
/*     */ import org.eclipse.swt.widgets.Event;
/*     */ import org.eclipse.swt.widgets.Widget;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SelectionEvent
/*     */   extends TypedEvent
/*     */ {
/*     */   public Widget item;
/*     */   public int detail;
/*     */   public int x;
/*     */   public int y;
/*     */   public int width;
/*     */   public int height;
/*     */   public int stateMask;
/*     */   public String text;
/*     */   public boolean doit;
/*     */   static final long serialVersionUID = 3976735856884987953L;
/*     */   
/*     */   public SelectionEvent(Event e)
/*     */   {
/* 117 */     super(e);
/* 118 */     this.item = e.item;
/* 119 */     this.x = e.x;
/* 120 */     this.y = e.y;
/* 121 */     this.width = e.width;
/* 122 */     this.height = e.height;
/* 123 */     this.detail = e.detail;
/* 124 */     this.stateMask = e.stateMask;
/* 125 */     this.text = e.text;
/* 126 */     this.doit = e.doit;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 137 */     String string = super.toString();
/* 138 */     return string.substring(0, string.length() - 1) + " item=" + this.item + " detail=" + this.detail + " x=" + this.x + " y=" + this.y + " width=" + this.width + " height=" + this.height + " stateMask=0x" + 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 145 */       Integer.toHexString(this.stateMask) + " text=" + this.text + " doit=" + this.doit + "}";
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/events/SelectionEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */