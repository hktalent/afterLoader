package org.eclipse.swt.custom;

@FunctionalInterface
public abstract interface StyledTextLineSpacingProvider
{
  public abstract Integer getLineSpacing(int paramInt);
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/custom/StyledTextLineSpacingProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */