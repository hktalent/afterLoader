/*     */ package org.eclipse.swt.custom;
/*     */ 
/*     */ import org.eclipse.swt.graphics.Point;
/*     */ import org.eclipse.swt.graphics.Rectangle;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.swt.widgets.Control;
/*     */ import org.eclipse.swt.widgets.Layout;
/*     */ import org.eclipse.swt.widgets.Scrollable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class CBannerLayout
/*     */   extends Layout
/*     */ {
/*     */   protected Point computeSize(Composite composite, int wHint, int hHint, boolean flushCache)
/*     */   {
/*  26 */     CBanner banner = (CBanner)composite;
/*  27 */     Control left = banner.left;
/*  28 */     Control right = banner.right;
/*  29 */     Control bottom = banner.bottom;
/*  30 */     boolean showCurve = (left != null) && (right != null);
/*  31 */     int height = hHint;
/*  32 */     int width = wHint;
/*     */     
/*     */ 
/*  35 */     Point bottomSize = new Point(0, 0);
/*  36 */     if (bottom != null) {
/*  37 */       int trim = computeTrim(bottom);
/*  38 */       int w = wHint == -1 ? -1 : Math.max(0, width - trim);
/*  39 */       bottomSize = computeChildSize(bottom, w, -1, flushCache);
/*     */     }
/*  41 */     Point rightSize = new Point(0, 0);
/*  42 */     if (right != null) {
/*  43 */       int trim = computeTrim(right);
/*  44 */       int w = -1;
/*  45 */       if (banner.rightWidth != -1) {
/*  46 */         w = banner.rightWidth - trim;
/*  47 */         if (left != null) {
/*  48 */           w = Math.min(w, width - banner.curve_width + 2 * banner.curve_indent - 10 - trim);
/*     */         }
/*  50 */         w = Math.max(0, w);
/*     */       }
/*  52 */       rightSize = computeChildSize(right, w, -1, flushCache);
/*  53 */       if (wHint != -1) {
/*  54 */         width -= rightSize.x + banner.curve_width - 2 * banner.curve_indent;
/*     */       }
/*     */     }
/*  57 */     Point leftSize = new Point(0, 0);
/*  58 */     if (left != null) {
/*  59 */       int trim = computeTrim(left);
/*  60 */       int w = wHint == -1 ? -1 : Math.max(0, width - trim);
/*  61 */       leftSize = computeChildSize(left, w, -1, flushCache);
/*     */     }
/*     */     
/*     */ 
/*  65 */     width = leftSize.x + rightSize.x;
/*  66 */     height = bottomSize.y;
/*  67 */     if ((bottom != null) && ((left != null) || (right != null))) {
/*  68 */       height += 3;
/*     */     }
/*  70 */     if (left != null) {
/*  71 */       if (right == null) {
/*  72 */         height += leftSize.y;
/*     */       } else {
/*  74 */         height += Math.max(leftSize.y, banner.rightMinHeight == -1 ? rightSize.y : banner.rightMinHeight);
/*     */       }
/*     */     } else {
/*  77 */       height += rightSize.y;
/*     */     }
/*  79 */     if (showCurve) {
/*  80 */       width += banner.curve_width - 2 * banner.curve_indent;
/*  81 */       height += 7;
/*     */     }
/*     */     
/*  84 */     if (wHint != -1) width = wHint;
/*  85 */     if (hHint != -1) { height = hHint;
/*     */     }
/*  87 */     return new Point(width, height);
/*     */   }
/*     */   
/*  90 */   Point computeChildSize(Control control, int wHint, int hHint, boolean flushCache) { Object data = control.getLayoutData();
/*  91 */     if ((data == null) || (!(data instanceof CLayoutData))) {
/*  92 */       data = new CLayoutData();
/*  93 */       control.setLayoutData(data);
/*     */     }
/*  95 */     return ((CLayoutData)data).computeSize(control, wHint, hHint, flushCache);
/*     */   }
/*     */   
/*  98 */   int computeTrim(Control c) { if ((c instanceof Scrollable)) {
/*  99 */       Rectangle rect = ((Scrollable)c).computeTrim(0, 0, 0, 0);
/* 100 */       return rect.width;
/*     */     }
/* 102 */     return c.getBorderWidth() * 2;
/*     */   }
/*     */   
/*     */   protected boolean flushCache(Control control) {
/* 106 */     Object data = control.getLayoutData();
/* 107 */     if ((data != null) && ((data instanceof CLayoutData))) ((CLayoutData)data).flushCache();
/* 108 */     return true;
/*     */   }
/*     */   
/*     */   protected void layout(Composite composite, boolean flushCache) {
/* 112 */     CBanner banner = (CBanner)composite;
/* 113 */     Control left = banner.left;
/* 114 */     Control right = banner.right;
/* 115 */     Control bottom = banner.bottom;
/*     */     
/* 117 */     Point size = banner.getSize();
/* 118 */     boolean showCurve = (left != null) && (right != null);
/* 119 */     int width = size.x - 2 * banner.getBorderWidth();
/* 120 */     int height = size.y - 2 * banner.getBorderWidth();
/*     */     
/* 122 */     Point bottomSize = new Point(0, 0);
/* 123 */     if (bottom != null) {
/* 124 */       int trim = computeTrim(bottom);
/* 125 */       int w = Math.max(0, width - trim);
/* 126 */       bottomSize = computeChildSize(bottom, w, -1, flushCache);
/* 127 */       height -= bottomSize.y + 1 + 2;
/*     */     }
/* 129 */     if (showCurve) height -= 7;
/* 130 */     height = Math.max(0, height);
/* 131 */     Point rightSize = new Point(0, 0);
/* 132 */     if (right != null) {
/* 133 */       int trim = computeTrim(right);
/* 134 */       int w = -1;
/* 135 */       if (banner.rightWidth != -1) {
/* 136 */         w = banner.rightWidth - trim;
/* 137 */         if (left != null) {
/* 138 */           w = Math.min(w, width - banner.curve_width + 2 * banner.curve_indent - 10 - trim);
/*     */         }
/* 140 */         w = Math.max(0, w);
/*     */       }
/* 142 */       rightSize = computeChildSize(right, w, -1, flushCache);
/* 143 */       width -= rightSize.x - banner.curve_indent + banner.curve_width - banner.curve_indent;
/*     */     }
/* 145 */     Point leftSize = new Point(0, 0);
/* 146 */     if (left != null) {
/* 147 */       int trim = computeTrim(left);
/* 148 */       int w = Math.max(0, width - trim);
/* 149 */       leftSize = computeChildSize(left, w, -1, flushCache);
/*     */     }
/*     */     
/* 152 */     int x = 0;
/* 153 */     int y = 0;
/* 154 */     int oldStart = banner.curveStart;
/* 155 */     Rectangle leftRect = null;
/* 156 */     Rectangle rightRect = null;
/* 157 */     Rectangle bottomRect = null;
/* 158 */     if (bottom != null) {
/* 159 */       bottomRect = new Rectangle(x, y + size.y - bottomSize.y, bottomSize.x, bottomSize.y);
/*     */     }
/* 161 */     if (showCurve) y += 4;
/* 162 */     if (left != null) {
/* 163 */       leftRect = new Rectangle(x, y, leftSize.x, leftSize.y);
/* 164 */       banner.curveStart = (x + leftSize.x - banner.curve_indent);
/* 165 */       x += leftSize.x - banner.curve_indent + banner.curve_width - banner.curve_indent;
/*     */     }
/* 167 */     if (right != null) {
/* 168 */       if (left != null) {
/* 169 */         rightSize.y = Math.max(leftSize.y, banner.rightMinHeight == -1 ? rightSize.y : banner.rightMinHeight);
/*     */       }
/* 171 */       rightRect = new Rectangle(x, y, rightSize.x, rightSize.y);
/*     */     }
/* 173 */     if (banner.curveStart < oldStart) {
/* 174 */       banner.redraw(banner.curveStart - 200, 0, oldStart + banner.curve_width - banner.curveStart + 200 + 5, size.y, false);
/*     */     }
/* 176 */     if (banner.curveStart > oldStart) {
/* 177 */       banner.redraw(oldStart - 200, 0, banner.curveStart + banner.curve_width - oldStart + 200 + 5, size.y, false);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 185 */     banner.update();
/* 186 */     banner.curveRect = new Rectangle(banner.curveStart, 0, banner.curve_width, size.y);
/* 187 */     if (bottomRect != null) bottom.setBounds(bottomRect);
/* 188 */     if (rightRect != null) right.setBounds(rightRect);
/* 189 */     if (leftRect != null) left.setBounds(leftRect);
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/custom/CBannerLayout.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */