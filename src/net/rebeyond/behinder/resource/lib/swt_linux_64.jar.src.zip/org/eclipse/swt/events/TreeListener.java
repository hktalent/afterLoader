/*    */ package org.eclipse.swt.events;
/*    */ 
/*    */ import java.util.function.Consumer;
/*    */ import org.eclipse.swt.internal.SWTEventListener;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract interface TreeListener
/*    */   extends SWTEventListener
/*    */ {
/*    */   public abstract void treeCollapsed(TreeEvent paramTreeEvent);
/*    */   
/*    */   public abstract void treeExpanded(TreeEvent paramTreeEvent);
/*    */   
/*    */   public static TreeListener treeCollapsedAdapter(Consumer<TreeEvent> c)
/*    */   {
/* 59 */     new TreeAdapter()
/*    */     {
/*    */       public void treeCollapsed(TreeEvent e) {
/* 62 */         this.val$c.accept(e);
/*    */       }
/*    */     };
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static TreeListener treeExpandedAdapter(Consumer<TreeEvent> c)
/*    */   {
/* 76 */     new TreeAdapter()
/*    */     {
/*    */       public void treeExpanded(TreeEvent e) {
/* 79 */         this.val$c.accept(e);
/*    */       }
/*    */     };
/*    */   }
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/events/TreeListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */