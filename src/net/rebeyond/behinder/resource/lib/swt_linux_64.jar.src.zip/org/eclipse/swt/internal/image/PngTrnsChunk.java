/*     */ package org.eclipse.swt.internal.image;
/*     */ 
/*     */ import org.eclipse.swt.SWT;
/*     */ import org.eclipse.swt.graphics.RGB;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PngTrnsChunk
/*     */   extends PngChunk
/*     */ {
/*     */   static final int TRANSPARENCY_TYPE_PIXEL = 0;
/*     */   static final int TRANSPARENCY_TYPE_ALPHAS = 1;
/*     */   static final int RGB_DATA_LENGTH = 6;
/*     */   
/*     */   PngTrnsChunk(RGB rgb)
/*     */   {
/*  23 */     super(6);
/*  24 */     setType(TYPE_tRNS);
/*  25 */     setInt16(8, rgb.red);
/*  26 */     setInt16(10, rgb.green);
/*  27 */     setInt16(12, rgb.blue);
/*  28 */     setCRC(computeCRC());
/*     */   }
/*     */   
/*     */   PngTrnsChunk(byte[] reference) {
/*  32 */     super(reference);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*  37 */   int getChunkType() { return 5; }
/*     */   
/*     */   void validateLength(PngIhdrChunk header, PngPlteChunk paletteChunk) { boolean valid;
/*     */     boolean valid;
/*     */     boolean valid;
/*  42 */     boolean valid; switch (header.getColorType())
/*     */     {
/*     */     case 2: 
/*  45 */       valid = getLength() == 6;
/*  46 */       break;
/*     */     
/*     */     case 3: 
/*  49 */       valid = getLength() <= paletteChunk.getLength();
/*  50 */       break;
/*     */     
/*     */     case 0: 
/*  53 */       valid = getLength() == 2;
/*  54 */       break;
/*     */     case 1: case 4: 
/*     */     case 5: 
/*     */     case 6: 
/*     */     default: 
/*  59 */       valid = false;
/*     */     }
/*  61 */     if (!valid) {
/*  62 */       SWT.error(40);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   void validate(PngFileReadState readState, PngIhdrChunk headerChunk, PngPlteChunk paletteChunk)
/*     */   {
/*  70 */     if ((!readState.readIHDR) || 
/*  71 */       ((headerChunk.getMustHavePalette()) && (!readState.readPLTE)) || (readState.readIDAT) || (readState.readIEND))
/*     */     {
/*     */ 
/*     */ 
/*  75 */       SWT.error(40);
/*     */     } else {
/*  77 */       readState.readTRNS = true;
/*     */     }
/*     */     
/*  80 */     validateLength(headerChunk, paletteChunk);
/*     */     
/*  82 */     super.validate(readState, headerChunk);
/*     */   }
/*     */   
/*     */   int getTransparencyType(PngIhdrChunk header)
/*     */   {
/*  87 */     if (header.getColorType() == 3) {
/*  88 */       return 1;
/*     */     }
/*  90 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   int getSwtTransparentPixel(PngIhdrChunk header)
/*     */   {
/* 103 */     switch (header.getColorType()) {
/*     */     case 0: 
/* 105 */       int gray = ((this.reference[8] & 0xFF) << 8) + (this.reference[9] & 0xFF);
/*     */       
/* 107 */       if (header.getBitDepth() > 8) {
/* 108 */         return PNGFileFormat.compress16BitDepthTo8BitDepth(gray);
/*     */       }
/* 110 */       return gray & 0xFF;
/*     */     case 2: 
/* 112 */       int red = (this.reference[8] & 0xFF) << 8 | this.reference[9] & 0xFF;
/*     */       
/* 114 */       int green = (this.reference[10] & 0xFF) << 8 | this.reference[11] & 0xFF;
/*     */       
/* 116 */       int blue = (this.reference[12] & 0xFF) << 8 | this.reference[13] & 0xFF;
/*     */       
/* 118 */       if (header.getBitDepth() > 8) {
/* 119 */         red = PNGFileFormat.compress16BitDepthTo8BitDepth(red);
/* 120 */         green = PNGFileFormat.compress16BitDepthTo8BitDepth(green);
/* 121 */         blue = PNGFileFormat.compress16BitDepthTo8BitDepth(blue);
/*     */       }
/* 123 */       return red << 16 | green << 8 | blue;
/*     */     }
/* 125 */     SWT.error(40);
/* 126 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   byte[] getAlphaValues(PngIhdrChunk header, PngPlteChunk paletteChunk)
/*     */   {
/* 136 */     if (header.getColorType() != 3) {
/* 137 */       SWT.error(40);
/*     */     }
/* 139 */     byte[] alphas = new byte[paletteChunk.getPaletteSize()];
/* 140 */     int dataLength = getLength();
/* 141 */     int i = 0;
/* 142 */     for (i = 0; i < dataLength; i++) {
/* 143 */       alphas[i] = this.reference[(8 + i)];
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 150 */     for (int j = i; j < alphas.length; j++) {
/* 151 */       alphas[j] = -1;
/*     */     }
/* 153 */     return alphas;
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/internal/image/PngTrnsChunk.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */