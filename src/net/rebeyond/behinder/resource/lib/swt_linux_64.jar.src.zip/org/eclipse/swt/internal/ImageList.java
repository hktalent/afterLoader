/*     */ package org.eclipse.swt.internal;
/*     */ 
/*     */ import org.eclipse.swt.SWT;
/*     */ import org.eclipse.swt.graphics.Image;
/*     */ import org.eclipse.swt.graphics.Rectangle;
/*     */ import org.eclipse.swt.internal.cairo.Cairo;
/*     */ import org.eclipse.swt.internal.gtk.GDK;
/*     */ import org.eclipse.swt.internal.gtk.GTK;
/*     */ import org.eclipse.swt.internal.gtk.OS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ImageList
/*     */ {
/*     */   Image[] images;
/*  21 */   int height = -1; int width = -1;
/*     */   long[] pixbufs;
/*     */   
/*     */   public ImageList() {
/*  25 */     this.images = new Image[4];
/*  26 */     this.pixbufs = new long[4];
/*     */   }
/*     */   
/*     */   public static long convertSurface(Image image) {
/*  30 */     long newSurface = image.surface;
/*  31 */     int type = Cairo.cairo_surface_get_type(newSurface);
/*  32 */     if (type != 0) {
/*  33 */       Rectangle bounds = image.getBounds();
/*  34 */       int format = Cairo.cairo_surface_get_content(newSurface) == 4096 ? 1 : 0;
/*  35 */       newSurface = Cairo.cairo_image_surface_create(format, bounds.width, bounds.height);
/*  36 */       if (newSurface == 0L) { SWT.error(2);
/*     */       }
/*  38 */       if (GTK.GTK3) {
/*  39 */         double[] sx = new double[1];
/*  40 */         double[] sy = new double[1];
/*  41 */         Cairo.cairo_surface_get_device_scale(image.surface, sx, sy);
/*  42 */         if ((sx[0] == 0.0D) || (sy[0] == 0.0D)) {
/*  43 */           sx[0] = (sy[0] = DPIUtil.getDeviceZoom() / 100.0F);
/*     */         }
/*  45 */         Cairo.cairo_surface_set_device_scale(newSurface, sx[0], sy[0]);
/*     */       }
/*  47 */       long cairo = Cairo.cairo_create(newSurface);
/*  48 */       if (cairo == 0L) SWT.error(2);
/*  49 */       Cairo.cairo_set_operator(cairo, 1);
/*  50 */       Cairo.cairo_set_source_surface(cairo, image.surface, 0.0D, 0.0D);
/*  51 */       Cairo.cairo_paint(cairo);
/*  52 */       Cairo.cairo_destroy(cairo);
/*     */     } else {
/*  54 */       Cairo.cairo_surface_reference(newSurface);
/*     */     }
/*  56 */     return newSurface;
/*     */   }
/*     */   
/*     */   public static long createPixbuf(Image image) {
/*  60 */     long surface = convertSurface(image);
/*  61 */     int format = Cairo.cairo_image_surface_get_format(surface);
/*  62 */     int width = Cairo.cairo_image_surface_get_width(surface);
/*  63 */     int height = Cairo.cairo_image_surface_get_height(surface);
/*  64 */     boolean hasAlpha = format == 0;
/*  65 */     long pixbuf = GDK.gdk_pixbuf_new(0, hasAlpha, 8, width, height);
/*  66 */     if (pixbuf == 0L) SWT.error(2);
/*  67 */     int stride = GDK.gdk_pixbuf_get_rowstride(pixbuf);
/*  68 */     long pixels = GDK.gdk_pixbuf_get_pixels(pixbuf);
/*     */     int ob;
/*  70 */     int oa; int or; int og; int ob; if (OS.BIG_ENDIAN) {
/*  71 */       int oa = 0;int or = 1;int og = 2;ob = 3;
/*     */     } else {
/*  73 */       oa = 3;or = 2;og = 1;ob = 0;
/*     */     }
/*  75 */     byte[] line = new byte[stride];
/*  76 */     long surfaceData = Cairo.cairo_image_surface_get_data(surface);
/*  77 */     if (hasAlpha) {
/*  78 */       for (int y = 0; y < height; y++) {
/*  79 */         C.memmove(line, surfaceData + y * stride, stride);
/*  80 */         int x = 0; for (int offset = 0; x < width; offset += 4) {
/*  81 */           int a = line[(offset + oa)] & 0xFF;
/*  82 */           int r = line[(offset + or)] & 0xFF;
/*  83 */           int g = line[(offset + og)] & 0xFF;
/*  84 */           int b = line[(offset + ob)] & 0xFF;
/*  85 */           line[(offset + 3)] = ((byte)a);
/*  86 */           if (a != 0) {
/*  87 */             line[(offset + 0)] = ((byte)((r * 255 + a / 2) / a));
/*  88 */             line[(offset + 1)] = ((byte)((g * 255 + a / 2) / a));
/*  89 */             line[(offset + 2)] = ((byte)((b * 255 + a / 2) / a));
/*     */           }
/*  80 */           x++;
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  92 */         C.memmove(pixels + y * stride, line, stride);
/*     */       }
/*     */     } else {
/*  95 */       int cairoStride = Cairo.cairo_image_surface_get_stride(surface);
/*  96 */       byte[] cairoLine = new byte[cairoStride];
/*  97 */       for (int y = 0; y < height; y++) {
/*  98 */         C.memmove(cairoLine, surfaceData + y * cairoStride, cairoStride);
/*  99 */         int x = 0;int offset = 0; for (int cairoOffset = 0; x < width; cairoOffset += 4) {
/* 100 */           byte r = cairoLine[(cairoOffset + or)];
/* 101 */           byte g = cairoLine[(cairoOffset + og)];
/* 102 */           byte b = cairoLine[(cairoOffset + ob)];
/* 103 */           line[(offset + 0)] = r;
/* 104 */           line[(offset + 1)] = g;
/* 105 */           line[(offset + 2)] = b;x++;offset += 3;
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 107 */         C.memmove(pixels + y * stride, line, stride);
/*     */       }
/*     */     }
/* 110 */     Cairo.cairo_surface_destroy(surface);
/* 111 */     return pixbuf;
/*     */   }
/*     */   
/*     */   public int add(Image image) {
/* 115 */     int index = 0;
/* 116 */     while (index < this.images.length) {
/* 117 */       if ((this.images[index] != null) && 
/* 118 */         (this.images[index].isDisposed())) {
/* 119 */         OS.g_object_unref(this.pixbufs[index]);
/* 120 */         this.images[index] = null;
/* 121 */         this.pixbufs[index] = 0L;
/*     */       }
/*     */       
/* 124 */       if (this.images[index] == null) break;
/* 125 */       index++;
/*     */     }
/* 127 */     if (index == this.images.length) {
/* 128 */       Image[] newImages = new Image[this.images.length + 4];
/* 129 */       System.arraycopy(this.images, 0, newImages, 0, this.images.length);
/* 130 */       this.images = newImages;
/* 131 */       long[] newPixbufs = new long[this.pixbufs.length + 4];
/* 132 */       System.arraycopy(this.pixbufs, 0, newPixbufs, 0, this.pixbufs.length);
/* 133 */       this.pixbufs = newPixbufs;
/*     */     }
/* 135 */     set(index, image);
/* 136 */     return index;
/*     */   }
/*     */   
/*     */   public void dispose() {
/* 140 */     if (this.pixbufs == null) return;
/* 141 */     for (int index = 0; index < this.pixbufs.length; index++) {
/* 142 */       if (this.pixbufs[index] != 0L) OS.g_object_unref(this.pixbufs[index]);
/*     */     }
/* 144 */     this.images = null;
/* 145 */     this.pixbufs = null;
/*     */   }
/*     */   
/*     */   public Image get(int index) {
/* 149 */     return this.images[index];
/*     */   }
/*     */   
/*     */   public long getPixbuf(int index) {
/* 153 */     return this.pixbufs[index];
/*     */   }
/*     */   
/*     */   public int indexOf(Image image) {
/* 157 */     if (image == null) return -1;
/* 158 */     for (int index = 0; index < this.images.length; index++) {
/* 159 */       if (image == this.images[index]) return index;
/*     */     }
/* 161 */     return -1;
/*     */   }
/*     */   
/*     */   public int indexOf(long pixbuf) {
/* 165 */     if (pixbuf == 0L) return -1;
/* 166 */     for (int index = 0; index < this.images.length; index++) {
/* 167 */       if (pixbuf == this.pixbufs[index]) return index;
/*     */     }
/* 169 */     return -1;
/*     */   }
/*     */   
/*     */   public boolean isDisposed() {
/* 173 */     return this.images == null;
/*     */   }
/*     */   
/*     */   public void put(int index, Image image) {
/* 177 */     int count = this.images.length;
/* 178 */     if ((0 > index) || (index >= count)) return;
/* 179 */     if (image != null) {
/* 180 */       set(index, image);
/*     */     } else {
/* 182 */       this.images[index] = null;
/* 183 */       if (this.pixbufs[index] != 0L) OS.g_object_unref(this.pixbufs[index]);
/* 184 */       this.pixbufs[index] = 0L;
/*     */     }
/*     */   }
/*     */   
/*     */   public void remove(Image image) {
/* 189 */     if (image == null) return;
/* 190 */     for (int index = 0; index < this.images.length; index++) {
/* 191 */       if (image == this.images[index]) {
/* 192 */         OS.g_object_unref(this.pixbufs[index]);
/* 193 */         this.images[index] = null;
/* 194 */         this.pixbufs[index] = 0L;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   void set(int index, Image image) {
/* 200 */     long pixbuf = createPixbuf(image);
/* 201 */     int w = GDK.gdk_pixbuf_get_width(pixbuf);
/* 202 */     int h = GDK.gdk_pixbuf_get_height(pixbuf);
/* 203 */     if ((this.width == -1) || (this.height == -1)) {
/* 204 */       this.width = w;
/* 205 */       this.height = h;
/*     */     }
/* 207 */     if ((w != this.width) || (h != this.height)) {
/* 208 */       long scaledPixbuf = GDK.gdk_pixbuf_scale_simple(pixbuf, this.width, this.height, 2);
/* 209 */       OS.g_object_unref(pixbuf);
/* 210 */       pixbuf = scaledPixbuf;
/*     */     }
/* 212 */     long oldPixbuf = this.pixbufs[index];
/* 213 */     if (oldPixbuf != 0L) {
/* 214 */       if (this.images[index] == image) {
/* 215 */         GDK.gdk_pixbuf_copy_area(pixbuf, 0, 0, this.width, this.height, oldPixbuf, 0, 0);
/* 216 */         OS.g_object_unref(pixbuf);
/* 217 */         pixbuf = oldPixbuf;
/*     */       } else {
/* 219 */         OS.g_object_unref(oldPixbuf);
/*     */       }
/*     */     }
/* 222 */     this.pixbufs[index] = pixbuf;
/* 223 */     this.images[index] = image;
/*     */   }
/*     */   
/*     */   public int size() {
/* 227 */     int result = 0;
/* 228 */     for (int index = 0; index < this.images.length; index++) {
/* 229 */       if (this.images[index] != null) {
/* 230 */         if (this.images[index].isDisposed()) {
/* 231 */           OS.g_object_unref(this.pixbufs[index]);
/* 232 */           this.images[index] = null;
/* 233 */           this.pixbufs[index] = 0L;
/*     */         }
/* 235 */         if (this.images[index] != null) result++;
/*     */       }
/*     */     }
/* 238 */     return result;
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/internal/ImageList.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */