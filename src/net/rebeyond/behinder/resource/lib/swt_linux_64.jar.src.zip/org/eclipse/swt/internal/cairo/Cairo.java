/*      */ package org.eclipse.swt.internal.cairo;
/*      */ 
/*      */ import org.eclipse.swt.internal.Library;
/*      */ import org.eclipse.swt.internal.Lock;
/*      */ import org.eclipse.swt.internal.Platform;
/*      */ import org.eclipse.swt.internal.gtk.GdkColor;
/*      */ 
/*      */ public class Cairo extends Platform
/*      */ {
/*      */   public static final int CAIRO_ANTIALIAS_DEFAULT = 0;
/*      */   public static final int CAIRO_ANTIALIAS_NONE = 1;
/*      */   public static final int CAIRO_ANTIALIAS_GRAY = 2;
/*      */   public static final int CAIRO_ANTIALIAS_SUBPIXEL = 3;
/*      */   public static final int CAIRO_ANTIALIAS_BEST = 6;
/*      */   public static final int CAIRO_CONTENT_COLOR = 4096;
/*      */   public static final int CAIRO_CONTENT_ALPHA = 8192;
/*      */   public static final int CAIRO_CONTENT_COLOR_ALPHA = 12288;
/*      */   public static final int CAIRO_FORMAT_ARGB32 = 0;
/*      */   public static final int CAIRO_FORMAT_RGB24 = 1;
/*      */   public static final int CAIRO_FORMAT_A8 = 2;
/*      */   public static final int CAIRO_FORMAT_A1 = 3;
/*      */   public static final int CAIRO_OPERATOR_SOURCE = 1;
/*      */   public static final int CAIRO_OPERATOR_OVER = 2;
/*      */   public static final int CAIRO_OPERATOR_DIFFERENCE = 23;
/*      */   
/*      */   static
/*      */   {
/*   28 */     Library.loadLibrary("swt-cairo");
/*      */   }
/*      */   
/*      */ 
/*      */   public static final int CAIRO_FILL_RULE_WINDING = 0;
/*      */   
/*      */   public static final int CAIRO_FILL_RULE_EVEN_ODD = 1;
/*      */   
/*      */   public static final int CAIRO_LINE_CAP_BUTT = 0;
/*      */   
/*      */   public static final int CAIRO_LINE_CAP_ROUND = 1;
/*      */   
/*      */   public static final int CAIRO_LINE_CAP_SQUARE = 2;
/*      */   
/*      */   public static final int CAIRO_LINE_JOIN_MITER = 0;
/*      */   
/*      */   public static final int CAIRO_LINE_JOIN_ROUND = 1;
/*      */   
/*      */   public static final int CAIRO_LINE_JOIN_BEVEL = 2;
/*      */   
/*      */   public static final int CAIRO_FONT_SLANT_NORMAL = 0;
/*      */   
/*      */   public static final int CAIRO_FONT_SLANT_ITALIC = 1;
/*      */   
/*      */   public static final int CAIRO_FONT_SLANT_OBLIQUE = 2;
/*      */   
/*      */   public static final int CAIRO_FONT_WEIGHT_NORMAL = 0;
/*      */   
/*      */   public static final int CAIRO_FONT_WEIGHT_BOLD = 1;
/*      */   
/*      */   public static final int CAIRO_STATUS_SUCCESS = 0;
/*      */   
/*      */   public static final int CAIRO_STATUS_NO_MEMORY = 1;
/*      */   
/*      */   public static final int CAIRO_STATUS_INVALID_RESTORE = 2;
/*      */   
/*      */   public static final int CAIRO_STATUS_INVALID_POP_GROUP = 3;
/*      */   
/*      */   public static final int CAIRO_STATUS_NO_CURRENT_POINT = 4;
/*      */   
/*      */   public static final int CAIRO_STATUS_INVALID_MATRIX = 5;
/*      */   
/*      */   public static final int CAIRO_STATUS_NO_TARGET_SURFACE = 6;
/*      */   
/*      */   public static final int CAIRO_STATUS_NULL_POINTER = 7;
/*      */   
/*      */   public static final int CAIRO_SURFACE_TYPE_IMAGE = 0;
/*      */   
/*      */   public static final int CAIRO_SURFACE_TYPE_PDF = 1;
/*      */   
/*      */   public static final int CAIRO_SURFACE_TYPE_PS = 2;
/*      */   
/*      */   public static final int CAIRO_SURFACE_TYPE_XLIB = 3;
/*      */   
/*      */   public static final int CAIRO_SURFACE_TYPE_XCB = 4;
/*      */   
/*      */   public static final int CAIRO_SURFACE_TYPE_GLITZ = 5;
/*      */   public static final int CAIRO_SURFACE_TYPE_QUARTZ = 6;
/*      */   public static final int CAIRO_SURFACE_TYPE_WIN32 = 7;
/*      */   public static final int CAIRO_SURFACE_TYPE_BEOS = 8;
/*      */   public static final int CAIRO_SURFACE_TYPE_DIRECTFB = 9;
/*      */   public static final int CAIRO_SURFACE_TYPE_SVG = 10;
/*      */   public static final int CAIRO_FILTER_FAST = 0;
/*      */   public static final int CAIRO_FILTER_GOOD = 1;
/*      */   public static final int CAIRO_FILTER_BEST = 2;
/*      */   public static final int CAIRO_FILTER_NEAREST = 3;
/*      */   public static final int CAIRO_FILTER_BILINEAR = 4;
/*      */   public static final int CAIRO_FILTER_GAUSSIAN = 5;
/*      */   public static final int CAIRO_EXTEND_NONE = 0;
/*      */   public static final int CAIRO_EXTEND_REPEAT = 1;
/*      */   public static final int CAIRO_EXTEND_REFLECT = 2;
/*      */   public static final int CAIRO_EXTEND_PAD = 3;
/*      */   public static final int CAIRO_PATH_MOVE_TO = 0;
/*      */   public static final int CAIRO_PATH_LINE_TO = 1;
/*      */   public static final int CAIRO_PATH_CURVE_TO = 2;
/*      */   public static final int CAIRO_PATH_CLOSE_PATH = 3;
/*      */   public static final void cairo_append_path(long cr, long path)
/*      */   {
/*  106 */     lock.lock();
/*      */     try {
/*  108 */       _cairo_append_path(cr, path);
/*      */     } finally {
/*  110 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final void cairo_arc(long cr, double xc, double yc, double radius, double angle1, double angle2)
/*      */   {
/*  116 */     lock.lock();
/*      */     try {
/*  118 */       _cairo_arc(cr, xc, yc, radius, angle1, angle2);
/*      */     } finally {
/*  120 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final void cairo_arc_negative(long cr, double xc, double yc, double radius, double angle1, double angle2)
/*      */   {
/*  126 */     lock.lock();
/*      */     try {
/*  128 */       _cairo_arc_negative(cr, xc, yc, radius, angle1, angle2);
/*      */     } finally {
/*  130 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long cairo_copy_path(long cr)
/*      */   {
/*  166 */     lock.lock();
/*      */     try {
/*  168 */       return _cairo_copy_path(cr);
/*      */     } finally {
/*  170 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final long cairo_copy_path_flat(long cr)
/*      */   {
/*  176 */     lock.lock();
/*      */     try {
/*  178 */       return _cairo_copy_path_flat(cr);
/*      */     } finally {
/*  180 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final long cairo_create(long target)
/*      */   {
/*  186 */     lock.lock();
/*      */     try {
/*  188 */       return _cairo_create(target);
/*      */     } finally {
/*  190 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final void cairo_curve_to(long cr, double x1, double y1, double x2, double y2, double x3, double y3)
/*      */   {
/*  196 */     lock.lock();
/*      */     try {
/*  198 */       _cairo_curve_to(cr, x1, y1, x2, y2, x3, y3);
/*      */     } finally {
/*  200 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long cairo_font_options_create()
/*      */   {
/*  225 */     lock.lock();
/*      */     try {
/*  227 */       return _cairo_font_options_create();
/*      */     } finally {
/*  229 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int cairo_font_options_get_antialias(long options)
/*      */   {
/*  245 */     lock.lock();
/*      */     try {
/*  247 */       return _cairo_font_options_get_antialias(options);
/*      */     } finally {
/*  249 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int cairo_get_antialias(long cr)
/*      */   {
/*  265 */     lock.lock();
/*      */     try {
/*  267 */       return _cairo_get_antialias(cr);
/*      */     } finally {
/*  269 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final void cairo_get_current_point(long cr, double[] x, double[] y)
/*      */   {
/*  275 */     lock.lock();
/*      */     try {
/*  277 */       _cairo_get_current_point(cr, x, y);
/*      */     } finally {
/*  279 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final int cairo_get_fill_rule(long cr)
/*      */   {
/*  285 */     lock.lock();
/*      */     try {
/*  287 */       return _cairo_get_fill_rule(cr);
/*      */     } finally {
/*  289 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final long cairo_get_font_face(long cr)
/*      */   {
/*  295 */     lock.lock();
/*      */     try {
/*  297 */       return _cairo_get_font_face(cr);
/*      */     } finally {
/*  299 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int cairo_get_operator(long cr)
/*      */   {
/*  318 */     lock.lock();
/*      */     try {
/*  320 */       return _cairo_get_operator(cr);
/*      */     } finally {
/*  322 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final long cairo_get_source(long cr)
/*      */   {
/*  328 */     lock.lock();
/*      */     try {
/*  330 */       return _cairo_get_source(cr);
/*      */     } finally {
/*  332 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final long cairo_get_target(long cr)
/*      */   {
/*  338 */     lock.lock();
/*      */     try {
/*  340 */       return _cairo_get_target(cr);
/*      */     } finally {
/*  342 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final double cairo_get_tolerance(long cr)
/*      */   {
/*  348 */     lock.lock();
/*      */     try {
/*  350 */       return _cairo_get_tolerance(cr);
/*      */     } finally {
/*  352 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long cairo_image_surface_create(int format, int width, int height)
/*      */   {
/*  367 */     lock.lock();
/*      */     try {
/*  369 */       return _cairo_image_surface_create(format, width, height);
/*      */     } finally {
/*  371 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final long cairo_image_surface_get_data(long surface)
/*      */   {
/*  379 */     lock.lock();
/*      */     try {
/*  381 */       return _cairo_image_surface_get_data(surface);
/*      */     } finally {
/*  383 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final int cairo_image_surface_get_format(long surface)
/*      */   {
/*  391 */     lock.lock();
/*      */     try {
/*  393 */       return _cairo_image_surface_get_format(surface);
/*      */     } finally {
/*  395 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final int cairo_image_surface_get_height(long surface)
/*      */   {
/*  401 */     lock.lock();
/*      */     try {
/*  403 */       return _cairo_image_surface_get_height(surface);
/*      */     } finally {
/*  405 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final int cairo_image_surface_get_width(long surface)
/*      */   {
/*  411 */     lock.lock();
/*      */     try {
/*  413 */       return _cairo_image_surface_get_width(surface);
/*      */     } finally {
/*  415 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final int cairo_image_surface_get_stride(long surface)
/*      */   {
/*  423 */     lock.lock();
/*      */     try {
/*  425 */       return _cairo_image_surface_get_stride(surface);
/*      */     } finally {
/*  427 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final int cairo_in_fill(long cr, double x, double y)
/*      */   {
/*  433 */     lock.lock();
/*      */     try {
/*  435 */       return _cairo_in_fill(cr, x, y);
/*      */     } finally {
/*  437 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final int cairo_in_stroke(long cr, double x, double y)
/*      */   {
/*  443 */     lock.lock();
/*      */     try {
/*  445 */       return _cairo_in_stroke(cr, x, y);
/*      */     } finally {
/*  447 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final void cairo_line_to(long cr, double x, double y)
/*      */   {
/*  453 */     lock.lock();
/*      */     try {
/*  455 */       _cairo_line_to(cr, x, y);
/*      */     } finally {
/*  457 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void cairo_mask(long cr, long pattern)
/*      */   {
/*  466 */     lock.lock();
/*      */     try {
/*  468 */       _cairo_mask(cr, pattern);
/*      */     } finally {
/*  470 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void cairo_mask_surface(long cr, long surface, double surface_x, double surface_y)
/*      */   {
/*  479 */     lock.lock();
/*      */     try {
/*  481 */       _cairo_mask_surface(cr, surface, surface_x, surface_y);
/*      */     } finally {
/*  483 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final void cairo_matrix_init(double[] matrix, double xx, double yx, double xy, double yy, double x0, double y0)
/*      */   {
/*  489 */     lock.lock();
/*      */     try {
/*  491 */       _cairo_matrix_init(matrix, xx, yx, xy, yy, x0, y0);
/*      */     } finally {
/*  493 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void cairo_matrix_init_scale(double[] matrix, double sx, double sy)
/*      */   {
/*  519 */     lock.lock();
/*      */     try {
/*  521 */       _cairo_matrix_init_scale(matrix, sx, sy);
/*      */     } finally {
/*  523 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final int cairo_matrix_invert(double[] matrix)
/*      */   {
/*  529 */     lock.lock();
/*      */     try {
/*  531 */       return _cairo_matrix_invert(matrix);
/*      */     } finally {
/*  533 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void cairo_matrix_scale(double[] matrix, double sx, double sy)
/*      */   {
/*  563 */     lock.lock();
/*      */     try {
/*  565 */       _cairo_matrix_scale(matrix, sx, sy);
/*      */     } finally {
/*  567 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void cairo_matrix_translate(double[] matrix, double tx, double ty)
/*      */   {
/*  593 */     lock.lock();
/*      */     try {
/*  595 */       _cairo_matrix_translate(matrix, tx, ty);
/*      */     } finally {
/*  597 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final void cairo_move_to(long cr, double x, double y)
/*      */   {
/*  603 */     lock.lock();
/*      */     try {
/*  605 */       _cairo_move_to(cr, x, y);
/*      */     } finally {
/*  607 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void cairo_paint_with_alpha(long cr, double alpha)
/*      */   {
/*  633 */     lock.lock();
/*      */     try {
/*  635 */       _cairo_paint_with_alpha(cr, alpha);
/*      */     } finally {
/*  637 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void cairo_pattern_add_color_stop_rgba(long pattern, double offset, double red, double green, double blue, double alpha)
/*      */   {
/*  653 */     lock.lock();
/*      */     try {
/*  655 */       _cairo_pattern_add_color_stop_rgba(pattern, offset, red, green, blue, alpha);
/*      */     } finally {
/*  657 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final long cairo_pattern_create_for_surface(long surface)
/*      */   {
/*  663 */     lock.lock();
/*      */     try {
/*  665 */       return _cairo_pattern_create_for_surface(surface);
/*      */     } finally {
/*  667 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final long cairo_pattern_create_linear(double x0, double y0, double x1, double y1) {
/*  672 */     lock.lock();
/*      */     try {
/*  674 */       return _cairo_pattern_create_linear(x0, y0, x1, y1);
/*      */     } finally {
/*  676 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int cairo_pattern_get_extend(long pattern)
/*      */   {
/*  692 */     lock.lock();
/*      */     try {
/*  694 */       return _cairo_pattern_get_extend(pattern);
/*      */     } finally {
/*  696 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void cairo_pdf_surface_set_size(long surface, double width_in_points, double height_in_points)
/*      */   {
/*  738 */     lock.lock();
/*      */     try {
/*  740 */       _cairo_pdf_surface_set_size(surface, width_in_points, height_in_points);
/*      */     } finally {
/*  742 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void cairo_ps_surface_set_size(long surface, double width_in_points, double height_in_points)
/*      */   {
/*  775 */     lock.lock();
/*      */     try {
/*  777 */       _cairo_ps_surface_set_size(surface, width_in_points, height_in_points);
/*      */     } finally {
/*  779 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final void cairo_rectangle(long cr, double x, double y, double width, double height)
/*      */   {
/*  785 */     lock.lock();
/*      */     try {
/*  787 */       _cairo_rectangle(cr, x, y, width, height);
/*      */     } finally {
/*  789 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final long cairo_reference(long cr)
/*      */   {
/*  795 */     lock.lock();
/*      */     try {
/*  797 */       return _cairo_reference(cr);
/*      */     } finally {
/*  799 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void cairo_rotate(long cr, double angle)
/*      */   {
/*  825 */     lock.lock();
/*      */     try {
/*  827 */       _cairo_rotate(cr, angle);
/*      */     } finally {
/*  829 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void cairo_scale(long cr, double sx, double sy)
/*      */   {
/*  845 */     lock.lock();
/*      */     try {
/*  847 */       _cairo_scale(cr, sx, sy);
/*      */     } finally {
/*  849 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void cairo_surface_set_device_scale(long cr, double sx, double sy)
/*      */   {
/*  858 */     lock.lock();
/*      */     try {
/*  860 */       _cairo_surface_set_device_scale(cr, sx, sy);
/*      */     } finally {
/*  862 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void cairo_surface_get_device_scale(long cr, double[] sx, double[] sy)
/*      */   {
/*  873 */     lock.lock();
/*      */     try {
/*  875 */       _cairo_surface_get_device_scale(cr, sx, sy);
/*      */     } finally {
/*  877 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void cairo_select_font_face(long cr, byte[] family, int slant, int weight)
/*      */   {
/*  886 */     lock.lock();
/*      */     try {
/*  888 */       _cairo_select_font_face(cr, family, slant, weight);
/*      */     } finally {
/*  890 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void cairo_set_dash(long cr, double[] dashes, int ndash, double offset)
/*      */   {
/*  906 */     lock.lock();
/*      */     try {
/*  908 */       _cairo_set_dash(cr, dashes, ndash, offset);
/*      */     } finally {
/*  910 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void cairo_set_font_face(long cr, long font_face)
/*      */   {
/*  929 */     lock.lock();
/*      */     try {
/*  931 */       _cairo_set_font_face(cr, font_face);
/*      */     } finally {
/*  933 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final void cairo_set_font_size(long cr, double size)
/*      */   {
/*  939 */     lock.lock();
/*      */     try {
/*  941 */       _cairo_set_font_size(cr, size);
/*      */     } finally {
/*  943 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void cairo_set_line_width(long cr, double width)
/*      */   {
/*  969 */     lock.lock();
/*      */     try {
/*  971 */       _cairo_set_line_width(cr, width);
/*      */     } finally {
/*  973 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void cairo_set_miter_limit(long cr, double limit)
/*      */   {
/*  992 */     lock.lock();
/*      */     try {
/*  994 */       _cairo_set_miter_limit(cr, limit);
/*      */     } finally {
/*  996 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void cairo_set_source(long cr, long source)
/*      */   {
/* 1015 */     lock.lock();
/*      */     try {
/* 1017 */       _cairo_set_source(cr, source);
/*      */     } finally {
/* 1019 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final void cairo_set_source_rgb(long cr, double red, double green, double blue)
/*      */   {
/* 1025 */     lock.lock();
/*      */     try {
/* 1027 */       _cairo_set_source_rgb(cr, red, green, blue);
/*      */     } finally {
/* 1029 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void cairo_set_source_rgba_compatibility(long cairo, GdkColor color)
/*      */   {
/* 1038 */     double red = (color.red & 0xFFFF) / 65535.0F;
/* 1039 */     double green = (color.green & 0xFFFF) / 65535.0F;
/* 1040 */     double blue = (color.blue & 0xFFFF) / 65535.0F;
/* 1041 */     cairo_set_source_rgba(cairo, red, green, blue, 1.0D);
/*      */   }
/*      */   
/*      */   public static final void cairo_set_source_rgba(long cr, double red, double green, double blue, double alpha)
/*      */   {
/* 1046 */     lock.lock();
/*      */     try {
/* 1048 */       _cairo_set_source_rgba(cr, red, green, blue, alpha);
/*      */     } finally {
/* 1050 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void cairo_set_source_surface(long cr, long surface, double x, double y)
/*      */   {
/* 1059 */     lock.lock();
/*      */     try {
/* 1061 */       _cairo_set_source_surface(cr, surface, x, y);
/*      */     } finally {
/* 1063 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final void cairo_set_tolerance(long cr, double tolerance)
/*      */   {
/* 1069 */     lock.lock();
/*      */     try {
/* 1071 */       _cairo_set_tolerance(cr, tolerance);
/*      */     } finally {
/* 1073 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long cairo_surface_create_similar(long other, int format, int width, int height)
/*      */   {
/* 1099 */     lock.lock();
/*      */     try {
/* 1101 */       return _cairo_surface_create_similar(other, format, width, height);
/*      */     } finally {
/* 1103 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int cairo_surface_get_type(long surface)
/*      */   {
/* 1141 */     lock.lock();
/*      */     try {
/* 1143 */       return _cairo_surface_get_type(surface);
/*      */     } finally {
/* 1145 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final int cairo_surface_get_content(long surface)
/*      */   {
/* 1153 */     lock.lock();
/*      */     try {
/* 1155 */       return _cairo_surface_get_content(surface);
/*      */     } finally {
/* 1157 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long cairo_surface_get_user_data(long surface, long key)
/*      */   {
/* 1166 */     lock.lock();
/*      */     try {
/* 1168 */       return _cairo_surface_get_user_data(surface, key);
/*      */     } finally {
/* 1170 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void cairo_translate(long cr, double tx, double ty)
/*      */   {
/* 1209 */     lock.lock();
/*      */     try {
/* 1211 */       _cairo_translate(cr, tx, ty);
/*      */     } finally {
/* 1213 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final void cairo_user_to_device_distance(long cr, double[] dx, double[] dy)
/*      */   {
/* 1219 */     lock.lock();
/*      */     try {
/* 1221 */       _cairo_user_to_device_distance(cr, dx, dy);
/*      */     } finally {
/* 1223 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long cairo_xlib_surface_create(long dpy, long drawable, long visual, int width, int height)
/*      */   {
/* 1235 */     lock.lock();
/*      */     try {
/* 1237 */       return _cairo_xlib_surface_create(dpy, drawable, visual, width, height);
/*      */     } finally {
/* 1239 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int cairo_xlib_surface_get_height(long surface)
/*      */   {
/* 1248 */     lock.lock();
/*      */     try {
/* 1250 */       return _cairo_xlib_surface_get_height(surface);
/*      */     } finally {
/* 1252 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int cairo_xlib_surface_get_width(long surface)
/*      */   {
/* 1261 */     lock.lock();
/*      */     try {
/* 1263 */       return _cairo_xlib_surface_get_width(surface);
/*      */     } finally {
/* 1265 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final int cairo_region_num_rectangles(long region)
/*      */   {
/* 1271 */     lock.lock();
/*      */     try {
/* 1273 */       return _cairo_region_num_rectangles(region);
/*      */     } finally {
/* 1275 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final boolean cairo_region_contains_point(long region, int x, int y)
/*      */   {
/* 1281 */     lock.lock();
/*      */     try {
/* 1283 */       return _cairo_region_contains_point(region, x, y);
/*      */     } finally {
/* 1285 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final void cairo_region_get_rectangle(long region, int nth, long rectangle)
/*      */   {
/* 1291 */     lock.lock();
/*      */     try {
/* 1293 */       _cairo_region_get_rectangle(region, nth, rectangle);
/*      */     } finally {
/* 1295 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native int cairo_path_data_t_sizeof();
/*      */   
/*      */   public static final native int cairo_path_t_sizeof();
/*      */   
/*      */   public static final native int CAIRO_VERSION_ENCODE(int paramInt1, int paramInt2, int paramInt3);
/*      */   
/*      */   public static final native void _cairo_append_path(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final native void _cairo_arc(long paramLong, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5);
/*      */   
/*      */   public static final native void _cairo_arc_negative(long paramLong, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5);
/*      */   
/*      */   public static final native void _cairo_clip(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void cairo_clip(long cr)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 8	org/eclipse/swt/internal/cairo/Cairo:_cairo_clip	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #136	-> byte code offset #0
/*      */     //   Java source line #138	-> byte code offset #7
/*      */     //   Java source line #140	-> byte code offset #11
/*      */     //   Java source line #141	-> byte code offset #17
/*      */     //   Java source line #140	-> byte code offset #20
/*      */     //   Java source line #141	-> byte code offset #27
/*      */     //   Java source line #142	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	cr	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native void _cairo_close_path(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void cairo_close_path(long cr)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 9	org/eclipse/swt/internal/cairo/Cairo:_cairo_close_path	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #146	-> byte code offset #0
/*      */     //   Java source line #148	-> byte code offset #7
/*      */     //   Java source line #150	-> byte code offset #11
/*      */     //   Java source line #151	-> byte code offset #17
/*      */     //   Java source line #150	-> byte code offset #20
/*      */     //   Java source line #151	-> byte code offset #27
/*      */     //   Java source line #152	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	cr	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native void _cairo_copy_page(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void cairo_copy_page(long cr)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 10	org/eclipse/swt/internal/cairo/Cairo:_cairo_copy_page	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #156	-> byte code offset #0
/*      */     //   Java source line #158	-> byte code offset #7
/*      */     //   Java source line #160	-> byte code offset #11
/*      */     //   Java source line #161	-> byte code offset #17
/*      */     //   Java source line #160	-> byte code offset #20
/*      */     //   Java source line #161	-> byte code offset #27
/*      */     //   Java source line #162	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	cr	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native long _cairo_copy_path(long paramLong);
/*      */   
/*      */   public static final native long _cairo_copy_path_flat(long paramLong);
/*      */   
/*      */   public static final native long _cairo_create(long paramLong);
/*      */   
/*      */   public static final native void _cairo_curve_to(long paramLong, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6);
/*      */   
/*      */   public static final native void _cairo_destroy(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void cairo_destroy(long cr)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 15	org/eclipse/swt/internal/cairo/Cairo:_cairo_destroy	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #206	-> byte code offset #0
/*      */     //   Java source line #208	-> byte code offset #7
/*      */     //   Java source line #210	-> byte code offset #11
/*      */     //   Java source line #211	-> byte code offset #17
/*      */     //   Java source line #210	-> byte code offset #20
/*      */     //   Java source line #211	-> byte code offset #27
/*      */     //   Java source line #212	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	cr	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native void _cairo_fill(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void cairo_fill(long cr)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 16	org/eclipse/swt/internal/cairo/Cairo:_cairo_fill	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #216	-> byte code offset #0
/*      */     //   Java source line #218	-> byte code offset #7
/*      */     //   Java source line #220	-> byte code offset #11
/*      */     //   Java source line #221	-> byte code offset #17
/*      */     //   Java source line #220	-> byte code offset #20
/*      */     //   Java source line #221	-> byte code offset #27
/*      */     //   Java source line #222	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	cr	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native long _cairo_font_options_create();
/*      */   
/*      */   public static final native void _cairo_font_options_destroy(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void cairo_font_options_destroy(long options)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 18	org/eclipse/swt/internal/cairo/Cairo:_cairo_font_options_destroy	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #235	-> byte code offset #0
/*      */     //   Java source line #237	-> byte code offset #7
/*      */     //   Java source line #239	-> byte code offset #11
/*      */     //   Java source line #240	-> byte code offset #17
/*      */     //   Java source line #239	-> byte code offset #20
/*      */     //   Java source line #240	-> byte code offset #27
/*      */     //   Java source line #241	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	options	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native int _cairo_font_options_get_antialias(long paramLong);
/*      */   
/*      */   public static final native void _cairo_font_options_set_antialias(long paramLong, int paramInt);
/*      */   
/*      */   /* Error */
/*      */   public static final void cairo_font_options_set_antialias(long options, int antialias)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 20	org/eclipse/swt/internal/cairo/Cairo:_cairo_font_options_set_antialias	(JI)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #255	-> byte code offset #0
/*      */     //   Java source line #257	-> byte code offset #7
/*      */     //   Java source line #259	-> byte code offset #12
/*      */     //   Java source line #260	-> byte code offset #18
/*      */     //   Java source line #259	-> byte code offset #21
/*      */     //   Java source line #260	-> byte code offset #28
/*      */     //   Java source line #261	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	options	long
/*      */     //   0	31	2	antialias	int
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native int _cairo_get_antialias(long paramLong);
/*      */   
/*      */   public static final native void _cairo_get_current_point(long paramLong, double[] paramArrayOfDouble1, double[] paramArrayOfDouble2);
/*      */   
/*      */   public static final native int _cairo_get_fill_rule(long paramLong);
/*      */   
/*      */   public static final native long _cairo_get_font_face(long paramLong);
/*      */   
/*      */   public static final native void _cairo_get_matrix(long paramLong, double[] paramArrayOfDouble);
/*      */   
/*      */   /* Error */
/*      */   public static final void cairo_get_matrix(long cr, double[] matrix)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: aload_2
/*      */     //   9: invokestatic 25	org/eclipse/swt/internal/cairo/Cairo:_cairo_get_matrix	(J[D)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #308	-> byte code offset #0
/*      */     //   Java source line #310	-> byte code offset #7
/*      */     //   Java source line #312	-> byte code offset #12
/*      */     //   Java source line #313	-> byte code offset #18
/*      */     //   Java source line #312	-> byte code offset #21
/*      */     //   Java source line #313	-> byte code offset #28
/*      */     //   Java source line #314	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	cr	long
/*      */     //   0	31	2	matrix	double[]
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native int _cairo_get_operator(long paramLong);
/*      */   
/*      */   public static final native long _cairo_get_source(long paramLong);
/*      */   
/*      */   public static final native long _cairo_get_target(long paramLong);
/*      */   
/*      */   public static final native double _cairo_get_tolerance(long paramLong);
/*      */   
/*      */   public static final native void _cairo_identity_matrix(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void cairo_identity_matrix(long cr)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 30	org/eclipse/swt/internal/cairo/Cairo:_cairo_identity_matrix	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #358	-> byte code offset #0
/*      */     //   Java source line #360	-> byte code offset #7
/*      */     //   Java source line #362	-> byte code offset #11
/*      */     //   Java source line #363	-> byte code offset #17
/*      */     //   Java source line #362	-> byte code offset #20
/*      */     //   Java source line #363	-> byte code offset #27
/*      */     //   Java source line #364	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	cr	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native long _cairo_image_surface_create(int paramInt1, int paramInt2, int paramInt3);
/*      */   
/*      */   public static final native long _cairo_image_surface_get_data(long paramLong);
/*      */   
/*      */   public static final native int _cairo_image_surface_get_format(long paramLong);
/*      */   
/*      */   public static final native int _cairo_image_surface_get_height(long paramLong);
/*      */   
/*      */   public static final native int _cairo_image_surface_get_width(long paramLong);
/*      */   
/*      */   public static final native int _cairo_image_surface_get_stride(long paramLong);
/*      */   
/*      */   public static final native int _cairo_in_fill(long paramLong, double paramDouble1, double paramDouble2);
/*      */   
/*      */   public static final native int _cairo_in_stroke(long paramLong, double paramDouble1, double paramDouble2);
/*      */   
/*      */   public static final native void _cairo_line_to(long paramLong, double paramDouble1, double paramDouble2);
/*      */   
/*      */   public static final native void _cairo_mask(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final native void _cairo_mask_surface(long paramLong1, long paramLong2, double paramDouble1, double paramDouble2);
/*      */   
/*      */   public static final native void _cairo_matrix_init(double[] paramArrayOfDouble, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6);
/*      */   
/*      */   public static final native void _cairo_matrix_init_identity(double[] paramArrayOfDouble);
/*      */   
/*      */   /* Error */
/*      */   public static final void cairo_matrix_init_identity(double[] matrix)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: aload_0
/*      */     //   8: invokestatic 43	org/eclipse/swt/internal/cairo/Cairo:_cairo_matrix_init_identity	([D)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_1
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_1
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #499	-> byte code offset #0
/*      */     //   Java source line #501	-> byte code offset #7
/*      */     //   Java source line #503	-> byte code offset #11
/*      */     //   Java source line #504	-> byte code offset #17
/*      */     //   Java source line #503	-> byte code offset #20
/*      */     //   Java source line #504	-> byte code offset #27
/*      */     //   Java source line #505	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	matrix	double[]
/*      */     //   20	8	1	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native void _cairo_matrix_init_rotate(double[] paramArrayOfDouble, double paramDouble);
/*      */   
/*      */   /* Error */
/*      */   public static final void cairo_matrix_init_rotate(double[] matrix, double radians)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: aload_0
/*      */     //   8: dload_1
/*      */     //   9: invokestatic 44	org/eclipse/swt/internal/cairo/Cairo:_cairo_matrix_init_rotate	([DD)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #509	-> byte code offset #0
/*      */     //   Java source line #511	-> byte code offset #7
/*      */     //   Java source line #513	-> byte code offset #12
/*      */     //   Java source line #514	-> byte code offset #18
/*      */     //   Java source line #513	-> byte code offset #21
/*      */     //   Java source line #514	-> byte code offset #28
/*      */     //   Java source line #515	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	matrix	double[]
/*      */     //   0	31	1	radians	double
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _cairo_matrix_init_scale(double[] paramArrayOfDouble, double paramDouble1, double paramDouble2);
/*      */   
/*      */   public static final native int _cairo_matrix_invert(double[] paramArrayOfDouble);
/*      */   
/*      */   public static final native void _cairo_matrix_multiply(double[] paramArrayOfDouble1, double[] paramArrayOfDouble2, double[] paramArrayOfDouble3);
/*      */   
/*      */   /* Error */
/*      */   public static final void cairo_matrix_multiply(double[] result, double[] a, double[] b)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: aload_0
/*      */     //   8: aload_1
/*      */     //   9: aload_2
/*      */     //   10: invokestatic 47	org/eclipse/swt/internal/cairo/Cairo:_cairo_matrix_multiply	([D[D[D)V
/*      */     //   13: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   16: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   19: goto +12 -> 31
/*      */     //   22: astore_3
/*      */     //   23: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   26: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   29: aload_3
/*      */     //   30: athrow
/*      */     //   31: return
/*      */     // Line number table:
/*      */     //   Java source line #543	-> byte code offset #0
/*      */     //   Java source line #545	-> byte code offset #7
/*      */     //   Java source line #547	-> byte code offset #13
/*      */     //   Java source line #548	-> byte code offset #19
/*      */     //   Java source line #547	-> byte code offset #22
/*      */     //   Java source line #548	-> byte code offset #29
/*      */     //   Java source line #549	-> byte code offset #31
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	32	0	result	double[]
/*      */     //   0	32	1	a	double[]
/*      */     //   0	32	2	b	double[]
/*      */     //   22	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	13	22	finally
/*      */   }
/*      */   
/*      */   public static final native void _cairo_matrix_rotate(double[] paramArrayOfDouble, double paramDouble);
/*      */   
/*      */   /* Error */
/*      */   public static final void cairo_matrix_rotate(double[] matrix, double radians)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: aload_0
/*      */     //   8: dload_1
/*      */     //   9: invokestatic 48	org/eclipse/swt/internal/cairo/Cairo:_cairo_matrix_rotate	([DD)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #553	-> byte code offset #0
/*      */     //   Java source line #555	-> byte code offset #7
/*      */     //   Java source line #557	-> byte code offset #12
/*      */     //   Java source line #558	-> byte code offset #18
/*      */     //   Java source line #557	-> byte code offset #21
/*      */     //   Java source line #558	-> byte code offset #28
/*      */     //   Java source line #559	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	matrix	double[]
/*      */     //   0	31	1	radians	double
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _cairo_matrix_scale(double[] paramArrayOfDouble, double paramDouble1, double paramDouble2);
/*      */   
/*      */   public static final native void _cairo_matrix_transform_distance(double[] paramArrayOfDouble1, double[] paramArrayOfDouble2, double[] paramArrayOfDouble3);
/*      */   
/*      */   /* Error */
/*      */   public static final void cairo_matrix_transform_distance(double[] matrix, double[] dx, double[] dy)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: aload_0
/*      */     //   8: aload_1
/*      */     //   9: aload_2
/*      */     //   10: invokestatic 50	org/eclipse/swt/internal/cairo/Cairo:_cairo_matrix_transform_distance	([D[D[D)V
/*      */     //   13: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   16: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   19: goto +12 -> 31
/*      */     //   22: astore_3
/*      */     //   23: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   26: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   29: aload_3
/*      */     //   30: athrow
/*      */     //   31: return
/*      */     // Line number table:
/*      */     //   Java source line #573	-> byte code offset #0
/*      */     //   Java source line #575	-> byte code offset #7
/*      */     //   Java source line #577	-> byte code offset #13
/*      */     //   Java source line #578	-> byte code offset #19
/*      */     //   Java source line #577	-> byte code offset #22
/*      */     //   Java source line #578	-> byte code offset #29
/*      */     //   Java source line #579	-> byte code offset #31
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	32	0	matrix	double[]
/*      */     //   0	32	1	dx	double[]
/*      */     //   0	32	2	dy	double[]
/*      */     //   22	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	13	22	finally
/*      */   }
/*      */   
/*      */   public static final native void _cairo_matrix_transform_point(double[] paramArrayOfDouble1, double[] paramArrayOfDouble2, double[] paramArrayOfDouble3);
/*      */   
/*      */   /* Error */
/*      */   public static final void cairo_matrix_transform_point(double[] matrix, double[] x, double[] y)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: aload_0
/*      */     //   8: aload_1
/*      */     //   9: aload_2
/*      */     //   10: invokestatic 51	org/eclipse/swt/internal/cairo/Cairo:_cairo_matrix_transform_point	([D[D[D)V
/*      */     //   13: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   16: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   19: goto +12 -> 31
/*      */     //   22: astore_3
/*      */     //   23: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   26: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   29: aload_3
/*      */     //   30: athrow
/*      */     //   31: return
/*      */     // Line number table:
/*      */     //   Java source line #583	-> byte code offset #0
/*      */     //   Java source line #585	-> byte code offset #7
/*      */     //   Java source line #587	-> byte code offset #13
/*      */     //   Java source line #588	-> byte code offset #19
/*      */     //   Java source line #587	-> byte code offset #22
/*      */     //   Java source line #588	-> byte code offset #29
/*      */     //   Java source line #589	-> byte code offset #31
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	32	0	matrix	double[]
/*      */     //   0	32	1	x	double[]
/*      */     //   0	32	2	y	double[]
/*      */     //   22	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	13	22	finally
/*      */   }
/*      */   
/*      */   public static final native void _cairo_matrix_translate(double[] paramArrayOfDouble, double paramDouble1, double paramDouble2);
/*      */   
/*      */   public static final native void _cairo_move_to(long paramLong, double paramDouble1, double paramDouble2);
/*      */   
/*      */   public static final native void _cairo_new_path(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void cairo_new_path(long cr)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 54	org/eclipse/swt/internal/cairo/Cairo:_cairo_new_path	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #613	-> byte code offset #0
/*      */     //   Java source line #615	-> byte code offset #7
/*      */     //   Java source line #617	-> byte code offset #11
/*      */     //   Java source line #618	-> byte code offset #17
/*      */     //   Java source line #617	-> byte code offset #20
/*      */     //   Java source line #618	-> byte code offset #27
/*      */     //   Java source line #619	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	cr	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native void _cairo_paint(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void cairo_paint(long cr)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 55	org/eclipse/swt/internal/cairo/Cairo:_cairo_paint	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #623	-> byte code offset #0
/*      */     //   Java source line #625	-> byte code offset #7
/*      */     //   Java source line #627	-> byte code offset #11
/*      */     //   Java source line #628	-> byte code offset #17
/*      */     //   Java source line #627	-> byte code offset #20
/*      */     //   Java source line #628	-> byte code offset #27
/*      */     //   Java source line #629	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	cr	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native void _cairo_paint_with_alpha(long paramLong, double paramDouble);
/*      */   
/*      */   public static final native void _cairo_path_destroy(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void cairo_path_destroy(long path)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 57	org/eclipse/swt/internal/cairo/Cairo:_cairo_path_destroy	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #643	-> byte code offset #0
/*      */     //   Java source line #645	-> byte code offset #7
/*      */     //   Java source line #647	-> byte code offset #11
/*      */     //   Java source line #648	-> byte code offset #17
/*      */     //   Java source line #647	-> byte code offset #20
/*      */     //   Java source line #648	-> byte code offset #27
/*      */     //   Java source line #649	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	path	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native void _cairo_pattern_add_color_stop_rgba(long paramLong, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5);
/*      */   
/*      */   public static final native long _cairo_pattern_create_for_surface(long paramLong);
/*      */   
/*      */   public static final native long _cairo_pattern_create_linear(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4);
/*      */   
/*      */   public static final native void _cairo_pattern_destroy(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void cairo_pattern_destroy(long pattern)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 61	org/eclipse/swt/internal/cairo/Cairo:_cairo_pattern_destroy	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #682	-> byte code offset #0
/*      */     //   Java source line #684	-> byte code offset #7
/*      */     //   Java source line #686	-> byte code offset #11
/*      */     //   Java source line #687	-> byte code offset #17
/*      */     //   Java source line #686	-> byte code offset #20
/*      */     //   Java source line #687	-> byte code offset #27
/*      */     //   Java source line #688	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	pattern	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native int _cairo_pattern_get_extend(long paramLong);
/*      */   
/*      */   public static final native void _cairo_pattern_set_extend(long paramLong, int paramInt);
/*      */   
/*      */   /* Error */
/*      */   public static final void cairo_pattern_set_extend(long pattern, int extend)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 63	org/eclipse/swt/internal/cairo/Cairo:_cairo_pattern_set_extend	(JI)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #702	-> byte code offset #0
/*      */     //   Java source line #704	-> byte code offset #7
/*      */     //   Java source line #706	-> byte code offset #12
/*      */     //   Java source line #707	-> byte code offset #18
/*      */     //   Java source line #706	-> byte code offset #21
/*      */     //   Java source line #707	-> byte code offset #28
/*      */     //   Java source line #708	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	pattern	long
/*      */     //   0	31	2	extend	int
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _cairo_pattern_set_filter(long paramLong, int paramInt);
/*      */   
/*      */   /* Error */
/*      */   public static final void cairo_pattern_set_filter(long pattern, int filter)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 64	org/eclipse/swt/internal/cairo/Cairo:_cairo_pattern_set_filter	(JI)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #712	-> byte code offset #0
/*      */     //   Java source line #714	-> byte code offset #7
/*      */     //   Java source line #716	-> byte code offset #12
/*      */     //   Java source line #717	-> byte code offset #18
/*      */     //   Java source line #716	-> byte code offset #21
/*      */     //   Java source line #717	-> byte code offset #28
/*      */     //   Java source line #718	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	pattern	long
/*      */     //   0	31	2	filter	int
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _cairo_pattern_set_matrix(long paramLong, double[] paramArrayOfDouble);
/*      */   
/*      */   /* Error */
/*      */   public static final void cairo_pattern_set_matrix(long pattern, double[] matrix)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: aload_2
/*      */     //   9: invokestatic 65	org/eclipse/swt/internal/cairo/Cairo:_cairo_pattern_set_matrix	(J[D)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #725	-> byte code offset #0
/*      */     //   Java source line #727	-> byte code offset #7
/*      */     //   Java source line #729	-> byte code offset #12
/*      */     //   Java source line #730	-> byte code offset #18
/*      */     //   Java source line #729	-> byte code offset #21
/*      */     //   Java source line #730	-> byte code offset #28
/*      */     //   Java source line #731	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	pattern	long
/*      */     //   0	31	2	matrix	double[]
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _cairo_pdf_surface_set_size(long paramLong, double paramDouble1, double paramDouble2);
/*      */   
/*      */   public static final native void _cairo_push_group(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void cairo_push_group(long cairo)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 67	org/eclipse/swt/internal/cairo/Cairo:_cairo_push_group	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #750	-> byte code offset #0
/*      */     //   Java source line #752	-> byte code offset #7
/*      */     //   Java source line #754	-> byte code offset #11
/*      */     //   Java source line #755	-> byte code offset #17
/*      */     //   Java source line #754	-> byte code offset #20
/*      */     //   Java source line #755	-> byte code offset #27
/*      */     //   Java source line #756	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	cairo	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native void _cairo_pop_group_to_source(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void cairo_pop_group_to_source(long cairo)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 68	org/eclipse/swt/internal/cairo/Cairo:_cairo_pop_group_to_source	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #762	-> byte code offset #0
/*      */     //   Java source line #764	-> byte code offset #7
/*      */     //   Java source line #766	-> byte code offset #11
/*      */     //   Java source line #767	-> byte code offset #17
/*      */     //   Java source line #766	-> byte code offset #20
/*      */     //   Java source line #767	-> byte code offset #27
/*      */     //   Java source line #768	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	cairo	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native void _cairo_ps_surface_set_size(long paramLong, double paramDouble1, double paramDouble2);
/*      */   
/*      */   public static final native void _cairo_rectangle(long paramLong, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4);
/*      */   
/*      */   public static final native long _cairo_reference(long paramLong);
/*      */   
/*      */   public static final native void _cairo_reset_clip(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void cairo_reset_clip(long cr)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 72	org/eclipse/swt/internal/cairo/Cairo:_cairo_reset_clip	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #805	-> byte code offset #0
/*      */     //   Java source line #807	-> byte code offset #7
/*      */     //   Java source line #809	-> byte code offset #11
/*      */     //   Java source line #810	-> byte code offset #17
/*      */     //   Java source line #809	-> byte code offset #20
/*      */     //   Java source line #810	-> byte code offset #27
/*      */     //   Java source line #811	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	cr	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native void _cairo_restore(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void cairo_restore(long cr)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 73	org/eclipse/swt/internal/cairo/Cairo:_cairo_restore	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #815	-> byte code offset #0
/*      */     //   Java source line #817	-> byte code offset #7
/*      */     //   Java source line #819	-> byte code offset #11
/*      */     //   Java source line #820	-> byte code offset #17
/*      */     //   Java source line #819	-> byte code offset #20
/*      */     //   Java source line #820	-> byte code offset #27
/*      */     //   Java source line #821	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	cr	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native void _cairo_rotate(long paramLong, double paramDouble);
/*      */   
/*      */   public static final native void _cairo_save(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void cairo_save(long cr)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 75	org/eclipse/swt/internal/cairo/Cairo:_cairo_save	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #835	-> byte code offset #0
/*      */     //   Java source line #837	-> byte code offset #7
/*      */     //   Java source line #839	-> byte code offset #11
/*      */     //   Java source line #840	-> byte code offset #17
/*      */     //   Java source line #839	-> byte code offset #20
/*      */     //   Java source line #840	-> byte code offset #27
/*      */     //   Java source line #841	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	cr	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native void _cairo_scale(long paramLong, double paramDouble1, double paramDouble2);
/*      */   
/*      */   public static final native void _cairo_surface_set_device_scale(long paramLong, double paramDouble1, double paramDouble2);
/*      */   
/*      */   public static final native void _cairo_surface_get_device_scale(long paramLong, double[] paramArrayOfDouble1, double[] paramArrayOfDouble2);
/*      */   
/*      */   public static final native void _cairo_select_font_face(long paramLong, byte[] paramArrayOfByte, int paramInt1, int paramInt2);
/*      */   
/*      */   public static final native void _cairo_set_antialias(long paramLong, int paramInt);
/*      */   
/*      */   /* Error */
/*      */   public static final void cairo_set_antialias(long cr, int antialias)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 80	org/eclipse/swt/internal/cairo/Cairo:_cairo_set_antialias	(JI)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #896	-> byte code offset #0
/*      */     //   Java source line #898	-> byte code offset #7
/*      */     //   Java source line #900	-> byte code offset #12
/*      */     //   Java source line #901	-> byte code offset #18
/*      */     //   Java source line #900	-> byte code offset #21
/*      */     //   Java source line #901	-> byte code offset #28
/*      */     //   Java source line #902	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	cr	long
/*      */     //   0	31	2	antialias	int
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _cairo_set_dash(long paramLong, double[] paramArrayOfDouble, int paramInt, double paramDouble);
/*      */   
/*      */   public static final native void _cairo_set_fill_rule(long paramLong, int paramInt);
/*      */   
/*      */   /* Error */
/*      */   public static final void cairo_set_fill_rule(long cr, int fill_rule)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 82	org/eclipse/swt/internal/cairo/Cairo:_cairo_set_fill_rule	(JI)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #916	-> byte code offset #0
/*      */     //   Java source line #918	-> byte code offset #7
/*      */     //   Java source line #920	-> byte code offset #12
/*      */     //   Java source line #921	-> byte code offset #18
/*      */     //   Java source line #920	-> byte code offset #21
/*      */     //   Java source line #921	-> byte code offset #28
/*      */     //   Java source line #922	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	cr	long
/*      */     //   0	31	2	fill_rule	int
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _cairo_set_font_face(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final native void _cairo_set_font_size(long paramLong, double paramDouble);
/*      */   
/*      */   public static final native void _cairo_set_line_cap(long paramLong, int paramInt);
/*      */   
/*      */   /* Error */
/*      */   public static final void cairo_set_line_cap(long cr, int line_cap)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 85	org/eclipse/swt/internal/cairo/Cairo:_cairo_set_line_cap	(JI)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #949	-> byte code offset #0
/*      */     //   Java source line #951	-> byte code offset #7
/*      */     //   Java source line #953	-> byte code offset #12
/*      */     //   Java source line #954	-> byte code offset #18
/*      */     //   Java source line #953	-> byte code offset #21
/*      */     //   Java source line #954	-> byte code offset #28
/*      */     //   Java source line #955	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	cr	long
/*      */     //   0	31	2	line_cap	int
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _cairo_set_line_join(long paramLong, int paramInt);
/*      */   
/*      */   /* Error */
/*      */   public static final void cairo_set_line_join(long cr, int line_join)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 86	org/eclipse/swt/internal/cairo/Cairo:_cairo_set_line_join	(JI)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #959	-> byte code offset #0
/*      */     //   Java source line #961	-> byte code offset #7
/*      */     //   Java source line #963	-> byte code offset #12
/*      */     //   Java source line #964	-> byte code offset #18
/*      */     //   Java source line #963	-> byte code offset #21
/*      */     //   Java source line #964	-> byte code offset #28
/*      */     //   Java source line #965	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	cr	long
/*      */     //   0	31	2	line_join	int
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _cairo_set_line_width(long paramLong, double paramDouble);
/*      */   
/*      */   public static final native void _cairo_set_matrix(long paramLong, double[] paramArrayOfDouble);
/*      */   
/*      */   /* Error */
/*      */   public static final void cairo_set_matrix(long cr, double[] matrix)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: aload_2
/*      */     //   9: invokestatic 88	org/eclipse/swt/internal/cairo/Cairo:_cairo_set_matrix	(J[D)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #982	-> byte code offset #0
/*      */     //   Java source line #984	-> byte code offset #7
/*      */     //   Java source line #986	-> byte code offset #12
/*      */     //   Java source line #987	-> byte code offset #18
/*      */     //   Java source line #986	-> byte code offset #21
/*      */     //   Java source line #987	-> byte code offset #28
/*      */     //   Java source line #988	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	cr	long
/*      */     //   0	31	2	matrix	double[]
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _cairo_set_miter_limit(long paramLong, double paramDouble);
/*      */   
/*      */   public static final native void _cairo_set_operator(long paramLong, int paramInt);
/*      */   
/*      */   /* Error */
/*      */   public static final void cairo_set_operator(long cr, int op)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 90	org/eclipse/swt/internal/cairo/Cairo:_cairo_set_operator	(JI)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #1002	-> byte code offset #0
/*      */     //   Java source line #1004	-> byte code offset #7
/*      */     //   Java source line #1006	-> byte code offset #12
/*      */     //   Java source line #1007	-> byte code offset #18
/*      */     //   Java source line #1006	-> byte code offset #21
/*      */     //   Java source line #1007	-> byte code offset #28
/*      */     //   Java source line #1008	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	cr	long
/*      */     //   0	31	2	op	int
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _cairo_set_source(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final native void _cairo_set_source_rgb(long paramLong, double paramDouble1, double paramDouble2, double paramDouble3);
/*      */   
/*      */   public static final native void _cairo_set_source_rgba(long paramLong, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4);
/*      */   
/*      */   public static final native void _cairo_set_source_surface(long paramLong1, long paramLong2, double paramDouble1, double paramDouble2);
/*      */   
/*      */   public static final native void _cairo_set_tolerance(long paramLong, double paramDouble);
/*      */   
/*      */   public static final native void _cairo_show_page(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void cairo_show_page(long cr)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 102	org/eclipse/swt/internal/cairo/Cairo:_cairo_show_page	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #1079	-> byte code offset #0
/*      */     //   Java source line #1081	-> byte code offset #7
/*      */     //   Java source line #1083	-> byte code offset #11
/*      */     //   Java source line #1084	-> byte code offset #17
/*      */     //   Java source line #1083	-> byte code offset #20
/*      */     //   Java source line #1084	-> byte code offset #27
/*      */     //   Java source line #1085	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	cr	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native void _cairo_stroke(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void cairo_stroke(long cr)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 103	org/eclipse/swt/internal/cairo/Cairo:_cairo_stroke	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #1089	-> byte code offset #0
/*      */     //   Java source line #1091	-> byte code offset #7
/*      */     //   Java source line #1093	-> byte code offset #11
/*      */     //   Java source line #1094	-> byte code offset #17
/*      */     //   Java source line #1093	-> byte code offset #20
/*      */     //   Java source line #1094	-> byte code offset #27
/*      */     //   Java source line #1095	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	cr	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native long _cairo_surface_create_similar(long paramLong, int paramInt1, int paramInt2, int paramInt3);
/*      */   
/*      */   public static final native void _cairo_surface_destroy(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void cairo_surface_destroy(long surface)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 105	org/eclipse/swt/internal/cairo/Cairo:_cairo_surface_destroy	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #1109	-> byte code offset #0
/*      */     //   Java source line #1111	-> byte code offset #7
/*      */     //   Java source line #1113	-> byte code offset #11
/*      */     //   Java source line #1114	-> byte code offset #17
/*      */     //   Java source line #1113	-> byte code offset #20
/*      */     //   Java source line #1114	-> byte code offset #27
/*      */     //   Java source line #1115	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	surface	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native void _cairo_surface_flush(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void cairo_surface_flush(long surface)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 106	org/eclipse/swt/internal/cairo/Cairo:_cairo_surface_flush	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #1119	-> byte code offset #0
/*      */     //   Java source line #1121	-> byte code offset #7
/*      */     //   Java source line #1123	-> byte code offset #11
/*      */     //   Java source line #1124	-> byte code offset #17
/*      */     //   Java source line #1123	-> byte code offset #20
/*      */     //   Java source line #1124	-> byte code offset #27
/*      */     //   Java source line #1125	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	surface	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native void _cairo_surface_finish(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void cairo_surface_finish(long surface)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 107	org/eclipse/swt/internal/cairo/Cairo:_cairo_surface_finish	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #1129	-> byte code offset #0
/*      */     //   Java source line #1131	-> byte code offset #7
/*      */     //   Java source line #1133	-> byte code offset #11
/*      */     //   Java source line #1134	-> byte code offset #17
/*      */     //   Java source line #1133	-> byte code offset #20
/*      */     //   Java source line #1134	-> byte code offset #27
/*      */     //   Java source line #1135	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	surface	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native int _cairo_surface_get_type(long paramLong);
/*      */   
/*      */   public static final native int _cairo_surface_get_content(long paramLong);
/*      */   
/*      */   public static final native long _cairo_surface_get_user_data(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final native void _cairo_surface_mark_dirty(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void cairo_surface_mark_dirty(long surface)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 111	org/eclipse/swt/internal/cairo/Cairo:_cairo_surface_mark_dirty	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #1176	-> byte code offset #0
/*      */     //   Java source line #1178	-> byte code offset #7
/*      */     //   Java source line #1180	-> byte code offset #11
/*      */     //   Java source line #1181	-> byte code offset #17
/*      */     //   Java source line #1180	-> byte code offset #20
/*      */     //   Java source line #1181	-> byte code offset #27
/*      */     //   Java source line #1182	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	surface	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native void _cairo_surface_reference(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void cairo_surface_reference(long surface)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 112	org/eclipse/swt/internal/cairo/Cairo:_cairo_surface_reference	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #1186	-> byte code offset #0
/*      */     //   Java source line #1188	-> byte code offset #7
/*      */     //   Java source line #1190	-> byte code offset #11
/*      */     //   Java source line #1191	-> byte code offset #17
/*      */     //   Java source line #1190	-> byte code offset #20
/*      */     //   Java source line #1191	-> byte code offset #27
/*      */     //   Java source line #1192	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	surface	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native void _cairo_transform(long paramLong, double[] paramArrayOfDouble);
/*      */   
/*      */   /* Error */
/*      */   public static final void cairo_transform(long cr, double[] matrix)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: aload_2
/*      */     //   9: invokestatic 113	org/eclipse/swt/internal/cairo/Cairo:_cairo_transform	(J[D)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/cairo/Cairo:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #1199	-> byte code offset #0
/*      */     //   Java source line #1201	-> byte code offset #7
/*      */     //   Java source line #1203	-> byte code offset #12
/*      */     //   Java source line #1204	-> byte code offset #18
/*      */     //   Java source line #1203	-> byte code offset #21
/*      */     //   Java source line #1204	-> byte code offset #28
/*      */     //   Java source line #1205	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	cr	long
/*      */     //   0	31	2	matrix	double[]
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _cairo_translate(long paramLong, double paramDouble1, double paramDouble2);
/*      */   
/*      */   public static final native void _cairo_user_to_device_distance(long paramLong, double[] paramArrayOfDouble1, double[] paramArrayOfDouble2);
/*      */   
/*      */   public static final native int cairo_version();
/*      */   
/*      */   public static final native long cairo_version_string();
/*      */   
/*      */   public static final native long _cairo_xlib_surface_create(long paramLong1, long paramLong2, long paramLong3, int paramInt1, int paramInt2);
/*      */   
/*      */   public static final native int _cairo_xlib_surface_get_height(long paramLong);
/*      */   
/*      */   public static final native int _cairo_xlib_surface_get_width(long paramLong);
/*      */   
/*      */   public static final native int _cairo_region_num_rectangles(long paramLong);
/*      */   
/*      */   public static final native boolean _cairo_region_contains_point(long paramLong, int paramInt1, int paramInt2);
/*      */   
/*      */   public static final native void _cairo_region_get_rectangle(long paramLong1, int paramInt, long paramLong2);
/*      */   
/*      */   public static final native void memmove(cairo_path_t paramcairo_path_t, long paramLong1, long paramLong2);
/*      */   
/*      */   public static final native void memmove(cairo_path_data_t paramcairo_path_data_t, long paramLong1, long paramLong2);
/*      */   
/*      */   public static final native void memmove(double[] paramArrayOfDouble, long paramLong1, long paramLong2);
/*      */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/internal/cairo/Cairo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */