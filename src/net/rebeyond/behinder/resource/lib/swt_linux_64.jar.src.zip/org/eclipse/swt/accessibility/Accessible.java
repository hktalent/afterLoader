/*      */ package org.eclipse.swt.accessibility;
/*      */ 
/*      */ import java.util.ArrayList;
/*      */ import java.util.List;
/*      */ import org.eclipse.swt.SWT;
/*      */ import org.eclipse.swt.internal.gtk.GTK;
/*      */ import org.eclipse.swt.internal.gtk.OS;
/*      */ import org.eclipse.swt.widgets.Control;
/*      */ import org.eclipse.swt.widgets.Display;
/*      */ import org.eclipse.swt.widgets.Label;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class Accessible
/*      */ {
/*      */   List<AccessibleListener> accessibleListeners;
/*      */   List<AccessibleControlListener> accessibleControlListeners;
/*      */   List<AccessibleTextListener> accessibleTextListeners;
/*      */   List<AccessibleActionListener> accessibleActionListeners;
/*      */   List<AccessibleEditableTextListener> accessibleEditableTextListeners;
/*      */   List<AccessibleHyperlinkListener> accessibleHyperlinkListeners;
/*      */   List<AccessibleTableListener> accessibleTableListeners;
/*      */   List<AccessibleTableCellListener> accessibleTableCellListeners;
/*      */   List<AccessibleTextExtendedListener> accessibleTextExtendedListeners;
/*      */   List<AccessibleValueListener> accessibleValueListeners;
/*      */   List<AccessibleAttributeListener> accessibleAttributeListeners;
/*      */   Accessible parent;
/*      */   AccessibleObject accessibleObject;
/*      */   Control control;
/*      */   List<Relation> relations;
/*      */   List<Accessible> children;
/*      */   
/*      */   static class Relation
/*      */   {
/*      */     int type;
/*      */     Accessible target;
/*      */     
/*      */     public Relation(int type, Accessible target)
/*      */     {
/*   67 */       this.type = type;
/*   68 */       this.target = target;
/*      */     }
/*      */     
/*      */     public boolean equals(Object object)
/*      */     {
/*   73 */       if (object == this) return true;
/*   74 */       if (!(object instanceof Relation)) return false;
/*   75 */       Relation relation = (Relation)object;
/*   76 */       return (relation.type == this.type) && (relation.target == this.target);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Accessible(Accessible parent)
/*      */   {
/*   95 */     this.parent = checkNull(parent);
/*   96 */     this.control = parent.control;
/*   97 */     if (parent.children == null) parent.children = new ArrayList();
/*   98 */     parent.children.add(this);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   protected Accessible() {}
/*      */   
/*      */ 
/*      */ 
/*      */   static Accessible checkNull(Accessible parent)
/*      */   {
/*  110 */     if (parent == null) SWT.error(4);
/*  111 */     return parent;
/*      */   }
/*      */   
/*      */   Accessible(Control control)
/*      */   {
/*  116 */     this.control = control;
/*  117 */     if (GTK.GTK3) {
/*  118 */       long type = OS.G_OBJECT_TYPE(getControlHandle());
/*  119 */       this.accessibleObject = new AccessibleObject(type, getControlHandle(), this, false);
/*  120 */       addRelations();
/*      */     } else {
/*  122 */       AccessibleFactory.registerAccessible(this);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addAccessibleListener(AccessibleListener listener)
/*      */   {
/*  148 */     checkWidget();
/*  149 */     if (listener == null) SWT.error(4);
/*  150 */     if (this.accessibleListeners == null) this.accessibleListeners = new ArrayList();
/*  151 */     this.accessibleListeners.add(listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addAccessibleControlListener(AccessibleControlListener listener)
/*      */   {
/*  176 */     checkWidget();
/*  177 */     if (listener == null) SWT.error(4);
/*  178 */     if (this.accessibleControlListeners == null) this.accessibleControlListeners = new ArrayList();
/*  179 */     this.accessibleControlListeners.add(listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addAccessibleTextListener(AccessibleTextListener listener)
/*      */   {
/*  207 */     checkWidget();
/*  208 */     if (listener == null) SWT.error(4);
/*  209 */     if ((listener instanceof AccessibleTextExtendedListener)) {
/*  210 */       if (this.accessibleTextExtendedListeners == null) this.accessibleTextExtendedListeners = new ArrayList();
/*  211 */       this.accessibleTextExtendedListeners.add((AccessibleTextExtendedListener)listener);
/*      */     } else {
/*  213 */       if (this.accessibleTextListeners == null) this.accessibleTextListeners = new ArrayList();
/*  214 */       this.accessibleTextListeners.add(listener);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addAccessibleActionListener(AccessibleActionListener listener)
/*      */   {
/*  240 */     checkWidget();
/*  241 */     if (listener == null) SWT.error(4);
/*  242 */     if (this.accessibleActionListeners == null) this.accessibleActionListeners = new ArrayList();
/*  243 */     this.accessibleActionListeners.add(listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addAccessibleEditableTextListener(AccessibleEditableTextListener listener)
/*      */   {
/*  268 */     checkWidget();
/*  269 */     if (listener == null) SWT.error(4);
/*  270 */     if (this.accessibleEditableTextListeners == null) this.accessibleEditableTextListeners = new ArrayList();
/*  271 */     this.accessibleEditableTextListeners.add(listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addAccessibleHyperlinkListener(AccessibleHyperlinkListener listener)
/*      */   {
/*  296 */     checkWidget();
/*  297 */     if (listener == null) SWT.error(4);
/*  298 */     if (this.accessibleHyperlinkListeners == null) this.accessibleHyperlinkListeners = new ArrayList();
/*  299 */     this.accessibleHyperlinkListeners.add(listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addAccessibleTableListener(AccessibleTableListener listener)
/*      */   {
/*  324 */     checkWidget();
/*  325 */     if (listener == null) SWT.error(4);
/*  326 */     if (this.accessibleTableListeners == null) this.accessibleTableListeners = new ArrayList();
/*  327 */     this.accessibleTableListeners.add(listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addAccessibleTableCellListener(AccessibleTableCellListener listener)
/*      */   {
/*  352 */     checkWidget();
/*  353 */     if (listener == null) SWT.error(4);
/*  354 */     if (this.accessibleTableCellListeners == null) this.accessibleTableCellListeners = new ArrayList();
/*  355 */     this.accessibleTableCellListeners.add(listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addAccessibleValueListener(AccessibleValueListener listener)
/*      */   {
/*  380 */     checkWidget();
/*  381 */     if (listener == null) SWT.error(4);
/*  382 */     if (this.accessibleValueListeners == null) this.accessibleValueListeners = new ArrayList();
/*  383 */     this.accessibleValueListeners.add(listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addAccessibleAttributeListener(AccessibleAttributeListener listener)
/*      */   {
/*  408 */     checkWidget();
/*  409 */     if (listener == null) SWT.error(4);
/*  410 */     if (this.accessibleAttributeListeners == null) this.accessibleAttributeListeners = new ArrayList();
/*  411 */     this.accessibleAttributeListeners.add(listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addRelation(int type, Accessible target)
/*      */   {
/*  424 */     checkWidget();
/*  425 */     if (target == null) SWT.error(4);
/*  426 */     if (this.relations == null) this.relations = new ArrayList();
/*  427 */     Relation relation = new Relation(type, target);
/*  428 */     if (this.relations.indexOf(relation) != -1) return;
/*  429 */     this.relations.add(relation);
/*  430 */     if (this.accessibleObject != null) this.accessibleObject.addRelation(type, target);
/*      */   }
/*      */   
/*      */   void addRelations() {
/*  434 */     if (this.relations == null) return;
/*  435 */     if (this.accessibleObject == null) return;
/*  436 */     for (int i = 0; i < this.relations.size(); i++) {
/*  437 */       Relation relation = (Relation)this.relations.get(i);
/*  438 */       this.accessibleObject.addRelation(relation.type, relation.target);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void dispose()
/*      */   {
/*  459 */     if (this.parent == null) return;
/*  460 */     release();
/*  461 */     this.parent.children.remove(this);
/*  462 */     this.parent = null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Control getControl()
/*      */   {
/*  472 */     return this.control;
/*      */   }
/*      */   
/*      */   void checkWidget()
/*      */   {
/*  477 */     if (!isValidThread()) SWT.error(22);
/*  478 */     if (this.control.isDisposed()) SWT.error(24);
/*      */   }
/*      */   
/*      */   AccessibleObject getAccessibleObject() {
/*  482 */     if (this.accessibleObject == null) {
/*  483 */       if (GTK.GTK3) {
/*  484 */         long widget = getControlHandle();
/*  485 */         long type = OS.G_OBJECT_TYPE(widget);
/*  486 */         if (this.parent == null) {
/*  487 */           this.accessibleObject = new AccessibleObject(type, widget, this, false);
/*      */         } else {
/*  489 */           this.accessibleObject = new AccessibleObject(type, 0L, this, true);
/*  490 */           this.accessibleObject.parent = this.parent.getAccessibleObject();
/*      */         }
/*      */       }
/*  493 */       else if (this.parent == null) {
/*  494 */         AccessibleFactory.createAccessible(this);
/*      */       } else {
/*  496 */         this.accessibleObject = AccessibleFactory.createChildAccessible(this, -1);
/*  497 */         this.accessibleObject.parent = this.parent.getAccessibleObject();
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  502 */     return this.accessibleObject;
/*      */   }
/*      */   
/*      */   long getControlHandle() {
/*  506 */     long result = this.control.handle;
/*  507 */     if ((this.control instanceof Label)) {
/*  508 */       long list = GTK.gtk_container_get_children(result);
/*  509 */       if (list != 0L) {
/*  510 */         long temp = list;
/*  511 */         while (temp != 0L) {
/*  512 */           long widget = OS.g_list_data(temp);
/*  513 */           if (GTK.gtk_widget_get_visible(widget)) {
/*  514 */             result = widget;
/*  515 */             break;
/*      */           }
/*  517 */           temp = OS.g_list_next(temp);
/*      */         }
/*  519 */         OS.g_list_free(list);
/*      */       }
/*      */     }
/*  522 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void internal_dispose_Accessible()
/*      */   {
/*  538 */     if (!GTK.GTK3) AccessibleFactory.unregisterAccessible(this);
/*  539 */     release();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Accessible internal_new_Accessible(Control control)
/*      */   {
/*  558 */     return new Accessible(control);
/*      */   }
/*      */   
/*      */   boolean isValidThread()
/*      */   {
/*  563 */     return this.control.getDisplay().getThread() == Thread.currentThread();
/*      */   }
/*      */   
/*      */   void release() {
/*  567 */     if (this.children != null) {
/*  568 */       for (int i = 0; i < this.children.size(); i++) {
/*  569 */         Accessible child = (Accessible)this.children.get(i);
/*  570 */         child.dispose();
/*      */       }
/*      */     }
/*  573 */     if (this.accessibleObject != null) {
/*  574 */       this.accessibleObject.release();
/*  575 */       this.accessibleObject = null;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeAccessibleControlListener(AccessibleControlListener listener)
/*      */   {
/*  599 */     checkWidget();
/*  600 */     if (listener == null) SWT.error(4);
/*  601 */     if (this.accessibleControlListeners != null) {
/*  602 */       this.accessibleControlListeners.remove(listener);
/*  603 */       if (this.accessibleControlListeners.isEmpty()) { this.accessibleControlListeners = null;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeAccessibleListener(AccessibleListener listener)
/*      */   {
/*  627 */     checkWidget();
/*  628 */     if (listener == null) SWT.error(4);
/*  629 */     if (this.accessibleListeners != null) {
/*  630 */       this.accessibleListeners.remove(listener);
/*  631 */       if (this.accessibleListeners.isEmpty()) { this.accessibleListeners = null;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeAccessibleTextListener(AccessibleTextListener listener)
/*      */   {
/*  658 */     checkWidget();
/*  659 */     if (listener == null) SWT.error(4);
/*  660 */     if ((listener instanceof AccessibleTextExtendedListener)) {
/*  661 */       if (this.accessibleTextExtendedListeners != null) {
/*  662 */         this.accessibleTextExtendedListeners.remove(listener);
/*  663 */         if (this.accessibleTextExtendedListeners.isEmpty()) this.accessibleTextExtendedListeners = null;
/*      */       }
/*      */     }
/*  666 */     else if (this.accessibleTextListeners != null) {
/*  667 */       this.accessibleTextListeners.remove(listener);
/*  668 */       if (this.accessibleTextListeners.isEmpty()) { this.accessibleTextListeners = null;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeAccessibleActionListener(AccessibleActionListener listener)
/*      */   {
/*  695 */     checkWidget();
/*  696 */     if (listener == null) SWT.error(4);
/*  697 */     if (this.accessibleActionListeners != null) {
/*  698 */       this.accessibleActionListeners.remove(listener);
/*  699 */       if (this.accessibleActionListeners.isEmpty()) { this.accessibleActionListeners = null;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeAccessibleEditableTextListener(AccessibleEditableTextListener listener)
/*      */   {
/*  725 */     checkWidget();
/*  726 */     if (listener == null) SWT.error(4);
/*  727 */     if (this.accessibleEditableTextListeners != null) {
/*  728 */       this.accessibleEditableTextListeners.remove(listener);
/*  729 */       if (this.accessibleEditableTextListeners.isEmpty()) { this.accessibleEditableTextListeners = null;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeAccessibleHyperlinkListener(AccessibleHyperlinkListener listener)
/*      */   {
/*  755 */     checkWidget();
/*  756 */     if (listener == null) SWT.error(4);
/*  757 */     if (this.accessibleHyperlinkListeners != null) {
/*  758 */       this.accessibleHyperlinkListeners.remove(listener);
/*  759 */       if (this.accessibleHyperlinkListeners.isEmpty()) { this.accessibleHyperlinkListeners = null;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeAccessibleTableListener(AccessibleTableListener listener)
/*      */   {
/*  785 */     checkWidget();
/*  786 */     if (listener == null) SWT.error(4);
/*  787 */     if (this.accessibleTableListeners != null) {
/*  788 */       this.accessibleTableListeners.remove(listener);
/*  789 */       if (this.accessibleTableListeners.isEmpty()) { this.accessibleTableListeners = null;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeAccessibleTableCellListener(AccessibleTableCellListener listener)
/*      */   {
/*  815 */     checkWidget();
/*  816 */     if (listener == null) SWT.error(4);
/*  817 */     if (this.accessibleTableCellListeners != null) {
/*  818 */       this.accessibleTableCellListeners.remove(listener);
/*  819 */       if (this.accessibleTableCellListeners.isEmpty()) { this.accessibleTableCellListeners = null;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeAccessibleValueListener(AccessibleValueListener listener)
/*      */   {
/*  845 */     checkWidget();
/*  846 */     if (listener == null) SWT.error(4);
/*  847 */     if (this.accessibleValueListeners != null) {
/*  848 */       this.accessibleValueListeners.remove(listener);
/*  849 */       if (this.accessibleValueListeners.isEmpty()) { this.accessibleValueListeners = null;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeAccessibleAttributeListener(AccessibleAttributeListener listener)
/*      */   {
/*  875 */     checkWidget();
/*  876 */     if (listener == null) SWT.error(4);
/*  877 */     if (this.accessibleAttributeListeners != null) {
/*  878 */       this.accessibleAttributeListeners.remove(listener);
/*  879 */       if (this.accessibleAttributeListeners.isEmpty()) { this.accessibleAttributeListeners = null;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeRelation(int type, Accessible target)
/*      */   {
/*  893 */     checkWidget();
/*  894 */     if (this.relations == null) return;
/*  895 */     if (target == null) SWT.error(4);
/*  896 */     Relation relation = new Relation(type, target);
/*  897 */     int index = this.relations.indexOf(relation);
/*  898 */     if (index == -1) return;
/*  899 */     this.relations.remove(index);
/*  900 */     if (this.accessibleObject != null) { this.accessibleObject.removeRelation(type, target);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void sendEvent(int event, Object eventData)
/*      */   {
/*  952 */     checkWidget();
/*  953 */     if (this.accessibleObject != null) {
/*  954 */       this.accessibleObject.sendEvent(event, eventData);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void sendEvent(int event, Object eventData, int childID)
/*      */   {
/*  987 */     checkWidget();
/*  988 */     if (this.accessibleObject != null) {
/*  989 */       switch (event) {
/*      */       case 32777: 
/*      */       case 32778: 
/*      */       case 32779: 
/*      */       case 32780: 
/*      */       case 32781: 
/*      */       case 32782: 
/*      */       case 32788: 
/*  997 */         this.accessibleObject.sendEvent(event, eventData, childID);
/*      */       }
/*      */       
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void selectionChanged()
/*      */   {
/* 1014 */     checkWidget();
/* 1015 */     if (this.accessibleObject != null) {
/* 1016 */       this.accessibleObject.selectionChanged();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setFocus(int childID)
/*      */   {
/* 1032 */     checkWidget();
/* 1033 */     if (this.accessibleObject != null) {
/* 1034 */       this.accessibleObject.setFocus(childID);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void textCaretMoved(int index)
/*      */   {
/* 1052 */     checkWidget();
/* 1053 */     if (this.accessibleObject != null) {
/* 1054 */       this.accessibleObject.textCaretMoved(index);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void textChanged(int type, int startIndex, int length)
/*      */   {
/* 1078 */     checkWidget();
/* 1079 */     if (this.accessibleObject != null) {
/* 1080 */       this.accessibleObject.textChanged(type, startIndex, length);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void textSelectionChanged()
/*      */   {
/* 1096 */     checkWidget();
/* 1097 */     if (this.accessibleObject != null) {
/* 1098 */       this.accessibleObject.textSelectionChanged();
/*      */     }
/*      */   }
/*      */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/accessibility/Accessible.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */