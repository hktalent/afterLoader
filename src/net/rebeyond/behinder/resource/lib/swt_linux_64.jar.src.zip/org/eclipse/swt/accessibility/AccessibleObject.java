/*      */ package org.eclipse.swt.accessibility;
/*      */ 
/*      */ import java.util.List;
/*      */ import org.eclipse.swt.graphics.Color;
/*      */ import org.eclipse.swt.graphics.Font;
/*      */ import org.eclipse.swt.graphics.TextStyle;
/*      */ import org.eclipse.swt.internal.C;
/*      */ import org.eclipse.swt.internal.accessibility.gtk.ATK;
/*      */ import org.eclipse.swt.internal.accessibility.gtk.AtkActionIface;
/*      */ import org.eclipse.swt.internal.accessibility.gtk.AtkAttribute;
/*      */ import org.eclipse.swt.internal.accessibility.gtk.AtkComponentIface;
/*      */ import org.eclipse.swt.internal.accessibility.gtk.AtkEditableTextIface;
/*      */ import org.eclipse.swt.internal.accessibility.gtk.AtkHypertextIface;
/*      */ import org.eclipse.swt.internal.accessibility.gtk.AtkObjectClass;
/*      */ import org.eclipse.swt.internal.accessibility.gtk.AtkTableIface;
/*      */ import org.eclipse.swt.internal.accessibility.gtk.AtkTextIface;
/*      */ import org.eclipse.swt.internal.accessibility.gtk.AtkTextRange;
/*      */ import org.eclipse.swt.internal.accessibility.gtk.AtkTextRectangle;
/*      */ import org.eclipse.swt.internal.accessibility.gtk.AtkValueIface;
/*      */ import org.eclipse.swt.internal.gtk.GTK;
/*      */ import org.eclipse.swt.internal.gtk.OS;
/*      */ 
/*      */ class AccessibleObject
/*      */ {
/*   25 */   int index = -1; int id = -1;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*   33 */   boolean isLightweight = false;
/*      */   
/*   35 */   static long actionNamePtr = -1L;
/*   36 */   static long descriptionPtr = -1L;
/*   37 */   static long keybindingPtr = -1L;
/*   38 */   static long namePtr = -1L;
/*   39 */   static final java.util.Map<org.eclipse.swt.internal.LONG, AccessibleObject> AccessibleObjects = new java.util.HashMap(9);
/*   40 */   static final boolean DEBUG = org.eclipse.swt.graphics.Device.DEBUG;
/*      */   long atkHandle;
/*      */   Accessible accessible;
/*      */   AccessibleObject parent;
/*      */   AccessibleObject[] children;
/*      */   static final int ROW_ROLE;
/*      */   
/*   47 */   static { if (GTK.GTK_VERSION >= OS.VERSION(3, 2, 0)) {
/*   48 */       ROW_ROLE = 88;
/*      */     } else {
/*   50 */       ROW_ROLE = ATK.atk_role_register(org.eclipse.swt.internal.Converter.wcsToMbcs("row", true));
/*      */     }
/*      */   }
/*      */   
/*      */   AccessibleObject(long type, long widget, Accessible accessible, boolean isLightweight)
/*      */   {
/*   56 */     if (GTK.GTK3) {
/*   57 */       if (type == OS.swt_fixed_get_type()) {
/*   58 */         if ((widget != 0L) && (!isLightweight)) {
/*   59 */           this.atkHandle = GTK.gtk_widget_get_accessible(widget);
/*      */         }
/*      */         else
/*      */         {
/*   63 */           this.atkHandle = OS.g_object_new(OS.swt_fixed_accessible_get_type(), 0L);
/*      */         }
/*   65 */         OS.swt_fixed_accessible_register_accessible(this.atkHandle, false, widget);
/*      */       }
/*      */       else
/*      */       {
/*   69 */         this.atkHandle = GTK.gtk_widget_get_accessible(widget);
/*      */       }
/*      */     } else {
/*   72 */       this.atkHandle = OS.g_object_new(type, 0L);
/*   73 */       ATK.atk_object_initialize(this.atkHandle, widget);
/*      */     }
/*   75 */     this.accessible = accessible;
/*   76 */     this.isLightweight = isLightweight;
/*   77 */     AccessibleObjects.put(new org.eclipse.swt.internal.LONG(this.atkHandle), this);
/*      */   }
/*      */   
/*      */   static void print(String str) {
/*   81 */     System.out.println(str);
/*      */   }
/*      */   
/*      */   static int size(java.util.Collection<?> listeners) {
/*   85 */     return listeners == null ? 0 : listeners.size();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static AtkActionIface getParentActionIface(long atkObject)
/*      */   {
/*   99 */     long type = GTK.GTK3 ? OS.swt_fixed_accessible_get_type() : OS.G_OBJECT_TYPE(atkObject);
/*  100 */     if (OS.g_type_is_a(OS.g_type_parent(type), ATK.ATK_TYPE_ACTION())) {
/*  101 */       AtkActionIface iface = new AtkActionIface();
/*  102 */       ATK.memmove(iface, OS.g_type_interface_peek_parent(ATK.ATK_ACTION_GET_IFACE(atkObject)));
/*  103 */       return iface;
/*      */     }
/*  105 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static long atkAction_do_action(long atkObject, long index)
/*      */   {
/*  123 */     AccessibleObject object = getAccessibleObject(atkObject);
/*  124 */     if (object != null) {
/*  125 */       Accessible accessible = object.accessible;
/*  126 */       List<AccessibleActionListener> listeners = accessible.accessibleActionListeners;
/*  127 */       int length = size(listeners);
/*  128 */       if (length > 0) {
/*  129 */         AccessibleActionEvent event = new AccessibleActionEvent(accessible);
/*  130 */         event.index = ((int)index);
/*  131 */         for (int i = 0; i < length; i++) {
/*  132 */           AccessibleActionListener listener = (AccessibleActionListener)listeners.get(i);
/*  133 */           listener.doAction(event);
/*      */         }
/*  135 */         return "OK".equals(event.result) ? 1L : 0L;
/*      */       }
/*      */     }
/*  138 */     long parentResult = 0L;
/*  139 */     AtkActionIface iface = getParentActionIface(atkObject);
/*  140 */     if ((iface != null) && (iface.do_action != 0L)) {
/*  141 */       parentResult = ATK.call(iface.do_action, atkObject, index);
/*      */     }
/*  143 */     return parentResult;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static long atkAction_get_n_actions(long atkObject)
/*      */   {
/*  161 */     AccessibleObject object = getAccessibleObject(atkObject);
/*  162 */     if (object != null) {
/*  163 */       Accessible accessible = object.accessible;
/*  164 */       List<AccessibleActionListener> listeners = accessible.accessibleActionListeners;
/*  165 */       int length = size(listeners);
/*  166 */       if (length > 0) {
/*  167 */         AccessibleActionEvent event = new AccessibleActionEvent(accessible);
/*  168 */         for (int i = 0; i < length; i++) {
/*  169 */           AccessibleActionListener listener = (AccessibleActionListener)listeners.get(i);
/*  170 */           listener.getActionCount(event);
/*      */         }
/*  172 */         return event.count;
/*      */       }
/*      */     }
/*  175 */     long parentResult = 0L;
/*  176 */     AtkActionIface iface = getParentActionIface(atkObject);
/*  177 */     if ((iface != null) && (iface.get_n_actions != 0L)) {
/*  178 */       parentResult = ATK.call(iface.get_n_actions, atkObject);
/*      */     }
/*  180 */     return parentResult;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static long atkAction_get_description(long atkObject, long index)
/*      */   {
/*  197 */     AccessibleObject object = getAccessibleObject(atkObject);
/*  198 */     if (object != null) {
/*  199 */       Accessible accessible = object.accessible;
/*  200 */       List<AccessibleActionListener> listeners = accessible.accessibleActionListeners;
/*  201 */       int length = size(listeners);
/*  202 */       if (length > 0) {
/*  203 */         AccessibleActionEvent event = new AccessibleActionEvent(accessible);
/*  204 */         event.index = ((int)index);
/*  205 */         for (int i = 0; i < length; i++) {
/*  206 */           AccessibleActionListener listener = (AccessibleActionListener)listeners.get(i);
/*  207 */           listener.getDescription(event);
/*      */         }
/*  209 */         if (event.result == null) return 0L;
/*  210 */         if (descriptionPtr != -1L) OS.g_free(descriptionPtr);
/*  211 */         return descriptionPtr = getStringPtr(event.result);
/*      */       }
/*      */     }
/*  214 */     long parentResult = 0L;
/*  215 */     AtkActionIface iface = getParentActionIface(atkObject);
/*  216 */     if ((iface != null) && (iface.get_description != 0L)) {
/*  217 */       parentResult = ATK.call(iface.get_description, atkObject, index);
/*      */     }
/*  219 */     return parentResult;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static long atkAction_get_keybinding(long atkObject, long index)
/*      */   {
/*  237 */     AccessibleObject object = getAccessibleObject(atkObject);
/*  238 */     long parentResult = 0L;
/*  239 */     AtkActionIface iface = getParentActionIface(atkObject);
/*  240 */     if ((iface != null) && (iface.get_keybinding != 0L)) {
/*  241 */       parentResult = ATK.call(iface.get_keybinding, atkObject, index);
/*      */     }
/*  243 */     if (object != null) {
/*  244 */       Accessible accessible = object.accessible;
/*  245 */       List<AccessibleActionListener> listeners = accessible.accessibleActionListeners;
/*  246 */       int length = size(listeners);
/*  247 */       if (length > 0) {
/*  248 */         AccessibleActionEvent event = new AccessibleActionEvent(accessible);
/*  249 */         event.index = ((int)index);
/*  250 */         for (int i = 0; i < length; i++) {
/*  251 */           AccessibleActionListener listener = (AccessibleActionListener)listeners.get(i);
/*  252 */           listener.getKeyBinding(event);
/*      */         }
/*  254 */         if (event.result != null) {
/*  255 */           if (keybindingPtr != -1L) OS.g_free(keybindingPtr);
/*  256 */           return keybindingPtr = getStringPtr(event.result);
/*      */         }
/*      */       }
/*  259 */       List<AccessibleListener> listeners2 = accessible.accessibleListeners;
/*  260 */       length = size(listeners2);
/*  261 */       if (length > 0) {
/*  262 */         AccessibleEvent event = new AccessibleEvent(accessible);
/*  263 */         event.childID = object.id;
/*  264 */         if (parentResult != 0L) event.result = getString(parentResult);
/*  265 */         for (int i = 0; i < length; i++) {
/*  266 */           AccessibleListener listener = (AccessibleListener)listeners2.get(i);
/*  267 */           listener.getKeyboardShortcut(event);
/*      */         }
/*  269 */         if (event.result != null) {
/*  270 */           if (keybindingPtr != -1L) OS.g_free(keybindingPtr);
/*  271 */           return keybindingPtr = getStringPtr(event.result);
/*      */         }
/*      */       }
/*      */     }
/*  275 */     return parentResult;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static long atkAction_get_name(long atkObject, long index)
/*      */   {
/*  292 */     AccessibleObject object = getAccessibleObject(atkObject);
/*  293 */     long parentResult = 0L;
/*  294 */     AtkActionIface iface = getParentActionIface(atkObject);
/*  295 */     if ((iface != null) && (iface.get_name != 0L)) {
/*  296 */       parentResult = ATK.call(iface.get_name, atkObject, index);
/*      */     }
/*  298 */     if (object != null) {
/*  299 */       Accessible accessible = object.accessible;
/*  300 */       List<AccessibleActionListener> listeners = accessible.accessibleActionListeners;
/*  301 */       int length = size(listeners);
/*  302 */       if (length > 0) {
/*  303 */         AccessibleActionEvent event = new AccessibleActionEvent(accessible);
/*  304 */         event.index = ((int)index);
/*  305 */         for (int i = 0; i < length; i++) {
/*  306 */           AccessibleActionListener listener = (AccessibleActionListener)listeners.get(i);
/*  307 */           listener.getName(event);
/*      */         }
/*  309 */         if (event.result != null) {
/*  310 */           if (actionNamePtr != -1L) OS.g_free(actionNamePtr);
/*  311 */           return actionNamePtr = getStringPtr(event.result);
/*      */         }
/*      */       }
/*  314 */       if (index == 0L) {
/*  315 */         List<AccessibleControlListener> listeners2 = accessible.accessibleControlListeners;
/*  316 */         length = size(listeners2);
/*  317 */         if (length > 0) {
/*  318 */           AccessibleControlEvent event = new AccessibleControlEvent(accessible);
/*  319 */           event.childID = object.id;
/*  320 */           if (parentResult != 0L) event.result = getString(parentResult);
/*  321 */           for (int i = 0; i < length; i++) {
/*  322 */             AccessibleControlListener listener = (AccessibleControlListener)listeners2.get(i);
/*  323 */             listener.getDefaultAction(event);
/*      */           }
/*  325 */           if (event.result != null) {
/*  326 */             if (actionNamePtr != -1L) OS.g_free(actionNamePtr);
/*  327 */             return actionNamePtr = getStringPtr(event.result);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*  332 */     return parentResult;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static AtkComponentIface getParentComponentIface(long atkObject)
/*      */   {
/*  346 */     long type = GTK.GTK3 ? OS.swt_fixed_accessible_get_type() : OS.G_OBJECT_TYPE(atkObject);
/*  347 */     if (OS.g_type_is_a(OS.g_type_parent(type), ATK.ATK_TYPE_COMPONENT())) {
/*  348 */       AtkComponentIface iface = new AtkComponentIface();
/*  349 */       ATK.memmove(iface, OS.g_type_interface_peek_parent(ATK.ATK_COMPONENT_GET_IFACE(atkObject)));
/*  350 */       return iface;
/*      */     }
/*  352 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static long atkComponent_get_extents(long atkObject, long x, long y, long width, long height, long coord_type)
/*      */   {
/*  375 */     AccessibleObject object = getAccessibleObject(atkObject);
/*  376 */     C.memmove(x, new int[] { 0 }, 4L);
/*  377 */     C.memmove(y, new int[] { 0 }, 4L);
/*  378 */     C.memmove(width, new int[] { 0 }, 4L);
/*  379 */     C.memmove(height, new int[] { 0 }, 4L);
/*  380 */     AtkComponentIface iface = getParentComponentIface(atkObject);
/*  381 */     if ((iface != null) && (iface.get_extents != 0L)) {
/*  382 */       OS.call(iface.get_extents, atkObject, x, y, width, height, coord_type);
/*      */     }
/*  384 */     if (object != null) {
/*  385 */       Accessible accessible = object.accessible;
/*  386 */       List<AccessibleControlListener> listeners = accessible.accessibleControlListeners;
/*  387 */       int length = size(listeners);
/*  388 */       if (length > 0) {
/*  389 */         int[] parentX = new int[1];int[] parentY = new int[1];
/*  390 */         int[] parentWidth = new int[1];int[] parentHeight = new int[1];
/*  391 */         C.memmove(parentX, x, 4L);
/*  392 */         C.memmove(parentY, y, 4L);
/*  393 */         C.memmove(parentWidth, width, 4L);
/*  394 */         C.memmove(parentHeight, height, 4L);
/*  395 */         AccessibleControlEvent event = new AccessibleControlEvent(accessible);
/*  396 */         event.childID = object.id;
/*  397 */         event.x = parentX[0];event.y = parentY[0];
/*  398 */         event.width = parentWidth[0];event.height = parentHeight[0];
/*  399 */         int[] topWindowX = new int[1];int[] topWindowY = new int[1];
/*  400 */         if (coord_type == 1L) {
/*  401 */           windowPoint(object, topWindowX, topWindowY);
/*  402 */           event.x += topWindowX[0];
/*  403 */           event.y += topWindowY[0];
/*      */         }
/*  405 */         for (int i = 0; i < length; i++) {
/*  406 */           AccessibleControlListener listener = (AccessibleControlListener)listeners.get(i);
/*  407 */           listener.getLocation(event);
/*      */         }
/*  409 */         if (coord_type == 1L) {
/*  410 */           event.x -= topWindowX[0];
/*  411 */           event.y -= topWindowY[0];
/*      */         }
/*  413 */         C.memmove(x, new int[] { event.x }, 4L);
/*  414 */         C.memmove(y, new int[] { event.y }, 4L);
/*  415 */         C.memmove(width, new int[] { event.width }, 4L);
/*  416 */         C.memmove(height, new int[] { event.height }, 4L);
/*      */       }
/*      */     }
/*  419 */     return 0L;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static long atkComponent_get_position(long atkObject, long x, long y, long coord_type)
/*      */   {
/*  441 */     AccessibleObject object = getAccessibleObject(atkObject);
/*  442 */     C.memmove(x, new int[] { 0 }, 4L);
/*  443 */     C.memmove(y, new int[] { 0 }, 4L);
/*  444 */     AtkComponentIface iface = getParentComponentIface(atkObject);
/*  445 */     if ((iface != null) && (iface.get_position != 0L)) {
/*  446 */       OS.call(iface.get_position, atkObject, x, y, coord_type);
/*      */     }
/*  448 */     if (object != null) {
/*  449 */       Accessible accessible = object.accessible;
/*  450 */       List<AccessibleControlListener> listeners = accessible.accessibleControlListeners;
/*  451 */       int length = size(listeners);
/*  452 */       if (length > 0) {
/*  453 */         int[] parentX = new int[1];int[] parentY = new int[1];
/*  454 */         C.memmove(parentX, x, 4L);
/*  455 */         C.memmove(parentY, y, 4L);
/*  456 */         AccessibleControlEvent event = new AccessibleControlEvent(accessible);
/*  457 */         event.childID = object.id;
/*  458 */         event.x = parentX[0];event.y = parentY[0];
/*  459 */         int[] topWindowX = new int[1];int[] topWindowY = new int[1];
/*  460 */         if (coord_type == 1L) {
/*  461 */           windowPoint(object, topWindowX, topWindowY);
/*  462 */           event.x += topWindowX[0];
/*  463 */           event.y += topWindowY[0];
/*      */         }
/*  465 */         for (int i = 0; i < length; i++) {
/*  466 */           AccessibleControlListener listener = (AccessibleControlListener)listeners.get(i);
/*  467 */           listener.getLocation(event);
/*      */         }
/*  469 */         if (coord_type == 1L) {
/*  470 */           event.x -= topWindowX[0];
/*  471 */           event.y -= topWindowY[0];
/*      */         }
/*  473 */         C.memmove(x, new int[] { event.x }, 4L);
/*  474 */         C.memmove(y, new int[] { event.y }, 4L);
/*      */       }
/*      */     }
/*  477 */     return 0L;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static long atkComponent_get_size(long atkObject, long width, long height, long coord_type)
/*      */   {
/*  499 */     AccessibleObject object = getAccessibleObject(atkObject);
/*  500 */     C.memmove(width, new int[] { 0 }, 4L);
/*  501 */     C.memmove(height, new int[] { 0 }, 4L);
/*  502 */     AtkComponentIface iface = getParentComponentIface(atkObject);
/*  503 */     if ((iface != null) && (iface.get_size != 0L))
/*      */     {
/*  505 */       if (!GTK.GTK3) {
/*  506 */         OS.call(iface.get_size, atkObject, width, height, coord_type);
/*      */       } else {
/*  508 */         ATK.call(iface.get_size, atkObject, width, height);
/*      */       }
/*      */     }
/*  511 */     if (object != null) {
/*  512 */       Accessible accessible = object.accessible;
/*  513 */       List<AccessibleControlListener> listeners = accessible.accessibleControlListeners;
/*  514 */       int length = size(listeners);
/*  515 */       if (length > 0) {
/*  516 */         int[] parentWidth = new int[1];int[] parentHeight = new int[1];
/*  517 */         C.memmove(parentWidth, width, 4L);
/*  518 */         C.memmove(parentHeight, height, 4L);
/*  519 */         AccessibleControlEvent event = new AccessibleControlEvent(accessible);
/*  520 */         event.childID = object.id;
/*  521 */         event.width = parentWidth[0];event.height = parentHeight[0];
/*  522 */         for (int i = 0; i < length; i++) {
/*  523 */           AccessibleControlListener listener = (AccessibleControlListener)listeners.get(i);
/*  524 */           listener.getLocation(event);
/*      */         }
/*  526 */         C.memmove(width, new int[] { event.width }, 4L);
/*  527 */         C.memmove(height, new int[] { event.height }, 4L);
/*      */       }
/*      */     }
/*  530 */     return 0L;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static long atkComponent_ref_accessible_at_point(long atkObject, long x, long y, long coord_type)
/*      */   {
/*  552 */     AccessibleObject object = getAccessibleObject(atkObject);
/*  553 */     if (object != null) {
/*  554 */       Accessible accessible = object.accessible;
/*  555 */       List<AccessibleControlListener> listeners = accessible.accessibleControlListeners;
/*  556 */       int length = size(listeners);
/*  557 */       if (length > 0) {
/*  558 */         AccessibleControlEvent event = new AccessibleControlEvent(accessible);
/*  559 */         event.childID = object.id;
/*  560 */         event.x = ((int)x);event.y = ((int)y);
/*  561 */         int[] topWindowX = new int[1];int[] topWindowY = new int[1];
/*  562 */         if (coord_type == 1L) {
/*  563 */           windowPoint(object, topWindowX, topWindowY);
/*  564 */           event.x += topWindowX[0];
/*  565 */           event.y += topWindowY[0];
/*      */         }
/*  567 */         for (int i = 0; i < length; i++) {
/*  568 */           AccessibleControlListener listener = (AccessibleControlListener)listeners.get(i);
/*  569 */           listener.getChildAtPoint(event);
/*      */         }
/*  571 */         if (event.childID == object.id) event.childID = -1;
/*  572 */         Accessible result = event.accessible;
/*  573 */         AccessibleObject accObj = result != null ? result.getAccessibleObject() : object.getChildByID(event.childID);
/*  574 */         if (accObj != null) {
/*  575 */           return OS.g_object_ref(accObj.atkHandle);
/*      */         }
/*      */       }
/*      */     }
/*  579 */     long parentResult = 0L;
/*  580 */     AtkComponentIface iface = getParentComponentIface(atkObject);
/*  581 */     if ((iface != null) && (iface.ref_accessible_at_point != 0L)) {
/*  582 */       parentResult = OS.call(iface.ref_accessible_at_point, atkObject, x, y, coord_type);
/*      */     }
/*  584 */     return parentResult;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static AtkEditableTextIface getParentEditableTextIface(long atkObject)
/*      */   {
/*  599 */     long type = GTK.GTK3 ? OS.swt_fixed_accessible_get_type() : OS.G_OBJECT_TYPE(atkObject);
/*  600 */     if (OS.g_type_is_a(OS.g_type_parent(type), ATK.ATK_TYPE_EDITABLE_TEXT())) {
/*  601 */       AtkEditableTextIface iface = new AtkEditableTextIface();
/*  602 */       ATK.memmove(iface, OS.g_type_interface_peek_parent(ATK.ATK_EDITABLE_TEXT_GET_IFACE(atkObject)));
/*  603 */       return iface;
/*      */     }
/*  605 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static long atkEditableText_set_run_attributes(long atkObject, long attrib_set, long start_offset, long end_offset)
/*      */   {
/*  625 */     AccessibleObject object = getAccessibleObject(atkObject);
/*  626 */     if (object != null) {
/*  627 */       Accessible accessible = object.accessible;
/*  628 */       List<AccessibleEditableTextListener> listeners = accessible.accessibleEditableTextListeners;
/*  629 */       int length = size(listeners);
/*  630 */       if (length > 0) {
/*  631 */         org.eclipse.swt.widgets.Display display = accessible.control.getDisplay();
/*  632 */         long fontDesc = OS.pango_font_description_new();
/*  633 */         boolean createFont = false;
/*  634 */         TextStyle style = new TextStyle();
/*  635 */         String[] attributes = new String[0];
/*  636 */         long current = attrib_set;
/*  637 */         int listLength = OS.g_slist_length(attrib_set);
/*  638 */         for (int i = 0; i < listLength; i++) {
/*  639 */           long attrPtr = OS.g_slist_data(current);
/*  640 */           if (attrPtr != 0L) {
/*  641 */             AtkAttribute attr = new AtkAttribute();
/*  642 */             ATK.memmove(attr, attrPtr, AtkAttribute.sizeof);
/*  643 */             String name = getString(attr.name);
/*  644 */             String value = getString(attr.value);
/*  645 */             OS.g_free(attrPtr);
/*  646 */             String[] newAttributes = new String[attributes.length + 2];
/*  647 */             System.arraycopy(attributes, 0, newAttributes, 0, attributes.length);
/*  648 */             newAttributes[attributes.length] = name;
/*  649 */             newAttributes[(attributes.length + 1)] = value;
/*  650 */             attributes = newAttributes;
/*      */             try {
/*  652 */               if (name.equals(getString(ATK.atk_text_attribute_get_name(10))))
/*      */               {
/*  654 */                 style.rise = Integer.parseInt(value);
/*  655 */               } else if (name.equals(getString(ATK.atk_text_attribute_get_name(11))))
/*      */               {
/*  657 */                 if ((value.equals("single")) || (value.equals("low"))) {
/*  658 */                   style.underline = true;
/*  659 */                   style.underlineStyle = 0;
/*  660 */                 } else if (value.equals("double")) {
/*  661 */                   style.underline = true;
/*  662 */                   style.underlineStyle = 1;
/*  663 */                 } else if (value.equals("error")) {
/*  664 */                   style.underline = true;
/*  665 */                   style.underlineStyle = 2;
/*  666 */                 } else if (value.equals("squiggle")) {
/*  667 */                   style.underline = true;
/*  668 */                   style.underlineStyle = 3;
/*      */                 }
/*  670 */               } else if (name.equals(getString(ATK.atk_text_attribute_get_name(12))))
/*      */               {
/*  672 */                 if ((value.equals("true")) || (value.equals("1")) || (value.equals("single"))) style.strikeout = true;
/*  673 */               } else if (name.equals(getString(ATK.atk_text_attribute_get_name(17))))
/*      */               {
/*  675 */                 byte[] buffer = org.eclipse.swt.internal.Converter.wcsToMbcs(value, true);
/*  676 */                 OS.pango_font_description_set_family(fontDesc, buffer);
/*  677 */                 createFont = true;
/*  678 */               } else if (name.equals(getString(ATK.atk_text_attribute_get_name(13))))
/*      */               {
/*  680 */                 float size = Float.parseFloat(value);
/*  681 */                 OS.pango_font_description_set_size(fontDesc, (int)(size * 1024.0F));
/*  682 */                 createFont = true;
/*  683 */               } else if (name.equals(getString(ATK.atk_text_attribute_get_name(27))))
/*      */               {
/*  685 */                 int fontStyle = -1;
/*  686 */                 if (value.equals("normal")) { fontStyle = 0;
/*  687 */                 } else if (value.equals("italic")) { fontStyle = 2;
/*  688 */                 } else if (value.equals("oblique")) fontStyle = 1;
/*  689 */                 if (fontStyle != -1) {
/*  690 */                   OS.pango_font_description_set_style(fontDesc, fontStyle);
/*  691 */                   createFont = true;
/*      */                 }
/*  693 */               } else if (name.equals(getString(ATK.atk_text_attribute_get_name(26))))
/*      */               {
/*  695 */                 int variant = -1;
/*  696 */                 if (value.equals("normal")) { variant = 0;
/*  697 */                 } else if (value.equals("small_caps")) variant = 1;
/*  698 */                 if (variant != -1) {
/*  699 */                   OS.pango_font_description_set_variant(fontDesc, variant);
/*  700 */                   createFont = true;
/*      */                 }
/*  702 */               } else if (name.equals(getString(ATK.atk_text_attribute_get_name(25))))
/*      */               {
/*  704 */                 int stretch = -1;
/*  705 */                 if (value.equals("ultra_condensed")) { stretch = 0;
/*  706 */                 } else if (value.equals("extra_condensed")) { stretch = 1;
/*  707 */                 } else if (value.equals("condensed")) { stretch = 2;
/*  708 */                 } else if (value.equals("semi_condensed")) { stretch = 3;
/*  709 */                 } else if (value.equals("normal")) { stretch = 4;
/*  710 */                 } else if (value.equals("semi_expanded")) { stretch = 5;
/*  711 */                 } else if (value.equals("expanded")) { stretch = 6;
/*  712 */                 } else if (value.equals("extra_expanded")) { stretch = 7;
/*  713 */                 } else if (value.equals("ultra_expanded")) stretch = 8;
/*  714 */                 if (stretch != -1) {
/*  715 */                   OS.pango_font_description_set_stretch(fontDesc, stretch);
/*  716 */                   createFont = true;
/*      */                 }
/*  718 */               } else if (name.equals(getString(ATK.atk_text_attribute_get_name(15))))
/*      */               {
/*  720 */                 int weight = Integer.parseInt(value);
/*  721 */                 OS.pango_font_description_set_weight(fontDesc, weight);
/*  722 */                 createFont = true;
/*  723 */               } else if (name.equals(getString(ATK.atk_text_attribute_get_name(19))))
/*      */               {
/*  725 */                 style.foreground = colorFromString(display, value);
/*  726 */               } else if (name.equals(getString(ATK.atk_text_attribute_get_name(18))))
/*      */               {
/*  728 */                 style.background = colorFromString(display, value);
/*      */               }
/*      */             }
/*      */             catch (NumberFormatException localNumberFormatException) {}
/*      */           }
/*      */           
/*  734 */           current = OS.g_slist_next(current);
/*      */         }
/*  736 */         if (createFont) {
/*  737 */           style.font = Font.gtk_new(display, fontDesc);
/*      */         }
/*      */         
/*  740 */         AccessibleTextAttributeEvent event = new AccessibleTextAttributeEvent(accessible);
/*  741 */         event.start = ((int)start_offset);
/*  742 */         event.end = ((int)end_offset);
/*  743 */         event.textStyle = style;
/*  744 */         event.attributes = attributes;
/*  745 */         for (int i = 0; i < length; i++) {
/*  746 */           AccessibleEditableTextListener listener = (AccessibleEditableTextListener)listeners.get(i);
/*  747 */           listener.setTextAttributes(event);
/*      */         }
/*  749 */         if (style.font != null) {
/*  750 */           style.font.dispose();
/*      */         }
/*  752 */         if (style.foreground != null) {
/*  753 */           style.foreground.dispose();
/*      */         }
/*  755 */         if (style.background != null) {
/*  756 */           style.background.dispose();
/*      */         }
/*  758 */         return "OK".equals(event.result) ? 1L : 0L;
/*      */       }
/*      */     }
/*  761 */     long parentResult = 0L;
/*  762 */     AtkEditableTextIface iface = getParentEditableTextIface(atkObject);
/*  763 */     if ((iface != null) && (iface.set_run_attributes != 0L)) {
/*  764 */       parentResult = OS.call(iface.set_run_attributes, atkObject, attrib_set, start_offset, end_offset);
/*      */     }
/*  766 */     return parentResult;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   static Color colorFromString(org.eclipse.swt.widgets.Display display, String rgbString)
/*      */   {
/*      */     try
/*      */     {
/*  776 */       int comma1 = rgbString.indexOf(',');
/*  777 */       int comma2 = rgbString.indexOf(',', comma1 + 1);
/*  778 */       int r = Integer.parseInt(rgbString.substring(0, comma1));
/*  779 */       int g = Integer.parseInt(rgbString.substring(comma1 + 1, comma2));
/*  780 */       int b = Integer.parseInt(rgbString.substring(comma2 + 1, rgbString.length()));
/*  781 */       return new Color(display, r, g, b);
/*      */     } catch (NumberFormatException localNumberFormatException) {}
/*  783 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static long atkEditableText_set_text_contents(long atkObject, long string)
/*      */   {
/*  800 */     AccessibleObject object = getAccessibleObject(atkObject);
/*  801 */     if (object != null) {
/*  802 */       Accessible accessible = object.accessible;
/*  803 */       List<AccessibleEditableTextListener> listeners = accessible.accessibleEditableTextListeners;
/*  804 */       int length = size(listeners);
/*  805 */       if (length > 0) {
/*  806 */         AccessibleEditableTextEvent event = new AccessibleEditableTextEvent(accessible);
/*  807 */         event.start = 0;
/*  808 */         String text = object.getText();
/*  809 */         event.end = (text == null ? 0 : text.length());
/*  810 */         event.string = getString(string);
/*  811 */         for (int i = 0; i < length; i++) {
/*  812 */           AccessibleEditableTextListener listener = (AccessibleEditableTextListener)listeners.get(i);
/*  813 */           listener.replaceText(event);
/*      */         }
/*  815 */         return "OK".equals(event.result) ? 1L : 0L;
/*      */       }
/*      */     }
/*  818 */     long parentResult = 0L;
/*  819 */     AtkEditableTextIface iface = getParentEditableTextIface(atkObject);
/*  820 */     if ((iface != null) && (iface.set_text_contents != 0L)) {
/*  821 */       parentResult = ATK.call(iface.set_text_contents, atkObject, string);
/*      */     }
/*  823 */     return parentResult;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static long atkEditableText_insert_text(long atkObject, long string, long string_length, long position)
/*      */   {
/*  845 */     AccessibleObject object = getAccessibleObject(atkObject);
/*  846 */     if (object != null) {
/*  847 */       Accessible accessible = object.accessible;
/*  848 */       List<AccessibleEditableTextListener> listeners = accessible.accessibleEditableTextListeners;
/*  849 */       int length = size(listeners);
/*  850 */       if (length > 0) {
/*  851 */         AccessibleEditableTextEvent event = new AccessibleEditableTextEvent(accessible);
/*  852 */         int[] pos = new int[1];
/*  853 */         C.memmove(pos, position, C.PTR_SIZEOF);
/*  854 */         event.start = (event.end = pos[0]);
/*  855 */         event.string = getString(string);
/*  856 */         for (int i = 0; i < length; i++) {
/*  857 */           AccessibleEditableTextListener listener = (AccessibleEditableTextListener)listeners.get(i);
/*  858 */           listener.replaceText(event);
/*      */         }
/*  860 */         return "OK".equals(event.result) ? 1L : 0L;
/*      */       }
/*      */     }
/*  863 */     long parentResult = 0L;
/*  864 */     AtkEditableTextIface iface = getParentEditableTextIface(atkObject);
/*  865 */     if ((iface != null) && (iface.insert_text != 0L)) {
/*  866 */       parentResult = OS.call(iface.insert_text, atkObject, string, string_length, position);
/*      */     }
/*  868 */     return parentResult;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static long atkEditableText_copy_text(long atkObject, long start_pos, long end_pos)
/*      */   {
/*  887 */     AccessibleObject object = getAccessibleObject(atkObject);
/*  888 */     if (object != null) {
/*  889 */       Accessible accessible = object.accessible;
/*  890 */       List<AccessibleEditableTextListener> listeners = accessible.accessibleEditableTextListeners;
/*  891 */       int length = size(listeners);
/*  892 */       if (length > 0) {
/*  893 */         AccessibleEditableTextEvent event = new AccessibleEditableTextEvent(accessible);
/*  894 */         event.start = ((int)start_pos);
/*  895 */         event.end = ((int)end_pos);
/*  896 */         for (int i = 0; i < length; i++) {
/*  897 */           AccessibleEditableTextListener listener = (AccessibleEditableTextListener)listeners.get(i);
/*  898 */           listener.copyText(event);
/*      */         }
/*  900 */         return "OK".equals(event.result) ? 1L : 0L;
/*      */       }
/*      */     }
/*  903 */     long parentResult = 0L;
/*  904 */     AtkEditableTextIface iface = getParentEditableTextIface(atkObject);
/*  905 */     if ((iface != null) && (iface.copy_text != 0L)) {
/*  906 */       parentResult = ATK.call(iface.copy_text, atkObject, start_pos, end_pos);
/*      */     }
/*  908 */     return parentResult;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static long atkEditableText_cut_text(long atkObject, long start_pos, long end_pos)
/*      */   {
/*  927 */     AccessibleObject object = getAccessibleObject(atkObject);
/*  928 */     if (object != null) {
/*  929 */       Accessible accessible = object.accessible;
/*  930 */       List<AccessibleEditableTextListener> listeners = accessible.accessibleEditableTextListeners;
/*  931 */       int length = size(listeners);
/*  932 */       if (length > 0) {
/*  933 */         AccessibleEditableTextEvent event = new AccessibleEditableTextEvent(accessible);
/*  934 */         event.start = ((int)start_pos);
/*  935 */         event.end = ((int)end_pos);
/*  936 */         for (int i = 0; i < length; i++) {
/*  937 */           AccessibleEditableTextListener listener = (AccessibleEditableTextListener)listeners.get(i);
/*  938 */           listener.cutText(event);
/*      */         }
/*  940 */         return "OK".equals(event.result) ? 1L : 0L;
/*      */       }
/*      */     }
/*  943 */     long parentResult = 0L;
/*  944 */     AtkEditableTextIface iface = getParentEditableTextIface(atkObject);
/*  945 */     if ((iface != null) && (iface.cut_text != 0L)) {
/*  946 */       parentResult = ATK.call(iface.cut_text, atkObject, start_pos, end_pos);
/*      */     }
/*  948 */     return parentResult;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static long atkEditableText_delete_text(long atkObject, long start_pos, long end_pos)
/*      */   {
/*  966 */     AccessibleObject object = getAccessibleObject(atkObject);
/*  967 */     if (object != null) {
/*  968 */       Accessible accessible = object.accessible;
/*  969 */       List<AccessibleEditableTextListener> listeners = accessible.accessibleEditableTextListeners;
/*  970 */       int length = size(listeners);
/*  971 */       if (length > 0) {
/*  972 */         AccessibleEditableTextEvent event = new AccessibleEditableTextEvent(accessible);
/*  973 */         event.start = ((int)start_pos);
/*  974 */         event.end = ((int)end_pos);
/*  975 */         event.string = "";
/*  976 */         for (int i = 0; i < length; i++) {
/*  977 */           AccessibleEditableTextListener listener = (AccessibleEditableTextListener)listeners.get(i);
/*  978 */           listener.replaceText(event);
/*      */         }
/*  980 */         return "OK".equals(event.result) ? 1L : 0L;
/*      */       }
/*      */     }
/*  983 */     long parentResult = 0L;
/*  984 */     AtkEditableTextIface iface = getParentEditableTextIface(atkObject);
/*  985 */     if ((iface != null) && (iface.delete_text != 0L)) {
/*  986 */       parentResult = ATK.call(iface.delete_text, atkObject, start_pos, end_pos);
/*      */     }
/*  988 */     return parentResult;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static long atkEditableText_paste_text(long atkObject, long position)
/*      */   {
/* 1005 */     AccessibleObject object = getAccessibleObject(atkObject);
/* 1006 */     if (object != null) {
/* 1007 */       Accessible accessible = object.accessible;
/* 1008 */       List<AccessibleEditableTextListener> listeners = accessible.accessibleEditableTextListeners;
/* 1009 */       int length = size(listeners);
/* 1010 */       if (length > 0) {
/* 1011 */         AccessibleEditableTextEvent event = new AccessibleEditableTextEvent(accessible);
/* 1012 */         event.start = ((int)position);
/* 1013 */         for (int i = 0; i < length; i++) {
/* 1014 */           AccessibleEditableTextListener listener = (AccessibleEditableTextListener)listeners.get(i);
/* 1015 */           listener.pasteText(event);
/*      */         }
/* 1017 */         return "OK".equals(event.result) ? 1L : 0L;
/*      */       }
/*      */     }
/* 1020 */     long parentResult = 0L;
/* 1021 */     AtkEditableTextIface iface = getParentEditableTextIface(atkObject);
/* 1022 */     if ((iface != null) && (iface.paste_text != 0L)) {
/* 1023 */       parentResult = ATK.call(iface.paste_text, atkObject, position);
/*      */     }
/* 1025 */     return parentResult;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static AtkHypertextIface getParentHypertextIface(long atkObject)
/*      */   {
/* 1039 */     long type = GTK.GTK3 ? OS.swt_fixed_accessible_get_type() : OS.G_OBJECT_TYPE(atkObject);
/* 1040 */     if (OS.g_type_is_a(OS.g_type_parent(type), ATK.ATK_TYPE_HYPERTEXT())) {
/* 1041 */       AtkHypertextIface iface = new AtkHypertextIface();
/* 1042 */       ATK.memmove(iface, OS.g_type_interface_peek_parent(ATK.ATK_HYPERTEXT_GET_IFACE(atkObject)));
/* 1043 */       return iface;
/*      */     }
/* 1045 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static long atkHypertext_get_link(long atkObject, long link_index)
/*      */   {
/* 1062 */     AccessibleObject object = getAccessibleObject(atkObject);
/* 1063 */     if (object != null) {
/* 1064 */       Accessible accessible = object.accessible;
/* 1065 */       List<AccessibleTextExtendedListener> listeners = accessible.accessibleTextExtendedListeners;
/* 1066 */       int length = size(listeners);
/* 1067 */       if (length > 0) {
/* 1068 */         AccessibleTextEvent event = new AccessibleTextEvent(accessible);
/* 1069 */         event.index = ((int)link_index);
/* 1070 */         for (int i = 0; i < length; i++) {
/* 1071 */           AccessibleTextExtendedListener listener = (AccessibleTextExtendedListener)listeners.get(i);
/* 1072 */           listener.getHyperlink(event);
/*      */         }
/* 1074 */         Accessible result = event.accessible;
/* 1075 */         return result != null ? result.getAccessibleObject().atkHandle : 0L;
/*      */       }
/*      */     }
/* 1078 */     long parentResult = 0L;
/* 1079 */     AtkHypertextIface iface = getParentHypertextIface(atkObject);
/* 1080 */     if ((iface != null) && (iface.get_link != 0L)) {
/* 1081 */       parentResult = ATK.call(iface.get_link, atkObject, link_index);
/*      */     }
/* 1083 */     return parentResult;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static long atkHypertext_get_n_links(long atkObject)
/*      */   {
/* 1100 */     AccessibleObject object = getAccessibleObject(atkObject);
/* 1101 */     if (object != null) {
/* 1102 */       Accessible accessible = object.accessible;
/* 1103 */       List<AccessibleTextExtendedListener> listeners = accessible.accessibleTextExtendedListeners;
/* 1104 */       int length = size(listeners);
/* 1105 */       if (length > 0) {
/* 1106 */         AccessibleTextEvent event = new AccessibleTextEvent(accessible);
/* 1107 */         for (int i = 0; i < length; i++) {
/* 1108 */           AccessibleTextExtendedListener listener = (AccessibleTextExtendedListener)listeners.get(i);
/* 1109 */           listener.getHyperlinkCount(event);
/*      */         }
/* 1111 */         return event.count;
/*      */       }
/*      */     }
/* 1114 */     long parentResult = 0L;
/* 1115 */     AtkHypertextIface iface = getParentHypertextIface(atkObject);
/* 1116 */     if ((iface != null) && (iface.get_n_links != 0L)) {
/* 1117 */       parentResult = ATK.call(iface.get_n_links, atkObject);
/*      */     }
/* 1119 */     return parentResult;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static long atkHypertext_get_link_index(long atkObject, long char_index)
/*      */   {
/* 1138 */     AccessibleObject object = getAccessibleObject(atkObject);
/* 1139 */     if (object != null) {
/* 1140 */       Accessible accessible = object.accessible;
/* 1141 */       List<AccessibleTextExtendedListener> listeners = accessible.accessibleTextExtendedListeners;
/* 1142 */       int length = size(listeners);
/* 1143 */       if (length > 0) {
/* 1144 */         AccessibleTextEvent event = new AccessibleTextEvent(accessible);
/* 1145 */         event.offset = ((int)char_index);
/* 1146 */         event.index = -1;
/* 1147 */         for (int i = 0; i < length; i++) {
/* 1148 */           AccessibleTextExtendedListener listener = (AccessibleTextExtendedListener)listeners.get(i);
/* 1149 */           listener.getHyperlinkIndex(event);
/*      */         }
/* 1151 */         return event.index;
/*      */       }
/*      */     }
/* 1154 */     long parentResult = 0L;
/* 1155 */     AtkHypertextIface iface = getParentHypertextIface(atkObject);
/* 1156 */     if ((iface != null) && (iface.get_link_index != 0L)) {
/* 1157 */       parentResult = ATK.call(iface.get_link_index, atkObject, char_index);
/*      */     }
/* 1159 */     return parentResult;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static AtkObjectClass getParentAtkObjectClass(long atkObject)
/*      */   {
/* 1173 */     AtkObjectClass objectClass = new AtkObjectClass();
/* 1174 */     long type = GTK.GTK3 ? OS.swt_fixed_accessible_get_type() : OS.G_OBJECT_TYPE(atkObject);
/* 1175 */     if (type != 0L) {
/* 1176 */       long parentType = OS.g_type_parent(type);
/* 1177 */       if (parentType != 0L) ATK.memmove(objectClass, OS.g_type_class_peek(parentType));
/*      */     }
/* 1179 */     return objectClass;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static long atkObject_get_description(long atkObject)
/*      */   {
/* 1196 */     AccessibleObject object = getAccessibleObject(atkObject);
/* 1197 */     long parentResult = 0L;
/* 1198 */     AtkObjectClass objectClass = getParentAtkObjectClass(atkObject);
/* 1199 */     if (objectClass.get_description != 0L) {
/* 1200 */       parentResult = ATK.call(objectClass.get_description, atkObject);
/*      */     }
/* 1202 */     if (object != null) {
/* 1203 */       Accessible accessible = object.accessible;
/* 1204 */       List<AccessibleListener> listeners = accessible.accessibleListeners;
/* 1205 */       int length = size(listeners);
/* 1206 */       if (length > 0) {
/* 1207 */         AccessibleEvent event = new AccessibleEvent(accessible);
/* 1208 */         event.childID = object.id;
/* 1209 */         if (parentResult != 0L) event.result = getString(parentResult);
/* 1210 */         for (int i = 0; i < length; i++) {
/* 1211 */           AccessibleListener listener = (AccessibleListener)listeners.get(i);
/* 1212 */           listener.getDescription(event);
/*      */         }
/* 1214 */         if (event.result == null) return parentResult;
/* 1215 */         if (descriptionPtr != -1L) OS.g_free(descriptionPtr);
/* 1216 */         return descriptionPtr = getStringPtr(event.result);
/*      */       }
/*      */     }
/* 1219 */     return parentResult;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static long atkObject_get_attributes(long atkObject)
/*      */   {
/* 1237 */     AccessibleObject object = getAccessibleObject(atkObject);
/* 1238 */     long parentResult = 0L;
/* 1239 */     AtkObjectClass objectClass = getParentAtkObjectClass(atkObject);
/* 1240 */     if (objectClass.get_attributes != 0L) {
/* 1241 */       parentResult = ATK.call(objectClass.get_attributes, atkObject);
/*      */     }
/* 1243 */     if (object != null) {
/* 1244 */       Accessible accessible = object.accessible;
/* 1245 */       List<AccessibleAttributeListener> listeners = accessible.accessibleAttributeListeners;
/* 1246 */       int length = size(listeners);
/* 1247 */       if (length > 0) {
/* 1248 */         AccessibleAttributeEvent event = new AccessibleAttributeEvent(accessible);
/* 1249 */         event.topMargin = (event.bottomMargin = event.leftMargin = event.rightMargin = event.alignment = event.indent = event.groupLevel = event.groupCount = event.groupIndex = -1);
/*      */         
/* 1251 */         for (int i = 0; i < length; i++) {
/* 1252 */           AccessibleAttributeListener listener = (AccessibleAttributeListener)listeners.get(i);
/* 1253 */           listener.getAttributes(event);
/*      */         }
/* 1255 */         AtkAttribute attr = new AtkAttribute();
/* 1256 */         if (event.leftMargin != -1) {
/* 1257 */           long attrPtr = OS.g_malloc(AtkAttribute.sizeof);
/* 1258 */           attr.name = OS.g_strdup(ATK.atk_text_attribute_get_name(1));
/* 1259 */           attr.value = getStringPtr(String.valueOf(event.leftMargin));
/* 1260 */           ATK.memmove(attrPtr, attr, AtkAttribute.sizeof);
/* 1261 */           parentResult = OS.g_slist_append(parentResult, attrPtr);
/*      */         }
/* 1263 */         if (event.rightMargin != -1) {
/* 1264 */           long attrPtr = OS.g_malloc(AtkAttribute.sizeof);
/* 1265 */           attr.name = OS.g_strdup(ATK.atk_text_attribute_get_name(2));
/* 1266 */           attr.value = getStringPtr(String.valueOf(event.rightMargin));
/* 1267 */           ATK.memmove(attrPtr, attr, AtkAttribute.sizeof);
/* 1268 */           parentResult = OS.g_slist_append(parentResult, attrPtr);
/*      */         }
/* 1270 */         if (event.topMargin != -1) {
/* 1271 */           long attrPtr = OS.g_malloc(AtkAttribute.sizeof);
/* 1272 */           attr.name = getStringPtr("top-margin");
/* 1273 */           attr.value = getStringPtr(String.valueOf(event.topMargin));
/* 1274 */           ATK.memmove(attrPtr, attr, AtkAttribute.sizeof);
/* 1275 */           parentResult = OS.g_slist_append(parentResult, attrPtr);
/*      */         }
/* 1277 */         if (event.bottomMargin != -1) {
/* 1278 */           long attrPtr = OS.g_malloc(AtkAttribute.sizeof);
/* 1279 */           attr.name = getStringPtr("bottom-margin");
/* 1280 */           attr.value = getStringPtr(String.valueOf(event.bottomMargin));
/* 1281 */           ATK.memmove(attrPtr, attr, AtkAttribute.sizeof);
/* 1282 */           parentResult = OS.g_slist_append(parentResult, attrPtr);
/*      */         }
/* 1284 */         if (event.indent != -1) {
/* 1285 */           long attrPtr = OS.g_malloc(AtkAttribute.sizeof);
/* 1286 */           attr.name = OS.g_strdup(ATK.atk_text_attribute_get_name(3));
/* 1287 */           attr.value = getStringPtr(String.valueOf(event.indent));
/* 1288 */           ATK.memmove(attrPtr, attr, AtkAttribute.sizeof);
/* 1289 */           parentResult = OS.g_slist_append(parentResult, attrPtr);
/*      */         }
/* 1291 */         if (event.justify) {
/* 1292 */           long attrPtr = OS.g_malloc(AtkAttribute.sizeof);
/* 1293 */           attr.name = OS.g_strdup(ATK.atk_text_attribute_get_name(24));
/* 1294 */           attr.value = getStringPtr("fill");
/* 1295 */           ATK.memmove(attrPtr, attr, AtkAttribute.sizeof);
/* 1296 */           parentResult = OS.g_slist_append(parentResult, attrPtr);
/* 1297 */         } else if (event.alignment != -1) {
/* 1298 */           long attrPtr = OS.g_malloc(AtkAttribute.sizeof);
/* 1299 */           attr.name = OS.g_strdup(ATK.atk_text_attribute_get_name(24));
/* 1300 */           String str = "left";
/* 1301 */           switch (event.alignment) {
/* 1302 */           case 16384:  str = "left"; break;
/* 1303 */           case 131072:  str = "right"; break;
/* 1304 */           case 16777216:  str = "center";
/*      */           }
/* 1306 */           attr.value = getStringPtr(str);
/* 1307 */           ATK.memmove(attrPtr, attr, AtkAttribute.sizeof);
/* 1308 */           parentResult = OS.g_slist_append(parentResult, attrPtr);
/*      */         }
/*      */         
/*      */ 
/*      */ 
/* 1313 */         int level = event.groupLevel != -1 ? event.groupLevel : 0;
/* 1314 */         int setsize = event.groupCount != -1 ? event.groupCount : 0;
/* 1315 */         int posinset = event.groupIndex != -1 ? event.groupIndex : 0;
/* 1316 */         if ((setsize == 0) && (posinset == 0))
/*      */         {
/* 1318 */           org.eclipse.swt.widgets.Control control = accessible.control;
/* 1319 */           if (((control instanceof org.eclipse.swt.widgets.Button)) && ((control.getStyle() & 0x10) != 0)) {
/* 1320 */             org.eclipse.swt.widgets.Control[] children = control.getParent().getChildren();
/* 1321 */             posinset = 1;
/* 1322 */             setsize = 1;
/* 1323 */             for (int i = 0; i < children.length; i++) {
/* 1324 */               org.eclipse.swt.widgets.Control child = children[i];
/* 1325 */               if (((child instanceof org.eclipse.swt.widgets.Button)) && ((child.getStyle() & 0x10) != 0)) {
/* 1326 */                 if (child == control) posinset = setsize; else
/* 1327 */                   setsize++;
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/* 1332 */         if (level != 0) {
/* 1333 */           long attrPtr = OS.g_malloc(AtkAttribute.sizeof);
/* 1334 */           attr.name = getStringPtr("level");
/* 1335 */           attr.value = getStringPtr(String.valueOf(level));
/* 1336 */           ATK.memmove(attrPtr, attr, AtkAttribute.sizeof);
/* 1337 */           parentResult = OS.g_slist_append(parentResult, attrPtr);
/*      */         }
/* 1339 */         if (setsize != 0) {
/* 1340 */           long attrPtr = OS.g_malloc(AtkAttribute.sizeof);
/* 1341 */           attr.name = getStringPtr("setsize");
/* 1342 */           attr.value = getStringPtr(String.valueOf(setsize));
/* 1343 */           ATK.memmove(attrPtr, attr, AtkAttribute.sizeof);
/* 1344 */           parentResult = OS.g_slist_append(parentResult, attrPtr);
/*      */         }
/* 1346 */         if (posinset != 0) {
/* 1347 */           long attrPtr = OS.g_malloc(AtkAttribute.sizeof);
/* 1348 */           attr.name = getStringPtr("posinset");
/* 1349 */           attr.value = getStringPtr(String.valueOf(posinset));
/* 1350 */           ATK.memmove(attrPtr, attr, AtkAttribute.sizeof);
/* 1351 */           parentResult = OS.g_slist_append(parentResult, attrPtr);
/*      */         }
/*      */         
/* 1354 */         if (event.attributes != null) {
/* 1355 */           int end = event.attributes.length / 2 * 2;
/* 1356 */           for (int i = 0; i < end; i += 2) {
/* 1357 */             long attrPtr = OS.g_malloc(AtkAttribute.sizeof);
/* 1358 */             attr.name = getStringPtr(event.attributes[i]);
/* 1359 */             attr.value = getStringPtr(event.attributes[(i + 1)]);
/* 1360 */             ATK.memmove(attrPtr, attr, AtkAttribute.sizeof);
/* 1361 */             parentResult = OS.g_slist_append(parentResult, attrPtr);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/* 1366 */     return parentResult;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static long atkObject_get_name(long atkObject)
/*      */   {
/* 1383 */     AccessibleObject object = getAccessibleObject(atkObject);
/* 1384 */     long parentResult = 0L;
/* 1385 */     AtkObjectClass objectClass = getParentAtkObjectClass(atkObject);
/* 1386 */     if (objectClass.get_name != 0L) {
/* 1387 */       parentResult = ATK.call(objectClass.get_name, atkObject);
/*      */     }
/* 1389 */     if (object != null) {
/* 1390 */       Accessible accessible = object.accessible;
/* 1391 */       List<AccessibleListener> listeners = accessible.accessibleListeners;
/* 1392 */       int length = size(listeners);
/* 1393 */       if (length > 0) {
/* 1394 */         AccessibleEvent event = new AccessibleEvent(accessible);
/* 1395 */         event.childID = object.id;
/* 1396 */         if (parentResult != 0L) event.result = getString(parentResult);
/* 1397 */         for (int i = 0; i < length; i++) {
/* 1398 */           AccessibleListener listener = (AccessibleListener)listeners.get(i);
/* 1399 */           listener.getName(event);
/*      */         }
/* 1401 */         if (event.result == null) return parentResult;
/* 1402 */         if (namePtr != -1L) OS.g_free(namePtr);
/* 1403 */         return namePtr = getStringPtr(event.result);
/*      */       }
/*      */     }
/* 1406 */     return parentResult;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static long atkObject_get_n_children(long atkObject)
/*      */   {
/* 1424 */     AccessibleObject object = getAccessibleObject(atkObject);
/* 1425 */     long parentResult = 0L;
/* 1426 */     AtkObjectClass objectClass = getParentAtkObjectClass(atkObject);
/* 1427 */     if (objectClass.get_n_children != 0L) {
/* 1428 */       parentResult = ATK.call(objectClass.get_n_children, atkObject);
/*      */     }
/* 1430 */     if ((object != null) && (object.id == -1)) {
/* 1431 */       Accessible accessible = object.accessible;
/* 1432 */       List<AccessibleControlListener> listeners = accessible.accessibleControlListeners;
/* 1433 */       int length = size(listeners);
/* 1434 */       if (length > 0) {
/* 1435 */         AccessibleControlEvent event = new AccessibleControlEvent(accessible);
/* 1436 */         event.childID = object.id;
/* 1437 */         event.detail = ((int)parentResult);
/* 1438 */         for (int i = 0; i < length; i++) {
/* 1439 */           AccessibleControlListener listener = (AccessibleControlListener)listeners.get(i);
/* 1440 */           listener.getChildCount(event);
/*      */         }
/* 1442 */         return event.detail;
/*      */       }
/*      */     }
/* 1445 */     return parentResult;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static long atkObject_get_index_in_parent(long atkObject)
/*      */   {
/* 1463 */     AccessibleObject object = getAccessibleObject(atkObject);
/* 1464 */     if (object != null) {
/* 1465 */       Accessible accessible = object.accessible;
/* 1466 */       List<AccessibleControlListener> listeners = accessible.accessibleControlListeners;
/* 1467 */       AccessibleControlEvent event = new AccessibleControlEvent(accessible);
/* 1468 */       event.childID = -5;
/* 1469 */       event.detail = -1;
/* 1470 */       for (int i = 0; i < size(listeners); i++) {
/* 1471 */         AccessibleControlListener listener = (AccessibleControlListener)listeners.get(i);
/* 1472 */         listener.getChild(event);
/*      */       }
/* 1474 */       if (event.detail != -1) {
/* 1475 */         return event.detail;
/*      */       }
/* 1477 */       if (object.index != -1) {
/* 1478 */         return object.index;
/*      */       }
/*      */     }
/* 1481 */     AtkObjectClass objectClass = getParentAtkObjectClass(atkObject);
/* 1482 */     if (objectClass.get_index_in_parent == 0L) return 0L;
/* 1483 */     long result = ATK.call(objectClass.get_index_in_parent, atkObject);
/* 1484 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static long atkObject_get_parent(long atkObject)
/*      */   {
/* 1502 */     AccessibleObject object = getAccessibleObject(atkObject);
/* 1503 */     if ((object != null) && 
/* 1504 */       (object.parent != null)) {
/* 1505 */       return object.parent.atkHandle;
/*      */     }
/*      */     
/* 1508 */     AtkObjectClass objectClass = getParentAtkObjectClass(atkObject);
/* 1509 */     if (objectClass.get_parent == 0L) return 0L;
/* 1510 */     long parentResult = ATK.call(objectClass.get_parent, atkObject);
/* 1511 */     return parentResult;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static long atkObject_get_role(long atkObject)
/*      */   {
/* 1527 */     AccessibleObject object = getAccessibleObject(atkObject);
/* 1528 */     if (object != null) {
/* 1529 */       Accessible accessible = object.accessible;
/* 1530 */       List<AccessibleControlListener> listeners = accessible.accessibleControlListeners;
/* 1531 */       int length = size(listeners);
/* 1532 */       if (length > 0) {
/* 1533 */         AccessibleControlEvent event = new AccessibleControlEvent(accessible);
/* 1534 */         event.childID = object.id;
/* 1535 */         event.detail = -1;
/* 1536 */         for (int i = 0; i < length; i++) {
/* 1537 */           AccessibleControlListener listener = (AccessibleControlListener)listeners.get(i);
/* 1538 */           listener.getRole(event);
/*      */         }
/* 1540 */         if (event.detail != -1) {
/* 1541 */           switch (event.detail) {
/*      */           case 44: 
/* 1543 */             return 7L;
/* 1544 */           case 10:  return 18L;
/* 1545 */           case 46:  return 11L;
/* 1546 */           case 18:  return 16L;
/* 1547 */           case 41:  return 28L;
/* 1548 */           case 30:  return 60L;
/* 1549 */           case 33:  return 30L;
/* 1550 */           case 34:  return 31L;
/* 1551 */           case 11:  return 32L;
/* 1552 */           case 2:  return 33L;
/* 1553 */           case 12:  return 34L;
/* 1554 */           case 48:  return 41L;
/* 1555 */           case 43:  return 42L;
/* 1556 */           case 3:  return 47L;
/* 1557 */           case 21:  return 49L;
/* 1558 */           case 51:  return 50L;
/* 1559 */           case 24:  return 54L;
/* 1560 */           case 29:  return 55L;
/* 1561 */           case 25:  return 56L;
/* 1562 */           case 26:  return 57L;
/* 1563 */           case 60:  return 37L;
/* 1564 */           case 37:  return 36L;
/* 1565 */           case 42:  return 60L;
/* 1566 */           case 22:  return 62L;
/* 1567 */           case 13:  return 63L;
/* 1568 */           case 35:  return 64L;
/* 1569 */           case 36:  return 31L;
/* 1570 */           case 45:  return 43L;
/* 1571 */           case 62:  return 42L;
/* 1572 */           case 9:  return 68L;
/* 1573 */           case 28:  return ROW_ROLE;
/* 1574 */           case 27:  return 66L;
/* 1575 */           case 8:  return 2L;
/* 1576 */           case 54:  return 3L;
/* 1577 */           case 1025:  return 6L;
/* 1578 */           case 20:  return 38L;
/* 1579 */           case 52:  return 52L;
/* 1580 */           case 23:  return 53L;
/* 1581 */           case 1027:  return 8L;
/* 1582 */           case 1073:  return 44L;
/* 1583 */           case 61:  return 66L;
/* 1584 */           case 47:  return 4L;
/* 1585 */           case 1029:  return 12L;
/* 1586 */           case 1038:  return 70L;
/* 1587 */           case 1040:  return 85L;
/* 1588 */           case 1043:  return 69L;
/* 1589 */           case 1044:  return 81L;
/* 1590 */           case 1053:  return 82L;
/* 1591 */           case 1054:  return 71L;
/* 1592 */           case 1060:  return 83L;
/* 1593 */           case 15:  return 80L;
/* 1594 */           case 40:  return 26L;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/* 1599 */     AtkObjectClass objectClass = getParentAtkObjectClass(atkObject);
/* 1600 */     if (objectClass.get_role == 0L) return 0L;
/* 1601 */     return ATK.call(objectClass.get_role, atkObject);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static long atkObject_ref_child(long atkObject, long index)
/*      */   {
/* 1618 */     AccessibleObject object = getAccessibleObject(atkObject);
/* 1619 */     if ((object != null) && (object.id == -1)) {
/* 1620 */       Accessible accessible = object.accessible;
/* 1621 */       List<AccessibleControlListener> listeners = accessible.accessibleControlListeners;
/* 1622 */       int length = size(listeners);
/* 1623 */       if (length > 0) {
/* 1624 */         AccessibleControlEvent event = new AccessibleControlEvent(accessible);
/* 1625 */         event.childID = -4;
/* 1626 */         event.detail = ((int)index);
/* 1627 */         for (int i = 0; i < length; i++) {
/* 1628 */           AccessibleControlListener listener = (AccessibleControlListener)listeners.get(i);
/* 1629 */           listener.getChild(event);
/*      */         }
/* 1631 */         if (event.accessible != null) {
/* 1632 */           AccessibleObject accObject = event.accessible.getAccessibleObject();
/* 1633 */           if (accObject != null) {
/* 1634 */             return OS.g_object_ref(accObject.atkHandle);
/*      */           }
/*      */         }
/*      */       }
/* 1638 */       object.updateChildren();
/* 1639 */       AccessibleObject accObject = object.getChildByIndex((int)index);
/* 1640 */       if (accObject != null) {
/* 1641 */         return OS.g_object_ref(accObject.atkHandle);
/*      */       }
/*      */     }
/* 1644 */     AtkObjectClass objectClass = getParentAtkObjectClass(atkObject);
/* 1645 */     if (objectClass.ref_child == 0L) return 0L;
/* 1646 */     return ATK.call(objectClass.ref_child, atkObject, index);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static long atkObject_ref_state_set(long atkObject)
/*      */   {
/* 1663 */     AccessibleObject object = getAccessibleObject(atkObject);
/* 1664 */     long parentResult = 0L;
/* 1665 */     AtkObjectClass objectClass = getParentAtkObjectClass(atkObject);
/* 1666 */     if (objectClass.ref_state_set != 0L) {
/* 1667 */       parentResult = ATK.call(objectClass.ref_state_set, atkObject);
/*      */     }
/* 1669 */     if (object != null) {
/* 1670 */       Accessible accessible = object.accessible;
/* 1671 */       List<AccessibleControlListener> listeners = accessible.accessibleControlListeners;
/* 1672 */       int length = size(listeners);
/* 1673 */       if (length > 0) {
/* 1674 */         long set = parentResult;
/* 1675 */         AccessibleControlEvent event = new AccessibleControlEvent(accessible);
/* 1676 */         event.childID = object.id;
/* 1677 */         event.detail = -1;
/* 1678 */         for (int i = 0; i < length; i++) {
/* 1679 */           AccessibleControlListener listener = (AccessibleControlListener)listeners.get(i);
/* 1680 */           listener.getState(event);
/*      */         }
/* 1682 */         if (event.detail != -1)
/*      */         {
/* 1684 */           int state = event.detail;
/* 1685 */           if ((state & 0x800) != 0) ATK.atk_state_set_add_state(set, 3);
/* 1686 */           if ((state & 0x10) != 0) ATK.atk_state_set_add_state(set, 4);
/* 1687 */           if ((state & 0x200) != 0) ATK.atk_state_set_add_state(set, 9);
/* 1688 */           if ((state & 0x100000) != 0) ATK.atk_state_set_add_state(set, 10);
/* 1689 */           if ((state & 0x4) != 0) ATK.atk_state_set_add_state(set, 11);
/* 1690 */           if ((state & 0x80) != 0) ATK.atk_state_set_add_state(set, 2);
/* 1691 */           if ((state & 0x8000) == 0) ATK.atk_state_set_add_state(set, 28);
/* 1692 */           if ((state & 0x1000000) != 0) ATK.atk_state_set_add_state(set, 16);
/* 1693 */           if ((state & 0x10000) == 0) ATK.atk_state_set_add_state(set, 23);
/* 1694 */           if ((state & 0x8) != 0) ATK.atk_state_set_add_state(set, 18);
/* 1695 */           if ((state & 0x40) == 0) ATK.atk_state_set_add_state(set, 6);
/* 1696 */           if ((state & 0x200000) != 0) ATK.atk_state_set_add_state(set, 20);
/* 1697 */           if ((state & 0x2) != 0) ATK.atk_state_set_add_state(set, 21);
/* 1698 */           if ((state & 0x20000) != 0) ATK.atk_state_set_add_state(set, 19);
/* 1699 */           if ((state & 0x1) == 0) ATK.atk_state_set_add_state(set, 7);
/* 1700 */           if ((state & 0x4000000) != 0) ATK.atk_state_set_add_state(set, 1);
/* 1701 */           if ((state & 0x8000000) != 0) ATK.atk_state_set_add_state(set, 24);
/* 1702 */           if ((state & 0x10000000) != 0) ATK.atk_state_set_add_state(set, 15);
/* 1703 */           if ((state & 0x2000000) != 0) ATK.atk_state_set_add_state(set, 32);
/* 1704 */           if ((state & 0x20000000) != 0) ATK.atk_state_set_add_state(set, 33);
/* 1705 */           if ((state & 0x40000000) != 0) { ATK.atk_state_set_add_state(set, 34);
/*      */           }
/*      */         }
/* 1708 */         return set;
/*      */       }
/*      */     }
/* 1711 */     return parentResult;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static org.eclipse.swt.internal.accessibility.gtk.AtkSelectionIface getParentSelectionIface(long atkObject)
/*      */   {
/* 1725 */     long type = GTK.GTK3 ? OS.swt_fixed_accessible_get_type() : OS.G_OBJECT_TYPE(atkObject);
/* 1726 */     if (OS.g_type_is_a(OS.g_type_parent(type), ATK.ATK_TYPE_SELECTION())) {
/* 1727 */       org.eclipse.swt.internal.accessibility.gtk.AtkSelectionIface iface = new org.eclipse.swt.internal.accessibility.gtk.AtkSelectionIface();
/* 1728 */       ATK.memmove(iface, OS.g_type_interface_peek_parent(ATK.ATK_SELECTION_GET_IFACE(atkObject)));
/* 1729 */       return iface;
/*      */     }
/* 1731 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static long atkSelection_is_child_selected(long atkObject, long index)
/*      */   {
/* 1748 */     AccessibleObject object = getAccessibleObject(atkObject);
/* 1749 */     long parentResult = 0L;
/* 1750 */     org.eclipse.swt.internal.accessibility.gtk.AtkSelectionIface iface = getParentSelectionIface(atkObject);
/* 1751 */     if ((iface != null) && (iface.is_child_selected != 0L)) {
/* 1752 */       parentResult = ATK.call(iface.is_child_selected, atkObject, index);
/*      */     }
/* 1754 */     if (object != null) {
/* 1755 */       Accessible accessible = object.accessible;
/* 1756 */       List<AccessibleControlListener> listeners = accessible.accessibleControlListeners;
/* 1757 */       int length = size(listeners);
/* 1758 */       if (length > 0) {
/* 1759 */         AccessibleControlEvent event = new AccessibleControlEvent(accessible);
/* 1760 */         event.childID = object.id;
/* 1761 */         for (int i = 0; i < length; i++) {
/* 1762 */           AccessibleControlListener listener = (AccessibleControlListener)listeners.get(i);
/* 1763 */           listener.getSelection(event);
/*      */         }
/* 1765 */         Accessible result = event.accessible;
/* 1766 */         AccessibleObject accessibleObject = result != null ? result.getAccessibleObject() : object.getChildByID(event.childID);
/* 1767 */         if (accessibleObject != null) {
/* 1768 */           return accessibleObject.index == index ? 1L : 0L;
/*      */         }
/*      */       }
/*      */     }
/* 1772 */     return parentResult;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static long atkSelection_ref_selection(long atkObject, long index)
/*      */   {
/* 1791 */     AccessibleObject object = getAccessibleObject(atkObject);
/* 1792 */     long parentResult = 0L;
/* 1793 */     org.eclipse.swt.internal.accessibility.gtk.AtkSelectionIface iface = getParentSelectionIface(atkObject);
/* 1794 */     if ((iface != null) && (iface.ref_selection != 0L)) {
/* 1795 */       parentResult = ATK.call(iface.ref_selection, atkObject, index);
/*      */     }
/* 1797 */     if (object != null) {
/* 1798 */       Accessible accessible = object.accessible;
/* 1799 */       List<AccessibleControlListener> listeners = accessible.accessibleControlListeners;
/* 1800 */       int length = size(listeners);
/* 1801 */       if (length > 0) {
/* 1802 */         AccessibleControlEvent event = new AccessibleControlEvent(accessible);
/* 1803 */         event.childID = object.id;
/* 1804 */         for (int i = 0; i < length; i++) {
/* 1805 */           AccessibleControlListener listener = (AccessibleControlListener)listeners.get(i);
/* 1806 */           listener.getSelection(event);
/*      */         }
/* 1808 */         AccessibleObject accObj = object.getChildByID(event.childID);
/* 1809 */         if (accObj != null) {
/* 1810 */           if (parentResult != 0L) OS.g_object_unref(parentResult);
/* 1811 */           OS.g_object_ref(accObj.atkHandle);
/* 1812 */           return accObj.atkHandle;
/*      */         }
/*      */       }
/*      */     }
/* 1816 */     return parentResult;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static AtkTableIface getParentTableIface(long atkObject)
/*      */   {
/* 1830 */     long type = GTK.GTK3 ? OS.swt_fixed_accessible_get_type() : OS.G_OBJECT_TYPE(atkObject);
/* 1831 */     if (OS.g_type_is_a(OS.g_type_parent(type), ATK.ATK_TYPE_TABLE())) {
/* 1832 */       AtkTableIface iface = new AtkTableIface();
/* 1833 */       ATK.memmove(iface, OS.g_type_interface_peek_parent(ATK.ATK_TABLE_GET_IFACE(atkObject)));
/* 1834 */       return iface;
/*      */     }
/* 1836 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static long atkTable_ref_at(long atkObject, long row, long column)
/*      */   {
/* 1854 */     AccessibleObject object = getAccessibleObject(atkObject);
/* 1855 */     if (object != null) {
/* 1856 */       Accessible accessible = object.accessible;
/* 1857 */       List<AccessibleTableListener> listeners = accessible.accessibleTableListeners;
/* 1858 */       int length = size(listeners);
/* 1859 */       if (length > 0) {
/* 1860 */         AccessibleTableEvent event = new AccessibleTableEvent(accessible);
/* 1861 */         event.row = ((int)row);
/* 1862 */         event.column = ((int)column);
/* 1863 */         for (int i = 0; i < length; i++) {
/* 1864 */           AccessibleTableListener listener = (AccessibleTableListener)listeners.get(i);
/* 1865 */           listener.getCell(event);
/*      */         }
/* 1867 */         Accessible result = event.accessible;
/* 1868 */         if (result != null) {
/* 1869 */           AccessibleObject accessibleObject = result.getAccessibleObject();
/* 1870 */           OS.g_object_ref(accessibleObject.atkHandle);
/* 1871 */           return accessibleObject.atkHandle;
/*      */         }
/*      */       }
/*      */     }
/* 1875 */     long parentResult = 0L;
/* 1876 */     AtkTableIface iface = getParentTableIface(atkObject);
/* 1877 */     if ((iface != null) && (iface.ref_at != 0L)) {
/* 1878 */       parentResult = ATK.call(iface.ref_at, atkObject, row, column);
/*      */     }
/* 1880 */     return parentResult;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static long atkTable_get_index_at(long atkObject, long row, long column)
/*      */   {
/* 1898 */     AccessibleObject object = getAccessibleObject(atkObject);
/* 1899 */     if (object != null) {
/* 1900 */       Accessible accessible = object.accessible;
/* 1901 */       List<AccessibleTableListener> listeners = accessible.accessibleTableListeners;
/* 1902 */       int length = size(listeners);
/* 1903 */       if (length > 0) {
/* 1904 */         AccessibleTableEvent event = new AccessibleTableEvent(accessible);
/* 1905 */         event.row = ((int)row);
/* 1906 */         event.column = ((int)column);
/* 1907 */         for (int i = 0; i < length; i++) {
/* 1908 */           AccessibleTableListener listener = (AccessibleTableListener)listeners.get(i);
/* 1909 */           listener.getCell(event);
/*      */         }
/* 1911 */         Accessible result = event.accessible;
/* 1912 */         if (result == null) return -1L;
/* 1913 */         event = new AccessibleTableEvent(accessible);
/* 1914 */         for (int i = 0; i < length; i++) {
/* 1915 */           AccessibleTableListener listener = (AccessibleTableListener)listeners.get(i);
/* 1916 */           listener.getColumnCount(event);
/*      */         }
/* 1918 */         return row * event.count + column;
/*      */       }
/*      */     }
/* 1921 */     long parentResult = 0L;
/* 1922 */     AtkTableIface iface = getParentTableIface(atkObject);
/* 1923 */     if ((iface != null) && (iface.get_index_at != 0L)) {
/* 1924 */       parentResult = ATK.call(iface.get_index_at, atkObject, row, column);
/*      */     }
/* 1926 */     return parentResult;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static long atkTable_get_column_at_index(long atkObject, long index)
/*      */   {
/* 1944 */     AccessibleObject object = getAccessibleObject(atkObject);
/* 1945 */     if (object != null) {
/* 1946 */       Accessible accessible = object.accessible;
/* 1947 */       List<AccessibleTableListener> listeners = accessible.accessibleTableListeners;
/* 1948 */       int length = size(listeners);
/* 1949 */       if (length > 0) {
/* 1950 */         AccessibleTableEvent event = new AccessibleTableEvent(accessible);
/* 1951 */         for (int i = 0; i < length; i++) {
/* 1952 */           AccessibleTableListener listener = (AccessibleTableListener)listeners.get(i);
/* 1953 */           listener.getColumnCount(event);
/*      */         }
/* 1955 */         long result = event.count == 0 ? -1L : index % event.count;
/* 1956 */         return result;
/*      */       }
/*      */     }
/* 1959 */     long parentResult = 0L;
/* 1960 */     AtkTableIface iface = getParentTableIface(atkObject);
/* 1961 */     if ((iface != null) && (iface.get_column_at_index != 0L)) {
/* 1962 */       parentResult = ATK.call(iface.get_column_at_index, atkObject, index);
/*      */     }
/* 1964 */     return parentResult;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static long atkTable_get_row_at_index(long atkObject, long index)
/*      */   {
/* 1982 */     AccessibleObject object = getAccessibleObject(atkObject);
/* 1983 */     if (object != null) {
/* 1984 */       Accessible accessible = object.accessible;
/* 1985 */       List<AccessibleTableListener> listeners = accessible.accessibleTableListeners;
/* 1986 */       int length = size(listeners);
/* 1987 */       if (length > 0) {
/* 1988 */         AccessibleTableEvent event = new AccessibleTableEvent(accessible);
/* 1989 */         for (int i = 0; i < length; i++) {
/* 1990 */           AccessibleTableListener listener = (AccessibleTableListener)listeners.get(i);
/* 1991 */           listener.getColumnCount(event);
/*      */         }
/* 1993 */         long result = event.count == 0 ? -1L : index / event.count;
/* 1994 */         return result;
/*      */       }
/*      */     }
/* 1997 */     long parentResult = 0L;
/* 1998 */     AtkTableIface iface = getParentTableIface(atkObject);
/* 1999 */     if ((iface != null) && (iface.get_row_at_index != 0L)) {
/* 2000 */       parentResult = ATK.call(iface.get_row_at_index, atkObject, index);
/*      */     }
/* 2002 */     return parentResult;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static long atkTable_get_n_columns(long atkObject)
/*      */   {
/* 2019 */     AccessibleObject object = getAccessibleObject(atkObject);
/* 2020 */     long parentResult = 0L;
/* 2021 */     AtkTableIface iface = getParentTableIface(atkObject);
/* 2022 */     if ((iface != null) && (iface.get_n_columns != 0L)) {
/* 2023 */       parentResult = ATK.call(iface.get_n_columns, atkObject);
/*      */     }
/* 2025 */     if (object != null) {
/* 2026 */       Accessible accessible = object.accessible;
/* 2027 */       List<AccessibleTableListener> listeners = accessible.accessibleTableListeners;
/* 2028 */       int length = size(listeners);
/* 2029 */       if (length > 0) {
/* 2030 */         AccessibleTableEvent event = new AccessibleTableEvent(accessible);
/* 2031 */         event.count = ((int)parentResult);
/* 2032 */         for (int i = 0; i < length; i++) {
/* 2033 */           AccessibleTableListener listener = (AccessibleTableListener)listeners.get(i);
/* 2034 */           listener.getColumnCount(event);
/* 2035 */           parentResult = event.count;
/*      */         }
/*      */       }
/*      */     }
/* 2039 */     return parentResult;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static long atkTable_get_n_rows(long atkObject)
/*      */   {
/* 2056 */     AccessibleObject object = getAccessibleObject(atkObject);
/* 2057 */     long parentResult = 0L;
/* 2058 */     AtkTableIface iface = getParentTableIface(atkObject);
/* 2059 */     if ((iface != null) && (iface.get_n_rows != 0L)) {
/* 2060 */       parentResult = ATK.call(iface.get_n_rows, atkObject);
/*      */     }
/* 2062 */     if (object != null) {
/* 2063 */       Accessible accessible = object.accessible;
/* 2064 */       List<AccessibleTableListener> listeners = accessible.accessibleTableListeners;
/* 2065 */       int length = size(listeners);
/* 2066 */       if (length > 0) {
/* 2067 */         AccessibleTableEvent event = new AccessibleTableEvent(accessible);
/* 2068 */         event.count = ((int)parentResult);
/* 2069 */         for (int i = 0; i < length; i++) {
/* 2070 */           AccessibleTableListener listener = (AccessibleTableListener)listeners.get(i);
/* 2071 */           listener.getRowCount(event);
/* 2072 */           parentResult = event.count;
/*      */         }
/*      */       }
/*      */     }
/* 2076 */     return parentResult;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static long atkTable_get_column_extent_at(long atkObject, long row, long column)
/*      */   {
/* 2096 */     AccessibleObject object = getAccessibleObject(atkObject);
/* 2097 */     long parentResult = 0L;
/* 2098 */     AtkTableIface iface = getParentTableIface(atkObject);
/* 2099 */     if ((iface != null) && (iface.get_column_extent_at != 0L)) {
/* 2100 */       parentResult = ATK.call(iface.get_column_extent_at, atkObject, row, column);
/*      */     }
/* 2102 */     if (object != null) {
/* 2103 */       Accessible accessible = object.accessible;
/* 2104 */       List<AccessibleTableListener> listeners = accessible.accessibleTableListeners;
/* 2105 */       int length = size(listeners);
/* 2106 */       if (length > 0) {
/* 2107 */         AccessibleTableEvent event = new AccessibleTableEvent(accessible);
/* 2108 */         event.row = ((int)row);
/* 2109 */         event.column = ((int)column);
/* 2110 */         for (int i = 0; i < length; i++) {
/* 2111 */           AccessibleTableListener listener = (AccessibleTableListener)listeners.get(i);
/* 2112 */           listener.getCell(event);
/*      */         }
/* 2114 */         Accessible result = event.accessible;
/* 2115 */         if (result != null) {
/* 2116 */           List<AccessibleTableCellListener> listeners2 = result.accessibleTableCellListeners;
/* 2117 */           length = size(listeners2);
/* 2118 */           if (length > 0) {
/* 2119 */             AccessibleTableCellEvent cellEvent = new AccessibleTableCellEvent(result);
/* 2120 */             cellEvent.count = ((int)parentResult);
/* 2121 */             for (int i = 0; i < length; i++) {
/* 2122 */               AccessibleTableCellListener listener = (AccessibleTableCellListener)listeners2.get(i);
/* 2123 */               listener.getColumnSpan(cellEvent);
/*      */             }
/* 2125 */             return cellEvent.count;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/* 2130 */     return parentResult;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static long atkTable_get_row_extent_at(long atkObject, long row, long column)
/*      */   {
/* 2150 */     AccessibleObject object = getAccessibleObject(atkObject);
/* 2151 */     long parentResult = 0L;
/* 2152 */     AtkTableIface iface = getParentTableIface(atkObject);
/* 2153 */     if ((iface != null) && (iface.get_row_extent_at != 0L)) {
/* 2154 */       parentResult = ATK.call(iface.get_row_extent_at, atkObject, row, column);
/*      */     }
/* 2156 */     if (object != null) {
/* 2157 */       Accessible accessible = object.accessible;
/* 2158 */       List<AccessibleTableListener> listeners = accessible.accessibleTableListeners;
/* 2159 */       int length = size(listeners);
/* 2160 */       if (length > 0) {
/* 2161 */         AccessibleTableEvent event = new AccessibleTableEvent(accessible);
/* 2162 */         event.row = ((int)row);
/* 2163 */         event.column = ((int)column);
/* 2164 */         for (int i = 0; i < length; i++) {
/* 2165 */           AccessibleTableListener listener = (AccessibleTableListener)listeners.get(i);
/* 2166 */           listener.getCell(event);
/*      */         }
/* 2168 */         Accessible result = event.accessible;
/* 2169 */         if (result != null) {
/* 2170 */           List<AccessibleTableCellListener> listeners2 = result.accessibleTableCellListeners;
/* 2171 */           length = size(listeners2);
/* 2172 */           if (length > 0) {
/* 2173 */             AccessibleTableCellEvent cellEvent = new AccessibleTableCellEvent(result);
/* 2174 */             cellEvent.count = ((int)parentResult);
/* 2175 */             for (int i = 0; i < length; i++) {
/* 2176 */               AccessibleTableCellListener listener = (AccessibleTableCellListener)listeners2.get(i);
/* 2177 */               listener.getRowSpan(cellEvent);
/*      */             }
/* 2179 */             return cellEvent.count;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/* 2184 */     return parentResult;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static long atkTable_get_caption(long atkObject)
/*      */   {
/* 2200 */     AccessibleObject object = getAccessibleObject(atkObject);
/* 2201 */     if (object != null) {
/* 2202 */       Accessible accessible = object.accessible;
/* 2203 */       List<AccessibleTableListener> listeners = accessible.accessibleTableListeners;
/* 2204 */       int length = size(listeners);
/* 2205 */       if (length > 0) {
/* 2206 */         AccessibleTableEvent event = new AccessibleTableEvent(accessible);
/* 2207 */         for (int i = 0; i < length; i++) {
/* 2208 */           AccessibleTableListener listener = (AccessibleTableListener)listeners.get(i);
/* 2209 */           listener.getCaption(event);
/*      */         }
/* 2211 */         Accessible result = event.accessible;
/* 2212 */         if (result != null) return result.getAccessibleObject().atkHandle;
/*      */       }
/*      */     }
/* 2215 */     long parentResult = 0L;
/* 2216 */     AtkTableIface iface = getParentTableIface(atkObject);
/* 2217 */     if ((iface != null) && (iface.get_caption != 0L)) {
/* 2218 */       parentResult = ATK.call(iface.get_caption, atkObject);
/*      */     }
/* 2220 */     return parentResult;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static long atkTable_get_summary(long atkObject)
/*      */   {
/* 2236 */     AccessibleObject object = getAccessibleObject(atkObject);
/* 2237 */     if (object != null) {
/* 2238 */       Accessible accessible = object.accessible;
/* 2239 */       List<AccessibleTableListener> listeners = accessible.accessibleTableListeners;
/* 2240 */       int length = size(listeners);
/* 2241 */       if (length > 0) {
/* 2242 */         AccessibleTableEvent event = new AccessibleTableEvent(accessible);
/* 2243 */         for (int i = 0; i < length; i++) {
/* 2244 */           AccessibleTableListener listener = (AccessibleTableListener)listeners.get(i);
/* 2245 */           listener.getSummary(event);
/*      */         }
/* 2247 */         Accessible result = event.accessible;
/* 2248 */         if (result != null) return result.getAccessibleObject().atkHandle;
/*      */       }
/*      */     }
/* 2251 */     long parentResult = 0L;
/* 2252 */     AtkTableIface iface = getParentTableIface(atkObject);
/* 2253 */     if ((iface != null) && (iface.get_summary != 0L)) {
/* 2254 */       parentResult = ATK.call(iface.get_summary, atkObject);
/*      */     }
/* 2256 */     return parentResult;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static long atkTable_get_column_description(long atkObject, long column)
/*      */   {
/* 2274 */     AccessibleObject object = getAccessibleObject(atkObject);
/* 2275 */     long parentResult = 0L;
/* 2276 */     AtkTableIface iface = getParentTableIface(atkObject);
/* 2277 */     if ((iface != null) && (iface.get_column_description != 0L)) {
/* 2278 */       parentResult = ATK.call(iface.get_column_description, atkObject, column);
/*      */     }
/* 2280 */     if (object != null) {
/* 2281 */       Accessible accessible = object.accessible;
/* 2282 */       List<AccessibleTableListener> listeners = accessible.accessibleTableListeners;
/* 2283 */       int length = size(listeners);
/* 2284 */       if (length > 0) {
/* 2285 */         AccessibleTableEvent event = new AccessibleTableEvent(accessible);
/* 2286 */         event.column = ((int)column);
/* 2287 */         if (parentResult != 0L) event.result = getString(parentResult);
/* 2288 */         for (int i = 0; i < length; i++) {
/* 2289 */           AccessibleTableListener listener = (AccessibleTableListener)listeners.get(i);
/* 2290 */           listener.getColumnDescription(event);
/*      */         }
/* 2292 */         if (event.result == null) return parentResult;
/* 2293 */         if (descriptionPtr != -1L) OS.g_free(descriptionPtr);
/* 2294 */         return descriptionPtr = getStringPtr(event.result);
/*      */       }
/*      */     }
/* 2297 */     return parentResult;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static long atkTable_get_column_header(long atkObject, long column)
/*      */   {
/* 2315 */     AccessibleObject object = getAccessibleObject(atkObject);
/* 2316 */     if (object != null) {
/* 2317 */       Accessible accessible = object.accessible;
/* 2318 */       List<AccessibleTableListener> listeners = accessible.accessibleTableListeners;
/* 2319 */       int length = size(listeners);
/* 2320 */       if (length > 0) {
/* 2321 */         AccessibleTableEvent event = new AccessibleTableEvent(accessible);
/* 2322 */         for (int i = 0; i < length; i++) {
/* 2323 */           AccessibleTableListener listener = (AccessibleTableListener)listeners.get(i);
/* 2324 */           listener.getRowHeaderCells(event);
/*      */         }
/* 2326 */         Accessible[] accessibles = event.accessibles;
/* 2327 */         if ((accessibles != null) && 
/* 2328 */           (0L <= column) && (column < accessibles.length)) {
/* 2329 */           return accessibles[((int)column)].getAccessibleObject().atkHandle;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 2334 */     long parentResult = 0L;
/* 2335 */     AtkTableIface iface = getParentTableIface(atkObject);
/* 2336 */     if ((iface != null) && (iface.get_column_header != 0L)) {
/* 2337 */       parentResult = ATK.call(iface.get_column_header, atkObject, column);
/*      */     }
/* 2339 */     return parentResult;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static long atkTable_get_row_description(long atkObject, long row)
/*      */   {
/* 2357 */     AccessibleObject object = getAccessibleObject(atkObject);
/* 2358 */     long parentResult = 0L;
/* 2359 */     AtkTableIface iface = getParentTableIface(atkObject);
/* 2360 */     if ((iface != null) && (iface.get_row_description != 0L)) {
/* 2361 */       parentResult = ATK.call(iface.get_row_description, atkObject, row);
/*      */     }
/* 2363 */     if (object != null) {
/* 2364 */       Accessible accessible = object.accessible;
/* 2365 */       List<AccessibleTableListener> listeners = accessible.accessibleTableListeners;
/* 2366 */       int length = size(listeners);
/* 2367 */       if (length > 0) {
/* 2368 */         AccessibleTableEvent event = new AccessibleTableEvent(accessible);
/* 2369 */         event.row = ((int)row);
/* 2370 */         if (parentResult != 0L) event.result = getString(parentResult);
/* 2371 */         for (int i = 0; i < length; i++) {
/* 2372 */           AccessibleTableListener listener = (AccessibleTableListener)listeners.get(i);
/* 2373 */           listener.getRowDescription(event);
/*      */         }
/* 2375 */         if (event.result == null) return parentResult;
/* 2376 */         if (descriptionPtr != -1L) OS.g_free(descriptionPtr);
/* 2377 */         return descriptionPtr = getStringPtr(event.result);
/*      */       }
/*      */     }
/* 2380 */     return parentResult;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static long atkTable_get_row_header(long atkObject, long row)
/*      */   {
/* 2398 */     AccessibleObject object = getAccessibleObject(atkObject);
/* 2399 */     if (object != null) {
/* 2400 */       Accessible accessible = object.accessible;
/* 2401 */       List<AccessibleTableListener> listeners = accessible.accessibleTableListeners;
/* 2402 */       int length = size(listeners);
/* 2403 */       if (length > 0) {
/* 2404 */         AccessibleTableEvent event = new AccessibleTableEvent(accessible);
/* 2405 */         for (int i = 0; i < length; i++) {
/* 2406 */           AccessibleTableListener listener = (AccessibleTableListener)listeners.get(i);
/* 2407 */           listener.getRowHeaderCells(event);
/*      */         }
/* 2409 */         Accessible[] accessibles = event.accessibles;
/* 2410 */         if ((accessibles != null) && 
/* 2411 */           (0L <= row) && (row < accessibles.length)) {
/* 2412 */           return accessibles[((int)row)].getAccessibleObject().atkHandle;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 2417 */     long parentResult = 0L;
/* 2418 */     AtkTableIface iface = getParentTableIface(atkObject);
/* 2419 */     if ((iface != null) && (iface.get_row_header != 0L)) {
/* 2420 */       parentResult = ATK.call(iface.get_row_header, atkObject, row);
/*      */     }
/* 2422 */     return parentResult;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static long atkTable_get_selected_columns(long atkObject, long selected)
/*      */   {
/* 2441 */     AccessibleObject object = getAccessibleObject(atkObject);
/* 2442 */     if (object != null) {
/* 2443 */       Accessible accessible = object.accessible;
/* 2444 */       List<AccessibleTableListener> listeners = accessible.accessibleTableListeners;
/* 2445 */       int length = size(listeners);
/* 2446 */       if (length > 0) {
/* 2447 */         AccessibleTableEvent event = new AccessibleTableEvent(accessible);
/* 2448 */         for (int i = 0; i < length; i++) {
/* 2449 */           AccessibleTableListener listener = (AccessibleTableListener)listeners.get(i);
/* 2450 */           listener.getSelectedColumns(event);
/*      */         }
/* 2452 */         int count = event.selected != null ? event.selected.length : 0;
/* 2453 */         long result = OS.g_malloc(count * 4);
/* 2454 */         if (event.selected != null) C.memmove(result, event.selected, count * 4);
/* 2455 */         if (selected != 0L) C.memmove(selected, new long[] { result }, C.PTR_SIZEOF);
/* 2456 */         return count;
/*      */       }
/*      */     }
/* 2459 */     long parentResult = 0L;
/* 2460 */     AtkTableIface iface = getParentTableIface(atkObject);
/* 2461 */     if ((iface != null) && (iface.get_selected_columns != 0L)) {
/* 2462 */       parentResult = ATK.call(iface.get_selected_columns, atkObject, selected);
/*      */     }
/* 2464 */     return parentResult;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static long atkTable_get_selected_rows(long atkObject, long selected)
/*      */   {
/* 2483 */     AccessibleObject object = getAccessibleObject(atkObject);
/* 2484 */     if (object != null) {
/* 2485 */       Accessible accessible = object.accessible;
/* 2486 */       List<AccessibleTableListener> listeners = accessible.accessibleTableListeners;
/* 2487 */       int length = size(listeners);
/* 2488 */       if (length > 0) {
/* 2489 */         AccessibleTableEvent event = new AccessibleTableEvent(accessible);
/* 2490 */         for (int i = 0; i < length; i++) {
/* 2491 */           AccessibleTableListener listener = (AccessibleTableListener)listeners.get(i);
/* 2492 */           listener.getSelectedRows(event);
/*      */         }
/* 2494 */         int count = event.selected != null ? event.selected.length : 0;
/* 2495 */         long result = OS.g_malloc(count * 4);
/* 2496 */         if (event.selected != null) C.memmove(result, event.selected, count * 4);
/* 2497 */         if (selected != 0L) C.memmove(selected, new long[] { result }, C.PTR_SIZEOF);
/* 2498 */         return count;
/*      */       }
/*      */     }
/* 2501 */     long parentResult = 0L;
/* 2502 */     AtkTableIface iface = getParentTableIface(atkObject);
/* 2503 */     if ((iface != null) && (iface.get_selected_rows != 0L)) {
/* 2504 */       parentResult = ATK.call(iface.get_selected_rows, atkObject, selected);
/*      */     }
/* 2506 */     return parentResult;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static long atkTable_is_column_selected(long atkObject, long column)
/*      */   {
/* 2523 */     AccessibleObject object = getAccessibleObject(atkObject);
/* 2524 */     long parentResult = 0L;
/* 2525 */     AtkTableIface iface = getParentTableIface(atkObject);
/* 2526 */     if ((iface != null) && (iface.is_column_selected != 0L)) {
/* 2527 */       parentResult = ATK.call(iface.is_column_selected, atkObject, column);
/*      */     }
/* 2529 */     if (object != null) {
/* 2530 */       Accessible accessible = object.accessible;
/* 2531 */       List<AccessibleTableListener> listeners = accessible.accessibleTableListeners;
/* 2532 */       int length = size(listeners);
/* 2533 */       if (length > 0) {
/* 2534 */         AccessibleTableEvent event = new AccessibleTableEvent(accessible);
/* 2535 */         event.isSelected = (parentResult != 0L);
/* 2536 */         event.column = ((int)column);
/* 2537 */         for (int i = 0; i < length; i++) {
/* 2538 */           AccessibleTableListener listener = (AccessibleTableListener)listeners.get(i);
/* 2539 */           listener.isColumnSelected(event);
/*      */         }
/* 2541 */         return event.isSelected ? 1L : 0L;
/*      */       }
/*      */     }
/* 2544 */     return parentResult;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static long atkTable_is_row_selected(long atkObject, long row)
/*      */   {
/* 2561 */     AccessibleObject object = getAccessibleObject(atkObject);
/* 2562 */     long parentResult = 0L;
/* 2563 */     AtkTableIface iface = getParentTableIface(atkObject);
/* 2564 */     if ((iface != null) && (iface.is_row_selected != 0L)) {
/* 2565 */       parentResult = ATK.call(iface.is_row_selected, atkObject, row);
/*      */     }
/* 2567 */     if (object != null) {
/* 2568 */       Accessible accessible = object.accessible;
/* 2569 */       List<AccessibleTableListener> listeners = accessible.accessibleTableListeners;
/* 2570 */       int length = size(listeners);
/* 2571 */       if (length > 0) {
/* 2572 */         AccessibleTableEvent event = new AccessibleTableEvent(accessible);
/* 2573 */         event.isSelected = (parentResult != 0L);
/* 2574 */         event.row = ((int)row);
/* 2575 */         for (int i = 0; i < length; i++) {
/* 2576 */           AccessibleTableListener listener = (AccessibleTableListener)listeners.get(i);
/* 2577 */           listener.isRowSelected(event);
/*      */         }
/* 2579 */         return event.isSelected ? 1L : 0L;
/*      */       }
/*      */     }
/* 2582 */     return parentResult;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static long atkTable_is_selected(long atkObject, long row, long column)
/*      */   {
/* 2601 */     AccessibleObject object = getAccessibleObject(atkObject);
/* 2602 */     long parentResult = 0L;
/* 2603 */     AtkTableIface iface = getParentTableIface(atkObject);
/* 2604 */     if ((iface != null) && (iface.is_selected != 0L)) {
/* 2605 */       parentResult = ATK.call(iface.is_selected, atkObject, row, column);
/*      */     }
/* 2607 */     if (object != null) {
/* 2608 */       Accessible accessible = object.accessible;
/* 2609 */       List<AccessibleTableListener> listeners = accessible.accessibleTableListeners;
/* 2610 */       int length = size(listeners);
/* 2611 */       if (length > 0) {
/* 2612 */         AccessibleTableEvent event = new AccessibleTableEvent(accessible);
/* 2613 */         event.row = ((int)row);
/* 2614 */         event.column = ((int)column);
/* 2615 */         for (int i = 0; i < length; i++) {
/* 2616 */           AccessibleTableListener listener = (AccessibleTableListener)listeners.get(i);
/* 2617 */           listener.getCell(event);
/*      */         }
/* 2619 */         Accessible result = event.accessible;
/* 2620 */         if (result != null) {
/* 2621 */           List<AccessibleTableCellListener> listeners2 = result.accessibleTableCellListeners;
/* 2622 */           length = size(listeners2);
/* 2623 */           if (length > 0) {
/* 2624 */             AccessibleTableCellEvent cellEvent = new AccessibleTableCellEvent(result);
/* 2625 */             cellEvent.isSelected = (parentResult != 0L);
/* 2626 */             for (int i = 0; i < length; i++) {
/* 2627 */               AccessibleTableCellListener listener = (AccessibleTableCellListener)listeners2.get(i);
/* 2628 */               listener.isSelected(cellEvent);
/*      */             }
/* 2630 */             return cellEvent.isSelected ? 1L : 0L;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/* 2635 */     return parentResult;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static long atkTable_add_row_selection(long atkObject, long row)
/*      */   {
/* 2653 */     AccessibleObject object = getAccessibleObject(atkObject);
/* 2654 */     if (object != null) {
/* 2655 */       Accessible accessible = object.accessible;
/* 2656 */       List<AccessibleTableListener> listeners = accessible.accessibleTableListeners;
/* 2657 */       int length = size(listeners);
/* 2658 */       if (length > 0) {
/* 2659 */         AccessibleTableEvent event = new AccessibleTableEvent(accessible);
/* 2660 */         event.row = ((int)row);
/* 2661 */         for (int i = 0; i < length; i++) {
/* 2662 */           AccessibleTableListener listener = (AccessibleTableListener)listeners.get(i);
/* 2663 */           listener.selectRow(event);
/*      */         }
/* 2665 */         return "OK".equals(event.result) ? 1L : 0L;
/*      */       }
/*      */     }
/* 2668 */     long parentResult = 0L;
/* 2669 */     AtkTableIface iface = getParentTableIface(atkObject);
/* 2670 */     if ((iface != null) && (iface.add_row_selection != 0L)) {
/* 2671 */       parentResult = ATK.call(iface.add_row_selection, atkObject, row);
/*      */     }
/* 2673 */     return parentResult;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static long atkTable_remove_row_selection(long atkObject, long row)
/*      */   {
/* 2691 */     AccessibleObject object = getAccessibleObject(atkObject);
/* 2692 */     if (object != null) {
/* 2693 */       Accessible accessible = object.accessible;
/* 2694 */       List<AccessibleTableListener> listeners = accessible.accessibleTableListeners;
/* 2695 */       int length = size(listeners);
/* 2696 */       if (length > 0) {
/* 2697 */         AccessibleTableEvent event = new AccessibleTableEvent(accessible);
/* 2698 */         event.row = ((int)row);
/* 2699 */         for (int i = 0; i < length; i++) {
/* 2700 */           AccessibleTableListener listener = (AccessibleTableListener)listeners.get(i);
/* 2701 */           listener.deselectRow(event);
/*      */         }
/* 2703 */         return "OK".equals(event.result) ? 1L : 0L;
/*      */       }
/*      */     }
/* 2706 */     long parentResult = 0L;
/* 2707 */     AtkTableIface iface = getParentTableIface(atkObject);
/* 2708 */     if ((iface != null) && (iface.remove_row_selection != 0L)) {
/* 2709 */       parentResult = ATK.call(iface.remove_row_selection, atkObject, row);
/*      */     }
/* 2711 */     return parentResult;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static long atkTable_add_column_selection(long atkObject, long column)
/*      */   {
/* 2729 */     AccessibleObject object = getAccessibleObject(atkObject);
/* 2730 */     if (object != null) {
/* 2731 */       Accessible accessible = object.accessible;
/* 2732 */       List<AccessibleTableListener> listeners = accessible.accessibleTableListeners;
/* 2733 */       int length = size(listeners);
/* 2734 */       if (length > 0) {
/* 2735 */         AccessibleTableEvent event = new AccessibleTableEvent(accessible);
/* 2736 */         event.column = ((int)column);
/* 2737 */         for (int i = 0; i < length; i++) {
/* 2738 */           AccessibleTableListener listener = (AccessibleTableListener)listeners.get(i);
/* 2739 */           listener.selectColumn(event);
/*      */         }
/* 2741 */         return "OK".equals(event.result) ? 1L : 0L;
/*      */       }
/*      */     }
/* 2744 */     long parentResult = 0L;
/* 2745 */     AtkTableIface iface = getParentTableIface(atkObject);
/* 2746 */     if ((iface != null) && (iface.add_column_selection != 0L)) {
/* 2747 */       parentResult = ATK.call(iface.add_column_selection, atkObject, column);
/*      */     }
/* 2749 */     return parentResult;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static long atkTable_remove_column_selection(long atkObject, long column)
/*      */   {
/* 2767 */     AccessibleObject object = getAccessibleObject(atkObject);
/* 2768 */     if (object != null) {
/* 2769 */       Accessible accessible = object.accessible;
/* 2770 */       List<AccessibleTableListener> listeners = accessible.accessibleTableListeners;
/* 2771 */       int length = size(listeners);
/* 2772 */       if (length > 0) {
/* 2773 */         AccessibleTableEvent event = new AccessibleTableEvent(accessible);
/* 2774 */         event.column = ((int)column);
/* 2775 */         for (int i = 0; i < length; i++) {
/* 2776 */           AccessibleTableListener listener = (AccessibleTableListener)listeners.get(i);
/* 2777 */           listener.deselectColumn(event);
/*      */         }
/* 2779 */         return "OK".equals(event.result) ? 1L : 0L;
/*      */       }
/*      */     }
/* 2782 */     long parentResult = 0L;
/* 2783 */     AtkTableIface iface = getParentTableIface(atkObject);
/* 2784 */     if ((iface != null) && (iface.remove_column_selection != 0L)) {
/* 2785 */       parentResult = ATK.call(iface.remove_column_selection, atkObject, column);
/*      */     }
/* 2787 */     return parentResult;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static AtkTextIface getParentTextIface(long atkObject)
/*      */   {
/* 2801 */     long type = GTK.GTK3 ? OS.swt_fixed_accessible_get_type() : OS.G_OBJECT_TYPE(atkObject);
/* 2802 */     if (OS.g_type_is_a(OS.g_type_parent(type), ATK.ATK_TYPE_TEXT())) {
/* 2803 */       AtkTextIface iface = new AtkTextIface();
/* 2804 */       ATK.memmove(iface, OS.g_type_interface_peek_parent(ATK.ATK_TEXT_GET_IFACE(atkObject)));
/* 2805 */       return iface;
/*      */     }
/* 2807 */     return null;
/*      */   }
/*      */   
/*      */   static String getString(long strPtr) {
/* 2811 */     int length = C.strlen(strPtr);
/* 2812 */     byte[] buffer = new byte[length];
/* 2813 */     C.memmove(buffer, strPtr, length);
/* 2814 */     return new String(org.eclipse.swt.internal.Converter.mbcsToWcs(buffer));
/*      */   }
/*      */   
/*      */   static long getStringPtr(String str) {
/* 2818 */     byte[] buffer = org.eclipse.swt.internal.Converter.wcsToMbcs(str != null ? str : "", true);
/* 2819 */     long ptr = OS.g_malloc(buffer.length);
/* 2820 */     C.memmove(ptr, buffer, buffer.length);
/* 2821 */     return ptr;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static long atkText_get_character_extents(long atkObject, long offset, long x, long y, long width, long height, long coords)
/*      */   {
/* 2847 */     AccessibleObject object = getAccessibleObject(atkObject);
/* 2848 */     if (object != null) {
/* 2849 */       Accessible accessible = object.accessible;
/* 2850 */       List<AccessibleTextExtendedListener> listeners = accessible.accessibleTextExtendedListeners;
/* 2851 */       int length = size(listeners);
/* 2852 */       if (length > 0) {
/* 2853 */         AccessibleTextEvent event = new AccessibleTextEvent(accessible);
/* 2854 */         event.start = ((int)offset);
/* 2855 */         event.end = ((int)(offset + 1L));
/* 2856 */         for (int i = 0; i < length; i++) {
/* 2857 */           AccessibleTextExtendedListener listener = (AccessibleTextExtendedListener)listeners.get(i);
/* 2858 */           listener.getTextBounds(event);
/*      */         }
/* 2860 */         int[] topWindowX = new int[1];int[] topWindowY = new int[1];
/* 2861 */         if (coords == 1L) {
/* 2862 */           windowPoint(object, topWindowX, topWindowY);
/* 2863 */           event.x -= topWindowX[0];
/* 2864 */           event.y -= topWindowY[0];
/*      */         }
/* 2866 */         C.memmove(x, new int[] { event.x }, 4L);
/* 2867 */         C.memmove(y, new int[] { event.y }, 4L);
/* 2868 */         C.memmove(width, new int[] { event.width }, 4L);
/* 2869 */         C.memmove(height, new int[] { event.height }, 4L);
/* 2870 */         return 0L;
/*      */       }
/*      */     }
/* 2873 */     AtkTextIface iface = getParentTextIface(atkObject);
/* 2874 */     if ((iface != null) && (iface.get_character_extents != 0L)) {
/* 2875 */       OS.call(iface.get_character_extents, atkObject, offset, x, y, width, height, coords);
/*      */     }
/* 2877 */     return 0L;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static long atkText_get_range_extents(long atkObject, long start_offset, long end_offset, long coord_type, long rect)
/*      */   {
/* 2901 */     AccessibleObject object = getAccessibleObject(atkObject);
/* 2902 */     if (object != null) {
/* 2903 */       Accessible accessible = object.accessible;
/* 2904 */       List<AccessibleTextExtendedListener> listeners = accessible.accessibleTextExtendedListeners;
/* 2905 */       int length = size(listeners);
/* 2906 */       if (length > 0) {
/* 2907 */         AccessibleTextEvent event = new AccessibleTextEvent(accessible);
/* 2908 */         event.start = ((int)start_offset);
/* 2909 */         event.end = ((int)end_offset);
/* 2910 */         for (int i = 0; i < length; i++) {
/* 2911 */           AccessibleTextExtendedListener listener = (AccessibleTextExtendedListener)listeners.get(i);
/* 2912 */           listener.getTextBounds(event);
/*      */         }
/* 2914 */         int[] topWindowX = new int[1];int[] topWindowY = new int[1];
/* 2915 */         if (coord_type == 1L) {
/* 2916 */           windowPoint(object, topWindowX, topWindowY);
/* 2917 */           event.x -= topWindowX[0];
/* 2918 */           event.y -= topWindowY[0];
/*      */         }
/* 2920 */         AtkTextRectangle atkRect = new AtkTextRectangle();
/* 2921 */         atkRect.x = event.x;
/* 2922 */         atkRect.y = event.y;
/* 2923 */         atkRect.width = event.width;
/* 2924 */         atkRect.height = event.height;
/* 2925 */         ATK.memmove(rect, atkRect, AtkTextRectangle.sizeof);
/* 2926 */         return 0L;
/*      */       }
/*      */     }
/* 2929 */     AtkTextIface iface = getParentTextIface(atkObject);
/* 2930 */     if ((iface != null) && (iface.get_range_extents != 0L)) {
/* 2931 */       ATK.call(iface.get_range_extents, atkObject, start_offset, end_offset, coord_type, rect);
/*      */     }
/* 2933 */     return 0L;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static long atkText_get_run_attributes(long atkObject, long offset, long start_offset, long end_offset)
/*      */   {
/* 2954 */     AccessibleObject object = getAccessibleObject(atkObject);
/* 2955 */     if (object != null) {
/* 2956 */       Accessible accessible = object.accessible;
/* 2957 */       List<AccessibleAttributeListener> listeners = accessible.accessibleAttributeListeners;
/* 2958 */       int length = size(listeners);
/* 2959 */       if (length > 0) {
/* 2960 */         AccessibleTextAttributeEvent event = new AccessibleTextAttributeEvent(accessible);
/* 2961 */         event.offset = ((int)offset);
/* 2962 */         for (int i = 0; i < length; i++) {
/* 2963 */           AccessibleAttributeListener listener = (AccessibleAttributeListener)listeners.get(i);
/* 2964 */           listener.getTextAttributes(event);
/*      */         }
/* 2966 */         C.memmove(start_offset, new int[] { event.start }, 4L);
/* 2967 */         C.memmove(end_offset, new int[] { event.end }, 4L);
/* 2968 */         TextStyle style = event.textStyle;
/* 2969 */         long result = 0L;
/* 2970 */         AtkAttribute attr = new AtkAttribute();
/* 2971 */         if (style != null) {
/* 2972 */           if (style.rise != 0) {
/* 2973 */             long attrPtr = OS.g_malloc(AtkAttribute.sizeof);
/* 2974 */             attr.name = OS.g_strdup(ATK.atk_text_attribute_get_name(10));
/* 2975 */             attr.value = getStringPtr(String.valueOf(style.rise));
/* 2976 */             ATK.memmove(attrPtr, attr, AtkAttribute.sizeof);
/* 2977 */             result = OS.g_slist_append(result, attrPtr);
/*      */           }
/* 2979 */           if (style.underline) {
/* 2980 */             long attrPtr = OS.g_malloc(AtkAttribute.sizeof);
/* 2981 */             attr.name = OS.g_strdup(ATK.atk_text_attribute_get_name(11));
/* 2982 */             String str = "none";
/* 2983 */             switch (style.underlineStyle) {
/* 2984 */             case 1:  str = "double"; break;
/* 2985 */             case 0:  str = "single"; break;
/* 2986 */             case 2:  str = "error"; break;
/* 2987 */             case 3:  str = "squiggle";
/*      */             }
/* 2989 */             attr.value = getStringPtr(str);
/* 2990 */             ATK.memmove(attrPtr, attr, AtkAttribute.sizeof);
/* 2991 */             result = OS.g_slist_append(result, attrPtr);
/*      */           }
/* 2993 */           if (style.strikeout) {
/* 2994 */             long attrPtr = OS.g_malloc(AtkAttribute.sizeof);
/* 2995 */             attr.name = OS.g_strdup(ATK.atk_text_attribute_get_name(12));
/* 2996 */             attr.value = getStringPtr("1");
/* 2997 */             ATK.memmove(attrPtr, attr, AtkAttribute.sizeof);
/* 2998 */             result = OS.g_slist_append(result, attrPtr);
/*      */           }
/* 3000 */           Font font = style.font;
/* 3001 */           if ((font != null) && (!font.isDisposed()))
/*      */           {
/*      */ 
/* 3004 */             long attrPtr = OS.g_malloc(AtkAttribute.sizeof);
/* 3005 */             attr.name = OS.g_strdup(ATK.atk_text_attribute_get_name(17));
/* 3006 */             attr.value = OS.g_strdup(OS.pango_font_description_get_family(font.handle));
/* 3007 */             ATK.memmove(attrPtr, attr, AtkAttribute.sizeof);
/* 3008 */             result = OS.g_slist_append(result, attrPtr);
/*      */             
/* 3010 */             attrPtr = OS.g_malloc(AtkAttribute.sizeof);
/* 3011 */             attr.name = OS.g_strdup(ATK.atk_text_attribute_get_name(13));
/* 3012 */             attr.value = getStringPtr(String.valueOf(OS.pango_font_description_get_size(font.handle) / 1024));
/* 3013 */             ATK.memmove(attrPtr, attr, AtkAttribute.sizeof);
/* 3014 */             result = OS.g_slist_append(result, attrPtr);
/*      */             
/* 3016 */             attrPtr = OS.g_malloc(AtkAttribute.sizeof);
/* 3017 */             attr.name = OS.g_strdup(ATK.atk_text_attribute_get_name(27));
/* 3018 */             attr.value = OS.g_strdup(ATK.atk_text_attribute_get_value(27, OS.pango_font_description_get_style(font.handle)));
/* 3019 */             ATK.memmove(attrPtr, attr, AtkAttribute.sizeof);
/* 3020 */             result = OS.g_slist_append(result, attrPtr);
/*      */             
/* 3022 */             attrPtr = OS.g_malloc(AtkAttribute.sizeof);
/* 3023 */             attr.name = OS.g_strdup(ATK.atk_text_attribute_get_name(26));
/* 3024 */             attr.value = OS.g_strdup(ATK.atk_text_attribute_get_value(26, OS.pango_font_description_get_variant(font.handle)));
/* 3025 */             ATK.memmove(attrPtr, attr, AtkAttribute.sizeof);
/* 3026 */             result = OS.g_slist_append(result, attrPtr);
/*      */             
/* 3028 */             attrPtr = OS.g_malloc(AtkAttribute.sizeof);
/* 3029 */             attr.name = OS.g_strdup(ATK.atk_text_attribute_get_name(25));
/* 3030 */             attr.value = OS.g_strdup(ATK.atk_text_attribute_get_value(25, OS.pango_font_description_get_stretch(font.handle)));
/* 3031 */             ATK.memmove(attrPtr, attr, AtkAttribute.sizeof);
/* 3032 */             result = OS.g_slist_append(result, attrPtr);
/*      */             
/* 3034 */             attrPtr = OS.g_malloc(AtkAttribute.sizeof);
/* 3035 */             attr.name = OS.g_strdup(ATK.atk_text_attribute_get_name(15));
/* 3036 */             attr.value = getStringPtr(String.valueOf(OS.pango_font_description_get_weight(font.handle)));
/* 3037 */             ATK.memmove(attrPtr, attr, AtkAttribute.sizeof);
/* 3038 */             result = OS.g_slist_append(result, attrPtr);
/*      */           }
/* 3040 */           Color color = style.foreground;
/* 3041 */           if ((color != null) && (!color.isDisposed())) {
/* 3042 */             long attrPtr = OS.g_malloc(AtkAttribute.sizeof);
/* 3043 */             attr.name = OS.g_strdup(ATK.atk_text_attribute_get_name(19));
/* 3044 */             if (GTK.GTK3) {
/* 3045 */               attr.value = getStringPtr(color.handleRGBA.red * 255.0D + "," + color.handleRGBA.green * 255.0D + "," + color.handleRGBA.blue * 255.0D);
/*      */             } else {
/* 3047 */               attr.value = getStringPtr((color.handle.red & 0xFFFF) + "," + (color.handle.blue & 0xFFFF) + "," + (color.handle.blue & 0xFFFF));
/*      */             }
/* 3049 */             ATK.memmove(attrPtr, attr, AtkAttribute.sizeof);
/* 3050 */             result = OS.g_slist_append(result, attrPtr);
/*      */           }
/* 3052 */           color = style.background;
/* 3053 */           if ((color != null) && (!color.isDisposed())) {
/* 3054 */             long attrPtr = OS.g_malloc(AtkAttribute.sizeof);
/* 3055 */             attr.name = OS.g_strdup(ATK.atk_text_attribute_get_name(18));
/* 3056 */             if (GTK.GTK3) {
/* 3057 */               attr.value = getStringPtr(color.handleRGBA.red * 255.0D + "," + color.handleRGBA.green * 255.0D + "," + color.handleRGBA.blue * 255.0D);
/*      */             } else {
/* 3059 */               attr.value = getStringPtr((color.handle.red & 0xFFFF) + "," + (color.handle.blue & 0xFFFF) + "," + (color.handle.blue & 0xFFFF));
/*      */             }
/* 3061 */             ATK.memmove(attrPtr, attr, AtkAttribute.sizeof);
/* 3062 */             result = OS.g_slist_append(result, attrPtr);
/*      */           }
/*      */         }
/* 3065 */         if (event.attributes != null) {
/* 3066 */           int end = event.attributes.length / 2 * 2;
/* 3067 */           for (int i = 0; i < end; i += 2) {
/* 3068 */             long attrPtr = OS.g_malloc(AtkAttribute.sizeof);
/* 3069 */             attr.name = getStringPtr(event.attributes[i]);
/* 3070 */             attr.value = getStringPtr(event.attributes[(i + 1)]);
/* 3071 */             ATK.memmove(attrPtr, attr, AtkAttribute.sizeof);
/* 3072 */             result = OS.g_slist_append(result, attrPtr);
/*      */           }
/*      */         }
/* 3075 */         return result;
/*      */       }
/*      */     }
/* 3078 */     long parentResult = 0L;
/* 3079 */     AtkTextIface iface = getParentTextIface(atkObject);
/* 3080 */     if ((iface != null) && (iface.get_run_attributes != 0L)) {
/* 3081 */       parentResult = OS.call(iface.get_run_attributes, atkObject, offset, start_offset, end_offset);
/*      */     }
/* 3083 */     return parentResult;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static long atkText_get_offset_at_point(long atkObject, long x, long y, long coords)
/*      */   {
/* 3104 */     AccessibleObject object = getAccessibleObject(atkObject);
/* 3105 */     if (object != null) {
/* 3106 */       Accessible accessible = object.accessible;
/* 3107 */       List<AccessibleTextExtendedListener> listeners = accessible.accessibleTextExtendedListeners;
/* 3108 */       int length = size(listeners);
/* 3109 */       if (length > 0) {
/* 3110 */         AccessibleTextEvent event = new AccessibleTextEvent(accessible);
/* 3111 */         event.x = ((int)x);
/* 3112 */         event.y = ((int)y);
/* 3113 */         int[] topWindowX = new int[1];int[] topWindowY = new int[1];
/* 3114 */         if (coords == 1L) {
/* 3115 */           windowPoint(object, topWindowX, topWindowY);
/* 3116 */           event.x += topWindowX[0];
/* 3117 */           event.y += topWindowY[0];
/*      */         }
/* 3119 */         for (int i = 0; i < length; i++) {
/* 3120 */           AccessibleTextExtendedListener listener = (AccessibleTextExtendedListener)listeners.get(i);
/* 3121 */           listener.getOffsetAtPoint(event);
/*      */         }
/* 3123 */         return event.offset;
/*      */       }
/*      */     }
/* 3126 */     long parentResult = 0L;
/* 3127 */     AtkTextIface iface = getParentTextIface(atkObject);
/* 3128 */     if ((iface != null) && (iface.get_offset_at_point != 0L)) {
/* 3129 */       parentResult = OS.call(iface.get_offset_at_point, atkObject, x, y, coords);
/*      */     }
/* 3131 */     return parentResult;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static long atkText_add_selection(long atkObject, long start_offset, long end_offset)
/*      */   {
/* 3149 */     AccessibleObject object = getAccessibleObject(atkObject);
/* 3150 */     if (object != null) {
/* 3151 */       Accessible accessible = object.accessible;
/* 3152 */       List<AccessibleTextExtendedListener> listeners = accessible.accessibleTextExtendedListeners;
/* 3153 */       int length = size(listeners);
/* 3154 */       if (length > 0) {
/* 3155 */         AccessibleTextEvent event = new AccessibleTextEvent(accessible);
/* 3156 */         event.start = ((int)start_offset);
/* 3157 */         event.end = ((int)end_offset);
/* 3158 */         for (int i = 0; i < length; i++) {
/* 3159 */           AccessibleTextExtendedListener listener = (AccessibleTextExtendedListener)listeners.get(i);
/* 3160 */           listener.addSelection(event);
/*      */         }
/* 3162 */         return "OK".equals(event.result) ? 1L : 0L;
/*      */       }
/*      */     }
/* 3165 */     long parentResult = 0L;
/* 3166 */     AtkTextIface iface = getParentTextIface(atkObject);
/* 3167 */     if ((iface != null) && (iface.add_selection != 0L)) {
/* 3168 */       parentResult = ATK.call(iface.add_selection, atkObject, start_offset, end_offset);
/*      */     }
/* 3170 */     return parentResult;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static long atkText_remove_selection(long atkObject, long selection_num)
/*      */   {
/* 3187 */     AccessibleObject object = getAccessibleObject(atkObject);
/* 3188 */     if (object != null) {
/* 3189 */       Accessible accessible = object.accessible;
/* 3190 */       List<AccessibleTextExtendedListener> listeners = accessible.accessibleTextExtendedListeners;
/* 3191 */       int length = size(listeners);
/* 3192 */       if (length > 0) {
/* 3193 */         AccessibleTextEvent event = new AccessibleTextEvent(accessible);
/* 3194 */         event.index = ((int)selection_num);
/* 3195 */         for (int i = 0; i < length; i++) {
/* 3196 */           AccessibleTextExtendedListener listener = (AccessibleTextExtendedListener)listeners.get(i);
/* 3197 */           listener.removeSelection(event);
/*      */         }
/* 3199 */         return "OK".equals(event.result) ? 1L : 0L;
/*      */       }
/*      */     }
/* 3202 */     long parentResult = 0L;
/* 3203 */     AtkTextIface iface = getParentTextIface(atkObject);
/* 3204 */     if ((iface != null) && (iface.remove_selection != 0L)) {
/* 3205 */       parentResult = ATK.call(iface.remove_selection, atkObject, selection_num);
/*      */     }
/* 3207 */     return parentResult;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static long atkText_set_caret_offset(long atkObject, long offset)
/*      */   {
/* 3224 */     AccessibleObject object = getAccessibleObject(atkObject);
/* 3225 */     if (object != null) {
/* 3226 */       Accessible accessible = object.accessible;
/* 3227 */       List<AccessibleTextExtendedListener> listeners = accessible.accessibleTextExtendedListeners;
/* 3228 */       int length = size(listeners);
/* 3229 */       if (length > 0) {
/* 3230 */         AccessibleTextEvent event = new AccessibleTextEvent(accessible);
/* 3231 */         event.offset = ((int)offset);
/* 3232 */         for (int i = 0; i < length; i++) {
/* 3233 */           AccessibleTextExtendedListener listener = (AccessibleTextExtendedListener)listeners.get(i);
/* 3234 */           listener.setCaretOffset(event);
/*      */         }
/* 3236 */         return "OK".equals(event.result) ? 1L : 0L;
/*      */       }
/*      */     }
/* 3239 */     AtkTextIface iface = getParentTextIface(atkObject);
/* 3240 */     if ((iface != null) && (iface.set_caret_offset != 0L)) {
/* 3241 */       return ATK.call(iface.set_caret_offset, atkObject, offset);
/*      */     }
/* 3243 */     return 0L;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static long atkText_set_selection(long atkObject, long selection_num, long start_offset, long end_offset)
/*      */   {
/* 3263 */     AccessibleObject object = getAccessibleObject(atkObject);
/* 3264 */     if (object != null) {
/* 3265 */       Accessible accessible = object.accessible;
/* 3266 */       List<AccessibleTextExtendedListener> listeners = accessible.accessibleTextExtendedListeners;
/* 3267 */       int length = size(listeners);
/* 3268 */       if (length > 0) {
/* 3269 */         AccessibleTextEvent event = new AccessibleTextEvent(accessible);
/* 3270 */         event.index = ((int)selection_num);
/* 3271 */         event.start = ((int)start_offset);
/* 3272 */         event.end = ((int)end_offset);
/* 3273 */         for (int i = 0; i < length; i++) {
/* 3274 */           AccessibleTextExtendedListener listener = (AccessibleTextExtendedListener)listeners.get(i);
/* 3275 */           listener.setSelection(event);
/*      */         }
/* 3277 */         return "OK".equals(event.result) ? 1L : 0L;
/*      */       }
/*      */     }
/* 3280 */     long parentResult = 0L;
/* 3281 */     AtkTextIface iface = getParentTextIface(atkObject);
/* 3282 */     if ((iface != null) && (iface.set_selection != 0L)) {
/* 3283 */       parentResult = OS.call(iface.set_selection, atkObject, selection_num, start_offset, end_offset);
/*      */     }
/* 3285 */     return parentResult;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static long atkText_get_caret_offset(long atkObject)
/*      */   {
/* 3301 */     AccessibleObject object = getAccessibleObject(atkObject);
/* 3302 */     long parentResult = 0L;
/* 3303 */     AtkTextIface iface = getParentTextIface(atkObject);
/* 3304 */     if ((iface != null) && (iface.get_caret_offset != 0L)) {
/* 3305 */       parentResult = ATK.call(iface.get_caret_offset, atkObject);
/*      */     }
/* 3307 */     if (object != null) {
/* 3308 */       Accessible accessible = object.accessible;
/* 3309 */       List<AccessibleTextExtendedListener> listeners = accessible.accessibleTextExtendedListeners;
/* 3310 */       int length = size(listeners);
/* 3311 */       if (length > 0) {
/* 3312 */         AccessibleTextEvent event = new AccessibleTextEvent(accessible);
/* 3313 */         for (int i = 0; i < length; i++) {
/* 3314 */           AccessibleTextExtendedListener listener = (AccessibleTextExtendedListener)listeners.get(i);
/* 3315 */           listener.getCaretOffset(event);
/*      */         }
/* 3317 */         return event.offset;
/*      */       }
/* 3319 */       List<AccessibleTextListener> listeners2 = accessible.accessibleTextListeners;
/* 3320 */       length = size(listeners2);
/* 3321 */       if (length > 0) {
/* 3322 */         AccessibleTextEvent event = new AccessibleTextEvent(object.accessible);
/* 3323 */         event.childID = object.id;
/* 3324 */         event.offset = ((int)parentResult);
/* 3325 */         for (int i = 0; i < length; i++) {
/* 3326 */           AccessibleTextListener listener = (AccessibleTextListener)listeners2.get(i);
/* 3327 */           listener.getCaretOffset(event);
/*      */         }
/* 3329 */         return event.offset;
/*      */       }
/*      */     }
/* 3332 */     return parentResult;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static long atkText_get_bounded_ranges(long atkObject, long rect, long coord_type, long x_clip_type, long y_clip_type)
/*      */   {
/* 3355 */     AccessibleObject object = getAccessibleObject(atkObject);
/* 3356 */     if (object != null) {
/* 3357 */       Accessible accessible = object.accessible;
/* 3358 */       List<AccessibleTextExtendedListener> listeners = accessible.accessibleTextExtendedListeners;
/* 3359 */       int length = size(listeners);
/* 3360 */       if (length > 0) {
/* 3361 */         AccessibleTextEvent event = new AccessibleTextEvent(accessible);
/* 3362 */         AtkTextRectangle atkRect = new AtkTextRectangle();
/* 3363 */         ATK.memmove(atkRect, rect, AtkTextRectangle.sizeof);
/* 3364 */         event.x = atkRect.x;
/* 3365 */         event.y = atkRect.y;
/* 3366 */         event.width = atkRect.width;
/* 3367 */         event.height = atkRect.height;
/* 3368 */         for (int i = 0; i < length; i++) {
/* 3369 */           AccessibleTextExtendedListener listener = (AccessibleTextExtendedListener)listeners.get(i);
/* 3370 */           listener.getRanges(event);
/*      */         }
/* 3372 */         int[] ranges = event.ranges;
/* 3373 */         int size = ranges == null ? 1 : ranges.length / 2;
/* 3374 */         long result = C.malloc(size * AtkTextRange.sizeof);
/* 3375 */         AtkTextRange range = new AtkTextRange();
/* 3376 */         int j = 0; for (int end = ranges != null ? ranges.length / 2 : 1; j < end; j++) {
/* 3377 */           if (ranges != null) {
/* 3378 */             int index = j * 2;
/* 3379 */             event.start = ranges[index];
/* 3380 */             event.end = ranges[(index + 1)];
/*      */           }
/* 3382 */           event.count = 0;
/* 3383 */           event.type = 5;
/* 3384 */           for (int i = 0; i < length; i++) {
/* 3385 */             AccessibleTextExtendedListener listener = (AccessibleTextExtendedListener)listeners.get(i);
/* 3386 */             listener.getText(event);
/*      */           }
/* 3388 */           range.start_offset = event.start;
/* 3389 */           range.end_offset = event.end;
/* 3390 */           range.content = getStringPtr(event.result);
/* 3391 */           event.result = null;
/* 3392 */           event.count = (event.type = event.x = event.y = event.width = event.height = 0);
/* 3393 */           for (int i = 0; i < length; i++) {
/* 3394 */             AccessibleTextExtendedListener listener = (AccessibleTextExtendedListener)listeners.get(i);
/* 3395 */             listener.getTextBounds(event);
/*      */           }
/* 3397 */           range.bounds.x = event.x;
/* 3398 */           range.bounds.y = event.y;
/* 3399 */           range.bounds.width = event.width;
/* 3400 */           range.bounds.height = event.height;
/* 3401 */           ATK.memmove(result + j * AtkTextRange.sizeof, range, AtkTextRange.sizeof);
/*      */         }
/* 3403 */         return result;
/*      */       }
/*      */     }
/* 3406 */     long parentResult = 0L;
/* 3407 */     AtkTextIface iface = getParentTextIface(atkObject);
/* 3408 */     if ((iface != null) && (iface.get_bounded_ranges != 0L)) {
/* 3409 */       parentResult = ATK.call(iface.get_bounded_ranges, atkObject);
/*      */     }
/* 3411 */     return parentResult;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static long atkText_get_character_at_offset(long atkObject, long offset)
/*      */   {
/* 3428 */     AccessibleObject object = getAccessibleObject(atkObject);
/* 3429 */     if (object != null) {
/* 3430 */       Accessible accessible = object.accessible;
/* 3431 */       List<AccessibleTextExtendedListener> listeners = accessible.accessibleTextExtendedListeners;
/* 3432 */       int length = size(listeners);
/* 3433 */       if (length > 0) {
/* 3434 */         AccessibleTextEvent event = new AccessibleTextEvent(accessible);
/* 3435 */         event.start = ((int)offset);
/* 3436 */         event.end = ((int)(offset + 1L));
/* 3437 */         event.type = 0;
/* 3438 */         for (int i = 0; i < length; i++) {
/* 3439 */           AccessibleTextExtendedListener listener = (AccessibleTextExtendedListener)listeners.get(i);
/* 3440 */           listener.getText(event);
/*      */         }
/* 3442 */         String text = event.result;
/* 3443 */         return (text != null) && (text.length() > 0) ? text.charAt(0) : 0L;
/*      */       }
/* 3445 */       String text = object.getText();
/* 3446 */       if ((text != null) && (text.length() > offset)) return text.charAt((int)offset);
/*      */     }
/* 3448 */     AtkTextIface iface = getParentTextIface(atkObject);
/* 3449 */     if ((iface != null) && (iface.get_character_at_offset != 0L)) {
/* 3450 */       return ATK.call(iface.get_character_at_offset, atkObject, offset);
/*      */     }
/* 3452 */     return 0L;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static long atkText_get_character_count(long atkObject)
/*      */   {
/* 3468 */     AccessibleObject object = getAccessibleObject(atkObject);
/* 3469 */     if (object != null) {
/* 3470 */       Accessible accessible = object.accessible;
/* 3471 */       List<AccessibleTextExtendedListener> listeners = accessible.accessibleTextExtendedListeners;
/* 3472 */       int length = size(listeners);
/* 3473 */       if (length > 0) {
/* 3474 */         AccessibleTextEvent event = new AccessibleTextEvent(accessible);
/* 3475 */         for (int i = 0; i < length; i++) {
/* 3476 */           AccessibleTextExtendedListener listener = (AccessibleTextExtendedListener)listeners.get(i);
/* 3477 */           listener.getCharacterCount(event);
/*      */         }
/* 3479 */         return event.count;
/*      */       }
/* 3481 */       String text = object.getText();
/* 3482 */       if (text != null) return text.length();
/*      */     }
/* 3484 */     AtkTextIface iface = getParentTextIface(atkObject);
/* 3485 */     if ((iface != null) && (iface.get_character_count != 0L)) {
/* 3486 */       return ATK.call(iface.get_character_count, atkObject);
/*      */     }
/* 3488 */     return 0L;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static long atkText_get_n_selections(long atkObject)
/*      */   {
/* 3504 */     AccessibleObject object = getAccessibleObject(atkObject);
/* 3505 */     if (object != null) {
/* 3506 */       Accessible accessible = object.accessible;
/* 3507 */       List<AccessibleTextExtendedListener> listeners = accessible.accessibleTextExtendedListeners;
/* 3508 */       int length = size(listeners);
/* 3509 */       if (length > 0) {
/* 3510 */         AccessibleTextEvent event = new AccessibleTextEvent(accessible);
/* 3511 */         for (int i = 0; i < length; i++) {
/* 3512 */           AccessibleTextExtendedListener listener = (AccessibleTextExtendedListener)listeners.get(i);
/* 3513 */           listener.getSelectionCount(event);
/*      */         }
/* 3515 */         return event.count;
/*      */       }
/* 3517 */       List<AccessibleTextListener> listeners2 = accessible.accessibleTextListeners;
/* 3518 */       length = size(listeners2);
/* 3519 */       if (length > 0) {
/* 3520 */         AccessibleTextEvent event = new AccessibleTextEvent(object.accessible);
/* 3521 */         event.childID = object.id;
/* 3522 */         for (int i = 0; i < length; i++) {
/* 3523 */           AccessibleTextListener listener = (AccessibleTextListener)listeners2.get(i);
/* 3524 */           listener.getSelectionRange(event);
/*      */         }
/* 3526 */         if (event.length > 0) return 1L;
/*      */       }
/*      */     }
/* 3529 */     long parentResult = 0L;
/* 3530 */     AtkTextIface iface = getParentTextIface(atkObject);
/* 3531 */     if ((iface != null) && (iface.get_n_selections != 0L)) {
/* 3532 */       parentResult = ATK.call(iface.get_n_selections, atkObject);
/*      */     }
/* 3534 */     return parentResult;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static long atkText_get_selection(long atkObject, long selection_num, long start_offset, long end_offset)
/*      */   {
/* 3554 */     AccessibleObject object = getAccessibleObject(atkObject);
/* 3555 */     long parentResult = 0L;
/* 3556 */     C.memmove(start_offset, new int[] { 0 }, 4L);
/* 3557 */     C.memmove(end_offset, new int[] { 0 }, 4L);
/* 3558 */     AtkTextIface iface = getParentTextIface(atkObject);
/* 3559 */     if ((iface != null) && (iface.get_selection != 0L)) {
/* 3560 */       parentResult = OS.call(iface.get_selection, atkObject, selection_num, start_offset, end_offset);
/*      */     }
/* 3562 */     if (object != null) {
/* 3563 */       int[] parentStart = new int[1];
/* 3564 */       int[] parentEnd = new int[1];
/* 3565 */       C.memmove(parentStart, start_offset, 4L);
/* 3566 */       C.memmove(parentEnd, end_offset, 4L);
/* 3567 */       Accessible accessible = object.accessible;
/* 3568 */       List<AccessibleTextExtendedListener> listeners = accessible.accessibleTextExtendedListeners;
/* 3569 */       int length = size(listeners);
/* 3570 */       if (length > 0) {
/* 3571 */         AccessibleTextEvent event = new AccessibleTextEvent(accessible);
/* 3572 */         event.index = ((int)selection_num);
/* 3573 */         event.start = parentStart[0];
/* 3574 */         event.end = parentEnd[0];
/* 3575 */         for (int i = 0; i < length; i++) {
/* 3576 */           AccessibleTextExtendedListener listener = (AccessibleTextExtendedListener)listeners.get(i);
/* 3577 */           listener.getSelection(event);
/*      */         }
/* 3579 */         parentStart[0] = event.start;
/* 3580 */         parentEnd[0] = event.end;
/* 3581 */         C.memmove(start_offset, parentStart, 4L);
/* 3582 */         C.memmove(end_offset, parentEnd, 4L);
/* 3583 */         event.count = (event.index = 0);
/* 3584 */         event.type = 5;
/* 3585 */         for (int i = 0; i < length; i++) {
/* 3586 */           AccessibleTextExtendedListener listener = (AccessibleTextExtendedListener)listeners.get(i);
/* 3587 */           listener.getText(event);
/*      */         }
/* 3589 */         if (parentResult != 0L) OS.g_free(parentResult);
/* 3590 */         return getStringPtr(event.result);
/*      */       }
/* 3592 */       if (selection_num == 0L) {
/* 3593 */         List<AccessibleTextListener> listeners2 = accessible.accessibleTextListeners;
/* 3594 */         length = size(listeners2);
/* 3595 */         if (length > 0) {
/* 3596 */           AccessibleTextEvent event = new AccessibleTextEvent(accessible);
/* 3597 */           event.childID = object.id;
/* 3598 */           event.offset = parentStart[0];
/* 3599 */           event.length = (parentEnd[0] - parentStart[0]);
/* 3600 */           for (int i = 0; i < length; i++) {
/* 3601 */             AccessibleTextListener listener = (AccessibleTextListener)listeners2.get(i);
/* 3602 */             listener.getSelectionRange(event);
/*      */           }
/* 3604 */           C.memmove(start_offset, new int[] { event.offset }, 4L);
/* 3605 */           C.memmove(end_offset, new int[] { event.offset + event.length }, 4L);
/* 3606 */           if (parentResult != 0L) OS.g_free(parentResult);
/* 3607 */           String text = object.getText();
/* 3608 */           if ((text != null) && (text.length() > event.offset) && (text.length() >= event.offset + event.length)) {
/* 3609 */             return getStringPtr(text.substring(event.offset, event.offset + event.length));
/*      */           }
/* 3611 */           if ((iface != null) && (iface.get_text != 0L)) {
/* 3612 */             return ATK.call(iface.get_text, atkObject, event.offset, event.offset + event.length);
/*      */           }
/* 3614 */           return 0L;
/*      */         }
/*      */       }
/*      */     }
/* 3618 */     return parentResult;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static long atkText_get_text(long atkObject, long start_offset, long end_offset)
/*      */   {
/* 3637 */     AccessibleObject object = getAccessibleObject(atkObject);
/* 3638 */     if (object != null) {
/* 3639 */       Accessible accessible = object.accessible;
/* 3640 */       List<AccessibleTextExtendedListener> listeners = accessible.accessibleTextExtendedListeners;
/* 3641 */       int length = size(listeners);
/* 3642 */       if (length > 0) {
/* 3643 */         AccessibleTextEvent event = new AccessibleTextEvent(accessible);
/* 3644 */         event.start = ((int)start_offset);
/* 3645 */         event.end = ((int)end_offset);
/* 3646 */         event.type = 5;
/* 3647 */         for (int i = 0; i < length; i++) {
/* 3648 */           AccessibleTextExtendedListener listener = (AccessibleTextExtendedListener)listeners.get(i);
/* 3649 */           listener.getText(event);
/*      */         }
/* 3651 */         return getStringPtr(event.result);
/*      */       }
/* 3653 */       String text = object.getText();
/* 3654 */       if ((text != null) && (text.length() > 0)) {
/* 3655 */         if (end_offset == -1L) {
/* 3656 */           end_offset = text.length();
/*      */         } else {
/* 3658 */           end_offset = Math.min(end_offset, text.length());
/*      */         }
/* 3660 */         start_offset = Math.min(start_offset, end_offset);
/* 3661 */         text = text.substring((int)start_offset, (int)end_offset);
/* 3662 */         return getStringPtr(text);
/*      */       }
/*      */     }
/* 3665 */     AtkTextIface iface = getParentTextIface(atkObject);
/* 3666 */     if ((iface != null) && (iface.get_text != 0L)) {
/* 3667 */       return ATK.call(iface.get_text, atkObject, start_offset, end_offset);
/*      */     }
/* 3669 */     return 0L;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static long atkText_get_text_after_offset(long atkObject, long offset_value, long boundary_type, long start_offset, long end_offset)
/*      */   {
/* 3691 */     AccessibleObject object = getAccessibleObject(atkObject);
/* 3692 */     if (object != null) {
/* 3693 */       Accessible accessible = object.accessible;
/* 3694 */       List<AccessibleTextExtendedListener> listeners = accessible.accessibleTextExtendedListeners;
/* 3695 */       int length = size(listeners);
/* 3696 */       if (length > 0) {
/* 3697 */         long charCount = atkText_get_character_count(atkObject);
/* 3698 */         AccessibleTextEvent event = new AccessibleTextEvent(accessible);
/* 3699 */         event.start = (event.end = (int)offset_value);
/* 3700 */         event.count = 1;
/* 3701 */         switch ((int)boundary_type) {
/* 3702 */         case 0:  event.type = 0; break;
/* 3703 */         case 1:  event.type = 1; break;
/* 3704 */         case 2:  event.type = 1; break;
/* 3705 */         case 3:  event.type = 2; break;
/* 3706 */         case 4:  event.type = 2; break;
/* 3707 */         case 5:  event.type = 4; break;
/* 3708 */         case 6:  event.type = 4;
/*      */         }
/* 3710 */         int eventStart = event.start;
/* 3711 */         int eventEnd = event.end;
/* 3712 */         for (int i = 0; i < length; i++) {
/* 3713 */           AccessibleTextExtendedListener listener = (AccessibleTextExtendedListener)listeners.get(i);
/* 3714 */           listener.getText(event);
/*      */         }
/* 3716 */         switch ((int)boundary_type) {
/*      */         case 1: 
/*      */         case 3: 
/*      */         case 5: 
/* 3720 */           if (event.end < charCount) {
/* 3721 */             int start = event.start;
/* 3722 */             event.start = eventStart;
/* 3723 */             event.end = eventEnd;
/* 3724 */             event.count = 2;
/* 3725 */             for (int i = 0; i < length; i++) {
/* 3726 */               AccessibleTextExtendedListener listener = (AccessibleTextExtendedListener)listeners.get(i);
/* 3727 */               listener.getText(event);
/*      */             }
/* 3729 */             event.end = event.start;
/* 3730 */             event.start = start;
/* 3731 */             event.type = 5;
/* 3732 */             event.count = 0;
/* 3733 */             for (int i = 0; i < length; i++) {
/* 3734 */               AccessibleTextExtendedListener listener = (AccessibleTextExtendedListener)listeners.get(i);
/* 3735 */               listener.getText(event);
/*      */             } }
/* 3737 */           break;
/*      */         
/*      */         case 2: 
/*      */         case 4: 
/*      */         case 6: 
/* 3742 */           if (0 < event.start) {
/* 3743 */             int end = event.end;
/* 3744 */             event.start = eventStart;
/* 3745 */             event.end = eventEnd;
/* 3746 */             event.count = 0;
/* 3747 */             for (int i = 0; i < length; i++) {
/* 3748 */               AccessibleTextExtendedListener listener = (AccessibleTextExtendedListener)listeners.get(i);
/* 3749 */               listener.getText(event);
/*      */             }
/* 3751 */             event.start = event.end;
/* 3752 */             event.end = end;
/* 3753 */             event.type = 5;
/* 3754 */             event.count = 0;
/* 3755 */             for (int i = 0; i < length; i++) {
/* 3756 */               AccessibleTextExtendedListener listener = (AccessibleTextExtendedListener)listeners.get(i);
/* 3757 */               listener.getText(event);
/*      */             }
/*      */           }
/*      */           break;
/*      */         }
/* 3762 */         C.memmove(start_offset, new int[] { event.start }, 4L);
/* 3763 */         C.memmove(end_offset, new int[] { event.end }, 4L);
/* 3764 */         return getStringPtr(event.result);
/*      */       }
/* 3766 */       int offset = (int)offset_value;
/* 3767 */       String text = object.getText();
/* 3768 */       if ((text != null) && (text.length() > 0)) {
/* 3769 */         length = text.length();
/* 3770 */         offset = Math.min(offset, length - 1);
/* 3771 */         int startBounds = offset;
/* 3772 */         int endBounds = offset;
/* 3773 */         switch ((int)boundary_type) {
/*      */         case 0: 
/* 3775 */           if (length > offset) { endBounds++;
/*      */           }
/*      */           break;
/*      */         case 1: 
/* 3779 */           int wordStart1 = nextIndexOfChar(text, " !?.\n", offset - 1);
/* 3780 */           if (wordStart1 == -1) {
/* 3781 */             startBounds = endBounds = length;
/*      */           }
/*      */           else {
/* 3784 */             wordStart1 = nextIndexOfNotChar(text, " !?.\n", wordStart1);
/* 3785 */             if (wordStart1 == length) {
/* 3786 */               startBounds = endBounds = length;
/*      */             }
/*      */             else {
/* 3789 */               startBounds = wordStart1;
/* 3790 */               int wordStart2 = nextIndexOfChar(text, " !?.\n", wordStart1);
/* 3791 */               if (wordStart2 == -1) {
/* 3792 */                 endBounds = length;
/*      */               }
/*      */               else
/* 3795 */                 endBounds = nextIndexOfNotChar(text, " !?.\n", wordStart2); } }
/* 3796 */           break;
/*      */         
/*      */         case 2: 
/* 3799 */           int previousWordEnd = previousIndexOfNotChar(text, " \n", offset);
/* 3800 */           if ((previousWordEnd == -1) || (previousWordEnd != offset - 1)) {
/* 3801 */             offset = nextIndexOfNotChar(text, " \n", offset);
/*      */           }
/* 3803 */           if (offset == -1) {
/* 3804 */             startBounds = endBounds = length;
/*      */           }
/*      */           else {
/* 3807 */             int wordEnd1 = nextIndexOfChar(text, " !?.\n", offset);
/* 3808 */             if (wordEnd1 == -1) {
/* 3809 */               startBounds = endBounds = length;
/*      */             }
/*      */             else {
/* 3812 */               wordEnd1 = nextIndexOfNotChar(text, "!?.", wordEnd1);
/* 3813 */               if (wordEnd1 == length) {
/* 3814 */                 startBounds = endBounds = length;
/*      */               }
/*      */               else {
/* 3817 */                 startBounds = wordEnd1;
/* 3818 */                 int wordEnd2 = nextIndexOfNotChar(text, " \n", wordEnd1);
/* 3819 */                 if (wordEnd2 == length) {
/* 3820 */                   startBounds = endBounds = length;
/*      */                 }
/*      */                 else {
/* 3823 */                   wordEnd2 = nextIndexOfChar(text, " !?.\n", wordEnd2);
/* 3824 */                   if (wordEnd2 == -1) {
/* 3825 */                     endBounds = length;
/*      */                   }
/*      */                   else
/* 3828 */                     endBounds = nextIndexOfNotChar(text, "!?.", wordEnd2); } } } }
/* 3829 */           break;
/*      */         
/*      */         case 3: 
/* 3832 */           int previousSentenceEnd = previousIndexOfChar(text, "!?.", offset);
/* 3833 */           int previousText = previousIndexOfNotChar(text, " !?.\n", offset);
/* 3834 */           int sentenceStart1 = 0;
/* 3835 */           if (previousSentenceEnd >= previousText) {
/* 3836 */             sentenceStart1 = nextIndexOfNotChar(text, " !?.\n", offset);
/*      */           } else {
/* 3838 */             sentenceStart1 = nextIndexOfChar(text, "!?.", offset);
/* 3839 */             if (sentenceStart1 == -1) {
/* 3840 */               startBounds = endBounds = length;
/* 3841 */               break;
/*      */             }
/* 3843 */             sentenceStart1 = nextIndexOfNotChar(text, " !?.\n", sentenceStart1);
/*      */           }
/* 3845 */           if (sentenceStart1 == length) {
/* 3846 */             startBounds = endBounds = length;
/*      */           }
/*      */           else {
/* 3849 */             startBounds = sentenceStart1;
/* 3850 */             int sentenceStart2 = nextIndexOfChar(text, "!?.", sentenceStart1);
/* 3851 */             if (sentenceStart2 == -1) {
/* 3852 */               endBounds = length;
/*      */             }
/*      */             else
/* 3855 */               endBounds = nextIndexOfNotChar(text, " !?.\n", sentenceStart2); }
/* 3856 */           break;
/*      */         
/*      */         case 4: 
/* 3859 */           int sentenceEnd1 = nextIndexOfChar(text, "!?.", offset);
/* 3860 */           if (sentenceEnd1 == -1) {
/* 3861 */             startBounds = endBounds = length;
/*      */           }
/*      */           else {
/* 3864 */             sentenceEnd1 = nextIndexOfNotChar(text, "!?.", sentenceEnd1);
/* 3865 */             if (sentenceEnd1 == length) {
/* 3866 */               startBounds = endBounds = length;
/*      */             }
/*      */             else {
/* 3869 */               startBounds = sentenceEnd1;
/* 3870 */               int sentenceEnd2 = nextIndexOfNotChar(text, " \n", sentenceEnd1);
/* 3871 */               if (sentenceEnd2 == length) {
/* 3872 */                 startBounds = endBounds = length;
/*      */               }
/*      */               else {
/* 3875 */                 sentenceEnd2 = nextIndexOfChar(text, "!?.", sentenceEnd2);
/* 3876 */                 if (sentenceEnd2 == -1) {
/* 3877 */                   endBounds = length;
/*      */                 }
/*      */                 else
/* 3880 */                   endBounds = nextIndexOfNotChar(text, "!?.", sentenceEnd2); } } }
/* 3881 */           break;
/*      */         
/*      */         case 5: 
/* 3884 */           int lineStart1 = text.indexOf('\n', offset - 1);
/* 3885 */           if (lineStart1 == -1) {
/* 3886 */             startBounds = endBounds = length;
/*      */           }
/*      */           else {
/* 3889 */             lineStart1 = nextIndexOfNotChar(text, "\n", lineStart1);
/* 3890 */             if (lineStart1 == length) {
/* 3891 */               startBounds = endBounds = length;
/*      */             }
/*      */             else {
/* 3894 */               startBounds = lineStart1;
/* 3895 */               int lineStart2 = text.indexOf('\n', lineStart1);
/* 3896 */               if (lineStart2 == -1) {
/* 3897 */                 endBounds = length;
/*      */               }
/*      */               else {
/* 3900 */                 lineStart2 = nextIndexOfNotChar(text, "\n", lineStart2);
/* 3901 */                 endBounds = lineStart2; } } }
/* 3902 */           break;
/*      */         
/*      */         case 6: 
/* 3905 */           int lineEnd1 = nextIndexOfChar(text, "\n", offset);
/* 3906 */           if (lineEnd1 == -1) {
/* 3907 */             startBounds = endBounds = length;
/*      */           }
/*      */           else {
/* 3910 */             startBounds = lineEnd1;
/* 3911 */             if (startBounds == length) {
/* 3912 */               endBounds = length;
/*      */             }
/*      */             else {
/* 3915 */               int lineEnd2 = nextIndexOfChar(text, "\n", lineEnd1 + 1);
/* 3916 */               if (lineEnd2 == -1) {
/* 3917 */                 endBounds = length;
/*      */               }
/*      */               else
/* 3920 */                 endBounds = lineEnd2; } }
/* 3921 */           break;
/*      */         }
/*      */         
/* 3924 */         C.memmove(start_offset, new int[] { startBounds }, 4L);
/* 3925 */         C.memmove(end_offset, new int[] { endBounds }, 4L);
/* 3926 */         text = text.substring(startBounds, endBounds);
/* 3927 */         return getStringPtr(text);
/*      */       }
/*      */     }
/* 3930 */     AtkTextIface iface = getParentTextIface(atkObject);
/* 3931 */     if ((iface != null) && (iface.get_text_after_offset != 0L)) {
/* 3932 */       return ATK.call(iface.get_text_after_offset, atkObject, offset_value, boundary_type, start_offset, end_offset);
/*      */     }
/* 3934 */     return 0L;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static long atkText_get_text_at_offset(long atkObject, long offset_value, long boundary_type, long start_offset, long end_offset)
/*      */   {
/* 3956 */     AccessibleObject object = getAccessibleObject(atkObject);
/* 3957 */     if (object != null) {
/* 3958 */       Accessible accessible = object.accessible;
/* 3959 */       List<AccessibleTextExtendedListener> listeners = accessible.accessibleTextExtendedListeners;
/* 3960 */       int length = size(listeners);
/* 3961 */       if (length > 0) {
/* 3962 */         long charCount = atkText_get_character_count(atkObject);
/* 3963 */         AccessibleTextEvent event = new AccessibleTextEvent(accessible);
/* 3964 */         event.start = (event.end = (int)offset_value);
/* 3965 */         event.count = 0;
/* 3966 */         switch ((int)boundary_type) {
/* 3967 */         case 0:  event.type = 0; break;
/* 3968 */         case 1:  event.type = 1; break;
/* 3969 */         case 2:  event.type = 1; break;
/* 3970 */         case 3:  event.type = 2; break;
/* 3971 */         case 4:  event.type = 2; break;
/* 3972 */         case 5:  event.type = 4; break;
/* 3973 */         case 6:  event.type = 4;
/*      */         }
/* 3975 */         int eventStart = event.start;
/* 3976 */         int eventEnd = event.end;
/* 3977 */         for (int i = 0; i < length; i++) {
/* 3978 */           AccessibleTextExtendedListener listener = (AccessibleTextExtendedListener)listeners.get(i);
/* 3979 */           listener.getText(event);
/*      */         }
/* 3981 */         switch ((int)boundary_type) {
/*      */         case 1: 
/*      */         case 3: 
/*      */         case 5: 
/* 3985 */           if (event.end < charCount) {
/* 3986 */             int start = event.start;
/* 3987 */             event.start = eventStart;
/* 3988 */             event.end = eventEnd;
/* 3989 */             event.count = 1;
/* 3990 */             for (int i = 0; i < length; i++) {
/* 3991 */               AccessibleTextExtendedListener listener = (AccessibleTextExtendedListener)listeners.get(i);
/* 3992 */               listener.getText(event);
/*      */             }
/* 3994 */             event.end = event.start;
/* 3995 */             event.start = start;
/* 3996 */             event.type = 5;
/* 3997 */             event.count = 0;
/* 3998 */             for (int i = 0; i < length; i++) {
/* 3999 */               AccessibleTextExtendedListener listener = (AccessibleTextExtendedListener)listeners.get(i);
/* 4000 */               listener.getText(event);
/*      */             } }
/* 4002 */           break;
/*      */         
/*      */         case 2: 
/*      */         case 4: 
/*      */         case 6: 
/* 4007 */           if (0 < event.start) {
/* 4008 */             int end = event.end;
/* 4009 */             event.start = eventStart;
/* 4010 */             event.end = eventEnd;
/* 4011 */             event.count = -1;
/* 4012 */             for (int i = 0; i < length; i++) {
/* 4013 */               AccessibleTextExtendedListener listener = (AccessibleTextExtendedListener)listeners.get(i);
/* 4014 */               listener.getText(event);
/*      */             }
/* 4016 */             event.start = event.end;
/* 4017 */             event.end = end;
/* 4018 */             event.type = 5;
/* 4019 */             event.count = 0;
/* 4020 */             for (int i = 0; i < length; i++) {
/* 4021 */               AccessibleTextExtendedListener listener = (AccessibleTextExtendedListener)listeners.get(i);
/* 4022 */               listener.getText(event);
/*      */             }
/*      */           }
/*      */           break;
/*      */         }
/* 4027 */         C.memmove(start_offset, new int[] { event.start }, 4L);
/* 4028 */         C.memmove(end_offset, new int[] { event.end }, 4L);
/* 4029 */         return getStringPtr(event.result);
/*      */       }
/* 4031 */       int offset = (int)offset_value;
/* 4032 */       String text = object.getText();
/* 4033 */       if ((text != null) && (text.length() > 0)) {
/* 4034 */         length = text.length();
/* 4035 */         offset = Math.min(offset, length - 1);
/* 4036 */         int startBounds = offset;
/* 4037 */         int endBounds = offset;
/* 4038 */         switch ((int)boundary_type) {
/*      */         case 0: 
/* 4040 */           if (length > offset) { endBounds++;
/*      */           }
/*      */           break;
/*      */         case 1: 
/* 4044 */           int wordStart1 = previousIndexOfNotChar(text, " !?.\n", offset);
/* 4045 */           if (wordStart1 == -1) {
/* 4046 */             startBounds = endBounds = 0;
/*      */           }
/*      */           else {
/* 4049 */             wordStart1 = previousIndexOfChar(text, " !?.\n", wordStart1) + 1;
/* 4050 */             if (wordStart1 == -1) {
/* 4051 */               startBounds = 0;
/*      */             }
/*      */             else {
/* 4054 */               startBounds = wordStart1;
/* 4055 */               int wordStart2 = nextIndexOfChar(text, " !?.\n", wordStart1);
/* 4056 */               endBounds = nextIndexOfNotChar(text, " !?.\n", wordStart2); } }
/* 4057 */           break;
/*      */         
/*      */         case 2: 
/* 4060 */           int wordEnd1 = previousIndexOfNotChar(text, "!?.", offset + 1);
/* 4061 */           wordEnd1 = previousIndexOfChar(text, " !?.\n", wordEnd1);
/* 4062 */           wordEnd1 = previousIndexOfNotChar(text, " \n", wordEnd1 + 1);
/* 4063 */           if (wordEnd1 == -1) {
/* 4064 */             startBounds = endBounds = 0;
/*      */           }
/*      */           else {
/* 4067 */             startBounds = wordEnd1 + 1;
/* 4068 */             int wordEnd2 = nextIndexOfNotChar(text, " \n", startBounds);
/* 4069 */             if (wordEnd2 == length) {
/* 4070 */               endBounds = startBounds;
/*      */             }
/*      */             else {
/* 4073 */               wordEnd2 = nextIndexOfChar(text, " !?.\n", wordEnd2);
/* 4074 */               if (wordEnd2 == -1) {
/* 4075 */                 endBounds = startBounds;
/*      */               }
/*      */               else
/* 4078 */                 endBounds = nextIndexOfNotChar(text, "!?.", wordEnd2); } }
/* 4079 */           break;
/*      */         
/*      */         case 3: 
/* 4082 */           int sentenceStart1 = previousIndexOfNotChar(text, " !?.\n", offset + 1);
/* 4083 */           if (sentenceStart1 == -1) {
/* 4084 */             startBounds = endBounds = 0;
/*      */           }
/*      */           else {
/* 4087 */             sentenceStart1 = previousIndexOfChar(text, "!?.", sentenceStart1) + 1;
/* 4088 */             startBounds = nextIndexOfNotChar(text, " \n", sentenceStart1);
/* 4089 */             int sentenceStart2 = nextIndexOfChar(text, "!?.", startBounds);
/* 4090 */             endBounds = nextIndexOfNotChar(text, " !?.\n", sentenceStart2); }
/* 4091 */           break;
/*      */         
/*      */         case 4: 
/* 4094 */           int sentenceEnd1 = previousIndexOfNotChar(text, "!?.", offset + 1);
/* 4095 */           sentenceEnd1 = previousIndexOfChar(text, "!?.", sentenceEnd1);
/* 4096 */           sentenceEnd1 = previousIndexOfNotChar(text, " \n", sentenceEnd1 + 1);
/* 4097 */           if (sentenceEnd1 == -1) {
/* 4098 */             startBounds = endBounds = 0;
/*      */           }
/*      */           else {
/* 4101 */             startBounds = sentenceEnd1 + 1;
/* 4102 */             int sentenceEnd2 = nextIndexOfNotChar(text, " \n", startBounds);
/* 4103 */             if (sentenceEnd2 == length) {
/* 4104 */               endBounds = startBounds;
/*      */             }
/*      */             else {
/* 4107 */               sentenceEnd2 = nextIndexOfChar(text, "!?.", sentenceEnd2);
/* 4108 */               if (sentenceEnd2 == -1) {
/* 4109 */                 endBounds = startBounds;
/*      */               }
/*      */               else
/* 4112 */                 endBounds = nextIndexOfNotChar(text, "!?.", sentenceEnd2); } }
/* 4113 */           break;
/*      */         
/*      */         case 5: 
/* 4116 */           startBounds = previousIndexOfChar(text, "\n", offset) + 1;
/* 4117 */           int lineEnd2 = nextIndexOfChar(text, "\n", startBounds);
/* 4118 */           if (lineEnd2 < length) lineEnd2++;
/* 4119 */           endBounds = lineEnd2;
/* 4120 */           break;
/*      */         
/*      */         case 6: 
/* 4123 */           int lineEnd1 = previousIndexOfChar(text, "\n", offset);
/* 4124 */           if (lineEnd1 == -1) {
/* 4125 */             startBounds = endBounds = 0;
/*      */           }
/*      */           else {
/* 4128 */             startBounds = lineEnd1;
/* 4129 */             endBounds = nextIndexOfChar(text, "\n", lineEnd1 + 1);
/*      */           }
/*      */           break; }
/* 4132 */         C.memmove(start_offset, new int[] { startBounds }, 4L);
/* 4133 */         C.memmove(end_offset, new int[] { endBounds }, 4L);
/* 4134 */         text = text.substring(startBounds, endBounds);
/* 4135 */         return getStringPtr(text);
/*      */       }
/*      */     }
/* 4138 */     AtkTextIface iface = getParentTextIface(atkObject);
/* 4139 */     if ((iface != null) && (iface.get_text_at_offset != 0L)) {
/* 4140 */       return ATK.call(iface.get_text_at_offset, atkObject, offset_value, boundary_type, start_offset, end_offset);
/*      */     }
/* 4142 */     return 0L;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static long atkText_get_text_before_offset(long atkObject, long offset_value, long boundary_type, long start_offset, long end_offset)
/*      */   {
/* 4164 */     AccessibleObject object = getAccessibleObject(atkObject);
/* 4165 */     if (object != null) {
/* 4166 */       Accessible accessible = object.accessible;
/* 4167 */       List<AccessibleTextExtendedListener> listeners = accessible.accessibleTextExtendedListeners;
/* 4168 */       int length = size(listeners);
/* 4169 */       if (length > 0) {
/* 4170 */         long charCount = atkText_get_character_count(atkObject);
/* 4171 */         AccessibleTextEvent event = new AccessibleTextEvent(accessible);
/* 4172 */         event.start = (event.end = (int)offset_value);
/* 4173 */         event.count = -1;
/* 4174 */         switch ((int)boundary_type) {
/* 4175 */         case 0:  event.type = 0; break;
/* 4176 */         case 1:  event.type = 1; break;
/* 4177 */         case 2:  event.type = 1; break;
/* 4178 */         case 3:  event.type = 2; break;
/* 4179 */         case 4:  event.type = 2; break;
/* 4180 */         case 5:  event.type = 4; break;
/* 4181 */         case 6:  event.type = 4;
/*      */         }
/* 4183 */         int eventStart = event.start;
/* 4184 */         int eventEnd = event.end;
/* 4185 */         for (int i = 0; i < length; i++) {
/* 4186 */           AccessibleTextExtendedListener listener = (AccessibleTextExtendedListener)listeners.get(i);
/* 4187 */           listener.getText(event);
/*      */         }
/* 4189 */         C.memmove(start_offset, new int[] { event.start }, 4L);
/* 4190 */         C.memmove(end_offset, new int[] { event.end }, 4L);
/* 4191 */         switch ((int)boundary_type) {
/*      */         case 1: 
/*      */         case 3: 
/*      */         case 5: 
/* 4195 */           if (event.end < charCount) {
/* 4196 */             int start = event.start;
/* 4197 */             event.start = eventStart;
/* 4198 */             event.end = eventEnd;
/* 4199 */             event.count = 0;
/* 4200 */             for (int i = 0; i < length; i++) {
/* 4201 */               AccessibleTextExtendedListener listener = (AccessibleTextExtendedListener)listeners.get(i);
/* 4202 */               listener.getText(event);
/*      */             }
/* 4204 */             event.end = event.start;
/* 4205 */             event.start = start;
/* 4206 */             event.type = 5;
/* 4207 */             event.count = 0;
/* 4208 */             for (int i = 0; i < length; i++) {
/* 4209 */               AccessibleTextExtendedListener listener = (AccessibleTextExtendedListener)listeners.get(i);
/* 4210 */               listener.getText(event);
/*      */             } }
/* 4212 */           break;
/*      */         
/*      */         case 2: 
/*      */         case 4: 
/*      */         case 6: 
/* 4217 */           if (0 < event.start) {
/* 4218 */             int end = event.end;
/* 4219 */             event.start = eventStart;
/* 4220 */             event.end = eventEnd;
/* 4221 */             event.count = -2;
/* 4222 */             for (int i = 0; i < length; i++) {
/* 4223 */               AccessibleTextExtendedListener listener = (AccessibleTextExtendedListener)listeners.get(i);
/* 4224 */               listener.getText(event);
/*      */             }
/* 4226 */             event.start = event.end;
/* 4227 */             event.end = end;
/* 4228 */             event.type = 5;
/* 4229 */             event.count = 0;
/* 4230 */             for (int i = 0; i < length; i++) {
/* 4231 */               AccessibleTextExtendedListener listener = (AccessibleTextExtendedListener)listeners.get(i);
/* 4232 */               listener.getText(event);
/*      */             }
/*      */           }
/*      */           break;
/*      */         }
/* 4237 */         return getStringPtr(event.result);
/*      */       }
/* 4239 */       int offset = (int)offset_value;
/* 4240 */       String text = object.getText();
/* 4241 */       if ((text != null) && (text.length() > 0)) {
/* 4242 */         length = text.length();
/* 4243 */         offset = Math.min(offset, length - 1);
/* 4244 */         int startBounds = offset;
/* 4245 */         int endBounds = offset;
/* 4246 */         switch ((int)boundary_type) {
/*      */         case 0: 
/* 4248 */           if ((length >= offset) && (offset > 0)) { startBounds--;
/*      */           }
/*      */           break;
/*      */         case 1: 
/* 4252 */           int wordStart1 = previousIndexOfChar(text, " !?.\n", offset - 1);
/* 4253 */           if (wordStart1 == -1) {
/* 4254 */             startBounds = endBounds = 0;
/*      */           }
/*      */           else {
/* 4257 */             int wordStart2 = previousIndexOfNotChar(text, " !?.\n", wordStart1);
/* 4258 */             if (wordStart2 == -1) {
/* 4259 */               startBounds = endBounds = 0;
/*      */             }
/*      */             else {
/* 4262 */               endBounds = wordStart1 + 1;
/* 4263 */               startBounds = previousIndexOfChar(text, " !?.\n", wordStart2) + 1; } }
/* 4264 */           break;
/*      */         
/*      */         case 2: 
/* 4267 */           int wordEnd1 = previousIndexOfChar(text, " !?.\n", offset);
/* 4268 */           if (wordEnd1 == -1) {
/* 4269 */             startBounds = endBounds = 0;
/*      */           }
/*      */           else {
/* 4272 */             wordEnd1 = previousIndexOfNotChar(text, " \n", wordEnd1 + 1);
/* 4273 */             if (wordEnd1 == -1) {
/* 4274 */               startBounds = endBounds = 0;
/*      */             }
/*      */             else {
/* 4277 */               endBounds = wordEnd1 + 1;
/* 4278 */               int wordEnd2 = previousIndexOfNotChar(text, " !?.\n", endBounds);
/* 4279 */               wordEnd2 = previousIndexOfChar(text, " !?.\n", wordEnd2);
/* 4280 */               if (wordEnd2 == -1) {
/* 4281 */                 startBounds = 0;
/*      */               }
/*      */               else
/* 4284 */                 startBounds = previousIndexOfNotChar(text, " \n", wordEnd2 + 1) + 1; } }
/* 4285 */           break;
/*      */         
/*      */         case 3: 
/* 4288 */           int sentenceStart1 = previousIndexOfChar(text, "!?.", offset);
/* 4289 */           if (sentenceStart1 == -1) {
/* 4290 */             startBounds = endBounds = 0;
/*      */           }
/*      */           else {
/* 4293 */             int sentenceStart2 = previousIndexOfNotChar(text, "!?.", sentenceStart1);
/* 4294 */             if (sentenceStart2 == -1) {
/* 4295 */               startBounds = endBounds = 0;
/*      */             }
/*      */             else {
/* 4298 */               endBounds = sentenceStart1 + 1;
/* 4299 */               startBounds = previousIndexOfChar(text, "!?.", sentenceStart2) + 1; } }
/* 4300 */           break;
/*      */         
/*      */         case 4: 
/* 4303 */           int sentenceEnd1 = previousIndexOfChar(text, "!?.", offset);
/* 4304 */           if (sentenceEnd1 == -1) {
/* 4305 */             startBounds = endBounds = 0;
/*      */           }
/*      */           else {
/* 4308 */             sentenceEnd1 = previousIndexOfNotChar(text, " \n", sentenceEnd1 + 1);
/* 4309 */             if (sentenceEnd1 == -1) {
/* 4310 */               startBounds = endBounds = 0;
/*      */             }
/*      */             else {
/* 4313 */               endBounds = sentenceEnd1 + 1;
/* 4314 */               int sentenceEnd2 = previousIndexOfNotChar(text, "!?.", endBounds);
/* 4315 */               sentenceEnd2 = previousIndexOfChar(text, "!?.", sentenceEnd2);
/* 4316 */               if (sentenceEnd2 == -1) {
/* 4317 */                 startBounds = 0;
/*      */               }
/*      */               else
/* 4320 */                 startBounds = previousIndexOfNotChar(text, " \n", sentenceEnd2 + 1) + 1; } }
/* 4321 */           break;
/*      */         
/*      */         case 5: 
/* 4324 */           int lineStart1 = previousIndexOfChar(text, "\n", offset);
/* 4325 */           if (lineStart1 == -1) {
/* 4326 */             startBounds = endBounds = 0;
/*      */           }
/*      */           else {
/* 4329 */             endBounds = lineStart1 + 1;
/* 4330 */             startBounds = previousIndexOfChar(text, "\n", lineStart1) + 1; }
/* 4331 */           break;
/*      */         
/*      */         case 6: 
/* 4334 */           int lineEnd1 = previousIndexOfChar(text, "\n", offset);
/* 4335 */           if (lineEnd1 == -1) {
/* 4336 */             startBounds = endBounds = 0;
/*      */           }
/*      */           else {
/* 4339 */             endBounds = lineEnd1;
/* 4340 */             startBounds = previousIndexOfChar(text, "\n", lineEnd1);
/* 4341 */             if (startBounds == -1) startBounds = 0;
/*      */           }
/*      */           break;
/*      */         }
/* 4345 */         C.memmove(start_offset, new int[] { startBounds }, 4L);
/* 4346 */         C.memmove(end_offset, new int[] { endBounds }, 4L);
/* 4347 */         text = text.substring(startBounds, endBounds);
/* 4348 */         return getStringPtr(text);
/*      */       }
/*      */     }
/* 4351 */     AtkTextIface iface = getParentTextIface(atkObject);
/* 4352 */     if ((iface != null) && (iface.get_text_before_offset != 0L)) {
/* 4353 */       return ATK.call(iface.get_text_before_offset, atkObject, offset_value, boundary_type, start_offset, end_offset);
/*      */     }
/* 4355 */     return 0L;
/*      */   }
/*      */   
/*      */   static void setGValue(long value, Number number) {
/* 4359 */     if (number == null) return;
/* 4360 */     if (OS.G_VALUE_TYPE(value) != 0L) OS.g_value_unset(value);
/* 4361 */     if ((number instanceof Double)) {
/* 4362 */       OS.g_value_init(value, OS.G_TYPE_DOUBLE());
/* 4363 */       OS.g_value_set_double(value, number.doubleValue());
/* 4364 */     } else if ((number instanceof Float)) {
/* 4365 */       OS.g_value_init(value, OS.G_TYPE_FLOAT());
/* 4366 */       OS.g_value_set_float(value, number.floatValue());
/* 4367 */     } else if ((number instanceof Long)) {
/* 4368 */       OS.g_value_init(value, OS.G_TYPE_INT64());
/* 4369 */       OS.g_value_set_int64(value, number.longValue());
/*      */     } else {
/* 4371 */       OS.g_value_init(value, OS.G_TYPE_INT());
/* 4372 */       OS.g_value_set_int(value, number.intValue());
/*      */     }
/*      */   }
/*      */   
/*      */   static Number getGValue(long value) {
/* 4377 */     long type = OS.G_VALUE_TYPE(value);
/* 4378 */     if (type == 0L) return null;
/* 4379 */     if (type == OS.G_TYPE_DOUBLE()) return Double.valueOf(OS.g_value_get_double(value));
/* 4380 */     if (type == OS.G_TYPE_FLOAT()) return Float.valueOf(OS.g_value_get_float(value));
/* 4381 */     if (type == OS.G_TYPE_INT64()) return Long.valueOf(OS.g_value_get_int64(value));
/* 4382 */     return Integer.valueOf(OS.g_value_get_int(value));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static AtkValueIface getParentValueIface(long atkObject)
/*      */   {
/* 4396 */     long type = GTK.GTK3 ? OS.swt_fixed_accessible_get_type() : OS.G_OBJECT_TYPE(atkObject);
/* 4397 */     if (OS.g_type_is_a(OS.g_type_parent(type), ATK.ATK_TYPE_VALUE())) {
/* 4398 */       AtkValueIface iface = new AtkValueIface();
/* 4399 */       ATK.memmove(iface, OS.g_type_interface_peek_parent(ATK.ATK_VALUE_GET_IFACE(atkObject)));
/* 4400 */       return iface;
/*      */     }
/* 4402 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static long atkValue_get_current_value(long atkObject, long value)
/*      */   {
/* 4419 */     AccessibleObject object = getAccessibleObject(atkObject);
/* 4420 */     AtkValueIface iface = getParentValueIface(atkObject);
/* 4421 */     if ((iface != null) && (iface.get_current_value != 0L)) {
/* 4422 */       ATK.call(iface.get_current_value, atkObject, value);
/*      */     }
/* 4424 */     if (object != null) {
/* 4425 */       Accessible accessible = object.accessible;
/* 4426 */       List<AccessibleValueListener> listeners = accessible.accessibleValueListeners;
/* 4427 */       int length = size(listeners);
/* 4428 */       if (length > 0) {
/* 4429 */         AccessibleValueEvent event = new AccessibleValueEvent(accessible);
/* 4430 */         event.value = getGValue(value);
/* 4431 */         for (int i = 0; i < length; i++) {
/* 4432 */           AccessibleValueListener listener = (AccessibleValueListener)listeners.get(i);
/* 4433 */           listener.getCurrentValue(event);
/*      */         }
/* 4435 */         setGValue(value, event.value);
/*      */       }
/*      */     }
/* 4438 */     return 0L;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static long atkValue_get_maximum_value(long atkObject, long value)
/*      */   {
/* 4456 */     AccessibleObject object = getAccessibleObject(atkObject);
/* 4457 */     AtkValueIface iface = getParentValueIface(atkObject);
/* 4458 */     if ((iface != null) && (iface.get_maximum_value != 0L)) {
/* 4459 */       ATK.call(iface.get_maximum_value, atkObject, value);
/*      */     }
/* 4461 */     if (object != null) {
/* 4462 */       Accessible accessible = object.accessible;
/* 4463 */       List<AccessibleValueListener> listeners = accessible.accessibleValueListeners;
/* 4464 */       int length = size(listeners);
/* 4465 */       if (length > 0) {
/* 4466 */         AccessibleValueEvent event = new AccessibleValueEvent(accessible);
/* 4467 */         event.value = getGValue(value);
/* 4468 */         for (int i = 0; i < length; i++) {
/* 4469 */           AccessibleValueListener listener = (AccessibleValueListener)listeners.get(i);
/* 4470 */           listener.getMaximumValue(event);
/*      */         }
/* 4472 */         setGValue(value, event.value);
/*      */       }
/*      */     }
/* 4475 */     return 0L;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static long atkValue_get_minimum_value(long atkObject, long value)
/*      */   {
/* 4493 */     AccessibleObject object = getAccessibleObject(atkObject);
/* 4494 */     AtkValueIface iface = getParentValueIface(atkObject);
/* 4495 */     if ((iface != null) && (iface.get_minimum_value != 0L)) {
/* 4496 */       ATK.call(iface.get_minimum_value, atkObject, value);
/*      */     }
/* 4498 */     if (object != null) {
/* 4499 */       Accessible accessible = object.accessible;
/* 4500 */       List<AccessibleValueListener> listeners = accessible.accessibleValueListeners;
/* 4501 */       int length = size(listeners);
/* 4502 */       if (length > 0) {
/* 4503 */         AccessibleValueEvent event = new AccessibleValueEvent(accessible);
/* 4504 */         event.value = getGValue(value);
/* 4505 */         for (int i = 0; i < length; i++) {
/* 4506 */           AccessibleValueListener listener = (AccessibleValueListener)listeners.get(i);
/* 4507 */           listener.getMinimumValue(event);
/*      */         }
/* 4509 */         setGValue(value, event.value);
/*      */       }
/*      */     }
/* 4512 */     return 0L;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static long atkValue_set_current_value(long atkObject, long value)
/*      */   {
/* 4529 */     AccessibleObject object = getAccessibleObject(atkObject);
/* 4530 */     if (object != null) {
/* 4531 */       Accessible accessible = object.accessible;
/* 4532 */       List<AccessibleValueListener> listeners = accessible.accessibleValueListeners;
/* 4533 */       int length = size(listeners);
/* 4534 */       if (length > 0) {
/* 4535 */         AccessibleValueEvent event = new AccessibleValueEvent(accessible);
/* 4536 */         event.value = getGValue(value);
/* 4537 */         for (int i = 0; i < length; i++) {
/* 4538 */           AccessibleValueListener listener = (AccessibleValueListener)listeners.get(i);
/* 4539 */           listener.setCurrentValue(event);
/*      */         }
/* 4541 */         return event.value != null ? 1L : 0L;
/*      */       }
/*      */     }
/* 4544 */     long parentResult = 0L;
/* 4545 */     AtkValueIface iface = getParentValueIface(atkObject);
/* 4546 */     if ((iface != null) && (iface.set_current_value != 0L)) {
/* 4547 */       parentResult = ATK.call(iface.set_current_value, atkObject, value);
/*      */     }
/* 4549 */     return parentResult;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static AccessibleObject getAccessibleObject(long atkObject)
/*      */   {
/* 4561 */     AccessibleObject object = (AccessibleObject)AccessibleObjects.get(new org.eclipse.swt.internal.LONG(atkObject));
/* 4562 */     if (object == null) return null;
/* 4563 */     if (object.accessible == null) return null;
/* 4564 */     org.eclipse.swt.widgets.Control control = object.accessible.control;
/* 4565 */     if ((control == null) || (control.isDisposed())) return null;
/* 4566 */     return object;
/*      */   }
/*      */   
/*      */   AccessibleObject getChildByID(int childId) {
/* 4570 */     if (childId == -1) return this;
/* 4571 */     if ((childId == -2) || (childId == -3)) return null;
/* 4572 */     if (this.children != null) {
/* 4573 */       for (int i = 0; i < this.children.length; i++) {
/* 4574 */         AccessibleObject child = this.children[i];
/* 4575 */         if ((child != null) && (child.id == childId)) return child;
/*      */       }
/*      */     }
/* 4578 */     return null;
/*      */   }
/*      */   
/*      */   AccessibleObject getChildByIndex(int childIndex) {
/* 4582 */     if ((this.children != null) && (childIndex < this.children.length)) return this.children[childIndex];
/* 4583 */     return null;
/*      */   }
/*      */   
/*      */   String getText() {
/* 4587 */     List<AccessibleControlListener> listeners = this.accessible.accessibleControlListeners;
/* 4588 */     int length = size(listeners);
/* 4589 */     if (length > 0) {
/* 4590 */       String parentText = "";
/* 4591 */       AtkTextIface iface = getParentTextIface(this.atkHandle);
/* 4592 */       if ((iface != null) && (iface.get_character_count != 0L)) {
/* 4593 */         long characterCount = ATK.call(iface.get_character_count, this.atkHandle);
/* 4594 */         if ((characterCount > 0L) && (iface.get_text != 0L)) {
/* 4595 */           long parentResult = ATK.call(iface.get_text, this.atkHandle, 0L, characterCount);
/* 4596 */           if (parentResult != 0L) {
/* 4597 */             parentText = getString(parentResult);
/* 4598 */             OS.g_free(parentResult);
/*      */           }
/*      */         }
/*      */       }
/* 4602 */       AccessibleControlEvent event = new AccessibleControlEvent(this.accessible);
/* 4603 */       event.childID = this.id;
/* 4604 */       event.result = parentText;
/* 4605 */       for (int i = 0; i < length; i++) {
/* 4606 */         AccessibleControlListener listener = (AccessibleControlListener)listeners.get(i);
/* 4607 */         listener.getValue(event);
/*      */       }
/* 4609 */       return event.result;
/*      */     }
/* 4611 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static long gObjectClass_finalize(long atkObject)
/*      */   {
/* 4620 */     if (!GTK.GTK3) {
/* 4621 */       long superType = OS.g_type_class_peek_parent(OS.G_OBJECT_GET_CLASS(atkObject));
/* 4622 */       long gObjectClass = OS.G_OBJECT_CLASS(superType);
/* 4623 */       org.eclipse.swt.internal.gtk.GObjectClass objectClassStruct = new org.eclipse.swt.internal.gtk.GObjectClass();
/* 4624 */       OS.memmove(objectClassStruct, gObjectClass);
/* 4625 */       ATK.call(objectClassStruct.finalize, atkObject);
/*      */     }
/* 4627 */     AccessibleObject object = (AccessibleObject)AccessibleObjects.get(new org.eclipse.swt.internal.LONG(atkObject));
/* 4628 */     if (object != null) {
/* 4629 */       AccessibleObjects.remove(new org.eclipse.swt.internal.LONG(atkObject));
/*      */     }
/* 4631 */     return 0L;
/*      */   }
/*      */   
/*      */   static int toATKRelation(int relation) {
/* 4635 */     switch (relation) {
/* 4636 */     case 0:  return 1;
/* 4637 */     case 1:  return 2;
/* 4638 */     case 2:  return 14;
/* 4639 */     case 3:  return 15;
/* 4640 */     case 4:  return 11;
/* 4641 */     case 5:  return 10;
/* 4642 */     case 6:  return 8;
/* 4643 */     case 7:  return 7;
/* 4644 */     case 8:  return 3;
/* 4645 */     case 9:  return 4;
/* 4646 */     case 10:  return 5;
/* 4647 */     case 11:  return 6;
/* 4648 */     case 12:  return 13;
/* 4649 */     case 13:  return 12;
/* 4650 */     case 14:  return 9;
/*      */     }
/* 4652 */     return 0;
/*      */   }
/*      */   
/*      */   static void windowPoint(AccessibleObject object, int[] x, int[] y) {
/* 4656 */     long widget = GTK.gtk_accessible_get_widget(object.atkHandle);
/* 4657 */     while ((widget == 0L) && (object.parent != null)) {
/* 4658 */       object = object.parent;
/* 4659 */       widget = GTK.gtk_accessible_get_widget(object.atkHandle);
/*      */     }
/* 4661 */     if (widget == 0L) return;
/* 4662 */     long topLevel = GTK.gtk_widget_get_toplevel(widget);
/* 4663 */     long window = GTK.gtk_widget_get_window(topLevel);
/* 4664 */     org.eclipse.swt.internal.gtk.GDK.gdk_window_get_origin(window, x, y);
/*      */   }
/*      */   
/*      */   static int nextIndexOfChar(String string, String searchChars, int startIndex) {
/* 4668 */     int result = string.length();
/* 4669 */     for (int i = 0; i < searchChars.length(); i++) {
/* 4670 */       char current = searchChars.charAt(i);
/* 4671 */       int index = string.indexOf(current, startIndex);
/* 4672 */       if (index != -1) result = Math.min(result, index);
/*      */     }
/* 4674 */     return result;
/*      */   }
/*      */   
/*      */   static int nextIndexOfNotChar(String string, String searchChars, int startIndex) {
/* 4678 */     int length = string.length();
/* 4679 */     int index = startIndex;
/* 4680 */     while (index < length) {
/* 4681 */       char current = string.charAt(index);
/* 4682 */       if (searchChars.indexOf(current) == -1) break;
/* 4683 */       index++;
/*      */     }
/* 4685 */     return index;
/*      */   }
/*      */   
/*      */   static int previousIndexOfChar(String string, String searchChars, int startIndex) {
/* 4689 */     int result = -1;
/* 4690 */     if (startIndex < 0) return result;
/* 4691 */     string = string.substring(0, startIndex);
/* 4692 */     for (int i = 0; i < searchChars.length(); i++) {
/* 4693 */       char current = searchChars.charAt(i);
/* 4694 */       int index = string.lastIndexOf(current);
/* 4695 */       if (index != -1) result = Math.max(result, index);
/*      */     }
/* 4697 */     return result;
/*      */   }
/*      */   
/*      */   static int previousIndexOfNotChar(String string, String searchChars, int startIndex) {
/* 4701 */     if (startIndex < 0) return -1;
/* 4702 */     int index = startIndex - 1;
/* 4703 */     while (index >= 0) {
/* 4704 */       char current = string.charAt(index);
/* 4705 */       if (searchChars.indexOf(current) == -1) break;
/* 4706 */       index--;
/*      */     }
/* 4708 */     return index;
/*      */   }
/*      */   
/*      */   void addRelation(int type, Accessible target) {
/* 4712 */     AccessibleObject targetAccessibleObject = target.getAccessibleObject();
/* 4713 */     if (targetAccessibleObject != null)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4722 */       ATK.atk_object_add_relationship(this.atkHandle, toATKRelation(type), targetAccessibleObject.atkHandle);
/*      */     }
/*      */   }
/*      */   
/*      */   void release() {
/* 4727 */     this.accessible = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 4732 */     if (this.children != null) {
/* 4733 */       for (int i = 0; i < this.children.length; i++) {
/* 4734 */         AccessibleObject child = this.children[i];
/* 4735 */         if (child != null) OS.g_object_unref(child.atkHandle);
/*      */       }
/* 4737 */       this.children = null;
/*      */     }
/* 4739 */     if (this.isLightweight) {
/* 4740 */       OS.g_object_unref(this.atkHandle);
/*      */     }
/*      */   }
/*      */   
/*      */   void removeRelation(int type, Accessible target) {
/* 4745 */     AccessibleObject targetAccessibleObject = target.getAccessibleObject();
/* 4746 */     if (targetAccessibleObject != null)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4755 */       ATK.atk_object_remove_relationship(this.atkHandle, toATKRelation(type), targetAccessibleObject.atkHandle);
/*      */     }
/*      */   }
/*      */   
/*      */   void selectionChanged() {
/* 4760 */     OS.g_signal_emit_by_name(this.atkHandle, ATK.selection_changed);
/*      */   }
/*      */   
/*      */   void sendEvent(int event, Object eventData) {
/* 4764 */     switch (event) {
/*      */     case 32777: 
/* 4766 */       OS.g_signal_emit_by_name(this.atkHandle, ATK.selection_changed);
/* 4767 */       break;
/*      */     case 32788: 
/* 4769 */       OS.g_signal_emit_by_name(this.atkHandle, ATK.text_selection_changed);
/* 4770 */       break;
/*      */     case 32778: 
/* 4772 */       if ((eventData instanceof int[])) {
/* 4773 */         int[] array = (int[])eventData;
/* 4774 */         int state = array[0];
/* 4775 */         int value = array[1];
/* 4776 */         int atkState = -1;
/* 4777 */         switch (state) {
/* 4778 */         case 2:  atkState = 21; break;
/* 4779 */         case 2097152:  atkState = 20; break;
/* 4780 */         case 16777216:  atkState = 16; break;
/* 4781 */         case 4:  atkState = 11; break;
/* 4782 */         case 1048576:  atkState = 10; break;
/* 4783 */         case 8:  atkState = 18; break;
/* 4784 */         case 16:  atkState = 4; break;
/* 4785 */         case 512:  atkState = 9; break;
/* 4786 */         case 1024:  atkState = 9; break;
/* 4787 */         case 128:  atkState = 2; break;
/* 4788 */         case 2048:  atkState = 3; break;
/* 4789 */         case 64:  atkState = 6; break;
/* 4790 */         case 32768:  atkState = 28; break;
/* 4791 */         case 65536:  atkState = 23; break;
/* 4792 */         case 131072:  atkState = 19; break;
/*      */         case 4194304: 
/*      */           break; case 1:  atkState = 7; break;
/* 4795 */         case 67108864:  atkState = 1; break;
/* 4796 */         case 134217728:  atkState = 24; break;
/* 4797 */         case 268435456:  atkState = 15; break;
/* 4798 */         case 33554432:  atkState = 32; break;
/* 4799 */         case 536870912:  atkState = 33; break;
/* 4800 */         case 1073741824:  atkState = 34;
/*      */         }
/* 4802 */         if (atkState != -1)
/* 4803 */           ATK.atk_object_notify_state_change(this.atkHandle, atkState, value != 0); }
/* 4804 */       break;
/*      */     
/*      */     case 32779: 
/* 4807 */       List<AccessibleControlListener> listeners = this.accessible.accessibleControlListeners;
/* 4808 */       int length = size(listeners);
/* 4809 */       org.eclipse.swt.internal.gtk.GdkRectangle rect = new org.eclipse.swt.internal.gtk.GdkRectangle();
/* 4810 */       if (length > 0) {
/* 4811 */         AccessibleControlEvent e = new AccessibleControlEvent(this.accessible);
/* 4812 */         e.childID = this.id;
/* 4813 */         for (int i = 0; i < length; i++) {
/* 4814 */           AccessibleControlListener listener = (AccessibleControlListener)listeners.get(i);
/* 4815 */           listener.getLocation(e);
/*      */         }
/* 4817 */         rect.x = e.x;
/* 4818 */         rect.y = e.y;
/* 4819 */         rect.width = e.width;
/* 4820 */         rect.height = e.height;
/*      */       }
/* 4822 */       OS.g_signal_emit_by_name(this.atkHandle, ATK.bounds_changed, rect);
/* 4823 */       break;
/*      */     
/*      */     case 32780: 
/* 4826 */       OS.g_object_notify(this.atkHandle, ATK.accessible_name);
/* 4827 */       break;
/*      */     case 32781: 
/* 4829 */       OS.g_object_notify(this.atkHandle, ATK.accessible_description);
/* 4830 */       break;
/*      */     case 32782: 
/* 4832 */       OS.g_object_notify(this.atkHandle, ATK.accessible_value);
/* 4833 */       break;
/*      */     case 261: 
/* 4835 */       OS.g_signal_emit_by_name(this.atkHandle, ATK.load_complete);
/* 4836 */       break;
/*      */     case 262: 
/* 4838 */       OS.g_signal_emit_by_name(this.atkHandle, ATK.load_stopped);
/* 4839 */       break;
/*      */     case 263: 
/* 4841 */       OS.g_signal_emit_by_name(this.atkHandle, ATK.reload);
/* 4842 */       break;
/*      */     case 273: 
/*      */       break;
/*      */     case 274: 
/*      */       break;
/*      */     case 256: 
/*      */       break;
/*      */     case 264: 
/* 4850 */       OS.g_object_notify(this.atkHandle, ATK.end_index);
/* 4851 */       break;
/*      */     case 265: 
/* 4853 */       OS.g_object_notify(this.atkHandle, ATK.number_of_anchors);
/* 4854 */       break;
/*      */     case 266: 
/* 4856 */       OS.g_object_notify(this.atkHandle, ATK.selected_link);
/* 4857 */       break;
/*      */     case 269: 
/* 4859 */       OS.g_object_notify(this.atkHandle, ATK.start_index);
/* 4860 */       break;
/*      */     case 267: 
/* 4862 */       OS.g_signal_emit_by_name(this.atkHandle, ATK.link_activated);
/* 4863 */       break;
/*      */     case 268: 
/* 4865 */       if ((eventData instanceof Integer)) {
/* 4866 */         int index = ((Integer)eventData).intValue();
/* 4867 */         OS.g_signal_emit_by_name(this.atkHandle, ATK.link_selected, index); }
/* 4868 */       break;
/*      */     case 271: 
/* 4870 */       OS.g_object_notify(this.atkHandle, ATK.accessible_hypertext_nlinks);
/* 4871 */       break;
/*      */     case 512: 
/* 4873 */       OS.g_signal_emit_by_name(this.atkHandle, ATK.attributes_changed);
/* 4874 */       break;
/*      */     case 515: 
/* 4876 */       OS.g_object_notify(this.atkHandle, ATK.accessible_table_caption_object);
/* 4877 */       break;
/*      */     case 516: 
/* 4879 */       OS.g_object_notify(this.atkHandle, ATK.accessible_table_column_description);
/* 4880 */       break;
/*      */     case 517: 
/* 4882 */       OS.g_object_notify(this.atkHandle, ATK.accessible_table_column_header);
/* 4883 */       break;
/*      */     case 518: 
/* 4885 */       if ((eventData instanceof int[])) {
/* 4886 */         int[] array = (int[])eventData;
/* 4887 */         int type = array[0];
/* 4888 */         int rowStart = array[1];
/* 4889 */         int rowCount = array[2];
/* 4890 */         int columnStart = array[3];
/* 4891 */         int columnCount = array[4];
/* 4892 */         switch (type) {
/*      */         case 1: 
/* 4894 */           if (rowCount > 0) OS.g_signal_emit_by_name(this.atkHandle, ATK.row_deleted, rowStart, rowCount);
/* 4895 */           if (columnCount > 0) OS.g_signal_emit_by_name(this.atkHandle, ATK.column_deleted, columnStart, columnCount);
/*      */           break;
/*      */         case 0: 
/* 4898 */           if (rowCount > 0) OS.g_signal_emit_by_name(this.atkHandle, ATK.row_inserted, rowStart, rowCount);
/* 4899 */           if (columnCount > 0) OS.g_signal_emit_by_name(this.atkHandle, ATK.column_inserted, columnStart, columnCount);
/*      */           break; }
/*      */       }
/* 4902 */       break;
/*      */     
/*      */     case 519: 
/* 4905 */       OS.g_object_notify(this.atkHandle, ATK.accessible_table_row_description);
/* 4906 */       break;
/*      */     case 520: 
/* 4908 */       OS.g_object_notify(this.atkHandle, ATK.accessible_table_row_header);
/* 4909 */       break;
/*      */     case 521: 
/* 4911 */       OS.g_object_notify(this.atkHandle, ATK.accessible_table_summary);
/* 4912 */       break;
/*      */     case 522: 
/* 4914 */       OS.g_signal_emit_by_name(this.atkHandle, ATK.text_attributes_changed);
/* 4915 */       break;
/*      */     case 283: 
/*      */     case 285: 
/* 4918 */       int offset = 0;
/* 4919 */       List<AccessibleTextExtendedListener> listeners = this.accessible.accessibleTextExtendedListeners;
/* 4920 */       int length = size(listeners);
/* 4921 */       AccessibleTextEvent e = new AccessibleTextEvent(this.accessible);
/* 4922 */       if (length > 0) {
/* 4923 */         for (int i = 0; i < length; i++) {
/* 4924 */           AccessibleTextListener listener = (AccessibleTextListener)listeners.get(i);
/* 4925 */           listener.getCaretOffset(e);
/*      */         }
/*      */       } else {
/* 4928 */         List<AccessibleTextListener> listeners2 = this.accessible.accessibleTextListeners;
/* 4929 */         length = size(listeners2);
/* 4930 */         if (length > 0) {
/* 4931 */           e.childID = this.id;
/* 4932 */           for (int i = 0; i < length; i++) {
/* 4933 */             AccessibleTextListener listener = (AccessibleTextListener)listeners2.get(i);
/* 4934 */             listener.getCaretOffset(e);
/*      */           }
/*      */         }
/*      */       }
/* 4938 */       offset = e.offset;
/* 4939 */       OS.g_signal_emit_by_name(this.atkHandle, ATK.text_caret_moved, offset);
/* 4940 */       break;
/*      */     
/*      */     case 524: 
/* 4943 */       if ((eventData instanceof Object[])) {
/* 4944 */         Object[] data = (Object[])eventData;
/* 4945 */         int type = ((Integer)data[0]).intValue();
/* 4946 */         int start = ((Integer)data[1]).intValue();
/* 4947 */         int end = ((Integer)data[2]).intValue();
/* 4948 */         switch (type) {
/*      */         case 1: 
/* 4950 */           OS.g_signal_emit_by_name(this.atkHandle, ATK.text_changed_delete, start, end - start);
/* 4951 */           break;
/*      */         case 0: 
/* 4953 */           OS.g_signal_emit_by_name(this.atkHandle, ATK.text_changed_insert, start, end - start);
/*      */         }
/*      */       }
/* 4956 */       break;
/*      */     }
/*      */   }
/*      */   
/*      */   void sendEvent(int event, Object eventData, int childID)
/*      */   {
/* 4962 */     updateChildren();
/* 4963 */     AccessibleObject accObject = getChildByID(childID);
/* 4964 */     if (accObject != null) {
/* 4965 */       accObject.sendEvent(event, eventData);
/*      */     }
/*      */   }
/*      */   
/*      */   void setFocus(int childID) {
/* 4970 */     updateChildren();
/* 4971 */     AccessibleObject accObject = getChildByID(childID);
/* 4972 */     if (accObject != null) {
/* 4973 */       OS.g_signal_emit_by_name(accObject.atkHandle, ATK.focus_event, 1L, 0L);
/* 4974 */       ATK.atk_object_notify_state_change(accObject.atkHandle, 11, true);
/*      */     }
/*      */   }
/*      */   
/*      */   void textCaretMoved(int index) {
/* 4979 */     OS.g_signal_emit_by_name(this.atkHandle, ATK.text_caret_moved, index);
/*      */   }
/*      */   
/*      */   void textChanged(int type, int startIndex, int length) {
/* 4983 */     if (type == 1) {
/* 4984 */       OS.g_signal_emit_by_name(this.atkHandle, ATK.text_changed_delete, startIndex, length);
/*      */     } else {
/* 4986 */       OS.g_signal_emit_by_name(this.atkHandle, ATK.text_changed_insert, startIndex, length);
/*      */     }
/*      */   }
/*      */   
/*      */   void textSelectionChanged() {
/* 4991 */     OS.g_signal_emit_by_name(this.atkHandle, ATK.text_selection_changed);
/*      */   }
/*      */   
/*      */   void updateChildren() {
/* 4995 */     List<AccessibleControlListener> listeners = this.accessible.accessibleControlListeners;
/* 4996 */     int length = size(listeners);
/* 4997 */     AccessibleControlEvent event = new AccessibleControlEvent(this.accessible);
/* 4998 */     event.childID = this.id;
/* 4999 */     for (int i = 0; i < length; i++) {
/* 5000 */       AccessibleControlListener listener = (AccessibleControlListener)listeners.get(i);
/* 5001 */       listener.getChildren(event);
/*      */     }
/* 5003 */     Object[] children = event.children;
/* 5004 */     AccessibleObject[] oldChildren = this.children;
/* 5005 */     int count = children != null ? children.length : 0;
/* 5006 */     AccessibleObject[] newChildren = new AccessibleObject[count];
/* 5007 */     for (int i = 0; i < count; i++) {
/* 5008 */       Object child = children[i];
/* 5009 */       AccessibleObject object = null;
/*      */       
/* 5011 */       if ((child instanceof Integer)) {
/* 5012 */         int id = ((Integer)child).intValue();
/* 5013 */         object = (oldChildren != null) && (i < oldChildren.length) ? oldChildren[i] : null;
/* 5014 */         if ((object == null) || (object.id != id)) {
/* 5015 */           event = new AccessibleControlEvent(this.accessible);
/* 5016 */           event.childID = id;
/* 5017 */           for (int j = 0; j < length; j++) {
/* 5018 */             AccessibleControlListener listener = (AccessibleControlListener)listeners.get(j);
/* 5019 */             listener.getChild(event);
/*      */           }
/* 5021 */           if (event.accessible != null) {
/* 5022 */             object = event.accessible.getAccessibleObject();
/* 5023 */             if (object != null) OS.g_object_ref(object.atkHandle);
/*      */           }
/* 5025 */           else if (GTK.GTK3) {
/* 5026 */             long type = OS.G_OBJECT_TYPE(this.accessible.getControlHandle());
/* 5027 */             long widget = this.accessible.getControlHandle();
/* 5028 */             object = new AccessibleObject(type, widget, this.accessible, true);
/*      */           } else {
/* 5030 */             object = AccessibleFactory.createChildAccessible(this.accessible, id);
/*      */           }
/*      */           
/* 5033 */           object.id = id;
/*      */         } else {
/* 5035 */           OS.g_object_ref(object.atkHandle);
/*      */         }
/* 5037 */       } else if ((child instanceof Accessible)) {
/* 5038 */         object = ((Accessible)child).getAccessibleObject();
/* 5039 */         if (object != null) OS.g_object_ref(object.atkHandle);
/*      */       }
/* 5041 */       if (object != null) {
/* 5042 */         object.index = i;
/* 5043 */         object.parent = this;
/* 5044 */         newChildren[i] = object;
/*      */       }
/*      */     }
/* 5047 */     if (oldChildren != null) {
/* 5048 */       for (int i = 0; i < oldChildren.length; i++) {
/* 5049 */         AccessibleObject object = oldChildren[i];
/* 5050 */         if (object != null) OS.g_object_unref(object.atkHandle);
/*      */       }
/*      */     }
/* 5053 */     this.children = newChildren;
/*      */   }
/*      */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/accessibility/AccessibleObject.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */