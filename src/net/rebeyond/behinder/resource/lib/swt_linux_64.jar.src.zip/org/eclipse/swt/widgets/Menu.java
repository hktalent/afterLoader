/*      */ package org.eclipse.swt.widgets;
/*      */ 
/*      */ import java.io.PrintStream;
/*      */ import org.eclipse.swt.SWT;
/*      */ import org.eclipse.swt.events.HelpListener;
/*      */ import org.eclipse.swt.events.MenuListener;
/*      */ import org.eclipse.swt.graphics.Point;
/*      */ import org.eclipse.swt.graphics.Rectangle;
/*      */ import org.eclipse.swt.internal.Converter;
/*      */ import org.eclipse.swt.internal.DPIUtil;
/*      */ import org.eclipse.swt.internal.ImageList;
/*      */ import org.eclipse.swt.internal.gtk.GDK;
/*      */ import org.eclipse.swt.internal.gtk.GTK;
/*      */ import org.eclipse.swt.internal.gtk.GdkEventButton;
/*      */ import org.eclipse.swt.internal.gtk.GdkEventKey;
/*      */ import org.eclipse.swt.internal.gtk.GdkRectangle;
/*      */ import org.eclipse.swt.internal.gtk.GtkAllocation;
/*      */ import org.eclipse.swt.internal.gtk.OS;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class Menu
/*      */   extends Widget
/*      */ {
/*      */   int x;
/*      */   int y;
/*      */   boolean hasLocation;
/*      */   MenuItem cascade;
/*      */   MenuItem selectedItem;
/*      */   Decorations parent;
/*      */   long imItem;
/*      */   long imSeparator;
/*      */   long imHandle;
/*      */   ImageList imageList;
/*      */   int poppedUpCount;
/*      */   
/*      */   public Menu(Control parent)
/*      */   {
/*   79 */     this(checkNull(parent).menuShell(), 8);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Menu(Decorations parent, int style)
/*      */   {
/*  120 */     super(parent, checkStyle(style));
/*  121 */     this.parent = parent;
/*  122 */     createWidget(0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Menu(Menu parentMenu)
/*      */   {
/*  150 */     this(checkNull(parentMenu).parent, 4);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Menu(MenuItem parentItem)
/*      */   {
/*  178 */     this(checkNull(parentItem).parent);
/*      */   }
/*      */   
/*      */   static Control checkNull(Control control) {
/*  182 */     if (control == null) SWT.error(4);
/*  183 */     return control;
/*      */   }
/*      */   
/*      */   static Menu checkNull(Menu menu) {
/*  187 */     if (menu == null) SWT.error(4);
/*  188 */     return menu;
/*      */   }
/*      */   
/*      */   static MenuItem checkNull(MenuItem item) {
/*  192 */     if (item == null) SWT.error(4);
/*  193 */     return item;
/*      */   }
/*      */   
/*      */   static int checkStyle(int style) {
/*  197 */     return checkBits(style, 8, 2, 4, 0, 0, 0);
/*      */   }
/*      */   
/*      */   void _setVisible(boolean visible) {
/*  201 */     if (visible == GTK.gtk_widget_get_mapped(this.handle)) return;
/*  202 */     if (visible) {
/*  203 */       sendEvent(22);
/*  204 */       if (getItemCount() != 0)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  211 */         if ((this.parent._getShell().style & 0x4000) != 0) {
/*  212 */           GTK.gtk_menu_shell_set_take_focus(this.handle, false);
/*      */         }
/*  214 */         if (GTK.GTK_VERSION < OS.VERSION(3, 22, 0)) {
/*  215 */           long address = 0L;
/*  216 */           this.hasLocation = false;
/*  217 */           long data = 0L;
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  225 */           TrayItem item = this.display.currentTrayItem;
/*  226 */           if ((item != null) && (!item.isDisposed())) {
/*  227 */             data = item.handle;
/*  228 */             address = GTK.gtk_status_icon_position_menu_func();
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  236 */           GTK.gtk_menu_popup(this.handle, 0L, 0L, address, data, 0, this.display.getLastEventTime());
/*      */         }
/*      */         else {
/*  239 */           long eventPtr = 0L;
/*  240 */           if (this.hasLocation)
/*      */           {
/*      */ 
/*  243 */             eventPtr = GDK.gdk_event_new(4);
/*  244 */             GdkEventButton event = new GdkEventButton();
/*  245 */             event.type = 4;
/*  246 */             event.device = GDK.gdk_get_pointer(GDK.gdk_display_get_default());
/*      */             
/*  248 */             event.window = GDK.gdk_display_get_default_group(GDK.gdk_display_get_default());
/*  249 */             OS.g_object_ref(event.window);
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*  254 */             int[] globalWindowOriginY = new int[1];
/*  255 */             int[] globalWindowOriginX = new int[1];
/*  256 */             GDK.gdk_window_get_origin(event.window, globalWindowOriginX, globalWindowOriginY);
/*      */             
/*  258 */             event.time = this.display.getLastEventTime();
/*  259 */             OS.memmove(eventPtr, event, GdkEventButton.sizeof);
/*      */             
/*      */ 
/*  262 */             GdkRectangle rect = new GdkRectangle();
/*  263 */             rect.x = (this.x - globalWindowOriginX[0]);
/*  264 */             rect.y = (this.y - globalWindowOriginY[0]);
/*      */             
/*      */ 
/*  267 */             GTK.gtk_menu_popup_at_rect(this.handle, event.window, rect, 1, 1, eventPtr);
/*      */             
/*  269 */             GDK.gdk_event_free(eventPtr);
/*      */ 
/*      */ 
/*      */           }
/*      */           else
/*      */           {
/*      */ 
/*  276 */             eventPtr = GTK.gtk_get_current_event();
/*  277 */             if (eventPtr == 0L) {
/*  278 */               eventPtr = GDK.gdk_event_new(4);
/*  279 */               GdkEventButton event = new GdkEventButton();
/*  280 */               event.type = 4;
/*      */               
/*  282 */               if (OS.isX11()) {
/*  283 */                 event.window = OS.g_object_ref(GTK.gtk_widget_get_window(getShell().handle));
/*      */               }
/*  285 */               event.device = GDK.gdk_get_pointer(GDK.gdk_display_get_default());
/*  286 */               event.time = this.display.getLastEventTime();
/*  287 */               OS.memmove(eventPtr, event, GdkEventButton.sizeof);
/*      */             }
/*  289 */             adjustParentWindowWayland(eventPtr);
/*  290 */             verifyMenuPosition(getItemCount());
/*  291 */             GTK.gtk_menu_popup_at_pointer(this.handle, eventPtr);
/*  292 */             GDK.gdk_event_free(eventPtr);
/*      */           }
/*      */         }
/*  295 */         this.poppedUpCount = getItemCount();
/*      */       } else {
/*  297 */         sendEvent(23);
/*      */       }
/*      */     } else {
/*  300 */       GTK.gtk_menu_popdown(this.handle);
/*      */     }
/*      */   }
/*      */   
/*      */   void addAccelerators(long accelGroup) {
/*  305 */     MenuItem[] items = getItems();
/*  306 */     for (int i = 0; i < items.length; i++) {
/*  307 */       MenuItem item = items[i];
/*  308 */       item.addAccelerators(accelGroup);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addMenuListener(MenuListener listener)
/*      */   {
/*  332 */     checkWidget();
/*  333 */     if (listener == null) error(4);
/*  334 */     TypedListener typedListener = new TypedListener(listener);
/*  335 */     addListener(23, typedListener);
/*  336 */     addListener(22, typedListener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addHelpListener(HelpListener listener)
/*      */   {
/*  359 */     checkWidget();
/*  360 */     if (listener == null) error(4);
/*  361 */     TypedListener typedListener = new TypedListener(listener);
/*  362 */     addListener(28, typedListener);
/*      */   }
/*      */   
/*      */   void createHandle(int index)
/*      */   {
/*  367 */     this.state |= 0x8;
/*  368 */     if ((this.style & 0x2) != 0) {
/*  369 */       this.handle = GTK.gtk_menu_bar_new();
/*  370 */       if (this.handle == 0L) error(2);
/*  371 */       long vboxHandle = this.parent.vboxHandle;
/*  372 */       GTK.gtk_container_add(vboxHandle, this.handle);
/*  373 */       GTK.gtk_box_set_child_packing(vboxHandle, this.handle, false, true, 0, 0);
/*      */     } else {
/*  375 */       this.handle = GTK.gtk_menu_new();
/*  376 */       if (this.handle == 0L) error(2);
/*      */     }
/*      */   }
/*      */   
/*      */   void createIMMenu(long imHandle) {
/*  381 */     boolean showInputMethod = false;
/*  382 */     long settings = GTK.gtk_settings_get_default();
/*  383 */     if ((settings != 0L) && (GTK.GTK_VERSION < OS.VERSION(3, 10, 0))) {
/*  384 */       int[] buffer = new int[1];
/*  385 */       OS.g_object_get(settings, GTK.gtk_show_input_method_menu, buffer, 0L);
/*  386 */       showInputMethod = buffer[0] != 0;
/*      */     }
/*  388 */     if ((imHandle == 0L) || (!showInputMethod)) {
/*  389 */       this.imHandle = 0L;
/*  390 */       if (this.imItem != 0L) {
/*  391 */         GTK.gtk_widget_destroy(this.imItem);
/*  392 */         this.imItem = 0L;
/*      */       }
/*  394 */       if (this.imSeparator != 0L) {
/*  395 */         GTK.gtk_widget_destroy(this.imSeparator);
/*  396 */         this.imSeparator = 0L;
/*      */       }
/*  398 */       return;
/*      */     }
/*  400 */     if (this.imHandle == imHandle) return;
/*  401 */     this.imHandle = imHandle;
/*      */     
/*  403 */     if (this.imSeparator == 0L) {
/*  404 */       this.imSeparator = GTK.gtk_separator_menu_item_new();
/*  405 */       GTK.gtk_widget_show(this.imSeparator);
/*  406 */       GTK.gtk_menu_shell_insert(this.handle, this.imSeparator, -1);
/*      */     }
/*  408 */     if (this.imItem == 0L) {
/*  409 */       byte[] buffer = Converter.wcsToMbcs(SWT.getMessage("SWT_InputMethods"), true);
/*  410 */       if (GTK.GTK3) {
/*  411 */         this.imItem = GTK.gtk_menu_item_new();
/*  412 */         if (this.imItem == 0L) error(2);
/*  413 */         long imageHandle = 0L;
/*  414 */         long labelHandle = GTK.gtk_accel_label_new(buffer);
/*  415 */         if (labelHandle == 0L) error(2);
/*  416 */         if (GTK.GTK_VERSION >= OS.VERSION(3, 16, 0)) {
/*  417 */           GTK.gtk_label_set_xalign(labelHandle, 0.0F);
/*  418 */           GTK.gtk_widget_set_halign(labelHandle, 0);
/*      */         } else {
/*  420 */           GTK.gtk_misc_set_alignment(labelHandle, 0.0F, 0.0F);
/*      */         }
/*  422 */         long boxHandle = gtk_box_new(0, false, 0);
/*  423 */         if (boxHandle == 0L) error(2);
/*  424 */         if (OS.SWT_PADDED_MENU_ITEMS) {
/*  425 */           imageHandle = GTK.gtk_image_new();
/*  426 */           if (imageHandle == 0L) error(2);
/*  427 */           GTK.gtk_image_set_pixel_size(imageHandle, 16);
/*  428 */           if (boxHandle != 0L) {
/*  429 */             GTK.gtk_container_add(boxHandle, imageHandle);
/*  430 */             GTK.gtk_widget_show(imageHandle);
/*      */           }
/*      */         }
/*  433 */         if ((labelHandle != 0L) && (boxHandle != 0L)) {
/*  434 */           GTK.gtk_box_pack_end(boxHandle, labelHandle, true, true, 0);
/*  435 */           GTK.gtk_widget_show(labelHandle);
/*      */         }
/*  437 */         if (boxHandle != 0L) {
/*  438 */           GTK.gtk_container_add(this.imItem, boxHandle);
/*  439 */           GTK.gtk_widget_show(boxHandle);
/*      */         }
/*      */       } else {
/*  442 */         this.imItem = GTK.gtk_image_menu_item_new_with_label(buffer);
/*  443 */         if (this.imItem == 0L) error(2);
/*      */       }
/*  445 */       GTK.gtk_widget_show(this.imItem);
/*  446 */       GTK.gtk_menu_shell_insert(this.handle, this.imItem, -1);
/*      */     }
/*  448 */     long imSubmenu = GTK.gtk_menu_new();
/*  449 */     GTK.gtk_im_multicontext_append_menuitems(imHandle, imSubmenu);
/*  450 */     GTK.gtk_menu_item_set_submenu(this.imItem, imSubmenu);
/*      */   }
/*      */   
/*      */   void createWidget(int index)
/*      */   {
/*  455 */     checkOrientation(this.parent);
/*  456 */     super.createWidget(index);
/*  457 */     this.parent.addMenu(this);
/*      */   }
/*      */   
/*      */   void fixMenus(Decorations newParent) {
/*  461 */     if (isDisposed()) {
/*  462 */       return;
/*      */     }
/*  464 */     MenuItem[] items = getItems();
/*  465 */     for (int i = 0; i < items.length; i++) {
/*  466 */       items[i].fixMenus(newParent);
/*      */     }
/*  468 */     this.parent.removeMenu(this);
/*  469 */     newParent.addMenu(this);
/*  470 */     this.parent = newParent;
/*      */   }
/*      */   
/*      */   Rectangle getBounds() {
/*  474 */     checkWidget();
/*  475 */     if (!GTK.gtk_widget_get_mapped(this.handle)) {
/*  476 */       return new Rectangle(0, 0, 0, 0);
/*      */     }
/*  478 */     long window = gtk_widget_get_window(this.handle);
/*  479 */     int[] origin_x = new int[1];int[] origin_y = new int[1];
/*  480 */     GDK.gdk_window_get_origin(window, origin_x, origin_y);
/*  481 */     GtkAllocation allocation = new GtkAllocation();
/*  482 */     GTK.gtk_widget_get_allocation(this.handle, allocation);
/*  483 */     int x = origin_x[0] + allocation.x;
/*  484 */     int y = origin_y[0] + allocation.y;
/*  485 */     int width = allocation.width;
/*  486 */     int height = allocation.height;
/*  487 */     return new Rectangle(x, y, width, height);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public MenuItem getDefaultItem()
/*      */   {
/*  503 */     checkWidget();
/*  504 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getEnabled()
/*      */   {
/*  523 */     checkWidget();
/*  524 */     return GTK.gtk_widget_get_sensitive(this.handle);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public MenuItem getItem(int index)
/*      */   {
/*  543 */     checkWidget();
/*  544 */     long list = GTK.gtk_container_get_children(this.handle);
/*  545 */     if (list == 0L) error(8);
/*  546 */     int count = OS.g_list_length(list);
/*  547 */     if (this.imSeparator != 0L) count--;
/*  548 */     if (this.imItem != 0L) count--;
/*  549 */     if ((0 > index) || (index >= count)) error(6);
/*  550 */     long data = OS.g_list_nth_data(list, index);
/*  551 */     OS.g_list_free(list);
/*  552 */     if (data == 0L) error(8);
/*  553 */     return (MenuItem)this.display.getWidget(data);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getItemCount()
/*      */   {
/*  567 */     checkWidget();
/*  568 */     long list = GTK.gtk_container_get_children(this.handle);
/*  569 */     if (list == 0L) return 0;
/*  570 */     int count = OS.g_list_length(list);
/*  571 */     OS.g_list_free(list);
/*  572 */     if (this.imSeparator != 0L) count--;
/*  573 */     if (this.imItem != 0L) count--;
/*  574 */     return Math.max(0, count);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public MenuItem[] getItems()
/*      */   {
/*  594 */     checkWidget();
/*  595 */     long list = GTK.gtk_container_get_children(this.handle);
/*  596 */     if (list == 0L) return new MenuItem[0];
/*  597 */     long originalList = list;
/*  598 */     int count = OS.g_list_length(list);
/*  599 */     if (this.imSeparator != 0L) count--;
/*  600 */     if (this.imItem != 0L) count--;
/*  601 */     MenuItem[] items = new MenuItem[count];
/*  602 */     int index = 0;
/*  603 */     for (int i = 0; i < count; i++) {
/*  604 */       long data = OS.g_list_data(list);
/*  605 */       MenuItem item = (MenuItem)this.display.getWidget(data);
/*  606 */       if (item != null) items[(index++)] = item;
/*  607 */       list = OS.g_list_next(list);
/*      */     }
/*  609 */     OS.g_list_free(originalList);
/*  610 */     if (index != items.length) {
/*  611 */       MenuItem[] newItems = new MenuItem[index];
/*  612 */       System.arraycopy(items, 0, newItems, 0, index);
/*  613 */       items = newItems;
/*      */     }
/*  615 */     return items;
/*      */   }
/*      */   
/*      */   String getNameText()
/*      */   {
/*  620 */     String result = "";
/*  621 */     MenuItem[] items = getItems();
/*  622 */     int length = items.length;
/*  623 */     if (length > 0) {
/*  624 */       for (int i = 0; i < length - 1; i++) {
/*  625 */         result = result + items[i].getNameText() + ", ";
/*      */       }
/*  627 */       result = result + items[(length - 1)].getNameText();
/*      */     }
/*  629 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getOrientation()
/*      */   {
/*  646 */     checkWidget();
/*  647 */     return this.style & 0x6000000;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Decorations getParent()
/*      */   {
/*  661 */     checkWidget();
/*  662 */     return this.parent;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public MenuItem getParentItem()
/*      */   {
/*  678 */     checkWidget();
/*  679 */     return this.cascade;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Menu getParentMenu()
/*      */   {
/*  695 */     checkWidget();
/*  696 */     if (this.cascade == null) return null;
/*  697 */     return this.cascade.getParent();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Shell getShell()
/*      */   {
/*  717 */     checkWidget();
/*  718 */     return this.parent.getShell();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getVisible()
/*      */   {
/*  739 */     checkWidget();
/*  740 */     if ((this.style & 0x8) != 0) {
/*  741 */       Menu[] popups = this.display.popups;
/*  742 */       if (popups != null) {
/*  743 */         for (int i = 0; i < popups.length; i++) {
/*  744 */           if (popups[i] == this) return true;
/*      */         }
/*      */       }
/*      */     }
/*  748 */     return GTK.gtk_widget_get_mapped(this.handle);
/*      */   }
/*      */   
/*      */   long gtk_hide(long widget)
/*      */   {
/*  753 */     if (((this.style & 0x8) != 0) && 
/*  754 */       (this.display.activeShell != null)) {
/*  755 */       this.display.activeShell = getShell();
/*  756 */       this.display.activeShell.ignoreFocusOut = false;
/*      */     }
/*      */     
/*  759 */     sendEvent(23);
/*  760 */     if (OS.ubuntu_menu_proxy_get() != 0L) {
/*  761 */       MenuItem[] items = getItems();
/*  762 */       for (int i = 0; i < items.length; i++) {
/*  763 */         MenuItem item = items[i];
/*  764 */         if (item.updateAcceleratorText(false)) {}
/*      */       }
/*      */     }
/*  767 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_show(long widget)
/*      */   {
/*  772 */     if ((this.style & 0x8) != 0) {
/*  773 */       if (this.display.activeShell != null) {
/*  774 */         this.display.activeShell = getShell();
/*  775 */         this.display.activeShell.ignoreFocusOut = true;
/*      */       }
/*  777 */       return 0L;
/*      */     }
/*  779 */     sendEvent(22);
/*  780 */     if (OS.ubuntu_menu_proxy_get() != 0L) {
/*  781 */       MenuItem[] items = getItems();
/*  782 */       for (int i = 0; i < items.length; i++) {
/*  783 */         MenuItem item = items[i];
/*  784 */         if (item.updateAcceleratorText(true)) {}
/*      */       }
/*      */     }
/*  787 */     return 0L;
/*      */   }
/*      */   
/*      */ 
/*      */   long gtk_show_help(long widget, long helpType)
/*      */   {
/*  793 */     if (sendHelpEvent(helpType)) {
/*  794 */       GTK.gtk_menu_shell_deactivate(this.handle);
/*  795 */       return 1L;
/*      */     }
/*  797 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_menu_popped_up(long widget, long flipped_rect, long final_rect, long flipped_x, long flipped_y)
/*      */   {
/*  802 */     GdkRectangle finalRect = new GdkRectangle();
/*  803 */     OS.memmove(finalRect, final_rect, GDK.GdkRectangle_sizeof());
/*  804 */     GdkRectangle flippedRect = new GdkRectangle();
/*  805 */     OS.memmove(flippedRect, flipped_rect, GDK.GdkRectangle_sizeof());
/*  806 */     boolean flippedX = flipped_x == 1L;
/*  807 */     boolean flippedY = flipped_y == 1L;
/*  808 */     System.out.println("SWT_MENU_LOCATION_DEBUGGING enabled, printing positioning info for " + widget);
/*  809 */     if (!OS.isX11()) System.out.println("Note: SWT is running on Wayland, coordinates will be parent-relative");
/*  810 */     if (this.hasLocation) {
/*  811 */       System.out.println("hasLocation is true and set coordinates are Point {" + this.x + ", " + this.y + "}");
/*      */     } else {
/*  813 */       System.out.println("hasLocation is not set, this is most likely a right click menu");
/*      */     }
/*  815 */     if (flippedX) System.out.println("Menu is inverted along the X-axis");
/*  816 */     if (flippedY) System.out.println("Menu is inverted along the Y-axis");
/*  817 */     System.out.println("Final menu position and size is Rectangle {" + finalRect.x + ", " + finalRect.y + ", " + finalRect.width + ", " + finalRect.height + "}");
/*      */     
/*  819 */     System.out.println("Flipped menu position and size is Rectangle {" + flippedRect.x + ", " + flippedRect.y + ", " + flippedRect.width + ", " + flippedRect.height + "}");
/*      */     
/*  821 */     System.out.println("");
/*  822 */     return 0L;
/*      */   }
/*      */   
/*      */ 
/*      */   void hookEvents()
/*      */   {
/*  828 */     super.hookEvents();
/*  829 */     OS.g_signal_connect_closure_by_id(this.handle, this.display.signalIds[45], 0, this.display.getClosure(45), false);
/*  830 */     OS.g_signal_connect_closure_by_id(this.handle, this.display.signalIds[24], 0, this.display.getClosure(24), false);
/*      */     
/*  832 */     if ((GTK.GTK_VERSION >= OS.VERSION(3, 22, 0)) && (OS.SWT_MENU_LOCATION_DEBUGGING)) {
/*  833 */       OS.g_signal_connect_closure_by_id(this.handle, this.display.signalIds[85], 0, this.display.getClosure(85), false);
/*      */     }
/*  835 */     OS.g_signal_connect_closure_by_id(this.handle, this.display.signalIds[46], 0, this.display.getClosure(46), false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int indexOf(MenuItem item)
/*      */   {
/*  856 */     checkWidget();
/*  857 */     if (item == null) error(4);
/*  858 */     MenuItem[] items = getItems();
/*  859 */     for (int i = 0; i < items.length; i++) {
/*  860 */       if (items[i] == item) return i;
/*      */     }
/*  862 */     return -1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isEnabled()
/*      */   {
/*  881 */     checkWidget();
/*  882 */     Menu parentMenu = getParentMenu();
/*  883 */     if (parentMenu == null) {
/*  884 */       return (getEnabled()) && (this.parent.isEnabled());
/*      */     }
/*  886 */     return (getEnabled()) && (parentMenu.isEnabled());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isVisible()
/*      */   {
/*  904 */     checkWidget();
/*  905 */     return getVisible();
/*      */   }
/*      */   
/*      */   void releaseChildren(boolean destroy)
/*      */   {
/*  910 */     MenuItem[] items = getItems();
/*  911 */     for (int i = 0; i < items.length; i++) {
/*  912 */       MenuItem item = items[i];
/*  913 */       if ((item != null) && (!item.isDisposed())) {
/*  914 */         item.release(false);
/*      */       }
/*      */     }
/*  917 */     super.releaseChildren(destroy);
/*      */   }
/*      */   
/*      */   void releaseParent()
/*      */   {
/*  922 */     super.releaseParent();
/*  923 */     if (this.cascade != null) this.cascade.setMenu(null);
/*  924 */     if (((this.style & 0x2) != 0) && (this == this.parent.menuBar)) {
/*  925 */       this.parent.setMenuBar(null);
/*      */     }
/*  927 */     else if ((this.style & 0x8) != 0) {
/*  928 */       this.display.removePopup(this);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   void releaseWidget()
/*      */   {
/*  935 */     super.releaseWidget();
/*  936 */     if (this.parent != null) this.parent.removeMenu(this);
/*  937 */     this.parent = null;
/*  938 */     this.cascade = null;
/*  939 */     this.imItem = (this.imSeparator = this.imHandle = 0L);
/*  940 */     if (this.imageList != null) this.imageList.dispose();
/*  941 */     this.imageList = null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeMenuListener(MenuListener listener)
/*      */   {
/*  962 */     checkWidget();
/*  963 */     if (listener == null) error(4);
/*  964 */     if (this.eventTable == null) return;
/*  965 */     this.eventTable.unhook(23, listener);
/*  966 */     this.eventTable.unhook(22, listener);
/*      */   }
/*      */   
/*      */   void removeAccelerators(long accelGroup) {
/*  970 */     MenuItem[] items = getItems();
/*  971 */     for (int i = 0; i < items.length; i++) {
/*  972 */       MenuItem item = items[i];
/*  973 */       item.removeAccelerators(accelGroup);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeHelpListener(HelpListener listener)
/*      */   {
/*  995 */     checkWidget();
/*  996 */     if (listener == null) error(4);
/*  997 */     if (this.eventTable == null) return;
/*  998 */     this.eventTable.unhook(28, listener);
/*      */   }
/*      */   
/*      */   void reskinChildren(int flags)
/*      */   {
/* 1003 */     MenuItem[] items = getItems();
/* 1004 */     for (int i = 0; i < items.length; i++) {
/* 1005 */       MenuItem item = items[i];
/* 1006 */       item.reskin(flags);
/*      */     }
/* 1008 */     super.reskinChildren(flags);
/*      */   }
/*      */   
/*      */   boolean sendHelpEvent(long helpType) {
/* 1012 */     if ((this.selectedItem != null) && (!this.selectedItem.isDisposed()) && 
/* 1013 */       (this.selectedItem.hooks(28))) {
/* 1014 */       this.selectedItem.postEvent(28);
/* 1015 */       return true;
/*      */     }
/*      */     
/* 1018 */     if (hooks(28)) {
/* 1019 */       postEvent(28);
/* 1020 */       return true;
/*      */     }
/* 1022 */     return this.parent.sendHelpEvent(helpType);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDefaultItem(MenuItem item)
/*      */   {
/* 1040 */     checkWidget();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setEnabled(boolean enabled)
/*      */   {
/* 1057 */     checkWidget();
/* 1058 */     GTK.gtk_widget_set_sensitive(this.handle, enabled);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setLocation(int x, int y)
/*      */   {
/* 1084 */     checkWidget();
/* 1085 */     setLocation(new Point(x, y));
/*      */   }
/*      */   
/*      */   void setLocationInPixels(int x, int y) {
/* 1089 */     checkWidget();
/* 1090 */     if ((this.style & 0x6) != 0) return;
/* 1091 */     this.x = x;
/* 1092 */     this.y = y;
/*      */     
/* 1094 */     if (OS.isX11()) {
/* 1095 */       this.hasLocation = true;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setLocation(Point location)
/*      */   {
/* 1124 */     checkWidget();
/* 1125 */     setLocationInPixels(DPIUtil.autoScaleUp(location));
/*      */   }
/*      */   
/*      */   void setLocationInPixels(Point location) {
/* 1129 */     checkWidget();
/* 1130 */     if (location == null) error(4);
/* 1131 */     setLocationInPixels(location.x, location.y);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setOrientation(int orientation)
/*      */   {
/* 1149 */     checkWidget();
/* 1150 */     if ((this.style & 0x6) != 0) return;
/* 1151 */     _setOrientation(orientation);
/*      */   }
/*      */   
/*      */   void _setOrientation(int orientation) {
/* 1155 */     int flags = 100663296;
/* 1156 */     if (((orientation & flags) == 0) || ((orientation & flags) == flags)) return;
/* 1157 */     this.style &= (flags ^ 0xFFFFFFFF);
/* 1158 */     this.style |= orientation & flags;
/* 1159 */     setOrientation(false);
/*      */   }
/*      */   
/*      */   void setOrientation(boolean create)
/*      */   {
/* 1164 */     if (((this.style & 0x4000000) != 0) || (!create)) {
/* 1165 */       int dir = (this.style & 0x4000000) != 0 ? 2 : 1;
/* 1166 */       if (this.handle != 0L) GTK.gtk_widget_set_direction(this.handle, dir);
/* 1167 */       MenuItem[] items = getItems();
/* 1168 */       for (int i = 0; i < items.length; i++) {
/* 1169 */         items[i].setOrientation(create);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void adjustParentWindowWayland(long eventPtr)
/*      */   {
/* 1182 */     if (!OS.isX11()) {
/* 1183 */       long display = GDK.gdk_display_get_default();
/* 1184 */       long pointer = GDK.gdk_get_pointer(display);
/* 1185 */       long deviceWindow = GDK.gdk_device_get_window_at_position(pointer, null, null);
/* 1186 */       OS.g_object_ref(deviceWindow);
/* 1187 */       int eventType = GDK.gdk_event_get_event_type(eventPtr);
/* 1188 */       switch (eventType) {
/*      */       case 4: 
/* 1190 */         GdkEventButton eventButton = new GdkEventButton();
/* 1191 */         OS.memmove(eventButton, eventPtr, GdkEventButton.sizeof);
/* 1192 */         eventButton.window = deviceWindow;
/* 1193 */         OS.memmove(eventPtr, eventButton, GdkEventButton.sizeof);
/* 1194 */         break;
/*      */       case 8: 
/* 1196 */         GdkEventKey eventKey = new GdkEventKey();
/* 1197 */         OS.memmove(eventKey, eventPtr, GdkEventKey.sizeof);
/* 1198 */         eventKey.window = deviceWindow;
/* 1199 */         OS.memmove(eventPtr, eventKey, GdkEventKey.sizeof);
/*      */       }
/*      */       
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void verifyMenuPosition(int itemCount)
/*      */   {
/* 1225 */     if ((GTK.GTK3) && (OS.isX11()) && 
/* 1226 */       (itemCount != this.poppedUpCount) && (this.poppedUpCount != 0)) {
/* 1227 */       int[] naturalHeight = new int[1];
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1232 */       GTK.gtk_widget_show(this.handle);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1237 */       GTK.gtk_widget_get_preferred_height(this.handle, null, naturalHeight);
/* 1238 */       if (naturalHeight[0] > 0) {
/* 1239 */         long topLevelWidget = GTK.gtk_widget_get_toplevel(this.handle);
/* 1240 */         long topLevelWindow = GTK.gtk_widget_get_window(topLevelWidget);
/* 1241 */         int width = GDK.gdk_window_get_width(topLevelWindow);
/* 1242 */         GDK.gdk_window_resize(topLevelWindow, width, naturalHeight[0]);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setVisible(boolean visible)
/*      */   {
/* 1266 */     checkWidget();
/* 1267 */     if ((this.style & 0x6) != 0) return;
/* 1268 */     if (visible) {
/* 1269 */       this.display.addPopup(this);
/*      */     } else {
/* 1271 */       this.display.removePopup(this);
/* 1272 */       _setVisible(false);
/*      */     }
/*      */   }
/*      */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/widgets/Menu.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */