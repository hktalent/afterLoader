/*     */ package org.eclipse.swt.widgets;
/*     */ 
/*     */ import org.eclipse.swt.events.ExpandListener;
/*     */ import org.eclipse.swt.graphics.Font;
/*     */ import org.eclipse.swt.graphics.FontMetrics;
/*     */ import org.eclipse.swt.graphics.GC;
/*     */ import org.eclipse.swt.graphics.Point;
/*     */ import org.eclipse.swt.graphics.Rectangle;
/*     */ import org.eclipse.swt.internal.DPIUtil;
/*     */ import org.eclipse.swt.internal.gtk.GTK;
/*     */ import org.eclipse.swt.internal.gtk.GdkColor;
/*     */ import org.eclipse.swt.internal.gtk.GdkEventKey;
/*     */ import org.eclipse.swt.internal.gtk.GdkRGBA;
/*     */ import org.eclipse.swt.internal.gtk.GtkAdjustment;
/*     */ import org.eclipse.swt.internal.gtk.GtkAllocation;
/*     */ import org.eclipse.swt.internal.gtk.GtkRequisition;
/*     */ import org.eclipse.swt.internal.gtk.OS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExpandBar
/*     */   extends Composite
/*     */ {
/*     */   ExpandItem[] items;
/*     */   ExpandItem lastFocus;
/*     */   int itemCount;
/*     */   int spacing;
/*     */   int yCurrentScroll;
/*     */   
/*     */   public ExpandBar(Composite parent, int style)
/*     */   {
/*  83 */     super(parent, style);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addExpandListener(ExpandListener listener)
/*     */   {
/* 106 */     checkWidget();
/* 107 */     if (listener == null) error(4);
/* 108 */     TypedListener typedListener = new TypedListener(listener);
/* 109 */     addListener(17, typedListener);
/* 110 */     addListener(18, typedListener);
/*     */   }
/*     */   
/*     */   protected void checkSubclass()
/*     */   {
/* 115 */     if (!isValidSubclass()) error(43);
/*     */   }
/*     */   
/*     */   Point computeSizeInPixels(int wHint, int hHint, boolean changed)
/*     */   {
/* 120 */     if ((wHint != -1) && (wHint < 0)) wHint = 0;
/* 121 */     if ((hHint != -1) && (hHint < 0)) hHint = 0;
/* 122 */     Point size = computeNativeSize(this.handle, wHint, hHint, changed);
/* 123 */     if ((size.x == 0) && (wHint == -1)) size.x = 64;
/* 124 */     if ((size.y == 0) && (hHint == -1)) size.y = 64;
/* 125 */     int border = GTK.gtk_container_get_border_width(this.handle);
/* 126 */     size.x += 2 * border;
/* 127 */     size.y += 2 * border;
/* 128 */     return size;
/*     */   }
/*     */   
/*     */   void createHandle(int index)
/*     */   {
/* 133 */     this.state |= 0x8;
/* 134 */     this.fixedHandle = OS.g_object_new(this.display.gtk_fixed_get_type(), 0L);
/* 135 */     if (this.fixedHandle == 0L) error(2);
/* 136 */     GTK.gtk_widget_set_has_window(this.fixedHandle, true);
/* 137 */     this.handle = gtk_box_new(1, false, 0);
/* 138 */     if (this.handle == 0L) error(2);
/* 139 */     if ((this.style & 0x200) != 0) {
/* 140 */       this.scrolledHandle = GTK.gtk_scrolled_window_new(0L, 0L);
/* 141 */       if (this.scrolledHandle == 0L) error(2);
/* 142 */       GTK.gtk_scrolled_window_set_policy(this.scrolledHandle, 2, 1);
/* 143 */       GTK.gtk_container_add(this.fixedHandle, this.scrolledHandle);
/* 144 */       if (GTK.GTK_VERSION < OS.VERSION(3, 8, 0)) {
/* 145 */         GTK.gtk_scrolled_window_add_with_viewport(this.scrolledHandle, this.handle);
/*     */       } else {
/* 147 */         GTK.gtk_container_add(this.scrolledHandle, this.handle);
/*     */       }
/* 149 */       long viewport = GTK.gtk_bin_get_child(this.scrolledHandle);
/* 150 */       GTK.gtk_viewport_set_shadow_type(viewport, 0);
/*     */     } else {
/* 152 */       GTK.gtk_container_add(this.fixedHandle, this.handle);
/*     */     }
/* 154 */     GTK.gtk_container_set_border_width(this.handle, 0);
/*     */     
/*     */ 
/* 157 */     if (GTK.GTK3) {
/* 158 */       setFontDescription(defaultFont().handle);
/*     */     }
/*     */   }
/*     */   
/*     */   void createItem(ExpandItem item, int style, int index) {
/* 163 */     if ((0 > index) || (index > this.itemCount)) error(6);
/* 164 */     if (this.itemCount == this.items.length) {
/* 165 */       ExpandItem[] newItems = new ExpandItem[this.itemCount + 4];
/* 166 */       System.arraycopy(this.items, 0, newItems, 0, this.items.length);
/* 167 */       this.items = newItems;
/*     */     }
/* 169 */     System.arraycopy(this.items, index, this.items, index + 1, this.itemCount - index);
/* 170 */     this.items[index] = item;
/* 171 */     this.itemCount += 1;
/* 172 */     item.width = Math.max(0, getClientAreaInPixels().width - this.spacing * 2);
/* 173 */     layoutItems(index, true);
/*     */   }
/*     */   
/*     */   void createWidget(int index)
/*     */   {
/* 178 */     super.createWidget(index);
/* 179 */     this.items = new ExpandItem[4];
/*     */   }
/*     */   
/*     */   void destroyItem(ExpandItem item) {
/* 183 */     int index = 0;
/* 184 */     while ((index < this.itemCount) && 
/* 185 */       (this.items[index] != item)) {
/* 186 */       index++;
/*     */     }
/* 188 */     if (index == this.itemCount) return;
/* 189 */     System.arraycopy(this.items, index + 1, this.items, index, --this.itemCount - index);
/* 190 */     this.items[this.itemCount] = null;
/* 191 */     item.redraw();
/* 192 */     layoutItems(index, true);
/*     */   }
/*     */   
/*     */   long eventHandle()
/*     */   {
/* 197 */     return this.fixedHandle;
/*     */   }
/*     */   
/*     */   boolean forceFocus(long focusHandle)
/*     */   {
/* 202 */     if ((this.lastFocus != null) && (this.lastFocus.setFocus())) return true;
/* 203 */     for (int i = 0; i < this.itemCount; i++) {
/* 204 */       ExpandItem item = this.items[i];
/* 205 */       if (item.setFocus()) return true;
/*     */     }
/* 207 */     return super.forceFocus(focusHandle);
/*     */   }
/*     */   
/*     */   boolean hasFocus()
/*     */   {
/* 212 */     for (int i = 0; i < this.itemCount; i++) {
/* 213 */       ExpandItem item = this.items[i];
/* 214 */       if (item.hasFocus()) return true;
/*     */     }
/* 216 */     return super.hasFocus();
/*     */   }
/*     */   
/*     */   void hookEvents()
/*     */   {
/* 221 */     super.hookEvents();
/* 222 */     if (this.scrolledHandle != 0L) {
/* 223 */       OS.g_signal_connect_closure(this.scrolledHandle, OS.size_allocate, this.display.getClosure(47), true);
/*     */     }
/*     */   }
/*     */   
/*     */   int getBandHeight() {
/* 228 */     if (this.font == null) return 24;
/* 229 */     GC gc = new GC(this);
/* 230 */     FontMetrics metrics = gc.getFontMetrics();
/* 231 */     gc.dispose();
/* 232 */     return Math.max(24, metrics.getHeight());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ExpandItem getItem(int index)
/*     */   {
/* 251 */     checkWidget();
/* 252 */     if ((0 > index) || (index >= this.itemCount)) error(6);
/* 253 */     return this.items[index];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getItemCount()
/*     */   {
/* 267 */     checkWidget();
/* 268 */     return this.itemCount;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ExpandItem[] getItems()
/*     */   {
/* 288 */     checkWidget();
/* 289 */     ExpandItem[] result = new ExpandItem[this.itemCount];
/* 290 */     System.arraycopy(this.items, 0, result, 0, this.itemCount);
/* 291 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getSpacing()
/*     */   {
/* 305 */     checkWidget();
/* 306 */     return DPIUtil.autoScaleDown(this.spacing);
/*     */   }
/*     */   
/*     */   int getSpacingInPixels() {
/* 310 */     checkWidget();
/* 311 */     return this.spacing;
/*     */   }
/*     */   
/*     */   long gtk_key_press_event(long widget, long event)
/*     */   {
/* 316 */     if (!hasFocus()) return 0L;
/* 317 */     long result = super.gtk_key_press_event(widget, event);
/* 318 */     if (result != 0L) return result;
/* 319 */     int index = 0;
/* 320 */     while ((index < this.itemCount) && 
/* 321 */       (!this.items[index].hasFocus())) {
/* 322 */       index++;
/*     */     }
/* 324 */     GdkEventKey gdkEvent = new GdkEventKey();
/* 325 */     OS.memmove(gdkEvent, event, GdkEventKey.sizeof);
/* 326 */     boolean next = false;
/* 327 */     switch (gdkEvent.keyval) {
/*     */     case 65361: case 65362: 
/* 329 */       next = false; break;
/*     */     case 65363: case 65364: 
/* 331 */       next = true; break;
/* 332 */     default:  return result;
/*     */     }
/* 334 */     int start = index;int offset = next ? 1 : -1;
/* 335 */     while ((index = (index + offset + this.itemCount) % this.itemCount) != start) {
/* 336 */       ExpandItem item = this.items[index];
/* 337 */       if (item.setFocus()) return result;
/*     */     }
/* 339 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int indexOf(ExpandItem item)
/*     */   {
/* 361 */     checkWidget();
/* 362 */     if (item == null) error(4);
/* 363 */     for (int i = 0; i < this.itemCount; i++) {
/* 364 */       if (this.items[i] == item) return i;
/*     */     }
/* 366 */     return -1;
/*     */   }
/*     */   
/*     */   void layoutItems(int index, boolean setScrollbar) {
/* 370 */     for (int i = 0; i < this.itemCount; i++) {
/* 371 */       ExpandItem item = this.items[i];
/* 372 */       if (item != null) item.resizeControl(this.yCurrentScroll);
/*     */     }
/*     */   }
/*     */   
/*     */   long gtk_size_allocate(long widget, long allocation)
/*     */   {
/* 378 */     long result = super.gtk_size_allocate(widget, allocation);
/* 379 */     layoutItems(0, false);
/* 380 */     return result;
/*     */   }
/*     */   
/*     */   long parentingHandle()
/*     */   {
/* 385 */     return this.fixedHandle;
/*     */   }
/*     */   
/*     */   void releaseChildren(boolean destroy)
/*     */   {
/* 390 */     for (int i = 0; i < this.itemCount; i++) {
/* 391 */       ExpandItem item = this.items[i];
/* 392 */       if ((item != null) && (!item.isDisposed())) {
/* 393 */         item.release(false);
/*     */       }
/*     */     }
/* 396 */     super.releaseChildren(destroy);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeExpandListener(ExpandListener listener)
/*     */   {
/* 417 */     checkWidget();
/* 418 */     if (listener == null) error(4);
/* 419 */     if (this.eventTable == null) return;
/* 420 */     this.eventTable.unhook(17, listener);
/* 421 */     this.eventTable.unhook(18, listener);
/*     */   }
/*     */   
/*     */   void reskinChildren(int flags)
/*     */   {
/* 426 */     if (this.items != null) {
/* 427 */       for (int i = 0; i < this.items.length; i++) {
/* 428 */         ExpandItem item = this.items[i];
/* 429 */         if (item != null) item.reskin(flags);
/*     */       }
/*     */     }
/* 432 */     super.reskinChildren(flags);
/*     */   }
/*     */   
/*     */   void setWidgetBackground()
/*     */   {
/* 437 */     if (GTK.GTK_VERSION >= OS.VERSION(3, 14, 0)) {
/* 438 */       GdkRGBA rgba = (this.state & 0x2000) != 0 ? getBackgroundGdkRGBA() : null;
/* 439 */       super.setBackgroundGdkRGBA(this.handle, rgba);
/*     */     } else {
/* 441 */       super.setWidgetBackground();
/*     */     }
/*     */   }
/*     */   
/*     */   void setFontDescription(long font)
/*     */   {
/* 447 */     super.setFontDescription(font);
/* 448 */     for (int i = 0; i < this.itemCount; i++) {
/* 449 */       this.items[i].setFontDescription(font);
/*     */     }
/* 451 */     layoutItems(0, true);
/*     */   }
/*     */   
/*     */   void setForegroundGdkColor(GdkColor color)
/*     */   {
/* 456 */     assert (!GTK.GTK3) : "GTK2 code was run by GTK3";
/* 457 */     super.setForegroundGdkColor(color);
/* 458 */     for (int i = 0; i < this.itemCount; i++) {
/* 459 */       this.items[i].setForegroundColor(color);
/*     */     }
/*     */   }
/*     */   
/*     */   void setForegroundGdkRGBA(GdkRGBA rgba)
/*     */   {
/* 465 */     assert (GTK.GTK3) : "GTK3 code was run by GTK2";
/* 466 */     super.setForegroundGdkRGBA(rgba);
/* 467 */     for (int i = 0; i < this.itemCount; i++) {
/* 468 */       this.items[i].setForegroundRGBA(rgba);
/*     */     }
/*     */   }
/*     */   
/*     */   void setOrientation(boolean create)
/*     */   {
/* 474 */     super.setOrientation(create);
/* 475 */     if (this.items != null) {
/* 476 */       for (int i = 0; i < this.items.length; i++) {
/* 477 */         if (this.items[i] != null) this.items[i].setOrientation(create);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   void setScrollbar() {
/* 483 */     if (this.itemCount == 0) return;
/* 484 */     if ((this.style & 0x200) == 0) return;
/* 485 */     int height = getClientAreaInPixels().height;
/* 486 */     ExpandItem item = this.items[(this.itemCount - 1)];
/* 487 */     int maxHeight = item.y + getBandHeight() + this.spacing;
/* 488 */     if (item.expanded) maxHeight += item.height;
/* 489 */     long adjustmentHandle = GTK.gtk_scrolled_window_get_vadjustment(this.scrolledHandle);
/* 490 */     GtkAdjustment adjustment = new GtkAdjustment();
/* 491 */     gtk_adjustment_get(adjustmentHandle, adjustment);
/* 492 */     this.yCurrentScroll = ((int)adjustment.value);
/*     */     
/*     */ 
/* 495 */     if ((this.yCurrentScroll > 0) && (height > maxHeight)) {
/* 496 */       this.yCurrentScroll = Math.max(0, this.yCurrentScroll + maxHeight - height);
/* 497 */       layoutItems(0, false);
/*     */     }
/* 499 */     maxHeight += this.yCurrentScroll;
/* 500 */     adjustment.value = Math.min(this.yCurrentScroll, maxHeight);
/* 501 */     adjustment.upper = maxHeight;
/* 502 */     adjustment.page_size = height;
/* 503 */     GTK.gtk_adjustment_configure(adjustmentHandle, adjustment.value, adjustment.lower, adjustment.upper, adjustment.step_increment, adjustment.page_increment, adjustment.page_size);
/*     */     
/* 505 */     int policy = maxHeight > height ? 0 : 2;
/* 506 */     GTK.gtk_scrolled_window_set_policy(this.scrolledHandle, 2, policy);
/* 507 */     GtkAllocation allocation = new GtkAllocation();
/* 508 */     GTK.gtk_widget_get_allocation(this.fixedHandle, allocation);
/* 509 */     int width = allocation.width - this.spacing * 2;
/* 510 */     if (policy == 0) {
/* 511 */       long vHandle = 0L;
/* 512 */       vHandle = GTK.gtk_scrolled_window_get_vscrollbar(this.scrolledHandle);
/* 513 */       GtkRequisition requisition = new GtkRequisition();
/* 514 */       gtk_widget_get_preferred_size(vHandle, requisition);
/* 515 */       width -= requisition.width;
/*     */     }
/* 517 */     width = Math.max(0, width);
/* 518 */     for (int i = 0; i < this.itemCount; i++) {
/* 519 */       ExpandItem item2 = this.items[i];
/* 520 */       item2.setBounds(0, 0, width, item2.height, false, true);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSpacing(int spacing)
/*     */   {
/* 536 */     checkWidget();
/* 537 */     setSpacingInPixels(DPIUtil.autoScaleUp(spacing));
/*     */   }
/*     */   
/*     */   void setSpacingInPixels(int spacing) {
/* 541 */     checkWidget();
/* 542 */     if (spacing < 0) return;
/* 543 */     if (spacing == this.spacing) return;
/* 544 */     this.spacing = spacing;
/* 545 */     GTK.gtk_box_set_spacing(this.handle, spacing);
/* 546 */     GTK.gtk_container_set_border_width(this.handle, spacing);
/*     */   }
/*     */   
/*     */   void showItem(ExpandItem item) {
/* 550 */     Control control = item.control;
/* 551 */     if ((control != null) && (!control.isDisposed())) {
/* 552 */       control.setVisible(item.expanded);
/*     */     }
/* 554 */     item.redraw();
/* 555 */     int index = indexOf(item);
/* 556 */     layoutItems(index + 1, true);
/*     */   }
/*     */   
/*     */   void updateScrollBarValue(ScrollBar bar)
/*     */   {
/* 561 */     this.yCurrentScroll = bar.getSelection();
/* 562 */     layoutItems(0, false);
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/widgets/ExpandBar.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */