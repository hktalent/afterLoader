/*      */ package org.eclipse.swt.widgets;
/*      */ 
/*      */ import org.eclipse.swt.SWT;
/*      */ import org.eclipse.swt.graphics.Color;
/*      */ import org.eclipse.swt.graphics.Font;
/*      */ import org.eclipse.swt.graphics.Image;
/*      */ import org.eclipse.swt.graphics.Rectangle;
/*      */ import org.eclipse.swt.internal.C;
/*      */ import org.eclipse.swt.internal.Converter;
/*      */ import org.eclipse.swt.internal.DPIUtil;
/*      */ import org.eclipse.swt.internal.ImageList;
/*      */ import org.eclipse.swt.internal.gtk.GDK;
/*      */ import org.eclipse.swt.internal.gtk.GTK;
/*      */ import org.eclipse.swt.internal.gtk.GdkColor;
/*      */ import org.eclipse.swt.internal.gtk.GdkRGBA;
/*      */ import org.eclipse.swt.internal.gtk.GdkRectangle;
/*      */ import org.eclipse.swt.internal.gtk.OS;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class TableItem
/*      */   extends Item
/*      */ {
/*      */   Table parent;
/*      */   Font font;
/*      */   Font[] cellFont;
/*      */   String[] strings;
/*      */   boolean cached;
/*      */   boolean grayed;
/*      */   
/*      */   public TableItem(Table parent, int style, int index)
/*      */   {
/*   76 */     this(parent, style, index, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public TableItem(Table parent, int style)
/*      */   {
/*  110 */     this(parent, style, checkNull(parent).getItemCount(), true);
/*      */   }
/*      */   
/*      */   TableItem(Table parent, int style, int index, boolean create)
/*      */   {
/*  115 */     super(parent, style);
/*  116 */     this.parent = parent;
/*  117 */     if (create) {
/*  118 */       parent.createItem(this, index);
/*      */     } else {
/*  120 */       this.handle = OS.g_malloc(GTK.GtkTreeIter_sizeof());
/*  121 */       GTK.gtk_tree_model_iter_nth_child(parent.modelHandle, this.handle, 0L, index);
/*      */     }
/*      */   }
/*      */   
/*      */   static Table checkNull(Table control) {
/*  126 */     if (control == null) SWT.error(4);
/*  127 */     return control;
/*      */   }
/*      */   
/*      */   Color _getBackground() {
/*  131 */     long[] ptr = new long[1];
/*  132 */     GTK.gtk_tree_model_get(this.parent.modelHandle, this.handle, 3, ptr, -1);
/*  133 */     if (ptr[0] == 0L) return this.parent.getBackground();
/*  134 */     if (GTK.GTK3) {
/*  135 */       GdkRGBA gdkRGBA = new GdkRGBA();
/*  136 */       OS.memmove(gdkRGBA, ptr[0], GdkRGBA.sizeof);
/*  137 */       GDK.gdk_rgba_free(ptr[0]);
/*  138 */       return Color.gtk_new(this.display, gdkRGBA);
/*      */     }
/*  140 */     GdkColor gdkColor = new GdkColor();
/*  141 */     OS.memmove(gdkColor, ptr[0], GdkColor.sizeof);
/*  142 */     GDK.gdk_color_free(ptr[0]);
/*  143 */     return Color.gtk_new(this.display, gdkColor);
/*      */   }
/*      */   
/*      */   Color _getBackground(int index)
/*      */   {
/*  148 */     int count = Math.max(1, this.parent.columnCount);
/*  149 */     if ((0 > index) || (index > count - 1)) return _getBackground();
/*  150 */     long[] ptr = new long[1];
/*  151 */     int modelIndex = this.parent.columnCount == 0 ? 5 : this.parent.columns[index].modelIndex;
/*  152 */     GTK.gtk_tree_model_get(this.parent.modelHandle, this.handle, modelIndex + 3, ptr, -1);
/*  153 */     if (ptr[0] == 0L) return _getBackground();
/*  154 */     if (GTK.GTK3) {
/*  155 */       GdkRGBA gdkRGBA = new GdkRGBA();
/*  156 */       OS.memmove(gdkRGBA, ptr[0], GdkRGBA.sizeof);
/*  157 */       GDK.gdk_rgba_free(ptr[0]);
/*  158 */       return Color.gtk_new(this.display, gdkRGBA);
/*      */     }
/*  160 */     GdkColor gdkColor = new GdkColor();
/*  161 */     OS.memmove(gdkColor, ptr[0], GdkColor.sizeof);
/*  162 */     GDK.gdk_color_free(ptr[0]);
/*  163 */     return Color.gtk_new(this.display, gdkColor);
/*      */   }
/*      */   
/*      */   boolean _getChecked()
/*      */   {
/*  168 */     int[] ptr = new int[1];
/*  169 */     GTK.gtk_tree_model_get(this.parent.modelHandle, this.handle, 0, ptr, -1);
/*  170 */     return ptr[0] != 0;
/*      */   }
/*      */   
/*      */   Color _getForeground() {
/*  174 */     long[] ptr = new long[1];
/*  175 */     GTK.gtk_tree_model_get(this.parent.modelHandle, this.handle, 2, ptr, -1);
/*  176 */     if (ptr[0] == 0L) return this.parent.getForeground();
/*  177 */     if (GTK.GTK3) {
/*  178 */       GdkRGBA gdkRGBA = new GdkRGBA();
/*  179 */       OS.memmove(gdkRGBA, ptr[0], GdkRGBA.sizeof);
/*  180 */       GDK.gdk_rgba_free(ptr[0]);
/*  181 */       return Color.gtk_new(this.display, gdkRGBA);
/*      */     }
/*  183 */     GdkColor gdkColor = new GdkColor();
/*  184 */     OS.memmove(gdkColor, ptr[0], GdkColor.sizeof);
/*  185 */     GDK.gdk_color_free(ptr[0]);
/*  186 */     return Color.gtk_new(this.display, gdkColor);
/*      */   }
/*      */   
/*      */   Color _getForeground(int index)
/*      */   {
/*  191 */     int count = Math.max(1, this.parent.columnCount);
/*  192 */     if ((0 > index) || (index > count - 1)) return _getForeground();
/*  193 */     long[] ptr = new long[1];
/*  194 */     int modelIndex = this.parent.columnCount == 0 ? 5 : this.parent.columns[index].modelIndex;
/*  195 */     GTK.gtk_tree_model_get(this.parent.modelHandle, this.handle, modelIndex + 2, ptr, -1);
/*  196 */     if (ptr[0] == 0L) return _getForeground();
/*  197 */     if (GTK.GTK3) {
/*  198 */       GdkRGBA gdkRGBA = new GdkRGBA();
/*  199 */       OS.memmove(gdkRGBA, ptr[0], GdkRGBA.sizeof);
/*  200 */       GDK.gdk_rgba_free(ptr[0]);
/*  201 */       return Color.gtk_new(this.display, gdkRGBA);
/*      */     }
/*  203 */     GdkColor gdkColor = new GdkColor();
/*  204 */     OS.memmove(gdkColor, ptr[0], GdkColor.sizeof);
/*  205 */     GDK.gdk_color_free(ptr[0]);
/*  206 */     return Color.gtk_new(this.display, gdkColor);
/*      */   }
/*      */   
/*      */   Image _getImage(int index)
/*      */   {
/*  211 */     int count = Math.max(1, this.parent.getColumnCount());
/*  212 */     if ((0 > index) || (index > count - 1)) return null;
/*  213 */     long[] ptr = new long[1];
/*  214 */     int modelIndex = this.parent.columnCount == 0 ? 5 : this.parent.columns[index].modelIndex;
/*  215 */     GTK.gtk_tree_model_get(this.parent.modelHandle, this.handle, modelIndex + 0, ptr, -1);
/*  216 */     if (ptr[0] == 0L) return null;
/*  217 */     ImageList imageList = this.parent.imageList;
/*  218 */     int imageIndex = imageList.indexOf(ptr[0]);
/*  219 */     OS.g_object_unref(ptr[0]);
/*  220 */     if (imageIndex == -1) return null;
/*  221 */     return imageList.get(imageIndex);
/*      */   }
/*      */   
/*      */   String _getText(int index) {
/*  225 */     int count = Math.max(1, this.parent.getColumnCount());
/*  226 */     if ((0 > index) || (index > count - 1)) return "";
/*  227 */     long[] ptr = new long[1];
/*  228 */     int modelIndex = this.parent.columnCount == 0 ? 5 : this.parent.columns[index].modelIndex;
/*  229 */     GTK.gtk_tree_model_get(this.parent.modelHandle, this.handle, modelIndex + 1, ptr, -1);
/*  230 */     if (ptr[0] == 0L) return "";
/*  231 */     int length = C.strlen(ptr[0]);
/*  232 */     byte[] buffer = new byte[length];
/*  233 */     C.memmove(buffer, ptr[0], length);
/*  234 */     OS.g_free(ptr[0]);
/*  235 */     return new String(Converter.mbcsToWcs(buffer));
/*      */   }
/*      */   
/*      */   protected void checkSubclass()
/*      */   {
/*  240 */     if (!isValidSubclass()) error(43);
/*      */   }
/*      */   
/*      */   void clear() {
/*  244 */     if (this.parent.currentItem == this) return;
/*  245 */     if ((this.cached) || ((this.parent.style & 0x10000000) == 0)) {
/*  246 */       int columnCount = GTK.gtk_tree_model_get_n_columns(this.parent.modelHandle);
/*      */       
/*  248 */       for (int i = 0; i < 2; i++) {
/*  249 */         GTK.gtk_list_store_set(this.parent.modelHandle, this.handle, i, 0, -1);
/*      */       }
/*  251 */       for (int i = 2; i < columnCount; i++) {
/*  252 */         GTK.gtk_list_store_set(this.parent.modelHandle, this.handle, i, 0L, -1);
/*      */       }
/*      */     }
/*  255 */     this.cached = false;
/*  256 */     this.font = null;
/*  257 */     this.cellFont = null;
/*  258 */     this.strings = null;
/*      */   }
/*      */   
/*      */   void destroyWidget()
/*      */   {
/*  263 */     this.parent.destroyItem(this);
/*  264 */     releaseHandle();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Color getBackground()
/*      */   {
/*  280 */     checkWidget();
/*  281 */     if (!this.parent.checkData(this)) error(24);
/*  282 */     return _getBackground();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Rectangle getBounds()
/*      */   {
/*  299 */     return DPIUtil.autoScaleDown(getBoundsinPixels());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   Rectangle getBoundsinPixels()
/*      */   {
/*  318 */     checkWidget();
/*  319 */     if (!this.parent.checkData(this)) error(24);
/*  320 */     long parentHandle = this.parent.handle;
/*  321 */     long column = GTK.gtk_tree_view_get_column(parentHandle, 0);
/*  322 */     if (column == 0L) return new Rectangle(0, 0, 0, 0);
/*  323 */     long textRenderer = this.parent.getTextRenderer(column);
/*  324 */     long pixbufRenderer = this.parent.getPixbufRenderer(column);
/*  325 */     if ((textRenderer == 0L) || (pixbufRenderer == 0L)) { return new Rectangle(0, 0, 0, 0);
/*      */     }
/*  327 */     long path = GTK.gtk_tree_model_get_path(this.parent.modelHandle, this.handle);
/*  328 */     GTK.gtk_widget_realize(parentHandle);
/*      */     
/*  330 */     boolean isExpander = GTK.gtk_tree_model_iter_n_children(this.parent.modelHandle, this.handle) > 0;
/*  331 */     boolean isExpanded = GTK.gtk_tree_view_row_expanded(parentHandle, path);
/*  332 */     GTK.gtk_tree_view_column_cell_set_cell_data(column, this.parent.modelHandle, this.handle, isExpander, isExpanded);
/*      */     
/*  334 */     GdkRectangle rect = new GdkRectangle();
/*  335 */     GTK.gtk_tree_view_get_cell_area(parentHandle, path, column, rect);
/*  336 */     GTK.gtk_tree_path_free(path);
/*  337 */     if ((this.parent.getStyle() & 0x8000000) != 0) rect.x = (this.parent.getClientWidth() - rect.width - rect.x);
/*  338 */     int right = rect.x + rect.width;
/*      */     
/*  340 */     int[] x = new int[1];int[] w = new int[1];
/*  341 */     this.parent.ignoreSize = true;
/*  342 */     gtk_cell_renderer_get_preferred_size(textRenderer, parentHandle, w, null);
/*  343 */     this.parent.ignoreSize = false;
/*  344 */     rect.width = w[0];
/*  345 */     int[] buffer = new int[1];
/*  346 */     if (GTK.gtk_tree_view_get_expander_column(parentHandle) == column) {
/*  347 */       GTK.gtk_widget_style_get(parentHandle, OS.expander_size, buffer, 0L);
/*  348 */       rect.x += buffer[0] + 4;
/*      */     }
/*  350 */     GTK.gtk_widget_style_get(parentHandle, OS.horizontal_separator, buffer, 0L);
/*  351 */     int horizontalSeparator = buffer[0];
/*  352 */     rect.x += horizontalSeparator;
/*      */     
/*  354 */     gtk_tree_view_column_cell_get_position(column, textRenderer, x, null);
/*  355 */     rect.x += x[0];
/*      */     
/*  357 */     if ((this.parent.columnCount > 0) && 
/*  358 */       (rect.x + rect.width > right)) {
/*  359 */       rect.width = Math.max(0, right - rect.x);
/*      */     }
/*      */     
/*  362 */     int width = GTK.gtk_tree_view_column_get_visible(column) ? rect.width + 1 : 0;
/*  363 */     Rectangle r = new Rectangle(rect.x, rect.y, width, rect.height + 1);
/*  364 */     return r;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Color getBackground(int index)
/*      */   {
/*  381 */     checkWidget();
/*  382 */     if (!this.parent.checkData(this)) error(24);
/*  383 */     return _getBackground(index);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Rectangle getBounds(int index)
/*      */   {
/*  399 */     checkWidget();
/*  400 */     return DPIUtil.autoScaleDown(getBoundsInPixels(index));
/*      */   }
/*      */   
/*      */   Rectangle getBoundsInPixels(int index) {
/*  404 */     checkWidget();
/*  405 */     if (!this.parent.checkData(this)) error(24);
/*  406 */     long parentHandle = this.parent.handle;
/*  407 */     long column = 0L;
/*  408 */     if ((index >= 0) && (index < this.parent.columnCount)) {
/*  409 */       column = this.parent.columns[index].handle;
/*      */     } else {
/*  411 */       column = GTK.gtk_tree_view_get_column(parentHandle, index);
/*      */     }
/*  413 */     if (column == 0L) return new Rectangle(0, 0, 0, 0);
/*  414 */     long path = GTK.gtk_tree_model_get_path(this.parent.modelHandle, this.handle);
/*  415 */     GTK.gtk_widget_realize(parentHandle);
/*  416 */     GTK.gtk_tree_view_column_cell_set_cell_data(column, this.parent.modelHandle, this.handle, false, false);
/*  417 */     GdkRectangle rect = new GdkRectangle();
/*  418 */     GTK.gtk_tree_view_get_cell_area(parentHandle, path, column, rect);
/*  419 */     GTK.gtk_tree_path_free(path);
/*  420 */     int[] cw = new int[1];int[] ch = new int[1];
/*  421 */     GTK.gtk_tree_view_column_cell_get_size(column, null, null, null, cw, ch);
/*  422 */     rect.height = ch[0];
/*  423 */     if ((this.parent.getStyle() & 0x8000000) != 0) { rect.x = (this.parent.getClientWidth() - rect.width - rect.x);
/*      */     }
/*  425 */     if ((index == 0) && ((this.parent.style & 0x20) != 0)) {
/*  426 */       int[] x = new int[1];int[] w = new int[1];
/*  427 */       gtk_tree_view_column_cell_get_position(column, this.parent.checkRenderer, x, w);
/*  428 */       rect.x += x[0] + w[0];
/*  429 */       rect.width -= x[0] + w[0];
/*      */     }
/*  431 */     int width = GTK.gtk_tree_view_column_get_visible(column) ? rect.width + 1 : 0;
/*  432 */     Rectangle r = new Rectangle(rect.x, rect.y, width, rect.height + 1);
/*  433 */     return r;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getChecked()
/*      */   {
/*  449 */     checkWidget();
/*  450 */     if (!this.parent.checkData(this)) error(24);
/*  451 */     if ((this.parent.style & 0x20) == 0) return false;
/*  452 */     return _getChecked();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Font getFont()
/*      */   {
/*  468 */     checkWidget();
/*  469 */     if (!this.parent.checkData(this)) error(24);
/*  470 */     return this.font != null ? this.font : this.parent.getFont();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Font getFont(int index)
/*      */   {
/*  488 */     checkWidget();
/*  489 */     if (!this.parent.checkData(this)) error(24);
/*  490 */     int count = Math.max(1, this.parent.columnCount);
/*  491 */     if ((0 > index) || (index > count - 1)) return getFont();
/*  492 */     if ((this.cellFont == null) || (this.cellFont[index] == null)) return getFont();
/*  493 */     return this.cellFont[index];
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Color getForeground()
/*      */   {
/*  509 */     checkWidget();
/*  510 */     if (!this.parent.checkData(this)) error(24);
/*  511 */     return _getForeground();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Color getForeground(int index)
/*      */   {
/*  529 */     checkWidget();
/*  530 */     if (!this.parent.checkData(this)) error(24);
/*  531 */     return _getForeground(index);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getGrayed()
/*      */   {
/*  547 */     checkWidget();
/*  548 */     if (!this.parent.checkData(this)) error(24);
/*  549 */     if ((this.parent.style & 0x20) == 0) return false;
/*  550 */     return this.grayed;
/*      */   }
/*      */   
/*      */   public Image getImage()
/*      */   {
/*  555 */     checkWidget();
/*  556 */     if (!this.parent.checkData(this)) error(24);
/*  557 */     return getImage(0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Image getImage(int index)
/*      */   {
/*  573 */     checkWidget();
/*  574 */     if (!this.parent.checkData(this)) error(24);
/*  575 */     return _getImage(index);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Rectangle getImageBounds(int index)
/*      */   {
/*  593 */     checkWidget();
/*  594 */     return DPIUtil.autoScaleDown(getImageBoundsInPixels(index));
/*      */   }
/*      */   
/*      */   Rectangle getImageBoundsInPixels(int index) {
/*  598 */     checkWidget();
/*  599 */     if (!this.parent.checkData(this)) error(24);
/*  600 */     long parentHandle = this.parent.handle;
/*  601 */     long column = 0L;
/*  602 */     if ((index >= 0) && (index < this.parent.columnCount)) {
/*  603 */       column = this.parent.columns[index].handle;
/*      */     } else {
/*  605 */       column = GTK.gtk_tree_view_get_column(parentHandle, index);
/*      */     }
/*  607 */     if (column == 0L) return new Rectangle(0, 0, 0, 0);
/*  608 */     long pixbufRenderer = this.parent.getPixbufRenderer(column);
/*  609 */     if (pixbufRenderer == 0L) return new Rectangle(0, 0, 0, 0);
/*  610 */     GdkRectangle rect = new GdkRectangle();
/*  611 */     long path = GTK.gtk_tree_model_get_path(this.parent.modelHandle, this.handle);
/*  612 */     GTK.gtk_widget_realize(parentHandle);
/*  613 */     GTK.gtk_tree_view_get_cell_area(parentHandle, path, column, rect);
/*  614 */     GTK.gtk_tree_path_free(path);
/*  615 */     if ((this.parent.getStyle() & 0x8000000) != 0) rect.x = (this.parent.getClientWidth() - rect.width - rect.x);
/*  616 */     int[] x = new int[1];int[] w = new int[1];
/*  617 */     gtk_tree_view_column_cell_get_position(column, pixbufRenderer, x, w);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  625 */     if (GTK.GTK3) {
/*  626 */       if (this.parent.pixbufSizeSet) {
/*  627 */         if (x[0] > 0) {
/*  628 */           rect.x += x[0];
/*      */         }
/*      */         
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*      */ 
/*  636 */         long textRenderer = this.parent.getTextRenderer(column);
/*  637 */         if (textRenderer == 0L) return new Rectangle(0, 0, 0, 0);
/*  638 */         int[] xText = new int[1];int[] wText = new int[1];
/*  639 */         gtk_tree_view_column_cell_get_position(column, textRenderer, xText, wText);
/*  640 */         rect.x += xText[0];
/*      */       }
/*      */     } else {
/*  643 */       rect.x += x[0];
/*      */     }
/*  645 */     rect.width = w[0];
/*  646 */     int width = GTK.gtk_tree_view_column_get_visible(column) ? rect.width : 0;
/*  647 */     return new Rectangle(rect.x, rect.y, width, rect.height + 1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getImageIndent()
/*      */   {
/*  661 */     checkWidget();
/*  662 */     if (!this.parent.checkData(this)) { error(24);
/*      */     }
/*  664 */     return 0;
/*      */   }
/*      */   
/*      */   String getNameText()
/*      */   {
/*  669 */     if (((this.parent.style & 0x10000000) != 0) && 
/*  670 */       (!this.cached)) { return "*virtual*";
/*      */     }
/*  672 */     return super.getNameText();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Table getParent()
/*      */   {
/*  686 */     checkWidget();
/*  687 */     return this.parent;
/*      */   }
/*      */   
/*      */   public String getText()
/*      */   {
/*  692 */     checkWidget();
/*  693 */     if (!this.parent.checkData(this)) error(24);
/*  694 */     return getText(0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getText(int index)
/*      */   {
/*  710 */     checkWidget();
/*  711 */     if (!this.parent.checkData(this)) error(24);
/*  712 */     if ((this.strings != null) && 
/*  713 */       (0 <= index) && (index < this.strings.length)) {
/*  714 */       String string = this.strings[index];
/*  715 */       return string != null ? string : "";
/*      */     }
/*      */     
/*  718 */     return _getText(index);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Rectangle getTextBounds(int index)
/*      */   {
/*  738 */     checkWidget();
/*  739 */     return DPIUtil.autoScaleDown(getTextBoundsInPixels(index));
/*      */   }
/*      */   
/*      */   Rectangle getTextBoundsInPixels(int index) {
/*  743 */     checkWidget();
/*  744 */     if (!this.parent.checkData(this)) error(24);
/*  745 */     int count = Math.max(1, this.parent.getColumnCount());
/*  746 */     if ((0 > index) || (index > count - 1)) { return new Rectangle(0, 0, 0, 0);
/*      */     }
/*      */     
/*  749 */     long parentHandle = this.parent.handle;
/*  750 */     long column = 0L;
/*  751 */     if ((index >= 0) && (index < this.parent.columnCount)) {
/*  752 */       column = this.parent.columns[index].handle;
/*      */     } else {
/*  754 */       column = GTK.gtk_tree_view_get_column(parentHandle, index);
/*      */     }
/*  756 */     if (column == 0L) return new Rectangle(0, 0, 0, 0);
/*  757 */     long textRenderer = this.parent.getTextRenderer(column);
/*  758 */     long pixbufRenderer = this.parent.getPixbufRenderer(column);
/*  759 */     if ((textRenderer == 0L) || (pixbufRenderer == 0L)) { return new Rectangle(0, 0, 0, 0);
/*      */     }
/*  761 */     long path = GTK.gtk_tree_model_get_path(this.parent.modelHandle, this.handle);
/*  762 */     GTK.gtk_widget_realize(parentHandle);
/*      */     
/*  764 */     boolean isExpander = GTK.gtk_tree_model_iter_n_children(this.parent.modelHandle, this.handle) > 0;
/*  765 */     boolean isExpanded = GTK.gtk_tree_view_row_expanded(parentHandle, path);
/*  766 */     GTK.gtk_tree_view_column_cell_set_cell_data(column, this.parent.modelHandle, this.handle, isExpander, isExpanded);
/*      */     
/*  768 */     GdkRectangle rect = new GdkRectangle();
/*  769 */     GTK.gtk_tree_view_get_cell_area(parentHandle, path, column, rect);
/*  770 */     GTK.gtk_tree_path_free(path);
/*  771 */     if ((this.parent.getStyle() & 0x8000000) != 0) rect.x = (this.parent.getClientWidth() - rect.width - rect.x);
/*  772 */     int right = rect.x + rect.width;
/*      */     
/*  774 */     int[] x = new int[1];int[] w = new int[1];
/*  775 */     this.parent.ignoreSize = true;
/*  776 */     gtk_cell_renderer_get_preferred_size(textRenderer, parentHandle, w, null);
/*  777 */     this.parent.ignoreSize = false;
/*  778 */     int[] buffer = new int[1];
/*  779 */     if (GTK.gtk_tree_view_get_expander_column(parentHandle) == column) {
/*  780 */       GTK.gtk_widget_style_get(parentHandle, OS.expander_size, buffer, 0L);
/*  781 */       rect.x += buffer[0] + 4;
/*      */     }
/*  783 */     GTK.gtk_widget_style_get(parentHandle, OS.horizontal_separator, buffer, 0L);
/*  784 */     int horizontalSeparator = buffer[0];
/*  785 */     rect.x += horizontalSeparator;
/*      */     
/*  787 */     gtk_tree_view_column_cell_get_position(column, textRenderer, x, null);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  795 */     if (GTK.GTK3) {
/*  796 */       Image image = _getImage(index);
/*  797 */       int imageWidth = 0;
/*  798 */       if (image != null) {
/*  799 */         imageWidth = image.getBounds().width;
/*      */       }
/*  801 */       if (x[0] < imageWidth) {
/*  802 */         rect.x += imageWidth;
/*      */       } else {
/*  804 */         rect.x += x[0];
/*      */       }
/*      */     } else {
/*  807 */       rect.x += x[0];
/*      */     }
/*  809 */     if ((this.parent.columnCount > 0) && 
/*  810 */       (rect.x + rect.width > right)) {
/*  811 */       rect.width = Math.max(0, right - rect.x);
/*      */     }
/*      */     
/*  814 */     int width = GTK.gtk_tree_view_column_get_visible(column) ? rect.width + 1 : 0;
/*  815 */     return new Rectangle(rect.x, rect.y, width, rect.height + 1);
/*      */   }
/*      */   
/*      */   void releaseHandle()
/*      */   {
/*  820 */     if (this.handle != 0L) OS.g_free(this.handle);
/*  821 */     this.handle = 0L;
/*  822 */     super.releaseHandle();
/*  823 */     this.parent = null;
/*      */   }
/*      */   
/*      */   void releaseWidget()
/*      */   {
/*  828 */     super.releaseWidget();
/*  829 */     this.font = null;
/*  830 */     this.cellFont = null;
/*  831 */     this.strings = null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBackground(Color color)
/*      */   {
/*  852 */     checkWidget();
/*  853 */     if ((color != null) && (color.isDisposed())) {
/*  854 */       error(5);
/*      */     }
/*  856 */     if (_getBackground().equals(color)) return;
/*  857 */     if (GTK.GTK3) {
/*  858 */       GdkRGBA gdkRGBA = color != null ? color.handleRGBA : null;
/*  859 */       GTK.gtk_list_store_set(this.parent.modelHandle, this.handle, 3, gdkRGBA, -1);
/*      */     } else {
/*  861 */       GdkColor gdkColor = color != null ? color.handle : null;
/*  862 */       GTK.gtk_list_store_set(this.parent.modelHandle, this.handle, 3, gdkColor, -1);
/*      */     }
/*  864 */     this.cached = true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBackground(int index, Color color)
/*      */   {
/*  886 */     checkWidget();
/*  887 */     if ((color != null) && (color.isDisposed())) {
/*  888 */       error(5);
/*      */     }
/*  890 */     if (_getBackground(index).equals(color)) return;
/*  891 */     int count = Math.max(1, this.parent.getColumnCount());
/*  892 */     if ((0 > index) || (index > count - 1)) return;
/*  893 */     int modelIndex = this.parent.columnCount == 0 ? 5 : this.parent.columns[index].modelIndex;
/*  894 */     if (GTK.GTK3) {
/*  895 */       GdkRGBA gdkRGBA = color != null ? color.handleRGBA : null;
/*  896 */       GTK.gtk_list_store_set(this.parent.modelHandle, this.handle, modelIndex + 3, gdkRGBA, -1);
/*      */     } else {
/*  898 */       GdkColor gdkColor = color != null ? color.handle : null;
/*  899 */       GTK.gtk_list_store_set(this.parent.modelHandle, this.handle, modelIndex + 3, gdkColor, -1);
/*      */     }
/*  901 */     this.cached = true;
/*      */     
/*  903 */     if (color != null) {
/*  904 */       boolean customDraw = this.parent.columnCount == 0 ? this.parent.firstCustomDraw : this.parent.columns[index].customDraw;
/*  905 */       if (!customDraw) {
/*  906 */         if ((this.parent.style & 0x10000000) == 0) {
/*  907 */           long parentHandle = this.parent.handle;
/*  908 */           long column = 0L;
/*  909 */           if (this.parent.columnCount > 0) {
/*  910 */             column = this.parent.columns[index].handle;
/*      */           } else {
/*  912 */             column = GTK.gtk_tree_view_get_column(parentHandle, index);
/*      */           }
/*  914 */           if (column == 0L) return;
/*  915 */           long textRenderer = this.parent.getTextRenderer(column);
/*  916 */           long imageRenderer = this.parent.getPixbufRenderer(column);
/*  917 */           GTK.gtk_tree_view_column_set_cell_data_func(column, textRenderer, this.display.cellDataProc, parentHandle, 0L);
/*  918 */           GTK.gtk_tree_view_column_set_cell_data_func(column, imageRenderer, this.display.cellDataProc, parentHandle, 0L);
/*      */         }
/*  920 */         if (this.parent.columnCount == 0) {
/*  921 */           this.parent.firstCustomDraw = true;
/*      */         } else {
/*  923 */           this.parent.columns[index].customDraw = true;
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setChecked(boolean checked)
/*      */   {
/*  941 */     checkWidget();
/*  942 */     if ((this.parent.style & 0x20) == 0) return;
/*  943 */     if (_getChecked() == checked) return;
/*  944 */     GTK.gtk_list_store_set(this.parent.modelHandle, this.handle, 0, checked, -1);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  950 */     GTK.gtk_list_store_set(this.parent.modelHandle, this.handle, 1, !checked ? false : this.grayed, -1);
/*  951 */     this.cached = true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setFont(Font font)
/*      */   {
/*  972 */     checkWidget();
/*  973 */     if ((font != null) && (font.isDisposed())) {
/*  974 */       error(5);
/*      */     }
/*  976 */     Font oldFont = this.font;
/*  977 */     if (oldFont == font) return;
/*  978 */     this.font = font;
/*  979 */     if ((oldFont != null) && (oldFont.equals(font))) return;
/*  980 */     long fontHandle = font != null ? font.handle : 0L;
/*  981 */     GTK.gtk_list_store_set(this.parent.modelHandle, this.handle, 4, fontHandle, -1);
/*  982 */     this.cached = true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setFont(int index, Font font)
/*      */   {
/* 1005 */     checkWidget();
/* 1006 */     if ((font != null) && (font.isDisposed())) {
/* 1007 */       error(5);
/*      */     }
/* 1009 */     int count = Math.max(1, this.parent.getColumnCount());
/* 1010 */     if ((0 > index) || (index > count - 1)) return;
/* 1011 */     if (this.cellFont == null) {
/* 1012 */       if (font == null) return;
/* 1013 */       this.cellFont = new Font[count];
/*      */     }
/* 1015 */     Font oldFont = this.cellFont[index];
/* 1016 */     if (oldFont == font) return;
/* 1017 */     this.cellFont[index] = font;
/* 1018 */     if ((oldFont != null) && (oldFont.equals(font))) { return;
/*      */     }
/* 1020 */     int modelIndex = this.parent.columnCount == 0 ? 5 : this.parent.columns[index].modelIndex;
/* 1021 */     long fontHandle = font != null ? font.handle : 0L;
/* 1022 */     GTK.gtk_list_store_set(this.parent.modelHandle, this.handle, modelIndex + 4, fontHandle, -1);
/* 1023 */     this.cached = true;
/*      */     
/* 1025 */     if (font != null) {
/* 1026 */       boolean customDraw = this.parent.columnCount == 0 ? this.parent.firstCustomDraw : this.parent.columns[index].customDraw;
/* 1027 */       if (!customDraw) {
/* 1028 */         if ((this.parent.style & 0x10000000) == 0) {
/* 1029 */           long parentHandle = this.parent.handle;
/* 1030 */           long column = 0L;
/* 1031 */           if (this.parent.columnCount > 0) {
/* 1032 */             column = this.parent.columns[index].handle;
/*      */           } else {
/* 1034 */             column = GTK.gtk_tree_view_get_column(parentHandle, index);
/*      */           }
/* 1036 */           if (column == 0L) return;
/* 1037 */           long textRenderer = this.parent.getTextRenderer(column);
/* 1038 */           long imageRenderer = this.parent.getPixbufRenderer(column);
/* 1039 */           GTK.gtk_tree_view_column_set_cell_data_func(column, textRenderer, this.display.cellDataProc, parentHandle, 0L);
/* 1040 */           GTK.gtk_tree_view_column_set_cell_data_func(column, imageRenderer, this.display.cellDataProc, parentHandle, 0L);
/*      */         }
/* 1042 */         if (this.parent.columnCount == 0) {
/* 1043 */           this.parent.firstCustomDraw = true;
/*      */         } else {
/* 1045 */           this.parent.columns[index].customDraw = true;
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setForeground(Color color)
/*      */   {
/* 1069 */     checkWidget();
/* 1070 */     if ((color != null) && (color.isDisposed())) {
/* 1071 */       error(5);
/*      */     }
/* 1073 */     if (_getForeground().equals(color)) return;
/* 1074 */     if (GTK.GTK3) {
/* 1075 */       GdkRGBA gdkRGBA = color != null ? color.handleRGBA : null;
/* 1076 */       GTK.gtk_list_store_set(this.parent.modelHandle, this.handle, 2, gdkRGBA, -1);
/*      */     } else {
/* 1078 */       GdkColor gdkColor = color != null ? color.handle : null;
/* 1079 */       GTK.gtk_list_store_set(this.parent.modelHandle, this.handle, 2, gdkColor, -1);
/*      */     }
/* 1081 */     this.cached = true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setForeground(int index, Color color)
/*      */   {
/* 1103 */     checkWidget();
/* 1104 */     if ((color != null) && (color.isDisposed())) {
/* 1105 */       error(5);
/*      */     }
/* 1107 */     if (_getForeground(index).equals(color)) return;
/* 1108 */     int count = Math.max(1, this.parent.getColumnCount());
/* 1109 */     if ((0 > index) || (index > count - 1)) return;
/* 1110 */     int modelIndex = this.parent.columnCount == 0 ? 5 : this.parent.columns[index].modelIndex;
/* 1111 */     if (GTK.GTK3) {
/* 1112 */       GdkRGBA gdkRGBA = color != null ? color.handleRGBA : null;
/* 1113 */       GTK.gtk_list_store_set(this.parent.modelHandle, this.handle, modelIndex + 2, gdkRGBA, -1);
/*      */     } else {
/* 1115 */       GdkColor gdkColor = color != null ? color.handle : null;
/* 1116 */       GTK.gtk_list_store_set(this.parent.modelHandle, this.handle, modelIndex + 2, gdkColor, -1);
/*      */     }
/* 1118 */     this.cached = true;
/*      */     
/* 1120 */     if (color != null) {
/* 1121 */       boolean customDraw = this.parent.columnCount == 0 ? this.parent.firstCustomDraw : this.parent.columns[index].customDraw;
/* 1122 */       if (!customDraw) {
/* 1123 */         if ((this.parent.style & 0x10000000) == 0) {
/* 1124 */           long parentHandle = this.parent.handle;
/* 1125 */           long column = 0L;
/* 1126 */           if (this.parent.columnCount > 0) {
/* 1127 */             column = this.parent.columns[index].handle;
/*      */           } else {
/* 1129 */             column = GTK.gtk_tree_view_get_column(parentHandle, index);
/*      */           }
/* 1131 */           if (column == 0L) return;
/* 1132 */           long textRenderer = this.parent.getTextRenderer(column);
/* 1133 */           long imageRenderer = this.parent.getPixbufRenderer(column);
/* 1134 */           GTK.gtk_tree_view_column_set_cell_data_func(column, textRenderer, this.display.cellDataProc, parentHandle, 0L);
/* 1135 */           GTK.gtk_tree_view_column_set_cell_data_func(column, imageRenderer, this.display.cellDataProc, parentHandle, 0L);
/*      */         }
/* 1137 */         if (this.parent.columnCount == 0) {
/* 1138 */           this.parent.firstCustomDraw = true;
/*      */         } else {
/* 1140 */           this.parent.columns[index].customDraw = true;
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setGrayed(boolean grayed)
/*      */   {
/* 1158 */     checkWidget();
/* 1159 */     if ((this.parent.style & 0x20) == 0) return;
/* 1160 */     if (this.grayed == grayed) return;
/* 1161 */     this.grayed = grayed;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1166 */     int[] ptr = new int[1];
/* 1167 */     GTK.gtk_tree_model_get(this.parent.modelHandle, this.handle, 0, ptr, -1);
/* 1168 */     GTK.gtk_list_store_set(this.parent.modelHandle, this.handle, 1, ptr[0] == 0 ? false : grayed, -1);
/* 1169 */     this.cached = true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setImage(int index, Image image)
/*      */   {
/* 1187 */     checkWidget();
/* 1188 */     if ((image != null) && (image.isDisposed())) {
/* 1189 */       error(5);
/*      */     }
/* 1191 */     if ((image != null) && (image.type == 1) && 
/* 1192 */       (image.equals(_getImage(index)))) { return;
/*      */     }
/* 1194 */     int count = Math.max(1, this.parent.getColumnCount());
/* 1195 */     if ((0 > index) || (index > count - 1)) return;
/* 1196 */     long pixbuf = 0L;
/* 1197 */     if (image != null) {
/* 1198 */       ImageList imageList = this.parent.imageList;
/* 1199 */       if (imageList == null) imageList = this.parent.imageList = new ImageList();
/* 1200 */       int imageIndex = imageList.indexOf(image);
/* 1201 */       if (imageIndex == -1) imageIndex = imageList.add(image);
/* 1202 */       pixbuf = imageList.getPixbuf(imageIndex);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1214 */     if (GTK.GTK3)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 1219 */       if ((!this.parent.ownerDraw) && (image != null) && (DPIUtil.getDeviceZoom() != 100)) {
/* 1220 */         Rectangle imgSize = image.getBounds();
/* 1221 */         long scaledPixbuf = GDK.gdk_pixbuf_scale_simple(pixbuf, imgSize.width, imgSize.height, 2);
/* 1222 */         if (scaledPixbuf != 0L) {
/* 1223 */           pixbuf = scaledPixbuf;
/*      */         }
/*      */       }
/* 1226 */       long parentHandle = this.parent.handle;
/* 1227 */       long column = GTK.gtk_tree_view_get_column(parentHandle, index);
/* 1228 */       long pixbufRenderer = this.parent.getPixbufRenderer(column);
/* 1229 */       int[] currentWidth = new int[1];
/* 1230 */       int[] currentHeight = new int[1];
/* 1231 */       GTK.gtk_cell_renderer_get_fixed_size(pixbufRenderer, currentWidth, currentHeight);
/* 1232 */       if (!this.parent.pixbufSizeSet) {
/* 1233 */         if (image != null) {
/* 1234 */           int iWidth = image.getBounds().width;
/* 1235 */           int iHeight = image.getBounds().height;
/* 1236 */           if ((iWidth > currentWidth[0]) || (iHeight > currentHeight[0])) {
/* 1237 */             GTK.gtk_cell_renderer_set_fixed_size(pixbufRenderer, iWidth, iHeight);
/* 1238 */             this.parent.pixbufHeight = iHeight;
/* 1239 */             this.parent.pixbufWidth = iWidth;
/* 1240 */             this.parent.pixbufSizeSet = true;
/*      */ 
/*      */           }
/*      */           
/*      */ 
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */       }
/* 1250 */       else if ((this.parent.pixbufWidth > Math.max(currentWidth[0], 0)) || (this.parent.pixbufHeight > Math.max(currentHeight[0], 0))) {
/* 1251 */         GTK.gtk_cell_renderer_set_fixed_size(pixbufRenderer, this.parent.pixbufWidth, this.parent.pixbufHeight);
/*      */       }
/*      */     }
/*      */     
/* 1255 */     int modelIndex = this.parent.columnCount == 0 ? 5 : this.parent.columns[index].modelIndex;
/* 1256 */     GTK.gtk_list_store_set(this.parent.modelHandle, this.handle, modelIndex + 0, pixbuf, -1);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1262 */     if (((this.parent.style & 0x10000000) != 0) && (this.parent.currentItem == null) && 
/* 1263 */       (image != null)) {
/* 1264 */       long parentHandle = this.parent.handle;
/* 1265 */       long column = GTK.gtk_tree_view_get_column(parentHandle, index);
/* 1266 */       int[] w = new int[1];
/* 1267 */       long pixbufRenderer = this.parent.getPixbufRenderer(column);
/* 1268 */       gtk_tree_view_column_cell_get_position(column, pixbufRenderer, null, w);
/* 1269 */       if (w[0] < image.getBounds().width)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1275 */         if (!GTK.GTK3) {
/* 1276 */           long style = GTK.gtk_widget_get_modifier_style(parentHandle);
/* 1277 */           this.parent.modifyStyle(parentHandle, style);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 1282 */     this.cached = true;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1289 */     if (this.parent.columnCount == 0) {
/* 1290 */       long column = GTK.gtk_tree_view_get_column(this.parent.handle, index);
/* 1291 */       this.parent.maxWidth = Math.max(this.parent.maxWidth, this.parent.calculateWidth(column, this.handle));
/*      */     }
/*      */   }
/*      */   
/*      */   public void setImage(Image image)
/*      */   {
/* 1297 */     checkWidget();
/* 1298 */     setImage(0, image);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setImage(Image[] images)
/*      */   {
/* 1316 */     checkWidget();
/* 1317 */     if (images == null) error(4);
/* 1318 */     for (int i = 0; i < images.length; i++) {
/* 1319 */       setImage(i, images[i]);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   @Deprecated
/*      */   public void setImageIndent(int indent)
/*      */   {
/* 1338 */     checkWidget();
/* 1339 */     if (indent < 0) { return;
/*      */     }
/* 1341 */     this.cached = true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setText(int index, String string)
/*      */   {
/* 1362 */     checkWidget();
/* 1363 */     if (string == null) error(4);
/* 1364 */     if (getText(index).equals(string)) { return;
/*      */     }
/* 1366 */     int count = Math.max(1, this.parent.getColumnCount());
/* 1367 */     if ((0 > index) || (index > count - 1)) return;
/* 1368 */     if ((0 <= index) && (index < count)) {
/* 1369 */       if (this.strings == null) this.strings = new String[count];
/* 1370 */       if (string.equals(this.strings[index])) return;
/* 1371 */       this.strings[index] = string;
/*      */     }
/* 1373 */     if ((string != null) && (string.length() > 8192)) {
/* 1374 */       string = string.substring(0, 8192 - "...".length()) + "...";
/*      */     }
/* 1376 */     byte[] buffer = Converter.wcsToMbcs(string, true);
/* 1377 */     int modelIndex = this.parent.columnCount == 0 ? 5 : this.parent.columns[index].modelIndex;
/* 1378 */     GTK.gtk_list_store_set(this.parent.modelHandle, this.handle, modelIndex + 1, buffer, -1);
/* 1379 */     this.cached = true;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1386 */     if (this.parent.columnCount == 0) {
/* 1387 */       long column = GTK.gtk_tree_view_get_column(this.parent.handle, index);
/* 1388 */       this.parent.maxWidth = Math.max(this.parent.maxWidth, this.parent.calculateWidth(column, this.handle));
/*      */     }
/*      */   }
/*      */   
/*      */   public void setText(String string)
/*      */   {
/* 1394 */     checkWidget();
/* 1395 */     setText(0, string);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setText(String[] strings)
/*      */   {
/* 1415 */     checkWidget();
/* 1416 */     if (strings == null) error(4);
/* 1417 */     for (int i = 0; i < strings.length; i++) {
/* 1418 */       String string = strings[i];
/* 1419 */       if (string != null) setText(i, string);
/*      */     }
/*      */   }
/*      */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/widgets/TableItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */