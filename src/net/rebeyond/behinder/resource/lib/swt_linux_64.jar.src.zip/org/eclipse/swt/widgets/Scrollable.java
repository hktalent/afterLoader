/*     */ package org.eclipse.swt.widgets;
/*     */ 
/*     */ import org.eclipse.swt.graphics.Point;
/*     */ import org.eclipse.swt.graphics.Rectangle;
/*     */ import org.eclipse.swt.internal.DPIUtil;
/*     */ import org.eclipse.swt.internal.gtk.GDK;
/*     */ import org.eclipse.swt.internal.gtk.GTK;
/*     */ import org.eclipse.swt.internal.gtk.GdkEventScroll;
/*     */ import org.eclipse.swt.internal.gtk.GdkRectangle;
/*     */ import org.eclipse.swt.internal.gtk.GtkAdjustment;
/*     */ import org.eclipse.swt.internal.gtk.GtkAllocation;
/*     */ import org.eclipse.swt.internal.gtk.GtkRequisition;
/*     */ import org.eclipse.swt.internal.gtk.OS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Scrollable
/*     */   extends Control
/*     */ {
/*     */   long scrolledHandle;
/*     */   ScrollBar horizontalBar;
/*     */   ScrollBar verticalBar;
/*     */   
/*     */   Scrollable() {}
/*     */   
/*     */   public Scrollable(Composite parent, int style)
/*     */   {
/*  75 */     super(parent, style);
/*     */   }
/*     */   
/*     */   long clientHandle() {
/*  79 */     return this.handle;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Rectangle computeTrim(int x, int y, int width, int height)
/*     */   {
/* 110 */     checkWidget();
/* 111 */     Rectangle rect = DPIUtil.autoScaleUp(new Rectangle(x, y, width, height));
/* 112 */     return DPIUtil.autoScaleDown(computeTrimInPixels(rect.x, rect.y, rect.width, rect.height));
/*     */   }
/*     */   
/*     */   Rectangle computeTrimInPixels(int x, int y, int width, int height) {
/* 116 */     checkWidget();
/* 117 */     int border = 0;
/* 118 */     if (this.fixedHandle != 0L) border += GTK.gtk_container_get_border_width(this.fixedHandle);
/* 119 */     if (this.scrolledHandle != 0L) border += GTK.gtk_container_get_border_width(this.scrolledHandle);
/* 120 */     int trimX = x - border;int trimY = y - border;
/* 121 */     int trimWidth = width + border * 2;int trimHeight = height + border * 2;
/* 122 */     trimHeight += hScrollBarWidth();
/* 123 */     trimWidth += vScrollBarWidth();
/* 124 */     if ((this.scrolledHandle != 0L) && 
/* 125 */       (GTK.gtk_scrolled_window_get_shadow_type(this.scrolledHandle) != 0)) {
/* 126 */       Point thickness = getThickness(this.scrolledHandle);
/* 127 */       int xthickness = thickness.x;
/* 128 */       int ythickness = thickness.y;
/* 129 */       trimX -= xthickness;
/* 130 */       trimY -= ythickness;
/* 131 */       trimWidth += xthickness * 2;
/* 132 */       trimHeight += ythickness * 2;
/*     */     }
/*     */     
/* 135 */     return new Rectangle(trimX, trimY, trimWidth, trimHeight);
/*     */   }
/*     */   
/*     */   ScrollBar createScrollBar(int style) {
/* 139 */     if (this.scrolledHandle == 0L) return null;
/* 140 */     ScrollBar bar = new ScrollBar();
/* 141 */     bar.parent = this;
/* 142 */     bar.style = style;
/* 143 */     bar.display = this.display;
/* 144 */     bar.state |= 0x8;
/* 145 */     if ((style & 0x100) != 0) {
/* 146 */       bar.handle = GTK.gtk_scrolled_window_get_hscrollbar(this.scrolledHandle);
/* 147 */       bar.adjustmentHandle = GTK.gtk_scrolled_window_get_hadjustment(this.scrolledHandle);
/*     */     } else {
/* 149 */       bar.handle = GTK.gtk_scrolled_window_get_vscrollbar(this.scrolledHandle);
/* 150 */       bar.adjustmentHandle = GTK.gtk_scrolled_window_get_vadjustment(this.scrolledHandle);
/*     */     }
/* 152 */     bar.setOrientation(true);
/* 153 */     bar.hookEvents();
/* 154 */     bar.register();
/* 155 */     return bar;
/*     */   }
/*     */   
/*     */   void createWidget(int index)
/*     */   {
/* 160 */     super.createWidget(index);
/* 161 */     if ((this.style & 0x100) != 0) this.horizontalBar = createScrollBar(256);
/* 162 */     if ((this.style & 0x200) != 0) this.verticalBar = createScrollBar(512);
/*     */   }
/*     */   
/*     */   void updateBackgroundMode()
/*     */   {
/* 167 */     super.updateBackgroundMode();
/* 168 */     switch (applyThemeBackground()) {
/* 169 */     case 0:  this.state &= 0xFFFEFFFF; break;
/* 170 */     case 1:  this.state |= 0x10000; break;
/*     */     }
/*     */     
/* 173 */     super.updateBackgroundMode();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   int applyThemeBackground()
/*     */   {
/* 183 */     return this.backgroundAlpha == 0 ? 1 : 0;
/*     */   }
/*     */   
/*     */   void deregister()
/*     */   {
/* 188 */     super.deregister();
/* 189 */     if (this.scrolledHandle != 0L) this.display.removeWidget(this.scrolledHandle);
/*     */   }
/*     */   
/*     */   void destroyScrollBar(ScrollBar bar) {
/* 193 */     setScrollBarVisible(bar, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   int getBorderWidthInPixels()
/*     */   {
/* 200 */     checkWidget();
/* 201 */     int border = 0;
/* 202 */     if (this.fixedHandle != 0L) border += GTK.gtk_container_get_border_width(this.fixedHandle);
/* 203 */     if (this.scrolledHandle != 0L) {
/* 204 */       border += GTK.gtk_container_get_border_width(this.scrolledHandle);
/* 205 */       if (GTK.gtk_scrolled_window_get_shadow_type(this.scrolledHandle) != 0) {
/* 206 */         border += getThickness(this.scrolledHandle).x;
/*     */       }
/*     */     }
/* 209 */     return border;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Rectangle getClientArea()
/*     */   {
/* 226 */     checkWidget();
/* 227 */     return DPIUtil.autoScaleDown(getClientAreaInPixels());
/*     */   }
/*     */   
/*     */   Rectangle getClientAreaInPixels() {
/* 231 */     checkWidget();
/* 232 */     forceResize();
/* 233 */     long clientHandle = clientHandle();
/* 234 */     GtkAllocation allocation = new GtkAllocation();
/* 235 */     GTK.gtk_widget_get_allocation(clientHandle, allocation);
/* 236 */     int x = allocation.x;
/* 237 */     int y = allocation.y;
/* 238 */     int width = (this.state & 0x200) != 0 ? 0 : allocation.width;
/* 239 */     int height = (this.state & 0x400) != 0 ? 0 : allocation.height;
/* 240 */     return new Rectangle(x, y, width, height);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ScrollBar getHorizontalBar()
/*     */   {
/* 254 */     checkWidget();
/* 255 */     return this.horizontalBar;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getScrollbarsMode()
/*     */   {
/* 279 */     checkWidget();
/* 280 */     if ((GTK.GTK_VERSION >= OS.VERSION(3, 16, 0)) && (GTK.gtk_scrolled_window_get_overlay_scrolling(this.scrolledHandle))) {
/* 281 */       return 2;
/*     */     }
/* 283 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ScrollBar getVerticalBar()
/*     */   {
/* 297 */     checkWidget();
/* 298 */     return this.verticalBar;
/*     */   }
/*     */   
/*     */   long gtk_scroll_event(long widget, long eventPtr)
/*     */   {
/* 303 */     long result = super.gtk_scroll_event(widget, eventPtr);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 310 */     if ((this.state & 0x2) != 0)
/*     */     {
/* 312 */       GdkEventScroll gdkEvent = new GdkEventScroll();
/* 313 */       OS.memmove(gdkEvent, eventPtr, GdkEventScroll.sizeof);
/* 314 */       if (gdkEvent.direction == 4) {
/* 315 */         double[] delta_x = new double[1];double[] delta_y = new double[1];
/* 316 */         if (GDK.gdk_event_get_scroll_deltas(eventPtr, delta_x, delta_y)) {
/* 317 */           if (delta_x[0] != 0.0D) {
/* 318 */             ScrollBar scrollBar = this.horizontalBar;
/* 319 */             if ((scrollBar != null) && (!GTK.gtk_widget_get_visible(scrollBar.handle)) && (scrollBar.getEnabled())) {
/* 320 */               GtkAdjustment adjustment = new GtkAdjustment();
/* 321 */               gtk_adjustment_get(scrollBar.adjustmentHandle, adjustment);
/* 322 */               double delta = Math.pow(adjustment.page_size, 0.6666666666666666D) * delta_x[0];
/* 323 */               int value = (int)Math.max(adjustment.lower, 
/* 324 */                 Math.min(adjustment.upper - adjustment.page_size, adjustment.value + delta));
/* 325 */               GTK.gtk_adjustment_set_value(scrollBar.adjustmentHandle, value);
/* 326 */               result = 1L;
/*     */             }
/*     */           }
/* 329 */           if (delta_y[0] != 0.0D) {
/* 330 */             ScrollBar scrollBar = this.verticalBar;
/* 331 */             if ((scrollBar != null) && (!GTK.gtk_widget_get_visible(scrollBar.handle)) && (scrollBar.getEnabled())) {
/* 332 */               GtkAdjustment adjustment = new GtkAdjustment();
/* 333 */               gtk_adjustment_get(scrollBar.adjustmentHandle, adjustment);
/* 334 */               double delta = Math.pow(adjustment.page_size, 0.6666666666666666D) * delta_y[0];
/* 335 */               int value = (int)Math.max(adjustment.lower, 
/* 336 */                 Math.min(adjustment.upper - adjustment.page_size, adjustment.value + delta));
/* 337 */               GTK.gtk_adjustment_set_value(scrollBar.adjustmentHandle, value);
/* 338 */               result = 1L;
/*     */             }
/*     */           }
/*     */         } } else { ScrollBar scrollBar;
/*     */         ScrollBar scrollBar;
/* 343 */         if ((gdkEvent.direction == 0) || (gdkEvent.direction == 1)) {
/* 344 */           scrollBar = this.verticalBar;
/*     */         } else {
/* 346 */           scrollBar = this.horizontalBar;
/*     */         }
/* 348 */         if ((scrollBar != null) && (!GTK.gtk_widget_get_visible(scrollBar.handle)) && (scrollBar.getEnabled())) {
/* 349 */           GtkAdjustment adjustment = new GtkAdjustment();
/* 350 */           gtk_adjustment_get(scrollBar.adjustmentHandle, adjustment);
/*     */           
/* 352 */           int wheel_delta = (int)Math.pow(adjustment.page_size, 0.6666666666666666D);
/* 353 */           if ((gdkEvent.direction == 0) || (gdkEvent.direction == 2))
/* 354 */             wheel_delta = -wheel_delta;
/* 355 */           int value = (int)Math.max(adjustment.lower, 
/* 356 */             Math.min(adjustment.upper - adjustment.page_size, adjustment.value + wheel_delta));
/* 357 */           GTK.gtk_adjustment_set_value(scrollBar.adjustmentHandle, value);
/* 358 */           return 1L;
/*     */         }
/*     */       }
/*     */     }
/* 362 */     return result;
/*     */   }
/*     */   
/*     */   int hScrollBarWidth() {
/* 366 */     Point hScrollbarSize = hScrollbarSize();
/* 367 */     return hScrollbarSize.y;
/*     */   }
/*     */   
/*     */   void reskinChildren(int flags)
/*     */   {
/* 372 */     if (this.horizontalBar != null) this.horizontalBar.reskin(flags);
/* 373 */     if (this.verticalBar != null) this.verticalBar.reskin(flags);
/* 374 */     super.reskinChildren(flags);
/*     */   }
/*     */   
/*     */   boolean sendLeaveNotify()
/*     */   {
/* 379 */     return this.scrolledHandle != 0L;
/*     */   }
/*     */   
/*     */   void setOrientation(boolean create)
/*     */   {
/* 384 */     super.setOrientation(create);
/* 385 */     if (((this.style & 0x4000000) != 0) || (!create)) {
/* 386 */       int dir = (this.style & 0x4000000) != 0 ? 2 : 1;
/* 387 */       if (this.scrolledHandle != 0L) {
/* 388 */         GTK.gtk_widget_set_direction(this.scrolledHandle, dir);
/*     */       }
/*     */     }
/* 391 */     if (this.horizontalBar != null) this.horizontalBar.setOrientation(create);
/* 392 */     if (this.verticalBar != null) this.verticalBar.setOrientation(create);
/*     */   }
/*     */   
/*     */   boolean setScrollBarVisible(ScrollBar bar, boolean visible) {
/* 396 */     if (this.scrolledHandle == 0L) return false;
/* 397 */     int[] hsp = new int[1];int[] vsp = new int[1];
/* 398 */     GTK.gtk_scrolled_window_get_policy(this.scrolledHandle, hsp, vsp);
/* 399 */     int policy = visible ? 0 : 2;
/* 400 */     if ((GTK.GTK_VERSION >= OS.VERSION(3, 16, 0)) && (!visible)) {
/* 401 */       policy = 3;
/*     */     }
/* 403 */     if ((bar.style & 0x100) != 0) {
/* 404 */       if (hsp[0] == policy) return false;
/* 405 */       hsp[0] = policy;
/*     */     } else {
/* 407 */       if (vsp[0] == policy) return false;
/* 408 */       vsp[0] = policy;
/*     */     }
/* 410 */     GTK.gtk_scrolled_window_set_policy(this.scrolledHandle, hsp[0], vsp[0]);
/* 411 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   void redrawBackgroundImage() {}
/*     */   
/*     */   void redrawWidget(int x, int y, int width, int height, boolean redrawAll, boolean all, boolean trim)
/*     */   {
/* 419 */     super.redrawWidget(x, y, width, height, redrawAll, all, trim);
/* 420 */     if (!GTK.gtk_widget_get_realized(this.handle)) return;
/* 421 */     if (!trim) return;
/* 422 */     long topHandle = topHandle();long paintHandle = paintHandle();
/* 423 */     if (topHandle == paintHandle) return;
/* 424 */     long window = gtk_widget_get_window(topHandle);
/* 425 */     GdkRectangle rect = new GdkRectangle();
/* 426 */     if (redrawAll) {
/* 427 */       GtkAllocation allocation = new GtkAllocation();
/* 428 */       GTK.gtk_widget_get_allocation(topHandle, allocation);
/* 429 */       rect.width = allocation.width;
/* 430 */       rect.height = allocation.height;
/*     */     } else {
/* 432 */       int[] destX = new int[1];int[] destY = new int[1];
/* 433 */       GTK.gtk_widget_translate_coordinates(paintHandle, topHandle, x, y, destX, destY);
/* 434 */       rect.x = destX[0];
/* 435 */       rect.y = destY[0];
/* 436 */       rect.width = Math.max(0, width);
/* 437 */       rect.height = Math.max(0, height);
/*     */     }
/* 439 */     GDK.gdk_window_invalidate_rect(window, rect, all);
/*     */   }
/*     */   
/*     */   void register()
/*     */   {
/* 444 */     super.register();
/* 445 */     if (this.scrolledHandle != 0L) this.display.addWidget(this.scrolledHandle, this);
/*     */   }
/*     */   
/*     */   void releaseHandle()
/*     */   {
/* 450 */     super.releaseHandle();
/* 451 */     this.scrolledHandle = 0L;
/*     */   }
/*     */   
/*     */   void releaseChildren(boolean destroy)
/*     */   {
/* 456 */     if (this.horizontalBar != null) {
/* 457 */       this.horizontalBar.release(false);
/* 458 */       this.horizontalBar = null;
/*     */     }
/* 460 */     if (this.verticalBar != null) {
/* 461 */       this.verticalBar.release(false);
/* 462 */       this.verticalBar = null;
/*     */     }
/* 464 */     super.releaseChildren(destroy);
/*     */   }
/*     */   
/*     */   void resizeHandle(int width, int height)
/*     */   {
/* 469 */     if (GTK.GTK3) {
/* 470 */       if (this.fixedHandle != 0L) {
/* 471 */         OS.swt_fixed_resize(GTK.gtk_widget_get_parent(this.fixedHandle), this.fixedHandle, width, height);
/*     */       }
/* 473 */       long child = this.scrolledHandle != 0L ? this.scrolledHandle : this.handle;
/* 474 */       Point sizes = resizeCalculationsGTK3(child, width, height);
/* 475 */       width = sizes.x;
/* 476 */       height = sizes.y;
/* 477 */       OS.swt_fixed_resize(GTK.gtk_widget_get_parent(child), child, width, height);
/*     */     } else {
/* 479 */       if (this.fixedHandle != 0L) GTK.gtk_widget_set_size_request(this.fixedHandle, width, height);
/* 480 */       GTK.gtk_widget_set_size_request(this.scrolledHandle != 0L ? this.scrolledHandle : this.handle, width, height);
/*     */     }
/*     */   }
/*     */   
/*     */   void showWidget()
/*     */   {
/* 486 */     super.showWidget();
/* 487 */     if (this.scrolledHandle != 0L) GTK.gtk_widget_show(this.scrolledHandle);
/*     */   }
/*     */   
/*     */   long topHandle()
/*     */   {
/* 492 */     if (this.fixedHandle != 0L) return this.fixedHandle;
/* 493 */     if (this.scrolledHandle != 0L) return this.scrolledHandle;
/* 494 */     return super.topHandle();
/*     */   }
/*     */   
/*     */   void updateScrollBarValue(ScrollBar bar) {
/* 498 */     redrawBackgroundImage();
/*     */   }
/*     */   
/*     */   int vScrollBarWidth() {
/* 502 */     Point vScrollBarSize = vScrollBarSize();
/* 503 */     return vScrollBarSize.x;
/*     */   }
/*     */   
/*     */   private Point hScrollbarSize() {
/* 507 */     if (this.horizontalBar == null) return new Point(0, 0);
/* 508 */     long vBarHandle = GTK.gtk_scrolled_window_get_hscrollbar(this.scrolledHandle);
/* 509 */     return scrollBarSize(vBarHandle);
/*     */   }
/*     */   
/*     */   private Point vScrollBarSize() {
/* 513 */     if (this.verticalBar == null) return new Point(0, 0);
/* 514 */     long vBarHandle = GTK.gtk_scrolled_window_get_vscrollbar(this.scrolledHandle);
/* 515 */     return scrollBarSize(vBarHandle);
/*     */   }
/*     */   
/*     */   private Point scrollBarSize(long scrollBarHandle) {
/* 519 */     if (scrollBarHandle == 0L) return new Point(0, 0);
/* 520 */     GtkRequisition requisition = new GtkRequisition();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 526 */     if (GTK.GTK_VERSION >= OS.VERSION(3, 20, 0)) {
/* 527 */       GTK.gtk_widget_queue_resize(scrollBarHandle);
/*     */     }
/* 529 */     gtk_widget_get_preferred_size(scrollBarHandle, requisition);
/* 530 */     int[] padding = new int[1];
/* 531 */     GTK.gtk_widget_style_get(this.scrolledHandle, OS.scrollbar_spacing, padding, 0L);
/* 532 */     int spacing = padding[0];
/* 533 */     return new Point(requisition.width + spacing, requisition.height + spacing);
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/widgets/Scrollable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */