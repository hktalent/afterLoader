/*     */ package org.eclipse.swt.widgets;
/*     */ 
/*     */ import org.eclipse.swt.events.SelectionListener;
/*     */ import org.eclipse.swt.graphics.Point;
/*     */ import org.eclipse.swt.graphics.Rectangle;
/*     */ import org.eclipse.swt.internal.DPIUtil;
/*     */ import org.eclipse.swt.internal.ImageList;
/*     */ import org.eclipse.swt.internal.gtk.GTK;
/*     */ import org.eclipse.swt.internal.gtk.GdkColor;
/*     */ import org.eclipse.swt.internal.gtk.GdkRGBA;
/*     */ import org.eclipse.swt.internal.gtk.GtkAllocation;
/*     */ import org.eclipse.swt.internal.gtk.OS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TabFolder
/*     */   extends Composite
/*     */ {
/*     */   TabItem[] items;
/*     */   ImageList imageList;
/*     */   
/*     */   public TabFolder(Composite parent, int style)
/*     */   {
/* 122 */     super(parent, checkStyle(style));
/*     */   }
/*     */   
/*     */   static int checkStyle(int style) {
/* 126 */     style = checkBits(style, 128, 1024, 0, 0, 0, 0);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 134 */     return style & 0xFCFF;
/*     */   }
/*     */   
/*     */   protected void checkSubclass()
/*     */   {
/* 139 */     if (!isValidSubclass()) error(43);
/*     */   }
/*     */   
/*     */   long childStyle()
/*     */   {
/* 144 */     long rcStyle = GTK.gtk_widget_get_modifier_style(this.handle);
/* 145 */     if ((GTK.gtk_rc_style_get_color_flags(rcStyle, 0) & 0x2) != 0) return 0L;
/* 146 */     GTK.gtk_widget_realize(this.handle);
/* 147 */     return GTK.gtk_widget_get_style(this.handle);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addSelectionListener(SelectionListener listener)
/*     */   {
/* 175 */     checkWidget();
/* 176 */     if (listener == null) error(4);
/* 177 */     TypedListener typedListener = new TypedListener(listener);
/* 178 */     addListener(13, typedListener);
/* 179 */     addListener(14, typedListener);
/*     */   }
/*     */   
/*     */   long clientHandle()
/*     */   {
/* 184 */     int index = GTK.gtk_notebook_get_current_page(this.handle);
/* 185 */     if ((index != -1) && (this.items[index] != null)) {
/* 186 */       return this.items[index].pageHandle;
/*     */     }
/* 188 */     return this.handle;
/*     */   }
/*     */   
/*     */   Point computeSizeInPixels(int wHint, int hHint, boolean changed)
/*     */   {
/* 193 */     checkWidget();
/* 194 */     Point size = super.computeSizeInPixels(wHint, hHint, changed);
/* 195 */     if ((wHint != -1) && (wHint < 0)) wHint = 0;
/* 196 */     if ((hHint != -1) && (hHint < 0)) hHint = 0;
/* 197 */     boolean scrollable = GTK.gtk_notebook_get_scrollable(this.handle);
/* 198 */     GTK.gtk_notebook_set_scrollable(this.handle, false);
/* 199 */     Point notebookSize = computeNativeSize(this.handle, wHint, hHint, changed);
/* 200 */     GTK.gtk_notebook_set_scrollable(this.handle, scrollable);
/* 201 */     if (GTK.GTK_VERSION >= OS.VERSION(3, 2, 0)) {
/* 202 */       int[] initialGap = new int[1];
/* 203 */       GTK.gtk_widget_style_get(this.handle, OS.initial_gap, initialGap, 0L);
/* 204 */       notebookSize.x += initialGap[0] * 2;
/*     */     }
/* 206 */     size.x = Math.max(notebookSize.x, size.x);
/* 207 */     size.y = Math.max(notebookSize.y, size.y);
/* 208 */     return size;
/*     */   }
/*     */   
/*     */   Rectangle computeTrimInPixels(int x, int y, int width, int height)
/*     */   {
/* 213 */     checkWidget();
/* 214 */     forceResize();
/* 215 */     long clientHandle = clientHandle();
/* 216 */     GtkAllocation allocation = new GtkAllocation();
/* 217 */     GTK.gtk_widget_get_allocation(clientHandle, allocation);
/* 218 */     int clientX = allocation.x;
/* 219 */     int clientY = allocation.y;
/* 220 */     x -= clientX;
/* 221 */     y -= clientY;
/* 222 */     width += clientX + clientX;
/* 223 */     if ((this.style & 0x400) != 0) {
/* 224 */       int clientHeight = allocation.height;
/* 225 */       GTK.gtk_widget_get_allocation(this.handle, allocation);
/* 226 */       int parentHeight = allocation.height;
/* 227 */       height += parentHeight - clientHeight;
/*     */     } else {
/* 229 */       height += clientX + clientY;
/*     */     }
/* 231 */     return new Rectangle(x, y, width, height);
/*     */   }
/*     */   
/*     */   Rectangle getClientAreaInPixels()
/*     */   {
/* 236 */     Rectangle clientRectangle = super.getClientAreaInPixels();
/*     */     
/* 238 */     if (GTK.GTK3)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 254 */       clientRectangle.x = 0;
/* 255 */       clientRectangle.y = 0;
/*     */     }
/* 257 */     return clientRectangle;
/*     */   }
/*     */   
/*     */ 
/*     */   void createHandle(int index)
/*     */   {
/* 263 */     this.state |= 0x8;
/* 264 */     this.fixedHandle = OS.g_object_new(this.display.gtk_fixed_get_type(), 0L);
/* 265 */     if (this.fixedHandle == 0L) error(2);
/* 266 */     GTK.gtk_widget_set_has_window(this.fixedHandle, true);
/* 267 */     this.handle = GTK.gtk_notebook_new();
/* 268 */     if (this.handle == 0L) error(2);
/* 269 */     GTK.gtk_container_add(this.fixedHandle, this.handle);
/* 270 */     GTK.gtk_notebook_set_show_tabs(this.handle, true);
/* 271 */     GTK.gtk_notebook_set_scrollable(this.handle, true);
/* 272 */     if ((this.style & 0x400) != 0) {
/* 273 */       GTK.gtk_notebook_set_tab_pos(this.handle, 3);
/*     */     }
/*     */   }
/*     */   
/*     */   void createWidget(int index)
/*     */   {
/* 279 */     super.createWidget(index);
/* 280 */     this.items = new TabItem[4];
/*     */   }
/*     */   
/*     */   void createItem(TabItem item, int index) {
/* 284 */     long list = GTK.gtk_container_get_children(this.handle);
/* 285 */     int itemCount = 0;
/* 286 */     if (list != 0L) {
/* 287 */       itemCount = OS.g_list_length(list);
/* 288 */       OS.g_list_free(list);
/*     */     }
/* 290 */     if ((0 > index) || (index > itemCount)) error(6);
/* 291 */     if (itemCount == this.items.length) {
/* 292 */       TabItem[] newItems = new TabItem[this.items.length + 4];
/* 293 */       System.arraycopy(this.items, 0, newItems, 0, this.items.length);
/* 294 */       this.items = newItems;
/*     */     }
/* 296 */     long boxHandle = gtk_box_new(0, false, 0);
/* 297 */     if (boxHandle == 0L) error(2);
/* 298 */     long labelHandle = GTK.gtk_label_new_with_mnemonic(null);
/* 299 */     if (labelHandle == 0L) error(2);
/* 300 */     long imageHandle = GTK.gtk_image_new();
/* 301 */     if (imageHandle == 0L) error(2);
/* 302 */     GTK.gtk_container_add(boxHandle, imageHandle);
/* 303 */     GTK.gtk_container_add(boxHandle, labelHandle);
/* 304 */     long pageHandle = OS.g_object_new(this.display.gtk_fixed_get_type(), 0L);
/* 305 */     if (pageHandle == 0L) error(2);
/* 306 */     OS.g_signal_handlers_block_matched(this.handle, 16, 0, 0, 0L, 0L, 49L);
/* 307 */     GTK.gtk_notebook_insert_page(this.handle, pageHandle, boxHandle, index);
/* 308 */     OS.g_signal_handlers_unblock_matched(this.handle, 16, 0, 0, 0L, 0L, 49L);
/* 309 */     GTK.gtk_widget_show(boxHandle);
/* 310 */     GTK.gtk_widget_show(labelHandle);
/* 311 */     GTK.gtk_widget_show(pageHandle);
/* 312 */     item.state |= 0x8;
/* 313 */     item.handle = boxHandle;
/* 314 */     item.labelHandle = labelHandle;
/* 315 */     item.imageHandle = imageHandle;
/* 316 */     item.pageHandle = pageHandle;
/* 317 */     System.arraycopy(this.items, index, this.items, index + 1, itemCount++ - index);
/* 318 */     this.items[index] = item;
/* 319 */     if ((this.state & 0x1000) != 0) {
/* 320 */       item.setForegroundGdkColor(getForegroundGdkColor());
/*     */     }
/* 322 */     if ((this.state & 0x4000) != 0) {
/* 323 */       item.setFontDescription(getFontDescription());
/*     */     }
/* 325 */     if (itemCount == 1) {
/* 326 */       OS.g_signal_handlers_block_matched(this.handle, 16, 0, 0, 0L, 0L, 49L);
/* 327 */       GTK.gtk_notebook_set_current_page(this.handle, 0);
/* 328 */       OS.g_signal_handlers_unblock_matched(this.handle, 16, 0, 0, 0L, 0L, 49L);
/* 329 */       Event event = new Event();
/* 330 */       event.item = this.items[0];
/* 331 */       sendSelectionEvent(13, event, false);
/*     */     }
/*     */   }
/*     */   
/*     */   void destroyItem(TabItem item)
/*     */   {
/* 337 */     int index = 0;
/* 338 */     int itemCount = getItemCount();
/* 339 */     while ((index < itemCount) && 
/* 340 */       (this.items[index] != item)) {
/* 341 */       index++;
/*     */     }
/* 343 */     if (index == itemCount) error(15);
/* 344 */     int oldIndex = GTK.gtk_notebook_get_current_page(this.handle);
/* 345 */     OS.g_signal_handlers_block_matched(this.handle, 16, 0, 0, 0L, 0L, 49L);
/* 346 */     GTK.gtk_notebook_remove_page(this.handle, index);
/* 347 */     OS.g_signal_handlers_unblock_matched(this.handle, 16, 0, 0, 0L, 0L, 49L);
/* 348 */     System.arraycopy(this.items, index + 1, this.items, index, --itemCount - index);
/* 349 */     this.items[itemCount] = null;
/* 350 */     if (index == oldIndex) {
/* 351 */       int newIndex = GTK.gtk_notebook_get_current_page(this.handle);
/* 352 */       if (newIndex != -1) {
/* 353 */         Control control = this.items[newIndex].getControl();
/* 354 */         if ((control != null) && (!control.isDisposed())) {
/* 355 */           control.setBoundsInPixels(getClientAreaInPixels());
/* 356 */           control.setVisible(true);
/*     */         }
/* 358 */         Event event = new Event();
/* 359 */         event.item = this.items[newIndex];
/* 360 */         sendSelectionEvent(13, event, true);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   long eventHandle()
/*     */   {
/* 368 */     return this.handle;
/*     */   }
/*     */   
/*     */   Control[] _getChildren()
/*     */   {
/* 373 */     Control[] directChildren = super._getChildren();
/* 374 */     if (GTK.GTK3) {
/* 375 */       int directCount = directChildren.length;
/* 376 */       int count = this.items == null ? 0 : this.items.length;
/* 377 */       Control[] children = new Control[count + directCount];
/* 378 */       int i = 0;
/* 379 */       for (int j = 0; j < count; j++) {
/* 380 */         TabItem tabItem = this.items[j];
/* 381 */         if ((tabItem != null) && (!tabItem.isDisposed())) {
/* 382 */           long parentHandle = tabItem.pageHandle;
/* 383 */           long list = GTK.gtk_container_get_children(parentHandle);
/* 384 */           if (list != 0L) {
/* 385 */             long handle = OS.g_list_data(list);
/* 386 */             if (handle != 0L) {
/* 387 */               Widget widget = this.display.getWidget(handle);
/* 388 */               if ((widget != null) && (widget != this) && 
/* 389 */                 ((widget instanceof Control))) {
/* 390 */                 children[(i++)] = ((Control)widget);
/*     */               }
/*     */             }
/*     */             
/* 394 */             OS.g_list_free(list);
/*     */           }
/*     */         }
/*     */       }
/* 398 */       if (i == count + directCount) return children;
/*     */       Control[] newChildren;
/* 400 */       Control[] newChildren; if (i == count) {
/* 401 */         newChildren = children;
/*     */       } else {
/* 403 */         newChildren = new Control[i + directCount];
/* 404 */         System.arraycopy(children, 0, newChildren, 0, i);
/*     */       }
/* 406 */       System.arraycopy(directChildren, 0, newChildren, i, directCount);
/* 407 */       return newChildren;
/*     */     }
/*     */     
/* 410 */     return directChildren;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TabItem getItem(int index)
/*     */   {
/* 430 */     checkWidget();
/* 431 */     if ((0 > index) || (index >= getItemCount())) error(6);
/* 432 */     long list = GTK.gtk_container_get_children(this.handle);
/* 433 */     if (list == 0L) error(8);
/* 434 */     int itemCount = OS.g_list_length(list);
/* 435 */     OS.g_list_free(list);
/* 436 */     if ((0 > index) || (index >= itemCount)) error(8);
/* 437 */     return this.items[index];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TabItem getItem(Point point)
/*     */   {
/* 459 */     checkWidget();
/* 460 */     if (point == null) error(4);
/* 461 */     long list = GTK.gtk_container_get_children(this.handle);
/* 462 */     if (list == 0L) return null;
/* 463 */     int itemCount = OS.g_list_length(list);
/* 464 */     OS.g_list_free(list);
/* 465 */     for (int i = 0; i < itemCount; i++) {
/* 466 */       TabItem item = this.items[i];
/* 467 */       Rectangle rect = item.getBounds();
/* 468 */       if (rect.contains(point)) return item;
/*     */     }
/* 470 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getItemCount()
/*     */   {
/* 484 */     checkWidget();
/* 485 */     long list = GTK.gtk_container_get_children(this.handle);
/* 486 */     if (list == 0L) return 0;
/* 487 */     int itemCount = OS.g_list_length(list);
/* 488 */     OS.g_list_free(list);
/* 489 */     return itemCount;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TabItem[] getItems()
/*     */   {
/* 509 */     checkWidget();
/* 510 */     int count = getItemCount();
/* 511 */     TabItem[] result = new TabItem[count];
/* 512 */     System.arraycopy(this.items, 0, result, 0, count);
/* 513 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TabItem[] getSelection()
/*     */   {
/* 533 */     checkWidget();
/* 534 */     int index = GTK.gtk_notebook_get_current_page(this.handle);
/* 535 */     if (index == -1) return new TabItem[0];
/* 536 */     return new TabItem[] { this.items[index] };
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getSelectionIndex()
/*     */   {
/* 551 */     checkWidget();
/* 552 */     return GTK.gtk_notebook_get_current_page(this.handle);
/*     */   }
/*     */   
/*     */   long gtk_focus(long widget, long directionType)
/*     */   {
/* 557 */     return 0L;
/*     */   }
/*     */   
/*     */   long gtk_switch_page(long widget, long page, long page_num)
/*     */   {
/* 562 */     int index = GTK.gtk_notebook_get_current_page(this.handle);
/* 563 */     if (index != -1) {
/* 564 */       Control control = this.items[index].getControl();
/* 565 */       if ((control != null) && (!control.isDisposed())) {
/* 566 */         control.setVisible(false);
/*     */       }
/*     */     } else {
/* 569 */       return 0L;
/*     */     }
/* 571 */     TabItem item = this.items[((int)page_num)];
/* 572 */     Control control = item.getControl();
/* 573 */     if ((control != null) && (!control.isDisposed())) {
/* 574 */       control.setBoundsInPixels(getClientAreaInPixels());
/* 575 */       control.setVisible(true);
/*     */     }
/* 577 */     Event event = new Event();
/* 578 */     event.item = item;
/* 579 */     sendSelectionEvent(13, event, false);
/* 580 */     return 0L;
/*     */   }
/*     */   
/*     */   void hookEvents()
/*     */   {
/* 585 */     super.hookEvents();
/* 586 */     OS.g_signal_connect_closure(this.handle, OS.switch_page, this.display.getClosure(49), false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int indexOf(TabItem item)
/*     */   {
/* 607 */     checkWidget();
/* 608 */     if (item == null) error(4);
/* 609 */     long list = GTK.gtk_container_get_children(this.handle);
/* 610 */     if (list == 0L) return -1;
/* 611 */     int count = OS.g_list_length(list);
/* 612 */     OS.g_list_free(list);
/* 613 */     for (int i = 0; i < count; i++) {
/* 614 */       if (this.items[i] == item) return i;
/*     */     }
/* 616 */     return -1;
/*     */   }
/*     */   
/*     */   Point minimumSize(int wHint, int hHint, boolean flushCache)
/*     */   {
/* 621 */     Control[] children = _getChildren();
/* 622 */     int width = 0;int height = 0;
/* 623 */     for (int i = 0; i < children.length; i++) {
/* 624 */       Control child = children[i];
/* 625 */       int index = 0;
/* 626 */       int count = 0;
/* 627 */       long list = GTK.gtk_container_get_children(this.handle);
/* 628 */       if (list != 0L) {
/* 629 */         count = OS.g_list_length(list);
/* 630 */         OS.g_list_free(list);
/*     */       }
/* 632 */       while ((index < count) && 
/* 633 */         (this.items[index].control != child)) {
/* 634 */         index++;
/*     */       }
/* 636 */       if (index == count) {
/* 637 */         Rectangle rect = DPIUtil.autoScaleUp(child.getBounds());
/* 638 */         width = Math.max(width, rect.x + rect.width);
/* 639 */         height = Math.max(height, rect.y + rect.height);
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/*     */ 
/* 645 */         Point size = DPIUtil.autoScaleUp(child.computeSize(DPIUtil.autoScaleDown(wHint), DPIUtil.autoScaleDown(hHint), flushCache));
/* 646 */         width = Math.max(width, size.x);
/* 647 */         height = Math.max(height, size.y);
/*     */       }
/*     */     }
/* 650 */     return new Point(width, height);
/*     */   }
/*     */   
/*     */   boolean mnemonicHit(char key)
/*     */   {
/* 655 */     int itemCount = getItemCount();
/* 656 */     for (int i = 0; i < itemCount; i++) {
/* 657 */       long labelHandle = this.items[i].labelHandle;
/* 658 */       if ((labelHandle != 0L) && (mnemonicHit(labelHandle, key))) return true;
/*     */     }
/* 660 */     return false;
/*     */   }
/*     */   
/*     */   boolean mnemonicMatch(char key)
/*     */   {
/* 665 */     int itemCount = getItemCount();
/* 666 */     for (int i = 0; i < itemCount; i++) {
/* 667 */       long labelHandle = this.items[i].labelHandle;
/* 668 */       if ((labelHandle != 0L) && (mnemonicHit(labelHandle, key))) return true;
/*     */     }
/* 670 */     return false;
/*     */   }
/*     */   
/*     */   void releaseChildren(boolean destroy)
/*     */   {
/* 675 */     if (this.items != null) {
/* 676 */       for (int i = 0; i < this.items.length; i++) {
/* 677 */         TabItem item = this.items[i];
/* 678 */         if ((item != null) && (!item.isDisposed())) {
/* 679 */           item.release(false);
/*     */         }
/*     */       }
/* 682 */       this.items = null;
/*     */     }
/* 684 */     super.releaseChildren(destroy);
/*     */   }
/*     */   
/*     */   void releaseWidget()
/*     */   {
/* 689 */     super.releaseWidget();
/* 690 */     if (this.imageList != null) this.imageList.dispose();
/* 691 */     this.imageList = null;
/*     */   }
/*     */   
/*     */   void removeControl(Control control)
/*     */   {
/* 696 */     super.removeControl(control);
/* 697 */     int count = getItemCount();
/* 698 */     for (int i = 0; i < count; i++) {
/* 699 */       TabItem item = this.items[i];
/* 700 */       if (item.control == control) { item.setControl(null);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeSelectionListener(SelectionListener listener)
/*     */   {
/* 722 */     checkWidget();
/* 723 */     if (listener == null) error(4);
/* 724 */     if (this.eventTable == null) return;
/* 725 */     this.eventTable.unhook(13, listener);
/* 726 */     this.eventTable.unhook(14, listener);
/*     */   }
/*     */   
/*     */   void reskinChildren(int flags)
/*     */   {
/* 731 */     if (this.items != null) {
/* 732 */       long list = GTK.gtk_container_get_children(this.handle);
/* 733 */       if (list != 0L) {
/* 734 */         int count = OS.g_list_length(list);
/* 735 */         OS.g_list_free(list);
/* 736 */         for (int i = 0; i < count; i++) {
/* 737 */           TabItem item = this.items[i];
/* 738 */           if (item != null) item.reskin(flags);
/*     */         }
/*     */       }
/*     */     }
/* 742 */     super.reskinChildren(flags);
/*     */   }
/*     */   
/*     */   void setBackgroundGdkRGBA(long context, long handle, GdkRGBA rgba)
/*     */   {
/* 747 */     assert (GTK.GTK3) : "GTK3 code was run by GTK2";
/* 748 */     if (GTK.GTK_VERSION >= OS.VERSION(3, 14, 0))
/*     */     {
/* 750 */       String name = GTK.GTK_VERSION >= OS.VERSION(3, 20, 0) ? "notebook header" : "GtkNotebook.header";
/* 751 */       String css = name + " {background-color: " + this.display.gtk_rgba_to_css_string(rgba) + ";}";
/*     */       
/*     */ 
/* 754 */       this.cssBackground = css;
/*     */       
/*     */ 
/* 757 */       String finalCss = this.display.gtk_css_create_css_color_string(this.cssBackground, this.cssForeground, 8);
/* 758 */       gtk_css_provider_load_from_css(context, finalCss);
/*     */     } else {
/* 760 */       GTK.gtk_widget_override_background_color(handle, 0, rgba);
/*     */     }
/*     */   }
/*     */   
/*     */   int setBounds(int x, int y, int width, int height, boolean move, boolean resize)
/*     */   {
/* 766 */     int result = super.setBounds(x, y, width, height, move, resize);
/* 767 */     if ((result & 0x100) != 0) {
/* 768 */       int index = getSelectionIndex();
/* 769 */       if (index != -1) {
/* 770 */         TabItem item = this.items[index];
/* 771 */         Control control = item.control;
/* 772 */         if ((control != null) && (!control.isDisposed())) {
/* 773 */           control.setBoundsInPixels(getClientAreaInPixels());
/*     */         }
/*     */       }
/*     */     }
/* 777 */     return result;
/*     */   }
/*     */   
/*     */   void setFontDescription(long font)
/*     */   {
/* 782 */     super.setFontDescription(font);
/* 783 */     TabItem[] items = getItems();
/* 784 */     for (int i = 0; i < items.length; i++) {
/* 785 */       if (items[i] != null) {
/* 786 */         items[i].setFontDescription(font);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   void setForegroundGdkRGBA(GdkRGBA rgba)
/*     */   {
/* 793 */     assert (GTK.GTK3) : "GTK3 code was run by GTK2";
/* 794 */     super.setForegroundGdkRGBA(rgba);
/* 795 */     TabItem[] items = getItems();
/* 796 */     for (int i = 0; i < items.length; i++) {
/* 797 */       if (items[i] != null) {
/* 798 */         items[i].setForegroundRGBA(rgba);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   void setForegroundGdkColor(GdkColor color)
/*     */   {
/* 805 */     assert (!GTK.GTK3) : "GTK2 code was run by GTK3";
/* 806 */     super.setForegroundGdkColor(color);
/* 807 */     TabItem[] items = getItems();
/* 808 */     for (int i = 0; i < items.length; i++) {
/* 809 */       if (items[i] != null) {
/* 810 */         items[i].setForegroundGdkColor(color);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   void setOrientation(boolean create)
/*     */   {
/* 817 */     super.setOrientation(create);
/* 818 */     if (this.items != null) {
/* 819 */       for (int i = 0; i < this.items.length; i++) {
/* 820 */         if (this.items[i] != null) { this.items[i].setOrientation(create);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSelection(int index)
/*     */   {
/* 839 */     checkWidget();
/* 840 */     if ((0 > index) || (index >= getItemCount())) return;
/* 841 */     setSelection(index, false);
/*     */   }
/*     */   
/*     */   void setSelection(int index, boolean notify) {
/* 845 */     if (index < 0) return;
/* 846 */     int oldIndex = GTK.gtk_notebook_get_current_page(this.handle);
/* 847 */     if (oldIndex == index) return;
/* 848 */     if (oldIndex != -1) {
/* 849 */       TabItem item = this.items[oldIndex];
/* 850 */       Control control = item.control;
/* 851 */       if ((control != null) && (!control.isDisposed())) {
/* 852 */         control.setVisible(false);
/*     */       }
/*     */     }
/* 855 */     OS.g_signal_handlers_block_matched(this.handle, 16, 0, 0, 0L, 0L, 49L);
/* 856 */     GTK.gtk_notebook_set_current_page(this.handle, index);
/* 857 */     OS.g_signal_handlers_unblock_matched(this.handle, 16, 0, 0, 0L, 0L, 49L);
/* 858 */     int newIndex = GTK.gtk_notebook_get_current_page(this.handle);
/* 859 */     if (newIndex != -1) {
/* 860 */       TabItem item = this.items[newIndex];
/* 861 */       Control control = item.control;
/* 862 */       if ((control != null) && (!control.isDisposed())) {
/* 863 */         control.setBoundsInPixels(getClientAreaInPixels());
/* 864 */         control.setVisible(true);
/*     */       }
/* 866 */       if (notify) {
/* 867 */         Event event = new Event();
/* 868 */         event.item = item;
/* 869 */         sendSelectionEvent(13, event, true);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSelection(TabItem item)
/*     */   {
/* 892 */     if (item == null) error(4);
/* 893 */     setSelection(new TabItem[] { item });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSelection(TabItem[] items)
/*     */   {
/* 912 */     checkWidget();
/* 913 */     if (items == null) error(4);
/* 914 */     if (items.length == 0) {
/* 915 */       setSelection(-1, false);
/*     */     } else {
/* 917 */       for (int i = items.length - 1; i >= 0; i--) {
/* 918 */         int index = indexOf(items[i]);
/* 919 */         if (index != -1) setSelection(index, false);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   boolean traversePage(boolean next)
/*     */   {
/* 926 */     if (next) {
/* 927 */       GTK.gtk_notebook_next_page(this.handle);
/*     */     } else {
/* 929 */       GTK.gtk_notebook_prev_page(this.handle);
/*     */     }
/* 931 */     return true;
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/widgets/TabFolder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */