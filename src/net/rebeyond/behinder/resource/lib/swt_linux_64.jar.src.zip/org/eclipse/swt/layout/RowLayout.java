/*     */ package org.eclipse.swt.layout;
/*     */ 
/*     */ import org.eclipse.swt.graphics.Point;
/*     */ import org.eclipse.swt.graphics.Rectangle;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.swt.widgets.Control;
/*     */ import org.eclipse.swt.widgets.Layout;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class RowLayout
/*     */   extends Layout
/*     */ {
/*  73 */   public int type = 256;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  83 */   public int marginWidth = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  93 */   public int marginHeight = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 101 */   public int spacing = 3;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 109 */   public boolean wrap = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 120 */   public boolean pack = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 131 */   public boolean fill = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 142 */   public boolean center = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 150 */   public boolean justify = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 158 */   public int marginLeft = 3;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 166 */   public int marginTop = 3;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 174 */   public int marginRight = 3;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 182 */   public int marginBottom = 3;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RowLayout() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RowLayout(int type)
/*     */   {
/* 198 */     this.type = type;
/*     */   }
/*     */   
/*     */   protected Point computeSize(Composite composite, int wHint, int hHint, boolean flushCache) {
/*     */     Point extent;
/*     */     Point extent;
/* 204 */     if (this.type == 256) {
/* 205 */       extent = layoutHorizontal(composite, false, (wHint != -1) && (this.wrap), wHint, flushCache);
/*     */     } else {
/* 207 */       extent = layoutVertical(composite, false, (hHint != -1) && (this.wrap), hHint, flushCache);
/*     */     }
/* 209 */     if (wHint != -1) extent.x = wHint;
/* 210 */     if (hHint != -1) extent.y = hHint;
/* 211 */     return extent;
/*     */   }
/*     */   
/*     */   Point computeSize(Control control, boolean flushCache) {
/* 215 */     int wHint = -1;int hHint = -1;
/* 216 */     RowData data = (RowData)control.getLayoutData();
/* 217 */     if (data != null) {
/* 218 */       wHint = data.width;
/* 219 */       hHint = data.height;
/*     */     }
/* 221 */     return control.computeSize(wHint, hHint, flushCache);
/*     */   }
/*     */   
/*     */   protected boolean flushCache(Control control)
/*     */   {
/* 226 */     return true;
/*     */   }
/*     */   
/*     */   String getName() {
/* 230 */     String string = getClass().getName();
/* 231 */     int index = string.lastIndexOf('.');
/* 232 */     if (index == -1) return string;
/* 233 */     return string.substring(index + 1, string.length());
/*     */   }
/*     */   
/*     */   protected void layout(Composite composite, boolean flushCache)
/*     */   {
/* 238 */     Rectangle clientArea = composite.getClientArea();
/* 239 */     if (this.type == 256) {
/* 240 */       layoutHorizontal(composite, true, this.wrap, clientArea.width, flushCache);
/*     */     } else {
/* 242 */       layoutVertical(composite, true, this.wrap, clientArea.height, flushCache);
/*     */     }
/*     */   }
/*     */   
/*     */   Point layoutHorizontal(Composite composite, boolean move, boolean wrap, int width, boolean flushCache) {
/* 247 */     Control[] children = composite.getChildren();
/* 248 */     int count = 0;
/* 249 */     for (int i = 0; i < children.length; i++) {
/* 250 */       Control control = children[i];
/* 251 */       RowData data = (RowData)control.getLayoutData();
/* 252 */       if ((data == null) || (!data.exclude)) {
/* 253 */         children[(count++)] = children[i];
/*     */       }
/*     */     }
/* 256 */     if (count == 0) {
/* 257 */       return new Point(this.marginLeft + this.marginWidth * 2 + this.marginRight, this.marginTop + this.marginHeight * 2 + this.marginBottom);
/*     */     }
/* 259 */     int childWidth = 0;int childHeight = 0;int maxHeight = 0;
/* 260 */     if (!this.pack) {
/* 261 */       for (int i = 0; i < count; i++) {
/* 262 */         Control child = children[i];
/* 263 */         Point size = computeSize(child, flushCache);
/* 264 */         if ((width > -1) && (width < size.x) && (wrap)) {
/* 265 */           size = child.computeSize(width, child.getLayoutData() == null ? -1 : ((RowData)child.getLayoutData()).height, flushCache);
/*     */         }
/* 267 */         childWidth = Math.max(childWidth, size.x);
/* 268 */         childHeight = Math.max(childHeight, size.y);
/*     */       }
/* 270 */       maxHeight = childHeight;
/*     */     }
/* 272 */     int clientX = 0;int clientY = 0;
/* 273 */     if (move) {
/* 274 */       Rectangle rect = composite.getClientArea();
/* 275 */       clientX = rect.x;
/* 276 */       clientY = rect.y;
/*     */     }
/* 278 */     int[] wraps = null;
/* 279 */     boolean wrapped = false;
/* 280 */     Rectangle[] bounds = null;
/* 281 */     if ((move) && ((this.justify) || (this.fill) || (this.center))) {
/* 282 */       bounds = new Rectangle[count];
/* 283 */       wraps = new int[count];
/*     */     }
/* 285 */     int maxX = 0;int x = this.marginLeft + this.marginWidth;int y = this.marginTop + this.marginHeight;
/* 286 */     for (int i = 0; i < count; i++) {
/* 287 */       Control child = children[i];
/* 288 */       if (this.pack) {
/* 289 */         Point size = computeSize(child, flushCache);
/* 290 */         if ((width > -1) && (width < size.x) && (wrap)) {
/* 291 */           size = child.computeSize(width, child.getLayoutData() == null ? -1 : ((RowData)child.getLayoutData()).height, flushCache);
/*     */         }
/* 293 */         childWidth = size.x;
/* 294 */         childHeight = size.y;
/*     */       }
/* 296 */       if ((wrap) && (i != 0) && (x + childWidth > width)) {
/* 297 */         wrapped = true;
/* 298 */         if ((move) && ((this.justify) || (this.fill) || (this.center))) wraps[(i - 1)] = maxHeight;
/* 299 */         x = this.marginLeft + this.marginWidth;
/* 300 */         y += this.spacing + maxHeight;
/* 301 */         if (this.pack) maxHeight = 0;
/*     */       }
/* 303 */       if ((this.pack) || (this.fill) || (this.center)) {
/* 304 */         maxHeight = Math.max(maxHeight, childHeight);
/*     */       }
/* 306 */       if (move) {
/* 307 */         int childX = x + clientX;int childY = y + clientY;
/* 308 */         if ((this.justify) || (this.fill) || (this.center)) {
/* 309 */           bounds[i] = new Rectangle(childX, childY, childWidth, childHeight);
/*     */         } else {
/* 311 */           child.setBounds(childX, childY, childWidth, childHeight);
/*     */         }
/*     */       }
/* 314 */       x += this.spacing + childWidth;
/* 315 */       maxX = Math.max(maxX, x);
/*     */     }
/* 317 */     maxX = Math.max(clientX + this.marginLeft + this.marginWidth, maxX - this.spacing);
/* 318 */     if (!wrapped) maxX += this.marginRight + this.marginWidth;
/* 319 */     if ((move) && ((this.justify) || (this.fill) || (this.center))) {
/* 320 */       int space = 0;int margin = 0;
/* 321 */       if (!wrapped) {
/* 322 */         space = Math.max(0, (width - maxX) / (count + 1));
/* 323 */         margin = Math.max(0, (width - maxX) % (count + 1) / 2);
/*     */       }
/* 325 */       else if ((this.fill) || (this.justify) || (this.center)) {
/* 326 */         int last = 0;
/* 327 */         if (count > 0) wraps[(count - 1)] = maxHeight;
/* 328 */         for (int i = 0; i < count; i++) {
/* 329 */           if (wraps[i] != 0) {
/* 330 */             int wrapCount = i - last + 1;
/* 331 */             if (this.justify) {
/* 332 */               int wrapX = 0;
/* 333 */               for (int j = last; j <= i; j++) {
/* 334 */                 wrapX += bounds[j].width + this.spacing;
/*     */               }
/* 336 */               space = Math.max(0, (width - wrapX) / (wrapCount + 1));
/* 337 */               margin = Math.max(0, (width - wrapX) % (wrapCount + 1) / 2);
/*     */             }
/* 339 */             for (int j = last; j <= i; j++) {
/* 340 */               if (this.justify) bounds[j].x += space * (j - last + 1) + margin;
/* 341 */               if (this.fill) {
/* 342 */                 bounds[j].height = wraps[i];
/*     */               }
/* 344 */               else if (this.center) {
/* 345 */                 bounds[j].y += Math.max(0, (wraps[i] - bounds[j].height) / 2);
/*     */               }
/*     */             }
/*     */             
/* 349 */             last = i + 1;
/*     */           }
/*     */         }
/*     */       }
/*     */       
/* 354 */       for (int i = 0; i < count; i++) {
/* 355 */         if (!wrapped) {
/* 356 */           if (this.justify) bounds[i].x += space * (i + 1) + margin;
/* 357 */           if (this.fill) {
/* 358 */             bounds[i].height = maxHeight;
/*     */           }
/* 360 */           else if (this.center) {
/* 361 */             bounds[i].y += Math.max(0, (maxHeight - bounds[i].height) / 2);
/*     */           }
/*     */         }
/*     */         
/* 365 */         children[i].setBounds(bounds[i]);
/*     */       }
/*     */     }
/* 368 */     return new Point(maxX, y + maxHeight + this.marginBottom + this.marginHeight);
/*     */   }
/*     */   
/*     */   Point layoutVertical(Composite composite, boolean move, boolean wrap, int height, boolean flushCache) {
/* 372 */     Control[] children = composite.getChildren();
/* 373 */     int count = 0;
/* 374 */     for (int i = 0; i < children.length; i++) {
/* 375 */       Control control = children[i];
/* 376 */       RowData data = (RowData)control.getLayoutData();
/* 377 */       if ((data == null) || (!data.exclude)) {
/* 378 */         children[(count++)] = children[i];
/*     */       }
/*     */     }
/* 381 */     if (count == 0) {
/* 382 */       return new Point(this.marginLeft + this.marginWidth * 2 + this.marginRight, this.marginTop + this.marginHeight * 2 + this.marginBottom);
/*     */     }
/* 384 */     int childWidth = 0;int childHeight = 0;int maxWidth = 0;
/* 385 */     if (!this.pack) {
/* 386 */       for (int i = 0; i < count; i++) {
/* 387 */         Control child = children[i];
/* 388 */         Point size = computeSize(child, flushCache);
/* 389 */         if ((height > -1) && (height < size.y) && (wrap))
/* 390 */           size = child.computeSize(child.getLayoutData() == null ? -1 : ((RowData)child.getLayoutData()).width, height, flushCache);
/* 391 */         childWidth = Math.max(childWidth, size.x);
/* 392 */         childHeight = Math.max(childHeight, size.y);
/*     */       }
/* 394 */       maxWidth = childWidth;
/*     */     }
/* 396 */     int clientX = 0;int clientY = 0;
/* 397 */     if (move) {
/* 398 */       Rectangle rect = composite.getClientArea();
/* 399 */       clientX = rect.x;
/* 400 */       clientY = rect.y;
/*     */     }
/* 402 */     int[] wraps = null;
/* 403 */     boolean wrapped = false;
/* 404 */     Rectangle[] bounds = null;
/* 405 */     if ((move) && ((this.justify) || (this.fill) || (this.center))) {
/* 406 */       bounds = new Rectangle[count];
/* 407 */       wraps = new int[count];
/*     */     }
/* 409 */     int maxY = 0;int x = this.marginLeft + this.marginWidth;int y = this.marginTop + this.marginHeight;
/* 410 */     for (int i = 0; i < count; i++) {
/* 411 */       Control child = children[i];
/* 412 */       if (this.pack) {
/* 413 */         Point size = computeSize(child, flushCache);
/* 414 */         if ((height > -1) && (height < size.y) && (wrap))
/* 415 */           size = child.computeSize(child.getLayoutData() == null ? -1 : ((RowData)child.getLayoutData()).width, height, flushCache);
/* 416 */         childWidth = size.x;
/* 417 */         childHeight = size.y;
/*     */       }
/* 419 */       if ((wrap) && (i != 0) && (y + childHeight > height)) {
/* 420 */         wrapped = true;
/* 421 */         if ((move) && ((this.justify) || (this.fill) || (this.center))) wraps[(i - 1)] = maxWidth;
/* 422 */         x += this.spacing + maxWidth;
/* 423 */         y = this.marginTop + this.marginHeight;
/* 424 */         if (this.pack) maxWidth = 0;
/*     */       }
/* 426 */       if ((this.pack) || (this.fill) || (this.center)) {
/* 427 */         maxWidth = Math.max(maxWidth, childWidth);
/*     */       }
/* 429 */       if (move) {
/* 430 */         int childX = x + clientX;int childY = y + clientY;
/* 431 */         if ((this.justify) || (this.fill) || (this.center)) {
/* 432 */           bounds[i] = new Rectangle(childX, childY, childWidth, childHeight);
/*     */         } else {
/* 434 */           child.setBounds(childX, childY, childWidth, childHeight);
/*     */         }
/*     */       }
/* 437 */       y += this.spacing + childHeight;
/* 438 */       maxY = Math.max(maxY, y);
/*     */     }
/* 440 */     maxY = Math.max(clientY + this.marginTop + this.marginHeight, maxY - this.spacing);
/* 441 */     if (!wrapped) maxY += this.marginBottom + this.marginHeight;
/* 442 */     if ((move) && ((this.justify) || (this.fill) || (this.center))) {
/* 443 */       int space = 0;int margin = 0;
/* 444 */       if (!wrapped) {
/* 445 */         space = Math.max(0, (height - maxY) / (count + 1));
/* 446 */         margin = Math.max(0, (height - maxY) % (count + 1) / 2);
/*     */       }
/* 448 */       else if ((this.fill) || (this.justify) || (this.center)) {
/* 449 */         int last = 0;
/* 450 */         if (count > 0) wraps[(count - 1)] = maxWidth;
/* 451 */         for (int i = 0; i < count; i++) {
/* 452 */           if (wraps[i] != 0) {
/* 453 */             int wrapCount = i - last + 1;
/* 454 */             if (this.justify) {
/* 455 */               int wrapY = 0;
/* 456 */               for (int j = last; j <= i; j++) {
/* 457 */                 wrapY += bounds[j].height + this.spacing;
/*     */               }
/* 459 */               space = Math.max(0, (height - wrapY) / (wrapCount + 1));
/* 460 */               margin = Math.max(0, (height - wrapY) % (wrapCount + 1) / 2);
/*     */             }
/* 462 */             for (int j = last; j <= i; j++) {
/* 463 */               if (this.justify) bounds[j].y += space * (j - last + 1) + margin;
/* 464 */               if (this.fill) {
/* 465 */                 bounds[j].width = wraps[i];
/*     */               }
/* 467 */               else if (this.center) {
/* 468 */                 bounds[j].x += Math.max(0, (wraps[i] - bounds[j].width) / 2);
/*     */               }
/*     */             }
/*     */             
/* 472 */             last = i + 1;
/*     */           }
/*     */         }
/*     */       }
/*     */       
/* 477 */       for (int i = 0; i < count; i++) {
/* 478 */         if (!wrapped) {
/* 479 */           if (this.justify) bounds[i].y += space * (i + 1) + margin;
/* 480 */           if (this.fill) {
/* 481 */             bounds[i].width = maxWidth;
/*     */           }
/* 483 */           else if (this.center) {
/* 484 */             bounds[i].x += Math.max(0, (maxWidth - bounds[i].width) / 2);
/*     */           }
/*     */         }
/*     */         
/*     */ 
/* 489 */         children[i].setBounds(bounds[i]);
/*     */       }
/*     */     }
/* 492 */     return new Point(x + maxWidth + this.marginRight + this.marginWidth, maxY);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 503 */     String string = getName() + " {";
/* 504 */     string = string + "type=" + (this.type != 256 ? "SWT.VERTICAL" : "SWT.HORIZONTAL") + " ";
/* 505 */     if (this.marginWidth != 0) string = string + "marginWidth=" + this.marginWidth + " ";
/* 506 */     if (this.marginHeight != 0) string = string + "marginHeight=" + this.marginHeight + " ";
/* 507 */     if (this.marginLeft != 0) string = string + "marginLeft=" + this.marginLeft + " ";
/* 508 */     if (this.marginTop != 0) string = string + "marginTop=" + this.marginTop + " ";
/* 509 */     if (this.marginRight != 0) string = string + "marginRight=" + this.marginRight + " ";
/* 510 */     if (this.marginBottom != 0) string = string + "marginBottom=" + this.marginBottom + " ";
/* 511 */     if (this.spacing != 0) string = string + "spacing=" + this.spacing + " ";
/* 512 */     string = string + "wrap=" + this.wrap + " ";
/* 513 */     string = string + "pack=" + this.pack + " ";
/* 514 */     string = string + "fill=" + this.fill + " ";
/* 515 */     string = string + "justify=" + this.justify + " ";
/* 516 */     string = string.trim();
/* 517 */     string = string + "}";
/* 518 */     return string;
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/layout/RowLayout.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */