package org.eclipse.swt.dnd;

import org.eclipse.swt.internal.SWTEventListener;

public abstract interface DragSourceListener
  extends SWTEventListener
{
  public abstract void dragStart(DragSourceEvent paramDragSourceEvent);
  
  public abstract void dragSetData(DragSourceEvent paramDragSourceEvent);
  
  public abstract void dragFinished(DragSourceEvent paramDragSourceEvent);
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/dnd/DragSourceListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */