/*      */ package org.eclipse.swt.internal.webkit;
/*      */ 
/*      */ import java.io.PrintStream;
/*      */ import org.eclipse.swt.internal.Lock;
/*      */ 
/*      */ public class WebKitGTK extends org.eclipse.swt.internal.C
/*      */ {
/*      */   public static boolean LibraryLoaded;
/*      */   public static boolean WEBKIT1;
/*      */   public static boolean WEBKIT2;
/*      */   public static final String Webkit1AssertMsg = "Webkit2 code reached by webkit1";
/*      */   public static final String Webkit2AssertMsg = "Webkit1 code reached by webkit2";
/*      */   public static final String swtWebkitGlueCodeVersion = " SWT Glue code version: 54.0";
/*      */   public static final String swtWebkitGlueCodeVersionInfo = " info: +BrowserFunction/GDBus, +WebkitExtension Folder versioning, +WebKitExtension OSGI support, +setUrl(..postData..), -setCookie(), -getCookie +mouseDown/Focus";
/*      */   public static final int kJSTypeUndefined = 0;
/*      */   public static final int kJSTypeNull = 1;
/*      */   public static final int kJSTypeBoolean = 2;
/*      */   public static final int kJSTypeNumber = 3;
/*      */   public static final int kJSTypeString = 4;
/*      */   public static final int kJSTypeObject = 5;
/*      */   public static final int SOUP_MEMORY_TAKE = 1;
/*      */   public static final int WEBKIT_DOWNLOAD_STATUS_ERROR = -1;
/*      */   public static final int WEBKIT_DOWNLOAD_STATUS_CANCELLED = 2;
/*      */   public static final int WEBKIT_DOWNLOAD_STATUS_FINISHED = 3;
/*      */   public static final int WEBKIT_LOAD_COMMITTED = 1;
/*      */   public static final int WEBKIT_LOAD_FINISHED = 2;
/*      */   public static final int WEBKIT2_LOAD_STARTED = 0;
/*      */   public static final int WEBKIT2_LOAD_REDIRECTED = 1;
/*      */   public static final int WEBKIT2_LOAD_COMMITTED = 2;
/*      */   public static final int WEBKIT2_LOAD_FINISHED = 3;
/*      */   public static final int WEBKIT_POLICY_DECISION_TYPE_NAVIGATION_ACTION = 0;
/*      */   public static final int WEBKIT_POLICY_DECISION_TYPE_NEW_WINDOW_ACTION = 1;
/*      */   public static final int WEBKIT_POLICY_DECISION_TYPE_RESPONSE = 2;
/*      */   public static final int WEBKIT_CREDENTIAL_PERSISTENCE_NONE = 0;
/*      */   public static final int WEBKIT_CREDENTIAL_PERSISTENCE_FOR_SESSION = 1;
/*      */   public static final int WEBKIT_CREDENTIAL_PERSISTENCE_PERMANENT = 2;
/*      */   public static final int WEBKIT_WEBSITE_DATA_COOKIES = 256;
/*      */   
/*      */   static
/*      */   {
/*      */     try
/*      */     {
/*   43 */       org.eclipse.swt.internal.Library.loadLibrary("swt-webkit");
/*   44 */       LibraryLoaded = true;
/*      */     }
/*      */     catch (Throwable localThrowable) {}
/*      */     
/*   48 */     if (LibraryLoaded) {
/*   49 */       String webkit2 = System.getenv("SWT_WEBKIT2");
/*   50 */       int webkit2VersionFunction = webkit_get_major_version();
/*   51 */       if (webkit2VersionFunction != 0) {
/*   52 */         webkit2 = "1";
/*      */       }
/*   54 */       WEBKIT2 = (webkit2 != null) && (webkit2.equals("1")) && (org.eclipse.swt.internal.gtk.GTK.GTK3);
/*   55 */       WEBKIT1 = !WEBKIT2;
/*      */     }
/*      */     
/*   58 */     String swt_lib_versions = org.eclipse.swt.internal.gtk.OS.getEnvironmentalVariable("SWT_LIB_VERSIONS");
/*   59 */     if ((swt_lib_versions != null) && (swt_lib_versions.equals("1"))) {
/*   60 */       if (WEBKIT1) {
/*   61 */         System.out.println("SWT_LIB  Webkit1   Webkitgtk:" + webkit_major_version() + "." + webkit_minor_version() + "." + webkit_micro_version() + "  (webkitgtk < 2.5 is Webkit1)");
/*      */       }
/*   63 */       if (WEBKIT2) {
/*   64 */         System.out.println("SWT_LIB  Webkit2   Webkitgtk:" + webkit_get_major_version() + "." + webkit_get_minor_version() + "." + 
/*   65 */           webkit_get_micro_version() + "  (webkitgtk >=2.5 is Webkit2) " + " SWT Glue code version: 54.0" + " info: +BrowserFunction/GDBus, +WebkitExtension Folder versioning, +WebKitExtension OSGI support, +setUrl(..postData..), -setCookie(), -getCookie +mouseDown/Focus");
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  103 */   public static final byte[] authenticate = ascii("authenticate");
/*      */   
/*      */ 
/*  106 */   public static final byte[] close_web_view = ascii("close-web-view");
/*  107 */   public static final byte[] close = ascii("close");
/*      */   
/*      */ 
/*  110 */   public static final byte[] console_message = ascii("console-message");
/*      */   
/*      */ 
/*  113 */   public static final byte[] populate_popup = ascii("populate-popup");
/*  114 */   public static final byte[] context_menu = ascii("context-menu");
/*      */   
/*      */ 
/*  117 */   public static final byte[] create_web_view = ascii("create-web-view");
/*  118 */   public static final byte[] create = ascii("create");
/*      */   
/*      */ 
/*  121 */   public static final byte[] mime_type_policy_decision_requested = ascii("mime-type-policy-decision-requested");
/*  122 */   public static final byte[] navigation_policy_decision_requested = ascii("navigation-policy-decision-requested");
/*  123 */   public static final byte[] decide_policy = ascii("decide-policy");
/*  124 */   public static final byte[] decide_destination = ascii("decide-destination");
/*      */   
/*      */ 
/*  127 */   public static final byte[] download_requested = ascii("download-requested");
/*  128 */   public static final byte[] download_started = ascii("download-started");
/*  129 */   public static final byte[] failed = ascii("failed");
/*  130 */   public static final byte[] finished = ascii("finished");
/*      */   
/*      */ 
/*  133 */   public static final byte[] initialize_web_extensions = ascii("initialize-web-extensions");
/*      */   
/*      */ 
/*  136 */   public static final byte[] hovering_over_link = ascii("hovering-over-link");
/*  137 */   public static final byte[] mouse_target_changed = ascii("mouse-target-changed");
/*      */   
/*      */ 
/*      */ 
/*  141 */   public static final byte[] status_bar_text_changed = ascii("status-bar-text-changed");
/*      */   
/*      */ 
/*  144 */   public static final byte[] window_object_cleared = ascii("window-object-cleared");
/*  145 */   public static final byte[] load_changed = ascii("load-changed");
/*      */   
/*      */ 
/*  148 */   public static final byte[] notify_load_status = ascii("notify::load-status");
/*  149 */   public static final byte[] notify_progress = ascii("notify::progress");
/*  150 */   public static final byte[] notify_estimated_load_progress = ascii("notify::estimated-load-progress");
/*      */   
/*      */ 
/*  153 */   public static final byte[] notify_title = ascii("notify::title");
/*      */   
/*      */ 
/*  156 */   public static final byte[] resource_request_starting = ascii("resource-request-starting");
/*  157 */   public static final byte[] resource_load_started = ascii("resource-load-started");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*  162 */   public static final byte[] web_view_ready = ascii("web-view-ready");
/*  163 */   public static final byte[] ready_to_show = ascii("ready-to-show");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  179 */   public static final byte[] default_encoding = ascii("default-encoding");
/*  180 */   public static final byte[] default_charset = ascii("default-charset");
/*      */   
/*  182 */   public static final byte[] enable_scripts = ascii("enable-scripts");
/*  183 */   public static final byte[] enable_javascript = ascii("enable-javascript");
/*      */   
/*  185 */   public static final byte[] enable_webgl = ascii("enable-webgl");
/*      */   
/*  187 */   public static final byte[] enable_universal_access_from_file_uris = ascii("enable-universal-access-from-file-uris");
/*  188 */   public static final byte[] allow_universal_access_from_file_urls = ascii("allow-universal-access-from-file-urls");
/*      */   
/*  190 */   public static final byte[] user_agent = ascii("user-agent");
/*      */   
/*  192 */   public static final byte[] javascript_can_open_windows_automatically = ascii("javascript-can-open-windows-automatically");
/*      */   
/*  194 */   public static final byte[] locationbar_visible = ascii("locationbar-visible");
/*  195 */   public static final byte[] menubar_visible = ascii("menubar-visible");
/*  196 */   public static final byte[] statusbar_visible = ascii("statusbar-visible");
/*  197 */   public static final byte[] toolbar_visible = ascii("toolbar-visible");
/*      */   
/*      */ 
/*  200 */   public static final byte[] height = ascii("height");
/*  201 */   public static final byte[] width = ascii("width");
/*  202 */   public static final byte[] x = ascii("x");
/*  203 */   public static final byte[] y = ascii("y");
/*      */   
/*  205 */   public static final byte[] SOUP_SESSION_PROXY_URI = ascii("proxy-uri");
/*      */   
/*      */ 
/*  208 */   public static final byte[] dragstart = ascii("dragstart");
/*  209 */   public static final byte[] keydown = ascii("keydown");
/*  210 */   public static final byte[] keypress = ascii("keypress");
/*  211 */   public static final byte[] keyup = ascii("keyup");
/*  212 */   public static final byte[] mousedown = ascii("mousedown");
/*  213 */   public static final byte[] mousemove = ascii("mousemove");
/*  214 */   public static final byte[] mouseup = ascii("mouseup");
/*  215 */   public static final byte[] mousewheel = ascii("mousewheel");
/*      */   
/*      */   protected static byte[] ascii(String name)
/*      */   {
/*  219 */     int length = name.length();
/*  220 */     char[] chars = new char[length];
/*  221 */     name.getChars(0, length, chars, 0);
/*  222 */     byte[] buffer = new byte[length + 1];
/*  223 */     for (int i = 0; i < length; i++) {
/*  224 */       buffer[i] = ((byte)chars[i]);
/*      */     }
/*  226 */     return buffer;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final long JSClassCreate(long definition)
/*      */   {
/*  233 */     lock.lock();
/*      */     try {
/*  235 */       return _JSClassCreate(definition);
/*      */     } finally {
/*  237 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final long JSContextGetGlobalObject(long ctx)
/*      */   {
/*  244 */     lock.lock();
/*      */     try {
/*  246 */       return _JSContextGetGlobalObject(ctx);
/*      */     } finally {
/*  248 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final long JSEvaluateScript(long ctx, long script, long thisObject, long sourceURL, int startingLineNumber, long[] exception)
/*      */   {
/*  255 */     lock.lock();
/*      */     try {
/*  257 */       return _JSEvaluateScript(ctx, script, thisObject, sourceURL, startingLineNumber, exception);
/*      */     } finally {
/*  259 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final long JSObjectGetPrivate(long object)
/*      */   {
/*  266 */     lock.lock();
/*      */     try {
/*  268 */       return _JSObjectGetPrivate(object);
/*      */     } finally {
/*  270 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final long JSObjectGetProperty(long ctx, long object, long propertyName, long[] exception)
/*      */   {
/*  277 */     lock.lock();
/*      */     try {
/*  279 */       return _JSObjectGetProperty(ctx, object, propertyName, exception);
/*      */     } finally {
/*  281 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final long JSObjectGetPropertyAtIndex(long ctx, long object, int propertyIndex, long[] exception)
/*      */   {
/*  288 */     lock.lock();
/*      */     try {
/*  290 */       return _JSObjectGetPropertyAtIndex(ctx, object, propertyIndex, exception);
/*      */     } finally {
/*  292 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final long JSObjectMake(long ctx, long jsClass, long data)
/*      */   {
/*  299 */     lock.lock();
/*      */     try {
/*  301 */       return _JSObjectMake(ctx, jsClass, data);
/*      */     } finally {
/*  303 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final long JSObjectMakeArray(long ctx, long argumentCount, long[] arguments, long[] exception)
/*      */   {
/*  310 */     lock.lock();
/*      */     try {
/*  312 */       return _JSObjectMakeArray(ctx, argumentCount, arguments, exception);
/*      */     } finally {
/*  314 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final long JSObjectMakeFunctionWithCallback(long ctx, long name, long callAsFunction)
/*      */   {
/*  321 */     lock.lock();
/*      */     try {
/*  323 */       return _JSObjectMakeFunctionWithCallback(ctx, name, callAsFunction);
/*      */     } finally {
/*  325 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final void JSObjectSetProperty(long ctx, long object, long propertyName, long value, int attributes, long[] exception)
/*      */   {
/*  332 */     lock.lock();
/*      */     try {
/*  334 */       _JSObjectSetProperty(ctx, object, propertyName, value, attributes, exception);
/*      */     } finally {
/*  336 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final long JSStringCreateWithUTF8CString(byte[] string)
/*      */   {
/*  343 */     lock.lock();
/*      */     try {
/*  345 */       return _JSStringCreateWithUTF8CString(string);
/*      */     } finally {
/*  347 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final long JSStringGetLength(long string)
/*      */   {
/*  354 */     lock.lock();
/*      */     try {
/*  356 */       return _JSStringGetLength(string);
/*      */     } finally {
/*  358 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final long JSStringGetMaximumUTF8CStringSize(long string)
/*      */   {
/*  365 */     lock.lock();
/*      */     try {
/*  367 */       return _JSStringGetMaximumUTF8CStringSize(string);
/*      */     } finally {
/*  369 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final long JSStringGetUTF8CString(long string, byte[] buffer, long bufferSize)
/*      */   {
/*  376 */     lock.lock();
/*      */     try {
/*  378 */       return _JSStringGetUTF8CString(string, buffer, bufferSize);
/*      */     } finally {
/*  380 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final int JSStringIsEqualToUTF8CString(long a, byte[] b)
/*      */   {
/*  387 */     lock.lock();
/*      */     try {
/*  389 */       return _JSStringIsEqualToUTF8CString(a, b);
/*      */     } finally {
/*  391 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int JSValueGetType(long ctx, long value)
/*      */   {
/*  423 */     lock.lock();
/*      */     try {
/*  425 */       return _JSValueGetType(ctx, value);
/*      */     } finally {
/*  427 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final int JSValueIsObjectOfClass(long ctx, long value, long jsClass)
/*      */   {
/*  434 */     lock.lock();
/*      */     try {
/*  436 */       return _JSValueIsObjectOfClass(ctx, value, jsClass);
/*      */     } finally {
/*  438 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final long JSValueMakeBoolean(long ctx, int bool)
/*      */   {
/*  445 */     lock.lock();
/*      */     try {
/*  447 */       return _JSValueMakeBoolean(ctx, bool);
/*      */     } finally {
/*  449 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final long JSValueMakeNumber(long ctx, double number)
/*      */   {
/*  456 */     lock.lock();
/*      */     try {
/*  458 */       return _JSValueMakeNumber(ctx, number);
/*      */     } finally {
/*  460 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final long JSValueMakeString(long ctx, long string)
/*      */   {
/*  467 */     lock.lock();
/*      */     try {
/*  469 */       return _JSValueMakeString(ctx, string);
/*      */     } finally {
/*  471 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final long JSValueMakeUndefined(long ctx)
/*      */   {
/*  478 */     lock.lock();
/*      */     try {
/*  480 */       return _JSValueMakeUndefined(ctx);
/*      */     } finally {
/*  482 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final double JSValueToNumber(long ctx, long value, long[] exception)
/*      */   {
/*  489 */     lock.lock();
/*      */     try {
/*  491 */       return _JSValueToNumber(ctx, value, exception);
/*      */     } finally {
/*  493 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final long JSValueToStringCopy(long ctx, long value, long[] exception)
/*      */   {
/*  500 */     lock.lock();
/*      */     try {
/*  502 */       return _JSValueToStringCopy(ctx, value, exception);
/*      */     } finally {
/*  504 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void soup_auth_authenticate(long auth, byte[] username, byte[] password)
/*      */   {
/*  513 */     lock.lock();
/*      */     try {
/*  515 */       _soup_auth_authenticate(auth, username, password);
/*      */     } finally {
/*  517 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final long soup_auth_get_host(long auth)
/*      */   {
/*  524 */     lock.lock();
/*      */     try {
/*  526 */       return _soup_auth_get_host(auth);
/*      */     } finally {
/*  528 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final long soup_auth_get_scheme_name(long auth)
/*      */   {
/*  535 */     lock.lock();
/*      */     try {
/*  537 */       return _soup_auth_get_scheme_name(auth);
/*      */     } finally {
/*  539 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void soup_cookie_jar_add_cookie(long jar, long cookie)
/*      */   {
/*  557 */     lock.lock();
/*      */     try {
/*  559 */       _soup_cookie_jar_add_cookie(jar, cookie);
/*      */     } finally {
/*  561 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final long soup_cookie_jar_all_cookies(long jar)
/*      */   {
/*  568 */     lock.lock();
/*      */     try {
/*  570 */       return _soup_cookie_jar_all_cookies(jar);
/*      */     } finally {
/*  572 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final void soup_cookie_jar_delete_cookie(long jar, long cookie)
/*      */   {
/*  579 */     lock.lock();
/*      */     try {
/*  581 */       _soup_cookie_jar_delete_cookie(jar, cookie);
/*      */     } finally {
/*  583 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final long soup_cookie_jar_get_cookies(long jar, long uri, int for_http)
/*      */   {
/*  590 */     lock.lock();
/*      */     try {
/*  592 */       return _soup_cookie_jar_get_cookies(jar, uri, for_http);
/*      */     } finally {
/*  594 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final long soup_cookie_jar_get_type()
/*      */   {
/*  601 */     lock.lock();
/*      */     try {
/*  603 */       return _soup_cookie_jar_get_type();
/*      */     } finally {
/*  605 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final long soup_cookie_parse(byte[] header, long origin)
/*      */   {
/*  612 */     lock.lock();
/*      */     try {
/*  614 */       return _soup_cookie_parse(header, origin);
/*      */     } finally {
/*  616 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final void soup_message_body_append(long body, int use, long data, long length)
/*      */   {
/*  623 */     lock.lock();
/*      */     try {
/*  625 */       _soup_message_body_append(body, use, data, length);
/*      */     } finally {
/*  627 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long soup_message_get_uri(long msg)
/*      */   {
/*  645 */     lock.lock();
/*      */     try {
/*  647 */       return _soup_message_get_uri(msg);
/*      */     } finally {
/*  649 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final void soup_message_headers_append(long headers, byte[] name, byte[] value)
/*      */   {
/*  656 */     lock.lock();
/*      */     try {
/*  658 */       _soup_message_headers_append(headers, name, value);
/*      */     } finally {
/*  660 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final void soup_session_add_feature_by_type(long session, long type)
/*      */   {
/*  667 */     lock.lock();
/*      */     try {
/*  669 */       _soup_session_add_feature_by_type(session, type);
/*      */     } finally {
/*  671 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final long soup_session_get_feature(long session, long feature_type)
/*      */   {
/*  678 */     lock.lock();
/*      */     try {
/*  680 */       return _soup_session_get_feature(session, feature_type);
/*      */     } finally {
/*  682 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final void soup_session_feature_attach(long feature, long session)
/*      */   {
/*  689 */     lock.lock();
/*      */     try {
/*  691 */       _soup_session_feature_attach(feature, session);
/*      */     } finally {
/*  693 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final long soup_session_get_type()
/*      */   {
/*  700 */     lock.lock();
/*      */     try {
/*  702 */       return _soup_session_get_type();
/*      */     } finally {
/*  704 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final void soup_session_feature_detach(long feature, long session)
/*      */   {
/*  711 */     lock.lock();
/*      */     try {
/*  713 */       _soup_session_feature_detach(feature, session);
/*      */     } finally {
/*  715 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long soup_uri_new(byte[] uri_string)
/*      */   {
/*  733 */     lock.lock();
/*      */     try {
/*  735 */       return _soup_uri_new(uri_string);
/*      */     } finally {
/*  737 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final long soup_uri_to_string(long uri, int just_path_and_query)
/*      */   {
/*  744 */     lock.lock();
/*      */     try {
/*  746 */       return _soup_uri_to_string(uri, just_path_and_query);
/*      */     } finally {
/*  748 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void webkit_authentication_request_authenticate(long request, long credential)
/*      */   {
/*  757 */     assert (WEBKIT2) : "Webkit1 code reached by webkit2";
/*  758 */     lock.lock();
/*      */     try {
/*  760 */       _webkit_authentication_request_authenticate(request, credential);
/*      */     } finally {
/*  762 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final boolean webkit_authentication_request_is_retry(long request)
/*      */   {
/*  781 */     assert (WEBKIT2) : "Webkit1 code reached by webkit2";
/*  782 */     lock.lock();
/*      */     try {
/*  784 */       return _webkit_authentication_request_is_retry(request);
/*      */     } finally {
/*  786 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long webkit_web_context_get_type()
/*      */   {
/*  806 */     assert (WEBKIT2) : "Webkit1 code reached by webkit2";
/*  807 */     lock.lock();
/*      */     try {
/*  809 */       return _webkit_web_context_get_type();
/*      */     } finally {
/*  811 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final long webkit_credential_new(byte[] username, byte[] password, int persistence)
/*      */   {
/*  818 */     assert (WEBKIT2) : "Webkit1 code reached by webkit2";
/*  819 */     lock.lock();
/*      */     try {
/*  821 */       return _webkit_credential_new(username, password, persistence);
/*      */     } finally {
/*  823 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final int webkit_dom_event_target_add_event_listener(long target, byte[] name, long handler, int bubble, long userData)
/*      */   {
/*  831 */     lock.lock();
/*      */     try {
/*  833 */       return _webkit_dom_event_target_add_event_listener(target, name, handler, bubble, userData);
/*      */     } finally {
/*  835 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final int webkit_dom_mouse_event_get_alt_key(long self)
/*      */   {
/*  842 */     lock.lock();
/*      */     try {
/*  844 */       return _webkit_dom_mouse_event_get_alt_key(self);
/*      */     } finally {
/*  846 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final short webkit_dom_mouse_event_get_button(long self)
/*      */   {
/*  853 */     lock.lock();
/*      */     try {
/*  855 */       return _webkit_dom_mouse_event_get_button(self);
/*      */     } finally {
/*  857 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final int webkit_dom_mouse_event_get_ctrl_key(long self)
/*      */   {
/*  864 */     lock.lock();
/*      */     try {
/*  866 */       return _webkit_dom_mouse_event_get_ctrl_key(self);
/*      */     } finally {
/*  868 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final int webkit_dom_mouse_event_get_meta_key(long self)
/*      */   {
/*  875 */     lock.lock();
/*      */     try {
/*  877 */       return _webkit_dom_mouse_event_get_meta_key(self);
/*      */     } finally {
/*  879 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final long webkit_dom_mouse_event_get_screen_x(long self)
/*      */   {
/*  886 */     lock.lock();
/*      */     try {
/*  888 */       return _webkit_dom_mouse_event_get_screen_x(self);
/*      */     } finally {
/*  890 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final long webkit_dom_mouse_event_get_screen_y(long self)
/*      */   {
/*  897 */     lock.lock();
/*      */     try {
/*  899 */       return _webkit_dom_mouse_event_get_screen_y(self);
/*      */     } finally {
/*  901 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final int webkit_dom_mouse_event_get_shift_key(long self)
/*      */   {
/*  908 */     lock.lock();
/*      */     try {
/*  910 */       return _webkit_dom_mouse_event_get_shift_key(self);
/*      */     } finally {
/*  912 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final long webkit_dom_ui_event_get_char_code(long self)
/*      */   {
/*  919 */     lock.lock();
/*      */     try {
/*  921 */       return _webkit_dom_ui_event_get_char_code(self);
/*      */     } finally {
/*  923 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final long webkit_dom_ui_event_get_detail(long self)
/*      */   {
/*  930 */     lock.lock();
/*      */     try {
/*  932 */       return _webkit_dom_ui_event_get_detail(self);
/*      */     } finally {
/*  934 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final long webkit_dom_ui_event_get_key_code(long self)
/*      */   {
/*  941 */     lock.lock();
/*      */     try {
/*  943 */       return _webkit_dom_ui_event_get_key_code(self);
/*      */     } finally {
/*  945 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long webkit_download_get_current_size(long download)
/*      */   {
/*  964 */     assert (WEBKIT1) : "Webkit2 code reached by webkit1";
/*  965 */     lock.lock();
/*      */     try {
/*  967 */       return _webkit_download_get_current_size(download);
/*      */     } finally {
/*  969 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final long webkit_download_get_received_data_length(long download)
/*      */   {
/*  976 */     assert (WEBKIT2) : "Webkit1 code reached by webkit2";
/*  977 */     lock.lock();
/*      */     try {
/*  979 */       return _webkit_download_get_received_data_length(download);
/*      */     } finally {
/*  981 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final long webkit_download_get_network_request(long download)
/*      */   {
/*  988 */     assert (WEBKIT1) : "Webkit2 code reached by webkit1";
/*  989 */     lock.lock();
/*      */     try {
/*  991 */       return _webkit_download_get_network_request(download);
/*      */     } finally {
/*  993 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final int webkit_download_get_status(long download)
/*      */   {
/* 1000 */     assert (WEBKIT1) : "Webkit2 code reached by webkit1";
/* 1001 */     lock.lock();
/*      */     try {
/* 1003 */       return _webkit_download_get_status(download);
/*      */     } finally {
/* 1005 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final long webkit_download_get_suggested_filename(long download)
/*      */   {
/* 1012 */     assert (WEBKIT1) : "Webkit2 code reached by webkit1";
/* 1013 */     lock.lock();
/*      */     try {
/* 1015 */       return _webkit_download_get_suggested_filename(download);
/*      */     } finally {
/* 1017 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final long webkit_download_get_request(long download)
/*      */   {
/* 1024 */     assert (WEBKIT2) : "Webkit1 code reached by webkit2";
/* 1025 */     lock.lock();
/*      */     try {
/* 1027 */       return _webkit_download_get_request(download);
/*      */     } finally {
/* 1029 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final long webkit_download_get_response(long download)
/*      */   {
/* 1036 */     assert (WEBKIT2) : "Webkit1 code reached by webkit2";
/* 1037 */     lock.lock();
/*      */     try {
/* 1039 */       return _webkit_download_get_response(download);
/*      */     } finally {
/* 1041 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final long webkit_download_get_total_size(long download)
/*      */   {
/* 1048 */     assert (WEBKIT1) : "Webkit2 code reached by webkit1";
/* 1049 */     lock.lock();
/*      */     try {
/* 1051 */       return _webkit_download_get_total_size(download);
/*      */     } finally {
/* 1053 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final long webkit_download_get_type()
/*      */   {
/* 1060 */     assert (WEBKIT2) : "Webkit1 code reached by webkit2";
/* 1061 */     lock.lock();
/*      */     try {
/* 1063 */       return _webkit_download_get_type();
/*      */     } finally {
/* 1065 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final long webkit_uri_response_get_content_length(long response)
/*      */   {
/* 1072 */     assert (WEBKIT2) : "Webkit1 code reached by webkit2";
/* 1073 */     lock.lock();
/*      */     try {
/* 1075 */       return _webkit_uri_response_get_content_length(response);
/*      */     } finally {
/* 1077 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final long webkit_download_get_uri(long download)
/*      */   {
/* 1084 */     assert (WEBKIT1) : "Webkit2 code reached by webkit1";
/* 1085 */     lock.lock();
/*      */     try {
/* 1087 */       return _webkit_download_get_uri(download);
/*      */     } finally {
/* 1089 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final long webkit_download_get_web_view(long download)
/*      */   {
/* 1096 */     assert (WEBKIT2) : "Webkit1 code reached by webkit2";
/* 1097 */     lock.lock();
/*      */     try {
/* 1099 */       return _webkit_download_get_web_view(download);
/*      */     } finally {
/* 1101 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final long webkit_download_new(long request)
/*      */   {
/* 1108 */     assert (WEBKIT1) : "Webkit2 code reached by webkit1";
/* 1109 */     lock.lock();
/*      */     try {
/* 1111 */       return _webkit_download_new(request);
/*      */     } finally {
/* 1113 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void webkit_favicon_database_set_path(long database, long path)
/*      */   {
/* 1168 */     assert (WEBKIT1) : "Webkit2 code reached by webkit1";
/* 1169 */     lock.lock();
/*      */     try {
/* 1171 */       _webkit_favicon_database_set_path(database, path);
/*      */     } finally {
/* 1173 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final long webkit_get_default_session()
/*      */   {
/* 1180 */     assert (WEBKIT1) : "Webkit2 code reached by webkit1";
/* 1181 */     lock.lock();
/*      */     try {
/* 1183 */       return _webkit_get_default_session();
/*      */     } finally {
/* 1185 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final long webkit_get_favicon_database()
/*      */   {
/* 1192 */     assert (WEBKIT1) : "Webkit2 code reached by webkit1";
/* 1193 */     lock.lock();
/*      */     try {
/* 1195 */       return _webkit_get_favicon_database();
/*      */     } finally {
/* 1197 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final boolean webkit_hit_test_result_context_is_link(long hit_test_result)
/*      */   {
/* 1204 */     assert (WEBKIT2) : "Webkit1 code reached by webkit2";
/* 1205 */     lock.lock();
/*      */     try {
/* 1207 */       return _webkit_hit_test_result_context_is_link(hit_test_result);
/*      */     } finally {
/* 1209 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final long webkit_hit_test_result_get_link_uri(long hit_test_result)
/*      */   {
/* 1216 */     assert (WEBKIT2) : "Webkit1 code reached by webkit2";
/* 1217 */     lock.lock();
/*      */     try {
/* 1219 */       return _webkit_hit_test_result_get_link_uri(hit_test_result);
/*      */     } finally {
/* 1221 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final long webkit_hit_test_result_get_link_title(long hit_test_result)
/*      */   {
/* 1228 */     assert (WEBKIT2) : "Webkit1 code reached by webkit2";
/* 1229 */     lock.lock();
/*      */     try {
/* 1231 */       return _webkit_hit_test_result_get_link_title(hit_test_result);
/*      */     } finally {
/* 1233 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final int webkit_major_version()
/*      */   {
/* 1240 */     assert (WEBKIT1) : "Webkit2 code reached by webkit1";
/* 1241 */     lock.lock();
/*      */     try {
/* 1243 */       return _webkit_major_version();
/*      */     } finally {
/* 1245 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final int webkit_get_major_version()
/*      */   {
/* 1253 */     lock.lock();
/*      */     try {
/* 1255 */       return _webkit_get_major_version();
/*      */     } finally {
/* 1257 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final int webkit_micro_version()
/*      */   {
/* 1264 */     assert (WEBKIT1) : "Webkit2 code reached by webkit1";
/* 1265 */     lock.lock();
/*      */     try {
/* 1267 */       return _webkit_micro_version();
/*      */     } finally {
/* 1269 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final int webkit_get_micro_version()
/*      */   {
/* 1276 */     assert (WEBKIT2) : "Webkit1 code reached by webkit2";
/* 1277 */     lock.lock();
/*      */     try {
/* 1279 */       return _webkit_get_micro_version();
/*      */     } finally {
/* 1281 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final int webkit_minor_version()
/*      */   {
/* 1288 */     assert (WEBKIT1) : "Webkit2 code reached by webkit1";
/* 1289 */     lock.lock();
/*      */     try {
/* 1291 */       return _webkit_minor_version();
/*      */     } finally {
/* 1293 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final int webkit_get_minor_version()
/*      */   {
/* 1300 */     assert (WEBKIT2) : "Webkit1 code reached by webkit2";
/* 1301 */     lock.lock();
/*      */     try {
/* 1303 */       return _webkit_get_minor_version();
/*      */     } finally {
/* 1305 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final long webkit_navigation_policy_decision_get_request(long decision)
/*      */   {
/* 1312 */     assert (WEBKIT2) : "Webkit1 code reached by webkit2";
/* 1313 */     lock.lock();
/*      */     try {
/* 1315 */       return _webkit_navigation_policy_decision_get_request(decision);
/*      */     } finally {
/* 1317 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final long webkit_network_request_get_message(long request)
/*      */   {
/* 1324 */     assert (WEBKIT1) : "Webkit2 code reached by webkit1";
/* 1325 */     lock.lock();
/*      */     try {
/* 1327 */       return _webkit_network_request_get_message(request);
/*      */     } finally {
/* 1329 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final long webkit_network_request_get_uri(long request)
/*      */   {
/* 1336 */     assert (WEBKIT1) : "Webkit2 code reached by webkit1";
/* 1337 */     lock.lock();
/*      */     try {
/* 1339 */       return _webkit_network_request_get_uri(request);
/*      */     } finally {
/* 1341 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final long webkit_network_request_new(byte[] uri)
/*      */   {
/* 1348 */     assert (WEBKIT1) : "Webkit2 code reached by webkit1";
/* 1349 */     lock.lock();
/*      */     try {
/* 1351 */       return _webkit_network_request_new(uri);
/*      */     } finally {
/* 1353 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long webkit_soup_auth_dialog_get_type()
/*      */   {
/* 1385 */     assert (WEBKIT1) : "Webkit2 code reached by webkit1";
/* 1386 */     lock.lock();
/*      */     try {
/* 1388 */       return _webkit_soup_auth_dialog_get_type();
/*      */     } finally {
/* 1390 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final long webkit_web_context_get_default()
/*      */   {
/* 1397 */     assert (WEBKIT2) : "Webkit1 code reached by webkit2";
/* 1398 */     lock.lock();
/*      */     try {
/* 1400 */       return _webkit_web_context_get_default();
/*      */     } finally {
/* 1402 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final long webkit_web_context_get_website_data_manager(long context)
/*      */   {
/* 1409 */     assert (WEBKIT2) : "Webkit1 code reached by webkit2";
/* 1410 */     lock.lock();
/*      */     try {
/* 1412 */       return _webkit_web_context_get_website_data_manager(context);
/*      */     } finally {
/* 1414 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final long webkit_web_context_set_favicon_database_directory(long context, long path)
/*      */   {
/* 1421 */     assert (WEBKIT2) : "Webkit1 code reached by webkit2";
/* 1422 */     lock.lock();
/*      */     try {
/* 1424 */       return _webkit_web_context_set_favicon_database_directory(context, path);
/*      */     } finally {
/* 1426 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final long webkit_web_data_source_get_data(long data_source)
/*      */   {
/* 1434 */     assert (WEBKIT1) : "Webkit2 code reached by webkit1";
/* 1435 */     lock.lock();
/*      */     try {
/* 1437 */       return _webkit_web_data_source_get_data(data_source);
/*      */     } finally {
/* 1439 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final long webkit_web_data_source_get_encoding(long data_source)
/*      */   {
/* 1446 */     assert (WEBKIT1) : "Webkit2 code reached by webkit1";
/* 1447 */     lock.lock();
/*      */     try {
/* 1449 */       return _webkit_web_data_source_get_encoding(data_source);
/*      */     } finally {
/* 1451 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final long webkit_web_frame_get_data_source(long frame)
/*      */   {
/* 1458 */     assert (WEBKIT1) : "Webkit2 code reached by webkit1";
/* 1459 */     lock.lock();
/*      */     try {
/* 1461 */       return _webkit_web_frame_get_data_source(frame);
/*      */     } finally {
/* 1463 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final long webkit_web_frame_get_global_context(long frame)
/*      */   {
/* 1470 */     assert (WEBKIT1) : "Webkit2 code reached by webkit1";
/* 1471 */     lock.lock();
/*      */     try {
/* 1473 */       return _webkit_web_frame_get_global_context(frame);
/*      */     } finally {
/* 1475 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final int webkit_web_frame_get_load_status(long frame)
/*      */   {
/* 1482 */     assert (WEBKIT1) : "Webkit2 code reached by webkit1";
/* 1483 */     lock.lock();
/*      */     try {
/* 1485 */       return _webkit_web_frame_get_load_status(frame);
/*      */     } finally {
/* 1487 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final long webkit_web_frame_get_parent(long frame)
/*      */   {
/* 1494 */     assert (WEBKIT1) : "Webkit2 code reached by webkit1";
/* 1495 */     lock.lock();
/*      */     try {
/* 1497 */       return _webkit_web_frame_get_parent(frame);
/*      */     } finally {
/* 1499 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final long webkit_web_frame_get_title(long frame)
/*      */   {
/* 1506 */     assert (WEBKIT1) : "Webkit2 code reached by webkit1";
/* 1507 */     lock.lock();
/*      */     try {
/* 1509 */       return _webkit_web_frame_get_title(frame);
/*      */     } finally {
/* 1511 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final long webkit_web_frame_get_type()
/*      */   {
/* 1519 */     assert (WEBKIT1) : "Webkit2 code reached by webkit1";
/* 1520 */     lock.lock();
/*      */     try {
/* 1522 */       return _webkit_web_frame_get_type();
/*      */     } finally {
/* 1524 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final long webkit_web_frame_get_uri(long frame)
/*      */   {
/* 1531 */     assert (WEBKIT1) : "Webkit2 code reached by webkit1";
/* 1532 */     lock.lock();
/*      */     try {
/* 1534 */       return _webkit_web_frame_get_uri(frame);
/*      */     } finally {
/* 1536 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final long webkit_web_frame_get_web_view(long frame)
/*      */   {
/* 1543 */     assert (WEBKIT1) : "Webkit2 code reached by webkit1";
/* 1544 */     lock.lock();
/*      */     try {
/* 1546 */       return _webkit_web_frame_get_web_view(frame);
/*      */     } finally {
/* 1548 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int webkit_web_view_can_go_back(long web_view)
/*      */   {
/* 1579 */     assert ((WEBKIT1) || (WEBKIT2));
/* 1580 */     lock.lock();
/*      */     try {
/* 1582 */       return _webkit_web_view_can_go_back(web_view);
/*      */     } finally {
/* 1584 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final long webkit_web_view_get_main_resource(long web_view)
/*      */   {
/* 1591 */     assert (WEBKIT2) : "Webkit1 code reached by webkit2";
/* 1592 */     lock.lock();
/*      */     try {
/* 1594 */       return _webkit_web_view_get_main_resource(web_view);
/*      */     } finally {
/* 1596 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final int webkit_web_view_can_go_forward(long web_view)
/*      */   {
/* 1603 */     assert ((WEBKIT1) || (WEBKIT2));
/* 1604 */     lock.lock();
/*      */     try {
/* 1606 */       return _webkit_web_view_can_go_forward(web_view);
/*      */     } finally {
/* 1608 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final int webkit_web_view_can_show_mime_type(long web_view, long mime_type)
/*      */   {
/* 1615 */     assert ((WEBKIT1) || (WEBKIT2));
/* 1616 */     lock.lock();
/*      */     try {
/* 1618 */       return _webkit_web_view_can_show_mime_type(web_view, mime_type);
/*      */     } finally {
/* 1620 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long webkit_web_view_get_dom_document(long web_view)
/*      */   {
/* 1639 */     assert (WEBKIT1) : "Webkit2 code reached by webkit1";
/*      */     
/* 1641 */     lock.lock();
/*      */     try {
/* 1643 */       return _webkit_web_view_get_dom_document(web_view);
/*      */     } finally {
/* 1645 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final double webkit_web_view_get_estimated_load_progress(long web_view)
/*      */   {
/* 1652 */     assert (WEBKIT2) : "Webkit1 code reached by webkit2";
/* 1653 */     lock.lock();
/*      */     try {
/* 1655 */       return _webkit_web_view_get_estimated_load_progress(web_view);
/*      */     } finally {
/* 1657 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final int webkit_web_view_get_load_status(long web_view)
/*      */   {
/* 1664 */     assert (WEBKIT1) : "Webkit2 code reached by webkit1";
/* 1665 */     lock.lock();
/*      */     try {
/* 1667 */       return _webkit_web_view_get_load_status(web_view);
/*      */     } finally {
/* 1669 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final long webkit_web_view_get_main_frame(long web_view)
/*      */   {
/* 1676 */     assert (WEBKIT1) : "Webkit2 code reached by webkit1";
/* 1677 */     lock.lock();
/*      */     try {
/* 1679 */       return _webkit_web_view_get_main_frame(web_view);
/*      */     } finally {
/* 1681 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final double webkit_web_view_get_progress(long web_view)
/*      */   {
/* 1688 */     assert (WEBKIT1) : "Webkit2 code reached by webkit1";
/* 1689 */     lock.lock();
/*      */     try {
/* 1691 */       return _webkit_web_view_get_progress(web_view);
/*      */     } finally {
/* 1693 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final long webkit_web_view_get_settings(long web_view)
/*      */   {
/* 1700 */     assert ((WEBKIT1) || (WEBKIT2));
/* 1701 */     lock.lock();
/*      */     try {
/* 1703 */       return _webkit_web_view_get_settings(web_view);
/*      */     } finally {
/* 1705 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final long webkit_web_view_get_title(long web_view)
/*      */   {
/* 1712 */     assert ((WEBKIT1) || (WEBKIT2));
/* 1713 */     lock.lock();
/*      */     try {
/* 1715 */       return _webkit_web_view_get_title(web_view);
/*      */     } finally {
/* 1717 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long webkit_web_view_get_type()
/*      */   {
/* 1726 */     lock.lock();
/*      */     try {
/* 1728 */       return _webkit_web_view_get_type();
/*      */     } finally {
/* 1730 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final long webkit_web_view_get_uri(long web_view)
/*      */   {
/* 1737 */     assert ((WEBKIT1) || (WEBKIT2));
/* 1738 */     lock.lock();
/*      */     try {
/* 1740 */       return _webkit_web_view_get_uri(web_view);
/*      */     } finally {
/* 1742 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final long webkit_web_view_get_window_features(long web_view)
/*      */   {
/* 1749 */     assert (WEBKIT1) : "Webkit2 code reached by webkit1";
/* 1750 */     lock.lock();
/*      */     try {
/* 1752 */       return _webkit_web_view_get_window_features(web_view);
/*      */     } finally {
/* 1754 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final long webkit_web_view_get_window_properties(long webView)
/*      */   {
/* 1762 */     assert (WEBKIT2) : "Webkit1 code reached by webkit2";
/* 1763 */     lock.lock();
/*      */     try {
/* 1765 */       return _webkit_web_view_get_window_properties(webView);
/*      */     } finally {
/* 1767 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void webkit_web_view_load_html(long web_view, byte[] content, byte[] base_uri)
/*      */   {
/* 1815 */     assert ((WEBKIT1) || (WEBKIT2));
/* 1816 */     lock.lock();
/*      */     try {
/* 1818 */       _webkit_web_view_load_html(web_view, content, base_uri);
/*      */     } finally {
/* 1820 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final void webkit_web_view_load_bytes(long web_view, long bytes, byte[] mime_type, byte[] encoding, byte[] base_uri)
/*      */   {
/* 1827 */     assert ((WEBKIT1) || (WEBKIT2));
/* 1828 */     lock.lock();
/*      */     try {
/* 1830 */       _webkit_web_view_load_bytes(web_view, bytes, mime_type, encoding, base_uri);
/*      */     } finally {
/* 1832 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final void webkit_web_view_load_string(long web_view, byte[] content, byte[] mime_type, byte[] encoding, byte[] base_uri)
/*      */   {
/* 1839 */     assert (WEBKIT1) : "Webkit2 code reached by webkit1";
/* 1840 */     lock.lock();
/*      */     try {
/* 1842 */       _webkit_web_view_load_string(web_view, content, mime_type, encoding, base_uri);
/*      */     } finally {
/* 1844 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final void webkit_web_view_load_request(long web_view, long request)
/*      */   {
/* 1851 */     assert ((WEBKIT1) || (WEBKIT2));
/* 1852 */     lock.lock();
/*      */     try {
/* 1854 */       _webkit_web_view_load_request(web_view, request);
/*      */     } finally {
/* 1856 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long webkit_web_view_new()
/*      */   {
/* 1875 */     assert ((WEBKIT1) || (WEBKIT2));
/* 1876 */     lock.lock();
/*      */     try {
/* 1878 */       return _webkit_web_view_new();
/*      */     } finally {
/* 1880 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void webkit_web_context_set_web_extensions_initialization_user_data(long context, long user_data)
/*      */   {
/* 1901 */     assert (WEBKIT2);
/* 1902 */     lock.lock();
/*      */     try {
/* 1904 */       _webkit_web_context_set_web_extensions_initialization_user_data(context, user_data);
/*      */     } finally {
/* 1906 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long webkit_javascript_result_get_global_context(long js_result)
/*      */   {
/* 1918 */     assert (WEBKIT2) : "Webkit1 code reached by webkit2";
/* 1919 */     lock.lock();
/*      */     try {
/* 1921 */       return _webkit_javascript_result_get_global_context(js_result);
/*      */     } finally {
/* 1923 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long webkit_javascript_result_get_value(long js_result)
/*      */   {
/* 1934 */     assert (WEBKIT2) : "Webkit1 code reached by webkit2";
/* 1935 */     lock.lock();
/*      */     try {
/* 1937 */       return _webkit_javascript_result_get_value(js_result);
/*      */     } finally {
/* 1939 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void webkit_web_view_run_javascript(long web_view, byte[] script, long cancellable, long callback, long user_data)
/*      */   {
/* 1960 */     assert (WEBKIT2) : "Webkit1 code reached by webkit2";
/* 1961 */     lock.lock();
/*      */     try {
/* 1963 */       _webkit_web_view_run_javascript(web_view, script, cancellable, callback, user_data);
/*      */     } finally {
/* 1965 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final void webkit_web_resource_get_data(long webKitWebResource, long gCancellable, long GAsyncReadyCallback, long user_data)
/*      */   {
/* 1972 */     assert ((WEBKIT1) || (WEBKIT2));
/* 1973 */     lock.lock();
/*      */     try {
/* 1975 */       _webkit_web_resource_get_data(webKitWebResource, gCancellable, GAsyncReadyCallback, user_data);
/*      */     } finally {
/* 1977 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final long webkit_web_resource_get_data_finish(long WebKitWebResource, long GAsyncResult, long[] gsize, long[] GError)
/*      */   {
/* 1984 */     assert (WEBKIT2) : "Webkit1 code reached by webkit2";
/* 1985 */     lock.lock();
/*      */     try {
/* 1987 */       return _webkit_web_resource_get_data_finish(WebKitWebResource, GAsyncResult, gsize, GError);
/*      */     } finally {
/* 1989 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static long webkit_web_view_run_javascript_finish(long web_view, long GAsyncResult, long[] gerror)
/*      */   {
/* 2001 */     assert (WEBKIT2) : "Webkit1 code reached by webkit2";
/* 2002 */     lock.lock();
/*      */     try {
/* 2004 */       return _webkit_web_view_run_javascript_finish(web_view, GAsyncResult, gerror);
/*      */     } finally {
/* 2006 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void webkit_website_data_manager_clear(long manager, long types, long timespan, long cancellable, long callback, long user_data)
/*      */   {
/* 2025 */     assert (WEBKIT2) : "Webkit1 code reached by webkit2";
/* 2026 */     lock.lock();
/*      */     try {
/* 2028 */       _webkit_website_data_manager_clear(manager, types, timespan, cancellable, callback, user_data);
/*      */     } finally {
/* 2030 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final long webkit_response_policy_decision_get_request(long decision)
/*      */   {
/* 2037 */     assert (WEBKIT2) : "Webkit1 code reached by webkit2";
/* 2038 */     lock.lock();
/*      */     try {
/* 2040 */       return _webkit_response_policy_decision_get_request(decision);
/*      */     } finally {
/* 2042 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final long webkit_response_policy_decision_get_response(long decision)
/*      */   {
/* 2049 */     assert (WEBKIT2) : "Webkit1 code reached by webkit2";
/* 2050 */     lock.lock();
/*      */     try {
/* 2052 */       return _webkit_response_policy_decision_get_response(decision);
/*      */     } finally {
/* 2054 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final long webkit_uri_request_new(byte[] uri)
/*      */   {
/* 2061 */     assert (WEBKIT2) : "Webkit1 code reached by webkit2";
/* 2062 */     lock.lock();
/*      */     try {
/* 2064 */       return _webkit_uri_request_new(uri);
/*      */     } finally {
/* 2066 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final long webkit_uri_request_get_http_headers(long request)
/*      */   {
/* 2073 */     assert (WEBKIT2) : "Webkit1 code reached by webkit2";
/* 2074 */     lock.lock();
/*      */     try {
/* 2076 */       return _webkit_uri_request_get_http_headers(request);
/*      */     } finally {
/* 2078 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final long webkit_uri_request_get_uri(long request)
/*      */   {
/* 2085 */     assert (WEBKIT2) : "Webkit1 code reached by webkit2";
/* 2086 */     lock.lock();
/*      */     try {
/* 2088 */       return _webkit_uri_request_get_uri(request);
/*      */     } finally {
/* 2090 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final long webkit_uri_response_get_mime_type(long response)
/*      */   {
/* 2097 */     assert (WEBKIT2) : "Webkit1 code reached by webkit2";
/* 2098 */     lock.lock();
/*      */     try {
/* 2100 */       return _webkit_uri_response_get_mime_type(response);
/*      */     } finally {
/* 2102 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long SoupCookie_expires(long cookie)
/*      */   {
/* 2124 */     lock.lock();
/*      */     try {
/* 2126 */       return _SoupCookie_expires(cookie);
/*      */     } finally {
/* 2128 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void SoupMessage_method(long message, long method)
/*      */   {
/* 2139 */     lock.lock();
/*      */     try {
/* 2141 */       _SoupMessage_method(message, method);
/*      */     } finally {
/* 2143 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long SoupMessage_request_body(long message)
/*      */   {
/* 2153 */     lock.lock();
/*      */     try {
/* 2155 */       return _SoupMessage_request_body(message);
/*      */     } finally {
/* 2157 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long SoupMessage_request_headers(long message)
/*      */   {
/* 2167 */     lock.lock();
/*      */     try {
/* 2169 */       return _SoupMessage_request_headers(message);
/*      */     } finally {
/* 2171 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _JSClassCreate(long paramLong);
/*      */   
/*      */   public static final native long _JSContextGetGlobalObject(long paramLong);
/*      */   
/*      */   public static final native long _JSEvaluateScript(long paramLong1, long paramLong2, long paramLong3, long paramLong4, int paramInt, long[] paramArrayOfLong);
/*      */   
/*      */   public static final native long _JSObjectGetPrivate(long paramLong);
/*      */   
/*      */   public static final native long _JSObjectGetProperty(long paramLong1, long paramLong2, long paramLong3, long[] paramArrayOfLong);
/*      */   
/*      */   public static final native long _JSObjectGetPropertyAtIndex(long paramLong1, long paramLong2, int paramInt, long[] paramArrayOfLong);
/*      */   
/*      */   public static final native long _JSObjectMake(long paramLong1, long paramLong2, long paramLong3);
/*      */   
/*      */   public static final native long _JSObjectMakeArray(long paramLong1, long paramLong2, long[] paramArrayOfLong1, long[] paramArrayOfLong2);
/*      */   
/*      */   public static final native long _JSObjectMakeFunctionWithCallback(long paramLong1, long paramLong2, long paramLong3);
/*      */   
/*      */   public static final native void _JSObjectSetProperty(long paramLong1, long paramLong2, long paramLong3, long paramLong4, int paramInt, long[] paramArrayOfLong);
/*      */   
/*      */   public static final native long _JSStringCreateWithUTF8CString(byte[] paramArrayOfByte);
/*      */   
/*      */   public static final native long _JSStringGetLength(long paramLong);
/*      */   
/*      */   public static final native long _JSStringGetMaximumUTF8CStringSize(long paramLong);
/*      */   
/*      */   public static final native long _JSStringGetUTF8CString(long paramLong1, byte[] paramArrayOfByte, long paramLong2);
/*      */   
/*      */   public static final native int _JSStringIsEqualToUTF8CString(long paramLong, byte[] paramArrayOfByte);
/*      */   
/*      */   public static final native void _JSStringRelease(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void JSStringRelease(long string)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 4	org/eclipse/swt/internal/webkit/WebKitGTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 5	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 22	org/eclipse/swt/internal/webkit/WebKitGTK:_JSStringRelease	(J)V
/*      */     //   11: getstatic 4	org/eclipse/swt/internal/webkit/WebKitGTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 7	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 4	org/eclipse/swt/internal/webkit/WebKitGTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 7	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #398	-> byte code offset #0
/*      */     //   Java source line #400	-> byte code offset #7
/*      */     //   Java source line #402	-> byte code offset #11
/*      */     //   Java source line #403	-> byte code offset #17
/*      */     //   Java source line #402	-> byte code offset #20
/*      */     //   Java source line #403	-> byte code offset #27
/*      */     //   Java source line #404	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	string	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native void _webkit_javascript_result_unref(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void webkit_javascript_result_unref(long js_result)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 23	org/eclipse/swt/internal/webkit/WebKitGTK:$assertionsDisabled	Z
/*      */     //   3: ifne +19 -> 22
/*      */     //   6: getstatic 24	org/eclipse/swt/internal/webkit/WebKitGTK:WEBKIT2	Z
/*      */     //   9: ifne +13 -> 22
/*      */     //   12: new 25	java/lang/AssertionError
/*      */     //   15: dup
/*      */     //   16: ldc 27
/*      */     //   18: invokespecial 28	java/lang/AssertionError:<init>	(Ljava/lang/Object;)V
/*      */     //   21: athrow
/*      */     //   22: getstatic 4	org/eclipse/swt/internal/webkit/WebKitGTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   28: pop
/*      */     //   29: lload_0
/*      */     //   30: invokestatic 29	org/eclipse/swt/internal/webkit/WebKitGTK:_webkit_javascript_result_unref	(J)V
/*      */     //   33: getstatic 4	org/eclipse/swt/internal/webkit/WebKitGTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   36: invokevirtual 7	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   39: goto +12 -> 51
/*      */     //   42: astore_2
/*      */     //   43: getstatic 4	org/eclipse/swt/internal/webkit/WebKitGTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   46: invokevirtual 7	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   49: aload_2
/*      */     //   50: athrow
/*      */     //   51: return
/*      */     // Line number table:
/*      */     //   Java source line #411	-> byte code offset #0
/*      */     //   Java source line #412	-> byte code offset #22
/*      */     //   Java source line #414	-> byte code offset #29
/*      */     //   Java source line #416	-> byte code offset #33
/*      */     //   Java source line #417	-> byte code offset #39
/*      */     //   Java source line #416	-> byte code offset #42
/*      */     //   Java source line #417	-> byte code offset #49
/*      */     //   Java source line #418	-> byte code offset #51
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	52	0	js_result	long
/*      */     //   42	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   29	33	42	finally
/*      */   }
/*      */   
/*      */   public static final native int _JSValueGetType(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final native int _JSValueIsObjectOfClass(long paramLong1, long paramLong2, long paramLong3);
/*      */   
/*      */   public static final native long _JSValueMakeBoolean(long paramLong, int paramInt);
/*      */   
/*      */   public static final native long _JSValueMakeNumber(long paramLong, double paramDouble);
/*      */   
/*      */   public static final native long _JSValueMakeString(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final native long _JSValueMakeUndefined(long paramLong);
/*      */   
/*      */   public static final native double _JSValueToNumber(long paramLong1, long paramLong2, long[] paramArrayOfLong);
/*      */   
/*      */   public static final native long _JSValueToStringCopy(long paramLong1, long paramLong2, long[] paramArrayOfLong);
/*      */   
/*      */   public static final native void _soup_auth_authenticate(long paramLong, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2);
/*      */   
/*      */   public static final native long _soup_auth_get_host(long paramLong);
/*      */   
/*      */   public static final native long _soup_auth_get_scheme_name(long paramLong);
/*      */   
/*      */   public static final native void _soup_cookie_free(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void soup_cookie_free(long cookie)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 4	org/eclipse/swt/internal/webkit/WebKitGTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 5	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 41	org/eclipse/swt/internal/webkit/WebKitGTK:_soup_cookie_free	(J)V
/*      */     //   11: getstatic 4	org/eclipse/swt/internal/webkit/WebKitGTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 7	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 4	org/eclipse/swt/internal/webkit/WebKitGTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 7	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #546	-> byte code offset #0
/*      */     //   Java source line #548	-> byte code offset #7
/*      */     //   Java source line #550	-> byte code offset #11
/*      */     //   Java source line #551	-> byte code offset #17
/*      */     //   Java source line #550	-> byte code offset #20
/*      */     //   Java source line #551	-> byte code offset #27
/*      */     //   Java source line #552	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	cookie	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native void _soup_cookie_jar_add_cookie(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final native long _soup_cookie_jar_all_cookies(long paramLong);
/*      */   
/*      */   public static final native void _soup_cookie_jar_delete_cookie(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final native long _soup_cookie_jar_get_cookies(long paramLong1, long paramLong2, int paramInt);
/*      */   
/*      */   public static final native long _soup_cookie_jar_get_type();
/*      */   
/*      */   public static final native long _soup_cookie_parse(byte[] paramArrayOfByte, long paramLong);
/*      */   
/*      */   public static final native void _soup_message_body_append(long paramLong1, int paramInt, long paramLong2, long paramLong3);
/*      */   
/*      */   public static final native void _soup_message_body_flatten(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void soup_message_body_flatten(long body)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 4	org/eclipse/swt/internal/webkit/WebKitGTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 5	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 49	org/eclipse/swt/internal/webkit/WebKitGTK:_soup_message_body_flatten	(J)V
/*      */     //   11: getstatic 4	org/eclipse/swt/internal/webkit/WebKitGTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 7	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 4	org/eclipse/swt/internal/webkit/WebKitGTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 7	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #634	-> byte code offset #0
/*      */     //   Java source line #636	-> byte code offset #7
/*      */     //   Java source line #638	-> byte code offset #11
/*      */     //   Java source line #639	-> byte code offset #17
/*      */     //   Java source line #638	-> byte code offset #20
/*      */     //   Java source line #639	-> byte code offset #27
/*      */     //   Java source line #640	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	body	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native long _soup_message_get_uri(long paramLong);
/*      */   
/*      */   public static final native void _soup_message_headers_append(long paramLong, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2);
/*      */   
/*      */   public static final native void _soup_session_add_feature_by_type(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final native long _soup_session_get_feature(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final native void _soup_session_feature_attach(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final native long _soup_session_get_type();
/*      */   
/*      */   public static final native void _soup_session_feature_detach(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final native void _soup_uri_free(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void soup_uri_free(long uri)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 4	org/eclipse/swt/internal/webkit/WebKitGTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 5	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 57	org/eclipse/swt/internal/webkit/WebKitGTK:_soup_uri_free	(J)V
/*      */     //   11: getstatic 4	org/eclipse/swt/internal/webkit/WebKitGTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 7	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 4	org/eclipse/swt/internal/webkit/WebKitGTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 7	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #722	-> byte code offset #0
/*      */     //   Java source line #724	-> byte code offset #7
/*      */     //   Java source line #726	-> byte code offset #11
/*      */     //   Java source line #727	-> byte code offset #17
/*      */     //   Java source line #726	-> byte code offset #20
/*      */     //   Java source line #727	-> byte code offset #27
/*      */     //   Java source line #728	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	uri	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native long _soup_uri_new(byte[] paramArrayOfByte);
/*      */   
/*      */   public static final native long _soup_uri_to_string(long paramLong, int paramInt);
/*      */   
/*      */   public static final native void _webkit_authentication_request_authenticate(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final native void _webkit_authentication_request_cancel(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void webkit_authentication_request_cancel(long request)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 23	org/eclipse/swt/internal/webkit/WebKitGTK:$assertionsDisabled	Z
/*      */     //   3: ifne +19 -> 22
/*      */     //   6: getstatic 24	org/eclipse/swt/internal/webkit/WebKitGTK:WEBKIT2	Z
/*      */     //   9: ifne +13 -> 22
/*      */     //   12: new 25	java/lang/AssertionError
/*      */     //   15: dup
/*      */     //   16: ldc 27
/*      */     //   18: invokespecial 28	java/lang/AssertionError:<init>	(Ljava/lang/Object;)V
/*      */     //   21: athrow
/*      */     //   22: getstatic 4	org/eclipse/swt/internal/webkit/WebKitGTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   28: pop
/*      */     //   29: lload_0
/*      */     //   30: invokestatic 61	org/eclipse/swt/internal/webkit/WebKitGTK:_webkit_authentication_request_cancel	(J)V
/*      */     //   33: getstatic 4	org/eclipse/swt/internal/webkit/WebKitGTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   36: invokevirtual 7	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   39: goto +12 -> 51
/*      */     //   42: astore_2
/*      */     //   43: getstatic 4	org/eclipse/swt/internal/webkit/WebKitGTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   46: invokevirtual 7	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   49: aload_2
/*      */     //   50: athrow
/*      */     //   51: return
/*      */     // Line number table:
/*      */     //   Java source line #769	-> byte code offset #0
/*      */     //   Java source line #770	-> byte code offset #22
/*      */     //   Java source line #772	-> byte code offset #29
/*      */     //   Java source line #774	-> byte code offset #33
/*      */     //   Java source line #775	-> byte code offset #39
/*      */     //   Java source line #774	-> byte code offset #42
/*      */     //   Java source line #775	-> byte code offset #49
/*      */     //   Java source line #776	-> byte code offset #51
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	52	0	request	long
/*      */     //   42	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   29	33	42	finally
/*      */   }
/*      */   
/*      */   public static final native boolean _webkit_authentication_request_is_retry(long paramLong);
/*      */   
/*      */   public static final native void _webkit_credential_free(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void webkit_credential_free(long credential)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 23	org/eclipse/swt/internal/webkit/WebKitGTK:$assertionsDisabled	Z
/*      */     //   3: ifne +19 -> 22
/*      */     //   6: getstatic 24	org/eclipse/swt/internal/webkit/WebKitGTK:WEBKIT2	Z
/*      */     //   9: ifne +13 -> 22
/*      */     //   12: new 25	java/lang/AssertionError
/*      */     //   15: dup
/*      */     //   16: ldc 27
/*      */     //   18: invokespecial 28	java/lang/AssertionError:<init>	(Ljava/lang/Object;)V
/*      */     //   21: athrow
/*      */     //   22: getstatic 4	org/eclipse/swt/internal/webkit/WebKitGTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   28: pop
/*      */     //   29: lload_0
/*      */     //   30: invokestatic 63	org/eclipse/swt/internal/webkit/WebKitGTK:_webkit_credential_free	(J)V
/*      */     //   33: getstatic 4	org/eclipse/swt/internal/webkit/WebKitGTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   36: invokevirtual 7	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   39: goto +12 -> 51
/*      */     //   42: astore_2
/*      */     //   43: getstatic 4	org/eclipse/swt/internal/webkit/WebKitGTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   46: invokevirtual 7	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   49: aload_2
/*      */     //   50: athrow
/*      */     //   51: return
/*      */     // Line number table:
/*      */     //   Java source line #793	-> byte code offset #0
/*      */     //   Java source line #794	-> byte code offset #22
/*      */     //   Java source line #796	-> byte code offset #29
/*      */     //   Java source line #798	-> byte code offset #33
/*      */     //   Java source line #799	-> byte code offset #39
/*      */     //   Java source line #798	-> byte code offset #42
/*      */     //   Java source line #799	-> byte code offset #49
/*      */     //   Java source line #800	-> byte code offset #51
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	52	0	credential	long
/*      */     //   42	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   29	33	42	finally
/*      */   }
/*      */   
/*      */   public static final native long _webkit_web_context_get_type();
/*      */   
/*      */   public static final native long _webkit_credential_new(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, int paramInt);
/*      */   
/*      */   public static final native int _webkit_dom_event_target_add_event_listener(long paramLong1, byte[] paramArrayOfByte, long paramLong2, int paramInt, long paramLong3);
/*      */   
/*      */   public static final native int _webkit_dom_mouse_event_get_alt_key(long paramLong);
/*      */   
/*      */   public static final native short _webkit_dom_mouse_event_get_button(long paramLong);
/*      */   
/*      */   public static final native int _webkit_dom_mouse_event_get_ctrl_key(long paramLong);
/*      */   
/*      */   public static final native int _webkit_dom_mouse_event_get_meta_key(long paramLong);
/*      */   
/*      */   public static final native long _webkit_dom_mouse_event_get_screen_x(long paramLong);
/*      */   
/*      */   public static final native long _webkit_dom_mouse_event_get_screen_y(long paramLong);
/*      */   
/*      */   public static final native int _webkit_dom_mouse_event_get_shift_key(long paramLong);
/*      */   
/*      */   public static final native long _webkit_dom_ui_event_get_char_code(long paramLong);
/*      */   
/*      */   public static final native long _webkit_dom_ui_event_get_detail(long paramLong);
/*      */   
/*      */   public static final native long _webkit_dom_ui_event_get_key_code(long paramLong);
/*      */   
/*      */   public static final native void _webkit_download_cancel(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void webkit_download_cancel(long download)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 23	org/eclipse/swt/internal/webkit/WebKitGTK:$assertionsDisabled	Z
/*      */     //   3: ifne +23 -> 26
/*      */     //   6: getstatic 77	org/eclipse/swt/internal/webkit/WebKitGTK:WEBKIT1	Z
/*      */     //   9: ifne +17 -> 26
/*      */     //   12: getstatic 24	org/eclipse/swt/internal/webkit/WebKitGTK:WEBKIT2	Z
/*      */     //   15: ifne +11 -> 26
/*      */     //   18: new 25	java/lang/AssertionError
/*      */     //   21: dup
/*      */     //   22: invokespecial 78	java/lang/AssertionError:<init>	()V
/*      */     //   25: athrow
/*      */     //   26: getstatic 4	org/eclipse/swt/internal/webkit/WebKitGTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   29: invokevirtual 5	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   32: pop
/*      */     //   33: lload_0
/*      */     //   34: invokestatic 79	org/eclipse/swt/internal/webkit/WebKitGTK:_webkit_download_cancel	(J)V
/*      */     //   37: getstatic 4	org/eclipse/swt/internal/webkit/WebKitGTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   40: invokevirtual 7	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   43: goto +12 -> 55
/*      */     //   46: astore_2
/*      */     //   47: getstatic 4	org/eclipse/swt/internal/webkit/WebKitGTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   50: invokevirtual 7	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   53: aload_2
/*      */     //   54: athrow
/*      */     //   55: return
/*      */     // Line number table:
/*      */     //   Java source line #952	-> byte code offset #0
/*      */     //   Java source line #953	-> byte code offset #26
/*      */     //   Java source line #955	-> byte code offset #33
/*      */     //   Java source line #957	-> byte code offset #37
/*      */     //   Java source line #958	-> byte code offset #43
/*      */     //   Java source line #957	-> byte code offset #46
/*      */     //   Java source line #958	-> byte code offset #53
/*      */     //   Java source line #959	-> byte code offset #55
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	56	0	download	long
/*      */     //   46	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   33	37	46	finally
/*      */   }
/*      */   
/*      */   public static final native long _webkit_download_get_current_size(long paramLong);
/*      */   
/*      */   public static final native long _webkit_download_get_received_data_length(long paramLong);
/*      */   
/*      */   public static final native long _webkit_download_get_network_request(long paramLong);
/*      */   
/*      */   public static final native int _webkit_download_get_status(long paramLong);
/*      */   
/*      */   public static final native long _webkit_download_get_suggested_filename(long paramLong);
/*      */   
/*      */   public static final native long _webkit_download_get_request(long paramLong);
/*      */   
/*      */   public static final native long _webkit_download_get_response(long paramLong);
/*      */   
/*      */   public static final native long _webkit_download_get_total_size(long paramLong);
/*      */   
/*      */   public static final native long _webkit_download_get_type();
/*      */   
/*      */   public static final native long _webkit_uri_response_get_content_length(long paramLong);
/*      */   
/*      */   public static final native long _webkit_download_get_uri(long paramLong);
/*      */   
/*      */   public static final native long _webkit_download_get_web_view(long paramLong);
/*      */   
/*      */   public static final native long _webkit_download_new(long paramLong);
/*      */   
/*      */   public static final native void _webkit_download_set_allow_overwrite(long paramLong, boolean paramBoolean);
/*      */   
/*      */   /* Error */
/*      */   public static final void webkit_download_set_allow_overwrite(long download, boolean allowed)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 23	org/eclipse/swt/internal/webkit/WebKitGTK:$assertionsDisabled	Z
/*      */     //   3: ifne +19 -> 22
/*      */     //   6: getstatic 24	org/eclipse/swt/internal/webkit/WebKitGTK:WEBKIT2	Z
/*      */     //   9: ifne +13 -> 22
/*      */     //   12: new 25	java/lang/AssertionError
/*      */     //   15: dup
/*      */     //   16: ldc 27
/*      */     //   18: invokespecial 28	java/lang/AssertionError:<init>	(Ljava/lang/Object;)V
/*      */     //   21: athrow
/*      */     //   22: getstatic 4	org/eclipse/swt/internal/webkit/WebKitGTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   28: pop
/*      */     //   29: lload_0
/*      */     //   30: iload_2
/*      */     //   31: invokestatic 94	org/eclipse/swt/internal/webkit/WebKitGTK:_webkit_download_set_allow_overwrite	(JZ)V
/*      */     //   34: getstatic 4	org/eclipse/swt/internal/webkit/WebKitGTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   37: invokevirtual 7	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   40: goto +12 -> 52
/*      */     //   43: astore_3
/*      */     //   44: getstatic 4	org/eclipse/swt/internal/webkit/WebKitGTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   47: invokevirtual 7	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   50: aload_3
/*      */     //   51: athrow
/*      */     //   52: return
/*      */     // Line number table:
/*      */     //   Java source line #1120	-> byte code offset #0
/*      */     //   Java source line #1121	-> byte code offset #22
/*      */     //   Java source line #1123	-> byte code offset #29
/*      */     //   Java source line #1125	-> byte code offset #34
/*      */     //   Java source line #1126	-> byte code offset #40
/*      */     //   Java source line #1125	-> byte code offset #43
/*      */     //   Java source line #1126	-> byte code offset #50
/*      */     //   Java source line #1127	-> byte code offset #52
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	53	0	download	long
/*      */     //   0	53	2	allowed	boolean
/*      */     //   43	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   29	34	43	finally
/*      */   }
/*      */   
/*      */   public static final native void _webkit_download_set_destination_uri(long paramLong, byte[] paramArrayOfByte);
/*      */   
/*      */   /* Error */
/*      */   public static final void webkit_download_set_destination_uri(long download, byte[] destination_uri)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 23	org/eclipse/swt/internal/webkit/WebKitGTK:$assertionsDisabled	Z
/*      */     //   3: ifne +19 -> 22
/*      */     //   6: getstatic 77	org/eclipse/swt/internal/webkit/WebKitGTK:WEBKIT1	Z
/*      */     //   9: ifne +13 -> 22
/*      */     //   12: new 25	java/lang/AssertionError
/*      */     //   15: dup
/*      */     //   16: ldc 80
/*      */     //   18: invokespecial 28	java/lang/AssertionError:<init>	(Ljava/lang/Object;)V
/*      */     //   21: athrow
/*      */     //   22: getstatic 4	org/eclipse/swt/internal/webkit/WebKitGTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   28: pop
/*      */     //   29: lload_0
/*      */     //   30: aload_2
/*      */     //   31: invokestatic 95	org/eclipse/swt/internal/webkit/WebKitGTK:_webkit_download_set_destination_uri	(J[B)V
/*      */     //   34: getstatic 4	org/eclipse/swt/internal/webkit/WebKitGTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   37: invokevirtual 7	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   40: goto +12 -> 52
/*      */     //   43: astore_3
/*      */     //   44: getstatic 4	org/eclipse/swt/internal/webkit/WebKitGTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   47: invokevirtual 7	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   50: aload_3
/*      */     //   51: athrow
/*      */     //   52: return
/*      */     // Line number table:
/*      */     //   Java source line #1132	-> byte code offset #0
/*      */     //   Java source line #1133	-> byte code offset #22
/*      */     //   Java source line #1135	-> byte code offset #29
/*      */     //   Java source line #1137	-> byte code offset #34
/*      */     //   Java source line #1138	-> byte code offset #40
/*      */     //   Java source line #1137	-> byte code offset #43
/*      */     //   Java source line #1138	-> byte code offset #50
/*      */     //   Java source line #1139	-> byte code offset #52
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	53	0	download	long
/*      */     //   0	53	2	destination_uri	byte[]
/*      */     //   43	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   29	34	43	finally
/*      */   }
/*      */   
/*      */   public static final native void _webkit_download_set_destination(long paramLong, byte[] paramArrayOfByte);
/*      */   
/*      */   /* Error */
/*      */   public static final void webkit_download_set_destination(long download, byte[] destination_uri)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 23	org/eclipse/swt/internal/webkit/WebKitGTK:$assertionsDisabled	Z
/*      */     //   3: ifne +19 -> 22
/*      */     //   6: getstatic 24	org/eclipse/swt/internal/webkit/WebKitGTK:WEBKIT2	Z
/*      */     //   9: ifne +13 -> 22
/*      */     //   12: new 25	java/lang/AssertionError
/*      */     //   15: dup
/*      */     //   16: ldc 27
/*      */     //   18: invokespecial 28	java/lang/AssertionError:<init>	(Ljava/lang/Object;)V
/*      */     //   21: athrow
/*      */     //   22: getstatic 4	org/eclipse/swt/internal/webkit/WebKitGTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   28: pop
/*      */     //   29: lload_0
/*      */     //   30: aload_2
/*      */     //   31: invokestatic 96	org/eclipse/swt/internal/webkit/WebKitGTK:_webkit_download_set_destination	(J[B)V
/*      */     //   34: getstatic 4	org/eclipse/swt/internal/webkit/WebKitGTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   37: invokevirtual 7	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   40: goto +12 -> 52
/*      */     //   43: astore_3
/*      */     //   44: getstatic 4	org/eclipse/swt/internal/webkit/WebKitGTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   47: invokevirtual 7	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   50: aload_3
/*      */     //   51: athrow
/*      */     //   52: return
/*      */     // Line number table:
/*      */     //   Java source line #1144	-> byte code offset #0
/*      */     //   Java source line #1145	-> byte code offset #22
/*      */     //   Java source line #1147	-> byte code offset #29
/*      */     //   Java source line #1149	-> byte code offset #34
/*      */     //   Java source line #1150	-> byte code offset #40
/*      */     //   Java source line #1149	-> byte code offset #43
/*      */     //   Java source line #1150	-> byte code offset #50
/*      */     //   Java source line #1151	-> byte code offset #52
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	53	0	download	long
/*      */     //   0	53	2	destination_uri	byte[]
/*      */     //   43	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   29	34	43	finally
/*      */   }
/*      */   
/*      */   public static final native void _webkit_download_start(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void webkit_download_start(long download)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 23	org/eclipse/swt/internal/webkit/WebKitGTK:$assertionsDisabled	Z
/*      */     //   3: ifne +19 -> 22
/*      */     //   6: getstatic 77	org/eclipse/swt/internal/webkit/WebKitGTK:WEBKIT1	Z
/*      */     //   9: ifne +13 -> 22
/*      */     //   12: new 25	java/lang/AssertionError
/*      */     //   15: dup
/*      */     //   16: ldc 80
/*      */     //   18: invokespecial 28	java/lang/AssertionError:<init>	(Ljava/lang/Object;)V
/*      */     //   21: athrow
/*      */     //   22: getstatic 4	org/eclipse/swt/internal/webkit/WebKitGTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   28: pop
/*      */     //   29: lload_0
/*      */     //   30: invokestatic 97	org/eclipse/swt/internal/webkit/WebKitGTK:_webkit_download_start	(J)V
/*      */     //   33: getstatic 4	org/eclipse/swt/internal/webkit/WebKitGTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   36: invokevirtual 7	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   39: goto +12 -> 51
/*      */     //   42: astore_2
/*      */     //   43: getstatic 4	org/eclipse/swt/internal/webkit/WebKitGTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   46: invokevirtual 7	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   49: aload_2
/*      */     //   50: athrow
/*      */     //   51: return
/*      */     // Line number table:
/*      */     //   Java source line #1156	-> byte code offset #0
/*      */     //   Java source line #1157	-> byte code offset #22
/*      */     //   Java source line #1159	-> byte code offset #29
/*      */     //   Java source line #1161	-> byte code offset #33
/*      */     //   Java source line #1162	-> byte code offset #39
/*      */     //   Java source line #1161	-> byte code offset #42
/*      */     //   Java source line #1162	-> byte code offset #49
/*      */     //   Java source line #1163	-> byte code offset #51
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	52	0	download	long
/*      */     //   42	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   29	33	42	finally
/*      */   }
/*      */   
/*      */   public static final native void _webkit_favicon_database_set_path(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final native long _webkit_get_default_session();
/*      */   
/*      */   public static final native long _webkit_get_favicon_database();
/*      */   
/*      */   public static final native boolean _webkit_hit_test_result_context_is_link(long paramLong);
/*      */   
/*      */   public static final native long _webkit_hit_test_result_get_link_uri(long paramLong);
/*      */   
/*      */   public static final native long _webkit_hit_test_result_get_link_title(long paramLong);
/*      */   
/*      */   public static final native int _webkit_major_version();
/*      */   
/*      */   public static final native int _webkit_get_major_version();
/*      */   
/*      */   public static final native int _webkit_micro_version();
/*      */   
/*      */   public static final native int _webkit_get_micro_version();
/*      */   
/*      */   public static final native int _webkit_minor_version();
/*      */   
/*      */   public static final native int _webkit_get_minor_version();
/*      */   
/*      */   public static final native long _webkit_navigation_policy_decision_get_request(long paramLong);
/*      */   
/*      */   public static final native long _webkit_network_request_get_message(long paramLong);
/*      */   
/*      */   public static final native long _webkit_network_request_get_uri(long paramLong);
/*      */   
/*      */   public static final native long _webkit_network_request_new(byte[] paramArrayOfByte);
/*      */   
/*      */   public static final native void _webkit_policy_decision_download(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void webkit_policy_decision_download(long decision)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 23	org/eclipse/swt/internal/webkit/WebKitGTK:$assertionsDisabled	Z
/*      */     //   3: ifne +19 -> 22
/*      */     //   6: getstatic 24	org/eclipse/swt/internal/webkit/WebKitGTK:WEBKIT2	Z
/*      */     //   9: ifne +13 -> 22
/*      */     //   12: new 25	java/lang/AssertionError
/*      */     //   15: dup
/*      */     //   16: ldc 27
/*      */     //   18: invokespecial 28	java/lang/AssertionError:<init>	(Ljava/lang/Object;)V
/*      */     //   21: athrow
/*      */     //   22: getstatic 4	org/eclipse/swt/internal/webkit/WebKitGTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   28: pop
/*      */     //   29: lload_0
/*      */     //   30: invokestatic 114	org/eclipse/swt/internal/webkit/WebKitGTK:_webkit_policy_decision_download	(J)V
/*      */     //   33: getstatic 4	org/eclipse/swt/internal/webkit/WebKitGTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   36: invokevirtual 7	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   39: goto +12 -> 51
/*      */     //   42: astore_2
/*      */     //   43: getstatic 4	org/eclipse/swt/internal/webkit/WebKitGTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   46: invokevirtual 7	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   49: aload_2
/*      */     //   50: athrow
/*      */     //   51: return
/*      */     // Line number table:
/*      */     //   Java source line #1360	-> byte code offset #0
/*      */     //   Java source line #1361	-> byte code offset #22
/*      */     //   Java source line #1363	-> byte code offset #29
/*      */     //   Java source line #1365	-> byte code offset #33
/*      */     //   Java source line #1366	-> byte code offset #39
/*      */     //   Java source line #1365	-> byte code offset #42
/*      */     //   Java source line #1366	-> byte code offset #49
/*      */     //   Java source line #1367	-> byte code offset #51
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	52	0	decision	long
/*      */     //   42	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   29	33	42	finally
/*      */   }
/*      */   
/*      */   public static final native void _webkit_policy_decision_ignore(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void webkit_policy_decision_ignore(long decision)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 23	org/eclipse/swt/internal/webkit/WebKitGTK:$assertionsDisabled	Z
/*      */     //   3: ifne +19 -> 22
/*      */     //   6: getstatic 24	org/eclipse/swt/internal/webkit/WebKitGTK:WEBKIT2	Z
/*      */     //   9: ifne +13 -> 22
/*      */     //   12: new 25	java/lang/AssertionError
/*      */     //   15: dup
/*      */     //   16: ldc 27
/*      */     //   18: invokespecial 28	java/lang/AssertionError:<init>	(Ljava/lang/Object;)V
/*      */     //   21: athrow
/*      */     //   22: getstatic 4	org/eclipse/swt/internal/webkit/WebKitGTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   28: pop
/*      */     //   29: lload_0
/*      */     //   30: invokestatic 115	org/eclipse/swt/internal/webkit/WebKitGTK:_webkit_policy_decision_ignore	(J)V
/*      */     //   33: getstatic 4	org/eclipse/swt/internal/webkit/WebKitGTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   36: invokevirtual 7	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   39: goto +12 -> 51
/*      */     //   42: astore_2
/*      */     //   43: getstatic 4	org/eclipse/swt/internal/webkit/WebKitGTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   46: invokevirtual 7	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   49: aload_2
/*      */     //   50: athrow
/*      */     //   51: return
/*      */     // Line number table:
/*      */     //   Java source line #1372	-> byte code offset #0
/*      */     //   Java source line #1373	-> byte code offset #22
/*      */     //   Java source line #1375	-> byte code offset #29
/*      */     //   Java source line #1377	-> byte code offset #33
/*      */     //   Java source line #1378	-> byte code offset #39
/*      */     //   Java source line #1377	-> byte code offset #42
/*      */     //   Java source line #1378	-> byte code offset #49
/*      */     //   Java source line #1379	-> byte code offset #51
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	52	0	decision	long
/*      */     //   42	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   29	33	42	finally
/*      */   }
/*      */   
/*      */   public static final native long _webkit_soup_auth_dialog_get_type();
/*      */   
/*      */   public static final native long _webkit_web_context_get_default();
/*      */   
/*      */   public static final native long _webkit_web_context_get_website_data_manager(long paramLong);
/*      */   
/*      */   public static final native long _webkit_web_context_set_favicon_database_directory(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final native long _webkit_web_data_source_get_data(long paramLong);
/*      */   
/*      */   public static final native long _webkit_web_data_source_get_encoding(long paramLong);
/*      */   
/*      */   public static final native long _webkit_web_frame_get_data_source(long paramLong);
/*      */   
/*      */   public static final native long _webkit_web_frame_get_global_context(long paramLong);
/*      */   
/*      */   public static final native int _webkit_web_frame_get_load_status(long paramLong);
/*      */   
/*      */   public static final native long _webkit_web_frame_get_parent(long paramLong);
/*      */   
/*      */   public static final native long _webkit_web_frame_get_title(long paramLong);
/*      */   
/*      */   public static final native long _webkit_web_frame_get_type();
/*      */   
/*      */   public static final native long _webkit_web_frame_get_uri(long paramLong);
/*      */   
/*      */   public static final native long _webkit_web_frame_get_web_view(long paramLong);
/*      */   
/*      */   public static final native void _webkit_web_policy_decision_download(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void webkit_web_policy_decision_download(long decision)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 23	org/eclipse/swt/internal/webkit/WebKitGTK:$assertionsDisabled	Z
/*      */     //   3: ifne +19 -> 22
/*      */     //   6: getstatic 77	org/eclipse/swt/internal/webkit/WebKitGTK:WEBKIT1	Z
/*      */     //   9: ifne +13 -> 22
/*      */     //   12: new 25	java/lang/AssertionError
/*      */     //   15: dup
/*      */     //   16: ldc 80
/*      */     //   18: invokespecial 28	java/lang/AssertionError:<init>	(Ljava/lang/Object;)V
/*      */     //   21: athrow
/*      */     //   22: getstatic 4	org/eclipse/swt/internal/webkit/WebKitGTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   28: pop
/*      */     //   29: lload_0
/*      */     //   30: invokestatic 130	org/eclipse/swt/internal/webkit/WebKitGTK:_webkit_web_policy_decision_download	(J)V
/*      */     //   33: getstatic 4	org/eclipse/swt/internal/webkit/WebKitGTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   36: invokevirtual 7	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   39: goto +12 -> 51
/*      */     //   42: astore_2
/*      */     //   43: getstatic 4	org/eclipse/swt/internal/webkit/WebKitGTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   46: invokevirtual 7	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   49: aload_2
/*      */     //   50: athrow
/*      */     //   51: return
/*      */     // Line number table:
/*      */     //   Java source line #1555	-> byte code offset #0
/*      */     //   Java source line #1556	-> byte code offset #22
/*      */     //   Java source line #1558	-> byte code offset #29
/*      */     //   Java source line #1560	-> byte code offset #33
/*      */     //   Java source line #1561	-> byte code offset #39
/*      */     //   Java source line #1560	-> byte code offset #42
/*      */     //   Java source line #1561	-> byte code offset #49
/*      */     //   Java source line #1562	-> byte code offset #51
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	52	0	decision	long
/*      */     //   42	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   29	33	42	finally
/*      */   }
/*      */   
/*      */   public static final native void _webkit_web_policy_decision_ignore(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void webkit_web_policy_decision_ignore(long decision)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 23	org/eclipse/swt/internal/webkit/WebKitGTK:$assertionsDisabled	Z
/*      */     //   3: ifne +19 -> 22
/*      */     //   6: getstatic 77	org/eclipse/swt/internal/webkit/WebKitGTK:WEBKIT1	Z
/*      */     //   9: ifne +13 -> 22
/*      */     //   12: new 25	java/lang/AssertionError
/*      */     //   15: dup
/*      */     //   16: ldc 80
/*      */     //   18: invokespecial 28	java/lang/AssertionError:<init>	(Ljava/lang/Object;)V
/*      */     //   21: athrow
/*      */     //   22: getstatic 4	org/eclipse/swt/internal/webkit/WebKitGTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   28: pop
/*      */     //   29: lload_0
/*      */     //   30: invokestatic 131	org/eclipse/swt/internal/webkit/WebKitGTK:_webkit_web_policy_decision_ignore	(J)V
/*      */     //   33: getstatic 4	org/eclipse/swt/internal/webkit/WebKitGTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   36: invokevirtual 7	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   39: goto +12 -> 51
/*      */     //   42: astore_2
/*      */     //   43: getstatic 4	org/eclipse/swt/internal/webkit/WebKitGTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   46: invokevirtual 7	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   49: aload_2
/*      */     //   50: athrow
/*      */     //   51: return
/*      */     // Line number table:
/*      */     //   Java source line #1567	-> byte code offset #0
/*      */     //   Java source line #1568	-> byte code offset #22
/*      */     //   Java source line #1570	-> byte code offset #29
/*      */     //   Java source line #1572	-> byte code offset #33
/*      */     //   Java source line #1573	-> byte code offset #39
/*      */     //   Java source line #1572	-> byte code offset #42
/*      */     //   Java source line #1573	-> byte code offset #49
/*      */     //   Java source line #1574	-> byte code offset #51
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	52	0	decision	long
/*      */     //   42	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   29	33	42	finally
/*      */   }
/*      */   
/*      */   public static final native int _webkit_web_view_can_go_back(long paramLong);
/*      */   
/*      */   public static final native long _webkit_web_view_get_main_resource(long paramLong);
/*      */   
/*      */   public static final native int _webkit_web_view_can_go_forward(long paramLong);
/*      */   
/*      */   public static final native int _webkit_web_view_can_show_mime_type(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final native void _webkit_web_view_execute_script(long paramLong, byte[] paramArrayOfByte);
/*      */   
/*      */   /* Error */
/*      */   public static final void webkit_web_view_execute_script(long web_view, byte[] script)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 23	org/eclipse/swt/internal/webkit/WebKitGTK:$assertionsDisabled	Z
/*      */     //   3: ifne +19 -> 22
/*      */     //   6: getstatic 77	org/eclipse/swt/internal/webkit/WebKitGTK:WEBKIT1	Z
/*      */     //   9: ifne +13 -> 22
/*      */     //   12: new 25	java/lang/AssertionError
/*      */     //   15: dup
/*      */     //   16: ldc 80
/*      */     //   18: invokespecial 28	java/lang/AssertionError:<init>	(Ljava/lang/Object;)V
/*      */     //   21: athrow
/*      */     //   22: getstatic 4	org/eclipse/swt/internal/webkit/WebKitGTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   28: pop
/*      */     //   29: lload_0
/*      */     //   30: aload_2
/*      */     //   31: invokestatic 136	org/eclipse/swt/internal/webkit/WebKitGTK:_webkit_web_view_execute_script	(J[B)V
/*      */     //   34: getstatic 4	org/eclipse/swt/internal/webkit/WebKitGTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   37: invokevirtual 7	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   40: goto +12 -> 52
/*      */     //   43: astore_3
/*      */     //   44: getstatic 4	org/eclipse/swt/internal/webkit/WebKitGTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   47: invokevirtual 7	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   50: aload_3
/*      */     //   51: athrow
/*      */     //   52: return
/*      */     // Line number table:
/*      */     //   Java source line #1627	-> byte code offset #0
/*      */     //   Java source line #1628	-> byte code offset #22
/*      */     //   Java source line #1630	-> byte code offset #29
/*      */     //   Java source line #1632	-> byte code offset #34
/*      */     //   Java source line #1633	-> byte code offset #40
/*      */     //   Java source line #1632	-> byte code offset #43
/*      */     //   Java source line #1633	-> byte code offset #50
/*      */     //   Java source line #1634	-> byte code offset #52
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	53	0	web_view	long
/*      */     //   0	53	2	script	byte[]
/*      */     //   43	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   29	34	43	finally
/*      */   }
/*      */   
/*      */   public static final native long _webkit_web_view_get_dom_document(long paramLong);
/*      */   
/*      */   public static final native double _webkit_web_view_get_estimated_load_progress(long paramLong);
/*      */   
/*      */   public static final native int _webkit_web_view_get_load_status(long paramLong);
/*      */   
/*      */   public static final native long _webkit_web_view_get_main_frame(long paramLong);
/*      */   
/*      */   public static final native double _webkit_web_view_get_progress(long paramLong);
/*      */   
/*      */   public static final native long _webkit_web_view_get_settings(long paramLong);
/*      */   
/*      */   public static final native long _webkit_web_view_get_title(long paramLong);
/*      */   
/*      */   public static final native long _webkit_web_view_get_type();
/*      */   
/*      */   public static final native long _webkit_web_view_get_uri(long paramLong);
/*      */   
/*      */   public static final native long _webkit_web_view_get_window_features(long paramLong);
/*      */   
/*      */   public static final native long _webkit_web_view_get_window_properties(long paramLong);
/*      */   
/*      */   public static final native void _webkit_window_properties_get_geometry(long paramLong, GdkRectangle paramGdkRectangle);
/*      */   
/*      */   /* Error */
/*      */   public static final void webkit_window_properties_get_geometry(long webKitWindowProperties, GdkRectangle rectangle)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 23	org/eclipse/swt/internal/webkit/WebKitGTK:$assertionsDisabled	Z
/*      */     //   3: ifne +19 -> 22
/*      */     //   6: getstatic 24	org/eclipse/swt/internal/webkit/WebKitGTK:WEBKIT2	Z
/*      */     //   9: ifne +13 -> 22
/*      */     //   12: new 25	java/lang/AssertionError
/*      */     //   15: dup
/*      */     //   16: ldc 27
/*      */     //   18: invokespecial 28	java/lang/AssertionError:<init>	(Ljava/lang/Object;)V
/*      */     //   21: athrow
/*      */     //   22: getstatic 4	org/eclipse/swt/internal/webkit/WebKitGTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   28: pop
/*      */     //   29: lload_0
/*      */     //   30: aload_2
/*      */     //   31: invokestatic 148	org/eclipse/swt/internal/webkit/WebKitGTK:_webkit_window_properties_get_geometry	(JLorg/eclipse/swt/internal/webkit/GdkRectangle;)V
/*      */     //   34: getstatic 4	org/eclipse/swt/internal/webkit/WebKitGTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   37: invokevirtual 7	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   40: goto +12 -> 52
/*      */     //   43: astore_3
/*      */     //   44: getstatic 4	org/eclipse/swt/internal/webkit/WebKitGTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   47: invokevirtual 7	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   50: aload_3
/*      */     //   51: athrow
/*      */     //   52: return
/*      */     // Line number table:
/*      */     //   Java source line #1777	-> byte code offset #0
/*      */     //   Java source line #1778	-> byte code offset #22
/*      */     //   Java source line #1780	-> byte code offset #29
/*      */     //   Java source line #1782	-> byte code offset #34
/*      */     //   Java source line #1783	-> byte code offset #40
/*      */     //   Java source line #1782	-> byte code offset #43
/*      */     //   Java source line #1783	-> byte code offset #50
/*      */     //   Java source line #1784	-> byte code offset #52
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	53	0	webKitWindowProperties	long
/*      */     //   0	53	2	rectangle	GdkRectangle
/*      */     //   43	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   29	34	43	finally
/*      */   }
/*      */   
/*      */   public static final native void _webkit_web_view_go_back(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void webkit_web_view_go_back(long web_view)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 23	org/eclipse/swt/internal/webkit/WebKitGTK:$assertionsDisabled	Z
/*      */     //   3: ifne +23 -> 26
/*      */     //   6: getstatic 77	org/eclipse/swt/internal/webkit/WebKitGTK:WEBKIT1	Z
/*      */     //   9: ifne +17 -> 26
/*      */     //   12: getstatic 24	org/eclipse/swt/internal/webkit/WebKitGTK:WEBKIT2	Z
/*      */     //   15: ifne +11 -> 26
/*      */     //   18: new 25	java/lang/AssertionError
/*      */     //   21: dup
/*      */     //   22: invokespecial 78	java/lang/AssertionError:<init>	()V
/*      */     //   25: athrow
/*      */     //   26: getstatic 4	org/eclipse/swt/internal/webkit/WebKitGTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   29: invokevirtual 5	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   32: pop
/*      */     //   33: lload_0
/*      */     //   34: invokestatic 149	org/eclipse/swt/internal/webkit/WebKitGTK:_webkit_web_view_go_back	(J)V
/*      */     //   37: getstatic 4	org/eclipse/swt/internal/webkit/WebKitGTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   40: invokevirtual 7	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   43: goto +12 -> 55
/*      */     //   46: astore_2
/*      */     //   47: getstatic 4	org/eclipse/swt/internal/webkit/WebKitGTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   50: invokevirtual 7	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   53: aload_2
/*      */     //   54: athrow
/*      */     //   55: return
/*      */     // Line number table:
/*      */     //   Java source line #1791	-> byte code offset #0
/*      */     //   Java source line #1792	-> byte code offset #26
/*      */     //   Java source line #1794	-> byte code offset #33
/*      */     //   Java source line #1796	-> byte code offset #37
/*      */     //   Java source line #1797	-> byte code offset #43
/*      */     //   Java source line #1796	-> byte code offset #46
/*      */     //   Java source line #1797	-> byte code offset #53
/*      */     //   Java source line #1798	-> byte code offset #55
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	56	0	web_view	long
/*      */     //   46	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   33	37	46	finally
/*      */   }
/*      */   
/*      */   public static final native void _webkit_web_view_go_forward(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void webkit_web_view_go_forward(long web_view)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 23	org/eclipse/swt/internal/webkit/WebKitGTK:$assertionsDisabled	Z
/*      */     //   3: ifne +23 -> 26
/*      */     //   6: getstatic 77	org/eclipse/swt/internal/webkit/WebKitGTK:WEBKIT1	Z
/*      */     //   9: ifne +17 -> 26
/*      */     //   12: getstatic 24	org/eclipse/swt/internal/webkit/WebKitGTK:WEBKIT2	Z
/*      */     //   15: ifne +11 -> 26
/*      */     //   18: new 25	java/lang/AssertionError
/*      */     //   21: dup
/*      */     //   22: invokespecial 78	java/lang/AssertionError:<init>	()V
/*      */     //   25: athrow
/*      */     //   26: getstatic 4	org/eclipse/swt/internal/webkit/WebKitGTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   29: invokevirtual 5	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   32: pop
/*      */     //   33: lload_0
/*      */     //   34: invokestatic 150	org/eclipse/swt/internal/webkit/WebKitGTK:_webkit_web_view_go_forward	(J)V
/*      */     //   37: getstatic 4	org/eclipse/swt/internal/webkit/WebKitGTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   40: invokevirtual 7	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   43: goto +12 -> 55
/*      */     //   46: astore_2
/*      */     //   47: getstatic 4	org/eclipse/swt/internal/webkit/WebKitGTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   50: invokevirtual 7	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   53: aload_2
/*      */     //   54: athrow
/*      */     //   55: return
/*      */     // Line number table:
/*      */     //   Java source line #1803	-> byte code offset #0
/*      */     //   Java source line #1804	-> byte code offset #26
/*      */     //   Java source line #1806	-> byte code offset #33
/*      */     //   Java source line #1808	-> byte code offset #37
/*      */     //   Java source line #1809	-> byte code offset #43
/*      */     //   Java source line #1808	-> byte code offset #46
/*      */     //   Java source line #1809	-> byte code offset #53
/*      */     //   Java source line #1810	-> byte code offset #55
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	56	0	web_view	long
/*      */     //   46	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   33	37	46	finally
/*      */   }
/*      */   
/*      */   public static final native void _webkit_web_view_load_html(long paramLong, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2);
/*      */   
/*      */   public static final native void _webkit_web_view_load_bytes(long paramLong1, long paramLong2, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3);
/*      */   
/*      */   public static final native void _webkit_web_view_load_string(long paramLong, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3, byte[] paramArrayOfByte4);
/*      */   
/*      */   public static final native void _webkit_web_view_load_request(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final native void _webkit_web_view_load_uri(long paramLong, byte[] paramArrayOfByte);
/*      */   
/*      */   /* Error */
/*      */   public static final void webkit_web_view_load_uri(long web_view, byte[] uri)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 23	org/eclipse/swt/internal/webkit/WebKitGTK:$assertionsDisabled	Z
/*      */     //   3: ifne +23 -> 26
/*      */     //   6: getstatic 77	org/eclipse/swt/internal/webkit/WebKitGTK:WEBKIT1	Z
/*      */     //   9: ifne +17 -> 26
/*      */     //   12: getstatic 24	org/eclipse/swt/internal/webkit/WebKitGTK:WEBKIT2	Z
/*      */     //   15: ifne +11 -> 26
/*      */     //   18: new 25	java/lang/AssertionError
/*      */     //   21: dup
/*      */     //   22: invokespecial 78	java/lang/AssertionError:<init>	()V
/*      */     //   25: athrow
/*      */     //   26: getstatic 4	org/eclipse/swt/internal/webkit/WebKitGTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   29: invokevirtual 5	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   32: pop
/*      */     //   33: lload_0
/*      */     //   34: aload_2
/*      */     //   35: invokestatic 155	org/eclipse/swt/internal/webkit/WebKitGTK:_webkit_web_view_load_uri	(J[B)V
/*      */     //   38: getstatic 4	org/eclipse/swt/internal/webkit/WebKitGTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   41: invokevirtual 7	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   44: goto +12 -> 56
/*      */     //   47: astore_3
/*      */     //   48: getstatic 4	org/eclipse/swt/internal/webkit/WebKitGTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   51: invokevirtual 7	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   54: aload_3
/*      */     //   55: athrow
/*      */     //   56: return
/*      */     // Line number table:
/*      */     //   Java source line #1863	-> byte code offset #0
/*      */     //   Java source line #1864	-> byte code offset #26
/*      */     //   Java source line #1866	-> byte code offset #33
/*      */     //   Java source line #1868	-> byte code offset #38
/*      */     //   Java source line #1869	-> byte code offset #44
/*      */     //   Java source line #1868	-> byte code offset #47
/*      */     //   Java source line #1869	-> byte code offset #54
/*      */     //   Java source line #1870	-> byte code offset #56
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	57	0	web_view	long
/*      */     //   0	57	2	uri	byte[]
/*      */     //   47	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   33	38	47	finally
/*      */   }
/*      */   
/*      */   public static final native long _webkit_web_view_new();
/*      */   
/*      */   public static final native void _webkit_web_context_set_web_extensions_directory(long paramLong, byte[] paramArrayOfByte);
/*      */   
/*      */   /* Error */
/*      */   public static final void webkit_web_context_set_web_extensions_directory(long context, byte[] directory)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 23	org/eclipse/swt/internal/webkit/WebKitGTK:$assertionsDisabled	Z
/*      */     //   3: ifne +17 -> 20
/*      */     //   6: getstatic 24	org/eclipse/swt/internal/webkit/WebKitGTK:WEBKIT2	Z
/*      */     //   9: ifne +11 -> 20
/*      */     //   12: new 25	java/lang/AssertionError
/*      */     //   15: dup
/*      */     //   16: invokespecial 78	java/lang/AssertionError:<init>	()V
/*      */     //   19: athrow
/*      */     //   20: getstatic 4	org/eclipse/swt/internal/webkit/WebKitGTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   23: invokevirtual 5	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   26: pop
/*      */     //   27: lload_0
/*      */     //   28: aload_2
/*      */     //   29: invokestatic 157	org/eclipse/swt/internal/webkit/WebKitGTK:_webkit_web_context_set_web_extensions_directory	(J[B)V
/*      */     //   32: getstatic 4	org/eclipse/swt/internal/webkit/WebKitGTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   35: invokevirtual 7	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   38: goto +12 -> 50
/*      */     //   41: astore_3
/*      */     //   42: getstatic 4	org/eclipse/swt/internal/webkit/WebKitGTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   45: invokevirtual 7	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   48: aload_3
/*      */     //   49: athrow
/*      */     //   50: return
/*      */     // Line number table:
/*      */     //   Java source line #1888	-> byte code offset #0
/*      */     //   Java source line #1889	-> byte code offset #20
/*      */     //   Java source line #1891	-> byte code offset #27
/*      */     //   Java source line #1893	-> byte code offset #32
/*      */     //   Java source line #1894	-> byte code offset #38
/*      */     //   Java source line #1893	-> byte code offset #41
/*      */     //   Java source line #1894	-> byte code offset #48
/*      */     //   Java source line #1895	-> byte code offset #50
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	51	0	context	long
/*      */     //   0	51	2	directory	byte[]
/*      */     //   41	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   27	32	41	finally
/*      */   }
/*      */   
/*      */   public static final native void _webkit_web_context_set_web_extensions_initialization_user_data(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final native long _webkit_javascript_result_get_global_context(long paramLong);
/*      */   
/*      */   public static final native long _webkit_javascript_result_get_value(long paramLong);
/*      */   
/*      */   public static final native void _webkit_web_view_reload(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void webkit_web_view_reload(long web_view)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 23	org/eclipse/swt/internal/webkit/WebKitGTK:$assertionsDisabled	Z
/*      */     //   3: ifne +23 -> 26
/*      */     //   6: getstatic 77	org/eclipse/swt/internal/webkit/WebKitGTK:WEBKIT1	Z
/*      */     //   9: ifne +17 -> 26
/*      */     //   12: getstatic 24	org/eclipse/swt/internal/webkit/WebKitGTK:WEBKIT2	Z
/*      */     //   15: ifne +11 -> 26
/*      */     //   18: new 25	java/lang/AssertionError
/*      */     //   21: dup
/*      */     //   22: invokespecial 78	java/lang/AssertionError:<init>	()V
/*      */     //   25: athrow
/*      */     //   26: getstatic 4	org/eclipse/swt/internal/webkit/WebKitGTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   29: invokevirtual 5	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   32: pop
/*      */     //   33: lload_0
/*      */     //   34: invokestatic 161	org/eclipse/swt/internal/webkit/WebKitGTK:_webkit_web_view_reload	(J)V
/*      */     //   37: getstatic 4	org/eclipse/swt/internal/webkit/WebKitGTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   40: invokevirtual 7	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   43: goto +12 -> 55
/*      */     //   46: astore_2
/*      */     //   47: getstatic 4	org/eclipse/swt/internal/webkit/WebKitGTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   50: invokevirtual 7	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   53: aload_2
/*      */     //   54: athrow
/*      */     //   55: return
/*      */     // Line number table:
/*      */     //   Java source line #1946	-> byte code offset #0
/*      */     //   Java source line #1947	-> byte code offset #26
/*      */     //   Java source line #1949	-> byte code offset #33
/*      */     //   Java source line #1951	-> byte code offset #37
/*      */     //   Java source line #1952	-> byte code offset #43
/*      */     //   Java source line #1951	-> byte code offset #46
/*      */     //   Java source line #1952	-> byte code offset #53
/*      */     //   Java source line #1953	-> byte code offset #55
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	56	0	web_view	long
/*      */     //   46	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   33	37	46	finally
/*      */   }
/*      */   
/*      */   public static final native void _webkit_web_view_run_javascript(long paramLong1, byte[] paramArrayOfByte, long paramLong2, long paramLong3, long paramLong4);
/*      */   
/*      */   public static final native void _webkit_web_resource_get_data(long paramLong1, long paramLong2, long paramLong3, long paramLong4);
/*      */   
/*      */   public static final native long _webkit_web_resource_get_data_finish(long paramLong1, long paramLong2, long[] paramArrayOfLong1, long[] paramArrayOfLong2);
/*      */   
/*      */   public static final native long _webkit_web_view_run_javascript_finish(long paramLong1, long paramLong2, long[] paramArrayOfLong);
/*      */   
/*      */   public static final native void _webkit_web_view_stop_loading(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void webkit_web_view_stop_loading(long web_view)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 23	org/eclipse/swt/internal/webkit/WebKitGTK:$assertionsDisabled	Z
/*      */     //   3: ifne +23 -> 26
/*      */     //   6: getstatic 77	org/eclipse/swt/internal/webkit/WebKitGTK:WEBKIT1	Z
/*      */     //   9: ifne +17 -> 26
/*      */     //   12: getstatic 24	org/eclipse/swt/internal/webkit/WebKitGTK:WEBKIT2	Z
/*      */     //   15: ifne +11 -> 26
/*      */     //   18: new 25	java/lang/AssertionError
/*      */     //   21: dup
/*      */     //   22: invokespecial 78	java/lang/AssertionError:<init>	()V
/*      */     //   25: athrow
/*      */     //   26: getstatic 4	org/eclipse/swt/internal/webkit/WebKitGTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   29: invokevirtual 5	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   32: pop
/*      */     //   33: lload_0
/*      */     //   34: invokestatic 166	org/eclipse/swt/internal/webkit/WebKitGTK:_webkit_web_view_stop_loading	(J)V
/*      */     //   37: getstatic 4	org/eclipse/swt/internal/webkit/WebKitGTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   40: invokevirtual 7	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   43: goto +12 -> 55
/*      */     //   46: astore_2
/*      */     //   47: getstatic 4	org/eclipse/swt/internal/webkit/WebKitGTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   50: invokevirtual 7	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   53: aload_2
/*      */     //   54: athrow
/*      */     //   55: return
/*      */     // Line number table:
/*      */     //   Java source line #2013	-> byte code offset #0
/*      */     //   Java source line #2014	-> byte code offset #26
/*      */     //   Java source line #2016	-> byte code offset #33
/*      */     //   Java source line #2018	-> byte code offset #37
/*      */     //   Java source line #2019	-> byte code offset #43
/*      */     //   Java source line #2018	-> byte code offset #46
/*      */     //   Java source line #2019	-> byte code offset #53
/*      */     //   Java source line #2020	-> byte code offset #55
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	56	0	web_view	long
/*      */     //   46	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   33	37	46	finally
/*      */   }
/*      */   
/*      */   public static final native void _webkit_website_data_manager_clear(long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5, long paramLong6);
/*      */   
/*      */   public static final native long _webkit_response_policy_decision_get_request(long paramLong);
/*      */   
/*      */   public static final native long _webkit_response_policy_decision_get_response(long paramLong);
/*      */   
/*      */   public static final native long _webkit_uri_request_new(byte[] paramArrayOfByte);
/*      */   
/*      */   public static final native long _webkit_uri_request_get_http_headers(long paramLong);
/*      */   
/*      */   public static final native long _webkit_uri_request_get_uri(long paramLong);
/*      */   
/*      */   public static final native long _webkit_uri_response_get_mime_type(long paramLong);
/*      */   
/*      */   public static final native int JSClassDefinition_sizeof();
/*      */   
/*      */   public static final native int GdkRectangle_sizeof();
/*      */   
/*      */   public static final native void memmove(long paramLong1, JSClassDefinition paramJSClassDefinition, long paramLong2);
/*      */   
/*      */   public static final native long _SoupCookie_expires(long paramLong);
/*      */   
/*      */   public static final native void _SoupMessage_method(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final native long _SoupMessage_request_body(long paramLong);
/*      */   
/*      */   public static final native long _SoupMessage_request_headers(long paramLong);
/*      */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/internal/webkit/WebKitGTK.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */