/*     */ package org.eclipse.swt.program;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.LinkOption;
/*     */ import java.nio.file.Path;
/*     */ import java.nio.file.Paths;
/*     */ import java.nio.file.attribute.FileTime;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.eclipse.swt.SWT;
/*     */ import org.eclipse.swt.graphics.ImageData;
/*     */ import org.eclipse.swt.graphics.PaletteData;
/*     */ import org.eclipse.swt.internal.C;
/*     */ import org.eclipse.swt.internal.Compatibility;
/*     */ import org.eclipse.swt.internal.Converter;
/*     */ import org.eclipse.swt.internal.gtk.GDK;
/*     */ import org.eclipse.swt.internal.gtk.GTK;
/*     */ import org.eclipse.swt.internal.gtk.OS;
/*     */ import org.eclipse.swt.widgets.Display;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Program
/*     */ {
/*  34 */   String name = "";
/*     */   
/*     */ 
/*     */   String command;
/*     */   
/*     */ 
/*     */   String iconPath;
/*     */   
/*     */ 
/*     */   Display display;
/*     */   
/*     */   boolean gioExpectUri;
/*     */   
/*     */   static long modTime;
/*     */   
/*     */   static Map<String, List<String>> mimeTable;
/*     */   
/*     */   static final String PREFIX_HTTP = "http://";
/*     */   
/*     */   static final String PREFIX_HTTPS = "https://";
/*     */   
/*     */ 
/*     */   static String[] parseCommand(String cmd)
/*     */   {
/*  58 */     List<String> args = new ArrayList();
/*  59 */     int sIndex = 0;
/*     */     
/*  61 */     while (sIndex < cmd.length())
/*     */     {
/*  63 */       while ((sIndex < cmd.length()) && (Character.isWhitespace(cmd.charAt(sIndex)))) {
/*  64 */         sIndex++;
/*     */       }
/*  66 */       if (sIndex < cmd.length())
/*     */       {
/*  68 */         if ((cmd.charAt(sIndex) == '"') || (cmd.charAt(sIndex) == '\''))
/*     */         {
/*     */ 
/*     */ 
/*  72 */           int eIndex = sIndex + 1;
/*  73 */           while ((eIndex < cmd.length()) && (cmd.charAt(eIndex) != cmd.charAt(sIndex))) eIndex++;
/*  74 */           if (eIndex >= cmd.length())
/*     */           {
/*     */ 
/*     */ 
/*  78 */             args.add(cmd.substring(sIndex, eIndex));
/*     */           }
/*     */           else {
/*  81 */             args.add(cmd.substring(sIndex + 1, eIndex));
/*     */           }
/*  83 */           sIndex = eIndex + 1;
/*     */         }
/*     */         else
/*     */         {
/*  87 */           int eIndex = sIndex;
/*  88 */           while ((eIndex < cmd.length()) && (!Character.isWhitespace(cmd.charAt(eIndex)))) eIndex++;
/*  89 */           args.add(cmd.substring(sIndex, eIndex));
/*  90 */           sIndex = eIndex + 1;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*  95 */     return (String[])args.toArray(new String[args.size()]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Program findProgram(String extension)
/*     */   {
/* 112 */     return findProgram(Display.getCurrent(), extension);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   static Program findProgram(Display display, String extension)
/*     */   {
/* 120 */     if (extension == null) SWT.error(4);
/* 121 */     if (extension.length() == 0) return null;
/* 122 */     if (extension.charAt(0) != '.') extension = "." + extension;
/* 123 */     String mimeType = gio_getMimeType(extension);
/* 124 */     if (mimeType == null) return null;
/* 125 */     return gio_getProgram(display, mimeType);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Program[] getPrograms()
/*     */   {
/* 136 */     return getPrograms(Display.getCurrent());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ImageData getImageData()
/*     */   {
/* 147 */     if (this.iconPath == null) return null;
/* 148 */     ImageData data = null;
/* 149 */     long icon_theme = GTK.gtk_icon_theme_get_default();
/* 150 */     byte[] icon = Converter.wcsToMbcs(this.iconPath, true);
/* 151 */     long gicon = OS.g_icon_new_for_string(icon, null);
/* 152 */     if (gicon != 0L) {
/* 153 */       long gicon_info = GTK.gtk_icon_theme_lookup_by_gicon(icon_theme, gicon, 16, 0);
/* 154 */       if (gicon_info != 0L) {
/* 155 */         long pixbuf = GTK.gtk_icon_info_load_icon(gicon_info, null);
/* 156 */         if (pixbuf != 0L) {
/* 157 */           int stride = GDK.gdk_pixbuf_get_rowstride(pixbuf);
/* 158 */           long pixels = GDK.gdk_pixbuf_get_pixels(pixbuf);
/* 159 */           int height = GDK.gdk_pixbuf_get_height(pixbuf);
/* 160 */           int width = GDK.gdk_pixbuf_get_width(pixbuf);
/* 161 */           boolean hasAlpha = GDK.gdk_pixbuf_get_has_alpha(pixbuf);
/* 162 */           byte[] srcData = new byte[stride * height];
/* 163 */           C.memmove(srcData, pixels, srcData.length);
/* 164 */           OS.g_object_unref(pixbuf);
/* 165 */           if (hasAlpha) {
/* 166 */             PaletteData palette = new PaletteData(-16777216, 16711680, 65280);
/* 167 */             data = new ImageData(width, height, 32, palette, 4, srcData);
/* 168 */             data.bytesPerLine = stride;
/* 169 */             int s = 3;int a = 0;
/* 170 */             byte[] alphaData = new byte[width * height];
/* 171 */             for (int y = 0; y < height; y++) {
/* 172 */               for (int x = 0; x < width; x++) {
/* 173 */                 alphaData[(a++)] = srcData[s];
/* 174 */                 srcData[s] = 0;
/* 175 */                 s += 4;
/*     */               }
/*     */             }
/* 178 */             data.alphaData = alphaData;
/*     */           } else {
/* 180 */             PaletteData palette = new PaletteData(16711680, 65280, 255);
/* 181 */             data = new ImageData(width, height, 24, palette, 4, srcData);
/* 182 */             data.bytesPerLine = stride;
/*     */           }
/*     */         }
/* 185 */         if (GTK.GTK_VERSION >= OS.VERSION(3, 8, 0)) {
/* 186 */           OS.g_object_unref(gicon_info);
/*     */         } else {
/* 188 */           GTK.gtk_icon_info_free(gicon_info);
/*     */         }
/*     */       }
/* 191 */       OS.g_object_unref(gicon);
/*     */     }
/* 193 */     return data;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static Map<String, List<String>> gio_getMimeInfo()
/*     */   {
/* 203 */     Path path = Paths.get("/usr/share/mime/globs", new String[0]);
/* 204 */     long lastModified = 0L;
/*     */     try {
/* 206 */       lastModified = Files.getLastModifiedTime(path, new LinkOption[0]).toMillis();
/*     */     }
/*     */     catch (IOException localIOException) {}
/*     */     
/* 210 */     if ((modTime != 0L) && (modTime == lastModified)) {
/* 211 */       return mimeTable;
/*     */     }
/*     */     try {
/* 214 */       mimeTable = new HashMap();
/* 215 */       modTime = lastModified;
/* 216 */       for (String line : Files.readAllLines(path)) {
/* 217 */         int separatorIndex = line.indexOf(':');
/* 218 */         if (separatorIndex > 0) {
/* 219 */           List<String> mimeTypes = new ArrayList();
/* 220 */           String mimeType = line.substring(0, separatorIndex);
/* 221 */           String extensionFormat = line.substring(separatorIndex + 1);
/* 222 */           int extensionIndex = extensionFormat.indexOf(".");
/* 223 */           if (extensionIndex > 0) {
/* 224 */             String extension = extensionFormat.substring(extensionIndex);
/* 225 */             if (mimeTable.containsKey(extension))
/*     */             {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 231 */               List<String> value = (List)mimeTable.get(extension);
/* 232 */               mimeTypes.addAll(value);
/*     */             }
/* 234 */             mimeTypes.add(mimeType);
/* 235 */             mimeTable.put(extension, mimeTypes);
/*     */           }
/*     */         }
/*     */       }
/* 239 */       return mimeTable;
/*     */     }
/*     */     catch (IOException localIOException1) {}
/*     */     
/* 243 */     return null;
/*     */   }
/*     */   
/*     */   static String gio_getMimeType(String extension) {
/* 247 */     String mimeType = null;
/* 248 */     Map<String, List<String>> h = gio_getMimeInfo();
/* 249 */     if ((h != null) && (h.containsKey(extension))) {
/* 250 */       List<String> mimeTypes = (List)h.get(extension);
/* 251 */       mimeType = (String)mimeTypes.get(0);
/*     */     }
/* 253 */     return mimeType;
/*     */   }
/*     */   
/*     */   static Program gio_getProgram(Display display, String mimeType) {
/* 257 */     Program program = null;
/* 258 */     byte[] mimeTypeBuffer = Converter.wcsToMbcs(mimeType, true);
/* 259 */     long application = OS.g_app_info_get_default_for_type(mimeTypeBuffer, false);
/* 260 */     if (application != 0L) {
/* 261 */       program = gio_getProgram(display, application);
/*     */     }
/* 263 */     return program;
/*     */   }
/*     */   
/*     */   static Program gio_getProgram(Display display, long application) {
/* 267 */     Program program = new Program();
/* 268 */     program.display = display;
/*     */     
/*     */ 
/* 271 */     long applicationName = OS.g_app_info_get_name(application);
/* 272 */     if (applicationName != 0L) {
/* 273 */       int length = C.strlen(applicationName);
/* 274 */       if (length > 0) {
/* 275 */         byte[] buffer = new byte[length];
/* 276 */         C.memmove(buffer, applicationName, length);
/* 277 */         program.name = new String(Converter.mbcsToWcs(buffer));
/*     */       }
/*     */     }
/* 280 */     long applicationCommand = OS.g_app_info_get_executable(application);
/* 281 */     if (applicationCommand != 0L) {
/* 282 */       int length = C.strlen(applicationCommand);
/* 283 */       if (length > 0) {
/* 284 */         byte[] buffer = new byte[length];
/* 285 */         C.memmove(buffer, applicationCommand, length);
/* 286 */         program.command = new String(Converter.mbcsToWcs(buffer));
/*     */       }
/*     */     }
/* 289 */     program.gioExpectUri = OS.g_app_info_supports_uris(application);
/* 290 */     long icon = OS.g_app_info_get_icon(application);
/* 291 */     if (icon != 0L) {
/* 292 */       long icon_name = OS.g_icon_to_string(icon);
/* 293 */       if (icon_name != 0L) {
/* 294 */         int length = C.strlen(icon_name);
/* 295 */         if (length > 0) {
/* 296 */           byte[] buffer = new byte[length];
/* 297 */           C.memmove(buffer, icon_name, length);
/* 298 */           program.iconPath = new String(Converter.mbcsToWcs(buffer));
/*     */         }
/* 300 */         OS.g_free(icon_name);
/*     */       }
/* 302 */       OS.g_object_unref(icon);
/*     */     }
/* 304 */     return program.command != null ? program : null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   static Program[] getPrograms(Display display)
/*     */   {
/* 312 */     long applicationList = OS.g_app_info_get_all();
/* 313 */     long list = applicationList;
/*     */     
/* 315 */     LinkedHashSet<Program> programs = new LinkedHashSet();
/* 316 */     while (list != 0L) {
/* 317 */       long application = OS.g_list_data(list);
/* 318 */       if (application != 0L)
/*     */       {
/*     */ 
/* 321 */         Program program = gio_getProgram(display, application);
/* 322 */         if (program != null) { programs.add(program);
/*     */         }
/*     */       }
/* 325 */       list = OS.g_list_next(list);
/*     */     }
/* 327 */     if (applicationList != 0L) OS.g_list_free(applicationList);
/* 328 */     return (Program[])programs.toArray(new Program[programs.size()]);
/*     */   }
/*     */   
/*     */   static boolean isExecutable(String fileName) {
/* 332 */     byte[] fileNameBuffer = Converter.wcsToMbcs(fileName, true);
/* 333 */     if (OS.g_file_test(fileNameBuffer, 4)) return false;
/* 334 */     if (!OS.g_file_test(fileNameBuffer, 8)) return false;
/* 335 */     long file = OS.g_file_new_for_path(fileNameBuffer);
/* 336 */     boolean result = false;
/* 337 */     if (file != 0L) {
/* 338 */       byte[] buffer = Converter.wcsToMbcs("*", true);
/* 339 */       long fileInfo = OS.g_file_query_info(file, buffer, 0L, 0L, 0L);
/* 340 */       if (fileInfo != 0L) {
/* 341 */         long contentType = OS.g_file_info_get_content_type(fileInfo);
/* 342 */         if (contentType != 0L) {
/* 343 */           byte[] exeType = Converter.wcsToMbcs("application/x-executable", true);
/* 344 */           result = OS.g_content_type_is_a(contentType, exeType);
/* 345 */           if (!result) {
/* 346 */             byte[] shellType = Converter.wcsToMbcs("application/x-shellscript", true);
/* 347 */             result = OS.g_content_type_equals(contentType, shellType);
/*     */           }
/*     */         }
/* 350 */         OS.g_object_unref(fileInfo);
/*     */       }
/* 352 */       OS.g_object_unref(file);
/*     */     }
/* 354 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   static boolean gio_launch(String fileName)
/*     */   {
/* 361 */     boolean result = false;
/* 362 */     byte[] fileNameBuffer = Converter.wcsToMbcs(fileName, true);
/* 363 */     long file = OS.g_file_new_for_commandline_arg(fileNameBuffer);
/* 364 */     if (file != 0L) {
/* 365 */       long uri = OS.g_file_get_uri(file);
/* 366 */       if (uri != 0L) {
/* 367 */         result = OS.g_app_info_launch_default_for_uri(uri, 0L, 0L);
/* 368 */         OS.g_free(uri);
/*     */       }
/* 370 */       OS.g_object_unref(file);
/*     */     }
/* 372 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   boolean gio_execute(String fileName)
/*     */   {
/* 379 */     boolean result = false;
/* 380 */     byte[] commandBuffer = Converter.wcsToMbcs(this.command, true);
/* 381 */     byte[] nameBuffer = Converter.wcsToMbcs(this.name, true);
/* 382 */     long application = OS.g_app_info_create_from_commandline(commandBuffer, nameBuffer, this.gioExpectUri ? 2L : 0L, 0L);
/*     */     
/* 384 */     if (application != 0L) {
/* 385 */       byte[] fileNameBuffer = Converter.wcsToMbcs(fileName, true);
/* 386 */       long file = 0L;
/* 387 */       if (fileName.length() > 0) {
/* 388 */         if (OS.g_app_info_supports_uris(application)) {
/* 389 */           file = OS.g_file_new_for_uri(fileNameBuffer);
/*     */         } else {
/* 391 */           file = OS.g_file_new_for_path(fileNameBuffer);
/*     */         }
/*     */       }
/* 394 */       long list = 0L;
/* 395 */       if (file != 0L) list = OS.g_list_append(0L, file);
/* 396 */       result = OS.g_app_info_launch(application, list, 0L, 0L);
/* 397 */       if (list != 0L) {
/* 398 */         OS.g_list_free(list);
/* 399 */         OS.g_object_unref(file);
/*     */       }
/* 401 */       OS.g_object_unref(application);
/*     */     }
/* 403 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String[] getExtensions()
/*     */   {
/* 414 */     Map<String, List<String>> mimeInfo = gio_getMimeInfo();
/* 415 */     if (mimeInfo == null) { return new String[0];
/*     */     }
/* 417 */     List<String> extensions = new ArrayList(mimeInfo.keySet());
/*     */     
/* 419 */     return (String[])extensions.toArray(new String[extensions.size()]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean launch(String fileName)
/*     */   {
/* 436 */     return launch(Display.getCurrent(), fileName, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean launch(String fileName, String workingDir)
/*     */   {
/* 459 */     return launch(Display.getCurrent(), fileName, workingDir);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   static boolean launch(Display display, String fileName, String workingDir)
/*     */   {
/* 467 */     if (fileName == null) SWT.error(4);
/* 468 */     if ((workingDir != null) && (isExecutable(fileName))) {
/*     */       try {
/* 470 */         Compatibility.exec(new String[] { fileName }, null, workingDir);
/* 471 */         return true;
/*     */       } catch (IOException e) {
/* 473 */         return false;
/*     */       }
/*     */     }
/* 476 */     if (gio_launch(fileName)) return true;
/* 477 */     int index = fileName.lastIndexOf('.');
/* 478 */     if (index != -1) {
/* 479 */       String extension = fileName.substring(index);
/* 480 */       Program program = findProgram(display, extension);
/* 481 */       if ((program != null) && (program.execute(fileName))) return true;
/*     */     }
/* 483 */     String lowercaseName = fileName.toLowerCase();
/* 484 */     if ((lowercaseName.startsWith("http://")) || (lowercaseName.startsWith("https://"))) {
/* 485 */       Program program = findProgram(display, ".html");
/* 486 */       if (program == null) {
/* 487 */         program = findProgram(display, ".htm");
/*     */       }
/* 489 */       if ((program != null) && (program.execute(fileName))) return true;
/*     */     }
/*     */     try
/*     */     {
/* 493 */       Compatibility.exec(new String[] { fileName }, null, workingDir);
/* 494 */       return true;
/*     */     } catch (IOException e) {}
/* 496 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object other)
/*     */   {
/* 512 */     if (this == other) return true;
/* 513 */     if (!(other instanceof Program)) return false;
/* 514 */     Program program = (Program)other;
/* 515 */     return (this.display == program.display) && (this.name.equals(program.name)) && (this.command.equals(program.command)) && (this.gioExpectUri == program.gioExpectUri);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean execute(String fileName)
/*     */   {
/* 533 */     if (fileName == null) SWT.error(4);
/* 534 */     return gio_execute(fileName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getName()
/*     */   {
/* 546 */     return this.name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 561 */     return this.name.hashCode() ^ this.command.hashCode();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 572 */     return "Program {" + this.name + "}";
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/program/Program.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */