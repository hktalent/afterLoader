/*     */ package org.eclipse.swt.graphics;
/*     */ 
/*     */ import org.eclipse.swt.SWT;
/*     */ import org.eclipse.swt.internal.DPIUtil;
/*     */ import org.eclipse.swt.internal.cairo.Cairo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Pattern
/*     */   extends Resource
/*     */ {
/*     */   public long handle;
/*     */   long surface;
/*     */   
/*     */   public Pattern(Device device, Image image)
/*     */   {
/*  83 */     super(device);
/*  84 */     if (image == null) SWT.error(4);
/*  85 */     if (image.isDisposed()) SWT.error(5);
/*  86 */     image.createSurface();
/*  87 */     this.handle = Cairo.cairo_pattern_create_for_surface(image.surface);
/*  88 */     if (this.handle == 0L) SWT.error(2);
/*  89 */     Cairo.cairo_pattern_set_extend(this.handle, 1);
/*  90 */     this.surface = image.surface;
/*  91 */     init();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Pattern(Device device, float x1, float y1, float x2, float y2, Color color1, Color color2)
/*     */   {
/* 130 */     this(device, x1, y1, x2, y2, color1, 255, color2, 255);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Pattern(Device device, float x1, float y1, float x2, float y2, Color color1, int alpha1, Color color2, int alpha2)
/*     */   {
/* 172 */     super(device);
/* 173 */     x1 = DPIUtil.autoScaleUp(x1);
/* 174 */     y1 = DPIUtil.autoScaleUp(y1);
/* 175 */     x2 = DPIUtil.autoScaleUp(x2);
/* 176 */     y2 = DPIUtil.autoScaleUp(y2);
/* 177 */     if (color1 == null) SWT.error(4);
/* 178 */     if (color1.isDisposed()) SWT.error(5);
/* 179 */     if (color2 == null) SWT.error(4);
/* 180 */     if (color2.isDisposed()) SWT.error(5);
/* 181 */     this.handle = Cairo.cairo_pattern_create_linear(x1, y1, x2, y2);
/* 182 */     if (this.handle == 0L) SWT.error(2);
/* 183 */     GC.setCairoPatternColor(this.handle, 0, color1, alpha1);
/* 184 */     GC.setCairoPatternColor(this.handle, 1, color2, alpha2);
/* 185 */     Cairo.cairo_pattern_set_extend(this.handle, 1);
/* 186 */     init();
/*     */   }
/*     */   
/*     */   void destroy()
/*     */   {
/* 191 */     Cairo.cairo_pattern_destroy(this.handle);
/* 192 */     this.handle = (this.surface = 0L);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isDisposed()
/*     */   {
/* 207 */     return this.handle == 0L;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 218 */     if (isDisposed()) return "Pattern {*DISPOSED*}";
/* 219 */     return "Pattern {" + this.handle + "}";
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/graphics/Pattern.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */