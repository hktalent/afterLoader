/*    */ package org.eclipse.swt.internal.image;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import org.eclipse.swt.SWT;
/*    */ import org.eclipse.swt.graphics.ImageData;
/*    */ import org.eclipse.swt.graphics.ImageLoader;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class TIFFFileFormat
/*    */   extends FileFormat
/*    */ {
/*    */   boolean isFileFormat(LEDataInputStream stream)
/*    */   {
/*    */     try
/*    */     {
/* 27 */       byte[] header = new byte[4];
/* 28 */       stream.read(header);
/* 29 */       stream.unread(header);
/* 30 */       if (header[0] != header[1]) return false;
/* 31 */       if (((header[0] != 73) || (header[2] != 42) || (header[3] != 0)) && ((header[0] != 77) || (header[2] != 0) || (header[3] != 42)))
/*    */       {
/* 33 */         return false;
/*    */       }
/* 35 */       return true;
/*    */     } catch (Exception e) {}
/* 37 */     return false;
/*    */   }
/*    */   
/*    */ 
/*    */   ImageData[] loadFromByteStream()
/*    */   {
/* 43 */     byte[] header = new byte[8];
/*    */     
/* 45 */     ImageData[] images = new ImageData[0];
/* 46 */     TIFFRandomFileAccess file = new TIFFRandomFileAccess(this.inputStream);
/*    */     try {
/* 48 */       file.read(header);
/* 49 */       if (header[0] != header[1]) SWT.error(40);
/* 50 */       if (((header[0] != 73) || (header[2] != 42) || (header[3] != 0)) && ((header[0] != 77) || (header[2] != 0) || (header[3] != 42)))
/*    */       {
/* 52 */         SWT.error(40);
/*    */       }
/* 54 */       boolean isLittleEndian = header[0] == 73;
/* 55 */       int offset = isLittleEndian ? header[4] & 0xFF | (header[5] & 0xFF) << 8 | (header[6] & 0xFF) << 16 | (header[7] & 0xFF) << 24 : header[7] & 0xFF | (header[6] & 0xFF) << 8 | (header[5] & 0xFF) << 16 | (header[4] & 0xFF) << 24;
/*    */       
/*    */ 
/* 58 */       while (offset != 0) {
/* 59 */         file.seek(offset);
/* 60 */         TIFFDirectory directory = new TIFFDirectory(file, isLittleEndian, this.loader);
/* 61 */         int[] nextIFDOffset = new int[1];
/* 62 */         ImageData image = directory.read(nextIFDOffset);
/* 63 */         offset = nextIFDOffset[0];
/* 64 */         ImageData[] oldImages = images;
/* 65 */         images = new ImageData[oldImages.length + 1];
/* 66 */         System.arraycopy(oldImages, 0, images, 0, oldImages.length);
/* 67 */         images[(images.length - 1)] = image;
/*    */       }
/*    */     } catch (IOException e) {
/* 70 */       SWT.error(39, e);
/*    */     }
/* 72 */     return images;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   void unloadIntoByteStream(ImageLoader loader)
/*    */   {
/* 79 */     ImageData image = loader.data[0];
/* 80 */     TIFFDirectory directory = new TIFFDirectory(image);
/*    */     try {
/* 82 */       directory.writeToStream(this.outputStream);
/*    */     } catch (IOException e) {
/* 84 */       SWT.error(39, e);
/*    */     }
/*    */   }
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/internal/image/TIFFFileFormat.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */