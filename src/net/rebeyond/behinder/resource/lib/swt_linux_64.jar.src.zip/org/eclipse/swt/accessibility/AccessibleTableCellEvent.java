/*    */ package org.eclipse.swt.accessibility;
/*    */ 
/*    */ import java.util.EventObject;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AccessibleTableCellEvent
/*    */   extends EventObject
/*    */ {
/*    */   public Accessible accessible;
/*    */   public Accessible[] accessibles;
/*    */   public boolean isSelected;
/*    */   public int count;
/*    */   public int index;
/*    */   static final long serialVersionUID = 7231059449172889781L;
/*    */   
/*    */   public AccessibleTableCellEvent(Object source)
/*    */   {
/* 40 */     super(source);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String toString()
/*    */   {
/* 51 */     return "AccessibleTableCellEvent { accessibles=" + this.accessibles + " isSelected=" + this.isSelected + " count=" + this.count + " index=" + this.index + "}";
/*    */   }
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/accessibility/AccessibleTableCellEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */