package org.eclipse.swt.dnd;

import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.widgets.Event;

class DNDEvent
  extends Event
{
  public TransferData dataType;
  public TransferData[] dataTypes;
  public int operations;
  public int feedback;
  public Image image;
  public int offsetX;
  public int offsetY;
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/dnd/DNDEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */