/*     */ package org.eclipse.swt.browser;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import org.eclipse.swt.SWT;
/*     */ import org.eclipse.swt.SWTException;
/*     */ import org.eclipse.swt.internal.Callback;
/*     */ import org.eclipse.swt.internal.Converter;
/*     */ import org.eclipse.swt.internal.gtk.OS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class WebkitGDBus
/*     */ {
/*     */   private static String DBUS_SERVICE_NAME;
/*     */   private static final String DBUS_OBJECT_NAME = "/org/eclipse/swt/gdbus";
/*     */   private static final String INTERFACE_NAME = "org.eclipse.swt.gdbusInterface";
/*     */   private static final String webkit2callJava;
/*     */   private static final String dbus_introspection_xml;
/*     */   private static final byte SWT_DBUS_MAGIC_NUMBER_EMPTY_ARRAY = 101;
/*     */   private static final byte SWT_DBUS_MAGIC_NUMBER_NULL = 48;
/*     */   private static Callback onBusAcquiredCallback;
/*     */   private static Callback onNameAcquiredCallback;
/*     */   private static Callback onNameLostCallback;
/*     */   private static Callback handleMethodCallback;
/*     */   private static boolean initialized;
/*     */   
/*     */   static
/*     */   {
/*  40 */     webkit2callJava = WebKit.Webkit2Extension.getJavaScriptFunctionName();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  70 */     dbus_introspection_xml = "<node>  <interface name='org.eclipse.swt.gdbusInterface'>    <method name='" + webkit2callJava + "'>      <arg type='" + "s" + "' name='webViewPtr' direction='in'/>      <arg type='" + "d" + "' name='index' direction='in'/>      <arg type='" + "s" + "' name='token' direction='in'/>      <arg type='" + "*" + "' name='arguments' direction='in'/>      <arg type='" + "*" + "' name='result' direction='out'/>    </method>  </interface></node>";
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 100 */     onBusAcquiredCallback = new Callback(WebkitGDBus.class, "onBusAcquiredCallback", 3);
/* 101 */     if (onBusAcquiredCallback.getAddress() == 0L) { SWT.error(3);
/*     */     }
/* 103 */     onNameAcquiredCallback = new Callback(WebkitGDBus.class, "onNameAcquiredCallback", 3);
/* 104 */     if (onNameAcquiredCallback.getAddress() == 0L) { SWT.error(3);
/*     */     }
/* 106 */     onNameLostCallback = new Callback(WebkitGDBus.class, "onNameLostCallback", 3);
/* 107 */     if (onNameLostCallback.getAddress() == 0L) { SWT.error(3);
/*     */     }
/* 109 */     handleMethodCallback = new Callback(WebkitGDBus.class, "handleMethodCallback", 8);
/* 110 */     if (handleMethodCallback.getAddress() == 0L) { SWT.error(3);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   static void init(String uniqueId)
/*     */   {
/* 117 */     if (initialized)
/* 118 */       return;
/* 119 */     initialized = true;
/* 120 */     DBUS_SERVICE_NAME = "org.eclipse.swt" + uniqueId;
/* 121 */     int owner_id = OS.g_bus_own_name(2, 
/* 122 */       Converter.javaStringToCString(DBUS_SERVICE_NAME), 3, onBusAcquiredCallback
/*     */       
/* 124 */       .getAddress(), onNameAcquiredCallback
/* 125 */       .getAddress(), onNameLostCallback
/* 126 */       .getAddress(), 0L, 0L);
/*     */     
/*     */ 
/*     */ 
/* 130 */     if (owner_id == 0) {
/* 131 */       System.err.println("SWT WebkitGDBus: Failed to aquire bus name: " + DBUS_SERVICE_NAME);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static long onBusAcquiredCallback(long connection, long name, long user_data)
/*     */   {
/* 155 */     long[] error = new long[1];
/* 156 */     long gdBusNodeInfo = OS.g_dbus_node_info_new_for_xml(Converter.javaStringToCString(dbus_introspection_xml), error);
/* 157 */     if ((gdBusNodeInfo == 0L) || (error[0] != 0L)) {
/* 158 */       System.err.println("SWT WebkitGDBus: Failed to get introspection data");
/*     */     }
/* 160 */     assert (gdBusNodeInfo != 0L) : "SWT WebkitGDBus: introspection data should not be 0";
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 165 */     long[] error = new long[1];
/* 166 */     long interface_info = OS.g_dbus_node_info_lookup_interface(gdBusNodeInfo, Converter.javaStringToCString("org.eclipse.swt.gdbusInterface"));
/* 167 */     long[] vtable = { handleMethodCallback.getAddress(), 0L, 0L };
/*     */     
/*     */ 
/* 170 */     OS.g_dbus_connection_register_object(connection, 
/*     */     
/* 172 */       Converter.javaStringToCString("/org/eclipse/swt/gdbus"), interface_info, vtable, 0L, 0L, error);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 179 */     if (error[0] != 0L) {
/* 180 */       System.err.println("SWT WebkitGDBus: Failed to register object: /org/eclipse/swt/gdbus");
/* 181 */       return 0L;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 192 */     return 0L;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static long onNameAcquiredCallback(long connection, long name, long user_data)
/*     */   {
/* 199 */     return 0L;
/*     */   }
/*     */   
/*     */ 
/*     */   private static long onNameLostCallback(long connection, long name, long user_data)
/*     */   {
/* 205 */     if (!$assertionsDisabled) throw new AssertionError("This code should never have executed");
/* 206 */     System.err.println("SWT WebkitGDBus.java: Lost GDBus name. This should never occur");
/* 207 */     return 0L;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static long handleMethodCallback(long connection, long sender, long object_path, long interface_name, long method_name, long gvar_parameters, long invocation, long user_data)
/*     */   {
/* 237 */     String java_method_name = Converter.cCharPtrToJavaString(method_name, false);
/* 238 */     Object result = null;
/* 239 */     if ((java_method_name != null) && (java_method_name.equals(webkit2callJava))) {
/*     */       try {
/* 241 */         Object[] java_parameters = (Object[])convertGVariantToJava(gvar_parameters);
/* 242 */         result = WebKit.Webkit2Extension.webkit2callJavaCallback(java_parameters);
/*     */       }
/*     */       catch (Exception e) {
/* 245 */         result = WebBrowser.CreateErrorString(e.getLocalizedMessage());
/* 246 */         System.err.println("SWT Webkit: Exception occured in Webkit2 callback logic. Bug?");
/*     */       }
/*     */     } else {
/* 249 */       result = "SWT Webkit: Gdbus called an unknown method?";
/* 250 */       System.err.println("SWT WebkitGDBus: Received a call from an unknown method: " + java_method_name);
/*     */     }
/* 252 */     long resultGVariant = 0L;
/*     */     try {
/* 254 */       resultGVariant = convertJavaToGVariant(new Object[] { result });
/*     */     }
/*     */     catch (SWTException e) {
/* 257 */       String errMsg = WebBrowser.CreateErrorString(e.getLocalizedMessage());
/* 258 */       resultGVariant = convertJavaToGVariant(new Object[] { errMsg });
/*     */     }
/* 260 */     OS.g_dbus_method_invocation_return_value(invocation, resultGVariant);
/* 261 */     return 0L;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Object convertGVariantToJava(long gVariant)
/*     */   {
/* 294 */     if (OS.g_variant_is_of_type(gVariant, OS.G_VARIANT_TYPE_BOOLEAN)) {
/* 295 */       return new Boolean(OS.g_variant_get_boolean(gVariant));
/*     */     }
/*     */     
/*     */ 
/* 299 */     if (OS.g_variant_is_of_type(gVariant, OS.G_VARIANT_TYPE_BYTE)) {
/* 300 */       byte byteVal = OS.g_variant_get_byte(gVariant);
/*     */       
/* 302 */       switch (byteVal) {
/*     */       case 48: 
/* 304 */         return null;
/*     */       case 101: 
/* 306 */         return new Object[0];
/*     */       }
/* 308 */       System.err.println("SWT Error, received unsupported byte type via gdbus: " + byteVal);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 313 */     if (OS.g_variant_is_of_type(gVariant, OS.G_VARIANT_TYPE_DOUBLE)) {
/* 314 */       return new Double(OS.g_variant_get_double(gVariant));
/*     */     }
/*     */     
/* 317 */     if (OS.g_variant_is_of_type(gVariant, OS.G_VARIANT_TYPE_STRING)) {
/* 318 */       return Converter.cCharPtrToJavaString(OS.g_variant_get_string(gVariant, null), false);
/*     */     }
/*     */     
/* 321 */     if (OS.g_variant_is_of_type(gVariant, OS.G_VARIANT_TYPE_TUPLE)) {
/* 322 */       int length = (int)OS.g_variant_n_children(gVariant);
/* 323 */       Object[] result = new Object[length];
/* 324 */       for (int i = 0; i < length; i++) {
/* 325 */         result[i] = convertGVariantToJava(OS.g_variant_get_child_value(gVariant, i));
/*     */       }
/* 327 */       return result;
/*     */     }
/*     */     
/* 330 */     String typeString = Converter.cCharPtrToJavaString(OS.g_variant_get_type_string(gVariant), false);
/* 331 */     SWT.error(5, new Throwable("Unhandled variant type " + typeString));
/* 332 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static long convertJavaToGVariant(Object javaObject)
/*     */     throws SWTException
/*     */   {
/* 345 */     if (javaObject == null) {
/* 346 */       return OS.g_variant_new_byte((byte)48);
/*     */     }
/*     */     
/* 349 */     if ((javaObject instanceof String)) {
/* 350 */       return OS.g_variant_new_string(Converter.javaStringToCString((String)javaObject));
/*     */     }
/*     */     
/* 353 */     if ((javaObject instanceof Boolean)) {
/* 354 */       return OS.g_variant_new_boolean(((Boolean)javaObject).booleanValue());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 359 */     if ((javaObject instanceof Number)) {
/* 360 */       return OS.g_variant_new_double(((Number)javaObject).doubleValue());
/*     */     }
/*     */     
/* 363 */     if ((javaObject instanceof Object[])) {
/* 364 */       Object[] arrayValue = (Object[])javaObject;
/* 365 */       int length = arrayValue.length;
/*     */       
/* 367 */       if (length == 0) {
/* 368 */         return OS.g_variant_new_byte((byte)101);
/*     */       }
/*     */       
/* 371 */       long[] variants = new long[length];
/*     */       
/* 373 */       for (int i = 0; i < length; i++) {
/* 374 */         variants[i] = convertJavaToGVariant(arrayValue[i]);
/*     */       }
/*     */       
/* 377 */       return OS.g_variant_new_tuple(variants, length);
/*     */     }
/* 379 */     System.err.println("SWT Webkit: Invalid object being returned to javascript: " + javaObject.toString() + "\nOnly the following are supported: null, String, Boolean, Number(Long,Integer,Double...), Object[] of basic types");
/*     */     
/* 381 */     throw new SWTException(5, "Given object is not valid: " + javaObject.toString());
/*     */   }
/*     */   
/*     */   private static void teardown_gdbus() {}
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/browser/WebkitGDBus.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */