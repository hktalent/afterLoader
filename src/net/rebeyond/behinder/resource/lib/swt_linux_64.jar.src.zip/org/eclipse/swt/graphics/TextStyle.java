/*     */ package org.eclipse.swt.graphics;
/*     */ 
/*     */ import org.eclipse.swt.SWT;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TextStyle
/*     */ {
/*     */   public Font font;
/*     */   public Color foreground;
/*     */   public Color background;
/*     */   public boolean underline;
/*     */   public Color underlineColor;
/*     */   public int underlineStyle;
/*     */   public boolean strikeout;
/*     */   public Color strikeoutColor;
/*     */   public int borderStyle;
/*     */   public Color borderColor;
/*     */   public GlyphMetrics metrics;
/*     */   public int rise;
/*     */   public Object data;
/*     */   
/*     */   public TextStyle() {}
/*     */   
/*     */   public TextStyle(Font font, Color foreground, Color background)
/*     */   {
/* 170 */     if ((font != null) && (font.isDisposed())) SWT.error(5);
/* 171 */     if ((foreground != null) && (foreground.isDisposed())) SWT.error(5);
/* 172 */     if ((background != null) && (background.isDisposed())) SWT.error(5);
/* 173 */     this.font = font;
/* 174 */     this.foreground = foreground;
/* 175 */     this.background = background;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TextStyle(TextStyle style)
/*     */   {
/* 187 */     if (style == null) SWT.error(5);
/* 188 */     this.font = style.font;
/* 189 */     this.foreground = style.foreground;
/* 190 */     this.background = style.background;
/* 191 */     this.underline = style.underline;
/* 192 */     this.underlineColor = style.underlineColor;
/* 193 */     this.underlineStyle = style.underlineStyle;
/* 194 */     this.strikeout = style.strikeout;
/* 195 */     this.strikeoutColor = style.strikeoutColor;
/* 196 */     this.borderStyle = style.borderStyle;
/* 197 */     this.borderColor = style.borderColor;
/* 198 */     this.metrics = style.metrics;
/* 199 */     this.rise = style.rise;
/* 200 */     this.data = style.data;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object object)
/*     */   {
/* 215 */     if (object == this) return true;
/* 216 */     if (object == null) return false;
/* 217 */     if (!(object instanceof TextStyle)) return false;
/* 218 */     TextStyle style = (TextStyle)object;
/* 219 */     if (this.foreground != null) {
/* 220 */       if (!this.foreground.equals(style.foreground)) return false;
/* 221 */     } else if (style.foreground != null) return false;
/* 222 */     if (this.background != null) {
/* 223 */       if (!this.background.equals(style.background)) return false;
/* 224 */     } else if (style.background != null) return false;
/* 225 */     if (this.font != null) {
/* 226 */       if (!this.font.equals(style.font)) return false;
/* 227 */     } else if (style.font != null) return false;
/* 228 */     if (this.metrics != null) {
/* 229 */       if (!this.metrics.equals(style.metrics)) return false;
/* 230 */     } else if (style.metrics != null) return false;
/* 231 */     if (this.underline != style.underline) return false;
/* 232 */     if (this.underlineStyle != style.underlineStyle) return false;
/* 233 */     if (this.borderStyle != style.borderStyle) return false;
/* 234 */     if (this.strikeout != style.strikeout) return false;
/* 235 */     if (this.rise != style.rise) return false;
/* 236 */     if (this.underlineColor != null) {
/* 237 */       if (!this.underlineColor.equals(style.underlineColor)) return false;
/* 238 */     } else if (style.underlineColor != null) return false;
/* 239 */     if (this.strikeoutColor != null) {
/* 240 */       if (!this.strikeoutColor.equals(style.strikeoutColor)) return false;
/* 241 */     } else if (style.strikeoutColor != null) return false;
/* 242 */     if (this.underlineStyle != style.underlineStyle) return false;
/* 243 */     if (this.borderColor != null) {
/* 244 */       if (!this.borderColor.equals(style.borderColor)) return false;
/* 245 */     } else if (style.borderColor != null) return false;
/* 246 */     if (this.data != null) {
/* 247 */       if (!this.data.equals(style.data)) return false;
/* 248 */     } else if (style.data != null) return false;
/* 249 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 264 */     int hash = 0;
/* 265 */     if (this.foreground != null) hash ^= this.foreground.hashCode();
/* 266 */     if (this.background != null) hash ^= this.background.hashCode();
/* 267 */     if (this.font != null) hash ^= this.font.hashCode();
/* 268 */     if (this.metrics != null) hash ^= this.metrics.hashCode();
/* 269 */     if (this.underline) hash ^= hash << 1;
/* 270 */     if (this.strikeout) hash ^= hash << 2;
/* 271 */     hash ^= this.rise;
/* 272 */     if (this.underlineColor != null) hash ^= this.underlineColor.hashCode();
/* 273 */     if (this.strikeoutColor != null) hash ^= this.strikeoutColor.hashCode();
/* 274 */     if (this.borderColor != null) hash ^= this.borderColor.hashCode();
/* 275 */     hash ^= this.underlineStyle;
/* 276 */     return hash;
/*     */   }
/*     */   
/*     */   boolean isAdherentBorder(TextStyle style) {
/* 280 */     if (this == style) return true;
/* 281 */     if (style == null) return false;
/* 282 */     if (this.borderStyle != style.borderStyle) return false;
/* 283 */     if (this.borderColor != null) {
/* 284 */       if (!this.borderColor.equals(style.borderColor)) return false;
/*     */     } else {
/* 286 */       if (style.borderColor != null) return false;
/* 287 */       if (this.foreground != null) {
/* 288 */         if (!this.foreground.equals(style.foreground)) return false;
/* 289 */       } else if (style.foreground != null) return false;
/*     */     }
/* 291 */     return true;
/*     */   }
/*     */   
/*     */   boolean isAdherentUnderline(TextStyle style) {
/* 295 */     if (this == style) return true;
/* 296 */     if (style == null) return false;
/* 297 */     if (this.underline != style.underline) return false;
/* 298 */     if (this.underlineStyle != style.underlineStyle) return false;
/* 299 */     if (this.underlineColor != null) {
/* 300 */       if (!this.underlineColor.equals(style.underlineColor)) return false;
/*     */     } else {
/* 302 */       if (style.underlineColor != null) return false;
/* 303 */       if (this.foreground != null) {
/* 304 */         if (!this.foreground.equals(style.foreground)) return false;
/* 305 */       } else if (style.foreground != null) return false;
/*     */     }
/* 307 */     return true;
/*     */   }
/*     */   
/*     */   boolean isAdherentStrikeout(TextStyle style) {
/* 311 */     if (this == style) return true;
/* 312 */     if (style == null) return false;
/* 313 */     if (this.strikeout != style.strikeout) return false;
/* 314 */     if (this.strikeoutColor != null) {
/* 315 */       if (!this.strikeoutColor.equals(style.strikeoutColor)) return false;
/*     */     } else {
/* 317 */       if (style.strikeoutColor != null) return false;
/* 318 */       if (this.foreground != null) {
/* 319 */         if (!this.foreground.equals(style.foreground)) return false;
/* 320 */       } else if (style.foreground != null) return false;
/*     */     }
/* 322 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 333 */     StringBuilder buffer = new StringBuilder("TextStyle {");
/* 334 */     int startLength = buffer.length();
/* 335 */     if (this.font != null) {
/* 336 */       if (buffer.length() > startLength) buffer.append(", ");
/* 337 */       buffer.append("font=");
/* 338 */       buffer.append(this.font);
/*     */     }
/* 340 */     if (this.foreground != null) {
/* 341 */       if (buffer.length() > startLength) buffer.append(", ");
/* 342 */       buffer.append("foreground=");
/* 343 */       buffer.append(this.foreground);
/*     */     }
/* 345 */     if (this.background != null) {
/* 346 */       if (buffer.length() > startLength) buffer.append(", ");
/* 347 */       buffer.append("background=");
/* 348 */       buffer.append(this.background);
/*     */     }
/* 350 */     if (this.underline) {
/* 351 */       if (buffer.length() > startLength) buffer.append(", ");
/* 352 */       buffer.append("underline=");
/* 353 */       switch (this.underlineStyle) {
/* 354 */       case 0:  buffer.append("single"); break;
/* 355 */       case 1:  buffer.append("double"); break;
/* 356 */       case 3:  buffer.append("squiggle"); break;
/* 357 */       case 2:  buffer.append("error"); break;
/* 358 */       case 4:  buffer.append("link");
/*     */       }
/* 360 */       if (this.underlineColor != null) {
/* 361 */         buffer.append(", underlineColor=");
/* 362 */         buffer.append(this.underlineColor);
/*     */       }
/*     */     }
/* 365 */     if (this.strikeout) {
/* 366 */       if (buffer.length() > startLength) buffer.append(", ");
/* 367 */       buffer.append("striked out");
/* 368 */       if (this.strikeoutColor != null) {
/* 369 */         buffer.append(", strikeoutColor=");
/* 370 */         buffer.append(this.strikeoutColor);
/*     */       }
/*     */     }
/* 373 */     if (this.borderStyle != 0) {
/* 374 */       if (buffer.length() > startLength) buffer.append(", ");
/* 375 */       buffer.append("border=");
/* 376 */       switch (this.borderStyle) {
/* 377 */       case 1:  buffer.append("solid"); break;
/* 378 */       case 4:  buffer.append("dot"); break;
/* 379 */       case 2:  buffer.append("dash");
/*     */       }
/* 381 */       if (this.borderColor != null) {
/* 382 */         buffer.append(", borderColor=");
/* 383 */         buffer.append(this.borderColor);
/*     */       }
/*     */     }
/* 386 */     if (this.rise != 0) {
/* 387 */       if (buffer.length() > startLength) buffer.append(", ");
/* 388 */       buffer.append("rise=");
/* 389 */       buffer.append(this.rise);
/*     */     }
/* 391 */     if (this.metrics != null) {
/* 392 */       if (buffer.length() > startLength) buffer.append(", ");
/* 393 */       buffer.append("metrics=");
/* 394 */       buffer.append(this.metrics);
/*     */     }
/* 396 */     buffer.append("}");
/* 397 */     return buffer.toString();
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/graphics/TextStyle.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */