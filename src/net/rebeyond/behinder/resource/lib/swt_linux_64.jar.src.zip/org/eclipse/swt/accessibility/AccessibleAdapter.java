package org.eclipse.swt.accessibility;

public abstract class AccessibleAdapter
  implements AccessibleListener
{
  public void getName(AccessibleEvent e) {}
  
  public void getHelp(AccessibleEvent e) {}
  
  public void getKeyboardShortcut(AccessibleEvent e) {}
  
  public void getDescription(AccessibleEvent e) {}
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/accessibility/AccessibleAdapter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */