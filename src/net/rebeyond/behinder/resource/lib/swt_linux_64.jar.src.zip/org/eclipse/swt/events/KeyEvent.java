/*     */ package org.eclipse.swt.events;
/*     */ 
/*     */ import org.eclipse.swt.widgets.Event;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class KeyEvent
/*     */   extends TypedEvent
/*     */ {
/*     */   public char character;
/*     */   public int keyCode;
/*     */   public int keyLocation;
/*     */   public int stateMask;
/*     */   public boolean doit;
/*     */   static final long serialVersionUID = 3256442491011412789L;
/*     */   
/*     */   public KeyEvent(Event e)
/*     */   {
/* 110 */     super(e);
/* 111 */     this.character = e.character;
/* 112 */     this.keyCode = e.keyCode;
/* 113 */     this.keyLocation = e.keyLocation;
/* 114 */     this.stateMask = e.stateMask;
/* 115 */     this.doit = e.doit;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 126 */     String string = super.toString();
/* 127 */     return string.substring(0, string.length() - 1) + " character='" + (this.character == 0 ? "\\0" : 
/* 128 */       String.valueOf(this.character)) + "'=0x" + Integer.toHexString(this.character) + " keyCode=0x" + 
/* 129 */       Integer.toHexString(this.keyCode) + " keyLocation=0x" + 
/* 130 */       Integer.toHexString(this.keyLocation) + " stateMask=0x" + 
/* 131 */       Integer.toHexString(this.stateMask) + " doit=" + this.doit + "}";
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/events/KeyEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */