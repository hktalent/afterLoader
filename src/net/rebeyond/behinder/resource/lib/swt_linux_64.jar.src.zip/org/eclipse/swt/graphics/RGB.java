/*     */ package org.eclipse.swt.graphics;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import org.eclipse.swt.SWT;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class RGB
/*     */   implements Serializable
/*     */ {
/*     */   public int red;
/*     */   public int green;
/*     */   public int blue;
/*     */   static final long serialVersionUID = 3258415023461249074L;
/*     */   
/*     */   public RGB(int red, int green, int blue)
/*     */   {
/*  74 */     if ((red > 255) || (red < 0) || (green > 255) || (green < 0) || (blue > 255) || (blue < 0))
/*     */     {
/*     */ 
/*  77 */       SWT.error(5); }
/*  78 */     this.red = red;
/*  79 */     this.green = green;
/*  80 */     this.blue = blue;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RGB(float hue, float saturation, float brightness)
/*     */   {
/*  99 */     if ((hue < 0.0F) || (hue > 360.0F) || (saturation < 0.0F) || (saturation > 1.0F) || (brightness < 0.0F) || (brightness > 1.0F))
/*     */     {
/* 101 */       SWT.error(5); }
/*     */     float r;
/*     */     float r;
/* 104 */     float g; float b; if (saturation == 0.0F) { float b;
/* 105 */       float g; r = g = b = brightness;
/*     */     } else {
/* 107 */       if (hue == 360.0F) hue = 0.0F;
/* 108 */       hue /= 60.0F;
/* 109 */       int i = (int)hue;
/* 110 */       float f = hue - i;
/* 111 */       float p = brightness * (1.0F - saturation);
/* 112 */       float q = brightness * (1.0F - saturation * f);
/* 113 */       float t = brightness * (1.0F - saturation * (1.0F - f));
/* 114 */       float b; float b; float b; float b; float b; switch (i) {
/*     */       case 0: 
/* 116 */         float r = brightness;
/* 117 */         float g = t;
/* 118 */         b = p;
/* 119 */         break;
/*     */       case 1: 
/* 121 */         float r = q;
/* 122 */         float g = brightness;
/* 123 */         b = p;
/* 124 */         break;
/*     */       case 2: 
/* 126 */         float r = p;
/* 127 */         float g = brightness;
/* 128 */         b = t;
/* 129 */         break;
/*     */       case 3: 
/* 131 */         float r = p;
/* 132 */         float g = q;
/* 133 */         b = brightness;
/* 134 */         break;
/*     */       case 4: 
/* 136 */         float r = t;
/* 137 */         float g = p;
/* 138 */         b = brightness;
/* 139 */         break;
/*     */       case 5: 
/*     */       default: 
/* 142 */         r = brightness;
/* 143 */         g = p;
/* 144 */         b = q;
/*     */       }
/*     */       
/*     */     }
/* 148 */     this.red = ((int)(r * 255.0F + 0.5D));
/* 149 */     this.green = ((int)(g * 255.0F + 0.5D));
/* 150 */     this.blue = ((int)(b * 255.0F + 0.5D));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public float[] getHSB()
/*     */   {
/* 166 */     float r = this.red / 255.0F;
/* 167 */     float g = this.green / 255.0F;
/* 168 */     float b = this.blue / 255.0F;
/* 169 */     float max = Math.max(Math.max(r, g), b);
/* 170 */     float min = Math.min(Math.min(r, g), b);
/* 171 */     float delta = max - min;
/* 172 */     float hue = 0.0F;
/* 173 */     float brightness = max;
/* 174 */     float saturation = max == 0.0F ? 0.0F : (max - min) / max;
/* 175 */     if (delta != 0.0F) {
/* 176 */       if (r == max) {
/* 177 */         hue = (g - b) / delta;
/*     */       }
/* 179 */       else if (g == max) {
/* 180 */         hue = 2.0F + (b - r) / delta;
/*     */       } else {
/* 182 */         hue = 4.0F + (r - g) / delta;
/*     */       }
/*     */       
/* 185 */       hue *= 60.0F;
/* 186 */       if (hue < 0.0F) hue += 360.0F;
/*     */     }
/* 188 */     return new float[] { hue, saturation, brightness };
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object object)
/*     */   {
/* 203 */     if (object == this) return true;
/* 204 */     if (!(object instanceof RGB)) return false;
/* 205 */     RGB rgb = (RGB)object;
/* 206 */     return (rgb.red == this.red) && (rgb.green == this.green) && (rgb.blue == this.blue);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 221 */     return this.blue << 16 | this.green << 8 | this.red;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 232 */     return "RGB {" + this.red + ", " + this.green + ", " + this.blue + "}";
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/graphics/RGB.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */