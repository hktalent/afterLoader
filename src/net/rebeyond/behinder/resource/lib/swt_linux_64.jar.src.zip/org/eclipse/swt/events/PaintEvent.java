/*    */ package org.eclipse.swt.events;
/*    */ 
/*    */ import org.eclipse.swt.graphics.GC;
/*    */ import org.eclipse.swt.widgets.Event;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class PaintEvent
/*    */   extends TypedEvent
/*    */ {
/*    */   public GC gc;
/*    */   public int x;
/*    */   public int y;
/*    */   public int width;
/*    */   public int height;
/*    */   public int count;
/*    */   static final long serialVersionUID = 3256446919205992497L;
/*    */   
/*    */   public PaintEvent(Event e)
/*    */   {
/* 75 */     super(e);
/* 76 */     this.gc = e.gc;
/* 77 */     this.x = e.x;
/* 78 */     this.y = e.y;
/* 79 */     this.width = e.width;
/* 80 */     this.height = e.height;
/* 81 */     this.count = e.count;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String toString()
/*    */   {
/* 92 */     String string = super.toString();
/* 93 */     return string.substring(0, string.length() - 1) + " gc=" + this.gc + " x=" + this.x + " y=" + this.y + " width=" + this.width + " height=" + this.height + " count=" + this.count + "}";
/*    */   }
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/events/PaintEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */