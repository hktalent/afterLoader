/*      */ package org.eclipse.swt.widgets;
/*      */ 
/*      */ import org.eclipse.swt.events.SelectionListener;
/*      */ import org.eclipse.swt.graphics.Color;
/*      */ import org.eclipse.swt.graphics.Font;
/*      */ import org.eclipse.swt.graphics.Point;
/*      */ import org.eclipse.swt.graphics.Rectangle;
/*      */ import org.eclipse.swt.internal.C;
/*      */ import org.eclipse.swt.internal.Converter;
/*      */ import org.eclipse.swt.internal.DPIUtil;
/*      */ import org.eclipse.swt.internal.gtk.GDK;
/*      */ import org.eclipse.swt.internal.gtk.GTK;
/*      */ import org.eclipse.swt.internal.gtk.GdkColor;
/*      */ import org.eclipse.swt.internal.gtk.GdkEventButton;
/*      */ import org.eclipse.swt.internal.gtk.GdkEventKey;
/*      */ import org.eclipse.swt.internal.gtk.GdkRGBA;
/*      */ import org.eclipse.swt.internal.gtk.GdkRectangle;
/*      */ import org.eclipse.swt.internal.gtk.OS;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class List
/*      */   extends Scrollable
/*      */ {
/*      */   long modelHandle;
/*      */   int topIndex;
/*      */   int selectionCountOnPress;
/*      */   int selectionCountOnRelease;
/*      */   static final int TEXT_COLUMN = 0;
/*      */   double cachedAdjustment;
/*      */   double currentAdjustment;
/*      */   
/*      */   public List(Composite parent, int style)
/*      */   {
/*   80 */     super(parent, checkStyle(style));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void add(String string)
/*      */   {
/*  102 */     checkWidget();
/*  103 */     if (string == null) error(4);
/*  104 */     byte[] buffer = Converter.wcsToMbcs(string, true);
/*  105 */     long iter = OS.g_malloc(GTK.GtkTreeIter_sizeof());
/*  106 */     if (iter == 0L) error(14);
/*  107 */     GTK.gtk_list_store_append(this.modelHandle, iter);
/*  108 */     GTK.gtk_list_store_set(this.modelHandle, iter, 0, buffer, -1);
/*  109 */     OS.g_free(iter);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void add(String string, int index)
/*      */   {
/*  139 */     checkWidget();
/*  140 */     if (string == null) error(4);
/*  141 */     int count = GTK.gtk_tree_model_iter_n_children(this.modelHandle, 0L);
/*  142 */     if ((0 > index) || (index > count)) {
/*  143 */       error(6);
/*      */     }
/*  145 */     byte[] buffer = Converter.wcsToMbcs(string, true);
/*  146 */     long iter = OS.g_malloc(GTK.GtkTreeIter_sizeof());
/*  147 */     if (iter == 0L) { error(14);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  152 */     if (index == count) {
/*  153 */       GTK.gtk_list_store_append(this.modelHandle, iter);
/*      */     } else {
/*  155 */       GTK.gtk_list_store_insert(this.modelHandle, iter, index);
/*      */     }
/*  157 */     GTK.gtk_list_store_set(this.modelHandle, iter, 0, buffer, -1);
/*  158 */     OS.g_free(iter);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addSelectionListener(SelectionListener listener)
/*      */   {
/*  186 */     checkWidget();
/*  187 */     if (listener == null) error(4);
/*  188 */     TypedListener typedListener = new TypedListener(listener);
/*  189 */     addListener(13, typedListener);
/*  190 */     addListener(14, typedListener);
/*      */   }
/*      */   
/*      */   static int checkStyle(int style) {
/*  194 */     return checkBits(style, 4, 2, 0, 0, 0, 0);
/*      */   }
/*      */   
/*      */   void createHandle(int index)
/*      */   {
/*  199 */     this.state |= 0x8;
/*  200 */     this.fixedHandle = OS.g_object_new(this.display.gtk_fixed_get_type(), 0L);
/*  201 */     if (this.fixedHandle == 0L) error(2);
/*  202 */     GTK.gtk_widget_set_has_window(this.fixedHandle, true);
/*  203 */     this.scrolledHandle = GTK.gtk_scrolled_window_new(0L, 0L);
/*  204 */     if (this.scrolledHandle == 0L) { error(2);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  209 */     long[] types = { OS.G_TYPE_STRING() };
/*  210 */     this.modelHandle = GTK.gtk_list_store_newv(types.length, types);
/*  211 */     if (this.modelHandle == 0L) error(2);
/*  212 */     this.handle = GTK.gtk_tree_view_new_with_model(this.modelHandle);
/*  213 */     if (this.handle == 0L) error(2);
/*  214 */     long textRenderer = GTK.gtk_cell_renderer_text_new();
/*  215 */     if (textRenderer == 0L) error(2);
/*  216 */     long columnHandle = GTK.gtk_tree_view_column_new();
/*  217 */     if (columnHandle == 0L) error(2);
/*  218 */     GTK.gtk_tree_view_column_pack_start(columnHandle, textRenderer, true);
/*  219 */     GTK.gtk_tree_view_column_add_attribute(columnHandle, textRenderer, OS.text, 0);
/*  220 */     GTK.gtk_tree_view_column_set_min_width(columnHandle, 0);
/*  221 */     GTK.gtk_tree_view_insert_column(this.handle, columnHandle, index);
/*  222 */     GTK.gtk_container_add(this.fixedHandle, this.scrolledHandle);
/*  223 */     GTK.gtk_container_add(this.scrolledHandle, this.handle);
/*      */     
/*  225 */     int mode = (this.style & 0x2) != 0 ? 3 : 2;
/*  226 */     long selectionHandle = GTK.gtk_tree_view_get_selection(this.handle);
/*  227 */     GTK.gtk_tree_selection_set_mode(selectionHandle, mode);
/*  228 */     GTK.gtk_tree_view_set_headers_visible(this.handle, false);
/*  229 */     int hsp = (this.style & 0x100) != 0 ? 1 : 2;
/*  230 */     int vsp = (this.style & 0x200) != 0 ? 1 : 2;
/*  231 */     GTK.gtk_scrolled_window_set_policy(this.scrolledHandle, hsp, vsp);
/*  232 */     if ((this.style & 0x800) != 0) { GTK.gtk_scrolled_window_set_shadow_type(this.scrolledHandle, 3);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  240 */     if ((getShell().style & 0x4000) != 0) {
/*  241 */       GTK.gtk_tree_view_set_search_column(this.handle, -1);
/*      */     }
/*      */     
/*      */ 
/*  245 */     if (GTK.GTK3) {
/*  246 */       setFontDescription(defaultFont().handle);
/*      */     }
/*      */   }
/*      */   
/*      */   int applyThemeBackground()
/*      */   {
/*  252 */     return -1;
/*      */   }
/*      */   
/*      */   Point computeSizeInPixels(int wHint, int hHint, boolean changed)
/*      */   {
/*  257 */     checkWidget();
/*  258 */     if ((wHint != -1) && (wHint < 0)) wHint = 0;
/*  259 */     if ((hHint != -1) && (hHint < 0)) hHint = 0;
/*  260 */     GTK.gtk_widget_realize(this.handle);
/*  261 */     Point size = computeNativeSize(this.handle, wHint, hHint, changed);
/*  262 */     if ((size.x == 0) && (wHint == -1)) { size.x = 64;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  268 */     if ((GTK.GTK3) && (size.y == 0) && (hHint == -1)) {
/*  269 */       size.y = (getItemCount() * getItemHeightInPixels());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  277 */     if ((size.y == 0) && (hHint == -1)) size.y = 64;
/*  278 */     Rectangle trim = computeTrimInPixels(0, 0, size.x, size.y);
/*  279 */     size.x = trim.width;
/*  280 */     size.y = trim.height;
/*  281 */     return size;
/*      */   }
/*      */   
/*      */   GdkRGBA defaultBackground()
/*      */   {
/*  286 */     return this.display.getSystemColor(25).handleRGBA;
/*      */   }
/*      */   
/*      */   void deregister()
/*      */   {
/*  291 */     super.deregister();
/*  292 */     this.display.removeWidget(GTK.gtk_tree_view_get_selection(this.handle));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void deselect(int index)
/*      */   {
/*  308 */     checkWidget();
/*  309 */     if ((0 > index) || (index >= GTK.gtk_tree_model_iter_n_children(this.modelHandle, 0L))) return;
/*  310 */     long iter = OS.g_malloc(GTK.GtkTreeIter_sizeof());
/*  311 */     long selection = GTK.gtk_tree_view_get_selection(this.handle);
/*  312 */     OS.g_signal_handlers_block_matched(selection, 16, 0, 0, 0L, 0L, 6L);
/*  313 */     GTK.gtk_tree_model_iter_nth_child(this.modelHandle, iter, 0L, index);
/*  314 */     GTK.gtk_tree_selection_unselect_iter(selection, iter);
/*  315 */     OS.g_signal_handlers_unblock_matched(selection, 16, 0, 0, 0L, 0L, 6L);
/*  316 */     OS.g_free(iter);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void deselect(int start, int end)
/*      */   {
/*  335 */     checkWidget();
/*  336 */     if ((start < 0) && (end < 0)) return;
/*  337 */     int count = GTK.gtk_tree_model_iter_n_children(this.modelHandle, 0L);
/*  338 */     if ((start >= count) && (end >= count)) return;
/*  339 */     start = Math.min(count - 1, Math.max(0, start));
/*  340 */     end = Math.min(count - 1, Math.max(0, end));
/*  341 */     long iter = OS.g_malloc(GTK.GtkTreeIter_sizeof());
/*  342 */     long selection = GTK.gtk_tree_view_get_selection(this.handle);
/*  343 */     OS.g_signal_handlers_block_matched(selection, 16, 0, 0, 0L, 0L, 6L);
/*  344 */     for (int index = start; index <= end; index++) {
/*  345 */       GTK.gtk_tree_model_iter_nth_child(this.modelHandle, iter, 0L, index);
/*  346 */       GTK.gtk_tree_selection_unselect_iter(selection, iter);
/*      */     }
/*  348 */     OS.g_signal_handlers_unblock_matched(selection, 16, 0, 0, 0L, 0L, 6L);
/*  349 */     OS.g_free(iter);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void deselect(int[] indices)
/*      */   {
/*  370 */     checkWidget();
/*  371 */     if (indices == null) error(4);
/*  372 */     long iter = OS.g_malloc(GTK.GtkTreeIter_sizeof());
/*  373 */     int count = GTK.gtk_tree_model_iter_n_children(this.modelHandle, 0L);
/*  374 */     long selection = GTK.gtk_tree_view_get_selection(this.handle);
/*  375 */     OS.g_signal_handlers_block_matched(selection, 16, 0, 0, 0L, 0L, 6L);
/*  376 */     for (int i = 0; i < indices.length; i++) {
/*  377 */       int index = indices[i];
/*  378 */       if ((index >= 0) && (index <= count - 1)) {
/*  379 */         GTK.gtk_tree_model_iter_nth_child(this.modelHandle, iter, 0L, index);
/*  380 */         GTK.gtk_tree_selection_unselect_iter(selection, iter);
/*      */       } }
/*  382 */     OS.g_signal_handlers_unblock_matched(selection, 16, 0, 0, 0L, 0L, 6L);
/*  383 */     OS.g_free(iter);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void deselectAll()
/*      */   {
/*  395 */     checkWidget();
/*  396 */     long selection = GTK.gtk_tree_view_get_selection(this.handle);
/*  397 */     OS.g_signal_handlers_block_matched(selection, 16, 0, 0, 0L, 0L, 6L);
/*  398 */     GTK.gtk_tree_selection_unselect_all(selection);
/*  399 */     OS.g_signal_handlers_unblock_matched(selection, 16, 0, 0, 0L, 0L, 6L);
/*      */   }
/*      */   
/*      */   boolean dragDetect(int x, int y, boolean filter, boolean dragOnTimeout, boolean[] consume)
/*      */   {
/*  404 */     boolean selected = false;
/*  405 */     if (OS.isX11()) {
/*  406 */       if (filter) {
/*  407 */         long[] path = new long[1];
/*  408 */         if (GTK.gtk_tree_view_get_path_at_pos(this.handle, x, y, path, null, null, null)) {
/*  409 */           if (path[0] != 0L) {
/*  410 */             long selection = GTK.gtk_tree_view_get_selection(this.handle);
/*  411 */             if (GTK.gtk_tree_selection_path_is_selected(selection, path[0])) selected = true;
/*  412 */             GTK.gtk_tree_path_free(path[0]);
/*      */           }
/*      */         } else {
/*  415 */           return false;
/*      */         }
/*      */       }
/*  418 */       boolean dragDetect = super.dragDetect(x, y, filter, false, consume);
/*  419 */       if ((dragDetect) && (selected) && (consume != null)) consume[0] = true;
/*  420 */       return dragDetect;
/*      */     }
/*  422 */     double[] startX = new double[1];
/*  423 */     double[] startY = new double[1];
/*  424 */     long[] path = new long[1];
/*  425 */     if (GTK.gtk_gesture_drag_get_start_point(this.dragGesture, startX, startY)) {
/*  426 */       if (GTK.gtk_tree_view_get_path_at_pos(this.handle, (int)startX[0], (int)startY[0], path, null, null, null)) {
/*  427 */         if (path[0] != 0L) {
/*  428 */           boolean dragDetect = super.dragDetect(x, y, filter, false, consume);
/*  429 */           if ((dragDetect) && (selected) && (consume != null)) consume[0] = true;
/*  430 */           return dragDetect;
/*      */         }
/*      */       } else {
/*  433 */         return false;
/*      */       }
/*      */     }
/*      */     
/*  437 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */   long eventWindow()
/*      */   {
/*  443 */     return paintWindow();
/*      */   }
/*      */   
/*      */   GdkColor getBackgroundGdkColor()
/*      */   {
/*  448 */     assert (!GTK.GTK3) : "GTK2 code was run by GTK3";
/*  449 */     return getBaseGdkColor();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getFocusIndex()
/*      */   {
/*  464 */     checkWidget();
/*  465 */     long[] path = new long[1];
/*  466 */     GTK.gtk_tree_view_get_cursor(this.handle, path, null);
/*  467 */     if (path[0] == 0L) return -1;
/*  468 */     long indices = GTK.gtk_tree_path_get_indices(path[0]);
/*  469 */     int[] index = { -1 };
/*  470 */     if (indices != 0L) C.memmove(index, indices, 4L);
/*  471 */     GTK.gtk_tree_path_free(path[0]);
/*  472 */     return index[0];
/*      */   }
/*      */   
/*      */   GdkColor getForegroundGdkColor()
/*      */   {
/*  477 */     assert (!GTK.GTK3) : "GTK2 code was run by GTK3";
/*  478 */     return getTextColor();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getItem(int index)
/*      */   {
/*  497 */     checkWidget();
/*  498 */     if ((0 > index) || (index >= GTK.gtk_tree_model_iter_n_children(this.modelHandle, 0L))) {
/*  499 */       error(6);
/*      */     }
/*  501 */     long[] ptr = new long[1];
/*  502 */     long iter = OS.g_malloc(GTK.GtkTreeIter_sizeof());
/*  503 */     GTK.gtk_tree_model_iter_nth_child(this.modelHandle, iter, 0L, index);
/*  504 */     GTK.gtk_tree_model_get(this.modelHandle, iter, 0, ptr, -1);
/*  505 */     OS.g_free(iter);
/*  506 */     if (ptr[0] == 0L) return null;
/*  507 */     int length = C.strlen(ptr[0]);
/*  508 */     byte[] buffer2 = new byte[length];
/*  509 */     C.memmove(buffer2, ptr[0], length);
/*  510 */     OS.g_free(ptr[0]);
/*  511 */     return new String(Converter.mbcsToWcs(buffer2));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getItemCount()
/*      */   {
/*  525 */     checkWidget();
/*  526 */     return GTK.gtk_tree_model_iter_n_children(this.modelHandle, 0L);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getItemHeight()
/*      */   {
/*  541 */     checkWidget();
/*  542 */     return DPIUtil.autoScaleDown(getItemHeightInPixels());
/*      */   }
/*      */   
/*      */   int getItemHeightInPixels() {
/*  546 */     checkWidget();
/*  547 */     int itemCount = GTK.gtk_tree_model_iter_n_children(this.modelHandle, 0L);
/*  548 */     long column = GTK.gtk_tree_view_get_column(this.handle, 0);
/*  549 */     if (itemCount == 0) {
/*  550 */       int[] w = new int[1];int[] h = new int[1];
/*  551 */       GTK.gtk_tree_view_column_cell_get_size(column, null, null, null, w, h);
/*  552 */       int height = h[0];
/*  553 */       if (GTK.GTK3) {
/*  554 */         long textRenderer = getTextRenderer(column);
/*  555 */         GTK.gtk_cell_renderer_get_preferred_height_for_width(textRenderer, this.handle, 0, h, null);
/*  556 */         height += h[0];
/*      */       }
/*  558 */       return height;
/*      */     }
/*  560 */     long iter = OS.g_malloc(GTK.GtkTreeIter_sizeof());
/*  561 */     GTK.gtk_tree_model_get_iter_first(this.modelHandle, iter);
/*  562 */     GTK.gtk_tree_view_column_cell_set_cell_data(column, this.modelHandle, iter, false, false);
/*  563 */     int[] w = new int[1];int[] h = new int[1];
/*  564 */     GTK.gtk_tree_view_column_cell_get_size(column, null, null, null, w, h);
/*  565 */     OS.g_free(iter);
/*  566 */     return h[0];
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String[] getItems()
/*      */   {
/*  587 */     checkWidget();
/*  588 */     int count = GTK.gtk_tree_model_iter_n_children(this.modelHandle, 0L);
/*  589 */     long[] ptr = new long[1];
/*  590 */     String[] result = new String[count];
/*  591 */     long iter = OS.g_malloc(GTK.GtkTreeIter_sizeof());
/*  592 */     for (int index = 0; index < count; index++) {
/*  593 */       GTK.gtk_tree_model_iter_nth_child(this.modelHandle, iter, 0L, index);
/*  594 */       GTK.gtk_tree_model_get(this.modelHandle, iter, 0, ptr, -1);
/*  595 */       if (ptr[0] != 0L) {
/*  596 */         int length = C.strlen(ptr[0]);
/*  597 */         byte[] buffer = new byte[length];
/*  598 */         C.memmove(buffer, ptr[0], length);
/*  599 */         OS.g_free(ptr[0]);
/*  600 */         result[index] = new String(Converter.mbcsToWcs(buffer));
/*      */       }
/*      */     }
/*  603 */     OS.g_free(iter);
/*  604 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String[] getSelection()
/*      */   {
/*  624 */     checkWidget();
/*  625 */     int[] indices = getSelectionIndices();
/*  626 */     String[] result = new String[indices.length];
/*  627 */     for (int i = 0; i < indices.length; i++) {
/*  628 */       result[i] = getItem(indices[i]);
/*      */     }
/*  630 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getSelectionCount()
/*      */   {
/*  644 */     checkWidget();
/*  645 */     long selection = GTK.gtk_tree_view_get_selection(this.handle);
/*  646 */     return GTK.gtk_tree_selection_count_selected_rows(selection);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getSelectionIndex()
/*      */   {
/*  661 */     checkWidget();
/*  662 */     long selection = GTK.gtk_tree_view_get_selection(this.handle);
/*  663 */     long list = GTK.gtk_tree_selection_get_selected_rows(selection, null);
/*  664 */     long originalList = list;
/*  665 */     if (list != 0L) {
/*  666 */       int[] index = new int[1];
/*  667 */       boolean foundIndex = false;
/*  668 */       while (list != 0L) {
/*  669 */         long data = OS.g_list_data(list);
/*  670 */         if (!foundIndex) {
/*  671 */           long indices = GTK.gtk_tree_path_get_indices(data);
/*  672 */           if (indices != 0L) {
/*  673 */             C.memmove(index, indices, 4L);
/*  674 */             foundIndex = true;
/*      */           }
/*      */         }
/*  677 */         list = OS.g_list_next(list);
/*  678 */         GTK.gtk_tree_path_free(data);
/*      */       }
/*  680 */       OS.g_list_free(originalList);
/*  681 */       return index[0];
/*      */     }
/*  683 */     return -1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int[] getSelectionIndices()
/*      */   {
/*  703 */     checkWidget();
/*  704 */     long selection = GTK.gtk_tree_view_get_selection(this.handle);
/*  705 */     long list = GTK.gtk_tree_selection_get_selected_rows(selection, null);
/*  706 */     long originalList = list;
/*  707 */     if (list != 0L) {
/*  708 */       int count = OS.g_list_length(list);
/*  709 */       int[] treeSelection = new int[count];
/*  710 */       int length = 0;
/*  711 */       for (int i = 0; i < count; i++) {
/*  712 */         long data = OS.g_list_data(list);
/*  713 */         long indices = GTK.gtk_tree_path_get_indices(data);
/*  714 */         if (indices != 0L) {
/*  715 */           int[] index = new int[1];
/*  716 */           C.memmove(index, indices, 4L);
/*  717 */           treeSelection[length] = index[0];
/*  718 */           length++;
/*      */         }
/*  720 */         GTK.gtk_tree_path_free(data);
/*  721 */         list = OS.g_list_next(list);
/*      */       }
/*  723 */       OS.g_list_free(originalList);
/*  724 */       int[] result = new int[length];
/*  725 */       System.arraycopy(treeSelection, 0, result, 0, length);
/*  726 */       return result;
/*      */     }
/*  728 */     return new int[0];
/*      */   }
/*      */   
/*      */   long getTextRenderer(long column) {
/*  732 */     long list = GTK.gtk_cell_layout_get_cells(column);
/*  733 */     if (list == 0L) return 0L;
/*  734 */     long originalList = list;
/*  735 */     long textRenderer = 0L;
/*  736 */     while (list != 0L) {
/*  737 */       long renderer = OS.g_list_data(list);
/*  738 */       if (GTK.GTK_IS_CELL_RENDERER_TEXT(renderer)) {
/*  739 */         textRenderer = renderer;
/*  740 */         break;
/*      */       }
/*  742 */       list = OS.g_list_next(list);
/*      */     }
/*  744 */     OS.g_list_free(originalList);
/*  745 */     return textRenderer;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getTopIndex()
/*      */   {
/*  761 */     checkWidget();
/*      */     
/*      */ 
/*      */     long vAdjustment;
/*      */     
/*      */     long vAdjustment;
/*      */     
/*  768 */     if (GTK.GTK3) {
/*  769 */       vAdjustment = GTK.gtk_scrollable_get_vadjustment(this.handle);
/*      */     } else {
/*  771 */       vAdjustment = GTK.gtk_tree_view_get_vadjustment(this.handle);
/*      */     }
/*  773 */     this.currentAdjustment = GTK.gtk_adjustment_get_value(vAdjustment);
/*  774 */     if (this.cachedAdjustment == this.currentAdjustment) {
/*  775 */       return this.topIndex;
/*      */     }
/*  777 */     long[] path = new long[1];
/*  778 */     GTK.gtk_widget_realize(this.handle);
/*  779 */     if (!GTK.gtk_tree_view_get_path_at_pos(this.handle, 1, 1, path, null, null, null)) return 0;
/*  780 */     if (path[0] == 0L) return 0;
/*  781 */     long indices = GTK.gtk_tree_path_get_indices(path[0]);
/*  782 */     int[] index = new int[1];
/*  783 */     if (indices != 0L) C.memmove(index, indices, 4L);
/*  784 */     GTK.gtk_tree_path_free(path[0]);
/*  785 */     return index[0];
/*      */   }
/*      */   
/*      */ 
/*      */   long gtk_changed(long widget)
/*      */   {
/*  791 */     sendSelectionEvent(13);
/*  792 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_event_after(long widget, long gdkEvent)
/*      */   {
/*  797 */     switch (GDK.GDK_EVENT_TYPE(gdkEvent))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 2: 
/*  806 */       if (GTK.gtk_tree_model_iter_n_children(this.modelHandle, 0L) == 0) {
/*  807 */         gtk_expose_event(widget, gdkEvent);
/*      */       }
/*      */       break;
/*      */     }
/*      */     
/*  812 */     return super.gtk_event_after(widget, gdkEvent);
/*      */   }
/*      */   
/*      */   long gtk_button_press_event(long widget, long event)
/*      */   {
/*  817 */     long result = super.gtk_button_press_event(widget, event);
/*  818 */     if (result != 0L) { return result;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  825 */     GdkEventButton gdkEvent = new GdkEventButton();
/*  826 */     OS.memmove(gdkEvent, event, GdkEventButton.sizeof);
/*  827 */     if (((this.state & 0x800000) != 0) && (hooks(29)) && 
/*  828 */       (!OS.isX11()) && (gdkEvent.type == 4))
/*      */     {
/*  830 */       long nextEvent = GDK.gdk_event_peek();
/*  831 */       if (nextEvent == 0L) {
/*  832 */         long[] path = new long[1];
/*  833 */         long selection = GTK.gtk_tree_view_get_selection(this.handle);
/*  834 */         if ((GTK.gtk_tree_view_get_path_at_pos(this.handle, (int)gdkEvent.x, (int)gdkEvent.y, path, null, null, null)) && (path[0] != 0L))
/*      */         {
/*      */ 
/*  837 */           this.selectionCountOnPress = getSelectionCount();
/*  838 */           if ((GTK.gtk_tree_selection_path_is_selected(selection, path[0])) && (
/*  839 */             ((gdkEvent.state & 0x5) == 0) || ((gdkEvent.state & 0x4) != 0)))
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  848 */             long gtk_false_funcPtr = GTK.GET_FUNCTION_POINTER_gtk_false();
/*  849 */             GTK.gtk_tree_selection_set_select_function(selection, gtk_false_funcPtr, 0L, 0L);
/*      */           }
/*      */         }
/*      */       }
/*      */       else {
/*  854 */         GDK.gdk_event_free(nextEvent);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  866 */     int button = gdkEvent.button;
/*  867 */     if ((button == 3) && (gdkEvent.type == 4)) {
/*  868 */       long[] path = new long[1];
/*  869 */       if ((GTK.gtk_tree_view_get_path_at_pos(this.handle, (int)gdkEvent.x, (int)gdkEvent.y, path, null, null, null)) && 
/*  870 */         (path[0] != 0L)) {
/*  871 */         long selection = GTK.gtk_tree_view_get_selection(this.handle);
/*  872 */         if (GTK.gtk_tree_selection_path_is_selected(selection, path[0])) result = 1L;
/*  873 */         GTK.gtk_tree_path_free(path[0]);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  885 */     if (((this.style & 0x4) != 0) && (getSelectionCount() == 0)) {
/*  886 */       long[] path = new long[1];
/*  887 */       if ((GTK.gtk_tree_view_get_path_at_pos(this.handle, (int)gdkEvent.x, (int)gdkEvent.y, path, null, null, null)) && 
/*  888 */         (path[0] != 0L)) {
/*  889 */         long selection = GTK.gtk_tree_view_get_selection(this.handle);
/*  890 */         OS.g_signal_handlers_block_matched(selection, 16, 0, 0, 0L, 0L, 6L);
/*  891 */         GTK.gtk_tree_view_set_cursor(this.handle, path[0], 0L, false);
/*  892 */         OS.g_signal_handlers_unblock_matched(selection, 16, 0, 0, 0L, 0L, 6L);
/*  893 */         GTK.gtk_tree_path_free(path[0]);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  899 */     if (gdkEvent.type == 5) {
/*  900 */       sendTreeDefaultSelection();
/*      */     }
/*      */     
/*  903 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */   long gtk_key_press_event(long widget, long event)
/*      */   {
/*  909 */     GdkEventKey keyEvent = new GdkEventKey();
/*  910 */     OS.memmove(keyEvent, event, GdkEventKey.sizeof);
/*  911 */     int key = keyEvent.keyval;
/*  912 */     keyPressDefaultSelectionHandler(event, key);
/*  913 */     return super.gtk_key_press_event(widget, event);
/*      */   }
/*      */   
/*      */   long gtk_button_release_event(long widget, long event)
/*      */   {
/*  918 */     GdkEventButton gdkEvent = new GdkEventButton();
/*  919 */     OS.memmove(gdkEvent, event, GdkEventButton.sizeof);
/*  920 */     if (gdkEvent.window != GTK.gtk_tree_view_get_bin_window(this.handle)) { return 0L;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  928 */     if (((this.state & 0x800000) != 0) && (hooks(29)) && (!OS.isX11())) {
/*  929 */       long[] path = new long[1];
/*  930 */       long selection = GTK.gtk_tree_view_get_selection(this.handle);
/*      */       
/*  932 */       GTK.gtk_tree_selection_set_select_function(selection, 0L, 0L, 0L);
/*  933 */       if ((GTK.gtk_tree_view_get_path_at_pos(this.handle, (int)gdkEvent.x, (int)gdkEvent.y, path, null, null, null)) && (path[0] != 0L) && 
/*  934 */         (GTK.gtk_tree_selection_path_is_selected(selection, path[0]))) {
/*  935 */         this.selectionCountOnRelease = getSelectionCount();
/*  936 */         if ((gdkEvent.state & 0x5) == 0) {
/*  937 */           GTK.gtk_tree_view_set_cursor(this.handle, path[0], 0L, false);
/*      */         }
/*      */         
/*      */ 
/*  941 */         if (((gdkEvent.state & 0x4) != 0) && (this.selectionCountOnRelease == this.selectionCountOnPress)) {
/*  942 */           GTK.gtk_tree_selection_unselect_path(selection, path[0]);
/*      */         }
/*      */       }
/*      */     }
/*  946 */     return super.gtk_button_release_event(widget, event);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   void keyPressDefaultSelectionHandler(long event, int key)
/*      */   {
/*  954 */     int keymask = gdk_event_get_state(event);
/*  955 */     switch (key)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */     case 65293: 
/*  961 */       if ((keymask & 0x1C000008) == 0) {
/*  962 */         sendTreeDefaultSelection();
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */       break;
/*      */     }
/*      */     
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   void sendTreeDefaultSelection()
/*      */   {
/*  976 */     Event event = new Event();
/*  977 */     event.index = getFocusIndex();
/*      */     
/*  979 */     if (event.index >= 0)
/*  980 */       event.text = getItem(event.index);
/*  981 */     sendSelectionEvent(14, event, false);
/*      */   }
/*      */   
/*      */   void hookEvents()
/*      */   {
/*  986 */     super.hookEvents();
/*  987 */     long selection = GTK.gtk_tree_view_get_selection(this.handle);
/*  988 */     OS.g_signal_connect_closure(selection, OS.changed, this.display.getClosure(6), false);
/*  989 */     OS.g_signal_connect_closure(this.handle, OS.row_activated, this.display.getClosure(41), false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int indexOf(String string)
/*      */   {
/* 1012 */     checkWidget();
/* 1013 */     return indexOf(string, 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int indexOf(String string, int start)
/*      */   {
/* 1036 */     checkWidget();
/* 1037 */     if (string == null) error(4);
/* 1038 */     String[] items = getItems();
/* 1039 */     for (int i = start; i < items.length; i++) {
/* 1040 */       if (items[i].equals(string)) return i;
/*      */     }
/* 1042 */     return -1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isSelected(int index)
/*      */   {
/* 1059 */     checkWidget();
/* 1060 */     long selection = GTK.gtk_tree_view_get_selection(this.handle);
/* 1061 */     byte[] buffer = Converter.wcsToMbcs(Integer.toString(index), true);
/* 1062 */     long path = GTK.gtk_tree_path_new_from_string(buffer);
/* 1063 */     boolean answer = GTK.gtk_tree_selection_path_is_selected(selection, path);
/* 1064 */     GTK.gtk_tree_path_free(path);
/* 1065 */     return answer;
/*      */   }
/*      */   
/*      */   long paintWindow()
/*      */   {
/* 1070 */     GTK.gtk_widget_realize(this.handle);
/* 1071 */     return GTK.gtk_tree_view_get_bin_window(this.handle);
/*      */   }
/*      */   
/*      */   void register()
/*      */   {
/* 1076 */     super.register();
/* 1077 */     this.display.addWidget(GTK.gtk_tree_view_get_selection(this.handle), this);
/*      */   }
/*      */   
/*      */   void releaseWidget()
/*      */   {
/* 1082 */     super.releaseWidget();
/* 1083 */     if (this.modelHandle != 0L) OS.g_object_unref(this.modelHandle);
/* 1084 */     this.modelHandle = 0L;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void remove(int index)
/*      */   {
/* 1102 */     checkWidget();
/* 1103 */     if ((0 > index) || (index >= GTK.gtk_tree_model_iter_n_children(this.modelHandle, 0L))) {
/* 1104 */       error(6);
/*      */     }
/* 1106 */     long iter = OS.g_malloc(GTK.GtkTreeIter_sizeof());
/* 1107 */     GTK.gtk_tree_model_iter_nth_child(this.modelHandle, iter, 0L, index);
/* 1108 */     long selection = GTK.gtk_tree_view_get_selection(this.handle);
/* 1109 */     OS.g_signal_handlers_block_matched(selection, 16, 0, 0, 0L, 0L, 6L);
/* 1110 */     GTK.gtk_list_store_remove(this.modelHandle, iter);
/* 1111 */     OS.g_signal_handlers_unblock_matched(selection, 16, 0, 0, 0L, 0L, 6L);
/* 1112 */     OS.g_free(iter);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void remove(int start, int end)
/*      */   {
/* 1132 */     checkWidget();
/* 1133 */     if (start > end) return;
/* 1134 */     int count = GTK.gtk_tree_model_iter_n_children(this.modelHandle, 0L);
/* 1135 */     if ((0 > start) || (start > end) || (end >= count)) {
/* 1136 */       error(6);
/*      */     }
/* 1138 */     long iter = OS.g_malloc(GTK.GtkTreeIter_sizeof());
/* 1139 */     long selection = GTK.gtk_tree_view_get_selection(this.handle);
/* 1140 */     OS.g_signal_handlers_block_matched(selection, 16, 0, 0, 0L, 0L, 6L);
/* 1141 */     for (int index = end; index >= start; index--) {
/* 1142 */       GTK.gtk_tree_model_iter_nth_child(this.modelHandle, iter, 0L, index);
/* 1143 */       GTK.gtk_list_store_remove(this.modelHandle, iter);
/*      */     }
/* 1145 */     OS.g_signal_handlers_unblock_matched(selection, 16, 0, 0, 0L, 0L, 6L);
/* 1146 */     OS.g_free(iter);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void remove(String string)
/*      */   {
/* 1166 */     checkWidget();
/* 1167 */     if (string == null) error(4);
/* 1168 */     int index = indexOf(string, 0);
/* 1169 */     if (index == -1) error(5);
/* 1170 */     remove(index);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void remove(int[] indices)
/*      */   {
/* 1189 */     checkWidget();
/* 1190 */     if (indices == null) error(4);
/* 1191 */     if (indices.length == 0) return;
/* 1192 */     int[] newIndices = new int[indices.length];
/* 1193 */     System.arraycopy(indices, 0, newIndices, 0, indices.length);
/* 1194 */     sort(newIndices);
/* 1195 */     int start = newIndices[(newIndices.length - 1)];int end = newIndices[0];
/* 1196 */     int count = getItemCount();
/* 1197 */     if ((0 > start) || (start > end) || (end >= count)) {
/* 1198 */       error(6);
/*      */     }
/* 1200 */     long iter = OS.g_malloc(GTK.GtkTreeIter_sizeof());
/* 1201 */     long selection = GTK.gtk_tree_view_get_selection(this.handle);
/* 1202 */     OS.g_signal_handlers_block_matched(selection, 16, 0, 0, 0L, 0L, 6L);
/* 1203 */     int last = -1;
/* 1204 */     for (int i = 0; i < newIndices.length; i++) {
/* 1205 */       int index = newIndices[i];
/* 1206 */       if (index != last) {
/* 1207 */         GTK.gtk_tree_model_iter_nth_child(this.modelHandle, iter, 0L, index);
/* 1208 */         GTK.gtk_list_store_remove(this.modelHandle, iter);
/* 1209 */         last = index;
/*      */       }
/*      */     }
/* 1212 */     OS.g_signal_handlers_unblock_matched(selection, 16, 0, 0, 0L, 0L, 6L);
/* 1213 */     OS.g_free(iter);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeAll()
/*      */   {
/* 1225 */     checkWidget();
/* 1226 */     long selection = GTK.gtk_tree_view_get_selection(this.handle);
/* 1227 */     OS.g_signal_handlers_block_matched(selection, 16, 0, 0, 0L, 0L, 6L);
/* 1228 */     GTK.gtk_list_store_clear(this.modelHandle);
/* 1229 */     OS.g_signal_handlers_unblock_matched(selection, 16, 0, 0, 0L, 0L, 6L);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeSelectionListener(SelectionListener listener)
/*      */   {
/* 1250 */     checkWidget();
/* 1251 */     if (listener == null) error(4);
/* 1252 */     if (this.eventTable == null) return;
/* 1253 */     this.eventTable.unhook(13, listener);
/* 1254 */     this.eventTable.unhook(14, listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void select(int index)
/*      */   {
/* 1270 */     checkWidget();
/* 1271 */     if ((0 > index) || (index >= GTK.gtk_tree_model_iter_n_children(this.modelHandle, 0L))) return;
/* 1272 */     long iter = OS.g_malloc(GTK.GtkTreeIter_sizeof());
/* 1273 */     long selection = GTK.gtk_tree_view_get_selection(this.handle);
/* 1274 */     OS.g_signal_handlers_block_matched(selection, 16, 0, 0, 0L, 0L, 6L);
/* 1275 */     GTK.gtk_tree_model_iter_nth_child(this.modelHandle, iter, 0L, index);
/* 1276 */     GTK.gtk_tree_selection_select_iter(selection, iter);
/* 1277 */     if ((this.style & 0x4) != 0) {
/* 1278 */       long path = GTK.gtk_tree_model_get_path(this.modelHandle, iter);
/* 1279 */       GTK.gtk_tree_view_set_cursor(this.handle, path, 0L, false);
/* 1280 */       GTK.gtk_tree_path_free(path);
/*      */     }
/* 1282 */     OS.g_signal_handlers_unblock_matched(selection, 16, 0, 0, 0L, 0L, 6L);
/* 1283 */     OS.g_free(iter);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void select(int start, int end)
/*      */   {
/* 1309 */     checkWidget();
/* 1310 */     if ((end < 0) || (start > end) || (((this.style & 0x4) != 0) && (start != end))) return;
/* 1311 */     int count = GTK.gtk_tree_model_iter_n_children(this.modelHandle, 0L);
/* 1312 */     if ((count == 0) || (start >= count)) return;
/* 1313 */     start = Math.max(0, start);
/* 1314 */     end = Math.min(end, count - 1);
/* 1315 */     long iter = OS.g_malloc(GTK.GtkTreeIter_sizeof());
/* 1316 */     long selection = GTK.gtk_tree_view_get_selection(this.handle);
/* 1317 */     OS.g_signal_handlers_block_matched(selection, 16, 0, 0, 0L, 0L, 6L);
/* 1318 */     for (int index = start; index <= end; index++) {
/* 1319 */       GTK.gtk_tree_model_iter_nth_child(this.modelHandle, iter, 0L, index);
/* 1320 */       GTK.gtk_tree_selection_select_iter(selection, iter);
/* 1321 */       if ((this.style & 0x4) != 0) {
/* 1322 */         long path = GTK.gtk_tree_model_get_path(this.modelHandle, iter);
/* 1323 */         GTK.gtk_tree_view_set_cursor(this.handle, path, 0L, false);
/* 1324 */         GTK.gtk_tree_path_free(path);
/*      */       }
/*      */     }
/* 1327 */     OS.g_signal_handlers_unblock_matched(selection, 16, 0, 0, 0L, 0L, 6L);
/* 1328 */     OS.g_free(iter);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void select(int[] indices)
/*      */   {
/* 1354 */     checkWidget();
/* 1355 */     if (indices == null) error(4);
/* 1356 */     int length = indices.length;
/* 1357 */     if ((length == 0) || (((this.style & 0x4) != 0) && (length > 1))) return;
/* 1358 */     long iter = OS.g_malloc(GTK.GtkTreeIter_sizeof());
/* 1359 */     int count = GTK.gtk_tree_model_iter_n_children(this.modelHandle, 0L);
/* 1360 */     long selection = GTK.gtk_tree_view_get_selection(this.handle);
/* 1361 */     OS.g_signal_handlers_block_matched(selection, 16, 0, 0, 0L, 0L, 6L);
/* 1362 */     for (int i = 0; i < length; i++) {
/* 1363 */       int index = indices[i];
/* 1364 */       if ((0 <= index) && (index < count)) {
/* 1365 */         GTK.gtk_tree_model_iter_nth_child(this.modelHandle, iter, 0L, index);
/* 1366 */         GTK.gtk_tree_selection_select_iter(selection, iter);
/* 1367 */         if ((this.style & 0x4) != 0) {
/* 1368 */           long path = GTK.gtk_tree_model_get_path(this.modelHandle, iter);
/* 1369 */           GTK.gtk_tree_view_set_cursor(this.handle, path, 0L, false);
/* 1370 */           GTK.gtk_tree_path_free(path);
/*      */         }
/*      */       } }
/* 1373 */     OS.g_signal_handlers_unblock_matched(selection, 16, 0, 0, 0L, 0L, 6L);
/* 1374 */     OS.g_free(iter);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void selectAll()
/*      */   {
/* 1388 */     checkWidget();
/* 1389 */     if ((this.style & 0x4) != 0) return;
/* 1390 */     long selection = GTK.gtk_tree_view_get_selection(this.handle);
/* 1391 */     OS.g_signal_handlers_block_matched(selection, 16, 0, 0, 0L, 0L, 6L);
/* 1392 */     GTK.gtk_tree_selection_select_all(selection);
/* 1393 */     OS.g_signal_handlers_unblock_matched(selection, 16, 0, 0, 0L, 0L, 6L);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void selectFocusIndex(int index)
/*      */   {
/* 1402 */     int count = GTK.gtk_tree_model_iter_n_children(this.modelHandle, 0L);
/* 1403 */     if ((0 > index) || (index >= count)) return;
/* 1404 */     long iter = OS.g_malloc(GTK.GtkTreeIter_sizeof());
/* 1405 */     GTK.gtk_tree_model_iter_nth_child(this.modelHandle, iter, 0L, index);
/* 1406 */     long path = GTK.gtk_tree_model_get_path(this.modelHandle, iter);
/* 1407 */     long selection = GTK.gtk_tree_view_get_selection(this.handle);
/* 1408 */     OS.g_signal_handlers_block_matched(selection, 16, 0, 0, 0L, 0L, 6L);
/* 1409 */     GTK.gtk_tree_view_set_cursor(this.handle, path, 0L, false);
/* 1410 */     OS.g_signal_handlers_unblock_matched(selection, 16, 0, 0, 0L, 0L, 6L);
/* 1411 */     GTK.gtk_tree_path_free(path);
/* 1412 */     OS.g_free(iter);
/*      */   }
/*      */   
/*      */   void setBackgroundGdkColor(GdkColor color)
/*      */   {
/* 1417 */     assert (!GTK.GTK3) : "GTK2 code was run by GTK3";
/* 1418 */     super.setBackgroundGdkColor(color);
/* 1419 */     GTK.gtk_widget_modify_base(this.handle, 0, color);
/*      */   }
/*      */   
/*      */   int setBounds(int x, int y, int width, int height, boolean move, boolean resize)
/*      */   {
/* 1424 */     int result = super.setBounds(x, y, width, height, move, resize);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1433 */     GTK.gtk_widget_realize(this.handle);
/* 1434 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setItem(int index, String string)
/*      */   {
/* 1454 */     checkWidget();
/* 1455 */     if (string == null) error(4);
/* 1456 */     if ((0 > index) || (index >= GTK.gtk_tree_model_iter_n_children(this.modelHandle, 0L))) {
/* 1457 */       error(6);
/*      */     }
/* 1459 */     long iter = OS.g_malloc(GTK.GtkTreeIter_sizeof());
/* 1460 */     GTK.gtk_tree_model_iter_nth_child(this.modelHandle, iter, 0L, index);
/* 1461 */     byte[] buffer = Converter.wcsToMbcs(string, true);
/* 1462 */     GTK.gtk_list_store_set(this.modelHandle, iter, 0, buffer, -1);
/* 1463 */     OS.g_free(iter);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setItems(String... items)
/*      */   {
/* 1481 */     checkWidget();
/* 1482 */     if (items == null) error(4);
/* 1483 */     for (int i = 0; i < items.length; i++) {
/* 1484 */       if (items[i] == null) error(5);
/*      */     }
/* 1486 */     long selection = GTK.gtk_tree_view_get_selection(this.handle);
/* 1487 */     OS.g_signal_handlers_block_matched(selection, 16, 0, 0, 0L, 0L, 6L);
/* 1488 */     GTK.gtk_list_store_clear(this.modelHandle);
/* 1489 */     OS.g_signal_handlers_unblock_matched(selection, 16, 0, 0, 0L, 0L, 6L);
/* 1490 */     long iter = OS.g_malloc(GTK.GtkTreeIter_sizeof());
/* 1491 */     if (iter == 0L) error(14);
/* 1492 */     for (int i = 0; i < items.length; i++) {
/* 1493 */       String string = items[i];
/* 1494 */       byte[] buffer = Converter.wcsToMbcs(string, true);
/* 1495 */       GTK.gtk_list_store_append(this.modelHandle, iter);
/* 1496 */       GTK.gtk_list_store_set(this.modelHandle, iter, 0, buffer, -1);
/*      */     }
/* 1498 */     OS.g_free(iter);
/*      */   }
/*      */   
/*      */   void setForegroundGdkRGBA(GdkRGBA rgba)
/*      */   {
/* 1503 */     assert (GTK.GTK3) : "GTK3 code was run by GTK2";
/* 1504 */     if (GTK.GTK_VERSION >= OS.VERSION(3, 14, 0)) {
/* 1505 */       GdkRGBA toSet = rgba == null ? this.display.COLOR_LIST_FOREGROUND_RGBA : rgba;
/* 1506 */       setForegroundGdkRGBA(this.handle, toSet);
/*      */     } else {
/* 1508 */       super.setForegroundGdkRGBA(rgba);
/*      */     }
/*      */   }
/*      */   
/*      */   void setForegroundGdkColor(GdkColor color)
/*      */   {
/* 1514 */     assert (!GTK.GTK3) : "GTK2 code was run by GTK3";
/* 1515 */     setForegroundColor(this.handle, color, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSelection(int index)
/*      */   {
/* 1535 */     checkWidget();
/* 1536 */     deselectAll();
/* 1537 */     selectFocusIndex(index);
/* 1538 */     showSelection();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSelection(int start, int end)
/*      */   {
/* 1564 */     checkWidget();
/* 1565 */     deselectAll();
/* 1566 */     if ((end < 0) || (start > end) || (((this.style & 0x4) != 0) && (start != end))) return;
/* 1567 */     int count = GTK.gtk_tree_model_iter_n_children(this.modelHandle, 0L);
/* 1568 */     if ((count == 0) || (start >= count)) return;
/* 1569 */     start = Math.max(0, start);
/* 1570 */     end = Math.min(end, count - 1);
/* 1571 */     selectFocusIndex(start);
/* 1572 */     if ((this.style & 0x2) != 0) {
/* 1573 */       select(start, end);
/*      */     }
/* 1575 */     showSelection();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSelection(int[] indices)
/*      */   {
/* 1601 */     checkWidget();
/* 1602 */     if (indices == null) error(4);
/* 1603 */     deselectAll();
/* 1604 */     int length = indices.length;
/* 1605 */     if ((length == 0) || (((this.style & 0x4) != 0) && (length > 1))) return;
/* 1606 */     selectFocusIndex(indices[0]);
/* 1607 */     if ((this.style & 0x2) != 0) {
/* 1608 */       select(indices);
/*      */     }
/* 1610 */     showSelection();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSelection(String[] items)
/*      */   {
/* 1637 */     checkWidget();
/* 1638 */     if (items == null) error(4);
/* 1639 */     deselectAll();
/* 1640 */     int length = items.length;
/* 1641 */     if ((length == 0) || (((this.style & 0x4) != 0) && (length > 1))) return;
/* 1642 */     boolean first = true;
/* 1643 */     for (int i = 0; i < length; i++) {
/* 1644 */       int index = 0;
/* 1645 */       String string = items[i];
/* 1646 */       if (string != null) {
/* 1647 */         while ((index = indexOf(string, index)) != -1) {
/* 1648 */           if ((this.style & 0x2) != 0) {
/* 1649 */             if (first) {
/* 1650 */               first = false;
/* 1651 */               selectFocusIndex(index);
/*      */             } else {
/* 1653 */               select(index);
/*      */             }
/*      */           } else {
/* 1656 */             selectFocusIndex(index);
/* 1657 */             break;
/*      */           }
/* 1659 */           index++;
/*      */         }
/*      */       }
/*      */     }
/* 1663 */     showSelection();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTopIndex(int index)
/*      */   {
/* 1679 */     checkWidget();
/*      */     
/*      */ 
/*      */     long vAdjustment;
/*      */     
/*      */ 
/*      */     long vAdjustment;
/*      */     
/*      */ 
/* 1688 */     if (GTK.GTK3) {
/* 1689 */       vAdjustment = GTK.gtk_scrollable_get_vadjustment(this.handle);
/*      */     } else {
/* 1691 */       vAdjustment = GTK.gtk_tree_view_get_vadjustment(this.handle);
/*      */     }
/* 1693 */     this.cachedAdjustment = GTK.gtk_adjustment_get_value(vAdjustment);
/* 1694 */     this.topIndex = index;
/*      */     
/*      */ 
/*      */ 
/* 1698 */     if ((0 > index) || (index >= GTK.gtk_tree_model_iter_n_children(this.modelHandle, 0L))) return;
/* 1699 */     long iter = OS.g_malloc(GTK.GtkTreeIter_sizeof());
/* 1700 */     GTK.gtk_tree_model_iter_nth_child(this.modelHandle, iter, 0L, index);
/* 1701 */     long path = GTK.gtk_tree_model_get_path(this.modelHandle, iter);
/* 1702 */     GTK.gtk_tree_view_scroll_to_cell(this.handle, path, 0L, true, 0.0F, 0.0F);
/* 1703 */     GTK.gtk_tree_path_free(path);
/* 1704 */     OS.g_free(iter);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void showSelection()
/*      */   {
/* 1718 */     checkWidget();
/* 1719 */     int index = getSelectionIndex();
/* 1720 */     if (index == -1) return;
/* 1721 */     long iter = OS.g_malloc(GTK.GtkTreeIter_sizeof());
/* 1722 */     GTK.gtk_tree_model_iter_nth_child(this.modelHandle, iter, 0L, index);
/* 1723 */     long path = GTK.gtk_tree_model_get_path(this.modelHandle, iter);
/*      */     
/* 1725 */     GTK.gtk_widget_realize(this.handle);
/* 1726 */     GTK.gtk_tree_view_scroll_to_cell(this.handle, path, 0L, false, 0.0F, 0.0F);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1733 */     GdkRectangle visibleRect = new GdkRectangle();
/* 1734 */     GTK.gtk_tree_view_get_visible_rect(this.handle, visibleRect);
/* 1735 */     GdkRectangle cellRect = new GdkRectangle();
/* 1736 */     GTK.gtk_tree_view_get_cell_area(this.handle, path, 0L, cellRect);
/* 1737 */     int[] tx = new int[1];int[] ty = new int[1];
/* 1738 */     GTK.gtk_tree_view_convert_bin_window_to_tree_coords(this.handle, cellRect.x, cellRect.y, tx, ty);
/* 1739 */     if (ty[0] < visibleRect.y) {
/* 1740 */       GTK.gtk_tree_view_scroll_to_point(this.handle, -1, ty[0]);
/*      */     } else {
/* 1742 */       int height = Math.min(visibleRect.height, cellRect.height);
/* 1743 */       if (ty[0] + height > visibleRect.y + visibleRect.height) {
/* 1744 */         ty[0] += cellRect.height - visibleRect.height;
/* 1745 */         GTK.gtk_tree_view_scroll_to_point(this.handle, -1, ty[0]);
/*      */       }
/*      */     }
/* 1748 */     GTK.gtk_tree_path_free(path);
/* 1749 */     OS.g_free(iter);
/*      */   }
/*      */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/widgets/List.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */