/*     */ package org.eclipse.swt.graphics;
/*     */ 
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.eclipse.swt.SWT;
/*     */ import org.eclipse.swt.internal.image.FileFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ImageLoader
/*     */ {
/*     */   public ImageData[] data;
/*     */   public int logicalScreenWidth;
/*     */   public int logicalScreenHeight;
/*     */   public int backgroundPixel;
/*     */   public int repeatCount;
/*     */   public int compression;
/*     */   List<ImageLoaderListener> imageLoaderListeners;
/*     */   
/*     */   public ImageLoader()
/*     */   {
/* 115 */     reset();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   void reset()
/*     */   {
/* 123 */     this.data = null;
/* 124 */     this.logicalScreenWidth = 0;
/* 125 */     this.logicalScreenHeight = 0;
/* 126 */     this.backgroundPixel = -1;
/* 127 */     this.repeatCount = 1;
/* 128 */     this.compression = -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ImageData[] load(InputStream stream)
/*     */   {
/* 150 */     if (stream == null) SWT.error(4);
/* 151 */     reset();
/* 152 */     this.data = FileFormat.load(stream, this);
/* 153 */     return this.data;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ImageData[] load(String filename)
/*     */   {
/* 175 */     if (filename == null) SWT.error(4);
/* 176 */     InputStream stream = null;
/*     */     try {
/* 178 */       stream = new FileInputStream(filename);
/* 179 */       return load(stream);
/*     */     } catch (IOException e) {
/* 181 */       SWT.error(39, e);
/*     */     } finally {
/*     */       try {
/* 184 */         if (stream != null) { stream.close();
/*     */         }
/*     */       }
/*     */       catch (IOException localIOException3) {}
/*     */     }
/* 189 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void save(OutputStream stream, int format)
/*     */   {
/* 223 */     if (stream == null) SWT.error(4);
/* 224 */     FileFormat.save(stream, format, this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void save(String filename, int format)
/*     */   {
/* 258 */     if (filename == null) SWT.error(4);
/* 259 */     OutputStream stream = null;
/*     */     try {
/* 261 */       stream = new FileOutputStream(filename);
/*     */     } catch (IOException e) {
/* 263 */       SWT.error(39, e);
/*     */     }
/* 265 */     save(stream, format);
/*     */     try {
/* 267 */       stream.close();
/*     */     }
/*     */     catch (IOException localIOException1) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addImageLoaderListener(ImageLoaderListener listener)
/*     */   {
/* 292 */     if (listener == null) SWT.error(4);
/* 293 */     if (this.imageLoaderListeners == null) {
/* 294 */       this.imageLoaderListeners = new ArrayList();
/*     */     }
/* 296 */     this.imageLoaderListeners.add(listener);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeImageLoaderListener(ImageLoaderListener listener)
/*     */   {
/* 312 */     if (listener == null) SWT.error(4);
/* 313 */     if (this.imageLoaderListeners == null) return;
/* 314 */     this.imageLoaderListeners.remove(listener);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean hasListeners()
/*     */   {
/* 327 */     return (this.imageLoaderListeners != null) && (this.imageLoaderListeners.size() > 0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void notifyListeners(ImageLoaderEvent event)
/*     */   {
/* 337 */     if (!hasListeners()) return;
/* 338 */     int size = this.imageLoaderListeners.size();
/* 339 */     for (int i = 0; i < size; i++) {
/* 340 */       ImageLoaderListener listener = (ImageLoaderListener)this.imageLoaderListeners.get(i);
/* 341 */       listener.imageDataLoaded(event);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/graphics/ImageLoader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */