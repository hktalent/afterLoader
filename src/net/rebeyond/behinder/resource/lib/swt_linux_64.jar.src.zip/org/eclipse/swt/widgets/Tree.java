/*      */ package org.eclipse.swt.widgets;
/*      */ 
/*      */ import org.eclipse.swt.events.SelectionListener;
/*      */ import org.eclipse.swt.events.TreeListener;
/*      */ import org.eclipse.swt.graphics.Color;
/*      */ import org.eclipse.swt.graphics.Font;
/*      */ import org.eclipse.swt.graphics.GC;
/*      */ import org.eclipse.swt.graphics.GCData;
/*      */ import org.eclipse.swt.graphics.Image;
/*      */ import org.eclipse.swt.graphics.Point;
/*      */ import org.eclipse.swt.graphics.Rectangle;
/*      */ import org.eclipse.swt.internal.C;
/*      */ import org.eclipse.swt.internal.Converter;
/*      */ import org.eclipse.swt.internal.DPIUtil;
/*      */ import org.eclipse.swt.internal.ImageList;
/*      */ import org.eclipse.swt.internal.cairo.Cairo;
/*      */ import org.eclipse.swt.internal.gtk.GDK;
/*      */ import org.eclipse.swt.internal.gtk.GTK;
/*      */ import org.eclipse.swt.internal.gtk.GdkColor;
/*      */ import org.eclipse.swt.internal.gtk.GdkEventButton;
/*      */ import org.eclipse.swt.internal.gtk.GdkEventExpose;
/*      */ import org.eclipse.swt.internal.gtk.GdkEventKey;
/*      */ import org.eclipse.swt.internal.gtk.GdkRGBA;
/*      */ import org.eclipse.swt.internal.gtk.GdkRectangle;
/*      */ import org.eclipse.swt.internal.gtk.GtkAllocation;
/*      */ import org.eclipse.swt.internal.gtk.GtkCellRendererClass;
/*      */ import org.eclipse.swt.internal.gtk.GtkRequisition;
/*      */ import org.eclipse.swt.internal.gtk.OS;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class Tree
/*      */   extends Composite
/*      */ {
/*      */   long modelHandle;
/*      */   long checkRenderer;
/*      */   int columnCount;
/*      */   int sortDirection;
/*      */   int selectionCountOnPress;
/*      */   int selectionCountOnRelease;
/*      */   long ignoreCell;
/*      */   TreeItem[] items;
/*      */   TreeColumn[] columns;
/*      */   TreeColumn sortColumn;
/*      */   TreeItem currentItem;
/*      */   ImageList imageList;
/*      */   ImageList headerImageList;
/*      */   boolean firstCustomDraw;
/*      */   boolean modelChanged;
/*      */   boolean expandAll;
/*      */   int drawState;
/*      */   int drawFlags;
/*      */   GdkColor drawForeground;
/*      */   GdkRGBA background;
/*      */   GdkRGBA foreground;
/*      */   GdkRGBA drawForegroundRGBA;
/*      */   boolean ownerDraw;
/*      */   boolean ignoreSize;
/*      */   boolean ignoreAccessibility;
/*      */   boolean pixbufSizeSet;
/*      */   boolean hasChildren;
/*      */   int pixbufHeight;
/*      */   int pixbufWidth;
/*      */   TreeItem topItem;
/*      */   double cachedAdjustment;
/*      */   double currentAdjustment;
/*      */   Color headerBackground;
/*      */   Color headerForeground;
/*      */   String headerCSSBackground;
/*      */   String headerCSSForeground;
/*      */   static final int ID_COLUMN = 0;
/*      */   static final int CHECKED_COLUMN = 1;
/*      */   static final int GRAYED_COLUMN = 2;
/*      */   static final int FOREGROUND_COLUMN = 3;
/*      */   static final int BACKGROUND_COLUMN = 4;
/*      */   static final int FONT_COLUMN = 5;
/*      */   static final int FIRST_COLUMN = 6;
/*      */   static final int CELL_PIXBUF = 0;
/*      */   static final int CELL_TEXT = 1;
/*      */   static final int CELL_FOREGROUND = 2;
/*      */   static final int CELL_BACKGROUND = 3;
/*      */   static final int CELL_FONT = 4;
/*      */   static final int CELL_TYPES = 5;
/*      */   
/*      */   public Tree(Composite parent, int style)
/*      */   {
/*  149 */     super(parent, checkStyle(style));
/*      */   }
/*      */   
/*      */   void _addListener(int eventType, Listener listener)
/*      */   {
/*  154 */     super._addListener(eventType, listener);
/*  155 */     if (!this.ownerDraw) {
/*  156 */       switch (eventType) {
/*      */       case 40: 
/*      */       case 41: 
/*      */       case 42: 
/*  160 */         this.ownerDraw = true;
/*  161 */         recreateRenderers();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   TreeItem _getItem(long iter)
/*      */   {
/*  168 */     int id = getId(iter, true);
/*  169 */     if (this.items[id] != null) return this.items[id];
/*  170 */     long path = GTK.gtk_tree_model_get_path(this.modelHandle, iter);
/*  171 */     int depth = GTK.gtk_tree_path_get_depth(path);
/*  172 */     int[] indices = new int[depth];
/*  173 */     C.memmove(indices, GTK.gtk_tree_path_get_indices(path), 4 * depth);
/*  174 */     long parentIter = 0L;
/*  175 */     if (depth > 1) {
/*  176 */       GTK.gtk_tree_path_up(path);
/*  177 */       parentIter = OS.g_malloc(GTK.GtkTreeIter_sizeof());
/*  178 */       GTK.gtk_tree_model_get_iter(this.modelHandle, parentIter, path);
/*      */     }
/*  180 */     this.items[id] = new TreeItem(this, parentIter, 0, indices[(indices.length - 1)], false);
/*  181 */     GTK.gtk_tree_path_free(path);
/*  182 */     if (parentIter != 0L) OS.g_free(parentIter);
/*  183 */     return this.items[id];
/*      */   }
/*      */   
/*      */   TreeItem _getItem(long parentIter, int index) {
/*  187 */     long iter = OS.g_malloc(GTK.GtkTreeIter_sizeof());
/*  188 */     GTK.gtk_tree_model_iter_nth_child(this.modelHandle, iter, parentIter, index);
/*  189 */     int id = getId(iter, true);
/*  190 */     OS.g_free(iter);
/*  191 */     if (this.items[id] != null) return this.items[id];
/*  192 */     return this.items[id] = new TreeItem(this, parentIter, 0, index, false);
/*      */   }
/*      */   
/*      */   int getId(long iter, boolean queryModel) {
/*  196 */     if (queryModel) {
/*  197 */       int[] value = new int[1];
/*  198 */       GTK.gtk_tree_model_get(this.modelHandle, iter, 0, value, -1);
/*  199 */       if (value[0] != -1) { return value[0];
/*      */       }
/*      */     }
/*  202 */     int id = 0;
/*  203 */     while ((id < this.items.length) && (this.items[id] != null)) id++;
/*  204 */     if (id == this.items.length) {
/*  205 */       TreeItem[] newItems = new TreeItem[this.items.length + 4];
/*  206 */       System.arraycopy(this.items, 0, newItems, 0, this.items.length);
/*  207 */       this.items = newItems;
/*      */     }
/*  209 */     GTK.gtk_tree_store_set(this.modelHandle, iter, 0, id, -1);
/*  210 */     return id;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   static int checkStyle(int style)
/*      */   {
/*  223 */     if ((style & 0x10) == 0) {
/*  224 */       style |= 0x300;
/*      */     }
/*      */     
/*  227 */     style |= 0x10000;
/*  228 */     return checkBits(style, 4, 2, 0, 0, 0, 0);
/*      */   }
/*      */   
/*      */   long cellDataProc(long tree_column, long cell, long tree_model, long iter, long data)
/*      */   {
/*  233 */     if (cell == this.ignoreCell) return 0L;
/*  234 */     TreeItem item = _getItem(iter);
/*  235 */     if (item != null) OS.g_object_set_qdata(cell, Display.SWT_OBJECT_INDEX2, item.handle);
/*  236 */     boolean isPixbuf = GTK.GTK_IS_CELL_RENDERER_PIXBUF(cell);
/*  237 */     boolean isText = GTK.GTK_IS_CELL_RENDERER_TEXT(cell);
/*  238 */     if ((isText) && (GTK.GTK3)) {
/*  239 */       GTK.gtk_cell_renderer_set_fixed_size(cell, -1, -1);
/*      */     }
/*  241 */     if ((!isPixbuf) && (!isText)) return 0L;
/*  242 */     int modelIndex = -1;
/*  243 */     boolean customDraw = false;
/*  244 */     if (this.columnCount == 0) {
/*  245 */       modelIndex = 6;
/*  246 */       customDraw = this.firstCustomDraw;
/*      */     } else {
/*  248 */       TreeColumn column = (TreeColumn)this.display.getWidget(tree_column);
/*  249 */       if (column != null) {
/*  250 */         modelIndex = column.modelIndex;
/*  251 */         customDraw = column.customDraw;
/*      */       }
/*      */     }
/*  254 */     if (modelIndex == -1) return 0L;
/*  255 */     boolean setData = false;
/*  256 */     if (((this.style & 0x10000000) != 0) && 
/*  257 */       (!item.cached))
/*      */     {
/*  259 */       setData = checkData(item);
/*      */     }
/*      */     
/*  262 */     long[] ptr = new long[1];
/*  263 */     if (setData) {
/*  264 */       if (isPixbuf) {
/*  265 */         ptr[0] = 0L;
/*  266 */         GTK.gtk_tree_model_get(tree_model, iter, modelIndex + 0, ptr, -1);
/*  267 */         OS.g_object_set(cell, GTK.GTK3 ? OS.gicon : OS.pixbuf, ptr[0], 0L);
/*  268 */         if (ptr[0] != 0L) OS.g_object_unref(ptr[0]);
/*      */       } else {
/*  270 */         ptr[0] = 0L;
/*  271 */         GTK.gtk_tree_model_get(tree_model, iter, modelIndex + 1, ptr, -1);
/*  272 */         if (ptr[0] != 0L) {
/*  273 */           OS.g_object_set(cell, OS.text, ptr[0], 0L);
/*  274 */           OS.g_free(ptr[0]);
/*      */         }
/*      */       }
/*      */     }
/*  278 */     if (customDraw) {
/*  279 */       if (!this.ownerDraw) {
/*  280 */         ptr[0] = 0L;
/*  281 */         GTK.gtk_tree_model_get(tree_model, iter, modelIndex + 3, ptr, -1);
/*  282 */         if (ptr[0] != 0L) {
/*  283 */           if (GTK.GTK3) {
/*  284 */             OS.g_object_set(cell, OS.cell_background_rgba, ptr[0], 0L);
/*  285 */             GDK.gdk_rgba_free(ptr[0]);
/*      */           } else {
/*  287 */             OS.g_object_set(cell, OS.cell_background_gdk, ptr[0], 0L);
/*  288 */             GDK.gdk_color_free(ptr[0]);
/*      */           }
/*      */         }
/*      */       }
/*  292 */       if (!isPixbuf) {
/*  293 */         ptr[0] = 0L;
/*  294 */         GTK.gtk_tree_model_get(tree_model, iter, modelIndex + 2, ptr, -1);
/*  295 */         if (ptr[0] != 0L) {
/*  296 */           if (GTK.GTK3) {
/*  297 */             OS.g_object_set(cell, OS.foreground_rgba, ptr[0], 0L);
/*  298 */             GDK.gdk_rgba_free(ptr[0]);
/*      */           } else {
/*  300 */             OS.g_object_set(cell, OS.foreground_gdk, ptr[0], 0L);
/*  301 */             GDK.gdk_color_free(ptr[0]);
/*      */           }
/*      */         }
/*  304 */         ptr[0] = 0L;
/*  305 */         GTK.gtk_tree_model_get(tree_model, iter, modelIndex + 4, ptr, -1);
/*  306 */         if (ptr[0] != 0L) {
/*  307 */           OS.g_object_set(cell, OS.font_desc, ptr[0], 0L);
/*  308 */           OS.pango_font_description_free(ptr[0]);
/*      */         }
/*      */       }
/*      */     }
/*  312 */     if (setData) {
/*  313 */       this.ignoreCell = cell;
/*  314 */       setScrollWidth(tree_column, item);
/*  315 */       this.ignoreCell = 0L;
/*      */     }
/*  317 */     return 0L;
/*      */   }
/*      */   
/*      */   boolean checkData(TreeItem item) {
/*  321 */     if (item.cached) return true;
/*  322 */     if ((this.style & 0x10000000) != 0) {
/*  323 */       item.cached = true;
/*  324 */       TreeItem parentItem = item.getParentItem();
/*  325 */       Event event = new Event();
/*  326 */       event.item = item;
/*  327 */       event.index = (parentItem == null ? indexOf(item) : parentItem.indexOf(item));
/*  328 */       int mask = 17;
/*  329 */       int signal_id = OS.g_signal_lookup(OS.row_changed, GTK.gtk_tree_model_get_type());
/*  330 */       OS.g_signal_handlers_block_matched(this.modelHandle, mask, signal_id, 0, 0L, 0L, this.handle);
/*  331 */       this.currentItem = item;
/*  332 */       sendEvent(36, event);
/*  333 */       this.currentItem = null;
/*      */       
/*  335 */       if (isDisposed()) return false;
/*  336 */       OS.g_signal_handlers_unblock_matched(this.modelHandle, mask, signal_id, 0, 0L, 0L, this.handle);
/*  337 */       if (item.isDisposed()) return false;
/*      */     }
/*  339 */     return true;
/*      */   }
/*      */   
/*      */   protected void checkSubclass()
/*      */   {
/*  344 */     if (!isValidSubclass()) { error(43);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addSelectionListener(SelectionListener listener)
/*      */   {
/*  375 */     checkWidget();
/*  376 */     if (listener == null) error(4);
/*  377 */     TypedListener typedListener = new TypedListener(listener);
/*  378 */     addListener(13, typedListener);
/*  379 */     addListener(14, typedListener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addTreeListener(TreeListener listener)
/*      */   {
/*  402 */     checkWidget();
/*  403 */     if (listener == null) error(4);
/*  404 */     TypedListener typedListener = new TypedListener(listener);
/*  405 */     addListener(17, typedListener);
/*  406 */     addListener(18, typedListener);
/*      */   }
/*      */   
/*      */   int calculateWidth(long column, long iter, boolean recurse) {
/*  410 */     GTK.gtk_tree_view_column_cell_set_cell_data(column, this.modelHandle, iter, false, false);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  421 */     int width = 0;
/*  422 */     int[] w = new int[1];
/*  423 */     long path = 0L;
/*      */     
/*  425 */     if (GTK.gtk_tree_view_get_expander_column(this.handle) == column)
/*      */     {
/*  427 */       GdkRectangle rect = new GdkRectangle();
/*  428 */       GTK.gtk_widget_realize(this.handle);
/*  429 */       path = GTK.gtk_tree_model_get_path(this.modelHandle, iter);
/*  430 */       GTK.gtk_tree_view_get_cell_area(this.handle, path, column, rect);
/*  431 */       width += rect.x;
/*      */       
/*  433 */       GTK.gtk_widget_style_get(this.handle, OS.expander_size, w, 0L);
/*  434 */       width += w[0] + 4;
/*      */     }
/*  436 */     GTK.gtk_widget_style_get(this.handle, OS.focus_line_width, w, 0L);
/*  437 */     width += 2 * w[0];
/*  438 */     long list = GTK.gtk_cell_layout_get_cells(column);
/*  439 */     if (list == 0L) return 0;
/*  440 */     long temp = list;
/*  441 */     while (temp != 0L) {
/*  442 */       long renderer = OS.g_list_data(temp);
/*  443 */       if (renderer != 0L) {
/*  444 */         gtk_cell_renderer_get_preferred_size(renderer, this.handle, w, null);
/*  445 */         width += w[0];
/*      */       }
/*  447 */       temp = OS.g_list_next(temp);
/*      */     }
/*  449 */     OS.g_list_free(list);
/*      */     
/*  451 */     if (recurse) {
/*  452 */       if (path == 0L) path = GTK.gtk_tree_model_get_path(this.modelHandle, iter);
/*  453 */       boolean expanded = GTK.gtk_tree_view_row_expanded(this.handle, path);
/*  454 */       if (expanded) {
/*  455 */         long childIter = OS.g_malloc(GTK.GtkTreeIter_sizeof());
/*  456 */         boolean valid = GTK.gtk_tree_model_iter_children(this.modelHandle, childIter, iter);
/*  457 */         while (valid) {
/*  458 */           width = Math.max(width, calculateWidth(column, childIter, true));
/*  459 */           valid = GTK.gtk_tree_model_iter_next(this.modelHandle, childIter);
/*      */         }
/*  461 */         OS.g_free(childIter);
/*      */       }
/*      */     }
/*      */     
/*  465 */     if (path != 0L) GTK.gtk_tree_path_free(path);
/*  466 */     if (GTK.gtk_tree_view_get_grid_lines(this.handle) > 0) {
/*  467 */       GTK.gtk_widget_style_get(this.handle, OS.grid_line_width, w, 0L);
/*  468 */       width += 2 * w[0];
/*      */     }
/*  470 */     return width;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void clear(int index, boolean all)
/*      */   {
/*  497 */     checkWidget();
/*  498 */     clear(0L, index, all);
/*      */   }
/*      */   
/*      */   void clear(long parentIter, int index, boolean all) {
/*  502 */     long iter = OS.g_malloc(GTK.GtkTreeIter_sizeof());
/*  503 */     GTK.gtk_tree_model_iter_nth_child(this.modelHandle, iter, parentIter, index);
/*  504 */     int[] value = new int[1];
/*  505 */     GTK.gtk_tree_model_get(this.modelHandle, iter, 0, value, -1);
/*  506 */     if (value[0] != -1) {
/*  507 */       TreeItem item = this.items[value[0]];
/*  508 */       item.clear();
/*      */     }
/*  510 */     if (all) clearAll(all, iter);
/*  511 */     OS.g_free(iter);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void clearAll(boolean all)
/*      */   {
/*  534 */     checkWidget();
/*  535 */     clearAll(all, 0L);
/*      */   }
/*      */   
/*  538 */   void clearAll(boolean all, long parentIter) { int length = GTK.gtk_tree_model_iter_n_children(this.modelHandle, parentIter);
/*  539 */     if (length == 0) return;
/*  540 */     long iter = OS.g_malloc(GTK.GtkTreeIter_sizeof());
/*  541 */     boolean valid = GTK.gtk_tree_model_iter_children(this.modelHandle, iter, parentIter);
/*  542 */     int[] value = new int[1];
/*  543 */     while (valid) {
/*  544 */       GTK.gtk_tree_model_get(this.modelHandle, iter, 0, value, -1);
/*  545 */       if (value[0] != -1) {
/*  546 */         TreeItem item = this.items[value[0]];
/*  547 */         item.clear();
/*      */       }
/*  549 */       if (all) clearAll(all, iter);
/*  550 */       valid = GTK.gtk_tree_model_iter_next(this.modelHandle, iter);
/*      */     }
/*  552 */     OS.g_free(iter);
/*      */   }
/*      */   
/*      */   Point computeSizeInPixels(int wHint, int hHint, boolean changed)
/*      */   {
/*  557 */     checkWidget();
/*  558 */     if ((wHint != -1) && (wHint < 0)) wHint = 0;
/*  559 */     if ((hHint != -1) && (hHint < 0)) hHint = 0;
/*  560 */     GTK.gtk_widget_realize(this.handle);
/*  561 */     Point size = computeNativeSize(this.handle, wHint, hHint, changed);
/*  562 */     if ((size.x == 0) && (wHint == -1)) { size.x = 64;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  572 */     if ((GTK.GTK3) && (hHint == -1) && (size.y == getHeaderHeight())) {
/*  573 */       size.y = (getItemCount() * getItemHeightInPixels() + getHeaderHeight());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  581 */     if ((size.y == 0) && (hHint == -1)) size.y = 64;
/*  582 */     Rectangle trim = computeTrimInPixels(0, 0, size.x, size.y);
/*  583 */     size.x = trim.width;
/*  584 */     size.y = trim.height;
/*  585 */     return size;
/*      */   }
/*      */   
/*      */   void copyModel(long oldModel, int oldStart, long newModel, int newStart, long[] types, long oldParent, long newParent, int modelLength) {
/*  589 */     long iter = OS.g_malloc(GTK.GtkTreeIter_sizeof());
/*  590 */     if (GTK.gtk_tree_model_iter_children(oldModel, iter, oldParent)) {
/*  591 */       long[] oldItems = new long[GTK.gtk_tree_model_iter_n_children(oldModel, oldParent)];
/*  592 */       int oldIndex = 0;
/*  593 */       long[] ptr = new long[1];
/*  594 */       int[] ptr1 = new int[1];
/*      */       do {
/*  596 */         long newItem = OS.g_malloc(GTK.GtkTreeIter_sizeof());
/*  597 */         if (newItem == 0L) error(2);
/*  598 */         GTK.gtk_tree_store_append(newModel, newItem, newParent);
/*  599 */         GTK.gtk_tree_model_get(oldModel, iter, 0, ptr1, -1);
/*  600 */         int index = ptr1[0];
/*  601 */         TreeItem item = null;
/*  602 */         if (index != -1) {
/*  603 */           item = this.items[index];
/*  604 */           if (item != null) {
/*  605 */             long oldItem = item.handle;
/*  606 */             oldItems[(oldIndex++)] = oldItem;
/*      */             
/*  608 */             for (int j = 0; j < 3; j++) {
/*  609 */               GTK.gtk_tree_model_get(oldModel, oldItem, j, ptr1, -1);
/*  610 */               GTK.gtk_tree_store_set(newModel, newItem, j, ptr1[0], -1);
/*      */             }
/*  612 */             for (int j = 3; j < 6; j++) {
/*  613 */               GTK.gtk_tree_model_get(oldModel, oldItem, j, ptr, -1);
/*  614 */               GTK.gtk_tree_store_set(newModel, newItem, j, ptr[0], -1);
/*  615 */               if (ptr[0] != 0L) {
/*  616 */                 if (GTK.GTK3) {
/*  617 */                   if (types[j] == GDK.GDK_TYPE_RGBA()) {
/*  618 */                     GDK.gdk_rgba_free(ptr[0]);
/*      */                   }
/*      */                 }
/*  621 */                 else if (types[j] == GDK.GDK_TYPE_COLOR()) {
/*  622 */                   GDK.gdk_color_free(ptr[0]);
/*      */                 }
/*      */                 
/*  625 */                 if (types[j] == OS.G_TYPE_STRING()) {
/*  626 */                   OS.g_free(ptr[0]);
/*  627 */                 } else if (types[j] == GDK.GDK_TYPE_PIXBUF()) {
/*  628 */                   OS.g_object_unref(ptr[0]);
/*  629 */                 } else if (types[j] == OS.PANGO_TYPE_FONT_DESCRIPTION()) {
/*  630 */                   OS.pango_font_description_free(ptr[0]);
/*      */                 }
/*      */               }
/*      */             }
/*  634 */             for (int j = 0; j < modelLength - 6; j++) {
/*  635 */               int newIndex = newStart + j;
/*  636 */               GTK.gtk_tree_model_get(oldModel, oldItem, oldStart + j, ptr, -1);
/*  637 */               GTK.gtk_tree_store_set(newModel, newItem, newIndex, ptr[0], -1);
/*  638 */               if (ptr[0] != 0L) {
/*  639 */                 if (GTK.GTK3) {
/*  640 */                   if (types[newIndex] == GDK.GDK_TYPE_RGBA()) {
/*  641 */                     GDK.gdk_rgba_free(ptr[0]);
/*      */                   }
/*      */                 }
/*  644 */                 else if (types[newIndex] == GDK.GDK_TYPE_COLOR()) {
/*  645 */                   GDK.gdk_color_free(ptr[0]);
/*      */                 }
/*      */                 
/*  648 */                 if (types[newIndex] == OS.G_TYPE_STRING()) {
/*  649 */                   OS.g_free(ptr[0]);
/*  650 */                 } else if (types[newIndex] == GDK.GDK_TYPE_PIXBUF()) {
/*  651 */                   OS.g_object_unref(ptr[0]);
/*  652 */                 } else if (types[newIndex] == OS.PANGO_TYPE_FONT_DESCRIPTION()) {
/*  653 */                   OS.pango_font_description_free(ptr[0]);
/*      */                 }
/*      */               }
/*      */             }
/*      */           }
/*      */         } else {
/*  659 */           GTK.gtk_tree_store_set(newModel, newItem, 0, -1, -1);
/*      */         }
/*      */         
/*  662 */         copyModel(oldModel, oldStart, newModel, newStart, types, iter, newItem, modelLength);
/*      */         
/*  664 */         if (item != null) {
/*  665 */           item.handle = newItem;
/*      */         } else {
/*  667 */           OS.g_free(newItem);
/*      */         }
/*  669 */       } while (GTK.gtk_tree_model_iter_next(oldModel, iter));
/*  670 */       for (int i = 0; i < oldItems.length; i++) {
/*  671 */         long oldItem = oldItems[i];
/*  672 */         if (oldItem != 0L) {
/*  673 */           GTK.gtk_tree_store_remove(oldModel, oldItem);
/*  674 */           OS.g_free(oldItem);
/*      */         }
/*      */       }
/*      */     }
/*  678 */     OS.g_free(iter);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void createColumn(TreeColumn column, int index)
/*      */   {
/*  689 */     int modelIndex = 6;
/*  690 */     if (this.columnCount != 0) {
/*  691 */       int modelLength = GTK.gtk_tree_model_get_n_columns(this.modelHandle);
/*  692 */       boolean[] usedColumns = new boolean[modelLength];
/*  693 */       for (int i = 0; i < this.columnCount; i++) {
/*  694 */         int columnIndex = this.columns[i].modelIndex;
/*  695 */         for (int j = 0; j < 5; j++) {
/*  696 */           usedColumns[(columnIndex + j)] = true;
/*      */         }
/*      */       }
/*  699 */       while ((modelIndex < modelLength) && 
/*  700 */         (usedColumns[modelIndex] != 0)) {
/*  701 */         modelIndex++;
/*      */       }
/*  703 */       if (modelIndex == modelLength) {
/*  704 */         long oldModel = this.modelHandle;
/*  705 */         long[] types = getColumnTypes(this.columnCount + 4);
/*  706 */         long newModel = GTK.gtk_tree_store_newv(types.length, types);
/*  707 */         if (newModel == 0L) error(2);
/*  708 */         copyModel(oldModel, 6, newModel, 6, types, 0L, 0L, modelLength);
/*  709 */         GTK.gtk_tree_view_set_model(this.handle, newModel);
/*  710 */         setModel(newModel);
/*      */       }
/*      */     }
/*  713 */     long columnHandle = GTK.gtk_tree_view_column_new();
/*  714 */     if (columnHandle == 0L) error(2);
/*  715 */     if ((index == 0) && (this.columnCount > 0)) {
/*  716 */       TreeColumn checkColumn = this.columns[0];
/*  717 */       createRenderers(checkColumn.handle, checkColumn.modelIndex, false, checkColumn.style);
/*      */     }
/*  719 */     createRenderers(columnHandle, modelIndex, index == 0, column == null ? 0 : column.style);
/*  720 */     if (((this.style & 0x10000000) == 0) && (this.columnCount == 0)) {
/*  721 */       GTK.gtk_tree_view_column_set_sizing(columnHandle, 0);
/*      */     } else {
/*  723 */       GTK.gtk_tree_view_column_set_sizing(columnHandle, 2);
/*      */     }
/*  725 */     GTK.gtk_tree_view_column_set_resizable(columnHandle, true);
/*  726 */     GTK.gtk_tree_view_column_set_clickable(columnHandle, true);
/*  727 */     GTK.gtk_tree_view_column_set_min_width(columnHandle, 0);
/*  728 */     GTK.gtk_tree_view_insert_column(this.handle, columnHandle, index);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  734 */     if (this.columnCount != 0) GTK.gtk_tree_view_column_set_visible(columnHandle, false);
/*  735 */     if (column != null) {
/*  736 */       column.handle = columnHandle;
/*  737 */       column.modelIndex = modelIndex;
/*      */     }
/*  739 */     if (!searchEnabled()) {
/*  740 */       GTK.gtk_tree_view_set_search_column(this.handle, -1);
/*      */     }
/*      */     else {
/*  743 */       int firstColumn = this.columnCount == 0 ? 6 : this.columns[0].modelIndex;
/*  744 */       GTK.gtk_tree_view_set_search_column(this.handle, firstColumn + 1);
/*      */     }
/*      */   }
/*      */   
/*      */   void createHandle(int index)
/*      */   {
/*  750 */     this.state |= 0x8;
/*  751 */     this.fixedHandle = OS.g_object_new(this.display.gtk_fixed_get_type(), 0L);
/*  752 */     if (this.fixedHandle == 0L) error(2);
/*  753 */     GTK.gtk_widget_set_has_window(this.fixedHandle, true);
/*  754 */     this.scrolledHandle = GTK.gtk_scrolled_window_new(0L, 0L);
/*  755 */     if (this.scrolledHandle == 0L) error(2);
/*  756 */     long[] types = getColumnTypes(1);
/*  757 */     this.modelHandle = GTK.gtk_tree_store_newv(types.length, types);
/*  758 */     if (this.modelHandle == 0L) error(2);
/*  759 */     this.handle = GTK.gtk_tree_view_new_with_model(this.modelHandle);
/*  760 */     if (this.handle == 0L) error(2);
/*  761 */     if ((this.style & 0x20) != 0) {
/*  762 */       this.checkRenderer = GTK.gtk_cell_renderer_toggle_new();
/*  763 */       if (this.checkRenderer == 0L) error(2);
/*  764 */       OS.g_object_ref(this.checkRenderer);
/*      */     }
/*  766 */     createColumn(null, 0);
/*  767 */     GTK.gtk_container_add(this.fixedHandle, this.scrolledHandle);
/*  768 */     GTK.gtk_container_add(this.scrolledHandle, this.handle);
/*      */     
/*  770 */     int mode = (this.style & 0x2) != 0 ? 3 : 2;
/*  771 */     long selectionHandle = GTK.gtk_tree_view_get_selection(this.handle);
/*  772 */     GTK.gtk_tree_selection_set_mode(selectionHandle, mode);
/*  773 */     GTK.gtk_tree_view_set_headers_visible(this.handle, false);
/*  774 */     int hsp = (this.style & 0x100) != 0 ? 1 : 2;
/*  775 */     int vsp = (this.style & 0x200) != 0 ? 1 : 2;
/*  776 */     GTK.gtk_scrolled_window_set_policy(this.scrolledHandle, hsp, vsp);
/*  777 */     if ((this.style & 0x800) != 0) { GTK.gtk_scrolled_window_set_shadow_type(this.scrolledHandle, 3);
/*      */     }
/*      */     
/*      */ 
/*  781 */     if ((this.style & 0x10000000) != 0) {
/*  782 */       OS.g_object_set(this.handle, OS.fixed_height_mode, true, 0L);
/*      */     }
/*  784 */     if (!searchEnabled()) {
/*  785 */       GTK.gtk_tree_view_set_search_column(this.handle, -1);
/*      */     }
/*      */   }
/*      */   
/*      */   int applyThemeBackground()
/*      */   {
/*  791 */     return -1;
/*      */   }
/*      */   
/*      */   void createItem(TreeColumn column, int index) {
/*  795 */     if ((0 > index) || (index > this.columnCount)) error(6);
/*  796 */     if (index == 0)
/*      */     {
/*  798 */       column.style &= 0xFEFDBFFF;
/*  799 */       column.style |= 0x4000;
/*      */     }
/*  801 */     if (this.columnCount == 0) {
/*  802 */       column.handle = GTK.gtk_tree_view_get_column(this.handle, 0);
/*  803 */       GTK.gtk_tree_view_column_set_sizing(column.handle, 2);
/*  804 */       GTK.gtk_tree_view_column_set_visible(column.handle, false);
/*  805 */       column.modelIndex = 6;
/*  806 */       createRenderers(column.handle, column.modelIndex, true, column.style);
/*  807 */       column.customDraw = this.firstCustomDraw;
/*  808 */       this.firstCustomDraw = false;
/*      */     } else {
/*  810 */       createColumn(column, index);
/*      */     }
/*  812 */     long boxHandle = gtk_box_new(0, false, 3);
/*  813 */     if (boxHandle == 0L) error(2);
/*  814 */     long labelHandle = GTK.gtk_label_new_with_mnemonic(null);
/*  815 */     if (labelHandle == 0L) error(2);
/*  816 */     long imageHandle = GTK.gtk_image_new();
/*  817 */     if (imageHandle == 0L) error(2);
/*  818 */     GTK.gtk_container_add(boxHandle, imageHandle);
/*  819 */     GTK.gtk_container_add(boxHandle, labelHandle);
/*  820 */     GTK.gtk_widget_show(boxHandle);
/*  821 */     GTK.gtk_widget_show(labelHandle);
/*  822 */     column.labelHandle = labelHandle;
/*  823 */     column.imageHandle = imageHandle;
/*  824 */     GTK.gtk_tree_view_column_set_widget(column.handle, boxHandle);
/*  825 */     if (GTK.GTK3) {
/*  826 */       column.buttonHandle = GTK.gtk_tree_view_column_get_button(column.handle);
/*      */     } else {
/*  828 */       long widget = GTK.gtk_widget_get_parent(boxHandle);
/*  829 */       while (widget != this.handle) {
/*  830 */         if (GTK.GTK_IS_BUTTON(widget)) {
/*  831 */           column.buttonHandle = widget;
/*  832 */           break;
/*      */         }
/*  834 */         widget = GTK.gtk_widget_get_parent(widget);
/*      */       }
/*      */     }
/*  837 */     if (this.columnCount == this.columns.length) {
/*  838 */       TreeColumn[] newColumns = new TreeColumn[this.columns.length + 4];
/*  839 */       System.arraycopy(this.columns, 0, newColumns, 0, this.columns.length);
/*  840 */       this.columns = newColumns;
/*      */     }
/*  842 */     System.arraycopy(this.columns, index, this.columns, index + 1, this.columnCount++ - index);
/*  843 */     this.columns[index] = column;
/*  844 */     if ((this.state & 0x4000) != 0) {
/*  845 */       column.setFontDescription(getFontDescription());
/*      */     }
/*  847 */     if (this.columnCount >= 1) {
/*  848 */       for (int i = 0; i < this.items.length; i++) {
/*  849 */         TreeItem item = this.items[i];
/*  850 */         if (item != null) {
/*  851 */           Font[] cellFont = item.cellFont;
/*  852 */           if (cellFont != null) {
/*  853 */             Font[] temp = new Font[this.columnCount];
/*  854 */             System.arraycopy(cellFont, 0, temp, 0, index);
/*  855 */             System.arraycopy(cellFont, index, temp, index + 1, this.columnCount - index - 1);
/*  856 */             item.cellFont = temp;
/*      */           }
/*  858 */           String[] strings = item.strings;
/*  859 */           if (strings != null) {
/*  860 */             String[] temp = new String[this.columnCount];
/*  861 */             System.arraycopy(strings, 0, temp, 0, index);
/*  862 */             System.arraycopy(strings, index, temp, index + 1, this.columnCount - index - 1);
/*  863 */             temp[index] = "";
/*  864 */             item.strings = temp;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   void createItem(TreeItem item, long parentIter, int index)
/*      */   {
/*  873 */     int count = GTK.gtk_tree_model_iter_n_children(this.modelHandle, parentIter);
/*  874 */     if (index == -1) index = count;
/*  875 */     if ((0 > index) || (index > count)) error(6);
/*  876 */     item.handle = OS.g_malloc(GTK.GtkTreeIter_sizeof());
/*  877 */     if (item.handle == 0L) { error(2);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  882 */     if (index == count) {
/*  883 */       GTK.gtk_tree_store_append(this.modelHandle, item.handle, parentIter);
/*      */     } else {
/*  885 */       GTK.gtk_tree_store_insert(this.modelHandle, item.handle, parentIter, index);
/*      */     }
/*  887 */     int id = getId(item.handle, false);
/*  888 */     this.items[id] = item;
/*  889 */     this.modelChanged = true;
/*      */   }
/*      */   
/*      */   void createRenderers(long columnHandle, int modelIndex, boolean check, int columnStyle) {
/*  893 */     GTK.gtk_tree_view_column_clear(columnHandle);
/*  894 */     if (((this.style & 0x20) != 0) && (check)) {
/*  895 */       GTK.gtk_tree_view_column_pack_start(columnHandle, this.checkRenderer, false);
/*  896 */       GTK.gtk_tree_view_column_add_attribute(columnHandle, this.checkRenderer, OS.active, 1);
/*  897 */       GTK.gtk_tree_view_column_add_attribute(columnHandle, this.checkRenderer, OS.inconsistent, 2);
/*  898 */       if ((!this.ownerDraw) && (!GTK.GTK3)) GTK.gtk_tree_view_column_add_attribute(columnHandle, this.checkRenderer, OS.cell_background_gdk, 4);
/*  899 */       if ((!this.ownerDraw) && (GTK.GTK3)) GTK.gtk_tree_view_column_add_attribute(columnHandle, this.checkRenderer, OS.cell_background_rgba, 4);
/*  900 */       if (this.ownerDraw) {
/*  901 */         GTK.gtk_tree_view_column_set_cell_data_func(columnHandle, this.checkRenderer, this.display.cellDataProc, this.handle, 0L);
/*  902 */         OS.g_object_set_qdata(this.checkRenderer, Display.SWT_OBJECT_INDEX1, columnHandle);
/*      */       }
/*      */     }
/*  905 */     long pixbufRenderer = this.ownerDraw ? OS.g_object_new(this.display.gtk_cell_renderer_pixbuf_get_type(), 0L) : GTK.gtk_cell_renderer_pixbuf_new();
/*  906 */     if (pixbufRenderer == 0L) {
/*  907 */       error(2);
/*      */ 
/*      */     }
/*  910 */     else if ((!this.ownerDraw) && (GTK.GTK3))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  917 */       if (((this.style & 0x10000000) != 0) && (this.pixbufSizeSet)) {
/*  918 */         GTK.gtk_cell_renderer_set_fixed_size(pixbufRenderer, this.pixbufHeight, this.pixbufWidth);
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*      */ 
/*  924 */         GTK.gtk_cell_renderer_set_fixed_size(pixbufRenderer, 0, 0);
/*      */       }
/*      */     }
/*      */     
/*  928 */     long textRenderer = this.ownerDraw ? OS.g_object_new(this.display.gtk_cell_renderer_text_get_type(), 0L) : GTK.gtk_cell_renderer_text_new();
/*  929 */     if (textRenderer == 0L) { error(2);
/*      */     }
/*  931 */     if (this.ownerDraw) {
/*  932 */       OS.g_object_set_qdata(pixbufRenderer, Display.SWT_OBJECT_INDEX1, columnHandle);
/*  933 */       OS.g_object_set_qdata(textRenderer, Display.SWT_OBJECT_INDEX1, columnHandle);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  942 */     if (((this.style & 0x20) != 0) && (check)) {
/*  943 */       OS.g_object_set(pixbufRenderer, OS.mode, 1, 0L);
/*      */     }
/*      */     
/*      */ 
/*  947 */     if ((columnStyle & 0x20000) != 0) {
/*  948 */       OS.g_object_set(textRenderer, OS.xalign, 1.0F, 0L);
/*  949 */       GTK.gtk_tree_view_column_pack_end(columnHandle, textRenderer, true);
/*  950 */       GTK.gtk_tree_view_column_pack_end(columnHandle, pixbufRenderer, false);
/*  951 */       GTK.gtk_tree_view_column_set_alignment(columnHandle, 1.0F);
/*  952 */     } else if ((columnStyle & 0x1000000) != 0) {
/*  953 */       OS.g_object_set(textRenderer, OS.xalign, 0.5F, 0L);
/*  954 */       GTK.gtk_tree_view_column_pack_start(columnHandle, pixbufRenderer, false);
/*  955 */       GTK.gtk_tree_view_column_pack_end(columnHandle, textRenderer, true);
/*  956 */       GTK.gtk_tree_view_column_set_alignment(columnHandle, 0.5F);
/*      */     } else {
/*  958 */       GTK.gtk_tree_view_column_pack_start(columnHandle, pixbufRenderer, false);
/*  959 */       GTK.gtk_tree_view_column_pack_start(columnHandle, textRenderer, true);
/*  960 */       GTK.gtk_tree_view_column_set_alignment(columnHandle, 0.0F);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  970 */     GTK.gtk_tree_view_column_add_attribute(columnHandle, pixbufRenderer, OS.pixbuf, modelIndex + 0);
/*  971 */     if (!this.ownerDraw) {
/*  972 */       if (GTK.GTK3) {
/*  973 */         GTK.gtk_tree_view_column_add_attribute(columnHandle, pixbufRenderer, OS.cell_background_rgba, 4);
/*  974 */         GTK.gtk_tree_view_column_add_attribute(columnHandle, textRenderer, OS.cell_background_rgba, 4);
/*      */       } else {
/*  976 */         GTK.gtk_tree_view_column_add_attribute(columnHandle, pixbufRenderer, OS.cell_background_gdk, 4);
/*  977 */         GTK.gtk_tree_view_column_add_attribute(columnHandle, textRenderer, OS.cell_background_gdk, 4);
/*      */       }
/*      */     }
/*  980 */     GTK.gtk_tree_view_column_add_attribute(columnHandle, textRenderer, OS.text, modelIndex + 1);
/*  981 */     if (GTK.GTK3) {
/*  982 */       GTK.gtk_tree_view_column_add_attribute(columnHandle, textRenderer, OS.foreground_rgba, 3);
/*      */     } else {
/*  984 */       GTK.gtk_tree_view_column_add_attribute(columnHandle, textRenderer, OS.foreground_gdk, 3);
/*      */     }
/*  986 */     GTK.gtk_tree_view_column_add_attribute(columnHandle, textRenderer, OS.font_desc, 5);
/*      */     
/*  988 */     boolean customDraw = this.firstCustomDraw;
/*  989 */     if (this.columnCount != 0) {
/*  990 */       for (int i = 0; i < this.columnCount; i++) {
/*  991 */         if (this.columns[i].handle == columnHandle) {
/*  992 */           customDraw = this.columns[i].customDraw;
/*  993 */           break;
/*      */         }
/*      */       }
/*      */     }
/*  997 */     if (((this.style & 0x10000000) != 0) || (customDraw) || (this.ownerDraw)) {
/*  998 */       GTK.gtk_tree_view_column_set_cell_data_func(columnHandle, textRenderer, this.display.cellDataProc, this.handle, 0L);
/*  999 */       GTK.gtk_tree_view_column_set_cell_data_func(columnHandle, pixbufRenderer, this.display.cellDataProc, this.handle, 0L);
/*      */     }
/*      */   }
/*      */   
/*      */   void createWidget(int index)
/*      */   {
/* 1005 */     super.createWidget(index);
/* 1006 */     this.items = new TreeItem[4];
/* 1007 */     this.columns = new TreeColumn[4];
/* 1008 */     this.columnCount = 0;
/*      */     
/*      */ 
/* 1011 */     if (GTK.GTK3) {
/* 1012 */       setFontDescription(defaultFont().handle);
/*      */     }
/*      */   }
/*      */   
/*      */   GdkRGBA defaultBackground()
/*      */   {
/* 1018 */     return this.display.getSystemColor(25).handleRGBA;
/*      */   }
/*      */   
/*      */   void deregister()
/*      */   {
/* 1023 */     super.deregister();
/* 1024 */     this.display.removeWidget(GTK.gtk_tree_view_get_selection(this.handle));
/* 1025 */     if (this.checkRenderer != 0L) this.display.removeWidget(this.checkRenderer);
/* 1026 */     this.display.removeWidget(this.modelHandle);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void deselect(TreeItem item)
/*      */   {
/* 1047 */     checkWidget();
/* 1048 */     if (item == null) error(4);
/* 1049 */     if (item.isDisposed()) error(5);
/* 1050 */     boolean fixColumn = showFirstColumn();
/* 1051 */     long selection = GTK.gtk_tree_view_get_selection(this.handle);
/* 1052 */     OS.g_signal_handlers_block_matched(selection, 16, 0, 0, 0L, 0L, 6L);
/* 1053 */     GTK.gtk_tree_selection_unselect_iter(selection, item.handle);
/* 1054 */     OS.g_signal_handlers_unblock_matched(selection, 16, 0, 0, 0L, 0L, 6L);
/* 1055 */     if (fixColumn) { hideFirstColumn();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void deselectAll()
/*      */   {
/* 1067 */     checkWidget();
/* 1068 */     boolean fixColumn = showFirstColumn();
/* 1069 */     long selection = GTK.gtk_tree_view_get_selection(this.handle);
/* 1070 */     OS.g_signal_handlers_block_matched(selection, 16, 0, 0, 0L, 0L, 6L);
/* 1071 */     GTK.gtk_tree_selection_unselect_all(selection);
/* 1072 */     OS.g_signal_handlers_unblock_matched(selection, 16, 0, 0, 0L, 0L, 6L);
/* 1073 */     if (fixColumn) hideFirstColumn();
/*      */   }
/*      */   
/*      */   void destroyItem(TreeColumn column) {
/* 1077 */     int index = 0;
/* 1078 */     while ((index < this.columnCount) && 
/* 1079 */       (this.columns[index] != column)) {
/* 1080 */       index++;
/*      */     }
/* 1082 */     if (index == this.columnCount) return;
/* 1083 */     long columnHandle = column.handle;
/* 1084 */     if (this.columnCount == 1) {
/* 1085 */       this.firstCustomDraw = column.customDraw;
/*      */     }
/* 1087 */     System.arraycopy(this.columns, index + 1, this.columns, index, --this.columnCount - index);
/* 1088 */     this.columns[this.columnCount] = null;
/* 1089 */     GTK.gtk_tree_view_remove_column(this.handle, columnHandle);
/* 1090 */     if (this.columnCount == 0) {
/* 1091 */       long oldModel = this.modelHandle;
/* 1092 */       long[] types = getColumnTypes(1);
/* 1093 */       long newModel = GTK.gtk_tree_store_newv(types.length, types);
/* 1094 */       if (newModel == 0L) error(2);
/* 1095 */       copyModel(oldModel, column.modelIndex, newModel, 6, types, 0L, 0L, 11);
/* 1096 */       GTK.gtk_tree_view_set_model(this.handle, newModel);
/* 1097 */       setModel(newModel);
/* 1098 */       createColumn(null, 0);
/*      */     } else {
/* 1100 */       for (int i = 0; i < this.items.length; i++) {
/* 1101 */         TreeItem item = this.items[i];
/* 1102 */         if (item != null) {
/* 1103 */           long iter = item.handle;
/* 1104 */           int modelIndex = column.modelIndex;
/* 1105 */           GTK.gtk_tree_store_set(this.modelHandle, iter, modelIndex + 0, 0L, -1);
/* 1106 */           GTK.gtk_tree_store_set(this.modelHandle, iter, modelIndex + 1, 0L, -1);
/* 1107 */           GTK.gtk_tree_store_set(this.modelHandle, iter, modelIndex + 2, 0L, -1);
/* 1108 */           GTK.gtk_tree_store_set(this.modelHandle, iter, modelIndex + 3, 0L, -1);
/* 1109 */           GTK.gtk_tree_store_set(this.modelHandle, iter, modelIndex + 4, 0L, -1);
/*      */           
/* 1111 */           Font[] cellFont = item.cellFont;
/* 1112 */           if (cellFont != null) {
/* 1113 */             if (this.columnCount == 0) {
/* 1114 */               item.cellFont = null;
/*      */             } else {
/* 1116 */               Font[] temp = new Font[this.columnCount];
/* 1117 */               System.arraycopy(cellFont, 0, temp, 0, index);
/* 1118 */               System.arraycopy(cellFont, index + 1, temp, index, this.columnCount - index);
/* 1119 */               item.cellFont = temp;
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/* 1124 */       if (index == 0)
/*      */       {
/* 1126 */         TreeColumn firstColumn = this.columns[0];
/* 1127 */         firstColumn.style &= 0xFEFDBFFF;
/* 1128 */         firstColumn.style |= 0x4000;
/* 1129 */         createRenderers(firstColumn.handle, firstColumn.modelIndex, true, firstColumn.style);
/*      */       }
/*      */     }
/* 1132 */     if (!searchEnabled()) {
/* 1133 */       GTK.gtk_tree_view_set_search_column(this.handle, -1);
/*      */     }
/*      */     else {
/* 1136 */       int firstColumn = this.columnCount == 0 ? 6 : this.columns[0].modelIndex;
/* 1137 */       GTK.gtk_tree_view_set_search_column(this.handle, firstColumn + 1);
/*      */     }
/*      */   }
/*      */   
/*      */   void destroyItem(TreeItem item)
/*      */   {
/* 1143 */     long selection = GTK.gtk_tree_view_get_selection(this.handle);
/* 1144 */     OS.g_signal_handlers_block_matched(selection, 16, 0, 0, 0L, 0L, 6L);
/* 1145 */     GTK.gtk_tree_store_remove(this.modelHandle, item.handle);
/* 1146 */     OS.g_signal_handlers_unblock_matched(selection, 16, 0, 0, 0L, 0L, 6L);
/* 1147 */     this.modelChanged = true;
/*      */   }
/*      */   
/*      */   boolean dragDetect(int x, int y, boolean filter, boolean dragOnTimeout, boolean[] consume)
/*      */   {
/* 1152 */     boolean selected = false;
/* 1153 */     if (OS.isX11()) {
/* 1154 */       if (filter) {
/* 1155 */         long[] path = new long[1];
/* 1156 */         if (GTK.gtk_tree_view_get_path_at_pos(this.handle, x, y, path, null, null, null)) {
/* 1157 */           if (path[0] != 0L) {
/* 1158 */             long selection = GTK.gtk_tree_view_get_selection(this.handle);
/* 1159 */             if (GTK.gtk_tree_selection_path_is_selected(selection, path[0])) selected = true;
/* 1160 */             GTK.gtk_tree_path_free(path[0]);
/*      */           }
/*      */         } else {
/* 1163 */           return false;
/*      */         }
/*      */       }
/* 1166 */       boolean dragDetect = super.dragDetect(x, y, filter, false, consume);
/* 1167 */       if ((dragDetect) && (selected) && (consume != null)) consume[0] = true;
/* 1168 */       return dragDetect;
/*      */     }
/* 1170 */     double[] startX = new double[1];
/* 1171 */     double[] startY = new double[1];
/* 1172 */     long[] path = new long[1];
/* 1173 */     if (GTK.gtk_gesture_drag_get_start_point(this.dragGesture, startX, startY)) {
/* 1174 */       if (getHeaderVisible()) {
/* 1175 */         startY[0] -= getHeaderHeightInPixels();
/*      */       }
/* 1177 */       if (GTK.gtk_tree_view_get_path_at_pos(this.handle, (int)startX[0], (int)startY[0], path, null, null, null)) {
/* 1178 */         if (path[0] != 0L) {
/* 1179 */           boolean dragDetect = super.dragDetect(x, y, filter, false, consume);
/* 1180 */           if ((dragDetect) && (selected) && (consume != null)) consume[0] = true;
/* 1181 */           return dragDetect;
/*      */         }
/*      */       } else {
/* 1184 */         return false;
/*      */       }
/*      */     }
/*      */     
/* 1188 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */   long eventWindow()
/*      */   {
/* 1194 */     return paintWindow();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   boolean fixAccessibility()
/*      */   {
/* 1209 */     return true;
/*      */   }
/*      */   
/*      */   void fixChildren(Shell newShell, Shell oldShell, Decorations newDecorations, Decorations oldDecorations, Menu[] menus)
/*      */   {
/* 1214 */     super.fixChildren(newShell, oldShell, newDecorations, oldDecorations, menus);
/* 1215 */     for (int i = 0; i < this.columnCount; i++) {
/* 1216 */       TreeColumn column = this.columns[i];
/* 1217 */       if (column.toolTipText != null) {
/* 1218 */         column.setToolTipText(oldShell, null);
/* 1219 */         column.setToolTipText(newShell, column.toolTipText);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   GdkColor getBackgroundGdkColor()
/*      */   {
/* 1226 */     assert (!GTK.GTK3) : "GTK2 code was run by GTK3";
/* 1227 */     return getBaseGdkColor();
/*      */   }
/*      */   
/*      */   Rectangle getClientAreaInPixels()
/*      */   {
/* 1232 */     checkWidget();
/* 1233 */     forceResize();
/* 1234 */     GTK.gtk_widget_realize(this.handle);
/* 1235 */     long fixedWindow = gtk_widget_get_window(this.fixedHandle);
/* 1236 */     long binWindow = GTK.gtk_tree_view_get_bin_window(this.handle);
/* 1237 */     int[] binX = new int[1];int[] binY = new int[1];
/* 1238 */     GDK.gdk_window_get_origin(binWindow, binX, binY);
/* 1239 */     int[] fixedX = new int[1];int[] fixedY = new int[1];
/* 1240 */     GDK.gdk_window_get_origin(fixedWindow, fixedX, fixedY);
/* 1241 */     long clientHandle = clientHandle();
/* 1242 */     GtkAllocation allocation = new GtkAllocation();
/* 1243 */     GTK.gtk_widget_get_allocation(clientHandle, allocation);
/* 1244 */     int width = (this.state & 0x200) != 0 ? 0 : allocation.width;
/* 1245 */     int height = (this.state & 0x400) != 0 ? 0 : allocation.height;
/* 1246 */     Rectangle rect = new Rectangle(fixedX[0] - binX[0], fixedY[0] - binY[0], width, height);
/* 1247 */     return rect;
/*      */   }
/*      */   
/*      */   int getClientWidth()
/*      */   {
/* 1252 */     int[] w = new int[1];int[] h = new int[1];
/* 1253 */     GTK.gtk_widget_realize(this.handle);
/* 1254 */     gdk_window_get_size(GTK.gtk_tree_view_get_bin_window(this.handle), w, h);
/* 1255 */     return w[0];
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public TreeColumn getColumn(int index)
/*      */   {
/* 1288 */     checkWidget();
/* 1289 */     if ((0 > index) || (index >= this.columnCount)) error(6);
/* 1290 */     return this.columns[index];
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getColumnCount()
/*      */   {
/* 1310 */     checkWidget();
/* 1311 */     return this.columnCount;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int[] getColumnOrder()
/*      */   {
/* 1343 */     checkWidget();
/* 1344 */     if (this.columnCount == 0) return new int[0];
/* 1345 */     long list = GTK.gtk_tree_view_get_columns(this.handle);
/* 1346 */     if (list == 0L) return new int[0];
/* 1347 */     int i = 0;int count = OS.g_list_length(list);
/* 1348 */     int[] order = new int[count];
/* 1349 */     long temp = list;
/* 1350 */     while (temp != 0L) {
/* 1351 */       long column = OS.g_list_data(temp);
/* 1352 */       if (column != 0L) {
/* 1353 */         for (int j = 0; j < this.columnCount; j++) {
/* 1354 */           if (this.columns[j].handle == column) {
/* 1355 */             order[(i++)] = j;
/* 1356 */             break;
/*      */           }
/*      */         }
/*      */       }
/* 1360 */       temp = OS.g_list_next(temp);
/*      */     }
/* 1362 */     OS.g_list_free(list);
/* 1363 */     return order;
/*      */   }
/*      */   
/*      */   long[] getColumnTypes(int columnCount) {
/* 1367 */     long[] types = new long[6 + columnCount * 5];
/*      */     
/* 1369 */     types[0] = OS.G_TYPE_INT();
/* 1370 */     types[1] = OS.G_TYPE_BOOLEAN();
/* 1371 */     types[2] = OS.G_TYPE_BOOLEAN();
/* 1372 */     types[3] = (GTK.GTK3 ? GDK.GDK_TYPE_RGBA() : GDK.GDK_TYPE_COLOR());
/* 1373 */     types[4] = (GTK.GTK3 ? GDK.GDK_TYPE_RGBA() : GDK.GDK_TYPE_COLOR());
/* 1374 */     types[5] = OS.PANGO_TYPE_FONT_DESCRIPTION();
/*      */     
/* 1376 */     for (int i = 6; i < types.length; i += 5) {
/* 1377 */       types[(i + 0)] = GDK.GDK_TYPE_PIXBUF();
/* 1378 */       types[(i + 1)] = OS.G_TYPE_STRING();
/* 1379 */       types[(i + 2)] = (GTK.GTK3 ? GDK.GDK_TYPE_RGBA() : GDK.GDK_TYPE_COLOR());
/* 1380 */       types[(i + 3)] = (GTK.GTK3 ? GDK.GDK_TYPE_RGBA() : GDK.GDK_TYPE_COLOR());
/* 1381 */       types[(i + 4)] = OS.PANGO_TYPE_FONT_DESCRIPTION();
/*      */     }
/* 1383 */     return types;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public TreeColumn[] getColumns()
/*      */   {
/* 1416 */     checkWidget();
/* 1417 */     TreeColumn[] result = new TreeColumn[this.columnCount];
/* 1418 */     System.arraycopy(this.columns, 0, result, 0, this.columnCount);
/* 1419 */     return result;
/*      */   }
/*      */   
/*      */   GdkRGBA getContextBackgroundGdkRGBA()
/*      */   {
/* 1424 */     assert (GTK.GTK3) : "GTK3 code was run by GTK2";
/* 1425 */     if (this.background != null) {
/* 1426 */       return this.background;
/*      */     }
/*      */     
/*      */ 
/* 1430 */     return defaultBackground();
/*      */   }
/*      */   
/*      */ 
/*      */   GdkRGBA getContextColorGdkRGBA()
/*      */   {
/* 1436 */     if (GTK.GTK_VERSION >= OS.VERSION(3, 14, 0)) {
/* 1437 */       if (this.foreground != null) {
/* 1438 */         return this.foreground;
/*      */       }
/* 1440 */       return this.display.COLOR_LIST_FOREGROUND_RGBA;
/*      */     }
/*      */     
/* 1443 */     return super.getContextColorGdkRGBA();
/*      */   }
/*      */   
/*      */   TreeItem getFocusItem()
/*      */   {
/* 1448 */     long[] path = new long[1];
/* 1449 */     GTK.gtk_tree_view_get_cursor(this.handle, path, null);
/* 1450 */     if (path[0] == 0L) return null;
/* 1451 */     TreeItem item = null;
/* 1452 */     long iter = OS.g_malloc(GTK.GtkTreeIter_sizeof());
/* 1453 */     if (GTK.gtk_tree_model_get_iter(this.modelHandle, iter, path[0])) {
/* 1454 */       int[] index = new int[1];
/* 1455 */       GTK.gtk_tree_model_get(this.modelHandle, iter, 0, index, -1);
/* 1456 */       if (index[0] != -1) item = this.items[index[0]];
/*      */     }
/* 1458 */     OS.g_free(iter);
/* 1459 */     GTK.gtk_tree_path_free(path[0]);
/* 1460 */     return item;
/*      */   }
/*      */   
/*      */   GdkColor getForegroundGdkColor()
/*      */   {
/* 1465 */     assert (!GTK.GTK3) : "GTK2 code was run by GTK3";
/* 1466 */     return getTextColor();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getGridLineWidth()
/*      */   {
/* 1482 */     checkWidget();
/* 1483 */     return DPIUtil.autoScaleDown(getGridLineWidthInPixels());
/*      */   }
/*      */   
/*      */   int getGridLineWidthInPixels() {
/* 1487 */     checkWidget();
/* 1488 */     return 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Color getHeaderBackground()
/*      */   {
/* 1503 */     checkWidget();
/* 1504 */     return this.headerBackground != null ? this.headerBackground : this.display.getSystemColor(25);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Color getHeaderForeground()
/*      */   {
/* 1519 */     checkWidget();
/* 1520 */     return this.headerForeground != null ? this.headerForeground : this.display.getSystemColor(24);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getHeaderHeight()
/*      */   {
/* 1536 */     checkWidget();
/* 1537 */     return DPIUtil.autoScaleDown(getHeaderHeightInPixels());
/*      */   }
/*      */   
/*      */   int getHeaderHeightInPixels() {
/* 1541 */     checkWidget();
/* 1542 */     if (!GTK.gtk_tree_view_get_headers_visible(this.handle)) return 0;
/* 1543 */     if (this.columnCount > 0) {
/* 1544 */       GtkRequisition requisition = new GtkRequisition();
/* 1545 */       int height = 0;
/* 1546 */       for (int i = 0; i < this.columnCount; i++) {
/* 1547 */         long buttonHandle = this.columns[i].buttonHandle;
/* 1548 */         if (buttonHandle != 0L) {
/* 1549 */           gtk_widget_get_preferred_size(buttonHandle, requisition);
/* 1550 */           height = Math.max(height, requisition.height);
/*      */         }
/*      */       }
/* 1553 */       return height;
/*      */     }
/* 1555 */     GTK.gtk_widget_realize(this.handle);
/* 1556 */     long fixedWindow = gtk_widget_get_window(this.fixedHandle);
/* 1557 */     long binWindow = GTK.gtk_tree_view_get_bin_window(this.handle);
/* 1558 */     int[] binY = new int[1];
/* 1559 */     GDK.gdk_window_get_origin(binWindow, null, binY);
/* 1560 */     int[] fixedY = new int[1];
/* 1561 */     GDK.gdk_window_get_origin(fixedWindow, null, fixedY);
/* 1562 */     return binY[0] - fixedY[0];
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getHeaderVisible()
/*      */   {
/* 1585 */     checkWidget();
/* 1586 */     return GTK.gtk_tree_view_get_headers_visible(this.handle);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public TreeItem getItem(int index)
/*      */   {
/* 1607 */     checkWidget();
/* 1608 */     if ((0 > index) || (index >= GTK.gtk_tree_model_iter_n_children(this.modelHandle, 0L))) {
/* 1609 */       error(6);
/*      */     }
/* 1611 */     return _getItem(0L, index);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public TreeItem getItem(Point point)
/*      */   {
/* 1638 */     checkWidget();
/* 1639 */     return getItemInPixels(DPIUtil.autoScaleUp(point));
/*      */   }
/*      */   
/*      */   TreeItem getItemInPixels(Point point) {
/* 1643 */     checkWidget();
/* 1644 */     if (point == null) error(4);
/* 1645 */     long[] path = new long[1];
/* 1646 */     GTK.gtk_widget_realize(this.handle);
/* 1647 */     int x = point.x;
/* 1648 */     int y = point.y;
/* 1649 */     if ((this.style & 0x8000000) != 0) x = getClientWidth() - x;
/* 1650 */     long[] columnHandle = new long[1];
/* 1651 */     if (!GTK.gtk_tree_view_get_path_at_pos(this.handle, x, y, path, columnHandle, null, null)) return null;
/* 1652 */     if (path[0] == 0L) return null;
/* 1653 */     TreeItem item = null;
/* 1654 */     long iter = OS.g_malloc(GTK.GtkTreeIter_sizeof());
/* 1655 */     if (GTK.gtk_tree_model_get_iter(this.modelHandle, iter, path[0])) {
/* 1656 */       boolean overExpander = false;
/* 1657 */       if (GTK.gtk_tree_view_get_expander_column(this.handle) == columnHandle[0]) {
/* 1658 */         GdkRectangle rect = new GdkRectangle();
/* 1659 */         GTK.gtk_tree_view_get_cell_area(this.handle, path[0], columnHandle[0], rect);
/* 1660 */         if ((this.style & 0x8000000) != 0) {
/* 1661 */           overExpander = x > rect.x + rect.width;
/*      */         } else {
/* 1663 */           overExpander = x < rect.x;
/*      */         }
/*      */       }
/* 1666 */       if (!overExpander) {
/* 1667 */         item = _getItem(iter);
/*      */       }
/*      */     }
/* 1670 */     OS.g_free(iter);
/* 1671 */     GTK.gtk_tree_path_free(path[0]);
/* 1672 */     return item;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getItemCount()
/*      */   {
/* 1689 */     checkWidget();
/* 1690 */     return GTK.gtk_tree_model_iter_n_children(this.modelHandle, 0L);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getItemHeight()
/*      */   {
/* 1705 */     checkWidget();
/* 1706 */     return DPIUtil.autoScaleDown(getItemHeightInPixels());
/*      */   }
/*      */   
/*      */   int getItemHeightInPixels() {
/* 1710 */     checkWidget();
/* 1711 */     int itemCount = GTK.gtk_tree_model_iter_n_children(this.modelHandle, 0L);
/* 1712 */     if (itemCount == 0) {
/* 1713 */       long column = GTK.gtk_tree_view_get_column(this.handle, 0);
/* 1714 */       int[] w = new int[1];int[] h = new int[1];
/* 1715 */       this.ignoreSize = true;
/* 1716 */       GTK.gtk_tree_view_column_cell_get_size(column, null, null, null, w, h);
/* 1717 */       int height = h[0];
/* 1718 */       if (GTK.GTK3) {
/* 1719 */         long textRenderer = getTextRenderer(column);
/* 1720 */         GTK.gtk_cell_renderer_get_preferred_height_for_width(textRenderer, this.handle, 0, h, null);
/* 1721 */         height += h[0];
/*      */       }
/* 1723 */       this.ignoreSize = false;
/* 1724 */       return height;
/*      */     }
/* 1726 */     int height = 0;
/* 1727 */     long iter = OS.g_malloc(GTK.GtkTreeIter_sizeof());
/* 1728 */     GTK.gtk_tree_model_get_iter_first(this.modelHandle, iter);
/* 1729 */     int columnCount = Math.max(1, this.columnCount);
/* 1730 */     for (int i = 0; i < columnCount; i++) {
/* 1731 */       long column = GTK.gtk_tree_view_get_column(this.handle, i);
/* 1732 */       GTK.gtk_tree_view_column_cell_set_cell_data(column, this.modelHandle, iter, false, false);
/* 1733 */       int[] w = new int[1];int[] h = new int[1];
/* 1734 */       GTK.gtk_tree_view_column_cell_get_size(column, null, null, null, w, h);
/* 1735 */       height = Math.max(height, h[0]);
/*      */     }
/* 1737 */     OS.g_free(iter);
/* 1738 */     return height;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public TreeItem[] getItems()
/*      */   {
/* 1760 */     checkWidget();
/* 1761 */     return getItems(0L);
/*      */   }
/*      */   
/*      */   TreeItem[] getItems(long parent) {
/* 1765 */     int length = GTK.gtk_tree_model_iter_n_children(this.modelHandle, parent);
/* 1766 */     TreeItem[] result = new TreeItem[length];
/* 1767 */     if (length == 0) return result;
/* 1768 */     if ((this.style & 0x10000000) != 0) {
/* 1769 */       for (int i = 0; i < length; i++) {
/* 1770 */         result[i] = _getItem(parent, i);
/*      */       }
/*      */     } else {
/* 1773 */       int i = 0;
/* 1774 */       int[] index = new int[1];
/* 1775 */       long iter = OS.g_malloc(GTK.GtkTreeIter_sizeof());
/* 1776 */       boolean valid = GTK.gtk_tree_model_iter_children(this.modelHandle, iter, parent);
/* 1777 */       while (valid) {
/* 1778 */         GTK.gtk_tree_model_get(this.modelHandle, iter, 0, index, -1);
/* 1779 */         result[(i++)] = this.items[index[0]];
/* 1780 */         valid = GTK.gtk_tree_model_iter_next(this.modelHandle, iter);
/*      */       }
/* 1782 */       OS.g_free(iter);
/*      */     }
/* 1784 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getLinesVisible()
/*      */   {
/* 1808 */     checkWidget();
/* 1809 */     if (GTK.GTK3) {
/* 1810 */       return GTK.gtk_tree_view_get_grid_lines(this.handle) > 0;
/*      */     }
/* 1812 */     return GTK.gtk_tree_view_get_rules_hint(this.handle);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public TreeItem getParentItem()
/*      */   {
/* 1829 */     checkWidget();
/* 1830 */     return null;
/*      */   }
/*      */   
/*      */   long getPixbufRenderer(long column) {
/* 1834 */     long list = GTK.gtk_cell_layout_get_cells(column);
/* 1835 */     if (list == 0L) return 0L;
/* 1836 */     long originalList = list;
/* 1837 */     long pixbufRenderer = 0L;
/* 1838 */     while (list != 0L) {
/* 1839 */       long renderer = OS.g_list_data(list);
/* 1840 */       if (GTK.GTK_IS_CELL_RENDERER_PIXBUF(renderer)) {
/* 1841 */         pixbufRenderer = renderer;
/* 1842 */         break;
/*      */       }
/* 1844 */       list = OS.g_list_next(list);
/*      */     }
/* 1846 */     OS.g_list_free(originalList);
/* 1847 */     return pixbufRenderer;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public TreeItem[] getSelection()
/*      */   {
/* 1867 */     checkWidget();
/* 1868 */     long selection = GTK.gtk_tree_view_get_selection(this.handle);
/* 1869 */     long list = GTK.gtk_tree_selection_get_selected_rows(selection, null);
/* 1870 */     if (list != 0L) {
/* 1871 */       long originalList = list;
/* 1872 */       int count = OS.g_list_length(list);
/* 1873 */       TreeItem[] treeSelection = new TreeItem[count];
/* 1874 */       int length = 0;
/* 1875 */       for (int i = 0; i < count; i++) {
/* 1876 */         long data = OS.g_list_data(list);
/* 1877 */         long iter = OS.g_malloc(GTK.GtkTreeIter_sizeof());
/* 1878 */         if (GTK.gtk_tree_model_get_iter(this.modelHandle, iter, data)) {
/* 1879 */           treeSelection[length] = _getItem(iter);
/* 1880 */           length++;
/*      */         }
/* 1882 */         list = OS.g_list_next(list);
/* 1883 */         OS.g_free(iter);
/* 1884 */         GTK.gtk_tree_path_free(data);
/*      */       }
/* 1886 */       OS.g_list_free(originalList);
/* 1887 */       if (length < count) {
/* 1888 */         TreeItem[] temp = new TreeItem[length];
/* 1889 */         System.arraycopy(treeSelection, 0, temp, 0, length);
/* 1890 */         treeSelection = temp;
/*      */       }
/* 1892 */       return treeSelection;
/*      */     }
/* 1894 */     return new TreeItem[0];
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getSelectionCount()
/*      */   {
/* 1908 */     checkWidget();
/* 1909 */     long selection = GTK.gtk_tree_view_get_selection(this.handle);
/* 1910 */     return GTK.gtk_tree_selection_count_selected_rows(selection);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public TreeColumn getSortColumn()
/*      */   {
/* 1930 */     checkWidget();
/* 1931 */     return this.sortColumn;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getSortDirection()
/*      */   {
/* 1951 */     checkWidget();
/* 1952 */     return this.sortDirection;
/*      */   }
/*      */   
/*      */   long getTextRenderer(long column) {
/* 1956 */     long list = GTK.gtk_cell_layout_get_cells(column);
/* 1957 */     if (list == 0L) return 0L;
/* 1958 */     long originalList = list;
/* 1959 */     long textRenderer = 0L;
/* 1960 */     while (list != 0L) {
/* 1961 */       long renderer = OS.g_list_data(list);
/* 1962 */       if (GTK.GTK_IS_CELL_RENDERER_TEXT(renderer)) {
/* 1963 */         textRenderer = renderer;
/* 1964 */         break;
/*      */       }
/* 1966 */       list = OS.g_list_next(list);
/*      */     }
/* 1968 */     OS.g_list_free(originalList);
/* 1969 */     return textRenderer;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public TreeItem getTopItem()
/*      */   {
/* 1987 */     checkWidget();
/*      */     
/*      */ 
/*      */     long vAdjustment;
/*      */     
/*      */     long vAdjustment;
/*      */     
/* 1994 */     if (GTK.GTK3) {
/* 1995 */       vAdjustment = GTK.gtk_scrollable_get_vadjustment(this.handle);
/*      */     }
/*      */     else {
/* 1998 */       vAdjustment = GTK.gtk_tree_view_get_vadjustment(this.handle);
/*      */     }
/* 2000 */     this.currentAdjustment = GTK._gtk_adjustment_get_value(vAdjustment);
/* 2001 */     TreeItem item = null;
/* 2002 */     if (this.cachedAdjustment == this.currentAdjustment) {
/* 2003 */       item = _getCachedTopItem();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 2009 */     if ((item != null) && (!item.isDisposed())) {
/* 2010 */       return item;
/*      */     }
/*      */     
/* 2013 */     long[] path = new long[1];
/* 2014 */     GTK.gtk_widget_realize(this.handle);
/* 2015 */     if (!GTK.gtk_tree_view_get_path_at_pos(this.handle, 1, 1, path, null, null, null)) return null;
/* 2016 */     if (path[0] == 0L) return null;
/* 2017 */     item = null;
/* 2018 */     long iter = OS.g_malloc(GTK.GtkTreeIter_sizeof());
/* 2019 */     if (GTK.gtk_tree_model_get_iter(this.modelHandle, iter, path[0])) {
/* 2020 */       item = _getItem(iter);
/*      */     }
/* 2022 */     OS.g_free(iter);
/* 2023 */     GTK.gtk_tree_path_free(path[0]);
/* 2024 */     this.topItem = item;
/* 2025 */     return item;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   TreeItem _getCachedTopItem()
/*      */   {
/* 2034 */     long treeSelect = GTK.gtk_tree_view_get_selection(this.handle);
/* 2035 */     long list = GTK.gtk_tree_selection_get_selected_rows(treeSelect, null);
/* 2036 */     TreeItem treeSelection = null;
/* 2037 */     if (list != 0L) {
/* 2038 */       long iter = OS.g_malloc(GTK.GtkTreeIter_sizeof());
/* 2039 */       long data = OS.g_list_data(list);
/* 2040 */       if (GTK.gtk_tree_model_get_iter(this.modelHandle, iter, data)) {
/* 2041 */         treeSelection = _getItem(iter);
/*      */       }
/* 2043 */       OS.g_free(iter);
/* 2044 */       GTK.gtk_tree_path_free(data);
/* 2045 */       if (this.topItem == treeSelection) {
/* 2046 */         return this.topItem;
/*      */       }
/*      */       
/* 2049 */       return treeSelection;
/*      */     }
/*      */     
/* 2052 */     if (this.topItem == null)
/*      */     {
/* 2054 */       TreeItem item = null;
/* 2055 */       long iter = OS.g_malloc(GTK.GtkTreeIter_sizeof());
/* 2056 */       if (GTK.gtk_tree_model_get_iter_first(this.modelHandle, iter)) {
/* 2057 */         item = _getItem(iter);
/*      */       }
/* 2059 */       OS.g_free(iter);
/* 2060 */       return item;
/*      */     }
/* 2062 */     return this.topItem;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   long gtk_button_press_event(long widget, long event)
/*      */   {
/* 2069 */     GdkEventButton gdkEvent = new GdkEventButton();
/* 2070 */     OS.memmove(gdkEvent, event, GdkEventButton.sizeof);
/* 2071 */     if (gdkEvent.window != GTK.gtk_tree_view_get_bin_window(this.handle)) return 0L;
/* 2072 */     long result = super.gtk_button_press_event(widget, event);
/* 2073 */     if (result != 0L) { return result;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2080 */     if (((this.state & 0x800000) != 0) && (hooks(29)) && 
/* 2081 */       (!OS.isX11()) && (gdkEvent.type == 4))
/*      */     {
/* 2083 */       long nextEvent = GDK.gdk_event_peek();
/* 2084 */       if (nextEvent == 0L) {
/* 2085 */         long[] path = new long[1];
/* 2086 */         long selection = GTK.gtk_tree_view_get_selection(this.handle);
/* 2087 */         if ((GTK.gtk_tree_view_get_path_at_pos(this.handle, (int)gdkEvent.x, (int)gdkEvent.y, path, null, null, null)) && (path[0] != 0L))
/*      */         {
/*      */ 
/* 2090 */           this.selectionCountOnPress = getSelectionCount();
/* 2091 */           if ((GTK.gtk_tree_selection_path_is_selected(selection, path[0])) && (
/* 2092 */             ((gdkEvent.state & 0x5) == 0) || ((gdkEvent.state & 0x4) != 0)))
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2101 */             long gtk_false_funcPtr = GTK.GET_FUNCTION_POINTER_gtk_false();
/* 2102 */             GTK.gtk_tree_selection_set_select_function(selection, gtk_false_funcPtr, 0L, 0L);
/*      */           }
/*      */         }
/*      */       }
/*      */       else {
/* 2107 */         GDK.gdk_event_free(nextEvent);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2118 */     int button = gdkEvent.button;
/* 2119 */     if ((button == 3) && (gdkEvent.type == 4)) {
/* 2120 */       long[] path = new long[1];
/* 2121 */       if ((GTK.gtk_tree_view_get_path_at_pos(this.handle, (int)gdkEvent.x, (int)gdkEvent.y, path, null, null, null)) && 
/* 2122 */         (path[0] != 0L)) {
/* 2123 */         long selection = GTK.gtk_tree_view_get_selection(this.handle);
/* 2124 */         if (GTK.gtk_tree_selection_path_is_selected(selection, path[0])) result = 1L;
/* 2125 */         GTK.gtk_tree_path_free(path[0]);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2137 */     if (((this.style & 0x4) != 0) && (getSelectionCount() == 0)) {
/* 2138 */       long[] path = new long[1];
/* 2139 */       if ((GTK.gtk_tree_view_get_path_at_pos(this.handle, (int)gdkEvent.x, (int)gdkEvent.y, path, null, null, null)) && 
/* 2140 */         (path[0] != 0L)) {
/* 2141 */         long selection = GTK.gtk_tree_view_get_selection(this.handle);
/* 2142 */         OS.g_signal_handlers_block_matched(selection, 16, 0, 0, 0L, 0L, 6L);
/* 2143 */         GTK.gtk_tree_view_set_cursor(this.handle, path[0], 0L, false);
/* 2144 */         OS.g_signal_handlers_unblock_matched(selection, 16, 0, 0, 0L, 0L, 6L);
/* 2145 */         GTK.gtk_tree_path_free(path[0]);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 2151 */     if (gdkEvent.type == 5) {
/* 2152 */       sendTreeDefaultSelection();
/*      */     }
/*      */     
/* 2155 */     return result;
/*      */   }
/*      */   
/*      */   long gtk_key_press_event(long widget, long event)
/*      */   {
/* 2160 */     GdkEventKey keyEvent = new GdkEventKey();
/* 2161 */     OS.memmove(keyEvent, event, GdkEventKey.sizeof);
/* 2162 */     int key = keyEvent.keyval;
/* 2163 */     keyPressDefaultSelectionHandler(event, key);
/* 2164 */     return super.gtk_key_press_event(widget, event);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   void keyPressDefaultSelectionHandler(long event, int key)
/*      */   {
/* 2172 */     int keymask = gdk_event_get_state(event);
/* 2173 */     switch (key)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */     case 65293: 
/* 2179 */       if ((keymask & 0x1C000008) == 0) {
/* 2180 */         sendTreeDefaultSelection();
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */       break;
/*      */     }
/*      */     
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   void sendTreeDefaultSelection()
/*      */   {
/* 2194 */     TreeItem treeItem = getFocusItem();
/* 2195 */     if (treeItem == null) {
/* 2196 */       return;
/*      */     }
/* 2198 */     Event event = new Event();
/* 2199 */     event.item = treeItem;
/*      */     
/* 2201 */     sendSelectionEvent(14, event, false);
/*      */   }
/*      */   
/*      */   long gtk_button_release_event(long widget, long event)
/*      */   {
/* 2206 */     GdkEventButton gdkEvent = new GdkEventButton();
/* 2207 */     OS.memmove(gdkEvent, event, GdkEventButton.sizeof);
/*      */     
/* 2209 */     this.lastInput.x = ((int)gdkEvent.x);
/* 2210 */     this.lastInput.y = ((int)gdkEvent.y);
/* 2211 */     if (containedInRegion(this.lastInput.x, this.lastInput.y)) return 0L;
/* 2212 */     if (gdkEvent.window != GTK.gtk_tree_view_get_bin_window(this.handle)) { return 0L;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2220 */     if (((this.state & 0x800000) != 0) && (hooks(29)) && (!OS.isX11())) {
/* 2221 */       long[] path = new long[1];
/* 2222 */       long selection = GTK.gtk_tree_view_get_selection(this.handle);
/*      */       
/* 2224 */       GTK.gtk_tree_selection_set_select_function(selection, 0L, 0L, 0L);
/* 2225 */       if ((GTK.gtk_tree_view_get_path_at_pos(this.handle, (int)gdkEvent.x, (int)gdkEvent.y, path, null, null, null)) && (path[0] != 0L) && 
/* 2226 */         (GTK.gtk_tree_selection_path_is_selected(selection, path[0]))) {
/* 2227 */         this.selectionCountOnRelease = getSelectionCount();
/* 2228 */         if ((gdkEvent.state & 0x5) == 0) {
/* 2229 */           GTK.gtk_tree_view_set_cursor(this.handle, path[0], 0L, false);
/*      */         }
/*      */         
/*      */ 
/* 2233 */         if (((gdkEvent.state & 0x4) != 0) && (this.selectionCountOnRelease == this.selectionCountOnPress)) {
/* 2234 */           GTK.gtk_tree_selection_unselect_path(selection, path[0]);
/*      */         }
/*      */       }
/*      */     }
/* 2238 */     return super.gtk_button_release_event(widget, event);
/*      */   }
/*      */   
/*      */   long gtk_changed(long widget)
/*      */   {
/* 2243 */     TreeItem item = getFocusItem();
/* 2244 */     if (item != null) {
/* 2245 */       Event event = new Event();
/* 2246 */       event.item = item;
/* 2247 */       sendSelectionEvent(13, event, false);
/*      */     }
/* 2249 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_event_after(long widget, long gdkEvent)
/*      */   {
/* 2254 */     switch (GDK.GDK_EVENT_TYPE(gdkEvent))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case 2: 
/* 2263 */       if (GTK.gtk_tree_model_iter_n_children(this.modelHandle, 0L) == 0) {
/* 2264 */         gtk_expose_event(widget, gdkEvent);
/*      */       }
/*      */       break;
/*      */     }
/*      */     
/* 2269 */     return super.gtk_event_after(widget, gdkEvent);
/*      */   }
/*      */   
/*      */ 
/*      */   long gtk_expand_collapse_cursor_row(long widget, long logical, long expand, long open_all)
/*      */   {
/* 2275 */     if ((expand != 0L) && (open_all != 0L)) this.expandAll = true;
/* 2276 */     return 0L;
/*      */   }
/*      */   
/*      */   void drawInheritedBackground(long eventPtr, long cairo) {
/* 2280 */     if (((this.state & 0x8000) != 0) || (this.backgroundImage != null)) {
/* 2281 */       Control control = findBackgroundControl();
/* 2282 */       if (control != null) {
/* 2283 */         long window = GTK.gtk_tree_view_get_bin_window(this.handle);
/* 2284 */         long rgn = 0L;
/* 2285 */         if (eventPtr != 0L) {
/* 2286 */           GdkEventExpose gdkEvent = new GdkEventExpose();
/* 2287 */           OS.memmove(gdkEvent, eventPtr, GdkEventExpose.sizeof);
/* 2288 */           if (window != gdkEvent.window) return;
/* 2289 */           rgn = gdkEvent.region;
/*      */         }
/* 2291 */         int[] width = new int[1];int[] height = new int[1];
/* 2292 */         gdk_window_get_size(window, width, height);
/* 2293 */         long parent = 0L;
/* 2294 */         int itemCount = GTK.gtk_tree_model_iter_n_children(this.modelHandle, parent);
/* 2295 */         GdkRectangle rect = new GdkRectangle();
/* 2296 */         boolean expanded = true;
/* 2297 */         while ((itemCount != 0) && (expanded) && (height[0] > rect.y + rect.height)) {
/* 2298 */           long iter = OS.g_malloc(GTK.GtkTreeIter_sizeof());
/* 2299 */           GTK.gtk_tree_model_iter_nth_child(this.modelHandle, iter, parent, itemCount - 1);
/* 2300 */           itemCount = GTK.gtk_tree_model_iter_n_children(this.modelHandle, iter);
/* 2301 */           long path = GTK.gtk_tree_model_get_path(this.modelHandle, iter);
/* 2302 */           GTK.gtk_tree_view_get_cell_area(this.handle, path, 0L, rect);
/* 2303 */           expanded = GTK.gtk_tree_view_row_expanded(this.handle, path);
/* 2304 */           GTK.gtk_tree_path_free(path);
/* 2305 */           if (parent != 0L) OS.g_free(parent);
/* 2306 */           parent = iter;
/*      */         }
/* 2308 */         if (parent != 0L) OS.g_free(parent);
/* 2309 */         if (height[0] > rect.y + rect.height) {
/* 2310 */           drawBackground(control, window, cairo, rgn, 0, rect.y + rect.height, width[0], height[0] - (rect.y + rect.height));
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   long gtk_draw(long widget, long cairo)
/*      */   {
/* 2318 */     if ((this.state & 0x40) != 0) return 0L;
/* 2319 */     drawInheritedBackground(0L, cairo);
/* 2320 */     return super.gtk_draw(widget, cairo);
/*      */   }
/*      */   
/*      */   long gtk_expose_event(long widget, long eventPtr)
/*      */   {
/* 2325 */     if ((this.state & 0x40) != 0) return 0L;
/* 2326 */     drawInheritedBackground(eventPtr, 0L);
/* 2327 */     return super.gtk_expose_event(widget, eventPtr);
/*      */   }
/*      */   
/*      */   long gtk_motion_notify_event(long widget, long event)
/*      */   {
/* 2332 */     long window = GDK.GDK_EVENT_WINDOW(event);
/* 2333 */     if (window != GTK.gtk_tree_view_get_bin_window(this.handle)) return 0L;
/* 2334 */     return super.gtk_motion_notify_event(widget, event);
/*      */   }
/*      */   
/*      */   long gtk_row_deleted(long model, long path)
/*      */   {
/* 2339 */     if (this.ignoreAccessibility) {
/* 2340 */       OS.g_signal_stop_emission_by_name(model, OS.row_deleted);
/*      */     }
/* 2342 */     return 0L;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   long gtk_row_has_child_toggled(long model, long path, long iter)
/*      */   {
/* 2355 */     int[] index = new int[1];
/* 2356 */     GTK.gtk_tree_model_get(this.modelHandle, iter, 0, index, -1);
/* 2357 */     if (index[0] >= this.items.length) return 0L;
/* 2358 */     TreeItem item = this.items[index[0]];
/* 2359 */     if (item == null) return 0L;
/* 2360 */     int childCount = GTK.gtk_tree_model_iter_n_children(this.modelHandle, item.handle);
/* 2361 */     if ((childCount != 0) && (item.isExpanded)) {
/* 2362 */       OS.g_signal_handlers_block_matched(this.handle, 16, 0, 0, 0L, 0L, 51L);
/* 2363 */       GTK.gtk_tree_view_expand_row(this.handle, path, false);
/* 2364 */       OS.g_signal_handlers_unblock_matched(this.handle, 16, 0, 0, 0L, 0L, 51L);
/*      */     }
/* 2366 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_row_inserted(long model, long path, long iter)
/*      */   {
/* 2371 */     if (this.ignoreAccessibility) {
/* 2372 */       OS.g_signal_stop_emission_by_name(model, OS.row_inserted);
/*      */     }
/* 2374 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_start_interactive_search(long widget)
/*      */   {
/* 2379 */     if (!searchEnabled()) {
/* 2380 */       OS.g_signal_stop_emission_by_name(widget, OS.start_interactive_search);
/* 2381 */       return 1L;
/*      */     }
/* 2383 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_test_collapse_row(long tree, long iter, long path)
/*      */   {
/* 2388 */     int[] index = new int[1];
/* 2389 */     GTK.gtk_tree_model_get(this.modelHandle, iter, 0, index, -1);
/* 2390 */     TreeItem item = this.items[index[0]];
/* 2391 */     Event event = new Event();
/* 2392 */     event.item = item;
/* 2393 */     boolean oldModelChanged = this.modelChanged;
/* 2394 */     this.modelChanged = false;
/* 2395 */     sendEvent(18, event);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2402 */     boolean changed = (this.modelChanged) || (!GTK.gtk_tree_view_row_expanded(this.handle, path));
/* 2403 */     this.modelChanged = oldModelChanged;
/* 2404 */     if ((isDisposed()) || (item.isDisposed())) return 1L;
/* 2405 */     item.isExpanded = false;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2417 */     if (changed) {
/* 2418 */       OS.g_signal_handlers_block_matched(this.handle, 16, 0, 0, 0L, 0L, 50L);
/* 2419 */       GTK.gtk_tree_view_collapse_row(this.handle, path);
/* 2420 */       OS.g_signal_handlers_unblock_matched(this.handle, 16, 0, 0, 0L, 0L, 50L);
/* 2421 */       return 1L;
/*      */     }
/* 2423 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_test_expand_row(long tree, long iter, long path)
/*      */   {
/* 2428 */     int[] index = new int[1];
/* 2429 */     GTK.gtk_tree_model_get(this.modelHandle, iter, 0, index, -1);
/* 2430 */     TreeItem item = this.items[index[0]];
/* 2431 */     Event event = new Event();
/* 2432 */     event.item = item;
/* 2433 */     boolean oldModelChanged = this.modelChanged;
/* 2434 */     this.modelChanged = false;
/* 2435 */     sendEvent(17, event);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2442 */     boolean changed = (this.modelChanged) || (GTK.gtk_tree_view_row_expanded(this.handle, path));
/* 2443 */     this.modelChanged = oldModelChanged;
/* 2444 */     if ((isDisposed()) || (item.isDisposed())) return 1L;
/* 2445 */     item.isExpanded = true;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2461 */     if ((changed) || (this.expandAll)) {
/* 2462 */       OS.g_signal_handlers_block_matched(this.handle, 16, 0, 0, 0L, 0L, 51L);
/* 2463 */       GTK.gtk_tree_view_expand_row(this.handle, path, false);
/* 2464 */       OS.g_signal_handlers_unblock_matched(this.handle, 16, 0, 0, 0L, 0L, 51L);
/* 2465 */       return 1L;
/*      */     }
/* 2467 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_toggled(long renderer, long pathStr)
/*      */   {
/* 2472 */     long path = GTK.gtk_tree_path_new_from_string(pathStr);
/* 2473 */     if (path == 0L) return 0L;
/* 2474 */     TreeItem item = null;
/* 2475 */     long iter = OS.g_malloc(GTK.GtkTreeIter_sizeof());
/* 2476 */     if (GTK.gtk_tree_model_get_iter(this.modelHandle, iter, path)) {
/* 2477 */       item = _getItem(iter);
/*      */     }
/* 2479 */     OS.g_free(iter);
/* 2480 */     GTK.gtk_tree_path_free(path);
/* 2481 */     if (item != null) {
/* 2482 */       item.setChecked(!item.getChecked());
/* 2483 */       Event event = new Event();
/* 2484 */       event.detail = 32;
/* 2485 */       event.item = item;
/* 2486 */       sendSelectionEvent(13, event, false);
/*      */     }
/* 2488 */     return 0L;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   void gtk_widget_size_request(long widget, GtkRequisition requisition)
/*      */   {
/* 2499 */     if (this.columnCount == 0) {
/* 2500 */       super.gtk_widget_size_request(widget, requisition);
/* 2501 */       return;
/*      */     }
/* 2503 */     long columns = GTK.gtk_tree_view_get_columns(this.handle);long list = columns;
/* 2504 */     boolean fixVisible = columns != 0L;
/* 2505 */     while (list != 0L) {
/* 2506 */       long column = OS.g_list_data(list);
/* 2507 */       if (GTK.gtk_tree_view_column_get_visible(column)) {
/* 2508 */         fixVisible = false;
/* 2509 */         break;
/*      */       }
/* 2511 */       list = OS.g_list_next(list);
/*      */     }
/* 2513 */     long columnHandle = 0L;
/* 2514 */     if (fixVisible) {
/* 2515 */       columnHandle = OS.g_list_data(columns);
/* 2516 */       GTK.gtk_tree_view_column_set_visible(columnHandle, true);
/*      */     }
/* 2518 */     super.gtk_widget_size_request(widget, requisition);
/* 2519 */     if (fixVisible) {
/* 2520 */       GTK.gtk_tree_view_column_set_visible(columnHandle, false);
/*      */     }
/* 2522 */     if (columns != 0L) OS.g_list_free(columns);
/*      */   }
/*      */   
/*      */   void hideFirstColumn() {
/* 2526 */     long firstColumn = GTK.gtk_tree_view_get_column(this.handle, 0);
/* 2527 */     GTK.gtk_tree_view_column_set_visible(firstColumn, false);
/*      */   }
/*      */   
/*      */   void hookEvents()
/*      */   {
/* 2532 */     super.hookEvents();
/* 2533 */     long selection = GTK.gtk_tree_view_get_selection(this.handle);
/* 2534 */     OS.g_signal_connect_closure(selection, OS.changed, this.display.getClosure(6), false);
/* 2535 */     OS.g_signal_connect_closure(this.handle, OS.row_activated, this.display.getClosure(41), false);
/* 2536 */     OS.g_signal_connect_closure(this.handle, OS.test_expand_row, this.display.getClosure(51), false);
/* 2537 */     OS.g_signal_connect_closure(this.handle, OS.test_collapse_row, this.display.getClosure(50), false);
/* 2538 */     OS.g_signal_connect_closure(this.handle, OS.expand_collapse_cursor_row, this.display.getClosure(17), false);
/* 2539 */     OS.g_signal_connect_closure(this.modelHandle, OS.row_has_child_toggled, this.display.getClosure(84), false);
/* 2540 */     if (this.checkRenderer != 0L) {
/* 2541 */       OS.g_signal_connect_closure(this.checkRenderer, OS.toggled, this.display.getClosure(53), false);
/*      */     }
/* 2543 */     OS.g_signal_connect_closure(this.handle, OS.start_interactive_search, this.display.getClosure(69), false);
/* 2544 */     if (fixAccessibility()) {
/* 2545 */       OS.g_signal_connect_closure(this.modelHandle, OS.row_inserted, this.display.getClosure(64), true);
/* 2546 */       OS.g_signal_connect_closure(this.modelHandle, OS.row_deleted, this.display.getClosure(65), true);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int indexOf(TreeColumn column)
/*      */   {
/* 2570 */     checkWidget();
/* 2571 */     if (column == null) error(4);
/* 2572 */     for (int i = 0; i < this.columnCount; i++) {
/* 2573 */       if (this.columns[i] == column) return i;
/*      */     }
/* 2575 */     return -1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int indexOf(TreeItem item)
/*      */   {
/* 2599 */     checkWidget();
/* 2600 */     if (item == null) error(4);
/* 2601 */     if (item.isDisposed()) error(5);
/* 2602 */     int index = -1;
/* 2603 */     long path = GTK.gtk_tree_model_get_path(this.modelHandle, item.handle);
/* 2604 */     int depth = GTK.gtk_tree_path_get_depth(path);
/* 2605 */     if (depth == 1) {
/* 2606 */       long indices = GTK.gtk_tree_path_get_indices(path);
/* 2607 */       if (indices != 0L) {
/* 2608 */         int[] temp = new int[1];
/* 2609 */         C.memmove(temp, indices, 4L);
/* 2610 */         index = temp[0];
/*      */       }
/*      */     }
/* 2613 */     GTK.gtk_tree_path_free(path);
/* 2614 */     return index;
/*      */   }
/*      */   
/*      */   boolean mnemonicHit(char key)
/*      */   {
/* 2619 */     for (int i = 0; i < this.columnCount; i++) {
/* 2620 */       long labelHandle = this.columns[i].labelHandle;
/* 2621 */       if ((labelHandle != 0L) && (mnemonicHit(labelHandle, key))) return true;
/*      */     }
/* 2623 */     return false;
/*      */   }
/*      */   
/*      */   boolean mnemonicMatch(char key)
/*      */   {
/* 2628 */     for (int i = 0; i < this.columnCount; i++) {
/* 2629 */       long labelHandle = this.columns[i].labelHandle;
/* 2630 */       if ((labelHandle != 0L) && (mnemonicMatch(labelHandle, key))) return true;
/*      */     }
/* 2632 */     return false;
/*      */   }
/*      */   
/*      */   long paintWindow()
/*      */   {
/* 2637 */     GTK.gtk_widget_realize(this.handle);
/* 2638 */     return GTK.gtk_tree_view_get_bin_window(this.handle);
/*      */   }
/*      */   
/*      */   void recreateRenderers() {
/* 2642 */     if (this.checkRenderer != 0L) {
/* 2643 */       this.display.removeWidget(this.checkRenderer);
/* 2644 */       OS.g_object_unref(this.checkRenderer);
/* 2645 */       this.checkRenderer = (this.ownerDraw ? OS.g_object_new(this.display.gtk_cell_renderer_toggle_get_type(), 0L) : GTK.gtk_cell_renderer_toggle_new());
/* 2646 */       if (this.checkRenderer == 0L) error(2);
/* 2647 */       OS.g_object_ref(this.checkRenderer);
/* 2648 */       this.display.addWidget(this.checkRenderer, this);
/* 2649 */       OS.g_signal_connect_closure(this.checkRenderer, OS.toggled, this.display.getClosure(53), false);
/*      */     }
/* 2651 */     if (this.columnCount == 0) {
/* 2652 */       createRenderers(GTK.gtk_tree_view_get_column(this.handle, 0), 6, true, 0);
/*      */     } else {
/* 2654 */       for (int i = 0; i < this.columnCount; i++) {
/* 2655 */         TreeColumn column = this.columns[i];
/* 2656 */         createRenderers(column.handle, column.modelIndex, i == 0, column.style);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   void redrawBackgroundImage()
/*      */   {
/* 2663 */     Control control = findBackgroundControl();
/* 2664 */     if ((control != null) && (control.backgroundImage != null)) {
/* 2665 */       redrawWidget(0, 0, 0, 0, true, false, false);
/*      */     }
/*      */   }
/*      */   
/*      */   void register()
/*      */   {
/* 2671 */     super.register();
/* 2672 */     this.display.addWidget(GTK.gtk_tree_view_get_selection(this.handle), this);
/* 2673 */     if (this.checkRenderer != 0L) this.display.addWidget(this.checkRenderer, this);
/* 2674 */     this.display.addWidget(this.modelHandle, this);
/*      */   }
/*      */   
/*      */   void releaseItem(TreeItem item, boolean release) {
/* 2678 */     int[] index = new int[1];
/* 2679 */     GTK.gtk_tree_model_get(this.modelHandle, item.handle, 0, index, -1);
/* 2680 */     if (index[0] == -1) return;
/* 2681 */     if (release) item.release(false);
/* 2682 */     this.items[index[0]] = null;
/*      */   }
/*      */   
/*      */   void releaseItems(long parentIter) {
/* 2686 */     int[] index = new int[1];
/* 2687 */     long iter = OS.g_malloc(GTK.GtkTreeIter_sizeof());
/* 2688 */     boolean valid = GTK.gtk_tree_model_iter_children(this.modelHandle, iter, parentIter);
/* 2689 */     while (valid) {
/* 2690 */       releaseItems(iter);
/* 2691 */       if (!isDisposed()) {
/* 2692 */         GTK.gtk_tree_model_get(this.modelHandle, iter, 0, index, -1);
/* 2693 */         if (index[0] != -1) {
/* 2694 */           TreeItem item = this.items[index[0]];
/* 2695 */           if (item != null) releaseItem(item, true);
/*      */         }
/*      */       }
/* 2698 */       valid = GTK.gtk_tree_model_iter_next(this.modelHandle, iter);
/*      */     }
/* 2700 */     OS.g_free(iter);
/*      */   }
/*      */   
/*      */   void releaseChildren(boolean destroy)
/*      */   {
/* 2705 */     if (this.items != null) {
/* 2706 */       for (int i = 0; i < this.items.length; i++) {
/* 2707 */         TreeItem item = this.items[i];
/* 2708 */         if ((item != null) && (!item.isDisposed())) {
/* 2709 */           item.release(false);
/*      */         }
/*      */       }
/* 2712 */       this.items = null;
/*      */     }
/* 2714 */     if (this.columns != null) {
/* 2715 */       for (int i = 0; i < this.columnCount; i++) {
/* 2716 */         TreeColumn column = this.columns[i];
/* 2717 */         if ((column != null) && (!column.isDisposed())) {
/* 2718 */           column.release(false);
/*      */         }
/*      */       }
/* 2721 */       this.columns = null;
/*      */     }
/* 2723 */     super.releaseChildren(destroy);
/*      */   }
/*      */   
/*      */   void releaseWidget()
/*      */   {
/* 2728 */     super.releaseWidget();
/* 2729 */     if (this.modelHandle != 0L) OS.g_object_unref(this.modelHandle);
/* 2730 */     this.modelHandle = 0L;
/* 2731 */     if (this.checkRenderer != 0L) OS.g_object_unref(this.checkRenderer);
/* 2732 */     this.checkRenderer = 0L;
/* 2733 */     if (this.imageList != null) this.imageList.dispose();
/* 2734 */     if (this.headerImageList != null) this.headerImageList.dispose();
/* 2735 */     this.imageList = (this.headerImageList = null);
/* 2736 */     this.currentItem = null;
/*      */   }
/*      */   
/*      */   void remove(long parentIter, int start, int end) {
/* 2740 */     if (start > end) return;
/* 2741 */     int itemCount = GTK.gtk_tree_model_iter_n_children(this.modelHandle, parentIter);
/* 2742 */     if ((0 > start) || (start > end) || (end >= itemCount)) {
/* 2743 */       error(6);
/*      */     }
/* 2745 */     long selection = GTK.gtk_tree_view_get_selection(this.handle);
/* 2746 */     long iter = OS.g_malloc(GTK.GtkTreeIter_sizeof());
/* 2747 */     if (iter == 0L) error(2);
/* 2748 */     if (fixAccessibility()) {
/* 2749 */       this.ignoreAccessibility = true;
/*      */     }
/* 2751 */     for (int i = start; i <= end; i++) {
/* 2752 */       GTK.gtk_tree_model_iter_nth_child(this.modelHandle, iter, parentIter, start);
/* 2753 */       int[] value = new int[1];
/* 2754 */       GTK.gtk_tree_model_get(this.modelHandle, iter, 0, value, -1);
/* 2755 */       TreeItem item = value[0] != -1 ? this.items[value[0]] : null;
/* 2756 */       if ((item != null) && (!item.isDisposed())) {
/* 2757 */         item.dispose();
/*      */       } else {
/* 2759 */         OS.g_signal_handlers_block_matched(selection, 16, 0, 0, 0L, 0L, 6L);
/* 2760 */         GTK.gtk_tree_store_remove(this.modelHandle, iter);
/* 2761 */         OS.g_signal_handlers_unblock_matched(selection, 16, 0, 0, 0L, 0L, 6L);
/*      */       }
/*      */     }
/* 2764 */     if (fixAccessibility()) {
/* 2765 */       this.ignoreAccessibility = false;
/* 2766 */       OS.g_object_notify(this.handle, OS.model);
/*      */     }
/* 2768 */     OS.g_free(iter);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeAll()
/*      */   {
/* 2780 */     checkWidget();
/* 2781 */     for (int i = 0; i < this.items.length; i++) {
/* 2782 */       TreeItem item = this.items[i];
/* 2783 */       if ((item != null) && (!item.isDisposed())) item.release(false);
/*      */     }
/* 2785 */     this.items = new TreeItem[4];
/* 2786 */     long selection = GTK.gtk_tree_view_get_selection(this.handle);
/* 2787 */     OS.g_signal_handlers_block_matched(selection, 16, 0, 0, 0L, 0L, 6L);
/* 2788 */     if (fixAccessibility()) {
/* 2789 */       this.ignoreAccessibility = true;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2796 */     GTK.gtk_tree_view_set_model(this.handle, 0L);
/* 2797 */     GTK.gtk_tree_store_clear(this.modelHandle);
/* 2798 */     GTK.gtk_tree_view_set_model(this.handle, this.modelHandle);
/* 2799 */     if (fixAccessibility()) {
/* 2800 */       this.ignoreAccessibility = false;
/* 2801 */       OS.g_object_notify(this.handle, OS.model);
/*      */     }
/* 2803 */     OS.g_signal_handlers_unblock_matched(selection, 16, 0, 0, 0L, 0L, 6L);
/*      */     
/* 2805 */     if (!searchEnabled()) {
/* 2806 */       GTK.gtk_tree_view_set_search_column(this.handle, -1);
/*      */     }
/*      */     else {
/* 2809 */       int firstColumn = this.columnCount == 0 ? 6 : this.columns[0].modelIndex;
/* 2810 */       GTK.gtk_tree_view_set_search_column(this.handle, firstColumn + 1);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeSelectionListener(SelectionListener listener)
/*      */   {
/* 2832 */     checkWidget();
/* 2833 */     if (listener == null) error(4);
/* 2834 */     this.eventTable.unhook(13, listener);
/* 2835 */     this.eventTable.unhook(14, listener);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeTreeListener(TreeListener listener)
/*      */   {
/* 2856 */     checkWidget();
/* 2857 */     if (listener == null) error(4);
/* 2858 */     if (this.eventTable == null) return;
/* 2859 */     this.eventTable.unhook(17, listener);
/* 2860 */     this.eventTable.unhook(18, listener);
/*      */   }
/*      */   
/*      */   void sendMeasureEvent(long cell, long width, long height) {
/* 2864 */     if ((!this.ignoreSize) && (GTK.GTK_IS_CELL_RENDERER_TEXT(cell)) && (hooks(41))) {
/* 2865 */       long iter = OS.g_object_get_qdata(cell, Display.SWT_OBJECT_INDEX2);
/* 2866 */       TreeItem item = null;
/* 2867 */       if (iter != 0L) item = _getItem(iter);
/* 2868 */       if ((item != null) && (!item.isDisposed())) {
/* 2869 */         int columnIndex = 0;
/* 2870 */         if (this.columnCount > 0) {
/* 2871 */           long columnHandle = OS.g_object_get_qdata(cell, Display.SWT_OBJECT_INDEX1);
/* 2872 */           for (int i = 0; i < this.columnCount; i++) {
/* 2873 */             if (this.columns[i].handle == columnHandle) {
/* 2874 */               columnIndex = i;
/* 2875 */               break;
/*      */             }
/*      */           }
/*      */         }
/* 2879 */         int[] contentWidth = new int[1];int[] contentHeight = new int[1];
/* 2880 */         if (width != 0L) C.memmove(contentWidth, width, 4L);
/* 2881 */         if (height != 0L) C.memmove(contentHeight, height, 4L);
/* 2882 */         if (GTK.GTK3) {
/* 2883 */           GTK.gtk_cell_renderer_get_preferred_height_for_width(cell, this.handle, contentWidth[0], contentHeight, null);
/*      */         }
/* 2885 */         Image image = item.getImage(columnIndex);
/* 2886 */         int imageWidth = 0;
/* 2887 */         if ((image != null) && (!image.isDisposed())) {
/* 2888 */           Rectangle bounds = image.getBounds();
/* 2889 */           imageWidth = bounds.width;
/*      */         }
/* 2891 */         contentWidth[0] += imageWidth;
/* 2892 */         GC gc = new GC(this);
/* 2893 */         gc.setFont(item.getFont(columnIndex));
/* 2894 */         Event event = new Event();
/* 2895 */         event.item = item;
/* 2896 */         event.index = columnIndex;
/* 2897 */         event.gc = gc;
/* 2898 */         Rectangle eventRect = new Rectangle(0, 0, contentWidth[0], contentHeight[0]);
/* 2899 */         event.setBounds(DPIUtil.autoScaleDown(eventRect));
/* 2900 */         long path = GTK.gtk_tree_model_get_path(this.modelHandle, iter);
/* 2901 */         long selection = GTK.gtk_tree_view_get_selection(this.handle);
/* 2902 */         if (GTK.gtk_tree_selection_path_is_selected(selection, path)) {
/* 2903 */           event.detail = 2;
/*      */         }
/* 2905 */         GTK.gtk_tree_path_free(path);
/* 2906 */         sendEvent(41, event);
/* 2907 */         gc.dispose();
/* 2908 */         Rectangle rect = DPIUtil.autoScaleUp(event.getBounds());
/* 2909 */         contentWidth[0] = (rect.width - imageWidth);
/* 2910 */         if (contentHeight[0] < rect.height) contentHeight[0] = rect.height;
/* 2911 */         if (width != 0L) C.memmove(width, contentWidth, 4L);
/* 2912 */         if (height != 0L) C.memmove(height, contentHeight, 4L);
/* 2913 */         if (GTK.GTK3) {
/* 2914 */           GTK.gtk_cell_renderer_set_fixed_size(cell, contentWidth[0], contentHeight[0]);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   long rendererGetPreferredWidthProc(long cell, long handle, long minimun_size, long natural_size)
/*      */   {
/* 2922 */     long g_class = OS.g_type_class_peek_parent(OS.G_OBJECT_GET_CLASS(cell));
/* 2923 */     GtkCellRendererClass klass = new GtkCellRendererClass();
/* 2924 */     OS.memmove(klass, g_class);
/* 2925 */     OS.call(klass.get_preferred_width, cell, handle, minimun_size, natural_size);
/* 2926 */     sendMeasureEvent(cell, minimun_size, 0L);
/* 2927 */     return 0L;
/*      */   }
/*      */   
/*      */   long rendererGetSizeProc(long cell, long widget, long cell_area, long x_offset, long y_offset, long width, long height)
/*      */   {
/* 2932 */     long g_class = OS.g_type_class_peek_parent(OS.G_OBJECT_GET_CLASS(cell));
/* 2933 */     GtkCellRendererClass klass = new GtkCellRendererClass();
/* 2934 */     OS.memmove(klass, g_class);
/* 2935 */     OS.call_get_size(klass.get_size, cell, this.handle, cell_area, x_offset, y_offset, width, height);
/* 2936 */     sendMeasureEvent(cell, width, height);
/* 2937 */     return 0L;
/*      */   }
/*      */   
/*      */   long rendererRenderProc(long cell, long cr, long widget, long background_area, long cell_area, long flags)
/*      */   {
/* 2942 */     rendererRender(cell, cr, 0L, widget, background_area, cell_area, 0L, flags);
/* 2943 */     return 0L;
/*      */   }
/*      */   
/*      */   long rendererRenderProc(long cell, long window, long widget, long background_area, long cell_area, long expose_area, long flags)
/*      */   {
/* 2948 */     rendererRender(cell, 0L, window, widget, background_area, cell_area, expose_area, flags);
/* 2949 */     return 0L;
/*      */   }
/*      */   
/*      */   void rendererRender(long cell, long cr, long window, long widget, long background_area, long cell_area, long expose_area, long flags) {
/* 2953 */     TreeItem item = null;
/* 2954 */     boolean wasSelected = false;
/* 2955 */     long iter = OS.g_object_get_qdata(cell, Display.SWT_OBJECT_INDEX2);
/* 2956 */     if (iter != 0L) item = _getItem(iter);
/* 2957 */     long columnHandle = OS.g_object_get_qdata(cell, Display.SWT_OBJECT_INDEX1);
/* 2958 */     int columnIndex = 0;
/* 2959 */     if (this.columnCount > 0) {
/* 2960 */       for (int i = 0; i < this.columnCount; i++) {
/* 2961 */         if (this.columns[i].handle == columnHandle) {
/* 2962 */           columnIndex = i;
/* 2963 */           break;
/*      */         }
/*      */       }
/*      */     }
/* 2967 */     if ((item != null) && (
/* 2968 */       (GTK.GTK_IS_CELL_RENDERER_TOGGLE(cell)) || (
/* 2969 */       ((GTK.GTK_IS_CELL_RENDERER_PIXBUF(cell)) || (GTK.GTK_VERSION > OS.VERSION(3, 13, 0))) && ((columnIndex != 0) || ((this.style & 0x20) == 0))))) {
/* 2970 */       this.drawFlags = ((int)flags);
/* 2971 */       this.drawState = 16;
/* 2972 */       long[] ptr = new long[1];
/* 2973 */       GTK.gtk_tree_model_get(this.modelHandle, item.handle, 4, ptr, -1);
/* 2974 */       if (ptr[0] == 0L) {
/* 2975 */         int modelIndex = this.columnCount == 0 ? 6 : this.columns[columnIndex].modelIndex;
/* 2976 */         GTK.gtk_tree_model_get(this.modelHandle, item.handle, modelIndex + 3, ptr, -1);
/*      */       }
/* 2978 */       if (ptr[0] != 0L) {
/* 2979 */         this.drawState |= 0x8;
/* 2980 */         if (GTK.GTK3) {
/* 2981 */           GDK.gdk_rgba_free(ptr[0]);
/*      */         } else {
/* 2983 */           GDK.gdk_color_free(ptr[0]);
/*      */         }
/*      */       }
/* 2986 */       if ((flags & 1L) != 0L) this.drawState |= 0x2;
/* 2987 */       if (((!GTK.GTK3) || ((flags & 1L) == 0L)) && 
/* 2988 */         ((flags & 0x10) != 0L)) { this.drawState |= 0x4;
/*      */       }
/*      */       
/* 2991 */       GdkRectangle rect = new GdkRectangle();
/* 2992 */       long path = GTK.gtk_tree_model_get_path(this.modelHandle, iter);
/* 2993 */       GTK.gtk_tree_view_get_background_area(this.handle, path, columnHandle, rect);
/* 2994 */       GTK.gtk_tree_path_free(path);
/*      */       
/* 2996 */       if ((cr != 0L) && (GTK.GTK_VERSION > OS.VERSION(3, 9, 0)) && (GTK.GTK_VERSION <= OS.VERSION(3, 14, 8))) {
/* 2997 */         GdkRectangle r2 = new GdkRectangle();
/* 2998 */         GDK.gdk_cairo_get_clip_rectangle(cr, r2);
/* 2999 */         rect.x = r2.x;
/* 3000 */         rect.width = r2.width;
/*      */       }
/* 3002 */       if (((this.drawState & 0x2) == 0) && (
/* 3003 */         ((this.state & 0x8000) != 0) || (this.backgroundImage != null))) {
/* 3004 */         Control control = findBackgroundControl();
/* 3005 */         if (control != null) {
/* 3006 */           if (cr != 0L) {
/* 3007 */             Cairo.cairo_save(cr);
/* 3008 */             if (!GTK.GTK3) {
/* 3009 */               Cairo.cairo_reset_clip(cr);
/*      */             }
/*      */           }
/* 3012 */           drawBackground(control, window, cr, 0L, rect.x, rect.y, rect.width, rect.height);
/* 3013 */           if (cr != 0L) {
/* 3014 */             Cairo.cairo_restore(cr);
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 3021 */       long textRenderer = getTextRenderer(columnHandle);
/* 3022 */       if (textRenderer != 0L) { gtk_cell_renderer_get_preferred_size(textRenderer, this.handle, null, null);
/*      */       }
/* 3024 */       if (hooks(40))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3030 */         wasSelected = (this.drawState & 0x2) != 0;
/* 3031 */         if (wasSelected) {
/* 3032 */           Control control = findBackgroundControl();
/* 3033 */           if (control == null) control = this;
/* 3034 */           if (!GTK.GTK3) {
/* 3035 */             if (cr != 0L) {
/* 3036 */               Cairo.cairo_save(cr);
/* 3037 */               Cairo.cairo_reset_clip(cr);
/*      */             }
/* 3039 */             drawBackground(control, window, cr, 0L, rect.x, rect.y, rect.width, rect.height);
/* 3040 */             if (cr != 0L) {
/* 3041 */               Cairo.cairo_restore(cr);
/*      */             }
/*      */           }
/*      */         }
/* 3045 */         GC gc = getGC(cr);
/* 3046 */         if ((this.drawState & 0x2) != 0) {
/* 3047 */           gc.setBackground(this.display.getSystemColor(26));
/* 3048 */           gc.setForeground(this.display.getSystemColor(27));
/*      */         } else {
/* 3050 */           gc.setBackground(item.getBackground(columnIndex));
/* 3051 */           gc.setForeground(item.getForeground(columnIndex));
/*      */         }
/* 3053 */         gc.setFont(item.getFont(columnIndex));
/* 3054 */         if ((this.style & 0x8000000) != 0) { rect.x = (getClientWidth() - rect.width - rect.x);
/*      */         }
/* 3056 */         if ((GTK.GTK_VERSION >= OS.VERSION(3, 9, 0)) && (cr != 0L)) {
/* 3057 */           GdkRectangle r = new GdkRectangle();
/* 3058 */           GDK.gdk_cairo_get_clip_rectangle(cr, r);
/* 3059 */           Rectangle rect2 = DPIUtil.autoScaleDown(new Rectangle(rect.x, r.y, r.width, r.height));
/*      */           
/* 3061 */           gc.setClipping(rect2.x, rect2.y, rect2.width, rect2.height);
/* 3062 */           if (GTK.GTK_VERSION <= OS.VERSION(3, 14, 8)) {
/* 3063 */             rect.width = r.width;
/*      */           }
/*      */         } else {
/* 3066 */           Rectangle rect2 = DPIUtil.autoScaleDown(new Rectangle(rect.x, rect.y, rect.width, rect.height));
/*      */           
/* 3068 */           gc.setClipping(rect2.x, rect2.y, rect2.width, rect2.height);
/*      */         }
/* 3070 */         Event event = new Event();
/* 3071 */         event.item = item;
/* 3072 */         event.index = columnIndex;
/* 3073 */         event.gc = gc;
/* 3074 */         Rectangle eventRect = new Rectangle(rect.x, rect.y, rect.width, rect.height);
/* 3075 */         event.setBounds(DPIUtil.autoScaleDown(eventRect));
/* 3076 */         event.detail = this.drawState;
/* 3077 */         sendEvent(40, event);
/* 3078 */         if (GTK.GTK3) {
/* 3079 */           this.drawForegroundRGBA = null;
/*      */         } else {
/* 3081 */           this.drawForeground = null;
/*      */         }
/* 3083 */         this.drawState = (event.doit ? event.detail : 0);
/* 3084 */         this.drawFlags &= 0xFFFFFFEE;
/* 3085 */         if ((this.drawState & 0x2) != 0) this.drawFlags |= 0x1;
/* 3086 */         if ((this.drawState & 0x4) != 0) this.drawFlags |= 0x10;
/* 3087 */         if ((this.drawState & 0x2) != 0) {
/* 3088 */           if (!GTK.GTK3) {
/* 3089 */             long style = GTK.gtk_widget_get_style(widget);
/*      */             
/* 3091 */             byte[] detail = Converter.wcsToMbcs("cell_odd", true);
/* 3092 */             GTK.gtk_paint_flat_box(style, window, 3, 0, rect, widget, detail, rect.x, rect.y, rect.width, rect.height);
/*      */           }
/*      */         }
/* 3095 */         else if (wasSelected) {
/* 3096 */           if (GTK.GTK3) {
/* 3097 */             this.drawForegroundRGBA = gc.getForeground().handleRGBA;
/*      */           } else {
/* 3099 */             this.drawForeground = gc.getForeground().handle;
/*      */           }
/*      */         }
/*      */         
/* 3103 */         gc.dispose();
/*      */       }
/*      */     }
/*      */     
/* 3107 */     if (((this.drawState & 0x8) != 0) && ((this.drawState & 0x2) == 0))
/*      */     {
/* 3109 */       GC gc = getGC(cr);
/* 3110 */       gc.setBackground(item.getBackground(columnIndex));
/* 3111 */       GdkRectangle rect = new GdkRectangle();
/* 3112 */       OS.memmove(rect, background_area, GdkRectangle.sizeof);
/* 3113 */       gc.fillRectangle(DPIUtil.autoScaleDown(new Rectangle(rect.x, rect.y, rect.width, rect.height)));
/* 3114 */       gc.dispose();
/*      */     }
/* 3116 */     if (((this.drawState & 0x10) != 0) || (GTK.GTK_IS_CELL_RENDERER_TOGGLE(cell))) {
/* 3117 */       long g_class = OS.g_type_class_peek_parent(OS.G_OBJECT_GET_CLASS(cell));
/* 3118 */       GtkCellRendererClass klass = new GtkCellRendererClass();
/* 3119 */       OS.memmove(klass, g_class);
/* 3120 */       if ((this.drawForeground != null) && (GTK.GTK_IS_CELL_RENDERER_TEXT(cell)) && (!GTK.GTK3)) {
/* 3121 */         OS.g_object_set(cell, OS.foreground_gdk, this.drawForeground, 0L);
/* 3122 */       } else if ((this.drawForegroundRGBA != null) && (GTK.GTK_IS_CELL_RENDERER_TEXT(cell)) && (GTK.GTK3)) {
/* 3123 */         OS.g_object_set(cell, OS.foreground_rgba, this.drawForegroundRGBA, 0L);
/*      */       }
/* 3125 */       if (GTK.GTK3) {
/* 3126 */         OS.call(klass.render, cell, cr, widget, background_area, cell_area, this.drawFlags);
/*      */       } else {
/* 3128 */         OS.call(klass.render, cell, window, widget, background_area, cell_area, expose_area, this.drawFlags);
/*      */       }
/*      */     }
/* 3131 */     if ((item != null) && 
/* 3132 */       (GTK.GTK_IS_CELL_RENDERER_TEXT(cell)) && 
/* 3133 */       (hooks(42))) {
/* 3134 */       if (wasSelected) this.drawState |= 0x2;
/* 3135 */       GdkRectangle rect = new GdkRectangle();
/* 3136 */       long path = GTK.gtk_tree_model_get_path(this.modelHandle, iter);
/* 3137 */       GTK.gtk_tree_view_get_cell_area(this.handle, path, columnHandle, rect);
/* 3138 */       GTK.gtk_tree_path_free(path);
/*      */       
/* 3140 */       if ((cr != 0L) && (GTK.GTK_VERSION > OS.VERSION(3, 9, 0)) && (GTK.GTK_VERSION <= OS.VERSION(3, 14, 8))) {
/* 3141 */         GdkRectangle r2 = new GdkRectangle();
/* 3142 */         GDK.gdk_cairo_get_clip_rectangle(cr, r2);
/* 3143 */         rect.x = r2.x;
/* 3144 */         rect.width = r2.width;
/*      */       }
/* 3146 */       this.ignoreSize = true;
/* 3147 */       int[] contentX = new int[1];int[] contentWidth = new int[1];
/* 3148 */       gtk_cell_renderer_get_preferred_size(cell, this.handle, contentWidth, null);
/* 3149 */       gtk_tree_view_column_cell_get_position(columnHandle, cell, contentX, null);
/* 3150 */       this.ignoreSize = false;
/* 3151 */       Image image = item.getImage(columnIndex);
/* 3152 */       int imageWidth = 0;
/* 3153 */       if (image != null) {
/* 3154 */         Rectangle bounds = image.getBounds();
/* 3155 */         imageWidth = bounds.width;
/*      */       }
/*      */       
/*      */ 
/* 3159 */       if ((cr != 0L) && (GTK.GTK_VERSION > OS.VERSION(3, 9, 0)) && (GTK.GTK_VERSION <= OS.VERSION(3, 14, 8))) {
/* 3160 */         rect.x -= imageWidth;
/* 3161 */         rect.width += imageWidth;
/*      */       }
/* 3163 */       contentX[0] -= imageWidth;
/* 3164 */       contentWidth[0] += imageWidth;
/* 3165 */       GC gc = getGC(cr);
/* 3166 */       if ((this.drawState & 0x2) != 0) { Color foreground;
/*      */         Color background;
/* 3168 */         Color foreground; if ((GTK.gtk_widget_has_focus(this.handle)) || (GTK.GTK3)) {
/* 3169 */           Color background = this.display.getSystemColor(26);
/* 3170 */           foreground = this.display.getSystemColor(27);
/*      */ 
/*      */ 
/*      */         }
/*      */         else
/*      */         {
/*      */ 
/* 3177 */           background = Color.gtk_new(this.display, this.display.COLOR_LIST_SELECTION_INACTIVE);
/* 3178 */           foreground = Color.gtk_new(this.display, this.display.COLOR_LIST_SELECTION_TEXT_INACTIVE);
/*      */         }
/* 3180 */         gc.setBackground(background);
/* 3181 */         gc.setForeground(foreground);
/*      */       } else {
/* 3183 */         gc.setBackground(item.getBackground(columnIndex));
/*      */         Color foreground;
/* 3185 */         Color foreground; if (GTK.GTK3) {
/* 3186 */           foreground = this.drawForegroundRGBA != null ? Color.gtk_new(this.display, this.drawForegroundRGBA) : item.getForeground(columnIndex);
/*      */         } else {
/* 3188 */           foreground = this.drawForeground != null ? Color.gtk_new(this.display, this.drawForeground) : item.getForeground(columnIndex);
/*      */         }
/* 3190 */         gc.setForeground(foreground);
/*      */       }
/* 3192 */       gc.setFont(item.getFont(columnIndex));
/* 3193 */       if ((this.style & 0x8000000) != 0) {
/* 3194 */         rect.x = (getClientWidth() - rect.width - rect.x);
/*      */       }
/*      */       
/* 3197 */       Rectangle rect2 = DPIUtil.autoScaleDown(new Rectangle(rect.x, rect.y, rect.width, rect.height));
/*      */       
/* 3199 */       gc.setClipping(rect2.x, rect2.y, rect2.width, rect2.height);
/*      */       
/* 3201 */       Event event = new Event();
/* 3202 */       event.item = item;
/* 3203 */       event.index = columnIndex;
/* 3204 */       event.gc = gc;
/* 3205 */       Rectangle eventRect = new Rectangle(rect.x + contentX[0], rect.y, contentWidth[0], rect.height);
/* 3206 */       event.setBounds(DPIUtil.autoScaleDown(eventRect));
/* 3207 */       event.detail = this.drawState;
/* 3208 */       sendEvent(42, event);
/* 3209 */       gc.dispose();
/*      */     }
/*      */   }
/*      */   
/*      */   private GC getGC(long cr)
/*      */   {
/*      */     GC gc;
/*      */     GC gc;
/* 3217 */     if (GTK.GTK3) {
/* 3218 */       GCData gcData = new GCData();
/* 3219 */       gcData.cairo = cr;
/* 3220 */       gc = GC.gtk_new(this, gcData);
/*      */     } else {
/* 3222 */       gc = new GC(this);
/*      */     }
/* 3224 */     return gc;
/*      */   }
/*      */   
/*      */   void resetCustomDraw() {
/* 3228 */     if (((this.style & 0x10000000) != 0) || (this.ownerDraw)) return;
/* 3229 */     int end = Math.max(1, this.columnCount);
/* 3230 */     for (int i = 0; i < end; i++) {
/* 3231 */       boolean customDraw = this.columnCount != 0 ? this.columns[i].customDraw : this.firstCustomDraw;
/* 3232 */       if (customDraw) {
/* 3233 */         long column = GTK.gtk_tree_view_get_column(this.handle, i);
/* 3234 */         long textRenderer = getTextRenderer(column);
/* 3235 */         GTK.gtk_tree_view_column_set_cell_data_func(column, textRenderer, 0L, 0L, 0L);
/* 3236 */         if (this.columnCount != 0) this.columns[i].customDraw = false;
/*      */       }
/*      */     }
/* 3239 */     this.firstCustomDraw = false;
/*      */   }
/*      */   
/*      */   void reskinChildren(int flags)
/*      */   {
/* 3244 */     if (this.items != null) {
/* 3245 */       for (int i = 0; i < this.items.length; i++) {
/* 3246 */         TreeItem item = this.items[i];
/* 3247 */         if (item != null) item.reskinChildren(flags);
/*      */       }
/*      */     }
/* 3250 */     if (this.columns != null) {
/* 3251 */       for (int i = 0; i < this.columns.length; i++) {
/* 3252 */         TreeColumn column = this.columns[i];
/* 3253 */         if (column != null) column.reskinChildren(flags);
/*      */       }
/*      */     }
/* 3256 */     super.reskinChildren(flags);
/*      */   }
/*      */   
/*      */   boolean searchEnabled() {
/* 3260 */     if ((this.style & 0x10000000) != 0) return false;
/* 3261 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setInsertMark(TreeItem item, boolean before)
/*      */   {
/* 3281 */     checkWidget();
/* 3282 */     if (item == null) {
/* 3283 */       GTK.gtk_tree_view_set_drag_dest_row(this.handle, 0L, 0);
/* 3284 */       return;
/*      */     }
/* 3286 */     if (item.isDisposed()) error(5);
/* 3287 */     if (item.parent != this) return;
/* 3288 */     Rectangle rect = item.getBoundsInPixels();
/* 3289 */     long[] path = new long[1];
/* 3290 */     GTK.gtk_widget_realize(this.handle);
/* 3291 */     if (!GTK.gtk_tree_view_get_path_at_pos(this.handle, rect.x, rect.y, path, null, null, null)) return;
/* 3292 */     if (path[0] == 0L) return;
/* 3293 */     int position = before ? 0 : 1;
/* 3294 */     GTK.gtk_tree_view_set_drag_dest_row(this.handle, path[0], position);
/* 3295 */     GTK.gtk_tree_path_free(path[0]);
/*      */   }
/*      */   
/*      */   void setItemCount(long parentIter, int count) {
/* 3299 */     int itemCount = GTK.gtk_tree_model_iter_n_children(this.modelHandle, parentIter);
/* 3300 */     if (count == itemCount) return;
/* 3301 */     boolean isVirtual = (this.style & 0x10000000) != 0;
/* 3302 */     if (!isVirtual) setRedraw(false);
/* 3303 */     remove(parentIter, count, itemCount - 1);
/* 3304 */     if (isVirtual) {
/* 3305 */       if (fixAccessibility()) {
/* 3306 */         this.ignoreAccessibility = true;
/*      */       }
/* 3308 */       for (int i = itemCount; i < count; i++) {
/* 3309 */         long iter = OS.g_malloc(GTK.GtkTreeIter_sizeof());
/* 3310 */         if (iter == 0L) error(2);
/* 3311 */         GTK.gtk_tree_store_append(this.modelHandle, iter, parentIter);
/* 3312 */         GTK.gtk_tree_store_set(this.modelHandle, iter, 0, -1, -1);
/* 3313 */         OS.g_free(iter);
/*      */       }
/* 3315 */       if (fixAccessibility()) {
/* 3316 */         this.ignoreAccessibility = false;
/* 3317 */         OS.g_object_notify(this.handle, OS.model);
/*      */       }
/*      */     } else {
/* 3320 */       for (int i = itemCount; i < count; i++) {
/* 3321 */         new TreeItem(this, parentIter, 0, i, true);
/*      */       }
/*      */     }
/* 3324 */     if (!isVirtual) setRedraw(true);
/* 3325 */     this.modelChanged = true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setItemCount(int count)
/*      */   {
/* 3341 */     checkWidget();
/* 3342 */     count = Math.max(0, count);
/* 3343 */     setItemCount(0L, count);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void select(TreeItem item)
/*      */   {
/* 3364 */     checkWidget();
/* 3365 */     if (item == null) error(4);
/* 3366 */     if (item.isDisposed()) error(5);
/* 3367 */     boolean fixColumn = showFirstColumn();
/* 3368 */     long selection = GTK.gtk_tree_view_get_selection(this.handle);
/* 3369 */     OS.g_signal_handlers_block_matched(selection, 16, 0, 0, 0L, 0L, 6L);
/* 3370 */     GTK.gtk_tree_selection_select_iter(selection, item.handle);
/* 3371 */     OS.g_signal_handlers_unblock_matched(selection, 16, 0, 0, 0L, 0L, 6L);
/* 3372 */     if (fixColumn) { hideFirstColumn();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void selectAll()
/*      */   {
/* 3387 */     checkWidget();
/* 3388 */     if ((this.style & 0x4) != 0) return;
/* 3389 */     boolean fixColumn = showFirstColumn();
/* 3390 */     long selection = GTK.gtk_tree_view_get_selection(this.handle);
/* 3391 */     OS.g_signal_handlers_block_matched(selection, 16, 0, 0, 0L, 0L, 6L);
/* 3392 */     GTK.gtk_tree_selection_select_all(selection);
/* 3393 */     OS.g_signal_handlers_unblock_matched(selection, 16, 0, 0, 0L, 0L, 6L);
/* 3394 */     if (fixColumn) hideFirstColumn();
/*      */   }
/*      */   
/*      */   void setBackgroundGdkColor(GdkColor color)
/*      */   {
/* 3399 */     assert (!GTK.GTK3) : "GTK2 code was run by GTK3";
/* 3400 */     super.setBackgroundGdkColor(color);
/* 3401 */     GTK.gtk_widget_modify_base(this.handle, 0, color);
/*      */   }
/*      */   
/*      */   void setBackgroundGdkRGBA(long context, long handle, GdkRGBA rgba)
/*      */   {
/* 3406 */     assert (GTK.GTK3) : "GTK3 code was run by GTK2";
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3412 */     if (rgba == null) {
/* 3413 */       this.background = defaultBackground();
/*      */     } else {
/* 3415 */       this.background = rgba;
/*      */     }
/* 3417 */     GdkRGBA selectedBackground = this.display.getSystemColor(26).handleRGBA;
/* 3418 */     if (GTK.GTK_VERSION >= OS.VERSION(3, 14, 0)) {
/* 3419 */       String name = GTK.GTK_VERSION >= OS.VERSION(3, 20, 0) ? "treeview" : "GtkTreeView";
/*      */       
/* 3421 */       String css = name + " {background-color: " + this.display.gtk_rgba_to_css_string(this.background) + ";}\n" + name + ":selected {background-color: " + this.display.gtk_rgba_to_css_string(selectedBackground) + ";}";
/*      */       
/*      */ 
/* 3424 */       this.cssBackground = css;
/*      */       
/*      */ 
/* 3427 */       String finalCss = this.display.gtk_css_create_css_color_string(this.cssBackground, this.cssForeground, 8);
/* 3428 */       gtk_css_provider_load_from_css(context, finalCss);
/*      */     } else {
/* 3430 */       super.setBackgroundGdkRGBA(context, handle, rgba);
/* 3431 */       GTK.gtk_widget_override_background_color(handle, 4, selectedBackground);
/*      */     }
/*      */   }
/*      */   
/*      */   void setBackgroundPixmap(Image image)
/*      */   {
/* 3437 */     this.ownerDraw = true;
/* 3438 */     recreateRenderers();
/*      */   }
/*      */   
/*      */   int setBounds(int x, int y, int width, int height, boolean move, boolean resize)
/*      */   {
/* 3443 */     int result = super.setBounds(x, y, width, height, move, resize);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3452 */     GTK.gtk_widget_realize(this.handle);
/* 3453 */     return result;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setColumnOrder(int[] order)
/*      */   {
/* 3481 */     checkWidget();
/* 3482 */     if (order == null) error(4);
/* 3483 */     if (this.columnCount == 0) {
/* 3484 */       if (order.length > 0) error(5);
/* 3485 */       return;
/*      */     }
/* 3487 */     if (order.length != this.columnCount) error(5);
/* 3488 */     boolean[] seen = new boolean[this.columnCount];
/* 3489 */     for (int i = 0; i < order.length; i++) {
/* 3490 */       int index = order[i];
/* 3491 */       if ((index < 0) || (index >= this.columnCount)) error(6);
/* 3492 */       if (seen[index] != 0) error(5);
/* 3493 */       seen[index] = true;
/*      */     }
/* 3495 */     long baseColumn = 0L;
/* 3496 */     for (int i = 0; i < order.length; i++) {
/* 3497 */       long column = this.columns[order[i]].handle;
/* 3498 */       GTK.gtk_tree_view_move_column_after(this.handle, column, baseColumn);
/* 3499 */       baseColumn = column;
/*      */     }
/*      */   }
/*      */   
/*      */   void setFontDescription(long font)
/*      */   {
/* 3505 */     super.setFontDescription(font);
/* 3506 */     TreeColumn[] columns = getColumns();
/* 3507 */     for (int i = 0; i < columns.length; i++) {
/* 3508 */       if (columns[i] != null) {
/* 3509 */         columns[i].setFontDescription(font);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   void setForegroundGdkRGBA(GdkRGBA rgba)
/*      */   {
/* 3516 */     if (GTK.GTK_VERSION >= OS.VERSION(3, 14, 0)) {
/* 3517 */       this.foreground = rgba;
/* 3518 */       GdkRGBA toSet = rgba == null ? this.display.COLOR_LIST_FOREGROUND_RGBA : rgba;
/* 3519 */       setForegroundGdkRGBA(this.handle, toSet);
/*      */     } else {
/* 3521 */       super.setForegroundGdkRGBA(rgba);
/*      */     }
/*      */   }
/*      */   
/*      */   void setForegroundGdkColor(GdkColor color)
/*      */   {
/* 3527 */     assert (!GTK.GTK3) : "GTK2 code was run by GTK3";
/* 3528 */     setForegroundColor(this.handle, color, false);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setHeaderBackground(Color color)
/*      */   {
/* 3551 */     checkWidget();
/* 3552 */     if (color != null) {
/* 3553 */       if (color.isDisposed())
/* 3554 */         error(5);
/* 3555 */       if (!color.equals(this.headerBackground)) {}
/*      */     }
/* 3557 */     else if (this.headerBackground == null) { return; }
/* 3558 */     this.headerBackground = color;
/* 3559 */     if (GTK.GTK3) { GdkRGBA background;
/*      */       GdkRGBA background;
/* 3561 */       if (this.headerBackground != null) {
/* 3562 */         background = this.headerBackground.handleRGBA;
/*      */       } else {
/* 3564 */         background = defaultBackground();
/*      */       }
/* 3566 */       String name = GTK.GTK_VERSION >= OS.VERSION(3, 20, 0) ? "button" : "GtkButton";
/*      */       
/* 3568 */       String css = name + " {background: " + this.display.gtk_rgba_to_css_string(background) + ";}\n";
/* 3569 */       this.headerCSSBackground = css;
/* 3570 */       String finalCss = this.display.gtk_css_create_css_color_string(this.headerCSSBackground, this.headerCSSForeground, 8);
/* 3571 */       for (TreeColumn column : this.columns) {
/* 3572 */         if (column != null) {
/* 3573 */           long context = GTK.gtk_widget_get_style_context(column.buttonHandle);
/*      */           
/* 3575 */           long provider = GTK.gtk_css_provider_new();
/* 3576 */           GTK.gtk_style_context_add_provider(context, provider, 600);
/* 3577 */           OS.g_object_unref(provider);
/* 3578 */           GTK.gtk_css_provider_load_from_data(provider, Converter.wcsToMbcs(finalCss, true), -1L, null);
/* 3579 */           GTK.gtk_style_context_invalidate(context);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setHeaderForeground(Color color)
/*      */   {
/* 3606 */     checkWidget();
/* 3607 */     if (color != null) {
/* 3608 */       if (color.isDisposed())
/* 3609 */         error(5);
/* 3610 */       if (!color.equals(this.headerForeground)) {}
/*      */     }
/* 3612 */     else if (this.headerForeground == null) { return; }
/* 3613 */     this.headerForeground = color;
/* 3614 */     if (GTK.GTK3) { GdkRGBA foreground;
/*      */       GdkRGBA foreground;
/* 3616 */       if (this.headerForeground != null) {
/* 3617 */         foreground = this.headerForeground.handleRGBA;
/*      */       } else {
/* 3619 */         foreground = this.display.COLOR_LIST_FOREGROUND_RGBA;
/*      */       }
/* 3621 */       String name = GTK.GTK_VERSION >= OS.VERSION(3, 20, 0) ? "button" : "GtkButton";
/* 3622 */       String css = name + " {color: " + this.display.gtk_rgba_to_css_string(foreground) + ";}";
/* 3623 */       this.headerCSSForeground = css;
/* 3624 */       String finalCss = this.display.gtk_css_create_css_color_string(this.headerCSSBackground, this.headerCSSForeground, 16);
/* 3625 */       for (TreeColumn column : this.columns) {
/* 3626 */         if (column != null) {
/* 3627 */           long context = GTK.gtk_widget_get_style_context(column.buttonHandle);
/*      */           
/* 3629 */           long provider = GTK.gtk_css_provider_new();
/* 3630 */           GTK.gtk_style_context_add_provider(context, provider, 600);
/* 3631 */           OS.g_object_unref(provider);
/* 3632 */           GTK.gtk_css_provider_load_from_data(provider, Converter.wcsToMbcs(finalCss, true), -1L, null);
/* 3633 */           GTK.gtk_style_context_invalidate(context);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setHeaderVisible(boolean show)
/*      */   {
/* 3659 */     checkWidget();
/* 3660 */     GTK.gtk_tree_view_set_headers_visible(this.handle, show);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setLinesVisible(boolean show)
/*      */   {
/* 3683 */     checkWidget();
/* 3684 */     if (!GTK.GTK3) {
/* 3685 */       GTK.gtk_tree_view_set_rules_hint(this.handle, show);
/*      */     }
/*      */     
/* 3688 */     GTK.gtk_tree_view_set_grid_lines(this.handle, show ? 2 : 0);
/*      */   }
/*      */   
/*      */   void setModel(long newModel) {
/* 3692 */     this.display.removeWidget(this.modelHandle);
/* 3693 */     OS.g_object_unref(this.modelHandle);
/* 3694 */     this.modelHandle = newModel;
/* 3695 */     this.display.addWidget(this.modelHandle, this);
/* 3696 */     if (fixAccessibility()) {
/* 3697 */       OS.g_signal_connect_closure(this.modelHandle, OS.row_inserted, this.display.getClosure(64), true);
/* 3698 */       OS.g_signal_connect_closure(this.modelHandle, OS.row_deleted, this.display.getClosure(65), true);
/*      */     }
/*      */   }
/*      */   
/*      */   void setOrientation(boolean create)
/*      */   {
/* 3704 */     super.setOrientation(create);
/* 3705 */     if (this.items != null) {
/* 3706 */       for (int i = 0; i < this.items.length; i++) {
/* 3707 */         if (this.items[i] != null) this.items[i].setOrientation(create);
/*      */       }
/*      */     }
/* 3710 */     if (this.columns != null) {
/* 3711 */       for (int i = 0; i < this.columns.length; i++) {
/* 3712 */         if (this.columns[i] != null) this.columns[i].setOrientation(create);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   void setParentBackground()
/*      */   {
/* 3719 */     this.ownerDraw = true;
/* 3720 */     recreateRenderers();
/*      */   }
/*      */   
/*      */   void setParentGdkWindow(Control child)
/*      */   {
/* 3725 */     long parentGdkWindow = eventWindow();
/* 3726 */     GTK.gtk_widget_set_parent_window(child.topHandle(), parentGdkWindow);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3737 */     if (GTK.GTK_VERSION >= OS.VERSION(3, 10, 0)) {
/* 3738 */       this.hasChildren = true;
/* 3739 */       connectFixedHandleDraw();
/*      */     }
/*      */   }
/*      */   
/*      */   void setScrollWidth(long column, TreeItem item) {
/* 3744 */     if ((this.columnCount != 0) || (this.currentItem == item)) return;
/* 3745 */     int width = GTK.gtk_tree_view_column_get_fixed_width(column);
/* 3746 */     int itemWidth = calculateWidth(column, item.handle, true);
/* 3747 */     if (width < itemWidth) {
/* 3748 */       GTK.gtk_tree_view_column_set_fixed_width(column, itemWidth);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSelection(TreeItem item)
/*      */   {
/* 3774 */     checkWidget();
/* 3775 */     if (item == null) error(4);
/* 3776 */     setSelection(new TreeItem[] { item });
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSelection(TreeItem[] items)
/*      */   {
/* 3803 */     checkWidget();
/* 3804 */     if (items == null) error(4);
/* 3805 */     deselectAll();
/* 3806 */     int length = items.length;
/* 3807 */     if ((length == 0) || (((this.style & 0x4) != 0) && (length > 1))) return;
/* 3808 */     boolean fixColumn = showFirstColumn();
/* 3809 */     long selection = GTK.gtk_tree_view_get_selection(this.handle);
/* 3810 */     OS.g_signal_handlers_block_matched(selection, 16, 0, 0, 0L, 0L, 6L);
/* 3811 */     boolean first = true;
/* 3812 */     for (int i = 0; i < length; i++) {
/* 3813 */       TreeItem item = items[i];
/* 3814 */       if (item != null) {
/* 3815 */         if (item.isDisposed()) break;
/* 3816 */         if (item.parent == this) {
/* 3817 */           long path = GTK.gtk_tree_model_get_path(this.modelHandle, item.handle);
/* 3818 */           showItem(path, false);
/* 3819 */           if (first) {
/* 3820 */             GTK.gtk_tree_view_set_cursor(this.handle, path, 0L, false);
/*      */           }
/* 3822 */           GTK.gtk_tree_selection_select_iter(selection, item.handle);
/* 3823 */           GTK.gtk_tree_path_free(path);
/* 3824 */           first = false;
/*      */         } } }
/* 3826 */     OS.g_signal_handlers_unblock_matched(selection, 16, 0, 0, 0L, 0L, 6L);
/* 3827 */     if (fixColumn) { hideFirstColumn();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSortColumn(TreeColumn column)
/*      */   {
/* 3848 */     checkWidget();
/* 3849 */     if ((column != null) && (column.isDisposed())) error(5);
/* 3850 */     if ((this.sortColumn != null) && (!this.sortColumn.isDisposed())) {
/* 3851 */       GTK.gtk_tree_view_column_set_sort_indicator(this.sortColumn.handle, false);
/*      */     }
/* 3853 */     this.sortColumn = column;
/* 3854 */     if ((this.sortColumn != null) && (this.sortDirection != 0)) {
/* 3855 */       GTK.gtk_tree_view_column_set_sort_indicator(this.sortColumn.handle, true);
/* 3856 */       GTK.gtk_tree_view_column_set_sort_order(this.sortColumn.handle, this.sortDirection == 1024 ? 0 : 1);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSortDirection(int direction)
/*      */   {
/* 3874 */     checkWidget();
/* 3875 */     if ((direction != 128) && (direction != 1024) && (direction != 0)) return;
/* 3876 */     this.sortDirection = direction;
/* 3877 */     if ((this.sortColumn == null) || (this.sortColumn.isDisposed())) return;
/* 3878 */     if (this.sortDirection == 0) {
/* 3879 */       GTK.gtk_tree_view_column_set_sort_indicator(this.sortColumn.handle, false);
/*      */     } else {
/* 3881 */       GTK.gtk_tree_view_column_set_sort_indicator(this.sortColumn.handle, true);
/* 3882 */       GTK.gtk_tree_view_column_set_sort_order(this.sortColumn.handle, this.sortDirection == 1024 ? 0 : 1);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setTopItem(TreeItem item)
/*      */   {
/*      */     long vAdjustment;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     long vAdjustment;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3916 */     if (GTK.GTK3) {
/* 3917 */       vAdjustment = GTK.gtk_scrollable_get_vadjustment(this.handle);
/*      */     }
/*      */     else {
/* 3920 */       vAdjustment = GTK.gtk_tree_view_get_vadjustment(this.handle);
/*      */     }
/* 3922 */     this.cachedAdjustment = GTK.gtk_adjustment_get_value(vAdjustment);
/* 3923 */     this.topItem = item;
/*      */     
/* 3925 */     if (item == null) error(4);
/* 3926 */     if (item.isDisposed()) error(5);
/* 3927 */     if (item.parent != this) return;
/* 3928 */     long path = GTK.gtk_tree_model_get_path(this.modelHandle, item.handle);
/* 3929 */     showItem(path, false);
/* 3930 */     GTK.gtk_tree_view_scroll_to_cell(this.handle, path, 0L, true, 0.0F, 0.0F);
/* 3931 */     GTK.gtk_tree_path_free(path);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void showColumn(TreeColumn column)
/*      */   {
/* 3953 */     checkWidget();
/* 3954 */     if (column == null) error(4);
/* 3955 */     if (column.isDisposed()) error(5);
/* 3956 */     if (column.parent != this) { return;
/*      */     }
/* 3958 */     GTK.gtk_tree_view_scroll_to_cell(this.handle, 0L, column.handle, false, 0.0F, 0.0F);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   boolean showFirstColumn()
/*      */   {
/* 3966 */     int columnCount = Math.max(1, this.columnCount);
/* 3967 */     for (int i = 0; i < columnCount; i++) {
/* 3968 */       long column = GTK.gtk_tree_view_get_column(this.handle, i);
/* 3969 */       if (GTK.gtk_tree_view_column_get_visible(column)) return false;
/*      */     }
/* 3971 */     long firstColumn = GTK.gtk_tree_view_get_column(this.handle, 0);
/* 3972 */     GTK.gtk_tree_view_column_set_visible(firstColumn, true);
/* 3973 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void showSelection()
/*      */   {
/* 3989 */     checkWidget();
/* 3990 */     TreeItem[] items = getSelection();
/* 3991 */     if ((items.length != 0) && (items[0] != null)) showItem(items[0]);
/*      */   }
/*      */   
/*      */   void showItem(long path, boolean scroll) {
/* 3995 */     int depth = GTK.gtk_tree_path_get_depth(path);
/* 3996 */     if (depth > 1) {
/* 3997 */       int[] indices = new int[depth - 1];
/* 3998 */       long indicesPtr = GTK.gtk_tree_path_get_indices(path);
/* 3999 */       C.memmove(indices, indicesPtr, indices.length * 4);
/* 4000 */       long tempPath = GTK.gtk_tree_path_new();
/* 4001 */       for (int i = 0; i < indices.length; i++) {
/* 4002 */         GTK.gtk_tree_path_append_index(tempPath, indices[i]);
/* 4003 */         GTK.gtk_tree_view_expand_row(this.handle, tempPath, false);
/*      */       }
/* 4005 */       GTK.gtk_tree_path_free(tempPath);
/*      */     }
/* 4007 */     if (scroll) {
/* 4008 */       GdkRectangle cellRect = new GdkRectangle();
/* 4009 */       GTK.gtk_widget_realize(this.handle);
/* 4010 */       GTK.gtk_tree_view_get_cell_area(this.handle, path, 0L, cellRect);
/* 4011 */       boolean isHidden = (cellRect.y == 0) && (cellRect.height == 0);
/* 4012 */       int[] tx = new int[1];int[] ty = new int[1];
/* 4013 */       GTK.gtk_tree_view_convert_bin_window_to_tree_coords(this.handle, cellRect.x, cellRect.y, tx, ty);
/* 4014 */       if (!isHidden) {
/* 4015 */         GdkRectangle visibleRect = new GdkRectangle();
/* 4016 */         GTK.gtk_tree_view_get_visible_rect(this.handle, visibleRect);
/* 4017 */         if ((ty[0] < visibleRect.y) || (ty[0] + cellRect.height > visibleRect.y + visibleRect.height)) {
/* 4018 */           isHidden = true;
/*      */         }
/*      */       }
/* 4021 */       if (isHidden) {
/* 4022 */         GTK.gtk_tree_view_scroll_to_cell(this.handle, path, 0L, depth != 1, 0.5F, 0.0F);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void showItem(TreeItem item)
/*      */   {
/* 4046 */     checkWidget();
/* 4047 */     if (item == null) error(4);
/* 4048 */     if (item.isDisposed()) error(5);
/* 4049 */     if (item.parent != this) return;
/* 4050 */     long path = GTK.gtk_tree_model_get_path(this.modelHandle, item.handle);
/* 4051 */     showItem(path, true);
/* 4052 */     GTK.gtk_tree_path_free(path);
/*      */   }
/*      */   
/*      */   void updateScrollBarValue(ScrollBar bar)
/*      */   {
/* 4057 */     super.updateScrollBarValue(bar);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4065 */     long parentHandle = parentingHandle();
/* 4066 */     long list = GTK.gtk_container_get_children(parentHandle);
/* 4067 */     if (list == 0L) return;
/* 4068 */     long temp = list;
/* 4069 */     while (temp != 0L) {
/* 4070 */       long widget = OS.g_list_data(temp);
/* 4071 */       if (widget != 0L) GTK.gtk_widget_queue_resize(widget);
/* 4072 */       temp = OS.g_list_next(temp);
/*      */     }
/* 4074 */     OS.g_list_free(list);
/*      */   }
/*      */   
/*      */   long windowProc(long handle, long arg0, long user_data)
/*      */   {
/* 4079 */     switch ((int)user_data)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */     case 18: 
/* 4085 */       if ((GTK.GTK_VERSION >= OS.VERSION(3, 10, 0)) && (this.hasChildren)) {
/* 4086 */         propagateDraw(handle, arg0);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       break;
/*      */     case 19: 
/* 4096 */       int itemCount = GTK.gtk_tree_model_iter_n_children(this.modelHandle, 0L);
/* 4097 */       if ((itemCount == 0) && ((this.state & 0x40) == 0) && (
/* 4098 */         ((this.state & 0x8000) != 0) || (this.backgroundImage != null))) {
/* 4099 */         Control control = findBackgroundControl();
/* 4100 */         if (control != null) {
/* 4101 */           GdkEventExpose gdkEvent = new GdkEventExpose();
/* 4102 */           OS.memmove(gdkEvent, arg0, GdkEventExpose.sizeof);
/* 4103 */           long window = GTK.gtk_tree_view_get_bin_window(handle);
/* 4104 */           if (window == gdkEvent.window)
/* 4105 */             drawBackground(control, window, gdkEvent.region, gdkEvent.area_x, gdkEvent.area_y, gdkEvent.area_width, gdkEvent.area_height);
/*      */         }
/*      */       }
/* 4108 */       break;
/*      */     }
/*      */     
/*      */     
/*      */ 
/* 4113 */     return super.windowProc(handle, arg0, user_data);
/*      */   }
/*      */   
/*      */   Point resizeCalculationsGTK3(long widget, int width, int height)
/*      */   {
/* 4118 */     Point sizes = super.resizeCalculationsGTK3(widget, width, height);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 4130 */     if ((widget == this.scrolledHandle) && (GTK.GTK_VERSION >= OS.VERSION(3, 14, 0)) && (getHeaderVisible())) {
/* 4131 */       int hScrollBarHeight = hScrollBarWidth();
/* 4132 */       if (hScrollBarHeight > 0) {
/* 4133 */         sizes.y = Math.max(sizes.y, getHeaderHeight() + hScrollBarHeight + getBorderWidth() * 2);
/*      */       }
/*      */     }
/* 4136 */     return sizes;
/*      */   }
/*      */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/widgets/Tree.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */