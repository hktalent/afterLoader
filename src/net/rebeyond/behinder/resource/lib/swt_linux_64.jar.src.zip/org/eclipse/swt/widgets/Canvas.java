/*     */ package org.eclipse.swt.widgets;
/*     */ 
/*     */ import org.eclipse.swt.graphics.Font;
/*     */ import org.eclipse.swt.graphics.GC;
/*     */ import org.eclipse.swt.graphics.Image;
/*     */ import org.eclipse.swt.graphics.Point;
/*     */ import org.eclipse.swt.graphics.Rectangle;
/*     */ import org.eclipse.swt.internal.DPIUtil;
/*     */ import org.eclipse.swt.internal.cairo.Cairo;
/*     */ import org.eclipse.swt.internal.gtk.GDK;
/*     */ import org.eclipse.swt.internal.gtk.GTK;
/*     */ import org.eclipse.swt.internal.gtk.GdkRectangle;
/*     */ import org.eclipse.swt.internal.gtk.GtkRequisition;
/*     */ import org.eclipse.swt.internal.gtk.OS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Canvas
/*     */   extends Composite
/*     */ {
/*     */   Caret caret;
/*     */   IME ime;
/*     */   boolean blink;
/*     */   boolean drawFlag;
/*     */   
/*     */   Canvas() {}
/*     */   
/*     */   public Canvas(Composite parent, int style)
/*     */   {
/*  76 */     super(parent, checkStyle(style));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void drawBackground(GC gc, int x, int y, int width, int height)
/*     */   {
/* 101 */     drawBackground(gc, x, y, width, height, 0, 0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Caret getCaret()
/*     */   {
/* 123 */     checkWidget();
/* 124 */     return this.caret;
/*     */   }
/*     */   
/*     */   Point getIMCaretPos()
/*     */   {
/* 129 */     if (this.caret == null) return super.getIMCaretPos();
/* 130 */     return new Point(this.caret.x, this.caret.y);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public IME getIME()
/*     */   {
/* 146 */     checkWidget();
/* 147 */     return this.ime;
/*     */   }
/*     */   
/*     */   long gtk_button_press_event(long widget, long event)
/*     */   {
/* 152 */     if (this.ime != null) {
/* 153 */       long result = this.ime.gtk_button_press_event(widget, event);
/* 154 */       if (result != 0L) return result;
/*     */     }
/* 156 */     return super.gtk_button_press_event(widget, event);
/*     */   }
/*     */   
/*     */   long gtk_commit(long imcontext, long text)
/*     */   {
/* 161 */     if (this.ime != null) {
/* 162 */       long result = this.ime.gtk_commit(imcontext, text);
/* 163 */       if (result != 0L) return result;
/*     */     }
/* 165 */     return super.gtk_commit(imcontext, text);
/*     */   }
/*     */   
/*     */   long gtk_draw(long widget, long cairo)
/*     */   {
/* 170 */     if ((this.state & 0x40) != 0) return 0L;
/*     */     long result;
/* 172 */     if (GTK.GTK_VERSION < OS.VERSION(3, 22, 0)) {
/* 173 */       boolean isFocus = (this.caret != null) && (this.caret.isFocusCaret());
/* 174 */       if (isFocus) this.caret.killFocus();
/* 175 */       long result = super.gtk_draw(widget, cairo);
/* 176 */       if (isFocus) this.caret.setFocus();
/*     */     } else {
/* 178 */       result = super.gtk_draw(widget, cairo);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 184 */       if ((this.caret != null) && (this.blink == true)) {
/* 185 */         drawCaret(widget, cairo);
/* 186 */         this.blink = false;
/*     */       }
/*     */     }
/* 189 */     return result;
/*     */   }
/*     */   
/*     */   private void drawCaret(long widget, long cairo) {
/* 193 */     if (isDisposed()) return;
/* 194 */     if (cairo == 0L) error(2);
/* 195 */     if (this.drawFlag) {
/* 196 */       Cairo.cairo_save(cairo);
/* 197 */       if ((this.caret.image != null) && (!this.caret.image.isDisposed()) && (this.caret.image.mask == 0L)) {
/* 198 */         Cairo.cairo_set_source_rgb(cairo, 1.0D, 1.0D, 1.0D);
/* 199 */         Cairo.cairo_set_operator(cairo, 23);
/* 200 */         long surface = Cairo.cairo_get_target(cairo);
/* 201 */         int nWidth = 0;
/* 202 */         switch (Cairo.cairo_surface_get_type(surface)) {
/*     */         case 0: 
/* 204 */           nWidth = Cairo.cairo_image_surface_get_width(surface);
/* 205 */           break;
/*     */         case 3: 
/* 207 */           nWidth = Cairo.cairo_xlib_surface_get_width(surface);
/*     */         }
/*     */         
/* 210 */         int nX = this.caret.x;
/* 211 */         if ((this.style & 0x8000000) != 0) nX = getClientWidth() - nWidth - nX;
/* 212 */         Cairo.cairo_translate(cairo, nX, this.caret.y);
/* 213 */         Cairo.cairo_set_source_surface(cairo, this.caret.image.surface, 0.0D, 0.0D);
/* 214 */         Cairo.cairo_paint(cairo);
/*     */       } else {
/* 216 */         Cairo.cairo_set_source_rgb(cairo, 1.0D, 1.0D, 1.0D);
/* 217 */         Cairo.cairo_set_operator(cairo, 23);
/* 218 */         int nWidth = this.caret.width;int nHeight = this.caret.height;
/* 219 */         if (nWidth <= 0) nWidth = 1;
/* 220 */         int nX = this.caret.x;
/* 221 */         if ((this.style & 0x8000000) != 0) nX = getClientWidth() - nWidth - nX;
/* 222 */         Cairo.cairo_rectangle(cairo, nX, this.caret.y, nWidth, nHeight);
/*     */       }
/* 224 */       Cairo.cairo_fill(cairo);
/* 225 */       Cairo.cairo_restore(cairo);
/* 226 */       this.drawFlag = false;
/*     */     } else {
/* 228 */       this.drawFlag = true;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   long gtk_expose_event(long widget, long event)
/*     */   {
/* 235 */     if ((this.state & 0x40) != 0) return 0L;
/* 236 */     boolean isFocus = (this.caret != null) && (this.caret.isFocusCaret());
/* 237 */     if (isFocus) this.caret.killFocus();
/* 238 */     long result = super.gtk_expose_event(widget, event);
/* 239 */     if (isFocus) this.caret.setFocus();
/* 240 */     return result;
/*     */   }
/*     */   
/*     */   long gtk_focus_in_event(long widget, long event)
/*     */   {
/* 245 */     long result = super.gtk_focus_in_event(widget, event);
/* 246 */     if (this.caret != null) this.caret.setFocus();
/* 247 */     return result;
/*     */   }
/*     */   
/*     */   long gtk_focus_out_event(long widget, long event)
/*     */   {
/* 252 */     long result = super.gtk_focus_out_event(widget, event);
/* 253 */     if (this.caret != null) this.caret.killFocus();
/* 254 */     return result;
/*     */   }
/*     */   
/*     */   long gtk_preedit_changed(long imcontext)
/*     */   {
/* 259 */     if (this.ime != null) {
/* 260 */       long result = this.ime.gtk_preedit_changed(imcontext);
/* 261 */       if (result != 0L) return result;
/*     */     }
/* 263 */     return super.gtk_preedit_changed(imcontext);
/*     */   }
/*     */   
/*     */   void redrawWidget(int x, int y, int width, int height, boolean redrawAll, boolean all, boolean trim)
/*     */   {
/* 268 */     boolean isFocus = (this.caret != null) && (this.caret.isFocusCaret());
/* 269 */     if (isFocus) this.caret.killFocus();
/* 270 */     super.redrawWidget(x, y, width, height, redrawAll, all, trim);
/* 271 */     if (isFocus) this.caret.setFocus();
/*     */   }
/*     */   
/*     */   void releaseChildren(boolean destroy)
/*     */   {
/* 276 */     if (this.caret != null) {
/* 277 */       this.caret.release(false);
/* 278 */       this.caret = null;
/*     */     }
/* 280 */     if (this.ime != null) {
/* 281 */       this.ime.release(false);
/* 282 */       this.ime = null;
/*     */     }
/* 284 */     super.releaseChildren(destroy);
/*     */   }
/*     */   
/*     */   void reskinChildren(int flags)
/*     */   {
/* 289 */     if (this.caret != null) this.caret.reskin(flags);
/* 290 */     if (this.ime != null) this.ime.reskin(flags);
/* 291 */     super.reskinChildren(flags);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void scroll(int destX, int destY, int x, int y, int width, int height, boolean all)
/*     */   {
/* 317 */     checkWidget();
/* 318 */     if ((width <= 0) || (height <= 0)) return;
/* 319 */     Point destination = DPIUtil.autoScaleUp(new Point(destX, destY));
/* 320 */     Rectangle srcRect = DPIUtil.autoScaleUp(new Rectangle(x, y, width, height));
/* 321 */     scrollInPixels(destination.x, destination.y, srcRect.x, srcRect.y, srcRect.width, srcRect.height, all);
/*     */   }
/*     */   
/*     */   void scrollInPixels(int destX, int destY, int x, int y, int width, int height, boolean all) {
/* 325 */     if ((this.style & 0x8000000) != 0) {
/* 326 */       int clientWidth = getClientWidth();
/* 327 */       x = clientWidth - width - x;
/* 328 */       destX = clientWidth - width - destX;
/*     */     }
/* 330 */     int deltaX = destX - x;int deltaY = destY - y;
/* 331 */     if ((deltaX == 0) && (deltaY == 0)) return;
/* 332 */     if (!isVisible()) return;
/* 333 */     boolean isFocus = (this.caret != null) && (this.caret.isFocusCaret());
/* 334 */     if (isFocus) this.caret.killFocus();
/* 335 */     long window = paintWindow();
/*     */     long visibleRegion;
/* 337 */     long visibleRegion; if (GTK.GTK3) {
/* 338 */       visibleRegion = GDK.gdk_window_get_visible_region(window);
/*     */     } else {
/* 340 */       visibleRegion = GDK.gdk_drawable_get_visible_region(window);
/*     */     }
/* 342 */     GdkRectangle srcRect = new GdkRectangle();
/* 343 */     srcRect.x = x;
/* 344 */     srcRect.y = y;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 351 */     if (GTK.GTK_VERSION >= OS.VERSION(3, 16, 0)) {
/* 352 */       long hBarHandle = 0L;
/* 353 */       long vBarHandle = 0L;
/* 354 */       if (GTK.GTK_IS_SCROLLED_WINDOW(this.scrolledHandle)) {
/* 355 */         hBarHandle = GTK.gtk_scrolled_window_get_hscrollbar(this.scrolledHandle);
/* 356 */         vBarHandle = GTK.gtk_scrolled_window_get_vscrollbar(this.scrolledHandle);
/*     */       }
/* 358 */       GtkRequisition requisition = new GtkRequisition();
/* 359 */       if (hBarHandle != 0L) {
/* 360 */         gtk_widget_get_preferred_size(hBarHandle, requisition);
/* 361 */         if (requisition.height > 0) {
/* 362 */           srcRect.y = (y - requisition.height);
/*     */         }
/*     */       }
/* 365 */       if (vBarHandle != 0L) {
/* 366 */         gtk_widget_get_preferred_size(vBarHandle, requisition);
/* 367 */         if (requisition.width > 0) {
/* 368 */           srcRect.x = (x - requisition.width);
/*     */         }
/*     */       }
/*     */     }
/* 372 */     srcRect.width = width;
/* 373 */     srcRect.height = height;
/* 374 */     long copyRegion = GDK.gdk_region_rectangle(srcRect);
/* 375 */     GDK.gdk_region_intersect(copyRegion, visibleRegion);
/* 376 */     long invalidateRegion = GDK.gdk_region_rectangle(srcRect);
/* 377 */     GDK.gdk_region_subtract(invalidateRegion, visibleRegion);
/* 378 */     GDK.gdk_region_offset(invalidateRegion, deltaX, deltaY);
/* 379 */     GdkRectangle copyRect = new GdkRectangle();
/* 380 */     GDK.gdk_region_get_clipbox(copyRegion, copyRect);
/* 381 */     if ((copyRect.width != 0) && (copyRect.height != 0)) {
/* 382 */       update();
/*     */     }
/* 384 */     Control control = findBackgroundControl();
/* 385 */     if (control == null) control = this;
/* 386 */     if (control.backgroundImage != null) {
/* 387 */       redrawWidget(x, y, width, height, false, false, false);
/* 388 */       redrawWidget(destX, destY, width, height, false, false, false);
/*     */     } else {
/* 390 */       long cairo = GDK.gdk_cairo_create(window);
/* 391 */       if (Cairo.cairo_version() < Cairo.CAIRO_VERSION_ENCODE(1, 12, 0)) {
/* 392 */         GDK.gdk_cairo_set_source_window(cairo, window, 0, 0);
/*     */       } else {
/* 394 */         Cairo.cairo_push_group(cairo);
/* 395 */         GDK.gdk_cairo_set_source_window(cairo, window, 0, 0);
/* 396 */         Cairo.cairo_paint(cairo);
/* 397 */         Cairo.cairo_pop_group_to_source(cairo);
/*     */       }
/* 399 */       double[] matrix = { 1.0D, 0.0D, 0.0D, 1.0D, -deltaX, -deltaY };
/* 400 */       Cairo.cairo_pattern_set_matrix(Cairo.cairo_get_source(cairo), matrix);
/* 401 */       Cairo.cairo_rectangle(cairo, copyRect.x + deltaX, copyRect.y + deltaY, copyRect.width, copyRect.height);
/* 402 */       Cairo.cairo_clip(cairo);
/* 403 */       Cairo.cairo_paint(cairo);
/* 404 */       Cairo.cairo_destroy(cairo);
/* 405 */       boolean disjoint = (destX + width < x) || (x + width < destX) || (destY + height < y) || (y + height < destY);
/* 406 */       if (disjoint) {
/* 407 */         GdkRectangle rect = new GdkRectangle();
/* 408 */         rect.x = x;
/* 409 */         rect.y = y;
/* 410 */         rect.width = width;
/* 411 */         rect.height = height;
/* 412 */         GDK.gdk_region_union_with_rect(invalidateRegion, rect);
/*     */       } else {
/* 414 */         GdkRectangle rect = new GdkRectangle();
/* 415 */         if (deltaX != 0) {
/* 416 */           int newX = destX - deltaX;
/* 417 */           if (deltaX < 0) newX = destX + width;
/* 418 */           rect.x = newX;
/* 419 */           rect.y = y;
/* 420 */           rect.width = Math.abs(deltaX);
/* 421 */           rect.height = height;
/* 422 */           GDK.gdk_region_union_with_rect(invalidateRegion, rect);
/*     */         }
/* 424 */         if (deltaY != 0) {
/* 425 */           int newY = destY - deltaY;
/* 426 */           if (deltaY < 0) newY = destY + height;
/* 427 */           rect.x = x;
/* 428 */           rect.y = newY;
/* 429 */           rect.width = width;
/* 430 */           rect.height = Math.abs(deltaY);
/* 431 */           GDK.gdk_region_union_with_rect(invalidateRegion, rect);
/*     */         }
/*     */       }
/* 434 */       GDK.gdk_window_invalidate_region(window, invalidateRegion, all);
/*     */     }
/* 436 */     GDK.gdk_region_destroy(visibleRegion);
/* 437 */     GDK.gdk_region_destroy(copyRegion);
/* 438 */     GDK.gdk_region_destroy(invalidateRegion);
/* 439 */     if (all) {
/* 440 */       Control[] children = _getChildren();
/* 441 */       for (int i = 0; i < children.length; i++) {
/* 442 */         Control child = children[i];
/* 443 */         Rectangle rect = child.getBoundsInPixels();
/* 444 */         if ((Math.min(x + width, rect.x + rect.width) >= Math.max(x, rect.x)) && 
/* 445 */           (Math.min(y + height, rect.y + rect.height) >= Math.max(y, rect.y))) {
/* 446 */           child.setLocationInPixels(rect.x + deltaX, rect.y + deltaY);
/*     */         }
/*     */       }
/*     */     }
/* 450 */     if (isFocus) { this.caret.setFocus();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 455 */     if (GTK.GTK_VERSION >= OS.VERSION(3, 16, 0)) {
/* 456 */       redraw(false);
/*     */     }
/*     */   }
/*     */   
/*     */   int setBounds(int x, int y, int width, int height, boolean move, boolean resize)
/*     */   {
/* 462 */     boolean isFocus = (this.caret != null) && (this.caret.isFocusCaret());
/* 463 */     if (isFocus) this.caret.killFocus();
/* 464 */     int result = super.setBounds(x, y, width, height, move, resize);
/* 465 */     if (isFocus) this.caret.setFocus();
/* 466 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCaret(Caret caret)
/*     */   {
/* 490 */     checkWidget();
/* 491 */     Caret newCaret = caret;
/* 492 */     Caret oldCaret = this.caret;
/* 493 */     this.caret = newCaret;
/* 494 */     if (hasFocus()) {
/* 495 */       if (oldCaret != null) oldCaret.killFocus();
/* 496 */       if (newCaret != null) {
/* 497 */         if (newCaret.isDisposed()) error(5);
/* 498 */         newCaret.setFocus();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void setFont(Font font)
/*     */   {
/* 505 */     checkWidget();
/* 506 */     if (this.caret != null) this.caret.setFont(font);
/* 507 */     super.setFont(font);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setIME(IME ime)
/*     */   {
/* 526 */     checkWidget();
/* 527 */     if ((ime != null) && (ime.isDisposed())) error(5);
/* 528 */     this.ime = ime;
/*     */   }
/*     */   
/*     */   void updateCaret() {
/* 532 */     long imHandle = imHandle();
/* 533 */     if (imHandle == 0L) return;
/* 534 */     GdkRectangle rect = new GdkRectangle();
/* 535 */     rect.x = this.caret.x;
/* 536 */     rect.y = this.caret.y;
/* 537 */     rect.width = this.caret.width;
/* 538 */     rect.height = this.caret.height;
/* 539 */     GTK.gtk_im_context_set_cursor_location(imHandle, rect);
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/widgets/Canvas.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */