/*     */ package org.eclipse.swt.dnd;
/*     */ 
/*     */ import org.eclipse.swt.SWT;
/*     */ import org.eclipse.swt.graphics.Image;
/*     */ import org.eclipse.swt.internal.cairo.Cairo;
/*     */ import org.eclipse.swt.internal.gtk.GDK;
/*     */ import org.eclipse.swt.internal.gtk.GTK;
/*     */ import org.eclipse.swt.internal.gtk.GdkRectangle;
/*     */ import org.eclipse.swt.internal.gtk.OS;
/*     */ import org.eclipse.swt.widgets.Display;
/*     */ import org.eclipse.swt.widgets.Tree;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TreeDragSourceEffect
/*     */   extends DragSourceEffect
/*     */ {
/*  37 */   Image dragSourceImage = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TreeDragSourceEffect(Tree tree)
/*     */   {
/*  46 */     super(tree);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void dragFinished(DragSourceEvent event)
/*     */   {
/*  60 */     if (this.dragSourceImage != null) this.dragSourceImage.dispose();
/*  61 */     this.dragSourceImage = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void dragStart(DragSourceEvent event)
/*     */   {
/*  77 */     event.image = getDragSourceImage(event);
/*     */   }
/*     */   
/*     */   Image getDragSourceImage(DragSourceEvent event) {
/*  81 */     if (this.dragSourceImage != null) this.dragSourceImage.dispose();
/*  82 */     this.dragSourceImage = null;
/*     */     
/*  84 */     Tree tree = (Tree)this.control;
/*     */     
/*  86 */     if ((tree.isListening(40)) || (tree.isListening(42))) { return null;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  93 */     long handle = tree.handle;
/*  94 */     long selection = GTK.gtk_tree_view_get_selection(handle);
/*  95 */     long[] model = null;
/*  96 */     long list = GTK.gtk_tree_selection_get_selected_rows(selection, model);
/*  97 */     if (list == 0L) return null;
/*  98 */     int count = Math.min(10, OS.g_list_length(list));
/*  99 */     long originalList = list;
/*     */     
/* 101 */     Display display = tree.getDisplay();
/* 102 */     if (count == 1) {
/* 103 */       long path = OS.g_list_nth_data(list, 0);
/* 104 */       long icon = GTK.gtk_tree_view_create_row_drag_icon(handle, path);
/* 105 */       this.dragSourceImage = Image.gtk_new(display, 1, icon, 0L);
/* 106 */       GTK.gtk_tree_path_free(path);
/*     */     } else {
/* 108 */       int width = 0;int height = 0;
/* 109 */       int[] w = new int[1];int[] h = new int[1];
/* 110 */       int[] yy = new int[count];int[] hh = new int[count];
/* 111 */       long[] icons = new long[count];
/* 112 */       GdkRectangle rect = new GdkRectangle();
/* 113 */       for (int i = 0; i < count; i++) {
/* 114 */         long path = OS.g_list_data(list);
/* 115 */         GTK.gtk_tree_view_get_cell_area(handle, path, 0L, rect);
/* 116 */         icons[i] = GTK.gtk_tree_view_create_row_drag_icon(handle, path);
/* 117 */         if (GTK.GTK3) {
/* 118 */           switch (Cairo.cairo_surface_get_type(icons[i])) {
/*     */           case 0: 
/* 120 */             w[0] = Cairo.cairo_image_surface_get_width(icons[i]);
/* 121 */             h[0] = Cairo.cairo_image_surface_get_height(icons[i]);
/* 122 */             break;
/*     */           case 3: 
/* 124 */             w[0] = Cairo.cairo_xlib_surface_get_width(icons[i]);
/* 125 */             h[0] = Cairo.cairo_xlib_surface_get_height(icons[i]);
/*     */           }
/*     */           
/*     */         } else {
/* 129 */           GDK.gdk_pixmap_get_size(icons[i], w, h);
/*     */         }
/* 131 */         width = Math.max(width, w[0]);
/* 132 */         height = rect.y + h[0] - yy[0];
/* 133 */         yy[i] = rect.y;
/* 134 */         hh[i] = h[0];
/* 135 */         list = OS.g_list_next(list);
/* 136 */         GTK.gtk_tree_path_free(path); }
/*     */       long cairo;
/*     */       long surface;
/*     */       long cairo;
/* 140 */       if (GTK.GTK3) {
/* 141 */         long surface = Cairo.cairo_image_surface_create(0, width, height);
/* 142 */         if (surface == 0L) SWT.error(2);
/* 143 */         cairo = Cairo.cairo_create(surface);
/*     */       } else {
/* 145 */         surface = GDK.gdk_pixmap_new(GDK.gdk_get_default_root_window(), width, height, -1);
/* 146 */         if (surface == 0L) SWT.error(2);
/* 147 */         cairo = GDK.gdk_cairo_create(surface);
/*     */       }
/* 149 */       if (cairo == 0L) SWT.error(2);
/* 150 */       Cairo.cairo_set_operator(cairo, 1);
/* 151 */       for (int i = 0; i < count; i++) {
/* 152 */         if (GTK.GTK3) {
/* 153 */           Cairo.cairo_set_source_surface(cairo, icons[i], 2.0D, yy[i] - yy[0] + 2);
/*     */         } else {
/* 155 */           GDK.gdk_cairo_set_source_pixmap(cairo, icons[i], 0.0D, yy[i] - yy[0]);
/*     */         }
/* 157 */         Cairo.cairo_rectangle(cairo, 0.0D, yy[i] - yy[0], width, hh[i]);
/* 158 */         Cairo.cairo_fill(cairo);
/* 159 */         if (GTK.GTK3) {
/* 160 */           Cairo.cairo_surface_destroy(icons[i]);
/*     */         }
/*     */       }
/* 163 */       Cairo.cairo_destroy(cairo);
/* 164 */       if (GTK.GTK3) {
/* 165 */         this.dragSourceImage = Image.gtk_new(display, 1, surface, 0L);
/*     */       } else {
/* 167 */         long pixbuf = GDK.gdk_pixbuf_new(0, true, 8, width, height);
/* 168 */         if (pixbuf == 0L) SWT.error(2);
/* 169 */         long colormap = GDK.gdk_colormap_get_system();
/* 170 */         GDK.gdk_pixbuf_get_from_drawable(pixbuf, surface, colormap, 0, 0, 0, 0, width, height);
/* 171 */         this.dragSourceImage = Image.gtk_new_from_pixbuf(display, 1, pixbuf);
/*     */       }
/*     */     }
/* 174 */     OS.g_list_free(originalList);
/* 175 */     return this.dragSourceImage;
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/dnd/TreeDragSourceEffect.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */