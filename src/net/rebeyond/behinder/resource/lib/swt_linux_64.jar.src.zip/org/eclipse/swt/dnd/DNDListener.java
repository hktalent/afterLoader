/*     */ package org.eclipse.swt.dnd;
/*     */ 
/*     */ import org.eclipse.swt.internal.SWTEventListener;
/*     */ import org.eclipse.swt.widgets.Event;
/*     */ import org.eclipse.swt.widgets.TypedListener;
/*     */ import org.eclipse.swt.widgets.Widget;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DNDListener
/*     */   extends TypedListener
/*     */ {
/*     */   Widget dndWidget;
/*     */   
/*     */   DNDListener(SWTEventListener listener)
/*     */   {
/*  24 */     super(listener);
/*     */   }
/*     */   
/*     */   public void handleEvent(Event e) {
/*  28 */     switch (e.type) {
/*     */     case 2008: 
/*  30 */       DragSourceEvent event = new DragSourceEvent((DNDEvent)e);
/*  31 */       DragSourceEffect sourceEffect = ((DragSource)this.dndWidget).getDragSourceEffect();
/*  32 */       if (sourceEffect != null) {
/*  33 */         sourceEffect.dragStart(event);
/*     */       }
/*  35 */       ((DragSourceListener)this.eventListener).dragStart(event);
/*  36 */       event.updateEvent((DNDEvent)e);
/*  37 */       break;
/*     */     
/*     */     case 2000: 
/*  40 */       DragSourceEvent event = new DragSourceEvent((DNDEvent)e);
/*  41 */       DragSourceEffect sourceEffect = ((DragSource)this.dndWidget).getDragSourceEffect();
/*  42 */       if (sourceEffect != null) {
/*  43 */         sourceEffect.dragFinished(event);
/*     */       }
/*  45 */       ((DragSourceListener)this.eventListener).dragFinished(event);
/*  46 */       event.updateEvent((DNDEvent)e);
/*  47 */       break;
/*     */     
/*     */     case 2001: 
/*  50 */       DragSourceEvent event = new DragSourceEvent((DNDEvent)e);
/*  51 */       DragSourceEffect sourceEffect = ((DragSource)this.dndWidget).getDragSourceEffect();
/*  52 */       if (sourceEffect != null) {
/*  53 */         sourceEffect.dragSetData(event);
/*     */       }
/*  55 */       ((DragSourceListener)this.eventListener).dragSetData(event);
/*  56 */       event.updateEvent((DNDEvent)e);
/*  57 */       break;
/*     */     
/*     */     case 2002: 
/*  60 */       DropTargetEvent event = new DropTargetEvent((DNDEvent)e);
/*  61 */       ((DropTargetListener)this.eventListener).dragEnter(event);
/*  62 */       DropTargetEffect dropEffect = ((DropTarget)this.dndWidget).getDropTargetEffect();
/*  63 */       if (dropEffect != null) {
/*  64 */         dropEffect.dragEnter(event);
/*     */       }
/*  66 */       event.updateEvent((DNDEvent)e);
/*  67 */       break;
/*     */     
/*     */     case 2003: 
/*  70 */       DropTargetEvent event = new DropTargetEvent((DNDEvent)e);
/*  71 */       ((DropTargetListener)this.eventListener).dragLeave(event);
/*  72 */       DropTargetEffect dropEffect = ((DropTarget)this.dndWidget).getDropTargetEffect();
/*  73 */       if (dropEffect != null) {
/*  74 */         dropEffect.dragLeave(event);
/*     */       }
/*  76 */       event.updateEvent((DNDEvent)e);
/*  77 */       break;
/*     */     
/*     */     case 2004: 
/*  80 */       DropTargetEvent event = new DropTargetEvent((DNDEvent)e);
/*  81 */       ((DropTargetListener)this.eventListener).dragOver(event);
/*  82 */       DropTargetEffect dropEffect = ((DropTarget)this.dndWidget).getDropTargetEffect();
/*  83 */       if (dropEffect != null) {
/*  84 */         dropEffect.dragOver(event);
/*     */       }
/*  86 */       event.updateEvent((DNDEvent)e);
/*  87 */       break;
/*     */     
/*     */     case 2006: 
/*  90 */       DropTargetEvent event = new DropTargetEvent((DNDEvent)e);
/*  91 */       ((DropTargetListener)this.eventListener).drop(event);
/*  92 */       DropTargetEffect dropEffect = ((DropTarget)this.dndWidget).getDropTargetEffect();
/*  93 */       if (dropEffect != null) {
/*  94 */         dropEffect.drop(event);
/*     */       }
/*  96 */       event.updateEvent((DNDEvent)e);
/*  97 */       break;
/*     */     
/*     */     case 2007: 
/* 100 */       DropTargetEvent event = new DropTargetEvent((DNDEvent)e);
/* 101 */       ((DropTargetListener)this.eventListener).dropAccept(event);
/* 102 */       DropTargetEffect dropEffect = ((DropTarget)this.dndWidget).getDropTargetEffect();
/* 103 */       if (dropEffect != null) {
/* 104 */         dropEffect.dropAccept(event);
/*     */       }
/* 106 */       event.updateEvent((DNDEvent)e);
/* 107 */       break;
/*     */     
/*     */     case 2005: 
/* 110 */       DropTargetEvent event = new DropTargetEvent((DNDEvent)e);
/* 111 */       ((DropTargetListener)this.eventListener).dragOperationChanged(event);
/* 112 */       DropTargetEffect dropEffect = ((DropTarget)this.dndWidget).getDropTargetEffect();
/* 113 */       if (dropEffect != null) {
/* 114 */         dropEffect.dragOperationChanged(event);
/*     */       }
/* 116 */       event.updateEvent((DNDEvent)e);
/* 117 */       break;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/dnd/DNDListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */