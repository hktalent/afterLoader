/*      */ package org.eclipse.swt.widgets;
/*      */ 
/*      */ import org.eclipse.swt.events.SelectionListener;
/*      */ import org.eclipse.swt.graphics.Image;
/*      */ import org.eclipse.swt.graphics.Rectangle;
/*      */ import org.eclipse.swt.internal.Callback;
/*      */ import org.eclipse.swt.internal.Converter;
/*      */ import org.eclipse.swt.internal.DPIUtil;
/*      */ import org.eclipse.swt.internal.ImageList;
/*      */ import org.eclipse.swt.internal.gtk.GDK;
/*      */ import org.eclipse.swt.internal.gtk.GTK;
/*      */ import org.eclipse.swt.internal.gtk.GdkColor;
/*      */ import org.eclipse.swt.internal.gtk.GdkEvent;
/*      */ import org.eclipse.swt.internal.gtk.GdkEventButton;
/*      */ import org.eclipse.swt.internal.gtk.GdkRGBA;
/*      */ import org.eclipse.swt.internal.gtk.GtkAllocation;
/*      */ import org.eclipse.swt.internal.gtk.GtkRequisition;
/*      */ import org.eclipse.swt.internal.gtk.OS;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ToolItem
/*      */   extends Item
/*      */ {
/*      */   long arrowHandle;
/*      */   long labelHandle;
/*      */   long imageHandle;
/*      */   long eventHandle;
/*      */   long proxyMenuItem;
/*      */   long provider;
/*      */   ToolBar parent;
/*      */   Control control;
/*      */   Image hotImage;
/*      */   Image disabledImage;
/*      */   String toolTipText;
/*      */   boolean drawHotImage;
/*      */   
/*      */   public ToolItem(ToolBar parent, int style)
/*      */   {
/*   84 */     super(parent, checkStyle(style));
/*   85 */     this.parent = parent;
/*   86 */     createWidget(parent.getItemCount());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ToolItem(ToolBar parent, int style, int index)
/*      */   {
/*  126 */     super(parent, checkStyle(style));
/*  127 */     this.parent = parent;
/*  128 */     int count = parent.getItemCount();
/*  129 */     if ((0 > index) || (index > count)) {
/*  130 */       error(6);
/*      */     }
/*  132 */     createWidget(index);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addSelectionListener(SelectionListener listener)
/*      */   {
/*  167 */     checkWidget();
/*  168 */     if (listener == null) error(4);
/*  169 */     TypedListener typedListener = new TypedListener(listener);
/*  170 */     addListener(13, typedListener);
/*  171 */     addListener(14, typedListener);
/*      */   }
/*      */   
/*      */   static int checkStyle(int style) {
/*  175 */     return checkBits(style, 8, 32, 16, 2, 4, 0);
/*      */   }
/*      */   
/*      */   protected void checkSubclass()
/*      */   {
/*  180 */     if (!isValidSubclass()) error(43);
/*      */   }
/*      */   
/*      */   void createHandle(int index)
/*      */   {
/*  185 */     this.state |= 0x8;
/*  186 */     int bits = 62;
/*  187 */     if ((this.style & 0x2) == 0) {
/*  188 */       this.labelHandle = GTK.gtk_label_new_with_mnemonic(null);
/*  189 */       if (this.labelHandle == 0L) error(2);
/*  190 */       this.imageHandle = GTK.gtk_image_new_from_pixbuf(0L);
/*  191 */       if (this.imageHandle == 0L) error(2);
/*      */     }
/*  193 */     switch (this.style & bits) {
/*      */     case 2: 
/*  195 */       this.handle = GTK.gtk_separator_tool_item_new();
/*  196 */       if (this.handle == 0L) error(2);
/*  197 */       GTK.gtk_separator_tool_item_set_draw(this.handle, true);
/*  198 */       break;
/*      */     case 4: 
/*  200 */       this.handle = GTK.gtk_menu_tool_button_new(0L, null);
/*  201 */       if (this.handle == 0L) { error(2);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  207 */       long child = GTK.gtk_bin_get_child(this.handle);
/*  208 */       long list = GTK.gtk_container_get_children(child);
/*  209 */       this.arrowHandle = OS.g_list_nth_data(list, 1);
/*  210 */       if (this.arrowHandle != 0L) {
/*  211 */         GTK.gtk_widget_set_sensitive(this.arrowHandle, true);
/*  212 */         if (!GTK.GTK3) {
/*  213 */           GTK.gtk_widget_set_size_request(GTK.gtk_bin_get_child(this.arrowHandle), 8, 6);
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       break;
/*      */     case 16: 
/*      */     case 32: 
/*  225 */       this.handle = GTK.gtk_toggle_tool_button_new();
/*  226 */       if (this.handle == 0L) error(2);
/*      */       break;
/*      */     case 8: 
/*      */     default: 
/*  230 */       this.handle = GTK.gtk_tool_button_new(0L, null);
/*  231 */       if (this.handle == 0L) error(2);
/*      */       break;
/*      */     }
/*  234 */     if (this.labelHandle != 0L) {
/*  235 */       GTK.gtk_tool_button_set_label_widget(this.handle, this.labelHandle);
/*      */     }
/*  237 */     if (this.imageHandle != 0L) {
/*  238 */       GTK.gtk_tool_button_set_icon_widget(this.handle, this.imageHandle);
/*      */     }
/*  240 */     if ((this.parent.state & 0x1000) != 0) {
/*  241 */       setForegroundColor(this.parent.getForegroundGdkColor());
/*      */     }
/*  243 */     if ((this.parent.state & 0x4000) != 0) {
/*  244 */       setFontDescription(this.parent.getFontDescription());
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  251 */     if ((this.parent.style & 0x20000) != 0) GTK.gtk_tool_item_set_is_important(this.handle, true);
/*  252 */     if ((this.style & 0x2) == 0) GTK.gtk_tool_button_set_use_underline(this.handle, true);
/*      */   }
/*      */   
/*      */   void createWidget(int index)
/*      */   {
/*  257 */     super.createWidget(index);
/*  258 */     showWidget(index);
/*  259 */     this.parent.relayout();
/*      */   }
/*      */   
/*      */   Widget[] computeTabList() {
/*  263 */     if ((isTabGroup()) && 
/*  264 */       (getEnabled())) {
/*  265 */       if ((this.style & 0x2) != 0) {
/*  266 */         if (this.control != null) return this.control.computeTabList();
/*      */       } else {
/*  268 */         return new Widget[] { this };
/*      */       }
/*      */     }
/*      */     
/*  272 */     return new Widget[0];
/*      */   }
/*      */   
/*      */   void deregister()
/*      */   {
/*  277 */     super.deregister();
/*  278 */     if (this.eventHandle != 0L) this.display.removeWidget(this.eventHandle);
/*  279 */     if (this.arrowHandle != 0L) this.display.removeWidget(this.arrowHandle);
/*      */   }
/*      */   
/*      */   public void dispose()
/*      */   {
/*  284 */     if (isDisposed()) return;
/*  285 */     ToolBar parent = this.parent;
/*  286 */     super.dispose();
/*  287 */     parent.relayout();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Rectangle getBounds()
/*      */   {
/*  302 */     checkWidget();
/*  303 */     return DPIUtil.autoScaleDown(getBoundsInPixels());
/*      */   }
/*      */   
/*      */   Rectangle getBoundsInPixels() {
/*  307 */     checkWidget();
/*  308 */     this.parent.forceResize();
/*  309 */     long topHandle = topHandle();
/*  310 */     GtkAllocation allocation = new GtkAllocation();
/*  311 */     GTK.gtk_widget_get_allocation(topHandle, allocation);
/*  312 */     int x = allocation.x;
/*  313 */     int y = allocation.y;
/*  314 */     int width = allocation.width;
/*  315 */     int height = allocation.height;
/*  316 */     if ((this.parent.style & 0x8000000) != 0) x = this.parent.getClientWidth() - width - x;
/*  317 */     if (((this.style & 0x2) != 0) && (this.control != null)) height = Math.max(height, 23);
/*  318 */     return new Rectangle(x, y, width, height);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Control getControl()
/*      */   {
/*  333 */     checkWidget();
/*  334 */     return this.control;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Image getDisabledImage()
/*      */   {
/*  352 */     checkWidget();
/*  353 */     return this.disabledImage;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getEnabled()
/*      */   {
/*  372 */     checkWidget();
/*  373 */     long topHandle = topHandle();
/*  374 */     return GTK.gtk_widget_get_sensitive(topHandle);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Image getHotImage()
/*      */   {
/*  392 */     checkWidget();
/*  393 */     return this.hotImage;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public ToolBar getParent()
/*      */   {
/*  407 */     checkWidget();
/*  408 */     if (this.parent == null) error(24);
/*  409 */     return this.parent;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getSelection()
/*      */   {
/*  430 */     checkWidget();
/*  431 */     if ((this.style & 0x30) == 0) return false;
/*  432 */     return GTK.gtk_toggle_tool_button_get_active(this.handle);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getToolTipText()
/*      */   {
/*  446 */     checkWidget();
/*  447 */     return this.toolTipText;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getWidth()
/*      */   {
/*  461 */     checkWidget();
/*  462 */     return DPIUtil.autoScaleDown(getWidthInPixels());
/*      */   }
/*      */   
/*      */   int getWidthInPixels() {
/*  466 */     checkWidget();
/*  467 */     this.parent.forceResize();
/*  468 */     long topHandle = topHandle();
/*  469 */     GtkAllocation allocation = new GtkAllocation();
/*  470 */     GTK.gtk_widget_get_allocation(topHandle, allocation);
/*  471 */     return allocation.width;
/*      */   }
/*      */   
/*      */   long gtk_button_press_event(long widget, long event)
/*      */   {
/*  476 */     GdkEventButton gdkEvent = new GdkEventButton();
/*  477 */     OS.memmove(gdkEvent, event, GdkEventButton.sizeof);
/*  478 */     GtkAllocation allocation = new GtkAllocation();
/*  479 */     GTK.gtk_widget_get_allocation(this.handle, allocation);
/*  480 */     double x = gdkEvent.x + allocation.x;
/*  481 */     double y = gdkEvent.y + allocation.y;
/*  482 */     OS.memmove(event, gdkEvent, GdkEventButton.sizeof);
/*  483 */     long result = this.parent.gtk_button_press_event(widget, event);
/*  484 */     gdkEvent.x = x;
/*  485 */     gdkEvent.y = y;
/*  486 */     OS.memmove(event, gdkEvent, GdkEventButton.sizeof);
/*  487 */     return result;
/*      */   }
/*      */   
/*      */   long gtk_button_release_event(long widget, long event)
/*      */   {
/*  492 */     GdkEventButton gdkEvent = new GdkEventButton();
/*  493 */     OS.memmove(gdkEvent, event, GdkEventButton.sizeof);
/*  494 */     GtkAllocation allocation = new GtkAllocation();
/*  495 */     GTK.gtk_widget_get_allocation(this.handle, allocation);
/*  496 */     double x = gdkEvent.x + allocation.x;
/*  497 */     double y = gdkEvent.y + allocation.y;
/*  498 */     OS.memmove(event, gdkEvent, GdkEventButton.sizeof);
/*  499 */     long result = this.parent.gtk_button_release_event(widget, event);
/*  500 */     gdkEvent.x = x;
/*  501 */     gdkEvent.y = y;
/*  502 */     OS.memmove(event, gdkEvent, GdkEventButton.sizeof);
/*  503 */     return result;
/*      */   }
/*      */   
/*      */   long gtk_clicked(long widget)
/*      */   {
/*  508 */     Event event = new Event();
/*  509 */     if ((this.style & 0x4) != 0) {
/*  510 */       long eventPtr = GTK.gtk_get_current_event();
/*  511 */       if (eventPtr != 0L) {
/*  512 */         GdkEvent gdkEvent = new GdkEvent();
/*  513 */         OS.memmove(gdkEvent, eventPtr, GdkEvent.sizeof);
/*  514 */         long topHandle = topHandle();
/*  515 */         switch (gdkEvent.type) {
/*      */         case 4: 
/*      */         case 5: 
/*      */         case 7: 
/*      */         case 9: 
/*  520 */           boolean isArrow = false;
/*  521 */           if (widget == this.arrowHandle) {
/*  522 */             isArrow = true;
/*  523 */             topHandle = widget;
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*  528 */             OS.g_signal_handlers_block_matched(widget, 16, 0, 0, 0L, 0L, 8L);
/*  529 */             GTK.gtk_toggle_button_set_active(widget, false);
/*  530 */             OS.g_signal_handlers_unblock_matched(widget, 16, 0, 0, 0L, 0L, 8L);
/*      */           }
/*  532 */           if (isArrow) {
/*  533 */             event.detail = 4;
/*  534 */             GtkAllocation allocation = new GtkAllocation();
/*  535 */             GTK.gtk_widget_get_allocation(topHandle, allocation);
/*  536 */             event.x = DPIUtil.autoScaleDown(allocation.x);
/*  537 */             if ((this.style & 0x8000000) != 0) event.x = (DPIUtil.autoScaleDown(this.parent.getClientWidth() - allocation.width) - event.x);
/*  538 */             event.y = DPIUtil.autoScaleDown(allocation.y + allocation.height); }
/*  539 */           break;
/*      */         }
/*      */         
/*      */         
/*  543 */         GDK.gdk_event_free(eventPtr);
/*      */       }
/*      */     }
/*  546 */     if (((this.style & 0x10) != 0) && 
/*  547 */       ((this.parent.getStyle() & 0x400000) == 0)) {
/*  548 */       selectRadio();
/*      */     }
/*      */     
/*  551 */     sendSelectionEvent(13, event, false);
/*  552 */     return 0L;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   long gtk_create_menu_proxy(long widget)
/*      */   {
/*  564 */     byte[] buffer = Converter.wcsToMbcs("menu-id", true);
/*  565 */     if (this.proxyMenuItem != 0L)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  571 */       GTK.gtk_tool_item_set_proxy_menu_item(widget, buffer, this.proxyMenuItem);
/*  572 */       return 1L;
/*      */     }
/*      */     
/*  575 */     if (this.image != null) {
/*  576 */       ImageList imageList = this.parent.imageList;
/*  577 */       if (imageList != null) {
/*  578 */         int index = imageList.indexOf(this.image);
/*  579 */         if (index != -1) {
/*  580 */           long pixbuf = imageList.getPixbuf(index);
/*  581 */           byte[] label = null;
/*  582 */           int[] showImages = { 1 };
/*  583 */           long settings = GTK.gtk_settings_get_default();
/*  584 */           if ((settings != 0L) && 
/*  585 */             (!GTK.GTK3)) {
/*  586 */             long property = OS.g_object_class_find_property(OS.G_OBJECT_GET_CLASS(settings), GTK.gtk_menu_images);
/*  587 */             if (property != 0L) { OS.g_object_get(settings, GTK.gtk_menu_images, showImages, 0L);
/*      */             }
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  600 */           if ((this.text == null) || (this.text.length() == 0)) {
/*  601 */             if ((showImages[0] == 0) && (this.toolTipText != null)) {
/*  602 */               label = Converter.wcsToMbcs(this.toolTipText, true);
/*      */             } else {
/*  604 */               label = new byte[] { 0 };
/*      */             }
/*      */           } else {
/*  607 */             label = Converter.wcsToMbcs(this.text, true);
/*      */           }
/*      */           long menuItem;
/*  610 */           if (GTK.GTK3)
/*      */           {
/*  612 */             long menuItem = GTK.gtk_menu_item_new();
/*  613 */             if (menuItem == 0L) { error(2);
/*      */             }
/*  615 */             long boxHandle = gtk_box_new(0, false, 6);
/*  616 */             if (boxHandle == 0L) { error(2);
/*      */             }
/*  618 */             long menuLabel = GTK.gtk_accel_label_new(label);
/*  619 */             if (menuLabel == 0L) error(2);
/*  620 */             if (GTK.GTK_VERSION >= OS.VERSION(3, 16, 0)) {
/*  621 */               GTK.gtk_label_set_xalign(this.labelHandle, 0.0F);
/*  622 */               GTK.gtk_widget_set_halign(this.labelHandle, 0);
/*      */             } else {
/*  624 */               GTK.gtk_misc_set_alignment(this.labelHandle, 0.0F, 0.0F);
/*      */             }
/*      */             
/*  627 */             long menuImage = GTK.gtk_image_new_from_pixbuf(pixbuf);
/*  628 */             if (menuImage == 0L) { error(2);
/*      */             }
/*  630 */             GTK.gtk_container_add(boxHandle, menuImage);
/*  631 */             GTK.gtk_box_pack_end(boxHandle, menuLabel, true, true, 0);
/*  632 */             GTK.gtk_container_add(menuItem, boxHandle);
/*      */           } else {
/*  634 */             menuItem = GTK.gtk_image_menu_item_new_with_label(label);
/*  635 */             if (menuItem == 0L) { error(2);
/*      */             }
/*  637 */             long menuImage = GTK.gtk_image_new_from_pixbuf(pixbuf);
/*  638 */             if (menuImage == 0L) error(2);
/*  639 */             GTK.gtk_image_menu_item_set_image(menuItem, menuImage);
/*      */           }
/*  641 */           GTK.gtk_tool_item_set_proxy_menu_item(widget, buffer, menuItem);
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  648 */           this.proxyMenuItem = GTK.gtk_tool_item_get_proxy_menu_item(widget, buffer);
/*  649 */           OS.g_signal_connect(menuItem, OS.activate, ToolBar.menuItemSelectedFunc.getAddress(), this.handle);
/*  650 */           return 1L;
/*      */         }
/*      */       }
/*      */     }
/*  654 */     return 0L;
/*      */   }
/*      */   
/*      */ 
/*      */   void gtk_css_provider_load_from_css(long context, String css)
/*      */   {
/*  660 */     if (this.provider == 0L) {
/*  661 */       this.provider = GTK.gtk_css_provider_new();
/*  662 */       GTK.gtk_style_context_add_provider(context, this.provider, 600);
/*  663 */       OS.g_object_unref(this.provider);
/*      */     }
/*  665 */     GTK.gtk_css_provider_load_from_data(this.provider, Converter.wcsToMbcs(css, true), -1L, null);
/*      */   }
/*      */   
/*      */   long gtk_enter_notify_event(long widget, long event)
/*      */   {
/*  670 */     this.parent.gtk_enter_notify_event(widget, event);
/*  671 */     this.drawHotImage = (((this.parent.style & 0x800000) != 0) && (this.hotImage != null));
/*  672 */     if (this.drawHotImage) {
/*  673 */       ImageList imageList = this.parent.imageList;
/*  674 */       if (imageList != null) {
/*  675 */         int index = imageList.indexOf(this.hotImage);
/*  676 */         if ((index != -1) && (this.imageHandle != 0L)) {
/*  677 */           long pixbuf = imageList.getPixbuf(index);
/*  678 */           gtk_image_set_from_pixbuf(this.imageHandle, pixbuf);
/*      */         }
/*      */       }
/*      */     }
/*  682 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_event_after(long widget, long gdkEvent)
/*      */   {
/*  687 */     GdkEvent event = new GdkEvent();
/*  688 */     OS.memmove(event, gdkEvent, GdkEvent.sizeof);
/*  689 */     switch (event.type) {
/*      */     case 4: 
/*  691 */       GdkEventButton gdkEventButton = new GdkEventButton();
/*  692 */       OS.memmove(gdkEventButton, gdkEvent, GdkEventButton.sizeof);
/*  693 */       if (gdkEventButton.button == 3) {
/*  694 */         this.parent.showMenu((int)gdkEventButton.x_root, (int)gdkEventButton.y_root);
/*      */       }
/*      */       break;
/*      */     }
/*      */     
/*  699 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_focus_in_event(long widget, long event)
/*      */   {
/*  704 */     this.parent.hasChildFocus = true;
/*  705 */     this.parent.currentFocusItem = this;
/*  706 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_focus_out_event(long widget, long event)
/*      */   {
/*  711 */     this.parent.hasChildFocus = false;
/*  712 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_leave_notify_event(long widget, long event)
/*      */   {
/*  717 */     this.parent.gtk_leave_notify_event(widget, event);
/*  718 */     if (this.drawHotImage) {
/*  719 */       this.drawHotImage = false;
/*  720 */       if (this.image != null) {
/*  721 */         ImageList imageList = this.parent.imageList;
/*  722 */         if (imageList != null) {
/*  723 */           int index = imageList.indexOf(this.image);
/*  724 */           if ((index != -1) && (this.imageHandle != 0L)) {
/*  725 */             long pixbuf = imageList.getPixbuf(index);
/*  726 */             gtk_image_set_from_pixbuf(this.imageHandle, pixbuf);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*  731 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_map(long widget)
/*      */   {
/*  736 */     this.parent.fixZOrder();
/*  737 */     return 0L;
/*      */   }
/*      */   
/*      */   long gtk_mnemonic_activate(long widget, long arg1)
/*      */   {
/*  742 */     return this.parent.gtk_mnemonic_activate(widget, arg1);
/*      */   }
/*      */   
/*      */   void hookEvents()
/*      */   {
/*  747 */     super.hookEvents();
/*  748 */     if ((this.style & 0x2) != 0) return;
/*  749 */     OS.g_signal_connect_closure(this.handle, OS.clicked, this.display.getClosure(8), false);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  755 */     this.eventHandle = GTK.gtk_bin_get_child(this.handle);
/*  756 */     if ((this.style & 0x4) != 0) {
/*  757 */       long list = GTK.gtk_container_get_children(this.eventHandle);
/*  758 */       this.eventHandle = OS.g_list_nth_data(list, 0);
/*  759 */       if (this.arrowHandle != 0L) OS.g_signal_connect_closure(this.arrowHandle, OS.clicked, this.display.getClosure(8), false);
/*      */     }
/*  761 */     OS.g_signal_connect_closure(this.handle, OS.create_menu_proxy, this.display.getClosure(83), false);
/*      */     
/*  763 */     OS.g_signal_connect_closure_by_id(this.eventHandle, this.display.signalIds[14], 0, this.display.getClosure(14), false);
/*  764 */     OS.g_signal_connect_closure_by_id(this.eventHandle, this.display.signalIds[29], 0, this.display.getClosure(29), false);
/*  765 */     OS.g_signal_connect_closure_by_id(this.eventHandle, this.display.signalIds[21], 0, this.display.getClosure(21), false);
/*  766 */     OS.g_signal_connect_closure_by_id(this.eventHandle, this.display.signalIds[22], 0, this.display.getClosure(22), false);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  775 */     int mask = 32518;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  781 */     GTK.gtk_widget_add_events(this.eventHandle, mask);
/*  782 */     OS.g_signal_connect_closure_by_id(this.eventHandle, this.display.signalIds[2], 0, this.display.getClosure(2), false);
/*  783 */     OS.g_signal_connect_closure_by_id(this.eventHandle, this.display.signalIds[4], 0, this.display.getClosure(4), false);
/*  784 */     OS.g_signal_connect_closure_by_id(this.eventHandle, this.display.signalIds[16], 0, this.display.getClosure(16), false);
/*      */     
/*  786 */     long topHandle = topHandle();
/*  787 */     OS.g_signal_connect_closure_by_id(topHandle, this.display.signalIds[30], 0, this.display.getClosure(30), true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isEnabled()
/*      */   {
/*  806 */     checkWidget();
/*  807 */     return (getEnabled()) && (this.parent.isEnabled());
/*      */   }
/*      */   
/*      */   boolean isTabGroup() {
/*  811 */     ToolItem[] tabList = this.parent._getTabItemList();
/*  812 */     if (tabList != null) {
/*  813 */       for (int i = 0; i < tabList.length; i++) {
/*  814 */         if (tabList[i] == this) return true;
/*      */       }
/*      */     }
/*  817 */     if ((this.style & 0x2) != 0) return true;
/*  818 */     int index = this.parent.indexOf(this);
/*  819 */     if (index == 0) return true;
/*  820 */     ToolItem previous = this.parent.getItem(index - 1);
/*  821 */     return (previous.getStyle() & 0x2) != 0;
/*      */   }
/*      */   
/*      */   void register()
/*      */   {
/*  826 */     super.register();
/*  827 */     if (this.eventHandle != 0L) this.display.addWidget(this.eventHandle, this);
/*  828 */     if (this.arrowHandle != 0L) this.display.addWidget(this.arrowHandle, this);
/*      */   }
/*      */   
/*      */   void releaseHandle()
/*      */   {
/*  833 */     super.releaseHandle();
/*  834 */     this.arrowHandle = (this.labelHandle = this.imageHandle = this.eventHandle = 0L);
/*      */   }
/*      */   
/*      */   void releaseWidget()
/*      */   {
/*  839 */     super.releaseWidget();
/*  840 */     if (this.parent.currentFocusItem == this) this.parent.currentFocusItem = null;
/*  841 */     this.parent = null;
/*  842 */     this.control = null;
/*  843 */     this.hotImage = (this.disabledImage = null);
/*  844 */     this.toolTipText = null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeSelectionListener(SelectionListener listener)
/*      */   {
/*  865 */     checkWidget();
/*  866 */     if (listener == null) error(4);
/*  867 */     if (this.eventTable == null) return;
/*  868 */     this.eventTable.unhook(13, listener);
/*  869 */     this.eventTable.unhook(14, listener);
/*      */   }
/*      */   
/*      */   void resizeControl() {
/*  873 */     if ((this.control != null) && (!this.control.isDisposed()))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  882 */       Rectangle itemRect = getBounds();
/*  883 */       this.control.setSize(itemRect.width, itemRect.height);
/*  884 */       resizeHandle(itemRect.width, itemRect.height);
/*  885 */       Rectangle rect = this.control.getBounds();
/*  886 */       itemRect.x += (itemRect.width - rect.width) / 2;
/*  887 */       itemRect.y += (itemRect.height - rect.height) / 2;
/*  888 */       this.control.setLocation(rect.x, rect.y);
/*      */     }
/*      */   }
/*      */   
/*      */   void resizeHandle(int width, int height) {
/*  893 */     GTK.gtk_widget_set_size_request(this.handle, width, height);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  899 */     GtkRequisition requisition = new GtkRequisition();
/*  900 */     this.parent.gtk_widget_size_request(this.handle, requisition);
/*  901 */     GtkAllocation allocation = new GtkAllocation();
/*  902 */     GTK.gtk_widget_get_allocation(this.handle, allocation);
/*  903 */     allocation.width = width;
/*  904 */     allocation.height = height;
/*  905 */     GTK.gtk_widget_size_allocate(this.handle, allocation);
/*      */   }
/*      */   
/*      */   void selectRadio() {
/*  909 */     int index = 0;
/*  910 */     ToolItem[] items = this.parent.getItems();
/*  911 */     while ((index < items.length) && (items[index] != this)) index++;
/*  912 */     int i = index - 1;
/*  913 */     while ((i >= 0) && (items[i].setRadioSelection(false))) i--;
/*  914 */     int j = index + 1;
/*  915 */     while ((j < items.length) && (items[j].setRadioSelection(false))) j++;
/*  916 */     setSelection(true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setControl(Control control)
/*      */   {
/*  935 */     checkWidget();
/*  936 */     if (control != null) {
/*  937 */       if (control.isDisposed()) error(5);
/*  938 */       if (control.parent != this.parent) error(32);
/*      */     }
/*  940 */     if ((this.style & 0x2) == 0) return;
/*  941 */     if (this.control == control) return;
/*  942 */     this.control = control;
/*  943 */     this.parent.relayout();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDisabledImage(Image image)
/*      */   {
/*  964 */     checkWidget();
/*  965 */     if ((this.style & 0x2) != 0) return;
/*  966 */     this.disabledImage = image;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setEnabled(boolean enabled)
/*      */   {
/*  986 */     checkWidget();
/*  987 */     long topHandle = topHandle();
/*  988 */     if (GTK.gtk_widget_get_sensitive(topHandle) == enabled) return;
/*  989 */     GTK.gtk_widget_set_sensitive(topHandle, enabled);
/*      */     
/*  991 */     if (!GTK.GTK3) {
/*  992 */       if (enabled)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  999 */         int[] x = new int[1];int[] y = new int[1];
/* 1000 */         gdk_window_get_device_position(this.parent.paintWindow(), x, y, null);
/* 1001 */         if (getBoundsInPixels().contains(x[0], y[0])) {
/* 1002 */           GTK.gtk_widget_hide(this.handle);
/* 1003 */           GTK.gtk_widget_show(this.handle);
/*      */ 
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*      */ 
/* 1013 */         GTK.gtk_widget_set_state(topHandle, 0);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   boolean setFocus() {
/* 1019 */     return GTK.gtk_widget_child_focus(this.handle, 0);
/*      */   }
/*      */   
/*      */   void setFontDescription(long font) {
/* 1023 */     if (this.labelHandle != 0L) setFontDescription(this.labelHandle, font);
/*      */   }
/*      */   
/*      */   void setForegroundRGBA(GdkRGBA rgba) {
/* 1027 */     assert (GTK.GTK3) : "GTK3 code was run by GTK2";
/* 1028 */     if (this.labelHandle != 0L) setForegroundRGBA(this.labelHandle, rgba);
/*      */   }
/*      */   
/*      */   void setBackgroundRGBA(GdkRGBA rgba) {
/* 1032 */     assert (GTK.GTK3) : "GTK3 code was run by GTK2";
/* 1033 */     if (this.handle != 0L) setBackgroundRGBA(this.handle, rgba);
/*      */   }
/*      */   
/*      */   void setForegroundColor(GdkColor color) {
/* 1037 */     assert (!GTK.GTK3) : "GTK2 code was run by GTK3";
/* 1038 */     if (this.labelHandle != 0L) setForegroundColor(this.labelHandle, color);
/*      */   }
/*      */   
/*      */   void setBackgroundRGBA(long handle, GdkRGBA rgba) {
/* 1042 */     assert (GTK.GTK3) : "GTK3 code was run by GTK2";
/* 1043 */     if (GTK.GTK_VERSION >= OS.VERSION(3, 14, 0))
/*      */     {
/* 1045 */       long context = GTK.gtk_widget_get_style_context(handle);
/*      */       
/* 1047 */       String name = GTK.GTK_VERSION >= OS.VERSION(3, 20, 0) ? this.display.gtk_widget_class_get_css_name(handle) : this.display.gtk_widget_get_name(handle);
/* 1048 */       String css = name + " {background-color: " + this.display.gtk_rgba_to_css_string(rgba) + "}";
/*      */       
/*      */ 
/*      */ 
/* 1052 */       gtk_css_provider_load_from_css(context, css);
/*      */     }
/*      */   }
/*      */   
/*      */   void setForegroundRGBA(long handle, GdkRGBA rgba) {
/* 1057 */     assert (GTK.GTK3) : "GTK3 code was run by GTK2";
/* 1058 */     if (GTK.GTK_VERSION < OS.VERSION(3, 14, 0)) {
/* 1059 */       GdkRGBA selectedForeground = this.display.COLOR_LIST_SELECTION_TEXT_RGBA;
/* 1060 */       GTK.gtk_widget_override_color(handle, 0, rgba);
/* 1061 */       GTK.gtk_widget_override_color(handle, 4, selectedForeground);
/* 1062 */       long context = GTK.gtk_widget_get_style_context(handle);
/* 1063 */       GTK.gtk_style_context_invalidate(context);
/* 1064 */       return;
/*      */     }
/* 1066 */     GdkRGBA toSet = new GdkRGBA();
/* 1067 */     if (rgba != null) {
/* 1068 */       toSet = rgba;
/*      */     } else {
/* 1070 */       toSet = this.display.COLOR_WIDGET_FOREGROUND_RGBA;
/*      */     }
/* 1072 */     long context = GTK.gtk_widget_get_style_context(handle);
/*      */     
/* 1074 */     String color = this.display.gtk_rgba_to_css_string(toSet);
/* 1075 */     String css = "* {color: " + color + ";}";
/*      */     
/*      */ 
/* 1078 */     this.parent.cssForeground = css;
/* 1079 */     gtk_css_provider_load_from_css(context, css);
/*      */     
/*      */ 
/*      */ 
/* 1083 */     this.parent.restoreBackground();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setHotImage(Image image)
/*      */   {
/* 1104 */     checkWidget();
/* 1105 */     if ((this.style & 0x2) != 0) return;
/* 1106 */     this.hotImage = image;
/* 1107 */     if (image != null) {
/* 1108 */       ImageList imageList = this.parent.imageList;
/* 1109 */       if (imageList == null) imageList = this.parent.imageList = new ImageList();
/* 1110 */       int imageIndex = imageList.indexOf(image);
/* 1111 */       if (imageIndex == -1) {
/* 1112 */         imageIndex = imageList.add(image);
/*      */       } else {
/* 1114 */         imageList.put(imageIndex, image);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public void setImage(Image image)
/*      */   {
/* 1121 */     checkWidget();
/* 1122 */     if ((this.style & 0x2) != 0) return;
/* 1123 */     super.setImage(image);
/* 1124 */     if (image != null) {
/* 1125 */       ImageList imageList = this.parent.imageList;
/* 1126 */       if (imageList == null) imageList = this.parent.imageList = new ImageList();
/* 1127 */       int imageIndex = imageList.indexOf(image);
/* 1128 */       if (imageIndex == -1) {
/* 1129 */         imageIndex = imageList.add(image);
/*      */       } else {
/* 1131 */         imageList.put(imageIndex, image);
/*      */       }
/* 1133 */       long pixbuf = imageList.getPixbuf(imageIndex);
/* 1134 */       gtk_image_set_from_pixbuf(this.imageHandle, pixbuf);
/*      */     } else {
/* 1136 */       gtk_image_set_from_pixbuf(this.imageHandle, 0L);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1143 */     if ((this.style & 0x4) != 0) {
/* 1144 */       this.proxyMenuItem = 0L;
/* 1145 */       this.proxyMenuItem = GTK.gtk_tool_item_retrieve_proxy_menu_item(this.handle);
/* 1146 */       OS.g_signal_connect(this.proxyMenuItem, OS.activate, ToolBar.menuItemSelectedFunc.getAddress(), this.handle);
/*      */     }
/* 1148 */     this.parent.relayout();
/*      */   }
/*      */   
/*      */   void setOrientation(boolean create)
/*      */   {
/* 1153 */     if (((this.parent.style & 0x4000000) != 0) || (!create)) {
/* 1154 */       int dir = (this.parent.style & 0x4000000) != 0 ? 2 : 1;
/* 1155 */       if (this.handle != 0L) GTK.gtk_widget_set_direction(this.handle, dir);
/*      */     }
/*      */   }
/*      */   
/*      */   boolean setRadioSelection(boolean value) {
/* 1160 */     if ((this.style & 0x10) == 0) return false;
/* 1161 */     if (getSelection() != value) {
/* 1162 */       setSelection(value);
/* 1163 */       sendSelectionEvent(13);
/*      */     }
/* 1165 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSelection(boolean selected)
/*      */   {
/* 1184 */     checkWidget();
/* 1185 */     if ((this.style & 0x30) == 0) return;
/* 1186 */     OS.g_signal_handlers_block_matched(this.handle, 16, 0, 0, 0L, 0L, 8L);
/* 1187 */     GTK.gtk_toggle_tool_button_set_active(this.handle, selected);
/* 1188 */     OS.g_signal_handlers_unblock_matched(this.handle, 16, 0, 0, 0L, 0L, 8L);
/*      */   }
/*      */   
/*      */   boolean setTabItemFocus(boolean next)
/*      */   {
/* 1193 */     return setFocus();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setText(String string)
/*      */   {
/* 1226 */     checkWidget();
/* 1227 */     if (string == null) error(4);
/* 1228 */     if ((this.style & 0x2) != 0) return;
/* 1229 */     if (string.equals(this.text)) return;
/* 1230 */     super.setText(string);
/* 1231 */     if (this.labelHandle == 0L) return;
/* 1232 */     char[] chars = fixMnemonic(string);
/* 1233 */     byte[] buffer = Converter.wcsToMbcs(chars, true);
/* 1234 */     GTK.gtk_label_set_text_with_mnemonic(this.labelHandle, buffer);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1240 */     if ((this.style & 0x4) != 0) {
/* 1241 */       this.proxyMenuItem = 0L;
/* 1242 */       this.proxyMenuItem = GTK.gtk_tool_item_retrieve_proxy_menu_item(this.handle);
/* 1243 */       OS.g_signal_connect(this.proxyMenuItem, OS.activate, ToolBar.menuItemSelectedFunc.getAddress(), this.handle);
/*      */     }
/* 1245 */     this.parent.relayout();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setToolTipText(String string)
/*      */   {
/* 1274 */     checkWidget();
/* 1275 */     if ((this.toolTipText == string) || ((this.toolTipText != null) && (this.toolTipText.equals(string)))) return;
/* 1276 */     if (this.parent.toolTipText == null) {
/* 1277 */       Shell shell = this.parent._getShell();
/* 1278 */       setToolTipText(shell, string);
/*      */     }
/* 1280 */     this.toolTipText = string;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1288 */     if ((this.style & 0x4) != 0) {
/* 1289 */       this.proxyMenuItem = 0L;
/* 1290 */       this.proxyMenuItem = GTK.gtk_tool_item_retrieve_proxy_menu_item(this.handle);
/* 1291 */       OS.g_signal_connect(this.proxyMenuItem, OS.activate, ToolBar.menuItemSelectedFunc.getAddress(), this.handle);
/*      */     }
/*      */   }
/*      */   
/*      */   void setToolTipText(Shell shell, String newString) {
/* 1296 */     long child = GTK.gtk_bin_get_child(this.handle);
/* 1297 */     if ((this.style & 0x4) != 0) {
/* 1298 */       long list = GTK.gtk_container_get_children(child);
/* 1299 */       child = OS.g_list_nth_data(list, 0);
/* 1300 */       if (this.arrowHandle != 0L) shell.setToolTipText(this.arrowHandle, newString);
/*      */     }
/* 1302 */     shell.setToolTipText(child != 0L ? child : this.handle, newString);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setWidth(int width)
/*      */   {
/* 1323 */     checkWidget();
/* 1324 */     setWidthInPixels(DPIUtil.autoScaleUp(width));
/*      */   }
/*      */   
/*      */   void setWidthInPixels(int width) {
/* 1328 */     checkWidget();
/* 1329 */     if ((this.style & 0x2) == 0) return;
/* 1330 */     if (width < 0) return;
/* 1331 */     resizeHandle(width, (this.parent.style & 0x200) != 0 ? 6 : 15);
/* 1332 */     this.parent.relayout();
/*      */   }
/*      */   
/*      */   void showWidget(int index) {
/* 1336 */     if (this.handle != 0L) GTK.gtk_widget_show(this.handle);
/* 1337 */     if (this.labelHandle != 0L) GTK.gtk_widget_show(this.labelHandle);
/* 1338 */     if (this.imageHandle != 0L) GTK.gtk_widget_show(this.imageHandle);
/* 1339 */     GTK.gtk_toolbar_insert(this.parent.handle, this.handle, index);
/*      */   }
/*      */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/widgets/ToolItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */