/*     */ package org.eclipse.swt.events;
/*     */ 
/*     */ import java.util.function.Consumer;
/*     */ import org.eclipse.swt.internal.SWTEventListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract interface MouseListener
/*     */   extends SWTEventListener
/*     */ {
/*     */   public abstract void mouseDoubleClick(MouseEvent paramMouseEvent);
/*     */   
/*     */   public abstract void mouseDown(MouseEvent paramMouseEvent);
/*     */   
/*     */   public abstract void mouseUp(MouseEvent paramMouseEvent);
/*     */   
/*     */   public static MouseListener mouseDoubleClickAdapter(Consumer<MouseEvent> c)
/*     */   {
/*  72 */     new MouseAdapter()
/*     */     {
/*     */       public void mouseDoubleClick(MouseEvent e) {
/*  75 */         this.val$c.accept(e);
/*     */       }
/*     */     };
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static MouseListener mouseDownAdapter(Consumer<MouseEvent> c)
/*     */   {
/*  90 */     new MouseAdapter()
/*     */     {
/*     */       public void mouseDown(MouseEvent e) {
/*  93 */         this.val$c.accept(e);
/*     */       }
/*     */     };
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static MouseListener mouseUpAdapter(Consumer<MouseEvent> c)
/*     */   {
/* 108 */     new MouseAdapter()
/*     */     {
/*     */       public void mouseUp(MouseEvent e) {
/* 111 */         this.val$c.accept(e);
/*     */       }
/*     */     };
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/events/MouseListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */