/*     */ package org.eclipse.swt.widgets;
/*     */ 
/*     */ import org.eclipse.swt.SWT;
/*     */ import org.eclipse.swt.graphics.Image;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TaskItem
/*     */   extends Item
/*     */ {
/*     */   TaskBar parent;
/*     */   Shell shell;
/*     */   int progress;
/*  36 */   int progressState = -1;
/*     */   Image overlayImage;
/*  38 */   String overlayText = "";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   Menu menu;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static final int PROGRESS_MAX = 100;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   TaskItem(TaskBar parent, int style)
/*     */   {
/*  73 */     super(parent, style);
/*  74 */     this.parent = parent;
/*  75 */     parent.createItem(this, -1);
/*     */   }
/*     */   
/*     */   protected void checkSubclass()
/*     */   {
/*  80 */     if (!isValidSubclass()) error(43);
/*     */   }
/*     */   
/*     */   void destroyWidget()
/*     */   {
/*  85 */     this.parent.destroyItem(this);
/*  86 */     releaseHandle();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Menu getMenu()
/*     */   {
/* 101 */     checkWidget();
/* 102 */     return this.menu;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Image getOverlayImage()
/*     */   {
/* 117 */     checkWidget();
/* 118 */     return this.overlayImage;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getOverlayText()
/*     */   {
/* 133 */     checkWidget();
/* 134 */     return this.overlayText;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TaskBar getParent()
/*     */   {
/* 149 */     checkWidget();
/* 150 */     return this.parent;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getProgress()
/*     */   {
/* 164 */     checkWidget();
/* 165 */     return this.progress;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getProgressState()
/*     */   {
/* 179 */     checkWidget();
/* 180 */     return this.progressState;
/*     */   }
/*     */   
/*     */   void releaseHandle()
/*     */   {
/* 185 */     super.releaseHandle();
/* 186 */     this.parent = null;
/*     */   }
/*     */   
/*     */   void releaseWidget()
/*     */   {
/* 191 */     super.releaseWidget();
/* 192 */     this.overlayImage = null;
/* 193 */     this.overlayText = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMenu(Menu menu)
/*     */   {
/* 228 */     checkWidget();
/* 229 */     if (menu != null) {
/* 230 */       if (menu.isDisposed()) SWT.error(5);
/* 231 */       if ((menu.style & 0x8) == 0) {
/* 232 */         error(37);
/*     */       }
/*     */     }
/* 235 */     this.menu = menu;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setOverlayImage(Image overlayImage)
/*     */   {
/* 266 */     checkWidget();
/* 267 */     if ((overlayImage != null) && (overlayImage.isDisposed())) error(5);
/* 268 */     this.overlayImage = overlayImage;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setOverlayText(String overlayText)
/*     */   {
/* 298 */     checkWidget();
/* 299 */     if (overlayText == null) error(4);
/* 300 */     this.overlayText = overlayText;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setProgressState(int progressState)
/*     */   {
/* 339 */     checkWidget();
/* 340 */     if (this.progressState == progressState) return;
/* 341 */     this.progressState = progressState;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setProgress(int progress)
/*     */   {
/* 370 */     checkWidget();
/* 371 */     progress = Math.max(0, Math.min(progress, 100));
/* 372 */     if (this.progress == progress) return;
/* 373 */     this.progress = progress;
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/widgets/TaskItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */