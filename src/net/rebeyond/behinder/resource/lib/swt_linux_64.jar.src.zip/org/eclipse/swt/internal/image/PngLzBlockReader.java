/*     */ package org.eclipse.swt.internal.image;
/*     */ 
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PngLzBlockReader
/*     */ {
/*     */   boolean isLastBlock;
/*     */   byte compressionType;
/*     */   int uncompressedBytesRemaining;
/*     */   PngDecodingDataStream stream;
/*     */   PngHuffmanTables huffmanTables;
/*     */   byte[] window;
/*     */   int windowIndex;
/*     */   int copyIndex;
/*     */   int copyBytesRemaining;
/*     */   static final int UNCOMPRESSED = 0;
/*     */   static final int COMPRESSED_FIXED = 1;
/*     */   static final int COMPRESSED_DYNAMIC = 2;
/*     */   static final int END_OF_COMPRESSED_BLOCK = 256;
/*     */   static final int FIRST_LENGTH_CODE = 257;
/*     */   static final int LAST_LENGTH_CODE = 285;
/*     */   static final int FIRST_DISTANCE_CODE = 1;
/*     */   static final int LAST_DISTANCE_CODE = 29;
/*     */   static final int FIRST_CODE_LENGTH_CODE = 4;
/*     */   static final int LAST_CODE_LENGTH_CODE = 19;
/*  39 */   static final int[] lengthBases = { 3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 15, 17, 19, 23, 27, 31, 35, 43, 51, 59, 67, 83, 99, 115, 131, 163, 195, 227, 258 };
/*     */   
/*     */ 
/*     */ 
/*  43 */   static final int[] extraLengthBits = { 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0 };
/*     */   
/*     */ 
/*     */ 
/*  47 */   static final int[] distanceBases = { 1, 2, 3, 4, 5, 7, 9, 13, 17, 25, 33, 49, 65, 97, 129, 193, 257, 385, 513, 769, 1025, 1537, 2049, 3073, 4097, 6145, 8193, 12289, 16385, 24577 };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  52 */   static final int[] extraDistanceBits = { 0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13 };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   PngLzBlockReader(PngDecodingDataStream stream)
/*     */   {
/*  59 */     this.stream = stream;
/*  60 */     this.isLastBlock = false;
/*     */   }
/*     */   
/*     */   void setWindowSize(int windowSize) {
/*  64 */     this.window = new byte[windowSize];
/*     */   }
/*     */   
/*     */   void readNextBlockHeader() throws IOException {
/*  68 */     this.isLastBlock = (this.stream.getNextIdatBit() != 0);
/*  69 */     this.compressionType = ((byte)this.stream.getNextIdatBits(2));
/*  70 */     if (this.compressionType > 2) { this.stream.error();
/*     */     }
/*  72 */     if (this.compressionType == 0) {
/*  73 */       byte b1 = this.stream.getNextIdatByte();
/*  74 */       byte b2 = this.stream.getNextIdatByte();
/*  75 */       byte b3 = this.stream.getNextIdatByte();
/*  76 */       byte b4 = this.stream.getNextIdatByte();
/*  77 */       if ((b1 != (b3 ^ 0xFFFFFFFF)) || (b2 != (b4 ^ 0xFFFFFFFF))) this.stream.error();
/*  78 */       this.uncompressedBytesRemaining = (b1 & 0xFF | (b2 & 0xFF) << 8);
/*  79 */     } else if (this.compressionType == 2) {
/*  80 */       this.huffmanTables = PngHuffmanTables.getDynamicTables(this.stream);
/*     */     } else {
/*  82 */       this.huffmanTables = PngHuffmanTables.getFixedTables();
/*     */     }
/*     */   }
/*     */   
/*     */   byte getNextByte() throws IOException {
/*  87 */     if (this.compressionType == 0) {
/*  88 */       if (this.uncompressedBytesRemaining == 0) {
/*  89 */         readNextBlockHeader();
/*  90 */         return getNextByte();
/*     */       }
/*  92 */       this.uncompressedBytesRemaining -= 1;
/*  93 */       return this.stream.getNextIdatByte();
/*     */     }
/*  95 */     return getNextCompressedByte();
/*     */   }
/*     */   
/*     */   private void assertBlockAtEnd() throws IOException
/*     */   {
/* 100 */     if (this.compressionType == 0) {
/* 101 */       if (this.uncompressedBytesRemaining > 0) this.stream.error();
/* 102 */     } else if ((this.copyBytesRemaining > 0) || 
/* 103 */       (this.huffmanTables.getNextLiteralValue(this.stream) != 256))
/*     */     {
/* 105 */       this.stream.error(); }
/*     */   }
/*     */   
/*     */   void assertCompressedDataAtEnd() throws IOException {
/* 109 */     assertBlockAtEnd();
/* 110 */     while (!this.isLastBlock) {
/* 111 */       readNextBlockHeader();
/* 112 */       assertBlockAtEnd();
/*     */     }
/*     */   }
/*     */   
/*     */   private byte getNextCompressedByte() throws IOException {
/* 117 */     if (this.copyBytesRemaining > 0) {
/* 118 */       byte value = this.window[this.copyIndex];
/* 119 */       this.window[this.windowIndex] = value;
/* 120 */       this.copyBytesRemaining -= 1;
/*     */       
/* 122 */       this.copyIndex += 1;
/* 123 */       this.windowIndex += 1;
/* 124 */       if (this.copyIndex == this.window.length) this.copyIndex = 0;
/* 125 */       if (this.windowIndex == this.window.length) { this.windowIndex = 0;
/*     */       }
/* 127 */       return value;
/*     */     }
/*     */     
/* 130 */     int value = this.huffmanTables.getNextLiteralValue(this.stream);
/* 131 */     if (value < 256) {
/* 132 */       this.window[this.windowIndex] = ((byte)value);
/* 133 */       this.windowIndex += 1;
/* 134 */       if (this.windowIndex >= this.window.length) this.windowIndex = 0;
/* 135 */       return (byte)value; }
/* 136 */     if (value == 256) {
/* 137 */       readNextBlockHeader();
/* 138 */       return getNextByte(); }
/* 139 */     if (value <= 285) {
/* 140 */       int extraBits = extraLengthBits[(value - 257)];
/* 141 */       int length = lengthBases[(value - 257)];
/* 142 */       if (extraBits > 0) {
/* 143 */         length += this.stream.getNextIdatBits(extraBits);
/*     */       }
/*     */       
/* 146 */       value = this.huffmanTables.getNextDistanceValue(this.stream);
/* 147 */       if (value > 29) this.stream.error();
/* 148 */       extraBits = extraDistanceBits[value];
/* 149 */       int distance = distanceBases[value];
/* 150 */       if (extraBits > 0) {
/* 151 */         distance += this.stream.getNextIdatBits(extraBits);
/*     */       }
/*     */       
/* 154 */       this.copyIndex = (this.windowIndex - distance);
/* 155 */       if (this.copyIndex < 0) { this.copyIndex += this.window.length;
/*     */       }
/* 157 */       this.copyBytesRemaining = length;
/* 158 */       return getNextCompressedByte();
/*     */     }
/* 160 */     this.stream.error();
/* 161 */     return 0;
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/internal/image/PngLzBlockReader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */