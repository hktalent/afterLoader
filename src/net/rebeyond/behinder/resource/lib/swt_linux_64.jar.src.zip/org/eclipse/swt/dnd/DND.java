/*     */ package org.eclipse.swt.dnd;
/*     */ 
/*     */ import org.eclipse.swt.SWT;
/*     */ import org.eclipse.swt.SWTError;
/*     */ import org.eclipse.swt.SWTException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DND
/*     */ {
/*     */   public static final int CLIPBOARD = 1;
/*     */   public static final int SELECTION_CLIPBOARD = 2;
/*     */   public static final int DROP_NONE = 0;
/*     */   public static final int DROP_COPY = 1;
/*     */   public static final int DROP_MOVE = 2;
/*     */   public static final int DROP_LINK = 4;
/*     */   public static final int DROP_TARGET_MOVE = 8;
/*     */   public static final int DROP_DEFAULT = 16;
/*     */   public static final int DragEnd = 2000;
/*     */   public static final int DragSetData = 2001;
/*     */   public static final int DragEnter = 2002;
/*     */   public static final int DragLeave = 2003;
/*     */   public static final int DragOver = 2004;
/*     */   public static final int DragOperationChanged = 2005;
/*     */   public static final int Drop = 2006;
/*     */   public static final int DropAccept = 2007;
/*     */   public static final int DragStart = 2008;
/*     */   public static final int FEEDBACK_NONE = 0;
/*     */   public static final int FEEDBACK_SELECT = 1;
/*     */   public static final int FEEDBACK_INSERT_BEFORE = 2;
/*     */   public static final int FEEDBACK_INSERT_AFTER = 4;
/*     */   public static final int FEEDBACK_SCROLL = 8;
/*     */   public static final int FEEDBACK_EXPAND = 16;
/*     */   public static final int ERROR_CANNOT_INIT_DRAG = 2000;
/*     */   public static final int ERROR_CANNOT_INIT_DROP = 2001;
/*     */   public static final int ERROR_CANNOT_SET_CLIPBOARD = 2002;
/*     */   public static final int ERROR_INVALID_DATA = 2003;
/*     */   public static final String DROP_TARGET_KEY = "DropTarget";
/*     */   public static final String DRAG_SOURCE_KEY = "DragSource";
/*     */   static final String INIT_DRAG_MESSAGE = "Cannot initialize Drag";
/*     */   static final String INIT_DROP_MESSAGE = "Cannot initialize Drop";
/*     */   static final String CANNOT_SET_CLIPBOARD_MESSAGE = "Cannot set data in clipboard";
/*     */   static final String INVALID_DATA_MESSAGE = "Data does not have correct format for type";
/*     */   
/*     */   public static void error(int code)
/*     */   {
/* 238 */     error(code, 0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void error(int code, int hresult)
/*     */   {
/* 267 */     switch (code)
/*     */     {
/*     */     case 2000: 
/* 270 */       String msg = "Cannot initialize Drag";
/* 271 */       if (hresult != 0) msg = msg + " result = " + hresult;
/* 272 */       throw new SWTError(code, msg);
/*     */     
/*     */     case 2001: 
/* 275 */       String msg = "Cannot initialize Drop";
/* 276 */       if (hresult != 0) msg = msg + " result = " + hresult;
/* 277 */       throw new SWTError(code, msg);
/*     */     
/*     */     case 2002: 
/* 280 */       String msg = "Cannot set data in clipboard";
/* 281 */       if (hresult != 0) msg = msg + " result = " + hresult;
/* 282 */       throw new SWTError(code, msg);
/*     */     
/*     */     case 2003: 
/* 285 */       String msg = "Data does not have correct format for type";
/* 286 */       if (hresult != 0) msg = msg + " result = " + hresult;
/* 287 */       throw new SWTException(code, msg);
/*     */     }
/*     */     
/*     */     
/*     */ 
/* 292 */     SWT.error(code);
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/dnd/DND.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */