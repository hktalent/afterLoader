/*    */ package org.eclipse.swt.widgets;
/*    */ 
/*    */ import java.util.function.Consumer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class RunnableLock
/*    */ {
/*    */   Runnable runnable;
/*    */   Thread thread;
/*    */   Throwable throwable;
/*    */   
/*    */   RunnableLock(Runnable runnable)
/*    */   {
/* 27 */     this.runnable = runnable;
/*    */   }
/*    */   
/*    */   boolean done() {
/* 31 */     return (this.runnable == null) || (this.throwable != null);
/*    */   }
/*    */   
/*    */   void run(Display display) {
/* 35 */     if (this.runnable != null) {
/*    */       try {
/* 37 */         this.runnable.run();
/*    */       } catch (RuntimeException exception) {
/* 39 */         display.getRuntimeExceptionHandler().accept(exception);
/*    */       } catch (Error error) {
/* 41 */         display.getErrorHandler().accept(error);
/*    */       }
/*    */     }
/* 44 */     this.runnable = null;
/*    */   }
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/widgets/RunnableLock.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */