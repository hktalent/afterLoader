/*    */ package org.eclipse.swt.internal;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LONG
/*    */ {
/*    */   public long value;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public LONG(long value)
/*    */   {
/* 18 */     this.value = value;
/*    */   }
/*    */   
/*    */   public boolean equals(Object object)
/*    */   {
/* 23 */     if (object == this) return true;
/* 24 */     if (!(object instanceof LONG)) return false;
/* 25 */     LONG obj = (LONG)object;
/* 26 */     return obj.value == this.value;
/*    */   }
/*    */   
/*    */   public int hashCode()
/*    */   {
/* 31 */     return (int)(this.value ^ this.value >>> 32);
/*    */   }
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/internal/LONG.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */