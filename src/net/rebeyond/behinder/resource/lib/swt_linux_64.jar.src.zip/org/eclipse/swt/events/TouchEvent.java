/*    */ package org.eclipse.swt.events;
/*    */ 
/*    */ import org.eclipse.swt.widgets.Event;
/*    */ import org.eclipse.swt.widgets.Touch;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TouchEvent
/*    */   extends TypedEvent
/*    */ {
/*    */   public Touch[] touches;
/*    */   public int stateMask;
/*    */   public int x;
/*    */   public int y;
/*    */   static final long serialVersionUID = -8348741538373572182L;
/*    */   
/*    */   public TouchEvent(Event e)
/*    */   {
/* 65 */     super(e);
/* 66 */     this.touches = e.touches;
/* 67 */     this.stateMask = e.stateMask;
/* 68 */     this.x = e.x;
/* 69 */     this.y = e.y;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public String toString()
/*    */   {
/* 80 */     String string = super.toString();
/* 81 */     string = string.substring(0, string.length() - 1);
/* 82 */     string = string + " stateMask=0x" + Integer.toHexString(this.stateMask) + " x=" + this.x + " y=" + this.y;
/*    */     
/*    */ 
/* 85 */     if (this.touches != null) {
/* 86 */       for (int i = 0; i < this.touches.length; i++) {
/* 87 */         string = string + "\n     " + this.touches[i].toString();
/*    */       }
/* 89 */       string = string + "\n";
/*    */     }
/* 91 */     string = string + "}";
/* 92 */     return string;
/*    */   }
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/events/TouchEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */