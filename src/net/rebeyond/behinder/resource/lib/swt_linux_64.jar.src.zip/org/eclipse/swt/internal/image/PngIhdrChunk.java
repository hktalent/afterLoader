/*     */ package org.eclipse.swt.internal.image;
/*     */ 
/*     */ import org.eclipse.swt.SWT;
/*     */ import org.eclipse.swt.graphics.PaletteData;
/*     */ import org.eclipse.swt.graphics.RGB;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class PngIhdrChunk
/*     */   extends PngChunk
/*     */ {
/*     */   static final int IHDR_DATA_LENGTH = 13;
/*     */   static final int WIDTH_DATA_OFFSET = 8;
/*     */   static final int HEIGHT_DATA_OFFSET = 12;
/*     */   static final int BIT_DEPTH_OFFSET = 16;
/*     */   static final int COLOR_TYPE_OFFSET = 17;
/*     */   static final int COMPRESSION_METHOD_OFFSET = 18;
/*     */   static final int FILTER_METHOD_OFFSET = 19;
/*     */   static final int INTERLACE_METHOD_OFFSET = 20;
/*     */   static final byte COLOR_TYPE_GRAYSCALE = 0;
/*     */   static final byte COLOR_TYPE_RGB = 2;
/*     */   static final byte COLOR_TYPE_PALETTE = 3;
/*     */   static final byte COLOR_TYPE_GRAYSCALE_WITH_ALPHA = 4;
/*     */   static final byte COLOR_TYPE_RGB_WITH_ALPHA = 6;
/*     */   static final int INTERLACE_METHOD_NONE = 0;
/*     */   static final int INTERLACE_METHOD_ADAM7 = 1;
/*     */   static final int FILTER_NONE = 0;
/*     */   static final int FILTER_SUB = 1;
/*     */   static final int FILTER_UP = 2;
/*     */   static final int FILTER_AVERAGE = 3;
/*     */   static final int FILTER_PAETH = 4;
/*  43 */   static final byte[] ValidBitDepths = { 1, 2, 4, 8, 16 };
/*  44 */   static final byte[] ValidColorTypes = { 0, 2, 3, 4, 6 };
/*     */   int width;
/*     */   int height;
/*     */   byte bitDepth;
/*     */   
/*     */   PngIhdrChunk(int width, int height, byte bitDepth, byte colorType, byte compressionMethod, byte filterMethod, byte interlaceMethod) {
/*  50 */     super(13);
/*  51 */     setType(TYPE_IHDR);
/*  52 */     setWidth(width);
/*  53 */     setHeight(height);
/*  54 */     setBitDepth(bitDepth);
/*  55 */     setColorType(colorType);
/*  56 */     setCompressionMethod(compressionMethod);
/*  57 */     setFilterMethod(filterMethod);
/*  58 */     setInterlaceMethod(interlaceMethod);
/*  59 */     setCRC(computeCRC());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   PngIhdrChunk(byte[] reference)
/*     */   {
/*  67 */     super(reference);
/*  68 */     if (reference.length <= 13) SWT.error(40);
/*  69 */     this.width = getInt32(8);
/*  70 */     this.height = getInt32(12);
/*  71 */     this.bitDepth = reference[16];
/*  72 */     this.colorType = reference[17];
/*  73 */     this.compressionMethod = reference[18];
/*  74 */     this.filterMethod = reference[19];
/*  75 */     this.interlaceMethod = reference[20];
/*     */   }
/*     */   
/*     */   int getChunkType()
/*     */   {
/*  80 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   int getWidth()
/*     */   {
/*  87 */     return this.width;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   void setWidth(int value)
/*     */   {
/*  94 */     setInt32(8, value);
/*  95 */     this.width = value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   int getHeight()
/*     */   {
/* 102 */     return this.height;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   void setHeight(int value)
/*     */   {
/* 109 */     setInt32(12, value);
/* 110 */     this.height = value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   byte getBitDepth()
/*     */   {
/* 118 */     return this.bitDepth;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   void setBitDepth(byte value)
/*     */   {
/* 126 */     this.reference[16] = value;
/* 127 */     this.bitDepth = value;
/*     */   }
/*     */   
/*     */ 
/*     */   byte colorType;
/*     */   
/*     */   byte compressionMethod;
/*     */   
/*     */   byte filterMethod;
/*     */   
/*     */   byte interlaceMethod;
/*     */   byte getColorType()
/*     */   {
/* 140 */     return this.colorType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void setColorType(byte value)
/*     */   {
/* 153 */     this.reference[17] = value;
/* 154 */     this.colorType = value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   byte getCompressionMethod()
/*     */   {
/* 162 */     return this.compressionMethod;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   void setCompressionMethod(byte value)
/*     */   {
/* 170 */     this.reference[18] = value;
/* 171 */     this.compressionMethod = value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   byte getFilterMethod()
/*     */   {
/* 179 */     return this.filterMethod;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   void setFilterMethod(byte value)
/*     */   {
/* 187 */     this.reference[19] = value;
/* 188 */     this.filterMethod = value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   byte getInterlaceMethod()
/*     */   {
/* 198 */     return this.interlaceMethod;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void setInterlaceMethod(byte value)
/*     */   {
/* 208 */     this.reference[20] = value;
/* 209 */     this.interlaceMethod = value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void validate(PngFileReadState readState, PngIhdrChunk headerChunk)
/*     */   {
/* 219 */     if ((readState.readIHDR) || (readState.readPLTE) || (readState.readIDAT) || (readState.readIEND))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 224 */       SWT.error(40);
/*     */     } else {
/* 226 */       readState.readIHDR = true;
/*     */     }
/*     */     
/* 229 */     super.validate(readState, headerChunk);
/*     */     
/* 231 */     if (this.length != 13) SWT.error(40);
/* 232 */     if (this.compressionMethod != 0) SWT.error(40);
/* 233 */     if ((this.interlaceMethod != 0) && (this.interlaceMethod != 1))
/*     */     {
/* 235 */       SWT.error(40);
/*     */     }
/*     */     
/* 238 */     boolean colorTypeIsValid = false;
/* 239 */     for (int i = 0; i < ValidColorTypes.length; i++) {
/* 240 */       if (ValidColorTypes[i] == this.colorType) {
/* 241 */         colorTypeIsValid = true;
/* 242 */         break;
/*     */       }
/*     */     }
/* 245 */     if (!colorTypeIsValid) { SWT.error(40);
/*     */     }
/* 247 */     boolean bitDepthIsValid = false;
/* 248 */     for (int i = 0; i < ValidBitDepths.length; i++) {
/* 249 */       if (ValidBitDepths[i] == this.bitDepth) {
/* 250 */         bitDepthIsValid = true;
/* 251 */         break;
/*     */       }
/*     */     }
/* 254 */     if (!bitDepthIsValid) { SWT.error(40);
/*     */     }
/* 256 */     if (((this.colorType == 2) || (this.colorType == 6) || (this.colorType == 4)) && (this.bitDepth < 8))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 261 */       SWT.error(40);
/*     */     }
/*     */     
/* 264 */     if ((this.colorType == 3) && (this.bitDepth > 8)) {
/* 265 */       SWT.error(40);
/*     */     }
/*     */   }
/*     */   
/*     */   String getColorTypeString() {
/* 270 */     switch (this.colorType) {
/* 271 */     case 0:  return "Grayscale";
/* 272 */     case 2:  return "RGB";
/* 273 */     case 3:  return "Palette";
/* 274 */     case 4:  return "Grayscale with Alpha";
/* 275 */     case 6:  return "RGB with Alpha"; }
/* 276 */     return "Unknown - " + this.colorType;
/*     */   }
/*     */   
/*     */   String getFilterMethodString()
/*     */   {
/* 281 */     switch (this.filterMethod) {
/* 282 */     case 0:  return "None";
/* 283 */     case 1:  return "Sub";
/* 284 */     case 2:  return "Up";
/* 285 */     case 3:  return "Average";
/* 286 */     case 4:  return "Paeth"; }
/* 287 */     return "Unknown";
/*     */   }
/*     */   
/*     */   String getInterlaceMethodString()
/*     */   {
/* 292 */     switch (this.interlaceMethod) {
/* 293 */     case 0:  return "Not Interlaced";
/* 294 */     case 1:  return "Interlaced - ADAM7"; }
/* 295 */     return "Unknown";
/*     */   }
/*     */   
/*     */ 
/*     */   void contributeToString(StringBuilder buffer)
/*     */   {
/* 301 */     buffer.append("\n\tWidth: ");
/* 302 */     buffer.append(this.width);
/* 303 */     buffer.append("\n\tHeight: ");
/* 304 */     buffer.append(this.height);
/* 305 */     buffer.append("\n\tBit Depth: ");
/* 306 */     buffer.append(this.bitDepth);
/* 307 */     buffer.append("\n\tColor Type: ");
/* 308 */     buffer.append(getColorTypeString());
/* 309 */     buffer.append("\n\tCompression Method: ");
/* 310 */     buffer.append(this.compressionMethod);
/* 311 */     buffer.append("\n\tFilter Method: ");
/* 312 */     buffer.append(getFilterMethodString());
/* 313 */     buffer.append("\n\tInterlace Method: ");
/* 314 */     buffer.append(getInterlaceMethodString());
/*     */   }
/*     */   
/*     */   boolean getMustHavePalette() {
/* 318 */     return this.colorType == 3;
/*     */   }
/*     */   
/*     */   boolean getCanHavePalette() {
/* 322 */     return (this.colorType != 0) && (this.colorType != 4);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   int getBitsPerPixel()
/*     */   {
/* 331 */     switch (this.colorType) {
/*     */     case 6: 
/* 333 */       return 4 * this.bitDepth;
/*     */     case 2: 
/* 335 */       return 3 * this.bitDepth;
/*     */     case 4: 
/* 337 */       return 2 * this.bitDepth;
/*     */     case 0: 
/*     */     case 3: 
/* 340 */       return this.bitDepth;
/*     */     }
/* 342 */     SWT.error(40);
/* 343 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   int getSwtBitsPerPixel()
/*     */   {
/* 352 */     switch (this.colorType) {
/*     */     case 2: 
/*     */     case 4: 
/*     */     case 6: 
/* 356 */       return 24;
/*     */     case 0: 
/*     */     case 3: 
/* 359 */       return Math.min(this.bitDepth, 8);
/*     */     }
/* 361 */     SWT.error(40);
/* 362 */     return 0;
/*     */   }
/*     */   
/*     */   int getFilterByteOffset()
/*     */   {
/* 367 */     if (this.bitDepth < 8) return 1;
/* 368 */     return getBitsPerPixel() / 8;
/*     */   }
/*     */   
/*     */   boolean usesDirectColor() {
/* 372 */     switch (this.colorType) {
/*     */     case 0: 
/*     */     case 2: 
/*     */     case 4: 
/*     */     case 6: 
/* 377 */       return true;
/*     */     }
/* 379 */     return false;
/*     */   }
/*     */   
/*     */   PaletteData createGrayscalePalette()
/*     */   {
/* 384 */     int depth = Math.min(this.bitDepth, 8);
/* 385 */     int max = (1 << depth) - 1;
/* 386 */     int delta = 255 / max;
/* 387 */     int gray = 0;
/* 388 */     RGB[] rgbs = new RGB[max + 1];
/* 389 */     for (int i = 0; i <= max; i++) {
/* 390 */       rgbs[i] = new RGB(gray, gray, gray);
/* 391 */       gray += delta;
/*     */     }
/* 393 */     return new PaletteData(rgbs);
/*     */   }
/*     */   
/*     */   PaletteData getPaletteData() {
/* 397 */     switch (this.colorType) {
/*     */     case 0: 
/* 399 */       return createGrayscalePalette();
/*     */     case 2: 
/*     */     case 4: 
/*     */     case 6: 
/* 403 */       return new PaletteData(16711680, 65280, 255);
/*     */     }
/* 405 */     return null;
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/internal/image/PngIhdrChunk.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */