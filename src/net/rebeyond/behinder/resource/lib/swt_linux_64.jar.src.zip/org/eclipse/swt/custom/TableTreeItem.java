/*     */ package org.eclipse.swt.custom;
/*     */ 
/*     */ import org.eclipse.swt.SWT;
/*     */ import org.eclipse.swt.graphics.Color;
/*     */ import org.eclipse.swt.graphics.Font;
/*     */ import org.eclipse.swt.graphics.GC;
/*     */ import org.eclipse.swt.graphics.Image;
/*     */ import org.eclipse.swt.graphics.Rectangle;
/*     */ import org.eclipse.swt.widgets.Event;
/*     */ import org.eclipse.swt.widgets.Item;
/*     */ import org.eclipse.swt.widgets.Table;
/*     */ import org.eclipse.swt.widgets.TableItem;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class TableTreeItem
/*     */   extends Item
/*     */ {
/*     */   TableItem tableItem;
/*     */   TableTree parent;
/*     */   TableTreeItem parentItem;
/*  32 */   TableTreeItem[] items = TableTree.EMPTY_ITEMS;
/*  33 */   String[] texts = TableTree.EMPTY_TEXTS;
/*  34 */   Image[] images = TableTree.EMPTY_IMAGES;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   Color background;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   Color foreground;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   Font font;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   boolean expanded;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   boolean checked;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   boolean grayed;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public TableTreeItem(TableTree parent, int style)
/*     */   {
/*  71 */     this(parent, style, parent.getItemCount());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TableTreeItem(TableTree parent, int style, int index)
/*     */   {
/* 104 */     this(parent, null, style, index);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TableTreeItem(TableTreeItem parent, int style)
/*     */   {
/* 136 */     this(parent, style, parent.getItemCount());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TableTreeItem(TableTreeItem parent, int style, int index)
/*     */   {
/* 169 */     this(parent.getParent(), parent, style, index);
/*     */   }
/*     */   
/*     */   TableTreeItem(TableTree parent, TableTreeItem parentItem, int style, int index) {
/* 173 */     super(parent, style);
/* 174 */     this.parent = parent;
/* 175 */     this.parentItem = parentItem;
/* 176 */     if (parentItem == null)
/*     */     {
/*     */ 
/* 179 */       int tableIndex = parent.addItem(this, index);
/* 180 */       this.tableItem = new TableItem(parent.getTable(), style, tableIndex);
/* 181 */       this.tableItem.setData("TableTreeItemID", this);
/* 182 */       addCheck();
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 190 */       if (parent.sizeImage == null) {
/* 191 */         int itemHeight = parent.getItemHeight();
/* 192 */         parent.sizeImage = new Image(parent.getDisplay(), itemHeight, itemHeight);
/* 193 */         GC gc = new GC(parent.sizeImage);
/* 194 */         gc.setBackground(parent.getBackground());
/* 195 */         gc.fillRectangle(0, 0, itemHeight, itemHeight);
/* 196 */         gc.dispose();
/* 197 */         this.tableItem.setImage(0, parent.sizeImage);
/*     */       }
/*     */     } else {
/* 200 */       parentItem.addItem(this, index);
/*     */     }
/*     */   }
/*     */   
/* 204 */   void addCheck() { Table table = this.parent.getTable();
/* 205 */     if ((table.getStyle() & 0x20) == 0) return;
/* 206 */     this.tableItem.setChecked(this.checked);
/* 207 */     this.tableItem.setGrayed(this.grayed);
/*     */   }
/*     */   
/* 210 */   void addItem(TableTreeItem item, int index) { if (item == null) SWT.error(4);
/* 211 */     if ((index < 0) || (index > this.items.length)) { SWT.error(5);
/*     */     }
/*     */     
/* 214 */     if ((this.items.length == 0) && (index == 0) && 
/* 215 */       (this.tableItem != null)) {
/* 216 */       Image image = this.expanded ? this.parent.getMinusImage() : this.parent.getPlusImage();
/* 217 */       this.tableItem.setImage(0, image);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 222 */     TableTreeItem[] newItems = new TableTreeItem[this.items.length + 1];
/* 223 */     System.arraycopy(this.items, 0, newItems, 0, index);
/* 224 */     newItems[index] = item;
/* 225 */     System.arraycopy(this.items, index, newItems, index + 1, this.items.length - index);
/* 226 */     this.items = newItems;
/* 227 */     if (this.expanded) { item.setVisible(true);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Color getBackground()
/*     */   {
/* 244 */     checkWidget();
/* 245 */     return this.background == null ? this.parent.getBackground() : this.background;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Rectangle getBounds(int index)
/*     */   {
/* 260 */     checkWidget();
/* 261 */     if (this.tableItem != null) {
/* 262 */       return this.tableItem.getBounds(index);
/*     */     }
/* 264 */     return new Rectangle(0, 0, 0, 0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getChecked()
/*     */   {
/* 280 */     checkWidget();
/* 281 */     if (this.tableItem == null) return this.checked;
/* 282 */     return this.tableItem.getChecked();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getGrayed()
/*     */   {
/* 300 */     checkWidget();
/* 301 */     if (this.tableItem == null) return this.grayed;
/* 302 */     return this.tableItem.getGrayed();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getExpanded()
/*     */   {
/* 314 */     return this.expanded;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Font getFont()
/*     */   {
/* 330 */     checkWidget();
/* 331 */     return this.font == null ? this.parent.getFont() : this.font;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Color getForeground()
/*     */   {
/* 347 */     checkWidget();
/* 348 */     return this.foreground == null ? this.parent.getForeground() : this.foreground;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Image getImage()
/*     */   {
/* 365 */     checkWidget();
/* 366 */     return getImage(0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Image getImage(int index)
/*     */   {
/* 382 */     if ((0 < index) && (index < this.images.length)) return this.images[index];
/* 383 */     return null;
/*     */   }
/*     */   
/*     */   int getIndent() {
/* 387 */     if (this.parentItem == null) return 0;
/* 388 */     return this.parentItem.getIndent() + 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TableTreeItem getItem(int index)
/*     */   {
/* 409 */     checkWidget();
/* 410 */     int count = this.items.length;
/* 411 */     if ((0 > index) || (index >= count)) SWT.error(6);
/* 412 */     return this.items[index];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getItemCount()
/*     */   {
/* 423 */     return this.items.length;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TableTreeItem[] getItems()
/*     */   {
/* 439 */     TableTreeItem[] newItems = new TableTreeItem[this.items.length];
/* 440 */     System.arraycopy(this.items, 0, newItems, 0, this.items.length);
/* 441 */     return newItems;
/*     */   }
/*     */   
/*     */   TableTreeItem getItem(TableItem tableItem) {
/* 445 */     if (tableItem == null) return null;
/* 446 */     if (this.tableItem == tableItem) return this;
/* 447 */     for (int i = 0; i < this.items.length; i++) {
/* 448 */       TableTreeItem item = this.items[i].getItem(tableItem);
/* 449 */       if (item != null) return item;
/*     */     }
/* 451 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TableTree getParent()
/*     */   {
/* 461 */     return this.parent;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TableTreeItem getParentItem()
/*     */   {
/* 473 */     return this.parentItem;
/*     */   }
/*     */   
/*     */   public String getText() {
/* 477 */     checkWidget();
/* 478 */     return getText(0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getText(int index)
/*     */   {
/* 495 */     if ((0 <= index) && (index < this.texts.length)) return this.texts[index];
/* 496 */     return null;
/*     */   }
/*     */   
/*     */   boolean getVisible() {
/* 500 */     return this.tableItem != null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int indexOf(TableTreeItem item)
/*     */   {
/* 517 */     for (int i = 0; i < this.items.length; i++) {
/* 518 */       if (this.items[i] == item) return i;
/*     */     }
/* 520 */     return -1;
/*     */   }
/*     */   
/*     */   void expandAll(boolean notify) {
/* 524 */     if (this.items.length == 0) return;
/* 525 */     if (!this.expanded) {
/* 526 */       setExpanded(true);
/* 527 */       if (notify) {
/* 528 */         Event event = new Event();
/* 529 */         event.item = this;
/* 530 */         this.parent.notifyListeners(17, event);
/*     */       }
/*     */     }
/* 533 */     for (int i = 0; i < this.items.length; i++)
/* 534 */       this.items[i].expandAll(notify);
/*     */   }
/*     */   
/*     */   int expandedIndexOf(TableTreeItem item) {
/* 538 */     int index = 0;
/* 539 */     for (int i = 0; i < this.items.length; i++) {
/* 540 */       if (this.items[i] == item) return index;
/* 541 */       if (this.items[i].expanded) index += this.items[i].visibleChildrenCount();
/* 542 */       index++;
/*     */     }
/* 544 */     return -1;
/*     */   }
/*     */   
/*     */   int visibleChildrenCount() {
/* 548 */     int count = 0;
/* 549 */     for (int i = 0; i < this.items.length; i++) {
/* 550 */       if (this.items[i].getVisible()) {
/* 551 */         count += 1 + this.items[i].visibleChildrenCount();
/*     */       }
/*     */     }
/* 554 */     return count;
/*     */   }
/*     */   
/*     */   public void dispose()
/*     */   {
/* 559 */     if (isDisposed()) return;
/* 560 */     for (int i = this.items.length - 1; i >= 0; i--) {
/* 561 */       this.items[i].dispose();
/*     */     }
/* 563 */     super.dispose();
/* 564 */     if (!this.parent.inDispose) {
/* 565 */       if (this.parentItem != null) {
/* 566 */         this.parentItem.removeItem(this);
/*     */       } else {
/* 568 */         this.parent.removeItem(this);
/*     */       }
/* 570 */       if (this.tableItem != null) this.tableItem.dispose();
/*     */     }
/* 572 */     this.items = null;
/* 573 */     this.parentItem = null;
/* 574 */     this.parent = null;
/* 575 */     this.images = null;
/* 576 */     this.texts = null;
/* 577 */     this.tableItem = null;
/* 578 */     this.foreground = null;
/* 579 */     this.background = null;
/* 580 */     this.font = null;
/*     */   }
/*     */   
/*     */   void removeItem(TableTreeItem item) {
/* 584 */     int index = 0;
/* 585 */     while ((index < this.items.length) && (this.items[index] != item)) index++;
/* 586 */     if (index == this.items.length) return;
/* 587 */     TableTreeItem[] newItems = new TableTreeItem[this.items.length - 1];
/* 588 */     System.arraycopy(this.items, 0, newItems, 0, index);
/* 589 */     System.arraycopy(this.items, index + 1, newItems, index, this.items.length - index - 1);
/* 590 */     this.items = newItems;
/* 591 */     if ((this.items.length == 0) && 
/* 592 */       (this.tableItem != null)) { this.tableItem.setImage(0, null);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBackground(Color color)
/*     */   {
/* 615 */     checkWidget();
/* 616 */     if ((color != null) && (color.isDisposed())) {
/* 617 */       SWT.error(5);
/*     */     }
/* 619 */     if (this.tableItem != null) {
/* 620 */       this.tableItem.setBackground(color);
/*     */     }
/* 622 */     this.background = color;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setChecked(boolean checked)
/*     */   {
/* 637 */     checkWidget();
/* 638 */     Table table = this.parent.getTable();
/* 639 */     if ((table.getStyle() & 0x20) == 0) return;
/* 640 */     if (this.tableItem != null) {
/* 641 */       this.tableItem.setChecked(checked);
/*     */     }
/* 643 */     this.checked = checked;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setGrayed(boolean grayed)
/*     */   {
/* 660 */     checkWidget();
/* 661 */     Table table = this.parent.getTable();
/* 662 */     if ((table.getStyle() & 0x20) == 0) return;
/* 663 */     if (this.tableItem != null) {
/* 664 */       this.tableItem.setGrayed(grayed);
/*     */     }
/* 666 */     this.grayed = grayed;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setExpanded(boolean expanded)
/*     */   {
/* 680 */     checkWidget();
/* 681 */     if (this.items.length == 0) return;
/* 682 */     if (this.expanded == expanded) return;
/* 683 */     this.expanded = expanded;
/* 684 */     if (this.tableItem == null) return;
/* 685 */     this.parent.setRedraw(false);
/* 686 */     for (int i = 0; i < this.items.length; i++) {
/* 687 */       this.items[i].setVisible(expanded);
/*     */     }
/* 689 */     Image image = expanded ? this.parent.getMinusImage() : this.parent.getPlusImage();
/* 690 */     this.tableItem.setImage(0, image);
/* 691 */     this.parent.setRedraw(true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFont(Font font)
/*     */   {
/* 712 */     checkWidget();
/* 713 */     if ((font != null) && (font.isDisposed())) {
/* 714 */       SWT.error(5);
/*     */     }
/* 716 */     if (this.tableItem != null) {
/* 717 */       this.tableItem.setFont(font);
/*     */     }
/* 719 */     this.font = font;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setForeground(Color color)
/*     */   {
/* 742 */     checkWidget();
/* 743 */     if ((color != null) && (color.isDisposed())) {
/* 744 */       SWT.error(5);
/*     */     }
/* 746 */     if (this.tableItem != null) {
/* 747 */       this.tableItem.setForeground(color);
/*     */     }
/* 749 */     this.foreground = color;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setImage(int index, Image image)
/*     */   {
/* 767 */     checkWidget();
/* 768 */     int columnCount = Math.max(this.parent.getTable().getColumnCount(), 1);
/* 769 */     if ((index <= 0) || (index >= columnCount)) return;
/* 770 */     if (this.images.length < columnCount) {
/* 771 */       Image[] newImages = new Image[columnCount];
/* 772 */       System.arraycopy(this.images, 0, newImages, 0, this.images.length);
/* 773 */       this.images = newImages;
/*     */     }
/* 775 */     this.images[index] = image;
/* 776 */     if (this.tableItem != null) { this.tableItem.setImage(index, image);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setImage(Image image)
/*     */   {
/* 795 */     setImage(0, image);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setText(int index, String text)
/*     */   {
/* 818 */     checkWidget();
/* 819 */     if (text == null) SWT.error(4);
/* 820 */     int columnCount = Math.max(this.parent.getTable().getColumnCount(), 1);
/* 821 */     if ((index < 0) || (index >= columnCount)) return;
/* 822 */     if (this.texts.length < columnCount) {
/* 823 */       String[] newTexts = new String[columnCount];
/* 824 */       System.arraycopy(this.texts, 0, newTexts, 0, this.texts.length);
/* 825 */       this.texts = newTexts;
/*     */     }
/* 827 */     this.texts[index] = text;
/* 828 */     if (this.tableItem != null) this.tableItem.setText(index, text);
/*     */   }
/*     */   
/*     */   public void setText(String string) {
/* 832 */     setText(0, string);
/*     */   }
/*     */   
/*     */   void setVisible(boolean show) {
/* 836 */     if (this.parentItem == null) return;
/* 837 */     if (getVisible() == show) { return;
/*     */     }
/* 839 */     if (show) {
/* 840 */       if (!this.parentItem.getVisible()) { return;
/*     */       }
/* 842 */       Table table = this.parent.getTable();
/* 843 */       int parentIndex = table.indexOf(this.parentItem.tableItem);
/* 844 */       int index = this.parentItem.expandedIndexOf(this) + parentIndex + 1;
/* 845 */       if (index < 0) return;
/* 846 */       this.tableItem = new TableItem(table, getStyle(), index);
/* 847 */       this.tableItem.setData("TableTreeItemID", this);
/* 848 */       this.tableItem.setImageIndent(getIndent());
/* 849 */       if (this.background != null) this.tableItem.setBackground(this.background);
/* 850 */       if (this.foreground != null) this.tableItem.setForeground(this.foreground);
/* 851 */       if (this.font != null) this.tableItem.setFont(this.font);
/* 852 */       addCheck();
/*     */       
/*     */ 
/*     */ 
/* 856 */       int columnCount = Math.max(table.getColumnCount(), 1);
/* 857 */       for (int i = 0; i < columnCount; i++) {
/* 858 */         if ((i < this.texts.length) && (this.texts[i] != null)) setText(i, this.texts[i]);
/* 859 */         if ((i < this.images.length) && (this.images[i] != null)) { setImage(i, this.images[i]);
/*     */         }
/*     */       }
/*     */       
/* 863 */       if (this.items.length != 0) {
/* 864 */         if (this.expanded) {
/* 865 */           this.tableItem.setImage(0, this.parent.getMinusImage());
/* 866 */           int i = 0; for (int length = this.items.length; i < length; i++) {
/* 867 */             this.items[i].setVisible(true);
/*     */           }
/*     */         } else {
/* 870 */           this.tableItem.setImage(0, this.parent.getPlusImage());
/*     */         }
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 876 */       int i = 0; for (int length = this.items.length; i < length; i++) {
/* 877 */         this.items[i].setVisible(false);
/*     */       }
/*     */       
/* 880 */       this.tableItem.dispose();
/* 881 */       this.tableItem = null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/custom/TableTreeItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */