/*     */ package org.eclipse.swt.custom;
/*     */ 
/*     */ import org.eclipse.swt.graphics.Point;
/*     */ import org.eclipse.swt.graphics.Rectangle;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.swt.widgets.Control;
/*     */ import org.eclipse.swt.widgets.Layout;
/*     */ import org.eclipse.swt.widgets.Scrollable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ViewFormLayout
/*     */   extends Layout
/*     */ {
/*     */   protected Point computeSize(Composite composite, int wHint, int hHint, boolean flushCache)
/*     */   {
/*  26 */     ViewForm form = (ViewForm)composite;
/*  27 */     Control left = form.topLeft;
/*  28 */     Control center = form.topCenter;
/*  29 */     Control right = form.topRight;
/*  30 */     Control content = form.content;
/*     */     
/*  32 */     Point leftSize = new Point(0, 0);
/*  33 */     if (left != null) {
/*  34 */       leftSize = computeChildSize(left, -1, -1, flushCache);
/*     */     }
/*  36 */     Point centerSize = new Point(0, 0);
/*  37 */     if (center != null) {
/*  38 */       centerSize = computeChildSize(center, -1, -1, flushCache);
/*     */     }
/*  40 */     Point rightSize = new Point(0, 0);
/*  41 */     if (right != null) {
/*  42 */       rightSize = computeChildSize(right, -1, -1, flushCache);
/*     */     }
/*  44 */     Point size = new Point(0, 0);
/*     */     
/*  46 */     if ((form.separateTopCenter) || ((wHint != -1) && (leftSize.x + centerSize.x + rightSize.x > wHint)))
/*     */     {
/*  48 */       leftSize.x += rightSize.x;
/*  49 */       if ((leftSize.x > 0) && (rightSize.x > 0)) size.x += form.horizontalSpacing;
/*  50 */       size.x = Math.max(centerSize.x, size.x);
/*  51 */       size.y = Math.max(leftSize.y, rightSize.y);
/*  52 */       if (center != null) {
/*  53 */         size.y += centerSize.y;
/*  54 */         if ((left != null) || (right != null)) size.y += form.verticalSpacing;
/*     */       }
/*     */     } else {
/*  57 */       size.x = (leftSize.x + centerSize.x + rightSize.x);
/*  58 */       int count = -1;
/*  59 */       if (leftSize.x > 0) count++;
/*  60 */       if (centerSize.x > 0) count++;
/*  61 */       if (rightSize.x > 0) count++;
/*  62 */       if (count > 0) size.x += count * form.horizontalSpacing;
/*  63 */       size.y = Math.max(leftSize.y, Math.max(centerSize.y, rightSize.y));
/*     */     }
/*     */     
/*  66 */     if (content != null) {
/*  67 */       if ((left != null) || (right != null) || (center != null)) size.y += 1;
/*  68 */       Point contentSize = new Point(0, 0);
/*  69 */       contentSize = computeChildSize(content, -1, -1, flushCache);
/*  70 */       size.x = Math.max(size.x, contentSize.x);
/*  71 */       size.y += contentSize.y;
/*  72 */       if (size.y > contentSize.y) { size.y += form.verticalSpacing;
/*     */       }
/*     */     }
/*  75 */     size.x += 2 * form.marginWidth;
/*  76 */     size.y += 2 * form.marginHeight;
/*     */     
/*  78 */     if (wHint != -1) size.x = wHint;
/*  79 */     if (hHint != -1) { size.y = hHint;
/*     */     }
/*  81 */     return size;
/*     */   }
/*     */   
/*     */   Point computeChildSize(Control control, int wHint, int hHint, boolean flushCache) {
/*  85 */     Object data = control.getLayoutData();
/*  86 */     if ((data == null) || (!(data instanceof CLayoutData))) {
/*  87 */       data = new CLayoutData();
/*  88 */       control.setLayoutData(data);
/*     */     }
/*  90 */     return ((CLayoutData)data).computeSize(control, wHint, hHint, flushCache);
/*     */   }
/*     */   
/*     */   int computeTrim(Control c) {
/*  94 */     if ((c instanceof Scrollable)) {
/*  95 */       Rectangle rect = ((Scrollable)c).computeTrim(0, 0, 0, 0);
/*  96 */       return rect.width;
/*     */     }
/*  98 */     return c.getBorderWidth() * 2;
/*     */   }
/*     */   
/*     */   protected boolean flushCache(Control control)
/*     */   {
/* 103 */     Object data = control.getLayoutData();
/* 104 */     if ((data != null) && ((data instanceof CLayoutData))) ((CLayoutData)data).flushCache();
/* 105 */     return true;
/*     */   }
/*     */   
/*     */   protected void layout(Composite composite, boolean flushCache)
/*     */   {
/* 110 */     ViewForm form = (ViewForm)composite;
/* 111 */     Control left = form.topLeft;
/* 112 */     Control center = form.topCenter;
/* 113 */     Control right = form.topRight;
/* 114 */     Control content = form.content;
/*     */     
/* 116 */     Rectangle rect = composite.getClientArea();
/*     */     
/* 118 */     Point leftSize = new Point(0, 0);
/* 119 */     if ((left != null) && (!left.isDisposed())) {
/* 120 */       leftSize = computeChildSize(left, -1, -1, flushCache);
/*     */     }
/* 122 */     Point centerSize = new Point(0, 0);
/* 123 */     if ((center != null) && (!center.isDisposed())) {
/* 124 */       centerSize = computeChildSize(center, -1, -1, flushCache);
/*     */     }
/* 126 */     Point rightSize = new Point(0, 0);
/* 127 */     if ((right != null) && (!right.isDisposed())) {
/* 128 */       rightSize = computeChildSize(right, -1, -1, flushCache);
/*     */     }
/*     */     
/* 131 */     int minTopWidth = leftSize.x + centerSize.x + rightSize.x + 2 * form.marginWidth + 2 * form.highlight;
/* 132 */     int count = -1;
/* 133 */     if (leftSize.x > 0) count++;
/* 134 */     if (centerSize.x > 0) count++;
/* 135 */     if (rightSize.x > 0) count++;
/* 136 */     if (count > 0) { minTopWidth += count * form.horizontalSpacing;
/*     */     }
/* 138 */     int x = rect.x + rect.width - form.marginWidth - form.highlight;
/* 139 */     int y = rect.y + form.marginHeight + form.highlight;
/*     */     
/* 141 */     boolean top = false;
/* 142 */     if ((form.separateTopCenter) || (minTopWidth > rect.width)) {
/* 143 */       int topHeight = Math.max(rightSize.y, leftSize.y);
/* 144 */       if ((right != null) && (!right.isDisposed())) {
/* 145 */         top = true;
/* 146 */         x -= rightSize.x;
/* 147 */         right.setBounds(x, y, rightSize.x, topHeight);
/* 148 */         x -= form.horizontalSpacing;
/*     */       }
/* 150 */       if ((left != null) && (!left.isDisposed())) {
/* 151 */         top = true;
/* 152 */         int trim = computeTrim(left);
/* 153 */         int leftW = x - rect.x - form.marginWidth - form.highlight - trim;
/* 154 */         leftSize = computeChildSize(left, leftW, -1, false);
/* 155 */         left.setBounds(rect.x + form.marginWidth + form.highlight, y, leftSize.x, topHeight);
/*     */       }
/* 157 */       if (top) y += topHeight + form.verticalSpacing;
/* 158 */       if ((center != null) && (!center.isDisposed())) {
/* 159 */         top = true;
/* 160 */         int trim = computeTrim(center);
/* 161 */         int w = rect.width - 2 * form.marginWidth - 2 * form.highlight - trim;
/* 162 */         Point size = computeChildSize(center, w, -1, false);
/* 163 */         if (size.x < centerSize.x) {
/* 164 */           centerSize = size;
/*     */         }
/* 166 */         center.setBounds(rect.x + rect.width - form.marginWidth - form.highlight - centerSize.x, y, centerSize.x, centerSize.y);
/* 167 */         y += centerSize.y + form.verticalSpacing;
/*     */       }
/*     */     } else {
/* 170 */       int topHeight = Math.max(rightSize.y, Math.max(centerSize.y, leftSize.y));
/* 171 */       if ((right != null) && (!right.isDisposed())) {
/* 172 */         top = true;
/* 173 */         x -= rightSize.x;
/* 174 */         right.setBounds(x, y, rightSize.x, topHeight);
/* 175 */         x -= form.horizontalSpacing;
/*     */       }
/* 177 */       if ((center != null) && (!center.isDisposed())) {
/* 178 */         top = true;
/* 179 */         x -= centerSize.x;
/* 180 */         center.setBounds(x, y, centerSize.x, topHeight);
/* 181 */         x -= form.horizontalSpacing;
/*     */       }
/* 183 */       if ((left != null) && (!left.isDisposed())) {
/* 184 */         top = true;
/* 185 */         Rectangle trim = (left instanceof Composite) ? ((Composite)left).computeTrim(0, 0, 0, 0) : new Rectangle(0, 0, 0, 0);
/* 186 */         int w = x - rect.x - form.marginWidth - form.highlight - trim.width;
/* 187 */         int h = topHeight - trim.height;
/* 188 */         leftSize = computeChildSize(left, w, h, false);
/* 189 */         left.setBounds(rect.x + form.marginWidth + form.highlight, y, leftSize.x, topHeight);
/*     */       }
/* 191 */       if (top) y += topHeight + form.verticalSpacing;
/*     */     }
/* 193 */     int oldSeperator = form.separator;
/* 194 */     form.separator = -1;
/* 195 */     if ((content != null) && (!content.isDisposed())) {
/* 196 */       if ((left != null) || (right != null) || (center != null)) {
/* 197 */         form.separator = y;
/* 198 */         y++;
/*     */       }
/* 200 */       content.setBounds(rect.x + form.marginWidth + form.highlight, y, rect.width - 2 * form.marginWidth - 2 * form.highlight, rect.y + rect.height - y - form.marginHeight - form.highlight);
/*     */     }
/* 202 */     if (oldSeperator != form.separator) { int b;
/*     */       int t;
/* 204 */       int b; if (oldSeperator == -1) {
/* 205 */         int t = form.separator;
/* 206 */         b = form.separator + 1; } else { int b;
/* 207 */         if (form.separator == -1) {
/* 208 */           int t = oldSeperator;
/* 209 */           b = oldSeperator + 1;
/*     */         } else {
/* 211 */           t = Math.min(form.separator, oldSeperator);
/* 212 */           b = Math.max(form.separator, oldSeperator);
/*     */         } }
/* 214 */       form.redraw(form.borderLeft, t, form.getSize().x - form.borderLeft - form.borderRight, b - t, false);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/custom/ViewFormLayout.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */