/*    */ package org.eclipse.swt.internal.image;
/*    */ 
/*    */ import org.eclipse.swt.SWT;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class JPEGFixedSizeSegment
/*    */   extends JPEGSegment
/*    */ {
/*    */   public JPEGFixedSizeSegment()
/*    */   {
/* 19 */     this.reference = new byte[fixedSize()];
/* 20 */     setSegmentMarker(signature());
/*    */   }
/*    */   
/*    */   public JPEGFixedSizeSegment(byte[] reference) {
/* 24 */     super(reference);
/*    */   }
/*    */   
/*    */   public JPEGFixedSizeSegment(LEDataInputStream byteStream) {
/* 28 */     this.reference = new byte[fixedSize()];
/*    */     try {
/* 30 */       byteStream.read(this.reference);
/*    */     } catch (Exception e) {
/* 32 */       SWT.error(39, e);
/*    */     }
/*    */   }
/*    */   
/*    */   public abstract int fixedSize();
/*    */   
/*    */   public int getSegmentLength()
/*    */   {
/* 40 */     return fixedSize() - 2;
/*    */   }
/*    */   
/*    */   public void setSegmentLength(int length) {}
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/internal/image/JPEGFixedSizeSegment.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */