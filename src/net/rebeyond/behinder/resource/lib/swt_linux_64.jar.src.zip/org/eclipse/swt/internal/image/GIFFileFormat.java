/*     */ package org.eclipse.swt.internal.image;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import org.eclipse.swt.SWT;
/*     */ import org.eclipse.swt.graphics.ImageData;
/*     */ import org.eclipse.swt.graphics.ImageLoader;
/*     */ import org.eclipse.swt.graphics.ImageLoaderEvent;
/*     */ import org.eclipse.swt.graphics.PaletteData;
/*     */ import org.eclipse.swt.graphics.RGB;
/*     */ 
/*     */ 
/*     */ public final class GIFFileFormat
/*     */   extends FileFormat
/*     */ {
/*     */   String signature;
/*     */   int screenWidth;
/*     */   int screenHeight;
/*     */   int backgroundPixel;
/*     */   int bitsPerPixel;
/*     */   int defaultDepth;
/*  21 */   int disposalMethod = 0;
/*  22 */   int delayTime = 0;
/*  23 */   int transparentPixel = -1;
/*  24 */   int repeatCount = 1;
/*     */   
/*     */   static final int GIF_APPLICATION_EXTENSION_BLOCK_ID = 255;
/*     */   static final int GIF_GRAPHICS_CONTROL_BLOCK_ID = 249;
/*     */   static final int GIF_PLAIN_TEXT_BLOCK_ID = 1;
/*     */   static final int GIF_COMMENT_BLOCK_ID = 254;
/*     */   static final int GIF_EXTENSION_BLOCK_ID = 33;
/*     */   static final int GIF_IMAGE_BLOCK_ID = 44;
/*     */   static final int GIF_TRAILER_ID = 59;
/*  33 */   static final byte[] GIF89a = { 71, 73, 70, 56, 57, 97 };
/*  34 */   static final byte[] NETSCAPE2_0 = { 78, 69, 84, 83, 67, 65, 80, 69, 50, 46, 48 };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   static PaletteData grayRamp(int numGrays)
/*     */   {
/*  41 */     int n = numGrays - 1;
/*  42 */     RGB[] colors = new RGB[numGrays];
/*  43 */     for (int i = 0; i < numGrays; i++) {
/*  44 */       int intensity = (byte)(i * 3 * 256 / n);
/*  45 */       colors[i] = new RGB(intensity, intensity, intensity);
/*     */     }
/*  47 */     return new PaletteData(colors);
/*     */   }
/*     */   
/*     */   boolean isFileFormat(LEDataInputStream stream)
/*     */   {
/*     */     try {
/*  53 */       byte[] signature = new byte[3];
/*  54 */       stream.read(signature);
/*  55 */       stream.unread(signature);
/*  56 */       return (signature[0] == 71) && (signature[1] == 73) && (signature[2] == 70);
/*     */     } catch (Exception e) {}
/*  58 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   ImageData[] loadFromByteStream()
/*     */   {
/*  68 */     byte[] signature = new byte[3];
/*  69 */     byte[] versionBytes = new byte[3];
/*  70 */     byte[] block = new byte[7];
/*     */     try {
/*  72 */       this.inputStream.read(signature);
/*  73 */       if ((signature[0] != 71) || (signature[1] != 73) || (signature[2] != 70)) {
/*  74 */         SWT.error(40);
/*     */       }
/*  76 */       this.inputStream.read(versionBytes);
/*     */       
/*  78 */       this.inputStream.read(block);
/*     */     } catch (IOException e) {
/*  80 */       SWT.error(39, e);
/*     */     }
/*  82 */     this.screenWidth = (block[0] & 0xFF | (block[1] & 0xFF) << 8);
/*  83 */     this.loader.logicalScreenWidth = this.screenWidth;
/*  84 */     this.screenHeight = (block[2] & 0xFF | (block[3] & 0xFF) << 8);
/*  85 */     this.loader.logicalScreenHeight = this.screenHeight;
/*  86 */     byte bitField = block[4];
/*  87 */     this.backgroundPixel = (block[5] & 0xFF);
/*     */     
/*  89 */     this.bitsPerPixel = ((bitField >> 4 & 0x7) + 1);
/*  90 */     this.defaultDepth = ((bitField & 0x7) + 1);
/*  91 */     PaletteData palette = null;
/*  92 */     if ((bitField & 0x80) != 0)
/*     */     {
/*     */ 
/*  95 */       palette = readPalette(1 << this.defaultDepth);
/*     */     }
/*     */     else
/*     */     {
/*  99 */       this.backgroundPixel = -1;
/* 100 */       this.defaultDepth = this.bitsPerPixel;
/*     */     }
/* 102 */     this.loader.backgroundPixel = this.backgroundPixel;
/*     */     
/* 104 */     ImageData[] images = new ImageData[0];
/* 105 */     int id = readID();
/* 106 */     while ((id != 59) && (id != -1)) {
/* 107 */       if (id == 44) {
/* 108 */         ImageData image = readImageBlock(palette);
/* 109 */         if (this.loader.hasListeners()) {
/* 110 */           this.loader.notifyListeners(new ImageLoaderEvent(this.loader, image, 3, true));
/*     */         }
/* 112 */         ImageData[] oldImages = images;
/* 113 */         images = new ImageData[oldImages.length + 1];
/* 114 */         System.arraycopy(oldImages, 0, images, 0, oldImages.length);
/* 115 */         images[(images.length - 1)] = image;
/* 116 */       } else if (id == 33)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 123 */         readExtension();
/*     */       }
/*     */       else
/*     */       {
/* 127 */         if (images.length > 0) break;
/* 128 */         SWT.error(40);
/*     */       }
/* 130 */       id = readID();
/* 131 */       if (id == 0) id = readID();
/*     */     }
/* 133 */     return images;
/*     */   }
/*     */   
/*     */ 
/*     */   int readID()
/*     */   {
/*     */     try
/*     */     {
/* 141 */       return this.inputStream.read();
/*     */     } catch (IOException e) {
/* 143 */       SWT.error(39, e);
/*     */     }
/* 145 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   byte[] readExtension()
/*     */   {
/* 153 */     int extensionID = readID();
/* 154 */     if (extensionID == 254)
/* 155 */       return readCommentExtension();
/* 156 */     if (extensionID == 1)
/* 157 */       return readPlainTextExtension();
/* 158 */     if (extensionID == 249)
/* 159 */       return readGraphicsControlExtension();
/* 160 */     if (extensionID == 255) {
/* 161 */       return readApplicationExtension();
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 166 */       int extSize = this.inputStream.read();
/* 167 */       if (extSize < 0) {
/* 168 */         SWT.error(40);
/*     */       }
/* 170 */       byte[] ext = new byte[extSize];
/* 171 */       this.inputStream.read(ext, 0, extSize);
/* 172 */       return ext;
/*     */     } catch (IOException e) {
/* 174 */       SWT.error(39, e); }
/* 175 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   byte[] readCommentExtension()
/*     */   {
/*     */     try
/*     */     {
/* 186 */       byte[] comment = new byte[0];
/* 187 */       byte[] block = new byte['ÿ'];
/* 188 */       int size = this.inputStream.read();
/* 189 */       while ((size > 0) && (this.inputStream.read(block, 0, size) != -1)) {
/* 190 */         byte[] oldComment = comment;
/* 191 */         comment = new byte[oldComment.length + size];
/* 192 */         System.arraycopy(oldComment, 0, comment, 0, oldComment.length);
/* 193 */         System.arraycopy(block, 0, comment, oldComment.length, size);
/* 194 */         size = this.inputStream.read();
/*     */       }
/* 196 */       return comment;
/*     */     } catch (Exception e) {
/* 198 */       SWT.error(39, e); }
/* 199 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   byte[] readPlainTextExtension()
/*     */   {
/*     */     try
/*     */     {
/* 211 */       this.inputStream.read();
/*     */       
/* 213 */       byte[] info = new byte[12];
/* 214 */       this.inputStream.read(info);
/*     */       
/* 216 */       byte[] text = new byte[0];
/* 217 */       byte[] block = new byte['ÿ'];
/* 218 */       int size = this.inputStream.read();
/* 219 */       while ((size > 0) && (this.inputStream.read(block, 0, size) != -1)) {
/* 220 */         byte[] oldText = text;
/* 221 */         text = new byte[oldText.length + size];
/* 222 */         System.arraycopy(oldText, 0, text, 0, oldText.length);
/* 223 */         System.arraycopy(block, 0, text, oldText.length, size);
/* 224 */         size = this.inputStream.read();
/*     */       }
/* 226 */       return text;
/*     */     } catch (Exception e) {
/* 228 */       SWT.error(39, e); }
/* 229 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   byte[] readGraphicsControlExtension()
/*     */   {
/*     */     try
/*     */     {
/* 241 */       this.inputStream.read();
/*     */       
/* 243 */       byte[] controlBlock = new byte[4];
/* 244 */       this.inputStream.read(controlBlock);
/* 245 */       byte bitField = controlBlock[0];
/*     */       
/*     */ 
/*     */ 
/* 249 */       this.disposalMethod = (bitField >> 2 & 0x7);
/*     */       
/* 251 */       this.delayTime = (controlBlock[1] & 0xFF | (controlBlock[2] & 0xFF) << 8);
/*     */       
/* 253 */       if ((bitField & 0x1) != 0) {
/* 254 */         this.transparentPixel = (controlBlock[3] & 0xFF);
/*     */       } else {
/* 256 */         this.transparentPixel = -1;
/*     */       }
/* 258 */       return controlBlock;
/*     */     } catch (Exception e) {
/* 260 */       SWT.error(39, e); }
/* 261 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   byte[] readApplicationExtension()
/*     */   {
/*     */     try
/*     */     {
/* 273 */       int blockSize = this.inputStream.read();
/* 274 */       byte[] blockData = new byte[blockSize];
/* 275 */       this.inputStream.read(blockData);
/*     */       
/* 277 */       byte[] data = new byte[0];
/* 278 */       byte[] block = new byte['ÿ'];
/* 279 */       int size = this.inputStream.read();
/* 280 */       while ((size > 0) && (this.inputStream.read(block, 0, size) != -1)) {
/* 281 */         byte[] oldData = data;
/* 282 */         data = new byte[oldData.length + size];
/* 283 */         System.arraycopy(oldData, 0, data, 0, oldData.length);
/* 284 */         System.arraycopy(block, 0, data, oldData.length, size);
/* 285 */         size = this.inputStream.read();
/*     */       }
/*     */       
/* 288 */       boolean netscape = (blockSize > 7) && (blockData[0] == 78) && (blockData[1] == 69) && (blockData[2] == 84) && (blockData[3] == 83) && (blockData[4] == 67) && (blockData[5] == 65) && (blockData[6] == 80) && (blockData[7] == 69);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 298 */       boolean authentic = (blockSize > 10) && (blockData[8] == 50) && (blockData[9] == 46) && (blockData[10] == 48);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 303 */       if ((netscape) && (authentic) && (data[0] == 1)) {
/* 304 */         this.repeatCount = (data[1] & 0xFF | (data[2] & 0xFF) << 8);
/* 305 */         this.loader.repeatCount = this.repeatCount;
/*     */       }
/* 307 */       return data;
/*     */     } catch (Exception e) {
/* 309 */       SWT.error(39, e); }
/* 310 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   ImageData readImageBlock(PaletteData defaultPalette)
/*     */   {
/* 322 */     byte[] block = new byte[9];
/*     */     try {
/* 324 */       this.inputStream.read(block);
/*     */     } catch (IOException e) {
/* 326 */       SWT.error(39, e);
/*     */     }
/* 328 */     int left = block[0] & 0xFF | (block[1] & 0xFF) << 8;
/* 329 */     int top = block[2] & 0xFF | (block[3] & 0xFF) << 8;
/* 330 */     int width = block[4] & 0xFF | (block[5] & 0xFF) << 8;
/* 331 */     int height = block[6] & 0xFF | (block[7] & 0xFF) << 8;
/* 332 */     byte bitField = block[8];
/* 333 */     boolean interlaced = (bitField & 0x40) != 0;
/*     */     PaletteData palette;
/* 335 */     int depth; PaletteData palette; if ((bitField & 0x80) != 0)
/*     */     {
/* 337 */       int depth = (bitField & 0x7) + 1;
/* 338 */       palette = readPalette(1 << depth);
/*     */     }
/*     */     else {
/* 341 */       depth = this.defaultDepth;
/* 342 */       palette = defaultPalette;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 347 */     if (this.transparentPixel > 1 << depth) {
/* 348 */       this.transparentPixel = -1;
/*     */     }
/*     */     
/* 351 */     if ((depth != 1) && (depth != 4) && (depth != 8)) {
/* 352 */       if (depth < 4) {
/* 353 */         depth = 4;
/*     */       } else
/* 355 */         depth = 8;
/*     */     }
/* 357 */     if (palette == null) {
/* 358 */       palette = grayRamp(1 << depth);
/*     */     }
/* 360 */     int initialCodeSize = -1;
/*     */     try {
/* 362 */       initialCodeSize = this.inputStream.read();
/*     */     } catch (IOException e) {
/* 364 */       SWT.error(39, e);
/*     */     }
/* 366 */     if (initialCodeSize < 0) {
/* 367 */       SWT.error(40);
/*     */     }
/* 369 */     ImageData image = ImageData.internal_new(width, height, depth, palette, 4, null, 0, null, null, -1, this.transparentPixel, 2, left, top, this.disposalMethod, this.delayTime);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 386 */     LZWCodec codec = new LZWCodec();
/* 387 */     codec.decode(this.inputStream, this.loader, image, interlaced, initialCodeSize);
/* 388 */     return image;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   PaletteData readPalette(int numColors)
/*     */   {
/* 395 */     byte[] bytes = new byte[numColors * 3];
/*     */     try {
/* 397 */       if (this.inputStream.read(bytes) != bytes.length)
/* 398 */         SWT.error(40);
/*     */     } catch (IOException e) {
/* 400 */       SWT.error(39, e);
/*     */     }
/* 402 */     RGB[] colors = new RGB[numColors];
/* 403 */     for (int i = 0; i < numColors; i++) {
/* 404 */       colors[i] = new RGB(bytes[(i * 3)] & 0xFF, bytes[(i * 3 + 1)] & 0xFF, bytes[(i * 3 + 2)] & 0xFF);
/*     */     }
/* 406 */     return new PaletteData(colors);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   void unloadIntoByteStream(ImageLoader loader)
/*     */   {
/* 413 */     ImageData[] data = loader.data;
/* 414 */     int frameCount = data.length;
/* 415 */     boolean multi = frameCount > 1;
/* 416 */     ImageData firstImage = data[0];
/* 417 */     int logicalScreenWidth = multi ? loader.logicalScreenWidth : firstImage.width;
/* 418 */     int logicalScreenHeight = multi ? loader.logicalScreenHeight : firstImage.height;
/* 419 */     int backgroundPixel = loader.backgroundPixel;
/* 420 */     int depth = firstImage.depth;
/* 421 */     PaletteData palette = firstImage.palette;
/* 422 */     RGB[] colors = palette.getRGBs();
/* 423 */     short globalTable = 1;
/*     */     
/*     */ 
/* 426 */     if ((depth != 1) && (depth != 4) && (depth != 8)) {
/* 427 */       SWT.error(38);
/*     */     }
/* 429 */     for (int i = 0; i < frameCount; i++) {
/* 430 */       if (data[i].palette.isDirect) {
/* 431 */         SWT.error(40);
/*     */       }
/* 433 */       if (multi) {
/* 434 */         if ((data[i].height > logicalScreenHeight) || (data[i].width > logicalScreenWidth) || (data[i].depth != depth)) {
/* 435 */           SWT.error(40);
/*     */         }
/* 437 */         if (globalTable == 1) {
/* 438 */           RGB[] rgbs = data[i].palette.getRGBs();
/* 439 */           if (rgbs.length != colors.length) {
/* 440 */             globalTable = 0;
/*     */           } else {
/* 442 */             for (int j = 0; j < colors.length; j++) {
/* 443 */               if ((rgbs[j].red != colors[j].red) || (rgbs[j].green != colors[j].green) || (rgbs[j].blue != colors[j].blue))
/*     */               {
/*     */ 
/* 446 */                 globalTable = 0;
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     try
/*     */     {
/* 455 */       this.outputStream.write(GIF89a);
/* 456 */       int bitField = globalTable * 128 + (depth - 1) * 16 + depth - 1;
/* 457 */       this.outputStream.writeShort((short)logicalScreenWidth);
/* 458 */       this.outputStream.writeShort((short)logicalScreenHeight);
/* 459 */       this.outputStream.write(bitField);
/* 460 */       this.outputStream.write(backgroundPixel);
/* 461 */       this.outputStream.write(0);
/*     */     } catch (IOException e) {
/* 463 */       SWT.error(39, e);
/*     */     }
/*     */     
/*     */ 
/* 467 */     if (globalTable == 1) {
/* 468 */       writePalette(palette, depth);
/*     */     }
/*     */     
/*     */ 
/* 472 */     if (multi) {
/* 473 */       int repeatCount = loader.repeatCount;
/*     */       try {
/* 475 */         this.outputStream.write(33);
/* 476 */         this.outputStream.write(255);
/* 477 */         this.outputStream.write(NETSCAPE2_0.length);
/* 478 */         this.outputStream.write(NETSCAPE2_0);
/* 479 */         this.outputStream.write(3);
/* 480 */         this.outputStream.write(1);
/* 481 */         this.outputStream.writeShort((short)repeatCount);
/* 482 */         this.outputStream.write(0);
/*     */       } catch (IOException e) {
/* 484 */         SWT.error(39, e);
/*     */       }
/*     */     }
/*     */     
/* 488 */     for (int frame = 0; frame < frameCount; frame++)
/*     */     {
/*     */ 
/* 491 */       if ((multi) || (data[frame].transparentPixel != -1)) {
/* 492 */         writeGraphicsControlBlock(data[frame]);
/*     */       }
/*     */       
/*     */ 
/* 496 */       int x = data[frame].x;
/* 497 */       int y = data[frame].y;
/* 498 */       int width = data[frame].width;
/* 499 */       int height = data[frame].height;
/*     */       try {
/* 501 */         this.outputStream.write(44);
/* 502 */         byte[] block = new byte[9];
/* 503 */         block[0] = ((byte)(x & 0xFF));
/* 504 */         block[1] = ((byte)(x >> 8 & 0xFF));
/* 505 */         block[2] = ((byte)(y & 0xFF));
/* 506 */         block[3] = ((byte)(y >> 8 & 0xFF));
/* 507 */         block[4] = ((byte)(width & 0xFF));
/* 508 */         block[5] = ((byte)(width >> 8 & 0xFF));
/* 509 */         block[6] = ((byte)(height & 0xFF));
/* 510 */         block[7] = ((byte)(height >> 8 & 0xFF));
/* 511 */         block[8] = ((byte)(globalTable == 0 ? depth - 1 | 0x80 : 0));
/* 512 */         this.outputStream.write(block);
/*     */       } catch (IOException e) {
/* 514 */         SWT.error(39, e);
/*     */       }
/*     */       
/*     */ 
/* 518 */       if (globalTable == 0) {
/* 519 */         writePalette(data[frame].palette, depth);
/*     */       }
/*     */       
/*     */       try
/*     */       {
/* 524 */         this.outputStream.write(depth);
/*     */       } catch (IOException e) {
/* 526 */         SWT.error(39, e);
/*     */       }
/* 528 */       new LZWCodec().encode(this.outputStream, data[frame]);
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 533 */       this.outputStream.write(59);
/*     */     } catch (IOException e) {
/* 535 */       SWT.error(39, e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   void writeGraphicsControlBlock(ImageData image)
/*     */   {
/*     */     try
/*     */     {
/* 545 */       this.outputStream.write(33);
/* 546 */       this.outputStream.write(249);
/* 547 */       byte[] gcBlock = new byte[4];
/* 548 */       gcBlock[0] = 0;
/* 549 */       gcBlock[1] = 0;
/* 550 */       gcBlock[2] = 0;
/* 551 */       gcBlock[3] = 0;
/* 552 */       if (image.transparentPixel != -1) {
/* 553 */         gcBlock[0] = 1;
/* 554 */         gcBlock[3] = ((byte)image.transparentPixel);
/*     */       }
/* 556 */       if (image.disposalMethod != 0) {
/* 557 */         int tmp68_67 = 0; byte[] tmp68_66 = gcBlock;tmp68_66[tmp68_67] = ((byte)(tmp68_66[tmp68_67] | (byte)((image.disposalMethod & 0x7) << 2)));
/*     */       }
/* 559 */       if (image.delayTime != 0) {
/* 560 */         gcBlock[1] = ((byte)(image.delayTime & 0xFF));
/* 561 */         gcBlock[2] = ((byte)(image.delayTime >> 8 & 0xFF));
/*     */       }
/* 563 */       this.outputStream.write((byte)gcBlock.length);
/* 564 */       this.outputStream.write(gcBlock);
/* 565 */       this.outputStream.write(0);
/*     */     } catch (IOException e) {
/* 567 */       SWT.error(39, e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   void writePalette(PaletteData palette, int depth)
/*     */   {
/* 575 */     byte[] bytes = new byte[(1 << depth) * 3];
/* 576 */     int offset = 0;
/* 577 */     for (int i = 0; i < palette.colors.length; i++) {
/* 578 */       RGB color = palette.colors[i];
/* 579 */       bytes[offset] = ((byte)color.red);
/* 580 */       bytes[(offset + 1)] = ((byte)color.green);
/* 581 */       bytes[(offset + 2)] = ((byte)color.blue);
/* 582 */       offset += 3;
/*     */     }
/*     */     try {
/* 585 */       this.outputStream.write(bytes);
/*     */     } catch (IOException e) {
/* 587 */       SWT.error(39, e);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/internal/image/GIFFileFormat.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */