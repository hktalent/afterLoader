/*     */ package org.eclipse.swt.dnd;
/*     */ 
/*     */ import org.eclipse.swt.SWT;
/*     */ import org.eclipse.swt.graphics.Image;
/*     */ import org.eclipse.swt.internal.cairo.Cairo;
/*     */ import org.eclipse.swt.internal.gtk.GDK;
/*     */ import org.eclipse.swt.internal.gtk.GTK;
/*     */ import org.eclipse.swt.internal.gtk.GdkRectangle;
/*     */ import org.eclipse.swt.internal.gtk.OS;
/*     */ import org.eclipse.swt.widgets.Display;
/*     */ import org.eclipse.swt.widgets.Table;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TableDragSourceEffect
/*     */   extends DragSourceEffect
/*     */ {
/*  38 */   Image dragSourceImage = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TableDragSourceEffect(Table table)
/*     */   {
/*  47 */     super(table);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void dragFinished(DragSourceEvent event)
/*     */   {
/*  61 */     if (this.dragSourceImage != null) this.dragSourceImage.dispose();
/*  62 */     this.dragSourceImage = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void dragStart(DragSourceEvent event)
/*     */   {
/*  78 */     event.image = getDragSourceImage(event);
/*     */   }
/*     */   
/*     */   Image getDragSourceImage(DragSourceEvent event) {
/*  82 */     if (this.dragSourceImage != null) this.dragSourceImage.dispose();
/*  83 */     this.dragSourceImage = null;
/*     */     
/*  85 */     Table table = (Table)this.control;
/*     */     
/*  87 */     if ((table.isListening(40)) || (table.isListening(42))) { return null;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  94 */     long handle = table.handle;
/*  95 */     long selection = GTK.gtk_tree_view_get_selection(handle);
/*  96 */     long[] model = null;
/*  97 */     long list = GTK.gtk_tree_selection_get_selected_rows(selection, model);
/*  98 */     if (list == 0L) return null;
/*  99 */     int count = Math.min(10, OS.g_list_length(list));
/* 100 */     long originalList = list;
/*     */     
/* 102 */     Display display = table.getDisplay();
/* 103 */     if (count == 1) {
/* 104 */       long path = OS.g_list_nth_data(list, 0);
/* 105 */       long icon = GTK.gtk_tree_view_create_row_drag_icon(handle, path);
/* 106 */       this.dragSourceImage = Image.gtk_new(display, 1, icon, 0L);
/* 107 */       GTK.gtk_tree_path_free(path);
/*     */     } else {
/* 109 */       int width = 0;int height = 0;
/* 110 */       int[] w = new int[1];int[] h = new int[1];
/* 111 */       int[] yy = new int[count];int[] hh = new int[count];
/* 112 */       long[] icons = new long[count];
/* 113 */       GdkRectangle rect = new GdkRectangle();
/* 114 */       for (int i = 0; i < count; i++) {
/* 115 */         long path = OS.g_list_data(list);
/* 116 */         GTK.gtk_tree_view_get_cell_area(handle, path, 0L, rect);
/* 117 */         icons[i] = GTK.gtk_tree_view_create_row_drag_icon(handle, path);
/* 118 */         if (GTK.GTK3) {
/* 119 */           switch (Cairo.cairo_surface_get_type(icons[i])) {
/*     */           case 0: 
/* 121 */             w[0] = Cairo.cairo_image_surface_get_width(icons[i]);
/* 122 */             h[0] = Cairo.cairo_image_surface_get_height(icons[i]);
/* 123 */             break;
/*     */           case 3: 
/* 125 */             w[0] = Cairo.cairo_xlib_surface_get_width(icons[i]);
/* 126 */             h[0] = Cairo.cairo_xlib_surface_get_height(icons[i]);
/*     */           }
/*     */           
/*     */         } else {
/* 130 */           GDK.gdk_pixmap_get_size(icons[i], w, h);
/*     */         }
/* 132 */         width = Math.max(width, w[0]);
/* 133 */         height = rect.y + h[0] - yy[0];
/* 134 */         yy[i] = rect.y;
/* 135 */         hh[i] = h[0];
/* 136 */         list = OS.g_list_next(list);
/* 137 */         GTK.gtk_tree_path_free(path); }
/*     */       long cairo;
/*     */       long surface;
/*     */       long cairo;
/* 141 */       if (GTK.GTK3) {
/* 142 */         long surface = Cairo.cairo_image_surface_create(0, width, height);
/* 143 */         if (surface == 0L) SWT.error(2);
/* 144 */         cairo = Cairo.cairo_create(surface);
/*     */       } else {
/* 146 */         surface = GDK.gdk_pixmap_new(GDK.gdk_get_default_root_window(), width, height, -1);
/* 147 */         if (surface == 0L) SWT.error(2);
/* 148 */         cairo = GDK.gdk_cairo_create(surface);
/*     */       }
/* 150 */       if (cairo == 0L) SWT.error(2);
/* 151 */       Cairo.cairo_set_operator(cairo, 1);
/* 152 */       for (int i = 0; i < count; i++) {
/* 153 */         if (GTK.GTK3) {
/* 154 */           Cairo.cairo_set_source_surface(cairo, icons[i], 2.0D, yy[i] - yy[0] + 2);
/*     */         } else {
/* 156 */           GDK.gdk_cairo_set_source_pixmap(cairo, icons[i], 0.0D, yy[i] - yy[0]);
/*     */         }
/* 158 */         Cairo.cairo_rectangle(cairo, 0.0D, yy[i] - yy[0], width, hh[i]);
/* 159 */         Cairo.cairo_fill(cairo);
/* 160 */         if (GTK.GTK3) {
/* 161 */           Cairo.cairo_surface_destroy(icons[i]);
/*     */         }
/*     */       }
/* 164 */       Cairo.cairo_destroy(cairo);
/* 165 */       if (GTK.GTK3) {
/* 166 */         this.dragSourceImage = Image.gtk_new(display, 1, surface, 0L);
/*     */       } else {
/* 168 */         long pixbuf = GDK.gdk_pixbuf_new(0, true, 8, width, height);
/* 169 */         if (pixbuf == 0L) SWT.error(2);
/* 170 */         long colormap = GDK.gdk_colormap_get_system();
/* 171 */         GDK.gdk_pixbuf_get_from_drawable(pixbuf, surface, colormap, 0, 0, 0, 0, width, height);
/* 172 */         this.dragSourceImage = Image.gtk_new_from_pixbuf(display, 1, pixbuf);
/*     */       }
/*     */     }
/* 175 */     OS.g_list_free(originalList);
/* 176 */     return this.dragSourceImage;
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/dnd/TableDragSourceEffect.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */