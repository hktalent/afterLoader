package org.eclipse.swt.internal.gtk;

public class GdkImage
{
  public int type;
  public long visual;
  public int byte_order;
  public int width;
  public int height;
  public short depth;
  public short bpp;
  public short bpl;
  public short bits_per_pixel;
  public long mem;
  public long colormap;
  public long windowing_data;
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/internal/gtk/GdkImage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */