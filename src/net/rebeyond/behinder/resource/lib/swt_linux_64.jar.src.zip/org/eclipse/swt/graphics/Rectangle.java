/*     */ package org.eclipse.swt.graphics;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import org.eclipse.swt.SWT;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Rectangle
/*     */   implements Serializable
/*     */ {
/*     */   public int x;
/*     */   public int y;
/*     */   public int width;
/*     */   public int height;
/*     */   static final long serialVersionUID = 3256439218279428914L;
/*     */   
/*     */   public Rectangle(int x, int y, int width, int height)
/*     */   {
/*  79 */     this.x = x;
/*  80 */     this.y = y;
/*  81 */     this.width = width;
/*  82 */     this.height = height;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void add(Rectangle rect)
/*     */   {
/* 102 */     if (rect == null) SWT.error(4);
/* 103 */     int left = this.x < rect.x ? this.x : rect.x;
/* 104 */     int top = this.y < rect.y ? this.y : rect.y;
/* 105 */     int lhs = this.x + this.width;
/* 106 */     int rhs = rect.x + rect.width;
/* 107 */     int right = lhs > rhs ? lhs : rhs;
/* 108 */     lhs = this.y + this.height;
/* 109 */     rhs = rect.y + rect.height;
/* 110 */     int bottom = lhs > rhs ? lhs : rhs;
/* 111 */     this.x = left;this.y = top;this.width = (right - left);this.height = (bottom - top);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean contains(int x, int y)
/*     */   {
/* 124 */     return (x >= this.x) && (y >= this.y) && (x < this.x + this.width) && (y < this.y + this.height);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean contains(Point pt)
/*     */   {
/* 140 */     if (pt == null) SWT.error(4);
/* 141 */     return contains(pt.x, pt.y);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object object)
/*     */   {
/* 156 */     if (object == this) return true;
/* 157 */     if (!(object instanceof Rectangle)) return false;
/* 158 */     Rectangle r = (Rectangle)object;
/* 159 */     return (r.x == this.x) && (r.y == this.y) && (r.width == this.width) && (r.height == this.height);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 174 */     return this.x ^ this.y ^ this.width ^ this.height;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void intersect(Rectangle rect)
/*     */   {
/* 191 */     if (rect == null) SWT.error(4);
/* 192 */     if (this == rect) return;
/* 193 */     int left = this.x > rect.x ? this.x : rect.x;
/* 194 */     int top = this.y > rect.y ? this.y : rect.y;
/* 195 */     int lhs = this.x + this.width;
/* 196 */     int rhs = rect.x + rect.width;
/* 197 */     int right = lhs < rhs ? lhs : rhs;
/* 198 */     lhs = this.y + this.height;
/* 199 */     rhs = rect.y + rect.height;
/* 200 */     int bottom = lhs < rhs ? lhs : rhs;
/* 201 */     this.x = (right < left ? 0 : left);
/* 202 */     this.y = (bottom < top ? 0 : top);
/* 203 */     this.width = (right < left ? 0 : right - left);
/* 204 */     this.height = (bottom < top ? 0 : bottom - top);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Rectangle intersection(Rectangle rect)
/*     */   {
/* 223 */     if (rect == null) SWT.error(4);
/* 224 */     if (this == rect) return new Rectangle(this.x, this.y, this.width, this.height);
/* 225 */     int left = this.x > rect.x ? this.x : rect.x;
/* 226 */     int top = this.y > rect.y ? this.y : rect.y;
/* 227 */     int lhs = this.x + this.width;
/* 228 */     int rhs = rect.x + rect.width;
/* 229 */     int right = lhs < rhs ? lhs : rhs;
/* 230 */     lhs = this.y + this.height;
/* 231 */     rhs = rect.y + rect.height;
/* 232 */     int bottom = lhs < rhs ? lhs : rhs;
/* 233 */     return new Rectangle(right < left ? 0 : left, bottom < top ? 0 : top, right < left ? 0 : right - left, bottom < top ? 0 : bottom - top);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean intersects(int x, int y, int width, int height)
/*     */   {
/* 265 */     return (x < this.x + this.width) && (y < this.y + this.height) && (x + width > this.x) && (y + height > this.y);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean intersects(Rectangle rect)
/*     */   {
/* 288 */     if (rect == null) SWT.error(4);
/* 289 */     return (rect == this) || (intersects(rect.x, rect.y, rect.width, rect.height));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isEmpty()
/*     */   {
/* 305 */     return (this.width <= 0) || (this.height <= 0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 316 */     return "Rectangle {" + this.x + ", " + this.y + ", " + this.width + ", " + this.height + "}";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Rectangle union(Rectangle rect)
/*     */   {
/* 338 */     if (rect == null) SWT.error(4);
/* 339 */     int left = this.x < rect.x ? this.x : rect.x;
/* 340 */     int top = this.y < rect.y ? this.y : rect.y;
/* 341 */     int lhs = this.x + this.width;
/* 342 */     int rhs = rect.x + rect.width;
/* 343 */     int right = lhs > rhs ? lhs : rhs;
/* 344 */     lhs = this.y + this.height;
/* 345 */     rhs = rect.y + rect.height;
/* 346 */     int bottom = lhs > rhs ? lhs : rhs;
/* 347 */     return new Rectangle(left, top, right - left, bottom - top);
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/graphics/Rectangle.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */