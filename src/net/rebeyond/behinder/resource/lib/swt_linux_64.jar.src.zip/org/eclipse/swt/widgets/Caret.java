/*     */ package org.eclipse.swt.widgets;
/*     */ 
/*     */ import org.eclipse.swt.graphics.Font;
/*     */ import org.eclipse.swt.graphics.Image;
/*     */ import org.eclipse.swt.graphics.Point;
/*     */ import org.eclipse.swt.graphics.Rectangle;
/*     */ import org.eclipse.swt.internal.DPIUtil;
/*     */ import org.eclipse.swt.internal.cairo.Cairo;
/*     */ import org.eclipse.swt.internal.gtk.GDK;
/*     */ import org.eclipse.swt.internal.gtk.GTK;
/*     */ import org.eclipse.swt.internal.gtk.OS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Caret
/*     */   extends Widget
/*     */ {
/*     */   Canvas parent;
/*     */   int x;
/*     */   int y;
/*     */   int width;
/*     */   int height;
/*     */   boolean isVisible;
/*     */   boolean isShowing;
/*     */   int blinkRate;
/*     */   Image image;
/*     */   Font font;
/*     */   static final int DEFAULT_WIDTH = 1;
/*     */   
/*     */   public Caret(Canvas parent, int style)
/*     */   {
/*  77 */     super(parent, style);
/*  78 */     this.parent = parent;
/*  79 */     createWidget(0);
/*     */   }
/*     */   
/*     */   boolean blinkCaret() {
/*  83 */     if (!this.isVisible) return true;
/*  84 */     if (!this.isShowing) return showCaret();
/*  85 */     if (this.blinkRate == 0) return true;
/*  86 */     return hideCaret();
/*     */   }
/*     */   
/*     */   void createWidget(int index)
/*     */   {
/*  91 */     super.createWidget(index);
/*  92 */     this.blinkRate = this.display.getCaretBlinkTime();
/*  93 */     this.isVisible = true;
/*  94 */     if (this.parent.getCaret() == null) {
/*  95 */       this.parent.setCaret(this);
/*     */     }
/*     */   }
/*     */   
/*     */   boolean drawCaret() {
/* 100 */     if (this.parent == null) return false;
/* 101 */     if (this.parent.isDisposed()) return false;
/* 102 */     if (GTK.GTK_VERSION < OS.VERSION(3, 22, 0)) {
/* 103 */       long window = this.parent.paintWindow();
/* 104 */       long cairo = GDK.gdk_cairo_create(window);
/* 105 */       if (cairo == 0L) error(2);
/* 106 */       Cairo.cairo_set_source_rgba(cairo, 1.0D, 1.0D, 1.0D, 1.0D);
/* 107 */       Cairo.cairo_set_operator(cairo, 23);
/* 108 */       if ((this.image != null) && (!this.image.isDisposed()) && (this.image.mask == 0L)) {
/* 109 */         long surface = Cairo.cairo_get_target(cairo);
/* 110 */         int nWidth = 0;
/* 111 */         switch (Cairo.cairo_surface_get_type(surface)) {
/*     */         case 0: 
/* 113 */           nWidth = Cairo.cairo_image_surface_get_width(surface);
/* 114 */           break;
/*     */         case 3: 
/* 116 */           nWidth = Cairo.cairo_xlib_surface_get_width(surface);
/*     */         }
/*     */         
/* 119 */         int nX = this.x;
/* 120 */         if ((this.parent.style & 0x8000000) != 0) nX = this.parent.getClientWidth() - nWidth - nX;
/* 121 */         Cairo.cairo_translate(cairo, nX, this.y);
/* 122 */         Cairo.cairo_set_source_surface(cairo, this.image.surface, 0.0D, 0.0D);
/* 123 */         Cairo.cairo_paint(cairo);
/*     */       } else {
/* 125 */         int nWidth = this.width;int nHeight = this.height;
/* 126 */         if (nWidth <= 0) nWidth = 1;
/* 127 */         int nX = this.x;
/* 128 */         if ((this.parent.style & 0x8000000) != 0) nX = this.parent.getClientWidth() - nWidth - nX;
/* 129 */         Cairo.cairo_rectangle(cairo, nX, this.y, nWidth, nHeight);
/*     */       }
/* 131 */       Cairo.cairo_fill(cairo);
/* 132 */       Cairo.cairo_destroy(cairo);
/* 133 */       return true;
/*     */     }
/* 135 */     GTK.gtk_widget_queue_draw(this.parent.handle);
/* 136 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Rectangle getBounds()
/*     */   {
/* 152 */     checkWidget();
/* 153 */     return DPIUtil.autoScaleDown(getBoundsInPixels());
/*     */   }
/*     */   
/*     */   Rectangle getBoundsInPixels() {
/* 157 */     checkWidget();
/* 158 */     if (this.image != null) {
/* 159 */       Rectangle rect = this.image.getBoundsInPixels();
/* 160 */       return new Rectangle(this.x, this.y, rect.width, rect.height);
/*     */     }
/* 162 */     if (this.width == 0) {
/* 163 */       return new Rectangle(this.x, this.y, 1, this.height);
/*     */     }
/*     */     
/* 166 */     return new Rectangle(this.x, this.y, this.width, this.height);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Font getFont()
/*     */   {
/* 180 */     checkWidget();
/* 181 */     if (this.font != null) return this.font;
/* 182 */     return this.parent.getFont();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Image getImage()
/*     */   {
/* 196 */     checkWidget();
/* 197 */     return this.image;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Point getLocation()
/*     */   {
/* 212 */     checkWidget();
/* 213 */     return DPIUtil.autoScaleDown(getLocationInPixels());
/*     */   }
/*     */   
/*     */   Point getLocationInPixels() {
/* 217 */     checkWidget();
/* 218 */     return new Point(this.x, this.y);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Canvas getParent()
/*     */   {
/* 232 */     checkWidget();
/* 233 */     return this.parent;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Point getSize()
/*     */   {
/* 247 */     checkWidget();
/* 248 */     return DPIUtil.autoScaleDown(getSizeInPixels());
/*     */   }
/*     */   
/*     */   Point getSizeInPixels() {
/* 252 */     checkWidget();
/* 253 */     if (this.image != null) {
/* 254 */       Rectangle rect = this.image.getBoundsInPixels();
/* 255 */       return new Point(rect.width, rect.height);
/*     */     }
/* 257 */     if (this.width == 0) {
/* 258 */       return new Point(1, this.height);
/*     */     }
/*     */     
/* 261 */     return new Point(this.width, this.height);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getVisible()
/*     */   {
/* 282 */     checkWidget();
/* 283 */     return this.isVisible;
/*     */   }
/*     */   
/*     */   boolean hideCaret() {
/* 287 */     if (!this.isShowing) return true;
/* 288 */     this.isShowing = false;
/* 289 */     return drawCaret();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isVisible()
/*     */   {
/* 307 */     checkWidget();
/* 308 */     return (this.isVisible) && (this.parent.isVisible()) && (this.parent.hasFocus());
/*     */   }
/*     */   
/*     */   boolean isFocusCaret() {
/* 312 */     return this == this.display.currentCaret;
/*     */   }
/*     */   
/*     */   void killFocus() {
/* 316 */     if (this.display.currentCaret != this) return;
/* 317 */     this.display.setCurrentCaret(null);
/* 318 */     if (this.isVisible) hideCaret();
/*     */   }
/*     */   
/*     */   void releaseParent()
/*     */   {
/* 323 */     super.releaseParent();
/* 324 */     if (this == this.parent.getCaret()) this.parent.setCaret(null);
/*     */   }
/*     */   
/*     */   void releaseWidget()
/*     */   {
/* 329 */     super.releaseWidget();
/* 330 */     if (this.display.currentCaret == this) {
/* 331 */       hideCaret();
/* 332 */       this.display.setCurrentCaret(null);
/*     */     }
/* 334 */     this.parent = null;
/* 335 */     this.image = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBounds(int x, int y, int width, int height)
/*     */   {
/* 355 */     checkWidget();
/* 356 */     setBounds(new Rectangle(x, y, width, height));
/*     */   }
/*     */   
/*     */   void setBoundsInPixels(int x, int y, int width, int height) {
/* 360 */     checkWidget();
/* 361 */     if ((this.x == x) && (this.y == y) && (this.width == width) && (this.height == height)) return;
/* 362 */     boolean isFocus = isFocusCaret();
/* 363 */     if ((isFocus) && (this.isVisible)) hideCaret();
/* 364 */     this.x = x;this.y = y;
/* 365 */     this.width = width;this.height = height;
/* 366 */     this.parent.updateCaret();
/* 367 */     if ((isFocus) && (this.isVisible)) { showCaret();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBounds(Rectangle rect)
/*     */   {
/* 384 */     checkWidget();
/* 385 */     rect = DPIUtil.autoScaleUp(rect);
/* 386 */     setBoundsInPixels(rect);
/*     */   }
/*     */   
/*     */   void setBoundsInPixels(Rectangle rect) {
/* 390 */     checkWidget();
/* 391 */     if (rect == null) error(4);
/* 392 */     setBoundsInPixels(rect.x, rect.y, rect.width, rect.height);
/*     */   }
/*     */   
/*     */   void setFocus() {
/* 396 */     if (this.display.currentCaret == this) return;
/* 397 */     this.display.setCurrentCaret(this);
/* 398 */     if (this.isVisible) { showCaret();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFont(Font font)
/*     */   {
/* 417 */     checkWidget();
/* 418 */     if ((font != null) && (font.isDisposed())) {
/* 419 */       error(5);
/*     */     }
/* 421 */     this.font = font;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setImage(Image image)
/*     */   {
/* 440 */     checkWidget();
/* 441 */     if ((image != null) && (image.isDisposed())) {
/* 442 */       error(5);
/*     */     }
/* 444 */     boolean isFocus = isFocusCaret();
/* 445 */     if ((isFocus) && (this.isVisible)) hideCaret();
/* 446 */     this.image = image;
/* 447 */     if ((isFocus) && (this.isVisible)) { showCaret();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLocation(int x, int y)
/*     */   {
/* 464 */     checkWidget();
/* 465 */     setLocation(new Point(x, y));
/*     */   }
/*     */   
/*     */   void setLocationInPixels(int x, int y) {
/* 469 */     checkWidget();
/* 470 */     setBoundsInPixels(x, y, this.width, this.height);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLocation(Point location)
/*     */   {
/* 486 */     checkWidget();
/* 487 */     setLocationInPixels(DPIUtil.autoScaleUp(location));
/*     */   }
/*     */   
/*     */   void setLocationInPixels(Point location) {
/* 491 */     checkWidget();
/* 492 */     if (location == null) error(4);
/* 493 */     setLocationInPixels(location.x, location.y);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSize(int width, int height)
/*     */   {
/* 508 */     checkWidget();
/* 509 */     setSize(new Point(width, height));
/*     */   }
/*     */   
/*     */   void setSizeInPixels(int width, int height) {
/* 513 */     checkWidget();
/* 514 */     setBoundsInPixels(this.x, this.y, width, height);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSize(Point size)
/*     */   {
/* 531 */     checkWidget();
/* 532 */     setSizeInPixels(DPIUtil.autoScaleUp(size));
/*     */   }
/*     */   
/*     */   void setSizeInPixels(Point size) {
/* 536 */     checkWidget();
/* 537 */     if (size == null) error(4);
/* 538 */     setSizeInPixels(size.x, size.y);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setVisible(boolean visible)
/*     */   {
/* 558 */     checkWidget();
/* 559 */     Canvas canvas = getParent();
/* 560 */     canvas.blink = true;
/* 561 */     canvas.drawFlag = visible;
/* 562 */     this.display.resetCaretTiming();
/* 563 */     if (visible == this.isVisible) return;
/* 564 */     this.isVisible = visible;
/* 565 */     if (!isFocusCaret()) return;
/* 566 */     if (this.isVisible) {
/* 567 */       showCaret();
/*     */     } else {
/* 569 */       hideCaret();
/*     */     }
/*     */   }
/*     */   
/*     */   boolean showCaret() {
/* 574 */     if (this.isShowing) return true;
/* 575 */     this.isShowing = true;
/* 576 */     return drawCaret();
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/widgets/Caret.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */