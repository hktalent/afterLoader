/*    */ package org.eclipse.swt.custom;
/*    */ 
/*    */ import org.eclipse.swt.events.TypedEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MovementEvent
/*    */   extends TypedEvent
/*    */ {
/*    */   public int lineOffset;
/*    */   public String lineText;
/*    */   public int offset;
/*    */   public int newOffset;
/*    */   public int movement;
/*    */   static final long serialVersionUID = 3978765487853324342L;
/*    */   
/*    */   public MovementEvent(StyledTextEvent e)
/*    */   {
/* 65 */     super(e);
/* 66 */     this.lineOffset = e.detail;
/* 67 */     this.lineText = e.text;
/* 68 */     this.movement = e.count;
/* 69 */     this.offset = e.start;
/* 70 */     this.newOffset = e.end;
/*    */   }
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/custom/MovementEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */