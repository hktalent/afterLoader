/*     */ package org.eclipse.swt.custom;
/*     */ 
/*     */ import org.eclipse.swt.graphics.GC;
/*     */ import org.eclipse.swt.graphics.Point;
/*     */ import org.eclipse.swt.graphics.Rectangle;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.swt.widgets.Control;
/*     */ import org.eclipse.swt.widgets.Layout;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class CTabFolderLayout
/*     */   extends Layout
/*     */ {
/*     */   protected Point computeSize(Composite composite, int wHint, int hHint, boolean flushCache)
/*     */   {
/*  25 */     CTabFolder folder = (CTabFolder)composite;
/*  26 */     CTabItem[] items = folder.items;
/*  27 */     CTabFolderRenderer renderer = folder.renderer;
/*     */     
/*  29 */     int tabW = 0;
/*  30 */     int selectedIndex = folder.selectedIndex;
/*  31 */     if (selectedIndex == -1) selectedIndex = 0;
/*  32 */     GC gc = new GC(folder);
/*  33 */     for (int i = 0; i < items.length; i++) {
/*  34 */       if (folder.single) {
/*  35 */         tabW = Math.max(tabW, renderer.computeSize(i, 2, gc, -1, -1).x);
/*     */       } else {
/*  37 */         int state = 0;
/*  38 */         if (i == selectedIndex) state |= 0x2;
/*  39 */         tabW += renderer.computeSize(i, state, gc, -1, -1).x;
/*     */       }
/*     */     }
/*     */     
/*  43 */     int width = 0;int wrapHeight = 0;
/*  44 */     boolean leftControl = false;boolean rightControl = false;
/*  45 */     if (wHint == -1) {
/*  46 */       for (int i = 0; i < folder.controls.length; i++) {
/*  47 */         Control control = folder.controls[i];
/*  48 */         if ((!control.isDisposed()) && (control.getVisible())) {
/*  49 */           if ((folder.controlAlignments[i] & 0x4000) != 0) {
/*  50 */             leftControl = true;
/*     */           } else {
/*  52 */             rightControl = true;
/*     */           }
/*  54 */           width += control.computeSize(-1, -1).x;
/*     */         }
/*     */       }
/*     */     } else {
/*  58 */       Point size = new Point(wHint, hHint);
/*  59 */       boolean[][] positions = new boolean[1][];
/*  60 */       Rectangle[] rects = folder.computeControlBounds(size, positions);
/*  61 */       int minY = Integer.MAX_VALUE;int maxY = 0;
/*  62 */       for (int i = 0; i < rects.length; i++) {
/*  63 */         if (positions[0][i] != 0) {
/*  64 */           minY = Math.min(minY, rects[i].y);
/*  65 */           maxY = Math.max(maxY, rects[i].y + rects[i].height);
/*  66 */           wrapHeight = maxY - minY;
/*     */         } else {
/*  68 */           if ((folder.controlAlignments[i] & 0x4000) != 0) {
/*  69 */             leftControl = true;
/*     */           } else {
/*  71 */             rightControl = true;
/*     */           }
/*  73 */           width += rects[i].width;
/*     */         }
/*     */       }
/*     */     }
/*  77 */     if (leftControl) width += 6;
/*  78 */     if (rightControl) width += 6;
/*  79 */     tabW += width;
/*     */     
/*  81 */     gc.dispose();
/*     */     
/*  83 */     int controlW = 0;
/*  84 */     int controlH = 0;
/*     */     
/*  86 */     for (int i = 0; i < items.length; i++) {
/*  87 */       Control control = items[i].control;
/*  88 */       if ((control != null) && (!control.isDisposed())) {
/*  89 */         Point size = control.computeSize(wHint, hHint, flushCache);
/*  90 */         controlW = Math.max(controlW, size.x);
/*  91 */         controlH = Math.max(controlH, size.y);
/*     */       }
/*     */     }
/*     */     
/*  95 */     int minWidth = Math.max(tabW, controlW + folder.marginWidth);
/*  96 */     int minHeight = folder.minimized ? 0 : controlH + wrapHeight;
/*  97 */     if (minWidth == 0) minWidth = 64;
/*  98 */     if (minHeight == 0) { minHeight = 64;
/*     */     }
/* 100 */     if (wHint != -1) minWidth = wHint;
/* 101 */     if (hHint != -1) { minHeight = hHint;
/*     */     }
/* 103 */     return new Point(minWidth, minHeight);
/*     */   }
/*     */   
/*     */   protected boolean flushCache(Control control) {
/* 107 */     return true;
/*     */   }
/*     */   
/*     */   protected void layout(Composite composite, boolean flushCache) {
/* 111 */     CTabFolder folder = (CTabFolder)composite;
/*     */     
/* 113 */     if (folder.selectedIndex != -1) {
/* 114 */       Control control = folder.items[folder.selectedIndex].control;
/* 115 */       if ((control != null) && (!control.isDisposed())) {
/* 116 */         control.setBounds(folder.getClientArea());
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/custom/CTabFolderLayout.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */