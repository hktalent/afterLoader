/*     */ package org.eclipse.swt.widgets;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TaskBar
/*     */   extends Widget
/*     */ {
/*     */   int itemCount;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  35 */   TaskItem[] items = new TaskItem[4];
/*     */   
/*     */   TaskBar(Display display, int style) {
/*  38 */     if (display == null) display = Display.getCurrent();
/*  39 */     if (display == null) display = Display.getDefault();
/*  40 */     if (!display.isValidThread()) {
/*  41 */       error(22);
/*     */     }
/*  43 */     this.display = display;
/*  44 */     reskinWidget();
/*     */   }
/*     */   
/*     */   void createItem(TaskItem item, int index) {
/*  48 */     if (index == -1) index = this.itemCount;
/*  49 */     if ((0 > index) || (index > this.itemCount)) error(6);
/*  50 */     if (this.itemCount == this.items.length) {
/*  51 */       TaskItem[] newItems = new TaskItem[this.items.length + 4];
/*  52 */       System.arraycopy(this.items, 0, newItems, 0, this.items.length);
/*  53 */       this.items = newItems;
/*     */     }
/*  55 */     System.arraycopy(this.items, index, this.items, index + 1, this.itemCount++ - index);
/*  56 */     this.items[index] = item;
/*     */   }
/*     */   
/*     */   void createItems() {}
/*     */   
/*     */   void destroyItem(TaskItem item)
/*     */   {
/*  63 */     int index = 0;
/*  64 */     while ((index < this.itemCount) && 
/*  65 */       (this.items[index] != item)) {
/*  66 */       index++;
/*     */     }
/*  68 */     if (index == this.itemCount) return;
/*  69 */     System.arraycopy(this.items, index + 1, this.items, index, --this.itemCount - index);
/*  70 */     this.items[this.itemCount] = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TaskItem getItem(int index)
/*     */   {
/*  89 */     checkWidget();
/*  90 */     createItems();
/*  91 */     if ((0 > index) || (index >= this.itemCount)) error(6);
/*  92 */     return this.items[index];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getItemCount()
/*     */   {
/* 106 */     checkWidget();
/* 107 */     createItems();
/* 108 */     return this.itemCount;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TaskItem getItem(Shell shell)
/*     */   {
/* 125 */     checkWidget();
/* 126 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TaskItem[] getItems()
/*     */   {
/* 146 */     checkWidget();
/* 147 */     createItems();
/* 148 */     TaskItem[] result = new TaskItem[this.itemCount];
/* 149 */     System.arraycopy(this.items, 0, result, 0, result.length);
/* 150 */     return result;
/*     */   }
/*     */   
/*     */   void releaseChildren(boolean destroy)
/*     */   {
/* 155 */     if (this.items != null) {
/* 156 */       for (int i = 0; i < this.items.length; i++) {
/* 157 */         TaskItem item = this.items[i];
/* 158 */         if ((item != null) && (!item.isDisposed())) {
/* 159 */           item.release(false);
/*     */         }
/*     */       }
/* 162 */       this.items = null;
/*     */     }
/* 164 */     super.releaseChildren(destroy);
/*     */   }
/*     */   
/*     */   void reskinChildren(int flags)
/*     */   {
/* 169 */     if (this.items != null) {
/* 170 */       for (int i = 0; i < this.items.length; i++) {
/* 171 */         TaskItem item = this.items[i];
/* 172 */         if (item != null) item.reskin(flags);
/*     */       }
/*     */     }
/* 175 */     super.reskinChildren(flags);
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/widgets/TaskBar.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */