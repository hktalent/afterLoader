/*     */ package org.eclipse.swt.dnd;
/*     */ 
/*     */ import org.eclipse.swt.graphics.Point;
/*     */ import org.eclipse.swt.internal.C;
/*     */ import org.eclipse.swt.internal.DPIUtil;
/*     */ import org.eclipse.swt.internal.gtk.GTK;
/*     */ import org.eclipse.swt.widgets.Table;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TableDropTargetEffect
/*     */   extends DropTargetEffect
/*     */ {
/*     */   static final int SCROLL_HYSTERESIS = 150;
/*     */   int scrollIndex;
/*     */   long scrollBeginTime;
/*     */   
/*     */   public TableDropTargetEffect(Table table)
/*     */   {
/*  61 */     super(table);
/*     */   }
/*     */   
/*     */   int checkEffect(int effect)
/*     */   {
/*  66 */     if ((effect & 0x1) != 0) effect = effect & 0xFFFFFFFB & 0xFFFFFFFD;
/*  67 */     if ((effect & 0x2) != 0) effect &= 0xFFFFFFFB;
/*  68 */     return effect;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void dragEnter(DropTargetEvent event)
/*     */   {
/*  87 */     this.scrollBeginTime = 0L;
/*  88 */     this.scrollIndex = -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void dragLeave(DropTargetEvent event)
/*     */   {
/* 107 */     Table table = (Table)this.control;
/* 108 */     long handle = table.handle;
/* 109 */     GTK.gtk_tree_view_set_drag_dest_row(handle, 0L, 0);
/*     */     
/* 111 */     this.scrollBeginTime = 0L;
/* 112 */     this.scrollIndex = -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void dragOver(DropTargetEvent event)
/*     */   {
/* 134 */     Table table = (Table)this.control;
/* 135 */     long handle = table.handle;
/* 136 */     int effect = checkEffect(event.feedback);
/* 137 */     Point coordinates = new Point(event.x, event.y);
/* 138 */     coordinates = DPIUtil.autoScaleUp(table.toControl(coordinates));
/* 139 */     long[] path = new long[1];
/* 140 */     GTK.gtk_tree_view_get_path_at_pos(handle, coordinates.x, coordinates.y, path, null, null, null);
/* 141 */     int index = -1;
/* 142 */     if (path[0] != 0L) {
/* 143 */       long indices = GTK.gtk_tree_path_get_indices(path[0]);
/* 144 */       if (indices != 0L) {
/* 145 */         int[] temp = new int[1];
/* 146 */         C.memmove(temp, indices, 4L);
/* 147 */         index = temp[0];
/*     */       }
/*     */     }
/* 150 */     if ((effect & 0x8) == 0) {
/* 151 */       this.scrollBeginTime = 0L;
/* 152 */       this.scrollIndex = -1;
/*     */     }
/* 154 */     else if ((index != -1) && (this.scrollIndex == index) && (this.scrollBeginTime != 0L)) {
/* 155 */       if (System.currentTimeMillis() >= this.scrollBeginTime) {
/* 156 */         if (coordinates.y < DPIUtil.autoScaleUp(table.getItemHeight())) {
/* 157 */           GTK.gtk_tree_path_prev(path[0]);
/*     */         } else {
/* 159 */           GTK.gtk_tree_path_next(path[0]);
/*     */         }
/* 161 */         if (path[0] != 0L) {
/* 162 */           GTK.gtk_tree_view_scroll_to_cell(handle, path[0], 0L, false, 0.0F, 0.0F);
/* 163 */           GTK.gtk_tree_path_free(path[0]);
/* 164 */           path[0] = 0L;
/* 165 */           GTK.gtk_tree_view_get_path_at_pos(handle, coordinates.x, coordinates.y, path, null, null, null);
/*     */         }
/* 167 */         this.scrollBeginTime = 0L;
/* 168 */         this.scrollIndex = -1;
/*     */       }
/*     */     } else {
/* 171 */       this.scrollBeginTime = (System.currentTimeMillis() + 150L);
/* 172 */       this.scrollIndex = index;
/*     */     }
/*     */     
/* 175 */     if (path[0] != 0L) {
/* 176 */       int position = -1;
/* 177 */       if ((effect & 0x1) != 0) position = 2;
/* 178 */       if ((effect & 0x2) != 0) position = 0;
/* 179 */       if ((effect & 0x4) != 0) position = 1;
/* 180 */       if (position != -1) {
/* 181 */         GTK.gtk_tree_view_set_drag_dest_row(handle, path[0], position);
/*     */       } else {
/* 183 */         GTK.gtk_tree_view_set_drag_dest_row(handle, 0L, 0);
/*     */       }
/*     */     } else {
/* 186 */       GTK.gtk_tree_view_set_drag_dest_row(handle, 0L, 0);
/*     */     }
/* 188 */     if (path[0] != 0L) GTK.gtk_tree_path_free(path[0]);
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/dnd/TableDropTargetEffect.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */