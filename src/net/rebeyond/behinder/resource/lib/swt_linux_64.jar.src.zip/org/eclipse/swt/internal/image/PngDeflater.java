/*     */ package org.eclipse.swt.internal.image;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PngDeflater
/*     */ {
/*     */   static final int BASE = 65521;
/*     */   static final int WINDOW = 32768;
/*     */   static final int MIN_LENGTH = 3;
/*     */   static final int MAX_MATCHES = 32;
/*     */   static final int HASH = 8209;
/*     */   byte[] in;
/*     */   int inLength;
/*  26 */   ByteArrayOutputStream bytes = new ByteArrayOutputStream(1024);
/*     */   
/*  28 */   int adler32 = 1;
/*     */   
/*     */   int buffer;
/*     */   int bitCount;
/*  32 */   Link[] hashtable = new Link['‑'];
/*  33 */   Link[] window = new Link[32768];
/*     */   int nextWindow;
/*     */   
/*     */   static class Link {
/*     */     int hash;
/*     */     int value;
/*     */     Link previous;
/*     */     Link next;
/*     */     
/*     */     Link() {
/*  43 */       this.hash = 0;
/*  44 */       this.value = 0;
/*  45 */       this.previous = null;
/*  46 */       this.next = null;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   static class Match
/*     */   {
/*     */     int length;
/*     */     int distance;
/*     */     
/*     */     Match(int length, int distance)
/*     */     {
/*  58 */       this.length = length;
/*  59 */       this.distance = distance;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*  65 */   static final short[] mirrorBytes = { 0, 128, 64, 192, 32, 160, 96, 224, 16, 144, 80, 208, 48, 176, 112, 240, 8, 136, 72, 200, 40, 168, 104, 232, 24, 152, 88, 216, 56, 184, 120, 248, 4, 132, 68, 196, 36, 164, 100, 228, 20, 148, 84, 212, 52, 180, 116, 244, 12, 140, 76, 204, 44, 172, 108, 236, 28, 156, 92, 220, 60, 188, 124, 252, 2, 130, 66, 194, 34, 162, 98, 226, 18, 146, 82, 210, 50, 178, 114, 242, 10, 138, 74, 202, 42, 170, 106, 234, 26, 154, 90, 218, 58, 186, 122, 250, 6, 134, 70, 198, 38, 166, 102, 230, 22, 150, 86, 214, 54, 182, 118, 246, 14, 142, 78, 206, 46, 174, 110, 238, 30, 158, 94, 222, 62, 190, 126, 254, 1, 129, 65, 193, 33, 161, 97, 225, 17, 145, 81, 209, 49, 177, 113, 241, 9, 137, 73, 201, 41, 169, 105, 233, 25, 153, 89, 217, 57, 185, 121, 249, 5, 133, 69, 197, 37, 165, 101, 229, 21, 149, 85, 213, 53, 181, 117, 245, 13, 141, 77, 205, 45, 173, 109, 237, 29, 157, 93, 221, 61, 189, 125, 253, 3, 131, 67, 195, 35, 163, 99, 227, 19, 147, 83, 211, 51, 179, 115, 243, 11, 139, 75, 203, 43, 171, 107, 235, 27, 155, 91, 219, 59, 187, 123, 251, 7, 135, 71, 199, 39, 167, 103, 231, 23, 151, 87, 215, 55, 183, 119, 247, 15, 143, 79, 207, 47, 175, 111, 239, 31, 159, 95, 223, 63, 191, 127, 255 };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static class Code
/*     */   {
/*     */     int code;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     int extraBits;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     int min;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     int max;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     Code(int code, int extraBits, int min, int max)
/*     */     {
/* 108 */       this.code = code;
/* 109 */       this.extraBits = extraBits;
/* 110 */       this.min = min;
/* 111 */       this.max = max;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/* 117 */   static final Code[] lengthCodes = { new Code(257, 0, 3, 3), new Code(258, 0, 4, 4), new Code(259, 0, 5, 5), new Code(260, 0, 6, 6), new Code(261, 0, 7, 7), new Code(262, 0, 8, 8), new Code(263, 0, 9, 9), new Code(264, 0, 10, 10), new Code(265, 1, 11, 12), new Code(266, 1, 13, 14), new Code(267, 1, 15, 16), new Code(268, 1, 17, 18), new Code(269, 2, 19, 22), new Code(270, 2, 23, 26), new Code(271, 2, 27, 30), new Code(272, 2, 31, 34), new Code(273, 3, 35, 42), new Code(274, 3, 43, 50), new Code(275, 3, 51, 58), new Code(276, 3, 59, 66), new Code(277, 4, 67, 82), new Code(278, 4, 83, 98), new Code(279, 4, 99, 114), new Code(280, 4, 115, 130), new Code(281, 5, 131, 162), new Code(282, 5, 163, 194), new Code(283, 5, 195, 226), new Code(284, 5, 227, 257), new Code(285, 0, 258, 258) };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 151 */   static final Code[] distanceCodes = { new Code(0, 0, 1, 1), new Code(1, 0, 2, 2), new Code(2, 0, 3, 3), new Code(3, 0, 4, 4), new Code(4, 1, 5, 6), new Code(5, 1, 7, 8), new Code(6, 2, 9, 12), new Code(7, 2, 13, 16), new Code(8, 3, 17, 24), new Code(9, 3, 25, 32), new Code(10, 4, 33, 48), new Code(11, 4, 49, 64), new Code(12, 5, 65, 96), new Code(13, 5, 97, 128), new Code(14, 6, 129, 192), new Code(15, 6, 193, 256), new Code(16, 7, 257, 384), new Code(17, 7, 385, 512), new Code(18, 8, 513, 768), new Code(19, 8, 769, 1024), new Code(20, 9, 1025, 1536), new Code(21, 9, 1537, 2048), new Code(22, 10, 2049, 3072), new Code(23, 10, 3073, 4096), new Code(24, 11, 4097, 6144), new Code(25, 11, 6145, 8192), new Code(26, 12, 8193, 12288), new Code(27, 12, 12289, 16384), new Code(28, 13, 16385, 24576), new Code(29, 13, 24577, 32768) };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void writeShortLSB(ByteArrayOutputStream baos, int theShort)
/*     */   {
/* 188 */     byte byte1 = (byte)(theShort & 0xFF);
/* 189 */     byte byte2 = (byte)(theShort >> 8 & 0xFF);
/* 190 */     byte[] temp = { byte1, byte2 };
/* 191 */     baos.write(temp, 0, 2);
/*     */   }
/*     */   
/*     */ 
/*     */   void writeInt(ByteArrayOutputStream baos, int theInt)
/*     */   {
/* 197 */     byte byte1 = (byte)(theInt >> 24 & 0xFF);
/* 198 */     byte byte2 = (byte)(theInt >> 16 & 0xFF);
/* 199 */     byte byte3 = (byte)(theInt >> 8 & 0xFF);
/* 200 */     byte byte4 = (byte)(theInt & 0xFF);
/* 201 */     byte[] temp = { byte1, byte2, byte3, byte4 };
/* 202 */     baos.write(temp, 0, 4);
/*     */   }
/*     */   
/*     */ 
/*     */   void updateAdler(byte value)
/*     */   {
/* 208 */     int low = this.adler32 & 0xFFFF;
/* 209 */     int high = this.adler32 >> 16 & 0xFFFF;
/* 210 */     int valueInt = value & 0xFF;
/* 211 */     low = (low + valueInt) % 65521;
/* 212 */     high = (low + high) % 65521;
/* 213 */     this.adler32 = (high << 16 | low);
/*     */   }
/*     */   
/*     */ 
/*     */   int hash(byte[] bytes)
/*     */   {
/* 219 */     int hash = ((bytes[0] & 0xFF) << 24 | (bytes[1] & 0xFF) << 16 | (bytes[2] & 0xFF) << 8) % 8209;
/* 220 */     if (hash < 0) {
/* 221 */       hash += 8209;
/*     */     }
/* 223 */     return hash;
/*     */   }
/*     */   
/*     */ 
/*     */   void writeBits(int value, int count)
/*     */   {
/* 229 */     this.buffer |= value << this.bitCount;
/* 230 */     this.bitCount += count;
/* 231 */     if (this.bitCount >= 16) {
/* 232 */       this.bytes.write((byte)this.buffer);
/* 233 */       this.bytes.write((byte)(this.buffer >>> 8));
/* 234 */       this.buffer >>>= 16;
/* 235 */       this.bitCount -= 16;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   void alignToByte()
/*     */   {
/* 242 */     if (this.bitCount > 0) {
/* 243 */       this.bytes.write((byte)this.buffer);
/* 244 */       if (this.bitCount > 8) this.bytes.write((byte)(this.buffer >>> 8));
/*     */     }
/* 246 */     this.buffer = 0;
/* 247 */     this.bitCount = 0;
/*     */   }
/*     */   
/*     */ 
/*     */   void outputLiteral(byte literal)
/*     */   {
/* 253 */     int i = literal & 0xFF;
/*     */     
/* 255 */     if (i <= 143)
/*     */     {
/* 257 */       writeBits(mirrorBytes[(48 + i)], 8);
/*     */     }
/*     */     else
/*     */     {
/* 261 */       writeBits(1 + 2 * mirrorBytes[(0 + i)], 9);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   Code findCode(int value, Code[] codes)
/*     */   {
/* 270 */     int i = -1;
/* 271 */     int j = codes.length;
/*     */     int k;
/* 273 */     for (;;) { k = (j + i) / 2;
/* 274 */       if (value < codes[k].min) {
/* 275 */         j = k;
/*     */       } else {
/* 277 */         if (value <= codes[k].max) break;
/* 278 */         i = k;
/*     */       }
/*     */     }
/* 281 */     return codes[k];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void outputMatch(int length, int distance)
/*     */   {
/* 292 */     while (length > 0)
/*     */     {
/*     */       int thisLength;
/*     */       
/*     */       int thisLength;
/*     */       
/* 298 */       if (length > 260) {
/* 299 */         thisLength = 258;
/*     */       } else { int thisLength;
/* 301 */         if (length <= 258) {
/* 302 */           thisLength = length;
/*     */         }
/*     */         else {
/* 305 */           thisLength = length - 3;
/*     */         }
/*     */       }
/* 308 */       length -= thisLength;
/*     */       
/*     */ 
/* 311 */       Code l = findCode(thisLength, lengthCodes);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 316 */       if (l.code <= 279) {
/* 317 */         writeBits(mirrorBytes[((l.code - 256) * 2)], 7);
/*     */       }
/*     */       else {
/* 320 */         writeBits(mirrorBytes[(-88 + l.code)], 8);
/*     */       }
/*     */       
/*     */ 
/* 324 */       if (l.extraBits != 0) {
/* 325 */         writeBits(thisLength - l.min, l.extraBits);
/*     */       }
/*     */       
/*     */ 
/* 329 */       Code d = findCode(distance, distanceCodes);
/*     */       
/*     */ 
/*     */ 
/* 333 */       writeBits(mirrorBytes[(d.code * 8)], 5);
/*     */       
/*     */ 
/* 336 */       if (d.extraBits != 0) {
/* 337 */         writeBits(distance - d.min, d.extraBits);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   Match findLongestMatch(int position, Link firstPosition)
/*     */   {
/* 346 */     Link link = firstPosition;
/* 347 */     int numberOfMatches = 0;
/* 348 */     Match bestMatch = new Match(-1, -1);
/*     */     
/*     */     for (;;)
/*     */     {
/* 352 */       int matchPosition = link.value;
/*     */       
/* 354 */       if ((position - matchPosition < 32768) && (matchPosition != 0))
/*     */       {
/*     */ 
/*     */ 
/* 358 */         for (int i = 1; position + i < this.inLength; i++) {
/* 359 */           if (this.in[(position + i)] != this.in[(matchPosition + i)]) {
/*     */             break;
/*     */           }
/*     */         }
/*     */         
/* 364 */         if (i >= 3)
/*     */         {
/* 366 */           if (i > bestMatch.length) {
/* 367 */             bestMatch.length = i;
/* 368 */             bestMatch.distance = (position - matchPosition);
/*     */           }
/*     */           
/* 371 */           numberOfMatches += 1;
/*     */           
/* 373 */           if (numberOfMatches == 32) {
/*     */             break;
/*     */           }
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 381 */       link = link.next;
/* 382 */       if (link == null) {
/*     */         break;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 388 */     if ((bestMatch.length < 3) || (bestMatch.distance < 1) || (bestMatch.distance > 32768)) {
/* 389 */       return null;
/*     */     }
/*     */     
/* 392 */     return bestMatch;
/*     */   }
/*     */   
/*     */ 
/*     */   void updateHashtable(int to, int from)
/*     */   {
/* 398 */     byte[] data = new byte[3];
/*     */     
/*     */ 
/*     */ 
/* 402 */     for (int i = to; i < from; i++)
/*     */     {
/* 404 */       if (i + 3 > this.inLength) {
/*     */         break;
/*     */       }
/*     */       
/* 408 */       data[0] = this.in[i];
/* 409 */       data[1] = this.in[(i + 1)];
/* 410 */       data[2] = this.in[(i + 2)];
/*     */       
/* 412 */       int hash = hash(data);
/*     */       
/* 414 */       if (this.window[this.nextWindow].previous != null) {
/* 415 */         this.window[this.nextWindow].previous.next = null;
/*     */       }
/* 417 */       else if (this.window[this.nextWindow].hash != 0) {
/* 418 */         this.hashtable[this.window[this.nextWindow].hash].next = null;
/*     */       }
/*     */       
/* 421 */       this.window[this.nextWindow].hash = hash;
/* 422 */       this.window[this.nextWindow].value = i;
/* 423 */       this.window[this.nextWindow].previous = null;
/* 424 */       Link temp = this.window[this.nextWindow].next = this.hashtable[hash].next;
/* 425 */       this.hashtable[hash].next = this.window[this.nextWindow];
/* 426 */       if (temp != null) {
/* 427 */         temp.previous = this.window[this.nextWindow];
/*     */       }
/*     */       
/* 430 */       this.nextWindow += 1;
/* 431 */       if (this.nextWindow == 32768) {
/* 432 */         this.nextWindow = 0;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   void compress()
/*     */   {
/* 442 */     byte[] data = new byte[3];
/*     */     
/* 444 */     for (int i = 0; i < 8209; i++) {
/* 445 */       this.hashtable[i] = new Link();
/*     */     }
/* 447 */     for (int i = 0; i < 32768; i++) {
/* 448 */       this.window[i] = new Link();
/*     */     }
/* 450 */     this.nextWindow = 0;
/*     */     
/*     */ 
/* 453 */     int deferredPosition = -1;
/* 454 */     Match deferredMatch = null;
/*     */     
/* 456 */     writeBits(1, 1);
/* 457 */     writeBits(1, 2);
/*     */     
/*     */ 
/* 460 */     outputLiteral(this.in[0]);
/* 461 */     int position = 1;
/*     */     
/* 463 */     while (position < this.inLength)
/*     */     {
/* 465 */       if (this.inLength - position < 3) {
/* 466 */         outputLiteral(this.in[position]);
/* 467 */         position += 1;
/*     */       }
/*     */       else
/*     */       {
/* 471 */         data[0] = this.in[position];
/* 472 */         data[1] = this.in[(position + 1)];
/* 473 */         data[2] = this.in[(position + 2)];
/*     */         
/* 475 */         int hash = hash(data);
/* 476 */         Link firstPosition = this.hashtable[hash];
/*     */         
/* 478 */         Match match = findLongestMatch(position, firstPosition);
/*     */         
/* 480 */         updateHashtable(position, position + 1);
/*     */         
/* 482 */         if (match != null)
/*     */         {
/* 484 */           if (deferredMatch != null) {
/* 485 */             if (match.length > deferredMatch.length + 1)
/*     */             {
/* 487 */               outputLiteral(this.in[deferredPosition]);
/*     */               
/* 489 */               deferredPosition = position;
/* 490 */               deferredMatch = match;
/* 491 */               position += 1;
/*     */             }
/*     */             else
/*     */             {
/* 495 */               outputMatch(deferredMatch.length, deferredMatch.distance);
/* 496 */               int newPosition = deferredPosition + deferredMatch.length;
/* 497 */               deferredPosition = -1;
/* 498 */               deferredMatch = null;
/* 499 */               updateHashtable(position + 1, newPosition);
/* 500 */               position = newPosition;
/*     */             }
/*     */           }
/*     */           else
/*     */           {
/* 505 */             deferredPosition = position;
/* 506 */             deferredMatch = match;
/* 507 */             position += 1;
/*     */ 
/*     */ 
/*     */           }
/*     */           
/*     */ 
/*     */ 
/*     */         }
/* 515 */         else if (deferredMatch != null) {
/* 516 */           outputMatch(deferredMatch.length, deferredMatch.distance);
/* 517 */           int newPosition = deferredPosition + deferredMatch.length;
/* 518 */           deferredPosition = -1;
/* 519 */           deferredMatch = null;
/* 520 */           updateHashtable(position + 1, newPosition);
/* 521 */           position = newPosition;
/*     */         }
/*     */         else {
/* 524 */           outputLiteral(this.in[position]);
/* 525 */           position += 1;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 532 */     writeBits(0, 7);
/* 533 */     alignToByte();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   void compressHuffmanOnly()
/*     */   {
/* 541 */     writeBits(1, 1);
/* 542 */     writeBits(1, 2);
/*     */     
/* 544 */     for (int position = 0; position < this.inLength;)
/*     */     {
/* 546 */       outputLiteral(this.in[position]);
/* 547 */       position += 1;
/*     */     }
/*     */     
/*     */ 
/* 551 */     writeBits(0, 7);
/* 552 */     alignToByte();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   void store()
/*     */   {
/* 560 */     int start = 0;
/* 561 */     int length = this.inLength;
/*     */     
/* 563 */     int BFINAL = 0;
/*     */     
/* 565 */     while (length > 0) {
/*     */       int blockLength;
/* 567 */       if (length < 65535) {
/* 568 */         int blockLength = length;
/* 569 */         BFINAL = 1;
/*     */       }
/*     */       else {
/* 572 */         blockLength = 65535;
/* 573 */         BFINAL = 0;
/*     */       }
/*     */       
/*     */ 
/* 577 */       this.bytes.write((byte)BFINAL);
/* 578 */       writeShortLSB(this.bytes, blockLength);
/* 579 */       writeShortLSB(this.bytes, blockLength ^ 0xFFFF);
/*     */       
/*     */ 
/* 582 */       this.bytes.write(this.in, start, blockLength);
/*     */       
/* 584 */       length -= blockLength;
/* 585 */       start += blockLength;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public byte[] deflate(byte[] input)
/*     */   {
/* 593 */     this.in = input;
/* 594 */     this.inLength = input.length;
/*     */     
/*     */ 
/* 597 */     this.bytes.write(120);
/* 598 */     this.bytes.write(-100);
/*     */     
/*     */ 
/* 601 */     for (int i = 0; i < this.inLength; i++) {
/* 602 */       updateAdler(this.in[i]);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 609 */     compress();
/*     */     
/*     */ 
/* 612 */     writeInt(this.bytes, this.adler32);
/*     */     
/* 614 */     return this.bytes.toByteArray();
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/internal/image/PngDeflater.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */