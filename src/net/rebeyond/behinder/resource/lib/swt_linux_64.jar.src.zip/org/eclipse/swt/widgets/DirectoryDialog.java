/*     */ package org.eclipse.swt.widgets;
/*     */ 
/*     */ import java.io.File;
/*     */ import org.eclipse.swt.internal.C;
/*     */ import org.eclipse.swt.internal.Converter;
/*     */ import org.eclipse.swt.internal.gtk.GDK;
/*     */ import org.eclipse.swt.internal.gtk.GTK;
/*     */ import org.eclipse.swt.internal.gtk.OS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DirectoryDialog
/*     */   extends Dialog
/*     */ {
/*  39 */   String message = ""; String filterPath = "";
/*  40 */   static final String SEPARATOR = File.separator;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final int PATH_MAX = 1024;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DirectoryDialog(Shell parent)
/*     */   {
/*  57 */     this(parent, 65536);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DirectoryDialog(Shell parent, int style)
/*     */   {
/*  84 */     super(parent, checkStyle(parent, style));
/*  85 */     checkSubclass();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getFilterPath()
/*     */   {
/*  96 */     return this.filterPath;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getMessage()
/*     */   {
/* 106 */     return this.message;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 121 */   public String open() { return openChooserDialog(); }
/*     */   
/*     */   String openChooserDialog() {
/* 124 */     byte[] titleBytes = Converter.wcsToMbcs(this.title, true);
/* 125 */     long shellHandle = this.parent.topHandle();
/* 126 */     Display display = this.parent != null ? this.parent.getDisplay() : Display.getCurrent();
/* 127 */     long handle = 0L;
/* 128 */     if (display.getDismissalAlignment() == 131072) {
/* 129 */       if (GTK.GTK3) {
/* 130 */         handle = GTK.gtk_file_chooser_dialog_new(titleBytes, shellHandle, 2, GTK.GTK_NAMED_LABEL_CANCEL, -6, GTK.GTK_NAMED_LABEL_OK, -5, 0L);
/*     */       } else {
/* 132 */         handle = GTK.gtk_file_chooser_dialog_new(titleBytes, shellHandle, 2, GTK.GTK_STOCK_CANCEL(), -6, GTK.GTK_STOCK_OK(), -5, 0L);
/*     */       }
/*     */     }
/* 135 */     else if (GTK.GTK3) {
/* 136 */       handle = GTK.gtk_file_chooser_dialog_new(titleBytes, shellHandle, 2, GTK.GTK_NAMED_LABEL_OK, -5, GTK.GTK_NAMED_LABEL_CANCEL, -6, 0L);
/*     */     } else {
/* 138 */       handle = GTK.gtk_file_chooser_dialog_new(titleBytes, shellHandle, 2, GTK.GTK_STOCK_OK(), -5, GTK.GTK_STOCK_CANCEL(), -6, 0L);
/*     */     }
/*     */     
/* 141 */     if (handle == 0L) error(2);
/* 142 */     long group = GTK.gtk_window_get_group(0L);
/* 143 */     GTK.gtk_window_group_add_window(group, handle);
/* 144 */     GTK.gtk_window_set_modal(handle, true);
/* 145 */     long pixbufs = GTK.gtk_window_get_icon_list(shellHandle);
/* 146 */     if (pixbufs != 0L) {
/* 147 */       GTK.gtk_window_set_icon_list(handle, pixbufs);
/* 148 */       OS.g_list_free(pixbufs);
/*     */     }
/* 150 */     if ((this.filterPath != null) && (this.filterPath.length() > 0)) {
/* 151 */       StringBuilder stringBuilder = new StringBuilder();
/*     */       
/* 153 */       if (!this.filterPath.startsWith(SEPARATOR)) {
/* 154 */         stringBuilder.append(SEPARATOR);
/*     */       }
/* 156 */       stringBuilder.append(this.filterPath);
/* 157 */       byte[] buffer = Converter.wcsToMbcs(stringBuilder.toString(), true);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 163 */       if (OS.IsAIX) {
/* 164 */         byte[] outputBuffer = new byte['Ѐ'];
/* 165 */         long ptr = OS.realpath(buffer, outputBuffer);
/* 166 */         if (ptr != 0L) {
/* 167 */           GTK.gtk_file_chooser_set_current_folder(handle, ptr);
/*     */         }
/*     */         
/*     */       }
/*     */       else
/*     */       {
/* 173 */         long ptr = OS.realpath(buffer, null);
/* 174 */         if (ptr != 0L) {
/* 175 */           GTK.gtk_file_chooser_set_current_folder(handle, ptr);
/* 176 */           OS.g_free(ptr);
/*     */         }
/*     */       }
/*     */     }
/* 180 */     if (this.message.length() > 0) {
/* 181 */       byte[] buffer = Converter.wcsToMbcs(this.message, true);
/* 182 */       long box = 0L;
/* 183 */       if (GTK.GTK3) {
/* 184 */         box = GTK.gtk_box_new(0, 0);
/* 185 */         GTK.gtk_box_set_homogeneous(box, false);
/*     */       } else {
/* 187 */         box = GTK.gtk_hbox_new(false, 0);
/*     */       }
/* 189 */       if (box == 0L) error(2);
/* 190 */       long label = GTK.gtk_label_new(buffer);
/* 191 */       if (label == 0L) error(2);
/* 192 */       GTK.gtk_container_add(box, label);
/* 193 */       GTK.gtk_widget_show(label);
/* 194 */       GTK.gtk_label_set_line_wrap(label, true);
/* 195 */       GTK.gtk_label_set_justify(label, 2);
/* 196 */       GTK.gtk_file_chooser_set_extra_widget(handle, box);
/*     */     }
/* 198 */     String answer = null;
/* 199 */     display.addIdleProc();
/* 200 */     Dialog oldModal = null;
/* 201 */     if (GTK.gtk_window_get_modal(handle)) {
/* 202 */       oldModal = display.getModalDialog();
/* 203 */       display.setModalDialog(this);
/*     */     }
/* 205 */     int signalId = 0;
/* 206 */     long hookId = 0L;
/* 207 */     if ((this.style & 0x4000000) != 0) {
/* 208 */       signalId = OS.g_signal_lookup(OS.map, GTK.GTK_TYPE_WIDGET());
/* 209 */       hookId = OS.g_signal_add_emission_hook(signalId, 0, display.emissionProc, handle, 0L);
/*     */     }
/* 211 */     display.sendPreExternalEventDispatchEvent();
/* 212 */     int response = GTK.gtk_dialog_run(handle);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 219 */     GDK.gdk_threads_leave();
/* 220 */     display.sendPostExternalEventDispatchEvent();
/* 221 */     if ((this.style & 0x4000000) != 0) {
/* 222 */       OS.g_signal_remove_emission_hook(signalId, hookId);
/*     */     }
/* 224 */     if (GTK.gtk_window_get_modal(handle)) {
/* 225 */       display.setModalDialog(oldModal);
/*     */     }
/* 227 */     if (response == -5) {
/* 228 */       long path = GTK.gtk_file_chooser_get_filename(handle);
/* 229 */       if (path != 0L) {
/* 230 */         long utf8Ptr = OS.g_filename_to_utf8(path, -1L, null, null, null);
/* 231 */         if (utf8Ptr == 0L) utf8Ptr = OS.g_filename_display_name(path);
/* 232 */         if (path != utf8Ptr) OS.g_free(path);
/* 233 */         if (utf8Ptr != 0L) {
/* 234 */           long[] items_written = new long[1];
/* 235 */           long utf16Ptr = OS.g_utf8_to_utf16(utf8Ptr, -1L, null, items_written, null);
/* 236 */           OS.g_free(utf8Ptr);
/* 237 */           if (utf16Ptr != 0L) {
/* 238 */             int clength = (int)items_written[0];
/* 239 */             char[] chars = new char[clength];
/* 240 */             C.memmove(chars, utf16Ptr, clength * 2);
/* 241 */             OS.g_free(utf16Ptr);
/* 242 */             answer = new String(chars);
/* 243 */             this.filterPath = answer;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 248 */     display.removeIdleProc();
/* 249 */     GTK.gtk_widget_destroy(handle);
/* 250 */     return answer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFilterPath(String string)
/*     */   {
/* 266 */     this.filterPath = string;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMessage(String string)
/*     */   {
/* 285 */     if (string == null) error(4);
/* 286 */     this.message = string;
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/widgets/DirectoryDialog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */