/*      */ package org.eclipse.swt.widgets;
/*      */ 
/*      */ import org.eclipse.swt.SWT;
/*      */ import org.eclipse.swt.graphics.Color;
/*      */ import org.eclipse.swt.graphics.Font;
/*      */ import org.eclipse.swt.graphics.Image;
/*      */ import org.eclipse.swt.graphics.Rectangle;
/*      */ import org.eclipse.swt.internal.C;
/*      */ import org.eclipse.swt.internal.Converter;
/*      */ import org.eclipse.swt.internal.DPIUtil;
/*      */ import org.eclipse.swt.internal.ImageList;
/*      */ import org.eclipse.swt.internal.gtk.GDK;
/*      */ import org.eclipse.swt.internal.gtk.GTK;
/*      */ import org.eclipse.swt.internal.gtk.GdkColor;
/*      */ import org.eclipse.swt.internal.gtk.GdkRGBA;
/*      */ import org.eclipse.swt.internal.gtk.GdkRectangle;
/*      */ import org.eclipse.swt.internal.gtk.OS;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class TreeItem
/*      */   extends Item
/*      */ {
/*      */   Tree parent;
/*      */   Font font;
/*      */   Font[] cellFont;
/*      */   String[] strings;
/*      */   boolean cached;
/*      */   boolean grayed;
/*      */   boolean isExpanded;
/*      */   static final int EXPANDER_EXTRA_PADDING = 4;
/*      */   
/*      */   public TreeItem(Tree parent, int style)
/*      */   {
/*   76 */     this(checkNull(parent), 0L, style, -1, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public TreeItem(Tree parent, int style, int index)
/*      */   {
/*  112 */     this(checkNull(parent), 0L, style, checkIndex(index), true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public TreeItem(TreeItem parentItem, int style)
/*      */   {
/*  146 */     this(checkNull(parentItem).parent, parentItem.handle, style, -1, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public TreeItem(TreeItem parentItem, int style, int index)
/*      */   {
/*  182 */     this(checkNull(parentItem).parent, parentItem.handle, style, checkIndex(index), true);
/*      */   }
/*      */   
/*      */   TreeItem(Tree parent, long parentIter, int style, int index, boolean create) {
/*  186 */     super(parent, style);
/*  187 */     this.parent = parent;
/*  188 */     if (create) {
/*  189 */       parent.createItem(this, parentIter, index);
/*      */     } else {
/*  191 */       this.handle = OS.g_malloc(GTK.GtkTreeIter_sizeof());
/*  192 */       GTK.gtk_tree_model_iter_nth_child(parent.modelHandle, this.handle, parentIter, index);
/*      */     }
/*      */   }
/*      */   
/*      */   static int checkIndex(int index) {
/*  197 */     if (index < 0) SWT.error(6);
/*  198 */     return index;
/*      */   }
/*      */   
/*      */   static TreeItem checkNull(TreeItem item) {
/*  202 */     if (item == null) SWT.error(4);
/*  203 */     return item;
/*      */   }
/*      */   
/*      */   static Tree checkNull(Tree control) {
/*  207 */     if (control == null) SWT.error(4);
/*  208 */     return control;
/*      */   }
/*      */   
/*      */   protected void checkSubclass()
/*      */   {
/*  213 */     if (!isValidSubclass()) error(43);
/*      */   }
/*      */   
/*      */   Color _getBackground() {
/*  217 */     long[] ptr = new long[1];
/*  218 */     GTK.gtk_tree_model_get(this.parent.modelHandle, this.handle, 4, ptr, -1);
/*  219 */     if (ptr[0] == 0L) return this.parent.getBackground();
/*  220 */     if (GTK.GTK3) {
/*  221 */       GdkRGBA gdkRGBA = new GdkRGBA();
/*  222 */       OS.memmove(gdkRGBA, ptr[0], GdkRGBA.sizeof);
/*  223 */       GDK.gdk_rgba_free(ptr[0]);
/*  224 */       return Color.gtk_new(this.display, gdkRGBA);
/*      */     }
/*  226 */     GdkColor gdkColor = new GdkColor();
/*  227 */     OS.memmove(gdkColor, ptr[0], GdkColor.sizeof);
/*  228 */     GDK.gdk_color_free(ptr[0]);
/*  229 */     return Color.gtk_new(this.display, gdkColor);
/*      */   }
/*      */   
/*      */   Color _getBackground(int index)
/*      */   {
/*  234 */     int count = Math.max(1, this.parent.columnCount);
/*  235 */     if ((0 > index) || (index > count - 1)) return _getBackground();
/*  236 */     long[] ptr = new long[1];
/*  237 */     int modelIndex = this.parent.columnCount == 0 ? 6 : this.parent.columns[index].modelIndex;
/*  238 */     GTK.gtk_tree_model_get(this.parent.modelHandle, this.handle, modelIndex + 3, ptr, -1);
/*  239 */     if (ptr[0] == 0L) return _getBackground();
/*  240 */     if (GTK.GTK3) {
/*  241 */       GdkRGBA gdkRGBA = new GdkRGBA();
/*  242 */       OS.memmove(gdkRGBA, ptr[0], GdkRGBA.sizeof);
/*  243 */       GDK.gdk_rgba_free(ptr[0]);
/*  244 */       return Color.gtk_new(this.display, gdkRGBA);
/*      */     }
/*  246 */     GdkColor gdkColor = new GdkColor();
/*  247 */     OS.memmove(gdkColor, ptr[0], GdkColor.sizeof);
/*  248 */     GDK.gdk_color_free(ptr[0]);
/*  249 */     return Color.gtk_new(this.display, gdkColor);
/*      */   }
/*      */   
/*      */   boolean _getChecked()
/*      */   {
/*  254 */     int[] ptr = new int[1];
/*  255 */     GTK.gtk_tree_model_get(this.parent.modelHandle, this.handle, 1, ptr, -1);
/*  256 */     return ptr[0] != 0;
/*      */   }
/*      */   
/*      */   Color _getForeground() {
/*  260 */     long[] ptr = new long[1];
/*  261 */     GTK.gtk_tree_model_get(this.parent.modelHandle, this.handle, 3, ptr, -1);
/*  262 */     if (ptr[0] == 0L) return this.parent.getForeground();
/*  263 */     if (GTK.GTK3) {
/*  264 */       GdkRGBA gdkRGBA = new GdkRGBA();
/*  265 */       OS.memmove(gdkRGBA, ptr[0], GdkRGBA.sizeof);
/*  266 */       GDK.gdk_rgba_free(ptr[0]);
/*  267 */       return Color.gtk_new(this.display, gdkRGBA);
/*      */     }
/*  269 */     GdkColor gdkColor = new GdkColor();
/*  270 */     OS.memmove(gdkColor, ptr[0], GdkColor.sizeof);
/*  271 */     GDK.gdk_color_free(ptr[0]);
/*  272 */     return Color.gtk_new(this.display, gdkColor);
/*      */   }
/*      */   
/*      */   Color _getForeground(int index)
/*      */   {
/*  277 */     int count = Math.max(1, this.parent.columnCount);
/*  278 */     if ((0 > index) || (index > count - 1)) return _getForeground();
/*  279 */     long[] ptr = new long[1];
/*  280 */     int modelIndex = this.parent.columnCount == 0 ? 6 : this.parent.columns[index].modelIndex;
/*  281 */     GTK.gtk_tree_model_get(this.parent.modelHandle, this.handle, modelIndex + 2, ptr, -1);
/*  282 */     if (ptr[0] == 0L) return _getForeground();
/*  283 */     if (GTK.GTK3) {
/*  284 */       GdkRGBA gdkRGBA = new GdkRGBA();
/*  285 */       OS.memmove(gdkRGBA, ptr[0], GdkRGBA.sizeof);
/*  286 */       GDK.gdk_rgba_free(ptr[0]);
/*  287 */       return Color.gtk_new(this.display, gdkRGBA);
/*      */     }
/*  289 */     GdkColor gdkColor = new GdkColor();
/*  290 */     OS.memmove(gdkColor, ptr[0], GdkColor.sizeof);
/*  291 */     GDK.gdk_color_free(ptr[0]);
/*  292 */     return Color.gtk_new(this.display, gdkColor);
/*      */   }
/*      */   
/*      */   Image _getImage(int index)
/*      */   {
/*  297 */     int count = Math.max(1, this.parent.getColumnCount());
/*  298 */     if ((0 > index) || (index > count - 1)) return null;
/*  299 */     long[] ptr = new long[1];
/*  300 */     int modelIndex = this.parent.columnCount == 0 ? 6 : this.parent.columns[index].modelIndex;
/*  301 */     GTK.gtk_tree_model_get(this.parent.modelHandle, this.handle, modelIndex + 0, ptr, -1);
/*  302 */     if (ptr[0] == 0L) return null;
/*  303 */     ImageList imageList = this.parent.imageList;
/*  304 */     int imageIndex = imageList.indexOf(ptr[0]);
/*  305 */     OS.g_object_unref(ptr[0]);
/*  306 */     if (imageIndex == -1) return null;
/*  307 */     return imageList.get(imageIndex);
/*      */   }
/*      */   
/*      */   String _getText(int index) {
/*  311 */     int count = Math.max(1, this.parent.getColumnCount());
/*  312 */     if ((0 > index) || (index > count - 1)) return "";
/*  313 */     long[] ptr = new long[1];
/*  314 */     int modelIndex = this.parent.columnCount == 0 ? 6 : this.parent.columns[index].modelIndex;
/*  315 */     GTK.gtk_tree_model_get(this.parent.modelHandle, this.handle, modelIndex + 1, ptr, -1);
/*  316 */     if (ptr[0] == 0L) return "";
/*  317 */     int length = C.strlen(ptr[0]);
/*  318 */     byte[] buffer = new byte[length];
/*  319 */     C.memmove(buffer, ptr[0], length);
/*  320 */     OS.g_free(ptr[0]);
/*  321 */     return new String(Converter.mbcsToWcs(buffer));
/*      */   }
/*      */   
/*      */   void clear() {
/*  325 */     if (this.parent.currentItem == this) return;
/*  326 */     if ((this.cached) || ((this.parent.style & 0x10000000) == 0)) {
/*  327 */       int columnCount = GTK.gtk_tree_model_get_n_columns(this.parent.modelHandle);
/*      */       
/*  329 */       for (int i = 1; i < 3; i++) {
/*  330 */         GTK.gtk_tree_store_set(this.parent.modelHandle, this.handle, i, 0, -1);
/*      */       }
/*  332 */       for (int i = 3; i < columnCount; i++) {
/*  333 */         GTK.gtk_tree_store_set(this.parent.modelHandle, this.handle, i, 0L, -1);
/*      */       }
/*      */     }
/*  336 */     this.cached = false;
/*  337 */     this.font = null;
/*  338 */     this.strings = null;
/*  339 */     this.cellFont = null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void clear(int index, boolean all)
/*      */   {
/*  366 */     checkWidget();
/*  367 */     this.parent.clear(this.handle, index, all);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void clearAll(boolean all)
/*      */   {
/*  390 */     checkWidget();
/*  391 */     this.parent.clearAll(all, this.handle);
/*      */   }
/*      */   
/*      */   void destroyWidget()
/*      */   {
/*  396 */     this.parent.releaseItem(this, false);
/*  397 */     this.parent.destroyItem(this);
/*  398 */     releaseHandle();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Color getBackground()
/*      */   {
/*  415 */     checkWidget();
/*  416 */     if (!this.parent.checkData(this)) error(24);
/*  417 */     return _getBackground();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Color getBackground(int index)
/*      */   {
/*  434 */     checkWidget();
/*  435 */     if (!this.parent.checkData(this)) error(24);
/*  436 */     return _getBackground(index);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Rectangle getBounds(int index)
/*      */   {
/*  454 */     checkWidget();
/*  455 */     return DPIUtil.autoScaleDown(getBoundsInPixels(index));
/*      */   }
/*      */   
/*      */   Rectangle getBoundsInPixels(int index)
/*      */   {
/*  460 */     checkWidget();
/*  461 */     if (!this.parent.checkData(this)) error(24);
/*  462 */     long parentHandle = this.parent.handle;
/*  463 */     long column = 0L;
/*  464 */     if ((index >= 0) && (index < this.parent.columnCount)) {
/*  465 */       column = this.parent.columns[index].handle;
/*      */     } else {
/*  467 */       column = GTK.gtk_tree_view_get_column(parentHandle, index);
/*      */     }
/*  469 */     if (column == 0L) return new Rectangle(0, 0, 0, 0);
/*  470 */     long path = GTK.gtk_tree_model_get_path(this.parent.modelHandle, this.handle);
/*  471 */     GTK.gtk_widget_realize(parentHandle);
/*  472 */     GdkRectangle rect = new GdkRectangle();
/*  473 */     GTK.gtk_tree_view_get_cell_area(parentHandle, path, column, rect);
/*  474 */     if ((this.parent.getStyle() & 0x8000000) != 0) { rect.x = (this.parent.getClientWidth() - rect.width - rect.x);
/*      */     }
/*  476 */     GTK.gtk_tree_path_free(path);
/*      */     
/*  478 */     if ((index == 0) && ((this.parent.style & 0x20) != 0)) {
/*  479 */       int[] x = new int[1];int[] w = new int[1];
/*  480 */       gtk_tree_view_column_cell_get_position(column, this.parent.checkRenderer, x, w);
/*  481 */       rect.x += x[0] + w[0];
/*  482 */       rect.width -= x[0] + w[0];
/*      */     }
/*  484 */     int width = GTK.gtk_tree_view_column_get_visible(column) ? rect.width + 1 : 0;
/*  485 */     Rectangle r = new Rectangle(rect.x, rect.y, width, rect.height + 1);
/*  486 */     return r;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Rectangle getBounds()
/*      */   {
/*  501 */     checkWidget();
/*  502 */     return DPIUtil.autoScaleDown(getBoundsInPixels());
/*      */   }
/*      */   
/*      */ 
/*      */   Rectangle getBoundsInPixels()
/*      */   {
/*  508 */     checkWidget();
/*  509 */     if (!this.parent.checkData(this)) error(24);
/*  510 */     long parentHandle = this.parent.handle;
/*  511 */     long column = GTK.gtk_tree_view_get_column(parentHandle, 0);
/*  512 */     if (column == 0L) return new Rectangle(0, 0, 0, 0);
/*  513 */     long textRenderer = this.parent.getTextRenderer(column);
/*  514 */     long pixbufRenderer = this.parent.getPixbufRenderer(column);
/*  515 */     if ((textRenderer == 0L) || (pixbufRenderer == 0L)) { return new Rectangle(0, 0, 0, 0);
/*      */     }
/*  517 */     long path = GTK.gtk_tree_model_get_path(this.parent.modelHandle, this.handle);
/*  518 */     GTK.gtk_widget_realize(parentHandle);
/*      */     
/*  520 */     boolean isExpander = GTK.gtk_tree_model_iter_n_children(this.parent.modelHandle, this.handle) > 0;
/*  521 */     boolean isExpanded = GTK.gtk_tree_view_row_expanded(parentHandle, path);
/*  522 */     GTK.gtk_tree_view_column_cell_set_cell_data(column, this.parent.modelHandle, this.handle, isExpander, isExpanded);
/*      */     
/*  524 */     GdkRectangle rect = new GdkRectangle();
/*  525 */     GTK.gtk_tree_view_get_cell_area(parentHandle, path, column, rect);
/*  526 */     if ((this.parent.getStyle() & 0x8000000) != 0) rect.x = (this.parent.getClientWidth() - rect.width - rect.x);
/*  527 */     int right = rect.x + rect.width;
/*      */     
/*  529 */     int[] x = new int[1];int[] w = new int[1];
/*  530 */     this.parent.ignoreSize = true;
/*  531 */     gtk_cell_renderer_get_preferred_size(textRenderer, parentHandle, w, null);
/*  532 */     this.parent.ignoreSize = false;
/*  533 */     rect.width = w[0];
/*  534 */     int[] buffer = new int[1];
/*  535 */     GTK.gtk_tree_path_free(path);
/*      */     
/*  537 */     GTK.gtk_widget_style_get(parentHandle, OS.horizontal_separator, buffer, 0L);
/*  538 */     int horizontalSeparator = buffer[0];
/*  539 */     rect.x += horizontalSeparator;
/*      */     
/*  541 */     gtk_tree_view_column_cell_get_position(column, textRenderer, x, null);
/*  542 */     rect.x += x[0];
/*  543 */     if ((this.parent.columnCount > 0) && 
/*  544 */       (rect.x + rect.width > right)) {
/*  545 */       rect.width = Math.max(0, right - rect.x);
/*      */     }
/*      */     
/*  548 */     int width = GTK.gtk_tree_view_column_get_visible(column) ? rect.width + 1 : 0;
/*  549 */     Rectangle r = new Rectangle(rect.x, rect.y, width, rect.height + 1);
/*  550 */     return r;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getChecked()
/*      */   {
/*  567 */     checkWidget();
/*  568 */     if (!this.parent.checkData(this)) error(24);
/*  569 */     if ((this.parent.style & 0x20) == 0) return false;
/*  570 */     return _getChecked();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getExpanded()
/*      */   {
/*  586 */     checkWidget();
/*  587 */     long path = GTK.gtk_tree_model_get_path(this.parent.modelHandle, this.handle);
/*  588 */     boolean answer = GTK.gtk_tree_view_row_expanded(this.parent.handle, path);
/*  589 */     GTK.gtk_tree_path_free(path);
/*  590 */     return answer;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Font getFont()
/*      */   {
/*  606 */     checkWidget();
/*  607 */     if (!this.parent.checkData(this)) error(24);
/*  608 */     return this.font != null ? this.font : this.parent.getFont();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Font getFont(int index)
/*      */   {
/*  626 */     checkWidget();
/*  627 */     if (!this.parent.checkData(this)) error(24);
/*  628 */     int count = Math.max(1, this.parent.columnCount);
/*  629 */     if ((0 > index) || (index > count - 1)) return getFont();
/*  630 */     if ((this.cellFont == null) || (this.cellFont[index] == null)) return getFont();
/*  631 */     return this.cellFont[index];
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Color getForeground()
/*      */   {
/*  649 */     checkWidget();
/*  650 */     if (!this.parent.checkData(this)) error(24);
/*  651 */     return _getForeground();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Color getForeground(int index)
/*      */   {
/*  669 */     checkWidget();
/*  670 */     if (!this.parent.checkData(this)) error(24);
/*  671 */     return _getForeground(index);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean getGrayed()
/*      */   {
/*  688 */     checkWidget();
/*  689 */     if (!this.parent.checkData(this)) error(24);
/*  690 */     if ((this.parent.style & 0x20) == 0) return false;
/*  691 */     return this.grayed;
/*      */   }
/*      */   
/*      */   public Image getImage()
/*      */   {
/*  696 */     checkWidget();
/*  697 */     if (!this.parent.checkData(this)) error(24);
/*  698 */     return getImage(0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Image getImage(int index)
/*      */   {
/*  716 */     checkWidget();
/*  717 */     if (!this.parent.checkData(this)) error(24);
/*  718 */     return _getImage(index);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Rectangle getImageBounds(int index)
/*      */   {
/*  737 */     checkWidget();
/*  738 */     return DPIUtil.autoScaleDown(getImageBoundsInPixels(index));
/*      */   }
/*      */   
/*      */   Rectangle getImageBoundsInPixels(int index)
/*      */   {
/*  743 */     checkWidget();
/*  744 */     if (!this.parent.checkData(this)) error(24);
/*  745 */     long parentHandle = this.parent.handle;
/*  746 */     long column = 0L;
/*  747 */     if ((index >= 0) && (index < this.parent.getColumnCount())) {
/*  748 */       column = this.parent.columns[index].handle;
/*      */     } else {
/*  750 */       column = GTK.gtk_tree_view_get_column(parentHandle, index);
/*      */     }
/*  752 */     if (column == 0L) return new Rectangle(0, 0, 0, 0);
/*  753 */     long pixbufRenderer = this.parent.getPixbufRenderer(column);
/*  754 */     if (pixbufRenderer == 0L) return new Rectangle(0, 0, 0, 0);
/*  755 */     GdkRectangle rect = new GdkRectangle();
/*  756 */     long path = GTK.gtk_tree_model_get_path(this.parent.modelHandle, this.handle);
/*  757 */     GTK.gtk_widget_realize(parentHandle);
/*  758 */     GTK.gtk_tree_view_get_cell_area(parentHandle, path, column, rect);
/*  759 */     if ((this.parent.getStyle() & 0x8000000) != 0) rect.x = (this.parent.getClientWidth() - rect.width - rect.x);
/*  760 */     GTK.gtk_tree_path_free(path);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  768 */     int[] x = new int[1];int[] w = new int[1];
/*  769 */     gtk_tree_view_column_cell_get_position(column, pixbufRenderer, x, w);
/*  770 */     if (GTK.GTK3) {
/*  771 */       if (this.parent.pixbufSizeSet) {
/*  772 */         if (x[0] > 0) {
/*  773 */           rect.x += x[0];
/*      */         }
/*      */         
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*      */ 
/*  781 */         long textRenderer = this.parent.getTextRenderer(column);
/*  782 */         if (textRenderer == 0L) return new Rectangle(0, 0, 0, 0);
/*  783 */         int[] xText = new int[1];int[] wText = new int[1];
/*  784 */         gtk_tree_view_column_cell_get_position(column, textRenderer, xText, wText);
/*  785 */         rect.x += xText[0];
/*      */       }
/*      */     } else {
/*  788 */       rect.x += x[0];
/*      */     }
/*  790 */     rect.width = w[0];
/*  791 */     int width = GTK.gtk_tree_view_column_get_visible(column) ? rect.width : 0;
/*  792 */     return new Rectangle(rect.x, rect.y, width, rect.height + 1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getItemCount()
/*      */   {
/*  807 */     checkWidget();
/*  808 */     if (!this.parent.checkData(this)) error(24);
/*  809 */     return GTK.gtk_tree_model_iter_n_children(this.parent.modelHandle, this.handle);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public TreeItem getItem(int index)
/*      */   {
/*  830 */     checkWidget();
/*  831 */     if (index < 0) error(6);
/*  832 */     if (!this.parent.checkData(this)) error(24);
/*  833 */     int itemCount = GTK.gtk_tree_model_iter_n_children(this.parent.modelHandle, this.handle);
/*  834 */     if (index >= itemCount) error(6);
/*  835 */     return this.parent._getItem(this.handle, index);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public TreeItem[] getItems()
/*      */   {
/*  855 */     checkWidget();
/*  856 */     if (!this.parent.checkData(this)) error(24);
/*  857 */     return this.parent.getItems(this.handle);
/*      */   }
/*      */   
/*      */   String getNameText()
/*      */   {
/*  862 */     if (((this.parent.style & 0x10000000) != 0) && 
/*  863 */       (!this.cached)) { return "*virtual*";
/*      */     }
/*  865 */     return super.getNameText();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Tree getParent()
/*      */   {
/*  879 */     checkWidget();
/*  880 */     return this.parent;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public TreeItem getParentItem()
/*      */   {
/*  896 */     checkWidget();
/*  897 */     long path = GTK.gtk_tree_model_get_path(this.parent.modelHandle, this.handle);
/*  898 */     TreeItem item = null;
/*  899 */     int depth = GTK.gtk_tree_path_get_depth(path);
/*  900 */     if (depth > 1) {
/*  901 */       GTK.gtk_tree_path_up(path);
/*  902 */       long iter = OS.g_malloc(GTK.GtkTreeIter_sizeof());
/*  903 */       if (GTK.gtk_tree_model_get_iter(this.parent.modelHandle, iter, path)) {
/*  904 */         item = this.parent._getItem(iter);
/*      */       }
/*  906 */       OS.g_free(iter);
/*      */     }
/*  908 */     GTK.gtk_tree_path_free(path);
/*  909 */     return item;
/*      */   }
/*      */   
/*      */   public String getText()
/*      */   {
/*  914 */     checkWidget();
/*  915 */     if (!this.parent.checkData(this)) error(24);
/*  916 */     return getText(0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getText(int index)
/*      */   {
/*  934 */     checkWidget();
/*  935 */     if (!this.parent.checkData(this)) error(24);
/*  936 */     if ((this.strings != null) && 
/*  937 */       (0 <= index) && (index < this.strings.length)) {
/*  938 */       String string = this.strings[index];
/*  939 */       return string != null ? string : "";
/*      */     }
/*      */     
/*  942 */     return _getText(index);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Rectangle getTextBounds(int index)
/*      */   {
/*  961 */     checkWidget();
/*  962 */     return DPIUtil.autoScaleDown(getTextBoundsInPixels(index));
/*      */   }
/*      */   
/*      */   Rectangle getTextBoundsInPixels(int index) {
/*  966 */     checkWidget();
/*  967 */     if (!this.parent.checkData(this)) error(24);
/*  968 */     int count = Math.max(1, this.parent.getColumnCount());
/*  969 */     if ((0 > index) || (index > count - 1)) { return new Rectangle(0, 0, 0, 0);
/*      */     }
/*      */     
/*  972 */     long parentHandle = this.parent.handle;
/*  973 */     long column = 0L;
/*  974 */     if ((index >= 0) && (index < this.parent.columnCount)) {
/*  975 */       column = this.parent.columns[index].handle;
/*      */     } else {
/*  977 */       column = GTK.gtk_tree_view_get_column(parentHandle, index);
/*      */     }
/*  979 */     if (column == 0L) return new Rectangle(0, 0, 0, 0);
/*  980 */     long textRenderer = this.parent.getTextRenderer(column);
/*  981 */     long pixbufRenderer = this.parent.getPixbufRenderer(column);
/*  982 */     if ((textRenderer == 0L) || (pixbufRenderer == 0L)) { return new Rectangle(0, 0, 0, 0);
/*      */     }
/*  984 */     long path = GTK.gtk_tree_model_get_path(this.parent.modelHandle, this.handle);
/*  985 */     GTK.gtk_widget_realize(parentHandle);
/*      */     
/*  987 */     boolean isExpander = GTK.gtk_tree_model_iter_n_children(this.parent.modelHandle, this.handle) > 0;
/*  988 */     boolean isExpanded = GTK.gtk_tree_view_row_expanded(parentHandle, path);
/*  989 */     GTK.gtk_tree_view_column_cell_set_cell_data(column, this.parent.modelHandle, this.handle, isExpander, isExpanded);
/*      */     
/*  991 */     GdkRectangle rect = new GdkRectangle();
/*  992 */     GTK.gtk_tree_view_get_cell_area(parentHandle, path, column, rect);
/*  993 */     if ((this.parent.getStyle() & 0x8000000) != 0) rect.x = (this.parent.getClientWidth() - rect.width - rect.x);
/*  994 */     int right = rect.x + rect.width;
/*      */     
/*  996 */     int[] x = new int[1];int[] w = new int[1];
/*  997 */     this.parent.ignoreSize = true;
/*  998 */     gtk_cell_renderer_get_preferred_size(textRenderer, parentHandle, w, null);
/*  999 */     this.parent.ignoreSize = false;
/* 1000 */     int[] buffer = new int[1];
/* 1001 */     GTK.gtk_tree_path_free(path);
/*      */     
/* 1003 */     GTK.gtk_widget_style_get(parentHandle, OS.horizontal_separator, buffer, 0L);
/* 1004 */     int horizontalSeparator = buffer[0];
/* 1005 */     rect.x += horizontalSeparator;
/* 1006 */     gtk_tree_view_column_cell_get_position(column, textRenderer, x, null);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1014 */     if (GTK.GTK3) {
/* 1015 */       Image image = _getImage(index);
/* 1016 */       int imageWidth = 0;
/* 1017 */       if (image != null) {
/* 1018 */         imageWidth = image.getBounds().width;
/*      */       }
/* 1020 */       if (x[0] < imageWidth) {
/* 1021 */         rect.x += imageWidth;
/*      */       } else {
/* 1023 */         rect.x += x[0];
/*      */       }
/*      */     } else {
/* 1026 */       rect.x += x[0];
/*      */     }
/* 1028 */     if ((this.parent.columnCount > 0) && 
/* 1029 */       (rect.x + rect.width > right)) {
/* 1030 */       rect.width = Math.max(0, right - rect.x);
/*      */     }
/*      */     
/* 1033 */     int width = GTK.gtk_tree_view_column_get_visible(column) ? rect.width + 1 : 0;
/* 1034 */     return new Rectangle(rect.x, rect.y, width, rect.height + 1);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int indexOf(TreeItem item)
/*      */   {
/* 1058 */     checkWidget();
/* 1059 */     if (item == null) error(4);
/* 1060 */     if (item.isDisposed()) error(5);
/* 1061 */     int index = -1;
/* 1062 */     boolean isParent = false;
/* 1063 */     long currentPath = GTK.gtk_tree_model_get_path(this.parent.modelHandle, this.handle);
/* 1064 */     long parentPath = GTK.gtk_tree_model_get_path(this.parent.modelHandle, item.handle);
/* 1065 */     int depth = GTK.gtk_tree_path_get_depth(parentPath);
/* 1066 */     if ((depth > 1) && (GTK.gtk_tree_path_up(parentPath)) && 
/* 1067 */       (GTK.gtk_tree_path_compare(currentPath, parentPath) == 0L)) { isParent = true;
/*      */     }
/* 1069 */     GTK.gtk_tree_path_free(currentPath);
/* 1070 */     GTK.gtk_tree_path_free(parentPath);
/* 1071 */     if (!isParent) return index;
/* 1072 */     long path = GTK.gtk_tree_model_get_path(this.parent.modelHandle, item.handle);
/* 1073 */     if (depth > 1) {
/* 1074 */       long indices = GTK.gtk_tree_path_get_indices(path);
/* 1075 */       if (indices != 0L) {
/* 1076 */         int[] temp = new int[depth];
/* 1077 */         C.memmove(temp, indices, 4 * temp.length);
/* 1078 */         index = temp[(temp.length - 1)];
/*      */       }
/*      */     }
/* 1081 */     GTK.gtk_tree_path_free(path);
/* 1082 */     return index;
/*      */   }
/*      */   
/*      */   void releaseChildren(boolean destroy)
/*      */   {
/* 1087 */     if (destroy) {
/* 1088 */       this.parent.releaseItems(this.handle);
/*      */     }
/* 1090 */     super.releaseChildren(destroy);
/*      */   }
/*      */   
/*      */   void releaseHandle()
/*      */   {
/* 1095 */     if (this.handle != 0L) OS.g_free(this.handle);
/* 1096 */     this.handle = 0L;
/* 1097 */     super.releaseHandle();
/* 1098 */     this.parent = null;
/*      */   }
/*      */   
/*      */   void releaseWidget()
/*      */   {
/* 1103 */     super.releaseWidget();
/* 1104 */     this.font = null;
/* 1105 */     this.cellFont = null;
/* 1106 */     this.strings = null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeAll()
/*      */   {
/* 1120 */     checkWidget();
/* 1121 */     long modelHandle = this.parent.modelHandle;
/* 1122 */     int length = GTK.gtk_tree_model_iter_n_children(modelHandle, this.handle);
/* 1123 */     if (length == 0) return;
/* 1124 */     long iter = OS.g_malloc(GTK.GtkTreeIter_sizeof());
/* 1125 */     if (iter == 0L) error(2);
/* 1126 */     if (this.parent.fixAccessibility()) {
/* 1127 */       this.parent.ignoreAccessibility = true;
/*      */     }
/* 1129 */     long selection = GTK.gtk_tree_view_get_selection(this.parent.handle);
/* 1130 */     int[] value = new int[1];
/* 1131 */     while (GTK.gtk_tree_model_iter_children(modelHandle, iter, this.handle)) {
/* 1132 */       GTK.gtk_tree_model_get(modelHandle, iter, 0, value, -1);
/* 1133 */       TreeItem item = value[0] != -1 ? this.parent.items[value[0]] : null;
/* 1134 */       if ((item != null) && (!item.isDisposed())) {
/* 1135 */         item.dispose();
/*      */       } else {
/* 1137 */         OS.g_signal_handlers_block_matched(selection, 16, 0, 0, 0L, 0L, 6L);
/* 1138 */         GTK.gtk_tree_store_remove(modelHandle, iter);
/* 1139 */         OS.g_signal_handlers_unblock_matched(selection, 16, 0, 0, 0L, 0L, 6L);
/*      */       }
/*      */     }
/* 1142 */     if (this.parent.fixAccessibility()) {
/* 1143 */       this.parent.ignoreAccessibility = false;
/* 1144 */       OS.g_object_notify(this.parent.handle, OS.model);
/*      */     }
/* 1146 */     OS.g_free(iter);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBackground(Color color)
/*      */   {
/* 1168 */     checkWidget();
/* 1169 */     if ((color != null) && (color.isDisposed())) {
/* 1170 */       error(5);
/*      */     }
/* 1172 */     if (_getBackground().equals(color)) return;
/* 1173 */     if (GTK.GTK3) {
/* 1174 */       GdkRGBA gdkRGBA = color != null ? color.handleRGBA : null;
/* 1175 */       GTK.gtk_tree_store_set(this.parent.modelHandle, this.handle, 4, gdkRGBA, -1);
/*      */     } else {
/* 1177 */       GdkColor gdkColor = color != null ? color.handle : null;
/* 1178 */       GTK.gtk_tree_store_set(this.parent.modelHandle, this.handle, 4, gdkColor, -1);
/*      */     }
/* 1180 */     this.cached = true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setBackground(int index, Color color)
/*      */   {
/* 1203 */     checkWidget();
/* 1204 */     if ((color != null) && (color.isDisposed())) {
/* 1205 */       error(5);
/*      */     }
/* 1207 */     if (_getBackground(index).equals(color)) return;
/* 1208 */     int count = Math.max(1, this.parent.getColumnCount());
/* 1209 */     if ((0 > index) || (index > count - 1)) return;
/* 1210 */     int modelIndex = this.parent.columnCount == 0 ? 6 : this.parent.columns[index].modelIndex;
/* 1211 */     if (GTK.GTK3) {
/* 1212 */       GdkRGBA gdkRGBA = color != null ? color.handleRGBA : null;
/* 1213 */       GTK.gtk_tree_store_set(this.parent.modelHandle, this.handle, modelIndex + 3, gdkRGBA, -1);
/*      */     } else {
/* 1215 */       GdkColor gdkColor = color != null ? color.handle : null;
/* 1216 */       GTK.gtk_tree_store_set(this.parent.modelHandle, this.handle, modelIndex + 3, gdkColor, -1);
/*      */     }
/* 1218 */     this.cached = true;
/*      */     
/*      */ 
/* 1221 */     if (color != null) {
/* 1222 */       boolean customDraw = this.parent.columnCount == 0 ? this.parent.firstCustomDraw : this.parent.columns[index].customDraw;
/* 1223 */       if (!customDraw) {
/* 1224 */         if ((this.parent.style & 0x10000000) == 0) {
/* 1225 */           long parentHandle = this.parent.handle;
/* 1226 */           long column = 0L;
/* 1227 */           if (this.parent.columnCount > 0) {
/* 1228 */             column = this.parent.columns[index].handle;
/*      */           } else {
/* 1230 */             column = GTK.gtk_tree_view_get_column(parentHandle, index);
/*      */           }
/* 1232 */           if (column == 0L) return;
/* 1233 */           long textRenderer = this.parent.getTextRenderer(column);
/* 1234 */           long imageRenderer = this.parent.getPixbufRenderer(column);
/* 1235 */           GTK.gtk_tree_view_column_set_cell_data_func(column, textRenderer, this.display.cellDataProc, parentHandle, 0L);
/* 1236 */           GTK.gtk_tree_view_column_set_cell_data_func(column, imageRenderer, this.display.cellDataProc, parentHandle, 0L);
/*      */         }
/* 1238 */         if (this.parent.columnCount == 0) {
/* 1239 */           this.parent.firstCustomDraw = true;
/*      */         } else {
/* 1241 */           this.parent.columns[index].customDraw = true;
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setChecked(boolean checked)
/*      */   {
/* 1259 */     checkWidget();
/* 1260 */     if ((this.parent.style & 0x20) == 0) return;
/* 1261 */     if (_getChecked() == checked) return;
/* 1262 */     GTK.gtk_tree_store_set(this.parent.modelHandle, this.handle, 1, checked, -1);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1268 */     GTK.gtk_tree_store_set(this.parent.modelHandle, this.handle, 2, !checked ? false : this.grayed, -1);
/* 1269 */     this.cached = true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setExpanded(boolean expanded)
/*      */   {
/* 1284 */     checkWidget();
/* 1285 */     long path = GTK.gtk_tree_model_get_path(this.parent.modelHandle, this.handle);
/* 1286 */     if (expanded != GTK.gtk_tree_view_row_expanded(this.parent.handle, path)) {
/* 1287 */       if (expanded) {
/* 1288 */         OS.g_signal_handlers_block_matched(this.parent.handle, 16, 0, 0, 0L, 0L, 51L);
/* 1289 */         GTK.gtk_tree_view_expand_row(this.parent.handle, path, false);
/* 1290 */         OS.g_signal_handlers_unblock_matched(this.parent.handle, 16, 0, 0, 0L, 0L, 51L);
/*      */       } else {
/* 1292 */         OS.g_signal_handlers_block_matched(this.parent.handle, 16, 0, 0, 0L, 0L, 50L);
/* 1293 */         GTK.gtk_widget_realize(this.parent.handle);
/* 1294 */         GTK.gtk_tree_view_collapse_row(this.parent.handle, path);
/* 1295 */         OS.g_signal_handlers_unblock_matched(this.parent.handle, 16, 0, 0, 0L, 0L, 50L);
/*      */       }
/*      */     }
/* 1298 */     GTK.gtk_tree_path_free(path);
/* 1299 */     this.isExpanded = expanded;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setFont(Font font)
/*      */   {
/* 1321 */     checkWidget();
/* 1322 */     if ((font != null) && (font.isDisposed())) {
/* 1323 */       error(5);
/*      */     }
/* 1325 */     Font oldFont = this.font;
/* 1326 */     if (oldFont == font) return;
/* 1327 */     this.font = font;
/* 1328 */     if ((oldFont != null) && (oldFont.equals(font))) return;
/* 1329 */     long fontHandle = font != null ? font.handle : 0L;
/* 1330 */     GTK.gtk_tree_store_set(this.parent.modelHandle, this.handle, 5, fontHandle, -1);
/* 1331 */     this.cached = true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setFont(int index, Font font)
/*      */   {
/* 1354 */     checkWidget();
/* 1355 */     if ((font != null) && (font.isDisposed())) {
/* 1356 */       error(5);
/*      */     }
/* 1358 */     int count = Math.max(1, this.parent.getColumnCount());
/* 1359 */     if ((0 > index) || (index > count - 1)) return;
/* 1360 */     if (this.cellFont == null) {
/* 1361 */       if (font == null) return;
/* 1362 */       this.cellFont = new Font[count];
/*      */     }
/* 1364 */     Font oldFont = this.cellFont[index];
/* 1365 */     if (oldFont == font) return;
/* 1366 */     this.cellFont[index] = font;
/* 1367 */     if ((oldFont != null) && (oldFont.equals(font))) { return;
/*      */     }
/* 1369 */     int modelIndex = this.parent.columnCount == 0 ? 6 : this.parent.columns[index].modelIndex;
/* 1370 */     long fontHandle = font != null ? font.handle : 0L;
/* 1371 */     GTK.gtk_tree_store_set(this.parent.modelHandle, this.handle, modelIndex + 4, fontHandle, -1);
/* 1372 */     this.cached = true;
/*      */     
/* 1374 */     if (font != null) {
/* 1375 */       boolean customDraw = this.parent.columnCount == 0 ? this.parent.firstCustomDraw : this.parent.columns[index].customDraw;
/* 1376 */       if (!customDraw) {
/* 1377 */         if ((this.parent.style & 0x10000000) == 0) {
/* 1378 */           long parentHandle = this.parent.handle;
/* 1379 */           long column = 0L;
/* 1380 */           if (this.parent.columnCount > 0) {
/* 1381 */             column = this.parent.columns[index].handle;
/*      */           } else {
/* 1383 */             column = GTK.gtk_tree_view_get_column(parentHandle, index);
/*      */           }
/* 1385 */           if (column == 0L) return;
/* 1386 */           long textRenderer = this.parent.getTextRenderer(column);
/* 1387 */           long imageRenderer = this.parent.getPixbufRenderer(column);
/* 1388 */           GTK.gtk_tree_view_column_set_cell_data_func(column, textRenderer, this.display.cellDataProc, parentHandle, 0L);
/* 1389 */           GTK.gtk_tree_view_column_set_cell_data_func(column, imageRenderer, this.display.cellDataProc, parentHandle, 0L);
/*      */         }
/* 1391 */         if (this.parent.columnCount == 0) {
/* 1392 */           this.parent.firstCustomDraw = true;
/*      */         } else {
/* 1394 */           this.parent.columns[index].customDraw = true;
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setForeground(Color color)
/*      */   {
/* 1419 */     checkWidget();
/* 1420 */     if ((color != null) && (color.isDisposed())) {
/* 1421 */       error(5);
/*      */     }
/* 1423 */     if (_getForeground().equals(color)) return;
/* 1424 */     if (GTK.GTK3) {
/* 1425 */       GdkRGBA gdkRGBA = color != null ? color.handleRGBA : null;
/* 1426 */       GTK.gtk_tree_store_set(this.parent.modelHandle, this.handle, 3, gdkRGBA, -1);
/*      */     } else {
/* 1428 */       GdkColor gdkColor = color != null ? color.handle : null;
/* 1429 */       GTK.gtk_tree_store_set(this.parent.modelHandle, this.handle, 3, gdkColor, -1);
/*      */     }
/* 1431 */     this.cached = true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setForeground(int index, Color color)
/*      */   {
/* 1454 */     checkWidget();
/* 1455 */     if ((color != null) && (color.isDisposed())) {
/* 1456 */       error(5);
/*      */     }
/* 1458 */     if (_getForeground(index).equals(color)) return;
/* 1459 */     int count = Math.max(1, this.parent.getColumnCount());
/* 1460 */     if ((0 > index) || (index > count - 1)) return;
/* 1461 */     int modelIndex = this.parent.columnCount == 0 ? 6 : this.parent.columns[index].modelIndex;
/* 1462 */     if (GTK.GTK3) {
/* 1463 */       GdkRGBA gdkRGBA = color != null ? color.handleRGBA : null;
/* 1464 */       GTK.gtk_tree_store_set(this.parent.modelHandle, this.handle, modelIndex + 2, gdkRGBA, -1);
/*      */     } else {
/* 1466 */       GdkColor gdkColor = color != null ? color.handle : null;
/* 1467 */       GTK.gtk_tree_store_set(this.parent.modelHandle, this.handle, modelIndex + 2, gdkColor, -1);
/*      */     }
/* 1469 */     this.cached = true;
/*      */     
/* 1471 */     if (color != null) {
/* 1472 */       boolean customDraw = this.parent.columnCount == 0 ? this.parent.firstCustomDraw : this.parent.columns[index].customDraw;
/* 1473 */       if (!customDraw) {
/* 1474 */         if ((this.parent.style & 0x10000000) == 0) {
/* 1475 */           long parentHandle = this.parent.handle;
/* 1476 */           long column = 0L;
/* 1477 */           if (this.parent.columnCount > 0) {
/* 1478 */             column = this.parent.columns[index].handle;
/*      */           } else {
/* 1480 */             column = GTK.gtk_tree_view_get_column(parentHandle, index);
/*      */           }
/* 1482 */           if (column == 0L) return;
/* 1483 */           long textRenderer = this.parent.getTextRenderer(column);
/* 1484 */           long imageRenderer = this.parent.getPixbufRenderer(column);
/* 1485 */           GTK.gtk_tree_view_column_set_cell_data_func(column, textRenderer, this.display.cellDataProc, parentHandle, 0L);
/* 1486 */           GTK.gtk_tree_view_column_set_cell_data_func(column, imageRenderer, this.display.cellDataProc, parentHandle, 0L);
/*      */         }
/* 1488 */         if (this.parent.columnCount == 0) {
/* 1489 */           this.parent.firstCustomDraw = true;
/*      */         } else {
/* 1491 */           this.parent.columns[index].customDraw = true;
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setGrayed(boolean grayed)
/*      */   {
/* 1509 */     checkWidget();
/* 1510 */     if ((this.parent.style & 0x20) == 0) return;
/* 1511 */     if (this.grayed == grayed) return;
/* 1512 */     this.grayed = grayed;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1517 */     int[] ptr = new int[1];
/* 1518 */     GTK.gtk_tree_model_get(this.parent.modelHandle, this.handle, 1, ptr, -1);
/* 1519 */     GTK.gtk_tree_store_set(this.parent.modelHandle, this.handle, 2, ptr[0] == 0 ? false : grayed, -1);
/* 1520 */     this.cached = true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setImage(int index, Image image)
/*      */   {
/* 1540 */     checkWidget();
/* 1541 */     if ((image != null) && (image.isDisposed())) {
/* 1542 */       error(5);
/*      */     }
/* 1544 */     if ((image != null) && (image.type == 1) && 
/* 1545 */       (image.equals(_getImage(index)))) { return;
/*      */     }
/* 1547 */     int count = Math.max(1, this.parent.getColumnCount());
/* 1548 */     if ((0 > index) || (index > count - 1)) return;
/* 1549 */     long pixbuf = 0L;
/* 1550 */     if (image != null) {
/* 1551 */       ImageList imageList = this.parent.imageList;
/* 1552 */       if (imageList == null) imageList = this.parent.imageList = new ImageList();
/* 1553 */       int imageIndex = imageList.indexOf(image);
/* 1554 */       if (imageIndex == -1) imageIndex = imageList.add(image);
/* 1555 */       pixbuf = imageList.getPixbuf(imageIndex);
/*      */     }
/* 1557 */     int modelIndex = this.parent.columnCount == 0 ? 6 : this.parent.columns[index].modelIndex;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1568 */     if (GTK.GTK3)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/* 1573 */       if ((!this.parent.ownerDraw) && (image != null) && (DPIUtil.getDeviceZoom() != 100)) {
/* 1574 */         Rectangle imgSize = image.getBounds();
/* 1575 */         long scaledPixbuf = GDK.gdk_pixbuf_scale_simple(pixbuf, imgSize.width, imgSize.height, 2);
/* 1576 */         if (scaledPixbuf != 0L) {
/* 1577 */           pixbuf = scaledPixbuf;
/*      */         }
/*      */       }
/* 1580 */       long parentHandle = this.parent.handle;
/* 1581 */       long column = GTK.gtk_tree_view_get_column(parentHandle, index);
/* 1582 */       long pixbufRenderer = this.parent.getPixbufRenderer(column);
/* 1583 */       int[] currentWidth = new int[1];
/* 1584 */       int[] currentHeight = new int[1];
/* 1585 */       GTK.gtk_cell_renderer_get_fixed_size(pixbufRenderer, currentWidth, currentHeight);
/* 1586 */       if (!this.parent.pixbufSizeSet) {
/* 1587 */         if (image != null) {
/* 1588 */           int iWidth = image.getBounds().width;
/* 1589 */           int iHeight = image.getBounds().height;
/* 1590 */           if ((iWidth > currentWidth[0]) || (iHeight > currentHeight[0])) {
/* 1591 */             GTK.gtk_cell_renderer_set_fixed_size(pixbufRenderer, iWidth, iHeight);
/* 1592 */             this.parent.pixbufSizeSet = true;
/* 1593 */             this.parent.pixbufHeight = iHeight;
/* 1594 */             this.parent.pixbufWidth = iWidth;
/*      */             
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1603 */             if ((this.parent.style & 0x10000000) != 0)
/*      */             {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1609 */               boolean check = (modelIndex == 6) && ((this.parent.style & 0x20) != 0);
/* 1610 */               this.parent.createRenderers(column, modelIndex, check, this.parent.style);
/*      */ 
/*      */             }
/*      */             
/*      */ 
/*      */           }
/*      */           
/*      */         }
/*      */         
/*      */ 
/*      */       }
/* 1621 */       else if ((this.parent.pixbufWidth > Math.max(currentWidth[0], 0)) || (this.parent.pixbufHeight > Math.max(currentHeight[0], 0))) {
/* 1622 */         GTK.gtk_cell_renderer_set_fixed_size(pixbufRenderer, this.parent.pixbufWidth, this.parent.pixbufHeight);
/*      */       }
/*      */     }
/*      */     
/* 1626 */     GTK.gtk_tree_store_set(this.parent.modelHandle, this.handle, modelIndex + 0, pixbuf, -1);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1632 */     if (((this.parent.style & 0x10000000) != 0) && (this.parent.currentItem == null) && 
/* 1633 */       (image != null)) {
/* 1634 */       long parentHandle = this.parent.handle;
/* 1635 */       long column = GTK.gtk_tree_view_get_column(parentHandle, index);
/* 1636 */       int[] w = new int[1];
/* 1637 */       long pixbufRenderer = this.parent.getPixbufRenderer(column);
/* 1638 */       gtk_tree_view_column_cell_get_position(column, pixbufRenderer, null, w);
/* 1639 */       if (w[0] < image.getBounds().width)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1645 */         if (!GTK.GTK3) {
/* 1646 */           long style = GTK.gtk_widget_get_modifier_style(parentHandle);
/* 1647 */           this.parent.modifyStyle(parentHandle, style);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 1652 */     this.cached = true;
/*      */   }
/*      */   
/*      */   public void setImage(Image image)
/*      */   {
/* 1657 */     checkWidget();
/* 1658 */     setImage(0, image);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setImage(Image[] images)
/*      */   {
/* 1678 */     checkWidget();
/* 1679 */     if (images == null) error(4);
/* 1680 */     for (int i = 0; i < images.length; i++) {
/* 1681 */       setImage(i, images[i]);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setItemCount(int count)
/*      */   {
/* 1698 */     checkWidget();
/* 1699 */     count = Math.max(0, count);
/* 1700 */     this.parent.setItemCount(this.handle, count);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setText(int index, String string)
/*      */   {
/* 1723 */     checkWidget();
/* 1724 */     if (string == null) error(4);
/* 1725 */     if (getText(index).equals(string)) { return;
/*      */     }
/* 1727 */     int count = Math.max(1, this.parent.getColumnCount());
/* 1728 */     if ((0 > index) || (index > count - 1)) return;
/* 1729 */     if ((0 <= index) && (index < count)) {
/* 1730 */       if (this.strings == null) this.strings = new String[count];
/* 1731 */       if (string.equals(this.strings[index])) return;
/* 1732 */       this.strings[index] = string;
/*      */     }
/* 1734 */     if ((string != null) && (string.length() > 8192)) {
/* 1735 */       string = string.substring(0, 8192 - "...".length()) + "...";
/*      */     }
/* 1737 */     byte[] buffer = Converter.wcsToMbcs(string, true);
/* 1738 */     int modelIndex = this.parent.columnCount == 0 ? 6 : this.parent.columns[index].modelIndex;
/* 1739 */     GTK.gtk_tree_store_set(this.parent.modelHandle, this.handle, modelIndex + 1, buffer, -1);
/* 1740 */     this.cached = true;
/*      */   }
/*      */   
/*      */   public void setText(String string)
/*      */   {
/* 1745 */     checkWidget();
/* 1746 */     setText(0, string);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setText(String[] strings)
/*      */   {
/* 1768 */     checkWidget();
/* 1769 */     if (strings == null) error(4);
/* 1770 */     for (int i = 0; i < strings.length; i++) {
/* 1771 */       String string = strings[i];
/* 1772 */       if (string != null) setText(i, string);
/*      */     }
/*      */   }
/*      */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/widgets/TreeItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */