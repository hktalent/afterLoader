/*     */ package org.eclipse.swt.widgets;
/*     */ 
/*     */ import org.eclipse.swt.graphics.RGB;
/*     */ import org.eclipse.swt.internal.C;
/*     */ import org.eclipse.swt.internal.Converter;
/*     */ import org.eclipse.swt.internal.gtk.GDK;
/*     */ import org.eclipse.swt.internal.gtk.GTK;
/*     */ import org.eclipse.swt.internal.gtk.GdkColor;
/*     */ import org.eclipse.swt.internal.gtk.GdkRGBA;
/*     */ import org.eclipse.swt.internal.gtk.OS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ColorDialog
/*     */   extends Dialog
/*     */ {
/*     */   RGB rgb;
/*     */   RGB[] rgbs;
/*     */   
/*     */   public ColorDialog(Shell parent)
/*     */   {
/*  57 */     this(parent, 65536);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ColorDialog(Shell parent, int style)
/*     */   {
/*  88 */     super(parent, checkStyle(parent, style));
/*  89 */     checkSubclass();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RGB getRGB()
/*     */   {
/* 100 */     return this.rgb;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RGB[] getRGBs()
/*     */   {
/* 112 */     return this.rgbs;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RGB open()
/*     */   {
/* 128 */     byte[] buffer = Converter.wcsToMbcs(this.title, true);
/* 129 */     long handle = 0L;
/* 130 */     if (GTK.GTK_VERSION >= OS.VERSION(3, 4, 0)) {
/* 131 */       handle = GTK.gtk_color_chooser_dialog_new(buffer, this.parent.topHandle());
/*     */     } else {
/* 133 */       handle = GTK.gtk_color_selection_dialog_new(buffer);
/*     */     }
/* 135 */     Display display = this.parent != null ? this.parent.getDisplay() : Display.getCurrent();
/* 136 */     long colorsel = 0L;
/*     */     
/*     */ 
/* 139 */     if (GTK.GTK_VERSION <= OS.VERSION(3, 4, 0)) {
/* 140 */       if (this.parent != null) {
/* 141 */         long shellHandle = this.parent.topHandle();
/* 142 */         GTK.gtk_window_set_transient_for(handle, shellHandle);
/* 143 */         long pixbufs = GTK.gtk_window_get_icon_list(shellHandle);
/* 144 */         if (pixbufs != 0L) {
/* 145 */           GTK.gtk_window_set_icon_list(handle, pixbufs);
/* 146 */           OS.g_list_free(pixbufs);
/*     */         }
/*     */       }
/* 149 */       long group = GTK.gtk_window_get_group(0L);
/* 150 */       GTK.gtk_window_group_add_window(group, handle);
/* 151 */       GTK.gtk_window_set_modal(handle, true);
/*     */       
/* 153 */       colorsel = GTK.gtk_color_selection_dialog_get_color_selection(handle);
/* 154 */       if (this.rgb != null) {
/* 155 */         GdkColor color = new GdkColor();
/* 156 */         color.red = ((short)(this.rgb.red & 0xFF | (this.rgb.red & 0xFF) << 8));
/* 157 */         color.green = ((short)(this.rgb.green & 0xFF | (this.rgb.green & 0xFF) << 8));
/* 158 */         color.blue = ((short)(this.rgb.blue & 0xFF | (this.rgb.blue & 0xFF) << 8));
/* 159 */         GTK.gtk_color_selection_set_current_color(colorsel, color);
/*     */       }
/* 161 */       GTK.gtk_color_selection_set_has_palette(colorsel, true);
/*     */     } else {
/* 163 */       GdkRGBA rgba = new GdkRGBA();
/* 164 */       if (this.rgb != null) {
/* 165 */         rgba.red = (this.rgb.red / 255.0D);
/* 166 */         rgba.green = (this.rgb.green / 255.0D);
/* 167 */         rgba.blue = (this.rgb.blue / 255.0D);
/* 168 */         rgba.alpha = 1.0D;
/*     */       }
/* 170 */       GTK.gtk_color_chooser_set_rgba(handle, rgba);
/*     */     }
/* 172 */     if (this.rgbs != null) {
/* 173 */       if (GTK.GTK_VERSION >= OS.VERSION(3, 4, 0)) {
/* 174 */         int colorsPerRow = 9;
/* 175 */         long gdkRGBAS = OS.g_malloc(GdkRGBA.sizeof * this.rgbs.length);
/* 176 */         GdkRGBA rgba = new GdkRGBA();
/* 177 */         for (int i = 0; i < this.rgbs.length; i++) {
/* 178 */           RGB rgbS = this.rgbs[i];
/* 179 */           if (rgbS != null) {
/* 180 */             rgba.red = (rgbS.red / 255.0D);
/* 181 */             rgba.green = (rgbS.green / 255.0D);
/* 182 */             rgba.blue = (rgbS.blue / 255.0D);
/* 183 */             OS.memmove(gdkRGBAS + i * GdkRGBA.sizeof, rgba, GdkRGBA.sizeof);
/*     */           }
/*     */         }
/* 186 */         GTK.gtk_color_chooser_add_palette(handle, 0, colorsPerRow, this.rgbs.length, gdkRGBAS);
/*     */         
/* 188 */         GTK.gtk_color_chooser_set_rgba(handle, rgba);
/*     */         
/*     */ 
/* 191 */         if (GTK.gtk_color_chooser_get_use_alpha(handle)) {
/* 192 */           GTK.gtk_color_chooser_set_use_alpha(handle, false);
/*     */         }
/* 194 */         OS.g_free(gdkRGBAS);
/*     */       } else {
/* 196 */         long gdkColors = OS.g_malloc(GdkColor.sizeof * this.rgbs.length);
/* 197 */         for (int i = 0; i < this.rgbs.length; i++) {
/* 198 */           RGB rgb = this.rgbs[i];
/* 199 */           if (rgb != null) {
/* 200 */             GdkColor color = new GdkColor();
/* 201 */             color.red = ((short)(rgb.red & 0xFF | (rgb.red & 0xFF) << 8));
/* 202 */             color.green = ((short)(rgb.green & 0xFF | (rgb.green & 0xFF) << 8));
/* 203 */             color.blue = ((short)(rgb.blue & 0xFF | (rgb.blue & 0xFF) << 8));
/* 204 */             OS.memmove(gdkColors + i * GdkColor.sizeof, color, GdkColor.sizeof);
/*     */           }
/*     */         }
/* 207 */         long strPtr = GTK.gtk_color_selection_palette_to_string(gdkColors, this.rgbs.length);
/* 208 */         int length = C.strlen(strPtr);
/*     */         
/* 210 */         buffer = new byte[length];
/* 211 */         C.memmove(buffer, strPtr, length);
/* 212 */         String paletteString = new String(Converter.mbcsToWcs(buffer));
/* 213 */         buffer = Converter.wcsToMbcs(paletteString, true);
/* 214 */         OS.g_free(gdkColors);
/* 215 */         long settings = GTK.gtk_settings_get_default();
/* 216 */         if (settings != 0L) {
/* 217 */           GTK.gtk_settings_set_string_property(settings, GTK.gtk_color_palette, buffer, Converter.wcsToMbcs("gtk_color_selection_palette_to_string", true));
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 223 */     display.addIdleProc();
/* 224 */     Dialog oldModal = null;
/* 225 */     if (GTK.gtk_window_get_modal(handle)) {
/* 226 */       oldModal = display.getModalDialog();
/* 227 */       display.setModalDialog(this);
/*     */     }
/* 229 */     int signalId = 0;
/* 230 */     long hookId = 0L;
/* 231 */     if ((this.style & 0x4000000) != 0) {
/* 232 */       signalId = OS.g_signal_lookup(OS.map, GTK.GTK_TYPE_WIDGET());
/* 233 */       hookId = OS.g_signal_add_emission_hook(signalId, 0, display.emissionProc, handle, 0L);
/*     */     }
/* 235 */     display.sendPreExternalEventDispatchEvent();
/* 236 */     int response = GTK.gtk_dialog_run(handle);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 243 */     GDK.gdk_threads_leave();
/* 244 */     display.sendPostExternalEventDispatchEvent();
/* 245 */     if ((this.style & 0x4000000) != 0) {
/* 246 */       OS.g_signal_remove_emission_hook(signalId, hookId);
/*     */     }
/* 248 */     if (GTK.gtk_window_get_modal(handle)) {
/* 249 */       display.setModalDialog(oldModal);
/*     */     }
/* 251 */     boolean success = response == -5;
/* 252 */     if (success) {
/* 253 */       int red = 0;
/* 254 */       int green = 0;
/* 255 */       int blue = 0;
/* 256 */       if (GTK.GTK_VERSION >= OS.VERSION(3, 4, 0)) {
/* 257 */         GdkRGBA rgba = new GdkRGBA();
/* 258 */         GTK.gtk_color_chooser_get_rgba(handle, rgba);
/* 259 */         red = (int)(rgba.red * 255.0D);
/* 260 */         green = (int)(rgba.green * 255.0D);
/* 261 */         blue = (int)(rgba.blue * 255.0D);
/*     */       } else {
/* 263 */         GdkColor color = new GdkColor();
/* 264 */         GTK.gtk_color_selection_get_current_color(colorsel, color);
/* 265 */         red = color.red >> 8 & 0xFF;
/* 266 */         green = color.green >> 8 & 0xFF;
/* 267 */         blue = color.blue >> 8 & 0xFF;
/*     */         
/* 269 */         long settings = GTK.gtk_settings_get_default();
/* 270 */         if (settings != 0L)
/*     */         {
/* 272 */           long[] ptr = new long[1];
/* 273 */           OS.g_object_get(settings, GTK.gtk_color_palette, ptr, 0L);
/* 274 */           if (ptr[0] != 0L) {
/* 275 */             int length = C.strlen(ptr[0]);
/* 276 */             buffer = new byte[length];
/* 277 */             C.memmove(buffer, ptr[0], length);
/* 278 */             OS.g_free(ptr[0]);
/* 279 */             String[] gdkColorStrings = null;
/* 280 */             if (length > 0) {
/* 281 */               String gtk_color_palette = new String(Converter.mbcsToWcs(buffer));
/* 282 */               gdkColorStrings = splitString(gtk_color_palette, ':');
/* 283 */               length = gdkColorStrings.length;
/*     */             }
/* 285 */             this.rgbs = new RGB[length];
/* 286 */             for (int i = 0; i < length; i++) {
/* 287 */               String colorString = gdkColorStrings[i];
/* 288 */               buffer = Converter.wcsToMbcs(colorString, true);
/* 289 */               GDK.gdk_color_parse(buffer, color);
/* 290 */               int redI = color.red >> 8 & 0xFF;
/* 291 */               int greenI = color.green >> 8 & 0xFF;
/* 292 */               int blueI = color.blue >> 8 & 0xFF;
/* 293 */               this.rgbs[i] = new RGB(redI, greenI, blueI);
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/* 298 */       this.rgb = new RGB(red, green, blue);
/*     */     }
/*     */     
/* 301 */     display.removeIdleProc();
/* 302 */     GTK.gtk_widget_destroy(handle);
/* 303 */     if (!success) { return null;
/*     */     }
/* 305 */     return this.rgb;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRGB(RGB rgb)
/*     */   {
/* 316 */     this.rgb = rgb;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 332 */   public void setRGBs(RGB[] rgbs) { this.rgbs = rgbs; }
/*     */   
/*     */   static String[] splitString(String text, char ch) {
/* 335 */     String[] substrings = new String[1];
/* 336 */     int start = 0;int pos = 0;
/* 337 */     while (pos != -1) {
/* 338 */       pos = text.indexOf(ch, start);
/* 339 */       if (pos == -1) {
/* 340 */         substrings[(substrings.length - 1)] = text.substring(start);
/*     */       } else {
/* 342 */         substrings[(substrings.length - 1)] = text.substring(start, pos);
/* 343 */         start = pos + 1;
/* 344 */         String[] newSubstrings = new String[substrings.length + 1];
/* 345 */         System.arraycopy(substrings, 0, newSubstrings, 0, substrings.length);
/* 346 */         substrings = newSubstrings;
/*     */       }
/*     */     }
/* 349 */     return substrings;
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/widgets/ColorDialog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */