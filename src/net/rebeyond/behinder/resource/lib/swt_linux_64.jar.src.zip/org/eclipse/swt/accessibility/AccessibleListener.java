/*     */ package org.eclipse.swt.accessibility;
/*     */ 
/*     */ import java.util.function.Consumer;
/*     */ import org.eclipse.swt.internal.SWTEventListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract interface AccessibleListener
/*     */   extends SWTEventListener
/*     */ {
/*     */   public abstract void getName(AccessibleEvent paramAccessibleEvent);
/*     */   
/*     */   public abstract void getHelp(AccessibleEvent paramAccessibleEvent);
/*     */   
/*     */   public abstract void getKeyboardShortcut(AccessibleEvent paramAccessibleEvent);
/*     */   
/*     */   public abstract void getDescription(AccessibleEvent paramAccessibleEvent);
/*     */   
/*     */   public static AccessibleListener getNameAdapter(Consumer<AccessibleEvent> c)
/*     */   {
/* 138 */     new AccessibleAdapter()
/*     */     {
/*     */       public void getName(AccessibleEvent e) {
/* 141 */         this.val$c.accept(e);
/*     */       }
/*     */     };
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static AccessibleListener getHelpAdapter(Consumer<AccessibleEvent> c)
/*     */   {
/* 155 */     new AccessibleAdapter()
/*     */     {
/*     */       public void getHelp(AccessibleEvent e) {
/* 158 */         this.val$c.accept(e);
/*     */       }
/*     */     };
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static AccessibleListener getKeyboardShortcutAdapter(Consumer<AccessibleEvent> c)
/*     */   {
/* 172 */     new AccessibleAdapter()
/*     */     {
/*     */       public void getKeyboardShortcut(AccessibleEvent e) {
/* 175 */         this.val$c.accept(e);
/*     */       }
/*     */     };
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static AccessibleListener getDescriptionAdapter(Consumer<AccessibleEvent> c)
/*     */   {
/* 189 */     new AccessibleAdapter()
/*     */     {
/*     */       public void getDescription(AccessibleEvent e) {
/* 192 */         this.val$c.accept(e);
/*     */       }
/*     */     };
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/accessibility/AccessibleListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */