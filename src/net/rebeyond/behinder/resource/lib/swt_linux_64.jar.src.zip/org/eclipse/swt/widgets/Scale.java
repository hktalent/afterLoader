/*     */ package org.eclipse.swt.widgets;
/*     */ 
/*     */ import org.eclipse.swt.events.SelectionListener;
/*     */ import org.eclipse.swt.graphics.Point;
/*     */ import org.eclipse.swt.internal.gtk.GTK;
/*     */ import org.eclipse.swt.internal.gtk.GtkRequisition;
/*     */ import org.eclipse.swt.internal.gtk.OS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Scale
/*     */   extends Control
/*     */ {
/*     */   public Scale(Composite parent, int style)
/*     */   {
/*  73 */     super(parent, checkStyle(style));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addSelectionListener(SelectionListener listener)
/*     */   {
/* 100 */     checkWidget();
/* 101 */     if (listener == null) error(4);
/* 102 */     TypedListener typedListener = new TypedListener(listener);
/* 103 */     addListener(13, typedListener);
/* 104 */     addListener(14, typedListener);
/*     */   }
/*     */   
/*     */   static int checkStyle(int style) {
/* 108 */     return checkBits(style, 256, 512, 0, 0, 0, 0);
/*     */   }
/*     */   
/*     */   Point computeSizeInPixels(int wHint, int hHint, boolean changed)
/*     */   {
/* 113 */     checkWidget();
/* 114 */     if ((wHint != -1) && (wHint < 0)) wHint = 0;
/* 115 */     if ((hHint != -1) && (hHint < 0)) hHint = 0;
/* 116 */     Point size = computeNativeSize(this.handle, wHint, hHint, changed);
/* 117 */     if ((this.style & 0x100) != 0) {
/* 118 */       if (wHint == -1) size.x = (2 * size.x);
/*     */     }
/* 120 */     else if (hHint == -1) { size.y = (2 * size.y);
/*     */     }
/* 122 */     return size;
/*     */   }
/*     */   
/*     */   void createHandle(int index)
/*     */   {
/* 127 */     this.state |= 0x10008;
/* 128 */     this.fixedHandle = OS.g_object_new(this.display.gtk_fixed_get_type(), 0L);
/* 129 */     if (this.fixedHandle == 0L) error(2);
/* 130 */     GTK.gtk_widget_set_has_window(this.fixedHandle, true);
/* 131 */     long hAdjustment = GTK.gtk_adjustment_new(0.0D, 0.0D, 100.0D, 1.0D, 10.0D, 0.0D);
/* 132 */     if (hAdjustment == 0L) error(2);
/* 133 */     if ((this.style & 0x100) != 0) {
/* 134 */       this.handle = gtk_scale_new(0, hAdjustment);
/*     */     } else {
/* 136 */       this.handle = gtk_scale_new(1, hAdjustment);
/*     */     }
/* 138 */     if (this.handle == 0L) error(2);
/* 139 */     GTK.gtk_container_add(this.fixedHandle, this.handle);
/* 140 */     GTK.gtk_scale_set_digits(this.handle, 0);
/* 141 */     GTK.gtk_scale_set_draw_value(this.handle, false);
/*     */   }
/*     */   
/*     */   void hookEvents()
/*     */   {
/* 146 */     super.hookEvents();
/* 147 */     OS.g_signal_connect_closure(this.handle, OS.value_changed, this.display.getClosure(57), false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getIncrement()
/*     */   {
/* 163 */     checkWidget();
/* 164 */     long hAdjustment = GTK.gtk_range_get_adjustment(this.handle);
/* 165 */     return (int)GTK.gtk_adjustment_get_step_increment(hAdjustment);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getMaximum()
/*     */   {
/* 179 */     checkWidget();
/* 180 */     long hAdjustment = GTK.gtk_range_get_adjustment(this.handle);
/* 181 */     return (int)GTK.gtk_adjustment_get_upper(hAdjustment);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getMinimum()
/*     */   {
/* 195 */     checkWidget();
/* 196 */     long hAdjustment = GTK.gtk_range_get_adjustment(this.handle);
/* 197 */     return (int)GTK.gtk_adjustment_get_lower(hAdjustment);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getPageIncrement()
/*     */   {
/* 213 */     checkWidget();
/* 214 */     long hAdjustment = GTK.gtk_range_get_adjustment(this.handle);
/* 215 */     return (int)GTK.gtk_adjustment_get_page_increment(hAdjustment);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getSelection()
/*     */   {
/* 229 */     checkWidget();
/* 230 */     long hAdjustment = GTK.gtk_range_get_adjustment(this.handle);
/* 231 */     return (int)GTK.gtk_adjustment_get_value(hAdjustment);
/*     */   }
/*     */   
/*     */   long gtk_value_changed(long adjustment)
/*     */   {
/* 236 */     sendSelectionEvent(13);
/* 237 */     return 0L;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeSelectionListener(SelectionListener listener)
/*     */   {
/* 258 */     checkWidget();
/* 259 */     if (listener == null) error(4);
/* 260 */     if (this.eventTable == null) return;
/* 261 */     this.eventTable.unhook(13, listener);
/* 262 */     this.eventTable.unhook(14, listener);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setIncrement(int increment)
/*     */   {
/* 279 */     checkWidget();
/* 280 */     if (increment < 1) return;
/* 281 */     OS.g_signal_handlers_block_matched(this.handle, 16, 0, 0, 0L, 0L, 57L);
/* 282 */     GTK.gtk_range_set_increments(this.handle, increment, getPageIncrement());
/* 283 */     OS.g_signal_handlers_unblock_matched(this.handle, 16, 0, 0, 0L, 0L, 57L);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMaximum(int value)
/*     */   {
/* 300 */     checkWidget();
/* 301 */     int minimum = getMinimum();
/* 302 */     if (value <= minimum) return;
/* 303 */     OS.g_signal_handlers_block_matched(this.handle, 16, 0, 0, 0L, 0L, 57L);
/* 304 */     GTK.gtk_range_set_range(this.handle, minimum, value);
/* 305 */     OS.g_signal_handlers_unblock_matched(this.handle, 16, 0, 0, 0L, 0L, 57L);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMinimum(int value)
/*     */   {
/* 322 */     checkWidget();
/* 323 */     if (value < 0) return;
/* 324 */     int maximum = getMaximum();
/* 325 */     if (value >= maximum) return;
/* 326 */     OS.g_signal_handlers_block_matched(this.handle, 16, 0, 0, 0L, 0L, 57L);
/* 327 */     GTK.gtk_range_set_range(this.handle, value, maximum);
/* 328 */     OS.g_signal_handlers_unblock_matched(this.handle, 16, 0, 0, 0L, 0L, 57L);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPageIncrement(int pageIncrement)
/*     */   {
/* 345 */     checkWidget();
/* 346 */     if (pageIncrement < 1) return;
/* 347 */     OS.g_signal_handlers_block_matched(this.handle, 16, 0, 0, 0L, 0L, 57L);
/* 348 */     GTK.gtk_range_set_increments(this.handle, getIncrement(), pageIncrement);
/* 349 */     OS.g_signal_handlers_unblock_matched(this.handle, 16, 0, 0, 0L, 0L, 57L);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSelection(int value)
/*     */   {
/* 364 */     checkWidget();
/* 365 */     OS.g_signal_handlers_block_matched(this.handle, 16, 0, 0, 0L, 0L, 57L);
/* 366 */     GTK.gtk_range_set_value(this.handle, value);
/* 367 */     OS.g_signal_handlers_unblock_matched(this.handle, 16, 0, 0, 0L, 0L, 57L);
/*     */   }
/*     */   
/*     */   long gtk_scale_new(int orientation, long adjustment) {
/* 371 */     long scale = 0L;
/* 372 */     if (GTK.GTK3) {
/* 373 */       scale = GTK.gtk_scale_new(orientation, adjustment);
/*     */     }
/* 375 */     else if (orientation == 0) {
/* 376 */       scale = GTK.gtk_hscale_new(adjustment);
/*     */     } else {
/* 378 */       scale = GTK.gtk_vscale_new(adjustment);
/*     */     }
/*     */     
/* 381 */     return scale;
/*     */   }
/*     */   
/*     */   Point resizeCalculationsGTK3(long widget, int width, int height)
/*     */   {
/* 386 */     Point size = super.resizeCalculationsGTK3(widget, width, height);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 395 */     if ((widget == this.handle) && (GTK.GTK_VERSION >= OS.VERSION(3, 20, 0))) {
/* 396 */       GtkRequisition naturalSize = new GtkRequisition();
/* 397 */       GtkRequisition minimumSize = new GtkRequisition();
/* 398 */       GTK.gtk_widget_get_preferred_size(this.handle, minimumSize, naturalSize);
/* 399 */       if ((this.style & 0x200) != 0) {
/* 400 */         size.x = Math.max(size.x, minimumSize.width);
/*     */       }
/* 402 */       if ((this.style & 0x100) != 0) {
/* 403 */         size.y = Math.max(size.y, minimumSize.height);
/*     */       }
/*     */     }
/* 406 */     return size;
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/widgets/Scale.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */