/*     */ package org.eclipse.swt.internal.image;
/*     */ 
/*     */ 
/*     */ 
/*     */ final class JPEGHuffmanTable
/*     */   extends JPEGVariableSizeSegment
/*     */ {
/*     */   JPEGHuffmanTable[] allTables;
/*     */   
/*     */ 
/*     */   int tableClass;
/*     */   
/*     */ 
/*     */   int tableIdentifier;
/*     */   
/*     */ 
/*     */   int[] dhMaxCodes;
/*     */   
/*     */ 
/*     */   int[] dhMinCodes;
/*     */   
/*     */ 
/*     */   int[] dhValPtrs;
/*     */   
/*     */ 
/*     */   int[] dhValues;
/*     */   
/*     */ 
/*     */   int[] ehCodes;
/*     */   
/*     */ 
/*     */   byte[] ehCodeLengths;
/*     */   
/*  34 */   static byte[] DCLuminanceTable = { -1, -60, 0, 31, 0, 0, 1, 5, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11 };
/*     */   
/*     */ 
/*     */ 
/*  38 */   static byte[] DCChrominanceTable = { -1, -60, 0, 31, 1, 0, 3, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11 };
/*     */   
/*     */ 
/*     */ 
/*  42 */   static byte[] ACLuminanceTable = { -1, -60, 0, -75, 16, 0, 2, 1, 3, 3, 2, 4, 3, 5, 5, 4, 4, 0, 0, 1, 125, 1, 2, 3, 0, 4, 17, 5, 18, 33, 49, 65, 6, 19, 81, 97, 7, 34, 113, 20, 50, -127, -111, -95, 8, 35, 66, -79, -63, 21, 82, -47, -16, 36, 51, 98, 114, -126, 9, 10, 22, 23, 24, 25, 26, 37, 38, 39, 40, 41, 42, 52, 53, 54, 55, 56, 57, 58, 67, 68, 69, 70, 71, 72, 73, 74, 83, 84, 85, 86, 87, 88, 89, 90, 99, 100, 101, 102, 103, 104, 105, 106, 115, 116, 117, 118, 119, 120, 121, 122, -125, -124, -123, -122, -121, -120, -119, -118, -110, -109, -108, -107, -106, -105, -104, -103, -102, -94, -93, -92, -91, -90, -89, -88, -87, -86, -78, -77, -76, -75, -74, -73, -72, -71, -70, -62, -61, -60, -59, -58, -57, -56, -55, -54, -46, -45, -44, -43, -42, -41, -40, -39, -38, -31, -30, -29, -28, -27, -26, -25, -24, -23, -22, -15, -14, -13, -12, -11, -10, -9, -8, -7, -6 };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  56 */   static byte[] ACChrominanceTable = { -1, -60, 0, -75, 17, 0, 2, 1, 2, 4, 4, 3, 4, 7, 5, 4, 4, 0, 1, 2, 119, 0, 1, 2, 3, 17, 4, 5, 33, 49, 6, 18, 65, 81, 7, 97, 113, 19, 34, 50, -127, 8, 20, 66, -111, -95, -79, -63, 9, 35, 51, 82, -16, 21, 98, 114, -47, 10, 22, 36, 52, -31, 37, -15, 23, 24, 25, 26, 38, 39, 40, 41, 42, 53, 54, 55, 56, 57, 58, 67, 68, 69, 70, 71, 72, 73, 74, 83, 84, 85, 86, 87, 88, 89, 90, 99, 100, 101, 102, 103, 104, 105, 106, 115, 116, 117, 118, 119, 120, 121, 122, -126, -125, -124, -123, -122, -121, -120, -119, -118, -110, -109, -108, -107, -106, -105, -104, -103, -102, -94, -93, -92, -91, -90, -89, -88, -87, -86, -78, -77, -76, -75, -74, -73, -72, -71, -70, -62, -61, -60, -59, -58, -57, -56, -55, -54, -46, -45, -44, -43, -42, -41, -40, -39, -38, -30, -29, -28, -27, -26, -25, -24, -23, -22, -14, -13, -12, -11, -10, -9, -8, -7, -6 };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public JPEGHuffmanTable(byte[] reference)
/*     */   {
/*  78 */     super(reference);
/*     */   }
/*     */   
/*     */   public JPEGHuffmanTable(LEDataInputStream byteStream) {
/*  82 */     super(byteStream);
/*  83 */     initialize();
/*     */   }
/*     */   
/*     */   public JPEGHuffmanTable[] getAllTables() {
/*  87 */     return this.allTables;
/*     */   }
/*     */   
/*     */   public static JPEGHuffmanTable getDefaultACChrominanceTable() {
/*  91 */     JPEGHuffmanTable result = new JPEGHuffmanTable(ACChrominanceTable);
/*  92 */     result.initialize();
/*  93 */     return result;
/*     */   }
/*     */   
/*     */   public static JPEGHuffmanTable getDefaultACLuminanceTable() {
/*  97 */     JPEGHuffmanTable result = new JPEGHuffmanTable(ACLuminanceTable);
/*  98 */     result.initialize();
/*  99 */     return result;
/*     */   }
/*     */   
/*     */   public static JPEGHuffmanTable getDefaultDCChrominanceTable() {
/* 103 */     JPEGHuffmanTable result = new JPEGHuffmanTable(DCChrominanceTable);
/* 104 */     result.initialize();
/* 105 */     return result;
/*     */   }
/*     */   
/*     */   public static JPEGHuffmanTable getDefaultDCLuminanceTable() {
/* 109 */     JPEGHuffmanTable result = new JPEGHuffmanTable(DCLuminanceTable);
/* 110 */     result.initialize();
/* 111 */     return result;
/*     */   }
/*     */   
/*     */   public int[] getDhMaxCodes() {
/* 115 */     return this.dhMaxCodes;
/*     */   }
/*     */   
/*     */   public int[] getDhMinCodes() {
/* 119 */     return this.dhMinCodes;
/*     */   }
/*     */   
/*     */   public int[] getDhValPtrs() {
/* 123 */     return this.dhValPtrs;
/*     */   }
/*     */   
/*     */   public int[] getDhValues() {
/* 127 */     return this.dhValues;
/*     */   }
/*     */   
/*     */   public int getTableClass() {
/* 131 */     return this.tableClass;
/*     */   }
/*     */   
/*     */   public int getTableIdentifier() {
/* 135 */     return this.tableIdentifier;
/*     */   }
/*     */   
/*     */   void initialize() {
/* 139 */     int totalLength = getSegmentLength() - 2;
/* 140 */     int ofs = 4;
/* 141 */     int[] bits = new int[16];
/* 142 */     JPEGHuffmanTable[] huffTables = new JPEGHuffmanTable[8];
/* 143 */     int huffTableCount = 0;
/* 144 */     while (totalLength > 0) {
/* 145 */       int tc = (this.reference[ofs] & 0xFF) >> 4;
/* 146 */       int tid = this.reference[ofs] & 0xF;
/* 147 */       ofs++;
/*     */       
/*     */ 
/* 150 */       int count = 0;
/* 151 */       for (int i = 0; i < bits.length; i++) {
/* 152 */         int bCount = this.reference[(ofs + i)] & 0xFF;
/* 153 */         bits[i] = bCount;
/* 154 */         count += bCount;
/*     */       }
/* 156 */       ofs += 16;
/* 157 */       totalLength -= 17;
/*     */       
/*     */ 
/* 160 */       int[] huffVals = new int[count];
/* 161 */       for (int i = 0; i < count; i++) {
/* 162 */         huffVals[i] = (this.reference[(ofs + i)] & 0xFF);
/*     */       }
/* 164 */       ofs += count;
/* 165 */       totalLength -= count;
/*     */       
/*     */ 
/* 168 */       int[] huffCodeLengths = new int[50];
/* 169 */       int huffCodeLengthsIndex = 0;
/* 170 */       for (int i = 0; i < 16; i++) {
/* 171 */         for (int j = 0; j < bits[i]; j++) {
/* 172 */           if (huffCodeLengthsIndex >= huffCodeLengths.length) {
/* 173 */             int[] newHuffCodeLengths = new int[huffCodeLengths.length + 50];
/* 174 */             System.arraycopy(huffCodeLengths, 0, newHuffCodeLengths, 0, huffCodeLengths.length);
/* 175 */             huffCodeLengths = newHuffCodeLengths;
/*     */           }
/* 177 */           huffCodeLengths[huffCodeLengthsIndex] = (i + 1);
/* 178 */           huffCodeLengthsIndex++;
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 183 */       if (huffCodeLengthsIndex < huffCodeLengths.length) {
/* 184 */         int[] newHuffCodeLengths = new int[huffCodeLengthsIndex];
/* 185 */         System.arraycopy(huffCodeLengths, 0, newHuffCodeLengths, 0, huffCodeLengthsIndex);
/* 186 */         huffCodeLengths = newHuffCodeLengths;
/*     */       }
/*     */       
/*     */ 
/* 190 */       int[] huffCodes = new int[50];
/* 191 */       int huffCodesIndex = 0;
/* 192 */       int k = 1;
/* 193 */       int code = 0;
/* 194 */       int si = huffCodeLengths[0];
/* 195 */       int p = 0;
/* 196 */       while (p < huffCodeLengthsIndex) {
/* 197 */         while ((p < huffCodeLengthsIndex) && (huffCodeLengths[p] == si)) {
/* 198 */           if (huffCodesIndex >= huffCodes.length) {
/* 199 */             int[] newHuffCodes = new int[huffCodes.length + 50];
/* 200 */             System.arraycopy(huffCodes, 0, newHuffCodes, 0, huffCodes.length);
/* 201 */             huffCodes = newHuffCodes;
/*     */           }
/* 203 */           huffCodes[huffCodesIndex] = code;
/* 204 */           huffCodesIndex++;
/* 205 */           code++;
/* 206 */           p++;
/*     */         }
/* 208 */         code *= 2;
/* 209 */         si++;
/*     */       }
/*     */       
/*     */ 
/* 213 */       if (huffCodesIndex < huffCodes.length) {
/* 214 */         int[] newHuffCodes = new int[huffCodesIndex];
/* 215 */         System.arraycopy(huffCodes, 0, newHuffCodes, 0, huffCodesIndex);
/* 216 */         huffCodes = newHuffCodes;
/*     */       }
/*     */       
/*     */ 
/* 220 */       k = 0;
/* 221 */       int[] maxCodes = new int[16];
/* 222 */       int[] minCodes = new int[16];
/* 223 */       int[] valPtrs = new int[16];
/* 224 */       for (int i = 0; i < 16; i++) {
/* 225 */         int bSize = bits[i];
/* 226 */         if (bSize == 0) {
/* 227 */           maxCodes[i] = -1;
/*     */         } else {
/* 229 */           valPtrs[i] = k;
/* 230 */           minCodes[i] = huffCodes[k];
/* 231 */           k += bSize;
/* 232 */           maxCodes[i] = huffCodes[(k - 1)];
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 237 */       int[] eHuffCodes = new int['Ā'];
/* 238 */       byte[] eHuffSize = new byte['Ā'];
/* 239 */       for (int i = 0; i < huffCodesIndex; i++) {
/* 240 */         eHuffCodes[huffVals[i]] = huffCodes[i];
/* 241 */         eHuffSize[huffVals[i]] = ((byte)huffCodeLengths[i]);
/*     */       }
/*     */       
/*     */ 
/* 245 */       JPEGHuffmanTable dhtTable = new JPEGHuffmanTable(this.reference);
/* 246 */       dhtTable.tableClass = tc;
/* 247 */       dhtTable.tableIdentifier = tid;
/* 248 */       dhtTable.dhValues = huffVals;
/* 249 */       dhtTable.dhMinCodes = minCodes;
/* 250 */       dhtTable.dhMaxCodes = maxCodes;
/* 251 */       dhtTable.dhValPtrs = valPtrs;
/* 252 */       dhtTable.ehCodes = eHuffCodes;
/* 253 */       dhtTable.ehCodeLengths = eHuffSize;
/* 254 */       huffTables[huffTableCount] = dhtTable;
/* 255 */       huffTableCount++;
/*     */     }
/* 257 */     this.allTables = new JPEGHuffmanTable[huffTableCount];
/* 258 */     System.arraycopy(huffTables, 0, this.allTables, 0, huffTableCount);
/*     */   }
/*     */   
/*     */   public int signature()
/*     */   {
/* 263 */     return 65476;
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/internal/image/JPEGHuffmanTable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */