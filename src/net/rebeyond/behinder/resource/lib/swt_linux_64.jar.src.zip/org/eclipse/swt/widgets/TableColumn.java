/*     */ package org.eclipse.swt.widgets;
/*     */ 
/*     */ import org.eclipse.swt.events.ControlListener;
/*     */ import org.eclipse.swt.events.SelectionListener;
/*     */ import org.eclipse.swt.graphics.Image;
/*     */ import org.eclipse.swt.internal.Converter;
/*     */ import org.eclipse.swt.internal.DPIUtil;
/*     */ import org.eclipse.swt.internal.ImageList;
/*     */ import org.eclipse.swt.internal.gtk.GDK;
/*     */ import org.eclipse.swt.internal.gtk.GTK;
/*     */ import org.eclipse.swt.internal.gtk.GdkEvent;
/*     */ import org.eclipse.swt.internal.gtk.GdkEventButton;
/*     */ import org.eclipse.swt.internal.gtk.GtkAllocation;
/*     */ import org.eclipse.swt.internal.gtk.GtkRequisition;
/*     */ import org.eclipse.swt.internal.gtk.OS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TableColumn
/*     */   extends Item
/*     */ {
/*     */   long labelHandle;
/*     */   long imageHandle;
/*     */   long buttonHandle;
/*     */   Table parent;
/*     */   int modelIndex;
/*     */   int lastButton;
/*     */   int lastTime;
/*     */   int lastX;
/*     */   int lastWidth;
/*     */   boolean customDraw;
/*     */   boolean useFixedWidth;
/*     */   String toolTipText;
/*     */   
/*     */   public TableColumn(Table parent, int style)
/*     */   {
/*  78 */     super(parent, checkStyle(style));
/*  79 */     this.parent = parent;
/*  80 */     createWidget(parent.getColumnCount());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TableColumn(Table parent, int style, int index)
/*     */   {
/* 121 */     super(parent, checkStyle(style));
/* 122 */     this.parent = parent;
/* 123 */     createWidget(index);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addControlListener(ControlListener listener)
/*     */   {
/* 146 */     checkWidget();
/* 147 */     if (listener == null) error(4);
/* 148 */     TypedListener typedListener = new TypedListener(listener);
/* 149 */     addListener(11, typedListener);
/* 150 */     addListener(10, typedListener);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addSelectionListener(SelectionListener listener)
/*     */   {
/* 178 */     checkWidget();
/* 179 */     if (listener == null) error(4);
/* 180 */     TypedListener typedListener = new TypedListener(listener);
/* 181 */     addListener(13, typedListener);
/* 182 */     addListener(14, typedListener);
/*     */   }
/*     */   
/*     */   static int checkStyle(int style) {
/* 186 */     return checkBits(style, 16384, 16777216, 131072, 0, 0, 0);
/*     */   }
/*     */   
/*     */   protected void checkSubclass()
/*     */   {
/* 191 */     if (!isValidSubclass()) error(43);
/*     */   }
/*     */   
/*     */   void createWidget(int index)
/*     */   {
/* 196 */     this.parent.createItem(this, index);
/* 197 */     setOrientation(true);
/* 198 */     hookEvents();
/* 199 */     register();
/* 200 */     this.text = "";
/*     */   }
/*     */   
/*     */   void deregister()
/*     */   {
/* 205 */     super.deregister();
/* 206 */     this.display.removeWidget(this.handle);
/* 207 */     if (this.buttonHandle != 0L) this.display.removeWidget(this.buttonHandle);
/* 208 */     if (this.labelHandle != 0L) this.display.removeWidget(this.labelHandle);
/*     */   }
/*     */   
/*     */   void destroyWidget()
/*     */   {
/* 213 */     this.parent.destroyItem(this);
/* 214 */     releaseHandle();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getAlignment()
/*     */   {
/* 230 */     checkWidget();
/* 231 */     if ((this.style & 0x4000) != 0) return 16384;
/* 232 */     if ((this.style & 0x1000000) != 0) return 16777216;
/* 233 */     if ((this.style & 0x20000) != 0) return 131072;
/* 234 */     return 16384;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getMoveable()
/*     */   {
/* 258 */     checkWidget();
/* 259 */     return GTK.gtk_tree_view_column_get_reorderable(this.handle);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Table getParent()
/*     */   {
/* 273 */     checkWidget();
/* 274 */     return this.parent;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getResizable()
/*     */   {
/* 290 */     checkWidget();
/* 291 */     return GTK.gtk_tree_view_column_get_resizable(this.handle);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getToolTipText()
/*     */   {
/* 308 */     checkWidget();
/* 309 */     return this.toolTipText;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getWidth()
/*     */   {
/* 323 */     checkWidget();
/* 324 */     return DPIUtil.autoScaleDown(getWidthInPixels());
/*     */   }
/*     */   
/*     */   int getWidthInPixels() {
/* 328 */     checkWidget();
/* 329 */     if (!GTK.gtk_tree_view_column_get_visible(this.handle)) {
/* 330 */       return 0;
/*     */     }
/* 332 */     if (this.useFixedWidth) return GTK.gtk_tree_view_column_get_fixed_width(this.handle);
/* 333 */     return GTK.gtk_tree_view_column_get_width(this.handle);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   long gtk_clicked(long widget)
/*     */   {
/* 345 */     boolean doubleClick = false;
/* 346 */     boolean postEvent = true;
/* 347 */     long eventPtr = GTK.gtk_get_current_event();
/* 348 */     if (eventPtr != 0L) {
/* 349 */       GdkEventButton gdkEvent = new GdkEventButton();
/* 350 */       OS.memmove(gdkEvent, eventPtr, GdkEventButton.sizeof);
/* 351 */       GDK.gdk_event_free(eventPtr);
/* 352 */       switch (gdkEvent.type) {
/*     */       case 7: 
/* 354 */         int clickTime = this.display.getDoubleClickTime();
/* 355 */         int eventTime = gdkEvent.time;int eventButton = gdkEvent.button;
/* 356 */         if ((this.lastButton == eventButton) && (this.lastTime != 0) && (Math.abs(this.lastTime - eventTime) <= clickTime)) {
/* 357 */           doubleClick = true;
/*     */         }
/* 359 */         this.lastTime = (eventTime == 0 ? 1 : eventTime);
/* 360 */         this.lastButton = eventButton;
/* 361 */         break;
/*     */       }
/*     */       
/*     */     }
/* 365 */     if (postEvent) sendSelectionEvent(doubleClick ? 14 : 13);
/* 366 */     return 0L;
/*     */   }
/*     */   
/*     */   long gtk_event_after(long widget, long gdkEvent)
/*     */   {
/* 371 */     GdkEvent event = new GdkEvent();
/* 372 */     OS.memmove(event, gdkEvent, GdkEvent.sizeof);
/* 373 */     switch (event.type) {
/*     */     case 4: 
/* 375 */       GdkEventButton gdkEventButton = new GdkEventButton();
/* 376 */       OS.memmove(gdkEventButton, gdkEvent, GdkEventButton.sizeof);
/* 377 */       if (gdkEventButton.button == 3) {
/* 378 */         this.parent.showMenu((int)gdkEventButton.x_root, (int)gdkEventButton.y_root);
/*     */       }
/*     */       break;
/*     */     }
/*     */     
/* 383 */     return 0L;
/*     */   }
/*     */   
/*     */   long gtk_mnemonic_activate(long widget, long arg1)
/*     */   {
/* 388 */     return this.parent.gtk_mnemonic_activate(widget, arg1);
/*     */   }
/*     */   
/*     */   long gtk_size_allocate(long widget, long allocation)
/*     */   {
/* 393 */     this.useFixedWidth = false;
/* 394 */     GtkAllocation widgetAllocation = new GtkAllocation();
/* 395 */     GTK.gtk_widget_get_allocation(widget, widgetAllocation);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 402 */     boolean minimumResizeSignal = (widgetAllocation.width == 1) && (widgetAllocation.height == 1);
/* 403 */     boolean movingSignal = (widgetAllocation.x == 0) && (widgetAllocation.y == 0);
/* 404 */     int x = widgetAllocation.x;
/* 405 */     int width = widgetAllocation.width;
/* 406 */     if ((x != this.lastX) && (!movingSignal)) {
/* 407 */       this.lastX = x;
/* 408 */       sendEvent(10);
/*     */     }
/* 410 */     if ((width != this.lastWidth) && (!minimumResizeSignal)) {
/* 411 */       this.lastWidth = width;
/* 412 */       sendEvent(11);
/*     */     }
/* 414 */     return 0L;
/*     */   }
/*     */   
/*     */   void hookEvents()
/*     */   {
/* 419 */     super.hookEvents();
/* 420 */     OS.g_signal_connect_closure(this.handle, OS.clicked, this.display.getClosure(8), false);
/* 421 */     if (this.buttonHandle != 0L) {
/* 422 */       OS.g_signal_connect_closure_by_id(this.buttonHandle, this.display.signalIds[47], 0, this.display.getClosure(47), false);
/* 423 */       OS.g_signal_connect_closure_by_id(this.buttonHandle, this.display.signalIds[16], 0, this.display.getClosure(16), false);
/*     */     }
/* 425 */     if (this.labelHandle != 0L) { OS.g_signal_connect_closure_by_id(this.labelHandle, this.display.signalIds[32], 0, this.display.getClosure(32), false);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void pack()
/*     */   {
/* 440 */     checkWidget();
/* 441 */     int width = 0;
/* 442 */     if (this.buttonHandle != 0L) {
/* 443 */       GtkRequisition requisition = new GtkRequisition();
/* 444 */       if ((this.parent.getHeaderVisible()) && (GTK.GTK_VERSION >= OS.VERSION(3, 8, 0)) && (!GTK.gtk_widget_get_visible(this.buttonHandle))) {
/* 445 */         GTK.gtk_widget_show(this.buttonHandle);
/* 446 */         gtk_widget_get_preferred_size(this.buttonHandle, requisition);
/* 447 */         GTK.gtk_widget_hide(this.buttonHandle);
/*     */       } else {
/* 449 */         gtk_widget_get_preferred_size(this.buttonHandle, requisition);
/*     */       }
/* 451 */       width = requisition.width;
/*     */     }
/* 453 */     if ((this.parent.style & 0x10000000) != 0) {
/* 454 */       for (int i = 0; i < this.parent.items.length; i++) {
/* 455 */         TableItem item = this.parent.items[i];
/* 456 */         if ((item != null) && (item.cached)) {
/* 457 */           width = Math.max(width, this.parent.calculateWidth(this.handle, item.handle));
/*     */         }
/*     */       }
/*     */     } else {
/* 461 */       long iter = OS.g_malloc(GTK.GtkTreeIter_sizeof());
/* 462 */       if (GTK.gtk_tree_model_get_iter_first(this.parent.modelHandle, iter)) {
/*     */         do {
/* 464 */           width = Math.max(width, this.parent.calculateWidth(this.handle, iter));
/* 465 */         } while (GTK.gtk_tree_model_iter_next(this.parent.modelHandle, iter));
/*     */       }
/* 467 */       OS.g_free(iter);
/*     */     }
/* 469 */     setWidthInPixels(width);
/*     */   }
/*     */   
/*     */   void register()
/*     */   {
/* 474 */     super.register();
/* 475 */     this.display.addWidget(this.handle, this);
/* 476 */     if (this.buttonHandle != 0L) this.display.addWidget(this.buttonHandle, this);
/* 477 */     if (this.labelHandle != 0L) this.display.addWidget(this.labelHandle, this);
/*     */   }
/*     */   
/*     */   void releaseHandle()
/*     */   {
/* 482 */     super.releaseHandle();
/* 483 */     this.handle = (this.buttonHandle = this.labelHandle = this.imageHandle = 0L);
/* 484 */     this.modelIndex = -1;
/* 485 */     this.parent = null;
/*     */   }
/*     */   
/*     */   void releaseParent()
/*     */   {
/* 490 */     super.releaseParent();
/* 491 */     if (this.parent.sortColumn == this) {
/* 492 */       this.parent.sortColumn = null;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeControlListener(ControlListener listener)
/*     */   {
/* 514 */     checkWidget();
/* 515 */     if (listener == null) error(4);
/* 516 */     if (this.eventTable == null) return;
/* 517 */     this.eventTable.unhook(10, listener);
/* 518 */     this.eventTable.unhook(11, listener);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeSelectionListener(SelectionListener listener)
/*     */   {
/* 539 */     checkWidget();
/* 540 */     if (listener == null) error(4);
/* 541 */     if (this.eventTable == null) return;
/* 542 */     this.eventTable.unhook(13, listener);
/* 543 */     this.eventTable.unhook(14, listener);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAlignment(int alignment)
/*     */   {
/* 562 */     checkWidget();
/* 563 */     if ((alignment & 0x1024000) == 0) return;
/* 564 */     int index = this.parent.indexOf(this);
/* 565 */     if ((index == -1) || (index == 0)) return;
/* 566 */     this.style &= 0xFEFDBFFF;
/* 567 */     this.style |= alignment & 0x1024000;
/* 568 */     this.parent.createRenderers(this.handle, this.modelIndex, index == 0, this.style);
/*     */   }
/*     */   
/*     */   void setFontDescription(long font) {
/* 572 */     setFontDescription(this.labelHandle, font);
/* 573 */     setFontDescription(this.imageHandle, font);
/*     */   }
/*     */   
/*     */   public void setImage(Image image)
/*     */   {
/* 578 */     checkWidget();
/* 579 */     super.setImage(image);
/* 580 */     if (image != null) {
/* 581 */       ImageList headerImageList = this.parent.headerImageList;
/* 582 */       if (headerImageList == null) {
/* 583 */         headerImageList = this.parent.headerImageList = new ImageList();
/*     */       }
/* 585 */       int imageIndex = headerImageList.indexOf(image);
/* 586 */       if (imageIndex == -1) imageIndex = headerImageList.add(image);
/* 587 */       long pixbuf = headerImageList.getPixbuf(imageIndex);
/* 588 */       gtk_image_set_from_pixbuf(this.imageHandle, pixbuf);
/* 589 */       GTK.gtk_widget_show(this.imageHandle);
/*     */     } else {
/* 591 */       gtk_image_set_from_pixbuf(this.imageHandle, 0L);
/* 592 */       GTK.gtk_widget_hide(this.imageHandle);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setResizable(boolean resizable)
/*     */   {
/* 611 */     checkWidget();
/* 612 */     GTK.gtk_tree_view_column_set_resizable(this.handle, resizable);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMoveable(boolean moveable)
/*     */   {
/* 637 */     checkWidget();
/* 638 */     GTK.gtk_tree_view_column_set_reorderable(this.handle, moveable);
/*     */   }
/*     */   
/*     */   void setOrientation(boolean create)
/*     */   {
/* 643 */     if ((((this.parent.style & 0x4000000) != 0) || (!create)) && 
/* 644 */       (this.buttonHandle != 0L)) {
/* 645 */       int dir = (this.parent.style & 0x4000000) != 0 ? 2 : 1;
/* 646 */       GTK.gtk_widget_set_direction(this.buttonHandle, dir);
/* 647 */       GTK.gtk_container_forall(this.buttonHandle, this.display.setDirectionProc, dir);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void setText(String string)
/*     */   {
/* 654 */     checkWidget();
/* 655 */     if (string == null) error(4);
/* 656 */     super.setText(string);
/* 657 */     char[] chars = fixMnemonic(string);
/* 658 */     byte[] buffer = Converter.wcsToMbcs(chars, true);
/* 659 */     GTK.gtk_label_set_text_with_mnemonic(this.labelHandle, buffer);
/* 660 */     if (string.length() != 0) {
/* 661 */       GTK.gtk_widget_show(this.labelHandle);
/*     */     } else {
/* 663 */       GTK.gtk_widget_hide(this.labelHandle);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setToolTipText(String string)
/*     */   {
/* 695 */     checkWidget();
/* 696 */     Shell shell = this.parent._getShell();
/* 697 */     setToolTipText(shell, string);
/* 698 */     this.toolTipText = string;
/*     */   }
/*     */   
/*     */   void setToolTipText(Shell shell, String newString) {
/* 702 */     shell.setToolTipText(this.buttonHandle, newString);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setWidth(int width)
/*     */   {
/* 716 */     checkWidget();
/* 717 */     setWidthInPixels(DPIUtil.autoScaleUp(width));
/*     */   }
/*     */   
/*     */   void setWidthInPixels(int width) {
/* 721 */     checkWidget();
/* 722 */     if (width < 0) return;
/* 723 */     if (width == this.lastWidth) return;
/* 724 */     if (width > 0) {
/* 725 */       this.useFixedWidth = true;
/* 726 */       GTK.gtk_tree_view_column_set_fixed_width(this.handle, width);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 733 */     if (width != 0) GTK.gtk_widget_realize(this.parent.handle);
/* 734 */     GTK.gtk_tree_view_column_set_visible(this.handle, width != 0);
/* 735 */     this.lastWidth = width;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 743 */     if ((width != 0) && 
/* 744 */       (this.buttonHandle != 0L)) {
/* 745 */       long window = GTK.gtk_widget_get_parent_window(this.buttonHandle);
/* 746 */       if (window != 0L) {
/* 747 */         long windowList = GDK.gdk_window_get_children(window);
/* 748 */         if (windowList != 0L) {
/* 749 */           long windows = windowList;
/* 750 */           long[] userData = new long[1];
/* 751 */           while (windows != 0L) {
/* 752 */             long child = OS.g_list_data(windows);
/* 753 */             GDK.gdk_window_get_user_data(child, userData);
/* 754 */             if (userData[0] == this.buttonHandle) {
/* 755 */               GDK.gdk_window_lower(child);
/* 756 */               break;
/*     */             }
/* 758 */             windows = OS.g_list_next(windows);
/*     */           }
/* 760 */           OS.g_list_free(windowList);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 765 */     sendEvent(11);
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/widgets/TableColumn.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */