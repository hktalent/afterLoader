/*     */ package org.eclipse.swt.internal.image;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import org.eclipse.swt.SWT;
/*     */ import org.eclipse.swt.graphics.ImageData;
/*     */ import org.eclipse.swt.graphics.ImageLoader;
/*     */ import org.eclipse.swt.graphics.ImageLoaderEvent;
/*     */ import org.eclipse.swt.graphics.PaletteData;
/*     */ import org.eclipse.swt.graphics.RGB;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class TIFFDirectory
/*     */ {
/*     */   TIFFRandomFileAccess file;
/*     */   boolean isLittleEndian;
/*     */   ImageLoader loader;
/*     */   int depth;
/*     */   int subfileType;
/*     */   int imageWidth;
/*     */   int imageLength;
/*     */   int[] bitsPerSample;
/*     */   int compression;
/*     */   int photometricInterpretation;
/*     */   int[] stripOffsets;
/*     */   int samplesPerPixel;
/*     */   int rowsPerStrip;
/*     */   int[] stripByteCounts;
/*     */   int t4Options;
/*     */   int colorMapOffset;
/*     */   ImageData image;
/*     */   LEDataOutputStream out;
/*     */   static final int NO_VALUE = -1;
/*     */   static final short TAG_NewSubfileType = 254;
/*     */   static final short TAG_SubfileType = 255;
/*     */   static final short TAG_ImageWidth = 256;
/*     */   static final short TAG_ImageLength = 257;
/*     */   static final short TAG_BitsPerSample = 258;
/*     */   static final short TAG_Compression = 259;
/*     */   static final short TAG_PhotometricInterpretation = 262;
/*     */   static final short TAG_FillOrder = 266;
/*     */   static final short TAG_ImageDescription = 270;
/*     */   static final short TAG_StripOffsets = 273;
/*     */   static final short TAG_Orientation = 274;
/*     */   static final short TAG_SamplesPerPixel = 277;
/*     */   static final short TAG_RowsPerStrip = 278;
/*     */   static final short TAG_StripByteCounts = 279;
/*     */   static final short TAG_XResolution = 282;
/*     */   static final short TAG_YResolution = 283;
/*     */   static final short TAG_PlanarConfiguration = 284;
/*     */   static final short TAG_T4Options = 292;
/*     */   static final short TAG_ResolutionUnit = 296;
/*     */   static final short TAG_Software = 305;
/*     */   static final short TAG_DateTime = 306;
/*     */   static final short TAG_ColorMap = 320;
/*     */   static final int TYPE_BYTE = 1;
/*     */   static final int TYPE_ASCII = 2;
/*     */   static final int TYPE_SHORT = 3;
/*     */   static final int TYPE_LONG = 4;
/*     */   static final int TYPE_RATIONAL = 5;
/*     */   static final int FILETYPE_REDUCEDIMAGE = 1;
/*     */   static final int FILETYPE_PAGE = 2;
/*     */   static final int FILETYPE_MASK = 4;
/*     */   static final int OFILETYPE_IMAGE = 1;
/*     */   static final int OFILETYPE_REDUCEDIMAGE = 2;
/*     */   static final int OFILETYPE_PAGE = 3;
/*     */   static final int COMPRESSION_NONE = 1;
/*     */   static final int COMPRESSION_CCITT_3_1 = 2;
/*     */   static final int COMPRESSION_PACKBITS = 32773;
/*     */   static final int IFD_ENTRY_SIZE = 12;
/*     */   
/*     */   public TIFFDirectory(TIFFRandomFileAccess file, boolean isLittleEndian, ImageLoader loader)
/*     */   {
/*  89 */     this.file = file;
/*  90 */     this.isLittleEndian = isLittleEndian;
/*  91 */     this.loader = loader;
/*     */   }
/*     */   
/*     */   public TIFFDirectory(ImageData image) {
/*  95 */     this.image = image;
/*     */   }
/*     */   
/*     */   int decodePackBits(byte[] src, byte[] dest, int offsetDest)
/*     */   {
/* 100 */     int destIndex = offsetDest;
/* 101 */     int srcIndex = 0;
/* 102 */     while (srcIndex < src.length) {
/* 103 */       byte n = src[srcIndex];
/* 104 */       if (n >= 0)
/*     */       {
/* 106 */         System.arraycopy(src, ++srcIndex, dest, destIndex, n + 1);
/* 107 */         srcIndex += n + 1;
/* 108 */         destIndex += n + 1;
/* 109 */       } else if (n >= -127)
/*     */       {
/* 111 */         byte value = src[(++srcIndex)];
/* 112 */         for (int j = 0; j < -n + 1; j++) {
/* 113 */           dest[(destIndex++)] = value;
/*     */         }
/* 115 */         srcIndex++;
/*     */       }
/*     */       else {
/* 118 */         srcIndex++;
/*     */       }
/*     */     }
/*     */     
/* 122 */     return destIndex - offsetDest;
/*     */   }
/*     */   
/*     */   int getEntryValue(int type, byte[] buffer, int index) {
/* 126 */     return toInt(buffer, index + 8, type);
/*     */   }
/*     */   
/*     */   void getEntryValue(int type, byte[] buffer, int index, int[] values) throws IOException {
/* 130 */     int start = index + 8;
/*     */     
/* 132 */     int offset = toInt(buffer, start, 4);
/* 133 */     int size; int size; int size; int size; switch (type) {
/* 134 */     case 3:  size = 2; break;
/* 135 */     case 4:  size = 4; break;
/* 136 */     case 5:  size = 8; break;
/*     */     case 1: case 2: 
/* 138 */       size = 1; break;
/* 139 */     default:  SWT.error(42); return; }
/*     */     int size;
/* 141 */     if (values.length * size > 4) {
/* 142 */       buffer = new byte[values.length * size];
/* 143 */       this.file.seek(offset);
/* 144 */       this.file.read(buffer);
/* 145 */       start = 0;
/*     */     }
/* 147 */     for (int i = 0; i < values.length; i++) {
/* 148 */       values[i] = toInt(buffer, start + i * size, type);
/*     */     }
/*     */   }
/*     */   
/*     */   void decodePixels(ImageData image) throws IOException
/*     */   {
/* 154 */     byte[] imageData = new byte[(this.imageWidth * this.depth + 7) / 8 * this.imageLength];
/* 155 */     image.data = imageData;
/* 156 */     int destIndex = 0;
/* 157 */     int length = this.stripOffsets.length;
/* 158 */     for (int i = 0; i < length; i++)
/*     */     {
/* 160 */       byte[] data = new byte[this.stripByteCounts[i]];
/* 161 */       this.file.seek(this.stripOffsets[i]);
/* 162 */       this.file.read(data);
/* 163 */       if (this.compression == 1) {
/* 164 */         System.arraycopy(data, 0, imageData, destIndex, data.length);
/* 165 */         destIndex += data.length;
/* 166 */       } else if (this.compression == 32773) {
/* 167 */         destIndex += decodePackBits(data, imageData, destIndex);
/* 168 */       } else if ((this.compression == 2) || (this.compression == 3)) {
/* 169 */         TIFFModifiedHuffmanCodec codec = new TIFFModifiedHuffmanCodec();
/* 170 */         int nRows = this.rowsPerStrip;
/* 171 */         if (i == length - 1) {
/* 172 */           int n = this.imageLength % this.rowsPerStrip;
/* 173 */           if (n != 0) nRows = n;
/*     */         }
/* 175 */         destIndex += codec.decode(data, imageData, destIndex, this.imageWidth, nRows);
/*     */       }
/* 177 */       if (this.loader.hasListeners()) {
/* 178 */         this.loader.notifyListeners(new ImageLoaderEvent(this.loader, image, i, i == length - 1));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   PaletteData getColorMap() throws IOException {
/* 184 */     int numColors = 1 << this.bitsPerSample[0];
/*     */     
/* 186 */     int numBytes = 6 * numColors;
/* 187 */     byte[] buffer = new byte[numBytes];
/* 188 */     this.file.seek(this.colorMapOffset);
/* 189 */     this.file.read(buffer);
/* 190 */     RGB[] colors = new RGB[numColors];
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 200 */     int offset = this.isLittleEndian ? 1 : 0;
/* 201 */     int startG = 2 * numColors;
/* 202 */     int startB = startG + 2 * numColors;
/* 203 */     for (int i = 0; i < numColors; i++) {
/* 204 */       int r = buffer[offset] & 0xFF;
/* 205 */       int g = buffer[(startG + offset)] & 0xFF;
/* 206 */       int b = buffer[(startB + offset)] & 0xFF;
/* 207 */       colors[i] = new RGB(r, g, b);
/* 208 */       offset += 2;
/*     */     }
/* 210 */     return new PaletteData(colors);
/*     */   }
/*     */   
/*     */   PaletteData getGrayPalette() {
/* 214 */     int numColors = 1 << this.bitsPerSample[0];
/* 215 */     RGB[] rgbs = new RGB[numColors];
/* 216 */     for (int i = 0; i < numColors; i++) {
/* 217 */       int value = i * 255 / (numColors - 1);
/* 218 */       if (this.photometricInterpretation == 0) value = 255 - value;
/* 219 */       rgbs[i] = new RGB(value, value, value);
/*     */     }
/* 221 */     return new PaletteData(rgbs);
/*     */   }
/*     */   
/*     */   PaletteData getRGBPalette(int bitsR, int bitsG, int bitsB) {
/* 225 */     int blueMask = 0;
/* 226 */     for (int i = 0; i < bitsB; i++) {
/* 227 */       blueMask |= 1 << i;
/*     */     }
/* 229 */     int greenMask = 0;
/* 230 */     for (int i = bitsB; i < bitsB + bitsG; i++) {
/* 231 */       greenMask |= 1 << i;
/*     */     }
/* 233 */     int redMask = 0;
/* 234 */     for (int i = bitsB + bitsG; i < bitsB + bitsG + bitsR; i++) {
/* 235 */       redMask |= 1 << i;
/*     */     }
/* 237 */     return new PaletteData(redMask, greenMask, blueMask);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   int formatStrips(int rowByteSize, int nbrRows, byte[] data, int maxStripByteSize, int offsetPostIFD, int extraBytes, int[][] strips)
/*     */   {
/*     */     int nbrRowsPerStrip;
/*     */     
/*     */ 
/*     */     int nbrRowsPerStrip;
/*     */     
/*     */     int n;
/*     */     
/* 251 */     if (rowByteSize > maxStripByteSize)
/*     */     {
/* 253 */       int n = data.length / rowByteSize;
/* 254 */       nbrRowsPerStrip = 1;
/*     */     } else {
/* 256 */       int nbr = (data.length + maxStripByteSize - 1) / maxStripByteSize;
/* 257 */       nbrRowsPerStrip = nbrRows / nbr;
/* 258 */       n = (nbrRows + nbrRowsPerStrip - 1) / nbrRowsPerStrip;
/*     */     }
/* 260 */     int stripByteSize = rowByteSize * nbrRowsPerStrip;
/*     */     
/* 262 */     int[] offsets = new int[n];
/* 263 */     int[] counts = new int[n];
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 273 */     int postIFDData = n == 1 ? 0 : n * 2 * 4;
/* 274 */     int startOffset = offsetPostIFD + extraBytes + postIFDData;
/*     */     
/* 276 */     int offset = startOffset;
/* 277 */     for (int i = 0; i < n; i++)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 282 */       offsets[i] = offset;
/* 283 */       counts[i] = stripByteSize;
/* 284 */       offset += stripByteSize;
/*     */     }
/*     */     
/* 287 */     int mod = data.length % stripByteSize;
/* 288 */     if (mod != 0) { counts[(counts.length - 1)] = mod;
/*     */     }
/* 290 */     strips[0] = offsets;
/* 291 */     strips[1] = counts;
/* 292 */     return nbrRowsPerStrip;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   int[] formatColorMap(RGB[] rgbs)
/*     */   {
/* 301 */     int[] colorMap = new int[rgbs.length * 3];
/* 302 */     int offsetGreen = rgbs.length;
/* 303 */     int offsetBlue = rgbs.length * 2;
/* 304 */     for (int i = 0; i < rgbs.length; i++) {
/* 305 */       colorMap[i] = (rgbs[i].red << 8 | rgbs[i].red);
/* 306 */       colorMap[(i + offsetGreen)] = (rgbs[i].green << 8 | rgbs[i].green);
/* 307 */       colorMap[(i + offsetBlue)] = (rgbs[i].blue << 8 | rgbs[i].blue);
/*     */     }
/* 309 */     return colorMap;
/*     */   }
/*     */   
/*     */   void parseEntries(byte[] buffer) throws IOException {
/* 313 */     for (int offset = 0; offset < buffer.length; offset += 12) {
/* 314 */       int tag = toInt(buffer, offset, 3);
/* 315 */       int type = toInt(buffer, offset + 2, 3);
/* 316 */       int count = toInt(buffer, offset + 4, 4);
/* 317 */       switch (tag) {
/*     */       case 254: 
/* 319 */         this.subfileType = getEntryValue(type, buffer, offset);
/* 320 */         break;
/*     */       
/*     */       case 255: 
/* 323 */         int oldSubfileType = getEntryValue(type, buffer, offset);
/* 324 */         this.subfileType = (oldSubfileType == 3 ? 2 : oldSubfileType == 2 ? 1 : 0);
/* 325 */         break;
/*     */       
/*     */       case 256: 
/* 328 */         this.imageWidth = getEntryValue(type, buffer, offset);
/* 329 */         break;
/*     */       
/*     */       case 257: 
/* 332 */         this.imageLength = getEntryValue(type, buffer, offset);
/* 333 */         break;
/*     */       
/*     */       case 258: 
/* 336 */         if (type != 3) SWT.error(40);
/* 337 */         this.bitsPerSample = new int[count];
/* 338 */         getEntryValue(type, buffer, offset, this.bitsPerSample);
/* 339 */         break;
/*     */       
/*     */       case 259: 
/* 342 */         this.compression = getEntryValue(type, buffer, offset);
/* 343 */         break;
/*     */       
/*     */       case 266: 
/*     */         break;
/*     */       
/*     */ 
/*     */       case 270: 
/*     */         break;
/*     */       
/*     */ 
/*     */       case 262: 
/* 354 */         this.photometricInterpretation = getEntryValue(type, buffer, offset);
/* 355 */         break;
/*     */       
/*     */       case 273: 
/* 358 */         if ((type != 4) && (type != 3)) SWT.error(40);
/* 359 */         this.stripOffsets = new int[count];
/* 360 */         getEntryValue(type, buffer, offset, this.stripOffsets);
/* 361 */         break;
/*     */       
/*     */       case 274: 
/*     */         break;
/*     */       
/*     */ 
/*     */       case 277: 
/* 368 */         if (type != 3) SWT.error(40);
/* 369 */         this.samplesPerPixel = getEntryValue(type, buffer, offset);
/*     */         
/* 371 */         if ((this.samplesPerPixel != 1) && (this.samplesPerPixel != 3)) { SWT.error(38);
/*     */         }
/*     */         break;
/*     */       case 278: 
/* 375 */         this.rowsPerStrip = getEntryValue(type, buffer, offset);
/* 376 */         break;
/*     */       
/*     */       case 279: 
/* 379 */         this.stripByteCounts = new int[count];
/* 380 */         getEntryValue(type, buffer, offset, this.stripByteCounts);
/* 381 */         break;
/*     */       
/*     */       case 282: 
/*     */         break;
/*     */       
/*     */ 
/*     */       case 283: 
/*     */         break;
/*     */       
/*     */ 
/*     */       case 284: 
/*     */         break;
/*     */       
/*     */ 
/*     */       case 292: 
/* 396 */         if (type != 4) SWT.error(40);
/* 397 */         this.t4Options = getEntryValue(type, buffer, offset);
/* 398 */         if ((this.t4Options & 0x1) == 1)
/*     */         {
/* 400 */           SWT.error(42);
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         break;
/*     */       case 296: 
/*     */         break;
/*     */       case 305: 
/*     */         break;
/*     */       case 306: 
/*     */         break;
/*     */       case 320: 
/* 417 */         if (type != 3) { SWT.error(40);
/*     */         }
/* 419 */         this.colorMapOffset = getEntryValue(4, buffer, offset);
/*     */       }
/*     */       
/*     */     }
/*     */   }
/*     */   
/*     */   public ImageData read(int[] nextIFDOffset)
/*     */     throws IOException
/*     */   {
/* 428 */     this.bitsPerSample = new int[] { 1 };
/* 429 */     this.colorMapOffset = -1;
/* 430 */     this.compression = 1;
/* 431 */     this.imageLength = -1;
/* 432 */     this.imageWidth = -1;
/* 433 */     this.photometricInterpretation = -1;
/* 434 */     this.rowsPerStrip = Integer.MAX_VALUE;
/* 435 */     this.samplesPerPixel = 1;
/* 436 */     this.stripByteCounts = null;
/* 437 */     this.stripOffsets = null;
/*     */     
/* 439 */     byte[] buffer = new byte[2];
/* 440 */     this.file.read(buffer);
/* 441 */     int numberEntries = toInt(buffer, 0, 3);
/* 442 */     buffer = new byte[12 * numberEntries];
/* 443 */     this.file.read(buffer);
/* 444 */     byte[] buffer2 = new byte[4];
/* 445 */     this.file.read(buffer2);
/* 446 */     nextIFDOffset[0] = toInt(buffer2, 0, 4);
/* 447 */     parseEntries(buffer);
/*     */     
/* 449 */     PaletteData palette = null;
/* 450 */     this.depth = 0;
/* 451 */     switch (this.photometricInterpretation)
/*     */     {
/*     */     case 0: 
/*     */     case 1: 
/* 455 */       palette = getGrayPalette();
/* 456 */       this.depth = this.bitsPerSample[0];
/* 457 */       break;
/*     */     
/*     */ 
/*     */     case 2: 
/* 461 */       if (this.colorMapOffset != -1) { SWT.error(40);
/*     */       }
/* 463 */       palette = getRGBPalette(this.bitsPerSample[0], this.bitsPerSample[1], this.bitsPerSample[2]);
/* 464 */       this.depth = (this.bitsPerSample[0] + this.bitsPerSample[1] + this.bitsPerSample[2]);
/* 465 */       break;
/*     */     
/*     */ 
/*     */     case 3: 
/* 469 */       if (this.colorMapOffset == -1) SWT.error(40);
/* 470 */       palette = getColorMap();
/* 471 */       this.depth = this.bitsPerSample[0];
/* 472 */       break;
/*     */     
/*     */     default: 
/* 475 */       SWT.error(40);
/*     */     }
/*     */     
/*     */     
/* 479 */     ImageData image = ImageData.internal_new(this.imageWidth, this.imageLength, this.depth, palette, 1, null, 0, null, null, -1, -1, 6, 0, 0, 0, 0);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 496 */     decodePixels(image);
/* 497 */     return image;
/*     */   }
/*     */   
/*     */   int toInt(byte[] buffer, int i, int type) {
/* 501 */     if (type == 4) {
/* 502 */       return this.isLittleEndian ? buffer[i] & 0xFF | (buffer[(i + 1)] & 0xFF) << 8 | (buffer[(i + 2)] & 0xFF) << 16 | (buffer[(i + 3)] & 0xFF) << 24 : buffer[(i + 3)] & 0xFF | (buffer[(i + 2)] & 0xFF) << 8 | (buffer[(i + 1)] & 0xFF) << 16 | (buffer[i] & 0xFF) << 24;
/*     */     }
/*     */     
/*     */ 
/* 506 */     if (type == 3) {
/* 507 */       return this.isLittleEndian ? buffer[i] & 0xFF | (buffer[(i + 1)] & 0xFF) << 8 : buffer[(i + 1)] & 0xFF | (buffer[i] & 0xFF) << 8;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 512 */     SWT.error(40);
/* 513 */     return -1;
/*     */   }
/*     */   
/*     */   void write(int photometricInterpretation) throws IOException {
/* 517 */     boolean isRGB = photometricInterpretation == 2;
/* 518 */     boolean isColorMap = photometricInterpretation == 3;
/* 519 */     boolean isBiLevel = (photometricInterpretation == 0) || (photometricInterpretation == 1);
/*     */     
/* 521 */     int imageWidth = this.image.width;
/* 522 */     int imageLength = this.image.height;
/* 523 */     int rowByteSize = this.image.bytesPerLine;
/*     */     
/* 525 */     int numberEntries = isBiLevel ? 9 : 11;
/* 526 */     int lengthDirectory = 2 + 12 * numberEntries + 4;
/*     */     
/* 528 */     int nextOffset = 8 + lengthDirectory;
/*     */     
/*     */ 
/* 531 */     int extraBytes = 16;
/*     */     
/* 533 */     int[] colorMap = null;
/* 534 */     if (isColorMap) {
/* 535 */       PaletteData palette = this.image.palette;
/* 536 */       RGB[] rgbs = palette.getRGBs();
/* 537 */       colorMap = formatColorMap(rgbs);
/*     */       
/* 539 */       if (colorMap.length != 3 << this.image.depth) { SWT.error(42);
/*     */       }
/* 541 */       extraBytes += colorMap.length * 2;
/*     */     }
/* 543 */     if (isRGB)
/*     */     {
/* 545 */       extraBytes += 6;
/*     */     }
/*     */     
/* 548 */     byte[] data = this.image.data;
/* 549 */     int[][] strips = new int[2][];
/* 550 */     int nbrRowsPerStrip = formatStrips(rowByteSize, imageLength, data, 8192, nextOffset, extraBytes, strips);
/* 551 */     int[] stripOffsets = strips[0];
/* 552 */     int[] stripByteCounts = strips[1];
/*     */     
/* 554 */     int bitsPerSampleOffset = -1;
/* 555 */     if (isRGB) {
/* 556 */       bitsPerSampleOffset = nextOffset;
/* 557 */       nextOffset += 6;
/*     */     }
/* 559 */     int stripOffsetsOffset = -1;int stripByteCountsOffset = -1;
/* 560 */     int colorMapOffset = -1;
/* 561 */     int cnt = stripOffsets.length;
/* 562 */     if (cnt > 1) {
/* 563 */       stripOffsetsOffset = nextOffset;
/* 564 */       nextOffset += 4 * cnt;
/* 565 */       stripByteCountsOffset = nextOffset;
/* 566 */       nextOffset += 4 * cnt;
/*     */     }
/* 568 */     int xResolutionOffset = nextOffset;
/* 569 */     nextOffset += 8;
/* 570 */     int yResolutionOffset = nextOffset;
/* 571 */     nextOffset += 8;
/* 572 */     if (isColorMap) {
/* 573 */       colorMapOffset = nextOffset;
/* 574 */       nextOffset += colorMap.length * 2;
/*     */     }
/*     */     
/* 577 */     writeHeader();
/*     */     
/*     */ 
/* 580 */     this.out.writeShort(numberEntries);
/* 581 */     writeEntry((short)256, 4, 1, imageWidth);
/* 582 */     writeEntry((short)257, 4, 1, imageLength);
/* 583 */     if (isColorMap) writeEntry((short)258, 3, 1, this.image.depth);
/* 584 */     if (isRGB) writeEntry((short)258, 3, 3, bitsPerSampleOffset);
/* 585 */     writeEntry((short)259, 3, 1, 1);
/* 586 */     writeEntry((short)262, 3, 1, photometricInterpretation);
/* 587 */     writeEntry((short)273, 4, cnt, cnt > 1 ? stripOffsetsOffset : stripOffsets[0]);
/* 588 */     if (isRGB) writeEntry((short)277, 3, 1, 3);
/* 589 */     writeEntry((short)278, 4, 1, nbrRowsPerStrip);
/* 590 */     writeEntry((short)279, 4, cnt, cnt > 1 ? stripByteCountsOffset : stripByteCounts[0]);
/* 591 */     writeEntry((short)282, 5, 1, xResolutionOffset);
/* 592 */     writeEntry((short)283, 5, 1, yResolutionOffset);
/* 593 */     if (isColorMap) { writeEntry((short)320, 3, colorMap.length, colorMapOffset);
/*     */     }
/* 595 */     this.out.writeInt(0);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 600 */     if (isRGB) for (int i = 0; i < 3; i++) this.out.writeShort(8);
/* 601 */     if (cnt > 1) {
/* 602 */       for (int i = 0; i < cnt; i++) this.out.writeInt(stripOffsets[i]);
/* 603 */       for (int i = 0; i < cnt; i++) { this.out.writeInt(stripByteCounts[i]);
/*     */       }
/*     */     }
/* 606 */     for (int i = 0; i < 2; i++) {
/* 607 */       this.out.writeInt(300);
/* 608 */       this.out.writeInt(1);
/*     */     }
/*     */     
/* 611 */     if (isColorMap) { for (int i = 0; i < colorMap.length; i++) { this.out.writeShort(colorMap[i]);
/*     */       }
/*     */     }
/* 614 */     this.out.write(data);
/*     */   }
/*     */   
/*     */   void writeEntry(short tag, int type, int count, int value) throws IOException {
/* 618 */     this.out.writeShort(tag);
/* 619 */     this.out.writeShort(type);
/* 620 */     this.out.writeInt(count);
/* 621 */     this.out.writeInt(value);
/*     */   }
/*     */   
/*     */   void writeHeader() throws IOException
/*     */   {
/* 626 */     this.out.write(73);
/* 627 */     this.out.write(73);
/*     */     
/*     */ 
/* 630 */     this.out.writeShort(42);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 635 */     this.out.writeInt(8);
/*     */   }
/*     */   
/*     */   void writeToStream(LEDataOutputStream byteStream) throws IOException {
/* 639 */     this.out = byteStream;
/* 640 */     int photometricInterpretation = -1;
/*     */     
/*     */ 
/* 643 */     if (this.image.scanlinePad != 1) SWT.error(42);
/* 644 */     switch (this.image.depth)
/*     */     {
/*     */     case 1: 
/* 647 */       PaletteData palette = this.image.palette;
/* 648 */       RGB[] rgbs = palette.colors;
/* 649 */       if ((palette.isDirect) || (rgbs == null) || (rgbs.length != 2)) SWT.error(42);
/* 650 */       RGB rgb0 = rgbs[0];
/* 651 */       RGB rgb1 = rgbs[1];
/* 652 */       if ((rgb0.red != rgb0.green) || (rgb0.green != rgb0.blue) || (rgb1.red != rgb1.green) || (rgb1.green != rgb1.blue) || (((rgb0.red != 0) || (rgb1.red != 255)) && ((rgb0.red != 255) || (rgb1.red != 0))))
/*     */       {
/*     */ 
/* 655 */         SWT.error(42);
/*     */       }
/*     */       
/* 658 */       photometricInterpretation = this.image.palette.colors[0].red == 255 ? 0 : 1;
/* 659 */       break;
/*     */     
/*     */     case 4: 
/*     */     case 8: 
/* 663 */       photometricInterpretation = 3;
/* 664 */       break;
/*     */     
/*     */     case 24: 
/* 667 */       photometricInterpretation = 2;
/* 668 */       break;
/*     */     
/*     */     default: 
/* 671 */       SWT.error(42);
/*     */     }
/*     */     
/* 674 */     write(photometricInterpretation);
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/internal/image/TIFFDirectory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */