/*    */ package org.eclipse.swt.custom;
/*    */ 
/*    */ import org.eclipse.swt.graphics.Point;
/*    */ import org.eclipse.swt.widgets.Control;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class CLayoutData
/*    */ {
/* 19 */   int defaultWidth = -1; int defaultHeight = -1;
/* 20 */   int currentWidth = -1; int currentHeight = -1;
/*    */   int currentWhint;
/*    */   
/* 23 */   Point computeSize(Control control, int wHint, int hHint, boolean flushCache) { if (flushCache) flushCache();
/* 24 */     if ((wHint == -1) && (hHint == -1)) {
/* 25 */       if ((this.defaultWidth == -1) || (this.defaultHeight == -1)) {
/* 26 */         Point size = control.computeSize(wHint, hHint, flushCache);
/* 27 */         this.defaultWidth = size.x;
/* 28 */         this.defaultHeight = size.y;
/*    */       }
/* 30 */       return new Point(this.defaultWidth, this.defaultHeight);
/*    */     }
/* 32 */     if ((this.currentWidth == -1) || (this.currentHeight == -1) || (wHint != this.currentWhint) || (hHint != this.currentHhint)) {
/* 33 */       Point size = control.computeSize(wHint, hHint, flushCache);
/* 34 */       this.currentWhint = wHint;
/* 35 */       this.currentHhint = hHint;
/* 36 */       this.currentWidth = size.x;
/* 37 */       this.currentHeight = size.y;
/*    */     }
/* 39 */     return new Point(this.currentWidth, this.currentHeight); }
/*    */   
/*    */   int currentHhint;
/* 42 */   void flushCache() { this.defaultWidth = (this.defaultHeight = -1);
/* 43 */     this.currentWidth = (this.currentHeight = -1);
/*    */   }
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/custom/CLayoutData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */