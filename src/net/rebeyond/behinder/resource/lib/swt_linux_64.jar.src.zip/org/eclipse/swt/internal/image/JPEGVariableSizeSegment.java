/*    */ package org.eclipse.swt.internal.image;
/*    */ 
/*    */ import org.eclipse.swt.SWT;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class JPEGVariableSizeSegment
/*    */   extends JPEGSegment
/*    */ {
/*    */   public JPEGVariableSizeSegment(byte[] reference)
/*    */   {
/* 19 */     super(reference);
/*    */   }
/*    */   
/*    */   public JPEGVariableSizeSegment(LEDataInputStream byteStream) {
/*    */     try {
/* 24 */       byte[] header = new byte[4];
/* 25 */       byteStream.read(header);
/* 26 */       this.reference = header;
/* 27 */       byte[] contents = new byte[getSegmentLength() + 2];
/* 28 */       contents[0] = header[0];
/* 29 */       contents[1] = header[1];
/* 30 */       contents[2] = header[2];
/* 31 */       contents[3] = header[3];
/* 32 */       byteStream.read(contents, 4, contents.length - 4);
/* 33 */       this.reference = contents;
/*    */     } catch (Exception e) {
/* 35 */       SWT.error(39, e);
/*    */     }
/*    */   }
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/internal/image/JPEGVariableSizeSegment.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */