/*      */ package org.eclipse.swt.internal.gtk;
/*      */ 
/*      */ import java.io.PrintStream;
/*      */ import org.eclipse.swt.internal.C;
/*      */ import org.eclipse.swt.internal.Converter;
/*      */ import org.eclipse.swt.internal.Library;
/*      */ import org.eclipse.swt.internal.Lock;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class OS
/*      */   extends C
/*      */ {
/*      */   public static final boolean IsAIX;
/*      */   public static final boolean IsLinux;
/*      */   public static final boolean IsWin32;
/*      */   public static final boolean BIG_ENDIAN;
/*      */   public static final String SWT_LIB_VERSIONS = "SWT_LIB_VERSIONS";
/*      */   public static final int G_FILE_TEST_IS_DIR = 4;
/*      */   public static final int G_FILE_TEST_IS_EXECUTABLE = 8;
/*      */   public static final int G_SIGNAL_MATCH_FUNC = 8;
/*      */   public static final int G_SIGNAL_MATCH_DATA = 16;
/*      */   public static final int G_SIGNAL_MATCH_ID = 1;
/*      */   public static final int G_LOG_FLAG_FATAL = 2;
/*      */   public static final int G_LOG_FLAG_RECURSION = 1;
/*      */   public static final int G_LOG_LEVEL_MASK = -4;
/*      */   public static final int G_APP_INFO_CREATE_NONE = 0;
/*      */   public static final int G_APP_INFO_CREATE_NEEDS_TERMINAL = 1;
/*      */   public static final int G_APP_INFO_CREATE_SUPPORTS_URIS = 2;
/*      */   public static final int None = 0;
/*      */   public static final int PANGO_ALIGN_LEFT = 0;
/*      */   public static final int PANGO_ALIGN_CENTER = 1;
/*      */   public static final int PANGO_ALIGN_RIGHT = 2;
/*      */   public static final int PANGO_ATTR_FOREGROUND = 9;
/*      */   public static final int PANGO_ATTR_BACKGROUND = 10;
/*      */   public static final int PANGO_ATTR_UNDERLINE = 11;
/*      */   public static final int PANGO_ATTR_UNDERLINE_COLOR = 18;
/*      */   public static final int PANGO_DIRECTION_LTR = 0;
/*      */   public static final int PANGO_DIRECTION_RTL = 1;
/*      */   public static final int PANGO_SCALE = 1024;
/*      */   public static final int PANGO_STRETCH_ULTRA_CONDENSED = 0;
/*      */   public static final int PANGO_STRETCH_EXTRA_CONDENSED = 1;
/*      */   public static final int PANGO_STRETCH_CONDENSED = 2;
/*      */   public static final int PANGO_STRETCH_SEMI_CONDENSED = 3;
/*      */   public static final int PANGO_STRETCH_NORMAL = 4;
/*      */   public static final int PANGO_STRETCH_SEMI_EXPANDED = 5;
/*      */   public static final int PANGO_STRETCH_EXPANDED = 6;
/*      */   public static final int PANGO_STRETCH_EXTRA_EXPANDED = 7;
/*      */   public static final int PANGO_STRETCH_ULTRA_EXPANDED = 8;
/*      */   public static final int PANGO_STYLE_ITALIC = 2;
/*      */   public static final int PANGO_STYLE_NORMAL = 0;
/*      */   public static final int PANGO_STYLE_OBLIQUE = 1;
/*      */   public static final int PANGO_TAB_LEFT = 0;
/*      */   public static final int PANGO_UNDERLINE_NONE = 0;
/*      */   public static final int PANGO_UNDERLINE_SINGLE = 1;
/*      */   public static final int PANGO_UNDERLINE_DOUBLE = 2;
/*      */   public static final int PANGO_UNDERLINE_LOW = 3;
/*      */   public static final int PANGO_UNDERLINE_ERROR = 4;
/*      */   public static final int PANGO_VARIANT_NORMAL = 0;
/*      */   public static final int PANGO_VARIANT_SMALL_CAPS = 1;
/*      */   public static final int PANGO_WEIGHT_BOLD = 700;
/*      */   public static final int PANGO_WEIGHT_NORMAL = 400;
/*      */   public static final int PANGO_WRAP_WORD = 0;
/*      */   public static final int PANGO_WRAP_WORD_CHAR = 2;
/*      */   public static final int RTLD_GLOBAL;
/*      */   public static final int RTLD_LAZY;
/*      */   public static final int RTLD_MEMBER = 262144;
/*      */   public static final int RTLD_NOW;
/*      */   public static final int G_BUS_TYPE_STARTER = -1;
/*      */   public static final int G_BUS_TYPE_NONE = 0;
/*      */   public static final int G_BUS_TYPE_SYSTEM = 1;
/*      */   public static final int G_BUS_TYPE_SESSION = 2;
/*      */   public static final int G_BUS_NAME_OWNER_FLAGS_NONE = 0;
/*      */   
/*      */   public static String getEnvironmentalVariable(String envVarName)
/*      */   {
/*  119 */     String envVarValue = null;
/*  120 */     long ptr = C.getenv(ascii(envVarName));
/*  121 */     if (ptr != 0L) {
/*  122 */       int length = C.strlen(ptr);
/*  123 */       byte[] buffer = new byte[length];
/*  124 */       C.memmove(buffer, ptr, length);
/*  125 */       char[] convertedChar = new char[buffer.length];
/*  126 */       for (int i = 0; i < buffer.length; i++) {
/*  127 */         convertedChar[i] = ((char)buffer[i]);
/*      */       }
/*  129 */       envVarValue = new String(convertedChar);
/*      */     }
/*  131 */     return envVarValue;
/*      */   }
/*      */   
/*      */ 
/*      */   public static final int G_BUS_NAME_OWNER_FLAGS_ALLOW_REPLACEMENT = 1;
/*      */   
/*      */   public static final int G_BUS_NAME_OWNER_FLAGS_REPLACE = 2;
/*      */   
/*      */   public static final String DBUS_TYPE_BYTE = "y";
/*      */   
/*      */   public static final String DBUS_TYPE_BOOLEAN = "b";
/*      */   
/*      */   public static final String DBUS_TYPE_ARRAY = "a";
/*      */   
/*      */   public static final String DBUS_TYPE_STRING = "s";
/*      */   
/*      */   public static final String DBUS_TYPE_STRING_ARRAY = "as";
/*      */   
/*      */   public static final String DBUS_TYPE_INT32 = "i";
/*      */   
/*      */   public static final String DBUS_TYPE_DOUBLE = "d";
/*      */   
/*      */   public static final String DBUS_TYPE_STRUCT = "r";
/*      */   
/*      */   public static final String DBUS_TYPE_SINGLE_COMPLETE = "*";
/*      */   
/*      */   public static final byte[] G_VARIANT_TYPE_BYTE;
/*      */   
/*      */   public static final byte[] G_VARIANT_TYPE_BOOLEAN;
/*      */   
/*      */   public static final byte[] G_VARIANT_TYPE_STRING_ARRAY;
/*      */   
/*      */   public static final byte[] G_VARIANT_TYPE_STRING;
/*      */   
/*      */   public static final byte[] G_VARIANT_TYPE_IN32;
/*      */   
/*      */   public static final byte[] G_VARIANT_TYPE_DOUBLE;
/*      */   
/*      */   public static final byte[] G_VARIANT_TYPE_TUPLE;
/*      */   
/*      */   public static final byte[] accel_closures_changed;
/*      */   
/*      */   public static final byte[] activate;
/*      */   
/*      */   public static final byte[] angle_changed;
/*      */   
/*      */   public static final byte[] backspace;
/*      */   
/*      */   public static final byte[] begin;
/*      */   
/*      */   public static final byte[] button_press_event;
/*      */   
/*      */   public static final byte[] button_release_event;
/*      */   
/*      */   public static final byte[] changed;
/*      */   
/*      */   public static final byte[] change_current_page;
/*      */   
/*      */   public static final byte[] change_value;
/*      */   
/*      */   public static final byte[] clicked;
/*      */   
/*      */   public static final byte[] commit;
/*      */   
/*      */   public static final byte[] configure_event;
/*      */   
/*      */   public static final byte[] copy_clipboard;
/*      */   
/*      */   public static final byte[] cut_clipboard;
/*      */   
/*      */   public static final byte[] create_menu_proxy;
/*      */   
/*      */   public static final byte[] delete_event;
/*      */   
/*      */   public static final byte[] delete_from_cursor;
/*      */   
/*      */   public static final byte[] day_selected;
/*      */   
/*      */   public static final byte[] day_selected_double_click;
/*      */   
/*      */   public static final byte[] delete_range;
/*      */   
/*      */   public static final byte[] delete_text;
/*      */   
/*      */   public static final byte[] direction_changed;
/*      */   
/*      */   public static final byte[] drag_begin;
/*      */   
/*      */   public static final byte[] drag_data_delete;
/*      */   
/*      */   public static final byte[] drag_data_get;
/*      */   
/*      */   public static final byte[] drag_data_received;
/*      */   
/*      */   public static final byte[] drag_drop;
/*      */   
/*      */   public static final byte[] drag_end;
/*      */   
/*      */   public static final byte[] drag_leave;
/*      */   
/*      */   public static final byte[] drag_motion;
/*      */   
/*      */   public static final byte[] draw;
/*      */   
/*      */   public static final byte[] end;
/*      */   
/*      */   public static final byte[] enter_notify_event;
/*      */   
/*      */   public static final byte[] event;
/*      */   
/*      */   public static final byte[] event_after;
/*      */   
/*      */   public static final byte[] expand_collapse_cursor_row;
/*      */   
/*      */   public static final byte[] expose_event;
/*      */   
/*      */   public static final byte[] focus;
/*      */   
/*      */   public static final byte[] focus_in_event;
/*      */   
/*      */   public static final byte[] focus_out_event;
/*      */   
/*      */   public static final byte[] grab_focus;
/*      */   
/*      */   public static final byte[] hide;
/*      */   
/*      */   public static final byte[] icon_release;
/*      */   
/*      */   public static final byte[] input;
/*      */   
/*      */   public static final byte[] insert_text;
/*      */   
/*      */   public static final byte[] key_press_event;
/*      */   
/*      */   public static final byte[] key_release_event;
/*      */   
/*      */   public static final byte[] keys_changed;
/*      */   
/*      */   public static final byte[] leave_notify_event;
/*      */   
/*      */   public static final byte[] link_color;
/*      */   
/*      */   public static final byte[] map;
/*      */   
/*      */   public static final byte[] map_event;
/*      */   
/*      */   public static final byte[] mnemonic_activate;
/*      */   
/*      */   public static final byte[] month_changed;
/*      */   
/*      */   public static final byte[] motion_notify_event;
/*      */   
/*      */   public static final byte[] move_cursor;
/*      */   
/*      */   public static final byte[] move_focus;
/*      */   
/*      */   public static final byte[] output;
/*      */   
/*      */   public static final byte[] paste_clipboard;
/*      */   
/*      */   public static final byte[] popped_up;
/*      */   
/*      */   public static final byte[] popup_menu;
/*      */   
/*      */   public static final byte[] populate_popup;
/*      */   
/*      */   public static final byte[] preedit_changed;
/*      */   
/*      */   public static final byte[] property_notify_event;
/*      */   
/*      */   public static final byte[] realize;
/*      */   
/*      */   public static final byte[] row_activated;
/*      */   
/*      */   public static final byte[] row_changed;
/*      */   
/*      */   public static final byte[] row_has_child_toggled;
/*      */   
/*      */   public static final byte[] row_inserted;
/*      */   
/*      */   public static final byte[] row_deleted;
/*      */   
/*      */   public static final byte[] scale_changed;
/*      */   
/*      */   public static final byte[] scroll_child;
/*      */   
/*      */   public static final byte[] scroll_event;
/*      */   
/*      */   public static final byte[] select;
/*      */   
/*      */   public static final byte[] selection_done;
/*      */   
/*      */   public static final byte[] show;
/*      */   
/*      */   public static final byte[] show_help;
/*      */   
/*      */   public static final byte[] size_allocate;
/*      */   
/*      */   public static final byte[] size_request;
/*      */   
/*      */   public static final byte[] start_interactive_search;
/*      */   
/*      */   public static final byte[] style_set;
/*      */   
/*      */   public static final byte[] swipe;
/*      */   
/*      */   public static final byte[] switch_page;
/*      */   
/*      */   public static final byte[] test_collapse_row;
/*      */   
/*      */   public static final byte[] test_expand_row;
/*      */   
/*      */   public static final byte[] toggled;
/*      */   
/*      */   public static final byte[] unmap;
/*      */   
/*      */   public static final byte[] unmap_event;
/*      */   
/*      */   public static final byte[] unrealize;
/*      */   
/*      */   public static final byte[] value_changed;
/*      */   public static final byte[] window_state_event;
/*      */   public static final byte[] active;
/*      */   public static final byte[] background_gdk;
/*      */   public static final byte[] background_rgba;
/*      */   public static final byte[] button_relief;
/*      */   public static final byte[] cell_background_gdk;
/*      */   public static final byte[] cell_background_rgba;
/*      */   public static final byte[] default_border;
/*      */   public static final byte[] expander_size;
/*      */   public static final byte[] fixed_height_mode;
/*      */   public static final byte[] focus_line_width;
/*      */   public static final byte[] focus_padding;
/*      */   public static final byte[] font_desc;
/*      */   public static final byte[] foreground_gdk;
/*      */   public static final byte[] foreground_rgba;
/*      */   public static final byte[] grid_line_width;
/*      */   public static final byte[] inner_border;
/*      */   public static final byte[] has_backward_stepper;
/*      */   public static final byte[] has_secondary_backward_stepper;
/*      */   public static final byte[] has_forward_stepper;
/*      */   public static final byte[] has_secondary_forward_stepper;
/*      */   public static final byte[] horizontal_separator;
/*      */   public static final byte[] inconsistent;
/*      */   public static final byte[] indicator_size;
/*      */   public static final byte[] indicator_spacing;
/*      */   public static final byte[] initial_gap;
/*      */   public static final byte[] interior_focus;
/*      */   public static final byte[] mode;
/*      */   public static final byte[] model;
/*      */   public static final byte[] spacing;
/*      */   public static final byte[] pixbuf;
/*      */   public static final byte[] gicon;
/*      */   public static final byte[] text;
/*      */   public static final byte[] xalign;
/*      */   public static final byte[] ypad;
/*      */   public static final byte[] margin_bottom;
/*      */   public static final byte[] margin_top;
/*      */   public static final byte[] scrollbar_spacing;
/*      */   public static final int GLIB_VERSION;
/*      */   private static final boolean MIN_GLIB_2_32;
/*      */   public static final boolean SWT_MENU_LOCATION_DEBUGGING;
/*      */   public static final boolean GTK_THEME_SET;
/*      */   public static final String GTK_THEME_NAME;
/*      */   public static final boolean GTK_THEME_DARK;
/*      */   public static final boolean SWT_PADDED_MENU_ITEMS;
/*      */   public static final boolean CAIRO_CONTEXT_REUSE;
/*      */   public static final int Above = 0;
/*      */   public static final int Below = 1;
/*      */   public static final int ButtonRelease = 5;
/*      */   public static final int CurrentTime = 0;
/*      */   public static final int CWSibling = 32;
/*      */   public static final int CWStackMode = 64;
/*      */   public static final int EnterNotify = 7;
/*      */   public static final int Expose = 12;
/*      */   public static final int FocusChangeMask = 2097152;
/*      */   public static final int FocusIn = 9;
/*      */   public static final int FocusOut = 10;
/*      */   public static final int GraphicsExpose = 13;
/*      */   public static final int NoExpose = 14;
/*      */   public static final int ExposureMask = 32768;
/*      */   public static final long NoEventMask = 0L;
/*      */   public static final int NotifyNormal = 0;
/*      */   public static final int NotifyGrab = 1;
/*      */   public static final int NotifyHint = 1;
/*      */   public static final int NotifyUngrab = 2;
/*      */   public static final int NotifyWhileGrabbed = 3;
/*      */   public static final int NotifyAncestor = 0;
/*      */   public static final int NotifyVirtual = 1;
/*      */   public static final int NotifyNonlinear = 3;
/*      */   public static final int NotifyNonlinearVirtual = 4;
/*      */   public static final int NotifyPointer = 5;
/*      */   public static final int RevertToParent = 2;
/*      */   public static final boolean gdk_keymap_translate_keyboard_state(long keymap, int hardware_keycode, int state, int group, long[] keyval, int[] effective_group, int[] level, int[] consumed_modifiers)
/*      */   {
/*  426 */     lock.lock();
/*      */     try {
/*  428 */       return _gdk_keymap_translate_keyboard_state(keymap, hardware_keycode, state, group, keyval, effective_group, level, consumed_modifiers);
/*      */     } finally {
/*  430 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void call_get_size(long function, long arg0, long arg1, long arg2, long arg3, long arg4, long arg5, long arg6)
/*      */   {
/*  439 */     lock.lock();
/*      */     try {
/*  441 */       _call_get_size(function, arg0, arg1, arg2, arg3, arg4, arg5, arg6);
/*      */     } finally {
/*  443 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long swt_fixed_get_type()
/*      */   {
/*  503 */     lock.lock();
/*      */     try {
/*  505 */       return _swt_fixed_get_type();
/*      */     } finally {
/*  507 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final long swt_fixed_accessible_get_type()
/*      */   {
/*  514 */     lock.lock();
/*      */     try {
/*  516 */       return _swt_fixed_accessible_get_type();
/*      */     } finally {
/*  518 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void swt_fixed_accessible_register_accessible(long obj, boolean is_native, long to_map)
/*      */   {
/*  529 */     lock.lock();
/*      */     try {
/*  531 */       _swt_fixed_accessible_register_accessible(obj, is_native, to_map);
/*      */     } finally {
/*  533 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void swt_fixed_restack(long fixed, long widget, long sibling, boolean above)
/*      */   {
/*  544 */     lock.lock();
/*      */     try {
/*  546 */       _swt_fixed_restack(fixed, widget, sibling, above);
/*      */     } finally {
/*  548 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void swt_fixed_move(long fixed, long widget, int x, int y)
/*      */   {
/*  558 */     lock.lock();
/*      */     try {
/*  560 */       _swt_fixed_move(fixed, widget, x, y);
/*      */     } finally {
/*  562 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void swt_fixed_resize(long fixed, long widget, int width, int height)
/*      */   {
/*  572 */     lock.lock();
/*      */     try {
/*  574 */       _swt_fixed_resize(fixed, widget, width, height);
/*      */     } finally {
/*  576 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long g_utf16_offset_to_pointer(long str, long offset)
/*      */   {
/*  586 */     lock.lock();
/*      */     try {
/*  588 */       return _g_utf16_offset_to_pointer(str, offset);
/*      */     } finally {
/*  590 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long g_utf16_pointer_to_offset(long str, long pos)
/*      */   {
/*  602 */     lock.lock();
/*      */     try {
/*  604 */       return _g_utf16_pointer_to_offset(str, pos);
/*      */     } finally {
/*  606 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long g_utf16_strlen(long str, long max)
/*      */   {
/*  615 */     lock.lock();
/*      */     try {
/*  617 */       return _g_utf16_strlen(str, max);
/*      */     } finally {
/*  619 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long g_utf8_offset_to_utf16_offset(long str, long offset)
/*      */   {
/*  628 */     lock.lock();
/*      */     try {
/*  630 */       return _g_utf8_offset_to_utf16_offset(str, offset);
/*      */     } finally {
/*  632 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long g_utf16_offset_to_utf8_offset(long str, long offset)
/*      */   {
/*  641 */     lock.lock();
/*      */     try {
/*  643 */       return _g_utf16_offset_to_utf8_offset(str, offset);
/*      */     } finally {
/*  645 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   static
/*      */   {
/*   60 */     String osName = System.getProperty("os.name");
/*   61 */     boolean isAIX = false;boolean isLinux = false;boolean isWin32 = false;
/*   62 */     if (osName.equals("Linux")) isLinux = true;
/*   63 */     if (osName.equals("AIX")) isAIX = true;
/*   64 */     if (osName.startsWith("Windows")) isWin32 = true;
/*   65 */     IsAIX = isAIX;IsLinux = isLinux;IsWin32 = isWin32;
/*      */     
/*   67 */     byte[] buffer = new byte[4];
/*   68 */     long ptr = C.malloc(4L);
/*   69 */     C.memmove(ptr, new int[] { 1 }, 4L);
/*   70 */     C.memmove(buffer, ptr, 1L);
/*   71 */     C.free(ptr);
/*   72 */     BIG_ENDIAN = buffer[0] == 0;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*   77 */     String propertyName = "SWT_GTK3";
/*   78 */     String gtk3 = getEnvironmentalVariable(propertyName);
/*   79 */     if ((gtk3 != null) && (gtk3.equals("0"))) {
/*      */       try {
/*   81 */         Library.loadLibrary("swt-pi");
/*      */       } catch (Throwable e) {
/*   83 */         Library.loadLibrary("swt-pi3");
/*      */       }
/*      */     } else {
/*      */       try {
/*   87 */         Library.loadLibrary("swt-pi3");
/*      */       } catch (Throwable e) {
/*   89 */         Library.loadLibrary("swt-pi");
/*      */       }
/*      */     }
/*   92 */     cachejvmptr();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*   98 */     String propertyName = "SWT_FATAL_WARNINGS";
/*   99 */     String swt_fatal_warnings = getEnvironmentalVariable(propertyName);
/*      */     
/*  101 */     if ((swt_fatal_warnings != null) && (swt_fatal_warnings.equals("1"))) {
/*  102 */       swt_debug_on_fatal_warnings();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  108 */     String swt_lib_versions = getEnvironmentalVariable("SWT_LIB_VERSIONS");
/*  109 */     if ((swt_lib_versions != null) && (swt_lib_versions.equals("1"))) {
/*  110 */       System.out.print("SWT_LIB_Gtk:" + GTK.gtk_major_version() + "." + GTK.gtk_minor_version() + "." + GTK.gtk_micro_version());
/*  111 */       System.out.print(" (Dynamic gdbus)");
/*  112 */       System.out.println("");
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  181 */     RTLD_GLOBAL = IsWin32 ? 0 : RTLD_GLOBAL();
/*  182 */     RTLD_LAZY = IsWin32 ? 0 : RTLD_LAZY();
/*      */     
/*  184 */     RTLD_NOW = IsWin32 ? 0 : RTLD_NOW();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  238 */     G_VARIANT_TYPE_BYTE = ascii("y");
/*      */     
/*  240 */     G_VARIANT_TYPE_BOOLEAN = ascii("b");
/*      */     
/*  242 */     G_VARIANT_TYPE_STRING_ARRAY = ascii("as");
/*      */     
/*  244 */     G_VARIANT_TYPE_STRING = ascii("s");
/*      */     
/*  246 */     G_VARIANT_TYPE_IN32 = ascii("i");
/*      */     
/*  248 */     G_VARIANT_TYPE_DOUBLE = ascii("d");
/*      */     
/*  250 */     G_VARIANT_TYPE_TUPLE = ascii("r");
/*      */     
/*      */ 
/*      */ 
/*  254 */     accel_closures_changed = ascii("accel-closures-changed");
/*  255 */     activate = ascii("activate");
/*  256 */     angle_changed = ascii("angle_changed");
/*  257 */     backspace = ascii("backspace");
/*  258 */     begin = ascii("begin");
/*  259 */     button_press_event = ascii("button-press-event");
/*  260 */     button_release_event = ascii("button-release-event");
/*  261 */     changed = ascii("changed");
/*  262 */     change_current_page = ascii("change-current-page");
/*  263 */     change_value = ascii("change-value");
/*  264 */     clicked = ascii("clicked");
/*  265 */     commit = ascii("commit");
/*  266 */     configure_event = ascii("configure-event");
/*  267 */     copy_clipboard = ascii("copy-clipboard");
/*  268 */     cut_clipboard = ascii("cut-clipboard");
/*  269 */     create_menu_proxy = ascii("create-menu-proxy");
/*  270 */     delete_event = ascii("delete-event");
/*  271 */     delete_from_cursor = ascii("delete-from-cursor");
/*  272 */     day_selected = ascii("day-selected");
/*  273 */     day_selected_double_click = ascii("day-selected-double-click");
/*  274 */     delete_range = ascii("delete-range");
/*  275 */     delete_text = ascii("delete-text");
/*  276 */     direction_changed = ascii("direction-changed");
/*  277 */     drag_begin = ascii("drag_begin");
/*  278 */     drag_data_delete = ascii("drag_data_delete");
/*  279 */     drag_data_get = ascii("drag_data_get");
/*  280 */     drag_data_received = ascii("drag_data_received");
/*  281 */     drag_drop = ascii("drag_drop");
/*  282 */     drag_end = ascii("drag_end");
/*  283 */     drag_leave = ascii("drag_leave");
/*  284 */     drag_motion = ascii("drag_motion");
/*  285 */     draw = ascii("draw");
/*  286 */     end = ascii("end");
/*  287 */     enter_notify_event = ascii("enter-notify-event");
/*  288 */     event = ascii("event");
/*  289 */     event_after = ascii("event-after");
/*  290 */     expand_collapse_cursor_row = ascii("expand-collapse-cursor-row");
/*  291 */     expose_event = ascii("expose-event");
/*  292 */     focus = ascii("focus");
/*  293 */     focus_in_event = ascii("focus-in-event");
/*  294 */     focus_out_event = ascii("focus-out-event");
/*  295 */     grab_focus = ascii("grab-focus");
/*  296 */     hide = ascii("hide");
/*  297 */     icon_release = ascii("icon-release");
/*  298 */     input = ascii("input");
/*  299 */     insert_text = ascii("insert-text");
/*  300 */     key_press_event = ascii("key-press-event");
/*  301 */     key_release_event = ascii("key-release-event");
/*  302 */     keys_changed = ascii("keys-changed");
/*  303 */     leave_notify_event = ascii("leave-notify-event");
/*  304 */     link_color = ascii("link-color");
/*  305 */     map = ascii("map");
/*  306 */     map_event = ascii("map-event");
/*  307 */     mnemonic_activate = ascii("mnemonic-activate");
/*  308 */     month_changed = ascii("month-changed");
/*  309 */     motion_notify_event = ascii("motion-notify-event");
/*  310 */     move_cursor = ascii("move-cursor");
/*  311 */     move_focus = ascii("move-focus");
/*  312 */     output = ascii("output");
/*  313 */     paste_clipboard = ascii("paste-clipboard");
/*  314 */     popped_up = ascii("popped-up");
/*  315 */     popup_menu = ascii("popup-menu");
/*  316 */     populate_popup = ascii("populate-popup");
/*  317 */     preedit_changed = ascii("preedit-changed");
/*  318 */     property_notify_event = ascii("property-notify-event");
/*  319 */     realize = ascii("realize");
/*  320 */     row_activated = ascii("row-activated");
/*  321 */     row_changed = ascii("row-changed");
/*  322 */     row_has_child_toggled = ascii("row-has-child-toggled");
/*  323 */     row_inserted = ascii("row-inserted");
/*  324 */     row_deleted = ascii("row-deleted");
/*  325 */     scale_changed = ascii("scale-changed");
/*  326 */     scroll_child = ascii("scroll-child");
/*  327 */     scroll_event = ascii("scroll-event");
/*  328 */     select = ascii("select");
/*  329 */     selection_done = ascii("selection-done");
/*  330 */     show = ascii("show");
/*  331 */     show_help = ascii("show-help");
/*  332 */     size_allocate = ascii("size-allocate");
/*  333 */     size_request = ascii("size-request");
/*  334 */     start_interactive_search = ascii("start-interactive-search");
/*  335 */     style_set = ascii("style-set");
/*  336 */     swipe = ascii("swipe");
/*  337 */     switch_page = ascii("switch-page");
/*  338 */     test_collapse_row = ascii("test-collapse-row");
/*  339 */     test_expand_row = ascii("test-expand-row");
/*  340 */     toggled = ascii("toggled");
/*  341 */     unmap = ascii("unmap");
/*  342 */     unmap_event = ascii("unmap-event");
/*  343 */     unrealize = ascii("unrealize");
/*  344 */     value_changed = ascii("value-changed");
/*  345 */     window_state_event = ascii("window-state-event");
/*      */     
/*      */ 
/*  348 */     active = ascii("active");
/*  349 */     background_gdk = ascii("background-gdk");
/*  350 */     background_rgba = ascii("background-rgba");
/*  351 */     button_relief = ascii("button-relief");
/*  352 */     cell_background_gdk = ascii("cell-background-gdk");
/*  353 */     cell_background_rgba = ascii("cell-background-rgba");
/*  354 */     default_border = ascii("default-border");
/*  355 */     expander_size = ascii("expander-size");
/*  356 */     fixed_height_mode = ascii("fixed-height-mode");
/*  357 */     focus_line_width = ascii("focus-line-width");
/*  358 */     focus_padding = ascii("focus-padding");
/*  359 */     font_desc = ascii("font-desc");
/*  360 */     foreground_gdk = ascii("foreground-gdk");
/*  361 */     foreground_rgba = ascii("foreground-rgba");
/*  362 */     grid_line_width = ascii("grid-line-width");
/*  363 */     inner_border = ascii("inner-border");
/*  364 */     has_backward_stepper = ascii("has-backward-stepper");
/*  365 */     has_secondary_backward_stepper = ascii("has-secondary-backward-stepper");
/*  366 */     has_forward_stepper = ascii("has-forward-stepper");
/*  367 */     has_secondary_forward_stepper = ascii("has-secondary-forward-stepper");
/*  368 */     horizontal_separator = ascii("horizontal-separator");
/*  369 */     inconsistent = ascii("inconsistent");
/*  370 */     indicator_size = ascii("indicator-size");
/*  371 */     indicator_spacing = ascii("indicator-spacing");
/*  372 */     initial_gap = ascii("initial-gap");
/*  373 */     interior_focus = ascii("interior-focus");
/*  374 */     mode = ascii("mode");
/*  375 */     model = ascii("model");
/*  376 */     spacing = ascii("spacing");
/*  377 */     pixbuf = ascii("pixbuf");
/*  378 */     gicon = ascii("gicon");
/*  379 */     text = ascii("text");
/*  380 */     xalign = ascii("xalign");
/*  381 */     ypad = ascii("ypad");
/*  382 */     margin_bottom = ascii("margin-bottom");
/*  383 */     margin_top = ascii("margin-top");
/*  384 */     scrollbar_spacing = ascii("scrollbar-spacing");
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  676 */     GLIB_VERSION = VERSION(glib_major_version(), glib_minor_version(), glib_micro_version());
/*  677 */     MIN_GLIB_2_32 = GLIB_VERSION >= VERSION(2, 32, 0);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  724 */     String paddedProperty = "SWT_PADDED_MENU_ITEMS";
/*  725 */     String paddedCheck = getEnvironmentalVariable(paddedProperty);
/*  726 */     boolean usePadded = false;
/*  727 */     if ((paddedCheck != null) && (paddedCheck.equals("1"))) {
/*  728 */       usePadded = true;
/*      */     }
/*  730 */     SWT_PADDED_MENU_ITEMS = usePadded;
/*      */     
/*  732 */     String menuLocationProperty = "SWT_MENU_LOCATION_DEBUGGING";
/*  733 */     String menuLocationCheck = getEnvironmentalVariable(menuLocationProperty);
/*  734 */     boolean menuLocationDebuggingEnabled = false;
/*  735 */     if ((menuLocationCheck != null) && (menuLocationCheck.equals("1"))) {
/*  736 */       menuLocationDebuggingEnabled = true;
/*      */     }
/*  738 */     SWT_MENU_LOCATION_DEBUGGING = menuLocationDebuggingEnabled;
/*      */     
/*  740 */     String gtkThemeProperty = "GTK_THEME";
/*  741 */     String gtkThemeCheck = getEnvironmentalVariable(gtkThemeProperty);
/*  742 */     boolean gtkThemeSet = false;
/*  743 */     String gtkThemeName = "";
/*  744 */     boolean gtkThemeDark = false;
/*  745 */     if ((gtkThemeCheck != null) && (!gtkThemeCheck.isEmpty())) {
/*  746 */       gtkThemeSet = true;
/*  747 */       gtkThemeDark = gtkThemeCheck.contains(":dark");
/*  748 */       String[] themeNameSplit = gtkThemeCheck.split(":");
/*  749 */       gtkThemeName = themeNameSplit[0];
/*      */     }
/*  751 */     GTK_THEME_SET = gtkThemeSet;
/*  752 */     GTK_THEME_NAME = gtkThemeName;
/*  753 */     GTK_THEME_DARK = gtkThemeDark;
/*      */     
/*  755 */     System.setProperty("org.eclipse.swt.internal.gtk.version", (GTK.GTK_VERSION >>> 16) + "." + (GTK.GTK_VERSION >>> 8 & 0xFF) + "." + (GTK.GTK_VERSION & 0xFF));
/*      */     
/*      */ 
/*  758 */     if (isX11()) {
/*  759 */       System.setProperty("org.eclipse.swt.internal.gdk.backend", "x11");
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  777 */     boolean cairoContextReuse = true;
/*  778 */     if ("false".equals(System.getProperty("org.eclipse.swt.internal.gtk.cairoContextReuse"))) {
/*  779 */       cairoContextReuse = false;
/*      */     }
/*  781 */     CAIRO_CONTEXT_REUSE = cairoContextReuse;
/*      */   }
/*      */   
/*      */   protected static byte[] ascii(String name) {
/*  785 */     int length = name.length();
/*  786 */     char[] chars = new char[length];
/*  787 */     name.getChars(0, length, chars, 0);
/*  788 */     byte[] buffer = new byte[length + 1];
/*  789 */     for (int i = 0; i < length; i++) {
/*  790 */       buffer[i] = ((byte)chars[i]);
/*      */     }
/*  792 */     return buffer;
/*      */   }
/*      */   
/*      */   public static int VERSION(int major, int minor, int micro) {
/*  796 */     return (major << 16) + (minor << 8) + micro;
/*      */   }
/*      */   
/*      */   public static boolean isX11() {
/*  800 */     return (GDK_WINDOWING_X11()) && (GDK.GDK_IS_X11_DISPLAY(GDK.gdk_display_get_default()));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int Call(long proc, long arg1, long arg2)
/*      */   {
/*  883 */     lock.lock();
/*      */     try {
/*  885 */       return _Call(proc, arg1, arg2);
/*      */     } finally {
/*  887 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final long call(long function, long arg0, long arg1, long arg2, long arg3, long arg4, long arg5, long arg6) {
/*  892 */     lock.lock();
/*      */     try {
/*  894 */       return _call(function, arg0, arg1, arg2, arg3, arg4, arg5, arg6);
/*      */     } finally {
/*  896 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final long call(long function, long arg0, long arg1, long arg2, long arg3) {
/*  901 */     lock.lock();
/*      */     try {
/*  903 */       return _call(function, arg0, arg1, arg2, arg3);
/*      */     } finally {
/*  905 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final long call(long function, long arg0, long arg1, long arg2, long arg3, long arg4, long arg5) {
/*  910 */     lock.lock();
/*      */     try {
/*  912 */       return _call(function, arg0, arg1, arg2, arg3, arg4, arg5);
/*      */     } finally {
/*  914 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final boolean XCheckIfEvent(long display, long event_return, long predicate, long arg)
/*      */   {
/*  925 */     lock.lock();
/*      */     try {
/*  927 */       return _XCheckIfEvent(display, event_return, predicate, arg);
/*      */     } finally {
/*  929 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final int XDefaultScreen(long display)
/*      */   {
/*  935 */     lock.lock();
/*      */     try {
/*  937 */       return _XDefaultScreen(display);
/*      */     } finally {
/*  939 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final long XDefaultRootWindow(long display)
/*      */   {
/*  945 */     lock.lock();
/*      */     try {
/*  947 */       return _XDefaultRootWindow(display);
/*      */     } finally {
/*  949 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int XQueryPointer(long display, long w, long[] root_return, long[] child_return, int[] root_x_return, int[] root_y_return, int[] win_x_return, int[] win_y_return, int[] mask_return)
/*      */   {
/*  976 */     lock.lock();
/*      */     try {
/*  978 */       return _XQueryPointer(display, w, root_return, child_return, root_x_return, root_y_return, win_x_return, win_y_return, mask_return);
/*      */     } finally {
/*  980 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int XKeysymToKeycode(long display, long keysym)
/*      */   {
/*  989 */     lock.lock();
/*      */     try {
/*  991 */       return _XKeysymToKeycode(display, keysym);
/*      */     } finally {
/*  993 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final long XSetIOErrorHandler(long handler)
/*      */   {
/*  999 */     lock.lock();
/*      */     try {
/* 1001 */       return _XSetIOErrorHandler(handler);
/*      */     } finally {
/* 1003 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final long XSetErrorHandler(long handler)
/*      */   {
/* 1009 */     lock.lock();
/*      */     try {
/* 1011 */       return _XSetErrorHandler(handler);
/*      */     } finally {
/* 1013 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int XSetInputFocus(long display, long window, int revert, int time)
/*      */   {
/* 1022 */     lock.lock();
/*      */     try {
/* 1024 */       return _XSetInputFocus(display, window, revert, time);
/*      */     } finally {
/* 1026 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int XSetTransientForHint(long display, long w, long prop_window)
/*      */   {
/* 1036 */     lock.lock();
/*      */     try {
/* 1038 */       return _XSetTransientForHint(display, w, prop_window);
/*      */     } finally {
/* 1040 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final long XSynchronize(long display, boolean onoff)
/*      */   {
/* 1046 */     lock.lock();
/*      */     try {
/* 1048 */       return _XSynchronize(display, onoff);
/*      */     } finally {
/* 1050 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void XTestFakeKeyEvent(long display, int keycode, boolean is_press, long delay)
/*      */   {
/* 1060 */     lock.lock();
/*      */     try {
/* 1062 */       _XTestFakeKeyEvent(display, keycode, is_press, delay);
/*      */     } finally {
/* 1064 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long G_OBJECT_CLASS(long klass)
/*      */   {
/* 1099 */     lock.lock();
/*      */     try {
/* 1101 */       return _G_OBJECT_CLASS(klass);
/*      */     } finally {
/* 1103 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final long G_OBJECT_GET_CLASS(long object) {
/* 1108 */     lock.lock();
/*      */     try {
/* 1110 */       return _G_OBJECT_GET_CLASS(object);
/*      */     } finally {
/* 1112 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final long G_OBJECT_TYPE_NAME(long object) {
/* 1117 */     lock.lock();
/*      */     try {
/* 1119 */       return _G_OBJECT_TYPE_NAME(object);
/*      */     } finally {
/* 1121 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final boolean G_TYPE_CHECK_INSTANCE_TYPE(long instance, long type)
/*      */   {
/* 1134 */     lock.lock();
/*      */     try {
/* 1136 */       return _G_TYPE_CHECK_INSTANCE_TYPE(instance, type);
/*      */     } finally {
/* 1138 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long G_OBJECT_TYPE(long instance)
/*      */   {
/* 1154 */     lock.lock();
/*      */     try {
/* 1156 */       return _G_OBJECT_TYPE(instance);
/*      */     } finally {
/* 1158 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final long G_TYPE_STRING()
/*      */   {
/* 1164 */     lock.lock();
/*      */     try {
/* 1166 */       return _G_TYPE_STRING();
/*      */     } finally {
/* 1168 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final int PANGO_PIXELS(int dimension) {
/* 1173 */     lock.lock();
/*      */     try {
/* 1175 */       return _PANGO_PIXELS(dimension);
/*      */     } finally {
/* 1177 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final long PANGO_TYPE_FONT_DESCRIPTION()
/*      */   {
/* 1183 */     lock.lock();
/*      */     try {
/* 1185 */       return _PANGO_TYPE_FONT_DESCRIPTION();
/*      */     } finally {
/* 1187 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final long PANGO_TYPE_FONT_FAMILY()
/*      */   {
/* 1193 */     lock.lock();
/*      */     try {
/* 1195 */       return _PANGO_TYPE_FONT_FAMILY();
/*      */     } finally {
/* 1197 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final long PANGO_TYPE_FONT_FACE()
/*      */   {
/* 1203 */     lock.lock();
/*      */     try {
/* 1205 */       return _PANGO_TYPE_FONT_FACE();
/*      */     } finally {
/* 1207 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final long PANGO_TYPE_LAYOUT()
/*      */   {
/* 1213 */     lock.lock();
/*      */     try {
/* 1215 */       return _PANGO_TYPE_LAYOUT();
/*      */     } finally {
/* 1217 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final long dlopen(byte[] filename, int flag)
/*      */   {
/* 1223 */     lock.lock();
/*      */     try {
/* 1225 */       return _dlopen(filename, flag);
/*      */     } finally {
/* 1227 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long g_app_info_create_from_commandline(byte[] commandline, byte[] applName, long flags, long error)
/*      */   {
/* 1238 */     lock.lock();
/*      */     try {
/* 1240 */       return _g_app_info_create_from_commandline(commandline, applName, flags, error);
/*      */     } finally {
/* 1242 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final long g_app_info_get_all() {
/* 1247 */     lock.lock();
/*      */     try {
/* 1249 */       return _g_app_info_get_all();
/*      */     } finally {
/* 1251 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final long g_app_info_get_executable(long appInfo)
/*      */   {
/* 1259 */     lock.lock();
/*      */     try {
/* 1261 */       return _g_app_info_get_executable(appInfo);
/*      */     } finally {
/* 1263 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final long g_app_info_get_icon(long appInfo)
/*      */   {
/* 1271 */     lock.lock();
/*      */     try {
/* 1273 */       return _g_app_info_get_icon(appInfo);
/*      */     } finally {
/* 1275 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final long g_app_info_get_name(long appInfo)
/*      */   {
/* 1283 */     lock.lock();
/*      */     try {
/* 1285 */       return _g_app_info_get_name(appInfo);
/*      */     } finally {
/* 1287 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final boolean g_app_info_launch(long appInfo, long list, long launchContext, long error)
/*      */   {
/* 1298 */     lock.lock();
/*      */     try {
/* 1300 */       return _g_app_info_launch(appInfo, list, launchContext, error);
/*      */     } finally {
/* 1302 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long g_app_info_get_default_for_type(byte[] mimeType, boolean mustSupportURIs)
/*      */   {
/* 1311 */     lock.lock();
/*      */     try {
/* 1313 */       return _g_app_info_get_default_for_type(mimeType, mustSupportURIs);
/*      */     } finally {
/* 1315 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final boolean g_app_info_launch_default_for_uri(long uri, long launchContext, long error)
/*      */   {
/* 1325 */     lock.lock();
/*      */     try {
/* 1327 */       return _g_app_info_launch_default_for_uri(uri, launchContext, error);
/*      */     } finally {
/* 1329 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final boolean g_app_info_should_show(long appInfo)
/*      */   {
/* 1337 */     lock.lock();
/*      */     try {
/* 1339 */       return _g_app_info_should_show(appInfo);
/*      */     } finally {
/* 1341 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final boolean g_app_info_supports_uris(long appInfo)
/*      */   {
/* 1349 */     lock.lock();
/*      */     try {
/* 1351 */       return _g_app_info_supports_uris(appInfo);
/*      */     } finally {
/* 1353 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final long g_error_get_message(long error)
/*      */   {
/* 1361 */     lock.lock();
/*      */     try {
/* 1363 */       return _g_error_get_message(error);
/*      */     } finally {
/* 1365 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final boolean g_content_type_equals(long type1, byte[] type2)
/*      */   {
/* 1388 */     lock.lock();
/*      */     try {
/* 1390 */       return _g_content_type_equals(type1, type2);
/*      */     } finally {
/* 1392 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final boolean g_content_type_is_a(long type, byte[] supertype)
/*      */   {
/* 1401 */     lock.lock();
/*      */     try {
/* 1403 */       return _g_content_type_is_a(type, supertype);
/*      */     } finally {
/* 1405 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final long g_file_info_get_content_type(long info)
/*      */   {
/* 1413 */     lock.lock();
/*      */     try {
/* 1415 */       return _g_file_info_get_content_type(info);
/*      */     } finally {
/* 1417 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final long g_file_get_uri(long file)
/*      */   {
/* 1425 */     lock.lock();
/*      */     try {
/* 1427 */       return _g_file_get_uri(file);
/*      */     } finally {
/* 1429 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final long g_file_new_for_path(byte[] fileName)
/*      */   {
/* 1435 */     lock.lock();
/*      */     try {
/* 1437 */       return _g_file_new_for_path(fileName);
/*      */     } finally {
/* 1439 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final long g_file_new_for_commandline_arg(byte[] fileName)
/*      */   {
/* 1447 */     lock.lock();
/*      */     try {
/* 1449 */       return _g_file_new_for_commandline_arg(fileName);
/*      */     } finally {
/* 1451 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final long g_file_new_for_uri(byte[] fileName)
/*      */   {
/* 1457 */     lock.lock();
/*      */     try {
/* 1459 */       return _g_file_new_for_uri(fileName);
/*      */     } finally {
/* 1461 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long g_file_query_info(long file, byte[] attributes, long flags, long cancellable, long error)
/*      */   {
/* 1473 */     lock.lock();
/*      */     try {
/* 1475 */       return _g_file_query_info(file, attributes, flags, cancellable, error);
/*      */     } finally {
/* 1477 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final boolean g_file_test(byte[] file, int test)
/*      */   {
/* 1486 */     lock.lock();
/*      */     try {
/* 1488 */       return _g_file_test(file, test);
/*      */     } finally {
/* 1490 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final long g_icon_to_string(long icon)
/*      */   {
/* 1496 */     lock.lock();
/*      */     try {
/* 1498 */       return _g_icon_to_string(icon);
/*      */     } finally {
/* 1500 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long g_icon_new_for_string(byte[] str, long[] error)
/*      */   {
/* 1509 */     lock.lock();
/*      */     try {
/* 1511 */       return _g_icon_new_for_string(str, error);
/*      */     } finally {
/* 1513 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long g_signal_add_emission_hook(int signal_id, int detail, long hook_func, long hook_data, long data_destroy)
/*      */   {
/* 1525 */     lock.lock();
/*      */     try {
/* 1527 */       return _g_signal_add_emission_hook(signal_id, detail, hook_func, hook_data, data_destroy);
/*      */     } finally {
/* 1529 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long g_cclosure_new(long callback_func, long user_data, long destroy_data)
/*      */   {
/* 1552 */     lock.lock();
/*      */     try {
/* 1554 */       return _g_cclosure_new(callback_func, user_data, destroy_data);
/*      */     } finally {
/* 1556 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final long g_closure_ref(long closure)
/*      */   {
/* 1562 */     lock.lock();
/*      */     try {
/* 1564 */       return _g_closure_ref(closure);
/*      */     } finally {
/* 1566 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final boolean g_main_context_acquire(long context)
/*      */   {
/* 1592 */     lock.lock();
/*      */     try {
/* 1594 */       return _g_main_context_acquire(context);
/*      */     } finally {
/* 1596 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int g_main_context_check(long context, int max_priority, long fds, int n_fds)
/*      */   {
/* 1605 */     lock.lock();
/*      */     try {
/* 1607 */       return _g_main_context_check(context, max_priority, fds, n_fds);
/*      */     } finally {
/* 1609 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final long g_main_context_default() {
/* 1614 */     lock.lock();
/*      */     try {
/* 1616 */       return _g_main_context_default();
/*      */     } finally {
/* 1618 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final boolean g_main_context_iteration(long context, boolean may_block)
/*      */   {
/* 1624 */     lock.lock();
/*      */     try {
/* 1626 */       return _g_main_context_iteration(context, may_block);
/*      */     } finally {
/* 1628 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final long g_main_context_get_poll_func(long context)
/*      */   {
/* 1634 */     lock.lock();
/*      */     try {
/* 1636 */       return _g_main_context_get_poll_func(context);
/*      */     } finally {
/* 1638 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final boolean g_main_context_prepare(long context, int[] priority)
/*      */   {
/* 1647 */     lock.lock();
/*      */     try {
/* 1649 */       return _g_main_context_prepare(context, priority);
/*      */     } finally {
/* 1651 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int g_main_context_query(long context, int max_priority, int[] timeout_, long fds, int n_fds)
/*      */   {
/* 1661 */     lock.lock();
/*      */     try {
/* 1663 */       return _g_main_context_query(context, max_priority, timeout_, fds, n_fds);
/*      */     } finally {
/* 1665 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long g_filename_to_utf8(long opsysstring, long len, long[] bytes_read, long[] bytes_written, long[] error)
/*      */   {
/* 1689 */     lock.lock();
/*      */     try {
/* 1691 */       return _g_filename_to_utf8(opsysstring, len, bytes_read, bytes_written, error);
/*      */     } finally {
/* 1693 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final long g_filename_display_name(long filename)
/*      */   {
/* 1699 */     lock.lock();
/*      */     try {
/* 1701 */       return _g_filename_display_name(filename);
/*      */     } finally {
/* 1703 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long g_filename_to_uri(long filename, long hostname, long[] error)
/*      */   {
/* 1713 */     lock.lock();
/*      */     try {
/* 1715 */       return _g_filename_to_uri(filename, hostname, error);
/*      */     } finally {
/* 1717 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long g_filename_from_utf8(long opsysstring, long len, long[] bytes_read, long[] bytes_written, long[] error)
/*      */   {
/* 1729 */     lock.lock();
/*      */     try {
/* 1731 */       return _g_filename_from_utf8(opsysstring, len, bytes_read, bytes_written, error);
/*      */     } finally {
/* 1733 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long g_filename_from_uri(long uri, long[] hostname, long[] error)
/*      */   {
/* 1743 */     lock.lock();
/*      */     try {
/* 1745 */       return _g_filename_from_uri(uri, hostname, error);
/*      */     } finally {
/* 1747 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long g_hash_table_get_values(long table)
/*      */   {
/* 1765 */     lock.lock();
/*      */     try {
/* 1767 */       return _g_hash_table_get_values(table);
/*      */     } finally {
/* 1769 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int g_idle_add(long function, long data)
/*      */   {
/* 1778 */     lock.lock();
/*      */     try {
/* 1780 */       return _g_idle_add(function, data);
/*      */     } finally {
/* 1782 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long g_list_append(long list, long data)
/*      */   {
/* 1791 */     lock.lock();
/*      */     try {
/* 1793 */       return _g_list_append(list, data);
/*      */     } finally {
/* 1795 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final long g_list_data(long list)
/*      */   {
/* 1801 */     lock.lock();
/*      */     try {
/* 1803 */       return _g_list_data(list);
/*      */     } finally {
/* 1805 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long g_list_last(long list)
/*      */   {
/* 1833 */     lock.lock();
/*      */     try {
/* 1835 */       return _g_list_last(list);
/*      */     } finally {
/* 1837 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final int g_list_length(long list)
/*      */   {
/* 1843 */     lock.lock();
/*      */     try {
/* 1845 */       return _g_list_length(list);
/*      */     } finally {
/* 1847 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void g_list_set_next(long list, long llist)
/*      */   {
/* 1856 */     lock.lock();
/*      */     try {
/* 1858 */       _g_list_set_next(list, llist);
/*      */     } finally {
/* 1860 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final long g_list_next(long list) {
/* 1865 */     lock.lock();
/*      */     try {
/* 1867 */       return _g_list_next(list);
/*      */     } finally {
/* 1869 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long g_list_nth(long list, int n)
/*      */   {
/* 1878 */     lock.lock();
/*      */     try {
/* 1880 */       return _g_list_nth(list, n);
/*      */     } finally {
/* 1882 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long g_list_nth_data(long list, int n)
/*      */   {
/* 1891 */     lock.lock();
/*      */     try {
/* 1893 */       return _g_list_nth_data(list, n);
/*      */     } finally {
/* 1895 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long g_list_prepend(long list, long data)
/*      */   {
/* 1904 */     lock.lock();
/*      */     try {
/* 1906 */       return _g_list_prepend(list, data);
/*      */     } finally {
/* 1908 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void g_list_set_previous(long list, long llist)
/*      */   {
/* 1917 */     lock.lock();
/*      */     try {
/* 1919 */       _g_list_set_previous(list, llist);
/*      */     } finally {
/* 1921 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final long g_list_previous(long list) {
/* 1926 */     lock.lock();
/*      */     try {
/* 1928 */       return _g_list_previous(list);
/*      */     } finally {
/* 1930 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long g_list_remove_link(long list, long link)
/*      */   {
/* 1939 */     lock.lock();
/*      */     try {
/* 1941 */       return _g_list_remove_link(list, link);
/*      */     } finally {
/* 1943 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void g_log_default_handler(long log_domain, int log_levels, long message, long unused_data)
/*      */   {
/* 1954 */     lock.lock();
/*      */     try {
/* 1956 */       _g_log_default_handler(log_domain, log_levels, message, unused_data);
/*      */     } finally {
/* 1958 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int g_log_set_handler(byte[] log_domain, int log_levels, long log_func, long user_data)
/*      */   {
/* 1982 */     lock.lock();
/*      */     try {
/* 1984 */       return _g_log_set_handler(log_domain, log_levels, log_func, user_data);
/*      */     } finally {
/* 1986 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final long g_malloc(long size)
/*      */   {
/* 1992 */     lock.lock();
/*      */     try {
/* 1994 */       return _g_malloc(size);
/*      */     } finally {
/* 1996 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long g_object_class_find_property(long oclass, byte[] property_name)
/*      */   {
/* 2005 */     lock.lock();
/*      */     try {
/* 2007 */       return _g_object_class_find_property(oclass, property_name);
/*      */     } finally {
/* 2009 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void g_object_get(long object, byte[] first_property_name, int[] value, long terminator)
/*      */   {
/* 2019 */     lock.lock();
/*      */     try {
/* 2021 */       _g_object_get(object, first_property_name, value, terminator);
/*      */     } finally {
/* 2023 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void g_object_get(long object, byte[] first_property_name, long[] value, long terminator)
/*      */   {
/* 2033 */     lock.lock();
/*      */     try {
/* 2035 */       _g_object_get(object, first_property_name, value, terminator);
/*      */     } finally {
/* 2037 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long g_object_get_qdata(long object, int quark)
/*      */   {
/* 2046 */     lock.lock();
/*      */     try {
/* 2048 */       return _g_object_get_qdata(object, quark);
/*      */     } finally {
/* 2050 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long g_object_new(long type, long first_property_name)
/*      */   {
/* 2059 */     lock.lock();
/*      */     try {
/* 2061 */       return _g_object_new(type, first_property_name);
/*      */     } finally {
/* 2063 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long g_object_ref(long object)
/*      */   {
/* 2082 */     lock.lock();
/*      */     try {
/* 2084 */       return _g_object_ref(object);
/*      */     } finally {
/* 2086 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void g_object_set(long object, byte[] first_property_name, boolean data, long terminator)
/*      */   {
/* 2096 */     lock.lock();
/*      */     try {
/* 2098 */       _g_object_set(object, first_property_name, data, terminator);
/*      */     } finally {
/* 2100 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void g_object_set(long object, byte[] first_property_name, byte[] data, long terminator)
/*      */   {
/* 2110 */     lock.lock();
/*      */     try {
/* 2112 */       _g_object_set(object, first_property_name, data, terminator);
/*      */     } finally {
/* 2114 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void g_object_set(long object, byte[] first_property_name, GdkColor data, long terminator)
/*      */   {
/* 2124 */     lock.lock();
/*      */     try {
/* 2126 */       _g_object_set(object, first_property_name, data, terminator);
/*      */     } finally {
/* 2128 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void g_object_set(long object, byte[] first_property_name, GdkRGBA data, long terminator)
/*      */   {
/* 2141 */     lock.lock();
/*      */     try {
/* 2143 */       _g_object_set(object, first_property_name, data, terminator);
/*      */     } finally {
/* 2145 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void g_object_set(long object, byte[] first_property_name, int data, long terminator)
/*      */   {
/* 2156 */     lock.lock();
/*      */     try {
/* 2158 */       _g_object_set(object, first_property_name, data, terminator);
/*      */     } finally {
/* 2160 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void g_object_set(long object, byte[] first_property_name, float data, long terminator)
/*      */   {
/* 2170 */     lock.lock();
/*      */     try {
/* 2172 */       _g_object_set(object, first_property_name, data, terminator);
/*      */     } finally {
/* 2174 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void g_object_set(long object, byte[] first_property_name, long data, long terminator)
/*      */   {
/* 2184 */     lock.lock();
/*      */     try {
/* 2186 */       _g_object_set(object, first_property_name, data, terminator);
/*      */     } finally {
/* 2188 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void g_object_set_qdata(long object, int quark, long data)
/*      */   {
/* 2198 */     lock.lock();
/*      */     try {
/* 2200 */       _g_object_set_qdata(object, quark, data);
/*      */     } finally {
/* 2202 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long g_bytes_new(byte[] data, long size)
/*      */   {
/* 2224 */     assert (MIN_GLIB_2_32);
/* 2225 */     lock.lock();
/*      */     try {
/* 2227 */       return _g_bytes_new(data, size);
/*      */     } finally {
/* 2229 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int g_quark_from_string(byte[] string)
/*      */   {
/* 2251 */     lock.lock();
/*      */     try {
/* 2253 */       return _g_quark_from_string(string);
/*      */     } finally {
/* 2255 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int g_signal_connect(long instance, byte[] detailed_signal, long proc, long data)
/*      */   {
/* 2276 */     lock.lock();
/*      */     try {
/* 2278 */       return _g_signal_connect(instance, detailed_signal, proc, data);
/*      */     } finally {
/* 2280 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int g_signal_connect_closure(long instance, byte[] detailed_signal, long closure, boolean after)
/*      */   {
/* 2291 */     lock.lock();
/*      */     try {
/* 2293 */       return _g_signal_connect_closure(instance, detailed_signal, closure, after);
/*      */     } finally {
/* 2295 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int g_signal_connect_closure_by_id(long instance, int signal_id, int detail, long closure, boolean after)
/*      */   {
/* 2307 */     lock.lock();
/*      */     try {
/* 2309 */       return _g_signal_connect_closure_by_id(instance, signal_id, detail, closure, after);
/*      */     } finally {
/* 2311 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void g_signal_emit_by_name(long instance, byte[] detailed_signal, long data)
/*      */   {
/* 2333 */     lock.lock();
/*      */     try {
/* 2335 */       _g_signal_emit_by_name(instance, detailed_signal, data);
/*      */     } finally {
/* 2337 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void g_signal_emit_by_name(long instance, byte[] detailed_signal, GdkRectangle data)
/*      */   {
/* 2346 */     lock.lock();
/*      */     try {
/* 2348 */       _g_signal_emit_by_name(instance, detailed_signal, data);
/*      */     } finally {
/* 2350 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void g_signal_emit_by_name(long instance, byte[] detailed_signal, long data1, long data2)
/*      */   {
/* 2359 */     lock.lock();
/*      */     try {
/* 2361 */       _g_signal_emit_by_name(instance, detailed_signal, data1, data2);
/*      */     } finally {
/* 2363 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void g_signal_emit_by_name(long instance, byte[] detailed_signal, byte[] data)
/*      */   {
/* 2372 */     lock.lock();
/*      */     try {
/* 2374 */       _g_signal_emit_by_name(instance, detailed_signal, data);
/*      */     } finally {
/* 2376 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int g_signal_handler_find(long instance, int mask, int signal_id, int detail, long closure, long func, long data)
/*      */   {
/* 2401 */     lock.lock();
/*      */     try {
/* 2403 */       return _g_signal_handler_find(instance, mask, signal_id, detail, closure, func, data);
/*      */     } finally {
/* 2405 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int g_signal_handlers_block_matched(long instance, int mask, int signal_id, int detail, long closure, long func, long data)
/*      */   {
/* 2419 */     lock.lock();
/*      */     try {
/* 2421 */       return _g_signal_handlers_block_matched(instance, mask, signal_id, detail, closure, func, data);
/*      */     } finally {
/* 2423 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int g_signal_handlers_unblock_matched(long instance, int mask, int signal_id, int detail, long closure, long func, long data)
/*      */   {
/* 2437 */     lock.lock();
/*      */     try {
/* 2439 */       return _g_signal_handlers_unblock_matched(instance, mask, signal_id, detail, closure, func, data);
/*      */     } finally {
/* 2441 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final int g_signal_lookup(byte[] name, long itype)
/*      */   {
/* 2447 */     lock.lock();
/*      */     try {
/* 2449 */       return _g_signal_lookup(name, itype);
/*      */     } finally {
/* 2451 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final boolean g_source_remove(long tag)
/*      */   {
/* 2470 */     lock.lock();
/*      */     try {
/* 2472 */       return _g_source_remove(tag);
/*      */     } finally {
/* 2474 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long g_slist_append(long list, long data)
/*      */   {
/* 2483 */     lock.lock();
/*      */     try {
/* 2485 */       return _g_slist_append(list, data);
/*      */     } finally {
/* 2487 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final long g_slist_data(long list)
/*      */   {
/* 2493 */     lock.lock();
/*      */     try {
/* 2495 */       return _g_slist_data(list);
/*      */     } finally {
/* 2497 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long g_slist_next(long list)
/*      */   {
/* 2513 */     lock.lock();
/*      */     try {
/* 2515 */       return _g_slist_next(list);
/*      */     } finally {
/* 2517 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final int g_slist_length(long list)
/*      */   {
/* 2523 */     lock.lock();
/*      */     try {
/* 2525 */       return _g_slist_length(list);
/*      */     } finally {
/* 2527 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int GString_len(long string)
/*      */   {
/* 2546 */     lock.lock();
/*      */     try {
/* 2548 */       return _GString_len(string);
/*      */     } finally {
/* 2550 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long GString_str(long string)
/*      */   {
/* 2559 */     lock.lock();
/*      */     try {
/* 2561 */       return _GString_str(string);
/*      */     } finally {
/* 2563 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long g_string_new_len(long init, long gssize)
/*      */   {
/* 2573 */     lock.lock();
/*      */     try {
/* 2575 */       return _g_string_new_len(init, gssize);
/*      */     } finally {
/* 2577 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long g_string_free(long GString, int gboolen_free_segment)
/*      */   {
/* 2587 */     lock.lock();
/*      */     try {
/* 2589 */       return _g_string_free(GString, gboolen_free_segment);
/*      */     } finally {
/* 2591 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final double g_strtod(long str, long[] endptr)
/*      */   {
/* 2601 */     lock.lock();
/*      */     try {
/* 2603 */       return _g_strtod(str, endptr);
/*      */     } finally {
/* 2605 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void g_type_add_interface_static(long instance_type, long interface_type, long info)
/*      */   {
/* 2617 */     lock.lock();
/*      */     try {
/* 2619 */       _g_type_add_interface_static(instance_type, interface_type, info);
/*      */     } finally {
/* 2621 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final long g_type_class_peek(long g_class)
/*      */   {
/* 2627 */     lock.lock();
/*      */     try {
/* 2629 */       return _g_type_class_peek(g_class);
/*      */     } finally {
/* 2631 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final long g_type_class_peek_parent(long g_class)
/*      */   {
/* 2637 */     lock.lock();
/*      */     try {
/* 2639 */       return _g_type_class_peek_parent(g_class);
/*      */     } finally {
/* 2641 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final long g_type_class_ref(long g_class)
/*      */   {
/* 2647 */     lock.lock();
/*      */     try {
/* 2649 */       return _g_type_class_ref(g_class);
/*      */     } finally {
/* 2651 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long g_type_from_name(byte[] name)
/*      */   {
/* 2667 */     lock.lock();
/*      */     try {
/* 2669 */       return _g_type_from_name(name);
/*      */     } finally {
/* 2671 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final long g_type_interface_peek_parent(long iface)
/*      */   {
/* 2677 */     lock.lock();
/*      */     try {
/* 2679 */       return _g_type_interface_peek_parent(iface);
/*      */     } finally {
/* 2681 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final boolean g_type_is_a(long type, long is_a_type)
/*      */   {
/* 2690 */     lock.lock();
/*      */     try {
/* 2692 */       return _g_type_is_a(type, is_a_type);
/*      */     } finally {
/* 2694 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final long g_type_name(long handle)
/*      */   {
/* 2700 */     lock.lock();
/*      */     try {
/* 2702 */       return _g_type_name(handle);
/*      */     } finally {
/* 2704 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final long g_type_parent(long type)
/*      */   {
/* 2710 */     lock.lock();
/*      */     try {
/* 2712 */       return _g_type_parent(type);
/*      */     } finally {
/* 2714 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void g_type_query(long type, long query)
/*      */   {
/* 2723 */     lock.lock();
/*      */     try {
/* 2725 */       _g_type_query(type, query);
/*      */     } finally {
/* 2727 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long g_type_register_static(long parent_type, byte[] type_name, long info, int flags)
/*      */   {
/* 2738 */     lock.lock();
/*      */     try {
/* 2740 */       return _g_type_register_static(parent_type, type_name, info, flags);
/*      */     } finally {
/* 2742 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final boolean g_thread_supported()
/*      */   {
/* 2761 */     lock.lock();
/*      */     try {
/* 2763 */       return _g_thread_supported();
/*      */     } finally {
/* 2765 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long g_utf16_to_utf8(char[] str, long len, long[] items_read, long[] items_written, long[] error)
/*      */   {
/* 2777 */     lock.lock();
/*      */     try {
/* 2779 */       return _g_utf16_to_utf8(str, len, items_read, items_written, error);
/*      */     } finally {
/* 2781 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long g_utf8_pointer_to_offset(long str, long pos)
/*      */   {
/* 2790 */     lock.lock();
/*      */     try {
/* 2792 */       return _g_utf8_pointer_to_offset(str, pos);
/*      */     } finally {
/* 2794 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final long g_utf8_strlen(long str, long max)
/*      */   {
/* 2800 */     lock.lock();
/*      */     try {
/* 2802 */       return _g_utf8_strlen(str, max);
/*      */     } finally {
/* 2804 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long g_utf8_to_utf16(byte[] str, long len, long[] items_read, long[] items_written, long[] error)
/*      */   {
/* 2816 */     lock.lock();
/*      */     try {
/* 2818 */       return _g_utf8_to_utf16(str, len, items_read, items_written, error);
/*      */     } finally {
/* 2820 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long g_utf8_to_utf16(long str, long len, long[] items_read, long[] items_written, long[] error)
/*      */   {
/* 2832 */     lock.lock();
/*      */     try {
/* 2834 */       return _g_utf8_to_utf16(str, len, items_read, items_written, error);
/*      */     } finally {
/* 2836 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long g_value_peek_pointer(long value)
/*      */   {
/* 2865 */     lock.lock();
/*      */     try {
/* 2867 */       return _g_value_peek_pointer(value);
/*      */     } finally {
/* 2869 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final int glib_major_version()
/*      */   {
/* 2876 */     lock.lock();
/*      */     try {
/* 2878 */       return _glib_major_version();
/*      */     } finally {
/* 2880 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final int glib_minor_version()
/*      */   {
/* 2886 */     lock.lock();
/*      */     try {
/* 2888 */       return _glib_minor_version();
/*      */     } finally {
/* 2890 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final int glib_micro_version()
/*      */   {
/* 2896 */     lock.lock();
/*      */     try {
/* 2898 */       return _glib_micro_version();
/*      */     } finally {
/* 2900 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int g_timeout_add(int interval, long function, long data)
/*      */   {
/* 2911 */     lock.lock();
/*      */     try {
/* 2913 */       return _g_timeout_add(interval, function, data);
/*      */     } finally {
/* 2915 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final boolean FcConfigAppFontAddFile(long config, byte[] file)
/*      */   {
/* 2922 */     lock.lock();
/*      */     try {
/* 2924 */       return _FcConfigAppFontAddFile(config, file);
/*      */     } finally {
/* 2926 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int getpid()
/*      */   {
/* 2937 */     lock.lock();
/*      */     try {
/* 2939 */       return _getpid();
/*      */     } finally {
/* 2941 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long pango_attribute_copy(long attribute)
/*      */   {
/* 3186 */     lock.lock();
/*      */     try {
/* 3188 */       return _pango_attribute_copy(attribute);
/*      */     } finally {
/* 3190 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final long pango_attr_background_new(short red, short green, short blue) {
/* 3195 */     lock.lock();
/*      */     try {
/* 3197 */       return _pango_attr_background_new(red, green, blue);
/*      */     } finally {
/* 3199 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final long pango_attr_font_desc_new(long desc)
/*      */   {
/* 3205 */     lock.lock();
/*      */     try {
/* 3207 */       return _pango_attr_font_desc_new(desc);
/*      */     } finally {
/* 3209 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final long pango_attr_foreground_new(short red, short green, short blue) {
/* 3214 */     lock.lock();
/*      */     try {
/* 3216 */       return _pango_attr_foreground_new(red, green, blue);
/*      */     } finally {
/* 3218 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final long pango_attr_rise_new(int rise) {
/* 3223 */     lock.lock();
/*      */     try {
/* 3225 */       return _pango_attr_rise_new(rise);
/*      */     } finally {
/* 3227 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long pango_attr_shape_new(PangoRectangle ink_rect, PangoRectangle logical_rect)
/*      */   {
/* 3236 */     lock.lock();
/*      */     try {
/* 3238 */       return _pango_attr_shape_new(ink_rect, logical_rect);
/*      */     } finally {
/* 3240 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void pango_attr_list_insert(long list, long attr)
/*      */   {
/* 3249 */     lock.lock();
/*      */     try {
/* 3251 */       _pango_attr_list_insert(list, attr);
/*      */     } finally {
/* 3253 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final long pango_attr_list_get_iterator(long list)
/*      */   {
/* 3259 */     lock.lock();
/*      */     try {
/* 3261 */       return _pango_attr_list_get_iterator(list);
/*      */     } finally {
/* 3263 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final boolean pango_attr_iterator_next(long iterator)
/*      */   {
/* 3269 */     lock.lock();
/*      */     try {
/* 3271 */       return _pango_attr_iterator_next(iterator);
/*      */     } finally {
/* 3273 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void pango_attr_iterator_range(long iterator, int[] start, int[] end)
/*      */   {
/* 3283 */     lock.lock();
/*      */     try {
/* 3285 */       _pango_attr_iterator_range(iterator, start, end);
/*      */     } finally {
/* 3287 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long pango_attr_iterator_get(long iterator, int type)
/*      */   {
/* 3296 */     lock.lock();
/*      */     try {
/* 3298 */       return _pango_attr_iterator_get(iterator, type);
/*      */     } finally {
/* 3300 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long pango_attr_list_new()
/*      */   {
/* 3315 */     lock.lock();
/*      */     try {
/* 3317 */       return _pango_attr_list_new();
/*      */     } finally {
/* 3319 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long pango_attr_strikethrough_color_new(short red, short green, short blue)
/*      */   {
/* 3334 */     lock.lock();
/*      */     try {
/* 3336 */       return _pango_attr_strikethrough_color_new(red, green, blue);
/*      */     } finally {
/* 3338 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final long pango_attr_strikethrough_new(boolean strikethrough) {
/* 3343 */     lock.lock();
/*      */     try {
/* 3345 */       return _pango_attr_strikethrough_new(strikethrough);
/*      */     } finally {
/* 3347 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final long pango_attr_underline_color_new(short red, short green, short blue) {
/* 3352 */     lock.lock();
/*      */     try {
/* 3354 */       return _pango_attr_underline_color_new(red, green, blue);
/*      */     } finally {
/* 3356 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final long pango_attr_underline_new(int underline) {
/* 3361 */     lock.lock();
/*      */     try {
/* 3363 */       return _pango_attr_underline_new(underline);
/*      */     } finally {
/* 3365 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final long pango_attr_weight_new(int weight) {
/* 3370 */     lock.lock();
/*      */     try {
/* 3372 */       return _pango_attr_weight_new(weight);
/*      */     } finally {
/* 3374 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final long pango_cairo_create_layout(long cairo)
/*      */   {
/* 3382 */     lock.lock();
/*      */     try {
/* 3384 */       return _pango_cairo_create_layout(cairo);
/*      */     } finally {
/* 3386 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final long pango_cairo_context_get_font_options(long context)
/*      */   {
/* 3394 */     lock.lock();
/*      */     try {
/* 3396 */       return _pango_cairo_context_get_font_options(context);
/*      */     } finally {
/* 3398 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void pango_cairo_context_set_font_options(long context, long options)
/*      */   {
/* 3407 */     lock.lock();
/*      */     try {
/* 3409 */       _pango_cairo_context_set_font_options(context, options);
/*      */     } finally {
/* 3411 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void pango_cairo_layout_path(long cairo, long layout)
/*      */   {
/* 3420 */     lock.lock();
/*      */     try {
/* 3422 */       _pango_cairo_layout_path(cairo, layout);
/*      */     } finally {
/* 3424 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void pango_cairo_show_layout(long cairo, long layout)
/*      */   {
/* 3433 */     lock.lock();
/*      */     try {
/* 3435 */       _pango_cairo_show_layout(cairo, layout);
/*      */     } finally {
/* 3437 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final int pango_context_get_base_dir(long context)
/*      */   {
/* 3443 */     lock.lock();
/*      */     try {
/* 3445 */       return _pango_context_get_base_dir(context);
/*      */     } finally {
/* 3447 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final long pango_context_get_language(long context)
/*      */   {
/* 3453 */     lock.lock();
/*      */     try {
/* 3455 */       return _pango_context_get_language(context);
/*      */     } finally {
/* 3457 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long pango_context_get_metrics(long context, long desc, long language)
/*      */   {
/* 3467 */     lock.lock();
/*      */     try {
/* 3469 */       return _pango_context_get_metrics(context, desc, language);
/*      */     } finally {
/* 3471 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void pango_context_list_families(long context, long[] families, int[] n_families)
/*      */   {
/* 3481 */     lock.lock();
/*      */     try {
/* 3483 */       _pango_context_list_families(context, families, n_families);
/*      */     } finally {
/* 3485 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void pango_context_set_language(long context, long language)
/*      */   {
/* 3504 */     lock.lock();
/*      */     try {
/* 3506 */       _pango_context_set_language(context, language);
/*      */     } finally {
/* 3508 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final long pango_font_description_copy(long desc)
/*      */   {
/* 3514 */     lock.lock();
/*      */     try {
/* 3516 */       return _pango_font_description_copy(desc);
/*      */     } finally {
/* 3518 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long pango_font_description_from_string(byte[] str)
/*      */   {
/* 3534 */     lock.lock();
/*      */     try {
/* 3536 */       return _pango_font_description_from_string(str);
/*      */     } finally {
/* 3538 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final long pango_font_description_get_family(long desc)
/*      */   {
/* 3544 */     lock.lock();
/*      */     try {
/* 3546 */       return _pango_font_description_get_family(desc);
/*      */     } finally {
/* 3548 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final int pango_font_description_get_size(long desc)
/*      */   {
/* 3554 */     lock.lock();
/*      */     try {
/* 3556 */       return _pango_font_description_get_size(desc);
/*      */     } finally {
/* 3558 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final int pango_font_description_get_stretch(long desc)
/*      */   {
/* 3564 */     lock.lock();
/*      */     try {
/* 3566 */       return _pango_font_description_get_stretch(desc);
/*      */     } finally {
/* 3568 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final int pango_font_description_get_variant(long desc)
/*      */   {
/* 3574 */     lock.lock();
/*      */     try {
/* 3576 */       return _pango_font_description_get_variant(desc);
/*      */     } finally {
/* 3578 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final int pango_font_description_get_style(long desc)
/*      */   {
/* 3584 */     lock.lock();
/*      */     try {
/* 3586 */       return _pango_font_description_get_style(desc);
/*      */     } finally {
/* 3588 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final int pango_font_description_get_weight(long desc)
/*      */   {
/* 3594 */     lock.lock();
/*      */     try {
/* 3596 */       return _pango_font_description_get_weight(desc);
/*      */     } finally {
/* 3598 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final long pango_font_description_new() {
/* 3603 */     lock.lock();
/*      */     try {
/* 3605 */       return _pango_font_description_new();
/*      */     } finally {
/* 3607 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long pango_font_description_to_string(long desc)
/*      */   {
/* 3691 */     lock.lock();
/*      */     try {
/* 3693 */       return _pango_font_description_to_string(desc);
/*      */     } finally {
/* 3695 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final long pango_font_face_describe(long face)
/*      */   {
/* 3701 */     lock.lock();
/*      */     try {
/* 3703 */       return _pango_font_face_describe(face);
/*      */     } finally {
/* 3705 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final long pango_font_family_get_name(long family)
/*      */   {
/* 3711 */     lock.lock();
/*      */     try {
/* 3713 */       return _pango_font_family_get_name(family);
/*      */     } finally {
/* 3715 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void pango_font_family_list_faces(long family, long[] faces, int[] n_faces)
/*      */   {
/* 3725 */     lock.lock();
/*      */     try {
/* 3727 */       _pango_font_family_list_faces(family, faces, n_faces);
/*      */     } finally {
/* 3729 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long pango_font_get_metrics(long font, long language)
/*      */   {
/* 3738 */     lock.lock();
/*      */     try {
/* 3740 */       return _pango_font_get_metrics(font, language);
/*      */     } finally {
/* 3742 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final int pango_font_metrics_get_approximate_char_width(long metrics)
/*      */   {
/* 3748 */     lock.lock();
/*      */     try {
/* 3750 */       return _pango_font_metrics_get_approximate_char_width(metrics);
/*      */     } finally {
/* 3752 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final int pango_font_metrics_get_ascent(long metrics)
/*      */   {
/* 3758 */     lock.lock();
/*      */     try {
/* 3760 */       return _pango_font_metrics_get_ascent(metrics);
/*      */     } finally {
/* 3762 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final int pango_font_metrics_get_descent(long metrics)
/*      */   {
/* 3768 */     lock.lock();
/*      */     try {
/* 3770 */       return _pango_font_metrics_get_descent(metrics);
/*      */     } finally {
/* 3772 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int pango_layout_get_alignment(long layout)
/*      */   {
/* 3798 */     lock.lock();
/*      */     try {
/* 3800 */       return _pango_layout_get_alignment(layout);
/*      */     } finally {
/* 3802 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final long pango_layout_get_context(long layout)
/*      */   {
/* 3808 */     lock.lock();
/*      */     try {
/* 3810 */       return _pango_layout_get_context(layout);
/*      */     } finally {
/* 3812 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final int pango_layout_get_indent(long layout)
/*      */   {
/* 3818 */     lock.lock();
/*      */     try {
/* 3820 */       return _pango_layout_get_indent(layout);
/*      */     } finally {
/* 3822 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final long pango_layout_get_iter(long layout)
/*      */   {
/* 3828 */     lock.lock();
/*      */     try {
/* 3830 */       return _pango_layout_get_iter(layout);
/*      */     } finally {
/* 3832 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final boolean pango_layout_get_justify(long layout)
/*      */   {
/* 3838 */     lock.lock();
/*      */     try {
/* 3840 */       return _pango_layout_get_justify(layout);
/*      */     } finally {
/* 3842 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final long pango_layout_get_line(long layout, int line)
/*      */   {
/* 3848 */     lock.lock();
/*      */     try {
/* 3850 */       return _pango_layout_get_line(layout, line);
/*      */     } finally {
/* 3852 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final int pango_layout_get_line_count(long layout)
/*      */   {
/* 3858 */     lock.lock();
/*      */     try {
/* 3860 */       return _pango_layout_get_line_count(layout);
/*      */     } finally {
/* 3862 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void pango_layout_get_log_attrs(long layout, long[] attrs, int[] n_attrs)
/*      */   {
/* 3872 */     lock.lock();
/*      */     try {
/* 3874 */       _pango_layout_get_log_attrs(layout, attrs, n_attrs);
/*      */     } finally {
/* 3876 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void pango_layout_get_size(long layout, int[] width, int[] height)
/*      */   {
/* 3886 */     lock.lock();
/*      */     try {
/* 3888 */       _pango_layout_get_size(layout, width, height);
/*      */     } finally {
/* 3890 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void pango_layout_get_pixel_size(long layout, int[] width, int[] height)
/*      */   {
/* 3900 */     lock.lock();
/*      */     try {
/* 3902 */       _pango_layout_get_pixel_size(layout, width, height);
/*      */     } finally {
/* 3904 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final int pango_layout_get_spacing(long layout)
/*      */   {
/* 3910 */     lock.lock();
/*      */     try {
/* 3912 */       return _pango_layout_get_spacing(layout);
/*      */     } finally {
/* 3914 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final long pango_layout_get_text(long layout)
/*      */   {
/* 3920 */     lock.lock();
/*      */     try {
/* 3922 */       return _pango_layout_get_text(layout);
/*      */     } finally {
/* 3924 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final int pango_layout_get_width(long layout)
/*      */   {
/* 3930 */     lock.lock();
/*      */     try {
/* 3932 */       return _pango_layout_get_width(layout);
/*      */     } finally {
/* 3934 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void pango_layout_index_to_pos(long layout, int index, PangoRectangle pos)
/*      */   {
/* 3943 */     lock.lock();
/*      */     try {
/* 3945 */       _pango_layout_index_to_pos(layout, index, pos);
/*      */     } finally {
/* 3947 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void pango_layout_iter_get_line_extents(long iter, PangoRectangle ink_rect, PangoRectangle logical_rect)
/*      */   {
/* 3967 */     lock.lock();
/*      */     try {
/* 3969 */       _pango_layout_iter_get_line_extents(iter, ink_rect, logical_rect);
/*      */     } finally {
/* 3971 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final int pango_layout_iter_get_index(long iter)
/*      */   {
/* 3977 */     lock.lock();
/*      */     try {
/* 3979 */       return _pango_layout_iter_get_index(iter);
/*      */     } finally {
/* 3981 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final long pango_layout_iter_get_run(long iter)
/*      */   {
/* 3987 */     lock.lock();
/*      */     try {
/* 3989 */       return _pango_layout_iter_get_run(iter);
/*      */     } finally {
/* 3991 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final boolean pango_layout_iter_next_line(long iter)
/*      */   {
/* 3997 */     lock.lock();
/*      */     try {
/* 3999 */       return _pango_layout_iter_next_line(iter);
/*      */     } finally {
/* 4001 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final boolean pango_layout_iter_next_run(long iter)
/*      */   {
/* 4007 */     lock.lock();
/*      */     try {
/* 4009 */       return _pango_layout_iter_next_run(iter);
/*      */     } finally {
/* 4011 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void pango_layout_line_get_extents(long line, PangoRectangle ink_rect, PangoRectangle logical_rect)
/*      */   {
/* 4021 */     lock.lock();
/*      */     try {
/* 4023 */       _pango_layout_line_get_extents(line, ink_rect, logical_rect);
/*      */     } finally {
/* 4025 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final long pango_layout_new(long context)
/*      */   {
/* 4031 */     lock.lock();
/*      */     try {
/* 4033 */       return _pango_layout_new(context);
/*      */     } finally {
/* 4035 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void pango_layout_set_attributes(long layout, long attrs)
/*      */   {
/* 4054 */     lock.lock();
/*      */     try {
/* 4056 */       _pango_layout_set_attributes(layout, attrs);
/*      */     } finally {
/* 4058 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void pango_layout_set_font_description(long context, long descr)
/*      */   {
/* 4079 */     lock.lock();
/*      */     try {
/* 4081 */       _pango_layout_set_font_description(context, descr);
/*      */     } finally {
/* 4083 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void pango_layout_set_tabs(long layout, long tabs)
/*      */   {
/* 4135 */     lock.lock();
/*      */     try {
/* 4137 */       _pango_layout_set_tabs(layout, tabs);
/*      */     } finally {
/* 4139 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void pango_layout_set_text(long layout, byte[] text, int length)
/*      */   {
/* 4149 */     lock.lock();
/*      */     try {
/* 4151 */       _pango_layout_set_text(layout, text, length);
/*      */     } finally {
/* 4153 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final boolean pango_layout_xy_to_index(long layout, int x, int y, int[] index, int[] trailing)
/*      */   {
/* 4183 */     lock.lock();
/*      */     try {
/* 4185 */       return _pango_layout_xy_to_index(layout, x, y, index, trailing);
/*      */     } finally {
/* 4187 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long pango_tab_array_new(int initial_size, boolean positions_in_pixels)
/*      */   {
/* 4206 */     lock.lock();
/*      */     try {
/* 4208 */       return _pango_tab_array_new(initial_size, positions_in_pixels);
/*      */     } finally {
/* 4210 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void pango_tab_array_set_tab(long tab_array, int tab_index, long alignment, int location)
/*      */   {
/* 4221 */     lock.lock();
/*      */     try {
/* 4223 */       _pango_tab_array_set_tab(tab_array, tab_index, alignment, location);
/*      */     } finally {
/* 4225 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final long ubuntu_menu_proxy_get()
/*      */   {
/* 4233 */     lock.lock();
/*      */     try {
/* 4235 */       return _ubuntu_menu_proxy_get();
/*      */     } finally {
/* 4237 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final int access(byte[] path, int amode)
/*      */   {
/* 4245 */     lock.lock();
/*      */     try {
/* 4247 */       return _access(path, amode);
/*      */     } finally {
/* 4249 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final String getThemeName()
/*      */   {
/* 4269 */     byte[] themeNameBytes = getThemeNameBytes();
/* 4270 */     String themeName = "unknown";
/* 4271 */     if ((themeNameBytes != null) && (themeNameBytes.length > 0)) {
/* 4272 */       themeName = new String(Converter.mbcsToWcs(themeNameBytes));
/*      */     }
/* 4274 */     return themeName;
/*      */   }
/*      */   
/*      */   public static final byte[] getThemeNameBytes() {
/* 4278 */     byte[] buffer = null;
/*      */     
/* 4280 */     long settings = GTK.gtk_settings_get_default();
/* 4281 */     long[] ptr = new long[1];
/* 4282 */     g_object_get(settings, GTK.gtk_theme_name, ptr, 0L);
/* 4283 */     if (ptr[0] == 0L) {
/* 4284 */       return buffer;
/*      */     }
/* 4286 */     int length = C.strlen(ptr[0]);
/* 4287 */     if (length == 0) {
/* 4288 */       return buffer;
/*      */     }
/* 4290 */     buffer = new byte[length];
/* 4291 */     C.memmove(buffer, ptr[0], length);
/* 4292 */     g_free(ptr[0]);
/* 4293 */     return buffer;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void setDarkThemePreferred(boolean preferred)
/*      */   {
/* 4305 */     if (!GTK.GTK3) return;
/* 4306 */     GDK.gdk_flush();
/* 4307 */     g_object_set(GTK.gtk_settings_get_default(), GTK.gtk_application_prefer_dark_theme, preferred, 0L);
/*      */     
/* 4309 */     g_object_notify(GTK.gtk_settings_get_default(), GTK.gtk_application_prefer_dark_theme);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long g_dbus_node_info_new_for_xml(byte[] xml_data, long[] error)
/*      */   {
/* 4322 */     lock.lock();
/*      */     try {
/* 4324 */       return _g_dbus_node_info_new_for_xml(xml_data, error);
/*      */     } finally {
/* 4326 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int g_bus_own_name(int bus_type, byte[] name, int flags, long bus_acquired_handler, long name_acquired_handler, long name_lost_handler, long user_data, long user_data_free_func)
/*      */   {
/* 4344 */     lock.lock();
/*      */     try {
/* 4346 */       return _g_bus_own_name(bus_type, name, flags, bus_acquired_handler, name_acquired_handler, name_lost_handler, user_data, user_data_free_func);
/*      */     } finally {
/* 4348 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int g_dbus_connection_register_object(long connection, byte[] object_path, long interface_info, long[] vtable, long user_data, long user_data_free_func, long[] error)
/*      */   {
/* 4365 */     lock.lock();
/*      */     try {
/* 4367 */       return _g_dbus_connection_register_object(connection, object_path, interface_info, vtable, user_data, user_data_free_func, error);
/*      */     } finally {
/* 4369 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long g_dbus_node_info_lookup_interface(long info, byte[] name)
/*      */   {
/* 4381 */     lock.lock();
/*      */     try {
/* 4383 */       return _g_dbus_node_info_lookup_interface(info, name);
/*      */     } finally {
/* 4385 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void g_dbus_method_invocation_return_value(long invocation, long parameters)
/*      */   {
/* 4397 */     lock.lock();
/*      */     try {
/* 4399 */       _g_dbus_method_invocation_return_value(invocation, parameters);
/*      */     } finally {
/* 4401 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long g_variant_new_int32(int intval)
/*      */   {
/* 4412 */     lock.lock();
/*      */     try {
/* 4414 */       return _g_variant_new_int32(intval);
/*      */     } finally {
/* 4416 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int g_variant_get_int32(long gvariant)
/*      */   {
/* 4429 */     lock.lock();
/*      */     try {
/* 4431 */       return _g_variant_get_int32(gvariant);
/*      */     } finally {
/* 4433 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final byte g_variant_get_byte(long gvariant)
/*      */   {
/* 4445 */     lock.lock();
/*      */     try {
/* 4447 */       return _g_variant_get_byte(gvariant);
/*      */     } finally {
/* 4449 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final boolean g_variant_get_boolean(long gvariant)
/*      */   {
/* 4460 */     lock.lock();
/*      */     try {
/* 4462 */       return _g_variant_get_boolean(gvariant);
/*      */     } finally {
/* 4464 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long g_variant_get_child_value(long gvariant, int index)
/*      */   {
/* 4476 */     lock.lock();
/*      */     try {
/* 4478 */       return _g_variant_get_child_value(gvariant, index);
/*      */     } finally {
/* 4480 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final double g_variant_get_double(long gvariant)
/*      */   {
/* 4491 */     lock.lock();
/*      */     try {
/* 4493 */       return _g_variant_get_double(gvariant);
/*      */     } finally {
/* 4495 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long g_variant_get_string(long gvariant, long[] length)
/*      */   {
/* 4507 */     lock.lock();
/*      */     try {
/* 4509 */       return _g_variant_get_string(gvariant, length);
/*      */     } finally {
/* 4511 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long g_variant_get_type(long gvariant)
/*      */   {
/* 4523 */     lock.lock();
/*      */     try {
/* 4525 */       return _g_variant_get_type(gvariant);
/*      */     } finally {
/* 4527 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long g_variant_get_type_string(long gvariant)
/*      */   {
/* 4538 */     lock.lock();
/*      */     try {
/* 4540 */       return _g_variant_get_type_string(gvariant);
/*      */     } finally {
/* 4542 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final boolean g_variant_is_of_type(long gvariant, byte[] type)
/*      */   {
/* 4554 */     lock.lock();
/*      */     try {
/* 4556 */       return _g_variant_is_of_type(gvariant, type);
/*      */     } finally {
/* 4558 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long g_variant_n_children(long gvariant)
/*      */   {
/* 4569 */     lock.lock();
/*      */     try {
/* 4571 */       return _g_variant_n_children(gvariant);
/*      */     } finally {
/* 4573 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long g_variant_new_boolean(boolean value)
/*      */   {
/* 4584 */     lock.lock();
/*      */     try {
/* 4586 */       return _g_variant_new_boolean(value);
/*      */     } finally {
/* 4588 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long g_variant_new_double(double value)
/*      */   {
/* 4599 */     lock.lock();
/*      */     try {
/* 4601 */       return _g_variant_new_double(value);
/*      */     } finally {
/* 4603 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long g_variant_new_byte(byte value)
/*      */   {
/* 4614 */     lock.lock();
/*      */     try {
/* 4616 */       return _g_variant_new_byte(value);
/*      */     } finally {
/* 4618 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long g_variant_new_tuple(long[] items, long length)
/*      */   {
/* 4630 */     lock.lock();
/*      */     try {
/* 4632 */       return _g_variant_new_tuple(items, length);
/*      */     } finally {
/* 4634 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long g_variant_new_string(byte[] string)
/*      */   {
/* 4645 */     lock.lock();
/*      */     try {
/* 4647 */       return _g_variant_new_string(string);
/*      */     } finally {
/* 4649 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long g_object_ref_sink(long object)
/*      */   {
/* 4659 */     lock.lock();
/*      */     try {
/* 4661 */       return _g_object_ref_sink(object);
/*      */     } finally {
/* 4663 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native boolean GDK_WINDOWING_X11();
/*      */   
/*      */   public static final native boolean GDK_WINDOWING_WAYLAND();
/*      */   
/*      */   public static final native boolean _gdk_keymap_translate_keyboard_state(long paramLong, int paramInt1, int paramInt2, int paramInt3, long[] paramArrayOfLong, int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3);
/*      */   
/*      */   public static final native void _call_get_size(long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5, long paramLong6, long paramLong7, long paramLong8);
/*      */   
/*      */   public static final native long pangoLayoutNewProc_CALLBACK(long paramLong);
/*      */   
/*      */   public static final native long pangoFontFamilyNewProc_CALLBACK(long paramLong);
/*      */   
/*      */   public static final native long pangoFontFaceNewProc_CALLBACK(long paramLong);
/*      */   
/*      */   public static final native long printerOptionWidgetNewProc_CALLBACK(long paramLong);
/*      */   
/*      */   public static final native long imContextNewProc_CALLBACK(long paramLong);
/*      */   
/*      */   public static final native long imContextLast();
/*      */   
/*      */   public static final native void _cachejvmptr();
/*      */   
/*      */   /* Error */
/*      */   public static final void cachejvmptr()
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 9	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: invokestatic 13	org/eclipse/swt/internal/gtk/OS:_cachejvmptr	()V
/*      */     //   10: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   13: invokevirtual 11	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   16: goto +12 -> 28
/*      */     //   19: astore_0
/*      */     //   20: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   23: invokevirtual 11	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   26: aload_0
/*      */     //   27: athrow
/*      */     //   28: return
/*      */     // Line number table:
/*      */     //   Java source line #479	-> byte code offset #0
/*      */     //   Java source line #481	-> byte code offset #7
/*      */     //   Java source line #483	-> byte code offset #10
/*      */     //   Java source line #484	-> byte code offset #16
/*      */     //   Java source line #483	-> byte code offset #19
/*      */     //   Java source line #484	-> byte code offset #26
/*      */     //   Java source line #485	-> byte code offset #28
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   19	8	0	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	10	19	finally
/*      */   }
/*      */   
/*      */   public static final native void _swt_debug_on_fatal_warnings();
/*      */   
/*      */   /* Error */
/*      */   public static final void swt_debug_on_fatal_warnings()
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 9	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: invokestatic 14	org/eclipse/swt/internal/gtk/OS:_swt_debug_on_fatal_warnings	()V
/*      */     //   10: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   13: invokevirtual 11	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   16: goto +12 -> 28
/*      */     //   19: astore_0
/*      */     //   20: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   23: invokevirtual 11	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   26: aload_0
/*      */     //   27: athrow
/*      */     //   28: return
/*      */     // Line number table:
/*      */     //   Java source line #492	-> byte code offset #0
/*      */     //   Java source line #494	-> byte code offset #7
/*      */     //   Java source line #496	-> byte code offset #10
/*      */     //   Java source line #497	-> byte code offset #16
/*      */     //   Java source line #496	-> byte code offset #19
/*      */     //   Java source line #497	-> byte code offset #26
/*      */     //   Java source line #498	-> byte code offset #28
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   19	8	0	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	10	19	finally
/*      */   }
/*      */   
/*      */   public static final native long _swt_fixed_get_type();
/*      */   
/*      */   public static final native long _swt_fixed_accessible_get_type();
/*      */   
/*      */   public static final native void _swt_fixed_accessible_register_accessible(long paramLong1, boolean paramBoolean, long paramLong2);
/*      */   
/*      */   public static final native void _swt_fixed_restack(long paramLong1, long paramLong2, long paramLong3, boolean paramBoolean);
/*      */   
/*      */   public static final native void _swt_fixed_move(long paramLong1, long paramLong2, int paramInt1, int paramInt2);
/*      */   
/*      */   public static final native void _swt_fixed_resize(long paramLong1, long paramLong2, int paramInt1, int paramInt2);
/*      */   
/*      */   public static final native long _g_utf16_offset_to_pointer(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final native long _g_utf16_pointer_to_offset(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final native long _g_utf16_strlen(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final native long _g_utf8_offset_to_utf16_offset(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final native long _g_utf16_offset_to_utf8_offset(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final native int GInterfaceInfo_sizeof();
/*      */   
/*      */   public static final native int GPollFD_sizeof();
/*      */   
/*      */   public static final native int GTypeInfo_sizeof();
/*      */   
/*      */   public static final native int GTypeQuery_sizeof();
/*      */   
/*      */   public static final native int PangoAttribute_sizeof();
/*      */   
/*      */   public static final native int PangoAttrColor_sizeof();
/*      */   
/*      */   public static final native int PangoAttrInt_sizeof();
/*      */   
/*      */   public static final native int PangoItem_sizeof();
/*      */   
/*      */   public static final native int PangoLayoutLine_sizeof();
/*      */   
/*      */   public static final native int PangoLayoutRun_sizeof();
/*      */   
/*      */   public static final native int PangoLogAttr_sizeof();
/*      */   
/*      */   public static final native int PangoRectangle_sizeof();
/*      */   
/*      */   public static final native int XAnyEvent_sizeof();
/*      */   
/*      */   public static final native int XEvent_sizeof();
/*      */   
/*      */   public static final native int XExposeEvent_sizeof();
/*      */   
/*      */   public static final native int XFocusChangeEvent_sizeof();
/*      */   
/*      */   public static final native long localeconv_decimal_point();
/*      */   
/*      */   public static final native long realpath(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2);
/*      */   
/*      */   public static final native long G_OBJECT_CLASS_CONSTRUCTOR(long paramLong);
/*      */   
/*      */   public static final native void G_OBJECT_CLASS_SET_CONSTRUCTOR(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final native int X_EVENT_TYPE(long paramLong);
/*      */   
/*      */   public static final native long X_EVENT_WINDOW(long paramLong);
/*      */   
/*      */   public static final native int _Call(long paramLong1, long paramLong2, long paramLong3);
/*      */   
/*      */   public static final native long _call(long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5, long paramLong6, long paramLong7, long paramLong8);
/*      */   
/*      */   public static final native long _call(long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5);
/*      */   
/*      */   public static final native long _call(long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5, long paramLong6, long paramLong7);
/*      */   
/*      */   public static final native boolean _XCheckIfEvent(long paramLong1, long paramLong2, long paramLong3, long paramLong4);
/*      */   
/*      */   public static final native int _XDefaultScreen(long paramLong);
/*      */   
/*      */   public static final native long _XDefaultRootWindow(long paramLong);
/*      */   
/*      */   public static final native void _XFree(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void XFree(long address)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 9	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 38	org/eclipse/swt/internal/gtk/OS:_XFree	(J)V
/*      */     //   11: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 11	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 11	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #955	-> byte code offset #0
/*      */     //   Java source line #957	-> byte code offset #7
/*      */     //   Java source line #959	-> byte code offset #11
/*      */     //   Java source line #960	-> byte code offset #17
/*      */     //   Java source line #959	-> byte code offset #20
/*      */     //   Java source line #960	-> byte code offset #27
/*      */     //   Java source line #961	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	address	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native int _XQueryPointer(long paramLong1, long paramLong2, long[] paramArrayOfLong1, long[] paramArrayOfLong2, int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3, int[] paramArrayOfInt4, int[] paramArrayOfInt5);
/*      */   
/*      */   public static final native int _XKeysymToKeycode(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final native long _XSetIOErrorHandler(long paramLong);
/*      */   
/*      */   public static final native long _XSetErrorHandler(long paramLong);
/*      */   
/*      */   public static final native int _XSetInputFocus(long paramLong1, long paramLong2, int paramInt1, int paramInt2);
/*      */   
/*      */   public static final native int _XSetTransientForHint(long paramLong1, long paramLong2, long paramLong3);
/*      */   
/*      */   public static final native long _XSynchronize(long paramLong, boolean paramBoolean);
/*      */   
/*      */   public static final native void _XTestFakeKeyEvent(long paramLong1, int paramInt, boolean paramBoolean, long paramLong2);
/*      */   
/*      */   public static final native void memmove(long paramLong1, XExposeEvent paramXExposeEvent, long paramLong2);
/*      */   
/*      */   public static final native void memmove(XExposeEvent paramXExposeEvent, long paramLong1, long paramLong2);
/*      */   
/*      */   public static final native void memmove(XFocusChangeEvent paramXFocusChangeEvent, long paramLong1, long paramLong2);
/*      */   
/*      */   public static final native int RTLD_GLOBAL();
/*      */   
/*      */   public static final native int RTLD_NOW();
/*      */   
/*      */   public static final native int RTLD_LAZY();
/*      */   
/*      */   public static final native int Call(long paramLong1, long paramLong2, int paramInt1, int paramInt2);
/*      */   
/*      */   public static final native long Call(long paramLong1, long paramLong2, int paramInt, long paramLong3);
/*      */   
/*      */   public static final native long _G_OBJECT_CLASS(long paramLong);
/*      */   
/*      */   public static final native long _G_OBJECT_GET_CLASS(long paramLong);
/*      */   
/*      */   public static final native long _G_OBJECT_TYPE_NAME(long paramLong);
/*      */   
/*      */   public static final native boolean _G_TYPE_CHECK_INSTANCE_TYPE(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final native long G_TYPE_BOOLEAN();
/*      */   
/*      */   public static final native long G_TYPE_DOUBLE();
/*      */   
/*      */   public static final native long G_TYPE_FLOAT();
/*      */   
/*      */   public static final native long G_TYPE_INT();
/*      */   
/*      */   public static final native long G_TYPE_INT64();
/*      */   
/*      */   public static final native long G_VALUE_TYPE(long paramLong);
/*      */   
/*      */   public static final native long _G_OBJECT_TYPE(long paramLong);
/*      */   
/*      */   public static final native long _G_TYPE_STRING();
/*      */   
/*      */   public static final native int _PANGO_PIXELS(int paramInt);
/*      */   
/*      */   public static final native long _PANGO_TYPE_FONT_DESCRIPTION();
/*      */   
/*      */   public static final native long _PANGO_TYPE_FONT_FAMILY();
/*      */   
/*      */   public static final native long _PANGO_TYPE_FONT_FACE();
/*      */   
/*      */   public static final native long _PANGO_TYPE_LAYOUT();
/*      */   
/*      */   public static final native long _dlopen(byte[] paramArrayOfByte, int paramInt);
/*      */   
/*      */   public static final native long _g_app_info_create_from_commandline(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, long paramLong1, long paramLong2);
/*      */   
/*      */   public static final native long _g_app_info_get_all();
/*      */   
/*      */   public static final native long _g_app_info_get_executable(long paramLong);
/*      */   
/*      */   public static final native long _g_app_info_get_icon(long paramLong);
/*      */   
/*      */   public static final native long _g_app_info_get_name(long paramLong);
/*      */   
/*      */   public static final native boolean _g_app_info_launch(long paramLong1, long paramLong2, long paramLong3, long paramLong4);
/*      */   
/*      */   public static final native long _g_app_info_get_default_for_type(byte[] paramArrayOfByte, boolean paramBoolean);
/*      */   
/*      */   public static final native boolean _g_app_info_launch_default_for_uri(long paramLong1, long paramLong2, long paramLong3);
/*      */   
/*      */   public static final native boolean _g_app_info_should_show(long paramLong);
/*      */   
/*      */   public static final native boolean _g_app_info_supports_uris(long paramLong);
/*      */   
/*      */   public static final native long _g_error_get_message(long paramLong);
/*      */   
/*      */   public static final native void _g_error_free(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void g_error_free(long gerror)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 9	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 70	org/eclipse/swt/internal/gtk/OS:_g_error_free	(J)V
/*      */     //   11: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 11	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 11	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #1374	-> byte code offset #0
/*      */     //   Java source line #1376	-> byte code offset #7
/*      */     //   Java source line #1378	-> byte code offset #11
/*      */     //   Java source line #1379	-> byte code offset #17
/*      */     //   Java source line #1378	-> byte code offset #20
/*      */     //   Java source line #1379	-> byte code offset #27
/*      */     //   Java source line #1380	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	gerror	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native boolean _g_content_type_equals(long paramLong, byte[] paramArrayOfByte);
/*      */   
/*      */   public static final native boolean _g_content_type_is_a(long paramLong, byte[] paramArrayOfByte);
/*      */   
/*      */   public static final native long _g_file_info_get_content_type(long paramLong);
/*      */   
/*      */   public static final native long _g_file_get_uri(long paramLong);
/*      */   
/*      */   public static final native long _g_file_new_for_path(byte[] paramArrayOfByte);
/*      */   
/*      */   public static final native long _g_file_new_for_commandline_arg(byte[] paramArrayOfByte);
/*      */   
/*      */   public static final native long _g_file_new_for_uri(byte[] paramArrayOfByte);
/*      */   
/*      */   public static final native long _g_file_query_info(long paramLong1, byte[] paramArrayOfByte, long paramLong2, long paramLong3, long paramLong4);
/*      */   
/*      */   public static final native boolean _g_file_test(byte[] paramArrayOfByte, int paramInt);
/*      */   
/*      */   public static final native long _g_icon_to_string(long paramLong);
/*      */   
/*      */   public static final native long _g_icon_new_for_string(byte[] paramArrayOfByte, long[] paramArrayOfLong);
/*      */   
/*      */   public static final native long _g_signal_add_emission_hook(int paramInt1, int paramInt2, long paramLong1, long paramLong2, long paramLong3);
/*      */   
/*      */   public static final native void _g_signal_remove_emission_hook(int paramInt, long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void g_signal_remove_emission_hook(int signal_id, long hook_id)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 9	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: iload_0
/*      */     //   8: lload_1
/*      */     //   9: invokestatic 83	org/eclipse/swt/internal/gtk/OS:_g_signal_remove_emission_hook	(IJ)V
/*      */     //   12: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 11	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 11	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #1538	-> byte code offset #0
/*      */     //   Java source line #1540	-> byte code offset #7
/*      */     //   Java source line #1542	-> byte code offset #12
/*      */     //   Java source line #1543	-> byte code offset #18
/*      */     //   Java source line #1542	-> byte code offset #21
/*      */     //   Java source line #1543	-> byte code offset #28
/*      */     //   Java source line #1544	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	signal_id	int
/*      */     //   0	31	1	hook_id	long
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native long _g_cclosure_new(long paramLong1, long paramLong2, long paramLong3);
/*      */   
/*      */   public static final native long _g_closure_ref(long paramLong);
/*      */   
/*      */   public static final native void _g_closure_sink(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void g_closure_sink(long closure)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 9	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 86	org/eclipse/swt/internal/gtk/OS:_g_closure_sink	(J)V
/*      */     //   11: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 11	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 11	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #1572	-> byte code offset #0
/*      */     //   Java source line #1574	-> byte code offset #7
/*      */     //   Java source line #1576	-> byte code offset #11
/*      */     //   Java source line #1577	-> byte code offset #17
/*      */     //   Java source line #1576	-> byte code offset #20
/*      */     //   Java source line #1577	-> byte code offset #27
/*      */     //   Java source line #1578	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	closure	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native void _g_closure_unref(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void g_closure_unref(long closure)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 9	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 87	org/eclipse/swt/internal/gtk/OS:_g_closure_unref	(J)V
/*      */     //   11: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 11	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 11	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #1582	-> byte code offset #0
/*      */     //   Java source line #1584	-> byte code offset #7
/*      */     //   Java source line #1586	-> byte code offset #11
/*      */     //   Java source line #1587	-> byte code offset #17
/*      */     //   Java source line #1586	-> byte code offset #20
/*      */     //   Java source line #1587	-> byte code offset #27
/*      */     //   Java source line #1588	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	closure	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native boolean _g_main_context_acquire(long paramLong);
/*      */   
/*      */   public static final native int _g_main_context_check(long paramLong1, int paramInt1, long paramLong2, int paramInt2);
/*      */   
/*      */   public static final native long _g_main_context_default();
/*      */   
/*      */   public static final native boolean _g_main_context_iteration(long paramLong, boolean paramBoolean);
/*      */   
/*      */   public static final native long _g_main_context_get_poll_func(long paramLong);
/*      */   
/*      */   public static final native boolean _g_main_context_prepare(long paramLong, int[] paramArrayOfInt);
/*      */   
/*      */   public static final native int _g_main_context_query(long paramLong1, int paramInt1, int[] paramArrayOfInt, long paramLong2, int paramInt2);
/*      */   
/*      */   public static final native void _g_main_context_release(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void g_main_context_release(long context)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 9	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 95	org/eclipse/swt/internal/gtk/OS:_g_main_context_release	(J)V
/*      */     //   11: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 11	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 11	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #1671	-> byte code offset #0
/*      */     //   Java source line #1673	-> byte code offset #7
/*      */     //   Java source line #1675	-> byte code offset #11
/*      */     //   Java source line #1676	-> byte code offset #17
/*      */     //   Java source line #1675	-> byte code offset #20
/*      */     //   Java source line #1676	-> byte code offset #27
/*      */     //   Java source line #1677	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	context	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native void g_main_context_wakeup(long paramLong);
/*      */   
/*      */   public static final native long _g_filename_to_utf8(long paramLong1, long paramLong2, long[] paramArrayOfLong1, long[] paramArrayOfLong2, long[] paramArrayOfLong3);
/*      */   
/*      */   public static final native long _g_filename_display_name(long paramLong);
/*      */   
/*      */   public static final native long _g_filename_to_uri(long paramLong1, long paramLong2, long[] paramArrayOfLong);
/*      */   
/*      */   public static final native long _g_filename_from_utf8(long paramLong1, long paramLong2, long[] paramArrayOfLong1, long[] paramArrayOfLong2, long[] paramArrayOfLong3);
/*      */   
/*      */   public static final native long _g_filename_from_uri(long paramLong, long[] paramArrayOfLong1, long[] paramArrayOfLong2);
/*      */   
/*      */   public static final native void _g_free(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void g_free(long mem)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 9	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 101	org/eclipse/swt/internal/gtk/OS:_g_free	(J)V
/*      */     //   11: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 11	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 11	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #1753	-> byte code offset #0
/*      */     //   Java source line #1755	-> byte code offset #7
/*      */     //   Java source line #1757	-> byte code offset #11
/*      */     //   Java source line #1758	-> byte code offset #17
/*      */     //   Java source line #1757	-> byte code offset #20
/*      */     //   Java source line #1758	-> byte code offset #27
/*      */     //   Java source line #1759	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	mem	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native long _g_hash_table_get_values(long paramLong);
/*      */   
/*      */   public static final native int _g_idle_add(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final native long _g_list_append(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final native long _g_list_data(long paramLong);
/*      */   
/*      */   public static final native void _g_list_free(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void g_list_free(long list)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 9	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 106	org/eclipse/swt/internal/gtk/OS:_g_list_free	(J)V
/*      */     //   11: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 11	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 11	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #1811	-> byte code offset #0
/*      */     //   Java source line #1813	-> byte code offset #7
/*      */     //   Java source line #1815	-> byte code offset #11
/*      */     //   Java source line #1816	-> byte code offset #17
/*      */     //   Java source line #1815	-> byte code offset #20
/*      */     //   Java source line #1816	-> byte code offset #27
/*      */     //   Java source line #1817	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	list	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native void _g_list_free_1(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void g_list_free_1(long list)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 9	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 107	org/eclipse/swt/internal/gtk/OS:_g_list_free_1	(J)V
/*      */     //   11: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 11	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 11	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #1821	-> byte code offset #0
/*      */     //   Java source line #1823	-> byte code offset #7
/*      */     //   Java source line #1825	-> byte code offset #11
/*      */     //   Java source line #1826	-> byte code offset #17
/*      */     //   Java source line #1825	-> byte code offset #20
/*      */     //   Java source line #1826	-> byte code offset #27
/*      */     //   Java source line #1827	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	list	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native long _g_list_last(long paramLong);
/*      */   
/*      */   public static final native int _g_list_length(long paramLong);
/*      */   
/*      */   public static final native void _g_list_set_next(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final native long _g_list_next(long paramLong);
/*      */   
/*      */   public static final native long _g_list_nth(long paramLong, int paramInt);
/*      */   
/*      */   public static final native long _g_list_nth_data(long paramLong, int paramInt);
/*      */   
/*      */   public static final native long _g_list_prepend(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final native void _g_list_set_previous(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final native long _g_list_previous(long paramLong);
/*      */   
/*      */   public static final native long _g_list_remove_link(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final native void _g_log_default_handler(long paramLong1, int paramInt, long paramLong2, long paramLong3);
/*      */   
/*      */   public static final native void _g_log_remove_handler(byte[] paramArrayOfByte, int paramInt);
/*      */   
/*      */   /* Error */
/*      */   public static final void g_log_remove_handler(byte[] log_domain, int handler_id)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 9	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: aload_0
/*      */     //   8: iload_1
/*      */     //   9: invokestatic 119	org/eclipse/swt/internal/gtk/OS:_g_log_remove_handler	([BI)V
/*      */     //   12: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 11	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_2
/*      */     //   22: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 11	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_2
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #1967	-> byte code offset #0
/*      */     //   Java source line #1969	-> byte code offset #7
/*      */     //   Java source line #1971	-> byte code offset #12
/*      */     //   Java source line #1972	-> byte code offset #18
/*      */     //   Java source line #1971	-> byte code offset #21
/*      */     //   Java source line #1972	-> byte code offset #28
/*      */     //   Java source line #1973	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	log_domain	byte[]
/*      */     //   0	31	1	handler_id	int
/*      */     //   21	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native int _g_log_set_handler(byte[] paramArrayOfByte, int paramInt, long paramLong1, long paramLong2);
/*      */   
/*      */   public static final native long _g_malloc(long paramLong);
/*      */   
/*      */   public static final native long _g_object_class_find_property(long paramLong, byte[] paramArrayOfByte);
/*      */   
/*      */   public static final native void _g_object_get(long paramLong1, byte[] paramArrayOfByte, int[] paramArrayOfInt, long paramLong2);
/*      */   
/*      */   public static final native void _g_object_get(long paramLong1, byte[] paramArrayOfByte, long[] paramArrayOfLong, long paramLong2);
/*      */   
/*      */   public static final native long _g_object_get_qdata(long paramLong, int paramInt);
/*      */   
/*      */   public static final native long _g_object_new(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final native void _g_object_notify(long paramLong, byte[] paramArrayOfByte);
/*      */   
/*      */   /* Error */
/*      */   public static final void g_object_notify(long object, byte[] property_name)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 9	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: aload_2
/*      */     //   9: invokestatic 127	org/eclipse/swt/internal/gtk/OS:_g_object_notify	(J[B)V
/*      */     //   12: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 11	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 11	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #2072	-> byte code offset #0
/*      */     //   Java source line #2074	-> byte code offset #7
/*      */     //   Java source line #2076	-> byte code offset #12
/*      */     //   Java source line #2077	-> byte code offset #18
/*      */     //   Java source line #2076	-> byte code offset #21
/*      */     //   Java source line #2077	-> byte code offset #28
/*      */     //   Java source line #2078	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	object	long
/*      */     //   0	31	2	property_name	byte[]
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native long _g_object_ref(long paramLong);
/*      */   
/*      */   public static final native void _g_object_set(long paramLong1, byte[] paramArrayOfByte, boolean paramBoolean, long paramLong2);
/*      */   
/*      */   public static final native void _g_object_set(long paramLong1, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, long paramLong2);
/*      */   
/*      */   public static final native void _g_object_set(long paramLong1, byte[] paramArrayOfByte, GdkColor paramGdkColor, long paramLong2);
/*      */   
/*      */   public static final native void _g_object_set(long paramLong1, byte[] paramArrayOfByte, GdkRGBA paramGdkRGBA, long paramLong2);
/*      */   
/*      */   public static final native void _g_object_set(long paramLong1, byte[] paramArrayOfByte, int paramInt, long paramLong2);
/*      */   
/*      */   public static final native void _g_object_set(long paramLong1, byte[] paramArrayOfByte, float paramFloat, long paramLong2);
/*      */   
/*      */   public static final native void _g_object_set(long paramLong1, byte[] paramArrayOfByte, long paramLong2, long paramLong3);
/*      */   
/*      */   public static final native void _g_object_set_qdata(long paramLong1, int paramInt, long paramLong2);
/*      */   
/*      */   public static final native void _g_object_unref(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void g_object_unref(long object)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 9	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 137	org/eclipse/swt/internal/gtk/OS:_g_object_unref	(J)V
/*      */     //   11: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 11	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 11	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #2208	-> byte code offset #0
/*      */     //   Java source line #2210	-> byte code offset #7
/*      */     //   Java source line #2212	-> byte code offset #11
/*      */     //   Java source line #2213	-> byte code offset #17
/*      */     //   Java source line #2212	-> byte code offset #20
/*      */     //   Java source line #2213	-> byte code offset #27
/*      */     //   Java source line #2214	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	object	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native long _g_bytes_new(byte[] paramArrayOfByte, long paramLong);
/*      */   
/*      */   public static final native void _g_bytes_unref(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void g_bytes_unref(long gBytes)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 138	org/eclipse/swt/internal/gtk/OS:$assertionsDisabled	Z
/*      */     //   3: ifne +17 -> 20
/*      */     //   6: getstatic 139	org/eclipse/swt/internal/gtk/OS:MIN_GLIB_2_32	Z
/*      */     //   9: ifne +11 -> 20
/*      */     //   12: new 140	java/lang/AssertionError
/*      */     //   15: dup
/*      */     //   16: invokespecial 141	java/lang/AssertionError:<init>	()V
/*      */     //   19: athrow
/*      */     //   20: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   23: invokevirtual 9	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   26: pop
/*      */     //   27: lload_0
/*      */     //   28: invokestatic 143	org/eclipse/swt/internal/gtk/OS:_g_bytes_unref	(J)V
/*      */     //   31: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   34: invokevirtual 11	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   37: goto +12 -> 49
/*      */     //   40: astore_2
/*      */     //   41: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   44: invokevirtual 11	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   47: aload_2
/*      */     //   48: athrow
/*      */     //   49: return
/*      */     // Line number table:
/*      */     //   Java source line #2239	-> byte code offset #0
/*      */     //   Java source line #2240	-> byte code offset #20
/*      */     //   Java source line #2242	-> byte code offset #27
/*      */     //   Java source line #2244	-> byte code offset #31
/*      */     //   Java source line #2245	-> byte code offset #37
/*      */     //   Java source line #2244	-> byte code offset #40
/*      */     //   Java source line #2245	-> byte code offset #47
/*      */     //   Java source line #2246	-> byte code offset #49
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	50	0	gBytes	long
/*      */     //   40	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   27	31	40	finally
/*      */   }
/*      */   
/*      */   public static final native int _g_quark_from_string(byte[] paramArrayOfByte);
/*      */   
/*      */   public static final native void _g_set_prgname(byte[] paramArrayOfByte);
/*      */   
/*      */   /* Error */
/*      */   public static final void g_set_prgname(byte[] prgname)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 9	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: aload_0
/*      */     //   8: invokestatic 145	org/eclipse/swt/internal/gtk/OS:_g_set_prgname	([B)V
/*      */     //   11: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 11	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_1
/*      */     //   21: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 11	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_1
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #2261	-> byte code offset #0
/*      */     //   Java source line #2263	-> byte code offset #7
/*      */     //   Java source line #2265	-> byte code offset #11
/*      */     //   Java source line #2266	-> byte code offset #17
/*      */     //   Java source line #2265	-> byte code offset #20
/*      */     //   Java source line #2266	-> byte code offset #27
/*      */     //   Java source line #2267	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	prgname	byte[]
/*      */     //   20	8	1	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native int _g_signal_connect(long paramLong1, byte[] paramArrayOfByte, long paramLong2, long paramLong3);
/*      */   
/*      */   public static final native int _g_signal_connect_closure(long paramLong1, byte[] paramArrayOfByte, long paramLong2, boolean paramBoolean);
/*      */   
/*      */   public static final native int _g_signal_connect_closure_by_id(long paramLong1, int paramInt1, int paramInt2, long paramLong2, boolean paramBoolean);
/*      */   
/*      */   public static final native void _g_signal_emit_by_name(long paramLong, byte[] paramArrayOfByte);
/*      */   
/*      */   /* Error */
/*      */   public static final void g_signal_emit_by_name(long instance, byte[] detailed_signal)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 9	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: aload_2
/*      */     //   9: invokestatic 149	org/eclipse/swt/internal/gtk/OS:_g_signal_emit_by_name	(J[B)V
/*      */     //   12: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 11	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 11	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #2320	-> byte code offset #0
/*      */     //   Java source line #2322	-> byte code offset #7
/*      */     //   Java source line #2324	-> byte code offset #12
/*      */     //   Java source line #2325	-> byte code offset #18
/*      */     //   Java source line #2324	-> byte code offset #21
/*      */     //   Java source line #2325	-> byte code offset #28
/*      */     //   Java source line #2326	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	instance	long
/*      */     //   0	31	2	detailed_signal	byte[]
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _g_signal_emit_by_name(long paramLong1, byte[] paramArrayOfByte, long paramLong2);
/*      */   
/*      */   public static final native void _g_signal_emit_by_name(long paramLong, byte[] paramArrayOfByte, GdkRectangle paramGdkRectangle);
/*      */   
/*      */   public static final native void _g_signal_emit_by_name(long paramLong1, byte[] paramArrayOfByte, long paramLong2, long paramLong3);
/*      */   
/*      */   public static final native void _g_signal_emit_by_name(long paramLong, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2);
/*      */   
/*      */   public static final native void _g_signal_handler_disconnect(long paramLong, int paramInt);
/*      */   
/*      */   /* Error */
/*      */   public static final void g_signal_handler_disconnect(long instance, int handler_id)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 9	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 154	org/eclipse/swt/internal/gtk/OS:_g_signal_handler_disconnect	(JI)V
/*      */     //   12: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 11	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 11	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #2385	-> byte code offset #0
/*      */     //   Java source line #2387	-> byte code offset #7
/*      */     //   Java source line #2389	-> byte code offset #12
/*      */     //   Java source line #2390	-> byte code offset #18
/*      */     //   Java source line #2389	-> byte code offset #21
/*      */     //   Java source line #2390	-> byte code offset #28
/*      */     //   Java source line #2391	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	instance	long
/*      */     //   0	31	2	handler_id	int
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native int _g_signal_handler_find(long paramLong1, int paramInt1, int paramInt2, int paramInt3, long paramLong2, long paramLong3, long paramLong4);
/*      */   
/*      */   public static final native int _g_signal_handlers_block_matched(long paramLong1, int paramInt1, int paramInt2, int paramInt3, long paramLong2, long paramLong3, long paramLong4);
/*      */   
/*      */   public static final native int _g_signal_handlers_unblock_matched(long paramLong1, int paramInt1, int paramInt2, int paramInt3, long paramLong2, long paramLong3, long paramLong4);
/*      */   
/*      */   public static final native int _g_signal_lookup(byte[] paramArrayOfByte, long paramLong);
/*      */   
/*      */   public static final native void _g_signal_stop_emission_by_name(long paramLong, byte[] paramArrayOfByte);
/*      */   
/*      */   /* Error */
/*      */   public static final void g_signal_stop_emission_by_name(long instance, byte[] detailed_signal)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 9	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: aload_2
/*      */     //   9: invokestatic 159	org/eclipse/swt/internal/gtk/OS:_g_signal_stop_emission_by_name	(J[B)V
/*      */     //   12: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 11	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 11	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #2460	-> byte code offset #0
/*      */     //   Java source line #2462	-> byte code offset #7
/*      */     //   Java source line #2464	-> byte code offset #12
/*      */     //   Java source line #2465	-> byte code offset #18
/*      */     //   Java source line #2464	-> byte code offset #21
/*      */     //   Java source line #2465	-> byte code offset #28
/*      */     //   Java source line #2466	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	instance	long
/*      */     //   0	31	2	detailed_signal	byte[]
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native boolean _g_source_remove(long paramLong);
/*      */   
/*      */   public static final native long _g_slist_append(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final native long _g_slist_data(long paramLong);
/*      */   
/*      */   public static final native void _g_slist_free(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void g_slist_free(long list)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 9	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 163	org/eclipse/swt/internal/gtk/OS:_g_slist_free	(J)V
/*      */     //   11: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 11	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 11	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #2503	-> byte code offset #0
/*      */     //   Java source line #2505	-> byte code offset #7
/*      */     //   Java source line #2507	-> byte code offset #11
/*      */     //   Java source line #2508	-> byte code offset #17
/*      */     //   Java source line #2507	-> byte code offset #20
/*      */     //   Java source line #2508	-> byte code offset #27
/*      */     //   Java source line #2509	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	list	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native long _g_slist_next(long paramLong);
/*      */   
/*      */   public static final native int _g_slist_length(long paramLong);
/*      */   
/*      */   public static final native void _g_strfreev(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void g_strfreev(long string_array)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 9	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 166	org/eclipse/swt/internal/gtk/OS:_g_strfreev	(J)V
/*      */     //   11: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 11	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 11	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #2533	-> byte code offset #0
/*      */     //   Java source line #2535	-> byte code offset #7
/*      */     //   Java source line #2537	-> byte code offset #11
/*      */     //   Java source line #2538	-> byte code offset #17
/*      */     //   Java source line #2537	-> byte code offset #20
/*      */     //   Java source line #2538	-> byte code offset #27
/*      */     //   Java source line #2539	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	string_array	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native int _GString_len(long paramLong);
/*      */   
/*      */   public static final native long _GString_str(long paramLong);
/*      */   
/*      */   public static final native long _g_string_new_len(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final native long _g_string_free(long paramLong, int paramInt);
/*      */   
/*      */   public static final native double _g_strtod(long paramLong, long[] paramArrayOfLong);
/*      */   
/*      */   public static final native long g_strdup(long paramLong);
/*      */   
/*      */   public static final native void _g_type_add_interface_static(long paramLong1, long paramLong2, long paramLong3);
/*      */   
/*      */   public static final native long _g_type_class_peek(long paramLong);
/*      */   
/*      */   public static final native long _g_type_class_peek_parent(long paramLong);
/*      */   
/*      */   public static final native long _g_type_class_ref(long paramLong);
/*      */   
/*      */   public static final native void _g_type_class_unref(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void g_type_class_unref(long g_class)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 9	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 176	org/eclipse/swt/internal/gtk/OS:_g_type_class_unref	(J)V
/*      */     //   11: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 11	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 11	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #2657	-> byte code offset #0
/*      */     //   Java source line #2659	-> byte code offset #7
/*      */     //   Java source line #2661	-> byte code offset #11
/*      */     //   Java source line #2662	-> byte code offset #17
/*      */     //   Java source line #2661	-> byte code offset #20
/*      */     //   Java source line #2662	-> byte code offset #27
/*      */     //   Java source line #2663	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	g_class	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native long _g_type_from_name(byte[] paramArrayOfByte);
/*      */   
/*      */   public static final native long _g_type_interface_peek_parent(long paramLong);
/*      */   
/*      */   public static final native boolean _g_type_is_a(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final native long _g_type_name(long paramLong);
/*      */   
/*      */   public static final native long _g_type_parent(long paramLong);
/*      */   
/*      */   public static final native void _g_type_query(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final native long _g_type_register_static(long paramLong1, byte[] paramArrayOfByte, long paramLong2, int paramInt);
/*      */   
/*      */   public static final native void _g_thread_init(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void g_thread_init(long vtable)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 9	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 184	org/eclipse/swt/internal/gtk/OS:_g_thread_init	(J)V
/*      */     //   11: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 11	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 11	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #2751	-> byte code offset #0
/*      */     //   Java source line #2753	-> byte code offset #7
/*      */     //   Java source line #2755	-> byte code offset #11
/*      */     //   Java source line #2756	-> byte code offset #17
/*      */     //   Java source line #2755	-> byte code offset #20
/*      */     //   Java source line #2756	-> byte code offset #27
/*      */     //   Java source line #2757	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	vtable	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native boolean _g_thread_supported();
/*      */   
/*      */   public static final native long _g_utf16_to_utf8(char[] paramArrayOfChar, long paramLong, long[] paramArrayOfLong1, long[] paramArrayOfLong2, long[] paramArrayOfLong3);
/*      */   
/*      */   public static final native long _g_utf8_pointer_to_offset(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final native long _g_utf8_strlen(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final native long _g_utf8_to_utf16(byte[] paramArrayOfByte, long paramLong, long[] paramArrayOfLong1, long[] paramArrayOfLong2, long[] paramArrayOfLong3);
/*      */   
/*      */   public static final native long _g_utf8_to_utf16(long paramLong1, long paramLong2, long[] paramArrayOfLong1, long[] paramArrayOfLong2, long[] paramArrayOfLong3);
/*      */   
/*      */   public static final native long g_value_init(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final native int g_value_get_int(long paramLong);
/*      */   
/*      */   public static final native void g_value_set_int(long paramLong, int paramInt);
/*      */   
/*      */   public static final native double g_value_get_double(long paramLong);
/*      */   
/*      */   public static final native void g_value_set_double(long paramLong, double paramDouble);
/*      */   
/*      */   public static final native float g_value_get_float(long paramLong);
/*      */   
/*      */   public static final native void g_value_set_float(long paramLong, float paramFloat);
/*      */   
/*      */   public static final native long g_value_get_int64(long paramLong);
/*      */   
/*      */   public static final native void g_value_set_int64(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final native void g_value_unset(long paramLong);
/*      */   
/*      */   public static final native long _g_value_peek_pointer(long paramLong);
/*      */   
/*      */   public static final native int _glib_major_version();
/*      */   
/*      */   public static final native int _glib_minor_version();
/*      */   
/*      */   public static final native int _glib_micro_version();
/*      */   
/*      */   public static final native int _g_timeout_add(int paramInt, long paramLong1, long paramLong2);
/*      */   
/*      */   public static final native boolean _FcConfigAppFontAddFile(long paramLong, byte[] paramArrayOfByte);
/*      */   
/*      */   public static final native int _getpid();
/*      */   
/*      */   public static final native void memmove(long paramLong, GInterfaceInfo paramGInterfaceInfo, int paramInt);
/*      */   
/*      */   public static final native void memmove(long paramLong, GObjectClass paramGObjectClass);
/*      */   
/*      */   public static final native void memmove(long paramLong, GTypeInfo paramGTypeInfo, int paramInt);
/*      */   
/*      */   public static final native void memmove(long paramLong1, GtkTargetEntry paramGtkTargetEntry, long paramLong2);
/*      */   
/*      */   public static final native void memmove(long paramLong1, GdkColor paramGdkColor, long paramLong2);
/*      */   
/*      */   public static final native void memmove(long paramLong1, GdkRGBA paramGdkRGBA, long paramLong2);
/*      */   
/*      */   public static final native void memmove(long paramLong1, GdkEventButton paramGdkEventButton, long paramLong2);
/*      */   
/*      */   public static final native void memmove(long paramLong1, GdkEventKey paramGdkEventKey, long paramLong2);
/*      */   
/*      */   public static final native void memmove(long paramLong1, GdkEventExpose paramGdkEventExpose, long paramLong2);
/*      */   
/*      */   public static final native void memmove(long paramLong1, GdkEventMotion paramGdkEventMotion, long paramLong2);
/*      */   
/*      */   public static final native void memmove(long paramLong, GtkWidgetClass paramGtkWidgetClass);
/*      */   
/*      */   public static final native void memmove(long paramLong1, PangoAttribute paramPangoAttribute, long paramLong2);
/*      */   
/*      */   public static final native void memmove(GObjectClass paramGObjectClass, long paramLong);
/*      */   
/*      */   public static final native void memmove(GTypeQuery paramGTypeQuery, long paramLong1, long paramLong2);
/*      */   
/*      */   public static final native void memmove(GdkDragContext paramGdkDragContext, long paramLong1, long paramLong2);
/*      */   
/*      */   public static final native void memmove(GtkWidgetClass paramGtkWidgetClass, long paramLong);
/*      */   
/*      */   public static final native void memmove(GtkBorder paramGtkBorder, long paramLong1, long paramLong2);
/*      */   
/*      */   public static final native void memmove(GdkColor paramGdkColor, long paramLong1, long paramLong2);
/*      */   
/*      */   public static final native void memmove(GdkKeymapKey paramGdkKeymapKey, long paramLong1, long paramLong2);
/*      */   
/*      */   public static final native void memmove(GdkRGBA paramGdkRGBA, long paramLong1, long paramLong2);
/*      */   
/*      */   public static final native void memmove(GdkEvent paramGdkEvent, long paramLong1, long paramLong2);
/*      */   
/*      */   public static final native void memmove(GdkEventAny paramGdkEventAny, long paramLong1, long paramLong2);
/*      */   
/*      */   public static final native void memmove(GdkEventButton paramGdkEventButton, long paramLong1, long paramLong2);
/*      */   
/*      */   public static final native void memmove(GdkEventCrossing paramGdkEventCrossing, long paramLong1, long paramLong2);
/*      */   
/*      */   public static final native void memmove(GdkEventExpose paramGdkEventExpose, long paramLong1, long paramLong2);
/*      */   
/*      */   public static final native void memmove(GdkEventFocus paramGdkEventFocus, long paramLong1, long paramLong2);
/*      */   
/*      */   public static final native void memmove(GdkEventKey paramGdkEventKey, long paramLong1, long paramLong2);
/*      */   
/*      */   public static final native void memmove(GdkEventMotion paramGdkEventMotion, long paramLong1, long paramLong2);
/*      */   
/*      */   public static final native void memmove(GdkEventScroll paramGdkEventScroll, long paramLong1, long paramLong2);
/*      */   
/*      */   public static final native void memmove(GdkEventWindowState paramGdkEventWindowState, long paramLong1, long paramLong2);
/*      */   
/*      */   public static final native void memmove(long paramLong, GtkCellRendererClass paramGtkCellRendererClass);
/*      */   
/*      */   public static final native void memmove(GtkCellRendererClass paramGtkCellRendererClass, long paramLong);
/*      */   
/*      */   public static final native void memmove(GtkFixed paramGtkFixed, long paramLong);
/*      */   
/*      */   public static final native void memmove(long paramLong, GtkFixed paramGtkFixed);
/*      */   
/*      */   public static final native void memmove(GdkImage paramGdkImage, long paramLong);
/*      */   
/*      */   public static final native void memmove(GdkRectangle paramGdkRectangle, long paramLong1, long paramLong2);
/*      */   
/*      */   public static final native void memmove(PangoAttribute paramPangoAttribute, long paramLong1, long paramLong2);
/*      */   
/*      */   public static final native void memmove(PangoAttrColor paramPangoAttrColor, long paramLong1, long paramLong2);
/*      */   
/*      */   public static final native void memmove(PangoAttrInt paramPangoAttrInt, long paramLong1, long paramLong2);
/*      */   
/*      */   public static final native void memmove(PangoItem paramPangoItem, long paramLong1, long paramLong2);
/*      */   
/*      */   public static final native void memmove(PangoLayoutLine paramPangoLayoutLine, long paramLong1, long paramLong2);
/*      */   
/*      */   public static final native void memmove(PangoLayoutRun paramPangoLayoutRun, long paramLong1, long paramLong2);
/*      */   
/*      */   public static final native void memmove(PangoLogAttr paramPangoLogAttr, long paramLong1, long paramLong2);
/*      */   
/*      */   public static final native long _pango_attribute_copy(long paramLong);
/*      */   
/*      */   public static final native long _pango_attr_background_new(short paramShort1, short paramShort2, short paramShort3);
/*      */   
/*      */   public static final native long _pango_attr_font_desc_new(long paramLong);
/*      */   
/*      */   public static final native long _pango_attr_foreground_new(short paramShort1, short paramShort2, short paramShort3);
/*      */   
/*      */   public static final native long _pango_attr_rise_new(int paramInt);
/*      */   
/*      */   public static final native long _pango_attr_shape_new(PangoRectangle paramPangoRectangle1, PangoRectangle paramPangoRectangle2);
/*      */   
/*      */   public static final native void _pango_attr_list_insert(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final native long _pango_attr_list_get_iterator(long paramLong);
/*      */   
/*      */   public static final native boolean _pango_attr_iterator_next(long paramLong);
/*      */   
/*      */   public static final native void _pango_attr_iterator_range(long paramLong, int[] paramArrayOfInt1, int[] paramArrayOfInt2);
/*      */   
/*      */   public static final native long _pango_attr_iterator_get(long paramLong, int paramInt);
/*      */   
/*      */   public static final native void _pango_attr_iterator_destroy(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void pango_attr_iterator_destroy(long iterator)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 9	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 209	org/eclipse/swt/internal/gtk/OS:_pango_attr_iterator_destroy	(J)V
/*      */     //   11: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 11	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 11	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #3306	-> byte code offset #0
/*      */     //   Java source line #3308	-> byte code offset #7
/*      */     //   Java source line #3310	-> byte code offset #11
/*      */     //   Java source line #3311	-> byte code offset #17
/*      */     //   Java source line #3310	-> byte code offset #20
/*      */     //   Java source line #3311	-> byte code offset #27
/*      */     //   Java source line #3312	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	iterator	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native long _pango_attr_list_new();
/*      */   
/*      */   public static final native void _pango_attr_list_unref(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void pango_attr_list_unref(long list)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 9	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 211	org/eclipse/swt/internal/gtk/OS:_pango_attr_list_unref	(J)V
/*      */     //   11: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 11	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 11	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #3325	-> byte code offset #0
/*      */     //   Java source line #3327	-> byte code offset #7
/*      */     //   Java source line #3329	-> byte code offset #11
/*      */     //   Java source line #3330	-> byte code offset #17
/*      */     //   Java source line #3329	-> byte code offset #20
/*      */     //   Java source line #3330	-> byte code offset #27
/*      */     //   Java source line #3331	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	list	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native long _pango_attr_strikethrough_color_new(short paramShort1, short paramShort2, short paramShort3);
/*      */   
/*      */   public static final native long _pango_attr_strikethrough_new(boolean paramBoolean);
/*      */   
/*      */   public static final native long _pango_attr_underline_color_new(short paramShort1, short paramShort2, short paramShort3);
/*      */   
/*      */   public static final native long _pango_attr_underline_new(int paramInt);
/*      */   
/*      */   public static final native long _pango_attr_weight_new(int paramInt);
/*      */   
/*      */   public static final native long _pango_cairo_create_layout(long paramLong);
/*      */   
/*      */   public static final native long _pango_cairo_context_get_font_options(long paramLong);
/*      */   
/*      */   public static final native void _pango_cairo_context_set_font_options(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final native void _pango_cairo_layout_path(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final native void _pango_cairo_show_layout(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final native int _pango_context_get_base_dir(long paramLong);
/*      */   
/*      */   public static final native long _pango_context_get_language(long paramLong);
/*      */   
/*      */   public static final native long _pango_context_get_metrics(long paramLong1, long paramLong2, long paramLong3);
/*      */   
/*      */   public static final native void _pango_context_list_families(long paramLong, long[] paramArrayOfLong, int[] paramArrayOfInt);
/*      */   
/*      */   public static final native void _pango_context_set_base_dir(long paramLong, int paramInt);
/*      */   
/*      */   /* Error */
/*      */   public static final void pango_context_set_base_dir(long context, int direction)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 9	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 226	org/eclipse/swt/internal/gtk/OS:_pango_context_set_base_dir	(JI)V
/*      */     //   12: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 11	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 11	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #3491	-> byte code offset #0
/*      */     //   Java source line #3493	-> byte code offset #7
/*      */     //   Java source line #3495	-> byte code offset #12
/*      */     //   Java source line #3496	-> byte code offset #18
/*      */     //   Java source line #3495	-> byte code offset #21
/*      */     //   Java source line #3496	-> byte code offset #28
/*      */     //   Java source line #3497	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	context	long
/*      */     //   0	31	2	direction	int
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _pango_context_set_language(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final native long _pango_font_description_copy(long paramLong);
/*      */   
/*      */   public static final native void _pango_font_description_free(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void pango_font_description_free(long desc)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 9	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 229	org/eclipse/swt/internal/gtk/OS:_pango_font_description_free	(J)V
/*      */     //   11: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 11	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 11	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #3524	-> byte code offset #0
/*      */     //   Java source line #3526	-> byte code offset #7
/*      */     //   Java source line #3528	-> byte code offset #11
/*      */     //   Java source line #3529	-> byte code offset #17
/*      */     //   Java source line #3528	-> byte code offset #20
/*      */     //   Java source line #3529	-> byte code offset #27
/*      */     //   Java source line #3530	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	desc	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native long _pango_font_description_from_string(byte[] paramArrayOfByte);
/*      */   
/*      */   public static final native long _pango_font_description_get_family(long paramLong);
/*      */   
/*      */   public static final native int _pango_font_description_get_size(long paramLong);
/*      */   
/*      */   public static final native int _pango_font_description_get_stretch(long paramLong);
/*      */   
/*      */   public static final native int _pango_font_description_get_variant(long paramLong);
/*      */   
/*      */   public static final native int _pango_font_description_get_style(long paramLong);
/*      */   
/*      */   public static final native int _pango_font_description_get_weight(long paramLong);
/*      */   
/*      */   public static final native long _pango_font_description_new();
/*      */   
/*      */   public static final native void _pango_font_description_set_family(long paramLong, byte[] paramArrayOfByte);
/*      */   
/*      */   /* Error */
/*      */   public static final void pango_font_description_set_family(long desc, byte[] family)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 9	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: aload_2
/*      */     //   9: invokestatic 238	org/eclipse/swt/internal/gtk/OS:_pango_font_description_set_family	(J[B)V
/*      */     //   12: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 11	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 11	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #3616	-> byte code offset #0
/*      */     //   Java source line #3618	-> byte code offset #7
/*      */     //   Java source line #3620	-> byte code offset #12
/*      */     //   Java source line #3621	-> byte code offset #18
/*      */     //   Java source line #3620	-> byte code offset #21
/*      */     //   Java source line #3621	-> byte code offset #28
/*      */     //   Java source line #3622	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	desc	long
/*      */     //   0	31	2	family	byte[]
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _pango_font_description_set_size(long paramLong, int paramInt);
/*      */   
/*      */   /* Error */
/*      */   public static final void pango_font_description_set_size(long desc, int size)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 9	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 239	org/eclipse/swt/internal/gtk/OS:_pango_font_description_set_size	(JI)V
/*      */     //   12: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 11	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 11	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #3629	-> byte code offset #0
/*      */     //   Java source line #3631	-> byte code offset #7
/*      */     //   Java source line #3633	-> byte code offset #12
/*      */     //   Java source line #3634	-> byte code offset #18
/*      */     //   Java source line #3633	-> byte code offset #21
/*      */     //   Java source line #3634	-> byte code offset #28
/*      */     //   Java source line #3635	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	desc	long
/*      */     //   0	31	2	size	int
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _pango_font_description_set_stretch(long paramLong, int paramInt);
/*      */   
/*      */   /* Error */
/*      */   public static final void pango_font_description_set_stretch(long desc, int stretch)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 9	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 240	org/eclipse/swt/internal/gtk/OS:_pango_font_description_set_stretch	(JI)V
/*      */     //   12: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 11	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 11	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #3642	-> byte code offset #0
/*      */     //   Java source line #3644	-> byte code offset #7
/*      */     //   Java source line #3646	-> byte code offset #12
/*      */     //   Java source line #3647	-> byte code offset #18
/*      */     //   Java source line #3646	-> byte code offset #21
/*      */     //   Java source line #3647	-> byte code offset #28
/*      */     //   Java source line #3648	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	desc	long
/*      */     //   0	31	2	stretch	int
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _pango_font_description_set_style(long paramLong, int paramInt);
/*      */   
/*      */   /* Error */
/*      */   public static final void pango_font_description_set_style(long desc, int weight)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 9	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 241	org/eclipse/swt/internal/gtk/OS:_pango_font_description_set_style	(JI)V
/*      */     //   12: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 11	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 11	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #3655	-> byte code offset #0
/*      */     //   Java source line #3657	-> byte code offset #7
/*      */     //   Java source line #3659	-> byte code offset #12
/*      */     //   Java source line #3660	-> byte code offset #18
/*      */     //   Java source line #3659	-> byte code offset #21
/*      */     //   Java source line #3660	-> byte code offset #28
/*      */     //   Java source line #3661	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	desc	long
/*      */     //   0	31	2	weight	int
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _pango_font_description_set_weight(long paramLong, int paramInt);
/*      */   
/*      */   /* Error */
/*      */   public static final void pango_font_description_set_weight(long desc, int weight)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 9	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 242	org/eclipse/swt/internal/gtk/OS:_pango_font_description_set_weight	(JI)V
/*      */     //   12: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 11	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 11	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #3668	-> byte code offset #0
/*      */     //   Java source line #3670	-> byte code offset #7
/*      */     //   Java source line #3672	-> byte code offset #12
/*      */     //   Java source line #3673	-> byte code offset #18
/*      */     //   Java source line #3672	-> byte code offset #21
/*      */     //   Java source line #3673	-> byte code offset #28
/*      */     //   Java source line #3674	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	desc	long
/*      */     //   0	31	2	weight	int
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _pango_font_description_set_variant(long paramLong, int paramInt);
/*      */   
/*      */   /* Error */
/*      */   public static final void pango_font_description_set_variant(long desc, int variant)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 9	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 243	org/eclipse/swt/internal/gtk/OS:_pango_font_description_set_variant	(JI)V
/*      */     //   12: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 11	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 11	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #3681	-> byte code offset #0
/*      */     //   Java source line #3683	-> byte code offset #7
/*      */     //   Java source line #3685	-> byte code offset #12
/*      */     //   Java source line #3686	-> byte code offset #18
/*      */     //   Java source line #3685	-> byte code offset #21
/*      */     //   Java source line #3686	-> byte code offset #28
/*      */     //   Java source line #3687	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	desc	long
/*      */     //   0	31	2	variant	int
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native long _pango_font_description_to_string(long paramLong);
/*      */   
/*      */   public static final native long _pango_font_face_describe(long paramLong);
/*      */   
/*      */   public static final native long _pango_font_family_get_name(long paramLong);
/*      */   
/*      */   public static final native void _pango_font_family_list_faces(long paramLong, long[] paramArrayOfLong, int[] paramArrayOfInt);
/*      */   
/*      */   public static final native long _pango_font_get_metrics(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final native int _pango_font_metrics_get_approximate_char_width(long paramLong);
/*      */   
/*      */   public static final native int _pango_font_metrics_get_ascent(long paramLong);
/*      */   
/*      */   public static final native int _pango_font_metrics_get_descent(long paramLong);
/*      */   
/*      */   public static final native void _pango_font_metrics_unref(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void pango_font_metrics_unref(long metrics)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 9	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 252	org/eclipse/swt/internal/gtk/OS:_pango_font_metrics_unref	(J)V
/*      */     //   11: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 11	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 11	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #3778	-> byte code offset #0
/*      */     //   Java source line #3780	-> byte code offset #7
/*      */     //   Java source line #3782	-> byte code offset #11
/*      */     //   Java source line #3783	-> byte code offset #17
/*      */     //   Java source line #3782	-> byte code offset #20
/*      */     //   Java source line #3783	-> byte code offset #27
/*      */     //   Java source line #3784	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	metrics	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native void _pango_layout_context_changed(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void pango_layout_context_changed(long layout)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 9	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 253	org/eclipse/swt/internal/gtk/OS:_pango_layout_context_changed	(J)V
/*      */     //   11: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 11	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 11	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #3788	-> byte code offset #0
/*      */     //   Java source line #3790	-> byte code offset #7
/*      */     //   Java source line #3792	-> byte code offset #11
/*      */     //   Java source line #3793	-> byte code offset #17
/*      */     //   Java source line #3792	-> byte code offset #20
/*      */     //   Java source line #3793	-> byte code offset #27
/*      */     //   Java source line #3794	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	layout	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native int _pango_layout_get_alignment(long paramLong);
/*      */   
/*      */   public static final native long _pango_layout_get_context(long paramLong);
/*      */   
/*      */   public static final native int _pango_layout_get_indent(long paramLong);
/*      */   
/*      */   public static final native long _pango_layout_get_iter(long paramLong);
/*      */   
/*      */   public static final native boolean _pango_layout_get_justify(long paramLong);
/*      */   
/*      */   public static final native long _pango_layout_get_line(long paramLong, int paramInt);
/*      */   
/*      */   public static final native int _pango_layout_get_line_count(long paramLong);
/*      */   
/*      */   public static final native void _pango_layout_get_log_attrs(long paramLong, long[] paramArrayOfLong, int[] paramArrayOfInt);
/*      */   
/*      */   public static final native void _pango_layout_get_size(long paramLong, int[] paramArrayOfInt1, int[] paramArrayOfInt2);
/*      */   
/*      */   public static final native void _pango_layout_get_pixel_size(long paramLong, int[] paramArrayOfInt1, int[] paramArrayOfInt2);
/*      */   
/*      */   public static final native int _pango_layout_get_spacing(long paramLong);
/*      */   
/*      */   public static final native long _pango_layout_get_text(long paramLong);
/*      */   
/*      */   public static final native int _pango_layout_get_width(long paramLong);
/*      */   
/*      */   public static final native void _pango_layout_index_to_pos(long paramLong, int paramInt, PangoRectangle paramPangoRectangle);
/*      */   
/*      */   public static final native void _pango_layout_iter_free(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void pango_layout_iter_free(long iter)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 9	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 268	org/eclipse/swt/internal/gtk/OS:_pango_layout_iter_free	(J)V
/*      */     //   11: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 11	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 11	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #3953	-> byte code offset #0
/*      */     //   Java source line #3955	-> byte code offset #7
/*      */     //   Java source line #3957	-> byte code offset #11
/*      */     //   Java source line #3958	-> byte code offset #17
/*      */     //   Java source line #3957	-> byte code offset #20
/*      */     //   Java source line #3958	-> byte code offset #27
/*      */     //   Java source line #3959	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	iter	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native void _pango_layout_iter_get_line_extents(long paramLong, PangoRectangle paramPangoRectangle1, PangoRectangle paramPangoRectangle2);
/*      */   
/*      */   public static final native int _pango_layout_iter_get_index(long paramLong);
/*      */   
/*      */   public static final native long _pango_layout_iter_get_run(long paramLong);
/*      */   
/*      */   public static final native boolean _pango_layout_iter_next_line(long paramLong);
/*      */   
/*      */   public static final native boolean _pango_layout_iter_next_run(long paramLong);
/*      */   
/*      */   public static final native void _pango_layout_line_get_extents(long paramLong, PangoRectangle paramPangoRectangle1, PangoRectangle paramPangoRectangle2);
/*      */   
/*      */   public static final native long _pango_layout_new(long paramLong);
/*      */   
/*      */   public static final native void _pango_layout_set_alignment(long paramLong, int paramInt);
/*      */   
/*      */   /* Error */
/*      */   public static final void pango_layout_set_alignment(long layout, int alignment)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 9	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 276	org/eclipse/swt/internal/gtk/OS:_pango_layout_set_alignment	(JI)V
/*      */     //   12: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 11	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 11	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #4041	-> byte code offset #0
/*      */     //   Java source line #4043	-> byte code offset #7
/*      */     //   Java source line #4045	-> byte code offset #12
/*      */     //   Java source line #4046	-> byte code offset #18
/*      */     //   Java source line #4045	-> byte code offset #21
/*      */     //   Java source line #4046	-> byte code offset #28
/*      */     //   Java source line #4047	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	layout	long
/*      */     //   0	31	2	alignment	int
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _pango_layout_set_attributes(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final native void _pango_layout_set_auto_dir(long paramLong, boolean paramBoolean);
/*      */   
/*      */   /* Error */
/*      */   public static final void pango_layout_set_auto_dir(long layout, boolean auto_dir)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 9	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 278	org/eclipse/swt/internal/gtk/OS:_pango_layout_set_auto_dir	(JZ)V
/*      */     //   12: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 11	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 11	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #4066	-> byte code offset #0
/*      */     //   Java source line #4068	-> byte code offset #7
/*      */     //   Java source line #4070	-> byte code offset #12
/*      */     //   Java source line #4071	-> byte code offset #18
/*      */     //   Java source line #4070	-> byte code offset #21
/*      */     //   Java source line #4071	-> byte code offset #28
/*      */     //   Java source line #4072	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	layout	long
/*      */     //   0	31	2	auto_dir	boolean
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _pango_layout_set_font_description(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final native void _pango_layout_set_indent(long paramLong, int paramInt);
/*      */   
/*      */   /* Error */
/*      */   public static final void pango_layout_set_indent(long layout, int indent)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 9	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 280	org/eclipse/swt/internal/gtk/OS:_pango_layout_set_indent	(JI)V
/*      */     //   12: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 11	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 11	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #4089	-> byte code offset #0
/*      */     //   Java source line #4091	-> byte code offset #7
/*      */     //   Java source line #4093	-> byte code offset #12
/*      */     //   Java source line #4094	-> byte code offset #18
/*      */     //   Java source line #4093	-> byte code offset #21
/*      */     //   Java source line #4094	-> byte code offset #28
/*      */     //   Java source line #4095	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	layout	long
/*      */     //   0	31	2	indent	int
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _pango_layout_set_justify(long paramLong, boolean paramBoolean);
/*      */   
/*      */   /* Error */
/*      */   public static final void pango_layout_set_justify(long layout, boolean justify)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 9	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 281	org/eclipse/swt/internal/gtk/OS:_pango_layout_set_justify	(JZ)V
/*      */     //   12: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 11	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 11	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #4099	-> byte code offset #0
/*      */     //   Java source line #4101	-> byte code offset #7
/*      */     //   Java source line #4103	-> byte code offset #12
/*      */     //   Java source line #4104	-> byte code offset #18
/*      */     //   Java source line #4103	-> byte code offset #21
/*      */     //   Java source line #4104	-> byte code offset #28
/*      */     //   Java source line #4105	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	layout	long
/*      */     //   0	31	2	justify	boolean
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _pango_layout_set_single_paragraph_mode(long paramLong, boolean paramBoolean);
/*      */   
/*      */   /* Error */
/*      */   public static final void pango_layout_set_single_paragraph_mode(long context, boolean setting)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 9	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 282	org/eclipse/swt/internal/gtk/OS:_pango_layout_set_single_paragraph_mode	(JZ)V
/*      */     //   12: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 11	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 11	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #4112	-> byte code offset #0
/*      */     //   Java source line #4114	-> byte code offset #7
/*      */     //   Java source line #4116	-> byte code offset #12
/*      */     //   Java source line #4117	-> byte code offset #18
/*      */     //   Java source line #4116	-> byte code offset #21
/*      */     //   Java source line #4117	-> byte code offset #28
/*      */     //   Java source line #4118	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	context	long
/*      */     //   0	31	2	setting	boolean
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _pango_layout_set_spacing(long paramLong, int paramInt);
/*      */   
/*      */   /* Error */
/*      */   public static final void pango_layout_set_spacing(long layout, int spacing)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 9	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 283	org/eclipse/swt/internal/gtk/OS:_pango_layout_set_spacing	(JI)V
/*      */     //   12: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 11	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 11	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #4122	-> byte code offset #0
/*      */     //   Java source line #4124	-> byte code offset #7
/*      */     //   Java source line #4126	-> byte code offset #12
/*      */     //   Java source line #4127	-> byte code offset #18
/*      */     //   Java source line #4126	-> byte code offset #21
/*      */     //   Java source line #4127	-> byte code offset #28
/*      */     //   Java source line #4128	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	layout	long
/*      */     //   0	31	2	spacing	int
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _pango_layout_set_tabs(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final native void _pango_layout_set_text(long paramLong, byte[] paramArrayOfByte, int paramInt);
/*      */   
/*      */   public static final native void _pango_layout_set_width(long paramLong, int paramInt);
/*      */   
/*      */   /* Error */
/*      */   public static final void pango_layout_set_width(long layout, int width)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 9	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 286	org/eclipse/swt/internal/gtk/OS:_pango_layout_set_width	(JI)V
/*      */     //   12: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 11	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 11	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #4159	-> byte code offset #0
/*      */     //   Java source line #4161	-> byte code offset #7
/*      */     //   Java source line #4163	-> byte code offset #12
/*      */     //   Java source line #4164	-> byte code offset #18
/*      */     //   Java source line #4163	-> byte code offset #21
/*      */     //   Java source line #4164	-> byte code offset #28
/*      */     //   Java source line #4165	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	layout	long
/*      */     //   0	31	2	width	int
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _pango_layout_set_wrap(long paramLong, int paramInt);
/*      */   
/*      */   /* Error */
/*      */   public static final void pango_layout_set_wrap(long layout, int wrap)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 9	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 287	org/eclipse/swt/internal/gtk/OS:_pango_layout_set_wrap	(JI)V
/*      */     //   12: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 11	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 11	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #4169	-> byte code offset #0
/*      */     //   Java source line #4171	-> byte code offset #7
/*      */     //   Java source line #4173	-> byte code offset #12
/*      */     //   Java source line #4174	-> byte code offset #18
/*      */     //   Java source line #4173	-> byte code offset #21
/*      */     //   Java source line #4174	-> byte code offset #28
/*      */     //   Java source line #4175	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	layout	long
/*      */     //   0	31	2	wrap	int
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native boolean _pango_layout_xy_to_index(long paramLong, int paramInt1, int paramInt2, int[] paramArrayOfInt1, int[] paramArrayOfInt2);
/*      */   
/*      */   public static final native void _pango_tab_array_free(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void pango_tab_array_free(long tab_array)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 9	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 289	org/eclipse/swt/internal/gtk/OS:_pango_tab_array_free	(J)V
/*      */     //   11: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 11	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 8	org/eclipse/swt/internal/gtk/OS:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 11	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #4193	-> byte code offset #0
/*      */     //   Java source line #4195	-> byte code offset #7
/*      */     //   Java source line #4197	-> byte code offset #11
/*      */     //   Java source line #4198	-> byte code offset #17
/*      */     //   Java source line #4197	-> byte code offset #20
/*      */     //   Java source line #4198	-> byte code offset #27
/*      */     //   Java source line #4199	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	tab_array	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native long _pango_tab_array_new(int paramInt, boolean paramBoolean);
/*      */   
/*      */   public static final native void _pango_tab_array_set_tab(long paramLong1, int paramInt1, long paramLong2, int paramInt2);
/*      */   
/*      */   public static final native long _ubuntu_menu_proxy_get();
/*      */   
/*      */   public static final native int _access(byte[] paramArrayOfByte, int paramInt);
/*      */   
/*      */   public static final native int strcmp(long paramLong, byte[] paramArrayOfByte);
/*      */   
/*      */   public static final native long _g_dbus_node_info_new_for_xml(byte[] paramArrayOfByte, long[] paramArrayOfLong);
/*      */   
/*      */   public static final native int _g_bus_own_name(int paramInt1, byte[] paramArrayOfByte, int paramInt2, long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5);
/*      */   
/*      */   public static final native int _g_dbus_connection_register_object(long paramLong1, byte[] paramArrayOfByte, long paramLong2, long[] paramArrayOfLong1, long paramLong3, long paramLong4, long[] paramArrayOfLong2);
/*      */   
/*      */   public static final native long _g_dbus_node_info_lookup_interface(long paramLong, byte[] paramArrayOfByte);
/*      */   
/*      */   public static final native void _g_dbus_method_invocation_return_value(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final native long _g_variant_new_int32(int paramInt);
/*      */   
/*      */   public static final native int _g_variant_get_int32(long paramLong);
/*      */   
/*      */   public static final native byte _g_variant_get_byte(long paramLong);
/*      */   
/*      */   public static final native boolean _g_variant_get_boolean(long paramLong);
/*      */   
/*      */   public static final native long _g_variant_get_child_value(long paramLong, int paramInt);
/*      */   
/*      */   public static final native double _g_variant_get_double(long paramLong);
/*      */   
/*      */   public static final native long _g_variant_get_string(long paramLong, long[] paramArrayOfLong);
/*      */   
/*      */   public static final native long _g_variant_get_type(long paramLong);
/*      */   
/*      */   public static final native long _g_variant_get_type_string(long paramLong);
/*      */   
/*      */   public static final native boolean _g_variant_is_of_type(long paramLong, byte[] paramArrayOfByte);
/*      */   
/*      */   public static final native long _g_variant_n_children(long paramLong);
/*      */   
/*      */   public static final native long _g_variant_new_boolean(boolean paramBoolean);
/*      */   
/*      */   public static final native long _g_variant_new_double(double paramDouble);
/*      */   
/*      */   public static final native long _g_variant_new_byte(byte paramByte);
/*      */   
/*      */   public static final native long _g_variant_new_tuple(long[] paramArrayOfLong, long paramLong);
/*      */   
/*      */   public static final native long _g_variant_new_string(byte[] paramArrayOfByte);
/*      */   
/*      */   public static final native long _g_object_ref_sink(long paramLong);
/*      */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/internal/gtk/OS.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */