/*     */ package org.eclipse.swt.events;
/*     */ 
/*     */ import org.eclipse.swt.widgets.Event;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MouseEvent
/*     */   extends TypedEvent
/*     */ {
/*     */   public int button;
/*     */   public int stateMask;
/*     */   public int x;
/*     */   public int y;
/*     */   public int count;
/*     */   static final long serialVersionUID = 3257288037011566898L;
/*     */   
/*     */   public MouseEvent(Event e)
/*     */   {
/*  84 */     super(e);
/*  85 */     this.x = e.x;
/*  86 */     this.y = e.y;
/*  87 */     this.button = e.button;
/*  88 */     this.stateMask = e.stateMask;
/*  89 */     this.count = e.count;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 100 */     String string = super.toString();
/* 101 */     return string.substring(0, string.length() - 1) + " button=" + this.button + " stateMask=0x" + 
/*     */     
/* 103 */       Integer.toHexString(this.stateMask) + " x=" + this.x + " y=" + this.y + " count=" + this.count + "}";
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/events/MouseEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */