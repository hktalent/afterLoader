/*     */ package org.eclipse.swt.widgets;
/*     */ 
/*     */ import org.eclipse.swt.graphics.Font;
/*     */ import org.eclipse.swt.graphics.FontData;
/*     */ import org.eclipse.swt.graphics.RGB;
/*     */ import org.eclipse.swt.internal.C;
/*     */ import org.eclipse.swt.internal.Converter;
/*     */ import org.eclipse.swt.internal.gtk.GDK;
/*     */ import org.eclipse.swt.internal.gtk.GTK;
/*     */ import org.eclipse.swt.internal.gtk.OS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FontDialog
/*     */   extends Dialog
/*     */ {
/*     */   FontData fontData;
/*     */   RGB rgb;
/*     */   
/*     */   public FontDialog(Shell parent)
/*     */   {
/*  53 */     this(parent, 65536);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FontDialog(Shell parent, int style)
/*     */   {
/*  80 */     super(parent, checkStyle(parent, style));
/*  81 */     checkSubclass();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getEffectsVisible()
/*     */   {
/*  99 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public FontData getFontData()
/*     */   {
/* 111 */     return this.fontData;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FontData[] getFontList()
/*     */   {
/* 122 */     if (this.fontData == null) return null;
/* 123 */     FontData[] result = new FontData[1];
/* 124 */     result[0] = this.fontData;
/* 125 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RGB getRGB()
/*     */   {
/* 139 */     return this.rgb;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FontData open()
/*     */   {
/* 157 */     byte[] titleBytes = Converter.wcsToMbcs(this.title, true);
/* 158 */     Display display = this.parent != null ? this.parent.getDisplay() : Display.getCurrent();
/* 159 */     long handle = gtk_font_chooser_dialog_new(titleBytes);
/* 160 */     if (this.parent != null) {
/* 161 */       long shellHandle = this.parent.topHandle();
/* 162 */       GTK.gtk_window_set_transient_for(handle, shellHandle);
/* 163 */       long pixbufs = GTK.gtk_window_get_icon_list(shellHandle);
/* 164 */       if (pixbufs != 0L) {
/* 165 */         GTK.gtk_window_set_icon_list(handle, pixbufs);
/* 166 */         OS.g_list_free(pixbufs);
/*     */       }
/*     */     }
/* 169 */     long group = GTK.gtk_window_get_group(0L);
/* 170 */     GTK.gtk_window_group_add_window(group, handle);
/* 171 */     GTK.gtk_window_set_modal(handle, true);
/* 172 */     if (this.fontData != null) {
/* 173 */       Font font = new Font(display, this.fontData);
/* 174 */       long fontName = OS.pango_font_description_to_string(font.handle);
/* 175 */       int length = C.strlen(fontName);
/* 176 */       byte[] buffer = new byte[length + 1];
/* 177 */       C.memmove(buffer, fontName, length);
/* 178 */       font.dispose();
/* 179 */       OS.g_free(fontName);
/* 180 */       gtk_font_chooser_set_font(handle, buffer);
/*     */     }
/* 182 */     display.addIdleProc();
/* 183 */     Dialog oldModal = null;
/* 184 */     if (GTK.gtk_window_get_modal(handle)) {
/* 185 */       oldModal = display.getModalDialog();
/* 186 */       display.setModalDialog(this);
/*     */     }
/* 188 */     int signalId = 0;
/* 189 */     long hookId = 0L;
/* 190 */     if ((this.style & 0x4000000) != 0) {
/* 191 */       signalId = OS.g_signal_lookup(OS.map, GTK.GTK_TYPE_WIDGET());
/* 192 */       hookId = OS.g_signal_add_emission_hook(signalId, 0, display.emissionProc, handle, 0L);
/*     */     }
/* 194 */     display.sendPreExternalEventDispatchEvent();
/* 195 */     int response = GTK.gtk_dialog_run(handle);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 202 */     GDK.gdk_threads_leave();
/* 203 */     display.sendPostExternalEventDispatchEvent();
/* 204 */     if ((this.style & 0x4000000) != 0) {
/* 205 */       OS.g_signal_remove_emission_hook(signalId, hookId);
/*     */     }
/* 207 */     if (GTK.gtk_window_get_modal(handle)) {
/* 208 */       display.setModalDialog(oldModal);
/*     */     }
/* 210 */     boolean success = response == -5;
/* 211 */     if (success) {
/* 212 */       long fontName = gtk_font_chooser_get_font(handle);
/* 213 */       int length = C.strlen(fontName);
/* 214 */       byte[] buffer = new byte[length + 1];
/* 215 */       C.memmove(buffer, fontName, length);
/* 216 */       OS.g_free(fontName);
/* 217 */       long fontDesc = OS.pango_font_description_from_string(buffer);
/* 218 */       Font font = Font.gtk_new(display, fontDesc);
/* 219 */       this.fontData = font.getFontData()[0];
/* 220 */       OS.pango_font_description_free(fontDesc);
/*     */     }
/* 222 */     display.removeIdleProc();
/* 223 */     GTK.gtk_widget_destroy(handle);
/* 224 */     if (!success) return null;
/* 225 */     return this.fontData;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setEffectsVisible(boolean visible) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public void setFontData(FontData fontData)
/*     */   {
/* 253 */     this.fontData = fontData;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFontList(FontData[] fontData)
/*     */   {
/* 269 */     if ((fontData != null) && (fontData.length > 0)) {
/* 270 */       this.fontData = fontData[0];
/*     */     } else {
/* 272 */       this.fontData = null;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRGB(RGB rgb)
/*     */   {
/* 287 */     this.rgb = rgb;
/*     */   }
/*     */   
/*     */   long gtk_font_chooser_get_font(long fontchooser) {
/* 291 */     if (GTK.GTK_VERSION >= OS.VERSION(3, 2, 0)) {
/* 292 */       return GTK.gtk_font_chooser_get_font(fontchooser);
/*     */     }
/* 294 */     return GTK.gtk_font_selection_dialog_get_font_name(fontchooser);
/*     */   }
/*     */   
/*     */   long gtk_font_chooser_dialog_new(byte[] title)
/*     */   {
/* 299 */     if (GTK.GTK_VERSION >= OS.VERSION(3, 2, 0)) {
/* 300 */       return GTK.gtk_font_chooser_dialog_new(title, 0L);
/*     */     }
/* 302 */     return GTK.gtk_font_selection_dialog_new(title);
/*     */   }
/*     */   
/*     */ 
/*     */   void gtk_font_chooser_set_font(long fsd, byte[] fontname)
/*     */   {
/* 308 */     if (GTK.GTK_VERSION >= OS.VERSION(3, 2, 0)) {
/* 309 */       GTK.gtk_font_chooser_set_font(fsd, fontname);
/*     */     } else {
/* 311 */       GTK.gtk_font_selection_dialog_set_font_name(fsd, fontname);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/widgets/FontDialog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */