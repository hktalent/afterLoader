/*     */ package org.eclipse.swt.graphics;
/*     */ 
/*     */ import org.eclipse.swt.SWT;
/*     */ import org.eclipse.swt.internal.C;
/*     */ import org.eclipse.swt.internal.Converter;
/*     */ import org.eclipse.swt.internal.gtk.OS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Font
/*     */   extends Resource
/*     */ {
/*     */   public long handle;
/*     */   
/*     */   Font(Device device)
/*     */   {
/*  50 */     super(device);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Font(Device device, FontData fd)
/*     */   {
/*  74 */     super(device);
/*  75 */     if (fd == null) SWT.error(4);
/*  76 */     init(fd.getName(), fd.getHeightF(), fd.getStyle(), fd.string);
/*  77 */     init();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Font(Device device, FontData[] fds)
/*     */   {
/* 106 */     super(device);
/* 107 */     if (fds == null) SWT.error(4);
/* 108 */     if (fds.length == 0) SWT.error(5);
/* 109 */     for (int i = 0; i < fds.length; i++) {
/* 110 */       if (fds[i] == null) SWT.error(5);
/*     */     }
/* 112 */     FontData fd = fds[0];
/* 113 */     init(fd.getName(), fd.getHeightF(), fd.getStyle(), fd.string);
/* 114 */     init();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Font(Device device, String name, int height, int style)
/*     */   {
/* 142 */     super(device);
/* 143 */     init(name, height, style, null);
/* 144 */     init();
/*     */   }
/*     */   
/*     */   Font(Device device, String name, float height, int style) {
/* 148 */     super(device);
/* 149 */     init(name, height, style, null);
/* 150 */     init();
/*     */   }
/*     */   
/*     */   void destroy()
/*     */   {
/* 155 */     OS.pango_font_description_free(this.handle);
/* 156 */     this.handle = 0L;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object object)
/*     */   {
/* 171 */     if (object == this) return true;
/* 172 */     if (!(object instanceof Font)) return false;
/* 173 */     return this.handle == ((Font)object).handle;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FontData[] getFontData()
/*     */   {
/* 189 */     if (isDisposed()) { SWT.error(44);
/*     */     }
/* 191 */     long family = OS.pango_font_description_get_family(this.handle);
/* 192 */     int length = C.strlen(family);
/* 193 */     byte[] buffer = new byte[length];
/* 194 */     C.memmove(buffer, family, length);
/* 195 */     String name = new String(Converter.mbcsToWcs(buffer));
/* 196 */     float height = OS.pango_font_description_get_size(this.handle) / 1024.0F;
/* 197 */     Point dpi = this.device.dpi;Point screenDPI = this.device.getScreenDPI();
/* 198 */     float size = height * screenDPI.y / dpi.y;
/* 199 */     int pangoStyle = OS.pango_font_description_get_style(this.handle);
/* 200 */     int pangoWeight = OS.pango_font_description_get_weight(this.handle);
/* 201 */     int style = 0;
/* 202 */     if (pangoStyle == 2) style |= 0x2;
/* 203 */     if (pangoStyle == 1) style |= 0x20;
/* 204 */     if (pangoWeight >= 700) style |= 0x1;
/* 205 */     long fontString = OS.pango_font_description_to_string(this.handle);
/* 206 */     length = C.strlen(fontString);
/* 207 */     buffer = new byte[length + 1];
/* 208 */     C.memmove(buffer, fontString, length);
/* 209 */     OS.g_free(fontString);
/* 210 */     FontData data = new FontData(name, size, style);
/* 211 */     data.string = buffer;
/* 212 */     return new FontData[] { data };
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Font gtk_new(Device device, long handle)
/*     */   {
/* 231 */     Font font = new Font(device);
/* 232 */     font.handle = handle;
/* 233 */     return font;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 248 */     return (int)this.handle;
/*     */   }
/*     */   
/*     */   void init(String name, float height, int style, byte[] fontString) {
/* 252 */     if (name == null) SWT.error(4);
/* 253 */     if (height < 0.0F) SWT.error(5);
/* 254 */     Point dpi = this.device.dpi;Point screenDPI = this.device.getScreenDPI();
/* 255 */     float size = height * dpi.y / screenDPI.y;
/* 256 */     if (fontString != null) {
/* 257 */       this.handle = OS.pango_font_description_from_string(fontString);
/* 258 */       if (this.handle == 0L) SWT.error(2);
/*     */     } else {
/* 260 */       this.handle = OS.pango_font_description_new();
/* 261 */       if (this.handle == 0L) SWT.error(2);
/* 262 */       byte[] buffer = Converter.wcsToMbcs(name, true);
/* 263 */       OS.pango_font_description_set_family(this.handle, buffer);
/* 264 */       if (size > 0.0F) {
/* 265 */         OS.pango_font_description_set_size(this.handle, (int)(0.5F + size * 1024.0F));
/*     */       }
/* 267 */       OS.pango_font_description_set_stretch(this.handle, 4);
/* 268 */       int pangoStyle = 0;
/* 269 */       int pangoWeight = 400;
/* 270 */       if ((style & 0x2) != 0) pangoStyle = 2;
/* 271 */       if ((style & 0x20) != 0) pangoStyle = 1;
/* 272 */       if ((style & 0x1) != 0) pangoWeight = 700;
/* 273 */       OS.pango_font_description_set_style(this.handle, pangoStyle);
/* 274 */       OS.pango_font_description_set_weight(this.handle, pangoWeight);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isDisposed()
/*     */   {
/* 290 */     return this.handle == 0L;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 301 */     if (isDisposed()) return "Font {*DISPOSED*}";
/* 302 */     return "Font {" + this.handle + "}";
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/graphics/Font.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */