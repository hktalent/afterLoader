/*    */ package org.eclipse.swt.internal.image;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class JPEGComment
/*    */   extends JPEGVariableSizeSegment
/*    */ {
/*    */   public JPEGComment(byte[] reference)
/*    */   {
/* 17 */     super(reference);
/*    */   }
/*    */   
/*    */   public JPEGComment(LEDataInputStream byteStream) {
/* 21 */     super(byteStream);
/*    */   }
/*    */   
/*    */   public int signature()
/*    */   {
/* 26 */     return 65534;
/*    */   }
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/internal/image/JPEGComment.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */