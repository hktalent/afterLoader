/*     */ package org.eclipse.swt.custom;
/*     */ 
/*     */ import org.eclipse.swt.events.TypedEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LineStyleEvent
/*     */   extends TypedEvent
/*     */ {
/*     */   public int lineOffset;
/*     */   public String lineText;
/*     */   public int[] ranges;
/*     */   public StyleRange[] styles;
/*     */   public int alignment;
/*     */   public int indent;
/*     */   public int wrapIndent;
/*     */   public boolean justify;
/*     */   public Bullet bullet;
/*     */   public int bulletIndex;
/*     */   public int[] tabStops;
/*     */   static final long serialVersionUID = 3906081274027192884L;
/*     */   
/*     */   public LineStyleEvent(StyledTextEvent e)
/*     */   {
/* 106 */     super(e);
/* 107 */     this.styles = e.styles;
/* 108 */     this.ranges = e.ranges;
/* 109 */     this.lineOffset = e.detail;
/* 110 */     this.lineText = e.text;
/* 111 */     this.alignment = e.alignment;
/* 112 */     this.justify = e.justify;
/* 113 */     this.indent = e.indent;
/* 114 */     this.wrapIndent = e.wrapIndent;
/* 115 */     this.bullet = e.bullet;
/* 116 */     this.bulletIndex = e.bulletIndex;
/* 117 */     this.tabStops = e.tabStops;
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/custom/LineStyleEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */