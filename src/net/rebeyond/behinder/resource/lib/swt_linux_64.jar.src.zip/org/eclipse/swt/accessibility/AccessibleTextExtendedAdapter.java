package org.eclipse.swt.accessibility;

public class AccessibleTextExtendedAdapter
  extends AccessibleTextAdapter
  implements AccessibleTextExtendedListener
{
  public void addSelection(AccessibleTextEvent e) {}
  
  public void getCharacterCount(AccessibleTextEvent e) {}
  
  public void getHyperlinkCount(AccessibleTextEvent e) {}
  
  public void getHyperlink(AccessibleTextEvent e) {}
  
  public void getHyperlinkIndex(AccessibleTextEvent e) {}
  
  public void getOffsetAtPoint(AccessibleTextEvent e) {}
  
  public void getRanges(AccessibleTextEvent e) {}
  
  public void getSelection(AccessibleTextEvent e) {}
  
  public void getSelectionCount(AccessibleTextEvent e) {}
  
  public void getText(AccessibleTextEvent e) {}
  
  public void getTextBounds(AccessibleTextEvent e) {}
  
  public void getVisibleRanges(AccessibleTextEvent e) {}
  
  public void removeSelection(AccessibleTextEvent e) {}
  
  public void scrollText(AccessibleTextEvent e) {}
  
  public void setCaretOffset(AccessibleTextEvent e) {}
  
  public void setSelection(AccessibleTextEvent e) {}
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/accessibility/AccessibleTextExtendedAdapter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */