package org.eclipse.swt.accessibility;

public abstract class AccessibleControlAdapter
  implements AccessibleControlListener
{
  public void getChildAtPoint(AccessibleControlEvent e) {}
  
  public void getLocation(AccessibleControlEvent e) {}
  
  public void getChild(AccessibleControlEvent e) {}
  
  public void getChildCount(AccessibleControlEvent e) {}
  
  public void getDefaultAction(AccessibleControlEvent e) {}
  
  public void getFocus(AccessibleControlEvent e) {}
  
  public void getRole(AccessibleControlEvent e) {}
  
  public void getSelection(AccessibleControlEvent e) {}
  
  public void getState(AccessibleControlEvent e) {}
  
  public void getValue(AccessibleControlEvent e) {}
  
  public void getChildren(AccessibleControlEvent e) {}
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/accessibility/AccessibleControlAdapter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */