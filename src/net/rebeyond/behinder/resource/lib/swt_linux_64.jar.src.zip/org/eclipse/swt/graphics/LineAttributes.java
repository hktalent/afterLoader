/*     */ package org.eclipse.swt.graphics;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LineAttributes
/*     */ {
/*     */   public float width;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int style;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int cap;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int join;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public float[] dash;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public float dashOffset;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public float miterLimit;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public LineAttributes(float width)
/*     */   {
/*  88 */     this(width, 1, 1, 1, null, 0.0F, 10.0F);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public LineAttributes(float width, int cap, int join)
/*     */   {
/*  99 */     this(width, cap, join, 1, null, 0.0F, 10.0F);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public LineAttributes(float width, int cap, int join, int style, float[] dash, float dashOffset, float miterLimit)
/*     */   {
/* 114 */     this.width = width;
/* 115 */     this.cap = cap;
/* 116 */     this.join = join;
/* 117 */     this.style = style;
/* 118 */     this.dash = dash;
/* 119 */     this.dashOffset = dashOffset;
/* 120 */     this.miterLimit = miterLimit;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object object)
/*     */   {
/* 135 */     if (object == this) return true;
/* 136 */     if (!(object instanceof LineAttributes)) return false;
/* 137 */     LineAttributes p = (LineAttributes)object;
/* 138 */     if (p.width != this.width) return false;
/* 139 */     if (p.cap != this.cap) return false;
/* 140 */     if (p.join != this.join) return false;
/* 141 */     if (p.style != this.style) return false;
/* 142 */     if (p.dashOffset != this.dashOffset) return false;
/* 143 */     if (p.miterLimit != this.miterLimit) return false;
/* 144 */     if ((p.dash != null) && (this.dash != null)) {
/* 145 */       if (p.dash.length != this.dash.length) return false;
/* 146 */       for (int i = 0; i < this.dash.length; i++) {
/* 147 */         if (p.dash[i] != this.dash[i]) return false;
/*     */       }
/*     */     }
/* 150 */     else if ((p.dash != null) || (this.dash != null)) { return false;
/*     */     }
/* 152 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 167 */     int hashCode = Float.floatToIntBits(this.width);
/* 168 */     hashCode = 31 * hashCode + this.cap;
/* 169 */     hashCode = 31 * hashCode + this.join;
/* 170 */     hashCode = 31 * hashCode + this.style;
/* 171 */     hashCode = 31 * hashCode + Float.floatToIntBits(this.dashOffset);
/* 172 */     hashCode = 31 * hashCode + Float.floatToIntBits(this.miterLimit);
/* 173 */     if (this.dash != null) {
/* 174 */       for (int i = 0; i < this.dash.length; i++) {
/* 175 */         hashCode = 31 * hashCode + Float.floatToIntBits(this.dash[i]);
/*     */       }
/*     */     }
/* 178 */     return hashCode;
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/graphics/LineAttributes.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */