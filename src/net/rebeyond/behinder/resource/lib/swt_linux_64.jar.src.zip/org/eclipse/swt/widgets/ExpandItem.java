/*     */ package org.eclipse.swt.widgets;
/*     */ 
/*     */ import org.eclipse.swt.graphics.GC;
/*     */ import org.eclipse.swt.graphics.Image;
/*     */ import org.eclipse.swt.graphics.Point;
/*     */ import org.eclipse.swt.internal.Converter;
/*     */ import org.eclipse.swt.internal.DPIUtil;
/*     */ import org.eclipse.swt.internal.ImageList;
/*     */ import org.eclipse.swt.internal.gtk.GTK;
/*     */ import org.eclipse.swt.internal.gtk.GdkColor;
/*     */ import org.eclipse.swt.internal.gtk.GdkRGBA;
/*     */ import org.eclipse.swt.internal.gtk.GtkAllocation;
/*     */ import org.eclipse.swt.internal.gtk.OS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExpandItem
/*     */   extends Item
/*     */ {
/*     */   ExpandBar parent;
/*     */   Control control;
/*     */   ImageList imageList;
/*     */   long clientHandle;
/*     */   long boxHandle;
/*     */   long labelHandle;
/*     */   long imageHandle;
/*     */   boolean expanded;
/*     */   int x;
/*     */   int y;
/*     */   int width;
/*     */   int height;
/*     */   int imageHeight;
/*     */   int imageWidth;
/*     */   static final int TEXT_INSET = 6;
/*     */   static final int BORDER = 1;
/*     */   static final int CHEVRON_SIZE = 24;
/*     */   
/*     */   public ExpandItem(ExpandBar parent, int style)
/*     */   {
/*  78 */     super(parent, style);
/*  79 */     this.parent = parent;
/*  80 */     createWidget(parent.getItemCount());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ExpandItem(ExpandBar parent, int style, int index)
/*     */   {
/* 114 */     super(parent, style);
/* 115 */     this.parent = parent;
/* 116 */     createWidget(index);
/*     */   }
/*     */   
/*     */   protected void checkSubclass()
/*     */   {
/* 121 */     if (!isValidSubclass()) error(43);
/*     */   }
/*     */   
/*     */   void createHandle(int index)
/*     */   {
/* 126 */     this.state |= 0x8;
/* 127 */     this.handle = GTK.gtk_expander_new(null);
/* 128 */     if (this.handle == 0L) error(2);
/* 129 */     this.clientHandle = OS.g_object_new(this.display.gtk_fixed_get_type(), 0L);
/* 130 */     if (this.clientHandle == 0L) error(2);
/* 131 */     GTK.gtk_container_add(this.handle, this.clientHandle);
/* 132 */     this.boxHandle = gtk_box_new(0, false, 4);
/* 133 */     if (this.boxHandle == 0L) error(2);
/* 134 */     this.labelHandle = GTK.gtk_label_new(null);
/* 135 */     if (this.labelHandle == 0L) error(2);
/* 136 */     this.imageHandle = GTK.gtk_image_new();
/* 137 */     if (this.imageHandle == 0L) error(2);
/* 138 */     GTK.gtk_container_add(this.boxHandle, this.imageHandle);
/* 139 */     GTK.gtk_container_add(this.boxHandle, this.labelHandle);
/* 140 */     GTK.gtk_expander_set_label_widget(this.handle, this.boxHandle);
/* 141 */     GTK.gtk_widget_set_can_focus(this.handle, true);
/*     */   }
/*     */   
/*     */   void createWidget(int index)
/*     */   {
/* 146 */     super.createWidget(index);
/* 147 */     showWidget(index);
/* 148 */     this.parent.createItem(this, this.style, index);
/*     */   }
/*     */   
/*     */   void deregister()
/*     */   {
/* 153 */     super.deregister();
/* 154 */     this.display.removeWidget(this.clientHandle);
/* 155 */     this.display.removeWidget(this.boxHandle);
/* 156 */     this.display.removeWidget(this.labelHandle);
/* 157 */     this.display.removeWidget(this.imageHandle);
/*     */   }
/*     */   
/*     */   void release(boolean destroy)
/*     */   {
/* 162 */     if (GTK.GTK3)
/*     */     {
/*     */ 
/*     */ 
/* 166 */       if ((this.control != null) && (!this.control.isDisposed())) {
/* 167 */         this.control.release(destroy);
/*     */       }
/*     */     }
/* 170 */     super.release(destroy);
/*     */   }
/*     */   
/*     */   void destroyWidget()
/*     */   {
/* 175 */     this.parent.destroyItem(this);
/* 176 */     super.destroyWidget(); }
/*     */   
/*     */   void drawChevron(GC gc, int x, int y) { int[] polyline2;
/*     */     int[] polyline1;
/*     */     int[] polyline2;
/* 181 */     if (this.expanded) {
/* 182 */       int px = x + 4 + 5;
/* 183 */       int py = y + 4 + 7;
/* 184 */       int[] polyline1 = { px, py, px + 1, py, px + 1, py - 1, px + 2, py - 1, px + 2, py - 2, px + 3, py - 2, px + 3, py - 3, px + 3, py - 2, px + 4, py - 2, px + 4, py - 1, px + 5, py - 1, px + 5, py, px + 6, py };
/*     */       
/*     */ 
/* 187 */       py += 4;
/* 188 */       polyline2 = new int[] { px, py, px + 1, py, px + 1, py - 1, px + 2, py - 1, px + 2, py - 2, px + 3, py - 2, px + 3, py - 3, px + 3, py - 2, px + 4, py - 2, px + 4, py - 1, px + 5, py - 1, px + 5, py, px + 6, py };
/*     */     }
/*     */     else
/*     */     {
/* 192 */       int px = x + 4 + 5;
/* 193 */       int py = y + 4 + 4;
/* 194 */       polyline1 = new int[] { px, py, px + 1, py, px + 1, py + 1, px + 2, py + 1, px + 2, py + 2, px + 3, py + 2, px + 3, py + 3, px + 3, py + 2, px + 4, py + 2, px + 4, py + 1, px + 5, py + 1, px + 5, py, px + 6, py };
/*     */       
/*     */ 
/* 197 */       py += 4;
/* 198 */       polyline2 = new int[] { px, py, px + 1, py, px + 1, py + 1, px + 2, py + 1, px + 2, py + 2, px + 3, py + 2, px + 3, py + 3, px + 3, py + 2, px + 4, py + 2, px + 4, py + 1, px + 5, py + 1, px + 5, py, px + 6, py };
/*     */     }
/*     */     
/*     */ 
/* 202 */     gc.setForeground(this.display.getSystemColor(30));
/* 203 */     gc.drawPolyline(DPIUtil.autoScaleDown(polyline1));
/* 204 */     gc.drawPolyline(DPIUtil.autoScaleDown(polyline2));
/*     */   }
/*     */   
/*     */   void drawItem(GC gc, boolean drawFocus) {
/* 208 */     int headerHeight = this.parent.getBandHeight();
/* 209 */     Display display = getDisplay();
/* 210 */     gc.setForeground(display.getSystemColor(31));
/* 211 */     gc.setBackground(display.getSystemColor(32));
/* 212 */     gc.fillGradientRectangle(this.x, this.y, this.width, headerHeight, true);
/* 213 */     if (this.expanded) {
/* 214 */       gc.setForeground(display.getSystemColor(32));
/* 215 */       gc.drawLine(this.x, this.y + headerHeight, this.x, this.y + headerHeight + this.height - 1);
/* 216 */       gc.drawLine(this.x, this.y + headerHeight + this.height - 1, this.x + this.width - 1, this.y + headerHeight + this.height - 1);
/* 217 */       gc.drawLine(this.x + this.width - 1, this.y + headerHeight + this.height - 1, this.x + this.width - 1, this.y + headerHeight);
/*     */     }
/* 219 */     int drawX = this.x;
/* 220 */     if (this.image != null) {
/* 221 */       drawX += 6;
/* 222 */       if (this.imageHeight > headerHeight) {
/* 223 */         gc.drawImage(this.image, drawX, this.y + headerHeight - this.imageHeight);
/*     */       } else {
/* 225 */         gc.drawImage(this.image, drawX, this.y + (headerHeight - this.imageHeight) / 2);
/*     */       }
/* 227 */       drawX += this.imageWidth;
/*     */     }
/* 229 */     if (this.text.length() > 0) {
/* 230 */       drawX += 6;
/* 231 */       Point size = gc.stringExtent(this.text);
/* 232 */       gc.setForeground(this.parent.getForeground());
/* 233 */       gc.drawString(this.text, drawX, this.y + (headerHeight - size.y) / 2, true);
/*     */     }
/* 235 */     int chevronSize = 24;
/* 236 */     drawChevron(gc, this.x + this.width - chevronSize, this.y + (headerHeight - chevronSize) / 2);
/* 237 */     if (drawFocus) {
/* 238 */       gc.drawFocus(this.x + 1, this.y + 1, this.width - 2, headerHeight - 2);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Control getControl()
/*     */   {
/* 254 */     checkWidget();
/* 255 */     return this.control;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getExpanded()
/*     */   {
/* 270 */     checkWidget();
/* 271 */     return this.expanded;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getHeaderHeight()
/*     */   {
/* 285 */     checkWidget();
/* 286 */     return DPIUtil.autoScaleDown(getHeaderHeightInPixels());
/*     */   }
/*     */   
/*     */   int getHeaderHeightInPixels() {
/* 290 */     checkWidget();
/* 291 */     GtkAllocation allocation = new GtkAllocation();
/* 292 */     GTK.gtk_widget_get_allocation(this.handle, allocation);
/*     */     
/*     */ 
/*     */ 
/* 296 */     int headerHeight = allocation.height - (this.expanded ? this.height : 0);
/* 297 */     if ((this.expanded) && (headerHeight < 0)) {
/* 298 */       return allocation.height;
/*     */     }
/* 300 */     return headerHeight;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getHeight()
/*     */   {
/* 313 */     checkWidget();
/* 314 */     return DPIUtil.autoScaleDown(getHeightInPixels());
/*     */   }
/*     */   
/*     */   int getHeightInPixels() {
/* 318 */     checkWidget();
/* 319 */     return this.height;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ExpandBar getParent()
/*     */   {
/* 333 */     checkWidget();
/* 334 */     return this.parent;
/*     */   }
/*     */   
/*     */   int getPreferredWidth(GC gc) {
/* 338 */     int width = 36;
/* 339 */     if (this.image != null) {
/* 340 */       width += 6 + this.imageWidth;
/*     */     }
/* 342 */     if (this.text.length() > 0) {
/* 343 */       width += gc.stringExtent(this.text).x;
/*     */     }
/* 345 */     return width;
/*     */   }
/*     */   
/*     */   long gtk_activate(long widget)
/*     */   {
/* 350 */     Event event = new Event();
/* 351 */     event.item = this;
/* 352 */     int type = GTK.gtk_expander_get_expanded(this.handle) ? 18 : 17;
/* 353 */     this.parent.sendEvent(type, event);
/* 354 */     return 0L;
/*     */   }
/*     */   
/*     */   long gtk_button_press_event(long widget, long event)
/*     */   {
/* 359 */     setFocus();
/* 360 */     return 0L;
/*     */   }
/*     */   
/*     */   long gtk_focus_out_event(long widget, long event)
/*     */   {
/* 365 */     GTK.gtk_widget_set_can_focus(this.handle, false);
/* 366 */     this.parent.lastFocus = this;
/* 367 */     return 0L;
/*     */   }
/*     */   
/*     */   long gtk_size_allocate(long widget, long allocation)
/*     */   {
/* 372 */     this.parent.layoutItems(0, false);
/* 373 */     return 0L;
/*     */   }
/*     */   
/*     */   long gtk_enter_notify_event(long widget, long event)
/*     */   {
/* 378 */     this.parent.gtk_enter_notify_event(widget, event);
/* 379 */     return 0L;
/*     */   }
/*     */   
/*     */   boolean hasFocus() {
/* 383 */     return GTK.gtk_widget_has_focus(this.handle);
/*     */   }
/*     */   
/*     */   void hookEvents()
/*     */   {
/* 388 */     super.hookEvents();
/* 389 */     OS.g_signal_connect_closure(this.handle, OS.activate, this.display.getClosure(1), false);
/* 390 */     OS.g_signal_connect_closure(this.handle, OS.activate, this.display.getClosure(60), true);
/* 391 */     OS.g_signal_connect_closure_by_id(this.handle, this.display.signalIds[2], 0, this.display.getClosure(2), false);
/* 392 */     OS.g_signal_connect_closure_by_id(this.handle, this.display.signalIds[22], 0, this.display.getClosure(22), false);
/* 393 */     OS.g_signal_connect_closure(this.clientHandle, OS.size_allocate, this.display.getClosure(47), true);
/* 394 */     OS.g_signal_connect_closure_by_id(this.handle, this.display.signalIds[14], 0, this.display.getClosure(14), false);
/*     */   }
/*     */   
/*     */ 
/*     */   void redraw() {}
/*     */   
/*     */   void register()
/*     */   {
/* 402 */     super.register();
/* 403 */     this.display.addWidget(this.clientHandle, this);
/* 404 */     this.display.addWidget(this.boxHandle, this);
/* 405 */     this.display.addWidget(this.labelHandle, this);
/* 406 */     this.display.addWidget(this.imageHandle, this);
/*     */   }
/*     */   
/*     */   void releaseHandle()
/*     */   {
/* 411 */     super.releaseHandle();
/* 412 */     this.clientHandle = (this.boxHandle = this.labelHandle = this.imageHandle = 0L);
/* 413 */     this.parent = null;
/*     */   }
/*     */   
/*     */   void releaseWidget()
/*     */   {
/* 418 */     super.releaseWidget();
/* 419 */     if (this.imageList != null) this.imageList.dispose();
/* 420 */     if (this.parent.lastFocus == this) this.parent.lastFocus = null;
/* 421 */     this.imageList = null;
/* 422 */     this.control = null;
/*     */   }
/*     */   
/*     */   void resizeControl(int yScroll) {
/* 426 */     if ((this.control != null) && (!this.control.isDisposed())) {
/* 427 */       boolean visible = GTK.gtk_expander_get_expanded(this.handle);
/* 428 */       if (visible) {
/* 429 */         GtkAllocation allocation = new GtkAllocation();
/* 430 */         GTK.gtk_widget_get_allocation(this.clientHandle, allocation);
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 441 */         int x = GTK.GTK3 ? 0 : allocation.x;
/* 442 */         int y = GTK.GTK3 ? 0 : allocation.y;
/*     */         
/* 444 */         if ((x != -1) && (y != -1)) {
/* 445 */           int width = allocation.width;
/* 446 */           int height = allocation.height;
/* 447 */           int[] property = new int[1];
/* 448 */           GTK.gtk_widget_style_get(this.handle, OS.focus_line_width, property, 0L);
/* 449 */           y += property[0] * 2;
/* 450 */           height -= property[0] * 2;
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 460 */           ScrollBar vBar = this.parent.verticalBar;
/* 461 */           if ((vBar != null) && 
/* 462 */             (GTK.gtk_widget_get_visible(vBar.handle))) {
/* 463 */             GTK.gtk_widget_get_allocation(this.parent.scrolledHandle, allocation);
/* 464 */             width = allocation.width - this.parent.vScrollBarWidth() - 2 * this.parent.spacing;
/*     */           }
/*     */           
/*     */ 
/* 468 */           if (GTK.GTK3) {
/* 469 */             this.control.setBounds(x, y, width, Math.max(0, height), true, true);
/*     */           }
/*     */           else {
/* 472 */             this.control.setBounds(x, y - yScroll, width, Math.max(0, height), true, true);
/*     */           }
/*     */         }
/*     */       }
/* 476 */       this.control.setVisible(visible);
/*     */     }
/*     */   }
/*     */   
/*     */   void setBounds(int x, int y, int width, int height, boolean move, boolean size) {
/* 481 */     redraw();
/* 482 */     int headerHeight = this.parent.getBandHeight();
/* 483 */     if (move) {
/* 484 */       if (this.imageHeight > headerHeight) {
/* 485 */         y += this.imageHeight - headerHeight;
/*     */       }
/* 487 */       this.x = x;
/* 488 */       this.y = y;
/* 489 */       redraw();
/*     */     }
/* 491 */     if (size) {
/* 492 */       this.width = width;
/* 493 */       this.height = height;
/* 494 */       redraw();
/*     */     }
/* 496 */     if ((this.control != null) && (!this.control.isDisposed())) {
/* 497 */       if (move) this.control.setLocationInPixels(x + 1, y + headerHeight);
/* 498 */       if (size) { this.control.setSizeInPixels(Math.max(0, width - 2), Math.max(0, height - 1));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setControl(Control control)
/*     */   {
/* 517 */     checkWidget();
/* 518 */     if (control != null) {
/* 519 */       if (control.isDisposed()) error(5);
/* 520 */       if (control.parent != this.parent) error(32);
/*     */     }
/* 522 */     if (this.control == control) { return;
/*     */     }
/*     */     
/* 525 */     this.control = control;
/* 526 */     if (control != null) {
/* 527 */       control.setVisible(this.expanded);
/* 528 */       if (GTK.GTK3)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 535 */         Control.gtk_widget_reparent(control, clientHandle());
/*     */       }
/*     */     }
/* 538 */     this.parent.layoutItems(0, true);
/*     */   }
/*     */   
/*     */   long clientHandle() {
/* 542 */     return this.clientHandle;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setExpanded(boolean expanded)
/*     */   {
/* 557 */     checkWidget();
/* 558 */     this.expanded = expanded;
/* 559 */     GTK.gtk_expander_set_expanded(this.handle, expanded);
/* 560 */     this.parent.layoutItems(0, true);
/*     */   }
/*     */   
/*     */   boolean setFocus() {
/* 564 */     if (!GTK.gtk_widget_get_child_visible(this.handle)) return false;
/* 565 */     GTK.gtk_widget_set_can_focus(this.handle, true);
/* 566 */     GTK.gtk_widget_grab_focus(this.handle);
/*     */     
/* 568 */     if (isDisposed()) return false;
/* 569 */     boolean result = GTK.gtk_widget_is_focus(this.handle);
/* 570 */     if (!result) GTK.gtk_widget_set_can_focus(this.handle, false);
/* 571 */     return result;
/*     */   }
/*     */   
/*     */   void setFontDescription(long font) {
/* 575 */     setFontDescription(this.handle, font);
/* 576 */     if (this.labelHandle != 0L) setFontDescription(this.labelHandle, font);
/* 577 */     if (this.imageHandle != 0L) setFontDescription(this.imageHandle, font);
/*     */   }
/*     */   
/*     */   void setForegroundColor(GdkColor color) {
/* 581 */     assert (!GTK.GTK3) : "GTK2 code was run by GTK3";
/* 582 */     setForegroundColor(this.handle, color);
/* 583 */     if (this.labelHandle != 0L) setForegroundColor(this.labelHandle, color);
/* 584 */     if (this.imageHandle != 0L) setForegroundColor(this.imageHandle, color);
/*     */   }
/*     */   
/*     */   void setForegroundRGBA(GdkRGBA rgba) {
/* 588 */     assert (GTK.GTK3) : "GTK3 code was run by GTK2";
/* 589 */     this.parent.setForegroundGdkRGBA(this.handle, rgba);
/* 590 */     if (this.labelHandle != 0L) this.parent.setForegroundGdkRGBA(this.labelHandle, rgba);
/* 591 */     if (this.imageHandle != 0L) { this.parent.setForegroundGdkRGBA(this.imageHandle, rgba);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setHeight(int height)
/*     */   {
/* 606 */     checkWidget();
/* 607 */     setHeightInPixels(DPIUtil.autoScaleUp(height));
/*     */   }
/*     */   
/*     */   void setHeightInPixels(int height) {
/* 611 */     checkWidget();
/* 612 */     if (height < 0) return;
/* 613 */     this.height = height;
/* 614 */     GTK.gtk_widget_set_size_request(this.clientHandle, -1, height);
/* 615 */     this.parent.layoutItems(0, false);
/*     */   }
/*     */   
/*     */   public void setImage(Image image)
/*     */   {
/* 620 */     super.setImage(image);
/* 621 */     if (this.imageList != null) this.imageList.dispose();
/* 622 */     this.imageList = null;
/* 623 */     if (image != null) {
/* 624 */       if (image.isDisposed()) error(5);
/* 625 */       this.imageList = new ImageList();
/* 626 */       int imageIndex = this.imageList.add(image);
/* 627 */       long pixbuf = this.imageList.getPixbuf(imageIndex);
/* 628 */       gtk_image_set_from_pixbuf(this.imageHandle, pixbuf);
/* 629 */       if (this.text.length() == 0) GTK.gtk_widget_hide(this.labelHandle);
/* 630 */       GTK.gtk_widget_show(this.imageHandle);
/*     */     } else {
/* 632 */       gtk_image_set_from_pixbuf(this.imageHandle, 0L);
/* 633 */       GTK.gtk_widget_show(this.labelHandle);
/* 634 */       GTK.gtk_widget_hide(this.imageHandle);
/*     */     }
/*     */   }
/*     */   
/*     */   void setOrientation(boolean create)
/*     */   {
/* 640 */     super.setOrientation(create);
/* 641 */     if (((this.parent.style & 0x4000000) != 0) || (!create)) {
/* 642 */       int dir = (this.parent.style & 0x4000000) != 0 ? 2 : 1;
/* 643 */       GTK.gtk_widget_set_direction(this.handle, dir);
/* 644 */       GTK.gtk_container_forall(this.handle, this.display.setDirectionProc, dir);
/*     */     }
/*     */   }
/*     */   
/*     */   public void setText(String string)
/*     */   {
/* 650 */     super.setText(string);
/* 651 */     byte[] buffer = Converter.wcsToMbcs(string, true);
/* 652 */     GTK.gtk_label_set_text(this.labelHandle, buffer);
/*     */   }
/*     */   
/*     */   void showWidget(int index) {
/* 656 */     GTK.gtk_widget_show(this.handle);
/* 657 */     GTK.gtk_widget_show(this.clientHandle);
/* 658 */     if (this.labelHandle != 0L)
/* 659 */       GTK.gtk_widget_show(this.labelHandle);
/* 660 */     if (this.boxHandle != 0L)
/* 661 */       GTK.gtk_widget_show(this.boxHandle);
/* 662 */     GTK.gtk_container_add(this.parent.handle, this.handle);
/* 663 */     GTK.gtk_box_set_child_packing(this.parent.handle, this.handle, false, false, 0, 0);
/*     */   }
/*     */   
/*     */   long windowProc(long handle, long user_data)
/*     */   {
/* 668 */     switch ((int)user_data) {
/*     */     case 60: 
/* 670 */       this.expanded = GTK.gtk_expander_get_expanded(handle);
/* 671 */       this.parent.layoutItems(0, false);
/* 672 */       return 0L;
/*     */     }
/*     */     
/* 675 */     return super.windowProc(handle, user_data);
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/widgets/ExpandItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */