/*    */ package org.eclipse.swt.internal.gtk;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GdkWindowAttr
/*    */ {
/*    */   public long title;
/*    */   
/*    */ 
/*    */   public int event_mask;
/*    */   
/*    */ 
/*    */   public int x;
/*    */   
/*    */ 
/*    */   public int y;
/*    */   
/*    */   public int width;
/*    */   
/*    */   public int height;
/*    */   
/*    */   public int wclass;
/*    */   
/*    */   public long visual;
/*    */   
/*    */   public long colormap;
/*    */   
/*    */   public int window_type;
/*    */   
/*    */   public long cursor;
/*    */   
/*    */   public long wmclass_name;
/*    */   
/*    */   public long wmclass_class;
/*    */   
/*    */   public boolean override_redirect;
/*    */   
/* 38 */   public static final int sizeof = ;
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/internal/gtk/GdkWindowAttr.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */