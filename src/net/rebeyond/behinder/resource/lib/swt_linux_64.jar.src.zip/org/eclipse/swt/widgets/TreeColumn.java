/*     */ package org.eclipse.swt.widgets;
/*     */ 
/*     */ import org.eclipse.swt.events.ControlListener;
/*     */ import org.eclipse.swt.events.SelectionListener;
/*     */ import org.eclipse.swt.graphics.Image;
/*     */ import org.eclipse.swt.internal.Converter;
/*     */ import org.eclipse.swt.internal.DPIUtil;
/*     */ import org.eclipse.swt.internal.ImageList;
/*     */ import org.eclipse.swt.internal.gtk.GDK;
/*     */ import org.eclipse.swt.internal.gtk.GTK;
/*     */ import org.eclipse.swt.internal.gtk.GdkEvent;
/*     */ import org.eclipse.swt.internal.gtk.GdkEventButton;
/*     */ import org.eclipse.swt.internal.gtk.GtkAllocation;
/*     */ import org.eclipse.swt.internal.gtk.GtkRequisition;
/*     */ import org.eclipse.swt.internal.gtk.OS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TreeColumn
/*     */   extends Item
/*     */ {
/*     */   long labelHandle;
/*     */   long imageHandle;
/*     */   long buttonHandle;
/*     */   Tree parent;
/*     */   int modelIndex;
/*     */   int lastButton;
/*     */   int lastTime;
/*     */   int lastX;
/*     */   int lastWidth;
/*     */   boolean customDraw;
/*     */   boolean useFixedWidth;
/*     */   String toolTipText;
/*     */   
/*     */   public TreeColumn(Tree parent, int style)
/*     */   {
/*  80 */     super(parent, checkStyle(style));
/*  81 */     this.parent = parent;
/*  82 */     createWidget(parent.getColumnCount());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TreeColumn(Tree parent, int style, int index)
/*     */   {
/* 123 */     super(parent, checkStyle(style));
/* 124 */     this.parent = parent;
/* 125 */     createWidget(index);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addControlListener(ControlListener listener)
/*     */   {
/* 148 */     checkWidget();
/* 149 */     if (listener == null) error(4);
/* 150 */     TypedListener typedListener = new TypedListener(listener);
/* 151 */     addListener(11, typedListener);
/* 152 */     addListener(10, typedListener);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addSelectionListener(SelectionListener listener)
/*     */   {
/* 180 */     checkWidget();
/* 181 */     if (listener == null) error(4);
/* 182 */     TypedListener typedListener = new TypedListener(listener);
/* 183 */     addListener(13, typedListener);
/* 184 */     addListener(14, typedListener);
/*     */   }
/*     */   
/*     */   static int checkStyle(int style) {
/* 188 */     return checkBits(style, 16384, 16777216, 131072, 0, 0, 0);
/*     */   }
/*     */   
/*     */   protected void checkSubclass()
/*     */   {
/* 193 */     if (!isValidSubclass()) error(43);
/*     */   }
/*     */   
/*     */   void createWidget(int index)
/*     */   {
/* 198 */     this.parent.createItem(this, index);
/* 199 */     setOrientation(true);
/* 200 */     hookEvents();
/* 201 */     register();
/* 202 */     this.text = "";
/*     */   }
/*     */   
/*     */   void deregister()
/*     */   {
/* 207 */     super.deregister();
/* 208 */     this.display.removeWidget(this.handle);
/* 209 */     if (this.buttonHandle != 0L) this.display.removeWidget(this.buttonHandle);
/* 210 */     if (this.labelHandle != 0L) this.display.removeWidget(this.labelHandle);
/*     */   }
/*     */   
/*     */   void destroyWidget()
/*     */   {
/* 215 */     this.parent.destroyItem(this);
/* 216 */     releaseHandle();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getAlignment()
/*     */   {
/* 232 */     checkWidget();
/* 233 */     if ((this.style & 0x4000) != 0) return 16384;
/* 234 */     if ((this.style & 0x1000000) != 0) return 16777216;
/* 235 */     if ((this.style & 0x20000) != 0) return 131072;
/* 236 */     return 16384;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getMoveable()
/*     */   {
/* 260 */     checkWidget();
/* 261 */     return GTK.gtk_tree_view_column_get_reorderable(this.handle);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Tree getParent()
/*     */   {
/* 275 */     checkWidget();
/* 276 */     return this.parent;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getResizable()
/*     */   {
/* 292 */     checkWidget();
/* 293 */     return GTK.gtk_tree_view_column_get_resizable(this.handle);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getToolTipText()
/*     */   {
/* 310 */     checkWidget();
/* 311 */     return this.toolTipText;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getWidth()
/*     */   {
/* 325 */     checkWidget();
/* 326 */     return DPIUtil.autoScaleDown(getWidthInPixels());
/*     */   }
/*     */   
/*     */   int getWidthInPixels() {
/* 330 */     checkWidget();
/* 331 */     if (!GTK.gtk_tree_view_column_get_visible(this.handle)) {
/* 332 */       return 0;
/*     */     }
/* 334 */     if (this.useFixedWidth) return GTK.gtk_tree_view_column_get_fixed_width(this.handle);
/* 335 */     return GTK.gtk_tree_view_column_get_width(this.handle);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   long gtk_clicked(long widget)
/*     */   {
/* 347 */     boolean doubleClick = false;
/* 348 */     boolean postEvent = true;
/* 349 */     long eventPtr = GTK.gtk_get_current_event();
/* 350 */     if (eventPtr != 0L) {
/* 351 */       GdkEventButton gdkEvent = new GdkEventButton();
/* 352 */       OS.memmove(gdkEvent, eventPtr, GdkEventButton.sizeof);
/* 353 */       GDK.gdk_event_free(eventPtr);
/* 354 */       switch (gdkEvent.type) {
/*     */       case 7: 
/* 356 */         int clickTime = this.display.getDoubleClickTime();
/* 357 */         int eventTime = gdkEvent.time;int eventButton = gdkEvent.button;
/* 358 */         if ((this.lastButton == eventButton) && (this.lastTime != 0) && (Math.abs(this.lastTime - eventTime) <= clickTime)) {
/* 359 */           doubleClick = true;
/*     */         }
/* 361 */         this.lastTime = (eventTime == 0 ? 1 : eventTime);
/* 362 */         this.lastButton = eventButton;
/* 363 */         break;
/*     */       }
/*     */       
/*     */     }
/* 367 */     if (postEvent) sendSelectionEvent(doubleClick ? 14 : 13);
/* 368 */     return 0L;
/*     */   }
/*     */   
/*     */   long gtk_event_after(long widget, long gdkEvent)
/*     */   {
/* 373 */     GdkEvent event = new GdkEvent();
/* 374 */     OS.memmove(event, gdkEvent, GdkEvent.sizeof);
/* 375 */     switch (event.type) {
/*     */     case 4: 
/* 377 */       GdkEventButton gdkEventButton = new GdkEventButton();
/* 378 */       OS.memmove(gdkEventButton, gdkEvent, GdkEventButton.sizeof);
/* 379 */       if (gdkEventButton.button == 3) {
/* 380 */         this.parent.showMenu((int)gdkEventButton.x_root, (int)gdkEventButton.y_root);
/*     */       }
/*     */       break;
/*     */     }
/*     */     
/* 385 */     return 0L;
/*     */   }
/*     */   
/*     */   long gtk_mnemonic_activate(long widget, long arg1)
/*     */   {
/* 390 */     return this.parent.gtk_mnemonic_activate(widget, arg1);
/*     */   }
/*     */   
/*     */   long gtk_size_allocate(long widget, long allocation)
/*     */   {
/* 395 */     this.useFixedWidth = false;
/* 396 */     GtkAllocation widgetAllocation = new GtkAllocation();
/* 397 */     GTK.gtk_widget_get_allocation(widget, widgetAllocation);
/* 398 */     int x = widgetAllocation.x;
/* 399 */     int width = widgetAllocation.width;
/* 400 */     if (x != this.lastX) {
/* 401 */       this.lastX = x;
/* 402 */       sendEvent(10);
/*     */     }
/* 404 */     if (width != this.lastWidth) {
/* 405 */       this.lastWidth = width;
/* 406 */       sendEvent(11);
/*     */     }
/* 408 */     return 0L;
/*     */   }
/*     */   
/*     */   void hookEvents()
/*     */   {
/* 413 */     super.hookEvents();
/* 414 */     OS.g_signal_connect_closure(this.handle, OS.clicked, this.display.getClosure(8), false);
/* 415 */     if (this.buttonHandle != 0L) {
/* 416 */       OS.g_signal_connect_closure_by_id(this.buttonHandle, this.display.signalIds[47], 0, this.display.getClosure(47), false);
/* 417 */       OS.g_signal_connect_closure_by_id(this.buttonHandle, this.display.signalIds[16], 0, this.display.getClosure(16), false);
/*     */     }
/* 419 */     if (this.labelHandle != 0L) { OS.g_signal_connect_closure_by_id(this.labelHandle, this.display.signalIds[32], 0, this.display.getClosure(32), false);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void pack()
/*     */   {
/* 434 */     checkWidget();
/* 435 */     int width = 0;
/* 436 */     if (this.buttonHandle != 0L) {
/* 437 */       GtkRequisition requisition = new GtkRequisition();
/* 438 */       gtk_widget_get_preferred_size(this.buttonHandle, requisition);
/* 439 */       width = requisition.width;
/*     */     }
/* 441 */     if ((this.parent.style & 0x10000000) != 0) {
/* 442 */       for (int i = 0; i < this.parent.items.length; i++) {
/* 443 */         TreeItem item = this.parent.items[i];
/* 444 */         if ((item != null) && (item.cached)) {
/* 445 */           width = Math.max(width, this.parent.calculateWidth(this.handle, item.handle, true));
/*     */         }
/*     */       }
/*     */     } else {
/* 449 */       long iter = OS.g_malloc(GTK.GtkTreeIter_sizeof());
/* 450 */       if (GTK.gtk_tree_model_get_iter_first(this.parent.modelHandle, iter)) {
/*     */         do {
/* 452 */           width = Math.max(width, this.parent.calculateWidth(this.handle, iter, true));
/* 453 */         } while (GTK.gtk_tree_model_iter_next(this.parent.modelHandle, iter));
/*     */       }
/* 455 */       OS.g_free(iter);
/*     */     }
/* 457 */     setWidthInPixels(width);
/*     */   }
/*     */   
/*     */   void register()
/*     */   {
/* 462 */     super.register();
/* 463 */     this.display.addWidget(this.handle, this);
/* 464 */     if (this.buttonHandle != 0L) this.display.addWidget(this.buttonHandle, this);
/* 465 */     if (this.labelHandle != 0L) this.display.addWidget(this.labelHandle, this);
/*     */   }
/*     */   
/*     */   void releaseHandle()
/*     */   {
/* 470 */     super.releaseHandle();
/* 471 */     this.handle = (this.buttonHandle = this.labelHandle = this.imageHandle = 0L);
/* 472 */     this.modelIndex = -1;
/* 473 */     this.parent = null;
/*     */   }
/*     */   
/*     */   void releaseParent()
/*     */   {
/* 478 */     super.releaseParent();
/* 479 */     if (this.parent.sortColumn == this) {
/* 480 */       this.parent.sortColumn = null;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeControlListener(ControlListener listener)
/*     */   {
/* 502 */     checkWidget();
/* 503 */     if (listener == null) error(4);
/* 504 */     if (this.eventTable == null) return;
/* 505 */     this.eventTable.unhook(10, listener);
/* 506 */     this.eventTable.unhook(11, listener);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeSelectionListener(SelectionListener listener)
/*     */   {
/* 527 */     checkWidget();
/* 528 */     if (listener == null) error(4);
/* 529 */     if (this.eventTable == null) return;
/* 530 */     this.eventTable.unhook(13, listener);
/* 531 */     this.eventTable.unhook(14, listener);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAlignment(int alignment)
/*     */   {
/* 550 */     checkWidget();
/* 551 */     if ((alignment & 0x1024000) == 0) return;
/* 552 */     int index = this.parent.indexOf(this);
/* 553 */     if ((index == -1) || (index == 0)) return;
/* 554 */     this.style &= 0xFEFDBFFF;
/* 555 */     this.style |= alignment & 0x1024000;
/* 556 */     this.parent.createRenderers(this.handle, this.modelIndex, index == 0, this.style);
/*     */   }
/*     */   
/*     */   void setFontDescription(long font) {
/* 560 */     setFontDescription(this.labelHandle, font);
/* 561 */     setFontDescription(this.imageHandle, font);
/*     */   }
/*     */   
/*     */   public void setImage(Image image)
/*     */   {
/* 566 */     checkWidget();
/* 567 */     super.setImage(image);
/* 568 */     if (image != null) {
/* 569 */       ImageList headerImageList = this.parent.headerImageList;
/* 570 */       if (headerImageList == null) {
/* 571 */         headerImageList = this.parent.headerImageList = new ImageList();
/*     */       }
/* 573 */       int imageIndex = headerImageList.indexOf(image);
/* 574 */       if (imageIndex == -1) imageIndex = headerImageList.add(image);
/* 575 */       long pixbuf = headerImageList.getPixbuf(imageIndex);
/* 576 */       gtk_image_set_from_pixbuf(this.imageHandle, pixbuf);
/* 577 */       GTK.gtk_widget_show(this.imageHandle);
/*     */     } else {
/* 579 */       gtk_image_set_from_pixbuf(this.imageHandle, 0L);
/* 580 */       GTK.gtk_widget_hide(this.imageHandle);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMoveable(boolean moveable)
/*     */   {
/* 606 */     checkWidget();
/* 607 */     GTK.gtk_tree_view_column_set_reorderable(this.handle, moveable);
/*     */   }
/*     */   
/*     */   void setOrientation(boolean create)
/*     */   {
/* 612 */     if ((((this.parent.style & 0x4000000) != 0) || (!create)) && 
/* 613 */       (this.buttonHandle != 0L)) {
/* 614 */       int dir = (this.parent.style & 0x4000000) != 0 ? 2 : 1;
/* 615 */       GTK.gtk_widget_set_direction(this.buttonHandle, dir);
/* 616 */       GTK.gtk_container_forall(this.buttonHandle, this.display.setDirectionProc, dir);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setResizable(boolean resizable)
/*     */   {
/* 634 */     checkWidget();
/* 635 */     GTK.gtk_tree_view_column_set_resizable(this.handle, resizable);
/*     */   }
/*     */   
/*     */   public void setText(String string)
/*     */   {
/* 640 */     checkWidget();
/* 641 */     if (string == null) error(4);
/* 642 */     super.setText(string);
/* 643 */     char[] chars = fixMnemonic(string);
/* 644 */     byte[] buffer = Converter.wcsToMbcs(chars, true);
/* 645 */     GTK.gtk_label_set_text_with_mnemonic(this.labelHandle, buffer);
/* 646 */     if (string.length() != 0) {
/* 647 */       GTK.gtk_widget_show(this.labelHandle);
/*     */     } else {
/* 649 */       GTK.gtk_widget_hide(this.labelHandle);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setToolTipText(String string)
/*     */   {
/* 681 */     checkWidget();
/* 682 */     Shell shell = this.parent._getShell();
/* 683 */     setToolTipText(shell, string);
/* 684 */     this.toolTipText = string;
/*     */   }
/*     */   
/*     */   void setToolTipText(Shell shell, String newString) {
/* 688 */     shell.setToolTipText(this.buttonHandle, newString);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setWidth(int width)
/*     */   {
/* 702 */     checkWidget();
/* 703 */     setWidthInPixels(DPIUtil.autoScaleUp(width));
/*     */   }
/*     */   
/*     */   void setWidthInPixels(int width) {
/* 707 */     checkWidget();
/* 708 */     if (width < 0) return;
/* 709 */     if (width == this.lastWidth) return;
/* 710 */     if (width > 0) {
/* 711 */       this.useFixedWidth = true;
/* 712 */       GTK.gtk_tree_view_column_set_fixed_width(this.handle, width);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 719 */     if (width != 0) GTK.gtk_widget_realize(this.parent.handle);
/* 720 */     GTK.gtk_tree_view_column_set_visible(this.handle, width != 0);
/* 721 */     this.lastWidth = width;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 729 */     if ((width != 0) && 
/* 730 */       (this.buttonHandle != 0L)) {
/* 731 */       long window = GTK.gtk_widget_get_parent_window(this.buttonHandle);
/* 732 */       if (window != 0L) {
/* 733 */         long windowList = GDK.gdk_window_get_children(window);
/* 734 */         if (windowList != 0L) {
/* 735 */           long windows = windowList;
/* 736 */           long[] userData = new long[1];
/* 737 */           while (windows != 0L) {
/* 738 */             long child = OS.g_list_data(windows);
/* 739 */             GDK.gdk_window_get_user_data(child, userData);
/* 740 */             if (userData[0] == this.buttonHandle) {
/* 741 */               GDK.gdk_window_lower(child);
/* 742 */               break;
/*     */             }
/* 744 */             windows = OS.g_list_next(windows);
/*     */           }
/* 746 */           OS.g_list_free(windowList);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 751 */     sendEvent(11);
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/widgets/TreeColumn.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */