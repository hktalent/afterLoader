/*    */ package org.eclipse.swt.widgets;
/*    */ 
/*    */ import org.eclipse.swt.graphics.Point;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class Layout
/*    */ {
/*    */   protected abstract Point computeSize(Composite paramComposite, int paramInt1, int paramInt2, boolean paramBoolean);
/*    */   
/*    */   protected boolean flushCache(Control control)
/*    */   {
/* 72 */     return false;
/*    */   }
/*    */   
/*    */   protected abstract void layout(Composite paramComposite, boolean paramBoolean);
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/widgets/Layout.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */