/*     */ package org.eclipse.swt.graphics;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import org.eclipse.swt.SWT;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class RGBA
/*     */   implements Serializable
/*     */ {
/*     */   public final RGB rgb;
/*     */   public int alpha;
/*     */   static final long serialVersionUID = 1049467103126495855L;
/*     */   
/*     */   public RGBA(int red, int green, int blue, int alpha)
/*     */   {
/*  70 */     if ((alpha > 255) || (alpha < 0)) SWT.error(5);
/*  71 */     this.rgb = new RGB(red, green, blue);
/*  72 */     this.alpha = alpha;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RGBA(float hue, float saturation, float brightness, float alpha)
/*     */   {
/*  92 */     if ((alpha > 255.0F) || (alpha < 0.0F)) SWT.error(5);
/*  93 */     this.rgb = new RGB(hue, saturation, brightness);
/*  94 */     this.alpha = ((int)(alpha + 0.5D));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public float[] getHSBA()
/*     */   {
/* 109 */     float[] hsb = this.rgb.getHSB();
/* 110 */     return new float[] { hsb[0], hsb[1], hsb[2], this.alpha };
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object object)
/*     */   {
/* 125 */     if (object == this) return true;
/* 126 */     if (!(object instanceof RGBA)) return false;
/* 127 */     RGBA rgba = (RGBA)object;
/* 128 */     return (rgba.rgb.red == this.rgb.red) && (rgba.rgb.green == this.rgb.green) && (rgba.rgb.blue == this.rgb.blue) && (rgba.alpha == this.alpha);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 144 */     return this.alpha << 24 | this.rgb.blue << 16 | this.rgb.green << 8 | this.rgb.red;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 155 */     return "RGBA {" + this.rgb.red + ", " + this.rgb.green + ", " + this.rgb.blue + ", " + this.alpha + "}";
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/graphics/RGBA.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */