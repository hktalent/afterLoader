/*     */ package org.eclipse.swt.internal.image;
/*     */ 
/*     */ import org.eclipse.swt.SWT;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class JPEGFrameHeader
/*     */   extends JPEGVariableSizeSegment
/*     */ {
/*     */   int maxVFactor;
/*     */   int maxHFactor;
/*     */   public int[] componentIdentifiers;
/*     */   public int[][] componentParameters;
/*     */   
/*     */   public JPEGFrameHeader(byte[] reference)
/*     */   {
/*  23 */     super(reference);
/*     */   }
/*     */   
/*     */   public JPEGFrameHeader(LEDataInputStream byteStream) {
/*  27 */     super(byteStream);
/*  28 */     initializeComponentParameters();
/*     */   }
/*     */   
/*     */   public int getSamplePrecision() {
/*  32 */     return this.reference[4] & 0xFF;
/*     */   }
/*     */   
/*     */   public int getNumberOfLines() {
/*  36 */     return (this.reference[5] & 0xFF) << 8 | this.reference[6] & 0xFF;
/*     */   }
/*     */   
/*     */   public int getSamplesPerLine() {
/*  40 */     return (this.reference[7] & 0xFF) << 8 | this.reference[8] & 0xFF;
/*     */   }
/*     */   
/*     */   public int getNumberOfImageComponents() {
/*  44 */     return this.reference[9] & 0xFF;
/*     */   }
/*     */   
/*     */   public void setSamplePrecision(int precision) {
/*  48 */     this.reference[4] = ((byte)(precision & 0xFF));
/*     */   }
/*     */   
/*     */   public void setNumberOfLines(int anInteger) {
/*  52 */     this.reference[5] = ((byte)((anInteger & 0xFF00) >> 8));
/*  53 */     this.reference[6] = ((byte)(anInteger & 0xFF));
/*     */   }
/*     */   
/*     */   public void setSamplesPerLine(int samples) {
/*  57 */     this.reference[7] = ((byte)((samples & 0xFF00) >> 8));
/*  58 */     this.reference[8] = ((byte)(samples & 0xFF));
/*     */   }
/*     */   
/*     */   public void setNumberOfImageComponents(int anInteger) {
/*  62 */     this.reference[9] = ((byte)(anInteger & 0xFF));
/*     */   }
/*     */   
/*     */   public int getMaxHFactor() {
/*  66 */     return this.maxHFactor;
/*     */   }
/*     */   
/*     */   public int getMaxVFactor() {
/*  70 */     return this.maxVFactor;
/*     */   }
/*     */   
/*     */   public void setMaxHFactor(int anInteger) {
/*  74 */     this.maxHFactor = anInteger;
/*     */   }
/*     */   
/*     */   public void setMaxVFactor(int anInteger) {
/*  78 */     this.maxVFactor = anInteger;
/*     */   }
/*     */   
/*     */   void initializeComponentParameters()
/*     */   {
/*  83 */     int nf = getNumberOfImageComponents();
/*  84 */     this.componentIdentifiers = new int[nf];
/*  85 */     int[][] compSpecParams = new int[0][];
/*  86 */     int hmax = 1;
/*  87 */     int vmax = 1;
/*  88 */     for (int i = 0; i < nf; i++) {
/*  89 */       int ofs = i * 3 + 10;
/*  90 */       int ci = this.reference[ofs] & 0xFF;
/*  91 */       this.componentIdentifiers[i] = ci;
/*  92 */       int hi = (this.reference[(ofs + 1)] & 0xFF) >> 4;
/*  93 */       int vi = this.reference[(ofs + 1)] & 0xF;
/*  94 */       int tqi = this.reference[(ofs + 2)] & 0xFF;
/*  95 */       if (hi > hmax) {
/*  96 */         hmax = hi;
/*     */       }
/*  98 */       if (vi > vmax) {
/*  99 */         vmax = vi;
/*     */       }
/* 101 */       int[] compParam = new int[5];
/* 102 */       compParam[0] = tqi;
/* 103 */       compParam[1] = hi;
/* 104 */       compParam[2] = vi;
/* 105 */       if (compSpecParams.length <= ci) {
/* 106 */         int[][] newParams = new int[ci + 1][];
/* 107 */         System.arraycopy(compSpecParams, 0, newParams, 0, compSpecParams.length);
/* 108 */         compSpecParams = newParams;
/*     */       }
/* 110 */       compSpecParams[ci] = compParam;
/*     */     }
/* 112 */     int x = getSamplesPerLine();
/* 113 */     int y = getNumberOfLines();
/* 114 */     int[] multiples = { 8, 16, 24, 32 };
/* 115 */     for (int i = 0; i < nf; i++) {
/* 116 */       int[] compParam = compSpecParams[this.componentIdentifiers[i]];
/* 117 */       int hi = compParam[1];
/* 118 */       int vi = compParam[2];
/* 119 */       int compWidth = (x * hi + hmax - 1) / hmax;
/* 120 */       int compHeight = (y * vi + vmax - 1) / vmax;
/* 121 */       int dsWidth = roundUpToMultiple(compWidth, multiples[(hi - 1)]);
/* 122 */       int dsHeight = roundUpToMultiple(compHeight, multiples[(vi - 1)]);
/* 123 */       compParam[3] = dsWidth;
/* 124 */       compParam[4] = dsHeight;
/*     */     }
/* 126 */     setMaxHFactor(hmax);
/* 127 */     setMaxVFactor(vmax);
/* 128 */     this.componentParameters = compSpecParams;
/*     */   }
/*     */   
/*     */   public void initializeContents()
/*     */   {
/* 133 */     int nf = getNumberOfImageComponents();
/* 134 */     if ((nf == 0) || (nf != this.componentParameters.length)) {
/* 135 */       SWT.error(40);
/*     */     }
/* 137 */     int hmax = 0;
/* 138 */     int vmax = 0;
/* 139 */     int[][] compSpecParams = this.componentParameters;
/* 140 */     for (int i = 0; i < nf; i++) {
/* 141 */       int ofs = i * 3 + 10;
/* 142 */       int[] compParam = compSpecParams[this.componentIdentifiers[i]];
/* 143 */       int hi = compParam[1];
/* 144 */       int vi = compParam[2];
/* 145 */       if (hi * vi > 4) {
/* 146 */         SWT.error(40);
/*     */       }
/* 148 */       this.reference[ofs] = ((byte)(i + 1));
/* 149 */       this.reference[(ofs + 1)] = ((byte)(hi * 16 + vi));
/* 150 */       this.reference[(ofs + 2)] = ((byte)compParam[0]);
/* 151 */       if (hi > hmax) hmax = hi;
/* 152 */       if (vi > vmax) vmax = vi;
/*     */     }
/* 154 */     int x = getSamplesPerLine();
/* 155 */     int y = getNumberOfLines();
/* 156 */     int[] multiples = { 8, 16, 24, 32 };
/* 157 */     for (int i = 0; i < nf; i++) {
/* 158 */       int[] compParam = compSpecParams[this.componentIdentifiers[i]];
/* 159 */       int hi = compParam[1];
/* 160 */       int vi = compParam[2];
/* 161 */       int compWidth = (x * hi + hmax - 1) / hmax;
/* 162 */       int compHeight = (y * vi + vmax - 1) / vmax;
/* 163 */       int dsWidth = roundUpToMultiple(compWidth, multiples[(hi - 1)]);
/* 164 */       int dsHeight = roundUpToMultiple(compHeight, multiples[(vi - 1)]);
/* 165 */       compParam[3] = dsWidth;
/* 166 */       compParam[4] = dsHeight;
/*     */     }
/* 168 */     setMaxHFactor(hmax);
/* 169 */     setMaxVFactor(vmax);
/*     */   }
/*     */   
/*     */   int roundUpToMultiple(int anInteger, int mInteger) {
/* 173 */     int a = anInteger + mInteger - 1;
/* 174 */     return a - a % mInteger;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean verify()
/*     */   {
/* 197 */     int marker = getSegmentMarker();
/* 198 */     return ((marker >= 65472) && (marker <= 65475)) || ((marker >= 65477) && (marker <= 65479)) || ((marker >= 65481) && (marker <= 65483)) || ((marker >= 65485) && (marker <= 65487));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isProgressive()
/*     */   {
/* 205 */     int marker = getSegmentMarker();
/* 206 */     return (marker == 65474) || (marker == 65478) || (marker == 65482) || (marker == 65486);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isArithmeticCoding()
/*     */   {
/* 213 */     return getSegmentMarker() >= 65481;
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/internal/image/JPEGFrameHeader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */