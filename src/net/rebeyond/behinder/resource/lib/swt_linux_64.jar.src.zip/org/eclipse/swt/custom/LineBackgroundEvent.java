/*    */ package org.eclipse.swt.custom;
/*    */ 
/*    */ import org.eclipse.swt.events.TypedEvent;
/*    */ import org.eclipse.swt.graphics.Color;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LineBackgroundEvent
/*    */   extends TypedEvent
/*    */ {
/*    */   public int lineOffset;
/*    */   public String lineText;
/*    */   public Color lineBackground;
/*    */   static final long serialVersionUID = 3978711687853324342L;
/*    */   
/*    */   public LineBackgroundEvent(StyledTextEvent e)
/*    */   {
/* 47 */     super(e);
/* 48 */     this.lineOffset = e.detail;
/* 49 */     this.lineText = e.text;
/* 50 */     this.lineBackground = e.lineBackground;
/*    */   }
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/custom/LineBackgroundEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */