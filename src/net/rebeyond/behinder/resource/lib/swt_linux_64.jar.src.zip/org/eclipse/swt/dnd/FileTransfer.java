/*     */ package org.eclipse.swt.dnd;
/*     */ 
/*     */ import org.eclipse.swt.internal.C;
/*     */ import org.eclipse.swt.internal.gtk.OS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FileTransfer
/*     */   extends ByteArrayTransfer
/*     */ {
/*  38 */   private static FileTransfer _instance = new FileTransfer();
/*     */   private static final String URI_LIST = "text/uri-list";
/*  40 */   private static final int URI_LIST_ID = registerType("text/uri-list");
/*     */   private static final String GNOME_LIST = "x-special/gnome-copied-files";
/*  42 */   private static final int GNOME_LIST_ID = registerType("x-special/gnome-copied-files");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static FileTransfer getInstance()
/*     */   {
/*  52 */     return _instance;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void javaToNative(Object object, TransferData transferData)
/*     */   {
/*  69 */     transferData.result = 0;
/*  70 */     if ((!checkFile(object)) || (!isSupportedType(transferData))) {
/*  71 */       DND.error(2003);
/*     */     }
/*  73 */     boolean gnomeList = transferData.type == GNOME_LIST_ID;
/*     */     byte[] separator;
/*  75 */     byte[] buffer; byte[] separator; if (gnomeList) {
/*  76 */       byte[] buffer = { 99, 111, 112, 121 };
/*  77 */       separator = new byte[] { 10 };
/*     */     } else {
/*  79 */       buffer = new byte[0];
/*  80 */       separator = new byte[] { 13, 10 };
/*     */     }
/*  82 */     String[] files = (String[])object;
/*  83 */     for (int i = 0; i < files.length; i++) {
/*  84 */       String string = files[i];
/*  85 */       if (string != null) {
/*  86 */         int length = string.length();
/*  87 */         if (length != 0) {
/*  88 */           char[] chars = new char[length];
/*  89 */           string.getChars(0, length, chars, 0);
/*  90 */           long[] error = new long[1];
/*  91 */           long utf8Ptr = OS.g_utf16_to_utf8(chars, chars.length, null, null, error);
/*  92 */           if ((error[0] == 0L) && (utf8Ptr != 0L)) {
/*  93 */             long localePtr = OS.g_filename_from_utf8(utf8Ptr, -1L, null, null, error);
/*  94 */             OS.g_free(utf8Ptr);
/*  95 */             if ((error[0] == 0L) && (localePtr != 0L)) {
/*  96 */               long uriPtr = OS.g_filename_to_uri(localePtr, 0L, error);
/*  97 */               OS.g_free(localePtr);
/*  98 */               if ((error[0] == 0L) && (uriPtr != 0L)) {
/*  99 */                 length = C.strlen(uriPtr);
/* 100 */                 byte[] temp = new byte[length];
/* 101 */                 C.memmove(temp, uriPtr, length);
/* 102 */                 OS.g_free(uriPtr);
/* 103 */                 int newLength = buffer.length > 0 ? buffer.length + separator.length + temp.length : temp.length;
/* 104 */                 byte[] newBuffer = new byte[newLength];
/* 105 */                 int offset = 0;
/* 106 */                 if (buffer.length > 0) {
/* 107 */                   System.arraycopy(buffer, 0, newBuffer, 0, buffer.length);
/* 108 */                   offset += buffer.length;
/* 109 */                   System.arraycopy(separator, 0, newBuffer, offset, separator.length);
/* 110 */                   offset += separator.length;
/*     */                 }
/* 112 */                 System.arraycopy(temp, 0, newBuffer, offset, temp.length);
/* 113 */                 buffer = newBuffer;
/*     */               } } } } } }
/* 115 */     if (buffer.length == 0) return;
/* 116 */     long ptr = OS.g_malloc(buffer.length + 1);
/* 117 */     C.memset(ptr, 0, buffer.length + 1);
/* 118 */     C.memmove(ptr, buffer, buffer.length);
/* 119 */     transferData.pValue = ptr;
/* 120 */     transferData.length = buffer.length;
/* 121 */     transferData.format = 8;
/* 122 */     transferData.result = 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object nativeToJava(TransferData transferData)
/*     */   {
/* 137 */     if ((!isSupportedType(transferData)) || (transferData.pValue == 0L) || (transferData.length <= 0)) return null;
/* 138 */     int length = transferData.length;
/* 139 */     byte[] temp = new byte[length];
/* 140 */     C.memmove(temp, transferData.pValue, length);
/* 141 */     boolean gnomeList = transferData.type == GNOME_LIST_ID;
/* 142 */     int sepLength = gnomeList ? 1 : 2;
/* 143 */     long[] files = new long[0];
/* 144 */     int offset = 0;
/* 145 */     for (int i = 0; i < temp.length - 1; i++) {
/* 146 */       boolean terminator = temp[i] == 10;
/* 147 */       if (terminator) {
/* 148 */         if ((!gnomeList) || (offset != 0))
/*     */         {
/* 150 */           int size = i - offset;
/* 151 */           long file = OS.g_malloc(size + 1);
/* 152 */           byte[] fileBuffer = new byte[size + 1];
/* 153 */           System.arraycopy(temp, offset, fileBuffer, 0, size);
/* 154 */           C.memmove(file, fileBuffer, size + 1);
/* 155 */           long[] newFiles = new long[files.length + 1];
/* 156 */           System.arraycopy(files, 0, newFiles, 0, files.length);
/* 157 */           newFiles[files.length] = file;
/* 158 */           files = newFiles;
/*     */         }
/* 160 */         offset = i + sepLength;
/*     */       }
/*     */     }
/* 163 */     if (offset < temp.length - sepLength) {
/* 164 */       int size = temp.length - offset;
/* 165 */       long file = OS.g_malloc(size + 1);
/* 166 */       byte[] fileBuffer = new byte[size + 1];
/* 167 */       System.arraycopy(temp, offset, fileBuffer, 0, size);
/* 168 */       C.memmove(file, fileBuffer, size + 1);
/* 169 */       long[] newFiles = new long[files.length + 1];
/* 170 */       System.arraycopy(files, 0, newFiles, 0, files.length);
/* 171 */       newFiles[files.length] = file;
/* 172 */       files = newFiles;
/*     */     }
/* 174 */     String[] fileNames = new String[0];
/* 175 */     for (int i = 0; i < files.length; i++) {
/* 176 */       long[] error = new long[1];
/* 177 */       long localePtr = OS.g_filename_from_uri(files[i], null, error);
/* 178 */       OS.g_free(files[i]);
/* 179 */       if ((error[0] == 0L) && (localePtr != 0L)) {
/* 180 */         long utf8Ptr = OS.g_filename_to_utf8(localePtr, -1L, null, null, null);
/* 181 */         if (utf8Ptr == 0L) utf8Ptr = OS.g_filename_display_name(localePtr);
/* 182 */         if (localePtr != utf8Ptr) OS.g_free(localePtr);
/* 183 */         if (utf8Ptr != 0L) {
/* 184 */           long[] items_written = new long[1];
/* 185 */           long utf16Ptr = OS.g_utf8_to_utf16(utf8Ptr, -1L, null, items_written, null);
/* 186 */           OS.g_free(utf8Ptr);
/* 187 */           if (utf16Ptr != 0L) {
/* 188 */             length = (int)items_written[0];
/* 189 */             char[] buffer = new char[length];
/* 190 */             C.memmove(buffer, utf16Ptr, length * 2);
/* 191 */             OS.g_free(utf16Ptr);
/* 192 */             String name = new String(buffer);
/* 193 */             String[] newFileNames = new String[fileNames.length + 1];
/* 194 */             System.arraycopy(fileNames, 0, newFileNames, 0, fileNames.length);
/* 195 */             newFileNames[fileNames.length] = name;
/* 196 */             fileNames = newFileNames;
/*     */           } } } }
/* 198 */     if (fileNames.length == 0) return null;
/* 199 */     return fileNames;
/*     */   }
/*     */   
/*     */   protected int[] getTypeIds()
/*     */   {
/* 204 */     return new int[] { URI_LIST_ID, GNOME_LIST_ID };
/*     */   }
/*     */   
/*     */   protected String[] getTypeNames()
/*     */   {
/* 209 */     return new String[] { "text/uri-list", "x-special/gnome-copied-files" };
/*     */   }
/*     */   
/*     */   boolean checkFile(Object object) {
/* 213 */     if ((object == null) || (!(object instanceof String[])) || (((String[])object).length == 0)) return false;
/* 214 */     String[] strings = (String[])object;
/* 215 */     for (int i = 0; i < strings.length; i++) {
/* 216 */       if ((strings[i] == null) || (strings[i].length() == 0)) return false;
/*     */     }
/* 218 */     return true;
/*     */   }
/*     */   
/*     */   protected boolean validate(Object object)
/*     */   {
/* 223 */     return checkFile(object);
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/dnd/FileTransfer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */