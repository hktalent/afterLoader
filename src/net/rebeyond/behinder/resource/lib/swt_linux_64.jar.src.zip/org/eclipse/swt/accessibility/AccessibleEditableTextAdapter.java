package org.eclipse.swt.accessibility;

public class AccessibleEditableTextAdapter
  implements AccessibleEditableTextListener
{
  public void copyText(AccessibleEditableTextEvent e) {}
  
  public void cutText(AccessibleEditableTextEvent e) {}
  
  public void pasteText(AccessibleEditableTextEvent e) {}
  
  public void replaceText(AccessibleEditableTextEvent e) {}
  
  public void setTextAttributes(AccessibleTextAttributeEvent e) {}
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/accessibility/AccessibleEditableTextAdapter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */