/*      */ package org.eclipse.swt.internal.gtk;
/*      */ 
/*      */ import org.eclipse.swt.internal.Lock;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class GTK
/*      */   extends OS
/*      */ {
/*      */   public static final int GTK_ACCEL_VISIBLE = 1;
/*      */   public static final int GTK_ARROW_DOWN = 1;
/*      */   public static final int GTK_ARROW_LEFT = 2;
/*      */   public static final int GTK_ARROW_RIGHT = 3;
/*      */   public static final int GTK_ARROW_UP = 0;
/*      */   public static final int GTK_ALIGN_FILL = 0;
/*      */   public static final int GTK_ALIGN_START = 1;
/*      */   public static final int GTK_ALIGN_END = 2;
/*      */   public static final int GTK_ALIGN_CENTER = 3;
/*      */   public static final int GTK_ALIGN_BASELINE = 4;
/*      */   public static final int GTK_CALENDAR_SHOW_HEADING = 1;
/*      */   public static final int GTK_CALENDAR_SHOW_DAY_NAMES = 2;
/*      */   public static final int GTK_CALENDAR_NO_MONTH_CHANGE = 4;
/*      */   public static final int GTK_CALENDAR_SHOW_WEEK_NUMBERS = 8;
/*      */   public static final int GTK_CALENDAR_WEEK_START_MONDAY = 16;
/*      */   public static final int GTK_CAN_DEFAULT = 8192;
/*      */   public static final int GTK_CAN_FOCUS = 2048;
/*      */   public static final int GTK_CELL_RENDERER_MODE_ACTIVATABLE = 1;
/*      */   public static final int GTK_CELL_RENDERER_SELECTED = 1;
/*      */   public static final int GTK_CELL_RENDERER_FOCUSED = 16;
/*      */   public static final int GTK_CLIST_SHOW_TITLES = 4;
/*      */   public static final int GTK_CORNER_TOP_LEFT = 0;
/*      */   public static final int GTK_CORNER_TOP_RIGHT = 2;
/*      */   public static final int GTK_DIALOG_DESTROY_WITH_PARENT = 2;
/*      */   public static final int GTK_DIALOG_MODAL = 1;
/*      */   public static final int GTK_DIR_TAB_FORWARD = 0;
/*      */   public static final int GTK_DIR_TAB_BACKWARD = 1;
/*      */   public static final int GTK_ENTRY_ICON_PRIMARY = 0;
/*      */   public static final int GTK_ENTRY_ICON_SECONDARY = 1;
/*      */   public static final int GTK_FILE_CHOOSER_ACTION_OPEN = 0;
/*      */   public static final int GTK_FILE_CHOOSER_ACTION_SAVE = 1;
/*      */   public static final int GTK_FILE_CHOOSER_ACTION_SELECT_FOLDER = 2;
/*      */   public static final int GTK_FRAME_LABEL_PAD = 1;
/*      */   public static final int GTK_FRAME_LABEL_SIDE_PAD = 2;
/*      */   public static final int GTK_HAS_FOCUS = 4096;
/*      */   public static final int GTK_ICON_SIZE_MENU = 1;
/*      */   public static final int GTK_ICON_SIZE_SMALL_TOOLBAR = 2;
/*      */   public static final int GTK_ICON_SIZE_LARGE_TOOLBAR = 3;
/*      */   public static final int GTK_ICON_SIZE_DIALOG = 6;
/*      */   public static final int GTK_ICON_LOOKUP_FORCE_SIZE = 4;
/*      */   public static final int GTK_JUSTIFY_CENTER = 2;
/*      */   public static final int GTK_JUSTIFY_LEFT = 0;
/*      */   public static final int GTK_JUSTIFY_RIGHT = 1;
/*      */   public static final int GTK_MAPPED = 128;
/*      */   public static final int GTK_MESSAGE_INFO = 0;
/*      */   public static final int GTK_MESSAGE_WARNING = 1;
/*      */   public static final int GTK_MESSAGE_QUESTION = 2;
/*      */   public static final int GTK_MESSAGE_ERROR = 3;
/*      */   public static final int GTK_MOVEMENT_VISUAL_POSITIONS = 1;
/*      */   public static final int GTK_NO_WINDOW = 32;
/*      */   public static final int GTK_ORIENTATION_HORIZONTAL = 0;
/*      */   public static final int GTK_ORIENTATION_VERTICAL = 1;
/*      */   public static final int GTK_PACK_END = 1;
/*      */   public static final int GTK_PACK_START = 0;
/*      */   public static final int GTK_PAGE_ORIENTATION_PORTRAIT = 0;
/*      */   public static final int GTK_PAGE_ORIENTATION_LANDSCAPE = 1;
/*      */   public static final int GTK_POLICY_ALWAYS = 0;
/*      */   public static final int GTK_POLICY_AUTOMATIC = 1;
/*      */   public static final int GTK_POLICY_NEVER = 2;
/*      */   public static final int GTK_POLICY_EXTERNAL = 3;
/*      */   public static final int GTK_POS_TOP = 2;
/*      */   public static final int GTK_POS_BOTTOM = 3;
/*      */   public static final int GTK_PRINT_CAPABILITY_PAGE_SET = 1;
/*      */   public static final int GTK_PRINT_CAPABILITY_COPIES = 2;
/*      */   public static final int GTK_PRINT_CAPABILITY_COLLATE = 4;
/*      */   public static final int GTK_PRINT_CAPABILITY_REVERSE = 8;
/*      */   public static final int GTK_PRINT_CAPABILITY_SCALE = 16;
/*      */   public static final int GTK_PRINT_CAPABILITY_GENERATE_PDF = 32;
/*      */   public static final int GTK_PRINT_CAPABILITY_GENERATE_PS = 64;
/*      */   public static final int GTK_PRINT_CAPABILITY_PREVIEW = 128;
/*      */   public static final int GTK_PRINT_PAGES_ALL = 0;
/*      */   public static final int GTK_PRINT_PAGES_CURRENT = 1;
/*      */   public static final int GTK_PRINT_PAGES_RANGES = 2;
/*      */   public static final int GTK_PRINT_DUPLEX_SIMPLEX = 0;
/*      */   public static final int GTK_PRINT_DUPLEX_HORIZONTAL = 1;
/*      */   public static final int GTK_PRINT_DUPLEX_VERTICAL = 2;
/*      */   public static final int GTK_PROGRESS_CONTINUOUS = 0;
/*      */   public static final int GTK_PROGRESS_DISCRETE = 1;
/*      */   public static final int GTK_PROGRESS_LEFT_TO_RIGHT = 0;
/*      */   public static final int GTK_PROGRESS_BOTTOM_TO_TOP = 2;
/*      */   public static final int GTK_RECEIVES_DEFAULT = 1048576;
/*      */   public static final int GTK_RELIEF_NONE = 2;
/*      */   public static final int GTK_RELIEF_NORMAL = 0;
/*      */   public static final int GTK_RC_BG = 2;
/*      */   public static final int GTK_RC_FG = 1;
/*      */   public static final int GTK_RC_TEXT = 4;
/*      */   public static final int GTK_RC_BASE = 8;
/*      */   public static final int GTK_RESPONSE_APPLY = -10;
/*      */   public static final int GTK_RESPONSE_CANCEL = -6;
/*      */   public static final int GTK_RESPONSE_OK = -5;
/*      */   public static final int GTK_SCROLL_NONE = 0;
/*      */   public static final int GTK_SCROLL_JUMP = 1;
/*      */   public static final int GTK_SCROLL_STEP_BACKWARD = 2;
/*      */   public static final int GTK_SCROLL_STEP_FORWARD = 3;
/*      */   public static final int GTK_SCROLL_PAGE_BACKWARD = 4;
/*      */   public static final int GTK_SCROLL_PAGE_FORWARD = 5;
/*      */   public static final int GTK_SCROLL_STEP_UP = 6;
/*      */   public static final int GTK_SCROLL_STEP_DOWN = 7;
/*      */   public static final int GTK_SCROLL_PAGE_UP = 8;
/*      */   public static final int GTK_SCROLL_PAGE_DOWN = 9;
/*      */   public static final int GTK_SCROLL_STEP_LEFT = 10;
/*      */   public static final int GTK_SCROLL_STEP_RIGHT = 11;
/*      */   public static final int GTK_SCROLL_PAGE_LEFT = 12;
/*      */   public static final int GTK_SCROLL_PAGE_RIGHT = 13;
/*      */   public static final int GTK_SCROLL_START = 14;
/*      */   public static final int GTK_SCROLL_END = 15;
/*      */   public static final int GTK_SELECTION_BROWSE = 2;
/*      */   public static final int GTK_SELECTION_MULTIPLE = 3;
/*      */   public static final int GTK_SENSITIVE = 512;
/*      */   public static final int GTK_SHADOW_ETCHED_IN = 3;
/*      */   public static final int GTK_SHADOW_ETCHED_OUT = 4;
/*      */   public static final int GTK_SHADOW_IN = 1;
/*      */   public static final int GTK_SHADOW_NONE = 0;
/*      */   public static final int GTK_SHADOW_OUT = 2;
/*      */   public static final int GTK_STATE_ACTIVE = 1;
/*      */   public static final int GTK_STATE_INSENSITIVE = 4;
/*      */   public static final int GTK_STATE_NORMAL = 0;
/*      */   public static final int GTK_STATE_PRELIGHT = 2;
/*      */   public static final int GTK_STATE_SELECTED = 3;
/*      */   public static final int GTK_STATE_FLAG_NORMAL = 0;
/*      */   public static final int GTK_STATE_FLAG_ACTIVE = 1;
/*      */   public static final int GTK_STATE_FLAG_PRELIGHT = 2;
/*      */   public static final int GTK_STATE_FLAG_SELECTED = 4;
/*      */   public static final int GTK_STATE_FLAG_INSENSITIVE = 8;
/*      */   public static final int GTK_STATE_FLAG_INCONSISTENT = 16;
/*      */   public static final int GTK_STATE_FLAG_FOCUSED = 32;
/*      */   public static final int GTK_STATE_FLAG_BACKDROP = 64;
/*      */   public static final int GTK_TEXT_DIR_LTR = 1;
/*      */   public static final int GTK_TEXT_DIR_NONE = 0;
/*      */   public static final int GTK_TEXT_DIR_RTL = 2;
/*      */   public static final int GTK_TEXT_WINDOW_TEXT = 2;
/*      */   public static final int GTK_TOOLBAR_CHILD_BUTTON = 1;
/*      */   public static final int GTK_TOOLBAR_CHILD_RADIOBUTTON = 3;
/*      */   public static final int GTK_TOOLBAR_CHILD_TOGGLEBUTTON = 2;
/*      */   public static final int GTK_TOOLBAR_ICONS = 0;
/*      */   public static final int GTK_TOOLBAR_TEXT = 1;
/*      */   public static final int GTK_TOOLBAR_BOTH = 2;
/*      */   public static final int GTK_TOOLBAR_BOTH_HORIZ = 3;
/*      */   public static final int GTK_TREE_VIEW_COLUMN_GROW_ONLY = 0;
/*      */   public static final int GTK_TREE_VIEW_COLUMN_AUTOSIZE = 1;
/*      */   public static final int GTK_TREE_VIEW_COLUMN_FIXED = 2;
/*      */   public static final int GTK_TREE_VIEW_DROP_BEFORE = 0;
/*      */   public static final int GTK_TREE_VIEW_DROP_AFTER = 1;
/*      */   public static final int GTK_TREE_VIEW_DROP_INTO_OR_BEFORE = 2;
/*      */   public static final int GTK_TREE_VIEW_DROP_INTO_OR_AFTER = 3;
/*      */   public static final int GTK_TREE_VIEW_GRID_LINES_NONE = 0;
/*      */   public static final int GTK_TREE_VIEW_GRID_LINES_HORIZONTAL = 1;
/*      */   public static final int GTK_TREE_VIEW_GRID_LINES_VERTICAL = 2;
/*      */   public static final int GTK_TREE_VIEW_GRID_LINES_BOTH = 3;
/*      */   public static final int GTK_STYLE_PROVIDER_PRIORITY_APPLICATION = 600;
/*      */   public static final int GTK_STYLE_PROVIDER_PRIORITY_USER = 800;
/*      */   public static final int GTK_UNIT_PIXEL = 0;
/*      */   public static final int GTK_UNIT_POINTS = 1;
/*      */   public static final int GTK_UNIT_INCH = 2;
/*      */   public static final int GTK_UNIT_MM = 3;
/*      */   public static final int GTK_VISIBLE = 256;
/*      */   public static final int GTK_WINDOW_POPUP = 1;
/*      */   public static final int GTK_WINDOW_TOPLEVEL = 0;
/*      */   public static final int GTK_WRAP_NONE = 0;
/*      */   public static final int GTK_WRAP_WORD = 2;
/*      */   public static final int GTK_WRAP_WORD_CHAR = 3;
/*      */   public static final int GTK_EXPANDER_COLAPSED = 0;
/*      */   public static final int GTK_EXPANDER_SEMI_COLLAPSED = 1;
/*      */   public static final int GTK_EXPANDER_SEMI_EXPANDED = 2;
/*      */   public static final int GTK_EXPANDER_EXPANDED = 3;
/*  193 */   public static final byte[] GTK_STYLE_CLASS_TOOLTIP = OS.ascii("tooltip");
/*  194 */   public static final byte[] GTK_STYLE_CLASS_VIEW = OS.ascii("view");
/*  195 */   public static final byte[] GTK_STYLE_CLASS_CELL = OS.ascii("cell");
/*  196 */   public static final byte[] GTK_STYLE_CLASS_PANE_SEPARATOR = OS.ascii("pane-separator");
/*  197 */   public static final byte[] GTK_STYLE_CLASS_FRAME = OS.ascii("frame");
/*      */   
/*      */ 
/*  200 */   public static final byte[] gtk_alternative_button_order = OS.ascii("gtk-alternative-button-order");
/*  201 */   public static final byte[] gtk_color_palette = OS.ascii("gtk-color-palette");
/*  202 */   public static final byte[] gtk_cursor_blink = OS.ascii("gtk-cursor-blink");
/*  203 */   public static final byte[] gtk_cursor_blink_time = OS.ascii("gtk-cursor-blink-time");
/*  204 */   public static final byte[] gtk_double_click_time = OS.ascii("gtk-double-click-time");
/*  205 */   public static final byte[] gtk_entry_select_on_focus = OS.ascii("gtk-entry-select-on-focus");
/*  206 */   public static final byte[] gtk_show_input_method_menu = OS.ascii("gtk-show-input-method-menu");
/*  207 */   public static final byte[] gtk_style_property_font = OS.ascii("font");
/*  208 */   public static final byte[] gtk_menu_bar_accel = OS.ascii("gtk-menu-bar-accel");
/*  209 */   public static final byte[] gtk_menu_images = OS.ascii("gtk-menu-images");
/*  210 */   public static final byte[] gtk_theme_name = OS.ascii("gtk-theme-name");
/*      */   
/*      */ 
/*      */ 
/*  214 */   public static final byte[] GTK_PRINT_SETTINGS_OUTPUT_URI = OS.ascii("output-uri");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  220 */   public static final byte[] gtk_application_prefer_dark_theme = OS.ascii("gtk-application-prefer-dark-theme");
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  228 */   public static final byte[] GTK_NAMED_ICON_FIND = OS.ascii("system-search-symbolic");
/*  229 */   public static final byte[] GTK_NAMED_ICON_CLEAR = OS.ascii("edit-clear-symbolic");
/*  230 */   public static final byte[] GTK_NAMED_ICON_GO_UP = OS.ascii("go-up-symbolic");
/*  231 */   public static final byte[] GTK_NAMED_ICON_GO_DOWN = OS.ascii("go-down-symbolic");
/*  232 */   public static final byte[] GTK_NAMED_ICON_GO_NEXT = OS.ascii("go-next-symbolic");
/*  233 */   public static final byte[] GTK_NAMED_ICON_GO_PREVIOUS = OS.ascii("go-previous-symbolic");
/*  234 */   public static final byte[] GTK_NAMED_LABEL_OK = OS.ascii("_OK");
/*  235 */   public static final byte[] GTK_NAMED_LABEL_CANCEL = OS.ascii("_Cancel");
/*      */   
/*  237 */   public static final int GTK_VERSION = OS.VERSION(gtk_major_version(), gtk_minor_version(), gtk_micro_version());
/*  238 */   public static final boolean GTK3 = GTK_VERSION >= OS.VERSION(3, 0, 0);
/*      */   
/*      */   public static final native int GtkAllocation_sizeof();
/*      */   
/*      */   public static final native int GtkBorder_sizeof();
/*      */   
/*      */   public static final native int GtkRequisition_sizeof();
/*      */   
/*      */   public static final native int GtkTargetEntry_sizeof();
/*      */   
/*      */   public static final native int GtkTextIter_sizeof();
/*      */   
/*      */   public static final native int GtkCellRendererText_sizeof();
/*      */   
/*      */   public static final native int GtkCellRendererTextClass_sizeof();
/*      */   
/*      */   public static final native int GtkCellRendererPixbuf_sizeof();
/*      */   
/*      */   public static final native int GtkCellRendererPixbufClass_sizeof();
/*      */   
/*      */   public static final native int GtkCellRendererToggle_sizeof();
/*      */   
/*      */   public static final native int GtkCellRendererToggleClass_sizeof();
/*      */   
/*      */   public static final native int GtkTreeIter_sizeof();
/*      */   
/*      */   public static final native long GTK_WIDGET_GET_CLASS(long paramLong);
/*      */   
/*      */   public static final native void GTK_ACCEL_LABEL_SET_ACCEL_STRING(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final native long GTK_ACCEL_LABEL_GET_ACCEL_STRING(long paramLong);
/*      */   
/*      */   public static final native long GTK_ENTRY_IM_CONTEXT(long paramLong);
/*      */   
/*      */   public static final native long GTK_TEXTVIEW_IM_CONTEXT(long paramLong);
/*      */   
/*      */   public static final native int GTK_WIDGET_REQUISITION_WIDTH(long paramLong);
/*      */   
/*      */   public static final native int GTK_WIDGET_REQUISITION_HEIGHT(long paramLong);
/*      */   
/*      */   public static final native long GTK_TYPE_ACCESSIBLE();
/*      */   
/*      */   public static final native long _GTK_ACCESSIBLE(long paramLong);
/*      */   
/*      */   public static final native boolean _GTK_IS_ACCEL_LABEL(long paramLong);
/*      */   
/*      */   public static final boolean GTK_IS_ACCEL_LABEL(long obj) {
/*  285 */     lock.lock();
/*      */     try {
/*  287 */       return _GTK_IS_ACCEL_LABEL(obj);
/*      */     } finally {
/*  289 */       lock.unlock();
/*      */     } }
/*      */   
/*      */   public static final native boolean _GTK_IS_BUTTON(long paramLong);
/*      */   
/*  294 */   public static final boolean GTK_IS_BUTTON(long obj) { lock.lock();
/*      */     try {
/*  296 */       return _GTK_IS_BUTTON(obj);
/*      */     } finally {
/*  298 */       lock.unlock();
/*      */     } }
/*      */   
/*      */   public static final native boolean _GTK_IS_LABEL(long paramLong);
/*      */   
/*  303 */   public static final boolean GTK_IS_LABEL(long obj) { lock.lock();
/*      */     try {
/*  305 */       return _GTK_IS_LABEL(obj);
/*      */     } finally {
/*  307 */       lock.unlock();
/*      */     } }
/*      */   
/*      */   public static final native boolean _GTK_IS_SCROLLED_WINDOW(long paramLong);
/*      */   
/*  312 */   public static final boolean GTK_IS_SCROLLED_WINDOW(long obj) { lock.lock();
/*      */     try {
/*  314 */       return _GTK_IS_SCROLLED_WINDOW(obj);
/*      */     } finally {
/*  316 */       lock.unlock();
/*      */     } }
/*      */   
/*      */   public static final native boolean _GTK_IS_WINDOW(long paramLong);
/*      */   
/*  321 */   public static final boolean GTK_IS_WINDOW(long obj) { lock.lock();
/*      */     try {
/*  323 */       return _GTK_IS_WINDOW(obj);
/*      */     } finally {
/*  325 */       lock.unlock();
/*      */     } }
/*      */   
/*      */   public static final native boolean _GTK_IS_CELL_RENDERER_PIXBUF(long paramLong);
/*      */   
/*  330 */   public static final boolean GTK_IS_CELL_RENDERER_PIXBUF(long obj) { lock.lock();
/*      */     try {
/*  332 */       return _GTK_IS_CELL_RENDERER_PIXBUF(obj);
/*      */     } finally {
/*  334 */       lock.unlock();
/*      */     } }
/*      */   
/*      */   public static final native boolean _GTK_IS_CELL_RENDERER_TEXT(long paramLong);
/*      */   
/*  339 */   public static final boolean GTK_IS_CELL_RENDERER_TEXT(long obj) { lock.lock();
/*      */     try {
/*  341 */       return _GTK_IS_CELL_RENDERER_TEXT(obj);
/*      */     } finally {
/*  343 */       lock.unlock();
/*      */     } }
/*      */   
/*      */   public static final native boolean _GTK_IS_CELL_RENDERER_TOGGLE(long paramLong);
/*      */   
/*  348 */   public static final boolean GTK_IS_CELL_RENDERER_TOGGLE(long obj) { lock.lock();
/*      */     try {
/*  350 */       return _GTK_IS_CELL_RENDERER_TOGGLE(obj);
/*      */     } finally {
/*  352 */       lock.unlock();
/*      */     } }
/*      */   
/*      */   public static final native boolean _GTK_IS_CONTAINER(long paramLong);
/*      */   
/*  357 */   public static final boolean GTK_IS_CONTAINER(long obj) { lock.lock();
/*      */     try {
/*  359 */       return _GTK_IS_CONTAINER(obj);
/*      */     } finally {
/*  361 */       lock.unlock();
/*      */     } }
/*      */   
/*      */   public static final native boolean _GTK_IS_IMAGE_MENU_ITEM(long paramLong);
/*      */   
/*  366 */   public static final boolean GTK_IS_IMAGE_MENU_ITEM(long obj) { lock.lock();
/*      */     try {
/*  368 */       return _GTK_IS_IMAGE_MENU_ITEM(obj);
/*      */     } finally {
/*  370 */       lock.unlock();
/*      */     } }
/*      */   
/*      */   public static final native boolean _GTK_IS_MENU_ITEM(long paramLong);
/*      */   
/*  375 */   public static final boolean GTK_IS_MENU_ITEM(long obj) { lock.lock();
/*      */     try {
/*  377 */       return _GTK_IS_MENU_ITEM(obj);
/*      */     } finally {
/*  379 */       lock.unlock();
/*      */     } }
/*      */   
/*      */   public static final native boolean _GTK_IS_PLUG(long paramLong);
/*      */   
/*  384 */   public static final boolean GTK_IS_PLUG(long obj) { lock.lock();
/*      */     try {
/*  386 */       return _GTK_IS_PLUG(obj);
/*      */     } finally {
/*  388 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _GTK_STOCK_CANCEL();
/*      */   
/*  394 */   public static final long GTK_STOCK_CANCEL() { lock.lock();
/*      */     try {
/*  396 */       return _GTK_STOCK_CANCEL();
/*      */     } finally {
/*  398 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _GTK_STOCK_OK();
/*      */   
/*  404 */   public static final long GTK_STOCK_OK() { lock.lock();
/*      */     try {
/*  406 */       return _GTK_STOCK_OK();
/*      */     } finally {
/*  408 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _GTK_TYPE_CELL_RENDERER_TEXT();
/*      */   
/*  414 */   public static final long GTK_TYPE_CELL_RENDERER_TEXT() { lock.lock();
/*      */     try {
/*  416 */       return _GTK_TYPE_CELL_RENDERER_TEXT();
/*      */     } finally {
/*  418 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _GTK_TYPE_CELL_RENDERER_PIXBUF();
/*      */   
/*  424 */   public static final long GTK_TYPE_CELL_RENDERER_PIXBUF() { lock.lock();
/*      */     try {
/*  426 */       return _GTK_TYPE_CELL_RENDERER_PIXBUF();
/*      */     } finally {
/*  428 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _GTK_TYPE_CELL_RENDERER_TOGGLE();
/*      */   
/*  434 */   public static final long GTK_TYPE_CELL_RENDERER_TOGGLE() { lock.lock();
/*      */     try {
/*  436 */       return _GTK_TYPE_CELL_RENDERER_TOGGLE();
/*      */     } finally {
/*  438 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _GTK_TYPE_IM_MULTICONTEXT();
/*      */   
/*  444 */   public static final long GTK_TYPE_IM_MULTICONTEXT() { lock.lock();
/*      */     try {
/*  446 */       return _GTK_TYPE_IM_MULTICONTEXT();
/*      */     } finally {
/*  448 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _GTK_TYPE_FIXED();
/*      */   
/*  454 */   public static final long GTK_TYPE_FIXED() { lock.lock();
/*      */     try {
/*  456 */       return _GTK_TYPE_FIXED();
/*      */     } finally {
/*  458 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _GTK_TYPE_MENU();
/*      */   
/*  464 */   public static final long GTK_TYPE_MENU() { lock.lock();
/*      */     try {
/*  466 */       return _GTK_TYPE_MENU();
/*      */     } finally {
/*  468 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _GTK_TYPE_WIDGET();
/*      */   
/*  474 */   public static final long GTK_TYPE_WIDGET() { lock.lock();
/*      */     try {
/*  476 */       return _GTK_TYPE_WIDGET();
/*      */     } finally {
/*  478 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _GTK_TYPE_WINDOW();
/*      */   
/*  484 */   public static final long GTK_TYPE_WINDOW() { lock.lock();
/*      */     try {
/*  486 */       return _GTK_TYPE_WINDOW();
/*      */     } finally {
/*  488 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _GTK_WIDGET_SET_FLAGS(long paramLong, int paramInt);
/*      */   
/*      */   /* Error */
/*      */   public static final void GTK_WIDGET_SET_FLAGS(long wid, int flag)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 27	org/eclipse/swt/internal/gtk/GTK:_GTK_WIDGET_SET_FLAGS	(JI)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #493	-> byte code offset #0
/*      */     //   Java source line #495	-> byte code offset #7
/*      */     //   Java source line #497	-> byte code offset #12
/*      */     //   Java source line #498	-> byte code offset #18
/*      */     //   Java source line #497	-> byte code offset #21
/*      */     //   Java source line #498	-> byte code offset #28
/*      */     //   Java source line #499	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	wid	long
/*      */     //   0	31	2	flag	int
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _GTK_WIDGET_UNSET_FLAGS(long paramLong, int paramInt);
/*      */   
/*      */   /* Error */
/*      */   public static final void GTK_WIDGET_UNSET_FLAGS(long wid, int flag)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 28	org/eclipse/swt/internal/gtk/GTK:_GTK_WIDGET_UNSET_FLAGS	(JI)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #502	-> byte code offset #0
/*      */     //   Java source line #504	-> byte code offset #7
/*      */     //   Java source line #506	-> byte code offset #12
/*      */     //   Java source line #507	-> byte code offset #18
/*      */     //   Java source line #506	-> byte code offset #21
/*      */     //   Java source line #507	-> byte code offset #28
/*      */     //   Java source line #508	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	wid	long
/*      */     //   0	31	2	flag	int
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native long _GET_FUNCTION_POINTER_gtk_false();
/*      */   
/*      */   public static final long GET_FUNCTION_POINTER_gtk_false()
/*      */   {
/*  514 */     lock.lock();
/*      */     try {
/*  516 */       return _GET_FUNCTION_POINTER_gtk_false();
/*      */     } finally {
/*  518 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native boolean _gtk_widget_has_default(long paramLong);
/*      */   
/*      */   public static final boolean gtk_widget_has_default(long widget) {
/*  525 */     lock.lock();
/*      */     try {
/*  527 */       return _gtk_widget_has_default(widget);
/*      */     } finally {
/*  529 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native boolean _gtk_widget_get_sensitive(long paramLong);
/*      */   
/*      */   public static final boolean gtk_widget_get_sensitive(long widget) {
/*  536 */     lock.lock();
/*      */     try {
/*  538 */       return _gtk_widget_get_sensitive(widget);
/*      */     } finally {
/*  540 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gtk_widget_get_name(long paramLong);
/*      */   
/*      */   public static final long gtk_widget_get_name(long widget) {
/*  547 */     lock.lock();
/*      */     try {
/*  549 */       return _gtk_widget_get_name(widget);
/*      */     } finally {
/*  551 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native long _gtk_widget_class_get_css_name(long paramLong);
/*      */   
/*      */   public static final long gtk_widget_class_get_css_name(long widget_class)
/*      */   {
/*  560 */     lock.lock();
/*      */     try {
/*  562 */       return _gtk_widget_class_get_css_name(widget_class);
/*      */     } finally {
/*  564 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_button_clicked(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_button_clicked(long button)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 34	org/eclipse/swt/internal/gtk/GTK:_gtk_button_clicked	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #571	-> byte code offset #0
/*      */     //   Java source line #573	-> byte code offset #7
/*      */     //   Java source line #575	-> byte code offset #11
/*      */     //   Java source line #576	-> byte code offset #17
/*      */     //   Java source line #575	-> byte code offset #20
/*      */     //   Java source line #576	-> byte code offset #27
/*      */     //   Java source line #577	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	button	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native long _gtk_button_new();
/*      */   
/*      */   public static final long gtk_button_new()
/*      */   {
/*  581 */     lock.lock();
/*      */     try {
/*  583 */       return _gtk_button_new();
/*      */     } finally {
/*  585 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_button_set_image(long paramLong1, long paramLong2);
/*      */   
/*      */ 
/*      */   public static final void gtk_button_set_image(long button, long image)
/*      */   {
/*  595 */     lock.lock();
/*      */     try {
/*  597 */       _gtk_button_set_image(button, image);
/*      */     } finally {
/*  599 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final native void _gtk_accel_label_set_accel(long paramLong, int paramInt1, int paramInt2);
/*      */   
/*      */ 
/*      */ 
/*      */   public static final void gtk_accel_label_set_accel(long accel_label, int accel_key, int accel_mods)
/*      */   {
/*  611 */     lock.lock();
/*      */     try {
/*  613 */       _gtk_accel_label_set_accel(accel_label, accel_key, accel_mods);
/*      */     } finally {
/*  615 */       lock.unlock();
/*      */     } }
/*      */   
/*      */   public static final native int _gtk_accelerator_get_default_mod_mask();
/*      */   
/*  620 */   public static final int gtk_accelerator_get_default_mod_mask() { lock.lock();
/*      */     try {
/*  622 */       return _gtk_accelerator_get_default_mod_mask();
/*      */     } finally {
/*  624 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_accelerator_parse(long paramLong, int[] paramArrayOfInt1, int[] paramArrayOfInt2);
/*      */   
/*      */ 
/*      */   public static final void gtk_accelerator_parse(long accelerator, int[] accelerator_key, int[] accelerator_mods)
/*      */   {
/*  634 */     lock.lock();
/*      */     try {
/*  636 */       _gtk_accelerator_parse(accelerator, accelerator_key, accelerator_mods);
/*      */     } finally {
/*  638 */       lock.unlock();
/*      */     } }
/*      */   
/*      */   public static final native long _gtk_accel_group_new();
/*      */   
/*  643 */   public static final long gtk_accel_group_new() { lock.lock();
/*      */     try {
/*  645 */       return _gtk_accel_group_new();
/*      */     } finally {
/*  647 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_accel_label_set_accel_widget(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final void gtk_accel_label_set_accel_widget(long accel_label, long accel_widget)
/*      */   {
/*  656 */     lock.lock();
/*      */     try {
/*  658 */       _gtk_accel_label_set_accel_widget(accel_label, accel_widget);
/*      */     } finally {
/*  660 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gtk_accel_label_new(byte[] paramArrayOfByte);
/*      */   
/*  666 */   public static final long gtk_accel_label_new(byte[] label) { lock.lock();
/*      */     try {
/*  668 */       return _gtk_accel_label_new(label);
/*      */     } finally {
/*  670 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gtk_accessible_get_widget(long paramLong);
/*      */   
/*      */   public static final long gtk_accessible_get_widget(long accessible)
/*      */   {
/*  678 */     lock.lock();
/*      */     try {
/*  680 */       return _gtk_accessible_get_widget(accessible);
/*      */     } finally {
/*  682 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_adjustment_configure(long paramLong, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6);
/*      */   
/*      */   public static final void gtk_adjustment_configure(long adjustment, double value, double lower, double upper, double step_increment, double page_increment, double page_size)
/*      */   {
/*  690 */     lock.lock();
/*      */     try {
/*  692 */       _gtk_adjustment_configure(adjustment, value, lower, upper, step_increment, page_increment, page_size);
/*      */     } finally {
/*  694 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final native long _gtk_adjustment_new(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6);
/*      */   
/*      */ 
/*      */ 
/*      */   public static final long gtk_adjustment_new(double value, double lower, double upper, double step_increment, double page_increment, double page_size)
/*      */   {
/*  706 */     lock.lock();
/*      */     try {
/*  708 */       return _gtk_adjustment_new(value, lower, upper, step_increment, page_increment, page_size);
/*      */     } finally {
/*  710 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native double _gtk_adjustment_get_lower(long paramLong);
/*      */   
/*      */   public static final double gtk_adjustment_get_lower(long adjustment)
/*      */   {
/*  718 */     lock.lock();
/*      */     try {
/*  720 */       return _gtk_adjustment_get_lower(adjustment);
/*      */     } finally {
/*  722 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native double _gtk_adjustment_get_page_increment(long paramLong);
/*      */   
/*      */   public static final double gtk_adjustment_get_page_increment(long adjustment)
/*      */   {
/*  730 */     lock.lock();
/*      */     try {
/*  732 */       return _gtk_adjustment_get_page_increment(adjustment);
/*      */     } finally {
/*  734 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native double _gtk_adjustment_get_page_size(long paramLong);
/*      */   
/*      */   public static final double gtk_adjustment_get_page_size(long adjustment)
/*      */   {
/*  742 */     lock.lock();
/*      */     try {
/*  744 */       return _gtk_adjustment_get_page_size(adjustment);
/*      */     } finally {
/*  746 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native double _gtk_adjustment_get_step_increment(long paramLong);
/*      */   
/*      */   public static final double gtk_adjustment_get_step_increment(long adjustment)
/*      */   {
/*  754 */     lock.lock();
/*      */     try {
/*  756 */       return _gtk_adjustment_get_step_increment(adjustment);
/*      */     } finally {
/*  758 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native double _gtk_adjustment_get_upper(long paramLong);
/*      */   
/*      */   public static final double gtk_adjustment_get_upper(long adjustment)
/*      */   {
/*  766 */     lock.lock();
/*      */     try {
/*  768 */       return _gtk_adjustment_get_upper(adjustment);
/*      */     } finally {
/*  770 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native double _gtk_adjustment_get_value(long paramLong);
/*      */   
/*      */   public static final double gtk_adjustment_get_value(long adjustment)
/*      */   {
/*  778 */     lock.lock();
/*      */     try {
/*  780 */       return _gtk_adjustment_get_value(adjustment);
/*      */     } finally {
/*  782 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_adjustment_set_value(long paramLong, double paramDouble);
/*      */   
/*      */   public static final void gtk_adjustment_set_value(long adjustment, double value)
/*      */   {
/*  791 */     lock.lock();
/*      */     try {
/*  793 */       _gtk_adjustment_set_value(adjustment, value);
/*      */     } finally {
/*  795 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_adjustment_set_step_increment(long paramLong, double paramDouble);
/*      */   
/*      */   public static final void gtk_adjustment_set_step_increment(long adjustment, double value)
/*      */   {
/*  804 */     lock.lock();
/*      */     try {
/*  806 */       _gtk_adjustment_set_step_increment(adjustment, value);
/*      */     } finally {
/*  808 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_adjustment_set_page_increment(long paramLong, double paramDouble);
/*      */   
/*      */   public static final void gtk_adjustment_set_page_increment(long adjustment, double value)
/*      */   {
/*  817 */     lock.lock();
/*      */     try {
/*  819 */       _gtk_adjustment_set_page_increment(adjustment, value);
/*      */     } finally {
/*  821 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_adjustment_value_changed(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_adjustment_value_changed(long adjustment)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 55	org/eclipse/swt/internal/gtk/GTK:_gtk_adjustment_value_changed	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #831	-> byte code offset #0
/*      */     //   Java source line #833	-> byte code offset #7
/*      */     //   Java source line #835	-> byte code offset #11
/*      */     //   Java source line #836	-> byte code offset #17
/*      */     //   Java source line #835	-> byte code offset #20
/*      */     //   Java source line #836	-> byte code offset #27
/*      */     //   Java source line #837	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	adjustment	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native long _gtk_arrow_new(int paramInt1, int paramInt2);
/*      */   
/*      */   public static final long gtk_arrow_new(int arrow_type, int shadow_type)
/*      */   {
/*  846 */     lock.lock();
/*      */     try {
/*  848 */       return _gtk_arrow_new(arrow_type, shadow_type);
/*      */     } finally {
/*  850 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final native void _gtk_arrow_set(long paramLong, int paramInt1, int paramInt2);
/*      */   
/*      */ 
/*      */ 
/*      */   public static final void gtk_arrow_set(long arrow, int arrow_type, int shadow_type)
/*      */   {
/*  862 */     lock.lock();
/*      */     try {
/*  864 */       _gtk_arrow_set(arrow, arrow_type, shadow_type);
/*      */     } finally {
/*  866 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gtk_bin_get_child(long paramLong);
/*      */   
/*  872 */   public static final long gtk_bin_get_child(long bin) { lock.lock();
/*      */     try {
/*  874 */       return _gtk_bin_get_child(bin);
/*      */     } finally {
/*  876 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_border_free(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_border_free(long border)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 59	org/eclipse/swt/internal/gtk/GTK:_gtk_border_free	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #882	-> byte code offset #0
/*      */     //   Java source line #884	-> byte code offset #7
/*      */     //   Java source line #886	-> byte code offset #11
/*      */     //   Java source line #887	-> byte code offset #17
/*      */     //   Java source line #886	-> byte code offset #20
/*      */     //   Java source line #887	-> byte code offset #27
/*      */     //   Java source line #888	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	border	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_box_set_spacing(long paramLong, int paramInt);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_box_set_spacing(long box, int spacing)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 60	org/eclipse/swt/internal/gtk/GTK:_gtk_box_set_spacing	(JI)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #892	-> byte code offset #0
/*      */     //   Java source line #894	-> byte code offset #7
/*      */     //   Java source line #896	-> byte code offset #12
/*      */     //   Java source line #897	-> byte code offset #18
/*      */     //   Java source line #896	-> byte code offset #21
/*      */     //   Java source line #897	-> byte code offset #28
/*      */     //   Java source line #898	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	box	long
/*      */     //   0	31	2	spacing	int
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_box_set_child_packing(long paramLong1, long paramLong2, boolean paramBoolean1, boolean paramBoolean2, int paramInt1, int paramInt2);
/*      */   
/*      */   public static final void gtk_box_set_child_packing(long box, long child, boolean expand, boolean fill, int padding, int pack_type)
/*      */   {
/*  905 */     lock.lock();
/*      */     try {
/*  907 */       _gtk_box_set_child_packing(box, child, expand, fill, padding, pack_type);
/*      */     } finally {
/*  909 */       lock.unlock();
/*      */     } }
/*      */   
/*      */   public static final native long _gtk_calendar_new();
/*      */   
/*  914 */   public static final long gtk_calendar_new() { lock.lock();
/*      */     try {
/*  916 */       return _gtk_calendar_new();
/*      */     } finally {
/*  918 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_calendar_select_month(long paramLong, int paramInt1, int paramInt2);
/*      */   
/*      */ 
/*      */   public static final void gtk_calendar_select_month(long calendar, int month, int year)
/*      */   {
/*  928 */     lock.lock();
/*      */     try {
/*  930 */       _gtk_calendar_select_month(calendar, month, year);
/*      */     } finally {
/*  932 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_calendar_select_day(long paramLong, int paramInt);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_calendar_select_day(long calendar, int day)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 64	org/eclipse/swt/internal/gtk/GTK:_gtk_calendar_select_day	(JI)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #941	-> byte code offset #0
/*      */     //   Java source line #943	-> byte code offset #7
/*      */     //   Java source line #945	-> byte code offset #12
/*      */     //   Java source line #946	-> byte code offset #18
/*      */     //   Java source line #945	-> byte code offset #21
/*      */     //   Java source line #946	-> byte code offset #28
/*      */     //   Java source line #947	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	calendar	long
/*      */     //   0	31	2	day	int
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_calendar_mark_day(long paramLong, int paramInt);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_calendar_mark_day(long calendar, int day)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 65	org/eclipse/swt/internal/gtk/GTK:_gtk_calendar_mark_day	(JI)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #954	-> byte code offset #0
/*      */     //   Java source line #956	-> byte code offset #7
/*      */     //   Java source line #958	-> byte code offset #12
/*      */     //   Java source line #959	-> byte code offset #18
/*      */     //   Java source line #958	-> byte code offset #21
/*      */     //   Java source line #959	-> byte code offset #28
/*      */     //   Java source line #960	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	calendar	long
/*      */     //   0	31	2	day	int
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_calendar_clear_marks(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_calendar_clear_marks(long calendar)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 66	org/eclipse/swt/internal/gtk/GTK:_gtk_calendar_clear_marks	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #966	-> byte code offset #0
/*      */     //   Java source line #968	-> byte code offset #7
/*      */     //   Java source line #970	-> byte code offset #11
/*      */     //   Java source line #971	-> byte code offset #17
/*      */     //   Java source line #970	-> byte code offset #20
/*      */     //   Java source line #971	-> byte code offset #27
/*      */     //   Java source line #972	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	calendar	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_calendar_set_display_options(long paramLong, int paramInt);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_calendar_set_display_options(long calendar, int flags)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 67	org/eclipse/swt/internal/gtk/GTK:_gtk_calendar_set_display_options	(JI)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #979	-> byte code offset #0
/*      */     //   Java source line #981	-> byte code offset #7
/*      */     //   Java source line #983	-> byte code offset #12
/*      */     //   Java source line #984	-> byte code offset #18
/*      */     //   Java source line #983	-> byte code offset #21
/*      */     //   Java source line #984	-> byte code offset #28
/*      */     //   Java source line #985	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	calendar	long
/*      */     //   0	31	2	flags	int
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_calendar_get_date(long paramLong, int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3);
/*      */   
/*      */   public static final void gtk_calendar_get_date(long calendar, int[] year, int[] month, int[] day)
/*      */   {
/*  994 */     lock.lock();
/*      */     try {
/*  996 */       _gtk_calendar_get_date(calendar, year, month, day);
/*      */     } finally {
/*  998 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_cell_layout_clear(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_cell_layout_clear(long cell_layout)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 69	org/eclipse/swt/internal/gtk/GTK:_gtk_cell_layout_clear	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #1004	-> byte code offset #0
/*      */     //   Java source line #1006	-> byte code offset #7
/*      */     //   Java source line #1008	-> byte code offset #11
/*      */     //   Java source line #1009	-> byte code offset #17
/*      */     //   Java source line #1008	-> byte code offset #20
/*      */     //   Java source line #1009	-> byte code offset #27
/*      */     //   Java source line #1010	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	cell_layout	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native long _gtk_cell_layout_get_cells(long paramLong);
/*      */   
/*      */   public static final long gtk_cell_layout_get_cells(long cell_layout)
/*      */   {
/* 1014 */     lock.lock();
/*      */     try {
/* 1016 */       return _gtk_cell_layout_get_cells(cell_layout);
/*      */     } finally {
/* 1018 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_cell_layout_set_attributes(long paramLong1, long paramLong2, byte[] paramArrayOfByte, int paramInt, long paramLong3);
/*      */   
/*      */ 
/*      */   public static final void gtk_cell_layout_set_attributes(long cell_layout, long cell, byte[] attribute, int column, long sentinel)
/*      */   {
/* 1028 */     lock.lock();
/*      */     try {
/* 1030 */       _gtk_cell_layout_set_attributes(cell_layout, cell, attribute, column, sentinel);
/*      */     } finally {
/* 1032 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_cell_layout_pack_start(long paramLong1, long paramLong2, boolean paramBoolean);
/*      */   
/*      */   public static final void gtk_cell_layout_pack_start(long cell_layout, long cell, boolean expand)
/*      */   {
/* 1041 */     lock.lock();
/*      */     try {
/* 1043 */       _gtk_cell_layout_pack_start(cell_layout, cell, expand);
/*      */     } finally {
/* 1045 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final native void _gtk_cell_renderer_get_size(long paramLong1, long paramLong2, GdkRectangle paramGdkRectangle, int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3, int[] paramArrayOfInt4);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void gtk_cell_renderer_get_size(long cell, long widget, GdkRectangle area, int[] x_offset, int[] y_offset, int[] width, int[] height)
/*      */   {
/* 1061 */     lock.lock();
/*      */     try {
/* 1063 */       _gtk_cell_renderer_get_size(cell, widget, area, x_offset, y_offset, width, height);
/*      */     } finally {
/* 1065 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final native void _gtk_cell_renderer_get_preferred_size(long paramLong1, long paramLong2, GtkRequisition paramGtkRequisition1, GtkRequisition paramGtkRequisition2);
/*      */   
/*      */ 
/*      */ 
/*      */   public static final void gtk_cell_renderer_get_preferred_size(long cell, long widget, GtkRequisition minimum_size, GtkRequisition natural_size)
/*      */   {
/* 1077 */     lock.lock();
/*      */     try {
/* 1079 */       _gtk_cell_renderer_get_preferred_size(cell, widget, minimum_size, natural_size);
/*      */     } finally {
/* 1081 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_cell_renderer_get_preferred_height_for_width(long paramLong1, long paramLong2, int paramInt, int[] paramArrayOfInt1, int[] paramArrayOfInt2);
/*      */   
/*      */   public static final void gtk_cell_renderer_get_preferred_height_for_width(long cell, long widget, int width, int[] minimum_height, int[] natural_height)
/*      */   {
/* 1090 */     lock.lock();
/*      */     try {
/* 1092 */       _gtk_cell_renderer_get_preferred_height_for_width(cell, widget, width, minimum_height, natural_height);
/*      */     } finally {
/* 1094 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_cell_renderer_set_fixed_size(long paramLong, int paramInt1, int paramInt2);
/*      */   
/*      */ 
/*      */   public static final void gtk_cell_renderer_set_fixed_size(long cell, int width, int height)
/*      */   {
/* 1104 */     lock.lock();
/*      */     try {
/* 1106 */       _gtk_cell_renderer_set_fixed_size(cell, width, height);
/*      */     } finally {
/* 1108 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_cell_renderer_get_fixed_size(long paramLong, int[] paramArrayOfInt1, int[] paramArrayOfInt2);
/*      */   
/*      */ 
/*      */   public static final void gtk_cell_renderer_get_fixed_size(long cell, int[] width, int[] height)
/*      */   {
/* 1118 */     lock.lock();
/*      */     try {
/* 1120 */       _gtk_cell_renderer_get_fixed_size(cell, width, height);
/*      */     } finally {
/* 1122 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final native void _gtk_widget_get_preferred_size(long paramLong, GtkRequisition paramGtkRequisition1, GtkRequisition paramGtkRequisition2);
/*      */   
/*      */ 
/*      */   public static final void gtk_widget_get_preferred_size(long widget, GtkRequisition minimum_size, GtkRequisition natural_size)
/*      */   {
/* 1133 */     lock.lock();
/*      */     try {
/* 1135 */       _gtk_widget_get_preferred_size(widget, minimum_size, natural_size);
/*      */     } finally {
/* 1137 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_widget_get_preferred_height_for_width(long paramLong, int paramInt, int[] paramArrayOfInt1, int[] paramArrayOfInt2);
/*      */   
/*      */   public static final void gtk_widget_get_preferred_height_for_width(long widget, int width, int[] minimum_size, int[] natural_size)
/*      */   {
/* 1145 */     lock.lock();
/*      */     try {
/* 1147 */       _gtk_widget_get_preferred_height_for_width(widget, width, minimum_size, natural_size);
/*      */     } finally {
/* 1149 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_widget_get_preferred_height(long paramLong, int[] paramArrayOfInt1, int[] paramArrayOfInt2);
/*      */   
/*      */   public static final void gtk_widget_get_preferred_height(long widget, int[] minimum_size, int[] natural_size)
/*      */   {
/* 1157 */     lock.lock();
/*      */     try {
/* 1159 */       _gtk_widget_get_preferred_height(widget, minimum_size, natural_size);
/*      */     } finally {
/* 1161 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_widget_get_preferred_width_for_height(long paramLong, int paramInt, int[] paramArrayOfInt1, int[] paramArrayOfInt2);
/*      */   
/*      */   public static final void gtk_widget_get_preferred_width_for_height(long widget, int height, int[] minimum_size, int[] natural_size)
/*      */   {
/* 1169 */     lock.lock();
/*      */     try {
/* 1171 */       _gtk_widget_get_preferred_width_for_height(widget, height, minimum_size, natural_size);
/*      */     } finally {
/* 1173 */       lock.unlock();
/*      */     } }
/*      */   
/*      */   public static final native long _gtk_cell_renderer_pixbuf_new();
/*      */   
/* 1178 */   public static final long gtk_cell_renderer_pixbuf_new() { lock.lock();
/*      */     try {
/* 1180 */       return _gtk_cell_renderer_pixbuf_new();
/*      */     } finally {
/* 1182 */       lock.unlock();
/*      */     } }
/*      */   
/*      */   public static final native long _gtk_cell_renderer_text_new();
/*      */   
/* 1187 */   public static final long gtk_cell_renderer_text_new() { lock.lock();
/*      */     try {
/* 1189 */       return _gtk_cell_renderer_text_new();
/*      */     } finally {
/* 1191 */       lock.unlock();
/*      */     } }
/*      */   
/*      */   public static final native long _gtk_cell_renderer_toggle_new();
/*      */   
/* 1196 */   public static final long gtk_cell_renderer_toggle_new() { lock.lock();
/*      */     try {
/* 1198 */       return _gtk_cell_renderer_toggle_new();
/*      */     } finally {
/* 1200 */       lock.unlock();
/*      */     } }
/*      */   
/*      */   public static final native long _gtk_check_button_new();
/*      */   
/* 1205 */   public static final long gtk_check_button_new() { lock.lock();
/*      */     try {
/* 1207 */       return _gtk_check_button_new();
/*      */     } finally {
/* 1209 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native boolean _gtk_check_menu_item_get_active(long paramLong);
/*      */   
/* 1215 */   public static final boolean gtk_check_menu_item_get_active(long check_menu_item) { lock.lock();
/*      */     try {
/* 1217 */       return _gtk_check_menu_item_get_active(check_menu_item);
/*      */     } finally {
/* 1219 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native long _gtk_image_menu_item_new_with_label(byte[] paramArrayOfByte);
/*      */   
/*      */ 
/*      */   public static final long gtk_image_menu_item_new_with_label(byte[] label)
/*      */   {
/* 1229 */     lock.lock();
/*      */     try {
/* 1231 */       return _gtk_image_menu_item_new_with_label(label);
/*      */     } finally {
/* 1233 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gtk_check_menu_item_new_with_label(byte[] paramArrayOfByte);
/*      */   
/* 1239 */   public static final long gtk_check_menu_item_new_with_label(byte[] label) { lock.lock();
/*      */     try {
/* 1241 */       return _gtk_check_menu_item_new_with_label(label);
/*      */     } finally {
/* 1243 */       lock.unlock();
/*      */     } }
/*      */   
/*      */   public static final native long _gtk_check_menu_item_new();
/*      */   
/* 1248 */   public static final long gtk_check_menu_item_new() { lock.lock();
/*      */     try {
/* 1250 */       return _gtk_check_menu_item_new();
/*      */     } finally {
/* 1252 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_check_menu_item_set_active(long paramLong, boolean paramBoolean);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_check_menu_item_set_active(long wid, boolean active)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 90	org/eclipse/swt/internal/gtk/GTK:_gtk_check_menu_item_set_active	(JZ)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #1261	-> byte code offset #0
/*      */     //   Java source line #1263	-> byte code offset #7
/*      */     //   Java source line #1265	-> byte code offset #12
/*      */     //   Java source line #1266	-> byte code offset #18
/*      */     //   Java source line #1265	-> byte code offset #21
/*      */     //   Java source line #1266	-> byte code offset #28
/*      */     //   Java source line #1267	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	wid	long
/*      */     //   0	31	2	active	boolean
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native long _gtk_check_version(int paramInt1, int paramInt2, int paramInt3);
/*      */   
/*      */   public static final long gtk_check_version(int required_major, int required_minor, int required_micro)
/*      */   {
/* 1270 */     lock.lock();
/*      */     try {
/* 1272 */       return _gtk_check_version(required_major, required_minor, required_micro);
/*      */     } finally {
/* 1274 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_clipboard_clear(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_clipboard_clear(long clipboard)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 92	org/eclipse/swt/internal/gtk/GTK:_gtk_clipboard_clear	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #1280	-> byte code offset #0
/*      */     //   Java source line #1282	-> byte code offset #7
/*      */     //   Java source line #1284	-> byte code offset #11
/*      */     //   Java source line #1285	-> byte code offset #17
/*      */     //   Java source line #1284	-> byte code offset #20
/*      */     //   Java source line #1285	-> byte code offset #27
/*      */     //   Java source line #1286	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	clipboard	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native long _gtk_clipboard_get(long paramLong);
/*      */   
/*      */   public static final long gtk_clipboard_get(long selection)
/*      */   {
/* 1290 */     lock.lock();
/*      */     try {
/* 1292 */       return _gtk_clipboard_get(selection);
/*      */     } finally {
/* 1294 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final native boolean _gtk_clipboard_set_with_owner(long paramLong1, long paramLong2, int paramInt, long paramLong3, long paramLong4, long paramLong5);
/*      */   
/*      */ 
/*      */ 
/*      */   public static final boolean gtk_clipboard_set_with_owner(long clipboard, long target, int n_targets, long get_func, long clear_func, long user_data)
/*      */   {
/* 1307 */     lock.lock();
/*      */     try {
/* 1309 */       return _gtk_clipboard_set_with_owner(clipboard, target, n_targets, get_func, clear_func, user_data);
/*      */     } finally {
/* 1311 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_clipboard_set_can_store(long paramLong1, long paramLong2, int paramInt);
/*      */   
/*      */ 
/*      */   public static final void gtk_clipboard_set_can_store(long clipboard, long targets, int n_targets)
/*      */   {
/* 1321 */     lock.lock();
/*      */     try {
/* 1323 */       _gtk_clipboard_set_can_store(clipboard, targets, n_targets);
/*      */     } finally {
/* 1325 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_clipboard_store(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_clipboard_store(long clipboard)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 96	org/eclipse/swt/internal/gtk/GTK:_gtk_clipboard_store	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #1333	-> byte code offset #0
/*      */     //   Java source line #1335	-> byte code offset #7
/*      */     //   Java source line #1337	-> byte code offset #11
/*      */     //   Java source line #1338	-> byte code offset #17
/*      */     //   Java source line #1337	-> byte code offset #20
/*      */     //   Java source line #1338	-> byte code offset #27
/*      */     //   Java source line #1339	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	clipboard	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native long _gtk_clipboard_wait_for_contents(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final long gtk_clipboard_wait_for_contents(long clipboard, long target)
/*      */   {
/* 1346 */     lock.lock();
/*      */     try {
/* 1348 */       return _gtk_clipboard_wait_for_contents(clipboard, target);
/*      */     } finally {
/* 1350 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native long _gtk_color_selection_dialog_new(byte[] paramArrayOfByte);
/*      */   
/*      */ 
/*      */   public static final long gtk_color_selection_dialog_new(byte[] title)
/*      */   {
/* 1360 */     lock.lock();
/*      */     try {
/* 1362 */       return _gtk_color_selection_dialog_new(title);
/*      */     } finally {
/* 1364 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final native long _gtk_color_chooser_add_palette(long paramLong1, int paramInt1, int paramInt2, int paramInt3, long paramLong2);
/*      */   
/*      */ 
/*      */   public static final long gtk_color_chooser_add_palette(long chooser, int orientation, int colors_per_line, int n_colors, long colors)
/*      */   {
/* 1375 */     lock.lock();
/*      */     try {
/* 1377 */       return _gtk_color_chooser_add_palette(chooser, orientation, colors_per_line, n_colors, colors);
/*      */     } finally {
/* 1379 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native long _gtk_color_chooser_dialog_new(byte[] paramArrayOfByte, long paramLong);
/*      */   
/*      */ 
/*      */   public static final long gtk_color_chooser_dialog_new(byte[] title, long parent)
/*      */   {
/* 1389 */     lock.lock();
/*      */     try {
/* 1391 */       return _gtk_color_chooser_dialog_new(title, parent);
/*      */     } finally {
/* 1393 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_color_chooser_set_use_alpha(long paramLong, boolean paramBoolean);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_color_chooser_set_use_alpha(long chooser, boolean use_alpha)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 101	org/eclipse/swt/internal/gtk/GTK:_gtk_color_chooser_set_use_alpha	(JZ)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #1401	-> byte code offset #0
/*      */     //   Java source line #1403	-> byte code offset #7
/*      */     //   Java source line #1405	-> byte code offset #12
/*      */     //   Java source line #1406	-> byte code offset #18
/*      */     //   Java source line #1405	-> byte code offset #21
/*      */     //   Java source line #1406	-> byte code offset #28
/*      */     //   Java source line #1407	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	chooser	long
/*      */     //   0	31	2	use_alpha	boolean
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native boolean _gtk_color_chooser_get_use_alpha(long paramLong);
/*      */   
/*      */   public static final boolean gtk_color_chooser_get_use_alpha(long chooser)
/*      */   {
/* 1413 */     lock.lock();
/*      */     try {
/* 1415 */       return _gtk_color_chooser_get_use_alpha(chooser);
/*      */     } finally {
/* 1417 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native long _gtk_color_selection_dialog_get_color_selection(long paramLong);
/*      */   
/*      */ 
/*      */   public static final long gtk_color_selection_dialog_get_color_selection(long color_dialog)
/*      */   {
/* 1427 */     lock.lock();
/*      */     try {
/* 1429 */       return _gtk_color_selection_dialog_get_color_selection(color_dialog);
/*      */     } finally {
/* 1431 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_color_chooser_set_rgba(long paramLong, GdkRGBA paramGdkRGBA);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_color_chooser_get_rgba(long chooser, GdkRGBA color)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: aload_2
/*      */     //   9: invokestatic 104	org/eclipse/swt/internal/gtk/GTK:_gtk_color_chooser_get_rgba	(JLorg/eclipse/swt/internal/gtk/GdkRGBA;)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #1439	-> byte code offset #0
/*      */     //   Java source line #1441	-> byte code offset #7
/*      */     //   Java source line #1443	-> byte code offset #12
/*      */     //   Java source line #1444	-> byte code offset #18
/*      */     //   Java source line #1443	-> byte code offset #21
/*      */     //   Java source line #1444	-> byte code offset #28
/*      */     //   Java source line #1445	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	chooser	long
/*      */     //   0	31	2	color	GdkRGBA
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_color_chooser_get_rgba(long paramLong, GdkRGBA paramGdkRGBA);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_color_chooser_set_rgba(long chooser, GdkRGBA color)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: aload_2
/*      */     //   9: invokestatic 105	org/eclipse/swt/internal/gtk/GTK:_gtk_color_chooser_set_rgba	(JLorg/eclipse/swt/internal/gtk/GdkRGBA;)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #1451	-> byte code offset #0
/*      */     //   Java source line #1453	-> byte code offset #7
/*      */     //   Java source line #1455	-> byte code offset #12
/*      */     //   Java source line #1456	-> byte code offset #18
/*      */     //   Java source line #1455	-> byte code offset #21
/*      */     //   Java source line #1456	-> byte code offset #28
/*      */     //   Java source line #1457	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	chooser	long
/*      */     //   0	31	2	color	GdkRGBA
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_color_selection_get_current_color(long paramLong, GdkColor paramGdkColor);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_color_selection_get_current_color(long colorsel, GdkColor color)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: aload_2
/*      */     //   9: invokestatic 106	org/eclipse/swt/internal/gtk/GTK:_gtk_color_selection_get_current_color	(JLorg/eclipse/swt/internal/gtk/GdkColor;)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #1465	-> byte code offset #0
/*      */     //   Java source line #1467	-> byte code offset #7
/*      */     //   Java source line #1469	-> byte code offset #12
/*      */     //   Java source line #1470	-> byte code offset #18
/*      */     //   Java source line #1469	-> byte code offset #21
/*      */     //   Java source line #1470	-> byte code offset #28
/*      */     //   Java source line #1471	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	colorsel	long
/*      */     //   0	31	2	color	GdkColor
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native long _gtk_color_selection_palette_to_string(long paramLong, int paramInt);
/*      */   
/*      */   public static final long gtk_color_selection_palette_to_string(long colors, int n_colors)
/*      */   {
/* 1476 */     lock.lock();
/*      */     try {
/* 1478 */       return _gtk_color_selection_palette_to_string(colors, n_colors);
/*      */     } finally {
/* 1480 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_color_selection_set_current_color(long paramLong, GdkColor paramGdkColor);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_color_selection_set_current_color(long colorsel, GdkColor color)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: aload_2
/*      */     //   9: invokestatic 108	org/eclipse/swt/internal/gtk/GTK:_gtk_color_selection_set_current_color	(JLorg/eclipse/swt/internal/gtk/GdkColor;)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #1490	-> byte code offset #0
/*      */     //   Java source line #1492	-> byte code offset #7
/*      */     //   Java source line #1494	-> byte code offset #12
/*      */     //   Java source line #1495	-> byte code offset #18
/*      */     //   Java source line #1494	-> byte code offset #21
/*      */     //   Java source line #1495	-> byte code offset #28
/*      */     //   Java source line #1496	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	colorsel	long
/*      */     //   0	31	2	color	GdkColor
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_color_selection_set_has_palette(long paramLong, boolean paramBoolean);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_color_selection_set_has_palette(long colorsel, boolean has_palette)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 109	org/eclipse/swt/internal/gtk/GTK:_gtk_color_selection_set_has_palette	(JZ)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #1501	-> byte code offset #0
/*      */     //   Java source line #1503	-> byte code offset #7
/*      */     //   Java source line #1505	-> byte code offset #12
/*      */     //   Java source line #1506	-> byte code offset #18
/*      */     //   Java source line #1505	-> byte code offset #21
/*      */     //   Java source line #1506	-> byte code offset #28
/*      */     //   Java source line #1507	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	colorsel	long
/*      */     //   0	31	2	has_palette	boolean
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_combo_box_set_focus_on_click(long paramLong, boolean paramBoolean);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_combo_box_set_focus_on_click(long combo, boolean val)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 110	org/eclipse/swt/internal/gtk/GTK:_gtk_combo_box_set_focus_on_click	(JZ)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #1516	-> byte code offset #0
/*      */     //   Java source line #1518	-> byte code offset #7
/*      */     //   Java source line #1520	-> byte code offset #12
/*      */     //   Java source line #1521	-> byte code offset #18
/*      */     //   Java source line #1520	-> byte code offset #21
/*      */     //   Java source line #1521	-> byte code offset #28
/*      */     //   Java source line #1522	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	combo	long
/*      */     //   0	31	2	val	boolean
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native long _gtk_combo_box_text_new();
/*      */   
/*      */   public static final long gtk_combo_box_text_new()
/*      */   {
/* 1525 */     lock.lock();
/*      */     try {
/* 1527 */       return _gtk_combo_box_text_new();
/*      */     } finally {
/* 1529 */       lock.unlock();
/*      */     } }
/*      */   
/*      */   public static final native long _gtk_combo_box_text_new_with_entry();
/*      */   
/* 1534 */   public static final long gtk_combo_box_text_new_with_entry() { lock.lock();
/*      */     try {
/* 1536 */       return _gtk_combo_box_text_new_with_entry();
/*      */     } finally {
/* 1538 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_combo_box_text_insert(long paramLong, int paramInt, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2);
/*      */   
/* 1544 */   public static final void gtk_combo_box_text_insert(long combo_box, int position, byte[] id, byte[] text) { lock.lock();
/*      */     try {
/* 1546 */       _gtk_combo_box_text_insert(combo_box, position, id, text);
/*      */     } finally {
/* 1548 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_combo_box_text_insert_text(long paramLong, int paramInt, byte[] paramArrayOfByte);
/*      */   
/*      */ 
/*      */   public static final void gtk_combo_box_text_insert_text(long combo_box, int position, byte[] text)
/*      */   {
/* 1558 */     lock.lock();
/*      */     try {
/* 1560 */       _gtk_combo_box_text_insert_text(combo_box, position, text);
/*      */     } finally {
/* 1562 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_combo_box_text_remove(long paramLong, int paramInt);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_combo_box_text_remove(long combo_box, int position)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 115	org/eclipse/swt/internal/gtk/GTK:_gtk_combo_box_text_remove	(JI)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #1568	-> byte code offset #0
/*      */     //   Java source line #1570	-> byte code offset #7
/*      */     //   Java source line #1572	-> byte code offset #12
/*      */     //   Java source line #1573	-> byte code offset #18
/*      */     //   Java source line #1572	-> byte code offset #21
/*      */     //   Java source line #1573	-> byte code offset #28
/*      */     //   Java source line #1574	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	combo_box	long
/*      */     //   0	31	2	position	int
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_combo_box_text_remove_all(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_combo_box_text_remove_all(long combo_box)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 116	org/eclipse/swt/internal/gtk/GTK:_gtk_combo_box_text_remove_all	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #1578	-> byte code offset #0
/*      */     //   Java source line #1580	-> byte code offset #7
/*      */     //   Java source line #1582	-> byte code offset #11
/*      */     //   Java source line #1583	-> byte code offset #17
/*      */     //   Java source line #1582	-> byte code offset #20
/*      */     //   Java source line #1583	-> byte code offset #27
/*      */     //   Java source line #1584	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	combo_box	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native int _gtk_combo_box_get_active(long paramLong);
/*      */   
/*      */   public static final int gtk_combo_box_get_active(long combo_box)
/*      */   {
/* 1590 */     lock.lock();
/*      */     try {
/* 1592 */       return _gtk_combo_box_get_active(combo_box);
/*      */     } finally {
/* 1594 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gtk_combo_box_get_model(long paramLong);
/*      */   
/*      */   public static final long gtk_combo_box_get_model(long combo_box)
/*      */   {
/* 1602 */     lock.lock();
/*      */     try {
/* 1604 */       return _gtk_combo_box_get_model(combo_box);
/*      */     } finally {
/* 1606 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_combo_box_set_active(long paramLong, int paramInt);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_combo_box_set_active(long combo_box, int index)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 119	org/eclipse/swt/internal/gtk/GTK:_gtk_combo_box_set_active	(JI)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #1615	-> byte code offset #0
/*      */     //   Java source line #1617	-> byte code offset #7
/*      */     //   Java source line #1619	-> byte code offset #12
/*      */     //   Java source line #1620	-> byte code offset #18
/*      */     //   Java source line #1619	-> byte code offset #21
/*      */     //   Java source line #1620	-> byte code offset #28
/*      */     //   Java source line #1621	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	combo_box	long
/*      */     //   0	31	2	index	int
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_combo_box_set_wrap_width(long paramLong, int paramInt);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_combo_box_set_wrap_width(long combo_box, int width)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 120	org/eclipse/swt/internal/gtk/GTK:_gtk_combo_box_set_wrap_width	(JI)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #1628	-> byte code offset #0
/*      */     //   Java source line #1630	-> byte code offset #7
/*      */     //   Java source line #1632	-> byte code offset #12
/*      */     //   Java source line #1633	-> byte code offset #18
/*      */     //   Java source line #1632	-> byte code offset #21
/*      */     //   Java source line #1633	-> byte code offset #28
/*      */     //   Java source line #1634	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	combo_box	long
/*      */     //   0	31	2	width	int
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_combo_box_popup(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_combo_box_popup(long combo_box)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 121	org/eclipse/swt/internal/gtk/GTK:_gtk_combo_box_popup	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #1640	-> byte code offset #0
/*      */     //   Java source line #1642	-> byte code offset #7
/*      */     //   Java source line #1644	-> byte code offset #11
/*      */     //   Java source line #1645	-> byte code offset #17
/*      */     //   Java source line #1644	-> byte code offset #20
/*      */     //   Java source line #1645	-> byte code offset #27
/*      */     //   Java source line #1646	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	combo_box	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_combo_box_popdown(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_combo_box_popdown(long combo_box)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 122	org/eclipse/swt/internal/gtk/GTK:_gtk_combo_box_popdown	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #1652	-> byte code offset #0
/*      */     //   Java source line #1654	-> byte code offset #7
/*      */     //   Java source line #1656	-> byte code offset #11
/*      */     //   Java source line #1657	-> byte code offset #17
/*      */     //   Java source line #1656	-> byte code offset #20
/*      */     //   Java source line #1657	-> byte code offset #27
/*      */     //   Java source line #1658	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	combo_box	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_container_add(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final void gtk_container_add(long container, long widget)
/*      */   {
/* 1665 */     lock.lock();
/*      */     try {
/* 1667 */       _gtk_container_add(container, widget);
/*      */     } finally {
/* 1669 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final native void _gtk_container_forall(long paramLong1, long paramLong2, long paramLong3);
/*      */   
/*      */ 
/*      */ 
/*      */   public static final void gtk_container_forall(long container, long callback, long callback_data)
/*      */   {
/* 1682 */     lock.lock();
/*      */     try {
/* 1684 */       _gtk_container_forall(container, callback, callback_data);
/*      */     } finally {
/* 1686 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final native void _gtk_container_propagate_draw(long paramLong1, long paramLong2, long paramLong3);
/*      */   
/*      */ 
/*      */   public static final void gtk_container_propagate_draw(long container, long child, long cairo)
/*      */   {
/* 1697 */     lock.lock();
/*      */     try {
/* 1699 */       _gtk_container_propagate_draw(container, child, cairo);
/*      */     } finally {
/* 1701 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native int _gtk_container_get_border_width(long paramLong);
/*      */   
/* 1707 */   public static final int gtk_container_get_border_width(long container) { lock.lock();
/*      */     try {
/* 1709 */       return _gtk_container_get_border_width(container);
/*      */     } finally {
/* 1711 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gtk_container_get_children(long paramLong);
/*      */   
/* 1717 */   public static final long gtk_container_get_children(long container) { lock.lock();
/*      */     try {
/* 1719 */       return _gtk_container_get_children(container);
/*      */     } finally {
/* 1721 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_container_remove(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final void gtk_container_remove(long container, long widget)
/*      */   {
/* 1730 */     lock.lock();
/*      */     try {
/* 1732 */       _gtk_container_remove(container, widget);
/*      */     } finally {
/* 1734 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_container_set_border_width(long paramLong, int paramInt);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_container_set_border_width(long container, int border_width)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 129	org/eclipse/swt/internal/gtk/GTK:_gtk_container_set_border_width	(JI)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #1743	-> byte code offset #0
/*      */     //   Java source line #1745	-> byte code offset #7
/*      */     //   Java source line #1747	-> byte code offset #12
/*      */     //   Java source line #1748	-> byte code offset #18
/*      */     //   Java source line #1747	-> byte code offset #21
/*      */     //   Java source line #1748	-> byte code offset #28
/*      */     //   Java source line #1749	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	container	long
/*      */     //   0	31	2	border_width	int
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native long _gtk_dialog_add_button(long paramLong, byte[] paramArrayOfByte, int paramInt);
/*      */   
/*      */   public static final long gtk_dialog_add_button(long dialog, byte[] button_text, int response_id)
/*      */   {
/* 1757 */     lock.lock();
/*      */     try {
/* 1759 */       return _gtk_dialog_add_button(dialog, button_text, response_id);
/*      */     } finally {
/* 1761 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native int _gtk_dialog_run(long paramLong);
/*      */   
/* 1767 */   public static final int gtk_dialog_run(long dialog) { lock.lock();
/*      */     try {
/* 1769 */       return _gtk_dialog_run(dialog);
/*      */     } finally {
/* 1771 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final native long _gtk_drag_begin(long paramLong1, long paramLong2, int paramInt1, int paramInt2, long paramLong3);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long gtk_drag_begin(long widget, long targets, int actions, int button, long event)
/*      */   {
/* 1785 */     lock.lock();
/*      */     try {
/* 1787 */       return _gtk_drag_begin(widget, targets, actions, button, event);
/*      */     } finally {
/* 1789 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final native long _gtk_drag_begin_with_coordinates(long paramLong1, long paramLong2, int paramInt1, int paramInt2, long paramLong3, int paramInt3, int paramInt4);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final long gtk_drag_begin_with_coordinates(long widget, long targets, int actions, int button, long event, int x, int y)
/*      */   {
/* 1804 */     lock.lock();
/*      */     try {
/* 1806 */       return _gtk_drag_begin_with_coordinates(widget, targets, actions, button, event, x, y);
/*      */     } finally {
/* 1808 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final native boolean _gtk_drag_check_threshold(long paramLong, int paramInt1, int paramInt2, int paramInt3, int paramInt4);
/*      */   
/*      */ 
/*      */ 
/*      */   public static final boolean gtk_drag_check_threshold(long widget, int start_x, int start_y, int current_x, int current_y)
/*      */   {
/* 1820 */     lock.lock();
/*      */     try {
/* 1822 */       return _gtk_drag_check_threshold(widget, start_x, start_y, current_x, current_y);
/*      */     } finally {
/* 1824 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native long _gtk_drag_dest_find_target(long paramLong1, long paramLong2, long paramLong3);
/*      */   
/*      */ 
/*      */   public static final long gtk_drag_dest_find_target(long widget, long context, long target_list)
/*      */   {
/* 1834 */     lock.lock();
/*      */     try {
/* 1836 */       return _gtk_drag_dest_find_target(widget, context, target_list);
/*      */     } finally {
/* 1838 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final native void _gtk_drag_dest_set(long paramLong1, int paramInt1, long paramLong2, int paramInt2, int paramInt3);
/*      */   
/*      */ 
/*      */ 
/*      */   public static final void gtk_drag_dest_set(long widget, int flags, long targets, int n_targets, int actions)
/*      */   {
/* 1850 */     lock.lock();
/*      */     try {
/* 1852 */       _gtk_drag_dest_set(widget, flags, targets, n_targets, actions);
/*      */     } finally {
/* 1854 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_drag_dest_unset(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_drag_dest_unset(long widget)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 137	org/eclipse/swt/internal/gtk/GTK:_gtk_drag_dest_unset	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #1860	-> byte code offset #0
/*      */     //   Java source line #1862	-> byte code offset #7
/*      */     //   Java source line #1864	-> byte code offset #11
/*      */     //   Java source line #1865	-> byte code offset #17
/*      */     //   Java source line #1864	-> byte code offset #20
/*      */     //   Java source line #1865	-> byte code offset #27
/*      */     //   Java source line #1866	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	widget	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_drag_finish(long paramLong, boolean paramBoolean1, boolean paramBoolean2, int paramInt);
/*      */   
/*      */   public static final void gtk_drag_finish(long context, boolean success, boolean delete, int time)
/*      */   {
/* 1875 */     lock.lock();
/*      */     try {
/* 1877 */       _gtk_drag_finish(context, success, delete, time);
/*      */     } finally {
/* 1879 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final native void _gtk_drag_get_data(long paramLong1, long paramLong2, long paramLong3, int paramInt);
/*      */   
/*      */ 
/*      */   public static final void gtk_drag_get_data(long widget, long context, long target, int time)
/*      */   {
/* 1890 */     lock.lock();
/*      */     try {
/* 1892 */       _gtk_drag_get_data(widget, context, target, time);
/*      */     } finally {
/* 1894 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_drag_set_icon_pixbuf(long paramLong1, long paramLong2, int paramInt1, int paramInt2);
/*      */   
/*      */   public static final void gtk_drag_set_icon_pixbuf(long context, long pixbuf, int hot_x, int hot_y)
/*      */   {
/* 1903 */     lock.lock();
/*      */     try {
/* 1905 */       _gtk_drag_set_icon_pixbuf(context, pixbuf, hot_x, hot_y);
/*      */     } finally {
/* 1907 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_drag_set_icon_surface(long paramLong1, long paramLong2);
/*      */   
/* 1913 */   public static final void gtk_drag_set_icon_surface(long context, long surface) { lock.lock();
/*      */     try {
/* 1915 */       _gtk_drag_set_icon_surface(context, surface);
/*      */     } finally {
/* 1917 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_editable_copy_clipboard(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_editable_copy_clipboard(long editable)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 142	org/eclipse/swt/internal/gtk/GTK:_gtk_editable_copy_clipboard	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #1923	-> byte code offset #0
/*      */     //   Java source line #1925	-> byte code offset #7
/*      */     //   Java source line #1927	-> byte code offset #11
/*      */     //   Java source line #1928	-> byte code offset #17
/*      */     //   Java source line #1927	-> byte code offset #20
/*      */     //   Java source line #1928	-> byte code offset #27
/*      */     //   Java source line #1929	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	editable	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_editable_cut_clipboard(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_editable_cut_clipboard(long editable)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 143	org/eclipse/swt/internal/gtk/GTK:_gtk_editable_cut_clipboard	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #1933	-> byte code offset #0
/*      */     //   Java source line #1935	-> byte code offset #7
/*      */     //   Java source line #1937	-> byte code offset #11
/*      */     //   Java source line #1938	-> byte code offset #17
/*      */     //   Java source line #1937	-> byte code offset #20
/*      */     //   Java source line #1938	-> byte code offset #27
/*      */     //   Java source line #1939	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	editable	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_editable_delete_selection(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_editable_delete_selection(long editable)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 144	org/eclipse/swt/internal/gtk/GTK:_gtk_editable_delete_selection	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #1943	-> byte code offset #0
/*      */     //   Java source line #1945	-> byte code offset #7
/*      */     //   Java source line #1947	-> byte code offset #11
/*      */     //   Java source line #1948	-> byte code offset #17
/*      */     //   Java source line #1947	-> byte code offset #20
/*      */     //   Java source line #1948	-> byte code offset #27
/*      */     //   Java source line #1949	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	editable	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_editable_delete_text(long paramLong, int paramInt1, int paramInt2);
/*      */   
/*      */   public static final void gtk_editable_delete_text(long editable, int start_pos, int end_pos)
/*      */   {
/* 1957 */     lock.lock();
/*      */     try {
/* 1959 */       _gtk_editable_delete_text(editable, start_pos, end_pos);
/*      */     } finally {
/* 1961 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native boolean _gtk_editable_get_editable(long paramLong);
/*      */   
/* 1967 */   public static final boolean gtk_editable_get_editable(long editable) { lock.lock();
/*      */     try {
/* 1969 */       return _gtk_editable_get_editable(editable);
/*      */     } finally {
/* 1971 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native int _gtk_editable_get_position(long paramLong);
/*      */   
/* 1977 */   public static final int gtk_editable_get_position(long editable) { lock.lock();
/*      */     try {
/* 1979 */       return _gtk_editable_get_position(editable);
/*      */     } finally {
/* 1981 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native boolean _gtk_editable_get_selection_bounds(long paramLong, int[] paramArrayOfInt1, int[] paramArrayOfInt2);
/*      */   
/*      */ 
/*      */   public static final boolean gtk_editable_get_selection_bounds(long editable, int[] start, int[] end)
/*      */   {
/* 1991 */     lock.lock();
/*      */     try {
/* 1993 */       return _gtk_editable_get_selection_bounds(editable, start, end);
/*      */     } finally {
/* 1995 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final native void _gtk_editable_insert_text(long paramLong, byte[] paramArrayOfByte, int paramInt, int[] paramArrayOfInt);
/*      */   
/*      */ 
/*      */   public static final void gtk_editable_insert_text(long editable, byte[] new_text, int new_text_length, int[] position)
/*      */   {
/* 2006 */     lock.lock();
/*      */     try {
/* 2008 */       _gtk_editable_insert_text(editable, new_text, new_text_length, position);
/*      */     } finally {
/* 2010 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_editable_paste_clipboard(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_editable_paste_clipboard(long editable)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 150	org/eclipse/swt/internal/gtk/GTK:_gtk_editable_paste_clipboard	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #2016	-> byte code offset #0
/*      */     //   Java source line #2018	-> byte code offset #7
/*      */     //   Java source line #2020	-> byte code offset #11
/*      */     //   Java source line #2021	-> byte code offset #17
/*      */     //   Java source line #2020	-> byte code offset #20
/*      */     //   Java source line #2021	-> byte code offset #27
/*      */     //   Java source line #2022	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	editable	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_editable_select_region(long paramLong, int paramInt1, int paramInt2);
/*      */   
/*      */   public static final void gtk_editable_select_region(long editable, int start, int end)
/*      */   {
/* 2030 */     lock.lock();
/*      */     try {
/* 2032 */       _gtk_editable_select_region(editable, start, end);
/*      */     } finally {
/* 2034 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_editable_set_editable(long paramLong, boolean paramBoolean);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_editable_set_editable(long entry, boolean editable)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 152	org/eclipse/swt/internal/gtk/GTK:_gtk_editable_set_editable	(JZ)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #2043	-> byte code offset #0
/*      */     //   Java source line #2045	-> byte code offset #7
/*      */     //   Java source line #2047	-> byte code offset #12
/*      */     //   Java source line #2048	-> byte code offset #18
/*      */     //   Java source line #2047	-> byte code offset #21
/*      */     //   Java source line #2048	-> byte code offset #28
/*      */     //   Java source line #2049	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	entry	long
/*      */     //   0	31	2	editable	boolean
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_editable_set_position(long paramLong, int paramInt);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_editable_set_position(long editable, int position)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 153	org/eclipse/swt/internal/gtk/GTK:_gtk_editable_set_position	(JI)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #2056	-> byte code offset #0
/*      */     //   Java source line #2058	-> byte code offset #7
/*      */     //   Java source line #2060	-> byte code offset #12
/*      */     //   Java source line #2061	-> byte code offset #18
/*      */     //   Java source line #2060	-> byte code offset #21
/*      */     //   Java source line #2061	-> byte code offset #28
/*      */     //   Java source line #2062	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	editable	long
/*      */     //   0	31	2	position	int
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native long _gtk_entry_get_inner_border(long paramLong);
/*      */   
/*      */   public static final long gtk_entry_get_inner_border(long entry)
/*      */   {
/* 2067 */     lock.lock();
/*      */     try {
/* 2069 */       return _gtk_entry_get_inner_border(entry);
/*      */     } finally {
/* 2071 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_entry_set_width_chars(long paramLong, int paramInt);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_entry_set_width_chars(long self, int n_chars)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 155	org/eclipse/swt/internal/gtk/GTK:_gtk_entry_set_width_chars	(JI)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #2080	-> byte code offset #0
/*      */     //   Java source line #2082	-> byte code offset #7
/*      */     //   Java source line #2084	-> byte code offset #12
/*      */     //   Java source line #2085	-> byte code offset #18
/*      */     //   Java source line #2084	-> byte code offset #21
/*      */     //   Java source line #2085	-> byte code offset #28
/*      */     //   Java source line #2086	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	self	long
/*      */     //   0	31	2	n_chars	int
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native char _gtk_entry_get_invisible_char(long paramLong);
/*      */   
/*      */   public static final char gtk_entry_get_invisible_char(long entry)
/*      */   {
/* 2090 */     lock.lock();
/*      */     try {
/* 2092 */       return _gtk_entry_get_invisible_char(entry);
/*      */     } finally {
/* 2094 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gtk_entry_get_layout(long paramLong);
/*      */   
/* 2100 */   public static final long gtk_entry_get_layout(long entry) { lock.lock();
/*      */     try {
/* 2102 */       return _gtk_entry_get_layout(entry);
/*      */     } finally {
/* 2104 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_entry_get_layout_offsets(long paramLong, int[] paramArrayOfInt1, int[] paramArrayOfInt2);
/*      */   
/*      */ 
/*      */   public static final void gtk_entry_get_layout_offsets(long entry, int[] x, int[] y)
/*      */   {
/* 2114 */     lock.lock();
/*      */     try {
/* 2116 */       _gtk_entry_get_layout_offsets(entry, x, y);
/*      */     } finally {
/* 2118 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native int _gtk_entry_text_index_to_layout_index(long paramLong, int paramInt);
/*      */   
/*      */   public static final int gtk_entry_text_index_to_layout_index(long entry, int index)
/*      */   {
/* 2127 */     lock.lock();
/*      */     try {
/* 2129 */       return _gtk_entry_text_index_to_layout_index(entry, index);
/*      */     } finally {
/* 2131 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native int _gtk_entry_get_icon_area(long paramLong, int paramInt, GdkRectangle paramGdkRectangle);
/*      */   
/*      */   public static final int gtk_entry_get_icon_area(long entry, int icon_pos, GdkRectangle icon_area)
/*      */   {
/* 2140 */     lock.lock();
/*      */     try {
/* 2142 */       return _gtk_entry_get_icon_area(entry, icon_pos, icon_area);
/*      */     } finally {
/* 2144 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native int _gtk_entry_get_max_length(long paramLong);
/*      */   
/* 2150 */   public static final int gtk_entry_get_max_length(long entry) { lock.lock();
/*      */     try {
/* 2152 */       return _gtk_entry_get_max_length(entry);
/*      */     } finally {
/* 2154 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gtk_entry_get_text(long paramLong);
/*      */   
/* 2160 */   public static final long gtk_entry_get_text(long entry) { lock.lock();
/*      */     try {
/* 2162 */       return _gtk_entry_get_text(entry);
/*      */     } finally {
/* 2164 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native boolean _gtk_entry_get_visibility(long paramLong);
/*      */   
/* 2170 */   public static final boolean gtk_entry_get_visibility(long entry) { lock.lock();
/*      */     try {
/* 2172 */       return _gtk_entry_get_visibility(entry);
/*      */     } finally {
/* 2174 */       lock.unlock();
/*      */     } }
/*      */   
/*      */   public static final native long _gtk_entry_new();
/*      */   
/* 2179 */   public static final long gtk_entry_new() { lock.lock();
/*      */     try {
/* 2181 */       return _gtk_entry_new();
/*      */     } finally {
/* 2183 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_entry_set_alignment(long paramLong, float paramFloat);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_entry_set_alignment(long entry, float xalign)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: fload_2
/*      */     //   9: invokestatic 165	org/eclipse/swt/internal/gtk/GTK:_gtk_entry_set_alignment	(JF)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #2192	-> byte code offset #0
/*      */     //   Java source line #2194	-> byte code offset #7
/*      */     //   Java source line #2196	-> byte code offset #12
/*      */     //   Java source line #2197	-> byte code offset #18
/*      */     //   Java source line #2196	-> byte code offset #21
/*      */     //   Java source line #2197	-> byte code offset #28
/*      */     //   Java source line #2198	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	entry	long
/*      */     //   0	31	2	xalign	float
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_entry_set_has_frame(long paramLong, boolean paramBoolean);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_entry_set_has_frame(long entry, boolean setting)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 166	org/eclipse/swt/internal/gtk/GTK:_gtk_entry_set_has_frame	(JZ)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #2205	-> byte code offset #0
/*      */     //   Java source line #2207	-> byte code offset #7
/*      */     //   Java source line #2209	-> byte code offset #12
/*      */     //   Java source line #2210	-> byte code offset #18
/*      */     //   Java source line #2209	-> byte code offset #21
/*      */     //   Java source line #2210	-> byte code offset #28
/*      */     //   Java source line #2211	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	entry	long
/*      */     //   0	31	2	setting	boolean
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_entry_set_icon_from_icon_name(long paramLong, int paramInt, byte[] paramArrayOfByte);
/*      */   
/*      */   public static final void gtk_entry_set_icon_from_icon_name(long entry, int iconPos, byte[] iconName)
/*      */   {
/* 2219 */     lock.lock();
/*      */     try {
/* 2221 */       _gtk_entry_set_icon_from_icon_name(entry, iconPos, iconName);
/*      */     } finally {
/* 2223 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_entry_set_icon_sensitive(long paramLong, int paramInt, boolean paramBoolean);
/*      */   
/*      */ 
/*      */   public static final void gtk_entry_set_icon_sensitive(long entry, int icon_pos, boolean sensitive)
/*      */   {
/* 2233 */     lock.lock();
/*      */     try {
/* 2235 */       _gtk_entry_set_icon_sensitive(entry, icon_pos, sensitive);
/*      */     } finally {
/* 2237 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_entry_set_invisible_char(long paramLong, char paramChar);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_entry_set_invisible_char(long entry, char ch)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 169	org/eclipse/swt/internal/gtk/GTK:_gtk_entry_set_invisible_char	(JC)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #2246	-> byte code offset #0
/*      */     //   Java source line #2248	-> byte code offset #7
/*      */     //   Java source line #2250	-> byte code offset #12
/*      */     //   Java source line #2251	-> byte code offset #18
/*      */     //   Java source line #2250	-> byte code offset #21
/*      */     //   Java source line #2251	-> byte code offset #28
/*      */     //   Java source line #2252	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	entry	long
/*      */     //   0	31	2	ch	char
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_entry_set_max_length(long paramLong, int paramInt);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_entry_set_max_length(long entry, int max)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 170	org/eclipse/swt/internal/gtk/GTK:_gtk_entry_set_max_length	(JI)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #2259	-> byte code offset #0
/*      */     //   Java source line #2261	-> byte code offset #7
/*      */     //   Java source line #2263	-> byte code offset #12
/*      */     //   Java source line #2264	-> byte code offset #18
/*      */     //   Java source line #2263	-> byte code offset #21
/*      */     //   Java source line #2264	-> byte code offset #28
/*      */     //   Java source line #2265	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	entry	long
/*      */     //   0	31	2	max	int
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_entry_set_text(long paramLong, byte[] paramArrayOfByte);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_entry_set_text(long entry, byte[] text)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: aload_2
/*      */     //   9: invokestatic 171	org/eclipse/swt/internal/gtk/GTK:_gtk_entry_set_text	(J[B)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #2272	-> byte code offset #0
/*      */     //   Java source line #2274	-> byte code offset #7
/*      */     //   Java source line #2276	-> byte code offset #12
/*      */     //   Java source line #2277	-> byte code offset #18
/*      */     //   Java source line #2276	-> byte code offset #21
/*      */     //   Java source line #2277	-> byte code offset #28
/*      */     //   Java source line #2278	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	entry	long
/*      */     //   0	31	2	text	byte[]
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_entry_set_placeholder_text(long paramLong, byte[] paramArrayOfByte);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_entry_set_placeholder_text(long entry, byte[] text)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: aload_2
/*      */     //   9: invokestatic 172	org/eclipse/swt/internal/gtk/GTK:_gtk_entry_set_placeholder_text	(J[B)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #2286	-> byte code offset #0
/*      */     //   Java source line #2288	-> byte code offset #7
/*      */     //   Java source line #2290	-> byte code offset #12
/*      */     //   Java source line #2291	-> byte code offset #18
/*      */     //   Java source line #2290	-> byte code offset #21
/*      */     //   Java source line #2291	-> byte code offset #28
/*      */     //   Java source line #2292	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	entry	long
/*      */     //   0	31	2	text	byte[]
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_entry_set_visibility(long paramLong, boolean paramBoolean);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_entry_set_visibility(long entry, boolean visible)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 173	org/eclipse/swt/internal/gtk/GTK:_gtk_entry_set_visibility	(JZ)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #2299	-> byte code offset #0
/*      */     //   Java source line #2301	-> byte code offset #7
/*      */     //   Java source line #2303	-> byte code offset #12
/*      */     //   Java source line #2304	-> byte code offset #18
/*      */     //   Java source line #2303	-> byte code offset #21
/*      */     //   Java source line #2304	-> byte code offset #28
/*      */     //   Java source line #2305	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	entry	long
/*      */     //   0	31	2	visible	boolean
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native boolean _gtk_expander_get_expanded(long paramLong);
/*      */   
/*      */   public static final boolean gtk_expander_get_expanded(long expander)
/*      */   {
/* 2309 */     lock.lock();
/*      */     try {
/* 2311 */       return _gtk_expander_get_expanded(expander);
/*      */     } finally {
/* 2313 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gtk_expander_new(byte[] paramArrayOfByte);
/*      */   
/*      */   public static final long gtk_expander_new(byte[] label)
/*      */   {
/* 2321 */     lock.lock();
/*      */     try {
/* 2323 */       return _gtk_expander_new(label);
/*      */     } finally {
/* 2325 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_expander_set_expanded(long paramLong, boolean paramBoolean);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_expander_set_expanded(long expander, boolean expanded)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 176	org/eclipse/swt/internal/gtk/GTK:_gtk_expander_set_expanded	(JZ)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #2331	-> byte code offset #0
/*      */     //   Java source line #2333	-> byte code offset #7
/*      */     //   Java source line #2335	-> byte code offset #12
/*      */     //   Java source line #2336	-> byte code offset #18
/*      */     //   Java source line #2335	-> byte code offset #21
/*      */     //   Java source line #2336	-> byte code offset #28
/*      */     //   Java source line #2337	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	expander	long
/*      */     //   0	31	2	expanded	boolean
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_expander_set_label_widget(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final void gtk_expander_set_label_widget(long expander, long label_widget)
/*      */   {
/* 2344 */     lock.lock();
/*      */     try {
/* 2346 */       _gtk_expander_set_label_widget(expander, label_widget);
/*      */     } finally {
/* 2348 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_file_chooser_add_filter(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final void gtk_file_chooser_add_filter(long chooser, long filter)
/*      */   {
/* 2357 */     lock.lock();
/*      */     try {
/* 2359 */       _gtk_file_chooser_add_filter(chooser, filter);
/*      */     } finally {
/* 2361 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final native long _gtk_file_chooser_dialog_new(byte[] paramArrayOfByte1, long paramLong1, int paramInt1, byte[] paramArrayOfByte2, int paramInt2, byte[] paramArrayOfByte3, int paramInt3, long paramLong2);
/*      */   
/*      */ 
/*      */   public static final long gtk_file_chooser_dialog_new(byte[] title, long parent, int action, byte[] first_button_text, int first_button_id, byte[] second_button_text, int second_button_id, long terminator)
/*      */   {
/* 2372 */     lock.lock();
/*      */     try {
/* 2374 */       return _gtk_file_chooser_dialog_new(title, parent, action, first_button_text, first_button_id, second_button_text, second_button_id, terminator);
/*      */     } finally {
/* 2376 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final native long _gtk_file_chooser_dialog_new(byte[] paramArrayOfByte, long paramLong1, int paramInt1, long paramLong2, int paramInt2, long paramLong3, int paramInt3, long paramLong4);
/*      */   
/*      */ 
/*      */   public static final long gtk_file_chooser_dialog_new(byte[] title, long parent, int action, long first_button_text, int first_button_id, long second_button_text, int second_button_id, long terminator)
/*      */   {
/* 2387 */     lock.lock();
/*      */     try {
/* 2389 */       return _gtk_file_chooser_dialog_new(title, parent, action, first_button_text, first_button_id, second_button_text, second_button_id, terminator);
/*      */     } finally {
/* 2391 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gtk_file_chooser_get_filename(long paramLong);
/*      */   
/* 2397 */   public static final long gtk_file_chooser_get_filename(long chooser) { lock.lock();
/*      */     try {
/* 2399 */       return _gtk_file_chooser_get_filename(chooser);
/*      */     } finally {
/* 2401 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gtk_file_chooser_get_filenames(long paramLong);
/*      */   
/* 2407 */   public static final long gtk_file_chooser_get_filenames(long chooser) { lock.lock();
/*      */     try {
/* 2409 */       return _gtk_file_chooser_get_filenames(chooser);
/*      */     } finally {
/* 2411 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gtk_file_chooser_get_uri(long paramLong);
/*      */   
/* 2417 */   public static final long gtk_file_chooser_get_uri(long chooser) { lock.lock();
/*      */     try {
/* 2419 */       return _gtk_file_chooser_get_uri(chooser);
/*      */     } finally {
/* 2421 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gtk_file_chooser_get_uris(long paramLong);
/*      */   
/* 2427 */   public static final long gtk_file_chooser_get_uris(long chooser) { lock.lock();
/*      */     try {
/* 2429 */       return _gtk_file_chooser_get_uris(chooser);
/*      */     } finally {
/* 2431 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gtk_file_chooser_get_filter(long paramLong);
/*      */   
/* 2437 */   public static final long gtk_file_chooser_get_filter(long chooser) { lock.lock();
/*      */     try {
/* 2439 */       return _gtk_file_chooser_get_filter(chooser);
/*      */     } finally {
/* 2441 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_file_chooser_set_current_folder(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final void gtk_file_chooser_set_current_folder(long chooser, long filename)
/*      */   {
/* 2450 */     lock.lock();
/*      */     try {
/* 2452 */       _gtk_file_chooser_set_current_folder(chooser, filename);
/*      */     } finally {
/* 2454 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_file_chooser_set_current_folder_uri(long paramLong, byte[] paramArrayOfByte);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_file_chooser_set_current_folder_uri(long chooser, byte[] uri)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: aload_2
/*      */     //   9: invokestatic 187	org/eclipse/swt/internal/gtk/GTK:_gtk_file_chooser_set_current_folder_uri	(J[B)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #2463	-> byte code offset #0
/*      */     //   Java source line #2465	-> byte code offset #7
/*      */     //   Java source line #2467	-> byte code offset #12
/*      */     //   Java source line #2468	-> byte code offset #18
/*      */     //   Java source line #2467	-> byte code offset #21
/*      */     //   Java source line #2468	-> byte code offset #28
/*      */     //   Java source line #2469	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	chooser	long
/*      */     //   0	31	2	uri	byte[]
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_file_chooser_set_current_name(long paramLong, byte[] paramArrayOfByte);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_file_chooser_set_current_name(long chooser, byte[] name)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: aload_2
/*      */     //   9: invokestatic 188	org/eclipse/swt/internal/gtk/GTK:_gtk_file_chooser_set_current_name	(J[B)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #2476	-> byte code offset #0
/*      */     //   Java source line #2478	-> byte code offset #7
/*      */     //   Java source line #2480	-> byte code offset #12
/*      */     //   Java source line #2481	-> byte code offset #18
/*      */     //   Java source line #2480	-> byte code offset #21
/*      */     //   Java source line #2481	-> byte code offset #28
/*      */     //   Java source line #2482	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	chooser	long
/*      */     //   0	31	2	name	byte[]
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_file_chooser_set_local_only(long paramLong, boolean paramBoolean);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_file_chooser_set_local_only(long chooser, boolean local_only)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 189	org/eclipse/swt/internal/gtk/GTK:_gtk_file_chooser_set_local_only	(JZ)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #2489	-> byte code offset #0
/*      */     //   Java source line #2491	-> byte code offset #7
/*      */     //   Java source line #2493	-> byte code offset #12
/*      */     //   Java source line #2494	-> byte code offset #18
/*      */     //   Java source line #2493	-> byte code offset #21
/*      */     //   Java source line #2494	-> byte code offset #28
/*      */     //   Java source line #2495	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	chooser	long
/*      */     //   0	31	2	local_only	boolean
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_file_chooser_set_do_overwrite_confirmation(long paramLong, boolean paramBoolean);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_file_chooser_set_do_overwrite_confirmation(long chooser, boolean do_overwrite_confirmation)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 190	org/eclipse/swt/internal/gtk/GTK:_gtk_file_chooser_set_do_overwrite_confirmation	(JZ)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #2502	-> byte code offset #0
/*      */     //   Java source line #2504	-> byte code offset #7
/*      */     //   Java source line #2506	-> byte code offset #12
/*      */     //   Java source line #2507	-> byte code offset #18
/*      */     //   Java source line #2506	-> byte code offset #21
/*      */     //   Java source line #2507	-> byte code offset #28
/*      */     //   Java source line #2508	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	chooser	long
/*      */     //   0	31	2	do_overwrite_confirmation	boolean
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_file_chooser_set_extra_widget(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final void gtk_file_chooser_set_extra_widget(long chooser, long extra_widget)
/*      */   {
/* 2515 */     lock.lock();
/*      */     try {
/* 2517 */       _gtk_file_chooser_set_extra_widget(chooser, extra_widget);
/*      */     } finally {
/* 2519 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_file_chooser_set_filename(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final void gtk_file_chooser_set_filename(long chooser, long name)
/*      */   {
/* 2528 */     lock.lock();
/*      */     try {
/* 2530 */       _gtk_file_chooser_set_filename(chooser, name);
/*      */     } finally {
/* 2532 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_file_chooser_set_filter(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final void gtk_file_chooser_set_filter(long chooser, long filter)
/*      */   {
/* 2541 */     lock.lock();
/*      */     try {
/* 2543 */       _gtk_file_chooser_set_filter(chooser, filter);
/*      */     } finally {
/* 2545 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_file_chooser_set_uri(long paramLong, byte[] paramArrayOfByte);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_file_chooser_set_uri(long chooser, byte[] uri)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: aload_2
/*      */     //   9: invokestatic 194	org/eclipse/swt/internal/gtk/GTK:_gtk_file_chooser_set_uri	(J[B)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #2554	-> byte code offset #0
/*      */     //   Java source line #2556	-> byte code offset #7
/*      */     //   Java source line #2558	-> byte code offset #12
/*      */     //   Java source line #2559	-> byte code offset #18
/*      */     //   Java source line #2558	-> byte code offset #21
/*      */     //   Java source line #2559	-> byte code offset #28
/*      */     //   Java source line #2560	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	chooser	long
/*      */     //   0	31	2	uri	byte[]
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_file_chooser_set_select_multiple(long paramLong, boolean paramBoolean);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_file_chooser_set_select_multiple(long chooser, boolean select_multiple)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 195	org/eclipse/swt/internal/gtk/GTK:_gtk_file_chooser_set_select_multiple	(JZ)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #2567	-> byte code offset #0
/*      */     //   Java source line #2569	-> byte code offset #7
/*      */     //   Java source line #2571	-> byte code offset #12
/*      */     //   Java source line #2572	-> byte code offset #18
/*      */     //   Java source line #2571	-> byte code offset #21
/*      */     //   Java source line #2572	-> byte code offset #28
/*      */     //   Java source line #2573	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	chooser	long
/*      */     //   0	31	2	select_multiple	boolean
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_event_controller_set_propagation_phase(long paramLong, int paramInt);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_event_controller_set_propagation_phase(long controller, int phase)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 196	org/eclipse/swt/internal/gtk/GTK:_gtk_event_controller_set_propagation_phase	(JI)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #2579	-> byte code offset #0
/*      */     //   Java source line #2581	-> byte code offset #7
/*      */     //   Java source line #2583	-> byte code offset #12
/*      */     //   Java source line #2584	-> byte code offset #18
/*      */     //   Java source line #2583	-> byte code offset #21
/*      */     //   Java source line #2584	-> byte code offset #28
/*      */     //   Java source line #2585	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	controller	long
/*      */     //   0	31	2	phase	int
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_event_controller_handle_event(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final void gtk_event_controller_handle_event(long gesture, long event)
/*      */   {
/* 2591 */     lock.lock();
/*      */     try {
/* 2593 */       _gtk_event_controller_handle_event(gesture, event);
/*      */     } finally {
/* 2595 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_file_filter_add_pattern(long paramLong, byte[] paramArrayOfByte);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_file_filter_add_pattern(long filter, byte[] pattern)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: aload_2
/*      */     //   9: invokestatic 198	org/eclipse/swt/internal/gtk/GTK:_gtk_file_filter_add_pattern	(J[B)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #2604	-> byte code offset #0
/*      */     //   Java source line #2606	-> byte code offset #7
/*      */     //   Java source line #2608	-> byte code offset #12
/*      */     //   Java source line #2609	-> byte code offset #18
/*      */     //   Java source line #2608	-> byte code offset #21
/*      */     //   Java source line #2609	-> byte code offset #28
/*      */     //   Java source line #2610	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	filter	long
/*      */     //   0	31	2	pattern	byte[]
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native long _gtk_file_filter_new();
/*      */   
/*      */   public static final long gtk_file_filter_new()
/*      */   {
/* 2613 */     lock.lock();
/*      */     try {
/* 2615 */       return _gtk_file_filter_new();
/*      */     } finally {
/* 2617 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gtk_file_filter_get_name(long paramLong);
/*      */   
/* 2623 */   public static final long gtk_file_filter_get_name(long filter) { lock.lock();
/*      */     try {
/* 2625 */       return _gtk_file_filter_get_name(filter);
/*      */     } finally {
/* 2627 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_file_filter_set_name(long paramLong, byte[] paramArrayOfByte);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_file_filter_set_name(long filter, byte[] name)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: aload_2
/*      */     //   9: invokestatic 201	org/eclipse/swt/internal/gtk/GTK:_gtk_file_filter_set_name	(J[B)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #2636	-> byte code offset #0
/*      */     //   Java source line #2638	-> byte code offset #7
/*      */     //   Java source line #2640	-> byte code offset #12
/*      */     //   Java source line #2641	-> byte code offset #18
/*      */     //   Java source line #2640	-> byte code offset #21
/*      */     //   Java source line #2641	-> byte code offset #28
/*      */     //   Java source line #2642	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	filter	long
/*      */     //   0	31	2	name	byte[]
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_fixed_move(long paramLong1, long paramLong2, int paramInt1, int paramInt2);
/*      */   
/*      */   public static final void gtk_fixed_move(long fixed, long widget, int x, int y)
/*      */   {
/* 2651 */     lock.lock();
/*      */     try {
/* 2653 */       _gtk_fixed_move(fixed, widget, x, y);
/*      */     } finally {
/* 2655 */       lock.unlock();
/*      */     } }
/*      */   
/*      */   public static final native long _gtk_fixed_new();
/*      */   
/* 2660 */   public static final long gtk_fixed_new() { lock.lock();
/*      */     try {
/* 2662 */       return _gtk_fixed_new();
/*      */     } finally {
/* 2664 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native boolean _gtk_gesture_drag_get_start_point(long paramLong, double[] paramArrayOfDouble1, double[] paramArrayOfDouble2);
/*      */   
/*      */   public static final boolean gtk_gesture_drag_get_start_point(long gesture, double[] x, double[] y)
/*      */   {
/* 2672 */     lock.lock();
/*      */     try {
/* 2674 */       return _gtk_gesture_drag_get_start_point(gesture, x, y);
/*      */     } finally {
/* 2676 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native boolean _gtk_gesture_is_recognized(long paramLong);
/*      */   
/*      */   public static final boolean gtk_gesture_is_recognized(long gesture)
/*      */   {
/* 2684 */     lock.lock();
/*      */     try {
/* 2686 */       return _gtk_gesture_is_recognized(gesture);
/*      */     } finally {
/* 2688 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native long _gtk_gesture_drag_new(long paramLong);
/*      */   
/*      */   public static final long gtk_gesture_drag_new(long widget)
/*      */   {
/* 2697 */     lock.lock();
/*      */     try {
/* 2699 */       return _gtk_gesture_drag_new(widget);
/*      */     } finally {
/* 2701 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gtk_gesture_get_last_event(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final long gtk_gesture_get_last_event(long gesture, long sequence)
/*      */   {
/* 2709 */     lock.lock();
/*      */     try {
/* 2711 */       return _gtk_gesture_get_last_event(gesture, sequence);
/*      */     } finally {
/* 2713 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gtk_gesture_get_last_updated_sequence(long paramLong);
/*      */   
/*      */   public static final long gtk_gesture_get_last_updated_sequence(long gesture)
/*      */   {
/* 2721 */     lock.lock();
/*      */     try {
/* 2723 */       return _gtk_gesture_get_last_updated_sequence(gesture);
/*      */     } finally {
/* 2725 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native boolean _gtk_gesture_get_point(long paramLong1, long paramLong2, double[] paramArrayOfDouble1, double[] paramArrayOfDouble2);
/*      */   
/*      */   public static final boolean gtk_gesture_get_point(long gesture, long sequence, double[] x, double[] y)
/*      */   {
/* 2733 */     lock.lock();
/*      */     try {
/* 2735 */       return _gtk_gesture_get_point(gesture, sequence, x, y);
/*      */     } finally {
/* 2737 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gtk_gesture_get_sequences(long paramLong);
/*      */   
/*      */   public static final long gtk_gesture_get_sequences(long gesture)
/*      */   {
/* 2745 */     lock.lock();
/*      */     try {
/* 2747 */       return _gtk_gesture_get_sequences(gesture);
/*      */     } finally {
/* 2749 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_gesture_group(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final void gtk_gesture_group(long group_gesture, long gesture)
/*      */   {
/* 2757 */     lock.lock();
/*      */     try {
/* 2759 */       _gtk_gesture_group(group_gesture, gesture);
/*      */     } finally {
/* 2761 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_gesture_pan_set_orientation(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_gesture_pan_set_orientation(long orientation)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 212	org/eclipse/swt/internal/gtk/GTK:_gtk_gesture_pan_set_orientation	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #2769	-> byte code offset #0
/*      */     //   Java source line #2771	-> byte code offset #7
/*      */     //   Java source line #2773	-> byte code offset #11
/*      */     //   Java source line #2774	-> byte code offset #17
/*      */     //   Java source line #2773	-> byte code offset #20
/*      */     //   Java source line #2774	-> byte code offset #27
/*      */     //   Java source line #2775	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	orientation	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native long _gtk_gesture_pan_get_orientation(long paramLong);
/*      */   
/*      */   public static final long gtk_gesture_pan_get_orientation(long gesture)
/*      */   {
/* 2781 */     lock.lock();
/*      */     try {
/* 2783 */       return _gtk_gesture_pan_get_orientation(gesture);
/*      */     } finally {
/* 2785 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_gesture_pan_new(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final void gtk_gesture_pan_new(long widget, long orientation)
/*      */   {
/* 2793 */     lock.lock();
/*      */     try {
/* 2795 */       _gtk_gesture_pan_new(widget, orientation);
/*      */     } finally {
/* 2797 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_gesture_single_set_button(long paramLong, int paramInt);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_gesture_single_set_button(long gesture, int button)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 215	org/eclipse/swt/internal/gtk/GTK:_gtk_gesture_single_set_button	(JI)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #2805	-> byte code offset #0
/*      */     //   Java source line #2807	-> byte code offset #7
/*      */     //   Java source line #2809	-> byte code offset #12
/*      */     //   Java source line #2810	-> byte code offset #18
/*      */     //   Java source line #2809	-> byte code offset #21
/*      */     //   Java source line #2810	-> byte code offset #28
/*      */     //   Java source line #2811	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	gesture	long
/*      */     //   0	31	2	button	int
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native boolean _gtk_gesture_swipe_get_velocity(long paramLong, double[] paramArrayOfDouble1, double[] paramArrayOfDouble2);
/*      */   
/*      */   public static final boolean gtk_gesture_swipe_get_velocity(long gesture, double[] velocity_x, double[] velocity_y)
/*      */   {
/* 2817 */     lock.lock();
/*      */     try {
/* 2819 */       return _gtk_gesture_swipe_get_velocity(gesture, velocity_x, velocity_y);
/*      */     } finally {
/* 2821 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gtk_gesture_swipe_new(long paramLong);
/*      */   
/*      */   public static final long gtk_gesture_swipe_new(long widget)
/*      */   {
/* 2829 */     lock.lock();
/*      */     try {
/* 2831 */       return _gtk_gesture_swipe_new(widget);
/*      */     } finally {
/* 2833 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_gesture_drag_get_offset(long paramLong, double[] paramArrayOfDouble1, double[] paramArrayOfDouble2);
/*      */   
/*      */   public static final void gtk_gesture_drag_get_offset(long gesture, double[] x, double[] y)
/*      */   {
/* 2841 */     lock.lock();
/*      */     try {
/* 2843 */       _gtk_gesture_drag_get_offset(gesture, x, y);
/*      */     } finally {
/* 2845 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native double _gtk_gesture_rotate_get_angle_delta(long paramLong);
/*      */   
/*      */   public static final double gtk_gesture_rotate_get_angle_delta(long gesture)
/*      */   {
/* 2854 */     lock.lock();
/*      */     try {
/* 2856 */       return _gtk_gesture_rotate_get_angle_delta(gesture);
/*      */     } finally {
/* 2858 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native long _gtk_gesture_rotate_new(long paramLong);
/*      */   
/*      */   public static final long gtk_gesture_rotate_new(long widget)
/*      */   {
/* 2867 */     lock.lock();
/*      */     try {
/* 2869 */       return _gtk_gesture_rotate_new(widget);
/*      */     } finally {
/* 2871 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gtk_gesture_zoom_new(long paramLong);
/*      */   
/*      */   public static final long gtk_gesture_zoom_new(long widget)
/*      */   {
/* 2879 */     lock.lock();
/*      */     try {
/* 2881 */       return _gtk_gesture_zoom_new(widget);
/*      */     } finally {
/* 2883 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native double _gtk_gesture_zoom_get_scale_delta(long paramLong);
/*      */   
/*      */   public static final double gtk_gesture_zoom_get_scale_delta(long gesture)
/*      */   {
/* 2891 */     lock.lock();
/*      */     try {
/* 2893 */       return _gtk_gesture_zoom_get_scale_delta(gesture);
/*      */     } finally {
/* 2895 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_widget_set_clip(long paramLong, GtkAllocation paramGtkAllocation);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_widget_set_clip(long widget, GtkAllocation allocation)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: aload_2
/*      */     //   9: invokestatic 223	org/eclipse/swt/internal/gtk/GTK:_gtk_widget_set_clip	(JLorg/eclipse/swt/internal/gtk/GtkAllocation;)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #2904	-> byte code offset #0
/*      */     //   Java source line #2906	-> byte code offset #7
/*      */     //   Java source line #2908	-> byte code offset #12
/*      */     //   Java source line #2909	-> byte code offset #18
/*      */     //   Java source line #2908	-> byte code offset #21
/*      */     //   Java source line #2909	-> byte code offset #28
/*      */     //   Java source line #2910	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	widget	long
/*      */     //   0	31	2	allocation	GtkAllocation
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_widget_get_clip(long paramLong, GtkAllocation paramGtkAllocation);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_widget_get_clip(long widget, GtkAllocation allocation)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: aload_2
/*      */     //   9: invokestatic 224	org/eclipse/swt/internal/gtk/GTK:_gtk_widget_get_clip	(JLorg/eclipse/swt/internal/gtk/GtkAllocation;)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #2917	-> byte code offset #0
/*      */     //   Java source line #2919	-> byte code offset #7
/*      */     //   Java source line #2921	-> byte code offset #12
/*      */     //   Java source line #2922	-> byte code offset #18
/*      */     //   Java source line #2921	-> byte code offset #21
/*      */     //   Java source line #2922	-> byte code offset #28
/*      */     //   Java source line #2923	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	widget	long
/*      */     //   0	31	2	allocation	GtkAllocation
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_widget_set_has_window(long paramLong, boolean paramBoolean);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_widget_set_has_window(long widget, boolean has_window)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 225	org/eclipse/swt/internal/gtk/GTK:_gtk_widget_set_has_window	(JZ)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #2930	-> byte code offset #0
/*      */     //   Java source line #2932	-> byte code offset #7
/*      */     //   Java source line #2934	-> byte code offset #12
/*      */     //   Java source line #2935	-> byte code offset #18
/*      */     //   Java source line #2934	-> byte code offset #21
/*      */     //   Java source line #2935	-> byte code offset #28
/*      */     //   Java source line #2936	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	widget	long
/*      */     //   0	31	2	has_window	boolean
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_label_set_xalign(long paramLong, float paramFloat);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_label_set_xalign(long label, float xalign)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: fload_2
/*      */     //   9: invokestatic 226	org/eclipse/swt/internal/gtk/GTK:_gtk_label_set_xalign	(JF)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #2946	-> byte code offset #0
/*      */     //   Java source line #2948	-> byte code offset #7
/*      */     //   Java source line #2950	-> byte code offset #12
/*      */     //   Java source line #2951	-> byte code offset #18
/*      */     //   Java source line #2950	-> byte code offset #21
/*      */     //   Java source line #2951	-> byte code offset #28
/*      */     //   Java source line #2952	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	label	long
/*      */     //   0	31	2	xalign	float
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_label_set_yalign(long paramLong, float paramFloat);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_label_set_yalign(long label, float yalign)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: fload_2
/*      */     //   9: invokestatic 227	org/eclipse/swt/internal/gtk/GTK:_gtk_label_set_yalign	(JF)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #2962	-> byte code offset #0
/*      */     //   Java source line #2964	-> byte code offset #7
/*      */     //   Java source line #2966	-> byte code offset #12
/*      */     //   Java source line #2967	-> byte code offset #18
/*      */     //   Java source line #2966	-> byte code offset #21
/*      */     //   Java source line #2967	-> byte code offset #28
/*      */     //   Java source line #2968	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	label	long
/*      */     //   0	31	2	yalign	float
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_widget_set_halign(long paramLong, int paramInt);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_widget_set_halign(long widget, int gtk_align)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 228	org/eclipse/swt/internal/gtk/GTK:_gtk_widget_set_halign	(JI)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #2976	-> byte code offset #0
/*      */     //   Java source line #2978	-> byte code offset #7
/*      */     //   Java source line #2980	-> byte code offset #12
/*      */     //   Java source line #2981	-> byte code offset #18
/*      */     //   Java source line #2980	-> byte code offset #21
/*      */     //   Java source line #2981	-> byte code offset #28
/*      */     //   Java source line #2982	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	widget	long
/*      */     //   0	31	2	gtk_align	int
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_widget_set_valign(long paramLong, int paramInt);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_widget_set_valign(long widget, int gtk_align)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 229	org/eclipse/swt/internal/gtk/GTK:_gtk_widget_set_valign	(JI)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #2989	-> byte code offset #0
/*      */     //   Java source line #2991	-> byte code offset #7
/*      */     //   Java source line #2993	-> byte code offset #12
/*      */     //   Java source line #2994	-> byte code offset #18
/*      */     //   Java source line #2993	-> byte code offset #21
/*      */     //   Java source line #2994	-> byte code offset #28
/*      */     //   Java source line #2995	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	widget	long
/*      */     //   0	31	2	gtk_align	int
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native long _gtk_font_selection_dialog_get_font_name(long paramLong);
/*      */   
/*      */   public static final long gtk_font_selection_dialog_get_font_name(long fsd)
/*      */   {
/* 3000 */     lock.lock();
/*      */     try {
/* 3002 */       return _gtk_font_selection_dialog_get_font_name(fsd);
/*      */     } finally {
/* 3004 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native long _gtk_font_chooser_dialog_new(byte[] paramArrayOfByte, long paramLong);
/*      */   
/*      */ 
/*      */   public static final long gtk_font_chooser_dialog_new(byte[] title, long parent)
/*      */   {
/* 3014 */     lock.lock();
/*      */     try {
/* 3016 */       return _gtk_font_chooser_dialog_new(title, parent);
/*      */     } finally {
/* 3018 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gtk_font_chooser_get_font(long paramLong);
/*      */   
/* 3024 */   public static final long gtk_font_chooser_get_font(long fontchooser) { lock.lock();
/*      */     try {
/* 3026 */       return _gtk_font_chooser_get_font(fontchooser);
/*      */     } finally {
/* 3028 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_font_chooser_set_font(long paramLong, byte[] paramArrayOfByte);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_font_chooser_set_font(long fsd, byte[] fontname)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: aload_2
/*      */     //   9: invokestatic 233	org/eclipse/swt/internal/gtk/GTK:_gtk_font_chooser_set_font	(J[B)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #3037	-> byte code offset #0
/*      */     //   Java source line #3039	-> byte code offset #7
/*      */     //   Java source line #3041	-> byte code offset #12
/*      */     //   Java source line #3042	-> byte code offset #18
/*      */     //   Java source line #3041	-> byte code offset #21
/*      */     //   Java source line #3042	-> byte code offset #28
/*      */     //   Java source line #3043	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	fsd	long
/*      */     //   0	31	2	fontname	byte[]
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native long _gtk_font_selection_dialog_new(byte[] paramArrayOfByte);
/*      */   
/*      */   public static final long gtk_font_selection_dialog_new(byte[] title)
/*      */   {
/* 3051 */     lock.lock();
/*      */     try {
/* 3053 */       return _gtk_font_selection_dialog_new(title);
/*      */     } finally {
/* 3055 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native boolean _gtk_font_selection_dialog_set_font_name(long paramLong, byte[] paramArrayOfByte);
/*      */   
/*      */ 
/*      */   public static final boolean gtk_font_selection_dialog_set_font_name(long fsd, byte[] fontname)
/*      */   {
/* 3065 */     lock.lock();
/*      */     try {
/* 3067 */       return _gtk_font_selection_dialog_set_font_name(fsd, fontname);
/*      */     } finally {
/* 3069 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gtk_frame_new(byte[] paramArrayOfByte);
/*      */   
/* 3075 */   public static final long gtk_frame_new(byte[] label) { lock.lock();
/*      */     try {
/* 3077 */       return _gtk_frame_new(label);
/*      */     } finally {
/* 3079 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gtk_frame_get_label_widget(long paramLong);
/*      */   
/* 3085 */   public static final long gtk_frame_get_label_widget(long frame) { lock.lock();
/*      */     try {
/* 3087 */       return _gtk_frame_get_label_widget(frame);
/*      */     } finally {
/* 3089 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_frame_set_label_widget(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final void gtk_frame_set_label_widget(long frame, long label_widget)
/*      */   {
/* 3098 */     lock.lock();
/*      */     try {
/* 3100 */       _gtk_frame_set_label_widget(frame, label_widget);
/*      */     } finally {
/* 3102 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_frame_set_shadow_type(long paramLong, int paramInt);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_frame_set_shadow_type(long frame, int type)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 239	org/eclipse/swt/internal/gtk/GTK:_gtk_frame_set_shadow_type	(JI)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #3111	-> byte code offset #0
/*      */     //   Java source line #3113	-> byte code offset #7
/*      */     //   Java source line #3115	-> byte code offset #12
/*      */     //   Java source line #3116	-> byte code offset #18
/*      */     //   Java source line #3115	-> byte code offset #21
/*      */     //   Java source line #3116	-> byte code offset #28
/*      */     //   Java source line #3117	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	frame	long
/*      */     //   0	31	2	type	int
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native long _gtk_get_current_event();
/*      */   
/*      */   public static final long gtk_get_current_event()
/*      */   {
/* 3120 */     lock.lock();
/*      */     try {
/* 3122 */       return _gtk_get_current_event();
/*      */     } finally {
/* 3124 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native boolean _gtk_get_current_event_state(int[] paramArrayOfInt);
/*      */   
/* 3130 */   public static final boolean gtk_get_current_event_state(int[] state) { lock.lock();
/*      */     try {
/* 3132 */       return _gtk_get_current_event_state(state);
/*      */     } finally {
/* 3134 */       lock.unlock();
/*      */     } }
/*      */   
/*      */   public static final native long _gtk_get_default_language();
/*      */   
/* 3139 */   public static final long gtk_get_default_language() { lock.lock();
/*      */     try {
/* 3141 */       return _gtk_get_default_language();
/*      */     } finally {
/* 3143 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gtk_get_event_widget(long paramLong);
/*      */   
/* 3149 */   public static final long gtk_get_event_widget(long event) { lock.lock();
/*      */     try {
/* 3151 */       return _gtk_get_event_widget(event);
/*      */     } finally {
/* 3153 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_grab_add(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_grab_add(long widget)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 244	org/eclipse/swt/internal/gtk/GTK:_gtk_grab_add	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #3159	-> byte code offset #0
/*      */     //   Java source line #3161	-> byte code offset #7
/*      */     //   Java source line #3163	-> byte code offset #11
/*      */     //   Java source line #3164	-> byte code offset #17
/*      */     //   Java source line #3163	-> byte code offset #20
/*      */     //   Java source line #3164	-> byte code offset #27
/*      */     //   Java source line #3165	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	widget	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native long _gtk_grab_get_current();
/*      */   
/*      */   public static final long gtk_grab_get_current()
/*      */   {
/* 3168 */     lock.lock();
/*      */     try {
/* 3170 */       return _gtk_grab_get_current();
/*      */     } finally {
/* 3172 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_grab_remove(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_grab_remove(long widget)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 246	org/eclipse/swt/internal/gtk/GTK:_gtk_grab_remove	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #3178	-> byte code offset #0
/*      */     //   Java source line #3180	-> byte code offset #7
/*      */     //   Java source line #3182	-> byte code offset #11
/*      */     //   Java source line #3183	-> byte code offset #17
/*      */     //   Java source line #3182	-> byte code offset #20
/*      */     //   Java source line #3183	-> byte code offset #27
/*      */     //   Java source line #3184	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	widget	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native long _gtk_hbox_new(boolean paramBoolean, int paramInt);
/*      */   
/*      */   public static final long gtk_hbox_new(boolean homogeneous, int spacing)
/*      */   {
/* 3193 */     lock.lock();
/*      */     try {
/* 3195 */       return _gtk_hbox_new(homogeneous, spacing);
/*      */     } finally {
/* 3197 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final native void _gtk_hsv_to_rgb(double paramDouble1, double paramDouble2, double paramDouble3, double[] paramArrayOfDouble1, double[] paramArrayOfDouble2, double[] paramArrayOfDouble3);
/*      */   
/*      */ 
/*      */ 
/*      */   public static final void gtk_hsv_to_rgb(double h, double s, double v, double[] r, double[] g, double[] b)
/*      */   {
/* 3210 */     lock.lock();
/*      */     try {
/* 3212 */       _gtk_hsv_to_rgb(h, s, v, r, g, b);
/*      */     } finally {
/* 3214 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final native void _gtk_rgb_to_hsv(double paramDouble1, double paramDouble2, double paramDouble3, double[] paramArrayOfDouble1, double[] paramArrayOfDouble2, double[] paramArrayOfDouble3);
/*      */   
/*      */ 
/*      */ 
/*      */   public static final void gtk_rgb_to_hsv(double r, double g, double b, double[] h, double[] s, double[] v)
/*      */   {
/* 3227 */     lock.lock();
/*      */     try {
/* 3229 */       _gtk_rgb_to_hsv(r, g, b, h, s, v);
/*      */     } finally {
/* 3231 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native long _gtk_box_new(int paramInt1, int paramInt2);
/*      */   
/*      */   public static final long gtk_box_new(int orientation, int spacing)
/*      */   {
/* 3240 */     lock.lock();
/*      */     try {
/* 3242 */       return _gtk_box_new(orientation, spacing);
/*      */     } finally {
/* 3244 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final native void _gtk_box_pack_end(long paramLong1, long paramLong2, boolean paramBoolean1, boolean paramBoolean2, int paramInt);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void gtk_box_pack_end(long box, long widget, boolean expand, boolean fill, int padding)
/*      */   {
/* 3258 */     lock.lock();
/*      */     try {
/* 3260 */       _gtk_box_pack_end(box, widget, expand, fill, padding);
/*      */     } finally {
/* 3262 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_box_reorder_child(long paramLong1, long paramLong2, int paramInt);
/*      */   
/*      */ 
/*      */   public static final void gtk_box_reorder_child(long box, long child, int position)
/*      */   {
/* 3272 */     lock.lock();
/*      */     try {
/* 3274 */       _gtk_box_reorder_child(box, child, position);
/*      */     } finally {
/* 3276 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_box_set_homogeneous(long paramLong, boolean paramBoolean);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_box_set_homogeneous(long box, boolean homogeneous)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 253	org/eclipse/swt/internal/gtk/GTK:_gtk_box_set_homogeneous	(JZ)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #3285	-> byte code offset #0
/*      */     //   Java source line #3287	-> byte code offset #7
/*      */     //   Java source line #3289	-> byte code offset #12
/*      */     //   Java source line #3290	-> byte code offset #18
/*      */     //   Java source line #3289	-> byte code offset #21
/*      */     //   Java source line #3290	-> byte code offset #28
/*      */     //   Java source line #3291	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	box	long
/*      */     //   0	31	2	homogeneous	boolean
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native long _gtk_event_box_new();
/*      */   
/*      */   public static final long gtk_event_box_new()
/*      */   {
/* 3294 */     lock.lock();
/*      */     try {
/* 3296 */       return _gtk_event_box_new();
/*      */     } finally {
/* 3298 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native long _gtk_hscale_new(long paramLong);
/*      */   
/*      */ 
/*      */   public static final long gtk_hscale_new(long adjustment)
/*      */   {
/* 3308 */     lock.lock();
/*      */     try {
/* 3310 */       return _gtk_hscale_new(adjustment);
/*      */     } finally {
/* 3312 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native long _gtk_scale_new(int paramInt, long paramLong);
/*      */   
/*      */ 
/*      */   public static final long gtk_scale_new(int orientation, long adjustment)
/*      */   {
/* 3322 */     lock.lock();
/*      */     try {
/* 3324 */       return _gtk_scale_new(orientation, adjustment);
/*      */     } finally {
/* 3326 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native long _gtk_hscrollbar_new(long paramLong);
/*      */   
/*      */ 
/*      */   public static final long gtk_hscrollbar_new(long adjustment)
/*      */   {
/* 3336 */     lock.lock();
/*      */     try {
/* 3338 */       return _gtk_hscrollbar_new(adjustment);
/*      */     } finally {
/* 3340 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native long _gtk_scrollbar_new(int paramInt, long paramLong);
/*      */   
/*      */ 
/*      */   public static final long gtk_scrollbar_new(int orientation, long adjustment)
/*      */   {
/* 3350 */     lock.lock();
/*      */     try {
/* 3352 */       return _gtk_scrollbar_new(orientation, adjustment);
/*      */     } finally {
/* 3354 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gtk_hseparator_new();
/*      */   
/* 3360 */   public static final long gtk_hseparator_new() { lock.lock();
/*      */     try {
/* 3362 */       return _gtk_hseparator_new();
/*      */     } finally {
/* 3364 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native long _gtk_separator_new(int paramInt);
/*      */   
/*      */   public static final long gtk_separator_new(int orientation)
/*      */   {
/* 3373 */     lock.lock();
/*      */     try {
/* 3375 */       return _gtk_separator_new(orientation);
/*      */     } finally {
/* 3377 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gtk_status_icon_position_menu_func();
/*      */   
/*      */   public static final long gtk_status_icon_position_menu_func() {
/* 3384 */     lock.lock();
/*      */     try {
/* 3386 */       return _gtk_status_icon_position_menu_func();
/*      */     } finally {
/* 3388 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_icon_info_free(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_icon_info_free(long icon_info)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 262	org/eclipse/swt/internal/gtk/GTK:_gtk_icon_info_free	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #3397	-> byte code offset #0
/*      */     //   Java source line #3399	-> byte code offset #7
/*      */     //   Java source line #3401	-> byte code offset #11
/*      */     //   Java source line #3402	-> byte code offset #17
/*      */     //   Java source line #3401	-> byte code offset #20
/*      */     //   Java source line #3402	-> byte code offset #27
/*      */     //   Java source line #3403	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	icon_info	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native long _gtk_icon_theme_get_default();
/*      */   
/*      */   public static final long gtk_icon_theme_get_default()
/*      */   {
/* 3407 */     lock.lock();
/*      */     try {
/* 3409 */       return _gtk_icon_theme_get_default();
/*      */     } finally {
/* 3411 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final native long _gtk_icon_theme_lookup_by_gicon(long paramLong1, long paramLong2, int paramInt1, int paramInt2);
/*      */   
/*      */ 
/*      */   public static final long gtk_icon_theme_lookup_by_gicon(long icon_theme, long icon, int size, int flags)
/*      */   {
/* 3422 */     lock.lock();
/*      */     try {
/* 3424 */       return _gtk_icon_theme_lookup_by_gicon(icon_theme, icon, size, flags);
/*      */     } finally {
/* 3426 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final native long _gtk_icon_theme_load_icon(long paramLong1, byte[] paramArrayOfByte, int paramInt1, int paramInt2, long paramLong2);
/*      */   
/*      */ 
/*      */ 
/*      */   public static final long gtk_icon_theme_load_icon(long icon_theme, byte[] icon_name, int size, int flags, long error)
/*      */   {
/* 3438 */     lock.lock();
/*      */     try {
/* 3440 */       return _gtk_icon_theme_load_icon(icon_theme, icon_name, size, flags, error);
/*      */     } finally {
/* 3442 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native long _gtk_icon_info_load_icon(long paramLong, long[] paramArrayOfLong);
/*      */   
/*      */   public static final long gtk_icon_info_load_icon(long icon_info, long[] error)
/*      */   {
/* 3451 */     lock.lock();
/*      */     try {
/* 3453 */       return _gtk_icon_info_load_icon(icon_info, error);
/*      */     } finally {
/* 3455 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native boolean _gtk_im_context_filter_keypress(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final boolean gtk_im_context_filter_keypress(long context, long event)
/*      */   {
/* 3464 */     lock.lock();
/*      */     try {
/* 3466 */       return _gtk_im_context_filter_keypress(context, event);
/*      */     } finally {
/* 3468 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_im_context_focus_in(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_im_context_focus_in(long context)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 268	org/eclipse/swt/internal/gtk/GTK:_gtk_im_context_focus_in	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #3474	-> byte code offset #0
/*      */     //   Java source line #3476	-> byte code offset #7
/*      */     //   Java source line #3478	-> byte code offset #11
/*      */     //   Java source line #3479	-> byte code offset #17
/*      */     //   Java source line #3478	-> byte code offset #20
/*      */     //   Java source line #3479	-> byte code offset #27
/*      */     //   Java source line #3480	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	context	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_im_context_focus_out(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_im_context_focus_out(long context)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 269	org/eclipse/swt/internal/gtk/GTK:_gtk_im_context_focus_out	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #3484	-> byte code offset #0
/*      */     //   Java source line #3486	-> byte code offset #7
/*      */     //   Java source line #3488	-> byte code offset #11
/*      */     //   Java source line #3489	-> byte code offset #17
/*      */     //   Java source line #3488	-> byte code offset #20
/*      */     //   Java source line #3489	-> byte code offset #27
/*      */     //   Java source line #3490	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	context	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_im_context_get_preedit_string(long paramLong, long[] paramArrayOfLong1, long[] paramArrayOfLong2, int[] paramArrayOfInt);
/*      */   
/*      */   public static final void gtk_im_context_get_preedit_string(long context, long[] str, long[] attrs, int[] cursor_pos)
/*      */   {
/* 3499 */     lock.lock();
/*      */     try {
/* 3501 */       _gtk_im_context_get_preedit_string(context, str, attrs, cursor_pos);
/*      */     } finally {
/* 3503 */       lock.unlock();
/*      */     } }
/*      */   
/*      */   public static final native long _gtk_im_context_get_type();
/*      */   
/* 3508 */   public static final long gtk_im_context_get_type() { lock.lock();
/*      */     try {
/* 3510 */       return _gtk_im_context_get_type();
/*      */     } finally {
/* 3512 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_im_context_reset(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_im_context_reset(long context)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 272	org/eclipse/swt/internal/gtk/GTK:_gtk_im_context_reset	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #3518	-> byte code offset #0
/*      */     //   Java source line #3520	-> byte code offset #7
/*      */     //   Java source line #3522	-> byte code offset #11
/*      */     //   Java source line #3523	-> byte code offset #17
/*      */     //   Java source line #3522	-> byte code offset #20
/*      */     //   Java source line #3523	-> byte code offset #27
/*      */     //   Java source line #3524	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	context	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_im_context_set_client_window(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final void gtk_im_context_set_client_window(long context, long window)
/*      */   {
/* 3531 */     lock.lock();
/*      */     try {
/* 3533 */       _gtk_im_context_set_client_window(context, window);
/*      */     } finally {
/* 3535 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_im_context_set_cursor_location(long paramLong, GdkRectangle paramGdkRectangle);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_im_context_set_cursor_location(long context, GdkRectangle area)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: aload_2
/*      */     //   9: invokestatic 274	org/eclipse/swt/internal/gtk/GTK:_gtk_im_context_set_cursor_location	(JLorg/eclipse/swt/internal/gtk/GdkRectangle;)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #3544	-> byte code offset #0
/*      */     //   Java source line #3546	-> byte code offset #7
/*      */     //   Java source line #3548	-> byte code offset #12
/*      */     //   Java source line #3549	-> byte code offset #18
/*      */     //   Java source line #3548	-> byte code offset #21
/*      */     //   Java source line #3549	-> byte code offset #28
/*      */     //   Java source line #3550	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	context	long
/*      */     //   0	31	2	area	GdkRectangle
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_im_multicontext_append_menuitems(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final void gtk_im_multicontext_append_menuitems(long context, long menushell)
/*      */   {
/* 3558 */     lock.lock();
/*      */     try {
/* 3560 */       _gtk_im_multicontext_append_menuitems(context, menushell);
/*      */     } finally {
/* 3562 */       lock.unlock();
/*      */     } }
/*      */   
/*      */   public static final native long _gtk_im_multicontext_new();
/*      */   
/* 3567 */   public static final long gtk_im_multicontext_new() { lock.lock();
/*      */     try {
/* 3569 */       return _gtk_im_multicontext_new();
/*      */     } finally {
/* 3571 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final native void _gtk_image_menu_item_set_image(long paramLong1, long paramLong2);
/*      */   
/*      */ 
/*      */   public static final void gtk_image_menu_item_set_image(long menu_item, long image)
/*      */   {
/* 3582 */     lock.lock();
/*      */     try {
/* 3584 */       _gtk_image_menu_item_set_image(menu_item, image);
/*      */     } finally {
/* 3586 */       lock.unlock();
/*      */     } }
/*      */   
/*      */   public static final native long _gtk_image_new();
/*      */   
/* 3591 */   public static final long gtk_image_new() { lock.lock();
/*      */     try {
/* 3593 */       return _gtk_image_new();
/*      */     } finally {
/* 3595 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_image_set_pixel_size(long paramLong, int paramInt);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_image_set_pixel_size(long image, int pixel_size)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 279	org/eclipse/swt/internal/gtk/GTK:_gtk_image_set_pixel_size	(JI)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #3604	-> byte code offset #0
/*      */     //   Java source line #3606	-> byte code offset #7
/*      */     //   Java source line #3608	-> byte code offset #12
/*      */     //   Java source line #3609	-> byte code offset #18
/*      */     //   Java source line #3608	-> byte code offset #21
/*      */     //   Java source line #3609	-> byte code offset #28
/*      */     //   Java source line #3610	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	image	long
/*      */     //   0	31	2	pixel_size	int
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native long _gtk_image_new_from_pixbuf(long paramLong);
/*      */   
/*      */   public static final long gtk_image_new_from_pixbuf(long pixbuf)
/*      */   {
/* 3614 */     lock.lock();
/*      */     try {
/* 3616 */       return _gtk_image_new_from_pixbuf(pixbuf);
/*      */     } finally {
/* 3618 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_image_set_from_pixbuf(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final void gtk_image_set_from_pixbuf(long image, long pixbuf)
/*      */   {
/* 3627 */     lock.lock();
/*      */     try {
/* 3629 */       _gtk_image_set_from_pixbuf(image, pixbuf);
/*      */     } finally {
/* 3631 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_image_set_from_gicon(long paramLong1, long paramLong2, int paramInt);
/*      */   
/*      */ 
/*      */   public static final void gtk_image_set_from_gicon(long image, long gicon, int size)
/*      */   {
/* 3641 */     lock.lock();
/*      */     try {
/* 3643 */       _gtk_image_set_from_gicon(image, gicon, size);
/*      */     } finally {
/* 3645 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native long _gtk_image_new_from_icon_name(byte[] paramArrayOfByte, int paramInt);
/*      */   
/*      */   public static final long gtk_image_new_from_icon_name(byte[] icon_name, int size)
/*      */   {
/* 3654 */     lock.lock();
/*      */     try {
/* 3656 */       return _gtk_image_new_from_icon_name(icon_name, size);
/*      */     } finally {
/* 3658 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_image_set_from_icon_name(long paramLong, byte[] paramArrayOfByte, int paramInt);
/*      */   
/*      */ 
/*      */   public static final void gtk_image_set_from_icon_name(long image, byte[] icon_name, int size)
/*      */   {
/* 3668 */     lock.lock();
/*      */     try {
/* 3670 */       _gtk_image_set_from_icon_name(image, icon_name, size);
/*      */     } finally {
/* 3672 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native boolean _gtk_init_check(long[] paramArrayOfLong1, long[] paramArrayOfLong2);
/*      */   
/*      */   public static final boolean gtk_init_check(long[] argc, long[] argv)
/*      */   {
/* 3681 */     lock.lock();
/*      */     try {
/* 3683 */       return _gtk_init_check(argc, argv);
/*      */     } finally {
/* 3685 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gtk_label_get_layout(long paramLong);
/*      */   
/* 3691 */   public static final long gtk_label_get_layout(long label) { lock.lock();
/*      */     try {
/* 3693 */       return _gtk_label_get_layout(label);
/*      */     } finally {
/* 3695 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native int _gtk_label_get_mnemonic_keyval(long paramLong);
/*      */   
/* 3701 */   public static final int gtk_label_get_mnemonic_keyval(long label) { lock.lock();
/*      */     try {
/* 3703 */       return _gtk_label_get_mnemonic_keyval(label);
/*      */     } finally {
/* 3705 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gtk_label_new(byte[] paramArrayOfByte);
/*      */   
/* 3711 */   public static final long gtk_label_new(byte[] label) { lock.lock();
/*      */     try {
/* 3713 */       return _gtk_label_new(label);
/*      */     } finally {
/* 3715 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gtk_label_new_with_mnemonic(byte[] paramArrayOfByte);
/*      */   
/* 3721 */   public static final long gtk_label_new_with_mnemonic(byte[] str) { lock.lock();
/*      */     try {
/* 3723 */       return _gtk_label_new_with_mnemonic(str);
/*      */     } finally {
/* 3725 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_label_set_attributes(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final void gtk_label_set_attributes(long label, long attrs)
/*      */   {
/* 3734 */     lock.lock();
/*      */     try {
/* 3736 */       _gtk_label_set_attributes(label, attrs);
/*      */     } finally {
/* 3738 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_label_set_justify(long paramLong, int paramInt);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_label_set_justify(long label, int jtype)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 291	org/eclipse/swt/internal/gtk/GTK:_gtk_label_set_justify	(JI)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #3747	-> byte code offset #0
/*      */     //   Java source line #3749	-> byte code offset #7
/*      */     //   Java source line #3751	-> byte code offset #12
/*      */     //   Java source line #3752	-> byte code offset #18
/*      */     //   Java source line #3751	-> byte code offset #21
/*      */     //   Java source line #3752	-> byte code offset #28
/*      */     //   Java source line #3753	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	label	long
/*      */     //   0	31	2	jtype	int
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_label_set_line_wrap(long paramLong, boolean paramBoolean);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_label_set_line_wrap(long label, boolean wrap)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 292	org/eclipse/swt/internal/gtk/GTK:_gtk_label_set_line_wrap	(JZ)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #3760	-> byte code offset #0
/*      */     //   Java source line #3762	-> byte code offset #7
/*      */     //   Java source line #3764	-> byte code offset #12
/*      */     //   Java source line #3765	-> byte code offset #18
/*      */     //   Java source line #3764	-> byte code offset #21
/*      */     //   Java source line #3765	-> byte code offset #28
/*      */     //   Java source line #3766	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	label	long
/*      */     //   0	31	2	wrap	boolean
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_label_set_line_wrap_mode(long paramLong, int paramInt);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_label_set_line_wrap_mode(long label, int wrap_mode)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 293	org/eclipse/swt/internal/gtk/GTK:_gtk_label_set_line_wrap_mode	(JI)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #3773	-> byte code offset #0
/*      */     //   Java source line #3775	-> byte code offset #7
/*      */     //   Java source line #3777	-> byte code offset #12
/*      */     //   Java source line #3778	-> byte code offset #18
/*      */     //   Java source line #3777	-> byte code offset #21
/*      */     //   Java source line #3778	-> byte code offset #28
/*      */     //   Java source line #3779	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	label	long
/*      */     //   0	31	2	wrap_mode	int
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_label_set_text(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final void gtk_label_set_text(long label, long str)
/*      */   {
/* 3786 */     lock.lock();
/*      */     try {
/* 3788 */       _gtk_label_set_text(label, str);
/*      */     } finally {
/* 3790 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_label_set_text(long paramLong, byte[] paramArrayOfByte);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_label_set_text(long label, byte[] str)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: aload_2
/*      */     //   9: invokestatic 295	org/eclipse/swt/internal/gtk/GTK:_gtk_label_set_text	(J[B)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #3799	-> byte code offset #0
/*      */     //   Java source line #3801	-> byte code offset #7
/*      */     //   Java source line #3803	-> byte code offset #12
/*      */     //   Java source line #3804	-> byte code offset #18
/*      */     //   Java source line #3803	-> byte code offset #21
/*      */     //   Java source line #3804	-> byte code offset #28
/*      */     //   Java source line #3805	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	label	long
/*      */     //   0	31	2	str	byte[]
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_label_set_text_with_mnemonic(long paramLong, byte[] paramArrayOfByte);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_label_set_text_with_mnemonic(long label, byte[] str)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: aload_2
/*      */     //   9: invokestatic 296	org/eclipse/swt/internal/gtk/GTK:_gtk_label_set_text_with_mnemonic	(J[B)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #3812	-> byte code offset #0
/*      */     //   Java source line #3814	-> byte code offset #7
/*      */     //   Java source line #3816	-> byte code offset #12
/*      */     //   Java source line #3817	-> byte code offset #18
/*      */     //   Java source line #3816	-> byte code offset #21
/*      */     //   Java source line #3817	-> byte code offset #28
/*      */     //   Java source line #3818	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	label	long
/*      */     //   0	31	2	str	byte[]
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_list_store_append(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final void gtk_list_store_append(long list_store, long iter)
/*      */   {
/* 3825 */     lock.lock();
/*      */     try {
/* 3827 */       _gtk_list_store_append(list_store, iter);
/*      */     } finally {
/* 3829 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_list_store_clear(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_list_store_clear(long store)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 298	org/eclipse/swt/internal/gtk/GTK:_gtk_list_store_clear	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #3835	-> byte code offset #0
/*      */     //   Java source line #3837	-> byte code offset #7
/*      */     //   Java source line #3839	-> byte code offset #11
/*      */     //   Java source line #3840	-> byte code offset #17
/*      */     //   Java source line #3839	-> byte code offset #20
/*      */     //   Java source line #3840	-> byte code offset #27
/*      */     //   Java source line #3841	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	store	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_list_store_insert(long paramLong1, long paramLong2, int paramInt);
/*      */   
/*      */   public static final void gtk_list_store_insert(long list_store, long iter, int position)
/*      */   {
/* 3849 */     lock.lock();
/*      */     try {
/* 3851 */       _gtk_list_store_insert(list_store, iter, position);
/*      */     } finally {
/* 3853 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native long _gtk_list_store_newv(int paramInt, long[] paramArrayOfLong);
/*      */   
/*      */   public static final long gtk_list_store_newv(int numColumns, long[] types)
/*      */   {
/* 3862 */     lock.lock();
/*      */     try {
/* 3864 */       return _gtk_list_store_newv(numColumns, types);
/*      */     } finally {
/* 3866 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final native boolean _gtk_css_provider_load_from_data(long paramLong1, byte[] paramArrayOfByte, long paramLong2, long[] paramArrayOfLong);
/*      */   
/*      */ 
/*      */   public static final boolean gtk_css_provider_load_from_data(long css_provider, byte[] data, long length, long[] error)
/*      */   {
/* 3877 */     lock.lock();
/*      */     try {
/* 3879 */       return _gtk_css_provider_load_from_data(css_provider, data, length, error);
/*      */     } finally {
/* 3881 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gtk_css_provider_new();
/*      */   
/* 3887 */   public static final long gtk_css_provider_new() { lock.lock();
/*      */     try {
/* 3889 */       return _gtk_css_provider_new();
/*      */     } finally {
/* 3891 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gtk_css_provider_to_string(long paramLong);
/*      */   
/* 3897 */   public static final long gtk_css_provider_to_string(long provider) { lock.lock();
/*      */     try {
/* 3899 */       return _gtk_css_provider_to_string(provider);
/*      */     } finally {
/* 3901 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native long _gtk_css_provider_get_named(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2);
/*      */   
/*      */   public static final long gtk_css_provider_get_named(byte[] name, byte[] variant)
/*      */   {
/* 3910 */     lock.lock();
/*      */     try {
/* 3912 */       return _gtk_css_provider_get_named(name, variant);
/*      */     } finally {
/* 3914 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_style_context_add_provider_for_screen(long paramLong1, long paramLong2, int paramInt);
/*      */   
/*      */ 
/*      */   public static final void gtk_style_context_add_provider_for_screen(long screen, long provider, int priority)
/*      */   {
/* 3924 */     lock.lock();
/*      */     try {
/* 3926 */       _gtk_style_context_add_provider_for_screen(screen, provider, priority);
/*      */     } finally {
/* 3928 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_style_context_add_provider(long paramLong1, long paramLong2, int paramInt);
/*      */   
/*      */ 
/*      */   public static final void gtk_style_context_add_provider(long context, long provider, int priority)
/*      */   {
/* 3938 */     lock.lock();
/*      */     try {
/* 3940 */       _gtk_style_context_add_provider(context, provider, priority);
/*      */     } finally {
/* 3942 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_list_store_remove(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final void gtk_list_store_remove(long list_store, long iter)
/*      */   {
/* 3951 */     lock.lock();
/*      */     try {
/* 3953 */       _gtk_list_store_remove(list_store, iter);
/*      */     } finally {
/* 3955 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_list_store_set(long paramLong1, long paramLong2, int paramInt1, byte[] paramArrayOfByte, int paramInt2);
/*      */   
/*      */   public static final void gtk_list_store_set(long store, long iter, int column, byte[] value, int terminator)
/*      */   {
/* 3964 */     lock.lock();
/*      */     try {
/* 3966 */       _gtk_list_store_set(store, iter, column, value, terminator);
/*      */     } finally {
/* 3968 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_list_store_set(long paramLong1, long paramLong2, int paramInt1, int paramInt2, int paramInt3);
/*      */   
/*      */   public static final void gtk_list_store_set(long store, long iter, int column, int value, int terminator)
/*      */   {
/* 3977 */     lock.lock();
/*      */     try {
/* 3979 */       _gtk_list_store_set(store, iter, column, value, terminator);
/*      */     } finally {
/* 3981 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_list_store_set(long paramLong1, long paramLong2, int paramInt1, long paramLong3, int paramInt2);
/*      */   
/*      */   public static final void gtk_list_store_set(long store, long iter, int column, long value, int terminator)
/*      */   {
/* 3990 */     lock.lock();
/*      */     try {
/* 3992 */       _gtk_list_store_set(store, iter, column, value, terminator);
/*      */     } finally {
/* 3994 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_list_store_set(long paramLong1, long paramLong2, int paramInt1, GdkColor paramGdkColor, int paramInt2);
/*      */   
/*      */ 
/*      */   public static final void gtk_list_store_set(long store, long iter, int column, GdkColor value, int terminator)
/*      */   {
/* 4004 */     lock.lock();
/* 4005 */     assert (!GTK3) : "GTK2 code was run by GTK3";
/*      */     try {
/* 4007 */       _gtk_list_store_set(store, iter, column, value, terminator);
/*      */     } finally {
/* 4009 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_list_store_set(long paramLong1, long paramLong2, int paramInt1, GdkRGBA paramGdkRGBA, int paramInt2);
/*      */   
/*      */ 
/*      */   public static final void gtk_list_store_set(long store, long iter, int column, GdkRGBA value, int terminator)
/*      */   {
/* 4019 */     lock.lock();
/* 4020 */     assert (GTK3) : "GTK3 code was run by GTK2";
/*      */     try {
/* 4022 */       _gtk_list_store_set(store, iter, column, value, terminator);
/*      */     } finally {
/* 4024 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_list_store_set(long paramLong1, long paramLong2, int paramInt1, boolean paramBoolean, int paramInt2);
/*      */   
/*      */   public static final void gtk_list_store_set(long store, long iter, int column, boolean value, int terminator)
/*      */   {
/* 4033 */     lock.lock();
/*      */     try {
/* 4035 */       _gtk_list_store_set(store, iter, column, value, terminator);
/*      */     } finally {
/* 4037 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native int _gtk_major_version();
/*      */   
/* 4043 */   public static final int gtk_major_version() { lock.lock();
/*      */     try {
/* 4045 */       return _gtk_major_version();
/*      */     } finally {
/* 4047 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native int _gtk_minor_version();
/*      */   
/* 4053 */   public static final int gtk_minor_version() { lock.lock();
/*      */     try {
/* 4055 */       return _gtk_minor_version();
/*      */     } finally {
/* 4057 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native int _gtk_micro_version();
/*      */   
/* 4063 */   public static final int gtk_micro_version() { lock.lock();
/*      */     try {
/* 4065 */       return _gtk_micro_version();
/*      */     } finally {
/* 4067 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_main();
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_main()
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: invokestatic 323	org/eclipse/swt/internal/gtk/GTK:_gtk_main	()V
/*      */     //   10: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   13: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   16: goto +12 -> 28
/*      */     //   19: astore_0
/*      */     //   20: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   23: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   26: aload_0
/*      */     //   27: athrow
/*      */     //   28: return
/*      */     // Line number table:
/*      */     //   Java source line #4072	-> byte code offset #0
/*      */     //   Java source line #4074	-> byte code offset #7
/*      */     //   Java source line #4076	-> byte code offset #10
/*      */     //   Java source line #4077	-> byte code offset #16
/*      */     //   Java source line #4076	-> byte code offset #19
/*      */     //   Java source line #4077	-> byte code offset #26
/*      */     //   Java source line #4078	-> byte code offset #28
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   19	8	0	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	10	19	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_main_do_event(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_main_do_event(long event)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 324	org/eclipse/swt/internal/gtk/GTK:_gtk_main_do_event	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #4082	-> byte code offset #0
/*      */     //   Java source line #4084	-> byte code offset #7
/*      */     //   Java source line #4086	-> byte code offset #11
/*      */     //   Java source line #4087	-> byte code offset #17
/*      */     //   Java source line #4086	-> byte code offset #20
/*      */     //   Java source line #4087	-> byte code offset #27
/*      */     //   Java source line #4088	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	event	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native long _gtk_menu_bar_new();
/*      */   
/*      */   public static final long gtk_menu_bar_new()
/*      */   {
/* 4091 */     lock.lock();
/*      */     try {
/* 4093 */       return _gtk_menu_bar_new();
/*      */     } finally {
/* 4095 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gtk_menu_item_get_submenu(long paramLong);
/*      */   
/* 4101 */   public static final long gtk_menu_item_get_submenu(long menu_item) { lock.lock();
/*      */     try {
/* 4103 */       return _gtk_menu_item_get_submenu(menu_item);
/*      */     } finally {
/* 4105 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gtk_menu_item_new_with_label(byte[] paramArrayOfByte);
/*      */   
/* 4111 */   public static final long gtk_menu_item_new_with_label(byte[] label) { lock.lock();
/*      */     try {
/* 4113 */       return _gtk_menu_item_new_with_label(label);
/*      */     } finally {
/* 4115 */       lock.unlock();
/*      */     } }
/*      */   
/*      */   public static final native long _gtk_menu_item_new();
/*      */   
/* 4120 */   public static final long gtk_menu_item_new() { lock.lock();
/*      */     try {
/* 4122 */       return _gtk_menu_item_new();
/*      */     } finally {
/* 4124 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_menu_item_set_submenu(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final void gtk_menu_item_set_submenu(long menu_item, long submenu)
/*      */   {
/* 4133 */     lock.lock();
/*      */     try {
/* 4135 */       _gtk_menu_item_set_submenu(menu_item, submenu);
/*      */     } finally {
/* 4137 */       lock.unlock();
/*      */     } }
/*      */   
/*      */   public static final native long _gtk_menu_new();
/*      */   
/* 4142 */   public static final long gtk_menu_new() { lock.lock();
/*      */     try {
/* 4144 */       return _gtk_menu_new();
/*      */     } finally {
/* 4146 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_menu_popdown(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_menu_popdown(long menu)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 331	org/eclipse/swt/internal/gtk/GTK:_gtk_menu_popdown	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #4152	-> byte code offset #0
/*      */     //   Java source line #4154	-> byte code offset #7
/*      */     //   Java source line #4156	-> byte code offset #11
/*      */     //   Java source line #4157	-> byte code offset #17
/*      */     //   Java source line #4156	-> byte code offset #20
/*      */     //   Java source line #4157	-> byte code offset #27
/*      */     //   Java source line #4158	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	menu	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_menu_popup(long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5, int paramInt1, int paramInt2);
/*      */   
/*      */   public static final void gtk_menu_popup(long menu, long parent_menu_shell, long parent_menu_item, long func, long data, int button, int activate_time)
/*      */   {
/* 4172 */     lock.lock();
/*      */     try {
/* 4174 */       _gtk_menu_popup(menu, parent_menu_shell, parent_menu_item, func, data, button, activate_time);
/*      */     } finally {
/* 4176 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_menu_popup_at_pointer(long paramLong1, long paramLong2);
/*      */   
/*      */   public static void gtk_menu_popup_at_pointer(long menu, long trigger_event)
/*      */   {
/* 4184 */     lock.lock();
/*      */     try {
/* 4186 */       _gtk_menu_popup_at_pointer(menu, trigger_event);
/*      */     } finally {
/* 4188 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_menu_popup_at_rect(long paramLong1, long paramLong2, GdkRectangle paramGdkRectangle, int paramInt1, int paramInt2, long paramLong3);
/*      */   
/*      */   public static void gtk_menu_popup_at_rect(long menu, long rect_window, GdkRectangle rect, int rect_anchor, int menu_anchor, long trigger_event)
/*      */   {
/* 4196 */     lock.lock();
/*      */     try {
/* 4198 */       _gtk_menu_popup_at_rect(menu, rect_window, rect, rect_anchor, menu_anchor, trigger_event);
/*      */     } finally {
/* 4200 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_menu_shell_deactivate(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_menu_shell_deactivate(long menu_shell)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 335	org/eclipse/swt/internal/gtk/GTK:_gtk_menu_shell_deactivate	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #4206	-> byte code offset #0
/*      */     //   Java source line #4208	-> byte code offset #7
/*      */     //   Java source line #4210	-> byte code offset #11
/*      */     //   Java source line #4211	-> byte code offset #17
/*      */     //   Java source line #4210	-> byte code offset #20
/*      */     //   Java source line #4211	-> byte code offset #27
/*      */     //   Java source line #4212	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	menu_shell	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_menu_shell_insert(long paramLong1, long paramLong2, int paramInt);
/*      */   
/*      */   public static final void gtk_menu_shell_insert(long menu_shell, long child, int position)
/*      */   {
/* 4220 */     lock.lock();
/*      */     try {
/* 4222 */       _gtk_menu_shell_insert(menu_shell, child, position);
/*      */     } finally {
/* 4224 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_menu_shell_set_take_focus(long paramLong, boolean paramBoolean);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_menu_shell_set_take_focus(long menu_shell, boolean take_focus)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 337	org/eclipse/swt/internal/gtk/GTK:_gtk_menu_shell_set_take_focus	(JZ)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #4233	-> byte code offset #0
/*      */     //   Java source line #4235	-> byte code offset #7
/*      */     //   Java source line #4237	-> byte code offset #12
/*      */     //   Java source line #4238	-> byte code offset #18
/*      */     //   Java source line #4237	-> byte code offset #21
/*      */     //   Java source line #4238	-> byte code offset #28
/*      */     //   Java source line #4239	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	menu_shell	long
/*      */     //   0	31	2	take_focus	boolean
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native long _gtk_menu_tool_button_new(long paramLong, byte[] paramArrayOfByte);
/*      */   
/*      */   public static final long gtk_menu_tool_button_new(long icon_widget, byte[] label)
/*      */   {
/* 4246 */     lock.lock();
/*      */     try {
/* 4248 */       return _gtk_menu_tool_button_new(icon_widget, label);
/*      */     } finally {
/* 4250 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final native long _gtk_message_dialog_new(long paramLong, int paramInt1, int paramInt2, int paramInt3, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2);
/*      */   
/*      */ 
/*      */ 
/*      */   public static final long gtk_message_dialog_new(long parent, int flags, int type, int buttons, byte[] message_format, byte[] arg)
/*      */   {
/* 4263 */     lock.lock();
/*      */     try {
/* 4265 */       return _gtk_message_dialog_new(parent, flags, type, buttons, message_format, arg);
/*      */     } finally {
/* 4267 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final native void _gtk_misc_set_alignment(long paramLong, float paramFloat1, float paramFloat2);
/*      */   
/*      */ 
/*      */ 
/*      */   public static final void gtk_misc_set_alignment(long misc, float xalign, float yalign)
/*      */   {
/* 4279 */     lock.lock();
/*      */     try {
/* 4281 */       _gtk_misc_set_alignment(misc, xalign, yalign);
/*      */     } finally {
/* 4283 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native int _gtk_notebook_get_current_page(long paramLong);
/*      */   
/* 4289 */   public static final int gtk_notebook_get_current_page(long notebook) { lock.lock();
/*      */     try {
/* 4291 */       return _gtk_notebook_get_current_page(notebook);
/*      */     } finally {
/* 4293 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native boolean _gtk_notebook_get_scrollable(long paramLong);
/*      */   
/* 4299 */   public static final boolean gtk_notebook_get_scrollable(long notebook) { lock.lock();
/*      */     try {
/* 4301 */       return _gtk_notebook_get_scrollable(notebook);
/*      */     } finally {
/* 4303 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final native void _gtk_notebook_insert_page(long paramLong1, long paramLong2, long paramLong3, int paramInt);
/*      */   
/*      */ 
/*      */   public static final void gtk_notebook_insert_page(long notebook, long child, long tab_label, int position)
/*      */   {
/* 4314 */     lock.lock();
/*      */     try {
/* 4316 */       _gtk_notebook_insert_page(notebook, child, tab_label, position);
/*      */     } finally {
/* 4318 */       lock.unlock();
/*      */     } }
/*      */   
/*      */   public static final native long _gtk_notebook_new();
/*      */   
/* 4323 */   public static final long gtk_notebook_new() { lock.lock();
/*      */     try {
/* 4325 */       return _gtk_notebook_new();
/*      */     } finally {
/* 4327 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_notebook_next_page(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_notebook_next_page(long notebook)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 345	org/eclipse/swt/internal/gtk/GTK:_gtk_notebook_next_page	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #4333	-> byte code offset #0
/*      */     //   Java source line #4335	-> byte code offset #7
/*      */     //   Java source line #4337	-> byte code offset #11
/*      */     //   Java source line #4338	-> byte code offset #17
/*      */     //   Java source line #4337	-> byte code offset #20
/*      */     //   Java source line #4338	-> byte code offset #27
/*      */     //   Java source line #4339	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	notebook	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_notebook_prev_page(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_notebook_prev_page(long notebook)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 346	org/eclipse/swt/internal/gtk/GTK:_gtk_notebook_prev_page	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #4343	-> byte code offset #0
/*      */     //   Java source line #4345	-> byte code offset #7
/*      */     //   Java source line #4347	-> byte code offset #11
/*      */     //   Java source line #4348	-> byte code offset #17
/*      */     //   Java source line #4347	-> byte code offset #20
/*      */     //   Java source line #4348	-> byte code offset #27
/*      */     //   Java source line #4349	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	notebook	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_notebook_remove_page(long paramLong, int paramInt);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_notebook_remove_page(long notebook, int page_num)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 347	org/eclipse/swt/internal/gtk/GTK:_gtk_notebook_remove_page	(JI)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #4356	-> byte code offset #0
/*      */     //   Java source line #4358	-> byte code offset #7
/*      */     //   Java source line #4360	-> byte code offset #12
/*      */     //   Java source line #4361	-> byte code offset #18
/*      */     //   Java source line #4360	-> byte code offset #21
/*      */     //   Java source line #4361	-> byte code offset #28
/*      */     //   Java source line #4362	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	notebook	long
/*      */     //   0	31	2	page_num	int
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_notebook_set_current_page(long paramLong, int paramInt);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_notebook_set_current_page(long notebook, int page_num)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 348	org/eclipse/swt/internal/gtk/GTK:_gtk_notebook_set_current_page	(JI)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #4369	-> byte code offset #0
/*      */     //   Java source line #4371	-> byte code offset #7
/*      */     //   Java source line #4373	-> byte code offset #12
/*      */     //   Java source line #4374	-> byte code offset #18
/*      */     //   Java source line #4373	-> byte code offset #21
/*      */     //   Java source line #4374	-> byte code offset #28
/*      */     //   Java source line #4375	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	notebook	long
/*      */     //   0	31	2	page_num	int
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_notebook_set_scrollable(long paramLong, boolean paramBoolean);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_notebook_set_scrollable(long notebook, boolean scrollable)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 349	org/eclipse/swt/internal/gtk/GTK:_gtk_notebook_set_scrollable	(JZ)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #4382	-> byte code offset #0
/*      */     //   Java source line #4384	-> byte code offset #7
/*      */     //   Java source line #4386	-> byte code offset #12
/*      */     //   Java source line #4387	-> byte code offset #18
/*      */     //   Java source line #4386	-> byte code offset #21
/*      */     //   Java source line #4387	-> byte code offset #28
/*      */     //   Java source line #4388	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	notebook	long
/*      */     //   0	31	2	scrollable	boolean
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_notebook_set_show_tabs(long paramLong, boolean paramBoolean);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_notebook_set_show_tabs(long notebook, boolean show_tabs)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 350	org/eclipse/swt/internal/gtk/GTK:_gtk_notebook_set_show_tabs	(JZ)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #4395	-> byte code offset #0
/*      */     //   Java source line #4397	-> byte code offset #7
/*      */     //   Java source line #4399	-> byte code offset #12
/*      */     //   Java source line #4400	-> byte code offset #18
/*      */     //   Java source line #4399	-> byte code offset #21
/*      */     //   Java source line #4400	-> byte code offset #28
/*      */     //   Java source line #4401	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	notebook	long
/*      */     //   0	31	2	show_tabs	boolean
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_notebook_set_tab_pos(long paramLong, int paramInt);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_notebook_set_tab_pos(long notebook, int pos)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 351	org/eclipse/swt/internal/gtk/GTK:_gtk_notebook_set_tab_pos	(JI)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #4408	-> byte code offset #0
/*      */     //   Java source line #4410	-> byte code offset #7
/*      */     //   Java source line #4412	-> byte code offset #12
/*      */     //   Java source line #4413	-> byte code offset #18
/*      */     //   Java source line #4412	-> byte code offset #21
/*      */     //   Java source line #4413	-> byte code offset #28
/*      */     //   Java source line #4414	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	notebook	long
/*      */     //   0	31	2	pos	int
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_orientable_set_orientation(long paramLong, int paramInt);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_orientable_set_orientation(long orientable, int orientation)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 352	org/eclipse/swt/internal/gtk/GTK:_gtk_orientable_set_orientation	(JI)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #4421	-> byte code offset #0
/*      */     //   Java source line #4423	-> byte code offset #7
/*      */     //   Java source line #4425	-> byte code offset #12
/*      */     //   Java source line #4426	-> byte code offset #18
/*      */     //   Java source line #4425	-> byte code offset #21
/*      */     //   Java source line #4426	-> byte code offset #28
/*      */     //   Java source line #4427	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	orientable	long
/*      */     //   0	31	2	orientation	int
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native long _gtk_page_setup_new();
/*      */   
/*      */   public static final long gtk_page_setup_new()
/*      */   {
/* 4430 */     lock.lock();
/*      */     try {
/* 4432 */       return _gtk_page_setup_new();
/*      */     } finally {
/* 4434 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native int _gtk_page_setup_get_orientation(long paramLong);
/*      */   
/*      */   public static final int gtk_page_setup_get_orientation(long setup)
/*      */   {
/* 4442 */     lock.lock();
/*      */     try {
/* 4444 */       return _gtk_page_setup_get_orientation(setup);
/*      */     } finally {
/* 4446 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_page_setup_set_orientation(long paramLong, int paramInt);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_page_setup_set_orientation(long setup, int orientation)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 355	org/eclipse/swt/internal/gtk/GTK:_gtk_page_setup_set_orientation	(JI)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #4455	-> byte code offset #0
/*      */     //   Java source line #4457	-> byte code offset #7
/*      */     //   Java source line #4459	-> byte code offset #12
/*      */     //   Java source line #4460	-> byte code offset #18
/*      */     //   Java source line #4459	-> byte code offset #21
/*      */     //   Java source line #4460	-> byte code offset #28
/*      */     //   Java source line #4461	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	setup	long
/*      */     //   0	31	2	orientation	int
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native long _gtk_page_setup_get_paper_size(long paramLong);
/*      */   
/*      */   public static final long gtk_page_setup_get_paper_size(long setup)
/*      */   {
/* 4467 */     lock.lock();
/*      */     try {
/* 4469 */       return _gtk_page_setup_get_paper_size(setup);
/*      */     } finally {
/* 4471 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_page_setup_set_paper_size(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final void gtk_page_setup_set_paper_size(long setup, long size)
/*      */   {
/* 4480 */     lock.lock();
/*      */     try {
/* 4482 */       _gtk_page_setup_set_paper_size(setup, size);
/*      */     } finally {
/* 4484 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native double _gtk_page_setup_get_top_margin(long paramLong, int paramInt);
/*      */   
/*      */   public static final double gtk_page_setup_get_top_margin(long setup, int unit)
/*      */   {
/* 4493 */     lock.lock();
/*      */     try {
/* 4495 */       return _gtk_page_setup_get_top_margin(setup, unit);
/*      */     } finally {
/* 4497 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_page_setup_set_top_margin(long paramLong, double paramDouble, int paramInt);
/*      */   
/*      */ 
/*      */   public static final void gtk_page_setup_set_top_margin(long setup, double margin, int unit)
/*      */   {
/* 4507 */     lock.lock();
/*      */     try {
/* 4509 */       _gtk_page_setup_set_top_margin(setup, margin, unit);
/*      */     } finally {
/* 4511 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native double _gtk_page_setup_get_bottom_margin(long paramLong, int paramInt);
/*      */   
/*      */ 
/*      */   public static final double gtk_page_setup_get_bottom_margin(long setup, int unit)
/*      */   {
/* 4521 */     lock.lock();
/*      */     try {
/* 4523 */       return _gtk_page_setup_get_bottom_margin(setup, unit);
/*      */     } finally {
/* 4525 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_page_setup_set_bottom_margin(long paramLong, double paramDouble, int paramInt);
/*      */   
/*      */ 
/*      */   public static final void gtk_page_setup_set_bottom_margin(long setup, double margin, int unit)
/*      */   {
/* 4535 */     lock.lock();
/*      */     try {
/* 4537 */       _gtk_page_setup_set_bottom_margin(setup, margin, unit);
/*      */     } finally {
/* 4539 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native double _gtk_page_setup_get_left_margin(long paramLong, int paramInt);
/*      */   
/*      */   public static final double gtk_page_setup_get_left_margin(long setup, int unit)
/*      */   {
/* 4548 */     lock.lock();
/*      */     try {
/* 4550 */       return _gtk_page_setup_get_left_margin(setup, unit);
/*      */     } finally {
/* 4552 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_page_setup_set_left_margin(long paramLong, double paramDouble, int paramInt);
/*      */   
/*      */ 
/*      */   public static final void gtk_page_setup_set_left_margin(long setup, double margin, int unit)
/*      */   {
/* 4562 */     lock.lock();
/*      */     try {
/* 4564 */       _gtk_page_setup_set_left_margin(setup, margin, unit);
/*      */     } finally {
/* 4566 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native double _gtk_page_setup_get_right_margin(long paramLong, int paramInt);
/*      */   
/*      */   public static final double gtk_page_setup_get_right_margin(long setup, int unit)
/*      */   {
/* 4575 */     lock.lock();
/*      */     try {
/* 4577 */       return _gtk_page_setup_get_right_margin(setup, unit);
/*      */     } finally {
/* 4579 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_page_setup_set_right_margin(long paramLong, double paramDouble, int paramInt);
/*      */   
/*      */ 
/*      */   public static final void gtk_page_setup_set_right_margin(long setup, double margin, int unit)
/*      */   {
/* 4589 */     lock.lock();
/*      */     try {
/* 4591 */       _gtk_page_setup_set_right_margin(setup, margin, unit);
/*      */     } finally {
/* 4593 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native double _gtk_page_setup_get_paper_width(long paramLong, int paramInt);
/*      */   
/*      */   public static final double gtk_page_setup_get_paper_width(long setup, int unit)
/*      */   {
/* 4602 */     lock.lock();
/*      */     try {
/* 4604 */       return _gtk_page_setup_get_paper_width(setup, unit);
/*      */     } finally {
/* 4606 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native double _gtk_page_setup_get_paper_height(long paramLong, int paramInt);
/*      */   
/*      */   public static final double gtk_page_setup_get_paper_height(long setup, int unit)
/*      */   {
/* 4615 */     lock.lock();
/*      */     try {
/* 4617 */       return _gtk_page_setup_get_paper_height(setup, unit);
/*      */     } finally {
/* 4619 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native double _gtk_page_setup_get_page_width(long paramLong, int paramInt);
/*      */   
/*      */   public static final double gtk_page_setup_get_page_width(long setup, int unit)
/*      */   {
/* 4628 */     lock.lock();
/*      */     try {
/* 4630 */       return _gtk_page_setup_get_page_width(setup, unit);
/*      */     } finally {
/* 4632 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native double _gtk_page_setup_get_page_height(long paramLong, int paramInt);
/*      */   
/*      */   public static final double gtk_page_setup_get_page_height(long setup, int unit)
/*      */   {
/* 4641 */     lock.lock();
/*      */     try {
/* 4643 */       return _gtk_page_setup_get_page_height(setup, unit);
/*      */     } finally {
/* 4645 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final native void _gtk_paint_handle(long paramLong1, long paramLong2, int paramInt1, int paramInt2, GdkRectangle paramGdkRectangle, long paramLong3, byte[] paramArrayOfByte, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7);
/*      */   
/*      */ 
/*      */ 
/*      */   public static final void gtk_paint_handle(long style, long window, int state_type, int shadow_type, GdkRectangle area, long widget, byte[] detail, int x, int y, int width, int height, int orientation)
/*      */   {
/* 4658 */     lock.lock();
/*      */     try {
/* 4660 */       _gtk_paint_handle(style, window, state_type, shadow_type, area, widget, detail, x, y, width, height, orientation);
/*      */     } finally {
/* 4662 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final native void _gtk_render_frame(long paramLong1, long paramLong2, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4);
/*      */   
/*      */ 
/*      */ 
/*      */   public static final void gtk_render_frame(long context, long cr, double x, double y, double width, double height)
/*      */   {
/* 4674 */     lock.lock();
/*      */     try {
/* 4676 */       _gtk_render_frame(context, cr, x, y, width, height);
/*      */     } finally {
/* 4678 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final native void _gtk_render_background(long paramLong1, long paramLong2, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4);
/*      */   
/*      */ 
/*      */ 
/*      */   public static final void gtk_render_background(long context, long cr, double x, double y, double width, double height)
/*      */   {
/* 4690 */     lock.lock();
/*      */     try {
/* 4692 */       _gtk_render_background(context, cr, x, y, width, height);
/*      */     } finally {
/* 4694 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final native void _gtk_paint_flat_box(long paramLong1, long paramLong2, int paramInt1, int paramInt2, GdkRectangle paramGdkRectangle, long paramLong3, byte[] paramArrayOfByte, int paramInt3, int paramInt4, int paramInt5, int paramInt6);
/*      */   
/*      */ 
/*      */ 
/*      */   public static final void gtk_paint_flat_box(long style, long window, int state_type, int shadow_type, GdkRectangle area, long widget, byte[] detail, int x, int y, int width, int height)
/*      */   {
/* 4706 */     lock.lock();
/*      */     try {
/* 4708 */       _gtk_paint_flat_box(style, window, state_type, shadow_type, area, widget, detail, x, y, width, height);
/*      */     } finally {
/* 4710 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final native void _gtk_render_focus(long paramLong1, long paramLong2, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4);
/*      */   
/*      */ 
/*      */ 
/*      */   public static final void gtk_render_focus(long context, long cr, double x, double y, double width, double height)
/*      */   {
/* 4722 */     lock.lock();
/*      */     try {
/* 4724 */       _gtk_render_focus(context, cr, x, y, width, height);
/*      */     } finally {
/* 4726 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final native void _gtk_paint_box(long paramLong1, long paramLong2, int paramInt1, int paramInt2, GdkRectangle paramGdkRectangle, long paramLong3, byte[] paramArrayOfByte, int paramInt3, int paramInt4, int paramInt5, int paramInt6);
/*      */   
/*      */ 
/*      */ 
/*      */   public static final void gtk_paint_box(long style, long window, int state_type, int shadow_type, GdkRectangle area, long widget, byte[] detail, int x, int y, int width, int height)
/*      */   {
/* 4738 */     lock.lock();
/*      */     try {
/* 4740 */       _gtk_paint_box(style, window, state_type, shadow_type, area, widget, detail, x, y, width, height);
/*      */     } finally {
/* 4742 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_paper_size_free(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_paper_size_free(long size)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 376	org/eclipse/swt/internal/gtk/GTK:_gtk_paper_size_free	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #4750	-> byte code offset #0
/*      */     //   Java source line #4752	-> byte code offset #7
/*      */     //   Java source line #4754	-> byte code offset #11
/*      */     //   Java source line #4755	-> byte code offset #17
/*      */     //   Java source line #4754	-> byte code offset #20
/*      */     //   Java source line #4755	-> byte code offset #27
/*      */     //   Java source line #4756	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	size	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native long _gtk_paper_size_new(byte[] paramArrayOfByte);
/*      */   
/*      */   public static final long gtk_paper_size_new(byte[] name)
/*      */   {
/* 4762 */     lock.lock();
/*      */     try {
/* 4764 */       return _gtk_paper_size_new(name);
/*      */     } finally {
/* 4766 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final native long _gtk_paper_size_new_from_ppd(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, double paramDouble1, double paramDouble2);
/*      */   
/*      */ 
/*      */   public static final long gtk_paper_size_new_from_ppd(byte[] ppd_name, byte[] ppd_display_name, double width, double height)
/*      */   {
/* 4777 */     lock.lock();
/*      */     try {
/* 4779 */       return _gtk_paper_size_new_from_ppd(ppd_name, ppd_display_name, width, height);
/*      */     } finally {
/* 4781 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final native long _gtk_paper_size_new_custom(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, double paramDouble1, double paramDouble2, int paramInt);
/*      */   
/*      */ 
/*      */ 
/*      */   public static final long gtk_paper_size_new_custom(byte[] name, byte[] display_name, double width, double height, int unit)
/*      */   {
/* 4793 */     lock.lock();
/*      */     try {
/* 4795 */       return _gtk_paper_size_new_custom(name, display_name, width, height, unit);
/*      */     } finally {
/* 4797 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gtk_paper_size_get_name(long paramLong);
/*      */   
/*      */   public static final long gtk_paper_size_get_name(long size)
/*      */   {
/* 4805 */     lock.lock();
/*      */     try {
/* 4807 */       return _gtk_paper_size_get_name(size);
/*      */     } finally {
/* 4809 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gtk_paper_size_get_display_name(long paramLong);
/*      */   
/*      */   public static final long gtk_paper_size_get_display_name(long size)
/*      */   {
/* 4817 */     lock.lock();
/*      */     try {
/* 4819 */       return _gtk_paper_size_get_display_name(size);
/*      */     } finally {
/* 4821 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gtk_paper_size_get_ppd_name(long paramLong);
/*      */   
/*      */   public static final long gtk_paper_size_get_ppd_name(long size)
/*      */   {
/* 4829 */     lock.lock();
/*      */     try {
/* 4831 */       return _gtk_paper_size_get_ppd_name(size);
/*      */     } finally {
/* 4833 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native double _gtk_paper_size_get_width(long paramLong, int paramInt);
/*      */   
/*      */   public static final double gtk_paper_size_get_width(long size, int unit)
/*      */   {
/* 4842 */     lock.lock();
/*      */     try {
/* 4844 */       return _gtk_paper_size_get_width(size, unit);
/*      */     } finally {
/* 4846 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native double _gtk_paper_size_get_height(long paramLong, int paramInt);
/*      */   
/*      */   public static final double gtk_paper_size_get_height(long size, int unit)
/*      */   {
/* 4855 */     lock.lock();
/*      */     try {
/* 4857 */       return _gtk_paper_size_get_height(size, unit);
/*      */     } finally {
/* 4859 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native boolean _gtk_paper_size_is_custom(long paramLong);
/*      */   
/*      */   public static final boolean gtk_paper_size_is_custom(long size)
/*      */   {
/* 4867 */     lock.lock();
/*      */     try {
/* 4869 */       return _gtk_paper_size_is_custom(size);
/*      */     } finally {
/* 4871 */       lock.unlock();
/*      */     } }
/*      */   
/*      */   public static final native long _gtk_plug_new(long paramLong);
/*      */   
/* 4876 */   public static final long gtk_plug_new(long socket_id) { lock.lock();
/*      */     try {
/* 4878 */       return _gtk_plug_new(socket_id);
/*      */     } finally {
/* 4880 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gtk_printer_get_backend(long paramLong);
/*      */   
/*      */   public static final long gtk_printer_get_backend(long printer)
/*      */   {
/* 4888 */     lock.lock();
/*      */     try {
/* 4890 */       return _gtk_printer_get_backend(printer);
/*      */     } finally {
/* 4892 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gtk_printer_get_name(long paramLong);
/*      */   
/*      */   public static final long gtk_printer_get_name(long printer)
/*      */   {
/* 4900 */     lock.lock();
/*      */     try {
/* 4902 */       return _gtk_printer_get_name(printer);
/*      */     } finally {
/* 4904 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native boolean _gtk_printer_is_default(long paramLong);
/*      */   
/*      */   public static final boolean gtk_printer_is_default(long printer)
/*      */   {
/* 4912 */     lock.lock();
/*      */     try {
/* 4914 */       return _gtk_printer_is_default(printer);
/*      */     } finally {
/* 4916 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final native void _gtk_enumerate_printers(long paramLong1, long paramLong2, long paramLong3, boolean paramBoolean);
/*      */   
/*      */ 
/*      */   public static final void gtk_enumerate_printers(long func, long data, long destroy, boolean wait)
/*      */   {
/* 4927 */     lock.lock();
/*      */     try {
/* 4929 */       _gtk_enumerate_printers(func, data, destroy, wait);
/*      */     } finally {
/* 4931 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final native long _gtk_print_job_new(byte[] paramArrayOfByte, long paramLong1, long paramLong2, long paramLong3);
/*      */   
/*      */ 
/*      */   public static final long gtk_print_job_new(byte[] title, long printer, long settings, long page_setup)
/*      */   {
/* 4942 */     lock.lock();
/*      */     try {
/* 4944 */       return _gtk_print_job_new(title, printer, settings, page_setup);
/*      */     } finally {
/* 4946 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native long _gtk_print_job_get_surface(long paramLong, long[] paramArrayOfLong);
/*      */   
/*      */   public static final long gtk_print_job_get_surface(long job, long[] error)
/*      */   {
/* 4955 */     lock.lock();
/*      */     try {
/* 4957 */       return _gtk_print_job_get_surface(job, error);
/*      */     } finally {
/* 4959 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final native void _gtk_print_job_send(long paramLong1, long paramLong2, long paramLong3, long paramLong4);
/*      */   
/*      */ 
/*      */   public static final void gtk_print_job_send(long job, long callback, long user_data, long dnotify)
/*      */   {
/* 4970 */     lock.lock();
/*      */     try {
/* 4972 */       _gtk_print_job_send(job, callback, user_data, dnotify);
/*      */     } finally {
/* 4974 */       lock.unlock();
/*      */     } }
/*      */   
/*      */   public static final native long _gtk_print_settings_new();
/*      */   
/* 4979 */   public static final long gtk_print_settings_new() { lock.lock();
/*      */     try {
/* 4981 */       return _gtk_print_settings_new();
/*      */     } finally {
/* 4983 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_print_settings_foreach(long paramLong1, long paramLong2, long paramLong3);
/*      */   
/*      */ 
/*      */   public static final void gtk_print_settings_foreach(long settings, long func, long data)
/*      */   {
/* 4993 */     lock.lock();
/*      */     try {
/* 4995 */       _gtk_print_settings_foreach(settings, func, data);
/*      */     } finally {
/* 4997 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native long _gtk_print_settings_get(long paramLong, byte[] paramArrayOfByte);
/*      */   
/*      */   public static final long gtk_print_settings_get(long settings, byte[] key)
/*      */   {
/* 5006 */     lock.lock();
/*      */     try {
/* 5008 */       return _gtk_print_settings_get(settings, key);
/*      */     } finally {
/* 5010 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_print_settings_set(long paramLong, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2);
/*      */   
/*      */ 
/*      */   public static final void gtk_print_settings_set(long settings, byte[] key, byte[] value)
/*      */   {
/* 5020 */     lock.lock();
/*      */     try {
/* 5022 */       _gtk_print_settings_set(settings, key, value);
/*      */     } finally {
/* 5024 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_print_settings_set_printer(long paramLong, byte[] paramArrayOfByte);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_print_settings_set_printer(long settings, byte[] printer)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: aload_2
/*      */     //   9: invokestatic 398	org/eclipse/swt/internal/gtk/GTK:_gtk_print_settings_set_printer	(J[B)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #5033	-> byte code offset #0
/*      */     //   Java source line #5035	-> byte code offset #7
/*      */     //   Java source line #5037	-> byte code offset #12
/*      */     //   Java source line #5038	-> byte code offset #18
/*      */     //   Java source line #5037	-> byte code offset #21
/*      */     //   Java source line #5038	-> byte code offset #28
/*      */     //   Java source line #5039	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	settings	long
/*      */     //   0	31	2	printer	byte[]
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_print_settings_set_orientation(long paramLong, int paramInt);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_print_settings_set_orientation(long settings, int orientation)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 399	org/eclipse/swt/internal/gtk/GTK:_gtk_print_settings_set_orientation	(JI)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #5046	-> byte code offset #0
/*      */     //   Java source line #5048	-> byte code offset #7
/*      */     //   Java source line #5050	-> byte code offset #12
/*      */     //   Java source line #5051	-> byte code offset #18
/*      */     //   Java source line #5050	-> byte code offset #21
/*      */     //   Java source line #5051	-> byte code offset #28
/*      */     //   Java source line #5052	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	settings	long
/*      */     //   0	31	2	orientation	int
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native boolean _gtk_print_settings_get_collate(long paramLong);
/*      */   
/*      */   public static final boolean gtk_print_settings_get_collate(long settings)
/*      */   {
/* 5058 */     lock.lock();
/*      */     try {
/* 5060 */       return _gtk_print_settings_get_collate(settings);
/*      */     } finally {
/* 5062 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_print_settings_set_collate(long paramLong, boolean paramBoolean);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_print_settings_set_collate(long settings, boolean collate)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 401	org/eclipse/swt/internal/gtk/GTK:_gtk_print_settings_set_collate	(JZ)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #5071	-> byte code offset #0
/*      */     //   Java source line #5073	-> byte code offset #7
/*      */     //   Java source line #5075	-> byte code offset #12
/*      */     //   Java source line #5076	-> byte code offset #18
/*      */     //   Java source line #5075	-> byte code offset #21
/*      */     //   Java source line #5076	-> byte code offset #28
/*      */     //   Java source line #5077	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	settings	long
/*      */     //   0	31	2	collate	boolean
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native int _gtk_print_settings_get_duplex(long paramLong);
/*      */   
/*      */   public static final int gtk_print_settings_get_duplex(long settings)
/*      */   {
/* 5083 */     lock.lock();
/*      */     try {
/* 5085 */       return _gtk_print_settings_get_duplex(settings);
/*      */     } finally {
/* 5087 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_print_settings_set_duplex(long paramLong, int paramInt);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_print_settings_set_duplex(long settings, int duplex)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 403	org/eclipse/swt/internal/gtk/GTK:_gtk_print_settings_set_duplex	(JI)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #5096	-> byte code offset #0
/*      */     //   Java source line #5098	-> byte code offset #7
/*      */     //   Java source line #5100	-> byte code offset #12
/*      */     //   Java source line #5101	-> byte code offset #18
/*      */     //   Java source line #5100	-> byte code offset #21
/*      */     //   Java source line #5101	-> byte code offset #28
/*      */     //   Java source line #5102	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	settings	long
/*      */     //   0	31	2	duplex	int
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native int _gtk_print_settings_get_n_copies(long paramLong);
/*      */   
/*      */   public static final int gtk_print_settings_get_n_copies(long settings)
/*      */   {
/* 5108 */     lock.lock();
/*      */     try {
/* 5110 */       return _gtk_print_settings_get_n_copies(settings);
/*      */     } finally {
/* 5112 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_print_settings_set_n_copies(long paramLong, int paramInt);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_print_settings_set_n_copies(long settings, int num_copies)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 405	org/eclipse/swt/internal/gtk/GTK:_gtk_print_settings_set_n_copies	(JI)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #5121	-> byte code offset #0
/*      */     //   Java source line #5123	-> byte code offset #7
/*      */     //   Java source line #5125	-> byte code offset #12
/*      */     //   Java source line #5126	-> byte code offset #18
/*      */     //   Java source line #5125	-> byte code offset #21
/*      */     //   Java source line #5126	-> byte code offset #28
/*      */     //   Java source line #5127	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	settings	long
/*      */     //   0	31	2	num_copies	int
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native int _gtk_print_settings_get_print_pages(long paramLong);
/*      */   
/*      */   public static final int gtk_print_settings_get_print_pages(long settings)
/*      */   {
/* 5133 */     lock.lock();
/*      */     try {
/* 5135 */       return _gtk_print_settings_get_print_pages(settings);
/*      */     } finally {
/* 5137 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_print_settings_set_print_pages(long paramLong, int paramInt);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_print_settings_set_print_pages(long settings, int pages)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 407	org/eclipse/swt/internal/gtk/GTK:_gtk_print_settings_set_print_pages	(JI)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #5146	-> byte code offset #0
/*      */     //   Java source line #5148	-> byte code offset #7
/*      */     //   Java source line #5150	-> byte code offset #12
/*      */     //   Java source line #5151	-> byte code offset #18
/*      */     //   Java source line #5150	-> byte code offset #21
/*      */     //   Java source line #5151	-> byte code offset #28
/*      */     //   Java source line #5152	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	settings	long
/*      */     //   0	31	2	pages	int
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native long _gtk_print_settings_get_page_ranges(long paramLong, int[] paramArrayOfInt);
/*      */   
/*      */   public static final long gtk_print_settings_get_page_ranges(long settings, int[] num_ranges)
/*      */   {
/* 5159 */     lock.lock();
/*      */     try {
/* 5161 */       return _gtk_print_settings_get_page_ranges(settings, num_ranges);
/*      */     } finally {
/* 5163 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_print_settings_set_page_ranges(long paramLong, int[] paramArrayOfInt, int paramInt);
/*      */   
/*      */ 
/*      */   public static final void gtk_print_settings_set_page_ranges(long settings, int[] page_ranges, int num_ranges)
/*      */   {
/* 5173 */     lock.lock();
/*      */     try {
/* 5175 */       _gtk_print_settings_set_page_ranges(settings, page_ranges, num_ranges);
/*      */     } finally {
/* 5177 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native int _gtk_print_settings_get_resolution(long paramLong);
/*      */   
/*      */   public static final int gtk_print_settings_get_resolution(long settings)
/*      */   {
/* 5185 */     lock.lock();
/*      */     try {
/* 5187 */       return _gtk_print_settings_get_resolution(settings);
/*      */     } finally {
/* 5189 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native long _gtk_print_unix_dialog_new(byte[] paramArrayOfByte, long paramLong);
/*      */   
/*      */   public static final long gtk_print_unix_dialog_new(byte[] title, long parent)
/*      */   {
/* 5198 */     lock.lock();
/*      */     try {
/* 5200 */       return _gtk_print_unix_dialog_new(title, parent);
/*      */     } finally {
/* 5202 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_print_unix_dialog_set_embed_page_setup(long paramLong, boolean paramBoolean);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_print_unix_dialog_set_embed_page_setup(long dialog, boolean embed)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 412	org/eclipse/swt/internal/gtk/GTK:_gtk_print_unix_dialog_set_embed_page_setup	(JZ)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #5211	-> byte code offset #0
/*      */     //   Java source line #5213	-> byte code offset #7
/*      */     //   Java source line #5215	-> byte code offset #12
/*      */     //   Java source line #5216	-> byte code offset #18
/*      */     //   Java source line #5215	-> byte code offset #21
/*      */     //   Java source line #5216	-> byte code offset #28
/*      */     //   Java source line #5217	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	dialog	long
/*      */     //   0	31	2	embed	boolean
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_print_unix_dialog_set_page_setup(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final void gtk_print_unix_dialog_set_page_setup(long dialog, long page_setup)
/*      */   {
/* 5224 */     lock.lock();
/*      */     try {
/* 5226 */       _gtk_print_unix_dialog_set_page_setup(dialog, page_setup);
/*      */     } finally {
/* 5228 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gtk_print_unix_dialog_get_page_setup(long paramLong);
/*      */   
/*      */   public static final long gtk_print_unix_dialog_get_page_setup(long dialog)
/*      */   {
/* 5236 */     lock.lock();
/*      */     try {
/* 5238 */       return _gtk_print_unix_dialog_get_page_setup(dialog);
/*      */     } finally {
/* 5240 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_print_unix_dialog_set_current_page(long paramLong, int paramInt);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_print_unix_dialog_set_current_page(long dialog, int current_page)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 415	org/eclipse/swt/internal/gtk/GTK:_gtk_print_unix_dialog_set_current_page	(JI)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #5249	-> byte code offset #0
/*      */     //   Java source line #5251	-> byte code offset #7
/*      */     //   Java source line #5253	-> byte code offset #12
/*      */     //   Java source line #5254	-> byte code offset #18
/*      */     //   Java source line #5253	-> byte code offset #21
/*      */     //   Java source line #5254	-> byte code offset #28
/*      */     //   Java source line #5255	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	dialog	long
/*      */     //   0	31	2	current_page	int
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native int _gtk_print_unix_dialog_get_current_page(long paramLong);
/*      */   
/*      */   public static final int gtk_print_unix_dialog_get_current_page(long dialog)
/*      */   {
/* 5261 */     lock.lock();
/*      */     try {
/* 5263 */       return _gtk_print_unix_dialog_get_current_page(dialog);
/*      */     } finally {
/* 5265 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_print_unix_dialog_set_settings(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final void gtk_print_unix_dialog_set_settings(long dialog, long settings)
/*      */   {
/* 5274 */     lock.lock();
/*      */     try {
/* 5276 */       _gtk_print_unix_dialog_set_settings(dialog, settings);
/*      */     } finally {
/* 5278 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gtk_print_unix_dialog_get_settings(long paramLong);
/*      */   
/*      */   public static final long gtk_print_unix_dialog_get_settings(long dialog)
/*      */   {
/* 5286 */     lock.lock();
/*      */     try {
/* 5288 */       return _gtk_print_unix_dialog_get_settings(dialog);
/*      */     } finally {
/* 5290 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gtk_print_unix_dialog_get_selected_printer(long paramLong);
/*      */   
/*      */   public static final long gtk_print_unix_dialog_get_selected_printer(long dialog)
/*      */   {
/* 5298 */     lock.lock();
/*      */     try {
/* 5300 */       return _gtk_print_unix_dialog_get_selected_printer(dialog);
/*      */     } finally {
/* 5302 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_print_unix_dialog_set_manual_capabilities(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final void gtk_print_unix_dialog_set_manual_capabilities(long dialog, long capabilities)
/*      */   {
/* 5311 */     lock.lock();
/*      */     try {
/* 5313 */       _gtk_print_unix_dialog_set_manual_capabilities(dialog, capabilities);
/*      */     } finally {
/* 5315 */       lock.unlock();
/*      */     } }
/*      */   
/*      */   public static final native long _gtk_progress_bar_new();
/*      */   
/* 5320 */   public static final long gtk_progress_bar_new() { lock.lock();
/*      */     try {
/* 5322 */       return _gtk_progress_bar_new();
/*      */     } finally {
/* 5324 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_progress_bar_pulse(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_progress_bar_pulse(long pbar)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 422	org/eclipse/swt/internal/gtk/GTK:_gtk_progress_bar_pulse	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #5330	-> byte code offset #0
/*      */     //   Java source line #5332	-> byte code offset #7
/*      */     //   Java source line #5334	-> byte code offset #11
/*      */     //   Java source line #5335	-> byte code offset #17
/*      */     //   Java source line #5334	-> byte code offset #20
/*      */     //   Java source line #5335	-> byte code offset #27
/*      */     //   Java source line #5336	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	pbar	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_progress_bar_set_fraction(long paramLong, double paramDouble);
/*      */   
/*      */   public static final void gtk_progress_bar_set_fraction(long pbar, double fraction)
/*      */   {
/* 5343 */     lock.lock();
/*      */     try {
/* 5345 */       _gtk_progress_bar_set_fraction(pbar, fraction);
/*      */     } finally {
/* 5347 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_progress_bar_set_inverted(long paramLong, boolean paramBoolean);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_progress_bar_set_inverted(long pbar, boolean inverted)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 424	org/eclipse/swt/internal/gtk/GTK:_gtk_progress_bar_set_inverted	(JZ)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #5357	-> byte code offset #0
/*      */     //   Java source line #5359	-> byte code offset #7
/*      */     //   Java source line #5361	-> byte code offset #12
/*      */     //   Java source line #5362	-> byte code offset #18
/*      */     //   Java source line #5361	-> byte code offset #21
/*      */     //   Java source line #5362	-> byte code offset #28
/*      */     //   Java source line #5363	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	pbar	long
/*      */     //   0	31	2	inverted	boolean
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_progress_bar_set_orientation(long paramLong, int paramInt);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_progress_bar_set_orientation(long pbar, int orientation)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 425	org/eclipse/swt/internal/gtk/GTK:_gtk_progress_bar_set_orientation	(JI)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #5370	-> byte code offset #0
/*      */     //   Java source line #5372	-> byte code offset #7
/*      */     //   Java source line #5374	-> byte code offset #12
/*      */     //   Java source line #5375	-> byte code offset #18
/*      */     //   Java source line #5374	-> byte code offset #21
/*      */     //   Java source line #5375	-> byte code offset #28
/*      */     //   Java source line #5376	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	pbar	long
/*      */     //   0	31	2	orientation	int
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native long _gtk_radio_button_get_group(long paramLong);
/*      */   
/*      */   public static final long gtk_radio_button_get_group(long radio_button)
/*      */   {
/* 5380 */     lock.lock();
/*      */     try {
/* 5382 */       return _gtk_radio_button_get_group(radio_button);
/*      */     } finally {
/* 5384 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gtk_radio_button_new(long paramLong);
/*      */   
/* 5390 */   public static final long gtk_radio_button_new(long group) { lock.lock();
/*      */     try {
/* 5392 */       return _gtk_radio_button_new(group);
/*      */     } finally {
/* 5394 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gtk_radio_menu_item_get_group(long paramLong);
/*      */   
/* 5400 */   public static final long gtk_radio_menu_item_get_group(long radio_menu_item) { lock.lock();
/*      */     try {
/* 5402 */       return _gtk_radio_menu_item_get_group(radio_menu_item);
/*      */     } finally {
/* 5404 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gtk_radio_menu_item_new(long paramLong);
/*      */   
/* 5410 */   public static final long gtk_radio_menu_item_new(long group) { lock.lock();
/*      */     try {
/* 5412 */       return _gtk_radio_menu_item_new(group);
/*      */     } finally {
/* 5414 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native long _gtk_radio_menu_item_new_with_label(long paramLong, byte[] paramArrayOfByte);
/*      */   
/*      */   public static final long gtk_radio_menu_item_new_with_label(long group, byte[] label)
/*      */   {
/* 5423 */     lock.lock();
/*      */     try {
/* 5425 */       return _gtk_radio_menu_item_new_with_label(group, label);
/*      */     } finally {
/* 5427 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gtk_range_get_adjustment(long paramLong);
/*      */   
/* 5433 */   public static final long gtk_range_get_adjustment(long range) { lock.lock();
/*      */     try {
/* 5435 */       return _gtk_range_get_adjustment(range);
/*      */     } finally {
/* 5437 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_range_set_increments(long paramLong, double paramDouble1, double paramDouble2);
/*      */   
/* 5443 */   public static final void gtk_range_set_increments(long range, double step, double page) { lock.lock();
/*      */     try {
/* 5445 */       _gtk_range_set_increments(range, step, page);
/*      */     } finally {
/* 5447 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_range_set_inverted(long paramLong, boolean paramBoolean);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_range_set_inverted(long range, boolean setting)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 433	org/eclipse/swt/internal/gtk/GTK:_gtk_range_set_inverted	(JZ)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #5453	-> byte code offset #0
/*      */     //   Java source line #5455	-> byte code offset #7
/*      */     //   Java source line #5457	-> byte code offset #12
/*      */     //   Java source line #5458	-> byte code offset #18
/*      */     //   Java source line #5457	-> byte code offset #21
/*      */     //   Java source line #5458	-> byte code offset #28
/*      */     //   Java source line #5459	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	range	long
/*      */     //   0	31	2	setting	boolean
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_range_set_range(long paramLong, double paramDouble1, double paramDouble2);
/*      */   
/*      */   public static final void gtk_range_set_range(long range, double min, double max)
/*      */   {
/* 5463 */     lock.lock();
/*      */     try {
/* 5465 */       _gtk_range_set_range(range, min, max);
/*      */     } finally {
/* 5467 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_range_set_value(long paramLong, double paramDouble);
/*      */   
/* 5473 */   public static final void gtk_range_set_value(long range, double value) { lock.lock();
/*      */     try {
/* 5475 */       _gtk_range_set_value(range, value);
/*      */     } finally {
/* 5477 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_range_get_slider_range(long paramLong, int[] paramArrayOfInt1, int[] paramArrayOfInt2);
/*      */   
/*      */ 
/*      */   public static final void gtk_range_get_slider_range(long range, int[] slider_start, int[] slider_end)
/*      */   {
/* 5487 */     lock.lock();
/*      */     try {
/* 5489 */       _gtk_range_get_slider_range(range, slider_start, slider_end);
/*      */     } finally {
/* 5491 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_rc_parse_string(byte[] paramArrayOfByte);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_rc_parse_string(byte[] rc_string)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: aload_0
/*      */     //   8: invokestatic 437	org/eclipse/swt/internal/gtk/GTK:_gtk_rc_parse_string	([B)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_1
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_1
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #5501	-> byte code offset #0
/*      */     //   Java source line #5503	-> byte code offset #7
/*      */     //   Java source line #5505	-> byte code offset #11
/*      */     //   Java source line #5506	-> byte code offset #17
/*      */     //   Java source line #5505	-> byte code offset #20
/*      */     //   Java source line #5506	-> byte code offset #27
/*      */     //   Java source line #5507	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	rc_string	byte[]
/*      */     //   20	8	1	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native long _gtk_rc_style_get_bg_pixmap_name(long paramLong, int paramInt);
/*      */   
/*      */   public static final long gtk_rc_style_get_bg_pixmap_name(long style, int index)
/*      */   {
/* 5511 */     lock.lock();
/*      */     try {
/* 5513 */       return _gtk_rc_style_get_bg_pixmap_name(style, index);
/*      */     } finally {
/* 5515 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native int _gtk_rc_style_get_color_flags(long paramLong, int paramInt);
/*      */   
/* 5521 */   public static final int gtk_rc_style_get_color_flags(long style, int index) { lock.lock();
/*      */     try {
/* 5523 */       return _gtk_rc_style_get_color_flags(style, index);
/*      */     } finally {
/* 5525 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_rc_style_set_bg(long paramLong, int paramInt, GdkColor paramGdkColor);
/*      */   
/*      */   public static final void gtk_rc_style_set_bg(long style, int index, GdkColor color)
/*      */   {
/* 5534 */     lock.lock();
/*      */     try {
/* 5536 */       _gtk_rc_style_set_bg(style, index, color);
/*      */     } finally {
/* 5538 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_rc_style_set_bg_pixmap_name(long paramLong1, int paramInt, long paramLong2);
/*      */   
/*      */   public static final void gtk_rc_style_set_bg_pixmap_name(long style, int index, long name)
/*      */   {
/* 5547 */     lock.lock();
/*      */     try {
/* 5549 */       _gtk_rc_style_set_bg_pixmap_name(style, index, name);
/*      */     } finally {
/* 5551 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_rc_style_set_color_flags(long paramLong, int paramInt1, int paramInt2);
/*      */   
/* 5557 */   public static final void gtk_rc_style_set_color_flags(long style, int index, int flag) { lock.lock();
/*      */     try {
/* 5559 */       _gtk_rc_style_set_color_flags(style, index, flag);
/*      */     } finally {
/* 5561 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_scale_set_digits(long paramLong, int paramInt);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_scale_set_digits(long scale, int digits)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 443	org/eclipse/swt/internal/gtk/GTK:_gtk_scale_set_digits	(JI)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #5570	-> byte code offset #0
/*      */     //   Java source line #5572	-> byte code offset #7
/*      */     //   Java source line #5574	-> byte code offset #12
/*      */     //   Java source line #5575	-> byte code offset #18
/*      */     //   Java source line #5574	-> byte code offset #21
/*      */     //   Java source line #5575	-> byte code offset #28
/*      */     //   Java source line #5576	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	scale	long
/*      */     //   0	31	2	digits	int
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_scale_set_draw_value(long paramLong, boolean paramBoolean);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_scale_set_draw_value(long scale, boolean draw_value)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 444	org/eclipse/swt/internal/gtk/GTK:_gtk_scale_set_draw_value	(JZ)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #5583	-> byte code offset #0
/*      */     //   Java source line #5585	-> byte code offset #7
/*      */     //   Java source line #5587	-> byte code offset #12
/*      */     //   Java source line #5588	-> byte code offset #18
/*      */     //   Java source line #5587	-> byte code offset #21
/*      */     //   Java source line #5588	-> byte code offset #28
/*      */     //   Java source line #5589	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	scale	long
/*      */     //   0	31	2	draw_value	boolean
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native long _gtk_scrollable_get_vadjustment(long paramLong);
/*      */   
/*      */   public static final long gtk_scrollable_get_vadjustment(long scrollable)
/*      */   {
/* 5596 */     lock.lock();
/*      */     try {
/* 5598 */       return _gtk_scrollable_get_vadjustment(scrollable);
/*      */     } finally {
/* 5600 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_rc_style_set_fg(long paramLong, int paramInt, GdkColor paramGdkColor);
/*      */   
/*      */   public static final void gtk_rc_style_set_fg(long style, int index, GdkColor color)
/*      */   {
/* 5609 */     lock.lock();
/*      */     try {
/* 5611 */       _gtk_rc_style_set_fg(style, index, color);
/*      */     } finally {
/* 5613 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_rc_style_set_text(long paramLong, int paramInt, GdkColor paramGdkColor);
/*      */   
/*      */   public static final void gtk_rc_style_set_text(long style, int index, GdkColor color)
/*      */   {
/* 5622 */     lock.lock();
/*      */     try {
/* 5624 */       _gtk_rc_style_set_text(style, index, color);
/*      */     } finally {
/* 5626 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final native void _gtk_scrolled_window_add_with_viewport(long paramLong1, long paramLong2);
/*      */   
/*      */ 
/*      */   public static final void gtk_scrolled_window_add_with_viewport(long scrolled_window, long child)
/*      */   {
/* 5637 */     lock.lock();
/*      */     try {
/* 5639 */       _gtk_scrolled_window_add_with_viewport(scrolled_window, child);
/*      */     } finally {
/* 5641 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gtk_scrolled_window_get_hadjustment(long paramLong);
/*      */   
/* 5647 */   public static final long gtk_scrolled_window_get_hadjustment(long scrolled_window) { lock.lock();
/*      */     try {
/* 5649 */       return _gtk_scrolled_window_get_hadjustment(scrolled_window);
/*      */     } finally {
/* 5651 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gtk_scrolled_window_get_hscrollbar(long paramLong);
/*      */   
/*      */   public static final long gtk_scrolled_window_get_hscrollbar(long scrolled_window)
/*      */   {
/* 5659 */     lock.lock();
/*      */     try {
/* 5661 */       return _gtk_scrolled_window_get_hscrollbar(scrolled_window);
/*      */     } finally {
/* 5663 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_scrolled_window_get_policy(long paramLong, int[] paramArrayOfInt1, int[] paramArrayOfInt2);
/*      */   
/*      */ 
/*      */   public static final void gtk_scrolled_window_get_policy(long scrolled_window, int[] hscrollbar_policy, int[] vscrollbar_policy)
/*      */   {
/* 5673 */     lock.lock();
/*      */     try {
/* 5675 */       _gtk_scrolled_window_get_policy(scrolled_window, hscrollbar_policy, vscrollbar_policy);
/*      */     } finally {
/* 5677 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native int _gtk_scrolled_window_get_shadow_type(long paramLong);
/*      */   
/* 5683 */   public static final int gtk_scrolled_window_get_shadow_type(long scrolled_window) { lock.lock();
/*      */     try {
/* 5685 */       return _gtk_scrolled_window_get_shadow_type(scrolled_window);
/*      */     } finally {
/* 5687 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gtk_scrolled_window_get_vadjustment(long paramLong);
/*      */   
/* 5693 */   public static final long gtk_scrolled_window_get_vadjustment(long scrolled_window) { lock.lock();
/*      */     try {
/* 5695 */       return _gtk_scrolled_window_get_vadjustment(scrolled_window);
/*      */     } finally {
/* 5697 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gtk_scrolled_window_get_vscrollbar(long paramLong);
/*      */   
/*      */   public static final long gtk_scrolled_window_get_vscrollbar(long scrolled_window)
/*      */   {
/* 5705 */     lock.lock();
/*      */     try {
/* 5707 */       return _gtk_scrolled_window_get_vscrollbar(scrolled_window);
/*      */     } finally {
/* 5709 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native long _gtk_scrolled_window_new(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final long gtk_scrolled_window_new(long hadjustment, long vadjustment)
/*      */   {
/* 5718 */     lock.lock();
/*      */     try {
/* 5720 */       return _gtk_scrolled_window_new(hadjustment, vadjustment);
/*      */     } finally {
/* 5722 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_scrolled_window_set_policy(long paramLong, int paramInt1, int paramInt2);
/*      */   
/*      */ 
/*      */   public static final void gtk_scrolled_window_set_policy(long scrolled_window, int hscrollbar_policy, int vscrollbar_policy)
/*      */   {
/* 5732 */     lock.lock();
/*      */     try {
/* 5734 */       _gtk_scrolled_window_set_policy(scrolled_window, hscrollbar_policy, vscrollbar_policy);
/*      */     } finally {
/* 5736 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native boolean _gtk_scrolled_window_get_overlay_scrolling(long paramLong);
/*      */   
/*      */   public static final boolean gtk_scrolled_window_get_overlay_scrolling(long scrolled_window)
/*      */   {
/* 5745 */     lock.lock();
/*      */     try {
/* 5747 */       return _gtk_scrolled_window_get_overlay_scrolling(scrolled_window);
/*      */     } finally {
/* 5749 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_scrolled_window_set_shadow_type(long paramLong, int paramInt);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_scrolled_window_set_shadow_type(long scrolled_window, int type)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 458	org/eclipse/swt/internal/gtk/GTK:_gtk_scrolled_window_set_shadow_type	(JI)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #5758	-> byte code offset #0
/*      */     //   Java source line #5760	-> byte code offset #7
/*      */     //   Java source line #5762	-> byte code offset #12
/*      */     //   Java source line #5763	-> byte code offset #18
/*      */     //   Java source line #5762	-> byte code offset #21
/*      */     //   Java source line #5763	-> byte code offset #28
/*      */     //   Java source line #5764	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	scrolled_window	long
/*      */     //   0	31	2	type	int
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native long _gtk_settings_get_default();
/*      */   
/*      */   public static final long gtk_settings_get_default()
/*      */   {
/* 5767 */     lock.lock();
/*      */     try {
/* 5769 */       return _gtk_settings_get_default();
/*      */     } finally {
/* 5771 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final native void _gtk_settings_set_string_property(long paramLong, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3);
/*      */   
/*      */ 
/*      */ 
/*      */   public static final void gtk_settings_set_string_property(long settings, byte[] name, byte[] v_string, byte[] origin)
/*      */   {
/* 5784 */     lock.lock();
/*      */     try {
/* 5786 */       _gtk_settings_set_string_property(settings, name, v_string, origin);
/*      */     } finally {
/* 5788 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_selection_data_free(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_selection_data_free(long selection_data)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 461	org/eclipse/swt/internal/gtk/GTK:_gtk_selection_data_free	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #5794	-> byte code offset #0
/*      */     //   Java source line #5796	-> byte code offset #7
/*      */     //   Java source line #5798	-> byte code offset #11
/*      */     //   Java source line #5799	-> byte code offset #17
/*      */     //   Java source line #5798	-> byte code offset #20
/*      */     //   Java source line #5799	-> byte code offset #27
/*      */     //   Java source line #5800	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	selection_data	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native long _gtk_selection_data_get_data(long paramLong);
/*      */   
/*      */   public static final long gtk_selection_data_get_data(long selection_data)
/*      */   {
/* 5806 */     lock.lock();
/*      */     try {
/* 5808 */       return _gtk_selection_data_get_data(selection_data);
/*      */     } finally {
/* 5810 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native int _gtk_selection_data_get_format(long paramLong);
/*      */   
/*      */   public static final int gtk_selection_data_get_format(long selection_data)
/*      */   {
/* 5818 */     lock.lock();
/*      */     try {
/* 5820 */       return _gtk_selection_data_get_format(selection_data);
/*      */     } finally {
/* 5822 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native int _gtk_selection_data_get_length(long paramLong);
/*      */   
/*      */   public static final int gtk_selection_data_get_length(long selection_data)
/*      */   {
/* 5830 */     lock.lock();
/*      */     try {
/* 5832 */       return _gtk_selection_data_get_length(selection_data);
/*      */     } finally {
/* 5834 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gtk_selection_data_get_target(long paramLong);
/*      */   
/*      */   public static final long gtk_selection_data_get_target(long selection_data)
/*      */   {
/* 5842 */     lock.lock();
/*      */     try {
/* 5844 */       return _gtk_selection_data_get_target(selection_data);
/*      */     } finally {
/* 5846 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gtk_selection_data_get_data_type(long paramLong);
/*      */   
/*      */   public static final long gtk_selection_data_get_data_type(long selection_data)
/*      */   {
/* 5854 */     lock.lock();
/*      */     try {
/* 5856 */       return _gtk_selection_data_get_data_type(selection_data);
/*      */     } finally {
/* 5858 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final native void _gtk_selection_data_set(long paramLong1, long paramLong2, int paramInt1, long paramLong3, int paramInt2);
/*      */   
/*      */ 
/*      */ 
/*      */   public static final void gtk_selection_data_set(long selection_data, long type, int format, long data, int length)
/*      */   {
/* 5870 */     lock.lock();
/*      */     try {
/* 5872 */       _gtk_selection_data_set(selection_data, type, format, data, length);
/*      */     } finally {
/* 5874 */       lock.unlock();
/*      */     } }
/*      */   
/*      */   public static final native long _gtk_separator_menu_item_new();
/*      */   
/* 5879 */   public static final long gtk_separator_menu_item_new() { lock.lock();
/*      */     try {
/* 5881 */       return _gtk_separator_menu_item_new();
/*      */     } finally {
/* 5883 */       lock.unlock();
/*      */     } }
/*      */   
/*      */   public static final native long _gtk_separator_tool_item_new();
/*      */   
/* 5888 */   public static final long gtk_separator_tool_item_new() { lock.lock();
/*      */     try {
/* 5890 */       return _gtk_separator_tool_item_new();
/*      */     } finally {
/* 5892 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_separator_tool_item_set_draw(long paramLong, boolean paramBoolean);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_separator_tool_item_set_draw(long item, boolean draw)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 470	org/eclipse/swt/internal/gtk/GTK:_gtk_separator_tool_item_set_draw	(JZ)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #5901	-> byte code offset #0
/*      */     //   Java source line #5903	-> byte code offset #7
/*      */     //   Java source line #5905	-> byte code offset #12
/*      */     //   Java source line #5906	-> byte code offset #18
/*      */     //   Java source line #5905	-> byte code offset #21
/*      */     //   Java source line #5906	-> byte code offset #28
/*      */     //   Java source line #5907	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	item	long
/*      */     //   0	31	2	draw	boolean
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native long _gtk_socket_get_id(long paramLong);
/*      */   
/*      */   public static final long gtk_socket_get_id(long socket)
/*      */   {
/* 5911 */     lock.lock();
/*      */     try {
/* 5913 */       return _gtk_socket_get_id(socket);
/*      */     } finally {
/* 5915 */       lock.unlock();
/*      */     } }
/*      */   
/*      */   public static final native long _gtk_socket_new();
/*      */   
/* 5920 */   public static final long gtk_socket_new() { lock.lock();
/*      */     try {
/* 5922 */       return _gtk_socket_new();
/*      */     } finally {
/* 5924 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gtk_spin_button_new(long paramLong, double paramDouble, int paramInt);
/*      */   
/* 5930 */   public static final long gtk_spin_button_new(long adjustment, double climb_rate, int digits) { lock.lock();
/*      */     try {
/* 5932 */       return _gtk_spin_button_new(adjustment, climb_rate, digits);
/*      */     } finally {
/* 5934 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_spin_button_set_numeric(long paramLong, boolean paramBoolean);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_spin_button_set_numeric(long spin_button, boolean numeric)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 474	org/eclipse/swt/internal/gtk/GTK:_gtk_spin_button_set_numeric	(JZ)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #5943	-> byte code offset #0
/*      */     //   Java source line #5945	-> byte code offset #7
/*      */     //   Java source line #5947	-> byte code offset #12
/*      */     //   Java source line #5948	-> byte code offset #18
/*      */     //   Java source line #5947	-> byte code offset #21
/*      */     //   Java source line #5948	-> byte code offset #28
/*      */     //   Java source line #5949	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	spin_button	long
/*      */     //   0	31	2	numeric	boolean
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_spin_button_configure(long paramLong1, long paramLong2, double paramDouble, int paramInt);
/*      */   
/*      */   public static final void gtk_spin_button_configure(long spin_button, long adjustment, double climb_rate, int digits)
/*      */   {
/* 5956 */     lock.lock();
/*      */     try {
/* 5958 */       _gtk_spin_button_configure(spin_button, adjustment, climb_rate, digits);
/*      */     } finally {
/* 5960 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gtk_spin_button_get_adjustment(long paramLong);
/*      */   
/* 5966 */   public static final long gtk_spin_button_get_adjustment(long spin_button) { lock.lock();
/*      */     try {
/* 5968 */       return _gtk_spin_button_get_adjustment(spin_button);
/*      */     } finally {
/* 5970 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native int _gtk_spin_button_get_digits(long paramLong);
/*      */   
/* 5976 */   public static final int gtk_spin_button_get_digits(long spin_button) { lock.lock();
/*      */     try {
/* 5978 */       return _gtk_spin_button_get_digits(spin_button);
/*      */     } finally {
/* 5980 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_spin_button_set_digits(long paramLong, int paramInt);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_spin_button_set_digits(long spin_button, int digits)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 478	org/eclipse/swt/internal/gtk/GTK:_gtk_spin_button_set_digits	(JI)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #5986	-> byte code offset #0
/*      */     //   Java source line #5988	-> byte code offset #7
/*      */     //   Java source line #5990	-> byte code offset #12
/*      */     //   Java source line #5991	-> byte code offset #18
/*      */     //   Java source line #5990	-> byte code offset #21
/*      */     //   Java source line #5991	-> byte code offset #28
/*      */     //   Java source line #5992	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	spin_button	long
/*      */     //   0	31	2	digits	int
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_spin_button_set_increments(long paramLong, double paramDouble1, double paramDouble2);
/*      */   
/*      */   public static final void gtk_spin_button_set_increments(long spin_button, double step, double page)
/*      */   {
/* 5996 */     lock.lock();
/*      */     try {
/* 5998 */       _gtk_spin_button_set_increments(spin_button, step, page);
/*      */     } finally {
/* 6000 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_spin_button_set_range(long paramLong, double paramDouble1, double paramDouble2);
/*      */   
/* 6006 */   public static final void gtk_spin_button_set_range(long spin_button, double max, double min) { lock.lock();
/*      */     try {
/* 6008 */       _gtk_spin_button_set_range(spin_button, max, min);
/*      */     } finally {
/* 6010 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_spin_button_set_value(long paramLong, double paramDouble);
/*      */   
/* 6016 */   public static final void gtk_spin_button_set_value(long spin_button, double value) { lock.lock();
/*      */     try {
/* 6018 */       _gtk_spin_button_set_value(spin_button, value);
/*      */     } finally {
/* 6020 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_spin_button_set_wrap(long paramLong, boolean paramBoolean);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_spin_button_set_wrap(long spin_button, boolean wrap)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 482	org/eclipse/swt/internal/gtk/GTK:_gtk_spin_button_set_wrap	(JZ)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #6026	-> byte code offset #0
/*      */     //   Java source line #6028	-> byte code offset #7
/*      */     //   Java source line #6030	-> byte code offset #12
/*      */     //   Java source line #6031	-> byte code offset #18
/*      */     //   Java source line #6030	-> byte code offset #21
/*      */     //   Java source line #6031	-> byte code offset #28
/*      */     //   Java source line #6032	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	spin_button	long
/*      */     //   0	31	2	wrap	boolean
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_spin_button_update(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_spin_button_update(long spin_button)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 483	org/eclipse/swt/internal/gtk/GTK:_gtk_spin_button_update	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #6036	-> byte code offset #0
/*      */     //   Java source line #6038	-> byte code offset #7
/*      */     //   Java source line #6040	-> byte code offset #11
/*      */     //   Java source line #6041	-> byte code offset #17
/*      */     //   Java source line #6040	-> byte code offset #20
/*      */     //   Java source line #6041	-> byte code offset #27
/*      */     //   Java source line #6042	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	spin_button	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native boolean _gtk_status_icon_get_geometry(long paramLong1, long paramLong2, GdkRectangle paramGdkRectangle, long paramLong3);
/*      */   
/*      */   public static final boolean gtk_status_icon_get_geometry(long handle, long screen, GdkRectangle area, long orientation)
/*      */   {
/* 6051 */     lock.lock();
/*      */     try {
/* 6053 */       return _gtk_status_icon_get_geometry(handle, screen, area, orientation);
/*      */     } finally {
/* 6055 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native boolean _gtk_status_icon_get_visible(long paramLong);
/*      */   
/* 6061 */   public static final boolean gtk_status_icon_get_visible(long handle) { lock.lock();
/*      */     try {
/* 6063 */       return _gtk_status_icon_get_visible(handle);
/*      */     } finally {
/* 6065 */       lock.unlock();
/*      */     } }
/*      */   
/*      */   public static final native long _gtk_status_icon_new();
/*      */   
/* 6070 */   public static final long gtk_status_icon_new() { lock.lock();
/*      */     try {
/* 6072 */       return _gtk_status_icon_new();
/*      */     } finally {
/* 6074 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_status_icon_set_from_pixbuf(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final void gtk_status_icon_set_from_pixbuf(long handle, long pixbuf)
/*      */   {
/* 6083 */     lock.lock();
/*      */     try {
/* 6085 */       _gtk_status_icon_set_from_pixbuf(handle, pixbuf);
/*      */     } finally {
/* 6087 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_status_icon_set_visible(long paramLong, boolean paramBoolean);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_status_icon_set_visible(long handle, boolean visible)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 488	org/eclipse/swt/internal/gtk/GTK:_gtk_status_icon_set_visible	(JZ)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #6096	-> byte code offset #0
/*      */     //   Java source line #6098	-> byte code offset #7
/*      */     //   Java source line #6100	-> byte code offset #12
/*      */     //   Java source line #6101	-> byte code offset #18
/*      */     //   Java source line #6100	-> byte code offset #21
/*      */     //   Java source line #6101	-> byte code offset #28
/*      */     //   Java source line #6102	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	handle	long
/*      */     //   0	31	2	visible	boolean
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_status_icon_set_tooltip_text(long paramLong, byte[] paramArrayOfByte);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_status_icon_set_tooltip_text(long handle, byte[] tip_text)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: aload_2
/*      */     //   9: invokestatic 489	org/eclipse/swt/internal/gtk/GTK:_gtk_status_icon_set_tooltip_text	(J[B)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #6109	-> byte code offset #0
/*      */     //   Java source line #6111	-> byte code offset #7
/*      */     //   Java source line #6113	-> byte code offset #12
/*      */     //   Java source line #6114	-> byte code offset #18
/*      */     //   Java source line #6113	-> byte code offset #21
/*      */     //   Java source line #6114	-> byte code offset #28
/*      */     //   Java source line #6115	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	handle	long
/*      */     //   0	31	2	tip_text	byte[]
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_style_get_base(long paramLong, int paramInt, GdkColor paramGdkColor);
/*      */   
/*      */   public static final void gtk_style_get_base(long style, int index, GdkColor color)
/*      */   {
/* 6122 */     lock.lock();
/*      */     try {
/* 6124 */       _gtk_style_get_base(style, index, color);
/*      */     } finally {
/* 6126 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_style_context_add_class(long paramLong, byte[] paramArrayOfByte);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_style_context_add_class(long context, byte[] class_name)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: aload_2
/*      */     //   9: invokestatic 491	org/eclipse/swt/internal/gtk/GTK:_gtk_style_context_add_class	(J[B)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #6132	-> byte code offset #0
/*      */     //   Java source line #6134	-> byte code offset #7
/*      */     //   Java source line #6136	-> byte code offset #12
/*      */     //   Java source line #6137	-> byte code offset #18
/*      */     //   Java source line #6136	-> byte code offset #21
/*      */     //   Java source line #6137	-> byte code offset #28
/*      */     //   Java source line #6138	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	context	long
/*      */     //   0	31	2	class_name	byte[]
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_style_context_get_background_color(long paramLong, int paramInt, GdkRGBA paramGdkRGBA);
/*      */   
/*      */   public static final void gtk_style_context_get_background_color(long context, int state, GdkRGBA color)
/*      */   {
/* 6143 */     lock.lock();
/*      */     try {
/* 6145 */       _gtk_style_context_get_background_color(context, state, color);
/*      */     } finally {
/* 6147 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_style_context_get_color(long paramLong, int paramInt, GdkRGBA paramGdkRGBA);
/*      */   
/* 6153 */   public static final void gtk_style_context_get_color(long context, int state, GdkRGBA color) { lock.lock();
/*      */     try {
/* 6155 */       _gtk_style_context_get_color(context, state, color);
/*      */     } finally {
/* 6157 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gtk_style_context_get_font(long paramLong, int paramInt);
/*      */   
/*      */   public static final long gtk_style_context_get_font(long context, int state) {
/* 6164 */     lock.lock();
/*      */     try {
/* 6166 */       return _gtk_style_context_get_font(context, state);
/*      */     } finally {
/* 6168 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_style_context_get_padding(long paramLong, int paramInt, GtkBorder paramGtkBorder);
/*      */   
/* 6174 */   public static final void gtk_style_context_get_padding(long context, int state, GtkBorder padding) { lock.lock();
/*      */     try {
/* 6176 */       _gtk_style_context_get_padding(context, state, padding);
/*      */     } finally {
/* 6178 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_style_context_get(long paramLong1, int paramInt, byte[] paramArrayOfByte, long[] paramArrayOfLong, long paramLong2);
/*      */   
/*      */ 
/*      */   public static final void gtk_style_context_get(long context, int state, byte[] property, long[] value, long terminator)
/*      */   {
/* 6188 */     lock.lock();
/*      */     try {
/* 6190 */       _gtk_style_context_get(context, state, property, value, terminator);
/*      */     } finally {
/* 6192 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_style_context_get_border(long paramLong, int paramInt, GtkBorder paramGtkBorder);
/*      */   
/* 6198 */   public static final void gtk_style_context_get_border(long context, int state, GtkBorder padding) { lock.lock();
/*      */     try {
/* 6200 */       _gtk_style_context_get_border(context, state, padding);
/*      */     } finally {
/* 6202 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_style_context_invalidate(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_style_context_invalidate(long context)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 498	org/eclipse/swt/internal/gtk/GTK:_gtk_style_context_invalidate	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #6209	-> byte code offset #0
/*      */     //   Java source line #6211	-> byte code offset #7
/*      */     //   Java source line #6213	-> byte code offset #11
/*      */     //   Java source line #6214	-> byte code offset #17
/*      */     //   Java source line #6213	-> byte code offset #20
/*      */     //   Java source line #6214	-> byte code offset #27
/*      */     //   Java source line #6215	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	context	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_style_context_save(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_style_context_save(long self)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 499	org/eclipse/swt/internal/gtk/GTK:_gtk_style_context_save	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #6219	-> byte code offset #0
/*      */     //   Java source line #6221	-> byte code offset #7
/*      */     //   Java source line #6223	-> byte code offset #11
/*      */     //   Java source line #6224	-> byte code offset #17
/*      */     //   Java source line #6223	-> byte code offset #20
/*      */     //   Java source line #6224	-> byte code offset #27
/*      */     //   Java source line #6225	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	self	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_style_context_restore(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_style_context_restore(long context)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 500	org/eclipse/swt/internal/gtk/GTK:_gtk_style_context_restore	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #6229	-> byte code offset #0
/*      */     //   Java source line #6231	-> byte code offset #7
/*      */     //   Java source line #6233	-> byte code offset #11
/*      */     //   Java source line #6234	-> byte code offset #17
/*      */     //   Java source line #6233	-> byte code offset #20
/*      */     //   Java source line #6234	-> byte code offset #27
/*      */     //   Java source line #6235	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	context	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native int _gtk_widget_get_state_flags(long paramLong);
/*      */   
/*      */   public static final int gtk_widget_get_state_flags(long self)
/*      */   {
/* 6241 */     lock.lock();
/*      */     try {
/* 6243 */       return _gtk_widget_get_state_flags(self);
/*      */     } finally {
/* 6245 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_style_context_set_state(long paramLong1, long paramLong2);
/*      */   
/* 6251 */   public static final void gtk_style_context_set_state(long context, long flags) { lock.lock();
/*      */     try {
/* 6253 */       _gtk_style_context_set_state(context, flags);
/*      */     } finally {
/* 6255 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_style_get_black(long paramLong, GdkColor paramGdkColor);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_style_get_black(long style, GdkColor color)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: aload_2
/*      */     //   9: invokestatic 503	org/eclipse/swt/internal/gtk/GTK:_gtk_style_get_black	(JLorg/eclipse/swt/internal/gtk/GdkColor;)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #6264	-> byte code offset #0
/*      */     //   Java source line #6266	-> byte code offset #7
/*      */     //   Java source line #6268	-> byte code offset #12
/*      */     //   Java source line #6269	-> byte code offset #18
/*      */     //   Java source line #6268	-> byte code offset #21
/*      */     //   Java source line #6269	-> byte code offset #28
/*      */     //   Java source line #6270	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	style	long
/*      */     //   0	31	2	color	GdkColor
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_style_get_bg(long paramLong, int paramInt, GdkColor paramGdkColor);
/*      */   
/*      */   public static final void gtk_style_get_bg(long style, int index, GdkColor color)
/*      */   {
/* 6277 */     lock.lock();
/*      */     try {
/* 6279 */       _gtk_style_get_bg(style, index, color);
/*      */     } finally {
/* 6281 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_style_get_dark(long paramLong, int paramInt, GdkColor paramGdkColor);
/*      */   
/*      */   public static final void gtk_style_get_dark(long style, int index, GdkColor color)
/*      */   {
/* 6290 */     lock.lock();
/*      */     try {
/* 6292 */       _gtk_style_get_dark(style, index, color);
/*      */     } finally {
/* 6294 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_style_get_fg(long paramLong, int paramInt, GdkColor paramGdkColor);
/*      */   
/*      */   public static final void gtk_style_get_fg(long style, int index, GdkColor color)
/*      */   {
/* 6303 */     lock.lock();
/*      */     try {
/* 6305 */       _gtk_style_get_fg(style, index, color);
/*      */     } finally {
/* 6307 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gtk_style_get_font_desc(long paramLong);
/*      */   
/* 6313 */   public static final long gtk_style_get_font_desc(long style) { lock.lock();
/*      */     try {
/* 6315 */       return _gtk_style_get_font_desc(style);
/*      */     } finally {
/* 6317 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_style_get_light(long paramLong, int paramInt, GdkColor paramGdkColor);
/*      */   
/*      */   public static final void gtk_style_get_light(long style, int index, GdkColor color)
/*      */   {
/* 6326 */     lock.lock();
/*      */     try {
/* 6328 */       _gtk_style_get_light(style, index, color);
/*      */     } finally {
/* 6330 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_style_get_text(long paramLong, int paramInt, GdkColor paramGdkColor);
/*      */   
/*      */   public static final void gtk_style_get_text(long style, int index, GdkColor color)
/*      */   {
/* 6339 */     lock.lock();
/*      */     try {
/* 6341 */       _gtk_style_get_text(style, index, color);
/*      */     } finally {
/* 6343 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native int _gtk_style_get_xthickness(long paramLong);
/*      */   
/* 6349 */   public static final int gtk_style_get_xthickness(long style) { lock.lock();
/*      */     try {
/* 6351 */       return _gtk_style_get_xthickness(style);
/*      */     } finally {
/* 6353 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native int _gtk_style_get_ythickness(long paramLong);
/*      */   
/* 6359 */   public static final int gtk_style_get_ythickness(long style) { lock.lock();
/*      */     try {
/* 6361 */       return _gtk_style_get_ythickness(style);
/*      */     } finally {
/* 6363 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native long _gtk_target_list_new(long paramLong, int paramInt);
/*      */   
/*      */   public static final long gtk_target_list_new(long targets, int ntargets)
/*      */   {
/* 6372 */     lock.lock();
/*      */     try {
/* 6374 */       return _gtk_target_list_new(targets, ntargets);
/*      */     } finally {
/* 6376 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_target_list_unref(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_target_list_unref(long list)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 513	org/eclipse/swt/internal/gtk/GTK:_gtk_target_list_unref	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #6382	-> byte code offset #0
/*      */     //   Java source line #6384	-> byte code offset #7
/*      */     //   Java source line #6386	-> byte code offset #11
/*      */     //   Java source line #6387	-> byte code offset #17
/*      */     //   Java source line #6386	-> byte code offset #20
/*      */     //   Java source line #6387	-> byte code offset #27
/*      */     //   Java source line #6388	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	list	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_text_buffer_copy_clipboard(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final void gtk_text_buffer_copy_clipboard(long buffer, long clipboard)
/*      */   {
/* 6395 */     lock.lock();
/*      */     try {
/* 6397 */       _gtk_text_buffer_copy_clipboard(buffer, clipboard);
/*      */     } finally {
/* 6399 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final native long _gtk_text_buffer_create_mark(long paramLong, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, boolean paramBoolean);
/*      */   
/*      */ 
/*      */   public static final long gtk_text_buffer_create_mark(long buffer, byte[] mark_name, byte[] where, boolean left_gravity)
/*      */   {
/* 6410 */     lock.lock();
/*      */     try {
/* 6412 */       return _gtk_text_buffer_create_mark(buffer, mark_name, where, left_gravity);
/*      */     } finally {
/* 6414 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_text_buffer_cut_clipboard(long paramLong1, long paramLong2, boolean paramBoolean);
/*      */   
/*      */ 
/*      */   public static final void gtk_text_buffer_cut_clipboard(long buffer, long clipboard, boolean default_editable)
/*      */   {
/* 6424 */     lock.lock();
/*      */     try {
/* 6426 */       _gtk_text_buffer_cut_clipboard(buffer, clipboard, default_editable);
/*      */     } finally {
/* 6428 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_text_buffer_delete(long paramLong, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2);
/*      */   
/*      */ 
/*      */   public static final void gtk_text_buffer_delete(long buffer, byte[] start, byte[] end)
/*      */   {
/* 6438 */     lock.lock();
/*      */     try {
/* 6440 */       _gtk_text_buffer_delete(buffer, start, end);
/*      */     } finally {
/* 6442 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_text_buffer_get_bounds(long paramLong, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2);
/*      */   
/*      */ 
/*      */   public static final void gtk_text_buffer_get_bounds(long buffer, byte[] start, byte[] end)
/*      */   {
/* 6452 */     lock.lock();
/*      */     try {
/* 6454 */       _gtk_text_buffer_get_bounds(buffer, start, end);
/*      */     } finally {
/* 6456 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_text_buffer_get_end_iter(long paramLong, byte[] paramArrayOfByte);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_text_buffer_get_end_iter(long buffer, byte[] iter)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: aload_2
/*      */     //   9: invokestatic 519	org/eclipse/swt/internal/gtk/GTK:_gtk_text_buffer_get_end_iter	(J[B)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #6465	-> byte code offset #0
/*      */     //   Java source line #6467	-> byte code offset #7
/*      */     //   Java source line #6469	-> byte code offset #12
/*      */     //   Java source line #6470	-> byte code offset #18
/*      */     //   Java source line #6469	-> byte code offset #21
/*      */     //   Java source line #6470	-> byte code offset #28
/*      */     //   Java source line #6471	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	buffer	long
/*      */     //   0	31	2	iter	byte[]
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native long _gtk_text_buffer_get_insert(long paramLong);
/*      */   
/*      */   public static final long gtk_text_buffer_get_insert(long buffer)
/*      */   {
/* 6475 */     lock.lock();
/*      */     try {
/* 6477 */       return _gtk_text_buffer_get_insert(buffer);
/*      */     } finally {
/* 6479 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_text_buffer_get_iter_at_line(long paramLong, byte[] paramArrayOfByte, int paramInt);
/*      */   
/*      */ 
/*      */   public static final void gtk_text_buffer_get_iter_at_line(long buffer, byte[] iter, int line_number)
/*      */   {
/* 6489 */     lock.lock();
/*      */     try {
/* 6491 */       _gtk_text_buffer_get_iter_at_line(buffer, iter, line_number);
/*      */     } finally {
/* 6493 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_text_buffer_get_iter_at_mark(long paramLong1, byte[] paramArrayOfByte, long paramLong2);
/*      */   
/*      */ 
/*      */   public static final void gtk_text_buffer_get_iter_at_mark(long buffer, byte[] iter, long mark)
/*      */   {
/* 6503 */     lock.lock();
/*      */     try {
/* 6505 */       _gtk_text_buffer_get_iter_at_mark(buffer, iter, mark);
/*      */     } finally {
/* 6507 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_text_buffer_get_iter_at_offset(long paramLong, byte[] paramArrayOfByte, int paramInt);
/*      */   
/*      */ 
/*      */   public static final void gtk_text_buffer_get_iter_at_offset(long buffer, byte[] iter, int char_offset)
/*      */   {
/* 6517 */     lock.lock();
/*      */     try {
/* 6519 */       _gtk_text_buffer_get_iter_at_offset(buffer, iter, char_offset);
/*      */     } finally {
/* 6521 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native int _gtk_text_buffer_get_line_count(long paramLong);
/*      */   
/* 6527 */   public static final int gtk_text_buffer_get_line_count(long buffer) { lock.lock();
/*      */     try {
/* 6529 */       return _gtk_text_buffer_get_line_count(buffer);
/*      */     } finally {
/* 6531 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gtk_text_buffer_get_selection_bound(long paramLong);
/*      */   
/* 6537 */   public static final long gtk_text_buffer_get_selection_bound(long buffer) { lock.lock();
/*      */     try {
/* 6539 */       return _gtk_text_buffer_get_selection_bound(buffer);
/*      */     } finally {
/* 6541 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native boolean _gtk_text_buffer_get_selection_bounds(long paramLong, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2);
/*      */   
/*      */ 
/*      */   public static final boolean gtk_text_buffer_get_selection_bounds(long buffer, byte[] start, byte[] end)
/*      */   {
/* 6551 */     lock.lock();
/*      */     try {
/* 6553 */       return _gtk_text_buffer_get_selection_bounds(buffer, start, end);
/*      */     } finally {
/* 6555 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final native long _gtk_text_buffer_get_text(long paramLong, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, boolean paramBoolean);
/*      */   
/*      */ 
/*      */   public static final long gtk_text_buffer_get_text(long buffer, byte[] start, byte[] end, boolean include_hidden_chars)
/*      */   {
/* 6566 */     lock.lock();
/*      */     try {
/* 6568 */       return _gtk_text_buffer_get_text(buffer, start, end, include_hidden_chars);
/*      */     } finally {
/* 6570 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final native void _gtk_text_buffer_insert(long paramLong, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, int paramInt);
/*      */   
/*      */ 
/*      */   public static final void gtk_text_buffer_insert(long buffer, byte[] iter, byte[] text, int len)
/*      */   {
/* 6581 */     lock.lock();
/*      */     try {
/* 6583 */       _gtk_text_buffer_insert(buffer, iter, text, len);
/*      */     } finally {
/* 6585 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final native void _gtk_text_buffer_insert(long paramLong1, long paramLong2, byte[] paramArrayOfByte, int paramInt);
/*      */   
/*      */ 
/*      */   public static final void gtk_text_buffer_insert(long buffer, long iter, byte[] text, int len)
/*      */   {
/* 6596 */     lock.lock();
/*      */     try {
/* 6598 */       _gtk_text_buffer_insert(buffer, iter, text, len);
/*      */     } finally {
/* 6600 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_text_buffer_select_range(long paramLong, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2);
/*      */   
/*      */ 
/*      */   public static final void gtk_text_buffer_select_range(long buffer, byte[] ins, byte[] bound)
/*      */   {
/* 6610 */     lock.lock();
/*      */     try {
/* 6612 */       _gtk_text_buffer_select_range(buffer, ins, bound);
/*      */     } finally {
/* 6614 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final native void _gtk_text_buffer_paste_clipboard(long paramLong1, long paramLong2, byte[] paramArrayOfByte, boolean paramBoolean);
/*      */   
/*      */ 
/*      */   public static final void gtk_text_buffer_paste_clipboard(long buffer, long clipboard, byte[] override_location, boolean default_editable)
/*      */   {
/* 6625 */     lock.lock();
/*      */     try {
/* 6627 */       _gtk_text_buffer_paste_clipboard(buffer, clipboard, override_location, default_editable);
/*      */     } finally {
/* 6629 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_text_buffer_place_cursor(long paramLong, byte[] paramArrayOfByte);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_text_buffer_place_cursor(long buffer, byte[] where)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: aload_2
/*      */     //   9: invokestatic 532	org/eclipse/swt/internal/gtk/GTK:_gtk_text_buffer_place_cursor	(J[B)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #6638	-> byte code offset #0
/*      */     //   Java source line #6640	-> byte code offset #7
/*      */     //   Java source line #6642	-> byte code offset #12
/*      */     //   Java source line #6643	-> byte code offset #18
/*      */     //   Java source line #6642	-> byte code offset #21
/*      */     //   Java source line #6643	-> byte code offset #28
/*      */     //   Java source line #6644	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	buffer	long
/*      */     //   0	31	2	where	byte[]
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_text_buffer_set_text(long paramLong, byte[] paramArrayOfByte, int paramInt);
/*      */   
/*      */   public static final void gtk_text_buffer_set_text(long buffer, byte[] text, int len)
/*      */   {
/* 6652 */     lock.lock();
/*      */     try {
/* 6654 */       _gtk_text_buffer_set_text(buffer, text, len);
/*      */     } finally {
/* 6656 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native int _gtk_text_iter_get_line(byte[] paramArrayOfByte);
/*      */   
/* 6662 */   public static final int gtk_text_iter_get_line(byte[] iter) { lock.lock();
/*      */     try {
/* 6664 */       return _gtk_text_iter_get_line(iter);
/*      */     } finally {
/* 6666 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native int _gtk_text_iter_get_offset(byte[] paramArrayOfByte);
/*      */   
/* 6672 */   public static final int gtk_text_iter_get_offset(byte[] iter) { lock.lock();
/*      */     try {
/* 6674 */       return _gtk_text_iter_get_offset(iter);
/*      */     } finally {
/* 6676 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final native void _gtk_text_view_buffer_to_window_coords(long paramLong, int paramInt1, int paramInt2, int paramInt3, int[] paramArrayOfInt1, int[] paramArrayOfInt2);
/*      */   
/*      */ 
/*      */ 
/*      */   public static final void gtk_text_view_buffer_to_window_coords(long text_view, int win, int buffer_x, int buffer_y, int[] window_x, int[] window_y)
/*      */   {
/* 6689 */     lock.lock();
/*      */     try {
/* 6691 */       _gtk_text_view_buffer_to_window_coords(text_view, win, buffer_x, buffer_y, window_x, window_y);
/*      */     } finally {
/* 6693 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gtk_text_view_get_buffer(long paramLong);
/*      */   
/* 6699 */   public static final long gtk_text_view_get_buffer(long text_view) { lock.lock();
/*      */     try {
/* 6701 */       return _gtk_text_view_get_buffer(text_view);
/*      */     } finally {
/* 6703 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native boolean _gtk_text_view_get_editable(long paramLong);
/*      */   
/* 6709 */   public static final boolean gtk_text_view_get_editable(long text_view) { lock.lock();
/*      */     try {
/* 6711 */       return _gtk_text_view_get_editable(text_view);
/*      */     } finally {
/* 6713 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final native void _gtk_text_view_get_iter_at_location(long paramLong, byte[] paramArrayOfByte, int paramInt1, int paramInt2);
/*      */   
/*      */ 
/*      */   public static final void gtk_text_view_get_iter_at_location(long text_view, byte[] iter, int x, int y)
/*      */   {
/* 6724 */     lock.lock();
/*      */     try {
/* 6726 */       _gtk_text_view_get_iter_at_location(text_view, iter, x, y);
/*      */     } finally {
/* 6728 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_text_view_get_iter_location(long paramLong, byte[] paramArrayOfByte, GdkRectangle paramGdkRectangle);
/*      */   
/*      */ 
/*      */   public static final void gtk_text_view_get_iter_location(long text_view, byte[] iter, GdkRectangle location)
/*      */   {
/* 6738 */     lock.lock();
/*      */     try {
/* 6740 */       _gtk_text_view_get_iter_location(text_view, iter, location);
/*      */     } finally {
/* 6742 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final native void _gtk_text_view_get_line_at_y(long paramLong, byte[] paramArrayOfByte, int paramInt, int[] paramArrayOfInt);
/*      */   
/*      */ 
/*      */   public static final void gtk_text_view_get_line_at_y(long text_view, byte[] target_iter, int y, int[] line_top)
/*      */   {
/* 6753 */     lock.lock();
/*      */     try {
/* 6755 */       _gtk_text_view_get_line_at_y(text_view, target_iter, y, line_top);
/*      */     } finally {
/* 6757 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final native void _gtk_text_view_get_line_yrange(long paramLong, byte[] paramArrayOfByte, int[] paramArrayOfInt1, int[] paramArrayOfInt2);
/*      */   
/*      */ 
/*      */   public static final void gtk_text_view_get_line_yrange(long text_view, byte[] target_iter, int[] y, int[] height)
/*      */   {
/* 6768 */     lock.lock();
/*      */     try {
/* 6770 */       _gtk_text_view_get_line_yrange(text_view, target_iter, y, height);
/*      */     } finally {
/* 6772 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_text_view_get_visible_rect(long paramLong, GdkRectangle paramGdkRectangle);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_text_view_get_visible_rect(long text_view, GdkRectangle visible_rect)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: aload_2
/*      */     //   9: invokestatic 543	org/eclipse/swt/internal/gtk/GTK:_gtk_text_view_get_visible_rect	(JLorg/eclipse/swt/internal/gtk/GdkRectangle;)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #6781	-> byte code offset #0
/*      */     //   Java source line #6783	-> byte code offset #7
/*      */     //   Java source line #6785	-> byte code offset #12
/*      */     //   Java source line #6786	-> byte code offset #18
/*      */     //   Java source line #6785	-> byte code offset #21
/*      */     //   Java source line #6786	-> byte code offset #28
/*      */     //   Java source line #6787	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	text_view	long
/*      */     //   0	31	2	visible_rect	GdkRectangle
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native long _gtk_text_view_get_window(long paramLong, int paramInt);
/*      */   
/*      */   public static final long gtk_text_view_get_window(long text_view, int win)
/*      */   {
/* 6794 */     lock.lock();
/*      */     try {
/* 6796 */       return _gtk_text_view_get_window(text_view, win);
/*      */     } finally {
/* 6798 */       lock.unlock();
/*      */     } }
/*      */   
/*      */   public static final native long _gtk_text_view_new();
/*      */   
/* 6803 */   public static final long gtk_text_view_new() { lock.lock();
/*      */     try {
/* 6805 */       return _gtk_text_view_new();
/*      */     } finally {
/* 6807 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final native void _gtk_text_view_scroll_to_mark(long paramLong1, long paramLong2, double paramDouble1, boolean paramBoolean, double paramDouble2, double paramDouble3);
/*      */   
/*      */ 
/*      */ 
/*      */   public static final void gtk_text_view_scroll_to_mark(long text_view, long mark, double within_margin, boolean use_align, double xalign, double yalign)
/*      */   {
/* 6820 */     lock.lock();
/*      */     try {
/* 6822 */       _gtk_text_view_scroll_to_mark(text_view, mark, within_margin, use_align, xalign, yalign);
/*      */     } finally {
/* 6824 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final native boolean _gtk_text_view_scroll_to_iter(long paramLong, byte[] paramArrayOfByte, double paramDouble1, boolean paramBoolean, double paramDouble2, double paramDouble3);
/*      */   
/*      */ 
/*      */ 
/*      */   public static final boolean gtk_text_view_scroll_to_iter(long text_view, byte[] iter, double within_margin, boolean use_align, double xalign, double yalign)
/*      */   {
/* 6837 */     lock.lock();
/*      */     try {
/* 6839 */       return _gtk_text_view_scroll_to_iter(text_view, iter, within_margin, use_align, xalign, yalign);
/*      */     } finally {
/* 6841 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_text_view_set_editable(long paramLong, boolean paramBoolean);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_text_view_set_editable(long text_view, boolean setting)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 548	org/eclipse/swt/internal/gtk/GTK:_gtk_text_view_set_editable	(JZ)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #6850	-> byte code offset #0
/*      */     //   Java source line #6852	-> byte code offset #7
/*      */     //   Java source line #6854	-> byte code offset #12
/*      */     //   Java source line #6855	-> byte code offset #18
/*      */     //   Java source line #6854	-> byte code offset #21
/*      */     //   Java source line #6855	-> byte code offset #28
/*      */     //   Java source line #6856	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	text_view	long
/*      */     //   0	31	2	setting	boolean
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_text_view_set_justification(long paramLong, int paramInt);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_text_view_set_justification(long text_view, int justification)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 549	org/eclipse/swt/internal/gtk/GTK:_gtk_text_view_set_justification	(JI)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #6860	-> byte code offset #0
/*      */     //   Java source line #6862	-> byte code offset #7
/*      */     //   Java source line #6864	-> byte code offset #12
/*      */     //   Java source line #6865	-> byte code offset #18
/*      */     //   Java source line #6864	-> byte code offset #21
/*      */     //   Java source line #6865	-> byte code offset #28
/*      */     //   Java source line #6866	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	text_view	long
/*      */     //   0	31	2	justification	int
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_text_view_set_tabs(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final void gtk_text_view_set_tabs(long text_view, long tabs)
/*      */   {
/* 6873 */     lock.lock();
/*      */     try {
/* 6875 */       _gtk_text_view_set_tabs(text_view, tabs);
/*      */     } finally {
/* 6877 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_text_view_set_wrap_mode(long paramLong, int paramInt);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_text_view_set_wrap_mode(long text_view, int wrap_mode)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 551	org/eclipse/swt/internal/gtk/GTK:_gtk_text_view_set_wrap_mode	(JI)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #6883	-> byte code offset #0
/*      */     //   Java source line #6885	-> byte code offset #7
/*      */     //   Java source line #6887	-> byte code offset #12
/*      */     //   Java source line #6888	-> byte code offset #18
/*      */     //   Java source line #6887	-> byte code offset #21
/*      */     //   Java source line #6888	-> byte code offset #28
/*      */     //   Java source line #6889	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	text_view	long
/*      */     //   0	31	2	wrap_mode	int
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native boolean _gtk_toggle_button_get_active(long paramLong);
/*      */   
/*      */   public static final boolean gtk_toggle_button_get_active(long toggle_button)
/*      */   {
/* 6893 */     lock.lock();
/*      */     try {
/* 6895 */       return _gtk_toggle_button_get_active(toggle_button);
/*      */     } finally {
/* 6897 */       lock.unlock();
/*      */     } }
/*      */   
/*      */   public static final native long _gtk_toggle_button_new();
/*      */   
/* 6902 */   public static final long gtk_toggle_button_new() { lock.lock();
/*      */     try {
/* 6904 */       return _gtk_toggle_button_new();
/*      */     } finally {
/* 6906 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_toggle_button_set_active(long paramLong, boolean paramBoolean);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_toggle_button_set_active(long toggle_button, boolean is_active)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 554	org/eclipse/swt/internal/gtk/GTK:_gtk_toggle_button_set_active	(JZ)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #6915	-> byte code offset #0
/*      */     //   Java source line #6917	-> byte code offset #7
/*      */     //   Java source line #6919	-> byte code offset #12
/*      */     //   Java source line #6920	-> byte code offset #18
/*      */     //   Java source line #6919	-> byte code offset #21
/*      */     //   Java source line #6920	-> byte code offset #28
/*      */     //   Java source line #6921	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	toggle_button	long
/*      */     //   0	31	2	is_active	boolean
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_toggle_button_set_inconsistent(long paramLong, boolean paramBoolean);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_toggle_button_set_inconsistent(long toggle_button, boolean setting)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 555	org/eclipse/swt/internal/gtk/GTK:_gtk_toggle_button_set_inconsistent	(JZ)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #6928	-> byte code offset #0
/*      */     //   Java source line #6930	-> byte code offset #7
/*      */     //   Java source line #6932	-> byte code offset #12
/*      */     //   Java source line #6933	-> byte code offset #18
/*      */     //   Java source line #6932	-> byte code offset #21
/*      */     //   Java source line #6933	-> byte code offset #28
/*      */     //   Java source line #6934	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	toggle_button	long
/*      */     //   0	31	2	setting	boolean
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_toggle_button_set_mode(long paramLong, boolean paramBoolean);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_toggle_button_set_mode(long toggle_button, boolean draw_indicator)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 556	org/eclipse/swt/internal/gtk/GTK:_gtk_toggle_button_set_mode	(JZ)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #6941	-> byte code offset #0
/*      */     //   Java source line #6943	-> byte code offset #7
/*      */     //   Java source line #6945	-> byte code offset #12
/*      */     //   Java source line #6946	-> byte code offset #18
/*      */     //   Java source line #6945	-> byte code offset #21
/*      */     //   Java source line #6946	-> byte code offset #28
/*      */     //   Java source line #6947	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	toggle_button	long
/*      */     //   0	31	2	draw_indicator	boolean
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native boolean _gtk_toggle_tool_button_get_active(long paramLong);
/*      */   
/*      */   public static final boolean gtk_toggle_tool_button_get_active(long button)
/*      */   {
/* 6951 */     lock.lock();
/*      */     try {
/* 6953 */       return _gtk_toggle_tool_button_get_active(button);
/*      */     } finally {
/* 6955 */       lock.unlock();
/*      */     } }
/*      */   
/*      */   public static final native long _gtk_toggle_tool_button_new();
/*      */   
/* 6960 */   public static final long gtk_toggle_tool_button_new() { lock.lock();
/*      */     try {
/* 6962 */       return _gtk_toggle_tool_button_new();
/*      */     } finally {
/* 6964 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_toggle_tool_button_set_active(long paramLong, boolean paramBoolean);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_toggle_tool_button_set_active(long item, boolean selected)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 559	org/eclipse/swt/internal/gtk/GTK:_gtk_toggle_tool_button_set_active	(JZ)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #6973	-> byte code offset #0
/*      */     //   Java source line #6975	-> byte code offset #7
/*      */     //   Java source line #6977	-> byte code offset #12
/*      */     //   Java source line #6978	-> byte code offset #18
/*      */     //   Java source line #6977	-> byte code offset #21
/*      */     //   Java source line #6978	-> byte code offset #28
/*      */     //   Java source line #6979	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	item	long
/*      */     //   0	31	2	selected	boolean
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native long _gtk_tool_button_new(long paramLong, byte[] paramArrayOfByte);
/*      */   
/*      */   public static final long gtk_tool_button_new(long icon_widget, byte[] label)
/*      */   {
/* 6986 */     lock.lock();
/*      */     try {
/* 6988 */       return _gtk_tool_button_new(icon_widget, label);
/*      */     } finally {
/* 6990 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_tool_button_set_icon_widget(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final void gtk_tool_button_set_icon_widget(long button, long widget)
/*      */   {
/* 6999 */     lock.lock();
/*      */     try {
/* 7001 */       _gtk_tool_button_set_icon_widget(button, widget);
/*      */     } finally {
/* 7003 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_tool_button_set_label(long paramLong, byte[] paramArrayOfByte);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_tool_button_set_label(long button, byte[] label)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: aload_2
/*      */     //   9: invokestatic 562	org/eclipse/swt/internal/gtk/GTK:_gtk_tool_button_set_label	(J[B)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #7012	-> byte code offset #0
/*      */     //   Java source line #7014	-> byte code offset #7
/*      */     //   Java source line #7016	-> byte code offset #12
/*      */     //   Java source line #7017	-> byte code offset #18
/*      */     //   Java source line #7016	-> byte code offset #21
/*      */     //   Java source line #7017	-> byte code offset #28
/*      */     //   Java source line #7018	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	button	long
/*      */     //   0	31	2	label	byte[]
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_tool_button_set_label_widget(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final void gtk_tool_button_set_label_widget(long button, long widget)
/*      */   {
/* 7025 */     lock.lock();
/*      */     try {
/* 7027 */       _gtk_tool_button_set_label_widget(button, widget);
/*      */     } finally {
/* 7029 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_tool_button_set_use_underline(long paramLong, boolean paramBoolean);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_tool_button_set_use_underline(long item, boolean underline)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 564	org/eclipse/swt/internal/gtk/GTK:_gtk_tool_button_set_use_underline	(JZ)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #7038	-> byte code offset #0
/*      */     //   Java source line #7040	-> byte code offset #7
/*      */     //   Java source line #7042	-> byte code offset #12
/*      */     //   Java source line #7043	-> byte code offset #18
/*      */     //   Java source line #7042	-> byte code offset #21
/*      */     //   Java source line #7043	-> byte code offset #28
/*      */     //   Java source line #7044	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	item	long
/*      */     //   0	31	2	underline	boolean
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native long _gtk_tool_item_get_proxy_menu_item(long paramLong, byte[] paramArrayOfByte);
/*      */   
/*      */   public static final long gtk_tool_item_get_proxy_menu_item(long item, byte[] menu_id)
/*      */   {
/* 7051 */     lock.lock();
/*      */     try {
/* 7053 */       return _gtk_tool_item_get_proxy_menu_item(item, menu_id);
/*      */     } finally {
/* 7055 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gtk_tool_item_retrieve_proxy_menu_item(long paramLong);
/*      */   
/* 7061 */   public static final long gtk_tool_item_retrieve_proxy_menu_item(long item) { lock.lock();
/*      */     try {
/* 7063 */       return _gtk_tool_item_retrieve_proxy_menu_item(item);
/*      */     } finally {
/* 7065 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_tool_item_set_is_important(long paramLong, boolean paramBoolean);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_tool_item_set_is_important(long item, boolean important)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 567	org/eclipse/swt/internal/gtk/GTK:_gtk_tool_item_set_is_important	(JZ)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #7074	-> byte code offset #0
/*      */     //   Java source line #7076	-> byte code offset #7
/*      */     //   Java source line #7078	-> byte code offset #12
/*      */     //   Java source line #7079	-> byte code offset #18
/*      */     //   Java source line #7078	-> byte code offset #21
/*      */     //   Java source line #7079	-> byte code offset #28
/*      */     //   Java source line #7080	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	item	long
/*      */     //   0	31	2	important	boolean
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_tool_item_set_proxy_menu_item(long paramLong1, byte[] paramArrayOfByte, long paramLong2);
/*      */   
/*      */   public static final void gtk_tool_item_set_proxy_menu_item(long item, byte[] menu_id, long widget)
/*      */   {
/* 7088 */     lock.lock();
/*      */     try {
/* 7090 */       _gtk_tool_item_set_proxy_menu_item(item, menu_id, widget);
/*      */     } finally {
/* 7092 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_toolbar_insert(long paramLong1, long paramLong2, int paramInt);
/*      */   
/*      */   public static final void gtk_toolbar_insert(long toolbar, long item, int pos)
/*      */   {
/* 7101 */     lock.lock();
/*      */     try {
/* 7103 */       _gtk_toolbar_insert(toolbar, item, pos);
/*      */     } finally {
/* 7105 */       lock.unlock();
/*      */     } }
/*      */   
/*      */   public static final native long _gtk_toolbar_new();
/*      */   
/* 7110 */   public static final long gtk_toolbar_new() { lock.lock();
/*      */     try {
/* 7112 */       return _gtk_toolbar_new();
/*      */     } finally {
/* 7114 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_toolbar_set_show_arrow(long paramLong, boolean paramBoolean);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_toolbar_set_show_arrow(long toolbar, boolean show_arrow)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 571	org/eclipse/swt/internal/gtk/GTK:_gtk_toolbar_set_show_arrow	(JZ)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #7123	-> byte code offset #0
/*      */     //   Java source line #7125	-> byte code offset #7
/*      */     //   Java source line #7127	-> byte code offset #12
/*      */     //   Java source line #7128	-> byte code offset #18
/*      */     //   Java source line #7127	-> byte code offset #21
/*      */     //   Java source line #7128	-> byte code offset #28
/*      */     //   Java source line #7129	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	toolbar	long
/*      */     //   0	31	2	show_arrow	boolean
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_toolbar_set_style(long paramLong, int paramInt);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_toolbar_set_style(long toolbar, int style)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 572	org/eclipse/swt/internal/gtk/GTK:_gtk_toolbar_set_style	(JI)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #7135	-> byte code offset #0
/*      */     //   Java source line #7137	-> byte code offset #7
/*      */     //   Java source line #7139	-> byte code offset #12
/*      */     //   Java source line #7140	-> byte code offset #18
/*      */     //   Java source line #7139	-> byte code offset #21
/*      */     //   Java source line #7140	-> byte code offset #28
/*      */     //   Java source line #7141	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	toolbar	long
/*      */     //   0	31	2	style	int
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_toolbar_set_icon_size(long paramLong, int paramInt);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_toolbar_set_icon_size(long toolbar, int size)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 573	org/eclipse/swt/internal/gtk/GTK:_gtk_toolbar_set_icon_size	(JI)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #7146	-> byte code offset #0
/*      */     //   Java source line #7148	-> byte code offset #7
/*      */     //   Java source line #7150	-> byte code offset #12
/*      */     //   Java source line #7151	-> byte code offset #18
/*      */     //   Java source line #7150	-> byte code offset #21
/*      */     //   Java source line #7151	-> byte code offset #28
/*      */     //   Java source line #7152	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	toolbar	long
/*      */     //   0	31	2	size	int
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_tree_model_get(long paramLong1, long paramLong2, int paramInt1, long[] paramArrayOfLong, int paramInt2);
/*      */   
/*      */   public static final void gtk_tree_model_get(long tree_model, long iter, int column, long[] value, int terminator)
/*      */   {
/* 7159 */     lock.lock();
/*      */     try {
/* 7161 */       _gtk_tree_model_get(tree_model, iter, column, value, terminator);
/*      */     } finally {
/* 7163 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_tree_model_get(long paramLong1, long paramLong2, int paramInt1, int[] paramArrayOfInt, int paramInt2);
/*      */   
/*      */   public static final void gtk_tree_model_get(long tree_model, long iter, int column, int[] value, int terminator)
/*      */   {
/* 7172 */     lock.lock();
/*      */     try {
/* 7174 */       _gtk_tree_model_get(tree_model, iter, column, value, terminator);
/*      */     } finally {
/* 7176 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native boolean _gtk_tree_model_get_iter(long paramLong1, long paramLong2, long paramLong3);
/*      */   
/*      */ 
/*      */   public static final boolean gtk_tree_model_get_iter(long tree_model, long iter, long path)
/*      */   {
/* 7186 */     lock.lock();
/*      */     try {
/* 7188 */       return _gtk_tree_model_get_iter(tree_model, iter, path);
/*      */     } finally {
/* 7190 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native boolean _gtk_tree_model_get_iter_first(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final boolean gtk_tree_model_get_iter_first(long tree_model, long iter)
/*      */   {
/* 7199 */     lock.lock();
/*      */     try {
/* 7201 */       return _gtk_tree_model_get_iter_first(tree_model, iter);
/*      */     } finally {
/* 7203 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native int _gtk_tree_model_get_n_columns(long paramLong);
/*      */   
/* 7209 */   public static final int gtk_tree_model_get_n_columns(long tree_model) { lock.lock();
/*      */     try {
/* 7211 */       return _gtk_tree_model_get_n_columns(tree_model);
/*      */     } finally {
/* 7213 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native long _gtk_tree_model_get_path(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final long gtk_tree_model_get_path(long tree_model, long iter)
/*      */   {
/* 7222 */     lock.lock();
/*      */     try {
/* 7224 */       return _gtk_tree_model_get_path(tree_model, iter);
/*      */     } finally {
/* 7226 */       lock.unlock();
/*      */     } }
/*      */   
/*      */   public static final native long _gtk_tree_model_get_type();
/*      */   
/* 7231 */   public static final long gtk_tree_model_get_type() { lock.lock();
/*      */     try {
/* 7233 */       return _gtk_tree_model_get_type();
/*      */     } finally {
/* 7235 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native boolean _gtk_tree_model_iter_children(long paramLong1, long paramLong2, long paramLong3);
/*      */   
/*      */ 
/*      */   public static final boolean gtk_tree_model_iter_children(long model, long iter, long parent)
/*      */   {
/* 7245 */     lock.lock();
/*      */     try {
/* 7247 */       return _gtk_tree_model_iter_children(model, iter, parent);
/*      */     } finally {
/* 7249 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native int _gtk_tree_model_iter_n_children(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final int gtk_tree_model_iter_n_children(long model, long iter)
/*      */   {
/* 7258 */     lock.lock();
/*      */     try {
/* 7260 */       return _gtk_tree_model_iter_n_children(model, iter);
/*      */     } finally {
/* 7262 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native boolean _gtk_tree_model_iter_next(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final boolean gtk_tree_model_iter_next(long model, long iter)
/*      */   {
/* 7271 */     lock.lock();
/*      */     try {
/* 7273 */       return _gtk_tree_model_iter_next(model, iter);
/*      */     } finally {
/* 7275 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native boolean _gtk_tree_model_iter_nth_child(long paramLong1, long paramLong2, long paramLong3, int paramInt);
/*      */   
/*      */ 
/*      */   public static final boolean gtk_tree_model_iter_nth_child(long tree_model, long iter, long parent, int n)
/*      */   {
/* 7285 */     lock.lock();
/*      */     try {
/* 7287 */       return _gtk_tree_model_iter_nth_child(tree_model, iter, parent, n);
/*      */     } finally {
/* 7289 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_tree_path_append_index(long paramLong, int paramInt);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_tree_path_append_index(long path, int index)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 585	org/eclipse/swt/internal/gtk/GTK:_gtk_tree_path_append_index	(JI)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #7295	-> byte code offset #0
/*      */     //   Java source line #7297	-> byte code offset #7
/*      */     //   Java source line #7299	-> byte code offset #12
/*      */     //   Java source line #7300	-> byte code offset #18
/*      */     //   Java source line #7299	-> byte code offset #21
/*      */     //   Java source line #7300	-> byte code offset #28
/*      */     //   Java source line #7301	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	path	long
/*      */     //   0	31	2	index	int
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native long _gtk_tree_path_compare(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final long gtk_tree_path_compare(long a, long b)
/*      */   {
/* 7308 */     lock.lock();
/*      */     try {
/* 7310 */       return _gtk_tree_path_compare(a, b);
/*      */     } finally {
/* 7312 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_tree_path_free(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_tree_path_free(long path)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 587	org/eclipse/swt/internal/gtk/GTK:_gtk_tree_path_free	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #7318	-> byte code offset #0
/*      */     //   Java source line #7320	-> byte code offset #7
/*      */     //   Java source line #7322	-> byte code offset #11
/*      */     //   Java source line #7323	-> byte code offset #17
/*      */     //   Java source line #7322	-> byte code offset #20
/*      */     //   Java source line #7323	-> byte code offset #27
/*      */     //   Java source line #7324	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	path	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native int _gtk_tree_path_get_depth(long paramLong);
/*      */   
/*      */   public static final int gtk_tree_path_get_depth(long path)
/*      */   {
/* 7328 */     lock.lock();
/*      */     try {
/* 7330 */       return _gtk_tree_path_get_depth(path);
/*      */     } finally {
/* 7332 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gtk_tree_path_get_indices(long paramLong);
/*      */   
/* 7338 */   public static final long gtk_tree_path_get_indices(long path) { lock.lock();
/*      */     try {
/* 7340 */       return _gtk_tree_path_get_indices(path);
/*      */     } finally {
/* 7342 */       lock.unlock();
/*      */     } }
/*      */   
/*      */   public static final native long _gtk_tree_path_new();
/*      */   
/* 7347 */   public static final long gtk_tree_path_new() { lock.lock();
/*      */     try {
/* 7349 */       return _gtk_tree_path_new();
/*      */     } finally {
/* 7351 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gtk_tree_path_new_from_string(byte[] paramArrayOfByte);
/*      */   
/* 7357 */   public static final long gtk_tree_path_new_from_string(byte[] path) { lock.lock();
/*      */     try {
/* 7359 */       return _gtk_tree_path_new_from_string(path);
/*      */     } finally {
/* 7361 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gtk_tree_path_new_from_string(long paramLong);
/*      */   
/* 7367 */   public static final long gtk_tree_path_new_from_string(long path) { lock.lock();
/*      */     try {
/* 7369 */       return _gtk_tree_path_new_from_string(path);
/*      */     } finally {
/* 7371 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_tree_path_next(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_tree_path_next(long path)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 593	org/eclipse/swt/internal/gtk/GTK:_gtk_tree_path_next	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #7377	-> byte code offset #0
/*      */     //   Java source line #7379	-> byte code offset #7
/*      */     //   Java source line #7381	-> byte code offset #11
/*      */     //   Java source line #7382	-> byte code offset #17
/*      */     //   Java source line #7381	-> byte code offset #20
/*      */     //   Java source line #7382	-> byte code offset #27
/*      */     //   Java source line #7383	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	path	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native boolean _gtk_tree_path_prev(long paramLong);
/*      */   
/*      */   public static final boolean gtk_tree_path_prev(long path)
/*      */   {
/* 7387 */     lock.lock();
/*      */     try {
/* 7389 */       return _gtk_tree_path_prev(path);
/*      */     } finally {
/* 7391 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native boolean _gtk_tree_path_up(long paramLong);
/*      */   
/* 7397 */   public static final boolean gtk_tree_path_up(long path) { lock.lock();
/*      */     try {
/* 7399 */       return _gtk_tree_path_up(path);
/*      */     } finally {
/* 7401 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native int _gtk_tree_selection_count_selected_rows(long paramLong);
/*      */   
/*      */   public static final int gtk_tree_selection_count_selected_rows(long selection)
/*      */   {
/* 7409 */     lock.lock();
/*      */     try {
/* 7411 */       return _gtk_tree_selection_count_selected_rows(selection);
/*      */     } finally {
/* 7413 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native long _gtk_tree_selection_get_selected_rows(long paramLong, long[] paramArrayOfLong);
/*      */   
/*      */   public static final long gtk_tree_selection_get_selected_rows(long selection, long[] model)
/*      */   {
/* 7422 */     lock.lock();
/*      */     try {
/* 7424 */       return _gtk_tree_selection_get_selected_rows(selection, model);
/*      */     } finally {
/* 7426 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native boolean _gtk_tree_selection_path_is_selected(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final boolean gtk_tree_selection_path_is_selected(long selection, long path)
/*      */   {
/* 7435 */     lock.lock();
/*      */     try {
/* 7437 */       return _gtk_tree_selection_path_is_selected(selection, path);
/*      */     } finally {
/* 7439 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_tree_selection_select_all(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_tree_selection_select_all(long selection)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 599	org/eclipse/swt/internal/gtk/GTK:_gtk_tree_selection_select_all	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #7445	-> byte code offset #0
/*      */     //   Java source line #7447	-> byte code offset #7
/*      */     //   Java source line #7449	-> byte code offset #11
/*      */     //   Java source line #7450	-> byte code offset #17
/*      */     //   Java source line #7449	-> byte code offset #20
/*      */     //   Java source line #7450	-> byte code offset #27
/*      */     //   Java source line #7451	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	selection	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_tree_selection_select_iter(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final void gtk_tree_selection_select_iter(long selection, long iter)
/*      */   {
/* 7458 */     lock.lock();
/*      */     try {
/* 7460 */       _gtk_tree_selection_select_iter(selection, iter);
/*      */     } finally {
/* 7462 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gtk_tree_selection_get_select_function(long paramLong);
/*      */   
/*      */   public static final long gtk_tree_selection_get_select_function(long selection)
/*      */   {
/* 7470 */     lock.lock();
/*      */     try {
/* 7472 */       return _gtk_tree_selection_get_select_function(selection);
/*      */     } finally {
/* 7474 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final native void _gtk_tree_selection_set_select_function(long paramLong1, long paramLong2, long paramLong3, long paramLong4);
/*      */   
/*      */ 
/*      */   public static final void gtk_tree_selection_set_select_function(long selection, long func, long data, long destroy)
/*      */   {
/* 7485 */     lock.lock();
/*      */     try {
/* 7487 */       _gtk_tree_selection_set_select_function(selection, func, data, destroy);
/*      */     } finally {
/* 7489 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_tree_selection_select_path(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final void gtk_tree_selection_select_path(long selection, long path)
/*      */   {
/* 7498 */     lock.lock();
/*      */     try {
/* 7500 */       _gtk_tree_selection_select_path(selection, path);
/*      */     } finally {
/* 7502 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_tree_selection_set_mode(long paramLong, int paramInt);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_tree_selection_set_mode(long selection, int mode)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 604	org/eclipse/swt/internal/gtk/GTK:_gtk_tree_selection_set_mode	(JI)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #7511	-> byte code offset #0
/*      */     //   Java source line #7513	-> byte code offset #7
/*      */     //   Java source line #7515	-> byte code offset #12
/*      */     //   Java source line #7516	-> byte code offset #18
/*      */     //   Java source line #7515	-> byte code offset #21
/*      */     //   Java source line #7516	-> byte code offset #28
/*      */     //   Java source line #7517	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	selection	long
/*      */     //   0	31	2	mode	int
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_tree_selection_unselect_path(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final void gtk_tree_selection_unselect_path(long selection, long path)
/*      */   {
/* 7524 */     lock.lock();
/*      */     try {
/* 7526 */       _gtk_tree_selection_unselect_path(selection, path);
/*      */     } finally {
/* 7528 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_tree_selection_unselect_all(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_tree_selection_unselect_all(long selection)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 606	org/eclipse/swt/internal/gtk/GTK:_gtk_tree_selection_unselect_all	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #7534	-> byte code offset #0
/*      */     //   Java source line #7536	-> byte code offset #7
/*      */     //   Java source line #7538	-> byte code offset #11
/*      */     //   Java source line #7539	-> byte code offset #17
/*      */     //   Java source line #7538	-> byte code offset #20
/*      */     //   Java source line #7539	-> byte code offset #27
/*      */     //   Java source line #7540	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	selection	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_tree_selection_unselect_iter(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final void gtk_tree_selection_unselect_iter(long selection, long iter)
/*      */   {
/* 7547 */     lock.lock();
/*      */     try {
/* 7549 */       _gtk_tree_selection_unselect_iter(selection, iter);
/*      */     } finally {
/* 7551 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_tree_store_append(long paramLong1, long paramLong2, long paramLong3);
/*      */   
/*      */ 
/*      */   public static final void gtk_tree_store_append(long store, long iter, long parent)
/*      */   {
/* 7561 */     lock.lock();
/*      */     try {
/* 7563 */       _gtk_tree_store_append(store, iter, parent);
/*      */     } finally {
/* 7565 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_tree_store_clear(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_tree_store_clear(long store)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 609	org/eclipse/swt/internal/gtk/GTK:_gtk_tree_store_clear	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #7571	-> byte code offset #0
/*      */     //   Java source line #7573	-> byte code offset #7
/*      */     //   Java source line #7575	-> byte code offset #11
/*      */     //   Java source line #7576	-> byte code offset #17
/*      */     //   Java source line #7575	-> byte code offset #20
/*      */     //   Java source line #7576	-> byte code offset #27
/*      */     //   Java source line #7577	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	store	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_tree_store_insert(long paramLong1, long paramLong2, long paramLong3, int paramInt);
/*      */   
/*      */   public static final void gtk_tree_store_insert(long store, long iter, long parent, int position)
/*      */   {
/* 7586 */     lock.lock();
/*      */     try {
/* 7588 */       _gtk_tree_store_insert(store, iter, parent, position);
/*      */     } finally {
/* 7590 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gtk_tree_store_newv(int paramInt, long[] paramArrayOfLong);
/*      */   
/* 7596 */   public static final long gtk_tree_store_newv(int numColumns, long[] types) { lock.lock();
/*      */     try {
/* 7598 */       return _gtk_tree_store_newv(numColumns, types);
/*      */     } finally {
/* 7600 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_tree_store_remove(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final void gtk_tree_store_remove(long store, long iter)
/*      */   {
/* 7609 */     lock.lock();
/*      */     try {
/* 7611 */       _gtk_tree_store_remove(store, iter);
/*      */     } finally {
/* 7613 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_tree_store_set(long paramLong1, long paramLong2, int paramInt1, byte[] paramArrayOfByte, int paramInt2);
/*      */   
/*      */   public static final void gtk_tree_store_set(long store, long iter, int column, byte[] value, int terminator)
/*      */   {
/* 7622 */     lock.lock();
/*      */     try {
/* 7624 */       _gtk_tree_store_set(store, iter, column, value, terminator);
/*      */     } finally {
/* 7626 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_tree_store_set(long paramLong1, long paramLong2, int paramInt1, int paramInt2, int paramInt3);
/*      */   
/*      */   public static final void gtk_tree_store_set(long store, long iter, int column, int value, int terminator)
/*      */   {
/* 7635 */     lock.lock();
/*      */     try {
/* 7637 */       _gtk_tree_store_set(store, iter, column, value, terminator);
/*      */     } finally {
/* 7639 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_tree_store_set(long paramLong1, long paramLong2, int paramInt1, long paramLong3, int paramInt2);
/*      */   
/*      */   public static final void gtk_tree_store_set(long store, long iter, int column, long value, int terminator)
/*      */   {
/* 7648 */     lock.lock();
/*      */     try {
/* 7650 */       _gtk_tree_store_set(store, iter, column, value, terminator);
/*      */     } finally {
/* 7652 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_tree_store_set(long paramLong1, long paramLong2, int paramInt1, GdkColor paramGdkColor, int paramInt2);
/*      */   
/*      */ 
/*      */   public static final void gtk_tree_store_set(long store, long iter, int column, GdkColor value, int terminator)
/*      */   {
/* 7662 */     lock.lock();
/* 7663 */     assert (!GTK3) : "GTK2 code was run by GTK3";
/*      */     try {
/* 7665 */       _gtk_tree_store_set(store, iter, column, value, terminator);
/*      */     } finally {
/* 7667 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_tree_store_set(long paramLong1, long paramLong2, int paramInt1, GdkRGBA paramGdkRGBA, int paramInt2);
/*      */   
/*      */ 
/*      */   public static final void gtk_tree_store_set(long store, long iter, int column, GdkRGBA value, int terminator)
/*      */   {
/* 7677 */     lock.lock();
/* 7678 */     assert (GTK3) : "GTK3 code was run by GTK2";
/*      */     try {
/* 7680 */       _gtk_tree_store_set(store, iter, column, value, terminator);
/*      */     } finally {
/* 7682 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_tree_store_set(long paramLong1, long paramLong2, int paramInt1, boolean paramBoolean, int paramInt2);
/*      */   
/*      */   public static final void gtk_tree_store_set(long store, long iter, int column, boolean value, int terminator)
/*      */   {
/* 7691 */     lock.lock();
/*      */     try {
/* 7693 */       _gtk_tree_store_set(store, iter, column, value, terminator);
/*      */     } finally {
/* 7695 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native long _gtk_tree_view_create_row_drag_icon(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final long gtk_tree_view_create_row_drag_icon(long view, long path)
/*      */   {
/* 7704 */     lock.lock();
/*      */     try {
/* 7706 */       return _gtk_tree_view_create_row_drag_icon(view, path);
/*      */     } finally {
/* 7708 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native boolean _gtk_tree_view_collapse_row(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final boolean gtk_tree_view_collapse_row(long view, long path)
/*      */   {
/* 7717 */     lock.lock();
/*      */     try {
/* 7719 */       return _gtk_tree_view_collapse_row(view, path);
/*      */     } finally {
/* 7721 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final native void _gtk_tree_view_column_add_attribute(long paramLong1, long paramLong2, byte[] paramArrayOfByte, int paramInt);
/*      */   
/*      */ 
/*      */   public static final void gtk_tree_view_column_add_attribute(long treeColumn, long cellRenderer, byte[] attribute, int column)
/*      */   {
/* 7732 */     lock.lock();
/*      */     try {
/* 7734 */       _gtk_tree_view_column_add_attribute(treeColumn, cellRenderer, attribute, column);
/*      */     } finally {
/* 7736 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final native boolean _gtk_tree_view_column_cell_get_position(long paramLong1, long paramLong2, int[] paramArrayOfInt1, int[] paramArrayOfInt2);
/*      */   
/*      */ 
/*      */   public static final boolean gtk_tree_view_column_cell_get_position(long tree_column, long cell_renderer, int[] start_pos, int[] width)
/*      */   {
/* 7747 */     lock.lock();
/*      */     try {
/* 7749 */       return _gtk_tree_view_column_cell_get_position(tree_column, cell_renderer, start_pos, width);
/*      */     } finally {
/* 7751 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final native void _gtk_tree_view_column_cell_get_size(long paramLong, GdkRectangle paramGdkRectangle, int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3, int[] paramArrayOfInt4);
/*      */   
/*      */ 
/*      */ 
/*      */   public static final void gtk_tree_view_column_cell_get_size(long tree_column, GdkRectangle cell_area, int[] x_offset, int[] y_offset, int[] width, int[] height)
/*      */   {
/* 7764 */     lock.lock();
/*      */     try {
/* 7766 */       _gtk_tree_view_column_cell_get_size(tree_column, cell_area, x_offset, y_offset, width, height);
/*      */     } finally {
/* 7768 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_tree_view_column_cell_set_cell_data(long paramLong1, long paramLong2, long paramLong3, boolean paramBoolean1, boolean paramBoolean2);
/*      */   
/*      */ 
/*      */   public static final void gtk_tree_view_column_cell_set_cell_data(long tree_column, long tree_model, long iter, boolean is_expander, boolean is_expanded)
/*      */   {
/* 7778 */     lock.lock();
/*      */     try {
/* 7780 */       _gtk_tree_view_column_cell_set_cell_data(tree_column, tree_model, iter, is_expander, is_expanded);
/*      */     } finally {
/* 7782 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_tree_view_column_clear(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_tree_view_column_clear(long tree_column)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 625	org/eclipse/swt/internal/gtk/GTK:_gtk_tree_view_column_clear	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #7788	-> byte code offset #0
/*      */     //   Java source line #7790	-> byte code offset #7
/*      */     //   Java source line #7792	-> byte code offset #11
/*      */     //   Java source line #7793	-> byte code offset #17
/*      */     //   Java source line #7792	-> byte code offset #20
/*      */     //   Java source line #7793	-> byte code offset #27
/*      */     //   Java source line #7794	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	tree_column	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native long _gtk_tree_view_column_get_button(long paramLong);
/*      */   
/*      */   public static final long gtk_tree_view_column_get_button(long column)
/*      */   {
/* 7801 */     lock.lock();
/*      */     try {
/* 7803 */       return _gtk_tree_view_column_get_button(column);
/*      */     } finally {
/* 7805 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native int _gtk_tree_view_column_get_fixed_width(long paramLong);
/*      */   
/* 7811 */   public static final int gtk_tree_view_column_get_fixed_width(long column) { lock.lock();
/*      */     try {
/* 7813 */       return _gtk_tree_view_column_get_fixed_width(column);
/*      */     } finally {
/* 7815 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native boolean _gtk_tree_view_column_get_reorderable(long paramLong);
/*      */   
/* 7821 */   public static final boolean gtk_tree_view_column_get_reorderable(long column) { lock.lock();
/*      */     try {
/* 7823 */       return _gtk_tree_view_column_get_reorderable(column);
/*      */     } finally {
/* 7825 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native boolean _gtk_tree_view_column_get_resizable(long paramLong);
/*      */   
/* 7831 */   public static final boolean gtk_tree_view_column_get_resizable(long column) { lock.lock();
/*      */     try {
/* 7833 */       return _gtk_tree_view_column_get_resizable(column);
/*      */     } finally {
/* 7835 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native boolean _gtk_tree_view_column_get_visible(long paramLong);
/*      */   
/* 7841 */   public static final boolean gtk_tree_view_column_get_visible(long column) { lock.lock();
/*      */     try {
/* 7843 */       return _gtk_tree_view_column_get_visible(column);
/*      */     } finally {
/* 7845 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native int _gtk_tree_view_column_get_width(long paramLong);
/*      */   
/* 7851 */   public static final int gtk_tree_view_column_get_width(long column) { lock.lock();
/*      */     try {
/* 7853 */       return _gtk_tree_view_column_get_width(column);
/*      */     } finally {
/* 7855 */       lock.unlock();
/*      */     } }
/*      */   
/*      */   public static final native long _gtk_tree_view_column_new();
/*      */   
/* 7860 */   public static final long gtk_tree_view_column_new() { lock.lock();
/*      */     try {
/* 7862 */       return _gtk_tree_view_column_new();
/*      */     } finally {
/* 7864 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_tree_view_column_pack_start(long paramLong1, long paramLong2, boolean paramBoolean);
/*      */   
/*      */ 
/*      */   public static final void gtk_tree_view_column_pack_start(long tree_column, long cell_renderer, boolean expand)
/*      */   {
/* 7874 */     lock.lock();
/*      */     try {
/* 7876 */       _gtk_tree_view_column_pack_start(tree_column, cell_renderer, expand);
/*      */     } finally {
/* 7878 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_tree_view_column_pack_end(long paramLong1, long paramLong2, boolean paramBoolean);
/*      */   
/*      */ 
/*      */   public static final void gtk_tree_view_column_pack_end(long tree_column, long cell_renderer, boolean expand)
/*      */   {
/* 7888 */     lock.lock();
/*      */     try {
/* 7890 */       _gtk_tree_view_column_pack_end(tree_column, cell_renderer, expand);
/*      */     } finally {
/* 7892 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_tree_view_column_set_alignment(long paramLong, float paramFloat);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_tree_view_column_set_alignment(long tree_column, float xalign)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: fload_2
/*      */     //   9: invokestatic 635	org/eclipse/swt/internal/gtk/GTK:_gtk_tree_view_column_set_alignment	(JF)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #7898	-> byte code offset #0
/*      */     //   Java source line #7900	-> byte code offset #7
/*      */     //   Java source line #7902	-> byte code offset #12
/*      */     //   Java source line #7903	-> byte code offset #18
/*      */     //   Java source line #7902	-> byte code offset #21
/*      */     //   Java source line #7903	-> byte code offset #28
/*      */     //   Java source line #7904	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	tree_column	long
/*      */     //   0	31	2	xalign	float
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_tree_view_column_set_cell_data_func(long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5);
/*      */   
/*      */   public static final void gtk_tree_view_column_set_cell_data_func(long tree_column, long cell_renderer, long func, long func_data, long destroy)
/*      */   {
/* 7914 */     lock.lock();
/*      */     try {
/* 7916 */       _gtk_tree_view_column_set_cell_data_func(tree_column, cell_renderer, func, func_data, destroy);
/*      */     } finally {
/* 7918 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_tree_view_column_set_clickable(long paramLong, boolean paramBoolean);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_tree_view_column_set_clickable(long column, boolean clickable)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 637	org/eclipse/swt/internal/gtk/GTK:_gtk_tree_view_column_set_clickable	(JZ)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #7927	-> byte code offset #0
/*      */     //   Java source line #7929	-> byte code offset #7
/*      */     //   Java source line #7931	-> byte code offset #12
/*      */     //   Java source line #7932	-> byte code offset #18
/*      */     //   Java source line #7931	-> byte code offset #21
/*      */     //   Java source line #7932	-> byte code offset #28
/*      */     //   Java source line #7933	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	column	long
/*      */     //   0	31	2	clickable	boolean
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_tree_view_column_set_fixed_width(long paramLong, int paramInt);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_tree_view_column_set_fixed_width(long column, int fixed_width)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 638	org/eclipse/swt/internal/gtk/GTK:_gtk_tree_view_column_set_fixed_width	(JI)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #7940	-> byte code offset #0
/*      */     //   Java source line #7942	-> byte code offset #7
/*      */     //   Java source line #7944	-> byte code offset #12
/*      */     //   Java source line #7945	-> byte code offset #18
/*      */     //   Java source line #7944	-> byte code offset #21
/*      */     //   Java source line #7945	-> byte code offset #28
/*      */     //   Java source line #7946	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	column	long
/*      */     //   0	31	2	fixed_width	int
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_tree_view_column_set_min_width(long paramLong, int paramInt);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_tree_view_column_set_min_width(long tree_column, int min_width)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 639	org/eclipse/swt/internal/gtk/GTK:_gtk_tree_view_column_set_min_width	(JI)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #7953	-> byte code offset #0
/*      */     //   Java source line #7955	-> byte code offset #7
/*      */     //   Java source line #7957	-> byte code offset #12
/*      */     //   Java source line #7958	-> byte code offset #18
/*      */     //   Java source line #7957	-> byte code offset #21
/*      */     //   Java source line #7958	-> byte code offset #28
/*      */     //   Java source line #7959	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	tree_column	long
/*      */     //   0	31	2	min_width	int
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_tree_view_column_set_reorderable(long paramLong, boolean paramBoolean);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_tree_view_column_set_reorderable(long column, boolean reorderable)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 640	org/eclipse/swt/internal/gtk/GTK:_gtk_tree_view_column_set_reorderable	(JZ)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #7966	-> byte code offset #0
/*      */     //   Java source line #7968	-> byte code offset #7
/*      */     //   Java source line #7970	-> byte code offset #12
/*      */     //   Java source line #7971	-> byte code offset #18
/*      */     //   Java source line #7970	-> byte code offset #21
/*      */     //   Java source line #7971	-> byte code offset #28
/*      */     //   Java source line #7972	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	column	long
/*      */     //   0	31	2	reorderable	boolean
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_tree_view_column_set_resizable(long paramLong, boolean paramBoolean);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_tree_view_column_set_resizable(long column, boolean resizable)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 641	org/eclipse/swt/internal/gtk/GTK:_gtk_tree_view_column_set_resizable	(JZ)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #7979	-> byte code offset #0
/*      */     //   Java source line #7981	-> byte code offset #7
/*      */     //   Java source line #7983	-> byte code offset #12
/*      */     //   Java source line #7984	-> byte code offset #18
/*      */     //   Java source line #7983	-> byte code offset #21
/*      */     //   Java source line #7984	-> byte code offset #28
/*      */     //   Java source line #7985	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	column	long
/*      */     //   0	31	2	resizable	boolean
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_tree_view_column_set_sizing(long paramLong, int paramInt);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_tree_view_column_set_sizing(long column, int type)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 642	org/eclipse/swt/internal/gtk/GTK:_gtk_tree_view_column_set_sizing	(JI)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #7992	-> byte code offset #0
/*      */     //   Java source line #7994	-> byte code offset #7
/*      */     //   Java source line #7996	-> byte code offset #12
/*      */     //   Java source line #7997	-> byte code offset #18
/*      */     //   Java source line #7996	-> byte code offset #21
/*      */     //   Java source line #7997	-> byte code offset #28
/*      */     //   Java source line #7998	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	column	long
/*      */     //   0	31	2	type	int
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_tree_view_column_set_sort_indicator(long paramLong, boolean paramBoolean);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_tree_view_column_set_sort_indicator(long tree_column, boolean setting)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 643	org/eclipse/swt/internal/gtk/GTK:_gtk_tree_view_column_set_sort_indicator	(JZ)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #8005	-> byte code offset #0
/*      */     //   Java source line #8007	-> byte code offset #7
/*      */     //   Java source line #8009	-> byte code offset #12
/*      */     //   Java source line #8010	-> byte code offset #18
/*      */     //   Java source line #8009	-> byte code offset #21
/*      */     //   Java source line #8010	-> byte code offset #28
/*      */     //   Java source line #8011	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	tree_column	long
/*      */     //   0	31	2	setting	boolean
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_tree_view_column_set_sort_order(long paramLong, int paramInt);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_tree_view_column_set_sort_order(long tree_column, int order)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 644	org/eclipse/swt/internal/gtk/GTK:_gtk_tree_view_column_set_sort_order	(JI)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #8018	-> byte code offset #0
/*      */     //   Java source line #8020	-> byte code offset #7
/*      */     //   Java source line #8022	-> byte code offset #12
/*      */     //   Java source line #8023	-> byte code offset #18
/*      */     //   Java source line #8022	-> byte code offset #21
/*      */     //   Java source line #8023	-> byte code offset #28
/*      */     //   Java source line #8024	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	tree_column	long
/*      */     //   0	31	2	order	int
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_tree_view_column_set_visible(long paramLong, boolean paramBoolean);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_tree_view_column_set_visible(long tree_column, boolean visible)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 645	org/eclipse/swt/internal/gtk/GTK:_gtk_tree_view_column_set_visible	(JZ)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #8028	-> byte code offset #0
/*      */     //   Java source line #8030	-> byte code offset #7
/*      */     //   Java source line #8032	-> byte code offset #12
/*      */     //   Java source line #8033	-> byte code offset #18
/*      */     //   Java source line #8032	-> byte code offset #21
/*      */     //   Java source line #8033	-> byte code offset #28
/*      */     //   Java source line #8034	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	tree_column	long
/*      */     //   0	31	2	visible	boolean
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_tree_view_column_set_widget(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final void gtk_tree_view_column_set_widget(long tree_column, long widget)
/*      */   {
/* 8041 */     lock.lock();
/*      */     try {
/* 8043 */       _gtk_tree_view_column_set_widget(tree_column, widget);
/*      */     } finally {
/* 8045 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_tree_view_set_drag_dest_row(long paramLong1, long paramLong2, int paramInt);
/*      */   
/*      */   public static final void gtk_tree_view_set_drag_dest_row(long view, long path, int pos)
/*      */   {
/* 8054 */     lock.lock();
/*      */     try {
/* 8056 */       _gtk_tree_view_set_drag_dest_row(view, path, pos);
/*      */     } finally {
/* 8058 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native boolean _gtk_tree_view_expand_row(long paramLong1, long paramLong2, boolean paramBoolean);
/*      */   
/*      */ 
/*      */   public static final boolean gtk_tree_view_expand_row(long view, long path, boolean open_all)
/*      */   {
/* 8068 */     lock.lock();
/*      */     try {
/* 8070 */       return _gtk_tree_view_expand_row(view, path, open_all);
/*      */     } finally {
/* 8072 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final native void _gtk_tree_view_get_background_area(long paramLong1, long paramLong2, long paramLong3, GdkRectangle paramGdkRectangle);
/*      */   
/*      */ 
/*      */   public static final void gtk_tree_view_get_background_area(long tree_view, long path, long column, GdkRectangle rect)
/*      */   {
/* 8083 */     lock.lock();
/*      */     try {
/* 8085 */       _gtk_tree_view_get_background_area(tree_view, path, column, rect);
/*      */     } finally {
/* 8087 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gtk_tree_view_get_bin_window(long paramLong);
/*      */   
/* 8093 */   public static final long gtk_tree_view_get_bin_window(long tree_view) { lock.lock();
/*      */     try {
/* 8095 */       return _gtk_tree_view_get_bin_window(tree_view);
/*      */     } finally {
/* 8097 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final native void _gtk_tree_view_get_cell_area(long paramLong1, long paramLong2, long paramLong3, GdkRectangle paramGdkRectangle);
/*      */   
/*      */ 
/*      */   public static final void gtk_tree_view_get_cell_area(long tree_view, long path, long column, GdkRectangle rect)
/*      */   {
/* 8108 */     lock.lock();
/*      */     try {
/* 8110 */       _gtk_tree_view_get_cell_area(tree_view, path, column, rect);
/*      */     } finally {
/* 8112 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gtk_tree_view_get_expander_column(long paramLong);
/*      */   
/* 8118 */   public static final long gtk_tree_view_get_expander_column(long tree_view) { lock.lock();
/*      */     try {
/* 8120 */       return _gtk_tree_view_get_expander_column(tree_view);
/*      */     } finally {
/* 8122 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native long _gtk_tree_view_get_column(long paramLong, int paramInt);
/*      */   
/*      */   public static final long gtk_tree_view_get_column(long tree_view, int n)
/*      */   {
/* 8131 */     lock.lock();
/*      */     try {
/* 8133 */       return _gtk_tree_view_get_column(tree_view, n);
/*      */     } finally {
/* 8135 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gtk_tree_view_get_columns(long paramLong);
/*      */   
/* 8141 */   public static final long gtk_tree_view_get_columns(long tree_view) { lock.lock();
/*      */     try {
/* 8143 */       return _gtk_tree_view_get_columns(tree_view);
/*      */     } finally {
/* 8145 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_tree_view_get_cursor(long paramLong, long[] paramArrayOfLong1, long[] paramArrayOfLong2);
/*      */   
/*      */ 
/*      */   public static final void gtk_tree_view_get_cursor(long tree_view, long[] path, long[] focus_column)
/*      */   {
/* 8155 */     lock.lock();
/*      */     try {
/* 8157 */       _gtk_tree_view_get_cursor(tree_view, path, focus_column);
/*      */     } finally {
/* 8159 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native boolean _gtk_tree_view_get_headers_visible(long paramLong);
/*      */   
/* 8165 */   public static final boolean gtk_tree_view_get_headers_visible(long tree_view) { lock.lock();
/*      */     try {
/* 8167 */       return _gtk_tree_view_get_headers_visible(tree_view);
/*      */     } finally {
/* 8169 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native long _gtk_tree_view_get_vadjustment(long paramLong);
/*      */   
/*      */ 
/*      */   public static final long gtk_tree_view_get_vadjustment(long tree_view)
/*      */   {
/* 8179 */     lock.lock();
/*      */     try {
/* 8181 */       return _gtk_tree_view_get_vadjustment(tree_view);
/*      */     } finally {
/* 8183 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final native boolean _gtk_tree_view_get_path_at_pos(long paramLong, int paramInt1, int paramInt2, long[] paramArrayOfLong1, long[] paramArrayOfLong2, int[] paramArrayOfInt1, int[] paramArrayOfInt2);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final boolean gtk_tree_view_get_path_at_pos(long tree_view, int x, int y, long[] path, long[] column, int[] cell_x, int[] cell_y)
/*      */   {
/* 8197 */     lock.lock();
/*      */     try {
/* 8199 */       return _gtk_tree_view_get_path_at_pos(tree_view, x, y, path, column, cell_x, cell_y);
/*      */     } finally {
/* 8201 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native boolean _gtk_tree_view_get_rules_hint(long paramLong);
/*      */   
/*      */ 
/*      */   public static final boolean gtk_tree_view_get_rules_hint(long tree_view)
/*      */   {
/* 8211 */     lock.lock();
/*      */     try {
/* 8213 */       return _gtk_tree_view_get_rules_hint(tree_view);
/*      */     } finally {
/* 8215 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gtk_tree_view_get_selection(long paramLong);
/*      */   
/* 8221 */   public static final long gtk_tree_view_get_selection(long tree_view) { lock.lock();
/*      */     try {
/* 8223 */       return _gtk_tree_view_get_selection(tree_view);
/*      */     } finally {
/* 8225 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_tree_view_get_visible_rect(long paramLong, GdkRectangle paramGdkRectangle);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_tree_view_get_visible_rect(long tree_view, GdkRectangle visible_rect)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: aload_2
/*      */     //   9: invokestatic 661	org/eclipse/swt/internal/gtk/GTK:_gtk_tree_view_get_visible_rect	(JLorg/eclipse/swt/internal/gtk/GdkRectangle;)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #8234	-> byte code offset #0
/*      */     //   Java source line #8236	-> byte code offset #7
/*      */     //   Java source line #8238	-> byte code offset #12
/*      */     //   Java source line #8239	-> byte code offset #18
/*      */     //   Java source line #8238	-> byte code offset #21
/*      */     //   Java source line #8239	-> byte code offset #28
/*      */     //   Java source line #8240	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	tree_view	long
/*      */     //   0	31	2	visible_rect	GdkRectangle
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native int _gtk_tree_view_insert_column(long paramLong1, long paramLong2, int paramInt);
/*      */   
/*      */   public static final int gtk_tree_view_insert_column(long tree_view, long column, int position)
/*      */   {
/* 8248 */     lock.lock();
/*      */     try {
/* 8250 */       return _gtk_tree_view_insert_column(tree_view, column, position);
/*      */     } finally {
/* 8252 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_tree_view_move_column_after(long paramLong1, long paramLong2, long paramLong3);
/*      */   
/*      */ 
/*      */   public static final void gtk_tree_view_move_column_after(long tree_view, long column, long base_column)
/*      */   {
/* 8262 */     lock.lock();
/*      */     try {
/* 8264 */       _gtk_tree_view_move_column_after(tree_view, column, base_column);
/*      */     } finally {
/* 8266 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gtk_tree_view_new_with_model(long paramLong);
/*      */   
/* 8272 */   public static final long gtk_tree_view_new_with_model(long model) { lock.lock();
/*      */     try {
/* 8274 */       return _gtk_tree_view_new_with_model(model);
/*      */     } finally {
/* 8276 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_tree_view_remove_column(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final void gtk_tree_view_remove_column(long tree_view, long column)
/*      */   {
/* 8285 */     lock.lock();
/*      */     try {
/* 8287 */       _gtk_tree_view_remove_column(tree_view, column);
/*      */     } finally {
/* 8289 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native boolean _gtk_tree_view_row_expanded(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final boolean gtk_tree_view_row_expanded(long view, long path)
/*      */   {
/* 8298 */     lock.lock();
/*      */     try {
/* 8300 */       return _gtk_tree_view_row_expanded(view, path);
/*      */     } finally {
/* 8302 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final native void _gtk_tree_view_scroll_to_cell(long paramLong1, long paramLong2, long paramLong3, boolean paramBoolean, float paramFloat1, float paramFloat2);
/*      */   
/*      */ 
/*      */ 
/*      */   public static final void gtk_tree_view_scroll_to_cell(long tree_view, long path, long column, boolean use_align, float row_aligh, float column_align)
/*      */   {
/* 8315 */     lock.lock();
/*      */     try {
/* 8317 */       _gtk_tree_view_scroll_to_cell(tree_view, path, column, use_align, row_aligh, column_align);
/*      */     } finally {
/* 8319 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_tree_view_scroll_to_point(long paramLong, int paramInt1, int paramInt2);
/*      */   
/*      */ 
/*      */   public static final void gtk_tree_view_scroll_to_point(long tree_view, int tree_x, int tree_y)
/*      */   {
/* 8329 */     lock.lock();
/*      */     try {
/* 8331 */       _gtk_tree_view_scroll_to_point(tree_view, tree_x, tree_y);
/*      */     } finally {
/* 8333 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_tree_view_set_cursor(long paramLong1, long paramLong2, long paramLong3, boolean paramBoolean);
/*      */   
/*      */ 
/*      */   public static final void gtk_tree_view_set_cursor(long tree_view, long path, long focus_column, boolean start_editing)
/*      */   {
/* 8343 */     lock.lock();
/*      */     try {
/* 8345 */       _gtk_tree_view_set_cursor(tree_view, path, focus_column, start_editing);
/*      */     } finally {
/* 8347 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_tree_view_set_grid_lines(long paramLong, int paramInt);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_tree_view_set_grid_lines(long tree_view, int grid_lines)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 670	org/eclipse/swt/internal/gtk/GTK:_gtk_tree_view_set_grid_lines	(JI)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #8356	-> byte code offset #0
/*      */     //   Java source line #8358	-> byte code offset #7
/*      */     //   Java source line #8360	-> byte code offset #12
/*      */     //   Java source line #8361	-> byte code offset #18
/*      */     //   Java source line #8360	-> byte code offset #21
/*      */     //   Java source line #8361	-> byte code offset #28
/*      */     //   Java source line #8362	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	tree_view	long
/*      */     //   0	31	2	grid_lines	int
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native int _gtk_tree_view_get_grid_lines(long paramLong);
/*      */   
/*      */   public static final int gtk_tree_view_get_grid_lines(long tree_view)
/*      */   {
/* 8368 */     lock.lock();
/*      */     try {
/* 8370 */       return _gtk_tree_view_get_grid_lines(tree_view);
/*      */     } finally {
/* 8372 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_tree_view_set_headers_visible(long paramLong, boolean paramBoolean);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_tree_view_set_headers_visible(long tree_view, boolean visible)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 672	org/eclipse/swt/internal/gtk/GTK:_gtk_tree_view_set_headers_visible	(JZ)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #8381	-> byte code offset #0
/*      */     //   Java source line #8383	-> byte code offset #7
/*      */     //   Java source line #8385	-> byte code offset #12
/*      */     //   Java source line #8386	-> byte code offset #18
/*      */     //   Java source line #8385	-> byte code offset #21
/*      */     //   Java source line #8386	-> byte code offset #28
/*      */     //   Java source line #8387	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	tree_view	long
/*      */     //   0	31	2	visible	boolean
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_tree_view_set_model(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final void gtk_tree_view_set_model(long tree_view, long model)
/*      */   {
/* 8394 */     lock.lock();
/*      */     try {
/* 8396 */       _gtk_tree_view_set_model(tree_view, model);
/*      */     } finally {
/* 8398 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_tree_view_set_rules_hint(long paramLong, boolean paramBoolean);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_tree_view_set_rules_hint(long tree_view, boolean setting)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 674	org/eclipse/swt/internal/gtk/GTK:_gtk_tree_view_set_rules_hint	(JZ)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #8408	-> byte code offset #0
/*      */     //   Java source line #8410	-> byte code offset #7
/*      */     //   Java source line #8412	-> byte code offset #12
/*      */     //   Java source line #8413	-> byte code offset #18
/*      */     //   Java source line #8412	-> byte code offset #21
/*      */     //   Java source line #8413	-> byte code offset #28
/*      */     //   Java source line #8414	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	tree_view	long
/*      */     //   0	31	2	setting	boolean
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_tree_view_set_search_column(long paramLong, int paramInt);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_tree_view_set_search_column(long tree_view, int column)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 675	org/eclipse/swt/internal/gtk/GTK:_gtk_tree_view_set_search_column	(JI)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #8421	-> byte code offset #0
/*      */     //   Java source line #8423	-> byte code offset #7
/*      */     //   Java source line #8425	-> byte code offset #12
/*      */     //   Java source line #8426	-> byte code offset #18
/*      */     //   Java source line #8425	-> byte code offset #21
/*      */     //   Java source line #8426	-> byte code offset #28
/*      */     //   Java source line #8427	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	tree_view	long
/*      */     //   0	31	2	column	int
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_tree_view_unset_rows_drag_dest(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_tree_view_unset_rows_drag_dest(long tree_view)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 676	org/eclipse/swt/internal/gtk/GTK:_gtk_tree_view_unset_rows_drag_dest	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #8431	-> byte code offset #0
/*      */     //   Java source line #8433	-> byte code offset #7
/*      */     //   Java source line #8435	-> byte code offset #11
/*      */     //   Java source line #8436	-> byte code offset #17
/*      */     //   Java source line #8435	-> byte code offset #20
/*      */     //   Java source line #8436	-> byte code offset #27
/*      */     //   Java source line #8437	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	tree_view	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_tree_view_convert_bin_window_to_tree_coords(long paramLong, int paramInt1, int paramInt2, int[] paramArrayOfInt1, int[] paramArrayOfInt2);
/*      */   
/*      */   public static final void gtk_tree_view_convert_bin_window_to_tree_coords(long tree_view, int bx, int by, int[] tx, int[] ty)
/*      */   {
/* 8447 */     lock.lock();
/*      */     try {
/* 8449 */       _gtk_tree_view_convert_bin_window_to_tree_coords(tree_view, bx, by, tx, ty);
/*      */     } finally {
/* 8451 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final native long _gtk_vbox_new(boolean paramBoolean, int paramInt);
/*      */   
/*      */ 
/*      */   public static final long gtk_vbox_new(boolean homogeneous, int spacing)
/*      */   {
/* 8462 */     lock.lock();
/*      */     try {
/* 8464 */       return _gtk_vbox_new(homogeneous, spacing);
/*      */     } finally {
/* 8466 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_viewport_set_shadow_type(long paramLong, int paramInt);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_viewport_set_shadow_type(long viewport, int type)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 679	org/eclipse/swt/internal/gtk/GTK:_gtk_viewport_set_shadow_type	(JI)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #8475	-> byte code offset #0
/*      */     //   Java source line #8477	-> byte code offset #7
/*      */     //   Java source line #8479	-> byte code offset #12
/*      */     //   Java source line #8480	-> byte code offset #18
/*      */     //   Java source line #8479	-> byte code offset #21
/*      */     //   Java source line #8480	-> byte code offset #28
/*      */     //   Java source line #8481	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	viewport	long
/*      */     //   0	31	2	type	int
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native long _gtk_vscale_new(long paramLong);
/*      */   
/*      */   public static final long gtk_vscale_new(long adjustment)
/*      */   {
/* 8489 */     lock.lock();
/*      */     try {
/* 8491 */       return _gtk_vscale_new(adjustment);
/*      */     } finally {
/* 8493 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native long _gtk_vscrollbar_new(long paramLong);
/*      */   
/*      */ 
/*      */   public static final long gtk_vscrollbar_new(long adjustment)
/*      */   {
/* 8503 */     lock.lock();
/*      */     try {
/* 8505 */       return _gtk_vscrollbar_new(adjustment);
/*      */     } finally {
/* 8507 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gtk_vseparator_new();
/*      */   
/*      */   public static final long gtk_vseparator_new() {
/* 8514 */     lock.lock();
/*      */     try {
/* 8516 */       return _gtk_vseparator_new();
/*      */     } finally {
/* 8518 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final native void _gtk_widget_add_accelerator(long paramLong1, byte[] paramArrayOfByte, long paramLong2, int paramInt1, int paramInt2, int paramInt3);
/*      */   
/*      */ 
/*      */ 
/*      */   public static final void gtk_widget_add_accelerator(long widget, byte[] accel_signal, long accel_group, int accel_key, int accel_mods, int accel_flags)
/*      */   {
/* 8530 */     lock.lock();
/*      */     try {
/* 8532 */       _gtk_widget_add_accelerator(widget, accel_signal, accel_group, accel_key, accel_mods, accel_flags);
/*      */     } finally {
/* 8534 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_widget_add_events(long paramLong, int paramInt);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_widget_add_events(long widget, int events)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 684	org/eclipse/swt/internal/gtk/GTK:_gtk_widget_add_events	(JI)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #8543	-> byte code offset #0
/*      */     //   Java source line #8545	-> byte code offset #7
/*      */     //   Java source line #8547	-> byte code offset #12
/*      */     //   Java source line #8548	-> byte code offset #18
/*      */     //   Java source line #8547	-> byte code offset #21
/*      */     //   Java source line #8548	-> byte code offset #28
/*      */     //   Java source line #8549	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	widget	long
/*      */     //   0	31	2	events	int
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native boolean _gtk_widget_child_focus(long paramLong, int paramInt);
/*      */   
/*      */   public static final boolean gtk_widget_child_focus(long widget, int direction)
/*      */   {
/* 8553 */     lock.lock();
/*      */     try {
/* 8555 */       return _gtk_widget_child_focus(widget, direction);
/*      */     } finally {
/* 8557 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native long _gtk_widget_create_pango_layout(long paramLong, byte[] paramArrayOfByte);
/*      */   
/*      */   public static final long gtk_widget_create_pango_layout(long widget, byte[] text)
/*      */   {
/* 8566 */     lock.lock();
/*      */     try {
/* 8568 */       return _gtk_widget_create_pango_layout(widget, text);
/*      */     } finally {
/* 8570 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native long _gtk_widget_create_pango_layout(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final long gtk_widget_create_pango_layout(long widget, long text)
/*      */   {
/* 8579 */     lock.lock();
/*      */     try {
/* 8581 */       return _gtk_widget_create_pango_layout(widget, text);
/*      */     } finally {
/* 8583 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_widget_destroy(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_widget_destroy(long widget)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 688	org/eclipse/swt/internal/gtk/GTK:_gtk_widget_destroy	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #8589	-> byte code offset #0
/*      */     //   Java source line #8591	-> byte code offset #7
/*      */     //   Java source line #8593	-> byte code offset #11
/*      */     //   Java source line #8594	-> byte code offset #17
/*      */     //   Java source line #8593	-> byte code offset #20
/*      */     //   Java source line #8594	-> byte code offset #27
/*      */     //   Java source line #8595	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	widget	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_widget_draw(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final void gtk_widget_draw(long widget, long cr)
/*      */   {
/* 8599 */     lock.lock();
/*      */     try {
/* 8601 */       _gtk_widget_draw(widget, cr);
/*      */     } finally {
/* 8603 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native boolean _gtk_widget_event(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final boolean gtk_widget_event(long widget, long event)
/*      */   {
/* 8612 */     lock.lock();
/*      */     try {
/* 8614 */       return _gtk_widget_event(widget, event);
/*      */     } finally {
/* 8616 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gtk_widget_get_accessible(long paramLong);
/*      */   
/* 8622 */   public static final long gtk_widget_get_accessible(long widget) { lock.lock();
/*      */     try {
/* 8624 */       return _gtk_widget_get_accessible(widget);
/*      */     } finally {
/* 8626 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native boolean _gtk_widget_get_visible(long paramLong);
/*      */   
/* 8632 */   public static final boolean gtk_widget_get_visible(long widget) { lock.lock();
/*      */     try {
/* 8634 */       return _gtk_widget_get_visible(widget);
/*      */     } finally {
/* 8636 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native boolean _gtk_widget_get_realized(long paramLong);
/*      */   
/* 8642 */   public static final boolean gtk_widget_get_realized(long widget) { lock.lock();
/*      */     try {
/* 8644 */       return _gtk_widget_get_realized(widget);
/*      */     } finally {
/* 8646 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native boolean _gtk_widget_get_has_window(long paramLong);
/*      */   
/* 8652 */   public static final boolean gtk_widget_get_has_window(long widget) { lock.lock();
/*      */     try {
/* 8654 */       return _gtk_widget_get_has_window(widget);
/*      */     } finally {
/* 8656 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native boolean _gtk_widget_get_can_default(long paramLong);
/*      */   
/* 8662 */   public static final boolean gtk_widget_get_can_default(long widget) { lock.lock();
/*      */     try {
/* 8664 */       return _gtk_widget_get_can_default(widget);
/*      */     } finally {
/* 8666 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native boolean _gtk_widget_get_child_visible(long paramLong);
/*      */   
/* 8672 */   public static final boolean gtk_widget_get_child_visible(long widget) { lock.lock();
/*      */     try {
/* 8674 */       return _gtk_widget_get_child_visible(widget);
/*      */     } finally {
/* 8676 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gtk_widget_get_default_style();
/*      */   
/*      */   public static final long gtk_widget_get_default_style() {
/* 8683 */     lock.lock();
/*      */     try {
/* 8685 */       return _gtk_widget_get_default_style();
/*      */     } finally {
/* 8687 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native int _gtk_widget_get_events(long paramLong);
/*      */   
/* 8693 */   public static final int gtk_widget_get_events(long widget) { lock.lock();
/*      */     try {
/* 8695 */       return _gtk_widget_get_events(widget);
/*      */     } finally {
/* 8697 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gtk_widget_get_window(long paramLong);
/*      */   
/* 8703 */   public static final long gtk_widget_get_window(long widget) { lock.lock();
/*      */     try {
/* 8705 */       return _gtk_widget_get_window(widget);
/*      */     } finally {
/* 8707 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native long _gtk_widget_get_modifier_style(long paramLong);
/*      */   
/*      */ 
/*      */   public static final long gtk_widget_get_modifier_style(long widget)
/*      */   {
/* 8717 */     lock.lock();
/*      */     try {
/* 8719 */       return _gtk_widget_get_modifier_style(widget);
/*      */     } finally {
/* 8721 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native boolean _gtk_widget_get_mapped(long paramLong);
/*      */   
/* 8727 */   public static final boolean gtk_widget_get_mapped(long widget) { lock.lock();
/*      */     try {
/* 8729 */       return _gtk_widget_get_mapped(widget);
/*      */     } finally {
/* 8731 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gtk_widget_get_pango_context(long paramLong);
/*      */   
/* 8737 */   public static final long gtk_widget_get_pango_context(long widget) { lock.lock();
/*      */     try {
/* 8739 */       return _gtk_widget_get_pango_context(widget);
/*      */     } finally {
/* 8741 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gtk_widget_get_parent(long paramLong);
/*      */   
/* 8747 */   public static final long gtk_widget_get_parent(long widget) { lock.lock();
/*      */     try {
/* 8749 */       return _gtk_widget_get_parent(widget);
/*      */     } finally {
/* 8751 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gtk_widget_get_parent_window(long paramLong);
/*      */   
/* 8757 */   public static final long gtk_widget_get_parent_window(long widget) { lock.lock();
/*      */     try {
/* 8759 */       return _gtk_widget_get_parent_window(widget);
/*      */     } finally {
/* 8761 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_widget_get_allocation(long paramLong, GtkAllocation paramGtkAllocation);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_widget_get_allocation(long widget, GtkAllocation allocation)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: aload_2
/*      */     //   9: invokestatic 705	org/eclipse/swt/internal/gtk/GTK:_gtk_widget_get_allocation	(JLorg/eclipse/swt/internal/gtk/GtkAllocation;)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #8770	-> byte code offset #0
/*      */     //   Java source line #8772	-> byte code offset #7
/*      */     //   Java source line #8774	-> byte code offset #12
/*      */     //   Java source line #8775	-> byte code offset #18
/*      */     //   Java source line #8774	-> byte code offset #21
/*      */     //   Java source line #8775	-> byte code offset #28
/*      */     //   Java source line #8776	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	widget	long
/*      */     //   0	31	2	allocation	GtkAllocation
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_render_handle(long paramLong1, long paramLong2, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4);
/*      */   
/*      */   public static final void gtk_render_handle(long context, long cr, double x, double y, double width, double height)
/*      */   {
/* 8786 */     lock.lock();
/*      */     try {
/* 8788 */       _gtk_render_handle(context, cr, x, y, width, height);
/*      */     } finally {
/* 8790 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native long _gtk_widget_get_style_context(long paramLong);
/*      */   
/*      */   public static final long gtk_widget_get_style_context(long widget)
/*      */   {
/* 8799 */     lock.lock();
/*      */     try {
/* 8801 */       return _gtk_widget_get_style_context(widget);
/*      */     } finally {
/* 8803 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native long _gtk_widget_get_style(long paramLong);
/*      */   
/*      */ 
/*      */   public static final long gtk_widget_get_style(long widget)
/*      */   {
/* 8813 */     lock.lock();
/*      */     try {
/* 8815 */       return _gtk_widget_get_style(widget);
/*      */     } finally {
/* 8817 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_widget_get_size_request(long paramLong, int[] paramArrayOfInt1, int[] paramArrayOfInt2);
/*      */   
/*      */ 
/*      */   public static final void gtk_widget_get_size_request(long widget, int[] width, int[] height)
/*      */   {
/* 8827 */     lock.lock();
/*      */     try {
/* 8829 */       _gtk_widget_get_size_request(widget, width, height);
/*      */     } finally {
/* 8831 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gtk_widget_get_toplevel(long paramLong);
/*      */   
/* 8837 */   public static final long gtk_widget_get_toplevel(long widget) { lock.lock();
/*      */     try {
/* 8839 */       return _gtk_widget_get_toplevel(widget);
/*      */     } finally {
/* 8841 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gtk_widget_get_tooltip_text(long paramLong);
/*      */   
/* 8847 */   public static final long gtk_widget_get_tooltip_text(long widget) { lock.lock();
/*      */     try {
/* 8849 */       return _gtk_widget_get_tooltip_text(widget);
/*      */     } finally {
/* 8851 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_widget_grab_focus(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_widget_grab_focus(long widget)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 712	org/eclipse/swt/internal/gtk/GTK:_gtk_widget_grab_focus	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #8857	-> byte code offset #0
/*      */     //   Java source line #8859	-> byte code offset #7
/*      */     //   Java source line #8861	-> byte code offset #11
/*      */     //   Java source line #8862	-> byte code offset #17
/*      */     //   Java source line #8861	-> byte code offset #20
/*      */     //   Java source line #8862	-> byte code offset #27
/*      */     //   Java source line #8863	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	widget	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native boolean _gtk_widget_has_focus(long paramLong);
/*      */   
/*      */   public static final boolean gtk_widget_has_focus(long widget)
/*      */   {
/* 8867 */     lock.lock();
/*      */     try {
/* 8869 */       return _gtk_widget_has_focus(widget);
/*      */     } finally {
/* 8871 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_widget_hide(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_widget_hide(long widget)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 714	org/eclipse/swt/internal/gtk/GTK:_gtk_widget_hide	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #8877	-> byte code offset #0
/*      */     //   Java source line #8879	-> byte code offset #7
/*      */     //   Java source line #8881	-> byte code offset #11
/*      */     //   Java source line #8882	-> byte code offset #17
/*      */     //   Java source line #8881	-> byte code offset #20
/*      */     //   Java source line #8882	-> byte code offset #27
/*      */     //   Java source line #8883	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	widget	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_widget_input_shape_combine_region(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final void gtk_widget_input_shape_combine_region(long widget, long region)
/*      */   {
/* 8890 */     lock.lock();
/*      */     try {
/* 8892 */       _gtk_widget_input_shape_combine_region(widget, region);
/*      */     } finally {
/* 8894 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native boolean _gtk_widget_is_composited(long paramLong);
/*      */   
/*      */ 
/*      */   public static final boolean gtk_widget_is_composited(long widget)
/*      */   {
/* 8904 */     lock.lock();
/*      */     try {
/* 8906 */       return _gtk_widget_is_composited(widget);
/*      */     } finally {
/* 8908 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native boolean _gtk_widget_is_focus(long paramLong);
/*      */   
/* 8914 */   public static final boolean gtk_widget_is_focus(long widget) { lock.lock();
/*      */     try {
/* 8916 */       return _gtk_widget_is_focus(widget);
/*      */     } finally {
/* 8918 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_widget_map(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_widget_map(long widget)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 718	org/eclipse/swt/internal/gtk/GTK:_gtk_widget_map	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #8924	-> byte code offset #0
/*      */     //   Java source line #8926	-> byte code offset #7
/*      */     //   Java source line #8928	-> byte code offset #11
/*      */     //   Java source line #8929	-> byte code offset #17
/*      */     //   Java source line #8928	-> byte code offset #20
/*      */     //   Java source line #8929	-> byte code offset #27
/*      */     //   Java source line #8930	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	widget	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native boolean _gtk_widget_mnemonic_activate(long paramLong, boolean paramBoolean);
/*      */   
/*      */   public static final boolean gtk_widget_mnemonic_activate(long widget, boolean group_cycling)
/*      */   {
/* 8937 */     lock.lock();
/*      */     try {
/* 8939 */       return _gtk_widget_mnemonic_activate(widget, group_cycling);
/*      */     } finally {
/* 8941 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final native void _gtk_widget_modify_base(long paramLong, int paramInt, GdkColor paramGdkColor);
/*      */   
/*      */ 
/*      */ 
/*      */   public static final void gtk_widget_modify_base(long widget, int state, GdkColor color)
/*      */   {
/* 8953 */     lock.lock();
/*      */     try {
/* 8955 */       _gtk_widget_modify_base(widget, state, color);
/*      */     } finally {
/* 8957 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final native void _gtk_widget_modify_bg(long paramLong, int paramInt, GdkColor paramGdkColor);
/*      */   
/*      */ 
/*      */ 
/*      */   public static final void gtk_widget_modify_bg(long widget, int state, GdkColor color)
/*      */   {
/* 8969 */     lock.lock();
/*      */     try {
/* 8971 */       _gtk_widget_modify_bg(widget, state, color);
/*      */     } finally {
/* 8973 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final native void _gtk_widget_modify_font(long paramLong1, long paramLong2);
/*      */   
/*      */ 
/*      */   public static final void gtk_widget_modify_font(long widget, long pango_font_descr)
/*      */   {
/* 8984 */     lock.lock();
/*      */     try {
/* 8986 */       _gtk_widget_modify_font(widget, pango_font_descr);
/*      */     } finally {
/* 8988 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final native void _gtk_widget_modify_style(long paramLong1, long paramLong2);
/*      */   
/*      */ 
/*      */   public static final void gtk_widget_modify_style(long widget, long style)
/*      */   {
/* 8999 */     lock.lock();
/*      */     try {
/* 9001 */       _gtk_widget_modify_style(widget, style);
/*      */     } finally {
/* 9003 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_widget_override_color(long paramLong, int paramInt, GdkRGBA paramGdkRGBA);
/*      */   
/*      */   public static final void gtk_widget_override_color(long widget, int state, GdkRGBA color)
/*      */   {
/* 9012 */     lock.lock();
/*      */     try {
/* 9014 */       _gtk_widget_override_color(widget, state, color);
/*      */     } finally {
/* 9016 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_widget_override_background_color(long paramLong, int paramInt, GdkRGBA paramGdkRGBA);
/*      */   
/*      */   public static final void gtk_widget_override_background_color(long widget, int state, GdkRGBA color)
/*      */   {
/* 9025 */     lock.lock();
/*      */     try {
/* 9027 */       _gtk_widget_override_background_color(widget, state, color);
/*      */     } finally {
/* 9029 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_widget_override_font(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final void gtk_widget_override_font(long widget, long font)
/*      */   {
/* 9038 */     lock.lock();
/*      */     try {
/* 9040 */       _gtk_widget_override_font(widget, font);
/*      */     } finally {
/* 9042 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_widget_queue_resize(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_widget_queue_resize(long widget)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 727	org/eclipse/swt/internal/gtk/GTK:_gtk_widget_queue_resize	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #9048	-> byte code offset #0
/*      */     //   Java source line #9050	-> byte code offset #7
/*      */     //   Java source line #9052	-> byte code offset #11
/*      */     //   Java source line #9053	-> byte code offset #17
/*      */     //   Java source line #9052	-> byte code offset #20
/*      */     //   Java source line #9053	-> byte code offset #27
/*      */     //   Java source line #9054	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	widget	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_widget_realize(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_widget_realize(long widget)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 728	org/eclipse/swt/internal/gtk/GTK:_gtk_widget_realize	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #9058	-> byte code offset #0
/*      */     //   Java source line #9060	-> byte code offset #7
/*      */     //   Java source line #9062	-> byte code offset #11
/*      */     //   Java source line #9063	-> byte code offset #17
/*      */     //   Java source line #9062	-> byte code offset #20
/*      */     //   Java source line #9063	-> byte code offset #27
/*      */     //   Java source line #9064	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	widget	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_widget_remove_accelerator(long paramLong1, long paramLong2, int paramInt1, int paramInt2);
/*      */   
/*      */   public static final void gtk_widget_remove_accelerator(long widget, long accel_group, int accel_key, int accel_mods)
/*      */   {
/* 9073 */     lock.lock();
/*      */     try {
/* 9075 */       _gtk_widget_remove_accelerator(widget, accel_group, accel_key, accel_mods);
/*      */     } finally {
/* 9077 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final native void _gtk_widget_reparent(long paramLong1, long paramLong2);
/*      */   
/*      */ 
/*      */   public static final void gtk_widget_reparent(long widget, long new_parent)
/*      */   {
/* 9088 */     lock.lock();
/*      */     try {
/* 9090 */       _gtk_widget_reparent(widget, new_parent);
/*      */     } finally {
/* 9092 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final native int _gtk_widget_send_expose(long paramLong1, long paramLong2);
/*      */   
/*      */ 
/*      */   public static final int gtk_widget_send_expose(long widget, long event)
/*      */   {
/* 9103 */     lock.lock();
/*      */     try {
/* 9105 */       return _gtk_widget_send_expose(widget, event);
/*      */     } finally {
/* 9107 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_widget_set_app_paintable(long paramLong, boolean paramBoolean);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_widget_set_app_paintable(long widget, boolean app_paintable)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 732	org/eclipse/swt/internal/gtk/GTK:_gtk_widget_set_app_paintable	(JZ)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #9113	-> byte code offset #0
/*      */     //   Java source line #9115	-> byte code offset #7
/*      */     //   Java source line #9117	-> byte code offset #12
/*      */     //   Java source line #9118	-> byte code offset #18
/*      */     //   Java source line #9117	-> byte code offset #21
/*      */     //   Java source line #9118	-> byte code offset #28
/*      */     //   Java source line #9119	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	widget	long
/*      */     //   0	31	2	app_paintable	boolean
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_widget_set_default_direction(int paramInt);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_widget_set_default_direction(int dir)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: iload_0
/*      */     //   8: invokestatic 733	org/eclipse/swt/internal/gtk/GTK:_gtk_widget_set_default_direction	(I)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_1
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_1
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #9123	-> byte code offset #0
/*      */     //   Java source line #9125	-> byte code offset #7
/*      */     //   Java source line #9127	-> byte code offset #11
/*      */     //   Java source line #9128	-> byte code offset #17
/*      */     //   Java source line #9127	-> byte code offset #20
/*      */     //   Java source line #9128	-> byte code offset #27
/*      */     //   Java source line #9129	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	dir	int
/*      */     //   20	8	1	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_widget_set_can_default(long paramLong, boolean paramBoolean);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_widget_set_can_default(long widget, boolean can_default)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 734	org/eclipse/swt/internal/gtk/GTK:_gtk_widget_set_can_default	(JZ)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #9136	-> byte code offset #0
/*      */     //   Java source line #9138	-> byte code offset #7
/*      */     //   Java source line #9140	-> byte code offset #12
/*      */     //   Java source line #9141	-> byte code offset #18
/*      */     //   Java source line #9140	-> byte code offset #21
/*      */     //   Java source line #9141	-> byte code offset #28
/*      */     //   Java source line #9142	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	widget	long
/*      */     //   0	31	2	can_default	boolean
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_widget_queue_draw(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_widget_queue_draw(long widget)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 735	org/eclipse/swt/internal/gtk/GTK:_gtk_widget_queue_draw	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #9146	-> byte code offset #0
/*      */     //   Java source line #9148	-> byte code offset #7
/*      */     //   Java source line #9150	-> byte code offset #11
/*      */     //   Java source line #9151	-> byte code offset #17
/*      */     //   Java source line #9150	-> byte code offset #20
/*      */     //   Java source line #9151	-> byte code offset #27
/*      */     //   Java source line #9152	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	widget	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_widget_set_can_focus(long paramLong, boolean paramBoolean);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_widget_set_can_focus(long widget, boolean can_focus)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 736	org/eclipse/swt/internal/gtk/GTK:_gtk_widget_set_can_focus	(JZ)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #9159	-> byte code offset #0
/*      */     //   Java source line #9161	-> byte code offset #7
/*      */     //   Java source line #9163	-> byte code offset #12
/*      */     //   Java source line #9164	-> byte code offset #18
/*      */     //   Java source line #9163	-> byte code offset #21
/*      */     //   Java source line #9164	-> byte code offset #28
/*      */     //   Java source line #9165	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	widget	long
/*      */     //   0	31	2	can_focus	boolean
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_widget_set_mapped(long paramLong, boolean paramBoolean);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_widget_set_mapped(long widget, boolean mapped)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 737	org/eclipse/swt/internal/gtk/GTK:_gtk_widget_set_mapped	(JZ)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #9172	-> byte code offset #0
/*      */     //   Java source line #9174	-> byte code offset #7
/*      */     //   Java source line #9176	-> byte code offset #12
/*      */     //   Java source line #9177	-> byte code offset #18
/*      */     //   Java source line #9176	-> byte code offset #21
/*      */     //   Java source line #9177	-> byte code offset #28
/*      */     //   Java source line #9178	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	widget	long
/*      */     //   0	31	2	mapped	boolean
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_widget_set_visible(long paramLong, boolean paramBoolean);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_widget_set_visible(long widget, boolean visible)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 738	org/eclipse/swt/internal/gtk/GTK:_gtk_widget_set_visible	(JZ)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #9185	-> byte code offset #0
/*      */     //   Java source line #9187	-> byte code offset #7
/*      */     //   Java source line #9189	-> byte code offset #12
/*      */     //   Java source line #9190	-> byte code offset #18
/*      */     //   Java source line #9189	-> byte code offset #21
/*      */     //   Java source line #9190	-> byte code offset #28
/*      */     //   Java source line #9191	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	widget	long
/*      */     //   0	31	2	visible	boolean
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_widget_set_direction(long paramLong, int paramInt);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_widget_set_direction(long widget, int dir)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 739	org/eclipse/swt/internal/gtk/GTK:_gtk_widget_set_direction	(JI)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #9198	-> byte code offset #0
/*      */     //   Java source line #9200	-> byte code offset #7
/*      */     //   Java source line #9202	-> byte code offset #12
/*      */     //   Java source line #9203	-> byte code offset #18
/*      */     //   Java source line #9202	-> byte code offset #21
/*      */     //   Java source line #9203	-> byte code offset #28
/*      */     //   Java source line #9204	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	widget	long
/*      */     //   0	31	2	dir	int
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_widget_set_receives_default(long paramLong, boolean paramBoolean);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_widget_set_receives_default(long widget, boolean receives_default)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 740	org/eclipse/swt/internal/gtk/GTK:_gtk_widget_set_receives_default	(JZ)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #9211	-> byte code offset #0
/*      */     //   Java source line #9213	-> byte code offset #7
/*      */     //   Java source line #9215	-> byte code offset #12
/*      */     //   Java source line #9216	-> byte code offset #18
/*      */     //   Java source line #9215	-> byte code offset #21
/*      */     //   Java source line #9216	-> byte code offset #28
/*      */     //   Java source line #9217	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	widget	long
/*      */     //   0	31	2	receives_default	boolean
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_widget_set_double_buffered(long paramLong, boolean paramBoolean);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_widget_set_double_buffered(long widget, boolean double_buffered)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 741	org/eclipse/swt/internal/gtk/GTK:_gtk_widget_set_double_buffered	(JZ)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #9224	-> byte code offset #0
/*      */     //   Java source line #9226	-> byte code offset #7
/*      */     //   Java source line #9228	-> byte code offset #12
/*      */     //   Java source line #9229	-> byte code offset #18
/*      */     //   Java source line #9228	-> byte code offset #21
/*      */     //   Java source line #9229	-> byte code offset #28
/*      */     //   Java source line #9230	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	widget	long
/*      */     //   0	31	2	double_buffered	boolean
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_widget_set_focus_on_click(long paramLong, boolean paramBoolean);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_widget_set_focus_on_click(long widget, boolean val)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 742	org/eclipse/swt/internal/gtk/GTK:_gtk_widget_set_focus_on_click	(JZ)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #9238	-> byte code offset #0
/*      */     //   Java source line #9240	-> byte code offset #7
/*      */     //   Java source line #9242	-> byte code offset #12
/*      */     //   Java source line #9243	-> byte code offset #18
/*      */     //   Java source line #9242	-> byte code offset #21
/*      */     //   Java source line #9243	-> byte code offset #28
/*      */     //   Java source line #9244	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	widget	long
/*      */     //   0	31	2	val	boolean
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_widget_set_name(long paramLong, byte[] paramArrayOfByte);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_widget_set_name(long widget, byte[] name)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: aload_2
/*      */     //   9: invokestatic 743	org/eclipse/swt/internal/gtk/GTK:_gtk_widget_set_name	(J[B)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #9251	-> byte code offset #0
/*      */     //   Java source line #9253	-> byte code offset #7
/*      */     //   Java source line #9255	-> byte code offset #12
/*      */     //   Java source line #9256	-> byte code offset #18
/*      */     //   Java source line #9255	-> byte code offset #21
/*      */     //   Java source line #9256	-> byte code offset #28
/*      */     //   Java source line #9257	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	widget	long
/*      */     //   0	31	2	name	byte[]
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_widget_set_opacity(long paramLong, double paramDouble);
/*      */   
/*      */   public static final void gtk_widget_set_opacity(long widget, double opacity)
/*      */   {
/* 9264 */     lock.lock();
/*      */     try {
/* 9266 */       _gtk_widget_set_opacity(widget, opacity);
/*      */     } finally {
/* 9268 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native double _gtk_widget_get_opacity(long paramLong);
/*      */   
/*      */   public static final double gtk_widget_get_opacity(long widget)
/*      */   {
/* 9277 */     lock.lock();
/*      */     try {
/* 9279 */       return _gtk_widget_get_opacity(widget);
/*      */     } finally {
/* 9281 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_widget_set_redraw_on_allocate(long paramLong, boolean paramBoolean);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_widget_set_redraw_on_allocate(long widget, boolean redraw)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 746	org/eclipse/swt/internal/gtk/GTK:_gtk_widget_set_redraw_on_allocate	(JZ)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #9290	-> byte code offset #0
/*      */     //   Java source line #9292	-> byte code offset #7
/*      */     //   Java source line #9294	-> byte code offset #12
/*      */     //   Java source line #9295	-> byte code offset #18
/*      */     //   Java source line #9294	-> byte code offset #21
/*      */     //   Java source line #9295	-> byte code offset #28
/*      */     //   Java source line #9296	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	widget	long
/*      */     //   0	31	2	redraw	boolean
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_widget_set_sensitive(long paramLong, boolean paramBoolean);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_widget_set_sensitive(long widget, boolean sensitive)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 747	org/eclipse/swt/internal/gtk/GTK:_gtk_widget_set_sensitive	(JZ)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #9303	-> byte code offset #0
/*      */     //   Java source line #9305	-> byte code offset #7
/*      */     //   Java source line #9307	-> byte code offset #12
/*      */     //   Java source line #9308	-> byte code offset #18
/*      */     //   Java source line #9307	-> byte code offset #21
/*      */     //   Java source line #9308	-> byte code offset #28
/*      */     //   Java source line #9309	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	widget	long
/*      */     //   0	31	2	sensitive	boolean
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_widget_set_size_request(long paramLong, int paramInt1, int paramInt2);
/*      */   
/*      */   public static final void gtk_widget_set_size_request(long widget, int width, int height)
/*      */   {
/* 9317 */     lock.lock();
/*      */     try {
/* 9319 */       _gtk_widget_set_size_request(widget, width, height);
/*      */     } finally {
/* 9321 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_widget_set_state(long paramLong, int paramInt);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_widget_set_state(long widget, int state)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 749	org/eclipse/swt/internal/gtk/GTK:_gtk_widget_set_state	(JI)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #9332	-> byte code offset #0
/*      */     //   Java source line #9334	-> byte code offset #7
/*      */     //   Java source line #9336	-> byte code offset #12
/*      */     //   Java source line #9337	-> byte code offset #18
/*      */     //   Java source line #9336	-> byte code offset #21
/*      */     //   Java source line #9337	-> byte code offset #28
/*      */     //   Java source line #9338	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	widget	long
/*      */     //   0	31	2	state	int
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_widget_show(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_widget_show(long widget)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 750	org/eclipse/swt/internal/gtk/GTK:_gtk_widget_show	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #9342	-> byte code offset #0
/*      */     //   Java source line #9344	-> byte code offset #7
/*      */     //   Java source line #9346	-> byte code offset #11
/*      */     //   Java source line #9347	-> byte code offset #17
/*      */     //   Java source line #9346	-> byte code offset #20
/*      */     //   Java source line #9347	-> byte code offset #27
/*      */     //   Java source line #9348	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	widget	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_widget_size_allocate(long paramLong, GtkAllocation paramGtkAllocation);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_widget_size_allocate(long widget, GtkAllocation allocation)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: aload_2
/*      */     //   9: invokestatic 751	org/eclipse/swt/internal/gtk/GTK:_gtk_widget_size_allocate	(JLorg/eclipse/swt/internal/gtk/GtkAllocation;)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #9355	-> byte code offset #0
/*      */     //   Java source line #9357	-> byte code offset #7
/*      */     //   Java source line #9359	-> byte code offset #12
/*      */     //   Java source line #9360	-> byte code offset #18
/*      */     //   Java source line #9359	-> byte code offset #21
/*      */     //   Java source line #9360	-> byte code offset #28
/*      */     //   Java source line #9361	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	widget	long
/*      */     //   0	31	2	allocation	GtkAllocation
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_widget_size_request(long paramLong, GtkRequisition paramGtkRequisition);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_widget_size_request(long widget, GtkRequisition requisition)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: aload_2
/*      */     //   9: invokestatic 752	org/eclipse/swt/internal/gtk/GTK:_gtk_widget_size_request	(JLorg/eclipse/swt/internal/gtk/GtkRequisition;)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #9370	-> byte code offset #0
/*      */     //   Java source line #9372	-> byte code offset #7
/*      */     //   Java source line #9374	-> byte code offset #12
/*      */     //   Java source line #9375	-> byte code offset #18
/*      */     //   Java source line #9374	-> byte code offset #21
/*      */     //   Java source line #9375	-> byte code offset #28
/*      */     //   Java source line #9376	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	widget	long
/*      */     //   0	31	2	requisition	GtkRequisition
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_widget_set_allocation(long paramLong, GtkAllocation paramGtkAllocation);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_widget_set_allocation(long widget, GtkAllocation allocation)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: aload_2
/*      */     //   9: invokestatic 753	org/eclipse/swt/internal/gtk/GTK:_gtk_widget_set_allocation	(JLorg/eclipse/swt/internal/gtk/GtkAllocation;)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #9383	-> byte code offset #0
/*      */     //   Java source line #9385	-> byte code offset #7
/*      */     //   Java source line #9387	-> byte code offset #12
/*      */     //   Java source line #9388	-> byte code offset #18
/*      */     //   Java source line #9387	-> byte code offset #21
/*      */     //   Java source line #9388	-> byte code offset #28
/*      */     //   Java source line #9389	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	widget	long
/*      */     //   0	31	2	allocation	GtkAllocation
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_widget_style_get(long paramLong1, byte[] paramArrayOfByte, int[] paramArrayOfInt, long paramLong2);
/*      */   
/*      */   public static final void gtk_widget_style_get(long widget, byte[] property_name, int[] value, long terminator)
/*      */   {
/* 9397 */     lock.lock();
/*      */     try {
/* 9399 */       _gtk_widget_style_get(widget, property_name, value, terminator);
/*      */     } finally {
/* 9401 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_widget_style_get(long paramLong1, byte[] paramArrayOfByte, long[] paramArrayOfLong, long paramLong2);
/*      */   
/*      */ 
/*      */   public static final void gtk_widget_style_get(long widget, byte[] property_name, long[] value, long terminator)
/*      */   {
/* 9411 */     lock.lock();
/*      */     try {
/* 9413 */       _gtk_widget_style_get(widget, property_name, value, terminator);
/*      */     } finally {
/* 9415 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final native boolean _gtk_widget_translate_coordinates(long paramLong1, long paramLong2, int paramInt1, int paramInt2, int[] paramArrayOfInt1, int[] paramArrayOfInt2);
/*      */   
/*      */ 
/*      */   public static final boolean gtk_widget_translate_coordinates(long src_widget, long dest_widget, int src_x, int src_y, int[] dest_x, int[] dest_y)
/*      */   {
/* 9426 */     lock.lock();
/*      */     try {
/* 9428 */       return _gtk_widget_translate_coordinates(src_widget, dest_widget, src_x, src_y, dest_x, dest_y);
/*      */     } finally {
/* 9430 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native boolean _gtk_window_activate_default(long paramLong);
/*      */   
/* 9436 */   public static final boolean gtk_window_activate_default(long window) { lock.lock();
/*      */     try {
/* 9438 */       return _gtk_window_activate_default(window);
/*      */     } finally {
/* 9440 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_window_add_accel_group(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final void gtk_window_add_accel_group(long window, long accel_group)
/*      */   {
/* 9449 */     lock.lock();
/*      */     try {
/* 9451 */       _gtk_window_add_accel_group(window, accel_group);
/*      */     } finally {
/* 9453 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_window_deiconify(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_window_deiconify(long handle)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 759	org/eclipse/swt/internal/gtk/GTK:_gtk_window_deiconify	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #9459	-> byte code offset #0
/*      */     //   Java source line #9461	-> byte code offset #7
/*      */     //   Java source line #9463	-> byte code offset #11
/*      */     //   Java source line #9464	-> byte code offset #17
/*      */     //   Java source line #9463	-> byte code offset #20
/*      */     //   Java source line #9464	-> byte code offset #27
/*      */     //   Java source line #9465	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	handle	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native long _gtk_window_get_focus(long paramLong);
/*      */   
/*      */   public static final long gtk_window_get_focus(long window)
/*      */   {
/* 9469 */     lock.lock();
/*      */     try {
/* 9471 */       return _gtk_window_get_focus(window);
/*      */     } finally {
/* 9473 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gtk_window_get_group(long paramLong);
/*      */   
/*      */   public static final long gtk_window_get_group(long window)
/*      */   {
/* 9481 */     lock.lock();
/*      */     try {
/* 9483 */       return _gtk_window_get_group(window);
/*      */     } finally {
/* 9485 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gtk_window_get_icon_list(long paramLong);
/*      */   
/* 9491 */   public static final long gtk_window_get_icon_list(long window) { lock.lock();
/*      */     try {
/* 9493 */       return _gtk_window_get_icon_list(window);
/*      */     } finally {
/* 9495 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native boolean _gtk_window_get_modal(long paramLong);
/*      */   
/* 9501 */   public static final boolean gtk_window_get_modal(long window) { lock.lock();
/*      */     try {
/* 9503 */       return _gtk_window_get_modal(window);
/*      */     } finally {
/* 9505 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native int _gtk_window_get_mnemonic_modifier(long paramLong);
/*      */   
/* 9511 */   public static final int gtk_window_get_mnemonic_modifier(long window) { lock.lock();
/*      */     try {
/* 9513 */       return _gtk_window_get_mnemonic_modifier(window);
/*      */     } finally {
/* 9515 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native double _gtk_window_get_opacity(long paramLong);
/*      */   
/*      */ 
/*      */   public static final double gtk_window_get_opacity(long window)
/*      */   {
/* 9525 */     lock.lock();
/*      */     try {
/* 9527 */       return _gtk_window_get_opacity(window);
/*      */     } finally {
/* 9529 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_window_get_position(long paramLong, int[] paramArrayOfInt1, int[] paramArrayOfInt2);
/*      */   
/*      */ 
/*      */   public static final void gtk_window_get_position(long handle, int[] x, int[] y)
/*      */   {
/* 9539 */     lock.lock();
/*      */     try {
/* 9541 */       _gtk_window_get_position(handle, x, y);
/*      */     } finally {
/* 9543 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_window_group_add_window(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final void gtk_window_group_add_window(long group, long window)
/*      */   {
/* 9552 */     lock.lock();
/*      */     try {
/* 9554 */       _gtk_window_group_add_window(group, window);
/*      */     } finally {
/* 9556 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_window_group_remove_window(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final void gtk_window_group_remove_window(long group, long window)
/*      */   {
/* 9565 */     lock.lock();
/*      */     try {
/* 9567 */       _gtk_window_group_remove_window(group, window);
/*      */     } finally {
/* 9569 */       lock.unlock();
/*      */     } }
/*      */   
/*      */   public static final native long _gtk_window_group_new();
/*      */   
/* 9574 */   public static final long gtk_window_group_new() { lock.lock();
/*      */     try {
/* 9576 */       return _gtk_window_group_new();
/*      */     } finally {
/* 9578 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native boolean _gtk_window_is_active(long paramLong);
/*      */   
/* 9584 */   public static final boolean gtk_window_is_active(long handle) { lock.lock();
/*      */     try {
/* 9586 */       return _gtk_window_is_active(handle);
/*      */     } finally {
/* 9588 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_window_iconify(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_window_iconify(long handle)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 771	org/eclipse/swt/internal/gtk/GTK:_gtk_window_iconify	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #9594	-> byte code offset #0
/*      */     //   Java source line #9596	-> byte code offset #7
/*      */     //   Java source line #9598	-> byte code offset #11
/*      */     //   Java source line #9599	-> byte code offset #17
/*      */     //   Java source line #9598	-> byte code offset #20
/*      */     //   Java source line #9599	-> byte code offset #27
/*      */     //   Java source line #9600	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	handle	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native long _gtk_window_list_toplevels();
/*      */   
/*      */   public static final long gtk_window_list_toplevels()
/*      */   {
/* 9603 */     lock.lock();
/*      */     try {
/* 9605 */       return _gtk_window_list_toplevels();
/*      */     } finally {
/* 9607 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_window_maximize(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_window_maximize(long handle)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 773	org/eclipse/swt/internal/gtk/GTK:_gtk_window_maximize	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #9613	-> byte code offset #0
/*      */     //   Java source line #9615	-> byte code offset #7
/*      */     //   Java source line #9617	-> byte code offset #11
/*      */     //   Java source line #9618	-> byte code offset #17
/*      */     //   Java source line #9617	-> byte code offset #20
/*      */     //   Java source line #9618	-> byte code offset #27
/*      */     //   Java source line #9619	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	handle	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_window_fullscreen(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_window_fullscreen(long handle)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 774	org/eclipse/swt/internal/gtk/GTK:_gtk_window_fullscreen	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #9623	-> byte code offset #0
/*      */     //   Java source line #9625	-> byte code offset #7
/*      */     //   Java source line #9627	-> byte code offset #11
/*      */     //   Java source line #9628	-> byte code offset #17
/*      */     //   Java source line #9627	-> byte code offset #20
/*      */     //   Java source line #9628	-> byte code offset #27
/*      */     //   Java source line #9629	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	handle	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_window_unfullscreen(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_window_unfullscreen(long handle)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 775	org/eclipse/swt/internal/gtk/GTK:_gtk_window_unfullscreen	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #9633	-> byte code offset #0
/*      */     //   Java source line #9635	-> byte code offset #7
/*      */     //   Java source line #9637	-> byte code offset #11
/*      */     //   Java source line #9638	-> byte code offset #17
/*      */     //   Java source line #9637	-> byte code offset #20
/*      */     //   Java source line #9638	-> byte code offset #27
/*      */     //   Java source line #9639	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	handle	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_window_move(long paramLong, int paramInt1, int paramInt2);
/*      */   
/*      */   public static final void gtk_window_move(long handle, int x, int y)
/*      */   {
/* 9647 */     lock.lock();
/*      */     try {
/* 9649 */       _gtk_window_move(handle, x, y);
/*      */     } finally {
/* 9651 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native long _gtk_window_new(int paramInt);
/*      */   
/* 9657 */   public static final long gtk_window_new(int type) { lock.lock();
/*      */     try {
/* 9659 */       return _gtk_window_new(type);
/*      */     } finally {
/* 9661 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_window_remove_accel_group(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final void gtk_window_remove_accel_group(long window, long accel_group)
/*      */   {
/* 9670 */     lock.lock();
/*      */     try {
/* 9672 */       _gtk_window_remove_accel_group(window, accel_group);
/*      */     } finally {
/* 9674 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_window_resize(long paramLong, int paramInt1, int paramInt2);
/*      */   
/*      */ 
/*      */   public static final void gtk_window_resize(long handle, int x, int y)
/*      */   {
/* 9684 */     lock.lock();
/*      */     try {
/* 9686 */       _gtk_window_resize(handle, x, y);
/*      */     } finally {
/* 9688 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_window_get_size(long paramLong, int[] paramArrayOfInt1, int[] paramArrayOfInt2);
/*      */   
/*      */ 
/*      */   public static final void gtk_window_get_size(long handle, int[] width, int[] height)
/*      */   {
/* 9698 */     lock.lock();
/*      */     try {
/* 9700 */       _gtk_window_get_size(handle, width, height);
/*      */     } finally {
/* 9702 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_window_set_default(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final void gtk_window_set_default(long window, long widget)
/*      */   {
/* 9711 */     lock.lock();
/*      */     try {
/* 9713 */       _gtk_window_set_default(window, widget);
/*      */     } finally {
/* 9715 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_window_set_decorated(long paramLong, boolean paramBoolean);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_window_set_decorated(long window, boolean decorated)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 782	org/eclipse/swt/internal/gtk/GTK:_gtk_window_set_decorated	(JZ)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #9724	-> byte code offset #0
/*      */     //   Java source line #9726	-> byte code offset #7
/*      */     //   Java source line #9728	-> byte code offset #12
/*      */     //   Java source line #9729	-> byte code offset #18
/*      */     //   Java source line #9728	-> byte code offset #21
/*      */     //   Java source line #9729	-> byte code offset #28
/*      */     //   Java source line #9730	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	window	long
/*      */     //   0	31	2	decorated	boolean
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_window_set_destroy_with_parent(long paramLong, boolean paramBoolean);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_window_set_destroy_with_parent(long window, boolean setting)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 783	org/eclipse/swt/internal/gtk/GTK:_gtk_window_set_destroy_with_parent	(JZ)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #9737	-> byte code offset #0
/*      */     //   Java source line #9739	-> byte code offset #7
/*      */     //   Java source line #9741	-> byte code offset #12
/*      */     //   Java source line #9742	-> byte code offset #18
/*      */     //   Java source line #9741	-> byte code offset #21
/*      */     //   Java source line #9742	-> byte code offset #28
/*      */     //   Java source line #9743	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	window	long
/*      */     //   0	31	2	setting	boolean
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_window_set_geometry_hints(long paramLong1, long paramLong2, GdkGeometry paramGdkGeometry, int paramInt);
/*      */   
/*      */   public static final void gtk_window_set_geometry_hints(long window, long geometry_widget, GdkGeometry geometry, int geom_mask)
/*      */   {
/* 9751 */     lock.lock();
/*      */     try {
/* 9753 */       _gtk_window_set_geometry_hints(window, geometry_widget, geometry, geom_mask);
/*      */     } finally {
/* 9755 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public static final native void _gtk_window_set_icon_list(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final void gtk_window_set_icon_list(long window, long list)
/*      */   {
/* 9764 */     lock.lock();
/*      */     try {
/* 9766 */       _gtk_window_set_icon_list(window, list);
/*      */     } finally {
/* 9768 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_window_set_modal(long paramLong, boolean paramBoolean);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_window_set_modal(long window, boolean modal)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 786	org/eclipse/swt/internal/gtk/GTK:_gtk_window_set_modal	(JZ)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #9777	-> byte code offset #0
/*      */     //   Java source line #9779	-> byte code offset #7
/*      */     //   Java source line #9781	-> byte code offset #12
/*      */     //   Java source line #9782	-> byte code offset #18
/*      */     //   Java source line #9781	-> byte code offset #21
/*      */     //   Java source line #9782	-> byte code offset #28
/*      */     //   Java source line #9783	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	window	long
/*      */     //   0	31	2	modal	boolean
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_window_set_opacity(long paramLong, double paramDouble);
/*      */   
/*      */   public static final void gtk_window_set_opacity(long window, double opacity)
/*      */   {
/* 9791 */     lock.lock();
/*      */     try {
/* 9793 */       _gtk_window_set_opacity(window, opacity);
/*      */     } finally {
/* 9795 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_widget_set_tooltip_text(long paramLong, byte[] paramArrayOfByte);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_widget_set_tooltip_text(long widget, byte[] tip_text)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: aload_2
/*      */     //   9: invokestatic 788	org/eclipse/swt/internal/gtk/GTK:_gtk_widget_set_tooltip_text	(J[B)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #9804	-> byte code offset #0
/*      */     //   Java source line #9806	-> byte code offset #7
/*      */     //   Java source line #9808	-> byte code offset #12
/*      */     //   Java source line #9809	-> byte code offset #18
/*      */     //   Java source line #9808	-> byte code offset #21
/*      */     //   Java source line #9809	-> byte code offset #28
/*      */     //   Java source line #9810	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	widget	long
/*      */     //   0	31	2	tip_text	byte[]
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_widget_set_parent_window(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final void gtk_widget_set_parent_window(long widget, long parent_window)
/*      */   {
/* 9817 */     lock.lock();
/*      */     try {
/* 9819 */       _gtk_widget_set_parent_window(widget, parent_window);
/*      */     } finally {
/* 9821 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_window_set_resizable(long paramLong, boolean paramBoolean);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_window_set_resizable(long window, boolean resizable)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 790	org/eclipse/swt/internal/gtk/GTK:_gtk_window_set_resizable	(JZ)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #9830	-> byte code offset #0
/*      */     //   Java source line #9832	-> byte code offset #7
/*      */     //   Java source line #9834	-> byte code offset #12
/*      */     //   Java source line #9835	-> byte code offset #18
/*      */     //   Java source line #9834	-> byte code offset #21
/*      */     //   Java source line #9835	-> byte code offset #28
/*      */     //   Java source line #9836	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	window	long
/*      */     //   0	31	2	resizable	boolean
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_window_set_title(long paramLong, byte[] paramArrayOfByte);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_window_set_title(long window, byte[] title)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: aload_2
/*      */     //   9: invokestatic 791	org/eclipse/swt/internal/gtk/GTK:_gtk_window_set_title	(J[B)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #9843	-> byte code offset #0
/*      */     //   Java source line #9845	-> byte code offset #7
/*      */     //   Java source line #9847	-> byte code offset #12
/*      */     //   Java source line #9848	-> byte code offset #18
/*      */     //   Java source line #9847	-> byte code offset #21
/*      */     //   Java source line #9848	-> byte code offset #28
/*      */     //   Java source line #9849	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	window	long
/*      */     //   0	31	2	title	byte[]
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_window_set_skip_taskbar_hint(long paramLong, boolean paramBoolean);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_window_set_skip_taskbar_hint(long window, boolean skips_taskbar)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 792	org/eclipse/swt/internal/gtk/GTK:_gtk_window_set_skip_taskbar_hint	(JZ)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #9856	-> byte code offset #0
/*      */     //   Java source line #9858	-> byte code offset #7
/*      */     //   Java source line #9860	-> byte code offset #12
/*      */     //   Java source line #9861	-> byte code offset #18
/*      */     //   Java source line #9860	-> byte code offset #21
/*      */     //   Java source line #9861	-> byte code offset #28
/*      */     //   Java source line #9862	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	window	long
/*      */     //   0	31	2	skips_taskbar	boolean
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_window_set_type_hint(long paramLong, int paramInt);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_window_set_type_hint(long window, int hint)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: iload_2
/*      */     //   9: invokestatic 793	org/eclipse/swt/internal/gtk/GTK:_gtk_window_set_type_hint	(JI)V
/*      */     //   12: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   15: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   18: goto +12 -> 30
/*      */     //   21: astore_3
/*      */     //   22: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   25: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   28: aload_3
/*      */     //   29: athrow
/*      */     //   30: return
/*      */     // Line number table:
/*      */     //   Java source line #9866	-> byte code offset #0
/*      */     //   Java source line #9868	-> byte code offset #7
/*      */     //   Java source line #9870	-> byte code offset #12
/*      */     //   Java source line #9871	-> byte code offset #18
/*      */     //   Java source line #9870	-> byte code offset #21
/*      */     //   Java source line #9871	-> byte code offset #28
/*      */     //   Java source line #9872	-> byte code offset #30
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	31	0	window	long
/*      */     //   0	31	2	hint	int
/*      */     //   21	8	3	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	12	21	finally
/*      */   }
/*      */   
/*      */   public static final native void _gtk_window_set_transient_for(long paramLong1, long paramLong2);
/*      */   
/*      */   public static final void gtk_window_set_transient_for(long window, long parent)
/*      */   {
/* 9879 */     lock.lock();
/*      */     try {
/* 9881 */       _gtk_window_set_transient_for(window, parent);
/*      */     } finally {
/* 9883 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_window_unmaximize(long paramLong);
/*      */   
/*      */   /* Error */
/*      */   public static final void gtk_window_unmaximize(long handle)
/*      */   {
/*      */     // Byte code:
/*      */     //   0: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   3: invokevirtual 3	org/eclipse/swt/internal/Lock:lock	()I
/*      */     //   6: pop
/*      */     //   7: lload_0
/*      */     //   8: invokestatic 795	org/eclipse/swt/internal/gtk/GTK:_gtk_window_unmaximize	(J)V
/*      */     //   11: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   14: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   17: goto +12 -> 29
/*      */     //   20: astore_2
/*      */     //   21: getstatic 2	org/eclipse/swt/internal/gtk/GTK:lock	Lorg/eclipse/swt/internal/Lock;
/*      */     //   24: invokevirtual 5	org/eclipse/swt/internal/Lock:unlock	()V
/*      */     //   27: aload_2
/*      */     //   28: athrow
/*      */     //   29: return
/*      */     // Line number table:
/*      */     //   Java source line #9889	-> byte code offset #0
/*      */     //   Java source line #9891	-> byte code offset #7
/*      */     //   Java source line #9893	-> byte code offset #11
/*      */     //   Java source line #9894	-> byte code offset #17
/*      */     //   Java source line #9893	-> byte code offset #20
/*      */     //   Java source line #9894	-> byte code offset #27
/*      */     //   Java source line #9895	-> byte code offset #29
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	signature
/*      */     //   0	30	0	handle	long
/*      */     //   20	8	2	localObject	Object
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   7	11	20	finally
/*      */   }
/*      */   
/*      */   public static final native long _gtk_printer_option_widget_get_type();
/*      */   
/*      */   public static final long gtk_printer_option_widget_get_type()
/*      */   {
/* 9899 */     lock.lock();
/*      */     try {
/* 9901 */       return _gtk_printer_option_widget_get_type();
/*      */     } finally {
/* 9903 */       lock.unlock();
/*      */     }
/*      */   }
/*      */   
/*      */   public static final native void _gtk_widget_shape_combine_region(long paramLong1, long paramLong2);
/*      */   
/* 9909 */   public static final void gtk_widget_shape_combine_region(long widget, long region) { lock.lock();
/*      */     try {
/* 9911 */       _gtk_widget_shape_combine_region(widget, region);
/*      */     } finally {
/* 9913 */       lock.unlock();
/*      */     }
/*      */   }
/*      */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/internal/gtk/GTK.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */