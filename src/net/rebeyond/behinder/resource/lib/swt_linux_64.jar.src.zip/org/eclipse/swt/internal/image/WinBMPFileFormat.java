/*     */ package org.eclipse.swt.internal.image;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import org.eclipse.swt.SWT;
/*     */ import org.eclipse.swt.graphics.ImageData;
/*     */ import org.eclipse.swt.graphics.ImageLoader;
/*     */ import org.eclipse.swt.graphics.PaletteData;
/*     */ import org.eclipse.swt.graphics.Point;
/*     */ import org.eclipse.swt.graphics.RGB;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class WinBMPFileFormat
/*     */   extends FileFormat
/*     */ {
/*     */   static final int BMPFileHeaderSize = 14;
/*     */   static final int BMPHeaderFixedSize = 40;
/*     */   int importantColors;
/*  22 */   Point pelsPerMeter = new Point(0, 0);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   int compress(int comp, byte[] src, int srcOffset, int numBytes, byte[] dest, boolean last)
/*     */   {
/*  31 */     if (comp == 1) {
/*  32 */       return compressRLE8Data(src, srcOffset, numBytes, dest, last);
/*     */     }
/*  34 */     if (comp == 2) {
/*  35 */       return compressRLE4Data(src, srcOffset, numBytes, dest, last);
/*     */     }
/*  37 */     SWT.error(40);
/*  38 */     return 0;
/*     */   }
/*     */   
/*  41 */   int compressRLE4Data(byte[] src, int srcOffset, int numBytes, byte[] dest, boolean last) { int sp = srcOffset;int end = srcOffset + numBytes;int dp = 0;
/*  42 */     int size = 0;
/*     */     
/*  44 */     while (sp < end)
/*     */     {
/*  46 */       int left = end - sp - 1;
/*  47 */       if (left > 127)
/*  48 */         left = 127;
/*  49 */       for (int n = 0; n < left; n++) {
/*  50 */         if (src[(sp + n)] == src[(sp + n + 1)]) {
/*     */           break;
/*     */         }
/*     */       }
/*  54 */       if ((n < 127) && (n == left)) {
/*  55 */         n++;
/*     */       }
/*  57 */       switch (n) {
/*     */       case 0: 
/*     */         break;
/*     */       case 1: 
/*  61 */         dest[dp] = 2;dp++;
/*  62 */         dest[dp] = src[sp];
/*  63 */         dp++;sp++;
/*  64 */         size += 2;
/*  65 */         break;
/*     */       default: 
/*  67 */         dest[dp] = 0;dp++;
/*  68 */         dest[dp] = ((byte)(n + n));dp++;
/*  69 */         for (int i = n; i > 0; i--) {
/*  70 */           dest[dp] = src[sp];
/*  71 */           dp++;sp++;
/*     */         }
/*  73 */         size += 2 + n;
/*  74 */         if ((n & 0x1) != 0) {
/*  75 */           dest[dp] = 0;
/*  76 */           dp++;
/*  77 */           size++;
/*     */         }
/*     */         break;
/*     */       }
/*     */       
/*  82 */       left = end - sp;
/*  83 */       if (left > 0) {
/*  84 */         if (left > 127)
/*  85 */           left = 127;
/*  86 */         byte theByte = src[sp];
/*  87 */         for (n = 1; n < left; n++) {
/*  88 */           if (src[(sp + n)] != theByte)
/*     */             break;
/*     */         }
/*  91 */         dest[dp] = ((byte)(n + n));dp++;
/*  92 */         dest[dp] = theByte;dp++;
/*  93 */         sp += n;
/*  94 */         size += 2;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*  99 */     dest[dp] = 0;dp++;
/* 100 */     if (last) {
/* 101 */       dest[dp] = 1;dp++;
/*     */     } else {
/* 103 */       dest[dp] = 0;dp++;
/*     */     }
/* 105 */     size += 2;
/*     */     
/* 107 */     return size;
/*     */   }
/*     */   
/* 110 */   int compressRLE8Data(byte[] src, int srcOffset, int numBytes, byte[] dest, boolean last) { int sp = srcOffset;int end = srcOffset + numBytes;int dp = 0;
/* 111 */     int size = 0;
/*     */     
/* 113 */     while (sp < end)
/*     */     {
/* 115 */       int left = end - sp - 1;
/* 116 */       if (left > 254)
/* 117 */         left = 254;
/* 118 */       for (int n = 0; n < left; n++) {
/* 119 */         if (src[(sp + n)] == src[(sp + n + 1)]) {
/*     */           break;
/*     */         }
/*     */       }
/* 123 */       if (n == left) {
/* 124 */         n++;
/*     */       }
/* 126 */       switch (n) {
/*     */       case 0: 
/*     */         break;
/*     */       case 2: 
/* 130 */         dest[dp] = 1;dp++;
/* 131 */         dest[dp] = src[sp];
/* 132 */         dp++;sp++;
/* 133 */         size += 2;
/*     */       
/*     */       case 1: 
/* 136 */         dest[dp] = 1;dp++;
/* 137 */         dest[dp] = src[sp];
/* 138 */         dp++;sp++;
/* 139 */         size += 2;
/* 140 */         break;
/*     */       default: 
/* 142 */         dest[dp] = 0;dp++;
/* 143 */         dest[dp] = ((byte)n);dp++;
/* 144 */         for (int i = n; i > 0; i--) {
/* 145 */           dest[dp] = src[sp];
/* 146 */           dp++;sp++;
/*     */         }
/* 148 */         size += 2 + n;
/* 149 */         if ((n & 0x1) != 0) {
/* 150 */           dest[dp] = 0;
/* 151 */           dp++;
/* 152 */           size++;
/*     */         }
/*     */         break;
/*     */       }
/*     */       
/* 157 */       left = end - sp;
/* 158 */       if (left > 0) {
/* 159 */         if (left > 255)
/* 160 */           left = 255;
/* 161 */         byte theByte = src[sp];
/* 162 */         for (n = 1; n < left; n++) {
/* 163 */           if (src[(sp + n)] != theByte)
/*     */             break;
/*     */         }
/* 166 */         dest[dp] = ((byte)n);dp++;
/* 167 */         dest[dp] = theByte;dp++;
/* 168 */         sp += n;
/* 169 */         size += 2;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 174 */     dest[dp] = 0;dp++;
/* 175 */     if (last) {
/* 176 */       dest[dp] = 1;dp++;
/*     */     } else {
/* 178 */       dest[dp] = 0;dp++;
/*     */     }
/* 180 */     size += 2;
/*     */     
/* 182 */     return size;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void convertPixelsToBGR(ImageData image, byte[] dest)
/*     */   {
/* 194 */     byte[] data = image.data;
/* 195 */     PaletteData palette = image.palette;
/* 196 */     for (int y = 0; y < image.height; y++)
/*     */     {
/* 198 */       int srcX = 0;int srcY = y;
/* 199 */       int numOfBytes = image.depth / 8;
/* 200 */       int index = y * image.bytesPerLine;
/*     */       
/* 202 */       for (int i = 0; i < image.width; i++) {
/* 203 */         int pixel = 0;
/* 204 */         switch (image.depth) {
/*     */         case 32: 
/* 206 */           pixel = (data[index] & 0xFF) << 24 | (data[(index + 1)] & 0xFF) << 16 | (data[(index + 2)] & 0xFF) << 8 | data[(index + 3)] & 0xFF;
/*     */           
/*     */ 
/*     */ 
/* 210 */           break;
/*     */         case 24: 
/* 212 */           pixel = (data[index] & 0xFF) << 16 | (data[(index + 1)] & 0xFF) << 8 | data[(index + 2)] & 0xFF;
/*     */           
/*     */ 
/* 215 */           break;
/*     */         case 16: 
/* 217 */           pixel = (data[(index + 1)] & 0xFF) << 8 | data[index] & 0xFF;
/*     */           
/* 219 */           break;
/*     */         default: 
/* 221 */           SWT.error(38);
/*     */         }
/*     */         
/* 224 */         if (image.depth == 16)
/*     */         {
/* 226 */           int r = pixel & palette.redMask;
/* 227 */           r = palette.redShift < 0 ? r >>> -palette.redShift : r << palette.redShift;
/*     */           
/*     */ 
/* 230 */           int g = pixel & palette.greenMask;
/* 231 */           g = palette.greenShift < 0 ? g >>> -palette.greenShift : g << palette.greenShift;
/*     */           
/* 233 */           g &= 0xF8;
/*     */           
/* 235 */           int b = pixel & palette.blueMask;
/* 236 */           b = palette.blueShift < 0 ? b >>> -palette.blueShift : b << palette.blueShift;
/*     */           
/*     */ 
/* 239 */           int modPixel = r << 7 | g << 2 | b >> 3;
/* 240 */           dest[index] = ((byte)(modPixel & 0xFF));
/* 241 */           dest[(index + 1)] = ((byte)(modPixel >> 8 & 0xFF));
/*     */         }
/*     */         else {
/* 244 */           int b = pixel & palette.blueMask;
/* 245 */           dest[index] = ((byte)(palette.blueShift < 0 ? b >>> -palette.blueShift : b << palette.blueShift));
/*     */           
/*     */ 
/* 248 */           int g = pixel & palette.greenMask;
/* 249 */           dest[(index + 1)] = ((byte)(palette.greenShift < 0 ? g >>> -palette.greenShift : g << palette.greenShift));
/*     */           
/*     */ 
/* 252 */           int r = pixel & palette.redMask;
/* 253 */           dest[(index + 2)] = ((byte)(palette.redShift < 0 ? r >>> -palette.redShift : r << palette.redShift));
/*     */           
/*     */ 
/* 256 */           if (numOfBytes == 4) { dest[(index + 3)] = 0;
/*     */           }
/*     */         }
/* 259 */         srcX++;
/* 260 */         if (srcX >= image.width) {
/* 261 */           srcY++;
/* 262 */           index = srcY * image.bytesPerLine;
/* 263 */           srcX = 0;
/*     */         } else {
/* 265 */           index += numOfBytes;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/* 271 */   void decompressData(byte[] src, byte[] dest, int stride, int cmp) { if (cmp == 1) {
/* 272 */       if (decompressRLE8Data(src, src.length, stride, dest, dest.length) <= 0)
/* 273 */         SWT.error(40);
/* 274 */       return;
/*     */     }
/* 276 */     if (cmp == 2) {
/* 277 */       if (decompressRLE4Data(src, src.length, stride, dest, dest.length) <= 0)
/* 278 */         SWT.error(40);
/* 279 */       return;
/*     */     }
/* 281 */     SWT.error(40);
/*     */   }
/*     */   
/* 284 */   int decompressRLE4Data(byte[] src, int numBytes, int stride, byte[] dest, int destSize) { int sp = 0;
/* 285 */     int se = numBytes;
/* 286 */     int dp = 0;
/* 287 */     int de = destSize;
/* 288 */     int x = 0;int y = 0;
/* 289 */     while (sp < se) {
/* 290 */       int len = src[sp] & 0xFF;
/* 291 */       sp++;
/* 292 */       if (len == 0) {
/* 293 */         len = src[sp] & 0xFF;
/* 294 */         sp++;
/* 295 */         switch (len) {
/*     */         case 0: 
/* 297 */           y++;
/* 298 */           x = 0;
/* 299 */           dp = y * stride;
/* 300 */           if (dp <= de) break;
/* 301 */           return -1;
/*     */         
/*     */         case 1: 
/* 304 */           return 1;
/*     */         case 2: 
/* 306 */           x += (src[sp] & 0xFF);
/* 307 */           sp++;
/* 308 */           y += (src[sp] & 0xFF);
/* 309 */           sp++;
/* 310 */           dp = y * stride + x / 2;
/* 311 */           if (dp <= de) break;
/* 312 */           return -1;
/*     */         
/*     */         default: 
/* 315 */           if ((len & 0x1) != 0)
/* 316 */             return -1;
/* 317 */           x += len;
/* 318 */           len /= 2;
/* 319 */           if (len > se - sp)
/* 320 */             return -1;
/* 321 */           if (len > de - dp)
/* 322 */             return -1;
/* 323 */           for (int i = 0; i < len; i++) {
/* 324 */             dest[dp] = src[sp];
/* 325 */             dp++;
/* 326 */             sp++;
/*     */           }
/* 328 */           if ((sp & 0x1) == 0) break;
/* 329 */           sp++;break;
/*     */         }
/*     */       }
/*     */       else {
/* 333 */         if ((len & 0x1) != 0)
/* 334 */           return -1;
/* 335 */         x += len;
/* 336 */         len /= 2;
/* 337 */         byte theByte = src[sp];
/* 338 */         sp++;
/* 339 */         if (len > de - dp)
/* 340 */           return -1;
/* 341 */         for (int i = 0; i < len; i++) {
/* 342 */           dest[dp] = theByte;
/* 343 */           dp++;
/*     */         }
/*     */       }
/*     */     }
/* 347 */     return 1;
/*     */   }
/*     */   
/* 350 */   int decompressRLE8Data(byte[] src, int numBytes, int stride, byte[] dest, int destSize) { int sp = 0;
/* 351 */     int se = numBytes;
/* 352 */     int dp = 0;
/* 353 */     int de = destSize;
/* 354 */     int x = 0;int y = 0;
/* 355 */     while (sp < se) {
/* 356 */       int len = src[sp] & 0xFF;
/* 357 */       sp++;
/* 358 */       if (len == 0) {
/* 359 */         len = src[sp] & 0xFF;
/* 360 */         sp++;
/* 361 */         switch (len) {
/*     */         case 0: 
/* 363 */           y++;
/* 364 */           x = 0;
/* 365 */           dp = y * stride;
/* 366 */           if (dp <= de) break;
/* 367 */           return -1;
/*     */         
/*     */         case 1: 
/* 370 */           return 1;
/*     */         case 2: 
/* 372 */           x += (src[sp] & 0xFF);
/* 373 */           sp++;
/* 374 */           y += (src[sp] & 0xFF);
/* 375 */           sp++;
/* 376 */           dp = y * stride + x;
/* 377 */           if (dp <= de) break;
/* 378 */           return -1;
/*     */         
/*     */         default: 
/* 381 */           if (len > se - sp)
/* 382 */             return -1;
/* 383 */           if (len > de - dp)
/* 384 */             return -1;
/* 385 */           for (int i = 0; i < len; i++) {
/* 386 */             dest[dp] = src[sp];
/* 387 */             dp++;
/* 388 */             sp++;
/*     */           }
/* 390 */           if ((sp & 0x1) != 0)
/* 391 */             sp++;
/* 392 */           x += len;
/* 393 */           break;
/*     */         }
/*     */       } else {
/* 396 */         byte theByte = src[sp];
/* 397 */         sp++;
/* 398 */         if (len > de - dp)
/* 399 */           return -1;
/* 400 */         for (int i = 0; i < len; i++) {
/* 401 */           dest[dp] = theByte;
/* 402 */           dp++;
/*     */         }
/* 404 */         x += len;
/*     */       }
/*     */     }
/* 407 */     return 1;
/*     */   }
/*     */   
/*     */   boolean isFileFormat(LEDataInputStream stream) {
/*     */     try {
/* 412 */       byte[] header = new byte[18];
/* 413 */       stream.read(header);
/* 414 */       stream.unread(header);
/* 415 */       int infoHeaderSize = header[14] & 0xFF | (header[15] & 0xFF) << 8 | (header[16] & 0xFF) << 16 | (header[17] & 0xFF) << 24;
/* 416 */       return (header[0] == 66) && (header[1] == 77) && (infoHeaderSize >= 40);
/*     */     } catch (Exception e) {}
/* 418 */     return false;
/*     */   }
/*     */   
/*     */   boolean isPaletteBMP(PaletteData pal, int depth) {
/* 422 */     switch (depth) {
/*     */     case 32: 
/* 424 */       if ((pal.redMask == 65280) && (pal.greenMask == 16711680) && (pal.blueMask == -16777216)) return true;
/* 425 */       return false;
/*     */     case 24: 
/* 427 */       if ((pal.redMask == 255) && (pal.greenMask == 65280) && (pal.blueMask == 16711680)) return true;
/* 428 */       return false;
/*     */     case 16: 
/* 430 */       if ((pal.redMask == 31744) && (pal.greenMask == 992) && (pal.blueMask == 31)) return true;
/* 431 */       return false;
/*     */     }
/* 433 */     return true;
/*     */   }
/*     */   
/*     */   byte[] loadData(byte[] infoHeader) {
/* 437 */     int width = infoHeader[4] & 0xFF | (infoHeader[5] & 0xFF) << 8 | (infoHeader[6] & 0xFF) << 16 | (infoHeader[7] & 0xFF) << 24;
/* 438 */     int height = infoHeader[8] & 0xFF | (infoHeader[9] & 0xFF) << 8 | (infoHeader[10] & 0xFF) << 16 | (infoHeader[11] & 0xFF) << 24;
/* 439 */     int bitCount = infoHeader[14] & 0xFF | (infoHeader[15] & 0xFF) << 8;
/* 440 */     int stride = (width * bitCount + 7) / 8;
/* 441 */     stride = (stride + 3) / 4 * 4;
/* 442 */     byte[] data = loadData(infoHeader, stride);
/* 443 */     flipScanLines(data, stride, height);
/* 444 */     return data;
/*     */   }
/*     */   
/* 447 */   byte[] loadData(byte[] infoHeader, int stride) { int height = infoHeader[8] & 0xFF | (infoHeader[9] & 0xFF) << 8 | (infoHeader[10] & 0xFF) << 16 | (infoHeader[11] & 0xFF) << 24;
/* 448 */     if (height < 0) height = -height;
/* 449 */     int dataSize = height * stride;
/* 450 */     byte[] data = new byte[dataSize];
/* 451 */     int cmp = infoHeader[16] & 0xFF | (infoHeader[17] & 0xFF) << 8 | (infoHeader[18] & 0xFF) << 16 | (infoHeader[19] & 0xFF) << 24;
/* 452 */     if ((cmp == 0) || (cmp == 3)) {
/*     */       try {
/* 454 */         if (this.inputStream.read(data) != dataSize)
/* 455 */           SWT.error(40);
/*     */       } catch (IOException e) {
/* 457 */         SWT.error(39, e);
/*     */       }
/*     */     } else {
/* 460 */       int compressedSize = infoHeader[20] & 0xFF | (infoHeader[21] & 0xFF) << 8 | (infoHeader[22] & 0xFF) << 16 | (infoHeader[23] & 0xFF) << 24;
/* 461 */       byte[] compressed = new byte[compressedSize];
/*     */       try {
/* 463 */         if (this.inputStream.read(compressed) != compressedSize)
/* 464 */           SWT.error(40);
/*     */       } catch (IOException e) {
/* 466 */         SWT.error(39, e);
/*     */       }
/* 468 */       decompressData(compressed, data, stride, cmp);
/*     */     }
/* 470 */     return data;
/*     */   }
/*     */   
/* 473 */   int[] loadFileHeader() { int[] header = new int[5];
/*     */     try {
/* 475 */       header[0] = this.inputStream.readShort();
/* 476 */       header[1] = this.inputStream.readInt();
/* 477 */       header[2] = this.inputStream.readShort();
/* 478 */       header[3] = this.inputStream.readShort();
/* 479 */       header[4] = this.inputStream.readInt();
/*     */     } catch (IOException e) {
/* 481 */       SWT.error(39, e);
/*     */     }
/* 483 */     if (header[0] != 19778)
/* 484 */       SWT.error(40);
/* 485 */     return header;
/*     */   }
/*     */   
/*     */   ImageData[] loadFromByteStream() {
/* 489 */     int[] fileHeader = loadFileHeader();
/* 490 */     byte[] infoHeader = new byte[40];
/*     */     try {
/* 492 */       this.inputStream.read(infoHeader);
/*     */     } catch (Exception e) {
/* 494 */       SWT.error(39, e);
/*     */     }
/* 496 */     int width = infoHeader[4] & 0xFF | (infoHeader[5] & 0xFF) << 8 | (infoHeader[6] & 0xFF) << 16 | (infoHeader[7] & 0xFF) << 24;
/* 497 */     int height = infoHeader[8] & 0xFF | (infoHeader[9] & 0xFF) << 8 | (infoHeader[10] & 0xFF) << 16 | (infoHeader[11] & 0xFF) << 24;
/* 498 */     if (height < 0) height = -height;
/* 499 */     int bitCount = infoHeader[14] & 0xFF | (infoHeader[15] & 0xFF) << 8;
/* 500 */     this.compression = (infoHeader[16] & 0xFF | (infoHeader[17] & 0xFF) << 8 | (infoHeader[18] & 0xFF) << 16 | (infoHeader[19] & 0xFF) << 24);
/* 501 */     PaletteData palette = loadPalette(infoHeader);
/* 502 */     if (this.inputStream.getPosition() < fileHeader[4]) {
/*     */       try
/*     */       {
/* 505 */         this.inputStream.skip(fileHeader[4] - this.inputStream.getPosition());
/*     */       } catch (IOException e) {
/* 507 */         SWT.error(39, e);
/*     */       }
/*     */     }
/* 510 */     byte[] data = loadData(infoHeader);
/* 511 */     this.importantColors = (infoHeader[36] & 0xFF | (infoHeader[37] & 0xFF) << 8 | (infoHeader[38] & 0xFF) << 16 | (infoHeader[39] & 0xFF) << 24);
/* 512 */     int xPelsPerMeter = infoHeader[24] & 0xFF | (infoHeader[25] & 0xFF) << 8 | (infoHeader[26] & 0xFF) << 16 | (infoHeader[27] & 0xFF) << 24;
/* 513 */     int yPelsPerMeter = infoHeader[28] & 0xFF | (infoHeader[29] & 0xFF) << 8 | (infoHeader[30] & 0xFF) << 16 | (infoHeader[31] & 0xFF) << 24;
/* 514 */     this.pelsPerMeter = new Point(xPelsPerMeter, yPelsPerMeter);
/* 515 */     int type = (this.compression == 1) || (this.compression == 2) ? 1 : 0;
/* 516 */     return new ImageData[] {
/* 517 */       ImageData.internal_new(width, height, bitCount, palette, 4, data, 0, null, null, -1, -1, type, 0, 0, 0, 0) };
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   PaletteData loadPalette(byte[] infoHeader)
/*     */   {
/* 537 */     int depth = infoHeader[14] & 0xFF | (infoHeader[15] & 0xFF) << 8;
/* 538 */     if (depth <= 8) {
/* 539 */       int numColors = infoHeader[32] & 0xFF | (infoHeader[33] & 0xFF) << 8 | (infoHeader[34] & 0xFF) << 16 | (infoHeader[35] & 0xFF) << 24;
/* 540 */       if (numColors == 0) {
/* 541 */         numColors = 1 << depth;
/*     */       }
/* 543 */       else if (numColors > 256) {
/* 544 */         numColors = 256;
/*     */       }
/* 546 */       byte[] buf = new byte[numColors * 4];
/*     */       try {
/* 548 */         if (this.inputStream.read(buf) != buf.length)
/* 549 */           SWT.error(40);
/*     */       } catch (IOException e) {
/* 551 */         SWT.error(39, e);
/*     */       }
/* 553 */       return paletteFromBytes(buf, numColors);
/*     */     }
/* 555 */     if (depth == 16) {
/* 556 */       if (this.compression == 3) {
/*     */         try {
/* 558 */           return new PaletteData(this.inputStream.readInt(), this.inputStream.readInt(), this.inputStream.readInt());
/*     */         } catch (IOException e) {
/* 560 */           SWT.error(39, e);
/*     */         }
/*     */       }
/* 563 */       return new PaletteData(31744, 992, 31);
/*     */     }
/* 565 */     if (depth == 24) return new PaletteData(255, 65280, 16711680);
/* 566 */     if (this.compression == 3) {
/*     */       try {
/* 568 */         return new PaletteData(this.inputStream.readInt(), this.inputStream.readInt(), this.inputStream.readInt());
/*     */       } catch (IOException e) {
/* 570 */         SWT.error(39, e);
/*     */       }
/*     */     }
/* 573 */     return new PaletteData(65280, 16711680, -16777216);
/*     */   }
/*     */   
/* 576 */   PaletteData paletteFromBytes(byte[] bytes, int numColors) { int bytesOffset = 0;
/* 577 */     RGB[] colors = new RGB[numColors];
/* 578 */     for (int i = 0; i < numColors; i++) {
/* 579 */       colors[i] = new RGB(bytes[(bytesOffset + 2)] & 0xFF, bytes[(bytesOffset + 1)] & 0xFF, bytes[bytesOffset] & 0xFF);
/*     */       
/*     */ 
/* 582 */       bytesOffset += 4;
/*     */     }
/* 584 */     return new PaletteData(colors);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   static byte[] paletteToBytes(PaletteData pal)
/*     */   {
/* 591 */     int n = pal.colors.length < 256 ? pal.colors.length : pal.colors == null ? 0 : 256;
/* 592 */     byte[] bytes = new byte[n * 4];
/* 593 */     int offset = 0;
/* 594 */     for (int i = 0; i < n; i++) {
/* 595 */       RGB col = pal.colors[i];
/* 596 */       bytes[offset] = ((byte)col.blue);
/* 597 */       bytes[(offset + 1)] = ((byte)col.green);
/* 598 */       bytes[(offset + 2)] = ((byte)col.red);
/* 599 */       offset += 4;
/*     */     }
/* 601 */     return bytes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   int unloadData(ImageData image, byte[] data, OutputStream out, int comp)
/*     */   {
/* 610 */     int totalSize = 0;
/*     */     try {
/* 612 */       if (comp == 0)
/* 613 */         return unloadDataNoCompression(image, data, out);
/* 614 */       int bpl = (image.width * image.depth + 7) / 8;
/* 615 */       int bmpBpl = (bpl + 3) / 4 * 4;
/* 616 */       int imageBpl = image.bytesPerLine;
/*     */       
/* 618 */       byte[] buf = new byte[bmpBpl * 2];
/* 619 */       int srcOffset = imageBpl * (image.height - 1);
/* 620 */       if (data == null) data = image.data;
/* 621 */       totalSize = 0;
/* 622 */       byte[] buf2 = new byte[32768];
/* 623 */       int buf2Offset = 0;
/* 624 */       for (int y = image.height - 1; y >= 0; y--) {
/* 625 */         int lineSize = compress(comp, data, srcOffset, bpl, buf, y == 0);
/* 626 */         if (buf2Offset + lineSize > buf2.length) {
/* 627 */           out.write(buf2, 0, buf2Offset);
/* 628 */           buf2Offset = 0;
/*     */         }
/* 630 */         System.arraycopy(buf, 0, buf2, buf2Offset, lineSize);
/* 631 */         buf2Offset += lineSize;
/* 632 */         totalSize += lineSize;
/* 633 */         srcOffset -= imageBpl;
/*     */       }
/* 635 */       if (buf2Offset > 0)
/* 636 */         out.write(buf2, 0, buf2Offset);
/*     */     } catch (IOException e) {
/* 638 */       SWT.error(39, e);
/*     */     }
/* 640 */     return totalSize;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   int unloadDataNoCompression(ImageData image, byte[] data, OutputStream out)
/*     */   {
/* 649 */     int bmpBpl = 0;
/*     */     try {
/* 651 */       int bpl = (image.width * image.depth + 7) / 8;
/* 652 */       bmpBpl = (bpl + 3) / 4 * 4;
/* 653 */       int linesPerBuf = 32678 / bmpBpl;
/* 654 */       byte[] buf = new byte[linesPerBuf * bmpBpl];
/* 655 */       if (data == null) data = image.data;
/* 656 */       int imageBpl = image.bytesPerLine;
/* 657 */       int dataIndex = imageBpl * (image.height - 1);
/* 658 */       if (image.depth == 16) {
/* 659 */         for (int y = 0; y < image.height; y += linesPerBuf) {
/* 660 */           int count = image.height - y;
/* 661 */           if (linesPerBuf < count) count = linesPerBuf;
/* 662 */           int bufOffset = 0;
/* 663 */           for (int i = 0; i < count; i++) {
/* 664 */             for (int wIndex = 0; wIndex < bpl; wIndex += 2) {
/* 665 */               buf[(bufOffset + wIndex + 1)] = data[(dataIndex + wIndex + 1)];
/* 666 */               buf[(bufOffset + wIndex)] = data[(dataIndex + wIndex)];
/*     */             }
/* 668 */             bufOffset += bmpBpl;
/* 669 */             dataIndex -= imageBpl;
/*     */           }
/* 671 */           out.write(buf, 0, bufOffset);
/*     */         }
/*     */       } else {
/* 674 */         for (int y = 0; y < image.height; y += linesPerBuf) {
/* 675 */           int tmp = image.height - y;
/* 676 */           int count = tmp < linesPerBuf ? tmp : linesPerBuf;
/* 677 */           int bufOffset = 0;
/* 678 */           for (int i = 0; i < count; i++) {
/* 679 */             System.arraycopy(data, dataIndex, buf, bufOffset, bpl);
/* 680 */             bufOffset += bmpBpl;
/* 681 */             dataIndex -= imageBpl;
/*     */           }
/* 683 */           out.write(buf, 0, bufOffset);
/*     */         }
/*     */       }
/*     */     } catch (IOException e) {
/* 687 */       SWT.error(39, e);
/*     */     }
/* 689 */     return bmpBpl * image.height;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   void unloadIntoByteStream(ImageLoader loader)
/*     */   {
/* 697 */     ImageData image = loader.data[0];
/*     */     
/*     */ 
/* 700 */     if ((image.depth != 1) && (image.depth != 4) && (image.depth != 8) && (image.depth != 16) && (image.depth != 24) && (image.depth != 32))
/*     */     {
/* 702 */       SWT.error(38); }
/* 703 */     int comp = this.compression;
/* 704 */     if ((comp != 0) && ((comp != 1) || (image.depth != 8)) && ((comp != 2) || (image.depth != 4)))
/*     */     {
/* 706 */       SWT.error(40); }
/* 707 */     PaletteData pal = image.palette;
/* 708 */     byte[] rgbs; int numCols; byte[] rgbs; if ((image.depth == 16) || (image.depth == 24) || (image.depth == 32)) {
/* 709 */       if (!pal.isDirect)
/* 710 */         SWT.error(40);
/* 711 */       int numCols = 0;
/* 712 */       rgbs = null;
/*     */     } else {
/* 714 */       if (pal.isDirect)
/* 715 */         SWT.error(40);
/* 716 */       numCols = pal.colors.length;
/* 717 */       rgbs = paletteToBytes(pal);
/*     */     }
/*     */     
/* 720 */     int headersSize = 54;
/* 721 */     int[] fileHeader = new int[5];
/* 722 */     fileHeader[0] = 19778;
/* 723 */     fileHeader[1] = 0;
/* 724 */     fileHeader[2] = 0;
/* 725 */     fileHeader[3] = 0;
/* 726 */     fileHeader[4] = headersSize;
/* 727 */     if (rgbs != null) {
/* 728 */       fileHeader[4] += rgbs.length;
/*     */     }
/*     */     
/* 731 */     byte[] iData = null;
/*     */     
/* 733 */     if ((pal.isDirect) && (!isPaletteBMP(pal, image.depth)))
/*     */     {
/* 735 */       iData = new byte[image.data.length];
/* 736 */       convertPixelsToBGR(image, iData);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 741 */     ByteArrayOutputStream out = new ByteArrayOutputStream();
/* 742 */     unloadData(image, iData, out, comp);
/* 743 */     byte[] data = out.toByteArray();
/*     */     
/*     */ 
/* 746 */     fileHeader[1] = (fileHeader[4] + data.length);
/*     */     
/*     */     try
/*     */     {
/* 750 */       this.outputStream.writeShort(fileHeader[0]);
/* 751 */       this.outputStream.writeInt(fileHeader[1]);
/* 752 */       this.outputStream.writeShort(fileHeader[2]);
/* 753 */       this.outputStream.writeShort(fileHeader[3]);
/* 754 */       this.outputStream.writeInt(fileHeader[4]);
/*     */     } catch (IOException e) {
/* 756 */       SWT.error(39, e);
/*     */     }
/*     */     try {
/* 759 */       this.outputStream.writeInt(40);
/* 760 */       this.outputStream.writeInt(image.width);
/* 761 */       this.outputStream.writeInt(image.height);
/* 762 */       this.outputStream.writeShort(1);
/* 763 */       this.outputStream.writeShort((short)image.depth);
/* 764 */       this.outputStream.writeInt(comp);
/* 765 */       this.outputStream.writeInt(data.length);
/* 766 */       this.outputStream.writeInt(this.pelsPerMeter.x);
/* 767 */       this.outputStream.writeInt(this.pelsPerMeter.y);
/* 768 */       this.outputStream.writeInt(numCols);
/* 769 */       this.outputStream.writeInt(this.importantColors);
/*     */     } catch (IOException e) {
/* 771 */       SWT.error(39, e);
/*     */     }
/*     */     
/*     */ 
/* 775 */     if (numCols > 0) {
/*     */       try {
/* 777 */         this.outputStream.write(rgbs);
/*     */       } catch (IOException e) {
/* 779 */         SWT.error(39, e);
/*     */       }
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 785 */       this.outputStream.write(data);
/*     */     } catch (IOException e) {
/* 787 */       SWT.error(39, e);
/*     */     }
/*     */   }
/*     */   
/* 791 */   void flipScanLines(byte[] data, int stride, int height) { int i1 = 0;
/* 792 */     int i2 = (height - 1) * stride;
/* 793 */     for (int i = 0; i < height / 2; i++) {
/* 794 */       for (int index = 0; index < stride; index++) {
/* 795 */         byte b = data[(index + i1)];
/* 796 */         data[(index + i1)] = data[(index + i2)];
/* 797 */         data[(index + i2)] = b;
/*     */       }
/* 799 */       i1 += stride;
/* 800 */       i2 -= stride;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/internal/image/WinBMPFileFormat.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */