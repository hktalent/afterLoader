/*     */ package org.eclipse.swt.custom;
/*     */ 
/*     */ import org.eclipse.swt.graphics.Point;
/*     */ import org.eclipse.swt.graphics.Rectangle;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.swt.widgets.Control;
/*     */ import org.eclipse.swt.widgets.Layout;
/*     */ import org.eclipse.swt.widgets.Sash;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SashFormLayout
/*     */   extends Layout
/*     */ {
/*     */   protected Point computeSize(Composite composite, int wHint, int hHint, boolean flushCache)
/*     */   {
/*  25 */     SashForm sashForm = (SashForm)composite;
/*  26 */     Control[] cArray = sashForm.getControls(true);
/*  27 */     int width = 0;
/*  28 */     int height = 0;
/*  29 */     if (cArray.length == 0) {
/*  30 */       if (wHint != -1) width = wHint;
/*  31 */       if (hHint != -1) height = hHint;
/*  32 */       return new Point(width, height);
/*     */     }
/*     */     
/*  35 */     boolean vertical = sashForm.getOrientation() == 512;
/*  36 */     int maxIndex = 0;
/*  37 */     int maxValue = 0;
/*  38 */     for (int i = 0; i < cArray.length; i++) {
/*  39 */       if (vertical) {
/*  40 */         Point size = cArray[i].computeSize(wHint, -1, flushCache);
/*  41 */         if (size.y > maxValue) {
/*  42 */           maxIndex = i;
/*  43 */           maxValue = size.y;
/*     */         }
/*  45 */         width = Math.max(width, size.x);
/*     */       } else {
/*  47 */         Point size = cArray[i].computeSize(-1, hHint, flushCache);
/*  48 */         if (size.x > maxValue) {
/*  49 */           maxIndex = i;
/*  50 */           maxValue = size.x;
/*     */         }
/*  52 */         height = Math.max(height, size.y);
/*     */       }
/*     */     }
/*     */     
/*  56 */     long[] ratios = new long[cArray.length];
/*  57 */     long total = 0L;
/*  58 */     for (int i = 0; i < cArray.length; i++) {
/*  59 */       Object data = cArray[i].getLayoutData();
/*  60 */       if ((data != null) && ((data instanceof SashFormData))) {
/*  61 */         ratios[i] = ((SashFormData)data).weight;
/*     */       } else {
/*  63 */         data = new SashFormData();
/*  64 */         cArray[i].setLayoutData(data);
/*  65 */         ((SashFormData)data).weight = (ratios[i] = 13108L);
/*     */       }
/*     */       
/*  68 */       total += ratios[i];
/*     */     }
/*  70 */     if (ratios[maxIndex] > 0L) {
/*  71 */       int sashwidth = sashForm.sashes.length > 0 ? sashForm.SASH_WIDTH + sashForm.sashes[0].getBorderWidth() * 2 : sashForm.SASH_WIDTH;
/*  72 */       if (vertical) {
/*  73 */         height += (int)(total * maxValue / ratios[maxIndex]) + (cArray.length - 1) * sashwidth;
/*     */       } else {
/*  75 */         width += (int)(total * maxValue / ratios[maxIndex]) + (cArray.length - 1) * sashwidth;
/*     */       }
/*     */     }
/*  78 */     width += sashForm.getBorderWidth() * 2;
/*  79 */     height += sashForm.getBorderWidth() * 2;
/*  80 */     if (wHint != -1) width = wHint;
/*  81 */     if (hHint != -1) height = hHint;
/*  82 */     return new Point(width, height);
/*     */   }
/*     */   
/*     */   protected boolean flushCache(Control control)
/*     */   {
/*  87 */     return true;
/*     */   }
/*     */   
/*     */   protected void layout(Composite composite, boolean flushCache)
/*     */   {
/*  92 */     SashForm sashForm = (SashForm)composite;
/*  93 */     Rectangle area = sashForm.getClientArea();
/*  94 */     if ((area.width <= 1) || (area.height <= 1)) { return;
/*     */     }
/*  96 */     Control[] newControls = sashForm.getControls(true);
/*  97 */     if ((sashForm.controls.length == 0) && (newControls.length == 0)) return;
/*  98 */     sashForm.controls = newControls;
/*     */     
/* 100 */     Control[] controls = sashForm.controls;
/*     */     
/* 102 */     if ((sashForm.maxControl != null) && (!sashForm.maxControl.isDisposed())) {
/* 103 */       for (int i = 0; i < controls.length; i++) {
/* 104 */         if (controls[i] != sashForm.maxControl) {
/* 105 */           controls[i].setBounds(65336, 65336, 0, 0);
/*     */         } else {
/* 107 */           controls[i].setBounds(area);
/*     */         }
/*     */       }
/* 110 */       return;
/*     */     }
/*     */     
/*     */ 
/* 114 */     if (sashForm.sashes.length < controls.length - 1) {
/* 115 */       Sash[] newSashes = new Sash[controls.length - 1];
/* 116 */       System.arraycopy(sashForm.sashes, 0, newSashes, 0, sashForm.sashes.length);
/* 117 */       for (int i = sashForm.sashes.length; i < newSashes.length; i++) {
/* 118 */         newSashes[i] = sashForm.createSash();
/*     */       }
/* 120 */       sashForm.sashes = newSashes;
/*     */     }
/* 122 */     if (sashForm.sashes.length > controls.length - 1) {
/* 123 */       if (controls.length == 0) {
/* 124 */         for (int i = 0; i < sashForm.sashes.length; i++) {
/* 125 */           sashForm.sashes[i].dispose();
/*     */         }
/* 127 */         sashForm.sashes = new Sash[0];
/*     */       } else {
/* 129 */         Sash[] newSashes = new Sash[controls.length - 1];
/* 130 */         System.arraycopy(sashForm.sashes, 0, newSashes, 0, newSashes.length);
/* 131 */         for (int i = controls.length - 1; i < sashForm.sashes.length; i++) {
/* 132 */           sashForm.sashes[i].dispose();
/*     */         }
/* 134 */         sashForm.sashes = newSashes;
/*     */       }
/*     */     }
/* 137 */     if (controls.length == 0) return;
/* 138 */     Sash[] sashes = sashForm.sashes;
/*     */     
/* 140 */     long[] ratios = new long[controls.length];
/* 141 */     long total = 0L;
/* 142 */     for (int i = 0; i < controls.length; i++) {
/* 143 */       Object data = controls[i].getLayoutData();
/* 144 */       if ((data != null) && ((data instanceof SashFormData))) {
/* 145 */         ratios[i] = ((SashFormData)data).weight;
/*     */       } else {
/* 147 */         data = new SashFormData();
/* 148 */         controls[i].setLayoutData(data);
/* 149 */         ((SashFormData)data).weight = (ratios[i] = 13108L);
/*     */       }
/*     */       
/* 152 */       total += ratios[i];
/*     */     }
/*     */     
/* 155 */     int sashwidth = sashes.length > 0 ? sashForm.SASH_WIDTH + sashes[0].getBorderWidth() * 2 : sashForm.SASH_WIDTH;
/* 156 */     if (sashForm.getOrientation() == 256) {
/* 157 */       int width = (int)(ratios[0] * (area.width - sashes.length * sashwidth) / total);
/* 158 */       int x = area.x;
/* 159 */       controls[0].setBounds(x, area.y, width, area.height);
/* 160 */       x += width;
/* 161 */       for (int i = 1; i < controls.length - 1; i++) {
/* 162 */         sashes[(i - 1)].setBounds(x, area.y, sashwidth, area.height);
/* 163 */         x += sashwidth;
/* 164 */         width = (int)(ratios[i] * (area.width - sashes.length * sashwidth) / total);
/* 165 */         controls[i].setBounds(x, area.y, width, area.height);
/* 166 */         x += width;
/*     */       }
/* 168 */       if (controls.length > 1) {
/* 169 */         sashes[(sashes.length - 1)].setBounds(x, area.y, sashwidth, area.height);
/* 170 */         x += sashwidth;
/* 171 */         width = area.width - x;
/* 172 */         controls[(controls.length - 1)].setBounds(x, area.y, width, area.height);
/*     */       }
/*     */     } else {
/* 175 */       int height = (int)(ratios[0] * (area.height - sashes.length * sashwidth) / total);
/* 176 */       int y = area.y;
/* 177 */       controls[0].setBounds(area.x, y, area.width, height);
/* 178 */       y += height;
/* 179 */       for (int i = 1; i < controls.length - 1; i++) {
/* 180 */         sashes[(i - 1)].setBounds(area.x, y, area.width, sashwidth);
/* 181 */         y += sashwidth;
/* 182 */         height = (int)(ratios[i] * (area.height - sashes.length * sashwidth) / total);
/* 183 */         controls[i].setBounds(area.x, y, area.width, height);
/* 184 */         y += height;
/*     */       }
/* 186 */       if (controls.length > 1) {
/* 187 */         sashes[(sashes.length - 1)].setBounds(area.x, y, area.width, sashwidth);
/* 188 */         y += sashwidth;
/* 189 */         height = area.height - y;
/* 190 */         controls[(controls.length - 1)].setBounds(area.x, y, area.width, height);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/custom/SashFormLayout.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */