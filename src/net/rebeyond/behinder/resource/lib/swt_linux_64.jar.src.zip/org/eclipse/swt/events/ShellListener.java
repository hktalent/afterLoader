/*     */ package org.eclipse.swt.events;
/*     */ 
/*     */ import java.util.function.Consumer;
/*     */ import org.eclipse.swt.internal.SWTEventListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract interface ShellListener
/*     */   extends SWTEventListener
/*     */ {
/*     */   public abstract void shellActivated(ShellEvent paramShellEvent);
/*     */   
/*     */   public abstract void shellClosed(ShellEvent paramShellEvent);
/*     */   
/*     */   public abstract void shellDeactivated(ShellEvent paramShellEvent);
/*     */   
/*     */   public abstract void shellDeiconified(ShellEvent paramShellEvent);
/*     */   
/*     */   public abstract void shellIconified(ShellEvent paramShellEvent);
/*     */   
/*     */   public static ShellListener shellActivatedAdapter(Consumer<ShellEvent> c)
/*     */   {
/*  79 */     new ShellAdapter()
/*     */     {
/*     */       public void shellActivated(ShellEvent e) {
/*  82 */         this.val$c.accept(e);
/*     */       }
/*     */     };
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ShellListener shellClosedAdapter(Consumer<ShellEvent> c)
/*     */   {
/*  96 */     new ShellAdapter()
/*     */     {
/*     */       public void shellClosed(ShellEvent e) {
/*  99 */         this.val$c.accept(e);
/*     */       }
/*     */     };
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ShellListener shellDeactivatedAdapter(Consumer<ShellEvent> c)
/*     */   {
/* 113 */     new ShellAdapter()
/*     */     {
/*     */       public void shellDeactivated(ShellEvent e) {
/* 116 */         this.val$c.accept(e);
/*     */       }
/*     */     };
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ShellListener shellDeiconifiedAdapter(Consumer<ShellEvent> c)
/*     */   {
/* 130 */     new ShellAdapter()
/*     */     {
/*     */       public void shellDeiconified(ShellEvent e) {
/* 133 */         this.val$c.accept(e);
/*     */       }
/*     */     };
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ShellListener shellIconifiedAdapter(Consumer<ShellEvent> c)
/*     */   {
/* 147 */     new ShellAdapter()
/*     */     {
/*     */       public void shellIconified(ShellEvent e) {
/* 150 */         this.val$c.accept(e);
/*     */       }
/*     */     };
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/events/ShellListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */