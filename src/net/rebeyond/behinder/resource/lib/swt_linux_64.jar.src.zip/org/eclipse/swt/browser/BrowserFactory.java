/*    */ package org.eclipse.swt.browser;
/*    */ 
/*    */ import org.eclipse.swt.internal.gtk.OS;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class BrowserFactory
/*    */ {
/*    */   WebBrowser createWebBrowser(int style)
/*    */   {
/* 18 */     if (OS.IsWin32) return null;
/* 19 */     boolean webkitInstalled = WebKit.IsInstalled();
/* 20 */     if (!webkitInstalled) { return null;
/*    */     }
/* 22 */     return new WebKit();
/*    */   }
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/browser/BrowserFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */