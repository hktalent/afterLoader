/*     */ package org.eclipse.swt.graphics;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class FontMetrics
/*     */ {
/*     */   int ascentInPoints;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   int descentInPoints;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   int averageCharWidthInPoints;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object object)
/*     */   {
/*  41 */     if (object == this) return true;
/*  42 */     if (!(object instanceof FontMetrics)) return false;
/*  43 */     FontMetrics metrics = (FontMetrics)object;
/*  44 */     return (this.ascentInPoints == metrics.ascentInPoints) && (this.descentInPoints == metrics.descentInPoints) && (this.averageCharWidthInPoints == metrics.averageCharWidthInPoints);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getAscent()
/*     */   {
/*  57 */     return this.ascentInPoints;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public double getAverageCharacterWidth()
/*     */   {
/*  68 */     return getAverageCharWidth();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @Deprecated
/*     */   public int getAverageCharWidth()
/*     */   {
/*  80 */     return this.averageCharWidthInPoints;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getDescent()
/*     */   {
/*  92 */     return this.descentInPoints;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getHeight()
/*     */   {
/* 107 */     return this.ascentInPoints + this.descentInPoints;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getLeading()
/*     */   {
/* 118 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static FontMetrics gtk_new(int ascentInPoints, int descentInPoints, int averageCharWidthInPoints)
/*     */   {
/* 134 */     FontMetrics fontMetrics = new FontMetrics();
/* 135 */     fontMetrics.ascentInPoints = ascentInPoints;
/* 136 */     fontMetrics.descentInPoints = descentInPoints;
/* 137 */     fontMetrics.averageCharWidthInPoints = averageCharWidthInPoints;
/* 138 */     return fontMetrics;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 153 */     return this.ascentInPoints ^ this.descentInPoints ^ this.averageCharWidthInPoints;
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/graphics/FontMetrics.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */