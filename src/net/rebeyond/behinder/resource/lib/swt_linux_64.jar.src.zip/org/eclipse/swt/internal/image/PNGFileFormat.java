/*     */ package org.eclipse.swt.internal.image;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.zip.InflaterInputStream;
/*     */ import org.eclipse.swt.SWT;
/*     */ import org.eclipse.swt.graphics.ImageData;
/*     */ import org.eclipse.swt.graphics.ImageLoader;
/*     */ import org.eclipse.swt.graphics.ImageLoaderEvent;
/*     */ import org.eclipse.swt.graphics.PaletteData;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class PNGFileFormat
/*     */   extends FileFormat
/*     */ {
/*     */   static final int SIGNATURE_LENGTH = 8;
/*     */   static final int PRIME = 65521;
/*     */   PngIhdrChunk headerChunk;
/*     */   PngPlteChunk paletteChunk;
/*     */   ImageData imageData;
/*     */   byte[] data;
/*     */   byte[] alphaPalette;
/*     */   byte headerByte1;
/*     */   byte headerByte2;
/*     */   int adler;
/*     */   
/*     */   void readSignature()
/*     */     throws IOException
/*     */   {
/*  37 */     byte[] signature = new byte[8];
/*  38 */     this.inputStream.read(signature);
/*     */   }
/*     */   
/*     */ 
/*     */   ImageData[] loadFromByteStream()
/*     */   {
/*     */     try
/*     */     {
/*  46 */       readSignature();
/*  47 */       PngChunkReader chunkReader = new PngChunkReader(this.inputStream);
/*  48 */       this.headerChunk = chunkReader.getIhdrChunk();
/*  49 */       int width = this.headerChunk.getWidth();int height = this.headerChunk.getHeight();
/*  50 */       if ((width <= 0) || (height <= 0)) SWT.error(40);
/*  51 */       int imageSize = getAlignedBytesPerRow() * height;
/*  52 */       this.data = new byte[imageSize];
/*  53 */       this.imageData = ImageData.internal_new(width, height, this.headerChunk
/*     */       
/*     */ 
/*  56 */         .getSwtBitsPerPixel(), new PaletteData(0, 0, 0), 4, this.data, 0, null, null, -1, -1, 5, 0, 0, 0, 0);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  71 */       if (this.headerChunk.usesDirectColor()) {
/*  72 */         this.imageData.palette = this.headerChunk.getPaletteData();
/*     */       }
/*     */       
/*     */ 
/*  76 */       while (chunkReader.hasMoreChunks()) {
/*  77 */         readNextChunk(chunkReader);
/*     */       }
/*     */       
/*  80 */       return new ImageData[] { this.imageData };
/*     */     } catch (IOException e) {
/*  82 */       SWT.error(40); }
/*  83 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   void readNextChunk(PngChunkReader chunkReader)
/*     */     throws IOException
/*     */   {
/*  91 */     PngChunk chunk = chunkReader.readNextChunk();
/*  92 */     switch (chunk.getChunkType()) {
/*     */     case 3: 
/*     */       break;
/*     */     case 1: 
/*  96 */       if (!this.headerChunk.usesDirectColor()) {
/*  97 */         this.paletteChunk = ((PngPlteChunk)chunk);
/*  98 */         this.imageData.palette = this.paletteChunk.getPaletteData();
/*     */       }
/*     */       break;
/*     */     case 5: 
/* 102 */       PngTrnsChunk trnsChunk = (PngTrnsChunk)chunk;
/* 103 */       if (trnsChunk.getTransparencyType(this.headerChunk) == 0)
/*     */       {
/*     */ 
/*     */ 
/* 107 */         this.imageData.transparentPixel = trnsChunk.getSwtTransparentPixel(this.headerChunk);
/*     */       } else {
/* 109 */         this.alphaPalette = trnsChunk.getAlphaValues(this.headerChunk, this.paletteChunk);
/* 110 */         int transparentCount = 0;int transparentPixel = -1;
/* 111 */         for (int i = 0; i < this.alphaPalette.length; i++) {
/* 112 */           if ((this.alphaPalette[i] & 0xFF) != 255) {
/* 113 */             transparentCount++;
/* 114 */             transparentPixel = i;
/*     */           }
/*     */         }
/* 117 */         if (transparentCount == 0) {
/* 118 */           this.alphaPalette = null;
/* 119 */         } else if ((transparentCount == 1) && (this.alphaPalette[transparentPixel] == 0)) {
/* 120 */           this.alphaPalette = null;
/* 121 */           this.imageData.transparentPixel = transparentPixel;
/*     */         }
/*     */       }
/* 124 */       break;
/*     */     case 2: 
/* 126 */       if (chunkReader.readPixelData())
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/* 131 */         SWT.error(40);
/*     */       }
/*     */       else
/*     */       {
/* 135 */         PngIdatChunk dataChunk = (PngIdatChunk)chunk;
/* 136 */         readPixelData(dataChunk, chunkReader);
/*     */       }
/* 138 */       break;
/*     */     case 4: default: 
/* 140 */       if (chunk.isCritical())
/*     */       {
/* 142 */         SWT.error(20); }
/*     */       break;
/*     */     }
/*     */   }
/*     */   
/*     */   void unloadIntoByteStream(ImageLoader loader) {
/* 148 */     PngEncoder encoder = new PngEncoder(loader);
/* 149 */     encoder.encode(this.outputStream);
/*     */   }
/*     */   
/*     */   boolean isFileFormat(LEDataInputStream stream) {
/*     */     try {
/* 154 */       byte[] signature = new byte[8];
/* 155 */       stream.read(signature);
/* 156 */       stream.unread(signature);
/* 157 */       if ((signature[0] & 0xFF) != 137) return false;
/* 158 */       if ((signature[1] & 0xFF) != 80) return false;
/* 159 */       if ((signature[2] & 0xFF) != 78) return false;
/* 160 */       if ((signature[3] & 0xFF) != 71) return false;
/* 161 */       if ((signature[4] & 0xFF) != 13) return false;
/* 162 */       if ((signature[5] & 0xFF) != 10) return false;
/* 163 */       if ((signature[6] & 0xFF) != 26) return false;
/* 164 */       if ((signature[7] & 0xFF) != 10) return false;
/* 165 */       return true;
/*     */     } catch (Exception e) {}
/* 167 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   byte[] validateBitDepth(byte[] data)
/*     */   {
/* 175 */     if (this.headerChunk.getBitDepth() > 8) {
/* 176 */       byte[] result = new byte[data.length / 2];
/* 177 */       compress16BitDepthTo8BitDepth(data, 0, result, 0, result.length);
/* 178 */       return result;
/*     */     }
/* 180 */     return data;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void setPixelData(byte[] data, ImageData imageData)
/*     */   {
/* 192 */     switch (this.headerChunk.getColorType())
/*     */     {
/*     */     case 4: 
/* 195 */       int width = imageData.width;
/* 196 */       int height = imageData.height;
/* 197 */       int destBytesPerLine = imageData.bytesPerLine;
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 202 */       int srcBytesPerLine = getAlignedBytesPerRow();
/* 203 */       if (this.headerChunk.getBitDepth() > 8) { srcBytesPerLine /= 2;
/*     */       }
/* 205 */       byte[] rgbData = new byte[destBytesPerLine * height];
/* 206 */       byte[] alphaData = new byte[width * height];
/* 207 */       for (int y = 0; y < height; y++) {
/* 208 */         int srcIndex = srcBytesPerLine * y;
/* 209 */         int destIndex = destBytesPerLine * y;
/* 210 */         int destAlphaIndex = width * y;
/* 211 */         for (int x = 0; x < width; x++) {
/* 212 */           byte grey = data[srcIndex];
/* 213 */           byte alpha = data[(srcIndex + 1)];
/* 214 */           rgbData[(destIndex + 0)] = grey;
/* 215 */           rgbData[(destIndex + 1)] = grey;
/* 216 */           rgbData[(destIndex + 2)] = grey;
/* 217 */           alphaData[destAlphaIndex] = alpha;
/* 218 */           srcIndex += 2;
/* 219 */           destIndex += 3;
/* 220 */           destAlphaIndex++;
/*     */         }
/*     */       }
/* 223 */       imageData.data = rgbData;
/* 224 */       imageData.alphaData = alphaData;
/* 225 */       break;
/*     */     
/*     */ 
/*     */     case 6: 
/* 229 */       int width = imageData.width;
/* 230 */       int height = imageData.height;
/* 231 */       int destBytesPerLine = imageData.bytesPerLine;
/* 232 */       int srcBytesPerLine = getAlignedBytesPerRow();
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 237 */       if (this.headerChunk.getBitDepth() > 8) { srcBytesPerLine /= 2;
/*     */       }
/* 239 */       byte[] rgbData = new byte[destBytesPerLine * height];
/* 240 */       byte[] alphaData = new byte[width * height];
/* 241 */       for (int y = 0; y < height; y++) {
/* 242 */         int srcIndex = srcBytesPerLine * y;
/* 243 */         int destIndex = destBytesPerLine * y;
/* 244 */         int destAlphaIndex = width * y;
/* 245 */         for (int x = 0; x < width; x++) {
/* 246 */           rgbData[(destIndex + 0)] = data[(srcIndex + 0)];
/* 247 */           rgbData[(destIndex + 1)] = data[(srcIndex + 1)];
/* 248 */           rgbData[(destIndex + 2)] = data[(srcIndex + 2)];
/* 249 */           alphaData[destAlphaIndex] = data[(srcIndex + 3)];
/* 250 */           srcIndex += 4;
/* 251 */           destIndex += 3;
/* 252 */           destAlphaIndex++;
/*     */         }
/*     */       }
/* 255 */       imageData.data = rgbData;
/* 256 */       imageData.alphaData = alphaData;
/* 257 */       break;
/*     */     
/*     */     case 3: 
/* 260 */       imageData.data = data;
/* 261 */       if (this.alphaPalette != null) {
/* 262 */         int size = imageData.width * imageData.height;
/* 263 */         byte[] alphaData = new byte[size];
/* 264 */         byte[] pixelData = new byte[size];
/* 265 */         imageData.getPixels(0, 0, size, pixelData, 0);
/* 266 */         for (int i = 0; i < pixelData.length; i++) {
/* 267 */           alphaData[i] = this.alphaPalette[(pixelData[i] & 0xFF)];
/*     */         }
/* 269 */         imageData.alphaData = alphaData; }
/* 270 */       break;
/*     */     case 2: 
/*     */     case 5: 
/*     */     default: 
/* 274 */       int height = imageData.height;
/* 275 */       int destBytesPerLine = imageData.bytesPerLine;
/* 276 */       int srcBytesPerLine = getAlignedBytesPerRow();
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 281 */       if (this.headerChunk.getBitDepth() > 8) srcBytesPerLine /= 2;
/* 282 */       if (destBytesPerLine != srcBytesPerLine) {
/* 283 */         for (int y = 0; y < height; y++) {
/* 284 */           System.arraycopy(data, y * srcBytesPerLine, imageData.data, y * destBytesPerLine, srcBytesPerLine);
/*     */         }
/*     */       } else {
/* 287 */         imageData.data = data;
/*     */       }
/*     */       
/*     */ 
/*     */       break;
/*     */     }
/*     */     
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   void setImageDataValues(byte[] data, ImageData imageData)
/*     */   {
/* 300 */     byte[] result = validateBitDepth(data);
/* 301 */     setPixelData(result, imageData);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   void readPixelData(PngIdatChunk chunk, PngChunkReader chunkReader)
/*     */     throws IOException
/*     */   {
/* 309 */     InputStream stream = new PngInputStream(chunk, chunkReader);
/*     */     
/* 311 */     boolean use3_2 = System.getProperty("org.eclipse.swt.internal.image.PNGFileFormat_3.2") != null;
/* 312 */     InputStream inflaterStream = use3_2 ? null : new BufferedInputStream(new InflaterInputStream(stream));
/* 313 */     if (inflaterStream != null) {
/* 314 */       stream = inflaterStream;
/*     */     } else {
/* 316 */       stream = new PngDecodingDataStream(stream);
/*     */     }
/* 318 */     int interlaceMethod = this.headerChunk.getInterlaceMethod();
/* 319 */     if (interlaceMethod == 0) {
/* 320 */       readNonInterlacedImage(stream);
/*     */     } else {
/* 322 */       readInterlacedImage(stream);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 329 */     while (stream.available() > 0) stream.read();
/* 330 */     stream.close();
/*     */   }
/*     */   
/*     */ 
/*     */   int getAlignedBytesPerRow()
/*     */   {
/* 336 */     return (getBytesPerRow(this.headerChunk.getWidth()) + 3) / 4 * 4;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   int getBytesPerRow()
/*     */   {
/* 345 */     return getBytesPerRow(this.headerChunk.getWidth());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   int getBytesPerPixel()
/*     */   {
/* 355 */     int bitsPerPixel = this.headerChunk.getBitsPerPixel();
/* 356 */     return (bitsPerPixel + 7) / 8;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   int getBytesPerRow(int rowWidthInPixels)
/*     */   {
/* 365 */     int bitsPerPixel = this.headerChunk.getBitsPerPixel();
/* 366 */     int bitsPerRow = bitsPerPixel * rowWidthInPixels;
/* 367 */     int bitsPerByte = 8;
/* 368 */     return (bitsPerRow + (bitsPerByte - 1)) / bitsPerByte;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void readInterlaceFrame(InputStream inputStream, int rowInterval, int columnInterval, int startRow, int startColumn, int frameCount)
/*     */     throws IOException
/*     */   {
/* 383 */     int width = this.headerChunk.getWidth();
/* 384 */     int alignedBytesPerRow = getAlignedBytesPerRow();
/* 385 */     int height = this.headerChunk.getHeight();
/* 386 */     if ((startRow >= height) || (startColumn >= width)) { return;
/*     */     }
/* 388 */     int pixelsPerRow = (width - startColumn + columnInterval - 1) / columnInterval;
/* 389 */     int bytesPerRow = getBytesPerRow(pixelsPerRow);
/* 390 */     byte[] row1 = new byte[bytesPerRow];
/* 391 */     byte[] row2 = new byte[bytesPerRow];
/* 392 */     byte[] currentRow = row1;
/* 393 */     byte[] lastRow = row2;
/* 394 */     for (int row = startRow; row < height; row += rowInterval) {
/* 395 */       byte filterType = (byte)inputStream.read();
/* 396 */       int read = 0;
/* 397 */       while (read != bytesPerRow) {
/* 398 */         read += inputStream.read(currentRow, read, bytesPerRow - read);
/*     */       }
/* 400 */       filterRow(currentRow, lastRow, filterType);
/* 401 */       if (this.headerChunk.getBitDepth() >= 8) {
/* 402 */         int bytesPerPixel = getBytesPerPixel();
/* 403 */         int dataOffset = row * alignedBytesPerRow + startColumn * bytesPerPixel;
/* 404 */         for (int rowOffset = 0; rowOffset < currentRow.length; rowOffset += bytesPerPixel) {
/* 405 */           for (int byteOffset = 0; byteOffset < bytesPerPixel; byteOffset++) {
/* 406 */             this.data[(dataOffset + byteOffset)] = currentRow[(rowOffset + byteOffset)];
/*     */           }
/* 408 */           dataOffset += columnInterval * bytesPerPixel;
/*     */         }
/*     */       } else {
/* 411 */         int bitsPerPixel = this.headerChunk.getBitDepth();
/* 412 */         int pixelsPerByte = 8 / bitsPerPixel;
/* 413 */         int column = startColumn;
/* 414 */         int rowBase = row * alignedBytesPerRow;
/* 415 */         int valueMask = 0;
/* 416 */         for (int i = 0; i < bitsPerPixel; i++) {
/* 417 */           valueMask <<= 1;
/* 418 */           valueMask |= 0x1;
/*     */         }
/* 420 */         int maxShift = 8 - bitsPerPixel;
/* 421 */         for (int byteOffset = 0; byteOffset < currentRow.length; byteOffset++) {
/* 422 */           for (int bitOffset = maxShift; bitOffset >= 0; bitOffset -= bitsPerPixel) {
/* 423 */             if (column < width) {
/* 424 */               int dataOffset = rowBase + column * bitsPerPixel / 8;
/* 425 */               int value = currentRow[byteOffset] >> bitOffset & valueMask;
/* 426 */               int dataShift = maxShift - bitsPerPixel * (column % pixelsPerByte); int 
/* 427 */                 tmp374_372 = dataOffset; byte[] tmp374_369 = this.data;tmp374_369[tmp374_372] = ((byte)(tmp374_369[tmp374_372] | value << dataShift));
/*     */             }
/* 429 */             column += columnInterval;
/*     */           }
/*     */         }
/*     */       }
/* 433 */       currentRow = currentRow == row1 ? row2 : row1;
/* 434 */       lastRow = lastRow == row1 ? row2 : row1;
/*     */     }
/* 436 */     setImageDataValues(this.data, this.imageData);
/* 437 */     fireInterlacedFrameEvent(frameCount);
/*     */   }
/*     */   
/*     */ 
/*     */   void readInterlacedImage(InputStream inputStream)
/*     */     throws IOException
/*     */   {
/* 444 */     readInterlaceFrame(inputStream, 8, 8, 0, 0, 0);
/* 445 */     readInterlaceFrame(inputStream, 8, 8, 0, 4, 1);
/* 446 */     readInterlaceFrame(inputStream, 8, 4, 4, 0, 2);
/* 447 */     readInterlaceFrame(inputStream, 4, 4, 0, 2, 3);
/* 448 */     readInterlaceFrame(inputStream, 4, 2, 2, 0, 4);
/* 449 */     readInterlaceFrame(inputStream, 2, 2, 0, 1, 5);
/* 450 */     readInterlaceFrame(inputStream, 2, 1, 1, 0, 6);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void fireInterlacedFrameEvent(int frameCount)
/*     */   {
/* 459 */     if (this.loader.hasListeners()) {
/* 460 */       ImageData image = (ImageData)this.imageData.clone();
/* 461 */       boolean finalFrame = frameCount == 6;
/* 462 */       this.loader.notifyListeners(new ImageLoaderEvent(this.loader, image, frameCount, finalFrame));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   void readNonInterlacedImage(InputStream inputStream)
/*     */     throws IOException
/*     */   {
/* 471 */     int dataOffset = 0;
/* 472 */     int alignedBytesPerRow = getAlignedBytesPerRow();
/* 473 */     int bytesPerRow = getBytesPerRow();
/* 474 */     byte[] row1 = new byte[bytesPerRow];
/* 475 */     byte[] row2 = new byte[bytesPerRow];
/* 476 */     byte[] currentRow = row1;
/* 477 */     byte[] lastRow = row2;
/* 478 */     int height = this.headerChunk.getHeight();
/* 479 */     for (int row = 0; row < height; row++) {
/* 480 */       byte filterType = (byte)inputStream.read();
/* 481 */       int read = 0;
/* 482 */       while (read != bytesPerRow) {
/* 483 */         read += inputStream.read(currentRow, read, bytesPerRow - read);
/*     */       }
/* 485 */       filterRow(currentRow, lastRow, filterType);
/* 486 */       System.arraycopy(currentRow, 0, this.data, dataOffset, bytesPerRow);
/* 487 */       dataOffset += alignedBytesPerRow;
/* 488 */       currentRow = currentRow == row1 ? row2 : row1;
/* 489 */       lastRow = lastRow == row1 ? row2 : row1;
/*     */     }
/* 491 */     setImageDataValues(this.data, this.imageData);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static void compress16BitDepthTo8BitDepth(byte[] source, int sourceOffset, byte[] destination, int destinationOffset, int numberOfValues)
/*     */   {
/* 510 */     for (int i = 0; i < numberOfValues; i++) {
/* 511 */       int sourceIndex = sourceOffset + 2 * i;
/* 512 */       int destinationIndex = destinationOffset + i;
/*     */       
/*     */ 
/* 515 */       byte compressedValue = source[sourceIndex];
/* 516 */       destination[destinationIndex] = compressedValue;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static int compress16BitDepthTo8BitDepth(int value)
/*     */   {
/* 531 */     return value >> 8;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   void filterRow(byte[] row, byte[] previousRow, int filterType)
/*     */   {
/* 539 */     int byteOffset = this.headerChunk.getFilterByteOffset();
/* 540 */     switch (filterType) {
/*     */     case 0: 
/*     */       break;
/*     */     case 1: 
/* 544 */       for (int i = byteOffset; i < row.length; i++) {
/* 545 */         int current = row[i] & 0xFF;
/* 546 */         int left = row[(i - byteOffset)] & 0xFF;
/* 547 */         row[i] = ((byte)(current + left & 0xFF));
/*     */       }
/* 549 */       break;
/*     */     case 2: 
/* 551 */       for (int i = 0; i < row.length; i++) {
/* 552 */         int current = row[i] & 0xFF;
/* 553 */         int above = previousRow[i] & 0xFF;
/* 554 */         row[i] = ((byte)(current + above & 0xFF));
/*     */       }
/* 556 */       break;
/*     */     case 3: 
/* 558 */       for (int i = 0; i < row.length; i++) {
/* 559 */         int left = i < byteOffset ? 0 : row[(i - byteOffset)] & 0xFF;
/* 560 */         int above = previousRow[i] & 0xFF;
/* 561 */         int current = row[i] & 0xFF;
/* 562 */         row[i] = ((byte)(current + (left + above) / 2 & 0xFF));
/*     */       }
/* 564 */       break;
/*     */     case 4: 
/* 566 */       for (int i = 0; i < row.length; i++) {
/* 567 */         int left = i < byteOffset ? 0 : row[(i - byteOffset)] & 0xFF;
/* 568 */         int aboveLeft = i < byteOffset ? 0 : previousRow[(i - byteOffset)] & 0xFF;
/* 569 */         int above = previousRow[i] & 0xFF;
/*     */         
/* 571 */         int a = Math.abs(above - aboveLeft);
/* 572 */         int b = Math.abs(left - aboveLeft);
/* 573 */         int c = Math.abs(left - aboveLeft + above - aboveLeft);
/*     */         
/* 575 */         int preductor = 0;
/* 576 */         if ((a <= b) && (a <= c)) {
/* 577 */           preductor = left;
/* 578 */         } else if (b <= c) {
/* 579 */           preductor = above;
/*     */         } else {
/* 581 */           preductor = aboveLeft;
/*     */         }
/*     */         
/* 584 */         int currentValue = row[i] & 0xFF;
/* 585 */         row[i] = ((byte)(currentValue + preductor & 0xFF));
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/internal/image/PNGFileFormat.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */