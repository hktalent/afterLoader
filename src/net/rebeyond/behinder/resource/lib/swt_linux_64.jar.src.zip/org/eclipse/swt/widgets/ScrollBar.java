/*     */ package org.eclipse.swt.widgets;
/*     */ 
/*     */ import org.eclipse.swt.events.SelectionListener;
/*     */ import org.eclipse.swt.graphics.Point;
/*     */ import org.eclipse.swt.graphics.Rectangle;
/*     */ import org.eclipse.swt.internal.DPIUtil;
/*     */ import org.eclipse.swt.internal.gtk.GDK;
/*     */ import org.eclipse.swt.internal.gtk.GTK;
/*     */ import org.eclipse.swt.internal.gtk.GdkEvent;
/*     */ import org.eclipse.swt.internal.gtk.GdkEventButton;
/*     */ import org.eclipse.swt.internal.gtk.GtkAdjustment;
/*     */ import org.eclipse.swt.internal.gtk.GtkAllocation;
/*     */ import org.eclipse.swt.internal.gtk.GtkRequisition;
/*     */ import org.eclipse.swt.internal.gtk.OS;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ScrollBar
/*     */   extends Widget
/*     */ {
/*     */   Scrollable parent;
/*     */   long adjustmentHandle;
/*     */   int detail;
/*     */   boolean dragSent;
/*     */   
/*     */   ScrollBar() {}
/*     */   
/*     */   ScrollBar(Scrollable parent, int style)
/*     */   {
/*  99 */     super(parent, checkStyle(style));
/* 100 */     this.parent = parent;
/* 101 */     createWidget(0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addSelectionListener(SelectionListener listener)
/*     */   {
/* 137 */     checkWidget();
/* 138 */     if (listener == null) error(4);
/* 139 */     TypedListener typedListener = new TypedListener(listener);
/* 140 */     addListener(13, typedListener);
/* 141 */     addListener(14, typedListener);
/*     */   }
/*     */   
/*     */   static int checkStyle(int style) {
/* 145 */     return checkBits(style, 256, 512, 0, 0, 0, 0);
/*     */   }
/*     */   
/*     */   void deregister()
/*     */   {
/* 150 */     super.deregister();
/* 151 */     if (this.adjustmentHandle != 0L) this.display.removeWidget(this.adjustmentHandle);
/*     */   }
/*     */   
/*     */   void destroyHandle() {
/* 155 */     super.destroyWidget();
/*     */   }
/*     */   
/*     */   void destroyWidget()
/*     */   {
/* 160 */     this.parent.destroyScrollBar(this);
/* 161 */     releaseHandle();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getEnabled()
/*     */   {
/* 181 */     checkWidget();
/* 182 */     if (this.handle != 0L) return GTK.gtk_widget_get_sensitive(this.handle);
/* 183 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getIncrement()
/*     */   {
/* 199 */     checkWidget();
/* 200 */     return (int)GTK.gtk_adjustment_get_step_increment(this.adjustmentHandle);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getMaximum()
/*     */   {
/* 214 */     checkWidget();
/* 215 */     return (int)GTK.gtk_adjustment_get_upper(this.adjustmentHandle);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getMinimum()
/*     */   {
/* 229 */     checkWidget();
/* 230 */     return (int)GTK.gtk_adjustment_get_lower(this.adjustmentHandle);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getPageIncrement()
/*     */   {
/* 246 */     checkWidget();
/* 247 */     return (int)GTK.gtk_adjustment_get_page_increment(this.adjustmentHandle);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Scrollable getParent()
/*     */   {
/* 261 */     checkWidget();
/* 262 */     return this.parent;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getSelection()
/*     */   {
/* 276 */     checkWidget();
/* 277 */     return (int)GTK.gtk_adjustment_get_value(this.adjustmentHandle);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Point getSize()
/*     */   {
/* 295 */     checkWidget();
/* 296 */     return DPIUtil.autoScaleDown(getSizeInPixels());
/*     */   }
/*     */   
/*     */   Point getSizeInPixels() {
/* 300 */     checkWidget();
/* 301 */     if (this.handle == 0L) return new Point(0, 0);
/* 302 */     GtkRequisition requisition = new GtkRequisition();
/* 303 */     gtk_widget_get_preferred_size(this.handle, requisition);
/* 304 */     return new Point(requisition.width, requisition.height);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getThumb()
/*     */   {
/* 320 */     checkWidget();
/* 321 */     return (int)GTK.gtk_adjustment_get_page_size(this.adjustmentHandle);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Rectangle getThumbBounds()
/*     */   {
/* 338 */     checkWidget();
/* 339 */     return DPIUtil.autoScaleDown(getThumbBoundsInPixels());
/*     */   }
/*     */   
/*     */   Rectangle getThumbBoundsInPixels() {
/* 343 */     checkWidget();
/* 344 */     int[] slider_start = new int[1];int[] slider_end = new int[1];
/* 345 */     gtk_range_get_slider_range(this.handle, slider_start, slider_end);
/*     */     
/* 347 */     GtkAllocation allocation = new GtkAllocation();
/* 348 */     GTK.gtk_widget_get_allocation(this.handle, allocation);
/* 349 */     int height; int x; int y; int width; int height; if ((this.style & 0x200) != 0) {
/* 350 */       int x = allocation.x;
/* 351 */       int y = slider_start[0];
/* 352 */       int width = allocation.width;
/* 353 */       height = slider_end[0] - slider_start[0];
/*     */     } else {
/* 355 */       x = slider_start[0];
/* 356 */       y = allocation.y;
/* 357 */       width = slider_end[0] - slider_start[0];
/* 358 */       height = allocation.height;
/*     */     }
/* 360 */     Rectangle rect = new Rectangle(x, y, width, height);
/* 361 */     int[] origin_x = new int[1];int[] origin_y = new int[1];
/* 362 */     long window = gtk_widget_get_window(this.parent.scrolledHandle);
/* 363 */     if (window != 0L) GDK.gdk_window_get_origin(window, origin_x, origin_y);
/* 364 */     rect.x += origin_x[0];
/* 365 */     rect.y += origin_y[0];
/* 366 */     window = gtk_widget_get_window(this.parent.handle);
/* 367 */     if (window != 0L) GDK.gdk_window_get_origin(window, origin_x, origin_y);
/* 368 */     rect.x -= origin_x[0];
/* 369 */     rect.y -= origin_y[0];
/* 370 */     return rect;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Rectangle getThumbTrackBounds()
/*     */   {
/* 388 */     checkWidget();
/* 389 */     return DPIUtil.autoScaleDown(getThumbTrackBoundsInPixels());
/*     */   }
/*     */   
/*     */   Rectangle getThumbTrackBoundsInPixels() {
/* 393 */     checkWidget();
/* 394 */     int x = 0;int y = 0;
/* 395 */     int[] has_stepper = new int[1];
/* 396 */     GTK.gtk_widget_style_get(this.handle, OS.has_backward_stepper, has_stepper, 0L);
/* 397 */     boolean hasB = has_stepper[0] != 0;
/* 398 */     GTK.gtk_widget_style_get(this.handle, OS.has_secondary_backward_stepper, has_stepper, 0L);
/* 399 */     boolean hasB2 = has_stepper[0] != 0;
/* 400 */     GTK.gtk_widget_style_get(this.handle, OS.has_forward_stepper, has_stepper, 0L);
/* 401 */     boolean hasF = has_stepper[0] != 0;
/* 402 */     GTK.gtk_widget_style_get(this.handle, OS.has_secondary_forward_stepper, has_stepper, 0L);
/* 403 */     boolean hasF2 = has_stepper[0] != 0;
/* 404 */     GtkAllocation allocation = new GtkAllocation();
/* 405 */     GTK.gtk_widget_get_allocation(this.handle, allocation);
/* 406 */     int width; int height; if ((this.style & 0x200) != 0) {
/* 407 */       int stepperSize = allocation.width;
/* 408 */       x = allocation.x;
/* 409 */       if (hasB) y += stepperSize;
/* 410 */       if (hasF2) y += stepperSize;
/* 411 */       int width = allocation.width;
/* 412 */       int height = allocation.height - y;
/* 413 */       if (hasB2) height -= stepperSize;
/* 414 */       if (hasF) height -= stepperSize;
/* 415 */       if (height < 0) {
/* 416 */         int[] slider_start = new int[1];int[] slider_end = new int[1];
/* 417 */         gtk_range_get_slider_range(this.handle, slider_start, slider_end);
/* 418 */         y = slider_start[0];
/* 419 */         height = 0;
/*     */       }
/*     */     } else {
/* 422 */       int stepperSize = allocation.height;
/* 423 */       if (hasB) x += stepperSize;
/* 424 */       if (hasF2) x += stepperSize;
/* 425 */       y = allocation.y;
/* 426 */       width = allocation.width - x;
/* 427 */       if (hasB2) width -= stepperSize;
/* 428 */       if (hasF) width -= stepperSize;
/* 429 */       height = allocation.height;
/* 430 */       if (width < 0) {
/* 431 */         int[] slider_start = new int[1];int[] slider_end = new int[1];
/* 432 */         gtk_range_get_slider_range(this.handle, slider_start, slider_end);
/* 433 */         x = slider_start[0];
/* 434 */         width = 0;
/*     */       }
/*     */     }
/* 437 */     Rectangle rect = new Rectangle(x, y, width, height);
/* 438 */     int[] origin_x = new int[1];int[] origin_y = new int[1];
/* 439 */     long window = gtk_widget_get_window(this.parent.scrolledHandle);
/* 440 */     if (window != 0L) GDK.gdk_window_get_origin(window, origin_x, origin_y);
/* 441 */     rect.x += origin_x[0];
/* 442 */     rect.y += origin_y[0];
/* 443 */     window = gtk_widget_get_window(this.parent.handle);
/* 444 */     if (window != 0L) GDK.gdk_window_get_origin(window, origin_x, origin_y);
/* 445 */     rect.x -= origin_x[0];
/* 446 */     rect.y -= origin_y[0];
/* 447 */     return rect;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getVisible()
/*     */   {
/* 468 */     checkWidget();
/* 469 */     long scrolledHandle = this.parent.scrolledHandle;
/* 470 */     int[] hsp = new int[1];int[] vsp = new int[1];
/* 471 */     GTK.gtk_scrolled_window_get_policy(scrolledHandle, hsp, vsp);
/* 472 */     if ((this.style & 0x100) != 0) {
/* 473 */       return (hsp[0] != 2) && (hsp[0] != 3) && (GTK.gtk_widget_get_visible(this.handle));
/*     */     }
/* 475 */     return (vsp[0] != 2) && (vsp[0] != 3) && (GTK.gtk_widget_get_visible(this.handle));
/*     */   }
/*     */   
/*     */ 
/*     */   long gtk_button_press_event(long widget, long eventPtr)
/*     */   {
/* 481 */     long result = super.gtk_button_press_event(widget, eventPtr);
/* 482 */     if (result != 0L) return result;
/* 483 */     this.detail = 0;
/* 484 */     this.dragSent = false;
/* 485 */     return result;
/*     */   }
/*     */   
/*     */   long gtk_change_value(long widget, long scroll, long value1, long value2)
/*     */   {
/* 490 */     this.detail = ((int)scroll);
/* 491 */     return 0L;
/*     */   }
/*     */   
/*     */   void gtk_range_get_slider_range(long widget, int[] slider_start, int[] slider_end) {
/* 495 */     GTK.gtk_range_get_slider_range(widget, slider_start, slider_end);
/*     */   }
/*     */   
/*     */   long gtk_value_changed(long adjustment)
/*     */   {
/* 500 */     Event event = new Event();
/* 501 */     this.dragSent = (this.detail == 1);
/* 502 */     switch (this.detail) {
/* 503 */     case 0:  event.detail = 0; break;
/* 504 */     case 1:  event.detail = 1; break;
/* 505 */     case 14:  event.detail = 16777223; break;
/* 506 */     case 15:  event.detail = 16777224; break;
/*     */     case 5: case 9: 
/*     */     case 13: 
/* 509 */       event.detail = 16777222; break;
/*     */     case 4: case 8: 
/*     */     case 12: 
/* 512 */       event.detail = 16777221; break;
/*     */     case 3: case 7: 
/*     */     case 11: 
/* 515 */       event.detail = 16777218; break;
/*     */     case 2: case 6: 
/*     */     case 10: 
/* 518 */       event.detail = 16777217;
/*     */     }
/* 520 */     if (!this.dragSent) this.detail = 0;
/* 521 */     sendSelectionEvent(13, event, false);
/* 522 */     this.parent.updateScrollBarValue(this);
/* 523 */     if (GTK.GTK3) {
/* 524 */       GTK.gtk_widget_queue_draw(this.parent.handle);
/*     */     }
/* 526 */     return 0L;
/*     */   }
/*     */   
/*     */   long gtk_event_after(long widget, long gdkEvent)
/*     */   {
/* 531 */     GdkEvent gtkEvent = new GdkEvent();
/* 532 */     OS.memmove(gtkEvent, gdkEvent, GdkEvent.sizeof);
/* 533 */     switch (gtkEvent.type) {
/*     */     case 7: 
/* 535 */       GdkEventButton gdkEventButton = new GdkEventButton();
/* 536 */       OS.memmove(gdkEventButton, gdkEvent, GdkEventButton.sizeof);
/* 537 */       if ((gdkEventButton.button == 1) && (this.detail == 1)) {
/* 538 */         if (!this.dragSent) {
/* 539 */           Event event = new Event();
/* 540 */           event.detail = 1;
/* 541 */           sendSelectionEvent(13, event, false);
/*     */         }
/* 543 */         sendSelectionEvent(13);
/*     */       }
/* 545 */       this.detail = 0;
/* 546 */       this.dragSent = false;
/* 547 */       break;
/*     */     }
/*     */     
/* 550 */     return super.gtk_event_after(widget, gdkEvent);
/*     */   }
/*     */   
/*     */   void hookEvents()
/*     */   {
/* 555 */     super.hookEvents();
/* 556 */     OS.g_signal_connect_closure(this.handle, OS.change_value, this.display.getClosure(7), false);
/* 557 */     OS.g_signal_connect_closure(this.adjustmentHandle, OS.value_changed, this.display.getClosure(57), false);
/* 558 */     OS.g_signal_connect_closure_by_id(this.handle, this.display.signalIds[16], 0, this.display.getClosure(16), false);
/* 559 */     OS.g_signal_connect_closure_by_id(this.handle, this.display.signalIds[2], 0, this.display.getClosure(2), false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isEnabled()
/*     */   {
/* 578 */     checkWidget();
/* 579 */     return (getEnabled()) && (getParent().getEnabled());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isVisible()
/*     */   {
/* 597 */     checkWidget();
/* 598 */     return (getVisible()) && (getParent().isVisible());
/*     */   }
/*     */   
/*     */   void register()
/*     */   {
/* 603 */     super.register();
/* 604 */     if (this.adjustmentHandle != 0L) this.display.addWidget(this.adjustmentHandle, this);
/*     */   }
/*     */   
/*     */   void releaseHandle()
/*     */   {
/* 609 */     super.releaseHandle();
/* 610 */     this.parent = null;
/*     */   }
/*     */   
/*     */   void releaseParent()
/*     */   {
/* 615 */     super.releaseParent();
/* 616 */     if (this.parent.horizontalBar == this) this.parent.horizontalBar = null;
/* 617 */     if (this.parent.verticalBar == this) { this.parent.verticalBar = null;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeSelectionListener(SelectionListener listener)
/*     */   {
/* 638 */     checkWidget();
/* 639 */     if (listener == null) error(4);
/* 640 */     if (this.eventTable == null) return;
/* 641 */     this.eventTable.unhook(13, listener);
/* 642 */     this.eventTable.unhook(14, listener);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setEnabled(boolean enabled)
/*     */   {
/* 659 */     checkWidget();
/* 660 */     if (this.handle != 0L) { GTK.gtk_widget_set_sensitive(this.handle, enabled);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setIncrement(int value)
/*     */   {
/* 677 */     checkWidget();
/* 678 */     if (value < 1) return;
/* 679 */     OS.g_signal_handlers_block_matched(this.adjustmentHandle, 16, 0, 0, 0L, 0L, 57L);
/* 680 */     GTK.gtk_adjustment_set_step_increment(this.adjustmentHandle, value);
/* 681 */     OS.g_signal_handlers_unblock_matched(this.adjustmentHandle, 16, 0, 0, 0L, 0L, 57L);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMaximum(int value)
/*     */   {
/* 698 */     checkWidget();
/* 699 */     GtkAdjustment adjustment = new GtkAdjustment();
/* 700 */     gtk_adjustment_get(this.adjustmentHandle, adjustment);
/* 701 */     int minimum = (int)adjustment.lower;
/* 702 */     if (value <= minimum) return;
/* 703 */     adjustment.upper = value;
/* 704 */     adjustment.page_size = Math.min((int)adjustment.page_size, value - minimum);
/* 705 */     adjustment.value = Math.min((int)adjustment.value, (int)(value - adjustment.page_size));
/* 706 */     OS.g_signal_handlers_block_matched(this.adjustmentHandle, 16, 0, 0, 0L, 0L, 57L);
/* 707 */     GTK.gtk_adjustment_configure(this.adjustmentHandle, adjustment.value, adjustment.lower, adjustment.upper, adjustment.step_increment, adjustment.page_increment, adjustment.page_size);
/*     */     
/* 709 */     OS.g_signal_handlers_unblock_matched(this.adjustmentHandle, 16, 0, 0, 0L, 0L, 57L);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMinimum(int value)
/*     */   {
/* 726 */     checkWidget();
/* 727 */     if (value < 0) return;
/* 728 */     GtkAdjustment adjustment = new GtkAdjustment();
/* 729 */     gtk_adjustment_get(this.adjustmentHandle, adjustment);
/* 730 */     int maximum = (int)adjustment.upper;
/* 731 */     if (value >= maximum) return;
/* 732 */     adjustment.lower = value;
/* 733 */     adjustment.page_size = Math.min((int)adjustment.page_size, maximum - value);
/* 734 */     adjustment.value = Math.max((int)adjustment.value, value);
/* 735 */     OS.g_signal_handlers_block_matched(this.adjustmentHandle, 16, 0, 0, 0L, 0L, 57L);
/* 736 */     GTK.gtk_adjustment_configure(this.adjustmentHandle, adjustment.value, adjustment.lower, adjustment.upper, adjustment.step_increment, adjustment.page_increment, adjustment.page_size);
/*     */     
/* 738 */     OS.g_signal_handlers_unblock_matched(this.adjustmentHandle, 16, 0, 0, 0L, 0L, 57L);
/*     */   }
/*     */   
/*     */   void setOrientation(boolean create)
/*     */   {
/* 743 */     super.setOrientation(create);
/* 744 */     if ((((this.parent.style & 0x8000000) != 0) || (!create)) && 
/* 745 */       ((this.parent.state & 0x2) != 0) && 
/* 746 */       ((this.style & 0x100) != 0)) {
/* 747 */       GTK.gtk_range_set_inverted(this.handle, (this.parent.style & 0x4000000) != 0);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPageIncrement(int value)
/*     */   {
/* 767 */     checkWidget();
/* 768 */     if (value < 1) return;
/* 769 */     OS.g_signal_handlers_block_matched(this.adjustmentHandle, 16, 0, 0, 0L, 0L, 57L);
/* 770 */     GTK.gtk_adjustment_set_page_increment(this.adjustmentHandle, value);
/* 771 */     OS.g_signal_handlers_unblock_matched(this.adjustmentHandle, 16, 0, 0, 0L, 0L, 57L);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSelection(int selection)
/*     */   {
/* 787 */     checkWidget();
/* 788 */     selection = Math.min(selection, getMaximum() - getThumb());
/* 789 */     OS.g_signal_handlers_block_matched(this.adjustmentHandle, 16, 0, 0, 0L, 0L, 57L);
/* 790 */     GTK.gtk_adjustment_set_value(this.adjustmentHandle, selection);
/* 791 */     OS.g_signal_handlers_unblock_matched(this.adjustmentHandle, 16, 0, 0, 0L, 0L, 57L);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setThumb(int value)
/*     */   {
/* 812 */     checkWidget();
/* 813 */     if (value < 1) return;
/* 814 */     GtkAdjustment adjustment = new GtkAdjustment();
/* 815 */     gtk_adjustment_get(this.adjustmentHandle, adjustment);
/* 816 */     value = Math.min(value, (int)(adjustment.upper - adjustment.lower));
/* 817 */     adjustment.page_size = value;
/* 818 */     adjustment.value = Math.min((int)adjustment.value, (int)(adjustment.upper - value));
/* 819 */     OS.g_signal_handlers_block_matched(this.adjustmentHandle, 16, 0, 0, 0L, 0L, 57L);
/* 820 */     GTK.gtk_adjustment_configure(this.adjustmentHandle, adjustment.value, adjustment.lower, adjustment.upper, adjustment.step_increment, adjustment.page_increment, adjustment.page_size);
/*     */     
/* 822 */     OS.g_signal_handlers_unblock_matched(this.adjustmentHandle, 16, 0, 0, 0L, 0L, 57L);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setValues(int selection, int minimum, int maximum, int thumb, int increment, int pageIncrement)
/*     */   {
/* 847 */     checkWidget();
/* 848 */     if (minimum < 0) return;
/* 849 */     if (maximum < 0) return;
/* 850 */     if (thumb < 1) return;
/* 851 */     if (increment < 1) return;
/* 852 */     if (pageIncrement < 1) return;
/* 853 */     thumb = Math.min(thumb, maximum - minimum);
/* 854 */     GtkAdjustment adjustment = new GtkAdjustment();
/* 855 */     adjustment.lower = minimum;
/* 856 */     adjustment.upper = maximum;
/* 857 */     adjustment.step_increment = increment;
/* 858 */     adjustment.page_increment = pageIncrement;
/* 859 */     adjustment.page_size = thumb;
/* 860 */     adjustment.value = Math.min(Math.max(selection, minimum), maximum - thumb);
/* 861 */     OS.g_signal_handlers_block_matched(this.adjustmentHandle, 16, 0, 0, 0L, 0L, 57L);
/* 862 */     GTK.gtk_adjustment_configure(this.adjustmentHandle, adjustment.value, adjustment.lower, adjustment.upper, adjustment.step_increment, adjustment.page_increment, adjustment.page_size);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 869 */     if (GTK.GTK_VERSION < OS.VERSION(3, 18, 0))
/* 870 */       GTK.gtk_adjustment_value_changed(this.adjustmentHandle);
/* 871 */     OS.g_signal_handlers_unblock_matched(this.adjustmentHandle, 16, 0, 0, 0L, 0L, 57L);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setVisible(boolean visible)
/*     */   {
/* 891 */     checkWidget();
/* 892 */     if (this.parent.setScrollBarVisible(this, visible)) {
/* 893 */       sendEvent(visible ? 22 : 23);
/* 894 */       this.parent.sendEvent(11);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/widgets/ScrollBar.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */