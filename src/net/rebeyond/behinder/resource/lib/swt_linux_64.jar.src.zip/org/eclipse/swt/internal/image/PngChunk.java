/*     */ package org.eclipse.swt.internal.image;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import org.eclipse.swt.SWT;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class PngChunk
/*     */ {
/*     */   byte[] reference;
/*     */   static final int LENGTH_OFFSET = 0;
/*     */   static final int TYPE_OFFSET = 4;
/*     */   static final int DATA_OFFSET = 8;
/*     */   static final int TYPE_FIELD_LENGTH = 4;
/*     */   static final int LENGTH_FIELD_LENGTH = 4;
/*     */   static final int MIN_LENGTH = 12;
/*     */   static final int CHUNK_UNKNOWN = -1;
/*     */   static final int CHUNK_IHDR = 0;
/*     */   static final int CHUNK_PLTE = 1;
/*     */   static final int CHUNK_IDAT = 2;
/*     */   static final int CHUNK_IEND = 3;
/*     */   static final int CHUNK_tRNS = 5;
/*  38 */   static final byte[] TYPE_IHDR = { 73, 72, 68, 82 };
/*  39 */   static final byte[] TYPE_PLTE = { 80, 76, 84, 69 };
/*  40 */   static final byte[] TYPE_IDAT = { 73, 68, 65, 84 };
/*  41 */   static final byte[] TYPE_IEND = { 73, 69, 78, 68 };
/*  42 */   static final byte[] TYPE_tRNS = { 116, 82, 78, 83 };
/*     */   
/*     */ 
/*     */ 
/*  46 */   static final int[] CRC_TABLE = new int['Ā'];
/*  47 */   static { for (int i = 0; i < 256; i++) {
/*  48 */       CRC_TABLE[i] = i;
/*  49 */       for (int j = 0; j < 8; j++) {
/*  50 */         if ((CRC_TABLE[i] & 0x1) == 0) {
/*  51 */           CRC_TABLE[i] = (CRC_TABLE[i] >> 1 & 0x7FFFFFFF);
/*     */         } else {
/*  53 */           CRC_TABLE[i] = (0xEDB88320 ^ CRC_TABLE[i] >> 1 & 0x7FFFFFFF);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   PngChunk(byte[] reference)
/*     */   {
/*  67 */     setReference(reference);
/*  68 */     if (reference.length < 4) SWT.error(40);
/*  69 */     this.length = getInt32(0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   PngChunk(int dataLength)
/*     */   {
/*  77 */     this(new byte[12 + dataLength]);
/*  78 */     setLength(dataLength);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   byte[] getReference()
/*     */   {
/*  85 */     return this.reference;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   void setReference(byte[] reference)
/*     */   {
/*  92 */     this.reference = reference;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   int getInt16(int offset)
/*     */   {
/* 100 */     int answer = 0;
/* 101 */     answer |= (this.reference[offset] & 0xFF) << 8;
/* 102 */     answer |= this.reference[(offset + 1)] & 0xFF;
/* 103 */     return answer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   void setInt16(int offset, int value)
/*     */   {
/* 111 */     this.reference[offset] = ((byte)(value >> 8 & 0xFF));
/* 112 */     this.reference[(offset + 1)] = ((byte)(value & 0xFF));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   int getInt32(int offset)
/*     */   {
/* 120 */     int answer = 0;
/* 121 */     answer |= (this.reference[offset] & 0xFF) << 24;
/* 122 */     answer |= (this.reference[(offset + 1)] & 0xFF) << 16;
/* 123 */     answer |= (this.reference[(offset + 2)] & 0xFF) << 8;
/* 124 */     answer |= this.reference[(offset + 3)] & 0xFF;
/* 125 */     return answer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   void setInt32(int offset, int value)
/*     */   {
/* 133 */     this.reference[offset] = ((byte)(value >> 24 & 0xFF));
/* 134 */     this.reference[(offset + 1)] = ((byte)(value >> 16 & 0xFF));
/* 135 */     this.reference[(offset + 2)] = ((byte)(value >> 8 & 0xFF));
/* 136 */     this.reference[(offset + 3)] = ((byte)(value & 0xFF));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   int getLength()
/*     */   {
/* 144 */     return this.length;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   void setLength(int value)
/*     */   {
/* 152 */     setInt32(0, value);
/* 153 */     this.length = value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   byte[] getTypeBytes()
/*     */   {
/* 166 */     byte[] type = new byte[4];
/* 167 */     System.arraycopy(this.reference, 4, type, 0, 4);
/* 168 */     return type;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void setType(byte[] value)
/*     */   {
/* 181 */     if (value.length != 4) {
/* 182 */       SWT.error(5);
/*     */     }
/* 184 */     System.arraycopy(value, 0, this.reference, 4, 4);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   byte[] getData()
/*     */   {
/* 191 */     int dataLength = getLength();
/* 192 */     if (this.reference.length < 12 + dataLength) {
/* 193 */       SWT.error(6);
/*     */     }
/* 195 */     byte[] data = new byte[dataLength];
/* 196 */     System.arraycopy(this.reference, 8, data, 0, dataLength);
/* 197 */     return data;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void setData(byte[] data)
/*     */   {
/* 209 */     setLength(data.length);
/* 210 */     System.arraycopy(data, 0, this.reference, 8, data.length);
/* 211 */     setCRC(computeCRC());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   int getCRC()
/*     */   {
/* 220 */     int crcOffset = 8 + getLength();
/* 221 */     return getInt32(crcOffset);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void setCRC(int value)
/*     */   {
/* 230 */     int crcOffset = 8 + getLength();
/* 231 */     setInt32(crcOffset, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   int getSize()
/*     */   {
/* 238 */     return 12 + getLength();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   boolean checkCRC()
/*     */   {
/* 247 */     int crc = computeCRC();
/* 248 */     int storedCRC = getCRC();
/* 249 */     return crc == storedCRC;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   int computeCRC()
/*     */   {
/* 256 */     int crc = -1;
/* 257 */     int start = 4;
/* 258 */     int stop = 8 + getLength();
/* 259 */     for (int i = start; i < stop; i++) {
/* 260 */       int index = (crc ^ this.reference[i]) & 0xFF;
/* 261 */       crc = CRC_TABLE[index] ^ crc >> 8 & 0xFFFFFF;
/*     */     }
/* 263 */     return crc ^ 0xFFFFFFFF;
/*     */   }
/*     */   
/*     */   boolean typeMatchesArray(byte[] array) {
/* 267 */     for (int i = 0; i < 4; i++) {
/* 268 */       if (this.reference[(4 + i)] != array[i]) {
/* 269 */         return false;
/*     */       }
/*     */     }
/* 272 */     return true;
/*     */   }
/*     */   
/*     */   boolean isCritical() {
/* 276 */     char c = (char)getTypeBytes()[0];
/* 277 */     return ('A' <= c) && (c <= 'Z');
/*     */   }
/*     */   
/*     */   int getChunkType() {
/* 281 */     if (typeMatchesArray(TYPE_IHDR)) return 0;
/* 282 */     if (typeMatchesArray(TYPE_PLTE)) return 1;
/* 283 */     if (typeMatchesArray(TYPE_IDAT)) return 2;
/* 284 */     if (typeMatchesArray(TYPE_IEND)) return 3;
/* 285 */     if (typeMatchesArray(TYPE_tRNS)) return 5;
/* 286 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   static PngChunk readNextFromStream(LEDataInputStream stream)
/*     */   {
/*     */     try
/*     */     {
/* 295 */       int headerLength = 8;
/* 296 */       byte[] headerBytes = new byte[headerLength];
/* 297 */       int result = stream.read(headerBytes, 0, headerLength);
/* 298 */       stream.unread(headerBytes);
/* 299 */       if (result != headerLength) { return null;
/*     */       }
/* 301 */       PngChunk tempChunk = new PngChunk(headerBytes);
/*     */       
/* 303 */       int chunkLength = tempChunk.getSize();
/* 304 */       byte[] chunk = new byte[chunkLength];
/* 305 */       result = stream.read(chunk, 0, chunkLength);
/* 306 */       if (result != chunkLength) { return null;
/*     */       }
/* 308 */       switch (tempChunk.getChunkType()) {
/*     */       case 0: 
/* 310 */         return new PngIhdrChunk(chunk);
/*     */       case 1: 
/* 312 */         return new PngPlteChunk(chunk);
/*     */       case 2: 
/* 314 */         return new PngIdatChunk(chunk);
/*     */       case 3: 
/* 316 */         return new PngIendChunk(chunk);
/*     */       case 5: 
/* 318 */         return new PngTrnsChunk(chunk);
/*     */       }
/* 320 */       return new PngChunk(chunk);
/*     */     }
/*     */     catch (IOException e) {}
/* 323 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   void validate(PngFileReadState readState, PngIhdrChunk headerChunk)
/*     */   {
/* 331 */     if (this.reference.length < 12) { SWT.error(40);
/*     */     }
/* 333 */     byte[] type = getTypeBytes();
/*     */     
/*     */ 
/* 336 */     char c = (char)type[2];
/* 337 */     if (('A' > c) || (c > 'Z')) { SWT.error(40);
/*     */     }
/*     */     
/* 340 */     for (int i = 0; i < 4; i++) {
/* 341 */       c = (char)type[i];
/* 342 */       if ((('a' > c) || (c > 'z')) && (('A' > c) || (c > 'Z'))) {
/* 343 */         SWT.error(40);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 348 */     if (!checkCRC()) { SWT.error(40);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   int length;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 365 */     StringBuilder buffer = new StringBuilder();
/* 366 */     buffer.append("{");
/* 367 */     buffer.append("\n\tLength: ");
/* 368 */     buffer.append(getLength());
/* 369 */     buffer.append("\n\tType: ");
/* 370 */     byte[] type = getTypeBytes();
/* 371 */     for (int i = 0; i < type.length; i++) {
/* 372 */       buffer.append((char)type[i]);
/*     */     }
/*     */     
/* 375 */     contributeToString(buffer);
/*     */     
/* 377 */     buffer.append("\n\tCRC: ");
/* 378 */     buffer.append(Integer.toHexString(getCRC()));
/* 379 */     buffer.append("\n}");
/* 380 */     return buffer.toString();
/*     */   }
/*     */   
/*     */   void contributeToString(StringBuilder buffer) {}
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/internal/image/PngChunk.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */