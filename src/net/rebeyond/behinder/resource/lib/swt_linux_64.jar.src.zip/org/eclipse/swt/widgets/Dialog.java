/*     */ package org.eclipse.swt.widgets;
/*     */ 
/*     */ import org.eclipse.swt.SWT;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Dialog
/*     */ {
/*     */   int style;
/*     */   Shell parent;
/*     */   String title;
/*     */   
/*     */   public Dialog(Shell parent)
/*     */   {
/*  97 */     this(parent, 32768);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Dialog(Shell parent, int style)
/*     */   {
/* 127 */     checkParent(parent);
/* 128 */     this.parent = parent;
/* 129 */     this.style = style;
/* 130 */     this.title = "";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void checkSubclass()
/*     */   {
/* 146 */     if (!Display.isValidClass(getClass())) {
/* 147 */       error(43);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void checkParent(Shell parent)
/*     */   {
/* 164 */     if (parent == null) error(4);
/* 165 */     parent.checkWidget();
/*     */   }
/*     */   
/*     */   static int checkStyle(Shell parent, int style) {
/* 169 */     int mask = 229376;
/* 170 */     if ((style & 0x10000000) != 0) {
/* 171 */       style &= 0xEFFFFFFF;
/* 172 */       if ((style & mask) == 0) {
/* 173 */         style |= (parent == null ? 65536 : 32768);
/*     */       }
/*     */     }
/* 176 */     if ((style & mask) == 0) {
/* 177 */       style |= 0x10000;
/*     */     }
/* 179 */     style &= 0xF7FFFFFF;
/* 180 */     if (((style & 0x6000000) == 0) && 
/* 181 */       (parent != null)) {
/* 182 */       if ((parent.style & 0x2000000) != 0) style |= 0x2000000;
/* 183 */       if ((parent.style & 0x4000000) != 0) { style |= 0x4000000;
/*     */       }
/*     */     }
/* 186 */     return Widget.checkBits(style, 33554432, 67108864, 0, 0, 0, 0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void error(int code)
/*     */   {
/* 198 */     SWT.error(code);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Shell getParent()
/*     */   {
/* 213 */     return this.parent;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getStyle()
/*     */   {
/* 232 */     return this.style;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getText()
/*     */   {
/* 249 */     return this.title;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setText(String string)
/*     */   {
/* 268 */     if (string == null) error(4);
/* 269 */     this.title = string;
/*     */   }
/*     */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/widgets/Dialog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */