/*    */ package org.eclipse.swt.internal.gtk;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PangoLogAttr
/*    */ {
/*    */   public boolean is_line_break;
/*    */   
/*    */ 
/*    */   public boolean is_mandatory_break;
/*    */   
/*    */ 
/*    */   public boolean is_char_break;
/*    */   
/*    */   public boolean is_white;
/*    */   
/*    */   public boolean is_cursor_position;
/*    */   
/*    */   public boolean is_word_start;
/*    */   
/*    */   public boolean is_word_end;
/*    */   
/*    */   public boolean is_sentence_boundary;
/*    */   
/*    */   public boolean is_sentence_start;
/*    */   
/*    */   public boolean is_sentence_end;
/*    */   
/* 29 */   public static final int sizeof = ;
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/internal/gtk/PangoLogAttr.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */