/*    */ package org.eclipse.swt.custom;
/*    */ 
/*    */ import org.eclipse.swt.events.VerifyEvent;
/*    */ import org.eclipse.swt.internal.SWTEventListener;
/*    */ import org.eclipse.swt.widgets.Event;
/*    */ import org.eclipse.swt.widgets.TypedListener;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class StyledTextListener
/*    */   extends TypedListener
/*    */ {
/*    */   StyledTextListener(SWTEventListener listener)
/*    */   {
/* 21 */     super(listener);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void handleEvent(Event e)
/*    */   {
/* 31 */     switch (e.type) {
/*    */     case 3000: 
/* 33 */       ExtendedModifyEvent extendedModifyEvent = new ExtendedModifyEvent((StyledTextEvent)e);
/* 34 */       ((ExtendedModifyListener)this.eventListener).modifyText(extendedModifyEvent);
/* 35 */       break;
/*    */     case 3001: 
/* 37 */       LineBackgroundEvent lineBgEvent = new LineBackgroundEvent((StyledTextEvent)e);
/* 38 */       ((LineBackgroundListener)this.eventListener).lineGetBackground(lineBgEvent);
/* 39 */       ((StyledTextEvent)e).lineBackground = lineBgEvent.lineBackground;
/* 40 */       break;
/*    */     case 3007: 
/* 42 */       BidiSegmentEvent segmentEvent = new BidiSegmentEvent((StyledTextEvent)e);
/* 43 */       ((BidiSegmentListener)this.eventListener).lineGetSegments(segmentEvent);
/* 44 */       ((StyledTextEvent)e).segments = segmentEvent.segments;
/* 45 */       ((StyledTextEvent)e).segmentsChars = segmentEvent.segmentsChars;
/* 46 */       break;
/*    */     case 3002: 
/* 48 */       LineStyleEvent lineStyleEvent = new LineStyleEvent((StyledTextEvent)e);
/* 49 */       ((LineStyleListener)this.eventListener).lineGetStyle(lineStyleEvent);
/* 50 */       ((StyledTextEvent)e).ranges = lineStyleEvent.ranges;
/* 51 */       ((StyledTextEvent)e).styles = lineStyleEvent.styles;
/* 52 */       ((StyledTextEvent)e).alignment = lineStyleEvent.alignment;
/* 53 */       ((StyledTextEvent)e).indent = lineStyleEvent.indent;
/* 54 */       ((StyledTextEvent)e).wrapIndent = lineStyleEvent.wrapIndent;
/* 55 */       ((StyledTextEvent)e).justify = lineStyleEvent.justify;
/* 56 */       ((StyledTextEvent)e).bullet = lineStyleEvent.bullet;
/* 57 */       ((StyledTextEvent)e).bulletIndex = lineStyleEvent.bulletIndex;
/* 58 */       ((StyledTextEvent)e).tabStops = lineStyleEvent.tabStops;
/* 59 */       break;
/*    */     case 3008: 
/* 61 */       PaintObjectEvent paintObjectEvent = new PaintObjectEvent((StyledTextEvent)e);
/* 62 */       ((PaintObjectListener)this.eventListener).paintObject(paintObjectEvent);
/* 63 */       break;
/*    */     case 3005: 
/* 65 */       VerifyEvent verifyEvent = new VerifyEvent(e);
/* 66 */       ((VerifyKeyListener)this.eventListener).verifyKey(verifyEvent);
/* 67 */       e.doit = verifyEvent.doit;
/* 68 */       break;
/*    */     case 3006: 
/* 70 */       TextChangedEvent textChangedEvent = new TextChangedEvent((StyledTextContent)e.data);
/* 71 */       ((TextChangeListener)this.eventListener).textChanged(textChangedEvent);
/* 72 */       break;
/*    */     
/*    */     case 3003: 
/* 75 */       TextChangingEvent textChangingEvent = new TextChangingEvent((StyledTextContent)e.data, (StyledTextEvent)e);
/* 76 */       ((TextChangeListener)this.eventListener).textChanging(textChangingEvent);
/* 77 */       break;
/*    */     case 3004: 
/* 79 */       TextChangedEvent textChangedEvent = new TextChangedEvent((StyledTextContent)e.data);
/* 80 */       ((TextChangeListener)this.eventListener).textSet(textChangedEvent);
/* 81 */       break;
/*    */     
/*    */     case 3009: 
/* 84 */       MovementEvent wordBoundaryEvent = new MovementEvent((StyledTextEvent)e);
/* 85 */       ((MovementListener)this.eventListener).getNextOffset(wordBoundaryEvent);
/* 86 */       ((StyledTextEvent)e).end = wordBoundaryEvent.newOffset;
/* 87 */       break;
/*    */     
/*    */     case 3010: 
/* 90 */       MovementEvent wordBoundaryEvent = new MovementEvent((StyledTextEvent)e);
/* 91 */       ((MovementListener)this.eventListener).getPreviousOffset(wordBoundaryEvent);
/* 92 */       ((StyledTextEvent)e).end = wordBoundaryEvent.newOffset;
/* 93 */       break;
/*    */     
/*    */     case 3011: 
/* 96 */       CaretEvent caretEvent = new CaretEvent((StyledTextEvent)e);
/* 97 */       ((CaretListener)this.eventListener).caretMoved(caretEvent);
/* 98 */       ((StyledTextEvent)e).end = caretEvent.caretOffset;
/* 99 */       break;
/*    */     }
/*    */   }
/*    */ }


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_64.jar!/org/eclipse/swt/custom/StyledTextListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */