package org.eclipse.swt.internal.webkit;

import org.eclipse.swt.internal.ole.win32.COM;
import org.eclipse.swt.internal.ole.win32.IUnknown;

public class IWebFramePrivate
  extends IUnknown
{
  public IWebFramePrivate(int paramInt)
  {
    super(paramInt);
  }
  
  public int setInPrintingMode(int paramInt1, int paramInt2)
  {
    return COM.VtblCall(8, getAddress(), paramInt1, paramInt2);
  }
  
  public int getPrintedPageCount(int paramInt, int[] paramArrayOfInt)
  {
    return COM.VtblCall(9, getAddress(), paramInt, paramArrayOfInt);
  }
  
  public int spoolPages(int paramInt1, int paramInt2, int paramInt3, int[] paramArrayOfInt)
  {
    return COM.VtblCall(10, getAddress(), paramInt1, paramInt2, paramInt3, paramArrayOfInt);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_32.jar!/org/eclipse/swt/internal/webkit/IWebFramePrivate.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */