package org.eclipse.swt.custom;

import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Cursor;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

public class BusyIndicator
{
  static int nextBusyId = 1;
  static final String BUSYID_NAME = "SWT BusyIndicator";
  static final String BUSY_CURSOR = "SWT BusyIndicator Cursor";
  
  public static void showWhile(Display paramDisplay, Runnable paramRunnable)
  {
    if (paramRunnable == null) {
      SWT.error(4);
    }
    if (paramDisplay == null)
    {
      paramDisplay = Display.getCurrent();
      if (paramDisplay == null)
      {
        paramRunnable.run();
        return;
      }
    }
    Integer localInteger1 = new Integer(nextBusyId);
    nextBusyId += 1;
    Cursor localCursor = paramDisplay.getSystemCursor(1);
    Shell[] arrayOfShell = paramDisplay.getShells();
    for (int i = 0; i < arrayOfShell.length; i++)
    {
      Integer localInteger2 = (Integer)arrayOfShell[i].getData("SWT BusyIndicator");
      if (localInteger2 == null)
      {
        arrayOfShell[i].setCursor(localCursor);
        arrayOfShell[i].setData("SWT BusyIndicator", localInteger1);
      }
    }
    try
    {
      paramRunnable.run();
    }
    finally
    {
      arrayOfShell = paramDisplay.getShells();
      for (int j = 0; j < arrayOfShell.length; j++)
      {
        Integer localInteger3 = (Integer)arrayOfShell[j].getData("SWT BusyIndicator");
        if (localInteger3 == localInteger1)
        {
          arrayOfShell[j].setCursor(null);
          arrayOfShell[j].setData("SWT BusyIndicator", null);
        }
      }
    }
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_32.jar!/org/eclipse/swt/custom/BusyIndicator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */