package org.eclipse.swt.internal.ole.win32;

public class FUNCDESC
{
  public int memid;
  public int lprgscode;
  public int lprgelemdescParam;
  public int funckind;
  public int invkind;
  public int callconv;
  public short cParams;
  public short cParamsOpt;
  public short oVft;
  public short cScodes;
  public int elemdescFunc_tdesc_union;
  public short elemdescFunc_tdesc_vt;
  public int elemdescFunc_paramdesc_pparamdescex;
  public short elemdescFunc_paramdesc_wParamFlags;
  public short wFuncFlags;
  public static final int sizeof = ;
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_32.jar!/org/eclipse/swt/internal/ole/win32/FUNCDESC.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */