package org.eclipse.swt.internal.mozilla;

public class nsIBaseWindow
  extends nsISupports
{
  static final int LAST_METHOD_ID = nsISupports.LAST_METHOD_ID + (IsXULRunner10() ? 22 : 24);
  static final String NS_IBASEWINDOW_IID_STR = "046bc8a0-8015-11d3-af70-00a024ffc08c";
  static final String NS_IBASEWINDOW_10_IID_STR = "7144ac8b-6702-4a4b-a73d-d1d4e9717e46";
  static final String NS_IBASEWINDOW_24_IID_STR = "9da319f3-eee6-4504-81a5-6a19cf6215bf";
  
  public nsIBaseWindow(int paramInt)
  {
    super(paramInt);
  }
  
  public int InitWindow(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 1, getAddress(), paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6);
  }
  
  public int Create()
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 2, getAddress());
  }
  
  public int Destroy()
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 3, getAddress());
  }
  
  public int SetPositionAndSize(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 8, getAddress(), paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
  }
  
  public int GetParentNativeWindow(int[] paramArrayOfInt)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 13, getAddress(), paramArrayOfInt);
  }
  
  public int SetVisibility(int paramInt)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + (IsXULRunner24() ? 17 : 16), getAddress(), paramInt);
  }
  
  public int SetFocus()
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + (IsXULRunner10() ? 20 : 22), getAddress());
  }
  
  static
  {
    IIDStore.RegisterIID(nsIBaseWindow.class, 0, new nsID("046bc8a0-8015-11d3-af70-00a024ffc08c"));
    IIDStore.RegisterIID(nsIBaseWindow.class, 5, new nsID("7144ac8b-6702-4a4b-a73d-d1d4e9717e46"));
    IIDStore.RegisterIID(nsIBaseWindow.class, 6, new nsID("9da319f3-eee6-4504-81a5-6a19cf6215bf"));
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_32.jar!/org/eclipse/swt/internal/mozilla/nsIBaseWindow.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */