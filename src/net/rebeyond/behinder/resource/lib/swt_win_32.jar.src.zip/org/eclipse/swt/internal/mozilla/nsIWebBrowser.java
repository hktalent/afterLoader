package org.eclipse.swt.internal.mozilla;

public class nsIWebBrowser
  extends nsISupports
{
  static final int LAST_METHOD_ID = nsISupports.LAST_METHOD_ID + ((IsXULRunner10()) || (IsXULRunner24()) ? 9 : 7);
  static final String NS_IWEBBROWSER_IID_STR = "69e5df00-7b8b-11d3-af61-00a024ffc08c";
  static final String NS_IWEBBROWSER_10_IID_STR = "33e9d001-caab-4ba9-8961-54902f197202";
  
  public nsIWebBrowser(int paramInt)
  {
    super(paramInt);
  }
  
  public int AddWebBrowserListener(int paramInt, nsID paramnsID)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 1, getAddress(), paramInt, paramnsID);
  }
  
  public int RemoveWebBrowserListener(int paramInt, nsID paramnsID)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 2, getAddress(), paramInt, paramnsID);
  }
  
  public int SetContainerWindow(int paramInt)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 4, getAddress(), paramInt);
  }
  
  public int SetParentURIContentListener(int paramInt)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 6, getAddress(), paramInt);
  }
  
  public int GetContentDOMWindow(int[] paramArrayOfInt)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 7, getAddress(), paramArrayOfInt);
  }
  
  static
  {
    IIDStore.RegisterIID(nsIWebBrowser.class, 0, new nsID("69e5df00-7b8b-11d3-af61-00a024ffc08c"));
    IIDStore.RegisterIID(nsIWebBrowser.class, 5, new nsID("33e9d001-caab-4ba9-8961-54902f197202"));
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_32.jar!/org/eclipse/swt/internal/mozilla/nsIWebBrowser.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */