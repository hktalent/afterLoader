package org.eclipse.swt.browser;

import org.eclipse.swt.internal.C;
import org.eclipse.swt.internal.mozilla.IIDStore;
import org.eclipse.swt.internal.mozilla.XPCOM;
import org.eclipse.swt.internal.mozilla.XPCOMObject;
import org.eclipse.swt.internal.mozilla.nsID;
import org.eclipse.swt.internal.mozilla.nsISupports;

class DownloadFactory_1_8
{
  XPCOMObject supports;
  XPCOMObject factory;
  int refCount = 0;
  
  DownloadFactory_1_8()
  {
    createCOMInterfaces();
  }
  
  int AddRef()
  {
    this.refCount += 1;
    return this.refCount;
  }
  
  void createCOMInterfaces()
  {
    this.supports = new XPCOMObject(new int[] { 2, 0, 0 })
    {
      public int method0(int[] paramAnonymousArrayOfInt)
      {
        return DownloadFactory_1_8.this.QueryInterface(paramAnonymousArrayOfInt[0], paramAnonymousArrayOfInt[1]);
      }
      
      public int method1(int[] paramAnonymousArrayOfInt)
      {
        return DownloadFactory_1_8.this.AddRef();
      }
      
      public int method2(int[] paramAnonymousArrayOfInt)
      {
        return DownloadFactory_1_8.this.Release();
      }
    };
    this.factory = new XPCOMObject(new int[] { 2, 0, 0, 3, 1 })
    {
      public int method0(int[] paramAnonymousArrayOfInt)
      {
        return DownloadFactory_1_8.this.QueryInterface(paramAnonymousArrayOfInt[0], paramAnonymousArrayOfInt[1]);
      }
      
      public int method1(int[] paramAnonymousArrayOfInt)
      {
        return DownloadFactory_1_8.this.AddRef();
      }
      
      public int method2(int[] paramAnonymousArrayOfInt)
      {
        return DownloadFactory_1_8.this.Release();
      }
      
      public int method3(int[] paramAnonymousArrayOfInt)
      {
        return DownloadFactory_1_8.this.CreateInstance(paramAnonymousArrayOfInt[0], paramAnonymousArrayOfInt[1], paramAnonymousArrayOfInt[2]);
      }
      
      public int method4(int[] paramAnonymousArrayOfInt)
      {
        return DownloadFactory_1_8.this.LockFactory(paramAnonymousArrayOfInt[0]);
      }
    };
  }
  
  void disposeCOMInterfaces()
  {
    if (this.supports != null)
    {
      this.supports.dispose();
      this.supports = null;
    }
    if (this.factory != null)
    {
      this.factory.dispose();
      this.factory = null;
    }
  }
  
  int getAddress()
  {
    return this.factory.getAddress();
  }
  
  int QueryInterface(int paramInt1, int paramInt2)
  {
    if ((paramInt1 == 0) || (paramInt2 == 0)) {
      return -2147467262;
    }
    nsID localnsID = new nsID();
    XPCOM.memmove(localnsID, paramInt1, 16);
    if (localnsID.Equals(IIDStore.GetIID(nsISupports.class)))
    {
      XPCOM.memmove(paramInt2, new int[] { this.supports.getAddress() }, C.PTR_SIZEOF);
      AddRef();
      return 0;
    }
    if (localnsID.Equals(XPCOM.NS_IFACTORY_IID))
    {
      XPCOM.memmove(paramInt2, new int[] { this.factory.getAddress() }, C.PTR_SIZEOF);
      AddRef();
      return 0;
    }
    XPCOM.memmove(paramInt2, new int[] { 0 }, C.PTR_SIZEOF);
    return -2147467262;
  }
  
  int Release()
  {
    this.refCount -= 1;
    if (this.refCount == 0) {
      disposeCOMInterfaces();
    }
    return this.refCount;
  }
  
  int CreateInstance(int paramInt1, int paramInt2, int paramInt3)
  {
    Download_1_8 localDownload_1_8 = new Download_1_8();
    localDownload_1_8.AddRef();
    XPCOM.memmove(paramInt3, new int[] { localDownload_1_8.getAddress() }, C.PTR_SIZEOF);
    return 0;
  }
  
  int LockFactory(int paramInt)
  {
    return 0;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_32.jar!/org/eclipse/swt/browser/DownloadFactory_1_8.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */