package org.eclipse.swt.browser;

import java.util.Hashtable;
import org.eclipse.swt.SWT;
import org.eclipse.swt.SWTException;
import org.eclipse.swt.internal.C;
import org.eclipse.swt.internal.Callback;
import org.eclipse.swt.internal.mozilla.IIDStore;
import org.eclipse.swt.internal.mozilla.MozillaVersion;
import org.eclipse.swt.internal.mozilla.XPCOM;
import org.eclipse.swt.internal.mozilla.XPCOMObject;
import org.eclipse.swt.internal.mozilla.nsIClassInfo;
import org.eclipse.swt.internal.mozilla.nsIComponentManager;
import org.eclipse.swt.internal.mozilla.nsID;
import org.eclipse.swt.internal.mozilla.nsIMemory;
import org.eclipse.swt.internal.mozilla.nsIServiceManager;
import org.eclipse.swt.internal.mozilla.nsISupports;
import org.eclipse.swt.internal.mozilla.nsIVariant;
import org.eclipse.swt.internal.mozilla.nsIWritableVariant;
import org.eclipse.swt.internal.mozilla.nsIXPConnect;

class External
{
  public static final String EXTERNAL_IID_STR = "ded01d20-ba6f-11dd-ad8b-0800200c9a66";
  public static final nsID EXTERNAL_IID = new nsID("ded01d20-ba6f-11dd-ad8b-0800200c9a66");
  XPCOMObject supports;
  XPCOMObject external;
  XPCOMObject classInfo;
  XPCOMObject securityCheckedComponent;
  XPCOMObject scriptObjectOwner;
  XPCOMObject xpcScriptable;
  int refCount = 0;
  static final String CALLJAVA = "callJava";
  static Callback CallJavaProc;
  static Callback GetScriptableFlags24Proc = null;
  
  External()
  {
    createCOMInterfaces();
  }
  
  static int callJava(int paramInt1, int paramInt2, int paramInt3)
  {
    int i = 8;
    int j = paramInt3 + 2 * i;
    nsIVariant localnsIVariant = null;
    int[] arrayOfInt1 = new int[1];
    int k = XPCOM.NS_GetServiceManager(arrayOfInt1);
    if (k != 0) {
      Mozilla.error(k);
    }
    if (arrayOfInt1[0] == 0) {
      Mozilla.error(-2147467262);
    }
    nsIServiceManager localnsIServiceManager = new nsIServiceManager(arrayOfInt1[0]);
    arrayOfInt1[0] = 0;
    k = localnsIServiceManager.GetService(XPCOM.NS_IXPCONNECT_CID, IIDStore.GetIID(nsIXPConnect.class), arrayOfInt1);
    if (k != 0) {
      Mozilla.error(k);
    }
    if (arrayOfInt1[0] == 0) {
      Mozilla.error(-2147467262);
    }
    nsIXPConnect localnsIXPConnect = new nsIXPConnect(arrayOfInt1[0]);
    arrayOfInt1[0] = 0;
    k = localnsIXPConnect.JSValToVariant(paramInt1, j, arrayOfInt1);
    if ((k == 0) && (arrayOfInt1[0] != 0))
    {
      localObject1 = new nsIVariant(arrayOfInt1[0]);
      arrayOfInt1[0] = 0;
      localObject2 = new short[1];
      k = ((nsIVariant)localObject1).GetDataType((short[])localObject2);
      if ((k == 0) && (localObject2[0] == 2))
      {
        int[] arrayOfInt2 = new int[1];
        k = ((nsIVariant)localObject1).GetAsInt32(arrayOfInt2);
        if (k == 0)
        {
          n = arrayOfInt2[0];
          j += i;
          k = localnsIXPConnect.JSValToVariant(paramInt1, j, arrayOfInt1);
          if ((k == 0) && (arrayOfInt1[0] != 0))
          {
            i1 = arrayOfInt1[0];
            arrayOfInt1[0] = 0;
            j += i;
            k = localnsIXPConnect.JSValToVariant(paramInt1, j, arrayOfInt1);
            if ((k == 0) && (arrayOfInt1[0] != 0))
            {
              int i2 = arrayOfInt1[0];
              arrayOfInt1[0] = 0;
              localnsIVariant = new nsIVariant(invokeFunction(n, i1, i2));
              new nsISupports(i2).Release();
            }
            new nsISupports(i1).Release();
          }
        }
      }
      ((nsIVariant)localObject1).Release();
    }
    arrayOfInt1[0] = 0;
    if (localnsIVariant == null)
    {
      k = XPCOM.NS_GetComponentManager(arrayOfInt1);
      if (k != 0) {
        Mozilla.error(k);
      }
      if (arrayOfInt1[0] == 0) {
        Mozilla.error(-2147467262);
      }
      localObject1 = new nsIComponentManager(arrayOfInt1[0]);
      arrayOfInt1[0] = 0;
      localnsIVariant = convertToJS(null, (nsIComponentManager)localObject1);
      ((nsIComponentManager)localObject1).Release();
    }
    Object localObject1 = MozillaDelegate.wcsToMbcs(null, "@mozilla.org/xpcom/memory-service;1", true);
    k = localnsIServiceManager.GetServiceByContractID((byte[])localObject1, IIDStore.GetIID(nsIMemory.class), arrayOfInt1);
    if (k != 0) {
      Mozilla.error(k);
    }
    if (arrayOfInt1[0] == 0) {
      Mozilla.error(-2147467262);
    }
    localnsIServiceManager.Release();
    Object localObject2 = new nsIMemory(arrayOfInt1[0]);
    arrayOfInt1[0] = 0;
    int m = ((nsIMemory)localObject2).Alloc(i);
    C.memset(m, 0, i);
    int n = 0;
    if (MozillaVersion.CheckVersion(6)) {
      n = XPCOM.JS_GetGlobalForScopeChain24(paramInt1);
    } else {
      n = XPCOM.JS_GetGlobalObject(Mozilla.getJSLibPathBytes(), paramInt1);
    }
    k = localnsIXPConnect.VariantToJS(paramInt1, n, localnsIVariant.getAddress(), m);
    localnsIVariant.Release();
    localnsIXPConnect.Release();
    int i1 = 0;
    if (k == 0)
    {
      C.memmove(paramInt3, m, i);
      i1 = 1;
    }
    ((nsIMemory)localObject2).Free(m);
    ((nsIMemory)localObject2).Release();
    return i1;
  }
  
  static int callJava(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    int i = invokeFunction(paramInt1, paramInt2, paramInt3);
    C.memmove(paramInt4, new int[] { i }, C.PTR_SIZEOF);
    return 0;
  }
  
  static Object convertToJava(nsIVariant paramnsIVariant, short paramShort)
  {
    int i;
    switch (paramShort)
    {
    case 13: 
    case 255: 
      return null;
    case 254: 
      return new Object[0];
    case 10: 
      int[] arrayOfInt1 = new int[1];
      i = paramnsIVariant.GetAsBool(arrayOfInt1);
      if (i != 0) {
        Mozilla.error(i);
      }
      return new Boolean(arrayOfInt1[0] != 0);
    case 2: 
      int[] arrayOfInt2 = new int[1];
      i = paramnsIVariant.GetAsInt32(arrayOfInt2);
      if (i != 0) {
        Mozilla.error(i);
      }
      return new Double(arrayOfInt2[0]);
    case 9: 
      int j = C.malloc(8);
      i = paramnsIVariant.GetAsDouble(j);
      if (i != 0) {
        Mozilla.error(i);
      }
      double[] arrayOfDouble = new double[1];
      C.memmove(arrayOfDouble, j, 8);
      C.free(j);
      return new Double(arrayOfDouble[0]);
    case 22: 
      int[] arrayOfInt3 = new int[1];
      int[] arrayOfInt4 = new int[1];
      i = paramnsIVariant.GetAsWStringWithSize(arrayOfInt3, arrayOfInt4);
      if (i != 0) {
        Mozilla.error(i);
      }
      char[] arrayOfChar1 = new char[arrayOfInt3[0]];
      C.memmove(arrayOfChar1, arrayOfInt4[0], arrayOfInt3[0] * 2);
      return new String(arrayOfChar1);
    case 20: 
      Object[] arrayOfObject = new Object[0];
      int k = C.malloc(16);
      C.memset(k, 0, 16);
      int[] arrayOfInt5 = new int[1];
      short[] arrayOfShort = new short[1];
      int[] arrayOfInt6 = new int[1];
      i = paramnsIVariant.GetAsArray(arrayOfShort, k, arrayOfInt5, arrayOfInt6);
      if (i != 0) {
        Mozilla.error(i);
      }
      if (arrayOfInt6[0] == 0) {
        Mozilla.error(-2147467261);
      }
      nsID localnsID = new nsID();
      XPCOM.memmove(localnsID, k, 16);
      C.free(k);
      int[] arrayOfInt7 = new int[1];
      i = XPCOM.NS_GetServiceManager(arrayOfInt7);
      if (i != 0) {
        Mozilla.error(i);
      }
      if (arrayOfInt7[0] == 0) {
        Mozilla.error(-2147467262);
      }
      nsIServiceManager localnsIServiceManager = new nsIServiceManager(arrayOfInt7[0]);
      arrayOfInt7[0] = 0;
      byte[] arrayOfByte = MozillaDelegate.wcsToMbcs(null, "@mozilla.org/xpcom/memory-service;1", true);
      i = localnsIServiceManager.GetServiceByContractID(arrayOfByte, IIDStore.GetIID(nsIMemory.class), arrayOfInt7);
      if (i != 0) {
        Mozilla.error(i);
      }
      if (arrayOfInt7[0] == 0) {
        Mozilla.error(-2147467262);
      }
      localnsIServiceManager.Release();
      nsIMemory localnsIMemory = new nsIMemory(arrayOfInt7[0]);
      arrayOfInt7[0] = 0;
      int m;
      Object localObject1;
      Object localObject2;
      if (localnsID.Equals(IIDStore.GetIID(nsIVariant.class)))
      {
        arrayOfObject = new Object[arrayOfInt5[0]];
        for (m = 0; m < arrayOfInt5[0]; m++)
        {
          localObject1 = new int[1];
          C.memmove((int[])localObject1, arrayOfInt6[0] + m * C.PTR_SIZEOF, C.PTR_SIZEOF);
          localObject2 = new nsISupports(localObject1[0]);
          i = ((nsISupports)localObject2).QueryInterface(localnsID, arrayOfInt7);
          if (i != 0) {
            Mozilla.error(i);
          }
          if (arrayOfInt7[0] == 0) {
            Mozilla.error(-2147467262);
          }
          nsIVariant localnsIVariant = new nsIVariant(arrayOfInt7[0]);
          arrayOfInt7[0] = 0;
          arrayOfShort[0] = 0;
          i = localnsIVariant.GetDataType(arrayOfShort);
          if (i != 0) {
            Mozilla.error(i);
          }
          try
          {
            arrayOfObject[m] = convertToJava(localnsIVariant, arrayOfShort[0]);
            localnsIVariant.Release();
          }
          catch (IllegalArgumentException localIllegalArgumentException)
          {
            localnsIVariant.Release();
            localnsIMemory.Free(arrayOfInt6[0]);
            localnsIMemory.Release();
            throw localIllegalArgumentException;
          }
        }
      }
      else
      {
        switch (arrayOfShort[0])
        {
        case 9: 
          arrayOfObject = new Object[arrayOfInt5[0]];
          for (m = 0; m < arrayOfInt5[0]; m++)
          {
            localObject1 = new double[1];
            C.memmove((double[])localObject1, arrayOfInt6[0] + m * 8, 8);
            arrayOfObject[m] = new Double(localObject1[0]);
          }
          break;
        case 10: 
          arrayOfObject = new Object[arrayOfInt5[0]];
          for (m = 0; m < arrayOfInt5[0]; m++) {
            if (MozillaVersion.CheckVersion(5))
            {
              localObject1 = new byte[1];
              C.memmove((byte[])localObject1, arrayOfInt6[0] + m, 1);
              arrayOfObject[m] = new Boolean(localObject1[0] != 0);
            }
            else
            {
              localObject1 = new int[1];
              C.memmove((int[])localObject1, arrayOfInt6[0] + m * 4, 4);
              arrayOfObject[m] = new Boolean(localObject1[0] != 0);
            }
          }
          break;
        case 2: 
          arrayOfObject = new Object[arrayOfInt5[0]];
          for (m = 0; m < arrayOfInt5[0]; m++)
          {
            localObject1 = new int[1];
            C.memmove((int[])localObject1, arrayOfInt6[0] + m * 4, 4);
            arrayOfObject[m] = new Double(localObject1[0]);
          }
          break;
        case 17: 
          arrayOfObject = new Object[arrayOfInt5[0]];
          for (m = 0; m < arrayOfInt5[0]; m++)
          {
            int n = arrayOfInt6[0] + m * C.PTR_SIZEOF;
            localObject2 = new int[1];
            C.memmove((int[])localObject2, n, C.PTR_SIZEOF);
            int i1 = XPCOM.strlen_PRUnichar(localObject2[0]);
            char[] arrayOfChar2 = new char[i1];
            XPCOM.memmove(arrayOfChar2, localObject2[0], i1 * 2);
            arrayOfObject[m] = new String(arrayOfChar2);
          }
          break;
        default: 
          localnsIMemory.Free(arrayOfInt6[0]);
          localnsIMemory.Release();
          SWT.error(5);
        }
      }
      localnsIMemory.Free(arrayOfInt6[0]);
      localnsIMemory.Release();
      return arrayOfObject;
    }
    SWT.error(5);
    return null;
  }
  
  static nsIVariant convertToJS(Object paramObject, nsIComponentManager paramnsIComponentManager)
  {
    int[] arrayOfInt1 = new int[1];
    byte[] arrayOfByte = MozillaDelegate.wcsToMbcs(null, "@mozilla.org/variant;1", true);
    int i = paramnsIComponentManager.CreateInstanceByContractID(arrayOfByte, 0, IIDStore.GetIID(nsIWritableVariant.class), arrayOfInt1);
    nsIWritableVariant localnsIWritableVariant = new nsIWritableVariant(arrayOfInt1[0]);
    arrayOfInt1[0] = 0;
    if (paramObject == null)
    {
      i = localnsIWritableVariant.SetAsEmpty();
      if (i != 0) {
        Mozilla.error(i);
      }
      return localnsIWritableVariant;
    }
    Object localObject1;
    int j;
    if ((paramObject instanceof String))
    {
      localObject1 = (String)paramObject;
      j = ((String)localObject1).length();
      char[] arrayOfChar = new char[j];
      ((String)localObject1).getChars(0, j, arrayOfChar, 0);
      i = localnsIWritableVariant.SetAsWStringWithSize(j, arrayOfChar);
      if (i != 0) {
        Mozilla.error(i);
      }
      return localnsIWritableVariant;
    }
    if ((paramObject instanceof Boolean))
    {
      localObject1 = (Boolean)paramObject;
      i = localnsIWritableVariant.SetAsBool(((Boolean)localObject1).booleanValue() ? 1 : 0);
      if (i != 0) {
        Mozilla.error(i);
      }
      return localnsIWritableVariant;
    }
    if ((paramObject instanceof Number))
    {
      localObject1 = (Number)paramObject;
      i = localnsIWritableVariant.SetAsDouble(((Number)localObject1).doubleValue());
      if (i != 0) {
        Mozilla.error(i);
      }
      return localnsIWritableVariant;
    }
    if ((paramObject instanceof Object[]))
    {
      localObject1 = (Object[])paramObject;
      j = localObject1.length;
      if (j == 0)
      {
        i = localnsIWritableVariant.SetAsEmptyArray();
        if (i != 0) {
          Mozilla.error(i);
        }
      }
      else
      {
        int k = C.malloc(C.PTR_SIZEOF * j);
        for (int m = 0; m < j; m++)
        {
          Object localObject2 = localObject1[m];
          try
          {
            nsIVariant localnsIVariant = convertToJS(localObject2, paramnsIComponentManager);
            C.memmove(k + C.PTR_SIZEOF * m, new int[] { localnsIVariant.getAddress() }, C.PTR_SIZEOF);
          }
          catch (SWTException localSWTException)
          {
            C.free(k);
            localnsIWritableVariant.Release();
            for (int n = 0; n < m; n++)
            {
              int[] arrayOfInt2 = new int[1];
              C.memmove(arrayOfInt2, k + C.PTR_SIZEOF * n, C.PTR_SIZEOF);
              new nsISupports(arrayOfInt2[0]).Release();
            }
            throw localSWTException;
          }
        }
        m = C.malloc(16);
        XPCOM.memmove(m, IIDStore.GetIID(nsIVariant.class), 16);
        i = localnsIWritableVariant.SetAsArray((short)19, m, j, k);
        C.free(m);
        C.free(k);
        if (i != 0) {
          Mozilla.error(i);
        }
      }
      return localnsIWritableVariant;
    }
    localnsIWritableVariant.Release();
    SWT.error(51);
    return null;
  }
  
  static int invokeFunction(int paramInt1, int paramInt2, int paramInt3)
  {
    Integer localInteger = new Integer(paramInt1);
    BrowserFunction localBrowserFunction = (BrowserFunction)Mozilla.AllFunctions.get(localInteger);
    Object localObject1 = null;
    Object localObject2;
    if (localBrowserFunction != null) {
      try
      {
        short[] arrayOfShort = new short[1];
        nsIVariant localnsIVariant = new nsIVariant(paramInt2);
        int j = localnsIVariant.GetDataType(arrayOfShort);
        if (j != 0) {
          Mozilla.error(j);
        }
        localObject2 = convertToJava(localnsIVariant, arrayOfShort[0]);
        arrayOfShort[0] = 0;
        if ((localObject2 instanceof String))
        {
          String str = (String)localObject2;
          if (str.equals(localBrowserFunction.token))
          {
            localnsIVariant = new nsIVariant(paramInt3);
            j = localnsIVariant.GetDataType(arrayOfShort);
            if (j != 0) {
              Mozilla.error(j);
            }
            localObject2 = convertToJava(localnsIVariant, arrayOfShort[0]);
            if ((localObject2 instanceof Object[]))
            {
              Object[] arrayOfObject = (Object[])localObject2;
              try
              {
                localObject1 = localBrowserFunction.function(arrayOfObject);
              }
              catch (Exception localException)
              {
                localObject1 = WebBrowser.CreateErrorString(localException.getLocalizedMessage());
              }
            }
          }
        }
      }
      catch (IllegalArgumentException localIllegalArgumentException)
      {
        if (localBrowserFunction.isEvaluate) {
          localBrowserFunction.function(new String[] { WebBrowser.CreateErrorString(new SWTException(51).getLocalizedMessage()) });
        }
        localObject1 = WebBrowser.CreateErrorString(localIllegalArgumentException.getLocalizedMessage());
      }
    }
    int[] arrayOfInt = new int[1];
    int i = XPCOM.NS_GetComponentManager(arrayOfInt);
    if (i != 0) {
      Mozilla.error(i);
    }
    if (arrayOfInt[0] == 0) {
      Mozilla.error(-2147467262);
    }
    nsIComponentManager localnsIComponentManager = new nsIComponentManager(arrayOfInt[0]);
    arrayOfInt[0] = 0;
    try
    {
      localObject2 = convertToJS(localObject1, localnsIComponentManager);
    }
    catch (SWTException localSWTException)
    {
      localObject2 = convertToJS(WebBrowser.CreateErrorString(localSWTException.getLocalizedMessage()), localnsIComponentManager);
    }
    localnsIComponentManager.Release();
    return ((nsIVariant)localObject2).getAddress();
  }
  
  int AddRef()
  {
    this.refCount += 1;
    return this.refCount;
  }
  
  void createCOMInterfaces()
  {
    this.supports = new XPCOMObject(new int[] { 2, 0, 0 })
    {
      public int method0(int[] paramAnonymousArrayOfInt)
      {
        return External.this.QueryInterface(paramAnonymousArrayOfInt[0], paramAnonymousArrayOfInt[1]);
      }
      
      public int method1(int[] paramAnonymousArrayOfInt)
      {
        return External.this.AddRef();
      }
      
      public int method2(int[] paramAnonymousArrayOfInt)
      {
        return External.this.Release();
      }
    };
    this.classInfo = new XPCOMObject(new int[] { 2, 0, 0, 2, 2, 1, 1, 1, 1, 1, 1 })
    {
      public int method0(int[] paramAnonymousArrayOfInt)
      {
        return External.this.QueryInterface(paramAnonymousArrayOfInt[0], paramAnonymousArrayOfInt[1]);
      }
      
      public int method1(int[] paramAnonymousArrayOfInt)
      {
        return External.this.AddRef();
      }
      
      public int method2(int[] paramAnonymousArrayOfInt)
      {
        return External.this.Release();
      }
      
      public int method3(int[] paramAnonymousArrayOfInt)
      {
        return External.this.getInterfaces(paramAnonymousArrayOfInt[0], paramAnonymousArrayOfInt[1]);
      }
      
      public int method4(int[] paramAnonymousArrayOfInt)
      {
        return External.this.getHelperForLanguage(paramAnonymousArrayOfInt[0], paramAnonymousArrayOfInt[1]);
      }
      
      public int method5(int[] paramAnonymousArrayOfInt)
      {
        return External.this.getContractID(paramAnonymousArrayOfInt[0]);
      }
      
      public int method6(int[] paramAnonymousArrayOfInt)
      {
        return External.this.getClassDescription(paramAnonymousArrayOfInt[0]);
      }
      
      public int method7(int[] paramAnonymousArrayOfInt)
      {
        return External.this.getClassID(paramAnonymousArrayOfInt[0]);
      }
      
      public int method8(int[] paramAnonymousArrayOfInt)
      {
        return External.this.getImplementationLanguage(paramAnonymousArrayOfInt[0]);
      }
      
      public int method9(int[] paramAnonymousArrayOfInt)
      {
        return External.this.getFlags(paramAnonymousArrayOfInt[0]);
      }
      
      public int method10(int[] paramAnonymousArrayOfInt)
      {
        return External.this.getClassIDNoAlloc(paramAnonymousArrayOfInt[0]);
      }
    };
    this.securityCheckedComponent = new XPCOMObject(new int[] { 2, 0, 0, 2, 3, 3, 3 })
    {
      public int method0(int[] paramAnonymousArrayOfInt)
      {
        return External.this.QueryInterface(paramAnonymousArrayOfInt[0], paramAnonymousArrayOfInt[1]);
      }
      
      public int method1(int[] paramAnonymousArrayOfInt)
      {
        return External.this.AddRef();
      }
      
      public int method2(int[] paramAnonymousArrayOfInt)
      {
        return External.this.Release();
      }
      
      public int method3(int[] paramAnonymousArrayOfInt)
      {
        return External.this.canCreateWrapper(paramAnonymousArrayOfInt[0], paramAnonymousArrayOfInt[1]);
      }
      
      public int method4(int[] paramAnonymousArrayOfInt)
      {
        return External.this.canCallMethod(paramAnonymousArrayOfInt[0], paramAnonymousArrayOfInt[1], paramAnonymousArrayOfInt[2]);
      }
      
      public int method5(int[] paramAnonymousArrayOfInt)
      {
        return External.this.canGetProperty(paramAnonymousArrayOfInt[0], paramAnonymousArrayOfInt[1], paramAnonymousArrayOfInt[2]);
      }
      
      public int method6(int[] paramAnonymousArrayOfInt)
      {
        return External.this.canSetProperty(paramAnonymousArrayOfInt[0], paramAnonymousArrayOfInt[1], paramAnonymousArrayOfInt[2]);
      }
    };
    this.external = new XPCOMObject(new int[] { 2, 0, 0, 4 })
    {
      public int method0(int[] paramAnonymousArrayOfInt)
      {
        return External.this.QueryInterface(paramAnonymousArrayOfInt[0], paramAnonymousArrayOfInt[1]);
      }
      
      public int method1(int[] paramAnonymousArrayOfInt)
      {
        return External.this.AddRef();
      }
      
      public int method2(int[] paramAnonymousArrayOfInt)
      {
        return External.this.Release();
      }
      
      public int method3(int[] paramAnonymousArrayOfInt)
      {
        return External.callJava(paramAnonymousArrayOfInt[0], paramAnonymousArrayOfInt[1], paramAnonymousArrayOfInt[2], paramAnonymousArrayOfInt[3]);
      }
    };
    this.scriptObjectOwner = new XPCOMObject(new int[] { 2, 0, 0, 2, 1 })
    {
      public int method0(int[] paramAnonymousArrayOfInt)
      {
        return External.this.QueryInterface(paramAnonymousArrayOfInt[0], paramAnonymousArrayOfInt[1]);
      }
      
      public int method1(int[] paramAnonymousArrayOfInt)
      {
        return External.this.AddRef();
      }
      
      public int method2(int[] paramAnonymousArrayOfInt)
      {
        return External.this.Release();
      }
      
      public int method3(int[] paramAnonymousArrayOfInt)
      {
        return External.this.getScriptObject(paramAnonymousArrayOfInt[0], paramAnonymousArrayOfInt[1]);
      }
      
      public int method4(int[] paramAnonymousArrayOfInt)
      {
        return External.this.setScriptObject(paramAnonymousArrayOfInt[0]);
      }
    };
    this.xpcScriptable = new XPCOMObject(new int[] { 2, 0, 0, 1, 0, 4, 3, 3, 3, 6, 5, 6, 6, 4, 7, 7, 6, 3, 7, 5, 5, 6, 4, 2 })
    {
      public int method0(int[] paramAnonymousArrayOfInt)
      {
        return External.this.QueryInterface(paramAnonymousArrayOfInt[0], paramAnonymousArrayOfInt[1]);
      }
      
      public int method1(int[] paramAnonymousArrayOfInt)
      {
        return External.this.AddRef();
      }
      
      public int method2(int[] paramAnonymousArrayOfInt)
      {
        return External.this.Release();
      }
      
      public int method3(int[] paramAnonymousArrayOfInt)
      {
        return External.this.getClassName(paramAnonymousArrayOfInt[0]);
      }
      
      public int method4(int[] paramAnonymousArrayOfInt)
      {
        return External.getScriptableFlags();
      }
      
      public int method7(int[] paramAnonymousArrayOfInt)
      {
        return External.this.postCreate(paramAnonymousArrayOfInt[0], paramAnonymousArrayOfInt[1], paramAnonymousArrayOfInt[2]);
      }
    };
    if (GetScriptableFlags24Proc != null)
    {
      int i = this.xpcScriptable.getVtable();
      int[] arrayOfInt1 = new int[1];
      C.memmove(arrayOfInt1, i, C.PTR_SIZEOF);
      int[] arrayOfInt2 = new int[24];
      C.memmove(arrayOfInt2, arrayOfInt1[0], C.PTR_SIZEOF * arrayOfInt2.length);
      arrayOfInt2[4] = XPCOM.CALLBACK_GetScriptableFlags24(GetScriptableFlags24Proc.getAddress());
      C.memmove(arrayOfInt1[0], arrayOfInt2, C.PTR_SIZEOF * arrayOfInt2.length);
    }
  }
  
  void disposeCOMInterfaces()
  {
    if (this.supports != null)
    {
      this.supports.dispose();
      this.supports = null;
    }
    if (this.classInfo != null)
    {
      this.classInfo.dispose();
      this.classInfo = null;
    }
    if (this.securityCheckedComponent != null)
    {
      this.securityCheckedComponent.dispose();
      this.securityCheckedComponent = null;
    }
    if (this.external != null)
    {
      this.external.dispose();
      this.external = null;
    }
    if (this.scriptObjectOwner != null)
    {
      this.scriptObjectOwner.dispose();
      this.scriptObjectOwner = null;
    }
    if (this.xpcScriptable != null)
    {
      this.xpcScriptable.dispose();
      this.xpcScriptable = null;
    }
  }
  
  int getAddress()
  {
    return this.external.getAddress();
  }
  
  int QueryInterface(int paramInt1, int paramInt2)
  {
    if ((paramInt1 == 0) || (paramInt2 == 0)) {
      return -2147467262;
    }
    nsID localnsID = new nsID();
    XPCOM.memmove(localnsID, paramInt1, 16);
    if (localnsID.Equals(IIDStore.GetIID(nsISupports.class)))
    {
      XPCOM.memmove(paramInt2, new int[] { this.supports.getAddress() }, C.PTR_SIZEOF);
      AddRef();
      return 0;
    }
    if (localnsID.Equals(IIDStore.GetIID(nsIClassInfo.class)))
    {
      XPCOM.memmove(paramInt2, new int[] { this.classInfo.getAddress() }, C.PTR_SIZEOF);
      AddRef();
      return 0;
    }
    if (localnsID.Equals(XPCOM.NS_ISECURITYCHECKEDCOMPONENT_IID))
    {
      XPCOM.memmove(paramInt2, new int[] { this.securityCheckedComponent.getAddress() }, C.PTR_SIZEOF);
      AddRef();
      return 0;
    }
    if (localnsID.Equals(EXTERNAL_IID))
    {
      XPCOM.memmove(paramInt2, new int[] { this.external.getAddress() }, C.PTR_SIZEOF);
      AddRef();
      return 0;
    }
    if (MozillaVersion.CheckVersion(5))
    {
      if (localnsID.Equals(XPCOM.NS_ISCRIPTOBJECTOWNER_IID))
      {
        XPCOM.memmove(paramInt2, new int[] { this.scriptObjectOwner.getAddress() }, C.PTR_SIZEOF);
        AddRef();
        return 0;
      }
      if ((MozillaVersion.CheckVersion(6)) && (localnsID.Equals(XPCOM.NS_IXPCSCRIPTABLE_IID)))
      {
        XPCOM.memmove(paramInt2, new int[] { this.xpcScriptable.getAddress() }, C.PTR_SIZEOF);
        AddRef();
        return 0;
      }
    }
    XPCOM.memmove(paramInt2, new int[] { 0 }, C.PTR_SIZEOF);
    return -2147467262;
  }
  
  int Release()
  {
    this.refCount -= 1;
    if (this.refCount == 0) {
      disposeCOMInterfaces();
    }
    return this.refCount;
  }
  
  int getClassDescription(int paramInt)
  {
    int[] arrayOfInt = new int[1];
    int i = XPCOM.NS_GetServiceManager(arrayOfInt);
    if (i != 0) {
      Mozilla.error(i);
    }
    if (arrayOfInt[0] == 0) {
      Mozilla.error(-2147467262);
    }
    nsIServiceManager localnsIServiceManager = new nsIServiceManager(arrayOfInt[0]);
    arrayOfInt[0] = 0;
    byte[] arrayOfByte1 = MozillaDelegate.wcsToMbcs(null, "@mozilla.org/xpcom/memory-service;1", true);
    i = localnsIServiceManager.GetServiceByContractID(arrayOfByte1, IIDStore.GetIID(nsIMemory.class), arrayOfInt);
    if (i != 0) {
      Mozilla.error(i);
    }
    if (arrayOfInt[0] == 0) {
      Mozilla.error(-2147467262);
    }
    localnsIServiceManager.Release();
    nsIMemory localnsIMemory = new nsIMemory(arrayOfInt[0]);
    arrayOfInt[0] = 0;
    byte[] arrayOfByte2 = MozillaDelegate.wcsToMbcs(null, "external", true);
    int j = localnsIMemory.Alloc(arrayOfByte2.length);
    C.memmove(j, arrayOfByte2, arrayOfByte2.length);
    C.memmove(paramInt, new int[] { j }, C.PTR_SIZEOF);
    localnsIMemory.Release();
    return 0;
  }
  
  int getClassID(int paramInt)
  {
    return 0;
  }
  
  int getClassIDNoAlloc(int paramInt)
  {
    return 0;
  }
  
  int getContractID(int paramInt)
  {
    return 0;
  }
  
  int getFlags(int paramInt)
  {
    C.memmove(paramInt, new int[] { 4 }, 4);
    return 0;
  }
  
  int getHelperForLanguage(int paramInt1, int paramInt2)
  {
    C.memmove(paramInt2, new int[] { 0 }, C.PTR_SIZEOF);
    return 0;
  }
  
  int getImplementationLanguage(int paramInt)
  {
    C.memmove(paramInt, new int[] { 5 }, 4);
    return 0;
  }
  
  int getInterfaces(int paramInt1, int paramInt2)
  {
    int[] arrayOfInt = new int[1];
    int i = XPCOM.NS_GetServiceManager(arrayOfInt);
    if (i != 0) {
      Mozilla.error(i);
    }
    if (arrayOfInt[0] == 0) {
      Mozilla.error(-2147467262);
    }
    nsIServiceManager localnsIServiceManager = new nsIServiceManager(arrayOfInt[0]);
    arrayOfInt[0] = 0;
    byte[] arrayOfByte = MozillaDelegate.wcsToMbcs(null, "@mozilla.org/xpcom/memory-service;1", true);
    i = localnsIServiceManager.GetServiceByContractID(arrayOfByte, IIDStore.GetIID(nsIMemory.class), arrayOfInt);
    if (i != 0) {
      Mozilla.error(i);
    }
    if (arrayOfInt[0] == 0) {
      Mozilla.error(-2147467262);
    }
    localnsIServiceManager.Release();
    nsIMemory localnsIMemory = new nsIMemory(arrayOfInt[0]);
    arrayOfInt[0] = 0;
    int j = localnsIMemory.Alloc(16);
    XPCOM.memmove(j, XPCOM.NS_ISECURITYCHECKEDCOMPONENT_IID, 16);
    int k = localnsIMemory.Alloc(16);
    XPCOM.memmove(k, EXTERNAL_IID, 16);
    int m = localnsIMemory.Alloc(3 * C.PTR_SIZEOF);
    C.memmove(m, new int[] { j }, C.PTR_SIZEOF);
    C.memmove(m + C.PTR_SIZEOF, new int[] { k }, C.PTR_SIZEOF);
    C.memmove(paramInt2, new int[] { m }, C.PTR_SIZEOF);
    localnsIMemory.Release();
    C.memmove(paramInt1, new int[] { 2 }, 4);
    return 0;
  }
  
  int getScriptObject(int paramInt1, int paramInt2)
  {
    byte[] arrayOfByte1 = Mozilla.getJSLibPathBytes();
    int i = XPCOM.nsIScriptContext_GetNativeContext(paramInt1);
    int j = XPCOM.JS_GetGlobalObject(arrayOfByte1, i);
    int k = XPCOM.JS_NewObject(arrayOfByte1, i, 0, 0, j);
    byte[] arrayOfByte2 = MozillaDelegate.wcsToMbcs(null, "callJava", true);
    int m = 7;
    XPCOM.JS_DefineFunction(arrayOfByte1, i, k, arrayOfByte2, XPCOM.CALLBACK_JSNative(CallJavaProc.getAddress()), 3, m);
    XPCOM.memmove(paramInt2, new int[] { k }, C.PTR_SIZEOF);
    return 0;
  }
  
  int setScriptObject(int paramInt)
  {
    return 1;
  }
  
  int canCreateWrapper(int paramInt1, int paramInt2)
  {
    int[] arrayOfInt = new int[1];
    int i = XPCOM.NS_GetServiceManager(arrayOfInt);
    if (i != 0) {
      Mozilla.error(i);
    }
    if (arrayOfInt[0] == 0) {
      Mozilla.error(-2147467262);
    }
    nsIServiceManager localnsIServiceManager = new nsIServiceManager(arrayOfInt[0]);
    arrayOfInt[0] = 0;
    byte[] arrayOfByte1 = MozillaDelegate.wcsToMbcs(null, "@mozilla.org/xpcom/memory-service;1", true);
    i = localnsIServiceManager.GetServiceByContractID(arrayOfByte1, IIDStore.GetIID(nsIMemory.class), arrayOfInt);
    if (i != 0) {
      Mozilla.error(i);
    }
    if (arrayOfInt[0] == 0) {
      Mozilla.error(-2147467262);
    }
    localnsIServiceManager.Release();
    nsIMemory localnsIMemory = new nsIMemory(arrayOfInt[0]);
    arrayOfInt[0] = 0;
    byte[] arrayOfByte2 = MozillaDelegate.wcsToMbcs(null, "allAccess", true);
    int j = localnsIMemory.Alloc(arrayOfByte2.length);
    C.memmove(j, arrayOfByte2, arrayOfByte2.length);
    C.memmove(paramInt2, new int[] { j }, C.PTR_SIZEOF);
    localnsIMemory.Release();
    return 0;
  }
  
  int canCallMethod(int paramInt1, int paramInt2, int paramInt3)
  {
    int[] arrayOfInt = new int[1];
    int i = XPCOM.NS_GetServiceManager(arrayOfInt);
    if (i != 0) {
      Mozilla.error(i);
    }
    if (arrayOfInt[0] == 0) {
      Mozilla.error(-2147467262);
    }
    nsIServiceManager localnsIServiceManager = new nsIServiceManager(arrayOfInt[0]);
    arrayOfInt[0] = 0;
    byte[] arrayOfByte1 = MozillaDelegate.wcsToMbcs(null, "@mozilla.org/xpcom/memory-service;1", true);
    i = localnsIServiceManager.GetServiceByContractID(arrayOfByte1, IIDStore.GetIID(nsIMemory.class), arrayOfInt);
    if (i != 0) {
      Mozilla.error(i);
    }
    if (arrayOfInt[0] == 0) {
      Mozilla.error(-2147467262);
    }
    localnsIServiceManager.Release();
    nsIMemory localnsIMemory = new nsIMemory(arrayOfInt[0]);
    arrayOfInt[0] = 0;
    int j = XPCOM.strlen_PRUnichar(paramInt2);
    char[] arrayOfChar = new char[j];
    XPCOM.memmove(arrayOfChar, paramInt2, j * 2);
    String str = new String(arrayOfChar);
    byte[] arrayOfByte2;
    if (str.equals("callJava")) {
      arrayOfByte2 = MozillaDelegate.wcsToMbcs(null, "allAccess", true);
    } else {
      arrayOfByte2 = MozillaDelegate.wcsToMbcs(null, "noAccess", true);
    }
    int k = localnsIMemory.Alloc(arrayOfByte2.length);
    C.memmove(k, arrayOfByte2, arrayOfByte2.length);
    C.memmove(paramInt3, new int[] { k }, C.PTR_SIZEOF);
    localnsIMemory.Release();
    return 0;
  }
  
  int canGetProperty(int paramInt1, int paramInt2, int paramInt3)
  {
    int[] arrayOfInt = new int[1];
    int i = XPCOM.NS_GetServiceManager(arrayOfInt);
    if (i != 0) {
      Mozilla.error(i);
    }
    if (arrayOfInt[0] == 0) {
      Mozilla.error(-2147467262);
    }
    nsIServiceManager localnsIServiceManager = new nsIServiceManager(arrayOfInt[0]);
    arrayOfInt[0] = 0;
    byte[] arrayOfByte1 = MozillaDelegate.wcsToMbcs(null, "@mozilla.org/xpcom/memory-service;1", true);
    i = localnsIServiceManager.GetServiceByContractID(arrayOfByte1, IIDStore.GetIID(nsIMemory.class), arrayOfInt);
    if (i != 0) {
      Mozilla.error(i);
    }
    if (arrayOfInt[0] == 0) {
      Mozilla.error(-2147467262);
    }
    localnsIServiceManager.Release();
    nsIMemory localnsIMemory = new nsIMemory(arrayOfInt[0]);
    arrayOfInt[0] = 0;
    byte[] arrayOfByte2 = MozillaDelegate.wcsToMbcs(null, "noAccess", true);
    int j = localnsIMemory.Alloc(arrayOfByte2.length);
    C.memmove(j, arrayOfByte2, arrayOfByte2.length);
    C.memmove(paramInt3, new int[] { j }, C.PTR_SIZEOF);
    localnsIMemory.Release();
    return 0;
  }
  
  int canSetProperty(int paramInt1, int paramInt2, int paramInt3)
  {
    int[] arrayOfInt = new int[1];
    int i = XPCOM.NS_GetServiceManager(arrayOfInt);
    if (i != 0) {
      Mozilla.error(i);
    }
    if (arrayOfInt[0] == 0) {
      Mozilla.error(-2147467262);
    }
    nsIServiceManager localnsIServiceManager = new nsIServiceManager(arrayOfInt[0]);
    arrayOfInt[0] = 0;
    byte[] arrayOfByte1 = MozillaDelegate.wcsToMbcs(null, "@mozilla.org/xpcom/memory-service;1", true);
    i = localnsIServiceManager.GetServiceByContractID(arrayOfByte1, IIDStore.GetIID(nsIMemory.class), arrayOfInt);
    if (i != 0) {
      Mozilla.error(i);
    }
    if (arrayOfInt[0] == 0) {
      Mozilla.error(-2147467262);
    }
    localnsIServiceManager.Release();
    nsIMemory localnsIMemory = new nsIMemory(arrayOfInt[0]);
    arrayOfInt[0] = 0;
    byte[] arrayOfByte2 = MozillaDelegate.wcsToMbcs(null, "noAccess", true);
    int j = localnsIMemory.Alloc(arrayOfByte2.length);
    C.memmove(j, arrayOfByte2, arrayOfByte2.length);
    C.memmove(paramInt3, new int[] { j }, C.PTR_SIZEOF);
    localnsIMemory.Release();
    return 0;
  }
  
  int getClassName(int paramInt)
  {
    int[] arrayOfInt = new int[1];
    int i = XPCOM.NS_GetServiceManager(arrayOfInt);
    if (i != 0) {
      Mozilla.error(i);
    }
    if (arrayOfInt[0] == 0) {
      Mozilla.error(-2147467262);
    }
    nsIServiceManager localnsIServiceManager = new nsIServiceManager(arrayOfInt[0]);
    arrayOfInt[0] = 0;
    byte[] arrayOfByte1 = MozillaDelegate.wcsToMbcs(null, "@mozilla.org/xpcom/memory-service;1", true);
    i = localnsIServiceManager.GetServiceByContractID(arrayOfByte1, IIDStore.GetIID(nsIMemory.class), arrayOfInt);
    if (i != 0) {
      Mozilla.error(i);
    }
    if (arrayOfInt[0] == 0) {
      Mozilla.error(-2147467262);
    }
    localnsIServiceManager.Release();
    nsIMemory localnsIMemory = new nsIMemory(arrayOfInt[0]);
    arrayOfInt[0] = 0;
    byte[] arrayOfByte2 = MozillaDelegate.wcsToMbcs(null, "external", true);
    int j = localnsIMemory.Alloc(arrayOfByte2.length);
    C.memmove(j, arrayOfByte2, arrayOfByte2.length);
    C.memmove(paramInt, new int[] { j }, C.PTR_SIZEOF);
    localnsIMemory.Release();
    return 0;
  }
  
  static int getScriptableFlags()
  {
    return 131076;
  }
  
  int postCreate(int paramInt1, int paramInt2, int paramInt3)
  {
    byte[] arrayOfByte = MozillaDelegate.wcsToMbcs(null, "callJava", true);
    int i = 7;
    XPCOM.JS_DefineFunction24(paramInt2, paramInt3, arrayOfByte, XPCOM.CALLBACK_JSNative(CallJavaProc.getAddress()), 3, i);
    return 0;
  }
  
  static
  {
    CallJavaProc = new Callback(External.class, "callJava", 3);
    if (CallJavaProc.getAddress() == 0) {
      SWT.error(3);
    }
    if ((MozillaVersion.CheckVersion(6)) && (SWT.getPlatform().equals("win32")))
    {
      GetScriptableFlags24Proc = new Callback(External.class, "getScriptableFlags", 0);
      if (GetScriptableFlags24Proc.getAddress() == 0) {
        SWT.error(3);
      }
    }
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_32.jar!/org/eclipse/swt/browser/External.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */