package org.eclipse.swt.internal.ole.win32;

public class IOleControl
  extends IUnknown
{
  public IOleControl(int paramInt)
  {
    super(paramInt);
  }
  
  public int GetControlInfo(CONTROLINFO paramCONTROLINFO)
  {
    return COM.VtblCall(3, this.address, paramCONTROLINFO);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_32.jar!/org/eclipse/swt/internal/ole/win32/IOleControl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */