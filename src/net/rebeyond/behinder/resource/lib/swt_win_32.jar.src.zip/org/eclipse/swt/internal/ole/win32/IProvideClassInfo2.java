package org.eclipse.swt.internal.ole.win32;

public class IProvideClassInfo2
  extends IProvideClassInfo
{
  public IProvideClassInfo2(int paramInt)
  {
    super(paramInt);
  }
  
  public int GetGUID(int paramInt, GUID paramGUID)
  {
    return COM.VtblCall(4, this.address, paramInt, paramGUID);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_32.jar!/org/eclipse/swt/internal/ole/win32/IProvideClassInfo2.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */