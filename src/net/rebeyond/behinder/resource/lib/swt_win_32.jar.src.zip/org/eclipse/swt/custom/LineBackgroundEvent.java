package org.eclipse.swt.custom;

import org.eclipse.swt.events.TypedEvent;
import org.eclipse.swt.graphics.Color;

public class LineBackgroundEvent
  extends TypedEvent
{
  public int lineOffset;
  public String lineText;
  public Color lineBackground;
  static final long serialVersionUID = 3978711687853324342L;
  
  public LineBackgroundEvent(StyledTextEvent paramStyledTextEvent)
  {
    super(paramStyledTextEvent);
    this.lineOffset = paramStyledTextEvent.detail;
    this.lineText = paramStyledTextEvent.text;
    this.lineBackground = paramStyledTextEvent.lineBackground;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_32.jar!/org/eclipse/swt/custom/LineBackgroundEvent.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */