package org.eclipse.swt.dnd;

import org.eclipse.swt.internal.ole.win32.FORMATETC;
import org.eclipse.swt.internal.ole.win32.STGMEDIUM;

public class TransferData
{
  public int type;
  public FORMATETC formatetc;
  public STGMEDIUM stgmedium;
  public int result = -2147467259;
  public int pIDataObject;
  
  static boolean sameType(TransferData paramTransferData1, TransferData paramTransferData2)
  {
    if (paramTransferData1 == paramTransferData2) {
      return true;
    }
    if ((paramTransferData1 == null) || (paramTransferData2 == null)) {
      return false;
    }
    return (paramTransferData1.type == paramTransferData2.type) && (paramTransferData1.formatetc.cfFormat == paramTransferData2.formatetc.cfFormat) && (paramTransferData1.formatetc.dwAspect == paramTransferData2.formatetc.dwAspect) && (paramTransferData1.formatetc.tymed == paramTransferData2.formatetc.tymed);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_32.jar!/org/eclipse/swt/dnd/TransferData.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */