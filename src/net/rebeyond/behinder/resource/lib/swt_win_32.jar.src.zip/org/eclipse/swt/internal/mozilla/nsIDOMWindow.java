package org.eclipse.swt.internal.mozilla;

public class nsIDOMWindow
  extends nsISupports
{
  static final int LAST_METHOD_ID = nsISupports.LAST_METHOD_ID + (IsXULRunner10() ? 129 : IsXULRunner24() ? 140 : 17);
  static final String NS_IDOMWINDOW_IID_STR = "a6cf906b-15b3-11d2-932e-00805f8add32";
  static final String NS_IDOMWINDOW_10_IID_STR = "8f577294-d572-4473-94b1-d2c5a74a2a74";
  static final String NS_IDOMWINDOW_24_IID_STR = "be62660a-e3f6-409c-a4a9-378364a9526f";
  
  public nsIDOMWindow(int paramInt)
  {
    super(paramInt);
  }
  
  public int GetDocument(int[] paramArrayOfInt)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + ((IsXULRunner10()) || (IsXULRunner24()) ? 3 : 1), getAddress(), paramArrayOfInt);
  }
  
  public int GetTop(int[] paramArrayOfInt)
  {
    if (IsXULRunner24()) {
      return GetRealTop(paramArrayOfInt);
    }
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + (IsXULRunner10() ? 21 : 3), getAddress(), paramArrayOfInt);
  }
  
  public int GetRealTop(int[] paramArrayOfInt)
  {
    if (!IsXULRunner24()) {
      return -2147467263;
    }
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 22, getAddress(), paramArrayOfInt);
  }
  
  public int GetFrames(int[] paramArrayOfInt)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + (IsXULRunner10() ? 62 : IsXULRunner24() ? 66 : 5), getAddress(), paramArrayOfInt);
  }
  
  static
  {
    IIDStore.RegisterIID(nsIDOMWindow.class, 0, new nsID("a6cf906b-15b3-11d2-932e-00805f8add32"));
    IIDStore.RegisterIID(nsIDOMWindow.class, 5, new nsID("8f577294-d572-4473-94b1-d2c5a74a2a74"));
    IIDStore.RegisterIID(nsIDOMWindow.class, 6, new nsID("be62660a-e3f6-409c-a4a9-378364a9526f"));
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_32.jar!/org/eclipse/swt/internal/mozilla/nsIDOMWindow.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */