package org.eclipse.swt.events;

import org.eclipse.swt.internal.SWTEventObject;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Widget;

public class TypedEvent
  extends SWTEventObject
{
  public Display display;
  public Widget widget;
  public int time;
  public Object data;
  static final long serialVersionUID = 3257285846578377524L;
  
  public TypedEvent(Object paramObject)
  {
    super(paramObject);
  }
  
  public TypedEvent(Event paramEvent)
  {
    super(paramEvent.widget);
    this.display = paramEvent.display;
    this.widget = paramEvent.widget;
    this.time = paramEvent.time;
    this.data = paramEvent.data;
  }
  
  String getName()
  {
    String str = getClass().getName();
    int i = str.lastIndexOf('.');
    if (i == -1) {
      return str;
    }
    return str.substring(i + 1, str.length());
  }
  
  public String toString()
  {
    return getName() + "{" + this.widget + " time=" + this.time + " data=" + this.data + "}";
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_32.jar!/org/eclipse/swt/events/TypedEvent.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */