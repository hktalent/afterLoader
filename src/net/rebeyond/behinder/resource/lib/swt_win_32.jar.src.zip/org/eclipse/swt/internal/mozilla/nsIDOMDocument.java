package org.eclipse.swt.internal.mozilla;

public class nsIDOMDocument
  extends nsIDOMNode
{
  static final int LAST_METHOD_ID = nsIDOMNode.LAST_METHOD_ID + (IsXULRunner10() ? 61 : IsXULRunner24() ? 68 : 17);
  static final String NS_IDOMDOCUMENT_IID_STR = "a6cf9075-15b3-11d2-932e-00805f8add32";
  static final String NS_IDOMDOCUMENT_10_IID_STR = "5c3bff4d-ae7f-4c93-948c-519589672c30";
  static final String NS_IDOMDOCUMENT_24_IID_STR = "75996de6-6b0f-43e5-ae79-c98fa669da9a";
  
  public nsIDOMDocument(int paramInt)
  {
    super(paramInt);
  }
  
  public int GetDocumentElement(int[] paramArrayOfInt)
  {
    return XPCOM.VtblCall(nsIDOMNode.LAST_METHOD_ID + 3, getAddress(), paramArrayOfInt);
  }
  
  static
  {
    IIDStore.RegisterIID(nsIDOMDocument.class, 0, new nsID("a6cf9075-15b3-11d2-932e-00805f8add32"));
    IIDStore.RegisterIID(nsIDOMDocument.class, 5, new nsID("5c3bff4d-ae7f-4c93-948c-519589672c30"));
    IIDStore.RegisterIID(nsIDOMDocument.class, 6, new nsID("75996de6-6b0f-43e5-ae79-c98fa669da9a"));
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_32.jar!/org/eclipse/swt/internal/mozilla/nsIDOMDocument.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */