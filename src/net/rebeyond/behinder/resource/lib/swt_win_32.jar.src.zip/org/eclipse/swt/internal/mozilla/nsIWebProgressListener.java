package org.eclipse.swt.internal.mozilla;

public class nsIWebProgressListener
  extends nsISupports
{
  static final int LAST_METHOD_ID = nsISupports.LAST_METHOD_ID + 5;
  static final String NS_IWEBPROGRESSLISTENER_IID_STR = "570f39d1-efd0-11d3-b093-00a024ffc08c";
  static final String NS_IWEBPROGRESSLISTENER_24_IID_STR = "a0cda7e4-c6ca-11e0-b6a5-001320257da5";
  public static final int STATE_START = 1;
  public static final int STATE_REDIRECTING = 2;
  public static final int STATE_TRANSFERRING = 4;
  public static final int STATE_NEGOTIATING = 8;
  public static final int STATE_STOP = 16;
  public static final int STATE_IS_REQUEST = 65536;
  public static final int STATE_IS_DOCUMENT = 131072;
  public static final int STATE_IS_NETWORK = 262144;
  public static final int STATE_IS_WINDOW = 524288;
  public static final int STATE_IS_INSECURE = 4;
  public static final int STATE_IS_BROKEN = 1;
  public static final int STATE_IS_SECURE = 2;
  public static final int STATE_SECURE_HIGH = 262144;
  public static final int STATE_SECURE_MED = 65536;
  public static final int STATE_SECURE_LOW = 131072;
  
  public nsIWebProgressListener(int paramInt)
  {
    super(paramInt);
  }
  
  static
  {
    IIDStore.RegisterIID(nsIWebProgressListener.class, 0, new nsID("570f39d1-efd0-11d3-b093-00a024ffc08c"));
    IIDStore.RegisterIID(nsIWebProgressListener.class, 6, new nsID("a0cda7e4-c6ca-11e0-b6a5-001320257da5"));
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_32.jar!/org/eclipse/swt/internal/mozilla/nsIWebProgressListener.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */