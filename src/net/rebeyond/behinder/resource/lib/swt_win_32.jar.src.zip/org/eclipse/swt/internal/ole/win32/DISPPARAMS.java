package org.eclipse.swt.internal.ole.win32;

public final class DISPPARAMS
{
  public int rgvarg;
  public int rgdispidNamedArgs;
  public int cArgs;
  public int cNamedArgs;
  public static final int sizeof = ;
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_32.jar!/org/eclipse/swt/internal/ole/win32/DISPPARAMS.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */