package org.eclipse.swt.internal.mozilla;

public class nsIWindowWatcher
  extends nsISupports
{
  static final int LAST_METHOD_ID = nsISupports.LAST_METHOD_ID + 11;
  static final String NS_IWINDOWWATCHER_IID_STR = "002286a8-494b-43b3-8ddd-49e3fc50622b";
  
  public nsIWindowWatcher(int paramInt)
  {
    super(paramInt);
  }
  
  public int SetWindowCreator(int paramInt)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 7, getAddress(), paramInt);
  }
  
  public int GetChromeForWindow(int paramInt, int[] paramArrayOfInt)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 8, getAddress(), paramInt, paramArrayOfInt);
  }
  
  static
  {
    IIDStore.RegisterIID(nsIWindowWatcher.class, 0, new nsID("002286a8-494b-43b3-8ddd-49e3fc50622b"));
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_32.jar!/org/eclipse/swt/internal/mozilla/nsIWindowWatcher.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */