package org.eclipse.swt.internal.mozilla;

public class nsIDOMEventTarget
  extends nsISupports
{
  static final int LAST_METHOD_ID = nsISupports.LAST_METHOD_ID + (IsXULRunner24() ? 5 : 3);
  static final String NS_IDOMEVENTTARGET_IID_STR = "1c773b30-d1cf-11d2-bd95-00805f8ae3f4";
  static final String NS_IDOMEVENTTARGET_10_IID_STR = "1797d5a4-b12a-428d-9eef-a0e13839728c";
  static final String NS_IDOMEVENTTARGET_24_IID_STR = "31e92e56-4d23-4a4a-9cfe-a6d12cf434bc";
  
  public nsIDOMEventTarget(int paramInt)
  {
    super(paramInt);
  }
  
  public int AddEventListener(int paramInt1, int paramInt2, int paramInt3)
  {
    if ((IsXULRunner10()) || (IsXULRunner24())) {
      return 1;
    }
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 1, getAddress(), paramInt1, paramInt2, paramInt3);
  }
  
  public int AddEventListener(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
  {
    if ((!IsXULRunner10()) && (!IsXULRunner24())) {
      return AddEventListener(paramInt1, paramInt2, paramInt3);
    }
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 1, getAddress(), paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
  }
  
  public int RemoveEventListener(int paramInt1, int paramInt2, int paramInt3)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + (IsXULRunner24() ? 3 : 2), getAddress(), paramInt1, paramInt2, paramInt3);
  }
  
  static
  {
    IIDStore.RegisterIID(nsIDOMEventTarget.class, 0, new nsID("1c773b30-d1cf-11d2-bd95-00805f8ae3f4"));
    IIDStore.RegisterIID(nsIDOMEventTarget.class, 5, new nsID("1797d5a4-b12a-428d-9eef-a0e13839728c"));
    IIDStore.RegisterIID(nsIDOMEventTarget.class, 6, new nsID("31e92e56-4d23-4a4a-9cfe-a6d12cf434bc"));
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_32.jar!/org/eclipse/swt/internal/mozilla/nsIDOMEventTarget.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */