package org.eclipse.swt.internal.webkit;

import org.eclipse.swt.internal.ole.win32.COM;
import org.eclipse.swt.internal.ole.win32.IUnknown;

public class IWebURLAuthenticationChallenge
  extends IUnknown
{
  public IWebURLAuthenticationChallenge(int paramInt)
  {
    super(paramInt);
  }
  
  public int previousFailureCount(int[] paramArrayOfInt)
  {
    return COM.VtblCall(7, getAddress(), paramArrayOfInt);
  }
  
  public int proposedCredential(int[] paramArrayOfInt)
  {
    return COM.VtblCall(8, getAddress(), paramArrayOfInt);
  }
  
  public int protectionSpace(int[] paramArrayOfInt)
  {
    return COM.VtblCall(9, getAddress(), paramArrayOfInt);
  }
  
  public int sender(int[] paramArrayOfInt)
  {
    return COM.VtblCall(10, getAddress(), paramArrayOfInt);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_32.jar!/org/eclipse/swt/internal/webkit/IWebURLAuthenticationChallenge.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */