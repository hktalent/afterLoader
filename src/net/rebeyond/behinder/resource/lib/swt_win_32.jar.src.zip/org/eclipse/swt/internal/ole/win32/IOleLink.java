package org.eclipse.swt.internal.ole.win32;

public class IOleLink
  extends IUnknown
{
  public IOleLink(int paramInt)
  {
    super(paramInt);
  }
  
  public int BindIfRunning()
  {
    return COM.VtblCall(10, this.address);
  }
  
  public int GetSourceMoniker(int[] paramArrayOfInt)
  {
    return COM.VtblCall(6, this.address, paramArrayOfInt);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_32.jar!/org/eclipse/swt/internal/ole/win32/IOleLink.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */