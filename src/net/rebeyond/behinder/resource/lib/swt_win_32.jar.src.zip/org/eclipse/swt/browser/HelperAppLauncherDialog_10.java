package org.eclipse.swt.browser;

import org.eclipse.swt.internal.C;
import org.eclipse.swt.internal.mozilla.XPCOM;
import org.eclipse.swt.internal.mozilla.XPCOMObject;
import org.eclipse.swt.internal.mozilla.nsEmbedString;
import org.eclipse.swt.internal.mozilla.nsIHelperAppLauncher_1_8;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Shell;

class HelperAppLauncherDialog_10
  extends HelperAppLauncherDialog_1_9
{
  XPCOMObject supports;
  XPCOMObject helperAppLauncherDialog;
  int refCount = 0;
  
  HelperAppLauncherDialog_10()
  {
    createCOMInterfaces();
  }
  
  int Show(int paramInt1, int paramInt2, int paramInt3)
  {
    nsIHelperAppLauncher_1_8 localnsIHelperAppLauncher_1_8 = new nsIHelperAppLauncher_1_8(paramInt1);
    return localnsIHelperAppLauncher_1_8.SaveToDisk(0, 0);
  }
  
  int PromptForSaveToFile(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6)
  {
    int i = XPCOM.strlen_PRUnichar(paramInt3);
    char[] arrayOfChar = new char[i];
    XPCOM.memmove(arrayOfChar, paramInt3, i * 2);
    String str1 = new String(arrayOfChar);
    i = XPCOM.strlen_PRUnichar(paramInt4);
    arrayOfChar = new char[i];
    XPCOM.memmove(arrayOfChar, paramInt4, i * 2);
    String str2 = new String(arrayOfChar);
    Shell localShell = new Shell();
    FileDialog localFileDialog = new FileDialog(localShell, 8192);
    localFileDialog.setFileName(str1);
    localFileDialog.setFilterExtensions(new String[] { str2 });
    String str3 = localFileDialog.open();
    localShell.close();
    if (str3 == null)
    {
      localObject = new nsIHelperAppLauncher_1_8(paramInt1);
      int j = ((nsIHelperAppLauncher_1_8)localObject).Cancel(-2142568446);
      if (j != 0) {
        Mozilla.error(j);
      }
      return -2147467259;
    }
    Object localObject = new nsEmbedString(str3);
    int[] arrayOfInt = new int[1];
    int k = XPCOM.NS_NewLocalFile(((nsEmbedString)localObject).getAddress(), 1, arrayOfInt);
    ((nsEmbedString)localObject).dispose();
    if (k != 0) {
      Mozilla.error(k);
    }
    if (arrayOfInt[0] == 0) {
      Mozilla.error(-2147467261);
    }
    XPCOM.memmove(paramInt6, arrayOfInt, C.PTR_SIZEOF);
    return 0;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_32.jar!/org/eclipse/swt/browser/HelperAppLauncherDialog_10.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */