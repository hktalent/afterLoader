package org.eclipse.swt.custom;

import org.eclipse.swt.SWT;
import org.eclipse.swt.accessibility.Accessible;
import org.eclipse.swt.accessibility.AccessibleAdapter;
import org.eclipse.swt.accessibility.AccessibleControlAdapter;
import org.eclipse.swt.accessibility.AccessibleControlEvent;
import org.eclipse.swt.accessibility.AccessibleEvent;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Device;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.ImageData;
import org.eclipse.swt.graphics.PaletteData;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.RGB;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Layout;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.MenuItem;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.ToolBar;
import org.eclipse.swt.widgets.ToolItem;
import org.eclipse.swt.widgets.TypedListener;

public class CTabFolder
  extends Composite
{
  public int marginWidth = 0;
  public int marginHeight = 0;
  @Deprecated
  public int MIN_TAB_WIDTH = 4;
  @Deprecated
  public static RGB borderInsideRGB = new RGB(132, 130, 132);
  @Deprecated
  public static RGB borderMiddleRGB = new RGB(143, 141, 138);
  @Deprecated
  public static RGB borderOutsideRGB = new RGB(171, 168, 165);
  boolean onBottom = false;
  boolean single = false;
  boolean simple = true;
  int fixedTabHeight = -1;
  int tabHeight;
  int minChars = 20;
  boolean borderVisible = false;
  CTabFolderRenderer renderer;
  CTabItem[] items = new CTabItem[0];
  int firstIndex = -1;
  int selectedIndex = -1;
  int[] priority = new int[0];
  boolean mru = false;
  Listener listener;
  boolean ignoreTraverse;
  boolean useDefaultRenderer;
  CTabFolder2Listener[] folderListeners = new CTabFolder2Listener[0];
  CTabFolderListener[] tabListeners = new CTabFolderListener[0];
  Image selectionBgImage;
  Color[] selectionGradientColors;
  int[] selectionGradientPercents;
  boolean selectionGradientVertical;
  Color selectionForeground;
  Color selectionBackground;
  Color[] gradientColors;
  int[] gradientPercents;
  boolean gradientVertical;
  boolean showUnselectedImage = true;
  boolean showClose = false;
  boolean showUnselectedClose = true;
  boolean showMin = false;
  boolean minimized = false;
  boolean showMax = false;
  boolean maximized = false;
  ToolBar minMaxTb;
  ToolItem maxItem;
  ToolItem minItem;
  Image maxImage;
  Image minImage;
  boolean hoverTb;
  Rectangle hoverRect = new Rectangle(0, 0, 0, 0);
  boolean hovering;
  boolean hoverTimerRunning;
  boolean showChevron = false;
  Menu showMenu;
  ToolBar chevronTb;
  ToolItem chevronItem;
  int chevronCount;
  boolean chevronVisible = true;
  Image chevronImage;
  Control topRight;
  int topRightAlignment = 131072;
  boolean ignoreResize;
  Control[] controls;
  int[] controlAlignments;
  Rectangle[] controlRects;
  Image[] controlBkImages;
  int updateFlags;
  static final int REDRAW = 2;
  static final int REDRAW_TABS = 4;
  static final int UPDATE_TAB_HEIGHT = 8;
  Runnable updateRun;
  boolean inDispose = false;
  Point oldSize;
  Font oldFont;
  static final int DEFAULT_WIDTH = 64;
  static final int DEFAULT_HEIGHT = 64;
  static final int SELECTION_FOREGROUND = 24;
  static final int SELECTION_BACKGROUND = 25;
  static final int FOREGROUND = 21;
  static final int BACKGROUND = 22;
  static final int SPACING = 3;
  
  public CTabFolder(Composite paramComposite, int paramInt)
  {
    super(paramComposite, checkStyle(paramComposite, paramInt));
    init(paramInt);
  }
  
  void init(int paramInt)
  {
    super.setLayout(new CTabFolderLayout());
    int i = super.getStyle();
    this.oldFont = getFont();
    this.onBottom = ((i & 0x400) != 0);
    this.showClose = ((i & 0x40) != 0);
    this.single = ((i & 0x4) != 0);
    this.borderVisible = ((paramInt & 0x800) != 0);
    Display localDisplay = getDisplay();
    this.selectionForeground = localDisplay.getSystemColor(24);
    this.selectionBackground = localDisplay.getSystemColor(25);
    this.renderer = new CTabFolderRenderer(this);
    this.useDefaultRenderer = true;
    this.controls = new Control[0];
    this.controlAlignments = new int[0];
    this.controlRects = new Rectangle[0];
    this.controlBkImages = new Image[0];
    updateTabHeight(false);
    this.listener = new Listener()
    {
      public void handleEvent(Event paramAnonymousEvent)
      {
        switch (paramAnonymousEvent.type)
        {
        case 12: 
          CTabFolder.this.onDispose(paramAnonymousEvent);
          break;
        case 29: 
          CTabFolder.this.onDragDetect(paramAnonymousEvent);
          break;
        case 15: 
          CTabFolder.this.onFocus(paramAnonymousEvent);
          break;
        case 16: 
          CTabFolder.this.onFocus(paramAnonymousEvent);
          break;
        case 1: 
          CTabFolder.this.onKeyDown(paramAnonymousEvent);
          break;
        case 35: 
          CTabFolder.this.onMenuDetect(paramAnonymousEvent);
          break;
        case 8: 
          CTabFolder.this.onMouseDoubleClick(paramAnonymousEvent);
          break;
        case 3: 
          CTabFolder.this.onMouse(paramAnonymousEvent);
          break;
        case 6: 
          CTabFolder.this.onMouse(paramAnonymousEvent);
          break;
        case 7: 
          CTabFolder.this.onMouse(paramAnonymousEvent);
          break;
        case 32: 
          CTabFolder.this.onMouse(paramAnonymousEvent);
          break;
        case 5: 
          CTabFolder.this.onMouse(paramAnonymousEvent);
          break;
        case 4: 
          CTabFolder.this.onMouse(paramAnonymousEvent);
          break;
        case 9: 
          CTabFolder.this.onPaint(paramAnonymousEvent);
          break;
        case 11: 
          CTabFolder.this.onResize(paramAnonymousEvent);
          break;
        case 31: 
          CTabFolder.this.onTraverse(paramAnonymousEvent);
          break;
        case 13: 
          CTabFolder.this.onSelection(paramAnonymousEvent);
        }
      }
    };
    int[] arrayOfInt = { 12, 29, 15, 16, 1, 35, 8, 3, 6, 7, 32, 5, 4, 9, 11, 31 };
    for (int j = 0; j < arrayOfInt.length; j++) {
      addListener(arrayOfInt[j], this.listener);
    }
    initAccessible();
  }
  
  static int checkStyle(Composite paramComposite, int paramInt)
  {
    int i = 109053126;
    paramInt &= i;
    if ((paramInt & 0x80) != 0) {
      paramInt &= 0xFBFF;
    }
    if ((paramInt & 0x2) != 0) {
      paramInt &= 0xFFFFFFFB;
    }
    paramInt |= 0x100000;
    if ((paramInt & 0x4000000) != 0) {
      return paramInt;
    }
    if (((paramComposite.getStyle() & 0x8000000) != 0) && ((paramInt & 0x2000000) == 0)) {
      return paramInt;
    }
    return paramInt | 0x20000000;
  }
  
  public void addCTabFolder2Listener(CTabFolder2Listener paramCTabFolder2Listener)
  {
    checkWidget();
    if (paramCTabFolder2Listener == null) {
      SWT.error(4);
    }
    CTabFolder2Listener[] arrayOfCTabFolder2Listener = new CTabFolder2Listener[this.folderListeners.length + 1];
    System.arraycopy(this.folderListeners, 0, arrayOfCTabFolder2Listener, 0, this.folderListeners.length);
    this.folderListeners = arrayOfCTabFolder2Listener;
    this.folderListeners[(this.folderListeners.length - 1)] = paramCTabFolder2Listener;
  }
  
  @Deprecated
  public void addCTabFolderListener(CTabFolderListener paramCTabFolderListener)
  {
    checkWidget();
    if (paramCTabFolderListener == null) {
      SWT.error(4);
    }
    CTabFolderListener[] arrayOfCTabFolderListener = new CTabFolderListener[this.tabListeners.length + 1];
    System.arraycopy(this.tabListeners, 0, arrayOfCTabFolderListener, 0, this.tabListeners.length);
    this.tabListeners = arrayOfCTabFolderListener;
    this.tabListeners[(this.tabListeners.length - 1)] = paramCTabFolderListener;
    if (!this.showClose)
    {
      this.showClose = true;
      updateFolder(2);
    }
  }
  
  public void addSelectionListener(SelectionListener paramSelectionListener)
  {
    checkWidget();
    if (paramSelectionListener == null) {
      SWT.error(4);
    }
    TypedListener localTypedListener = new TypedListener(paramSelectionListener);
    addListener(13, localTypedListener);
    addListener(14, localTypedListener);
  }
  
  Rectangle[] computeControlBounds(Point paramPoint, boolean[][] paramArrayOfBoolean)
  {
    if ((this.controls == null) || (this.controls.length == 0)) {
      return new Rectangle[0];
    }
    Rectangle[] arrayOfRectangle = new Rectangle[this.controls.length];
    for (int i = 0; i < arrayOfRectangle.length; i++) {
      arrayOfRectangle[i] = new Rectangle(0, 0, 0, 0);
    }
    Rectangle localRectangle1 = this.renderer.computeTrim(-3, 0, 0, 0, 0, 0);
    int j = localRectangle1.width + localRectangle1.x;
    int k = -localRectangle1.x;
    int m = localRectangle1.height + localRectangle1.y;
    int n = -localRectangle1.y;
    Point[] arrayOfPoint = new Point[this.controls.length];
    boolean[] arrayOfBoolean = new boolean[this.controls.length];
    int i1 = 0;
    int i2 = k + 3;
    int i3 = 0;
    int i4 = 0;
    for (int i5 = 0; i5 < this.controls.length; i5++)
    {
      Point localPoint1 = arrayOfPoint[i5] = (!this.controls[i5].isDisposed()) && (this.controls[i5].getVisible()) ? this.controls[i5].computeSize(-1, -1) : new Point(0, 0);
      i7 = this.controlAlignments[i5];
      if ((i7 & 0x4000) != 0)
      {
        arrayOfRectangle[i5].width = localPoint1.x;
        arrayOfRectangle[i5].height = getControlHeight(localPoint1);
        arrayOfRectangle[i5].x = i2;
        arrayOfRectangle[i5].y = getControlY(paramPoint, arrayOfRectangle, m, n, i5);
        i2 += localPoint1.x;
        i1 += localPoint1.x;
      }
      else
      {
        if ((i7 & 0x44) == 0) {
          i3 += localPoint1.x;
        }
        i4 += localPoint1.x;
      }
    }
    if (i1 > 0) {
      i1 += 6;
    }
    i5 = 0;
    for (int i6 = 0; i6 < this.items.length; i6++) {
      if (this.items[i6].showing) {
        i5 += this.items[i6].width;
      }
    }
    i6 = paramPoint.x - k - i1 - j;
    int i7 = Math.max(0, i6 - i5 - i3);
    if (i3 > 0) {
      i7 -= 6;
    }
    i2 = paramPoint.x - j - 3;
    int i8;
    Point localPoint2;
    if (i5 + i4 <= i6) {
      for (i8 = 0; i8 < this.controls.length; i8++)
      {
        i9 = this.controlAlignments[i8];
        if ((i9 & 0x20000) != 0)
        {
          localPoint2 = arrayOfPoint[i8];
          i2 -= localPoint2.x;
          arrayOfRectangle[i8].width = localPoint2.x;
          arrayOfRectangle[i8].height = getControlHeight(localPoint2);
          arrayOfRectangle[i8].x = i2;
          arrayOfRectangle[i8].y = getControlY(paramPoint, arrayOfRectangle, m, n, i8);
          if ((i9 & 0x44) != 0) {
            i7 -= localPoint2.x;
          }
        }
      }
    } else {
      for (i8 = 0; i8 < this.controls.length; i8++)
      {
        i9 = this.controlAlignments[i8];
        localPoint2 = arrayOfPoint[i8];
        if ((i9 & 0x20000) != 0) {
          if ((i9 & 0x44) == 0)
          {
            i2 -= localPoint2.x;
            arrayOfRectangle[i8].width = localPoint2.x;
            arrayOfRectangle[i8].height = getControlHeight(localPoint2);
            arrayOfRectangle[i8].x = i2;
            arrayOfRectangle[i8].y = getControlY(paramPoint, arrayOfRectangle, m, n, i8);
          }
          else if (((i9 & 0x40) != 0) && (localPoint2.x < i7))
          {
            i2 -= localPoint2.x;
            arrayOfRectangle[i8].width = localPoint2.x;
            arrayOfRectangle[i8].height = getControlHeight(localPoint2);
            arrayOfRectangle[i8].x = i2;
            arrayOfRectangle[i8].y = getControlY(paramPoint, arrayOfRectangle, m, n, i8);
            i7 -= localPoint2.x;
          }
          else if (((i9 & 0x4) != 0) && ((i9 & 0x40) == 0))
          {
            arrayOfRectangle[i8].width = 0;
            arrayOfRectangle[i8].height = getControlHeight(localPoint2);
            arrayOfRectangle[i8].x = i2;
            arrayOfRectangle[i8].y = getControlY(paramPoint, arrayOfRectangle, m, n, i8);
          }
          else if ((i9 & 0x40) != 0)
          {
            arrayOfBoolean[i8] = true;
          }
        }
      }
    }
    if (i7 > 0)
    {
      i8 = 0;
      for (i9 = 0; i9 < this.controls.length; i9++)
      {
        i10 = this.controlAlignments[i9];
        if (((i10 & 0x20000) != 0) && ((i10 & 0x4) != 0) && (arrayOfBoolean[i9] == 0)) {
          i8++;
        }
      }
      if (i8 != 0)
      {
        i9 = i7 / i8;
        i10 = 0;
        for (i11 = 0; i11 < this.controls.length; i11++)
        {
          i12 = this.controlAlignments[i11];
          if ((i12 & 0x20000) != 0)
          {
            if (((i12 & 0x4) != 0) && (arrayOfBoolean[i11] == 0))
            {
              arrayOfRectangle[i11].width += i9;
              i10 += i9;
            }
            if (arrayOfBoolean[i11] == 0) {
              arrayOfRectangle[i11].x -= i10;
            }
          }
        }
      }
    }
    Rectangle localRectangle2 = this.renderer.computeTrim(-1, 0, 0, 0, 0, 0);
    int i9 = localRectangle2.width + localRectangle2.x;
    int i10 = -localRectangle2.x;
    int i11 = paramPoint.x - i10 - i9;
    i2 = paramPoint.x - i9;
    int i12 = this.onBottom ? getSize().y - getTabHeight() + 2 * localRectangle2.y : -localRectangle2.y;
    i7 = i11;
    int i13 = 0;
    for (int i14 = 0; i14 < this.controls.length; i14++)
    {
      Point localPoint3 = arrayOfPoint[i14];
      if (arrayOfBoolean[i14] != 0) {
        if (i7 > localPoint3.x)
        {
          i2 -= localPoint3.x;
          arrayOfRectangle[i14].width = localPoint3.x;
          arrayOfRectangle[i14].y = (this.onBottom ? i12 - localPoint3.y : i12);
          arrayOfRectangle[i14].height = localPoint3.y;
          arrayOfRectangle[i14].x = i2;
          i7 -= localPoint3.x;
          i13 = Math.max(i13, localPoint3.y);
        }
        else
        {
          i2 = paramPoint.x - i9;
          i12 += i13;
          i13 = 0;
          i7 = i11;
          if (i7 > localPoint3.x)
          {
            i14--;
          }
          else
          {
            localPoint3 = this.controls[i14].isDisposed() ? new Point(0, 0) : this.controls[i14].computeSize(i11, -1);
            arrayOfRectangle[i14].width = i11;
            arrayOfRectangle[i14].y = (this.onBottom ? i12 - localPoint3.y : i12);
            arrayOfRectangle[i14].height = localPoint3.y;
            arrayOfRectangle[i14].x = (paramPoint.x - localPoint3.x - i9);
            i12 += localPoint3.y;
          }
        }
      }
    }
    if (this.showChevron)
    {
      i14 = 0;
      for (int i15 = -1; (i14 < this.priority.length) && (this.items[this.priority[i14]].showing); i15 = Math.max(i15, this.priority[(i14++)])) {}
      if (i15 == -1) {
        i15 = this.selectedIndex;
      }
      if (i15 != -1)
      {
        CTabItem localCTabItem = this.items[i15];
        int i16 = localCTabItem.x + localCTabItem.width + 3;
        if ((!this.simple) && (i15 == this.selectedIndex)) {
          i16 -= this.renderer.curveIndent - 7;
        }
        arrayOfRectangle[(this.controls.length - 1)].x = i16;
      }
    }
    if (paramArrayOfBoolean != null) {
      paramArrayOfBoolean[0] = arrayOfBoolean;
    }
    return arrayOfRectangle;
  }
  
  int getControlHeight(Point paramPoint)
  {
    return this.fixedTabHeight == -1 ? Math.max(this.tabHeight - 1, paramPoint.y) : paramPoint.y;
  }
  
  public Rectangle computeTrim(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    checkWidget();
    Rectangle localRectangle = this.renderer.computeTrim(-1, 0, paramInt1, paramInt2, paramInt3, paramInt4);
    Point localPoint = new Point(paramInt3, paramInt4);
    int i = getWrappedHeight(localPoint);
    if (this.onBottom)
    {
      localRectangle.height += i;
    }
    else
    {
      localRectangle.y -= i;
      localRectangle.height += i;
    }
    return localRectangle;
  }
  
  Image createButtonImage(Display paramDisplay, int paramInt)
  {
    GC localGC1 = new GC(this);
    Point localPoint = this.renderer.computeSize(paramInt, 0, localGC1, -1, -1);
    localGC1.dispose();
    Rectangle localRectangle = this.renderer.computeTrim(paramInt, 0, 0, 0, 0, 0);
    Image localImage = new Image(paramDisplay, localPoint.x - localRectangle.width, localPoint.y - localRectangle.height);
    GC localGC2 = new GC(localImage);
    RGB localRGB;
    if (paramInt == -7) {
      localRGB = new RGB(255, 255, 255);
    } else {
      localRGB = new RGB(253, 0, 0);
    }
    Color localColor = new Color(paramDisplay, localRGB);
    localGC2.setBackground(localColor);
    localGC2.fillRectangle(localImage.getBounds());
    this.renderer.draw(paramInt, 0, new Rectangle(localRectangle.x, localRectangle.y, localPoint.x, localPoint.y), localGC2);
    localGC2.dispose();
    localColor.dispose();
    ImageData localImageData = localImage.getImageData();
    localImageData.transparentPixel = localImageData.palette.getPixel(localRGB);
    localImage.dispose();
    localImage = new Image(paramDisplay, localImageData);
    return localImage;
  }
  
  void createItem(CTabItem paramCTabItem, int paramInt)
  {
    if ((0 > paramInt) || (paramInt > getItemCount())) {
      SWT.error(6);
    }
    paramCTabItem.parent = this;
    CTabItem[] arrayOfCTabItem = new CTabItem[this.items.length + 1];
    System.arraycopy(this.items, 0, arrayOfCTabItem, 0, paramInt);
    arrayOfCTabItem[paramInt] = paramCTabItem;
    System.arraycopy(this.items, paramInt, arrayOfCTabItem, paramInt + 1, this.items.length - paramInt);
    this.items = arrayOfCTabItem;
    if (this.selectedIndex >= paramInt) {
      this.selectedIndex += 1;
    }
    int[] arrayOfInt = new int[this.priority.length + 1];
    int i = 0;
    int j = this.priority.length;
    for (int k = 0; k < this.priority.length; k++)
    {
      if ((!this.mru) && ((this.priority[k] == paramInt) || ((this.priority[k] == 0) && (paramInt + 1 == this.items.length)))) {
        j = i++;
      }
      arrayOfInt[(i++)] = (this.priority[k] >= paramInt ? this.priority[k] + 1 : this.priority[k]);
    }
    arrayOfInt[j] = paramInt;
    this.priority = arrayOfInt;
    if (this.items.length == 1) {
      updateFolder(10);
    } else {
      updateFolder(4);
    }
  }
  
  void destroyItem(CTabItem paramCTabItem)
  {
    if (this.inDispose) {
      return;
    }
    int i = indexOf(paramCTabItem);
    if (i == -1) {
      return;
    }
    if (this.items.length == 1)
    {
      this.items = new CTabItem[0];
      this.priority = new int[0];
      this.firstIndex = -1;
      this.selectedIndex = -1;
      localObject1 = paramCTabItem.control;
      if ((localObject1 != null) && (!((Control)localObject1).isDisposed())) {
        ((Control)localObject1).setVisible(false);
      }
      setToolTipText(null);
      localObject2 = new GC(this);
      setButtonBounds((GC)localObject2);
      ((GC)localObject2).dispose();
      redraw();
      return;
    }
    Object localObject1 = new CTabItem[this.items.length - 1];
    System.arraycopy(this.items, 0, localObject1, 0, i);
    System.arraycopy(this.items, i + 1, localObject1, i, this.items.length - i - 1);
    this.items = ((CTabItem[])localObject1);
    Object localObject2 = new int[this.priority.length - 1];
    int j = 0;
    for (int k = 0; k < this.priority.length; k++) {
      if (this.priority[k] != i) {
        localObject2[(j++)] = (this.priority[k] > i ? this.priority[k] - 1 : this.priority[k]);
      }
    }
    this.priority = ((int[])localObject2);
    if (this.selectedIndex == i)
    {
      Control localControl = paramCTabItem.getControl();
      this.selectedIndex = -1;
      int m = this.mru ? this.priority[0] : Math.max(0, i - 1);
      setSelection(m, true);
      if ((localControl != null) && (!localControl.isDisposed())) {
        localControl.setVisible(false);
      }
    }
    else if (this.selectedIndex > i)
    {
      this.selectedIndex -= 1;
    }
    updateFolder(12);
  }
  
  public boolean getBorderVisible()
  {
    checkWidget();
    return this.borderVisible;
  }
  
  ToolBar getChevron()
  {
    if (this.chevronTb == null)
    {
      this.chevronTb = new ToolBar(this, 8388608);
      initAccessibleChevronTb();
      addTabControl(this.chevronTb, 131072, -1, false);
    }
    if (this.chevronItem == null)
    {
      this.chevronItem = new ToolItem(this.chevronTb, 8);
      this.chevronItem.setToolTipText(SWT.getMessage("SWT_ShowList"));
      this.chevronItem.addListener(13, this.listener);
    }
    return this.chevronTb;
  }
  
  boolean getChevronVisible()
  {
    checkWidget();
    return this.chevronVisible;
  }
  
  public Rectangle getClientArea()
  {
    checkWidget();
    Rectangle localRectangle = this.renderer.computeTrim(-1, 4, 0, 0, 0, 0);
    Point localPoint = getSize();
    int i = getWrappedHeight(localPoint);
    if (this.onBottom)
    {
      localRectangle.height += i;
    }
    else
    {
      localRectangle.y -= i;
      localRectangle.height += i;
    }
    if (this.minimized) {
      return new Rectangle(-localRectangle.x, -localRectangle.y, 0, 0);
    }
    int j = localPoint.x - localRectangle.width;
    int k = localPoint.y - localRectangle.height;
    return new Rectangle(-localRectangle.x, -localRectangle.y, j, k);
  }
  
  public CTabItem getItem(int paramInt)
  {
    if ((paramInt < 0) || (paramInt >= this.items.length)) {
      SWT.error(6);
    }
    return this.items[paramInt];
  }
  
  public CTabItem getItem(Point paramPoint)
  {
    if (this.items.length == 0) {
      return null;
    }
    runUpdate();
    Point localPoint = getSize();
    Rectangle localRectangle1 = this.renderer.computeTrim(-3, 0, 0, 0, 0, 0);
    if (localPoint.x <= localRectangle1.width) {
      return null;
    }
    for (int i = 0; i < this.priority.length; i++)
    {
      CTabItem localCTabItem = this.items[this.priority[i]];
      Rectangle localRectangle2 = localCTabItem.getBounds();
      if (localRectangle2.contains(paramPoint)) {
        return localCTabItem;
      }
    }
    return null;
  }
  
  public int getItemCount()
  {
    return this.items.length;
  }
  
  public CTabItem[] getItems()
  {
    CTabItem[] arrayOfCTabItem = new CTabItem[this.items.length];
    System.arraycopy(this.items, 0, arrayOfCTabItem, 0, this.items.length);
    return arrayOfCTabItem;
  }
  
  int getLeftItemEdge(GC paramGC, int paramInt)
  {
    Rectangle localRectangle = this.renderer.computeTrim(paramInt, 0, 0, 0, 0, 0);
    int i = -localRectangle.x;
    int j = 0;
    for (int k = 0; k < this.controls.length; k++) {
      if (((this.controlAlignments[k] & 0x4000) != 0) && (!this.controls[k].isDisposed()) && (this.controls[k].getVisible())) {
        j += this.controls[k].computeSize(-1, -1).x;
      }
    }
    if (j != 0) {
      j += 6;
    }
    i += j;
    return Math.max(0, i);
  }
  
  char _findMnemonic(String paramString)
  {
    if (paramString == null) {
      return '\000';
    }
    int i = 0;
    int j = paramString.length();
    do
    {
      while ((i < j) && (paramString.charAt(i) != '&')) {
        i++;
      }
      i++;
      if (i >= j) {
        return '\000';
      }
      if (paramString.charAt(i) != '&') {
        return Character.toLowerCase(paramString.charAt(i));
      }
      i++;
    } while (i < j);
    return '\000';
  }
  
  String stripMnemonic(String paramString)
  {
    int i = 0;
    int j = paramString.length();
    do
    {
      while ((i < j) && (paramString.charAt(i) != '&')) {
        i++;
      }
      i++;
      if (i >= j) {
        return paramString;
      }
      if (paramString.charAt(i) != '&') {
        return paramString.substring(0, i - 1) + paramString.substring(i, j);
      }
      i++;
    } while (i < j);
    return paramString;
  }
  
  public boolean getMinimized()
  {
    checkWidget();
    return this.minimized;
  }
  
  public boolean getMinimizeVisible()
  {
    checkWidget();
    return this.showMin;
  }
  
  public int getMinimumCharacters()
  {
    checkWidget();
    return this.minChars;
  }
  
  public boolean getMaximized()
  {
    checkWidget();
    return this.maximized;
  }
  
  public boolean getMaximizeVisible()
  {
    checkWidget();
    return this.showMax;
  }
  
  public boolean getMRUVisible()
  {
    checkWidget();
    return this.mru;
  }
  
  public CTabFolderRenderer getRenderer()
  {
    checkWidget();
    return this.renderer;
  }
  
  int getRightItemEdge(GC paramGC)
  {
    Rectangle localRectangle = this.renderer.computeTrim(-3, 0, 0, 0, 0, 0);
    int i = getSize().x - (localRectangle.width + localRectangle.x);
    int j = 0;
    for (int k = 0; k < this.controls.length; k++)
    {
      int m = this.controlAlignments[k];
      if (((m & 0x40) == 0) && ((m & 0x4000) == 0) && (!this.controls[k].isDisposed()) && (this.controls[k].getVisible()))
      {
        Point localPoint = this.controls[k].computeSize(-1, -1);
        j += localPoint.x;
      }
    }
    if (j != 0) {
      j += 6;
    }
    i -= j;
    return Math.max(0, i);
  }
  
  public CTabItem getSelection()
  {
    if (this.selectedIndex == -1) {
      return null;
    }
    return this.items[this.selectedIndex];
  }
  
  public Color getSelectionBackground()
  {
    checkWidget();
    return this.selectionBackground;
  }
  
  public Color getSelectionForeground()
  {
    checkWidget();
    return this.selectionForeground;
  }
  
  public int getSelectionIndex()
  {
    return this.selectedIndex;
  }
  
  public boolean getSimple()
  {
    checkWidget();
    return this.simple;
  }
  
  public boolean getSingle()
  {
    checkWidget();
    return this.single;
  }
  
  public int getStyle()
  {
    int i = super.getStyle();
    i &= 0xFB7F;
    i |= (this.onBottom ? 1024 : 128);
    i &= 0xFFFFFFF9;
    i |= (this.single ? 4 : 2);
    if (this.borderVisible) {
      i |= 0x800;
    }
    i &= 0xFFFFFFBF;
    if (this.showClose) {
      i |= 0x40;
    }
    return i;
  }
  
  public int getTabHeight()
  {
    checkWidget();
    if (this.fixedTabHeight != -1) {
      return this.fixedTabHeight;
    }
    return this.tabHeight - 1;
  }
  
  public int getTabPosition()
  {
    checkWidget();
    return this.onBottom ? 1024 : 128;
  }
  
  public Control getTopRight()
  {
    checkWidget();
    return this.topRight;
  }
  
  public int getTopRightAlignment()
  {
    checkWidget();
    return this.topRightAlignment;
  }
  
  public boolean getUnselectedCloseVisible()
  {
    checkWidget();
    return this.showUnselectedClose;
  }
  
  public boolean getUnselectedImageVisible()
  {
    checkWidget();
    return this.showUnselectedImage;
  }
  
  public int indexOf(CTabItem paramCTabItem)
  {
    checkWidget();
    if (paramCTabItem == null) {
      SWT.error(4);
    }
    for (int i = 0; i < this.items.length; i++) {
      if (this.items[i] == paramCTabItem) {
        return i;
      }
    }
    return -1;
  }
  
  void initAccessible()
  {
    final Accessible localAccessible = getAccessible();
    localAccessible.addAccessibleListener(new AccessibleAdapter()
    {
      public void getName(AccessibleEvent paramAnonymousAccessibleEvent)
      {
        CTabItem localCTabItem = null;
        int i = paramAnonymousAccessibleEvent.childID;
        if (i == -1)
        {
          if (CTabFolder.this.selectedIndex != -1) {
            localCTabItem = CTabFolder.this.items[CTabFolder.this.selectedIndex];
          }
        }
        else if ((i >= 0) && (i < CTabFolder.this.items.length)) {
          localCTabItem = CTabFolder.this.items[i];
        }
        paramAnonymousAccessibleEvent.result = (localCTabItem == null ? null : CTabFolder.this.stripMnemonic(localCTabItem.getText()));
      }
      
      public void getHelp(AccessibleEvent paramAnonymousAccessibleEvent)
      {
        String str = null;
        int i = paramAnonymousAccessibleEvent.childID;
        if (i == -1) {
          str = CTabFolder.this.getToolTipText();
        } else if ((i >= 0) && (i < CTabFolder.this.items.length)) {
          str = CTabFolder.this.items[i].getToolTipText();
        }
        paramAnonymousAccessibleEvent.result = str;
      }
      
      public void getKeyboardShortcut(AccessibleEvent paramAnonymousAccessibleEvent)
      {
        String str1 = null;
        int i = paramAnonymousAccessibleEvent.childID;
        if ((i >= 0) && (i < CTabFolder.this.items.length))
        {
          String str2 = CTabFolder.this.items[i].getText();
          if (str2 != null)
          {
            char c = CTabFolder.this._findMnemonic(str2);
            if (c != 0) {
              str1 = SWT.getMessage("SWT_Page_Mnemonic", new Object[] { new Character(c) });
            }
          }
        }
        if (i == -1) {
          str1 = SWT.getMessage("SWT_SwitchPage_Shortcut");
        }
        paramAnonymousAccessibleEvent.result = str1;
      }
    });
    localAccessible.addAccessibleControlListener(new AccessibleControlAdapter()
    {
      public void getChildAtPoint(AccessibleControlEvent paramAnonymousAccessibleControlEvent)
      {
        Point localPoint = CTabFolder.this.toControl(paramAnonymousAccessibleControlEvent.x, paramAnonymousAccessibleControlEvent.y);
        int i = -2;
        for (int j = 0; j < CTabFolder.this.items.length; j++) {
          if (CTabFolder.this.items[j].getBounds().contains(localPoint))
          {
            i = j;
            break;
          }
        }
        if (i == -2)
        {
          Rectangle localRectangle = CTabFolder.this.getBounds();
          localRectangle.x = (localRectangle.y = 0);
          localRectangle.height -= CTabFolder.this.getClientArea().height;
          if (localRectangle.contains(localPoint)) {
            i = -1;
          }
        }
        paramAnonymousAccessibleControlEvent.childID = i;
      }
      
      public void getLocation(AccessibleControlEvent paramAnonymousAccessibleControlEvent)
      {
        Rectangle localRectangle = null;
        Point localPoint = null;
        int i = paramAnonymousAccessibleControlEvent.childID;
        if (i == -1)
        {
          localRectangle = CTabFolder.this.getBounds();
          localPoint = CTabFolder.this.getParent().toDisplay(localRectangle.x, localRectangle.y);
        }
        else
        {
          if ((i >= 0) && (i < CTabFolder.this.items.length) && (CTabFolder.this.items[i].showing)) {
            localRectangle = CTabFolder.this.items[i].getBounds();
          }
          if (localRectangle != null) {
            localPoint = CTabFolder.this.toDisplay(localRectangle.x, localRectangle.y);
          }
        }
        if ((localRectangle != null) && (localPoint != null))
        {
          paramAnonymousAccessibleControlEvent.x = localPoint.x;
          paramAnonymousAccessibleControlEvent.y = localPoint.y;
          paramAnonymousAccessibleControlEvent.width = localRectangle.width;
          paramAnonymousAccessibleControlEvent.height = localRectangle.height;
        }
      }
      
      public void getChildCount(AccessibleControlEvent paramAnonymousAccessibleControlEvent)
      {
        paramAnonymousAccessibleControlEvent.detail = CTabFolder.this.items.length;
      }
      
      public void getDefaultAction(AccessibleControlEvent paramAnonymousAccessibleControlEvent)
      {
        String str = null;
        int i = paramAnonymousAccessibleControlEvent.childID;
        if ((i >= 0) && (i < CTabFolder.this.items.length)) {
          str = SWT.getMessage("SWT_Switch");
        }
        paramAnonymousAccessibleControlEvent.result = str;
      }
      
      public void getFocus(AccessibleControlEvent paramAnonymousAccessibleControlEvent)
      {
        int i = -2;
        if (CTabFolder.this.isFocusControl()) {
          if (CTabFolder.this.selectedIndex == -1) {
            i = -1;
          } else {
            i = CTabFolder.this.selectedIndex;
          }
        }
        paramAnonymousAccessibleControlEvent.childID = i;
      }
      
      public void getRole(AccessibleControlEvent paramAnonymousAccessibleControlEvent)
      {
        int i = 0;
        int j = paramAnonymousAccessibleControlEvent.childID;
        if (j == -1) {
          i = 60;
        } else if ((j >= 0) && (j < CTabFolder.this.items.length)) {
          i = 37;
        }
        paramAnonymousAccessibleControlEvent.detail = i;
      }
      
      public void getSelection(AccessibleControlEvent paramAnonymousAccessibleControlEvent)
      {
        paramAnonymousAccessibleControlEvent.childID = (CTabFolder.this.selectedIndex == -1 ? -2 : CTabFolder.this.selectedIndex);
      }
      
      public void getState(AccessibleControlEvent paramAnonymousAccessibleControlEvent)
      {
        int i = 0;
        int j = paramAnonymousAccessibleControlEvent.childID;
        if (j == -1)
        {
          i = 0;
        }
        else if ((j >= 0) && (j < CTabFolder.this.items.length))
        {
          i = 2097152;
          if (CTabFolder.this.isFocusControl()) {
            i |= 0x100000;
          }
          if (CTabFolder.this.selectedIndex == j)
          {
            i |= 0x2;
            if (CTabFolder.this.isFocusControl()) {
              i |= 0x4;
            }
          }
        }
        paramAnonymousAccessibleControlEvent.detail = i;
      }
      
      public void getChildren(AccessibleControlEvent paramAnonymousAccessibleControlEvent)
      {
        int i = CTabFolder.this.items.length;
        Object[] arrayOfObject = new Object[i];
        for (int j = 0; j < i; j++) {
          arrayOfObject[j] = new Integer(j);
        }
        paramAnonymousAccessibleControlEvent.children = arrayOfObject;
      }
    });
    addListener(13, new Listener()
    {
      public void handleEvent(Event paramAnonymousEvent)
      {
        if (CTabFolder.this.isFocusControl()) {
          if (CTabFolder.this.selectedIndex == -1) {
            localAccessible.setFocus(-1);
          } else {
            localAccessible.setFocus(CTabFolder.this.selectedIndex);
          }
        }
      }
    });
    addListener(15, new Listener()
    {
      public void handleEvent(Event paramAnonymousEvent)
      {
        if (CTabFolder.this.selectedIndex == -1) {
          localAccessible.setFocus(-1);
        } else {
          localAccessible.setFocus(CTabFolder.this.selectedIndex);
        }
      }
    });
  }
  
  void initAccessibleMinMaxTb()
  {
    this.minMaxTb.getAccessible().addAccessibleListener(new AccessibleAdapter()
    {
      public void getName(AccessibleEvent paramAnonymousAccessibleEvent)
      {
        if (paramAnonymousAccessibleEvent.childID != -1) {
          if ((CTabFolder.this.minItem != null) && (paramAnonymousAccessibleEvent.childID == CTabFolder.this.minMaxTb.indexOf(CTabFolder.this.minItem))) {
            paramAnonymousAccessibleEvent.result = CTabFolder.this.minItem.getToolTipText();
          } else if ((CTabFolder.this.maxItem != null) && (paramAnonymousAccessibleEvent.childID == CTabFolder.this.minMaxTb.indexOf(CTabFolder.this.maxItem))) {
            paramAnonymousAccessibleEvent.result = CTabFolder.this.maxItem.getToolTipText();
          }
        }
      }
    });
  }
  
  void initAccessibleChevronTb()
  {
    this.chevronTb.getAccessible().addAccessibleListener(new AccessibleAdapter()
    {
      public void getName(AccessibleEvent paramAnonymousAccessibleEvent)
      {
        if ((paramAnonymousAccessibleEvent.childID != -1) && (CTabFolder.this.chevronItem != null) && (paramAnonymousAccessibleEvent.childID == CTabFolder.this.chevronTb.indexOf(CTabFolder.this.chevronItem))) {
          paramAnonymousAccessibleEvent.result = CTabFolder.this.chevronItem.getToolTipText();
        }
      }
    });
  }
  
  void onKeyDown(Event paramEvent)
  {
    runUpdate();
    switch (paramEvent.keyCode)
    {
    case 16777219: 
    case 16777220: 
      int i = this.items.length;
      if (i == 0) {
        return;
      }
      if (this.selectedIndex == -1) {
        return;
      }
      int j = (getStyle() & 0x4000000) != 0 ? 16777220 : 16777219;
      int k = paramEvent.keyCode == j ? -1 : 1;
      int m;
      if (!this.mru)
      {
        m = this.selectedIndex + k;
      }
      else
      {
        int[] arrayOfInt = new int[this.items.length];
        int n = 0;
        int i1 = -1;
        for (int i2 = 0; i2 < this.items.length; i2++) {
          if (this.items[i2].showing)
          {
            if (i2 == this.selectedIndex) {
              i1 = n;
            }
            arrayOfInt[(n++)] = i2;
          }
        }
        if ((i1 + k >= 0) && (i1 + k < n))
        {
          m = arrayOfInt[(i1 + k)];
        }
        else
        {
          if (this.showChevron)
          {
            Rectangle localRectangle = this.chevronItem.getBounds();
            localRectangle = paramEvent.display.map(this.chevronTb, this, localRectangle);
            CTabFolderEvent localCTabFolderEvent = new CTabFolderEvent(this);
            localCTabFolderEvent.widget = this;
            localCTabFolderEvent.time = paramEvent.time;
            localCTabFolderEvent.x = localRectangle.x;
            localCTabFolderEvent.y = localRectangle.y;
            localCTabFolderEvent.width = localRectangle.width;
            localCTabFolderEvent.height = localRectangle.height;
            localCTabFolderEvent.doit = true;
            for (int i3 = 0; i3 < this.folderListeners.length; i3++) {
              this.folderListeners[i3].showList(localCTabFolderEvent);
            }
            if ((localCTabFolderEvent.doit) && (!isDisposed())) {
              showList(localRectangle);
            }
          }
          return;
        }
      }
      if ((m < 0) || (m >= i)) {
        return;
      }
      setSelection(m, true);
      forceFocus();
    }
  }
  
  void onDispose(Event paramEvent)
  {
    removeListener(12, this.listener);
    notifyListeners(12, paramEvent);
    paramEvent.type = 0;
    this.inDispose = true;
    if ((this.showMenu != null) && (!this.showMenu.isDisposed()))
    {
      this.showMenu.dispose();
      this.showMenu = null;
    }
    int i = this.items.length;
    for (int j = 0; j < i; j++) {
      if (this.items[j] != null) {
        this.items[j].dispose();
      }
    }
    this.gradientColors = null;
    this.selectionGradientColors = null;
    this.selectionGradientPercents = null;
    this.selectionBgImage = null;
    this.selectionBackground = null;
    this.selectionForeground = null;
    if (this.controlBkImages != null)
    {
      for (j = 0; j < this.controlBkImages.length; j++) {
        if (this.controlBkImages[j] != null)
        {
          this.controlBkImages[j].dispose();
          this.controlBkImages[j] = null;
        }
      }
      this.controlBkImages = null;
    }
    this.controls = null;
    this.controlAlignments = null;
    this.controlRects = null;
    if (this.maxImage != null) {
      this.maxImage.dispose();
    }
    this.maxImage = null;
    if (this.minImage != null) {
      this.minImage.dispose();
    }
    this.minImage = null;
    if (this.chevronImage != null) {
      this.chevronImage.dispose();
    }
    this.chevronImage = null;
    if (this.renderer != null) {
      this.renderer.dispose();
    }
    this.renderer = null;
    this.minItem = null;
    this.maxItem = null;
    this.minMaxTb = null;
    this.chevronItem = null;
    this.chevronTb = null;
    if (this.folderListeners.length != 0) {
      this.folderListeners = new CTabFolder2Listener[0];
    }
    if (this.tabListeners.length != 0) {
      this.tabListeners = new CTabFolderListener[0];
    }
  }
  
  void onDragDetect(Event paramEvent)
  {
    int i = 0;
    for (int j = 0; j < this.items.length; j++) {
      if (this.items[j].closeRect.contains(paramEvent.x, paramEvent.y))
      {
        i = 1;
        break;
      }
    }
    if (i != 0) {
      paramEvent.type = 0;
    }
  }
  
  void onFocus(Event paramEvent)
  {
    checkWidget();
    if (this.selectedIndex >= 0) {
      redraw();
    } else {
      setSelection(0, true);
    }
  }
  
  boolean onMnemonic(Event paramEvent, boolean paramBoolean)
  {
    char c = paramEvent.character;
    for (int i = 0; i < this.items.length; i++) {
      if (this.items[i] != null)
      {
        int j = _findMnemonic(this.items[i].getText());
        if ((j != 0) && (Character.toLowerCase(c) == j))
        {
          if (paramBoolean)
          {
            setSelection(i, true);
            forceFocus();
          }
          return true;
        }
      }
    }
    return false;
  }
  
  void onMenuDetect(Event paramEvent)
  {
    if ((paramEvent.detail == 1) && (this.selectedIndex != -1))
    {
      CTabItem localCTabItem = this.items[this.selectedIndex];
      Rectangle localRectangle1 = getDisplay().map(this, null, localCTabItem.getBounds());
      if (!localRectangle1.contains(paramEvent.x, paramEvent.y))
      {
        Rectangle localRectangle2 = this.renderer.computeTrim(this.selectedIndex, 0, 0, 0, 0, 0);
        Rectangle localRectangle3 = this.renderer.computeTrim(-8, 0, 0, 0, 0, 0);
        paramEvent.x = (localRectangle1.x + localRectangle1.width - localCTabItem.closeRect.width + localRectangle2.x - localRectangle3.width);
        paramEvent.y = (localRectangle1.y - localRectangle2.y - localRectangle3.y);
      }
    }
  }
  
  void onMouseDoubleClick(Event paramEvent)
  {
    if ((paramEvent.button != 1) || ((paramEvent.stateMask & 0x100000) != 0) || ((paramEvent.stateMask & 0x200000) != 0)) {
      return;
    }
    Event localEvent = new Event();
    localEvent.item = getItem(new Point(paramEvent.x, paramEvent.y));
    if (localEvent.item != null) {
      notifyListeners(14, localEvent);
    }
  }
  
  void onMouse(Event paramEvent)
  {
    if (isDisposed()) {
      return;
    }
    int i = paramEvent.x;
    int j = paramEvent.y;
    Object localObject1;
    int n;
    Object localObject2;
    switch (paramEvent.type)
    {
    case 6: 
      setToolTipText(null);
      break;
    case 7: 
      for (int k = 0; k < this.items.length; k++)
      {
        localObject1 = this.items[k];
        if ((k != this.selectedIndex) && (((CTabItem)localObject1).closeImageState != 8))
        {
          ((CTabItem)localObject1).closeImageState = 8;
          redraw(((CTabItem)localObject1).closeRect.x, ((CTabItem)localObject1).closeRect.y, ((CTabItem)localObject1).closeRect.width, ((CTabItem)localObject1).closeRect.height, false);
        }
        if ((((CTabItem)localObject1).state & 0x20) != 0)
        {
          localObject1.state &= 0xFFFFFFDF;
          redraw(((CTabItem)localObject1).x, ((CTabItem)localObject1).y, ((CTabItem)localObject1).width, ((CTabItem)localObject1).height, false);
        }
        if ((k == this.selectedIndex) && (((CTabItem)localObject1).closeImageState != 0))
        {
          ((CTabItem)localObject1).closeImageState = 0;
          redraw(((CTabItem)localObject1).closeRect.x, ((CTabItem)localObject1).closeRect.y, ((CTabItem)localObject1).closeRect.width, ((CTabItem)localObject1).closeRect.height, false);
        }
      }
      break;
    case 3: 
    case 32: 
      if ((this.hoverTb) && (this.hoverRect.contains(i, j)) && (!this.hovering))
      {
        this.hovering = true;
        updateItems();
        this.hoverTimerRunning = true;
        paramEvent.display.timerExec(2000, new Runnable()
        {
          public void run()
          {
            if (CTabFolder.this.isDisposed()) {
              return;
            }
            if (CTabFolder.this.hovering)
            {
              Display localDisplay = CTabFolder.this.getDisplay();
              Control localControl = localDisplay.getCursorControl();
              int i = 0;
              if (localControl != null) {
                for (int j = 0; j < CTabFolder.this.controls.length; j++)
                {
                  Object localObject = localControl;
                  do
                  {
                    if (localObject.equals(CTabFolder.this.controls[j]))
                    {
                      i = 1;
                    }
                    else
                    {
                      localObject = ((Control)localObject).getParent();
                      if ((localObject == null) || (localObject.equals(CTabFolder.this))) {
                        break;
                      }
                    }
                  } while (i == 0);
                  if (i != 0) {
                    break;
                  }
                }
              }
              if ((i != 0) && (CTabFolder.this.hoverTimerRunning))
              {
                localDisplay.timerExec(2000, this);
              }
              else
              {
                CTabFolder.this.hovering = false;
                CTabFolder.this.updateItems();
              }
            }
          }
        });
        return;
      }
      if (paramEvent.button != 1) {
        return;
      }
      CTabItem localCTabItem1 = null;
      if (this.single)
      {
        if (this.selectedIndex != -1)
        {
          localObject1 = this.items[this.selectedIndex].getBounds();
          if (((Rectangle)localObject1).contains(i, j)) {
            localCTabItem1 = this.items[this.selectedIndex];
          }
        }
      }
      else {
        for (n = 0; n < this.items.length; n++)
        {
          Rectangle localRectangle2 = this.items[n].getBounds();
          if (localRectangle2.contains(i, j)) {
            localCTabItem1 = this.items[n];
          }
        }
      }
      if (localCTabItem1 != null)
      {
        if (localCTabItem1.closeRect.contains(i, j))
        {
          localCTabItem1.closeImageState = 2;
          redraw(localCTabItem1.closeRect.x, localCTabItem1.closeRect.y, localCTabItem1.closeRect.width, localCTabItem1.closeRect.height, false);
          update();
          return;
        }
        n = indexOf(localCTabItem1);
        if (localCTabItem1.showing)
        {
          int i2 = this.selectedIndex;
          setSelection(n, true);
          if (i2 == this.selectedIndex) {
            forceFocus();
          }
        }
        return;
      }
      break;
    case 5: 
      _setToolTipText(paramEvent.x, paramEvent.y);
      int m = 0;
      for (n = 0; n < this.items.length; n++)
      {
        localObject2 = this.items[n];
        m = 0;
        if (((CTabItem)localObject2).getBounds().contains(i, j))
        {
          m = 1;
          if (((CTabItem)localObject2).closeRect.contains(i, j))
          {
            if ((((CTabItem)localObject2).closeImageState != 2) && (((CTabItem)localObject2).closeImageState != 32))
            {
              ((CTabItem)localObject2).closeImageState = 32;
              redraw(((CTabItem)localObject2).closeRect.x, ((CTabItem)localObject2).closeRect.y, ((CTabItem)localObject2).closeRect.width, ((CTabItem)localObject2).closeRect.height, false);
            }
          }
          else if (((CTabItem)localObject2).closeImageState != 0)
          {
            ((CTabItem)localObject2).closeImageState = 0;
            redraw(((CTabItem)localObject2).closeRect.x, ((CTabItem)localObject2).closeRect.y, ((CTabItem)localObject2).closeRect.width, ((CTabItem)localObject2).closeRect.height, false);
          }
          if ((((CTabItem)localObject2).state & 0x20) == 0)
          {
            localObject2.state |= 0x20;
            redraw(((CTabItem)localObject2).x, ((CTabItem)localObject2).y, ((CTabItem)localObject2).width, ((CTabItem)localObject2).height, false);
          }
        }
        if ((n != this.selectedIndex) && (((CTabItem)localObject2).closeImageState != 8) && (m == 0))
        {
          ((CTabItem)localObject2).closeImageState = 8;
          redraw(((CTabItem)localObject2).closeRect.x, ((CTabItem)localObject2).closeRect.y, ((CTabItem)localObject2).closeRect.width, ((CTabItem)localObject2).closeRect.height, false);
        }
        if (((((CTabItem)localObject2).state & 0x20) != 0) && (m == 0))
        {
          localObject2.state &= 0xFFFFFFDF;
          redraw(((CTabItem)localObject2).x, ((CTabItem)localObject2).y, ((CTabItem)localObject2).width, ((CTabItem)localObject2).height, false);
        }
        if ((n == this.selectedIndex) && (((CTabItem)localObject2).closeImageState != 0) && (m == 0))
        {
          ((CTabItem)localObject2).closeImageState = 0;
          redraw(((CTabItem)localObject2).closeRect.x, ((CTabItem)localObject2).closeRect.y, ((CTabItem)localObject2).closeRect.width, ((CTabItem)localObject2).closeRect.height, false);
        }
      }
      break;
    case 4: 
      if (paramEvent.button != 1) {
        return;
      }
      CTabItem localCTabItem2 = null;
      int i1;
      if (this.single)
      {
        if (this.selectedIndex != -1)
        {
          Rectangle localRectangle1 = this.items[this.selectedIndex].getBounds();
          if (localRectangle1.contains(i, j)) {
            localCTabItem2 = this.items[this.selectedIndex];
          }
        }
      }
      else {
        for (i1 = 0; i1 < this.items.length; i1++)
        {
          localObject2 = this.items[i1].getBounds();
          if (((Rectangle)localObject2).contains(i, j)) {
            localCTabItem2 = this.items[i1];
          }
        }
      }
      if ((localCTabItem2 != null) && (localCTabItem2.closeRect.contains(i, j)))
      {
        i1 = localCTabItem2.closeImageState == 2 ? 1 : 0;
        localCTabItem2.closeImageState = 32;
        redraw(localCTabItem2.closeRect.x, localCTabItem2.closeRect.y, localCTabItem2.closeRect.width, localCTabItem2.closeRect.height, false);
        if (i1 == 0) {
          return;
        }
        localObject2 = new CTabFolderEvent(this);
        ((CTabFolderEvent)localObject2).widget = this;
        ((CTabFolderEvent)localObject2).time = paramEvent.time;
        ((CTabFolderEvent)localObject2).item = localCTabItem2;
        ((CTabFolderEvent)localObject2).doit = true;
        Object localObject3;
        for (int i3 = 0; i3 < this.folderListeners.length; i3++)
        {
          localObject3 = this.folderListeners[i3];
          ((CTabFolder2Listener)localObject3).close((CTabFolderEvent)localObject2);
        }
        for (i3 = 0; i3 < this.tabListeners.length; i3++)
        {
          localObject3 = this.tabListeners[i3];
          ((CTabFolderListener)localObject3).itemClosed((CTabFolderEvent)localObject2);
        }
        if (((CTabFolderEvent)localObject2).doit) {
          localCTabItem2.dispose();
        }
        if ((!isDisposed()) && (localCTabItem2.isDisposed()))
        {
          Display localDisplay = getDisplay();
          localObject3 = localDisplay.getCursorLocation();
          localObject3 = localDisplay.map(null, this, ((Point)localObject3).x, ((Point)localObject3).y);
          CTabItem localCTabItem3 = getItem((Point)localObject3);
          if (localCTabItem3 != null) {
            if (localCTabItem3.closeRect.contains((Point)localObject3))
            {
              if ((localCTabItem3.closeImageState != 2) && (localCTabItem3.closeImageState != 32))
              {
                localCTabItem3.closeImageState = 32;
                redraw(localCTabItem3.closeRect.x, localCTabItem3.closeRect.y, localCTabItem3.closeRect.width, localCTabItem3.closeRect.height, false);
              }
            }
            else if (localCTabItem3.closeImageState != 0)
            {
              localCTabItem3.closeImageState = 0;
              redraw(localCTabItem3.closeRect.x, localCTabItem3.closeRect.y, localCTabItem3.closeRect.width, localCTabItem3.closeRect.height, false);
            }
          }
        }
        return;
      }
      break;
    }
  }
  
  void onPageTraversal(Event paramEvent)
  {
    int i = this.items.length;
    if (i == 0) {
      return;
    }
    int j = this.selectedIndex;
    if (j == -1)
    {
      j = 0;
    }
    else
    {
      int k = paramEvent.detail == 512 ? 1 : -1;
      if (!this.mru)
      {
        j = (this.selectedIndex + k + i) % i;
      }
      else
      {
        int[] arrayOfInt = new int[this.items.length];
        int m = 0;
        int n = -1;
        for (int i1 = 0; i1 < this.items.length; i1++) {
          if (this.items[i1].showing)
          {
            if (i1 == this.selectedIndex) {
              n = m;
            }
            arrayOfInt[(m++)] = i1;
          }
        }
        if ((n + k >= 0) && (n + k < m))
        {
          j = arrayOfInt[(n + k)];
        }
        else if (this.showChevron)
        {
          Rectangle localRectangle = this.chevronItem.getBounds();
          localRectangle = paramEvent.display.map(this.chevronTb, this, localRectangle);
          CTabFolderEvent localCTabFolderEvent = new CTabFolderEvent(this);
          localCTabFolderEvent.widget = this;
          localCTabFolderEvent.time = paramEvent.time;
          localCTabFolderEvent.x = localRectangle.x;
          localCTabFolderEvent.y = localRectangle.y;
          localCTabFolderEvent.width = localRectangle.width;
          localCTabFolderEvent.height = localRectangle.height;
          localCTabFolderEvent.doit = true;
          for (int i2 = 0; i2 < this.folderListeners.length; i2++) {
            this.folderListeners[i2].showList(localCTabFolderEvent);
          }
          if ((localCTabFolderEvent.doit) && (!isDisposed())) {
            showList(localRectangle);
          }
        }
      }
    }
    setSelection(j, true);
  }
  
  void onPaint(Event paramEvent)
  {
    if (this.inDispose) {
      return;
    }
    Font localFont1 = getFont();
    if ((this.oldFont == null) || (!this.oldFont.equals(localFont1)))
    {
      this.oldFont = localFont1;
      if (!updateTabHeight(false))
      {
        updateItems();
        redraw();
        return;
      }
    }
    GC localGC = paramEvent.gc;
    Font localFont2 = localGC.getFont();
    Color localColor1 = localGC.getBackground();
    Color localColor2 = localGC.getForeground();
    Point localPoint = getSize();
    Rectangle localRectangle1 = new Rectangle(0, 0, localPoint.x, localPoint.y);
    this.renderer.draw(-1, 24, localRectangle1, localGC);
    localGC.setFont(localFont2);
    localGC.setForeground(localColor2);
    localGC.setBackground(localColor1);
    this.renderer.draw(-2, 24, localRectangle1, localGC);
    localGC.setFont(localFont2);
    localGC.setForeground(localColor2);
    localGC.setBackground(localColor1);
    if (!this.single) {
      for (int i = 0; i < this.items.length; i++)
      {
        Rectangle localRectangle3 = this.items[i].getBounds();
        if ((i != this.selectedIndex) && (paramEvent.getBounds().intersects(localRectangle3))) {
          this.renderer.draw(i, 0x18 | this.items[i].state, localRectangle3, localGC);
        }
      }
    }
    localGC.setFont(localFont2);
    localGC.setForeground(localColor2);
    localGC.setBackground(localColor1);
    if (this.selectedIndex != -1) {
      this.renderer.draw(this.selectedIndex, this.items[this.selectedIndex].state | 0x8 | 0x10, this.items[this.selectedIndex].getBounds(), localGC);
    }
    localGC.setFont(localFont2);
    localGC.setForeground(localColor2);
    localGC.setBackground(localColor1);
    if (this.hoverTb)
    {
      Rectangle localRectangle2 = this.renderer.computeTrim(-3, 0, 0, 0, 0, 0);
      int j = getSize().x - (localRectangle2.width + localRectangle2.x);
      this.hoverRect = new Rectangle(j - 16 - 3, 2, 16, getTabHeight() - 2);
      localGC.setForeground(localGC.getDevice().getSystemColor(18));
      j = this.hoverRect.x;
      int k = this.hoverRect.y;
      localGC.setBackground(localGC.getDevice().getSystemColor(1));
      localGC.fillRectangle(j + this.hoverRect.width - 6, k, 5, 5);
      localGC.drawRectangle(j + this.hoverRect.width - 6, k, 5, 5);
      localGC.drawLine(j + this.hoverRect.width - 6, k + 2, j + this.hoverRect.width - 6 + 5, k + 2);
      localGC.fillRectangle(j, k, 5, 2);
      localGC.drawRectangle(j, k, 5, 2);
    }
    localGC.setFont(localFont2);
    localGC.setForeground(localColor2);
    localGC.setBackground(localColor1);
  }
  
  void onResize(Event paramEvent)
  {
    if (this.inDispose) {
      return;
    }
    if (this.ignoreResize) {
      return;
    }
    if (updateItems()) {
      redrawTabs();
    }
    Point localPoint = getSize();
    if (this.oldSize == null)
    {
      redraw();
    }
    else if ((this.onBottom) && (localPoint.y != this.oldSize.y))
    {
      redraw();
    }
    else
    {
      int i = Math.min(localPoint.x, this.oldSize.x);
      Rectangle localRectangle = this.renderer.computeTrim(-1, 0, 0, 0, 0, 0);
      if (localPoint.x != this.oldSize.x) {
        i -= localRectangle.width + localRectangle.x - this.marginWidth + 2;
      }
      if (!this.simple) {
        i -= 5;
      }
      int j = Math.min(localPoint.y, this.oldSize.y);
      if (localPoint.y != this.oldSize.y) {
        j -= localRectangle.height + localRectangle.y - this.marginHeight;
      }
      int k = Math.max(localPoint.x, this.oldSize.x);
      int m = Math.max(localPoint.y, this.oldSize.y);
      redraw(0, j, k, m - j, false);
      redraw(i, 0, k - i, m, false);
      if (this.hoverTb) {
        redraw(this.hoverRect.x, this.hoverRect.y, this.hoverRect.width, this.hoverRect.height, false);
      }
    }
    this.oldSize = localPoint;
  }
  
  void onSelection(Event paramEvent)
  {
    if (this.hovering)
    {
      this.hovering = false;
      updateItems();
    }
    Object localObject;
    int i;
    if (paramEvent.widget == this.maxItem)
    {
      localObject = new CTabFolderEvent(this);
      ((CTabFolderEvent)localObject).widget = this;
      ((CTabFolderEvent)localObject).time = paramEvent.time;
      for (i = 0; i < this.folderListeners.length; i++) {
        if (this.maximized) {
          this.folderListeners[i].restore((CTabFolderEvent)localObject);
        } else {
          this.folderListeners[i].maximize((CTabFolderEvent)localObject);
        }
      }
    }
    else if (paramEvent.widget == this.minItem)
    {
      localObject = new CTabFolderEvent(this);
      ((CTabFolderEvent)localObject).widget = this;
      ((CTabFolderEvent)localObject).time = paramEvent.time;
      for (i = 0; i < this.folderListeners.length; i++) {
        if (this.minimized) {
          this.folderListeners[i].restore((CTabFolderEvent)localObject);
        } else {
          this.folderListeners[i].minimize((CTabFolderEvent)localObject);
        }
      }
    }
    else if (paramEvent.widget == this.chevronItem)
    {
      localObject = this.chevronItem.getBounds();
      localObject = paramEvent.display.map(this.chevronTb, this, (Rectangle)localObject);
      CTabFolderEvent localCTabFolderEvent = new CTabFolderEvent(this);
      localCTabFolderEvent.widget = this;
      localCTabFolderEvent.time = paramEvent.time;
      localCTabFolderEvent.x = ((Rectangle)localObject).x;
      localCTabFolderEvent.y = ((Rectangle)localObject).y;
      localCTabFolderEvent.width = ((Rectangle)localObject).width;
      localCTabFolderEvent.height = ((Rectangle)localObject).height;
      localCTabFolderEvent.doit = true;
      for (int j = 0; j < this.folderListeners.length; j++) {
        this.folderListeners[j].showList(localCTabFolderEvent);
      }
      if ((localCTabFolderEvent.doit) && (!isDisposed())) {
        showList((Rectangle)localObject);
      }
    }
  }
  
  void onTraverse(Event paramEvent)
  {
    if (this.ignoreTraverse) {
      return;
    }
    runUpdate();
    switch (paramEvent.detail)
    {
    case 2: 
    case 4: 
    case 8: 
    case 16: 
      Control localControl = getDisplay().getFocusControl();
      if (localControl == this) {
        paramEvent.doit = true;
      }
      break;
    case 128: 
      paramEvent.doit = onMnemonic(paramEvent, false);
      break;
    case 256: 
    case 512: 
      paramEvent.doit = (this.items.length > 0);
    }
    this.ignoreTraverse = true;
    notifyListeners(31, paramEvent);
    this.ignoreTraverse = false;
    paramEvent.type = 0;
    if (isDisposed()) {
      return;
    }
    if (!paramEvent.doit) {
      return;
    }
    switch (paramEvent.detail)
    {
    case 128: 
      onMnemonic(paramEvent, true);
      paramEvent.detail = 0;
      break;
    case 256: 
    case 512: 
      onPageTraversal(paramEvent);
      paramEvent.detail = 0;
    }
  }
  
  void redrawTabs()
  {
    Point localPoint = getSize();
    Rectangle localRectangle = this.renderer.computeTrim(-1, 0, 0, 0, 0, 0);
    if (this.onBottom)
    {
      int i = localRectangle.height + localRectangle.y - this.marginHeight;
      redraw(0, localPoint.y - i - 1, localPoint.x, i + 1, false);
    }
    else
    {
      redraw(0, 0, localPoint.x, -localRectangle.y - this.marginHeight + 1, false);
    }
  }
  
  public void removeCTabFolder2Listener(CTabFolder2Listener paramCTabFolder2Listener)
  {
    checkWidget();
    if (paramCTabFolder2Listener == null) {
      SWT.error(4);
    }
    if (this.folderListeners.length == 0) {
      return;
    }
    int i = -1;
    for (int j = 0; j < this.folderListeners.length; j++) {
      if (paramCTabFolder2Listener == this.folderListeners[j])
      {
        i = j;
        break;
      }
    }
    if (i == -1) {
      return;
    }
    if (this.folderListeners.length == 1)
    {
      this.folderListeners = new CTabFolder2Listener[0];
      return;
    }
    CTabFolder2Listener[] arrayOfCTabFolder2Listener = new CTabFolder2Listener[this.folderListeners.length - 1];
    System.arraycopy(this.folderListeners, 0, arrayOfCTabFolder2Listener, 0, i);
    System.arraycopy(this.folderListeners, i + 1, arrayOfCTabFolder2Listener, i, this.folderListeners.length - i - 1);
    this.folderListeners = arrayOfCTabFolder2Listener;
  }
  
  @Deprecated
  public void removeCTabFolderListener(CTabFolderListener paramCTabFolderListener)
  {
    checkWidget();
    if (paramCTabFolderListener == null) {
      SWT.error(4);
    }
    if (this.tabListeners.length == 0) {
      return;
    }
    int i = -1;
    for (int j = 0; j < this.tabListeners.length; j++) {
      if (paramCTabFolderListener == this.tabListeners[j])
      {
        i = j;
        break;
      }
    }
    if (i == -1) {
      return;
    }
    if (this.tabListeners.length == 1)
    {
      this.tabListeners = new CTabFolderListener[0];
      return;
    }
    CTabFolderListener[] arrayOfCTabFolderListener = new CTabFolderListener[this.tabListeners.length - 1];
    System.arraycopy(this.tabListeners, 0, arrayOfCTabFolderListener, 0, i);
    System.arraycopy(this.tabListeners, i + 1, arrayOfCTabFolderListener, i, this.tabListeners.length - i - 1);
    this.tabListeners = arrayOfCTabFolderListener;
  }
  
  public void removeSelectionListener(SelectionListener paramSelectionListener)
  {
    checkWidget();
    if (paramSelectionListener == null) {
      SWT.error(4);
    }
    removeListener(13, paramSelectionListener);
    removeListener(14, paramSelectionListener);
  }
  
  public void reskin(int paramInt)
  {
    super.reskin(paramInt);
    for (int i = 0; i < this.items.length; i++) {
      this.items[i].reskin(paramInt);
    }
  }
  
  public void setBackground(Color paramColor)
  {
    super.setBackground(paramColor);
    this.renderer.createAntialiasColors();
    updateBkImages();
    redraw();
  }
  
  public void setBackground(Color[] paramArrayOfColor, int[] paramArrayOfInt)
  {
    setBackground(paramArrayOfColor, paramArrayOfInt, false);
  }
  
  public void setBackground(Color[] paramArrayOfColor, int[] paramArrayOfInt, boolean paramBoolean)
  {
    checkWidget();
    int i;
    if (paramArrayOfColor != null)
    {
      if ((paramArrayOfInt == null) || (paramArrayOfInt.length != paramArrayOfColor.length - 1)) {
        SWT.error(5);
      }
      for (i = 0; i < paramArrayOfInt.length; i++)
      {
        if ((paramArrayOfInt[i] < 0) || (paramArrayOfInt[i] > 100)) {
          SWT.error(5);
        }
        if ((i > 0) && (paramArrayOfInt[i] < paramArrayOfInt[(i - 1)])) {
          SWT.error(5);
        }
      }
      if (getDisplay().getDepth() < 15)
      {
        paramArrayOfColor = new Color[] { paramArrayOfColor[(paramArrayOfColor.length - 1)] };
        paramArrayOfInt = new int[0];
      }
    }
    int j;
    if ((this.gradientColors != null) && (paramArrayOfColor != null) && (this.gradientColors.length == paramArrayOfColor.length))
    {
      i = 0;
      for (int m = 0; m < this.gradientColors.length; m++)
      {
        if (this.gradientColors[m] == null) {
          i = paramArrayOfColor[m] == null ? 1 : 0;
        } else {
          j = this.gradientColors[m].equals(paramArrayOfColor[m]);
        }
        if (j == 0) {
          break;
        }
      }
      if (j != 0) {
        for (m = 0; m < this.gradientPercents.length; m++)
        {
          j = this.gradientPercents[m] == paramArrayOfInt[m] ? 1 : 0;
          if (j == 0) {
            break;
          }
        }
      }
      if ((j != 0) && (this.gradientVertical == paramBoolean)) {
        return;
      }
    }
    if (paramArrayOfColor == null)
    {
      this.gradientColors = null;
      this.gradientPercents = null;
      this.gradientVertical = false;
      setBackground((Color)null);
    }
    else
    {
      this.gradientColors = new Color[paramArrayOfColor.length];
      for (j = 0; j < paramArrayOfColor.length; j++) {
        this.gradientColors[j] = paramArrayOfColor[j];
      }
      this.gradientPercents = new int[paramArrayOfInt.length];
      for (int k = 0; k < paramArrayOfInt.length; k++) {
        this.gradientPercents[k] = paramArrayOfInt[k];
      }
      this.gradientVertical = paramBoolean;
      setBackground(this.gradientColors[(this.gradientColors.length - 1)]);
    }
    redraw();
  }
  
  public void setBackgroundImage(Image paramImage)
  {
    super.setBackgroundImage(paramImage);
    this.renderer.createAntialiasColors();
    redraw();
  }
  
  public void setBorderVisible(boolean paramBoolean)
  {
    checkWidget();
    if (this.borderVisible == paramBoolean) {
      return;
    }
    this.borderVisible = paramBoolean;
    updateFolder(2);
  }
  
  void setButtonBounds(GC paramGC)
  {
    Point localPoint = getSize();
    Display localDisplay = getDisplay();
    if (this.showMax)
    {
      if (this.minMaxTb == null)
      {
        this.minMaxTb = new ToolBar(this, 8388608);
        initAccessibleMinMaxTb();
        addTabControl(this.minMaxTb, 131072, 0, false);
      }
      if (this.maxItem == null)
      {
        this.maxItem = new ToolItem(this.minMaxTb, 8);
        if (this.maxImage == null) {
          this.maxImage = createButtonImage(localDisplay, -5);
        }
        this.maxItem.setImage(this.maxImage);
        this.maxItem.setToolTipText(this.maximized ? SWT.getMessage("SWT_Restore") : SWT.getMessage("SWT_Maximize"));
        this.maxItem.addListener(13, this.listener);
      }
    }
    else if (this.maxItem != null)
    {
      this.maxItem.dispose();
      this.maxItem = null;
    }
    if (this.showMin)
    {
      if (this.minMaxTb == null)
      {
        this.minMaxTb = new ToolBar(this, 8388608);
        initAccessibleMinMaxTb();
        addTabControl(this.minMaxTb, 131072, 0, false);
      }
      if (this.minItem == null)
      {
        this.minItem = new ToolItem(this.minMaxTb, 8, 0);
        if (this.minImage == null) {
          this.minImage = createButtonImage(localDisplay, -6);
        }
        this.minItem.setImage(this.minImage);
        this.minItem.setToolTipText(this.minimized ? SWT.getMessage("SWT_Restore") : SWT.getMessage("SWT_Minimize"));
        this.minItem.addListener(13, this.listener);
      }
    }
    else if (this.minItem != null)
    {
      this.minItem.dispose();
      this.minItem = null;
    }
    if ((this.minMaxTb != null) && (this.minMaxTb.getItemCount() == 0))
    {
      removeTabControl(this.minMaxTb, false);
      this.minMaxTb.dispose();
      this.minMaxTb = null;
    }
    if (this.showChevron)
    {
      int i = this.items.length;
      int j;
      if (this.single)
      {
        j = this.selectedIndex == -1 ? i : i - 1;
      }
      else
      {
        for (k = 0; (k < this.priority.length) && (this.items[this.priority[k]].showing); k++) {}
        j = i - k;
      }
      if (j != this.chevronCount)
      {
        this.chevronCount = j;
        if (this.chevronImage != null) {
          this.chevronImage.dispose();
        }
        this.chevronImage = createButtonImage(localDisplay, -7);
        this.chevronItem.setImage(this.chevronImage);
      }
    }
    boolean[][] arrayOfBoolean = new boolean[1][0];
    Rectangle[] arrayOfRectangle = computeControlBounds(localPoint, arrayOfBoolean);
    if (this.fixedTabHeight != -1)
    {
      k = this.fixedTabHeight;
      if (!this.hovering)
      {
        this.hoverTb = false;
        Rectangle localRectangle = getBounds();
        for (n = 0; n < arrayOfRectangle.length; n++) {
          if ((arrayOfBoolean[0][n] == 0) && (arrayOfRectangle[n].height > k))
          {
            this.hoverTb = true;
            break;
          }
        }
        if (this.hoverTb) {
          for (n = 0; n < arrayOfRectangle.length; n++) {
            if ((arrayOfBoolean[0][n] == 0) && (arrayOfRectangle[n].height > k)) {
              arrayOfRectangle[n].x = (localRectangle.width + 20);
            }
          }
        }
      }
    }
    int k = 0;
    for (int m = 0; m < arrayOfRectangle.length; m++) {
      if (arrayOfBoolean[0][m] == 0) {
        k = Math.max(arrayOfRectangle[m].height, k);
      }
    }
    m = 0;
    this.ignoreResize = true;
    for (int n = 0; n < this.controls.length; n++)
    {
      if (!this.controls[n].isDisposed()) {
        if (arrayOfBoolean[0][n] != 0)
        {
          this.controls[n].setBounds(arrayOfRectangle[n]);
        }
        else
        {
          this.controls[n].moveAbove(null);
          this.controls[n].setBounds(arrayOfRectangle[n].x, arrayOfRectangle[n].y, arrayOfRectangle[n].width, k);
        }
      }
      if ((m == 0) && (!arrayOfRectangle[n].equals(this.controlRects[n]))) {
        m = 1;
      }
    }
    this.ignoreResize = false;
    this.controlRects = arrayOfRectangle;
    if ((m != 0) || (this.hovering)) {
      updateBkImages();
    }
  }
  
  public boolean setFocus()
  {
    checkWidget();
    Control localControl = getDisplay().getFocusControl();
    boolean bool = isAncestor(localControl);
    if (bool)
    {
      CTabItem localCTabItem = getSelection();
      if ((localCTabItem != null) && (localCTabItem.setFocus())) {
        return true;
      }
    }
    return super.setFocus();
  }
  
  boolean isAncestor(Control paramControl)
  {
    while ((paramControl != null) && (paramControl != this) && (!(paramControl instanceof Shell))) {
      paramControl = paramControl.getParent();
    }
    return paramControl == this;
  }
  
  public void setFont(Font paramFont)
  {
    checkWidget();
    if ((paramFont != null) && (paramFont.equals(getFont()))) {
      return;
    }
    super.setFont(paramFont);
    this.oldFont = getFont();
    updateFolder(2);
  }
  
  public void setForeground(Color paramColor)
  {
    super.setForeground(paramColor);
    redraw();
  }
  
  public void setInsertMark(CTabItem paramCTabItem, boolean paramBoolean)
  {
    checkWidget();
  }
  
  public void setInsertMark(int paramInt, boolean paramBoolean)
  {
    checkWidget();
    if ((paramInt < -1) || (paramInt >= getItemCount())) {
      SWT.error(5);
    }
  }
  
  boolean setItemLocation(GC paramGC)
  {
    boolean bool = false;
    if (this.items.length == 0) {
      return false;
    }
    Rectangle localRectangle1 = this.renderer.computeTrim(-3, 0, 0, 0, 0, 0);
    int i = localRectangle1.height + localRectangle1.y;
    int j = -localRectangle1.y;
    Point localPoint1 = getSize();
    int k = this.onBottom ? Math.max(i, localPoint1.y - i - this.tabHeight) : j;
    Point localPoint2 = this.renderer.computeSize(-8, 0, paramGC, -1, -1);
    int m = getLeftItemEdge(paramGC, -3);
    int n;
    int i1;
    int i3;
    if (this.single)
    {
      n = getDisplay().getBounds().width + 10;
      for (i1 = 0; i1 < this.items.length; i1++)
      {
        CTabItem localCTabItem1 = this.items[i1];
        if (i1 == this.selectedIndex)
        {
          this.firstIndex = this.selectedIndex;
          i3 = localCTabItem1.x;
          int i4 = localCTabItem1.y;
          localCTabItem1.x = m;
          localCTabItem1.y = k;
          localCTabItem1.showing = true;
          if ((this.showClose) || (localCTabItem1.showClose))
          {
            localCTabItem1.closeRect.x = (m - this.renderer.computeTrim(i1, 0, 0, 0, 0, 0).x);
            localCTabItem1.closeRect.y = (this.onBottom ? localPoint1.y - i - this.tabHeight + (this.tabHeight - localPoint2.y) / 2 : j + (this.tabHeight - localPoint2.y) / 2);
          }
          if ((localCTabItem1.x != i3) || (localCTabItem1.y != i4)) {
            bool = true;
          }
        }
        else
        {
          localCTabItem1.x = n;
          localCTabItem1.showing = false;
        }
      }
    }
    else
    {
      n = getRightItemEdge(paramGC);
      i1 = n - m;
      int i2 = 0;
      for (i3 = 0; i3 < this.priority.length; i3++)
      {
        CTabItem localCTabItem2 = this.items[this.priority[i3]];
        i2 += localCTabItem2.width;
        localCTabItem2.showing = (i3 == 0);
      }
      i3 = getLeftItemEdge(paramGC, -2);
      int i5 = getDisplay().getBounds().width + 10;
      this.firstIndex = (this.items.length - 1);
      for (int i6 = 0; i6 < this.items.length; i6++)
      {
        CTabItem localCTabItem3 = this.items[i6];
        if (!localCTabItem3.showing)
        {
          if (localCTabItem3.x != i5) {
            bool = true;
          }
          localCTabItem3.x = i5;
        }
        else
        {
          this.firstIndex = Math.min(this.firstIndex, i6);
          if ((localCTabItem3.x != i3) || (localCTabItem3.y != k)) {
            bool = true;
          }
          localCTabItem3.x = i3;
          localCTabItem3.y = k;
          int i7 = 0;
          if (i6 == this.selectedIndex) {
            i7 |= 0x2;
          }
          Rectangle localRectangle2 = this.renderer.computeTrim(i6, i7, 0, 0, 0, 0);
          localCTabItem3.closeRect.x = (localCTabItem3.x + localCTabItem3.width - (localRectangle2.width + localRectangle2.x) - localPoint2.x);
          localCTabItem3.closeRect.y = (this.onBottom ? localPoint1.y - i - this.tabHeight + (this.tabHeight - localPoint2.y) / 2 : j + (this.tabHeight - localPoint2.y) / 2);
          i3 += localCTabItem3.width;
          if ((!this.simple) && (i6 == this.selectedIndex)) {
            i3 -= this.renderer.curveIndent;
          }
        }
      }
    }
    return bool;
  }
  
  void setItemOrder(int[] paramArrayOfInt)
  {
    checkWidget();
    if (paramArrayOfInt == null) {
      SWT.error(4);
    }
    if (paramArrayOfInt.length != this.items.length) {
      SWT.error(5);
    }
    int i = -1;
    boolean[] arrayOfBoolean = new boolean[this.items.length];
    CTabItem[] arrayOfCTabItem = new CTabItem[this.items.length];
    for (int j = 0; j < paramArrayOfInt.length; j++)
    {
      int k = paramArrayOfInt[j];
      if ((0 > k) || (k >= this.items.length)) {
        SWT.error(5);
      }
      if (arrayOfBoolean[k] != 0) {
        SWT.error(5);
      }
      arrayOfBoolean[k] = true;
      if (k == this.selectedIndex) {
        i = j;
      }
      arrayOfCTabItem[j] = this.items[k];
    }
    this.items = arrayOfCTabItem;
    this.selectedIndex = i;
    updateFolder(2);
  }
  
  boolean setItemSize(GC paramGC)
  {
    boolean bool = false;
    if (isDisposed()) {
      return bool;
    }
    Point localPoint1 = getSize();
    if ((localPoint1.x <= 0) || (localPoint1.y <= 0)) {
      return bool;
    }
    ToolBar localToolBar = getChevron();
    if (localToolBar != null) {
      localToolBar.setVisible(false);
    }
    this.showChevron = false;
    Object localObject1;
    if (this.single)
    {
      this.showChevron = ((this.chevronVisible) && (this.items.length > 1));
      if (this.showChevron) {
        localToolBar.setVisible(true);
      }
      if (this.selectedIndex != -1)
      {
        localObject1 = this.items[this.selectedIndex];
        i = this.renderer.computeSize(this.selectedIndex, 2, paramGC, -1, -1).x;
        i = Math.min(i, getRightItemEdge(paramGC) - getLeftItemEdge(paramGC, -3));
        if ((((CTabItem)localObject1).height != this.tabHeight) || (((CTabItem)localObject1).width != i))
        {
          bool = true;
          ((CTabItem)localObject1).shortenedText = null;
          ((CTabItem)localObject1).shortenedTextWidth = 0;
          ((CTabItem)localObject1).height = this.tabHeight;
          ((CTabItem)localObject1).width = i;
          ((CTabItem)localObject1).closeRect.width = (((CTabItem)localObject1).closeRect.height = 0);
          if ((this.showClose) || (((CTabItem)localObject1).showClose))
          {
            Point localPoint2 = this.renderer.computeSize(-8, 2, paramGC, -1, -1);
            ((CTabItem)localObject1).closeRect.width = localPoint2.x;
            ((CTabItem)localObject1).closeRect.height = localPoint2.y;
          }
        }
      }
      return bool;
    }
    if (this.items.length == 0) {
      return bool;
    }
    int i = Math.max(0, getRightItemEdge(paramGC) - getLeftItemEdge(paramGC, -3));
    int j = 0;
    int[] arrayOfInt = new int[this.items.length];
    int n;
    for (int k = 0; k < this.priority.length; k++)
    {
      int m = this.priority[k];
      n = 16777216;
      if (m == this.selectedIndex) {
        n |= 0x2;
      }
      arrayOfInt[m] = this.renderer.computeSize(m, n, paramGC, -1, -1).x;
      j += arrayOfInt[m];
      if (j > i) {
        break;
      }
    }
    Object localObject2;
    if (j > i)
    {
      this.showChevron = ((this.chevronVisible) && (this.items.length > 1));
      if (this.showChevron)
      {
        i -= localToolBar.computeSize(-1, -1).x;
        localToolBar.setVisible(true);
      }
      localObject1 = arrayOfInt;
      k = this.selectedIndex != -1 ? this.selectedIndex : 0;
      if (i < localObject1[k]) {
        localObject1[k] = Math.max(0, i);
      }
    }
    else
    {
      k = 0;
      localObject2 = new int[this.items.length];
      int i1;
      for (n = 0; n < this.items.length; n++)
      {
        i1 = 0;
        if (n == this.selectedIndex) {
          i1 |= 0x2;
        }
        localObject2[n] = this.renderer.computeSize(n, i1, paramGC, -1, -1).x;
        k += localObject2[n];
      }
      if (k <= i)
      {
        localObject1 = localObject2;
      }
      else
      {
        for (n = (i - j) / this.items.length;; n++)
        {
          i1 = 0;
          int i2 = 0;
          for (int i3 = 0; i3 < this.items.length; i3++) {
            if (localObject2[i3] > arrayOfInt[i3] + n)
            {
              i2 += arrayOfInt[i3] + n;
              i1++;
            }
            else
            {
              i2 += localObject2[i3];
            }
          }
          if (i2 >= i) {
            n--;
          } else {
            if ((i1 == 0) || (i - i2 < i1)) {
              break;
            }
          }
        }
        localObject1 = new int[this.items.length];
        for (i1 = 0; i1 < this.items.length; i1++) {
          localObject1[i1] = Math.min(localObject2[i1], arrayOfInt[i1] + n);
        }
      }
    }
    for (k = 0; k < this.items.length; k++)
    {
      localObject2 = this.items[k];
      n = localObject1[k];
      if ((((CTabItem)localObject2).height != this.tabHeight) || (((CTabItem)localObject2).width != n))
      {
        bool = true;
        ((CTabItem)localObject2).shortenedText = null;
        ((CTabItem)localObject2).shortenedTextWidth = 0;
        ((CTabItem)localObject2).height = this.tabHeight;
        ((CTabItem)localObject2).width = n;
        ((CTabItem)localObject2).closeRect.width = (((CTabItem)localObject2).closeRect.height = 0);
        if (((this.showClose) || (((CTabItem)localObject2).showClose)) && ((k == this.selectedIndex) || (this.showUnselectedClose)))
        {
          Point localPoint3 = this.renderer.computeSize(-8, 0, paramGC, -1, -1);
          ((CTabItem)localObject2).closeRect.width = localPoint3.x;
          ((CTabItem)localObject2).closeRect.height = localPoint3.y;
        }
      }
    }
    return bool;
  }
  
  public void setMaximizeVisible(boolean paramBoolean)
  {
    checkWidget();
    if (this.showMax == paramBoolean) {
      return;
    }
    this.showMax = paramBoolean;
    updateFolder(10);
  }
  
  public void setLayout(Layout paramLayout)
  {
    checkWidget();
  }
  
  public void setMaximized(boolean paramBoolean)
  {
    checkWidget();
    if (this.maximized == paramBoolean) {
      return;
    }
    if ((paramBoolean) && (this.minimized)) {
      setMinimized(false);
    }
    this.maximized = paramBoolean;
    if ((this.minMaxTb != null) && (this.maxItem != null))
    {
      if (this.maxImage != null) {
        this.maxImage.dispose();
      }
      this.maxImage = createButtonImage(getDisplay(), -5);
      this.maxItem.setImage(this.maxImage);
      this.maxItem.setToolTipText(this.maximized ? SWT.getMessage("SWT_Restore") : SWT.getMessage("SWT_Maximize"));
    }
  }
  
  public void setMinimizeVisible(boolean paramBoolean)
  {
    checkWidget();
    if (this.showMin == paramBoolean) {
      return;
    }
    this.showMin = paramBoolean;
    updateFolder(10);
  }
  
  public void setMinimized(boolean paramBoolean)
  {
    checkWidget();
    if (this.minimized == paramBoolean) {
      return;
    }
    if ((paramBoolean) && (this.maximized)) {
      setMaximized(false);
    }
    this.minimized = paramBoolean;
    if ((this.minMaxTb != null) && (this.minItem != null))
    {
      if (this.minImage != null) {
        this.minImage.dispose();
      }
      this.minImage = createButtonImage(getDisplay(), -6);
      this.minItem.setImage(this.minImage);
      this.minItem.setToolTipText(this.minimized ? SWT.getMessage("SWT_Restore") : SWT.getMessage("SWT_Minimize"));
    }
  }
  
  public void setMinimumCharacters(int paramInt)
  {
    checkWidget();
    if (paramInt < 0) {
      SWT.error(6);
    }
    if (this.minChars == paramInt) {
      return;
    }
    this.minChars = paramInt;
    updateFolder(4);
  }
  
  public void setMRUVisible(boolean paramBoolean)
  {
    checkWidget();
    if (this.mru == paramBoolean) {
      return;
    }
    this.mru = paramBoolean;
    if (!this.mru)
    {
      if (this.firstIndex == -1) {
        return;
      }
      int i = this.firstIndex;
      int j = 0;
      for (int k = this.firstIndex; k < this.items.length; k++) {
        this.priority[(j++)] = k;
      }
      for (k = 0; k < i; k++) {
        this.priority[(j++)] = k;
      }
      updateFolder(4);
    }
  }
  
  public void setRenderer(CTabFolderRenderer paramCTabFolderRenderer)
  {
    checkWidget();
    if ((this.renderer == paramCTabFolderRenderer) || ((this.useDefaultRenderer) && (paramCTabFolderRenderer == null))) {
      return;
    }
    if (this.renderer != null) {
      this.renderer.dispose();
    }
    this.useDefaultRenderer = (paramCTabFolderRenderer == null);
    if (this.useDefaultRenderer) {
      paramCTabFolderRenderer = new CTabFolderRenderer(this);
    }
    this.renderer = paramCTabFolderRenderer;
    updateFolder(2);
  }
  
  public void setSelection(CTabItem paramCTabItem)
  {
    checkWidget();
    if (paramCTabItem == null) {
      SWT.error(4);
    }
    int i = indexOf(paramCTabItem);
    setSelection(i);
  }
  
  public void setSelection(int paramInt)
  {
    checkWidget();
    if ((paramInt < 0) || (paramInt >= this.items.length)) {
      return;
    }
    CTabItem localCTabItem = this.items[paramInt];
    if (this.selectedIndex == paramInt)
    {
      showItem(localCTabItem);
      return;
    }
    int i = this.selectedIndex;
    this.selectedIndex = paramInt;
    if (i != -1)
    {
      this.items[i].closeImageState = 8;
      this.items[i].state &= 0xFFFFFFFD;
    }
    localCTabItem.closeImageState = 0;
    localCTabItem.showing = false;
    localCTabItem.state |= 0x2;
    Control localControl1 = localCTabItem.control;
    Control localControl2 = null;
    if (i != -1) {
      localControl2 = this.items[i].control;
    }
    if (localControl1 != localControl2)
    {
      if ((localControl1 != null) && (!localControl1.isDisposed()))
      {
        localControl1.setBounds(getClientArea());
        localControl1.setVisible(true);
      }
      if ((localControl2 != null) && (!localControl2.isDisposed())) {
        localControl2.setVisible(false);
      }
    }
    showItem(localCTabItem);
    redraw();
  }
  
  void setSelection(int paramInt, boolean paramBoolean)
  {
    int i = this.selectedIndex;
    setSelection(paramInt);
    if ((paramBoolean) && (this.selectedIndex != i) && (this.selectedIndex != -1))
    {
      Event localEvent = new Event();
      localEvent.item = getItem(this.selectedIndex);
      notifyListeners(13, localEvent);
    }
  }
  
  public void setSelectionBackground(Color paramColor)
  {
    if (this.inDispose) {
      return;
    }
    checkWidget();
    setSelectionHighlightGradientColor(null);
    if (this.selectionBackground == paramColor) {
      return;
    }
    if (paramColor == null) {
      paramColor = getDisplay().getSystemColor(25);
    }
    this.selectionBackground = paramColor;
    this.renderer.createAntialiasColors();
    if (this.selectedIndex > -1) {
      redraw();
    }
  }
  
  public void setSelectionBackground(Color[] paramArrayOfColor, int[] paramArrayOfInt)
  {
    setSelectionBackground(paramArrayOfColor, paramArrayOfInt, false);
  }
  
  public void setSelectionBackground(Color[] paramArrayOfColor, int[] paramArrayOfInt, boolean paramBoolean)
  {
    checkWidget();
    Color localColor = null;
    int j;
    int i;
    if (paramArrayOfColor != null)
    {
      if ((paramArrayOfInt == null) || ((paramArrayOfInt.length != paramArrayOfColor.length - 1) && (paramArrayOfInt.length != paramArrayOfColor.length - 2))) {
        SWT.error(5);
      }
      for (j = 0; j < paramArrayOfInt.length; j++)
      {
        if ((paramArrayOfInt[j] < 0) || (paramArrayOfInt[j] > 100)) {
          SWT.error(5);
        }
        if ((j > 0) && (paramArrayOfInt[j] < paramArrayOfInt[(j - 1)])) {
          SWT.error(5);
        }
      }
      if (paramArrayOfInt.length == paramArrayOfColor.length - 2)
      {
        localColor = paramArrayOfColor[(paramArrayOfColor.length - 1)];
        i = paramArrayOfColor.length - 1;
      }
      else
      {
        i = paramArrayOfColor.length;
      }
      if (getDisplay().getDepth() < 15)
      {
        paramArrayOfColor = new Color[] { paramArrayOfColor[(i - 1)] };
        i = paramArrayOfColor.length;
        paramArrayOfInt = new int[0];
      }
    }
    else
    {
      i = 0;
    }
    int k;
    if (this.selectionBgImage == null)
    {
      if ((this.selectionGradientColors != null) && (paramArrayOfColor != null) && (this.selectionGradientColors.length == i))
      {
        j = 0;
        for (int m = 0; m < this.selectionGradientColors.length; m++)
        {
          if (this.selectionGradientColors[m] == null) {
            j = paramArrayOfColor[m] == null ? 1 : 0;
          } else {
            k = this.selectionGradientColors[m].equals(paramArrayOfColor[m]);
          }
          if (k == 0) {
            break;
          }
        }
        if (k != 0) {
          for (m = 0; m < this.selectionGradientPercents.length; m++)
          {
            k = this.selectionGradientPercents[m] == paramArrayOfInt[m] ? 1 : 0;
            if (k == 0) {
              break;
            }
          }
        }
        if ((k != 0) && (this.selectionGradientVertical == paramBoolean)) {
          return;
        }
      }
    }
    else {
      this.selectionBgImage = null;
    }
    if (paramArrayOfColor == null)
    {
      this.selectionGradientColors = null;
      this.selectionGradientPercents = null;
      this.selectionGradientVertical = false;
      setSelectionBackground((Color)null);
      setSelectionHighlightGradientColor(null);
    }
    else
    {
      this.selectionGradientColors = new Color[i];
      for (k = 0; k < i; k++) {
        this.selectionGradientColors[k] = paramArrayOfColor[k];
      }
      this.selectionGradientPercents = new int[paramArrayOfInt.length];
      for (k = 0; k < paramArrayOfInt.length; k++) {
        this.selectionGradientPercents[k] = paramArrayOfInt[k];
      }
      this.selectionGradientVertical = paramBoolean;
      setSelectionBackground(this.selectionGradientColors[(this.selectionGradientColors.length - 1)]);
      setSelectionHighlightGradientColor(localColor);
    }
    if (this.selectedIndex > -1) {
      redraw();
    }
  }
  
  void setSelectionHighlightGradientColor(Color paramColor)
  {
    if (this.inDispose) {
      return;
    }
    this.renderer.setSelectionHighlightGradientColor(paramColor);
  }
  
  public void setSelectionBackground(Image paramImage)
  {
    checkWidget();
    setSelectionHighlightGradientColor(null);
    if (paramImage == this.selectionBgImage) {
      return;
    }
    if (paramImage != null)
    {
      this.selectionGradientColors = null;
      this.selectionGradientPercents = null;
      this.renderer.disposeSelectionHighlightGradientColors();
    }
    this.selectionBgImage = paramImage;
    this.renderer.createAntialiasColors();
    if (this.selectedIndex > -1) {
      redraw();
    }
  }
  
  public void setSelectionForeground(Color paramColor)
  {
    checkWidget();
    if (this.selectionForeground == paramColor) {
      return;
    }
    if (paramColor == null) {
      paramColor = getDisplay().getSystemColor(24);
    }
    this.selectionForeground = paramColor;
    if (this.selectedIndex > -1) {
      redraw();
    }
  }
  
  public void setSimple(boolean paramBoolean)
  {
    checkWidget();
    if (this.simple != paramBoolean)
    {
      this.simple = paramBoolean;
      updateFolder(10);
    }
  }
  
  public void setSingle(boolean paramBoolean)
  {
    checkWidget();
    if (this.single != paramBoolean)
    {
      this.single = paramBoolean;
      if (!paramBoolean) {
        for (int i = 0; i < this.items.length; i++) {
          if ((i != this.selectedIndex) && (this.items[i].closeImageState == 0)) {
            this.items[i].closeImageState = 8;
          }
        }
      }
      updateFolder(2);
    }
  }
  
  int getControlY(Point paramPoint, Rectangle[] paramArrayOfRectangle, int paramInt1, int paramInt2, int paramInt3)
  {
    int i = this.fixedTabHeight != -1 ? 0 : (this.tabHeight - paramArrayOfRectangle[paramInt3].height) / 2;
    return this.onBottom ? paramPoint.y - paramInt1 - this.tabHeight + i : 1 + paramInt2 + i;
  }
  
  public void setTabHeight(int paramInt)
  {
    checkWidget();
    if (paramInt < -1) {
      SWT.error(5);
    }
    this.fixedTabHeight = paramInt;
    updateFolder(8);
  }
  
  public void setTabPosition(int paramInt)
  {
    checkWidget();
    if ((paramInt != 128) && (paramInt != 1024)) {
      SWT.error(5);
    }
    if (this.onBottom != (paramInt == 1024))
    {
      this.onBottom = (paramInt == 1024);
      updateFolder(2);
    }
  }
  
  public void setTopRight(Control paramControl)
  {
    setTopRight(paramControl, 131072);
  }
  
  public void setTopRight(Control paramControl, int paramInt)
  {
    checkWidget();
    if ((paramInt != 131072) && (paramInt != 4) && (paramInt != 131136)) {
      SWT.error(5);
    }
    if ((paramControl != null) && ((paramControl.isDisposed()) || (paramControl.getParent() != this))) {
      SWT.error(5);
    }
    if ((this.topRight == paramControl) && (this.topRightAlignment == paramInt)) {
      return;
    }
    if ((this.topRight != null) && (!this.topRight.isDisposed())) {
      removeTabControl(this.topRight, false);
    }
    this.topRight = paramControl;
    this.topRightAlignment = paramInt;
    paramInt &= 0xFFFDFFFF;
    if (paramControl != null) {
      addTabControl(paramControl, 0x20000 | paramInt, -1, false);
    }
    updateFolder(10);
  }
  
  public void setUnselectedCloseVisible(boolean paramBoolean)
  {
    checkWidget();
    if (this.showUnselectedClose == paramBoolean) {
      return;
    }
    this.showUnselectedClose = paramBoolean;
    updateFolder(2);
  }
  
  public void setUnselectedImageVisible(boolean paramBoolean)
  {
    checkWidget();
    if (this.showUnselectedImage == paramBoolean) {
      return;
    }
    this.showUnselectedImage = paramBoolean;
    updateFolder(2);
  }
  
  public void showItem(CTabItem paramCTabItem)
  {
    checkWidget();
    if (paramCTabItem == null) {
      SWT.error(4);
    }
    if (paramCTabItem.isDisposed()) {
      SWT.error(5);
    }
    int i = indexOf(paramCTabItem);
    if (i == -1) {
      SWT.error(5);
    }
    int j = -1;
    for (int k = 0; k < this.priority.length; k++) {
      if (this.priority[k] == i)
      {
        j = k;
        break;
      }
    }
    if (this.mru)
    {
      int[] arrayOfInt = new int[this.priority.length];
      System.arraycopy(this.priority, 0, arrayOfInt, 1, j);
      System.arraycopy(this.priority, j + 1, arrayOfInt, j + 1, this.priority.length - j - 1);
      arrayOfInt[0] = i;
      this.priority = arrayOfInt;
    }
    if (paramCTabItem.showing) {
      return;
    }
    updateFolder(4);
  }
  
  void showList(Rectangle paramRectangle)
  {
    if ((this.items.length == 0) || (!this.showChevron)) {
      return;
    }
    if ((this.showMenu == null) || (this.showMenu.isDisposed()))
    {
      this.showMenu = new Menu(getShell(), getStyle() & 0x6000000);
    }
    else
    {
      MenuItem[] arrayOfMenuItem = this.showMenu.getItems();
      for (i = 0; i < arrayOfMenuItem.length; i++) {
        arrayOfMenuItem[i].dispose();
      }
    }
    for (int i = 0; i < this.items.length; i++)
    {
      CTabItem localCTabItem = this.items[i];
      if (!localCTabItem.showing)
      {
        localObject = new MenuItem(this.showMenu, 0);
        ((MenuItem)localObject).setText(localCTabItem.getText());
        ((MenuItem)localObject).setImage(localCTabItem.getImage());
        ((MenuItem)localObject).setData("CTabFolder_showList_Index", localCTabItem);
        ((MenuItem)localObject).addSelectionListener(new SelectionAdapter()
        {
          public void widgetSelected(SelectionEvent paramAnonymousSelectionEvent)
          {
            MenuItem localMenuItem = (MenuItem)paramAnonymousSelectionEvent.widget;
            int i = CTabFolder.this.indexOf((CTabItem)localMenuItem.getData("CTabFolder_showList_Index"));
            CTabFolder.this.setSelection(i, true);
          }
        });
      }
    }
    i = paramRectangle.x;
    int j = paramRectangle.y + paramRectangle.height;
    Object localObject = getDisplay().map(this, null, i, j);
    this.showMenu.setLocation(((Point)localObject).x, ((Point)localObject).y);
    this.showMenu.setVisible(true);
  }
  
  public void showSelection()
  {
    checkWidget();
    if (this.selectedIndex != -1) {
      showItem(getSelection());
    }
  }
  
  void _setToolTipText(int paramInt1, int paramInt2)
  {
    String str1 = getToolTipText();
    String str2 = _getToolTip(paramInt1, paramInt2);
    if ((str2 == null) || (!str2.equals(str1))) {
      setToolTipText(str2);
    }
  }
  
  boolean updateItems()
  {
    return updateItems(this.selectedIndex);
  }
  
  boolean updateItems(int paramInt)
  {
    GC localGC = new GC(this);
    if ((!this.single) && (!this.mru) && (paramInt != -1))
    {
      int i = paramInt;
      int j;
      int k;
      if (this.priority[0] < paramInt)
      {
        j = getRightItemEdge(localGC) - getLeftItemEdge(localGC, -3);
        k = 0;
        int[] arrayOfInt = new int[this.items.length];
        int n;
        for (int m = this.priority[0]; m <= paramInt; m++)
        {
          n = 16777216;
          if (m == this.selectedIndex) {
            n |= 0x2;
          }
          arrayOfInt[m] = this.renderer.computeSize(m, n, localGC, -1, -1).x;
          k += arrayOfInt[m];
          if (k > j) {
            break;
          }
        }
        if (k > j)
        {
          k = 0;
          for (m = paramInt; m >= 0; m--)
          {
            n = 16777216;
            if (m == this.selectedIndex) {
              n |= 0x2;
            }
            if (arrayOfInt[m] == 0) {
              arrayOfInt[m] = this.renderer.computeSize(m, n, localGC, -1, -1).x;
            }
            k += arrayOfInt[m];
            if (k > j) {
              break;
            }
            i = m;
          }
        }
        else
        {
          i = this.priority[0];
          for (m = paramInt + 1; m < this.items.length; m++)
          {
            n = 16777216;
            if (m == this.selectedIndex) {
              n |= 0x2;
            }
            arrayOfInt[m] = this.renderer.computeSize(m, n, localGC, -1, -1).x;
            k += arrayOfInt[m];
            if (k >= j) {
              break;
            }
          }
          if (k < j) {
            for (m = this.priority[0] - 1; m >= 0; m--)
            {
              n = 16777216;
              if (m == this.selectedIndex) {
                n |= 0x2;
              }
              if (arrayOfInt[m] == 0) {
                arrayOfInt[m] = this.renderer.computeSize(m, n, localGC, -1, -1).x;
              }
              k += arrayOfInt[m];
              if (k > j) {
                break;
              }
              i = m;
            }
          }
        }
      }
      if (i != this.priority[0])
      {
        j = 0;
        for (k = i; k < this.items.length; k++) {
          this.priority[(j++)] = k;
        }
        for (k = 0; k < i; k++) {
          this.priority[(j++)] = k;
        }
      }
    }
    boolean bool1 = this.showChevron;
    boolean bool2 = setItemSize(localGC);
    bool2 |= setItemLocation(localGC);
    setButtonBounds(localGC);
    bool2 |= this.showChevron != bool1;
    if ((bool2) && (getToolTipText() != null))
    {
      Point localPoint = getDisplay().getCursorLocation();
      localPoint = toControl(localPoint);
      _setToolTipText(localPoint.x, localPoint.y);
    }
    localGC.dispose();
    return bool2;
  }
  
  boolean updateTabHeight(boolean paramBoolean)
  {
    int i = this.tabHeight;
    GC localGC = new GC(this);
    this.tabHeight = this.renderer.computeSize(-2, 0, localGC, -1, -1).y;
    localGC.dispose();
    if ((this.fixedTabHeight == -1) && (this.controls != null) && (this.controls.length > 0)) {
      for (int j = 0; j < this.controls.length; j++) {
        if (((this.controlAlignments[j] & 0x40) == 0) && (!this.controls[j].isDisposed()) && ((this.controls[j].getVisible()) || (this.controls[j] == this.chevronTb)))
        {
          int k = this.controls[j].computeSize(-1, -1).y;
          k += this.renderer.computeTrim(-2, 0, 0, 0, 0, 0).height + 1;
          this.tabHeight = Math.max(k, this.tabHeight);
        }
      }
    }
    if ((!paramBoolean) && (this.tabHeight == i)) {
      return false;
    }
    this.oldSize = null;
    return true;
  }
  
  void updateFolder(int paramInt)
  {
    this.updateFlags |= paramInt;
    if (this.updateRun != null) {
      return;
    }
    this.updateRun = new Runnable()
    {
      public void run()
      {
        CTabFolder.this.updateRun = null;
        if (CTabFolder.this.isDisposed()) {
          return;
        }
        CTabFolder.this.runUpdate();
      }
    };
    getDisplay().asyncExec(this.updateRun);
  }
  
  void runUpdate()
  {
    if (this.updateFlags == 0) {
      return;
    }
    int i = this.updateFlags;
    this.updateFlags = 0;
    Rectangle localRectangle1 = getClientArea();
    boolean bool = updateTabHeight(false);
    bool |= updateItems(this.selectedIndex);
    if ((bool) && (getParent() != null)) {
      getParent().layout(true, true);
    }
    if ((i & 0x2) != 0) {
      redraw();
    } else if ((i & 0x4) != 0) {
      redrawTabs();
    }
    Rectangle localRectangle2 = getClientArea();
    if (!localRectangle1.equals(localRectangle2))
    {
      notifyListeners(11, new Event());
      layout();
    }
  }
  
  void updateBkImages()
  {
    if ((this.controls != null) && (this.controls.length > 0)) {
      for (int i = 0; i < this.controls.length; i++)
      {
        Control localControl = this.controls[i];
        if (!localControl.isDisposed()) {
          if (this.hovering)
          {
            if ((localControl instanceof Composite)) {
              ((Composite)localControl).setBackgroundMode(0);
            }
            localControl.setBackgroundImage(null);
            localControl.setBackground(getBackground());
          }
          else
          {
            if ((localControl instanceof Composite)) {
              ((Composite)localControl).setBackgroundMode(1);
            }
            Rectangle localRectangle = localControl.getBounds();
            int j = getTabHeight();
            int k = getSize().y;
            int m = localRectangle.y > j ? 1 : this.onBottom ? 0 : localRectangle.y + localRectangle.height < k - j ? 1 : 0;
            if ((m != 0) || (this.gradientColors == null))
            {
              localControl.setBackgroundImage(null);
              localControl.setBackground(getBackground());
            }
            else
            {
              localRectangle.width = 10;
              if (!this.onBottom)
              {
                localRectangle.y = (-localRectangle.y);
                localRectangle.height -= 2 * localRectangle.y - 1;
              }
              else
              {
                localRectangle.height += k - (localRectangle.y + localRectangle.height);
                localRectangle.y = -1;
              }
              localRectangle.x = 0;
              if (this.controlBkImages[i] != null) {
                this.controlBkImages[i].dispose();
              }
              this.controlBkImages[i] = new Image(localControl.getDisplay(), localRectangle);
              GC localGC = new GC(this.controlBkImages[i]);
              this.renderer.drawBackground(localGC, localRectangle, 0);
              localGC.dispose();
              localControl.setBackground(null);
              localControl.setBackgroundImage(this.controlBkImages[i]);
            }
          }
        }
      }
    }
  }
  
  String _getToolTip(int paramInt1, int paramInt2)
  {
    CTabItem localCTabItem = getItem(new Point(paramInt1, paramInt2));
    if (localCTabItem == null) {
      return null;
    }
    if (!localCTabItem.showing) {
      return null;
    }
    if (((this.showClose) || (localCTabItem.showClose)) && (localCTabItem.closeRect.contains(paramInt1, paramInt2))) {
      return SWT.getMessage("SWT_Close");
    }
    return localCTabItem.getToolTipText();
  }
  
  void addTabControl(Control paramControl, int paramInt)
  {
    checkWidget();
    addTabControl(paramControl, paramInt, -1, true);
  }
  
  void addTabControl(Control paramControl, int paramInt1, int paramInt2, boolean paramBoolean)
  {
    switch (paramInt1)
    {
    case 16384: 
    case 131072: 
    case 131076: 
    case 131136: 
    case 131140: 
      break;
    default: 
      SWT.error(5);
    }
    if ((paramControl != null) && (paramControl.getParent() != this)) {
      SWT.error(5);
    }
    for (int i = 0; i < this.controls.length; i++) {
      if (this.controls[i] == paramControl) {
        SWT.error(5);
      }
    }
    i = this.controls.length;
    paramControl.addListener(11, this.listener);
    Control[] arrayOfControl = new Control[i + 1];
    System.arraycopy(this.controls, 0, arrayOfControl, 0, i);
    this.controls = arrayOfControl;
    int[] arrayOfInt = new int[i + 1];
    System.arraycopy(this.controlAlignments, 0, arrayOfInt, 0, i);
    this.controlAlignments = arrayOfInt;
    Rectangle[] arrayOfRectangle = new Rectangle[i + 1];
    System.arraycopy(this.controlRects, 0, arrayOfRectangle, 0, i);
    this.controlRects = arrayOfRectangle;
    Image[] arrayOfImage = new Image[i + 1];
    System.arraycopy(this.controlBkImages, 0, arrayOfImage, 0, i);
    this.controlBkImages = arrayOfImage;
    if (paramInt2 == -1)
    {
      paramInt2 = i;
      if ((this.chevronTb != null) && (paramControl != this.chevronTb)) {
        paramInt2--;
      }
    }
    System.arraycopy(this.controls, paramInt2, this.controls, paramInt2 + 1, i - paramInt2);
    System.arraycopy(this.controlAlignments, paramInt2, this.controlAlignments, paramInt2 + 1, i - paramInt2);
    System.arraycopy(this.controlRects, paramInt2, this.controlRects, paramInt2 + 1, i - paramInt2);
    System.arraycopy(this.controlBkImages, paramInt2, this.controlBkImages, paramInt2 + 1, i - paramInt2);
    this.controls[paramInt2] = paramControl;
    this.controlAlignments[paramInt2] = paramInt1;
    this.controlRects[paramInt2] = new Rectangle(0, 0, 0, 0);
    if (paramBoolean) {
      updateFolder(10);
    }
  }
  
  void removeTabControl(Control paramControl)
  {
    checkWidget();
    removeTabControl(paramControl, true);
  }
  
  void removeTabControl(Control paramControl, boolean paramBoolean)
  {
    if ((paramControl != null) && (paramControl.getParent() != this)) {
      SWT.error(5);
    }
    int i = -1;
    for (int j = 0; j < this.controls.length; j++) {
      if (this.controls[j] == paramControl)
      {
        i = j;
        break;
      }
    }
    if (i == -1) {
      return;
    }
    if (!paramControl.isDisposed())
    {
      paramControl.removeListener(11, this.listener);
      paramControl.setBackground(null);
      paramControl.setBackgroundImage(null);
      if ((paramControl instanceof Composite)) {
        ((Composite)paramControl).setBackgroundMode(0);
      }
    }
    if ((this.controlBkImages[i] != null) && (!this.controlBkImages[i].isDisposed())) {
      this.controlBkImages[i].dispose();
    }
    if (this.controls.length == 1)
    {
      this.controls = new Control[0];
      this.controlAlignments = new int[0];
      this.controlRects = new Rectangle[0];
      this.controlBkImages = new Image[0];
    }
    else
    {
      Control[] arrayOfControl = new Control[this.controls.length - 1];
      System.arraycopy(this.controls, 0, arrayOfControl, 0, i);
      System.arraycopy(this.controls, i + 1, arrayOfControl, i, this.controls.length - i - 1);
      this.controls = arrayOfControl;
      int[] arrayOfInt = new int[this.controls.length];
      System.arraycopy(this.controlAlignments, 0, arrayOfInt, 0, i);
      System.arraycopy(this.controlAlignments, i + 1, arrayOfInt, i, this.controls.length - i);
      this.controlAlignments = arrayOfInt;
      Rectangle[] arrayOfRectangle = new Rectangle[this.controls.length];
      System.arraycopy(this.controlRects, 0, arrayOfRectangle, 0, i);
      System.arraycopy(this.controlRects, i + 1, arrayOfRectangle, i, this.controls.length - i);
      this.controlRects = arrayOfRectangle;
      Image[] arrayOfImage = new Image[this.controls.length];
      System.arraycopy(this.controlBkImages, 0, arrayOfImage, 0, i);
      System.arraycopy(this.controlBkImages, i + 1, arrayOfImage, i, this.controls.length - i);
      this.controlBkImages = arrayOfImage;
    }
    if (paramBoolean) {
      updateFolder(10);
    }
  }
  
  int getWrappedHeight(Point paramPoint)
  {
    boolean[][] arrayOfBoolean = new boolean[1][];
    Rectangle[] arrayOfRectangle = computeControlBounds(paramPoint, arrayOfBoolean);
    int i = Integer.MAX_VALUE;
    int j = 0;
    int k = 0;
    for (int m = 0; m < arrayOfRectangle.length; m++) {
      if (arrayOfBoolean[0][m] != 0)
      {
        i = Math.min(i, arrayOfRectangle[m].y);
        j = Math.max(j, arrayOfRectangle[m].y + arrayOfRectangle[m].height);
        k = j - i;
      }
    }
    return k;
  }
  
  void setChevronVisible(boolean paramBoolean)
  {
    checkWidget();
    if (this.chevronVisible == paramBoolean) {
      return;
    }
    this.chevronVisible = paramBoolean;
    updateFolder(10);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_32.jar!/org/eclipse/swt/custom/CTabFolder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */