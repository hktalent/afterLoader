package org.eclipse.swt.internal.mozilla;

public class nsIObserverService
  extends nsISupports
{
  static final int LAST_METHOD_ID = nsISupports.LAST_METHOD_ID + 4;
  static final String NS_IOBSERVERSERVICE_IID_STR = "d07f5192-e3d1-11d2-8acd-00105a1b8860";
  
  public nsIObserverService(int paramInt)
  {
    super(paramInt);
  }
  
  public int NotifyObservers(int paramInt, byte[] paramArrayOfByte, char[] paramArrayOfChar)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 3, getAddress(), paramInt, paramArrayOfByte, paramArrayOfChar);
  }
  
  static
  {
    IIDStore.RegisterIID(nsIObserverService.class, 0, new nsID("d07f5192-e3d1-11d2-8acd-00105a1b8860"));
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_32.jar!/org/eclipse/swt/internal/mozilla/nsIObserverService.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */