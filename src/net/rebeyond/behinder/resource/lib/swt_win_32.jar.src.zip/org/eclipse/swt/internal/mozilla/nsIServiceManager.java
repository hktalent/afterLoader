package org.eclipse.swt.internal.mozilla;

public class nsIServiceManager
  extends nsISupports
{
  static final int LAST_METHOD_ID = nsISupports.LAST_METHOD_ID + 4;
  static final String NS_ISERVICEMANAGER_IID_STR = "8bb35ed9-e332-462d-9155-4a002ab5c958";
  
  public nsIServiceManager(int paramInt)
  {
    super(paramInt);
  }
  
  public int GetService(nsID paramnsID1, nsID paramnsID2, int[] paramArrayOfInt)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 1, getAddress(), paramnsID1, paramnsID2, paramArrayOfInt);
  }
  
  public int GetServiceByContractID(byte[] paramArrayOfByte, nsID paramnsID, int[] paramArrayOfInt)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 2, getAddress(), paramArrayOfByte, paramnsID, paramArrayOfInt);
  }
  
  static
  {
    IIDStore.RegisterIID(nsIServiceManager.class, 0, new nsID("8bb35ed9-e332-462d-9155-4a002ab5c958"));
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_32.jar!/org/eclipse/swt/internal/mozilla/nsIServiceManager.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */