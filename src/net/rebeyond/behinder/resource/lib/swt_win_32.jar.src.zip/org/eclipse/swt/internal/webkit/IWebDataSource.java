package org.eclipse.swt.internal.webkit;

import org.eclipse.swt.internal.ole.win32.COM;
import org.eclipse.swt.internal.ole.win32.IUnknown;

public class IWebDataSource
  extends IUnknown
{
  public IWebDataSource(int paramInt)
  {
    super(paramInt);
  }
  
  public int representation(int[] paramArrayOfInt)
  {
    return COM.VtblCall(5, getAddress(), paramArrayOfInt);
  }
  
  public int webFrame(int[] paramArrayOfInt)
  {
    return COM.VtblCall(6, getAddress(), paramArrayOfInt);
  }
  
  public int request(int[] paramArrayOfInt)
  {
    return COM.VtblCall(8, getAddress(), paramArrayOfInt);
  }
  
  public int pageTitle(int[] paramArrayOfInt)
  {
    return COM.VtblCall(12, getAddress(), paramArrayOfInt);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_32.jar!/org/eclipse/swt/internal/webkit/IWebDataSource.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */