package org.eclipse.swt.custom;

import org.eclipse.swt.events.TypedEvent;

public class TextChangingEvent
  extends TypedEvent
{
  public int start;
  public String newText;
  public int replaceCharCount;
  public int newCharCount;
  public int replaceLineCount;
  public int newLineCount;
  static final long serialVersionUID = 3257290210114352439L;
  
  public TextChangingEvent(StyledTextContent paramStyledTextContent)
  {
    super(paramStyledTextContent);
  }
  
  TextChangingEvent(StyledTextContent paramStyledTextContent, StyledTextEvent paramStyledTextEvent)
  {
    super(paramStyledTextContent);
    this.start = paramStyledTextEvent.start;
    this.replaceCharCount = paramStyledTextEvent.replaceCharCount;
    this.newCharCount = paramStyledTextEvent.newCharCount;
    this.replaceLineCount = paramStyledTextEvent.replaceLineCount;
    this.newLineCount = paramStyledTextEvent.newLineCount;
    this.newText = paramStyledTextEvent.text;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_32.jar!/org/eclipse/swt/custom/TextChangingEvent.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */