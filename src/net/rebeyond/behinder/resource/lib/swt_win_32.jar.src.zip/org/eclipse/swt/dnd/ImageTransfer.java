package org.eclipse.swt.dnd;

import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.ImageData;
import org.eclipse.swt.graphics.PaletteData;
import org.eclipse.swt.graphics.RGB;
import org.eclipse.swt.internal.ole.win32.STGMEDIUM;
import org.eclipse.swt.internal.win32.BITMAPINFOHEADER;
import org.eclipse.swt.internal.win32.OS;

public class ImageTransfer
  extends ByteArrayTransfer
{
  private static ImageTransfer _instance = new ImageTransfer();
  private static final String CF_DIB = "CF_DIB";
  private static final int CF_DIBID = 8;
  
  public static ImageTransfer getInstance()
  {
    return _instance;
  }
  
  public void javaToNative(Object paramObject, TransferData paramTransferData)
  {
    if ((!checkImage(paramObject)) || (!isSupportedType(paramTransferData))) {
      DND.error(2003);
    }
    ImageData localImageData = (ImageData)paramObject;
    if (localImageData == null) {
      SWT.error(4);
    }
    int i = localImageData.data.length;
    int j = localImageData.height;
    int k = localImageData.bytesPerLine;
    BITMAPINFOHEADER localBITMAPINFOHEADER = new BITMAPINFOHEADER();
    localBITMAPINFOHEADER.biSize = BITMAPINFOHEADER.sizeof;
    localBITMAPINFOHEADER.biSizeImage = i;
    localBITMAPINFOHEADER.biWidth = localImageData.width;
    localBITMAPINFOHEADER.biHeight = j;
    localBITMAPINFOHEADER.biPlanes = 1;
    localBITMAPINFOHEADER.biBitCount = ((short)localImageData.depth);
    localBITMAPINFOHEADER.biCompression = 0;
    int m = 0;
    if (localBITMAPINFOHEADER.biBitCount <= 8) {
      m += (1 << localBITMAPINFOHEADER.biBitCount) * 4;
    }
    byte[] arrayOfByte1 = new byte[BITMAPINFOHEADER.sizeof + m];
    OS.MoveMemory(arrayOfByte1, localBITMAPINFOHEADER, BITMAPINFOHEADER.sizeof);
    RGB[] arrayOfRGB = localImageData.palette.getRGBs();
    if ((arrayOfRGB != null) && (m > 0))
    {
      n = BITMAPINFOHEADER.sizeof;
      for (i1 = 0; i1 < arrayOfRGB.length; i1++)
      {
        arrayOfByte1[n] = ((byte)arrayOfRGB[i1].blue);
        arrayOfByte1[(n + 1)] = ((byte)arrayOfRGB[i1].green);
        arrayOfByte1[(n + 2)] = ((byte)arrayOfRGB[i1].red);
        arrayOfByte1[(n + 3)] = 0;
        n += 4;
      }
    }
    int n = OS.GlobalAlloc(64, BITMAPINFOHEADER.sizeof + m + i);
    OS.MoveMemory(n, arrayOfByte1, arrayOfByte1.length);
    int i1 = n + BITMAPINFOHEADER.sizeof + m;
    if (j <= 0)
    {
      OS.MoveMemory(i1, localImageData.data, i);
    }
    else
    {
      int i2 = 0;
      i1 += k * (j - 1);
      byte[] arrayOfByte2 = new byte[k];
      for (int i3 = 0; i3 < j; i3++)
      {
        System.arraycopy(localImageData.data, i2, arrayOfByte2, 0, k);
        OS.MoveMemory(i1, arrayOfByte2, k);
        i2 += k;
        i1 -= k;
      }
    }
    paramTransferData.stgmedium = new STGMEDIUM();
    paramTransferData.stgmedium.tymed = 1;
    paramTransferData.stgmedium.unionField = n;
    paramTransferData.stgmedium.pUnkForRelease = 0;
    paramTransferData.result = 0;
  }
  
  /* Error */
  public Object nativeToJava(TransferData paramTransferData)
  {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: invokevirtual 4	org/eclipse/swt/dnd/ImageTransfer:isSupportedType	(Lorg/eclipse/swt/dnd/TransferData;)Z
    //   5: ifeq +10 -> 15
    //   8: aload_1
    //   9: getfield 39	org/eclipse/swt/dnd/TransferData:pIDataObject	I
    //   12: ifne +5 -> 17
    //   15: aconst_null
    //   16: areturn
    //   17: new 40	org/eclipse/swt/internal/ole/win32/IDataObject
    //   20: dup
    //   21: aload_1
    //   22: getfield 39	org/eclipse/swt/dnd/TransferData:pIDataObject	I
    //   25: invokespecial 41	org/eclipse/swt/internal/ole/win32/IDataObject:<init>	(I)V
    //   28: astore_2
    //   29: aload_2
    //   30: invokevirtual 42	org/eclipse/swt/internal/ole/win32/IDataObject:AddRef	()I
    //   33: pop
    //   34: new 43	org/eclipse/swt/internal/ole/win32/FORMATETC
    //   37: dup
    //   38: invokespecial 44	org/eclipse/swt/internal/ole/win32/FORMATETC:<init>	()V
    //   41: astore_3
    //   42: aload_3
    //   43: bipush 8
    //   45: putfield 45	org/eclipse/swt/internal/ole/win32/FORMATETC:cfFormat	I
    //   48: aload_3
    //   49: iconst_0
    //   50: putfield 46	org/eclipse/swt/internal/ole/win32/FORMATETC:ptd	I
    //   53: aload_3
    //   54: iconst_1
    //   55: putfield 47	org/eclipse/swt/internal/ole/win32/FORMATETC:dwAspect	I
    //   58: aload_3
    //   59: iconst_m1
    //   60: putfield 48	org/eclipse/swt/internal/ole/win32/FORMATETC:lindex	I
    //   63: aload_3
    //   64: iconst_1
    //   65: putfield 49	org/eclipse/swt/internal/ole/win32/FORMATETC:tymed	I
    //   68: new 32	org/eclipse/swt/internal/ole/win32/STGMEDIUM
    //   71: dup
    //   72: invokespecial 33	org/eclipse/swt/internal/ole/win32/STGMEDIUM:<init>	()V
    //   75: astore 4
    //   77: aload 4
    //   79: iconst_1
    //   80: putfield 35	org/eclipse/swt/internal/ole/win32/STGMEDIUM:tymed	I
    //   83: aload_1
    //   84: aload_0
    //   85: aload_2
    //   86: aload_3
    //   87: aload 4
    //   89: invokevirtual 50	org/eclipse/swt/dnd/ImageTransfer:getData	(Lorg/eclipse/swt/internal/ole/win32/IDataObject;Lorg/eclipse/swt/internal/ole/win32/FORMATETC;Lorg/eclipse/swt/internal/ole/win32/STGMEDIUM;)I
    //   92: putfield 38	org/eclipse/swt/dnd/TransferData:result	I
    //   95: aload_1
    //   96: getfield 38	org/eclipse/swt/dnd/TransferData:result	I
    //   99: ifeq +5 -> 104
    //   102: aconst_null
    //   103: areturn
    //   104: aload 4
    //   106: getfield 36	org/eclipse/swt/internal/ole/win32/STGMEDIUM:unionField	I
    //   109: istore 5
    //   111: aload_2
    //   112: invokevirtual 51	org/eclipse/swt/internal/ole/win32/IDataObject:Release	()I
    //   115: pop
    //   116: iload 5
    //   118: invokestatic 52	org/eclipse/swt/internal/win32/OS:GlobalLock	(I)I
    //   121: istore 6
    //   123: iload 6
    //   125: ifne +12 -> 137
    //   128: aconst_null
    //   129: astore 7
    //   131: jsr +302 -> 433
    //   134: aload 7
    //   136: areturn
    //   137: new 11	org/eclipse/swt/internal/win32/BITMAPINFOHEADER
    //   140: dup
    //   141: invokespecial 12	org/eclipse/swt/internal/win32/BITMAPINFOHEADER:<init>	()V
    //   144: astore 7
    //   146: aload 7
    //   148: iload 6
    //   150: getstatic 13	org/eclipse/swt/internal/win32/BITMAPINFOHEADER:sizeof	I
    //   153: invokestatic 53	org/eclipse/swt/internal/win32/OS:MoveMemory	(Lorg/eclipse/swt/internal/win32/BITMAPINFOHEADER;II)V
    //   156: iconst_1
    //   157: newarray <illegal type>
    //   159: astore 8
    //   161: iconst_0
    //   162: iload 6
    //   164: iconst_0
    //   165: aload 8
    //   167: iconst_0
    //   168: iconst_0
    //   169: invokestatic 54	org/eclipse/swt/internal/win32/OS:CreateDIBSection	(III[III)I
    //   172: istore 9
    //   174: iload 9
    //   176: ifne +7 -> 183
    //   179: iconst_2
    //   180: invokestatic 7	org/eclipse/swt/SWT:error	(I)V
    //   183: iload 6
    //   185: aload 7
    //   187: getfield 14	org/eclipse/swt/internal/win32/BITMAPINFOHEADER:biSize	I
    //   190: iadd
    //   191: istore 10
    //   193: aload 7
    //   195: getfield 21	org/eclipse/swt/internal/win32/BITMAPINFOHEADER:biBitCount	S
    //   198: bipush 8
    //   200: if_icmpgt +36 -> 236
    //   203: iload 10
    //   205: aload 7
    //   207: getfield 55	org/eclipse/swt/internal/win32/BITMAPINFOHEADER:biClrUsed	I
    //   210: ifne +13 -> 223
    //   213: iconst_1
    //   214: aload 7
    //   216: getfield 21	org/eclipse/swt/internal/win32/BITMAPINFOHEADER:biBitCount	S
    //   219: ishl
    //   220: goto +8 -> 228
    //   223: aload 7
    //   225: getfield 55	org/eclipse/swt/internal/win32/BITMAPINFOHEADER:biClrUsed	I
    //   228: iconst_4
    //   229: imul
    //   230: iadd
    //   231: istore 10
    //   233: goto +15 -> 248
    //   236: aload 7
    //   238: getfield 22	org/eclipse/swt/internal/win32/BITMAPINFOHEADER:biCompression	I
    //   241: iconst_3
    //   242: if_icmpne +6 -> 248
    //   245: iinc 10 12
    //   248: aload 7
    //   250: getfield 18	org/eclipse/swt/internal/win32/BITMAPINFOHEADER:biHeight	I
    //   253: ifge +20 -> 273
    //   256: aload 8
    //   258: iconst_0
    //   259: iaload
    //   260: iload 10
    //   262: aload 7
    //   264: getfield 15	org/eclipse/swt/internal/win32/BITMAPINFOHEADER:biSizeImage	I
    //   267: invokestatic 56	org/eclipse/swt/internal/win32/OS:MoveMemory	(III)V
    //   270: goto +97 -> 367
    //   273: new 57	org/eclipse/swt/internal/win32/DIBSECTION
    //   276: dup
    //   277: invokespecial 58	org/eclipse/swt/internal/win32/DIBSECTION:<init>	()V
    //   280: astore 11
    //   282: iload 9
    //   284: getstatic 59	org/eclipse/swt/internal/win32/DIBSECTION:sizeof	I
    //   287: aload 11
    //   289: invokestatic 60	org/eclipse/swt/internal/win32/OS:GetObject	(IILorg/eclipse/swt/internal/win32/DIBSECTION;)I
    //   292: pop
    //   293: aload 11
    //   295: getfield 61	org/eclipse/swt/internal/win32/DIBSECTION:biHeight	I
    //   298: istore 12
    //   300: aload 11
    //   302: getfield 62	org/eclipse/swt/internal/win32/DIBSECTION:biSizeImage	I
    //   305: iload 12
    //   307: idiv
    //   308: istore 13
    //   310: aload 8
    //   312: iconst_0
    //   313: iaload
    //   314: istore 14
    //   316: iload 10
    //   318: iload 13
    //   320: iload 12
    //   322: iconst_1
    //   323: isub
    //   324: imul
    //   325: iadd
    //   326: istore 15
    //   328: iconst_0
    //   329: istore 16
    //   331: iload 16
    //   333: iload 12
    //   335: if_icmpge +32 -> 367
    //   338: iload 14
    //   340: iload 15
    //   342: iload 13
    //   344: invokestatic 56	org/eclipse/swt/internal/win32/OS:MoveMemory	(III)V
    //   347: iload 14
    //   349: iload 13
    //   351: iadd
    //   352: istore 14
    //   354: iload 15
    //   356: iload 13
    //   358: isub
    //   359: istore 15
    //   361: iinc 16 1
    //   364: goto -33 -> 331
    //   367: aconst_null
    //   368: iconst_0
    //   369: iload 9
    //   371: invokestatic 63	org/eclipse/swt/graphics/Image:win32_new	(Lorg/eclipse/swt/graphics/Device;II)Lorg/eclipse/swt/graphics/Image;
    //   374: astore 11
    //   376: aload 11
    //   378: invokevirtual 64	org/eclipse/swt/graphics/Image:getImageData	()Lorg/eclipse/swt/graphics/ImageData;
    //   381: astore 12
    //   383: iload 9
    //   385: invokestatic 65	org/eclipse/swt/internal/win32/OS:DeleteObject	(I)Z
    //   388: pop
    //   389: aload 11
    //   391: invokevirtual 66	org/eclipse/swt/graphics/Image:dispose	()V
    //   394: aload 12
    //   396: astore 13
    //   398: jsr +17 -> 415
    //   401: jsr +32 -> 433
    //   404: aload 13
    //   406: areturn
    //   407: astore 17
    //   409: jsr +6 -> 415
    //   412: aload 17
    //   414: athrow
    //   415: astore 18
    //   417: iload 5
    //   419: invokestatic 67	org/eclipse/swt/internal/win32/OS:GlobalUnlock	(I)Z
    //   422: pop
    //   423: ret 18
    //   425: astore 19
    //   427: jsr +6 -> 433
    //   430: aload 19
    //   432: athrow
    //   433: astore 20
    //   435: iload 5
    //   437: invokestatic 68	org/eclipse/swt/internal/win32/OS:GlobalFree	(I)I
    //   440: pop
    //   441: ret 20
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	443	0	this	ImageTransfer
    //   0	443	1	paramTransferData	TransferData
    //   28	84	2	localIDataObject	org.eclipse.swt.internal.ole.win32.IDataObject
    //   41	46	3	localFORMATETC	org.eclipse.swt.internal.ole.win32.FORMATETC
    //   75	30	4	localSTGMEDIUM	STGMEDIUM
    //   109	327	5	i	int
    //   121	70	6	j	int
    //   129	134	7	localObject1	Object
    //   159	152	8	arrayOfInt	int[]
    //   172	212	9	k	int
    //   191	135	10	m	int
    //   280	110	11	localObject2	Object
    //   298	38	12	n	int
    //   381	14	12	localImageData1	ImageData
    //   308	51	13	i1	int
    //   396	9	13	localImageData2	ImageData
    //   314	39	14	i2	int
    //   326	34	15	i3	int
    //   329	33	16	i4	int
    //   407	6	17	localObject3	Object
    //   415	1	18	localObject4	Object
    //   425	6	19	localObject5	Object
    //   433	1	20	localObject6	Object
    // Exception table:
    //   from	to	target	type
    //   137	401	407	finally
    //   407	412	407	finally
    //   116	134	425	finally
    //   137	404	425	finally
    //   407	430	425	finally
  }
  
  protected int[] getTypeIds()
  {
    return new int[] { 8 };
  }
  
  protected String[] getTypeNames()
  {
    return new String[] { "CF_DIB" };
  }
  
  boolean checkImage(Object paramObject)
  {
    return (paramObject != null) && ((paramObject instanceof ImageData));
  }
  
  protected boolean validate(Object paramObject)
  {
    return checkImage(paramObject);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_32.jar!/org/eclipse/swt/dnd/ImageTransfer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */