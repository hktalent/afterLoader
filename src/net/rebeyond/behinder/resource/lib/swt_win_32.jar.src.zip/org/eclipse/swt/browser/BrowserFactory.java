package org.eclipse.swt.browser;

import org.eclipse.swt.SWTError;
import org.eclipse.swt.internal.win32.OS;

class BrowserFactory
{
  WebBrowser createWebBrowser(int paramInt)
  {
    if ((OS.IsWinCE) && ((paramInt & 0x18000) != 0)) {
      throw new SWTError(2, "Unsupported Browser type");
    }
    if ((paramInt & 0x8000) != 0) {
      return new Mozilla();
    }
    if ((paramInt & 0x10000) != 0) {
      return new WebKit();
    }
    return new IE();
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_32.jar!/org/eclipse/swt/browser/BrowserFactory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */