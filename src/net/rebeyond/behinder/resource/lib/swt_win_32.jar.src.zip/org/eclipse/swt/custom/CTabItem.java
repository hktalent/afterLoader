package org.eclipse.swt.custom;

import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Item;

public class CTabItem
  extends Item
{
  CTabFolder parent;
  int x;
  int y;
  int width;
  int height = 0;
  Control control;
  String toolTipText;
  String shortenedText;
  int shortenedTextWidth;
  Font font;
  Image disabledImage;
  Rectangle closeRect = new Rectangle(0, 0, 0, 0);
  int closeImageState = 8;
  int state = 0;
  boolean showClose = false;
  boolean showing = false;
  
  public CTabItem(CTabFolder paramCTabFolder, int paramInt)
  {
    this(paramCTabFolder, paramInt, paramCTabFolder.getItemCount());
  }
  
  public CTabItem(CTabFolder paramCTabFolder, int paramInt1, int paramInt2)
  {
    super(paramCTabFolder, paramInt1);
    this.showClose = ((paramInt1 & 0x40) != 0);
    paramCTabFolder.createItem(this, paramInt2);
  }
  
  public void dispose()
  {
    if (isDisposed()) {
      return;
    }
    this.parent.destroyItem(this);
    super.dispose();
    this.parent = null;
    this.control = null;
    this.toolTipText = null;
    this.shortenedText = null;
    this.font = null;
  }
  
  public Rectangle getBounds()
  {
    this.parent.runUpdate();
    return new Rectangle(this.x, this.y, this.width, this.height);
  }
  
  public Control getControl()
  {
    checkWidget();
    return this.control;
  }
  
  @Deprecated
  public Image getDisabledImage()
  {
    checkWidget();
    return this.disabledImage;
  }
  
  public Font getFont()
  {
    checkWidget();
    if (this.font != null) {
      return this.font;
    }
    return this.parent.getFont();
  }
  
  public CTabFolder getParent()
  {
    return this.parent;
  }
  
  public boolean getShowClose()
  {
    checkWidget();
    return this.showClose;
  }
  
  public String getToolTipText()
  {
    checkWidget();
    if ((this.toolTipText == null) && (this.shortenedText != null))
    {
      String str = getText();
      if (!this.shortenedText.equals(str)) {
        return str;
      }
    }
    return this.toolTipText;
  }
  
  public boolean isShowing()
  {
    checkWidget();
    return this.showing;
  }
  
  public void setControl(Control paramControl)
  {
    checkWidget();
    if (paramControl != null)
    {
      if (paramControl.isDisposed()) {
        SWT.error(5);
      }
      if (paramControl.getParent() != this.parent) {
        SWT.error(32);
      }
    }
    if ((this.control != null) && (!this.control.isDisposed())) {
      this.control.setVisible(false);
    }
    this.control = paramControl;
    if (this.control != null)
    {
      int i = this.parent.indexOf(this);
      if (i == this.parent.getSelectionIndex())
      {
        this.control.setBounds(this.parent.getClientArea());
        this.control.setVisible(true);
      }
      else
      {
        int j = this.parent.getSelectionIndex();
        Control localControl = null;
        if (j != -1) {
          localControl = this.parent.getItem(j).control;
        }
        if (this.control != localControl) {
          this.control.setVisible(false);
        }
      }
    }
  }
  
  @Deprecated
  public void setDisabledImage(Image paramImage)
  {
    checkWidget();
    if ((paramImage != null) && (paramImage.isDisposed())) {
      SWT.error(5);
    }
    this.disabledImage = paramImage;
  }
  
  boolean setFocus()
  {
    return (this.control != null) && (!this.control.isDisposed()) && (this.control.setFocus());
  }
  
  public void setFont(Font paramFont)
  {
    checkWidget();
    if ((paramFont != null) && (paramFont.isDisposed())) {
      SWT.error(5);
    }
    if ((paramFont == null) && (this.font == null)) {
      return;
    }
    if ((paramFont != null) && (paramFont.equals(this.font))) {
      return;
    }
    this.font = paramFont;
    this.parent.updateFolder(12);
  }
  
  public void setImage(Image paramImage)
  {
    checkWidget();
    if ((paramImage != null) && (paramImage.isDisposed())) {
      SWT.error(5);
    }
    Image localImage = getImage();
    if ((paramImage == null) && (localImage == null)) {
      return;
    }
    if ((paramImage != null) && (paramImage.equals(localImage))) {
      return;
    }
    super.setImage(paramImage);
    this.parent.updateFolder(12);
  }
  
  public void setShowClose(boolean paramBoolean)
  {
    checkWidget();
    if (this.showClose == paramBoolean) {
      return;
    }
    this.showClose = paramBoolean;
    this.parent.updateFolder(4);
  }
  
  public void setText(String paramString)
  {
    checkWidget();
    if (paramString == null) {
      SWT.error(4);
    }
    if (paramString.equals(getText())) {
      return;
    }
    super.setText(paramString);
    this.shortenedText = null;
    this.shortenedTextWidth = 0;
    this.parent.updateFolder(12);
  }
  
  public void setToolTipText(String paramString)
  {
    checkWidget();
    this.toolTipText = paramString;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_32.jar!/org/eclipse/swt/custom/CTabItem.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */