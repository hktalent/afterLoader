package org.eclipse.swt.internal.mozilla;

public class nsIHelperAppLauncher
  extends nsISupports
{
  static final int LAST_METHOD_ID = nsISupports.LAST_METHOD_ID + 9;
  public static final String NS_IHELPERAPPLAUNCHER_IID_STR = "9503d0fe-4c9d-11d4-98d0-001083010e9b";
  
  public nsIHelperAppLauncher(int paramInt)
  {
    super(paramInt);
  }
  
  public int SaveToDisk(int paramInt1, int paramInt2)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 4, getAddress(), paramInt1, paramInt2);
  }
  
  public int Cancel()
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 6, getAddress());
  }
  
  static
  {
    IIDStore.RegisterIID(nsIHelperAppLauncher.class, 0, new nsID("9503d0fe-4c9d-11d4-98d0-001083010e9b"));
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_32.jar!/org/eclipse/swt/internal/mozilla/nsIHelperAppLauncher.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */