package org.eclipse.swt.browser;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.internal.C;
import org.eclipse.swt.internal.Compatibility;
import org.eclipse.swt.internal.ole.win32.COM;
import org.eclipse.swt.internal.ole.win32.COMObject;
import org.eclipse.swt.internal.ole.win32.GUID;
import org.eclipse.swt.internal.ole.win32.IPropertyBag;
import org.eclipse.swt.internal.ole.win32.IUnknown;
import org.eclipse.swt.internal.ole.win32.VARIANT;
import org.eclipse.swt.internal.webkit.IWebDataSource;
import org.eclipse.swt.internal.webkit.IWebFrame;
import org.eclipse.swt.internal.webkit.IWebFramePrivate;
import org.eclipse.swt.internal.webkit.IWebOpenPanelResultListener;
import org.eclipse.swt.internal.webkit.IWebURLRequest;
import org.eclipse.swt.internal.webkit.IWebView;
import org.eclipse.swt.internal.webkit.WebKit_win32;
import org.eclipse.swt.internal.win32.DOCINFO;
import org.eclipse.swt.internal.win32.OS;
import org.eclipse.swt.internal.win32.PRINTDLG;
import org.eclipse.swt.internal.win32.RECT;
import org.eclipse.swt.internal.win32.TCHAR;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.Monitor;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

class WebUIDelegate
{
  COMObject iWebUIDelegate;
  int refCount = 0;
  String lastHoveredLinkURL;
  Browser browser;
  Point size;
  Point location;
  boolean menuBar = true;
  boolean toolBar = true;
  boolean statusBar = true;
  boolean prompt = true;
  
  WebUIDelegate(Browser paramBrowser)
  {
    createCOMInterfaces();
    this.browser = paramBrowser;
  }
  
  int AddRef()
  {
    this.refCount += 1;
    return this.refCount;
  }
  
  int canTakeFocus(int paramInt1, int paramInt2, int paramInt3)
  {
    OS.MoveMemory(paramInt3, new int[] { 1 }, 4);
    return 0;
  }
  
  int contextMenuItemsForElement(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    Point localPoint = this.browser.getDisplay().getCursorLocation();
    Event localEvent = new Event();
    localEvent.x = localPoint.x;
    localEvent.y = localPoint.y;
    this.browser.notifyListeners(35, localEvent);
    if (localEvent.doit)
    {
      Menu localMenu = this.browser.getMenu();
      if ((localMenu != null) && (!localMenu.isDisposed()))
      {
        if ((localEvent.x != localPoint.x) || (localEvent.y != localPoint.y)) {
          localMenu.setLocation(localEvent.x, localEvent.y);
        }
        localMenu.setVisible(true);
      }
      else
      {
        OS.MoveMemory(paramInt4, new int[] { paramInt3 }, C.PTR_SIZEOF);
        return 0;
      }
    }
    OS.MoveMemory(paramInt4, new int[] { 0 }, C.PTR_SIZEOF);
    return 0;
  }
  
  void createCOMInterfaces()
  {
    this.iWebUIDelegate = new COMObject(new int[] { 2, 0, 0, 3, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 3, 4, 4, 2, 3, 4, 4, 3, 3, 3, 3, 5, 3, 1, 3, 2, 2, 2, 2, 3, 2, 3, 1, 1, 0, 0, 1, 1, 2, 2, 2, 2, 3, 5, 2, 2, 3, 1, 2, 2, 4, 10, 3 })
    {
      public int method0(int[] paramAnonymousArrayOfInt)
      {
        return WebUIDelegate.this.QueryInterface(paramAnonymousArrayOfInt[0], paramAnonymousArrayOfInt[1]);
      }
      
      public int method1(int[] paramAnonymousArrayOfInt)
      {
        return WebUIDelegate.this.AddRef();
      }
      
      public int method2(int[] paramAnonymousArrayOfInt)
      {
        return WebUIDelegate.this.Release();
      }
      
      public int method3(int[] paramAnonymousArrayOfInt)
      {
        return WebUIDelegate.this.createWebViewWithRequest(paramAnonymousArrayOfInt[0], paramAnonymousArrayOfInt[1], paramAnonymousArrayOfInt[2]);
      }
      
      public int method4(int[] paramAnonymousArrayOfInt)
      {
        return WebUIDelegate.this.webViewShow(paramAnonymousArrayOfInt[0]);
      }
      
      public int method5(int[] paramAnonymousArrayOfInt)
      {
        return WebUIDelegate.this.webViewClose(paramAnonymousArrayOfInt[0]);
      }
      
      public int method6(int[] paramAnonymousArrayOfInt)
      {
        return -2147467263;
      }
      
      public int method7(int[] paramAnonymousArrayOfInt)
      {
        return -2147467263;
      }
      
      public int method8(int[] paramAnonymousArrayOfInt)
      {
        return -2147467263;
      }
      
      public int method9(int[] paramAnonymousArrayOfInt)
      {
        return -2147467263;
      }
      
      public int method10(int[] paramAnonymousArrayOfInt)
      {
        return WebUIDelegate.this.setStatusText(paramAnonymousArrayOfInt[0], paramAnonymousArrayOfInt[1]);
      }
      
      public int method11(int[] paramAnonymousArrayOfInt)
      {
        return -2147467263;
      }
      
      public int method12(int[] paramAnonymousArrayOfInt)
      {
        return -2147467263;
      }
      
      public int method13(int[] paramAnonymousArrayOfInt)
      {
        return WebUIDelegate.this.setToolbarsVisible(paramAnonymousArrayOfInt[0], paramAnonymousArrayOfInt[1]);
      }
      
      public int method14(int[] paramAnonymousArrayOfInt)
      {
        return -2147467263;
      }
      
      public int method15(int[] paramAnonymousArrayOfInt)
      {
        return WebUIDelegate.this.setStatusBarVisible(paramAnonymousArrayOfInt[0], paramAnonymousArrayOfInt[1]);
      }
      
      public int method16(int[] paramAnonymousArrayOfInt)
      {
        return -2147467263;
      }
      
      public int method17(int[] paramAnonymousArrayOfInt)
      {
        return -2147467263;
      }
      
      public int method18(int[] paramAnonymousArrayOfInt)
      {
        return WebUIDelegate.this.setFrame(paramAnonymousArrayOfInt[0], paramAnonymousArrayOfInt[1]);
      }
      
      public int method19(int[] paramAnonymousArrayOfInt)
      {
        return -2147467263;
      }
      
      public int method20(int[] paramAnonymousArrayOfInt)
      {
        return -2147467263;
      }
      
      public int method21(int[] paramAnonymousArrayOfInt)
      {
        return -2147467263;
      }
      
      public int method22(int[] paramAnonymousArrayOfInt)
      {
        return WebUIDelegate.this.runJavaScriptAlertPanelWithMessage(paramAnonymousArrayOfInt[0], paramAnonymousArrayOfInt[1]);
      }
      
      public int method23(int[] paramAnonymousArrayOfInt)
      {
        return WebUIDelegate.this.runJavaScriptConfirmPanelWithMessage(paramAnonymousArrayOfInt[0], paramAnonymousArrayOfInt[1], paramAnonymousArrayOfInt[2]);
      }
      
      public int method24(int[] paramAnonymousArrayOfInt)
      {
        return WebUIDelegate.this.runJavaScriptTextInputPanelWithPrompt(paramAnonymousArrayOfInt[0], paramAnonymousArrayOfInt[1], paramAnonymousArrayOfInt[2], paramAnonymousArrayOfInt[3]);
      }
      
      public int method25(int[] paramAnonymousArrayOfInt)
      {
        return WebUIDelegate.this.runBeforeUnloadConfirmPanelWithMessage(paramAnonymousArrayOfInt[0], paramAnonymousArrayOfInt[1], paramAnonymousArrayOfInt[2], paramAnonymousArrayOfInt[3]);
      }
      
      public int method26(int[] paramAnonymousArrayOfInt)
      {
        return WebUIDelegate.this.runOpenPanelForFileButtonWithResultListener(paramAnonymousArrayOfInt[0], paramAnonymousArrayOfInt[1]);
      }
      
      public int method27(int[] paramAnonymousArrayOfInt)
      {
        return WebUIDelegate.this.mouseDidMoveOverElement(paramAnonymousArrayOfInt[0], paramAnonymousArrayOfInt[1], paramAnonymousArrayOfInt[2]);
      }
      
      public int method28(int[] paramAnonymousArrayOfInt)
      {
        return WebUIDelegate.this.contextMenuItemsForElement(paramAnonymousArrayOfInt[0], paramAnonymousArrayOfInt[1], paramAnonymousArrayOfInt[2], paramAnonymousArrayOfInt[3]);
      }
      
      public int method29(int[] paramAnonymousArrayOfInt)
      {
        return -2147467263;
      }
      
      public int method30(int[] paramAnonymousArrayOfInt)
      {
        return -2147467263;
      }
      
      public int method31(int[] paramAnonymousArrayOfInt)
      {
        return -2147467263;
      }
      
      public int method32(int[] paramAnonymousArrayOfInt)
      {
        return -2147467263;
      }
      
      public int method33(int[] paramAnonymousArrayOfInt)
      {
        return -2147467263;
      }
      
      public int method34(int[] paramAnonymousArrayOfInt)
      {
        return -2147467263;
      }
      
      public int method35(int[] paramAnonymousArrayOfInt)
      {
        return -2147467263;
      }
      
      public int method36(int[] paramAnonymousArrayOfInt)
      {
        return -2147467263;
      }
      
      public int method37(int[] paramAnonymousArrayOfInt)
      {
        return -2147467263;
      }
      
      public int method38(int[] paramAnonymousArrayOfInt)
      {
        return -2147467263;
      }
      
      public int method39(int[] paramAnonymousArrayOfInt)
      {
        return -2147467263;
      }
      
      public int method40(int[] paramAnonymousArrayOfInt)
      {
        return -2147467263;
      }
      
      public int method41(int[] paramAnonymousArrayOfInt)
      {
        return -2147467263;
      }
      
      public int method42(int[] paramAnonymousArrayOfInt)
      {
        return WebUIDelegate.this.canTakeFocus(paramAnonymousArrayOfInt[0], paramAnonymousArrayOfInt[1], paramAnonymousArrayOfInt[2]);
      }
      
      public int method43(int[] paramAnonymousArrayOfInt)
      {
        return WebUIDelegate.this.takeFocus(paramAnonymousArrayOfInt[0], paramAnonymousArrayOfInt[1]);
      }
      
      public int method44(int[] paramAnonymousArrayOfInt)
      {
        return -2147467263;
      }
      
      public int method45(int[] paramAnonymousArrayOfInt)
      {
        return 0;
      }
      
      public int method46(int[] paramAnonymousArrayOfInt)
      {
        return -2147467263;
      }
      
      public int method47(int[] paramAnonymousArrayOfInt)
      {
        return -2147467263;
      }
      
      public int method48(int[] paramAnonymousArrayOfInt)
      {
        return -2147467263;
      }
      
      public int method49(int[] paramAnonymousArrayOfInt)
      {
        return -2147467263;
      }
      
      public int method50(int[] paramAnonymousArrayOfInt)
      {
        return -2147467263;
      }
      
      public int method51(int[] paramAnonymousArrayOfInt)
      {
        return WebUIDelegate.this.printFrame(paramAnonymousArrayOfInt[0], paramAnonymousArrayOfInt[1]);
      }
      
      public int method52(int[] paramAnonymousArrayOfInt)
      {
        return -2147467263;
      }
      
      public int method53(int[] paramAnonymousArrayOfInt)
      {
        return -2147467263;
      }
      
      public int method54(int[] paramAnonymousArrayOfInt)
      {
        return -2147467263;
      }
      
      public int method55(int[] paramAnonymousArrayOfInt)
      {
        return -2147467263;
      }
      
      public int method56(int[] paramAnonymousArrayOfInt)
      {
        return -2147467263;
      }
      
      public int method57(int[] paramAnonymousArrayOfInt)
      {
        return -2147467263;
      }
      
      public int method58(int[] paramAnonymousArrayOfInt)
      {
        return -2147467263;
      }
      
      public int method59(int[] paramAnonymousArrayOfInt)
      {
        return -2147467263;
      }
      
      public int method60(int[] paramAnonymousArrayOfInt)
      {
        return -2147467263;
      }
      
      public int method61(int[] paramAnonymousArrayOfInt)
      {
        return -2147467263;
      }
      
      public int method62(int[] paramAnonymousArrayOfInt)
      {
        return WebUIDelegate.this.setMenuBarVisible(paramAnonymousArrayOfInt[0], paramAnonymousArrayOfInt[1]);
      }
      
      public int method63(int[] paramAnonymousArrayOfInt)
      {
        return -2147467263;
      }
      
      public int method64(int[] paramAnonymousArrayOfInt)
      {
        return -2147467263;
      }
      
      public int method65(int[] paramAnonymousArrayOfInt)
      {
        return -2147467263;
      }
    };
  }
  
  int createWebViewWithRequest(int paramInt1, int paramInt2, int paramInt3)
  {
    WindowEvent localWindowEvent = new WindowEvent(this.browser);
    localWindowEvent.display = this.browser.getDisplay();
    localWindowEvent.widget = this.browser;
    localWindowEvent.required = true;
    OpenWindowListener[] arrayOfOpenWindowListener = this.browser.webBrowser.openWindowListeners;
    for (int i = 0; i < arrayOfOpenWindowListener.length; i++) {
      arrayOfOpenWindowListener[i].open(localWindowEvent);
    }
    IWebView localIWebView = null;
    Browser localBrowser = null;
    if ((localWindowEvent.browser != null) && ((localWindowEvent.browser.webBrowser instanceof WebKit))) {
      localBrowser = localWindowEvent.browser;
    }
    if ((localBrowser != null) && (!localBrowser.isDisposed()))
    {
      localIWebView = ((WebKit)localBrowser.webBrowser).webView;
      OS.MoveMemory(paramInt3, new int[] { localIWebView.getAddress() }, OS.PTR_SIZEOF);
      if (paramInt2 != 0)
      {
        IWebURLRequest localIWebURLRequest = new IWebURLRequest(paramInt2);
        int[] arrayOfInt = new int[1];
        int j = localIWebURLRequest.URL(arrayOfInt);
        if ((j != 0) || (arrayOfInt[0] == 0)) {
          return 0;
        }
        String str = WebKit.extractBSTR(arrayOfInt[0]);
        COM.SysFreeString(arrayOfInt[0]);
        if (str.length() != 0)
        {
          arrayOfInt[0] = 0;
          j = localIWebView.mainFrame(arrayOfInt);
          if ((j != 0) || (arrayOfInt[0] == 0)) {
            return 0;
          }
          IWebFrame localIWebFrame = new IWebFrame(arrayOfInt[0]);
          localIWebFrame.loadRequest(localIWebURLRequest.getAddress());
          localIWebFrame.Release();
        }
      }
      return 0;
    }
    return -2147467263;
  }
  
  protected void disposeCOMInterfaces()
  {
    if (this.iWebUIDelegate != null)
    {
      this.iWebUIDelegate.dispose();
      this.iWebUIDelegate = null;
    }
  }
  
  int getAddress()
  {
    return this.iWebUIDelegate.getAddress();
  }
  
  int mouseDidMoveOverElement(int paramInt1, int paramInt2, int paramInt3)
  {
    if (paramInt2 == 0) {
      return 0;
    }
    IPropertyBag localIPropertyBag = new IPropertyBag(paramInt2);
    int i = WebKit.createBSTR("WebElementLinkURLKey");
    int j = OS.GetProcessHeap();
    int k = OS.HeapAlloc(j, 8, VARIANT.sizeof);
    int m = localIPropertyBag.Read(i, k, null);
    if ((m != 0) || (k == 0)) {
      return 0;
    }
    String str = null;
    VARIANT localVARIANT = new VARIANT();
    COM.MoveMemory(localVARIANT, k, VARIANT.sizeof);
    if (localVARIANT.vt == 8) {
      str = WebKit.extractBSTR(localVARIANT.lVal);
    }
    OS.HeapFree(j, 0, k);
    StatusTextListener[] arrayOfStatusTextListener = this.browser.webBrowser.statusTextListeners;
    if ((str == null) || (str.length() == 0))
    {
      if (this.lastHoveredLinkURL == null) {
        return 0;
      }
      this.lastHoveredLinkURL = null;
      localStatusTextEvent = new StatusTextEvent(this.browser);
      localStatusTextEvent.display = this.browser.getDisplay();
      localStatusTextEvent.widget = this.browser;
      localStatusTextEvent.text = "";
      for (n = 0; n < arrayOfStatusTextListener.length; n++) {
        arrayOfStatusTextListener[n].changed(localStatusTextEvent);
      }
      return 0;
    }
    if (str.equals(this.lastHoveredLinkURL)) {
      return 0;
    }
    this.lastHoveredLinkURL = str;
    StatusTextEvent localStatusTextEvent = new StatusTextEvent(this.browser);
    localStatusTextEvent.display = this.browser.getDisplay();
    localStatusTextEvent.widget = this.browser;
    localStatusTextEvent.text = str;
    for (int n = 0; n < arrayOfStatusTextListener.length; n++) {
      arrayOfStatusTextListener[n].changed(localStatusTextEvent);
    }
    return 0;
  }
  
  int printFrame(int paramInt1, int paramInt2)
  {
    IWebFrame localIWebFrame = new IWebFrame(paramInt2);
    PRINTDLG localPRINTDLG = new PRINTDLG();
    localPRINTDLG.lStructSize = PRINTDLG.sizeof;
    localPRINTDLG.Flags = 256;
    if (!OS.PrintDlg(localPRINTDLG)) {
      return 0;
    }
    int i = localPRINTDLG.hDC;
    int[] arrayOfInt1 = new int[1];
    int j = localIWebFrame.QueryInterface(WebKit_win32.IID_IWebFramePrivate, arrayOfInt1);
    if ((j != 0) || (arrayOfInt1[0] == 0)) {
      return 0;
    }
    IWebFramePrivate localIWebFramePrivate = new IWebFramePrivate(arrayOfInt1[0]);
    localIWebFramePrivate.setInPrintingMode(1, i);
    int[] arrayOfInt2 = new int[1];
    j = localIWebFramePrivate.getPrintedPageCount(i, arrayOfInt2);
    if ((j != 0) || (arrayOfInt2[0] == 0))
    {
      localIWebFramePrivate.Release();
      return 0;
    }
    int k = arrayOfInt2[0];
    String str = null;
    arrayOfInt1[0] = 0;
    j = localIWebFrame.dataSource(arrayOfInt1);
    if ((j == 0) && (arrayOfInt1[0] != 0))
    {
      localObject = new IWebDataSource(arrayOfInt1[0]);
      arrayOfInt1[0] = 0;
      j = ((IWebDataSource)localObject).pageTitle(arrayOfInt1);
      ((IWebDataSource)localObject).Release();
      if ((j == 0) && (arrayOfInt1[0] != 0))
      {
        str = WebKit.extractBSTR(arrayOfInt1[0]);
        COM.SysFreeString(arrayOfInt1[0]);
      }
    }
    Object localObject = new DOCINFO();
    ((DOCINFO)localObject).cbSize = DOCINFO.sizeof;
    int m = OS.GetProcessHeap();
    int n = 0;
    int i2;
    if ((str != null) && (str.length() != 0))
    {
      TCHAR localTCHAR = new TCHAR(0, str, true);
      i2 = localTCHAR.length() * TCHAR.sizeof;
      n = OS.HeapAlloc(m, 8, i2);
      OS.MoveMemory(n, localTCHAR, i2);
      ((DOCINFO)localObject).lpszDocName = n;
    }
    int i1 = OS.StartDoc(i, (DOCINFO)localObject);
    if (n != 0) {
      OS.HeapFree(m, 0, n);
    }
    if (i1 >= 0)
    {
      for (i2 = 0; i2 < k; i2++)
      {
        OS.StartPage(i);
        localIWebFramePrivate.spoolPages(i, i2, i2, null);
        OS.EndPage(i);
      }
      localIWebFramePrivate.setInPrintingMode(0, i);
      OS.EndDoc(i);
    }
    localIWebFramePrivate.Release();
    return 0;
  }
  
  int QueryInterface(int paramInt1, int paramInt2)
  {
    if ((paramInt1 == 0) || (paramInt2 == 0)) {
      return -2147024809;
    }
    GUID localGUID = new GUID();
    COM.MoveMemory(localGUID, paramInt1, GUID.sizeof);
    if (COM.IsEqualGUID(localGUID, COM.IIDIUnknown))
    {
      COM.MoveMemory(paramInt2, new int[] { this.iWebUIDelegate.getAddress() }, OS.PTR_SIZEOF);
      new IUnknown(this.iWebUIDelegate.getAddress()).AddRef();
      return 0;
    }
    if (COM.IsEqualGUID(localGUID, WebKit_win32.IID_IWebUIDelegate))
    {
      COM.MoveMemory(paramInt2, new int[] { this.iWebUIDelegate.getAddress() }, OS.PTR_SIZEOF);
      new IUnknown(this.iWebUIDelegate.getAddress()).AddRef();
      return 0;
    }
    COM.MoveMemory(paramInt2, new int[] { 0 }, OS.PTR_SIZEOF);
    return -2147467262;
  }
  
  int Release()
  {
    this.refCount -= 1;
    if (this.refCount == 0) {
      disposeCOMInterfaces();
    }
    return this.refCount;
  }
  
  int runBeforeUnloadConfirmPanelWithMessage(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    if (!this.prompt) {
      return 0;
    }
    Shell localShell = this.browser.getShell();
    String str = WebKit.extractBSTR(paramInt2);
    StringBuffer localStringBuffer = new StringBuffer(Compatibility.getMessage("SWT_OnBeforeUnload_Message1"));
    localStringBuffer.append("\n\n");
    localStringBuffer.append(str);
    localStringBuffer.append("\n\n");
    localStringBuffer.append(Compatibility.getMessage("SWT_OnBeforeUnload_Message2"));
    MessageBox localMessageBox = new MessageBox(localShell, 292);
    localMessageBox.setMessage(localStringBuffer.toString());
    int[] arrayOfInt = new int[1];
    arrayOfInt[0] = (localMessageBox.open() == 32 ? 1 : 0);
    OS.MoveMemory(paramInt4, arrayOfInt, 4);
    return 0;
  }
  
  int runJavaScriptAlertPanelWithMessage(int paramInt1, int paramInt2)
  {
    String str = WebKit.extractBSTR(paramInt2);
    showAlertMessage("Javascript", str);
    return 0;
  }
  
  int runJavaScriptConfirmPanelWithMessage(int paramInt1, int paramInt2, int paramInt3)
  {
    String str = WebKit.extractBSTR(paramInt2);
    int[] arrayOfInt = new int[1];
    arrayOfInt[0] = (showConfirmPanel("Javascript", str) == 32 ? 1 : 0);
    OS.MoveMemory(paramInt3, arrayOfInt, 4);
    return 0;
  }
  
  int runJavaScriptTextInputPanelWithPrompt(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    String str1 = WebKit.extractBSTR(paramInt2);
    String str2 = WebKit.extractBSTR(paramInt3);
    String str3 = showTextPrompter("Javascript", str1, str2);
    int[] arrayOfInt = new int[1];
    if (str3 != null) {
      arrayOfInt[0] = WebKit.createBSTR(str3);
    }
    OS.MoveMemory(paramInt4, arrayOfInt, C.PTR_SIZEOF);
    return 0;
  }
  
  int runOpenPanelForFileButtonWithResultListener(int paramInt1, int paramInt2)
  {
    Shell localShell = this.browser.getShell();
    FileDialog localFileDialog = new FileDialog(localShell, 0);
    String str = localFileDialog.open();
    IWebOpenPanelResultListener localIWebOpenPanelResultListener = new IWebOpenPanelResultListener(paramInt2);
    if (str == null) {
      localIWebOpenPanelResultListener.cancel();
    } else {
      localIWebOpenPanelResultListener.chooseFilename(WebKit.createBSTR(str));
    }
    return 0;
  }
  
  int setFrame(int paramInt1, int paramInt2)
  {
    RECT localRECT = new RECT();
    COM.MoveMemory(localRECT, paramInt2, RECT.sizeof);
    this.location = this.browser.getDisplay().map(this.browser, null, localRECT.left, localRECT.top);
    int i = localRECT.right - localRECT.left;
    int j = localRECT.bottom - localRECT.top;
    if ((j < 0) || (i < 0) || ((i == 0) && (j == 0))) {
      return 0;
    }
    this.size = new Point(i, j);
    return 0;
  }
  
  int setMenuBarVisible(int paramInt1, int paramInt2)
  {
    this.menuBar = (paramInt2 == 1);
    return 0;
  }
  
  int setStatusBarVisible(int paramInt1, int paramInt2)
  {
    this.statusBar = (paramInt2 == 1);
    return 0;
  }
  
  int setStatusText(int paramInt1, int paramInt2)
  {
    String str = WebKit.extractBSTR(paramInt2);
    if (str.length() == 0) {
      return 0;
    }
    StatusTextEvent localStatusTextEvent = new StatusTextEvent(this.browser);
    localStatusTextEvent.display = this.browser.getDisplay();
    localStatusTextEvent.widget = this.browser;
    localStatusTextEvent.text = str;
    StatusTextListener[] arrayOfStatusTextListener = this.browser.webBrowser.statusTextListeners;
    for (int i = 0; i < arrayOfStatusTextListener.length; i++) {
      arrayOfStatusTextListener[i].changed(localStatusTextEvent);
    }
    return 0;
  }
  
  int setToolbarsVisible(int paramInt1, int paramInt2)
  {
    this.toolBar = (paramInt2 == 1);
    return 0;
  }
  
  void showAlertMessage(String paramString1, String paramString2)
  {
    Shell localShell1 = this.browser.getShell();
    final Shell localShell2 = new Shell(localShell1, 67680);
    GridLayout localGridLayout = new GridLayout(2, false);
    localGridLayout.horizontalSpacing = 10;
    localGridLayout.verticalSpacing = 20;
    localGridLayout.marginWidth = (localGridLayout.marginHeight = 10);
    localShell2.setLayout(localGridLayout);
    localShell2.setText(paramString1);
    Label localLabel = new Label(localShell2, 0);
    Image localImage = localShell2.getDisplay().getSystemImage(8);
    localLabel.setImage(localImage);
    localLabel = new Label(localShell2, 64);
    localLabel.setText(paramString2);
    Monitor localMonitor = localShell1.getMonitor();
    int i = localMonitor.getBounds().width * 2 / 3;
    int j = localLabel.computeSize(-1, -1).x;
    GridData localGridData1 = new GridData(4, 16777216, true, false);
    localGridData1.widthHint = Math.min(j, i);
    localLabel.setLayoutData(localGridData1);
    Button localButton = new Button(localShell2, 8);
    localButton.setText(SWT.getMessage("SWT_OK"));
    j = localButton.computeSize(-1, -1).x;
    GridData localGridData2 = new GridData();
    localGridData2.horizontalAlignment = 16777216;
    localGridData2.verticalAlignment = 16777216;
    localGridData2.horizontalSpan = 2;
    localGridData2.widthHint = Math.max(j, 75);
    localButton.setLayoutData(localGridData2);
    localButton.addSelectionListener(new SelectionAdapter()
    {
      public void widgetSelected(SelectionEvent paramAnonymousSelectionEvent)
      {
        localShell2.dispose();
      }
    });
    localShell2.setDefaultButton(localButton);
    localShell2.pack();
    Rectangle localRectangle1 = localShell1.getBounds();
    Rectangle localRectangle2 = localShell2.getBounds();
    int k = localShell1.getLocation().x + (localRectangle1.width - localRectangle2.width) / 2;
    int m = localShell1.getLocation().y + (localRectangle1.height - localRectangle2.height) / 2;
    localShell2.setLocation(k, m);
    localShell2.open();
    Display localDisplay = this.browser.getDisplay();
    while (!localShell2.isDisposed()) {
      if (!localDisplay.readAndDispatch()) {
        localDisplay.sleep();
      }
    }
  }
  
  int showConfirmPanel(String paramString1, String paramString2)
  {
    Shell localShell1 = this.browser.getShell();
    final Shell localShell2 = new Shell(localShell1, 67680);
    GridLayout localGridLayout = new GridLayout(2, false);
    localGridLayout.horizontalSpacing = 10;
    localGridLayout.verticalSpacing = 20;
    localGridLayout.marginWidth = (localGridLayout.marginHeight = 10);
    localShell2.setLayout(localGridLayout);
    localShell2.setText(paramString1);
    Label localLabel = new Label(localShell2, 0);
    Image localImage = localShell2.getDisplay().getSystemImage(4);
    localLabel.setImage(localImage);
    localLabel.setLayoutData(new GridData());
    localLabel = new Label(localShell2, 64);
    localLabel.setText(paramString2);
    Monitor localMonitor = localShell1.getMonitor();
    int i = localMonitor.getBounds().width * 2 / 3;
    int j = localLabel.computeSize(-1, -1).x;
    GridData localGridData1 = new GridData(4, 16777216, true, false);
    localGridData1.widthHint = Math.min(j, i);
    localLabel.setLayoutData(localGridData1);
    Composite localComposite = new Composite(localShell2, 0);
    localGridData1 = new GridData(16777216, 16777216, true, true, 2, 1);
    localComposite.setLayoutData(localGridData1);
    localComposite.setLayout(new GridLayout(2, true));
    Button localButton1 = new Button(localComposite, 8);
    localButton1.setText(SWT.getMessage("SWT_OK"));
    GridData localGridData2 = new GridData();
    localGridData2.horizontalAlignment = 16777216;
    localGridData2.verticalAlignment = 16777216;
    localButton1.setLayoutData(localGridData2);
    Button localButton2 = new Button(localComposite, 8);
    localButton2.setText(SWT.getMessage("SWT_Cancel"));
    localButton2.setLayoutData(localGridData2);
    j = localButton2.computeSize(-1, -1).x;
    localGridData2.widthHint = Math.max(j, 75);
    final int[] arrayOfInt = new int[1];
    localButton1.addSelectionListener(new SelectionAdapter()
    {
      public void widgetSelected(SelectionEvent paramAnonymousSelectionEvent)
      {
        arrayOfInt[0] = 32;
        localShell2.dispose();
      }
    });
    localButton2.addSelectionListener(new SelectionAdapter()
    {
      public void widgetSelected(SelectionEvent paramAnonymousSelectionEvent)
      {
        arrayOfInt[0] = 256;
        localShell2.dispose();
      }
    });
    localShell2.setDefaultButton(localButton1);
    localShell2.pack();
    Rectangle localRectangle1 = localShell1.getBounds();
    Rectangle localRectangle2 = localShell2.getBounds();
    int k = localShell1.getLocation().x + (localRectangle1.width - localRectangle2.width) / 2;
    int m = localShell1.getLocation().y + (localRectangle1.height - localRectangle2.height) / 2;
    localShell2.setLocation(k, m);
    localShell2.open();
    Display localDisplay = this.browser.getDisplay();
    while (!localShell2.isDisposed()) {
      if (!localDisplay.readAndDispatch()) {
        localDisplay.sleep();
      }
    }
    return arrayOfInt[0];
  }
  
  String showTextPrompter(String paramString1, String paramString2, String paramString3)
  {
    Shell localShell1 = this.browser.getShell();
    final Shell localShell2 = new Shell(localShell1, 67680);
    localShell2.setLayout(new GridLayout());
    localShell2.setText(paramString1);
    Label localLabel = new Label(localShell2, 0);
    localLabel.setLayoutData(new GridData(768));
    localLabel.setText(paramString2);
    final Text localText = new Text(localShell2, 2052);
    GridData localGridData = new GridData(768);
    localGridData.widthHint = 300;
    localText.setLayoutData(localGridData);
    localText.setText(paramString3);
    Composite localComposite = new Composite(localShell2, 0);
    localComposite.setLayout(new GridLayout(2, true));
    localComposite.setLayoutData(new GridData(64));
    Button localButton1 = new Button(localComposite, 8);
    localButton1.setText(SWT.getMessage("SWT_OK"));
    localButton1.setLayoutData(new GridData(768));
    final String[] arrayOfString = new String[1];
    localButton1.addSelectionListener(new SelectionAdapter()
    {
      public void widgetSelected(SelectionEvent paramAnonymousSelectionEvent)
      {
        arrayOfString[0] = localText.getText();
        localShell2.dispose();
      }
    });
    Button localButton2 = new Button(localComposite, 8);
    localButton2.setText(SWT.getMessage("SWT_Cancel"));
    localButton2.setLayoutData(new GridData(768));
    localButton2.addSelectionListener(new SelectionAdapter()
    {
      public void widgetSelected(SelectionEvent paramAnonymousSelectionEvent)
      {
        localShell2.dispose();
      }
    });
    localShell2.setDefaultButton(localButton1);
    localShell2.pack();
    Rectangle localRectangle1 = localShell1.getBounds();
    Rectangle localRectangle2 = localShell2.getBounds();
    int i = localShell1.getLocation().x + (localRectangle1.width - localRectangle2.width) / 2;
    int j = localShell1.getLocation().y + (localRectangle1.height - localRectangle2.height) / 2;
    localShell2.setLocation(i, j);
    localShell2.open();
    Display localDisplay = this.browser.getDisplay();
    while (!localShell2.isDisposed()) {
      if (!localDisplay.readAndDispatch()) {
        localDisplay.sleep();
      }
    }
    return arrayOfString[0];
  }
  
  int takeFocus(int paramInt1, int paramInt2)
  {
    int i = paramInt2 == 0 ? 8 : 16;
    ((WebKit)this.browser.webBrowser).traverseOut = true;
    this.browser.traverse(i);
    return 0;
  }
  
  int webViewClose(int paramInt)
  {
    WindowEvent localWindowEvent = new WindowEvent(this.browser);
    localWindowEvent.display = this.browser.getDisplay();
    localWindowEvent.widget = this.browser;
    CloseWindowListener[] arrayOfCloseWindowListener = this.browser.webBrowser.closeWindowListeners;
    for (int i = 0; i < arrayOfCloseWindowListener.length; i++) {
      arrayOfCloseWindowListener[i].close(localWindowEvent);
    }
    this.browser.dispose();
    return 0;
  }
  
  int webViewFrame(int paramInt1, int paramInt2)
  {
    RECT localRECT = new RECT();
    OS.MoveMemory(paramInt2, localRECT, RECT.sizeof);
    return 0;
  }
  
  int webViewShow(int paramInt)
  {
    WindowEvent localWindowEvent = new WindowEvent(this.browser);
    localWindowEvent.display = this.browser.getDisplay();
    localWindowEvent.widget = this.browser;
    if (this.location != null) {
      localWindowEvent.location = this.location;
    }
    if (this.size != null) {
      localWindowEvent.size = this.size;
    }
    localWindowEvent.addressBar = this.toolBar;
    localWindowEvent.menuBar = this.menuBar;
    localWindowEvent.statusBar = this.statusBar;
    localWindowEvent.toolBar = this.toolBar;
    VisibilityWindowListener[] arrayOfVisibilityWindowListener = this.browser.webBrowser.visibilityWindowListeners;
    for (int i = 0; i < arrayOfVisibilityWindowListener.length; i++) {
      arrayOfVisibilityWindowListener[i].show(localWindowEvent);
    }
    this.location = null;
    this.size = null;
    return 0;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_32.jar!/org/eclipse/swt/browser/WebUIDelegate.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */