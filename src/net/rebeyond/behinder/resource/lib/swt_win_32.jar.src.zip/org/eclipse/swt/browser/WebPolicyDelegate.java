package org.eclipse.swt.browser;

import org.eclipse.swt.internal.Compatibility;
import org.eclipse.swt.internal.ole.win32.COM;
import org.eclipse.swt.internal.ole.win32.COMObject;
import org.eclipse.swt.internal.ole.win32.GUID;
import org.eclipse.swt.internal.ole.win32.IUnknown;
import org.eclipse.swt.internal.webkit.IWebError;
import org.eclipse.swt.internal.webkit.IWebPolicyDecisionListener;
import org.eclipse.swt.internal.webkit.IWebPreferences;
import org.eclipse.swt.internal.webkit.IWebURLRequest;
import org.eclipse.swt.internal.webkit.IWebView;
import org.eclipse.swt.internal.webkit.WebKit_win32;
import org.eclipse.swt.internal.win32.OS;
import org.eclipse.swt.widgets.MessageBox;

class WebPolicyDelegate
{
  COMObject iWebPolicyDelegate;
  int refCount = 0;
  Browser browser;
  
  WebPolicyDelegate(Browser paramBrowser)
  {
    createCOMInterfaces();
    this.browser = paramBrowser;
  }
  
  int AddRef()
  {
    this.refCount += 1;
    return this.refCount;
  }
  
  void createCOMInterfaces()
  {
    this.iWebPolicyDelegate = new COMObject(new int[] { 2, 0, 0, 5, 5, 5, 3 })
    {
      public int method0(int[] paramAnonymousArrayOfInt)
      {
        return WebPolicyDelegate.this.QueryInterface(paramAnonymousArrayOfInt[0], paramAnonymousArrayOfInt[1]);
      }
      
      public int method1(int[] paramAnonymousArrayOfInt)
      {
        return WebPolicyDelegate.this.AddRef();
      }
      
      public int method2(int[] paramAnonymousArrayOfInt)
      {
        return WebPolicyDelegate.this.Release();
      }
      
      public int method3(int[] paramAnonymousArrayOfInt)
      {
        return WebPolicyDelegate.this.decidePolicyForNavigationAction(paramAnonymousArrayOfInt[0], paramAnonymousArrayOfInt[1], paramAnonymousArrayOfInt[2], paramAnonymousArrayOfInt[3], paramAnonymousArrayOfInt[4]);
      }
      
      public int method4(int[] paramAnonymousArrayOfInt)
      {
        return WebPolicyDelegate.this.decidePolicyForNewWindowAction(paramAnonymousArrayOfInt[0], paramAnonymousArrayOfInt[1], paramAnonymousArrayOfInt[2], paramAnonymousArrayOfInt[3], paramAnonymousArrayOfInt[4]);
      }
      
      public int method5(int[] paramAnonymousArrayOfInt)
      {
        return WebPolicyDelegate.this.decidePolicyForMIMEType(paramAnonymousArrayOfInt[0], paramAnonymousArrayOfInt[1], paramAnonymousArrayOfInt[2], paramAnonymousArrayOfInt[3], paramAnonymousArrayOfInt[4]);
      }
      
      public int method6(int[] paramAnonymousArrayOfInt)
      {
        return WebPolicyDelegate.this.unableToImplementPolicyWithError(paramAnonymousArrayOfInt[0], paramAnonymousArrayOfInt[1], paramAnonymousArrayOfInt[2]);
      }
    };
  }
  
  int decidePolicyForMIMEType(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
  {
    IWebView localIWebView = new IWebView(paramInt1);
    int[] arrayOfInt = new int[1];
    localIWebView.canShowMIMEType(paramInt2, arrayOfInt);
    IWebPolicyDecisionListener localIWebPolicyDecisionListener = new IWebPolicyDecisionListener(paramInt5);
    if (arrayOfInt[0] != 0) {
      localIWebPolicyDecisionListener.use();
    } else {
      localIWebPolicyDecisionListener.download();
    }
    return 0;
  }
  
  int decidePolicyForNavigationAction(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
  {
    IWebURLRequest localIWebURLRequest = new IWebURLRequest(paramInt3);
    int[] arrayOfInt = new int[1];
    int i = localIWebURLRequest.URL(arrayOfInt);
    if ((i != 0) || (arrayOfInt[0] == 0)) {
      return 0;
    }
    String str = WebKit.extractBSTR(arrayOfInt[0]);
    COM.SysFreeString(arrayOfInt[0]);
    IWebPolicyDecisionListener localIWebPolicyDecisionListener = new IWebPolicyDecisionListener(paramInt5);
    WebKit localWebKit = (WebKit)this.browser.webBrowser;
    if (localWebKit.loadingText)
    {
      localIWebPolicyDecisionListener.use();
      return 0;
    }
    if (str.length() == 0)
    {
      localIWebPolicyDecisionListener.ignore();
      return 0;
    }
    if ((str.startsWith("file://")) && (localWebKit.getUrl().startsWith("about:blank")) && (localWebKit.untrustedText))
    {
      localIWebPolicyDecisionListener.ignore();
      return 0;
    }
    if (str.equals("file:///"))
    {
      str = "about:blank";
    }
    else
    {
      int j = "file:///".length();
      if ((str.startsWith("file:///")) && (str.charAt(j) == '#')) {
        str = "about:blank" + str.substring(j);
      }
    }
    LocationEvent localLocationEvent = new LocationEvent(this.browser);
    localLocationEvent.display = this.browser.getDisplay();
    localLocationEvent.widget = this.browser;
    localLocationEvent.location = str;
    localLocationEvent.doit = true;
    LocationListener[] arrayOfLocationListener = localWebKit.locationListeners;
    if (arrayOfLocationListener != null) {
      for (int k = 0; k < arrayOfLocationListener.length; k++) {
        arrayOfLocationListener[k].changing(localLocationEvent);
      }
    }
    if (localLocationEvent.doit)
    {
      if (localWebKit.jsEnabled != localWebKit.jsEnabledOnNextPage)
      {
        localWebKit.jsEnabled = localWebKit.jsEnabledOnNextPage;
        IWebView localIWebView = new IWebView(paramInt1);
        arrayOfInt[0] = 0;
        i = localIWebView.preferences(arrayOfInt);
        if ((i == 0) && (arrayOfInt[0] != 0))
        {
          IWebPreferences localIWebPreferences = new IWebPreferences(arrayOfInt[0]);
          i = localIWebPreferences.setJavaScriptEnabled(localWebKit.jsEnabled ? 1 : 0);
          localIWebView.setPreferences(localIWebPreferences.getAddress());
          localIWebPreferences.Release();
        }
      }
      localIWebPolicyDecisionListener.use();
      localWebKit.lastNavigateURL = str;
    }
    else
    {
      localIWebPolicyDecisionListener.ignore();
    }
    return 0;
  }
  
  int decidePolicyForNewWindowAction(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
  {
    IWebPolicyDecisionListener localIWebPolicyDecisionListener = new IWebPolicyDecisionListener(paramInt5);
    localIWebPolicyDecisionListener.use();
    return 0;
  }
  
  protected void disposeCOMInterfaces()
  {
    if (this.iWebPolicyDelegate != null)
    {
      this.iWebPolicyDelegate.dispose();
      this.iWebPolicyDelegate = null;
    }
  }
  
  int getAddress()
  {
    return this.iWebPolicyDelegate.getAddress();
  }
  
  int QueryInterface(int paramInt1, int paramInt2)
  {
    if ((paramInt1 == 0) || (paramInt2 == 0)) {
      return -2147024809;
    }
    GUID localGUID = new GUID();
    COM.MoveMemory(localGUID, paramInt1, GUID.sizeof);
    if (COM.IsEqualGUID(localGUID, COM.IIDIUnknown))
    {
      COM.MoveMemory(paramInt2, new int[] { this.iWebPolicyDelegate.getAddress() }, OS.PTR_SIZEOF);
      new IUnknown(this.iWebPolicyDelegate.getAddress()).AddRef();
      return 0;
    }
    if (COM.IsEqualGUID(localGUID, WebKit_win32.IID_IWebPolicyDelegate))
    {
      COM.MoveMemory(paramInt2, new int[] { this.iWebPolicyDelegate.getAddress() }, OS.PTR_SIZEOF);
      new IUnknown(this.iWebPolicyDelegate.getAddress()).AddRef();
      return 0;
    }
    COM.MoveMemory(paramInt2, new int[] { 0 }, OS.PTR_SIZEOF);
    return -2147467262;
  }
  
  int Release()
  {
    this.refCount -= 1;
    if (this.refCount == 0) {
      disposeCOMInterfaces();
    }
    return this.refCount;
  }
  
  int unableToImplementPolicyWithError(int paramInt1, int paramInt2, int paramInt3)
  {
    if (this.browser.isDisposed()) {
      return 0;
    }
    IWebError localIWebError = new IWebError(paramInt2);
    String str1 = null;
    int[] arrayOfInt = new int[1];
    int i = localIWebError.failingURL(arrayOfInt);
    if ((i == 0) && (arrayOfInt[0] != 0))
    {
      str1 = WebKit.extractBSTR(arrayOfInt[0]);
      COM.SysFreeString(arrayOfInt[0]);
    }
    arrayOfInt[0] = 0;
    i = localIWebError.localizedDescription(arrayOfInt);
    if ((i != 0) || (arrayOfInt[0] == 0)) {
      return 0;
    }
    String str2 = WebKit.extractBSTR(arrayOfInt[0]);
    COM.SysFreeString(arrayOfInt[0]);
    String str3 = str1 != null ? str1 + "\n\n" : "";
    str3 = str3 + Compatibility.getMessage("SWT_Page_Load_Failed", new Object[] { str2 });
    MessageBox localMessageBox = new MessageBox(this.browser.getShell(), 33);
    localMessageBox.setMessage(str3);
    localMessageBox.open();
    return 0;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_32.jar!/org/eclipse/swt/browser/WebPolicyDelegate.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */