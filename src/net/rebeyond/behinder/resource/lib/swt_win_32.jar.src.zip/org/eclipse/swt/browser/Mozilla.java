package org.eclipse.swt.browser;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Locale;
import java.util.StringTokenizer;
import java.util.Vector;
import org.eclipse.swt.SWT;
import org.eclipse.swt.SWTError;
import org.eclipse.swt.graphics.Device;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.internal.C;
import org.eclipse.swt.internal.Compatibility;
import org.eclipse.swt.internal.LONG;
import org.eclipse.swt.internal.Library;
import org.eclipse.swt.internal.mozilla.IIDStore;
import org.eclipse.swt.internal.mozilla.MozillaVersion;
import org.eclipse.swt.internal.mozilla.XPCOM;
import org.eclipse.swt.internal.mozilla.XPCOMObject;
import org.eclipse.swt.internal.mozilla.init.GREProperty;
import org.eclipse.swt.internal.mozilla.init.GREVersionRange;
import org.eclipse.swt.internal.mozilla.init.XPCOMInit;
import org.eclipse.swt.internal.mozilla.nsDynamicFunctionLoad;
import org.eclipse.swt.internal.mozilla.nsEmbedString;
import org.eclipse.swt.internal.mozilla.nsIAppShell;
import org.eclipse.swt.internal.mozilla.nsIBaseWindow;
import org.eclipse.swt.internal.mozilla.nsICategoryManager;
import org.eclipse.swt.internal.mozilla.nsICertOverrideService;
import org.eclipse.swt.internal.mozilla.nsIChannel;
import org.eclipse.swt.internal.mozilla.nsIComponentManager;
import org.eclipse.swt.internal.mozilla.nsIComponentRegistrar;
import org.eclipse.swt.internal.mozilla.nsICookie;
import org.eclipse.swt.internal.mozilla.nsICookieManager;
import org.eclipse.swt.internal.mozilla.nsICookieService;
import org.eclipse.swt.internal.mozilla.nsID;
import org.eclipse.swt.internal.mozilla.nsIDOMDocument;
import org.eclipse.swt.internal.mozilla.nsIDOMEvent;
import org.eclipse.swt.internal.mozilla.nsIDOMEventTarget;
import org.eclipse.swt.internal.mozilla.nsIDOMKeyEvent;
import org.eclipse.swt.internal.mozilla.nsIDOMMouseEvent;
import org.eclipse.swt.internal.mozilla.nsIDOMSerializer;
import org.eclipse.swt.internal.mozilla.nsIDOMWindow;
import org.eclipse.swt.internal.mozilla.nsIDOMWindowCollection;
import org.eclipse.swt.internal.mozilla.nsIDocShell;
import org.eclipse.swt.internal.mozilla.nsIEmbeddingSiteWindow;
import org.eclipse.swt.internal.mozilla.nsIFile;
import org.eclipse.swt.internal.mozilla.nsIFocusManager;
import org.eclipse.swt.internal.mozilla.nsIHttpChannel;
import org.eclipse.swt.internal.mozilla.nsIIOService;
import org.eclipse.swt.internal.mozilla.nsIInputStream;
import org.eclipse.swt.internal.mozilla.nsIInterfaceRequestor;
import org.eclipse.swt.internal.mozilla.nsIJSContextStack;
import org.eclipse.swt.internal.mozilla.nsILocalFile;
import org.eclipse.swt.internal.mozilla.nsIMIMEInputStream;
import org.eclipse.swt.internal.mozilla.nsIObserverService;
import org.eclipse.swt.internal.mozilla.nsIPrefBranch;
import org.eclipse.swt.internal.mozilla.nsIPrefLocalizedString;
import org.eclipse.swt.internal.mozilla.nsIPrefService;
import org.eclipse.swt.internal.mozilla.nsIPrincipal;
import org.eclipse.swt.internal.mozilla.nsIProperties;
import org.eclipse.swt.internal.mozilla.nsIRequest;
import org.eclipse.swt.internal.mozilla.nsISSLStatus;
import org.eclipse.swt.internal.mozilla.nsIScriptContext;
import org.eclipse.swt.internal.mozilla.nsIScriptGlobalObject;
import org.eclipse.swt.internal.mozilla.nsIScriptSecurityManager;
import org.eclipse.swt.internal.mozilla.nsISeekableStream;
import org.eclipse.swt.internal.mozilla.nsIServiceManager;
import org.eclipse.swt.internal.mozilla.nsISimpleEnumerator;
import org.eclipse.swt.internal.mozilla.nsISupports;
import org.eclipse.swt.internal.mozilla.nsIURI;
import org.eclipse.swt.internal.mozilla.nsIUploadChannel;
import org.eclipse.swt.internal.mozilla.nsIWebBrowser;
import org.eclipse.swt.internal.mozilla.nsIWebBrowserChrome;
import org.eclipse.swt.internal.mozilla.nsIWebBrowserFocus;
import org.eclipse.swt.internal.mozilla.nsIWebBrowserSetup;
import org.eclipse.swt.internal.mozilla.nsIWebBrowserStream;
import org.eclipse.swt.internal.mozilla.nsIWebNavigation;
import org.eclipse.swt.internal.mozilla.nsIWebNavigationInfo;
import org.eclipse.swt.internal.mozilla.nsIWebProgress;
import org.eclipse.swt.internal.mozilla.nsIWebProgressListener;
import org.eclipse.swt.internal.mozilla.nsIWindowWatcher;
import org.eclipse.swt.internal.mozilla.nsIX509Cert;
import org.eclipse.swt.internal.mozilla.nsIX509CertValidity;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.Shell;

class Mozilla
  extends WebBrowser
{
  int embedHandle;
  nsIWebBrowser webBrowser;
  Object webBrowserObject;
  MozillaDelegate delegate;
  XPCOMObject supports;
  XPCOMObject weakReference;
  XPCOMObject webProgressListener;
  XPCOMObject webProgressListener_24;
  XPCOMObject webBrowserChrome;
  XPCOMObject webBrowserChromeFocus;
  XPCOMObject embeddingSiteWindow;
  XPCOMObject embeddingSiteWindow_24;
  XPCOMObject interfaceRequestor;
  XPCOMObject supportsWeakReference;
  XPCOMObject contextMenuListener;
  XPCOMObject uriContentListener;
  XPCOMObject tooltipListener;
  XPCOMObject domEventListener;
  XPCOMObject badCertListener;
  int chromeFlags = 1;
  int registerFunctionsOnState = 0;
  int refCount;
  int lastKeyCode;
  int lastCharCode;
  int authCount;
  int request;
  int badCertRequest;
  Point location;
  Point size;
  boolean visible;
  boolean isActive;
  boolean isChild;
  boolean ignoreDispose;
  boolean isRetrievingBadCert;
  boolean isViewingErrorPage;
  boolean ignoreAllMessages;
  boolean untrustedText;
  boolean updateLastNavigateUrl;
  Shell tip = null;
  Listener listener;
  Vector unhookedDOMWindows = new Vector();
  String lastNavigateURL;
  byte[] htmlBytes;
  static nsIAppShell AppShell;
  static AppFileLocProvider LocationProvider;
  static WindowCreator2 WindowCreator;
  static int BrowserCount;
  static int NextJSFunctionIndex = 1;
  static Hashtable AllFunctions = new Hashtable();
  static Listener DisplayListener;
  static boolean Initialized;
  static boolean IsXULRunner;
  static boolean PerformedVersionCheck;
  static boolean XPCOMWasGlued;
  static boolean XPCOMInitWasGlued;
  static boolean IsGettingSiteWindow;
  static String MozillaPath;
  static String oldProxyHostFTP;
  static String oldProxyHostHTTP;
  static String oldProxyHostSSL;
  static int oldProxyPortFTP = -1;
  static int oldProxyPortHTTP = -1;
  static int oldProxyPortSSL = -1;
  static int oldProxyType = -1;
  static byte[] jsLibPathBytes;
  static byte[] pathBytes_NSFree;
  static final String GCC3 = "-gcc3";
  static final String GRERANGE_LOWER = "1.8.1.2";
  static final String GRERANGE_LOWER_FALLBACK = "1.8";
  static final boolean LowerRangeInclusive = true;
  static final String GRERANGE_UPPER = "1.9.*";
  static final boolean UpperRangeInclusive = true;
  static final String PROPERTY_ABI = "abi";
  static final int MAX_PORT = 65535;
  static final String DEFAULTVALUE_STRING = "default";
  static final char SEPARATOR_OS = System.getProperty("file.separator").charAt(0);
  static final String ABOUT_BLANK = "about:blank";
  static final String DISPOSE_LISTENER_HOOKED = "org.eclipse.swt.browser.Mozilla.disposeListenerHooked";
  static final String HEADER_CONTENTLENGTH = "content-length";
  static final String HEADER_CONTENTTYPE = "content-type";
  static final String MIMETYPE_FORMURLENCODED = "application/x-www-form-urlencoded";
  static final String MOZILLA_FIVE_HOME = "MOZILLA_FIVE_HOME";
  static final String PREFIX_JAVASCRIPT = "javascript:";
  static final String PREFERENCE_CHARSET = "intl.charset.default";
  static final String PREFERENCE_DISABLEOPENDURINGLOAD = "dom.disable_open_during_load";
  static final String PREFERENCE_DISABLEOPENWINDOWSTATUSHIDE = "dom.disable_window_open_feature.status";
  static final String PREFERENCE_DISABLEWINDOWSTATUSCHANGE = "dom.disable_window_status_change";
  static final String PREFERENCE_JAVASCRIPTENABLED = "javascript.enabled";
  static final String PREFERENCE_LANGUAGES = "intl.accept_languages";
  static final String PREFERENCE_PROXYHOST_FTP = "network.proxy.ftp";
  static final String PREFERENCE_PROXYPORT_FTP = "network.proxy.ftp_port";
  static final String PREFERENCE_PROXYHOST_HTTP = "network.proxy.http";
  static final String PREFERENCE_PROXYPORT_HTTP = "network.proxy.http_port";
  static final String PREFERENCE_PROXYHOST_SSL = "network.proxy.ssl";
  static final String PREFERENCE_PROXYPORT_SSL = "network.proxy.ssl_port";
  static final String PREFERENCE_PROXYTYPE = "network.proxy.type";
  static final String PROFILE_AFTER_CHANGE = "profile-after-change";
  static final String PROFILE_BEFORE_CHANGE = "profile-before-change";
  static final String PROFILE_DIR = SEPARATOR_OS + "eclipse" + SEPARATOR_OS;
  static final String PROFILE_DO_CHANGE = "profile-do-change";
  static final String PROPERTY_PROXYPORT = "network.proxy_port";
  static final String PROPERTY_PROXYHOST = "network.proxy_host";
  static final String SEPARATOR_LOCALE = "-";
  static final String SHUTDOWN_PERSIST = "shutdown-persist";
  static final String STARTUP = "startup";
  static final String TOKENIZER_LOCALE = ",";
  static final String TRUE = "true";
  static final String URI_FILEROOT = "file:///";
  static final String MOZILLA_PROFILE_PATH = "org.eclipse.swt.browser.MOZ_PROFILE_PATH";
  static final String XULRUNNER_PATH = "org.eclipse.swt.browser.XULRunnerPath";
  static final String FACTORIES_REGISTERED = "org.eclipse.swt.browser.MozillaFactoriesRegistered";
  static final String GRE_INITIALIZED = "org.eclipse.swt.browser.XULRunnerInitialized";
  
  static String Arch()
  {
    String str = System.getProperty("os.arch");
    if ((str.equals("i386")) || (str.equals("i686"))) {
      return "x86";
    }
    if (str.equals("amd64")) {
      return "x86_64";
    }
    if (str.equals("IA64N")) {
      return "ia64_32";
    }
    if (str.equals("IA64W")) {
      return "ia64";
    }
    return str;
  }
  
  static String OS()
  {
    String str = System.getProperty("os.name");
    if (str.equals("Linux")) {
      return "linux";
    }
    if (str.equals("AIX")) {
      return "aix";
    }
    if ((str.equals("Solaris")) || (str.equals("SunOS"))) {
      return "solaris";
    }
    if (str.equals("HP-UX")) {
      return "hpux";
    }
    if (str.equals("Mac OS X")) {
      return "macosx";
    }
    if (str.startsWith("Win")) {
      return "win32";
    }
    return str;
  }
  
  static void LoadLibraries()
  {
    int i = 0;
    if (Boolean.getBoolean("org.eclipse.swt.browser.XULRunnerInitialized")) {
      Initialized = true;
    }
    MozillaPath = System.getProperty("org.eclipse.swt.browser.XULRunnerPath");
    if (MozillaPath == null) {
      try
      {
        Class.forName("org.eclipse.swt.browser.XULRunnerInitializer");
        MozillaPath = System.getProperty("org.eclipse.swt.browser.XULRunnerPath");
      }
      catch (ClassNotFoundException localClassNotFoundException) {}
    }
    if (MozillaPath == null)
    {
      try
      {
        String str = MozillaDelegate.getSWTInitLibraryName();
        Library.loadLibrary(str);
        i = 1;
      }
      catch (UnsatisfiedLinkError localUnsatisfiedLinkError) {}
    }
    else
    {
      if (SEPARATOR_OS == '/') {
        MozillaPath = MozillaPath.replace('\\', SEPARATOR_OS);
      } else {
        MozillaPath = MozillaPath.replace('/', SEPARATOR_OS);
      }
      MozillaPath += SEPARATOR_OS;
      MozillaPath += MozillaDelegate.getLibraryName(MozillaPath);
      IsXULRunner = true;
    }
    if (i != 0)
    {
      MozillaPath = InitDiscoverXULRunner();
      IsXULRunner = MozillaPath.length() > 0;
      if (IsXULRunner)
      {
        byte[] arrayOfByte = MozillaDelegate.wcsToMbcs(null, MozillaPath, true);
        int j = XPCOMInit.XPCOMGlueStartup(arrayOfByte);
        if (j != 0)
        {
          MozillaPath = MozillaPath.substring(0, MozillaPath.lastIndexOf(SEPARATOR_OS));
          if (Device.DEBUG) {
            System.out.println("cannot use detected XULRunner: " + MozillaPath);
          }
          int k = C.getenv(MozillaDelegate.wcsToMbcs(null, "MOZILLA_FIVE_HOME", true));
          if (k == 0)
          {
            IsXULRunner = false;
          }
          else
          {
            int m = C.strlen(k);
            arrayOfByte = new byte[m];
            C.memmove(arrayOfByte, k, m);
            MozillaPath = new String(MozillaDelegate.mbcsToWcs(null, arrayOfByte));
            if (MozillaPath.indexOf("xulrunner") == -1)
            {
              IsXULRunner = false;
            }
            else
            {
              MozillaPath += SEPARATOR_OS;
              MozillaPath += MozillaDelegate.getLibraryName(MozillaPath);
              arrayOfByte = MozillaDelegate.wcsToMbcs(null, MozillaPath, true);
              j = XPCOMInit.XPCOMGlueStartup(arrayOfByte);
              if (j == 0)
              {
                if (SEPARATOR_OS == '/') {
                  MozillaPath = MozillaPath.replace('\\', SEPARATOR_OS);
                } else {
                  MozillaPath = MozillaPath.replace('/', SEPARATOR_OS);
                }
              }
              else
              {
                IsXULRunner = false;
                MozillaPath = MozillaPath.substring(0, MozillaPath.lastIndexOf(SEPARATOR_OS));
                if (Device.DEBUG) {
                  System.out.println("failed to start as XULRunner: " + MozillaPath);
                }
              }
            }
          }
        }
        if (IsXULRunner) {
          XPCOMInitWasGlued = true;
        }
      }
    }
  }
  
  public void create(Composite paramComposite, int paramInt)
  {
    this.delegate = new MozillaDelegate(this.browser);
    Display localDisplay = paramComposite.getDisplay();
    int[] arrayOfInt = new int[1];
    if (!Initialized)
    {
      LoadLibraries();
      String str;
      if (IsXULRunner)
      {
        MozillaPath = initXULRunner(MozillaPath);
      }
      else
      {
        if ((paramInt & 0x8000) != 0)
        {
          this.browser.dispose();
          str = (MozillaPath != null) && (MozillaPath.length() > 0) ? " [Failed to use detected XULRunner: " + MozillaPath + "]" : " [Could not detect registered XULRunner to use]";
          SWT.error(2, null, str);
        }
        MozillaPath = initMozilla(MozillaPath);
      }
      if (!Initialized)
      {
        str = System.getProperty("org.eclipse.swt.browser.MOZ_PROFILE_PATH");
        if ((str != null) && (str.length() > 0))
        {
          if (SEPARATOR_OS == '/') {
            str = str.replace('\\', SEPARATOR_OS);
          } else {
            str = str.replace('/', SEPARATOR_OS);
          }
        }
        else {
          str = MozillaDelegate.getProfilePath();
        }
        localObject1 = MozillaDelegate.getCacheParentPath();
        LocationProvider = new AppFileLocProvider(MozillaPath, str, (String)localObject1, IsXULRunner);
        LocationProvider.AddRef();
        initExternal(LocationProvider.profilePath);
        initXPCOM(MozillaPath, IsXULRunner);
      }
      if (IsXULRunner) {
        initJavaXPCOM(MozillaPath);
      }
      i = XPCOM.NS_GetComponentManager(arrayOfInt);
      if (i != 0)
      {
        this.browser.dispose();
        error(i);
      }
      if (arrayOfInt[0] == 0)
      {
        this.browser.dispose();
        error(-2147467262);
      }
      localObject1 = new nsIComponentManager(arrayOfInt[0]);
      arrayOfInt[0] = 0;
      i = XPCOM.NS_GetServiceManager(arrayOfInt);
      if (i != 0)
      {
        this.browser.dispose();
        error(i);
      }
      if (arrayOfInt[0] == 0)
      {
        this.browser.dispose();
        error(-2147467262);
      }
      localObject2 = new nsIServiceManager(arrayOfInt[0]);
      arrayOfInt[0] = 0;
      initSpinup((nsIComponentManager)localObject1);
      j = Boolean.getBoolean("org.eclipse.swt.browser.MozillaFactoriesRegistered");
      if (j == 0) {
        initWindowCreator((nsIServiceManager)localObject2);
      }
      initProfile((nsIServiceManager)localObject2, IsXULRunner);
      initPreferences((nsIServiceManager)localObject2, (nsIComponentManager)localObject1);
      if (j == 0) {
        initFactories((nsIServiceManager)localObject2, (nsIComponentManager)localObject1, IsXULRunner);
      }
      ((nsIServiceManager)localObject2).Release();
      ((nsIComponentManager)localObject1).Release();
      if (MozillaPendingCookies != null) {
        SetPendingCookies(MozillaPendingCookies);
      }
      MozillaPendingCookies = null;
      Initialized = true;
    }
    BrowserCount += 1;
    if (localDisplay.getData("org.eclipse.swt.browser.Mozilla.disposeListenerHooked") == null)
    {
      localDisplay.setData("org.eclipse.swt.browser.Mozilla.disposeListenerHooked", "org.eclipse.swt.browser.Mozilla.disposeListenerHooked");
      localDisplay.addListener(12, DisplayListener);
    }
    int i = XPCOM.NS_GetComponentManager(arrayOfInt);
    if (i != 0)
    {
      this.browser.dispose();
      error(i);
    }
    if (arrayOfInt[0] == 0)
    {
      this.browser.dispose();
      error(-2147467262);
    }
    Object localObject1 = new nsIComponentManager(arrayOfInt[0]);
    arrayOfInt[0] = 0;
    i = ((nsIComponentManager)localObject1).CreateInstance(XPCOM.NS_IWEBBROWSER_CID, 0, IIDStore.GetIID(nsIWebBrowser.class), arrayOfInt);
    if (i != 0)
    {
      this.browser.dispose();
      error(i);
    }
    if (arrayOfInt[0] == 0)
    {
      this.browser.dispose();
      error(-2147467262);
    }
    this.webBrowser = new nsIWebBrowser(arrayOfInt[0]);
    arrayOfInt[0] = 0;
    createCOMInterfaces();
    AddRef();
    initWebBrowserWindows();
    if (!PerformedVersionCheck)
    {
      PerformedVersionCheck = true;
      i = ((nsIComponentManager)localObject1).QueryInterface(IIDStore.GetIID(nsIComponentRegistrar.class), arrayOfInt);
      if (i != 0)
      {
        this.browser.dispose();
        error(i);
      }
      if (arrayOfInt[0] == 0)
      {
        this.browser.dispose();
        error(-2147467262);
      }
      localObject2 = new nsIComponentRegistrar(arrayOfInt[0]);
      arrayOfInt[0] = 0;
      j = Boolean.getBoolean("org.eclipse.swt.browser.MozillaFactoriesRegistered");
      Object localObject3;
      Object localObject4;
      if (!MozillaVersion.CheckVersion(5))
      {
        i = this.webBrowser.QueryInterface(IIDStore.GetIID(nsIInterfaceRequestor.class), arrayOfInt);
        if (i != 0)
        {
          this.browser.dispose();
          error(-2147467259);
        }
        if (arrayOfInt[0] == 0)
        {
          this.browser.dispose();
          error(-2147467262);
        }
        localObject3 = new nsIInterfaceRequestor(arrayOfInt[0]);
        arrayOfInt[0] = 0;
        for (int k = 4; 0 <= k; k--)
        {
          localObject4 = IIDStore.GetIID(nsIDocShell.class, k, true);
          if (localObject4 != null)
          {
            arrayOfInt[0] = 0;
            i = ((nsIInterfaceRequestor)localObject3).GetInterface((nsID)localObject4, arrayOfInt);
            if ((i == 0) && (arrayOfInt[0] != 0))
            {
              new nsISupports(arrayOfInt[0]).Release();
              MozillaVersion.SetCurrentVersion(k);
              break;
            }
          }
        }
        ((nsIInterfaceRequestor)localObject3).Release();
        arrayOfInt[0] = 0;
      }
      byte[] arrayOfByte;
      if ((MozillaVersion.CheckVersion(1, true)) && (j == 0))
      {
        localObject3 = new DownloadFactory_1_8();
        ((DownloadFactory_1_8)localObject3).AddRef();
        arrayOfByte = MozillaDelegate.wcsToMbcs(null, "@mozilla.org/transfer;1", true);
        localObject4 = MozillaDelegate.wcsToMbcs(null, "swtTransfer", true);
        i = ((nsIComponentRegistrar)localObject2).RegisterFactory(XPCOM.NS_DOWNLOAD_CID, (byte[])localObject4, arrayOfByte, ((DownloadFactory_1_8)localObject3).getAddress());
        if (i != 0)
        {
          this.browser.dispose();
          error(i);
        }
        ((DownloadFactory_1_8)localObject3).Release();
      }
      ((nsIComponentRegistrar)localObject2).Release();
      if (j == 0)
      {
        localObject3 = new HelperAppLauncherDialogFactory();
        ((HelperAppLauncherDialogFactory)localObject3).AddRef();
        arrayOfByte = MozillaDelegate.wcsToMbcs(null, "@mozilla.org/helperapplauncherdialog;1", true);
        localObject4 = MozillaDelegate.wcsToMbcs(null, "swtHelperAppLauncherDialog", true);
        i = ((nsIComponentRegistrar)localObject2).RegisterFactory(XPCOM.NS_HELPERAPPLAUNCHERDIALOG_CID, (byte[])localObject4, arrayOfByte, ((HelperAppLauncherDialogFactory)localObject3).getAddress());
        if (i != 0)
        {
          this.browser.dispose();
          error(i);
        }
        ((HelperAppLauncherDialogFactory)localObject3).Release();
      }
      System.setProperty("org.eclipse.swt.browser.MozillaFactoriesRegistered", "true");
    }
    ((nsIComponentManager)localObject1).Release();
    if (MozillaVersion.CheckVersion(2)) {
      this.delegate.addWindowSubclass();
    }
    i = this.webBrowser.AddWebBrowserListener(this.weakReference.getAddress(), IIDStore.GetIID(nsIWebProgressListener.class));
    if (i != 0)
    {
      this.browser.dispose();
      error(i);
    }
    i = this.webBrowser.SetParentURIContentListener(this.uriContentListener.getAddress());
    if (i != 0)
    {
      this.browser.dispose();
      error(i);
    }
    this.delegate.init();
    this.listener = new Listener()
    {
      public void handleEvent(Event paramAnonymousEvent)
      {
        Object localObject;
        switch (paramAnonymousEvent.type)
        {
        case 12: 
          if (Mozilla.this.ignoreDispose)
          {
            Mozilla.this.ignoreDispose = false;
          }
          else
          {
            Mozilla.this.ignoreDispose = true;
            Mozilla.this.browser.notifyListeners(paramAnonymousEvent.type, paramAnonymousEvent);
            paramAnonymousEvent.type = 0;
            Mozilla.this.onDispose(paramAnonymousEvent.display);
          }
          break;
        case 11: 
          Mozilla.this.onResize();
          break;
        case 15: 
          Mozilla.this.Activate();
          localObject = new int[1];
          int i = XPCOM.NS_GetServiceManager((int[])localObject);
          if (i != 0) {
            Mozilla.error(i);
          }
          if (localObject[0] == 0) {
            Mozilla.error(-2147467262);
          }
          nsIServiceManager localnsIServiceManager = new nsIServiceManager(localObject[0]);
          localObject[0] = 0;
          byte[] arrayOfByte = MozillaDelegate.wcsToMbcs(null, "@mozilla.org/focus-manager;1", true);
          i = localnsIServiceManager.GetServiceByContractID(arrayOfByte, IIDStore.GetIID(nsIFocusManager.class), (int[])localObject);
          localnsIServiceManager.Release();
          if ((i == 0) && (localObject[0] != 0))
          {
            nsIFocusManager localnsIFocusManager = new nsIFocusManager(localObject[0]);
            localObject[0] = 0;
            i = localnsIFocusManager.GetFocusedElement((int[])localObject);
            if (i == 0) {
              if (localObject[0] != 0)
              {
                new nsISupports(localObject[0]).Release();
                localObject[0] = 0;
              }
              else
              {
                i = Mozilla.this.webBrowser.GetContentDOMWindow((int[])localObject);
                if ((i == 0) && (localObject[0] != 0))
                {
                  nsIDOMWindow localnsIDOMWindow = new nsIDOMWindow(localObject[0]);
                  localObject[0] = 0;
                  i = localnsIDOMWindow.GetDocument((int[])localObject);
                  localnsIDOMWindow.Release();
                  if ((i == 0) && (localObject[0] != 0))
                  {
                    nsIDOMDocument localnsIDOMDocument = new nsIDOMDocument(localObject[0]);
                    localObject[0] = 0;
                    i = localnsIDOMDocument.GetDocumentElement((int[])localObject);
                    localnsIDOMDocument.Release();
                    if ((i == 0) && (localObject[0] != 0))
                    {
                      i = localnsIFocusManager.SetFocus(localObject[0], 8192);
                      new nsISupports(localObject[0]).Release();
                      localObject[0] = 0;
                    }
                  }
                }
              }
            }
            localnsIFocusManager.Release();
          }
          break;
        case 26: 
          Mozilla.this.Activate();
          break;
        case 27: 
          localObject = paramAnonymousEvent.display;
          if (Mozilla.this.browser == ((Display)localObject).getFocusControl()) {
            Mozilla.this.Deactivate();
          }
          break;
        case 22: 
          localObject = paramAnonymousEvent.display;
          ((Display)localObject).asyncExec(new Runnable()
          {
            public void run()
            {
              if (Mozilla.this.browser.isDisposed()) {
                return;
              }
              Mozilla.this.onResize();
            }
          });
          break;
        }
      }
    };
    Object localObject2 = { 12, 11, 15, 26, 27, 22, 1 };
    for (int j = 0; j < localObject2.length; j++) {
      this.browser.addListener(localObject2[j], this.listener);
    }
  }
  
  public boolean back()
  {
    this.htmlBytes = null;
    int[] arrayOfInt = new int[1];
    int i = this.webBrowser.QueryInterface(IIDStore.GetIID(nsIWebNavigation.class), arrayOfInt);
    if (i != 0) {
      error(i);
    }
    if (arrayOfInt[0] == 0) {
      error(-2147467262);
    }
    nsIWebNavigation localnsIWebNavigation = new nsIWebNavigation(arrayOfInt[0]);
    i = localnsIWebNavigation.GoBack();
    localnsIWebNavigation.Release();
    return i == 0;
  }
  
  public boolean close()
  {
    final boolean[] arrayOfBoolean = { false };
    LocationListener[] arrayOfLocationListener = this.locationListeners;
    this.locationListeners = new LocationListener[] { new LocationAdapter()
    {
      public void changing(LocationEvent paramAnonymousLocationEvent)
      {
        arrayOfBoolean[0] = true;
      }
    } };
    execute("window.location.replace('about:blank');");
    this.locationListeners = arrayOfLocationListener;
    return arrayOfBoolean[0];
  }
  
  void createCOMInterfaces()
  {
    this.supports = new XPCOMObject(new int[] { 2, 0, 0 })
    {
      public int method0(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.QueryInterface(paramAnonymousArrayOfInt[0], paramAnonymousArrayOfInt[1]);
      }
      
      public int method1(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.AddRef();
      }
      
      public int method2(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.Release();
      }
    };
    this.weakReference = new XPCOMObject(new int[] { 2, 0, 0, 2 })
    {
      public int method0(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.QueryInterface(paramAnonymousArrayOfInt[0], paramAnonymousArrayOfInt[1]);
      }
      
      public int method1(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.AddRef();
      }
      
      public int method2(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.Release();
      }
      
      public int method3(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.QueryReferent(paramAnonymousArrayOfInt[0], paramAnonymousArrayOfInt[1]);
      }
    };
    this.webProgressListener = new XPCOMObject(new int[] { 2, 0, 0, 4, 6, 3, 4, 3 })
    {
      public int method0(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.QueryInterface(paramAnonymousArrayOfInt[0], paramAnonymousArrayOfInt[1]);
      }
      
      public int method1(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.AddRef();
      }
      
      public int method2(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.Release();
      }
      
      public int method3(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.OnStateChange(paramAnonymousArrayOfInt[0], paramAnonymousArrayOfInt[1], paramAnonymousArrayOfInt[2], paramAnonymousArrayOfInt[3]);
      }
      
      public int method4(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.OnProgressChange(paramAnonymousArrayOfInt[0], paramAnonymousArrayOfInt[1], paramAnonymousArrayOfInt[2], paramAnonymousArrayOfInt[3], paramAnonymousArrayOfInt[4], paramAnonymousArrayOfInt[5]);
      }
      
      public int method5(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.OnLocationChange(paramAnonymousArrayOfInt[0], paramAnonymousArrayOfInt[1], paramAnonymousArrayOfInt[2]);
      }
      
      public int method6(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.OnStatusChange(paramAnonymousArrayOfInt[0], paramAnonymousArrayOfInt[1], paramAnonymousArrayOfInt[2], paramAnonymousArrayOfInt[3]);
      }
      
      public int method7(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.OnSecurityChange(paramAnonymousArrayOfInt[0], paramAnonymousArrayOfInt[1], paramAnonymousArrayOfInt[2]);
      }
    };
    this.webProgressListener_24 = new XPCOMObject(new int[] { 2, 0, 0, 4, 6, 4, 4, 3 })
    {
      public int method0(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.QueryInterface(paramAnonymousArrayOfInt[0], paramAnonymousArrayOfInt[1]);
      }
      
      public int method1(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.AddRef();
      }
      
      public int method2(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.Release();
      }
      
      public int method3(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.OnStateChange(paramAnonymousArrayOfInt[0], paramAnonymousArrayOfInt[1], paramAnonymousArrayOfInt[2], paramAnonymousArrayOfInt[3]);
      }
      
      public int method4(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.OnProgressChange(paramAnonymousArrayOfInt[0], paramAnonymousArrayOfInt[1], paramAnonymousArrayOfInt[2], paramAnonymousArrayOfInt[3], paramAnonymousArrayOfInt[4], paramAnonymousArrayOfInt[5]);
      }
      
      public int method5(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.OnLocationChange(paramAnonymousArrayOfInt[0], paramAnonymousArrayOfInt[1], paramAnonymousArrayOfInt[2], paramAnonymousArrayOfInt[3]);
      }
      
      public int method6(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.OnStatusChange(paramAnonymousArrayOfInt[0], paramAnonymousArrayOfInt[1], paramAnonymousArrayOfInt[2], paramAnonymousArrayOfInt[3]);
      }
      
      public int method7(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.OnSecurityChange(paramAnonymousArrayOfInt[0], paramAnonymousArrayOfInt[1], paramAnonymousArrayOfInt[2]);
      }
    };
    this.webBrowserChrome = new XPCOMObject(new int[] { 2, 0, 0, 2, 1, 1, 1, 1, 0, 2, 0, 1, 1 })
    {
      public int method0(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.QueryInterface(paramAnonymousArrayOfInt[0], paramAnonymousArrayOfInt[1]);
      }
      
      public int method1(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.AddRef();
      }
      
      public int method2(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.Release();
      }
      
      public int method3(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.SetStatus(paramAnonymousArrayOfInt[0], paramAnonymousArrayOfInt[1]);
      }
      
      public int method4(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.GetWebBrowser(paramAnonymousArrayOfInt[0]);
      }
      
      public int method5(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.SetWebBrowser(paramAnonymousArrayOfInt[0]);
      }
      
      public int method6(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.GetChromeFlags(paramAnonymousArrayOfInt[0]);
      }
      
      public int method7(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.SetChromeFlags(paramAnonymousArrayOfInt[0]);
      }
      
      public int method8(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.DestroyBrowserWindow();
      }
      
      public int method9(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.SizeBrowserTo(paramAnonymousArrayOfInt[0], paramAnonymousArrayOfInt[1]);
      }
      
      public int method10(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.ShowAsModal();
      }
      
      public int method11(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.IsWindowModal(paramAnonymousArrayOfInt[0]);
      }
      
      public int method12(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.ExitModalEventLoop(paramAnonymousArrayOfInt[0]);
      }
    };
    this.webBrowserChromeFocus = new XPCOMObject(new int[] { 2, 0, 0, 0, 0 })
    {
      public int method0(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.QueryInterface(paramAnonymousArrayOfInt[0], paramAnonymousArrayOfInt[1]);
      }
      
      public int method1(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.AddRef();
      }
      
      public int method2(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.Release();
      }
      
      public int method3(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.FocusNextElement();
      }
      
      public int method4(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.FocusPrevElement();
      }
    };
    this.embeddingSiteWindow = new XPCOMObject(new int[] { 2, 0, 0, 5, 5, 0, 1, 1, 1, 1, 1 })
    {
      public int method0(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.QueryInterface(paramAnonymousArrayOfInt[0], paramAnonymousArrayOfInt[1]);
      }
      
      public int method1(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.AddRef();
      }
      
      public int method2(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.Release();
      }
      
      public int method3(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.SetDimensions(paramAnonymousArrayOfInt[0], paramAnonymousArrayOfInt[1], paramAnonymousArrayOfInt[2], paramAnonymousArrayOfInt[3], paramAnonymousArrayOfInt[4]);
      }
      
      public int method4(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.GetDimensions(paramAnonymousArrayOfInt[0], paramAnonymousArrayOfInt[1], paramAnonymousArrayOfInt[2], paramAnonymousArrayOfInt[3], paramAnonymousArrayOfInt[4]);
      }
      
      public int method5(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.SetFocus();
      }
      
      public int method6(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.GetVisibility(paramAnonymousArrayOfInt[0]);
      }
      
      public int method7(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.SetVisibility(paramAnonymousArrayOfInt[0]);
      }
      
      public int method8(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.GetTitle(paramAnonymousArrayOfInt[0]);
      }
      
      public int method9(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.SetTitle(paramAnonymousArrayOfInt[0]);
      }
      
      public int method10(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.GetSiteWindow(paramAnonymousArrayOfInt[0]);
      }
    };
    this.embeddingSiteWindow_24 = new XPCOMObject(new int[] { 2, 0, 0, 5, 5, 0, 1, 1, 1, 1, 1, 0 })
    {
      public int method0(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.QueryInterface(paramAnonymousArrayOfInt[0], paramAnonymousArrayOfInt[1]);
      }
      
      public int method1(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.AddRef();
      }
      
      public int method2(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.Release();
      }
      
      public int method3(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.SetDimensions(paramAnonymousArrayOfInt[0], paramAnonymousArrayOfInt[1], paramAnonymousArrayOfInt[2], paramAnonymousArrayOfInt[3], paramAnonymousArrayOfInt[4]);
      }
      
      public int method4(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.GetDimensions(paramAnonymousArrayOfInt[0], paramAnonymousArrayOfInt[1], paramAnonymousArrayOfInt[2], paramAnonymousArrayOfInt[3], paramAnonymousArrayOfInt[4]);
      }
      
      public int method5(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.SetFocus();
      }
      
      public int method6(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.GetVisibility(paramAnonymousArrayOfInt[0]);
      }
      
      public int method7(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.SetVisibility(paramAnonymousArrayOfInt[0]);
      }
      
      public int method8(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.GetTitle(paramAnonymousArrayOfInt[0]);
      }
      
      public int method9(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.SetTitle(paramAnonymousArrayOfInt[0]);
      }
      
      public int method10(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.GetSiteWindow(paramAnonymousArrayOfInt[0]);
      }
      
      public int method11(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.Blur();
      }
    };
    this.interfaceRequestor = new XPCOMObject(new int[] { 2, 0, 0, 2 })
    {
      public int method0(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.QueryInterface(paramAnonymousArrayOfInt[0], paramAnonymousArrayOfInt[1]);
      }
      
      public int method1(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.AddRef();
      }
      
      public int method2(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.Release();
      }
      
      public int method3(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.GetInterface(paramAnonymousArrayOfInt[0], paramAnonymousArrayOfInt[1]);
      }
    };
    this.supportsWeakReference = new XPCOMObject(new int[] { 2, 0, 0, 1 })
    {
      public int method0(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.QueryInterface(paramAnonymousArrayOfInt[0], paramAnonymousArrayOfInt[1]);
      }
      
      public int method1(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.AddRef();
      }
      
      public int method2(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.Release();
      }
      
      public int method3(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.GetWeakReference(paramAnonymousArrayOfInt[0]);
      }
    };
    this.contextMenuListener = new XPCOMObject(new int[] { 2, 0, 0, 3 })
    {
      public int method0(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.QueryInterface(paramAnonymousArrayOfInt[0], paramAnonymousArrayOfInt[1]);
      }
      
      public int method1(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.AddRef();
      }
      
      public int method2(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.Release();
      }
      
      public int method3(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.OnShowContextMenu(paramAnonymousArrayOfInt[0], paramAnonymousArrayOfInt[1], paramAnonymousArrayOfInt[2]);
      }
    };
    this.uriContentListener = new XPCOMObject(new int[] { 2, 0, 0, 2, 5, 3, 4, 1, 1, 1, 1 })
    {
      public int method0(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.QueryInterface(paramAnonymousArrayOfInt[0], paramAnonymousArrayOfInt[1]);
      }
      
      public int method1(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.AddRef();
      }
      
      public int method2(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.Release();
      }
      
      public int method3(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.OnStartURIOpen(paramAnonymousArrayOfInt[0], paramAnonymousArrayOfInt[1]);
      }
      
      public int method4(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.DoContent(paramAnonymousArrayOfInt[0], paramAnonymousArrayOfInt[1], paramAnonymousArrayOfInt[2], paramAnonymousArrayOfInt[3], paramAnonymousArrayOfInt[4]);
      }
      
      public int method5(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.IsPreferred(paramAnonymousArrayOfInt[0], paramAnonymousArrayOfInt[1], paramAnonymousArrayOfInt[2]);
      }
      
      public int method6(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.CanHandleContent(paramAnonymousArrayOfInt[0], paramAnonymousArrayOfInt[1], paramAnonymousArrayOfInt[2], paramAnonymousArrayOfInt[3]);
      }
      
      public int method7(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.GetLoadCookie(paramAnonymousArrayOfInt[0]);
      }
      
      public int method8(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.SetLoadCookie(paramAnonymousArrayOfInt[0]);
      }
      
      public int method9(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.GetParentContentListener(paramAnonymousArrayOfInt[0]);
      }
      
      public int method10(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.SetParentContentListener(paramAnonymousArrayOfInt[0]);
      }
    };
    this.tooltipListener = new XPCOMObject(new int[] { 2, 0, 0, 3, 0 })
    {
      public int method0(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.QueryInterface(paramAnonymousArrayOfInt[0], paramAnonymousArrayOfInt[1]);
      }
      
      public int method1(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.AddRef();
      }
      
      public int method2(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.Release();
      }
      
      public int method3(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.OnShowTooltip(paramAnonymousArrayOfInt[0], paramAnonymousArrayOfInt[1], paramAnonymousArrayOfInt[2]);
      }
      
      public int method4(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.OnHideTooltip();
      }
    };
    this.domEventListener = new XPCOMObject(new int[] { 2, 0, 0, 1 })
    {
      public int method0(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.QueryInterface(paramAnonymousArrayOfInt[0], paramAnonymousArrayOfInt[1]);
      }
      
      public int method1(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.AddRef();
      }
      
      public int method2(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.Release();
      }
      
      public int method3(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.HandleEvent(paramAnonymousArrayOfInt[0]);
      }
    };
    this.badCertListener = new XPCOMObject(new int[] { 2, 0, 0, 4 })
    {
      public int method0(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.QueryInterface(paramAnonymousArrayOfInt[0], paramAnonymousArrayOfInt[1]);
      }
      
      public int method1(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.AddRef();
      }
      
      public int method2(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.Release();
      }
      
      public int method3(int[] paramAnonymousArrayOfInt)
      {
        return Mozilla.this.NotifyCertProblem(paramAnonymousArrayOfInt[0], paramAnonymousArrayOfInt[1], paramAnonymousArrayOfInt[2], paramAnonymousArrayOfInt[3]);
      }
    };
  }
  
  void deregisterFunction(BrowserFunction paramBrowserFunction)
  {
    super.deregisterFunction(paramBrowserFunction);
    AllFunctions.remove(new Integer(paramBrowserFunction.index));
  }
  
  void disposeCOMInterfaces()
  {
    if (this.supports != null)
    {
      this.supports.dispose();
      this.supports = null;
    }
    if (this.weakReference != null)
    {
      this.weakReference.dispose();
      this.weakReference = null;
    }
    if (this.webProgressListener != null)
    {
      this.webProgressListener.dispose();
      this.webProgressListener = null;
    }
    if (this.webProgressListener_24 != null)
    {
      this.webProgressListener_24.dispose();
      this.webProgressListener_24 = null;
    }
    if (this.webBrowserChrome != null)
    {
      this.webBrowserChrome.dispose();
      this.webBrowserChrome = null;
    }
    if (this.webBrowserChromeFocus != null)
    {
      this.webBrowserChromeFocus.dispose();
      this.webBrowserChromeFocus = null;
    }
    if (this.embeddingSiteWindow != null)
    {
      this.embeddingSiteWindow.dispose();
      this.embeddingSiteWindow = null;
    }
    if (this.embeddingSiteWindow_24 != null)
    {
      this.embeddingSiteWindow_24.dispose();
      this.embeddingSiteWindow_24 = null;
    }
    if (this.interfaceRequestor != null)
    {
      this.interfaceRequestor.dispose();
      this.interfaceRequestor = null;
    }
    if (this.supportsWeakReference != null)
    {
      this.supportsWeakReference.dispose();
      this.supportsWeakReference = null;
    }
    if (this.contextMenuListener != null)
    {
      this.contextMenuListener.dispose();
      this.contextMenuListener = null;
    }
    if (this.uriContentListener != null)
    {
      this.uriContentListener.dispose();
      this.uriContentListener = null;
    }
    if (this.tooltipListener != null)
    {
      this.tooltipListener.dispose();
      this.tooltipListener = null;
    }
    if (this.domEventListener != null)
    {
      this.domEventListener.dispose();
      this.domEventListener = null;
    }
    if (this.badCertListener != null)
    {
      this.badCertListener.dispose();
      this.badCertListener = null;
    }
  }
  
  public boolean execute(String paramString)
  {
    this.delegate.removeWindowSubclass();
    int[] arrayOfInt = new int[1];
    if (MozillaVersion.CheckVersion(2))
    {
      int i = XPCOM.NS_GetServiceManager(arrayOfInt);
      if (i != 0) {
        error(i);
      }
      if (arrayOfInt[0] == 0) {
        error(-2147467262);
      }
      nsIServiceManager localnsIServiceManager = new nsIServiceManager(arrayOfInt[0]);
      arrayOfInt[0] = 0;
      localObject1 = MozillaDelegate.wcsToMbcs(null, "@mozilla.org/scriptsecuritymanager;1", true);
      i = localnsIServiceManager.GetServiceByContractID((byte[])localObject1, IIDStore.GetIID(nsIScriptSecurityManager.class), arrayOfInt);
      if ((i == 0) && (arrayOfInt[0] != 0))
      {
        localObject2 = new nsIScriptSecurityManager(arrayOfInt[0]);
        arrayOfInt[0] = 0;
        i = ((nsIScriptSecurityManager)localObject2).GetSystemPrincipal(arrayOfInt);
        ((nsIScriptSecurityManager)localObject2).Release();
        if ((i == 0) && (arrayOfInt[0] != 0))
        {
          localObject3 = new nsIPrincipal(arrayOfInt[0]);
          arrayOfInt[0] = 0;
          i = this.webBrowser.QueryInterface(IIDStore.GetIID(nsIInterfaceRequestor.class), arrayOfInt);
          if (i != 0) {
            error(i);
          }
          if (arrayOfInt[0] == 0) {
            error(-2147467262);
          }
          nsIInterfaceRequestor localnsIInterfaceRequestor = new nsIInterfaceRequestor(arrayOfInt[0]);
          arrayOfInt[0] = 0;
          i = localnsIInterfaceRequestor.GetInterface(IIDStore.GetIID(nsIScriptGlobalObject.class), arrayOfInt);
          localnsIInterfaceRequestor.Release();
          if ((i == 0) && (arrayOfInt[0] != 0))
          {
            int k = arrayOfInt[0];
            arrayOfInt[0] = 0;
            if (MozillaVersion.CheckVersion(6)) {
              i = XPCOM.nsIScriptGlobalObject24_EnsureScriptEnvironment(k);
            } else {
              i = XPCOM.nsIScriptGlobalObject_EnsureScriptEnvironment(k, 2);
            }
            if (i != 0)
            {
              new nsISupports(k).Release();
            }
            else
            {
              int m;
              if (MozillaVersion.CheckVersion(6)) {
                m = XPCOM.nsIScriptGlobalObject24_GetScriptContext(k);
              } else {
                m = XPCOM.nsIScriptGlobalObject_GetScriptContext(k, 2);
              }
              if (m != 0)
              {
                nsISupports localnsISupports = new nsISupports(m);
                i = localnsISupports.QueryInterface(IIDStore.GetIID(nsIScriptContext.class), arrayOfInt);
                if ((i == 0) && (arrayOfInt[0] != 0))
                {
                  new nsISupports(arrayOfInt[0]).Release();
                  arrayOfInt[0] = 0;
                  int n;
                  if (MozillaVersion.CheckVersion(6)) {
                    n = XPCOM.nsIScriptContext24_GetNativeContext(m);
                  } else {
                    n = XPCOM.nsIScriptContext_GetNativeContext(m);
                  }
                  if (n != 0)
                  {
                    int i1 = paramString.length();
                    char[] arrayOfChar = new char[i1];
                    paramString.getChars(0, i1, arrayOfChar, 0);
                    byte[] arrayOfByte1 = MozillaDelegate.wcsToMbcs(null, getUrl(), true);
                    i = ((nsIPrincipal)localObject3).GetJSPrincipals(n, arrayOfInt);
                    int i2 = 0;
                    if ((i == 0) && (arrayOfInt[0] != 0))
                    {
                      i2 = arrayOfInt[0];
                      arrayOfInt[0] = 0;
                    }
                    byte[] arrayOfByte2 = getJSLibPathBytes();
                    int i3;
                    if (MozillaVersion.CheckVersion(6)) {
                      i3 = XPCOM.nsIScriptGlobalObject24_GetGlobalJSObject(k);
                    } else {
                      i3 = XPCOM.JS_GetGlobalObject(arrayOfByte2, n);
                    }
                    if (i3 != 0)
                    {
                      if (MozillaVersion.CheckVersion(6))
                      {
                        boolean bool1 = XPCOM.JS_EvaluateUCScriptForPrincipals24(arrayOfByte2, n, i3, i2, arrayOfChar, i1, arrayOfByte1, 0, 0) != 0;
                        new nsISupports(k).Release();
                        ((nsIPrincipal)localObject3).Release();
                        localnsIServiceManager.Release();
                        return bool1;
                      }
                      localObject1 = MozillaDelegate.wcsToMbcs(null, "@mozilla.org/js/xpc/ContextStack;1", true);
                      i = localnsIServiceManager.GetServiceByContractID((byte[])localObject1, IIDStore.GetIID(nsIJSContextStack.class), arrayOfInt);
                      if ((i == 0) && (arrayOfInt[0] != 0))
                      {
                        nsIJSContextStack localnsIJSContextStack = new nsIJSContextStack(arrayOfInt[0]);
                        arrayOfInt[0] = 0;
                        i = localnsIJSContextStack.Push(n);
                        if (i != 0)
                        {
                          localnsIJSContextStack.Release();
                        }
                        else
                        {
                          boolean bool2;
                          if (MozillaVersion.CheckVersion(2, true)) {
                            bool2 = XPCOM.JS_EvaluateUCScriptForPrincipals(arrayOfByte2, n, i3, i2, arrayOfChar, i1, arrayOfByte1, 0, arrayOfInt) != 0;
                          } else {
                            bool2 = XPCOM.JS_EvaluateUCScriptForPrincipals191(arrayOfByte2, n, i3, i2, arrayOfChar, i1, arrayOfByte1, 0, 0) != 0;
                          }
                          arrayOfInt[0] = 0;
                          i = localnsIJSContextStack.Pop(arrayOfInt);
                          localnsIJSContextStack.Release();
                          new nsISupports(k).Release();
                          ((nsIPrincipal)localObject3).Release();
                          localnsIServiceManager.Release();
                          return bool2;
                        }
                      }
                    }
                  }
                }
              }
            }
            new nsISupports(k).Release();
          }
          ((nsIPrincipal)localObject3).Release();
        }
      }
      localnsIServiceManager.Release();
    }
    String str = "javascript:" + paramString + ";void(0);";
    int j = this.webBrowser.QueryInterface(IIDStore.GetIID(nsIWebNavigation.class), arrayOfInt);
    if (j != 0) {
      error(j);
    }
    if (arrayOfInt[0] == 0) {
      error(-2147467262);
    }
    Object localObject1 = new nsIWebNavigation(arrayOfInt[0]);
    Object localObject2 = str.toCharArray();
    Object localObject3 = new char[localObject2.length + 1];
    System.arraycopy(localObject2, 0, localObject3, 0, localObject2.length);
    j = ((nsIWebNavigation)localObject1).LoadURI((char[])localObject3, 0, 0, 0, 0);
    ((nsIWebNavigation)localObject1).Release();
    return j == 0;
  }
  
  static Browser findBrowser(int paramInt)
  {
    return MozillaDelegate.findBrowser(paramInt);
  }
  
  static Browser getBrowser(int paramInt)
  {
    int[] arrayOfInt = new int[1];
    int i = XPCOM.NS_GetServiceManager(arrayOfInt);
    if (i != 0) {
      error(i);
    }
    if (arrayOfInt[0] == 0) {
      error(-2147467262);
    }
    nsIServiceManager localnsIServiceManager = new nsIServiceManager(arrayOfInt[0]);
    arrayOfInt[0] = 0;
    byte[] arrayOfByte = MozillaDelegate.wcsToMbcs(null, "@mozilla.org/embedcomp/window-watcher;1", true);
    i = localnsIServiceManager.GetServiceByContractID(arrayOfByte, IIDStore.GetIID(nsIWindowWatcher.class), arrayOfInt);
    if (i != 0) {
      error(i);
    }
    if (arrayOfInt[0] == 0) {
      error(-2147467262);
    }
    localnsIServiceManager.Release();
    nsIWindowWatcher localnsIWindowWatcher = new nsIWindowWatcher(arrayOfInt[0]);
    arrayOfInt[0] = 0;
    nsIDOMWindow localnsIDOMWindow = new nsIDOMWindow(paramInt);
    i = localnsIDOMWindow.GetTop(arrayOfInt);
    if (i != 0) {
      error(i);
    }
    if (arrayOfInt[0] == 0) {
      error(-2147467262);
    }
    int j = arrayOfInt[0];
    arrayOfInt[0] = 0;
    i = localnsIWindowWatcher.GetChromeForWindow(j, arrayOfInt);
    if (i != 0) {
      error(i);
    }
    new nsISupports(j).Release();
    localnsIWindowWatcher.Release();
    if (arrayOfInt[0] == 0) {
      return null;
    }
    nsIWebBrowserChrome localnsIWebBrowserChrome = new nsIWebBrowserChrome(arrayOfInt[0]);
    arrayOfInt[0] = 0;
    i = localnsIWebBrowserChrome.QueryInterface(IIDStore.GetIID(nsIEmbeddingSiteWindow.class), arrayOfInt);
    if (i != 0) {
      error(i);
    }
    if (arrayOfInt[0] == 0) {
      error(-2147467262);
    }
    localnsIWebBrowserChrome.Release();
    nsIEmbeddingSiteWindow localnsIEmbeddingSiteWindow = new nsIEmbeddingSiteWindow(arrayOfInt[0]);
    arrayOfInt[0] = 0;
    IsGettingSiteWindow = true;
    i = localnsIEmbeddingSiteWindow.GetSiteWindow(arrayOfInt);
    IsGettingSiteWindow = false;
    if (i != 0) {
      error(i);
    }
    if (arrayOfInt[0] == 0) {
      error(-2147467262);
    }
    localnsIEmbeddingSiteWindow.Release();
    return findBrowser(arrayOfInt[0]);
  }
  
  public boolean forward()
  {
    this.htmlBytes = null;
    int[] arrayOfInt = new int[1];
    int i = this.webBrowser.QueryInterface(IIDStore.GetIID(nsIWebNavigation.class), arrayOfInt);
    if (i != 0) {
      error(i);
    }
    if (arrayOfInt[0] == 0) {
      error(-2147467262);
    }
    nsIWebNavigation localnsIWebNavigation = new nsIWebNavigation(arrayOfInt[0]);
    i = localnsIWebNavigation.GoForward();
    localnsIWebNavigation.Release();
    return i == 0;
  }
  
  public String getBrowserType()
  {
    return "mozilla";
  }
  
  static byte[] getJSLibPathBytes()
  {
    if (jsLibPathBytes == null)
    {
      String[] arrayOfString = { MozillaVersion.CheckVersion(5) ? MozillaDelegate.getJSLibraryNames() : MozillaDelegate.getJSLibraryName_Pre10() };
      for (int i = 0; i < arrayOfString.length; i++)
      {
        File localFile = new File(getMozillaPath(), arrayOfString[i]);
        if (localFile.exists())
        {
          String str = localFile.getAbsolutePath() + '\000';
          try
          {
            jsLibPathBytes = str.getBytes("UTF-8");
          }
          catch (UnsupportedEncodingException localUnsupportedEncodingException)
          {
            jsLibPathBytes = str.getBytes();
          }
        }
      }
    }
    return jsLibPathBytes;
  }
  
  static String getMozillaPath()
  {
    if (LocationProvider != null) {
      return LocationProvider.mozillaPath;
    }
    if (!Initialized) {
      return "";
    }
    int[] arrayOfInt = new int[1];
    int i = XPCOM.NS_GetServiceManager(arrayOfInt);
    if (i != 0) {
      error(i);
    }
    if (arrayOfInt[0] == 0) {
      error(-2147467262);
    }
    nsIServiceManager localnsIServiceManager = new nsIServiceManager(arrayOfInt[0]);
    arrayOfInt[0] = 0;
    byte[] arrayOfByte = MozillaDelegate.wcsToMbcs(null, "@mozilla.org/file/directory_service;1", true);
    i = localnsIServiceManager.GetServiceByContractID(arrayOfByte, XPCOM.NS_IDIRECTORYSERVICE_IID, arrayOfInt);
    if (i != 0) {
      error(i);
    }
    if (arrayOfInt[0] == 0) {
      error(-2147467262);
    }
    localnsIServiceManager.Release();
    nsISupports localnsISupports = new nsISupports(arrayOfInt[0]);
    arrayOfInt[0] = 0;
    i = localnsISupports.QueryInterface(IIDStore.GetIID(nsIProperties.class), arrayOfInt);
    if (i != 0) {
      error(i);
    }
    if (arrayOfInt[0] == 0) {
      error(-2147467262);
    }
    localnsISupports.Release();
    nsIProperties localnsIProperties = new nsIProperties(arrayOfInt[0]);
    arrayOfInt[0] = 0;
    arrayOfByte = MozillaDelegate.wcsToMbcs(null, "GreD", true);
    i = localnsIProperties.Get(arrayOfByte, IIDStore.GetIID(nsIFile.class), arrayOfInt);
    if (i != 0) {
      error(i);
    }
    if (arrayOfInt[0] == 0) {
      error(-2147467262);
    }
    localnsIProperties.Release();
    nsIFile localnsIFile = new nsIFile(arrayOfInt[0]);
    arrayOfInt[0] = 0;
    int j = XPCOM.nsEmbedString_new();
    i = localnsIFile.GetPath(j);
    if (i != 0) {
      error(i);
    }
    int k = XPCOM.nsEmbedString_Length(j);
    int m = XPCOM.nsEmbedString_get(j);
    char[] arrayOfChar = new char[k];
    XPCOM.memmove(arrayOfChar, m, k * 2);
    XPCOM.nsEmbedString_delete(j);
    localnsIFile.Release();
    return new String(arrayOfChar) + SEPARATOR_OS;
  }
  
  int getNextFunctionIndex()
  {
    return NextJSFunctionIndex++;
  }
  
  public String getText()
  {
    int[] arrayOfInt = new int[1];
    int i = this.webBrowser.GetContentDOMWindow(arrayOfInt);
    if (i != 0) {
      error(i);
    }
    if (arrayOfInt[0] == 0) {
      error(-2147467262);
    }
    nsIDOMWindow localnsIDOMWindow = new nsIDOMWindow(arrayOfInt[0]);
    arrayOfInt[0] = 0;
    i = localnsIDOMWindow.GetDocument(arrayOfInt);
    if (i != 0) {
      error(i);
    }
    if (arrayOfInt[0] == 0) {
      error(-2147467262);
    }
    localnsIDOMWindow.Release();
    int j = arrayOfInt[0];
    arrayOfInt[0] = 0;
    i = XPCOM.NS_GetComponentManager(arrayOfInt);
    if (i != 0) {
      error(i);
    }
    if (arrayOfInt[0] == 0) {
      error(-2147467262);
    }
    nsIComponentManager localnsIComponentManager = new nsIComponentManager(arrayOfInt[0]);
    arrayOfInt[0] = 0;
    byte[] arrayOfByte = MozillaDelegate.wcsToMbcs(null, "@mozilla.org/xmlextras/xmlserializer;1", true);
    char[] arrayOfChar = null;
    i = localnsIComponentManager.CreateInstanceByContractID(arrayOfByte, 0, IIDStore.GetIID(nsIDOMSerializer.class), arrayOfInt);
    if ((i == 0) && (arrayOfInt[0] != 0))
    {
      nsIDOMSerializer localnsIDOMSerializer = new nsIDOMSerializer(arrayOfInt[0]);
      arrayOfInt[0] = 0;
      int k;
      if (MozillaVersion.CheckVersion(1))
      {
        k = XPCOM.nsEmbedString_new();
        i = localnsIDOMSerializer.SerializeToString(j, k);
        if (i == 0)
        {
          int m = XPCOM.nsEmbedString_Length(k);
          int n = XPCOM.nsEmbedString_get(k);
          arrayOfChar = new char[m];
          XPCOM.memmove(arrayOfChar, n, m * 2);
        }
        XPCOM.nsEmbedString_delete(k);
      }
      else
      {
        i = localnsIDOMSerializer.SerializeToString(j, arrayOfInt);
        if (i == 0)
        {
          k = XPCOM.strlen_PRUnichar(arrayOfInt[0]);
          arrayOfChar = new char[k];
          XPCOM.memmove(arrayOfChar, arrayOfInt[0], k * 2);
        }
      }
      localnsIDOMSerializer.Release();
    }
    localnsIComponentManager.Release();
    new nsISupports(j).Release();
    return new String(arrayOfChar);
  }
  
  public String getUrl()
  {
    int[] arrayOfInt1 = new int[1];
    int i = this.webBrowser.QueryInterface(IIDStore.GetIID(nsIWebNavigation.class), arrayOfInt1);
    if (i != 0) {
      error(i);
    }
    if (arrayOfInt1[0] == 0) {
      error(-2147467262);
    }
    nsIWebNavigation localnsIWebNavigation = new nsIWebNavigation(arrayOfInt1[0]);
    int[] arrayOfInt2 = new int[1];
    i = localnsIWebNavigation.GetCurrentURI(arrayOfInt2);
    if (i != 0) {
      error(i);
    }
    localnsIWebNavigation.Release();
    byte[] arrayOfByte = null;
    int j;
    if (arrayOfInt2[0] != 0)
    {
      localObject = new nsIURI(arrayOfInt2[0]);
      j = XPCOM.nsEmbedCString_new();
      i = ((nsIURI)localObject).GetSpec(j);
      if (i != 0) {
        error(i);
      }
      int k = XPCOM.nsEmbedCString_Length(j);
      int m = XPCOM.nsEmbedCString_get(j);
      arrayOfByte = new byte[k];
      XPCOM.memmove(arrayOfByte, m, k);
      XPCOM.nsEmbedCString_delete(j);
      ((nsIURI)localObject).Release();
    }
    if (arrayOfByte == null) {
      return "";
    }
    Object localObject = new String(arrayOfByte);
    if (((String)localObject).equals("file:///"))
    {
      localObject = "about:blank";
    }
    else
    {
      j = "file:///".length();
      if ((((String)localObject).startsWith("file:///")) && (((String)localObject).charAt(j) == '#')) {
        localObject = "about:blank" + ((String)localObject).substring(j);
      }
    }
    return (String)localObject;
  }
  
  public Object getWebBrowser()
  {
    if ((this.browser.getStyle() & 0x8000) == 0) {
      return null;
    }
    if (this.webBrowserObject != null) {
      return this.webBrowserObject;
    }
    try
    {
      Class localClass = Class.forName("org.mozilla.xpcom.Mozilla");
      Method localMethod = localClass.getMethod("getInstance", new Class[0]);
      Object localObject = localMethod.invoke(null, new Object[0]);
      localMethod = localClass.getMethod("wrapXPCOMObject", new Class[] { Long.TYPE, String.class });
      this.webBrowserObject = localMethod.invoke(localObject, new Object[] { new Long(this.webBrowser.getAddress()), IIDStore.GetIID(nsIWebBrowser.class).toString() });
      this.webBrowser.AddRef();
      return this.webBrowserObject;
    }
    catch (ClassNotFoundException localClassNotFoundException) {}catch (NoSuchMethodException localNoSuchMethodException) {}catch (IllegalArgumentException localIllegalArgumentException) {}catch (IllegalAccessException localIllegalAccessException) {}catch (InvocationTargetException localInvocationTargetException) {}
    return null;
  }
  
  static String InitDiscoverXULRunner()
  {
    GREVersionRange localGREVersionRange = new GREVersionRange();
    byte[] arrayOfByte = MozillaDelegate.wcsToMbcs(null, "1.8.1.2", true);
    int i = C.malloc(arrayOfByte.length);
    C.memmove(i, arrayOfByte, arrayOfByte.length);
    localGREVersionRange.lower = i;
    localGREVersionRange.lowerInclusive = true;
    arrayOfByte = MozillaDelegate.wcsToMbcs(null, "1.9.*", true);
    int j = C.malloc(arrayOfByte.length);
    C.memmove(j, arrayOfByte, arrayOfByte.length);
    localGREVersionRange.upper = j;
    localGREVersionRange.upperInclusive = true;
    GREProperty localGREProperty = new GREProperty();
    arrayOfByte = MozillaDelegate.wcsToMbcs(null, "abi", true);
    int k = C.malloc(arrayOfByte.length);
    C.memmove(k, arrayOfByte, arrayOfByte.length);
    localGREProperty.property = k;
    arrayOfByte = MozillaDelegate.wcsToMbcs(null, Arch() + "-gcc3", true);
    int m = C.malloc(arrayOfByte.length);
    C.memmove(m, arrayOfByte, arrayOfByte.length);
    localGREProperty.value = m;
    int n = 4096;
    int i1 = C.malloc(n);
    int i2 = XPCOMInit.GRE_GetGREPathWithProperties(localGREVersionRange, 1, localGREProperty, 1, i1, n);
    if (i2 != 0)
    {
      i2 = XPCOMInit.GRE_GetGREPathWithProperties(localGREVersionRange, 1, localGREProperty, 0, i1, n);
      if (i2 != 0)
      {
        C.free(i);
        arrayOfByte = MozillaDelegate.wcsToMbcs(null, "1.8", true);
        i = C.malloc(arrayOfByte.length);
        C.memmove(i, arrayOfByte, arrayOfByte.length);
        localGREVersionRange.lower = i;
        i2 = XPCOMInit.GRE_GetGREPathWithProperties(localGREVersionRange, 1, localGREProperty, 0, i1, n);
      }
    }
    C.free(m);
    C.free(k);
    C.free(i);
    C.free(j);
    String str = null;
    if (i2 == 0)
    {
      n = C.strlen(i1);
      arrayOfByte = new byte[n];
      C.memmove(arrayOfByte, i1, n);
      str = new String(MozillaDelegate.mbcsToWcs(null, arrayOfByte));
    }
    else
    {
      str = "";
    }
    C.free(i1);
    return str;
  }
  
  void initExternal(String paramString)
  {
    File localFile1 = new File(paramString, "components");
    java.io.InputStream localInputStream = Library.class.getResourceAsStream("/external.xpt");
    if (localInputStream != null)
    {
      if (!localFile1.exists()) {
        localFile1.mkdirs();
      }
      byte[] arrayOfByte = new byte['က'];
      File localFile2 = new File(localFile1, "external.xpt");
      try
      {
        FileOutputStream localFileOutputStream = new FileOutputStream(localFile2);
        int i;
        while ((i = localInputStream.read(arrayOfByte)) != -1) {
          localFileOutputStream.write(arrayOfByte, 0, i);
        }
        localFileOutputStream.close();
        localInputStream.close();
      }
      catch (FileNotFoundException localFileNotFoundException) {}catch (IOException localIOException) {}
    }
  }
  
  void initFactories(nsIServiceManager paramnsIServiceManager, nsIComponentManager paramnsIComponentManager, boolean paramBoolean)
  {
    int[] arrayOfInt = new int[1];
    int i = paramnsIComponentManager.QueryInterface(IIDStore.GetIID(nsIComponentRegistrar.class), arrayOfInt);
    if (i != 0)
    {
      this.browser.dispose();
      error(i);
    }
    if (arrayOfInt[0] == 0)
    {
      this.browser.dispose();
      error(-2147467262);
    }
    nsIComponentRegistrar localnsIComponentRegistrar = new nsIComponentRegistrar(arrayOfInt[0]);
    arrayOfInt[0] = 0;
    if (!MozillaVersion.CheckVersion(6)) {
      localnsIComponentRegistrar.AutoRegister(0);
    }
    PromptService2Factory localPromptService2Factory = new PromptService2Factory();
    localPromptService2Factory.AddRef();
    byte[] arrayOfByte1 = MozillaDelegate.wcsToMbcs(null, "@mozilla.org/embedcomp/prompt-service;1", true);
    byte[] arrayOfByte2 = MozillaDelegate.wcsToMbcs(null, "swtPromptService", true);
    i = localnsIComponentRegistrar.RegisterFactory(XPCOM.NS_PROMPTSERVICE_CID, arrayOfByte2, arrayOfByte1, localPromptService2Factory.getAddress());
    if (i != 0)
    {
      this.browser.dispose();
      error(i);
    }
    if (MozillaVersion.CheckVersion(5))
    {
      arrayOfByte1 = MozillaDelegate.wcsToMbcs(null, "@mozilla.org/prompter;1", true);
      arrayOfByte2 = MozillaDelegate.wcsToMbcs(null, "swtPrompter", true);
      i = localnsIComponentRegistrar.RegisterFactory(XPCOM.NS_PROMPTER_CID, arrayOfByte2, arrayOfByte1, localPromptService2Factory.getAddress());
      if (i != 0)
      {
        this.browser.dispose();
        error(i);
      }
      arrayOfByte1 = MozillaDelegate.wcsToMbcs(null, "@mozilla.org/passwordmanager/authpromptfactory;1", true);
      arrayOfByte2 = MozillaDelegate.wcsToMbcs(null, "swtAuthPrompter", true);
      i = localnsIComponentRegistrar.RegisterFactory(XPCOM.NS_AUTHPROMPTER_CID, arrayOfByte2, arrayOfByte1, localPromptService2Factory.getAddress());
      if (i != 0)
      {
        this.browser.dispose();
        error(i);
      }
    }
    localPromptService2Factory.Release();
    ExternalFactory localExternalFactory = new ExternalFactory();
    localExternalFactory.AddRef();
    arrayOfByte1 = MozillaDelegate.wcsToMbcs(null, "@eclipse.org/external;1", true);
    arrayOfByte2 = MozillaDelegate.wcsToMbcs(null, "External", true);
    i = localnsIComponentRegistrar.RegisterFactory(XPCOM.EXTERNAL_CID, arrayOfByte2, arrayOfByte1, localExternalFactory.getAddress());
    if (i != 0)
    {
      this.browser.dispose();
      error(i);
    }
    localExternalFactory.Release();
    i = paramnsIServiceManager.GetService(XPCOM.NS_CATEGORYMANAGER_CID, IIDStore.GetIID(nsICategoryManager.class), arrayOfInt);
    if (i != 0) {
      error(i);
    }
    if (arrayOfInt[0] == 0) {
      error(-2147467262);
    }
    nsICategoryManager localnsICategoryManager = new nsICategoryManager(arrayOfInt[0]);
    arrayOfInt[0] = 0;
    byte[] arrayOfByte3 = MozillaDelegate.wcsToMbcs(null, "external", true);
    byte[] arrayOfByte4 = MozillaDelegate.wcsToMbcs(null, "JavaScript global property", true);
    i = localnsICategoryManager.AddCategoryEntry(arrayOfByte4, arrayOfByte3, arrayOfByte1, 0, 1, arrayOfInt);
    arrayOfInt[0] = 0;
    arrayOfByte4 = MozillaDelegate.wcsToMbcs(null, "JavaScript-global-property", true);
    i = localnsICategoryManager.AddCategoryEntry(arrayOfByte4, arrayOfByte3, arrayOfByte1, 0, 1, arrayOfInt);
    arrayOfInt[0] = 0;
    localnsICategoryManager.Release();
    Object localObject;
    if (!MozillaVersion.CheckVersion(5))
    {
      localObject = new DownloadFactory();
      ((DownloadFactory)localObject).AddRef();
      arrayOfByte1 = MozillaDelegate.wcsToMbcs(null, "@mozilla.org/download;1", true);
      arrayOfByte2 = MozillaDelegate.wcsToMbcs(null, "swtDownload", true);
      i = localnsIComponentRegistrar.RegisterFactory(XPCOM.NS_DOWNLOAD_CID, arrayOfByte2, arrayOfByte1, ((DownloadFactory)localObject).getAddress());
      if (i != 0)
      {
        this.browser.dispose();
        error(i);
      }
      ((DownloadFactory)localObject).Release();
    }
    if (!MozillaVersion.CheckVersion(6))
    {
      localObject = new FilePickerFactory();
      ((FilePickerFactory)localObject).AddRef();
      arrayOfByte1 = MozillaDelegate.wcsToMbcs(null, "@mozilla.org/filepicker;1", true);
      arrayOfByte2 = MozillaDelegate.wcsToMbcs(null, "swtFilePicker", true);
      i = localnsIComponentRegistrar.RegisterFactory(XPCOM.NS_FILEPICKER_CID, arrayOfByte2, arrayOfByte1, ((FilePickerFactory)localObject).getAddress());
      ((FilePickerFactory)localObject).Release();
    }
    localnsIComponentRegistrar.Release();
  }
  
  void initJavaXPCOM(String paramString)
  {
    try
    {
      Class localClass1 = Class.forName("org.mozilla.xpcom.Mozilla");
      Method localMethod = localClass1.getMethod("getInstance", new Class[0]);
      Object localObject1 = localMethod.invoke(null, new Object[0]);
      localMethod = localClass1.getMethod("getComponentManager", new Class[0]);
      try
      {
        localMethod.invoke(localObject1, new Object[0]);
      }
      catch (InvocationTargetException localInvocationTargetException2)
      {
        Class localClass2 = Class.forName("java.io.File");
        localMethod = localClass1.getMethod("initialize", new Class[] { localClass2 });
        Constructor localConstructor = localClass2.getDeclaredConstructor(new Class[] { String.class });
        Object localObject2 = localConstructor.newInstance(new Object[] { paramString });
        localMethod.invoke(localObject1, new Object[] { localObject2 });
      }
    }
    catch (ClassNotFoundException localClassNotFoundException) {}catch (NoSuchMethodException localNoSuchMethodException) {}catch (IllegalArgumentException localIllegalArgumentException) {}catch (IllegalAccessException localIllegalAccessException) {}catch (InvocationTargetException localInvocationTargetException1) {}catch (InstantiationException localInstantiationException) {}
  }
  
  String initMozilla(String paramString)
  {
    int i = C.getenv(MozillaDelegate.wcsToMbcs(null, "MOZILLA_FIVE_HOME", true));
    if (i != 0)
    {
      int j = C.strlen(i);
      byte[] arrayOfByte = new byte[j];
      C.memmove(arrayOfByte, i, j);
      paramString = new String(MozillaDelegate.mbcsToWcs(null, arrayOfByte));
      if (SEPARATOR_OS == '/') {
        paramString = paramString.replace('\\', SEPARATOR_OS);
      } else {
        paramString = paramString.replace('/', SEPARATOR_OS);
      }
    }
    else
    {
      this.browser.dispose();
      SWT.error(2, null, " [Unknown Mozilla path (MOZILLA_FIVE_HOME not set)]");
    }
    if (Device.DEBUG) {
      System.out.println("Mozilla path: " + paramString);
    }
    if (Compatibility.fileExists(paramString, "components/libwidget_gtk.so"))
    {
      this.browser.dispose();
      SWT.error(2, null, " [Mozilla GTK2 required (GTK1.2 detected)]");
    }
    try
    {
      Library.loadLibrary("swt-mozilla");
    }
    catch (UnsatisfiedLinkError localUnsatisfiedLinkError1)
    {
      try
      {
        Library.loadLibrary("swt-mozilla-gcc3");
      }
      catch (UnsatisfiedLinkError localUnsatisfiedLinkError2)
      {
        this.browser.dispose();
        SWT.error(2, localUnsatisfiedLinkError1, " [MOZILLA_FIVE_HOME='" + paramString + "']");
      }
    }
    return paramString;
  }
  
  void initXPCOM(String paramString, boolean paramBoolean)
  {
    int[] arrayOfInt = new int[1];
    nsEmbedString localnsEmbedString = new nsEmbedString(paramString);
    int i = XPCOM.NS_NewLocalFile(localnsEmbedString.getAddress(), 1, arrayOfInt);
    localnsEmbedString.dispose();
    if (i != 0)
    {
      this.browser.dispose();
      error(i);
    }
    if (arrayOfInt[0] == 0)
    {
      this.browser.dispose();
      error(-2147467261);
    }
    nsIFile localnsIFile = new nsIFile(arrayOfInt[0]);
    arrayOfInt[0] = 0;
    if (paramBoolean)
    {
      int j = XPCOM.nsDynamicFunctionLoad_sizeof();
      int k = C.malloc(j * 2);
      C.memset(k, 0, j * 2);
      nsDynamicFunctionLoad localnsDynamicFunctionLoad = new nsDynamicFunctionLoad();
      byte[] arrayOfByte = MozillaDelegate.wcsToMbcs(null, "XRE_InitEmbedding2", true);
      localnsDynamicFunctionLoad.functionName = C.malloc(arrayOfByte.length);
      C.memmove(localnsDynamicFunctionLoad.functionName, arrayOfByte, arrayOfByte.length);
      localnsDynamicFunctionLoad.function = C.malloc(C.PTR_SIZEOF);
      C.memmove(localnsDynamicFunctionLoad.function, new int[] { 0 }, C.PTR_SIZEOF);
      XPCOM.memmove(k, localnsDynamicFunctionLoad, XPCOM.nsDynamicFunctionLoad_sizeof());
      i = XPCOM.XPCOMGlueLoadXULFunctions(k);
      if (i == 0)
      {
        arrayOfInt[0] = 0;
        i = localnsIFile.QueryInterface(IIDStore.GetIID(nsIFile.class, 6, true), arrayOfInt);
        if (i == 0)
        {
          MozillaVersion.SetCurrentVersion(6);
        }
        else
        {
          i = localnsIFile.QueryInterface(IIDStore.GetIID(nsILocalFile.class, 5), arrayOfInt);
          if (i != 0)
          {
            this.browser.dispose();
            error(i);
          }
          MozillaVersion.SetCurrentVersion(5);
        }
        if (arrayOfInt[0] != 0) {
          new nsISupports(arrayOfInt[0]).Release();
        }
        arrayOfInt[0] = 0;
      }
      else
      {
        C.free(localnsDynamicFunctionLoad.functionName);
        arrayOfByte = MozillaDelegate.wcsToMbcs(null, "XRE_InitEmbedding", true);
        localnsDynamicFunctionLoad.functionName = C.malloc(arrayOfByte.length);
        C.memmove(localnsDynamicFunctionLoad.functionName, arrayOfByte, arrayOfByte.length);
        XPCOM.memmove(k, localnsDynamicFunctionLoad, XPCOM.nsDynamicFunctionLoad_sizeof());
        i = XPCOM.XPCOMGlueLoadXULFunctions(k);
        MozillaVersion.SetCurrentVersion(4);
      }
      C.memmove(arrayOfInt, localnsDynamicFunctionLoad.function, C.PTR_SIZEOF);
      int m = arrayOfInt[0];
      arrayOfInt[0] = 0;
      C.free(localnsDynamicFunctionLoad.function);
      C.free(localnsDynamicFunctionLoad.functionName);
      C.free(k);
      if (m == 0)
      {
        this.browser.dispose();
        error(-2147467261);
      }
      if (MozillaVersion.CheckVersion(6, true)) {
        Library.loadLibrary("swt-xulrunner24");
      }
      MozillaDelegate.loadAdditionalLibraries(paramString, true);
      if (MozillaVersion.CheckVersion(5)) {
        i = XPCOM.Call(m, localnsIFile.getAddress(), localnsIFile.getAddress(), LocationProvider.getAddress());
      } else {
        i = XPCOM.Call(m, localnsIFile.getAddress(), localnsIFile.getAddress(), LocationProvider.getAddress(), 0, 0);
      }
      if (i == 0) {
        System.setProperty("org.eclipse.swt.browser.XULRunnerPath", paramString);
      }
    }
    else
    {
      MozillaVersion.SetCurrentVersion(4);
      i = XPCOM.NS_InitXPCOM2(0, localnsIFile.getAddress(), LocationProvider.getAddress());
    }
    localnsIFile.Release();
    if (i != 0)
    {
      this.browser.dispose();
      SWT.error(2, null, " [MOZILLA_FIVE_HOME may not point at an embeddable GRE] [NS_InitEmbedding " + paramString + " error " + i + "]");
    }
    System.setProperty("org.eclipse.swt.browser.XULRunnerInitialized", "true");
  }
  
  void initPreferences(nsIServiceManager paramnsIServiceManager, nsIComponentManager paramnsIComponentManager)
  {
    int[] arrayOfInt = new int[1];
    byte[] arrayOfByte1 = MozillaDelegate.wcsToMbcs(null, "@mozilla.org/preferences-service;1", true);
    int i = paramnsIServiceManager.GetServiceByContractID(arrayOfByte1, IIDStore.GetIID(nsIPrefService.class), arrayOfInt);
    if (i != 0)
    {
      this.browser.dispose();
      error(i);
    }
    if (arrayOfInt[0] == 0)
    {
      this.browser.dispose();
      error(-2147467262);
    }
    nsIPrefService localnsIPrefService = new nsIPrefService(arrayOfInt[0]);
    arrayOfInt[0] = 0;
    byte[] arrayOfByte2 = new byte[1];
    i = localnsIPrefService.GetBranch(arrayOfByte2, arrayOfInt);
    localnsIPrefService.Release();
    if (i != 0)
    {
      this.browser.dispose();
      error(i);
    }
    if (arrayOfInt[0] == 0)
    {
      this.browser.dispose();
      error(-2147467262);
    }
    nsIPrefBranch localnsIPrefBranch = new nsIPrefBranch(arrayOfInt[0]);
    arrayOfInt[0] = 0;
    String str1 = null;
    nsIPrefLocalizedString localnsIPrefLocalizedString1 = null;
    arrayOfByte2 = MozillaDelegate.wcsToMbcs(null, "intl.accept_languages", true);
    i = localnsIPrefBranch.GetComplexValue(arrayOfByte2, IIDStore.GetIID(nsIPrefLocalizedString.class), arrayOfInt);
    if (i != 0)
    {
      str1 = "en-us,en,";
    }
    else
    {
      if (arrayOfInt[0] == 0)
      {
        this.browser.dispose();
        error(-2147467262);
      }
      localnsIPrefLocalizedString1 = new nsIPrefLocalizedString(arrayOfInt[0]);
      arrayOfInt[0] = 0;
      i = localnsIPrefLocalizedString1.ToString(arrayOfInt);
      if (i != 0)
      {
        this.browser.dispose();
        error(i);
      }
      if (arrayOfInt[0] == 0)
      {
        this.browser.dispose();
        error(-2147467262);
      }
      int j = XPCOM.strlen_PRUnichar(arrayOfInt[0]);
      localObject1 = new char[j];
      XPCOM.memmove((char[])localObject1, arrayOfInt[0], j * 2);
      str1 = new String((char[])localObject1) + ",";
    }
    arrayOfInt[0] = 0;
    Locale localLocale = Locale.getDefault();
    Object localObject1 = localLocale.getLanguage();
    String str2 = localLocale.getCountry();
    StringBuffer localStringBuffer = new StringBuffer((String)localObject1);
    localStringBuffer.append("-");
    localStringBuffer.append(str2.toLowerCase());
    localStringBuffer.append(",");
    localStringBuffer.append((String)localObject1);
    localStringBuffer.append(",");
    String str3 = localStringBuffer.toString();
    int m = -1;
    do
    {
      int k = m + 1;
      m = str1.indexOf(",", k);
      String str4;
      if (m == -1) {
        str4 = str1.substring(k);
      } else {
        str4 = str1.substring(k, m);
      }
      if (str4.length() > 0)
      {
        str4 = (str4 + ",").trim();
        if (str3.indexOf(str4) == -1) {
          localStringBuffer.append(str4);
        }
      }
    } while (m != -1);
    str3 = localStringBuffer.toString();
    Object localObject2;
    if (!str3.equals(str1))
    {
      str3 = str3.substring(0, str3.length() - ",".length());
      int n = str3.length();
      char[] arrayOfChar1 = new char[n + 1];
      str3.getChars(0, n, arrayOfChar1, 0);
      if (localnsIPrefLocalizedString1 == null)
      {
        localObject2 = MozillaDelegate.wcsToMbcs(null, "@mozilla.org/pref-localizedstring;1", true);
        i = paramnsIComponentManager.CreateInstanceByContractID((byte[])localObject2, 0, IIDStore.GetIID(nsIPrefLocalizedString.class), arrayOfInt);
        if (i != 0)
        {
          this.browser.dispose();
          error(i);
        }
        if (arrayOfInt[0] == 0)
        {
          this.browser.dispose();
          error(-2147467262);
        }
        localnsIPrefLocalizedString1 = new nsIPrefLocalizedString(arrayOfInt[0]);
        arrayOfInt[0] = 0;
      }
      localnsIPrefLocalizedString1.SetDataWithLength(n, arrayOfChar1);
      i = localnsIPrefBranch.SetComplexValue(arrayOfByte2, IIDStore.GetIID(nsIPrefLocalizedString.class), localnsIPrefLocalizedString1.getAddress());
    }
    if (localnsIPrefLocalizedString1 != null)
    {
      localnsIPrefLocalizedString1.Release();
      localnsIPrefLocalizedString1 = null;
    }
    String str5 = null;
    arrayOfByte2 = MozillaDelegate.wcsToMbcs(null, "intl.charset.default", true);
    i = localnsIPrefBranch.GetComplexValue(arrayOfByte2, IIDStore.GetIID(nsIPrefLocalizedString.class), arrayOfInt);
    if (i != 0)
    {
      str5 = "ISO-8859-1";
    }
    else
    {
      if (arrayOfInt[0] == 0)
      {
        this.browser.dispose();
        error(-2147467262);
      }
      localnsIPrefLocalizedString1 = new nsIPrefLocalizedString(arrayOfInt[0]);
      arrayOfInt[0] = 0;
      i = localnsIPrefLocalizedString1.ToString(arrayOfInt);
      if (i != 0)
      {
        this.browser.dispose();
        error(i);
      }
      if (arrayOfInt[0] == 0)
      {
        this.browser.dispose();
        error(-2147467262);
      }
      int i1 = XPCOM.strlen_PRUnichar(arrayOfInt[0]);
      localObject2 = new char[i1];
      XPCOM.memmove((char[])localObject2, arrayOfInt[0], i1 * 2);
      str5 = new String((char[])localObject2);
    }
    arrayOfInt[0] = 0;
    String str6 = System.getProperty("file.encoding");
    if (!str6.equals(str5))
    {
      int i2 = str6.length();
      char[] arrayOfChar2 = new char[i2 + 1];
      str6.getChars(0, i2, arrayOfChar2, 0);
      if (localnsIPrefLocalizedString1 == null)
      {
        byte[] arrayOfByte3 = MozillaDelegate.wcsToMbcs(null, "@mozilla.org/pref-localizedstring;1", true);
        i = paramnsIComponentManager.CreateInstanceByContractID(arrayOfByte3, 0, IIDStore.GetIID(nsIPrefLocalizedString.class), arrayOfInt);
        if (i != 0)
        {
          this.browser.dispose();
          error(i);
        }
        if (arrayOfInt[0] == 0)
        {
          this.browser.dispose();
          error(-2147467262);
        }
        localnsIPrefLocalizedString1 = new nsIPrefLocalizedString(arrayOfInt[0]);
        arrayOfInt[0] = 0;
      }
      localnsIPrefLocalizedString1.SetDataWithLength(i2, arrayOfChar2);
      i = localnsIPrefBranch.SetComplexValue(arrayOfByte2, IIDStore.GetIID(nsIPrefLocalizedString.class), localnsIPrefLocalizedString1.getAddress());
    }
    if (localnsIPrefLocalizedString1 != null) {
      localnsIPrefLocalizedString1.Release();
    }
    String str7 = System.getProperty("network.proxy_host");
    int i3 = -1;
    int i4 = Integer.getInteger("network.proxy_port", -1).intValue();
    if ((0 <= i4) && (i4 <= 65535)) {
      i3 = i4;
    }
    if (str7 != null)
    {
      localObject3 = MozillaDelegate.wcsToMbcs(null, "@mozilla.org/pref-localizedstring;1", true);
      i = paramnsIComponentManager.CreateInstanceByContractID((byte[])localObject3, 0, IIDStore.GetIID(nsIPrefLocalizedString.class), arrayOfInt);
      if (i != 0) {
        error(i);
      }
      if (arrayOfInt[0] == 0) {
        error(-2147467262);
      }
      localnsIPrefLocalizedString1 = new nsIPrefLocalizedString(arrayOfInt[0]);
      arrayOfInt[0] = 0;
      int i5 = str7.length();
      char[] arrayOfChar3 = new char[i5];
      str7.getChars(0, i5, arrayOfChar3, 0);
      i = localnsIPrefLocalizedString1.SetDataWithLength(i5, arrayOfChar3);
      if (i != 0) {
        error(i);
      }
      arrayOfByte2 = MozillaDelegate.wcsToMbcs(null, "network.proxy.ftp", true);
      i = localnsIPrefBranch.GetComplexValue(arrayOfByte2, IIDStore.GetIID(nsIPrefLocalizedString.class), arrayOfInt);
      nsIPrefLocalizedString localnsIPrefLocalizedString2;
      char[] arrayOfChar4;
      if ((i == 0) && (arrayOfInt[0] != 0))
      {
        localnsIPrefLocalizedString2 = new nsIPrefLocalizedString(arrayOfInt[0]);
        arrayOfInt[0] = 0;
        i = localnsIPrefLocalizedString2.ToString(arrayOfInt);
        if (i != 0) {
          error(i);
        }
        if (arrayOfInt[0] == 0) {
          error(-2147467261);
        }
        i5 = XPCOM.strlen_PRUnichar(arrayOfInt[0]);
        arrayOfChar4 = new char[i5];
        XPCOM.memmove(arrayOfChar4, arrayOfInt[0], i5 * 2);
        oldProxyHostFTP = new String(arrayOfChar4);
      }
      else
      {
        oldProxyHostFTP = "default";
      }
      arrayOfInt[0] = 0;
      i = localnsIPrefBranch.SetComplexValue(arrayOfByte2, IIDStore.GetIID(nsIPrefLocalizedString.class), localnsIPrefLocalizedString1.getAddress());
      if (i != 0) {
        error(i);
      }
      arrayOfByte2 = MozillaDelegate.wcsToMbcs(null, "network.proxy.http", true);
      i = localnsIPrefBranch.GetComplexValue(arrayOfByte2, IIDStore.GetIID(nsIPrefLocalizedString.class), arrayOfInt);
      if ((i == 0) && (arrayOfInt[0] != 0))
      {
        localnsIPrefLocalizedString2 = new nsIPrefLocalizedString(arrayOfInt[0]);
        arrayOfInt[0] = 0;
        i = localnsIPrefLocalizedString2.ToString(arrayOfInt);
        if (i != 0) {
          error(i);
        }
        if (arrayOfInt[0] == 0) {
          error(-2147467261);
        }
        i5 = XPCOM.strlen_PRUnichar(arrayOfInt[0]);
        arrayOfChar4 = new char[i5];
        XPCOM.memmove(arrayOfChar4, arrayOfInt[0], i5 * 2);
        oldProxyHostHTTP = new String(arrayOfChar4);
      }
      else
      {
        oldProxyHostHTTP = "default";
      }
      arrayOfInt[0] = 0;
      i = localnsIPrefBranch.SetComplexValue(arrayOfByte2, IIDStore.GetIID(nsIPrefLocalizedString.class), localnsIPrefLocalizedString1.getAddress());
      if (i != 0) {
        error(i);
      }
      arrayOfByte2 = MozillaDelegate.wcsToMbcs(null, "network.proxy.ssl", true);
      i = localnsIPrefBranch.GetComplexValue(arrayOfByte2, IIDStore.GetIID(nsIPrefLocalizedString.class), arrayOfInt);
      if ((i == 0) && (arrayOfInt[0] != 0))
      {
        localnsIPrefLocalizedString2 = new nsIPrefLocalizedString(arrayOfInt[0]);
        arrayOfInt[0] = 0;
        i = localnsIPrefLocalizedString2.ToString(arrayOfInt);
        if (i != 0) {
          error(i);
        }
        if (arrayOfInt[0] == 0) {
          error(-2147467261);
        }
        i5 = XPCOM.strlen_PRUnichar(arrayOfInt[0]);
        arrayOfChar4 = new char[i5];
        XPCOM.memmove(arrayOfChar4, arrayOfInt[0], i5 * 2);
        oldProxyHostSSL = new String(arrayOfChar4);
      }
      else
      {
        oldProxyHostSSL = "default";
      }
      arrayOfInt[0] = 0;
      i = localnsIPrefBranch.SetComplexValue(arrayOfByte2, IIDStore.GetIID(nsIPrefLocalizedString.class), localnsIPrefLocalizedString1.getAddress());
      if (i != 0) {
        error(i);
      }
      localnsIPrefLocalizedString1.Release();
    }
    Object localObject3 = new int[1];
    if (i3 != -1)
    {
      arrayOfByte2 = MozillaDelegate.wcsToMbcs(null, "network.proxy.ftp_port", true);
      i = localnsIPrefBranch.GetIntPref(arrayOfByte2, (int[])localObject3);
      if (i != 0) {
        error(i);
      }
      oldProxyPortFTP = localObject3[0];
      localObject3[0] = 0;
      i = localnsIPrefBranch.SetIntPref(arrayOfByte2, i3);
      if (i != 0) {
        error(i);
      }
      arrayOfByte2 = MozillaDelegate.wcsToMbcs(null, "network.proxy.http_port", true);
      i = localnsIPrefBranch.GetIntPref(arrayOfByte2, (int[])localObject3);
      if (i != 0) {
        error(i);
      }
      oldProxyPortHTTP = localObject3[0];
      localObject3[0] = 0;
      i = localnsIPrefBranch.SetIntPref(arrayOfByte2, i3);
      if (i != 0) {
        error(i);
      }
      arrayOfByte2 = MozillaDelegate.wcsToMbcs(null, "network.proxy.ssl_port", true);
      i = localnsIPrefBranch.GetIntPref(arrayOfByte2, (int[])localObject3);
      if (i != 0) {
        error(i);
      }
      oldProxyPortSSL = localObject3[0];
      localObject3[0] = 0;
      i = localnsIPrefBranch.SetIntPref(arrayOfByte2, i3);
      if (i != 0) {
        error(i);
      }
    }
    if ((str7 != null) || (i3 != -1))
    {
      arrayOfByte2 = MozillaDelegate.wcsToMbcs(null, "network.proxy.type", true);
      i = localnsIPrefBranch.GetIntPref(arrayOfByte2, (int[])localObject3);
      if (i != 0) {
        error(i);
      }
      oldProxyType = localObject3[0];
      localObject3[0] = 0;
      i = localnsIPrefBranch.SetIntPref(arrayOfByte2, 1);
      if (i != 0) {
        error(i);
      }
    }
    arrayOfByte2 = MozillaDelegate.wcsToMbcs(null, "dom.disable_open_during_load", true);
    i = localnsIPrefBranch.SetBoolPref(arrayOfByte2, 0);
    if (i != 0)
    {
      this.browser.dispose();
      error(i);
    }
    arrayOfByte2 = MozillaDelegate.wcsToMbcs(null, "dom.disable_window_status_change", true);
    i = localnsIPrefBranch.SetBoolPref(arrayOfByte2, 0);
    if (i != 0)
    {
      this.browser.dispose();
      error(i);
    }
    arrayOfByte2 = MozillaDelegate.wcsToMbcs(null, "dom.disable_window_open_feature.status", true);
    i = localnsIPrefBranch.SetBoolPref(arrayOfByte2, 0);
    if (i != 0)
    {
      this.browser.dispose();
      error(i);
    }
    arrayOfByte2 = MozillaDelegate.wcsToMbcs(null, "javascript.enabled", true);
    i = localnsIPrefBranch.SetBoolPref(arrayOfByte2, 1);
    if (i != 0)
    {
      this.browser.dispose();
      error(i);
    }
    localnsIPrefBranch.Release();
  }
  
  void initProfile(nsIServiceManager paramnsIServiceManager, boolean paramBoolean)
  {
    int[] arrayOfInt = new int[1];
    byte[] arrayOfByte1 = MozillaDelegate.wcsToMbcs(null, "@mozilla.org/observer-service;1", true);
    int i = paramnsIServiceManager.GetServiceByContractID(arrayOfByte1, IIDStore.GetIID(nsIObserverService.class), arrayOfInt);
    if (i != 0)
    {
      this.browser.dispose();
      error(i);
    }
    if (arrayOfInt[0] == 0)
    {
      this.browser.dispose();
      error(-2147467262);
    }
    nsIObserverService localnsIObserverService = new nsIObserverService(arrayOfInt[0]);
    arrayOfInt[0] = 0;
    arrayOfByte1 = MozillaDelegate.wcsToMbcs(null, "profile-do-change", true);
    int j = "startup".length();
    char[] arrayOfChar = new char[j + 1];
    "startup".getChars(0, j, arrayOfChar, 0);
    i = localnsIObserverService.NotifyObservers(0, arrayOfByte1, arrayOfChar);
    if (i != 0)
    {
      this.browser.dispose();
      error(i);
    }
    arrayOfByte1 = MozillaDelegate.wcsToMbcs(null, "profile-after-change", true);
    i = localnsIObserverService.NotifyObservers(0, arrayOfByte1, arrayOfChar);
    if (i != 0)
    {
      this.browser.dispose();
      error(i);
    }
    localnsIObserverService.Release();
    if (paramBoolean)
    {
      int k = XPCOM.nsDynamicFunctionLoad_sizeof();
      int m = C.malloc(k * 2);
      C.memset(m, 0, k * 2);
      nsDynamicFunctionLoad localnsDynamicFunctionLoad = new nsDynamicFunctionLoad();
      byte[] arrayOfByte2 = MozillaDelegate.wcsToMbcs(null, "XRE_NotifyProfile", true);
      localnsDynamicFunctionLoad.functionName = C.malloc(arrayOfByte2.length);
      C.memmove(localnsDynamicFunctionLoad.functionName, arrayOfByte2, arrayOfByte2.length);
      localnsDynamicFunctionLoad.function = C.malloc(C.PTR_SIZEOF);
      C.memmove(localnsDynamicFunctionLoad.function, new int[] { 0 }, C.PTR_SIZEOF);
      XPCOM.memmove(m, localnsDynamicFunctionLoad, XPCOM.nsDynamicFunctionLoad_sizeof());
      XPCOM.XPCOMGlueLoadXULFunctions(m);
      C.memmove(arrayOfInt, localnsDynamicFunctionLoad.function, C.PTR_SIZEOF);
      int n = arrayOfInt[0];
      arrayOfInt[0] = 0;
      C.free(localnsDynamicFunctionLoad.function);
      C.free(localnsDynamicFunctionLoad.functionName);
      C.free(m);
      if (n != 0)
      {
        i = XPCOM.Call(n);
        if (i != 0)
        {
          this.browser.dispose();
          error(i);
        }
      }
    }
  }
  
  void initSpinup(nsIComponentManager paramnsIComponentManager)
  {
    if (MozillaDelegate.needsSpinup())
    {
      int[] arrayOfInt = new int[1];
      int i = paramnsIComponentManager.CreateInstance(XPCOM.NS_APPSHELL_CID, 0, IIDStore.GetIID(nsIAppShell.class, 0), arrayOfInt);
      if (i != -2147467262)
      {
        if (i != 0)
        {
          this.browser.dispose();
          error(i);
        }
        if (arrayOfInt[0] == 0)
        {
          this.browser.dispose();
          error(-2147467262);
        }
        AppShell = new nsIAppShell(arrayOfInt[0]);
        arrayOfInt[0] = 0;
        i = AppShell.Create(0, null);
        if (i != 0)
        {
          this.browser.dispose();
          error(i);
        }
        i = AppShell.Spinup();
        if (i != 0)
        {
          this.browser.dispose();
          error(i);
        }
      }
    }
  }
  
  void initWebBrowserWindows()
  {
    int i = this.webBrowser.SetContainerWindow(this.webBrowserChrome.getAddress());
    if (i != 0)
    {
      this.browser.dispose();
      error(i);
    }
    int[] arrayOfInt = new int[1];
    i = this.webBrowser.QueryInterface(IIDStore.GetIID(nsIBaseWindow.class), arrayOfInt);
    if (i != 0)
    {
      this.browser.dispose();
      error(i);
    }
    if (arrayOfInt[0] == 0)
    {
      this.browser.dispose();
      error(-2147467262);
    }
    nsIBaseWindow localnsIBaseWindow = new nsIBaseWindow(arrayOfInt[0]);
    arrayOfInt[0] = 0;
    Rectangle localRectangle = this.browser.getClientArea();
    if (localRectangle.isEmpty())
    {
      localRectangle.width = 1;
      localRectangle.height = 1;
    }
    this.embedHandle = this.delegate.getHandle();
    i = localnsIBaseWindow.InitWindow(this.embedHandle, 0, 0, 0, localRectangle.width, localRectangle.height);
    if (i != 0)
    {
      this.browser.dispose();
      error(-2147467259);
    }
    i = this.delegate.createBaseWindow(localnsIBaseWindow);
    if (i != 0)
    {
      this.browser.dispose();
      error(-2147467259);
    }
    i = localnsIBaseWindow.SetVisibility(1);
    if (i != 0)
    {
      this.browser.dispose();
      error(-2147467259);
    }
    localnsIBaseWindow.Release();
  }
  
  void initWindowCreator(nsIServiceManager paramnsIServiceManager)
  {
    WindowCreator = new WindowCreator2();
    WindowCreator.AddRef();
    int[] arrayOfInt = new int[1];
    byte[] arrayOfByte = MozillaDelegate.wcsToMbcs(null, "@mozilla.org/embedcomp/window-watcher;1", true);
    int i = paramnsIServiceManager.GetServiceByContractID(arrayOfByte, IIDStore.GetIID(nsIWindowWatcher.class), arrayOfInt);
    if (i != 0)
    {
      this.browser.dispose();
      error(i);
    }
    if (arrayOfInt[0] == 0)
    {
      this.browser.dispose();
      error(-2147467262);
    }
    nsIWindowWatcher localnsIWindowWatcher = new nsIWindowWatcher(arrayOfInt[0]);
    arrayOfInt[0] = 0;
    i = localnsIWindowWatcher.SetWindowCreator(WindowCreator.getAddress());
    if (i != 0)
    {
      this.browser.dispose();
      error(i);
    }
    localnsIWindowWatcher.Release();
  }
  
  String initXULRunner(String paramString)
  {
    if (Device.DEBUG) {
      System.out.println("XULRunner path: " + paramString);
    }
    try
    {
      Library.loadLibrary("swt-xulrunner");
    }
    catch (UnsatisfiedLinkError localUnsatisfiedLinkError)
    {
      SWT.error(2, localUnsatisfiedLinkError);
    }
    String str = paramString.substring(0, paramString.lastIndexOf(SEPARATOR_OS));
    MozillaDelegate.loadAdditionalLibraries(str, false);
    byte[] arrayOfByte = MozillaDelegate.wcsToMbcs(null, paramString, true);
    int i = XPCOM.XPCOMGlueStartup(arrayOfByte);
    if (i != 0)
    {
      this.browser.dispose();
      error(i);
    }
    XPCOMWasGlued = true;
    return str;
  }
  
  public boolean isBackEnabled()
  {
    int[] arrayOfInt1 = new int[1];
    int i = this.webBrowser.QueryInterface(IIDStore.GetIID(nsIWebNavigation.class), arrayOfInt1);
    if (i != 0) {
      error(i);
    }
    if (arrayOfInt1[0] == 0) {
      error(-2147467262);
    }
    nsIWebNavigation localnsIWebNavigation = new nsIWebNavigation(arrayOfInt1[0]);
    int[] arrayOfInt2 = new int[1];
    i = localnsIWebNavigation.GetCanGoBack(arrayOfInt2);
    localnsIWebNavigation.Release();
    return arrayOfInt2[0] != 0;
  }
  
  public boolean isForwardEnabled()
  {
    int[] arrayOfInt1 = new int[1];
    int i = this.webBrowser.QueryInterface(IIDStore.GetIID(nsIWebNavigation.class), arrayOfInt1);
    if (i != 0) {
      error(i);
    }
    if (arrayOfInt1[0] == 0) {
      error(-2147467262);
    }
    nsIWebNavigation localnsIWebNavigation = new nsIWebNavigation(arrayOfInt1[0]);
    int[] arrayOfInt2 = new int[1];
    i = localnsIWebNavigation.GetCanGoForward(arrayOfInt2);
    localnsIWebNavigation.Release();
    return arrayOfInt2[0] != 0;
  }
  
  static String error(int paramInt)
  {
    throw new SWTError("XPCOM error 0x" + Integer.toHexString(paramInt));
  }
  
  void onDispose(Display paramDisplay)
  {
    if ((!this.browser.isClosing) && (!this.browser.isDisposed()))
    {
      LocationListener[] arrayOfLocationListener = this.locationListeners;
      this.locationListeners = new LocationListener[0];
      this.ignoreAllMessages = true;
      execute("window.location.replace('about:blank');");
      this.ignoreAllMessages = false;
      this.locationListeners = arrayOfLocationListener;
    }
    if (this.badCertRequest != 0) {
      new nsISupports(this.badCertRequest).Release();
    }
    int i = this.webBrowser.RemoveWebBrowserListener(this.weakReference.getAddress(), IIDStore.GetIID(nsIWebProgressListener.class));
    if (i != 0) {
      error(i);
    }
    i = this.webBrowser.SetParentURIContentListener(0);
    if (i != 0) {
      error(i);
    }
    i = this.webBrowser.SetContainerWindow(0);
    if (i != 0) {
      error(i);
    }
    unhookDOMListeners();
    int[] arrayOfInt = new int[1];
    i = this.webBrowser.QueryInterface(IIDStore.GetIID(nsIBaseWindow.class), arrayOfInt);
    if (i != 0)
    {
      this.browser.dispose();
      error(i);
    }
    if (arrayOfInt[0] == 0) {
      error(-2147467262);
    }
    nsIBaseWindow localnsIBaseWindow = new nsIBaseWindow(arrayOfInt[0]);
    i = localnsIBaseWindow.Destroy();
    if (i != 0) {
      error(i);
    }
    localnsIBaseWindow.Release();
    Release();
    this.webBrowser.Release();
    this.webBrowser = null;
    this.webBrowserObject = null;
    this.lastNavigateURL = null;
    this.htmlBytes = null;
    this.listener = null;
    if ((this.tip != null) && (!this.tip.isDisposed())) {
      this.tip.dispose();
    }
    this.tip = null;
    this.location = (this.size = null);
    Enumeration localEnumeration = this.unhookedDOMWindows.elements();
    Object localObject;
    while (localEnumeration.hasMoreElements())
    {
      localObject = (LONG)localEnumeration.nextElement();
      new nsISupports(((LONG)localObject).value).Release();
    }
    this.unhookedDOMWindows = null;
    localEnumeration = this.functions.elements();
    while (localEnumeration.hasMoreElements())
    {
      localObject = (BrowserFunction)localEnumeration.nextElement();
      AllFunctions.remove(new Integer(((BrowserFunction)localObject).index));
      ((BrowserFunction)localObject).dispose(false);
    }
    this.functions = null;
    this.delegate.onDispose(this.embedHandle);
    this.delegate = null;
    this.embedHandle = 0;
    BrowserCount -= 1;
  }
  
  void Activate()
  {
    this.isActive = true;
    int[] arrayOfInt = new int[1];
    int i = this.webBrowser.QueryInterface(IIDStore.GetIID(nsIWebBrowserFocus.class), arrayOfInt);
    if (i != 0) {
      error(i);
    }
    if (arrayOfInt[0] == 0) {
      error(-2147467262);
    }
    nsIWebBrowserFocus localnsIWebBrowserFocus = new nsIWebBrowserFocus(arrayOfInt[0]);
    i = localnsIWebBrowserFocus.Activate();
    if (i != 0) {
      error(i);
    }
    localnsIWebBrowserFocus.Release();
  }
  
  void Deactivate()
  {
    this.isActive = false;
    int[] arrayOfInt = new int[1];
    int i = this.webBrowser.QueryInterface(IIDStore.GetIID(nsIWebBrowserFocus.class), arrayOfInt);
    if (i != 0) {
      error(i);
    }
    if (arrayOfInt[0] == 0) {
      error(-2147467262);
    }
    nsIWebBrowserFocus localnsIWebBrowserFocus = new nsIWebBrowserFocus(arrayOfInt[0]);
    i = localnsIWebBrowserFocus.Deactivate();
    if (i != 0) {
      error(i);
    }
    localnsIWebBrowserFocus.Release();
  }
  
  void navigate(int paramInt)
  {
    nsIRequest localnsIRequest = new nsIRequest(paramInt);
    int[] arrayOfInt = new int[1];
    byte[] arrayOfByte1 = null;
    final Vector localVector = new Vector();
    int i = localnsIRequest.QueryInterface(IIDStore.GetIID(nsIUploadChannel.class), arrayOfInt);
    int n;
    byte[] arrayOfByte2;
    Object localObject5;
    if ((i == 0) && (arrayOfInt[0] != 0))
    {
      localObject1 = new nsIUploadChannel(arrayOfInt[0]);
      arrayOfInt[0] = 0;
      i = ((nsIUploadChannel)localObject1).GetUploadStream(arrayOfInt);
      if ((i == 0) && (arrayOfInt[0] != 0))
      {
        localObject2 = new nsIInputStream(arrayOfInt[0]);
        arrayOfInt[0] = 0;
        i = ((nsIInputStream)localObject2).QueryInterface(IIDStore.GetIID(nsISeekableStream.class), arrayOfInt);
        if ((i == 0) && (arrayOfInt[0] != 0))
        {
          nsISeekableStream localnsISeekableStream = new nsISeekableStream(arrayOfInt[0]);
          arrayOfInt[0] = 0;
          localObject3 = new long[1];
          i = localnsISeekableStream.Tell((long[])localObject3);
          if (i == 0)
          {
            i = localnsISeekableStream.Seek(0, 0L);
            if (i == 0)
            {
              Object localObject4;
              long l;
              if (MozillaVersion.CheckVersion(6))
              {
                localObject4 = new long[1];
                i = ((nsIInputStream)localObject2).Available((long[])localObject4);
                l = localObject4[0];
              }
              else
              {
                localObject4 = new int[1];
                i = ((nsIInputStream)localObject2).Available((int[])localObject4);
                l = localObject4[0];
              }
              if (i == 0)
              {
                n = (int)l;
                arrayOfByte2 = new byte[n];
                localObject5 = new int[1];
                i = ((nsIInputStream)localObject2).Read(arrayOfByte2, n, (int[])localObject5);
                if (i == 0)
                {
                  int i1 = 0;
                  for (int i2 = 0; i2 < n; i2++) {
                    if (arrayOfByte2[i2] == 13)
                    {
                      byte[] arrayOfByte3 = new byte[i2 - i1];
                      System.arraycopy(arrayOfByte2, i1, arrayOfByte3, 0, i2 - i1);
                      String str = new String(arrayOfByte3).trim();
                      if (str.length() != 0)
                      {
                        localVector.add(str);
                      }
                      else
                      {
                        i1 = i2 + 2;
                        arrayOfByte1 = new byte[n - i1];
                        System.arraycopy(arrayOfByte2, i1, arrayOfByte1, 0, n - i1);
                        break;
                      }
                      i1 = i2;
                    }
                  }
                }
              }
            }
            localnsISeekableStream.Seek(0, localObject3[0]);
          }
          localnsISeekableStream.Release();
        }
        ((nsIInputStream)localObject2).Release();
      }
      ((nsIUploadChannel)localObject1).Release();
    }
    Object localObject1 = new XPCOMObject(new int[] { 2, 0, 0, 2 })
    {
      int refCount = 0;
      
      public int method0(int[] paramAnonymousArrayOfInt)
      {
        int i = paramAnonymousArrayOfInt[0];
        int j = paramAnonymousArrayOfInt[1];
        if ((i == 0) || (j == 0)) {
          return -2147467262;
        }
        nsID localnsID = new nsID();
        XPCOM.memmove(localnsID, i, 16);
        if ((localnsID.Equals(IIDStore.GetIID(nsISupports.class))) || (localnsID.Equals(XPCOM.NS_IHTTPHEADERVISITOR_IID)) || (localnsID.Equals(XPCOM.NS_IHTTPHEADERVISITOR_10_IID)))
        {
          XPCOM.memmove(j, new int[] { getAddress() }, C.PTR_SIZEOF);
          this.refCount += 1;
          return 0;
        }
        XPCOM.memmove(j, new int[] { 0 }, C.PTR_SIZEOF);
        return -2147467262;
      }
      
      public int method1(int[] paramAnonymousArrayOfInt)
      {
        return ++this.refCount;
      }
      
      public int method2(int[] paramAnonymousArrayOfInt)
      {
        if (--this.refCount == 0) {
          dispose();
        }
        return this.refCount;
      }
      
      public int method3(int[] paramAnonymousArrayOfInt)
      {
        int i = paramAnonymousArrayOfInt[0];
        int j = paramAnonymousArrayOfInt[1];
        int k = XPCOM.nsEmbedCString_Length(i);
        int m = XPCOM.nsEmbedCString_get(i);
        byte[] arrayOfByte = new byte[k];
        XPCOM.memmove(arrayOfByte, m, k);
        String str1 = new String(arrayOfByte);
        k = XPCOM.nsEmbedCString_Length(j);
        m = XPCOM.nsEmbedCString_get(j);
        arrayOfByte = new byte[k];
        XPCOM.memmove(arrayOfByte, m, k);
        String str2 = new String(arrayOfByte);
        localVector.add(str1 + ':' + str2);
        return 0;
      }
    };
    new nsISupports(((XPCOMObject)localObject1).getAddress()).AddRef();
    i = localnsIRequest.QueryInterface(IIDStore.GetIID(nsIHttpChannel.class), arrayOfInt);
    if ((i == 0) && (arrayOfInt[0] != 0))
    {
      localObject2 = new nsIHttpChannel(arrayOfInt[0]);
      ((nsIHttpChannel)localObject2).VisitRequestHeaders(((XPCOMObject)localObject1).getAddress());
      ((nsIHttpChannel)localObject2).Release();
    }
    arrayOfInt[0] = 0;
    new nsISupports(((XPCOMObject)localObject1).getAddress()).Release();
    Object localObject2 = null;
    int j = localVector.size();
    if (j > 0)
    {
      localObject2 = new String[j];
      localVector.copyInto((Object[])localObject2);
    }
    Object localObject3 = this.lastNavigateURL;
    int k = XPCOM.nsEmbedCString_new();
    i = localnsIRequest.GetName(k);
    if (i == 0)
    {
      int m = XPCOM.nsEmbedCString_Length(k);
      n = XPCOM.nsEmbedCString_get(k);
      arrayOfByte2 = new byte[m];
      XPCOM.memmove(arrayOfByte2, n, m);
      localObject5 = new String(arrayOfByte2);
      if (((String)localObject5).indexOf(":/") != -1) {
        localObject3 = localObject5;
      }
    }
    XPCOM.nsEmbedCString_delete(k);
    setUrl((String)localObject3, arrayOfByte1, (String[])localObject2);
  }
  
  void onResize()
  {
    Rectangle localRectangle = this.browser.getClientArea();
    int i = Math.max(1, localRectangle.width);
    int j = Math.max(1, localRectangle.height);
    int[] arrayOfInt = new int[1];
    int k = this.webBrowser.QueryInterface(IIDStore.GetIID(nsIBaseWindow.class), arrayOfInt);
    if (k != 0)
    {
      this.browser.dispose();
      error(k);
    }
    if (arrayOfInt[0] == 0) {
      error(-2147467262);
    }
    Point localPoint = this.delegate.getNativeSize(i, j);
    this.delegate.setSize(this.embedHandle, localPoint.x, localPoint.y);
    nsIBaseWindow localnsIBaseWindow = new nsIBaseWindow(arrayOfInt[0]);
    k = localnsIBaseWindow.SetPositionAndSize(0, 0, localPoint.x, localPoint.y, 1);
    if (k != 0) {
      error(k);
    }
    localnsIBaseWindow.Release();
  }
  
  public void refresh()
  {
    this.htmlBytes = null;
    int[] arrayOfInt = new int[1];
    int i = this.webBrowser.QueryInterface(IIDStore.GetIID(nsIWebNavigation.class), arrayOfInt);
    if (i != 0) {
      error(i);
    }
    if (arrayOfInt[0] == 0) {
      error(-2147467262);
    }
    nsIWebNavigation localnsIWebNavigation = new nsIWebNavigation(arrayOfInt[0]);
    i = localnsIWebNavigation.Reload(0);
    localnsIWebNavigation.Release();
    switch (i)
    {
    case -2147467261: 
    case -2142568446: 
    case -2142109678: 
    case 0: 
      return;
    }
    error(i);
  }
  
  void registerFunction(BrowserFunction paramBrowserFunction)
  {
    super.registerFunction(paramBrowserFunction);
    AllFunctions.put(new Integer(paramBrowserFunction.index), paramBrowserFunction);
  }
  
  boolean sendChangingEvent(String paramString)
  {
    this.isViewingErrorPage = (paramString.indexOf("netError.xhtml") != -1);
    boolean bool = true;
    if ((this.request == 0) && (!paramString.startsWith("javascript:")))
    {
      Object localObject;
      int i;
      if (this.locationListeners.length > 0)
      {
        localObject = new LocationEvent(this.browser);
        ((LocationEvent)localObject).display = this.browser.getDisplay();
        ((LocationEvent)localObject).widget = this.browser;
        ((LocationEvent)localObject).location = paramString;
        if (((LocationEvent)localObject).location.equals("file:///"))
        {
          ((LocationEvent)localObject).location = "about:blank";
        }
        else
        {
          i = "file:///".length();
          if ((((LocationEvent)localObject).location.startsWith("file:///")) && (((LocationEvent)localObject).location.charAt(i) == '#')) {
            ((LocationEvent)localObject).location = ("about:blank" + ((LocationEvent)localObject).location.substring(i));
          }
        }
        ((LocationEvent)localObject).doit = bool;
        for (i = 0; i < this.locationListeners.length; i++) {
          this.locationListeners[i].changing((LocationEvent)localObject);
        }
        bool = (((LocationEvent)localObject).doit) && (!this.browser.isDisposed());
      }
      if (bool)
      {
        if (this.jsEnabled != this.jsEnabledOnNextPage)
        {
          this.jsEnabled = this.jsEnabledOnNextPage;
          localObject = new int[1];
          i = this.webBrowser.QueryInterface(IIDStore.GetIID(nsIWebBrowserSetup.class), (int[])localObject);
          if (i != 0) {
            error(i);
          }
          if (localObject[0] == 0) {
            error(-2147467262);
          }
          nsIWebBrowserSetup localnsIWebBrowserSetup = new nsIWebBrowserSetup(localObject[0]);
          localObject[0] = 0;
          i = localnsIWebBrowserSetup.SetProperty(2, this.jsEnabled ? 1 : 0);
          if (i != 0) {
            error(i);
          }
          localnsIWebBrowserSetup.Release();
        }
        if (!this.isViewingErrorPage) {
          this.lastNavigateURL = paramString;
        }
      }
    }
    return bool;
  }
  
  public boolean setText(String paramString, boolean paramBoolean)
  {
    if (this.browser != this.browser.getDisplay().getFocusControl()) {
      Deactivate();
    }
    byte[] arrayOfByte1 = null;
    try
    {
      arrayOfByte1 = paramString.getBytes("UTF-8");
    }
    catch (UnsupportedEncodingException localUnsupportedEncodingException)
    {
      return false;
    }
    this.delegate.removeWindowSubclass();
    int[] arrayOfInt = new int[1];
    int i = this.webBrowser.QueryInterface(IIDStore.GetIID(nsIWebBrowserStream.class), arrayOfInt);
    Object localObject;
    if ((i == 0) && (arrayOfInt[0] != 0))
    {
      new nsISupports(arrayOfInt[0]).Release();
      arrayOfInt[0] = 0;
      int j = this.htmlBytes != null ? 1 : 0;
      this.htmlBytes = arrayOfByte1;
      this.untrustedText = (!paramBoolean);
      if (j != 0) {
        return true;
      }
      i = this.webBrowser.QueryInterface(IIDStore.GetIID(nsIWebNavigation.class), arrayOfInt);
      if (i != 0) {
        error(i);
      }
      if (arrayOfInt[0] == 0) {
        error(-2147467262);
      }
      nsIWebNavigation localnsIWebNavigation = new nsIWebNavigation(arrayOfInt[0]);
      arrayOfInt[0] = 0;
      localObject = new char["about:blank".length() + 1];
      "about:blank".getChars(0, "about:blank".length(), (char[])localObject, 0);
      i = localnsIWebNavigation.LoadURI((char[])localObject, 0, 0, 0, 0);
      if (i != 0) {
        error(i);
      }
      localnsIWebNavigation.Release();
    }
    else
    {
      byte[] arrayOfByte2 = MozillaDelegate.wcsToMbcs(null, "UTF-8", false);
      int k = XPCOM.nsEmbedCString_new(arrayOfByte2, arrayOfByte2.length);
      localObject = MozillaDelegate.wcsToMbcs(null, "text/html", false);
      int m = XPCOM.nsEmbedCString_new((byte[])localObject, localObject.length);
      i = XPCOM.NS_GetServiceManager(arrayOfInt);
      if (i != 0) {
        error(i);
      }
      if (arrayOfInt[0] == 0) {
        error(-2147467262);
      }
      nsIServiceManager localnsIServiceManager = new nsIServiceManager(arrayOfInt[0]);
      arrayOfInt[0] = 0;
      i = localnsIServiceManager.GetService(XPCOM.NS_IOSERVICE_CID, IIDStore.GetIID(nsIIOService.class), arrayOfInt);
      if (i != 0) {
        error(i);
      }
      if (arrayOfInt[0] == 0) {
        error(-2147467262);
      }
      nsIIOService localnsIIOService = new nsIIOService(arrayOfInt[0]);
      arrayOfInt[0] = 0;
      byte[] arrayOfByte3;
      if (paramBoolean) {
        arrayOfByte3 = MozillaDelegate.wcsToMbcs(null, "file:///", false);
      } else {
        arrayOfByte3 = MozillaDelegate.wcsToMbcs(null, "about:blank", false);
      }
      int n = XPCOM.nsEmbedCString_new(arrayOfByte3, arrayOfByte3.length);
      i = localnsIIOService.NewURI(n, null, 0, arrayOfInt);
      if (i != 0) {
        error(i);
      }
      if (arrayOfInt[0] == 0) {
        error(-2147467262);
      }
      XPCOM.nsEmbedCString_delete(n);
      localnsIIOService.Release();
      nsIURI localnsIURI = new nsIURI(arrayOfInt[0]);
      arrayOfInt[0] = 0;
      i = this.webBrowser.QueryInterface(IIDStore.GetIID(nsIInterfaceRequestor.class), arrayOfInt);
      if (i != 0) {
        error(i);
      }
      if (arrayOfInt[0] == 0) {
        error(-2147467262);
      }
      nsIInterfaceRequestor localnsIInterfaceRequestor = new nsIInterfaceRequestor(arrayOfInt[0]);
      arrayOfInt[0] = 0;
      InputStream localInputStream = new InputStream(arrayOfByte1);
      localInputStream.AddRef();
      i = localnsIInterfaceRequestor.GetInterface(IIDStore.GetIID(nsIDocShell.class, 0), arrayOfInt);
      if (i != 0) {
        error(i);
      }
      if (arrayOfInt[0] == 0) {
        error(-2147467262);
      }
      nsIDocShell localnsIDocShell = new nsIDocShell(arrayOfInt[0]);
      arrayOfInt[0] = 0;
      i = localnsIDocShell.LoadStream(localInputStream.getAddress(), localnsIURI.getAddress(), m, k, 0);
      localnsIDocShell.Release();
      localInputStream.Release();
      localnsIInterfaceRequestor.Release();
      localnsIURI.Release();
      XPCOM.nsEmbedCString_delete(m);
      XPCOM.nsEmbedCString_delete(k);
    }
    return true;
  }
  
  public boolean setUrl(String paramString1, String paramString2, String[] paramArrayOfString)
  {
    byte[] arrayOfByte = null;
    if (paramString2 != null) {
      arrayOfByte = MozillaDelegate.wcsToMbcs(null, paramString2, false);
    }
    return setUrl(paramString1, arrayOfByte, paramArrayOfString);
  }
  
  boolean setUrl(String paramString, byte[] paramArrayOfByte, String[] paramArrayOfString)
  {
    this.htmlBytes = null;
    int[] arrayOfInt = new int[1];
    int i = this.webBrowser.QueryInterface(IIDStore.GetIID(nsIWebNavigation.class), arrayOfInt);
    if (i != 0) {
      error(i);
    }
    if (arrayOfInt[0] == 0) {
      error(-2147467262);
    }
    this.delegate.removeWindowSubclass();
    nsIWebNavigation localnsIWebNavigation = new nsIWebNavigation(arrayOfInt[0]);
    arrayOfInt[0] = 0;
    char[] arrayOfChar = new char[paramString.length() + 1];
    paramString.getChars(0, paramString.length(), arrayOfChar, 0);
    nsIMIMEInputStream localnsIMIMEInputStream = null;
    InputStream localInputStream = null;
    Object localObject2;
    int j;
    String str2;
    Object localObject3;
    if (paramArrayOfByte != null)
    {
      i = XPCOM.NS_GetComponentManager(arrayOfInt);
      if (i != 0) {
        error(i);
      }
      if (arrayOfInt[0] == 0) {
        error(-2147467262);
      }
      localObject1 = new nsIComponentManager(arrayOfInt[0]);
      arrayOfInt[0] = 0;
      localObject2 = MozillaDelegate.wcsToMbcs(null, "@mozilla.org/network/mime-input-stream;1", true);
      i = ((nsIComponentManager)localObject1).CreateInstanceByContractID((byte[])localObject2, 0, IIDStore.GetIID(nsIMIMEInputStream.class), arrayOfInt);
      ((nsIComponentManager)localObject1).Release();
      if ((i == 0) && (arrayOfInt[0] != 0))
      {
        localInputStream = new InputStream(paramArrayOfByte);
        localInputStream.AddRef();
        localnsIMIMEInputStream = new nsIMIMEInputStream(arrayOfInt[0]);
        i = localnsIMIMEInputStream.SetData(localInputStream.getAddress());
        if (i != 0) {
          error(i);
        }
        j = 0;
        int k = 0;
        if (paramArrayOfString != null) {
          for (int m = 0; m < paramArrayOfString.length; m++)
          {
            int i1 = paramArrayOfString[m].indexOf(':');
            if (i1 != -1)
            {
              str2 = paramArrayOfString[m].substring(0, i1).trim().toLowerCase();
              if (str2.equals("content-length")) {
                j = 1;
              } else if (str2.equals("content-type")) {
                k = 1;
              }
            }
          }
        }
        i = localnsIMIMEInputStream.SetAddContentLength(j != 0 ? 0 : 1);
        if (i != 0) {
          error(i);
        }
        if (k == 0)
        {
          byte[] arrayOfByte2 = MozillaDelegate.wcsToMbcs(null, "content-type", true);
          localObject3 = MozillaDelegate.wcsToMbcs(null, "application/x-www-form-urlencoded", true);
          i = localnsIMIMEInputStream.AddHeader(arrayOfByte2, (byte[])localObject3);
          if (i != 0) {
            error(i);
          }
        }
      }
      arrayOfInt[0] = 0;
    }
    Object localObject1 = null;
    if (paramArrayOfString != null)
    {
      localObject2 = new StringBuffer();
      for (j = 0; j < paramArrayOfString.length; j++)
      {
        String str1 = paramArrayOfString[j];
        if (str1 != null)
        {
          int n = str1.indexOf(':');
          if (n != -1)
          {
            localObject3 = str1.substring(0, n).trim();
            str2 = str1.substring(n + 1).trim();
            if ((((String)localObject3).length() > 0) && (str2.length() > 0))
            {
              ((StringBuffer)localObject2).append((String)localObject3);
              ((StringBuffer)localObject2).append(':');
              ((StringBuffer)localObject2).append(str2);
              ((StringBuffer)localObject2).append("\r\n");
            }
          }
        }
      }
      byte[] arrayOfByte1 = MozillaDelegate.wcsToMbcs(null, ((StringBuffer)localObject2).toString(), true);
      localObject1 = new InputStream(arrayOfByte1);
      ((InputStream)localObject1).AddRef();
    }
    i = localnsIWebNavigation.LoadURI(arrayOfChar, 0, 0, localnsIMIMEInputStream == null ? 0 : localnsIMIMEInputStream.getAddress(), localObject1 == null ? 0 : ((InputStream)localObject1).getAddress());
    if (localInputStream != null) {
      localInputStream.Release();
    }
    if (localObject1 != null) {
      ((InputStream)localObject1).Release();
    }
    localnsIWebNavigation.Release();
    return i == 0;
  }
  
  public void stop()
  {
    this.htmlBytes = null;
    int[] arrayOfInt = new int[1];
    int i = this.webBrowser.QueryInterface(IIDStore.GetIID(nsIWebNavigation.class), arrayOfInt);
    if (i != 0) {
      error(i);
    }
    if (arrayOfInt[0] == 0) {
      error(-2147467262);
    }
    nsIWebNavigation localnsIWebNavigation = new nsIWebNavigation(arrayOfInt[0]);
    i = localnsIWebNavigation.Stop(3);
    if (i != 0) {
      error(i);
    }
    localnsIWebNavigation.Release();
  }
  
  void hookDOMListeners(nsIDOMEventTarget paramnsIDOMEventTarget, boolean paramBoolean)
  {
    nsEmbedString localnsEmbedString = new nsEmbedString("focus");
    paramnsIDOMEventTarget.AddEventListener(localnsEmbedString.getAddress(), this.domEventListener.getAddress(), 0, 1, 0);
    localnsEmbedString.dispose();
    localnsEmbedString = new nsEmbedString("unload");
    paramnsIDOMEventTarget.AddEventListener(localnsEmbedString.getAddress(), this.domEventListener.getAddress(), 0, 1, 0);
    localnsEmbedString.dispose();
    localnsEmbedString = new nsEmbedString("mousedown");
    paramnsIDOMEventTarget.AddEventListener(localnsEmbedString.getAddress(), this.domEventListener.getAddress(), 0, 1, 0);
    localnsEmbedString.dispose();
    localnsEmbedString = new nsEmbedString("mouseup");
    paramnsIDOMEventTarget.AddEventListener(localnsEmbedString.getAddress(), this.domEventListener.getAddress(), 0, 1, 0);
    localnsEmbedString.dispose();
    localnsEmbedString = new nsEmbedString("mousemove");
    paramnsIDOMEventTarget.AddEventListener(localnsEmbedString.getAddress(), this.domEventListener.getAddress(), 0, 1, 0);
    localnsEmbedString.dispose();
    localnsEmbedString = new nsEmbedString("DOMMouseScroll");
    paramnsIDOMEventTarget.AddEventListener(localnsEmbedString.getAddress(), this.domEventListener.getAddress(), 0, 1, 0);
    localnsEmbedString.dispose();
    localnsEmbedString = new nsEmbedString("draggesture");
    paramnsIDOMEventTarget.AddEventListener(localnsEmbedString.getAddress(), this.domEventListener.getAddress(), 0, 1, 0);
    localnsEmbedString.dispose();
    if ((paramBoolean) && (this.delegate.hookEnterExit()))
    {
      localnsEmbedString = new nsEmbedString("mouseover");
      paramnsIDOMEventTarget.AddEventListener(localnsEmbedString.getAddress(), this.domEventListener.getAddress(), 0, 1, 0);
      localnsEmbedString.dispose();
      localnsEmbedString = new nsEmbedString("mouseout");
      paramnsIDOMEventTarget.AddEventListener(localnsEmbedString.getAddress(), this.domEventListener.getAddress(), 0, 1, 0);
      localnsEmbedString.dispose();
    }
    localnsEmbedString = new nsEmbedString("keydown");
    paramnsIDOMEventTarget.AddEventListener(localnsEmbedString.getAddress(), this.domEventListener.getAddress(), 0, 1, 0);
    localnsEmbedString.dispose();
    localnsEmbedString = new nsEmbedString("keypress");
    paramnsIDOMEventTarget.AddEventListener(localnsEmbedString.getAddress(), this.domEventListener.getAddress(), 0, 1, 0);
    localnsEmbedString.dispose();
    localnsEmbedString = new nsEmbedString("keyup");
    paramnsIDOMEventTarget.AddEventListener(localnsEmbedString.getAddress(), this.domEventListener.getAddress(), 0, 1, 0);
    localnsEmbedString.dispose();
  }
  
  void unhookDOMListeners()
  {
    int[] arrayOfInt1 = new int[1];
    int i = this.webBrowser.GetContentDOMWindow(arrayOfInt1);
    if ((i != 0) || (arrayOfInt1[0] == 0)) {
      return;
    }
    nsIDOMWindow localnsIDOMWindow1 = new nsIDOMWindow(arrayOfInt1[0]);
    arrayOfInt1[0] = 0;
    i = localnsIDOMWindow1.QueryInterface(IIDStore.GetIID(nsIDOMEventTarget.class), arrayOfInt1);
    if (i != 0) {
      error(i);
    }
    if (arrayOfInt1[0] == 0) {
      error(-2147467262);
    }
    nsIDOMEventTarget localnsIDOMEventTarget = new nsIDOMEventTarget(arrayOfInt1[0]);
    arrayOfInt1[0] = 0;
    unhookDOMListeners(localnsIDOMEventTarget);
    localnsIDOMEventTarget.Release();
    i = localnsIDOMWindow1.GetFrames(arrayOfInt1);
    if (i != 0) {
      error(i);
    }
    if (arrayOfInt1[0] == 0) {
      error(-2147467262);
    }
    nsIDOMWindowCollection localnsIDOMWindowCollection = new nsIDOMWindowCollection(arrayOfInt1[0]);
    arrayOfInt1[0] = 0;
    int[] arrayOfInt2 = new int[1];
    i = localnsIDOMWindowCollection.GetLength(arrayOfInt2);
    if (i != 0) {
      error(i);
    }
    int j = arrayOfInt2[0];
    if (j > 0) {
      for (int k = 0; k < j; k++)
      {
        i = localnsIDOMWindowCollection.Item(k, arrayOfInt1);
        if (i != 0) {
          error(i);
        }
        if (arrayOfInt1[0] == 0) {
          error(-2147467262);
        }
        nsIDOMWindow localnsIDOMWindow2 = new nsIDOMWindow(arrayOfInt1[0]);
        arrayOfInt1[0] = 0;
        i = localnsIDOMWindow2.QueryInterface(IIDStore.GetIID(nsIDOMEventTarget.class), arrayOfInt1);
        if (i != 0) {
          error(i);
        }
        if (arrayOfInt1[0] == 0) {
          error(-2147467262);
        }
        localnsIDOMEventTarget = new nsIDOMEventTarget(arrayOfInt1[0]);
        arrayOfInt1[0] = 0;
        unhookDOMListeners(localnsIDOMEventTarget);
        localnsIDOMEventTarget.Release();
        localnsIDOMWindow2.Release();
      }
    }
    localnsIDOMWindowCollection.Release();
    localnsIDOMWindow1.Release();
  }
  
  void unhookDOMListeners(nsIDOMEventTarget paramnsIDOMEventTarget)
  {
    nsEmbedString localnsEmbedString = new nsEmbedString("focus");
    paramnsIDOMEventTarget.RemoveEventListener(localnsEmbedString.getAddress(), this.domEventListener.getAddress(), 0);
    localnsEmbedString.dispose();
    localnsEmbedString = new nsEmbedString("unload");
    paramnsIDOMEventTarget.RemoveEventListener(localnsEmbedString.getAddress(), this.domEventListener.getAddress(), 0);
    localnsEmbedString.dispose();
    localnsEmbedString = new nsEmbedString("mousedown");
    paramnsIDOMEventTarget.RemoveEventListener(localnsEmbedString.getAddress(), this.domEventListener.getAddress(), 0);
    localnsEmbedString.dispose();
    localnsEmbedString = new nsEmbedString("mouseup");
    paramnsIDOMEventTarget.RemoveEventListener(localnsEmbedString.getAddress(), this.domEventListener.getAddress(), 0);
    localnsEmbedString.dispose();
    localnsEmbedString = new nsEmbedString("mousemove");
    paramnsIDOMEventTarget.RemoveEventListener(localnsEmbedString.getAddress(), this.domEventListener.getAddress(), 0);
    localnsEmbedString.dispose();
    localnsEmbedString = new nsEmbedString("DOMMouseScroll");
    paramnsIDOMEventTarget.RemoveEventListener(localnsEmbedString.getAddress(), this.domEventListener.getAddress(), 0);
    localnsEmbedString.dispose();
    localnsEmbedString = new nsEmbedString("draggesture");
    paramnsIDOMEventTarget.RemoveEventListener(localnsEmbedString.getAddress(), this.domEventListener.getAddress(), 0);
    localnsEmbedString.dispose();
    localnsEmbedString = new nsEmbedString("mouseover");
    paramnsIDOMEventTarget.RemoveEventListener(localnsEmbedString.getAddress(), this.domEventListener.getAddress(), 0);
    localnsEmbedString.dispose();
    localnsEmbedString = new nsEmbedString("mouseout");
    paramnsIDOMEventTarget.RemoveEventListener(localnsEmbedString.getAddress(), this.domEventListener.getAddress(), 0);
    localnsEmbedString.dispose();
    localnsEmbedString = new nsEmbedString("keydown");
    paramnsIDOMEventTarget.RemoveEventListener(localnsEmbedString.getAddress(), this.domEventListener.getAddress(), 0);
    localnsEmbedString.dispose();
    localnsEmbedString = new nsEmbedString("keypress");
    paramnsIDOMEventTarget.RemoveEventListener(localnsEmbedString.getAddress(), this.domEventListener.getAddress(), 0);
    localnsEmbedString.dispose();
    localnsEmbedString = new nsEmbedString("keyup");
    paramnsIDOMEventTarget.RemoveEventListener(localnsEmbedString.getAddress(), this.domEventListener.getAddress(), 0);
    localnsEmbedString.dispose();
  }
  
  int QueryInterface(int paramInt1, int paramInt2)
  {
    if ((paramInt1 == 0) || (paramInt2 == 0)) {
      return -2147467262;
    }
    nsID localnsID = new nsID();
    XPCOM.memmove(localnsID, paramInt1, 16);
    if (localnsID.Equals(IIDStore.GetIID(nsISupports.class)))
    {
      XPCOM.memmove(paramInt2, new int[] { this.supports.getAddress() }, C.PTR_SIZEOF);
      AddRef();
      return 0;
    }
    if (localnsID.Equals(XPCOM.NS_IWEAKREFERENCE_IID))
    {
      XPCOM.memmove(paramInt2, new int[] { this.weakReference.getAddress() }, C.PTR_SIZEOF);
      AddRef();
      return 0;
    }
    if (localnsID.Equals(IIDStore.GetIID(nsIWebProgressListener.class, 6, true)))
    {
      XPCOM.memmove(paramInt2, new int[] { this.webProgressListener_24.getAddress() }, C.PTR_SIZEOF);
      AddRef();
      return 0;
    }
    if (localnsID.Equals(IIDStore.GetIID(nsIWebProgressListener.class, 5)))
    {
      XPCOM.memmove(paramInt2, new int[] { this.webProgressListener.getAddress() }, C.PTR_SIZEOF);
      AddRef();
      return 0;
    }
    if (localnsID.Equals(IIDStore.GetIID(nsIWebBrowserChrome.class)))
    {
      XPCOM.memmove(paramInt2, new int[] { this.webBrowserChrome.getAddress() }, C.PTR_SIZEOF);
      AddRef();
      return 0;
    }
    if (localnsID.Equals(XPCOM.NS_IWEBBROWSERCHROMEFOCUS_IID))
    {
      XPCOM.memmove(paramInt2, new int[] { this.webBrowserChromeFocus.getAddress() }, C.PTR_SIZEOF);
      AddRef();
      return 0;
    }
    if (localnsID.Equals(IIDStore.GetIID(nsIEmbeddingSiteWindow.class, 6, true)))
    {
      XPCOM.memmove(paramInt2, new int[] { this.embeddingSiteWindow_24.getAddress() }, C.PTR_SIZEOF);
      AddRef();
      return 0;
    }
    if (localnsID.Equals(IIDStore.GetIID(nsIEmbeddingSiteWindow.class, 5)))
    {
      XPCOM.memmove(paramInt2, new int[] { this.embeddingSiteWindow.getAddress() }, C.PTR_SIZEOF);
      AddRef();
      return 0;
    }
    if (localnsID.Equals(IIDStore.GetIID(nsIInterfaceRequestor.class)))
    {
      XPCOM.memmove(paramInt2, new int[] { this.interfaceRequestor.getAddress() }, C.PTR_SIZEOF);
      AddRef();
      return 0;
    }
    if (localnsID.Equals(XPCOM.NS_ISUPPORTSWEAKREFERENCE_IID))
    {
      XPCOM.memmove(paramInt2, new int[] { this.supportsWeakReference.getAddress() }, C.PTR_SIZEOF);
      AddRef();
      return 0;
    }
    if (localnsID.Equals(XPCOM.NS_ICONTEXTMENULISTENER_IID))
    {
      XPCOM.memmove(paramInt2, new int[] { this.contextMenuListener.getAddress() }, C.PTR_SIZEOF);
      AddRef();
      return 0;
    }
    if (localnsID.Equals(XPCOM.NS_IURICONTENTLISTENER_IID))
    {
      XPCOM.memmove(paramInt2, new int[] { this.uriContentListener.getAddress() }, C.PTR_SIZEOF);
      AddRef();
      return 0;
    }
    if (localnsID.Equals(XPCOM.NS_ITOOLTIPLISTENER_IID))
    {
      XPCOM.memmove(paramInt2, new int[] { this.tooltipListener.getAddress() }, C.PTR_SIZEOF);
      AddRef();
      return 0;
    }
    if (localnsID.Equals(XPCOM.NS_IBADCERTLISTENER2_IID))
    {
      XPCOM.memmove(paramInt2, new int[] { this.badCertListener.getAddress() }, C.PTR_SIZEOF);
      AddRef();
      return 0;
    }
    XPCOM.memmove(paramInt2, new int[] { 0 }, C.PTR_SIZEOF);
    return -2147467262;
  }
  
  int AddRef()
  {
    this.refCount += 1;
    return this.refCount;
  }
  
  int Release()
  {
    this.refCount -= 1;
    if (this.refCount == 0) {
      disposeCOMInterfaces();
    }
    return this.refCount;
  }
  
  int QueryReferent(int paramInt1, int paramInt2)
  {
    return QueryInterface(paramInt1, paramInt2);
  }
  
  int GetInterface(int paramInt1, int paramInt2)
  {
    if ((paramInt1 == 0) || (paramInt2 == 0)) {
      return -2147467262;
    }
    nsID localnsID = new nsID();
    XPCOM.memmove(localnsID, paramInt1, 16);
    if (localnsID.Equals(IIDStore.GetIID(nsIDOMWindow.class)))
    {
      int[] arrayOfInt = new int[1];
      int i = this.webBrowser.GetContentDOMWindow(arrayOfInt);
      if (i != 0) {
        error(i);
      }
      if (arrayOfInt[0] == 0) {
        error(-2147467262);
      }
      XPCOM.memmove(paramInt2, arrayOfInt, C.PTR_SIZEOF);
      return i;
    }
    return QueryInterface(paramInt1, paramInt2);
  }
  
  int GetWeakReference(int paramInt)
  {
    XPCOM.memmove(paramInt, new int[] { this.weakReference.getAddress() }, C.PTR_SIZEOF);
    AddRef();
    return 0;
  }
  
  int OnStateChange(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    Object localObject1;
    if ((this.registerFunctionsOnState != 0) && ((paramInt3 & this.registerFunctionsOnState) == this.registerFunctionsOnState))
    {
      this.registerFunctionsOnState = 0;
      localObject1 = this.functions.elements();
      while (((Enumeration)localObject1).hasMoreElements())
      {
        BrowserFunction localBrowserFunction1 = (BrowserFunction)((Enumeration)localObject1).nextElement();
        if (!localBrowserFunction1.isEvaluate) {
          execute(localBrowserFunction1.functionString);
        }
      }
    }
    int k;
    Object localObject6;
    if ((this.updateLastNavigateUrl) && (paramInt3 == 65537))
    {
      localObject1 = new nsIRequest(paramInt2);
      int i = XPCOM.nsEmbedCString_new();
      k = ((nsIRequest)localObject1).GetName(i);
      if (k == 0)
      {
        int n = XPCOM.nsEmbedCString_Length(i);
        int i2 = XPCOM.nsEmbedCString_get(i);
        localObject6 = new byte[n];
        XPCOM.memmove((byte[])localObject6, i2, n);
        String str1 = new String((byte[])localObject6);
        if (str1.indexOf(":/") != -1)
        {
          boolean bool2 = sendChangingEvent(str1);
          if (bool2) {
            this.lastNavigateURL = str1;
          } else {
            stop();
          }
        }
      }
      XPCOM.nsEmbedCString_delete(i);
    }
    if ((paramInt3 & 0x20000) == 0) {
      return 0;
    }
    if ((paramInt3 & 0x1) != 0)
    {
      localObject1 = new int[1];
      if (this.isRetrievingBadCert)
      {
        localObject2 = new nsIRequest(paramInt2);
        k = ((nsIRequest)localObject2).QueryInterface(IIDStore.GetIID(nsIChannel.class), (int[])localObject1);
        if (k != 0) {
          error(k);
        }
        if (localObject1[0] == 0) {
          error(-2147467262);
        }
        nsIChannel localnsIChannel = new nsIChannel(localObject1[0]);
        localObject1[0] = 0;
        k = localnsIChannel.SetNotificationCallbacks(this.interfaceRequestor.getAddress());
        if (k != 0) {
          error(k);
        }
        localnsIChannel.Release();
        return 0;
      }
      if (this.request == 0) {
        this.request = paramInt2;
      }
      this.registerFunctionsOnState = 65537;
      Object localObject2 = new nsIWebProgress(paramInt1);
      k = ((nsIWebProgress)localObject2).GetDOMWindow((int[])localObject1);
      if (k != 0) {
        error(k);
      }
      if (localObject1[0] == 0) {
        error(-2147467262);
      }
      this.unhookedDOMWindows.addElement(new LONG(localObject1[0]));
    }
    else if ((paramInt3 & 0x2) != 0)
    {
      if (this.request == paramInt2) {
        this.request = 0;
      }
      this.registerFunctionsOnState = 4;
      this.updateLastNavigateUrl = true;
    }
    else
    {
      Object localObject7;
      if ((paramInt3 & 0x10) != 0)
      {
        if (this.isRetrievingBadCert) {
          return 0;
        }
        switch (paramInt4)
        {
        case -2141577306: 
        case -2141577252: 
        case -2141577246: 
        case -2141577237: 
        case -2141577236: 
        case -2141577229: 
        case -2141577227: 
        case -2141573132: 
          new nsISupports(paramInt2).AddRef();
          if (this.badCertRequest != 0) {
            new nsISupports(this.badCertRequest).Release();
          }
          this.badCertRequest = paramInt2;
          this.isRetrievingBadCert = true;
          navigate(paramInt2);
          return 0;
        }
        localObject1 = new int[1];
        LONG localLONG = new LONG(localObject1[0]);
        localObject1[0] = 0;
        int i1 = this.unhookedDOMWindows.indexOf(localLONG);
        int j;
        if (i1 != -1)
        {
          int[] arrayOfInt1 = new int[1];
          localObject6 = new nsIWebProgress(paramInt1);
          j = ((nsIWebProgress)localObject6).GetDOMWindow(arrayOfInt1);
          if (j != 0) {
            error(j);
          }
          if (arrayOfInt1[0] == 0) {
            error(-2147467262);
          }
          j = this.webBrowser.GetContentDOMWindow((int[])localObject1);
          if (j != 0) {
            error(j);
          }
          if (localObject1[0] == 0) {
            error(-2147467262);
          }
          boolean bool1 = localObject1[0] == arrayOfInt1[0];
          new nsISupports(localObject1[0]).Release();
          localObject1[0] = 0;
          nsIDOMWindow localnsIDOMWindow1 = new nsIDOMWindow(arrayOfInt1[0]);
          j = localnsIDOMWindow1.QueryInterface(IIDStore.GetIID(nsIDOMEventTarget.class), (int[])localObject1);
          localnsIDOMWindow1.Release();
          if (j != 0) {
            error(j);
          }
          if (localObject1[0] == 0) {
            error(-2147467262);
          }
          nsIDOMEventTarget localnsIDOMEventTarget2 = new nsIDOMEventTarget(localObject1[0]);
          hookDOMListeners(localnsIDOMEventTarget2, bool1);
          localnsIDOMEventTarget2.Release();
          localObject1[0] = 0;
          this.unhookedDOMWindows.remove(localLONG);
          new nsISupports(localLONG.value).Release();
        }
        int i3 = 0;
        int i5;
        if (this.htmlBytes != null)
        {
          localObject6 = new nsIRequest(paramInt2);
          i5 = XPCOM.nsEmbedCString_new();
          j = ((nsIRequest)localObject6).GetName(i5);
          if (j != 0) {
            error(j);
          }
          int i7 = XPCOM.nsEmbedCString_Length(i5);
          int i9 = XPCOM.nsEmbedCString_get(i5);
          byte[] arrayOfByte1 = new byte[i7];
          XPCOM.memmove(arrayOfByte1, i9, i7);
          String str2 = new String(arrayOfByte1);
          XPCOM.nsEmbedCString_delete(i5);
          if (str2.startsWith("about:blank"))
          {
            unhookDOMListeners();
            j = XPCOM.NS_GetServiceManager((int[])localObject1);
            if (j != 0) {
              error(j);
            }
            if (localObject1[0] == 0) {
              error(-2147467262);
            }
            nsIServiceManager localnsIServiceManager = new nsIServiceManager(localObject1[0]);
            localObject1[0] = 0;
            j = localnsIServiceManager.GetService(XPCOM.NS_IOSERVICE_CID, IIDStore.GetIID(nsIIOService.class), (int[])localObject1);
            if (j != 0) {
              error(j);
            }
            if (localObject1[0] == 0) {
              error(-2147467262);
            }
            localnsIServiceManager.Release();
            nsIIOService localnsIIOService = new nsIIOService(localObject1[0]);
            localObject1[0] = 0;
            byte[] arrayOfByte2;
            if (this.untrustedText) {
              arrayOfByte2 = MozillaDelegate.wcsToMbcs(null, "about:blank", false);
            } else {
              arrayOfByte2 = MozillaDelegate.wcsToMbcs(null, "file:///", false);
            }
            int i10 = XPCOM.nsEmbedCString_new(arrayOfByte2, arrayOfByte2.length);
            j = localnsIIOService.NewURI(i10, null, 0, (int[])localObject1);
            if (j != 0) {
              error(j);
            }
            if (localObject1[0] == 0) {
              error(-2147467262);
            }
            XPCOM.nsEmbedCString_delete(i10);
            localnsIIOService.Release();
            nsIURI localnsIURI = new nsIURI(localObject1[0]);
            localObject1[0] = 0;
            j = this.webBrowser.QueryInterface(IIDStore.GetIID(nsIWebBrowserStream.class), (int[])localObject1);
            if (j != 0) {
              error(j);
            }
            if (localObject1[0] == 0) {
              error(-2147467262);
            }
            nsIWebBrowserStream localnsIWebBrowserStream = new nsIWebBrowserStream(localObject1[0]);
            localObject1[0] = 0;
            byte[] arrayOfByte3 = MozillaDelegate.wcsToMbcs(null, "text/html", false);
            int i11 = XPCOM.nsEmbedCString_new(arrayOfByte3, arrayOfByte3.length);
            j = localnsIWebBrowserStream.OpenStream(localnsIURI.getAddress(), i11);
            if (j != 0) {
              error(j);
            }
            Enumeration localEnumeration = this.functions.elements();
            while (localEnumeration.hasMoreElements())
            {
              BrowserFunction localBrowserFunction2 = (BrowserFunction)localEnumeration.nextElement();
              if (!localBrowserFunction2.isEvaluate) {
                execute(localBrowserFunction2.functionString);
              }
            }
            this.registerFunctionsOnState = 65537;
            int i12 = C.malloc(this.htmlBytes.length);
            XPCOM.memmove(i12, this.htmlBytes, this.htmlBytes.length);
            int i13 = 8192;
            int i14 = this.htmlBytes.length / i13 + 1;
            int i15 = i12;
            for (int i16 = 0; i16 < i14; i16++)
            {
              i7 = i16 == i14 - 1 ? this.htmlBytes.length % i13 : i13;
              if (i7 > 0)
              {
                j = localnsIWebBrowserStream.AppendToStream(i15, i7);
                if (j != 0) {
                  error(j);
                }
              }
              i15 += i13;
            }
            j = localnsIWebBrowserStream.CloseStream();
            if (j != 0) {
              error(j);
            }
            C.free(i12);
            XPCOM.nsEmbedCString_delete(i11);
            localnsIWebBrowserStream.Release();
            localnsIURI.Release();
            this.htmlBytes = null;
            i3 = 1;
            int[] arrayOfInt2 = new int[1];
            nsIWebProgress localnsIWebProgress = new nsIWebProgress(paramInt1);
            j = localnsIWebProgress.GetDOMWindow(arrayOfInt2);
            if (j != 0) {
              error(j);
            }
            if (arrayOfInt2[0] == 0) {
              error(-2147467262);
            }
            j = this.webBrowser.GetContentDOMWindow((int[])localObject1);
            if (j != 0) {
              error(j);
            }
            if (localObject1[0] == 0) {
              error(-2147467262);
            }
            boolean bool3 = localObject1[0] == arrayOfInt2[0];
            new nsISupports(localObject1[0]).Release();
            localObject1[0] = 0;
            nsIDOMWindow localnsIDOMWindow2 = new nsIDOMWindow(arrayOfInt2[0]);
            j = localnsIDOMWindow2.QueryInterface(IIDStore.GetIID(nsIDOMEventTarget.class), (int[])localObject1);
            localnsIDOMWindow2.Release();
            if (j != 0) {
              error(j);
            }
            if (localObject1[0] == 0) {
              error(-2147467262);
            }
            nsIDOMEventTarget localnsIDOMEventTarget3 = new nsIDOMEventTarget(localObject1[0]);
            hookDOMListeners(localnsIDOMEventTarget3, bool3);
            localnsIDOMEventTarget3.Release();
            localObject1[0] = 0;
          }
          else
          {
            this.registerFunctionsOnState = 0;
          }
        }
        if ((this.request == paramInt2) || (this.request == 0))
        {
          this.request = 0;
          localObject6 = new StatusTextEvent(this.browser);
          ((StatusTextEvent)localObject6).display = this.browser.getDisplay();
          ((StatusTextEvent)localObject6).widget = this.browser;
          ((StatusTextEvent)localObject6).text = "";
          for (i5 = 0; i5 < this.statusTextListeners.length; i5++) {
            this.statusTextListeners[i5].changed((StatusTextEvent)localObject6);
          }
          Display localDisplay = this.browser.getDisplay();
          final ProgressEvent localProgressEvent = new ProgressEvent(this.browser);
          localProgressEvent.display = localDisplay;
          localProgressEvent.widget = this.browser;
          localObject7 = new Runnable()
          {
            public void run()
            {
              if (Mozilla.this.browser.isDisposed()) {
                return;
              }
              for (int i = 0; i < Mozilla.this.progressListeners.length; i++) {
                Mozilla.this.progressListeners[i].completed(localProgressEvent);
              }
            }
          };
          if (i3 != 0) {
            localDisplay.asyncExec((Runnable)localObject7);
          } else {
            localDisplay.syncExec((Runnable)localObject7);
          }
        }
      }
      else if ((paramInt3 & 0x4) != 0)
      {
        if (MozillaVersion.CheckVersion(5)) {
          this.registerFunctionsOnState = 65552;
        }
        int i6;
        if (this.updateLastNavigateUrl)
        {
          this.updateLastNavigateUrl = false;
          localObject1 = new nsIRequest(paramInt2);
          localObject3 = new int[1];
          m = ((nsIRequest)localObject1).QueryInterface(IIDStore.GetIID(nsIChannel.class), (int[])localObject3);
          if ((m == 0) && (localObject3[0] != 0))
          {
            localObject4 = new nsIChannel(localObject3[0]);
            localObject3[0] = 0;
            m = ((nsIChannel)localObject4).GetURI((int[])localObject3);
            if (m != 0) {
              error(m);
            }
            if (localObject3[0] == 0) {
              error(-2147467261);
            }
            ((nsIChannel)localObject4).Release();
            localObject5 = new nsIURI(localObject3[0]);
            localObject3[0] = 0;
            i4 = XPCOM.nsEmbedCString_new();
            m = ((nsIURI)localObject5).GetSpec(i4);
            if (m != 0) {
              error(m);
            }
            i6 = XPCOM.nsEmbedCString_Length(i4);
            int i8 = XPCOM.nsEmbedCString_get(i4);
            localObject7 = new byte[i6];
            XPCOM.memmove((byte[])localObject7, i8, i6);
            this.lastNavigateURL = new String((byte[])localObject7);
            XPCOM.nsEmbedCString_delete(i4);
            ((nsIURI)localObject5).Release();
          }
        }
        localObject1 = new int[1];
        Object localObject3 = new nsIWebProgress(paramInt1);
        int m = ((nsIWebProgress)localObject3).GetDOMWindow((int[])localObject1);
        if (m != 0) {
          error(m);
        }
        if (localObject1[0] == 0) {
          error(-2147467262);
        }
        Object localObject4 = new nsIDOMWindow(localObject1[0]);
        Object localObject5 = new LONG(localObject1[0]);
        localObject1[0] = 0;
        int i4 = this.unhookedDOMWindows.indexOf(localObject5);
        if (i4 != -1)
        {
          m = this.webBrowser.GetContentDOMWindow((int[])localObject1);
          if (m != 0) {
            error(m);
          }
          if (localObject1[0] == 0) {
            error(-2147467262);
          }
          i6 = localObject1[0] == ((nsIDOMWindow)localObject4).getAddress() ? 1 : 0;
          new nsISupports(localObject1[0]).Release();
          localObject1[0] = 0;
          m = ((nsIDOMWindow)localObject4).QueryInterface(IIDStore.GetIID(nsIDOMEventTarget.class), (int[])localObject1);
          if (m != 0) {
            error(m);
          }
          if (localObject1[0] == 0) {
            error(-2147467262);
          }
          nsIDOMEventTarget localnsIDOMEventTarget1 = new nsIDOMEventTarget(localObject1[0]);
          hookDOMListeners(localnsIDOMEventTarget1, i6);
          localnsIDOMEventTarget1.Release();
          localObject1[0] = 0;
          this.unhookedDOMWindows.remove(localObject5);
          new nsISupports(((LONG)localObject5).value).Release();
        }
        ((nsIDOMWindow)localObject4).Release();
      }
    }
    return 0;
  }
  
  int OnProgressChange(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6)
  {
    if (this.progressListeners.length == 0) {
      return 0;
    }
    ProgressEvent localProgressEvent = new ProgressEvent(this.browser);
    localProgressEvent.display = this.browser.getDisplay();
    localProgressEvent.widget = this.browser;
    localProgressEvent.current = paramInt5;
    localProgressEvent.total = paramInt6;
    for (int i = 0; i < this.progressListeners.length; i++) {
      this.progressListeners[i].changed(localProgressEvent);
    }
    return 0;
  }
  
  int OnLocationChange(int paramInt1, int paramInt2, int paramInt3)
  {
    return OnLocationChange(paramInt1, paramInt2, paramInt3, 0);
  }
  
  int OnLocationChange(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    if ((this.request != 0) && (this.request != paramInt2)) {
      this.request = paramInt2;
    }
    if (this.locationListeners.length == 0) {
      return 0;
    }
    nsIWebProgress localnsIWebProgress = new nsIWebProgress(paramInt1);
    int[] arrayOfInt1 = new int[1];
    int i = localnsIWebProgress.GetDOMWindow(arrayOfInt1);
    if (i != 0) {
      error(i);
    }
    if (arrayOfInt1[0] == 0) {
      error(-2147467262);
    }
    int[] arrayOfInt2 = new int[1];
    nsIDOMWindow localnsIDOMWindow1 = new nsIDOMWindow(arrayOfInt1[0]);
    i = localnsIDOMWindow1.GetTop(arrayOfInt2);
    localnsIDOMWindow1.Release();
    if (i != 0) {
      error(i);
    }
    if (arrayOfInt2[0] == 0) {
      error(-2147467262);
    }
    nsIDOMWindow localnsIDOMWindow2 = new nsIDOMWindow(arrayOfInt2[0]);
    localnsIDOMWindow2.Release();
    nsIURI localnsIURI = new nsIURI(paramInt3);
    int j = XPCOM.nsEmbedCString_new();
    localnsIURI.GetSpec(j);
    int k = XPCOM.nsEmbedCString_Length(j);
    int m = XPCOM.nsEmbedCString_get(j);
    byte[] arrayOfByte = new byte[k];
    XPCOM.memmove(arrayOfByte, m, k);
    XPCOM.nsEmbedCString_delete(j);
    String str = new String(arrayOfByte);
    if ((MozillaVersion.CheckVersion(1)) && (paramInt2 == 0) && (str.startsWith("about:blank"))) {
      return 0;
    }
    LocationEvent localLocationEvent = new LocationEvent(this.browser);
    localLocationEvent.display = this.browser.getDisplay();
    localLocationEvent.widget = this.browser;
    localLocationEvent.location = str;
    if (localLocationEvent.location.equals("file:///"))
    {
      localLocationEvent.location = "about:blank";
    }
    else
    {
      k = "file:///".length();
      if ((localLocationEvent.location.startsWith("file:///")) && (localLocationEvent.location.charAt(k) == '#')) {
        localLocationEvent.location = ("about:blank" + localLocationEvent.location.substring(k));
      }
    }
    localLocationEvent.top = (arrayOfInt2[0] == arrayOfInt1[0]);
    for (int n = 0; n < this.locationListeners.length; n++) {
      this.locationListeners[n].changed(localLocationEvent);
    }
    return 0;
  }
  
  int OnStatusChange(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    if (this.statusTextListeners.length == 0) {
      return 0;
    }
    StatusTextEvent localStatusTextEvent = new StatusTextEvent(this.browser);
    localStatusTextEvent.display = this.browser.getDisplay();
    localStatusTextEvent.widget = this.browser;
    int i = XPCOM.strlen_PRUnichar(paramInt4);
    char[] arrayOfChar = new char[i];
    XPCOM.memmove(arrayOfChar, paramInt4, i * 2);
    localStatusTextEvent.text = new String(arrayOfChar);
    for (int j = 0; j < this.statusTextListeners.length; j++) {
      this.statusTextListeners[j].changed(localStatusTextEvent);
    }
    return 0;
  }
  
  int OnSecurityChange(int paramInt1, int paramInt2, int paramInt3)
  {
    return 0;
  }
  
  int SetStatus(int paramInt1, int paramInt2)
  {
    if (this.statusTextListeners.length == 0) {
      return 0;
    }
    StatusTextEvent localStatusTextEvent = new StatusTextEvent(this.browser);
    localStatusTextEvent.display = this.browser.getDisplay();
    localStatusTextEvent.widget = this.browser;
    int i = XPCOM.strlen_PRUnichar(paramInt2);
    char[] arrayOfChar = new char[i];
    XPCOM.memmove(arrayOfChar, paramInt2, i * 2);
    String str = new String(arrayOfChar);
    localStatusTextEvent.text = str;
    for (int j = 0; j < this.statusTextListeners.length; j++) {
      this.statusTextListeners[j].changed(localStatusTextEvent);
    }
    return 0;
  }
  
  int GetWebBrowser(int paramInt)
  {
    int[] arrayOfInt = new int[1];
    if (this.webBrowser != null)
    {
      this.webBrowser.AddRef();
      arrayOfInt[0] = this.webBrowser.getAddress();
    }
    XPCOM.memmove(paramInt, arrayOfInt, C.PTR_SIZEOF);
    return 0;
  }
  
  int SetWebBrowser(int paramInt)
  {
    if (this.webBrowser != null) {
      this.webBrowser.Release();
    }
    this.webBrowser = (paramInt != 0 ? new nsIWebBrowser(paramInt) : null);
    return 0;
  }
  
  int GetChromeFlags(int paramInt)
  {
    int[] arrayOfInt = new int[1];
    arrayOfInt[0] = this.chromeFlags;
    XPCOM.memmove(paramInt, arrayOfInt, 4);
    return 0;
  }
  
  int SetChromeFlags(int paramInt)
  {
    this.chromeFlags = paramInt;
    return 0;
  }
  
  int DestroyBrowserWindow()
  {
    WindowEvent localWindowEvent = new WindowEvent(this.browser);
    localWindowEvent.display = this.browser.getDisplay();
    localWindowEvent.widget = this.browser;
    for (int i = 0; i < this.closeWindowListeners.length; i++) {
      this.closeWindowListeners[i].close(localWindowEvent);
    }
    this.browser.dispose();
    return 0;
  }
  
  int SizeBrowserTo(int paramInt1, int paramInt2)
  {
    this.size = new Point(paramInt1, paramInt2);
    int i = (this.chromeFlags & 0x80000000) != 0 ? 1 : 0;
    if (i != 0)
    {
      Shell localShell = this.browser.getShell();
      localShell.setSize(localShell.computeSize(this.size.x, this.size.y));
    }
    return 0;
  }
  
  int ShowAsModal()
  {
    int[] arrayOfInt = new int[1];
    int i = XPCOM.NS_GetServiceManager(arrayOfInt);
    if (i != 0) {
      error(i);
    }
    if (arrayOfInt[0] == 0) {
      error(-2147467262);
    }
    nsIServiceManager localnsIServiceManager = new nsIServiceManager(arrayOfInt[0]);
    arrayOfInt[0] = 0;
    byte[] arrayOfByte = MozillaDelegate.wcsToMbcs(null, "@mozilla.org/js/xpc/ContextStack;1", true);
    i = localnsIServiceManager.GetServiceByContractID(arrayOfByte, IIDStore.GetIID(nsIJSContextStack.class), arrayOfInt);
    if (i != 0) {
      error(i);
    }
    if (arrayOfInt[0] == 0) {
      error(-2147467262);
    }
    localnsIServiceManager.Release();
    nsIJSContextStack localnsIJSContextStack = new nsIJSContextStack(arrayOfInt[0]);
    arrayOfInt[0] = 0;
    i = localnsIJSContextStack.Push(0);
    if (i != 0) {
      error(i);
    }
    Shell localShell = this.browser.getShell();
    Display localDisplay = this.browser.getDisplay();
    while (!localShell.isDisposed()) {
      if (!localDisplay.readAndDispatch()) {
        localDisplay.sleep();
      }
    }
    i = localnsIJSContextStack.Pop(arrayOfInt);
    if (i != 0) {
      error(i);
    }
    localnsIJSContextStack.Release();
    return 0;
  }
  
  int IsWindowModal(int paramInt)
  {
    int i = (this.chromeFlags & 0x20000000) != 0 ? 1 : 0;
    XPCOM.memmove(paramInt, new boolean[] { i });
    return 0;
  }
  
  int ExitModalEventLoop(int paramInt)
  {
    return 0;
  }
  
  int SetDimensions(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
  {
    int i = (this.chromeFlags & 0x80000000) != 0 ? 1 : 0;
    if ((paramInt1 & 0x1) != 0)
    {
      this.location = new Point(paramInt2, paramInt3);
      if (i != 0) {
        this.browser.getShell().setLocation(paramInt2, paramInt3);
      }
    }
    if ((paramInt1 & 0x2) != 0)
    {
      this.size = new Point(paramInt4, paramInt5);
      if (i != 0) {
        this.browser.setSize(paramInt4, paramInt5);
      }
    }
    if (((paramInt1 & 0x4) != 0) && (i != 0)) {
      this.browser.getShell().setSize(paramInt4, paramInt5);
    }
    return 0;
  }
  
  int GetDimensions(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
  {
    Point localPoint;
    if ((paramInt1 & 0x1) != 0)
    {
      localPoint = this.browser.getShell().getLocation();
      if (paramInt2 != 0) {
        C.memmove(paramInt2, new int[] { localPoint.x }, 4);
      }
      if (paramInt3 != 0) {
        C.memmove(paramInt3, new int[] { localPoint.y }, 4);
      }
    }
    if ((paramInt1 & 0x2) != 0)
    {
      localPoint = this.browser.getSize();
      if (paramInt4 != 0) {
        C.memmove(paramInt4, new int[] { localPoint.x }, 4);
      }
      if (paramInt5 != 0) {
        C.memmove(paramInt5, new int[] { localPoint.y }, 4);
      }
    }
    if ((paramInt1 & 0x4) != 0)
    {
      localPoint = this.browser.getShell().getSize();
      if (paramInt4 != 0) {
        C.memmove(paramInt4, new int[] { localPoint.x }, 4);
      }
      if (paramInt5 != 0) {
        C.memmove(paramInt5, new int[] { localPoint.y }, 4);
      }
    }
    return 0;
  }
  
  int SetFocus()
  {
    int[] arrayOfInt = new int[1];
    int i = this.webBrowser.QueryInterface(IIDStore.GetIID(nsIBaseWindow.class), arrayOfInt);
    if (i != 0)
    {
      this.browser.dispose();
      error(i);
    }
    if (arrayOfInt[0] == 0) {
      error(-2147467262);
    }
    nsIBaseWindow localnsIBaseWindow = new nsIBaseWindow(arrayOfInt[0]);
    i = localnsIBaseWindow.SetFocus();
    if (i != 0) {
      error(i);
    }
    localnsIBaseWindow.Release();
    return 0;
  }
  
  int GetVisibility(int paramInt)
  {
    int i = (this.browser.isVisible()) && (!this.browser.getShell().getMinimized()) ? 1 : 0;
    XPCOM.memmove(paramInt, new boolean[] { i });
    return 0;
  }
  
  int SetVisibility(int paramInt)
  {
    if (this.isChild)
    {
      WindowEvent localWindowEvent = new WindowEvent(this.browser);
      localWindowEvent.display = this.browser.getDisplay();
      localWindowEvent.widget = this.browser;
      int i;
      if (paramInt != 0)
      {
        if (!this.visible)
        {
          this.visible = true;
          localWindowEvent.location = this.location;
          localWindowEvent.size = this.size;
          localWindowEvent.addressBar = ((this.chromeFlags & 0x40) != 0);
          i = ("win32".equals("cocoa")) || ("win32".equals("carbon")) ? 1 : 0;
          localWindowEvent.menuBar = ((i != 0) || ((this.chromeFlags & 0x10) != 0));
          localWindowEvent.statusBar = ((this.chromeFlags & 0x80) != 0);
          localWindowEvent.toolBar = ((this.chromeFlags & 0x20) != 0);
          for (int j = 0; j < this.visibilityWindowListeners.length; j++) {
            this.visibilityWindowListeners[j].show(localWindowEvent);
          }
          this.location = null;
          this.size = null;
        }
      }
      else
      {
        this.visible = false;
        for (i = 0; i < this.visibilityWindowListeners.length; i++) {
          this.visibilityWindowListeners[i].hide(localWindowEvent);
        }
      }
    }
    return 0;
  }
  
  int GetTitle(int paramInt)
  {
    return 0;
  }
  
  int SetTitle(int paramInt)
  {
    if (this.titleListeners.length == 0) {
      return 0;
    }
    TitleEvent localTitleEvent = new TitleEvent(this.browser);
    localTitleEvent.display = this.browser.getDisplay();
    localTitleEvent.widget = this.browser;
    int i = XPCOM.strlen_PRUnichar(paramInt);
    if (i > 0)
    {
      char[] arrayOfChar = new char[i];
      XPCOM.memmove(arrayOfChar, paramInt, i * 2);
      localTitleEvent.title = new String(arrayOfChar);
    }
    else
    {
      localTitleEvent.title = getUrl();
    }
    for (int j = 0; j < this.titleListeners.length; j++) {
      this.titleListeners[j].changed(localTitleEvent);
    }
    return 0;
  }
  
  int GetSiteWindow(int paramInt)
  {
    int i = this.delegate.getSiteWindow();
    XPCOM.memmove(paramInt, new int[] { i }, C.PTR_SIZEOF);
    return 0;
  }
  
  int Blur()
  {
    return 0;
  }
  
  int FocusNextElement()
  {
    this.browser.getDisplay().asyncExec(new Runnable()
    {
      public void run()
      {
        if (Mozilla.this.browser.isDisposed()) {
          return;
        }
        Mozilla.this.browser.traverse(16);
      }
    });
    return 0;
  }
  
  int FocusPrevElement()
  {
    this.browser.getDisplay().asyncExec(new Runnable()
    {
      public void run()
      {
        if (Mozilla.this.browser.isDisposed()) {
          return;
        }
        Mozilla.this.browser.traverse(8);
      }
    });
    return 0;
  }
  
  int OnShowContextMenu(int paramInt1, int paramInt2, int paramInt3)
  {
    nsIDOMEvent localnsIDOMEvent = new nsIDOMEvent(paramInt2);
    int[] arrayOfInt1 = new int[1];
    int i = localnsIDOMEvent.QueryInterface(IIDStore.GetIID(nsIDOMMouseEvent.class), arrayOfInt1);
    if (i != 0) {
      error(i);
    }
    if (arrayOfInt1[0] == 0) {
      error(-2147467262);
    }
    int[] arrayOfInt2 = new int[1];
    int[] arrayOfInt3 = new int[1];
    nsIDOMMouseEvent localnsIDOMMouseEvent = new nsIDOMMouseEvent(arrayOfInt1[0]);
    i = localnsIDOMMouseEvent.GetScreenX(arrayOfInt2);
    if (i != 0) {
      error(i);
    }
    i = localnsIDOMMouseEvent.GetScreenY(arrayOfInt3);
    if (i != 0) {
      error(i);
    }
    localnsIDOMMouseEvent.Release();
    Event localEvent = new Event();
    localEvent.x = arrayOfInt2[0];
    localEvent.y = arrayOfInt3[0];
    this.browser.notifyListeners(35, localEvent);
    if ((!localEvent.doit) || (this.browser.isDisposed())) {
      return 0;
    }
    Menu localMenu = this.browser.getMenu();
    if ((localMenu != null) && (!localMenu.isDisposed()))
    {
      if ((arrayOfInt2[0] != localEvent.x) || (arrayOfInt3[0] != localEvent.y)) {
        localMenu.setLocation(localEvent.x, localEvent.y);
      }
      localMenu.setVisible(true);
    }
    return 0;
  }
  
  int OnStartURIOpen(int paramInt1, int paramInt2)
  {
    if (this.isRetrievingBadCert) {
      return 0;
    }
    this.authCount = 0;
    nsIURI localnsIURI = new nsIURI(paramInt1);
    int i = XPCOM.nsEmbedCString_new();
    localnsIURI.GetSpec(i);
    int j = XPCOM.nsEmbedCString_Length(i);
    int k = XPCOM.nsEmbedCString_get(i);
    k = XPCOM.nsEmbedCString_get(i);
    byte[] arrayOfByte = new byte[j];
    XPCOM.memmove(arrayOfByte, k, j);
    XPCOM.nsEmbedCString_delete(i);
    String str = new String(arrayOfByte);
    if ((str.indexOf("aboutCertError.xhtml") != -1) || ((this.isViewingErrorPage) && (str.indexOf("javascript:showSecuritySection") != -1)))
    {
      XPCOM.memmove(paramInt2, new boolean[] { true });
      this.isRetrievingBadCert = true;
      setUrl(this.lastNavigateURL, (byte[])null, null);
      return 0;
    }
    boolean bool = sendChangingEvent(str);
    XPCOM.memmove(paramInt2, new boolean[] { !bool ? 1 : 0 });
    return 0;
  }
  
  int DoContent(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
  {
    return -2147467263;
  }
  
  int IsPreferred(int paramInt1, int paramInt2, int paramInt3)
  {
    int i = 0;
    int j = XPCOM.strlen(paramInt1);
    if (j > 0)
    {
      byte[] arrayOfByte1 = new byte[j + 1];
      XPCOM.memmove(arrayOfByte1, paramInt1, j);
      String str = new String(arrayOfByte1, 0, j);
      if ((!str.equals("application/x-vnd.mozilla.maybe-text")) && (!str.equals("multipart/x-mixed-replace")))
      {
        int[] arrayOfInt1 = new int[1];
        int k = XPCOM.NS_GetServiceManager(arrayOfInt1);
        if (k != 0) {
          error(k);
        }
        if (arrayOfInt1[0] == 0) {
          error(-2147467262);
        }
        nsIServiceManager localnsIServiceManager = new nsIServiceManager(arrayOfInt1[0]);
        arrayOfInt1[0] = 0;
        byte[] arrayOfByte2 = MozillaDelegate.wcsToMbcs(null, "@mozilla.org/webnavigation-info;1", true);
        k = localnsIServiceManager.GetServiceByContractID(arrayOfByte2, IIDStore.GetIID(nsIWebNavigationInfo.class), arrayOfInt1);
        Object localObject;
        if (k == 0)
        {
          localObject = MozillaDelegate.wcsToMbcs(null, str, false);
          int m = XPCOM.nsEmbedCString_new((byte[])localObject, localObject.length);
          nsIWebNavigationInfo localnsIWebNavigationInfo = new nsIWebNavigationInfo(arrayOfInt1[0]);
          arrayOfInt1[0] = 0;
          int[] arrayOfInt2 = new int[1];
          k = localnsIWebNavigationInfo.IsTypeSupported(m, 0, arrayOfInt2);
          if (k != 0) {
            error(k);
          }
          localnsIWebNavigationInfo.Release();
          XPCOM.nsEmbedCString_delete(m);
          i = arrayOfInt2[0] != 0 ? 1 : 0;
        }
        else
        {
          arrayOfInt1[0] = 0;
          k = localnsIServiceManager.GetService(XPCOM.NS_CATEGORYMANAGER_CID, IIDStore.GetIID(nsICategoryManager.class), arrayOfInt1);
          if (k != 0) {
            error(k);
          }
          if (arrayOfInt1[0] == 0) {
            error(-2147467262);
          }
          localObject = new nsICategoryManager(arrayOfInt1[0]);
          arrayOfInt1[0] = 0;
          byte[] arrayOfByte3 = MozillaDelegate.wcsToMbcs(null, "Gecko-Content-Viewers", true);
          k = ((nsICategoryManager)localObject).GetCategoryEntry(arrayOfByte3, arrayOfByte1, arrayOfInt1);
          ((nsICategoryManager)localObject).Release();
          i = k == 0 ? 1 : 0;
        }
        localnsIServiceManager.Release();
      }
    }
    XPCOM.memmove(paramInt3, new boolean[] { i });
    if (i != 0) {
      XPCOM.memmove(paramInt2, new int[] { 0 }, C.PTR_SIZEOF);
    }
    return 0;
  }
  
  int CanHandleContent(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    return -2147467263;
  }
  
  int GetLoadCookie(int paramInt)
  {
    return -2147467263;
  }
  
  int SetLoadCookie(int paramInt)
  {
    return -2147467263;
  }
  
  int GetParentContentListener(int paramInt)
  {
    return -2147467263;
  }
  
  int SetParentContentListener(int paramInt)
  {
    return -2147467263;
  }
  
  int OnShowTooltip(int paramInt1, int paramInt2, int paramInt3)
  {
    int i = XPCOM.strlen_PRUnichar(paramInt3);
    char[] arrayOfChar = new char[i];
    XPCOM.memmove(arrayOfChar, paramInt3, i * 2);
    String str = new String(arrayOfChar);
    if ((this.tip != null) && (!this.tip.isDisposed())) {
      this.tip.dispose();
    }
    Display localDisplay = this.browser.getDisplay();
    Shell localShell = this.browser.getShell();
    this.tip = new Shell(localShell, 16384);
    this.tip.setLayout(new FillLayout());
    Label localLabel = new Label(this.tip, 16777216);
    localLabel.setForeground(localDisplay.getSystemColor(28));
    localLabel.setBackground(localDisplay.getSystemColor(29));
    localLabel.setText(str);
    Point localPoint = localDisplay.getCursorLocation();
    localPoint.y += 21;
    this.tip.setLocation(localPoint);
    this.tip.pack();
    this.tip.setVisible(true);
    return 0;
  }
  
  int OnHideTooltip()
  {
    if ((this.tip != null) && (!this.tip.isDisposed())) {
      this.tip.dispose();
    }
    this.tip = null;
    return 0;
  }
  
  int HandleEvent(int paramInt)
  {
    nsIDOMEvent localnsIDOMEvent = new nsIDOMEvent(paramInt);
    int i = XPCOM.nsEmbedString_new();
    int j = localnsIDOMEvent.GetType(i);
    if (j != 0) {
      error(j);
    }
    int k = XPCOM.nsEmbedString_Length(i);
    int m = XPCOM.nsEmbedString_get(i);
    char[] arrayOfChar = new char[k];
    XPCOM.memmove(arrayOfChar, m, k * 2);
    String str = new String(arrayOfChar);
    XPCOM.nsEmbedString_delete(i);
    if ("unload".equals(str))
    {
      arrayOfInt1 = new int[1];
      j = localnsIDOMEvent.GetCurrentTarget(arrayOfInt1);
      if (j != 0) {
        error(j);
      }
      if (arrayOfInt1[0] == 0) {
        error(-2147467262);
      }
      localObject1 = new nsIDOMEventTarget(arrayOfInt1[0]);
      unhookDOMListeners((nsIDOMEventTarget)localObject1);
      ((nsIDOMEventTarget)localObject1).Release();
      return 0;
    }
    if ("focus".equals(str))
    {
      this.delegate.handleFocus();
      return 0;
    }
    if ("keydown".equals(str))
    {
      arrayOfInt1 = new int[1];
      j = localnsIDOMEvent.QueryInterface(IIDStore.GetIID(nsIDOMKeyEvent.class), arrayOfInt1);
      if (j != 0) {
        error(j);
      }
      if (arrayOfInt1[0] == 0) {
        error(-2147467262);
      }
      localObject1 = new nsIDOMKeyEvent(arrayOfInt1[0]);
      arrayOfInt1[0] = 0;
      arrayOfInt2 = new int[1];
      j = ((nsIDOMKeyEvent)localObject1).GetKeyCode(arrayOfInt2);
      if (j != 0) {
        error(j);
      }
      int n = translateKey(arrayOfInt2[0]);
      if (n != this.lastKeyCode)
      {
        this.lastKeyCode = n;
        Event localEvent1;
        switch (n)
        {
        case 65536: 
        case 131072: 
        case 262144: 
        case 4194304: 
        case 16777298: 
        case 16777299: 
        case 16777300: 
          localObject2 = new int[1];
          arrayOfInt5 = new int[1];
          localObject3 = new int[1];
          localObject4 = new int[1];
          j = ((nsIDOMKeyEvent)localObject1).GetAltKey((int[])localObject2);
          if (j != 0) {
            error(j);
          }
          j = ((nsIDOMKeyEvent)localObject1).GetCtrlKey(arrayOfInt5);
          if (j != 0) {
            error(j);
          }
          j = ((nsIDOMKeyEvent)localObject1).GetShiftKey((int[])localObject3);
          if (j != 0) {
            error(j);
          }
          j = ((nsIDOMKeyEvent)localObject1).GetMetaKey((int[])localObject4);
          if (j != 0) {
            error(j);
          }
          localEvent1 = new Event();
          localEvent1.widget = this.browser;
          localEvent1.type = 1;
          localEvent1.keyCode = n;
          localEvent1.stateMask = ((localObject2[0] != 0 ? 65536 : 0) | (arrayOfInt5[0] != 0 ? 262144 : 0) | (localObject3[0] != 0 ? 131072 : 0) | (localObject4[0] != 0 ? 4194304 : 0));
          localEvent1.stateMask &= (n ^ 0xFFFFFFFF);
          this.browser.notifyListeners(localEvent1.type, localEvent1);
          if ((!localEvent1.doit) || (this.browser.isDisposed())) {
            localnsIDOMEvent.PreventDefault();
          }
          break;
        default: 
          localObject2 = new int[1];
          j = ((nsIDOMKeyEvent)localObject1).GetMetaKey((int[])localObject2);
          if (j != 0) {
            error(j);
          }
          if (localObject2[0] != 0)
          {
            arrayOfInt5 = new int[1];
            j = ((nsIDOMKeyEvent)localObject1).GetCtrlKey(arrayOfInt5);
            if (j != 0) {
              error(j);
            }
            if (arrayOfInt5[0] == 0)
            {
              localObject3 = new int[1];
              localObject4 = new int[1];
              j = ((nsIDOMKeyEvent)localObject1).GetAltKey((int[])localObject3);
              if (j != 0) {
                error(j);
              }
              j = ((nsIDOMKeyEvent)localObject1).GetShiftKey((int[])localObject4);
              if (j != 0) {
                error(j);
              }
              localEvent1 = new Event();
              localEvent1.widget = this.browser;
              localEvent1.type = 1;
              localEvent1.keyCode = this.lastKeyCode;
              localEvent1.stateMask = ((localObject3[0] != 0 ? 65536 : 0) | (arrayOfInt5[0] != 0 ? 262144 : 0) | (localObject4[0] != 0 ? 131072 : 0) | (localObject2[0] != 0 ? 4194304 : 0));
              this.browser.notifyListeners(localEvent1.type, localEvent1);
              if ((!localEvent1.doit) || (this.browser.isDisposed())) {
                localnsIDOMEvent.PreventDefault();
              }
            }
          }
          break;
        }
      }
      ((nsIDOMKeyEvent)localObject1).Release();
      return 0;
    }
    if ("keypress".equals(str))
    {
      if (this.lastKeyCode == 0) {
        return 0;
      }
      switch (this.lastKeyCode)
      {
      case 16777298: 
      case 16777299: 
      case 16777300: 
        return 0;
      }
      arrayOfInt1 = new int[1];
      j = localnsIDOMEvent.QueryInterface(IIDStore.GetIID(nsIDOMKeyEvent.class), arrayOfInt1);
      if (j != 0) {
        error(j);
      }
      if (arrayOfInt1[0] == 0) {
        error(-2147467262);
      }
      localObject1 = new nsIDOMKeyEvent(arrayOfInt1[0]);
      arrayOfInt1[0] = 0;
      arrayOfInt2 = new int[1];
      int[] arrayOfInt3 = new int[1];
      localObject2 = new int[1];
      arrayOfInt5 = new int[1];
      j = ((nsIDOMKeyEvent)localObject1).GetAltKey(arrayOfInt2);
      if (j != 0) {
        error(j);
      }
      j = ((nsIDOMKeyEvent)localObject1).GetCtrlKey(arrayOfInt3);
      if (j != 0) {
        error(j);
      }
      j = ((nsIDOMKeyEvent)localObject1).GetShiftKey((int[])localObject2);
      if (j != 0) {
        error(j);
      }
      j = ((nsIDOMKeyEvent)localObject1).GetMetaKey(arrayOfInt5);
      if (j != 0) {
        error(j);
      }
      localObject3 = new int[1];
      j = ((nsIDOMKeyEvent)localObject1).GetCharCode((int[])localObject3);
      if (j != 0) {
        error(j);
      }
      ((nsIDOMKeyEvent)localObject1).Release();
      this.lastCharCode = localObject3[0];
      if (this.lastCharCode == 0) {
        switch (this.lastKeyCode)
        {
        case 9: 
          this.lastCharCode = 9;
          break;
        case 13: 
          this.lastCharCode = 13;
          break;
        case 8: 
          this.lastCharCode = 8;
          break;
        case 27: 
          this.lastCharCode = 27;
          break;
        case 127: 
          this.lastCharCode = 127;
        }
      }
      if ((arrayOfInt3[0] != 0) && (0 <= this.lastCharCode) && (this.lastCharCode <= 127))
      {
        if ((97 <= this.lastCharCode) && (this.lastCharCode <= 122)) {
          this.lastCharCode -= 32;
        }
        if ((64 <= this.lastCharCode) && (this.lastCharCode <= 95)) {
          this.lastCharCode -= 64;
        }
      }
      localObject4 = new Event();
      ((Event)localObject4).widget = this.browser;
      ((Event)localObject4).type = 1;
      ((Event)localObject4).keyCode = this.lastKeyCode;
      ((Event)localObject4).character = ((char)this.lastCharCode);
      ((Event)localObject4).stateMask = ((arrayOfInt2[0] != 0 ? 65536 : 0) | (arrayOfInt3[0] != 0 ? 262144 : 0) | (localObject2[0] != 0 ? 131072 : 0) | (arrayOfInt5[0] != 0 ? 4194304 : 0));
      boolean bool = true;
      if (this.delegate.sendTraverse())
      {
        bool = sendKeyEvent((Event)localObject4);
      }
      else
      {
        this.browser.notifyListeners(((Event)localObject4).type, (Event)localObject4);
        bool = ((Event)localObject4).doit;
      }
      if ((!bool) || (this.browser.isDisposed())) {
        localnsIDOMEvent.PreventDefault();
      }
      return 0;
    }
    if ("keyup".equals(str))
    {
      arrayOfInt1 = new int[1];
      j = localnsIDOMEvent.QueryInterface(IIDStore.GetIID(nsIDOMKeyEvent.class), arrayOfInt1);
      if (j != 0) {
        error(j);
      }
      if (arrayOfInt1[0] == 0) {
        error(-2147467262);
      }
      localObject1 = new nsIDOMKeyEvent(arrayOfInt1[0]);
      arrayOfInt1[0] = 0;
      arrayOfInt2 = new int[1];
      j = ((nsIDOMKeyEvent)localObject1).GetKeyCode(arrayOfInt2);
      if (j != 0) {
        error(j);
      }
      int i1 = translateKey(arrayOfInt2[0]);
      if (i1 == 0)
      {
        ((nsIDOMKeyEvent)localObject1).Release();
        return 0;
      }
      if (i1 != this.lastKeyCode)
      {
        this.lastKeyCode = i1;
        this.lastCharCode = 0;
      }
      localObject2 = new int[1];
      arrayOfInt5 = new int[1];
      localObject3 = new int[1];
      localObject4 = new int[1];
      j = ((nsIDOMKeyEvent)localObject1).GetAltKey((int[])localObject2);
      if (j != 0) {
        error(j);
      }
      j = ((nsIDOMKeyEvent)localObject1).GetCtrlKey(arrayOfInt5);
      if (j != 0) {
        error(j);
      }
      j = ((nsIDOMKeyEvent)localObject1).GetShiftKey((int[])localObject3);
      if (j != 0) {
        error(j);
      }
      j = ((nsIDOMKeyEvent)localObject1).GetMetaKey((int[])localObject4);
      if (j != 0) {
        error(j);
      }
      ((nsIDOMKeyEvent)localObject1).Release();
      localObject5 = new Event();
      ((Event)localObject5).widget = this.browser;
      ((Event)localObject5).type = 2;
      ((Event)localObject5).keyCode = this.lastKeyCode;
      ((Event)localObject5).character = ((char)this.lastCharCode);
      ((Event)localObject5).stateMask = ((localObject2[0] != 0 ? 65536 : 0) | (arrayOfInt5[0] != 0 ? 262144 : 0) | (localObject3[0] != 0 ? 131072 : 0) | (localObject4[0] != 0 ? 4194304 : 0));
      switch (this.lastKeyCode)
      {
      case 65536: 
      case 131072: 
      case 262144: 
      case 4194304: 
        localObject5.stateMask |= this.lastKeyCode;
      }
      this.browser.notifyListeners(((Event)localObject5).type, (Event)localObject5);
      if ((!((Event)localObject5).doit) || (this.browser.isDisposed())) {
        localnsIDOMEvent.PreventDefault();
      }
      this.lastKeyCode = (this.lastCharCode = 0);
      return 0;
    }
    int[] arrayOfInt1 = new int[1];
    j = localnsIDOMEvent.QueryInterface(IIDStore.GetIID(nsIDOMMouseEvent.class), arrayOfInt1);
    if (j != 0) {
      error(j);
    }
    if (arrayOfInt1[0] == 0) {
      error(-2147467262);
    }
    Object localObject1 = new nsIDOMMouseEvent(arrayOfInt1[0]);
    arrayOfInt1[0] = 0;
    if (("mouseover".equals(str)) || ("mouseout".equals(str)))
    {
      j = ((nsIDOMMouseEvent)localObject1).GetRelatedTarget(arrayOfInt1);
      if (j != 0) {
        error(j);
      }
      if (arrayOfInt1[0] != 0)
      {
        new nsISupports(arrayOfInt1[0]).Release();
        ((nsIDOMMouseEvent)localObject1).Release();
        return 0;
      }
    }
    int[] arrayOfInt2 = new int[1];
    int[] arrayOfInt4 = new int[1];
    j = ((nsIDOMMouseEvent)localObject1).GetScreenX(arrayOfInt2);
    if (j != 0) {
      error(j);
    }
    j = ((nsIDOMMouseEvent)localObject1).GetScreenY(arrayOfInt4);
    if (j != 0) {
      error(j);
    }
    Object localObject2 = new Point(arrayOfInt2[0], arrayOfInt4[0]);
    localObject2 = this.browser.getDisplay().map(null, this.browser, (Point)localObject2);
    int[] arrayOfInt5 = new int[1];
    j = ((nsIDOMMouseEvent)localObject1).GetDetail(arrayOfInt5);
    if (j != 0) {
      error(j);
    }
    Object localObject3 = new short[1];
    j = ((nsIDOMMouseEvent)localObject1).GetButton((short[])localObject3);
    if (j != 0) {
      error(j);
    }
    Object localObject4 = new int[1];
    Object localObject5 = new int[1];
    int[] arrayOfInt6 = new int[1];
    int[] arrayOfInt7 = new int[1];
    j = ((nsIDOMMouseEvent)localObject1).GetAltKey((int[])localObject4);
    if (j != 0) {
      error(j);
    }
    j = ((nsIDOMMouseEvent)localObject1).GetCtrlKey((int[])localObject5);
    if (j != 0) {
      error(j);
    }
    j = ((nsIDOMMouseEvent)localObject1).GetShiftKey(arrayOfInt6);
    if (j != 0) {
      error(j);
    }
    j = ((nsIDOMMouseEvent)localObject1).GetMetaKey(arrayOfInt7);
    if (j != 0) {
      error(j);
    }
    ((nsIDOMMouseEvent)localObject1).Release();
    Event localEvent2 = new Event();
    localEvent2.widget = this.browser;
    localEvent2.x = ((Point)localObject2).x;
    localEvent2.y = ((Point)localObject2).y;
    localEvent2.stateMask = ((localObject4[0] != 0 ? 65536 : 0) | (localObject5[0] != 0 ? 262144 : 0) | (arrayOfInt6[0] != 0 ? 131072 : 0) | (arrayOfInt7[0] != 0 ? 4194304 : 0));
    if ("mousedown".equals(str))
    {
      this.delegate.handleMouseDown();
      localEvent2.type = 3;
      localEvent2.button = (localObject3[0] + 1);
      localEvent2.count = arrayOfInt5[0];
    }
    else if ("mouseup".equals(str))
    {
      int i2 = localObject3[0] + 1;
      int i3 = arrayOfInt5[0];
      if ((i3 == 0) && (i2 == 3)) {
        return 0;
      }
      localEvent2.type = 4;
      localEvent2.button = i2;
      localEvent2.count = i3;
    }
    else if ("mousemove".equals(str))
    {
      localEvent2.type = 5;
    }
    else if ("DOMMouseScroll".equals(str))
    {
      localEvent2.type = 37;
      localEvent2.count = (-arrayOfInt5[0]);
    }
    else if ("mouseover".equals(str))
    {
      localEvent2.type = 6;
    }
    else if ("mouseout".equals(str))
    {
      localEvent2.type = 7;
    }
    else if ("draggesture".equals(str))
    {
      localEvent2.type = 29;
      localEvent2.button = (localObject3[0] + 1);
      switch (localEvent2.button)
      {
      case 1: 
        localEvent2.stateMask |= 0x80000;
        break;
      case 2: 
        localEvent2.stateMask |= 0x100000;
        break;
      case 3: 
        localEvent2.stateMask |= 0x200000;
        break;
      case 4: 
        localEvent2.stateMask |= 0x800000;
        break;
      case 5: 
        localEvent2.stateMask |= 0x2000000;
      }
    }
    this.browser.notifyListeners(localEvent2.type, localEvent2);
    if (this.browser.isDisposed()) {
      return 0;
    }
    if ((arrayOfInt5[0] == 2) && ("mousedown".equals(str)))
    {
      localEvent2 = new Event();
      localEvent2.widget = this.browser;
      localEvent2.x = ((Point)localObject2).x;
      localEvent2.y = ((Point)localObject2).y;
      localEvent2.stateMask = ((localObject4[0] != 0 ? 65536 : 0) | (localObject5[0] != 0 ? 262144 : 0) | (arrayOfInt6[0] != 0 ? 131072 : 0) | (arrayOfInt7[0] != 0 ? 4194304 : 0));
      localEvent2.type = 8;
      localEvent2.button = (localObject3[0] + 1);
      localEvent2.count = arrayOfInt5[0];
      this.browser.notifyListeners(localEvent2.type, localEvent2);
    }
    return 0;
  }
  
  int NotifyCertProblem(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    int i = XPCOM.nsEmbedCString_Length(paramInt3);
    int j = XPCOM.nsEmbedCString_get(paramInt3);
    byte[] arrayOfByte = new byte[i];
    XPCOM.memmove(arrayOfByte, j, i);
    final String str1 = new String(arrayOfByte);
    int k = str1.indexOf(':');
    final String str2 = str1.substring(0, k);
    final int m = Integer.valueOf(str1.substring(k + 1)).intValue();
    int[] arrayOfInt1 = new int[1];
    nsISupports localnsISupports = new nsISupports(paramInt2);
    int n = localnsISupports.QueryInterface(IIDStore.GetIID(nsISSLStatus.class), arrayOfInt1);
    if (n != 0) {
      error(n);
    }
    if (arrayOfInt1[0] == 0) {
      error(-2147467262);
    }
    nsISSLStatus localnsISSLStatus = new nsISSLStatus(arrayOfInt1[0]);
    arrayOfInt1[0] = 0;
    n = localnsISSLStatus.GetServerCert(arrayOfInt1);
    if (n != 0) {
      error(n);
    }
    if (arrayOfInt1[0] == 0) {
      error(-2147467261);
    }
    final nsIX509Cert localnsIX509Cert = new nsIX509Cert(arrayOfInt1[0]);
    arrayOfInt1[0] = 0;
    String[] arrayOfString = new String[3];
    int i1 = 0;
    int i2 = 0;
    int[] arrayOfInt2 = new int[1];
    n = localnsISSLStatus.GetIsDomainMismatch(arrayOfInt2);
    if (arrayOfInt2[0] != 0)
    {
      int i3 = XPCOM.nsEmbedString_new();
      n = localnsIX509Cert.GetCommonName(i3);
      if (n != 0) {
        SWT.error(n);
      }
      i = XPCOM.nsEmbedString_Length(i3);
      j = XPCOM.nsEmbedString_get(i3);
      char[] arrayOfChar = new char[i];
      XPCOM.memmove(arrayOfChar, j, i * 2);
      localObject2 = new String(arrayOfChar);
      arrayOfString[(i1++)] = Compatibility.getMessage("SWT_InvalidCert_InvalidName", new String[] { localObject2 });
      i2 |= 0x2;
      XPCOM.nsEmbedString_delete(i3);
    }
    arrayOfInt2[0] = 0;
    n = localnsISSLStatus.GetIsNotValidAtThisTime(arrayOfInt2);
    if (arrayOfInt2[0] != 0)
    {
      n = localnsIX509Cert.GetValidity(arrayOfInt1);
      if (n != 0) {
        SWT.error(n);
      }
      if (arrayOfInt1[0] == 0) {
        error(-2147467261);
      }
      nsIX509CertValidity localnsIX509CertValidity = new nsIX509CertValidity(arrayOfInt1[0]);
      arrayOfInt1[0] = 0;
      int i5 = XPCOM.nsEmbedString_new();
      n = localnsIX509CertValidity.GetNotBeforeGMT(i5);
      if (n != 0) {
        SWT.error(n);
      }
      i = XPCOM.nsEmbedString_Length(i5);
      j = XPCOM.nsEmbedString_get(i5);
      localObject2 = new char[i];
      XPCOM.memmove((char[])localObject2, j, i * 2);
      String str3 = new String((char[])localObject2);
      XPCOM.nsEmbedString_delete(i5);
      i5 = XPCOM.nsEmbedString_new();
      n = localnsIX509CertValidity.GetNotAfterGMT(i5);
      if (n != 0) {
        SWT.error(n);
      }
      i = XPCOM.nsEmbedString_Length(i5);
      j = XPCOM.nsEmbedString_get(i5);
      localObject2 = new char[i];
      XPCOM.memmove((char[])localObject2, j, i * 2);
      String str4 = new String((char[])localObject2);
      XPCOM.nsEmbedString_delete(i5);
      String str5 = str3 + " - " + str4;
      arrayOfString[(i1++)] = Compatibility.getMessage("SWT_InvalidCert_NotValid", new String[] { str5 });
      i2 |= 0x4;
      localnsIX509CertValidity.Release();
    }
    arrayOfInt2[0] = 0;
    n = localnsISSLStatus.GetIsUntrusted(arrayOfInt2);
    if (arrayOfInt2[0] != 0)
    {
      i4 = XPCOM.nsEmbedString_new();
      n = localnsIX509Cert.GetIssuerCommonName(i4);
      if (n != 0) {
        SWT.error(n);
      }
      i = XPCOM.nsEmbedString_Length(i4);
      j = XPCOM.nsEmbedString_get(i4);
      localObject1 = new char[i];
      XPCOM.memmove((char[])localObject1, j, i * 2);
      localObject2 = new String((char[])localObject1);
      arrayOfString[(i1++)] = Compatibility.getMessage("SWT_InvalidCert_NotTrusted", new String[] { localObject2 });
      i2 |= 0x1;
      XPCOM.nsEmbedString_delete(i4);
    }
    arrayOfInt2[0] = 0;
    localnsISSLStatus.Release();
    final int i4 = i2;
    final Object localObject1 = new String[i1];
    System.arraycopy(arrayOfString, 0, localObject1, 0, i1);
    final Object localObject2 = this.lastNavigateURL;
    this.browser.getDisplay().asyncExec(new Runnable()
    {
      public void run()
      {
        if (Mozilla.this.browser.isDisposed()) {
          return;
        }
        if (localObject2.equals(Mozilla.this.lastNavigateURL))
        {
          String str = Compatibility.getMessage("SWT_InvalidCert_Message", new String[] { str1 });
          if (new PromptDialog(Mozilla.this.browser.getShell()).invalidCert(Mozilla.this.browser, str, localObject1, localnsIX509Cert))
          {
            int[] arrayOfInt = new int[1];
            int i = XPCOM.NS_GetServiceManager(arrayOfInt);
            if (i != 0) {
              Mozilla.error(i);
            }
            if (arrayOfInt[0] == 0) {
              Mozilla.error(-2147467262);
            }
            nsIServiceManager localnsIServiceManager = new nsIServiceManager(arrayOfInt[0]);
            arrayOfInt[0] = 0;
            byte[] arrayOfByte1 = MozillaDelegate.wcsToMbcs(null, "@mozilla.org/security/certoverride;1", true);
            i = localnsIServiceManager.GetServiceByContractID(arrayOfByte1, IIDStore.GetIID(nsICertOverrideService.class), arrayOfInt);
            if (i != 0) {
              Mozilla.error(i);
            }
            if (arrayOfInt[0] == 0) {
              Mozilla.error(-2147467262);
            }
            localnsIServiceManager.Release();
            nsICertOverrideService localnsICertOverrideService = new nsICertOverrideService(arrayOfInt[0]);
            arrayOfInt[0] = 0;
            byte[] arrayOfByte2 = MozillaDelegate.wcsToMbcs(null, str2, false);
            int j = XPCOM.nsEmbedCString_new(arrayOfByte2, arrayOfByte2.length);
            i = localnsICertOverrideService.RememberValidityOverride(j, m, localnsIX509Cert.getAddress(), i4, 1);
            Mozilla.this.navigate(Mozilla.this.badCertRequest);
            XPCOM.nsEmbedCString_delete(j);
            localnsICertOverrideService.Release();
          }
          Mozilla.this.isRetrievingBadCert = false;
        }
        localnsIX509Cert.Release();
        new nsISupports(Mozilla.this.badCertRequest).Release();
        Mozilla.this.badCertRequest = 0;
      }
    });
    XPCOM.memmove(paramInt4, new boolean[] { true });
    return 0;
  }
  
  static
  {
    DisplayListener = new Listener()
    {
      public void handleEvent(Event paramAnonymousEvent)
      {
        if (Mozilla.BrowserCount > 0) {
          return;
        }
        int[] arrayOfInt = new int[1];
        int i = XPCOM.NS_GetServiceManager(arrayOfInt);
        if (i != 0) {
          Mozilla.error(i);
        }
        if (arrayOfInt[0] == 0) {
          Mozilla.error(-2147467262);
        }
        nsIServiceManager localnsIServiceManager = new nsIServiceManager(arrayOfInt[0]);
        arrayOfInt[0] = 0;
        byte[] arrayOfByte = MozillaDelegate.wcsToMbcs(null, "@mozilla.org/observer-service;1", true);
        i = localnsIServiceManager.GetServiceByContractID(arrayOfByte, IIDStore.GetIID(nsIObserverService.class), arrayOfInt);
        if (i != 0) {
          Mozilla.error(i);
        }
        if (arrayOfInt[0] == 0) {
          Mozilla.error(-2147467262);
        }
        nsIObserverService localnsIObserverService = new nsIObserverService(arrayOfInt[0]);
        arrayOfInt[0] = 0;
        arrayOfByte = MozillaDelegate.wcsToMbcs(null, "profile-before-change", true);
        int j = "shutdown-persist".length();
        char[] arrayOfChar = new char[j + 1];
        "shutdown-persist".getChars(0, j, arrayOfChar, 0);
        i = localnsIObserverService.NotifyObservers(0, arrayOfByte, arrayOfChar);
        if (i != 0) {
          Mozilla.error(i);
        }
        localnsIObserverService.Release();
        if (Mozilla.LocationProvider != null)
        {
          String str = Mozilla.LocationProvider.profilePath + "prefs.js";
          nsEmbedString localnsEmbedString = new nsEmbedString(str);
          i = XPCOM.NS_NewLocalFile(localnsEmbedString.getAddress(), 1, arrayOfInt);
          if (i != 0) {
            Mozilla.error(i);
          }
          if (arrayOfInt[0] == 0) {
            Mozilla.error(-2147467261);
          }
          localnsEmbedString.dispose();
          nsILocalFile localnsILocalFile = new nsILocalFile(arrayOfInt[0]);
          arrayOfInt[0] = 0;
          i = localnsILocalFile.QueryInterface(IIDStore.GetIID(nsIFile.class), arrayOfInt);
          if (i != 0) {
            Mozilla.error(i);
          }
          if (arrayOfInt[0] == 0) {
            Mozilla.error(-2147467262);
          }
          localnsILocalFile.Release();
          nsIFile localnsIFile = new nsIFile(arrayOfInt[0]);
          arrayOfInt[0] = 0;
          arrayOfByte = MozillaDelegate.wcsToMbcs(null, "@mozilla.org/preferences-service;1", true);
          i = localnsIServiceManager.GetServiceByContractID(arrayOfByte, IIDStore.GetIID(nsIPrefService.class), arrayOfInt);
          if (i != 0) {
            Mozilla.error(i);
          }
          if (arrayOfInt[0] == 0) {
            Mozilla.error(-2147467262);
          }
          nsIPrefService localnsIPrefService = new nsIPrefService(arrayOfInt[0]);
          arrayOfInt[0] = 0;
          revertProxySettings(localnsIPrefService);
          i = localnsIPrefService.SavePrefFile(localnsIFile.getAddress());
          localnsIPrefService.Release();
          localnsIFile.Release();
        }
        localnsIServiceManager.Release();
        if (Mozilla.XPCOMWasGlued) {
          Mozilla.XPCOMWasGlued = false;
        }
        if (Mozilla.XPCOMInitWasGlued)
        {
          XPCOMInit.XPCOMGlueShutdown();
          Mozilla.XPCOMInitWasGlued = false;
        }
        Mozilla.Initialized = Mozilla.PerformedVersionCheck = 0;
      }
      
      void revertProxySettings(nsIPrefService paramAnonymousnsIPrefService)
      {
        int i = (Mozilla.oldProxyHostFTP != null) || (Mozilla.oldProxyHostHTTP != null) || (Mozilla.oldProxyHostSSL != null) ? 1 : 0;
        if ((i == 0) && (Mozilla.oldProxyPortFTP == -1) && (Mozilla.oldProxyPortHTTP == -1) && (Mozilla.oldProxyPortSSL == -1) && (Mozilla.oldProxyType == -1)) {
          return;
        }
        int[] arrayOfInt = new int[1];
        byte[] arrayOfByte1 = new byte[1];
        int j = paramAnonymousnsIPrefService.GetBranch(arrayOfByte1, arrayOfInt);
        if (j != 0) {
          Mozilla.error(j);
        }
        if (arrayOfInt[0] == 0) {
          Mozilla.error(-2147467262);
        }
        nsIPrefBranch localnsIPrefBranch = new nsIPrefBranch(arrayOfInt[0]);
        arrayOfInt[0] = 0;
        if (i != 0)
        {
          j = XPCOM.NS_GetComponentManager(arrayOfInt);
          if (j != 0) {
            Mozilla.error(j);
          }
          if (arrayOfInt[0] == 0) {
            Mozilla.error(-2147467262);
          }
          nsIComponentManager localnsIComponentManager = new nsIComponentManager(arrayOfInt[0]);
          arrayOfInt[0] = 0;
          byte[] arrayOfByte2 = MozillaDelegate.wcsToMbcs(null, "@mozilla.org/pref-localizedstring;1", true);
          j = localnsIComponentManager.CreateInstanceByContractID(arrayOfByte2, 0, IIDStore.GetIID(nsIPrefLocalizedString.class), arrayOfInt);
          if (j != 0) {
            Mozilla.error(j);
          }
          if (arrayOfInt[0] == 0) {
            Mozilla.error(-2147467262);
          }
          nsIPrefLocalizedString localnsIPrefLocalizedString = new nsIPrefLocalizedString(arrayOfInt[0]);
          arrayOfInt[0] = 0;
          int k;
          char[] arrayOfChar;
          if (Mozilla.oldProxyHostFTP != null)
          {
            arrayOfByte1 = MozillaDelegate.wcsToMbcs(null, "network.proxy.ftp", true);
            if (Mozilla.oldProxyHostFTP.equals("default"))
            {
              j = localnsIPrefBranch.ClearUserPref(arrayOfByte1);
              if (j != 0) {
                Mozilla.error(j);
              }
            }
            else
            {
              k = Mozilla.oldProxyHostFTP.length();
              arrayOfChar = new char[k];
              Mozilla.oldProxyHostFTP.getChars(0, k, arrayOfChar, 0);
              j = localnsIPrefLocalizedString.SetDataWithLength(k, arrayOfChar);
              if (j != 0) {
                Mozilla.error(j);
              }
              j = localnsIPrefBranch.SetComplexValue(arrayOfByte1, IIDStore.GetIID(nsIPrefLocalizedString.class), localnsIPrefLocalizedString.getAddress());
              if (j != 0) {
                Mozilla.error(j);
              }
            }
          }
          if (Mozilla.oldProxyHostHTTP != null)
          {
            arrayOfByte1 = MozillaDelegate.wcsToMbcs(null, "network.proxy.http", true);
            if (Mozilla.oldProxyHostHTTP.equals("default"))
            {
              j = localnsIPrefBranch.ClearUserPref(arrayOfByte1);
              if (j != 0) {
                Mozilla.error(j);
              }
            }
            else
            {
              k = Mozilla.oldProxyHostHTTP.length();
              arrayOfChar = new char[k];
              Mozilla.oldProxyHostHTTP.getChars(0, k, arrayOfChar, 0);
              j = localnsIPrefLocalizedString.SetDataWithLength(k, arrayOfChar);
              if (j != 0) {
                Mozilla.error(j);
              }
              j = localnsIPrefBranch.SetComplexValue(arrayOfByte1, IIDStore.GetIID(nsIPrefLocalizedString.class), localnsIPrefLocalizedString.getAddress());
              if (j != 0) {
                Mozilla.error(j);
              }
            }
          }
          if (Mozilla.oldProxyHostSSL != null)
          {
            arrayOfByte1 = MozillaDelegate.wcsToMbcs(null, "network.proxy.ssl", true);
            if (Mozilla.oldProxyHostSSL.equals("default"))
            {
              j = localnsIPrefBranch.ClearUserPref(arrayOfByte1);
              if (j != 0) {
                Mozilla.error(j);
              }
            }
            else
            {
              k = Mozilla.oldProxyHostSSL.length();
              arrayOfChar = new char[k];
              Mozilla.oldProxyHostSSL.getChars(0, k, arrayOfChar, 0);
              j = localnsIPrefLocalizedString.SetDataWithLength(k, arrayOfChar);
              if (j != 0) {
                Mozilla.error(j);
              }
              j = localnsIPrefBranch.SetComplexValue(arrayOfByte1, IIDStore.GetIID(nsIPrefLocalizedString.class), localnsIPrefLocalizedString.getAddress());
              if (j != 0) {
                Mozilla.error(j);
              }
            }
          }
          localnsIPrefLocalizedString.Release();
          localnsIComponentManager.Release();
        }
        if (Mozilla.oldProxyPortFTP != -1)
        {
          arrayOfByte1 = MozillaDelegate.wcsToMbcs(null, "network.proxy.ftp_port", true);
          j = localnsIPrefBranch.SetIntPref(arrayOfByte1, Mozilla.oldProxyPortFTP);
          if (j != 0) {
            Mozilla.error(j);
          }
        }
        if (Mozilla.oldProxyPortHTTP != -1)
        {
          arrayOfByte1 = MozillaDelegate.wcsToMbcs(null, "network.proxy.http_port", true);
          j = localnsIPrefBranch.SetIntPref(arrayOfByte1, Mozilla.oldProxyPortHTTP);
          if (j != 0) {
            Mozilla.error(j);
          }
        }
        if (Mozilla.oldProxyPortSSL != -1)
        {
          arrayOfByte1 = MozillaDelegate.wcsToMbcs(null, "network.proxy.ssl_port", true);
          j = localnsIPrefBranch.SetIntPref(arrayOfByte1, Mozilla.oldProxyPortSSL);
          if (j != 0) {
            Mozilla.error(j);
          }
        }
        if (Mozilla.oldProxyType != -1)
        {
          arrayOfByte1 = MozillaDelegate.wcsToMbcs(null, "network.proxy.type", true);
          j = localnsIPrefBranch.SetIntPref(arrayOfByte1, Mozilla.oldProxyType);
          if (j != 0) {
            Mozilla.error(j);
          }
        }
        localnsIPrefBranch.Release();
      }
    };
    MozillaClearSessions = new Runnable()
    {
      public void run()
      {
        if (!Mozilla.Initialized) {
          return;
        }
        int[] arrayOfInt1 = new int[1];
        int i = XPCOM.NS_GetServiceManager(arrayOfInt1);
        if (i != 0) {
          Mozilla.error(i);
        }
        if (arrayOfInt1[0] == 0) {
          Mozilla.error(-2147467262);
        }
        nsIServiceManager localnsIServiceManager = new nsIServiceManager(arrayOfInt1[0]);
        arrayOfInt1[0] = 0;
        byte[] arrayOfByte = MozillaDelegate.wcsToMbcs(null, "@mozilla.org/cookiemanager;1", true);
        i = localnsIServiceManager.GetServiceByContractID(arrayOfByte, IIDStore.GetIID(nsICookieManager.class), arrayOfInt1);
        if (i != 0) {
          Mozilla.error(i);
        }
        if (arrayOfInt1[0] == 0) {
          Mozilla.error(-2147467262);
        }
        localnsIServiceManager.Release();
        nsICookieManager localnsICookieManager = new nsICookieManager(arrayOfInt1[0]);
        arrayOfInt1[0] = 0;
        i = localnsICookieManager.GetEnumerator(arrayOfInt1);
        if (i != 0) {
          Mozilla.error(i);
        }
        nsISimpleEnumerator localnsISimpleEnumerator = new nsISimpleEnumerator(arrayOfInt1[0]);
        int[] arrayOfInt2 = new int[1];
        i = localnsISimpleEnumerator.HasMoreElements(arrayOfInt2);
        if (i != 0) {
          Mozilla.error(i);
        }
        while (arrayOfInt2[0] != 0)
        {
          arrayOfInt1[0] = 0;
          i = localnsISimpleEnumerator.GetNext(arrayOfInt1);
          if (i != 0) {
            Mozilla.error(i);
          }
          nsICookie localnsICookie = new nsICookie(arrayOfInt1[0]);
          long[] arrayOfLong = new long[1];
          i = localnsICookie.GetExpires(arrayOfLong);
          if (arrayOfLong[0] == 0L)
          {
            int j = XPCOM.nsEmbedCString_new();
            int k = XPCOM.nsEmbedCString_new();
            int m = XPCOM.nsEmbedCString_new();
            localnsICookie.GetHost(j);
            localnsICookie.GetName(k);
            localnsICookie.GetPath(m);
            i = localnsICookieManager.Remove(j, k, m, 0);
            XPCOM.nsEmbedCString_delete(j);
            XPCOM.nsEmbedCString_delete(k);
            XPCOM.nsEmbedCString_delete(m);
            if (i != 0) {
              Mozilla.error(i);
            }
          }
          localnsICookie.Release();
          i = localnsISimpleEnumerator.HasMoreElements(arrayOfInt2);
          if (i != 0) {
            Mozilla.error(i);
          }
        }
        localnsISimpleEnumerator.Release();
        localnsICookieManager.Release();
      }
    };
    MozillaGetCookie = new Runnable()
    {
      public void run()
      {
        if (!Mozilla.Initialized) {
          return;
        }
        int[] arrayOfInt = new int[1];
        int i = XPCOM.NS_GetServiceManager(arrayOfInt);
        if (i != 0) {
          Mozilla.error(i);
        }
        if (arrayOfInt[0] == 0) {
          Mozilla.error(-2147467262);
        }
        nsIServiceManager localnsIServiceManager = new nsIServiceManager(arrayOfInt[0]);
        arrayOfInt[0] = 0;
        i = localnsIServiceManager.GetService(XPCOM.NS_IOSERVICE_CID, IIDStore.GetIID(nsIIOService.class), arrayOfInt);
        if (i != 0) {
          Mozilla.error(i);
        }
        if (arrayOfInt[0] == 0) {
          Mozilla.error(-2147467262);
        }
        nsIIOService localnsIIOService = new nsIIOService(arrayOfInt[0]);
        arrayOfInt[0] = 0;
        byte[] arrayOfByte1 = MozillaDelegate.wcsToMbcs(null, WebBrowser.CookieUrl, false);
        int j = XPCOM.nsEmbedCString_new(arrayOfByte1, arrayOfByte1.length);
        i = localnsIIOService.NewURI(j, null, 0, arrayOfInt);
        XPCOM.nsEmbedCString_delete(j);
        localnsIIOService.Release();
        if (i != 0)
        {
          localnsIServiceManager.Release();
          return;
        }
        if (arrayOfInt[0] == 0) {
          Mozilla.error(-2147467261);
        }
        nsIURI localnsIURI = new nsIURI(arrayOfInt[0]);
        arrayOfInt[0] = 0;
        byte[] arrayOfByte2 = MozillaDelegate.wcsToMbcs(null, "@mozilla.org/cookieService;1", true);
        i = localnsIServiceManager.GetServiceByContractID(arrayOfByte2, IIDStore.GetIID(nsICookieService.class), arrayOfInt);
        if (i != 0) {
          Mozilla.error(i);
        }
        if (arrayOfInt[0] == 0) {
          Mozilla.error(-2147467262);
        }
        nsICookieService localnsICookieService = new nsICookieService(arrayOfInt[0]);
        arrayOfInt[0] = 0;
        i = localnsICookieService.GetCookieString(localnsIURI.getAddress(), 0, arrayOfInt);
        localnsICookieService.Release();
        if (i != 0) {
          Mozilla.error(i);
        }
        if (arrayOfInt[0] == 0)
        {
          localnsIURI.Release();
          localnsIServiceManager.Release();
          return;
        }
        int k = arrayOfInt[0];
        arrayOfInt[0] = 0;
        localnsIURI.Release();
        localnsIServiceManager.Release();
        int m = C.strlen(k);
        arrayOfByte1 = new byte[m];
        XPCOM.memmove(arrayOfByte1, k, m);
        if (Mozilla.pathBytes_NSFree == null)
        {
          str1 = Mozilla.getMozillaPath();
          str1 = str1 + MozillaDelegate.getLibraryName(str1) + '\000';
          try
          {
            Mozilla.pathBytes_NSFree = str1.getBytes("UTF-8");
          }
          catch (UnsupportedEncodingException localUnsupportedEncodingException)
          {
            Mozilla.pathBytes_NSFree = str1.getBytes();
          }
        }
        if (!XPCOM.NS_Free(Mozilla.pathBytes_NSFree, k)) {
          C.free(k);
        }
        String str1 = new String(MozillaDelegate.mbcsToWcs(null, arrayOfByte1));
        StringTokenizer localStringTokenizer = new StringTokenizer(str1, ";");
        while (localStringTokenizer.hasMoreTokens())
        {
          String str2 = localStringTokenizer.nextToken();
          int n = str2.indexOf('=');
          if (n != -1)
          {
            String str3 = str2.substring(0, n).trim();
            if (str3.equals(WebBrowser.CookieName))
            {
              WebBrowser.CookieValue = str2.substring(n + 1).trim();
              return;
            }
          }
        }
      }
    };
    MozillaSetCookie = new Runnable()
    {
      public void run()
      {
        if (!Mozilla.Initialized) {
          return;
        }
        int[] arrayOfInt = new int[1];
        int i = XPCOM.NS_GetServiceManager(arrayOfInt);
        if (i != 0) {
          Mozilla.error(i);
        }
        if (arrayOfInt[0] == 0) {
          Mozilla.error(-2147467262);
        }
        nsIServiceManager localnsIServiceManager = new nsIServiceManager(arrayOfInt[0]);
        arrayOfInt[0] = 0;
        i = localnsIServiceManager.GetService(XPCOM.NS_IOSERVICE_CID, IIDStore.GetIID(nsIIOService.class), arrayOfInt);
        if (i != 0) {
          Mozilla.error(i);
        }
        if (arrayOfInt[0] == 0) {
          Mozilla.error(-2147467262);
        }
        nsIIOService localnsIIOService = new nsIIOService(arrayOfInt[0]);
        arrayOfInt[0] = 0;
        byte[] arrayOfByte1 = MozillaDelegate.wcsToMbcs(null, WebBrowser.CookieUrl, false);
        int j = XPCOM.nsEmbedCString_new(arrayOfByte1, arrayOfByte1.length);
        i = localnsIIOService.NewURI(j, null, 0, arrayOfInt);
        XPCOM.nsEmbedCString_delete(j);
        localnsIIOService.Release();
        if (i != 0)
        {
          localnsIServiceManager.Release();
          return;
        }
        if (arrayOfInt[0] == 0) {
          Mozilla.error(-2147467261);
        }
        nsIURI localnsIURI = new nsIURI(arrayOfInt[0]);
        arrayOfInt[0] = 0;
        byte[] arrayOfByte2 = MozillaDelegate.wcsToMbcs(null, WebBrowser.CookieValue, true);
        byte[] arrayOfByte3 = MozillaDelegate.wcsToMbcs(null, "@mozilla.org/cookieService;1", true);
        i = localnsIServiceManager.GetServiceByContractID(arrayOfByte3, IIDStore.GetIID(nsICookieService.class), arrayOfInt);
        if (i != 0) {
          Mozilla.error(i);
        }
        if (arrayOfInt[0] == 0) {
          Mozilla.error(-2147467262);
        }
        nsICookieService localnsICookieService = new nsICookieService(arrayOfInt[0]);
        arrayOfInt[0] = 0;
        i = localnsICookieService.SetCookieString(localnsIURI.getAddress(), 0, arrayOfByte2, 0);
        localnsICookieService.Release();
        localnsIURI.Release();
        localnsIServiceManager.Release();
        WebBrowser.CookieResult = i == 0;
      }
    };
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_32.jar!/org/eclipse/swt/browser/Mozilla.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */