package org.eclipse.swt.internal.ole.win32;

public final class GUID
{
  public int Data1;
  public short Data2;
  public short Data3;
  public byte[] Data4 = new byte[8];
  public static final int sizeof = ;
  static final String zeros = "00000000";
  
  static String toHex(int paramInt1, int paramInt2)
  {
    String str = Integer.toHexString(paramInt1).toUpperCase();
    int i = str.length();
    if (i > paramInt2) {
      str = str.substring(i - paramInt2);
    }
    return "00000000".substring(0, Math.max(0, paramInt2 - i)) + str;
  }
  
  public String toString()
  {
    return '{' + toHex(this.Data1, 8) + '-' + toHex(this.Data2, 4) + '-' + toHex(this.Data3, 4) + '-' + toHex(this.Data4[0], 2) + toHex(this.Data4[1], 2) + '-' + toHex(this.Data4[2], 2) + toHex(this.Data4[3], 2) + toHex(this.Data4[4], 2) + toHex(this.Data4[5], 2) + toHex(this.Data4[6], 2) + toHex(this.Data4[7], 2) + '}';
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_32.jar!/org/eclipse/swt/internal/ole/win32/GUID.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */