package org.eclipse.swt.internal.mozilla;

public class nsIDOMSerializer
  extends nsISupports
{
  static final int LAST_METHOD_ID = nsISupports.LAST_METHOD_ID + 2;
  static final String NS_IDOMSERIALIZER_IID_STR = "a6cf9123-15b3-11d2-932e-00805f8add32";
  static final String NS_IDOMSERIALIZER_1_8_IID_STR = "9fd4ba15-e67c-4c98-b52c-7715f62c9196";
  
  public nsIDOMSerializer(int paramInt)
  {
    super(paramInt);
  }
  
  public int SerializeToString(int paramInt, int[] paramArrayOfInt)
  {
    if (MozillaVersion.CheckVersion(1)) {
      return 1;
    }
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 1, getAddress(), paramInt, paramArrayOfInt);
  }
  
  public int SerializeToString(int paramInt1, int paramInt2)
  {
    if (!MozillaVersion.CheckVersion(1)) {
      return 1;
    }
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 1, getAddress(), paramInt1, paramInt2);
  }
  
  static
  {
    IIDStore.RegisterIID(nsIDOMSerializer.class, 0, new nsID("a6cf9123-15b3-11d2-932e-00805f8add32"));
    IIDStore.RegisterIID(nsIDOMSerializer.class, 1, new nsID("9fd4ba15-e67c-4c98-b52c-7715f62c9196"));
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_32.jar!/org/eclipse/swt/internal/mozilla/nsIDOMSerializer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */