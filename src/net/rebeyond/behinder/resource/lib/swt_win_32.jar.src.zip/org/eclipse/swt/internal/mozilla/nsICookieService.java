package org.eclipse.swt.internal.mozilla;

public class nsICookieService
  extends nsISupports
{
  static final int LAST_METHOD_ID = nsISupports.LAST_METHOD_ID + 5;
  static final String NS_ICOOKIESERVICE_IID_STR = "011c3190-1434-11d6-a618-0010a401eb10";
  static final String NS_ICOOKIESERVICE_1_9_IID_STR = "2aaa897a-293c-4d2b-a657-8c9b7136996d";
  
  public nsICookieService(int paramInt)
  {
    super(paramInt);
  }
  
  public int GetCookieString(int paramInt1, int paramInt2, int[] paramArrayOfInt)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 1, getAddress(), paramInt1, paramInt2, paramArrayOfInt);
  }
  
  public int SetCookieString(int paramInt1, int paramInt2, byte[] paramArrayOfByte, int paramInt3)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 3, getAddress(), paramInt1, paramInt2, paramArrayOfByte, paramInt3);
  }
  
  static
  {
    IIDStore.RegisterIID(nsICookieService.class, 0, new nsID("011c3190-1434-11d6-a618-0010a401eb10"));
    IIDStore.RegisterIID(nsICookieService.class, 2, new nsID("2aaa897a-293c-4d2b-a657-8c9b7136996d"));
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_32.jar!/org/eclipse/swt/internal/mozilla/nsICookieService.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */