package org.eclipse.swt.browser;

import java.io.File;
import java.io.PrintStream;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Enumeration;
import java.util.Hashtable;
import org.eclipse.swt.SWT;
import org.eclipse.swt.SWTError;
import org.eclipse.swt.SWTException;
import org.eclipse.swt.graphics.Device;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.internal.C;
import org.eclipse.swt.internal.Callback;
import org.eclipse.swt.internal.Library;
import org.eclipse.swt.internal.ole.win32.COM;
import org.eclipse.swt.internal.webkit.IWebCookieManager;
import org.eclipse.swt.internal.webkit.IWebDataSource;
import org.eclipse.swt.internal.webkit.IWebDocumentRepresentation;
import org.eclipse.swt.internal.webkit.IWebFrame;
import org.eclipse.swt.internal.webkit.IWebIBActions;
import org.eclipse.swt.internal.webkit.IWebMutableURLRequest;
import org.eclipse.swt.internal.webkit.IWebPreferences;
import org.eclipse.swt.internal.webkit.IWebView;
import org.eclipse.swt.internal.webkit.IWebViewPrivate;
import org.eclipse.swt.internal.webkit.JSClassDefinition;
import org.eclipse.swt.internal.webkit.WebKit_win32;
import org.eclipse.swt.internal.win32.OS;
import org.eclipse.swt.internal.win32.RECT;
import org.eclipse.swt.internal.win32.TCHAR;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Widget;

class WebKit
  extends WebBrowser
{
  IWebView webView;
  int webViewWindowHandle;
  int webViewData;
  int refCount = 0;
  int lastKeyCode;
  int lastCharCode;
  WebDownloadDelegate webDownloadDelegate;
  WebFrameLoadDelegate webFrameLoadDelegate;
  WebPolicyDelegate webPolicyDelegate;
  WebResourceLoadDelegate webResourceLoadDelegate;
  WebUIDelegate webUIDelegate;
  boolean ignoreDispose;
  boolean loadingText = false;
  boolean traverseNext = true;
  boolean traverseOut = false;
  boolean untrustedText;
  String lastNavigateURL;
  BrowserFunction eventFunction;
  static int prefsIdentifier;
  static int ExternalClass;
  static boolean LibraryLoaded = false;
  static String LibraryLoadError;
  static Callback JSObjectHasPropertyProc;
  static Callback JSObjectGetPropertyProc;
  static Callback JSObjectCallAsFunctionProc;
  static final int MAX_PROGRESS = 100;
  static final String ABOUT_BLANK = "about:blank";
  static final String CHARSET_UTF8 = "UTF-8";
  static final String CLASSNAME_EXTERNAL = "External";
  static final String EMPTY_STRING = "";
  static final String FUNCTIONNAME_CALLJAVA = "callJava";
  static final String HEADER_SETCOOKIE = "Set-Cookie";
  static final String POST = "POST";
  static final String PROPERTY_LENGTH = "length";
  static final String PROTOCOL_HTTPS = "https://";
  static final String PROTOCOL_FILE = "file://";
  static final String PROTOCOL_HTTP = "http://";
  static final String USER_AGENT = "user-agent";
  static final String URI_FILEROOT = "file:///";
  static final String DOMEVENT_DRAGSTART = "dragstart";
  static final String DOMEVENT_KEYDOWN = "keydown";
  static final String DOMEVENT_KEYPRESS = "keypress";
  static final String DOMEVENT_KEYUP = "keyup";
  static final String DOMEVENT_MOUSEDOWN = "mousedown";
  static final String DOMEVENT_MOUSEUP = "mouseup";
  static final String DOMEVENT_MOUSEMOVE = "mousemove";
  static final String DOMEVENT_MOUSEOUT = "mouseout";
  static final String DOMEVENT_MOUSEOVER = "mouseover";
  static final String DOMEVENT_MOUSEWHEEL = "mousewheel";
  
  static int createBSTR(String paramString)
  {
    char[] arrayOfChar = (paramString + '\000').toCharArray();
    return COM.SysAllocString(arrayOfChar);
  }
  
  static String error(int paramInt)
  {
    throw new SWTError("WebKit error " + paramInt);
  }
  
  static String extractBSTR(int paramInt)
  {
    int i = COM.SysStringByteLen(paramInt);
    if (i == 0) {
      return "";
    }
    char[] arrayOfChar = new char[(i + 1) / 2];
    COM.MoveMemory(arrayOfChar, paramInt, i);
    return new String(arrayOfChar);
  }
  
  static Browser findBrowser(int paramInt)
  {
    if (paramInt == 0) {
      return null;
    }
    IWebView localIWebView = new IWebView(paramInt);
    int[] arrayOfInt = new int[1];
    int i = localIWebView.hostWindow(arrayOfInt);
    if ((i == 0) && (arrayOfInt[0] != 0))
    {
      Widget localWidget = Display.getCurrent().findWidget(arrayOfInt[0]);
      if ((localWidget != null) && ((localWidget instanceof Browser))) {
        return (Browser)localWidget;
      }
    }
    return null;
  }
  
  static int JSObjectCallAsFunctionProc(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6)
  {
    WebKit_win32.JSGlobalContextRetain(paramInt1);
    if (WebKit_win32.JSValueIsObjectOfClass(paramInt1, paramInt3, ExternalClass) == 0) {
      return WebKit_win32.JSValueMakeUndefined(paramInt1);
    }
    int i = WebKit_win32.JSObjectGetPrivate(paramInt3);
    int[] arrayOfInt = new int[1];
    C.memmove(arrayOfInt, i, C.PTR_SIZEOF);
    Browser localBrowser = findBrowser(arrayOfInt[0]);
    if (localBrowser == null) {
      return WebKit_win32.JSValueMakeUndefined(paramInt1);
    }
    WebKit localWebKit = (WebKit)localBrowser.webBrowser;
    return localWebKit.callJava(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6);
  }
  
  static int JSObjectGetPropertyProc(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    byte[] arrayOfByte = null;
    try
    {
      arrayOfByte = "callJava\000".getBytes("UTF-8");
    }
    catch (UnsupportedEncodingException localUnsupportedEncodingException)
    {
      arrayOfByte = "callJava\000".getBytes();
    }
    int i = WebKit_win32.JSStringCreateWithUTF8CString(arrayOfByte);
    int j = WebKit_win32.JSObjectCallAsFunctionProc_CALLBACK(JSObjectCallAsFunctionProc.getAddress());
    int k = WebKit_win32.JSObjectMakeFunctionWithCallback(paramInt1, i, j);
    WebKit_win32.JSStringRelease(i);
    return k;
  }
  
  static int JSObjectHasPropertyProc(int paramInt1, int paramInt2, int paramInt3)
  {
    byte[] arrayOfByte = null;
    try
    {
      arrayOfByte = "callJava\000".getBytes("UTF-8");
    }
    catch (UnsupportedEncodingException localUnsupportedEncodingException)
    {
      arrayOfByte = "callJava\000".getBytes();
    }
    return WebKit_win32.JSStringIsEqualToUTF8CString(paramInt3, arrayOfByte);
  }
  
  static String readInstallDir(String paramString)
  {
    int[] arrayOfInt1 = new int[1];
    TCHAR localTCHAR1 = new TCHAR(0, paramString, true);
    if (OS.RegOpenKeyEx(-2147483646, localTCHAR1, 0, 131097, arrayOfInt1) == 0)
    {
      int[] arrayOfInt2 = new int[1];
      TCHAR localTCHAR2 = new TCHAR(0, "InstallDir", true);
      int i = OS.RegQueryValueEx(arrayOfInt1[0], localTCHAR2, 0, null, (TCHAR)null, arrayOfInt2);
      if (i == 0)
      {
        TCHAR localTCHAR3 = new TCHAR(0, arrayOfInt2[0] / TCHAR.sizeof);
        i = OS.RegQueryValueEx(arrayOfInt1[0], localTCHAR2, 0, null, localTCHAR3, arrayOfInt2);
        if (i == 0)
        {
          OS.RegCloseKey(arrayOfInt1[0]);
          return localTCHAR3.toString(0, localTCHAR3.strlen());
        }
      }
      OS.RegCloseKey(arrayOfInt1[0]);
    }
    return null;
  }
  
  static String stringFromCFString(int paramInt)
  {
    if (paramInt == 0) {
      return null;
    }
    int i = WebKit_win32.CFStringGetLength(paramInt);
    int j = WebKit_win32.CFStringGetCharactersPtr(paramInt);
    char[] arrayOfChar = new char[i];
    if (j != 0) {
      OS.MoveMemory(arrayOfChar, j, i);
    } else {
      for (int k = 0; k < i; k++) {
        arrayOfChar[k] = WebKit_win32.CFStringGetCharacterAtIndex(paramInt, k);
      }
    }
    return new String(arrayOfChar);
  }
  
  static String stringFromJSString(int paramInt)
  {
    if (paramInt == 0) {
      return null;
    }
    int i = WebKit_win32.JSStringGetLength(paramInt);
    byte[] arrayOfByte = new byte[i + 1];
    WebKit_win32.JSStringGetUTF8CString(paramInt, arrayOfByte, i + 1);
    return new String(arrayOfByte);
  }
  
  public boolean back()
  {
    int[] arrayOfInt = new int[1];
    this.webView.goBack(arrayOfInt);
    return arrayOfInt[0] != 0;
  }
  
  int callJava(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6)
  {
    Object localObject1 = null;
    if (paramInt4 == 3)
    {
      int[] arrayOfInt = new int[1];
      C.memmove(arrayOfInt, paramInt5, C.PTR_SIZEOF);
      int i = WebKit_win32.JSValueGetType(paramInt1, arrayOfInt[0]);
      if (i == 3)
      {
        int j = ((Double)convertToJava(paramInt1, arrayOfInt[0])).intValue();
        arrayOfInt[0] = 0;
        if (j > 0)
        {
          Integer localInteger = new Integer(j);
          C.memmove(arrayOfInt, paramInt5 + C.PTR_SIZEOF, C.PTR_SIZEOF);
          i = WebKit_win32.JSValueGetType(paramInt1, arrayOfInt[0]);
          if (i == 4)
          {
            String str = (String)convertToJava(paramInt1, arrayOfInt[0]);
            BrowserFunction localBrowserFunction = (BrowserFunction)this.functions.get(localInteger);
            if ((localBrowserFunction != null) && (str.equals(localBrowserFunction.token))) {
              try
              {
                C.memmove(arrayOfInt, paramInt5 + 2 * C.PTR_SIZEOF, C.PTR_SIZEOF);
                Object localObject2 = convertToJava(paramInt1, arrayOfInt[0]);
                if ((localObject2 instanceof Object[]))
                {
                  Object[] arrayOfObject = (Object[])localObject2;
                  try
                  {
                    localObject1 = localBrowserFunction.function(arrayOfObject);
                  }
                  catch (Exception localException)
                  {
                    localObject1 = WebBrowser.CreateErrorString(localException.getLocalizedMessage());
                  }
                }
              }
              catch (IllegalArgumentException localIllegalArgumentException)
              {
                if (localBrowserFunction.isEvaluate) {
                  localBrowserFunction.function(new String[] { WebBrowser.CreateErrorString(new SWTException(51).getLocalizedMessage()) });
                }
                localObject1 = WebBrowser.CreateErrorString(localIllegalArgumentException.getLocalizedMessage());
              }
            }
          }
        }
      }
    }
    return convertToJS(paramInt1, localObject1);
  }
  
  public boolean close()
  {
    return shouldClose();
  }
  
  Object convertToJava(int paramInt1, int paramInt2)
  {
    int i = WebKit_win32.JSValueGetType(paramInt1, paramInt2);
    switch (i)
    {
    case 2: 
      int j = (int)WebKit_win32.JSValueToNumber(paramInt1, paramInt2, null);
      return new Boolean(j != 0);
    case 3: 
      double d = WebKit_win32.JSValueToNumber(paramInt1, paramInt2, null);
      return new Double(d);
    case 4: 
      int k = WebKit_win32.JSValueToStringCopy(paramInt1, paramInt2, null);
      if (k == 0) {
        return "";
      }
      int m = WebKit_win32.JSStringGetMaximumUTF8CStringSize(k);
      byte[] arrayOfByte2 = new byte[m];
      m = WebKit_win32.JSStringGetUTF8CString(k, arrayOfByte2, m);
      WebKit_win32.JSStringRelease(k);
      try
      {
        return new String(arrayOfByte2, 0, m - 1, "UTF-8");
      }
      catch (UnsupportedEncodingException localUnsupportedEncodingException2)
      {
        return new String(arrayOfByte2);
      }
    case 0: 
    case 1: 
      return null;
    case 5: 
      byte[] arrayOfByte1 = null;
      try
      {
        arrayOfByte1 = "length\000".getBytes("UTF-8");
      }
      catch (UnsupportedEncodingException localUnsupportedEncodingException1)
      {
        arrayOfByte1 = "length\000".getBytes();
      }
      int n = WebKit_win32.JSStringCreateWithUTF8CString(arrayOfByte1);
      int i1 = WebKit_win32.JSObjectGetProperty(paramInt1, paramInt2, n, null);
      WebKit_win32.JSStringRelease(n);
      i = WebKit_win32.JSValueGetType(paramInt1, i1);
      if (i == 3)
      {
        int i2 = (int)WebKit_win32.JSValueToNumber(paramInt1, i1, null);
        Object[] arrayOfObject = new Object[i2];
        for (int i3 = 0; i3 < i2; i3++)
        {
          int i4 = WebKit_win32.JSObjectGetPropertyAtIndex(paramInt1, paramInt2, i3, null);
          if (i4 != 0) {
            arrayOfObject[i3] = convertToJava(paramInt1, i4);
          }
        }
        return arrayOfObject;
      }
      break;
    }
    SWT.error(5);
    return null;
  }
  
  int convertToJS(int paramInt, Object paramObject)
  {
    if (paramObject == null) {
      return WebKit_win32.JSValueMakeNull(paramInt);
    }
    Object localObject1;
    int i;
    if ((paramObject instanceof String))
    {
      localObject1 = null;
      try
      {
        localObject1 = ((String)paramObject + '\000').getBytes("UTF-8");
      }
      catch (UnsupportedEncodingException localUnsupportedEncodingException)
      {
        localObject1 = ((String)paramObject + '\000').getBytes();
      }
      i = WebKit_win32.JSStringCreateWithUTF8CString((byte[])localObject1);
      int j = WebKit_win32.JSValueMakeString(paramInt, i);
      WebKit_win32.JSStringRelease(i);
      return j;
    }
    if ((paramObject instanceof Boolean)) {
      return WebKit_win32.JSValueMakeBoolean(paramInt, ((Boolean)paramObject).booleanValue() ? 1 : 0);
    }
    if ((paramObject instanceof Number)) {
      return WebKit_win32.JSValueMakeNumber(paramInt, ((Number)paramObject).doubleValue());
    }
    if ((paramObject instanceof Object[]))
    {
      localObject1 = (Object[])paramObject;
      i = localObject1.length;
      int[] arrayOfInt = new int[i];
      for (int k = 0; k < i; k++)
      {
        Object localObject2 = localObject1[k];
        int m = convertToJS(paramInt, localObject2);
        arrayOfInt[k] = m;
      }
      return WebKit_win32.JSObjectMakeArray(paramInt, i, arrayOfInt, null);
    }
    SWT.error(51);
    return 0;
  }
  
  public void create(Composite paramComposite, int paramInt)
  {
    if (!LibraryLoaded)
    {
      this.browser.dispose();
      SWT.error(2, null, " [" + LibraryLoadError + ']');
    }
    if (ExternalClass == 0)
    {
      localObject = new JSClassDefinition();
      byte[] arrayOfByte = "External\000".getBytes();
      ((JSClassDefinition)localObject).className = C.malloc(arrayOfByte.length);
      OS.memmove(((JSClassDefinition)localObject).className, arrayOfByte, arrayOfByte.length);
      int j = WebKit_win32.JSObjectHasPropertyProc_CALLBACK(JSObjectHasPropertyProc.getAddress());
      ((JSClassDefinition)localObject).hasProperty = j;
      j = WebKit_win32.JSObjectGetPropertyProc_CALLBACK(JSObjectGetPropertyProc.getAddress());
      ((JSClassDefinition)localObject).getProperty = j;
      int k = C.malloc(JSClassDefinition.sizeof);
      WebKit_win32.memmove(k, (JSClassDefinition)localObject, JSClassDefinition.sizeof);
      ExternalClass = WebKit_win32.JSClassCreate(k);
      WebKit_win32.JSClassRetain(ExternalClass);
    }
    Object localObject = new int[1];
    int i = WebKit_win32.WebKitCreateInstance(WebKit_win32.CLSID_WebView, 0, WebKit_win32.IID_IWebView, (int[])localObject);
    if ((i != 0) || (localObject[0] == 0))
    {
      this.browser.dispose();
      error(i);
    }
    this.webView = new IWebView(localObject[0]);
    this.webViewData = C.malloc(C.PTR_SIZEOF);
    C.memmove(this.webViewData, new int[] { this.webView.getAddress() }, C.PTR_SIZEOF);
    i = this.webView.setHostWindow(this.browser.handle);
    if (i != 0)
    {
      this.browser.dispose();
      error(i);
    }
    i = this.webView.initWithFrame(new RECT(), 0, 0);
    if (i != 0)
    {
      this.browser.dispose();
      error(i);
    }
    localObject[0] = 0;
    i = this.webView.QueryInterface(WebKit_win32.IID_IWebViewPrivate, (int[])localObject);
    if ((i != 0) || (localObject[0] == 0))
    {
      this.browser.dispose();
      error(i);
    }
    IWebViewPrivate localIWebViewPrivate = new IWebViewPrivate(localObject[0]);
    localObject[0] = 0;
    i = localIWebViewPrivate.viewWindow((int[])localObject);
    if ((i != 0) || (localObject[0] == 0))
    {
      this.browser.dispose();
      error(i);
    }
    localIWebViewPrivate.Release();
    this.webViewWindowHandle = localObject[0];
    this.webFrameLoadDelegate = new WebFrameLoadDelegate(this.browser);
    i = this.webView.setFrameLoadDelegate(this.webFrameLoadDelegate.getAddress());
    if (i != 0)
    {
      this.browser.dispose();
      error(i);
    }
    this.webUIDelegate = new WebUIDelegate(this.browser);
    i = this.webView.setUIDelegate(this.webUIDelegate.getAddress());
    if (i != 0)
    {
      this.browser.dispose();
      error(i);
    }
    this.webResourceLoadDelegate = new WebResourceLoadDelegate(this.browser);
    i = this.webView.setResourceLoadDelegate(this.webResourceLoadDelegate.getAddress());
    if (i != 0)
    {
      this.browser.dispose();
      error(i);
    }
    this.webDownloadDelegate = new WebDownloadDelegate(this.browser);
    i = this.webView.setDownloadDelegate(this.webDownloadDelegate.getAddress());
    if (i != 0)
    {
      this.browser.dispose();
      error(i);
    }
    this.webPolicyDelegate = new WebPolicyDelegate(this.browser);
    i = this.webView.setPolicyDelegate(this.webPolicyDelegate.getAddress());
    if (i != 0)
    {
      this.browser.dispose();
      error(i);
    }
    initializeWebViewPreferences();
    Listener local4 = new Listener()
    {
      public void handleEvent(Event paramAnonymousEvent)
      {
        switch (paramAnonymousEvent.type)
        {
        case 12: 
          if (WebKit.this.ignoreDispose)
          {
            WebKit.this.ignoreDispose = false;
          }
          else
          {
            WebKit.this.ignoreDispose = true;
            WebKit.this.browser.notifyListeners(paramAnonymousEvent.type, paramAnonymousEvent);
            paramAnonymousEvent.type = 0;
            WebKit.this.onDispose();
          }
          break;
        case 15: 
          OS.SetFocus(WebKit.this.webViewWindowHandle);
          break;
        case 11: 
          Rectangle localRectangle = WebKit.this.browser.getClientArea();
          OS.SetWindowPos(WebKit.this.webViewWindowHandle, 0, localRectangle.x, localRectangle.y, localRectangle.width, localRectangle.height, 32);
          break;
        case 31: 
          if (WebKit.this.traverseOut)
          {
            paramAnonymousEvent.doit = true;
            WebKit.this.traverseOut = false;
          }
          else
          {
            paramAnonymousEvent.doit = false;
          }
          break;
        }
      }
    };
    this.browser.addListener(12, local4);
    this.browser.addListener(1, local4);
    this.browser.addListener(15, local4);
    this.browser.addListener(11, local4);
    this.browser.addListener(31, local4);
    this.eventFunction = new BrowserFunction(this.browser, "HandleWebKitEvent")
    {
      public Object function(Object[] paramAnonymousArrayOfObject)
      {
        return WebKit.this.handleEvent(paramAnonymousArrayOfObject) ? Boolean.TRUE : Boolean.FALSE;
      }
    };
  }
  
  public boolean execute(String paramString)
  {
    int[] arrayOfInt = new int[1];
    int i = this.webView.mainFrame(arrayOfInt);
    if ((i != 0) || (arrayOfInt[0] == 0)) {
      return false;
    }
    IWebFrame localIWebFrame = new IWebFrame(arrayOfInt[0]);
    int j = localIWebFrame.globalContext();
    localIWebFrame.Release();
    if (j == 0) {
      return false;
    }
    byte[] arrayOfByte = null;
    try
    {
      arrayOfByte = (paramString + '\000').getBytes("UTF-8");
    }
    catch (UnsupportedEncodingException localUnsupportedEncodingException1)
    {
      arrayOfByte = (paramString + '\000').getBytes();
    }
    int k = WebKit_win32.JSStringCreateWithUTF8CString(arrayOfByte);
    if (k == 0) {
      return false;
    }
    try
    {
      arrayOfByte = (getUrl() + '\000').getBytes("UTF-8");
    }
    catch (UnsupportedEncodingException localUnsupportedEncodingException2)
    {
      arrayOfByte = (getUrl() + '\000').getBytes();
    }
    int m = WebKit_win32.JSStringCreateWithUTF8CString(arrayOfByte);
    if (m == 0)
    {
      WebKit_win32.JSStringRelease(k);
      return false;
    }
    int n = WebKit_win32.JSEvaluateScript(j, k, 0, m, 0, null);
    WebKit_win32.JSStringRelease(m);
    WebKit_win32.JSStringRelease(k);
    return n != 0;
  }
  
  public boolean forward()
  {
    int[] arrayOfInt = new int[1];
    this.webView.goForward(arrayOfInt);
    return arrayOfInt[0] != 0;
  }
  
  public String getBrowserType()
  {
    return "webkit";
  }
  
  public String getText()
  {
    int[] arrayOfInt = new int[1];
    int i = this.webView.mainFrame(arrayOfInt);
    if ((i != 0) || (arrayOfInt[0] == 0)) {
      return "";
    }
    IWebFrame localIWebFrame = new IWebFrame(arrayOfInt[0]);
    arrayOfInt[0] = 0;
    i = localIWebFrame.dataSource(arrayOfInt);
    localIWebFrame.Release();
    if ((i != 0) || (arrayOfInt[0] == 0)) {
      return "";
    }
    IWebDataSource localIWebDataSource = new IWebDataSource(arrayOfInt[0]);
    arrayOfInt[0] = 0;
    i = localIWebDataSource.representation(arrayOfInt);
    localIWebDataSource.Release();
    if ((i != 0) || (arrayOfInt[0] == 0)) {
      return "";
    }
    IWebDocumentRepresentation localIWebDocumentRepresentation = new IWebDocumentRepresentation(arrayOfInt[0]);
    arrayOfInt[0] = 0;
    i = localIWebDocumentRepresentation.documentSource(arrayOfInt);
    localIWebDocumentRepresentation.Release();
    if ((i != 0) || (arrayOfInt[0] == 0)) {
      return "";
    }
    String str = extractBSTR(arrayOfInt[0]);
    COM.SysFreeString(arrayOfInt[0]);
    return str;
  }
  
  public String getUrl()
  {
    return this.webFrameLoadDelegate.getUrl();
  }
  
  boolean handleEvent(Object[] paramArrayOfObject)
  {
    String str = (String)paramArrayOfObject[0];
    if (str.equals("keydown"))
    {
      int i = translateKey(((Double)paramArrayOfObject[1]).intValue());
      this.lastKeyCode = i;
      switch (i)
      {
      case 9: 
      case 127: 
      case 65536: 
      case 131072: 
      case 262144: 
      case 4194304: 
      case 16777217: 
      case 16777218: 
      case 16777219: 
      case 16777220: 
      case 16777221: 
      case 16777222: 
      case 16777223: 
      case 16777224: 
      case 16777225: 
      case 16777226: 
      case 16777227: 
      case 16777228: 
      case 16777229: 
      case 16777230: 
      case 16777231: 
      case 16777232: 
      case 16777233: 
      case 16777234: 
      case 16777235: 
      case 16777236: 
      case 16777237: 
      case 16777298: 
      case 16777299: 
      case 16777300: 
      case 16777301: 
        localEvent2 = new Event();
        localEvent2.widget = this.browser;
        localEvent2.type = (str.equals("keydown") ? 1 : 2);
        localEvent2.keyCode = i;
        switch (i)
        {
        case 8: 
          localEvent2.character = '\b';
          break;
        case 127: 
          localEvent2.character = '';
          break;
        case 27: 
          localEvent2.character = '\033';
          break;
        case 9: 
          localEvent2.character = '\t';
        }
        this.lastCharCode = localEvent2.character;
        localEvent2.stateMask = ((((Boolean)paramArrayOfObject[3]).booleanValue() ? 65536 : 0) | (((Boolean)paramArrayOfObject[4]).booleanValue() ? 262144 : 0) | (((Boolean)paramArrayOfObject[5]).booleanValue() ? 131072 : 0) | (((Boolean)paramArrayOfObject[6]).booleanValue() ? 4194304 : 0));
        localEvent2.stateMask &= (i ^ 0xFFFFFFFF);
        if ((!sendKeyEvent(localEvent2)) || (this.browser.isDisposed())) {
          return false;
        }
        break;
      }
      return true;
    }
    if (str.equals("keypress"))
    {
      if (this.lastKeyCode == 0) {
        return true;
      }
      this.lastCharCode = ((Double)paramArrayOfObject[2]).intValue();
      if ((((Boolean)paramArrayOfObject[4]).booleanValue()) && (0 <= this.lastCharCode) && (this.lastCharCode <= 127))
      {
        if ((97 <= this.lastCharCode) && (this.lastCharCode <= 122)) {
          this.lastCharCode -= 32;
        }
        if ((64 <= this.lastCharCode) && (this.lastCharCode <= 95)) {
          this.lastCharCode -= 64;
        }
      }
      Event localEvent1 = new Event();
      localEvent1.widget = this.browser;
      localEvent1.type = 1;
      localEvent1.keyCode = this.lastKeyCode;
      localEvent1.character = ((char)this.lastCharCode);
      localEvent1.stateMask = ((((Boolean)paramArrayOfObject[3]).booleanValue() ? 65536 : 0) | (((Boolean)paramArrayOfObject[4]).booleanValue() ? 262144 : 0) | (((Boolean)paramArrayOfObject[5]).booleanValue() ? 131072 : 0) | (((Boolean)paramArrayOfObject[6]).booleanValue() ? 4194304 : 0));
      return (sendKeyEvent(localEvent1)) && (!this.browser.isDisposed());
    }
    if (str.equals("keyup"))
    {
      int j = translateKey(((Double)paramArrayOfObject[1]).intValue());
      if (j == 0) {
        return true;
      }
      if (j != this.lastKeyCode)
      {
        this.lastKeyCode = j;
        this.lastCharCode = 0;
      }
      localEvent2 = new Event();
      localEvent2.widget = this.browser;
      localEvent2.type = 2;
      localEvent2.keyCode = this.lastKeyCode;
      localEvent2.character = ((char)this.lastCharCode);
      localEvent2.stateMask = ((((Boolean)paramArrayOfObject[3]).booleanValue() ? 65536 : 0) | (((Boolean)paramArrayOfObject[4]).booleanValue() ? 262144 : 0) | (((Boolean)paramArrayOfObject[5]).booleanValue() ? 131072 : 0) | (((Boolean)paramArrayOfObject[6]).booleanValue() ? 4194304 : 0));
      switch (this.lastKeyCode)
      {
      case 65536: 
      case 131072: 
      case 262144: 
      case 4194304: 
        localEvent2.stateMask |= this.lastKeyCode;
      }
      this.browser.notifyListeners(localEvent2.type, localEvent2);
      this.lastKeyCode = (this.lastCharCode = 0);
      return (localEvent2.doit) && (!this.browser.isDisposed());
    }
    if (((str.equals("mouseover")) || (str.equals("mouseout"))) && (((Boolean)paramArrayOfObject[9]).booleanValue())) {
      return true;
    }
    Point localPoint = new Point(((Double)paramArrayOfObject[1]).intValue(), ((Double)paramArrayOfObject[2]).intValue());
    localPoint = this.browser.getDisplay().map(null, this.browser, localPoint);
    Event localEvent2 = new Event();
    localEvent2.widget = this.browser;
    localEvent2.x = localPoint.x;
    localEvent2.y = localPoint.y;
    int k = (((Boolean)paramArrayOfObject[5]).booleanValue() ? 65536 : 0) | (((Boolean)paramArrayOfObject[6]).booleanValue() ? 262144 : 0) | (((Boolean)paramArrayOfObject[7]).booleanValue() ? 131072 : 0);
    localEvent2.stateMask = k;
    if (str.equals("mousedown"))
    {
      localEvent2.type = 3;
      localEvent2.count = ((Double)paramArrayOfObject[3]).intValue();
      localEvent2.button = ((Double)paramArrayOfObject[4]).intValue();
      this.browser.notifyListeners(localEvent2.type, localEvent2);
      if (this.browser.isDisposed()) {
        return true;
      }
      if (((Double)paramArrayOfObject[3]).intValue() == 2)
      {
        localEvent2 = new Event();
        localEvent2.type = 8;
        localEvent2.widget = this.browser;
        localEvent2.x = localPoint.x;
        localEvent2.y = localPoint.y;
        localEvent2.stateMask = k;
        localEvent2.count = ((Double)paramArrayOfObject[3]).intValue();
        localEvent2.button = ((Double)paramArrayOfObject[4]).intValue();
        this.browser.notifyListeners(localEvent2.type, localEvent2);
      }
      return true;
    }
    if (str.equals("mouseup"))
    {
      localEvent2.type = 4;
      localEvent2.count = ((Double)paramArrayOfObject[3]).intValue();
      localEvent2.button = ((Double)paramArrayOfObject[4]).intValue();
      switch (localEvent2.button)
      {
      case 1: 
        localEvent2.stateMask |= 0x80000;
        break;
      case 2: 
        localEvent2.stateMask |= 0x100000;
        break;
      case 3: 
        localEvent2.stateMask |= 0x200000;
        break;
      case 4: 
        localEvent2.stateMask |= 0x800000;
        break;
      case 5: 
        localEvent2.stateMask |= 0x2000000;
      }
    }
    else if (str.equals("mousemove"))
    {
      localEvent2.type = 5;
    }
    else if (str.equals("mousewheel"))
    {
      localEvent2.type = 37;
      localEvent2.count = ((Double)paramArrayOfObject[3]).intValue();
    }
    else if (str.equals("mouseover"))
    {
      localEvent2.type = 6;
    }
    else if (str.equals("mouseout"))
    {
      localEvent2.type = 7;
      if (localEvent2.x < 0) {
        localEvent2.x = -1;
      }
      if (localEvent2.y < 0) {
        localEvent2.y = -1;
      }
    }
    else if (str.equals("dragstart"))
    {
      localEvent2.type = 29;
      localEvent2.button = (((Double)paramArrayOfObject[4]).intValue() + 1);
      switch (localEvent2.button)
      {
      case 1: 
        localEvent2.stateMask |= 0x80000;
        break;
      case 2: 
        localEvent2.stateMask |= 0x100000;
        break;
      case 3: 
        localEvent2.stateMask |= 0x200000;
        break;
      case 4: 
        localEvent2.stateMask |= 0x800000;
        break;
      case 5: 
        localEvent2.stateMask |= 0x2000000;
      }
    }
    this.browser.notifyListeners(localEvent2.type, localEvent2);
    return true;
  }
  
  public boolean isBackEnabled()
  {
    int[] arrayOfInt1 = new int[1];
    int i = this.webView.QueryInterface(WebKit_win32.IID_IWebIBActions, arrayOfInt1);
    if ((i != 0) || (arrayOfInt1[0] == 0)) {
      return false;
    }
    IWebIBActions localIWebIBActions = new IWebIBActions(arrayOfInt1[0]);
    int[] arrayOfInt2 = new int[1];
    localIWebIBActions.canGoBack(this.webView.getAddress(), arrayOfInt2);
    localIWebIBActions.Release();
    return arrayOfInt2[0] != 0;
  }
  
  public boolean isFocusControl()
  {
    int i = OS.GetFocus();
    return (i != 0) && (i == this.webViewWindowHandle);
  }
  
  public boolean isForwardEnabled()
  {
    int[] arrayOfInt1 = new int[1];
    int i = this.webView.QueryInterface(WebKit_win32.IID_IWebIBActions, arrayOfInt1);
    if ((i != 0) || (arrayOfInt1[0] == 0)) {
      return false;
    }
    IWebIBActions localIWebIBActions = new IWebIBActions(arrayOfInt1[0]);
    int[] arrayOfInt2 = new int[1];
    localIWebIBActions.canGoForward(this.webView.getAddress(), arrayOfInt2);
    localIWebIBActions.Release();
    return arrayOfInt2[0] != 0;
  }
  
  void onDispose()
  {
    if ((!this.browser.isDisposed()) && (!this.browser.isClosing))
    {
      this.webUIDelegate.prompt = false;
      shouldClose();
      this.webUIDelegate.prompt = true;
    }
    Enumeration localEnumeration = this.functions.elements();
    while (localEnumeration.hasMoreElements()) {
      ((BrowserFunction)localEnumeration.nextElement()).dispose(false);
    }
    this.functions = null;
    this.eventFunction.dispose();
    this.eventFunction = null;
    C.free(this.webViewData);
    this.webView.setPreferences(0);
    this.webView.setHostWindow(0);
    this.webView.setFrameLoadDelegate(0);
    this.webView.setResourceLoadDelegate(0);
    this.webView.setUIDelegate(0);
    this.webView.setPolicyDelegate(0);
    this.webView.setDownloadDelegate(0);
    this.webView.Release();
    this.webView = null;
    this.webDownloadDelegate = null;
    this.webFrameLoadDelegate = null;
    this.webPolicyDelegate = null;
    this.webResourceLoadDelegate = null;
    this.webUIDelegate = null;
    this.lastNavigateURL = null;
  }
  
  public void refresh()
  {
    this.webFrameLoadDelegate.html = null;
    int[] arrayOfInt = new int[1];
    int i = this.webView.QueryInterface(WebKit_win32.IID_IWebIBActions, arrayOfInt);
    if ((i != 0) || (arrayOfInt[0] == 0)) {
      return;
    }
    IWebIBActions localIWebIBActions = new IWebIBActions(arrayOfInt[0]);
    localIWebIBActions.reload(this.webView.getAddress());
    localIWebIBActions.Release();
  }
  
  boolean sendKeyEvent(Event paramEvent)
  {
    boolean bool1 = true;
    switch (paramEvent.keyCode)
    {
    case 9: 
    case 13: 
    case 27: 
    case 16777217: 
    case 16777218: 
    case 16777219: 
    case 16777220: 
    case 16777221: 
    case 16777222: 
      break;
    default: 
      if ((translateMnemonics()) && (paramEvent.character != 0) && ((paramEvent.stateMask & 0x50000) == 65536))
      {
        int i = 128;
        boolean bool2 = paramEvent.doit;
        paramEvent.doit = true;
        bool1 = !this.browser.traverse(i, paramEvent);
        paramEvent.doit = bool2;
      }
      break;
    }
    if (bool1)
    {
      this.browser.notifyListeners(paramEvent.type, paramEvent);
      bool1 = paramEvent.doit;
    }
    return bool1;
  }
  
  public boolean setText(String paramString, boolean paramBoolean)
  {
    int i = this.webFrameLoadDelegate.html != null ? 1 : 0;
    this.webFrameLoadDelegate.html = paramString;
    this.untrustedText = (!paramBoolean);
    if (i != 0) {
      return true;
    }
    int[] arrayOfInt = new int[1];
    int j = this.webView.mainFrame(arrayOfInt);
    if ((j != 0) || (arrayOfInt[0] == 0)) {
      return false;
    }
    IWebFrame localIWebFrame = new IWebFrame(arrayOfInt[0]);
    arrayOfInt[0] = 0;
    j = WebKit_win32.WebKitCreateInstance(WebKit_win32.CLSID_WebMutableURLRequest, 0, WebKit_win32.IID_IWebMutableURLRequest, arrayOfInt);
    if ((j != 0) || (arrayOfInt[0] == 0))
    {
      localIWebFrame.Release();
      return false;
    }
    IWebMutableURLRequest localIWebMutableURLRequest = new IWebMutableURLRequest(arrayOfInt[0]);
    int k = createBSTR("about:blank");
    j = localIWebMutableURLRequest.setURL(k);
    COM.SysFreeString(k);
    if (j == 0) {
      j = localIWebFrame.loadRequest(localIWebMutableURLRequest.getAddress());
    }
    localIWebFrame.Release();
    localIWebMutableURLRequest.Release();
    return j == 0;
  }
  
  public boolean setUrl(String paramString1, String paramString2, String[] paramArrayOfString)
  {
    if (paramString1.length() == 0) {
      return false;
    }
    try
    {
      new URL(paramString1);
    }
    catch (MalformedURLException localMalformedURLException1)
    {
      String str1 = null;
      if (new File(paramString1).isAbsolute()) {
        str1 = "file://" + paramString1;
      } else {
        str1 = "http://" + paramString1;
      }
      try
      {
        new URL(str1);
        paramString1 = str1;
      }
      catch (MalformedURLException localMalformedURLException2) {}
    }
    this.webFrameLoadDelegate.html = null;
    this.lastNavigateURL = paramString1;
    int[] arrayOfInt = new int[1];
    int i = this.webView.mainFrame(arrayOfInt);
    if ((i != 0) || (arrayOfInt[0] == 0)) {
      return false;
    }
    IWebFrame localIWebFrame = new IWebFrame(arrayOfInt[0]);
    arrayOfInt[0] = 0;
    i = WebKit_win32.WebKitCreateInstance(WebKit_win32.CLSID_WebMutableURLRequest, 0, WebKit_win32.IID_IWebMutableURLRequest, arrayOfInt);
    if ((i != 0) || (arrayOfInt[0] == 0))
    {
      localIWebFrame.Release();
      return false;
    }
    IWebMutableURLRequest localIWebMutableURLRequest = new IWebMutableURLRequest(arrayOfInt[0]);
    if (paramString2 != null) {}
    i = 0;
    int j;
    if (paramArrayOfString != null) {
      for (j = 0; j < paramArrayOfString.length; j++)
      {
        String str2 = paramArrayOfString[j];
        if (str2 != null)
        {
          int k = str2.indexOf(':');
          if (k != -1)
          {
            String str3 = str2.substring(0, k).trim();
            String str4 = str2.substring(k + 1).trim();
            if ((str3.length() > 0) && (str4.length() > 0))
            {
              int m = createBSTR(str4);
              if (str3.equalsIgnoreCase("user-agent"))
              {
                i = this.webView.setCustomUserAgent(m);
              }
              else
              {
                int n = createBSTR(str3);
                i = localIWebMutableURLRequest.setValue(m, n);
                COM.SysFreeString(n);
              }
              COM.SysFreeString(m);
            }
          }
        }
      }
    }
    if (i == 0)
    {
      j = createBSTR(paramString1);
      i = localIWebMutableURLRequest.setURL(j);
      COM.SysFreeString(j);
      if (i == 0) {
        i = localIWebFrame.loadRequest(localIWebMutableURLRequest.getAddress());
      }
      this.webView.setCustomUserAgent(0);
    }
    localIWebFrame.Release();
    localIWebMutableURLRequest.Release();
    return i == 0;
  }
  
  boolean shouldClose()
  {
    if (!this.jsEnabled) {
      return true;
    }
    int[] arrayOfInt1 = new int[1];
    int i = this.webView.QueryInterface(WebKit_win32.IID_IWebViewPrivate, arrayOfInt1);
    if ((i != 0) || (arrayOfInt1[0] == 0)) {
      return false;
    }
    IWebViewPrivate localIWebViewPrivate = new IWebViewPrivate(arrayOfInt1[0]);
    int[] arrayOfInt2 = new int[1];
    localIWebViewPrivate.shouldClose(arrayOfInt2);
    localIWebViewPrivate.Release();
    return arrayOfInt2[0] != 0;
  }
  
  public void stop()
  {
    this.webFrameLoadDelegate.html = null;
    int[] arrayOfInt = new int[1];
    int i = this.webView.QueryInterface(WebKit_win32.IID_IWebIBActions, arrayOfInt);
    if ((i != 0) || (arrayOfInt[0] == 0)) {
      return;
    }
    IWebIBActions localIWebIBActions = new IWebIBActions(arrayOfInt[0]);
    localIWebIBActions.stopLoading(this.webView.getAddress());
    localIWebIBActions.Release();
  }
  
  void initializeWebViewPreferences()
  {
    int[] arrayOfInt = new int[1];
    int i = WebKit_win32.WebKitCreateInstance(WebKit_win32.CLSID_WebPreferences, 0, WebKit_win32.IID_IWebPreferences, arrayOfInt);
    IWebPreferences localIWebPreferences;
    if ((i == 0) && (arrayOfInt[0] != 0))
    {
      localIWebPreferences = new IWebPreferences(arrayOfInt[0]);
      arrayOfInt[0] = 0;
      i = localIWebPreferences.initWithIdentifier(createBSTR(String.valueOf(prefsIdentifier++)), arrayOfInt);
      localIWebPreferences.Release();
      if ((i == 0) && (arrayOfInt[0] != 0))
      {
        localIWebPreferences = new IWebPreferences(arrayOfInt[0]);
        this.webView.setPreferences(localIWebPreferences.getAddress());
        localIWebPreferences.Release();
      }
    }
    arrayOfInt[0] = 0;
    i = this.webView.preferences(arrayOfInt);
    if ((i == 0) && (arrayOfInt[0] != 0))
    {
      localIWebPreferences = new IWebPreferences(arrayOfInt[0]);
      localIWebPreferences.setJavaScriptEnabled(1);
      localIWebPreferences.setJavaScriptCanOpenWindowsAutomatically(1);
      localIWebPreferences.setJavaEnabled(0);
      localIWebPreferences.setTabsToLinks(1);
      localIWebPreferences.setFontSmoothing(4);
      localIWebPreferences.Release();
    }
  }
  
  static
  {
    try
    {
      Library.loadLibrary("swt-webkit");
      LibraryLoaded = true;
    }
    catch (Throwable localThrowable1) {}
    if (!LibraryLoaded)
    {
      String str = readInstallDir("SOFTWARE\\Apple Computer, Inc.\\Safari");
      if (str != null)
      {
        str = str + "\\Apple Application Support";
        if (!new File(str).exists()) {
          str = null;
        }
      }
      if (str == null) {
        str = readInstallDir("SOFTWARE\\Apple Inc.\\Apple Application Support");
      }
      if (str != null)
      {
        TCHAR localTCHAR = new TCHAR(0, str, true);
        boolean bool = OS.SetDllDirectory(localTCHAR);
        if (bool)
        {
          try
          {
            Library.loadLibrary("swt-webkit");
            LibraryLoaded = true;
          }
          catch (Throwable localThrowable2)
          {
            LibraryLoadError = "Failed to load the swt-webkit library";
            if (Device.DEBUG) {
              System.out.println("Failed to load swt-webkit library. Apple Application Support directory path: " + str);
            }
          }
        }
        else
        {
          LibraryLoadError = "Failed to add the Apple Application Support package to the library lookup path.  ";
          LibraryLoadError = LibraryLoadError + "To use a SWT.WEBKIT-style Browser prepend " + str + " to your Windows 'Path' environment variable and restart.";
        }
      }
      else
      {
        LibraryLoadError = "Safari must be installed to use a SWT.WEBKIT-style Browser";
      }
    }
    if (LibraryLoaded)
    {
      JSObjectHasPropertyProc = new Callback(WebKit.class, "JSObjectHasPropertyProc", 3);
      if (JSObjectHasPropertyProc.getAddress() == 0) {
        SWT.error(3);
      }
      JSObjectGetPropertyProc = new Callback(WebKit.class, "JSObjectGetPropertyProc", 4);
      if (JSObjectGetPropertyProc.getAddress() == 0) {
        SWT.error(3);
      }
      JSObjectCallAsFunctionProc = new Callback(WebKit.class, "JSObjectCallAsFunctionProc", 6);
      if (JSObjectCallAsFunctionProc.getAddress() == 0) {
        SWT.error(3);
      }
      NativeClearSessions = new Runnable()
      {
        public void run()
        {
          int[] arrayOfInt1 = new int[1];
          int i = WebKit_win32.WebKitCreateInstance(WebKit_win32.CLSID_WebCookieManager, 0, WebKit_win32.IID_IWebCookieManager, arrayOfInt1);
          if ((i != 0) || (arrayOfInt1[0] == 0)) {
            return;
          }
          IWebCookieManager localIWebCookieManager = new IWebCookieManager(arrayOfInt1[0]);
          int[] arrayOfInt2 = new int[1];
          i = localIWebCookieManager.cookieStorage(arrayOfInt2);
          localIWebCookieManager.Release();
          if ((i != 0) || (arrayOfInt2[0] == 0)) {
            return;
          }
          int j = WebKit_win32.CFHTTPCookieStorageCopyCookies(arrayOfInt2[0]);
          if (j != 0)
          {
            int k = WebKit_win32.CFArrayGetCount(j);
            for (int m = 0; m < k; m++)
            {
              int n = WebKit_win32.CFArrayGetValueAtIndex(j, m);
              int i1 = WebKit_win32.CFHTTPCookieGetFlags(n);
              if ((i1 & 0x2) != 0) {
                WebKit_win32.CFHTTPCookieStorageDeleteCookie(arrayOfInt2[0], n);
              }
            }
            WebKit_win32.CFRelease(j);
          }
        }
      };
      NativeGetCookie = new Runnable()
      {
        public void run()
        {
          int[] arrayOfInt1 = new int[1];
          int i = WebKit_win32.WebKitCreateInstance(WebKit_win32.CLSID_WebCookieManager, 0, WebKit_win32.IID_IWebCookieManager, arrayOfInt1);
          if ((i != 0) || (arrayOfInt1[0] == 0)) {
            return;
          }
          IWebCookieManager localIWebCookieManager = new IWebCookieManager(arrayOfInt1[0]);
          int[] arrayOfInt2 = new int[1];
          i = localIWebCookieManager.cookieStorage(arrayOfInt2);
          localIWebCookieManager.Release();
          if ((i != 0) || (arrayOfInt2[0] == 0)) {
            return;
          }
          char[] arrayOfChar = WebBrowser.CookieUrl.toCharArray();
          int j = WebKit_win32.CFStringCreateWithCharacters(0, arrayOfChar, arrayOfChar.length);
          if (j != 0)
          {
            int k = WebKit_win32.CFURLCreateWithString(0, j, 0);
            if (k != 0)
            {
              boolean bool = WebBrowser.CookieUrl.startsWith("https://");
              int m = WebKit_win32.CFHTTPCookieStorageCopyCookiesForURL(arrayOfInt2[0], k, bool);
              if (m != 0)
              {
                int n = WebKit_win32.CFArrayGetCount(m);
                for (int i1 = 0; i1 < n; i1++)
                {
                  int i2 = WebKit_win32.CFArrayGetValueAtIndex(m, i1);
                  if (i2 != 0)
                  {
                    int i3 = WebKit_win32.CFHTTPCookieGetName(i2);
                    if (i3 != 0)
                    {
                      String str = WebKit.stringFromCFString(i3);
                      if (WebBrowser.CookieName.equals(str))
                      {
                        int i4 = WebKit_win32.CFHTTPCookieGetValue(i2);
                        if (i4 == 0) {
                          break;
                        }
                        WebBrowser.CookieValue = WebKit.stringFromCFString(i4);
                        break;
                      }
                    }
                  }
                }
                WebKit_win32.CFRelease(m);
              }
              WebKit_win32.CFRelease(k);
            }
            WebKit_win32.CFRelease(j);
          }
        }
      };
      NativeSetCookie = new Runnable()
      {
        public void run()
        {
          int[] arrayOfInt1 = new int[1];
          int i = WebKit_win32.WebKitCreateInstance(WebKit_win32.CLSID_WebCookieManager, 0, WebKit_win32.IID_IWebCookieManager, arrayOfInt1);
          if ((i != 0) || (arrayOfInt1[0] == 0)) {
            return;
          }
          IWebCookieManager localIWebCookieManager = new IWebCookieManager(arrayOfInt1[0]);
          int[] arrayOfInt2 = new int[1];
          i = localIWebCookieManager.cookieStorage(arrayOfInt2);
          localIWebCookieManager.Release();
          if ((i != 0) || (arrayOfInt2[0] == 0)) {
            return;
          }
          char[] arrayOfChar = WebBrowser.CookieUrl.toCharArray();
          int j = WebKit_win32.CFStringCreateWithCharacters(0, arrayOfChar, arrayOfChar.length);
          if (j != 0)
          {
            int k = WebKit_win32.CFURLCreateWithString(0, j, 0);
            if (k != 0)
            {
              arrayOfChar = WebBrowser.CookieValue.toCharArray();
              int m = WebKit_win32.CFStringCreateWithCharacters(0, arrayOfChar, arrayOfChar.length);
              if (m != 0)
              {
                arrayOfChar = "Set-Cookie".toCharArray();
                int n = WebKit_win32.CFStringCreateWithCharacters(0, arrayOfChar, arrayOfChar.length);
                if (n != 0)
                {
                  int i1 = WebKit_win32.CFDictionaryCreate(0, new int[] { n }, new int[] { m }, 1, WebKit_win32.kCFCopyStringDictionaryKeyCallBacks(), WebKit_win32.kCFTypeDictionaryValueCallBacks());
                  if (i1 != 0)
                  {
                    int i2 = WebKit_win32.CFHTTPCookieCreateWithResponseHeaderFields(0, i1, k);
                    if (i2 != 0)
                    {
                      int i3 = WebKit_win32.CFArrayGetValueAtIndex(i2, 0);
                      if (i3 != 0)
                      {
                        WebKit_win32.CFHTTPCookieStorageSetCookie(arrayOfInt2[0], i3);
                        WebBrowser.CookieResult = true;
                      }
                      WebKit_win32.CFRelease(i2);
                    }
                    WebKit_win32.CFRelease(i1);
                  }
                  WebKit_win32.CFRelease(n);
                }
                WebKit_win32.CFRelease(m);
              }
              WebKit_win32.CFRelease(k);
            }
            WebKit_win32.CFRelease(j);
          }
        }
      };
      if (NativePendingCookies != null) {
        SetPendingCookies(NativePendingCookies);
      }
      NativePendingCookies = null;
    }
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_32.jar!/org/eclipse/swt/browser/WebKit.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */