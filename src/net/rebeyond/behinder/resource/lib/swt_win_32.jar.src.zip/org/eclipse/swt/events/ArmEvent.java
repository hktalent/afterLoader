package org.eclipse.swt.events;

import org.eclipse.swt.widgets.Event;

public final class ArmEvent
  extends TypedEvent
{
  static final long serialVersionUID = 3258126964249212217L;
  
  public ArmEvent(Event paramEvent)
  {
    super(paramEvent);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_32.jar!/org/eclipse/swt/events/ArmEvent.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */