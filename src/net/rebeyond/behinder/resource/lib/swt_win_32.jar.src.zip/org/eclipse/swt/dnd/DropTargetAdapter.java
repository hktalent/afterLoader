package org.eclipse.swt.dnd;

public class DropTargetAdapter
  implements DropTargetListener
{
  public void dragEnter(DropTargetEvent paramDropTargetEvent) {}
  
  public void dragLeave(DropTargetEvent paramDropTargetEvent) {}
  
  public void dragOperationChanged(DropTargetEvent paramDropTargetEvent) {}
  
  public void dragOver(DropTargetEvent paramDropTargetEvent) {}
  
  public void drop(DropTargetEvent paramDropTargetEvent) {}
  
  public void dropAccept(DropTargetEvent paramDropTargetEvent) {}
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_32.jar!/org/eclipse/swt/dnd/DropTargetAdapter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */