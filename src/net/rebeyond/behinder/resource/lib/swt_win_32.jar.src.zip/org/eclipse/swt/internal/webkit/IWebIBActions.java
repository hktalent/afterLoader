package org.eclipse.swt.internal.webkit;

import org.eclipse.swt.internal.ole.win32.COM;
import org.eclipse.swt.internal.ole.win32.IUnknown;

public class IWebIBActions
  extends IUnknown
{
  public IWebIBActions(int paramInt)
  {
    super(paramInt);
  }
  
  public int stopLoading(int paramInt)
  {
    return COM.VtblCall(4, getAddress(), paramInt);
  }
  
  public int reload(int paramInt)
  {
    return COM.VtblCall(5, getAddress(), paramInt);
  }
  
  public int canGoBack(int paramInt, int[] paramArrayOfInt)
  {
    return COM.VtblCall(6, getAddress(), paramInt, paramArrayOfInt);
  }
  
  public int canGoForward(int paramInt, int[] paramArrayOfInt)
  {
    return COM.VtblCall(8, getAddress(), paramInt, paramArrayOfInt);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_32.jar!/org/eclipse/swt/internal/webkit/IWebIBActions.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */