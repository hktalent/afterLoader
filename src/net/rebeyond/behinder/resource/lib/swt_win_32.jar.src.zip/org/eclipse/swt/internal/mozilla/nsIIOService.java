package org.eclipse.swt.internal.mozilla;

public class nsIIOService
  extends nsISupports
{
  static final int LAST_METHOD_ID = nsISupports.LAST_METHOD_ID + 10;
  static final String NS_IIOSERVICE_IID_STR = "bddeda3f-9020-4d12-8c70-984ee9f7935e";
  
  public nsIIOService(int paramInt)
  {
    super(paramInt);
  }
  
  public int NewURI(int paramInt1, byte[] paramArrayOfByte, int paramInt2, int[] paramArrayOfInt)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 3, getAddress(), paramInt1, paramArrayOfByte, paramInt2, paramArrayOfInt);
  }
  
  static
  {
    IIDStore.RegisterIID(nsIIOService.class, 0, new nsID("bddeda3f-9020-4d12-8c70-984ee9f7935e"));
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_32.jar!/org/eclipse/swt/internal/mozilla/nsIIOService.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */