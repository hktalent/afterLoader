package org.eclipse.swt.internal.ole.win32;

public final class CONTROLINFO
{
  public int cb;
  public int hAccel;
  public short cAccel;
  public int dwFlags;
  public static final int sizeof = ;
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_32.jar!/org/eclipse/swt/internal/ole/win32/CONTROLINFO.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */