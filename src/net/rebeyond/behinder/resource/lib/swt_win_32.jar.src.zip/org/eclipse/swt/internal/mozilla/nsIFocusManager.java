package org.eclipse.swt.internal.mozilla;

public class nsIFocusManager
  extends nsISupports
{
  static final int LAST_METHOD_ID = nsISupports.LAST_METHOD_ID + ((IsXULRunner10()) || (IsXULRunner24()) ? 18 : 17);
  static final String NS_IFOCUSMANAGER_IID_STR = "cd6040a8-243f-412a-8a16-0bf2aa1083b9";
  static final String NS_IFOCUSMANAGER_10_IID_STR = "51db277b-7ee7-4bce-9b84-fd2efcd2c8bd";
  public static final int FLAG_RAISE = 1;
  public static final int FLAG_NOSCROLL = 2;
  public static final int FLAG_NOSWITCHFRAME = 4;
  public static final int FLAG_BYMOUSE = 4096;
  public static final int FLAG_BYKEY = 8192;
  public static final int FLAG_BYMOVEFOCUS = 16384;
  public static final int MOVEFOCUS_FORWARD = 1;
  public static final int MOVEFOCUS_BACKWARD = 2;
  public static final int MOVEFOCUS_FORWARDDOC = 3;
  public static final int MOVEFOCUS_BACKWARDDOC = 4;
  public static final int MOVEFOCUS_FIRST = 5;
  public static final int MOVEFOCUS_LAST = 6;
  public static final int MOVEFOCUS_ROOT = 7;
  public static final int MOVEFOCUS_CARET = 8;
  
  public nsIFocusManager(int paramInt)
  {
    super(paramInt);
  }
  
  public int GetFocusedElement(int[] paramArrayOfInt)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 5, getAddress(), paramArrayOfInt);
  }
  
  public int SetFocus(int paramInt1, int paramInt2)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 7, getAddress(), paramInt1, paramInt2);
  }
  
  static
  {
    IIDStore.RegisterIID(nsIFocusManager.class, 0, new nsID("cd6040a8-243f-412a-8a16-0bf2aa1083b9"));
    IIDStore.RegisterIID(nsIFocusManager.class, 5, new nsID("51db277b-7ee7-4bce-9b84-fd2efcd2c8bd"));
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_32.jar!/org/eclipse/swt/internal/mozilla/nsIFocusManager.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */