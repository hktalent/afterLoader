package org.eclipse.swt.events;

import org.eclipse.swt.widgets.Event;

public class GestureEvent
  extends TypedEvent
{
  public int stateMask;
  public int detail;
  public int x;
  public int y;
  public double rotation;
  public int xDirection;
  public int yDirection;
  public double magnification;
  public boolean doit;
  static final long serialVersionUID = -8348741538373572182L;
  
  public GestureEvent(Event paramEvent)
  {
    super(paramEvent);
    this.stateMask = paramEvent.stateMask;
    this.x = paramEvent.x;
    this.y = paramEvent.y;
    this.detail = paramEvent.detail;
    this.rotation = paramEvent.rotation;
    this.xDirection = paramEvent.xDirection;
    this.yDirection = paramEvent.yDirection;
    this.magnification = paramEvent.magnification;
    this.doit = paramEvent.doit;
  }
  
  public String toString()
  {
    String str = super.toString();
    return str.substring(0, str.length() - 1) + " stateMask=0x" + Integer.toHexString(this.stateMask) + " detail=" + this.detail + " x=" + this.x + " y=" + this.y + " rotation=" + this.rotation + " xDirection=" + this.xDirection + " yDirection=" + this.yDirection + " magnification=" + this.magnification + "}";
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_32.jar!/org/eclipse/swt/events/GestureEvent.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */