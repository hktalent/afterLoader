package org.eclipse.swt.internal.webkit;

import org.eclipse.swt.internal.ole.win32.COM;
import org.eclipse.swt.internal.ole.win32.IUnknown;

public class IWebURLCredential
  extends IUnknown
{
  public IWebURLCredential(int paramInt)
  {
    super(paramInt);
  }
  
  public int hasPassword(int[] paramArrayOfInt)
  {
    return COM.VtblCall(3, getAddress(), paramArrayOfInt);
  }
  
  public int initWithUser(int paramInt1, int paramInt2, int paramInt3)
  {
    return COM.VtblCall(4, getAddress(), paramInt1, paramInt2, paramInt3);
  }
  
  public int password(int[] paramArrayOfInt)
  {
    return COM.VtblCall(5, getAddress(), paramArrayOfInt);
  }
  
  public int user(int[] paramArrayOfInt)
  {
    return COM.VtblCall(7, getAddress(), paramArrayOfInt);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_32.jar!/org/eclipse/swt/internal/webkit/IWebURLCredential.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */