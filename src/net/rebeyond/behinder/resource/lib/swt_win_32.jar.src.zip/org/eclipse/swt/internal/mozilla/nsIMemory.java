package org.eclipse.swt.internal.mozilla;

public class nsIMemory
  extends nsISupports
{
  static final int LAST_METHOD_ID = nsISupports.LAST_METHOD_ID + (IsXULRunner24() ? 6 : 5);
  static final String NS_IMEMORY_IID_STR = "59e7e77a-38e4-11d4-8cf5-0060b0fc14a3";
  static final String NS_IMEMORY_24_IID_STR = "6aef11c4-8615-44a6-9711-98f43805693d";
  
  public nsIMemory(int paramInt)
  {
    super(paramInt);
  }
  
  public int Alloc(int paramInt)
  {
    return XPCOM.nsIMemory_Alloc(getAddress(), paramInt);
  }
  
  public int Free(int paramInt)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 3, getAddress(), paramInt);
  }
  
  static
  {
    IIDStore.RegisterIID(nsIMemory.class, 0, new nsID("59e7e77a-38e4-11d4-8cf5-0060b0fc14a3"));
    IIDStore.RegisterIID(nsIMemory.class, 6, new nsID("6aef11c4-8615-44a6-9711-98f43805693d"));
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_32.jar!/org/eclipse/swt/internal/mozilla/nsIMemory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */