package org.eclipse.swt.dnd;

import org.eclipse.swt.internal.ole.win32.STGMEDIUM;
import org.eclipse.swt.internal.win32.OS;

public class RTFTransfer
  extends ByteArrayTransfer
{
  private static RTFTransfer _instance = new RTFTransfer();
  private static final String CF_RTF = "Rich Text Format";
  private static final int CF_RTFID = registerType("Rich Text Format");
  
  public static RTFTransfer getInstance()
  {
    return _instance;
  }
  
  public void javaToNative(Object paramObject, TransferData paramTransferData)
  {
    if ((!checkRTF(paramObject)) || (!isSupportedType(paramTransferData))) {
      DND.error(2003);
    }
    String str = (String)paramObject;
    int i = str.length();
    char[] arrayOfChar = new char[i + 1];
    str.getChars(0, i, arrayOfChar, 0);
    int j = OS.GetACP();
    int k = OS.WideCharToMultiByte(j, 0, arrayOfChar, -1, null, 0, null, null);
    if (k == 0)
    {
      paramTransferData.stgmedium = new STGMEDIUM();
      paramTransferData.result = -2147221402;
      return;
    }
    int m = OS.GlobalAlloc(64, k);
    OS.WideCharToMultiByte(j, 0, arrayOfChar, -1, m, k, null, null);
    paramTransferData.stgmedium = new STGMEDIUM();
    paramTransferData.stgmedium.tymed = 1;
    paramTransferData.stgmedium.unionField = m;
    paramTransferData.stgmedium.pUnkForRelease = 0;
    paramTransferData.result = 0;
  }
  
  /* Error */
  public Object nativeToJava(TransferData paramTransferData)
  {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: invokevirtual 4	org/eclipse/swt/dnd/RTFTransfer:isSupportedType	(Lorg/eclipse/swt/dnd/TransferData;)Z
    //   5: ifeq +10 -> 15
    //   8: aload_1
    //   9: getfield 21	org/eclipse/swt/dnd/TransferData:pIDataObject	I
    //   12: ifne +5 -> 17
    //   15: aconst_null
    //   16: areturn
    //   17: new 22	org/eclipse/swt/internal/ole/win32/IDataObject
    //   20: dup
    //   21: aload_1
    //   22: getfield 21	org/eclipse/swt/dnd/TransferData:pIDataObject	I
    //   25: invokespecial 23	org/eclipse/swt/internal/ole/win32/IDataObject:<init>	(I)V
    //   28: astore_2
    //   29: aload_2
    //   30: invokevirtual 24	org/eclipse/swt/internal/ole/win32/IDataObject:AddRef	()I
    //   33: pop
    //   34: new 11	org/eclipse/swt/internal/ole/win32/STGMEDIUM
    //   37: dup
    //   38: invokespecial 12	org/eclipse/swt/internal/ole/win32/STGMEDIUM:<init>	()V
    //   41: astore_3
    //   42: aload_1
    //   43: getfield 25	org/eclipse/swt/dnd/TransferData:formatetc	Lorg/eclipse/swt/internal/ole/win32/FORMATETC;
    //   46: astore 4
    //   48: aload_3
    //   49: iconst_1
    //   50: putfield 18	org/eclipse/swt/internal/ole/win32/STGMEDIUM:tymed	I
    //   53: aload_1
    //   54: aload_0
    //   55: aload_2
    //   56: aload 4
    //   58: aload_3
    //   59: invokevirtual 26	org/eclipse/swt/dnd/RTFTransfer:getData	(Lorg/eclipse/swt/internal/ole/win32/IDataObject;Lorg/eclipse/swt/internal/ole/win32/FORMATETC;Lorg/eclipse/swt/internal/ole/win32/STGMEDIUM;)I
    //   62: putfield 15	org/eclipse/swt/dnd/TransferData:result	I
    //   65: aload_2
    //   66: invokevirtual 27	org/eclipse/swt/internal/ole/win32/IDataObject:Release	()I
    //   69: pop
    //   70: aload_1
    //   71: getfield 15	org/eclipse/swt/dnd/TransferData:result	I
    //   74: ifeq +5 -> 79
    //   77: aconst_null
    //   78: areturn
    //   79: aload_3
    //   80: getfield 19	org/eclipse/swt/internal/ole/win32/STGMEDIUM:unionField	I
    //   83: istore 5
    //   85: iload 5
    //   87: invokestatic 28	org/eclipse/swt/internal/win32/OS:GlobalLock	(I)I
    //   90: istore 6
    //   92: iload 6
    //   94: ifne +12 -> 106
    //   97: aconst_null
    //   98: astore 7
    //   100: jsr +110 -> 210
    //   103: aload 7
    //   105: areturn
    //   106: invokestatic 9	org/eclipse/swt/internal/win32/OS:GetACP	()I
    //   109: istore 7
    //   111: iload 7
    //   113: iconst_1
    //   114: iload 6
    //   116: iconst_m1
    //   117: aconst_null
    //   118: iconst_0
    //   119: invokestatic 29	org/eclipse/swt/internal/win32/OS:MultiByteToWideChar	(IIII[CI)I
    //   122: istore 8
    //   124: iload 8
    //   126: ifne +15 -> 141
    //   129: aconst_null
    //   130: astore 9
    //   132: jsr +60 -> 192
    //   135: jsr +75 -> 210
    //   138: aload 9
    //   140: areturn
    //   141: iload 8
    //   143: iconst_1
    //   144: isub
    //   145: newarray <illegal type>
    //   147: astore 9
    //   149: iload 7
    //   151: iconst_1
    //   152: iload 6
    //   154: iconst_m1
    //   155: aload 9
    //   157: aload 9
    //   159: arraylength
    //   160: invokestatic 29	org/eclipse/swt/internal/win32/OS:MultiByteToWideChar	(IIII[CI)I
    //   163: pop
    //   164: new 6	java/lang/String
    //   167: dup
    //   168: aload 9
    //   170: invokespecial 30	java/lang/String:<init>	([C)V
    //   173: astore 10
    //   175: jsr +17 -> 192
    //   178: jsr +32 -> 210
    //   181: aload 10
    //   183: areturn
    //   184: astore 11
    //   186: jsr +6 -> 192
    //   189: aload 11
    //   191: athrow
    //   192: astore 12
    //   194: iload 5
    //   196: invokestatic 31	org/eclipse/swt/internal/win32/OS:GlobalUnlock	(I)Z
    //   199: pop
    //   200: ret 12
    //   202: astore 13
    //   204: jsr +6 -> 210
    //   207: aload 13
    //   209: athrow
    //   210: astore 14
    //   212: iload 5
    //   214: invokestatic 32	org/eclipse/swt/internal/win32/OS:GlobalFree	(I)I
    //   217: pop
    //   218: ret 14
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	220	0	this	RTFTransfer
    //   0	220	1	paramTransferData	TransferData
    //   28	38	2	localIDataObject	org.eclipse.swt.internal.ole.win32.IDataObject
    //   41	39	3	localSTGMEDIUM	STGMEDIUM
    //   46	11	4	localFORMATETC	org.eclipse.swt.internal.ole.win32.FORMATETC
    //   83	130	5	i	int
    //   90	63	6	j	int
    //   98	6	7	localObject1	Object
    //   109	41	7	k	int
    //   122	23	8	m	int
    //   130	39	9	localObject2	Object
    //   173	9	10	str	String
    //   184	6	11	localObject3	Object
    //   192	1	12	localObject4	Object
    //   202	6	13	localObject5	Object
    //   210	1	14	localObject6	Object
    // Exception table:
    //   from	to	target	type
    //   106	135	184	finally
    //   141	178	184	finally
    //   184	189	184	finally
    //   85	103	202	finally
    //   106	138	202	finally
    //   141	181	202	finally
    //   184	207	202	finally
  }
  
  protected int[] getTypeIds()
  {
    return new int[] { CF_RTFID };
  }
  
  protected String[] getTypeNames()
  {
    return new String[] { "Rich Text Format" };
  }
  
  boolean checkRTF(Object paramObject)
  {
    return (paramObject != null) && ((paramObject instanceof String)) && (((String)paramObject).length() > 0);
  }
  
  protected boolean validate(Object paramObject)
  {
    return checkRTF(paramObject);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_32.jar!/org/eclipse/swt/dnd/RTFTransfer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */