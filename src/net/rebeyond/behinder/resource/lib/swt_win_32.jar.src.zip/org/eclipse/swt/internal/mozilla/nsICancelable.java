package org.eclipse.swt.internal.mozilla;

public class nsICancelable
  extends nsISupports
{
  static final int LAST_METHOD_ID = nsISupports.LAST_METHOD_ID + 1;
  static final String NS_ICANCELABLE_IID_STR = "d94ac0a0-bb18-46b8-844e-84159064b0bd";
  
  public nsICancelable(int paramInt)
  {
    super(paramInt);
  }
  
  public int Cancel(int paramInt)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 1, getAddress(), paramInt);
  }
  
  static
  {
    IIDStore.RegisterIID(nsICancelable.class, 0, new nsID("d94ac0a0-bb18-46b8-844e-84159064b0bd"));
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_32.jar!/org/eclipse/swt/internal/mozilla/nsICancelable.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */