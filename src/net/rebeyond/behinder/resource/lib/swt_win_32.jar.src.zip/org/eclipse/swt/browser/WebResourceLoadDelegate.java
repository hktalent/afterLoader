package org.eclipse.swt.browser;

import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.internal.C;
import org.eclipse.swt.internal.Compatibility;
import org.eclipse.swt.internal.ole.win32.COM;
import org.eclipse.swt.internal.ole.win32.COMObject;
import org.eclipse.swt.internal.ole.win32.GUID;
import org.eclipse.swt.internal.ole.win32.IUnknown;
import org.eclipse.swt.internal.webkit.IWebDataSource;
import org.eclipse.swt.internal.webkit.IWebFrame;
import org.eclipse.swt.internal.webkit.IWebMutableURLRequest;
import org.eclipse.swt.internal.webkit.IWebURLAuthenticationChallenge;
import org.eclipse.swt.internal.webkit.IWebURLAuthenticationChallengeSender;
import org.eclipse.swt.internal.webkit.IWebURLCredential;
import org.eclipse.swt.internal.webkit.IWebURLProtectionSpace;
import org.eclipse.swt.internal.webkit.IWebURLRequest;
import org.eclipse.swt.internal.webkit.IWebView;
import org.eclipse.swt.internal.webkit.WebKit_win32;
import org.eclipse.swt.internal.win32.OS;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Monitor;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

class WebResourceLoadDelegate
{
  COMObject iWebResourceLoadDelegate;
  int refCount = 0;
  Browser browser;
  String postData;
  
  WebResourceLoadDelegate(Browser paramBrowser)
  {
    createCOMInterfaces();
    this.browser = paramBrowser;
  }
  
  int AddRef()
  {
    this.refCount += 1;
    return this.refCount;
  }
  
  void createCOMInterfaces()
  {
    this.iWebResourceLoadDelegate = new COMObject(new int[] { 2, 0, 0, 4, 6, 4, 4, 4, 4, 3, 4, 3 })
    {
      public int method0(int[] paramAnonymousArrayOfInt)
      {
        return WebResourceLoadDelegate.this.QueryInterface(paramAnonymousArrayOfInt[0], paramAnonymousArrayOfInt[1]);
      }
      
      public int method1(int[] paramAnonymousArrayOfInt)
      {
        return WebResourceLoadDelegate.this.AddRef();
      }
      
      public int method2(int[] paramAnonymousArrayOfInt)
      {
        return WebResourceLoadDelegate.this.Release();
      }
      
      public int method3(int[] paramAnonymousArrayOfInt)
      {
        return WebResourceLoadDelegate.this.identifierForInitialRequest(paramAnonymousArrayOfInt[0], paramAnonymousArrayOfInt[1], paramAnonymousArrayOfInt[2], paramAnonymousArrayOfInt[3]);
      }
      
      public int method4(int[] paramAnonymousArrayOfInt)
      {
        return WebResourceLoadDelegate.this.willSendRequest(paramAnonymousArrayOfInt[0], paramAnonymousArrayOfInt[1], paramAnonymousArrayOfInt[2], paramAnonymousArrayOfInt[3], paramAnonymousArrayOfInt[4], paramAnonymousArrayOfInt[5]);
      }
      
      public int method5(int[] paramAnonymousArrayOfInt)
      {
        return WebResourceLoadDelegate.this.didReceiveAuthenticationChallenge(paramAnonymousArrayOfInt[0], paramAnonymousArrayOfInt[1], paramAnonymousArrayOfInt[2], paramAnonymousArrayOfInt[3]);
      }
      
      public int method6(int[] paramAnonymousArrayOfInt)
      {
        return -2147467263;
      }
      
      public int method7(int[] paramAnonymousArrayOfInt)
      {
        return 0;
      }
      
      public int method8(int[] paramAnonymousArrayOfInt)
      {
        return 0;
      }
      
      public int method9(int[] paramAnonymousArrayOfInt)
      {
        return 0;
      }
      
      public int method10(int[] paramAnonymousArrayOfInt)
      {
        return 0;
      }
      
      public int method11(int[] paramAnonymousArrayOfInt)
      {
        return -2147467263;
      }
    };
  }
  
  int didReceiveAuthenticationChallenge(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    IWebURLAuthenticationChallenge localIWebURLAuthenticationChallenge = new IWebURLAuthenticationChallenge(paramInt3);
    int[] arrayOfInt1 = new int[1];
    int i = localIWebURLAuthenticationChallenge.previousFailureCount(arrayOfInt1);
    int[] arrayOfInt2 = new int[1];
    if ((i == 0) && (arrayOfInt1[0] < 3))
    {
      localObject1 = this.browser.webBrowser.authenticationListeners;
      for (int j = 0; j < localObject1.length; j++)
      {
        localObject2 = new AuthenticationEvent(this.browser);
        ((AuthenticationEvent)localObject2).location = ((WebKit)this.browser.webBrowser).lastNavigateURL;
        localObject1[j].authenticate((AuthenticationEvent)localObject2);
        if (!((AuthenticationEvent)localObject2).doit)
        {
          i = localIWebURLAuthenticationChallenge.sender(arrayOfInt2);
          if ((i != 0) || (arrayOfInt2[0] == 0)) {
            return 0;
          }
          localObject3 = new IWebURLAuthenticationChallengeSender(arrayOfInt2[0]);
          ((IWebURLAuthenticationChallengeSender)localObject3).cancelAuthenticationChallenge(paramInt3);
          ((IWebURLAuthenticationChallengeSender)localObject3).Release();
          return 0;
        }
        if ((((AuthenticationEvent)localObject2).user != null) && (((AuthenticationEvent)localObject2).password != null))
        {
          i = localIWebURLAuthenticationChallenge.sender(arrayOfInt2);
          if ((i == 0) && (arrayOfInt2[0] != 0))
          {
            localObject3 = new IWebURLAuthenticationChallengeSender(arrayOfInt2[0]);
            arrayOfInt2[0] = 0;
            i = WebKit_win32.WebKitCreateInstance(WebKit_win32.CLSID_WebURLCredential, 0, WebKit_win32.IID_IWebURLCredential, arrayOfInt2);
            if ((i == 0) && (arrayOfInt2[0] != 0))
            {
              localObject4 = new IWebURLCredential(arrayOfInt2[0]);
              int k = WebKit.createBSTR(((AuthenticationEvent)localObject2).user);
              int m = WebKit.createBSTR(((AuthenticationEvent)localObject2).password);
              ((IWebURLCredential)localObject4).initWithUser(k, m, 1);
              ((IWebURLAuthenticationChallengeSender)localObject3).useCredential(((IWebURLCredential)localObject4).getAddress(), paramInt3);
              ((IWebURLCredential)localObject4).Release();
            }
            ((IWebURLAuthenticationChallengeSender)localObject3).Release();
            return 0;
          }
        }
      }
    }
    Object localObject1 = new String[1];
    String[] arrayOfString = new String[1];
    arrayOfInt2[0] = 0;
    i = localIWebURLAuthenticationChallenge.proposedCredential(arrayOfInt2);
    if ((i == 0) && (arrayOfInt2[0] != 0))
    {
      localObject2 = new IWebURLCredential(arrayOfInt2[0]);
      arrayOfInt2[0] = 0;
      i = ((IWebURLCredential)localObject2).user(arrayOfInt2);
      if ((i == 0) && (arrayOfInt2[0] != 0))
      {
        localObject1[0] = WebKit.extractBSTR(arrayOfInt2[0]);
        COM.SysFreeString(arrayOfInt2[0]);
        localObject3 = new int[1];
        i = ((IWebURLCredential)localObject2).hasPassword((int[])localObject3);
        if ((i == 0) && (localObject3[0] != 0))
        {
          arrayOfInt2[0] = 0;
          i = ((IWebURLCredential)localObject2).password(arrayOfInt2);
          if ((i == 0) && (arrayOfInt2[0] != 0))
          {
            arrayOfString[0] = WebKit.extractBSTR(arrayOfInt2[0]);
            COM.SysFreeString(arrayOfInt2[0]);
          }
        }
      }
      ((IWebURLCredential)localObject2).Release();
    }
    arrayOfInt2[0] = 0;
    i = localIWebURLAuthenticationChallenge.protectionSpace(arrayOfInt2);
    if ((i != 0) || (arrayOfInt2[0] == 0)) {
      return 0;
    }
    Object localObject2 = new IWebURLProtectionSpace(arrayOfInt2[0]);
    Object localObject3 = null;
    Object localObject4 = null;
    arrayOfInt2[0] = 0;
    i = ((IWebURLProtectionSpace)localObject2).host(arrayOfInt2);
    if ((i == 0) && (arrayOfInt2[0] != 0))
    {
      localObject3 = WebKit.extractBSTR(arrayOfInt2[0]);
      COM.SysFreeString(arrayOfInt2[0]);
      int[] arrayOfInt3 = new int[1];
      i = ((IWebURLProtectionSpace)localObject2).port(arrayOfInt3);
      if (i == 0)
      {
        localObject3 = (String)localObject3 + ":" + arrayOfInt3[0];
        arrayOfInt2[0] = 0;
        i = ((IWebURLProtectionSpace)localObject2).realm(arrayOfInt2);
        if ((i == 0) && (arrayOfInt2[0] != 0))
        {
          localObject4 = WebKit.extractBSTR(arrayOfInt2[0]);
          COM.SysFreeString(arrayOfInt2[0]);
        }
      }
    }
    ((IWebURLProtectionSpace)localObject2).Release();
    boolean bool = showAuthenticationDialog((String[])localObject1, arrayOfString, (String)localObject3, (String)localObject4);
    arrayOfInt2[0] = 0;
    i = localIWebURLAuthenticationChallenge.sender(arrayOfInt2);
    if ((i != 0) || (arrayOfInt2[0] == 0)) {
      return 0;
    }
    IWebURLAuthenticationChallengeSender localIWebURLAuthenticationChallengeSender = new IWebURLAuthenticationChallengeSender(arrayOfInt2[0]);
    if (!bool)
    {
      localIWebURLAuthenticationChallengeSender.cancelAuthenticationChallenge(paramInt3);
      localIWebURLAuthenticationChallengeSender.Release();
      return 0;
    }
    arrayOfInt2[0] = 0;
    i = WebKit_win32.WebKitCreateInstance(WebKit_win32.CLSID_WebURLCredential, 0, WebKit_win32.IID_IWebURLCredential, arrayOfInt2);
    if ((i == 0) && (arrayOfInt2[0] != 0))
    {
      IWebURLCredential localIWebURLCredential = new IWebURLCredential(arrayOfInt2[0]);
      int n = WebKit.createBSTR(localObject1[0]);
      int i1 = WebKit.createBSTR(arrayOfString[0]);
      localIWebURLCredential.initWithUser(n, i1, 1);
      localIWebURLAuthenticationChallengeSender.useCredential(localIWebURLCredential.getAddress(), paramInt3);
      localIWebURLCredential.Release();
    }
    localIWebURLAuthenticationChallengeSender.Release();
    return 0;
  }
  
  void disposeCOMInterfaces()
  {
    if (this.iWebResourceLoadDelegate != null)
    {
      this.iWebResourceLoadDelegate.dispose();
      this.iWebResourceLoadDelegate = null;
    }
  }
  
  int getAddress()
  {
    return this.iWebResourceLoadDelegate.getAddress();
  }
  
  int identifierForInitialRequest(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    if (this.browser.isDisposed()) {
      return 0;
    }
    IWebDataSource localIWebDataSource = new IWebDataSource(paramInt3);
    int[] arrayOfInt1 = new int[1];
    int i = localIWebDataSource.webFrame(arrayOfInt1);
    if ((i != 0) || (arrayOfInt1[0] == 0)) {
      return 0;
    }
    new IWebFrame(arrayOfInt1[0]).Release();
    int[] arrayOfInt2 = new int[1];
    IWebView localIWebView = new IWebView(paramInt1);
    i = localIWebView.mainFrame(arrayOfInt2);
    if ((i != 0) || (arrayOfInt2[0] == 0)) {
      return 0;
    }
    new IWebFrame(arrayOfInt2[0]).Release();
    if (arrayOfInt1[0] == arrayOfInt2[0])
    {
      int j = OS.malloc(8);
      localIWebView.estimatedProgress(j);
      double[] arrayOfDouble = new double[1];
      OS.MoveMemory(arrayOfDouble, j, 8);
      OS.free(j);
      int k = (int)(arrayOfDouble[0] * 100.0D);
      ProgressEvent localProgressEvent = new ProgressEvent(this.browser);
      localProgressEvent.display = this.browser.getDisplay();
      localProgressEvent.widget = this.browser;
      localProgressEvent.current = k;
      localProgressEvent.total = Math.max(k, 100);
      ProgressListener[] arrayOfProgressListener = this.browser.webBrowser.progressListeners;
      for (int m = 0; m < arrayOfProgressListener.length; m++) {
        arrayOfProgressListener[m].changed(localProgressEvent);
      }
    }
    return 0;
  }
  
  int QueryInterface(int paramInt1, int paramInt2)
  {
    if ((paramInt1 == 0) || (paramInt2 == 0)) {
      return -2147024809;
    }
    GUID localGUID = new GUID();
    COM.MoveMemory(localGUID, paramInt1, GUID.sizeof);
    if (COM.IsEqualGUID(localGUID, COM.IIDIUnknown))
    {
      COM.MoveMemory(paramInt2, new int[] { this.iWebResourceLoadDelegate.getAddress() }, OS.PTR_SIZEOF);
      new IUnknown(this.iWebResourceLoadDelegate.getAddress()).AddRef();
      return 0;
    }
    if (COM.IsEqualGUID(localGUID, WebKit_win32.IID_IWebResourceLoadDelegate))
    {
      COM.MoveMemory(paramInt2, new int[] { this.iWebResourceLoadDelegate.getAddress() }, OS.PTR_SIZEOF);
      new IUnknown(this.iWebResourceLoadDelegate.getAddress()).AddRef();
      return 0;
    }
    COM.MoveMemory(paramInt2, new int[] { 0 }, OS.PTR_SIZEOF);
    return -2147467262;
  }
  
  int Release()
  {
    this.refCount -= 1;
    if (this.refCount == 0) {
      disposeCOMInterfaces();
    }
    return this.refCount;
  }
  
  boolean showAuthenticationDialog(final String[] paramArrayOfString1, final String[] paramArrayOfString2, String paramString1, String paramString2)
  {
    Shell localShell1 = this.browser.getShell();
    final Shell localShell2 = new Shell(localShell1);
    localShell2.setLayout(new GridLayout());
    String str = SWT.getMessage("SWT_Authentication_Required");
    localShell2.setText(str);
    Label localLabel1 = new Label(localShell2, 64);
    localLabel1.setText(Compatibility.getMessage("SWT_Enter_Username_and_Password", new String[] { paramString2, paramString1 }));
    GridData localGridData = new GridData();
    Monitor localMonitor = this.browser.getMonitor();
    int i = localMonitor.getBounds().width * 2 / 3;
    int j = localLabel1.computeSize(-1, -1).x;
    localGridData.widthHint = Math.min(j, i);
    localGridData.horizontalAlignment = 4;
    localGridData.grabExcessHorizontalSpace = true;
    localLabel1.setLayoutData(localGridData);
    Label localLabel2 = new Label(localShell2, 0);
    localLabel2.setText(SWT.getMessage("SWT_Username"));
    final Text localText1 = new Text(localShell2, 2048);
    if (paramArrayOfString1[0] != null) {
      localText1.setText(paramArrayOfString1[0]);
    }
    localGridData = new GridData();
    localGridData.horizontalAlignment = 4;
    localGridData.grabExcessHorizontalSpace = true;
    localText1.setLayoutData(localGridData);
    Label localLabel3 = new Label(localShell2, 0);
    localLabel3.setText(SWT.getMessage("SWT_Password"));
    final Text localText2 = new Text(localShell2, 4196352);
    if (paramArrayOfString2[0] != null) {
      localText2.setText(paramArrayOfString2[0]);
    }
    localGridData = new GridData();
    localGridData.horizontalAlignment = 4;
    localGridData.grabExcessHorizontalSpace = true;
    localText2.setLayoutData(localGridData);
    final boolean[] arrayOfBoolean = new boolean[1];
    final Button[] arrayOfButton = new Button[2];
    Listener local2 = new Listener()
    {
      public void handleEvent(Event paramAnonymousEvent)
      {
        paramArrayOfString1[0] = localText1.getText();
        paramArrayOfString2[0] = localText2.getText();
        arrayOfBoolean[0] = (paramAnonymousEvent.widget == arrayOfButton[1] ? 1 : false);
        localShell2.close();
      }
    };
    Composite localComposite = new Composite(localShell2, 0);
    localGridData = new GridData();
    localGridData.horizontalAlignment = 3;
    localComposite.setLayoutData(localGridData);
    localComposite.setLayout(new GridLayout(2, true));
    arrayOfButton[0] = new Button(localComposite, 8);
    arrayOfButton[0].setText(SWT.getMessage("SWT_Cancel"));
    arrayOfButton[0].setLayoutData(new GridData(768));
    arrayOfButton[0].addListener(13, local2);
    arrayOfButton[1] = new Button(localComposite, 8);
    arrayOfButton[1].setText(SWT.getMessage("SWT_OK"));
    arrayOfButton[1].setLayoutData(new GridData(768));
    arrayOfButton[1].addListener(13, local2);
    localShell2.setDefaultButton(arrayOfButton[1]);
    localShell2.pack();
    Rectangle localRectangle1 = localShell1.getBounds();
    Rectangle localRectangle2 = localShell2.getBounds();
    int k = localShell1.getLocation().x + (localRectangle1.width - localRectangle2.width) / 2;
    int m = localShell1.getLocation().y + (localRectangle1.height - localRectangle2.height) / 2;
    localShell2.setLocation(k, m);
    localShell2.open();
    Display localDisplay = this.browser.getDisplay();
    while (!localShell2.isDisposed()) {
      if (!localDisplay.readAndDispatch()) {
        localDisplay.sleep();
      }
    }
    return arrayOfBoolean[0];
  }
  
  int willSendRequest(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6)
  {
    IWebURLRequest localIWebURLRequest = new IWebURLRequest(paramInt3);
    int[] arrayOfInt = new int[1];
    int i = localIWebURLRequest.URL(arrayOfInt);
    if ((i == 0) && (arrayOfInt[0] != 0))
    {
      String str = WebKit.extractBSTR(arrayOfInt[0]);
      COM.SysFreeString(arrayOfInt[0]);
      if ((str.startsWith("file://")) && (!str.startsWith("file:///")))
      {
        int j = "file://".length();
        str = "file:///" + str.substring(j);
        arrayOfInt[0] = 0;
        i = localIWebURLRequest.mutableCopy(arrayOfInt);
        if ((i == 0) && (arrayOfInt[0] != 0))
        {
          IWebMutableURLRequest localIWebMutableURLRequest = new IWebMutableURLRequest(arrayOfInt[0]);
          int k = WebKit.createBSTR(str);
          localIWebMutableURLRequest.setURL(k);
          OS.MoveMemory(paramInt6, new int[] { localIWebMutableURLRequest.getAddress() }, C.PTR_SIZEOF);
          return 0;
        }
      }
    }
    localIWebURLRequest.AddRef();
    OS.MoveMemory(paramInt6, new int[] { paramInt3 }, C.PTR_SIZEOF);
    return 0;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_32.jar!/org/eclipse/swt/browser/WebResourceLoadDelegate.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */