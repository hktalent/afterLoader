package org.eclipse.swt.internal.webkit;

import org.eclipse.swt.internal.ole.win32.COM;
import org.eclipse.swt.internal.ole.win32.IUnknown;

public class IWebPreferences
  extends IUnknown
{
  public IWebPreferences(int paramInt)
  {
    super(paramInt);
  }
  
  public int initWithIdentifier(int paramInt, int[] paramArrayOfInt)
  {
    return COM.VtblCall(4, getAddress(), paramInt, paramArrayOfInt);
  }
  
  public int setJavaEnabled(int paramInt)
  {
    return COM.VtblCall(33, getAddress(), paramInt);
  }
  
  public int setJavaScriptEnabled(int paramInt)
  {
    return COM.VtblCall(35, getAddress(), paramInt);
  }
  
  public int setJavaScriptCanOpenWindowsAutomatically(int paramInt)
  {
    return COM.VtblCall(37, getAddress(), paramInt);
  }
  
  public int setTabsToLinks(int paramInt)
  {
    return COM.VtblCall(52, getAddress(), paramInt);
  }
  
  public int setFontSmoothing(int paramInt)
  {
    return COM.VtblCall(63, getAddress(), paramInt);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_32.jar!/org/eclipse/swt/internal/webkit/IWebPreferences.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */