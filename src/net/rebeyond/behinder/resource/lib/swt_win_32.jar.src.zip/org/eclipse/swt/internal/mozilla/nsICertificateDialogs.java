package org.eclipse.swt.internal.mozilla;

public class nsICertificateDialogs
  extends nsISupports
{
  static final int LAST_METHOD_ID = nsISupports.LAST_METHOD_ID + (IsXULRunner24() ? 5 : 6);
  static final String NS_ICERTIFICATEDIALOGS_IID_STR = "a03ca940-09be-11d5-ac5d-000064657374";
  static final String NS_ICERTIFICATEDIALOGS_24_IID_STR = "da871dab-f69e-4173-ab26-99fcd47b0e85";
  
  public nsICertificateDialogs(int paramInt)
  {
    super(paramInt);
  }
  
  public int ViewCert(int paramInt1, int paramInt2)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 5, getAddress(), paramInt1, paramInt2);
  }
  
  static
  {
    IIDStore.RegisterIID(nsICertificateDialogs.class, 0, new nsID("a03ca940-09be-11d5-ac5d-000064657374"));
    IIDStore.RegisterIID(nsICertificateDialogs.class, 6, new nsID("da871dab-f69e-4173-ab26-99fcd47b0e85"));
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_32.jar!/org/eclipse/swt/internal/mozilla/nsICertificateDialogs.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */