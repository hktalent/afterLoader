package org.eclipse.swt.internal.mozilla;

public class nsIScriptGlobalObject
  extends nsISupports
{
  static final String NS_ISCRIPTGLOBALOBJECT_1_9_IID_STR = "6afecd40-0b9a-4cfd-8c42-0f645cd91829";
  static final String NS_ISCRIPTGLOBALOBJECT_1_9_2_IID_STR = "e9f3f2c1-2d94-4722-bbd4-2bf6fdf42f48";
  static final String NS_ISCRIPTGLOBALOBJECT_10_IID_STR = "08f73284-26e3-4fa6-bf89-8326f92a94b3";
  static final String NS_ISCRIPTGLOBALOBJECT_24_IID_STR = "de24b30a-12c6-4e5f-a85e-90cdfb6c5451";
  
  public nsIScriptGlobalObject(int paramInt)
  {
    super(paramInt);
  }
  
  static
  {
    IIDStore.RegisterIID(nsIScriptGlobalObject.class, 0, new nsID("6afecd40-0b9a-4cfd-8c42-0f645cd91829"));
    IIDStore.RegisterIID(nsIScriptGlobalObject.class, 4, new nsID("e9f3f2c1-2d94-4722-bbd4-2bf6fdf42f48"));
    IIDStore.RegisterIID(nsIScriptGlobalObject.class, 5, new nsID("08f73284-26e3-4fa6-bf89-8326f92a94b3"));
    IIDStore.RegisterIID(nsIScriptGlobalObject.class, 6, new nsID("de24b30a-12c6-4e5f-a85e-90cdfb6c5451"));
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_32.jar!/org/eclipse/swt/internal/mozilla/nsIScriptGlobalObject.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */