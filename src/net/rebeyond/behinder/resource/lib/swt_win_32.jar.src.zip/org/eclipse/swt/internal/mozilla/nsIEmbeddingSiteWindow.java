package org.eclipse.swt.internal.mozilla;

public class nsIEmbeddingSiteWindow
  extends nsISupports
{
  static final int LAST_METHOD_ID = nsISupports.LAST_METHOD_ID + (IsXULRunner24() ? 9 : 8);
  static final String NS_IEMBEDDINGSITEWINDOW_IID_STR = "3e5432cd-9568-4bd1-8cbe-d50aba110743";
  static final String NS_IEMBEDDINGSITEWINDOW_24_IID_STR = "0b976267-4aaa-4f36-a2d4-27b5ca8d73bb";
  public static final int DIM_FLAGS_POSITION = 1;
  public static final int DIM_FLAGS_SIZE_INNER = 2;
  public static final int DIM_FLAGS_SIZE_OUTER = 4;
  
  public nsIEmbeddingSiteWindow(int paramInt)
  {
    super(paramInt);
  }
  
  public int GetSiteWindow(int[] paramArrayOfInt)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 8, getAddress(), paramArrayOfInt);
  }
  
  static
  {
    IIDStore.RegisterIID(nsIEmbeddingSiteWindow.class, 0, new nsID("3e5432cd-9568-4bd1-8cbe-d50aba110743"));
    IIDStore.RegisterIID(nsIEmbeddingSiteWindow.class, 6, new nsID("0b976267-4aaa-4f36-a2d4-27b5ca8d73bb"));
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_32.jar!/org/eclipse/swt/internal/mozilla/nsIEmbeddingSiteWindow.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */