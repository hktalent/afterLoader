package org.eclipse.swt.internal.mozilla;

public class nsIWebProgress
  extends nsISupports
{
  static final int LAST_METHOD_ID = nsISupports.LAST_METHOD_ID + (IsXULRunner24() ? 6 : 4);
  static final String NS_IWEBPROGRESS_IID_STR = "570f39d0-efd0-11d3-b093-00a024ffc08c";
  static final String NS_IWEBPROGRESS_24_IID_STR = "1c3437b0-9e2c-11e2-9e96-0800200c9a66";
  public static final int NOTIFY_STATE_REQUEST = 1;
  public static final int NOTIFY_STATE_DOCUMENT = 2;
  public static final int NOTIFY_STATE_NETWORK = 4;
  public static final int NOTIFY_STATE_WINDOW = 8;
  public static final int NOTIFY_STATE_ALL = 15;
  public static final int NOTIFY_PROGRESS = 16;
  public static final int NOTIFY_STATUS = 32;
  public static final int NOTIFY_SECURITY = 64;
  public static final int NOTIFY_LOCATION = 128;
  public static final int NOTIFY_ALL = 255;
  
  public nsIWebProgress(int paramInt)
  {
    super(paramInt);
  }
  
  public int GetDOMWindow(int[] paramArrayOfInt)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 3, getAddress(), paramArrayOfInt);
  }
  
  static
  {
    IIDStore.RegisterIID(nsIWebProgress.class, 0, new nsID("570f39d0-efd0-11d3-b093-00a024ffc08c"));
    IIDStore.RegisterIID(nsIWebProgress.class, 6, new nsID("1c3437b0-9e2c-11e2-9e96-0800200c9a66"));
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_32.jar!/org/eclipse/swt/internal/mozilla/nsIWebProgress.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */