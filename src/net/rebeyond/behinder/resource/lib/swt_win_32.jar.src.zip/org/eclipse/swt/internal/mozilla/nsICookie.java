package org.eclipse.swt.internal.mozilla;

public class nsICookie
  extends nsISupports
{
  static final int LAST_METHOD_ID = nsISupports.LAST_METHOD_ID + 9;
  static final String NS_ICOOKIE_IID_STR = "e9fcb9a4-d376-458f-b720-e65e7df593bc";
  static final String NS_ICOOKIE_24_IID_STR = "8684966b-1877-4f0f-8155-be4490b96bf7";
  
  public nsICookie(int paramInt)
  {
    super(paramInt);
  }
  
  public int GetName(int paramInt)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 1, getAddress(), paramInt);
  }
  
  public int GetHost(int paramInt)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 4, getAddress(), paramInt);
  }
  
  public int GetPath(int paramInt)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 5, getAddress(), paramInt);
  }
  
  public int GetExpires(long[] paramArrayOfLong)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 7, getAddress(), paramArrayOfLong);
  }
  
  static
  {
    IIDStore.RegisterIID(nsICookie.class, 0, new nsID("e9fcb9a4-d376-458f-b720-e65e7df593bc"));
    IIDStore.RegisterIID(nsICookie.class, 6, new nsID("8684966b-1877-4f0f-8155-be4490b96bf7"));
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_32.jar!/org/eclipse/swt/internal/mozilla/nsICookie.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */