package org.eclipse.swt.browser;

import java.io.File;
import java.util.Enumeration;
import java.util.Vector;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.internal.Callback;
import org.eclipse.swt.internal.mozilla.IIDStore;
import org.eclipse.swt.internal.mozilla.MozillaVersion;
import org.eclipse.swt.internal.mozilla.XPCOM;
import org.eclipse.swt.internal.mozilla.nsIBaseWindow;
import org.eclipse.swt.internal.mozilla.nsIFocusManager;
import org.eclipse.swt.internal.mozilla.nsIServiceManager;
import org.eclipse.swt.internal.mozilla.nsISupports;
import org.eclipse.swt.internal.win32.OS;
import org.eclipse.swt.internal.win32.RECT;
import org.eclipse.swt.internal.win32.TCHAR;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Listener;

class MozillaDelegate
{
  Browser browser;
  Vector childWindows = new Vector(9);
  static int MozillaProc;
  static Callback SubclassProc;
  static Boolean IsXULRunner24;
  static final String LIB_XPCOM = "xpcom.dll";
  static final String LIB_XUL = "xul.dll";
  
  MozillaDelegate(Browser paramBrowser)
  {
    this.browser = paramBrowser;
  }
  
  static Browser findBrowser(int paramInt)
  {
    Display localDisplay = Display.getCurrent();
    return (Browser)localDisplay.findWidget(paramInt);
  }
  
  static String getCacheParentPath()
  {
    TCHAR localTCHAR = new TCHAR(0, 260);
    if (OS.SHGetFolderPath(0, 28, 0, 0, localTCHAR) == 0) {
      return localTCHAR.toString(0, localTCHAR.strlen()) + Mozilla.SEPARATOR_OS + "eclipse";
    }
    return getProfilePath();
  }
  
  static String[] getJSLibraryNames()
  {
    return new String[] { "mozjs.dll", "xul.dll" };
  }
  
  static String getJSLibraryName_Pre10()
  {
    return "js3250.dll";
  }
  
  static String getLibraryName(String paramString)
  {
    if (IsXULRunner24 == null) {
      IsXULRunner24 = new File(paramString, "xpcom.dll").exists() ? Boolean.FALSE : Boolean.TRUE;
    }
    return IsXULRunner24.booleanValue() ? "xul.dll" : "xpcom.dll";
  }
  
  static String getProfilePath()
  {
    TCHAR localTCHAR = new TCHAR(0, 260);
    String str;
    if (OS.SHGetFolderPath(0, 26, 0, 0, localTCHAR) == 0) {
      str = localTCHAR.toString(0, localTCHAR.strlen());
    } else {
      str = System.getProperty("user.home");
    }
    return str + Mozilla.SEPARATOR_OS + "Mozilla" + Mozilla.SEPARATOR_OS + "eclipse";
  }
  
  static String getSWTInitLibraryName()
  {
    return "swt-xulrunner";
  }
  
  static void loadAdditionalLibraries(String paramString, boolean paramBoolean) {}
  
  static char[] mbcsToWcs(String paramString, byte[] paramArrayOfByte)
  {
    char[] arrayOfChar1 = new char[paramArrayOfByte.length];
    int i = OS.MultiByteToWideChar(0, 1, paramArrayOfByte, paramArrayOfByte.length, arrayOfChar1, arrayOfChar1.length);
    if (i == arrayOfChar1.length) {
      return arrayOfChar1;
    }
    char[] arrayOfChar2 = new char[i];
    System.arraycopy(arrayOfChar1, 0, arrayOfChar2, 0, i);
    return arrayOfChar2;
  }
  
  static boolean needsSpinup()
  {
    return false;
  }
  
  static byte[] wcsToMbcs(String paramString1, String paramString2, boolean paramBoolean)
  {
    char[] arrayOfChar = new char[paramString2.length()];
    paramString2.getChars(0, arrayOfChar.length, arrayOfChar, 0);
    Object localObject = new byte[i = arrayOfChar.length * 2 + (paramBoolean ? 1 : 0)];
    int i = OS.WideCharToMultiByte(0, 0, arrayOfChar, arrayOfChar.length, (byte[])localObject, i, null, null);
    if (paramBoolean)
    {
      i++;
    }
    else if (localObject.length != i)
    {
      byte[] arrayOfByte = new byte[i];
      System.arraycopy(localObject, 0, arrayOfByte, 0, i);
      localObject = arrayOfByte;
    }
    return (byte[])localObject;
  }
  
  static int windowProc(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    switch (paramInt2)
    {
    case 296: 
      return 0;
    case 20: 
      RECT localRECT = new RECT();
      OS.GetClientRect(paramInt1, localRECT);
      OS.FillRect(paramInt3, localRECT, OS.GetSysColorBrush(OS.COLOR_WINDOW));
    }
    return OS.CallWindowProc(MozillaProc, paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  void addWindowSubclass()
  {
    int i = OS.GetWindow(this.browser.handle, 5);
    if (SubclassProc == null)
    {
      SubclassProc = new Callback(MozillaDelegate.class, "windowProc", 4);
      MozillaProc = OS.GetWindowLongPtr(i, -4);
    }
    OS.SetWindowLongPtr(i, -4, SubclassProc.getAddress());
  }
  
  int createBaseWindow(nsIBaseWindow paramnsIBaseWindow)
  {
    return paramnsIBaseWindow.Create();
  }
  
  int getHandle()
  {
    return this.browser.handle;
  }
  
  Point getNativeSize(int paramInt1, int paramInt2)
  {
    return new Point(paramInt1, paramInt2);
  }
  
  int getSiteWindow()
  {
    if ((!MozillaVersion.CheckVersion(5)) || (Mozilla.IsGettingSiteWindow)) {
      return getHandle();
    }
    Composite localComposite = new Composite(this.browser, 0);
    this.childWindows.addElement(localComposite);
    return localComposite.handle;
  }
  
  void handleFocus() {}
  
  void handleMouseDown() {}
  
  boolean hookEnterExit()
  {
    return true;
  }
  
  void init()
  {
    if (MozillaVersion.CheckVersion(5))
    {
      this.browser.addListener(31, new Listener()
      {
        public void handleEvent(Event paramAnonymousEvent)
        {
          switch (paramAnonymousEvent.detail)
          {
          case 2: 
          case 4: 
            paramAnonymousEvent.doit = false;
            break;
          case 8: 
          case 16: 
            int[] arrayOfInt = new int[1];
            int i = XPCOM.NS_GetServiceManager(arrayOfInt);
            if (i != 0) {
              Mozilla.error(i);
            }
            if (arrayOfInt[0] == 0) {
              Mozilla.error(-2147467262);
            }
            nsIServiceManager localnsIServiceManager = new nsIServiceManager(arrayOfInt[0]);
            arrayOfInt[0] = 0;
            byte[] arrayOfByte = MozillaDelegate.wcsToMbcs(null, "@mozilla.org/focus-manager;1", true);
            i = localnsIServiceManager.GetServiceByContractID(arrayOfByte, IIDStore.GetIID(nsIFocusManager.class, 5), arrayOfInt);
            localnsIServiceManager.Release();
            if ((i == 0) && (arrayOfInt[0] != 0))
            {
              nsIFocusManager localnsIFocusManager = new nsIFocusManager(arrayOfInt[0]);
              arrayOfInt[0] = 0;
              i = localnsIFocusManager.GetFocusedElement(arrayOfInt);
              localnsIFocusManager.Release();
              paramAnonymousEvent.doit = (arrayOfInt[0] == 0);
              if ((i == 0) && (arrayOfInt[0] != 0)) {
                new nsISupports(arrayOfInt[0]).Release();
              }
            }
            break;
          }
        }
      });
      this.browser.addLocationListener(new LocationAdapter()
      {
        public void changing(LocationEvent paramAnonymousLocationEvent)
        {
          Enumeration localEnumeration = MozillaDelegate.this.childWindows.elements();
          while (localEnumeration.hasMoreElements()) {
            ((Composite)localEnumeration.nextElement()).dispose();
          }
          MozillaDelegate.this.childWindows.clear();
        }
      });
    }
  }
  
  void onDispose(int paramInt)
  {
    if (SubclassProc == null) {
      return;
    }
    int i = OS.GetWindow(this.browser.handle, 5);
    OS.SetWindowLongPtr(i, -4, MozillaProc);
    this.childWindows = null;
    this.browser = null;
  }
  
  void removeWindowSubclass()
  {
    int i = OS.GetWindow(this.browser.handle, 5);
    if (SubclassProc != null) {
      OS.SetWindowLongPtr(i, -4, MozillaProc);
    }
  }
  
  boolean sendTraverse()
  {
    return false;
  }
  
  void setSize(int paramInt1, int paramInt2, int paramInt3) {}
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_32.jar!/org/eclipse/swt/browser/MozillaDelegate.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */