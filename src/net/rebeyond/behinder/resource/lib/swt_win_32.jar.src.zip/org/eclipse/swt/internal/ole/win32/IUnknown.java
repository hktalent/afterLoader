package org.eclipse.swt.internal.ole.win32;

public class IUnknown
{
  int address;
  
  public IUnknown(int paramInt)
  {
    this.address = paramInt;
  }
  
  public int AddRef()
  {
    return COM.VtblCall(1, this.address);
  }
  
  public int getAddress()
  {
    return this.address;
  }
  
  public int QueryInterface(GUID paramGUID, int[] paramArrayOfInt)
  {
    return COM.VtblCall(0, this.address, paramGUID, paramArrayOfInt);
  }
  
  public int Release()
  {
    return COM.VtblCall(2, this.address);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_32.jar!/org/eclipse/swt/internal/ole/win32/IUnknown.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */