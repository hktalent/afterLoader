package org.eclipse.swt.custom;

import org.eclipse.swt.events.TypedEvent;
import org.eclipse.swt.widgets.Widget;

public class CTabFolderEvent
  extends TypedEvent
{
  public Widget item;
  public boolean doit;
  public int x;
  public int y;
  public int width;
  public int height;
  static final long serialVersionUID = 3760566386225066807L;
  
  CTabFolderEvent(Widget paramWidget)
  {
    super(paramWidget);
  }
  
  public String toString()
  {
    String str = super.toString();
    return str.substring(0, str.length() - 1) + " item=" + this.item + " doit=" + this.doit + " x=" + this.x + " y=" + this.y + " width=" + this.width + " height=" + this.height + "}";
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_32.jar!/org/eclipse/swt/custom/CTabFolderEvent.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */