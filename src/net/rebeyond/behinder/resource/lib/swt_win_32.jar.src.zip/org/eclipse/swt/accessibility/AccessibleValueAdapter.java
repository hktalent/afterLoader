package org.eclipse.swt.accessibility;

public class AccessibleValueAdapter
  implements AccessibleValueListener
{
  public void getCurrentValue(AccessibleValueEvent paramAccessibleValueEvent) {}
  
  public void setCurrentValue(AccessibleValueEvent paramAccessibleValueEvent) {}
  
  public void getMaximumValue(AccessibleValueEvent paramAccessibleValueEvent) {}
  
  public void getMinimumValue(AccessibleValueEvent paramAccessibleValueEvent) {}
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_32.jar!/org/eclipse/swt/accessibility/AccessibleValueAdapter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */