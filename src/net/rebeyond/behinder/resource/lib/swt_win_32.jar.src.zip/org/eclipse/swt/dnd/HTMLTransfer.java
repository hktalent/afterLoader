package org.eclipse.swt.dnd;

import org.eclipse.swt.internal.ole.win32.STGMEDIUM;
import org.eclipse.swt.internal.win32.OS;

public class HTMLTransfer
  extends ByteArrayTransfer
{
  static HTMLTransfer _instance = new HTMLTransfer();
  static final String HTML_FORMAT = "HTML Format";
  static final int HTML_FORMATID = registerType("HTML Format");
  static final String NUMBER = "00000000";
  static final String HEADER = "Version:0.9\r\nStartHTML:00000000\r\nEndHTML:00000000\r\nStartFragment:00000000\r\nEndFragment:00000000\r\n";
  static final String PREFIX = "<html><body><!--StartFragment-->";
  static final String SUFFIX = "<!--EndFragment--></body></html>";
  static final String StartFragment = "StartFragment:";
  static final String EndFragment = "EndFragment:";
  
  public static HTMLTransfer getInstance()
  {
    return _instance;
  }
  
  public void javaToNative(Object paramObject, TransferData paramTransferData)
  {
    if ((!checkHTML(paramObject)) || (!isSupportedType(paramTransferData))) {
      DND.error(2003);
    }
    String str1 = (String)paramObject;
    int i = str1.length();
    char[] arrayOfChar = new char[i + 1];
    str1.getChars(0, i, arrayOfChar, 0);
    int j = OS.WideCharToMultiByte(65001, 0, arrayOfChar, -1, null, 0, null, null);
    if (j == 0)
    {
      paramTransferData.stgmedium = new STGMEDIUM();
      paramTransferData.result = -2147221402;
      return;
    }
    int k = "Version:0.9\r\nStartHTML:00000000\r\nEndHTML:00000000\r\nStartFragment:00000000\r\nEndFragment:00000000\r\n".length();
    int m = k + "<html><body><!--StartFragment-->".length();
    int n = m + j - 1;
    int i1 = n + "<!--EndFragment--></body></html>".length();
    StringBuffer localStringBuffer = new StringBuffer("Version:0.9\r\nStartHTML:00000000\r\nEndHTML:00000000\r\nStartFragment:00000000\r\nEndFragment:00000000\r\n");
    int i2 = "00000000".length();
    int i3 = localStringBuffer.toString().indexOf("00000000");
    String str2 = Integer.toString(k);
    localStringBuffer.replace(i3 + i2 - str2.length(), i3 + i2, str2);
    i3 = localStringBuffer.toString().indexOf("00000000", i3);
    str2 = Integer.toString(i1);
    localStringBuffer.replace(i3 + i2 - str2.length(), i3 + i2, str2);
    i3 = localStringBuffer.toString().indexOf("00000000", i3);
    str2 = Integer.toString(m);
    localStringBuffer.replace(i3 + i2 - str2.length(), i3 + i2, str2);
    i3 = localStringBuffer.toString().indexOf("00000000", i3);
    str2 = Integer.toString(n);
    localStringBuffer.replace(i3 + i2 - str2.length(), i3 + i2, str2);
    localStringBuffer.append("<html><body><!--StartFragment-->");
    localStringBuffer.append(str1);
    localStringBuffer.append("<!--EndFragment--></body></html>");
    i = localStringBuffer.length();
    arrayOfChar = new char[i + 1];
    localStringBuffer.getChars(0, i, arrayOfChar, 0);
    j = OS.WideCharToMultiByte(65001, 0, arrayOfChar, -1, null, 0, null, null);
    int i4 = OS.GlobalAlloc(64, j);
    OS.WideCharToMultiByte(65001, 0, arrayOfChar, -1, i4, j, null, null);
    paramTransferData.stgmedium = new STGMEDIUM();
    paramTransferData.stgmedium.tymed = 1;
    paramTransferData.stgmedium.unionField = i4;
    paramTransferData.stgmedium.pUnkForRelease = 0;
    paramTransferData.result = 0;
  }
  
  /* Error */
  public Object nativeToJava(TransferData paramTransferData)
  {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: invokevirtual 4	org/eclipse/swt/dnd/HTMLTransfer:isSupportedType	(Lorg/eclipse/swt/dnd/TransferData;)Z
    //   5: ifeq +10 -> 15
    //   8: aload_1
    //   9: getfield 35	org/eclipse/swt/dnd/TransferData:pIDataObject	I
    //   12: ifne +5 -> 17
    //   15: aconst_null
    //   16: areturn
    //   17: new 36	org/eclipse/swt/internal/ole/win32/IDataObject
    //   20: dup
    //   21: aload_1
    //   22: getfield 35	org/eclipse/swt/dnd/TransferData:pIDataObject	I
    //   25: invokespecial 37	org/eclipse/swt/internal/ole/win32/IDataObject:<init>	(I)V
    //   28: astore_2
    //   29: aload_2
    //   30: invokevirtual 38	org/eclipse/swt/internal/ole/win32/IDataObject:AddRef	()I
    //   33: pop
    //   34: new 11	org/eclipse/swt/internal/ole/win32/STGMEDIUM
    //   37: dup
    //   38: invokespecial 12	org/eclipse/swt/internal/ole/win32/STGMEDIUM:<init>	()V
    //   41: astore_3
    //   42: aload_1
    //   43: getfield 39	org/eclipse/swt/dnd/TransferData:formatetc	Lorg/eclipse/swt/internal/ole/win32/FORMATETC;
    //   46: astore 4
    //   48: aload_3
    //   49: iconst_1
    //   50: putfield 32	org/eclipse/swt/internal/ole/win32/STGMEDIUM:tymed	I
    //   53: aload_1
    //   54: aload_0
    //   55: aload_2
    //   56: aload 4
    //   58: aload_3
    //   59: invokevirtual 40	org/eclipse/swt/dnd/HTMLTransfer:getData	(Lorg/eclipse/swt/internal/ole/win32/IDataObject;Lorg/eclipse/swt/internal/ole/win32/FORMATETC;Lorg/eclipse/swt/internal/ole/win32/STGMEDIUM;)I
    //   62: putfield 15	org/eclipse/swt/dnd/TransferData:result	I
    //   65: aload_2
    //   66: invokevirtual 41	org/eclipse/swt/internal/ole/win32/IDataObject:Release	()I
    //   69: pop
    //   70: aload_1
    //   71: getfield 15	org/eclipse/swt/dnd/TransferData:result	I
    //   74: ifeq +5 -> 79
    //   77: aconst_null
    //   78: areturn
    //   79: aload_3
    //   80: getfield 33	org/eclipse/swt/internal/ole/win32/STGMEDIUM:unionField	I
    //   83: istore 5
    //   85: iload 5
    //   87: invokestatic 42	org/eclipse/swt/internal/win32/OS:GlobalLock	(I)I
    //   90: istore 6
    //   92: iload 6
    //   94: ifne +12 -> 106
    //   97: aconst_null
    //   98: astore 7
    //   100: jsr +362 -> 462
    //   103: aload 7
    //   105: areturn
    //   106: ldc 9
    //   108: iconst_0
    //   109: iload 6
    //   111: iconst_m1
    //   112: aconst_null
    //   113: iconst_0
    //   114: invokestatic 43	org/eclipse/swt/internal/win32/OS:MultiByteToWideChar	(IIII[CI)I
    //   117: istore 7
    //   119: iload 7
    //   121: ifne +15 -> 136
    //   124: aconst_null
    //   125: astore 8
    //   127: jsr +317 -> 444
    //   130: jsr +332 -> 462
    //   133: aload 8
    //   135: areturn
    //   136: iload 7
    //   138: iconst_1
    //   139: isub
    //   140: newarray <illegal type>
    //   142: astore 8
    //   144: ldc 9
    //   146: iconst_0
    //   147: iload 6
    //   149: iconst_m1
    //   150: aload 8
    //   152: aload 8
    //   154: arraylength
    //   155: invokestatic 43	org/eclipse/swt/internal/win32/OS:MultiByteToWideChar	(IIII[CI)I
    //   158: pop
    //   159: new 6	java/lang/String
    //   162: dup
    //   163: aload 8
    //   165: invokespecial 44	java/lang/String:<init>	([C)V
    //   168: astore 9
    //   170: iconst_0
    //   171: istore 10
    //   173: iconst_0
    //   174: istore 11
    //   176: aload 9
    //   178: ldc 45
    //   180: invokevirtual 23	java/lang/String:indexOf	(Ljava/lang/String;)I
    //   183: ldc 45
    //   185: invokevirtual 7	java/lang/String:length	()I
    //   188: iadd
    //   189: istore 12
    //   191: iload 12
    //   193: iconst_1
    //   194: iadd
    //   195: istore 13
    //   197: iload 13
    //   199: aload 9
    //   201: invokevirtual 7	java/lang/String:length	()I
    //   204: if_icmpge +35 -> 239
    //   207: aload 9
    //   209: iload 12
    //   211: iload 13
    //   213: invokevirtual 46	java/lang/String:substring	(II)Ljava/lang/String;
    //   216: astore 14
    //   218: aload 14
    //   220: invokestatic 47	java/lang/Integer:parseInt	(Ljava/lang/String;)I
    //   223: istore 10
    //   225: iinc 13 1
    //   228: goto +8 -> 236
    //   231: astore 15
    //   233: goto +6 -> 239
    //   236: goto -39 -> 197
    //   239: aload 9
    //   241: ldc 49
    //   243: invokevirtual 23	java/lang/String:indexOf	(Ljava/lang/String;)I
    //   246: ldc 49
    //   248: invokevirtual 7	java/lang/String:length	()I
    //   251: iadd
    //   252: istore 12
    //   254: iload 12
    //   256: iconst_1
    //   257: iadd
    //   258: istore 13
    //   260: iload 13
    //   262: aload 9
    //   264: invokevirtual 7	java/lang/String:length	()I
    //   267: if_icmpge +35 -> 302
    //   270: aload 9
    //   272: iload 12
    //   274: iload 13
    //   276: invokevirtual 46	java/lang/String:substring	(II)Ljava/lang/String;
    //   279: astore 14
    //   281: aload 14
    //   283: invokestatic 47	java/lang/Integer:parseInt	(Ljava/lang/String;)I
    //   286: istore 11
    //   288: iinc 13 1
    //   291: goto +8 -> 299
    //   294: astore 15
    //   296: goto +6 -> 302
    //   299: goto -39 -> 260
    //   302: iload 11
    //   304: iload 10
    //   306: if_icmple +13 -> 319
    //   309: iload 11
    //   311: iload 6
    //   313: invokestatic 50	org/eclipse/swt/internal/win32/OS:strlen	(I)I
    //   316: if_icmple +15 -> 331
    //   319: aconst_null
    //   320: astore 14
    //   322: jsr +122 -> 444
    //   325: jsr +137 -> 462
    //   328: aload 14
    //   330: areturn
    //   331: ldc 9
    //   333: iconst_0
    //   334: iload 6
    //   336: iload 10
    //   338: iadd
    //   339: iload 11
    //   341: iload 10
    //   343: isub
    //   344: aload 8
    //   346: aload 8
    //   348: arraylength
    //   349: invokestatic 43	org/eclipse/swt/internal/win32/OS:MultiByteToWideChar	(IIII[CI)I
    //   352: istore 7
    //   354: iload 7
    //   356: ifne +15 -> 371
    //   359: aconst_null
    //   360: astore 14
    //   362: jsr +82 -> 444
    //   365: jsr +97 -> 462
    //   368: aload 14
    //   370: areturn
    //   371: new 6	java/lang/String
    //   374: dup
    //   375: aload 8
    //   377: iconst_0
    //   378: iload 7
    //   380: invokespecial 51	java/lang/String:<init>	([CII)V
    //   383: astore 14
    //   385: ldc 52
    //   387: astore 15
    //   389: aload 14
    //   391: aload 15
    //   393: invokevirtual 23	java/lang/String:indexOf	(Ljava/lang/String;)I
    //   396: istore 16
    //   398: iload 16
    //   400: iconst_m1
    //   401: if_icmpeq +22 -> 423
    //   404: iload 16
    //   406: aload 15
    //   408: invokevirtual 7	java/lang/String:length	()I
    //   411: iadd
    //   412: istore 16
    //   414: aload 14
    //   416: iload 16
    //   418: invokevirtual 53	java/lang/String:substring	(I)Ljava/lang/String;
    //   421: astore 14
    //   423: aload 14
    //   425: astore 17
    //   427: jsr +17 -> 444
    //   430: jsr +32 -> 462
    //   433: aload 17
    //   435: areturn
    //   436: astore 18
    //   438: jsr +6 -> 444
    //   441: aload 18
    //   443: athrow
    //   444: astore 19
    //   446: iload 5
    //   448: invokestatic 54	org/eclipse/swt/internal/win32/OS:GlobalUnlock	(I)Z
    //   451: pop
    //   452: ret 19
    //   454: astore 20
    //   456: jsr +6 -> 462
    //   459: aload 20
    //   461: athrow
    //   462: astore 21
    //   464: iload 5
    //   466: invokestatic 55	org/eclipse/swt/internal/win32/OS:GlobalFree	(I)I
    //   469: pop
    //   470: ret 21
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	472	0	this	HTMLTransfer
    //   0	472	1	paramTransferData	TransferData
    //   28	38	2	localIDataObject	org.eclipse.swt.internal.ole.win32.IDataObject
    //   41	39	3	localSTGMEDIUM	STGMEDIUM
    //   46	11	4	localFORMATETC	org.eclipse.swt.internal.ole.win32.FORMATETC
    //   83	382	5	i	int
    //   90	249	6	j	int
    //   98	6	7	localObject1	Object
    //   117	262	7	k	int
    //   125	251	8	localObject2	Object
    //   168	103	9	str1	String
    //   171	173	10	m	int
    //   174	170	11	n	int
    //   189	84	12	i1	int
    //   195	94	13	i2	int
    //   216	208	14	str2	String
    //   231	1	15	localNumberFormatException1	NumberFormatException
    //   294	1	15	localNumberFormatException2	NumberFormatException
    //   387	20	15	str3	String
    //   396	21	16	i3	int
    //   425	9	17	str4	String
    //   436	6	18	localObject3	Object
    //   444	1	19	localObject4	Object
    //   454	6	20	localObject5	Object
    //   462	1	21	localObject6	Object
    // Exception table:
    //   from	to	target	type
    //   218	228	231	java/lang/NumberFormatException
    //   281	291	294	java/lang/NumberFormatException
    //   106	130	436	finally
    //   136	325	436	finally
    //   331	365	436	finally
    //   371	430	436	finally
    //   436	441	436	finally
    //   85	103	454	finally
    //   106	133	454	finally
    //   136	328	454	finally
    //   331	368	454	finally
    //   371	433	454	finally
    //   436	459	454	finally
  }
  
  protected int[] getTypeIds()
  {
    return new int[] { HTML_FORMATID };
  }
  
  protected String[] getTypeNames()
  {
    return new String[] { "HTML Format" };
  }
  
  boolean checkHTML(Object paramObject)
  {
    return (paramObject != null) && ((paramObject instanceof String)) && (((String)paramObject).length() > 0);
  }
  
  protected boolean validate(Object paramObject)
  {
    return checkHTML(paramObject);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_32.jar!/org/eclipse/swt/dnd/HTMLTransfer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */