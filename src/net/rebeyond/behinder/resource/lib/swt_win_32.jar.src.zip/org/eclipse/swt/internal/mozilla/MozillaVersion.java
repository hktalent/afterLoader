package org.eclipse.swt.internal.mozilla;

public class MozillaVersion
{
  public static final int VERSION_BASE = 0;
  public static final int VERSION_XR1_8 = 1;
  public static final int VERSION_XR1_9 = 2;
  public static final int VERSION_XR1_9_1 = 3;
  public static final int VERSION_XR1_9_2 = 4;
  public static final int VERSION_XR10 = 5;
  public static final int VERSION_XR24 = 6;
  static final int VERSION_LATEST = 6;
  static int CurrentVersion = -1;
  
  public static boolean CheckVersion(int paramInt)
  {
    return CheckVersion(paramInt, false);
  }
  
  public static boolean CheckVersion(int paramInt, boolean paramBoolean)
  {
    return paramInt == CurrentVersion;
  }
  
  public static int GetCurrentVersion()
  {
    return CurrentVersion;
  }
  
  public static int GetLatestVersion()
  {
    return 6;
  }
  
  public static void SetCurrentVersion(int paramInt)
  {
    CurrentVersion = paramInt;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_32.jar!/org/eclipse/swt/internal/mozilla/MozillaVersion.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */