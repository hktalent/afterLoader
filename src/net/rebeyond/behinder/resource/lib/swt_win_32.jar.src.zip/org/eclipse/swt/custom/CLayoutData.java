package org.eclipse.swt.custom;

import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.widgets.Control;

class CLayoutData
{
  int defaultWidth = -1;
  int defaultHeight = -1;
  int currentWhint;
  int currentHhint;
  int currentWidth = -1;
  int currentHeight = -1;
  
  Point computeSize(Control paramControl, int paramInt1, int paramInt2, boolean paramBoolean)
  {
    if (paramBoolean) {
      flushCache();
    }
    Point localPoint;
    if ((paramInt1 == -1) && (paramInt2 == -1))
    {
      if ((this.defaultWidth == -1) || (this.defaultHeight == -1))
      {
        localPoint = paramControl.computeSize(paramInt1, paramInt2, paramBoolean);
        this.defaultWidth = localPoint.x;
        this.defaultHeight = localPoint.y;
      }
      return new Point(this.defaultWidth, this.defaultHeight);
    }
    if ((this.currentWidth == -1) || (this.currentHeight == -1) || (paramInt1 != this.currentWhint) || (paramInt2 != this.currentHhint))
    {
      localPoint = paramControl.computeSize(paramInt1, paramInt2, paramBoolean);
      this.currentWhint = paramInt1;
      this.currentHhint = paramInt2;
      this.currentWidth = localPoint.x;
      this.currentHeight = localPoint.y;
    }
    return new Point(this.currentWidth, this.currentHeight);
  }
  
  void flushCache()
  {
    this.defaultWidth = (this.defaultHeight = -1);
    this.currentWidth = (this.currentHeight = -1);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_32.jar!/org/eclipse/swt/custom/CLayoutData.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */