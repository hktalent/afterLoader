package org.eclipse.swt.internal.ole.win32;

public class VARDESC
{
  public int memid;
  public int lpstrSchema;
  public int oInst;
  public int elemdescVar_tdesc_union;
  public short elemdescVar_tdesc_vt;
  public int elemdescVar_paramdesc_pparamdescex;
  public short elemdescVar_paramdesc_wParamFlags;
  public short wVarFlags;
  public int varkind;
  public static final int sizeof = ;
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_32.jar!/org/eclipse/swt/internal/ole/win32/VARDESC.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */