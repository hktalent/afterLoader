package org.eclipse.swt.accessibility;

public class AccessibleEditableTextAdapter
  implements AccessibleEditableTextListener
{
  public void copyText(AccessibleEditableTextEvent paramAccessibleEditableTextEvent) {}
  
  public void cutText(AccessibleEditableTextEvent paramAccessibleEditableTextEvent) {}
  
  public void pasteText(AccessibleEditableTextEvent paramAccessibleEditableTextEvent) {}
  
  public void replaceText(AccessibleEditableTextEvent paramAccessibleEditableTextEvent) {}
  
  public void setTextAttributes(AccessibleTextAttributeEvent paramAccessibleTextAttributeEvent) {}
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_32.jar!/org/eclipse/swt/accessibility/AccessibleEditableTextAdapter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */