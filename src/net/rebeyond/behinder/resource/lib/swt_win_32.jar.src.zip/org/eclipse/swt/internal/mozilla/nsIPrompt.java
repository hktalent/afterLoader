package org.eclipse.swt.internal.mozilla;

public class nsIPrompt
  extends nsISupports
{
  static final int LAST_METHOD_ID = nsISupports.LAST_METHOD_ID + 9;
  static final String NS_IPROMPT_IID_STR = "a63f70c0-148b-11d3-9333-00104ba0fd40";
  public static final int BUTTON_POS_0 = 1;
  public static final int BUTTON_POS_1 = 256;
  public static final int BUTTON_POS_2 = 65536;
  public static final int BUTTON_TITLE_OK = 1;
  public static final int BUTTON_TITLE_CANCEL = 2;
  public static final int BUTTON_TITLE_YES = 3;
  public static final int BUTTON_TITLE_NO = 4;
  public static final int BUTTON_TITLE_SAVE = 5;
  public static final int BUTTON_TITLE_DONT_SAVE = 6;
  public static final int BUTTON_TITLE_REVERT = 7;
  public static final int BUTTON_TITLE_IS_STRING = 127;
  public static final int BUTTON_POS_0_DEFAULT = 0;
  public static final int BUTTON_POS_1_DEFAULT = 16777216;
  public static final int BUTTON_POS_2_DEFAULT = 33554432;
  public static final int BUTTON_DELAY_ENABLE = 67108864;
  public static final int STD_OK_CANCEL_BUTTONS = 513;
  public static final int STD_YES_NO_BUTTONS = 1027;
  
  public nsIPrompt(int paramInt)
  {
    super(paramInt);
  }
  
  static
  {
    IIDStore.RegisterIID(nsIPrompt.class, 0, new nsID("a63f70c0-148b-11d3-9333-00104ba0fd40"));
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_32.jar!/org/eclipse/swt/internal/mozilla/nsIPrompt.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */