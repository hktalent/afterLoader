package org.eclipse.swt.internal.mozilla;

public class nsIXPConnect
  extends nsISupports
{
  static final int LAST_METHOD_ID = nsISupports.LAST_METHOD_ID + (IsXULRunner24() ? 48 : 27);
  static final String NS_IXPCONNECT_IID_STR = "a995b541-d514-43f1-ac0e-f49746c0b063";
  static final String NS_IXPCONNECT_24_IID_STR = "3bc074e6-2102-40a4-8c84-38b002c9e2f1";
  
  public nsIXPConnect(int paramInt)
  {
    super(paramInt);
  }
  
  public int JSValToVariant(int paramInt1, int paramInt2, int[] paramArrayOfInt)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 6, getAddress(), paramInt1, paramInt2, paramArrayOfInt);
  }
  
  public int VariantToJS(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + (IsXULRunner24() ? 26 : 33), getAddress(), paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  static
  {
    IIDStore.RegisterIID(nsIXPConnect.class, 0, new nsID("a995b541-d514-43f1-ac0e-f49746c0b063"));
    IIDStore.RegisterIID(nsIXPConnect.class, 6, new nsID("3bc074e6-2102-40a4-8c84-38b002c9e2f1"));
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_32.jar!/org/eclipse/swt/internal/mozilla/nsIXPConnect.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */