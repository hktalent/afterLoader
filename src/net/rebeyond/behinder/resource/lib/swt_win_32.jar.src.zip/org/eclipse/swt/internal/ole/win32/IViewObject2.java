package org.eclipse.swt.internal.ole.win32;

import org.eclipse.swt.internal.win32.SIZE;

public class IViewObject2
  extends IUnknown
{
  public IViewObject2(int paramInt)
  {
    super(paramInt);
  }
  
  public int GetExtent(int paramInt1, int paramInt2, DVTARGETDEVICE paramDVTARGETDEVICE, SIZE paramSIZE)
  {
    return COM.VtblCall(9, this.address, paramInt1, paramInt2, paramDVTARGETDEVICE, paramSIZE);
  }
  
  public int SetAdvise(int paramInt1, int paramInt2, int paramInt3)
  {
    return COM.VtblCall(7, this.address, paramInt1, paramInt2, paramInt3);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_32.jar!/org/eclipse/swt/internal/ole/win32/IViewObject2.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */