package org.eclipse.swt.internal.webkit;

import org.eclipse.swt.internal.ole.win32.COM;

public class IWebMutableURLRequest
  extends IWebURLRequest
{
  public IWebMutableURLRequest(int paramInt)
  {
    super(paramInt);
  }
  
  public int setHTTPMethod(int paramInt)
  {
    return COM.VtblCall(23, getAddress(), paramInt);
  }
  
  public int setURL(int paramInt)
  {
    return COM.VtblCall(27, getAddress(), paramInt);
  }
  
  public int setValue(int paramInt1, int paramInt2)
  {
    return COM.VtblCall(28, getAddress(), paramInt1, paramInt2);
  }
  
  public int setAllowsAnyHTTPSCertificate()
  {
    return COM.VtblCall(29, getAddress());
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_32.jar!/org/eclipse/swt/internal/webkit/IWebMutableURLRequest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */