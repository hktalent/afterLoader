package org.eclipse.swt.internal.ole.win32;

public class IFont
  extends IUnknown
{
  public IFont(int paramInt)
  {
    super(paramInt);
  }
  
  public int get_hFont(int[] paramArrayOfInt)
  {
    return COM.VtblCall(3, this.address, paramArrayOfInt);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_32.jar!/org/eclipse/swt/internal/ole/win32/IFont.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */