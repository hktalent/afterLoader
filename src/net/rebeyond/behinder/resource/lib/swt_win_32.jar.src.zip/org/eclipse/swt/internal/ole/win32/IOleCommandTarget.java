package org.eclipse.swt.internal.ole.win32;

public class IOleCommandTarget
  extends IUnknown
{
  public IOleCommandTarget(int paramInt)
  {
    super(paramInt);
  }
  
  public int Exec(GUID paramGUID, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    return COM.VtblCall(4, this.address, paramGUID, paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  public int QueryStatus(GUID paramGUID, int paramInt, OLECMD paramOLECMD, OLECMDTEXT paramOLECMDTEXT)
  {
    if (paramInt > 1) {
      return -2147024809;
    }
    return COM.VtblCall(3, this.address, paramGUID, paramInt, paramOLECMD, paramOLECMDTEXT);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_32.jar!/org/eclipse/swt/internal/ole/win32/IOleCommandTarget.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */