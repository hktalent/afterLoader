package org.eclipse.swt.dnd;

import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Control;

public class DragSourceEffect
  extends DragSourceAdapter
{
  Control control = null;
  
  public DragSourceEffect(Control paramControl)
  {
    if (paramControl == null) {
      SWT.error(4);
    }
    this.control = paramControl;
  }
  
  public Control getControl()
  {
    return this.control;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_32.jar!/org/eclipse/swt/dnd/DragSourceEffect.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */