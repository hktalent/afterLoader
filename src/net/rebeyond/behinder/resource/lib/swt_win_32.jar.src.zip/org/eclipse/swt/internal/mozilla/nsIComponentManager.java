package org.eclipse.swt.internal.mozilla;

public class nsIComponentManager
  extends nsISupports
{
  static final int LAST_METHOD_ID = nsISupports.LAST_METHOD_ID + (IsXULRunner24() ? 6 : 4);
  static final String NS_ICOMPONENTMANAGER_IID_STR = "a88e5a60-205a-4bb1-94e1-2628daf51eae";
  static final String NS_ICOMPONENTMANAGER_24_IID_STR = "1d940426-5fe5-42c3-84ae-a300f2d9ebd5";
  
  public nsIComponentManager(int paramInt)
  {
    super(paramInt);
  }
  
  public int CreateInstance(nsID paramnsID1, int paramInt, nsID paramnsID2, int[] paramArrayOfInt)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 3, getAddress(), paramnsID1, paramInt, paramnsID2, paramArrayOfInt);
  }
  
  public int CreateInstanceByContractID(byte[] paramArrayOfByte, int paramInt, nsID paramnsID, int[] paramArrayOfInt)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 4, getAddress(), paramArrayOfByte, paramInt, paramnsID, paramArrayOfInt);
  }
  
  static
  {
    IIDStore.RegisterIID(nsIComponentManager.class, 0, new nsID("a88e5a60-205a-4bb1-94e1-2628daf51eae"));
    IIDStore.RegisterIID(nsIComponentManager.class, 6, new nsID("1d940426-5fe5-42c3-84ae-a300f2d9ebd5"));
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_32.jar!/org/eclipse/swt/internal/mozilla/nsIComponentManager.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */