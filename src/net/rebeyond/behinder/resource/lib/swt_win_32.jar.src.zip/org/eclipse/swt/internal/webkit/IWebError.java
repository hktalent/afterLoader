package org.eclipse.swt.internal.webkit;

import org.eclipse.swt.internal.ole.win32.COM;
import org.eclipse.swt.internal.ole.win32.IUnknown;

public class IWebError
  extends IUnknown
{
  public IWebError(int paramInt)
  {
    super(paramInt);
  }
  
  public int code(int[] paramArrayOfInt)
  {
    return COM.VtblCall(4, getAddress(), paramArrayOfInt);
  }
  
  public int localizedDescription(int[] paramArrayOfInt)
  {
    return COM.VtblCall(6, getAddress(), paramArrayOfInt);
  }
  
  public int failingURL(int[] paramArrayOfInt)
  {
    return COM.VtblCall(12, getAddress(), paramArrayOfInt);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_32.jar!/org/eclipse/swt/internal/webkit/IWebError.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */