package org.eclipse.swt.internal.ole.win32;

public class IDragSourceHelper2
  extends IDragSourceHelper
{
  public IDragSourceHelper2(int paramInt)
  {
    super(paramInt);
  }
  
  public int SetFlags(int paramInt)
  {
    return COM.VtblCall(5, this.address, paramInt);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_32.jar!/org/eclipse/swt/internal/ole/win32/IDragSourceHelper2.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */