package org.eclipse.swt.internal.mozilla;

public class nsIDocShell
  extends nsISupports
{
  static final int LAST_METHOD_ID = nsISupports.LAST_METHOD_ID + 51;
  static final String NS_IDOCSHELL_IID_STR = "69e5de00-7b8b-11d3-af61-00a024ffc08c";
  static final String NS_IDOCSHELL_1_8_IID_STR = "9f0c7461-b9a4-47f6-b88c-421dce1bce66";
  static final String NS_IDOCSHELL_1_9_IID_STR = "7d1cf6b9-daa3-476d-8f9f-9eb2a971a95c";
  static final String NS_IDOCSHELL_1_9_1_IID_STR = "dc4daea1-b43d-406f-bd62-c2ee879192ad";
  static final String NS_IDOCSHELL_1_9_2_IID_STR = "8adfb831-1053-4a19-884d-bcdad7277b4b";
  static final String NS_IDOCSHELL_10_IID_STR = "0666adf8-8738-4ca7-a917-0348f47d2f40";
  static final String NS_IDOCSHELL_24_IID_STR = "f453d2ee-bac7-46f9-a553-df918f0cc0d0";
  
  public nsIDocShell(int paramInt)
  {
    super(paramInt);
  }
  
  public int LoadStream(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 2, getAddress(), paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
  }
  
  static
  {
    IIDStore.RegisterIID(nsIDocShell.class, 0, new nsID("69e5de00-7b8b-11d3-af61-00a024ffc08c"));
    IIDStore.RegisterIID(nsIDocShell.class, 1, new nsID("9f0c7461-b9a4-47f6-b88c-421dce1bce66"));
    IIDStore.RegisterIID(nsIDocShell.class, 2, new nsID("7d1cf6b9-daa3-476d-8f9f-9eb2a971a95c"));
    IIDStore.RegisterIID(nsIDocShell.class, 3, new nsID("dc4daea1-b43d-406f-bd62-c2ee879192ad"));
    IIDStore.RegisterIID(nsIDocShell.class, 4, new nsID("8adfb831-1053-4a19-884d-bcdad7277b4b"));
    IIDStore.RegisterIID(nsIDocShell.class, 5, new nsID("0666adf8-8738-4ca7-a917-0348f47d2f40"));
    IIDStore.RegisterIID(nsIDocShell.class, 6, new nsID("f453d2ee-bac7-46f9-a553-df918f0cc0d0"));
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_32.jar!/org/eclipse/swt/internal/mozilla/nsIDocShell.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */