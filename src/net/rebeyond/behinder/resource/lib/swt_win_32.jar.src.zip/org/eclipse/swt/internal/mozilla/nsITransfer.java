package org.eclipse.swt.internal.mozilla;

public class nsITransfer
  extends nsIWebProgressListener2
{
  static final int LAST_METHOD_ID = nsIWebProgressListener2.LAST_METHOD_ID + (IsXULRunner24() ? 2 : 1);
  static final String NS_ITRANSFER_IID_STR = "23c51569-e9a1-4a92-adeb-3723db82ef7c";
  static final String NS_ITRANSFER_24_IID_STR = "b1c81100-9d66-11e2-9e96-0800200c9a66";
  
  public nsITransfer(int paramInt)
  {
    super(paramInt);
  }
  
  static
  {
    IIDStore.RegisterIID(nsITransfer.class, 0, new nsID("23c51569-e9a1-4a92-adeb-3723db82ef7c"));
    IIDStore.RegisterIID(nsITransfer.class, 6, new nsID("b1c81100-9d66-11e2-9e96-0800200c9a66"));
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_32.jar!/org/eclipse/swt/internal/mozilla/nsITransfer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */