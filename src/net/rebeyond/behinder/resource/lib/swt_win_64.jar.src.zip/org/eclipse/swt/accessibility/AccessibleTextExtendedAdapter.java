package org.eclipse.swt.accessibility;

public class AccessibleTextExtendedAdapter
  extends AccessibleTextAdapter
  implements AccessibleTextExtendedListener
{
  public void addSelection(AccessibleTextEvent paramAccessibleTextEvent) {}
  
  public void getCharacterCount(AccessibleTextEvent paramAccessibleTextEvent) {}
  
  public void getHyperlinkCount(AccessibleTextEvent paramAccessibleTextEvent) {}
  
  public void getHyperlink(AccessibleTextEvent paramAccessibleTextEvent) {}
  
  public void getHyperlinkIndex(AccessibleTextEvent paramAccessibleTextEvent) {}
  
  public void getOffsetAtPoint(AccessibleTextEvent paramAccessibleTextEvent) {}
  
  public void getRanges(AccessibleTextEvent paramAccessibleTextEvent) {}
  
  public void getSelection(AccessibleTextEvent paramAccessibleTextEvent) {}
  
  public void getSelectionCount(AccessibleTextEvent paramAccessibleTextEvent) {}
  
  public void getText(AccessibleTextEvent paramAccessibleTextEvent) {}
  
  public void getTextBounds(AccessibleTextEvent paramAccessibleTextEvent) {}
  
  public void getVisibleRanges(AccessibleTextEvent paramAccessibleTextEvent) {}
  
  public void removeSelection(AccessibleTextEvent paramAccessibleTextEvent) {}
  
  public void scrollText(AccessibleTextEvent paramAccessibleTextEvent) {}
  
  public void setCaretOffset(AccessibleTextEvent paramAccessibleTextEvent) {}
  
  public void setSelection(AccessibleTextEvent paramAccessibleTextEvent) {}
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/accessibility/AccessibleTextExtendedAdapter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */