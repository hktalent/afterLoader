package org.eclipse.swt.events;

import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Touch;

public class TouchEvent
  extends TypedEvent
{
  public Touch[] touches;
  public int stateMask;
  public int x;
  public int y;
  static final long serialVersionUID = -8348741538373572182L;
  
  public TouchEvent(Event paramEvent)
  {
    super(paramEvent);
    this.touches = paramEvent.touches;
    this.stateMask = paramEvent.stateMask;
    this.x = paramEvent.x;
    this.y = paramEvent.y;
  }
  
  public String toString()
  {
    String str = super.toString();
    str = str.substring(0, str.length() - 1);
    str = str + " stateMask=0x" + Integer.toHexString(this.stateMask) + " x=" + this.x + " y=" + this.y;
    if (this.touches != null)
    {
      for (int i = 0; i < this.touches.length; i++) {
        str = str + "\n     " + this.touches[i].toString();
      }
      str = str + "\n";
    }
    str = str + "}";
    return str;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/events/TouchEvent.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */