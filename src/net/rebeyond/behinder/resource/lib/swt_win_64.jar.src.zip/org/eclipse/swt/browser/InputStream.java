package org.eclipse.swt.browser;

import org.eclipse.swt.internal.C;
import org.eclipse.swt.internal.mozilla.IIDStore;
import org.eclipse.swt.internal.mozilla.XPCOM;
import org.eclipse.swt.internal.mozilla.XPCOMObject;
import org.eclipse.swt.internal.mozilla.nsID;
import org.eclipse.swt.internal.mozilla.nsIInputStream;
import org.eclipse.swt.internal.mozilla.nsISupports;

class InputStream
{
  XPCOMObject inputStream;
  int refCount = 0;
  byte[] buffer;
  int index = 0;
  
  InputStream(byte[] paramArrayOfByte)
  {
    this.buffer = paramArrayOfByte;
    this.index = 0;
    createCOMInterfaces();
  }
  
  int AddRef()
  {
    this.refCount += 1;
    return this.refCount;
  }
  
  void createCOMInterfaces()
  {
    this.inputStream = new XPCOMObject(new int[] { 2, 0, 0, 0, 1, 3, 4, 1 })
    {
      public long method0(long[] paramAnonymousArrayOfLong)
      {
        return InputStream.this.QueryInterface(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method1(long[] paramAnonymousArrayOfLong)
      {
        return InputStream.this.AddRef();
      }
      
      public long method2(long[] paramAnonymousArrayOfLong)
      {
        return InputStream.this.Release();
      }
      
      public long method3(long[] paramAnonymousArrayOfLong)
      {
        return InputStream.this.Close();
      }
      
      public long method4(long[] paramAnonymousArrayOfLong)
      {
        return InputStream.this.Available(paramAnonymousArrayOfLong[0]);
      }
      
      public long method5(long[] paramAnonymousArrayOfLong)
      {
        return InputStream.this.Read(paramAnonymousArrayOfLong[0], (int)paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2]);
      }
      
      public long method6(long[] paramAnonymousArrayOfLong)
      {
        return InputStream.this.ReadSegments(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], (int)paramAnonymousArrayOfLong[2], paramAnonymousArrayOfLong[3]);
      }
      
      public long method7(long[] paramAnonymousArrayOfLong)
      {
        return InputStream.this.IsNonBlocking(paramAnonymousArrayOfLong[0]);
      }
    };
  }
  
  void disposeCOMInterfaces()
  {
    if (this.inputStream != null)
    {
      this.inputStream.dispose();
      this.inputStream = null;
    }
  }
  
  long getAddress()
  {
    return this.inputStream.getAddress();
  }
  
  int QueryInterface(long paramLong1, long paramLong2)
  {
    if ((paramLong1 == 0L) || (paramLong2 == 0L)) {
      return -2147467262;
    }
    nsID localnsID = new nsID();
    XPCOM.memmove(localnsID, paramLong1, 16);
    if (localnsID.Equals(IIDStore.GetIID(nsISupports.class)))
    {
      XPCOM.memmove(paramLong2, new long[] { this.inputStream.getAddress() }, C.PTR_SIZEOF);
      AddRef();
      return 0;
    }
    if (localnsID.Equals(IIDStore.GetIID(nsIInputStream.class)))
    {
      XPCOM.memmove(paramLong2, new long[] { this.inputStream.getAddress() }, C.PTR_SIZEOF);
      AddRef();
      return 0;
    }
    XPCOM.memmove(paramLong2, new long[] { 0L }, C.PTR_SIZEOF);
    return -2147467262;
  }
  
  int Release()
  {
    this.refCount -= 1;
    if (this.refCount == 0) {
      disposeCOMInterfaces();
    }
    return this.refCount;
  }
  
  int Close()
  {
    this.buffer = null;
    this.index = 0;
    return 0;
  }
  
  int Available(long paramLong)
  {
    int i = this.buffer == null ? 0 : this.buffer.length - this.index;
    XPCOM.memmove(paramLong, new int[] { i }, 4L);
    return 0;
  }
  
  int Read(long paramLong1, int paramInt, long paramLong2)
  {
    int i = Math.min(paramInt, this.buffer == null ? 0 : this.buffer.length - this.index);
    if (i > 0)
    {
      byte[] arrayOfByte = new byte[i];
      System.arraycopy(this.buffer, this.index, arrayOfByte, 0, i);
      XPCOM.memmove(paramLong1, arrayOfByte, i);
      this.index += i;
    }
    XPCOM.memmove(paramLong2, new int[] { i }, 4L);
    return 0;
  }
  
  int ReadSegments(long paramLong1, long paramLong2, int paramInt, long paramLong3)
  {
    int i = this.buffer == null ? 0 : this.buffer.length - this.index;
    if (paramInt != -1) {
      i = Math.min(i, paramInt);
    }
    int j = i;
    while (j > 0)
    {
      int[] arrayOfInt = new int[1];
      long l = XPCOM.Call(paramLong1, getAddress(), paramLong2, this.buffer, this.index, j, arrayOfInt);
      if (l != 0L) {
        break;
      }
      this.index += arrayOfInt[0];
      j -= arrayOfInt[0];
    }
    XPCOM.memmove(paramLong3, new int[] { i - j }, 4L);
    return 0;
  }
  
  int IsNonBlocking(long paramLong)
  {
    XPCOM.memmove(paramLong, new boolean[] { false });
    return 0;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/browser/InputStream.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */