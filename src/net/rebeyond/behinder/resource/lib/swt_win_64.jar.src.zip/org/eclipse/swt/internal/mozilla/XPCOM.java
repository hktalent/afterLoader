package org.eclipse.swt.internal.mozilla;

import org.eclipse.swt.internal.C;
import org.eclipse.swt.internal.Lock;

public class XPCOM
  extends C
{
  public static final String CONTENT_MAYBETEXT = "application/x-vnd.mozilla.maybe-text";
  public static final String CONTENT_MULTIPART = "multipart/x-mixed-replace";
  public static final String DOMEVENT_FOCUS = "focus";
  public static final String DOMEVENT_UNLOAD = "unload";
  public static final String DOMEVENT_MOUSEDOWN = "mousedown";
  public static final String DOMEVENT_MOUSEUP = "mouseup";
  public static final String DOMEVENT_MOUSEMOVE = "mousemove";
  public static final String DOMEVENT_MOUSEDRAG = "draggesture";
  public static final String DOMEVENT_MOUSEWHEEL = "DOMMouseScroll";
  public static final String DOMEVENT_MOUSEOVER = "mouseover";
  public static final String DOMEVENT_MOUSEOUT = "mouseout";
  public static final String DOMEVENT_KEYDOWN = "keydown";
  public static final String DOMEVENT_KEYPRESS = "keypress";
  public static final String DOMEVENT_KEYUP = "keyup";
  public static final nsID EXTERNAL_CID = new nsID("f2c59ad0-bd76-11dd-ad8b-0800200c9a66");
  public static final nsID NS_APPSHELL_CID = new nsID("2d96b3df-c051-11d1-a827-0040959a28c9");
  public static final nsID NS_AUTHPROMPTER_CID = new nsID("e2112d6a-0e28-421f-b46a-25c0b308cbd0");
  public static final nsID NS_CATEGORYMANAGER_CID = new nsID("16d222a6-1dd2-11b2-b693-f38b02c021b2");
  public static final nsID NS_DOWNLOAD_CID = new nsID("e3fa9D0a-1dd1-11b2-bdef-8c720b597445");
  public static final nsID NS_FILEPICKER_CID = new nsID("54ae32f8-1dd2-11b2-a209-df7c505370f8");
  public static final nsID NS_HELPERAPPLAUNCHERDIALOG_CID = new nsID("e68578eb-6ec2-4169-ae19-8c6243f0abe1");
  public static final nsID NS_INPUTSTREAMCHANNEL_CID = new nsID("6ddb050c-0d04-11d4-986e-00c04fa0cf4a");
  public static final nsID NS_IOSERVICE_CID = new nsID("9ac9e770-18bc-11d3-9337-00104ba0fd40");
  public static final nsID NS_LOADGROUP_CID = new nsID("e1c61582-2a84-11d3-8cce-0060b0fc14a3");
  public static final nsID NS_PROMPTER_CID = new nsID("f2112d6a-0e28-421f-b46a-25c0b308cbd0");
  public static final nsID NS_PROMPTSERVICE_CID = new nsID("a2112d6a-0e28-421f-b46a-25c0b308cbd0");
  public static final nsID NS_IWEBBROWSER_CID = new nsID("F1EAC761-87E9-11d3-AF80-00A024FFC08C");
  public static final nsID NS_IXPCONNECT_CID = new nsID("CB6593E0-F9B2-11d2-BDD6-000064657374");
  public static final nsID NS_IAUTHPROMPT2_IID = new nsID("651395eb-8612-4876-8ac0-a88d4dce9e1e");
  public static final nsID NS_IBADCERTLISTENER2_IID = new nsID("2c3d268c-ad82-49f3-99aa-e9ffddd7a0dc");
  public static final nsID NS_ICONTEXTMENULISTENER_IID = new nsID("3478b6b0-3875-11d4-94ef-0020183bf181");
  public static final nsID NS_IDIRECTORYSERVICE_IID = new nsID("57a66a60-d43a-11d3-8cc2-00609792278c");
  public static final nsID NS_IDIRECTORYSERVICEPROVIDER_IID = new nsID("bbf8cab0-d43a-11d3-8cc2-00609792278c");
  public static final nsID NS_IDIRECTORYSERVICEPROVIDER2_IID = new nsID("2f977d4b-5485-11d4-87e2-0010a4e75ef2");
  public static final nsID NS_IDOWNLOAD_IID = new nsID("06cb92f2-1dd2-11b2-95f2-96dfdfb804a1");
  public static final nsID NS_IDOWNLOAD_1_8_IID = new nsID("9e1fd9f2-9727-4926-85cd-f16c375bba6d");
  public static final nsID NS_IFACTORY_IID = new nsID("00000001-0000-0000-c000-000000000046");
  public static final nsID NS_IHELPERAPPLAUNCHERDIALOG_IID = new nsID("d7ebddf0-4c84-11d4-807a-00600811a9c3");
  public static final nsID NS_IHELPERAPPLAUNCHERDIALOG_1_9_IID = new nsID("f3704fdc-8ae6-4eba-a3c3-f02958ac0649");
  public static final nsID NS_IHTTPHEADERVISITOR_IID = new nsID("0cf40717-d7c1-4a94-8c1e-d6c9734101bb");
  public static final nsID NS_IHTTPHEADERVISITOR_10_IID = new nsID("35412859-b9d9-423c-8866-2d4559fdd2be");
  public static final nsID NS_IPROGRESSDIALOG_IID = new nsID("88a478b3-af65-440a-94dc-ed9b154d2990");
  public static final nsID NS_IPROGRESSDIALOG_1_8_IID = new nsID("20e790a2-76c6-462d-851a-22ab6cbbe48b");
  public static final nsID NS_IPROMPTFACTORY_IID = new nsID("2532b748-75db-4732-9173-78d3bf34f694");
  public static final nsID NS_IPROMPTSERVICE2_IID = new nsID("cf86d196-dbee-4482-9dfa-3477aa128319");
  public static final nsID NS_ISCRIPTOBJECTOWNER_IID = new nsID("8f6bca7e-ce42-11d1-b724-00600891d8c9");
  public static final nsID NS_ISECURITYCHECKEDCOMPONENT_IID = new nsID("0dad9e8c-a12d-4dcb-9a6f-7d09839356e1");
  public static final nsID NS_ISUPPORTSWEAKREFERENCE_IID = new nsID("9188bc86-f92e-11d2-81ef-0060083a0bcf");
  public static final nsID NS_ITOOLTIPLISTENER_IID = new nsID("44b78386-1dd2-11b2-9ad2-e4eee2ca1916");
  public static final nsID NS_IURICONTENTLISTENER_IID = new nsID("94928ab3-8b63-11d3-989d-001083010e9b");
  public static final nsID NS_IWEAKREFERENCE_IID = new nsID("9188bc85-f92e-11d2-81ef-0060083a0bcf");
  public static final nsID NS_IWEBBROWSERCHROMEFOCUS_IID = new nsID("d2206418-1dd1-11b2-8e55-acddcd2bcfb8");
  public static final nsID NS_IWINDOWCREATOR_IID = new nsID("30465632-a777-44cc-90f9-8145475ef999");
  public static final nsID NS_IWINDOWCREATOR2_IID = new nsID("f673ec81-a4b0-11d6-964b-eb5a2bf216fc");
  public static final nsID NS_IXPCSCRIPTABLE_IID = new nsID("155d1863-2b0b-4f5e-b800-05184944156b");
  public static final String EXTERNAL_CONTRACTID = "@eclipse.org/external;1";
  public static final String NS_AUTHPROMPTER_CONTRACTID = "@mozilla.org/passwordmanager/authpromptfactory;1";
  public static final String NS_CERTOVERRIDE_CONTRACTID = "@mozilla.org/security/certoverride;1";
  public static final String NS_CERTIFICATEDIALOGS_CONTRACTID = "@mozilla.org/nsCertificateDialogs;1";
  public static final String NS_CONTEXTSTACK_CONTRACTID = "@mozilla.org/js/xpc/ContextStack;1";
  public static final String NS_COOKIEMANAGER_CONTRACTID = "@mozilla.org/cookiemanager;1";
  public static final String NS_COOKIESERVICE_CONTRACTID = "@mozilla.org/cookieService;1";
  public static final String NS_DIRECTORYSERVICE_CONTRACTID = "@mozilla.org/file/directory_service;1";
  public static final String NS_DOMSERIALIZER_CONTRACTID = "@mozilla.org/xmlextras/xmlserializer;1";
  public static final String NS_DOWNLOAD_CONTRACTID = "@mozilla.org/download;1";
  public static final String NS_FILEPICKER_CONTRACTID = "@mozilla.org/filepicker;1";
  public static final String NS_FOCUSMANAGER_CONTRACTID = "@mozilla.org/focus-manager;1";
  public static final String NS_HELPERAPPLAUNCHERDIALOG_CONTRACTID = "@mozilla.org/helperapplauncherdialog;1";
  public static final String NS_MEMORY_CONTRACTID = "@mozilla.org/xpcom/memory-service;1";
  public static final String NS_MIMEINPUTSTREAM_CONTRACTID = "@mozilla.org/network/mime-input-stream;1";
  public static final String NS_SCRIPTSECURITYMANAGER_CONTRACTID = "@mozilla.org/scriptsecuritymanager;1";
  public static final String NS_OBSERVER_CONTRACTID = "@mozilla.org/observer-service;1";
  public static final String NS_PREFLOCALIZEDSTRING_CONTRACTID = "@mozilla.org/pref-localizedstring;1";
  public static final String NS_PREFSERVICE_CONTRACTID = "@mozilla.org/preferences-service;1";
  public static final String NS_PROMPTER_CONTRACTID = "@mozilla.org/prompter;1";
  public static final String NS_PROMPTSERVICE_CONTRACTID = "@mozilla.org/embedcomp/prompt-service;1";
  public static final String NS_TRANSFER_CONTRACTID = "@mozilla.org/transfer;1";
  public static final String NS_VARIANT_CONTRACTID = "@mozilla.org/variant;1";
  public static final String NS_WEBNAVIGATIONINFO_CONTRACTID = "@mozilla.org/webnavigation-info;1";
  public static final String NS_WINDOWWATCHER_CONTRACTID = "@mozilla.org/embedcomp/window-watcher;1";
  public static final String NS_APP_APPLICATION_REGISTRY_DIR = "AppRegD";
  public static final String NS_APP_CACHE_PARENT_DIR = "cachePDir";
  public static final String NS_APP_HISTORY_50_FILE = "UHist";
  public static final String NS_APP_LOCALSTORE_50_FILE = "LclSt";
  public static final String NS_APP_PLUGINS_DIR_LIST = "APluginsDL";
  public static final String NS_APP_PREF_DEFAULTS_50_DIR = "PrfDef";
  public static final String NS_APP_PREFS_50_DIR = "PrefD";
  public static final String NS_APP_PREFS_50_FILE = "PrefF";
  public static final String NS_APP_USER_CHROME_DIR = "UChrm";
  public static final String NS_APP_USER_MIMETYPES_50_FILE = "UMimTyp";
  public static final String NS_APP_USER_PROFILE_50_DIR = "ProfD";
  public static final String NS_GRE_COMPONENT_DIR = "GreComsD";
  public static final String NS_GRE_DIR = "GreD";
  public static final String NS_OS_CURRENT_PROCESS_DIR = "CurProcD";
  public static final String NS_OS_HOME_DIR = "Home";
  public static final String NS_OS_TEMP_DIR = "TmpD";
  public static final String NS_XPCOM_COMPONENT_DIR = "ComsD";
  public static final String NS_XPCOM_CURRENT_PROCESS_DIR = "XCurProcD";
  public static final String NS_XPCOM_INIT_CURRENT_PROCESS_DIR = "MozBinD";
  public static final int NS_OK = 0;
  public static final int NS_COMFALSE = 1;
  public static final int NS_BINDING_ABORTED = -2142568446;
  public static final int NS_ERROR_BASE = -1041039360;
  public static final int NS_ERROR_NOT_INITIALIZED = -1041039359;
  public static final int NS_ERROR_ALREADY_INITIALIZED = -1041039358;
  public static final int NS_ERROR_NOT_IMPLEMENTED = -2147467263;
  public static final int NS_NOINTERFACE = -2147467262;
  public static final int NS_ERROR_NO_INTERFACE = -2147467262;
  public static final int NS_ERROR_INVALID_POINTER = -2147467261;
  public static final int NS_ERROR_NULL_POINTER = -2147467261;
  public static final int NS_ERROR_ABORT = -2147467260;
  public static final int NS_ERROR_FAILURE = -2147467259;
  public static final int NS_ERROR_UNEXPECTED = -2147418113;
  public static final int NS_ERROR_OUT_OF_MEMORY = -2147024882;
  public static final int NS_ERROR_ILLEGAL_VALUE = -2147024809;
  public static final int NS_ERROR_INVALID_ARG = -2147024809;
  public static final int NS_ERROR_NO_AGGREGATION = -2147221232;
  public static final int NS_ERROR_NOT_AVAILABLE = -2147221231;
  public static final int NS_ERROR_FACTORY_NOT_REGISTERED = -2147221164;
  public static final int NS_ERROR_FACTORY_REGISTER_AGAIN = -2147221163;
  public static final int NS_ERROR_FACTORY_NOT_LOADED = -2147221000;
  public static final int NS_ERROR_FACTORY_NO_SIGNATURE_SUPPORT = -1041039103;
  public static final int NS_ERROR_FACTORY_EXISTS = -1041039104;
  public static final int NS_ERROR_HTMLPARSER_UNRESOLVEDDTD = -2142370829;
  public static final int NS_ERROR_FILE_NOT_FOUND = -2142109678;
  public static final int NS_ERROR_FILE_UNRECOGNIZED_PATH = -2142109695;
  public static final int SEC_ERROR_EXPIRED_ISSUER_CERTIFICATE = -2141577246;
  public static final int SEC_ERROR_CA_CERT_INVALID = -2141577252;
  public static final int SEC_ERROR_EXPIRED_CERTIFICATE = -2141577227;
  public static final int SEC_ERROR_INADEQUATE_KEY_USAGE = -2141577306;
  public static final int SEC_ERROR_UNKNOWN_ISSUER = -2141577229;
  public static final int SEC_ERROR_UNTRUSTED_CERT = -2141577237;
  public static final int SEC_ERROR_UNTRUSTED_ISSUER = -2141577236;
  public static final int SSL_ERROR_BAD_CERT_DOMAIN = -2141573132;
  public static final int USE_JSSTUB_FOR_ADDPROPERTY = 131072;
  public static final int WANT_POSTCREATE = 4;
  public static final int JSPROP_ENUMERATE = 1;
  public static final int JSPROP_PERMANENT = 4;
  public static final int JSPROP_READONLY = 2;
  public static final int JS_FALSE = 0;
  public static final int JS_TRUE = 1;
  
  public static final native int nsDynamicFunctionLoad_sizeof();
  
  public static void memmove(long paramLong, boolean[] paramArrayOfBoolean)
  {
    if (MozillaVersion.CheckVersion(5)) {
      memmove(paramLong, new byte[] { paramArrayOfBoolean[0] != 0 ? 1 : 0 }, 1L);
    } else {
      memmove(paramLong, new int[] { paramArrayOfBoolean[0] != 0 ? 1 : 0 }, 4L);
    }
  }
  
  public static void memmove(boolean[] paramArrayOfBoolean, long paramLong)
  {
    Object localObject;
    if (MozillaVersion.CheckVersion(5))
    {
      localObject = new byte[1];
      memmove((byte[])localObject, paramLong, 1L);
      paramArrayOfBoolean[0] = (localObject[0] != 0 ? 1 : false);
    }
    else
    {
      localObject = new int[1];
      memmove((int[])localObject, paramLong, 4L);
      paramArrayOfBoolean[0] = (localObject[0] != 0 ? 1 : false);
    }
  }
  
  public static final native void memmove(long paramLong1, nsDynamicFunctionLoad paramnsDynamicFunctionLoad, long paramLong2);
  
  public static final native void memmove(nsID paramnsID, long paramLong, int paramInt);
  
  public static final native void memmove(long paramLong, nsID paramnsID, int paramInt);
  
  public static final native int strlen_PRUnichar(long paramLong);
  
  public static final native long CALLBACK_GetScriptableFlags24(long paramLong);
  
  public static final native long CALLBACK_JSNative(long paramLong);
  
  public static final native long _JS_DefineFunction(byte[] paramArrayOfByte1, long paramLong1, long paramLong2, byte[] paramArrayOfByte2, long paramLong3, int paramInt1, int paramInt2);
  
  public static final long JS_DefineFunction(byte[] paramArrayOfByte1, long paramLong1, long paramLong2, byte[] paramArrayOfByte2, long paramLong3, int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      long l = _JS_DefineFunction(paramArrayOfByte1, paramLong1, paramLong2, paramArrayOfByte2, paramLong3, paramInt1, paramInt2);
      return l;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native long _JS_DefineFunction24(long paramLong1, long paramLong2, byte[] paramArrayOfByte, long paramLong3, int paramInt1, int paramInt2);
  
  public static final long JS_DefineFunction24(long paramLong1, long paramLong2, byte[] paramArrayOfByte, long paramLong3, int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      long l = _JS_DefineFunction24(paramLong1, paramLong2, paramArrayOfByte, paramLong3, paramInt1, paramInt2);
      return l;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _JS_EvaluateUCScriptForPrincipals(byte[] paramArrayOfByte1, long paramLong1, long paramLong2, long paramLong3, char[] paramArrayOfChar, int paramInt1, byte[] paramArrayOfByte2, int paramInt2, long[] paramArrayOfLong);
  
  public static final int JS_EvaluateUCScriptForPrincipals(byte[] paramArrayOfByte1, long paramLong1, long paramLong2, long paramLong3, char[] paramArrayOfChar, int paramInt1, byte[] paramArrayOfByte2, int paramInt2, long[] paramArrayOfLong)
  {
    lock.lock();
    try
    {
      int i = _JS_EvaluateUCScriptForPrincipals(paramArrayOfByte1, paramLong1, paramLong2, paramLong3, paramArrayOfChar, paramInt1, paramArrayOfByte2, paramInt2, paramArrayOfLong);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _JS_EvaluateUCScriptForPrincipals191(byte[] paramArrayOfByte1, long paramLong1, long paramLong2, long paramLong3, char[] paramArrayOfChar, int paramInt1, byte[] paramArrayOfByte2, int paramInt2, long paramLong4);
  
  public static final int JS_EvaluateUCScriptForPrincipals191(byte[] paramArrayOfByte1, long paramLong1, long paramLong2, long paramLong3, char[] paramArrayOfChar, int paramInt1, byte[] paramArrayOfByte2, int paramInt2, long paramLong4)
  {
    lock.lock();
    try
    {
      int i = _JS_EvaluateUCScriptForPrincipals191(paramArrayOfByte1, paramLong1, paramLong2, paramLong3, paramArrayOfChar, paramInt1, paramArrayOfByte2, paramInt2, paramLong4);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _JS_EvaluateUCScriptForPrincipals24(byte[] paramArrayOfByte1, long paramLong1, long paramLong2, long paramLong3, char[] paramArrayOfChar, int paramInt1, byte[] paramArrayOfByte2, int paramInt2, long paramLong4);
  
  public static final int JS_EvaluateUCScriptForPrincipals24(byte[] paramArrayOfByte1, long paramLong1, long paramLong2, long paramLong3, char[] paramArrayOfChar, int paramInt1, byte[] paramArrayOfByte2, int paramInt2, long paramLong4)
  {
    lock.lock();
    try
    {
      int i = _JS_EvaluateUCScriptForPrincipals24(paramArrayOfByte1, paramLong1, paramLong2, paramLong3, paramArrayOfChar, paramInt1, paramArrayOfByte2, paramInt2, paramLong4);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native long _JS_GetGlobalForScopeChain24(long paramLong);
  
  public static final long JS_GetGlobalForScopeChain24(long paramLong)
  {
    lock.lock();
    try
    {
      long l = _JS_GetGlobalForScopeChain24(paramLong);
      return l;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native long _JS_GetGlobalObject(byte[] paramArrayOfByte, long paramLong);
  
  public static final long JS_GetGlobalObject(byte[] paramArrayOfByte, long paramLong)
  {
    lock.lock();
    try
    {
      long l = _JS_GetGlobalObject(paramArrayOfByte, paramLong);
      return l;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native long _JS_NewObject(byte[] paramArrayOfByte, long paramLong1, long paramLong2, long paramLong3, long paramLong4);
  
  public static final long JS_NewObject(byte[] paramArrayOfByte, long paramLong1, long paramLong2, long paramLong3, long paramLong4)
  {
    lock.lock();
    try
    {
      long l = _JS_NewObject(paramArrayOfByte, paramLong1, paramLong2, paramLong3, paramLong4);
      return l;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _NS_Free(byte[] paramArrayOfByte, long paramLong);
  
  public static final boolean NS_Free(byte[] paramArrayOfByte, long paramLong)
  {
    lock.lock();
    try
    {
      boolean bool = _NS_Free(paramArrayOfByte, paramLong);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _NS_GetComponentManager(long[] paramArrayOfLong);
  
  public static final int NS_GetComponentManager(long[] paramArrayOfLong)
  {
    lock.lock();
    try
    {
      int i = _NS_GetComponentManager(paramArrayOfLong);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _NS_GetServiceManager(long[] paramArrayOfLong);
  
  public static final int NS_GetServiceManager(long[] paramArrayOfLong)
  {
    lock.lock();
    try
    {
      int i = _NS_GetServiceManager(paramArrayOfLong);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _NS_InitXPCOM2(long paramLong1, long paramLong2, long paramLong3);
  
  public static final int NS_InitXPCOM2(long paramLong1, long paramLong2, long paramLong3)
  {
    lock.lock();
    try
    {
      int i = _NS_InitXPCOM2(paramLong1, paramLong2, paramLong3);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _NS_NewLocalFile(long paramLong, int paramInt, long[] paramArrayOfLong);
  
  public static final int NS_NewLocalFile(long paramLong, int paramInt, long[] paramArrayOfLong)
  {
    lock.lock();
    try
    {
      int i = _NS_NewLocalFile(paramLong, paramInt, paramArrayOfLong);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native long _nsEmbedCString_new();
  
  public static final long nsEmbedCString_new()
  {
    lock.lock();
    try
    {
      long l = _nsEmbedCString_new();
      return l;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native long _nsEmbedCString_new(byte[] paramArrayOfByte, int paramInt);
  
  public static final long nsEmbedCString_new(byte[] paramArrayOfByte, int paramInt)
  {
    lock.lock();
    try
    {
      long l = _nsEmbedCString_new(paramArrayOfByte, paramInt);
      return l;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native long _nsEmbedCString_new(long paramLong, int paramInt);
  
  public static final long nsEmbedCString_new(long paramLong, int paramInt)
  {
    lock.lock();
    try
    {
      long l = _nsEmbedCString_new(paramLong, paramInt);
      return l;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _nsEmbedCString_delete(long paramLong);
  
  public static final void nsEmbedCString_delete(long paramLong)
  {
    lock.lock();
    try
    {
      _nsEmbedCString_delete(paramLong);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _nsEmbedCString_Length(long paramLong);
  
  public static final int nsEmbedCString_Length(long paramLong)
  {
    lock.lock();
    try
    {
      int i = _nsEmbedCString_Length(paramLong);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _nsIScriptGlobalObject_EnsureScriptEnvironment(long paramLong, int paramInt);
  
  public static final int nsIScriptGlobalObject_EnsureScriptEnvironment(long paramLong, int paramInt)
  {
    lock.lock();
    try
    {
      int i = _nsIScriptGlobalObject_EnsureScriptEnvironment(paramLong, paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _nsIScriptGlobalObject24_EnsureScriptEnvironment(long paramLong);
  
  public static final int nsIScriptGlobalObject24_EnsureScriptEnvironment(long paramLong)
  {
    lock.lock();
    try
    {
      int i = _nsIScriptGlobalObject24_EnsureScriptEnvironment(paramLong);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native long _nsIScriptGlobalObject24_GetGlobalJSObject(long paramLong);
  
  public static final long nsIScriptGlobalObject24_GetGlobalJSObject(long paramLong)
  {
    lock.lock();
    try
    {
      long l = _nsIScriptGlobalObject24_GetGlobalJSObject(paramLong);
      return l;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native long _nsIScriptGlobalObject_GetScriptContext(long paramLong, int paramInt);
  
  public static final long nsIScriptGlobalObject_GetScriptContext(long paramLong, int paramInt)
  {
    lock.lock();
    try
    {
      long l = _nsIScriptGlobalObject_GetScriptContext(paramLong, paramInt);
      return l;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native long _nsIScriptGlobalObject24_GetScriptContext(long paramLong);
  
  public static final long nsIScriptGlobalObject24_GetScriptContext(long paramLong)
  {
    lock.lock();
    try
    {
      long l = _nsIScriptGlobalObject24_GetScriptContext(paramLong);
      return l;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native long _nsIScriptContext_GetNativeContext(long paramLong);
  
  public static final long nsIScriptContext_GetNativeContext(long paramLong)
  {
    lock.lock();
    try
    {
      long l = _nsIScriptContext_GetNativeContext(paramLong);
      return l;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native long _nsIScriptContext24_GetNativeContext(long paramLong);
  
  public static final long nsIScriptContext24_GetNativeContext(long paramLong)
  {
    lock.lock();
    try
    {
      long l = _nsIScriptContext24_GetNativeContext(paramLong);
      return l;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native long _nsEmbedCString_get(long paramLong);
  
  public static final long nsEmbedCString_get(long paramLong)
  {
    lock.lock();
    try
    {
      long l = _nsEmbedCString_get(paramLong);
      return l;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _nsID_delete(long paramLong);
  
  public static final void nsID_delete(long paramLong)
  {
    lock.lock();
    try
    {
      _nsID_delete(paramLong);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native long _nsID_new();
  
  public static final long nsID_new()
  {
    lock.lock();
    try
    {
      long l = _nsID_new();
      return l;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _nsID_Equals(long paramLong1, long paramLong2);
  
  public static final int nsID_Equals(long paramLong1, long paramLong2)
  {
    lock.lock();
    try
    {
      int i = _nsID_Equals(paramLong1, paramLong2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native long _nsEmbedString_new();
  
  public static final long nsEmbedString_new()
  {
    lock.lock();
    try
    {
      long l = _nsEmbedString_new();
      return l;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native long _nsEmbedString_new(char[] paramArrayOfChar);
  
  public static final long nsEmbedString_new(char[] paramArrayOfChar)
  {
    lock.lock();
    try
    {
      long l = _nsEmbedString_new(paramArrayOfChar);
      return l;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _nsEmbedString_delete(long paramLong);
  
  public static final void nsEmbedString_delete(long paramLong)
  {
    lock.lock();
    try
    {
      _nsEmbedString_delete(paramLong);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _nsEmbedString_Length(long paramLong);
  
  public static final int nsEmbedString_Length(long paramLong)
  {
    lock.lock();
    try
    {
      int i = _nsEmbedString_Length(paramLong);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native long _nsEmbedString_get(long paramLong);
  
  public static final long nsEmbedString_get(long paramLong)
  {
    lock.lock();
    try
    {
      long l = _nsEmbedString_get(paramLong);
      return l;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native long _nsIMemory_Alloc(long paramLong, int paramInt);
  
  public static final long nsIMemory_Alloc(long paramLong, int paramInt)
  {
    lock.lock();
    try
    {
      long l = _nsIMemory_Alloc(paramLong, paramInt);
      return l;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native long _nsIMemory_Realloc(long paramLong1, long paramLong2, int paramInt);
  
  public static final long nsIMemory_Realloc(long paramLong1, long paramLong2, int paramInt)
  {
    lock.lock();
    try
    {
      long l = _nsIMemory_Realloc(paramLong1, paramLong2, paramInt);
      return l;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _XPCOMGlueLoadXULFunctions(long paramLong);
  
  public static final int XPCOMGlueLoadXULFunctions(long paramLong)
  {
    lock.lock();
    try
    {
      int i = _XPCOMGlueLoadXULFunctions(paramLong);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _XPCOMGlueStartup(byte[] paramArrayOfByte);
  
  public static final int XPCOMGlueStartup(byte[] paramArrayOfByte)
  {
    lock.lock();
    try
    {
      int i = _XPCOMGlueStartup(paramArrayOfByte);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _XPCOMGlueShutdown();
  
  public static final int XPCOMGlueShutdown()
  {
    lock.lock();
    try
    {
      int i = _XPCOMGlueShutdown();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _Call(long paramLong);
  
  public static final int Call(long paramLong)
  {
    lock.lock();
    try
    {
      int i = _Call(paramLong);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native long _Call(long paramLong1, long paramLong2, long paramLong3, byte[] paramArrayOfByte, int paramInt1, int paramInt2, int[] paramArrayOfInt);
  
  public static final long Call(long paramLong1, long paramLong2, long paramLong3, byte[] paramArrayOfByte, int paramInt1, int paramInt2, int[] paramArrayOfInt)
  {
    lock.lock();
    try
    {
      long l = _Call(paramLong1, paramLong2, paramLong3, paramArrayOfByte, paramInt1, paramInt2, paramArrayOfInt);
      return l;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _Call(long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5, int paramInt);
  
  public static final int Call(long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5, int paramInt)
  {
    lock.lock();
    try
    {
      int i = _Call(paramLong1, paramLong2, paramLong3, paramLong4, paramLong5, paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _Call(long paramLong1, long paramLong2, long paramLong3, long paramLong4);
  
  public static final int Call(long paramLong1, long paramLong2, long paramLong3, long paramLong4)
  {
    lock.lock();
    try
    {
      int i = _Call(paramLong1, paramLong2, paramLong3, paramLong4);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt, long paramLong);
  
  static final int VtblCall(int paramInt, long paramLong)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt, paramLong);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt, long paramLong, byte paramByte);
  
  static final int VtblCall(int paramInt, long paramLong, byte paramByte)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt, paramLong, paramByte);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt, long paramLong, byte[] paramArrayOfByte);
  
  static final int VtblCall(int paramInt, long paramLong, byte[] paramArrayOfByte)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt, paramLong, paramArrayOfByte);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt, long paramLong, char[] paramArrayOfChar);
  
  static final int VtblCall(int paramInt, long paramLong, char[] paramArrayOfChar)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt, paramLong, paramArrayOfChar);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt, long paramLong, double paramDouble);
  
  static final int VtblCall(int paramInt, long paramLong, double paramDouble)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt, paramLong, paramDouble);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt, long paramLong, float paramFloat);
  
  static final int VtblCall(int paramInt, long paramLong, float paramFloat)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt, paramLong, paramFloat);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt, long paramLong, float[] paramArrayOfFloat);
  
  static final int VtblCall(int paramInt, long paramLong, float[] paramArrayOfFloat)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt, paramLong, paramArrayOfFloat);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong, int paramInt2);
  
  static final int VtblCall(int paramInt1, long paramLong, int paramInt2)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong, paramInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt, long paramLong, int[] paramArrayOfInt);
  
  static final int VtblCall(int paramInt, long paramLong, int[] paramArrayOfInt)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt, paramLong, paramArrayOfInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt, long paramLong1, long paramLong2);
  
  static final int VtblCall(int paramInt, long paramLong1, long paramLong2)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt, paramLong1, paramLong2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt, long paramLong, long[] paramArrayOfLong);
  
  static final int VtblCall(int paramInt, long paramLong, long[] paramArrayOfLong)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt, paramLong, paramArrayOfLong);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt, long paramLong, short paramShort);
  
  static final int VtblCall(int paramInt, long paramLong, short paramShort)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt, paramLong, paramShort);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt, long paramLong, short[] paramArrayOfShort);
  
  static final int VtblCall(int paramInt, long paramLong, short[] paramArrayOfShort)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt, paramLong, paramArrayOfShort);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong, int paramInt2, int paramInt3);
  
  static final int VtblCall(int paramInt1, long paramLong, int paramInt2, int paramInt3)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong, paramInt2, paramInt3);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong1, int paramInt2, long paramLong2);
  
  static final int VtblCall(int paramInt1, long paramLong1, int paramInt2, long paramLong2)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong1, paramInt2, paramLong2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong1, long paramLong2, int paramInt2);
  
  static final int VtblCall(int paramInt1, long paramLong1, long paramLong2, int paramInt2)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong1, paramLong2, paramInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt, long paramLong1, long paramLong2, long paramLong3);
  
  static final int VtblCall(int paramInt, long paramLong1, long paramLong2, long paramLong3)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt, paramLong1, paramLong2, paramLong3);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong, int paramInt2, int[] paramArrayOfInt);
  
  static final int VtblCall(int paramInt1, long paramLong, int paramInt2, int[] paramArrayOfInt)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong, paramInt2, paramArrayOfInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong, int paramInt2, long[] paramArrayOfLong);
  
  static final int VtblCall(int paramInt1, long paramLong, int paramInt2, long[] paramArrayOfLong)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong, paramInt2, paramArrayOfLong);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt, long paramLong1, long paramLong2, long[] paramArrayOfLong);
  
  static final int VtblCall(int paramInt, long paramLong1, long paramLong2, long[] paramArrayOfLong)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt, paramLong1, paramLong2, paramArrayOfLong);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong, int paramInt2, short[] paramArrayOfShort);
  
  static final int VtblCall(int paramInt1, long paramLong, int paramInt2, short[] paramArrayOfShort)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong, paramInt2, paramArrayOfShort);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt, long paramLong1, long paramLong2, int[] paramArrayOfInt);
  
  static final int VtblCall(int paramInt, long paramLong1, long paramLong2, int[] paramArrayOfInt)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt, paramLong1, paramLong2, paramArrayOfInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt, long paramLong1, long paramLong2, short[] paramArrayOfShort);
  
  static final int VtblCall(int paramInt, long paramLong1, long paramLong2, short[] paramArrayOfShort)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt, paramLong1, paramLong2, paramArrayOfShort);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt, long paramLong, byte[] paramArrayOfByte, int[] paramArrayOfInt);
  
  static final int VtblCall(int paramInt, long paramLong, byte[] paramArrayOfByte, int[] paramArrayOfInt)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt, paramLong, paramArrayOfByte, paramArrayOfInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt, long paramLong, byte[] paramArrayOfByte, long[] paramArrayOfLong);
  
  static final int VtblCall(int paramInt, long paramLong, byte[] paramArrayOfByte, long[] paramArrayOfLong)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt, paramLong, paramArrayOfByte, paramArrayOfLong);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt, long paramLong1, byte[] paramArrayOfByte, long paramLong2);
  
  static final int VtblCall(int paramInt, long paramLong1, byte[] paramArrayOfByte, long paramLong2)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt, paramLong1, paramArrayOfByte, paramLong2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong, byte[] paramArrayOfByte, int paramInt2);
  
  static final int VtblCall(int paramInt1, long paramLong, byte[] paramArrayOfByte, int paramInt2)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong, paramArrayOfByte, paramInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt, long paramLong, byte[] paramArrayOfByte, short paramShort);
  
  static final int VtblCall(int paramInt, long paramLong, byte[] paramArrayOfByte, short paramShort)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt, paramLong, paramArrayOfByte, paramShort);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong, int paramInt2, nsID paramnsID);
  
  static final int VtblCall(int paramInt1, long paramLong, int paramInt2, nsID paramnsID)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong, paramInt2, paramnsID);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt, long paramLong1, long paramLong2, nsID paramnsID);
  
  static final int VtblCall(int paramInt, long paramLong1, long paramLong2, nsID paramnsID)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt, paramLong1, paramLong2, paramnsID);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong, int paramInt2, char[] paramArrayOfChar);
  
  static final int VtblCall(int paramInt1, long paramLong, int paramInt2, char[] paramArrayOfChar)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong, paramInt2, paramArrayOfChar);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt, long paramLong, int[] paramArrayOfInt1, int[] paramArrayOfInt2);
  
  static final int VtblCall(int paramInt, long paramLong, int[] paramArrayOfInt1, int[] paramArrayOfInt2)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt, paramLong, paramArrayOfInt1, paramArrayOfInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt, long paramLong, int[] paramArrayOfInt, long[] paramArrayOfLong);
  
  static final int VtblCall(int paramInt, long paramLong, int[] paramArrayOfInt, long[] paramArrayOfLong)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt, paramLong, paramArrayOfInt, paramArrayOfLong);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong, nsID paramnsID, int paramInt2);
  
  static final int VtblCall(int paramInt1, long paramLong, nsID paramnsID, int paramInt2)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong, paramnsID, paramInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt, long paramLong1, nsID paramnsID, long paramLong2);
  
  static final int VtblCall(int paramInt, long paramLong1, nsID paramnsID, long paramLong2)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt, paramLong1, paramnsID, paramLong2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt, long paramLong, nsID paramnsID, int[] paramArrayOfInt);
  
  static final int VtblCall(int paramInt, long paramLong, nsID paramnsID, int[] paramArrayOfInt)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt, paramLong, paramnsID, paramArrayOfInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt, long paramLong, nsID paramnsID, long[] paramArrayOfLong);
  
  static final int VtblCall(int paramInt, long paramLong, nsID paramnsID, long[] paramArrayOfLong)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt, paramLong, paramnsID, paramArrayOfLong);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt, long paramLong, char[] paramArrayOfChar1, char[] paramArrayOfChar2);
  
  static final int VtblCall(int paramInt, long paramLong, char[] paramArrayOfChar1, char[] paramArrayOfChar2)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt, paramLong, paramArrayOfChar1, paramArrayOfChar2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt, long paramLong, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2);
  
  static final int VtblCall(int paramInt, long paramLong, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt, paramLong, paramArrayOfByte1, paramArrayOfByte2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong, int paramInt2, byte[] paramArrayOfByte);
  
  static final int VtblCall(int paramInt1, long paramLong, int paramInt2, byte[] paramArrayOfByte)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong, paramInt2, paramArrayOfByte);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt, long paramLong1, long paramLong2, byte[] paramArrayOfByte);
  
  static final int VtblCall(int paramInt, long paramLong1, long paramLong2, byte[] paramArrayOfByte)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt, paramLong1, paramLong2, paramArrayOfByte);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong, int paramInt2, char[] paramArrayOfChar, int paramInt3);
  
  static final int VtblCall(int paramInt1, long paramLong, int paramInt2, char[] paramArrayOfChar, int paramInt3)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong, paramInt2, paramArrayOfChar, paramInt3);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong, int paramInt2, char[] paramArrayOfChar, int[] paramArrayOfInt);
  
  static final int VtblCall(int paramInt1, long paramLong, int paramInt2, char[] paramArrayOfChar, int[] paramArrayOfInt)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong, paramInt2, paramArrayOfChar, paramArrayOfInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt, long paramLong1, long paramLong2, char[] paramArrayOfChar, long[] paramArrayOfLong);
  
  static final int VtblCall(int paramInt, long paramLong1, long paramLong2, char[] paramArrayOfChar, long[] paramArrayOfLong)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt, paramLong1, paramLong2, paramArrayOfChar, paramArrayOfLong);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong1, long paramLong2, char[] paramArrayOfChar, int paramInt2);
  
  static final int VtblCall(int paramInt1, long paramLong1, long paramLong2, char[] paramArrayOfChar, int paramInt2)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong1, paramLong2, paramArrayOfChar, paramInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt, long paramLong, int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3);
  
  static final int VtblCall(int paramInt, long paramLong, int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt, paramLong, paramArrayOfInt1, paramArrayOfInt2, paramArrayOfInt3);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt, long paramLong, long[] paramArrayOfLong1, long[] paramArrayOfLong2);
  
  static final int VtblCall(int paramInt, long paramLong, long[] paramArrayOfLong1, long[] paramArrayOfLong2)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt, paramLong, paramArrayOfLong1, paramArrayOfLong2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong, int paramInt2, int[] paramArrayOfInt, int paramInt3);
  
  static final int VtblCall(int paramInt1, long paramLong, int paramInt2, int[] paramArrayOfInt, int paramInt3)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong, paramInt2, paramArrayOfInt, paramInt3);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong1, int paramInt2, int[] paramArrayOfInt, long paramLong2);
  
  static final int VtblCall(int paramInt1, long paramLong1, int paramInt2, int[] paramArrayOfInt, long paramLong2)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong1, paramInt2, paramArrayOfInt, paramLong2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt, long paramLong, long[] paramArrayOfLong1, long[] paramArrayOfLong2, long[] paramArrayOfLong3);
  
  static final int VtblCall(int paramInt, long paramLong, long[] paramArrayOfLong1, long[] paramArrayOfLong2, long[] paramArrayOfLong3)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt, paramLong, paramArrayOfLong1, paramArrayOfLong2, paramArrayOfLong3);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt, long paramLong, int[] paramArrayOfInt1, long[] paramArrayOfLong, int[] paramArrayOfInt2);
  
  static final int VtblCall(int paramInt, long paramLong, int[] paramArrayOfInt1, long[] paramArrayOfLong, int[] paramArrayOfInt2)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt, paramLong, paramArrayOfInt1, paramArrayOfLong, paramArrayOfInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt, long paramLong, int[] paramArrayOfInt, long[] paramArrayOfLong1, long[] paramArrayOfLong2);
  
  static final int VtblCall(int paramInt, long paramLong, int[] paramArrayOfInt, long[] paramArrayOfLong1, long[] paramArrayOfLong2)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt, paramLong, paramArrayOfInt, paramArrayOfLong1, paramArrayOfLong2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong, byte[] paramArrayOfByte, int paramInt2, int[] paramArrayOfInt);
  
  static final int VtblCall(int paramInt1, long paramLong, byte[] paramArrayOfByte, int paramInt2, int[] paramArrayOfInt)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong, paramArrayOfByte, paramInt2, paramArrayOfInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt, long paramLong1, byte[] paramArrayOfByte, long paramLong2, int[] paramArrayOfInt);
  
  static final int VtblCall(int paramInt, long paramLong1, byte[] paramArrayOfByte, long paramLong2, int[] paramArrayOfInt)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt, paramLong1, paramArrayOfByte, paramLong2, paramArrayOfInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt, long paramLong, byte[] paramArrayOfByte, nsID paramnsID, long[] paramArrayOfLong);
  
  static final int VtblCall(int paramInt, long paramLong, byte[] paramArrayOfByte, nsID paramnsID, long[] paramArrayOfLong)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt, paramLong, paramArrayOfByte, paramnsID, paramArrayOfLong);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt, long paramLong, byte[] paramArrayOfByte, nsID paramnsID, int[] paramArrayOfInt);
  
  static final int VtblCall(int paramInt, long paramLong, byte[] paramArrayOfByte, nsID paramnsID, int[] paramArrayOfInt)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt, paramLong, paramArrayOfByte, paramnsID, paramArrayOfInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong, char[] paramArrayOfChar, int paramInt2, int[] paramArrayOfInt);
  
  static final int VtblCall(int paramInt1, long paramLong, char[] paramArrayOfChar, int paramInt2, int[] paramArrayOfInt)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong, paramArrayOfChar, paramInt2, paramArrayOfInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt, long paramLong1, char[] paramArrayOfChar, long paramLong2, long[] paramArrayOfLong);
  
  static final int VtblCall(int paramInt, long paramLong1, char[] paramArrayOfChar, long paramLong2, long[] paramArrayOfLong)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt, paramLong1, paramArrayOfChar, paramLong2, paramArrayOfLong);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong, int paramInt2, char[] paramArrayOfChar1, char[] paramArrayOfChar2);
  
  static final int VtblCall(int paramInt1, long paramLong, int paramInt2, char[] paramArrayOfChar1, char[] paramArrayOfChar2)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong, paramInt2, paramArrayOfChar1, paramArrayOfChar2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt, long paramLong1, long paramLong2, char[] paramArrayOfChar1, char[] paramArrayOfChar2);
  
  static final int VtblCall(int paramInt, long paramLong1, long paramLong2, char[] paramArrayOfChar1, char[] paramArrayOfChar2)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt, paramLong1, paramLong2, paramArrayOfChar1, paramArrayOfChar2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt, long paramLong1, long paramLong2, long paramLong3, long paramLong4);
  
  static final int VtblCall(int paramInt, long paramLong1, long paramLong2, long paramLong3, long paramLong4)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt, paramLong1, paramLong2, paramLong3, paramLong4);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong1, long paramLong2, long paramLong3, int paramInt2);
  
  static final int VtblCall(int paramInt1, long paramLong1, long paramLong2, long paramLong3, int paramInt2)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong1, paramLong2, paramLong3, paramInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong1, int paramInt2, long paramLong2, long paramLong3);
  
  static final int VtblCall(int paramInt1, long paramLong1, int paramInt2, long paramLong2, long paramLong3)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong1, paramInt2, paramLong2, paramLong3);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong, int paramInt2, int paramInt3, int paramInt4);
  
  static final int VtblCall(int paramInt1, long paramLong, int paramInt2, int paramInt3, int paramInt4)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong, paramInt2, paramInt3, paramInt4);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong, int paramInt2, int paramInt3, long[] paramArrayOfLong);
  
  static final int VtblCall(int paramInt1, long paramLong, int paramInt2, int paramInt3, long[] paramArrayOfLong)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong, paramInt2, paramInt3, paramArrayOfLong);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong, int paramInt2, int paramInt3, int[] paramArrayOfInt);
  
  static final int VtblCall(int paramInt1, long paramLong, int paramInt2, int paramInt3, int[] paramArrayOfInt)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong, paramInt2, paramInt3, paramArrayOfInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt, long paramLong1, long paramLong2, long paramLong3, long[] paramArrayOfLong);
  
  static final int VtblCall(int paramInt, long paramLong1, long paramLong2, long paramLong3, long[] paramArrayOfLong)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt, paramLong1, paramLong2, paramLong3, paramArrayOfLong);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong1, long paramLong2, int paramInt2, long[] paramArrayOfLong);
  
  static final int VtblCall(int paramInt1, long paramLong1, long paramLong2, int paramInt2, long[] paramArrayOfLong)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong1, paramLong2, paramInt2, paramArrayOfLong);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt, long paramLong1, long paramLong2, long paramLong3, int[] paramArrayOfInt);
  
  static final int VtblCall(int paramInt, long paramLong1, long paramLong2, long paramLong3, int[] paramArrayOfInt)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt, paramLong1, paramLong2, paramLong3, paramArrayOfInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong, int paramInt2, nsID paramnsID, int[] paramArrayOfInt);
  
  static final int VtblCall(int paramInt1, long paramLong, int paramInt2, nsID paramnsID, int[] paramArrayOfInt)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong, paramInt2, paramnsID, paramArrayOfInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt, long paramLong1, long paramLong2, nsID paramnsID, long[] paramArrayOfLong);
  
  static final int VtblCall(int paramInt, long paramLong1, long paramLong2, nsID paramnsID, long[] paramArrayOfLong)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt, paramLong1, paramLong2, paramnsID, paramArrayOfLong);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong, int paramInt2, int paramInt3, char[] paramArrayOfChar);
  
  static final int VtblCall(int paramInt1, long paramLong, int paramInt2, int paramInt3, char[] paramArrayOfChar)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong, paramInt2, paramInt3, paramArrayOfChar);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt, long paramLong, nsID paramnsID1, nsID paramnsID2, long[] paramArrayOfLong);
  
  static final int VtblCall(int paramInt, long paramLong, nsID paramnsID1, nsID paramnsID2, long[] paramArrayOfLong)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt, paramLong, paramnsID1, paramnsID2, paramArrayOfLong);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt, long paramLong, nsID paramnsID1, nsID paramnsID2, int[] paramArrayOfInt);
  
  static final int VtblCall(int paramInt, long paramLong, nsID paramnsID1, nsID paramnsID2, int[] paramArrayOfInt)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt, paramLong, paramnsID1, paramnsID2, paramArrayOfInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt, long paramLong, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, int[] paramArrayOfInt);
  
  static final int VtblCall(int paramInt, long paramLong, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, int[] paramArrayOfInt)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt, paramLong, paramArrayOfByte1, paramArrayOfByte2, paramArrayOfInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt, long paramLong, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, long[] paramArrayOfLong);
  
  static final int VtblCall(int paramInt, long paramLong, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, long[] paramArrayOfLong)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt, paramLong, paramArrayOfByte1, paramArrayOfByte2, paramArrayOfLong);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt, long paramLong, byte[] paramArrayOfByte, int[] paramArrayOfInt1, int[] paramArrayOfInt2);
  
  static final int VtblCall(int paramInt, long paramLong, byte[] paramArrayOfByte, int[] paramArrayOfInt1, int[] paramArrayOfInt2)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt, paramLong, paramArrayOfByte, paramArrayOfInt1, paramArrayOfInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt, long paramLong, byte[] paramArrayOfByte, int[] paramArrayOfInt, long[] paramArrayOfLong);
  
  static final int VtblCall(int paramInt, long paramLong, byte[] paramArrayOfByte, int[] paramArrayOfInt, long[] paramArrayOfLong)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt, paramLong, paramArrayOfByte, paramArrayOfInt, paramArrayOfLong);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt, long paramLong, byte[] paramArrayOfByte, long[] paramArrayOfLong, int[] paramArrayOfInt);
  
  static final int VtblCall(int paramInt, long paramLong, byte[] paramArrayOfByte, long[] paramArrayOfLong, int[] paramArrayOfInt)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt, paramLong, paramArrayOfByte, paramArrayOfLong, paramArrayOfInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong, byte[] paramArrayOfByte, nsID paramnsID, int paramInt2);
  
  static final int VtblCall(int paramInt1, long paramLong, byte[] paramArrayOfByte, nsID paramnsID, int paramInt2)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong, paramArrayOfByte, paramnsID, paramInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt, long paramLong1, byte[] paramArrayOfByte, nsID paramnsID, long paramLong2);
  
  static final int VtblCall(int paramInt, long paramLong1, byte[] paramArrayOfByte, nsID paramnsID, long paramLong2)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt, paramLong1, paramArrayOfByte, paramnsID, paramLong2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong, int paramInt2, byte[] paramArrayOfByte, char[] paramArrayOfChar);
  
  static final int VtblCall(int paramInt1, long paramLong, int paramInt2, byte[] paramArrayOfByte, char[] paramArrayOfChar)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong, paramInt2, paramArrayOfByte, paramArrayOfChar);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt, long paramLong1, long paramLong2, byte[] paramArrayOfByte, char[] paramArrayOfChar);
  
  static final int VtblCall(int paramInt, long paramLong1, long paramLong2, byte[] paramArrayOfByte, char[] paramArrayOfChar)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt, paramLong1, paramLong2, paramArrayOfByte, paramArrayOfChar);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong, int paramInt2, int paramInt3, short paramShort);
  
  static final int VtblCall(int paramInt1, long paramLong, int paramInt2, int paramInt3, short paramShort)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong, paramInt2, paramInt3, paramShort);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt, long paramLong1, long paramLong2, long paramLong3, short paramShort);
  
  static final int VtblCall(int paramInt, long paramLong1, long paramLong2, long paramLong3, short paramShort)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt, paramLong1, paramLong2, paramLong3, paramShort);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong1, long paramLong2, int paramInt2, int paramInt3);
  
  static final int VtblCall(int paramInt1, long paramLong1, long paramLong2, int paramInt2, int paramInt3)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong1, paramLong2, paramInt2, paramInt3);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong, int paramInt2, int paramInt3, byte[] paramArrayOfByte);
  
  static final int VtblCall(int paramInt1, long paramLong, int paramInt2, int paramInt3, byte[] paramArrayOfByte)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong, paramInt2, paramInt3, paramArrayOfByte);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt, long paramLong1, long paramLong2, long paramLong3, byte[] paramArrayOfByte);
  
  static final int VtblCall(int paramInt, long paramLong1, long paramLong2, long paramLong3, byte[] paramArrayOfByte)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt, paramLong1, paramLong2, paramLong3, paramArrayOfByte);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, int paramInt2);
  
  static final int VtblCall(int paramInt1, long paramLong, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, int paramInt2)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong, paramArrayOfByte1, paramArrayOfByte2, paramInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong, int paramInt2, byte[] paramArrayOfByte, int[] paramArrayOfInt);
  
  static final int VtblCall(int paramInt1, long paramLong, int paramInt2, byte[] paramArrayOfByte, int[] paramArrayOfInt)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong, paramInt2, paramArrayOfByte, paramArrayOfInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt, long paramLong1, long paramLong2, byte[] paramArrayOfByte, long paramLong3);
  
  static final int VtblCall(int paramInt, long paramLong1, long paramLong2, byte[] paramArrayOfByte, long paramLong3)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt, paramLong1, paramLong2, paramArrayOfByte, paramLong3);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong, int paramInt2, byte[] paramArrayOfByte, int paramInt3);
  
  static final int VtblCall(int paramInt1, long paramLong, int paramInt2, byte[] paramArrayOfByte, int paramInt3)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong, paramInt2, paramArrayOfByte, paramInt3);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong1, long paramLong2, byte[] paramArrayOfByte, int paramInt2);
  
  static final int VtblCall(int paramInt1, long paramLong1, long paramLong2, byte[] paramArrayOfByte, int paramInt2)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong1, paramLong2, paramArrayOfByte, paramInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong, int paramInt2, byte[] paramArrayOfByte, short paramShort);
  
  static final int VtblCall(int paramInt1, long paramLong, int paramInt2, byte[] paramArrayOfByte, short paramShort)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong, paramInt2, paramArrayOfByte, paramShort);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt, long paramLong1, long paramLong2, byte[] paramArrayOfByte, short paramShort);
  
  static final int VtblCall(int paramInt, long paramLong1, long paramLong2, byte[] paramArrayOfByte, short paramShort)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt, paramLong1, paramLong2, paramArrayOfByte, paramShort);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt, long paramLong, float paramFloat1, float paramFloat2, int[] paramArrayOfInt);
  
  static final int VtblCall(int paramInt, long paramLong, float paramFloat1, float paramFloat2, int[] paramArrayOfInt)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt, paramLong, paramFloat1, paramFloat2, paramArrayOfInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt, long paramLong, float paramFloat1, float paramFloat2, long[] paramArrayOfLong);
  
  static final int VtblCall(int paramInt, long paramLong, float paramFloat1, float paramFloat2, long[] paramArrayOfLong)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt, paramLong, paramFloat1, paramFloat2, paramArrayOfLong);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong, short paramShort, int paramInt2, int paramInt3, int paramInt4);
  
  static final int VtblCall(int paramInt1, long paramLong, short paramShort, int paramInt2, int paramInt3, int paramInt4)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong, paramShort, paramInt2, paramInt3, paramInt4);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong1, short paramShort, long paramLong2, int paramInt2, long paramLong3);
  
  static final int VtblCall(int paramInt1, long paramLong1, short paramShort, long paramLong2, int paramInt2, long paramLong3)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong1, paramShort, paramLong2, paramInt2, paramLong3);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong, byte[] paramArrayOfByte, int paramInt2, nsID paramnsID, int[] paramArrayOfInt);
  
  static final int VtblCall(int paramInt1, long paramLong, byte[] paramArrayOfByte, int paramInt2, nsID paramnsID, int[] paramArrayOfInt)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong, paramArrayOfByte, paramInt2, paramnsID, paramArrayOfInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt, long paramLong1, byte[] paramArrayOfByte, long paramLong2, nsID paramnsID, long[] paramArrayOfLong);
  
  static final int VtblCall(int paramInt, long paramLong1, byte[] paramArrayOfByte, long paramLong2, nsID paramnsID, long[] paramArrayOfLong)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt, paramLong1, paramArrayOfByte, paramLong2, paramnsID, paramArrayOfLong);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong, int paramInt2, byte[] paramArrayOfByte, int paramInt3, int[] paramArrayOfInt);
  
  static final int VtblCall(int paramInt1, long paramLong, int paramInt2, byte[] paramArrayOfByte, int paramInt3, int[] paramArrayOfInt)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong, paramInt2, paramArrayOfByte, paramInt3, paramArrayOfInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt, long paramLong1, long paramLong2, byte[] paramArrayOfByte, long paramLong3, long[] paramArrayOfLong);
  
  static final int VtblCall(int paramInt, long paramLong1, long paramLong2, byte[] paramArrayOfByte, long paramLong3, long[] paramArrayOfLong)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt, paramLong1, paramLong2, paramArrayOfByte, paramLong3, paramArrayOfLong);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong, int paramInt2, char[] paramArrayOfChar1, char[] paramArrayOfChar2, int[] paramArrayOfInt);
  
  static final int VtblCall(int paramInt1, long paramLong, int paramInt2, char[] paramArrayOfChar1, char[] paramArrayOfChar2, int[] paramArrayOfInt)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong, paramInt2, paramArrayOfChar1, paramArrayOfChar2, paramArrayOfInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt, long paramLong1, long paramLong2, char[] paramArrayOfChar1, char[] paramArrayOfChar2, long[] paramArrayOfLong);
  
  static final int VtblCall(int paramInt, long paramLong1, long paramLong2, char[] paramArrayOfChar1, char[] paramArrayOfChar2, long[] paramArrayOfLong)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt, paramLong1, paramLong2, paramArrayOfChar1, paramArrayOfChar2, paramArrayOfLong);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt, long paramLong1, long paramLong2, char[] paramArrayOfChar1, char[] paramArrayOfChar2, int[] paramArrayOfInt);
  
  static final int VtblCall(int paramInt, long paramLong1, long paramLong2, char[] paramArrayOfChar1, char[] paramArrayOfChar2, int[] paramArrayOfInt)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt, paramLong1, paramLong2, paramArrayOfChar1, paramArrayOfChar2, paramArrayOfInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong, int paramInt2, int paramInt3, int paramInt4, char[] paramArrayOfChar);
  
  static final int VtblCall(int paramInt1, long paramLong, int paramInt2, int paramInt3, int paramInt4, char[] paramArrayOfChar)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong, paramInt2, paramInt3, paramInt4, paramArrayOfChar);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong1, long paramLong2, long paramLong3, int paramInt2, char[] paramArrayOfChar);
  
  static final int VtblCall(int paramInt1, long paramLong1, long paramLong2, long paramLong3, int paramInt2, char[] paramArrayOfChar)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong1, paramLong2, paramLong3, paramInt2, paramArrayOfChar);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong, int paramInt2, int paramInt3, int paramInt4, int paramInt5);
  
  static final int VtblCall(int paramInt1, long paramLong, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong, paramInt2, paramInt3, paramInt4, paramInt5);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong1, long paramLong2, long paramLong3, int paramInt2, int paramInt3);
  
  static final int VtblCall(int paramInt1, long paramLong1, long paramLong2, long paramLong3, int paramInt2, int paramInt3)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong1, paramLong2, paramLong3, paramInt2, paramInt3);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong1, long paramLong2, long paramLong3, long paramLong4, int paramInt2);
  
  static final int VtblCall(int paramInt1, long paramLong1, long paramLong2, long paramLong3, long paramLong4, int paramInt2)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong1, paramLong2, paramLong3, paramLong4, paramInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong, int paramInt2, int paramInt3, int paramInt4, int[] paramArrayOfInt);
  
  static final int VtblCall(int paramInt1, long paramLong, int paramInt2, int paramInt3, int paramInt4, int[] paramArrayOfInt)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong, paramInt2, paramInt3, paramInt4, paramArrayOfInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt, long paramLong1, long paramLong2, long paramLong3, long paramLong4, int[] paramArrayOfInt);
  
  static final int VtblCall(int paramInt, long paramLong1, long paramLong2, long paramLong3, long paramLong4, int[] paramArrayOfInt)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt, paramLong1, paramLong2, paramLong3, paramLong4, paramArrayOfInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt, long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5);
  
  static final int VtblCall(int paramInt, long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt, paramLong1, paramLong2, paramLong3, paramLong4, paramLong5);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt, long paramLong1, long paramLong2, long paramLong3, long paramLong4, long[] paramArrayOfLong);
  
  static final int VtblCall(int paramInt, long paramLong1, long paramLong2, long paramLong3, long paramLong4, long[] paramArrayOfLong)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt, paramLong1, paramLong2, paramLong3, paramLong4, paramArrayOfLong);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong1, long paramLong2, long paramLong3, int paramInt2, int[] paramArrayOfInt);
  
  static final int VtblCall(int paramInt1, long paramLong1, long paramLong2, long paramLong3, int paramInt2, int[] paramArrayOfInt)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong1, paramLong2, paramLong3, paramInt2, paramArrayOfInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt, long paramLong, int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3, int[] paramArrayOfInt4);
  
  static final int VtblCall(int paramInt, long paramLong, int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3, int[] paramArrayOfInt4)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt, paramLong, paramArrayOfInt1, paramArrayOfInt2, paramArrayOfInt3, paramArrayOfInt4);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong, int paramInt2, int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3);
  
  static final int VtblCall(int paramInt1, long paramLong, int paramInt2, int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong, paramInt2, paramArrayOfInt1, paramArrayOfInt2, paramArrayOfInt3);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong, int paramInt2, int[] paramArrayOfInt1, int[] paramArrayOfInt2, long[] paramArrayOfLong);
  
  static final int VtblCall(int paramInt1, long paramLong, int paramInt2, int[] paramArrayOfInt1, int[] paramArrayOfInt2, long[] paramArrayOfLong)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong, paramInt2, paramArrayOfInt1, paramArrayOfInt2, paramArrayOfLong);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong, nsID paramnsID, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, int paramInt2);
  
  static final int VtblCall(int paramInt1, long paramLong, nsID paramnsID, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, int paramInt2)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong, paramnsID, paramArrayOfByte1, paramArrayOfByte2, paramInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt, long paramLong1, nsID paramnsID, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, long paramLong2);
  
  static final int VtblCall(int paramInt, long paramLong1, nsID paramnsID, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, long paramLong2)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt, paramLong1, paramnsID, paramArrayOfByte1, paramArrayOfByte2, paramLong2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong, nsID paramnsID1, int paramInt2, nsID paramnsID2, int[] paramArrayOfInt);
  
  static final int VtblCall(int paramInt1, long paramLong, nsID paramnsID1, int paramInt2, nsID paramnsID2, int[] paramArrayOfInt)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong, paramnsID1, paramInt2, paramnsID2, paramArrayOfInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt, long paramLong1, nsID paramnsID1, long paramLong2, nsID paramnsID2, long[] paramArrayOfLong);
  
  static final int VtblCall(int paramInt, long paramLong1, nsID paramnsID1, long paramLong2, nsID paramnsID2, long[] paramArrayOfLong)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt, paramLong1, paramnsID1, paramLong2, paramnsID2, paramArrayOfLong);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong, byte[] paramArrayOfByte, int paramInt2, int[] paramArrayOfInt1, int[] paramArrayOfInt2);
  
  static final int VtblCall(int paramInt1, long paramLong, byte[] paramArrayOfByte, int paramInt2, int[] paramArrayOfInt1, int[] paramArrayOfInt2)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong, paramArrayOfByte, paramInt2, paramArrayOfInt1, paramArrayOfInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong, byte[] paramArrayOfByte, int paramInt2, long[] paramArrayOfLong, int[] paramArrayOfInt);
  
  static final int VtblCall(int paramInt1, long paramLong, byte[] paramArrayOfByte, int paramInt2, long[] paramArrayOfLong, int[] paramArrayOfInt)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong, paramArrayOfByte, paramInt2, paramArrayOfLong, paramArrayOfInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong, int paramInt2, int paramInt3, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2);
  
  static final int VtblCall(int paramInt1, long paramLong, int paramInt2, int paramInt3, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong, paramInt2, paramInt3, paramArrayOfByte1, paramArrayOfByte2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt, long paramLong1, long paramLong2, long paramLong3, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2);
  
  static final int VtblCall(int paramInt, long paramLong1, long paramLong2, long paramLong3, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt, paramLong1, paramLong2, paramLong3, paramArrayOfByte1, paramArrayOfByte2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong, int paramInt2, int paramInt3, byte[] paramArrayOfByte, int paramInt4);
  
  static final int VtblCall(int paramInt1, long paramLong, int paramInt2, int paramInt3, byte[] paramArrayOfByte, int paramInt4)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong, paramInt2, paramInt3, paramArrayOfByte, paramInt4);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt, long paramLong1, long paramLong2, long paramLong3, byte[] paramArrayOfByte, long paramLong4);
  
  static final int VtblCall(int paramInt, long paramLong1, long paramLong2, long paramLong3, byte[] paramArrayOfByte, long paramLong4)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt, paramLong1, paramLong2, paramLong3, paramArrayOfByte, paramLong4);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong, short[] paramArrayOfShort, int paramInt2, int[] paramArrayOfInt1, int[] paramArrayOfInt2);
  
  static final int VtblCall(int paramInt1, long paramLong, short[] paramArrayOfShort, int paramInt2, int[] paramArrayOfInt1, int[] paramArrayOfInt2)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong, paramArrayOfShort, paramInt2, paramArrayOfInt1, paramArrayOfInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt, long paramLong1, short[] paramArrayOfShort, long paramLong2, int[] paramArrayOfInt, long[] paramArrayOfLong);
  
  static final int VtblCall(int paramInt, long paramLong1, short[] paramArrayOfShort, long paramLong2, int[] paramArrayOfInt, long[] paramArrayOfLong)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt, paramLong1, paramArrayOfShort, paramLong2, paramArrayOfInt, paramArrayOfLong);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong1, long paramLong2, int paramInt2, int paramInt3, int[] paramArrayOfInt);
  
  static final int VtblCall(int paramInt1, long paramLong1, long paramLong2, int paramInt2, int paramInt3, int[] paramArrayOfInt)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong1, paramLong2, paramInt2, paramInt3, paramArrayOfInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong, int paramInt2, int paramInt3, int[] paramArrayOfInt1, int[] paramArrayOfInt2);
  
  static final int VtblCall(int paramInt1, long paramLong, int paramInt2, int paramInt3, int[] paramArrayOfInt1, int[] paramArrayOfInt2)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong, paramInt2, paramInt3, paramArrayOfInt1, paramArrayOfInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong1, long paramLong2, int paramInt2, long[] paramArrayOfLong1, long[] paramArrayOfLong2);
  
  static final int VtblCall(int paramInt1, long paramLong1, long paramLong2, int paramInt2, long[] paramArrayOfLong1, long[] paramArrayOfLong2)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong1, paramLong2, paramInt2, paramArrayOfLong1, paramArrayOfLong2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt, long paramLong1, long paramLong2, long paramLong3, int[] paramArrayOfInt1, int[] paramArrayOfInt2);
  
  static final int VtblCall(int paramInt, long paramLong1, long paramLong2, long paramLong3, int[] paramArrayOfInt1, int[] paramArrayOfInt2)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt, paramLong1, paramLong2, paramLong3, paramArrayOfInt1, paramArrayOfInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong, char[] paramArrayOfChar, int paramInt2, int paramInt3, int paramInt4, int paramInt5);
  
  static final int VtblCall(int paramInt1, long paramLong, char[] paramArrayOfChar, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong, paramArrayOfChar, paramInt2, paramInt3, paramInt4, paramInt5);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong1, char[] paramArrayOfChar, int paramInt2, long paramLong2, long paramLong3, long paramLong4);
  
  static final int VtblCall(int paramInt1, long paramLong1, char[] paramArrayOfChar, int paramInt2, long paramLong2, long paramLong3, long paramLong4)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong1, paramArrayOfChar, paramInt2, paramLong2, paramLong3, paramLong4);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt, long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5, long paramLong6);
  
  static final int VtblCall(int paramInt, long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5, long paramLong6)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt, paramLong1, paramLong2, paramLong3, paramLong4, paramLong5, paramLong6);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt, long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5, long[] paramArrayOfLong);
  
  static final int VtblCall(int paramInt, long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5, long[] paramArrayOfLong)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt, paramLong1, paramLong2, paramLong3, paramLong4, paramLong5, paramArrayOfLong);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong1, long paramLong2, int paramInt2, long paramLong3, int paramInt3, long[] paramArrayOfLong);
  
  static final int VtblCall(int paramInt1, long paramLong1, long paramLong2, int paramInt2, long paramLong3, int paramInt3, long[] paramArrayOfLong)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong1, paramLong2, paramInt2, paramLong3, paramInt3, paramArrayOfLong);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong1, long paramLong2, int paramInt2, int paramInt3, long paramLong3, int paramInt4);
  
  static final int VtblCall(int paramInt1, long paramLong1, long paramLong2, int paramInt2, int paramInt3, long paramLong3, int paramInt4)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong1, paramLong2, paramInt2, paramInt3, paramLong3, paramInt4);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6);
  
  static final int VtblCall(int paramInt1, long paramLong, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int[] paramArrayOfInt);
  
  static final int VtblCall(int paramInt1, long paramLong, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int[] paramArrayOfInt)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong, paramInt2, paramInt3, paramInt4, paramInt5, paramArrayOfInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong, int paramInt2, int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3, int[] paramArrayOfInt4);
  
  static final int VtblCall(int paramInt1, long paramLong, int paramInt2, int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3, int[] paramArrayOfInt4)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong, paramInt2, paramArrayOfInt1, paramArrayOfInt2, paramArrayOfInt3, paramArrayOfInt4);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong, int paramInt2, char[] paramArrayOfChar1, char[] paramArrayOfChar2, char[] paramArrayOfChar3, int[] paramArrayOfInt);
  
  static final int VtblCall(int paramInt1, long paramLong, int paramInt2, char[] paramArrayOfChar1, char[] paramArrayOfChar2, char[] paramArrayOfChar3, int[] paramArrayOfInt)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong, paramInt2, paramArrayOfChar1, paramArrayOfChar2, paramArrayOfChar3, paramArrayOfInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt, long paramLong1, long paramLong2, char[] paramArrayOfChar1, char[] paramArrayOfChar2, char[] paramArrayOfChar3, int[] paramArrayOfInt);
  
  static final int VtblCall(int paramInt, long paramLong1, long paramLong2, char[] paramArrayOfChar1, char[] paramArrayOfChar2, char[] paramArrayOfChar3, int[] paramArrayOfInt)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt, paramLong1, paramLong2, paramArrayOfChar1, paramArrayOfChar2, paramArrayOfChar3, paramArrayOfInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong, byte[] paramArrayOfByte, int paramInt2, int paramInt3, int[] paramArrayOfInt1, int[] paramArrayOfInt2);
  
  static final int VtblCall(int paramInt1, long paramLong, byte[] paramArrayOfByte, int paramInt2, int paramInt3, int[] paramArrayOfInt1, int[] paramArrayOfInt2)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong, paramArrayOfByte, paramInt2, paramInt3, paramArrayOfInt1, paramArrayOfInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong1, byte[] paramArrayOfByte, int paramInt2, long paramLong2, long[] paramArrayOfLong, int[] paramArrayOfInt);
  
  static final int VtblCall(int paramInt1, long paramLong1, byte[] paramArrayOfByte, int paramInt2, long paramLong2, long[] paramArrayOfLong, int[] paramArrayOfInt)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong1, paramArrayOfByte, paramInt2, paramLong2, paramArrayOfLong, paramArrayOfInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong, int paramInt2, int paramInt3, byte[] paramArrayOfByte, int paramInt4, int paramInt5);
  
  static final int VtblCall(int paramInt1, long paramLong, int paramInt2, int paramInt3, byte[] paramArrayOfByte, int paramInt4, int paramInt5)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong, paramInt2, paramInt3, paramArrayOfByte, paramInt4, paramInt5);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong1, long paramLong2, long paramLong3, byte[] paramArrayOfByte, long paramLong4, int paramInt2);
  
  static final int VtblCall(int paramInt1, long paramLong1, long paramLong2, long paramLong3, byte[] paramArrayOfByte, long paramLong4, int paramInt2)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong1, paramLong2, paramLong3, paramArrayOfByte, paramLong4, paramInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong, int paramInt2, nsID paramnsID, int paramInt3, int paramInt4, int[] paramArrayOfInt);
  
  static final int VtblCall(int paramInt1, long paramLong, int paramInt2, nsID paramnsID, int paramInt3, int paramInt4, int[] paramArrayOfInt)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong, paramInt2, paramnsID, paramInt3, paramInt4, paramArrayOfInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt, long paramLong1, long paramLong2, nsID paramnsID, long paramLong3, long paramLong4, long[] paramArrayOfLong);
  
  static final int VtblCall(int paramInt, long paramLong1, long paramLong2, nsID paramnsID, long paramLong3, long paramLong4, long[] paramArrayOfLong)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt, paramLong1, paramLong2, paramnsID, paramLong3, paramLong4, paramArrayOfLong);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong1, long paramLong2, int paramInt2, long paramLong3, int paramInt3, int paramInt4);
  
  static final int VtblCall(int paramInt1, long paramLong1, long paramLong2, int paramInt2, long paramLong3, int paramInt3, int paramInt4)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong1, paramLong2, paramInt2, paramLong3, paramInt3, paramInt4);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong1, long paramLong2, long paramLong3, int paramInt2, int paramInt3, long[] paramArrayOfLong);
  
  static final int VtblCall(int paramInt1, long paramLong1, long paramLong2, long paramLong3, int paramInt2, int paramInt3, long[] paramArrayOfLong)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong1, paramLong2, paramLong3, paramInt2, paramInt3, paramArrayOfLong);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong, int paramInt2, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3, int paramInt3, int[] paramArrayOfInt);
  
  static final int VtblCall(int paramInt1, long paramLong, int paramInt2, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3, int paramInt3, int[] paramArrayOfInt)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong, paramInt2, paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte3, paramInt3, paramArrayOfInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt, long paramLong1, long paramLong2, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3, long paramLong3, long[] paramArrayOfLong);
  
  static final int VtblCall(int paramInt, long paramLong1, long paramLong2, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3, long paramLong3, long[] paramArrayOfLong)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt, paramLong1, paramLong2, paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte3, paramLong3, paramArrayOfLong);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong1, int paramInt2, int paramInt3, char[] paramArrayOfChar, int paramInt4, long paramLong2, int paramInt5);
  
  static final int VtblCall(int paramInt1, long paramLong1, int paramInt2, int paramInt3, char[] paramArrayOfChar, int paramInt4, long paramLong2, int paramInt5)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong1, paramInt2, paramInt3, paramArrayOfChar, paramInt4, paramLong2, paramInt5);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong1, long paramLong2, long paramLong3, char[] paramArrayOfChar, int paramInt2, long paramLong4, int paramInt3);
  
  static final int VtblCall(int paramInt1, long paramLong1, long paramLong2, long paramLong3, char[] paramArrayOfChar, int paramInt2, long paramLong4, int paramInt3)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong1, paramLong2, paramLong3, paramArrayOfChar, paramInt2, paramLong4, paramInt3);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong1, int paramInt2, int paramInt3, char[] paramArrayOfChar, long paramLong2, long paramLong3, long paramLong4);
  
  static final int VtblCall(int paramInt1, long paramLong1, int paramInt2, int paramInt3, char[] paramArrayOfChar, long paramLong2, long paramLong3, long paramLong4)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong1, paramInt2, paramInt3, paramArrayOfChar, paramLong2, paramLong3, paramLong4);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt, long paramLong1, long paramLong2, long paramLong3, char[] paramArrayOfChar, long paramLong4, long paramLong5, long paramLong6);
  
  static final int VtblCall(int paramInt, long paramLong1, long paramLong2, long paramLong3, char[] paramArrayOfChar, long paramLong4, long paramLong5, long paramLong6)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt, paramLong1, paramLong2, paramLong3, paramArrayOfChar, paramLong4, paramLong5, paramLong6);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt, long paramLong, int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3, int[] paramArrayOfInt4, int[] paramArrayOfInt5, int[] paramArrayOfInt6);
  
  static final int VtblCall(int paramInt, long paramLong, int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3, int[] paramArrayOfInt4, int[] paramArrayOfInt5, int[] paramArrayOfInt6)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt, paramLong, paramArrayOfInt1, paramArrayOfInt2, paramArrayOfInt3, paramArrayOfInt4, paramArrayOfInt5, paramArrayOfInt6);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt, long paramLong, long[] paramArrayOfLong1, long[] paramArrayOfLong2, long[] paramArrayOfLong3, long[] paramArrayOfLong4, long[] paramArrayOfLong5, int[] paramArrayOfInt);
  
  static final int VtblCall(int paramInt, long paramLong, long[] paramArrayOfLong1, long[] paramArrayOfLong2, long[] paramArrayOfLong3, long[] paramArrayOfLong4, long[] paramArrayOfLong5, int[] paramArrayOfInt)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt, paramLong, paramArrayOfLong1, paramArrayOfLong2, paramArrayOfLong3, paramArrayOfLong4, paramArrayOfLong5, paramArrayOfInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7);
  
  static final int VtblCall(int paramInt1, long paramLong, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong1, long paramLong2, long paramLong3, int paramInt2, int paramInt3, int paramInt4, int paramInt5);
  
  static final int VtblCall(int paramInt1, long paramLong1, long paramLong2, long paramLong3, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong1, paramLong2, paramLong3, paramInt2, paramInt3, paramInt4, paramInt5);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int[] paramArrayOfInt);
  
  static final int VtblCall(int paramInt1, long paramLong, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int[] paramArrayOfInt)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramArrayOfInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt, long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5, long paramLong6, long[] paramArrayOfLong);
  
  static final int VtblCall(int paramInt, long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5, long paramLong6, long[] paramArrayOfLong)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt, paramLong1, paramLong2, paramLong3, paramLong4, paramLong5, paramLong6, paramArrayOfLong);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong, nsID paramnsID, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, int paramInt2, byte[] paramArrayOfByte3, byte[] paramArrayOfByte4);
  
  static final int VtblCall(int paramInt1, long paramLong, nsID paramnsID, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, int paramInt2, byte[] paramArrayOfByte3, byte[] paramArrayOfByte4)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong, paramnsID, paramArrayOfByte1, paramArrayOfByte2, paramInt2, paramArrayOfByte3, paramArrayOfByte4);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt, long paramLong1, nsID paramnsID, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, long paramLong2, byte[] paramArrayOfByte3, byte[] paramArrayOfByte4);
  
  static final int VtblCall(int paramInt, long paramLong1, nsID paramnsID, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, long paramLong2, byte[] paramArrayOfByte3, byte[] paramArrayOfByte4)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt, paramLong1, paramnsID, paramArrayOfByte1, paramArrayOfByte2, paramLong2, paramArrayOfByte3, paramArrayOfByte4);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong1, int paramInt2, int paramInt3, long paramLong2, long paramLong3, long paramLong4, long paramLong5);
  
  static final int VtblCall(int paramInt1, long paramLong1, int paramInt2, int paramInt3, long paramLong2, long paramLong3, long paramLong4, long paramLong5)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong1, paramInt2, paramInt3, paramLong2, paramLong3, paramLong4, paramLong5);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt, long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5, long paramLong6, long paramLong7);
  
  static final int VtblCall(int paramInt, long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5, long paramLong6, long paramLong7)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt, paramLong1, paramLong2, paramLong3, paramLong4, paramLong5, paramLong6, paramLong7);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong, int paramInt2, char[] paramArrayOfChar1, char[] paramArrayOfChar2, char[] paramArrayOfChar3, int[] paramArrayOfInt1, int[] paramArrayOfInt2);
  
  static final int VtblCall(int paramInt1, long paramLong, int paramInt2, char[] paramArrayOfChar1, char[] paramArrayOfChar2, char[] paramArrayOfChar3, int[] paramArrayOfInt1, int[] paramArrayOfInt2)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong, paramInt2, paramArrayOfChar1, paramArrayOfChar2, paramArrayOfChar3, paramArrayOfInt1, paramArrayOfInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt, long paramLong1, long paramLong2, char[] paramArrayOfChar1, char[] paramArrayOfChar2, char[] paramArrayOfChar3, int[] paramArrayOfInt1, int[] paramArrayOfInt2);
  
  static final int VtblCall(int paramInt, long paramLong1, long paramLong2, char[] paramArrayOfChar1, char[] paramArrayOfChar2, char[] paramArrayOfChar3, int[] paramArrayOfInt1, int[] paramArrayOfInt2)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt, paramLong1, paramLong2, paramArrayOfChar1, paramArrayOfChar2, paramArrayOfChar3, paramArrayOfInt1, paramArrayOfInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3, int paramInt2, int paramInt3, int[] paramArrayOfInt);
  
  static final int VtblCall(int paramInt1, long paramLong, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3, int paramInt2, int paramInt3, int[] paramArrayOfInt)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong, paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte3, paramInt2, paramInt3, paramArrayOfInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3, int paramInt2, int paramInt3, long[] paramArrayOfLong);
  
  static final int VtblCall(int paramInt1, long paramLong, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3, int paramInt2, int paramInt3, long[] paramArrayOfLong)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong, paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte3, paramInt2, paramInt3, paramArrayOfLong);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int[] paramArrayOfInt1, int[] paramArrayOfInt2);
  
  static final int VtblCall(int paramInt1, long paramLong, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int[] paramArrayOfInt1, int[] paramArrayOfInt2)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong, paramInt2, paramInt3, paramInt4, paramInt5, paramArrayOfInt1, paramArrayOfInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong1, long paramLong2, int paramInt2, int paramInt3, long paramLong3, int[] paramArrayOfInt, long[] paramArrayOfLong);
  
  static final int VtblCall(int paramInt1, long paramLong1, long paramLong2, int paramInt2, int paramInt3, long paramLong3, int[] paramArrayOfInt, long[] paramArrayOfLong)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong1, paramLong2, paramInt2, paramInt3, paramLong3, paramArrayOfInt, paramArrayOfLong);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong, int paramInt2, int paramInt3, char[] paramArrayOfChar1, char[] paramArrayOfChar2, int paramInt4, int[] paramArrayOfInt);
  
  static final int VtblCall(int paramInt1, long paramLong, int paramInt2, int paramInt3, char[] paramArrayOfChar1, char[] paramArrayOfChar2, int paramInt4, int[] paramArrayOfInt)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong, paramInt2, paramInt3, paramArrayOfChar1, paramArrayOfChar2, paramInt4, paramArrayOfInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong1, long paramLong2, long paramLong3, char[] paramArrayOfChar1, char[] paramArrayOfChar2, int paramInt2, long[] paramArrayOfLong);
  
  static final int VtblCall(int paramInt1, long paramLong1, long paramLong2, long paramLong3, char[] paramArrayOfChar1, char[] paramArrayOfChar2, int paramInt2, long[] paramArrayOfLong)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong1, paramLong2, paramLong3, paramArrayOfChar1, paramArrayOfChar2, paramInt2, paramArrayOfLong);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong, int paramInt2, int paramInt3, int paramInt4, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, int paramInt5);
  
  static final int VtblCall(int paramInt1, long paramLong, int paramInt2, int paramInt3, int paramInt4, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, int paramInt5)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong, paramInt2, paramInt3, paramInt4, paramArrayOfByte1, paramArrayOfByte2, paramInt5);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt, long paramLong1, long paramLong2, long paramLong3, long paramLong4, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, long paramLong5);
  
  static final int VtblCall(int paramInt, long paramLong1, long paramLong2, long paramLong3, long paramLong4, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, long paramLong5)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt, paramLong1, paramLong2, paramLong3, paramLong4, paramArrayOfByte1, paramArrayOfByte2, paramLong5);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong, int paramInt2, int paramInt3, int paramInt4, int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3);
  
  static final int VtblCall(int paramInt1, long paramLong, int paramInt2, int paramInt3, int paramInt4, int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong, paramInt2, paramInt3, paramInt4, paramArrayOfInt1, paramArrayOfInt2, paramArrayOfInt3);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong1, long paramLong2, int paramInt2, long paramLong3, int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3);
  
  static final int VtblCall(int paramInt1, long paramLong1, long paramLong2, int paramInt2, long paramLong3, int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong1, paramLong2, paramInt2, paramLong3, paramArrayOfInt1, paramArrayOfInt2, paramArrayOfInt3);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong, int paramInt2, char[] paramArrayOfChar1, char[] paramArrayOfChar2, int paramInt3, int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3);
  
  static final int VtblCall(int paramInt1, long paramLong, int paramInt2, char[] paramArrayOfChar1, char[] paramArrayOfChar2, int paramInt3, int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong, paramInt2, paramArrayOfChar1, paramArrayOfChar2, paramInt3, paramArrayOfInt1, paramArrayOfInt2, paramArrayOfInt3);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong1, long paramLong2, char[] paramArrayOfChar1, char[] paramArrayOfChar2, int paramInt2, long[] paramArrayOfLong, int[] paramArrayOfInt1, int[] paramArrayOfInt2);
  
  static final int VtblCall(int paramInt1, long paramLong1, long paramLong2, char[] paramArrayOfChar1, char[] paramArrayOfChar2, int paramInt2, long[] paramArrayOfLong, int[] paramArrayOfInt1, int[] paramArrayOfInt2)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong1, paramLong2, paramArrayOfChar1, paramArrayOfChar2, paramInt2, paramArrayOfLong, paramArrayOfInt1, paramArrayOfInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong, int paramInt2, char[] paramArrayOfChar1, char[] paramArrayOfChar2, int[] paramArrayOfInt1, char[] paramArrayOfChar3, int[] paramArrayOfInt2, int[] paramArrayOfInt3);
  
  static final int VtblCall(int paramInt1, long paramLong, int paramInt2, char[] paramArrayOfChar1, char[] paramArrayOfChar2, int[] paramArrayOfInt1, char[] paramArrayOfChar3, int[] paramArrayOfInt2, int[] paramArrayOfInt3)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong, paramInt2, paramArrayOfChar1, paramArrayOfChar2, paramArrayOfInt1, paramArrayOfChar3, paramArrayOfInt2, paramArrayOfInt3);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt, long paramLong1, long paramLong2, char[] paramArrayOfChar1, char[] paramArrayOfChar2, long[] paramArrayOfLong, char[] paramArrayOfChar3, int[] paramArrayOfInt1, int[] paramArrayOfInt2);
  
  static final int VtblCall(int paramInt, long paramLong1, long paramLong2, char[] paramArrayOfChar1, char[] paramArrayOfChar2, long[] paramArrayOfLong, char[] paramArrayOfChar3, int[] paramArrayOfInt1, int[] paramArrayOfInt2)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt, paramLong1, paramLong2, paramArrayOfChar1, paramArrayOfChar2, paramArrayOfLong, paramArrayOfChar3, paramArrayOfInt1, paramArrayOfInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong, int paramInt2, int paramInt3, int paramInt4, int paramInt5, char[] paramArrayOfChar, int[] paramArrayOfInt1, int[] paramArrayOfInt2);
  
  static final int VtblCall(int paramInt1, long paramLong, int paramInt2, int paramInt3, int paramInt4, int paramInt5, char[] paramArrayOfChar, int[] paramArrayOfInt1, int[] paramArrayOfInt2)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong, paramInt2, paramInt3, paramInt4, paramInt5, paramArrayOfChar, paramArrayOfInt1, paramArrayOfInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong1, long paramLong2, long paramLong3, int paramInt2, long paramLong4, char[] paramArrayOfChar, int[] paramArrayOfInt1, int[] paramArrayOfInt2);
  
  static final int VtblCall(int paramInt1, long paramLong1, long paramLong2, long paramLong3, int paramInt2, long paramLong4, char[] paramArrayOfChar, int[] paramArrayOfInt1, int[] paramArrayOfInt2)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong1, paramLong2, paramLong3, paramInt2, paramLong4, paramArrayOfChar, paramArrayOfInt1, paramArrayOfInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, long paramLong2, int paramInt6, int paramInt7);
  
  static final int VtblCall(int paramInt1, long paramLong1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, long paramLong2, int paramInt6, int paramInt7)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong1, paramInt2, paramInt3, paramInt4, paramInt5, paramLong2, paramInt6, paramInt7);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt, long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5, long paramLong6, long paramLong7, long paramLong8);
  
  static final int VtblCall(int paramInt, long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5, long paramLong6, long paramLong7, long paramLong8)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt, paramLong1, paramLong2, paramLong3, paramLong4, paramLong5, paramLong6, paramLong7, paramLong8);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3);
  
  static final int VtblCall(int paramInt1, long paramLong, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong, paramInt2, paramInt3, paramInt4, paramInt5, paramArrayOfInt1, paramArrayOfInt2, paramArrayOfInt3);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong1, long paramLong2, int paramInt2, long paramLong3, long paramLong4, int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3);
  
  static final int VtblCall(int paramInt1, long paramLong1, long paramLong2, int paramInt2, long paramLong3, long paramLong4, int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong1, paramLong2, paramInt2, paramLong3, paramLong4, paramArrayOfInt1, paramArrayOfInt2, paramArrayOfInt3);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong, int paramInt2, char[] paramArrayOfChar1, char[] paramArrayOfChar2, int[] paramArrayOfInt1, int[] paramArrayOfInt2, char[] paramArrayOfChar3, int[] paramArrayOfInt3, int[] paramArrayOfInt4);
  
  static final int VtblCall(int paramInt1, long paramLong, int paramInt2, char[] paramArrayOfChar1, char[] paramArrayOfChar2, int[] paramArrayOfInt1, int[] paramArrayOfInt2, char[] paramArrayOfChar3, int[] paramArrayOfInt3, int[] paramArrayOfInt4)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong, paramInt2, paramArrayOfChar1, paramArrayOfChar2, paramArrayOfInt1, paramArrayOfInt2, paramArrayOfChar3, paramArrayOfInt3, paramArrayOfInt4);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt, long paramLong1, long paramLong2, char[] paramArrayOfChar1, char[] paramArrayOfChar2, long[] paramArrayOfLong1, long[] paramArrayOfLong2, char[] paramArrayOfChar3, int[] paramArrayOfInt1, int[] paramArrayOfInt2);
  
  static final int VtblCall(int paramInt, long paramLong1, long paramLong2, char[] paramArrayOfChar1, char[] paramArrayOfChar2, long[] paramArrayOfLong1, long[] paramArrayOfLong2, char[] paramArrayOfChar3, int[] paramArrayOfInt1, int[] paramArrayOfInt2)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt, paramLong1, paramLong2, paramArrayOfChar1, paramArrayOfChar2, paramArrayOfLong1, paramArrayOfLong2, paramArrayOfChar3, paramArrayOfInt1, paramArrayOfInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int[] paramArrayOfInt);
  
  static final int VtblCall(int paramInt1, long paramLong, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int[] paramArrayOfInt)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8, paramArrayOfInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong1, int paramInt2, long paramLong2, long paramLong3, long paramLong4, long paramLong5, long paramLong6, long paramLong7, long[] paramArrayOfLong);
  
  static final int VtblCall(int paramInt1, long paramLong1, int paramInt2, long paramLong2, long paramLong3, long paramLong4, long paramLong5, long paramLong6, long paramLong7, long[] paramArrayOfLong)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong1, paramInt2, paramLong2, paramLong3, paramLong4, paramLong5, paramLong6, paramLong7, paramArrayOfLong);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong1, long paramLong2, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int[] paramArrayOfInt);
  
  static final int VtblCall(int paramInt1, long paramLong1, long paramLong2, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int[] paramArrayOfInt)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong1, paramLong2, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramArrayOfInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, char[] paramArrayOfChar, int[] paramArrayOfInt1, int[] paramArrayOfInt2);
  
  static final int VtblCall(int paramInt1, long paramLong, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, char[] paramArrayOfChar, int[] paramArrayOfInt1, int[] paramArrayOfInt2)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramArrayOfChar, paramArrayOfInt1, paramArrayOfInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5, int paramInt2, long paramLong6, char[] paramArrayOfChar, int[] paramArrayOfInt, long[] paramArrayOfLong);
  
  static final int VtblCall(int paramInt1, long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5, int paramInt2, long paramLong6, char[] paramArrayOfChar, int[] paramArrayOfInt, long[] paramArrayOfLong)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong1, paramLong2, paramLong3, paramLong4, paramLong5, paramInt2, paramLong6, paramArrayOfChar, paramArrayOfInt, paramArrayOfLong);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, int paramInt10, int paramInt11);
  
  static final int VtblCall(int paramInt1, long paramLong, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, int paramInt10, int paramInt11)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8, paramInt9, paramInt10, paramInt11);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong1, long paramLong2, int paramInt2, int paramInt3, long paramLong3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9);
  
  static final int VtblCall(int paramInt1, long paramLong1, long paramLong2, int paramInt2, int paramInt3, long paramLong3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong1, paramLong2, paramInt2, paramInt3, paramLong3, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8, paramInt9);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong, int paramInt2, char[] paramArrayOfChar1, char[] paramArrayOfChar2, int paramInt3, char[] paramArrayOfChar3, char[] paramArrayOfChar4, char[] paramArrayOfChar5, char[] paramArrayOfChar6, int[] paramArrayOfInt1, int[] paramArrayOfInt2);
  
  static final int VtblCall(int paramInt1, long paramLong, int paramInt2, char[] paramArrayOfChar1, char[] paramArrayOfChar2, int paramInt3, char[] paramArrayOfChar3, char[] paramArrayOfChar4, char[] paramArrayOfChar5, char[] paramArrayOfChar6, int[] paramArrayOfInt1, int[] paramArrayOfInt2)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong, paramInt2, paramArrayOfChar1, paramArrayOfChar2, paramInt3, paramArrayOfChar3, paramArrayOfChar4, paramArrayOfChar5, paramArrayOfChar6, paramArrayOfInt1, paramArrayOfInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong1, long paramLong2, char[] paramArrayOfChar1, char[] paramArrayOfChar2, int paramInt2, char[] paramArrayOfChar3, char[] paramArrayOfChar4, char[] paramArrayOfChar5, char[] paramArrayOfChar6, int[] paramArrayOfInt1, int[] paramArrayOfInt2);
  
  static final int VtblCall(int paramInt1, long paramLong1, long paramLong2, char[] paramArrayOfChar1, char[] paramArrayOfChar2, int paramInt2, char[] paramArrayOfChar3, char[] paramArrayOfChar4, char[] paramArrayOfChar5, char[] paramArrayOfChar6, int[] paramArrayOfInt1, int[] paramArrayOfInt2)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong1, paramLong2, paramArrayOfChar1, paramArrayOfChar2, paramInt2, paramArrayOfChar3, paramArrayOfChar4, paramArrayOfChar5, paramArrayOfChar6, paramArrayOfInt1, paramArrayOfInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong, int paramInt2, int paramInt3, int paramInt4, int paramInt5, char[] paramArrayOfChar, int paramInt6, int paramInt7, int paramInt8, int paramInt9, int paramInt10, int[] paramArrayOfInt1, int[] paramArrayOfInt2);
  
  static final int VtblCall(int paramInt1, long paramLong, int paramInt2, int paramInt3, int paramInt4, int paramInt5, char[] paramArrayOfChar, int paramInt6, int paramInt7, int paramInt8, int paramInt9, int paramInt10, int[] paramArrayOfInt1, int[] paramArrayOfInt2)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong, paramInt2, paramInt3, paramInt4, paramInt5, paramArrayOfChar, paramInt6, paramInt7, paramInt8, paramInt9, paramInt10, paramArrayOfInt1, paramArrayOfInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong1, long paramLong2, long paramLong3, long paramLong4, int paramInt2, char[] paramArrayOfChar, long paramLong5, long paramLong6, int paramInt3, long paramLong7, int paramInt4, long[] paramArrayOfLong1, long[] paramArrayOfLong2);
  
  static final int VtblCall(int paramInt1, long paramLong1, long paramLong2, long paramLong3, long paramLong4, int paramInt2, char[] paramArrayOfChar, long paramLong5, long paramLong6, int paramInt3, long paramLong7, int paramInt4, long[] paramArrayOfLong1, long[] paramArrayOfLong2)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong1, paramLong2, paramLong3, paramLong4, paramInt2, paramArrayOfChar, paramLong5, paramLong6, paramInt3, paramLong7, paramInt4, paramArrayOfLong1, paramArrayOfLong2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong, int paramInt2, int paramInt3, int paramInt4, int paramInt5, char[] paramArrayOfChar, byte[] paramArrayOfByte, int paramInt6, int paramInt7, int paramInt8, int paramInt9, int paramInt10, int[] paramArrayOfInt1, int[] paramArrayOfInt2);
  
  static final int VtblCall(int paramInt1, long paramLong, int paramInt2, int paramInt3, int paramInt4, int paramInt5, char[] paramArrayOfChar, byte[] paramArrayOfByte, int paramInt6, int paramInt7, int paramInt8, int paramInt9, int paramInt10, int[] paramArrayOfInt1, int[] paramArrayOfInt2)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong, paramInt2, paramInt3, paramInt4, paramInt5, paramArrayOfChar, paramArrayOfByte, paramInt6, paramInt7, paramInt8, paramInt9, paramInt10, paramArrayOfInt1, paramArrayOfInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong1, long paramLong2, long paramLong3, long paramLong4, int paramInt2, char[] paramArrayOfChar, byte[] paramArrayOfByte, long paramLong5, long paramLong6, int paramInt3, long paramLong7, int paramInt4, long[] paramArrayOfLong1, long[] paramArrayOfLong2);
  
  static final int VtblCall(int paramInt1, long paramLong1, long paramLong2, long paramLong3, long paramLong4, int paramInt2, char[] paramArrayOfChar, byte[] paramArrayOfByte, long paramLong5, long paramLong6, int paramInt3, long paramLong7, int paramInt4, long[] paramArrayOfLong1, long[] paramArrayOfLong2)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong1, paramLong2, paramLong3, paramLong4, paramInt2, paramArrayOfChar, paramArrayOfByte, paramLong5, paramLong6, paramInt3, paramLong7, paramInt4, paramArrayOfLong1, paramArrayOfLong2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, int paramInt10, int paramInt11, int paramInt12, int paramInt13, int paramInt14, short paramShort, int paramInt15);
  
  static final int VtblCall(int paramInt1, long paramLong, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, int paramInt10, int paramInt11, int paramInt12, int paramInt13, int paramInt14, short paramShort, int paramInt15)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8, paramInt9, paramInt10, paramInt11, paramInt12, paramInt13, paramInt14, paramShort, paramInt15);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong1, long paramLong2, int paramInt2, int paramInt3, long paramLong3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, int paramInt10, int paramInt11, int paramInt12, short paramShort, long paramLong4);
  
  static final int VtblCall(int paramInt1, long paramLong1, long paramLong2, int paramInt2, int paramInt3, long paramLong3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, int paramInt10, int paramInt11, int paramInt12, short paramShort, long paramLong4)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong1, paramLong2, paramInt2, paramInt3, paramLong3, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8, paramInt9, paramInt10, paramInt11, paramInt12, paramShort, paramLong4);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, int paramInt10, int paramInt11, int paramInt12, int paramInt13, int paramInt14, short paramShort1, int paramInt15, float paramFloat, short paramShort2);
  
  static final int VtblCall(int paramInt1, long paramLong, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, int paramInt10, int paramInt11, int paramInt12, int paramInt13, int paramInt14, short paramShort1, int paramInt15, float paramFloat, short paramShort2)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8, paramInt9, paramInt10, paramInt11, paramInt12, paramInt13, paramInt14, paramShort1, paramInt15, paramFloat, paramShort2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static final native int _VtblCall(int paramInt1, long paramLong1, long paramLong2, int paramInt2, int paramInt3, long paramLong3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, int paramInt10, int paramInt11, int paramInt12, short paramShort1, long paramLong4, float paramFloat, short paramShort2);
  
  static final int VtblCall(int paramInt1, long paramLong1, long paramLong2, int paramInt2, int paramInt3, long paramLong3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, int paramInt10, int paramInt11, int paramInt12, short paramShort1, long paramLong4, float paramFloat, short paramShort2)
  {
    lock.lock();
    try
    {
      int i = _VtblCall(paramInt1, paramLong1, paramLong2, paramInt2, paramInt3, paramLong3, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8, paramInt9, paramInt10, paramInt11, paramInt12, paramShort1, paramLong4, paramFloat, paramShort2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/internal/mozilla/XPCOM.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */