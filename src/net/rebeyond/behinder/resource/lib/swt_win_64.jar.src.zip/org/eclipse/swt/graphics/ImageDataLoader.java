package org.eclipse.swt.graphics;

import java.io.InputStream;

class ImageDataLoader
{
  public static ImageData[] load(InputStream paramInputStream)
  {
    return new ImageLoader().load(paramInputStream);
  }
  
  public static ImageData[] load(String paramString)
  {
    return new ImageLoader().load(paramString);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/graphics/ImageDataLoader.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */