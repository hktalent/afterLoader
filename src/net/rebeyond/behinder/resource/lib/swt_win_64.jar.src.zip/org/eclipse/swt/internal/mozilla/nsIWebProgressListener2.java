package org.eclipse.swt.internal.mozilla;

public class nsIWebProgressListener2
  extends nsIWebProgressListener
{
  static final int LAST_METHOD_ID = nsIWebProgressListener.LAST_METHOD_ID + 1;
  static final String NS_IWEBPROGRESSLISTENER2_IID_STR = "3f24610d-1e1f-4151-9d2e-239884742324";
  
  public nsIWebProgressListener2(long paramLong)
  {
    super(paramLong);
  }
  
  static
  {
    IIDStore.RegisterIID(nsIWebProgressListener2.class, 0, new nsID("3f24610d-1e1f-4151-9d2e-239884742324"));
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/internal/mozilla/nsIWebProgressListener2.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */