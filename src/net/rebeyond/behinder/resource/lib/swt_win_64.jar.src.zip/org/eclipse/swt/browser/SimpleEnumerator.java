package org.eclipse.swt.browser;

import org.eclipse.swt.internal.C;
import org.eclipse.swt.internal.mozilla.IIDStore;
import org.eclipse.swt.internal.mozilla.XPCOM;
import org.eclipse.swt.internal.mozilla.XPCOMObject;
import org.eclipse.swt.internal.mozilla.nsID;
import org.eclipse.swt.internal.mozilla.nsISimpleEnumerator;
import org.eclipse.swt.internal.mozilla.nsISupports;

class SimpleEnumerator
{
  XPCOMObject supports;
  XPCOMObject simpleEnumerator;
  int refCount = 0;
  nsISupports[] values;
  int index = 0;
  
  SimpleEnumerator(nsISupports[] paramArrayOfnsISupports)
  {
    this.values = paramArrayOfnsISupports;
    for (int i = 0; i < paramArrayOfnsISupports.length; i++) {
      paramArrayOfnsISupports[i].AddRef();
    }
    createCOMInterfaces();
  }
  
  int AddRef()
  {
    this.refCount += 1;
    return this.refCount;
  }
  
  void createCOMInterfaces()
  {
    this.supports = new XPCOMObject(new int[] { 2, 0, 0 })
    {
      public long method0(long[] paramAnonymousArrayOfLong)
      {
        return SimpleEnumerator.this.QueryInterface(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method1(long[] paramAnonymousArrayOfLong)
      {
        return SimpleEnumerator.this.AddRef();
      }
      
      public long method2(long[] paramAnonymousArrayOfLong)
      {
        return SimpleEnumerator.this.Release();
      }
    };
    this.simpleEnumerator = new XPCOMObject(new int[] { 2, 0, 0, 1, 1 })
    {
      public long method0(long[] paramAnonymousArrayOfLong)
      {
        return SimpleEnumerator.this.QueryInterface(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method1(long[] paramAnonymousArrayOfLong)
      {
        return SimpleEnumerator.this.AddRef();
      }
      
      public long method2(long[] paramAnonymousArrayOfLong)
      {
        return SimpleEnumerator.this.Release();
      }
      
      public long method3(long[] paramAnonymousArrayOfLong)
      {
        return SimpleEnumerator.this.HasMoreElements(paramAnonymousArrayOfLong[0]);
      }
      
      public long method4(long[] paramAnonymousArrayOfLong)
      {
        return SimpleEnumerator.this.GetNext(paramAnonymousArrayOfLong[0]);
      }
    };
  }
  
  void disposeCOMInterfaces()
  {
    if (this.supports != null)
    {
      this.supports.dispose();
      this.supports = null;
    }
    if (this.simpleEnumerator != null)
    {
      this.simpleEnumerator.dispose();
      this.simpleEnumerator = null;
    }
    if (this.values != null)
    {
      for (int i = 0; i < this.values.length; i++) {
        this.values[i].Release();
      }
      this.values = null;
    }
  }
  
  long getAddress()
  {
    return this.simpleEnumerator.getAddress();
  }
  
  int QueryInterface(long paramLong1, long paramLong2)
  {
    if ((paramLong1 == 0L) || (paramLong2 == 0L)) {
      return -2147467262;
    }
    nsID localnsID = new nsID();
    XPCOM.memmove(localnsID, paramLong1, 16);
    if (localnsID.Equals(IIDStore.GetIID(nsISupports.class)))
    {
      XPCOM.memmove(paramLong2, new long[] { this.supports.getAddress() }, C.PTR_SIZEOF);
      AddRef();
      return 0;
    }
    if (localnsID.Equals(IIDStore.GetIID(nsISimpleEnumerator.class)))
    {
      XPCOM.memmove(paramLong2, new long[] { this.simpleEnumerator.getAddress() }, C.PTR_SIZEOF);
      AddRef();
      return 0;
    }
    XPCOM.memmove(paramLong2, new long[] { 0L }, C.PTR_SIZEOF);
    return -2147467262;
  }
  
  int Release()
  {
    this.refCount -= 1;
    if (this.refCount == 0) {
      disposeCOMInterfaces();
    }
    return this.refCount;
  }
  
  int HasMoreElements(long paramLong)
  {
    int i = (this.values != null) && (this.index < this.values.length) ? 1 : 0;
    XPCOM.memmove(paramLong, new boolean[] { i });
    return 0;
  }
  
  int GetNext(long paramLong)
  {
    if ((this.values == null) || (this.index == this.values.length)) {
      return -2147418113;
    }
    nsISupports localnsISupports = this.values[(this.index++)];
    localnsISupports.AddRef();
    XPCOM.memmove(paramLong, new long[] { localnsISupports.getAddress() }, C.PTR_SIZEOF);
    return 0;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/browser/SimpleEnumerator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */