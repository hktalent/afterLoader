package org.eclipse.swt.events;

public abstract class MenuAdapter
  implements MenuListener
{
  public void menuHidden(MenuEvent paramMenuEvent) {}
  
  public void menuShown(MenuEvent paramMenuEvent) {}
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/events/MenuAdapter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */