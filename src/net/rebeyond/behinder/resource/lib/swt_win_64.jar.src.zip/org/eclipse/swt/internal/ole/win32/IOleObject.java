package org.eclipse.swt.internal.ole.win32;

import org.eclipse.swt.internal.win32.MSG;
import org.eclipse.swt.internal.win32.RECT;
import org.eclipse.swt.internal.win32.SIZE;

public class IOleObject
  extends IUnknown
{
  public IOleObject(long paramLong)
  {
    super(paramLong);
  }
  
  public int Advise(long paramLong, int[] paramArrayOfInt)
  {
    return COM.VtblCall(19, this.address, paramLong, paramArrayOfInt);
  }
  
  public int Close(int paramInt)
  {
    return COM.VtblCall(6, this.address, paramInt);
  }
  
  public int DoVerb(int paramInt1, MSG paramMSG, long paramLong1, int paramInt2, long paramLong2, RECT paramRECT)
  {
    return COM.VtblCall(11, this.address, paramInt1, paramMSG, paramLong1, paramInt2, paramLong2, paramRECT);
  }
  
  public int GetClientSite(long[] paramArrayOfLong)
  {
    return COM.VtblCall(4, this.address, paramArrayOfLong);
  }
  
  public int GetExtent(int paramInt, SIZE paramSIZE)
  {
    return COM.VtblCall(18, this.address, paramInt, paramSIZE);
  }
  
  public int SetClientSite(long paramLong)
  {
    return COM.VtblCall(3, this.address, paramLong);
  }
  
  public int SetExtent(int paramInt, SIZE paramSIZE)
  {
    return COM.VtblCall(17, this.address, paramInt, paramSIZE);
  }
  
  public int SetHostNames(String paramString1, String paramString2)
  {
    char[] arrayOfChar1 = null;
    if (paramString1 != null)
    {
      int i = paramString1.length();
      arrayOfChar1 = new char[i + 1];
      paramString1.getChars(0, i, arrayOfChar1, 0);
    }
    char[] arrayOfChar2 = null;
    if (paramString2 != null)
    {
      int j = paramString2.length();
      arrayOfChar2 = new char[j + 1];
      paramString2.getChars(0, j, arrayOfChar2, 0);
    }
    return COM.VtblCall(5, this.address, arrayOfChar1, arrayOfChar2);
  }
  
  public int Unadvise(int paramInt)
  {
    return COM.VtblCall(20, this.address, paramInt);
  }
  
  public int Update()
  {
    return COM.VtblCall(13, this.address);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/internal/ole/win32/IOleObject.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */