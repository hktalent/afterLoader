package org.eclipse.swt.dnd;

import org.eclipse.swt.internal.C;
import org.eclipse.swt.internal.ole.win32.COM;
import org.eclipse.swt.internal.ole.win32.COMObject;
import org.eclipse.swt.internal.ole.win32.FORMATETC;
import org.eclipse.swt.internal.ole.win32.GUID;
import org.eclipse.swt.internal.ole.win32.IDataObject;
import org.eclipse.swt.internal.ole.win32.IEnumFORMATETC;
import org.eclipse.swt.internal.win32.OS;
import org.eclipse.swt.internal.win32.POINT;
import org.eclipse.swt.internal.win32.RECT;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.Tree;
import org.eclipse.swt.widgets.Widget;

public class DropTarget
  extends Widget
{
  Control control;
  Listener controlListener;
  Transfer[] transferAgents = new Transfer[0];
  DropTargetEffect dropEffect;
  TransferData selectedDataType;
  int selectedOperation;
  int keyOperation = -1;
  IDataObject iDataObject;
  COMObject iDropTarget;
  int refCount;
  static final String DEFAULT_DROP_TARGET_EFFECT = "DEFAULT_DROP_TARGET_EFFECT";
  
  public DropTarget(Control paramControl, int paramInt)
  {
    super(paramControl, checkStyle(paramInt));
    this.control = paramControl;
    if (paramControl.getData("DropTarget") != null) {
      DND.error(2001);
    }
    paramControl.setData("DropTarget", this);
    createCOMInterfaces();
    AddRef();
    if (COM.CoLockObjectExternal(this.iDropTarget.getAddress(), true, true) != 0) {
      DND.error(2001);
    }
    if (COM.RegisterDragDrop(paramControl.handle, this.iDropTarget.getAddress()) != 0) {
      DND.error(2001);
    }
    this.controlListener = new Listener()
    {
      public void handleEvent(Event paramAnonymousEvent)
      {
        if (!DropTarget.this.isDisposed()) {
          DropTarget.this.dispose();
        }
      }
    };
    paramControl.addListener(12, this.controlListener);
    addListener(12, new Listener()
    {
      public void handleEvent(Event paramAnonymousEvent)
      {
        DropTarget.this.onDispose();
      }
    });
    Object localObject = paramControl.getData("DEFAULT_DROP_TARGET_EFFECT");
    if ((localObject instanceof DropTargetEffect)) {
      this.dropEffect = ((DropTargetEffect)localObject);
    } else if ((paramControl instanceof Table)) {
      this.dropEffect = new TableDropTargetEffect((Table)paramControl);
    } else if ((paramControl instanceof Tree)) {
      this.dropEffect = new TreeDropTargetEffect((Tree)paramControl);
    }
  }
  
  static int checkStyle(int paramInt)
  {
    if (paramInt == 0) {
      return 2;
    }
    return paramInt;
  }
  
  public void addDropListener(DropTargetListener paramDropTargetListener)
  {
    if (paramDropTargetListener == null) {
      DND.error(4);
    }
    DNDListener localDNDListener = new DNDListener(paramDropTargetListener);
    localDNDListener.dndWidget = this;
    addListener(2002, localDNDListener);
    addListener(2003, localDNDListener);
    addListener(2004, localDNDListener);
    addListener(2005, localDNDListener);
    addListener(2006, localDNDListener);
    addListener(2007, localDNDListener);
  }
  
  int AddRef()
  {
    this.refCount += 1;
    return this.refCount;
  }
  
  protected void checkSubclass()
  {
    String str1 = getClass().getName();
    String str2 = DropTarget.class.getName();
    if (!str2.equals(str1)) {
      DND.error(43);
    }
  }
  
  void createCOMInterfaces()
  {
    int i = C.PTR_SIZEOF == 4 ? 1 : 0;
    this.iDropTarget = new COMObject(new int[] { 2, 0, 0, i != 0 ? 5 : 4, i != 0 ? 4 : 3, 0, i != 0 ? 5 : 4 })
    {
      public long method0(long[] paramAnonymousArrayOfLong)
      {
        return DropTarget.this.QueryInterface(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method1(long[] paramAnonymousArrayOfLong)
      {
        return DropTarget.this.AddRef();
      }
      
      public long method2(long[] paramAnonymousArrayOfLong)
      {
        return DropTarget.this.Release();
      }
      
      public long method3(long[] paramAnonymousArrayOfLong)
      {
        if (paramAnonymousArrayOfLong.length == 5) {
          return DropTarget.this.DragEnter(paramAnonymousArrayOfLong[0], (int)paramAnonymousArrayOfLong[1], (int)paramAnonymousArrayOfLong[2], (int)paramAnonymousArrayOfLong[3], paramAnonymousArrayOfLong[4]);
        }
        return DropTarget.this.DragEnter_64(paramAnonymousArrayOfLong[0], (int)paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2], paramAnonymousArrayOfLong[3]);
      }
      
      public long method4(long[] paramAnonymousArrayOfLong)
      {
        if (paramAnonymousArrayOfLong.length == 4) {
          return DropTarget.this.DragOver((int)paramAnonymousArrayOfLong[0], (int)paramAnonymousArrayOfLong[1], (int)paramAnonymousArrayOfLong[2], paramAnonymousArrayOfLong[3]);
        }
        return DropTarget.this.DragOver_64((int)paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2]);
      }
      
      public long method5(long[] paramAnonymousArrayOfLong)
      {
        return DropTarget.this.DragLeave();
      }
      
      public long method6(long[] paramAnonymousArrayOfLong)
      {
        if (paramAnonymousArrayOfLong.length == 5) {
          return DropTarget.this.Drop(paramAnonymousArrayOfLong[0], (int)paramAnonymousArrayOfLong[1], (int)paramAnonymousArrayOfLong[2], (int)paramAnonymousArrayOfLong[3], paramAnonymousArrayOfLong[4]);
        }
        return DropTarget.this.Drop_64(paramAnonymousArrayOfLong[0], (int)paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2], paramAnonymousArrayOfLong[3]);
      }
    };
  }
  
  void disposeCOMInterfaces()
  {
    if (this.iDropTarget != null) {
      this.iDropTarget.dispose();
    }
    this.iDropTarget = null;
  }
  
  int DragEnter_64(long paramLong1, int paramInt, long paramLong2, long paramLong3)
  {
    POINT localPOINT = new POINT();
    OS.MoveMemory(localPOINT, new long[] { paramLong2 }, 8);
    return DragEnter(paramLong1, paramInt, localPOINT.x, localPOINT.y, paramLong3);
  }
  
  int DragEnter(long paramLong1, int paramInt1, int paramInt2, int paramInt3, long paramLong2)
  {
    this.selectedDataType = null;
    this.selectedOperation = 0;
    if (this.iDataObject != null) {
      this.iDataObject.Release();
    }
    this.iDataObject = null;
    DNDEvent localDNDEvent = new DNDEvent();
    if (!setEventData(localDNDEvent, paramLong1, paramInt1, paramInt2, paramInt3, paramLong2))
    {
      OS.MoveMemory(paramLong2, new int[] { 0 }, 4);
      return 1;
    }
    this.iDataObject = new IDataObject(paramLong1);
    this.iDataObject.AddRef();
    int i = localDNDEvent.operations;
    TransferData[] arrayOfTransferData = new TransferData[localDNDEvent.dataTypes.length];
    System.arraycopy(localDNDEvent.dataTypes, 0, arrayOfTransferData, 0, arrayOfTransferData.length);
    notifyListeners(2002, localDNDEvent);
    refresh();
    if (localDNDEvent.detail == 16) {
      localDNDEvent.detail = ((i & 0x2) != 0 ? 2 : 0);
    }
    this.selectedDataType = null;
    for (int j = 0; j < arrayOfTransferData.length; j++) {
      if (TransferData.sameType(arrayOfTransferData[j], localDNDEvent.dataType))
      {
        this.selectedDataType = arrayOfTransferData[j];
        break;
      }
    }
    this.selectedOperation = 0;
    if ((this.selectedDataType != null) && ((i & localDNDEvent.detail) != 0)) {
      this.selectedOperation = localDNDEvent.detail;
    }
    OS.MoveMemory(paramLong2, new int[] { opToOs(this.selectedOperation) }, 4);
    return 0;
  }
  
  int DragLeave()
  {
    this.keyOperation = -1;
    if (this.iDataObject == null) {
      return 1;
    }
    DNDEvent localDNDEvent = new DNDEvent();
    localDNDEvent.widget = this;
    localDNDEvent.time = OS.GetMessageTime();
    localDNDEvent.detail = 0;
    notifyListeners(2003, localDNDEvent);
    refresh();
    this.iDataObject.Release();
    this.iDataObject = null;
    return 0;
  }
  
  int DragOver_64(int paramInt, long paramLong1, long paramLong2)
  {
    POINT localPOINT = new POINT();
    OS.MoveMemory(localPOINT, new long[] { paramLong1 }, 8);
    return DragOver(paramInt, localPOINT.x, localPOINT.y, paramLong2);
  }
  
  int DragOver(int paramInt1, int paramInt2, int paramInt3, long paramLong)
  {
    if (this.iDataObject == null) {
      return 1;
    }
    int i = this.keyOperation;
    DNDEvent localDNDEvent = new DNDEvent();
    if (!setEventData(localDNDEvent, this.iDataObject.getAddress(), paramInt1, paramInt2, paramInt3, paramLong))
    {
      this.keyOperation = -1;
      OS.MoveMemory(paramLong, new int[] { 0 }, 4);
      return 1;
    }
    int j = localDNDEvent.operations;
    TransferData[] arrayOfTransferData = new TransferData[localDNDEvent.dataTypes.length];
    System.arraycopy(localDNDEvent.dataTypes, 0, arrayOfTransferData, 0, arrayOfTransferData.length);
    if (this.keyOperation == i)
    {
      localDNDEvent.type = 2004;
      localDNDEvent.dataType = this.selectedDataType;
      localDNDEvent.detail = this.selectedOperation;
    }
    else
    {
      localDNDEvent.type = 2005;
      localDNDEvent.dataType = this.selectedDataType;
    }
    notifyListeners(localDNDEvent.type, localDNDEvent);
    refresh();
    if (localDNDEvent.detail == 16) {
      localDNDEvent.detail = ((j & 0x2) != 0 ? 2 : 0);
    }
    this.selectedDataType = null;
    for (int k = 0; k < arrayOfTransferData.length; k++) {
      if (TransferData.sameType(arrayOfTransferData[k], localDNDEvent.dataType))
      {
        this.selectedDataType = arrayOfTransferData[k];
        break;
      }
    }
    this.selectedOperation = 0;
    if ((this.selectedDataType != null) && ((j & localDNDEvent.detail) == localDNDEvent.detail)) {
      this.selectedOperation = localDNDEvent.detail;
    }
    OS.MoveMemory(paramLong, new int[] { opToOs(this.selectedOperation) }, 4);
    return 0;
  }
  
  int Drop_64(long paramLong1, int paramInt, long paramLong2, long paramLong3)
  {
    POINT localPOINT = new POINT();
    OS.MoveMemory(localPOINT, new long[] { paramLong2 }, 8);
    return Drop(paramLong1, paramInt, localPOINT.x, localPOINT.y, paramLong3);
  }
  
  int Drop(long paramLong1, int paramInt1, int paramInt2, int paramInt3, long paramLong2)
  {
    DNDEvent localDNDEvent = new DNDEvent();
    localDNDEvent.widget = this;
    localDNDEvent.time = OS.GetMessageTime();
    if (this.dropEffect != null) {
      localDNDEvent.item = this.dropEffect.getItem(paramInt2, paramInt3);
    }
    localDNDEvent.detail = 0;
    notifyListeners(2003, localDNDEvent);
    refresh();
    localDNDEvent = new DNDEvent();
    if (!setEventData(localDNDEvent, paramLong1, paramInt1, paramInt2, paramInt3, paramLong2))
    {
      this.keyOperation = -1;
      OS.MoveMemory(paramLong2, new int[] { 0 }, 4);
      return 1;
    }
    this.keyOperation = -1;
    int i = localDNDEvent.operations;
    TransferData[] arrayOfTransferData = new TransferData[localDNDEvent.dataTypes.length];
    System.arraycopy(localDNDEvent.dataTypes, 0, arrayOfTransferData, 0, arrayOfTransferData.length);
    localDNDEvent.dataType = this.selectedDataType;
    localDNDEvent.detail = this.selectedOperation;
    notifyListeners(2007, localDNDEvent);
    refresh();
    this.selectedDataType = null;
    for (int j = 0; j < arrayOfTransferData.length; j++) {
      if (TransferData.sameType(arrayOfTransferData[j], localDNDEvent.dataType))
      {
        this.selectedDataType = arrayOfTransferData[j];
        break;
      }
    }
    this.selectedOperation = 0;
    if ((this.selectedDataType != null) && ((i & localDNDEvent.detail) == localDNDEvent.detail)) {
      this.selectedOperation = localDNDEvent.detail;
    }
    if (this.selectedOperation == 0)
    {
      OS.MoveMemory(paramLong2, new int[] { 0 }, 4);
      return 0;
    }
    Object localObject1 = null;
    for (int k = 0; k < this.transferAgents.length; k++)
    {
      Transfer localTransfer = this.transferAgents[k];
      if ((localTransfer != null) && (localTransfer.isSupportedType(this.selectedDataType)))
      {
        localObject1 = localTransfer.nativeToJava(this.selectedDataType);
        break;
      }
    }
    if (localObject1 == null) {
      this.selectedOperation = 0;
    }
    localDNDEvent.detail = this.selectedOperation;
    localDNDEvent.dataType = this.selectedDataType;
    localDNDEvent.data = localObject1;
    OS.ImageList_DragShowNolock(false);
    try
    {
      notifyListeners(2006, localDNDEvent);
    }
    finally
    {
      OS.ImageList_DragShowNolock(true);
    }
    refresh();
    this.selectedOperation = 0;
    if ((i & localDNDEvent.detail) == localDNDEvent.detail) {
      this.selectedOperation = localDNDEvent.detail;
    }
    OS.MoveMemory(paramLong2, new int[] { opToOs(this.selectedOperation) }, 4);
    return 0;
  }
  
  public Control getControl()
  {
    return this.control;
  }
  
  public DropTargetListener[] getDropListeners()
  {
    Listener[] arrayOfListener = getListeners(2002);
    int i = arrayOfListener.length;
    DropTargetListener[] arrayOfDropTargetListener1 = new DropTargetListener[i];
    int j = 0;
    for (int k = 0; k < i; k++)
    {
      Listener localListener = arrayOfListener[k];
      if ((localListener instanceof DNDListener))
      {
        arrayOfDropTargetListener1[j] = ((DropTargetListener)((DNDListener)localListener).getEventListener());
        j++;
      }
    }
    if (j == i) {
      return arrayOfDropTargetListener1;
    }
    DropTargetListener[] arrayOfDropTargetListener2 = new DropTargetListener[j];
    System.arraycopy(arrayOfDropTargetListener1, 0, arrayOfDropTargetListener2, 0, j);
    return arrayOfDropTargetListener2;
  }
  
  public DropTargetEffect getDropTargetEffect()
  {
    return this.dropEffect;
  }
  
  int getOperationFromKeyState(int paramInt)
  {
    int i = (paramInt & 0x8) != 0 ? 1 : 0;
    int j = (paramInt & 0x4) != 0 ? 1 : 0;
    int k = (paramInt & 0x20) != 0 ? 1 : 0;
    if (k != 0)
    {
      if ((i != 0) || (j != 0)) {
        return 16;
      }
      return 4;
    }
    if ((i != 0) && (j != 0)) {
      return 4;
    }
    if (i != 0) {
      return 1;
    }
    if (j != 0) {
      return 2;
    }
    return 16;
  }
  
  public Transfer[] getTransfer()
  {
    return this.transferAgents;
  }
  
  void onDispose()
  {
    if (this.control == null) {
      return;
    }
    COM.RevokeDragDrop(this.control.handle);
    if (this.controlListener != null) {
      this.control.removeListener(12, this.controlListener);
    }
    this.controlListener = null;
    this.control.setData("DropTarget", null);
    this.transferAgents = null;
    this.control = null;
    COM.CoLockObjectExternal(this.iDropTarget.getAddress(), false, true);
    Release();
    if (this.iDataObject != null) {
      this.iDataObject.Release();
    }
    this.iDataObject = null;
    if (COM.FreeUnusedLibraries) {
      COM.CoFreeUnusedLibraries();
    }
  }
  
  int opToOs(int paramInt)
  {
    int i = 0;
    if ((paramInt & 0x1) != 0) {
      i |= 0x1;
    }
    if ((paramInt & 0x4) != 0) {
      i |= 0x4;
    }
    if ((paramInt & 0x2) != 0) {
      i |= 0x2;
    }
    return i;
  }
  
  int osToOp(int paramInt)
  {
    int i = 0;
    if ((paramInt & 0x1) != 0) {
      i |= 0x1;
    }
    if ((paramInt & 0x4) != 0) {
      i |= 0x4;
    }
    if ((paramInt & 0x2) != 0) {
      i |= 0x2;
    }
    return i;
  }
  
  int QueryInterface(long paramLong1, long paramLong2)
  {
    if ((paramLong1 == 0L) || (paramLong2 == 0L)) {
      return -2147024809;
    }
    GUID localGUID = new GUID();
    COM.MoveMemory(localGUID, paramLong1, GUID.sizeof);
    if ((COM.IsEqualGUID(localGUID, COM.IIDIUnknown)) || (COM.IsEqualGUID(localGUID, COM.IIDIDropTarget)))
    {
      COM.MoveMemory(paramLong2, new long[] { this.iDropTarget.getAddress() }, OS.PTR_SIZEOF);
      AddRef();
      return 0;
    }
    COM.MoveMemory(paramLong2, new long[] { 0L }, OS.PTR_SIZEOF);
    return -2147467262;
  }
  
  int Release()
  {
    this.refCount -= 1;
    if (this.refCount == 0)
    {
      disposeCOMInterfaces();
      if (COM.FreeUnusedLibraries) {
        COM.CoFreeUnusedLibraries();
      }
    }
    return this.refCount;
  }
  
  void refresh()
  {
    if ((this.control == null) || (this.control.isDisposed())) {
      return;
    }
    long l = this.control.handle;
    RECT localRECT = new RECT();
    if (OS.GetUpdateRect(l, localRECT, false))
    {
      OS.ImageList_DragShowNolock(false);
      OS.RedrawWindow(l, localRECT, 0L, 257);
      OS.ImageList_DragShowNolock(true);
    }
  }
  
  public void removeDropListener(DropTargetListener paramDropTargetListener)
  {
    if (paramDropTargetListener == null) {
      DND.error(4);
    }
    removeListener(2002, paramDropTargetListener);
    removeListener(2003, paramDropTargetListener);
    removeListener(2004, paramDropTargetListener);
    removeListener(2005, paramDropTargetListener);
    removeListener(2006, paramDropTargetListener);
    removeListener(2007, paramDropTargetListener);
  }
  
  public void setDropTargetEffect(DropTargetEffect paramDropTargetEffect)
  {
    this.dropEffect = paramDropTargetEffect;
  }
  
  boolean setEventData(DNDEvent paramDNDEvent, long paramLong1, int paramInt1, int paramInt2, int paramInt3, long paramLong2)
  {
    if ((paramLong1 == 0L) || (paramLong2 == 0L)) {
      return false;
    }
    int i = getStyle();
    int[] arrayOfInt1 = new int[1];
    OS.MoveMemory(arrayOfInt1, paramLong2, 4);
    arrayOfInt1[0] = (osToOp(arrayOfInt1[0]) & i);
    if (arrayOfInt1[0] == 0) {
      return false;
    }
    int j = getOperationFromKeyState(paramInt1);
    this.keyOperation = j;
    if (j == 16)
    {
      if ((i & 0x10) == 0) {
        j = (arrayOfInt1[0] & 0x2) != 0 ? 2 : 0;
      }
    }
    else if ((j & arrayOfInt1[0]) == 0) {
      j = 0;
    }
    Object localObject1 = new TransferData[0];
    IDataObject localIDataObject = new IDataObject(paramLong1);
    localIDataObject.AddRef();
    try
    {
      long[] arrayOfLong = new long[1];
      if (localIDataObject.EnumFormatEtc(1, arrayOfLong) != 0)
      {
        boolean bool = false;
        return bool;
      }
      IEnumFORMATETC localIEnumFORMATETC = new IEnumFORMATETC(arrayOfLong[0]);
      try
      {
        long l = OS.GlobalAlloc(64, FORMATETC.sizeof);
        try
        {
          int[] arrayOfInt2 = new int[1];
          localIEnumFORMATETC.Reset();
          while ((localIEnumFORMATETC.Next(1, l, arrayOfInt2) == 0) && (arrayOfInt2[0] == 1))
          {
            TransferData localTransferData = new TransferData();
            localTransferData.formatetc = new FORMATETC();
            COM.MoveMemory(localTransferData.formatetc, l, FORMATETC.sizeof);
            localTransferData.type = localTransferData.formatetc.cfFormat;
            localTransferData.pIDataObject = paramLong1;
            for (int k = 0; k < this.transferAgents.length; k++)
            {
              Transfer localTransfer = this.transferAgents[k];
              if ((localTransfer != null) && (localTransfer.isSupportedType(localTransferData)))
              {
                TransferData[] arrayOfTransferData = new TransferData[localObject1.length + 1];
                System.arraycopy(localObject1, 0, arrayOfTransferData, 0, localObject1.length);
                arrayOfTransferData[localObject1.length] = localTransferData;
                localObject1 = arrayOfTransferData;
                break;
              }
            }
          }
        }
        finally
        {
          OS.GlobalFree(l);
        }
      }
      finally
      {
        localIEnumFORMATETC.Release();
      }
    }
    finally
    {
      localIDataObject.Release();
    }
    if (localObject1.length == 0) {
      return false;
    }
    paramDNDEvent.widget = this;
    paramDNDEvent.x = paramInt2;
    paramDNDEvent.y = paramInt3;
    paramDNDEvent.time = OS.GetMessageTime();
    paramDNDEvent.feedback = 1;
    paramDNDEvent.dataTypes = ((TransferData[])localObject1);
    paramDNDEvent.dataType = localObject1[0];
    if (this.dropEffect != null) {
      paramDNDEvent.item = this.dropEffect.getItem(paramInt2, paramInt3);
    }
    paramDNDEvent.operations = arrayOfInt1[0];
    paramDNDEvent.detail = j;
    return true;
  }
  
  public void setTransfer(Transfer[] paramArrayOfTransfer)
  {
    if (paramArrayOfTransfer == null) {
      DND.error(4);
    }
    this.transferAgents = paramArrayOfTransfer;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/dnd/DropTarget.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */