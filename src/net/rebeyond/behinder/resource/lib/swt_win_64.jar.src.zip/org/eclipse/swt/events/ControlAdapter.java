package org.eclipse.swt.events;

public abstract class ControlAdapter
  implements ControlListener
{
  public void controlMoved(ControlEvent paramControlEvent) {}
  
  public void controlResized(ControlEvent paramControlEvent) {}
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/events/ControlAdapter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */