package org.eclipse.swt.internal.mozilla;

public class nsIRequest
  extends nsISupports
{
  static final int LAST_METHOD_ID = nsISupports.LAST_METHOD_ID + 10;
  static final String NS_IREQUEST_IID_STR = "ef6bfbd2-fd46-48d8-96b7-9f8f0fd387fe";
  public static final int LOAD_NORMAL = 0;
  public static final int LOAD_BACKGROUND = 1;
  public static final int INHIBIT_CACHING = 128;
  public static final int INHIBIT_PERSISTENT_CACHING = 256;
  public static final int LOAD_BYPASS_CACHE = 512;
  public static final int LOAD_FROM_CACHE = 1024;
  public static final int VALIDATE_ALWAYS = 2048;
  public static final int VALIDATE_NEVER = 4096;
  public static final int VALIDATE_ONCE_PER_SESSION = 8192;
  
  public nsIRequest(long paramLong)
  {
    super(paramLong);
  }
  
  public int GetName(long paramLong)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 1, getAddress(), paramLong);
  }
  
  static
  {
    IIDStore.RegisterIID(nsIRequest.class, 0, new nsID("ef6bfbd2-fd46-48d8-96b7-9f8f0fd387fe"));
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/internal/mozilla/nsIRequest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */