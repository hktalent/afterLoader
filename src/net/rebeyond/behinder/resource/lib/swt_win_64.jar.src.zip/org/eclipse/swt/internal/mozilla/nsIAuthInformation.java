package org.eclipse.swt.internal.mozilla;

public class nsIAuthInformation
  extends nsISupports
{
  static final int LAST_METHOD_ID = nsISupports.LAST_METHOD_ID + 9;
  static final String NS_IAUTHINFORMATION_IID_STR = "0d73639c-2a92-4518-9f92-28f71fea5f20";
  public static final int AUTH_HOST = 1;
  public static final int AUTH_PROXY = 2;
  public static final int NEED_DOMAIN = 4;
  public static final int ONLY_PASSWORD = 8;
  
  public nsIAuthInformation(long paramLong)
  {
    super(paramLong);
  }
  
  public int GetRealm(long paramLong)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 2, getAddress(), paramLong);
  }
  
  public int GetUsername(long paramLong)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 4, getAddress(), paramLong);
  }
  
  public int SetUsername(long paramLong)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 5, getAddress(), paramLong);
  }
  
  public int GetPassword(long paramLong)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 6, getAddress(), paramLong);
  }
  
  public int SetPassword(long paramLong)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 7, getAddress(), paramLong);
  }
  
  static
  {
    IIDStore.RegisterIID(nsIAuthInformation.class, 0, new nsID("0d73639c-2a92-4518-9f92-28f71fea5f20"));
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/internal/mozilla/nsIAuthInformation.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */