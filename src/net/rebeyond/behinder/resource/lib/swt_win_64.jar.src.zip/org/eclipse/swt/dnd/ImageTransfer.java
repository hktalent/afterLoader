package org.eclipse.swt.dnd;

import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.ImageData;
import org.eclipse.swt.graphics.PaletteData;
import org.eclipse.swt.graphics.RGB;
import org.eclipse.swt.internal.ole.win32.STGMEDIUM;
import org.eclipse.swt.internal.win32.BITMAPINFOHEADER;
import org.eclipse.swt.internal.win32.OS;

public class ImageTransfer
  extends ByteArrayTransfer
{
  private static ImageTransfer _instance = new ImageTransfer();
  private static final String CF_DIB = "CF_DIB";
  private static final int CF_DIBID = 8;
  
  public static ImageTransfer getInstance()
  {
    return _instance;
  }
  
  public void javaToNative(Object paramObject, TransferData paramTransferData)
  {
    if ((!checkImage(paramObject)) || (!isSupportedType(paramTransferData))) {
      DND.error(2003);
    }
    ImageData localImageData = (ImageData)paramObject;
    if (localImageData == null) {
      SWT.error(4);
    }
    int i = localImageData.data.length;
    int j = localImageData.height;
    int k = localImageData.bytesPerLine;
    BITMAPINFOHEADER localBITMAPINFOHEADER = new BITMAPINFOHEADER();
    localBITMAPINFOHEADER.biSize = BITMAPINFOHEADER.sizeof;
    localBITMAPINFOHEADER.biSizeImage = i;
    localBITMAPINFOHEADER.biWidth = localImageData.width;
    localBITMAPINFOHEADER.biHeight = j;
    localBITMAPINFOHEADER.biPlanes = 1;
    localBITMAPINFOHEADER.biBitCount = ((short)localImageData.depth);
    localBITMAPINFOHEADER.biCompression = 0;
    int m = 0;
    if (localBITMAPINFOHEADER.biBitCount <= 8) {
      m += (1 << localBITMAPINFOHEADER.biBitCount) * 4;
    }
    byte[] arrayOfByte1 = new byte[BITMAPINFOHEADER.sizeof + m];
    OS.MoveMemory(arrayOfByte1, localBITMAPINFOHEADER, BITMAPINFOHEADER.sizeof);
    RGB[] arrayOfRGB = localImageData.palette.getRGBs();
    if ((arrayOfRGB != null) && (m > 0))
    {
      int n = BITMAPINFOHEADER.sizeof;
      for (int i1 = 0; i1 < arrayOfRGB.length; i1++)
      {
        arrayOfByte1[n] = ((byte)arrayOfRGB[i1].blue);
        arrayOfByte1[(n + 1)] = ((byte)arrayOfRGB[i1].green);
        arrayOfByte1[(n + 2)] = ((byte)arrayOfRGB[i1].red);
        arrayOfByte1[(n + 3)] = 0;
        n += 4;
      }
    }
    long l1 = OS.GlobalAlloc(64, BITMAPINFOHEADER.sizeof + m + i);
    OS.MoveMemory(l1, arrayOfByte1, arrayOfByte1.length);
    long l2 = l1 + BITMAPINFOHEADER.sizeof + m;
    if (j <= 0)
    {
      OS.MoveMemory(l2, localImageData.data, i);
    }
    else
    {
      int i2 = 0;
      l2 += k * (j - 1);
      byte[] arrayOfByte2 = new byte[k];
      for (int i3 = 0; i3 < j; i3++)
      {
        System.arraycopy(localImageData.data, i2, arrayOfByte2, 0, k);
        OS.MoveMemory(l2, arrayOfByte2, k);
        i2 += k;
        l2 -= k;
      }
    }
    paramTransferData.stgmedium = new STGMEDIUM();
    paramTransferData.stgmedium.tymed = 1;
    paramTransferData.stgmedium.unionField = l1;
    paramTransferData.stgmedium.pUnkForRelease = 0L;
    paramTransferData.result = 0;
  }
  
  /* Error */
  public Object nativeToJava(TransferData paramTransferData)
  {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: invokevirtual 4	org/eclipse/swt/dnd/ImageTransfer:isSupportedType	(Lorg/eclipse/swt/dnd/TransferData;)Z
    //   5: ifeq +12 -> 17
    //   8: aload_1
    //   9: getfield 39	org/eclipse/swt/dnd/TransferData:pIDataObject	J
    //   12: lconst_0
    //   13: lcmp
    //   14: ifne +5 -> 19
    //   17: aconst_null
    //   18: areturn
    //   19: new 40	org/eclipse/swt/internal/ole/win32/IDataObject
    //   22: dup
    //   23: aload_1
    //   24: getfield 39	org/eclipse/swt/dnd/TransferData:pIDataObject	J
    //   27: invokespecial 41	org/eclipse/swt/internal/ole/win32/IDataObject:<init>	(J)V
    //   30: astore_2
    //   31: aload_2
    //   32: invokevirtual 42	org/eclipse/swt/internal/ole/win32/IDataObject:AddRef	()I
    //   35: pop
    //   36: new 43	org/eclipse/swt/internal/ole/win32/FORMATETC
    //   39: dup
    //   40: invokespecial 44	org/eclipse/swt/internal/ole/win32/FORMATETC:<init>	()V
    //   43: astore_3
    //   44: aload_3
    //   45: bipush 8
    //   47: putfield 45	org/eclipse/swt/internal/ole/win32/FORMATETC:cfFormat	I
    //   50: aload_3
    //   51: lconst_0
    //   52: putfield 46	org/eclipse/swt/internal/ole/win32/FORMATETC:ptd	J
    //   55: aload_3
    //   56: iconst_1
    //   57: putfield 47	org/eclipse/swt/internal/ole/win32/FORMATETC:dwAspect	I
    //   60: aload_3
    //   61: iconst_m1
    //   62: putfield 48	org/eclipse/swt/internal/ole/win32/FORMATETC:lindex	I
    //   65: aload_3
    //   66: iconst_1
    //   67: putfield 49	org/eclipse/swt/internal/ole/win32/FORMATETC:tymed	I
    //   70: new 32	org/eclipse/swt/internal/ole/win32/STGMEDIUM
    //   73: dup
    //   74: invokespecial 33	org/eclipse/swt/internal/ole/win32/STGMEDIUM:<init>	()V
    //   77: astore 4
    //   79: aload 4
    //   81: iconst_1
    //   82: putfield 35	org/eclipse/swt/internal/ole/win32/STGMEDIUM:tymed	I
    //   85: aload_1
    //   86: aload_0
    //   87: aload_2
    //   88: aload_3
    //   89: aload 4
    //   91: invokevirtual 50	org/eclipse/swt/dnd/ImageTransfer:getData	(Lorg/eclipse/swt/internal/ole/win32/IDataObject;Lorg/eclipse/swt/internal/ole/win32/FORMATETC;Lorg/eclipse/swt/internal/ole/win32/STGMEDIUM;)I
    //   94: putfield 38	org/eclipse/swt/dnd/TransferData:result	I
    //   97: aload_1
    //   98: getfield 38	org/eclipse/swt/dnd/TransferData:result	I
    //   101: ifeq +5 -> 106
    //   104: aconst_null
    //   105: areturn
    //   106: aload 4
    //   108: getfield 36	org/eclipse/swt/internal/ole/win32/STGMEDIUM:unionField	J
    //   111: lstore 5
    //   113: aload_2
    //   114: invokevirtual 51	org/eclipse/swt/internal/ole/win32/IDataObject:Release	()I
    //   117: pop
    //   118: lload 5
    //   120: invokestatic 52	org/eclipse/swt/internal/win32/OS:GlobalLock	(J)J
    //   123: lstore 7
    //   125: lload 7
    //   127: lconst_0
    //   128: lcmp
    //   129: ifne +12 -> 141
    //   132: aconst_null
    //   133: astore 9
    //   135: jsr +314 -> 449
    //   138: aload 9
    //   140: areturn
    //   141: new 11	org/eclipse/swt/internal/win32/BITMAPINFOHEADER
    //   144: dup
    //   145: invokespecial 12	org/eclipse/swt/internal/win32/BITMAPINFOHEADER:<init>	()V
    //   148: astore 9
    //   150: aload 9
    //   152: lload 7
    //   154: getstatic 13	org/eclipse/swt/internal/win32/BITMAPINFOHEADER:sizeof	I
    //   157: invokestatic 53	org/eclipse/swt/internal/win32/OS:MoveMemory	(Lorg/eclipse/swt/internal/win32/BITMAPINFOHEADER;JI)V
    //   160: iconst_1
    //   161: newarray <illegal type>
    //   163: astore 10
    //   165: lconst_0
    //   166: lload 7
    //   168: iconst_0
    //   169: aload 10
    //   171: lconst_0
    //   172: iconst_0
    //   173: invokestatic 54	org/eclipse/swt/internal/win32/OS:CreateDIBSection	(JJI[JJI)J
    //   176: lstore 11
    //   178: lload 11
    //   180: lconst_0
    //   181: lcmp
    //   182: ifne +7 -> 189
    //   185: iconst_2
    //   186: invokestatic 7	org/eclipse/swt/SWT:error	(I)V
    //   189: lload 7
    //   191: aload 9
    //   193: getfield 14	org/eclipse/swt/internal/win32/BITMAPINFOHEADER:biSize	I
    //   196: i2l
    //   197: ladd
    //   198: lstore 13
    //   200: aload 9
    //   202: getfield 21	org/eclipse/swt/internal/win32/BITMAPINFOHEADER:biBitCount	S
    //   205: bipush 8
    //   207: if_icmpgt +37 -> 244
    //   210: lload 13
    //   212: aload 9
    //   214: getfield 55	org/eclipse/swt/internal/win32/BITMAPINFOHEADER:biClrUsed	I
    //   217: ifne +13 -> 230
    //   220: iconst_1
    //   221: aload 9
    //   223: getfield 21	org/eclipse/swt/internal/win32/BITMAPINFOHEADER:biBitCount	S
    //   226: ishl
    //   227: goto +8 -> 235
    //   230: aload 9
    //   232: getfield 55	org/eclipse/swt/internal/win32/BITMAPINFOHEADER:biClrUsed	I
    //   235: iconst_4
    //   236: imul
    //   237: i2l
    //   238: ladd
    //   239: lstore 13
    //   241: goto +20 -> 261
    //   244: aload 9
    //   246: getfield 22	org/eclipse/swt/internal/win32/BITMAPINFOHEADER:biCompression	I
    //   249: iconst_3
    //   250: if_icmpne +11 -> 261
    //   253: lload 13
    //   255: ldc2_w 56
    //   258: ladd
    //   259: lstore 13
    //   261: aload 9
    //   263: getfield 18	org/eclipse/swt/internal/win32/BITMAPINFOHEADER:biHeight	I
    //   266: ifge +20 -> 286
    //   269: aload 10
    //   271: iconst_0
    //   272: laload
    //   273: lload 13
    //   275: aload 9
    //   277: getfield 15	org/eclipse/swt/internal/win32/BITMAPINFOHEADER:biSizeImage	I
    //   280: invokestatic 58	org/eclipse/swt/internal/win32/OS:MoveMemory	(JJI)V
    //   283: goto +100 -> 383
    //   286: new 59	org/eclipse/swt/internal/win32/DIBSECTION
    //   289: dup
    //   290: invokespecial 60	org/eclipse/swt/internal/win32/DIBSECTION:<init>	()V
    //   293: astore 15
    //   295: lload 11
    //   297: getstatic 61	org/eclipse/swt/internal/win32/DIBSECTION:sizeof	I
    //   300: aload 15
    //   302: invokestatic 62	org/eclipse/swt/internal/win32/OS:GetObject	(JILorg/eclipse/swt/internal/win32/DIBSECTION;)I
    //   305: pop
    //   306: aload 15
    //   308: getfield 63	org/eclipse/swt/internal/win32/DIBSECTION:biHeight	I
    //   311: istore 16
    //   313: aload 15
    //   315: getfield 64	org/eclipse/swt/internal/win32/DIBSECTION:biSizeImage	I
    //   318: iload 16
    //   320: idiv
    //   321: istore 17
    //   323: aload 10
    //   325: iconst_0
    //   326: laload
    //   327: lstore 18
    //   329: lload 13
    //   331: iload 17
    //   333: iload 16
    //   335: iconst_1
    //   336: isub
    //   337: imul
    //   338: i2l
    //   339: ladd
    //   340: lstore 20
    //   342: iconst_0
    //   343: istore 22
    //   345: iload 22
    //   347: iload 16
    //   349: if_icmpge +34 -> 383
    //   352: lload 18
    //   354: lload 20
    //   356: iload 17
    //   358: invokestatic 58	org/eclipse/swt/internal/win32/OS:MoveMemory	(JJI)V
    //   361: lload 18
    //   363: iload 17
    //   365: i2l
    //   366: ladd
    //   367: lstore 18
    //   369: lload 20
    //   371: iload 17
    //   373: i2l
    //   374: lsub
    //   375: lstore 20
    //   377: iinc 22 1
    //   380: goto -35 -> 345
    //   383: aconst_null
    //   384: iconst_0
    //   385: lload 11
    //   387: invokestatic 65	org/eclipse/swt/graphics/Image:win32_new	(Lorg/eclipse/swt/graphics/Device;IJ)Lorg/eclipse/swt/graphics/Image;
    //   390: astore 15
    //   392: aload 15
    //   394: invokevirtual 66	org/eclipse/swt/graphics/Image:getImageData	()Lorg/eclipse/swt/graphics/ImageData;
    //   397: astore 16
    //   399: lload 11
    //   401: invokestatic 67	org/eclipse/swt/internal/win32/OS:DeleteObject	(J)Z
    //   404: pop
    //   405: aload 15
    //   407: invokevirtual 68	org/eclipse/swt/graphics/Image:dispose	()V
    //   410: aload 16
    //   412: astore 17
    //   414: jsr +17 -> 431
    //   417: jsr +32 -> 449
    //   420: aload 17
    //   422: areturn
    //   423: astore 23
    //   425: jsr +6 -> 431
    //   428: aload 23
    //   430: athrow
    //   431: astore 24
    //   433: lload 5
    //   435: invokestatic 69	org/eclipse/swt/internal/win32/OS:GlobalUnlock	(J)Z
    //   438: pop
    //   439: ret 24
    //   441: astore 25
    //   443: jsr +6 -> 449
    //   446: aload 25
    //   448: athrow
    //   449: astore 26
    //   451: lload 5
    //   453: invokestatic 70	org/eclipse/swt/internal/win32/OS:GlobalFree	(J)J
    //   456: pop2
    //   457: ret 26
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	459	0	this	ImageTransfer
    //   0	459	1	paramTransferData	TransferData
    //   30	84	2	localIDataObject	org.eclipse.swt.internal.ole.win32.IDataObject
    //   43	46	3	localFORMATETC	org.eclipse.swt.internal.ole.win32.FORMATETC
    //   77	30	4	localSTGMEDIUM	STGMEDIUM
    //   111	341	5	l1	long
    //   123	67	7	l2	long
    //   133	143	9	localObject1	Object
    //   163	161	10	arrayOfLong	long[]
    //   176	224	11	l3	long
    //   198	132	13	l4	long
    //   293	113	15	localObject2	Object
    //   311	39	16	i	int
    //   397	14	16	localImageData1	ImageData
    //   321	51	17	j	int
    //   412	9	17	localImageData2	ImageData
    //   327	41	18	l5	long
    //   340	36	20	l6	long
    //   343	35	22	k	int
    //   423	6	23	localObject3	Object
    //   431	1	24	localObject4	Object
    //   441	6	25	localObject5	Object
    //   449	1	26	localObject6	Object
    // Exception table:
    //   from	to	target	type
    //   141	417	423	finally
    //   423	428	423	finally
    //   118	138	441	finally
    //   141	420	441	finally
    //   423	446	441	finally
  }
  
  protected int[] getTypeIds()
  {
    return new int[] { 8 };
  }
  
  protected String[] getTypeNames()
  {
    return new String[] { "CF_DIB" };
  }
  
  boolean checkImage(Object paramObject)
  {
    return (paramObject != null) && ((paramObject instanceof ImageData));
  }
  
  protected boolean validate(Object paramObject)
  {
    return checkImage(paramObject);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/dnd/ImageTransfer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */