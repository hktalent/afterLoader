package org.eclipse.swt.browser;

import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Enumeration;
import java.util.Hashtable;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.internal.Compatibility;
import org.eclipse.swt.internal.ole.win32.COM;
import org.eclipse.swt.internal.ole.win32.COMObject;
import org.eclipse.swt.internal.ole.win32.GUID;
import org.eclipse.swt.internal.ole.win32.IUnknown;
import org.eclipse.swt.internal.webkit.IWebDataSource;
import org.eclipse.swt.internal.webkit.IWebError;
import org.eclipse.swt.internal.webkit.IWebErrorPrivate;
import org.eclipse.swt.internal.webkit.IWebFrame;
import org.eclipse.swt.internal.webkit.IWebMutableURLRequest;
import org.eclipse.swt.internal.webkit.IWebURLRequest;
import org.eclipse.swt.internal.webkit.IWebView;
import org.eclipse.swt.internal.webkit.WebKit_win32;
import org.eclipse.swt.internal.win32.CERT_CONTEXT;
import org.eclipse.swt.internal.win32.CERT_INFO;
import org.eclipse.swt.internal.win32.CRYPT_INTEGER_BLOB;
import org.eclipse.swt.internal.win32.OS;
import org.eclipse.swt.internal.win32.SYSTEMTIME;
import org.eclipse.swt.internal.win32.TCHAR;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.Monitor;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.TabFolder;
import org.eclipse.swt.widgets.TabItem;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;

class WebFrameLoadDelegate
{
  COMObject iWebFrameLoadDelegate;
  int refCount = 0;
  Browser browser;
  String html;
  String url;
  static final String OBJECTNAME_EXTERNAL = "external";
  
  WebFrameLoadDelegate(Browser paramBrowser)
  {
    createCOMInterfaces();
    this.browser = paramBrowser;
  }
  
  void addEventHandlers(boolean paramBoolean)
  {
    StringBuffer localStringBuffer;
    if (paramBoolean)
    {
      localStringBuffer = new StringBuffer("window.SWTkeyhandler = function SWTkeyhandler(e) {");
      localStringBuffer.append("try {e.returnValue = HandleWebKitEvent(e.type, e.keyCode, e.charCode, e.altKey, e.ctrlKey, e.shiftKey, e.metaKey);} catch (e) {}};");
      localStringBuffer.append("document.addEventListener('keydown', SWTkeyhandler, true);");
      localStringBuffer.append("document.addEventListener('keypress', SWTkeyhandler, true);");
      localStringBuffer.append("document.addEventListener('keyup', SWTkeyhandler, true);");
      this.browser.execute(localStringBuffer.toString());
      localStringBuffer = new StringBuffer("window.SWTmousehandler = function SWTmousehandler(e) {");
      localStringBuffer.append("try {e.returnValue = HandleWebKitEvent(e.type, e.screenX, e.screenY, e.detail, e.button + 1, e.altKey, e.ctrlKey, e.shiftKey, e.metaKey, e.relatedTarget != null);} catch (e) {}};");
      localStringBuffer.append("document.addEventListener('mousedown', SWTmousehandler, true);");
      localStringBuffer.append("document.addEventListener('mouseup', SWTmousehandler, true);");
      localStringBuffer.append("document.addEventListener('mousemove', SWTmousehandler, true);");
      localStringBuffer.append("document.addEventListener('mousewheel', SWTmousehandler, true);");
      localStringBuffer.append("document.addEventListener('dragstart', SWTmousehandler, true);");
      localStringBuffer.append("document.addEventListener('mouseover', SWTmousehandler, true);");
      localStringBuffer.append("document.addEventListener('mouseout', SWTmousehandler, true);");
      this.browser.execute(localStringBuffer.toString());
    }
    else
    {
      localStringBuffer = new StringBuffer("for (var i = 0; i < frames.length; i++) {");
      localStringBuffer.append("frames[i].document.addEventListener('keydown', window.SWTkeyhandler, true);");
      localStringBuffer.append("frames[i].document.addEventListener('keypress', window.SWTkeyhandler, true);");
      localStringBuffer.append("frames[i].document.addEventListener('keyup', window.SWTkeyhandler, true);");
      localStringBuffer.append("frames[i].document.addEventListener('mousedown', window.SWTmousehandler, true);");
      localStringBuffer.append("frames[i].document.addEventListener('mouseup', window.SWTmousehandler, true);");
      localStringBuffer.append("frames[i].document.addEventListener('mousemove', window.SWTmousehandler, true);");
      localStringBuffer.append("frames[i].document.addEventListener('mouseover', window.SWTmousehandler, true);");
      localStringBuffer.append("frames[i].document.addEventListener('mouseout', window.SWTmousehandler, true);");
      localStringBuffer.append("frames[i].document.addEventListener('mousewheel', window.SWTmousehandler, true);");
      localStringBuffer.append("frames[i].document.addEventListener('dragstart', window.SWTmousehandler, true);");
      localStringBuffer.append('}');
      this.browser.execute(localStringBuffer.toString());
    }
  }
  
  int AddRef()
  {
    this.refCount += 1;
    return this.refCount;
  }
  
  void createCOMInterfaces()
  {
    this.iWebFrameLoadDelegate = new COMObject(new int[] { 2, 0, 0, 2, 2, 3, 2, 3, 3, 2, 3, 2, 5, 2, 2, 3, 4 })
    {
      public long method0(long[] paramAnonymousArrayOfLong)
      {
        return WebFrameLoadDelegate.this.QueryInterface(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method1(long[] paramAnonymousArrayOfLong)
      {
        return WebFrameLoadDelegate.this.AddRef();
      }
      
      public long method2(long[] paramAnonymousArrayOfLong)
      {
        return WebFrameLoadDelegate.this.Release();
      }
      
      public long method3(long[] paramAnonymousArrayOfLong)
      {
        return WebFrameLoadDelegate.this.didStartProvisionalLoadForFrame(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method4(long[] paramAnonymousArrayOfLong)
      {
        return -2147467263L;
      }
      
      public long method5(long[] paramAnonymousArrayOfLong)
      {
        return WebFrameLoadDelegate.this.didFailProvisionalLoadWithError(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2]);
      }
      
      public long method6(long[] paramAnonymousArrayOfLong)
      {
        return WebFrameLoadDelegate.this.didCommitLoadForFrame(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method7(long[] paramAnonymousArrayOfLong)
      {
        return WebFrameLoadDelegate.this.didReceiveTitle(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2]);
      }
      
      public long method8(long[] paramAnonymousArrayOfLong)
      {
        return -2147467263L;
      }
      
      public long method9(long[] paramAnonymousArrayOfLong)
      {
        return WebFrameLoadDelegate.this.didFinishLoadForFrame(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method10(long[] paramAnonymousArrayOfLong)
      {
        return -2147467263L;
      }
      
      public long method11(long[] paramAnonymousArrayOfLong)
      {
        return WebFrameLoadDelegate.this.didChangeLocationWithinPageForFrame(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method12(long[] paramAnonymousArrayOfLong)
      {
        return 0L;
      }
      
      public long method13(long[] paramAnonymousArrayOfLong)
      {
        return -2147467263L;
      }
      
      public long method14(long[] paramAnonymousArrayOfLong)
      {
        return 0L;
      }
      
      public long method15(long[] paramAnonymousArrayOfLong)
      {
        return 0L;
      }
      
      public long method16(long[] paramAnonymousArrayOfLong)
      {
        return WebFrameLoadDelegate.this.didClearWindowObject(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2], paramAnonymousArrayOfLong[3]);
      }
    };
    long l = this.iWebFrameLoadDelegate.ppVtable;
    long[] arrayOfLong1 = new long[1];
    COM.MoveMemory(arrayOfLong1, l, OS.PTR_SIZEOF);
    long[] arrayOfLong2 = new long[17];
    COM.MoveMemory(arrayOfLong2, arrayOfLong1[0], OS.PTR_SIZEOF * arrayOfLong2.length);
    arrayOfLong2[12] = WebKit_win32.willPerformClientRedirectToURL_CALLBACK(arrayOfLong2[12]);
    COM.MoveMemory(arrayOfLong1[0], arrayOfLong2, OS.PTR_SIZEOF * arrayOfLong2.length);
  }
  
  int didChangeLocationWithinPageForFrame(long paramLong1, long paramLong2)
  {
    IWebFrame localIWebFrame = new IWebFrame(paramLong2);
    long[] arrayOfLong = new long[1];
    int i = localIWebFrame.dataSource(arrayOfLong);
    if ((i != 0) || (arrayOfLong[0] == 0L)) {
      return 0;
    }
    IWebDataSource localIWebDataSource = new IWebDataSource(arrayOfLong[0]);
    arrayOfLong[0] = 0L;
    i = localIWebDataSource.request(arrayOfLong);
    localIWebDataSource.Release();
    if ((i != 0) || (arrayOfLong[0] == 0L)) {
      return 0;
    }
    IWebURLRequest localIWebURLRequest = new IWebURLRequest(arrayOfLong[0]);
    arrayOfLong[0] = 0L;
    i = localIWebURLRequest.URL(arrayOfLong);
    localIWebURLRequest.Release();
    if ((i != 0) || (arrayOfLong[0] == 0L)) {
      return 0;
    }
    String str = WebKit.extractBSTR(arrayOfLong[0]);
    COM.SysFreeString(arrayOfLong[0]);
    if (str.length() == 0) {
      return 0;
    }
    if (str.equals("file:///"))
    {
      str = "about:blank";
    }
    else
    {
      int j = "file:///".length();
      if ((str.startsWith("file:///")) && (str.charAt(j) == '#')) {
        str = "about:blank" + str.substring(j);
      }
    }
    Display localDisplay = this.browser.getDisplay();
    arrayOfLong[0] = 0L;
    IWebView localIWebView = new IWebView(paramLong1);
    i = localIWebView.mainFrame(arrayOfLong);
    boolean bool = false;
    if ((i == 0) && (arrayOfLong[0] != 0L))
    {
      bool = paramLong2 == arrayOfLong[0];
      new IWebFrame(arrayOfLong[0]).Release();
    }
    if (bool)
    {
      localObject1 = new StatusTextEvent(this.browser);
      ((StatusTextEvent)localObject1).display = localDisplay;
      ((StatusTextEvent)localObject1).widget = this.browser;
      ((StatusTextEvent)localObject1).text = str;
      localObject2 = this.browser.webBrowser.statusTextListeners;
      for (k = 0; k < localObject2.length; k++) {
        localObject2[k].changed((StatusTextEvent)localObject1);
      }
    }
    Object localObject1 = new LocationEvent(this.browser);
    ((LocationEvent)localObject1).display = localDisplay;
    ((LocationEvent)localObject1).widget = this.browser;
    ((LocationEvent)localObject1).location = str;
    ((LocationEvent)localObject1).top = bool;
    Object localObject2 = this.browser.webBrowser.locationListeners;
    for (int k = 0; k < localObject2.length; k++) {
      localObject2[k].changed((LocationEvent)localObject1);
    }
    return 0;
  }
  
  int didClearWindowObject(long paramLong1, long paramLong2, long paramLong3, long paramLong4)
  {
    WebKit_win32.JSGlobalContextRetain(paramLong2);
    long l1 = WebKit_win32.JSContextGetGlobalObject(paramLong2);
    long l2 = ((WebKit)this.browser.webBrowser).webViewData;
    long l3 = WebKit_win32.JSObjectMake(paramLong2, WebKit.ExternalClass, l2);
    byte[] arrayOfByte = null;
    try
    {
      arrayOfByte = "external\000".getBytes("UTF-8");
    }
    catch (UnsupportedEncodingException localUnsupportedEncodingException)
    {
      arrayOfByte = "external\000".getBytes();
    }
    long l4 = WebKit_win32.JSStringCreateWithUTF8CString(arrayOfByte);
    WebKit_win32.JSObjectSetProperty(paramLong2, l1, l4, l3, 0L, null);
    WebKit_win32.JSStringRelease(l4);
    Enumeration localEnumeration = this.browser.webBrowser.functions.elements();
    while (localEnumeration.hasMoreElements())
    {
      localObject = (BrowserFunction)localEnumeration.nextElement();
      this.browser.execute(((BrowserFunction)localObject).functionString);
    }
    Object localObject = new IWebView(paramLong1);
    long[] arrayOfLong = new long[1];
    ((IWebView)localObject).mainFrame(arrayOfLong);
    boolean bool = arrayOfLong[0] == paramLong4;
    new IWebFrame(arrayOfLong[0]).Release();
    addEventHandlers(bool);
    return 0;
  }
  
  int didCommitLoadForFrame(long paramLong1, long paramLong2)
  {
    IWebFrame localIWebFrame = new IWebFrame(paramLong2);
    long[] arrayOfLong = new long[1];
    int i = localIWebFrame.dataSource(arrayOfLong);
    if ((i != 0) || (arrayOfLong[0] == 0L)) {
      return 0;
    }
    IWebDataSource localIWebDataSource = new IWebDataSource(arrayOfLong[0]);
    arrayOfLong[0] = 0L;
    i = localIWebDataSource.request(arrayOfLong);
    localIWebDataSource.Release();
    if ((i != 0) || (arrayOfLong[0] == 0L)) {
      return 0;
    }
    IWebMutableURLRequest localIWebMutableURLRequest = new IWebMutableURLRequest(arrayOfLong[0]);
    arrayOfLong[0] = 0L;
    i = localIWebMutableURLRequest.URL(arrayOfLong);
    localIWebMutableURLRequest.Release();
    if ((i != 0) || (arrayOfLong[0] == 0L)) {
      return 0;
    }
    String str = WebKit.extractBSTR(arrayOfLong[0]);
    COM.SysFreeString(arrayOfLong[0]);
    if (str.length() == 0) {
      return 0;
    }
    if (str.equals("file:///"))
    {
      str = "about:blank";
    }
    else
    {
      int j = "file:///".length();
      if ((str.startsWith("file:///")) && (str.charAt(j) == '#')) {
        str = "about:blank" + str.substring(j);
      }
    }
    Display localDisplay = this.browser.getDisplay();
    arrayOfLong[0] = 0L;
    IWebView localIWebView = new IWebView(paramLong1);
    i = localIWebView.mainFrame(arrayOfLong);
    boolean bool = false;
    if ((i == 0) && (arrayOfLong[0] != 0L))
    {
      bool = paramLong2 == arrayOfLong[0];
      new IWebFrame(arrayOfLong[0]).Release();
    }
    if (bool)
    {
      this.url = str;
      if ((str.startsWith("about:blank")) && (this.html != null)) {
        return 0;
      }
      localObject1 = this.browser.webBrowser.functions.elements();
      while (((Enumeration)localObject1).hasMoreElements())
      {
        localObject2 = (BrowserFunction)((Enumeration)localObject1).nextElement();
        this.browser.webBrowser.execute(((BrowserFunction)localObject2).functionString);
      }
      localObject2 = new ProgressEvent(this.browser);
      ((ProgressEvent)localObject2).display = localDisplay;
      ((ProgressEvent)localObject2).widget = this.browser;
      ((ProgressEvent)localObject2).current = 1;
      ((ProgressEvent)localObject2).total = 100;
      ProgressListener[] arrayOfProgressListener = this.browser.webBrowser.progressListeners;
      for (int m = 0; m < arrayOfProgressListener.length; m++) {
        arrayOfProgressListener[m].changed((ProgressEvent)localObject2);
      }
      if (this.browser.isDisposed()) {
        return 0;
      }
      StatusTextEvent localStatusTextEvent = new StatusTextEvent(this.browser);
      localStatusTextEvent.display = localDisplay;
      localStatusTextEvent.widget = this.browser;
      localStatusTextEvent.text = str;
      StatusTextListener[] arrayOfStatusTextListener = this.browser.webBrowser.statusTextListeners;
      for (int n = 0; n < arrayOfStatusTextListener.length; n++) {
        arrayOfStatusTextListener[n].changed(localStatusTextEvent);
      }
      if (this.browser.isDisposed()) {
        return 0;
      }
    }
    Object localObject1 = new LocationEvent(this.browser);
    ((LocationEvent)localObject1).display = localDisplay;
    ((LocationEvent)localObject1).widget = this.browser;
    ((LocationEvent)localObject1).location = str;
    ((LocationEvent)localObject1).top = bool;
    Object localObject2 = this.browser.webBrowser.locationListeners;
    for (int k = 0; k < localObject2.length; k++) {
      localObject2[k].changed((LocationEvent)localObject1);
    }
    return 0;
  }
  
  int didFailProvisionalLoadWithError(long paramLong1, long paramLong2, long paramLong3)
  {
    IWebError localIWebError = new IWebError(paramLong2);
    int[] arrayOfInt = new int[1];
    int i = localIWebError.code(arrayOfInt);
    if (64536 < arrayOfInt[0]) {
      return 0;
    }
    String str1 = null;
    long[] arrayOfLong1 = new long[1];
    i = localIWebError.failingURL(arrayOfLong1);
    if ((i == 0) && (arrayOfLong1[0] != 0L))
    {
      str1 = WebKit.extractBSTR(arrayOfLong1[0]);
      COM.SysFreeString(arrayOfLong1[0]);
    }
    Object localObject1;
    Object localObject2;
    if ((str1 != null) && (64332 <= arrayOfInt[0]) && (arrayOfInt[0] <= 64336))
    {
      arrayOfLong2 = new long[1];
      i = localIWebError.localizedDescription(arrayOfLong2);
      if ((i != 0) || (arrayOfLong2[0] == 0L)) {
        return 0;
      }
      str2 = WebKit.extractBSTR(arrayOfLong2[0]);
      COM.SysFreeString(arrayOfLong2[0]);
      arrayOfLong2[0] = 0L;
      i = localIWebError.QueryInterface(WebKit_win32.IID_IWebErrorPrivate, arrayOfLong2);
      if ((i != 0) || (arrayOfLong2[0] == 0L)) {
        return 0;
      }
      localObject1 = new IWebErrorPrivate(arrayOfLong2[0]);
      arrayOfLong2[0] = 0L;
      localObject2 = new long[1];
      i = ((IWebErrorPrivate)localObject1).sslPeerCertificate((long[])localObject2);
      ((IWebErrorPrivate)localObject1).Release();
      if ((i != 0) || (localObject2[0] == 0L)) {
        return 0;
      }
      if (showCertificateDialog(paramLong1, str1, str2, localObject2[0]))
      {
        IWebFrame localIWebFrame = new IWebFrame(paramLong3);
        i = WebKit_win32.WebKitCreateInstance(WebKit_win32.CLSID_WebMutableURLRequest, 0L, WebKit_win32.IID_IWebMutableURLRequest, arrayOfLong2);
        if ((i != 0) || (arrayOfLong2[0] == 0L))
        {
          localObject2[0] = 0L;
          return 0;
        }
        IWebMutableURLRequest localIWebMutableURLRequest = new IWebMutableURLRequest(arrayOfLong2[0]);
        localIWebMutableURLRequest.setURL(arrayOfLong1[0]);
        localIWebMutableURLRequest.setAllowsAnyHTTPSCertificate();
        localIWebFrame.loadRequest(localIWebMutableURLRequest.getAddress());
        localIWebMutableURLRequest.Release();
      }
      localObject2[0] = 0L;
      return 0;
    }
    long[] arrayOfLong2 = new long[1];
    i = localIWebError.localizedDescription(arrayOfLong2);
    if ((i != 0) || (arrayOfLong2[0] == 0L)) {
      return 0;
    }
    String str2 = WebKit.extractBSTR(arrayOfLong2[0]);
    COM.SysFreeString(arrayOfLong2[0]);
    if (!this.browser.isDisposed())
    {
      localObject1 = str1 != null ? str1 + "\n\n" : "";
      localObject1 = (String)localObject1 + Compatibility.getMessage("SWT_Page_Load_Failed", new Object[] { str2 });
      localObject2 = new MessageBox(this.browser.getShell(), 33);
      ((MessageBox)localObject2).setMessage((String)localObject1);
      ((MessageBox)localObject2).open();
    }
    return 0;
  }
  
  int didFinishLoadForFrame(long paramLong1, long paramLong2)
  {
    IWebView localIWebView = new IWebView(paramLong1);
    long[] arrayOfLong1 = new long[1];
    int i = localIWebView.mainFrame(arrayOfLong1);
    if ((i != 0) || (arrayOfLong1[0] == 0L)) {
      return 0;
    }
    int j = paramLong2 == arrayOfLong1[0] ? 1 : 0;
    new IWebFrame(arrayOfLong1[0]).Release();
    if (j == 0) {
      return 0;
    }
    Object localObject1;
    if ((this.html != null) && (getUrl().startsWith("about:blank")))
    {
      ((WebKit)this.browser.webBrowser).loadingText = true;
      long l1 = WebKit.createBSTR(this.html);
      long l2;
      if (((WebKit)this.browser.webBrowser).untrustedText) {
        l2 = WebKit.createBSTR("about:blank");
      } else {
        l2 = WebKit.createBSTR("file:///");
      }
      localObject1 = new IWebFrame(paramLong2);
      ((IWebFrame)localObject1).loadHTMLString(l1, l2);
      this.html = null;
    }
    if (!((WebKit)this.browser.webBrowser).loadingText)
    {
      if (this.browser.isDisposed()) {
        return 0;
      }
      Display localDisplay = this.browser.getDisplay();
      IWebFrame localIWebFrame = new IWebFrame(paramLong2);
      long[] arrayOfLong2 = new long[1];
      i = localIWebFrame.dataSource(arrayOfLong2);
      if ((i != 0) || (arrayOfLong2[0] == 0L)) {
        return 0;
      }
      IWebDataSource localIWebDataSource = new IWebDataSource(arrayOfLong2[0]);
      arrayOfLong2[0] = 0L;
      i = localIWebDataSource.pageTitle(arrayOfLong2);
      localIWebDataSource.Release();
      if (i != 0) {
        return 0;
      }
      localObject1 = null;
      if (arrayOfLong2[0] != 0L)
      {
        localObject1 = WebKit.extractBSTR(arrayOfLong2[0]);
        COM.SysFreeString(arrayOfLong2[0]);
      }
      if ((localObject1 == null) || (((String)localObject1).length() == 0))
      {
        localObject2 = new TitleEvent(this.browser);
        ((TitleEvent)localObject2).display = localDisplay;
        ((TitleEvent)localObject2).widget = this.browser;
        ((TitleEvent)localObject2).title = getUrl();
        localObject3 = this.browser.webBrowser.titleListeners;
        for (k = 0; k < localObject3.length; k++) {
          localObject3[k].changed((TitleEvent)localObject2);
        }
        if (this.browser.isDisposed()) {
          return 0;
        }
      }
      Object localObject2 = new ProgressEvent(this.browser);
      ((ProgressEvent)localObject2).display = localDisplay;
      ((ProgressEvent)localObject2).widget = this.browser;
      ((ProgressEvent)localObject2).current = 100;
      ((ProgressEvent)localObject2).total = 100;
      Object localObject3 = this.browser.webBrowser.progressListeners;
      for (int k = 0; k < localObject3.length; k++) {
        localObject3[k].completed((ProgressEvent)localObject2);
      }
      if (this.browser.isDisposed()) {
        return 0;
      }
    }
    ((WebKit)this.browser.webBrowser).loadingText = false;
    return 0;
  }
  
  int didReceiveTitle(long paramLong1, long paramLong2, long paramLong3)
  {
    long[] arrayOfLong = new long[1];
    IWebView localIWebView = new IWebView(paramLong1);
    int i = localIWebView.mainFrame(arrayOfLong);
    if ((i != 0) || (paramLong3 == 0L)) {
      return 0;
    }
    if (paramLong3 == arrayOfLong[0])
    {
      String str = WebKit.extractBSTR(paramLong2);
      TitleEvent localTitleEvent = new TitleEvent(this.browser);
      localTitleEvent.display = this.browser.getDisplay();
      localTitleEvent.widget = this.browser;
      localTitleEvent.title = str;
      TitleListener[] arrayOfTitleListener = this.browser.webBrowser.titleListeners;
      for (int j = 0; j < arrayOfTitleListener.length; j++) {
        arrayOfTitleListener[j].changed(localTitleEvent);
      }
    }
    new IWebFrame(arrayOfLong[0]).Release();
    return 0;
  }
  
  int didStartProvisionalLoadForFrame(long paramLong1, long paramLong2)
  {
    return 0;
  }
  
  void disposeCOMInterfaces()
  {
    if (this.iWebFrameLoadDelegate != null)
    {
      this.iWebFrameLoadDelegate.dispose();
      this.iWebFrameLoadDelegate = null;
    }
  }
  
  long getAddress()
  {
    return this.iWebFrameLoadDelegate.getAddress();
  }
  
  String getUrl()
  {
    if ((this.url == null) || (this.url.length() == 0)) {
      return "about:blank";
    }
    return this.url;
  }
  
  int QueryInterface(long paramLong1, long paramLong2)
  {
    if ((paramLong1 == 0L) || (paramLong2 == 0L)) {
      return -2147024809;
    }
    GUID localGUID = new GUID();
    COM.MoveMemory(localGUID, paramLong1, GUID.sizeof);
    if (COM.IsEqualGUID(localGUID, COM.IIDIUnknown))
    {
      COM.MoveMemory(paramLong2, new long[] { this.iWebFrameLoadDelegate.getAddress() }, OS.PTR_SIZEOF);
      new IUnknown(this.iWebFrameLoadDelegate.getAddress()).AddRef();
      return 0;
    }
    if (COM.IsEqualGUID(localGUID, WebKit_win32.IID_IWebFrameLoadDelegate))
    {
      COM.MoveMemory(paramLong2, new long[] { this.iWebFrameLoadDelegate.getAddress() }, OS.PTR_SIZEOF);
      new IUnknown(this.iWebFrameLoadDelegate.getAddress()).AddRef();
      return 0;
    }
    COM.MoveMemory(paramLong2, new long[] { 0L }, OS.PTR_SIZEOF);
    return -2147467262;
  }
  
  int Release()
  {
    this.refCount -= 1;
    if (this.refCount == 0) {
      disposeCOMInterfaces();
    }
    return this.refCount;
  }
  
  boolean showCertificateDialog(long paramLong1, String paramString1, String paramString2, final long paramLong2)
  {
    Shell localShell1 = this.browser.getShell();
    final Shell localShell2 = new Shell(localShell1, 67680);
    localShell2.setText(Compatibility.getMessage("SWT_InvalidCert_Title"));
    localShell2.setLayout(new GridLayout());
    Label localLabel = new Label(localShell2, 64);
    String str = null;
    try
    {
      str = new URL(paramString1).getHost();
    }
    catch (MalformedURLException localMalformedURLException)
    {
      str = paramString1;
    }
    StringBuffer localStringBuffer = new StringBuffer("\n");
    localStringBuffer.append(Compatibility.getMessage("SWT_InvalidCert_Message", new String[] { str }));
    localStringBuffer.append("\n\n");
    localStringBuffer.append(Compatibility.getMessage(paramString2));
    localStringBuffer.append("\n");
    localStringBuffer.append(Compatibility.getMessage("SWT_InvalidCert_Connect"));
    localStringBuffer.append("\n");
    localLabel.setText(localStringBuffer.toString());
    GridData localGridData = new GridData();
    Monitor localMonitor = this.browser.getMonitor();
    int i = localMonitor.getBounds().width * 2 / 3;
    int j = localLabel.computeSize(-1, -1).x;
    localGridData.widthHint = Math.min(j, i);
    localGridData.horizontalAlignment = 4;
    localGridData.grabExcessHorizontalSpace = true;
    localLabel.setLayoutData(localGridData);
    boolean[] arrayOfBoolean = new boolean[1];
    final Button[] arrayOfButton = new Button[3];
    Listener local2 = new Listener()
    {
      public void handleEvent(Event paramAnonymousEvent)
      {
        if (paramAnonymousEvent.widget == arrayOfButton[2])
        {
          WebFrameLoadDelegate.this.showCertificate(localShell2, paramLong2);
        }
        else
        {
          this.val$result[0] = (paramAnonymousEvent.widget == arrayOfButton[0] ? 1 : false);
          localShell2.close();
        }
      }
    };
    Composite localComposite = new Composite(localShell2, 0);
    localGridData = new GridData();
    localGridData.horizontalAlignment = 3;
    localComposite.setLayoutData(localGridData);
    localComposite.setLayout(new GridLayout(3, true));
    arrayOfButton[0] = new Button(localComposite, 8);
    arrayOfButton[0].setText(SWT.getMessage("SWT_Continue"));
    arrayOfButton[0].setLayoutData(new GridData(768));
    arrayOfButton[0].addListener(13, local2);
    arrayOfButton[1] = new Button(localComposite, 8);
    arrayOfButton[1].setText(SWT.getMessage("SWT_Cancel"));
    arrayOfButton[1].setLayoutData(new GridData(768));
    arrayOfButton[1].addListener(13, local2);
    arrayOfButton[2] = new Button(localComposite, 8);
    arrayOfButton[2].setText(SWT.getMessage("SWT_ViewCertificate"));
    arrayOfButton[2].setLayoutData(new GridData(768));
    arrayOfButton[2].addListener(13, local2);
    localShell2.setDefaultButton(arrayOfButton[0]);
    localShell2.pack();
    Rectangle localRectangle1 = localShell1.getBounds();
    Rectangle localRectangle2 = localShell2.getBounds();
    int k = localShell1.getLocation().x + (localRectangle1.width - localRectangle2.width) / 2;
    int m = localShell1.getLocation().y + (localRectangle1.height - localRectangle2.height) / 2;
    localShell2.setLocation(k, m);
    localShell2.open();
    Display localDisplay = this.browser.getDisplay();
    while (!localShell2.isDisposed()) {
      if (!localDisplay.readAndDispatch()) {
        localDisplay.sleep();
      }
    }
    return arrayOfBoolean[0];
  }
  
  void showCertificate(Shell paramShell, long paramLong)
  {
    CERT_CONTEXT localCERT_CONTEXT = new CERT_CONTEXT();
    OS.MoveMemory(localCERT_CONTEXT, paramLong, CERT_CONTEXT.sizeof);
    CERT_INFO localCERT_INFO = new CERT_INFO();
    OS.MoveMemory(localCERT_INFO, localCERT_CONTEXT.pCertInfo, CERT_INFO.sizeof);
    int i = OS.CertNameToStr(1, localCERT_INFO.Issuer, 1, null, 0);
    TCHAR localTCHAR = new TCHAR(0, i);
    OS.CertNameToStr(1, localCERT_INFO.Issuer, 1, localTCHAR, i);
    String str1 = localTCHAR.toString(0, localTCHAR.strlen());
    i = OS.CertNameToStr(1, localCERT_INFO.Subject, 1, null, 0);
    localTCHAR = new TCHAR(0, i);
    OS.CertNameToStr(1, localCERT_INFO.Subject, 1, localTCHAR, i);
    String str2 = localTCHAR.toString(0, localTCHAR.strlen());
    SYSTEMTIME localSYSTEMTIME = new SYSTEMTIME();
    OS.FileTimeToSystemTime(localCERT_INFO.NotBefore, localSYSTEMTIME);
    String str3 = localSYSTEMTIME.wDay + "/" + localSYSTEMTIME.wMonth + "/" + localSYSTEMTIME.wYear;
    String str4 = localSYSTEMTIME.wHour + ":" + localSYSTEMTIME.wMinute + ":" + localSYSTEMTIME.wSecond;
    localSYSTEMTIME = new SYSTEMTIME();
    OS.FileTimeToSystemTime(localCERT_INFO.NotAfter, localSYSTEMTIME);
    String str5 = localSYSTEMTIME.wDay + "/" + localSYSTEMTIME.wMonth + "/" + localSYSTEMTIME.wYear;
    String str6 = localSYSTEMTIME.wHour + ":" + localSYSTEMTIME.wMinute + ":" + localSYSTEMTIME.wSecond;
    i = localCERT_INFO.SerialNumber.cbData;
    byte[] arrayOfByte = new byte[i];
    OS.MoveMemory(arrayOfByte, localCERT_INFO.SerialNumber.pbData, i);
    String str7 = new String();
    for (int j = i - 1; j >= 0; j--)
    {
      int k = 0xFF & arrayOfByte[j];
      localObject = Integer.toHexString(k);
      if (((String)localObject).length() == 1) {
        str7 = str7 + "0";
      }
      str7 = str7 + (String)localObject + " ";
    }
    final Shell localShell = new Shell(paramShell, 67680);
    localShell.setText(SWT.getMessage("SWT_Certificate"));
    localShell.setLayout(new GridLayout(1, false));
    TabFolder localTabFolder = new TabFolder(localShell, 0);
    localTabFolder.setLayoutData(new GridData(4, 4, true, true, 1, 1));
    localTabFolder.setLayout(new FillLayout());
    Object localObject = new TabItem(localTabFolder, 0);
    ((TabItem)localObject).setText(SWT.getMessage("SWT_General"));
    Composite localComposite = new Composite(localTabFolder, 2048);
    localComposite.setLayout(new GridLayout(1, false));
    Label localLabel1 = new Label(localComposite, 0);
    localLabel1.setLayoutData(new GridData(1, 16777216, false, false));
    localLabel1.setText(Compatibility.getMessage("SWT_IssuedTo", new Object[] { str2 }));
    Label localLabel2 = new Label(localComposite, 0);
    localLabel2.setLayoutData(new GridData(1, 16777216, false, false));
    localLabel2.setText(Compatibility.getMessage("SWT_IssuedFrom", new Object[] { str1 }));
    Label localLabel3 = new Label(localComposite, 0);
    localLabel3.setLayoutData(new GridData(1, 16777216, false, false));
    localLabel3.setText(Compatibility.getMessage("SWT_ValidFromTo", new Object[] { str3, str5 }));
    ((TabItem)localObject).setControl(localComposite);
    TabItem localTabItem = new TabItem(localTabFolder, 0);
    localTabItem.setText(SWT.getMessage("SWT_Details"));
    Table localTable = new Table(localTabFolder, 67588);
    localTable.setHeaderVisible(true);
    TableColumn localTableColumn = new TableColumn(localTable, 16384);
    localTableColumn.setText(SWT.getMessage("SWT_Field"));
    localTableColumn = new TableColumn(localTable, 0);
    localTableColumn.setText(SWT.getMessage("SWT_Value"));
    TableItem localTableItem = new TableItem(localTable, 0);
    String str8 = "V" + String.valueOf(localCERT_INFO.dwVersion + 1);
    localTableItem.setText(new String[] { SWT.getMessage("SWT_Version"), str8 });
    localTableItem = new TableItem(localTable, 0);
    localTableItem.setText(new String[] { SWT.getMessage("SWT_SerialNumber"), str7 });
    localTableItem = new TableItem(localTable, 0);
    localTableItem.setText(new String[] { SWT.getMessage("SWT_Issuer"), str1 });
    localTableItem = new TableItem(localTable, 0);
    StringBuffer localStringBuffer1 = new StringBuffer();
    localStringBuffer1.append(str3);
    localStringBuffer1.append(", ");
    localStringBuffer1.append(str4);
    localStringBuffer1.append(" GMT");
    localTableItem.setText(new String[] { SWT.getMessage("SWT_ValidFrom"), localStringBuffer1.toString() });
    localTableItem = new TableItem(localTable, 0);
    StringBuffer localStringBuffer2 = new StringBuffer();
    localStringBuffer2.append(str5);
    localStringBuffer2.append(", ");
    localStringBuffer2.append(str6);
    localStringBuffer2.append(" GMT");
    localTableItem.setText(new String[] { SWT.getMessage("SWT_ValidTo"), localStringBuffer2.toString() });
    localTableItem = new TableItem(localTable, 0);
    localTableItem.setText(new String[] { SWT.getMessage("SWT_Subject"), str2 });
    for (int m = 0; m < localTable.getColumnCount(); m++) {
      localTable.getColumn(m).pack();
    }
    localTabItem.setControl(localTable);
    Button localButton = new Button(localShell, 8);
    GridData localGridData = new GridData(16777224, 16777216, false, false);
    localGridData.widthHint = 75;
    localButton.setLayoutData(localGridData);
    localButton.setText(SWT.getMessage("SWT_OK"));
    localButton.addSelectionListener(new SelectionAdapter()
    {
      public void widgetSelected(SelectionEvent paramAnonymousSelectionEvent)
      {
        localShell.dispose();
      }
    });
    localShell.setDefaultButton(localButton);
    localShell.pack();
    Rectangle localRectangle1 = paramShell.getBounds();
    Rectangle localRectangle2 = localShell.getBounds();
    int n = paramShell.getLocation().x + (localRectangle1.width - localRectangle2.width) / 2;
    int i1 = paramShell.getLocation().y + (localRectangle1.height - localRectangle2.height) / 2;
    localShell.setLocation(n, i1);
    localShell.open();
    Display localDisplay = this.browser.getDisplay();
    while (!localShell.isDisposed()) {
      if (!localDisplay.readAndDispatch()) {
        localDisplay.sleep();
      }
    }
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/browser/WebFrameLoadDelegate.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */