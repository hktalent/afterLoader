package org.eclipse.swt.internal.mozilla;

public class nsIVariant
  extends nsISupports
{
  static final int LAST_METHOD_ID = nsISupports.LAST_METHOD_ID + ((IsXULRunner10()) || (IsXULRunner24()) ? 27 : 26);
  static final String NS_IVARIANT_IID_STR = "6c9eb060-8c6a-11d5-90f3-0010a4e73d9a";
  static final String NS_IVARIANT_10_IID_STR = "81e4c2de-acac-4ad6-901a-b5fb1b851a0d";
  
  public nsIVariant(long paramLong)
  {
    super(paramLong);
  }
  
  public int GetDataType(short[] paramArrayOfShort)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 1, getAddress(), paramArrayOfShort);
  }
  
  public int GetAsInt32(int[] paramArrayOfInt)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 4, getAddress(), paramArrayOfInt);
  }
  
  public int GetAsDouble(long paramLong)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 11, getAddress(), paramLong);
  }
  
  public int GetAsBool(int[] paramArrayOfInt)
  {
    if ((nsISupports.IsXULRunner10()) || (nsISupports.IsXULRunner24()))
    {
      byte[] arrayOfByte = new byte[1];
      int i = XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 12, getAddress(), arrayOfByte);
      paramArrayOfInt[0] = arrayOfByte[0];
      return i;
    }
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 12, getAddress(), paramArrayOfInt);
  }
  
  public int GetAsArray(short[] paramArrayOfShort, long paramLong, int[] paramArrayOfInt, long[] paramArrayOfLong)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + ((IsXULRunner10()) || (IsXULRunner24()) ? 25 : 24), getAddress(), paramArrayOfShort, paramLong, paramArrayOfInt, paramArrayOfLong);
  }
  
  public int GetAsWStringWithSize(int[] paramArrayOfInt, long[] paramArrayOfLong)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + ((IsXULRunner10()) || (IsXULRunner24()) ? 27 : 26), getAddress(), paramArrayOfInt, paramArrayOfLong);
  }
  
  static
  {
    IIDStore.RegisterIID(nsIVariant.class, 0, new nsID("6c9eb060-8c6a-11d5-90f3-0010a4e73d9a"));
    IIDStore.RegisterIID(nsIVariant.class, 5, new nsID("81e4c2de-acac-4ad6-901a-b5fb1b851a0d"));
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/internal/mozilla/nsIVariant.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */