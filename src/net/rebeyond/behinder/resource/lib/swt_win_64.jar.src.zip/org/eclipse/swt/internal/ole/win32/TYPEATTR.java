package org.eclipse.swt.internal.ole.win32;

public final class TYPEATTR
{
  public int guid_Data1;
  public short guid_Data2;
  public short guid_Data3;
  public byte[] guid_Data4 = new byte[8];
  public int lcid;
  public int dwReserved;
  public int memidConstructor;
  public int memidDestructor;
  public long lpstrSchema;
  public int cbSizeInstance;
  public int typekind;
  public short cFuncs;
  public short cVars;
  public short cImplTypes;
  public short cbSizeVft;
  public short cbAlignment;
  public short wTypeFlags;
  public short wMajorVerNum;
  public short wMinorVerNum;
  public long tdescAlias_unionField;
  public short tdescAlias_vt;
  public int idldescType_dwReserved;
  public short idldescType_wIDLFlags;
  public static final int sizeof = ;
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/internal/ole/win32/TYPEATTR.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */