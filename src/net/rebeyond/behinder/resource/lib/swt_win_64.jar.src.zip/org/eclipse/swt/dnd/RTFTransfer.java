package org.eclipse.swt.dnd;

import org.eclipse.swt.internal.ole.win32.STGMEDIUM;
import org.eclipse.swt.internal.win32.OS;

public class RTFTransfer
  extends ByteArrayTransfer
{
  private static RTFTransfer _instance = new RTFTransfer();
  private static final String CF_RTF = "Rich Text Format";
  private static final int CF_RTFID = registerType("Rich Text Format");
  
  public static RTFTransfer getInstance()
  {
    return _instance;
  }
  
  public void javaToNative(Object paramObject, TransferData paramTransferData)
  {
    if ((!checkRTF(paramObject)) || (!isSupportedType(paramTransferData))) {
      DND.error(2003);
    }
    String str = (String)paramObject;
    int i = str.length();
    char[] arrayOfChar = new char[i + 1];
    str.getChars(0, i, arrayOfChar, 0);
    int j = OS.GetACP();
    int k = OS.WideCharToMultiByte(j, 0, arrayOfChar, -1, null, 0, null, null);
    if (k == 0)
    {
      paramTransferData.stgmedium = new STGMEDIUM();
      paramTransferData.result = -2147221402;
      return;
    }
    long l = OS.GlobalAlloc(64, k);
    OS.WideCharToMultiByte(j, 0, arrayOfChar, -1, l, k, null, null);
    paramTransferData.stgmedium = new STGMEDIUM();
    paramTransferData.stgmedium.tymed = 1;
    paramTransferData.stgmedium.unionField = l;
    paramTransferData.stgmedium.pUnkForRelease = 0L;
    paramTransferData.result = 0;
  }
  
  /* Error */
  public Object nativeToJava(TransferData paramTransferData)
  {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: invokevirtual 4	org/eclipse/swt/dnd/RTFTransfer:isSupportedType	(Lorg/eclipse/swt/dnd/TransferData;)Z
    //   5: ifeq +12 -> 17
    //   8: aload_1
    //   9: getfield 21	org/eclipse/swt/dnd/TransferData:pIDataObject	J
    //   12: lconst_0
    //   13: lcmp
    //   14: ifne +5 -> 19
    //   17: aconst_null
    //   18: areturn
    //   19: new 22	org/eclipse/swt/internal/ole/win32/IDataObject
    //   22: dup
    //   23: aload_1
    //   24: getfield 21	org/eclipse/swt/dnd/TransferData:pIDataObject	J
    //   27: invokespecial 23	org/eclipse/swt/internal/ole/win32/IDataObject:<init>	(J)V
    //   30: astore_2
    //   31: aload_2
    //   32: invokevirtual 24	org/eclipse/swt/internal/ole/win32/IDataObject:AddRef	()I
    //   35: pop
    //   36: new 11	org/eclipse/swt/internal/ole/win32/STGMEDIUM
    //   39: dup
    //   40: invokespecial 12	org/eclipse/swt/internal/ole/win32/STGMEDIUM:<init>	()V
    //   43: astore_3
    //   44: aload_1
    //   45: getfield 25	org/eclipse/swt/dnd/TransferData:formatetc	Lorg/eclipse/swt/internal/ole/win32/FORMATETC;
    //   48: astore 4
    //   50: aload_3
    //   51: iconst_1
    //   52: putfield 18	org/eclipse/swt/internal/ole/win32/STGMEDIUM:tymed	I
    //   55: aload_1
    //   56: aload_0
    //   57: aload_2
    //   58: aload 4
    //   60: aload_3
    //   61: invokevirtual 26	org/eclipse/swt/dnd/RTFTransfer:getData	(Lorg/eclipse/swt/internal/ole/win32/IDataObject;Lorg/eclipse/swt/internal/ole/win32/FORMATETC;Lorg/eclipse/swt/internal/ole/win32/STGMEDIUM;)I
    //   64: putfield 15	org/eclipse/swt/dnd/TransferData:result	I
    //   67: aload_2
    //   68: invokevirtual 27	org/eclipse/swt/internal/ole/win32/IDataObject:Release	()I
    //   71: pop
    //   72: aload_1
    //   73: getfield 15	org/eclipse/swt/dnd/TransferData:result	I
    //   76: ifeq +5 -> 81
    //   79: aconst_null
    //   80: areturn
    //   81: aload_3
    //   82: getfield 19	org/eclipse/swt/internal/ole/win32/STGMEDIUM:unionField	J
    //   85: lstore 5
    //   87: lload 5
    //   89: invokestatic 28	org/eclipse/swt/internal/win32/OS:GlobalLock	(J)J
    //   92: lstore 7
    //   94: lload 7
    //   96: lconst_0
    //   97: lcmp
    //   98: ifne +12 -> 110
    //   101: aconst_null
    //   102: astore 9
    //   104: jsr +110 -> 214
    //   107: aload 9
    //   109: areturn
    //   110: invokestatic 9	org/eclipse/swt/internal/win32/OS:GetACP	()I
    //   113: istore 9
    //   115: iload 9
    //   117: iconst_1
    //   118: lload 7
    //   120: iconst_m1
    //   121: aconst_null
    //   122: iconst_0
    //   123: invokestatic 29	org/eclipse/swt/internal/win32/OS:MultiByteToWideChar	(IIJI[CI)I
    //   126: istore 10
    //   128: iload 10
    //   130: ifne +15 -> 145
    //   133: aconst_null
    //   134: astore 11
    //   136: jsr +60 -> 196
    //   139: jsr +75 -> 214
    //   142: aload 11
    //   144: areturn
    //   145: iload 10
    //   147: iconst_1
    //   148: isub
    //   149: newarray <illegal type>
    //   151: astore 11
    //   153: iload 9
    //   155: iconst_1
    //   156: lload 7
    //   158: iconst_m1
    //   159: aload 11
    //   161: aload 11
    //   163: arraylength
    //   164: invokestatic 29	org/eclipse/swt/internal/win32/OS:MultiByteToWideChar	(IIJI[CI)I
    //   167: pop
    //   168: new 6	java/lang/String
    //   171: dup
    //   172: aload 11
    //   174: invokespecial 30	java/lang/String:<init>	([C)V
    //   177: astore 12
    //   179: jsr +17 -> 196
    //   182: jsr +32 -> 214
    //   185: aload 12
    //   187: areturn
    //   188: astore 13
    //   190: jsr +6 -> 196
    //   193: aload 13
    //   195: athrow
    //   196: astore 14
    //   198: lload 5
    //   200: invokestatic 31	org/eclipse/swt/internal/win32/OS:GlobalUnlock	(J)Z
    //   203: pop
    //   204: ret 14
    //   206: astore 15
    //   208: jsr +6 -> 214
    //   211: aload 15
    //   213: athrow
    //   214: astore 16
    //   216: lload 5
    //   218: invokestatic 32	org/eclipse/swt/internal/win32/OS:GlobalFree	(J)J
    //   221: pop2
    //   222: ret 16
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	224	0	this	RTFTransfer
    //   0	224	1	paramTransferData	TransferData
    //   30	38	2	localIDataObject	org.eclipse.swt.internal.ole.win32.IDataObject
    //   43	39	3	localSTGMEDIUM	STGMEDIUM
    //   48	11	4	localFORMATETC	org.eclipse.swt.internal.ole.win32.FORMATETC
    //   85	132	5	l1	long
    //   92	65	7	l2	long
    //   102	6	9	localObject1	Object
    //   113	41	9	i	int
    //   126	23	10	j	int
    //   134	39	11	localObject2	Object
    //   177	9	12	str	String
    //   188	6	13	localObject3	Object
    //   196	1	14	localObject4	Object
    //   206	6	15	localObject5	Object
    //   214	1	16	localObject6	Object
    // Exception table:
    //   from	to	target	type
    //   110	139	188	finally
    //   145	182	188	finally
    //   188	193	188	finally
    //   87	107	206	finally
    //   110	142	206	finally
    //   145	185	206	finally
    //   188	211	206	finally
  }
  
  protected int[] getTypeIds()
  {
    return new int[] { CF_RTFID };
  }
  
  protected String[] getTypeNames()
  {
    return new String[] { "Rich Text Format" };
  }
  
  boolean checkRTF(Object paramObject)
  {
    return (paramObject != null) && ((paramObject instanceof String)) && (((String)paramObject).length() > 0);
  }
  
  protected boolean validate(Object paramObject)
  {
    return checkRTF(paramObject);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/dnd/RTFTransfer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */