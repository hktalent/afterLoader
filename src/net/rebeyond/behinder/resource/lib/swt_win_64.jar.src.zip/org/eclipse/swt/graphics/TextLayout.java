package org.eclipse.swt.graphics;

import org.eclipse.swt.SWT;
import org.eclipse.swt.internal.Callback;
import org.eclipse.swt.internal.Compatibility;
import org.eclipse.swt.internal.gdip.Gdip;
import org.eclipse.swt.internal.gdip.Rect;
import org.eclipse.swt.internal.win32.EMR;
import org.eclipse.swt.internal.win32.EMREXTCREATEFONTINDIRECTW;
import org.eclipse.swt.internal.win32.EXTLOGFONTW;
import org.eclipse.swt.internal.win32.LOGBRUSH;
import org.eclipse.swt.internal.win32.LOGFONT;
import org.eclipse.swt.internal.win32.LOGFONTA;
import org.eclipse.swt.internal.win32.LOGFONTW;
import org.eclipse.swt.internal.win32.OS;
import org.eclipse.swt.internal.win32.OUTLINETEXTMETRIC;
import org.eclipse.swt.internal.win32.OUTLINETEXTMETRICA;
import org.eclipse.swt.internal.win32.OUTLINETEXTMETRICW;
import org.eclipse.swt.internal.win32.RECT;
import org.eclipse.swt.internal.win32.SCRIPT_ANALYSIS;
import org.eclipse.swt.internal.win32.SCRIPT_CONTROL;
import org.eclipse.swt.internal.win32.SCRIPT_FONTPROPERTIES;
import org.eclipse.swt.internal.win32.SCRIPT_ITEM;
import org.eclipse.swt.internal.win32.SCRIPT_LOGATTR;
import org.eclipse.swt.internal.win32.SCRIPT_PROPERTIES;
import org.eclipse.swt.internal.win32.SCRIPT_STATE;
import org.eclipse.swt.internal.win32.TEXTMETRIC;
import org.eclipse.swt.internal.win32.TEXTMETRICA;
import org.eclipse.swt.internal.win32.TEXTMETRICW;

public final class TextLayout
  extends Resource
{
  Font font;
  String text;
  String segmentsText;
  int lineSpacing = 0;
  int ascent;
  int descent;
  int alignment;
  int wrapWidth = this.ascent = this.descent = -1;
  int orientation = 33554432;
  int textDirection = 33554432;
  int indent;
  int wrapIndent;
  boolean justify;
  int[] tabs;
  int[] segments;
  char[] segmentsChars;
  StyleItem[] styles = new StyleItem[2];
  int stylesCount;
  StyleItem[] allRuns;
  StyleItem[][] runs;
  int[] lineOffset;
  int[] lineY;
  int[] lineWidth;
  long mLangFontLink2;
  static final char LTR_MARK = '‎';
  static final char RTL_MARK = '‏';
  static final int SCRIPT_VISATTR_SIZEOF = 2;
  static final int GOFFSET_SIZEOF = 8;
  static final byte[] CLSID_CMultiLanguage = new byte[16];
  static final byte[] IID_IMLangFontLink2 = new byte[16];
  static final int MERGE_MAX = 512;
  static final int TOO_MANY_RUNS = 1024;
  static final int UNDERLINE_IME_DOT = 65536;
  static final int UNDERLINE_IME_DASH = 131072;
  static final int UNDERLINE_IME_THICK = 196608;
  
  public TextLayout(Device paramDevice)
  {
    super(paramDevice);
    this.styles[0] = new StyleItem();
    this.styles[1] = new StyleItem();
    this.stylesCount = 2;
    this.text = "";
    long[] arrayOfLong = new long[1];
    OS.OleInitialize(0L);
    if (OS.CoCreateInstance(CLSID_CMultiLanguage, 0L, 1, IID_IMLangFontLink2, arrayOfLong) == 0) {
      this.mLangFontLink2 = arrayOfLong[0];
    }
    init();
  }
  
  RECT addClipRect(StyleItem paramStyleItem, RECT paramRECT1, RECT paramRECT2, int paramInt1, int paramInt2)
  {
    if (paramRECT2 != null)
    {
      if (paramRECT1 == null)
      {
        paramRECT1 = new RECT();
        OS.SetRect(paramRECT1, -1, paramRECT2.top, -1, paramRECT2.bottom);
      }
      int i = (this.orientation & 0x4000000) != 0 ? 1 : 0;
      if ((paramStyleItem.start <= paramInt1) && (paramInt1 <= paramStyleItem.start + paramStyleItem.length)) {
        if ((paramStyleItem.analysis.fRTL ^ i)) {
          paramRECT1.right = paramRECT2.left;
        } else {
          paramRECT1.left = paramRECT2.left;
        }
      }
      if ((paramStyleItem.start <= paramInt2) && (paramInt2 <= paramStyleItem.start + paramStyleItem.length)) {
        if ((paramStyleItem.analysis.fRTL ^ i)) {
          paramRECT1.left = paramRECT2.right;
        } else {
          paramRECT1.right = paramRECT2.right;
        }
      }
    }
    return paramRECT1;
  }
  
  void breakRun(StyleItem paramStyleItem)
  {
    if (paramStyleItem.psla != 0L) {
      return;
    }
    char[] arrayOfChar = new char[paramStyleItem.length];
    this.segmentsText.getChars(paramStyleItem.start, paramStyleItem.start + paramStyleItem.length, arrayOfChar, 0);
    long l = OS.GetProcessHeap();
    paramStyleItem.psla = OS.HeapAlloc(l, 8, SCRIPT_LOGATTR.sizeof * arrayOfChar.length);
    if (paramStyleItem.psla == 0L) {
      SWT.error(2);
    }
    OS.ScriptBreak(arrayOfChar, arrayOfChar.length, paramStyleItem.analysis, paramStyleItem.psla);
  }
  
  void checkLayout()
  {
    if (isDisposed()) {
      SWT.error(44);
    }
  }
  
  void computeRuns(GC paramGC)
  {
    if (this.runs != null) {
      return;
    }
    long l1 = paramGC != null ? paramGC.handle : this.device.internal_new_GC(null);
    long l2 = OS.CreateCompatibleDC(l1);
    this.allRuns = itemize();
    for (int i = 0; i < this.allRuns.length - 1; i++)
    {
      localObject = this.allRuns[i];
      OS.SelectObject(l2, getItemFont((StyleItem)localObject));
      shape(l2, (StyleItem)localObject);
    }
    SCRIPT_LOGATTR localSCRIPT_LOGATTR = new SCRIPT_LOGATTR();
    Object localObject = new SCRIPT_PROPERTIES();
    int j = this.indent;
    int k = 0;
    int m = 1;
    StyleItem localStyleItem4;
    for (int n = 0; n < this.allRuns.length - 1; n++)
    {
      StyleItem localStyleItem1 = this.allRuns[n];
      int i5;
      int i7;
      if ((this.tabs != null) && (localStyleItem1.tab))
      {
        i2 = this.tabs.length;
        for (int i3 = 0; i3 < i2; i3++) {
          if (this.tabs[i3] > j)
          {
            localStyleItem1.width = (this.tabs[i3] - j);
            break;
          }
        }
        if (i3 == i2)
        {
          i5 = this.tabs[(i2 - 1)];
          i6 = i2 > 1 ? this.tabs[(i2 - 1)] - this.tabs[(i2 - 2)] : this.tabs[0];
          if (i6 > 0)
          {
            while (i5 <= j) {
              i5 += i6;
            }
            localStyleItem1.width = (i5 - j);
          }
        }
        i5 = localStyleItem1.length;
        if (i5 > 1)
        {
          i6 = i3 + i5 - 1;
          if (i6 < i2)
          {
            localStyleItem1.width += this.tabs[i6] - this.tabs[i3];
          }
          else
          {
            if (i3 < i2)
            {
              localStyleItem1.width += this.tabs[(i2 - 1)] - this.tabs[i3];
              i5 -= i2 - 1 - i3;
            }
            i7 = i2 > 1 ? this.tabs[(i2 - 1)] - this.tabs[(i2 - 2)] : this.tabs[0];
            localStyleItem1.width += i7 * (i5 - 1);
          }
        }
      }
      if ((this.wrapWidth != -1) && (j + localStyleItem1.width > this.wrapWidth) && (!localStyleItem1.tab) && (!localStyleItem1.lineBreak))
      {
        i2 = 0;
        int[] arrayOfInt = new int[localStyleItem1.length];
        if ((localStyleItem1.style != null) && (localStyleItem1.style.metrics != null)) {
          arrayOfInt[0] = localStyleItem1.width;
        } else {
          OS.ScriptGetLogicalWidths(localStyleItem1.analysis, localStyleItem1.length, localStyleItem1.glyphCount, localStyleItem1.advances, localStyleItem1.clusters, localStyleItem1.visAttrs, arrayOfInt);
        }
        i5 = 0;
        i6 = this.wrapWidth - j;
        while (i5 + arrayOfInt[i2] < i6) {
          i5 += arrayOfInt[(i2++)];
        }
        i7 = i2;
        int i8 = n;
        while (n >= k)
        {
          breakRun(localStyleItem1);
          while (i2 >= 0)
          {
            OS.MoveMemory(localSCRIPT_LOGATTR, localStyleItem1.psla + i2 * SCRIPT_LOGATTR.sizeof, SCRIPT_LOGATTR.sizeof);
            if ((localSCRIPT_LOGATTR.fSoftBreak) || (localSCRIPT_LOGATTR.fWhiteSpace)) {
              break;
            }
            i2--;
          }
          if ((i2 == 0) && (n != k) && (!localStyleItem1.tab) && (localSCRIPT_LOGATTR.fSoftBreak) && (!localSCRIPT_LOGATTR.fWhiteSpace))
          {
            OS.MoveMemory((SCRIPT_PROPERTIES)localObject, this.device.scripts[localStyleItem1.analysis.eScript], SCRIPT_PROPERTIES.sizeof);
            i10 = ((SCRIPT_PROPERTIES)localObject).langid;
            localStyleItem4 = this.allRuns[(n - 1)];
            OS.MoveMemory((SCRIPT_PROPERTIES)localObject, this.device.scripts[localStyleItem4.analysis.eScript], SCRIPT_PROPERTIES.sizeof);
            if ((((SCRIPT_PROPERTIES)localObject).langid == i10) || (i10 == 0) || (((SCRIPT_PROPERTIES)localObject).langid == 0))
            {
              breakRun(localStyleItem4);
              OS.MoveMemory(localSCRIPT_LOGATTR, localStyleItem4.psla + (localStyleItem4.length - 1) * SCRIPT_LOGATTR.sizeof, SCRIPT_LOGATTR.sizeof);
              if (!localSCRIPT_LOGATTR.fWhiteSpace) {
                i2 = -1;
              }
            }
          }
          if ((i2 >= 0) || (n == k)) {
            break;
          }
          localStyleItem1 = this.allRuns[(--n)];
          i2 = localStyleItem1.length - 1;
        }
        int i10 = (i2 == 0) && (n != k) && (!localStyleItem1.tab) ? 1 : 0;
        if (i10 != 0)
        {
          breakRun(localStyleItem1);
          OS.MoveMemory(localSCRIPT_LOGATTR, localStyleItem1.psla + i2 * SCRIPT_LOGATTR.sizeof, SCRIPT_LOGATTR.sizeof);
          i10 = !localSCRIPT_LOGATTR.fWhiteSpace ? 1 : 0;
        }
        if (i10 != 0)
        {
          localStyleItem1 = this.allRuns[(--n)];
          i2 = localStyleItem1.length;
        }
        else if ((i2 <= 0) && (n == k))
        {
          if ((j == this.wrapWidth) && (i8 > 0))
          {
            n = i8 - 1;
            localStyleItem1 = this.allRuns[n];
            i2 = localStyleItem1.length;
          }
          else
          {
            n = i8;
            localStyleItem1 = this.allRuns[n];
            i2 = Math.max(1, i7);
          }
        }
        breakRun(localStyleItem1);
        while (i2 < localStyleItem1.length)
        {
          OS.MoveMemory(localSCRIPT_LOGATTR, localStyleItem1.psla + i2 * SCRIPT_LOGATTR.sizeof, SCRIPT_LOGATTR.sizeof);
          if (!localSCRIPT_LOGATTR.fWhiteSpace) {
            break;
          }
          i2++;
        }
        if ((0 < i2) && (i2 < localStyleItem1.length))
        {
          localStyleItem4 = new StyleItem();
          localStyleItem1.start += i2;
          localStyleItem1.length -= i2;
          localStyleItem4.style = localStyleItem1.style;
          localStyleItem4.analysis = cloneScriptAnalysis(localStyleItem1.analysis);
          localStyleItem1.free();
          localStyleItem1.length = i2;
          OS.SelectObject(l2, getItemFont(localStyleItem1));
          localStyleItem1.analysis.fNoGlyphIndex = false;
          shape(l2, localStyleItem1);
          OS.SelectObject(l2, getItemFont(localStyleItem4));
          localStyleItem4.analysis.fNoGlyphIndex = false;
          shape(l2, localStyleItem4);
          StyleItem[] arrayOfStyleItem3 = new StyleItem[this.allRuns.length + 1];
          System.arraycopy(this.allRuns, 0, arrayOfStyleItem3, 0, n + 1);
          System.arraycopy(this.allRuns, n + 1, arrayOfStyleItem3, n + 2, this.allRuns.length - n - 1);
          this.allRuns = arrayOfStyleItem3;
          this.allRuns[(n + 1)] = localStyleItem4;
        }
        if (n != this.allRuns.length - 2) {
          localStyleItem1.softBreak = (localStyleItem1.lineBreak = 1);
        }
      }
      j += localStyleItem1.width;
      if (localStyleItem1.lineBreak)
      {
        k = n + 1;
        j = localStyleItem1.softBreak ? this.wrapIndent : this.indent;
        m++;
      }
    }
    j = 0;
    this.runs = new StyleItem[m][];
    this.lineOffset = new int[m + 1];
    this.lineY = new int[m + 1];
    this.lineWidth = new int[m];
    n = 0;
    int i1 = 0;
    int i2 = Math.max(0, this.ascent);
    int i4 = Math.max(0, this.descent);
    StyleItem[] arrayOfStyleItem1 = new StyleItem[this.allRuns.length];
    for (int i6 = 0; i6 < this.allRuns.length; i6++)
    {
      StyleItem localStyleItem2 = this.allRuns[i6];
      arrayOfStyleItem1[(n++)] = localStyleItem2;
      j += localStyleItem2.width;
      i2 = Math.max(i2, localStyleItem2.ascent);
      i4 = Math.max(i4, localStyleItem2.descent);
      if ((localStyleItem2.lineBreak) || (i6 == this.allRuns.length - 1))
      {
        if ((n == 1) && ((i6 == this.allRuns.length - 1) || (!localStyleItem2.softBreak)))
        {
          TEXTMETRICA localTEXTMETRICA = OS.IsUnicode ? new TEXTMETRICW() : new TEXTMETRICA();
          OS.SelectObject(l2, getItemFont(localStyleItem2));
          OS.GetTextMetrics(l2, localTEXTMETRICA);
          localStyleItem2.ascent = localTEXTMETRICA.tmAscent;
          localStyleItem2.descent = localTEXTMETRICA.tmDescent;
          i2 = Math.max(i2, localStyleItem2.ascent);
          i4 = Math.max(i4, localStyleItem2.descent);
        }
        this.runs[i1] = new StyleItem[n];
        System.arraycopy(arrayOfStyleItem1, 0, this.runs[i1], 0, n);
        if ((this.justify) && (this.wrapWidth != -1) && (localStyleItem2.softBreak) && (j > 0))
        {
          int i9 = this.wrapIndent;
          if (i1 == 0)
          {
            i9 = this.indent;
          }
          else
          {
            StyleItem[] arrayOfStyleItem2 = this.runs[(i1 - 1)];
            localStyleItem4 = arrayOfStyleItem2[(arrayOfStyleItem2.length - 1)];
            if ((localStyleItem4.lineBreak) && (!localStyleItem4.softBreak)) {
              i9 = this.indent;
            }
          }
          j += i9;
          long l3 = OS.GetProcessHeap();
          int i13 = 0;
          for (int i14 = 0; i14 < this.runs[i1].length; i14++)
          {
            StyleItem localStyleItem5 = this.runs[i1][i14];
            int i15 = localStyleItem5.width * this.wrapWidth / j;
            if (i15 != localStyleItem5.width)
            {
              localStyleItem5.justify = OS.HeapAlloc(l3, 8, localStyleItem5.glyphCount * 4);
              if (localStyleItem5.justify == 0L) {
                SWT.error(2);
              }
              OS.ScriptJustify(localStyleItem5.visAttrs, localStyleItem5.advances, localStyleItem5.glyphCount, i15 - localStyleItem5.width, 2, localStyleItem5.justify);
              localStyleItem5.width = i15;
            }
            i13 += localStyleItem5.width;
          }
          j = i13;
        }
        this.lineWidth[i1] = j;
        StyleItem localStyleItem3 = this.runs[i1][(n - 1)];
        int i11 = localStyleItem3.start + localStyleItem3.length;
        this.runs[i1] = reorder(this.runs[i1], i6 == this.allRuns.length - 1 ? 1 : false);
        localStyleItem3 = this.runs[i1][(n - 1)];
        if ((localStyleItem2.softBreak) && (localStyleItem2 != localStyleItem3))
        {
          localStyleItem2.softBreak = (localStyleItem2.lineBreak = 0);
          localStyleItem3.softBreak = (localStyleItem3.lineBreak = 1);
        }
        j = getLineIndent(i1);
        for (int i12 = 0; i12 < this.runs[i1].length; i12++)
        {
          this.runs[i1][i12].x = j;
          j += this.runs[i1][i12].width;
        }
        i1++;
        this.lineY[i1] = (this.lineY[(i1 - 1)] + i2 + i4 + this.lineSpacing);
        this.lineOffset[i1] = i11;
        n = j = 0;
        i2 = Math.max(0, this.ascent);
        i4 = Math.max(0, this.descent);
      }
    }
    if (l2 != 0L) {
      OS.DeleteDC(l2);
    }
    if (paramGC == null) {
      this.device.internal_dispose_GC(l1, null);
    }
  }
  
  void destroy()
  {
    freeRuns();
    this.font = null;
    this.text = null;
    this.segmentsText = null;
    this.tabs = null;
    this.styles = null;
    this.runs = ((StyleItem[][])null);
    this.lineOffset = null;
    this.lineY = null;
    this.lineWidth = null;
    this.segments = null;
    this.segmentsChars = null;
    if (this.mLangFontLink2 != 0L)
    {
      OS.VtblCall(2, this.mLangFontLink2);
      this.mLangFontLink2 = 0L;
    }
    OS.OleUninitialize();
  }
  
  SCRIPT_ANALYSIS cloneScriptAnalysis(SCRIPT_ANALYSIS paramSCRIPT_ANALYSIS)
  {
    SCRIPT_ANALYSIS localSCRIPT_ANALYSIS = new SCRIPT_ANALYSIS();
    localSCRIPT_ANALYSIS.eScript = paramSCRIPT_ANALYSIS.eScript;
    localSCRIPT_ANALYSIS.fRTL = paramSCRIPT_ANALYSIS.fRTL;
    localSCRIPT_ANALYSIS.fLayoutRTL = paramSCRIPT_ANALYSIS.fLayoutRTL;
    localSCRIPT_ANALYSIS.fLinkBefore = paramSCRIPT_ANALYSIS.fLinkBefore;
    localSCRIPT_ANALYSIS.fLinkAfter = paramSCRIPT_ANALYSIS.fLinkAfter;
    localSCRIPT_ANALYSIS.fLogicalOrder = paramSCRIPT_ANALYSIS.fLogicalOrder;
    localSCRIPT_ANALYSIS.fNoGlyphIndex = paramSCRIPT_ANALYSIS.fNoGlyphIndex;
    localSCRIPT_ANALYSIS.s = new SCRIPT_STATE();
    localSCRIPT_ANALYSIS.s.uBidiLevel = paramSCRIPT_ANALYSIS.s.uBidiLevel;
    localSCRIPT_ANALYSIS.s.fOverrideDirection = paramSCRIPT_ANALYSIS.s.fOverrideDirection;
    localSCRIPT_ANALYSIS.s.fInhibitSymSwap = paramSCRIPT_ANALYSIS.s.fInhibitSymSwap;
    localSCRIPT_ANALYSIS.s.fCharShape = paramSCRIPT_ANALYSIS.s.fCharShape;
    localSCRIPT_ANALYSIS.s.fDigitSubstitute = paramSCRIPT_ANALYSIS.s.fDigitSubstitute;
    localSCRIPT_ANALYSIS.s.fInhibitLigate = paramSCRIPT_ANALYSIS.s.fInhibitLigate;
    localSCRIPT_ANALYSIS.s.fDisplayZWG = paramSCRIPT_ANALYSIS.s.fDisplayZWG;
    localSCRIPT_ANALYSIS.s.fArabicNumContext = paramSCRIPT_ANALYSIS.s.fArabicNumContext;
    localSCRIPT_ANALYSIS.s.fGcpClusters = paramSCRIPT_ANALYSIS.s.fGcpClusters;
    localSCRIPT_ANALYSIS.s.fReserved = paramSCRIPT_ANALYSIS.s.fReserved;
    localSCRIPT_ANALYSIS.s.fEngineReserved = paramSCRIPT_ANALYSIS.s.fEngineReserved;
    return localSCRIPT_ANALYSIS;
  }
  
  int[] computePolyline(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    int i = paramInt4 - paramInt2;
    int j = 2 * i;
    int k = Compatibility.ceil(paramInt3 - paramInt1, j);
    if ((k == 0) && (paramInt3 - paramInt1 > 2)) {
      k = 1;
    }
    int m = (2 * k + 1) * 2;
    if (m < 0) {
      return new int[0];
    }
    int[] arrayOfInt = new int[m];
    for (int n = 0; n < k; n++)
    {
      int i1 = 4 * n;
      arrayOfInt[i1] = (paramInt1 + j * n);
      arrayOfInt[(i1 + 1)] = paramInt4;
      arrayOfInt[(i1 + 2)] = (arrayOfInt[i1] + j / 2);
      arrayOfInt[(i1 + 3)] = paramInt2;
    }
    arrayOfInt[(m - 2)] = (paramInt1 + j * k);
    arrayOfInt[(m - 1)] = paramInt4;
    return arrayOfInt;
  }
  
  long createGdipBrush(int paramInt1, int paramInt2)
  {
    int i = (paramInt2 & 0xFF) << 24 | paramInt1 >> 16 & 0xFF | paramInt1 & 0xFF00 | (paramInt1 & 0xFF) << 16;
    long l1 = Gdip.Color_new(i);
    long l2 = Gdip.SolidBrush_new(l1);
    Gdip.Color_delete(l1);
    return l2;
  }
  
  long createGdipBrush(Color paramColor, int paramInt)
  {
    return createGdipBrush(paramColor.handle, paramInt);
  }
  
  public void draw(GC paramGC, int paramInt1, int paramInt2)
  {
    draw(paramGC, paramInt1, paramInt2, -1, -1, null, null);
  }
  
  public void draw(GC paramGC, int paramInt1, int paramInt2, int paramInt3, int paramInt4, Color paramColor1, Color paramColor2)
  {
    draw(paramGC, paramInt1, paramInt2, paramInt3, paramInt4, paramColor1, paramColor2, 0);
  }
  
  public void draw(GC paramGC, int paramInt1, int paramInt2, int paramInt3, int paramInt4, Color paramColor1, Color paramColor2, int paramInt5)
  {
    checkLayout();
    computeRuns(paramGC);
    if (paramGC == null) {
      SWT.error(4);
    }
    if (paramGC.isDisposed()) {
      SWT.error(5);
    }
    if ((paramColor1 != null) && (paramColor1.isDisposed())) {
      SWT.error(5);
    }
    if ((paramColor2 != null) && (paramColor2.isDisposed())) {
      SWT.error(5);
    }
    int i = this.text.length();
    if ((i == 0) && (paramInt5 == 0)) {
      return;
    }
    long l1 = paramGC.handle;
    Rectangle localRectangle = paramGC.getClipping();
    GCData localGCData = paramGC.data;
    long l2 = localGCData.gdipGraphics;
    long l3 = localGCData.foreground;
    int j = OS.GetSysColor(OS.COLOR_HOTLIGHT);
    int k = localGCData.alpha;
    int m = l2 != 0L ? 1 : 0;
    long l4 = 0L;
    long l5 = 0L;
    int n = 0;
    if (m != 0)
    {
      paramGC.checkGC(1);
      l4 = paramGC.getFgBrush();
    }
    else
    {
      n = OS.SaveDC(l1);
      if ((localGCData.style & 0x8000000) != 0) {
        OS.SetLayout(l1, OS.GetLayout(l1) | 0x1);
      }
    }
    boolean bool = (paramInt3 <= paramInt4) && (paramInt3 != -1) && (paramInt4 != -1);
    long l6 = 0L;
    long l7 = 0L;
    long l8 = 0L;
    long l9 = 0L;
    long l10 = 0L;
    int i1 = 0;
    if ((bool) || (((paramInt5 & 0x100000) != 0) && ((paramInt5 & 0x30000) != 0)))
    {
      int i2 = paramColor1 != null ? paramColor1.handle : OS.GetSysColor(OS.COLOR_HIGHLIGHTTEXT);
      i3 = paramColor2 != null ? paramColor2.handle : OS.GetSysColor(OS.COLOR_HIGHLIGHT);
      if (m != 0)
      {
        l6 = createGdipBrush(i3, k);
        l7 = createGdipBrush(i2, k);
      }
      else
      {
        l10 = OS.CreateSolidBrush(i3);
        i1 = i2;
      }
      if (bool)
      {
        paramInt3 = translateOffset(Math.min(Math.max(0, paramInt3), i - 1));
        paramInt4 = translateOffset(Math.min(Math.max(0, paramInt4), i - 1));
      }
    }
    RECT localRECT1 = new RECT();
    OS.SetBkMode(l1, 1);
    for (int i3 = 0; i3 < this.runs.length; i3++)
    {
      int i4 = paramInt1 + getLineIndent(i3);
      int i5 = paramInt2 + this.lineY[i3];
      StyleItem[] arrayOfStyleItem = this.runs[i3];
      int i6 = this.lineY[(i3 + 1)] - this.lineY[i3] - this.lineSpacing;
      int i7;
      int i8;
      if (((paramInt5 & 0x30000) != 0) && ((bool) || ((paramInt5 & 0x100000) != 0)))
      {
        i7 = 0;
        if ((i3 == this.runs.length - 1) && ((paramInt5 & 0x100000) != 0))
        {
          i7 = 1;
        }
        else
        {
          StyleItem localStyleItem1 = arrayOfStyleItem[(arrayOfStyleItem.length - 1)];
          if ((localStyleItem1.lineBreak) && (!localStyleItem1.softBreak))
          {
            if ((paramInt3 <= localStyleItem1.start) && (localStyleItem1.start <= paramInt4)) {
              i7 = 1;
            }
          }
          else
          {
            int i9 = localStyleItem1.start + localStyleItem1.length - 1;
            if ((paramInt3 <= i9) && (i9 < paramInt4) && ((paramInt5 & 0x10000) != 0)) {
              i7 = 1;
            }
          }
        }
        if (i7 != 0)
        {
          if ((paramInt5 & 0x10000) != 0) {
            i8 = OS.IsWin95 ? 32767 : 117440511;
          } else {
            i8 = i6 / 3;
          }
          if (m != 0)
          {
            Gdip.Graphics_FillRectangle(l2, l6, i4 + this.lineWidth[i3], i5, i8, i6);
          }
          else
          {
            OS.SelectObject(l1, l10);
            OS.PatBlt(l1, i4 + this.lineWidth[i3], i5, i8, i6, 15728673);
          }
        }
      }
      if ((i4 <= localRectangle.x + localRectangle.width) && (i4 + this.lineWidth[i3] >= localRectangle.x))
      {
        i7 = i4;
        for (i8 = 0; i8 < arrayOfStyleItem.length; i8++)
        {
          StyleItem localStyleItem2 = arrayOfStyleItem[i8];
          if (localStyleItem2.length != 0)
          {
            if (i4 > localRectangle.x + localRectangle.width) {
              break;
            }
            if ((i4 + localStyleItem2.width >= localRectangle.x) && ((!localStyleItem2.lineBreak) || (localStyleItem2.softBreak)))
            {
              OS.SetRect(localRECT1, i4, i5, i4 + localStyleItem2.width, i5 + i6);
              if (m != 0) {
                drawRunBackgroundGDIP(localStyleItem2, l2, localRECT1, paramInt3, paramInt4, k, l6, bool);
              } else {
                drawRunBackground(localStyleItem2, l1, localRECT1, paramInt3, paramInt4, l10, bool);
              }
            }
            i4 += localStyleItem2.width;
          }
        }
        i8 = Math.max(0, this.ascent);
        int i10 = 0;
        for (int i11 = 0; i11 < arrayOfStyleItem.length; i11++)
        {
          i8 = Math.max(i8, arrayOfStyleItem[i11].ascent);
          i10 = Math.min(i10, arrayOfStyleItem[i11].underlinePos);
        }
        RECT localRECT2 = null;
        RECT localRECT3 = null;
        RECT localRECT4 = null;
        RECT localRECT5 = null;
        i4 = i7;
        for (int i12 = 0; i12 < arrayOfStyleItem.length; i12++)
        {
          StyleItem localStyleItem3 = arrayOfStyleItem[i12];
          TextStyle localTextStyle = localStyleItem3.style;
          int i13 = (localTextStyle != null) && ((localTextStyle.underline) || (localTextStyle.strikeout) || (localTextStyle.borderStyle != 0)) ? 1 : 0;
          if (localStyleItem3.length != 0)
          {
            if (i4 > localRectangle.x + localRectangle.width) {
              break;
            }
            if (i4 + localStyleItem3.width >= localRectangle.x)
            {
              int i14 = (localStyleItem3.tab) && (i13 == 0) ? 1 : 0;
              if ((i14 == 0) && ((!localStyleItem3.lineBreak) || (localStyleItem3.softBreak)) && ((localTextStyle == null) || (localTextStyle.metrics == null)))
              {
                OS.SetRect(localRECT1, i4, i5, i4 + localStyleItem3.width, i5 + i6);
                long l11;
                if (m != 0)
                {
                  l11 = getItemFont(localStyleItem3);
                  if (l11 != l9)
                  {
                    l9 = l11;
                    if (l8 != 0L) {
                      Gdip.Font_delete(l8);
                    }
                    l12 = OS.SelectObject(l1, l11);
                    l8 = Gdip.Font_new(l1, l11);
                    OS.SelectObject(l1, l12);
                    if (l8 == 0L) {
                      SWT.error(2);
                    }
                    if (!Gdip.Font_IsAvailable(l8))
                    {
                      Gdip.Font_delete(l8);
                      l8 = 0L;
                    }
                  }
                  long l12 = l4;
                  if ((localTextStyle != null) && (localTextStyle.underline) && (localTextStyle.underlineStyle == 4))
                  {
                    if (l5 == 0L) {
                      l5 = createGdipBrush(j, k);
                    }
                    l12 = l5;
                  }
                  if ((l8 != 0L) && (!localStyleItem3.analysis.fNoGlyphIndex))
                  {
                    localRECT5 = drawRunTextGDIP(l2, localStyleItem3, localRECT1, l8, i8, l12, l7, paramInt3, paramInt4, k);
                  }
                  else
                  {
                    int i15 = (localTextStyle != null) && (localTextStyle.underline) && (localTextStyle.underlineStyle == 4) ? j : l3;
                    localRECT5 = drawRunTextGDIPRaster(l2, localStyleItem3, localRECT1, i8, i15, i1, paramInt3, paramInt4);
                  }
                  localRECT3 = drawUnderlineGDIP(l2, paramInt1, i5 + i8, i10, i5 + i6, arrayOfStyleItem, i12, l12, l7, localRECT3, localRECT5, paramInt3, paramInt4, k, localRectangle);
                  localRECT4 = drawStrikeoutGDIP(l2, paramInt1, i5 + i8, arrayOfStyleItem, i12, l12, l7, localRECT4, localRECT5, paramInt3, paramInt4, k, localRectangle);
                  localRECT2 = drawBorderGDIP(l2, paramInt1, i5, i6, arrayOfStyleItem, i12, l12, l7, localRECT2, localRECT5, paramInt3, paramInt4, k, localRectangle);
                }
                else
                {
                  l11 = (localTextStyle != null) && (localTextStyle.underline) && (localTextStyle.underlineStyle == 4) ? j : l3;
                  localRECT5 = drawRunText(l1, localStyleItem3, localRECT1, i8, l11, i1, paramInt3, paramInt4);
                  localRECT3 = drawUnderline(l1, paramInt1, i5 + i8, i10, i5 + i6, arrayOfStyleItem, i12, l11, i1, localRECT3, localRECT5, paramInt3, paramInt4, localRectangle);
                  localRECT4 = drawStrikeout(l1, paramInt1, i5 + i8, arrayOfStyleItem, i12, l11, i1, localRECT4, localRECT5, paramInt3, paramInt4, localRectangle);
                  localRECT2 = drawBorder(l1, paramInt1, i5, i6, arrayOfStyleItem, i12, l11, i1, localRECT2, localRECT5, paramInt3, paramInt4, localRectangle);
                }
              }
            }
            i4 += localStyleItem3.width;
          }
        }
      }
    }
    if (l6 != 0L) {
      Gdip.SolidBrush_delete(l6);
    }
    if (l7 != 0L) {
      Gdip.SolidBrush_delete(l7);
    }
    if (l5 != 0L) {
      Gdip.SolidBrush_delete(l5);
    }
    if (l8 != 0L) {
      Gdip.Font_delete(l8);
    }
    if (n != 0) {
      OS.RestoreDC(l1, n);
    }
    if (l10 != 0L) {
      OS.DeleteObject(l10);
    }
  }
  
  RECT drawBorder(long paramLong, int paramInt1, int paramInt2, int paramInt3, StyleItem[] paramArrayOfStyleItem, int paramInt4, int paramInt5, int paramInt6, RECT paramRECT1, RECT paramRECT2, int paramInt7, int paramInt8, Rectangle paramRectangle)
  {
    StyleItem localStyleItem = paramArrayOfStyleItem[paramInt4];
    TextStyle localTextStyle = localStyleItem.style;
    if (localTextStyle == null) {
      return null;
    }
    if (localTextStyle.borderStyle == 0) {
      return null;
    }
    paramRECT1 = addClipRect(localStyleItem, paramRECT1, paramRECT2, paramInt7, paramInt8);
    int i = (paramRectangle != null) && (paramInt1 + localStyleItem.x + localStyleItem.width > paramRectangle.x + paramRectangle.width) ? 1 : 0;
    if ((paramInt4 + 1 >= paramArrayOfStyleItem.length) || (i != 0) || (!localTextStyle.isAdherentBorder(paramArrayOfStyleItem[(paramInt4 + 1)].style)))
    {
      int j = localStyleItem.x;
      int k = localStyleItem.start;
      int m = localStyleItem.start + localStyleItem.length - 1;
      for (int n = paramInt4; (n > 0) && (localTextStyle.isAdherentBorder(paramArrayOfStyleItem[(n - 1)].style)); n--)
      {
        j = paramArrayOfStyleItem[(n - 1)].x;
        k = Math.min(k, paramArrayOfStyleItem[(n - 1)].start);
        m = Math.max(m, paramArrayOfStyleItem[(n - 1)].start + paramArrayOfStyleItem[(n - 1)].length - 1);
      }
      n = (paramInt7 <= paramInt8) && (paramInt7 != -1) && (paramInt8 != -1) ? 1 : 0;
      int i1 = (n != 0) && (paramInt7 <= k) && (m <= paramInt8) ? 1 : 0;
      if (localTextStyle.borderColor != null)
      {
        paramInt5 = localTextStyle.borderColor.handle;
        paramRECT1 = null;
      }
      else if (i1 != 0)
      {
        paramInt5 = paramInt6;
        paramRECT1 = null;
      }
      else if (localTextStyle.foreground != null)
      {
        paramInt5 = localTextStyle.foreground.handle;
      }
      int i2 = 1;
      int i3 = 1;
      int i4 = 0;
      switch (localTextStyle.borderStyle)
      {
      case 1: 
        break;
      case 2: 
        i4 = 1;
        i3 = 4;
        break;
      case 4: 
        i4 = 2;
        i3 = 2;
      }
      long l1 = OS.SelectObject(paramLong, OS.GetStockObject(5));
      LOGBRUSH localLOGBRUSH = new LOGBRUSH();
      localLOGBRUSH.lbStyle = 0;
      localLOGBRUSH.lbColor = paramInt5;
      long l2 = OS.ExtCreatePen(i4 | 0x10000, i2, localLOGBRUSH, 0, null);
      long l3 = OS.SelectObject(paramLong, l2);
      RECT localRECT = new RECT();
      OS.SetRect(localRECT, paramInt1 + j, paramInt2, paramInt1 + localStyleItem.x + localStyleItem.width, paramInt2 + paramInt3);
      int i5;
      if (paramRectangle != null)
      {
        if (localRECT.left < paramRectangle.x)
        {
          i5 = localRECT.left % i3;
          localRECT.left = (paramRectangle.x / i3 * i3 + i5 - i3);
        }
        if (localRECT.right > paramRectangle.x + paramRectangle.width)
        {
          i5 = localRECT.right % i3;
          localRECT.right = ((paramRectangle.x + paramRectangle.width) / i3 * i3 + i5 + i3);
        }
      }
      OS.Rectangle(paramLong, localRECT.left, localRECT.top, localRECT.right, localRECT.bottom);
      OS.SelectObject(paramLong, l3);
      OS.DeleteObject(l2);
      if (paramRECT1 != null)
      {
        i5 = OS.SaveDC(paramLong);
        if (paramRECT1.left == -1) {
          paramRECT1.left = 0;
        }
        if (paramRECT1.right == -1) {
          paramRECT1.right = 524287;
        }
        OS.IntersectClipRect(paramLong, paramRECT1.left, paramRECT1.top, paramRECT1.right, paramRECT1.bottom);
        localLOGBRUSH.lbColor = paramInt6;
        long l4 = OS.ExtCreatePen(i4 | 0x10000, i2, localLOGBRUSH, 0, null);
        l3 = OS.SelectObject(paramLong, l4);
        OS.Rectangle(paramLong, localRECT.left, localRECT.top, localRECT.right, localRECT.bottom);
        OS.RestoreDC(paramLong, i5);
        OS.SelectObject(paramLong, l3);
        OS.DeleteObject(l4);
      }
      OS.SelectObject(paramLong, l1);
      return null;
    }
    return paramRECT1;
  }
  
  RECT drawBorderGDIP(long paramLong1, int paramInt1, int paramInt2, int paramInt3, StyleItem[] paramArrayOfStyleItem, int paramInt4, long paramLong2, long paramLong3, RECT paramRECT1, RECT paramRECT2, int paramInt5, int paramInt6, int paramInt7, Rectangle paramRectangle)
  {
    StyleItem localStyleItem = paramArrayOfStyleItem[paramInt4];
    TextStyle localTextStyle = localStyleItem.style;
    if (localTextStyle == null) {
      return null;
    }
    if (localTextStyle.borderStyle == 0) {
      return null;
    }
    paramRECT1 = addClipRect(localStyleItem, paramRECT1, paramRECT2, paramInt5, paramInt6);
    int i = (paramRectangle != null) && (paramInt1 + localStyleItem.x + localStyleItem.width > paramRectangle.x + paramRectangle.width) ? 1 : 0;
    if ((paramInt4 + 1 >= paramArrayOfStyleItem.length) || (i != 0) || (!localTextStyle.isAdherentBorder(paramArrayOfStyleItem[(paramInt4 + 1)].style)))
    {
      int j = localStyleItem.x;
      int k = localStyleItem.start;
      int m = localStyleItem.start + localStyleItem.length - 1;
      for (int n = paramInt4; (n > 0) && (localTextStyle.isAdherentBorder(paramArrayOfStyleItem[(n - 1)].style)); n--)
      {
        j = paramArrayOfStyleItem[(n - 1)].x;
        k = Math.min(k, paramArrayOfStyleItem[(n - 1)].start);
        m = Math.max(m, paramArrayOfStyleItem[(n - 1)].start + paramArrayOfStyleItem[(n - 1)].length - 1);
      }
      n = (paramInt5 <= paramInt6) && (paramInt5 != -1) && (paramInt6 != -1) ? 1 : 0;
      int i1 = (n != 0) && (paramInt5 <= k) && (m <= paramInt6) ? 1 : 0;
      long l1 = paramLong2;
      if (localTextStyle.borderColor != null)
      {
        l1 = createGdipBrush(localTextStyle.borderColor, paramInt7);
        paramRECT1 = null;
      }
      else if (i1 != 0)
      {
        l1 = paramLong3;
        paramRECT1 = null;
      }
      else if (localTextStyle.foreground != null)
      {
        l1 = createGdipBrush(localTextStyle.foreground, paramInt7);
      }
      int i2 = 1;
      int i3 = 0;
      switch (localTextStyle.borderStyle)
      {
      case 1: 
        break;
      case 2: 
        i3 = 1;
        break;
      case 4: 
        i3 = 2;
      }
      long l2 = Gdip.Pen_new(l1, i2);
      Gdip.Pen_SetDashStyle(l2, i3);
      Gdip.Graphics_SetPixelOffsetMode(paramLong1, 3);
      int i4 = Gdip.Graphics_GetSmoothingMode(paramLong1);
      Gdip.Graphics_SetSmoothingMode(paramLong1, 3);
      if (paramRECT1 != null)
      {
        int i5 = Gdip.Graphics_Save(paramLong1);
        if (paramRECT1.left == -1) {
          paramRECT1.left = 0;
        }
        if (paramRECT1.right == -1) {
          paramRECT1.right = 524287;
        }
        Rect localRect = new Rect();
        localRect.X = paramRECT1.left;
        localRect.Y = paramRECT1.top;
        localRect.Width = (paramRECT1.right - paramRECT1.left);
        localRect.Height = (paramRECT1.bottom - paramRECT1.top);
        Gdip.Graphics_SetClip(paramLong1, localRect, 4);
        Gdip.Graphics_DrawRectangle(paramLong1, l2, paramInt1 + j, paramInt2, localStyleItem.x + localStyleItem.width - j - 1, paramInt3 - 1);
        Gdip.Graphics_Restore(paramLong1, i5);
        i5 = Gdip.Graphics_Save(paramLong1);
        Gdip.Graphics_SetClip(paramLong1, localRect, 1);
        long l3 = Gdip.Pen_new(paramLong3, i2);
        Gdip.Pen_SetDashStyle(l3, i3);
        Gdip.Graphics_DrawRectangle(paramLong1, l3, paramInt1 + j, paramInt2, localStyleItem.x + localStyleItem.width - j - 1, paramInt3 - 1);
        Gdip.Pen_delete(l3);
        Gdip.Graphics_Restore(paramLong1, i5);
      }
      else
      {
        Gdip.Graphics_DrawRectangle(paramLong1, l2, paramInt1 + j, paramInt2, localStyleItem.x + localStyleItem.width - j - 1, paramInt3 - 1);
      }
      Gdip.Graphics_SetPixelOffsetMode(paramLong1, 4);
      Gdip.Graphics_SetSmoothingMode(paramLong1, i4);
      Gdip.Pen_delete(l2);
      if ((l1 != paramLong3) && (l1 != paramLong2)) {
        Gdip.SolidBrush_delete(l1);
      }
      return null;
    }
    return paramRECT1;
  }
  
  void drawRunBackground(StyleItem paramStyleItem, long paramLong1, RECT paramRECT, int paramInt1, int paramInt2, long paramLong2, boolean paramBoolean)
  {
    int i = paramStyleItem.start + paramStyleItem.length - 1;
    int j = (paramBoolean) && (paramInt1 <= paramStyleItem.start) && (paramInt2 >= i) ? 1 : 0;
    if (j != 0)
    {
      OS.SelectObject(paramLong1, paramLong2);
      OS.PatBlt(paramLong1, paramRECT.left, paramRECT.top, paramRECT.right - paramRECT.left, paramRECT.bottom - paramRECT.top, 15728673);
    }
    else
    {
      if ((paramStyleItem.style != null) && (paramStyleItem.style.background != null))
      {
        k = paramStyleItem.style.background.handle;
        long l1 = OS.CreateSolidBrush(k);
        long l2 = OS.SelectObject(paramLong1, l1);
        OS.PatBlt(paramLong1, paramRECT.left, paramRECT.top, paramRECT.right - paramRECT.left, paramRECT.bottom - paramRECT.top, 15728673);
        OS.SelectObject(paramLong1, l2);
        OS.DeleteObject(l1);
      }
      int k = (paramBoolean) && (paramInt1 <= i) && (paramStyleItem.start <= paramInt2) ? 1 : 0;
      if (k != 0)
      {
        getPartialSelection(paramStyleItem, paramInt1, paramInt2, paramRECT);
        OS.SelectObject(paramLong1, paramLong2);
        OS.PatBlt(paramLong1, paramRECT.left, paramRECT.top, paramRECT.right - paramRECT.left, paramRECT.bottom - paramRECT.top, 15728673);
      }
    }
  }
  
  void drawRunBackgroundGDIP(StyleItem paramStyleItem, long paramLong1, RECT paramRECT, int paramInt1, int paramInt2, int paramInt3, long paramLong2, boolean paramBoolean)
  {
    int i = paramStyleItem.start + paramStyleItem.length - 1;
    int j = (paramBoolean) && (paramInt1 <= paramStyleItem.start) && (paramInt2 >= i) ? 1 : 0;
    if (j != 0)
    {
      Gdip.Graphics_FillRectangle(paramLong1, paramLong2, paramRECT.left, paramRECT.top, paramRECT.right - paramRECT.left, paramRECT.bottom - paramRECT.top);
    }
    else
    {
      if ((paramStyleItem.style != null) && (paramStyleItem.style.background != null))
      {
        long l = createGdipBrush(paramStyleItem.style.background, paramInt3);
        Gdip.Graphics_FillRectangle(paramLong1, l, paramRECT.left, paramRECT.top, paramRECT.right - paramRECT.left, paramRECT.bottom - paramRECT.top);
        Gdip.SolidBrush_delete(l);
      }
      int k = (paramBoolean) && (paramInt1 <= i) && (paramStyleItem.start <= paramInt2) ? 1 : 0;
      if (k != 0)
      {
        getPartialSelection(paramStyleItem, paramInt1, paramInt2, paramRECT);
        if (paramRECT.left > paramRECT.right)
        {
          int m = paramRECT.left;
          paramRECT.left = paramRECT.right;
          paramRECT.right = m;
        }
        Gdip.Graphics_FillRectangle(paramLong1, paramLong2, paramRECT.left, paramRECT.top, paramRECT.right - paramRECT.left, paramRECT.bottom - paramRECT.top);
      }
    }
  }
  
  RECT drawRunText(long paramLong, StyleItem paramStyleItem, RECT paramRECT, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
  {
    int i = paramStyleItem.start + paramStyleItem.length - 1;
    int j = (paramInt4 <= paramInt5) && (paramInt4 != -1) && (paramInt5 != -1) ? 1 : 0;
    int k = (j != 0) && (paramInt4 <= paramStyleItem.start) && (paramInt5 >= i) ? 1 : 0;
    int m = (j != 0) && (k == 0) && (paramInt4 <= i) && (paramStyleItem.start <= paramInt5) ? 1 : 0;
    int n = (this.orientation & 0x4000000) != 0 ? -1 : 0;
    int i1 = paramRECT.left + n;
    int i2 = paramRECT.top + (paramInt1 - paramStyleItem.ascent);
    long l = getItemFont(paramStyleItem);
    OS.SelectObject(paramLong, l);
    if (k != 0) {
      paramInt2 = paramInt3;
    } else if ((paramStyleItem.style != null) && (paramStyleItem.style.foreground != null)) {
      paramInt2 = paramStyleItem.style.foreground.handle;
    }
    OS.SetTextColor(paramLong, paramInt2);
    OS.ScriptTextOut(paramLong, paramStyleItem.psc, i1, i2, 0, null, paramStyleItem.analysis, 0L, 0, paramStyleItem.glyphs, paramStyleItem.glyphCount, paramStyleItem.advances, paramStyleItem.justify, paramStyleItem.goffsets);
    if (m != 0)
    {
      getPartialSelection(paramStyleItem, paramInt4, paramInt5, paramRECT);
      OS.SetTextColor(paramLong, paramInt3);
      OS.ScriptTextOut(paramLong, paramStyleItem.psc, i1, i2, 4, paramRECT, paramStyleItem.analysis, 0L, 0, paramStyleItem.glyphs, paramStyleItem.glyphCount, paramStyleItem.advances, paramStyleItem.justify, paramStyleItem.goffsets);
    }
    return (k != 0) || (m != 0) ? paramRECT : null;
  }
  
  RECT drawRunTextGDIP(long paramLong1, StyleItem paramStyleItem, RECT paramRECT, long paramLong2, int paramInt1, long paramLong3, long paramLong4, int paramInt2, int paramInt3, int paramInt4)
  {
    int i = paramStyleItem.start + paramStyleItem.length - 1;
    int j = (paramInt2 <= paramInt3) && (paramInt2 != -1) && (paramInt3 != -1) ? 1 : 0;
    int k = (j != 0) && (paramInt2 <= paramStyleItem.start) && (paramInt3 >= i) ? 1 : 0;
    int m = (j != 0) && (k == 0) && (paramInt2 <= i) && (paramStyleItem.start <= paramInt3) ? 1 : 0;
    int n = paramRECT.top + paramInt1;
    if ((paramStyleItem.style != null) && (paramStyleItem.style.rise != 0)) {
      n -= paramStyleItem.style.rise;
    }
    int i1 = paramRECT.left;
    long l = paramLong3;
    if (k != 0) {
      l = paramLong4;
    } else if ((paramStyleItem.style != null) && (paramStyleItem.style.foreground != null)) {
      l = createGdipBrush(paramStyleItem.style.foreground, paramInt4);
    }
    int i2 = 0;
    Rect localRect = null;
    if (m != 0)
    {
      localRect = new Rect();
      getPartialSelection(paramStyleItem, paramInt2, paramInt3, paramRECT);
      localRect.X = paramRECT.left;
      localRect.Y = paramRECT.top;
      localRect.Width = (paramRECT.right - paramRECT.left);
      localRect.Height = (paramRECT.bottom - paramRECT.top);
      i2 = Gdip.Graphics_Save(paramLong1);
      Gdip.Graphics_SetClip(paramLong1, localRect, 4);
    }
    int i3 = 0;
    int i4 = (this.orientation & 0x4000000) != 0 ? 1 : 0;
    if (i4 != 0)
    {
      switch (Gdip.Brush_GetType(l))
      {
      case 4: 
        Gdip.LinearGradientBrush_ScaleTransform(l, -1.0F, 1.0F, 0);
        Gdip.LinearGradientBrush_TranslateTransform(l, -2 * i1 - paramStyleItem.width, 0.0F, 0);
        break;
      case 2: 
        Gdip.TextureBrush_ScaleTransform(l, -1.0F, 1.0F, 0);
        Gdip.TextureBrush_TranslateTransform(l, -2 * i1 - paramStyleItem.width, 0.0F, 0);
      }
      i3 = Gdip.Graphics_Save(paramLong1);
      Gdip.Graphics_ScaleTransform(paramLong1, -1.0F, 1.0F, 0);
      Gdip.Graphics_TranslateTransform(paramLong1, -2 * i1 - paramStyleItem.width, 0.0F, 0);
    }
    int[] arrayOfInt = new int[paramStyleItem.glyphCount];
    float[] arrayOfFloat = new float[paramStyleItem.glyphCount * 2];
    OS.memmove(arrayOfInt, paramStyleItem.justify != 0L ? paramStyleItem.justify : paramStyleItem.advances, paramStyleItem.glyphCount * 4);
    int i5 = i1;
    int i6 = 0;
    int i7 = 0;
    while (i6 < arrayOfInt.length)
    {
      arrayOfFloat[(i7++)] = i5;
      arrayOfFloat[(i7++)] = n;
      i5 += arrayOfInt[i6];
      i6++;
    }
    Gdip.Graphics_DrawDriverString(paramLong1, paramStyleItem.glyphs, paramStyleItem.glyphCount, paramLong2, l, arrayOfFloat, 0, 0L);
    if (m != 0)
    {
      if (i4 != 0) {
        Gdip.Graphics_Restore(paramLong1, i3);
      }
      Gdip.Graphics_Restore(paramLong1, i2);
      i2 = Gdip.Graphics_Save(paramLong1);
      Gdip.Graphics_SetClip(paramLong1, localRect, 1);
      if (i4 != 0)
      {
        i3 = Gdip.Graphics_Save(paramLong1);
        Gdip.Graphics_ScaleTransform(paramLong1, -1.0F, 1.0F, 0);
        Gdip.Graphics_TranslateTransform(paramLong1, -2 * i1 - paramStyleItem.width, 0.0F, 0);
      }
      Gdip.Graphics_DrawDriverString(paramLong1, paramStyleItem.glyphs, paramStyleItem.glyphCount, paramLong2, paramLong4, arrayOfFloat, 0, 0L);
      Gdip.Graphics_Restore(paramLong1, i2);
    }
    if (i4 != 0)
    {
      switch (Gdip.Brush_GetType(l))
      {
      case 4: 
        Gdip.LinearGradientBrush_ResetTransform(l);
        break;
      case 2: 
        Gdip.TextureBrush_ResetTransform(l);
      }
      Gdip.Graphics_Restore(paramLong1, i3);
    }
    if ((l != paramLong4) && (l != paramLong3)) {
      Gdip.SolidBrush_delete(l);
    }
    return (k != 0) || (m != 0) ? paramRECT : null;
  }
  
  RECT drawRunTextGDIPRaster(long paramLong, StyleItem paramStyleItem, RECT paramRECT, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
  {
    long l1 = 0L;
    Gdip.Graphics_SetPixelOffsetMode(paramLong, 3);
    long l2 = Gdip.Region_new();
    if (l2 == 0L) {
      SWT.error(2);
    }
    Gdip.Graphics_GetClip(paramLong, l2);
    if (!Gdip.Region_IsInfinite(l2, paramLong)) {
      l1 = Gdip.Region_GetHRGN(l2, paramLong);
    }
    Gdip.Region_delete(l2);
    Gdip.Graphics_SetPixelOffsetMode(paramLong, 4);
    float[] arrayOfFloat = null;
    long l3 = Gdip.Matrix_new(1.0F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F);
    if (l3 == 0L) {
      SWT.error(2);
    }
    Gdip.Graphics_GetTransform(paramLong, l3);
    if (!Gdip.Matrix_IsIdentity(l3))
    {
      arrayOfFloat = new float[6];
      Gdip.Matrix_GetElements(l3, arrayOfFloat);
    }
    Gdip.Matrix_delete(l3);
    long l4 = Gdip.Graphics_GetHDC(paramLong);
    int i = OS.SaveDC(l4);
    if (arrayOfFloat != null)
    {
      OS.SetGraphicsMode(l4, 2);
      OS.SetWorldTransform(l4, arrayOfFloat);
    }
    if (l1 != 0L)
    {
      OS.SelectClipRgn(l4, l1);
      OS.DeleteObject(l1);
    }
    if ((this.orientation & 0x4000000) != 0) {
      OS.SetLayout(l4, OS.GetLayout(l4) | 0x1);
    }
    OS.SetBkMode(l4, 1);
    RECT localRECT = drawRunText(l4, paramStyleItem, paramRECT, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
    OS.RestoreDC(l4, i);
    Gdip.Graphics_ReleaseHDC(paramLong, l4);
    return localRECT;
  }
  
  RECT drawStrikeout(long paramLong, int paramInt1, int paramInt2, StyleItem[] paramArrayOfStyleItem, int paramInt3, int paramInt4, int paramInt5, RECT paramRECT1, RECT paramRECT2, int paramInt6, int paramInt7, Rectangle paramRectangle)
  {
    StyleItem localStyleItem = paramArrayOfStyleItem[paramInt3];
    TextStyle localTextStyle = localStyleItem.style;
    if (localTextStyle == null) {
      return null;
    }
    if (!localTextStyle.strikeout) {
      return null;
    }
    paramRECT1 = addClipRect(localStyleItem, paramRECT1, paramRECT2, paramInt6, paramInt7);
    int i = (paramRectangle != null) && (paramInt1 + localStyleItem.x + localStyleItem.width > paramRectangle.x + paramRectangle.width) ? 1 : 0;
    if ((paramInt3 + 1 >= paramArrayOfStyleItem.length) || (i != 0) || (!localTextStyle.isAdherentStrikeout(paramArrayOfStyleItem[(paramInt3 + 1)].style)))
    {
      int j = localStyleItem.x;
      int k = localStyleItem.start;
      int m = localStyleItem.start + localStyleItem.length - 1;
      for (int n = paramInt3; (n > 0) && (localTextStyle.isAdherentStrikeout(paramArrayOfStyleItem[(n - 1)].style)); n--)
      {
        j = paramArrayOfStyleItem[(n - 1)].x;
        k = Math.min(k, paramArrayOfStyleItem[(n - 1)].start);
        m = Math.max(m, paramArrayOfStyleItem[(n - 1)].start + paramArrayOfStyleItem[(n - 1)].length - 1);
      }
      n = (paramInt6 <= paramInt7) && (paramInt6 != -1) && (paramInt7 != -1) ? 1 : 0;
      int i1 = (n != 0) && (paramInt6 <= k) && (m <= paramInt7) ? 1 : 0;
      if (localTextStyle.strikeoutColor != null)
      {
        paramInt4 = localTextStyle.strikeoutColor.handle;
        paramRECT1 = null;
      }
      else if (i1 != 0)
      {
        paramInt4 = paramInt5;
        paramRECT1 = null;
      }
      else if (localTextStyle.foreground != null)
      {
        paramInt4 = localTextStyle.foreground.handle;
      }
      RECT localRECT = new RECT();
      OS.SetRect(localRECT, paramInt1 + j, paramInt2 - localStyleItem.strikeoutPos - localTextStyle.rise, paramInt1 + localStyleItem.x + localStyleItem.width, paramInt2 - localStyleItem.strikeoutPos + localStyleItem.strikeoutThickness - localTextStyle.rise);
      long l1 = OS.CreateSolidBrush(paramInt4);
      OS.FillRect(paramLong, localRECT, l1);
      OS.DeleteObject(l1);
      if (paramRECT1 != null)
      {
        long l2 = OS.CreateSolidBrush(paramInt5);
        if (paramRECT1.left == -1) {
          paramRECT1.left = 0;
        }
        if (paramRECT1.right == -1) {
          paramRECT1.right = 524287;
        }
        OS.SetRect(paramRECT1, Math.max(localRECT.left, paramRECT1.left), localRECT.top, Math.min(localRECT.right, paramRECT1.right), localRECT.bottom);
        OS.FillRect(paramLong, paramRECT1, l2);
        OS.DeleteObject(l2);
      }
      return null;
    }
    return paramRECT1;
  }
  
  RECT drawStrikeoutGDIP(long paramLong1, int paramInt1, int paramInt2, StyleItem[] paramArrayOfStyleItem, int paramInt3, long paramLong2, long paramLong3, RECT paramRECT1, RECT paramRECT2, int paramInt4, int paramInt5, int paramInt6, Rectangle paramRectangle)
  {
    StyleItem localStyleItem = paramArrayOfStyleItem[paramInt3];
    TextStyle localTextStyle = localStyleItem.style;
    if (localTextStyle == null) {
      return null;
    }
    if (!localTextStyle.strikeout) {
      return null;
    }
    paramRECT1 = addClipRect(localStyleItem, paramRECT1, paramRECT2, paramInt4, paramInt5);
    int i = (paramRectangle != null) && (paramInt1 + localStyleItem.x + localStyleItem.width > paramRectangle.x + paramRectangle.width) ? 1 : 0;
    if ((paramInt3 + 1 >= paramArrayOfStyleItem.length) || (i != 0) || (!localTextStyle.isAdherentStrikeout(paramArrayOfStyleItem[(paramInt3 + 1)].style)))
    {
      int j = localStyleItem.x;
      int k = localStyleItem.start;
      int m = localStyleItem.start + localStyleItem.length - 1;
      for (int n = paramInt3; (n > 0) && (localTextStyle.isAdherentStrikeout(paramArrayOfStyleItem[(n - 1)].style)); n--)
      {
        j = paramArrayOfStyleItem[(n - 1)].x;
        k = Math.min(k, paramArrayOfStyleItem[(n - 1)].start);
        m = Math.max(m, paramArrayOfStyleItem[(n - 1)].start + paramArrayOfStyleItem[(n - 1)].length - 1);
      }
      n = (paramInt4 <= paramInt5) && (paramInt4 != -1) && (paramInt5 != -1) ? 1 : 0;
      int i1 = (n != 0) && (paramInt4 <= k) && (m <= paramInt5) ? 1 : 0;
      long l = paramLong2;
      if (localTextStyle.strikeoutColor != null)
      {
        l = createGdipBrush(localTextStyle.strikeoutColor, paramInt6);
        paramRECT1 = null;
      }
      else if (i1 != 0)
      {
        l = paramLong3;
        paramRECT1 = null;
      }
      else if (localTextStyle.foreground != null)
      {
        l = createGdipBrush(localTextStyle.foreground, paramInt6);
      }
      if (paramRECT1 != null)
      {
        int i2 = Gdip.Graphics_Save(paramLong1);
        if (paramRECT1.left == -1) {
          paramRECT1.left = 0;
        }
        if (paramRECT1.right == -1) {
          paramRECT1.right = 524287;
        }
        Rect localRect = new Rect();
        localRect.X = paramRECT1.left;
        localRect.Y = paramRECT1.top;
        localRect.Width = (paramRECT1.right - paramRECT1.left);
        localRect.Height = (paramRECT1.bottom - paramRECT1.top);
        Gdip.Graphics_SetClip(paramLong1, localRect, 4);
        Gdip.Graphics_FillRectangle(paramLong1, l, paramInt1 + j, paramInt2 - localStyleItem.strikeoutPos - localTextStyle.rise, localStyleItem.x + localStyleItem.width - j, localStyleItem.strikeoutThickness);
        Gdip.Graphics_Restore(paramLong1, i2);
        i2 = Gdip.Graphics_Save(paramLong1);
        Gdip.Graphics_SetClip(paramLong1, localRect, 1);
        Gdip.Graphics_FillRectangle(paramLong1, paramLong3, paramInt1 + j, paramInt2 - localStyleItem.strikeoutPos - localTextStyle.rise, localStyleItem.x + localStyleItem.width - j, localStyleItem.strikeoutThickness);
        Gdip.Graphics_Restore(paramLong1, i2);
      }
      else
      {
        Gdip.Graphics_FillRectangle(paramLong1, l, paramInt1 + j, paramInt2 - localStyleItem.strikeoutPos - localTextStyle.rise, localStyleItem.x + localStyleItem.width - j, localStyleItem.strikeoutThickness);
      }
      if ((l != paramLong3) && (l != paramLong2)) {
        Gdip.SolidBrush_delete(l);
      }
      return null;
    }
    return paramRECT1;
  }
  
  RECT drawUnderline(long paramLong, int paramInt1, int paramInt2, int paramInt3, int paramInt4, StyleItem[] paramArrayOfStyleItem, int paramInt5, int paramInt6, int paramInt7, RECT paramRECT1, RECT paramRECT2, int paramInt8, int paramInt9, Rectangle paramRectangle)
  {
    StyleItem localStyleItem = paramArrayOfStyleItem[paramInt5];
    TextStyle localTextStyle = localStyleItem.style;
    if (localTextStyle == null) {
      return null;
    }
    if (!localTextStyle.underline) {
      return null;
    }
    paramRECT1 = addClipRect(localStyleItem, paramRECT1, paramRECT2, paramInt8, paramInt9);
    int i = (paramRectangle != null) && (paramInt1 + localStyleItem.x + localStyleItem.width > paramRectangle.x + paramRectangle.width) ? 1 : 0;
    if ((paramInt5 + 1 >= paramArrayOfStyleItem.length) || (i != 0) || (!localTextStyle.isAdherentUnderline(paramArrayOfStyleItem[(paramInt5 + 1)].style)))
    {
      int j = localStyleItem.x;
      int k = localStyleItem.start;
      int m = localStyleItem.start + localStyleItem.length - 1;
      for (int n = paramInt5; (n > 0) && (localTextStyle.isAdherentUnderline(paramArrayOfStyleItem[(n - 1)].style)); n--)
      {
        j = paramArrayOfStyleItem[(n - 1)].x;
        k = Math.min(k, paramArrayOfStyleItem[(n - 1)].start);
        m = Math.max(m, paramArrayOfStyleItem[(n - 1)].start + paramArrayOfStyleItem[(n - 1)].length - 1);
      }
      n = (paramInt8 <= paramInt9) && (paramInt8 != -1) && (paramInt9 != -1) ? 1 : 0;
      int i1 = (n != 0) && (paramInt8 <= k) && (m <= paramInt9) ? 1 : 0;
      if (localTextStyle.underlineColor != null)
      {
        paramInt6 = localTextStyle.underlineColor.handle;
        paramRECT1 = null;
      }
      else if (i1 != 0)
      {
        paramInt6 = paramInt7;
        paramRECT1 = null;
      }
      else if (localTextStyle.foreground != null)
      {
        paramInt6 = localTextStyle.foreground.handle;
      }
      RECT localRECT = new RECT();
      OS.SetRect(localRECT, paramInt1 + j, paramInt2 - paramInt3 - localTextStyle.rise, paramInt1 + localStyleItem.x + localStyleItem.width, paramInt2 - paramInt3 + localStyleItem.underlineThickness - localTextStyle.rise);
      if (paramRECT1 != null)
      {
        if (paramRECT1.left == -1) {
          paramRECT1.left = 0;
        }
        if (paramRECT1.right == -1) {
          paramRECT1.right = 524287;
        }
        OS.SetRect(paramRECT1, Math.max(localRECT.left, paramRECT1.left), localRECT.top, Math.min(localRECT.right, paramRECT1.right), localRECT.bottom);
      }
      int i2;
      long l3;
      long l4;
      switch (localTextStyle.underlineStyle)
      {
      case 2: 
      case 3: 
        i2 = 1;
        int i3 = 2 * i2;
        int i4 = Math.min(localRECT.top - i3 / 2, paramInt4 - i3 - 1);
        int[] arrayOfInt = computePolyline(localRECT.left, i4, localRECT.right, i4 + i3);
        l3 = OS.CreatePen(0, i2, paramInt6);
        l4 = OS.SelectObject(paramLong, l3);
        int i6 = OS.SaveDC(paramLong);
        OS.IntersectClipRect(paramLong, localRECT.left, i4, localRECT.right + 1, i4 + i3 + 1);
        OS.Polyline(paramLong, arrayOfInt, arrayOfInt.length / 2);
        int i7 = arrayOfInt.length;
        if ((i7 >= 2) && (i2 <= 1)) {
          OS.SetPixel(paramLong, arrayOfInt[(i7 - 2)], arrayOfInt[(i7 - 1)], paramInt6);
        }
        OS.SelectObject(paramLong, l4);
        OS.DeleteObject(l3);
        OS.RestoreDC(paramLong, i6);
        if (paramRECT1 != null)
        {
          l3 = OS.CreatePen(0, i2, paramInt7);
          l4 = OS.SelectObject(paramLong, l3);
          i6 = OS.SaveDC(paramLong);
          OS.IntersectClipRect(paramLong, paramRECT1.left, i4, paramRECT1.right + 1, i4 + i3 + 1);
          OS.Polyline(paramLong, arrayOfInt, arrayOfInt.length / 2);
          if ((i7 >= 2) && (i2 <= 1)) {
            OS.SetPixel(paramLong, arrayOfInt[(i7 - 2)], arrayOfInt[(i7 - 1)], paramInt7);
          }
          OS.SelectObject(paramLong, l4);
          OS.DeleteObject(l3);
          OS.RestoreDC(paramLong, i6);
        }
        break;
      case 0: 
      case 1: 
      case 4: 
      case 196608: 
        if (localTextStyle.underlineStyle == 196608)
        {
          localRECT.top -= localStyleItem.underlineThickness;
          if (paramRECT1 != null) {
            paramRECT1.top -= localStyleItem.underlineThickness;
          }
        }
        i2 = localTextStyle.underlineStyle == 1 ? localRECT.bottom + localStyleItem.underlineThickness * 2 : localRECT.bottom;
        if (i2 > paramInt4)
        {
          OS.OffsetRect(localRECT, 0, paramInt4 - i2);
          if (paramRECT1 != null) {
            OS.OffsetRect(paramRECT1, 0, paramInt4 - i2);
          }
        }
        long l1 = OS.CreateSolidBrush(paramInt6);
        OS.FillRect(paramLong, localRECT, l1);
        if (localTextStyle.underlineStyle == 1)
        {
          OS.SetRect(localRECT, localRECT.left, localRECT.top + localStyleItem.underlineThickness * 2, localRECT.right, localRECT.bottom + localStyleItem.underlineThickness * 2);
          OS.FillRect(paramLong, localRECT, l1);
        }
        OS.DeleteObject(l1);
        if (paramRECT1 != null)
        {
          long l2 = OS.CreateSolidBrush(paramInt7);
          OS.FillRect(paramLong, paramRECT1, l2);
          if (localTextStyle.underlineStyle == 1)
          {
            OS.SetRect(paramRECT1, paramRECT1.left, localRECT.top, paramRECT1.right, localRECT.bottom);
            OS.FillRect(paramLong, paramRECT1, l2);
          }
          OS.DeleteObject(l2);
        }
        break;
      case 65536: 
      case 131072: 
        int i5 = localTextStyle.underlineStyle == 131072 ? 1 : 2;
        l3 = OS.CreatePen(i5, 1, paramInt6);
        l4 = OS.SelectObject(paramLong, l3);
        OS.SetRect(localRECT, localRECT.left, paramInt2 + localStyleItem.descent, localRECT.right, paramInt2 + localStyleItem.descent + localStyleItem.underlineThickness);
        OS.MoveToEx(paramLong, localRECT.left, localRECT.top, 0L);
        OS.LineTo(paramLong, localRECT.right, localRECT.top);
        OS.SelectObject(paramLong, l4);
        OS.DeleteObject(l3);
        if (paramRECT1 != null)
        {
          l3 = OS.CreatePen(i5, 1, paramInt7);
          l4 = OS.SelectObject(paramLong, l3);
          OS.SetRect(paramRECT1, paramRECT1.left, localRECT.top, paramRECT1.right, localRECT.bottom);
          OS.MoveToEx(paramLong, paramRECT1.left, paramRECT1.top, 0L);
          OS.LineTo(paramLong, paramRECT1.right, paramRECT1.top);
          OS.SelectObject(paramLong, l4);
          OS.DeleteObject(l3);
        }
        break;
      }
      return null;
    }
    return paramRECT1;
  }
  
  RECT drawUnderlineGDIP(long paramLong1, int paramInt1, int paramInt2, int paramInt3, int paramInt4, StyleItem[] paramArrayOfStyleItem, int paramInt5, long paramLong2, long paramLong3, RECT paramRECT1, RECT paramRECT2, int paramInt6, int paramInt7, int paramInt8, Rectangle paramRectangle)
  {
    StyleItem localStyleItem = paramArrayOfStyleItem[paramInt5];
    TextStyle localTextStyle = localStyleItem.style;
    if (localTextStyle == null) {
      return null;
    }
    if (!localTextStyle.underline) {
      return null;
    }
    paramRECT1 = addClipRect(localStyleItem, paramRECT1, paramRECT2, paramInt6, paramInt7);
    int i = (paramRectangle != null) && (paramInt1 + localStyleItem.x + localStyleItem.width > paramRectangle.x + paramRectangle.width) ? 1 : 0;
    if ((paramInt5 + 1 >= paramArrayOfStyleItem.length) || (i != 0) || (!localTextStyle.isAdherentUnderline(paramArrayOfStyleItem[(paramInt5 + 1)].style)))
    {
      int j = localStyleItem.x;
      int k = localStyleItem.start;
      int m = localStyleItem.start + localStyleItem.length - 1;
      for (int n = paramInt5; (n > 0) && (localTextStyle.isAdherentUnderline(paramArrayOfStyleItem[(n - 1)].style)); n--)
      {
        j = paramArrayOfStyleItem[(n - 1)].x;
        k = Math.min(k, paramArrayOfStyleItem[(n - 1)].start);
        m = Math.max(m, paramArrayOfStyleItem[(n - 1)].start + paramArrayOfStyleItem[(n - 1)].length - 1);
      }
      n = (paramInt6 <= paramInt7) && (paramInt6 != -1) && (paramInt7 != -1) ? 1 : 0;
      int i1 = (n != 0) && (paramInt6 <= k) && (m <= paramInt7) ? 1 : 0;
      long l1 = paramLong2;
      if (localTextStyle.underlineColor != null)
      {
        l1 = createGdipBrush(localTextStyle.underlineColor, paramInt8);
        paramRECT1 = null;
      }
      else if (i1 != 0)
      {
        l1 = paramLong3;
        paramRECT1 = null;
      }
      else if (localTextStyle.foreground != null)
      {
        l1 = createGdipBrush(localTextStyle.foreground, paramInt8);
      }
      RECT localRECT = new RECT();
      OS.SetRect(localRECT, paramInt1 + j, paramInt2 - paramInt3 - localTextStyle.rise, paramInt1 + localStyleItem.x + localStyleItem.width, paramInt2 - paramInt3 + localStyleItem.underlineThickness - localTextStyle.rise);
      Rect localRect1 = null;
      if (paramRECT1 != null)
      {
        if (paramRECT1.left == -1) {
          paramRECT1.left = 0;
        }
        if (paramRECT1.right == -1) {
          paramRECT1.right = 524287;
        }
        OS.SetRect(paramRECT1, Math.max(localRECT.left, paramRECT1.left), localRECT.top, Math.min(localRECT.right, paramRECT1.right), localRECT.bottom);
        localRect1 = new Rect();
        localRect1.X = paramRECT1.left;
        localRect1.Y = paramRECT1.top;
        localRect1.Width = (paramRECT1.right - paramRECT1.left);
        localRect1.Height = (paramRECT1.bottom - paramRECT1.top);
      }
      int i2 = 0;
      Gdip.Graphics_SetPixelOffsetMode(paramLong1, 3);
      int i3 = Gdip.Graphics_GetSmoothingMode(paramLong1);
      Gdip.Graphics_SetSmoothingMode(paramLong1, 3);
      int i4;
      long l3;
      switch (localTextStyle.underlineStyle)
      {
      case 2: 
      case 3: 
        i4 = 1;
        int i5 = 2 * i4;
        int i6 = Math.min(localRECT.top - i5 / 2, paramInt4 - i5 - 1);
        int[] arrayOfInt = computePolyline(localRECT.left, i6, localRECT.right, i6 + i5);
        l3 = Gdip.Pen_new(l1, i4);
        i2 = Gdip.Graphics_Save(paramLong1);
        if (localRect1 != null)
        {
          Gdip.Graphics_SetClip(paramLong1, localRect1, 4);
        }
        else
        {
          Rect localRect2 = new Rect();
          localRect2.X = localRECT.left;
          localRect2.Y = i6;
          localRect2.Width = (localRECT.right - localRECT.left);
          localRect2.Height = (i5 + 1);
          Gdip.Graphics_SetClip(paramLong1, localRect2, 1);
        }
        Gdip.Graphics_DrawLines(paramLong1, l3, arrayOfInt, arrayOfInt.length / 2);
        if (localRect1 != null)
        {
          long l4 = Gdip.Pen_new(paramLong3, i4);
          Gdip.Graphics_Restore(paramLong1, i2);
          i2 = Gdip.Graphics_Save(paramLong1);
          Gdip.Graphics_SetClip(paramLong1, localRect1, 1);
          Gdip.Graphics_DrawLines(paramLong1, l4, arrayOfInt, arrayOfInt.length / 2);
          Gdip.Pen_delete(l4);
        }
        Gdip.Graphics_Restore(paramLong1, i2);
        Gdip.Pen_delete(l3);
        if (i2 != 0) {
          Gdip.Graphics_Restore(paramLong1, i2);
        }
        break;
      case 0: 
      case 1: 
      case 4: 
      case 196608: 
        if (localTextStyle.underlineStyle == 196608) {
          localRECT.top -= localStyleItem.underlineThickness;
        }
        i4 = localTextStyle.underlineStyle == 1 ? localRECT.bottom + localStyleItem.underlineThickness * 2 : localRECT.bottom;
        if (i4 > paramInt4) {
          OS.OffsetRect(localRECT, 0, paramInt4 - i4);
        }
        if (localRect1 != null)
        {
          localRect1.Y = localRECT.top;
          if (localTextStyle.underlineStyle == 196608) {
            localRect1.Height = (localStyleItem.underlineThickness * 2);
          }
          if (localTextStyle.underlineStyle == 1) {
            localRect1.Height = (localStyleItem.underlineThickness * 3);
          }
          i2 = Gdip.Graphics_Save(paramLong1);
          Gdip.Graphics_SetClip(paramLong1, localRect1, 4);
        }
        Gdip.Graphics_FillRectangle(paramLong1, l1, localRECT.left, localRECT.top, localRECT.right - localRECT.left, localRECT.bottom - localRECT.top);
        if (localTextStyle.underlineStyle == 1) {
          Gdip.Graphics_FillRectangle(paramLong1, l1, localRECT.left, localRECT.top + localStyleItem.underlineThickness * 2, localRECT.right - localRECT.left, localRECT.bottom - localRECT.top);
        }
        if (localRect1 != null)
        {
          Gdip.Graphics_Restore(paramLong1, i2);
          i2 = Gdip.Graphics_Save(paramLong1);
          Gdip.Graphics_SetClip(paramLong1, localRect1, 1);
          Gdip.Graphics_FillRectangle(paramLong1, paramLong3, localRECT.left, localRECT.top, localRECT.right - localRECT.left, localRECT.bottom - localRECT.top);
          if (localTextStyle.underlineStyle == 1) {
            Gdip.Graphics_FillRectangle(paramLong1, paramLong3, localRECT.left, localRECT.top + localStyleItem.underlineThickness * 2, localRECT.right - localRECT.left, localRECT.bottom - localRECT.top);
          }
          Gdip.Graphics_Restore(paramLong1, i2);
        }
        break;
      case 65536: 
      case 131072: 
        long l2 = Gdip.Pen_new(l1, 1.0F);
        int i7 = localTextStyle.underlineStyle == 65536 ? 2 : 1;
        Gdip.Pen_SetDashStyle(l2, i7);
        if (localRect1 != null)
        {
          i2 = Gdip.Graphics_Save(paramLong1);
          Gdip.Graphics_SetClip(paramLong1, localRect1, 4);
        }
        Gdip.Graphics_DrawLine(paramLong1, l2, localRECT.left, paramInt2 + localStyleItem.descent, localStyleItem.width - localStyleItem.length, paramInt2 + localStyleItem.descent);
        if (localRect1 != null)
        {
          Gdip.Graphics_Restore(paramLong1, i2);
          i2 = Gdip.Graphics_Save(paramLong1);
          Gdip.Graphics_SetClip(paramLong1, localRect1, 1);
          l3 = Gdip.Pen_new(l1, 1.0F);
          Gdip.Pen_SetDashStyle(l3, i7);
          Gdip.Graphics_DrawLine(paramLong1, l3, localRECT.left, paramInt2 + localStyleItem.descent, localStyleItem.width - localStyleItem.length, paramInt2 + localStyleItem.descent);
          Gdip.Graphics_Restore(paramLong1, i2);
          Gdip.Pen_delete(l3);
        }
        Gdip.Pen_delete(l2);
        break;
      }
      if ((l1 != paramLong3) && (l1 != paramLong2)) {
        Gdip.SolidBrush_delete(l1);
      }
      Gdip.Graphics_SetPixelOffsetMode(paramLong1, 4);
      Gdip.Graphics_SetSmoothingMode(paramLong1, i3);
      return null;
    }
    return paramRECT1;
  }
  
  void freeRuns()
  {
    if (this.allRuns == null) {
      return;
    }
    for (int i = 0; i < this.allRuns.length; i++)
    {
      StyleItem localStyleItem = this.allRuns[i];
      localStyleItem.free();
    }
    this.allRuns = null;
    this.runs = ((StyleItem[][])null);
    this.segmentsText = null;
  }
  
  public int getAlignment()
  {
    checkLayout();
    return this.alignment;
  }
  
  public int getAscent()
  {
    checkLayout();
    return this.ascent;
  }
  
  public Rectangle getBounds()
  {
    checkLayout();
    computeRuns(null);
    int i = 0;
    if (this.wrapWidth != -1) {
      i = this.wrapWidth;
    } else {
      for (int j = 0; j < this.runs.length; j++) {
        i = Math.max(i, this.lineWidth[j] + getLineIndent(j));
      }
    }
    return new Rectangle(0, 0, i, this.lineY[(this.lineY.length - 1)]);
  }
  
  public Rectangle getBounds(int paramInt1, int paramInt2)
  {
    checkLayout();
    computeRuns(null);
    int i = this.text.length();
    if (i == 0) {
      return new Rectangle(0, 0, 0, 0);
    }
    if (paramInt1 > paramInt2) {
      return new Rectangle(0, 0, 0, 0);
    }
    paramInt1 = Math.min(Math.max(0, paramInt1), i - 1);
    paramInt2 = Math.min(Math.max(0, paramInt2), i - 1);
    paramInt1 = translateOffset(paramInt1);
    paramInt2 = translateOffset(paramInt2);
    i = this.segmentsText.length();
    int j = this.segmentsText.charAt(paramInt1);
    if ((56320 <= j) && (j <= 57343) && (paramInt1 - 1 >= 0))
    {
      j = this.segmentsText.charAt(paramInt1 - 1);
      if ((55296 <= j) && (j <= 56319)) {
        paramInt1--;
      }
    }
    j = this.segmentsText.charAt(paramInt2);
    if ((55296 <= j) && (j <= 56319) && (paramInt2 + 1 < i))
    {
      j = this.segmentsText.charAt(paramInt2 + 1);
      if ((56320 <= j) && (j <= 57343)) {
        paramInt2++;
      }
    }
    int k = Integer.MAX_VALUE;
    int m = 0;
    int n = Integer.MAX_VALUE;
    int i1 = 0;
    int i2 = (this.orientation & 0x4000000) != 0 ? 1 : 0;
    for (int i3 = 0; i3 < this.allRuns.length - 1; i3++)
    {
      StyleItem localStyleItem = this.allRuns[i3];
      int i4 = localStyleItem.start + localStyleItem.length;
      if (i4 > paramInt1)
      {
        if (localStyleItem.start > paramInt2) {
          break;
        }
        int i5 = localStyleItem.x;
        int i6 = localStyleItem.x + localStyleItem.width;
        Object localObject;
        long l;
        if ((localStyleItem.start <= paramInt1) && (paramInt1 < i4))
        {
          i7 = 0;
          if ((localStyleItem.style != null) && (localStyleItem.style.metrics != null))
          {
            localObject = localStyleItem.style.metrics;
            i7 = ((GlyphMetrics)localObject).width * (paramInt1 - localStyleItem.start);
          }
          else if (!localStyleItem.tab)
          {
            localObject = new int[1];
            l = localStyleItem.justify != 0L ? localStyleItem.justify : localStyleItem.advances;
            OS.ScriptCPtoX(paramInt1 - localStyleItem.start, false, localStyleItem.length, localStyleItem.glyphCount, localStyleItem.clusters, localStyleItem.visAttrs, l, localStyleItem.analysis, (int[])localObject);
            i7 = i2 != 0 ? localStyleItem.width - localObject[0] : localObject[0];
          }
          if ((localStyleItem.analysis.fRTL ^ i2)) {
            i6 = localStyleItem.x + i7;
          } else {
            i5 = localStyleItem.x + i7;
          }
        }
        if ((localStyleItem.start <= paramInt2) && (paramInt2 < i4))
        {
          i7 = localStyleItem.width;
          if ((localStyleItem.style != null) && (localStyleItem.style.metrics != null))
          {
            localObject = localStyleItem.style.metrics;
            i7 = ((GlyphMetrics)localObject).width * (paramInt2 - localStyleItem.start + 1);
          }
          else if (!localStyleItem.tab)
          {
            localObject = new int[1];
            l = localStyleItem.justify != 0L ? localStyleItem.justify : localStyleItem.advances;
            OS.ScriptCPtoX(paramInt2 - localStyleItem.start, true, localStyleItem.length, localStyleItem.glyphCount, localStyleItem.clusters, localStyleItem.visAttrs, l, localStyleItem.analysis, (int[])localObject);
            i7 = i2 != 0 ? localStyleItem.width - localObject[0] : localObject[0];
          }
          if ((localStyleItem.analysis.fRTL ^ i2)) {
            i5 = localStyleItem.x + i7;
          } else {
            i6 = localStyleItem.x + i7;
          }
        }
        for (int i7 = 0; (i7 < this.runs.length) && (this.lineOffset[(i7 + 1)] <= localStyleItem.start); i7++) {}
        k = Math.min(k, i5);
        m = Math.max(m, i6);
        n = Math.min(n, this.lineY[i7]);
        i1 = Math.max(i1, this.lineY[(i7 + 1)] - this.lineSpacing);
      }
    }
    return new Rectangle(k, n, m - k, i1 - n);
  }
  
  public int getDescent()
  {
    checkLayout();
    return this.descent;
  }
  
  public Font getFont()
  {
    checkLayout();
    return this.font;
  }
  
  public int getIndent()
  {
    checkLayout();
    return this.indent;
  }
  
  public boolean getJustify()
  {
    checkLayout();
    return this.justify;
  }
  
  long getItemFont(StyleItem paramStyleItem)
  {
    if (paramStyleItem.fallbackFont != 0L) {
      return paramStyleItem.fallbackFont;
    }
    if ((paramStyleItem.style != null) && (paramStyleItem.style.font != null)) {
      return paramStyleItem.style.font.handle;
    }
    if (this.font != null) {
      return this.font.handle;
    }
    return this.device.systemFont.handle;
  }
  
  public int getLevel(int paramInt)
  {
    checkLayout();
    computeRuns(null);
    int i = this.text.length();
    if ((0 > paramInt) || (paramInt > i)) {
      SWT.error(6);
    }
    paramInt = translateOffset(paramInt);
    for (int j = 1; j < this.allRuns.length; j++) {
      if (this.allRuns[j].start > paramInt) {
        return this.allRuns[(j - 1)].analysis.s.uBidiLevel;
      }
    }
    return (this.textDirection & 0x4000000) != 0 ? 1 : 0;
  }
  
  public Rectangle getLineBounds(int paramInt)
  {
    checkLayout();
    computeRuns(null);
    if ((0 > paramInt) || (paramInt >= this.runs.length)) {
      SWT.error(6);
    }
    int i = getLineIndent(paramInt);
    int j = this.lineY[paramInt];
    int k = this.lineWidth[paramInt];
    int m = this.lineY[(paramInt + 1)] - j - this.lineSpacing;
    return new Rectangle(i, j, k, m);
  }
  
  public int getLineCount()
  {
    checkLayout();
    computeRuns(null);
    return this.runs.length;
  }
  
  int getLineIndent(int paramInt)
  {
    int i = this.wrapIndent;
    Object localObject;
    if (paramInt == 0)
    {
      i = this.indent;
    }
    else
    {
      StyleItem[] arrayOfStyleItem = this.runs[(paramInt - 1)];
      localObject = arrayOfStyleItem[(arrayOfStyleItem.length - 1)];
      if ((((StyleItem)localObject).lineBreak) && (!((StyleItem)localObject).softBreak)) {
        i = this.indent;
      }
    }
    if (this.wrapWidth != -1)
    {
      int j = 1;
      if (this.justify)
      {
        localObject = this.runs[paramInt];
        if (localObject[(localObject.length - 1)].softBreak) {
          j = 0;
        }
      }
      if (j != 0)
      {
        int k = this.lineWidth[paramInt] + i;
        switch (this.alignment)
        {
        case 16777216: 
          i += (this.wrapWidth - k) / 2;
          break;
        case 131072: 
          i += this.wrapWidth - k;
        }
      }
    }
    return i;
  }
  
  public int getLineIndex(int paramInt)
  {
    checkLayout();
    computeRuns(null);
    int i = this.text.length();
    if ((0 > paramInt) || (paramInt > i)) {
      SWT.error(6);
    }
    paramInt = translateOffset(paramInt);
    for (int j = 0; j < this.runs.length; j++) {
      if (this.lineOffset[(j + 1)] > paramInt) {
        return j;
      }
    }
    return this.runs.length - 1;
  }
  
  public FontMetrics getLineMetrics(int paramInt)
  {
    checkLayout();
    computeRuns(null);
    if ((0 > paramInt) || (paramInt >= this.runs.length)) {
      SWT.error(6);
    }
    long l1 = this.device.internal_new_GC(null);
    long l2 = OS.CreateCompatibleDC(l1);
    TEXTMETRICA localTEXTMETRICA = OS.IsUnicode ? new TEXTMETRICW() : new TEXTMETRICA();
    OS.SelectObject(l2, this.font != null ? this.font.handle : this.device.systemFont.handle);
    OS.GetTextMetrics(l2, localTEXTMETRICA);
    OS.DeleteDC(l2);
    this.device.internal_dispose_GC(l1, null);
    int i = Math.max(localTEXTMETRICA.tmAscent, this.ascent);
    int j = Math.max(localTEXTMETRICA.tmDescent, this.descent);
    int k = localTEXTMETRICA.tmInternalLeading;
    if (this.text.length() != 0)
    {
      StyleItem[] arrayOfStyleItem = this.runs[paramInt];
      for (int m = 0; m < arrayOfStyleItem.length; m++)
      {
        StyleItem localStyleItem = arrayOfStyleItem[m];
        if (localStyleItem.ascent > i)
        {
          i = localStyleItem.ascent;
          k = localStyleItem.leading;
        }
        j = Math.max(j, localStyleItem.descent);
      }
    }
    localTEXTMETRICA.tmAscent = i;
    localTEXTMETRICA.tmDescent = j;
    localTEXTMETRICA.tmHeight = (i + j);
    localTEXTMETRICA.tmInternalLeading = k;
    localTEXTMETRICA.tmAveCharWidth = 0;
    return FontMetrics.win32_new(localTEXTMETRICA);
  }
  
  public int[] getLineOffsets()
  {
    checkLayout();
    computeRuns(null);
    int[] arrayOfInt = new int[this.lineOffset.length];
    for (int i = 0; i < arrayOfInt.length; i++) {
      arrayOfInt[i] = untranslateOffset(this.lineOffset[i]);
    }
    return arrayOfInt;
  }
  
  public Point getLocation(int paramInt, boolean paramBoolean)
  {
    checkLayout();
    computeRuns(null);
    int i = this.text.length();
    if ((0 > paramInt) || (paramInt > i)) {
      SWT.error(6);
    }
    i = this.segmentsText.length();
    paramInt = translateOffset(paramInt);
    for (int j = 0; (j < this.runs.length) && (this.lineOffset[(j + 1)] <= paramInt); j++) {}
    j = Math.min(j, this.runs.length - 1);
    if (paramInt == i) {
      return new Point(getLineIndent(j) + this.lineWidth[j], this.lineY[j]);
    }
    int k = this.segmentsText.charAt(paramInt);
    if (paramBoolean)
    {
      if ((55296 <= k) && (k <= 56319) && (paramInt + 1 < i))
      {
        k = this.segmentsText.charAt(paramInt + 1);
        if ((56320 <= k) && (k <= 57343)) {
          paramInt++;
        }
      }
    }
    else if ((56320 <= k) && (k <= 57343) && (paramInt - 1 >= 0))
    {
      k = this.segmentsText.charAt(paramInt - 1);
      if ((55296 <= k) && (k <= 56319)) {
        paramInt--;
      }
    }
    int m = -1;
    int n = this.allRuns.length;
    while (n - m > 1)
    {
      int i1 = (n + m) / 2;
      StyleItem localStyleItem = this.allRuns[i1];
      if (localStyleItem.start > paramInt)
      {
        n = i1;
      }
      else if (localStyleItem.start + localStyleItem.length <= paramInt)
      {
        m = i1;
      }
      else
      {
        int i2;
        if ((localStyleItem.style != null) && (localStyleItem.style.metrics != null))
        {
          GlyphMetrics localGlyphMetrics = localStyleItem.style.metrics;
          i2 = localGlyphMetrics.width * (paramInt - localStyleItem.start + (paramBoolean ? 1 : 0));
        }
        else if (localStyleItem.tab)
        {
          i2 = (paramBoolean) || (paramInt == i) ? localStyleItem.width : 0;
        }
        else
        {
          int i3 = paramInt - localStyleItem.start;
          int i4 = localStyleItem.length;
          int i5 = localStyleItem.glyphCount;
          int[] arrayOfInt = new int[1];
          long l = localStyleItem.justify != 0L ? localStyleItem.justify : localStyleItem.advances;
          OS.ScriptCPtoX(i3, paramBoolean, i4, i5, localStyleItem.clusters, localStyleItem.visAttrs, l, localStyleItem.analysis, arrayOfInt);
          i2 = (this.orientation & 0x4000000) != 0 ? localStyleItem.width - arrayOfInt[0] : arrayOfInt[0];
        }
        return new Point(localStyleItem.x + i2, this.lineY[j]);
      }
    }
    return new Point(0, 0);
  }
  
  public int getNextOffset(int paramInt1, int paramInt2)
  {
    checkLayout();
    return _getOffset(paramInt1, paramInt2, true);
  }
  
  int _getOffset(int paramInt1, int paramInt2, boolean paramBoolean)
  {
    computeRuns(null);
    int i = this.text.length();
    if ((0 > paramInt1) || (paramInt1 > i)) {
      SWT.error(6);
    }
    if ((paramBoolean) && (paramInt1 == i)) {
      return i;
    }
    if ((!paramBoolean) && (paramInt1 == 0)) {
      return 0;
    }
    int j = paramBoolean ? 1 : -1;
    if ((paramInt2 & 0x1) != 0) {
      return paramInt1 + j;
    }
    i = this.segmentsText.length();
    paramInt1 = translateOffset(paramInt1);
    SCRIPT_LOGATTR localSCRIPT_LOGATTR = new SCRIPT_LOGATTR();
    SCRIPT_PROPERTIES localSCRIPT_PROPERTIES = new SCRIPT_PROPERTIES();
    int k = paramBoolean ? 0 : this.allRuns.length - 1;
    paramInt1 = validadeOffset(paramInt1, j);
    do
    {
      StyleItem localStyleItem = this.allRuns[k];
      if ((localStyleItem.start <= paramInt1) && (paramInt1 < localStyleItem.start + localStyleItem.length))
      {
        if ((localStyleItem.lineBreak) && (!localStyleItem.softBreak)) {
          return untranslateOffset(localStyleItem.start);
        }
        if (localStyleItem.tab) {
          return untranslateOffset(localStyleItem.start);
        }
        OS.MoveMemory(localSCRIPT_PROPERTIES, this.device.scripts[localStyleItem.analysis.eScript], SCRIPT_PROPERTIES.sizeof);
        int m = (localSCRIPT_PROPERTIES.fNeedsCaretInfo) || (localSCRIPT_PROPERTIES.fNeedsWordBreaking) ? 1 : 0;
        if (m != 0) {
          breakRun(localStyleItem);
        }
        while ((localStyleItem.start <= paramInt1) && (paramInt1 < localStyleItem.start + localStyleItem.length))
        {
          if (m != 0) {
            OS.MoveMemory(localSCRIPT_LOGATTR, localStyleItem.psla + (paramInt1 - localStyleItem.start) * SCRIPT_LOGATTR.sizeof, SCRIPT_LOGATTR.sizeof);
          }
          boolean bool1;
          boolean bool2;
          switch (paramInt2)
          {
          case 2: 
            if ((!localSCRIPT_PROPERTIES.fNeedsCaretInfo) || ((!localSCRIPT_LOGATTR.fInvalid) && (localSCRIPT_LOGATTR.fCharStop)))
            {
              int n = this.segmentsText.charAt(paramInt1);
              if ((56320 <= n) && (n <= 57343) && (paramInt1 > 0))
              {
                n = this.segmentsText.charAt(paramInt1 - 1);
                if ((55296 <= n) && (n <= 56319)) {
                  paramInt1 += j;
                }
              }
              return untranslateOffset(paramInt1);
            }
            break;
          case 4: 
          case 16: 
            if (localSCRIPT_PROPERTIES.fNeedsWordBreaking)
            {
              if ((!localSCRIPT_LOGATTR.fInvalid) && (localSCRIPT_LOGATTR.fWordStop)) {
                return untranslateOffset(paramInt1);
              }
            }
            else if (paramInt1 > 0)
            {
              bool1 = Compatibility.isLetterOrDigit(this.segmentsText.charAt(paramInt1));
              bool2 = Compatibility.isLetterOrDigit(this.segmentsText.charAt(paramInt1 - 1));
              if (((bool1 != bool2) || (!bool1)) && (!Compatibility.isWhitespace(this.segmentsText.charAt(paramInt1)))) {
                return untranslateOffset(paramInt1);
              }
            }
            break;
          case 8: 
            if (paramInt1 > 0)
            {
              bool1 = Compatibility.isLetterOrDigit(this.segmentsText.charAt(paramInt1));
              bool2 = Compatibility.isLetterOrDigit(this.segmentsText.charAt(paramInt1 - 1));
              if ((!bool1) && (bool2)) {
                return untranslateOffset(paramInt1);
              }
            }
            break;
          }
          paramInt1 = validadeOffset(paramInt1, j);
        }
      }
      k += j;
    } while ((0 <= k) && (k < this.allRuns.length - 1) && (0 <= paramInt1) && (paramInt1 < i));
    return paramBoolean ? this.text.length() : 0;
  }
  
  public int getOffset(Point paramPoint, int[] paramArrayOfInt)
  {
    checkLayout();
    if (paramPoint == null) {
      SWT.error(4);
    }
    return getOffset(paramPoint.x, paramPoint.y, paramArrayOfInt);
  }
  
  public int getOffset(int paramInt1, int paramInt2, int[] paramArrayOfInt)
  {
    checkLayout();
    computeRuns(null);
    if ((paramArrayOfInt != null) && (paramArrayOfInt.length < 1)) {
      SWT.error(5);
    }
    int j = this.runs.length;
    for (int i = 0; (i < j) && (this.lineY[(i + 1)] <= paramInt2); i++) {}
    i = Math.min(i, this.runs.length - 1);
    StyleItem[] arrayOfStyleItem = this.runs[i];
    int k = getLineIndent(i);
    if (paramInt1 >= k + this.lineWidth[i]) {
      paramInt1 = k + this.lineWidth[i] - 1;
    }
    if (paramInt1 < k) {
      paramInt1 = k;
    }
    int m = -1;
    int n = arrayOfStyleItem.length;
    while (n - m > 1)
    {
      int i1 = (n + m) / 2;
      StyleItem localStyleItem2 = arrayOfStyleItem[i1];
      if (localStyleItem2.x > paramInt1)
      {
        n = i1;
      }
      else if (localStyleItem2.x + localStyleItem2.width <= paramInt1)
      {
        m = i1;
      }
      else
      {
        if ((localStyleItem2.lineBreak) && (!localStyleItem2.softBreak)) {
          return untranslateOffset(localStyleItem2.start);
        }
        int i2 = paramInt1 - localStyleItem2.x;
        if ((localStyleItem2.style != null) && (localStyleItem2.style.metrics != null))
        {
          GlyphMetrics localGlyphMetrics = localStyleItem2.style.metrics;
          if (localGlyphMetrics.width > 0)
          {
            if (paramArrayOfInt != null) {
              paramArrayOfInt[0] = (i2 % localGlyphMetrics.width < localGlyphMetrics.width / 2 ? 0 : 1);
            }
            return untranslateOffset(localStyleItem2.start + i2 / localGlyphMetrics.width);
          }
        }
        if (localStyleItem2.tab)
        {
          if (paramArrayOfInt != null) {
            paramArrayOfInt[0] = (paramInt1 < localStyleItem2.x + localStyleItem2.width / 2 ? 0 : 1);
          }
          return untranslateOffset(localStyleItem2.start);
        }
        int i3 = localStyleItem2.length;
        int i4 = localStyleItem2.glyphCount;
        int[] arrayOfInt1 = new int[1];
        int[] arrayOfInt2 = new int[1];
        if ((this.orientation & 0x4000000) != 0) {
          i2 = localStyleItem2.width - i2;
        }
        long l = localStyleItem2.justify != 0L ? localStyleItem2.justify : localStyleItem2.advances;
        OS.ScriptXtoCP(i2, i3, i4, localStyleItem2.clusters, localStyleItem2.visAttrs, l, localStyleItem2.analysis, arrayOfInt1, arrayOfInt2);
        int i5 = localStyleItem2.start + arrayOfInt1[0];
        int i6 = this.segmentsText.length();
        int i7 = i5 < i6 ? this.segmentsText.charAt(i5) : 0;
        if ((55296 <= i7) && (i7 <= 56319) && (arrayOfInt2[0] <= 1))
        {
          if (i5 + 1 < i6)
          {
            i7 = this.segmentsText.charAt(i5 + 1);
            if ((56320 <= i7) && (i7 <= 57343) && (paramArrayOfInt != null)) {
              paramArrayOfInt[0] = 0;
            }
          }
        }
        else if ((56320 <= i7) && (i7 <= 57343) && (arrayOfInt2[0] <= 1))
        {
          if (i5 - 1 >= 0)
          {
            i7 = this.segmentsText.charAt(i5 - 1);
            if ((55296 <= i7) && (i7 <= 56319))
            {
              i5--;
              if (paramArrayOfInt != null) {
                paramArrayOfInt[0] = 2;
              }
            }
          }
        }
        else if (paramArrayOfInt != null) {
          paramArrayOfInt[0] = arrayOfInt2[0];
        }
        return untranslateOffset(i5);
      }
    }
    if (paramArrayOfInt != null) {
      paramArrayOfInt[0] = 0;
    }
    if (arrayOfStyleItem.length == 1)
    {
      StyleItem localStyleItem1 = arrayOfStyleItem[0];
      if ((localStyleItem1.lineBreak) && (!localStyleItem1.softBreak)) {
        return untranslateOffset(localStyleItem1.start);
      }
    }
    return untranslateOffset(this.lineOffset[(i + 1)]);
  }
  
  public int getOrientation()
  {
    checkLayout();
    return this.orientation;
  }
  
  void getPartialSelection(StyleItem paramStyleItem, int paramInt1, int paramInt2, RECT paramRECT)
  {
    int i = paramStyleItem.start + paramStyleItem.length - 1;
    int j = Math.max(paramInt1, paramStyleItem.start) - paramStyleItem.start;
    int k = Math.min(paramInt2, i) - paramStyleItem.start;
    int m = paramStyleItem.length;
    int n = paramStyleItem.glyphCount;
    int[] arrayOfInt = new int[1];
    int i1 = paramRECT.left;
    long l = paramStyleItem.justify != 0L ? paramStyleItem.justify : paramStyleItem.advances;
    OS.ScriptCPtoX(j, false, m, n, paramStyleItem.clusters, paramStyleItem.visAttrs, l, paramStyleItem.analysis, arrayOfInt);
    int i2 = (this.orientation & 0x4000000) != 0 ? paramStyleItem.width - arrayOfInt[0] : arrayOfInt[0];
    paramRECT.left = (i1 + i2);
    OS.ScriptCPtoX(k, true, m, n, paramStyleItem.clusters, paramStyleItem.visAttrs, l, paramStyleItem.analysis, arrayOfInt);
    i2 = (this.orientation & 0x4000000) != 0 ? paramStyleItem.width - arrayOfInt[0] : arrayOfInt[0];
    paramRECT.right = (i1 + i2);
  }
  
  public int getPreviousOffset(int paramInt1, int paramInt2)
  {
    checkLayout();
    return _getOffset(paramInt1, paramInt2, false);
  }
  
  public int[] getRanges()
  {
    checkLayout();
    Object localObject = new int[this.stylesCount * 2];
    int i = 0;
    for (int j = 0; j < this.stylesCount - 1; j++) {
      if (this.styles[j].style != null)
      {
        localObject[(i++)] = this.styles[j].start;
        localObject[(i++)] = (this.styles[(j + 1)].start - 1);
      }
    }
    if (i != localObject.length)
    {
      int[] arrayOfInt = new int[i];
      System.arraycopy(localObject, 0, arrayOfInt, 0, i);
      localObject = arrayOfInt;
    }
    return (int[])localObject;
  }
  
  public int[] getSegments()
  {
    checkLayout();
    return this.segments;
  }
  
  public char[] getSegmentsChars()
  {
    checkLayout();
    return this.segmentsChars;
  }
  
  String getSegmentsText()
  {
    int i = this.text.length();
    if (i == 0) {
      return this.text;
    }
    if (this.segments == null) {
      return this.text;
    }
    int j = this.segments.length;
    if (j == 0) {
      return this.text;
    }
    if (this.segmentsChars == null)
    {
      if (j == 1) {
        return this.text;
      }
      if ((j == 2) && (this.segments[0] == 0) && (this.segments[1] == i)) {
        return this.text;
      }
    }
    char[] arrayOfChar1 = new char[i];
    this.text.getChars(0, i, arrayOfChar1, 0);
    char[] arrayOfChar2 = new char[i + j];
    int k = 0;
    int m = 0;
    int n = (this.textDirection & 0x4000000) != 0 ? 8207 : 8206;
    int i1;
    while (k < i) {
      if ((m < j) && (k == this.segments[m]))
      {
        i1 = (this.segmentsChars != null) && (this.segmentsChars.length > m) ? this.segmentsChars[m] : n;
        arrayOfChar2[(k + m++)] = i1;
      }
      else
      {
        arrayOfChar2[(k + m)] = arrayOfChar1[(k++)];
      }
    }
    while (m < j)
    {
      this.segments[m] = k;
      i1 = (this.segmentsChars != null) && (this.segmentsChars.length > m) ? this.segmentsChars[m] : n;
      arrayOfChar2[(k + m++)] = i1;
    }
    return new String(arrayOfChar2, 0, arrayOfChar2.length);
  }
  
  public int getSpacing()
  {
    checkLayout();
    return this.lineSpacing;
  }
  
  public TextStyle getStyle(int paramInt)
  {
    checkLayout();
    int i = this.text.length();
    if ((0 > paramInt) || (paramInt >= i)) {
      SWT.error(6);
    }
    for (int j = 1; j < this.stylesCount; j++) {
      if (this.styles[j].start > paramInt) {
        return this.styles[(j - 1)].style;
      }
    }
    return null;
  }
  
  public TextStyle[] getStyles()
  {
    checkLayout();
    Object localObject = new TextStyle[this.stylesCount];
    int i = 0;
    for (int j = 0; j < this.stylesCount; j++) {
      if (this.styles[j].style != null) {
        localObject[(i++)] = this.styles[j].style;
      }
    }
    if (i != localObject.length)
    {
      TextStyle[] arrayOfTextStyle = new TextStyle[i];
      System.arraycopy(localObject, 0, arrayOfTextStyle, 0, i);
      localObject = arrayOfTextStyle;
    }
    return (TextStyle[])localObject;
  }
  
  public int[] getTabs()
  {
    checkLayout();
    return this.tabs;
  }
  
  public String getText()
  {
    checkLayout();
    return this.text;
  }
  
  public int getTextDirection()
  {
    checkLayout();
    return this.textDirection;
  }
  
  public int getWidth()
  {
    checkLayout();
    return this.wrapWidth;
  }
  
  public int getWrapIndent()
  {
    checkLayout();
    return this.wrapIndent;
  }
  
  public boolean isDisposed()
  {
    return this.device == null;
  }
  
  StyleItem[] itemize()
  {
    this.segmentsText = getSegmentsText();
    int i = this.segmentsText.length();
    SCRIPT_CONTROL localSCRIPT_CONTROL = new SCRIPT_CONTROL();
    SCRIPT_STATE localSCRIPT_STATE = new SCRIPT_STATE();
    int j = i + 1;
    if ((this.textDirection & 0x4000000) != 0)
    {
      localSCRIPT_STATE.uBidiLevel = 1;
      localSCRIPT_STATE.fArabicNumContext = true;
    }
    OS.ScriptApplyDigitSubstitution(null, localSCRIPT_CONTROL, localSCRIPT_STATE);
    long l1 = OS.GetProcessHeap();
    long l2 = OS.HeapAlloc(l1, 8, j * SCRIPT_ITEM.sizeof);
    if (l2 == 0L) {
      SWT.error(2);
    }
    int[] arrayOfInt = new int[1];
    char[] arrayOfChar = new char[i];
    this.segmentsText.getChars(0, i, arrayOfChar, 0);
    OS.ScriptItemize(arrayOfChar, i, j, localSCRIPT_CONTROL, localSCRIPT_STATE, l2, arrayOfInt);
    StyleItem[] arrayOfStyleItem = merge(l2, arrayOfInt[0]);
    OS.HeapFree(l1, 0, l2);
    return arrayOfStyleItem;
  }
  
  StyleItem[] merge(long paramLong, int paramInt)
  {
    if (this.styles.length > this.stylesCount)
    {
      StyleItem[] arrayOfStyleItem1 = new StyleItem[this.stylesCount];
      System.arraycopy(this.styles, 0, arrayOfStyleItem1, 0, this.stylesCount);
      this.styles = arrayOfStyleItem1;
    }
    int i = 0;
    int j = 0;
    int k = this.segmentsText.length();
    int m = 0;
    int n = 0;
    StyleItem[] arrayOfStyleItem2 = new StyleItem[paramInt + this.stylesCount];
    SCRIPT_ITEM localSCRIPT_ITEM = new SCRIPT_ITEM();
    int i1 = -1;
    int i2 = 0;
    int i3 = 0;
    int i4 = paramInt > 1024 ? 1 : 0;
    SCRIPT_PROPERTIES localSCRIPT_PROPERTIES = new SCRIPT_PROPERTIES();
    while (j < k)
    {
      localStyleItem = new StyleItem();
      localStyleItem.start = j;
      localStyleItem.style = this.styles[n].style;
      arrayOfStyleItem2[(i++)] = localStyleItem;
      OS.MoveMemory(localSCRIPT_ITEM, paramLong + m * SCRIPT_ITEM.sizeof, SCRIPT_ITEM.sizeof);
      localStyleItem.analysis = localSCRIPT_ITEM.a;
      localSCRIPT_ITEM.a = new SCRIPT_ANALYSIS();
      if (i3 != 0)
      {
        localStyleItem.analysis.fLinkBefore = true;
        i3 = 0;
      }
      int i5 = this.segmentsText.charAt(j);
      switch (i5)
      {
      case 10: 
      case 13: 
        localStyleItem.lineBreak = true;
        break;
      case 9: 
        localStyleItem.tab = true;
      }
      char c1;
      if (i1 == -1)
      {
        i2 = m + 1;
        OS.MoveMemory(localSCRIPT_ITEM, paramLong + i2 * SCRIPT_ITEM.sizeof, SCRIPT_ITEM.sizeof);
        i1 = localSCRIPT_ITEM.iCharPos;
        if ((i2 < paramInt) && (i5 == 13) && (this.segmentsText.charAt(i1) == '\n'))
        {
          i2 = m + 2;
          OS.MoveMemory(localSCRIPT_ITEM, paramLong + i2 * SCRIPT_ITEM.sizeof, SCRIPT_ITEM.sizeof);
          i1 = localSCRIPT_ITEM.iCharPos;
        }
        if ((i2 < paramInt) && (i4 != 0) && (!localStyleItem.lineBreak))
        {
          OS.MoveMemory(localSCRIPT_PROPERTIES, this.device.scripts[localStyleItem.analysis.eScript], SCRIPT_PROPERTIES.sizeof);
          if ((!localSCRIPT_PROPERTIES.fComplex) || (localStyleItem.tab)) {
            for (i6 = 0; (i6 < 512) && (i2 != paramInt); i6++)
            {
              c1 = this.segmentsText.charAt(i1);
              if ((c1 == '\n') || (c1 == '\r')) {
                break;
              }
              if ((c1 == '\t') != localStyleItem.tab) {
                break;
              }
              OS.MoveMemory(localSCRIPT_PROPERTIES, this.device.scripts[localSCRIPT_ITEM.a.eScript], SCRIPT_PROPERTIES.sizeof);
              if ((!localStyleItem.tab) && (localSCRIPT_PROPERTIES.fComplex)) {
                break;
              }
              i2++;
              OS.MoveMemory(localSCRIPT_ITEM, paramLong + i2 * SCRIPT_ITEM.sizeof, SCRIPT_ITEM.sizeof);
              i1 = localSCRIPT_ITEM.iCharPos;
            }
          }
        }
      }
      int i6 = translateOffset(this.styles[(n + 1)].start);
      if (i6 <= i1)
      {
        n++;
        j = i6;
        if ((j < i1) && (0 < j) && (j < k))
        {
          c1 = this.segmentsText.charAt(j - 1);
          char c2 = this.segmentsText.charAt(j);
          if ((Compatibility.isLetter(c1)) && (Compatibility.isLetter(c2)))
          {
            localStyleItem.analysis.fLinkAfter = true;
            i3 = 1;
          }
        }
      }
      if (i1 <= i6)
      {
        m = i2;
        j = i1;
        i1 = -1;
      }
      localStyleItem.length = (j - localStyleItem.start);
    }
    StyleItem localStyleItem = new StyleItem();
    localStyleItem.start = k;
    OS.MoveMemory(localSCRIPT_ITEM, paramLong + paramInt * SCRIPT_ITEM.sizeof, SCRIPT_ITEM.sizeof);
    localStyleItem.analysis = localSCRIPT_ITEM.a;
    arrayOfStyleItem2[(i++)] = localStyleItem;
    if (arrayOfStyleItem2.length != i)
    {
      StyleItem[] arrayOfStyleItem3 = new StyleItem[i];
      System.arraycopy(arrayOfStyleItem2, 0, arrayOfStyleItem3, 0, i);
      return arrayOfStyleItem3;
    }
    return arrayOfStyleItem2;
  }
  
  StyleItem[] reorder(StyleItem[] paramArrayOfStyleItem, boolean paramBoolean)
  {
    int i = paramArrayOfStyleItem.length;
    if (i <= 1) {
      return paramArrayOfStyleItem;
    }
    byte[] arrayOfByte = new byte[i];
    for (int j = 0; j < i; j++) {
      arrayOfByte[j] = ((byte)(paramArrayOfStyleItem[j].analysis.s.uBidiLevel & 0x1F));
    }
    StyleItem localStyleItem1 = paramArrayOfStyleItem[(i - 1)];
    if ((localStyleItem1.lineBreak) && (!localStyleItem1.softBreak)) {
      arrayOfByte[(i - 1)] = 0;
    }
    int[] arrayOfInt = new int[i];
    OS.ScriptLayout(i, arrayOfByte, null, arrayOfInt);
    StyleItem[] arrayOfStyleItem = new StyleItem[i];
    for (int k = 0; k < i; k++) {
      arrayOfStyleItem[arrayOfInt[k]] = paramArrayOfStyleItem[k];
    }
    if ((this.orientation & 0x4000000) != 0)
    {
      if (paramBoolean) {
        i--;
      }
      for (k = 0; k < i / 2; k++)
      {
        StyleItem localStyleItem2 = arrayOfStyleItem[k];
        arrayOfStyleItem[k] = arrayOfStyleItem[(i - k - 1)];
        arrayOfStyleItem[(i - k - 1)] = localStyleItem2;
      }
    }
    return arrayOfStyleItem;
  }
  
  public void setAlignment(int paramInt)
  {
    checkLayout();
    int i = 16924672;
    paramInt &= i;
    if (paramInt == 0) {
      return;
    }
    if ((paramInt & 0x4000) != 0) {
      paramInt = 16384;
    }
    if ((paramInt & 0x20000) != 0) {
      paramInt = 131072;
    }
    if (this.alignment == paramInt) {
      return;
    }
    freeRuns();
    this.alignment = paramInt;
  }
  
  public void setAscent(int paramInt)
  {
    checkLayout();
    if (paramInt < -1) {
      SWT.error(5);
    }
    if (this.ascent == paramInt) {
      return;
    }
    freeRuns();
    this.ascent = paramInt;
  }
  
  public void setDescent(int paramInt)
  {
    checkLayout();
    if (paramInt < -1) {
      SWT.error(5);
    }
    if (this.descent == paramInt) {
      return;
    }
    freeRuns();
    this.descent = paramInt;
  }
  
  public void setFont(Font paramFont)
  {
    checkLayout();
    if ((paramFont != null) && (paramFont.isDisposed())) {
      SWT.error(5);
    }
    Font localFont = this.font;
    if (localFont == paramFont) {
      return;
    }
    this.font = paramFont;
    if ((localFont != null) && (localFont.equals(paramFont))) {
      return;
    }
    freeRuns();
  }
  
  public void setIndent(int paramInt)
  {
    checkLayout();
    if (paramInt < 0) {
      return;
    }
    if (this.indent == paramInt) {
      return;
    }
    freeRuns();
    this.indent = paramInt;
  }
  
  public void setJustify(boolean paramBoolean)
  {
    checkLayout();
    if (this.justify == paramBoolean) {
      return;
    }
    freeRuns();
    this.justify = paramBoolean;
  }
  
  public void setOrientation(int paramInt)
  {
    checkLayout();
    int i = 100663296;
    paramInt &= i;
    if (paramInt == 0) {
      return;
    }
    if ((paramInt & 0x2000000) != 0) {
      paramInt = 33554432;
    }
    if (this.orientation == paramInt) {
      return;
    }
    this.textDirection = (this.orientation = paramInt);
    freeRuns();
  }
  
  public void setSegments(int[] paramArrayOfInt)
  {
    checkLayout();
    if ((this.segments == null) && (paramArrayOfInt == null)) {
      return;
    }
    if ((this.segments != null) && (paramArrayOfInt != null) && (this.segments.length == paramArrayOfInt.length))
    {
      for (int i = 0; (i < paramArrayOfInt.length) && (this.segments[i] == paramArrayOfInt[i]); i++) {}
      if (i == paramArrayOfInt.length) {
        return;
      }
    }
    freeRuns();
    this.segments = paramArrayOfInt;
  }
  
  public void setSegmentsChars(char[] paramArrayOfChar)
  {
    checkLayout();
    if ((this.segmentsChars == null) && (paramArrayOfChar == null)) {
      return;
    }
    if ((this.segmentsChars != null) && (paramArrayOfChar != null) && (this.segmentsChars.length == paramArrayOfChar.length))
    {
      for (int i = 0; (i < paramArrayOfChar.length) && (this.segmentsChars[i] == paramArrayOfChar[i]); i++) {}
      if (i == paramArrayOfChar.length) {
        return;
      }
    }
    freeRuns();
    this.segmentsChars = paramArrayOfChar;
  }
  
  public void setSpacing(int paramInt)
  {
    checkLayout();
    if (paramInt < 0) {
      SWT.error(5);
    }
    if (this.lineSpacing == paramInt) {
      return;
    }
    freeRuns();
    this.lineSpacing = paramInt;
  }
  
  public void setStyle(TextStyle paramTextStyle, int paramInt1, int paramInt2)
  {
    checkLayout();
    int i = this.text.length();
    if (i == 0) {
      return;
    }
    if (paramInt1 > paramInt2) {
      return;
    }
    paramInt1 = Math.min(Math.max(0, paramInt1), i - 1);
    paramInt2 = Math.min(Math.max(0, paramInt2), i - 1);
    int j = -1;
    StyleItem localStyleItem1 = this.stylesCount;
    while (localStyleItem1 - j > 1)
    {
      StyleItem localStyleItem2 = (localStyleItem1 + j) / 2;
      if (this.styles[(localStyleItem2 + 1)].start > paramInt1) {
        localStyleItem1 = localStyleItem2;
      } else {
        j = localStyleItem2;
      }
    }
    if ((0 <= localStyleItem1) && (localStyleItem1 < this.stylesCount))
    {
      localStyleItem3 = this.styles[localStyleItem1];
      if ((localStyleItem3.start == paramInt1) && (this.styles[(localStyleItem1 + 1)].start - 1 == paramInt2)) {
        if (paramTextStyle == null)
        {
          if (localStyleItem3.style != null) {}
        }
        else if (paramTextStyle.equals(localStyleItem3.style)) {
          return;
        }
      }
    }
    freeRuns();
    StyleItem localStyleItem3 = localStyleItem1;
    for (StyleItem localStyleItem4 = localStyleItem3; (localStyleItem4 < this.stylesCount) && (this.styles[(localStyleItem4 + 1)].start <= paramInt2); localStyleItem4++) {}
    int m;
    if (localStyleItem3 == localStyleItem4)
    {
      k = this.styles[localStyleItem3].start;
      m = this.styles[(localStyleItem4 + 1)].start - 1;
      if ((k == paramInt1) && (m == paramInt2))
      {
        this.styles[localStyleItem3].style = paramTextStyle;
        return;
      }
      if ((k != paramInt1) && (m != paramInt2))
      {
        int n = this.stylesCount + 2;
        if (n > this.styles.length)
        {
          int i1 = Math.min(n + 1024, Math.max(64, n * 2));
          StyleItem[] arrayOfStyleItem2 = new StyleItem[i1];
          System.arraycopy(this.styles, 0, arrayOfStyleItem2, 0, this.stylesCount);
          this.styles = arrayOfStyleItem2;
        }
        System.arraycopy(this.styles, localStyleItem4 + 1, this.styles, localStyleItem4 + 3, this.stylesCount - localStyleItem4 - 1);
        StyleItem localStyleItem6 = new StyleItem();
        localStyleItem6.start = paramInt1;
        localStyleItem6.style = paramTextStyle;
        this.styles[(localStyleItem3 + 1)] = localStyleItem6;
        localStyleItem6 = new StyleItem();
        localStyleItem6.start = (paramInt2 + 1);
        localStyleItem6.style = this.styles[localStyleItem3].style;
        this.styles[(localStyleItem3 + 2)] = localStyleItem6;
        this.stylesCount = n;
        return;
      }
    }
    if (paramInt1 == this.styles[localStyleItem3].start) {
      localStyleItem3--;
    }
    if (paramInt2 == this.styles[(localStyleItem4 + 1)].start - 1) {
      localStyleItem4++;
    }
    int k = this.stylesCount + 1 - (localStyleItem4 - localStyleItem3 - 1);
    if (k > this.styles.length)
    {
      m = Math.min(k + 1024, Math.max(64, k * 2));
      StyleItem[] arrayOfStyleItem1 = new StyleItem[m];
      System.arraycopy(this.styles, 0, arrayOfStyleItem1, 0, this.stylesCount);
      this.styles = arrayOfStyleItem1;
    }
    System.arraycopy(this.styles, localStyleItem4, this.styles, localStyleItem3 + 2, this.stylesCount - localStyleItem4);
    StyleItem localStyleItem5 = new StyleItem();
    localStyleItem5.start = paramInt1;
    localStyleItem5.style = paramTextStyle;
    this.styles[(localStyleItem3 + 1)] = localStyleItem5;
    this.styles[(localStyleItem3 + 2)].start = (paramInt2 + 1);
    this.stylesCount = k;
  }
  
  public void setTabs(int[] paramArrayOfInt)
  {
    checkLayout();
    if ((this.tabs == null) && (paramArrayOfInt == null)) {
      return;
    }
    if ((this.tabs != null) && (paramArrayOfInt != null) && (this.tabs.length == paramArrayOfInt.length))
    {
      for (int i = 0; (i < paramArrayOfInt.length) && (this.tabs[i] == paramArrayOfInt[i]); i++) {}
      if (i == paramArrayOfInt.length) {
        return;
      }
    }
    freeRuns();
    this.tabs = paramArrayOfInt;
  }
  
  public void setText(String paramString)
  {
    checkLayout();
    if (paramString == null) {
      SWT.error(4);
    }
    if (paramString.equals(this.text)) {
      return;
    }
    freeRuns();
    this.text = paramString;
    this.styles = new StyleItem[2];
    this.styles[0] = new StyleItem();
    this.styles[1] = new StyleItem();
    this.styles[1].start = paramString.length();
    this.stylesCount = 2;
  }
  
  public void setTextDirection(int paramInt)
  {
    checkLayout();
    int i = 100663296;
    paramInt &= i;
    if (paramInt == 0) {
      return;
    }
    if ((paramInt & 0x2000000) != 0) {
      paramInt = 33554432;
    }
    if (this.textDirection == paramInt) {
      return;
    }
    this.textDirection = paramInt;
    freeRuns();
  }
  
  public void setWidth(int paramInt)
  {
    checkLayout();
    if ((paramInt < -1) || (paramInt == 0)) {
      SWT.error(5);
    }
    if (this.wrapWidth == paramInt) {
      return;
    }
    freeRuns();
    this.wrapWidth = paramInt;
  }
  
  public void setWrapIndent(int paramInt)
  {
    checkLayout();
    if (paramInt < 0) {
      return;
    }
    if (this.wrapIndent == paramInt) {
      return;
    }
    freeRuns();
    this.wrapIndent = paramInt;
  }
  
  boolean shape(long paramLong, StyleItem paramStyleItem, char[] paramArrayOfChar, int[] paramArrayOfInt, int paramInt, SCRIPT_PROPERTIES paramSCRIPT_PROPERTIES)
  {
    int i = (!paramSCRIPT_PROPERTIES.fComplex) && (!paramStyleItem.analysis.fNoGlyphIndex) ? 1 : 0;
    if (i != 0)
    {
      short[] arrayOfShort1 = new short[paramArrayOfChar.length];
      if (OS.ScriptGetCMap(paramLong, paramStyleItem.psc, paramArrayOfChar, paramArrayOfChar.length, 0, arrayOfShort1) != 0)
      {
        if (paramStyleItem.psc != 0L)
        {
          OS.ScriptFreeCache(paramStyleItem.psc);
          paramArrayOfInt[0] = 0;
          OS.MoveMemory(paramStyleItem.psc, new long[1], OS.PTR_SIZEOF);
        }
        return false;
      }
    }
    int j = OS.ScriptShape(paramLong, paramStyleItem.psc, paramArrayOfChar, paramArrayOfChar.length, paramInt, paramStyleItem.analysis, paramStyleItem.glyphs, paramStyleItem.clusters, paramStyleItem.visAttrs, paramArrayOfInt);
    paramStyleItem.glyphCount = paramArrayOfInt[0];
    if (i != 0) {
      return true;
    }
    if (j != -2147220992)
    {
      if (paramStyleItem.analysis.fNoGlyphIndex) {
        return true;
      }
      SCRIPT_FONTPROPERTIES localSCRIPT_FONTPROPERTIES = new SCRIPT_FONTPROPERTIES();
      localSCRIPT_FONTPROPERTIES.cBytes = SCRIPT_FONTPROPERTIES.sizeof;
      OS.ScriptGetFontProperties(paramLong, paramStyleItem.psc, localSCRIPT_FONTPROPERTIES);
      short[] arrayOfShort2 = new short[paramArrayOfInt[0]];
      OS.MoveMemory(arrayOfShort2, paramStyleItem.glyphs, arrayOfShort2.length * 2);
      for (int k = 0; (k < arrayOfShort2.length) && (arrayOfShort2[k] != localSCRIPT_FONTPROPERTIES.wgDefault); k++) {}
      if (k == arrayOfShort2.length) {
        return true;
      }
    }
    if (paramStyleItem.psc != 0L)
    {
      OS.ScriptFreeCache(paramStyleItem.psc);
      paramArrayOfInt[0] = 0;
      OS.MoveMemory(paramStyleItem.psc, new long[1], OS.PTR_SIZEOF);
    }
    paramStyleItem.glyphCount = 0;
    return false;
  }
  
  void shape(long paramLong, StyleItem paramStyleItem)
  {
    if (paramStyleItem.lineBreak) {
      return;
    }
    if (paramStyleItem.glyphs != 0L) {
      return;
    }
    int[] arrayOfInt1 = new int[1];
    char[] arrayOfChar1 = new char[paramStyleItem.length];
    this.segmentsText.getChars(paramStyleItem.start, paramStyleItem.start + paramStyleItem.length, arrayOfChar1, 0);
    int i = arrayOfChar1.length * 3 / 2 + 16;
    long l1 = OS.GetProcessHeap();
    paramStyleItem.glyphs = OS.HeapAlloc(l1, 8, i * 2);
    if (paramStyleItem.glyphs == 0L) {
      SWT.error(2);
    }
    paramStyleItem.clusters = OS.HeapAlloc(l1, 8, i * 2);
    if (paramStyleItem.clusters == 0L) {
      SWT.error(2);
    }
    paramStyleItem.visAttrs = OS.HeapAlloc(l1, 8, i * 2);
    if (paramStyleItem.visAttrs == 0L) {
      SWT.error(2);
    }
    paramStyleItem.psc = OS.HeapAlloc(l1, 8, OS.PTR_SIZEOF);
    if (paramStyleItem.psc == 0L) {
      SWT.error(2);
    }
    int j = paramStyleItem.analysis.eScript;
    SCRIPT_PROPERTIES localSCRIPT_PROPERTIES = new SCRIPT_PROPERTIES();
    OS.MoveMemory(localSCRIPT_PROPERTIES, this.device.scripts[j], SCRIPT_PROPERTIES.sizeof);
    boolean bool = shape(paramLong, paramStyleItem, arrayOfChar1, arrayOfInt1, i, localSCRIPT_PROPERTIES);
    if ((!bool) && (localSCRIPT_PROPERTIES.fPrivateUseArea))
    {
      paramStyleItem.analysis.fNoGlyphIndex = true;
      bool = shape(paramLong, paramStyleItem, arrayOfChar1, arrayOfInt1, i, localSCRIPT_PROPERTIES);
    }
    if (!bool)
    {
      long l2 = OS.GetCurrentObject(paramLong, 6);
      long l3 = 0L;
      char[] arrayOfChar2 = new char[Math.min(arrayOfChar1.length, 2)];
      SCRIPT_LOGATTR localSCRIPT_LOGATTR = new SCRIPT_LOGATTR();
      breakRun(paramStyleItem);
      int k = 0;
      for (int m = 0; m < arrayOfChar1.length; m++)
      {
        OS.MoveMemory(localSCRIPT_LOGATTR, paramStyleItem.psla + m * SCRIPT_LOGATTR.sizeof, SCRIPT_LOGATTR.sizeof);
        if (!localSCRIPT_LOGATTR.fWhiteSpace)
        {
          arrayOfChar2[(k++)] = arrayOfChar1[m];
          if (k == arrayOfChar2.length) {
            break;
          }
        }
      }
      long l5;
      Object localObject3;
      if (k > 0)
      {
        long l4 = OS.HeapAlloc(l1, 8, OS.SCRIPT_STRING_ANALYSIS_sizeof());
        l5 = OS.CreateEnhMetaFile(paramLong, null, null, null);
        long l6 = OS.SelectObject(l5, l2);
        int i1 = 6304;
        if (OS.ScriptStringAnalyse(l5, arrayOfChar2, k, 0, -1, i1, 0, null, null, 0L, 0L, 0L, l4) == 0)
        {
          OS.ScriptStringOut(l4, 0, 0, 0, null, 0, 0, false);
          OS.ScriptStringFree(l4);
        }
        OS.HeapFree(l1, 0, l4);
        OS.SelectObject(l5, l6);
        long l9 = OS.CloseEnhMetaFile(l5);
        final EMREXTCREATEFONTINDIRECTW localEMREXTCREATEFONTINDIRECTW = new EMREXTCREATEFONTINDIRECTW();
        Object local1MetaFileEnumProc = new Object()
        {
          long metaFileEnumProc(long paramAnonymousLong1, long paramAnonymousLong2, long paramAnonymousLong3, long paramAnonymousLong4, long paramAnonymousLong5)
          {
            OS.MoveMemory(localEMREXTCREATEFONTINDIRECTW.emr, paramAnonymousLong3, EMR.sizeof);
            switch (localEMREXTCREATEFONTINDIRECTW.emr.iType)
            {
            case 82: 
              OS.MoveMemory(localEMREXTCREATEFONTINDIRECTW, paramAnonymousLong3, EMREXTCREATEFONTINDIRECTW.sizeof);
              break;
            case 84: 
              return 0L;
            }
            return 1L;
          }
        };
        int i2 = 0;
        if (i2 != 0) {
          local1MetaFileEnumProc.metaFileEnumProc(0L, 0L, 0L, 0L, 0L);
        }
        Callback localCallback = new Callback(local1MetaFileEnumProc, "metaFileEnumProc", 5);
        long l10 = localCallback.getAddress();
        if (l10 == 0L) {
          SWT.error(3);
        }
        OS.EnumEnhMetaFile(0L, l9, l10, 0L, null);
        OS.DeleteEnhMetaFile(l9);
        localCallback.dispose();
        l3 = OS.CreateFontIndirectW(localEMREXTCREATEFONTINDIRECTW.elfw.elfLogFont);
      }
      else
      {
        for (int n = 0; n < this.allRuns.length - 1; n++) {
          if (this.allRuns[n] == paramStyleItem)
          {
            LOGFONTA localLOGFONTA2;
            if (n > 0)
            {
              localObject3 = this.allRuns[(n - 1)];
              if (((StyleItem)localObject3).analysis.eScript == paramStyleItem.analysis.eScript)
              {
                l5 = getItemFont((StyleItem)localObject3);
                localLOGFONTA2 = OS.IsUnicode ? new LOGFONTW() : new LOGFONTA();
                OS.GetObject(l5, LOGFONT.sizeof, localLOGFONTA2);
                l3 = OS.CreateFontIndirect(localLOGFONTA2);
              }
            }
            if ((l3 != 0L) || (n + 1 >= this.allRuns.length - 1)) {
              break;
            }
            localObject3 = this.allRuns[(n + 1)];
            if (((StyleItem)localObject3).analysis.eScript == paramStyleItem.analysis.eScript)
            {
              OS.SelectObject(paramLong, getItemFont((StyleItem)localObject3));
              shape(paramLong, (StyleItem)localObject3);
              l5 = getItemFont((StyleItem)localObject3);
              localLOGFONTA2 = OS.IsUnicode ? new LOGFONTW() : new LOGFONTA();
              OS.GetObject(l5, LOGFONT.sizeof, localLOGFONTA2);
              l3 = OS.CreateFontIndirect(localLOGFONTA2);
            }
            break;
          }
        }
      }
      if (l3 != 0L)
      {
        OS.SelectObject(paramLong, l3);
        if ((bool = shape(paramLong, paramStyleItem, arrayOfChar1, arrayOfInt1, i, localSCRIPT_PROPERTIES))) {
          paramStyleItem.fallbackFont = l3;
        }
      }
      if ((!bool) && (!localSCRIPT_PROPERTIES.fComplex))
      {
        paramStyleItem.analysis.fNoGlyphIndex = true;
        if ((bool = shape(paramLong, paramStyleItem, arrayOfChar1, arrayOfInt1, i, localSCRIPT_PROPERTIES))) {
          paramStyleItem.fallbackFont = l3;
        } else {
          paramStyleItem.analysis.fNoGlyphIndex = false;
        }
      }
      if ((!bool) && (this.mLangFontLink2 != 0L))
      {
        long[] arrayOfLong = new long[1];
        localObject3 = new int[1];
        int[] arrayOfInt3 = new int[1];
        OS.VtblCall(4, this.mLangFontLink2, arrayOfChar1, arrayOfChar1.length, 0, (int[])localObject3, arrayOfInt3);
        if (OS.VtblCall(10, this.mLangFontLink2, paramLong, localObject3[0], arrayOfChar1[0], arrayOfLong) == 0)
        {
          LOGFONTA localLOGFONTA1 = OS.IsUnicode ? new LOGFONTW() : new LOGFONTA();
          OS.GetObject(arrayOfLong[0], LOGFONT.sizeof, localLOGFONTA1);
          OS.VtblCall(8, this.mLangFontLink2, arrayOfLong[0]);
          long l7 = OS.CreateFontIndirect(localLOGFONTA1);
          long l8 = OS.SelectObject(paramLong, l7);
          if ((bool = shape(paramLong, paramStyleItem, arrayOfChar1, arrayOfInt1, i, localSCRIPT_PROPERTIES)))
          {
            paramStyleItem.fallbackFont = l7;
          }
          else
          {
            OS.SelectObject(paramLong, l8);
            OS.DeleteObject(l7);
          }
        }
      }
      if (!bool) {
        OS.SelectObject(paramLong, l2);
      }
      if ((l3 != 0L) && (l3 != paramStyleItem.fallbackFont)) {
        OS.DeleteObject(l3);
      }
    }
    if (!bool)
    {
      OS.ScriptShape(paramLong, paramStyleItem.psc, arrayOfChar1, arrayOfChar1.length, i, paramStyleItem.analysis, paramStyleItem.glyphs, paramStyleItem.clusters, paramStyleItem.visAttrs, arrayOfInt1);
      paramStyleItem.glyphCount = arrayOfInt1[0];
    }
    int[] arrayOfInt2 = new int[3];
    paramStyleItem.advances = OS.HeapAlloc(l1, 8, paramStyleItem.glyphCount * 4);
    if (paramStyleItem.advances == 0L) {
      SWT.error(2);
    }
    paramStyleItem.goffsets = OS.HeapAlloc(l1, 8, paramStyleItem.glyphCount * 8);
    if (paramStyleItem.goffsets == 0L) {
      SWT.error(2);
    }
    OS.ScriptPlace(paramLong, paramStyleItem.psc, paramStyleItem.glyphs, paramStyleItem.glyphCount, paramStyleItem.visAttrs, paramStyleItem.analysis, paramStyleItem.advances, paramStyleItem.goffsets, arrayOfInt2);
    paramStyleItem.width = (arrayOfInt2[0] + arrayOfInt2[1] + arrayOfInt2[2]);
    TextStyle localTextStyle = paramStyleItem.style;
    Object localObject1;
    if (localTextStyle != null)
    {
      localObject1 = null;
      if ((localTextStyle.underline) || (localTextStyle.strikeout))
      {
        localObject1 = OS.IsUnicode ? new OUTLINETEXTMETRICW() : new OUTLINETEXTMETRICA();
        if (OS.GetOutlineTextMetrics(paramLong, OUTLINETEXTMETRIC.sizeof, (OUTLINETEXTMETRIC)localObject1) == 0) {
          localObject1 = null;
        }
      }
      Object localObject2;
      if (localTextStyle.metrics != null)
      {
        localObject2 = localTextStyle.metrics;
        paramStyleItem.width = (((GlyphMetrics)localObject2).width * Math.max(1, paramStyleItem.glyphCount));
        paramStyleItem.ascent = ((GlyphMetrics)localObject2).ascent;
        paramStyleItem.descent = ((GlyphMetrics)localObject2).descent;
        paramStyleItem.leading = 0;
      }
      else
      {
        localObject2 = null;
        if (localObject1 != null)
        {
          localObject2 = OS.IsUnicode ? ((OUTLINETEXTMETRICW)localObject1).otmTextMetrics : ((OUTLINETEXTMETRICA)localObject1).otmTextMetrics;
        }
        else
        {
          localObject2 = OS.IsUnicode ? new TEXTMETRICW() : new TEXTMETRICA();
          OS.GetTextMetrics(paramLong, (TEXTMETRIC)localObject2);
        }
        paramStyleItem.ascent = ((TEXTMETRIC)localObject2).tmAscent;
        paramStyleItem.descent = ((TEXTMETRIC)localObject2).tmDescent;
        paramStyleItem.leading = ((TEXTMETRIC)localObject2).tmInternalLeading;
      }
      if (localObject1 != null)
      {
        paramStyleItem.underlinePos = ((OUTLINETEXTMETRIC)localObject1).otmsUnderscorePosition;
        paramStyleItem.underlineThickness = Math.max(1, ((OUTLINETEXTMETRIC)localObject1).otmsUnderscoreSize);
        paramStyleItem.strikeoutPos = ((OUTLINETEXTMETRIC)localObject1).otmsStrikeoutPosition;
        paramStyleItem.strikeoutThickness = Math.max(1, ((OUTLINETEXTMETRIC)localObject1).otmsStrikeoutSize);
      }
      else
      {
        paramStyleItem.underlinePos = 1;
        paramStyleItem.underlineThickness = 1;
        paramStyleItem.strikeoutPos = (paramStyleItem.ascent / 2);
        paramStyleItem.strikeoutThickness = 1;
      }
      paramStyleItem.ascent += localTextStyle.rise;
      paramStyleItem.descent -= localTextStyle.rise;
    }
    else
    {
      localObject1 = OS.IsUnicode ? new TEXTMETRICW() : new TEXTMETRICA();
      OS.GetTextMetrics(paramLong, (TEXTMETRIC)localObject1);
      paramStyleItem.ascent = ((TEXTMETRIC)localObject1).tmAscent;
      paramStyleItem.descent = ((TEXTMETRIC)localObject1).tmDescent;
      paramStyleItem.leading = ((TEXTMETRIC)localObject1).tmInternalLeading;
    }
  }
  
  int validadeOffset(int paramInt1, int paramInt2)
  {
    paramInt1 = untranslateOffset(paramInt1);
    return translateOffset(paramInt1 + paramInt2);
  }
  
  public String toString()
  {
    if (isDisposed()) {
      return "TextLayout {*DISPOSED*}";
    }
    return "TextLayout {}";
  }
  
  int translateOffset(int paramInt)
  {
    int i = this.text.length();
    if (i == 0) {
      return paramInt;
    }
    if (this.segments == null) {
      return paramInt;
    }
    int j = this.segments.length;
    if (j == 0) {
      return paramInt;
    }
    if (this.segmentsChars == null)
    {
      if (j == 1) {
        return paramInt;
      }
      if ((j == 2) && (this.segments[0] == 0) && (this.segments[1] == i)) {
        return paramInt;
      }
    }
    for (int k = 0; (k < j) && (paramInt - k >= this.segments[k]); k++) {
      paramInt++;
    }
    return paramInt;
  }
  
  int untranslateOffset(int paramInt)
  {
    int i = this.text.length();
    if (i == 0) {
      return paramInt;
    }
    if (this.segments == null) {
      return paramInt;
    }
    int j = this.segments.length;
    if (j == 0) {
      return paramInt;
    }
    if (this.segmentsChars == null)
    {
      if (j == 1) {
        return paramInt;
      }
      if ((j == 2) && (this.segments[0] == 0) && (this.segments[1] == i)) {
        return paramInt;
      }
    }
    for (int k = 0; (k < j) && (paramInt > this.segments[k]); k++) {
      paramInt--;
    }
    return paramInt;
  }
  
  static
  {
    OS.IIDFromString("{275c23e2-3747-11d0-9fea-00aa003f8646}\000".toCharArray(), CLSID_CMultiLanguage);
    OS.IIDFromString("{DCCFC162-2B38-11d2-B7EC-00C04F8F5D9A}\000".toCharArray(), IID_IMLangFontLink2);
  }
  
  class StyleItem
  {
    TextStyle style;
    int start;
    int length;
    boolean lineBreak;
    boolean softBreak;
    boolean tab;
    SCRIPT_ANALYSIS analysis;
    long psc = 0L;
    long glyphs;
    int glyphCount;
    long clusters;
    long visAttrs;
    long advances;
    long goffsets;
    int width;
    int ascent;
    int descent;
    int leading;
    int x;
    int underlinePos;
    int underlineThickness;
    int strikeoutPos;
    int strikeoutThickness;
    long justify;
    long psla;
    long fallbackFont;
    
    StyleItem() {}
    
    void free()
    {
      long l = OS.GetProcessHeap();
      if (this.psc != 0L)
      {
        OS.ScriptFreeCache(this.psc);
        OS.HeapFree(l, 0, this.psc);
        this.psc = 0L;
      }
      if (this.glyphs != 0L)
      {
        OS.HeapFree(l, 0, this.glyphs);
        this.glyphs = 0L;
        this.glyphCount = 0;
      }
      if (this.clusters != 0L)
      {
        OS.HeapFree(l, 0, this.clusters);
        this.clusters = 0L;
      }
      if (this.visAttrs != 0L)
      {
        OS.HeapFree(l, 0, this.visAttrs);
        this.visAttrs = 0L;
      }
      if (this.advances != 0L)
      {
        OS.HeapFree(l, 0, this.advances);
        this.advances = 0L;
      }
      if (this.goffsets != 0L)
      {
        OS.HeapFree(l, 0, this.goffsets);
        this.goffsets = 0L;
      }
      if (this.justify != 0L)
      {
        OS.HeapFree(l, 0, this.justify);
        this.justify = 0L;
      }
      if (this.psla != 0L)
      {
        OS.HeapFree(l, 0, this.psla);
        this.psla = 0L;
      }
      if (this.fallbackFont != 0L)
      {
        OS.DeleteObject(this.fallbackFont);
        this.fallbackFont = 0L;
      }
      this.width = (this.ascent = this.descent = this.x = 0);
      this.lineBreak = (this.softBreak = 0);
    }
    
    public String toString()
    {
      return "StyleItem {" + this.start + ", " + this.style + "}";
    }
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/graphics/TextLayout.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */