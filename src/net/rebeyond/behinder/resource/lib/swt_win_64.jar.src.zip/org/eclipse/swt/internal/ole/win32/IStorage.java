package org.eclipse.swt.internal.ole.win32;

public class IStorage
  extends IUnknown
{
  public IStorage(long paramLong)
  {
    super(paramLong);
  }
  
  public int Commit(int paramInt)
  {
    return COM.VtblCall(9, this.address, paramInt);
  }
  
  public int CopyTo(int paramInt, GUID paramGUID, String[] paramArrayOfString, long paramLong)
  {
    if (paramArrayOfString != null) {
      return -2147024809;
    }
    return COM.VtblCall(7, this.address, paramInt, paramGUID, 0L, paramLong);
  }
  
  public int CreateStorage(String paramString, int paramInt1, int paramInt2, int paramInt3, long[] paramArrayOfLong)
  {
    char[] arrayOfChar = null;
    if (paramString != null) {
      arrayOfChar = (paramString + "\000").toCharArray();
    }
    return COM.VtblCall(5, this.address, arrayOfChar, paramInt1, paramInt2, paramInt3, paramArrayOfLong);
  }
  
  public int CreateStream(String paramString, int paramInt1, int paramInt2, int paramInt3, long[] paramArrayOfLong)
  {
    char[] arrayOfChar = null;
    if (paramString != null) {
      arrayOfChar = (paramString + "\000").toCharArray();
    }
    return COM.VtblCall(3, this.address, arrayOfChar, paramInt1, paramInt2, paramInt3, paramArrayOfLong);
  }
  
  public int DestroyElement(String paramString)
  {
    char[] arrayOfChar = null;
    if (paramString != null) {
      arrayOfChar = (paramString + "\000").toCharArray();
    }
    return COM.VtblCall(12, this.address, arrayOfChar);
  }
  
  public int EnumElements(int paramInt1, long paramLong, int paramInt2, long[] paramArrayOfLong)
  {
    return COM.VtblCall(11, this.address, paramInt1, paramLong, paramInt2, paramArrayOfLong);
  }
  
  public int OpenStorage(String paramString, long paramLong, int paramInt1, String[] paramArrayOfString, int paramInt2, long[] paramArrayOfLong)
  {
    char[] arrayOfChar = null;
    if (paramString != null) {
      arrayOfChar = (paramString + "\000").toCharArray();
    }
    if (paramArrayOfString != null) {
      return -2147024809;
    }
    return COM.VtblCall(6, this.address, arrayOfChar, paramLong, paramInt1, 0, paramInt2, paramArrayOfLong);
  }
  
  public int OpenStream(String paramString, long paramLong, int paramInt1, int paramInt2, long[] paramArrayOfLong)
  {
    char[] arrayOfChar = null;
    if (paramString != null) {
      arrayOfChar = (paramString + "\000").toCharArray();
    }
    return COM.VtblCall(4, this.address, arrayOfChar, paramLong, paramInt1, paramInt2, paramArrayOfLong);
  }
  
  public int RenameElement(String paramString1, String paramString2)
  {
    char[] arrayOfChar1 = null;
    if (paramString1 != null) {
      arrayOfChar1 = (paramString1 + "\000").toCharArray();
    }
    char[] arrayOfChar2 = null;
    if (paramString2 != null) {
      arrayOfChar2 = (paramString2 + "\000").toCharArray();
    }
    return COM.VtblCall(13, this.address, arrayOfChar1, arrayOfChar2);
  }
  
  public int Revert()
  {
    return COM.VtblCall(10, this.address);
  }
  
  public int SetClass(GUID paramGUID)
  {
    return COM.VtblCall(15, this.address, paramGUID);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/internal/ole/win32/IStorage.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */