package org.eclipse.swt.internal.mozilla;

public class nsIUploadChannel
  extends nsISupports
{
  static final int LAST_METHOD_ID = nsISupports.LAST_METHOD_ID + 2;
  static final String NS_IUPLOADCHANNEL_IID_STR = "ddf633d8-e9a4-439d-ad88-de636fd9bb75";
  static final String NS_IUPLOADCHANNEL_24_IID_STR = "5cfe15bd-5adb-4a7f-9e55-4f5a67d15794";
  
  public nsIUploadChannel(long paramLong)
  {
    super(paramLong);
  }
  
  public int GetUploadStream(long[] paramArrayOfLong)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 2, getAddress(), paramArrayOfLong);
  }
  
  static
  {
    IIDStore.RegisterIID(nsIUploadChannel.class, 0, new nsID("ddf633d8-e9a4-439d-ad88-de636fd9bb75"));
    IIDStore.RegisterIID(nsIUploadChannel.class, 6, new nsID("5cfe15bd-5adb-4a7f-9e55-4f5a67d15794"));
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/internal/mozilla/nsIUploadChannel.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */