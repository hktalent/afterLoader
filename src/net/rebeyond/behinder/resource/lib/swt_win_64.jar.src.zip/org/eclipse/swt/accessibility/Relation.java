package org.eclipse.swt.accessibility;

import org.eclipse.swt.SWT;
import org.eclipse.swt.internal.ole.win32.COM;
import org.eclipse.swt.internal.ole.win32.COMObject;
import org.eclipse.swt.internal.ole.win32.GUID;
import org.eclipse.swt.internal.win32.OS;

class Relation
{
  Accessible accessible;
  COMObject objIAccessibleRelation;
  int refCount;
  int type;
  Accessible[] targets;
  static final String[] relationTypeString = { "controlledBy", "controllerFor", "describedBy", "descriptionFor", "embeddedBy", "embeds", "flowsFrom", "flowsTo", "labelFor", "labelledBy", "memberOf", "nodeChildOf", "parentWindowOf", "popupFor", "subwindowOf" };
  static final String[] localizedRelationTypeString = { SWT.getMessage("SWT_Controlled_By"), SWT.getMessage("SWT_Controller_For"), SWT.getMessage("SWT_Described_By"), SWT.getMessage("SWT_Description_For"), SWT.getMessage("SWT_Embedded_By"), SWT.getMessage("SWT_Embeds"), SWT.getMessage("SWT_Flows_From"), SWT.getMessage("SWT_Flows_To"), SWT.getMessage("SWT_Label_For"), SWT.getMessage("SWT_Labelled_By"), SWT.getMessage("SWT_Member_Of"), SWT.getMessage("SWT_Node_Child_Of"), SWT.getMessage("SWT_Parent_Window_Of"), SWT.getMessage("SWT_Popup_For"), SWT.getMessage("SWT_Subwindow_Of") };
  
  Relation(Accessible paramAccessible, int paramInt)
  {
    this.accessible = paramAccessible;
    this.type = paramInt;
    this.targets = new Accessible[0];
    AddRef();
  }
  
  long getAddress()
  {
    if (this.objIAccessibleRelation == null) {
      createIAccessibleRelation();
    }
    return this.objIAccessibleRelation.getAddress();
  }
  
  void createIAccessibleRelation()
  {
    this.objIAccessibleRelation = new COMObject(new int[] { 2, 0, 0, 1, 1, 1, 2, 3 })
    {
      public long method0(long[] paramAnonymousArrayOfLong)
      {
        return Relation.this.QueryInterface(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method1(long[] paramAnonymousArrayOfLong)
      {
        return Relation.this.AddRef();
      }
      
      public long method2(long[] paramAnonymousArrayOfLong)
      {
        return Relation.this.Release();
      }
      
      public long method3(long[] paramAnonymousArrayOfLong)
      {
        return Relation.this.get_relationType(paramAnonymousArrayOfLong[0]);
      }
      
      public long method4(long[] paramAnonymousArrayOfLong)
      {
        return Relation.this.get_localizedRelationType(paramAnonymousArrayOfLong[0]);
      }
      
      public long method5(long[] paramAnonymousArrayOfLong)
      {
        return Relation.this.get_nTargets(paramAnonymousArrayOfLong[0]);
      }
      
      public long method6(long[] paramAnonymousArrayOfLong)
      {
        return Relation.this.get_target((int)paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method7(long[] paramAnonymousArrayOfLong)
      {
        return Relation.this.get_targets((int)paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2]);
      }
    };
  }
  
  int QueryInterface(long paramLong1, long paramLong2)
  {
    GUID localGUID = new GUID();
    COM.MoveMemory(localGUID, paramLong1, GUID.sizeof);
    if ((COM.IsEqualGUID(localGUID, COM.IIDIUnknown)) || (COM.IsEqualGUID(localGUID, COM.IIDIAccessibleRelation)))
    {
      COM.MoveMemory(paramLong2, new long[] { getAddress() }, OS.PTR_SIZEOF);
      AddRef();
      return 0;
    }
    return -2147467262;
  }
  
  int AddRef()
  {
    this.refCount += 1;
    return this.refCount;
  }
  
  int Release()
  {
    this.refCount -= 1;
    if (this.refCount == 0)
    {
      if (this.objIAccessibleRelation != null) {
        this.objIAccessibleRelation.dispose();
      }
      this.objIAccessibleRelation = null;
    }
    return this.refCount;
  }
  
  int get_relationType(long paramLong)
  {
    setString(paramLong, relationTypeString[this.type]);
    return 0;
  }
  
  int get_localizedRelationType(long paramLong)
  {
    setString(paramLong, localizedRelationTypeString[this.type]);
    return 0;
  }
  
  int get_nTargets(long paramLong)
  {
    COM.MoveMemory(paramLong, new int[] { this.targets.length }, 4);
    return 0;
  }
  
  int get_target(int paramInt, long paramLong)
  {
    if ((paramInt < 0) || (paramInt >= this.targets.length)) {
      return -2147024809;
    }
    Accessible localAccessible = this.targets[paramInt];
    localAccessible.AddRef();
    COM.MoveMemory(paramLong, new long[] { localAccessible.getAddress() }, OS.PTR_SIZEOF);
    return 0;
  }
  
  int get_targets(int paramInt, long paramLong1, long paramLong2)
  {
    int i = Math.min(this.targets.length, paramInt);
    for (int j = 0; j < i; j++)
    {
      Accessible localAccessible = this.targets[j];
      localAccessible.AddRef();
      COM.MoveMemory(paramLong1 + j * OS.PTR_SIZEOF, new long[] { localAccessible.getAddress() }, OS.PTR_SIZEOF);
    }
    COM.MoveMemory(paramLong2, new int[] { i }, 4);
    return 0;
  }
  
  void addTarget(Accessible paramAccessible)
  {
    if (containsTarget(paramAccessible)) {
      return;
    }
    Accessible[] arrayOfAccessible = new Accessible[this.targets.length + 1];
    System.arraycopy(this.targets, 0, arrayOfAccessible, 0, this.targets.length);
    arrayOfAccessible[this.targets.length] = paramAccessible;
    this.targets = arrayOfAccessible;
  }
  
  boolean containsTarget(Accessible paramAccessible)
  {
    for (int i = 0; i < this.targets.length; i++) {
      if (this.targets[i] == paramAccessible) {
        return true;
      }
    }
    return false;
  }
  
  void removeTarget(Accessible paramAccessible)
  {
    if (!containsTarget(paramAccessible)) {
      return;
    }
    Accessible[] arrayOfAccessible = new Accessible[this.targets.length - 1];
    int i = 0;
    for (int j = 0; j < this.targets.length; j++) {
      if (this.targets[j] != paramAccessible) {
        arrayOfAccessible[(i++)] = this.targets[j];
      }
    }
    this.targets = arrayOfAccessible;
  }
  
  boolean hasTargets()
  {
    return this.targets.length > 0;
  }
  
  void setString(long paramLong, String paramString)
  {
    char[] arrayOfChar = (paramString + "\000").toCharArray();
    long l = COM.SysAllocString(arrayOfChar);
    COM.MoveMemory(paramLong, new long[] { l }, OS.PTR_SIZEOF);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/accessibility/Relation.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */