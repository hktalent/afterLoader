package org.eclipse.swt.internal.mozilla;

public class nsIClassInfo
  extends nsISupports
{
  static final int LAST_METHOD_ID = nsISupports.LAST_METHOD_ID + 8;
  static final String NS_ICLASSINFO_IID_STR = "986c11d0-f340-11d4-9075-0010a4e73d9a";
  public static final int SINGLETON = 1;
  public static final int THREADSAFE = 2;
  public static final int MAIN_THREAD_ONLY = 4;
  public static final int DOM_OBJECT = 8;
  public static final int PLUGIN_OBJECT = 16;
  public static final int EAGER_CLASSINFO = 32;
  public static final int CONTENT_NODE = 64;
  
  public nsIClassInfo(long paramLong)
  {
    super(paramLong);
  }
  
  static
  {
    IIDStore.RegisterIID(nsIClassInfo.class, 0, new nsID("986c11d0-f340-11d4-9075-0010a4e73d9a"));
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/internal/mozilla/nsIClassInfo.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */