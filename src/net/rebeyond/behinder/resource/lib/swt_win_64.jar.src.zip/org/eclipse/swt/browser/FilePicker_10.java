package org.eclipse.swt.browser;

import org.eclipse.swt.internal.mozilla.XPCOMObject;

class FilePicker_10
  extends FilePicker_1_8
{
  void createCOMInterfaces()
  {
    this.supports = new XPCOMObject(new int[] { 2, 0, 0 })
    {
      public long method0(long[] paramAnonymousArrayOfLong)
      {
        return FilePicker_10.this.QueryInterface(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method1(long[] paramAnonymousArrayOfLong)
      {
        return FilePicker_10.this.AddRef();
      }
      
      public long method2(long[] paramAnonymousArrayOfLong)
      {
        return FilePicker_10.this.Release();
      }
    };
    this.filePicker = new XPCOMObject(new int[] { 2, 0, 0, 3, 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 })
    {
      public long method0(long[] paramAnonymousArrayOfLong)
      {
        return FilePicker_10.this.QueryInterface(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method1(long[] paramAnonymousArrayOfLong)
      {
        return FilePicker_10.this.AddRef();
      }
      
      public long method2(long[] paramAnonymousArrayOfLong)
      {
        return FilePicker_10.this.Release();
      }
      
      public long method3(long[] paramAnonymousArrayOfLong)
      {
        return FilePicker_10.this.Init(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], (short)(int)paramAnonymousArrayOfLong[2]);
      }
      
      public long method4(long[] paramAnonymousArrayOfLong)
      {
        return FilePicker_10.this.AppendFilters((int)paramAnonymousArrayOfLong[0]);
      }
      
      public long method5(long[] paramAnonymousArrayOfLong)
      {
        return FilePicker_10.this.AppendFilter(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method6(long[] paramAnonymousArrayOfLong)
      {
        return FilePicker_10.this.GetDefaultString(paramAnonymousArrayOfLong[0]);
      }
      
      public long method7(long[] paramAnonymousArrayOfLong)
      {
        return FilePicker_10.this.SetDefaultString(paramAnonymousArrayOfLong[0]);
      }
      
      public long method8(long[] paramAnonymousArrayOfLong)
      {
        return FilePicker_10.this.GetDefaultExtension(paramAnonymousArrayOfLong[0]);
      }
      
      public long method9(long[] paramAnonymousArrayOfLong)
      {
        return FilePicker_10.this.SetDefaultExtension(paramAnonymousArrayOfLong[0]);
      }
      
      public long method10(long[] paramAnonymousArrayOfLong)
      {
        return FilePicker_10.this.GetFilterIndex(paramAnonymousArrayOfLong[0]);
      }
      
      public long method11(long[] paramAnonymousArrayOfLong)
      {
        return FilePicker_10.this.SetFilterIndex((int)paramAnonymousArrayOfLong[0]);
      }
      
      public long method12(long[] paramAnonymousArrayOfLong)
      {
        return FilePicker_10.this.GetDisplayDirectory(paramAnonymousArrayOfLong[0]);
      }
      
      public long method13(long[] paramAnonymousArrayOfLong)
      {
        return FilePicker_10.this.SetDisplayDirectory(paramAnonymousArrayOfLong[0]);
      }
      
      public long method14(long[] paramAnonymousArrayOfLong)
      {
        return FilePicker_10.this.GetFile(paramAnonymousArrayOfLong[0]);
      }
      
      public long method15(long[] paramAnonymousArrayOfLong)
      {
        return FilePicker_10.this.GetFileURL(paramAnonymousArrayOfLong[0]);
      }
      
      public long method16(long[] paramAnonymousArrayOfLong)
      {
        return FilePicker_10.this.GetFiles(paramAnonymousArrayOfLong[0]);
      }
      
      public long method17(long[] paramAnonymousArrayOfLong)
      {
        return -2147467263L;
      }
      
      public long method18(long[] paramAnonymousArrayOfLong)
      {
        return -2147467263L;
      }
      
      public long method19(long[] paramAnonymousArrayOfLong)
      {
        return FilePicker_10.this.Show(paramAnonymousArrayOfLong[0]);
      }
    };
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/browser/FilePicker_10.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */