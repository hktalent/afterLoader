package org.eclipse.swt.internal.mozilla;

public class nsIScriptContext
  extends nsISupports
{
  static final String NS_ISCRIPTCONTEXT_1_9_IID_STR = "e7b9871d-3adc-4bf7-850d-7fb9554886bf";
  static final String NS_ISCRIPTCONTEXT_1_9_2_IID_STR = "87482b5e-e019-4df5-9bc2-b2a51b1f2d28";
  static final String NS_ISCRIPTCONTEXT_10_IID_STR = "2e583bf4-3c1f-432d-8283-8dee7eccc88b";
  static final String NS_ISCRIPTCONTEXT_24_IID_STR = "ef0c91ce-14f6-41c9-a577-a6ebdc6d447b";
  
  public nsIScriptContext(long paramLong)
  {
    super(paramLong);
  }
  
  static
  {
    IIDStore.RegisterIID(nsIScriptContext.class, 0, new nsID("e7b9871d-3adc-4bf7-850d-7fb9554886bf"));
    IIDStore.RegisterIID(nsIScriptContext.class, 4, new nsID("87482b5e-e019-4df5-9bc2-b2a51b1f2d28"));
    IIDStore.RegisterIID(nsIScriptContext.class, 5, new nsID("2e583bf4-3c1f-432d-8283-8dee7eccc88b"));
    IIDStore.RegisterIID(nsIScriptContext.class, 6, new nsID("ef0c91ce-14f6-41c9-a577-a6ebdc6d447b"));
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/internal/mozilla/nsIScriptContext.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */