package org.eclipse.swt.graphics;

import org.eclipse.swt.SWT;
import org.eclipse.swt.SWTException;
import org.eclipse.swt.internal.Compatibility;
import org.eclipse.swt.internal.gdip.Gdip;
import org.eclipse.swt.internal.gdip.PointF;
import org.eclipse.swt.internal.gdip.Rect;
import org.eclipse.swt.internal.gdip.RectF;
import org.eclipse.swt.internal.win32.BITMAP;
import org.eclipse.swt.internal.win32.BITMAPINFOHEADER;
import org.eclipse.swt.internal.win32.BLENDFUNCTION;
import org.eclipse.swt.internal.win32.GCP_RESULTS;
import org.eclipse.swt.internal.win32.GRADIENT_RECT;
import org.eclipse.swt.internal.win32.ICONINFO;
import org.eclipse.swt.internal.win32.LOGBRUSH;
import org.eclipse.swt.internal.win32.LOGFONT;
import org.eclipse.swt.internal.win32.LOGFONTA;
import org.eclipse.swt.internal.win32.LOGFONTW;
import org.eclipse.swt.internal.win32.LOGPEN;
import org.eclipse.swt.internal.win32.OS;
import org.eclipse.swt.internal.win32.POINT;
import org.eclipse.swt.internal.win32.RECT;
import org.eclipse.swt.internal.win32.SIZE;
import org.eclipse.swt.internal.win32.TCHAR;
import org.eclipse.swt.internal.win32.TEXTMETRIC;
import org.eclipse.swt.internal.win32.TEXTMETRICA;
import org.eclipse.swt.internal.win32.TEXTMETRICW;
import org.eclipse.swt.internal.win32.TRIVERTEX;

public final class GC
  extends Resource
{
  public long handle;
  Drawable drawable;
  GCData data;
  static final int FOREGROUND = 1;
  static final int BACKGROUND = 2;
  static final int FONT = 4;
  static final int LINE_STYLE = 8;
  static final int LINE_WIDTH = 16;
  static final int LINE_CAP = 32;
  static final int LINE_JOIN = 64;
  static final int LINE_MITERLIMIT = 128;
  static final int FOREGROUND_TEXT = 256;
  static final int BACKGROUND_TEXT = 512;
  static final int BRUSH = 1024;
  static final int PEN = 2048;
  static final int NULL_BRUSH = 4096;
  static final int NULL_PEN = 8192;
  static final int DRAW_OFFSET = 16384;
  static final int DRAW = 22777;
  static final int FILL = 9218;
  static final float[] LINE_DOT_ZERO = { 3.0F, 3.0F };
  static final float[] LINE_DASH_ZERO = { 18.0F, 6.0F };
  static final float[] LINE_DASHDOT_ZERO = { 9.0F, 6.0F, 3.0F, 6.0F };
  static final float[] LINE_DASHDOTDOT_ZERO = { 9.0F, 3.0F, 3.0F, 3.0F, 3.0F, 3.0F };
  
  GC() {}
  
  public GC(Drawable paramDrawable)
  {
    this(paramDrawable, 0);
  }
  
  public GC(Drawable paramDrawable, int paramInt)
  {
    if (paramDrawable == null) {
      SWT.error(4);
    }
    GCData localGCData = new GCData();
    localGCData.style = checkStyle(paramInt);
    long l = paramDrawable.internal_new_GC(localGCData);
    Device localDevice = localGCData.device;
    if (localDevice == null) {
      localDevice = Device.getDevice();
    }
    if (localDevice == null) {
      SWT.error(4);
    }
    this.device = (localGCData.device = localDevice);
    init(paramDrawable, localGCData, l);
    init();
  }
  
  static int checkStyle(int paramInt)
  {
    if ((paramInt & 0x2000000) != 0) {
      paramInt &= 0xFBFFFFFF;
    }
    return paramInt & 0x6000000;
  }
  
  void checkGC(int paramInt)
  {
    int i = this.data.state;
    if ((i & paramInt) == paramInt) {
      return;
    }
    i = (i ^ paramInt) & paramInt;
    this.data.state |= paramInt;
    long l1 = this.data.gdipGraphics;
    float f3;
    if (l1 != 0L)
    {
      long l2 = this.data.gdipPen;
      float f1 = this.data.lineWidth;
      int i6;
      long l10;
      if (((i & 0x1) != 0) || ((l2 == 0L) && ((i & 0xF8) != 0)))
      {
        if (this.data.gdipFgBrush != 0L) {
          Gdip.SolidBrush_delete(this.data.gdipFgBrush);
        }
        this.data.gdipFgBrush = 0L;
        Pattern localPattern = this.data.foregroundPattern;
        long l4;
        if (localPattern != null)
        {
          l4 = localPattern.handle;
          if ((this.data.style & 0x8000000) != 0) {
            switch (Gdip.Brush_GetType(l4))
            {
            case 2: 
              l4 = Gdip.Brush_Clone(l4);
              if (l4 == 0L) {
                SWT.error(2);
              }
              Gdip.TextureBrush_ScaleTransform(l4, -1.0F, 1.0F, 0);
              this.data.gdipFgBrush = l4;
            }
          }
        }
        else
        {
          i6 = this.data.foreground;
          int i7 = i6 >> 16 & 0xFF | i6 & 0xFF00 | (i6 & 0xFF) << 16;
          l10 = Gdip.Color_new(this.data.alpha << 24 | i7);
          if (l10 == 0L) {
            SWT.error(2);
          }
          l4 = Gdip.SolidBrush_new(l10);
          if (l4 == 0L) {
            SWT.error(2);
          }
          Gdip.Color_delete(l10);
          this.data.gdipFgBrush = l4;
        }
        if (l2 != 0L) {
          Gdip.Pen_SetBrush(l2, l4);
        } else {
          l2 = this.data.gdipPen = Gdip.Pen_new(l4, f1);
        }
      }
      if ((i & 0x10) != 0)
      {
        Gdip.Pen_SetWidth(l2, f1);
        switch (this.data.lineStyle)
        {
        case 6: 
          i |= 0x8;
        }
      }
      int i4;
      float f4;
      if ((i & 0x8) != 0)
      {
        float[] arrayOfFloat = null;
        float f2 = 0.0F;
        i4 = 0;
        switch (this.data.lineStyle)
        {
        case 1: 
          break;
        case 3: 
          i4 = 2;
          if (f1 == 0.0F) {
            arrayOfFloat = LINE_DOT_ZERO;
          }
          break;
        case 2: 
          i4 = 1;
          if (f1 == 0.0F) {
            arrayOfFloat = LINE_DASH_ZERO;
          }
          break;
        case 4: 
          i4 = 3;
          if (f1 == 0.0F) {
            arrayOfFloat = LINE_DASHDOT_ZERO;
          }
          break;
        case 5: 
          i4 = 4;
          if (f1 == 0.0F) {
            arrayOfFloat = LINE_DASHDOTDOT_ZERO;
          }
          break;
        case 6: 
          if (this.data.lineDashes != null)
          {
            f2 = this.data.lineDashesOffset / Math.max(1.0F, f1);
            arrayOfFloat = new float[this.data.lineDashes.length * 2];
            for (i6 = 0; i6 < this.data.lineDashes.length; i6++)
            {
              f4 = this.data.lineDashes[i6] / Math.max(1.0F, f1);
              arrayOfFloat[i6] = f4;
              arrayOfFloat[(i6 + this.data.lineDashes.length)] = f4;
            }
          }
          break;
        }
        if (arrayOfFloat != null)
        {
          Gdip.Pen_SetDashPattern(l2, arrayOfFloat, arrayOfFloat.length);
          Gdip.Pen_SetDashStyle(l2, 5);
          Gdip.Pen_SetDashOffset(l2, f2);
        }
        else
        {
          Gdip.Pen_SetDashStyle(l2, i4);
        }
      }
      if ((i & 0x80) != 0) {
        Gdip.Pen_SetMiterLimit(l2, this.data.lineMiterLimit);
      }
      int m;
      if ((i & 0x40) != 0)
      {
        m = 0;
        switch (this.data.lineJoin)
        {
        case 1: 
          m = 0;
          break;
        case 3: 
          m = 1;
          break;
        case 2: 
          m = 2;
        }
        Gdip.Pen_SetLineJoin(l2, m);
      }
      if ((i & 0x20) != 0)
      {
        m = 0;
        int i1 = 0;
        switch (this.data.lineCap)
        {
        case 1: 
          i1 = 0;
          break;
        case 2: 
          i1 = 2;
          m = 2;
          break;
        case 3: 
          i1 = 1;
        }
        Gdip.Pen_SetLineCap(l2, i1, i1, m);
      }
      Object localObject;
      if ((i & 0x2) != 0)
      {
        if (this.data.gdipBgBrush != 0L) {
          Gdip.SolidBrush_delete(this.data.gdipBgBrush);
        }
        this.data.gdipBgBrush = 0L;
        localObject = this.data.backgroundPattern;
        if (localObject != null)
        {
          this.data.gdipBrush = ((Pattern)localObject).handle;
          if ((this.data.style & 0x8000000) != 0) {
            switch (Gdip.Brush_GetType(this.data.gdipBrush))
            {
            case 2: 
              long l6 = Gdip.Brush_Clone(this.data.gdipBrush);
              if (l6 == 0L) {
                SWT.error(2);
              }
              Gdip.TextureBrush_ScaleTransform(l6, -1.0F, 1.0F, 0);
              this.data.gdipBrush = (this.data.gdipBgBrush = l6);
            }
          }
        }
        else
        {
          int i2 = this.data.background;
          i4 = i2 >> 16 & 0xFF | i2 & 0xFF00 | (i2 & 0xFF) << 16;
          long l8 = Gdip.Color_new(this.data.alpha << 24 | i4);
          if (l8 == 0L) {
            SWT.error(2);
          }
          l10 = Gdip.SolidBrush_new(l8);
          if (l10 == 0L) {
            SWT.error(2);
          }
          Gdip.Color_delete(l8);
          this.data.gdipBrush = (this.data.gdipBgBrush = l10);
        }
      }
      if ((i & 0x4) != 0)
      {
        localObject = this.data.font;
        OS.SelectObject(this.handle, ((Font)localObject).handle);
        long[] arrayOfLong = new long[1];
        long l7 = createGdipFont(this.handle, ((Font)localObject).handle, l1, this.device.fontCollection, null, arrayOfLong);
        if (arrayOfLong[0] != 0L) {
          OS.SelectObject(this.handle, arrayOfLong[0]);
        }
        if (this.data.hGDIFont != 0L) {
          OS.DeleteObject(this.data.hGDIFont);
        }
        this.data.hGDIFont = arrayOfLong[0];
        if (this.data.gdipFont != 0L) {
          Gdip.Font_delete(this.data.gdipFont);
        }
        this.data.gdipFont = l7;
      }
      if ((i & 0x4000) != 0)
      {
        this.data.gdipXOffset = (this.data.gdipYOffset = 0.0F);
        long l5 = Gdip.Matrix_new(1.0F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F);
        PointF localPointF = new PointF();
        localPointF.X = (localPointF.Y = 1.0F);
        Gdip.Graphics_GetTransform(l1, l5);
        Gdip.Matrix_TransformVectors(l5, localPointF, 1);
        Gdip.Matrix_delete(l5);
        f3 = localPointF.X;
        if (f3 < 0.0F) {
          f3 = -f3;
        }
        f4 = this.data.lineWidth * f3;
        if ((f4 == 0.0F) || ((int)f4 % 2 == 1)) {
          this.data.gdipXOffset = (0.5F / f3);
        }
        f3 = localPointF.Y;
        if (f3 < 0.0F) {
          f3 = -f3;
        }
        f4 = this.data.lineWidth * f3;
        if ((f4 == 0.0F) || ((int)f4 % 2 == 1)) {
          this.data.gdipYOffset = (0.5F / f3);
        }
      }
      return;
    }
    if ((i & 0x79) != 0)
    {
      int j = this.data.foreground;
      int k = (int)this.data.lineWidth;
      int[] arrayOfInt = null;
      int n = 0;
      switch (this.data.lineStyle)
      {
      case 1: 
        break;
      case 2: 
        n = 1;
        break;
      case 3: 
        n = 2;
        break;
      case 4: 
        n = 3;
        break;
      case 5: 
        n = 4;
        break;
      case 6: 
        if (this.data.lineDashes != null)
        {
          n = 7;
          arrayOfInt = new int[this.data.lineDashes.length];
          for (i3 = 0; i3 < arrayOfInt.length; i3++) {
            arrayOfInt[i3] = ((int)this.data.lineDashes[i3]);
          }
        }
        break;
      }
      if ((i & 0x8) != 0) {
        OS.SetBkMode(this.handle, this.data.lineStyle == 1 ? 2 : 1);
      }
      int i3 = 0;
      switch (this.data.lineJoin)
      {
      case 1: 
        i3 = 8192;
        break;
      case 2: 
        i3 = 0;
        break;
      case 3: 
        i3 = 4096;
      }
      int i5 = 0;
      switch (this.data.lineCap)
      {
      case 2: 
        i5 = 0;
        break;
      case 1: 
        i5 = 512;
        break;
      case 3: 
        i5 = 256;
      }
      f3 = n | i3 | i5;
      long l9;
      if ((OS.IsWinCE) || ((k == 0) && (n != 7)) || (f3 == 0))
      {
        l9 = OS.CreatePen(f3 & 0xF, k, j);
      }
      else
      {
        LOGBRUSH localLOGBRUSH = new LOGBRUSH();
        localLOGBRUSH.lbStyle = 0;
        localLOGBRUSH.lbColor = j;
        l9 = OS.ExtCreatePen(f3 | 0x10000, Math.max(1, k), localLOGBRUSH, arrayOfInt != null ? arrayOfInt.length : 0, arrayOfInt);
      }
      OS.SelectObject(this.handle, l9);
      this.data.state |= 0x800;
      this.data.state &= 0xDFFF;
      if (this.data.hPen != 0L) {
        OS.DeleteObject(this.data.hPen);
      }
      this.data.hPen = (this.data.hOldPen = l9);
    }
    else if ((i & 0x800) != 0)
    {
      OS.SelectObject(this.handle, this.data.hOldPen);
      this.data.state &= 0xDFFF;
    }
    else if ((i & 0x2000) != 0)
    {
      this.data.hOldPen = OS.SelectObject(this.handle, OS.GetStockObject(8));
      this.data.state &= 0xF7FF;
    }
    if ((i & 0x2) != 0)
    {
      long l3 = OS.CreateSolidBrush(this.data.background);
      OS.SelectObject(this.handle, l3);
      this.data.state |= 0x400;
      this.data.state &= 0xEFFF;
      if (this.data.hBrush != 0L) {
        OS.DeleteObject(this.data.hBrush);
      }
      this.data.hOldBrush = (this.data.hBrush = l3);
    }
    else if ((i & 0x400) != 0)
    {
      OS.SelectObject(this.handle, this.data.hOldBrush);
      this.data.state &= 0xEFFF;
    }
    else if ((i & 0x1000) != 0)
    {
      this.data.hOldBrush = OS.SelectObject(this.handle, OS.GetStockObject(5));
      this.data.state &= 0xFBFF;
    }
    if ((i & 0x200) != 0) {
      OS.SetBkColor(this.handle, this.data.background);
    }
    if ((i & 0x100) != 0) {
      OS.SetTextColor(this.handle, this.data.foreground);
    }
    if ((i & 0x4) != 0)
    {
      Font localFont = this.data.font;
      OS.SelectObject(this.handle, localFont.handle);
    }
  }
  
  public void copyArea(Image paramImage, int paramInt1, int paramInt2)
  {
    if (this.handle == 0L) {
      SWT.error(44);
    }
    if (paramImage == null) {
      SWT.error(4);
    }
    if ((paramImage.type != 0) || (paramImage.isDisposed())) {
      SWT.error(5);
    }
    Rectangle localRectangle = paramImage.getBounds();
    long l1 = OS.CreateCompatibleDC(this.handle);
    long l2 = OS.SelectObject(l1, paramImage.handle);
    OS.BitBlt(l1, 0, 0, localRectangle.width, localRectangle.height, this.handle, paramInt1, paramInt2, 13369376);
    OS.SelectObject(l1, l2);
    OS.DeleteDC(l1);
  }
  
  public void copyArea(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6)
  {
    copyArea(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, true);
  }
  
  public void copyArea(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, boolean paramBoolean)
  {
    if (this.handle == 0L) {
      SWT.error(44);
    }
    long l1 = this.data.hwnd;
    if (l1 == 0L)
    {
      OS.BitBlt(this.handle, paramInt5, paramInt6, paramInt3, paramInt4, this.handle, paramInt1, paramInt2, 13369376);
    }
    else
    {
      RECT localRECT1 = null;
      long l2 = OS.CreateRectRgn(0, 0, 0, 0);
      if (OS.GetClipRgn(this.handle, l2) == 1)
      {
        localRECT1 = new RECT();
        OS.GetRgnBox(l2, localRECT1);
      }
      OS.DeleteObject(l2);
      RECT localRECT2 = new RECT();
      OS.SetRect(localRECT2, paramInt1, paramInt2, paramInt1 + paramInt3, paramInt2 + paramInt4);
      int i = paramBoolean ? 6 : 0;
      int j = OS.ScrollWindowEx(l1, paramInt5 - paramInt1, paramInt6 - paramInt2, localRECT2, localRECT1, 0L, null, i);
      if ((j == 0) && (OS.IsWinCE))
      {
        OS.BitBlt(this.handle, paramInt5, paramInt6, paramInt3, paramInt4, this.handle, paramInt1, paramInt2, 13369376);
        if (paramBoolean)
        {
          int k = paramInt5 - paramInt1;
          int m = paramInt6 - paramInt2;
          int n = (paramInt5 + paramInt3 < paramInt1) || (paramInt1 + paramInt3 < paramInt5) || (paramInt6 + paramInt4 < paramInt2) || (paramInt2 + paramInt4 < paramInt6) ? 1 : 0;
          if (n != 0)
          {
            OS.InvalidateRect(l1, localRECT2, true);
          }
          else
          {
            int i1;
            if (k != 0)
            {
              i1 = paramInt5 - k;
              if (k < 0) {
                i1 = paramInt5 + paramInt3;
              }
              OS.SetRect(localRECT2, i1, paramInt2, i1 + Math.abs(k), paramInt2 + paramInt4);
              OS.InvalidateRect(l1, localRECT2, true);
            }
            if (m != 0)
            {
              i1 = paramInt6 - m;
              if (m < 0) {
                i1 = paramInt6 + paramInt4;
              }
              OS.SetRect(localRECT2, paramInt1, i1, paramInt1 + paramInt3, i1 + Math.abs(m));
              OS.InvalidateRect(l1, localRECT2, true);
            }
          }
        }
      }
    }
  }
  
  static long createGdipFont(long paramLong1, long paramLong2, long paramLong3, long paramLong4, long[] paramArrayOfLong1, long[] paramArrayOfLong2)
  {
    long l1 = Gdip.Font_new(paramLong1, paramLong2);
    if (l1 == 0L) {
      SWT.error(2);
    }
    long l2 = 0L;
    if (!Gdip.Font_IsAvailable(l1))
    {
      Gdip.Font_delete(l1);
      LOGFONTA localLOGFONTA = OS.IsUnicode ? new LOGFONTW() : new LOGFONTA();
      OS.GetObject(paramLong2, LOGFONT.sizeof, localLOGFONTA);
      int i = Math.abs(localLOGFONTA.lfHeight);
      int j = 0;
      if (localLOGFONTA.lfWeight == 700) {
        j |= 0x1;
      }
      if (localLOGFONTA.lfItalic != 0) {
        j |= 0x2;
      }
      char[] arrayOfChar1;
      if (OS.IsUnicode)
      {
        arrayOfChar1 = ((LOGFONTW)localLOGFONTA).lfFaceName;
      }
      else
      {
        arrayOfChar1 = new char[32];
        byte[] arrayOfByte = ((LOGFONTA)localLOGFONTA).lfFaceName;
        OS.MultiByteToWideChar(0, 1, arrayOfByte, arrayOfByte.length, arrayOfChar1, arrayOfChar1.length);
      }
      for (int k = 0; (k < arrayOfChar1.length) && (arrayOfChar1[k] != 0); k++) {}
      String str = new String(arrayOfChar1, 0, k);
      if (Compatibility.equalsIgnoreCase(str, "Courier")) {
        str = "Courier New";
      }
      char[] arrayOfChar2 = new char[str.length() + 1];
      str.getChars(0, str.length(), arrayOfChar2, 0);
      if (paramLong4 != 0L)
      {
        l2 = Gdip.FontFamily_new(arrayOfChar2, paramLong4);
        if (!Gdip.FontFamily_IsAvailable(l2))
        {
          Gdip.FontFamily_delete(l2);
          l2 = Gdip.FontFamily_new(arrayOfChar2, 0L);
          if (!Gdip.FontFamily_IsAvailable(l2))
          {
            Gdip.FontFamily_delete(l2);
            l2 = 0L;
          }
        }
      }
      if (l2 != 0L) {
        l1 = Gdip.Font_new(l2, i, j, 2);
      } else {
        l1 = Gdip.Font_new(arrayOfChar2, i, j, 2, 0L);
      }
      if ((paramArrayOfLong2 != null) && (l1 != 0L))
      {
        long l3 = OS.GetProcessHeap();
        long l4 = OS.HeapAlloc(l3, 8, LOGFONTW.sizeof);
        Gdip.Font_GetLogFontW(l1, paramLong3, l4);
        paramArrayOfLong2[0] = OS.CreateFontIndirectW(l4);
        OS.HeapFree(l3, 0, l4);
      }
    }
    if ((paramArrayOfLong1 != null) && (l1 != 0L))
    {
      if (l2 == 0L)
      {
        l2 = Gdip.FontFamily_new();
        Gdip.Font_GetFamily(l1, l2);
      }
      paramArrayOfLong1[0] = l2;
    }
    else if (l2 != 0L)
    {
      Gdip.FontFamily_delete(l2);
    }
    if (l1 == 0L) {
      SWT.error(2);
    }
    return l1;
  }
  
  static void destroyGdipBrush(long paramLong)
  {
    int i = Gdip.Brush_GetType(paramLong);
    switch (i)
    {
    case 0: 
      Gdip.SolidBrush_delete(paramLong);
      break;
    case 1: 
      Gdip.HatchBrush_delete(paramLong);
      break;
    case 4: 
      Gdip.LinearGradientBrush_delete(paramLong);
      break;
    case 2: 
      Gdip.TextureBrush_delete(paramLong);
    }
  }
  
  void destroy()
  {
    int i = this.data.gdipGraphics != 0L ? 1 : 0;
    disposeGdip();
    if ((i != 0) && ((this.data.style & 0x8000000) != 0)) {
      OS.SetLayout(this.handle, OS.GetLayout(this.handle) | 0x1);
    }
    if (this.data.hPen != 0L)
    {
      OS.SelectObject(this.handle, OS.GetStockObject(8));
      OS.DeleteObject(this.data.hPen);
      this.data.hPen = 0L;
    }
    if (this.data.hBrush != 0L)
    {
      OS.SelectObject(this.handle, OS.GetStockObject(5));
      OS.DeleteObject(this.data.hBrush);
      this.data.hBrush = 0L;
    }
    long l = this.data.hNullBitmap;
    if (l != 0L)
    {
      OS.SelectObject(this.handle, l);
      this.data.hNullBitmap = 0L;
    }
    Image localImage = this.data.image;
    if (localImage != null) {
      localImage.memGC = null;
    }
    if (this.drawable != null) {
      this.drawable.internal_dispose_GC(this.handle, this.data);
    }
    this.drawable = null;
    this.handle = 0L;
    this.data.image = null;
    this.data.ps = null;
    this.data = null;
  }
  
  void disposeGdip()
  {
    if (this.data.gdipPen != 0L) {
      Gdip.Pen_delete(this.data.gdipPen);
    }
    if (this.data.gdipBgBrush != 0L) {
      destroyGdipBrush(this.data.gdipBgBrush);
    }
    if (this.data.gdipFgBrush != 0L) {
      destroyGdipBrush(this.data.gdipFgBrush);
    }
    if (this.data.gdipFont != 0L) {
      Gdip.Font_delete(this.data.gdipFont);
    }
    if (this.data.hGDIFont != 0L) {
      OS.DeleteObject(this.data.hGDIFont);
    }
    if (this.data.gdipGraphics != 0L) {
      Gdip.Graphics_delete(this.data.gdipGraphics);
    }
    this.data.gdipGraphics = (this.data.gdipBrush = this.data.gdipBgBrush = this.data.gdipFgBrush = this.data.gdipFont = this.data.gdipPen = this.data.hGDIFont = 0L);
  }
  
  public void drawArc(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6)
  {
    if (this.handle == 0L) {
      SWT.error(44);
    }
    checkGC(22777);
    if (paramInt3 < 0)
    {
      paramInt1 += paramInt3;
      paramInt3 = -paramInt3;
    }
    if (paramInt4 < 0)
    {
      paramInt2 += paramInt4;
      paramInt4 = -paramInt4;
    }
    if ((paramInt3 == 0) || (paramInt4 == 0) || (paramInt6 == 0)) {
      return;
    }
    long l1 = this.data.gdipGraphics;
    if (l1 != 0L)
    {
      Gdip.Graphics_TranslateTransform(l1, this.data.gdipXOffset, this.data.gdipYOffset, 0);
      if (paramInt3 == paramInt4)
      {
        Gdip.Graphics_DrawArc(l1, this.data.gdipPen, paramInt1, paramInt2, paramInt3, paramInt4, -paramInt5, -paramInt6);
      }
      else
      {
        long l2 = Gdip.GraphicsPath_new(0);
        if (l2 == 0L) {
          SWT.error(2);
        }
        long l3 = Gdip.Matrix_new(paramInt3, 0.0F, 0.0F, paramInt4, paramInt1, paramInt2);
        if (l3 == 0L) {
          SWT.error(2);
        }
        Gdip.GraphicsPath_AddArc(l2, 0.0F, 0.0F, 1.0F, 1.0F, -paramInt5, -paramInt6);
        Gdip.GraphicsPath_Transform(l2, l3);
        Gdip.Graphics_DrawPath(l1, this.data.gdipPen, l2);
        Gdip.Matrix_delete(l3);
        Gdip.GraphicsPath_delete(l2);
      }
      Gdip.Graphics_TranslateTransform(l1, -this.data.gdipXOffset, -this.data.gdipYOffset, 0);
      return;
    }
    if (((this.data.style & 0x8000000) != 0) && (this.data.lineWidth != 0.0F) && (this.data.lineWidth % 2.0F == 0.0F)) {
      paramInt1--;
    }
    int j;
    int k;
    int m;
    int n;
    if (OS.IsWinCE)
    {
      if (paramInt6 < 0)
      {
        paramInt5 += paramInt6;
        paramInt6 = -paramInt6;
      }
      if (paramInt6 > 360) {
        paramInt6 = 360;
      }
      int[] arrayOfInt = new int[(paramInt6 + 1) * 2];
      j = 2 * paramInt1 + paramInt3;
      k = 2 * paramInt2 + paramInt4;
      m = 0;
      for (n = 0; n <= paramInt6; n++)
      {
        arrayOfInt[(m++)] = (Compatibility.cos(paramInt5 + n, paramInt3) + j >> 1);
        arrayOfInt[(m++)] = (k - Compatibility.sin(paramInt5 + n, paramInt4) >> 1);
      }
      OS.Polyline(this.handle, arrayOfInt, arrayOfInt.length / 2);
    }
    else
    {
      int i;
      if ((paramInt6 >= 360) || (paramInt6 <= 65176))
      {
        i = k = paramInt1 + paramInt3;
        j = m = paramInt2 + paramInt4 / 2;
      }
      else
      {
        int i1 = paramInt6 < 0 ? 1 : 0;
        paramInt6 += paramInt5;
        if (i1 != 0)
        {
          n = paramInt5;
          paramInt5 = paramInt6;
          paramInt6 = n;
        }
        i = Compatibility.cos(paramInt5, paramInt3) + paramInt1 + paramInt3 / 2;
        j = -1 * Compatibility.sin(paramInt5, paramInt4) + paramInt2 + paramInt4 / 2;
        k = Compatibility.cos(paramInt6, paramInt3) + paramInt1 + paramInt3 / 2;
        m = -1 * Compatibility.sin(paramInt6, paramInt4) + paramInt2 + paramInt4 / 2;
      }
      OS.Arc(this.handle, paramInt1, paramInt2, paramInt1 + paramInt3 + 1, paramInt2 + paramInt4 + 1, i, j, k, m);
    }
  }
  
  public void drawFocus(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    if (this.handle == 0L) {
      SWT.error(44);
    }
    if ((this.data.uiState & 0x1) != 0) {
      return;
    }
    this.data.focusDrawn = true;
    long l1 = this.handle;
    int i = 0;
    long l2 = this.data.gdipGraphics;
    if (l2 != 0L)
    {
      long l3 = 0L;
      Gdip.Graphics_SetPixelOffsetMode(l2, 3);
      long l4 = Gdip.Region_new();
      if (l4 == 0L) {
        SWT.error(2);
      }
      Gdip.Graphics_GetClip(l2, l4);
      if (!Gdip.Region_IsInfinite(l4, l2)) {
        l3 = Gdip.Region_GetHRGN(l4, l2);
      }
      Gdip.Region_delete(l4);
      Gdip.Graphics_SetPixelOffsetMode(l2, 4);
      float[] arrayOfFloat = null;
      long l5 = Gdip.Matrix_new(1.0F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F);
      if (l5 == 0L) {
        SWT.error(2);
      }
      Gdip.Graphics_GetTransform(l2, l5);
      if (!Gdip.Matrix_IsIdentity(l5))
      {
        arrayOfFloat = new float[6];
        Gdip.Matrix_GetElements(l5, arrayOfFloat);
      }
      Gdip.Matrix_delete(l5);
      l1 = Gdip.Graphics_GetHDC(l2);
      i = OS.SaveDC(l1);
      if (arrayOfFloat != null)
      {
        OS.SetGraphicsMode(l1, 2);
        OS.SetWorldTransform(l1, arrayOfFloat);
      }
      if (l3 != 0L)
      {
        OS.SelectClipRgn(l1, l3);
        OS.DeleteObject(l3);
      }
    }
    OS.SetBkColor(l1, 16777215);
    OS.SetTextColor(l1, 0);
    RECT localRECT = new RECT();
    OS.SetRect(localRECT, paramInt1, paramInt2, paramInt1 + paramInt3, paramInt2 + paramInt4);
    OS.DrawFocusRect(l1, localRECT);
    if (l2 != 0L)
    {
      OS.RestoreDC(l1, i);
      Gdip.Graphics_ReleaseHDC(l2, l1);
    }
    else
    {
      this.data.state &= 0xFCFF;
    }
  }
  
  public void drawImage(Image paramImage, int paramInt1, int paramInt2)
  {
    if (this.handle == 0L) {
      SWT.error(44);
    }
    if (paramImage == null) {
      SWT.error(4);
    }
    if (paramImage.isDisposed()) {
      SWT.error(5);
    }
    drawImage(paramImage, 0, 0, -1, -1, paramInt1, paramInt2, -1, -1, true);
  }
  
  public void drawImage(Image paramImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8)
  {
    if (this.handle == 0L) {
      SWT.error(44);
    }
    if ((paramInt3 == 0) || (paramInt4 == 0) || (paramInt7 == 0) || (paramInt8 == 0)) {
      return;
    }
    if ((paramInt1 < 0) || (paramInt2 < 0) || (paramInt3 < 0) || (paramInt4 < 0) || (paramInt7 < 0) || (paramInt8 < 0)) {
      SWT.error(5);
    }
    if (paramImage == null) {
      SWT.error(4);
    }
    if (paramImage.isDisposed()) {
      SWT.error(5);
    }
    drawImage(paramImage, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8, false);
  }
  
  void drawImage(Image paramImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, boolean paramBoolean)
  {
    if (this.data.gdipGraphics != 0L)
    {
      long[] arrayOfLong = paramImage.createGdipImage();
      long l1 = arrayOfLong[0];
      int i = Gdip.Image_GetWidth(l1);
      int j = Gdip.Image_GetHeight(l1);
      if (paramBoolean)
      {
        paramInt3 = paramInt7 = i;
        paramInt4 = paramInt8 = j;
      }
      else
      {
        if ((paramInt1 + paramInt3 > i) || (paramInt2 + paramInt4 > j)) {
          SWT.error(5);
        }
        paramBoolean = (paramInt1 == 0) && (paramInt2 == 0) && (paramInt3 == paramInt7) && (paramInt7 == i) && (paramInt4 == paramInt8) && (paramInt8 == j);
      }
      Rect localRect = new Rect();
      localRect.X = paramInt5;
      localRect.Y = paramInt6;
      localRect.Width = paramInt7;
      localRect.Height = paramInt8;
      long l2 = Gdip.ImageAttributes_new();
      Gdip.ImageAttributes_SetWrapMode(l2, 3);
      if (this.data.alpha != 255)
      {
        float[] arrayOfFloat = { 1.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, this.data.alpha / 255.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F };
        Gdip.ImageAttributes_SetColorMatrix(l2, arrayOfFloat, 0, 1);
      }
      int k = 0;
      if ((this.data.style & 0x8000000) != 0)
      {
        k = Gdip.Graphics_Save(this.data.gdipGraphics);
        Gdip.Graphics_ScaleTransform(this.data.gdipGraphics, -1.0F, 1.0F, 0);
        Gdip.Graphics_TranslateTransform(this.data.gdipGraphics, -2 * paramInt5 - paramInt7, 0.0F, 0);
      }
      Gdip.Graphics_DrawImage(this.data.gdipGraphics, l1, localRect, paramInt1, paramInt2, paramInt3, paramInt4, 2, l2, 0L, 0L);
      if ((this.data.style & 0x8000000) != 0) {
        Gdip.Graphics_Restore(this.data.gdipGraphics, k);
      }
      Gdip.ImageAttributes_delete(l2);
      Gdip.Bitmap_delete(l1);
      if (arrayOfLong[1] != 0L)
      {
        long l3 = OS.GetProcessHeap();
        OS.HeapFree(l3, 0, arrayOfLong[1]);
      }
      return;
    }
    switch (paramImage.type)
    {
    case 0: 
      drawBitmap(paramImage, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8, paramBoolean);
      break;
    case 1: 
      drawIcon(paramImage, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8, paramBoolean);
    }
  }
  
  void drawIcon(Image paramImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, boolean paramBoolean)
  {
    int i = OS.GetDeviceCaps(this.handle, 2);
    int j = 1;
    int k = 3;
    int m = 0;
    int n = 0;
    if ((!OS.IsWinCE) && (OS.WIN32_VERSION >= OS.VERSION(5, 1)))
    {
      if ((OS.GetLayout(this.handle) & 0x1) != 0)
      {
        k |= 0x10;
        localObject = new POINT();
        OS.GetWindowOrgEx(this.handle, (POINT)localObject);
        m = ((POINT)localObject).x;
        n = ((POINT)localObject).y;
      }
    }
    else if ((!OS.IsWinCE) && (OS.WIN32_VERSION >= OS.VERSION(4, 10))) {
      j = (OS.GetLayout(this.handle) & 0x1) == 0 ? 1 : 0;
    }
    if ((paramBoolean) && (i != 2) && (j != 0))
    {
      if ((m != 0) || (n != 0)) {
        OS.SetWindowOrgEx(this.handle, 0, 0, null);
      }
      OS.DrawIconEx(this.handle, paramInt5 - m, paramInt6 - n, paramImage.handle, 0, 0, 0, 0L, k);
      if ((m != 0) || (n != 0)) {
        OS.SetWindowOrgEx(this.handle, m, n, null);
      }
      return;
    }
    Object localObject = new ICONINFO();
    if (OS.IsWinCE) {
      Image.GetIconInfo(paramImage, (ICONINFO)localObject);
    } else {
      OS.GetIconInfo(paramImage.handle, (ICONINFO)localObject);
    }
    long l1 = ((ICONINFO)localObject).hbmColor;
    if (l1 == 0L) {
      l1 = ((ICONINFO)localObject).hbmMask;
    }
    BITMAP localBITMAP = new BITMAP();
    OS.GetObject(l1, BITMAP.sizeof, localBITMAP);
    int i1 = localBITMAP.bmWidth;
    int i2 = localBITMAP.bmHeight;
    if (l1 == ((ICONINFO)localObject).hbmMask) {
      i2 /= 2;
    }
    if (paramBoolean)
    {
      paramInt3 = paramInt7 = i1;
      paramInt4 = paramInt8 = i2;
    }
    int i3 = (paramInt1 + paramInt3 > i1) || (paramInt2 + paramInt4 > i2) ? 1 : 0;
    if (i3 == 0)
    {
      paramBoolean = (paramInt1 == 0) && (paramInt2 == 0) && (paramInt3 == paramInt7) && (paramInt4 == paramInt8) && (paramInt3 == i1) && (paramInt4 == i2);
      if (j == 0)
      {
        drawBitmapMask(paramImage, ((ICONINFO)localObject).hbmColor, ((ICONINFO)localObject).hbmMask, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8, paramBoolean, i1, i2, false);
      }
      else if ((paramBoolean) && (i != 2))
      {
        if ((m != 0) || (n != 0)) {
          OS.SetWindowOrgEx(this.handle, 0, 0, null);
        }
        OS.DrawIconEx(this.handle, paramInt5 - m, paramInt6 - n, paramImage.handle, 0, 0, 0, 0L, k);
        if ((m != 0) || (n != 0)) {
          OS.SetWindowOrgEx(this.handle, m, n, null);
        }
      }
      else
      {
        ICONINFO localICONINFO = new ICONINFO();
        localICONINFO.fIcon = true;
        long l2 = OS.CreateCompatibleDC(this.handle);
        long l3 = OS.CreateCompatibleDC(this.handle);
        int i4 = paramInt2;
        long l4 = ((ICONINFO)localObject).hbmColor;
        if (l4 == 0L)
        {
          l4 = ((ICONINFO)localObject).hbmMask;
          i4 += i2;
        }
        long l5 = OS.SelectObject(l2, l4);
        localICONINFO.hbmColor = OS.CreateCompatibleBitmap(l2, paramInt7, paramInt8);
        if (localICONINFO.hbmColor == 0L) {
          SWT.error(2);
        }
        long l6 = OS.SelectObject(l3, localICONINFO.hbmColor);
        int i5 = (!paramBoolean) && ((paramInt3 != paramInt7) || (paramInt4 != paramInt8)) ? 1 : 0;
        if (i5 != 0)
        {
          if (!OS.IsWinCE) {
            OS.SetStretchBltMode(l3, 3);
          }
          OS.StretchBlt(l3, 0, 0, paramInt7, paramInt8, l2, paramInt1, i4, paramInt3, paramInt4, 13369376);
        }
        else
        {
          OS.BitBlt(l3, 0, 0, paramInt7, paramInt8, l2, paramInt1, i4, 13369376);
        }
        OS.SelectObject(l2, ((ICONINFO)localObject).hbmMask);
        localICONINFO.hbmMask = OS.CreateBitmap(paramInt7, paramInt8, 1, 1, null);
        if (localICONINFO.hbmMask == 0L) {
          SWT.error(2);
        }
        OS.SelectObject(l3, localICONINFO.hbmMask);
        if (i5 != 0) {
          OS.StretchBlt(l3, 0, 0, paramInt7, paramInt8, l2, paramInt1, paramInt2, paramInt3, paramInt4, 13369376);
        } else {
          OS.BitBlt(l3, 0, 0, paramInt7, paramInt8, l2, paramInt1, paramInt2, 13369376);
        }
        if (i == 2)
        {
          OS.SelectObject(l2, localICONINFO.hbmColor);
          OS.SelectObject(l3, localICONINFO.hbmMask);
          drawBitmapTransparentByClipping(l2, l3, 0, 0, paramInt7, paramInt8, paramInt5, paramInt6, paramInt7, paramInt8, true, paramInt7, paramInt8);
          OS.SelectObject(l2, l5);
          OS.SelectObject(l3, l6);
        }
        else
        {
          OS.SelectObject(l2, l5);
          OS.SelectObject(l3, l6);
          long l7 = OS.CreateIconIndirect(localICONINFO);
          if (l7 == 0L) {
            SWT.error(2);
          }
          if ((m != 0) || (n != 0)) {
            OS.SetWindowOrgEx(this.handle, 0, 0, null);
          }
          OS.DrawIconEx(this.handle, paramInt5 - m, paramInt6 - n, l7, paramInt7, paramInt8, 0, 0L, k);
          if ((m != 0) || (n != 0)) {
            OS.SetWindowOrgEx(this.handle, m, n, null);
          }
          OS.DestroyIcon(l7);
        }
        OS.DeleteObject(localICONINFO.hbmMask);
        OS.DeleteObject(localICONINFO.hbmColor);
        OS.DeleteDC(l3);
        OS.DeleteDC(l2);
      }
    }
    OS.DeleteObject(((ICONINFO)localObject).hbmMask);
    if (((ICONINFO)localObject).hbmColor != 0L) {
      OS.DeleteObject(((ICONINFO)localObject).hbmColor);
    }
    if (i3 != 0) {
      SWT.error(5);
    }
  }
  
  void drawBitmap(Image paramImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, boolean paramBoolean)
  {
    BITMAP localBITMAP = new BITMAP();
    OS.GetObject(paramImage.handle, BITMAP.sizeof, localBITMAP);
    int i = localBITMAP.bmWidth;
    int j = localBITMAP.bmHeight;
    if (paramBoolean)
    {
      paramInt3 = paramInt7 = i;
      paramInt4 = paramInt8 = j;
    }
    else
    {
      if ((paramInt1 + paramInt3 > i) || (paramInt2 + paramInt4 > j)) {
        SWT.error(5);
      }
      paramBoolean = (paramInt1 == 0) && (paramInt2 == 0) && (paramInt3 == paramInt7) && (paramInt7 == i) && (paramInt4 == paramInt8) && (paramInt8 == j);
    }
    int k = 0;
    GC localGC = paramImage.memGC;
    if ((localGC != null) && (!localGC.isDisposed()))
    {
      localGC.flush();
      k = 1;
      GCData localGCData = localGC.data;
      if (localGCData.hNullBitmap != 0L)
      {
        OS.SelectObject(localGC.handle, localGCData.hNullBitmap);
        localGCData.hNullBitmap = 0L;
      }
    }
    if ((paramImage.alpha != -1) || (paramImage.alphaData != null)) {
      drawBitmapAlpha(paramImage, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8, paramBoolean, localBITMAP, i, j);
    } else if (paramImage.transparentPixel != -1) {
      drawBitmapTransparent(paramImage, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8, paramBoolean, localBITMAP, i, j);
    } else {
      drawBitmap(paramImage, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8, paramBoolean, localBITMAP, i, j);
    }
    if (k != 0)
    {
      long l = OS.SelectObject(localGC.handle, paramImage.handle);
      localGC.data.hNullBitmap = l;
    }
  }
  
  void drawBitmapAlpha(Image paramImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, boolean paramBoolean, BITMAP paramBITMAP, int paramInt9, int paramInt10)
  {
    if (paramImage.alpha == 0) {
      return;
    }
    if (paramImage.alpha == 255)
    {
      drawBitmap(paramImage, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8, paramBoolean, paramBITMAP, paramInt9, paramInt10);
      return;
    }
    int i = (OS.IsWinNT) && (OS.WIN32_VERSION >= OS.VERSION(4, 10)) ? 1 : 0;
    int j = OS.GetDeviceCaps(this.handle, 2) == 2 ? 1 : 0;
    if ((i != 0) && (j != 0))
    {
      int k = OS.GetDeviceCaps(this.handle, 120);
      if (k != 0) {
        if (paramImage.alpha != -1) {
          i = (k & 0x1) != 0 ? 1 : 0;
        } else {
          i = (k & 0x2) != 0 ? 1 : 0;
        }
      }
    }
    int i11;
    if (i != 0)
    {
      localObject = new BLENDFUNCTION();
      ((BLENDFUNCTION)localObject).BlendOp = 0;
      long l1 = OS.CreateCompatibleDC(this.handle);
      long l2 = OS.SelectObject(l1, paramImage.handle);
      if (paramImage.alpha != -1)
      {
        ((BLENDFUNCTION)localObject).SourceConstantAlpha = ((byte)paramImage.alpha);
        OS.AlphaBlend(this.handle, paramInt5, paramInt6, paramInt7, paramInt8, l1, paramInt1, paramInt2, paramInt3, paramInt4, (BLENDFUNCTION)localObject);
      }
      else
      {
        l3 = Image.createDIB(paramInt3, paramInt4, 32);
        if (l3 == 0L) {
          SWT.error(2);
        }
        l4 = OS.CreateCompatibleDC(this.handle);
        l5 = OS.SelectObject(l4, l3);
        BITMAP localBITMAP1 = new BITMAP();
        OS.GetObject(l3, BITMAP.sizeof, localBITMAP1);
        OS.BitBlt(l4, 0, 0, paramInt3, paramInt4, l1, paramInt1, paramInt2, 13369376);
        byte[] arrayOfByte1 = new byte[localBITMAP1.bmWidthBytes * localBITMAP1.bmHeight];
        OS.MoveMemory(arrayOfByte1, localBITMAP1.bmBits, arrayOfByte1.length);
        int i3 = paramInt9 - paramInt3;
        int i4 = paramInt2 * paramInt9 + paramInt1;
        int i5 = 0;
        byte[] arrayOfByte2 = paramImage.alphaData;
        for (int i7 = 0; i7 < paramInt4; i7++)
        {
          for (int i8 = 0; i8 < paramInt3; i8++)
          {
            i9 = arrayOfByte2[(i4++)] & 0xFF;
            i10 = (arrayOfByte1[(i5 + 0)] & 0xFF) * i9 + 128;
            i10 = i10 + (i10 >> 8) >> 8;
            i11 = (arrayOfByte1[(i5 + 1)] & 0xFF) * i9 + 128;
            i11 = i11 + (i11 >> 8) >> 8;
            i13 = (arrayOfByte1[(i5 + 2)] & 0xFF) * i9 + 128;
            i13 = i13 + (i13 >> 8) >> 8;
            arrayOfByte1[(i5 + 0)] = ((byte)i10);
            arrayOfByte1[(i5 + 1)] = ((byte)i11);
            arrayOfByte1[(i5 + 2)] = ((byte)i13);
            arrayOfByte1[(i5 + 3)] = ((byte)i9);
            i5 += 4;
          }
          i4 += i3;
        }
        OS.MoveMemory(localBITMAP1.bmBits, arrayOfByte1, arrayOfByte1.length);
        ((BLENDFUNCTION)localObject).SourceConstantAlpha = -1;
        ((BLENDFUNCTION)localObject).AlphaFormat = 1;
        OS.AlphaBlend(this.handle, paramInt5, paramInt6, paramInt7, paramInt8, l4, 0, 0, paramInt3, paramInt4, (BLENDFUNCTION)localObject);
        OS.SelectObject(l4, l5);
        OS.DeleteDC(l4);
        OS.DeleteObject(l3);
      }
      OS.SelectObject(l1, l2);
      OS.DeleteDC(l1);
      return;
    }
    Object localObject = getClipping();
    localObject = ((Rectangle)localObject).intersection(new Rectangle(paramInt5, paramInt6, paramInt7, paramInt8));
    if (((Rectangle)localObject).isEmpty()) {
      return;
    }
    int m = paramInt1 + (((Rectangle)localObject).x - paramInt5) * paramInt3 / paramInt7;
    int n = paramInt1 + (((Rectangle)localObject).x + ((Rectangle)localObject).width - paramInt5) * paramInt3 / paramInt7;
    int i1 = paramInt2 + (((Rectangle)localObject).y - paramInt6) * paramInt4 / paramInt8;
    int i2 = paramInt2 + (((Rectangle)localObject).y + ((Rectangle)localObject).height - paramInt6) * paramInt4 / paramInt8;
    paramInt5 = ((Rectangle)localObject).x;
    paramInt6 = ((Rectangle)localObject).y;
    paramInt7 = ((Rectangle)localObject).width;
    paramInt8 = ((Rectangle)localObject).height;
    paramInt1 = m;
    paramInt2 = i1;
    paramInt3 = Math.max(1, n - m);
    paramInt4 = Math.max(1, i2 - i1);
    long l3 = OS.CreateCompatibleDC(this.handle);
    long l4 = OS.SelectObject(l3, paramImage.handle);
    long l5 = OS.CreateCompatibleDC(this.handle);
    long l6 = Image.createDIB(Math.max(paramInt3, paramInt7), Math.max(paramInt4, paramInt8), 32);
    if (l6 == 0L) {
      SWT.error(2);
    }
    long l7 = OS.SelectObject(l5, l6);
    BITMAP localBITMAP2 = new BITMAP();
    OS.GetObject(l6, BITMAP.sizeof, localBITMAP2);
    int i6 = localBITMAP2.bmWidthBytes * localBITMAP2.bmHeight;
    OS.BitBlt(l5, 0, 0, paramInt7, paramInt8, this.handle, paramInt5, paramInt6, 13369376);
    byte[] arrayOfByte3 = new byte[i6];
    OS.MoveMemory(arrayOfByte3, localBITMAP2.bmBits, i6);
    OS.BitBlt(l5, 0, 0, paramInt3, paramInt4, l3, paramInt1, paramInt2, 13369376);
    byte[] arrayOfByte4 = new byte[i6];
    OS.MoveMemory(arrayOfByte4, localBITMAP2.bmBits, i6);
    int i9 = paramImage.alpha;
    int i10 = paramImage.alpha == -1 ? 1 : 0;
    int i16;
    if (i10 != 0)
    {
      i11 = paramInt9 - paramInt3;
      i13 = localBITMAP2.bmWidthBytes - paramInt3 * 4;
      int i14 = paramInt2 * paramInt9 + paramInt1;
      i16 = 3;
      byte[] arrayOfByte5 = paramImage.alphaData;
      for (int i17 = 0; i17 < paramInt4; i17++)
      {
        for (int i18 = 0; i18 < paramInt3; i18++)
        {
          arrayOfByte4[i16] = arrayOfByte5[(i14++)];
          i16 += 4;
        }
        i14 += i11;
        i16 += i13;
      }
    }
    OS.MoveMemory(localBITMAP2.bmBits, arrayOfByte4, i6);
    if (((OS.IsWinCE) && ((paramInt7 > paramInt3) || (paramInt8 > paramInt4))) || ((!OS.IsWinNT) && (!OS.IsWinCE)) || (j != 0))
    {
      long l8 = OS.CreateCompatibleDC(this.handle);
      long l9 = Image.createDIB(paramInt7, paramInt8, 32);
      if (l9 == 0L) {
        SWT.error(2);
      }
      long l10 = OS.SelectObject(l8, l9);
      if ((!paramBoolean) && ((paramInt3 != paramInt7) || (paramInt4 != paramInt8)))
      {
        if (!OS.IsWinCE) {
          OS.SetStretchBltMode(l5, 3);
        }
        OS.StretchBlt(l8, 0, 0, paramInt7, paramInt8, l5, 0, 0, paramInt3, paramInt4, 13369376);
      }
      else
      {
        OS.BitBlt(l8, 0, 0, paramInt7, paramInt8, l5, 0, 0, 13369376);
      }
      OS.BitBlt(l5, 0, 0, paramInt7, paramInt8, l8, 0, 0, 13369376);
      OS.SelectObject(l8, l10);
      OS.DeleteObject(l9);
      OS.DeleteDC(l8);
    }
    else if ((!paramBoolean) && ((paramInt3 != paramInt7) || (paramInt4 != paramInt8)))
    {
      if (!OS.IsWinCE) {
        OS.SetStretchBltMode(l5, 3);
      }
      OS.StretchBlt(l5, 0, 0, paramInt7, paramInt8, l5, 0, 0, paramInt3, paramInt4, 13369376);
    }
    else
    {
      OS.BitBlt(l5, 0, 0, paramInt7, paramInt8, l5, 0, 0, 13369376);
    }
    OS.MoveMemory(arrayOfByte4, localBITMAP2.bmBits, i6);
    int i12 = localBITMAP2.bmWidthBytes - paramInt7 * 4;
    int i13 = 0;
    for (int i15 = 0; i15 < paramInt8; i15++)
    {
      for (i16 = 0; i16 < paramInt7; i16++)
      {
        if (i10 != 0) {
          i9 = arrayOfByte4[(i13 + 3)] & 0xFF;
        }
        int tmp1482_1480 = i13;
        byte[] tmp1482_1478 = arrayOfByte3;
        tmp1482_1478[tmp1482_1480] = ((byte)(tmp1482_1478[tmp1482_1480] + ((arrayOfByte4[i13] & 0xFF) - (arrayOfByte3[i13] & 0xFF)) * i9 / 255));
        int tmp1519_1518 = (i13 + 1);
        byte[] tmp1519_1513 = arrayOfByte3;
        tmp1519_1513[tmp1519_1518] = ((byte)(tmp1519_1513[tmp1519_1518] + ((arrayOfByte4[(i13 + 1)] & 0xFF) - (arrayOfByte3[(i13 + 1)] & 0xFF)) * i9 / 255));
        int tmp1560_1559 = (i13 + 2);
        byte[] tmp1560_1554 = arrayOfByte3;
        tmp1560_1554[tmp1560_1559] = ((byte)(tmp1560_1554[tmp1560_1559] + ((arrayOfByte4[(i13 + 2)] & 0xFF) - (arrayOfByte3[(i13 + 2)] & 0xFF)) * i9 / 255));
        i13 += 4;
      }
      i13 += i12;
    }
    OS.MoveMemory(localBITMAP2.bmBits, arrayOfByte3, i6);
    OS.BitBlt(this.handle, paramInt5, paramInt6, paramInt7, paramInt8, l5, 0, 0, 13369376);
    OS.SelectObject(l5, l7);
    OS.DeleteDC(l5);
    OS.DeleteObject(l6);
    OS.SelectObject(l3, l4);
    OS.DeleteDC(l3);
  }
  
  void drawBitmapTransparentByClipping(long paramLong1, long paramLong2, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, boolean paramBoolean, int paramInt9, int paramInt10)
  {
    long l1 = OS.CreateRectRgn(0, 0, 0, 0);
    for (int i = 0; i < paramInt10; i++) {
      for (int j = 0; j < paramInt9; j++) {
        if (OS.GetPixel(paramLong2, j, i) == 0)
        {
          long l3 = OS.CreateRectRgn(j, i, j + 1, i + 1);
          OS.CombineRgn(l1, l1, l3, 2);
          OS.DeleteObject(l3);
        }
      }
    }
    if ((paramInt7 != paramInt3) || (paramInt8 != paramInt4))
    {
      i = OS.GetRegionData(l1, 0, null);
      int[] arrayOfInt = new int[i / 4];
      OS.GetRegionData(l1, i, arrayOfInt);
      float[] arrayOfFloat = { paramInt7 / paramInt3, 0.0F, 0.0F, paramInt8 / paramInt4, 0.0F, 0.0F };
      long l4 = OS.ExtCreateRegion(arrayOfFloat, i, arrayOfInt);
      OS.DeleteObject(l1);
      l1 = l4;
    }
    OS.OffsetRgn(l1, paramInt5, paramInt6);
    long l2 = OS.CreateRectRgn(0, 0, 0, 0);
    int k = OS.GetClipRgn(this.handle, l2);
    if (k == 1) {
      OS.CombineRgn(l1, l1, l2, 1);
    }
    OS.SelectClipRgn(this.handle, l1);
    int m = 0;
    if (!OS.IsWinCE)
    {
      m = OS.GetROP2(this.handle);
    }
    else
    {
      m = OS.SetROP2(this.handle, 13);
      OS.SetROP2(this.handle, m);
    }
    int n = m == 7 ? 6684742 : 13369376;
    if ((!paramBoolean) && ((paramInt3 != paramInt7) || (paramInt4 != paramInt8)))
    {
      int i1 = 0;
      if (!OS.IsWinCE) {
        i1 = OS.SetStretchBltMode(this.handle, 3);
      }
      OS.StretchBlt(this.handle, paramInt5, paramInt6, paramInt7, paramInt8, paramLong1, paramInt1, paramInt2, paramInt3, paramInt4, n);
      if (!OS.IsWinCE) {
        OS.SetStretchBltMode(this.handle, i1);
      }
    }
    else
    {
      OS.BitBlt(this.handle, paramInt5, paramInt6, paramInt7, paramInt8, paramLong1, paramInt1, paramInt2, n);
    }
    OS.SelectClipRgn(this.handle, k == 1 ? l2 : 0L);
    OS.DeleteObject(l2);
    OS.DeleteObject(l1);
  }
  
  void drawBitmapMask(Image paramImage, long paramLong1, long paramLong2, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, boolean paramBoolean1, int paramInt9, int paramInt10, boolean paramBoolean2)
  {
    int i = paramInt2;
    if (paramLong1 == 0L)
    {
      paramLong1 = paramLong2;
      i += paramInt10;
    }
    long l1 = OS.CreateCompatibleDC(this.handle);
    long l2 = OS.SelectObject(l1, paramLong1);
    long l3 = this.handle;
    int j = paramInt5;
    int k = paramInt6;
    long l4 = 0L;
    long l5 = 0L;
    long l6 = 0L;
    int m = 0;
    int n = 0;
    if (paramBoolean2)
    {
      l4 = OS.CreateCompatibleDC(this.handle);
      l5 = OS.CreateCompatibleBitmap(this.handle, paramInt7, paramInt8);
      l6 = OS.SelectObject(l4, l5);
      OS.BitBlt(l4, 0, 0, paramInt7, paramInt8, this.handle, paramInt5, paramInt6, 13369376);
      l3 = l4;
      j = k = 0;
    }
    else
    {
      m = OS.SetBkColor(this.handle, 16777215);
      n = OS.SetTextColor(this.handle, 0);
    }
    if ((!paramBoolean1) && ((paramInt3 != paramInt7) || (paramInt4 != paramInt8)))
    {
      int i1 = 0;
      if (!OS.IsWinCE) {
        i1 = OS.SetStretchBltMode(this.handle, 3);
      }
      OS.StretchBlt(l3, j, k, paramInt7, paramInt8, l1, paramInt1, i, paramInt3, paramInt4, 6684742);
      OS.SelectObject(l1, paramLong2);
      OS.StretchBlt(l3, j, k, paramInt7, paramInt8, l1, paramInt1, paramInt2, paramInt3, paramInt4, 8913094);
      OS.SelectObject(l1, paramLong1);
      OS.StretchBlt(l3, j, k, paramInt7, paramInt8, l1, paramInt1, i, paramInt3, paramInt4, 6684742);
      if (!OS.IsWinCE) {
        OS.SetStretchBltMode(this.handle, i1);
      }
    }
    else
    {
      OS.BitBlt(l3, j, k, paramInt7, paramInt8, l1, paramInt1, i, 6684742);
      OS.SetTextColor(l3, 0);
      OS.SelectObject(l1, paramLong2);
      OS.BitBlt(l3, j, k, paramInt7, paramInt8, l1, paramInt1, paramInt2, 8913094);
      OS.SelectObject(l1, paramLong1);
      OS.BitBlt(l3, j, k, paramInt7, paramInt8, l1, paramInt1, i, 6684742);
    }
    if (paramBoolean2)
    {
      OS.BitBlt(this.handle, paramInt5, paramInt6, paramInt7, paramInt8, l4, 0, 0, 13369376);
      OS.SelectObject(l4, l6);
      OS.DeleteDC(l4);
      OS.DeleteObject(l5);
    }
    else
    {
      OS.SetBkColor(this.handle, m);
      OS.SetTextColor(this.handle, n);
    }
    OS.SelectObject(l1, l2);
    OS.DeleteDC(l1);
  }
  
  void drawBitmapTransparent(Image paramImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, boolean paramBoolean, BITMAP paramBITMAP, int paramInt9, int paramInt10)
  {
    int i = paramBITMAP.bmBits != 0L ? 1 : 0;
    long l1 = paramImage.handle;
    long l2 = OS.CreateCompatibleDC(this.handle);
    long l3 = OS.SelectObject(l2, l1);
    Object localObject1 = null;
    int j = paramImage.transparentColor;
    int k;
    if (j == -1)
    {
      k = 0;
      int m = 0;
      int n = 0;
      int i1 = 0;
      int i2;
      if (paramBITMAP.bmBitsPixel <= 8)
      {
        Object localObject2;
        if (i != 0)
        {
          int i4;
          int i5;
          if (OS.IsWinCE)
          {
            byte[] arrayOfByte1 = new byte[1];
            OS.MoveMemory(arrayOfByte1, paramBITMAP.bmBits, 1);
            int i3 = arrayOfByte1[0];
            i4 = 255 << 8 - paramBITMAP.bmBitsPixel & 0xFF;
            arrayOfByte1[0] = ((byte)(paramImage.transparentPixel << 8 - paramBITMAP.bmBitsPixel | arrayOfByte1[0] & (i4 ^ 0xFFFFFFFF)));
            OS.MoveMemory(paramBITMAP.bmBits, arrayOfByte1, 1);
            i5 = OS.GetPixel(l2, 0, 0);
            arrayOfByte1[0] = i3;
            OS.MoveMemory(paramBITMAP.bmBits, arrayOfByte1, 1);
            k = (i5 & 0xFF0000) >> 16;
            m = (i5 & 0xFF00) >> 8;
            n = i5 & 0xFF;
          }
          else
          {
            i2 = 1 << paramBITMAP.bmBitsPixel;
            localObject2 = new byte[i2 * 4];
            OS.GetDIBColorTable(l2, 0, i2, (byte[])localObject2);
            i4 = paramImage.transparentPixel * 4;
            for (i5 = 0; i5 < localObject2.length; i5 += 4) {
              if ((i5 != i4) && (localObject2[i4] == localObject2[i5]) && (localObject2[(i4 + 1)] == localObject2[(i5 + 1)]) && (localObject2[(i4 + 2)] == localObject2[(i5 + 2)]))
              {
                i1 = 1;
                break;
              }
            }
            if (i1 != 0)
            {
              byte[] arrayOfByte3 = new byte[localObject2.length];
              n = m = k = 'ÿ';
              arrayOfByte3[i4] = ((byte)k);
              arrayOfByte3[(i4 + 1)] = ((byte)m);
              arrayOfByte3[(i4 + 2)] = ((byte)n);
              OS.SetDIBColorTable(l2, 0, i2, arrayOfByte3);
              localObject1 = localObject2;
            }
            else
            {
              k = localObject2[i4] & 0xFF;
              m = localObject2[(i4 + 1)] & 0xFF;
              n = localObject2[(i4 + 2)] & 0xFF;
            }
          }
        }
        else
        {
          i2 = 1 << paramBITMAP.bmBitsPixel;
          localObject2 = new BITMAPINFOHEADER();
          ((BITMAPINFOHEADER)localObject2).biSize = BITMAPINFOHEADER.sizeof;
          ((BITMAPINFOHEADER)localObject2).biPlanes = paramBITMAP.bmPlanes;
          ((BITMAPINFOHEADER)localObject2).biBitCount = paramBITMAP.bmBitsPixel;
          byte[] arrayOfByte2 = new byte[BITMAPINFOHEADER.sizeof + i2 * 4];
          OS.MoveMemory(arrayOfByte2, (BITMAPINFOHEADER)localObject2, BITMAPINFOHEADER.sizeof);
          if (OS.IsWinCE) {
            SWT.error(20);
          }
          OS.GetDIBits(l2, paramImage.handle, 0, 0, null, arrayOfByte2, 0);
          int i6 = BITMAPINFOHEADER.sizeof + 4 * paramImage.transparentPixel;
          n = arrayOfByte2[(i6 + 2)] & 0xFF;
          m = arrayOfByte2[(i6 + 1)] & 0xFF;
          k = arrayOfByte2[i6] & 0xFF;
        }
      }
      else
      {
        i2 = paramImage.transparentPixel;
        switch (paramBITMAP.bmBitsPixel)
        {
        case 16: 
          k = (i2 & 0x1F) << 3;
          m = (i2 & 0x3E0) >> 2;
          n = (i2 & 0x7C00) >> 7;
          break;
        case 24: 
          k = (i2 & 0xFF0000) >> 16;
          m = (i2 & 0xFF00) >> 8;
          n = i2 & 0xFF;
          break;
        case 32: 
          k = (i2 & 0xFF000000) >>> 24;
          m = (i2 & 0xFF0000) >> 16;
          n = (i2 & 0xFF00) >> 8;
        }
      }
      j = k << 16 | m << 8 | n;
      if (i1 == 0) {
        paramImage.transparentColor = j;
      }
    }
    if (OS.IsWinCE)
    {
      OS.TransparentImage(this.handle, paramInt5, paramInt6, paramInt7, paramInt8, l2, paramInt1, paramInt2, paramInt3, paramInt4, j);
    }
    else if ((localObject1 == null) && (OS.IsWinNT) && (OS.WIN32_VERSION >= OS.VERSION(4, 10)))
    {
      k = OS.SetStretchBltMode(this.handle, 3);
      OS.TransparentBlt(this.handle, paramInt5, paramInt6, paramInt7, paramInt8, l2, paramInt1, paramInt2, paramInt3, paramInt4, j);
      OS.SetStretchBltMode(this.handle, k);
    }
    else
    {
      long l4 = OS.CreateCompatibleDC(this.handle);
      long l5 = OS.CreateBitmap(paramInt9, paramInt10, 1, 1, null);
      long l6 = OS.SelectObject(l4, l5);
      OS.SetBkColor(l2, j);
      OS.BitBlt(l4, 0, 0, paramInt9, paramInt10, l2, 0, 0, 13369376);
      if (localObject1 != null) {
        OS.SetDIBColorTable(l2, 0, 1 << paramBITMAP.bmBitsPixel, (byte[])localObject1);
      }
      if (OS.GetDeviceCaps(this.handle, 2) == 2)
      {
        drawBitmapTransparentByClipping(l2, l4, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8, paramBoolean, paramInt9, paramInt10);
      }
      else
      {
        long l7 = OS.CreateCompatibleDC(this.handle);
        long l8 = OS.CreateCompatibleBitmap(this.handle, paramInt7, paramInt8);
        long l9 = OS.SelectObject(l7, l8);
        OS.BitBlt(l7, 0, 0, paramInt7, paramInt8, this.handle, paramInt5, paramInt6, 13369376);
        if ((!paramBoolean) && ((paramInt3 != paramInt7) || (paramInt4 != paramInt8)))
        {
          if (!OS.IsWinCE) {
            OS.SetStretchBltMode(l7, 3);
          }
          OS.StretchBlt(l7, 0, 0, paramInt7, paramInt8, l2, paramInt1, paramInt2, paramInt3, paramInt4, 6684742);
          OS.StretchBlt(l7, 0, 0, paramInt7, paramInt8, l4, paramInt1, paramInt2, paramInt3, paramInt4, 8913094);
          OS.StretchBlt(l7, 0, 0, paramInt7, paramInt8, l2, paramInt1, paramInt2, paramInt3, paramInt4, 6684742);
        }
        else
        {
          OS.BitBlt(l7, 0, 0, paramInt7, paramInt8, l2, paramInt1, paramInt2, 6684742);
          OS.BitBlt(l7, 0, 0, paramInt7, paramInt8, l4, paramInt1, paramInt2, 8913094);
          OS.BitBlt(l7, 0, 0, paramInt7, paramInt8, l2, paramInt1, paramInt2, 6684742);
        }
        OS.BitBlt(this.handle, paramInt5, paramInt6, paramInt7, paramInt8, l7, 0, 0, 13369376);
        OS.SelectObject(l7, l9);
        OS.DeleteDC(l7);
        OS.DeleteObject(l8);
      }
      OS.SelectObject(l4, l6);
      OS.DeleteDC(l4);
      OS.DeleteObject(l5);
    }
    OS.SelectObject(l2, l3);
    if (l1 != paramImage.handle) {
      OS.DeleteObject(l1);
    }
    OS.DeleteDC(l2);
  }
  
  void drawBitmap(Image paramImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, boolean paramBoolean, BITMAP paramBITMAP, int paramInt9, int paramInt10)
  {
    long l1 = OS.CreateCompatibleDC(this.handle);
    long l2 = OS.SelectObject(l1, paramImage.handle);
    int i = 0;
    if (!OS.IsWinCE)
    {
      i = OS.GetROP2(this.handle);
    }
    else
    {
      i = OS.SetROP2(this.handle, 13);
      OS.SetROP2(this.handle, i);
    }
    int j = i == 7 ? 6684742 : 13369376;
    if ((!paramBoolean) && ((paramInt3 != paramInt7) || (paramInt4 != paramInt8)))
    {
      int k = 0;
      if (!OS.IsWinCE) {
        k = OS.SetStretchBltMode(this.handle, 3);
      }
      OS.StretchBlt(this.handle, paramInt5, paramInt6, paramInt7, paramInt8, l1, paramInt1, paramInt2, paramInt3, paramInt4, j);
      if (!OS.IsWinCE) {
        OS.SetStretchBltMode(this.handle, k);
      }
    }
    else
    {
      OS.BitBlt(this.handle, paramInt5, paramInt6, paramInt7, paramInt8, l1, paramInt1, paramInt2, j);
    }
    OS.SelectObject(l1, l2);
    OS.DeleteDC(l1);
  }
  
  public void drawLine(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    if (this.handle == 0L) {
      SWT.error(44);
    }
    checkGC(22777);
    long l = this.data.gdipGraphics;
    if (l != 0L)
    {
      Gdip.Graphics_TranslateTransform(l, this.data.gdipXOffset, this.data.gdipYOffset, 0);
      Gdip.Graphics_DrawLine(l, this.data.gdipPen, paramInt1, paramInt2, paramInt3, paramInt4);
      Gdip.Graphics_TranslateTransform(l, -this.data.gdipXOffset, -this.data.gdipYOffset, 0);
      return;
    }
    if (((this.data.style & 0x8000000) != 0) && (this.data.lineWidth != 0.0F) && (this.data.lineWidth % 2.0F == 0.0F))
    {
      paramInt1--;
      paramInt3--;
    }
    if (OS.IsWinCE)
    {
      int[] arrayOfInt = { paramInt1, paramInt2, paramInt3, paramInt4 };
      OS.Polyline(this.handle, arrayOfInt, arrayOfInt.length / 2);
    }
    else
    {
      OS.MoveToEx(this.handle, paramInt1, paramInt2, 0L);
      OS.LineTo(this.handle, paramInt3, paramInt4);
    }
    if (this.data.lineWidth <= 1.0F) {
      OS.SetPixel(this.handle, paramInt3, paramInt4, this.data.foreground);
    }
  }
  
  public void drawOval(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    if (this.handle == 0L) {
      SWT.error(44);
    }
    checkGC(22777);
    long l = this.data.gdipGraphics;
    if (l != 0L)
    {
      Gdip.Graphics_TranslateTransform(l, this.data.gdipXOffset, this.data.gdipYOffset, 0);
      Gdip.Graphics_DrawEllipse(l, this.data.gdipPen, paramInt1, paramInt2, paramInt3, paramInt4);
      Gdip.Graphics_TranslateTransform(l, -this.data.gdipXOffset, -this.data.gdipYOffset, 0);
      return;
    }
    if (((this.data.style & 0x8000000) != 0) && (this.data.lineWidth != 0.0F) && (this.data.lineWidth % 2.0F == 0.0F)) {
      paramInt1--;
    }
    OS.Ellipse(this.handle, paramInt1, paramInt2, paramInt1 + paramInt3 + 1, paramInt2 + paramInt4 + 1);
  }
  
  public void drawPath(Path paramPath)
  {
    if (this.handle == 0L) {
      SWT.error(44);
    }
    if (paramPath == null) {
      SWT.error(4);
    }
    if (paramPath.handle == 0L) {
      SWT.error(5);
    }
    initGdip();
    checkGC(22777);
    long l = this.data.gdipGraphics;
    Gdip.Graphics_TranslateTransform(l, this.data.gdipXOffset, this.data.gdipYOffset, 0);
    Gdip.Graphics_DrawPath(l, this.data.gdipPen, paramPath.handle);
    Gdip.Graphics_TranslateTransform(l, -this.data.gdipXOffset, -this.data.gdipYOffset, 0);
  }
  
  public void drawPoint(int paramInt1, int paramInt2)
  {
    if (this.handle == 0L) {
      SWT.error(44);
    }
    if (this.data.gdipGraphics != 0L)
    {
      checkGC(22777);
      Gdip.Graphics_FillRectangle(this.data.gdipGraphics, getFgBrush(), paramInt1, paramInt2, 1, 1);
      return;
    }
    OS.SetPixel(this.handle, paramInt1, paramInt2, this.data.foreground);
  }
  
  public void drawPolygon(int[] paramArrayOfInt)
  {
    if (this.handle == 0L) {
      SWT.error(44);
    }
    if (paramArrayOfInt == null) {
      SWT.error(4);
    }
    checkGC(22777);
    long l = this.data.gdipGraphics;
    if (l != 0L)
    {
      Gdip.Graphics_TranslateTransform(l, this.data.gdipXOffset, this.data.gdipYOffset, 0);
      Gdip.Graphics_DrawPolygon(l, this.data.gdipPen, paramArrayOfInt, paramArrayOfInt.length / 2);
      Gdip.Graphics_TranslateTransform(l, -this.data.gdipXOffset, -this.data.gdipYOffset, 0);
      return;
    }
    int i;
    if (((this.data.style & 0x8000000) != 0) && (this.data.lineWidth != 0.0F) && (this.data.lineWidth % 2.0F == 0.0F)) {
      for (i = 0; i < paramArrayOfInt.length; i += 2) {
        paramArrayOfInt[i] -= 1;
      }
    }
    OS.Polygon(this.handle, paramArrayOfInt, paramArrayOfInt.length / 2);
    if (((this.data.style & 0x8000000) != 0) && (this.data.lineWidth != 0.0F) && (this.data.lineWidth % 2.0F == 0.0F)) {
      for (i = 0; i < paramArrayOfInt.length; i += 2) {
        paramArrayOfInt[i] += 1;
      }
    }
  }
  
  public void drawPolyline(int[] paramArrayOfInt)
  {
    if (this.handle == 0L) {
      SWT.error(44);
    }
    if (paramArrayOfInt == null) {
      SWT.error(4);
    }
    checkGC(22777);
    long l = this.data.gdipGraphics;
    if (l != 0L)
    {
      Gdip.Graphics_TranslateTransform(l, this.data.gdipXOffset, this.data.gdipYOffset, 0);
      Gdip.Graphics_DrawLines(l, this.data.gdipPen, paramArrayOfInt, paramArrayOfInt.length / 2);
      Gdip.Graphics_TranslateTransform(l, -this.data.gdipXOffset, -this.data.gdipYOffset, 0);
      return;
    }
    if (((this.data.style & 0x8000000) != 0) && (this.data.lineWidth != 0.0F) && (this.data.lineWidth % 2.0F == 0.0F)) {
      for (i = 0; i < paramArrayOfInt.length; i += 2) {
        paramArrayOfInt[i] -= 1;
      }
    }
    OS.Polyline(this.handle, paramArrayOfInt, paramArrayOfInt.length / 2);
    int i = paramArrayOfInt.length;
    if ((i >= 2) && (this.data.lineWidth <= 1.0F)) {
      OS.SetPixel(this.handle, paramArrayOfInt[(i - 2)], paramArrayOfInt[(i - 1)], this.data.foreground);
    }
    if (((this.data.style & 0x8000000) != 0) && (this.data.lineWidth != 0.0F) && (this.data.lineWidth % 2.0F == 0.0F)) {
      for (int j = 0; j < paramArrayOfInt.length; j += 2) {
        paramArrayOfInt[j] += 1;
      }
    }
  }
  
  public void drawRectangle(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    if (this.handle == 0L) {
      SWT.error(44);
    }
    checkGC(22777);
    long l = this.data.gdipGraphics;
    if (l != 0L)
    {
      if (paramInt3 < 0)
      {
        paramInt1 += paramInt3;
        paramInt3 = -paramInt3;
      }
      if (paramInt4 < 0)
      {
        paramInt2 += paramInt4;
        paramInt4 = -paramInt4;
      }
      Gdip.Graphics_TranslateTransform(l, this.data.gdipXOffset, this.data.gdipYOffset, 0);
      Gdip.Graphics_DrawRectangle(l, this.data.gdipPen, paramInt1, paramInt2, paramInt3, paramInt4);
      Gdip.Graphics_TranslateTransform(l, -this.data.gdipXOffset, -this.data.gdipYOffset, 0);
      return;
    }
    if ((this.data.style & 0x8000000) != 0) {
      if (this.data.lineWidth > 1.0F)
      {
        if (this.data.lineWidth % 2.0F == 1.0F) {
          paramInt1++;
        }
      }
      else if ((this.data.hPen != 0L) && (OS.GetObject(this.data.hPen, 0, 0L) != LOGPEN.sizeof)) {
        paramInt1++;
      }
    }
    OS.Rectangle(this.handle, paramInt1, paramInt2, paramInt1 + paramInt3 + 1, paramInt2 + paramInt4 + 1);
  }
  
  public void drawRectangle(Rectangle paramRectangle)
  {
    if (paramRectangle == null) {
      SWT.error(4);
    }
    drawRectangle(paramRectangle.x, paramRectangle.y, paramRectangle.width, paramRectangle.height);
  }
  
  public void drawRoundRectangle(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6)
  {
    if (this.handle == 0L) {
      SWT.error(44);
    }
    checkGC(22777);
    if (this.data.gdipGraphics != 0L)
    {
      drawRoundRectangleGdip(this.data.gdipGraphics, this.data.gdipPen, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6);
      return;
    }
    if (((this.data.style & 0x8000000) != 0) && (this.data.lineWidth != 0.0F) && (this.data.lineWidth % 2.0F == 0.0F)) {
      paramInt1--;
    }
    if (OS.IsWinCE)
    {
      if ((paramInt3 == 0) || (paramInt4 == 0)) {
        return;
      }
      if ((paramInt5 == 0) || (paramInt6 == 0))
      {
        drawRectangle(paramInt1, paramInt2, paramInt3, paramInt4);
        return;
      }
      if (paramInt3 < 0)
      {
        paramInt1 += paramInt3;
        paramInt3 = -paramInt3;
      }
      if (paramInt4 < 0)
      {
        paramInt2 += paramInt4;
        paramInt4 = -paramInt4;
      }
      if (paramInt5 < 0) {
        paramInt5 = -paramInt5;
      }
      if (paramInt6 < 0) {
        paramInt6 = -paramInt6;
      }
      if (paramInt5 > paramInt3) {
        paramInt5 = paramInt3;
      }
      if (paramInt6 > paramInt4) {
        paramInt6 = paramInt4;
      }
      if (paramInt5 < paramInt3)
      {
        drawLine(paramInt1 + paramInt5 / 2, paramInt2, paramInt1 + paramInt3 - paramInt5 / 2, paramInt2);
        drawLine(paramInt1 + paramInt5 / 2, paramInt2 + paramInt4, paramInt1 + paramInt3 - paramInt5 / 2, paramInt2 + paramInt4);
      }
      if (paramInt6 < paramInt4)
      {
        drawLine(paramInt1, paramInt2 + paramInt6 / 2, paramInt1, paramInt2 + paramInt4 - paramInt6 / 2);
        drawLine(paramInt1 + paramInt3, paramInt2 + paramInt6 / 2, paramInt1 + paramInt3, paramInt2 + paramInt4 - paramInt6 / 2);
      }
      if ((paramInt5 != 0) && (paramInt6 != 0))
      {
        drawArc(paramInt1, paramInt2, paramInt5, paramInt6, 90, 90);
        drawArc(paramInt1 + paramInt3 - paramInt5, paramInt2, paramInt5, paramInt6, 0, 90);
        drawArc(paramInt1 + paramInt3 - paramInt5, paramInt2 + paramInt4 - paramInt6, paramInt5, paramInt6, 0, -90);
        drawArc(paramInt1, paramInt2 + paramInt4 - paramInt6, paramInt5, paramInt6, 180, 90);
      }
    }
    else
    {
      OS.RoundRect(this.handle, paramInt1, paramInt2, paramInt1 + paramInt3 + 1, paramInt2 + paramInt4 + 1, paramInt5, paramInt6);
    }
  }
  
  void drawRoundRectangleGdip(long paramLong1, long paramLong2, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6)
  {
    int i = paramInt1;
    int j = paramInt2;
    int k = paramInt3;
    int m = paramInt4;
    int n = paramInt5;
    int i1 = paramInt6;
    if (k < 0)
    {
      k = 0 - k;
      i -= k;
    }
    if (m < 0)
    {
      m = 0 - m;
      j -= m;
    }
    if (n < 0) {
      n = 0 - n;
    }
    if (i1 < 0) {
      i1 = 0 - i1;
    }
    Gdip.Graphics_TranslateTransform(paramLong1, this.data.gdipXOffset, this.data.gdipYOffset, 0);
    if ((n == 0) || (i1 == 0))
    {
      Gdip.Graphics_DrawRectangle(paramLong1, this.data.gdipPen, paramInt1, paramInt2, paramInt3, paramInt4);
    }
    else
    {
      long l = Gdip.GraphicsPath_new(0);
      if (l == 0L) {
        SWT.error(2);
      }
      if (k > n)
      {
        if (m > i1)
        {
          Gdip.GraphicsPath_AddArc(l, i + k - n, j, n, i1, 0.0F, -90.0F);
          Gdip.GraphicsPath_AddArc(l, i, j, n, i1, -90.0F, -90.0F);
          Gdip.GraphicsPath_AddArc(l, i, j + m - i1, n, i1, -180.0F, -90.0F);
          Gdip.GraphicsPath_AddArc(l, i + k - n, j + m - i1, n, i1, -270.0F, -90.0F);
        }
        else
        {
          Gdip.GraphicsPath_AddArc(l, i + k - n, j, n, m, -270.0F, -180.0F);
          Gdip.GraphicsPath_AddArc(l, i, j, n, m, -90.0F, -180.0F);
        }
      }
      else if (m > i1)
      {
        Gdip.GraphicsPath_AddArc(l, i, j, k, i1, 0.0F, -180.0F);
        Gdip.GraphicsPath_AddArc(l, i, j + m - i1, k, i1, -180.0F, -180.0F);
      }
      else
      {
        Gdip.GraphicsPath_AddArc(l, i, j, k, m, 0.0F, 360.0F);
      }
      Gdip.GraphicsPath_CloseFigure(l);
      Gdip.Graphics_DrawPath(paramLong1, paramLong2, l);
      Gdip.GraphicsPath_delete(l);
    }
    Gdip.Graphics_TranslateTransform(paramLong1, -this.data.gdipXOffset, -this.data.gdipYOffset, 0);
  }
  
  public void drawString(String paramString, int paramInt1, int paramInt2)
  {
    drawString(paramString, paramInt1, paramInt2, false);
  }
  
  public void drawString(String paramString, int paramInt1, int paramInt2, boolean paramBoolean)
  {
    if (this.handle == 0L) {
      SWT.error(44);
    }
    if (paramString == null) {
      SWT.error(4);
    }
    int i = paramString.length();
    if (i == 0) {
      return;
    }
    char[] arrayOfChar = new char[i];
    paramString.getChars(0, i, arrayOfChar, 0);
    long l1 = this.data.gdipGraphics;
    if (l1 != 0L)
    {
      checkGC(0x5 | (paramBoolean ? 0 : 2));
      drawText(l1, paramString, paramInt1, paramInt2, paramBoolean ? 1 : 0, null);
      return;
    }
    int j = 0;
    if (OS.IsWinCE)
    {
      j = OS.SetROP2(this.handle, 13);
      OS.SetROP2(this.handle, j);
    }
    else
    {
      j = OS.GetROP2(this.handle);
    }
    checkGC(772);
    int k = OS.SetBkMode(this.handle, paramBoolean ? 1 : 2);
    RECT localRECT = null;
    SIZE localSIZE = null;
    int m = 0;
    if ((this.data.style & 0x8000000) != 0)
    {
      if (!paramBoolean)
      {
        localSIZE = new SIZE();
        OS.GetTextExtentPoint32W(this.handle, arrayOfChar, i, localSIZE);
        localRECT = new RECT();
        localRECT.left = paramInt1;
        localRECT.right = (paramInt1 + localSIZE.cx);
        localRECT.top = paramInt2;
        localRECT.bottom = (paramInt2 + localSIZE.cy);
        m = 4;
      }
      paramInt1--;
    }
    if (j != 7)
    {
      OS.ExtTextOutW(this.handle, paramInt1, paramInt2, m, localRECT, arrayOfChar, i, null);
    }
    else
    {
      int n = OS.GetTextColor(this.handle);
      int i1;
      if (paramBoolean)
      {
        if (localSIZE == null)
        {
          localSIZE = new SIZE();
          OS.GetTextExtentPoint32W(this.handle, arrayOfChar, i, localSIZE);
        }
        i1 = localSIZE.cx;
        int i2 = localSIZE.cy;
        long l2 = OS.CreateCompatibleBitmap(this.handle, i1, i2);
        if (l2 == 0L) {
          SWT.error(2);
        }
        long l3 = OS.CreateCompatibleDC(this.handle);
        long l4 = OS.SelectObject(l3, l2);
        OS.PatBlt(l3, 0, 0, i1, i2, 66);
        OS.SetBkMode(l3, 1);
        OS.SetTextColor(l3, n);
        OS.SelectObject(l3, OS.GetCurrentObject(this.handle, 6));
        OS.ExtTextOutW(l3, 0, 0, 0, null, arrayOfChar, i, null);
        OS.BitBlt(this.handle, paramInt1, paramInt2, i1, i2, l3, 0, 0, 6684742);
        OS.SelectObject(l3, l4);
        OS.DeleteDC(l3);
        OS.DeleteObject(l2);
      }
      else
      {
        i1 = OS.GetBkColor(this.handle);
        OS.SetTextColor(this.handle, n ^ i1);
        OS.ExtTextOutW(this.handle, paramInt1, paramInt2, m, localRECT, arrayOfChar, i, null);
        OS.SetTextColor(this.handle, n);
      }
    }
    OS.SetBkMode(this.handle, k);
  }
  
  public void drawText(String paramString, int paramInt1, int paramInt2)
  {
    drawText(paramString, paramInt1, paramInt2, 6);
  }
  
  public void drawText(String paramString, int paramInt1, int paramInt2, boolean paramBoolean)
  {
    int i = 6;
    if (paramBoolean) {
      i |= 0x1;
    }
    drawText(paramString, paramInt1, paramInt2, i);
  }
  
  public void drawText(String paramString, int paramInt1, int paramInt2, int paramInt3)
  {
    if (this.handle == 0L) {
      SWT.error(44);
    }
    if (paramString == null) {
      SWT.error(4);
    }
    if (paramString.length() == 0) {
      return;
    }
    long l1 = this.data.gdipGraphics;
    if (l1 != 0L)
    {
      checkGC(0x5 | ((paramInt3 & 0x1) != 0 ? 0 : 2));
      drawText(l1, paramString, paramInt1, paramInt2, paramInt3, null);
      return;
    }
    TCHAR localTCHAR = new TCHAR(getCodePage(), paramString, false);
    int i = localTCHAR.length();
    if (i == 0) {
      return;
    }
    RECT localRECT = new RECT();
    int j = OS.IsWin95 ? 32767 : 117440511;
    OS.SetRect(localRECT, paramInt1, paramInt2, j, j);
    int k = 0;
    if ((paramInt3 & 0x2) == 0) {
      k |= 0x20;
    }
    if ((paramInt3 & 0x4) != 0) {
      k |= 0x40;
    }
    if ((paramInt3 & 0x8) == 0) {
      k |= 0x800;
    }
    if (((paramInt3 & 0x8) != 0) && ((this.data.uiState & 0x2) != 0)) {
      k |= 0x100000;
    }
    int m = 0;
    if (OS.IsWinCE)
    {
      m = OS.SetROP2(this.handle, 13);
      OS.SetROP2(this.handle, m);
    }
    else
    {
      m = OS.GetROP2(this.handle);
    }
    checkGC(772);
    int n = OS.SetBkMode(this.handle, (paramInt3 & 0x1) != 0 ? 1 : 2);
    if (m != 7)
    {
      OS.DrawText(this.handle, localTCHAR, i, localRECT, k);
    }
    else
    {
      int i1 = OS.GetTextColor(this.handle);
      int i2;
      if ((paramInt3 & 0x1) != 0)
      {
        OS.DrawText(this.handle, localTCHAR, localTCHAR.length(), localRECT, k | 0x400);
        i2 = localRECT.right - localRECT.left;
        int i3 = localRECT.bottom - localRECT.top;
        long l2 = OS.CreateCompatibleBitmap(this.handle, i2, i3);
        if (l2 == 0L) {
          SWT.error(2);
        }
        long l3 = OS.CreateCompatibleDC(this.handle);
        long l4 = OS.SelectObject(l3, l2);
        OS.PatBlt(l3, 0, 0, i2, i3, 66);
        OS.SetBkMode(l3, 1);
        OS.SetTextColor(l3, i1);
        OS.SelectObject(l3, OS.GetCurrentObject(this.handle, 6));
        OS.SetRect(localRECT, 0, 0, 32767, 32767);
        OS.DrawText(l3, localTCHAR, i, localRECT, k);
        OS.BitBlt(this.handle, paramInt1, paramInt2, i2, i3, l3, 0, 0, 6684742);
        OS.SelectObject(l3, l4);
        OS.DeleteDC(l3);
        OS.DeleteObject(l2);
      }
      else
      {
        i2 = OS.GetBkColor(this.handle);
        OS.SetTextColor(this.handle, i1 ^ i2);
        OS.DrawText(this.handle, localTCHAR, i, localRECT, k);
        OS.SetTextColor(this.handle, i1);
      }
    }
    OS.SetBkMode(this.handle, n);
  }
  
  boolean useGDIP(long paramLong, char[] paramArrayOfChar)
  {
    if ((OS.IsWinCE) || (!OS.IsUnicode)) {
      return false;
    }
    short[] arrayOfShort = new short[paramArrayOfChar.length];
    OS.GetGlyphIndicesW(paramLong, paramArrayOfChar, paramArrayOfChar.length, arrayOfShort, 1);
    for (int i = 0; i < arrayOfShort.length; i++) {
      if (arrayOfShort[i] == -1) {
        switch (paramArrayOfChar[i])
        {
        case '\t': 
        case '\n': 
        case '\r': 
          break;
        case '\013': 
        case '\f': 
        default: 
          return true;
        }
      }
    }
    return false;
  }
  
  void drawText(long paramLong, String paramString, int paramInt1, int paramInt2, int paramInt3, Point paramPoint)
  {
    int i = paramString.length();
    char[] arrayOfChar = new char[i];
    paramString.getChars(0, i, arrayOfChar, 0);
    long l1 = Gdip.Graphics_GetHDC(paramLong);
    long l2 = this.data.hGDIFont;
    if ((l2 == 0L) && (this.data.font != null)) {
      l2 = this.data.font.handle;
    }
    long l3 = 0L;
    if (l2 != 0L) {
      l3 = OS.SelectObject(l1, l2);
    }
    TEXTMETRICA localTEXTMETRICA = OS.IsUnicode ? new TEXTMETRICW() : new TEXTMETRICA();
    OS.GetTextMetrics(l1, localTEXTMETRICA);
    boolean bool = useGDIP(l1, arrayOfChar);
    if (l2 != 0L) {
      OS.SelectObject(l1, l3);
    }
    Gdip.Graphics_ReleaseHDC(paramLong, l1);
    if (bool)
    {
      drawTextGDIP(paramLong, paramString, paramInt1, paramInt2, paramInt3, paramPoint == null, paramPoint);
      return;
    }
    int j = 0;
    int k = 0;
    int m = 0;
    int n = paramInt1;
    int i1 = paramInt2;
    int i2 = 0;
    int i3 = -1;
    if ((paramInt3 & 0xE) != 0)
    {
      int i4 = localTEXTMETRICA.tmAveCharWidth * 8;
      while (j < i)
      {
        int i5 = arrayOfChar[(m++)] = arrayOfChar[(j++)];
        int i6;
        RectF localRectF2;
        switch (i5)
        {
        case 9: 
          if ((paramInt3 & 0x4) != 0)
          {
            i6 = m - k - 1;
            localRectF2 = drawText(paramLong, arrayOfChar, k, i6, n, i1, paramInt3, i3, localTEXTMETRICA, paramPoint == null);
            n = (int)(n + Math.ceil(localRectF2.Width));
            n = paramInt1 + ((n - paramInt1) / i4 + 1) * i4;
            i3 = -1;
            k = m;
          }
          break;
        case 38: 
          if ((paramInt3 & 0x8) != 0) {
            if (j == i)
            {
              m--;
            }
            else if (arrayOfChar[j] == '&')
            {
              j++;
            }
            else
            {
              m--;
              i3 = m - k;
            }
          }
          break;
        case 10: 
        case 13: 
          if ((paramInt3 & 0x2) != 0)
          {
            i6 = m - k - 1;
            if ((i5 == 13) && (m != i) && (arrayOfChar[m] == '\n'))
            {
              m++;
              j++;
            }
            localRectF2 = drawText(paramLong, arrayOfChar, k, i6, n, i1, paramInt3, i3, localTEXTMETRICA, paramPoint == null);
            i1 = (int)(i1 + Math.ceil(localRectF2.Height));
            i2 = Math.max(i2, n + (int)Math.ceil(localRectF2.Width));
            n = paramInt1;
            i3 = -1;
            k = m;
          }
          break;
        }
      }
      i = m;
    }
    RectF localRectF1 = drawText(paramLong, arrayOfChar, k, i - k, n, i1, paramInt3, i3, localTEXTMETRICA, paramPoint == null);
    if (paramPoint != null)
    {
      i1 = (int)(i1 + Math.ceil(localRectF1.Height));
      i2 = Math.max(i2, n + (int)Math.ceil(localRectF1.Width));
      paramPoint.x = i2;
      paramPoint.y = i1;
    }
  }
  
  RectF drawText(long paramLong, char[] paramArrayOfChar, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, TEXTMETRIC paramTEXTMETRIC, boolean paramBoolean)
  {
    int i = (paramBoolean) && (paramInt6 != -1) && ((this.data.uiState & 0x2) == 0) ? 1 : 0;
    int j = (!paramBoolean) || (i != 0) || ((paramInt5 & 0x1) == 0) || ((this.data.style & 0x8000000) != 0) || ((paramInt5 & 0x2) != 0) ? 1 : 0;
    if (paramInt2 <= 0)
    {
      RectF localRectF1 = null;
      if (j != 0)
      {
        localRectF1 = new RectF();
        localRectF1.Height = paramTEXTMETRIC.tmHeight;
      }
      return localRectF1;
    }
    int k = paramInt2 * 3 / 2 + 16;
    GCP_RESULTS localGCP_RESULTS = new GCP_RESULTS();
    localGCP_RESULTS.lStructSize = GCP_RESULTS.sizeof;
    localGCP_RESULTS.nGlyphs = k;
    long l1 = OS.GetProcessHeap();
    long l2 = localGCP_RESULTS.lpDx = OS.HeapAlloc(l1, 8, k * 4);
    long l3 = localGCP_RESULTS.lpGlyphs = OS.HeapAlloc(l1, 8, k * 2);
    long l4 = 0L;
    int m = 50;
    if (i != 0) {
      l4 = localGCP_RESULTS.lpOrder = OS.HeapAlloc(l1, 8, k * 4);
    }
    long l5 = Gdip.Graphics_GetHDC(paramLong);
    long l6 = this.data.hGDIFont;
    if ((l6 == 0L) && (this.data.font != null)) {
      l6 = this.data.font.handle;
    }
    long l7 = 0L;
    if (l6 != 0L) {
      l7 = OS.SelectObject(l5, l6);
    }
    if (paramInt1 != 0)
    {
      char[] arrayOfChar = new char[paramInt2];
      System.arraycopy(paramArrayOfChar, paramInt1, arrayOfChar, 0, paramInt2);
      paramArrayOfChar = arrayOfChar;
    }
    if ((this.data.style & 0x8000000) != 0) {
      OS.SetLayout(l5, OS.GetLayout(l5) | 0x1);
    }
    OS.GetCharacterPlacementW(l5, paramArrayOfChar, paramInt2, 0, localGCP_RESULTS, m);
    if ((this.data.style & 0x8000000) != 0) {
      OS.SetLayout(l5, OS.GetLayout(l5) & 0xFFFFFFFE);
    }
    if (l6 != 0L) {
      OS.SelectObject(l5, l7);
    }
    Gdip.Graphics_ReleaseHDC(paramLong, l5);
    k = localGCP_RESULTS.nGlyphs;
    int n = paramInt3;
    int i1 = paramInt4 + paramTEXTMETRIC.tmAscent;
    int[] arrayOfInt1 = new int[k];
    OS.MoveMemory(arrayOfInt1, localGCP_RESULTS.lpDx, k * 4);
    float[] arrayOfFloat = new float[arrayOfInt1.length * 2];
    int i2 = 0;
    int i3 = 0;
    while (i2 < arrayOfInt1.length)
    {
      arrayOfFloat[(i3++)] = n;
      arrayOfFloat[(i3++)] = i1;
      n += arrayOfInt1[i2];
      i2++;
    }
    RectF localRectF2 = null;
    if (j != 0)
    {
      localRectF2 = new RectF();
      Gdip.Graphics_MeasureDriverString(paramLong, l3, k, this.data.gdipFont, arrayOfFloat, 0, 0L, localRectF2);
    }
    if (paramBoolean)
    {
      if ((paramInt5 & 0x1) == 0) {
        Gdip.Graphics_FillRectangle(paramLong, this.data.gdipBrush, paramInt3, paramInt4, (int)Math.ceil(localRectF2.Width), (int)Math.ceil(localRectF2.Height));
      }
      i3 = 0;
      long l8 = getFgBrush();
      if ((this.data.style & 0x8000000) != 0)
      {
        switch (Gdip.Brush_GetType(l8))
        {
        case 4: 
          Gdip.LinearGradientBrush_ScaleTransform(l8, -1.0F, 1.0F, 0);
          Gdip.LinearGradientBrush_TranslateTransform(l8, -2 * paramInt3 - localRectF2.Width, 0.0F, 0);
          break;
        case 2: 
          Gdip.TextureBrush_ScaleTransform(l8, -1.0F, 1.0F, 0);
          Gdip.TextureBrush_TranslateTransform(l8, -2 * paramInt3 - localRectF2.Width, 0.0F, 0);
        }
        i3 = Gdip.Graphics_Save(paramLong);
        Gdip.Graphics_ScaleTransform(paramLong, -1.0F, 1.0F, 0);
        Gdip.Graphics_TranslateTransform(paramLong, -2 * paramInt3 - localRectF2.Width, 0.0F, 0);
      }
      Gdip.Graphics_DrawDriverString(paramLong, l3, localGCP_RESULTS.nGlyphs, this.data.gdipFont, l8, arrayOfFloat, 0, 0L);
      if ((this.data.style & 0x8000000) != 0)
      {
        switch (Gdip.Brush_GetType(l8))
        {
        case 4: 
          Gdip.LinearGradientBrush_ResetTransform(l8);
          break;
        case 2: 
          Gdip.TextureBrush_ResetTransform(l8);
        }
        Gdip.Graphics_Restore(paramLong, i3);
      }
      if (i != 0)
      {
        long l9 = Gdip.Pen_new(l8, 1.0F);
        if (l9 != 0L)
        {
          int[] arrayOfInt2 = new int[1];
          OS.MoveMemory(arrayOfInt2, localGCP_RESULTS.lpOrder + paramInt6 * 4, 4);
          int i4;
          int i5;
          if ((this.data.style & 0x8000000) != 0)
          {
            i4 = (int)Math.ceil(localRectF2.Width) - (int)arrayOfFloat[(arrayOfInt2[0] * 2)] + 2 * paramInt3;
            i5 = i4 - arrayOfInt1[arrayOfInt2[0]];
          }
          else
          {
            i4 = (int)arrayOfFloat[(arrayOfInt2[0] * 2)];
            i5 = i4 + arrayOfInt1[arrayOfInt2[0]];
          }
          int i6 = paramInt4 + paramTEXTMETRIC.tmAscent + 2;
          int i7 = Gdip.Graphics_GetSmoothingMode(paramLong);
          Gdip.Graphics_SetSmoothingMode(paramLong, 3);
          Gdip.Graphics_DrawLine(paramLong, l9, i4, i6, i5, i6);
          Gdip.Graphics_SetSmoothingMode(paramLong, i7);
          Gdip.Pen_delete(l9);
        }
      }
    }
    if (l4 != 0L) {
      OS.HeapFree(l1, 0, l4);
    }
    OS.HeapFree(l1, 0, l3);
    OS.HeapFree(l1, 0, l2);
    return localRectF2;
  }
  
  void drawTextGDIP(long paramLong, String paramString, int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean, Point paramPoint)
  {
    int i = (!paramBoolean) || ((paramInt3 & 0x1) == 0) ? 1 : 0;
    int j = paramString.length();
    char[] arrayOfChar;
    if (j != 0)
    {
      arrayOfChar = new char[j];
      paramString.getChars(0, j, arrayOfChar, 0);
    }
    else
    {
      if (paramBoolean) {
        return;
      }
      arrayOfChar = new char[] { ' ' };
    }
    PointF localPointF = new PointF();
    long l1 = Gdip.StringFormat_Clone(Gdip.StringFormat_GenericTypographic());
    int k = Gdip.StringFormat_GetFormatFlags(l1) | 0x800;
    if ((this.data.style & 0x8000000) != 0) {
      k |= 0x1;
    }
    Gdip.StringFormat_SetFormatFlags(l1, k);
    float[] arrayOfFloat = (paramInt3 & 0x4) != 0 ? new float[] { measureSpace(this.data.gdipFont, l1) * 8.0F } : new float[1];
    Gdip.StringFormat_SetTabStops(l1, 0.0F, arrayOfFloat.length, arrayOfFloat);
    int m = (paramInt3 & 0x8) != 0 ? 1 : 0;
    if (((paramInt3 & 0x8) != 0) && ((this.data.uiState & 0x2) != 0)) {
      m = 2;
    }
    Gdip.StringFormat_SetHotkeyPrefix(l1, m);
    RectF localRectF = null;
    if (i != 0)
    {
      localRectF = new RectF();
      Gdip.Graphics_MeasureString(paramLong, arrayOfChar, arrayOfChar.length, this.data.gdipFont, localPointF, l1, localRectF);
    }
    if (paramBoolean)
    {
      if ((paramInt3 & 0x1) == 0) {
        Gdip.Graphics_FillRectangle(paramLong, this.data.gdipBrush, paramInt1, paramInt2, (int)Math.ceil(localRectF.Width), (int)Math.ceil(localRectF.Height));
      }
      int n = 0;
      long l2 = getFgBrush();
      if ((this.data.style & 0x8000000) != 0)
      {
        switch (Gdip.Brush_GetType(l2))
        {
        case 4: 
          Gdip.LinearGradientBrush_ScaleTransform(l2, -1.0F, 1.0F, 0);
          Gdip.LinearGradientBrush_TranslateTransform(l2, -2 * paramInt1, 0.0F, 0);
          break;
        case 2: 
          Gdip.TextureBrush_ScaleTransform(l2, -1.0F, 1.0F, 0);
          Gdip.TextureBrush_TranslateTransform(l2, -2 * paramInt1, 0.0F, 0);
        }
        n = Gdip.Graphics_Save(paramLong);
        Gdip.Graphics_ScaleTransform(paramLong, -1.0F, 1.0F, 0);
        Gdip.Graphics_TranslateTransform(paramLong, -2 * paramInt1, 0.0F, 0);
      }
      localPointF.X = paramInt1;
      localPointF.Y = paramInt2;
      Gdip.Graphics_DrawString(paramLong, arrayOfChar, arrayOfChar.length, this.data.gdipFont, localPointF, l1, l2);
      if ((this.data.style & 0x8000000) != 0)
      {
        switch (Gdip.Brush_GetType(l2))
        {
        case 4: 
          Gdip.LinearGradientBrush_ResetTransform(l2);
          break;
        case 2: 
          Gdip.TextureBrush_ResetTransform(l2);
        }
        Gdip.Graphics_Restore(paramLong, n);
      }
    }
    Gdip.StringFormat_delete(l1);
    if (j == 0) {
      localRectF.Width = 0.0F;
    }
    if (paramPoint != null)
    {
      paramPoint.x = ((int)Math.ceil(localRectF.Width));
      paramPoint.y = ((int)Math.ceil(localRectF.Height));
    }
  }
  
  public boolean equals(Object paramObject)
  {
    return (paramObject == this) || (((paramObject instanceof GC)) && (this.handle == ((GC)paramObject).handle));
  }
  
  public void fillArc(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6)
  {
    if (this.handle == 0L) {
      SWT.error(44);
    }
    checkGC(9218);
    if (paramInt3 < 0)
    {
      paramInt1 += paramInt3;
      paramInt3 = -paramInt3;
    }
    if (paramInt4 < 0)
    {
      paramInt2 += paramInt4;
      paramInt4 = -paramInt4;
    }
    if ((paramInt3 == 0) || (paramInt4 == 0) || (paramInt6 == 0)) {
      return;
    }
    long l = this.data.gdipGraphics;
    int i;
    if (l != 0L)
    {
      if (paramInt3 == paramInt4)
      {
        Gdip.Graphics_FillPie(l, this.data.gdipBrush, paramInt1, paramInt2, paramInt3, paramInt4, -paramInt5, -paramInt6);
      }
      else
      {
        i = Gdip.Graphics_Save(l);
        Gdip.Graphics_TranslateTransform(l, paramInt1, paramInt2, 0);
        Gdip.Graphics_ScaleTransform(l, paramInt3, paramInt4, 0);
        Gdip.Graphics_FillPie(l, this.data.gdipBrush, 0, 0, 1, 1, -paramInt5, -paramInt6);
        Gdip.Graphics_Restore(l, i);
      }
      return;
    }
    if ((this.data.style & 0x8000000) != 0) {
      paramInt1--;
    }
    int k;
    int m;
    int n;
    int i1;
    if (OS.IsWinCE)
    {
      if (paramInt6 < 0)
      {
        paramInt5 += paramInt6;
        paramInt6 = -paramInt6;
      }
      i = 1;
      if (paramInt6 >= 360)
      {
        paramInt6 = 360;
        i = 0;
      }
      int[] arrayOfInt = new int[(paramInt6 + 1) * 2 + (i != 0 ? 4 : 0)];
      k = 2 * paramInt1 + paramInt3;
      m = 2 * paramInt2 + paramInt4;
      n = i != 0 ? 2 : 0;
      for (i1 = 0; i1 <= paramInt6; i1++)
      {
        arrayOfInt[(n++)] = (Compatibility.cos(paramInt5 + i1, paramInt3) + k >> 1);
        arrayOfInt[(n++)] = (m - Compatibility.sin(paramInt5 + i1, paramInt4) >> 1);
      }
      if (i != 0)
      {
        arrayOfInt[0] = (arrayOfInt[(arrayOfInt.length - 2)] = k >> 1);
        arrayOfInt[1] = (arrayOfInt[(arrayOfInt.length - 1)] = m >> 1);
      }
      OS.Polygon(this.handle, arrayOfInt, arrayOfInt.length / 2);
    }
    else
    {
      int j;
      if ((paramInt6 >= 360) || (paramInt6 <= 65176))
      {
        i = k = paramInt1 + paramInt3;
        j = m = paramInt2 + paramInt4 / 2;
      }
      else
      {
        i1 = paramInt6 < 0 ? 1 : 0;
        paramInt6 += paramInt5;
        if (i1 != 0)
        {
          n = paramInt5;
          paramInt5 = paramInt6;
          paramInt6 = n;
        }
        i = Compatibility.cos(paramInt5, paramInt3) + paramInt1 + paramInt3 / 2;
        j = -1 * Compatibility.sin(paramInt5, paramInt4) + paramInt2 + paramInt4 / 2;
        k = Compatibility.cos(paramInt6, paramInt3) + paramInt1 + paramInt3 / 2;
        m = -1 * Compatibility.sin(paramInt6, paramInt4) + paramInt2 + paramInt4 / 2;
      }
      OS.Pie(this.handle, paramInt1, paramInt2, paramInt1 + paramInt3 + 1, paramInt2 + paramInt4 + 1, i, j, k, m);
    }
  }
  
  public void fillGradientRectangle(int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean)
  {
    if (this.handle == 0L) {
      SWT.error(44);
    }
    if ((paramInt3 == 0) || (paramInt4 == 0)) {
      return;
    }
    RGB localRGB1 = getBackground().getRGB();
    RGB localRGB2 = getForeground().getRGB();
    RGB localRGB3 = localRGB2;
    RGB localRGB4 = localRGB1;
    int i = 0;
    if (paramInt3 < 0)
    {
      paramInt1 += paramInt3;
      paramInt3 = -paramInt3;
      if (!paramBoolean) {
        i = 1;
      }
    }
    if (paramInt4 < 0)
    {
      paramInt2 += paramInt4;
      paramInt4 = -paramInt4;
      if (paramBoolean) {
        i = 1;
      }
    }
    if (i != 0)
    {
      localRGB3 = localRGB1;
      localRGB4 = localRGB2;
    }
    if (localRGB3.equals(localRGB4))
    {
      fillRectangle(paramInt1, paramInt2, paramInt3, paramInt4);
      return;
    }
    long l2;
    long l3;
    if (this.data.gdipGraphics != 0L)
    {
      initGdip();
      PointF localPointF1 = new PointF();
      PointF localPointF2 = new PointF();
      localPointF1.X = paramInt1;
      localPointF1.Y = paramInt2;
      if (paramBoolean)
      {
        localPointF2.X = localPointF1.X;
        localPointF1.Y += paramInt4;
      }
      else
      {
        localPointF1.X += paramInt3;
        localPointF2.Y = localPointF1.Y;
      }
      m = (localRGB3.red & 0xFF) << 16 | (localRGB3.green & 0xFF) << 8 | localRGB3.blue & 0xFF;
      l2 = Gdip.Color_new(this.data.alpha << 24 | m);
      if (l2 == 0L) {
        SWT.error(2);
      }
      m = (localRGB4.red & 0xFF) << 16 | (localRGB4.green & 0xFF) << 8 | localRGB4.blue & 0xFF;
      l3 = Gdip.Color_new(this.data.alpha << 24 | m);
      if (l3 == 0L) {
        SWT.error(2);
      }
      long l4 = Gdip.LinearGradientBrush_new(localPointF1, localPointF2, l2, l3);
      Gdip.Graphics_FillRectangle(this.data.gdipGraphics, l4, paramInt1, paramInt2, paramInt3, paramInt4);
      Gdip.LinearGradientBrush_delete(l4);
      Gdip.Color_delete(l2);
      Gdip.Color_delete(l3);
      return;
    }
    int j = 0;
    if (OS.IsWinCE)
    {
      j = OS.SetROP2(this.handle, 13);
      OS.SetROP2(this.handle, j);
    }
    else
    {
      j = OS.GetROP2(this.handle);
    }
    if ((OS.IsWinNT) && (j != 7) && (OS.GetDeviceCaps(this.handle, 2) != 2))
    {
      long l1 = OS.GetProcessHeap();
      l2 = OS.HeapAlloc(l1, 8, GRADIENT_RECT.sizeof + TRIVERTEX.sizeof * 2);
      if (l2 == 0L) {
        SWT.error(2);
      }
      l3 = l2 + GRADIENT_RECT.sizeof;
      GRADIENT_RECT localGRADIENT_RECT = new GRADIENT_RECT();
      localGRADIENT_RECT.UpperLeft = 0;
      localGRADIENT_RECT.LowerRight = 1;
      OS.MoveMemory(l2, localGRADIENT_RECT, GRADIENT_RECT.sizeof);
      TRIVERTEX localTRIVERTEX = new TRIVERTEX();
      localTRIVERTEX.x = paramInt1;
      localTRIVERTEX.y = paramInt2;
      localTRIVERTEX.Red = ((short)(localRGB3.red << 8 | localRGB3.red));
      localTRIVERTEX.Green = ((short)(localRGB3.green << 8 | localRGB3.green));
      localTRIVERTEX.Blue = ((short)(localRGB3.blue << 8 | localRGB3.blue));
      localTRIVERTEX.Alpha = -1;
      OS.MoveMemory(l3, localTRIVERTEX, TRIVERTEX.sizeof);
      localTRIVERTEX.x = (paramInt1 + paramInt3);
      localTRIVERTEX.y = (paramInt2 + paramInt4);
      localTRIVERTEX.Red = ((short)(localRGB4.red << 8 | localRGB4.red));
      localTRIVERTEX.Green = ((short)(localRGB4.green << 8 | localRGB4.green));
      localTRIVERTEX.Blue = ((short)(localRGB4.blue << 8 | localRGB4.blue));
      localTRIVERTEX.Alpha = -1;
      OS.MoveMemory(l3 + TRIVERTEX.sizeof, localTRIVERTEX, TRIVERTEX.sizeof);
      boolean bool = OS.GradientFill(this.handle, l3, 2, l2, 1, paramBoolean ? 1 : 0);
      OS.HeapFree(l1, 0, l2);
      if (bool) {
        return;
      }
    }
    int k = OS.GetDeviceCaps(this.handle, 12);
    int m = k >= 15 ? 5 : k >= 24 ? 8 : 0;
    ImageData.fillGradientRectangle(this, this.data.device, paramInt1, paramInt2, paramInt3, paramInt4, paramBoolean, localRGB3, localRGB4, m, m, m);
  }
  
  public void fillOval(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    if (this.handle == 0L) {
      SWT.error(44);
    }
    checkGC(9218);
    if (this.data.gdipGraphics != 0L)
    {
      Gdip.Graphics_FillEllipse(this.data.gdipGraphics, this.data.gdipBrush, paramInt1, paramInt2, paramInt3, paramInt4);
      return;
    }
    if ((this.data.style & 0x8000000) != 0) {
      paramInt1--;
    }
    OS.Ellipse(this.handle, paramInt1, paramInt2, paramInt1 + paramInt3 + 1, paramInt2 + paramInt4 + 1);
  }
  
  public void fillPath(Path paramPath)
  {
    if (this.handle == 0L) {
      SWT.error(44);
    }
    if (paramPath == null) {
      SWT.error(4);
    }
    if (paramPath.handle == 0L) {
      SWT.error(5);
    }
    initGdip();
    checkGC(9218);
    int i = OS.GetPolyFillMode(this.handle) == 2 ? 1 : 0;
    Gdip.GraphicsPath_SetFillMode(paramPath.handle, i);
    Gdip.Graphics_FillPath(this.data.gdipGraphics, this.data.gdipBrush, paramPath.handle);
  }
  
  public void fillPolygon(int[] paramArrayOfInt)
  {
    if (this.handle == 0L) {
      SWT.error(44);
    }
    if (paramArrayOfInt == null) {
      SWT.error(4);
    }
    checkGC(9218);
    int i;
    if (this.data.gdipGraphics != 0L)
    {
      i = OS.GetPolyFillMode(this.handle) == 2 ? 1 : 0;
      Gdip.Graphics_FillPolygon(this.data.gdipGraphics, this.data.gdipBrush, paramArrayOfInt, paramArrayOfInt.length / 2, i);
      return;
    }
    if ((this.data.style & 0x8000000) != 0) {
      for (i = 0; i < paramArrayOfInt.length; i += 2) {
        paramArrayOfInt[i] -= 1;
      }
    }
    OS.Polygon(this.handle, paramArrayOfInt, paramArrayOfInt.length / 2);
    if ((this.data.style & 0x8000000) != 0) {
      for (i = 0; i < paramArrayOfInt.length; i += 2) {
        paramArrayOfInt[i] += 1;
      }
    }
  }
  
  public void fillRectangle(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    if (this.handle == 0L) {
      SWT.error(44);
    }
    checkGC(9218);
    if (this.data.gdipGraphics != 0L)
    {
      if (paramInt3 < 0)
      {
        paramInt1 += paramInt3;
        paramInt3 = -paramInt3;
      }
      if (paramInt4 < 0)
      {
        paramInt2 += paramInt4;
        paramInt4 = -paramInt4;
      }
      Gdip.Graphics_FillRectangle(this.data.gdipGraphics, this.data.gdipBrush, paramInt1, paramInt2, paramInt3, paramInt4);
      return;
    }
    int i = 0;
    if (OS.IsWinCE)
    {
      i = OS.SetROP2(this.handle, 13);
      OS.SetROP2(this.handle, i);
    }
    else
    {
      i = OS.GetROP2(this.handle);
    }
    int j = i == 7 ? 5898313 : 15728673;
    OS.PatBlt(this.handle, paramInt1, paramInt2, paramInt3, paramInt4, j);
  }
  
  public void fillRectangle(Rectangle paramRectangle)
  {
    if (paramRectangle == null) {
      SWT.error(4);
    }
    fillRectangle(paramRectangle.x, paramRectangle.y, paramRectangle.width, paramRectangle.height);
  }
  
  public void fillRoundRectangle(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6)
  {
    if (this.handle == 0L) {
      SWT.error(44);
    }
    checkGC(9218);
    if (this.data.gdipGraphics != 0L)
    {
      fillRoundRectangleGdip(this.data.gdipGraphics, this.data.gdipBrush, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6);
      return;
    }
    if ((this.data.style & 0x8000000) != 0) {
      paramInt1--;
    }
    OS.RoundRect(this.handle, paramInt1, paramInt2, paramInt1 + paramInt3 + 1, paramInt2 + paramInt4 + 1, paramInt5, paramInt6);
  }
  
  void fillRoundRectangleGdip(long paramLong1, long paramLong2, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6)
  {
    int i = paramInt1;
    int j = paramInt2;
    int k = paramInt3;
    int m = paramInt4;
    int n = paramInt5;
    int i1 = paramInt6;
    if (k < 0)
    {
      k = 0 - k;
      i -= k;
    }
    if (m < 0)
    {
      m = 0 - m;
      j -= m;
    }
    if (n < 0) {
      n = 0 - n;
    }
    if (i1 < 0) {
      i1 = 0 - i1;
    }
    if ((n == 0) || (i1 == 0))
    {
      Gdip.Graphics_FillRectangle(this.data.gdipGraphics, this.data.gdipBrush, paramInt1, paramInt2, paramInt3, paramInt4);
    }
    else
    {
      long l = Gdip.GraphicsPath_new(0);
      if (l == 0L) {
        SWT.error(2);
      }
      if (k > n)
      {
        if (m > i1)
        {
          Gdip.GraphicsPath_AddArc(l, i + k - n, j, n, i1, 0.0F, -90.0F);
          Gdip.GraphicsPath_AddArc(l, i, j, n, i1, -90.0F, -90.0F);
          Gdip.GraphicsPath_AddArc(l, i, j + m - i1, n, i1, -180.0F, -90.0F);
          Gdip.GraphicsPath_AddArc(l, i + k - n, j + m - i1, n, i1, -270.0F, -90.0F);
        }
        else
        {
          Gdip.GraphicsPath_AddArc(l, i + k - n, j, n, m, -270.0F, -180.0F);
          Gdip.GraphicsPath_AddArc(l, i, j, n, m, -90.0F, -180.0F);
        }
      }
      else if (m > i1)
      {
        Gdip.GraphicsPath_AddArc(l, i, j, k, i1, 0.0F, -180.0F);
        Gdip.GraphicsPath_AddArc(l, i, j + m - i1, k, i1, -180.0F, -180.0F);
      }
      else
      {
        Gdip.GraphicsPath_AddArc(l, i, j, k, m, 0.0F, 360.0F);
      }
      Gdip.GraphicsPath_CloseFigure(l);
      Gdip.Graphics_FillPath(paramLong1, paramLong2, l);
      Gdip.GraphicsPath_delete(l);
    }
  }
  
  void flush()
  {
    if (this.data.gdipGraphics != 0L)
    {
      Gdip.Graphics_Flush(this.data.gdipGraphics, 0);
      long l = Gdip.Graphics_GetHDC(this.data.gdipGraphics);
      Gdip.Graphics_ReleaseHDC(this.data.gdipGraphics, l);
    }
  }
  
  public int getAdvanceWidth(char paramChar)
  {
    if (this.handle == 0L) {
      SWT.error(44);
    }
    checkGC(4);
    if (OS.IsWinCE)
    {
      SIZE localSIZE = new SIZE();
      OS.GetTextExtentPoint32W(this.handle, new char[] { paramChar }, 1, localSIZE);
      return localSIZE.cx;
    }
    int i = paramChar;
    if (paramChar > '')
    {
      localObject = new TCHAR(getCodePage(), paramChar, false);
      i = ((TCHAR)localObject).tcharAt(0);
    }
    Object localObject = new int[1];
    OS.GetCharWidth(this.handle, i, i, (int[])localObject);
    return localObject[0];
  }
  
  public boolean getAdvanced()
  {
    if (this.handle == 0L) {
      SWT.error(44);
    }
    return this.data.gdipGraphics != 0L;
  }
  
  public int getAlpha()
  {
    if (this.handle == 0L) {
      SWT.error(44);
    }
    return this.data.alpha;
  }
  
  public int getAntialias()
  {
    if (this.handle == 0L) {
      SWT.error(44);
    }
    if (this.data.gdipGraphics == 0L) {
      return -1;
    }
    int i = Gdip.Graphics_GetSmoothingMode(this.data.gdipGraphics);
    switch (i)
    {
    case 0: 
      return -1;
    case 1: 
    case 3: 
      return 0;
    case 2: 
    case 4: 
    case 5: 
      return 1;
    }
    return -1;
  }
  
  public Color getBackground()
  {
    if (this.handle == 0L) {
      SWT.error(44);
    }
    return Color.win32_new(this.data.device, this.data.background);
  }
  
  public Pattern getBackgroundPattern()
  {
    if (this.handle == 0L) {
      SWT.error(44);
    }
    return this.data.backgroundPattern;
  }
  
  public int getCharWidth(char paramChar)
  {
    if (this.handle == 0L) {
      SWT.error(44);
    }
    checkGC(4);
    if (!OS.IsWinCE)
    {
      int i = paramChar;
      if (paramChar > '')
      {
        localObject = new TCHAR(getCodePage(), paramChar, false);
        i = ((TCHAR)localObject).tcharAt(0);
      }
      localObject = new int[3];
      if (OS.GetCharABCWidths(this.handle, i, i, (int[])localObject)) {
        return localObject[1];
      }
    }
    TEXTMETRICA localTEXTMETRICA = OS.IsUnicode ? new TEXTMETRICW() : new TEXTMETRICA();
    OS.GetTextMetrics(this.handle, localTEXTMETRICA);
    Object localObject = new SIZE();
    OS.GetTextExtentPoint32W(this.handle, new char[] { paramChar }, 1, (SIZE)localObject);
    return ((SIZE)localObject).cx - localTEXTMETRICA.tmOverhang;
  }
  
  public Rectangle getClipping()
  {
    if (this.handle == 0L) {
      SWT.error(44);
    }
    long l = this.data.gdipGraphics;
    if (l != 0L)
    {
      localObject = new Rect();
      Gdip.Graphics_SetPixelOffsetMode(l, 3);
      Gdip.Graphics_GetVisibleClipBounds(l, (Rect)localObject);
      Gdip.Graphics_SetPixelOffsetMode(l, 4);
      return new Rectangle(((Rect)localObject).X, ((Rect)localObject).Y, ((Rect)localObject).Width, ((Rect)localObject).Height);
    }
    Object localObject = new RECT();
    OS.GetClipBox(this.handle, (RECT)localObject);
    return new Rectangle(((RECT)localObject).left, ((RECT)localObject).top, ((RECT)localObject).right - ((RECT)localObject).left, ((RECT)localObject).bottom - ((RECT)localObject).top);
  }
  
  public void getClipping(Region paramRegion)
  {
    if (this.handle == 0L) {
      SWT.error(44);
    }
    if (paramRegion == null) {
      SWT.error(4);
    }
    if (paramRegion.isDisposed()) {
      SWT.error(5);
    }
    long l1 = this.data.gdipGraphics;
    long l5;
    long l6;
    if (l1 != 0L)
    {
      long l2 = Gdip.Region_new();
      Gdip.Graphics_GetClip(this.data.gdipGraphics, l2);
      if (Gdip.Region_IsInfinite(l2, l1))
      {
        Rect localRect = new Rect();
        Gdip.Graphics_SetPixelOffsetMode(l1, 3);
        Gdip.Graphics_GetVisibleClipBounds(l1, localRect);
        Gdip.Graphics_SetPixelOffsetMode(l1, 4);
        OS.SetRectRgn(paramRegion.handle, localRect.X, localRect.Y, localRect.X + localRect.Width, localRect.Y + localRect.Height);
      }
      else
      {
        long l3 = Gdip.Matrix_new(1.0F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F);
        l5 = Gdip.Matrix_new(1.0F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F);
        Gdip.Graphics_GetTransform(l1, l3);
        Gdip.Graphics_SetTransform(l1, l5);
        l6 = Gdip.Region_GetHRGN(l2, this.data.gdipGraphics);
        Gdip.Graphics_SetTransform(l1, l3);
        Gdip.Matrix_delete(l5);
        Gdip.Matrix_delete(l3);
        if (!OS.IsWinCE)
        {
          POINT localPOINT2 = new POINT();
          OS.GetWindowOrgEx(this.handle, localPOINT2);
          OS.OffsetRgn(l6, localPOINT2.x, localPOINT2.y);
        }
        OS.CombineRgn(paramRegion.handle, l6, 0L, 5);
        OS.DeleteObject(l6);
      }
      Gdip.Region_delete(l2);
      return;
    }
    POINT localPOINT1 = new POINT();
    if (!OS.IsWinCE) {
      OS.GetWindowOrgEx(this.handle, localPOINT1);
    }
    int i = OS.GetClipRgn(this.handle, paramRegion.handle);
    if (i != 1)
    {
      RECT localRECT = new RECT();
      OS.GetClipBox(this.handle, localRECT);
      OS.SetRectRgn(paramRegion.handle, localRECT.left, localRECT.top, localRECT.right, localRECT.bottom);
    }
    else
    {
      OS.OffsetRgn(paramRegion.handle, localPOINT1.x, localPOINT1.y);
    }
    if (!OS.IsWinCE)
    {
      long l4 = OS.CreateRectRgn(0, 0, 0, 0);
      if (OS.GetMetaRgn(this.handle, l4) != 0)
      {
        OS.OffsetRgn(l4, localPOINT1.x, localPOINT1.y);
        OS.CombineRgn(paramRegion.handle, l4, paramRegion.handle, 1);
      }
      OS.DeleteObject(l4);
      l5 = this.data.hwnd;
      if ((l5 != 0L) && (this.data.ps != null))
      {
        l6 = OS.CreateRectRgn(0, 0, 0, 0);
        if (OS.GetRandomRgn(this.handle, l6, 4) == 1)
        {
          if ((OS.WIN32_VERSION >= OS.VERSION(4, 10)) && ((OS.GetLayout(this.handle) & 0x1) != 0))
          {
            int j = OS.GetRegionData(l6, 0, null);
            int[] arrayOfInt = new int[j / 4];
            OS.GetRegionData(l6, j, arrayOfInt);
            long l7 = OS.ExtCreateRegion(new float[] { -1.0F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F }, j, arrayOfInt);
            OS.DeleteObject(l6);
            l6 = l7;
          }
          if (OS.IsWinNT)
          {
            OS.MapWindowPoints(0L, l5, localPOINT1, 1);
            OS.OffsetRgn(l6, localPOINT1.x, localPOINT1.y);
          }
          OS.CombineRgn(paramRegion.handle, l6, paramRegion.handle, 1);
        }
        OS.DeleteObject(l6);
      }
    }
  }
  
  int getCodePage()
  {
    if (OS.IsUnicode) {
      return 0;
    }
    int[] arrayOfInt = new int[8];
    int i = OS.GetTextCharset(this.handle);
    OS.TranslateCharsetInfo(i, arrayOfInt, 1);
    return arrayOfInt[1];
  }
  
  long getFgBrush()
  {
    return this.data.foregroundPattern != null ? this.data.foregroundPattern.handle : this.data.gdipFgBrush;
  }
  
  public int getFillRule()
  {
    if (this.handle == 0L) {
      SWT.error(44);
    }
    if (OS.IsWinCE) {
      return 1;
    }
    return OS.GetPolyFillMode(this.handle) == 2 ? 2 : 1;
  }
  
  public Font getFont()
  {
    if (this.handle == 0L) {
      SWT.error(44);
    }
    return this.data.font;
  }
  
  public FontMetrics getFontMetrics()
  {
    if (this.handle == 0L) {
      SWT.error(44);
    }
    checkGC(4);
    TEXTMETRICA localTEXTMETRICA = OS.IsUnicode ? new TEXTMETRICW() : new TEXTMETRICA();
    OS.GetTextMetrics(this.handle, localTEXTMETRICA);
    return FontMetrics.win32_new(localTEXTMETRICA);
  }
  
  public Color getForeground()
  {
    if (this.handle == 0L) {
      SWT.error(44);
    }
    return Color.win32_new(this.data.device, this.data.foreground);
  }
  
  public Pattern getForegroundPattern()
  {
    if (this.handle == 0L) {
      SWT.error(44);
    }
    return this.data.foregroundPattern;
  }
  
  public GCData getGCData()
  {
    if (this.handle == 0L) {
      SWT.error(44);
    }
    return this.data;
  }
  
  public int getInterpolation()
  {
    if (this.handle == 0L) {
      SWT.error(44);
    }
    if (this.data.gdipGraphics == 0L) {
      return -1;
    }
    int i = Gdip.Graphics_GetInterpolationMode(this.data.gdipGraphics);
    switch (i)
    {
    case 0: 
      return -1;
    case 5: 
      return 0;
    case 1: 
    case 3: 
      return 1;
    case 2: 
    case 4: 
    case 6: 
    case 7: 
      return 2;
    }
    return -1;
  }
  
  public LineAttributes getLineAttributes()
  {
    if (this.handle == 0L) {
      SWT.error(44);
    }
    float[] arrayOfFloat = null;
    if (this.data.lineDashes != null)
    {
      arrayOfFloat = new float[this.data.lineDashes.length];
      System.arraycopy(this.data.lineDashes, 0, arrayOfFloat, 0, arrayOfFloat.length);
    }
    return new LineAttributes(this.data.lineWidth, this.data.lineCap, this.data.lineJoin, this.data.lineStyle, arrayOfFloat, this.data.lineDashesOffset, this.data.lineMiterLimit);
  }
  
  public int getLineCap()
  {
    if (this.handle == 0L) {
      SWT.error(44);
    }
    return this.data.lineCap;
  }
  
  public int[] getLineDash()
  {
    if (this.handle == 0L) {
      SWT.error(44);
    }
    if (this.data.lineDashes == null) {
      return null;
    }
    int[] arrayOfInt = new int[this.data.lineDashes.length];
    for (int i = 0; i < arrayOfInt.length; i++) {
      arrayOfInt[i] = ((int)this.data.lineDashes[i]);
    }
    return arrayOfInt;
  }
  
  public int getLineJoin()
  {
    if (this.handle == 0L) {
      SWT.error(44);
    }
    return this.data.lineJoin;
  }
  
  public int getLineStyle()
  {
    if (this.handle == 0L) {
      SWT.error(44);
    }
    return this.data.lineStyle;
  }
  
  public int getLineWidth()
  {
    if (this.handle == 0L) {
      SWT.error(44);
    }
    return (int)this.data.lineWidth;
  }
  
  public int getStyle()
  {
    if (this.handle == 0L) {
      SWT.error(44);
    }
    return this.data.style;
  }
  
  public int getTextAntialias()
  {
    if (this.handle == 0L) {
      SWT.error(44);
    }
    if (this.data.gdipGraphics == 0L) {
      return -1;
    }
    int i = Gdip.Graphics_GetTextRenderingHint(this.data.gdipGraphics);
    switch (i)
    {
    case 0: 
      return -1;
    case 1: 
    case 2: 
      return 0;
    case 3: 
    case 4: 
    case 5: 
      return 1;
    }
    return -1;
  }
  
  public void getTransform(Transform paramTransform)
  {
    if (this.handle == 0L) {
      SWT.error(44);
    }
    if (paramTransform == null) {
      SWT.error(4);
    }
    if (paramTransform.isDisposed()) {
      SWT.error(5);
    }
    long l1 = this.data.gdipGraphics;
    if (l1 != 0L)
    {
      Gdip.Graphics_GetTransform(l1, paramTransform.handle);
      long l2 = identity();
      Gdip.Matrix_Invert(l2);
      Gdip.Matrix_Multiply(paramTransform.handle, l2, 1);
      Gdip.Matrix_delete(l2);
    }
    else
    {
      paramTransform.setElements(1.0F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F);
    }
  }
  
  public boolean getXORMode()
  {
    if (this.handle == 0L) {
      SWT.error(44);
    }
    int i = 0;
    if (OS.IsWinCE)
    {
      i = OS.SetROP2(this.handle, 13);
      OS.SetROP2(this.handle, i);
    }
    else
    {
      i = OS.GetROP2(this.handle);
    }
    return i == 7;
  }
  
  void initGdip()
  {
    this.data.device.checkGDIP();
    long l1 = this.data.gdipGraphics;
    if (l1 != 0L) {
      return;
    }
    long l2 = OS.CreateRectRgn(0, 0, 0, 0);
    int i = OS.GetClipRgn(this.handle, l2);
    if (!OS.IsWinCE)
    {
      POINT localPOINT = new POINT();
      OS.GetWindowOrgEx(this.handle, localPOINT);
      OS.OffsetRgn(l2, localPOINT.x, localPOINT.y);
    }
    OS.SelectClipRgn(this.handle, 0L);
    if ((this.data.style & 0x8000000) != 0) {
      OS.SetLayout(this.handle, OS.GetLayout(this.handle) & 0xFFFFFFFE);
    }
    l1 = this.data.gdipGraphics = Gdip.Graphics_new(this.handle);
    if (l1 == 0L) {
      SWT.error(2);
    }
    Gdip.Graphics_SetPageUnit(l1, 2);
    Gdip.Graphics_SetPixelOffsetMode(l1, 4);
    if ((this.data.style & 0x8000000) != 0)
    {
      long l3 = identity();
      Gdip.Graphics_SetTransform(l1, l3);
      Gdip.Matrix_delete(l3);
    }
    if (i == 1) {
      setClipping(l2);
    }
    OS.DeleteObject(l2);
    this.data.state = 0;
    if (this.data.hPen != 0L)
    {
      OS.SelectObject(this.handle, OS.GetStockObject(8));
      OS.DeleteObject(this.data.hPen);
      this.data.hPen = 0L;
    }
    if (this.data.hBrush != 0L)
    {
      OS.SelectObject(this.handle, OS.GetStockObject(5));
      OS.DeleteObject(this.data.hBrush);
      this.data.hBrush = 0L;
    }
  }
  
  long identity()
  {
    if ((this.data.style & 0x8000000) != 0)
    {
      int i = 0;
      int j = OS.GetDeviceCaps(this.handle, 2);
      if (j == 2)
      {
        i = OS.GetDeviceCaps(this.handle, 110);
      }
      else
      {
        localObject = this.data.image;
        if (localObject != null)
        {
          BITMAP localBITMAP1 = new BITMAP();
          OS.GetObject(((Image)localObject).handle, BITMAP.sizeof, localBITMAP1);
          i = localBITMAP1.bmWidth;
        }
        else
        {
          long l1 = OS.IsWinCE ? this.data.hwnd : OS.WindowFromDC(this.handle);
          if (l1 != 0L)
          {
            RECT localRECT = new RECT();
            OS.GetClientRect(l1, localRECT);
            i = localRECT.right - localRECT.left;
          }
          else
          {
            long l2 = OS.GetCurrentObject(this.handle, 7);
            BITMAP localBITMAP2 = new BITMAP();
            OS.GetObject(l2, BITMAP.sizeof, localBITMAP2);
            i = localBITMAP2.bmWidth;
          }
        }
      }
      Object localObject = new POINT();
      if (!OS.IsWinCE) {
        OS.GetWindowOrgEx(this.handle, (POINT)localObject);
      }
      return Gdip.Matrix_new(-1.0F, 0.0F, 0.0F, 1.0F, i + 2 * ((POINT)localObject).x, 0.0F);
    }
    return Gdip.Matrix_new(1.0F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F);
  }
  
  void init(Drawable paramDrawable, GCData paramGCData, long paramLong)
  {
    int i = paramGCData.foreground;
    if (i != -1) {
      paramGCData.state &= 0xF6FE;
    } else {
      paramGCData.foreground = OS.GetTextColor(paramLong);
    }
    int j = paramGCData.background;
    if (j != -1) {
      paramGCData.state &= 0xF9FD;
    } else {
      paramGCData.background = OS.GetBkColor(paramLong);
    }
    paramGCData.state &= 0xCFFF;
    Font localFont = paramGCData.font;
    if (localFont != null) {
      paramGCData.state &= 0xFFFFFFFB;
    } else {
      paramGCData.font = Font.win32_new(this.device, OS.GetCurrentObject(paramLong, 6));
    }
    long l = paramGCData.device.hPalette;
    if (l != 0L)
    {
      OS.SelectPalette(paramLong, l, true);
      OS.RealizePalette(paramLong);
    }
    Image localImage = paramGCData.image;
    if (localImage != null)
    {
      paramGCData.hNullBitmap = OS.SelectObject(paramLong, localImage.handle);
      localImage.memGC = this;
    }
    int k = paramGCData.layout;
    if ((k != -1) && (!OS.IsWinCE) && (OS.WIN32_VERSION >= OS.VERSION(4, 10)))
    {
      int m = OS.GetLayout(paramLong);
      if ((m & 0x1) != (k & 0x1))
      {
        m &= 0xFFFFFFFE;
        OS.SetLayout(paramLong, m | k);
      }
      if ((paramGCData.style & 0x4000000) != 0) {
        paramGCData.style |= 0x8000000;
      }
    }
    this.drawable = paramDrawable;
    this.data = paramGCData;
    this.handle = paramLong;
  }
  
  public int hashCode()
  {
    return (int)this.handle;
  }
  
  public boolean isClipped()
  {
    if (this.handle == 0L) {
      SWT.error(44);
    }
    long l1 = this.data.gdipGraphics;
    if (l1 != 0L)
    {
      l2 = Gdip.Region_new();
      Gdip.Graphics_GetClip(this.data.gdipGraphics, l2);
      boolean bool = Gdip.Region_IsInfinite(l2, l1);
      Gdip.Region_delete(l2);
      return !bool;
    }
    long l2 = OS.CreateRectRgn(0, 0, 0, 0);
    int i = OS.GetClipRgn(this.handle, l2);
    OS.DeleteObject(l2);
    return i > 0;
  }
  
  public boolean isDisposed()
  {
    return this.handle == 0L;
  }
  
  float measureSpace(long paramLong1, long paramLong2)
  {
    PointF localPointF = new PointF();
    RectF localRectF = new RectF();
    Gdip.Graphics_MeasureString(this.data.gdipGraphics, new char[] { ' ' }, 1, paramLong1, localPointF, paramLong2, localRectF);
    return localRectF.Width;
  }
  
  public void setAdvanced(boolean paramBoolean)
  {
    if (this.handle == 0L) {
      SWT.error(44);
    }
    if ((paramBoolean) && (this.data.gdipGraphics != 0L)) {
      return;
    }
    if (paramBoolean)
    {
      try
      {
        initGdip();
      }
      catch (SWTException localSWTException) {}
    }
    else
    {
      disposeGdip();
      this.data.alpha = 255;
      this.data.backgroundPattern = (this.data.foregroundPattern = null);
      this.data.state = 0;
      setClipping(0L);
      if ((this.data.style & 0x8000000) != 0) {
        OS.SetLayout(this.handle, OS.GetLayout(this.handle) | 0x1);
      }
    }
  }
  
  public void setAntialias(int paramInt)
  {
    if (this.handle == 0L) {
      SWT.error(44);
    }
    if ((this.data.gdipGraphics == 0L) && (paramInt == -1)) {
      return;
    }
    int i = 0;
    switch (paramInt)
    {
    case -1: 
      i = 0;
      break;
    case 0: 
      i = 3;
      break;
    case 1: 
      i = 4;
      break;
    default: 
      SWT.error(5);
    }
    initGdip();
    Gdip.Graphics_SetSmoothingMode(this.data.gdipGraphics, i);
  }
  
  public void setAlpha(int paramInt)
  {
    if (this.handle == 0L) {
      SWT.error(44);
    }
    if ((this.data.gdipGraphics == 0L) && ((paramInt & 0xFF) == 255)) {
      return;
    }
    initGdip();
    this.data.alpha = (paramInt & 0xFF);
    this.data.state &= 0xFFFFFFFC;
  }
  
  public void setBackground(Color paramColor)
  {
    if (this.handle == 0L) {
      SWT.error(44);
    }
    if (paramColor == null) {
      SWT.error(4);
    }
    if (paramColor.isDisposed()) {
      SWT.error(5);
    }
    if ((this.data.backgroundPattern == null) && (this.data.background == paramColor.handle)) {
      return;
    }
    this.data.backgroundPattern = null;
    this.data.background = paramColor.handle;
    this.data.state &= 0xFDFD;
  }
  
  public void setBackgroundPattern(Pattern paramPattern)
  {
    if (this.handle == 0L) {
      SWT.error(44);
    }
    if ((paramPattern != null) && (paramPattern.isDisposed())) {
      SWT.error(5);
    }
    if ((this.data.gdipGraphics == 0L) && (paramPattern == null)) {
      return;
    }
    initGdip();
    if (this.data.backgroundPattern == paramPattern) {
      return;
    }
    this.data.backgroundPattern = paramPattern;
    this.data.state &= 0xFFFFFFFD;
  }
  
  void setClipping(long paramLong)
  {
    long l1 = paramLong;
    long l2 = this.data.gdipGraphics;
    if (l2 != 0L)
    {
      if (l1 != 0L)
      {
        long l3 = Gdip.Region_new(l1);
        Gdip.Graphics_SetClip(l2, l3, 0);
        Gdip.Region_delete(l3);
      }
      else
      {
        Gdip.Graphics_ResetClip(l2);
      }
    }
    else
    {
      POINT localPOINT = null;
      if ((l1 != 0L) && (!OS.IsWinCE))
      {
        localPOINT = new POINT();
        OS.GetWindowOrgEx(this.handle, localPOINT);
        OS.OffsetRgn(l1, -localPOINT.x, -localPOINT.y);
      }
      OS.SelectClipRgn(this.handle, l1);
      if ((l1 != 0L) && (!OS.IsWinCE)) {
        OS.OffsetRgn(l1, localPOINT.x, localPOINT.y);
      }
    }
  }
  
  public void setClipping(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    if (this.handle == 0L) {
      SWT.error(44);
    }
    long l = OS.CreateRectRgn(paramInt1, paramInt2, paramInt1 + paramInt3, paramInt2 + paramInt4);
    setClipping(l);
    OS.DeleteObject(l);
  }
  
  public void setClipping(Path paramPath)
  {
    if (this.handle == 0L) {
      SWT.error(44);
    }
    if ((paramPath != null) && (paramPath.isDisposed())) {
      SWT.error(5);
    }
    setClipping(0L);
    if (paramPath != null)
    {
      initGdip();
      int i = OS.GetPolyFillMode(this.handle) == 2 ? 1 : 0;
      Gdip.GraphicsPath_SetFillMode(paramPath.handle, i);
      Gdip.Graphics_SetClipPath(this.data.gdipGraphics, paramPath.handle);
    }
  }
  
  public void setClipping(Rectangle paramRectangle)
  {
    if (this.handle == 0L) {
      SWT.error(44);
    }
    if (paramRectangle == null) {
      setClipping(0L);
    } else {
      setClipping(paramRectangle.x, paramRectangle.y, paramRectangle.width, paramRectangle.height);
    }
  }
  
  public void setClipping(Region paramRegion)
  {
    if (this.handle == 0L) {
      SWT.error(44);
    }
    if ((paramRegion != null) && (paramRegion.isDisposed())) {
      SWT.error(5);
    }
    setClipping(paramRegion != null ? paramRegion.handle : 0L);
  }
  
  public void setFillRule(int paramInt)
  {
    if (this.handle == 0L) {
      SWT.error(44);
    }
    if (OS.IsWinCE) {
      return;
    }
    int i = 1;
    switch (paramInt)
    {
    case 2: 
      i = 2;
      break;
    case 1: 
      i = 1;
      break;
    default: 
      SWT.error(5);
    }
    OS.SetPolyFillMode(this.handle, i);
  }
  
  public void setFont(Font paramFont)
  {
    if (this.handle == 0L) {
      SWT.error(44);
    }
    if ((paramFont != null) && (paramFont.isDisposed())) {
      SWT.error(5);
    }
    this.data.font = (paramFont != null ? paramFont : this.data.device.systemFont);
    this.data.state &= 0xFFFFFFFB;
  }
  
  public void setForeground(Color paramColor)
  {
    if (this.handle == 0L) {
      SWT.error(44);
    }
    if (paramColor == null) {
      SWT.error(4);
    }
    if (paramColor.isDisposed()) {
      SWT.error(5);
    }
    if ((this.data.foregroundPattern == null) && (paramColor.handle == this.data.foreground)) {
      return;
    }
    this.data.foregroundPattern = null;
    this.data.foreground = paramColor.handle;
    this.data.state &= 0xFEFE;
  }
  
  public void setForegroundPattern(Pattern paramPattern)
  {
    if (this.handle == 0L) {
      SWT.error(44);
    }
    if ((paramPattern != null) && (paramPattern.isDisposed())) {
      SWT.error(5);
    }
    if ((this.data.gdipGraphics == 0L) && (paramPattern == null)) {
      return;
    }
    initGdip();
    if (this.data.foregroundPattern == paramPattern) {
      return;
    }
    this.data.foregroundPattern = paramPattern;
    this.data.state &= 0xFFFFFFFE;
  }
  
  public void setInterpolation(int paramInt)
  {
    if (this.handle == 0L) {
      SWT.error(44);
    }
    if ((this.data.gdipGraphics == 0L) && (paramInt == -1)) {
      return;
    }
    int i = 0;
    switch (paramInt)
    {
    case -1: 
      i = 0;
      break;
    case 0: 
      i = 5;
      break;
    case 1: 
      i = 1;
      break;
    case 2: 
      i = 2;
      break;
    default: 
      SWT.error(5);
    }
    initGdip();
    Gdip.Graphics_SetInterpolationMode(this.data.gdipGraphics, i);
  }
  
  public void setLineAttributes(LineAttributes paramLineAttributes)
  {
    if (this.handle == 0L) {
      SWT.error(44);
    }
    if (paramLineAttributes == null) {
      SWT.error(4);
    }
    int i = 0;
    float f1 = paramLineAttributes.width;
    if (f1 != this.data.lineWidth) {
      i |= 0x4010;
    }
    int j = paramLineAttributes.style;
    if (j != this.data.lineStyle)
    {
      i |= 0x8;
      switch (j)
      {
      case 1: 
      case 2: 
      case 3: 
      case 4: 
      case 5: 
        break;
      case 6: 
        if (paramLineAttributes.dash == null) {
          j = 1;
        }
        break;
      default: 
        SWT.error(5);
      }
    }
    int k = paramLineAttributes.join;
    if (k != this.data.lineJoin)
    {
      i |= 0x40;
      switch (k)
      {
      case 1: 
      case 2: 
      case 3: 
        break;
      default: 
        SWT.error(5);
      }
    }
    int m = paramLineAttributes.cap;
    if (m != this.data.lineCap)
    {
      i |= 0x20;
      switch (m)
      {
      case 1: 
      case 2: 
      case 3: 
        break;
      default: 
        SWT.error(5);
      }
    }
    Object localObject = paramLineAttributes.dash;
    float[] arrayOfFloat1 = this.data.lineDashes;
    if ((localObject != null) && (localObject.length > 0))
    {
      int n = (arrayOfFloat1 == null) || (arrayOfFloat1.length != localObject.length) ? 1 : 0;
      for (int i1 = 0; i1 < localObject.length; i1++)
      {
        float f4 = localObject[i1];
        if (f4 <= 0.0F) {
          SWT.error(5);
        }
        if ((n == 0) && (arrayOfFloat1[i1] != f4)) {
          n = 1;
        }
      }
      if (n != 0)
      {
        float[] arrayOfFloat2 = new float[localObject.length];
        System.arraycopy(localObject, 0, arrayOfFloat2, 0, localObject.length);
        localObject = arrayOfFloat2;
        i |= 0x8;
      }
      else
      {
        localObject = arrayOfFloat1;
      }
    }
    else if ((arrayOfFloat1 != null) && (arrayOfFloat1.length > 0))
    {
      i |= 0x8;
    }
    else
    {
      localObject = arrayOfFloat1;
    }
    float f2 = paramLineAttributes.dashOffset;
    if (f2 != this.data.lineDashesOffset) {
      i |= 0x8;
    }
    float f3 = paramLineAttributes.miterLimit;
    if (f3 != this.data.lineMiterLimit) {
      i |= 0x80;
    }
    initGdip();
    if (i == 0) {
      return;
    }
    this.data.lineWidth = f1;
    this.data.lineStyle = j;
    this.data.lineCap = m;
    this.data.lineJoin = k;
    this.data.lineDashes = ((float[])localObject);
    this.data.lineDashesOffset = f2;
    this.data.lineMiterLimit = f3;
    this.data.state &= (i ^ 0xFFFFFFFF);
  }
  
  public void setLineCap(int paramInt)
  {
    if (this.handle == 0L) {
      SWT.error(44);
    }
    if (this.data.lineCap == paramInt) {
      return;
    }
    switch (paramInt)
    {
    case 1: 
    case 2: 
    case 3: 
      break;
    default: 
      SWT.error(5);
    }
    this.data.lineCap = paramInt;
    this.data.state &= 0xFFFFFFDF;
  }
  
  public void setLineDash(int[] paramArrayOfInt)
  {
    if (this.handle == 0L) {
      SWT.error(44);
    }
    float[] arrayOfFloat = this.data.lineDashes;
    if ((paramArrayOfInt != null) && (paramArrayOfInt.length > 0))
    {
      int i = (this.data.lineStyle != 6) || (arrayOfFloat == null) || (arrayOfFloat.length != paramArrayOfInt.length) ? 1 : 0;
      for (int j = 0; j < paramArrayOfInt.length; j++)
      {
        int k = paramArrayOfInt[j];
        if (k <= 0) {
          SWT.error(5);
        }
        if ((i == 0) && (arrayOfFloat[j] != k)) {
          i = 1;
        }
      }
      if (i == 0) {
        return;
      }
      this.data.lineDashes = new float[paramArrayOfInt.length];
      for (j = 0; j < paramArrayOfInt.length; j++) {
        this.data.lineDashes[j] = paramArrayOfInt[j];
      }
      this.data.lineStyle = 6;
    }
    else
    {
      if ((this.data.lineStyle == 1) && ((arrayOfFloat == null) || (arrayOfFloat.length == 0))) {
        return;
      }
      this.data.lineDashes = null;
      this.data.lineStyle = 1;
    }
    this.data.state &= 0xFFFFFFF7;
  }
  
  public void setLineJoin(int paramInt)
  {
    if (this.handle == 0L) {
      SWT.error(44);
    }
    if (this.data.lineJoin == paramInt) {
      return;
    }
    switch (paramInt)
    {
    case 1: 
    case 2: 
    case 3: 
      break;
    default: 
      SWT.error(5);
    }
    this.data.lineJoin = paramInt;
    this.data.state &= 0xFFFFFFBF;
  }
  
  public void setLineStyle(int paramInt)
  {
    if (this.handle == 0L) {
      SWT.error(44);
    }
    if (this.data.lineStyle == paramInt) {
      return;
    }
    switch (paramInt)
    {
    case 1: 
    case 2: 
    case 3: 
    case 4: 
    case 5: 
      break;
    case 6: 
      if (this.data.lineDashes == null) {
        paramInt = 1;
      }
      break;
    default: 
      SWT.error(5);
    }
    this.data.lineStyle = paramInt;
    this.data.state &= 0xFFFFFFF7;
  }
  
  public void setLineWidth(int paramInt)
  {
    if (this.handle == 0L) {
      SWT.error(44);
    }
    if (this.data.lineWidth == paramInt) {
      return;
    }
    this.data.lineWidth = paramInt;
    this.data.state &= 0xBFEF;
  }
  
  /**
   * @deprecated
   */
  public void setXORMode(boolean paramBoolean)
  {
    if (this.handle == 0L) {
      SWT.error(44);
    }
    OS.SetROP2(this.handle, paramBoolean ? 7 : 13);
  }
  
  public void setTextAntialias(int paramInt)
  {
    if (this.handle == 0L) {
      SWT.error(44);
    }
    if ((this.data.gdipGraphics == 0L) && (paramInt == -1)) {
      return;
    }
    int i = 0;
    switch (paramInt)
    {
    case -1: 
      i = 0;
      break;
    case 0: 
      i = 1;
      break;
    case 1: 
      int[] arrayOfInt = new int[1];
      OS.SystemParametersInfo(8202, 0, arrayOfInt, 0);
      if (arrayOfInt[0] == 2) {
        i = 5;
      } else {
        i = 3;
      }
      break;
    default: 
      SWT.error(5);
    }
    initGdip();
    Gdip.Graphics_SetTextRenderingHint(this.data.gdipGraphics, i);
  }
  
  public void setTransform(Transform paramTransform)
  {
    if (this.handle == 0L) {
      SWT.error(44);
    }
    if ((paramTransform != null) && (paramTransform.isDisposed())) {
      SWT.error(5);
    }
    if ((this.data.gdipGraphics == 0L) && (paramTransform == null)) {
      return;
    }
    initGdip();
    long l = identity();
    if (paramTransform != null) {
      Gdip.Matrix_Multiply(l, paramTransform.handle, 0);
    }
    Gdip.Graphics_SetTransform(this.data.gdipGraphics, l);
    Gdip.Matrix_delete(l);
    this.data.state &= 0xBFFF;
  }
  
  public Point stringExtent(String paramString)
  {
    if (this.handle == 0L) {
      SWT.error(44);
    }
    if (paramString == null) {
      SWT.error(4);
    }
    checkGC(4);
    int i = paramString.length();
    long l = this.data.gdipGraphics;
    if (l != 0L)
    {
      localObject = new Point(0, 0);
      drawText(l, paramString, 0, 0, 0, (Point)localObject);
      return (Point)localObject;
    }
    Object localObject = new SIZE();
    if (i == 0)
    {
      OS.GetTextExtentPoint32W(this.handle, new char[] { ' ' }, 1, (SIZE)localObject);
      return new Point(0, ((SIZE)localObject).cy);
    }
    char[] arrayOfChar = new char[i];
    paramString.getChars(0, i, arrayOfChar, 0);
    OS.GetTextExtentPoint32W(this.handle, arrayOfChar, i, (SIZE)localObject);
    return new Point(((SIZE)localObject).cx, ((SIZE)localObject).cy);
  }
  
  public Point textExtent(String paramString)
  {
    return textExtent(paramString, 6);
  }
  
  public Point textExtent(String paramString, int paramInt)
  {
    if (this.handle == 0L) {
      SWT.error(44);
    }
    if (paramString == null) {
      SWT.error(4);
    }
    checkGC(4);
    long l = this.data.gdipGraphics;
    if (l != 0L)
    {
      localObject = new Point(0, 0);
      drawText(l, paramString, 0, 0, paramInt, (Point)localObject);
      return (Point)localObject;
    }
    if (paramString.length() == 0)
    {
      localObject = new SIZE();
      OS.GetTextExtentPoint32W(this.handle, new char[] { ' ' }, 1, (SIZE)localObject);
      return new Point(0, ((SIZE)localObject).cy);
    }
    Object localObject = new RECT();
    TCHAR localTCHAR = new TCHAR(getCodePage(), paramString, false);
    int i = 1024;
    if ((paramInt & 0x2) == 0) {
      i |= 0x20;
    }
    if ((paramInt & 0x4) != 0) {
      i |= 0x40;
    }
    if ((paramInt & 0x8) == 0) {
      i |= 0x800;
    }
    OS.DrawText(this.handle, localTCHAR, localTCHAR.length(), (RECT)localObject, i);
    return new Point(((RECT)localObject).right, ((RECT)localObject).bottom);
  }
  
  public String toString()
  {
    if (isDisposed()) {
      return "GC {*DISPOSED*}";
    }
    return "GC {" + this.handle + "}";
  }
  
  public static GC win32_new(Drawable paramDrawable, GCData paramGCData)
  {
    GC localGC = new GC();
    long l = paramDrawable.internal_new_GC(paramGCData);
    localGC.device = paramGCData.device;
    localGC.init(paramDrawable, paramGCData, l);
    return localGC;
  }
  
  public static GC win32_new(long paramLong, GCData paramGCData)
  {
    GC localGC = new GC();
    localGC.device = paramGCData.device;
    paramGCData.style |= 0x2000000;
    if ((!OS.IsWinCE) && (OS.WIN32_VERSION >= OS.VERSION(4, 10)))
    {
      int i = OS.GetLayout(paramLong);
      if ((i & 0x1) != 0) {
        paramGCData.style |= 0xC000000;
      }
    }
    localGC.init(null, paramGCData, paramLong);
    return localGC;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/graphics/GC.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */