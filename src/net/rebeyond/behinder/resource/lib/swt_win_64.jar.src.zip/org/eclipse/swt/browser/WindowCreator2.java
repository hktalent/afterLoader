package org.eclipse.swt.browser;

import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.internal.C;
import org.eclipse.swt.internal.mozilla.IIDStore;
import org.eclipse.swt.internal.mozilla.XPCOM;
import org.eclipse.swt.internal.mozilla.XPCOMObject;
import org.eclipse.swt.internal.mozilla.nsIBaseWindow;
import org.eclipse.swt.internal.mozilla.nsID;
import org.eclipse.swt.internal.mozilla.nsISupports;
import org.eclipse.swt.internal.mozilla.nsIURI;
import org.eclipse.swt.internal.mozilla.nsIWebBrowser;
import org.eclipse.swt.internal.mozilla.nsIWebBrowserChrome;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Shell;

class WindowCreator2
{
  XPCOMObject supports;
  XPCOMObject windowCreator;
  XPCOMObject windowCreator2;
  int refCount = 0;
  
  WindowCreator2()
  {
    createCOMInterfaces();
  }
  
  int AddRef()
  {
    this.refCount += 1;
    return this.refCount;
  }
  
  void createCOMInterfaces()
  {
    this.supports = new XPCOMObject(new int[] { 2, 0, 0 })
    {
      public long method0(long[] paramAnonymousArrayOfLong)
      {
        return WindowCreator2.this.QueryInterface(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method1(long[] paramAnonymousArrayOfLong)
      {
        return WindowCreator2.this.AddRef();
      }
      
      public long method2(long[] paramAnonymousArrayOfLong)
      {
        return WindowCreator2.this.Release();
      }
    };
    this.windowCreator = new XPCOMObject(new int[] { 2, 0, 0, 3 })
    {
      public long method0(long[] paramAnonymousArrayOfLong)
      {
        return WindowCreator2.this.QueryInterface(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method1(long[] paramAnonymousArrayOfLong)
      {
        return WindowCreator2.this.AddRef();
      }
      
      public long method2(long[] paramAnonymousArrayOfLong)
      {
        return WindowCreator2.this.Release();
      }
      
      public long method3(long[] paramAnonymousArrayOfLong)
      {
        return WindowCreator2.this.CreateChromeWindow(paramAnonymousArrayOfLong[0], (int)paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2]);
      }
    };
    this.windowCreator2 = new XPCOMObject(new int[] { 2, 0, 0, 3, 6 })
    {
      public long method0(long[] paramAnonymousArrayOfLong)
      {
        return WindowCreator2.this.QueryInterface(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method1(long[] paramAnonymousArrayOfLong)
      {
        return WindowCreator2.this.AddRef();
      }
      
      public long method2(long[] paramAnonymousArrayOfLong)
      {
        return WindowCreator2.this.Release();
      }
      
      public long method3(long[] paramAnonymousArrayOfLong)
      {
        return WindowCreator2.this.CreateChromeWindow(paramAnonymousArrayOfLong[0], (int)paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2]);
      }
      
      public long method4(long[] paramAnonymousArrayOfLong)
      {
        return WindowCreator2.this.CreateChromeWindow2(paramAnonymousArrayOfLong[0], (int)paramAnonymousArrayOfLong[1], (int)paramAnonymousArrayOfLong[2], paramAnonymousArrayOfLong[3], paramAnonymousArrayOfLong[4], paramAnonymousArrayOfLong[5]);
      }
    };
  }
  
  void disposeCOMInterfaces()
  {
    if (this.supports != null)
    {
      this.supports.dispose();
      this.supports = null;
    }
    if (this.windowCreator != null)
    {
      this.windowCreator.dispose();
      this.windowCreator = null;
    }
    if (this.windowCreator2 != null)
    {
      this.windowCreator2.dispose();
      this.windowCreator2 = null;
    }
  }
  
  long getAddress()
  {
    return this.windowCreator.getAddress();
  }
  
  int QueryInterface(long paramLong1, long paramLong2)
  {
    if ((paramLong1 == 0L) || (paramLong2 == 0L)) {
      return -2147467262;
    }
    nsID localnsID = new nsID();
    XPCOM.memmove(localnsID, paramLong1, 16);
    if (localnsID.Equals(IIDStore.GetIID(nsISupports.class)))
    {
      XPCOM.memmove(paramLong2, new long[] { this.supports.getAddress() }, C.PTR_SIZEOF);
      AddRef();
      return 0;
    }
    if (localnsID.Equals(XPCOM.NS_IWINDOWCREATOR_IID))
    {
      XPCOM.memmove(paramLong2, new long[] { this.windowCreator.getAddress() }, C.PTR_SIZEOF);
      AddRef();
      return 0;
    }
    if (localnsID.Equals(XPCOM.NS_IWINDOWCREATOR2_IID))
    {
      XPCOM.memmove(paramLong2, new long[] { this.windowCreator2.getAddress() }, C.PTR_SIZEOF);
      AddRef();
      return 0;
    }
    XPCOM.memmove(paramLong2, new long[] { 0L }, C.PTR_SIZEOF);
    return -2147467262;
  }
  
  int Release()
  {
    this.refCount -= 1;
    if (this.refCount == 0) {
      disposeCOMInterfaces();
    }
    return this.refCount;
  }
  
  int CreateChromeWindow(long paramLong1, int paramInt, long paramLong2)
  {
    return CreateChromeWindow2(paramLong1, paramInt, 0, 0L, 0L, paramLong2);
  }
  
  int CreateChromeWindow2(long paramLong1, int paramInt1, int paramInt2, long paramLong2, long paramLong3, long paramLong4)
  {
    if ((paramLong1 == 0L) && ((paramInt1 & 0x80000000) == 0)) {
      return -2147467263;
    }
    Browser localBrowser = null;
    Object localObject1;
    int j;
    final Object localObject3;
    Object localObject4;
    if (paramLong1 != 0L)
    {
      localObject1 = new nsIWebBrowserChrome(paramLong1);
      long[] arrayOfLong1 = new long[1];
      j = ((nsIWebBrowserChrome)localObject1).GetWebBrowser(arrayOfLong1);
      if (j != 0) {
        Mozilla.error(j);
      }
      if (arrayOfLong1[0] == 0L) {
        Mozilla.error(-2147467262);
      }
      localObject3 = new nsIWebBrowser(arrayOfLong1[0]);
      localObject4 = new long[1];
      j = ((nsIWebBrowser)localObject3).QueryInterface(IIDStore.GetIID(nsIBaseWindow.class), (long[])localObject4);
      if (j != 0) {
        SWT.error(j);
      }
      if (localObject4[0] == 0L) {
        Mozilla.error(-2147467262);
      }
      ((nsIWebBrowser)localObject3).Release();
      nsIBaseWindow localnsIBaseWindow = new nsIBaseWindow(localObject4[0]);
      localObject4[0] = 0L;
      long[] arrayOfLong2 = new long[1];
      j = localnsIBaseWindow.GetParentNativeWindow(arrayOfLong2);
      if (j != 0) {
        Mozilla.error(j);
      }
      if (arrayOfLong2[0] == 0L) {
        Mozilla.error(-2147467262);
      }
      localnsIBaseWindow.Release();
      localBrowser = Mozilla.findBrowser(arrayOfLong2[0]);
    }
    int i = 1;
    Object localObject2;
    if ((paramInt1 & 0x80000000) != 0)
    {
      j = 0;
      if ((paramInt1 & 0x8000) == 0) {
        j |= 0x860;
      }
      if ((paramInt1 & 0x20000000) != 0) {
        j |= 0x10000;
      }
      localObject3 = localBrowser == null ? new Shell(j) : new Shell(localBrowser.getShell(), j);
      ((Shell)localObject3).setLayout(new FillLayout());
      localObject1 = new Browser((Composite)localObject3, localBrowser == null ? 32768 : localBrowser.getStyle() & 0x8000);
      ((Browser)localObject1).addVisibilityWindowListener(new VisibilityWindowListener()
      {
        public void hide(WindowEvent paramAnonymousWindowEvent) {}
        
        public void show(WindowEvent paramAnonymousWindowEvent)
        {
          if (paramAnonymousWindowEvent.location != null) {
            localObject3.setLocation(paramAnonymousWindowEvent.location);
          }
          if (paramAnonymousWindowEvent.size != null)
          {
            Point localPoint = paramAnonymousWindowEvent.size;
            localObject3.setSize(localObject3.computeSize(localPoint.x, localPoint.y));
          }
          localObject3.open();
        }
      });
      ((Browser)localObject1).addCloseWindowListener(new CloseWindowListener()
      {
        public void close(WindowEvent paramAnonymousWindowEvent)
        {
          localObject3.close();
        }
      });
      if (paramLong2 != 0L)
      {
        localObject4 = new nsIURI(paramLong2);
        long l2 = XPCOM.nsEmbedCString_new();
        if (((nsIURI)localObject4).GetSpec(l2) == 0)
        {
          int n = XPCOM.nsEmbedCString_Length(l2);
          if (n > 0)
          {
            long l3 = XPCOM.nsEmbedCString_get(l2);
            byte[] arrayOfByte = new byte[n];
            XPCOM.memmove(arrayOfByte, l3, n);
            ((Browser)localObject1).setUrl(new String(arrayOfByte));
          }
        }
        XPCOM.nsEmbedCString_delete(l2);
      }
    }
    else
    {
      localObject2 = new WindowEvent(localBrowser);
      ((WindowEvent)localObject2).display = localBrowser.getDisplay();
      ((WindowEvent)localObject2).widget = localBrowser;
      ((WindowEvent)localObject2).required = true;
      for (int k = 0; k < localBrowser.webBrowser.openWindowListeners.length; k++) {
        localBrowser.webBrowser.openWindowListeners[k].open((WindowEvent)localObject2);
      }
      localObject1 = ((WindowEvent)localObject2).browser;
      i = (localObject1 != null) && (!((Browser)localObject1).isDisposed()) ? 1 : 0;
      if (i != 0)
      {
        String str = "win32";
        int m = (str.equals("gtk")) || (str.equals("motif")) ? 1 : 0;
        i = (m != 0) || ((((Browser)localObject1).getStyle() & 0x8000) != 0) ? 1 : 0;
      }
    }
    if (i != 0)
    {
      localObject2 = (Mozilla)((Browser)localObject1).webBrowser;
      ((Mozilla)localObject2).isChild = true;
      long l1 = ((Mozilla)localObject2).webBrowserChrome.getAddress();
      nsIWebBrowserChrome localnsIWebBrowserChrome = new nsIWebBrowserChrome(l1);
      localnsIWebBrowserChrome.SetChromeFlags(paramInt1);
      localnsIWebBrowserChrome.AddRef();
      XPCOM.memmove(paramLong4, new long[] { l1 }, C.PTR_SIZEOF);
    }
    else if (paramLong3 != 0L)
    {
      XPCOM.memmove(paramLong3, new boolean[] { true });
    }
    return i != 0 ? 0 : -2147467263;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/browser/WindowCreator2.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */