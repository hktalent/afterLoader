package org.eclipse.swt.browser;

import org.eclipse.swt.SWT;
import org.eclipse.swt.internal.C;
import org.eclipse.swt.internal.Compatibility;
import org.eclipse.swt.internal.mozilla.IIDStore;
import org.eclipse.swt.internal.mozilla.XPCOM;
import org.eclipse.swt.internal.mozilla.XPCOMObject;
import org.eclipse.swt.internal.mozilla.nsEmbedString;
import org.eclipse.swt.internal.mozilla.nsIAuthInformation;
import org.eclipse.swt.internal.mozilla.nsIChannel;
import org.eclipse.swt.internal.mozilla.nsID;
import org.eclipse.swt.internal.mozilla.nsISupports;
import org.eclipse.swt.internal.mozilla.nsIURI;
import org.eclipse.swt.widgets.Shell;

class PromptAuth2
{
  XPCOMObject supports;
  XPCOMObject promptAuth;
  int refCount = 0;
  long parent;
  
  PromptAuth2()
  {
    createCOMInterfaces();
  }
  
  int AddRef()
  {
    this.refCount += 1;
    return this.refCount;
  }
  
  void createCOMInterfaces()
  {
    this.supports = new XPCOMObject(new int[] { 2, 0, 0 })
    {
      public long method0(long[] paramAnonymousArrayOfLong)
      {
        return PromptAuth2.this.QueryInterface(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method1(long[] paramAnonymousArrayOfLong)
      {
        return PromptAuth2.this.AddRef();
      }
      
      public long method2(long[] paramAnonymousArrayOfLong)
      {
        return PromptAuth2.this.Release();
      }
    };
    this.promptAuth = new XPCOMObject(new int[] { 2, 0, 0, 4, 6 })
    {
      public long method0(long[] paramAnonymousArrayOfLong)
      {
        return PromptAuth2.this.QueryInterface(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method1(long[] paramAnonymousArrayOfLong)
      {
        return PromptAuth2.this.AddRef();
      }
      
      public long method2(long[] paramAnonymousArrayOfLong)
      {
        return PromptAuth2.this.Release();
      }
      
      public long method3(long[] paramAnonymousArrayOfLong)
      {
        return PromptAuth2.this.PromptAuth(paramAnonymousArrayOfLong[0], (int)paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2], paramAnonymousArrayOfLong[3]);
      }
      
      public long method4(long[] paramAnonymousArrayOfLong)
      {
        return PromptAuth2.this.AsyncPromptAuth(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2], (int)paramAnonymousArrayOfLong[3], paramAnonymousArrayOfLong[4], paramAnonymousArrayOfLong[5]);
      }
    };
  }
  
  void disposeCOMInterfaces()
  {
    if (this.supports != null)
    {
      this.supports.dispose();
      this.supports = null;
    }
    if (this.promptAuth != null)
    {
      this.promptAuth.dispose();
      this.promptAuth = null;
    }
  }
  
  long getAddress()
  {
    return this.promptAuth.getAddress();
  }
  
  int QueryInterface(long paramLong1, long paramLong2)
  {
    if ((paramLong1 == 0L) || (paramLong2 == 0L)) {
      return -2147467262;
    }
    nsID localnsID = new nsID();
    XPCOM.memmove(localnsID, paramLong1, 16);
    if (localnsID.Equals(IIDStore.GetIID(nsISupports.class)))
    {
      XPCOM.memmove(paramLong2, new long[] { this.supports.getAddress() }, C.PTR_SIZEOF);
      AddRef();
      return 0;
    }
    if (localnsID.Equals(XPCOM.NS_IAUTHPROMPT2_IID))
    {
      XPCOM.memmove(paramLong2, new long[] { this.promptAuth.getAddress() }, C.PTR_SIZEOF);
      AddRef();
      return 0;
    }
    XPCOM.memmove(paramLong2, new long[] { 0L }, C.PTR_SIZEOF);
    return -2147467262;
  }
  
  int Release()
  {
    this.refCount -= 1;
    if (this.refCount == 0) {
      disposeCOMInterfaces();
    }
    return this.refCount;
  }
  
  Browser getBrowser()
  {
    if (this.parent == 0L) {
      return null;
    }
    return Mozilla.getBrowser(this.parent);
  }
  
  void setParent(long paramLong)
  {
    this.parent = paramLong;
  }
  
  int PromptAuth(long paramLong1, int paramInt, long paramLong2, long paramLong3)
  {
    nsIAuthInformation localnsIAuthInformation = new nsIAuthInformation(paramLong2);
    Browser localBrowser = getBrowser();
    if (localBrowser != null)
    {
      localMozilla = (Mozilla)localBrowser.webBrowser;
      if (localMozilla.authCount++ < 3) {
        for (int i = 0; i < localMozilla.authenticationListeners.length; i++)
        {
          localObject1 = new AuthenticationEvent(localBrowser);
          ((AuthenticationEvent)localObject1).location = localMozilla.lastNavigateURL;
          localMozilla.authenticationListeners[i].authenticate((AuthenticationEvent)localObject1);
          if (!((AuthenticationEvent)localObject1).doit)
          {
            XPCOM.memmove(paramLong3, new boolean[] { false });
            return 0;
          }
          if ((((AuthenticationEvent)localObject1).user != null) && (((AuthenticationEvent)localObject1).password != null))
          {
            localObject2 = new nsEmbedString(((AuthenticationEvent)localObject1).user);
            int j = localnsIAuthInformation.SetUsername(((nsEmbedString)localObject2).getAddress());
            if (j != 0) {
              SWT.error(j);
            }
            ((nsEmbedString)localObject2).dispose();
            localObject2 = new nsEmbedString(((AuthenticationEvent)localObject1).password);
            j = localnsIAuthInformation.SetPassword(((nsEmbedString)localObject2).getAddress());
            if (j != 0) {
              SWT.error(j);
            }
            ((nsEmbedString)localObject2).dispose();
            XPCOM.memmove(paramLong3, new boolean[] { true });
            return 0;
          }
        }
      }
    }
    Mozilla localMozilla = null;
    boolean[] arrayOfBoolean1 = new boolean[1];
    Object localObject1 = new String[1];
    Object localObject2 = new String[1];
    String str1 = SWT.getMessage("SWT_Authentication_Required");
    long l1 = XPCOM.nsEmbedString_new();
    int k = localnsIAuthInformation.GetUsername(l1);
    if (k != 0) {
      SWT.error(k);
    }
    int m = XPCOM.nsEmbedString_Length(l1);
    long l2 = XPCOM.nsEmbedString_get(l1);
    char[] arrayOfChar = new char[m];
    XPCOM.memmove(arrayOfChar, l2, m * 2);
    localObject1[0] = new String(arrayOfChar);
    XPCOM.nsEmbedString_delete(l1);
    l1 = XPCOM.nsEmbedString_new();
    k = localnsIAuthInformation.GetPassword(l1);
    if (k != 0) {
      SWT.error(k);
    }
    m = XPCOM.nsEmbedString_Length(l1);
    l2 = XPCOM.nsEmbedString_get(l1);
    arrayOfChar = new char[m];
    XPCOM.memmove(arrayOfChar, l2, m * 2);
    localObject2[0] = new String(arrayOfChar);
    XPCOM.nsEmbedString_delete(l1);
    l1 = XPCOM.nsEmbedString_new();
    k = localnsIAuthInformation.GetRealm(l1);
    if (k != 0) {
      SWT.error(k);
    }
    m = XPCOM.nsEmbedString_Length(l1);
    l2 = XPCOM.nsEmbedString_get(l1);
    arrayOfChar = new char[m];
    XPCOM.memmove(arrayOfChar, l2, m * 2);
    String str2 = new String(arrayOfChar);
    XPCOM.nsEmbedString_delete(l1);
    nsIChannel localnsIChannel = new nsIChannel(paramLong1);
    long[] arrayOfLong = new long[1];
    k = localnsIChannel.GetURI(arrayOfLong);
    if (k != 0) {
      SWT.error(k);
    }
    if (arrayOfLong[0] == 0L) {
      Mozilla.error(-2147467262);
    }
    nsIURI localnsIURI = new nsIURI(arrayOfLong[0]);
    long l3 = XPCOM.nsEmbedCString_new();
    k = localnsIURI.GetHost(l3);
    if (k != 0) {
      SWT.error(k);
    }
    m = XPCOM.nsEmbedCString_Length(l3);
    l2 = XPCOM.nsEmbedCString_get(l3);
    byte[] arrayOfByte = new byte[m];
    XPCOM.memmove(arrayOfByte, l2, m);
    String str3 = new String(arrayOfByte);
    XPCOM.nsEmbedCString_delete(l3);
    localnsIURI.Release();
    String str4;
    if ((str2.length() > 0) && (str3.length() > 0)) {
      str4 = Compatibility.getMessage("SWT_Enter_Username_and_Password", new String[] { str2, str3 });
    } else {
      str4 = "";
    }
    Shell localShell = localBrowser == null ? new Shell() : localBrowser.getShell();
    PromptDialog localPromptDialog = new PromptDialog(localShell);
    boolean[] arrayOfBoolean2 = new boolean[1];
    localPromptDialog.promptUsernameAndPassword(str1, str4, localMozilla, (String[])localObject1, (String[])localObject2, arrayOfBoolean1, arrayOfBoolean2);
    XPCOM.memmove(paramLong3, arrayOfBoolean2);
    if (arrayOfBoolean2[0] != 0)
    {
      nsEmbedString localnsEmbedString = new nsEmbedString(localObject1[0]);
      k = localnsIAuthInformation.SetUsername(localnsEmbedString.getAddress());
      if (k != 0) {
        SWT.error(k);
      }
      localnsEmbedString.dispose();
      localnsEmbedString = new nsEmbedString(localObject2[0]);
      k = localnsIAuthInformation.SetPassword(localnsEmbedString.getAddress());
      if (k != 0) {
        SWT.error(k);
      }
      localnsEmbedString.dispose();
    }
    return 0;
  }
  
  int AsyncPromptAuth(long paramLong1, long paramLong2, long paramLong3, int paramInt, long paramLong4, long paramLong5)
  {
    return -2147467263;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/browser/PromptAuth2.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */