package org.eclipse.swt.internal.ole.win32;

public class IPersistStreamInit
  extends IPersist
{
  public IPersistStreamInit(long paramLong)
  {
    super(paramLong);
  }
  
  public int Load(long paramLong)
  {
    return COM.VtblCall(5, this.address, paramLong);
  }
  
  public int InitNew()
  {
    return COM.VtblCall(8, this.address);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/internal/ole/win32/IPersistStreamInit.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */