package org.eclipse.swt.internal.mozilla;

public class nsIURI
  extends nsISupports
{
  static final int LAST_METHOD_ID = nsISupports.LAST_METHOD_ID + ((IsXULRunner10()) || (IsXULRunner24()) ? 32 : 26);
  static final String NS_IURI_IID_STR = "07a22cc0-0ce5-11d3-9331-00104ba0fd40";
  static final String NS_IURI_10_IID_STR = "395fe045-7d18-4adb-a3fd-af98c8a1af11";
  
  public nsIURI(long paramLong)
  {
    super(paramLong);
  }
  
  public int GetSpec(long paramLong)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 1, getAddress(), paramLong);
  }
  
  public int GetHost(long paramLong)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 14, getAddress(), paramLong);
  }
  
  public int GetPath(long paramLong)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 18, getAddress(), paramLong);
  }
  
  static
  {
    IIDStore.RegisterIID(nsIURI.class, 0, new nsID("07a22cc0-0ce5-11d3-9331-00104ba0fd40"));
    IIDStore.RegisterIID(nsIURI.class, 5, new nsID("395fe045-7d18-4adb-a3fd-af98c8a1af11"));
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/internal/mozilla/nsIURI.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */