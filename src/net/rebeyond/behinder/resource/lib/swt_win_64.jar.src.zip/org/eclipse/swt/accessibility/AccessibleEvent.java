package org.eclipse.swt.accessibility;

import org.eclipse.swt.internal.SWTEventObject;

public class AccessibleEvent
  extends SWTEventObject
{
  public int childID;
  public String result;
  static final long serialVersionUID = 3257567304224026934L;
  
  public AccessibleEvent(Object paramObject)
  {
    super(paramObject);
  }
  
  public String toString()
  {
    return "AccessibleEvent {childID=" + this.childID + " result=" + this.result + "}";
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/accessibility/AccessibleEvent.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */