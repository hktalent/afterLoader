package org.eclipse.swt.dnd;

import org.eclipse.swt.internal.ole.win32.STGMEDIUM;
import org.eclipse.swt.internal.win32.OS;

public class HTMLTransfer
  extends ByteArrayTransfer
{
  static HTMLTransfer _instance = new HTMLTransfer();
  static final String HTML_FORMAT = "HTML Format";
  static final int HTML_FORMATID = registerType("HTML Format");
  static final String NUMBER = "00000000";
  static final String HEADER = "Version:0.9\r\nStartHTML:00000000\r\nEndHTML:00000000\r\nStartFragment:00000000\r\nEndFragment:00000000\r\n";
  static final String PREFIX = "<html><body><!--StartFragment-->";
  static final String SUFFIX = "<!--EndFragment--></body></html>";
  static final String StartFragment = "StartFragment:";
  static final String EndFragment = "EndFragment:";
  
  public static HTMLTransfer getInstance()
  {
    return _instance;
  }
  
  public void javaToNative(Object paramObject, TransferData paramTransferData)
  {
    if ((!checkHTML(paramObject)) || (!isSupportedType(paramTransferData))) {
      DND.error(2003);
    }
    String str1 = (String)paramObject;
    int i = str1.length();
    char[] arrayOfChar = new char[i + 1];
    str1.getChars(0, i, arrayOfChar, 0);
    int j = OS.WideCharToMultiByte(65001, 0, arrayOfChar, -1, null, 0, null, null);
    if (j == 0)
    {
      paramTransferData.stgmedium = new STGMEDIUM();
      paramTransferData.result = -2147221402;
      return;
    }
    int k = "Version:0.9\r\nStartHTML:00000000\r\nEndHTML:00000000\r\nStartFragment:00000000\r\nEndFragment:00000000\r\n".length();
    int m = k + "<html><body><!--StartFragment-->".length();
    int n = m + j - 1;
    int i1 = n + "<!--EndFragment--></body></html>".length();
    StringBuffer localStringBuffer = new StringBuffer("Version:0.9\r\nStartHTML:00000000\r\nEndHTML:00000000\r\nStartFragment:00000000\r\nEndFragment:00000000\r\n");
    int i2 = "00000000".length();
    int i3 = localStringBuffer.toString().indexOf("00000000");
    String str2 = Integer.toString(k);
    localStringBuffer.replace(i3 + i2 - str2.length(), i3 + i2, str2);
    i3 = localStringBuffer.toString().indexOf("00000000", i3);
    str2 = Integer.toString(i1);
    localStringBuffer.replace(i3 + i2 - str2.length(), i3 + i2, str2);
    i3 = localStringBuffer.toString().indexOf("00000000", i3);
    str2 = Integer.toString(m);
    localStringBuffer.replace(i3 + i2 - str2.length(), i3 + i2, str2);
    i3 = localStringBuffer.toString().indexOf("00000000", i3);
    str2 = Integer.toString(n);
    localStringBuffer.replace(i3 + i2 - str2.length(), i3 + i2, str2);
    localStringBuffer.append("<html><body><!--StartFragment-->");
    localStringBuffer.append(str1);
    localStringBuffer.append("<!--EndFragment--></body></html>");
    i = localStringBuffer.length();
    arrayOfChar = new char[i + 1];
    localStringBuffer.getChars(0, i, arrayOfChar, 0);
    j = OS.WideCharToMultiByte(65001, 0, arrayOfChar, -1, null, 0, null, null);
    long l = OS.GlobalAlloc(64, j);
    OS.WideCharToMultiByte(65001, 0, arrayOfChar, -1, l, j, null, null);
    paramTransferData.stgmedium = new STGMEDIUM();
    paramTransferData.stgmedium.tymed = 1;
    paramTransferData.stgmedium.unionField = l;
    paramTransferData.stgmedium.pUnkForRelease = 0L;
    paramTransferData.result = 0;
  }
  
  /* Error */
  public Object nativeToJava(TransferData paramTransferData)
  {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: invokevirtual 4	org/eclipse/swt/dnd/HTMLTransfer:isSupportedType	(Lorg/eclipse/swt/dnd/TransferData;)Z
    //   5: ifeq +12 -> 17
    //   8: aload_1
    //   9: getfield 35	org/eclipse/swt/dnd/TransferData:pIDataObject	J
    //   12: lconst_0
    //   13: lcmp
    //   14: ifne +5 -> 19
    //   17: aconst_null
    //   18: areturn
    //   19: new 36	org/eclipse/swt/internal/ole/win32/IDataObject
    //   22: dup
    //   23: aload_1
    //   24: getfield 35	org/eclipse/swt/dnd/TransferData:pIDataObject	J
    //   27: invokespecial 37	org/eclipse/swt/internal/ole/win32/IDataObject:<init>	(J)V
    //   30: astore_2
    //   31: aload_2
    //   32: invokevirtual 38	org/eclipse/swt/internal/ole/win32/IDataObject:AddRef	()I
    //   35: pop
    //   36: new 11	org/eclipse/swt/internal/ole/win32/STGMEDIUM
    //   39: dup
    //   40: invokespecial 12	org/eclipse/swt/internal/ole/win32/STGMEDIUM:<init>	()V
    //   43: astore_3
    //   44: aload_1
    //   45: getfield 39	org/eclipse/swt/dnd/TransferData:formatetc	Lorg/eclipse/swt/internal/ole/win32/FORMATETC;
    //   48: astore 4
    //   50: aload_3
    //   51: iconst_1
    //   52: putfield 32	org/eclipse/swt/internal/ole/win32/STGMEDIUM:tymed	I
    //   55: aload_1
    //   56: aload_0
    //   57: aload_2
    //   58: aload 4
    //   60: aload_3
    //   61: invokevirtual 40	org/eclipse/swt/dnd/HTMLTransfer:getData	(Lorg/eclipse/swt/internal/ole/win32/IDataObject;Lorg/eclipse/swt/internal/ole/win32/FORMATETC;Lorg/eclipse/swt/internal/ole/win32/STGMEDIUM;)I
    //   64: putfield 15	org/eclipse/swt/dnd/TransferData:result	I
    //   67: aload_2
    //   68: invokevirtual 41	org/eclipse/swt/internal/ole/win32/IDataObject:Release	()I
    //   71: pop
    //   72: aload_1
    //   73: getfield 15	org/eclipse/swt/dnd/TransferData:result	I
    //   76: ifeq +5 -> 81
    //   79: aconst_null
    //   80: areturn
    //   81: aload_3
    //   82: getfield 33	org/eclipse/swt/internal/ole/win32/STGMEDIUM:unionField	J
    //   85: lstore 5
    //   87: lload 5
    //   89: invokestatic 42	org/eclipse/swt/internal/win32/OS:GlobalLock	(J)J
    //   92: lstore 7
    //   94: lload 7
    //   96: lconst_0
    //   97: lcmp
    //   98: ifne +12 -> 110
    //   101: aconst_null
    //   102: astore 9
    //   104: jsr +363 -> 467
    //   107: aload 9
    //   109: areturn
    //   110: ldc 9
    //   112: iconst_0
    //   113: lload 7
    //   115: iconst_m1
    //   116: aconst_null
    //   117: iconst_0
    //   118: invokestatic 43	org/eclipse/swt/internal/win32/OS:MultiByteToWideChar	(IIJI[CI)I
    //   121: istore 9
    //   123: iload 9
    //   125: ifne +15 -> 140
    //   128: aconst_null
    //   129: astore 10
    //   131: jsr +318 -> 449
    //   134: jsr +333 -> 467
    //   137: aload 10
    //   139: areturn
    //   140: iload 9
    //   142: iconst_1
    //   143: isub
    //   144: newarray <illegal type>
    //   146: astore 10
    //   148: ldc 9
    //   150: iconst_0
    //   151: lload 7
    //   153: iconst_m1
    //   154: aload 10
    //   156: aload 10
    //   158: arraylength
    //   159: invokestatic 43	org/eclipse/swt/internal/win32/OS:MultiByteToWideChar	(IIJI[CI)I
    //   162: pop
    //   163: new 6	java/lang/String
    //   166: dup
    //   167: aload 10
    //   169: invokespecial 44	java/lang/String:<init>	([C)V
    //   172: astore 11
    //   174: iconst_0
    //   175: istore 12
    //   177: iconst_0
    //   178: istore 13
    //   180: aload 11
    //   182: ldc 45
    //   184: invokevirtual 23	java/lang/String:indexOf	(Ljava/lang/String;)I
    //   187: ldc 45
    //   189: invokevirtual 7	java/lang/String:length	()I
    //   192: iadd
    //   193: istore 14
    //   195: iload 14
    //   197: iconst_1
    //   198: iadd
    //   199: istore 15
    //   201: iload 15
    //   203: aload 11
    //   205: invokevirtual 7	java/lang/String:length	()I
    //   208: if_icmpge +35 -> 243
    //   211: aload 11
    //   213: iload 14
    //   215: iload 15
    //   217: invokevirtual 46	java/lang/String:substring	(II)Ljava/lang/String;
    //   220: astore 16
    //   222: aload 16
    //   224: invokestatic 47	java/lang/Integer:parseInt	(Ljava/lang/String;)I
    //   227: istore 12
    //   229: iinc 15 1
    //   232: goto +8 -> 240
    //   235: astore 17
    //   237: goto +6 -> 243
    //   240: goto -39 -> 201
    //   243: aload 11
    //   245: ldc 49
    //   247: invokevirtual 23	java/lang/String:indexOf	(Ljava/lang/String;)I
    //   250: ldc 49
    //   252: invokevirtual 7	java/lang/String:length	()I
    //   255: iadd
    //   256: istore 14
    //   258: iload 14
    //   260: iconst_1
    //   261: iadd
    //   262: istore 15
    //   264: iload 15
    //   266: aload 11
    //   268: invokevirtual 7	java/lang/String:length	()I
    //   271: if_icmpge +35 -> 306
    //   274: aload 11
    //   276: iload 14
    //   278: iload 15
    //   280: invokevirtual 46	java/lang/String:substring	(II)Ljava/lang/String;
    //   283: astore 16
    //   285: aload 16
    //   287: invokestatic 47	java/lang/Integer:parseInt	(Ljava/lang/String;)I
    //   290: istore 13
    //   292: iinc 15 1
    //   295: goto +8 -> 303
    //   298: astore 17
    //   300: goto +6 -> 306
    //   303: goto -39 -> 264
    //   306: iload 13
    //   308: iload 12
    //   310: if_icmple +13 -> 323
    //   313: iload 13
    //   315: lload 7
    //   317: invokestatic 50	org/eclipse/swt/internal/win32/OS:strlen	(J)I
    //   320: if_icmple +15 -> 335
    //   323: aconst_null
    //   324: astore 16
    //   326: jsr +123 -> 449
    //   329: jsr +138 -> 467
    //   332: aload 16
    //   334: areturn
    //   335: ldc 9
    //   337: iconst_0
    //   338: lload 7
    //   340: iload 12
    //   342: i2l
    //   343: ladd
    //   344: iload 13
    //   346: iload 12
    //   348: isub
    //   349: aload 10
    //   351: aload 10
    //   353: arraylength
    //   354: invokestatic 43	org/eclipse/swt/internal/win32/OS:MultiByteToWideChar	(IIJI[CI)I
    //   357: istore 9
    //   359: iload 9
    //   361: ifne +15 -> 376
    //   364: aconst_null
    //   365: astore 16
    //   367: jsr +82 -> 449
    //   370: jsr +97 -> 467
    //   373: aload 16
    //   375: areturn
    //   376: new 6	java/lang/String
    //   379: dup
    //   380: aload 10
    //   382: iconst_0
    //   383: iload 9
    //   385: invokespecial 51	java/lang/String:<init>	([CII)V
    //   388: astore 16
    //   390: ldc 52
    //   392: astore 17
    //   394: aload 16
    //   396: aload 17
    //   398: invokevirtual 23	java/lang/String:indexOf	(Ljava/lang/String;)I
    //   401: istore 18
    //   403: iload 18
    //   405: iconst_m1
    //   406: if_icmpeq +22 -> 428
    //   409: iload 18
    //   411: aload 17
    //   413: invokevirtual 7	java/lang/String:length	()I
    //   416: iadd
    //   417: istore 18
    //   419: aload 16
    //   421: iload 18
    //   423: invokevirtual 53	java/lang/String:substring	(I)Ljava/lang/String;
    //   426: astore 16
    //   428: aload 16
    //   430: astore 19
    //   432: jsr +17 -> 449
    //   435: jsr +32 -> 467
    //   438: aload 19
    //   440: areturn
    //   441: astore 20
    //   443: jsr +6 -> 449
    //   446: aload 20
    //   448: athrow
    //   449: astore 21
    //   451: lload 5
    //   453: invokestatic 54	org/eclipse/swt/internal/win32/OS:GlobalUnlock	(J)Z
    //   456: pop
    //   457: ret 21
    //   459: astore 22
    //   461: jsr +6 -> 467
    //   464: aload 22
    //   466: athrow
    //   467: astore 23
    //   469: lload 5
    //   471: invokestatic 55	org/eclipse/swt/internal/win32/OS:GlobalFree	(J)J
    //   474: pop2
    //   475: ret 23
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	477	0	this	HTMLTransfer
    //   0	477	1	paramTransferData	TransferData
    //   30	38	2	localIDataObject	org.eclipse.swt.internal.ole.win32.IDataObject
    //   43	39	3	localSTGMEDIUM	STGMEDIUM
    //   48	11	4	localFORMATETC	org.eclipse.swt.internal.ole.win32.FORMATETC
    //   85	385	5	l1	long
    //   92	247	7	l2	long
    //   102	6	9	localObject1	Object
    //   121	263	9	i	int
    //   129	252	10	localObject2	Object
    //   172	103	11	str1	String
    //   175	174	12	j	int
    //   178	171	13	k	int
    //   193	84	14	m	int
    //   199	94	15	n	int
    //   220	209	16	str2	String
    //   235	1	17	localNumberFormatException1	NumberFormatException
    //   298	1	17	localNumberFormatException2	NumberFormatException
    //   392	20	17	str3	String
    //   401	21	18	i1	int
    //   430	9	19	str4	String
    //   441	6	20	localObject3	Object
    //   449	1	21	localObject4	Object
    //   459	6	22	localObject5	Object
    //   467	1	23	localObject6	Object
    // Exception table:
    //   from	to	target	type
    //   222	232	235	java/lang/NumberFormatException
    //   285	295	298	java/lang/NumberFormatException
    //   110	134	441	finally
    //   140	329	441	finally
    //   335	370	441	finally
    //   376	435	441	finally
    //   441	446	441	finally
    //   87	107	459	finally
    //   110	137	459	finally
    //   140	332	459	finally
    //   335	373	459	finally
    //   376	438	459	finally
    //   441	464	459	finally
  }
  
  protected int[] getTypeIds()
  {
    return new int[] { HTML_FORMATID };
  }
  
  protected String[] getTypeNames()
  {
    return new String[] { "HTML Format" };
  }
  
  boolean checkHTML(Object paramObject)
  {
    return (paramObject != null) && ((paramObject instanceof String)) && (((String)paramObject).length() > 0);
  }
  
  protected boolean validate(Object paramObject)
  {
    return checkHTML(paramObject);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/dnd/HTMLTransfer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */