package org.eclipse.swt.graphics;

import org.eclipse.swt.SWT;
import org.eclipse.swt.internal.win32.OS;

public final class Color
  extends Resource
{
  public int handle;
  
  Color(Device paramDevice)
  {
    super(paramDevice);
  }
  
  public Color(Device paramDevice, int paramInt1, int paramInt2, int paramInt3)
  {
    super(paramDevice);
    init(paramInt1, paramInt2, paramInt3);
    init();
  }
  
  public Color(Device paramDevice, RGB paramRGB)
  {
    super(paramDevice);
    if (paramRGB == null) {
      SWT.error(4);
    }
    init(paramRGB.red, paramRGB.green, paramRGB.blue);
    init();
  }
  
  void destroy()
  {
    long l = this.device.hPalette;
    if (l != 0L)
    {
      int i = OS.GetNearestPaletteIndex(l, this.handle);
      int[] arrayOfInt = this.device.colorRefCount;
      if (arrayOfInt[i] > 0) {
        arrayOfInt[i] -= 1;
      }
    }
    this.handle = -1;
  }
  
  public boolean equals(Object paramObject)
  {
    if (paramObject == this) {
      return true;
    }
    if (!(paramObject instanceof Color)) {
      return false;
    }
    Color localColor = (Color)paramObject;
    return (this.device == localColor.device) && ((this.handle & 0xFFFFFF) == (localColor.handle & 0xFFFFFF));
  }
  
  public int getBlue()
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    return (this.handle & 0xFF0000) >> 16;
  }
  
  public int getGreen()
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    return (this.handle & 0xFF00) >> 8;
  }
  
  public int getRed()
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    return this.handle & 0xFF;
  }
  
  public RGB getRGB()
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    return new RGB(this.handle & 0xFF, (this.handle & 0xFF00) >> 8, (this.handle & 0xFF0000) >> 16);
  }
  
  public int hashCode()
  {
    return this.handle;
  }
  
  void init(int paramInt1, int paramInt2, int paramInt3)
  {
    if ((paramInt1 > 255) || (paramInt1 < 0) || (paramInt2 > 255) || (paramInt2 < 0) || (paramInt3 > 255) || (paramInt3 < 0)) {
      SWT.error(5);
    }
    this.handle = (paramInt1 & 0xFF | (paramInt2 & 0xFF) << 8 | (paramInt3 & 0xFF) << 16);
    long l = this.device.hPalette;
    if (l == 0L) {
      return;
    }
    int[] arrayOfInt = this.device.colorRefCount;
    int i = OS.GetNearestPaletteIndex(l, this.handle);
    byte[] arrayOfByte = new byte[4];
    OS.GetPaletteEntries(l, i, 1, arrayOfByte);
    if ((arrayOfByte[0] == (byte)paramInt1) && (arrayOfByte[1] == (byte)paramInt2) && (arrayOfByte[2] == (byte)paramInt3))
    {
      arrayOfInt[i] += 1;
      return;
    }
    for (int j = 0; j < arrayOfInt.length; j++) {
      if (arrayOfInt[j] == 0)
      {
        i = j;
        break;
      }
    }
    if (j == arrayOfInt.length)
    {
      this.handle = (arrayOfByte[0] & 0xFF | (arrayOfByte[1] & 0xFF) << 8 | (arrayOfByte[2] & 0xFF) << 16);
    }
    else
    {
      arrayOfByte = new byte[] { (byte)(paramInt1 & 0xFF), (byte)(paramInt2 & 0xFF), (byte)(paramInt3 & 0xFF), 0 };
      OS.SetPaletteEntries(l, i, 1, arrayOfByte);
    }
    arrayOfInt[i] += 1;
  }
  
  public boolean isDisposed()
  {
    return this.handle == -1;
  }
  
  public String toString()
  {
    if (isDisposed()) {
      return "Color {*DISPOSED*}";
    }
    return "Color {" + getRed() + ", " + getGreen() + ", " + getBlue() + "}";
  }
  
  public static Color win32_new(Device paramDevice, int paramInt)
  {
    Color localColor = new Color(paramDevice);
    localColor.handle = paramInt;
    return localColor;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/graphics/Color.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */