package org.eclipse.swt.dnd;

import org.eclipse.swt.internal.ole.win32.FORMATETC;
import org.eclipse.swt.internal.ole.win32.IDataObject;
import org.eclipse.swt.internal.ole.win32.STGMEDIUM;
import org.eclipse.swt.internal.win32.OS;

public class TextTransfer
  extends ByteArrayTransfer
{
  private static TextTransfer _instance = new TextTransfer();
  private static final String CF_UNICODETEXT = "CF_UNICODETEXT";
  private static final String CF_TEXT = "CF_TEXT";
  private static final int CF_UNICODETEXTID = 13;
  private static final int CF_TEXTID = 1;
  
  public static TextTransfer getInstance()
  {
    return _instance;
  }
  
  public void javaToNative(Object paramObject, TransferData paramTransferData)
  {
    if ((!checkText(paramObject)) || (!isSupportedType(paramTransferData))) {
      DND.error(2003);
    }
    paramTransferData.result = -2147467259;
    String str = (String)paramObject;
    int i;
    char[] arrayOfChar;
    int j;
    switch (paramTransferData.type)
    {
    case 13: 
      i = str.length();
      arrayOfChar = new char[i + 1];
      str.getChars(0, i, arrayOfChar, 0);
      j = arrayOfChar.length * 2;
      long l1 = OS.GlobalAlloc(64, j);
      OS.MoveMemory(l1, arrayOfChar, j);
      paramTransferData.stgmedium = new STGMEDIUM();
      paramTransferData.stgmedium.tymed = 1;
      paramTransferData.stgmedium.unionField = l1;
      paramTransferData.stgmedium.pUnkForRelease = 0L;
      paramTransferData.result = 0;
      break;
    case 1: 
      i = str.length();
      arrayOfChar = new char[i + 1];
      str.getChars(0, i, arrayOfChar, 0);
      j = OS.GetACP();
      int k = OS.WideCharToMultiByte(j, 0, arrayOfChar, -1, null, 0, null, null);
      if (k == 0)
      {
        paramTransferData.stgmedium = new STGMEDIUM();
        paramTransferData.result = -2147221402;
        return;
      }
      long l2 = OS.GlobalAlloc(64, k);
      OS.WideCharToMultiByte(j, 0, arrayOfChar, -1, l2, k, null, null);
      paramTransferData.stgmedium = new STGMEDIUM();
      paramTransferData.stgmedium.tymed = 1;
      paramTransferData.stgmedium.unionField = l2;
      paramTransferData.stgmedium.pUnkForRelease = 0L;
      paramTransferData.result = 0;
      break;
    }
  }
  
  public Object nativeToJava(TransferData paramTransferData)
  {
    if ((!isSupportedType(paramTransferData)) || (paramTransferData.pIDataObject == 0L)) {
      return null;
    }
    IDataObject localIDataObject = new IDataObject(paramTransferData.pIDataObject);
    localIDataObject.AddRef();
    FORMATETC localFORMATETC = paramTransferData.formatetc;
    STGMEDIUM localSTGMEDIUM = new STGMEDIUM();
    localSTGMEDIUM.tymed = 1;
    paramTransferData.result = getData(localIDataObject, localFORMATETC, localSTGMEDIUM);
    localIDataObject.Release();
    if (paramTransferData.result != 0) {
      return null;
    }
    long l1 = localSTGMEDIUM.unionField;
    try
    {
      String str;
      switch (paramTransferData.type)
      {
      case 13: 
        int i = OS.GlobalSize(l1) / 2 * 2;
        if (i == 0)
        {
          localObject1 = null;
          return localObject1;
        }
        Object localObject1 = new char[i / 2];
        long l3 = OS.GlobalLock(l1);
        if (l3 == 0L)
        {
          Object localObject3 = null;
          return localObject3;
        }
        try
        {
          OS.MoveMemory((char[])localObject1, l3, i);
          int m = localObject1.length;
          for (int n = 0; n < localObject1.length; n++) {
            if (localObject1[n] == 0)
            {
              m = n;
              break;
            }
          }
          str = new String((char[])localObject1, 0, m);
          return str;
        }
        finally
        {
          OS.GlobalUnlock(l1);
        }
      case 1: 
        long l2 = OS.GlobalLock(l1);
        if (l2 == 0L)
        {
          Object localObject2 = null;
          return localObject2;
        }
        try
        {
          int j = OS.GetACP();
          int k = OS.MultiByteToWideChar(j, 1, l2, -1, null, 0);
          if (k == 0)
          {
            localObject4 = null;
            return localObject4;
          }
          Object localObject4 = new char[k - 1];
          OS.MultiByteToWideChar(j, 1, l2, -1, (char[])localObject4, localObject4.length);
          str = new String((char[])localObject4);
          return str;
        }
        finally
        {
          OS.GlobalUnlock(l1);
        }
      }
    }
    finally
    {
      OS.GlobalFree(l1);
    }
    return null;
  }
  
  protected int[] getTypeIds()
  {
    return new int[] { 13, 1 };
  }
  
  protected String[] getTypeNames()
  {
    return new String[] { "CF_UNICODETEXT", "CF_TEXT" };
  }
  
  boolean checkText(Object paramObject)
  {
    return (paramObject != null) && ((paramObject instanceof String)) && (((String)paramObject).length() > 0);
  }
  
  protected boolean validate(Object paramObject)
  {
    return checkText(paramObject);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/dnd/TextTransfer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */