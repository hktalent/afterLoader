package org.eclipse.swt.internal.mozilla;

public class nsIPrefService
  extends nsISupports
{
  static final int LAST_METHOD_ID = nsISupports.LAST_METHOD_ID + 6;
  static final String NS_IPREFSERVICE_IID_STR = "decb9cc7-c08f-4ea5-be91-a8fc637ce2d2";
  
  public nsIPrefService(long paramLong)
  {
    super(paramLong);
  }
  
  public int SavePrefFile(long paramLong)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 4, getAddress(), paramLong);
  }
  
  public int GetBranch(byte[] paramArrayOfByte, long[] paramArrayOfLong)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 5, getAddress(), paramArrayOfByte, paramArrayOfLong);
  }
  
  static
  {
    IIDStore.RegisterIID(nsIPrefService.class, 0, new nsID("decb9cc7-c08f-4ea5-be91-a8fc637ce2d2"));
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/internal/mozilla/nsIPrefService.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */