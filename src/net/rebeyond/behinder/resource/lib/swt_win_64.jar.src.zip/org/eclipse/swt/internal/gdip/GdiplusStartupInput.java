package org.eclipse.swt.internal.gdip;

public class GdiplusStartupInput
{
  public int GdiplusVersion;
  public long DebugEventCallback;
  public boolean SuppressBackgroundThread;
  public boolean SuppressExternalCodecs;
  public static final int sizeof = ;
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/internal/gdip/GdiplusStartupInput.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */