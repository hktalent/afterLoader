package org.eclipse.swt.internal.ole.win32;

public class IPersistStorage
  extends IPersist
{
  public IPersistStorage(long paramLong)
  {
    super(paramLong);
  }
  
  public int IsDirty()
  {
    return COM.VtblCall(4, this.address);
  }
  
  public int InitNew(long paramLong)
  {
    return COM.VtblCall(5, this.address, paramLong);
  }
  
  public int Load(long paramLong)
  {
    return COM.VtblCall(6, this.address, paramLong);
  }
  
  public int Save(long paramLong, boolean paramBoolean)
  {
    return COM.VtblCall(7, this.address, paramLong, paramBoolean);
  }
  
  public int SaveCompleted(long paramLong)
  {
    return COM.VtblCall(8, this.address, paramLong);
  }
  
  public int HandsOffStorage()
  {
    return COM.VtblCall(9, this.address);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/internal/ole/win32/IPersistStorage.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */