package org.eclipse.swt.browser;

import java.io.File;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.internal.C;
import org.eclipse.swt.internal.Compatibility;
import org.eclipse.swt.internal.ole.win32.COM;
import org.eclipse.swt.internal.ole.win32.COMObject;
import org.eclipse.swt.internal.ole.win32.GUID;
import org.eclipse.swt.internal.ole.win32.IUnknown;
import org.eclipse.swt.internal.webkit.IWebDownload;
import org.eclipse.swt.internal.webkit.IWebMutableURLRequest;
import org.eclipse.swt.internal.webkit.IWebURLResponse;
import org.eclipse.swt.internal.webkit.WebKit_win32;
import org.eclipse.swt.internal.win32.OS;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Monitor;
import org.eclipse.swt.widgets.Shell;

class WebDownloadDelegate
{
  COMObject iWebDownloadDelegate;
  Browser browser;
  int refCount = 0;
  int status = -1;
  long size;
  long totalSize;
  String url;
  static final int DOWNLOAD_FINISHED = 0;
  static final int DOWNLOAD_CANCELLED = 1;
  static final int DOWNLOAD_ERROR = 3;
  
  WebDownloadDelegate(Browser paramBrowser)
  {
    createCOMInterfaces();
    this.browser = paramBrowser;
  }
  
  int AddRef()
  {
    this.refCount += 1;
    return this.refCount;
  }
  
  void createCOMInterfaces()
  {
    this.iWebDownloadDelegate = new COMObject(new int[] { 2, 0, 0, 2, 2, 2, 2, 2, 2, 2, 3, 3, 4, 1, 1 })
    {
      public long method0(long[] paramAnonymousArrayOfLong)
      {
        return WebDownloadDelegate.this.QueryInterface(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method1(long[] paramAnonymousArrayOfLong)
      {
        return WebDownloadDelegate.this.AddRef();
      }
      
      public long method2(long[] paramAnonymousArrayOfLong)
      {
        return WebDownloadDelegate.this.Release();
      }
      
      public long method3(long[] paramAnonymousArrayOfLong)
      {
        return WebDownloadDelegate.this.decideDestinationWithSuggestedFilename(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method4(long[] paramAnonymousArrayOfLong)
      {
        return -2147467263L;
      }
      
      public long method5(long[] paramAnonymousArrayOfLong)
      {
        return -2147467263L;
      }
      
      public long method6(long[] paramAnonymousArrayOfLong)
      {
        return WebDownloadDelegate.this.didFailWithError(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method7(long[] paramAnonymousArrayOfLong)
      {
        return -2147467263L;
      }
      
      public long method8(long[] paramAnonymousArrayOfLong)
      {
        return WebDownloadDelegate.this.didReceiveDataOfLength(paramAnonymousArrayOfLong[0], (int)paramAnonymousArrayOfLong[1]);
      }
      
      public long method9(long[] paramAnonymousArrayOfLong)
      {
        return WebDownloadDelegate.this.didReceiveResponse(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method10(long[] paramAnonymousArrayOfLong)
      {
        return -2147467263L;
      }
      
      public long method11(long[] paramAnonymousArrayOfLong)
      {
        return -2147467263L;
      }
      
      public long method12(long[] paramAnonymousArrayOfLong)
      {
        return WebDownloadDelegate.this.willSendRequest(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2], paramAnonymousArrayOfLong[3]);
      }
      
      public long method13(long[] paramAnonymousArrayOfLong)
      {
        return WebDownloadDelegate.this.didBegin(paramAnonymousArrayOfLong[0]);
      }
      
      public long method14(long[] paramAnonymousArrayOfLong)
      {
        return WebDownloadDelegate.this.didFinish(paramAnonymousArrayOfLong[0]);
      }
    };
  }
  
  int decideDestinationWithSuggestedFilename(long paramLong1, long paramLong2)
  {
    String str1 = WebKit.extractBSTR(paramLong2);
    FileDialog localFileDialog = new FileDialog(this.browser.getShell(), 8192);
    localFileDialog.setText(SWT.getMessage("SWT_FileDownload"));
    localFileDialog.setFileName(str1);
    localFileDialog.setOverwrite(true);
    String str2 = localFileDialog.open();
    IWebDownload localIWebDownload = new IWebDownload(paramLong1);
    localIWebDownload.setDeletesFileUponFailure(0);
    if (str2 == null)
    {
      localIWebDownload.setDestination(WebKit.createBSTR(""), 1);
      localIWebDownload.cancel();
      localIWebDownload.Release();
    }
    else
    {
      File localFile = new File(str2);
      if (localFile.exists()) {
        localFile.delete();
      }
      localIWebDownload.setDestination(WebKit.createBSTR(str2), 1);
      openDownloadWindow(localIWebDownload, str2);
    }
    return 0;
  }
  
  int didBegin(long paramLong)
  {
    new IWebDownload(paramLong).AddRef();
    this.status = -1;
    this.size = 0L;
    this.totalSize = 0L;
    this.url = null;
    return 0;
  }
  
  int didFailWithError(long paramLong1, long paramLong2)
  {
    new IWebDownload(paramLong1).Release();
    this.status = 3;
    return 0;
  }
  
  int didFinish(long paramLong)
  {
    new IWebDownload(paramLong).Release();
    this.status = 0;
    return 0;
  }
  
  int didReceiveDataOfLength(long paramLong, int paramInt)
  {
    this.size += paramInt;
    return 0;
  }
  
  int didReceiveResponse(long paramLong1, long paramLong2)
  {
    if (paramLong2 != 0L)
    {
      IWebURLResponse localIWebURLResponse = new IWebURLResponse(paramLong2);
      long[] arrayOfLong1 = new long[1];
      int i = localIWebURLResponse.expectedContentLength(arrayOfLong1);
      if (i == 0) {
        this.totalSize = arrayOfLong1[0];
      }
      long[] arrayOfLong2 = new long[1];
      i = localIWebURLResponse.URL(arrayOfLong2);
      if ((i == 0) && (arrayOfLong2[0] != 0L))
      {
        this.url = WebKit.extractBSTR(arrayOfLong2[0]);
        COM.SysFreeString(arrayOfLong2[0]);
      }
    }
    return 0;
  }
  
  void disposeCOMInterfaces()
  {
    if (this.iWebDownloadDelegate != null)
    {
      this.iWebDownloadDelegate.dispose();
      this.iWebDownloadDelegate = null;
    }
  }
  
  long getAddress()
  {
    return this.iWebDownloadDelegate.getAddress();
  }
  
  void openDownloadWindow(final IWebDownload paramIWebDownload, String paramString)
  {
    final Shell localShell = new Shell();
    localShell.setText(Compatibility.getMessage("SWT_FileDownload"));
    GridLayout localGridLayout = new GridLayout();
    localGridLayout.marginHeight = 15;
    localGridLayout.marginWidth = 15;
    localGridLayout.verticalSpacing = 20;
    localShell.setLayout(localGridLayout);
    Label localLabel1 = new Label(localShell, 64);
    localLabel1.setText(Compatibility.getMessage("SWT_Download_Location", new Object[] { paramString, this.url }));
    GridData localGridData = new GridData();
    Monitor localMonitor = this.browser.getMonitor();
    int i = localMonitor.getBounds().width / 2;
    int j = localLabel1.computeSize(-1, -1).x;
    localGridData.widthHint = Math.min(j, i);
    localGridData.horizontalAlignment = 4;
    localGridData.grabExcessHorizontalSpace = true;
    localLabel1.setLayoutData(localGridData);
    final Label localLabel2 = new Label(localShell, 0);
    localLabel2.setText(Compatibility.getMessage("SWT_Download_Started"));
    localGridData = new GridData(1808);
    localLabel2.setLayoutData(localGridData);
    final Button localButton = new Button(localShell, 8);
    localButton.setText(Compatibility.getMessage("SWT_Cancel"));
    localGridData = new GridData();
    localGridData.horizontalAlignment = 2;
    localButton.setLayoutData(localGridData);
    final Listener local2 = new Listener()
    {
      public void handleEvent(Event paramAnonymousEvent)
      {
        paramIWebDownload.cancel();
        WebDownloadDelegate.this.status = 1;
        paramIWebDownload.Release();
      }
    };
    localButton.addListener(13, local2);
    final Display localDisplay = this.browser.getDisplay();
    localDisplay.timerExec(500, new Runnable()
    {
      public void run()
      {
        if ((localShell.isDisposed()) || (WebDownloadDelegate.this.status == 0) || (WebDownloadDelegate.this.status == 1))
        {
          localShell.dispose();
          return;
        }
        if (WebDownloadDelegate.this.status == 3)
        {
          localLabel2.setText(Compatibility.getMessage("SWT_Download_Error"));
          localButton.removeListener(13, local2);
          localButton.addListener(13, new Listener()
          {
            public void handleEvent(Event paramAnonymous2Event)
            {
              WebDownloadDelegate.3.this.val$shell.dispose();
            }
          });
          return;
        }
        long l1 = WebDownloadDelegate.this.size / 1024L;
        long l2 = WebDownloadDelegate.this.totalSize / 1024L;
        String str = Compatibility.getMessage("SWT_Download_Status", new Object[] { new Long(l1), new Long(l2) });
        localLabel2.setText(str);
        localDisplay.timerExec(500, this);
      }
    });
    localShell.pack();
    localShell.open();
  }
  
  int QueryInterface(long paramLong1, long paramLong2)
  {
    if ((paramLong1 == 0L) || (paramLong2 == 0L)) {
      return -2147024809;
    }
    GUID localGUID = new GUID();
    COM.MoveMemory(localGUID, paramLong1, GUID.sizeof);
    if (COM.IsEqualGUID(localGUID, COM.IIDIUnknown))
    {
      COM.MoveMemory(paramLong2, new long[] { this.iWebDownloadDelegate.getAddress() }, OS.PTR_SIZEOF);
      new IUnknown(this.iWebDownloadDelegate.getAddress()).AddRef();
      return 0;
    }
    if (COM.IsEqualGUID(localGUID, WebKit_win32.IID_IWebDownloadDelegate))
    {
      COM.MoveMemory(paramLong2, new long[] { this.iWebDownloadDelegate.getAddress() }, OS.PTR_SIZEOF);
      new IUnknown(this.iWebDownloadDelegate.getAddress()).AddRef();
      return 0;
    }
    COM.MoveMemory(paramLong2, new long[] { 0L }, OS.PTR_SIZEOF);
    return -2147467262;
  }
  
  int Release()
  {
    this.refCount -= 1;
    if (this.refCount == 0) {
      disposeCOMInterfaces();
    }
    return this.refCount;
  }
  
  int willSendRequest(long paramLong1, long paramLong2, long paramLong3, long paramLong4)
  {
    IWebMutableURLRequest localIWebMutableURLRequest = new IWebMutableURLRequest(paramLong2);
    localIWebMutableURLRequest.AddRef();
    OS.MoveMemory(paramLong4, new long[] { paramLong2 }, C.PTR_SIZEOF);
    return 0;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/browser/WebDownloadDelegate.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */