package org.eclipse.swt.internal.mozilla;

public class nsICookieService
  extends nsISupports
{
  static final int LAST_METHOD_ID = nsISupports.LAST_METHOD_ID + 5;
  static final String NS_ICOOKIESERVICE_IID_STR = "011c3190-1434-11d6-a618-0010a401eb10";
  static final String NS_ICOOKIESERVICE_1_9_IID_STR = "2aaa897a-293c-4d2b-a657-8c9b7136996d";
  
  public nsICookieService(long paramLong)
  {
    super(paramLong);
  }
  
  public int GetCookieString(long paramLong1, long paramLong2, long[] paramArrayOfLong)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 1, getAddress(), paramLong1, paramLong2, paramArrayOfLong);
  }
  
  public int SetCookieString(long paramLong1, long paramLong2, byte[] paramArrayOfByte, long paramLong3)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 3, getAddress(), paramLong1, paramLong2, paramArrayOfByte, paramLong3);
  }
  
  static
  {
    IIDStore.RegisterIID(nsICookieService.class, 0, new nsID("011c3190-1434-11d6-a618-0010a401eb10"));
    IIDStore.RegisterIID(nsICookieService.class, 2, new nsID("2aaa897a-293c-4d2b-a657-8c9b7136996d"));
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/internal/mozilla/nsICookieService.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */