package org.eclipse.swt.internal.mozilla;

public class nsIJSContextStack
  extends nsISupports
{
  static final int LAST_METHOD_ID = nsISupports.LAST_METHOD_ID + 4;
  static final String NS_IJSCONTEXTSTACK_IID_STR = "c67d8270-3189-11d3-9885-006008962422";
  
  public nsIJSContextStack(long paramLong)
  {
    super(paramLong);
  }
  
  public int Pop(long[] paramArrayOfLong)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 3, getAddress(), paramArrayOfLong);
  }
  
  public int Push(long paramLong)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 4, getAddress(), paramLong);
  }
  
  static
  {
    IIDStore.RegisterIID(nsIJSContextStack.class, 0, new nsID("c67d8270-3189-11d3-9885-006008962422"));
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/internal/mozilla/nsIJSContextStack.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */