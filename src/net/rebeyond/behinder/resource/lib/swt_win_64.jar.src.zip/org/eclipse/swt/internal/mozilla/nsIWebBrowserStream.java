package org.eclipse.swt.internal.mozilla;

public class nsIWebBrowserStream
  extends nsISupports
{
  static final int LAST_METHOD_ID = nsISupports.LAST_METHOD_ID + 3;
  static final String NS_IWEBBROWSERSTREAM_IID_STR = "86d02f0e-219b-4cfc-9c88-bd98d2cce0b8";
  
  public nsIWebBrowserStream(long paramLong)
  {
    super(paramLong);
  }
  
  public int OpenStream(long paramLong1, long paramLong2)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 1, getAddress(), paramLong1, paramLong2);
  }
  
  public int AppendToStream(long paramLong, int paramInt)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 2, getAddress(), paramLong, paramInt);
  }
  
  public int CloseStream()
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 3, getAddress());
  }
  
  static
  {
    IIDStore.RegisterIID(nsIWebBrowserStream.class, 0, new nsID("86d02f0e-219b-4cfc-9c88-bd98d2cce0b8"));
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/internal/mozilla/nsIWebBrowserStream.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */