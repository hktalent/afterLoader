package org.eclipse.swt.internal.ole.win32;

public class IAccessible
  extends IDispatch
{
  public IAccessible(long paramLong)
  {
    super(paramLong);
  }
  
  public int get_accParent(long paramLong)
  {
    return COM.VtblCall(7, this.address, paramLong);
  }
  
  public int get_accChildCount(long paramLong)
  {
    return COM.VtblCall(8, this.address, paramLong);
  }
  
  public int get_accChild(long paramLong1, long paramLong2)
  {
    return COM.VtblCall_VARIANTP(9, this.address, paramLong1, paramLong2);
  }
  
  public int get_accName(long paramLong1, long paramLong2)
  {
    return COM.VtblCall_VARIANTP(10, this.address, paramLong1, paramLong2);
  }
  
  public int get_accValue(long paramLong1, long paramLong2)
  {
    return COM.VtblCall_VARIANTP(11, this.address, paramLong1, paramLong2);
  }
  
  public int get_accDescription(long paramLong1, long paramLong2)
  {
    return COM.VtblCall_VARIANTP(12, this.address, paramLong1, paramLong2);
  }
  
  public int get_accRole(long paramLong1, long paramLong2)
  {
    return COM.VtblCall_VARIANTP(13, this.address, paramLong1, paramLong2);
  }
  
  public int get_accState(long paramLong1, long paramLong2)
  {
    return COM.VtblCall_VARIANTP(14, this.address, paramLong1, paramLong2);
  }
  
  public int get_accHelp(long paramLong1, long paramLong2)
  {
    return COM.VtblCall_VARIANTP(15, this.address, paramLong1, paramLong2);
  }
  
  public int get_accHelpTopic(long paramLong1, long paramLong2, long paramLong3)
  {
    return COM.VtblCall_PVARIANTP(16, this.address, paramLong1, paramLong2, paramLong3);
  }
  
  public int get_accKeyboardShortcut(long paramLong1, long paramLong2)
  {
    return COM.VtblCall_VARIANTP(17, this.address, paramLong1, paramLong2);
  }
  
  public int get_accFocus(long paramLong)
  {
    return COM.VtblCall(18, this.address, paramLong);
  }
  
  public int get_accSelection(long paramLong)
  {
    return COM.VtblCall(19, this.address, paramLong);
  }
  
  public int get_accDefaultAction(long paramLong1, long paramLong2)
  {
    return COM.VtblCall_VARIANTP(20, this.address, paramLong1, paramLong2);
  }
  
  public int accSelect(int paramInt, long paramLong)
  {
    return COM.VtblCall_IVARIANT(21, this.address, paramInt, paramLong);
  }
  
  public int accLocation(long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5)
  {
    return COM.VtblCall_PPPPVARIANT(22, this.address, paramLong1, paramLong2, paramLong3, paramLong4, paramLong5);
  }
  
  public int accNavigate(int paramInt, long paramLong1, long paramLong2)
  {
    return COM.VtblCall_IVARIANTP(23, this.address, paramInt, paramLong1, paramLong2);
  }
  
  public int accHitTest(int paramInt1, int paramInt2, long paramLong)
  {
    return COM.VtblCall(24, this.address, paramInt1, paramInt2, paramLong);
  }
  
  public int accDoDefaultAction(long paramLong)
  {
    return COM.VtblCall_VARIANT(25, this.address, paramLong);
  }
  
  public int put_accName(long paramLong1, long paramLong2)
  {
    return COM.VtblCall_VARIANTP(26, this.address, paramLong1, paramLong2);
  }
  
  public int put_accValue(long paramLong1, long paramLong2)
  {
    return COM.VtblCall_VARIANTP(27, this.address, paramLong1, paramLong2);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/internal/ole/win32/IAccessible.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */