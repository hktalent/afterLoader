package org.eclipse.swt.dnd;

import org.eclipse.swt.internal.ole.win32.FORMATETC;
import org.eclipse.swt.internal.ole.win32.IDataObject;
import org.eclipse.swt.internal.ole.win32.STGMEDIUM;
import org.eclipse.swt.internal.win32.OS;

public abstract class ByteArrayTransfer
  extends Transfer
{
  public TransferData[] getSupportedTypes()
  {
    int[] arrayOfInt = getTypeIds();
    TransferData[] arrayOfTransferData = new TransferData[arrayOfInt.length];
    for (int i = 0; i < arrayOfInt.length; i++)
    {
      arrayOfTransferData[i] = new TransferData();
      arrayOfTransferData[i].type = arrayOfInt[i];
      arrayOfTransferData[i].formatetc = new FORMATETC();
      arrayOfTransferData[i].formatetc.cfFormat = arrayOfInt[i];
      arrayOfTransferData[i].formatetc.dwAspect = 1;
      arrayOfTransferData[i].formatetc.lindex = -1;
      arrayOfTransferData[i].formatetc.tymed = 1;
    }
    return arrayOfTransferData;
  }
  
  public boolean isSupportedType(TransferData paramTransferData)
  {
    if (paramTransferData == null) {
      return false;
    }
    int[] arrayOfInt = getTypeIds();
    for (int i = 0; i < arrayOfInt.length; i++)
    {
      FORMATETC localFORMATETC = paramTransferData.formatetc;
      if ((localFORMATETC.cfFormat == arrayOfInt[i]) && ((localFORMATETC.dwAspect & 0x1) == 1) && ((localFORMATETC.tymed & 0x1) == 1)) {
        return true;
      }
    }
    return false;
  }
  
  protected void javaToNative(Object paramObject, TransferData paramTransferData)
  {
    if ((!checkByteArray(paramObject)) || (!isSupportedType(paramTransferData))) {
      DND.error(2003);
    }
    byte[] arrayOfByte = (byte[])paramObject;
    int i = arrayOfByte.length;
    long l = OS.GlobalAlloc(64, i);
    OS.MoveMemory(l, arrayOfByte, i);
    paramTransferData.stgmedium = new STGMEDIUM();
    paramTransferData.stgmedium.tymed = 1;
    paramTransferData.stgmedium.unionField = l;
    paramTransferData.stgmedium.pUnkForRelease = 0L;
    paramTransferData.result = 0;
  }
  
  protected Object nativeToJava(TransferData paramTransferData)
  {
    if ((!isSupportedType(paramTransferData)) || (paramTransferData.pIDataObject == 0L)) {
      return null;
    }
    IDataObject localIDataObject = new IDataObject(paramTransferData.pIDataObject);
    localIDataObject.AddRef();
    FORMATETC localFORMATETC = paramTransferData.formatetc;
    STGMEDIUM localSTGMEDIUM = new STGMEDIUM();
    localSTGMEDIUM.tymed = 1;
    paramTransferData.result = getData(localIDataObject, localFORMATETC, localSTGMEDIUM);
    localIDataObject.Release();
    if (paramTransferData.result != 0) {
      return null;
    }
    long l1 = localSTGMEDIUM.unionField;
    int i = OS.GlobalSize(l1);
    byte[] arrayOfByte = new byte[i];
    long l2 = OS.GlobalLock(l1);
    OS.MoveMemory(arrayOfByte, l2, i);
    OS.GlobalUnlock(l1);
    OS.GlobalFree(l1);
    return arrayOfByte;
  }
  
  boolean checkByteArray(Object paramObject)
  {
    return (paramObject != null) && ((paramObject instanceof byte[])) && (((byte[])paramObject).length > 0);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/dnd/ByteArrayTransfer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */