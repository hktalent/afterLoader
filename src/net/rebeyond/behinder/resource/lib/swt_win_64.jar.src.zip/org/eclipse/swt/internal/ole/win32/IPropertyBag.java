package org.eclipse.swt.internal.ole.win32;

public class IPropertyBag
  extends IUnknown
{
  public IPropertyBag(long paramLong)
  {
    super(paramLong);
  }
  
  public int Read(long paramLong1, long paramLong2, long[] paramArrayOfLong)
  {
    return COM.VtblCall(3, getAddress(), paramLong1, paramLong2, paramArrayOfLong);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/internal/ole/win32/IPropertyBag.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */