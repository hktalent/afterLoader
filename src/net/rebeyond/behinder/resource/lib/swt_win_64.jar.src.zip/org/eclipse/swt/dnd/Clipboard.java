package org.eclipse.swt.dnd;

import org.eclipse.swt.internal.ole.win32.COM;
import org.eclipse.swt.internal.ole.win32.COMObject;
import org.eclipse.swt.internal.ole.win32.FORMATETC;
import org.eclipse.swt.internal.ole.win32.GUID;
import org.eclipse.swt.internal.ole.win32.IDataObject;
import org.eclipse.swt.internal.ole.win32.IEnumFORMATETC;
import org.eclipse.swt.internal.ole.win32.STGMEDIUM;
import org.eclipse.swt.internal.win32.MSG;
import org.eclipse.swt.internal.win32.OS;
import org.eclipse.swt.internal.win32.TCHAR;
import org.eclipse.swt.widgets.Display;

public class Clipboard
{
  private static final int RETRY_LIMIT = 10;
  private Display display;
  private COMObject iDataObject;
  private int refCount;
  private Transfer[] transferAgents = new Transfer[0];
  private Object[] data = new Object[0];
  private int CFSTR_PREFERREDDROPEFFECT;
  
  public Clipboard(Display paramDisplay)
  {
    checkSubclass();
    if (paramDisplay == null)
    {
      paramDisplay = Display.getCurrent();
      if (paramDisplay == null) {
        paramDisplay = Display.getDefault();
      }
    }
    if (paramDisplay.getThread() != Thread.currentThread()) {
      DND.error(22);
    }
    this.display = paramDisplay;
    TCHAR localTCHAR = new TCHAR(0, "Preferred DropEffect", true);
    this.CFSTR_PREFERREDDROPEFFECT = OS.RegisterClipboardFormat(localTCHAR);
    createCOMInterfaces();
    AddRef();
  }
  
  protected void checkSubclass()
  {
    String str1 = getClass().getName();
    String str2 = Clipboard.class.getName();
    if (!str2.equals(str1)) {
      DND.error(43);
    }
  }
  
  protected void checkWidget()
  {
    Display localDisplay = this.display;
    if (localDisplay == null) {
      DND.error(24);
    }
    if (localDisplay.getThread() != Thread.currentThread()) {
      DND.error(22);
    }
    if (localDisplay.isDisposed()) {
      DND.error(24);
    }
  }
  
  public void clearContents()
  {
    clearContents(1);
  }
  
  public void clearContents(int paramInt)
  {
    checkWidget();
    if (((paramInt & 0x1) != 0) && (COM.OleIsCurrentClipboard(this.iDataObject.getAddress()) == 0)) {
      COM.OleSetClipboard(0L);
    }
  }
  
  public void dispose()
  {
    if (isDisposed()) {
      return;
    }
    if (this.display.getThread() != Thread.currentThread()) {
      DND.error(22);
    }
    if (COM.OleIsCurrentClipboard(this.iDataObject.getAddress()) == 0) {
      COM.OleFlushClipboard();
    }
    Release();
    this.display = null;
  }
  
  public Object getContents(Transfer paramTransfer)
  {
    return getContents(paramTransfer, 1);
  }
  
  public Object getContents(Transfer paramTransfer, int paramInt)
  {
    checkWidget();
    if (paramTransfer == null) {
      DND.error(4);
    }
    if ((paramInt & 0x1) == 0) {
      return null;
    }
    long[] arrayOfLong = new long[1];
    int i = 0;
    for (int j = COM.OleGetClipboard(arrayOfLong); (j != 0) && (i++ < 10); j = COM.OleGetClipboard(arrayOfLong))
    {
      try
      {
        Thread.sleep(50L);
      }
      catch (Throwable localThrowable) {}
      localObject1 = new MSG();
      OS.PeekMessage((MSG)localObject1, 0L, 0, 0, 2);
    }
    if (j != 0) {
      return null;
    }
    Object localObject1 = new IDataObject(arrayOfLong[0]);
    try
    {
      TransferData[] arrayOfTransferData = paramTransfer.getSupportedTypes();
      for (int k = 0; k < arrayOfTransferData.length; k++) {
        if (((IDataObject)localObject1).QueryGetData(arrayOfTransferData[k].formatetc) == 0)
        {
          TransferData localTransferData = arrayOfTransferData[k];
          localTransferData.pIDataObject = arrayOfLong[0];
          Object localObject2 = paramTransfer.nativeToJava(localTransferData);
          return localObject2;
        }
      }
    }
    finally
    {
      ((IDataObject)localObject1).Release();
    }
    return null;
  }
  
  public boolean isDisposed()
  {
    return this.display == null;
  }
  
  public void setContents(Object[] paramArrayOfObject, Transfer[] paramArrayOfTransfer)
  {
    setContents(paramArrayOfObject, paramArrayOfTransfer, 1);
  }
  
  public void setContents(Object[] paramArrayOfObject, Transfer[] paramArrayOfTransfer, int paramInt)
  {
    checkWidget();
    if ((paramArrayOfObject == null) || (paramArrayOfTransfer == null) || (paramArrayOfObject.length != paramArrayOfTransfer.length) || (paramArrayOfObject.length == 0)) {
      DND.error(5);
    }
    for (int i = 0; i < paramArrayOfObject.length; i++) {
      if ((paramArrayOfObject[i] == null) || (paramArrayOfTransfer[i] == null) || (!paramArrayOfTransfer[i].validate(paramArrayOfObject[i]))) {
        DND.error(5);
      }
    }
    if ((paramInt & 0x1) == 0) {
      return;
    }
    this.data = paramArrayOfObject;
    this.transferAgents = paramArrayOfTransfer;
    i = COM.OleSetClipboard(this.iDataObject.getAddress());
    int j = 0;
    while ((i != 0) && (j++ < 10))
    {
      try
      {
        Thread.sleep(50L);
      }
      catch (Throwable localThrowable) {}
      MSG localMSG = new MSG();
      OS.PeekMessage(localMSG, 0L, 0, 0, 2);
      i = COM.OleSetClipboard(this.iDataObject.getAddress());
    }
    if (i != 0) {
      DND.error(2002);
    }
  }
  
  private int AddRef()
  {
    this.refCount += 1;
    return this.refCount;
  }
  
  private void createCOMInterfaces()
  {
    this.iDataObject = new COMObject(new int[] { 2, 0, 0, 2, 2, 1, 2, 3, 2, 4, 1, 1 })
    {
      public long method0(long[] paramAnonymousArrayOfLong)
      {
        return Clipboard.this.QueryInterface(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method1(long[] paramAnonymousArrayOfLong)
      {
        return Clipboard.this.AddRef();
      }
      
      public long method2(long[] paramAnonymousArrayOfLong)
      {
        return Clipboard.this.Release();
      }
      
      public long method3(long[] paramAnonymousArrayOfLong)
      {
        return Clipboard.this.GetData(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method5(long[] paramAnonymousArrayOfLong)
      {
        return Clipboard.this.QueryGetData(paramAnonymousArrayOfLong[0]);
      }
      
      public long method8(long[] paramAnonymousArrayOfLong)
      {
        return Clipboard.this.EnumFormatEtc((int)paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
    };
  }
  
  private void disposeCOMInterfaces()
  {
    if (this.iDataObject != null) {
      this.iDataObject.dispose();
    }
    this.iDataObject = null;
  }
  
  private int EnumFormatEtc(int paramInt, long paramLong)
  {
    if (paramInt == 2) {
      return -2147467263;
    }
    Object localObject1 = new TransferData[0];
    for (int i = 0; i < this.transferAgents.length; i++)
    {
      localObject2 = this.transferAgents[i].getSupportedTypes();
      TransferData[] arrayOfTransferData = new TransferData[localObject1.length + localObject2.length];
      System.arraycopy(localObject1, 0, arrayOfTransferData, 0, localObject1.length);
      System.arraycopy(localObject2, 0, arrayOfTransferData, localObject1.length, localObject2.length);
      localObject1 = arrayOfTransferData;
    }
    OleEnumFORMATETC localOleEnumFORMATETC = new OleEnumFORMATETC();
    localOleEnumFORMATETC.AddRef();
    Object localObject2 = new FORMATETC[localObject1.length + 1];
    for (int j = 0; j < localObject1.length; j++) {
      localObject2[j] = localObject1[j].formatetc;
    }
    FORMATETC localFORMATETC = new FORMATETC();
    localFORMATETC.cfFormat = this.CFSTR_PREFERREDDROPEFFECT;
    localFORMATETC.dwAspect = 1;
    localFORMATETC.lindex = -1;
    localFORMATETC.tymed = 1;
    localObject2[(localObject2.length - 1)] = localFORMATETC;
    localOleEnumFORMATETC.setFormats((FORMATETC[])localObject2);
    OS.MoveMemory(paramLong, new long[] { localOleEnumFORMATETC.getAddress() }, OS.PTR_SIZEOF);
    return 0;
  }
  
  private int GetData(long paramLong1, long paramLong2)
  {
    if ((paramLong1 == 0L) || (paramLong2 == 0L)) {
      return -2147024809;
    }
    if (QueryGetData(paramLong1) != 0) {
      return -2147221404;
    }
    TransferData localTransferData = new TransferData();
    localTransferData.formatetc = new FORMATETC();
    COM.MoveMemory(localTransferData.formatetc, paramLong1, FORMATETC.sizeof);
    localTransferData.type = localTransferData.formatetc.cfFormat;
    localTransferData.stgmedium = new STGMEDIUM();
    localTransferData.result = -2147467259;
    if (localTransferData.type == this.CFSTR_PREFERREDDROPEFFECT)
    {
      STGMEDIUM localSTGMEDIUM = new STGMEDIUM();
      localSTGMEDIUM.tymed = 1;
      localSTGMEDIUM.unionField = OS.GlobalAlloc(64, 4);
      OS.MoveMemory(localSTGMEDIUM.unionField, new int[] { 1 }, 4);
      localSTGMEDIUM.pUnkForRelease = 0L;
      COM.MoveMemory(paramLong2, localSTGMEDIUM, STGMEDIUM.sizeof);
      return 0;
    }
    int i = -1;
    for (int j = 0; j < this.transferAgents.length; j++) {
      if (this.transferAgents[j].isSupportedType(localTransferData))
      {
        i = j;
        break;
      }
    }
    if (i == -1) {
      return -2147221404;
    }
    this.transferAgents[i].javaToNative(this.data[i], localTransferData);
    COM.MoveMemory(paramLong2, localTransferData.stgmedium, STGMEDIUM.sizeof);
    return localTransferData.result;
  }
  
  private int QueryGetData(long paramLong)
  {
    if (this.transferAgents == null) {
      return -2147467259;
    }
    TransferData localTransferData = new TransferData();
    localTransferData.formatetc = new FORMATETC();
    COM.MoveMemory(localTransferData.formatetc, paramLong, FORMATETC.sizeof);
    localTransferData.type = localTransferData.formatetc.cfFormat;
    if (localTransferData.type == this.CFSTR_PREFERREDDROPEFFECT) {
      return 0;
    }
    for (int i = 0; i < this.transferAgents.length; i++) {
      if (this.transferAgents[i].isSupportedType(localTransferData)) {
        return 0;
      }
    }
    return -2147221404;
  }
  
  private int QueryInterface(long paramLong1, long paramLong2)
  {
    if ((paramLong1 == 0L) || (paramLong2 == 0L)) {
      return -2147024809;
    }
    GUID localGUID = new GUID();
    COM.MoveMemory(localGUID, paramLong1, GUID.sizeof);
    if ((COM.IsEqualGUID(localGUID, COM.IIDIUnknown)) || (COM.IsEqualGUID(localGUID, COM.IIDIDataObject)))
    {
      OS.MoveMemory(paramLong2, new long[] { this.iDataObject.getAddress() }, OS.PTR_SIZEOF);
      AddRef();
      return 0;
    }
    OS.MoveMemory(paramLong2, new long[] { 0L }, OS.PTR_SIZEOF);
    return -2147467262;
  }
  
  private int Release()
  {
    this.refCount -= 1;
    if (this.refCount == 0)
    {
      this.data = new Object[0];
      this.transferAgents = new Transfer[0];
      disposeCOMInterfaces();
      if (COM.FreeUnusedLibraries) {
        COM.CoFreeUnusedLibraries();
      }
    }
    return this.refCount;
  }
  
  public TransferData[] getAvailableTypes()
  {
    return getAvailableTypes(1);
  }
  
  public TransferData[] getAvailableTypes(int paramInt)
  {
    checkWidget();
    if ((paramInt & 0x1) == 0) {
      return new TransferData[0];
    }
    FORMATETC[] arrayOfFORMATETC = _getAvailableTypes();
    TransferData[] arrayOfTransferData = new TransferData[arrayOfFORMATETC.length];
    for (int i = 0; i < arrayOfFORMATETC.length; i++)
    {
      arrayOfTransferData[i] = new TransferData();
      arrayOfTransferData[i].type = arrayOfFORMATETC[i].cfFormat;
      arrayOfTransferData[i].formatetc = arrayOfFORMATETC[i];
    }
    return arrayOfTransferData;
  }
  
  public String[] getAvailableTypeNames()
  {
    checkWidget();
    FORMATETC[] arrayOfFORMATETC = _getAvailableTypes();
    String[] arrayOfString = new String[arrayOfFORMATETC.length];
    int i = 128;
    for (int j = 0; j < arrayOfFORMATETC.length; j++)
    {
      TCHAR localTCHAR = new TCHAR(0, i);
      int k = OS.GetClipboardFormatName(arrayOfFORMATETC[j].cfFormat, localTCHAR, i);
      if (k != 0) {
        arrayOfString[j] = localTCHAR.toString(0, k);
      } else {
        switch (arrayOfFORMATETC[j].cfFormat)
        {
        case 15: 
          arrayOfString[j] = "CF_HDROP";
          break;
        case 1: 
          arrayOfString[j] = "CF_TEXT";
          break;
        case 2: 
          arrayOfString[j] = "CF_BITMAP";
          break;
        case 3: 
          arrayOfString[j] = "CF_METAFILEPICT";
          break;
        case 4: 
          arrayOfString[j] = "CF_SYLK";
          break;
        case 5: 
          arrayOfString[j] = "CF_DIF";
          break;
        case 6: 
          arrayOfString[j] = "CF_TIFF";
          break;
        case 7: 
          arrayOfString[j] = "CF_OEMTEXT";
          break;
        case 8: 
          arrayOfString[j] = "CF_DIB";
          break;
        case 9: 
          arrayOfString[j] = "CF_PALETTE";
          break;
        case 10: 
          arrayOfString[j] = "CF_PENDATA";
          break;
        case 11: 
          arrayOfString[j] = "CF_RIFF";
          break;
        case 12: 
          arrayOfString[j] = "CF_WAVE";
          break;
        case 13: 
          arrayOfString[j] = "CF_UNICODETEXT";
          break;
        case 14: 
          arrayOfString[j] = "CF_ENHMETAFILE";
          break;
        case 16: 
          arrayOfString[j] = "CF_LOCALE";
          break;
        case 17: 
          arrayOfString[j] = "CF_MAX";
          break;
        default: 
          arrayOfString[j] = "UNKNOWN";
        }
      }
    }
    return arrayOfString;
  }
  
  private FORMATETC[] _getAvailableTypes()
  {
    Object localObject = new FORMATETC[0];
    long[] arrayOfLong1 = new long[1];
    if (COM.OleGetClipboard(arrayOfLong1) != 0) {
      return (FORMATETC[])localObject;
    }
    IDataObject localIDataObject = new IDataObject(arrayOfLong1[0]);
    long[] arrayOfLong2 = new long[1];
    int i = localIDataObject.EnumFormatEtc(1, arrayOfLong2);
    localIDataObject.Release();
    if (i != 0) {
      return (FORMATETC[])localObject;
    }
    IEnumFORMATETC localIEnumFORMATETC = new IEnumFORMATETC(arrayOfLong2[0]);
    long l = OS.GlobalAlloc(64, FORMATETC.sizeof);
    int[] arrayOfInt = new int[1];
    localIEnumFORMATETC.Reset();
    while ((localIEnumFORMATETC.Next(1, l, arrayOfInt) == 0) && (arrayOfInt[0] == 1))
    {
      FORMATETC localFORMATETC = new FORMATETC();
      COM.MoveMemory(localFORMATETC, l, FORMATETC.sizeof);
      FORMATETC[] arrayOfFORMATETC = new FORMATETC[localObject.length + 1];
      System.arraycopy(localObject, 0, arrayOfFORMATETC, 0, localObject.length);
      arrayOfFORMATETC[localObject.length] = localFORMATETC;
      localObject = arrayOfFORMATETC;
    }
    OS.GlobalFree(l);
    localIEnumFORMATETC.Release();
    return (FORMATETC[])localObject;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/dnd/Clipboard.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */