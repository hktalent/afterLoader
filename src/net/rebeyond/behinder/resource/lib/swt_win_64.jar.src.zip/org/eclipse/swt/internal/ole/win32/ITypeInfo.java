package org.eclipse.swt.internal.ole.win32;

import org.eclipse.swt.internal.win32.OS;

public class ITypeInfo
  extends IUnknown
{
  public ITypeInfo(long paramLong)
  {
    super(paramLong);
  }
  
  public int GetDocumentation(int paramInt, String[] paramArrayOfString1, String[] paramArrayOfString2, int[] paramArrayOfInt, String[] paramArrayOfString3)
  {
    long[] arrayOfLong1 = null;
    if (paramArrayOfString1 != null) {
      arrayOfLong1 = new long[1];
    }
    long[] arrayOfLong2 = null;
    if (paramArrayOfString2 != null) {
      arrayOfLong2 = new long[1];
    }
    long[] arrayOfLong3 = null;
    if (paramArrayOfString3 != null) {
      arrayOfLong3 = new long[1];
    }
    int i = COM.VtblCall(12, this.address, paramInt, arrayOfLong1, arrayOfLong2, paramArrayOfInt, arrayOfLong3);
    int j;
    char[] arrayOfChar;
    int k;
    if ((paramArrayOfString1 != null) && (arrayOfLong1[0] != 0L))
    {
      j = COM.SysStringByteLen(arrayOfLong1[0]);
      if (j > 0)
      {
        arrayOfChar = new char[(j + 1) / 2];
        COM.MoveMemory(arrayOfChar, arrayOfLong1[0], j);
        paramArrayOfString1[0] = new String(arrayOfChar);
        k = paramArrayOfString1[0].indexOf("\000");
        if (k > 0) {
          paramArrayOfString1[0] = paramArrayOfString1[0].substring(0, k);
        }
      }
      COM.SysFreeString(arrayOfLong1[0]);
    }
    if ((paramArrayOfString2 != null) && (arrayOfLong2[0] != 0L))
    {
      j = COM.SysStringByteLen(arrayOfLong2[0]);
      if (j > 0)
      {
        arrayOfChar = new char[(j + 1) / 2];
        COM.MoveMemory(arrayOfChar, arrayOfLong2[0], j);
        paramArrayOfString2[0] = new String(arrayOfChar);
        k = paramArrayOfString2[0].indexOf("\000");
        if (k > 0) {
          paramArrayOfString2[0] = paramArrayOfString2[0].substring(0, k);
        }
      }
      COM.SysFreeString(arrayOfLong2[0]);
    }
    if ((paramArrayOfString3 != null) && (arrayOfLong3[0] != 0L))
    {
      j = COM.SysStringByteLen(arrayOfLong3[0]);
      if (j > 0)
      {
        arrayOfChar = new char[(j + 1) / 2];
        COM.MoveMemory(arrayOfChar, arrayOfLong3[0], j);
        paramArrayOfString3[0] = new String(arrayOfChar);
        k = paramArrayOfString3[0].indexOf("\000");
        if (k > 0) {
          paramArrayOfString3[0] = paramArrayOfString3[0].substring(0, k);
        }
      }
      COM.SysFreeString(arrayOfLong3[0]);
    }
    return i;
  }
  
  public int GetFuncDesc(int paramInt, long[] paramArrayOfLong)
  {
    return COM.VtblCall(5, this.address, paramInt, paramArrayOfLong);
  }
  
  public int GetIDsOfNames(String[] paramArrayOfString, int paramInt, int[] paramArrayOfInt)
  {
    int i = paramArrayOfString.length;
    long l1 = OS.GetProcessHeap();
    long l2 = OS.HeapAlloc(l1, 8, i * OS.PTR_SIZEOF);
    long[] arrayOfLong = new long[i];
    try
    {
      for (int j = 0; j < i; j++)
      {
        int k = paramArrayOfString[j].length();
        char[] arrayOfChar = new char[k + 1];
        paramArrayOfString[j].getChars(0, k, arrayOfChar, 0);
        long l3 = OS.HeapAlloc(l1, 8, arrayOfChar.length * 2);
        OS.MoveMemory(l3, arrayOfChar, arrayOfChar.length * 2);
        COM.MoveMemory(l2 + OS.PTR_SIZEOF * j, new long[] { l3 }, OS.PTR_SIZEOF);
        arrayOfLong[j] = l3;
      }
      j = COM.VtblCall(10, this.address, l2, paramInt, paramArrayOfInt);
      return j;
    }
    finally
    {
      for (int m = 0; m < arrayOfLong.length; m++) {
        OS.HeapFree(l1, 0, arrayOfLong[m]);
      }
      OS.HeapFree(l1, 0, l2);
    }
  }
  
  public int GetImplTypeFlags(int paramInt, int[] paramArrayOfInt)
  {
    return COM.VtblCall(9, this.address, paramInt, paramArrayOfInt);
  }
  
  public int GetNames(int paramInt1, String[] paramArrayOfString, int paramInt2, int[] paramArrayOfInt)
  {
    int i = paramArrayOfString.length;
    long[] arrayOfLong = new long[i];
    int j = COM.VtblCall(7, this.address, paramInt1, arrayOfLong, i, paramArrayOfInt);
    if (j == 0) {
      for (int k = 0; k < paramArrayOfInt[0]; k++)
      {
        int m = COM.SysStringByteLen(arrayOfLong[k]);
        if (m > 0)
        {
          char[] arrayOfChar = new char[(m + 1) / 2];
          COM.MoveMemory(arrayOfChar, arrayOfLong[k], m);
          paramArrayOfString[k] = new String(arrayOfChar);
          int n = paramArrayOfString[k].indexOf("\000");
          if (n > 0) {
            paramArrayOfString[k] = paramArrayOfString[k].substring(0, n);
          }
        }
        COM.SysFreeString(arrayOfLong[k]);
      }
    }
    return j;
  }
  
  public int GetRefTypeInfo(int paramInt, long[] paramArrayOfLong)
  {
    return COM.VtblCall(14, this.address, paramInt, paramArrayOfLong);
  }
  
  public int GetRefTypeOfImplType(int paramInt, int[] paramArrayOfInt)
  {
    return COM.VtblCall(8, this.address, paramInt, paramArrayOfInt);
  }
  
  public int GetTypeAttr(long[] paramArrayOfLong)
  {
    return COM.VtblCall(3, this.address, paramArrayOfLong);
  }
  
  public int GetVarDesc(int paramInt, long[] paramArrayOfLong)
  {
    return COM.VtblCall(6, this.address, paramInt, paramArrayOfLong);
  }
  
  public int ReleaseFuncDesc(long paramLong)
  {
    return COM.VtblCall(20, this.address, paramLong);
  }
  
  public int ReleaseTypeAttr(long paramLong)
  {
    return COM.VtblCall(19, this.address, paramLong);
  }
  
  public int ReleaseVarDesc(long paramLong)
  {
    return COM.VtblCall(21, this.address, paramLong);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/internal/ole/win32/ITypeInfo.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */