package org.eclipse.swt.internal.ole.win32;

public class IOleCommandTarget
  extends IUnknown
{
  public IOleCommandTarget(long paramLong)
  {
    super(paramLong);
  }
  
  public int Exec(GUID paramGUID, int paramInt1, int paramInt2, long paramLong1, long paramLong2)
  {
    return COM.VtblCall(4, this.address, paramGUID, paramInt1, paramInt2, paramLong1, paramLong2);
  }
  
  public int QueryStatus(GUID paramGUID, int paramInt, OLECMD paramOLECMD, OLECMDTEXT paramOLECMDTEXT)
  {
    if (paramInt > 1) {
      return -2147024809;
    }
    return COM.VtblCall(3, this.address, paramGUID, paramInt, paramOLECMD, paramOLECMDTEXT);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/internal/ole/win32/IOleCommandTarget.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */