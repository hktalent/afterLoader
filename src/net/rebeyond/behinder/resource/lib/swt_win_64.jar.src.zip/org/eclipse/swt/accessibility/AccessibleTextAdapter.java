package org.eclipse.swt.accessibility;

public abstract class AccessibleTextAdapter
  implements AccessibleTextListener
{
  public void getCaretOffset(AccessibleTextEvent paramAccessibleTextEvent) {}
  
  public void getSelectionRange(AccessibleTextEvent paramAccessibleTextEvent) {}
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/accessibility/AccessibleTextAdapter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */