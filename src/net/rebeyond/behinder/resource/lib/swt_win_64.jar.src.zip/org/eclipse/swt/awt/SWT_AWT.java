package org.eclipse.swt.awt;

import java.awt.Canvas;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Frame;
import java.awt.Toolkit;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.awt.event.FocusEvent;
import java.awt.event.WindowEvent;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.internal.Compatibility;
import org.eclipse.swt.internal.Library;
import org.eclipse.swt.internal.win32.MSG;
import org.eclipse.swt.internal.win32.OS;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Shell;

public class SWT_AWT
{
  public static String embeddedFrameClass;
  static String EMBEDDED_FRAME_KEY = "org.eclipse.swt.awt.SWT_AWT.embeddedFrame";
  static boolean loaded;
  static boolean swingInitialized;
  
  static final native long getAWTHandle(Canvas paramCanvas);
  
  static synchronized void loadLibrary()
  {
    if (loaded) {
      return;
    }
    loaded = true;
    Toolkit.getDefaultToolkit();
    try
    {
      System.loadLibrary("jawt");
    }
    catch (Throwable localThrowable) {}
    Library.loadLibrary("swt-awt");
  }
  
  static synchronized void initializeSwing()
  {
    if (swingInitialized) {
      return;
    }
    swingInitialized = true;
    try
    {
      Class[] arrayOfClass = new Class[0];
      Object[] arrayOfObject = new Object[0];
      Class localClass = Class.forName("javax.swing.UIManager");
      Method localMethod = localClass.getMethod("getDefaults", arrayOfClass);
      if (localMethod != null) {
        localMethod.invoke(localClass, arrayOfObject);
      }
    }
    catch (Throwable localThrowable) {}
  }
  
  public static Frame getFrame(Composite paramComposite)
  {
    if (paramComposite == null) {
      SWT.error(4);
    }
    if ((paramComposite.getStyle() & 0x1000000) == 0) {
      return null;
    }
    return (Frame)paramComposite.getData(EMBEDDED_FRAME_KEY);
  }
  
  public static Frame new_Frame(Composite paramComposite)
  {
    if (paramComposite == null) {
      SWT.error(4);
    }
    if ((paramComposite.getStyle() & 0x1000000) == 0) {
      SWT.error(5);
    }
    final long l = paramComposite.handle;
    Frame[] arrayOfFrame = new Frame[1];
    Throwable[] arrayOfThrowable = new Throwable[1];
    Runnable local1 = new Runnable()
    {
      public void run()
      {
        try
        {
          Class localClass = null;
          try
          {
            String str = SWT_AWT.embeddedFrameClass != null ? SWT_AWT.embeddedFrameClass : "sun.awt.windows.WEmbeddedFrame";
            localClass = Class.forName(str);
          }
          catch (Throwable localThrowable1)
          {
            this.val$exception[0] = localThrowable1;
            return;
          }
          SWT_AWT.initializeSwing();
          Object localObject1 = null;
          Constructor localConstructor = null;
          try
          {
            localConstructor = localClass.getConstructor(new Class[] { Integer.TYPE });
            localObject1 = localConstructor.newInstance(new Object[] { new Integer((int)l) });
          }
          catch (Throwable localThrowable2)
          {
            try
            {
              localConstructor = localClass.getConstructor(new Class[] { Long.TYPE });
              localObject1 = localConstructor.newInstance(new Object[] { new Long(l) });
            }
            catch (Throwable localThrowable3)
            {
              this.val$exception[0] = localThrowable3;
              return;
            }
          }
          Frame localFrame = (Frame)localObject1;
          try
          {
            localClass = Class.forName("sun.awt.windows.WComponentPeer");
            Field localField = localClass.getDeclaredField("winGraphicsConfig");
            localField.setAccessible(true);
            localField.set(localFrame.getPeer(), localFrame.getGraphicsConfiguration());
          }
          catch (Throwable localThrowable4) {}
          this.val$result[0] = localFrame;
        }
        finally
        {
          synchronized (this.val$result)
          {
            this.val$result.notify();
          }
        }
      }
    };
    if ((EventQueue.isDispatchThread()) || (paramComposite.getDisplay().getSyncThread() != null))
    {
      local1.run();
    }
    else
    {
      EventQueue.invokeLater(local1);
      OS.ReplyMessage(0L);
      int i = 0;
      localObject1 = new MSG();
      int j = 4194306;
      while ((arrayOfFrame[0] == null) && (arrayOfThrowable[0] == null))
      {
        OS.PeekMessage((MSG)localObject1, 0L, 0, 0, j);
        try
        {
          synchronized (arrayOfFrame)
          {
            arrayOfFrame.wait(50L);
          }
        }
        catch (InterruptedException localInterruptedException)
        {
          i = 1;
        }
      }
      if (i != 0) {
        Compatibility.interrupt();
      }
    }
    if (arrayOfThrowable[0] != null) {
      SWT.error(20, arrayOfThrowable[0]);
    }
    final Frame localFrame = arrayOfFrame[0];
    paramComposite.setData(EMBEDDED_FRAME_KEY, localFrame);
    final Object localObject1 = new Listener()
    {
      public void handleEvent(Event paramAnonymousEvent)
      {
        switch (paramAnonymousEvent.type)
        {
        case 20: 
          EventQueue.invokeLater(new Runnable()
          {
            public void run()
            {
              SWT_AWT.2.this.val$frame.dispatchEvent(new WindowEvent(SWT_AWT.2.this.val$frame, 204));
            }
          });
          break;
        case 19: 
          EventQueue.invokeLater(new Runnable()
          {
            public void run()
            {
              SWT_AWT.2.this.val$frame.dispatchEvent(new WindowEvent(SWT_AWT.2.this.val$frame, 203));
            }
          });
        }
      }
    };
    Shell localShell = paramComposite.getShell();
    localShell.addListener(20, (Listener)localObject1);
    localShell.addListener(19, (Listener)localObject1);
    Listener local3 = new Listener()
    {
      public void handleEvent(Event paramAnonymousEvent)
      {
        switch (paramAnonymousEvent.type)
        {
        case 12: 
          Shell localShell = this.val$parent.getShell();
          localShell.removeListener(20, localObject1);
          localShell.removeListener(19, localObject1);
          this.val$parent.setVisible(false);
          EventQueue.invokeLater(new Runnable()
          {
            public void run()
            {
              try
              {
                SWT_AWT.3.this.val$frame.dispose();
              }
              catch (Throwable localThrowable) {}
            }
          });
          break;
        case 15: 
        case 26: 
          EventQueue.invokeLater(new Runnable()
          {
            public void run()
            {
              if (Library.JAVA_VERSION < Library.JAVA_VERSION(1, 4, 0))
              {
                SWT_AWT.3.this.val$frame.dispatchEvent(new WindowEvent(SWT_AWT.3.this.val$frame, 205));
                SWT_AWT.3.this.val$frame.dispatchEvent(new FocusEvent(SWT_AWT.3.this.val$frame, 1004));
              }
              else if (Library.JAVA_VERSION < Library.JAVA_VERSION(1, 5, 0))
              {
                SWT_AWT.3.this.val$frame.dispatchEvent(new WindowEvent(SWT_AWT.3.this.val$frame, 205));
                SWT_AWT.3.this.val$frame.dispatchEvent(new WindowEvent(SWT_AWT.3.this.val$frame, 207));
              }
              else
              {
                if (SWT_AWT.3.this.val$frame.isActive()) {
                  return;
                }
                try
                {
                  Class localClass = SWT_AWT.3.this.val$frame.getClass();
                  Method localMethod = localClass.getMethod("synthesizeWindowActivation", new Class[] { Boolean.TYPE });
                  if (localMethod != null) {
                    localMethod.invoke(SWT_AWT.3.this.val$frame, new Object[] { new Boolean(true) });
                  }
                }
                catch (Throwable localThrowable) {}
              }
            }
          });
          break;
        case 27: 
          EventQueue.invokeLater(new Runnable()
          {
            public void run()
            {
              if (Library.JAVA_VERSION < Library.JAVA_VERSION(1, 4, 0))
              {
                SWT_AWT.3.this.val$frame.dispatchEvent(new WindowEvent(SWT_AWT.3.this.val$frame, 206));
                SWT_AWT.3.this.val$frame.dispatchEvent(new FocusEvent(SWT_AWT.3.this.val$frame, 1005));
              }
              else if (Library.JAVA_VERSION < Library.JAVA_VERSION(1, 5, 0))
              {
                SWT_AWT.3.this.val$frame.dispatchEvent(new WindowEvent(SWT_AWT.3.this.val$frame, 208));
                SWT_AWT.3.this.val$frame.dispatchEvent(new WindowEvent(SWT_AWT.3.this.val$frame, 206));
              }
              else
              {
                if (!SWT_AWT.3.this.val$frame.isActive()) {
                  return;
                }
                try
                {
                  Class localClass = SWT_AWT.3.this.val$frame.getClass();
                  Method localMethod = localClass.getMethod("synthesizeWindowActivation", new Class[] { Boolean.TYPE });
                  if (localMethod != null) {
                    localMethod.invoke(SWT_AWT.3.this.val$frame, new Object[] { new Boolean(false) });
                  }
                }
                catch (Throwable localThrowable) {}
              }
            }
          });
        }
      }
    };
    if (Library.JAVA_VERSION < Library.JAVA_VERSION(1, 5, 0)) {
      paramComposite.addListener(26, local3);
    } else {
      paramComposite.addListener(15, local3);
    }
    paramComposite.addListener(27, local3);
    paramComposite.addListener(12, local3);
    paramComposite.getDisplay().asyncExec(new Runnable()
    {
      public void run()
      {
        if (this.val$parent.isDisposed()) {
          return;
        }
        final Rectangle localRectangle = this.val$parent.getClientArea();
        EventQueue.invokeLater(new Runnable()
        {
          public void run()
          {
            SWT_AWT.4.this.val$frame.setSize(localRectangle.width, localRectangle.height);
            SWT_AWT.4.this.val$frame.validate();
          }
        });
      }
    });
    return localFrame;
  }
  
  public static Shell new_Shell(Display paramDisplay, final Canvas paramCanvas)
  {
    if (paramDisplay == null) {
      SWT.error(4);
    }
    if (paramCanvas == null) {
      SWT.error(4);
    }
    long l = 0L;
    try
    {
      loadLibrary();
      l = getAWTHandle(paramCanvas);
    }
    catch (Throwable localThrowable)
    {
      SWT.error(20, localThrowable);
    }
    if (l == 0L) {
      SWT.error(5, null, " [peer not created]");
    }
    final Shell localShell = Shell.win32_new(paramDisplay, l);
    final ComponentAdapter local5 = new ComponentAdapter()
    {
      public void componentResized(ComponentEvent paramAnonymousComponentEvent)
      {
        this.val$display.syncExec(new Runnable()
        {
          public void run()
          {
            if (SWT_AWT.5.this.val$shell.isDisposed()) {
              return;
            }
            Dimension localDimension = SWT_AWT.5.this.val$parent.getSize();
            SWT_AWT.5.this.val$shell.setSize(localDimension.width, localDimension.height);
          }
        });
      }
    };
    paramCanvas.addComponentListener(local5);
    localShell.addListener(12, new Listener()
    {
      public void handleEvent(Event paramAnonymousEvent)
      {
        this.val$parent.removeComponentListener(local5);
      }
    });
    localShell.setVisible(true);
    return localShell;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/awt/SWT_AWT.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */