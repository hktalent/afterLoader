package org.eclipse.swt.internal.mozilla;

public class nsIComponentManager
  extends nsISupports
{
  static final int LAST_METHOD_ID = nsISupports.LAST_METHOD_ID + (IsXULRunner24() ? 6 : 4);
  static final String NS_ICOMPONENTMANAGER_IID_STR = "a88e5a60-205a-4bb1-94e1-2628daf51eae";
  static final String NS_ICOMPONENTMANAGER_24_IID_STR = "1d940426-5fe5-42c3-84ae-a300f2d9ebd5";
  
  public nsIComponentManager(long paramLong)
  {
    super(paramLong);
  }
  
  public int CreateInstance(nsID paramnsID1, long paramLong, nsID paramnsID2, long[] paramArrayOfLong)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 3, getAddress(), paramnsID1, paramLong, paramnsID2, paramArrayOfLong);
  }
  
  public int CreateInstanceByContractID(byte[] paramArrayOfByte, long paramLong, nsID paramnsID, long[] paramArrayOfLong)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 4, getAddress(), paramArrayOfByte, paramLong, paramnsID, paramArrayOfLong);
  }
  
  static
  {
    IIDStore.RegisterIID(nsIComponentManager.class, 0, new nsID("a88e5a60-205a-4bb1-94e1-2628daf51eae"));
    IIDStore.RegisterIID(nsIComponentManager.class, 6, new nsID("1d940426-5fe5-42c3-84ae-a300f2d9ebd5"));
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/internal/mozilla/nsIComponentManager.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */