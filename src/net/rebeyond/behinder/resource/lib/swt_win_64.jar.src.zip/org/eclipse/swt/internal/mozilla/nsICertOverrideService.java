package org.eclipse.swt.internal.mozilla;

public class nsICertOverrideService
  extends nsISupports
{
  static final int LAST_METHOD_ID = nsISupports.LAST_METHOD_ID + 6;
  static final String NS_ICERTOVERRIDESERVICE_IID_STR = "31738d2a-77d3-4359-84c9-4be2f38fb8c5";
  public static final int ERROR_UNTRUSTED = 1;
  public static final int ERROR_MISMATCH = 2;
  public static final int ERROR_TIME = 4;
  
  public nsICertOverrideService(long paramLong)
  {
    super(paramLong);
  }
  
  public int RememberValidityOverride(long paramLong1, int paramInt1, long paramLong2, int paramInt2, int paramInt3)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 1, getAddress(), paramLong1, paramInt1, paramLong2, paramInt2, paramInt3);
  }
  
  static
  {
    IIDStore.RegisterIID(nsICertOverrideService.class, 0, new nsID("31738d2a-77d3-4359-84c9-4be2f38fb8c5"));
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/internal/mozilla/nsICertOverrideService.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */