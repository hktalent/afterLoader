package org.eclipse.swt.browser;

import org.eclipse.swt.events.TypedEvent;
import org.eclipse.swt.widgets.Widget;

public class TitleEvent
  extends TypedEvent
{
  public String title;
  static final long serialVersionUID = 4121132532906340919L;
  
  public TitleEvent(Widget paramWidget)
  {
    super(paramWidget);
  }
  
  public String toString()
  {
    String str = super.toString();
    return str.substring(0, str.length() - 1) + " title=" + this.title + "}";
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/browser/TitleEvent.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */