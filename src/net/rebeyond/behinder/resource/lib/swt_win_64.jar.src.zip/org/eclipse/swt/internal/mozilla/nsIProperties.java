package org.eclipse.swt.internal.mozilla;

public class nsIProperties
  extends nsISupports
{
  static final int LAST_METHOD_ID = nsISupports.LAST_METHOD_ID + 5;
  static final String NS_IPROPERTIES_IID_STR = "78650582-4e93-4b60-8e85-26ebd3eb14ca";
  
  public nsIProperties(long paramLong)
  {
    super(paramLong);
  }
  
  public int Get(byte[] paramArrayOfByte, nsID paramnsID, long[] paramArrayOfLong)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 1, getAddress(), paramArrayOfByte, paramnsID, paramArrayOfLong);
  }
  
  static
  {
    IIDStore.RegisterIID(nsIProperties.class, 0, new nsID("78650582-4e93-4b60-8e85-26ebd3eb14ca"));
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/internal/mozilla/nsIProperties.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */