package org.eclipse.swt.dnd;

import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.internal.win32.OS;
import org.eclipse.swt.internal.win32.POINT;
import org.eclipse.swt.internal.win32.RECT;
import org.eclipse.swt.internal.win32.TVHITTESTINFO;
import org.eclipse.swt.internal.win32.TVITEM;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Tree;
import org.eclipse.swt.widgets.TreeItem;
import org.eclipse.swt.widgets.Widget;

public class TreeDropTargetEffect
  extends DropTargetEffect
{
  static final int SCROLL_HYSTERESIS = 200;
  static final int EXPAND_HYSTERESIS = 1000;
  long dropIndex;
  long scrollIndex;
  long scrollBeginTime;
  long expandIndex;
  long expandBeginTime;
  TreeItem insertItem;
  boolean insertBefore;
  
  public TreeDropTargetEffect(Tree paramTree)
  {
    super(paramTree);
  }
  
  int checkEffect(int paramInt)
  {
    if ((paramInt & 0x1) != 0) {
      paramInt = paramInt & 0xFFFFFFFB & 0xFFFFFFFD;
    }
    if ((paramInt & 0x2) != 0) {
      paramInt &= 0xFFFFFFFB;
    }
    return paramInt;
  }
  
  public void dragEnter(DropTargetEvent paramDropTargetEvent)
  {
    this.dropIndex = -1L;
    this.insertItem = null;
    this.expandBeginTime = 0L;
    this.expandIndex = -1L;
    this.scrollBeginTime = 0L;
    this.scrollIndex = -1L;
  }
  
  public void dragLeave(DropTargetEvent paramDropTargetEvent)
  {
    Tree localTree = (Tree)this.control;
    long l = localTree.handle;
    if (this.dropIndex != -1L)
    {
      TVITEM localTVITEM = new TVITEM();
      localTVITEM.hItem = this.dropIndex;
      localTVITEM.mask = 8;
      localTVITEM.stateMask = 8;
      localTVITEM.state = 0;
      OS.SendMessage(l, OS.TVM_SETITEM, 0L, localTVITEM);
      this.dropIndex = -1L;
    }
    if (this.insertItem != null)
    {
      localTree.setInsertMark(null, false);
      this.insertItem = null;
    }
    this.expandBeginTime = 0L;
    this.expandIndex = -1L;
    this.scrollBeginTime = 0L;
    this.scrollIndex = -1L;
  }
  
  public void dragOver(DropTargetEvent paramDropTargetEvent)
  {
    Tree localTree = (Tree)getControl();
    int i = checkEffect(paramDropTargetEvent.feedback);
    long l1 = localTree.handle;
    Point localPoint = new Point(paramDropTargetEvent.x, paramDropTargetEvent.y);
    localPoint = localTree.toControl(localPoint);
    TVHITTESTINFO localTVHITTESTINFO = new TVHITTESTINFO();
    localTVHITTESTINFO.x = localPoint.x;
    localTVHITTESTINFO.y = localPoint.y;
    OS.SendMessage(l1, 4369, 0L, localTVHITTESTINFO);
    long l2 = localTVHITTESTINFO.hItem;
    if ((i & 0x8) == 0)
    {
      this.scrollBeginTime = 0L;
      this.scrollIndex = -1L;
    }
    else if ((l2 != -1L) && (this.scrollIndex == l2) && (this.scrollBeginTime != 0L))
    {
      if (System.currentTimeMillis() >= this.scrollBeginTime)
      {
        long l3 = OS.SendMessage(l1, 4362, 5L, 0L);
        long l4 = OS.SendMessage(l1, 4362, l2 == l3 ? 7L : 6L, l2);
        int j = 1;
        if (l2 == l3)
        {
          j = l4 != 0L ? 1 : 0;
        }
        else
        {
          RECT localRECT1 = new RECT();
          if (OS.TreeView_GetItemRect(l1, l4, localRECT1, true))
          {
            RECT localRECT2 = new RECT();
            OS.GetClientRect(l1, localRECT2);
            POINT localPOINT = new POINT();
            localPOINT.x = localRECT1.left;
            localPOINT.y = localRECT1.top;
            if (OS.PtInRect(localRECT2, localPOINT))
            {
              localPOINT.y = localRECT1.bottom;
              if (OS.PtInRect(localRECT2, localPOINT)) {
                j = 0;
              }
            }
          }
        }
        if (j != 0)
        {
          OS.SendMessage(l1, 4372, 0L, l4);
          localTree.redraw();
        }
        this.scrollBeginTime = 0L;
        this.scrollIndex = -1L;
      }
    }
    else
    {
      this.scrollBeginTime = (System.currentTimeMillis() + 200L);
      this.scrollIndex = l2;
    }
    Object localObject1;
    Object localObject2;
    if ((i & 0x10) == 0)
    {
      this.expandBeginTime = 0L;
      this.expandIndex = -1L;
    }
    else if ((l2 != -1L) && (this.expandIndex == l2) && (this.expandBeginTime != 0L))
    {
      if (System.currentTimeMillis() >= this.expandBeginTime)
      {
        if (OS.SendMessage(l1, 4362, 4L, l2) != 0L)
        {
          localObject1 = (TreeItem)localTree.getDisplay().findWidget(localTree.handle, l2);
          if ((localObject1 != null) && (!((TreeItem)localObject1).getExpanded()))
          {
            ((TreeItem)localObject1).setExpanded(true);
            localTree.redraw();
            localObject2 = new Event();
            ((Event)localObject2).item = ((Widget)localObject1);
            localTree.notifyListeners(17, (Event)localObject2);
          }
        }
        this.expandBeginTime = 0L;
        this.expandIndex = -1L;
      }
    }
    else
    {
      this.expandBeginTime = (System.currentTimeMillis() + 1000L);
      this.expandIndex = l2;
    }
    if ((this.dropIndex != -1L) && ((this.dropIndex != l2) || ((i & 0x1) == 0)))
    {
      localObject1 = new TVITEM();
      ((TVITEM)localObject1).hItem = this.dropIndex;
      ((TVITEM)localObject1).mask = 8;
      ((TVITEM)localObject1).stateMask = 8;
      ((TVITEM)localObject1).state = 0;
      OS.SendMessage(l1, OS.TVM_SETITEM, 0L, (TVITEM)localObject1);
      this.dropIndex = -1L;
    }
    if ((l2 != -1L) && (l2 != this.dropIndex) && ((i & 0x1) != 0))
    {
      localObject1 = new TVITEM();
      ((TVITEM)localObject1).hItem = l2;
      ((TVITEM)localObject1).mask = 8;
      ((TVITEM)localObject1).stateMask = 8;
      ((TVITEM)localObject1).state = 8;
      OS.SendMessage(l1, OS.TVM_SETITEM, 0L, (TVITEM)localObject1);
      this.dropIndex = l2;
    }
    if (((i & 0x2) != 0) || ((i & 0x4) != 0))
    {
      boolean bool = (i & 0x2) != 0;
      localObject2 = (TreeItem)localTree.getDisplay().findWidget(localTree.handle, l2);
      if (localObject2 != null)
      {
        if ((localObject2 != this.insertItem) || (bool != this.insertBefore)) {
          localTree.setInsertMark((TreeItem)localObject2, bool);
        }
        this.insertItem = ((TreeItem)localObject2);
        this.insertBefore = bool;
      }
      else
      {
        if (this.insertItem != null) {
          localTree.setInsertMark(null, false);
        }
        this.insertItem = null;
      }
    }
    else
    {
      if (this.insertItem != null) {
        localTree.setInsertMark(null, false);
      }
      this.insertItem = null;
    }
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/dnd/TreeDropTargetEffect.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */