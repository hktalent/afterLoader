package org.eclipse.swt.custom;

import org.eclipse.swt.internal.SWTEventListener;

public abstract interface CTabFolder2Listener
  extends SWTEventListener
{
  public abstract void close(CTabFolderEvent paramCTabFolderEvent);
  
  public abstract void minimize(CTabFolderEvent paramCTabFolderEvent);
  
  public abstract void maximize(CTabFolderEvent paramCTabFolderEvent);
  
  public abstract void restore(CTabFolderEvent paramCTabFolderEvent);
  
  public abstract void showList(CTabFolderEvent paramCTabFolderEvent);
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/custom/CTabFolder2Listener.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */