package org.eclipse.swt.internal.ole.win32;

import org.eclipse.swt.internal.win32.OS;

public class IDispatch
  extends IUnknown
{
  public IDispatch(long paramLong)
  {
    super(paramLong);
  }
  
  public int GetIDsOfNames(GUID paramGUID, String[] paramArrayOfString, int paramInt1, int paramInt2, int[] paramArrayOfInt)
  {
    int i = paramArrayOfString.length;
    long l1 = OS.GetProcessHeap();
    long l2 = OS.HeapAlloc(l1, 8, i * OS.PTR_SIZEOF);
    long[] arrayOfLong = new long[i];
    try
    {
      int k;
      for (int j = 0; j < i; j++)
      {
        k = paramArrayOfString[j].length();
        char[] arrayOfChar = new char[k + 1];
        paramArrayOfString[j].getChars(0, k, arrayOfChar, 0);
        long l3 = OS.HeapAlloc(l1, 8, arrayOfChar.length * 2);
        OS.MoveMemory(l3, arrayOfChar, arrayOfChar.length * 2);
        COM.MoveMemory(l2 + OS.PTR_SIZEOF * j, new long[] { l3 }, OS.PTR_SIZEOF);
        arrayOfLong[j] = l3;
      }
      j = COM.VtblCall(5, this.address, new GUID(), l2, paramInt1, paramInt2, paramArrayOfInt);
      return j;
    }
    finally
    {
      for (int m = 0; m < arrayOfLong.length; m++) {
        OS.HeapFree(l1, 0, arrayOfLong[m]);
      }
      OS.HeapFree(l1, 0, l2);
    }
  }
  
  public int GetTypeInfo(int paramInt1, int paramInt2, long[] paramArrayOfLong)
  {
    return COM.VtblCall(4, this.address, paramInt1, paramInt2, paramArrayOfLong);
  }
  
  public int GetTypeInfoCount(int[] paramArrayOfInt)
  {
    return COM.VtblCall(3, this.address, paramArrayOfInt);
  }
  
  public int Invoke(int paramInt1, GUID paramGUID, int paramInt2, int paramInt3, DISPPARAMS paramDISPPARAMS, long paramLong, EXCEPINFO paramEXCEPINFO, int[] paramArrayOfInt)
  {
    return COM.VtblCall(6, this.address, paramInt1, paramGUID, paramInt2, paramInt3, paramDISPPARAMS, paramLong, paramEXCEPINFO, paramArrayOfInt);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/internal/ole/win32/IDispatch.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */