package org.eclipse.swt.accessibility;

import org.eclipse.swt.internal.SWTEventListener;

public abstract interface AccessibleTableCellListener
  extends SWTEventListener
{
  public abstract void getColumnSpan(AccessibleTableCellEvent paramAccessibleTableCellEvent);
  
  public abstract void getColumnHeaders(AccessibleTableCellEvent paramAccessibleTableCellEvent);
  
  public abstract void getColumnIndex(AccessibleTableCellEvent paramAccessibleTableCellEvent);
  
  public abstract void getRowSpan(AccessibleTableCellEvent paramAccessibleTableCellEvent);
  
  public abstract void getRowHeaders(AccessibleTableCellEvent paramAccessibleTableCellEvent);
  
  public abstract void getRowIndex(AccessibleTableCellEvent paramAccessibleTableCellEvent);
  
  public abstract void getTable(AccessibleTableCellEvent paramAccessibleTableCellEvent);
  
  public abstract void isSelected(AccessibleTableCellEvent paramAccessibleTableCellEvent);
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/accessibility/AccessibleTableCellListener.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */