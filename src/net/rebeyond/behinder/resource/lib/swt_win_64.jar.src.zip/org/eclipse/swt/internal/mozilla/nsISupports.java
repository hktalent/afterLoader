package org.eclipse.swt.internal.mozilla;

public class nsISupports
{
  static final boolean IsSolaris;
  static final int FIRST_METHOD_ID;
  static final int LAST_METHOD_ID;
  public static final String NS_ISUPPORTS_IID_STR = "00000000-0000-0000-c000-000000000046";
  long address;
  
  protected static boolean IsXULRunner10()
  {
    return MozillaVersion.CheckVersion(5, true);
  }
  
  protected static boolean IsXULRunner24()
  {
    return MozillaVersion.CheckVersion(6, true);
  }
  
  public nsISupports(long paramLong)
  {
    this.address = paramLong;
  }
  
  public long getAddress()
  {
    return this.address;
  }
  
  public int QueryInterface(nsID paramnsID, long[] paramArrayOfLong)
  {
    return XPCOM.VtblCall(FIRST_METHOD_ID, getAddress(), paramnsID, paramArrayOfLong);
  }
  
  public int AddRef()
  {
    return XPCOM.VtblCall(FIRST_METHOD_ID + 1, getAddress());
  }
  
  public int Release()
  {
    return XPCOM.VtblCall(FIRST_METHOD_ID + 2, getAddress());
  }
  
  static
  {
    String str = System.getProperty("os.name").toLowerCase();
    IsSolaris = (str.startsWith("sunos")) || (str.startsWith("solaris"));
    FIRST_METHOD_ID = IsSolaris ? 2 : 0;
    LAST_METHOD_ID = FIRST_METHOD_ID + 2;
    IIDStore.RegisterIID(nsISupports.class, 0, new nsID("00000000-0000-0000-c000-000000000046"));
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/internal/mozilla/nsISupports.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */