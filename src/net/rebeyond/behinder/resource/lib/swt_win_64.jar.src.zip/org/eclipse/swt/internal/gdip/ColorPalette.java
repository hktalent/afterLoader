package org.eclipse.swt.internal.gdip;

public class ColorPalette
{
  public int Flags;
  public int Count;
  public int[] Entries = new int[1];
  public static final int sizeof = ;
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/internal/gdip/ColorPalette.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */