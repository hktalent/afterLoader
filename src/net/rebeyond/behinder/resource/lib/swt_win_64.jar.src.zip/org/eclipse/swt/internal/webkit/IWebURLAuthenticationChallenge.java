package org.eclipse.swt.internal.webkit;

import org.eclipse.swt.internal.ole.win32.COM;
import org.eclipse.swt.internal.ole.win32.IUnknown;

public class IWebURLAuthenticationChallenge
  extends IUnknown
{
  public IWebURLAuthenticationChallenge(long paramLong)
  {
    super(paramLong);
  }
  
  public int previousFailureCount(int[] paramArrayOfInt)
  {
    return COM.VtblCall(7, getAddress(), paramArrayOfInt);
  }
  
  public int proposedCredential(long[] paramArrayOfLong)
  {
    return COM.VtblCall(8, getAddress(), paramArrayOfLong);
  }
  
  public int protectionSpace(long[] paramArrayOfLong)
  {
    return COM.VtblCall(9, getAddress(), paramArrayOfLong);
  }
  
  public int sender(long[] paramArrayOfLong)
  {
    return COM.VtblCall(10, getAddress(), paramArrayOfLong);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/internal/webkit/IWebURLAuthenticationChallenge.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */