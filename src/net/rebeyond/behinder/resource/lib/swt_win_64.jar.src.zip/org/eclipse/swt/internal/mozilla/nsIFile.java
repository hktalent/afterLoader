package org.eclipse.swt.internal.mozilla;

public class nsIFile
  extends nsISupports
{
  static final int LAST_METHOD_ID = nsISupports.LAST_METHOD_ID + (IsXULRunner24() ? 62 : 45);
  static final String NS_IFILE_IID_STR = "c8c0a080-0868-11d3-915f-d9d889d48e3c";
  static final String NS_IFILE_24_IID_STR = "272a5020-64f5-485c-a8c4-44b2882ae0a2";
  public static final int NORMAL_FILE_TYPE = 0;
  public static final int DIRECTORY_TYPE = 1;
  
  public nsIFile(long paramLong)
  {
    super(paramLong);
  }
  
  public int Create(int paramInt1, int paramInt2)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 4, getAddress(), paramInt1, paramInt2);
  }
  
  public int GetLeafName(long paramLong)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 5, getAddress(), paramLong);
  }
  
  public int GetPath(long paramLong)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 29, getAddress(), paramLong);
  }
  
  static
  {
    IIDStore.RegisterIID(nsIFile.class, 0, new nsID("c8c0a080-0868-11d3-915f-d9d889d48e3c"));
    IIDStore.RegisterIID(nsIFile.class, 6, new nsID("272a5020-64f5-485c-a8c4-44b2882ae0a2"));
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/internal/mozilla/nsIFile.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */