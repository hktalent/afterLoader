package org.eclipse.swt.internal.mozilla;

public class nsIChannel
  extends nsIRequest
{
  static final int LAST_METHOD_ID = nsIRequest.LAST_METHOD_ID + (IsXULRunner10() ? 19 : IsXULRunner24() ? 21 : 16);
  static final String NS_ICHANNEL_IID_STR = "c63a055a-a676-4e71-bf3c-6cfa11082018";
  static final String NS_ICHANNEL_10_IID_STR = "06f6ada3-7729-4e72-8d3f-bf8ba630ff9b";
  static final String NS_ICHANNEL_24_IID_STR = "2a8a7237-c1e2-4de7-b669-2002af29e42d";
  public static final int LOAD_DOCUMENT_URI = 65536;
  public static final int LOAD_RETARGETED_DOCUMENT_URI = 131072;
  public static final int LOAD_REPLACE = 262144;
  public static final int LOAD_INITIAL_DOCUMENT_URI = 524288;
  public static final int LOAD_TARGETED = 1048576;
  public static final int LOAD_CALL_CONTENT_SNIFFERS = 2097152;
  public static final int LOAD_CLASSIFY_URI = 4194304;
  public static final int DISPOSITION_INLINE = 0;
  public static final int DISPOSITION_ATTACHMENT = 1;
  
  public nsIChannel(long paramLong)
  {
    super(paramLong);
  }
  
  public int GetURI(long[] paramArrayOfLong)
  {
    return XPCOM.VtblCall(nsIRequest.LAST_METHOD_ID + 3, getAddress(), paramArrayOfLong);
  }
  
  public int SetNotificationCallbacks(long paramLong)
  {
    return XPCOM.VtblCall(nsIRequest.LAST_METHOD_ID + 7, getAddress(), paramLong);
  }
  
  static
  {
    IIDStore.RegisterIID(nsIChannel.class, 0, new nsID("c63a055a-a676-4e71-bf3c-6cfa11082018"));
    IIDStore.RegisterIID(nsIChannel.class, 5, new nsID("06f6ada3-7729-4e72-8d3f-bf8ba630ff9b"));
    IIDStore.RegisterIID(nsIChannel.class, 6, new nsID("2a8a7237-c1e2-4de7-b669-2002af29e42d"));
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/internal/mozilla/nsIChannel.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */