package org.eclipse.swt.graphics;

import org.eclipse.swt.internal.win32.PAINTSTRUCT;

public final class GCData
{
  public Device device;
  public int style;
  public int state = -1;
  public int foreground = -1;
  public int background = -1;
  public Font font;
  public Pattern foregroundPattern;
  public Pattern backgroundPattern;
  public int lineStyle = 1;
  public float lineWidth;
  public int lineCap = 1;
  public int lineJoin = 1;
  public float lineDashesOffset;
  public float[] lineDashes;
  public float lineMiterLimit = 10.0F;
  public int alpha = 255;
  public Image image;
  public PAINTSTRUCT ps;
  public int layout = -1;
  public long hPen;
  public long hOldPen;
  public long hBrush;
  public long hOldBrush;
  public long hNullBitmap;
  public long hwnd;
  public long gdipGraphics;
  public long gdipPen;
  public long gdipBrush;
  public long gdipFgBrush;
  public long gdipBgBrush;
  public long gdipFont;
  public long hGDIFont;
  public float gdipXOffset;
  public float gdipYOffset;
  public int uiState = 0;
  public boolean focusDrawn;
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/graphics/GCData.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */