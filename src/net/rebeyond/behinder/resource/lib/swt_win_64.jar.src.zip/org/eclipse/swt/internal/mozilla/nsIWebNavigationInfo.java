package org.eclipse.swt.internal.mozilla;

public class nsIWebNavigationInfo
  extends nsISupports
{
  static final int LAST_METHOD_ID = nsISupports.LAST_METHOD_ID + 1;
  static final String NS_IWEBNAVIGATIONINFO_IID_STR = "62a93afb-93a1-465c-84c8-0432264229de";
  public static final int UNSUPPORTED = 0;
  public static final int IMAGE = 1;
  public static final int PLUGIN = 2;
  public static final int OTHER = 32768;
  
  public nsIWebNavigationInfo(long paramLong)
  {
    super(paramLong);
  }
  
  public int IsTypeSupported(long paramLong1, long paramLong2, int[] paramArrayOfInt)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 1, getAddress(), paramLong1, paramLong2, paramArrayOfInt);
  }
  
  static
  {
    IIDStore.RegisterIID(nsIWebNavigationInfo.class, 0, new nsID("62a93afb-93a1-465c-84c8-0432264229de"));
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/internal/mozilla/nsIWebNavigationInfo.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */