package org.eclipse.swt.internal.mozilla;

public class nsIXPCSecurityManager
  extends nsISupports
{
  static final int LAST_METHOD_ID = nsISupports.LAST_METHOD_ID + 4;
  static final String NS_IXPCSECURITYMANAGER_IID_STR = "31431440-f1ce-11d2-985a-006008962422";
  
  public nsIXPCSecurityManager(long paramLong)
  {
    super(paramLong);
  }
  
  static
  {
    IIDStore.RegisterIID(nsIXPCSecurityManager.class, 0, new nsID("31431440-f1ce-11d2-985a-006008962422"));
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/internal/mozilla/nsIXPCSecurityManager.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */