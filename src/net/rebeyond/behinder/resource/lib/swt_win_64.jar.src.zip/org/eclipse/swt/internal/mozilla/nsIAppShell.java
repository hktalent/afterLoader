package org.eclipse.swt.internal.mozilla;

public class nsIAppShell
  extends nsISupports
{
  static final int LAST_METHOD_ID = nsISupports.LAST_METHOD_ID + 8;
  static final String NS_IAPPSHELL_IID_STR = "a0757c31-eeac-11d1-9ec1-00aa002fb821";
  
  public nsIAppShell(long paramLong)
  {
    super(paramLong);
  }
  
  public int Create(long paramLong, long[] paramArrayOfLong)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 1, getAddress(), paramLong, paramArrayOfLong);
  }
  
  public int Spinup()
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 3, getAddress());
  }
  
  static
  {
    IIDStore.RegisterIID(nsIAppShell.class, 0, new nsID("a0757c31-eeac-11d1-9ec1-00aa002fb821"));
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/internal/mozilla/nsIAppShell.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */