package org.eclipse.swt.dnd;

import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.ImageData;
import org.eclipse.swt.graphics.PaletteData;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.internal.win32.BITMAP;
import org.eclipse.swt.internal.win32.BITMAPINFOHEADER;
import org.eclipse.swt.internal.win32.OS;
import org.eclipse.swt.internal.win32.POINT;
import org.eclipse.swt.internal.win32.RECT;
import org.eclipse.swt.internal.win32.SHDRAGIMAGE;
import org.eclipse.swt.internal.win32.SIZE;
import org.eclipse.swt.internal.win32.TCHAR;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Tree;
import org.eclipse.swt.widgets.TreeItem;

public class TreeDragSourceEffect
  extends DragSourceEffect
{
  Image dragSourceImage = null;
  
  public TreeDragSourceEffect(Tree paramTree)
  {
    super(paramTree);
  }
  
  public void dragFinished(DragSourceEvent paramDragSourceEvent)
  {
    if (this.dragSourceImage != null) {
      this.dragSourceImage.dispose();
    }
    this.dragSourceImage = null;
  }
  
  public void dragStart(DragSourceEvent paramDragSourceEvent)
  {
    paramDragSourceEvent.image = getDragSourceImage(paramDragSourceEvent);
  }
  
  Image getDragSourceImage(DragSourceEvent paramDragSourceEvent)
  {
    if (this.dragSourceImage != null) {
      this.dragSourceImage.dispose();
    }
    this.dragSourceImage = null;
    int m;
    long l12;
    if ((!OS.IsWinCE) && (OS.WIN32_VERSION >= OS.VERSION(5, 1)))
    {
      localObject = new SHDRAGIMAGE();
      int i = OS.RegisterWindowMessage(new TCHAR(0, "ShellGetDragImage", true));
      if (OS.SendMessage(this.control.handle, i, 0L, (SHDRAGIMAGE)localObject) != 0L)
      {
        if ((this.control.getStyle() & 0x8000000) != 0) {
          paramDragSourceEvent.offsetX = (((SHDRAGIMAGE)localObject).sizeDragImage.cx - ((SHDRAGIMAGE)localObject).ptOffset.x);
        } else {
          paramDragSourceEvent.offsetX = ((SHDRAGIMAGE)localObject).ptOffset.x;
        }
        paramDragSourceEvent.offsetY = ((SHDRAGIMAGE)localObject).ptOffset.y;
        l1 = ((SHDRAGIMAGE)localObject).hbmpDragImage;
        if (l1 != 0L)
        {
          BITMAP localBITMAP1 = new BITMAP();
          OS.GetObject(l1, BITMAP.sizeof, localBITMAP1);
          int k = localBITMAP1.bmWidth;
          m = localBITMAP1.bmHeight;
          long l3 = OS.GetDC(0L);
          long l5 = OS.CreateCompatibleDC(l3);
          long l7 = OS.SelectObject(l5, l1);
          long l9 = OS.CreateCompatibleDC(l3);
          BITMAPINFOHEADER localBITMAPINFOHEADER = new BITMAPINFOHEADER();
          localBITMAPINFOHEADER.biSize = BITMAPINFOHEADER.sizeof;
          localBITMAPINFOHEADER.biWidth = k;
          localBITMAPINFOHEADER.biHeight = (-m);
          localBITMAPINFOHEADER.biPlanes = 1;
          localBITMAPINFOHEADER.biBitCount = 32;
          localBITMAPINFOHEADER.biCompression = 0;
          byte[] arrayOfByte1 = new byte[BITMAPINFOHEADER.sizeof];
          OS.MoveMemory(arrayOfByte1, localBITMAPINFOHEADER, BITMAPINFOHEADER.sizeof);
          long[] arrayOfLong = new long[1];
          long l11 = OS.CreateDIBSection(0L, arrayOfByte1, 0, arrayOfLong, 0L, 0);
          if (l11 == 0L) {
            SWT.error(2);
          }
          l12 = OS.SelectObject(l9, l11);
          BITMAP localBITMAP2 = new BITMAP();
          OS.GetObject(l11, BITMAP.sizeof, localBITMAP2);
          int i1 = localBITMAP2.bmWidthBytes * localBITMAP2.bmHeight;
          OS.BitBlt(l9, 0, 0, k, m, l5, 0, 0, 13369376);
          byte[] arrayOfByte2 = new byte[i1];
          OS.MoveMemory(arrayOfByte2, localBITMAP2.bmBits, i1);
          PaletteData localPaletteData = new PaletteData(65280, 16711680, -16777216);
          ImageData localImageData = new ImageData(k, m, localBITMAP1.bmBitsPixel, localPaletteData, localBITMAP1.bmWidthBytes, arrayOfByte2);
          if (((SHDRAGIMAGE)localObject).crColorKey == -1)
          {
            byte[] arrayOfByte3 = new byte[k * m];
            int i2 = localBITMAP2.bmWidthBytes - k * 4;
            int i3 = 0;
            int i4 = 3;
            for (int i5 = 0; i5 < m; i5++)
            {
              for (int i6 = 0; i6 < k; i6++)
              {
                arrayOfByte3[(i3++)] = arrayOfByte2[i4];
                i4 += 4;
              }
              i4 += i2;
            }
            localImageData.alphaData = arrayOfByte3;
          }
          else
          {
            localImageData.transparentPixel = (((SHDRAGIMAGE)localObject).crColorKey << 8);
          }
          this.dragSourceImage = new Image(this.control.getDisplay(), localImageData);
          OS.SelectObject(l9, l12);
          OS.DeleteDC(l9);
          OS.DeleteObject(l11);
          OS.SelectObject(l5, l7);
          OS.DeleteDC(l5);
          OS.ReleaseDC(0L, l3);
          OS.DeleteObject(l1);
          return this.dragSourceImage;
        }
      }
      return null;
    }
    Object localObject = (Tree)this.control;
    if ((((Tree)localObject).isListening(40)) || (((Tree)localObject).isListening(42))) {
      return null;
    }
    TreeItem[] arrayOfTreeItem = ((Tree)localObject).getSelection();
    if (arrayOfTreeItem.length == 0) {
      return null;
    }
    long l1 = OS.SendMessage(((Tree)localObject).handle, 4360, 0L, 0L);
    if (l1 != 0L)
    {
      int j = Math.min(arrayOfTreeItem.length, 10);
      Rectangle localRectangle1 = arrayOfTreeItem[0].getBounds(0);
      for (m = 1; m < j; m++) {
        localRectangle1 = localRectangle1.union(arrayOfTreeItem[m].getBounds(0));
      }
      long l2 = OS.GetDC(((Tree)localObject).handle);
      long l4 = OS.CreateCompatibleDC(l2);
      long l6 = OS.CreateCompatibleBitmap(l2, localRectangle1.width, localRectangle1.height);
      long l8 = OS.SelectObject(l4, l6);
      RECT localRECT = new RECT();
      localRECT.right = localRectangle1.width;
      localRECT.bottom = localRectangle1.height;
      long l10 = OS.GetStockObject(0);
      OS.FillRect(l4, localRECT, l10);
      for (int n = 0; n < j; n++)
      {
        TreeItem localTreeItem = arrayOfTreeItem[n];
        Rectangle localRectangle2 = localTreeItem.getBounds(0);
        l12 = OS.SendMessage(((Tree)localObject).handle, 4370, 0L, localTreeItem.handle);
        OS.ImageList_Draw(l12, 0, l4, localRectangle2.x - localRectangle1.x, localRectangle2.y - localRectangle1.y, 4);
        OS.ImageList_Destroy(l12);
      }
      OS.SelectObject(l4, l8);
      OS.DeleteDC(l4);
      OS.ReleaseDC(((Tree)localObject).handle, l2);
      Display localDisplay = ((Tree)localObject).getDisplay();
      this.dragSourceImage = Image.win32_new(localDisplay, 0, l6);
      return this.dragSourceImage;
    }
    return null;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/dnd/TreeDragSourceEffect.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */