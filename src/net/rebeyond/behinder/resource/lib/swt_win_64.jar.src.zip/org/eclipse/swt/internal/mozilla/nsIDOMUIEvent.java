package org.eclipse.swt.internal.mozilla;

public class nsIDOMUIEvent
  extends nsIDOMEvent
{
  static final int LAST_METHOD_ID = nsIDOMEvent.LAST_METHOD_ID + ((IsXULRunner10()) || (IsXULRunner24()) ? 13 : 3);
  static final String NS_IDOMUIEVENT_IID_STR = "a6cf90c3-15b3-11d2-932e-00805f8add32";
  static final String NS_IDOMUIEVENT_10_IID_STR = "af3f130e-0c22-4613-a150-780a46c22e3a";
  static final String NS_IDOMUIEVENT_24_IID_STR = "d73852f8-7bd6-477d-8233-117dbf83860b";
  public static final int SCROLL_PAGE_UP = -32768;
  public static final int SCROLL_PAGE_DOWN = 32768;
  
  public nsIDOMUIEvent(long paramLong)
  {
    super(paramLong);
  }
  
  public int GetDetail(int[] paramArrayOfInt)
  {
    return XPCOM.VtblCall(nsIDOMEvent.LAST_METHOD_ID + 2, getAddress(), paramArrayOfInt);
  }
  
  static
  {
    IIDStore.RegisterIID(nsIDOMUIEvent.class, 0, new nsID("a6cf90c3-15b3-11d2-932e-00805f8add32"));
    IIDStore.RegisterIID(nsIDOMUIEvent.class, 5, new nsID("af3f130e-0c22-4613-a150-780a46c22e3a"));
    IIDStore.RegisterIID(nsIDOMUIEvent.class, 6, new nsID("d73852f8-7bd6-477d-8233-117dbf83860b"));
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/internal/mozilla/nsIDOMUIEvent.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */