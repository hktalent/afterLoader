package org.eclipse.swt.internal.image;

final class JPEGRestartInterval
  extends JPEGFixedSizeSegment
{
  public JPEGRestartInterval(LEDataInputStream paramLEDataInputStream)
  {
    super(paramLEDataInputStream);
  }
  
  public int signature()
  {
    return 65501;
  }
  
  public int getRestartInterval()
  {
    return (this.reference[4] & 0xFF) << 8 | this.reference[5] & 0xFF;
  }
  
  public int fixedSize()
  {
    return 6;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/internal/image/JPEGRestartInterval.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */