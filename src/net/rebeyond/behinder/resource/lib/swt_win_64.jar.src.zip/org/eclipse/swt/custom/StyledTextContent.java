package org.eclipse.swt.custom;

public abstract interface StyledTextContent
{
  public abstract void addTextChangeListener(TextChangeListener paramTextChangeListener);
  
  public abstract int getCharCount();
  
  public abstract String getLine(int paramInt);
  
  public abstract int getLineAtOffset(int paramInt);
  
  public abstract int getLineCount();
  
  public abstract String getLineDelimiter();
  
  public abstract int getOffsetAtLine(int paramInt);
  
  public abstract String getTextRange(int paramInt1, int paramInt2);
  
  public abstract void removeTextChangeListener(TextChangeListener paramTextChangeListener);
  
  public abstract void replaceTextRange(int paramInt1, int paramInt2, String paramString);
  
  public abstract void setText(String paramString);
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/custom/StyledTextContent.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */