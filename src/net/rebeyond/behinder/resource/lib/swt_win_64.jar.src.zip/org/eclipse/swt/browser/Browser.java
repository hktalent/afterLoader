package org.eclipse.swt.browser;

import org.eclipse.swt.SWT;
import org.eclipse.swt.SWTException;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;

public class Browser
  extends Composite
{
  WebBrowser webBrowser;
  int userStyle;
  boolean isClosing;
  static int DefaultType = -1;
  static final String NO_INPUT_METHOD = "org.eclipse.swt.internal.gtk.noInputMethod";
  static final String PACKAGE_PREFIX = "org.eclipse.swt.browser.";
  static final String PROPERTY_DEFAULTTYPE = "org.eclipse.swt.browser.DefaultType";
  
  public Browser(Composite paramComposite, int paramInt)
  {
    super(checkParent(paramComposite), checkStyle(paramInt));
    this.userStyle = paramInt;
    String str = SWT.getPlatform();
    if ("gtk".equals(str)) {
      paramComposite.getDisplay().setData("org.eclipse.swt.internal.gtk.noInputMethod", null);
    }
    paramInt = getStyle();
    this.webBrowser = new BrowserFactory().createWebBrowser(paramInt);
    if (this.webBrowser != null)
    {
      this.webBrowser.setBrowser(this);
      this.webBrowser.create(paramComposite, paramInt);
      return;
    }
    dispose();
    SWT.error(2);
  }
  
  static Composite checkParent(Composite paramComposite)
  {
    String str = SWT.getPlatform();
    if (!"gtk".equals(str)) {
      return paramComposite;
    }
    if ((paramComposite != null) && (!paramComposite.isDisposed()))
    {
      Display localDisplay = paramComposite.getDisplay();
      if ((localDisplay != null) && (localDisplay.getThread() == Thread.currentThread())) {
        localDisplay.setData("org.eclipse.swt.internal.gtk.noInputMethod", "true");
      }
    }
    return paramComposite;
  }
  
  static int checkStyle(int paramInt)
  {
    String str1 = SWT.getPlatform();
    if (DefaultType == -1)
    {
      try
      {
        Class.forName("org.eclipse.swt.browser.BrowserInitializer");
      }
      catch (ClassNotFoundException localClassNotFoundException) {}
      String str2 = System.getProperty("org.eclipse.swt.browser.DefaultType");
      if (str2 != null)
      {
        int i = 0;
        int j = str2.length();
        do
        {
          int k = str2.indexOf(',', i);
          if (k == -1) {
            k = j;
          }
          String str3 = str2.substring(i, k).trim();
          if (str3.equalsIgnoreCase("mozilla"))
          {
            DefaultType = 32768;
            break;
          }
          if (str3.equalsIgnoreCase("webkit"))
          {
            DefaultType = 65536;
            break;
          }
          if ((str3.equalsIgnoreCase("ie")) && ("win32".equals(str1)))
          {
            DefaultType = 0;
            break;
          }
          i = k + 1;
        } while (i < j);
      }
      if (DefaultType == -1) {
        DefaultType = 0;
      }
    }
    if ((paramInt & 0x18000) == 0) {
      paramInt |= DefaultType;
    }
    if ((paramInt & 0x18000) == 98304) {
      paramInt &= 0xFFFEFFFF;
    }
    if (((paramInt & 0x8000) != 0) || ((paramInt & 0x10000) != 0))
    {
      if ("carbon".equals(str1)) {
        return paramInt | 0x1000000;
      }
      if ("motif".equals(str1)) {
        return paramInt | 0x1000000;
      }
      return paramInt;
    }
    if ("win32".equals(str1)) {
      return paramInt & 0xF7FF;
    }
    if ("motif".equals(str1)) {
      return paramInt | 0x1000000;
    }
    return paramInt;
  }
  
  protected void checkWidget()
  {
    super.checkWidget();
  }
  
  public static void clearSessions() {}
  
  public static String getCookie(String paramString1, String paramString2)
  {
    if (paramString1 == null) {
      SWT.error(4);
    }
    if (paramString2 == null) {
      SWT.error(4);
    }
    return WebBrowser.GetCookie(paramString1, paramString2);
  }
  
  public static boolean setCookie(String paramString1, String paramString2)
  {
    if (paramString1 == null) {
      SWT.error(4);
    }
    if (paramString2 == null) {
      SWT.error(4);
    }
    return WebBrowser.SetCookie(paramString1, paramString2, true);
  }
  
  public void addAuthenticationListener(AuthenticationListener paramAuthenticationListener)
  {
    checkWidget();
    if (paramAuthenticationListener == null) {
      SWT.error(4);
    }
    this.webBrowser.addAuthenticationListener(paramAuthenticationListener);
  }
  
  public void addCloseWindowListener(CloseWindowListener paramCloseWindowListener)
  {
    checkWidget();
    if (paramCloseWindowListener == null) {
      SWT.error(4);
    }
    this.webBrowser.addCloseWindowListener(paramCloseWindowListener);
  }
  
  public void addLocationListener(LocationListener paramLocationListener)
  {
    checkWidget();
    if (paramLocationListener == null) {
      SWT.error(4);
    }
    this.webBrowser.addLocationListener(paramLocationListener);
  }
  
  public void addOpenWindowListener(OpenWindowListener paramOpenWindowListener)
  {
    checkWidget();
    if (paramOpenWindowListener == null) {
      SWT.error(4);
    }
    this.webBrowser.addOpenWindowListener(paramOpenWindowListener);
  }
  
  public void addProgressListener(ProgressListener paramProgressListener)
  {
    checkWidget();
    if (paramProgressListener == null) {
      SWT.error(4);
    }
    this.webBrowser.addProgressListener(paramProgressListener);
  }
  
  public void addStatusTextListener(StatusTextListener paramStatusTextListener)
  {
    checkWidget();
    if (paramStatusTextListener == null) {
      SWT.error(4);
    }
    this.webBrowser.addStatusTextListener(paramStatusTextListener);
  }
  
  public void addTitleListener(TitleListener paramTitleListener)
  {
    checkWidget();
    if (paramTitleListener == null) {
      SWT.error(4);
    }
    this.webBrowser.addTitleListener(paramTitleListener);
  }
  
  public void addVisibilityWindowListener(VisibilityWindowListener paramVisibilityWindowListener)
  {
    checkWidget();
    if (paramVisibilityWindowListener == null) {
      SWT.error(4);
    }
    this.webBrowser.addVisibilityWindowListener(paramVisibilityWindowListener);
  }
  
  public boolean back()
  {
    checkWidget();
    return this.webBrowser.back();
  }
  
  protected void checkSubclass()
  {
    String str = getClass().getName();
    int i = str.lastIndexOf('.');
    if (!str.substring(0, i + 1).equals("org.eclipse.swt.browser.")) {
      SWT.error(43);
    }
  }
  
  public boolean execute(String paramString)
  {
    checkWidget();
    if (paramString == null) {
      SWT.error(4);
    }
    return this.webBrowser.execute(paramString);
  }
  
  public boolean close()
  {
    checkWidget();
    if (this.webBrowser.close())
    {
      this.isClosing = true;
      dispose();
      this.isClosing = false;
      return true;
    }
    return false;
  }
  
  public Object evaluate(String paramString)
    throws SWTException
  {
    checkWidget();
    if (paramString == null) {
      SWT.error(4);
    }
    return this.webBrowser.evaluate(paramString);
  }
  
  public boolean forward()
  {
    checkWidget();
    return this.webBrowser.forward();
  }
  
  public String getBrowserType()
  {
    checkWidget();
    return this.webBrowser.getBrowserType();
  }
  
  public boolean getJavascriptEnabled()
  {
    checkWidget();
    return this.webBrowser.jsEnabledOnNextPage;
  }
  
  public int getStyle()
  {
    return super.getStyle() | this.userStyle & 0x800;
  }
  
  public String getText()
  {
    checkWidget();
    return this.webBrowser.getText();
  }
  
  public String getUrl()
  {
    checkWidget();
    return this.webBrowser.getUrl();
  }
  
  public Object getWebBrowser()
  {
    checkWidget();
    return this.webBrowser.getWebBrowser();
  }
  
  public boolean isBackEnabled()
  {
    checkWidget();
    return this.webBrowser.isBackEnabled();
  }
  
  public boolean isFocusControl()
  {
    checkWidget();
    if (this.webBrowser.isFocusControl()) {
      return true;
    }
    return super.isFocusControl();
  }
  
  public boolean isForwardEnabled()
  {
    checkWidget();
    return this.webBrowser.isForwardEnabled();
  }
  
  public void refresh()
  {
    checkWidget();
    this.webBrowser.refresh();
  }
  
  public void removeAuthenticationListener(AuthenticationListener paramAuthenticationListener)
  {
    checkWidget();
    if (paramAuthenticationListener == null) {
      SWT.error(4);
    }
    this.webBrowser.removeAuthenticationListener(paramAuthenticationListener);
  }
  
  public void removeCloseWindowListener(CloseWindowListener paramCloseWindowListener)
  {
    checkWidget();
    if (paramCloseWindowListener == null) {
      SWT.error(4);
    }
    this.webBrowser.removeCloseWindowListener(paramCloseWindowListener);
  }
  
  public void removeLocationListener(LocationListener paramLocationListener)
  {
    checkWidget();
    if (paramLocationListener == null) {
      SWT.error(4);
    }
    this.webBrowser.removeLocationListener(paramLocationListener);
  }
  
  public void removeOpenWindowListener(OpenWindowListener paramOpenWindowListener)
  {
    checkWidget();
    if (paramOpenWindowListener == null) {
      SWT.error(4);
    }
    this.webBrowser.removeOpenWindowListener(paramOpenWindowListener);
  }
  
  public void removeProgressListener(ProgressListener paramProgressListener)
  {
    checkWidget();
    if (paramProgressListener == null) {
      SWT.error(4);
    }
    this.webBrowser.removeProgressListener(paramProgressListener);
  }
  
  public void removeStatusTextListener(StatusTextListener paramStatusTextListener)
  {
    checkWidget();
    if (paramStatusTextListener == null) {
      SWT.error(4);
    }
    this.webBrowser.removeStatusTextListener(paramStatusTextListener);
  }
  
  public void removeTitleListener(TitleListener paramTitleListener)
  {
    checkWidget();
    if (paramTitleListener == null) {
      SWT.error(4);
    }
    this.webBrowser.removeTitleListener(paramTitleListener);
  }
  
  public void removeVisibilityWindowListener(VisibilityWindowListener paramVisibilityWindowListener)
  {
    checkWidget();
    if (paramVisibilityWindowListener == null) {
      SWT.error(4);
    }
    this.webBrowser.removeVisibilityWindowListener(paramVisibilityWindowListener);
  }
  
  public void setJavascriptEnabled(boolean paramBoolean)
  {
    checkWidget();
    this.webBrowser.jsEnabledOnNextPage = paramBoolean;
  }
  
  public boolean setText(String paramString)
  {
    checkWidget();
    return setText(paramString, true);
  }
  
  public boolean setText(String paramString, boolean paramBoolean)
  {
    checkWidget();
    if (paramString == null) {
      SWT.error(4);
    }
    return this.webBrowser.setText(paramString, paramBoolean);
  }
  
  public boolean setUrl(String paramString)
  {
    checkWidget();
    return setUrl(paramString, null, null);
  }
  
  public boolean setUrl(String paramString1, String paramString2, String[] paramArrayOfString)
  {
    checkWidget();
    if (paramString1 == null) {
      SWT.error(4);
    }
    return this.webBrowser.setUrl(paramString1, paramString2, paramArrayOfString);
  }
  
  public void stop()
  {
    checkWidget();
    this.webBrowser.stop();
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/browser/Browser.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */