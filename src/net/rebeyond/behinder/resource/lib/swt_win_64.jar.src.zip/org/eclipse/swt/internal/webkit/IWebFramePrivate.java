package org.eclipse.swt.internal.webkit;

import org.eclipse.swt.internal.ole.win32.COM;
import org.eclipse.swt.internal.ole.win32.IUnknown;

public class IWebFramePrivate
  extends IUnknown
{
  public IWebFramePrivate(long paramLong)
  {
    super(paramLong);
  }
  
  public int setInPrintingMode(int paramInt, long paramLong)
  {
    return COM.VtblCall(8, getAddress(), paramInt, paramLong);
  }
  
  public int getPrintedPageCount(long paramLong, int[] paramArrayOfInt)
  {
    return COM.VtblCall(9, getAddress(), paramLong, paramArrayOfInt);
  }
  
  public int spoolPages(long paramLong, int paramInt1, int paramInt2, long[] paramArrayOfLong)
  {
    return COM.VtblCall(10, getAddress(), paramLong, paramInt1, paramInt2, paramArrayOfLong);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/internal/webkit/IWebFramePrivate.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */