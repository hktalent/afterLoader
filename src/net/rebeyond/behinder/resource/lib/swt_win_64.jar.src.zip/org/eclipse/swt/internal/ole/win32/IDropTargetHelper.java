package org.eclipse.swt.internal.ole.win32;

import org.eclipse.swt.internal.win32.POINT;

public class IDropTargetHelper
  extends IUnknown
{
  public IDropTargetHelper(long paramLong)
  {
    super(paramLong);
  }
  
  public int DragEnter(long paramLong1, long paramLong2, POINT paramPOINT, int paramInt)
  {
    return COM.VtblCall(3, this.address, paramLong1, paramLong2, paramPOINT, paramInt);
  }
  
  public int DragLeave()
  {
    return COM.VtblCall(4, this.address);
  }
  
  public int DragOver(POINT paramPOINT, int paramInt)
  {
    return COM.VtblCall(5, this.address, paramPOINT, paramInt);
  }
  
  public int Drop(long paramLong, POINT paramPOINT, int paramInt)
  {
    return COM.VtblCall(6, this.address, paramLong, paramPOINT, paramInt);
  }
  
  public int Show(boolean paramBoolean)
  {
    return COM.VtblCall(7, this.address, paramBoolean);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/internal/ole/win32/IDropTargetHelper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */