package org.eclipse.swt.browser;

import org.eclipse.swt.SWT;
import org.eclipse.swt.internal.C;
import org.eclipse.swt.internal.Compatibility;
import org.eclipse.swt.internal.mozilla.IIDStore;
import org.eclipse.swt.internal.mozilla.XPCOM;
import org.eclipse.swt.internal.mozilla.XPCOMObject;
import org.eclipse.swt.internal.mozilla.nsICancelable;
import org.eclipse.swt.internal.mozilla.nsID;
import org.eclipse.swt.internal.mozilla.nsISupports;
import org.eclipse.swt.internal.mozilla.nsIURI;
import org.eclipse.swt.internal.mozilla.nsIWebProgressListener;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Shell;

class Download_1_8
{
  XPCOMObject supports;
  XPCOMObject download;
  XPCOMObject progressDialog;
  XPCOMObject webProgressListener;
  nsICancelable cancelable;
  int refCount = 0;
  Shell shell;
  Label status;
  Button cancel;
  static final boolean is32 = C.PTR_SIZEOF == 4;
  
  Download_1_8()
  {
    createCOMInterfaces();
  }
  
  int AddRef()
  {
    this.refCount += 1;
    return this.refCount;
  }
  
  void createCOMInterfaces()
  {
    this.supports = new XPCOMObject(new int[] { 2, 0, 0 })
    {
      public long method0(long[] paramAnonymousArrayOfLong)
      {
        return Download_1_8.this.QueryInterface(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method1(long[] paramAnonymousArrayOfLong)
      {
        return Download_1_8.this.AddRef();
      }
      
      public long method2(long[] paramAnonymousArrayOfLong)
      {
        return Download_1_8.this.Release();
      }
    };
    this.download = new XPCOMObject(new int[] { 2, 0, 0, 4, 6, 3, 4, 3, is32 ? 10 : 6, is32 ? 8 : 7, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 })
    {
      public long method0(long[] paramAnonymousArrayOfLong)
      {
        return Download_1_8.this.QueryInterface(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method1(long[] paramAnonymousArrayOfLong)
      {
        return Download_1_8.this.AddRef();
      }
      
      public long method2(long[] paramAnonymousArrayOfLong)
      {
        return Download_1_8.this.Release();
      }
      
      public long method3(long[] paramAnonymousArrayOfLong)
      {
        return Download_1_8.this.OnStateChange(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], (int)paramAnonymousArrayOfLong[2], (int)paramAnonymousArrayOfLong[3]);
      }
      
      public long method4(long[] paramAnonymousArrayOfLong)
      {
        return Download_1_8.this.OnProgressChange(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], (int)paramAnonymousArrayOfLong[2], (int)paramAnonymousArrayOfLong[3], (int)paramAnonymousArrayOfLong[4], (int)paramAnonymousArrayOfLong[5]);
      }
      
      public long method5(long[] paramAnonymousArrayOfLong)
      {
        return Download_1_8.this.OnLocationChange(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2]);
      }
      
      public long method6(long[] paramAnonymousArrayOfLong)
      {
        return Download_1_8.this.OnStatusChange(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], (int)paramAnonymousArrayOfLong[2], paramAnonymousArrayOfLong[3]);
      }
      
      public long method7(long[] paramAnonymousArrayOfLong)
      {
        return Download_1_8.this.OnSecurityChange(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], (int)paramAnonymousArrayOfLong[2]);
      }
      
      public long method8(long[] paramAnonymousArrayOfLong)
      {
        if (paramAnonymousArrayOfLong.length == 10) {
          return Download_1_8.this.OnProgressChange64_32(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2], paramAnonymousArrayOfLong[3], paramAnonymousArrayOfLong[4], paramAnonymousArrayOfLong[5], paramAnonymousArrayOfLong[6], paramAnonymousArrayOfLong[7], paramAnonymousArrayOfLong[8], paramAnonymousArrayOfLong[9]);
        }
        return Download_1_8.this.OnProgressChange64(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2], paramAnonymousArrayOfLong[3], paramAnonymousArrayOfLong[4], paramAnonymousArrayOfLong[5]);
      }
      
      public long method9(long[] paramAnonymousArrayOfLong)
      {
        if (paramAnonymousArrayOfLong.length == 8) {
          return Download_1_8.this.Init_32(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2], paramAnonymousArrayOfLong[3], paramAnonymousArrayOfLong[4], paramAnonymousArrayOfLong[5], paramAnonymousArrayOfLong[6], paramAnonymousArrayOfLong[7]);
        }
        return Download_1_8.this.Init(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2], paramAnonymousArrayOfLong[3], paramAnonymousArrayOfLong[4], paramAnonymousArrayOfLong[5], paramAnonymousArrayOfLong[6]);
      }
      
      public long method10(long[] paramAnonymousArrayOfLong)
      {
        return Download_1_8.this.GetTargetFile(paramAnonymousArrayOfLong[0]);
      }
      
      public long method11(long[] paramAnonymousArrayOfLong)
      {
        return Download_1_8.this.GetPercentComplete(paramAnonymousArrayOfLong[0]);
      }
      
      public long method12(long[] paramAnonymousArrayOfLong)
      {
        return Download_1_8.this.GetAmountTransferred(paramAnonymousArrayOfLong[0]);
      }
      
      public long method13(long[] paramAnonymousArrayOfLong)
      {
        return Download_1_8.this.GetSize(paramAnonymousArrayOfLong[0]);
      }
      
      public long method14(long[] paramAnonymousArrayOfLong)
      {
        return Download_1_8.this.GetSource(paramAnonymousArrayOfLong[0]);
      }
      
      public long method15(long[] paramAnonymousArrayOfLong)
      {
        return Download_1_8.this.GetTarget(paramAnonymousArrayOfLong[0]);
      }
      
      public long method16(long[] paramAnonymousArrayOfLong)
      {
        return Download_1_8.this.GetCancelable(paramAnonymousArrayOfLong[0]);
      }
      
      public long method17(long[] paramAnonymousArrayOfLong)
      {
        return Download_1_8.this.GetDisplayName(paramAnonymousArrayOfLong[0]);
      }
      
      public long method18(long[] paramAnonymousArrayOfLong)
      {
        return Download_1_8.this.GetStartTime(paramAnonymousArrayOfLong[0]);
      }
      
      public long method19(long[] paramAnonymousArrayOfLong)
      {
        return Download_1_8.this.GetMIMEInfo(paramAnonymousArrayOfLong[0]);
      }
    };
    this.progressDialog = new XPCOMObject(new int[] { 2, 0, 0, 4, 6, 3, 4, 3, is32 ? 10 : 6, is32 ? 8 : 7, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 })
    {
      public long method0(long[] paramAnonymousArrayOfLong)
      {
        return Download_1_8.this.QueryInterface(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method1(long[] paramAnonymousArrayOfLong)
      {
        return Download_1_8.this.AddRef();
      }
      
      public long method2(long[] paramAnonymousArrayOfLong)
      {
        return Download_1_8.this.Release();
      }
      
      public long method3(long[] paramAnonymousArrayOfLong)
      {
        return Download_1_8.this.OnStateChange(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], (int)paramAnonymousArrayOfLong[2], (int)paramAnonymousArrayOfLong[3]);
      }
      
      public long method4(long[] paramAnonymousArrayOfLong)
      {
        return Download_1_8.this.OnProgressChange(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], (int)paramAnonymousArrayOfLong[2], (int)paramAnonymousArrayOfLong[3], (int)paramAnonymousArrayOfLong[4], (int)paramAnonymousArrayOfLong[5]);
      }
      
      public long method5(long[] paramAnonymousArrayOfLong)
      {
        return Download_1_8.this.OnLocationChange(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2]);
      }
      
      public long method6(long[] paramAnonymousArrayOfLong)
      {
        return Download_1_8.this.OnStatusChange(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], (int)paramAnonymousArrayOfLong[2], paramAnonymousArrayOfLong[3]);
      }
      
      public long method7(long[] paramAnonymousArrayOfLong)
      {
        return Download_1_8.this.OnSecurityChange(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], (int)paramAnonymousArrayOfLong[2]);
      }
      
      public long method8(long[] paramAnonymousArrayOfLong)
      {
        if (paramAnonymousArrayOfLong.length == 10) {
          return Download_1_8.this.OnProgressChange64_32(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2], paramAnonymousArrayOfLong[3], paramAnonymousArrayOfLong[4], paramAnonymousArrayOfLong[5], paramAnonymousArrayOfLong[6], paramAnonymousArrayOfLong[7], paramAnonymousArrayOfLong[8], paramAnonymousArrayOfLong[9]);
        }
        return Download_1_8.this.OnProgressChange64(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2], paramAnonymousArrayOfLong[3], paramAnonymousArrayOfLong[4], paramAnonymousArrayOfLong[5]);
      }
      
      public long method9(long[] paramAnonymousArrayOfLong)
      {
        if (paramAnonymousArrayOfLong.length == 8) {
          return Download_1_8.this.Init_32(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2], paramAnonymousArrayOfLong[3], paramAnonymousArrayOfLong[4], paramAnonymousArrayOfLong[5], paramAnonymousArrayOfLong[6], paramAnonymousArrayOfLong[7]);
        }
        return Download_1_8.this.Init(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2], paramAnonymousArrayOfLong[3], paramAnonymousArrayOfLong[4], paramAnonymousArrayOfLong[5], paramAnonymousArrayOfLong[6]);
      }
      
      public long method10(long[] paramAnonymousArrayOfLong)
      {
        return Download_1_8.this.GetTargetFile(paramAnonymousArrayOfLong[0]);
      }
      
      public long method11(long[] paramAnonymousArrayOfLong)
      {
        return Download_1_8.this.GetPercentComplete(paramAnonymousArrayOfLong[0]);
      }
      
      public long method12(long[] paramAnonymousArrayOfLong)
      {
        return Download_1_8.this.GetAmountTransferred(paramAnonymousArrayOfLong[0]);
      }
      
      public long method13(long[] paramAnonymousArrayOfLong)
      {
        return Download_1_8.this.GetSize(paramAnonymousArrayOfLong[0]);
      }
      
      public long method14(long[] paramAnonymousArrayOfLong)
      {
        return Download_1_8.this.GetSource(paramAnonymousArrayOfLong[0]);
      }
      
      public long method15(long[] paramAnonymousArrayOfLong)
      {
        return Download_1_8.this.GetTarget(paramAnonymousArrayOfLong[0]);
      }
      
      public long method16(long[] paramAnonymousArrayOfLong)
      {
        return Download_1_8.this.GetCancelable(paramAnonymousArrayOfLong[0]);
      }
      
      public long method17(long[] paramAnonymousArrayOfLong)
      {
        return Download_1_8.this.GetDisplayName(paramAnonymousArrayOfLong[0]);
      }
      
      public long method18(long[] paramAnonymousArrayOfLong)
      {
        return Download_1_8.this.GetStartTime(paramAnonymousArrayOfLong[0]);
      }
      
      public long method19(long[] paramAnonymousArrayOfLong)
      {
        return Download_1_8.this.GetMIMEInfo(paramAnonymousArrayOfLong[0]);
      }
      
      public long method20(long[] paramAnonymousArrayOfLong)
      {
        return Download_1_8.this.Open(paramAnonymousArrayOfLong[0]);
      }
      
      public long method21(long[] paramAnonymousArrayOfLong)
      {
        return Download_1_8.this.GetCancelDownloadOnClose(paramAnonymousArrayOfLong[0]);
      }
      
      public long method22(long[] paramAnonymousArrayOfLong)
      {
        return Download_1_8.this.SetCancelDownloadOnClose((int)paramAnonymousArrayOfLong[0]);
      }
      
      public long method23(long[] paramAnonymousArrayOfLong)
      {
        return Download_1_8.this.GetObserver(paramAnonymousArrayOfLong[0]);
      }
      
      public long method24(long[] paramAnonymousArrayOfLong)
      {
        return Download_1_8.this.SetObserver(paramAnonymousArrayOfLong[0]);
      }
      
      public long method25(long[] paramAnonymousArrayOfLong)
      {
        return Download_1_8.this.GetDialog(paramAnonymousArrayOfLong[0]);
      }
      
      public long method26(long[] paramAnonymousArrayOfLong)
      {
        return Download_1_8.this.SetDialog(paramAnonymousArrayOfLong[0]);
      }
    };
    this.webProgressListener = new XPCOMObject(new int[] { 2, 0, 0, 4, 6, 3, 4, 3 })
    {
      public long method0(long[] paramAnonymousArrayOfLong)
      {
        return Download_1_8.this.QueryInterface(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method1(long[] paramAnonymousArrayOfLong)
      {
        return Download_1_8.this.AddRef();
      }
      
      public long method2(long[] paramAnonymousArrayOfLong)
      {
        return Download_1_8.this.Release();
      }
      
      public long method3(long[] paramAnonymousArrayOfLong)
      {
        return Download_1_8.this.OnStateChange(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], (int)paramAnonymousArrayOfLong[2], (int)paramAnonymousArrayOfLong[3]);
      }
      
      public long method4(long[] paramAnonymousArrayOfLong)
      {
        return Download_1_8.this.OnProgressChange(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], (int)paramAnonymousArrayOfLong[2], (int)paramAnonymousArrayOfLong[3], (int)paramAnonymousArrayOfLong[4], (int)paramAnonymousArrayOfLong[5]);
      }
      
      public long method5(long[] paramAnonymousArrayOfLong)
      {
        return Download_1_8.this.OnLocationChange(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2]);
      }
      
      public long method6(long[] paramAnonymousArrayOfLong)
      {
        return Download_1_8.this.OnStatusChange(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], (int)paramAnonymousArrayOfLong[2], paramAnonymousArrayOfLong[3]);
      }
      
      public long method7(long[] paramAnonymousArrayOfLong)
      {
        return Download_1_8.this.OnSecurityChange(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], (int)paramAnonymousArrayOfLong[2]);
      }
    };
  }
  
  void disposeCOMInterfaces()
  {
    if (this.supports != null)
    {
      this.supports.dispose();
      this.supports = null;
    }
    if (this.download != null)
    {
      this.download.dispose();
      this.download = null;
    }
    if (this.progressDialog != null)
    {
      this.progressDialog.dispose();
      this.progressDialog = null;
    }
    if (this.webProgressListener != null)
    {
      this.webProgressListener.dispose();
      this.webProgressListener = null;
    }
  }
  
  long getAddress()
  {
    return this.progressDialog.getAddress();
  }
  
  int QueryInterface(long paramLong1, long paramLong2)
  {
    if ((paramLong1 == 0L) || (paramLong2 == 0L)) {
      return -2147467262;
    }
    nsID localnsID = new nsID();
    XPCOM.memmove(localnsID, paramLong1, 16);
    if (localnsID.Equals(IIDStore.GetIID(nsISupports.class)))
    {
      XPCOM.memmove(paramLong2, new long[] { this.supports.getAddress() }, C.PTR_SIZEOF);
      AddRef();
      return 0;
    }
    if (localnsID.Equals(XPCOM.NS_IDOWNLOAD_1_8_IID))
    {
      XPCOM.memmove(paramLong2, new long[] { this.download.getAddress() }, C.PTR_SIZEOF);
      AddRef();
      return 0;
    }
    if (localnsID.Equals(XPCOM.NS_IPROGRESSDIALOG_1_8_IID))
    {
      XPCOM.memmove(paramLong2, new long[] { this.progressDialog.getAddress() }, C.PTR_SIZEOF);
      AddRef();
      return 0;
    }
    if (localnsID.Equals(IIDStore.GetIID(nsIWebProgressListener.class)))
    {
      XPCOM.memmove(paramLong2, new long[] { this.webProgressListener.getAddress() }, C.PTR_SIZEOF);
      AddRef();
      return 0;
    }
    XPCOM.memmove(paramLong2, new long[] { 0L }, C.PTR_SIZEOF);
    return -2147467262;
  }
  
  int Release()
  {
    this.refCount -= 1;
    if (this.refCount == 0) {
      disposeCOMInterfaces();
    }
    return this.refCount;
  }
  
  int Init_32(long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5, long paramLong6, long paramLong7, long paramLong8)
  {
    long l = (paramLong6 << 32) + paramLong5;
    return Init(paramLong1, paramLong2, paramLong3, paramLong4, l, paramLong7, paramLong8);
  }
  
  int Init(long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5, long paramLong6, long paramLong7)
  {
    this.cancelable = new nsICancelable(paramLong7);
    nsIURI localnsIURI1 = new nsIURI(paramLong1);
    long l1 = XPCOM.nsEmbedCString_new();
    int i = localnsIURI1.GetHost(l1);
    if (i != 0) {
      Mozilla.error(i);
    }
    int j = XPCOM.nsEmbedCString_Length(l1);
    long l2 = XPCOM.nsEmbedCString_get(l1);
    byte[] arrayOfByte = new byte[j];
    XPCOM.memmove(arrayOfByte, l2, j);
    XPCOM.nsEmbedCString_delete(l1);
    String str1 = new String(arrayOfByte);
    nsIURI localnsIURI2 = new nsIURI(paramLong2);
    long l3 = XPCOM.nsEmbedCString_new();
    i = localnsIURI2.GetPath(l3);
    if (i != 0) {
      Mozilla.error(i);
    }
    j = XPCOM.nsEmbedCString_Length(l3);
    l2 = XPCOM.nsEmbedCString_get(l3);
    arrayOfByte = new byte[j];
    XPCOM.memmove(arrayOfByte, l2, j);
    XPCOM.nsEmbedCString_delete(l3);
    String str2 = new String(arrayOfByte);
    int k = str2.lastIndexOf(System.getProperty("file.separator"));
    str2 = str2.substring(k + 1);
    Listener local5 = new Listener()
    {
      public void handleEvent(Event paramAnonymousEvent)
      {
        if (paramAnonymousEvent.widget == Download_1_8.this.cancel) {
          Download_1_8.this.shell.close();
        }
        if (Download_1_8.this.cancelable != null)
        {
          int i = Download_1_8.this.cancelable.Cancel(-2142568446);
          if (i != 0) {
            Mozilla.error(i);
          }
        }
        Download_1_8.this.shell = null;
        Download_1_8.this.cancelable = null;
      }
    };
    this.shell = new Shell(2144);
    String str3 = Compatibility.getMessage("SWT_Download_File", new Object[] { str2 });
    this.shell.setText(str3);
    GridLayout localGridLayout = new GridLayout();
    localGridLayout.marginHeight = 15;
    localGridLayout.marginWidth = 15;
    localGridLayout.verticalSpacing = 20;
    this.shell.setLayout(localGridLayout);
    str3 = Compatibility.getMessage("SWT_Download_Location", new Object[] { str2, str1 });
    new Label(this.shell, 64).setText(str3);
    this.status = new Label(this.shell, 64);
    str3 = Compatibility.getMessage("SWT_Download_Started");
    this.status.setText(str3);
    GridData localGridData = new GridData();
    localGridData.grabExcessHorizontalSpace = true;
    localGridData.grabExcessVerticalSpace = true;
    this.status.setLayoutData(localGridData);
    this.cancel = new Button(this.shell, 8);
    this.cancel.setText(SWT.getMessage("SWT_Cancel"));
    localGridData = new GridData();
    localGridData.horizontalAlignment = 2;
    this.cancel.setLayoutData(localGridData);
    this.cancel.addListener(13, local5);
    this.shell.addListener(21, local5);
    this.shell.pack();
    this.shell.open();
    return 0;
  }
  
  int GetAmountTransferred(long paramLong)
  {
    return -2147467263;
  }
  
  int GetCancelable(long paramLong)
  {
    return -2147467263;
  }
  
  int GetDisplayName(long paramLong)
  {
    return -2147467263;
  }
  
  int GetMIMEInfo(long paramLong)
  {
    return -2147467263;
  }
  
  int GetPercentComplete(long paramLong)
  {
    return -2147467263;
  }
  
  int GetSize(long paramLong)
  {
    return -2147467263;
  }
  
  int GetSource(long paramLong)
  {
    return -2147467263;
  }
  
  int GetStartTime(long paramLong)
  {
    return -2147467263;
  }
  
  int GetTarget(long paramLong)
  {
    return -2147467263;
  }
  
  int GetTargetFile(long paramLong)
  {
    return -2147467263;
  }
  
  int GetCancelDownloadOnClose(long paramLong)
  {
    return -2147467263;
  }
  
  int GetDialog(long paramLong)
  {
    return -2147467263;
  }
  
  int GetObserver(long paramLong)
  {
    return -2147467263;
  }
  
  int Open(long paramLong)
  {
    return -2147467263;
  }
  
  int SetCancelDownloadOnClose(int paramInt)
  {
    return -2147467263;
  }
  
  int SetDialog(long paramLong)
  {
    return -2147467263;
  }
  
  int SetObserver(long paramLong)
  {
    return -2147467263;
  }
  
  int OnLocationChange(long paramLong1, long paramLong2, long paramLong3)
  {
    return 0;
  }
  
  int OnProgressChange(long paramLong1, long paramLong2, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    return OnProgressChange64(paramLong1, paramLong2, paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  int OnProgressChange64_32(long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5, long paramLong6, long paramLong7, long paramLong8, long paramLong9, long paramLong10)
  {
    long l1 = (paramLong4 << 32) + paramLong3;
    long l2 = (paramLong6 << 32) + paramLong5;
    long l3 = (paramLong8 << 32) + paramLong7;
    long l4 = (paramLong10 << 32) + paramLong9;
    return OnProgressChange64(paramLong1, paramLong2, l1, l2, l3, l4);
  }
  
  int OnProgressChange64(long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5, long paramLong6)
  {
    long l1 = paramLong5 / 1024L;
    long l2 = paramLong6 / 1024L;
    if ((this.shell != null) && (!this.shell.isDisposed()))
    {
      Object[] arrayOfObject = { new Long(l1), new Long(l2) };
      String str = Compatibility.getMessage("SWT_Download_Status", arrayOfObject);
      this.status.setText(str);
      this.shell.layout(true);
      this.shell.getDisplay().update();
    }
    return 0;
  }
  
  int OnSecurityChange(long paramLong1, long paramLong2, int paramInt)
  {
    return 0;
  }
  
  int OnStateChange(long paramLong1, long paramLong2, int paramInt1, int paramInt2)
  {
    if ((paramInt1 & 0x10) != 0)
    {
      this.cancelable = null;
      if ((this.shell != null) && (!this.shell.isDisposed())) {
        this.shell.dispose();
      }
      this.shell = null;
    }
    return 0;
  }
  
  int OnStatusChange(long paramLong1, long paramLong2, int paramInt, long paramLong3)
  {
    return 0;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/browser/Download_1_8.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */