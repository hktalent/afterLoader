package org.eclipse.swt.internal.mozilla;

public class nsIIOService
  extends nsISupports
{
  static final int LAST_METHOD_ID = nsISupports.LAST_METHOD_ID + 10;
  static final String NS_IIOSERVICE_IID_STR = "bddeda3f-9020-4d12-8c70-984ee9f7935e";
  
  public nsIIOService(long paramLong)
  {
    super(paramLong);
  }
  
  public int NewURI(long paramLong1, byte[] paramArrayOfByte, long paramLong2, long[] paramArrayOfLong)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 3, getAddress(), paramLong1, paramArrayOfByte, paramLong2, paramArrayOfLong);
  }
  
  static
  {
    IIDStore.RegisterIID(nsIIOService.class, 0, new nsID("bddeda3f-9020-4d12-8c70-984ee9f7935e"));
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/internal/mozilla/nsIIOService.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */