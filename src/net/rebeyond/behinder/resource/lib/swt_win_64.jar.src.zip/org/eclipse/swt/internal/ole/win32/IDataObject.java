package org.eclipse.swt.internal.ole.win32;

public class IDataObject
  extends IUnknown
{
  public IDataObject(long paramLong)
  {
    super(paramLong);
  }
  
  public int EnumFormatEtc(int paramInt, long[] paramArrayOfLong)
  {
    return COM.VtblCall(8, this.address, paramInt, paramArrayOfLong);
  }
  
  public int GetData(FORMATETC paramFORMATETC, STGMEDIUM paramSTGMEDIUM)
  {
    return COM.VtblCall(3, this.address, paramFORMATETC, paramSTGMEDIUM);
  }
  
  public int GetDataHere(FORMATETC paramFORMATETC, STGMEDIUM paramSTGMEDIUM)
  {
    return COM.VtblCall(4, this.address, paramFORMATETC, paramSTGMEDIUM);
  }
  
  public int QueryGetData(FORMATETC paramFORMATETC)
  {
    return COM.VtblCall(5, this.address, paramFORMATETC);
  }
  
  public int SetData(FORMATETC paramFORMATETC, STGMEDIUM paramSTGMEDIUM, boolean paramBoolean)
  {
    return COM.VtblCall(7, this.address, paramFORMATETC, paramSTGMEDIUM, paramBoolean);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/internal/ole/win32/IDataObject.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */