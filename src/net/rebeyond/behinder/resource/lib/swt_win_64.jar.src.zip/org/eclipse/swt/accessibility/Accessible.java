package org.eclipse.swt.accessibility;

import java.util.Locale;
import java.util.Vector;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.FontData;
import org.eclipse.swt.graphics.TextStyle;
import org.eclipse.swt.internal.ole.win32.COM;
import org.eclipse.swt.internal.ole.win32.COMObject;
import org.eclipse.swt.internal.ole.win32.GUID;
import org.eclipse.swt.internal.ole.win32.IAccessible;
import org.eclipse.swt.internal.ole.win32.IEnumVARIANT;
import org.eclipse.swt.internal.ole.win32.IServiceProvider;
import org.eclipse.swt.internal.ole.win32.VARIANT;
import org.eclipse.swt.internal.win32.LOGFONT;
import org.eclipse.swt.internal.win32.OS;
import org.eclipse.swt.internal.win32.TVITEM;
import org.eclipse.swt.ole.win32.OLE;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.TabFolder;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.ToolBar;
import org.eclipse.swt.widgets.ToolItem;
import org.eclipse.swt.widgets.Tree;
import org.eclipse.swt.widgets.TreeColumn;
import org.eclipse.swt.widgets.TreeItem;
import org.eclipse.swt.widgets.Widget;

public class Accessible
{
  static final int MAX_RELATION_TYPES = 15;
  static final int TABLE_MODEL_CHANGE_SIZE = 5;
  static final int TEXT_CHANGE_SIZE = 4;
  static final int SCROLL_RATE = 100;
  static final boolean DEBUG = false;
  static final String PROPERTY_USEIA2 = "org.eclipse.swt.accessibility.UseIA2";
  static boolean UseIA2 = true;
  static int UniqueID = -16;
  int refCount = 0;
  int enumIndex = 0;
  Runnable timer;
  COMObject objIAccessible;
  COMObject objIEnumVARIANT;
  COMObject objIServiceProvider;
  COMObject objIAccessible2;
  COMObject objIAccessibleAction;
  COMObject objIAccessibleApplication;
  COMObject objIAccessibleEditableText;
  COMObject objIAccessibleHyperlink;
  COMObject objIAccessibleHypertext;
  COMObject objIAccessibleTable2;
  COMObject objIAccessibleTableCell;
  COMObject objIAccessibleText;
  COMObject objIAccessibleValue;
  IAccessible iaccessible;
  Vector accessibleListeners;
  Vector accessibleControlListeners;
  Vector accessibleTextListeners;
  Vector accessibleActionListeners;
  Vector accessibleEditableTextListeners;
  Vector accessibleHyperlinkListeners;
  Vector accessibleTableListeners;
  Vector accessibleTableCellListeners;
  Vector accessibleTextExtendedListeners;
  Vector accessibleValueListeners;
  Vector accessibleAttributeListeners;
  Relation[] relations = new Relation[15];
  Object[] variants;
  Accessible parent;
  Vector children = new Vector();
  Control control;
  int uniqueID = -1;
  int[] tableChange;
  Object[] textDeleted;
  Object[] textInserted;
  ToolItem item;
  
  public Accessible(Accessible paramAccessible)
  {
    this.parent = checkNull(paramAccessible);
    this.control = paramAccessible.control;
    paramAccessible.children.addElement(this);
    AddRef();
  }
  
  /**
   * @deprecated
   */
  protected Accessible() {}
  
  Accessible(Control paramControl)
  {
    this.control = paramControl;
    long[] arrayOfLong = new long[1];
    int i = COM.CreateStdAccessibleObject(paramControl.handle, -4, COM.IIDIAccessible, arrayOfLong);
    if (arrayOfLong[0] == 0L) {
      return;
    }
    if (i != 0) {
      OLE.error(1001, i);
    }
    this.iaccessible = new IAccessible(arrayOfLong[0]);
    createIAccessible();
    AddRef();
  }
  
  Accessible(Accessible paramAccessible, long paramLong)
  {
    this(paramAccessible);
    this.iaccessible = new IAccessible(paramLong);
  }
  
  static Accessible checkNull(Accessible paramAccessible)
  {
    if (paramAccessible == null) {
      SWT.error(4);
    }
    return paramAccessible;
  }
  
  void createIAccessible()
  {
    this.objIAccessible = new COMObject(new int[] { 2, 0, 0, 1, 3, 5, 8, 1, 1, 2, 2, 2, 2, 2, 2, 2, 3, 2, 1, 1, 2, 2, 5, 3, 3, 1, 2, 2 })
    {
      public long method0(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.QueryInterface(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method1(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.AddRef();
      }
      
      public long method2(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.Release();
      }
      
      public long method7(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_accParent(paramAnonymousArrayOfLong[0]);
      }
      
      public long method8(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_accChildCount(paramAnonymousArrayOfLong[0]);
      }
      
      public long method9(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_accChild(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method10(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_accName(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method11(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_accValue(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method12(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_accDescription(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method13(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_accRole(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method14(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_accState(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method15(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_accHelp(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method16(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_accHelpTopic(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2]);
      }
      
      public long method17(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_accKeyboardShortcut(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method18(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_accFocus(paramAnonymousArrayOfLong[0]);
      }
      
      public long method19(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_accSelection(paramAnonymousArrayOfLong[0]);
      }
      
      public long method20(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_accDefaultAction(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method21(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.accSelect((int)paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method22(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.accLocation(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2], paramAnonymousArrayOfLong[3], paramAnonymousArrayOfLong[4]);
      }
      
      public long method23(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.accNavigate((int)paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2]);
      }
      
      public long method24(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.accHitTest((int)paramAnonymousArrayOfLong[0], (int)paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2]);
      }
      
      public long method25(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.accDoDefaultAction(paramAnonymousArrayOfLong[0]);
      }
      
      public long method26(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.put_accName(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method27(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.put_accValue(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
    };
    long l = this.objIAccessible.ppVtable;
    long[] arrayOfLong1 = new long[1];
    COM.MoveMemory(arrayOfLong1, l, OS.PTR_SIZEOF);
    long[] arrayOfLong2 = new long[28];
    COM.MoveMemory(arrayOfLong2, arrayOfLong1[0], OS.PTR_SIZEOF * arrayOfLong2.length);
    arrayOfLong2[9] = COM.get_accChild_CALLBACK(arrayOfLong2[9]);
    arrayOfLong2[10] = COM.get_accName_CALLBACK(arrayOfLong2[10]);
    arrayOfLong2[11] = COM.get_accValue_CALLBACK(arrayOfLong2[11]);
    arrayOfLong2[12] = COM.get_accDescription_CALLBACK(arrayOfLong2[12]);
    arrayOfLong2[13] = COM.get_accRole_CALLBACK(arrayOfLong2[13]);
    arrayOfLong2[14] = COM.get_accState_CALLBACK(arrayOfLong2[14]);
    arrayOfLong2[15] = COM.get_accHelp_CALLBACK(arrayOfLong2[15]);
    arrayOfLong2[16] = COM.get_accHelpTopic_CALLBACK(arrayOfLong2[16]);
    arrayOfLong2[17] = COM.get_accKeyboardShortcut_CALLBACK(arrayOfLong2[17]);
    arrayOfLong2[20] = COM.get_accDefaultAction_CALLBACK(arrayOfLong2[20]);
    arrayOfLong2[21] = COM.accSelect_CALLBACK(arrayOfLong2[21]);
    arrayOfLong2[22] = COM.accLocation_CALLBACK(arrayOfLong2[22]);
    arrayOfLong2[23] = COM.accNavigate_CALLBACK(arrayOfLong2[23]);
    arrayOfLong2[25] = COM.accDoDefaultAction_CALLBACK(arrayOfLong2[25]);
    arrayOfLong2[26] = COM.put_accName_CALLBACK(arrayOfLong2[26]);
    arrayOfLong2[27] = COM.put_accValue_CALLBACK(arrayOfLong2[27]);
    COM.MoveMemory(arrayOfLong1[0], arrayOfLong2, OS.PTR_SIZEOF * arrayOfLong2.length);
  }
  
  void createIAccessible2()
  {
    this.objIAccessible2 = new COMObject(new int[] { 2, 0, 0, 1, 3, 5, 8, 1, 1, 2, 2, 2, 2, 2, 2, 2, 3, 2, 1, 1, 2, 2, 5, 3, 3, 1, 2, 2, 1, 2, 3, 1, 1, 3, 3, 1, 1, 1, 1, 3, 3, 1, 1, 1, 1, 1 })
    {
      public long method0(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.QueryInterface(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method1(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.AddRef();
      }
      
      public long method2(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.Release();
      }
      
      public long method7(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_accParent(paramAnonymousArrayOfLong[0]);
      }
      
      public long method8(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_accChildCount(paramAnonymousArrayOfLong[0]);
      }
      
      public long method9(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_accChild(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method10(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_accName(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method11(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_accValue(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method12(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_accDescription(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method13(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_accRole(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method14(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_accState(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method15(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_accHelp(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method16(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_accHelpTopic(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2]);
      }
      
      public long method17(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_accKeyboardShortcut(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method18(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_accFocus(paramAnonymousArrayOfLong[0]);
      }
      
      public long method19(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_accSelection(paramAnonymousArrayOfLong[0]);
      }
      
      public long method20(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_accDefaultAction(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method21(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.accSelect((int)paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method22(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.accLocation(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2], paramAnonymousArrayOfLong[3], paramAnonymousArrayOfLong[4]);
      }
      
      public long method23(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.accNavigate((int)paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2]);
      }
      
      public long method24(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.accHitTest((int)paramAnonymousArrayOfLong[0], (int)paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2]);
      }
      
      public long method25(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.accDoDefaultAction(paramAnonymousArrayOfLong[0]);
      }
      
      public long method26(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.put_accName(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method27(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.put_accValue(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method28(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_nRelations(paramAnonymousArrayOfLong[0]);
      }
      
      public long method29(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_relation((int)paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method30(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_relations((int)paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2]);
      }
      
      public long method31(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_role(paramAnonymousArrayOfLong[0]);
      }
      
      public long method32(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.scrollTo((int)paramAnonymousArrayOfLong[0]);
      }
      
      public long method33(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.scrollToPoint((int)paramAnonymousArrayOfLong[0], (int)paramAnonymousArrayOfLong[1], (int)paramAnonymousArrayOfLong[2]);
      }
      
      public long method34(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_groupPosition(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2]);
      }
      
      public long method35(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_states(paramAnonymousArrayOfLong[0]);
      }
      
      public long method36(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_extendedRole(paramAnonymousArrayOfLong[0]);
      }
      
      public long method37(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_localizedExtendedRole(paramAnonymousArrayOfLong[0]);
      }
      
      public long method38(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_nExtendedStates(paramAnonymousArrayOfLong[0]);
      }
      
      public long method39(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_extendedStates((int)paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2]);
      }
      
      public long method40(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_localizedExtendedStates((int)paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2]);
      }
      
      public long method41(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_uniqueID(paramAnonymousArrayOfLong[0]);
      }
      
      public long method42(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_windowHandle(paramAnonymousArrayOfLong[0]);
      }
      
      public long method43(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_indexInParent(paramAnonymousArrayOfLong[0]);
      }
      
      public long method44(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_locale(paramAnonymousArrayOfLong[0]);
      }
      
      public long method45(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_attributes(paramAnonymousArrayOfLong[0]);
      }
    };
    long l = this.objIAccessible2.ppVtable;
    long[] arrayOfLong1 = new long[1];
    COM.MoveMemory(arrayOfLong1, l, OS.PTR_SIZEOF);
    long[] arrayOfLong2 = new long[28];
    COM.MoveMemory(arrayOfLong2, arrayOfLong1[0], OS.PTR_SIZEOF * arrayOfLong2.length);
    arrayOfLong2[9] = COM.get_accChild_CALLBACK(arrayOfLong2[9]);
    arrayOfLong2[10] = COM.get_accName_CALLBACK(arrayOfLong2[10]);
    arrayOfLong2[11] = COM.get_accValue_CALLBACK(arrayOfLong2[11]);
    arrayOfLong2[12] = COM.get_accDescription_CALLBACK(arrayOfLong2[12]);
    arrayOfLong2[13] = COM.get_accRole_CALLBACK(arrayOfLong2[13]);
    arrayOfLong2[14] = COM.get_accState_CALLBACK(arrayOfLong2[14]);
    arrayOfLong2[15] = COM.get_accHelp_CALLBACK(arrayOfLong2[15]);
    arrayOfLong2[16] = COM.get_accHelpTopic_CALLBACK(arrayOfLong2[16]);
    arrayOfLong2[17] = COM.get_accKeyboardShortcut_CALLBACK(arrayOfLong2[17]);
    arrayOfLong2[20] = COM.get_accDefaultAction_CALLBACK(arrayOfLong2[20]);
    arrayOfLong2[21] = COM.accSelect_CALLBACK(arrayOfLong2[21]);
    arrayOfLong2[22] = COM.accLocation_CALLBACK(arrayOfLong2[22]);
    arrayOfLong2[23] = COM.accNavigate_CALLBACK(arrayOfLong2[23]);
    arrayOfLong2[25] = COM.accDoDefaultAction_CALLBACK(arrayOfLong2[25]);
    arrayOfLong2[26] = COM.put_accName_CALLBACK(arrayOfLong2[26]);
    arrayOfLong2[27] = COM.put_accValue_CALLBACK(arrayOfLong2[27]);
    COM.MoveMemory(arrayOfLong1[0], arrayOfLong2, OS.PTR_SIZEOF * arrayOfLong2.length);
  }
  
  void createIAccessibleAction()
  {
    this.objIAccessibleAction = new COMObject(new int[] { 2, 0, 0, 1, 1, 2, 4, 2, 2 })
    {
      public long method0(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.QueryInterface(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method1(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.AddRef();
      }
      
      public long method2(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.Release();
      }
      
      public long method3(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_nActions(paramAnonymousArrayOfLong[0]);
      }
      
      public long method4(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.doAction((int)paramAnonymousArrayOfLong[0]);
      }
      
      public long method5(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_description((int)paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method6(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_keyBinding((int)paramAnonymousArrayOfLong[0], (int)paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2], paramAnonymousArrayOfLong[3]);
      }
      
      public long method7(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_name((int)paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method8(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_localizedName((int)paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
    };
  }
  
  void createIAccessibleApplication()
  {
    this.objIAccessibleApplication = new COMObject(new int[] { 2, 0, 0, 1, 1, 1, 1 })
    {
      public long method0(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.QueryInterface(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method1(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.AddRef();
      }
      
      public long method2(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.Release();
      }
      
      public long method3(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_appName(paramAnonymousArrayOfLong[0]);
      }
      
      public long method4(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_appVersion(paramAnonymousArrayOfLong[0]);
      }
      
      public long method5(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_toolkitName(paramAnonymousArrayOfLong[0]);
      }
      
      public long method6(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_toolkitVersion(paramAnonymousArrayOfLong[0]);
      }
    };
  }
  
  void createIAccessibleEditableText()
  {
    this.objIAccessibleEditableText = new COMObject(new int[] { 2, 0, 0, 2, 2, 2, 2, 1, 3, 3 })
    {
      public long method0(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.QueryInterface(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method1(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.AddRef();
      }
      
      public long method2(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.Release();
      }
      
      public long method3(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.copyText((int)paramAnonymousArrayOfLong[0], (int)paramAnonymousArrayOfLong[1]);
      }
      
      public long method4(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.deleteText((int)paramAnonymousArrayOfLong[0], (int)paramAnonymousArrayOfLong[1]);
      }
      
      public long method5(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.insertText((int)paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method6(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.cutText((int)paramAnonymousArrayOfLong[0], (int)paramAnonymousArrayOfLong[1]);
      }
      
      public long method7(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.pasteText((int)paramAnonymousArrayOfLong[0]);
      }
      
      public long method8(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.replaceText((int)paramAnonymousArrayOfLong[0], (int)paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2]);
      }
      
      public long method9(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.setAttributes((int)paramAnonymousArrayOfLong[0], (int)paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2]);
      }
    };
  }
  
  void createIAccessibleHyperlink()
  {
    this.objIAccessibleHyperlink = new COMObject(new int[] { 2, 0, 0, 1, 1, 2, 4, 2, 2, 2, 2, 1, 1, 1 })
    {
      public long method0(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.QueryInterface(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method1(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.AddRef();
      }
      
      public long method2(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.Release();
      }
      
      public long method3(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_nActions(paramAnonymousArrayOfLong[0]);
      }
      
      public long method4(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.doAction((int)paramAnonymousArrayOfLong[0]);
      }
      
      public long method5(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_description((int)paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method6(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_keyBinding((int)paramAnonymousArrayOfLong[0], (int)paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2], paramAnonymousArrayOfLong[3]);
      }
      
      public long method7(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_name((int)paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method8(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_localizedName((int)paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method9(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_anchor((int)paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method10(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_anchorTarget((int)paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method11(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_startIndex(paramAnonymousArrayOfLong[0]);
      }
      
      public long method12(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_endIndex(paramAnonymousArrayOfLong[0]);
      }
      
      public long method13(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_valid(paramAnonymousArrayOfLong[0]);
      }
    };
  }
  
  void createIAccessibleHypertext()
  {
    this.objIAccessibleHypertext = new COMObject(new int[] { 2, 0, 0, 2, 4, 1, 6, 1, 4, 3, 3, 5, 5, 5, 1, 1, 3, 1, 3, 5, 1, 1, 1, 2, 2 })
    {
      public long method0(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.QueryInterface(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method1(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.AddRef();
      }
      
      public long method2(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.Release();
      }
      
      public long method3(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.addSelection((int)paramAnonymousArrayOfLong[0], (int)paramAnonymousArrayOfLong[1]);
      }
      
      public long method4(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_attributes((int)paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2], paramAnonymousArrayOfLong[3]);
      }
      
      public long method5(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_caretOffset(paramAnonymousArrayOfLong[0]);
      }
      
      public long method6(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_characterExtents((int)paramAnonymousArrayOfLong[0], (int)paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2], paramAnonymousArrayOfLong[3], paramAnonymousArrayOfLong[4], paramAnonymousArrayOfLong[5]);
      }
      
      public long method7(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_nSelections(paramAnonymousArrayOfLong[0]);
      }
      
      public long method8(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_offsetAtPoint((int)paramAnonymousArrayOfLong[0], (int)paramAnonymousArrayOfLong[1], (int)paramAnonymousArrayOfLong[2], paramAnonymousArrayOfLong[3]);
      }
      
      public long method9(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_selection((int)paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2]);
      }
      
      public long method10(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_text((int)paramAnonymousArrayOfLong[0], (int)paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2]);
      }
      
      public long method11(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_textBeforeOffset((int)paramAnonymousArrayOfLong[0], (int)paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2], paramAnonymousArrayOfLong[3], paramAnonymousArrayOfLong[4]);
      }
      
      public long method12(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_textAfterOffset((int)paramAnonymousArrayOfLong[0], (int)paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2], paramAnonymousArrayOfLong[3], paramAnonymousArrayOfLong[4]);
      }
      
      public long method13(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_textAtOffset((int)paramAnonymousArrayOfLong[0], (int)paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2], paramAnonymousArrayOfLong[3], paramAnonymousArrayOfLong[4]);
      }
      
      public long method14(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.removeSelection((int)paramAnonymousArrayOfLong[0]);
      }
      
      public long method15(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.setCaretOffset((int)paramAnonymousArrayOfLong[0]);
      }
      
      public long method16(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.setSelection((int)paramAnonymousArrayOfLong[0], (int)paramAnonymousArrayOfLong[1], (int)paramAnonymousArrayOfLong[2]);
      }
      
      public long method17(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_nCharacters(paramAnonymousArrayOfLong[0]);
      }
      
      public long method18(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.scrollSubstringTo((int)paramAnonymousArrayOfLong[0], (int)paramAnonymousArrayOfLong[1], (int)paramAnonymousArrayOfLong[2]);
      }
      
      public long method19(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.scrollSubstringToPoint((int)paramAnonymousArrayOfLong[0], (int)paramAnonymousArrayOfLong[1], (int)paramAnonymousArrayOfLong[2], (int)paramAnonymousArrayOfLong[3], (int)paramAnonymousArrayOfLong[4]);
      }
      
      public long method20(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_newText(paramAnonymousArrayOfLong[0]);
      }
      
      public long method21(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_oldText(paramAnonymousArrayOfLong[0]);
      }
      
      public long method22(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_nHyperlinks(paramAnonymousArrayOfLong[0]);
      }
      
      public long method23(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_hyperlink((int)paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method24(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_hyperlinkIndex((int)paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
    };
  }
  
  void createIAccessibleTable2()
  {
    this.objIAccessibleTable2 = new COMObject(new int[] { 2, 0, 0, 3, 1, 2, 1, 1, 1, 1, 1, 2, 2, 2, 2, 1, 2, 2, 1, 1, 1, 1, 1 })
    {
      public long method0(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.QueryInterface(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method1(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.AddRef();
      }
      
      public long method2(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.Release();
      }
      
      public long method3(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_cellAt((int)paramAnonymousArrayOfLong[0], (int)paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2]);
      }
      
      public long method4(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_caption(paramAnonymousArrayOfLong[0]);
      }
      
      public long method5(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_columnDescription((int)paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method6(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_nColumns(paramAnonymousArrayOfLong[0]);
      }
      
      public long method7(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_nRows(paramAnonymousArrayOfLong[0]);
      }
      
      public long method8(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_nSelectedCells(paramAnonymousArrayOfLong[0]);
      }
      
      public long method9(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_nSelectedColumns(paramAnonymousArrayOfLong[0]);
      }
      
      public long method10(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_nSelectedRows(paramAnonymousArrayOfLong[0]);
      }
      
      public long method11(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_rowDescription((int)paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method12(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_selectedCells(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method13(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_selectedColumns(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method14(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_selectedRows(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method15(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_summary(paramAnonymousArrayOfLong[0]);
      }
      
      public long method16(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_isColumnSelected((int)paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method17(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_isRowSelected((int)paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method18(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.selectRow((int)paramAnonymousArrayOfLong[0]);
      }
      
      public long method19(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.selectColumn((int)paramAnonymousArrayOfLong[0]);
      }
      
      public long method20(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.unselectRow((int)paramAnonymousArrayOfLong[0]);
      }
      
      public long method21(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.unselectColumn((int)paramAnonymousArrayOfLong[0]);
      }
      
      public long method22(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_modelChange(paramAnonymousArrayOfLong[0]);
      }
    };
  }
  
  void createIAccessibleTableCell()
  {
    this.objIAccessibleTableCell = new COMObject(new int[] { 2, 0, 0, 1, 2, 1, 1, 2, 1, 1, 5, 1 })
    {
      public long method0(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.QueryInterface(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method1(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.AddRef();
      }
      
      public long method2(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.Release();
      }
      
      public long method3(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_columnExtent(paramAnonymousArrayOfLong[0]);
      }
      
      public long method4(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_columnHeaderCells(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method5(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_columnIndex(paramAnonymousArrayOfLong[0]);
      }
      
      public long method6(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_rowExtent(paramAnonymousArrayOfLong[0]);
      }
      
      public long method7(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_rowHeaderCells(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method8(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_rowIndex(paramAnonymousArrayOfLong[0]);
      }
      
      public long method9(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_isSelected(paramAnonymousArrayOfLong[0]);
      }
      
      public long method10(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_rowColumnExtents(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2], paramAnonymousArrayOfLong[3], paramAnonymousArrayOfLong[4]);
      }
      
      public long method11(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_table(paramAnonymousArrayOfLong[0]);
      }
    };
  }
  
  void createIAccessibleText()
  {
    this.objIAccessibleText = new COMObject(new int[] { 2, 0, 0, 2, 4, 1, 6, 1, 4, 3, 3, 5, 5, 5, 1, 1, 3, 1, 3, 5, 1, 1 })
    {
      public long method0(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.QueryInterface(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method1(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.AddRef();
      }
      
      public long method2(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.Release();
      }
      
      public long method3(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.addSelection((int)paramAnonymousArrayOfLong[0], (int)paramAnonymousArrayOfLong[1]);
      }
      
      public long method4(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_attributes((int)paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2], paramAnonymousArrayOfLong[3]);
      }
      
      public long method5(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_caretOffset(paramAnonymousArrayOfLong[0]);
      }
      
      public long method6(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_characterExtents((int)paramAnonymousArrayOfLong[0], (int)paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2], paramAnonymousArrayOfLong[3], paramAnonymousArrayOfLong[4], paramAnonymousArrayOfLong[5]);
      }
      
      public long method7(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_nSelections(paramAnonymousArrayOfLong[0]);
      }
      
      public long method8(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_offsetAtPoint((int)paramAnonymousArrayOfLong[0], (int)paramAnonymousArrayOfLong[1], (int)paramAnonymousArrayOfLong[2], paramAnonymousArrayOfLong[3]);
      }
      
      public long method9(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_selection((int)paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2]);
      }
      
      public long method10(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_text((int)paramAnonymousArrayOfLong[0], (int)paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2]);
      }
      
      public long method11(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_textBeforeOffset((int)paramAnonymousArrayOfLong[0], (int)paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2], paramAnonymousArrayOfLong[3], paramAnonymousArrayOfLong[4]);
      }
      
      public long method12(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_textAfterOffset((int)paramAnonymousArrayOfLong[0], (int)paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2], paramAnonymousArrayOfLong[3], paramAnonymousArrayOfLong[4]);
      }
      
      public long method13(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_textAtOffset((int)paramAnonymousArrayOfLong[0], (int)paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2], paramAnonymousArrayOfLong[3], paramAnonymousArrayOfLong[4]);
      }
      
      public long method14(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.removeSelection((int)paramAnonymousArrayOfLong[0]);
      }
      
      public long method15(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.setCaretOffset((int)paramAnonymousArrayOfLong[0]);
      }
      
      public long method16(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.setSelection((int)paramAnonymousArrayOfLong[0], (int)paramAnonymousArrayOfLong[1], (int)paramAnonymousArrayOfLong[2]);
      }
      
      public long method17(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_nCharacters(paramAnonymousArrayOfLong[0]);
      }
      
      public long method18(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.scrollSubstringTo((int)paramAnonymousArrayOfLong[0], (int)paramAnonymousArrayOfLong[1], (int)paramAnonymousArrayOfLong[2]);
      }
      
      public long method19(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.scrollSubstringToPoint((int)paramAnonymousArrayOfLong[0], (int)paramAnonymousArrayOfLong[1], (int)paramAnonymousArrayOfLong[2], (int)paramAnonymousArrayOfLong[3], (int)paramAnonymousArrayOfLong[4]);
      }
      
      public long method20(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_newText(paramAnonymousArrayOfLong[0]);
      }
      
      public long method21(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_oldText(paramAnonymousArrayOfLong[0]);
      }
    };
  }
  
  void createIAccessibleValue()
  {
    this.objIAccessibleValue = new COMObject(new int[] { 2, 0, 0, 1, 1, 1, 1 })
    {
      public long method0(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.QueryInterface(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method1(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.AddRef();
      }
      
      public long method2(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.Release();
      }
      
      public long method3(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_currentValue(paramAnonymousArrayOfLong[0]);
      }
      
      public long method4(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.setCurrentValue(paramAnonymousArrayOfLong[0]);
      }
      
      public long method5(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_maximumValue(paramAnonymousArrayOfLong[0]);
      }
      
      public long method6(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.get_minimumValue(paramAnonymousArrayOfLong[0]);
      }
    };
    long l = this.objIAccessibleValue.ppVtable;
    long[] arrayOfLong1 = new long[1];
    COM.MoveMemory(arrayOfLong1, l, OS.PTR_SIZEOF);
    long[] arrayOfLong2 = new long[7];
    COM.MoveMemory(arrayOfLong2, arrayOfLong1[0], OS.PTR_SIZEOF * arrayOfLong2.length);
    arrayOfLong2[4] = COM.CALLBACK_setCurrentValue(arrayOfLong2[4]);
    COM.MoveMemory(arrayOfLong1[0], arrayOfLong2, OS.PTR_SIZEOF * arrayOfLong2.length);
  }
  
  void createIEnumVARIANT()
  {
    this.objIEnumVARIANT = new COMObject(new int[] { 2, 0, 0, 3, 1, 0, 1 })
    {
      public long method0(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.QueryInterface(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method1(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.AddRef();
      }
      
      public long method2(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.Release();
      }
      
      public long method3(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.Next((int)paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2]);
      }
      
      public long method4(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.Skip((int)paramAnonymousArrayOfLong[0]);
      }
      
      public long method5(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.Reset();
      }
      
      public long method6(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.Clone(paramAnonymousArrayOfLong[0]);
      }
    };
  }
  
  void createIServiceProvider()
  {
    this.objIServiceProvider = new COMObject(new int[] { 2, 0, 0, 3 })
    {
      public long method0(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.QueryInterface(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method1(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.AddRef();
      }
      
      public long method2(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.Release();
      }
      
      public long method3(long[] paramAnonymousArrayOfLong)
      {
        return Accessible.this.QueryService(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2]);
      }
    };
  }
  
  public static Accessible internal_new_Accessible(Control paramControl)
  {
    return new Accessible(paramControl);
  }
  
  public void addAccessibleListener(AccessibleListener paramAccessibleListener)
  {
    checkWidget();
    if (paramAccessibleListener == null) {
      SWT.error(4);
    }
    if (this.accessibleListeners == null) {
      this.accessibleListeners = new Vector();
    }
    this.accessibleListeners.addElement(paramAccessibleListener);
  }
  
  public void addAccessibleControlListener(AccessibleControlListener paramAccessibleControlListener)
  {
    checkWidget();
    if (paramAccessibleControlListener == null) {
      SWT.error(4);
    }
    if (this.accessibleControlListeners == null) {
      this.accessibleControlListeners = new Vector();
    }
    this.accessibleControlListeners.addElement(paramAccessibleControlListener);
  }
  
  public void addAccessibleTextListener(AccessibleTextListener paramAccessibleTextListener)
  {
    checkWidget();
    if (paramAccessibleTextListener == null) {
      SWT.error(4);
    }
    if ((paramAccessibleTextListener instanceof AccessibleTextExtendedListener))
    {
      if (this.accessibleTextExtendedListeners == null) {
        this.accessibleTextExtendedListeners = new Vector();
      }
      this.accessibleTextExtendedListeners.addElement(paramAccessibleTextListener);
    }
    else
    {
      if (this.accessibleTextListeners == null) {
        this.accessibleTextListeners = new Vector();
      }
      this.accessibleTextListeners.addElement(paramAccessibleTextListener);
    }
  }
  
  public void addAccessibleActionListener(AccessibleActionListener paramAccessibleActionListener)
  {
    checkWidget();
    if (paramAccessibleActionListener == null) {
      SWT.error(4);
    }
    if (this.accessibleActionListeners == null) {
      this.accessibleActionListeners = new Vector();
    }
    this.accessibleActionListeners.addElement(paramAccessibleActionListener);
  }
  
  public void addAccessibleEditableTextListener(AccessibleEditableTextListener paramAccessibleEditableTextListener)
  {
    checkWidget();
    if (paramAccessibleEditableTextListener == null) {
      SWT.error(4);
    }
    if (this.accessibleEditableTextListeners == null) {
      this.accessibleEditableTextListeners = new Vector();
    }
    this.accessibleEditableTextListeners.addElement(paramAccessibleEditableTextListener);
  }
  
  public void addAccessibleHyperlinkListener(AccessibleHyperlinkListener paramAccessibleHyperlinkListener)
  {
    checkWidget();
    if (paramAccessibleHyperlinkListener == null) {
      SWT.error(4);
    }
    if (this.accessibleHyperlinkListeners == null) {
      this.accessibleHyperlinkListeners = new Vector();
    }
    this.accessibleHyperlinkListeners.addElement(paramAccessibleHyperlinkListener);
  }
  
  public void addAccessibleTableListener(AccessibleTableListener paramAccessibleTableListener)
  {
    checkWidget();
    if (paramAccessibleTableListener == null) {
      SWT.error(4);
    }
    if (this.accessibleTableListeners == null) {
      this.accessibleTableListeners = new Vector();
    }
    this.accessibleTableListeners.addElement(paramAccessibleTableListener);
  }
  
  public void addAccessibleTableCellListener(AccessibleTableCellListener paramAccessibleTableCellListener)
  {
    checkWidget();
    if (paramAccessibleTableCellListener == null) {
      SWT.error(4);
    }
    if (this.accessibleTableCellListeners == null) {
      this.accessibleTableCellListeners = new Vector();
    }
    this.accessibleTableCellListeners.addElement(paramAccessibleTableCellListener);
  }
  
  public void addAccessibleValueListener(AccessibleValueListener paramAccessibleValueListener)
  {
    checkWidget();
    if (paramAccessibleValueListener == null) {
      SWT.error(4);
    }
    if (this.accessibleValueListeners == null) {
      this.accessibleValueListeners = new Vector();
    }
    this.accessibleValueListeners.addElement(paramAccessibleValueListener);
  }
  
  public void addAccessibleAttributeListener(AccessibleAttributeListener paramAccessibleAttributeListener)
  {
    checkWidget();
    if (paramAccessibleAttributeListener == null) {
      SWT.error(4);
    }
    if (this.accessibleAttributeListeners == null) {
      this.accessibleAttributeListeners = new Vector();
    }
    this.accessibleAttributeListeners.addElement(paramAccessibleAttributeListener);
  }
  
  public void addRelation(int paramInt, Accessible paramAccessible)
  {
    checkWidget();
    if (this.relations[paramInt] == null) {
      this.relations[paramInt] = new Relation(this, paramInt);
    }
    this.relations[paramInt].addTarget(paramAccessible);
  }
  
  public void dispose()
  {
    if (this.parent == null) {
      return;
    }
    Release();
    this.parent.children.removeElement(this);
    this.parent = null;
  }
  
  long getAddress()
  {
    if (this.objIAccessible == null) {
      createIAccessible();
    }
    return this.objIAccessible.getAddress();
  }
  
  public Control getControl()
  {
    return this.control;
  }
  
  public void internal_dispose_Accessible()
  {
    if (this.iaccessible != null) {
      this.iaccessible.Release();
    }
    this.iaccessible = null;
    Release();
    for (int i = 0; i < this.children.size(); i++)
    {
      Accessible localAccessible = (Accessible)this.children.elementAt(i);
      localAccessible.dispose();
    }
  }
  
  public long internal_WM_GETOBJECT(long paramLong1, long paramLong2)
  {
    if (this.objIAccessible == null) {
      return 0L;
    }
    if ((int)paramLong2 == -4) {
      return COM.LresultFromObject(COM.IIDIAccessible, paramLong1, this.objIAccessible.getAddress());
    }
    return 0L;
  }
  
  public void removeAccessibleListener(AccessibleListener paramAccessibleListener)
  {
    checkWidget();
    if (paramAccessibleListener == null) {
      SWT.error(4);
    }
    if (this.accessibleListeners != null)
    {
      this.accessibleListeners.removeElement(paramAccessibleListener);
      if (this.accessibleListeners.isEmpty()) {
        this.accessibleListeners = null;
      }
    }
  }
  
  public void removeAccessibleControlListener(AccessibleControlListener paramAccessibleControlListener)
  {
    checkWidget();
    if (paramAccessibleControlListener == null) {
      SWT.error(4);
    }
    if (this.accessibleControlListeners != null)
    {
      this.accessibleControlListeners.removeElement(paramAccessibleControlListener);
      if (this.accessibleControlListeners.isEmpty()) {
        this.accessibleControlListeners = null;
      }
    }
  }
  
  public void removeAccessibleTextListener(AccessibleTextListener paramAccessibleTextListener)
  {
    checkWidget();
    if (paramAccessibleTextListener == null) {
      SWT.error(4);
    }
    if ((paramAccessibleTextListener instanceof AccessibleTextExtendedListener))
    {
      if (this.accessibleTextExtendedListeners != null)
      {
        this.accessibleTextExtendedListeners.removeElement(paramAccessibleTextListener);
        if (this.accessibleTextExtendedListeners.isEmpty()) {
          this.accessibleTextExtendedListeners = null;
        }
      }
    }
    else if (this.accessibleTextListeners != null)
    {
      this.accessibleTextListeners.removeElement(paramAccessibleTextListener);
      if (this.accessibleTextListeners.isEmpty()) {
        this.accessibleTextListeners = null;
      }
    }
  }
  
  public void removeAccessibleActionListener(AccessibleActionListener paramAccessibleActionListener)
  {
    checkWidget();
    if (paramAccessibleActionListener == null) {
      SWT.error(4);
    }
    if (this.accessibleActionListeners != null)
    {
      this.accessibleActionListeners.removeElement(paramAccessibleActionListener);
      if (this.accessibleActionListeners.isEmpty()) {
        this.accessibleActionListeners = null;
      }
    }
  }
  
  public void removeAccessibleEditableTextListener(AccessibleEditableTextListener paramAccessibleEditableTextListener)
  {
    checkWidget();
    if (paramAccessibleEditableTextListener == null) {
      SWT.error(4);
    }
    if (this.accessibleEditableTextListeners != null)
    {
      this.accessibleEditableTextListeners.removeElement(paramAccessibleEditableTextListener);
      if (this.accessibleEditableTextListeners.isEmpty()) {
        this.accessibleEditableTextListeners = null;
      }
    }
  }
  
  public void removeAccessibleHyperlinkListener(AccessibleHyperlinkListener paramAccessibleHyperlinkListener)
  {
    checkWidget();
    if (paramAccessibleHyperlinkListener == null) {
      SWT.error(4);
    }
    if (this.accessibleHyperlinkListeners != null)
    {
      this.accessibleHyperlinkListeners.removeElement(paramAccessibleHyperlinkListener);
      if (this.accessibleHyperlinkListeners.isEmpty()) {
        this.accessibleHyperlinkListeners = null;
      }
    }
  }
  
  public void removeAccessibleTableListener(AccessibleTableListener paramAccessibleTableListener)
  {
    checkWidget();
    if (paramAccessibleTableListener == null) {
      SWT.error(4);
    }
    if (this.accessibleTableListeners != null)
    {
      this.accessibleTableListeners.removeElement(paramAccessibleTableListener);
      if (this.accessibleTableListeners.isEmpty()) {
        this.accessibleTableListeners = null;
      }
    }
  }
  
  public void removeAccessibleTableCellListener(AccessibleTableCellListener paramAccessibleTableCellListener)
  {
    checkWidget();
    if (paramAccessibleTableCellListener == null) {
      SWT.error(4);
    }
    if (this.accessibleTableCellListeners != null)
    {
      this.accessibleTableCellListeners.removeElement(paramAccessibleTableCellListener);
      if (this.accessibleTableCellListeners.isEmpty()) {
        this.accessibleTableCellListeners = null;
      }
    }
  }
  
  public void removeAccessibleValueListener(AccessibleValueListener paramAccessibleValueListener)
  {
    checkWidget();
    if (paramAccessibleValueListener == null) {
      SWT.error(4);
    }
    if (this.accessibleValueListeners != null)
    {
      this.accessibleValueListeners.removeElement(paramAccessibleValueListener);
      if (this.accessibleValueListeners.isEmpty()) {
        this.accessibleValueListeners = null;
      }
    }
  }
  
  public void removeAccessibleAttributeListener(AccessibleAttributeListener paramAccessibleAttributeListener)
  {
    checkWidget();
    if (paramAccessibleAttributeListener == null) {
      SWT.error(4);
    }
    if (this.accessibleAttributeListeners != null)
    {
      this.accessibleAttributeListeners.removeElement(paramAccessibleAttributeListener);
      if (this.accessibleAttributeListeners.isEmpty()) {
        this.accessibleAttributeListeners = null;
      }
    }
  }
  
  public void removeRelation(int paramInt, Accessible paramAccessible)
  {
    checkWidget();
    Relation localRelation = this.relations[paramInt];
    if (localRelation != null)
    {
      localRelation.removeTarget(paramAccessible);
      if (!localRelation.hasTargets())
      {
        this.relations[paramInt].Release();
        this.relations[paramInt] = null;
      }
    }
  }
  
  public void sendEvent(int paramInt, Object paramObject)
  {
    checkWidget();
    if (!isATRunning()) {
      return;
    }
    if (!UseIA2) {
      return;
    }
    switch (paramInt)
    {
    case 518: 
      if (((paramObject instanceof int[])) && (((int[])paramObject).length == 5))
      {
        this.tableChange = ((int[])paramObject);
        COM.NotifyWinEvent(278, this.control.handle, -4, eventChildID());
      }
      break;
    case 524: 
      if (((paramObject instanceof Object[])) && (((Object[])paramObject).length == 4))
      {
        Object[] arrayOfObject = (Object[])paramObject;
        int i = ((Integer)arrayOfObject[0]).intValue();
        switch (i)
        {
        case 1: 
          this.textDeleted = ((Object[])paramObject);
          COM.NotifyWinEvent(287, this.control.handle, -4, eventChildID());
          break;
        case 0: 
          this.textInserted = ((Object[])paramObject);
          COM.NotifyWinEvent(286, this.control.handle, -4, eventChildID());
        }
      }
      break;
    case 268: 
      if ((paramObject instanceof Integer)) {
        COM.NotifyWinEvent(268, this.control.handle, -4, eventChildID());
      }
      break;
    case 32782: 
      COM.NotifyWinEvent(32782, this.control.handle, -4, eventChildID());
      break;
    case 32778: 
      COM.NotifyWinEvent(32778, this.control.handle, -4, eventChildID());
      break;
    case 32777: 
      COM.NotifyWinEvent(32777, this.control.handle, -4, eventChildID());
      break;
    case 32788: 
      COM.NotifyWinEvent(32788, this.control.handle, -4, eventChildID());
      break;
    case 32779: 
      COM.NotifyWinEvent(32779, this.control.handle, -4, eventChildID());
      break;
    case 32780: 
      COM.NotifyWinEvent(32780, this.control.handle, -4, eventChildID());
      break;
    case 32781: 
      COM.NotifyWinEvent(32781, this.control.handle, -4, eventChildID());
      break;
    case 261: 
      COM.NotifyWinEvent(261, this.control.handle, -4, eventChildID());
      break;
    case 262: 
      COM.NotifyWinEvent(262, this.control.handle, -4, eventChildID());
      break;
    case 263: 
      COM.NotifyWinEvent(263, this.control.handle, -4, eventChildID());
      break;
    case 273: 
      COM.NotifyWinEvent(273, this.control.handle, -4, eventChildID());
      break;
    case 274: 
      COM.NotifyWinEvent(274, this.control.handle, -4, eventChildID());
      break;
    case 256: 
      COM.NotifyWinEvent(257, this.control.handle, -4, eventChildID());
      break;
    case 269: 
      COM.NotifyWinEvent(269, this.control.handle, -4, eventChildID());
      break;
    case 264: 
      COM.NotifyWinEvent(264, this.control.handle, -4, eventChildID());
      break;
    case 265: 
      COM.NotifyWinEvent(265, this.control.handle, -4, eventChildID());
      break;
    case 266: 
      COM.NotifyWinEvent(266, this.control.handle, -4, eventChildID());
      break;
    case 267: 
      COM.NotifyWinEvent(267, this.control.handle, -4, eventChildID());
      break;
    case 271: 
      COM.NotifyWinEvent(271, this.control.handle, -4, eventChildID());
      break;
    case 512: 
      COM.NotifyWinEvent(272, this.control.handle, -4, eventChildID());
      break;
    case 515: 
      COM.NotifyWinEvent(275, this.control.handle, -4, eventChildID());
      break;
    case 516: 
      COM.NotifyWinEvent(276, this.control.handle, -4, eventChildID());
      break;
    case 517: 
      COM.NotifyWinEvent(277, this.control.handle, -4, eventChildID());
      break;
    case 519: 
      COM.NotifyWinEvent(279, this.control.handle, -4, eventChildID());
      break;
    case 520: 
      COM.NotifyWinEvent(280, this.control.handle, -4, eventChildID());
      break;
    case 521: 
      COM.NotifyWinEvent(281, this.control.handle, -4, eventChildID());
      break;
    case 522: 
      COM.NotifyWinEvent(282, this.control.handle, -4, eventChildID());
      break;
    case 283: 
      COM.NotifyWinEvent(283, this.control.handle, -4, eventChildID());
      break;
    case 285: 
      COM.NotifyWinEvent(285, this.control.handle, -4, eventChildID());
    }
  }
  
  public void sendEvent(int paramInt1, Object paramObject, int paramInt2)
  {
    checkWidget();
    if (!isATRunning()) {
      return;
    }
    if (!UseIA2) {
      return;
    }
    int i = paramInt2 == -1 ? eventChildID() : childIDToOs(paramInt2);
    switch (paramInt1)
    {
    case 32778: 
      COM.NotifyWinEvent(32778, this.control.handle, -4, i);
      break;
    case 32780: 
      COM.NotifyWinEvent(32780, this.control.handle, -4, i);
      break;
    case 32782: 
      COM.NotifyWinEvent(32782, this.control.handle, -4, i);
      break;
    case 32779: 
      COM.NotifyWinEvent(32779, this.control.handle, -4, i);
      break;
    case 32777: 
      COM.NotifyWinEvent(32777, this.control.handle, -4, i);
      break;
    case 32788: 
      COM.NotifyWinEvent(32788, this.control.handle, -4, i);
      break;
    case 32781: 
      COM.NotifyWinEvent(32781, this.control.handle, -4, i);
    }
  }
  
  public void selectionChanged()
  {
    checkWidget();
    if (!isATRunning()) {
      return;
    }
    COM.NotifyWinEvent(32777, this.control.handle, -4, eventChildID());
  }
  
  public void setFocus(int paramInt)
  {
    checkWidget();
    if (!isATRunning()) {
      return;
    }
    int i = paramInt == -1 ? eventChildID() : childIDToOs(paramInt);
    COM.NotifyWinEvent(32773, this.control.handle, -4, i);
  }
  
  public void textCaretMoved(int paramInt)
  {
    checkWidget();
    if (this.timer == null) {
      this.timer = new Runnable()
      {
        public void run()
        {
          if (!Accessible.this.isATRunning()) {
            return;
          }
          COM.NotifyWinEvent(32779, Accessible.this.control.handle, -8, Accessible.this.eventChildID());
          if (!Accessible.UseIA2) {
            return;
          }
          COM.NotifyWinEvent(283, Accessible.this.control.handle, -4, Accessible.this.eventChildID());
        }
      };
    }
    Display.getDefault().timerExec(100, this.timer);
  }
  
  public void textChanged(int paramInt1, int paramInt2, int paramInt3)
  {
    checkWidget();
    if (!isATRunning()) {
      return;
    }
    AccessibleTextEvent localAccessibleTextEvent = new AccessibleTextEvent(this);
    localAccessibleTextEvent.start = paramInt2;
    localAccessibleTextEvent.end = (paramInt2 + paramInt3);
    localAccessibleTextEvent.count = 0;
    localAccessibleTextEvent.type = 5;
    for (int i = 0; i < accessibleTextExtendedListenersSize(); i++)
    {
      AccessibleTextExtendedListener localAccessibleTextExtendedListener = (AccessibleTextExtendedListener)this.accessibleTextExtendedListeners.elementAt(i);
      localAccessibleTextExtendedListener.getText(localAccessibleTextEvent);
    }
    if (localAccessibleTextEvent.result != null)
    {
      Object[] arrayOfObject = { new Integer(paramInt1), new Integer(paramInt2), new Integer(paramInt2 + paramInt3), localAccessibleTextEvent.result };
      sendEvent(524, arrayOfObject);
      return;
    }
    COM.NotifyWinEvent(32782, this.control.handle, -4, eventChildID());
  }
  
  public void textSelectionChanged()
  {
    checkWidget();
    if (!isATRunning()) {
      return;
    }
    COM.NotifyWinEvent(32782, this.control.handle, -4, eventChildID());
  }
  
  int QueryInterface(long paramLong1, long paramLong2)
  {
    COM.MoveMemory(paramLong2, new long[] { 0L }, OS.PTR_SIZEOF);
    GUID localGUID = new GUID();
    COM.MoveMemory(localGUID, paramLong1, GUID.sizeof);
    if (COM.IsEqualGUID(localGUID, COM.IIDIUnknown))
    {
      COM.MoveMemory(paramLong2, new long[] { getAddress() }, OS.PTR_SIZEOF);
      AddRef();
      return 0;
    }
    if ((COM.IsEqualGUID(localGUID, COM.IIDIDispatch)) || (COM.IsEqualGUID(localGUID, COM.IIDIAccessible)))
    {
      if (this.objIAccessible == null) {
        createIAccessible();
      }
      COM.MoveMemory(paramLong2, new long[] { this.objIAccessible.getAddress() }, OS.PTR_SIZEOF);
      AddRef();
      return 0;
    }
    if (COM.IsEqualGUID(localGUID, COM.IIDIEnumVARIANT))
    {
      if (this.objIEnumVARIANT == null) {
        createIEnumVARIANT();
      }
      COM.MoveMemory(paramLong2, new long[] { this.objIEnumVARIANT.getAddress() }, OS.PTR_SIZEOF);
      AddRef();
      this.enumIndex = 0;
      return 0;
    }
    if (COM.IsEqualGUID(localGUID, COM.IIDIServiceProvider))
    {
      if (!UseIA2) {
        return -2147467262;
      }
      if ((accessibleActionListenersSize() > 0) || (accessibleAttributeListenersSize() > 0) || (accessibleHyperlinkListenersSize() > 0) || (accessibleTableListenersSize() > 0) || (accessibleTableCellListenersSize() > 0) || (accessibleTextExtendedListenersSize() > 0) || (accessibleValueListenersSize() > 0) || (getRelationCount() > 0) || (((this.control instanceof Button)) && ((this.control.getStyle() & 0x10) != 0)))
      {
        if (this.objIServiceProvider == null) {
          createIServiceProvider();
        }
        COM.MoveMemory(paramLong2, new long[] { this.objIServiceProvider.getAddress() }, OS.PTR_SIZEOF);
        AddRef();
        return 0;
      }
      return -2147467262;
    }
    int i = queryAccessible2Interfaces(localGUID, paramLong2);
    if (i != 1) {
      return i;
    }
    if (this.iaccessible != null)
    {
      long[] arrayOfLong = new long[1];
      i = this.iaccessible.QueryInterface(localGUID, arrayOfLong);
      COM.MoveMemory(paramLong2, arrayOfLong, OS.PTR_SIZEOF);
      return i;
    }
    return -2147467262;
  }
  
  int accessibleListenersSize()
  {
    return this.accessibleListeners == null ? 0 : this.accessibleListeners.size();
  }
  
  int accessibleControlListenersSize()
  {
    return this.accessibleControlListeners == null ? 0 : this.accessibleControlListeners.size();
  }
  
  int accessibleValueListenersSize()
  {
    return this.accessibleValueListeners == null ? 0 : this.accessibleValueListeners.size();
  }
  
  int accessibleTextExtendedListenersSize()
  {
    return this.accessibleTextExtendedListeners == null ? 0 : this.accessibleTextExtendedListeners.size();
  }
  
  int accessibleTextListenersSize()
  {
    return this.accessibleTextListeners == null ? 0 : this.accessibleTextListeners.size();
  }
  
  int accessibleTableCellListenersSize()
  {
    return this.accessibleTableCellListeners == null ? 0 : this.accessibleTableCellListeners.size();
  }
  
  int accessibleTableListenersSize()
  {
    return this.accessibleTableListeners == null ? 0 : this.accessibleTableListeners.size();
  }
  
  int accessibleHyperlinkListenersSize()
  {
    return this.accessibleHyperlinkListeners == null ? 0 : this.accessibleHyperlinkListeners.size();
  }
  
  int accessibleEditableTextListenersSize()
  {
    return this.accessibleEditableTextListeners == null ? 0 : this.accessibleEditableTextListeners.size();
  }
  
  int accessibleAttributeListenersSize()
  {
    return this.accessibleAttributeListeners == null ? 0 : this.accessibleAttributeListeners.size();
  }
  
  int accessibleActionListenersSize()
  {
    return this.accessibleActionListeners == null ? 0 : this.accessibleActionListeners.size();
  }
  
  int AddRef()
  {
    this.refCount += 1;
    return this.refCount;
  }
  
  int Release()
  {
    this.refCount -= 1;
    if (this.refCount == 0)
    {
      if (this.objIAccessible != null) {
        this.objIAccessible.dispose();
      }
      this.objIAccessible = null;
      if (this.objIEnumVARIANT != null) {
        this.objIEnumVARIANT.dispose();
      }
      this.objIEnumVARIANT = null;
      if (this.objIServiceProvider != null) {
        this.objIServiceProvider.dispose();
      }
      this.objIServiceProvider = null;
      if (this.objIAccessible2 != null) {
        this.objIAccessible2.dispose();
      }
      this.objIAccessible2 = null;
      if (this.objIAccessibleAction != null) {
        this.objIAccessibleAction.dispose();
      }
      this.objIAccessibleAction = null;
      if (this.objIAccessibleApplication != null) {
        this.objIAccessibleApplication.dispose();
      }
      this.objIAccessibleApplication = null;
      if (this.objIAccessibleEditableText != null) {
        this.objIAccessibleEditableText.dispose();
      }
      this.objIAccessibleEditableText = null;
      if (this.objIAccessibleHyperlink != null) {
        this.objIAccessibleHyperlink.dispose();
      }
      this.objIAccessibleHyperlink = null;
      if (this.objIAccessibleHypertext != null) {
        this.objIAccessibleHypertext.dispose();
      }
      this.objIAccessibleHypertext = null;
      if (this.objIAccessibleTable2 != null) {
        this.objIAccessibleTable2.dispose();
      }
      this.objIAccessibleTable2 = null;
      if (this.objIAccessibleTableCell != null) {
        this.objIAccessibleTableCell.dispose();
      }
      this.objIAccessibleTableCell = null;
      if (this.objIAccessibleText != null) {
        this.objIAccessibleText.dispose();
      }
      this.objIAccessibleText = null;
      if (this.objIAccessibleValue != null) {
        this.objIAccessibleValue.dispose();
      }
      this.objIAccessibleValue = null;
      for (int i = 0; i < this.relations.length; i++) {
        if (this.relations[i] != null) {
          this.relations[i].Release();
        }
      }
    }
    return this.refCount;
  }
  
  int QueryService(long paramLong1, long paramLong2, long paramLong3)
  {
    COM.MoveMemory(paramLong3, new long[] { 0L }, OS.PTR_SIZEOF);
    GUID localGUID1 = new GUID();
    COM.MoveMemory(localGUID1, paramLong1, GUID.sizeof);
    GUID localGUID2 = new GUID();
    COM.MoveMemory(localGUID2, paramLong2, GUID.sizeof);
    int i;
    if (COM.IsEqualGUID(localGUID1, COM.IIDIAccessible))
    {
      if ((COM.IsEqualGUID(localGUID2, COM.IIDIUnknown)) || ((COM.IsEqualGUID(localGUID2, COM.IIDIDispatch) | COM.IsEqualGUID(localGUID2, COM.IIDIAccessible))))
      {
        if (this.objIAccessible == null) {
          createIAccessible();
        }
        COM.MoveMemory(paramLong3, new long[] { this.objIAccessible.getAddress() }, OS.PTR_SIZEOF);
        AddRef();
        return 0;
      }
      i = queryAccessible2Interfaces(localGUID2, paramLong3);
      if (i != 1) {
        return i;
      }
    }
    if (COM.IsEqualGUID(localGUID1, COM.IIDIAccessible2))
    {
      i = queryAccessible2Interfaces(localGUID2, paramLong3);
      if (i != 1) {
        return i;
      }
    }
    if (this.iaccessible != null)
    {
      long[] arrayOfLong1 = new long[1];
      int j = this.iaccessible.QueryInterface(COM.IIDIServiceProvider, arrayOfLong1);
      if (j == 0)
      {
        IServiceProvider localIServiceProvider = new IServiceProvider(arrayOfLong1[0]);
        long[] arrayOfLong2 = new long[1];
        j = localIServiceProvider.QueryService(localGUID1, localGUID2, arrayOfLong2);
        COM.MoveMemory(paramLong3, arrayOfLong2, OS.PTR_SIZEOF);
        return j;
      }
    }
    return -2147467262;
  }
  
  int queryAccessible2Interfaces(GUID paramGUID, long paramLong)
  {
    if (COM.IsEqualGUID(paramGUID, COM.IIDIAccessible2))
    {
      if ((accessibleActionListenersSize() > 0) || (accessibleAttributeListenersSize() > 0) || (accessibleHyperlinkListenersSize() > 0) || (accessibleTableListenersSize() > 0) || (accessibleTableCellListenersSize() > 0) || (accessibleTextExtendedListenersSize() > 0) || (accessibleValueListenersSize() > 0) || (getRelationCount() > 0) || (((this.control instanceof Button)) && ((this.control.getStyle() & 0x10) != 0)))
      {
        if (this.objIAccessible2 == null) {
          createIAccessible2();
        }
        COM.MoveMemory(paramLong, new long[] { this.objIAccessible2.getAddress() }, OS.PTR_SIZEOF);
        AddRef();
        return 0;
      }
      return -2147467262;
    }
    if (COM.IsEqualGUID(paramGUID, COM.IIDIAccessibleAction))
    {
      if (accessibleActionListenersSize() > 0)
      {
        if (this.objIAccessibleAction == null) {
          createIAccessibleAction();
        }
        COM.MoveMemory(paramLong, new long[] { this.objIAccessibleAction.getAddress() }, OS.PTR_SIZEOF);
        AddRef();
        return 0;
      }
      return -2147467262;
    }
    if (COM.IsEqualGUID(paramGUID, COM.IIDIAccessibleApplication))
    {
      if (this.objIAccessibleApplication == null) {
        createIAccessibleApplication();
      }
      COM.MoveMemory(paramLong, new long[] { this.objIAccessibleApplication.getAddress() }, OS.PTR_SIZEOF);
      AddRef();
      return 0;
    }
    if (COM.IsEqualGUID(paramGUID, COM.IIDIAccessibleComponent)) {
      return -2147467262;
    }
    if (COM.IsEqualGUID(paramGUID, COM.IIDIAccessibleEditableText))
    {
      if (accessibleEditableTextListenersSize() > 0)
      {
        if (this.objIAccessibleEditableText == null) {
          createIAccessibleEditableText();
        }
        COM.MoveMemory(paramLong, new long[] { this.objIAccessibleEditableText.getAddress() }, OS.PTR_SIZEOF);
        AddRef();
        return 0;
      }
      return -2147467262;
    }
    if (COM.IsEqualGUID(paramGUID, COM.IIDIAccessibleHyperlink))
    {
      if (accessibleHyperlinkListenersSize() > 0)
      {
        if (this.objIAccessibleHyperlink == null) {
          createIAccessibleHyperlink();
        }
        COM.MoveMemory(paramLong, new long[] { this.objIAccessibleHyperlink.getAddress() }, OS.PTR_SIZEOF);
        AddRef();
        return 0;
      }
      return -2147467262;
    }
    if (COM.IsEqualGUID(paramGUID, COM.IIDIAccessibleHypertext))
    {
      if (accessibleTextExtendedListenersSize() > 0)
      {
        if (this.objIAccessibleHypertext == null) {
          createIAccessibleHypertext();
        }
        COM.MoveMemory(paramLong, new long[] { this.objIAccessibleHypertext.getAddress() }, OS.PTR_SIZEOF);
        AddRef();
        return 0;
      }
      return -2147467262;
    }
    if (COM.IsEqualGUID(paramGUID, COM.IIDIAccessibleImage)) {
      return -2147467262;
    }
    if (COM.IsEqualGUID(paramGUID, COM.IIDIAccessibleTable)) {
      return -2147467262;
    }
    if (COM.IsEqualGUID(paramGUID, COM.IIDIAccessibleTable2))
    {
      if (accessibleTableListenersSize() > 0)
      {
        if (this.objIAccessibleTable2 == null) {
          createIAccessibleTable2();
        }
        COM.MoveMemory(paramLong, new long[] { this.objIAccessibleTable2.getAddress() }, OS.PTR_SIZEOF);
        AddRef();
        return 0;
      }
      return -2147467262;
    }
    if (COM.IsEqualGUID(paramGUID, COM.IIDIAccessibleTableCell))
    {
      if (accessibleTableCellListenersSize() > 0)
      {
        if (this.objIAccessibleTableCell == null) {
          createIAccessibleTableCell();
        }
        COM.MoveMemory(paramLong, new long[] { this.objIAccessibleTableCell.getAddress() }, OS.PTR_SIZEOF);
        AddRef();
        return 0;
      }
      return -2147467262;
    }
    if (COM.IsEqualGUID(paramGUID, COM.IIDIAccessibleText))
    {
      if ((accessibleTextExtendedListenersSize() > 0) || (accessibleAttributeListenersSize() > 0))
      {
        if (this.objIAccessibleText == null) {
          createIAccessibleText();
        }
        COM.MoveMemory(paramLong, new long[] { this.objIAccessibleText.getAddress() }, OS.PTR_SIZEOF);
        AddRef();
        return 0;
      }
      return -2147467262;
    }
    if (COM.IsEqualGUID(paramGUID, COM.IIDIAccessibleValue))
    {
      if (accessibleValueListenersSize() > 0)
      {
        if (this.objIAccessibleValue == null) {
          createIAccessibleValue();
        }
        COM.MoveMemory(paramLong, new long[] { this.objIAccessibleValue.getAddress() }, OS.PTR_SIZEOF);
        AddRef();
        return 0;
      }
      return -2147467262;
    }
    return 1;
  }
  
  int accDoDefaultAction(long paramLong)
  {
    if (accessibleActionListenersSize() > 0)
    {
      VARIANT localVARIANT = getVARIANT(paramLong);
      if (localVARIANT.vt != 3) {
        return -2147024809;
      }
      if (localVARIANT.lVal == 0) {
        return doAction(0);
      }
    }
    int i = -2147352573;
    if (this.iaccessible != null)
    {
      i = this.iaccessible.accDoDefaultAction(paramLong);
      if (i == -2147024809) {
        i = -2147352573;
      }
    }
    return i;
  }
  
  int accHitTest(int paramInt1, int paramInt2, long paramLong)
  {
    int i = -2;
    long l = 0L;
    if (this.iaccessible != null)
    {
      int j = this.iaccessible.accHitTest(paramInt1, paramInt2, paramLong);
      if (j == 0)
      {
        VARIANT localVARIANT = getVARIANT(paramLong);
        if (localVARIANT.vt == 3) {
          i = localVARIANT.lVal;
        } else if (localVARIANT.vt == 9) {
          l = localVARIANT.lVal;
        }
      }
      if (accessibleControlListenersSize() == 0) {
        return j;
      }
    }
    AccessibleControlEvent localAccessibleControlEvent = new AccessibleControlEvent(this);
    localAccessibleControlEvent.childID = (i == -2 ? -2 : osToChildID(i));
    localAccessibleControlEvent.x = paramInt1;
    localAccessibleControlEvent.y = paramInt2;
    for (int k = 0; k < accessibleControlListenersSize(); k++)
    {
      AccessibleControlListener localAccessibleControlListener = (AccessibleControlListener)this.accessibleControlListeners.elementAt(k);
      localAccessibleControlListener.getChildAtPoint(localAccessibleControlEvent);
    }
    Accessible localAccessible = localAccessibleControlEvent.accessible;
    if (localAccessible != null)
    {
      localAccessible.AddRef();
      setPtrVARIANT(paramLong, (short)9, localAccessible.getAddress());
      return 0;
    }
    int m = localAccessibleControlEvent.childID;
    if (m == -2)
    {
      if (l != 0L) {
        return 0;
      }
      setIntVARIANT(paramLong, (short)0, 0);
      return 1;
    }
    setIntVARIANT(paramLong, (short)3, childIDToOs(m));
    return 0;
  }
  
  int accLocation(long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5)
  {
    VARIANT localVARIANT = getVARIANT(paramLong5);
    if (localVARIANT.vt != 3) {
      return -2147024809;
    }
    int i = 0;
    int j = 0;
    int k = 0;
    int m = 0;
    Object localObject;
    if (this.iaccessible != null)
    {
      int n = this.iaccessible.accLocation(paramLong1, paramLong2, paramLong3, paramLong4, paramLong5);
      if (n == -2147024809) {
        n = -2147352573;
      }
      if (accessibleControlListenersSize() == 0) {
        return n;
      }
      if (n == 0)
      {
        int[] arrayOfInt1 = new int[1];
        localObject = new int[1];
        int[] arrayOfInt2 = new int[1];
        int[] arrayOfInt3 = new int[1];
        COM.MoveMemory(arrayOfInt1, paramLong1, 4);
        COM.MoveMemory((int[])localObject, paramLong2, 4);
        COM.MoveMemory(arrayOfInt2, paramLong3, 4);
        COM.MoveMemory(arrayOfInt3, paramLong4, 4);
        i = arrayOfInt1[0];
        j = localObject[0];
        k = arrayOfInt2[0];
        m = arrayOfInt3[0];
      }
    }
    AccessibleControlEvent localAccessibleControlEvent = new AccessibleControlEvent(this);
    localAccessibleControlEvent.childID = osToChildID(localVARIANT.lVal);
    localAccessibleControlEvent.x = i;
    localAccessibleControlEvent.y = j;
    localAccessibleControlEvent.width = k;
    localAccessibleControlEvent.height = m;
    for (int i1 = 0; i1 < accessibleControlListenersSize(); i1++)
    {
      localObject = (AccessibleControlListener)this.accessibleControlListeners.elementAt(i1);
      ((AccessibleControlListener)localObject).getLocation(localAccessibleControlEvent);
    }
    OS.MoveMemory(paramLong1, new int[] { localAccessibleControlEvent.x }, 4);
    OS.MoveMemory(paramLong2, new int[] { localAccessibleControlEvent.y }, 4);
    OS.MoveMemory(paramLong3, new int[] { localAccessibleControlEvent.width }, 4);
    OS.MoveMemory(paramLong4, new int[] { localAccessibleControlEvent.height }, 4);
    return 0;
  }
  
  int accNavigate(int paramInt, long paramLong1, long paramLong2)
  {
    int i = -2147352573;
    if (this.iaccessible != null)
    {
      i = this.iaccessible.accNavigate(paramInt, paramLong1, paramLong2);
      if (i == -2147024809) {
        i = -2147352573;
      }
    }
    return i;
  }
  
  int accSelect(int paramInt, long paramLong)
  {
    int i = -2147352573;
    if (this.iaccessible != null)
    {
      i = this.iaccessible.accSelect(paramInt, paramLong);
      if (i == -2147024809) {
        i = -2147352573;
      }
    }
    return i;
  }
  
  int get_accChild(long paramLong1, long paramLong2)
  {
    VARIANT localVARIANT = getVARIANT(paramLong1);
    if (localVARIANT.vt != 3) {
      return -2147024809;
    }
    if (localVARIANT.lVal == 0)
    {
      AddRef();
      COM.MoveMemory(paramLong2, new long[] { getAddress() }, OS.PTR_SIZEOF);
      return 0;
    }
    final int i = osToChildID(localVARIANT.lVal);
    int j = 1;
    Accessible localAccessible1 = null;
    Object localObject2;
    if (this.iaccessible != null)
    {
      j = this.iaccessible.get_accChild(paramLong1, paramLong2);
      if (j == -2147024809) {
        j = 1;
      }
      if ((j == 0) && ((this.control instanceof ToolBar)))
      {
        localObject1 = (ToolBar)this.control;
        final ToolItem localToolItem = ((ToolBar)localObject1).getItem(i);
        if ((localToolItem != null) && ((localToolItem.getStyle() & 0x4) != 0))
        {
          localObject2 = new long[1];
          COM.MoveMemory((long[])localObject2, paramLong2, OS.PTR_SIZEOF);
          int m = 0;
          for (int n = 0; n < this.children.size(); n++)
          {
            Accessible localAccessible3 = (Accessible)this.children.elementAt(n);
            if (localAccessible3.item == localToolItem)
            {
              localAccessible3.dispose();
              localAccessible3.item = null;
              m = 1;
              break;
            }
          }
          localAccessible1 = new Accessible(this, localObject2[0]);
          localAccessible1.item = localToolItem;
          if (m == 0) {
            localToolItem.addListener(12, new Listener()
            {
              public void handleEvent(Event paramAnonymousEvent)
              {
                for (int i = 0; i < Accessible.this.children.size(); i++)
                {
                  Accessible localAccessible = (Accessible)Accessible.this.children.elementAt(i);
                  if (localAccessible.item == localToolItem) {
                    localAccessible.dispose();
                  }
                }
              }
            });
          }
          localAccessible1.addAccessibleListener(new AccessibleAdapter()
          {
            public void getName(AccessibleEvent paramAnonymousAccessibleEvent)
            {
              if (paramAnonymousAccessibleEvent.childID == -1)
              {
                AccessibleEvent localAccessibleEvent = new AccessibleEvent(Accessible.this);
                localAccessibleEvent.childID = i;
                for (int i = 0; i < Accessible.this.accessibleListenersSize(); i++)
                {
                  AccessibleListener localAccessibleListener = (AccessibleListener)Accessible.this.accessibleListeners.elementAt(i);
                  localAccessibleListener.getName(localAccessibleEvent);
                }
                paramAnonymousAccessibleEvent.result = localAccessibleEvent.result;
              }
            }
          });
        }
      }
    }
    Object localObject1 = new AccessibleControlEvent(this);
    ((AccessibleControlEvent)localObject1).childID = i;
    for (int k = 0; k < accessibleControlListenersSize(); k++)
    {
      localObject2 = (AccessibleControlListener)this.accessibleControlListeners.elementAt(k);
      ((AccessibleControlListener)localObject2).getChild((AccessibleControlEvent)localObject1);
    }
    Accessible localAccessible2 = ((AccessibleControlEvent)localObject1).accessible;
    if (localAccessible2 == null) {
      localAccessible2 = localAccessible1;
    }
    if (localAccessible2 != null)
    {
      localAccessible2.AddRef();
      COM.MoveMemory(paramLong2, new long[] { localAccessible2.getAddress() }, OS.PTR_SIZEOF);
      return 0;
    }
    return j;
  }
  
  int get_accChildCount(long paramLong)
  {
    int i = 0;
    if (this.iaccessible != null)
    {
      int j = this.iaccessible.get_accChildCount(paramLong);
      if (j == 0)
      {
        int[] arrayOfInt = new int[1];
        COM.MoveMemory(arrayOfInt, paramLong, 4);
        i = arrayOfInt[0];
      }
      if (accessibleControlListenersSize() == 0) {
        return j;
      }
    }
    AccessibleControlEvent localAccessibleControlEvent = new AccessibleControlEvent(this);
    localAccessibleControlEvent.childID = -1;
    localAccessibleControlEvent.detail = i;
    for (int k = 0; k < accessibleControlListenersSize(); k++)
    {
      AccessibleControlListener localAccessibleControlListener = (AccessibleControlListener)this.accessibleControlListeners.elementAt(k);
      localAccessibleControlListener.getChildCount(localAccessibleControlEvent);
    }
    COM.MoveMemory(paramLong, new int[] { localAccessibleControlEvent.detail }, 4);
    return 0;
  }
  
  int get_accDefaultAction(long paramLong1, long paramLong2)
  {
    VARIANT localVARIANT = getVARIANT(paramLong1);
    if (localVARIANT.vt != 3) {
      return -2147024809;
    }
    int i = -2147352573;
    String str = null;
    Object localObject2;
    if (this.iaccessible != null)
    {
      i = this.iaccessible.get_accDefaultAction(paramLong1, paramLong2);
      if (i == -2147024809) {
        i = 1;
      }
      if (accessibleControlListenersSize() == 0) {
        return i;
      }
      if (i == 0)
      {
        localObject1 = new long[1];
        COM.MoveMemory((long[])localObject1, paramLong2, OS.PTR_SIZEOF);
        j = COM.SysStringByteLen(localObject1[0]);
        if (j > 0)
        {
          localObject2 = new char[(j + 1) / 2];
          COM.MoveMemory((char[])localObject2, localObject1[0], j);
          str = new String((char[])localObject2);
        }
      }
    }
    Object localObject1 = new AccessibleControlEvent(this);
    ((AccessibleControlEvent)localObject1).childID = osToChildID(localVARIANT.lVal);
    ((AccessibleControlEvent)localObject1).result = str;
    for (int j = 0; j < accessibleControlListenersSize(); j++)
    {
      localObject2 = (AccessibleControlListener)this.accessibleControlListeners.elementAt(j);
      ((AccessibleControlListener)localObject2).getDefaultAction((AccessibleControlEvent)localObject1);
    }
    if (((((AccessibleControlEvent)localObject1).result == null) || (((AccessibleControlEvent)localObject1).result.length() == 0)) && (localVARIANT.lVal == 0)) {
      i = get_name(0, paramLong2);
    }
    if (((AccessibleControlEvent)localObject1).result == null) {
      return i;
    }
    if (((AccessibleControlEvent)localObject1).result.length() == 0) {
      return 1;
    }
    setString(paramLong2, ((AccessibleControlEvent)localObject1).result);
    return 0;
  }
  
  int get_accDescription(long paramLong1, long paramLong2)
  {
    VARIANT localVARIANT = getVARIANT(paramLong1);
    if (localVARIANT.vt != 3) {
      return -2147024809;
    }
    int i = -2147352573;
    String str = null;
    if (this.iaccessible != null)
    {
      i = this.iaccessible.get_accDescription(paramLong1, paramLong2);
      if (i == -2147024809) {
        i = 1;
      }
      if ((accessibleListenersSize() == 0) && (!(this.control instanceof Tree))) {
        return i;
      }
      if (i == 0)
      {
        localObject = new long[1];
        COM.MoveMemory((long[])localObject, paramLong2, OS.PTR_SIZEOF);
        int j = COM.SysStringByteLen(localObject[0]);
        if (j > 0)
        {
          char[] arrayOfChar = new char[(j + 1) / 2];
          COM.MoveMemory(arrayOfChar, localObject[0], j);
          str = new String(arrayOfChar);
        }
      }
    }
    Object localObject = new AccessibleEvent(this);
    ((AccessibleEvent)localObject).childID = osToChildID(localVARIANT.lVal);
    ((AccessibleEvent)localObject).result = str;
    if ((localVARIANT.lVal != 0) && ((this.control instanceof Tree)))
    {
      Tree localTree = (Tree)this.control;
      int m = localTree.getColumnCount();
      if (m > 1)
      {
        long l1 = this.control.handle;
        long l2 = 0L;
        if (OS.COMCTL32_MAJOR >= 6) {
          l2 = OS.SendMessage(l1, 4394, localVARIANT.lVal, 0L);
        } else {
          l2 = localVARIANT.lVal;
        }
        Widget localWidget = localTree.getDisplay().findWidget(l1, l2);
        ((AccessibleEvent)localObject).result = "";
        if ((localWidget != null) && ((localWidget instanceof TreeItem)))
        {
          TreeItem localTreeItem = (TreeItem)localWidget;
          for (int n = 1; n < m; n++)
          {
            Object tmp319_317 = localObject;
            tmp319_317.result = (tmp319_317.result + localTree.getColumn(n).getText() + ": " + localTreeItem.getText(n));
            if (n + 1 < m) {
              localObject.result += ", ";
            }
          }
        }
      }
    }
    for (int k = 0; k < accessibleListenersSize(); k++)
    {
      AccessibleListener localAccessibleListener = (AccessibleListener)this.accessibleListeners.elementAt(k);
      localAccessibleListener.getDescription((AccessibleEvent)localObject);
    }
    if (((AccessibleEvent)localObject).result == null) {
      return i;
    }
    if (((AccessibleEvent)localObject).result.length() == 0) {
      return 1;
    }
    setString(paramLong2, ((AccessibleEvent)localObject).result);
    return 0;
  }
  
  int get_accFocus(long paramLong)
  {
    int i = -2;
    if (this.iaccessible != null)
    {
      int j = this.iaccessible.get_accFocus(paramLong);
      if (j == 0)
      {
        VARIANT localVARIANT = getVARIANT(paramLong);
        if (localVARIANT.vt == 3) {
          i = localVARIANT.lVal;
        }
      }
      if (accessibleControlListenersSize() == 0) {
        return j;
      }
    }
    AccessibleControlEvent localAccessibleControlEvent = new AccessibleControlEvent(this);
    localAccessibleControlEvent.childID = (i == -2 ? -2 : osToChildID(i));
    for (int k = 0; k < accessibleControlListenersSize(); k++)
    {
      AccessibleControlListener localAccessibleControlListener = (AccessibleControlListener)this.accessibleControlListeners.elementAt(k);
      localAccessibleControlListener.getFocus(localAccessibleControlEvent);
    }
    Accessible localAccessible = localAccessibleControlEvent.accessible;
    if (localAccessible != null)
    {
      localAccessible.AddRef();
      setPtrVARIANT(paramLong, (short)9, localAccessible.getAddress());
      return 0;
    }
    int m = localAccessibleControlEvent.childID;
    if (m == -2)
    {
      setIntVARIANT(paramLong, (short)0, 0);
      return 1;
    }
    if (m == -1)
    {
      AddRef();
      setIntVARIANT(paramLong, (short)3, 0);
      return 0;
    }
    setIntVARIANT(paramLong, (short)3, childIDToOs(m));
    return 0;
  }
  
  int get_accHelp(long paramLong1, long paramLong2)
  {
    VARIANT localVARIANT = getVARIANT(paramLong1);
    if (localVARIANT.vt != 3) {
      return -2147024809;
    }
    int i = -2147352573;
    String str = null;
    Object localObject2;
    if (this.iaccessible != null)
    {
      i = this.iaccessible.get_accHelp(paramLong1, paramLong2);
      if (i == -2147024809) {
        i = 1;
      }
      if (accessibleListenersSize() == 0) {
        return i;
      }
      if (i == 0)
      {
        localObject1 = new long[1];
        COM.MoveMemory((long[])localObject1, paramLong2, OS.PTR_SIZEOF);
        j = COM.SysStringByteLen(localObject1[0]);
        if (j > 0)
        {
          localObject2 = new char[(j + 1) / 2];
          COM.MoveMemory((char[])localObject2, localObject1[0], j);
          str = new String((char[])localObject2);
        }
      }
    }
    Object localObject1 = new AccessibleEvent(this);
    ((AccessibleEvent)localObject1).childID = osToChildID(localVARIANT.lVal);
    ((AccessibleEvent)localObject1).result = str;
    for (int j = 0; j < accessibleListenersSize(); j++)
    {
      localObject2 = (AccessibleListener)this.accessibleListeners.elementAt(j);
      ((AccessibleListener)localObject2).getHelp((AccessibleEvent)localObject1);
    }
    if (((AccessibleEvent)localObject1).result == null) {
      return i;
    }
    if (((AccessibleEvent)localObject1).result.length() == 0) {
      return 1;
    }
    setString(paramLong2, ((AccessibleEvent)localObject1).result);
    return 0;
  }
  
  int get_accHelpTopic(long paramLong1, long paramLong2, long paramLong3)
  {
    int i = -2147352573;
    if (this.iaccessible != null)
    {
      i = this.iaccessible.get_accHelpTopic(paramLong1, paramLong2, paramLong3);
      if (i == -2147024809) {
        i = -2147352573;
      }
    }
    return i;
  }
  
  int get_accKeyboardShortcut(long paramLong1, long paramLong2)
  {
    VARIANT localVARIANT = getVARIANT(paramLong1);
    if (localVARIANT.vt != 3) {
      return -2147024809;
    }
    int i = -2147352573;
    String str = null;
    Object localObject2;
    if (this.iaccessible != null)
    {
      i = this.iaccessible.get_accKeyboardShortcut(paramLong1, paramLong2);
      if (i == -2147024809) {
        i = 1;
      }
      if ((accessibleListenersSize() == 0) && (!(this.control instanceof TabFolder))) {
        return i;
      }
      if (i == 0)
      {
        localObject1 = new long[1];
        COM.MoveMemory((long[])localObject1, paramLong2, OS.PTR_SIZEOF);
        j = COM.SysStringByteLen(localObject1[0]);
        if (j > 0)
        {
          localObject2 = new char[(j + 1) / 2];
          COM.MoveMemory((char[])localObject2, localObject1[0], j);
          str = new String((char[])localObject2);
        }
      }
    }
    Object localObject1 = new AccessibleEvent(this);
    ((AccessibleEvent)localObject1).childID = osToChildID(localVARIANT.lVal);
    ((AccessibleEvent)localObject1).result = str;
    if ((localVARIANT.lVal == 0) && ((this.control instanceof TabFolder))) {
      ((AccessibleEvent)localObject1).result = SWT.getMessage("SWT_SwitchPage_Shortcut");
    }
    for (int j = 0; j < accessibleListenersSize(); j++)
    {
      localObject2 = (AccessibleListener)this.accessibleListeners.elementAt(j);
      ((AccessibleListener)localObject2).getKeyboardShortcut((AccessibleEvent)localObject1);
    }
    if (((AccessibleEvent)localObject1).result == null) {
      return i;
    }
    if (((AccessibleEvent)localObject1).result.length() == 0) {
      return 1;
    }
    setString(paramLong2, ((AccessibleEvent)localObject1).result);
    return 0;
  }
  
  int get_accName(long paramLong1, long paramLong2)
  {
    VARIANT localVARIANT = getVARIANT(paramLong1);
    if (localVARIANT.vt != 3) {
      return -2147024809;
    }
    int i = 1;
    String str = null;
    Object localObject2;
    if (this.iaccessible != null)
    {
      i = this.iaccessible.get_accName(paramLong1, paramLong2);
      if (i == 0)
      {
        localObject1 = new long[1];
        COM.MoveMemory((long[])localObject1, paramLong2, OS.PTR_SIZEOF);
        j = COM.SysStringByteLen(localObject1[0]);
        if (j > 0)
        {
          localObject2 = new char[(j + 1) / 2];
          COM.MoveMemory((char[])localObject2, localObject1[0], j);
          str = new String((char[])localObject2);
        }
      }
      if (i == -2147024809) {
        i = 1;
      }
      if ((accessibleListenersSize() == 0) && (!(this.control instanceof Text))) {
        return i;
      }
    }
    Object localObject1 = new AccessibleEvent(this);
    ((AccessibleEvent)localObject1).childID = osToChildID(localVARIANT.lVal);
    ((AccessibleEvent)localObject1).result = str;
    if (((this.control instanceof Text)) && ((this.control.getStyle() & 0x80) != 0) && (str == null)) {
      ((AccessibleEvent)localObject1).result = ((Text)this.control).getMessage();
    }
    for (int j = 0; j < accessibleListenersSize(); j++)
    {
      localObject2 = (AccessibleListener)this.accessibleListeners.elementAt(j);
      ((AccessibleListener)localObject2).getName((AccessibleEvent)localObject1);
    }
    if (((AccessibleEvent)localObject1).result == null) {
      return i;
    }
    if (((AccessibleEvent)localObject1).result.length() == 0) {
      return 1;
    }
    setString(paramLong2, ((AccessibleEvent)localObject1).result);
    return 0;
  }
  
  int get_accParent(long paramLong)
  {
    int i = -2147352573;
    if (this.iaccessible != null) {
      i = this.iaccessible.get_accParent(paramLong);
    }
    if (this.parent != null)
    {
      this.parent.AddRef();
      COM.MoveMemory(paramLong, new long[] { this.parent.getAddress() }, OS.PTR_SIZEOF);
      i = 0;
    }
    return i;
  }
  
  int get_accRole(long paramLong1, long paramLong2)
  {
    VARIANT localVARIANT1 = getVARIANT(paramLong1);
    if (localVARIANT1.vt != 3) {
      return -2147024809;
    }
    int i = 10;
    if (this.iaccessible != null)
    {
      int j = this.iaccessible.get_accRole(paramLong1, paramLong2);
      if (j == 0)
      {
        VARIANT localVARIANT2 = getVARIANT(paramLong2);
        if (localVARIANT2.vt == 3) {
          i = localVARIANT2.lVal;
        }
      }
    }
    AccessibleControlEvent localAccessibleControlEvent = new AccessibleControlEvent(this);
    localAccessibleControlEvent.childID = osToChildID(localVARIANT1.lVal);
    localAccessibleControlEvent.detail = osToRole(i);
    if ((((this.control instanceof Tree)) || ((this.control instanceof Table))) && (localVARIANT1.lVal != 0) && ((this.control.getStyle() & 0x20) != 0)) {
      localAccessibleControlEvent.detail = 44;
    }
    for (int k = 0; k < accessibleControlListenersSize(); k++)
    {
      AccessibleControlListener localAccessibleControlListener = (AccessibleControlListener)this.accessibleControlListeners.elementAt(k);
      localAccessibleControlListener.getRole(localAccessibleControlEvent);
    }
    setIntVARIANT(paramLong2, (short)3, roleToOs(localAccessibleControlEvent.detail));
    return 0;
  }
  
  int get_accSelection(long paramLong)
  {
    int i = -2;
    long l = 0L;
    if (this.iaccessible != null)
    {
      int j = this.iaccessible.get_accSelection(paramLong);
      if (accessibleControlListenersSize() == 0) {
        return j;
      }
      if (j == 0)
      {
        VARIANT localVARIANT = getVARIANT(paramLong);
        if (localVARIANT.vt == 3) {
          i = osToChildID(localVARIANT.lVal);
        } else if (localVARIANT.vt == 9) {
          l = localVARIANT.lVal;
        } else if (localVARIANT.vt == 13) {
          i = -3;
        }
      }
    }
    AccessibleControlEvent localAccessibleControlEvent = new AccessibleControlEvent(this);
    localAccessibleControlEvent.childID = i;
    for (int k = 0; k < accessibleControlListenersSize(); k++)
    {
      AccessibleControlListener localAccessibleControlListener = (AccessibleControlListener)this.accessibleControlListeners.elementAt(k);
      localAccessibleControlListener.getSelection(localAccessibleControlEvent);
    }
    Accessible localAccessible = localAccessibleControlEvent.accessible;
    if (localAccessible != null)
    {
      localAccessible.AddRef();
      setPtrVARIANT(paramLong, (short)9, localAccessible.getAddress());
      return 0;
    }
    int m = localAccessibleControlEvent.childID;
    if (m == -2)
    {
      if (l != 0L) {
        return 0;
      }
      setIntVARIANT(paramLong, (short)0, 0);
      return 1;
    }
    if (m == -3) {
      return 0;
    }
    if (m == -1)
    {
      AddRef();
      setPtrVARIANT(paramLong, (short)9, getAddress());
      return 0;
    }
    setIntVARIANT(paramLong, (short)3, childIDToOs(m));
    return 0;
  }
  
  int get_accState(long paramLong1, long paramLong2)
  {
    VARIANT localVARIANT = getVARIANT(paramLong1);
    if (localVARIANT.vt != 3) {
      return -2147024809;
    }
    int i = 0;
    if (this.iaccessible != null)
    {
      j = this.iaccessible.get_accState(paramLong1, paramLong2);
      if (j == 0)
      {
        localObject1 = getVARIANT(paramLong2);
        if (((VARIANT)localObject1).vt == 3) {
          i = ((VARIANT)localObject1).lVal;
        }
      }
    }
    int j = 0;
    Object localObject1 = new AccessibleControlEvent(this);
    ((AccessibleControlEvent)localObject1).childID = osToChildID(localVARIANT.lVal);
    ((AccessibleControlEvent)localObject1).detail = osToState(i);
    if (localVARIANT.lVal != 0)
    {
      Object localObject2;
      if (((this.control instanceof Tree)) && ((this.control.getStyle() & 0x20) != 0))
      {
        long l1 = this.control.handle;
        localObject2 = new TVITEM();
        ((TVITEM)localObject2).mask = 24;
        ((TVITEM)localObject2).stateMask = 61440;
        if (OS.COMCTL32_MAJOR >= 6) {
          ((TVITEM)localObject2).hItem = OS.SendMessage(l1, 4394, localVARIANT.lVal, 0L);
        } else {
          ((TVITEM)localObject2).hItem = localVARIANT.lVal;
        }
        long l2 = OS.SendMessage(l1, OS.TVM_GETITEM, 0L, (TVITEM)localObject2);
        int n = (l2 != 0L) && ((((TVITEM)localObject2).state >> 12 & 0x1) == 0) ? 1 : 0;
        if (n != 0) {
          localObject1.detail |= 0x10;
        }
        j = ((TVITEM)localObject2).state >> 12 > 2 ? 1 : 0;
      }
      else if (((this.control instanceof Table)) && ((this.control.getStyle() & 0x20) != 0))
      {
        Table localTable = (Table)this.control;
        int m = ((AccessibleControlEvent)localObject1).childID;
        if ((0 <= m) && (m < localTable.getItemCount()))
        {
          localObject2 = localTable.getItem(m);
          if (((TableItem)localObject2).getChecked()) {
            localObject1.detail |= 0x10;
          }
          if (((TableItem)localObject2).getGrayed()) {
            j = 1;
          }
        }
      }
    }
    for (int k = 0; k < accessibleControlListenersSize(); k++)
    {
      AccessibleControlListener localAccessibleControlListener = (AccessibleControlListener)this.accessibleControlListeners.elementAt(k);
      localAccessibleControlListener.getState((AccessibleControlEvent)localObject1);
    }
    k = stateToOs(((AccessibleControlEvent)localObject1).detail);
    if (((k & 0x10) != 0) && (j != 0))
    {
      k &= 0xFFFFFFEF;
      k |= 0x20;
    }
    setIntVARIANT(paramLong2, (short)3, k);
    return 0;
  }
  
  int get_accValue(long paramLong1, long paramLong2)
  {
    VARIANT localVARIANT = getVARIANT(paramLong1);
    if (localVARIANT.vt != 3) {
      return -2147024809;
    }
    int i = -2147352573;
    String str = null;
    Object localObject2;
    if (this.iaccessible != null)
    {
      i = this.iaccessible.get_accValue(paramLong1, paramLong2);
      if (i == 0)
      {
        localObject1 = new long[1];
        COM.MoveMemory((long[])localObject1, paramLong2, OS.PTR_SIZEOF);
        j = COM.SysStringByteLen(localObject1[0]);
        if (j > 0)
        {
          localObject2 = new char[(j + 1) / 2];
          COM.MoveMemory((char[])localObject2, localObject1[0], j);
          str = new String((char[])localObject2);
        }
      }
      if (i == -2147024809) {
        i = -2147352573;
      }
      if ((accessibleControlListenersSize() == 0) && (!(this.control instanceof Text))) {
        return i;
      }
    }
    Object localObject1 = new AccessibleControlEvent(this);
    ((AccessibleControlEvent)localObject1).childID = osToChildID(localVARIANT.lVal);
    ((AccessibleControlEvent)localObject1).result = str;
    if (((this.control instanceof Text)) && ((this.control.getStyle() & 0x80) != 0) && (!this.control.isFocusControl())) {
      ((AccessibleControlEvent)localObject1).result = ((Text)this.control).getMessage();
    }
    for (int j = 0; j < accessibleControlListenersSize(); j++)
    {
      localObject2 = (AccessibleControlListener)this.accessibleControlListeners.elementAt(j);
      ((AccessibleControlListener)localObject2).getValue((AccessibleControlEvent)localObject1);
    }
    if (((AccessibleControlEvent)localObject1).result == null) {
      return i;
    }
    setString(paramLong2, ((AccessibleControlEvent)localObject1).result);
    return 0;
  }
  
  int put_accName(long paramLong1, long paramLong2)
  {
    return -2147467263;
  }
  
  int put_accValue(long paramLong1, long paramLong2)
  {
    VARIANT localVARIANT = getVARIANT(paramLong1);
    if (localVARIANT.vt != 3) {
      return -2147024809;
    }
    int i = -2147352573;
    if ((localVARIANT.lVal == 0) && (accessibleEditableTextListenersSize() > 0))
    {
      AccessibleEditableTextEvent localAccessibleEditableTextEvent = new AccessibleEditableTextEvent(this);
      localAccessibleEditableTextEvent.start = 0;
      localAccessibleEditableTextEvent.end = getCharacterCount();
      if (localAccessibleEditableTextEvent.end >= 0)
      {
        int j = COM.SysStringByteLen(paramLong2);
        char[] arrayOfChar = new char[(j + 1) / 2];
        OS.MoveMemory(arrayOfChar, paramLong2, j);
        localAccessibleEditableTextEvent.string = new String(arrayOfChar);
        for (int k = 0; k < accessibleEditableTextListenersSize(); k++)
        {
          AccessibleEditableTextListener localAccessibleEditableTextListener = (AccessibleEditableTextListener)this.accessibleEditableTextListeners.elementAt(k);
          localAccessibleEditableTextListener.replaceText(localAccessibleEditableTextEvent);
        }
        if ((localAccessibleEditableTextEvent.result != null) && (localAccessibleEditableTextEvent.result.equals("OK"))) {
          i = 0;
        }
      }
    }
    if ((i != 0) && (this.iaccessible != null))
    {
      i = this.iaccessible.put_accValue(paramLong1, paramLong2);
      if (i == -2147024809) {
        i = -2147352573;
      }
    }
    return i;
  }
  
  int Next(int paramInt, long paramLong1, long paramLong2)
  {
    int i;
    Object localObject2;
    Object localObject4;
    if ((this.iaccessible != null) && (accessibleControlListenersSize() == 0))
    {
      localObject1 = new long[1];
      i = this.iaccessible.QueryInterface(COM.IIDIEnumVARIANT, (long[])localObject1);
      if (i != 0) {
        return i;
      }
      localObject2 = new IEnumVARIANT(localObject1[0]);
      localObject4 = new int[1];
      i = ((IEnumVARIANT)localObject2).Next(paramInt, paramLong1, (int[])localObject4);
      ((IEnumVARIANT)localObject2).Release();
      COM.MoveMemory(paramLong2, (int[])localObject4, 4);
      return i;
    }
    if (paramLong1 == 0L) {
      return -2147024809;
    }
    if ((paramLong2 == 0L) && (paramInt != 1)) {
      return -2147024809;
    }
    if (this.enumIndex == 0)
    {
      localObject1 = new AccessibleControlEvent(this);
      ((AccessibleControlEvent)localObject1).childID = -1;
      for (i = 0; i < accessibleControlListenersSize(); i++)
      {
        localObject2 = (AccessibleControlListener)this.accessibleControlListeners.elementAt(i);
        ((AccessibleControlListener)localObject2).getChildren((AccessibleControlEvent)localObject1);
      }
      this.variants = ((AccessibleControlEvent)localObject1).children;
    }
    Object localObject1 = null;
    if ((this.variants != null) && (paramInt >= 1))
    {
      i = this.enumIndex + paramInt - 1;
      if (i > this.variants.length - 1) {
        i = this.variants.length - 1;
      }
      if (this.enumIndex <= i)
      {
        localObject1 = new Object[i - this.enumIndex + 1];
        for (int j = 0; j < localObject1.length; j++)
        {
          localObject4 = this.variants[this.enumIndex];
          if ((localObject4 instanceof Integer)) {
            localObject1[j] = new Integer(childIDToOs(((Integer)localObject4).intValue()));
          } else {
            localObject1[j] = localObject4;
          }
          this.enumIndex += 1;
        }
      }
    }
    if (localObject1 != null)
    {
      for (i = 0; i < localObject1.length; i++)
      {
        Object localObject3 = localObject1[i];
        if ((localObject3 instanceof Integer))
        {
          int k = ((Integer)localObject3).intValue();
          setIntVARIANT(paramLong1 + i * VARIANT.sizeof, (short)3, k);
        }
        else
        {
          Accessible localAccessible = (Accessible)localObject3;
          localAccessible.AddRef();
          setPtrVARIANT(paramLong1 + i * VARIANT.sizeof, (short)9, localAccessible.getAddress());
        }
      }
      if (paramLong2 != 0L) {
        COM.MoveMemory(paramLong2, new int[] { localObject1.length }, 4);
      }
      if (localObject1.length == paramInt) {
        return 0;
      }
    }
    else if (paramLong2 != 0L)
    {
      COM.MoveMemory(paramLong2, new int[] { 0 }, 4);
    }
    return 1;
  }
  
  int Skip(int paramInt)
  {
    if ((this.iaccessible != null) && (accessibleControlListenersSize() == 0))
    {
      long[] arrayOfLong = new long[1];
      int i = this.iaccessible.QueryInterface(COM.IIDIEnumVARIANT, arrayOfLong);
      if (i != 0) {
        return i;
      }
      IEnumVARIANT localIEnumVARIANT = new IEnumVARIANT(arrayOfLong[0]);
      i = localIEnumVARIANT.Skip(paramInt);
      localIEnumVARIANT.Release();
      return i;
    }
    if (paramInt < 1) {
      return -2147024809;
    }
    this.enumIndex += paramInt;
    if (this.enumIndex > this.variants.length - 1)
    {
      this.enumIndex = (this.variants.length - 1);
      return 1;
    }
    return 0;
  }
  
  int Reset()
  {
    if ((this.iaccessible != null) && (accessibleControlListenersSize() == 0))
    {
      long[] arrayOfLong = new long[1];
      int i = this.iaccessible.QueryInterface(COM.IIDIEnumVARIANT, arrayOfLong);
      if (i != 0) {
        return i;
      }
      IEnumVARIANT localIEnumVARIANT = new IEnumVARIANT(arrayOfLong[0]);
      i = localIEnumVARIANT.Reset();
      localIEnumVARIANT.Release();
      return i;
    }
    this.enumIndex = 0;
    return 0;
  }
  
  int Clone(long paramLong)
  {
    if ((this.iaccessible != null) && (accessibleControlListenersSize() == 0))
    {
      long[] arrayOfLong1 = new long[1];
      int i = this.iaccessible.QueryInterface(COM.IIDIEnumVARIANT, arrayOfLong1);
      if (i != 0) {
        return i;
      }
      IEnumVARIANT localIEnumVARIANT = new IEnumVARIANT(arrayOfLong1[0]);
      long[] arrayOfLong2 = new long[1];
      i = localIEnumVARIANT.Clone(arrayOfLong2);
      localIEnumVARIANT.Release();
      COM.MoveMemory(paramLong, arrayOfLong2, OS.PTR_SIZEOF);
      return i;
    }
    if (paramLong == 0L) {
      return -2147024809;
    }
    COM.MoveMemory(paramLong, new long[] { this.objIEnumVARIANT.getAddress() }, OS.PTR_SIZEOF);
    AddRef();
    return 0;
  }
  
  int get_nRelations(long paramLong)
  {
    int i = getRelationCount();
    COM.MoveMemory(paramLong, new int[] { i }, 4);
    return 0;
  }
  
  int get_relation(int paramInt, long paramLong)
  {
    int i = -1;
    for (int j = 0; j < 15; j++)
    {
      Relation localRelation = this.relations[j];
      if (localRelation != null) {
        i++;
      }
      if (i == paramInt)
      {
        localRelation.AddRef();
        COM.MoveMemory(paramLong, new long[] { localRelation.getAddress() }, OS.PTR_SIZEOF);
        return 0;
      }
    }
    return -2147024809;
  }
  
  int get_relations(int paramInt, long paramLong1, long paramLong2)
  {
    int i = 0;
    for (int j = 0; (j < 15) && (i != paramInt); j++)
    {
      Relation localRelation = this.relations[j];
      if (localRelation != null)
      {
        localRelation.AddRef();
        COM.MoveMemory(paramLong1 + i * OS.PTR_SIZEOF, new long[] { localRelation.getAddress() }, OS.PTR_SIZEOF);
        i++;
      }
    }
    COM.MoveMemory(paramLong2, new int[] { i }, 4);
    return 0;
  }
  
  int get_role(long paramLong)
  {
    int i = getRole();
    if (i == 0) {
      i = getDefaultRole();
    }
    COM.MoveMemory(paramLong, new int[] { i }, 4);
    return 0;
  }
  
  int scrollTo(int paramInt)
  {
    if ((paramInt < 4) || (paramInt > 6)) {
      return -2147024809;
    }
    return -2147467263;
  }
  
  int scrollToPoint(int paramInt1, int paramInt2, int paramInt3)
  {
    if (paramInt1 != 0) {
      return -2147024809;
    }
    return -2147467263;
  }
  
  int get_groupPosition(long paramLong1, long paramLong2, long paramLong3)
  {
    AccessibleAttributeEvent localAccessibleAttributeEvent = new AccessibleAttributeEvent(this);
    localAccessibleAttributeEvent.groupLevel = (localAccessibleAttributeEvent.groupCount = localAccessibleAttributeEvent.groupIndex = -1);
    for (int i = 0; i < accessibleAttributeListenersSize(); i++)
    {
      AccessibleAttributeListener localAccessibleAttributeListener = (AccessibleAttributeListener)this.accessibleAttributeListeners.elementAt(i);
      localAccessibleAttributeListener.getAttributes(localAccessibleAttributeEvent);
    }
    i = localAccessibleAttributeEvent.groupLevel != -1 ? localAccessibleAttributeEvent.groupLevel : 0;
    int j = localAccessibleAttributeEvent.groupCount != -1 ? localAccessibleAttributeEvent.groupCount : 0;
    int k = localAccessibleAttributeEvent.groupIndex != -1 ? localAccessibleAttributeEvent.groupIndex : 0;
    if ((j == 0) && (k == 0) && ((this.control instanceof Button)) && ((this.control.getStyle() & 0x10) != 0))
    {
      Control[] arrayOfControl = this.control.getParent().getChildren();
      k = 1;
      j = 1;
      for (int m = 0; m < arrayOfControl.length; m++)
      {
        Control localControl = arrayOfControl[m];
        if (((localControl instanceof Button)) && ((localControl.getStyle() & 0x10) != 0)) {
          if (localControl == this.control) {
            k = j;
          } else {
            j++;
          }
        }
      }
    }
    COM.MoveMemory(paramLong1, new int[] { i }, 4);
    COM.MoveMemory(paramLong2, new int[] { j }, 4);
    COM.MoveMemory(paramLong3, new int[] { k }, 4);
    if ((i == 0) && (j == 0) && (k == 0)) {
      return 1;
    }
    return 0;
  }
  
  int get_states(long paramLong)
  {
    AccessibleControlEvent localAccessibleControlEvent = new AccessibleControlEvent(this);
    localAccessibleControlEvent.childID = -1;
    for (int i = 0; i < accessibleControlListenersSize(); i++)
    {
      AccessibleControlListener localAccessibleControlListener = (AccessibleControlListener)this.accessibleControlListeners.elementAt(i);
      localAccessibleControlListener.getState(localAccessibleControlEvent);
    }
    i = localAccessibleControlEvent.detail;
    int j = 0;
    if ((i & 0x4000000) != 0) {
      j |= 0x1;
    }
    if ((i & 0x8000000) != 0) {
      j |= 0x2000;
    }
    if ((i & 0x10000000) != 0) {
      j |= 0x200;
    }
    if ((i & 0x2000000) != 0) {
      j |= 0x800;
    }
    if ((i & 0x20000000) != 0) {
      j |= 0x40;
    }
    if ((i & 0x40000000) != 0) {
      j |= 0x8000;
    }
    if ((getRole() == 42) && (accessibleTextExtendedListenersSize() > 0)) {
      j |= 0x8;
    }
    COM.MoveMemory(paramLong, new int[] { j }, 4);
    return 0;
  }
  
  int get_extendedRole(long paramLong)
  {
    setString(paramLong, null);
    return 1;
  }
  
  int get_localizedExtendedRole(long paramLong)
  {
    setString(paramLong, null);
    return 1;
  }
  
  int get_nExtendedStates(long paramLong)
  {
    COM.MoveMemory(paramLong, new int[] { 0 }, 4);
    return 0;
  }
  
  int get_extendedStates(int paramInt, long paramLong1, long paramLong2)
  {
    setString(paramLong1, null);
    COM.MoveMemory(paramLong2, new int[] { 0 }, 4);
    return 1;
  }
  
  int get_localizedExtendedStates(int paramInt, long paramLong1, long paramLong2)
  {
    setString(paramLong1, null);
    COM.MoveMemory(paramLong2, new int[] { 0 }, 4);
    return 1;
  }
  
  int get_uniqueID(long paramLong)
  {
    if (this.uniqueID == -1) {
      this.uniqueID = (UniqueID--);
    }
    COM.MoveMemory(paramLong, new long[] { this.uniqueID }, 4);
    return 0;
  }
  
  int get_windowHandle(long paramLong)
  {
    COM.MoveMemory(paramLong, new long[] { this.control.handle }, OS.PTR_SIZEOF);
    return 0;
  }
  
  int get_indexInParent(long paramLong)
  {
    AccessibleControlEvent localAccessibleControlEvent = new AccessibleControlEvent(this);
    localAccessibleControlEvent.childID = -5;
    localAccessibleControlEvent.detail = -1;
    for (int i = 0; i < accessibleControlListenersSize(); i++)
    {
      AccessibleControlListener localAccessibleControlListener = (AccessibleControlListener)this.accessibleControlListeners.elementAt(i);
      localAccessibleControlListener.getChild(localAccessibleControlEvent);
    }
    i = localAccessibleControlEvent.detail;
    if (i == -1) {}
    COM.MoveMemory(paramLong, new int[] { i }, 4);
    return i == -1 ? 1 : 0;
  }
  
  int get_locale(long paramLong)
  {
    Locale localLocale = Locale.getDefault();
    char[] arrayOfChar = (localLocale.getLanguage() + "\000").toCharArray();
    long l = COM.SysAllocString(arrayOfChar);
    COM.MoveMemory(paramLong, new long[] { l }, OS.PTR_SIZEOF);
    arrayOfChar = (localLocale.getCountry() + "\000").toCharArray();
    l = COM.SysAllocString(arrayOfChar);
    COM.MoveMemory(paramLong + OS.PTR_SIZEOF, new long[] { l }, OS.PTR_SIZEOF);
    arrayOfChar = (localLocale.getVariant() + "\000").toCharArray();
    l = COM.SysAllocString(arrayOfChar);
    COM.MoveMemory(paramLong + 2 * OS.PTR_SIZEOF, new long[] { l }, OS.PTR_SIZEOF);
    return 0;
  }
  
  int get_attributes(long paramLong)
  {
    AccessibleAttributeEvent localAccessibleAttributeEvent = new AccessibleAttributeEvent(this);
    for (int i = 0; i < accessibleAttributeListenersSize(); i++)
    {
      AccessibleAttributeListener localAccessibleAttributeListener = (AccessibleAttributeListener)this.accessibleAttributeListeners.elementAt(i);
      localAccessibleAttributeListener.getAttributes(localAccessibleAttributeEvent);
    }
    String str = "";
    str = str + "margin-left:" + localAccessibleAttributeEvent.leftMargin + ";";
    str = str + "margin-top:" + localAccessibleAttributeEvent.topMargin + ";";
    str = str + "margin-right:" + localAccessibleAttributeEvent.rightMargin + ";";
    str = str + "margin-bottom:" + localAccessibleAttributeEvent.bottomMargin + ";";
    int j;
    if (localAccessibleAttributeEvent.tabStops != null) {
      for (j = 0; j < localAccessibleAttributeEvent.tabStops.length; j++) {
        str = str + "tab-stop:position=" + localAccessibleAttributeEvent.tabStops[j] + ";";
      }
    }
    if (localAccessibleAttributeEvent.justify) {
      str = str + "text-align:justify;";
    }
    str = str + "text-align:" + (localAccessibleAttributeEvent.alignment == 131072 ? "right" : localAccessibleAttributeEvent.alignment == 16384 ? "left" : "center") + ";";
    str = str + "text-indent:" + localAccessibleAttributeEvent.indent + ";";
    if (localAccessibleAttributeEvent.attributes != null) {
      for (j = 0; j + 1 < localAccessibleAttributeEvent.attributes.length; j += 2) {
        str = str + localAccessibleAttributeEvent.attributes[j] + ":" + localAccessibleAttributeEvent.attributes[(j + 1)] + ";";
      }
    }
    if (getRole() == 42) {
      str = str + "text-model:a1;";
    }
    setString(paramLong, str);
    if (str.length() == 0) {
      return 1;
    }
    return 0;
  }
  
  int get_nActions(long paramLong)
  {
    AccessibleActionEvent localAccessibleActionEvent = new AccessibleActionEvent(this);
    for (int i = 0; i < accessibleActionListenersSize(); i++)
    {
      AccessibleActionListener localAccessibleActionListener = (AccessibleActionListener)this.accessibleActionListeners.elementAt(i);
      localAccessibleActionListener.getActionCount(localAccessibleActionEvent);
    }
    COM.MoveMemory(paramLong, new int[] { localAccessibleActionEvent.count }, 4);
    return 0;
  }
  
  int doAction(int paramInt)
  {
    AccessibleActionEvent localAccessibleActionEvent = new AccessibleActionEvent(this);
    localAccessibleActionEvent.index = paramInt;
    for (int i = 0; i < accessibleActionListenersSize(); i++)
    {
      AccessibleActionListener localAccessibleActionListener = (AccessibleActionListener)this.accessibleActionListeners.elementAt(i);
      localAccessibleActionListener.doAction(localAccessibleActionEvent);
    }
    if ((localAccessibleActionEvent.result == null) || (!localAccessibleActionEvent.result.equals("OK"))) {
      return -2147024809;
    }
    return 0;
  }
  
  int get_description(int paramInt, long paramLong)
  {
    AccessibleActionEvent localAccessibleActionEvent = new AccessibleActionEvent(this);
    localAccessibleActionEvent.index = paramInt;
    for (int i = 0; i < accessibleActionListenersSize(); i++)
    {
      AccessibleActionListener localAccessibleActionListener = (AccessibleActionListener)this.accessibleActionListeners.elementAt(i);
      localAccessibleActionListener.getDescription(localAccessibleActionEvent);
    }
    setString(paramLong, localAccessibleActionEvent.result);
    if ((localAccessibleActionEvent.result == null) || (localAccessibleActionEvent.result.length() == 0)) {
      return 1;
    }
    return 0;
  }
  
  int get_keyBinding(int paramInt1, int paramInt2, long paramLong1, long paramLong2)
  {
    AccessibleActionEvent localAccessibleActionEvent = new AccessibleActionEvent(this);
    localAccessibleActionEvent.index = paramInt1;
    for (int i = 0; i < accessibleActionListenersSize(); i++)
    {
      AccessibleActionListener localAccessibleActionListener = (AccessibleActionListener)this.accessibleActionListeners.elementAt(i);
      localAccessibleActionListener.getKeyBinding(localAccessibleActionEvent);
    }
    String str1 = localAccessibleActionEvent.result;
    int j = 0;
    if (str1 != null) {
      j = str1.length();
    }
    int k = 0;
    int m = 0;
    while ((k < j) && (m != paramInt2))
    {
      int n = str1.indexOf(';', k);
      if (n == -1) {
        n = j;
      }
      String str2 = str1.substring(k, n);
      if (str2.length() > 0)
      {
        setString(paramLong1 + m * OS.PTR_SIZEOF, str2);
        m++;
      }
      k = n + 1;
    }
    COM.MoveMemory(paramLong2, new int[] { m }, 4);
    if (m == 0)
    {
      setString(paramLong1, null);
      return 1;
    }
    return 0;
  }
  
  int get_name(int paramInt, long paramLong)
  {
    AccessibleActionEvent localAccessibleActionEvent = new AccessibleActionEvent(this);
    localAccessibleActionEvent.index = paramInt;
    localAccessibleActionEvent.localized = false;
    for (int i = 0; i < accessibleActionListenersSize(); i++)
    {
      AccessibleActionListener localAccessibleActionListener = (AccessibleActionListener)this.accessibleActionListeners.elementAt(i);
      localAccessibleActionListener.getName(localAccessibleActionEvent);
    }
    if ((localAccessibleActionEvent.result == null) || (localAccessibleActionEvent.result.length() == 0))
    {
      setString(paramLong, null);
      return 1;
    }
    setString(paramLong, localAccessibleActionEvent.result);
    return 0;
  }
  
  int get_localizedName(int paramInt, long paramLong)
  {
    AccessibleActionEvent localAccessibleActionEvent = new AccessibleActionEvent(this);
    localAccessibleActionEvent.index = paramInt;
    localAccessibleActionEvent.localized = true;
    for (int i = 0; i < accessibleActionListenersSize(); i++)
    {
      AccessibleActionListener localAccessibleActionListener = (AccessibleActionListener)this.accessibleActionListeners.elementAt(i);
      localAccessibleActionListener.getName(localAccessibleActionEvent);
    }
    if ((localAccessibleActionEvent.result == null) || (localAccessibleActionEvent.result.length() == 0))
    {
      setString(paramLong, null);
      return 1;
    }
    setString(paramLong, localAccessibleActionEvent.result);
    return 0;
  }
  
  int get_appName(long paramLong)
  {
    String str = Display.getAppName();
    if ((str == null) || (str.length() == 0))
    {
      setString(paramLong, null);
      return 1;
    }
    setString(paramLong, str);
    return 0;
  }
  
  int get_appVersion(long paramLong)
  {
    String str = Display.getAppVersion();
    if ((str == null) || (str.length() == 0))
    {
      setString(paramLong, null);
      return 1;
    }
    setString(paramLong, str);
    return 0;
  }
  
  int get_toolkitName(long paramLong)
  {
    String str = "SWT";
    setString(paramLong, str);
    return 0;
  }
  
  int get_toolkitVersion(long paramLong)
  {
    String str = "" + SWT.getVersion();
    setString(paramLong, str);
    return 0;
  }
  
  int copyText(int paramInt1, int paramInt2)
  {
    AccessibleEditableTextEvent localAccessibleEditableTextEvent = new AccessibleEditableTextEvent(this);
    localAccessibleEditableTextEvent.start = (paramInt1 == -1 ? getCharacterCount() : paramInt1);
    localAccessibleEditableTextEvent.end = (paramInt2 == -1 ? getCharacterCount() : paramInt2);
    for (int i = 0; i < accessibleEditableTextListenersSize(); i++)
    {
      AccessibleEditableTextListener localAccessibleEditableTextListener = (AccessibleEditableTextListener)this.accessibleEditableTextListeners.elementAt(i);
      localAccessibleEditableTextListener.copyText(localAccessibleEditableTextEvent);
    }
    if ((localAccessibleEditableTextEvent.result == null) || (!localAccessibleEditableTextEvent.result.equals("OK"))) {
      return -2147024809;
    }
    return 0;
  }
  
  int deleteText(int paramInt1, int paramInt2)
  {
    AccessibleEditableTextEvent localAccessibleEditableTextEvent = new AccessibleEditableTextEvent(this);
    localAccessibleEditableTextEvent.start = (paramInt1 == -1 ? getCharacterCount() : paramInt1);
    localAccessibleEditableTextEvent.end = (paramInt2 == -1 ? getCharacterCount() : paramInt2);
    localAccessibleEditableTextEvent.string = "";
    for (int i = 0; i < accessibleEditableTextListenersSize(); i++)
    {
      AccessibleEditableTextListener localAccessibleEditableTextListener = (AccessibleEditableTextListener)this.accessibleEditableTextListeners.elementAt(i);
      localAccessibleEditableTextListener.replaceText(localAccessibleEditableTextEvent);
    }
    if ((localAccessibleEditableTextEvent.result == null) || (!localAccessibleEditableTextEvent.result.equals("OK"))) {
      return -2147024809;
    }
    return 0;
  }
  
  int insertText(int paramInt, long paramLong)
  {
    AccessibleEditableTextEvent localAccessibleEditableTextEvent = new AccessibleEditableTextEvent(this);
    localAccessibleEditableTextEvent.start = (paramInt == -1 ? getCharacterCount() : paramInt);
    localAccessibleEditableTextEvent.end = localAccessibleEditableTextEvent.start;
    localAccessibleEditableTextEvent.string = getString(paramLong);
    for (int i = 0; i < accessibleEditableTextListenersSize(); i++)
    {
      AccessibleEditableTextListener localAccessibleEditableTextListener = (AccessibleEditableTextListener)this.accessibleEditableTextListeners.elementAt(i);
      localAccessibleEditableTextListener.replaceText(localAccessibleEditableTextEvent);
    }
    if ((localAccessibleEditableTextEvent.result == null) || (!localAccessibleEditableTextEvent.result.equals("OK"))) {
      return -2147024809;
    }
    return 0;
  }
  
  int cutText(int paramInt1, int paramInt2)
  {
    AccessibleEditableTextEvent localAccessibleEditableTextEvent = new AccessibleEditableTextEvent(this);
    localAccessibleEditableTextEvent.start = (paramInt1 == -1 ? getCharacterCount() : paramInt1);
    localAccessibleEditableTextEvent.end = (paramInt2 == -1 ? getCharacterCount() : paramInt2);
    for (int i = 0; i < accessibleEditableTextListenersSize(); i++)
    {
      AccessibleEditableTextListener localAccessibleEditableTextListener = (AccessibleEditableTextListener)this.accessibleEditableTextListeners.elementAt(i);
      localAccessibleEditableTextListener.cutText(localAccessibleEditableTextEvent);
    }
    if ((localAccessibleEditableTextEvent.result == null) || (!localAccessibleEditableTextEvent.result.equals("OK"))) {
      return -2147024809;
    }
    return 0;
  }
  
  int pasteText(int paramInt)
  {
    AccessibleEditableTextEvent localAccessibleEditableTextEvent = new AccessibleEditableTextEvent(this);
    localAccessibleEditableTextEvent.start = (paramInt == -1 ? getCharacterCount() : paramInt);
    localAccessibleEditableTextEvent.end = localAccessibleEditableTextEvent.start;
    for (int i = 0; i < accessibleEditableTextListenersSize(); i++)
    {
      AccessibleEditableTextListener localAccessibleEditableTextListener = (AccessibleEditableTextListener)this.accessibleEditableTextListeners.elementAt(i);
      localAccessibleEditableTextListener.pasteText(localAccessibleEditableTextEvent);
    }
    if ((localAccessibleEditableTextEvent.result == null) || (!localAccessibleEditableTextEvent.result.equals("OK"))) {
      return -2147024809;
    }
    return 0;
  }
  
  int replaceText(int paramInt1, int paramInt2, long paramLong)
  {
    AccessibleEditableTextEvent localAccessibleEditableTextEvent = new AccessibleEditableTextEvent(this);
    localAccessibleEditableTextEvent.start = (paramInt1 == -1 ? getCharacterCount() : paramInt1);
    localAccessibleEditableTextEvent.end = (paramInt2 == -1 ? getCharacterCount() : paramInt2);
    localAccessibleEditableTextEvent.string = getString(paramLong);
    for (int i = 0; i < accessibleEditableTextListenersSize(); i++)
    {
      AccessibleEditableTextListener localAccessibleEditableTextListener = (AccessibleEditableTextListener)this.accessibleEditableTextListeners.elementAt(i);
      localAccessibleEditableTextListener.replaceText(localAccessibleEditableTextEvent);
    }
    if ((localAccessibleEditableTextEvent.result == null) || (!localAccessibleEditableTextEvent.result.equals("OK"))) {
      return -2147024809;
    }
    return 0;
  }
  
  int setAttributes(int paramInt1, int paramInt2, long paramLong)
  {
    AccessibleTextAttributeEvent localAccessibleTextAttributeEvent = new AccessibleTextAttributeEvent(this);
    String str1 = getString(paramLong);
    if ((str1 != null) && (str1.length() > 0))
    {
      localAccessibleTextAttributeEvent.start = (paramInt1 == -1 ? getCharacterCount() : paramInt1);
      localAccessibleTextAttributeEvent.end = (paramInt2 == -1 ? getCharacterCount() : paramInt2);
      TextStyle localTextStyle = new TextStyle();
      FontData localFontData = null;
      int i = 10;
      Object localObject = new String[0];
      int j = 0;
      String[] arrayOfString1;
      for (int k = str1.indexOf(';'); (k != -1) && (k < str1.length()); k = str1.indexOf(';', j))
      {
        String str2 = str1.substring(j, k).trim();
        int n = str2.indexOf(':');
        if ((n != -1) && (n + 1 < str2.length()))
        {
          arrayOfString1 = new String[localObject.length + 2];
          System.arraycopy(localObject, 0, arrayOfString1, 0, localObject.length);
          arrayOfString1[localObject.length] = str2.substring(0, n).trim();
          arrayOfString1[(localObject.length + 1)] = str2.substring(n + 1).trim();
          localObject = arrayOfString1;
        }
        j = k + 1;
      }
      AccessibleEditableTextListener localAccessibleEditableTextListener;
      for (int m = 0; m + 1 < localObject.length; m += 2)
      {
        localAccessibleEditableTextListener = localObject[m];
        arrayOfString1 = localObject[(m + 1)];
        if (localAccessibleEditableTextListener.equals("text-position"))
        {
          if (arrayOfString1.equals("super")) {
            localTextStyle.rise = (i / 2);
          } else if (arrayOfString1.equals("sub")) {
            localTextStyle.rise = (-i / 2);
          }
        }
        else if (localAccessibleEditableTextListener.equals("text-underline-type"))
        {
          localTextStyle.underline = true;
          if (arrayOfString1.equals("double")) {
            localTextStyle.underlineStyle = 1;
          } else if ((arrayOfString1.equals("single")) && (localTextStyle.underlineStyle != 3) && (localTextStyle.underlineStyle != 2)) {
            localTextStyle.underlineStyle = 0;
          }
        }
        else if ((localAccessibleEditableTextListener.equals("text-underline-style")) && (arrayOfString1.equals("wave")))
        {
          localTextStyle.underline = true;
          localTextStyle.underlineStyle = 3;
        }
        else if ((localAccessibleEditableTextListener.equals("invalid")) && (arrayOfString1.equals("true")))
        {
          localTextStyle.underline = true;
          localTextStyle.underlineStyle = 2;
        }
        else if (localAccessibleEditableTextListener.equals("text-line-through-type"))
        {
          if (arrayOfString1.equals("single")) {
            localTextStyle.strikeout = true;
          }
        }
        else if (localAccessibleEditableTextListener.equals("font-family"))
        {
          if (localFontData == null) {
            localFontData = new FontData();
          }
          localFontData.setName(arrayOfString1);
        }
        else if (localAccessibleEditableTextListener.equals("font-size"))
        {
          try
          {
            String[] arrayOfString2 = arrayOfString1.endsWith("pt") ? arrayOfString1.substring(0, arrayOfString1.length() - 2) : arrayOfString1;
            i = Integer.parseInt(arrayOfString2);
            if (localFontData == null) {
              localFontData = new FontData();
            }
            localFontData.setHeight(i);
            if (localTextStyle.rise > 0) {
              localTextStyle.rise = (i / 2);
            } else if (localTextStyle.rise < 0) {
              localTextStyle.rise = (-i / 2);
            }
          }
          catch (NumberFormatException localNumberFormatException1) {}
        }
        else if (localAccessibleEditableTextListener.equals("font-style"))
        {
          if (arrayOfString1.equals("italic"))
          {
            if (localFontData == null) {
              localFontData = new FontData();
            }
            localFontData.setStyle(localFontData.getStyle() | 0x2);
          }
        }
        else if (localAccessibleEditableTextListener.equals("font-weight"))
        {
          if (arrayOfString1.equals("bold"))
          {
            if (localFontData == null) {
              localFontData = new FontData();
            }
            localFontData.setStyle(localFontData.getStyle() | 0x1);
          }
          else
          {
            try
            {
              int i1 = Integer.parseInt(arrayOfString1);
              if (localFontData == null) {
                localFontData = new FontData();
              }
              if (i1 > 400) {
                localFontData.setStyle(localFontData.getStyle() | 0x1);
              }
            }
            catch (NumberFormatException localNumberFormatException2) {}
          }
        }
        else if (localAccessibleEditableTextListener.equals("color"))
        {
          localTextStyle.foreground = colorFromString(arrayOfString1);
        }
        else if (localAccessibleEditableTextListener.equals("background-color"))
        {
          localTextStyle.background = colorFromString(arrayOfString1);
        }
      }
      if (localObject.length > 0)
      {
        localAccessibleTextAttributeEvent.attributes = ((String[])localObject);
        if (localFontData != null) {
          localTextStyle.font = new Font(this.control.getDisplay(), localFontData);
        }
        if (!localTextStyle.equals(new TextStyle())) {
          localAccessibleTextAttributeEvent.textStyle = localTextStyle;
        }
      }
      for (m = 0; m < accessibleEditableTextListenersSize(); m++)
      {
        localAccessibleEditableTextListener = (AccessibleEditableTextListener)this.accessibleEditableTextListeners.elementAt(m);
        localAccessibleEditableTextListener.setTextAttributes(localAccessibleTextAttributeEvent);
      }
      if (localTextStyle.font != null) {
        localTextStyle.font.dispose();
      }
      if (localTextStyle.foreground != null) {
        localTextStyle.foreground.dispose();
      }
      if (localTextStyle.background != null) {
        localTextStyle.background.dispose();
      }
    }
    if ((localAccessibleTextAttributeEvent.result == null) || (!localAccessibleTextAttributeEvent.result.equals("OK"))) {
      return -2147024809;
    }
    return 0;
  }
  
  int get_anchor(int paramInt, long paramLong)
  {
    AccessibleHyperlinkEvent localAccessibleHyperlinkEvent = new AccessibleHyperlinkEvent(this);
    localAccessibleHyperlinkEvent.index = paramInt;
    for (int i = 0; i < accessibleHyperlinkListenersSize(); i++)
    {
      AccessibleHyperlinkListener localAccessibleHyperlinkListener = (AccessibleHyperlinkListener)this.accessibleHyperlinkListeners.elementAt(i);
      localAccessibleHyperlinkListener.getAnchor(localAccessibleHyperlinkEvent);
    }
    Accessible localAccessible = localAccessibleHyperlinkEvent.accessible;
    if (localAccessible != null)
    {
      localAccessible.AddRef();
      setPtrVARIANT(paramLong, (short)9, localAccessible.getAddress());
      return 0;
    }
    setStringVARIANT(paramLong, localAccessibleHyperlinkEvent.result);
    if (localAccessibleHyperlinkEvent.result == null) {
      return 1;
    }
    return 0;
  }
  
  int get_anchorTarget(int paramInt, long paramLong)
  {
    AccessibleHyperlinkEvent localAccessibleHyperlinkEvent = new AccessibleHyperlinkEvent(this);
    localAccessibleHyperlinkEvent.index = paramInt;
    for (int i = 0; i < accessibleHyperlinkListenersSize(); i++)
    {
      AccessibleHyperlinkListener localAccessibleHyperlinkListener = (AccessibleHyperlinkListener)this.accessibleHyperlinkListeners.elementAt(i);
      localAccessibleHyperlinkListener.getAnchorTarget(localAccessibleHyperlinkEvent);
    }
    Accessible localAccessible = localAccessibleHyperlinkEvent.accessible;
    if (localAccessible != null)
    {
      localAccessible.AddRef();
      setPtrVARIANT(paramLong, (short)9, localAccessible.getAddress());
      return 0;
    }
    setStringVARIANT(paramLong, localAccessibleHyperlinkEvent.result);
    if (localAccessibleHyperlinkEvent.result == null) {
      return 1;
    }
    return 0;
  }
  
  int get_startIndex(long paramLong)
  {
    AccessibleHyperlinkEvent localAccessibleHyperlinkEvent = new AccessibleHyperlinkEvent(this);
    for (int i = 0; i < accessibleHyperlinkListenersSize(); i++)
    {
      AccessibleHyperlinkListener localAccessibleHyperlinkListener = (AccessibleHyperlinkListener)this.accessibleHyperlinkListeners.elementAt(i);
      localAccessibleHyperlinkListener.getStartIndex(localAccessibleHyperlinkEvent);
    }
    COM.MoveMemory(paramLong, new int[] { localAccessibleHyperlinkEvent.index }, 4);
    return 0;
  }
  
  int get_endIndex(long paramLong)
  {
    AccessibleHyperlinkEvent localAccessibleHyperlinkEvent = new AccessibleHyperlinkEvent(this);
    for (int i = 0; i < accessibleHyperlinkListenersSize(); i++)
    {
      AccessibleHyperlinkListener localAccessibleHyperlinkListener = (AccessibleHyperlinkListener)this.accessibleHyperlinkListeners.elementAt(i);
      localAccessibleHyperlinkListener.getEndIndex(localAccessibleHyperlinkEvent);
    }
    COM.MoveMemory(paramLong, new int[] { localAccessibleHyperlinkEvent.index }, 4);
    return 0;
  }
  
  int get_valid(long paramLong)
  {
    return -2147467263;
  }
  
  int get_nHyperlinks(long paramLong)
  {
    AccessibleTextEvent localAccessibleTextEvent = new AccessibleTextEvent(this);
    for (int i = 0; i < accessibleTextExtendedListenersSize(); i++)
    {
      AccessibleTextExtendedListener localAccessibleTextExtendedListener = (AccessibleTextExtendedListener)this.accessibleTextExtendedListeners.elementAt(i);
      localAccessibleTextExtendedListener.getHyperlinkCount(localAccessibleTextEvent);
    }
    COM.MoveMemory(paramLong, new int[] { localAccessibleTextEvent.count }, 4);
    return 0;
  }
  
  int get_hyperlink(int paramInt, long paramLong)
  {
    AccessibleTextEvent localAccessibleTextEvent = new AccessibleTextEvent(this);
    localAccessibleTextEvent.index = paramInt;
    for (int i = 0; i < accessibleTextExtendedListenersSize(); i++)
    {
      AccessibleTextExtendedListener localAccessibleTextExtendedListener = (AccessibleTextExtendedListener)this.accessibleTextExtendedListeners.elementAt(i);
      localAccessibleTextExtendedListener.getHyperlink(localAccessibleTextEvent);
    }
    Accessible localAccessible = localAccessibleTextEvent.accessible;
    if (localAccessible == null)
    {
      setIntVARIANT(paramLong, (short)0, 0);
      return -2147024809;
    }
    localAccessible.AddRef();
    COM.MoveMemory(paramLong, new long[] { localAccessible.getAddress() }, OS.PTR_SIZEOF);
    return 0;
  }
  
  int get_hyperlinkIndex(int paramInt, long paramLong)
  {
    AccessibleTextEvent localAccessibleTextEvent = new AccessibleTextEvent(this);
    localAccessibleTextEvent.offset = paramInt;
    localAccessibleTextEvent.index = -1;
    for (int i = 0; i < accessibleTextExtendedListenersSize(); i++)
    {
      AccessibleTextExtendedListener localAccessibleTextExtendedListener = (AccessibleTextExtendedListener)this.accessibleTextExtendedListeners.elementAt(i);
      localAccessibleTextExtendedListener.getHyperlinkIndex(localAccessibleTextEvent);
    }
    COM.MoveMemory(paramLong, new int[] { localAccessibleTextEvent.index }, 4);
    if (localAccessibleTextEvent.index == -1) {
      return 1;
    }
    return 0;
  }
  
  int get_cellAt(int paramInt1, int paramInt2, long paramLong)
  {
    AccessibleTableEvent localAccessibleTableEvent = new AccessibleTableEvent(this);
    localAccessibleTableEvent.row = paramInt1;
    localAccessibleTableEvent.column = paramInt2;
    for (int i = 0; i < accessibleTableListenersSize(); i++)
    {
      AccessibleTableListener localAccessibleTableListener = (AccessibleTableListener)this.accessibleTableListeners.elementAt(i);
      localAccessibleTableListener.getCell(localAccessibleTableEvent);
    }
    Accessible localAccessible = localAccessibleTableEvent.accessible;
    if (localAccessible == null) {
      return -2147024809;
    }
    localAccessible.AddRef();
    COM.MoveMemory(paramLong, new long[] { localAccessible.getAddress() }, OS.PTR_SIZEOF);
    return 0;
  }
  
  int get_caption(long paramLong)
  {
    AccessibleTableEvent localAccessibleTableEvent = new AccessibleTableEvent(this);
    for (int i = 0; i < accessibleTableListenersSize(); i++)
    {
      AccessibleTableListener localAccessibleTableListener = (AccessibleTableListener)this.accessibleTableListeners.elementAt(i);
      localAccessibleTableListener.getCaption(localAccessibleTableEvent);
    }
    Accessible localAccessible = localAccessibleTableEvent.accessible;
    if (localAccessible == null)
    {
      COM.MoveMemory(paramLong, new long[] { 0L }, OS.PTR_SIZEOF);
      return 1;
    }
    localAccessible.AddRef();
    COM.MoveMemory(paramLong, new long[] { localAccessible.getAddress() }, OS.PTR_SIZEOF);
    return 0;
  }
  
  int get_columnDescription(int paramInt, long paramLong)
  {
    AccessibleTableEvent localAccessibleTableEvent = new AccessibleTableEvent(this);
    localAccessibleTableEvent.column = paramInt;
    for (int i = 0; i < accessibleTableListenersSize(); i++)
    {
      AccessibleTableListener localAccessibleTableListener = (AccessibleTableListener)this.accessibleTableListeners.elementAt(i);
      localAccessibleTableListener.getColumnDescription(localAccessibleTableEvent);
    }
    setString(paramLong, localAccessibleTableEvent.result);
    if (localAccessibleTableEvent.result == null) {
      return 1;
    }
    return 0;
  }
  
  int get_nColumns(long paramLong)
  {
    AccessibleTableEvent localAccessibleTableEvent = new AccessibleTableEvent(this);
    for (int i = 0; i < accessibleTableListenersSize(); i++)
    {
      AccessibleTableListener localAccessibleTableListener = (AccessibleTableListener)this.accessibleTableListeners.elementAt(i);
      localAccessibleTableListener.getColumnCount(localAccessibleTableEvent);
    }
    COM.MoveMemory(paramLong, new int[] { localAccessibleTableEvent.count }, 4);
    return 0;
  }
  
  int get_nRows(long paramLong)
  {
    AccessibleTableEvent localAccessibleTableEvent = new AccessibleTableEvent(this);
    for (int i = 0; i < accessibleTableListenersSize(); i++)
    {
      AccessibleTableListener localAccessibleTableListener = (AccessibleTableListener)this.accessibleTableListeners.elementAt(i);
      localAccessibleTableListener.getRowCount(localAccessibleTableEvent);
    }
    COM.MoveMemory(paramLong, new int[] { localAccessibleTableEvent.count }, 4);
    return 0;
  }
  
  int get_nSelectedCells(long paramLong)
  {
    AccessibleTableEvent localAccessibleTableEvent = new AccessibleTableEvent(this);
    for (int i = 0; i < accessibleTableListenersSize(); i++)
    {
      AccessibleTableListener localAccessibleTableListener = (AccessibleTableListener)this.accessibleTableListeners.elementAt(i);
      localAccessibleTableListener.getSelectedCellCount(localAccessibleTableEvent);
    }
    COM.MoveMemory(paramLong, new int[] { localAccessibleTableEvent.count }, 4);
    return 0;
  }
  
  int get_nSelectedColumns(long paramLong)
  {
    AccessibleTableEvent localAccessibleTableEvent = new AccessibleTableEvent(this);
    for (int i = 0; i < accessibleTableListenersSize(); i++)
    {
      AccessibleTableListener localAccessibleTableListener = (AccessibleTableListener)this.accessibleTableListeners.elementAt(i);
      localAccessibleTableListener.getSelectedColumnCount(localAccessibleTableEvent);
    }
    COM.MoveMemory(paramLong, new int[] { localAccessibleTableEvent.count }, 4);
    return 0;
  }
  
  int get_nSelectedRows(long paramLong)
  {
    AccessibleTableEvent localAccessibleTableEvent = new AccessibleTableEvent(this);
    for (int i = 0; i < accessibleTableListenersSize(); i++)
    {
      AccessibleTableListener localAccessibleTableListener = (AccessibleTableListener)this.accessibleTableListeners.elementAt(i);
      localAccessibleTableListener.getSelectedRowCount(localAccessibleTableEvent);
    }
    COM.MoveMemory(paramLong, new int[] { localAccessibleTableEvent.count }, 4);
    return 0;
  }
  
  int get_rowDescription(int paramInt, long paramLong)
  {
    AccessibleTableEvent localAccessibleTableEvent = new AccessibleTableEvent(this);
    localAccessibleTableEvent.row = paramInt;
    for (int i = 0; i < accessibleTableListenersSize(); i++)
    {
      AccessibleTableListener localAccessibleTableListener = (AccessibleTableListener)this.accessibleTableListeners.elementAt(i);
      localAccessibleTableListener.getRowDescription(localAccessibleTableEvent);
    }
    setString(paramLong, localAccessibleTableEvent.result);
    if (localAccessibleTableEvent.result == null) {
      return 1;
    }
    return 0;
  }
  
  int get_selectedCells(long paramLong1, long paramLong2)
  {
    AccessibleTableEvent localAccessibleTableEvent = new AccessibleTableEvent(this);
    for (int i = 0; i < accessibleTableListenersSize(); i++)
    {
      AccessibleTableListener localAccessibleTableListener = (AccessibleTableListener)this.accessibleTableListeners.elementAt(i);
      localAccessibleTableListener.getSelectedCells(localAccessibleTableEvent);
    }
    if ((localAccessibleTableEvent.accessibles == null) || (localAccessibleTableEvent.accessibles.length == 0))
    {
      COM.MoveMemory(paramLong1, new long[] { 0L }, OS.PTR_SIZEOF);
      COM.MoveMemory(paramLong2, new int[] { 0 }, 4);
      return 1;
    }
    i = localAccessibleTableEvent.accessibles.length;
    long l = COM.CoTaskMemAlloc(i * OS.PTR_SIZEOF);
    int j = 0;
    for (int k = 0; k < i; k++)
    {
      Accessible localAccessible = localAccessibleTableEvent.accessibles[k];
      if (localAccessible != null)
      {
        localAccessible.AddRef();
        COM.MoveMemory(l + k * OS.PTR_SIZEOF, new long[] { localAccessible.getAddress() }, OS.PTR_SIZEOF);
        j++;
      }
    }
    COM.MoveMemory(paramLong1, new long[] { l }, OS.PTR_SIZEOF);
    COM.MoveMemory(paramLong2, new int[] { j }, 4);
    return 0;
  }
  
  int get_selectedColumns(long paramLong1, long paramLong2)
  {
    AccessibleTableEvent localAccessibleTableEvent = new AccessibleTableEvent(this);
    for (int i = 0; i < accessibleTableListenersSize(); i++)
    {
      AccessibleTableListener localAccessibleTableListener = (AccessibleTableListener)this.accessibleTableListeners.elementAt(i);
      localAccessibleTableListener.getSelectedColumns(localAccessibleTableEvent);
    }
    i = localAccessibleTableEvent.selected == null ? 0 : localAccessibleTableEvent.selected.length;
    if (i == 0)
    {
      COM.MoveMemory(paramLong1, new long[] { 0L }, OS.PTR_SIZEOF);
      COM.MoveMemory(paramLong2, new int[] { 0 }, 4);
      return 1;
    }
    long l = COM.CoTaskMemAlloc(i * 4);
    COM.MoveMemory(l, localAccessibleTableEvent.selected, i * 4);
    COM.MoveMemory(paramLong1, new long[] { l }, OS.PTR_SIZEOF);
    COM.MoveMemory(paramLong2, new int[] { i }, 4);
    return 0;
  }
  
  int get_selectedRows(long paramLong1, long paramLong2)
  {
    AccessibleTableEvent localAccessibleTableEvent = new AccessibleTableEvent(this);
    for (int i = 0; i < accessibleTableListenersSize(); i++)
    {
      AccessibleTableListener localAccessibleTableListener = (AccessibleTableListener)this.accessibleTableListeners.elementAt(i);
      localAccessibleTableListener.getSelectedRows(localAccessibleTableEvent);
    }
    i = localAccessibleTableEvent.selected == null ? 0 : localAccessibleTableEvent.selected.length;
    if (i == 0)
    {
      COM.MoveMemory(paramLong1, new long[] { 0L }, OS.PTR_SIZEOF);
      COM.MoveMemory(paramLong2, new int[] { 0 }, 4);
      return 1;
    }
    long l = COM.CoTaskMemAlloc(i * 4);
    COM.MoveMemory(l, localAccessibleTableEvent.selected, i * 4);
    COM.MoveMemory(paramLong1, new long[] { l }, OS.PTR_SIZEOF);
    COM.MoveMemory(paramLong2, new int[] { i }, 4);
    return 0;
  }
  
  int get_summary(long paramLong)
  {
    AccessibleTableEvent localAccessibleTableEvent = new AccessibleTableEvent(this);
    for (int i = 0; i < accessibleTableListenersSize(); i++)
    {
      AccessibleTableListener localAccessibleTableListener = (AccessibleTableListener)this.accessibleTableListeners.elementAt(i);
      localAccessibleTableListener.getSummary(localAccessibleTableEvent);
    }
    Accessible localAccessible = localAccessibleTableEvent.accessible;
    if (localAccessible == null)
    {
      COM.MoveMemory(paramLong, new long[] { 0L }, OS.PTR_SIZEOF);
      return 1;
    }
    localAccessible.AddRef();
    COM.MoveMemory(paramLong, new long[] { localAccessible.getAddress() }, OS.PTR_SIZEOF);
    return 0;
  }
  
  int get_isColumnSelected(int paramInt, long paramLong)
  {
    AccessibleTableEvent localAccessibleTableEvent = new AccessibleTableEvent(this);
    localAccessibleTableEvent.column = paramInt;
    for (int i = 0; i < accessibleTableListenersSize(); i++)
    {
      AccessibleTableListener localAccessibleTableListener = (AccessibleTableListener)this.accessibleTableListeners.elementAt(i);
      localAccessibleTableListener.isColumnSelected(localAccessibleTableEvent);
    }
    COM.MoveMemory(paramLong, new int[] { localAccessibleTableEvent.isSelected ? 1 : 0 }, 4);
    return 0;
  }
  
  int get_isRowSelected(int paramInt, long paramLong)
  {
    AccessibleTableEvent localAccessibleTableEvent = new AccessibleTableEvent(this);
    localAccessibleTableEvent.row = paramInt;
    for (int i = 0; i < accessibleTableListenersSize(); i++)
    {
      AccessibleTableListener localAccessibleTableListener = (AccessibleTableListener)this.accessibleTableListeners.elementAt(i);
      localAccessibleTableListener.isRowSelected(localAccessibleTableEvent);
    }
    COM.MoveMemory(paramLong, new int[] { localAccessibleTableEvent.isSelected ? 1 : 0 }, 4);
    return 0;
  }
  
  int selectRow(int paramInt)
  {
    AccessibleTableEvent localAccessibleTableEvent = new AccessibleTableEvent(this);
    localAccessibleTableEvent.row = paramInt;
    for (int i = 0; i < accessibleTableListenersSize(); i++)
    {
      AccessibleTableListener localAccessibleTableListener = (AccessibleTableListener)this.accessibleTableListeners.elementAt(i);
      localAccessibleTableListener.setSelectedRow(localAccessibleTableEvent);
    }
    if ((localAccessibleTableEvent.result == null) || (!localAccessibleTableEvent.result.equals("OK"))) {
      return -2147024809;
    }
    return 0;
  }
  
  int selectColumn(int paramInt)
  {
    AccessibleTableEvent localAccessibleTableEvent = new AccessibleTableEvent(this);
    localAccessibleTableEvent.column = paramInt;
    for (int i = 0; i < accessibleTableListenersSize(); i++)
    {
      AccessibleTableListener localAccessibleTableListener = (AccessibleTableListener)this.accessibleTableListeners.elementAt(i);
      localAccessibleTableListener.setSelectedColumn(localAccessibleTableEvent);
    }
    if ((localAccessibleTableEvent.result == null) || (!localAccessibleTableEvent.result.equals("OK"))) {
      return -2147024809;
    }
    return 0;
  }
  
  int unselectRow(int paramInt)
  {
    AccessibleTableEvent localAccessibleTableEvent = new AccessibleTableEvent(this);
    localAccessibleTableEvent.row = paramInt;
    for (int i = 0; i < accessibleTableListenersSize(); i++)
    {
      AccessibleTableListener localAccessibleTableListener = (AccessibleTableListener)this.accessibleTableListeners.elementAt(i);
      localAccessibleTableListener.deselectRow(localAccessibleTableEvent);
    }
    if ((localAccessibleTableEvent.result == null) || (!localAccessibleTableEvent.result.equals("OK"))) {
      return -2147024809;
    }
    return 0;
  }
  
  int unselectColumn(int paramInt)
  {
    AccessibleTableEvent localAccessibleTableEvent = new AccessibleTableEvent(this);
    localAccessibleTableEvent.column = paramInt;
    for (int i = 0; i < accessibleTableListenersSize(); i++)
    {
      AccessibleTableListener localAccessibleTableListener = (AccessibleTableListener)this.accessibleTableListeners.elementAt(i);
      localAccessibleTableListener.deselectColumn(localAccessibleTableEvent);
    }
    if ((localAccessibleTableEvent.result == null) || (!localAccessibleTableEvent.result.equals("OK"))) {
      return -2147024809;
    }
    return 0;
  }
  
  int get_modelChange(long paramLong)
  {
    if (this.tableChange == null)
    {
      COM.MoveMemory(paramLong, new long[] { 0L }, OS.PTR_SIZEOF);
      return 1;
    }
    COM.MoveMemory(paramLong, this.tableChange, this.tableChange.length * 4);
    return 0;
  }
  
  int get_columnExtent(long paramLong)
  {
    AccessibleTableCellEvent localAccessibleTableCellEvent = new AccessibleTableCellEvent(this);
    for (int i = 0; i < accessibleTableCellListenersSize(); i++)
    {
      AccessibleTableCellListener localAccessibleTableCellListener = (AccessibleTableCellListener)this.accessibleTableCellListeners.elementAt(i);
      localAccessibleTableCellListener.getColumnSpan(localAccessibleTableCellEvent);
    }
    COM.MoveMemory(paramLong, new int[] { localAccessibleTableCellEvent.count }, 4);
    return 0;
  }
  
  int get_columnHeaderCells(long paramLong1, long paramLong2)
  {
    AccessibleTableCellEvent localAccessibleTableCellEvent = new AccessibleTableCellEvent(this);
    for (int i = 0; i < accessibleTableCellListenersSize(); i++)
    {
      AccessibleTableCellListener localAccessibleTableCellListener = (AccessibleTableCellListener)this.accessibleTableCellListeners.elementAt(i);
      localAccessibleTableCellListener.getColumnHeaders(localAccessibleTableCellEvent);
    }
    if ((localAccessibleTableCellEvent.accessibles == null) || (localAccessibleTableCellEvent.accessibles.length == 0))
    {
      COM.MoveMemory(paramLong1, new long[] { 0L }, OS.PTR_SIZEOF);
      COM.MoveMemory(paramLong2, new int[] { 0 }, 4);
      return 1;
    }
    i = localAccessibleTableCellEvent.accessibles.length;
    long l = COM.CoTaskMemAlloc(i * OS.PTR_SIZEOF);
    int j = 0;
    for (int k = 0; k < i; k++)
    {
      Accessible localAccessible = localAccessibleTableCellEvent.accessibles[k];
      if (localAccessible != null)
      {
        localAccessible.AddRef();
        COM.MoveMemory(l + k * OS.PTR_SIZEOF, new long[] { localAccessible.getAddress() }, OS.PTR_SIZEOF);
        j++;
      }
    }
    COM.MoveMemory(paramLong1, new long[] { l }, OS.PTR_SIZEOF);
    COM.MoveMemory(paramLong2, new int[] { j }, 4);
    return 0;
  }
  
  int get_columnIndex(long paramLong)
  {
    AccessibleTableCellEvent localAccessibleTableCellEvent = new AccessibleTableCellEvent(this);
    for (int i = 0; i < accessibleTableCellListenersSize(); i++)
    {
      AccessibleTableCellListener localAccessibleTableCellListener = (AccessibleTableCellListener)this.accessibleTableCellListeners.elementAt(i);
      localAccessibleTableCellListener.getColumnIndex(localAccessibleTableCellEvent);
    }
    COM.MoveMemory(paramLong, new int[] { localAccessibleTableCellEvent.index }, 4);
    return 0;
  }
  
  int get_rowExtent(long paramLong)
  {
    AccessibleTableCellEvent localAccessibleTableCellEvent = new AccessibleTableCellEvent(this);
    for (int i = 0; i < accessibleTableCellListenersSize(); i++)
    {
      AccessibleTableCellListener localAccessibleTableCellListener = (AccessibleTableCellListener)this.accessibleTableCellListeners.elementAt(i);
      localAccessibleTableCellListener.getRowSpan(localAccessibleTableCellEvent);
    }
    COM.MoveMemory(paramLong, new int[] { localAccessibleTableCellEvent.count }, 4);
    return 0;
  }
  
  int get_rowHeaderCells(long paramLong1, long paramLong2)
  {
    AccessibleTableCellEvent localAccessibleTableCellEvent = new AccessibleTableCellEvent(this);
    for (int i = 0; i < accessibleTableCellListenersSize(); i++)
    {
      AccessibleTableCellListener localAccessibleTableCellListener = (AccessibleTableCellListener)this.accessibleTableCellListeners.elementAt(i);
      localAccessibleTableCellListener.getRowHeaders(localAccessibleTableCellEvent);
    }
    if ((localAccessibleTableCellEvent.accessibles == null) || (localAccessibleTableCellEvent.accessibles.length == 0))
    {
      COM.MoveMemory(paramLong1, new long[] { 0L }, OS.PTR_SIZEOF);
      COM.MoveMemory(paramLong2, new int[] { 0 }, 4);
      return 1;
    }
    i = localAccessibleTableCellEvent.accessibles.length;
    long l = COM.CoTaskMemAlloc(i * OS.PTR_SIZEOF);
    int j = 0;
    for (int k = 0; k < i; k++)
    {
      Accessible localAccessible = localAccessibleTableCellEvent.accessibles[k];
      if (localAccessible != null)
      {
        localAccessible.AddRef();
        COM.MoveMemory(l + k * OS.PTR_SIZEOF, new long[] { localAccessible.getAddress() }, OS.PTR_SIZEOF);
        j++;
      }
    }
    COM.MoveMemory(paramLong1, new long[] { l }, OS.PTR_SIZEOF);
    COM.MoveMemory(paramLong2, new int[] { j }, 4);
    return 0;
  }
  
  int get_rowIndex(long paramLong)
  {
    AccessibleTableCellEvent localAccessibleTableCellEvent = new AccessibleTableCellEvent(this);
    for (int i = 0; i < accessibleTableCellListenersSize(); i++)
    {
      AccessibleTableCellListener localAccessibleTableCellListener = (AccessibleTableCellListener)this.accessibleTableCellListeners.elementAt(i);
      localAccessibleTableCellListener.getRowIndex(localAccessibleTableCellEvent);
    }
    COM.MoveMemory(paramLong, new int[] { localAccessibleTableCellEvent.index }, 4);
    return 0;
  }
  
  int get_isSelected(long paramLong)
  {
    AccessibleTableCellEvent localAccessibleTableCellEvent = new AccessibleTableCellEvent(this);
    for (int i = 0; i < accessibleTableCellListenersSize(); i++)
    {
      AccessibleTableCellListener localAccessibleTableCellListener = (AccessibleTableCellListener)this.accessibleTableCellListeners.elementAt(i);
      localAccessibleTableCellListener.isSelected(localAccessibleTableCellEvent);
    }
    COM.MoveMemory(paramLong, new int[] { localAccessibleTableCellEvent.isSelected ? 1 : 0 }, 4);
    return 0;
  }
  
  int get_rowColumnExtents(long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5)
  {
    return -2147352573;
  }
  
  int get_table(long paramLong)
  {
    AccessibleTableCellEvent localAccessibleTableCellEvent = new AccessibleTableCellEvent(this);
    for (int i = 0; i < accessibleTableCellListenersSize(); i++)
    {
      AccessibleTableCellListener localAccessibleTableCellListener = (AccessibleTableCellListener)this.accessibleTableCellListeners.elementAt(i);
      localAccessibleTableCellListener.getTable(localAccessibleTableCellEvent);
    }
    Accessible localAccessible = localAccessibleTableCellEvent.accessible;
    if (localAccessible == null)
    {
      COM.MoveMemory(paramLong, new long[] { 0L }, OS.PTR_SIZEOF);
      return 1;
    }
    localAccessible.AddRef();
    COM.MoveMemory(paramLong, new long[] { localAccessible.getAddress() }, OS.PTR_SIZEOF);
    return 0;
  }
  
  int addSelection(int paramInt1, int paramInt2)
  {
    AccessibleTextEvent localAccessibleTextEvent = new AccessibleTextEvent(this);
    localAccessibleTextEvent.start = (paramInt1 == -1 ? getCharacterCount() : paramInt1);
    localAccessibleTextEvent.end = (paramInt2 == -1 ? getCharacterCount() : paramInt2);
    for (int i = 0; i < accessibleTextExtendedListenersSize(); i++)
    {
      AccessibleTextExtendedListener localAccessibleTextExtendedListener = (AccessibleTextExtendedListener)this.accessibleTextExtendedListeners.elementAt(i);
      localAccessibleTextExtendedListener.addSelection(localAccessibleTextEvent);
    }
    if ((localAccessibleTextEvent.result == null) || (!localAccessibleTextEvent.result.equals("OK"))) {
      return -2147024809;
    }
    return 0;
  }
  
  int get_attributes(int paramInt, long paramLong1, long paramLong2, long paramLong3)
  {
    AccessibleTextAttributeEvent localAccessibleTextAttributeEvent = new AccessibleTextAttributeEvent(this);
    localAccessibleTextAttributeEvent.offset = (paramInt == -1 ? getCharacterCount() : paramInt);
    for (int i = 0; i < accessibleAttributeListenersSize(); i++)
    {
      localObject1 = (AccessibleAttributeListener)this.accessibleAttributeListeners.elementAt(i);
      ((AccessibleAttributeListener)localObject1).getTextAttributes(localAccessibleTextAttributeEvent);
    }
    String str = "";
    Object localObject1 = localAccessibleTextAttributeEvent.textStyle;
    if (localObject1 != null)
    {
      if (((TextStyle)localObject1).rise != 0)
      {
        str = str + "text-position:";
        if (((TextStyle)localObject1).rise > 0) {
          str = str + "super";
        } else {
          str = str + "sub";
        }
      }
      if (((TextStyle)localObject1).underline)
      {
        str = str + "text-underline-type:";
        switch (((TextStyle)localObject1).underlineStyle)
        {
        case 0: 
          str = str + "single;";
          break;
        case 1: 
          str = str + "double;";
          break;
        case 3: 
          str = str + "single;text-underline-style:wave;";
          break;
        case 2: 
          str = str + "single;text-underline-style:wave;invalid:true;";
          break;
        default: 
          str = str + "none;";
        }
      }
      if (((TextStyle)localObject1).strikeout) {
        str = str + "text-line-through-type:single;";
      }
      Font localFont = ((TextStyle)localObject1).font;
      if ((localFont != null) && (!localFont.isDisposed()))
      {
        localObject2 = localFont.getFontData()[0];
        str = str + "font-family:" + ((FontData)localObject2).getName() + ";";
        str = str + "font-size:" + ((FontData)localObject2).getHeight() + "pt;";
        str = str + "font-style:" + (((FontData)localObject2).data.lfItalic != 0 ? "italic" : "normal") + ";";
        str = str + "font-weight:" + ((FontData)localObject2).data.lfWeight + ";";
      }
      Object localObject2 = ((TextStyle)localObject1).foreground;
      if ((localObject2 != null) && (!((Color)localObject2).isDisposed())) {
        str = str + "color:rgb(" + ((Color)localObject2).getRed() + "," + ((Color)localObject2).getGreen() + "," + ((Color)localObject2).getBlue() + ");";
      }
      localObject2 = ((TextStyle)localObject1).background;
      if ((localObject2 != null) && (!((Color)localObject2).isDisposed())) {
        str = str + "background-color:rgb(" + ((Color)localObject2).getRed() + "," + ((Color)localObject2).getGreen() + "," + ((Color)localObject2).getBlue() + ");";
      }
    }
    if (localAccessibleTextAttributeEvent.attributes != null) {
      for (int j = 0; j + 1 < localAccessibleTextAttributeEvent.attributes.length; j += 2) {
        str = str + localAccessibleTextAttributeEvent.attributes[j] + ":" + localAccessibleTextAttributeEvent.attributes[(j + 1)] + ";";
      }
    }
    COM.MoveMemory(paramLong1, new int[] { localAccessibleTextAttributeEvent.start }, 4);
    COM.MoveMemory(paramLong2, new int[] { localAccessibleTextAttributeEvent.end }, 4);
    setString(paramLong3, str);
    if (str.length() == 0) {
      return 1;
    }
    return 0;
  }
  
  int get_caretOffset(long paramLong)
  {
    int i = getCaretOffset();
    COM.MoveMemory(paramLong, new int[] { i }, 4);
    if (i == -1) {
      return 1;
    }
    return 0;
  }
  
  int get_characterExtents(int paramInt1, int paramInt2, long paramLong1, long paramLong2, long paramLong3, long paramLong4)
  {
    int i = getCharacterCount();
    AccessibleTextEvent localAccessibleTextEvent = new AccessibleTextEvent(this);
    localAccessibleTextEvent.start = (paramInt1 < 0 ? 0 : paramInt1 == -1 ? i : paramInt1);
    localAccessibleTextEvent.end = ((paramInt1 == -1) || (paramInt1 >= i) ? i : paramInt1 + 1);
    for (int j = 0; j < accessibleTextExtendedListenersSize(); j++)
    {
      AccessibleTextExtendedListener localAccessibleTextExtendedListener = (AccessibleTextExtendedListener)this.accessibleTextExtendedListeners.elementAt(j);
      localAccessibleTextExtendedListener.getTextBounds(localAccessibleTextEvent);
    }
    COM.MoveMemory(paramLong1, new int[] { localAccessibleTextEvent.x }, 4);
    COM.MoveMemory(paramLong2, new int[] { localAccessibleTextEvent.y }, 4);
    COM.MoveMemory(paramLong3, new int[] { localAccessibleTextEvent.width }, 4);
    COM.MoveMemory(paramLong4, new int[] { localAccessibleTextEvent.height }, 4);
    if ((localAccessibleTextEvent.width == 0) && (localAccessibleTextEvent.height == 0)) {
      return -2147024809;
    }
    return 0;
  }
  
  int get_nSelections(long paramLong)
  {
    AccessibleTextEvent localAccessibleTextEvent = new AccessibleTextEvent(this);
    localAccessibleTextEvent.count = -1;
    Object localObject;
    for (int i = 0; i < accessibleTextExtendedListenersSize(); i++)
    {
      localObject = (AccessibleTextExtendedListener)this.accessibleTextExtendedListeners.elementAt(i);
      ((AccessibleTextExtendedListener)localObject).getSelectionCount(localAccessibleTextEvent);
    }
    if (localAccessibleTextEvent.count == -1)
    {
      localAccessibleTextEvent.childID = -1;
      localAccessibleTextEvent.offset = -1;
      localAccessibleTextEvent.length = 0;
      for (i = 0; i < accessibleTextListenersSize(); i++)
      {
        localObject = (AccessibleTextListener)this.accessibleTextListeners.elementAt(i);
        ((AccessibleTextListener)localObject).getSelectionRange(localAccessibleTextEvent);
      }
      localAccessibleTextEvent.count = ((localAccessibleTextEvent.offset != -1) && (localAccessibleTextEvent.length > 0) ? 1 : 0);
    }
    COM.MoveMemory(paramLong, new int[] { localAccessibleTextEvent.count }, 4);
    return 0;
  }
  
  int get_offsetAtPoint(int paramInt1, int paramInt2, int paramInt3, long paramLong)
  {
    AccessibleTextEvent localAccessibleTextEvent = new AccessibleTextEvent(this);
    localAccessibleTextEvent.x = paramInt1;
    localAccessibleTextEvent.y = paramInt2;
    localAccessibleTextEvent.offset = -1;
    for (int i = 0; i < accessibleTextExtendedListenersSize(); i++)
    {
      AccessibleTextExtendedListener localAccessibleTextExtendedListener = (AccessibleTextExtendedListener)this.accessibleTextExtendedListeners.elementAt(i);
      localAccessibleTextExtendedListener.getOffsetAtPoint(localAccessibleTextEvent);
    }
    COM.MoveMemory(paramLong, new int[] { localAccessibleTextEvent.offset }, 4);
    if (localAccessibleTextEvent.offset == -1) {
      return 1;
    }
    return 0;
  }
  
  int get_selection(int paramInt, long paramLong1, long paramLong2)
  {
    AccessibleTextEvent localAccessibleTextEvent = new AccessibleTextEvent(this);
    localAccessibleTextEvent.index = paramInt;
    localAccessibleTextEvent.start = -1;
    localAccessibleTextEvent.end = -1;
    Object localObject;
    for (int i = 0; i < accessibleTextExtendedListenersSize(); i++)
    {
      localObject = (AccessibleTextExtendedListener)this.accessibleTextExtendedListeners.elementAt(i);
      ((AccessibleTextExtendedListener)localObject).getSelection(localAccessibleTextEvent);
    }
    if ((localAccessibleTextEvent.start == -1) && (paramInt == 0))
    {
      localAccessibleTextEvent.childID = -1;
      localAccessibleTextEvent.offset = -1;
      localAccessibleTextEvent.length = 0;
      for (i = 0; i < accessibleTextListenersSize(); i++)
      {
        localObject = (AccessibleTextListener)this.accessibleTextListeners.elementAt(i);
        ((AccessibleTextListener)localObject).getSelectionRange(localAccessibleTextEvent);
      }
      localAccessibleTextEvent.start = localAccessibleTextEvent.offset;
      localAccessibleTextEvent.end = (localAccessibleTextEvent.offset + localAccessibleTextEvent.length);
    }
    COM.MoveMemory(paramLong1, new int[] { localAccessibleTextEvent.start }, 4);
    COM.MoveMemory(paramLong2, new int[] { localAccessibleTextEvent.end }, 4);
    if (localAccessibleTextEvent.start == -1) {
      return 1;
    }
    return 0;
  }
  
  int get_text(int paramInt1, int paramInt2, long paramLong)
  {
    AccessibleTextEvent localAccessibleTextEvent = new AccessibleTextEvent(this);
    localAccessibleTextEvent.start = (paramInt1 == -1 ? getCharacterCount() : paramInt1);
    localAccessibleTextEvent.end = (paramInt2 == -1 ? getCharacterCount() : paramInt2);
    if (localAccessibleTextEvent.start > localAccessibleTextEvent.end)
    {
      i = localAccessibleTextEvent.start;
      localAccessibleTextEvent.start = localAccessibleTextEvent.end;
      localAccessibleTextEvent.end = i;
    }
    localAccessibleTextEvent.count = 0;
    localAccessibleTextEvent.type = 5;
    for (int i = 0; i < accessibleTextExtendedListenersSize(); i++)
    {
      AccessibleTextExtendedListener localAccessibleTextExtendedListener = (AccessibleTextExtendedListener)this.accessibleTextExtendedListeners.elementAt(i);
      localAccessibleTextExtendedListener.getText(localAccessibleTextEvent);
    }
    if (localAccessibleTextEvent.result == null)
    {
      AccessibleControlEvent localAccessibleControlEvent = new AccessibleControlEvent(this);
      localAccessibleControlEvent.childID = -1;
      for (int j = 0; j < accessibleControlListenersSize(); j++)
      {
        AccessibleControlListener localAccessibleControlListener = (AccessibleControlListener)this.accessibleControlListeners.elementAt(j);
        localAccessibleControlListener.getRole(localAccessibleControlEvent);
        localAccessibleControlListener.getValue(localAccessibleControlEvent);
      }
      if (localAccessibleControlEvent.detail == 42) {
        localAccessibleTextEvent.result = localAccessibleControlEvent.result;
      }
    }
    setString(paramLong, localAccessibleTextEvent.result);
    if (localAccessibleTextEvent.result == null) {
      return -2147024809;
    }
    return 0;
  }
  
  int get_textBeforeOffset(int paramInt1, int paramInt2, long paramLong1, long paramLong2, long paramLong3)
  {
    AccessibleTextEvent localAccessibleTextEvent = new AccessibleTextEvent(this);
    int i = getCharacterCount();
    localAccessibleTextEvent.start = (paramInt1 == -2 ? getCaretOffset() : paramInt1 == -1 ? i : paramInt1);
    localAccessibleTextEvent.end = localAccessibleTextEvent.start;
    localAccessibleTextEvent.count = -1;
    switch (paramInt2)
    {
    case 0: 
      localAccessibleTextEvent.type = 0;
      break;
    case 1: 
      localAccessibleTextEvent.type = 1;
      break;
    case 2: 
      localAccessibleTextEvent.type = 2;
      break;
    case 3: 
      localAccessibleTextEvent.type = 3;
      break;
    case 4: 
      localAccessibleTextEvent.type = 4;
      break;
    default: 
      return -2147024809;
    }
    int j = localAccessibleTextEvent.start;
    int k = localAccessibleTextEvent.end;
    for (int m = 0; m < accessibleTextExtendedListenersSize(); m++)
    {
      AccessibleTextExtendedListener localAccessibleTextExtendedListener1 = (AccessibleTextExtendedListener)this.accessibleTextExtendedListeners.elementAt(m);
      localAccessibleTextExtendedListener1.getText(localAccessibleTextEvent);
    }
    if (localAccessibleTextEvent.end < i) {
      switch (paramInt2)
      {
      case 1: 
      case 2: 
      case 3: 
      case 4: 
        m = localAccessibleTextEvent.start;
        localAccessibleTextEvent.start = j;
        localAccessibleTextEvent.end = k;
        localAccessibleTextEvent.count = 0;
        AccessibleTextExtendedListener localAccessibleTextExtendedListener2;
        for (int n = 0; n < accessibleTextExtendedListenersSize(); n++)
        {
          localAccessibleTextExtendedListener2 = (AccessibleTextExtendedListener)this.accessibleTextExtendedListeners.elementAt(n);
          localAccessibleTextExtendedListener2.getText(localAccessibleTextEvent);
        }
        localAccessibleTextEvent.end = localAccessibleTextEvent.start;
        localAccessibleTextEvent.start = m;
        localAccessibleTextEvent.type = 5;
        localAccessibleTextEvent.count = 0;
        for (n = 0; n < accessibleTextExtendedListenersSize(); n++)
        {
          localAccessibleTextExtendedListener2 = (AccessibleTextExtendedListener)this.accessibleTextExtendedListeners.elementAt(n);
          localAccessibleTextExtendedListener2.getText(localAccessibleTextEvent);
        }
      }
    }
    COM.MoveMemory(paramLong1, new int[] { localAccessibleTextEvent.start }, 4);
    COM.MoveMemory(paramLong2, new int[] { localAccessibleTextEvent.end }, 4);
    setString(paramLong3, localAccessibleTextEvent.result);
    if (localAccessibleTextEvent.result == null) {
      return 1;
    }
    return 0;
  }
  
  int get_textAfterOffset(int paramInt1, int paramInt2, long paramLong1, long paramLong2, long paramLong3)
  {
    AccessibleTextEvent localAccessibleTextEvent = new AccessibleTextEvent(this);
    int i = getCharacterCount();
    localAccessibleTextEvent.start = (paramInt1 == -2 ? getCaretOffset() : paramInt1 == -1 ? i : paramInt1);
    localAccessibleTextEvent.end = localAccessibleTextEvent.start;
    localAccessibleTextEvent.count = 1;
    switch (paramInt2)
    {
    case 0: 
      localAccessibleTextEvent.type = 0;
      break;
    case 1: 
      localAccessibleTextEvent.type = 1;
      break;
    case 2: 
      localAccessibleTextEvent.type = 2;
      break;
    case 3: 
      localAccessibleTextEvent.type = 3;
      break;
    case 4: 
      localAccessibleTextEvent.type = 4;
      break;
    default: 
      return -2147024809;
    }
    int j = localAccessibleTextEvent.start;
    int k = localAccessibleTextEvent.end;
    for (int m = 0; m < accessibleTextExtendedListenersSize(); m++)
    {
      AccessibleTextExtendedListener localAccessibleTextExtendedListener1 = (AccessibleTextExtendedListener)this.accessibleTextExtendedListeners.elementAt(m);
      localAccessibleTextExtendedListener1.getText(localAccessibleTextEvent);
    }
    if (localAccessibleTextEvent.end < i) {
      switch (paramInt2)
      {
      case 1: 
      case 2: 
      case 3: 
      case 4: 
        m = localAccessibleTextEvent.start;
        localAccessibleTextEvent.start = j;
        localAccessibleTextEvent.end = k;
        localAccessibleTextEvent.count = 2;
        AccessibleTextExtendedListener localAccessibleTextExtendedListener2;
        for (int n = 0; n < accessibleTextExtendedListenersSize(); n++)
        {
          localAccessibleTextExtendedListener2 = (AccessibleTextExtendedListener)this.accessibleTextExtendedListeners.elementAt(n);
          localAccessibleTextExtendedListener2.getText(localAccessibleTextEvent);
        }
        localAccessibleTextEvent.end = localAccessibleTextEvent.start;
        localAccessibleTextEvent.start = m;
        localAccessibleTextEvent.type = 5;
        localAccessibleTextEvent.count = 0;
        for (n = 0; n < accessibleTextExtendedListenersSize(); n++)
        {
          localAccessibleTextExtendedListener2 = (AccessibleTextExtendedListener)this.accessibleTextExtendedListeners.elementAt(n);
          localAccessibleTextExtendedListener2.getText(localAccessibleTextEvent);
        }
      }
    }
    COM.MoveMemory(paramLong1, new int[] { localAccessibleTextEvent.start }, 4);
    COM.MoveMemory(paramLong2, new int[] { localAccessibleTextEvent.end }, 4);
    setString(paramLong3, localAccessibleTextEvent.result);
    if (localAccessibleTextEvent.result == null) {
      return 1;
    }
    return 0;
  }
  
  int get_textAtOffset(int paramInt1, int paramInt2, long paramLong1, long paramLong2, long paramLong3)
  {
    AccessibleTextEvent localAccessibleTextEvent = new AccessibleTextEvent(this);
    int i = getCharacterCount();
    localAccessibleTextEvent.start = (paramInt1 == -2 ? getCaretOffset() : paramInt1 == -1 ? i : paramInt1);
    localAccessibleTextEvent.end = localAccessibleTextEvent.start;
    localAccessibleTextEvent.count = 0;
    switch (paramInt2)
    {
    case 0: 
      localAccessibleTextEvent.type = 0;
      break;
    case 1: 
      localAccessibleTextEvent.type = 1;
      break;
    case 2: 
      localAccessibleTextEvent.type = 2;
      break;
    case 3: 
      localAccessibleTextEvent.type = 3;
      break;
    case 4: 
      localAccessibleTextEvent.type = 4;
      break;
    case 5: 
      localAccessibleTextEvent.type = 5;
      localAccessibleTextEvent.start = 0;
      localAccessibleTextEvent.end = i;
      localAccessibleTextEvent.count = 0;
      break;
    default: 
      return -2147024809;
    }
    int j = localAccessibleTextEvent.start;
    int k = localAccessibleTextEvent.end;
    for (int m = 0; m < accessibleTextExtendedListenersSize(); m++)
    {
      AccessibleTextExtendedListener localAccessibleTextExtendedListener1 = (AccessibleTextExtendedListener)this.accessibleTextExtendedListeners.elementAt(m);
      localAccessibleTextExtendedListener1.getText(localAccessibleTextEvent);
    }
    if (localAccessibleTextEvent.end < i) {
      switch (paramInt2)
      {
      case 1: 
      case 2: 
      case 3: 
      case 4: 
        m = localAccessibleTextEvent.start;
        localAccessibleTextEvent.start = j;
        localAccessibleTextEvent.end = k;
        localAccessibleTextEvent.count = 1;
        AccessibleTextExtendedListener localAccessibleTextExtendedListener2;
        for (int n = 0; n < accessibleTextExtendedListenersSize(); n++)
        {
          localAccessibleTextExtendedListener2 = (AccessibleTextExtendedListener)this.accessibleTextExtendedListeners.elementAt(n);
          localAccessibleTextExtendedListener2.getText(localAccessibleTextEvent);
        }
        localAccessibleTextEvent.end = localAccessibleTextEvent.start;
        localAccessibleTextEvent.start = m;
        localAccessibleTextEvent.type = 5;
        localAccessibleTextEvent.count = 0;
        for (n = 0; n < accessibleTextExtendedListenersSize(); n++)
        {
          localAccessibleTextExtendedListener2 = (AccessibleTextExtendedListener)this.accessibleTextExtendedListeners.elementAt(n);
          localAccessibleTextExtendedListener2.getText(localAccessibleTextEvent);
        }
      }
    }
    COM.MoveMemory(paramLong1, new int[] { localAccessibleTextEvent.start }, 4);
    COM.MoveMemory(paramLong2, new int[] { localAccessibleTextEvent.end }, 4);
    setString(paramLong3, localAccessibleTextEvent.result);
    if (localAccessibleTextEvent.result == null) {
      return 1;
    }
    return 0;
  }
  
  int removeSelection(int paramInt)
  {
    AccessibleTextEvent localAccessibleTextEvent = new AccessibleTextEvent(this);
    localAccessibleTextEvent.index = paramInt;
    for (int i = 0; i < accessibleTextExtendedListenersSize(); i++)
    {
      AccessibleTextExtendedListener localAccessibleTextExtendedListener = (AccessibleTextExtendedListener)this.accessibleTextExtendedListeners.elementAt(i);
      localAccessibleTextExtendedListener.removeSelection(localAccessibleTextEvent);
    }
    if ((localAccessibleTextEvent.result == null) || (!localAccessibleTextEvent.result.equals("OK"))) {
      return -2147024809;
    }
    return 0;
  }
  
  int setCaretOffset(int paramInt)
  {
    AccessibleTextEvent localAccessibleTextEvent = new AccessibleTextEvent(this);
    localAccessibleTextEvent.offset = (paramInt == -1 ? getCharacterCount() : paramInt);
    for (int i = 0; i < accessibleTextExtendedListenersSize(); i++)
    {
      AccessibleTextExtendedListener localAccessibleTextExtendedListener = (AccessibleTextExtendedListener)this.accessibleTextExtendedListeners.elementAt(i);
      localAccessibleTextExtendedListener.setCaretOffset(localAccessibleTextEvent);
    }
    if ((localAccessibleTextEvent.result == null) || (!localAccessibleTextEvent.result.equals("OK"))) {
      return -2147024809;
    }
    return 0;
  }
  
  int setSelection(int paramInt1, int paramInt2, int paramInt3)
  {
    AccessibleTextEvent localAccessibleTextEvent = new AccessibleTextEvent(this);
    localAccessibleTextEvent.index = paramInt1;
    localAccessibleTextEvent.start = (paramInt2 == -1 ? getCharacterCount() : paramInt2);
    localAccessibleTextEvent.end = (paramInt3 == -1 ? getCharacterCount() : paramInt3);
    for (int i = 0; i < accessibleTextExtendedListenersSize(); i++)
    {
      AccessibleTextExtendedListener localAccessibleTextExtendedListener = (AccessibleTextExtendedListener)this.accessibleTextExtendedListeners.elementAt(i);
      localAccessibleTextExtendedListener.setSelection(localAccessibleTextEvent);
    }
    if ((localAccessibleTextEvent.result == null) || (!localAccessibleTextEvent.result.equals("OK"))) {
      return -2147024809;
    }
    return 0;
  }
  
  int get_nCharacters(long paramLong)
  {
    int i = getCharacterCount();
    COM.MoveMemory(paramLong, new int[] { i }, 4);
    return 0;
  }
  
  int scrollSubstringTo(int paramInt1, int paramInt2, int paramInt3)
  {
    AccessibleTextEvent localAccessibleTextEvent = new AccessibleTextEvent(this);
    localAccessibleTextEvent.start = paramInt1;
    localAccessibleTextEvent.end = paramInt2;
    switch (paramInt3)
    {
    case 0: 
      localAccessibleTextEvent.type = 0;
      break;
    case 1: 
      localAccessibleTextEvent.type = 1;
      break;
    case 2: 
      localAccessibleTextEvent.type = 2;
      break;
    case 3: 
      localAccessibleTextEvent.type = 3;
      break;
    case 4: 
      localAccessibleTextEvent.type = 4;
      break;
    case 5: 
      localAccessibleTextEvent.type = 5;
      break;
    case 6: 
      localAccessibleTextEvent.type = 6;
    }
    for (int i = 0; i < accessibleTextExtendedListenersSize(); i++)
    {
      AccessibleTextExtendedListener localAccessibleTextExtendedListener = (AccessibleTextExtendedListener)this.accessibleTextExtendedListeners.elementAt(i);
      localAccessibleTextExtendedListener.scrollText(localAccessibleTextEvent);
    }
    if ((localAccessibleTextEvent.result == null) || (!localAccessibleTextEvent.result.equals("OK"))) {
      return -2147024809;
    }
    return 0;
  }
  
  int scrollSubstringToPoint(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
  {
    AccessibleTextEvent localAccessibleTextEvent = new AccessibleTextEvent(this);
    localAccessibleTextEvent.start = paramInt1;
    localAccessibleTextEvent.end = paramInt2;
    localAccessibleTextEvent.type = 7;
    localAccessibleTextEvent.x = paramInt4;
    localAccessibleTextEvent.y = paramInt5;
    for (int i = 0; i < accessibleTextExtendedListenersSize(); i++)
    {
      AccessibleTextExtendedListener localAccessibleTextExtendedListener = (AccessibleTextExtendedListener)this.accessibleTextExtendedListeners.elementAt(i);
      localAccessibleTextExtendedListener.scrollText(localAccessibleTextEvent);
    }
    if ((localAccessibleTextEvent.result == null) || (!localAccessibleTextEvent.result.equals("OK"))) {
      return -2147024809;
    }
    return 0;
  }
  
  int get_newText(long paramLong)
  {
    String str = null;
    int i = 0;
    int j = 0;
    if (this.textInserted != null)
    {
      str = (String)this.textInserted[3];
      i = ((Integer)this.textInserted[1]).intValue();
      j = ((Integer)this.textInserted[2]).intValue();
    }
    setString(paramLong, str);
    COM.MoveMemory(paramLong + OS.PTR_SIZEOF, new int[] { i }, 4);
    COM.MoveMemory(paramLong + OS.PTR_SIZEOF + 4L, new int[] { j }, 4);
    if (this.textInserted == null) {
      return 1;
    }
    return 0;
  }
  
  int get_oldText(long paramLong)
  {
    String str = null;
    int i = 0;
    int j = 0;
    if (this.textDeleted != null)
    {
      str = (String)this.textDeleted[3];
      i = ((Integer)this.textDeleted[1]).intValue();
      j = ((Integer)this.textDeleted[2]).intValue();
    }
    setString(paramLong, str);
    COM.MoveMemory(paramLong + OS.PTR_SIZEOF, new int[] { i }, 4);
    COM.MoveMemory(paramLong + OS.PTR_SIZEOF + 4L, new int[] { j }, 4);
    if (this.textDeleted == null) {
      return 1;
    }
    return 0;
  }
  
  int get_currentValue(long paramLong)
  {
    AccessibleValueEvent localAccessibleValueEvent = new AccessibleValueEvent(this);
    for (int i = 0; i < accessibleValueListenersSize(); i++)
    {
      AccessibleValueListener localAccessibleValueListener = (AccessibleValueListener)this.accessibleValueListeners.elementAt(i);
      localAccessibleValueListener.getCurrentValue(localAccessibleValueEvent);
    }
    setNumberVARIANT(paramLong, localAccessibleValueEvent.value);
    return 0;
  }
  
  int setCurrentValue(long paramLong)
  {
    AccessibleValueEvent localAccessibleValueEvent = new AccessibleValueEvent(this);
    localAccessibleValueEvent.value = getNumberVARIANT(paramLong);
    for (int i = 0; i < accessibleValueListenersSize(); i++)
    {
      AccessibleValueListener localAccessibleValueListener = (AccessibleValueListener)this.accessibleValueListeners.elementAt(i);
      localAccessibleValueListener.setCurrentValue(localAccessibleValueEvent);
    }
    return 0;
  }
  
  int get_maximumValue(long paramLong)
  {
    AccessibleValueEvent localAccessibleValueEvent = new AccessibleValueEvent(this);
    for (int i = 0; i < accessibleValueListenersSize(); i++)
    {
      AccessibleValueListener localAccessibleValueListener = (AccessibleValueListener)this.accessibleValueListeners.elementAt(i);
      localAccessibleValueListener.getMaximumValue(localAccessibleValueEvent);
    }
    setNumberVARIANT(paramLong, localAccessibleValueEvent.value);
    return 0;
  }
  
  int get_minimumValue(long paramLong)
  {
    AccessibleValueEvent localAccessibleValueEvent = new AccessibleValueEvent(this);
    for (int i = 0; i < accessibleValueListenersSize(); i++)
    {
      AccessibleValueListener localAccessibleValueListener = (AccessibleValueListener)this.accessibleValueListeners.elementAt(i);
      localAccessibleValueListener.getMinimumValue(localAccessibleValueEvent);
    }
    setNumberVARIANT(paramLong, localAccessibleValueEvent.value);
    return 0;
  }
  
  int eventChildID()
  {
    if (this.parent == null) {
      return 0;
    }
    if (this.uniqueID == -1) {
      this.uniqueID = (UniqueID--);
    }
    return this.uniqueID;
  }
  
  void checkUniqueID(int paramInt)
  {
    AccessibleControlEvent localAccessibleControlEvent = new AccessibleControlEvent(this);
    localAccessibleControlEvent.childID = paramInt;
    for (int i = 0; i < accessibleControlListenersSize(); i++)
    {
      AccessibleControlListener localAccessibleControlListener = (AccessibleControlListener)this.accessibleControlListeners.elementAt(i);
      localAccessibleControlListener.getChild(localAccessibleControlEvent);
    }
    Accessible localAccessible = localAccessibleControlEvent.accessible;
    if ((localAccessible != null) && (localAccessible.uniqueID == -1)) {
      localAccessible.uniqueID = paramInt;
    }
  }
  
  int childIDToOs(int paramInt)
  {
    if (paramInt == -1) {
      return 0;
    }
    int i = paramInt + 1;
    if ((this.control instanceof Tree)) {
      if (OS.COMCTL32_MAJOR < 6) {
        i = paramInt;
      } else {
        i = (int)OS.SendMessage(this.control.handle, 4395, paramInt, 0L);
      }
    }
    checkUniqueID(i);
    return i;
  }
  
  int osToChildID(int paramInt)
  {
    if (paramInt == 0) {
      return -1;
    }
    if (!(this.control instanceof Tree)) {
      return paramInt - 1;
    }
    if (OS.COMCTL32_MAJOR < 6) {
      return paramInt;
    }
    return (int)OS.SendMessage(this.control.handle, 4394, paramInt, 0L);
  }
  
  int stateToOs(int paramInt)
  {
    int i = 0;
    if ((paramInt & 0x2) != 0) {
      i |= 0x2;
    }
    if ((paramInt & 0x200000) != 0) {
      i |= 0x200000;
    }
    if ((paramInt & 0x1000000) != 0) {
      i |= 0x1000000;
    }
    if ((paramInt & 0x4) != 0) {
      i |= 0x4;
    }
    if ((paramInt & 0x100000) != 0) {
      i |= 0x100000;
    }
    if ((paramInt & 0x8) != 0) {
      i |= 0x8;
    }
    if ((paramInt & 0x10) != 0) {
      i |= 0x10;
    }
    if ((paramInt & 0x200) != 0) {
      i |= 0x200;
    }
    if ((paramInt & 0x400) != 0) {
      i |= 0x400;
    }
    if ((paramInt & 0x80) != 0) {
      i |= 0x80;
    }
    if ((paramInt & 0x800) != 0) {
      i |= 0x800;
    }
    if ((paramInt & 0x40) != 0) {
      i |= 0x40;
    }
    if ((paramInt & 0x8000) != 0) {
      i |= 0x8000;
    }
    if ((paramInt & 0x10000) != 0) {
      i |= 0x10000;
    }
    if ((paramInt & 0x20000) != 0) {
      i |= 0x20000;
    }
    if ((paramInt & 0x400000) != 0) {
      i |= 0x400000;
    }
    if ((paramInt & 0x1) != 0) {
      i |= 0x1;
    }
    return i;
  }
  
  int osToState(int paramInt)
  {
    int i = 0;
    if ((paramInt & 0x2) != 0) {
      i |= 0x2;
    }
    if ((paramInt & 0x200000) != 0) {
      i |= 0x200000;
    }
    if ((paramInt & 0x1000000) != 0) {
      i |= 0x1000000;
    }
    if ((paramInt & 0x4) != 0) {
      i |= 0x4;
    }
    if ((paramInt & 0x100000) != 0) {
      i |= 0x100000;
    }
    if ((paramInt & 0x8) != 0) {
      i |= 0x8;
    }
    if ((paramInt & 0x10) != 0) {
      i |= 0x10;
    }
    if ((paramInt & 0x200) != 0) {
      i |= 0x200;
    }
    if ((paramInt & 0x400) != 0) {
      i |= 0x400;
    }
    if ((paramInt & 0x80) != 0) {
      i |= 0x80;
    }
    if ((paramInt & 0x800) != 0) {
      i |= 0x800;
    }
    if ((paramInt & 0x40) != 0) {
      i |= 0x40;
    }
    if ((paramInt & 0x8000) != 0) {
      i |= 0x8000;
    }
    if ((paramInt & 0x10000) != 0) {
      i |= 0x10000;
    }
    if ((paramInt & 0x20000) != 0) {
      i |= 0x20000;
    }
    if ((paramInt & 0x400000) != 0) {
      i |= 0x400000;
    }
    if ((paramInt & 0x1) != 0) {
      i |= 0x1;
    }
    return i;
  }
  
  int roleToOs(int paramInt)
  {
    switch (paramInt)
    {
    case 10: 
      return 10;
    case 9: 
      return 9;
    case 2: 
      return 2;
    case 11: 
      return 11;
    case 12: 
      return 12;
    case 21: 
      return 21;
    case 13: 
      return 13;
    case 3: 
      return 3;
    case 18: 
      return 18;
    case 41: 
      return 41;
    case 43: 
      return 43;
    case 44: 
      return 44;
    case 45: 
      return 45;
    case 62: 
      return 62;
    case 46: 
      return 46;
    case 42: 
      return 42;
    case 22: 
      return 22;
    case 33: 
      return 33;
    case 34: 
      return 34;
    case 24: 
      return 24;
    case 29: 
      return 29;
    case 25: 
      return 25;
    case 26: 
      return 26;
    case 35: 
      return 35;
    case 36: 
      return 36;
    case 60: 
      return 60;
    case 37: 
      return 37;
    case 48: 
      return 48;
    case 51: 
      return 51;
    case 30: 
      return 30;
    case 8: 
      return 8;
    case 54: 
      return 54;
    case 27: 
      return 27;
    case 15: 
      return 15;
    case 40: 
      return 40;
    case 20: 
      return 20;
    case 28: 
      return 28;
    case 52: 
      return 52;
    case 23: 
      return 23;
    case 61: 
      return 61;
    case 47: 
      return 47;
    case 1025: 
      return 10;
    case 1027: 
      return 12;
    case 1073: 
      return 12;
    case 1029: 
      return 47;
    case 1038: 
      return 10;
    case 1040: 
      return 10;
    case 1043: 
      return 10;
    case 1044: 
      return 10;
    case 1053: 
      return 10;
    case 1054: 
      return 10;
    case 1060: 
      return 10;
    }
    return 10;
  }
  
  int osToRole(int paramInt)
  {
    switch (paramInt)
    {
    case 10: 
      return 10;
    case 9: 
      return 9;
    case 2: 
      return 2;
    case 11: 
      return 11;
    case 12: 
      return 12;
    case 21: 
      return 21;
    case 13: 
      return 13;
    case 3: 
      return 3;
    case 18: 
      return 18;
    case 41: 
      return 41;
    case 43: 
      return 43;
    case 44: 
      return 44;
    case 45: 
      return 45;
    case 62: 
      return 62;
    case 46: 
      return 46;
    case 42: 
      return 42;
    case 22: 
      return 22;
    case 33: 
      return 33;
    case 34: 
      return 34;
    case 24: 
      return 24;
    case 29: 
      return 29;
    case 25: 
      return 25;
    case 26: 
      return 26;
    case 35: 
      return 35;
    case 36: 
      return 36;
    case 60: 
      return 60;
    case 37: 
      return 37;
    case 48: 
      return 48;
    case 51: 
      return 51;
    case 30: 
      return 30;
    case 8: 
      return 8;
    case 54: 
      return 54;
    case 27: 
      return 27;
    case 15: 
      return 15;
    case 40: 
      return 40;
    case 20: 
      return 20;
    case 28: 
      return 28;
    case 52: 
      return 52;
    case 23: 
      return 23;
    case 61: 
      return 61;
    case 47: 
      return 47;
    }
    return 10;
  }
  
  Color colorFromString(String paramString)
  {
    try
    {
      int i = paramString.indexOf('(');
      int j = paramString.indexOf(',');
      int k = paramString.indexOf(',', j + 1);
      int m = paramString.indexOf(')');
      int n = Integer.parseInt(paramString.substring(i + 1, j));
      int i1 = Integer.parseInt(paramString.substring(j + 1, k));
      int i2 = Integer.parseInt(paramString.substring(k + 1, m));
      return new Color(this.control.getDisplay(), n, i1, i2);
    }
    catch (NumberFormatException localNumberFormatException) {}
    return null;
  }
  
  int getCaretOffset()
  {
    AccessibleTextEvent localAccessibleTextEvent = new AccessibleTextEvent(this);
    localAccessibleTextEvent.offset = -1;
    AccessibleTextListener localAccessibleTextListener;
    for (int i = 0; i < accessibleTextExtendedListenersSize(); i++)
    {
      localAccessibleTextListener = (AccessibleTextListener)this.accessibleTextExtendedListeners.elementAt(i);
      localAccessibleTextListener.getCaretOffset(localAccessibleTextEvent);
    }
    if (localAccessibleTextEvent.offset == -1) {
      for (i = 0; i < accessibleTextListenersSize(); i++)
      {
        localAccessibleTextEvent.childID = -1;
        localAccessibleTextListener = (AccessibleTextListener)this.accessibleTextListeners.elementAt(i);
        localAccessibleTextListener.getCaretOffset(localAccessibleTextEvent);
      }
    }
    return localAccessibleTextEvent.offset;
  }
  
  int getCharacterCount()
  {
    AccessibleTextEvent localAccessibleTextEvent = new AccessibleTextEvent(this);
    localAccessibleTextEvent.count = -1;
    for (int i = 0; i < accessibleTextExtendedListenersSize(); i++)
    {
      AccessibleTextExtendedListener localAccessibleTextExtendedListener = (AccessibleTextExtendedListener)this.accessibleTextExtendedListeners.elementAt(i);
      localAccessibleTextExtendedListener.getCharacterCount(localAccessibleTextEvent);
    }
    if (localAccessibleTextEvent.count == -1)
    {
      AccessibleControlEvent localAccessibleControlEvent = new AccessibleControlEvent(this);
      localAccessibleControlEvent.childID = -1;
      for (int j = 0; j < accessibleControlListenersSize(); j++)
      {
        AccessibleControlListener localAccessibleControlListener = (AccessibleControlListener)this.accessibleControlListeners.elementAt(j);
        localAccessibleControlListener.getRole(localAccessibleControlEvent);
        localAccessibleControlListener.getValue(localAccessibleControlEvent);
      }
      localAccessibleTextEvent.count = ((localAccessibleControlEvent.detail == 42) && (localAccessibleControlEvent.result != null) ? localAccessibleControlEvent.result.length() : 0);
    }
    return localAccessibleTextEvent.count;
  }
  
  int getRelationCount()
  {
    int i = 0;
    for (int j = 0; j < 15; j++) {
      if (this.relations[j] != null) {
        i++;
      }
    }
    return i;
  }
  
  int getRole()
  {
    AccessibleControlEvent localAccessibleControlEvent = new AccessibleControlEvent(this);
    localAccessibleControlEvent.childID = -1;
    for (int i = 0; i < accessibleControlListenersSize(); i++)
    {
      AccessibleControlListener localAccessibleControlListener = (AccessibleControlListener)this.accessibleControlListeners.elementAt(i);
      localAccessibleControlListener.getRole(localAccessibleControlEvent);
    }
    return localAccessibleControlEvent.detail;
  }
  
  int getDefaultRole()
  {
    int i = 10;
    if (this.iaccessible != null)
    {
      long l1 = OS.GlobalAlloc(64, VARIANT.sizeof);
      setIntVARIANT(l1, (short)3, 0);
      long l2 = OS.GlobalAlloc(64, VARIANT.sizeof);
      int j = this.iaccessible.get_accRole(l1, l2);
      if (j == 0)
      {
        VARIANT localVARIANT = getVARIANT(l2);
        if (localVARIANT.vt == 3) {
          i = localVARIANT.lVal;
        }
      }
      OS.GlobalFree(l1);
      OS.GlobalFree(l2);
    }
    return i;
  }
  
  String getString(long paramLong)
  {
    long[] arrayOfLong = new long[1];
    OS.MoveMemory(arrayOfLong, paramLong, OS.PTR_SIZEOF);
    int i = COM.SysStringByteLen(arrayOfLong[0]);
    if (i == 0) {
      return "";
    }
    char[] arrayOfChar = new char[(i + 1) / 2];
    OS.MoveMemory(arrayOfChar, arrayOfLong[0], i);
    return new String(arrayOfChar);
  }
  
  VARIANT getVARIANT(long paramLong)
  {
    VARIANT localVARIANT = new VARIANT();
    COM.MoveMemory(localVARIANT, paramLong, VARIANT.sizeof);
    return localVARIANT;
  }
  
  Number getNumberVARIANT(long paramLong)
  {
    VARIANT localVARIANT = new VARIANT();
    COM.MoveMemory(localVARIANT, paramLong, VARIANT.sizeof);
    if (localVARIANT.vt == 20) {
      return new Long(localVARIANT.lVal);
    }
    return new Integer(localVARIANT.lVal);
  }
  
  void setIntVARIANT(long paramLong, short paramShort, int paramInt)
  {
    if ((paramShort == 3) || (paramShort == 0))
    {
      COM.MoveMemory(paramLong, new short[] { paramShort }, 2);
      COM.MoveMemory(paramLong + 8L, new int[] { paramInt }, 4);
    }
  }
  
  void setPtrVARIANT(long paramLong1, short paramShort, long paramLong2)
  {
    if ((paramShort == 9) || (paramShort == 13))
    {
      COM.MoveMemory(paramLong1, new short[] { paramShort }, 2);
      COM.MoveMemory(paramLong1 + 8L, new long[] { paramLong2 }, OS.PTR_SIZEOF);
    }
  }
  
  void setNumberVARIANT(long paramLong, Number paramNumber)
  {
    if (paramNumber == null)
    {
      COM.MoveMemory(paramLong, new short[] { 0 }, 2);
      COM.MoveMemory(paramLong + 8L, new int[] { 0 }, 4);
    }
    else if ((paramNumber instanceof Double))
    {
      COM.MoveMemory(paramLong, new short[] { 5 }, 2);
      COM.MoveMemory(paramLong + 8L, new double[] { paramNumber.doubleValue() }, 8);
    }
    else if ((paramNumber instanceof Float))
    {
      COM.MoveMemory(paramLong, new short[] { 4 }, 2);
      COM.MoveMemory(paramLong + 8L, new float[] { paramNumber.floatValue() }, 4);
    }
    else if ((paramNumber instanceof Long))
    {
      COM.MoveMemory(paramLong, new short[] { 20 }, 2);
      COM.MoveMemory(paramLong + 8L, new long[] { paramNumber.longValue() }, 8);
    }
    else
    {
      COM.MoveMemory(paramLong, new short[] { 3 }, 2);
      COM.MoveMemory(paramLong + 8L, new int[] { paramNumber.intValue() }, 4);
    }
  }
  
  void setString(long paramLong, String paramString)
  {
    long l = 0L;
    if (paramString != null)
    {
      char[] arrayOfChar = (paramString + "\000").toCharArray();
      l = COM.SysAllocString(arrayOfChar);
    }
    COM.MoveMemory(paramLong, new long[] { l }, OS.PTR_SIZEOF);
  }
  
  void setStringVARIANT(long paramLong, String paramString)
  {
    long l = 0L;
    if (paramString != null)
    {
      char[] arrayOfChar = (paramString + "\000").toCharArray();
      l = COM.SysAllocString(arrayOfChar);
    }
    COM.MoveMemory(paramLong, new short[] { l == 0L ? 0 : 8 }, 2);
    COM.MoveMemory(paramLong + 8L, new long[] { l }, OS.PTR_SIZEOF);
  }
  
  void checkWidget()
  {
    if (!isValidThread()) {
      SWT.error(22);
    }
    if (this.control.isDisposed()) {
      SWT.error(24);
    }
  }
  
  boolean isATRunning()
  {
    return true;
  }
  
  boolean isValidThread()
  {
    return this.control.getDisplay().getThread() == Thread.currentThread();
  }
  
  static void print(String paramString) {}
  
  String getRoleString(int paramInt)
  {
    return "Unknown role (" + paramInt + ")";
  }
  
  String getStateString(int paramInt)
  {
    if (paramInt == 0) {
      return " no state bits set";
    }
    StringBuffer localStringBuffer = new StringBuffer();
    return localStringBuffer.toString();
  }
  
  String getIA2StatesString(int paramInt)
  {
    if (paramInt == 0) {
      return " no state bits set";
    }
    StringBuffer localStringBuffer = new StringBuffer();
    return localStringBuffer.toString();
  }
  
  String getEventString(int paramInt)
  {
    return "Unknown event (" + paramInt + ")";
  }
  
  private String hresult(int paramInt)
  {
    return " HRESULT=" + paramInt;
  }
  
  boolean interesting(GUID paramGUID)
  {
    return false;
  }
  
  String guidString(GUID paramGUID)
  {
    return paramGUID.toString();
  }
  
  static GUID IIDFromString(String paramString)
  {
    return null;
  }
  
  public String toString()
  {
    String str = super.toString();
    return str;
  }
  
  static
  {
    String str = System.getProperty("org.eclipse.swt.accessibility.UseIA2");
    if ((str != null) && (str.equalsIgnoreCase("false"))) {
      UseIA2 = false;
    }
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/accessibility/Accessible.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */