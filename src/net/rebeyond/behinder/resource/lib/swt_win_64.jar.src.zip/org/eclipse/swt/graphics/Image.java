package org.eclipse.swt.graphics;

import java.io.InputStream;
import org.eclipse.swt.SWT;
import org.eclipse.swt.SWTException;
import org.eclipse.swt.internal.gdip.BitmapData;
import org.eclipse.swt.internal.gdip.ColorPalette;
import org.eclipse.swt.internal.gdip.Gdip;
import org.eclipse.swt.internal.gdip.Rect;
import org.eclipse.swt.internal.win32.BITMAP;
import org.eclipse.swt.internal.win32.BITMAPINFOHEADER;
import org.eclipse.swt.internal.win32.DIBSECTION;
import org.eclipse.swt.internal.win32.ICONINFO;
import org.eclipse.swt.internal.win32.OS;

public final class Image
  extends Resource
  implements Drawable
{
  public int type;
  public long handle;
  int transparentPixel = -1;
  int transparentColor = -1;
  GC memGC;
  byte[] alphaData;
  int alpha = -1;
  ImageData data;
  int width = -1;
  int height = -1;
  static final int DEFAULT_SCANLINE_PAD = 4;
  
  Image(Device paramDevice)
  {
    super(paramDevice);
  }
  
  public Image(Device paramDevice, int paramInt1, int paramInt2)
  {
    super(paramDevice);
    init(paramInt1, paramInt2);
    init();
  }
  
  public Image(Device paramDevice, Image paramImage, int paramInt)
  {
    super(paramDevice);
    paramDevice = this.device;
    if (paramImage == null) {
      SWT.error(4);
    }
    if (paramImage.isDisposed()) {
      SWT.error(5);
    }
    Rectangle localRectangle = paramImage.getBounds();
    this.type = paramImage.type;
    ImageData localImageData1;
    PaletteData localPaletteData;
    Object localObject1;
    Object localObject2;
    int[] arrayOfInt3;
    int m;
    int n;
    int i1;
    int i2;
    int i3;
    int i4;
    int i5;
    int i6;
    int i7;
    int i8;
    int i9;
    int i10;
    switch (paramInt)
    {
    case 0: 
      switch (this.type)
      {
      case 0: 
        long l1 = paramDevice.internal_new_GC(null);
        long l2 = OS.CreateCompatibleDC(l1);
        long l3 = OS.CreateCompatibleDC(l1);
        long l4 = OS.SelectObject(l2, paramImage.handle);
        BITMAP localBITMAP = new BITMAP();
        OS.GetObject(paramImage.handle, BITMAP.sizeof, localBITMAP);
        this.handle = OS.CreateCompatibleBitmap(l2, localRectangle.width, localBITMAP.bmBits != 0L ? -localRectangle.height : localRectangle.height);
        if (this.handle == 0L) {
          SWT.error(2);
        }
        long l5 = OS.SelectObject(l3, this.handle);
        OS.BitBlt(l3, 0, 0, localRectangle.width, localRectangle.height, l2, 0, 0, 13369376);
        OS.SelectObject(l2, l4);
        OS.SelectObject(l3, l5);
        OS.DeleteDC(l2);
        OS.DeleteDC(l3);
        paramDevice.internal_dispose_GC(l1, null);
        this.transparentPixel = paramImage.transparentPixel;
        this.alpha = paramImage.alpha;
        if (paramImage.alphaData != null)
        {
          this.alphaData = new byte[paramImage.alphaData.length];
          System.arraycopy(paramImage.alphaData, 0, this.alphaData, 0, this.alphaData.length);
        }
        break;
      case 1: 
        if (OS.IsWinCE)
        {
          init(paramImage.data);
        }
        else
        {
          this.handle = OS.CopyImage(paramImage.handle, 1, localRectangle.width, localRectangle.height, 0);
          if (this.handle == 0L) {
            SWT.error(2);
          }
        }
        break;
      default: 
        SWT.error(40);
      }
      break;
    case 1: 
      localImageData1 = paramImage.getImageData();
      localPaletteData = localImageData1.palette;
      localObject1 = new RGB[3];
      localObject1[0] = paramDevice.getSystemColor(2).getRGB();
      localObject1[1] = paramDevice.getSystemColor(18).getRGB();
      localObject1[2] = paramDevice.getSystemColor(22).getRGB();
      localObject2 = new ImageData(localRectangle.width, localRectangle.height, 8, new PaletteData((RGB[])localObject1));
      ((ImageData)localObject2).alpha = localImageData1.alpha;
      ((ImageData)localObject2).alphaData = localImageData1.alphaData;
      ((ImageData)localObject2).maskData = localImageData1.maskData;
      ((ImageData)localObject2).maskPad = localImageData1.maskPad;
      if (localImageData1.transparentPixel != -1) {
        ((ImageData)localObject2).transparentPixel = 0;
      }
      int[] arrayOfInt1 = new int[localRectangle.width];
      arrayOfInt3 = null;
      ImageData localImageData2 = null;
      if (localImageData1.maskData != null) {
        localImageData2 = localImageData1.getTransparencyMask();
      }
      if (localImageData2 != null) {
        arrayOfInt3 = new int[localRectangle.width];
      }
      m = localPaletteData.redMask;
      n = localPaletteData.greenMask;
      i1 = localPaletteData.blueMask;
      i2 = localPaletteData.redShift;
      i3 = localPaletteData.greenShift;
      i4 = localPaletteData.blueShift;
      for (i5 = 0; i5 < localRectangle.height; i5++)
      {
        i6 = i5 * ((ImageData)localObject2).bytesPerLine;
        localImageData1.getPixels(0, i5, localRectangle.width, arrayOfInt1, 0);
        if (localImageData2 != null) {
          localImageData2.getPixels(0, i5, localRectangle.width, arrayOfInt3, 0);
        }
        for (i7 = 0; i7 < localRectangle.width; i7++)
        {
          i8 = arrayOfInt1[i7];
          if (((localImageData1.transparentPixel == -1) || (i8 != localImageData1.transparentPixel)) && ((localImageData2 == null) || (arrayOfInt3[i7] != 0)))
          {
            int i11;
            if (localPaletteData.isDirect)
            {
              i9 = i8 & m;
              i9 = i2 < 0 ? i9 >>> -i2 : i9 << i2;
              i10 = i8 & n;
              i10 = i3 < 0 ? i10 >>> -i3 : i10 << i3;
              i11 = i8 & i1;
              i11 = i4 < 0 ? i11 >>> -i4 : i11 << i4;
            }
            else
            {
              i9 = localPaletteData.colors[i8].red;
              i10 = localPaletteData.colors[i8].green;
              i11 = localPaletteData.colors[i8].blue;
            }
            int i12 = i9 * i9 + i10 * i10 + i11 * i11;
            if (i12 < 98304) {
              ((ImageData)localObject2).data[i6] = 1;
            } else {
              ((ImageData)localObject2).data[i6] = 2;
            }
          }
          i6++;
        }
      }
      init((ImageData)localObject2);
      break;
    case 2: 
      localImageData1 = paramImage.getImageData();
      localPaletteData = localImageData1.palette;
      localObject1 = localImageData1;
      int i;
      int k;
      if (!localPaletteData.isDirect)
      {
        localObject2 = localPaletteData.getRGBs();
        for (i = 0; i < localObject2.length; i++) {
          if (localImageData1.transparentPixel != i)
          {
            arrayOfInt3 = localObject2[i];
            k = arrayOfInt3.red;
            m = arrayOfInt3.green;
            n = arrayOfInt3.blue;
            i1 = k + k + m + m + m + m + m + n >> 3;
            arrayOfInt3.red = (arrayOfInt3.green = arrayOfInt3.blue = i1);
          }
        }
        ((ImageData)localObject1).palette = new PaletteData((RGB[])localObject2);
      }
      else
      {
        localObject2 = new RGB['Ā'];
        for (i = 0; i < localObject2.length; i++) {
          localObject2[i] = new RGB(i, i, i);
        }
        localObject1 = new ImageData(localRectangle.width, localRectangle.height, 8, new PaletteData((RGB[])localObject2));
        ((ImageData)localObject1).alpha = localImageData1.alpha;
        ((ImageData)localObject1).alphaData = localImageData1.alphaData;
        ((ImageData)localObject1).maskData = localImageData1.maskData;
        ((ImageData)localObject1).maskPad = localImageData1.maskPad;
        if (localImageData1.transparentPixel != -1) {
          ((ImageData)localObject1).transparentPixel = 254;
        }
        int[] arrayOfInt2 = new int[localRectangle.width];
        int j = localPaletteData.redMask;
        k = localPaletteData.greenMask;
        m = localPaletteData.blueMask;
        n = localPaletteData.redShift;
        i1 = localPaletteData.greenShift;
        i2 = localPaletteData.blueShift;
        for (i3 = 0; i3 < localRectangle.height; i3++)
        {
          i4 = i3 * ((ImageData)localObject1).bytesPerLine;
          localImageData1.getPixels(0, i3, localRectangle.width, arrayOfInt2, 0);
          for (i5 = 0; i5 < localRectangle.width; i5++)
          {
            i6 = arrayOfInt2[i5];
            if (i6 != localImageData1.transparentPixel)
            {
              i7 = i6 & j;
              i7 = n < 0 ? i7 >>> -n : i7 << n;
              i8 = i6 & k;
              i8 = i1 < 0 ? i8 >>> -i1 : i8 << i1;
              i9 = i6 & m;
              i9 = i2 < 0 ? i9 >>> -i2 : i9 << i2;
              i10 = i7 + i7 + i8 + i8 + i8 + i8 + i8 + i9 >> 3;
              if (((ImageData)localObject1).transparentPixel == i10) {
                i10 = 255;
              }
              ((ImageData)localObject1).data[i4] = ((byte)i10);
            }
            else
            {
              ((ImageData)localObject1).data[i4] = -2;
            }
            i4++;
          }
        }
      }
      init((ImageData)localObject1);
      break;
    default: 
      SWT.error(5);
    }
    init();
  }
  
  public Image(Device paramDevice, Rectangle paramRectangle)
  {
    super(paramDevice);
    if (paramRectangle == null) {
      SWT.error(4);
    }
    init(paramRectangle.width, paramRectangle.height);
    init();
  }
  
  public Image(Device paramDevice, ImageData paramImageData)
  {
    super(paramDevice);
    init(paramImageData);
    init();
  }
  
  public Image(Device paramDevice, ImageData paramImageData1, ImageData paramImageData2)
  {
    super(paramDevice);
    if (paramImageData1 == null) {
      SWT.error(4);
    }
    if (paramImageData2 == null) {
      SWT.error(4);
    }
    if ((paramImageData1.width != paramImageData2.width) || (paramImageData1.height != paramImageData2.height)) {
      SWT.error(5);
    }
    paramImageData2 = ImageData.convertMask(paramImageData2);
    init(this.device, this, paramImageData1, paramImageData2);
    init();
  }
  
  public Image(Device paramDevice, InputStream paramInputStream)
  {
    super(paramDevice);
    init(new ImageData(paramInputStream));
    init();
  }
  
  public Image(Device paramDevice, String paramString)
  {
    super(paramDevice);
    if (paramString == null) {
      SWT.error(4);
    }
    initNative(paramString);
    if (this.handle == 0L) {
      init(new ImageData(paramString));
    }
    init();
  }
  
  void initNative(String paramString)
  {
    int i = 1;
    try
    {
      this.device.checkGDIP();
    }
    catch (SWTException localSWTException)
    {
      i = 0;
    }
    if ((i != 0) && (OS.PTR_SIZEOF == 8) && (paramString.toLowerCase().endsWith(".gif"))) {
      i = 0;
    }
    if ((!OS.IsWinCE) && (OS.WIN32_VERSION >= OS.VERSION(6, 1)) && (paramString.toLowerCase().endsWith(".gif"))) {
      i = 0;
    }
    if (i != 0)
    {
      int j = paramString.length();
      char[] arrayOfChar = new char[j + 1];
      paramString.getChars(0, j, arrayOfChar, 0);
      long l1 = Gdip.Bitmap_new(arrayOfChar, false);
      if (l1 != 0L)
      {
        int k = 2;
        int m = Gdip.Image_GetLastStatus(l1);
        if (m == 0) {
          if (paramString.toLowerCase().endsWith(".ico"))
          {
            this.type = 1;
            long[] arrayOfLong = new long[1];
            m = Gdip.Bitmap_GetHICON(l1, arrayOfLong);
            this.handle = arrayOfLong[0];
          }
          else
          {
            this.type = 0;
            int n = Gdip.Image_GetWidth(l1);
            int i1 = Gdip.Image_GetHeight(l1);
            int i2 = Gdip.Image_GetPixelFormat(l1);
            switch (i2)
            {
            case 135173: 
            case 135174: 
              this.handle = createDIB(n, i1, 16);
              break;
            case 8207: 
            case 137224: 
              this.handle = createDIB(n, i1, 24);
              break;
            case 139273: 
            case 925707: 
            case 1052676: 
            case 1060876: 
            case 1851406: 
            case 3424269: 
              this.handle = createDIB(n, i1, 32);
            }
            long l2;
            long l4;
            if (this.handle != 0L)
            {
              l2 = this.device.internal_new_GC(null);
              long l3 = OS.CreateCompatibleDC(l2);
              l4 = OS.SelectObject(l3, this.handle);
              long l5 = Gdip.Graphics_new(l3);
              if (l5 != 0L)
              {
                Rect localRect = new Rect();
                localRect.Width = n;
                localRect.Height = i1;
                m = Gdip.Graphics_DrawImage(l5, l1, localRect, 0, 0, n, i1, 2, 0L, 0L, 0L);
                if (m != 0)
                {
                  k = 40;
                  OS.DeleteObject(this.handle);
                  this.handle = 0L;
                }
                Gdip.Graphics_delete(l5);
              }
              OS.SelectObject(l3, l4);
              OS.DeleteDC(l3);
              this.device.internal_dispose_GC(l2, null);
            }
            else
            {
              l2 = Gdip.BitmapData_new();
              if (l2 != 0L)
              {
                m = Gdip.Bitmap_LockBits(l1, 0L, 0, i2, l2);
                if (m == 0)
                {
                  BitmapData localBitmapData = new BitmapData();
                  Gdip.MoveMemory(localBitmapData, l2);
                  int i3 = localBitmapData.Stride;
                  l4 = localBitmapData.Scan0;
                  int i4 = 0;
                  int i5 = 4;
                  int i6 = -1;
                  switch (localBitmapData.PixelFormat)
                  {
                  case 196865: 
                    i4 = 1;
                    break;
                  case 197634: 
                    i4 = 4;
                    break;
                  case 198659: 
                    i4 = 8;
                    break;
                  case 135173: 
                  case 135174: 
                  case 397319: 
                    i4 = 16;
                    break;
                  case 137224: 
                    i4 = 24;
                    break;
                  case 139273: 
                  case 2498570: 
                    i4 = 32;
                  }
                  if (i4 != 0)
                  {
                    PaletteData localPaletteData = null;
                    switch (localBitmapData.PixelFormat)
                    {
                    case 196865: 
                    case 197634: 
                    case 198659: 
                      int i7 = Gdip.Image_GetPaletteSize(l1);
                      long l6 = OS.GetProcessHeap();
                      long l7 = OS.HeapAlloc(l6, 8, i7);
                      if (l7 == 0L) {
                        SWT.error(2);
                      }
                      Gdip.Image_GetPalette(l1, l7, i7);
                      ColorPalette localColorPalette = new ColorPalette();
                      Gdip.MoveMemory(localColorPalette, l7, ColorPalette.sizeof);
                      int[] arrayOfInt = new int[localColorPalette.Count];
                      OS.MoveMemory(arrayOfInt, l7 + 8L, arrayOfInt.length * 4);
                      OS.HeapFree(l6, 0, l7);
                      RGB[] arrayOfRGB = new RGB[localColorPalette.Count];
                      localPaletteData = new PaletteData(arrayOfRGB);
                      for (int i10 = 0; i10 < arrayOfInt.length; i10++)
                      {
                        if (((arrayOfInt[i10] >> 24 & 0xFF) == 0) && ((localColorPalette.Flags & 0x1) != 0)) {
                          i6 = i10;
                        }
                        arrayOfRGB[i10] = new RGB((arrayOfInt[i10] & 0xFF0000) >> 16, (arrayOfInt[i10] & 0xFF00) >> 8, (arrayOfInt[i10] & 0xFF) >> 0);
                      }
                      break;
                    case 135173: 
                    case 397319: 
                      localPaletteData = new PaletteData(31744, 992, 31);
                      break;
                    case 135174: 
                      localPaletteData = new PaletteData(63488, 2016, 31);
                      break;
                    case 137224: 
                      localPaletteData = new PaletteData(255, 65280, 16711680);
                      break;
                    case 139273: 
                    case 2498570: 
                      localPaletteData = new PaletteData(65280, 16711680, -16777216);
                    }
                    byte[] arrayOfByte1 = new byte[i3 * i1];
                    byte[] arrayOfByte2 = null;
                    OS.MoveMemory(arrayOfByte1, l4, arrayOfByte1.length);
                    int i8;
                    int i9;
                    switch (localBitmapData.PixelFormat)
                    {
                    case 397319: 
                      arrayOfByte2 = new byte[n * i1];
                      i8 = 1;
                      for (i9 = 0; i8 < arrayOfByte1.length; i9++)
                      {
                        arrayOfByte2[i9] = ((byte)((arrayOfByte1[i8] & 0x80) != 0 ? 'ÿ' : 0));
                        i8 += 2;
                      }
                      break;
                    case 2498570: 
                      arrayOfByte2 = new byte[n * i1];
                      i8 = 3;
                      for (i9 = 0; i8 < arrayOfByte1.length; i9++)
                      {
                        arrayOfByte2[i9] = arrayOfByte1[i8];
                        i8 += 4;
                      }
                    }
                    ImageData localImageData = new ImageData(n, i1, i4, localPaletteData, i5, arrayOfByte1);
                    localImageData.transparentPixel = i6;
                    localImageData.alphaData = arrayOfByte2;
                    init(localImageData);
                  }
                  Gdip.Bitmap_UnlockBits(l1, l2);
                }
                else
                {
                  k = 40;
                }
                Gdip.BitmapData_delete(l2);
              }
            }
          }
        }
        Gdip.Bitmap_delete(l1);
        if ((m == 0) && (this.handle == 0L)) {
          SWT.error(k);
        }
      }
    }
  }
  
  long createDIBFromDDB(long paramLong1, long paramLong2, int paramInt1, int paramInt2)
  {
    int i = OS.GetDeviceCaps(paramLong1, 12);
    int j = OS.GetDeviceCaps(paramLong1, 14);
    int k = i * j;
    int m = k > 8 ? 1 : 0;
    RGB[] arrayOfRGB = null;
    if (m == 0)
    {
      n = 1 << k;
      localObject = new byte[4 * n];
      OS.GetPaletteEntries(this.device.hPalette, 0, n, (byte[])localObject);
      arrayOfRGB = new RGB[n];
      for (int i1 = 0; i1 < n; i1++) {
        arrayOfRGB[i1] = new RGB(localObject[i1] & 0xFF, localObject[(i1 + 1)] & 0xFF, localObject[(i1 + 2)] & 0xFF);
      }
    }
    int n = (OS.IsWinCE) && ((k == 16) || (k == 32)) ? 1 : 0;
    Object localObject = new BITMAPINFOHEADER();
    ((BITMAPINFOHEADER)localObject).biSize = BITMAPINFOHEADER.sizeof;
    ((BITMAPINFOHEADER)localObject).biWidth = paramInt1;
    ((BITMAPINFOHEADER)localObject).biHeight = (-paramInt2);
    ((BITMAPINFOHEADER)localObject).biPlanes = 1;
    ((BITMAPINFOHEADER)localObject).biBitCount = ((short)k);
    if (n != 0) {
      ((BITMAPINFOHEADER)localObject).biCompression = 3;
    } else {
      ((BITMAPINFOHEADER)localObject).biCompression = 0;
    }
    byte[] arrayOfByte;
    if (m != 0) {
      arrayOfByte = new byte[BITMAPINFOHEADER.sizeof + (n != 0 ? 12 : 0)];
    } else {
      arrayOfByte = new byte[BITMAPINFOHEADER.sizeof + arrayOfRGB.length * 4];
    }
    OS.MoveMemory(arrayOfByte, (BITMAPINFOHEADER)localObject, BITMAPINFOHEADER.sizeof);
    int i2 = BITMAPINFOHEADER.sizeof;
    int i3;
    if (m != 0)
    {
      if (n != 0)
      {
        i3 = 0;
        int i4 = 0;
        int i5 = 0;
        switch (k)
        {
        case 16: 
          i3 = 31744;
          i4 = 992;
          i5 = 31;
          arrayOfByte[i2] = ((byte)((i3 & 0xFF) >> 0));
          arrayOfByte[(i2 + 1)] = ((byte)((i3 & 0xFF00) >> 8));
          arrayOfByte[(i2 + 2)] = ((byte)((i3 & 0xFF0000) >> 16));
          arrayOfByte[(i2 + 3)] = ((byte)((i3 & 0xFF000000) >> 24));
          arrayOfByte[(i2 + 4)] = ((byte)((i4 & 0xFF) >> 0));
          arrayOfByte[(i2 + 5)] = ((byte)((i4 & 0xFF00) >> 8));
          arrayOfByte[(i2 + 6)] = ((byte)((i4 & 0xFF0000) >> 16));
          arrayOfByte[(i2 + 7)] = ((byte)((i4 & 0xFF000000) >> 24));
          arrayOfByte[(i2 + 8)] = ((byte)((i5 & 0xFF) >> 0));
          arrayOfByte[(i2 + 9)] = ((byte)((i5 & 0xFF00) >> 8));
          arrayOfByte[(i2 + 10)] = ((byte)((i5 & 0xFF0000) >> 16));
          arrayOfByte[(i2 + 11)] = ((byte)((i5 & 0xFF000000) >> 24));
          break;
        case 32: 
          i3 = 65280;
          i4 = 16711680;
          i5 = -16777216;
          arrayOfByte[i2] = ((byte)((i3 & 0xFF000000) >> 24));
          arrayOfByte[(i2 + 1)] = ((byte)((i3 & 0xFF0000) >> 16));
          arrayOfByte[(i2 + 2)] = ((byte)((i3 & 0xFF00) >> 8));
          arrayOfByte[(i2 + 3)] = ((byte)((i3 & 0xFF) >> 0));
          arrayOfByte[(i2 + 4)] = ((byte)((i4 & 0xFF000000) >> 24));
          arrayOfByte[(i2 + 5)] = ((byte)((i4 & 0xFF0000) >> 16));
          arrayOfByte[(i2 + 6)] = ((byte)((i4 & 0xFF00) >> 8));
          arrayOfByte[(i2 + 7)] = ((byte)((i4 & 0xFF) >> 0));
          arrayOfByte[(i2 + 8)] = ((byte)((i5 & 0xFF000000) >> 24));
          arrayOfByte[(i2 + 9)] = ((byte)((i5 & 0xFF0000) >> 16));
          arrayOfByte[(i2 + 10)] = ((byte)((i5 & 0xFF00) >> 8));
          arrayOfByte[(i2 + 11)] = ((byte)((i5 & 0xFF) >> 0));
          break;
        default: 
          SWT.error(38);
        }
      }
    }
    else {
      for (i3 = 0; i3 < arrayOfRGB.length; i3++)
      {
        arrayOfByte[i2] = ((byte)arrayOfRGB[i3].blue);
        arrayOfByte[(i2 + 1)] = ((byte)arrayOfRGB[i3].green);
        arrayOfByte[(i2 + 2)] = ((byte)arrayOfRGB[i3].red);
        arrayOfByte[(i2 + 3)] = 0;
        i2 += 4;
      }
    }
    long[] arrayOfLong = new long[1];
    long l1 = OS.CreateDIBSection(0L, arrayOfByte, 0, arrayOfLong, 0L, 0);
    if (l1 == 0L) {
      SWT.error(2);
    }
    long l2 = OS.CreateCompatibleDC(paramLong1);
    long l3 = OS.CreateCompatibleDC(paramLong1);
    long l4 = OS.SelectObject(l2, paramLong2);
    long l5 = OS.SelectObject(l3, l1);
    OS.BitBlt(l3, 0, 0, paramInt1, paramInt2, l2, 0, 0, 13369376);
    OS.SelectObject(l2, l4);
    OS.SelectObject(l3, l5);
    OS.DeleteDC(l2);
    OS.DeleteDC(l3);
    return l1;
  }
  
  long[] createGdipImage()
  {
    Object localObject;
    int i8;
    int i10;
    switch (this.type)
    {
    case 0: 
      if ((this.alpha != -1) || (this.alphaData != null) || (this.transparentPixel != -1))
      {
        localObject = new BITMAP();
        OS.GetObject(this.handle, BITMAP.sizeof, (BITMAP)localObject);
        int i = ((BITMAP)localObject).bmWidth;
        int j = ((BITMAP)localObject).bmHeight;
        long l2 = this.device.internal_new_GC(null);
        long l3 = OS.CreateCompatibleDC(l2);
        long l5 = OS.SelectObject(l3, this.handle);
        long l7 = OS.CreateCompatibleDC(l2);
        long l9 = createDIB(i, j, 32);
        if (l9 == 0L) {
          SWT.error(2);
        }
        long l11 = OS.SelectObject(l7, l9);
        BITMAP localBITMAP2 = new BITMAP();
        OS.GetObject(l9, BITMAP.sizeof, localBITMAP2);
        int n = localBITMAP2.bmWidthBytes * localBITMAP2.bmHeight;
        OS.BitBlt(l7, 0, 0, i, j, l3, 0, 0, 13369376);
        int i1 = 0;
        int i2 = 0;
        int i3 = 0;
        int i5;
        int i7;
        if (this.transparentPixel != -1) {
          if (((BITMAP)localObject).bmBitsPixel <= 8)
          {
            byte[] arrayOfByte1 = new byte[4];
            OS.GetDIBColorTable(l3, this.transparentPixel, 1, arrayOfByte1);
            i3 = arrayOfByte1[0];
            i2 = arrayOfByte1[1];
            i1 = arrayOfByte1[2];
          }
          else
          {
            switch (((BITMAP)localObject).bmBitsPixel)
            {
            case 16: 
              int i4 = 31;
              i5 = ImageData.getChannelShift(i4);
              byte[] arrayOfByte3 = ImageData.ANY_TO_EIGHT[ImageData.getChannelWidth(i4, i5)];
              i3 = arrayOfByte3[((this.transparentPixel & i4) >> i5)];
              i7 = 992;
              i8 = ImageData.getChannelShift(i7);
              byte[] arrayOfByte5 = ImageData.ANY_TO_EIGHT[ImageData.getChannelWidth(i7, i8)];
              i2 = arrayOfByte5[((this.transparentPixel & i7) >> i8)];
              i10 = 31744;
              int i11 = ImageData.getChannelShift(i10);
              byte[] arrayOfByte6 = ImageData.ANY_TO_EIGHT[ImageData.getChannelWidth(i10, i11)];
              i1 = arrayOfByte6[((this.transparentPixel & i10) >> i11)];
              break;
            case 24: 
              i3 = (byte)((this.transparentPixel & 0xFF0000) >> 16);
              i2 = (byte)((this.transparentPixel & 0xFF00) >> 8);
              i1 = (byte)(this.transparentPixel & 0xFF);
              break;
            case 32: 
              i3 = (byte)((this.transparentPixel & 0xFF000000) >>> 24);
              i2 = (byte)((this.transparentPixel & 0xFF0000) >> 16);
              i1 = (byte)((this.transparentPixel & 0xFF00) >> 8);
            }
          }
        }
        OS.SelectObject(l3, l5);
        OS.SelectObject(l7, l11);
        OS.DeleteObject(l3);
        OS.DeleteObject(l7);
        byte[] arrayOfByte2 = new byte[n];
        OS.MoveMemory(arrayOfByte2, localBITMAP2.bmBits, n);
        OS.DeleteObject(l9);
        this.device.internal_dispose_GC(l2, null);
        int i6;
        if (this.alpha != -1)
        {
          i5 = 0;
          i6 = 0;
          while (i5 < j)
          {
            for (i7 = 0; i7 < i; i7++)
            {
              arrayOfByte2[(i6 + 3)] = ((byte)this.alpha);
              i6 += 4;
            }
            i5++;
          }
        }
        else if (this.alphaData != null)
        {
          i5 = 0;
          i6 = 0;
          i7 = 0;
          while (i5 < j)
          {
            for (i8 = 0; i8 < i; i8++)
            {
              arrayOfByte2[(i6 + 3)] = this.alphaData[(i7++)];
              i6 += 4;
            }
            i5++;
          }
        }
        else if (this.transparentPixel != -1)
        {
          i5 = 0;
          i6 = 0;
          while (i5 < j)
          {
            for (i7 = 0; i7 < i; i7++)
            {
              if ((arrayOfByte2[i6] == i3) && (arrayOfByte2[(i6 + 1)] == i2) && (arrayOfByte2[(i6 + 2)] == i1)) {
                arrayOfByte2[(i6 + 3)] = 0;
              } else {
                arrayOfByte2[(i6 + 3)] = -1;
              }
              i6 += 4;
            }
            i5++;
          }
        }
        long l16 = OS.GetProcessHeap();
        long l17 = OS.HeapAlloc(l16, 8, arrayOfByte2.length);
        if (l17 == 0L) {
          SWT.error(2);
        }
        OS.MoveMemory(l17, arrayOfByte2, n);
        return new long[] { Gdip.Bitmap_new(i, j, localBITMAP2.bmWidthBytes, 2498570, l17), l17 };
      }
      return new long[] { Gdip.Bitmap_new(this.handle, 0L), 0L };
    case 1: 
      localObject = new ICONINFO();
      if (OS.IsWinCE) {
        GetIconInfo(this, (ICONINFO)localObject);
      } else {
        OS.GetIconInfo(this.handle, (ICONINFO)localObject);
      }
      long l1 = ((ICONINFO)localObject).hbmColor;
      if (l1 == 0L) {
        l1 = ((ICONINFO)localObject).hbmMask;
      }
      BITMAP localBITMAP1 = new BITMAP();
      OS.GetObject(l1, BITMAP.sizeof, localBITMAP1);
      int k = localBITMAP1.bmWidth;
      int m = l1 == ((ICONINFO)localObject).hbmMask ? localBITMAP1.bmHeight / 2 : localBITMAP1.bmHeight;
      long l4 = 0L;
      long l6 = 0L;
      if ((k > m) || (localBITMAP1.bmBitsPixel == 32))
      {
        long l8 = this.device.internal_new_GC(null);
        long l10 = OS.CreateCompatibleDC(l8);
        long l12 = OS.SelectObject(l10, l1);
        long l13 = OS.CreateCompatibleDC(l8);
        long l14 = createDIB(k, m, 32);
        if (l14 == 0L) {
          SWT.error(2);
        }
        long l15 = OS.SelectObject(l13, l14);
        BITMAP localBITMAP3 = new BITMAP();
        OS.GetObject(l14, BITMAP.sizeof, localBITMAP3);
        OS.BitBlt(l13, 0, 0, k, m, l10, 0, l1 == ((ICONINFO)localObject).hbmMask ? m : 0, 13369376);
        OS.SelectObject(l13, l15);
        OS.DeleteObject(l13);
        byte[] arrayOfByte4 = new byte[localBITMAP3.bmWidthBytes * localBITMAP3.bmHeight];
        OS.MoveMemory(arrayOfByte4, localBITMAP3.bmBits, arrayOfByte4.length);
        OS.DeleteObject(l14);
        OS.SelectObject(l10, ((ICONINFO)localObject).hbmMask);
        i8 = 0;
        int i9 = 3;
        while (i8 < m)
        {
          for (i10 = 0; i10 < k; i10++)
          {
            if (arrayOfByte4[i9] == 0) {
              if (OS.GetPixel(l10, i10, i8) != 0) {
                arrayOfByte4[i9] = 0;
              } else {
                arrayOfByte4[i9] = -1;
              }
            }
            i9 += 4;
          }
          i8++;
        }
        OS.SelectObject(l10, l12);
        OS.DeleteObject(l10);
        this.device.internal_dispose_GC(l8, null);
        long l18 = OS.GetProcessHeap();
        l6 = OS.HeapAlloc(l18, 8, arrayOfByte4.length);
        if (l6 == 0L) {
          SWT.error(2);
        }
        OS.MoveMemory(l6, arrayOfByte4, arrayOfByte4.length);
        l4 = Gdip.Bitmap_new(k, m, localBITMAP3.bmWidthBytes, 2498570, l6);
      }
      else
      {
        l4 = Gdip.Bitmap_new(this.handle);
      }
      if (((ICONINFO)localObject).hbmColor != 0L) {
        OS.DeleteObject(((ICONINFO)localObject).hbmColor);
      }
      if (((ICONINFO)localObject).hbmMask != 0L) {
        OS.DeleteObject(((ICONINFO)localObject).hbmMask);
      }
      return new long[] { l4, l6 };
    }
    SWT.error(40);
    return null;
  }
  
  void destroy()
  {
    if (this.memGC != null) {
      this.memGC.dispose();
    }
    if (this.type == 1)
    {
      if (OS.IsWinCE) {
        this.data = null;
      }
      OS.DestroyIcon(this.handle);
    }
    else
    {
      OS.DeleteObject(this.handle);
    }
    this.handle = 0L;
    this.memGC = null;
  }
  
  public boolean equals(Object paramObject)
  {
    if (paramObject == this) {
      return true;
    }
    if (!(paramObject instanceof Image)) {
      return false;
    }
    Image localImage = (Image)paramObject;
    return (this.device == localImage.device) && (this.handle == localImage.handle);
  }
  
  public Color getBackground()
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    if (this.transparentPixel == -1) {
      return null;
    }
    long l1 = this.device.internal_new_GC(null);
    BITMAP localBITMAP = new BITMAP();
    OS.GetObject(this.handle, BITMAP.sizeof, localBITMAP);
    long l2 = OS.CreateCompatibleDC(l1);
    long l3 = OS.SelectObject(l2, this.handle);
    int i = 0;
    int j = 0;
    int k = 0;
    if (localBITMAP.bmBitsPixel <= 8)
    {
      byte[] arrayOfByte;
      if (OS.IsWinCE)
      {
        arrayOfByte = new byte[1];
        OS.MoveMemory(arrayOfByte, localBITMAP.bmBits, 1);
        int m = arrayOfByte[0];
        int n = 255 << 8 - localBITMAP.bmBitsPixel & 0xFF;
        arrayOfByte[0] = ((byte)(this.transparentPixel << 8 - localBITMAP.bmBitsPixel | arrayOfByte[0] & (n ^ 0xFFFFFFFF)));
        OS.MoveMemory(localBITMAP.bmBits, arrayOfByte, 1);
        int i1 = OS.GetPixel(l2, 0, 0);
        arrayOfByte[0] = m;
        OS.MoveMemory(localBITMAP.bmBits, arrayOfByte, 1);
        k = (i1 & 0xFF0000) >> 16;
        j = (i1 & 0xFF00) >> 8;
        i = i1 & 0xFF;
      }
      else
      {
        arrayOfByte = new byte[4];
        OS.GetDIBColorTable(l2, this.transparentPixel, 1, arrayOfByte);
        k = arrayOfByte[0] & 0xFF;
        j = arrayOfByte[1] & 0xFF;
        i = arrayOfByte[2] & 0xFF;
      }
    }
    else
    {
      switch (localBITMAP.bmBitsPixel)
      {
      case 16: 
        k = (this.transparentPixel & 0x1F) << 3;
        j = (this.transparentPixel & 0x3E0) >> 2;
        i = (this.transparentPixel & 0x7C00) >> 7;
        break;
      case 24: 
        k = (this.transparentPixel & 0xFF0000) >> 16;
        j = (this.transparentPixel & 0xFF00) >> 8;
        i = this.transparentPixel & 0xFF;
        break;
      case 32: 
        k = (this.transparentPixel & 0xFF000000) >>> 24;
        j = (this.transparentPixel & 0xFF0000) >> 16;
        i = (this.transparentPixel & 0xFF00) >> 8;
        break;
      default: 
        return null;
      }
    }
    OS.SelectObject(l2, l3);
    OS.DeleteDC(l2);
    this.device.internal_dispose_GC(l1, null);
    return Color.win32_new(this.device, k << 16 | j << 8 | i);
  }
  
  public Rectangle getBounds()
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    if ((this.width != -1) && (this.height != -1)) {
      return new Rectangle(0, 0, this.width, this.height);
    }
    BITMAP localBITMAP;
    switch (this.type)
    {
    case 0: 
      localBITMAP = new BITMAP();
      OS.GetObject(this.handle, BITMAP.sizeof, localBITMAP);
      return new Rectangle(0, 0, this.width = localBITMAP.bmWidth, this.height = localBITMAP.bmHeight);
    case 1: 
      if (OS.IsWinCE) {
        return new Rectangle(0, 0, this.width = this.data.width, this.height = this.data.height);
      }
      ICONINFO localICONINFO = new ICONINFO();
      OS.GetIconInfo(this.handle, localICONINFO);
      long l = localICONINFO.hbmColor;
      if (l == 0L) {
        l = localICONINFO.hbmMask;
      }
      localBITMAP = new BITMAP();
      OS.GetObject(l, BITMAP.sizeof, localBITMAP);
      if (l == localICONINFO.hbmMask) {
        localBITMAP.bmHeight /= 2;
      }
      if (localICONINFO.hbmColor != 0L) {
        OS.DeleteObject(localICONINFO.hbmColor);
      }
      if (localICONINFO.hbmMask != 0L) {
        OS.DeleteObject(localICONINFO.hbmMask);
      }
      return new Rectangle(0, 0, this.width = localBITMAP.bmWidth, this.height = localBITMAP.bmHeight);
    }
    SWT.error(40);
    return null;
  }
  
  public ImageData getImageData()
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    long l1;
    BITMAP localBITMAP;
    int i;
    int j;
    int k;
    Object localObject1;
    Object localObject2;
    int i6;
    int i8;
    int i9;
    Object localObject3;
    switch (this.type)
    {
    case 1: 
      if (OS.IsWinCE) {
        return this.data;
      }
      ICONINFO localICONINFO = new ICONINFO();
      if (OS.IsWinCE) {
        SWT.error(20);
      }
      OS.GetIconInfo(this.handle, localICONINFO);
      l1 = localICONINFO.hbmColor;
      if (l1 == 0L) {
        l1 = localICONINFO.hbmMask;
      }
      localBITMAP = new BITMAP();
      OS.GetObject(l1, BITMAP.sizeof, localBITMAP);
      i = localBITMAP.bmPlanes * localBITMAP.bmBitsPixel;
      j = localBITMAP.bmWidth;
      if (l1 == localICONINFO.hbmMask) {
        localBITMAP.bmHeight /= 2;
      }
      k = localBITMAP.bmHeight;
      int n = 0;
      if (i <= 8) {
        n = 1 << i;
      }
      BITMAPINFOHEADER localBITMAPINFOHEADER1 = new BITMAPINFOHEADER();
      localBITMAPINFOHEADER1.biSize = BITMAPINFOHEADER.sizeof;
      localBITMAPINFOHEADER1.biWidth = j;
      localBITMAPINFOHEADER1.biHeight = (-k);
      localBITMAPINFOHEADER1.biPlanes = 1;
      localBITMAPINFOHEADER1.biBitCount = ((short)i);
      localBITMAPINFOHEADER1.biCompression = 0;
      byte[] arrayOfByte1 = new byte[BITMAPINFOHEADER.sizeof + n * 4];
      OS.MoveMemory(arrayOfByte1, localBITMAPINFOHEADER1, BITMAPINFOHEADER.sizeof);
      long l3 = this.device.internal_new_GC(null);
      long l5 = OS.CreateCompatibleDC(l3);
      long l7 = OS.SelectObject(l5, l1);
      long l9 = 0L;
      if (i <= 8)
      {
        long l11 = this.device.hPalette;
        if (l11 != 0L)
        {
          l9 = OS.SelectPalette(l5, l11, false);
          OS.RealizePalette(l5);
        }
      }
      if (OS.IsWinCE) {
        SWT.error(20);
      }
      OS.GetDIBits(l5, l1, 0, k, null, arrayOfByte1, 0);
      OS.MoveMemory(localBITMAPINFOHEADER1, arrayOfByte1, BITMAPINFOHEADER.sizeof);
      int i3 = localBITMAPINFOHEADER1.biSizeImage;
      byte[] arrayOfByte3 = new byte[i3];
      if (OS.IsWinCE) {
        SWT.error(20);
      }
      OS.GetDIBits(l5, l1, 0, k, arrayOfByte3, arrayOfByte1, 0);
      localObject1 = null;
      int i5;
      if (i <= 8)
      {
        localObject2 = new RGB[n];
        i5 = 40;
        for (i6 = 0; i6 < n; i6++)
        {
          localObject2[i6] = new RGB(arrayOfByte1[(i5 + 2)] & 0xFF, arrayOfByte1[(i5 + 1)] & 0xFF, arrayOfByte1[i5] & 0xFF);
          i5 += 4;
        }
        localObject1 = new PaletteData((RGB[])localObject2);
      }
      else if (i == 16)
      {
        localObject1 = new PaletteData(31744, 992, 31);
      }
      else if (i == 24)
      {
        localObject1 = new PaletteData(255, 65280, 16711680);
      }
      else if (i == 32)
      {
        localObject1 = new PaletteData(65280, 16711680, -16777216);
      }
      else
      {
        SWT.error(38);
      }
      localObject2 = null;
      if (localICONINFO.hbmColor == 0L)
      {
        localObject2 = new byte[i3];
        if (OS.IsWinCE) {
          SWT.error(20);
        }
        OS.GetDIBits(l5, l1, k, k, (byte[])localObject2, arrayOfByte1, 0);
      }
      else
      {
        localBITMAPINFOHEADER1 = new BITMAPINFOHEADER();
        localBITMAPINFOHEADER1.biSize = BITMAPINFOHEADER.sizeof;
        localBITMAPINFOHEADER1.biWidth = j;
        localBITMAPINFOHEADER1.biHeight = (-k);
        localBITMAPINFOHEADER1.biPlanes = 1;
        localBITMAPINFOHEADER1.biBitCount = 1;
        localBITMAPINFOHEADER1.biCompression = 0;
        arrayOfByte1 = new byte[BITMAPINFOHEADER.sizeof + 8];
        OS.MoveMemory(arrayOfByte1, localBITMAPINFOHEADER1, BITMAPINFOHEADER.sizeof);
        i5 = BITMAPINFOHEADER.sizeof;
        arrayOfByte1[(i5 + 4)] = (arrayOfByte1[(i5 + 5)] = arrayOfByte1[(i5 + 6)] = -1);
        arrayOfByte1[(i5 + 7)] = 0;
        OS.SelectObject(l5, localICONINFO.hbmMask);
        if (OS.IsWinCE) {
          SWT.error(20);
        }
        OS.GetDIBits(l5, localICONINFO.hbmMask, 0, k, null, arrayOfByte1, 0);
        OS.MoveMemory(localBITMAPINFOHEADER1, arrayOfByte1, BITMAPINFOHEADER.sizeof);
        i3 = localBITMAPINFOHEADER1.biSizeImage;
        localObject2 = new byte[i3];
        if (OS.IsWinCE) {
          SWT.error(20);
        }
        OS.GetDIBits(l5, localICONINFO.hbmMask, 0, k, (byte[])localObject2, arrayOfByte1, 0);
        for (i6 = 0; i6 < localObject2.length; i6++)
        {
          int tmp837_835 = i6;
          Object tmp837_833 = localObject2;
          tmp837_833[tmp837_835] = ((byte)(tmp837_833[tmp837_835] ^ 0xFFFFFFFF));
        }
        i8 = i3 / k;
        for (i6 = 1; i6 < 128; i6++)
        {
          i9 = ((j + 7) / 8 + (i6 - 1)) / i6 * i6;
          if (i9 == i8) {
            break;
          }
        }
        localObject2 = ImageData.convertPad((byte[])localObject2, j, k, 1, i6, 2);
      }
      OS.SelectObject(l5, l7);
      if (l9 != 0L)
      {
        OS.SelectPalette(l5, l9, false);
        OS.RealizePalette(l5);
      }
      OS.DeleteDC(l5);
      this.device.internal_dispose_GC(l3, null);
      if (localICONINFO.hbmColor != 0L) {
        OS.DeleteObject(localICONINFO.hbmColor);
      }
      if (localICONINFO.hbmMask != 0L) {
        OS.DeleteObject(localICONINFO.hbmMask);
      }
      localObject3 = new ImageData(j, k, i, (PaletteData)localObject1, 4, arrayOfByte3);
      ((ImageData)localObject3).maskData = ((byte[])localObject2);
      ((ImageData)localObject3).maskPad = 2;
      return (ImageData)localObject3;
    case 0: 
      localBITMAP = new BITMAP();
      OS.GetObject(this.handle, BITMAP.sizeof, localBITMAP);
      i = localBITMAP.bmPlanes * localBITMAP.bmBitsPixel;
      j = localBITMAP.bmWidth;
      k = localBITMAP.bmHeight;
      int m = localBITMAP.bmBits != 0L ? 1 : 0;
      l1 = this.device.internal_new_GC(null);
      long l2 = this.handle;
      if ((OS.IsWinCE) && (m == 0))
      {
        int i1 = 0;
        if ((this.memGC != null) && (!this.memGC.isDisposed()))
        {
          this.memGC.flush();
          i1 = 1;
          GCData localGCData = this.memGC.data;
          if (localGCData.hNullBitmap != 0L)
          {
            OS.SelectObject(this.memGC.handle, localGCData.hNullBitmap);
            localGCData.hNullBitmap = 0L;
          }
        }
        l2 = createDIBFromDDB(l1, this.handle, j, k);
        if (i1 != 0)
        {
          long l4 = OS.SelectObject(this.memGC.handle, this.handle);
          this.memGC.data.hNullBitmap = l4;
        }
        m = 1;
      }
      DIBSECTION localDIBSECTION = null;
      if (m != 0)
      {
        localDIBSECTION = new DIBSECTION();
        OS.GetObject(l2, DIBSECTION.sizeof, localDIBSECTION);
      }
      int i2 = 0;
      if (i <= 8) {
        if (m != 0) {
          i2 = localDIBSECTION.biClrUsed;
        } else {
          i2 = 1 << i;
        }
      }
      byte[] arrayOfByte2 = null;
      BITMAPINFOHEADER localBITMAPINFOHEADER2 = null;
      if (m == 0)
      {
        localBITMAPINFOHEADER2 = new BITMAPINFOHEADER();
        localBITMAPINFOHEADER2.biSize = BITMAPINFOHEADER.sizeof;
        localBITMAPINFOHEADER2.biWidth = j;
        localBITMAPINFOHEADER2.biHeight = (-k);
        localBITMAPINFOHEADER2.biPlanes = 1;
        localBITMAPINFOHEADER2.biBitCount = ((short)i);
        localBITMAPINFOHEADER2.biCompression = 0;
        arrayOfByte2 = new byte[BITMAPINFOHEADER.sizeof + i2 * 4];
        OS.MoveMemory(arrayOfByte2, localBITMAPINFOHEADER2, BITMAPINFOHEADER.sizeof);
      }
      long l6 = OS.CreateCompatibleDC(l1);
      long l8 = OS.SelectObject(l6, l2);
      long l10 = 0L;
      if ((m == 0) && (i <= 8))
      {
        long l12 = this.device.hPalette;
        if (l12 != 0L)
        {
          l10 = OS.SelectPalette(l6, l12, false);
          OS.RealizePalette(l6);
        }
      }
      int i4;
      if (m != 0)
      {
        i4 = localDIBSECTION.biSizeImage;
      }
      else
      {
        if (OS.IsWinCE) {
          SWT.error(20);
        }
        OS.GetDIBits(l6, l2, 0, k, null, arrayOfByte2, 0);
        OS.MoveMemory(localBITMAPINFOHEADER2, arrayOfByte2, BITMAPINFOHEADER.sizeof);
        i4 = localBITMAPINFOHEADER2.biSizeImage;
      }
      localObject1 = new byte[i4];
      if (m != 0)
      {
        if ((OS.IsWinCE) && (this.handle != l2)) {
          OS.MoveMemory((byte[])localObject1, localDIBSECTION.bmBits, i4);
        } else {
          OS.MoveMemory((byte[])localObject1, localBITMAP.bmBits, i4);
        }
      }
      else
      {
        if (OS.IsWinCE) {
          SWT.error(20);
        }
        OS.GetDIBits(l6, l2, 0, k, (byte[])localObject1, arrayOfByte2, 0);
      }
      localObject2 = null;
      if (i <= 8)
      {
        localObject3 = new RGB[i2];
        if (m != 0)
        {
          if (OS.IsWinCE)
          {
            i6 = 0;
            i8 = 0;
            i9 = 0;
            byte[] arrayOfByte5 = new byte[1];
            OS.MoveMemory(arrayOfByte5, localBITMAP.bmBits, 1);
            int i10 = arrayOfByte5[0];
            int i11 = 255 << 8 - localBITMAP.bmBitsPixel & 0xFF;
            for (int i12 = 0; i12 < i2; i12++)
            {
              arrayOfByte5[0] = ((byte)(i12 << 8 - localBITMAP.bmBitsPixel | arrayOfByte5[0] & (i11 ^ 0xFFFFFFFF)));
              OS.MoveMemory(localBITMAP.bmBits, arrayOfByte5, 1);
              int i13 = OS.GetPixel(l6, 0, 0);
              i9 = (i13 & 0xFF0000) >> 16;
              i8 = (i13 & 0xFF00) >> 8;
              i6 = i13 & 0xFF;
              localObject3[i12] = new RGB(i6, i8, i9);
            }
            arrayOfByte5[0] = i10;
            OS.MoveMemory(localBITMAP.bmBits, arrayOfByte5, 1);
          }
          else
          {
            byte[] arrayOfByte4 = new byte[i2 * 4];
            OS.GetDIBColorTable(l6, 0, i2, arrayOfByte4);
            i8 = 0;
            for (i9 = 0; i9 < localObject3.length; i9++)
            {
              localObject3[i9] = new RGB(arrayOfByte4[(i8 + 2)] & 0xFF, arrayOfByte4[(i8 + 1)] & 0xFF, arrayOfByte4[i8] & 0xFF);
              i8 += 4;
            }
          }
        }
        else
        {
          int i7 = BITMAPINFOHEADER.sizeof;
          for (i8 = 0; i8 < i2; i8++)
          {
            localObject3[i8] = new RGB(arrayOfByte2[(i7 + 2)] & 0xFF, arrayOfByte2[(i7 + 1)] & 0xFF, arrayOfByte2[i7] & 0xFF);
            i7 += 4;
          }
        }
        localObject2 = new PaletteData((RGB[])localObject3);
      }
      else if (i == 16)
      {
        localObject2 = new PaletteData(31744, 992, 31);
      }
      else if (i == 24)
      {
        localObject2 = new PaletteData(255, 65280, 16711680);
      }
      else if (i == 32)
      {
        localObject2 = new PaletteData(65280, 16711680, -16777216);
      }
      else
      {
        SWT.error(38);
      }
      OS.SelectObject(l6, l8);
      if (l10 != 0L)
      {
        OS.SelectPalette(l6, l10, false);
        OS.RealizePalette(l6);
      }
      if ((OS.IsWinCE) && (l2 != this.handle)) {
        OS.DeleteObject(l2);
      }
      OS.DeleteDC(l6);
      this.device.internal_dispose_GC(l1, null);
      localObject3 = new ImageData(j, k, i, (PaletteData)localObject2, 4, (byte[])localObject1);
      ((ImageData)localObject3).transparentPixel = this.transparentPixel;
      ((ImageData)localObject3).alpha = this.alpha;
      if ((this.alpha == -1) && (this.alphaData != null))
      {
        ((ImageData)localObject3).alphaData = new byte[this.alphaData.length];
        System.arraycopy(this.alphaData, 0, ((ImageData)localObject3).alphaData, 0, this.alphaData.length);
      }
      return (ImageData)localObject3;
    }
    SWT.error(40);
    return null;
  }
  
  public int hashCode()
  {
    return (int)this.handle;
  }
  
  void init(int paramInt1, int paramInt2)
  {
    if ((paramInt1 <= 0) || (paramInt2 <= 0)) {
      SWT.error(5);
    }
    this.type = 0;
    long l1 = this.device.internal_new_GC(null);
    this.handle = OS.CreateCompatibleBitmap(l1, paramInt1, paramInt2);
    if (this.handle == 0L)
    {
      int i = OS.GetDeviceCaps(l1, 12);
      int j = OS.GetDeviceCaps(l1, 14);
      int k = i * j;
      if (k < 16) {
        k = 16;
      }
      this.handle = createDIB(paramInt1, paramInt2, k);
    }
    if (this.handle != 0L)
    {
      long l2 = OS.CreateCompatibleDC(l1);
      long l3 = OS.SelectObject(l2, this.handle);
      OS.PatBlt(l2, 0, 0, paramInt1, paramInt2, 15728673);
      OS.SelectObject(l2, l3);
      OS.DeleteDC(l2);
    }
    this.device.internal_dispose_GC(l1, null);
    if (this.handle == 0L) {
      SWT.error(2, null, this.device.getLastError());
    }
  }
  
  static long createDIB(int paramInt1, int paramInt2, int paramInt3)
  {
    BITMAPINFOHEADER localBITMAPINFOHEADER = new BITMAPINFOHEADER();
    localBITMAPINFOHEADER.biSize = BITMAPINFOHEADER.sizeof;
    localBITMAPINFOHEADER.biWidth = paramInt1;
    localBITMAPINFOHEADER.biHeight = (-paramInt2);
    localBITMAPINFOHEADER.biPlanes = 1;
    localBITMAPINFOHEADER.biBitCount = ((short)paramInt3);
    if (OS.IsWinCE) {
      localBITMAPINFOHEADER.biCompression = 3;
    } else {
      localBITMAPINFOHEADER.biCompression = 0;
    }
    byte[] arrayOfByte = new byte[BITMAPINFOHEADER.sizeof + (OS.IsWinCE ? 12 : 0)];
    OS.MoveMemory(arrayOfByte, localBITMAPINFOHEADER, BITMAPINFOHEADER.sizeof);
    if (OS.IsWinCE)
    {
      int i = 65280;
      int j = 16711680;
      int k = -16777216;
      int m = BITMAPINFOHEADER.sizeof;
      arrayOfByte[m] = ((byte)((i & 0xFF000000) >> 24));
      arrayOfByte[(m + 1)] = ((byte)((i & 0xFF0000) >> 16));
      arrayOfByte[(m + 2)] = ((byte)((i & 0xFF00) >> 8));
      arrayOfByte[(m + 3)] = ((byte)((i & 0xFF) >> 0));
      arrayOfByte[(m + 4)] = ((byte)((j & 0xFF000000) >> 24));
      arrayOfByte[(m + 5)] = ((byte)((j & 0xFF0000) >> 16));
      arrayOfByte[(m + 6)] = ((byte)((j & 0xFF00) >> 8));
      arrayOfByte[(m + 7)] = ((byte)((j & 0xFF) >> 0));
      arrayOfByte[(m + 8)] = ((byte)((k & 0xFF000000) >> 24));
      arrayOfByte[(m + 9)] = ((byte)((k & 0xFF0000) >> 16));
      arrayOfByte[(m + 10)] = ((byte)((k & 0xFF00) >> 8));
      arrayOfByte[(m + 11)] = ((byte)((k & 0xFF) >> 0));
    }
    long[] arrayOfLong = new long[1];
    return OS.CreateDIBSection(0L, arrayOfByte, 0, arrayOfLong, 0L, 0);
  }
  
  static void GetIconInfo(Image paramImage, ICONINFO paramICONINFO)
  {
    long[] arrayOfLong = init(paramImage.device, null, paramImage.data);
    paramICONINFO.hbmColor = arrayOfLong[0];
    paramICONINFO.hbmMask = arrayOfLong[1];
  }
  
  static long[] init(Device paramDevice, Image paramImage, ImageData paramImageData)
  {
    if (((OS.IsWin95) && (paramImageData.depth == 1) && (paramImageData.getTransparencyType() != 2)) || (paramImageData.depth == 2))
    {
      localObject = new ImageData(paramImageData.width, paramImageData.height, 4, paramImageData.palette);
      ImageData.blit(1, paramImageData.data, paramImageData.depth, paramImageData.bytesPerLine, paramImageData.getByteOrder(), 0, 0, paramImageData.width, paramImageData.height, null, null, null, 255, null, 0, 0, 0, ((ImageData)localObject).data, ((ImageData)localObject).depth, ((ImageData)localObject).bytesPerLine, paramImageData.getByteOrder(), 0, 0, ((ImageData)localObject).width, ((ImageData)localObject).height, null, null, null, false, false);
      ((ImageData)localObject).transparentPixel = paramImageData.transparentPixel;
      ((ImageData)localObject).maskPad = paramImageData.maskPad;
      ((ImageData)localObject).maskData = paramImageData.maskData;
      ((ImageData)localObject).alpha = paramImageData.alpha;
      ((ImageData)localObject).alphaData = paramImageData.alphaData;
      paramImageData = (ImageData)localObject;
    }
    if (paramImageData.palette.isDirect)
    {
      localObject = paramImageData.palette;
      i = ((PaletteData)localObject).redMask;
      int j = ((PaletteData)localObject).greenMask;
      int k = ((PaletteData)localObject).blueMask;
      m = paramImageData.depth;
      int n = 1;
      PaletteData localPaletteData2 = null;
      switch (paramImageData.depth)
      {
      case 8: 
        m = 16;
        n = 0;
        localPaletteData2 = new PaletteData(31744, 992, 31);
        break;
      case 16: 
        n = 0;
        if ((i != 31744) || (j != 992) || (k != 31)) {
          localPaletteData2 = new PaletteData(31744, 992, 31);
        }
        break;
      case 24: 
        if ((i != 255) || (j != 65280) || (k != 16711680)) {
          localPaletteData2 = new PaletteData(255, 65280, 16711680);
        }
        break;
      case 32: 
        if ((i != 65280) || (j != 16711680) || (k != -16777216)) {
          localPaletteData2 = new PaletteData(65280, 16711680, -16777216);
        }
        break;
      default: 
        SWT.error(38);
      }
      if (localPaletteData2 != null)
      {
        ImageData localImageData = new ImageData(paramImageData.width, paramImageData.height, m, localPaletteData2);
        ImageData.blit(1, paramImageData.data, paramImageData.depth, paramImageData.bytesPerLine, paramImageData.getByteOrder(), 0, 0, paramImageData.width, paramImageData.height, i, j, k, 255, null, 0, 0, 0, localImageData.data, localImageData.depth, localImageData.bytesPerLine, n, 0, 0, localImageData.width, localImageData.height, localPaletteData2.redMask, localPaletteData2.greenMask, localPaletteData2.blueMask, false, false);
        if (paramImageData.transparentPixel != -1) {
          localImageData.transparentPixel = localPaletteData2.getPixel(((PaletteData)localObject).getRGB(paramImageData.transparentPixel));
        }
        localImageData.maskPad = paramImageData.maskPad;
        localImageData.maskData = paramImageData.maskData;
        localImageData.alpha = paramImageData.alpha;
        localImageData.alphaData = paramImageData.alphaData;
        paramImageData = localImageData;
      }
    }
    Object localObject = paramImageData.palette.getRGBs();
    int i = (OS.IsWinCE) && ((paramImageData.depth == 16) || (paramImageData.depth == 32)) ? 1 : 0;
    BITMAPINFOHEADER localBITMAPINFOHEADER = new BITMAPINFOHEADER();
    localBITMAPINFOHEADER.biSize = BITMAPINFOHEADER.sizeof;
    localBITMAPINFOHEADER.biWidth = paramImageData.width;
    localBITMAPINFOHEADER.biHeight = (-paramImageData.height);
    localBITMAPINFOHEADER.biPlanes = 1;
    localBITMAPINFOHEADER.biBitCount = ((short)paramImageData.depth);
    if (i != 0) {
      localBITMAPINFOHEADER.biCompression = 3;
    } else {
      localBITMAPINFOHEADER.biCompression = 0;
    }
    localBITMAPINFOHEADER.biClrUsed = (localObject == null ? 0 : localObject.length);
    byte[] arrayOfByte1;
    if (paramImageData.palette.isDirect) {
      arrayOfByte1 = new byte[BITMAPINFOHEADER.sizeof + (i != 0 ? 12 : 0)];
    } else {
      arrayOfByte1 = new byte[BITMAPINFOHEADER.sizeof + localObject.length * 4];
    }
    OS.MoveMemory(arrayOfByte1, localBITMAPINFOHEADER, BITMAPINFOHEADER.sizeof);
    int m = BITMAPINFOHEADER.sizeof;
    if (paramImageData.palette.isDirect)
    {
      if (i != 0)
      {
        PaletteData localPaletteData1 = paramImageData.palette;
        int i2 = localPaletteData1.redMask;
        int i3 = localPaletteData1.greenMask;
        int i4 = localPaletteData1.blueMask;
        if (paramImageData.getByteOrder() == 0)
        {
          arrayOfByte1[m] = ((byte)((i2 & 0xFF) >> 0));
          arrayOfByte1[(m + 1)] = ((byte)((i2 & 0xFF00) >> 8));
          arrayOfByte1[(m + 2)] = ((byte)((i2 & 0xFF0000) >> 16));
          arrayOfByte1[(m + 3)] = ((byte)((i2 & 0xFF000000) >> 24));
          arrayOfByte1[(m + 4)] = ((byte)((i3 & 0xFF) >> 0));
          arrayOfByte1[(m + 5)] = ((byte)((i3 & 0xFF00) >> 8));
          arrayOfByte1[(m + 6)] = ((byte)((i3 & 0xFF0000) >> 16));
          arrayOfByte1[(m + 7)] = ((byte)((i3 & 0xFF000000) >> 24));
          arrayOfByte1[(m + 8)] = ((byte)((i4 & 0xFF) >> 0));
          arrayOfByte1[(m + 9)] = ((byte)((i4 & 0xFF00) >> 8));
          arrayOfByte1[(m + 10)] = ((byte)((i4 & 0xFF0000) >> 16));
          arrayOfByte1[(m + 11)] = ((byte)((i4 & 0xFF000000) >> 24));
        }
        else
        {
          arrayOfByte1[m] = ((byte)((i2 & 0xFF000000) >> 24));
          arrayOfByte1[(m + 1)] = ((byte)((i2 & 0xFF0000) >> 16));
          arrayOfByte1[(m + 2)] = ((byte)((i2 & 0xFF00) >> 8));
          arrayOfByte1[(m + 3)] = ((byte)((i2 & 0xFF) >> 0));
          arrayOfByte1[(m + 4)] = ((byte)((i3 & 0xFF000000) >> 24));
          arrayOfByte1[(m + 5)] = ((byte)((i3 & 0xFF0000) >> 16));
          arrayOfByte1[(m + 6)] = ((byte)((i3 & 0xFF00) >> 8));
          arrayOfByte1[(m + 7)] = ((byte)((i3 & 0xFF) >> 0));
          arrayOfByte1[(m + 8)] = ((byte)((i4 & 0xFF000000) >> 24));
          arrayOfByte1[(m + 9)] = ((byte)((i4 & 0xFF0000) >> 16));
          arrayOfByte1[(m + 10)] = ((byte)((i4 & 0xFF00) >> 8));
          arrayOfByte1[(m + 11)] = ((byte)((i4 & 0xFF) >> 0));
        }
      }
    }
    else {
      for (int i1 = 0; i1 < localObject.length; i1++)
      {
        arrayOfByte1[m] = ((byte)localObject[i1].blue);
        arrayOfByte1[(m + 1)] = ((byte)localObject[i1].green);
        arrayOfByte1[(m + 2)] = ((byte)localObject[i1].red);
        arrayOfByte1[(m + 3)] = 0;
        m += 4;
      }
    }
    long[] arrayOfLong1 = new long[1];
    long l1 = OS.CreateDIBSection(0L, arrayOfByte1, 0, arrayOfLong1, 0L, 0);
    if (l1 == 0L) {
      SWT.error(2);
    }
    byte[] arrayOfByte2 = paramImageData.data;
    if ((paramImageData.scanlinePad != 4) && (paramImageData.bytesPerLine % 4 != 0)) {
      arrayOfByte2 = ImageData.convertPad(arrayOfByte2, paramImageData.width, paramImageData.height, paramImageData.depth, paramImageData.scanlinePad, 4);
    }
    OS.MoveMemory(arrayOfLong1[0], arrayOfByte2, arrayOfByte2.length);
    long[] arrayOfLong2 = null;
    if (paramImageData.getTransparencyType() == 2)
    {
      long l2 = paramDevice.internal_new_GC(null);
      long l3 = OS.CreateCompatibleDC(l2);
      OS.SelectObject(l3, l1);
      long l4 = OS.CreateCompatibleBitmap(l2, paramImageData.width, paramImageData.height);
      if (l4 == 0L) {
        SWT.error(2);
      }
      long l5 = OS.CreateCompatibleDC(l2);
      OS.SelectObject(l5, l4);
      OS.BitBlt(l5, 0, 0, paramImageData.width, paramImageData.height, l3, 0, 0, 13369376);
      paramDevice.internal_dispose_GC(l2, null);
      byte[] arrayOfByte3 = ImageData.convertPad(paramImageData.maskData, paramImageData.width, paramImageData.height, 1, paramImageData.maskPad, 2);
      long l6 = OS.CreateBitmap(paramImageData.width, paramImageData.height, 1, 1, arrayOfByte3);
      if (l6 == 0L) {
        SWT.error(2);
      }
      OS.SelectObject(l3, l6);
      OS.PatBlt(l3, 0, 0, paramImageData.width, paramImageData.height, 5570569);
      OS.DeleteDC(l3);
      OS.DeleteDC(l5);
      OS.DeleteObject(l1);
      if (paramImage == null)
      {
        arrayOfLong2 = new long[] { l4, l6 };
      }
      else
      {
        ICONINFO localICONINFO = new ICONINFO();
        localICONINFO.fIcon = true;
        localICONINFO.hbmColor = l4;
        localICONINFO.hbmMask = l6;
        long l7 = OS.CreateIconIndirect(localICONINFO);
        if (l7 == 0L) {
          SWT.error(2);
        }
        OS.DeleteObject(l4);
        OS.DeleteObject(l6);
        paramImage.handle = l7;
        paramImage.type = 1;
        if (OS.IsWinCE) {
          paramImage.data = paramImageData;
        }
      }
    }
    else if (paramImage == null)
    {
      arrayOfLong2 = new long[] { l1 };
    }
    else
    {
      paramImage.handle = l1;
      paramImage.type = 0;
      paramImage.transparentPixel = paramImageData.transparentPixel;
      if (paramImage.transparentPixel == -1)
      {
        paramImage.alpha = paramImageData.alpha;
        if ((paramImageData.alpha == -1) && (paramImageData.alphaData != null))
        {
          int i5 = paramImageData.alphaData.length;
          paramImage.alphaData = new byte[i5];
          System.arraycopy(paramImageData.alphaData, 0, paramImage.alphaData, 0, i5);
        }
      }
    }
    return arrayOfLong2;
  }
  
  static long[] init(Device paramDevice, Image paramImage, ImageData paramImageData1, ImageData paramImageData2)
  {
    int i = 0;
    ImageData localImageData;
    Object localObject1;
    Object localObject2;
    int k;
    if (paramImageData1.palette.isDirect)
    {
      localImageData = new ImageData(paramImageData1.width, paramImageData1.height, paramImageData1.depth, paramImageData1.palette);
    }
    else
    {
      localObject1 = new RGB(0, 0, 0);
      localObject2 = paramImageData1.getRGBs();
      RGB[] arrayOfRGB;
      if (paramImageData1.transparentPixel != -1)
      {
        arrayOfRGB = new RGB[localObject2.length];
        System.arraycopy(localObject2, 0, arrayOfRGB, 0, localObject2.length);
        if (paramImageData1.transparentPixel >= arrayOfRGB.length)
        {
          localObject2 = new RGB[paramImageData1.transparentPixel + 1];
          System.arraycopy(arrayOfRGB, 0, localObject2, 0, arrayOfRGB.length);
          for (k = arrayOfRGB.length; k <= paramImageData1.transparentPixel; k++) {
            localObject2[k] = new RGB(0, 0, 0);
          }
        }
        else
        {
          arrayOfRGB[paramImageData1.transparentPixel] = localObject1;
          localObject2 = arrayOfRGB;
        }
        i = paramImageData1.transparentPixel;
        localImageData = new ImageData(paramImageData1.width, paramImageData1.height, paramImageData1.depth, new PaletteData((RGB[])localObject2));
      }
      else
      {
        while ((i < localObject2.length) && (!localObject2[i].equals(localObject1))) {
          i++;
        }
        if (i == localObject2.length) {
          if (1 << paramImageData1.depth > localObject2.length)
          {
            arrayOfRGB = new RGB[localObject2.length + 1];
            System.arraycopy(localObject2, 0, arrayOfRGB, 0, localObject2.length);
            arrayOfRGB[localObject2.length] = localObject1;
            localObject2 = arrayOfRGB;
          }
          else
          {
            i = -1;
          }
        }
        localImageData = new ImageData(paramImageData1.width, paramImageData1.height, paramImageData1.depth, new PaletteData((RGB[])localObject2));
      }
    }
    if (i == -1)
    {
      System.arraycopy(paramImageData1.data, 0, localImageData.data, 0, localImageData.data.length);
    }
    else
    {
      localObject1 = new int[localImageData.width];
      localObject2 = new int[paramImageData2.width];
      for (int j = 0; j < localImageData.height; j++)
      {
        paramImageData1.getPixels(0, j, localImageData.width, (int[])localObject1, 0);
        paramImageData2.getPixels(0, j, paramImageData2.width, (int[])localObject2, 0);
        for (k = 0; k < localObject1.length; k++) {
          if (localObject2[k] == 0) {
            localObject1[k] = i;
          }
        }
        localImageData.setPixels(0, j, paramImageData1.width, (int[])localObject1, 0);
      }
    }
    localImageData.maskPad = paramImageData2.scanlinePad;
    localImageData.maskData = paramImageData2.data;
    return init(paramDevice, paramImage, localImageData);
  }
  
  void init(ImageData paramImageData)
  {
    if (paramImageData == null) {
      SWT.error(4);
    }
    init(this.device, this, paramImageData);
  }
  
  public long internal_new_GC(GCData paramGCData)
  {
    if (this.handle == 0L) {
      SWT.error(44);
    }
    if ((this.type != 0) || (this.memGC != null)) {
      SWT.error(5);
    }
    long l1 = this.device.internal_new_GC(null);
    long l2 = OS.CreateCompatibleDC(l1);
    this.device.internal_dispose_GC(l1, null);
    if (l2 == 0L) {
      SWT.error(2);
    }
    if (paramGCData != null)
    {
      int i = 100663296;
      if ((paramGCData.style & i) != 0) {
        paramGCData.layout = ((paramGCData.style & 0x4000000) != 0 ? 1 : 0);
      } else {
        paramGCData.style |= 0x2000000;
      }
      paramGCData.device = this.device;
      paramGCData.image = this;
      paramGCData.font = this.device.systemFont;
    }
    return l2;
  }
  
  public void internal_dispose_GC(long paramLong, GCData paramGCData)
  {
    OS.DeleteDC(paramLong);
  }
  
  public boolean isDisposed()
  {
    return this.handle == 0L;
  }
  
  public void setBackground(Color paramColor)
  {
    if (OS.IsWinCE) {
      return;
    }
    if (isDisposed()) {
      SWT.error(44);
    }
    if (paramColor == null) {
      SWT.error(4);
    }
    if (paramColor.isDisposed()) {
      SWT.error(5);
    }
    if (this.transparentPixel == -1) {
      return;
    }
    this.transparentColor = -1;
    long l1 = this.device.internal_new_GC(null);
    BITMAP localBITMAP = new BITMAP();
    OS.GetObject(this.handle, BITMAP.sizeof, localBITMAP);
    long l2 = OS.CreateCompatibleDC(l1);
    OS.SelectObject(l2, this.handle);
    int i = 1 << localBITMAP.bmBitsPixel;
    byte[] arrayOfByte = new byte[i * 4];
    if (OS.IsWinCE) {
      SWT.error(20);
    }
    int j = OS.GetDIBColorTable(l2, 0, i, arrayOfByte);
    int k = this.transparentPixel * 4;
    arrayOfByte[k] = ((byte)paramColor.getBlue());
    arrayOfByte[(k + 1)] = ((byte)paramColor.getGreen());
    arrayOfByte[(k + 2)] = ((byte)paramColor.getRed());
    if (OS.IsWinCE) {
      SWT.error(20);
    }
    OS.SetDIBColorTable(l2, 0, j, arrayOfByte);
    OS.DeleteDC(l2);
    this.device.internal_dispose_GC(l1, null);
  }
  
  public String toString()
  {
    if (isDisposed()) {
      return "Image {*DISPOSED*}";
    }
    return "Image {" + this.handle + "}";
  }
  
  public static Image win32_new(Device paramDevice, int paramInt, long paramLong)
  {
    Image localImage = new Image(paramDevice);
    localImage.type = paramInt;
    localImage.handle = paramLong;
    return localImage;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/graphics/Image.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */