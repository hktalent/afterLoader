package org.eclipse.swt.internal.ole.win32;

public class IConnectionPointContainer
  extends IUnknown
{
  public IConnectionPointContainer(long paramLong)
  {
    super(paramLong);
  }
  
  public int FindConnectionPoint(GUID paramGUID, long[] paramArrayOfLong)
  {
    return COM.VtblCall(4, this.address, paramGUID, paramArrayOfLong);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/internal/ole/win32/IConnectionPointContainer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */