package org.eclipse.swt.internal.mozilla;

public class nsIInputStream
  extends nsISupports
{
  static final int LAST_METHOD_ID = nsISupports.LAST_METHOD_ID + 5;
  static final String NS_IINPUTSTREAM_IID_STR = "fa9c7f6c-61b3-11d4-9877-00c04fa0cf4a";
  static final String NS_IINPUTSTREAM_24_IID_STR = "53cdbc97-c2d7-4e30-b2c3-45b2ee79db18";
  
  public nsIInputStream(long paramLong)
  {
    super(paramLong);
  }
  
  public int Available(int[] paramArrayOfInt)
  {
    if (IsXULRunner24()) {
      return 1;
    }
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 2, getAddress(), paramArrayOfInt);
  }
  
  public int Available(long[] paramArrayOfLong)
  {
    if (!IsXULRunner24()) {
      return 1;
    }
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 2, getAddress(), paramArrayOfLong);
  }
  
  public int Read(byte[] paramArrayOfByte, int paramInt, int[] paramArrayOfInt)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 3, getAddress(), paramArrayOfByte, paramInt, paramArrayOfInt);
  }
  
  static
  {
    IIDStore.RegisterIID(nsIInputStream.class, 0, new nsID("fa9c7f6c-61b3-11d4-9877-00c04fa0cf4a"));
    IIDStore.RegisterIID(nsIInputStream.class, 6, new nsID("53cdbc97-c2d7-4e30-b2c3-45b2ee79db18"));
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/internal/mozilla/nsIInputStream.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */