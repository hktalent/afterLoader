package org.eclipse.swt.internal.mozilla;

public class nsIPrefBranch
  extends nsISupports
{
  static final int LAST_METHOD_ID = nsISupports.LAST_METHOD_ID + (IsXULRunner24() ? 21 : 18);
  static final String NS_IPREFBRANCH_IID_STR = "56c35506-f14b-11d3-99d3-ddbfac2ccf65";
  static final String NS_IPREFBRANCH_10_IID_STR = "e162bfa0-01bd-4e9f-9843-8fb2efcd6d1f";
  static final String NS_IPREFBRANCH_24_IID_STR = "55d25e49-793f-4727-a69f-de8b15f4b985";
  public static final int PREF_INVALID = 0;
  public static final int PREF_STRING = 32;
  public static final int PREF_INT = 64;
  public static final int PREF_BOOL = 128;
  
  public nsIPrefBranch(long paramLong)
  {
    super(paramLong);
  }
  
  public int SetBoolPref(byte[] paramArrayOfByte, int paramInt)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 4, getAddress(), paramArrayOfByte, paramInt);
  }
  
  public int GetIntPref(byte[] paramArrayOfByte, int[] paramArrayOfInt)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + (IsXULRunner24() ? 8 : 7), getAddress(), paramArrayOfByte, paramArrayOfInt);
  }
  
  public int SetIntPref(byte[] paramArrayOfByte, int paramInt)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + (IsXULRunner24() ? 9 : 8), getAddress(), paramArrayOfByte, paramInt);
  }
  
  public int GetComplexValue(byte[] paramArrayOfByte, nsID paramnsID, long[] paramArrayOfLong)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + (IsXULRunner24() ? 10 : 9), getAddress(), paramArrayOfByte, paramnsID, paramArrayOfLong);
  }
  
  public int SetComplexValue(byte[] paramArrayOfByte, nsID paramnsID, long paramLong)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + (IsXULRunner24() ? 11 : 10), getAddress(), paramArrayOfByte, paramnsID, paramLong);
  }
  
  public int ClearUserPref(byte[] paramArrayOfByte)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + (IsXULRunner24() ? 12 : 11), getAddress(), paramArrayOfByte);
  }
  
  static
  {
    IIDStore.RegisterIID(nsIPrefBranch.class, 0, new nsID("56c35506-f14b-11d3-99d3-ddbfac2ccf65"));
    IIDStore.RegisterIID(nsIPrefBranch.class, 5, new nsID("e162bfa0-01bd-4e9f-9843-8fb2efcd6d1f"));
    IIDStore.RegisterIID(nsIPrefBranch.class, 6, new nsID("55d25e49-793f-4727-a69f-de8b15f4b985"));
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/internal/mozilla/nsIPrefBranch.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */