package org.eclipse.swt.internal.ole.win32;

public class IStream
  extends IUnknown
{
  public IStream(long paramLong)
  {
    super(paramLong);
  }
  
  public int Clone(long[] paramArrayOfLong)
  {
    return COM.VtblCall(13, this.address, paramArrayOfLong);
  }
  
  public int Commit(int paramInt)
  {
    return COM.VtblCall(8, this.address, paramInt);
  }
  
  public int Read(long paramLong, int paramInt, int[] paramArrayOfInt)
  {
    return COM.VtblCall(3, this.address, paramLong, paramInt, paramArrayOfInt);
  }
  
  public int Revert()
  {
    return COM.VtblCall(9, this.address);
  }
  
  public int Write(long paramLong, int paramInt, int[] paramArrayOfInt)
  {
    return COM.VtblCall(4, this.address, paramLong, paramInt, paramArrayOfInt);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/internal/ole/win32/IStream.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */