package org.eclipse.swt.internal.mozilla;

import java.lang.reflect.Constructor;
import java.util.HashMap;
import org.eclipse.swt.internal.C;

public abstract class IIDStore
{
  static HashMap<Class<?>, nsID[]> IIDs = new HashMap();
  
  public static nsID GetIID(Class<?> paramClass)
  {
    return GetIID(paramClass, MozillaVersion.GetCurrentVersion());
  }
  
  public static nsID GetIID(Class<?> paramClass, int paramInt)
  {
    return GetIID(paramClass, paramInt, false);
  }
  
  public static nsID GetIID(Class<?> paramClass, int paramInt, boolean paramBoolean)
  {
    if (paramInt <= MozillaVersion.GetLatestVersion())
    {
      nsID[] arrayOfnsID = (nsID[])IIDs.get(paramClass);
      if (arrayOfnsID == null) {
        try
        {
          Class localClass = C.PTR_SIZEOF == 4 ? Integer.TYPE : Long.TYPE;
          paramClass.getConstructor(new Class[] { localClass }).newInstance(new Object[] { Integer.valueOf(0) });
          arrayOfnsID = (nsID[])IIDs.get(paramClass);
        }
        catch (Exception localException) {}
      }
      if (arrayOfnsID != null)
      {
        if (paramBoolean) {
          return arrayOfnsID[paramInt];
        }
        int i = MozillaVersion.GetLatestVersion() + 1;
        if ((paramInt == MozillaVersion.GetCurrentVersion()) && (arrayOfnsID[i] != null)) {
          return arrayOfnsID[i];
        }
        for (int j = paramInt; 0 <= j; j--) {
          if (arrayOfnsID[j] != null)
          {
            if (paramInt == MozillaVersion.GetCurrentVersion()) {
              arrayOfnsID[i] = arrayOfnsID[j];
            }
            return arrayOfnsID[j];
          }
        }
      }
    }
    return null;
  }
  
  protected static void RegisterIID(Class<?> paramClass, int paramInt, nsID paramnsID)
  {
    if (paramInt <= MozillaVersion.GetLatestVersion())
    {
      nsID[] arrayOfnsID = (nsID[])IIDs.get(paramClass);
      if (arrayOfnsID == null)
      {
        arrayOfnsID = new nsID[MozillaVersion.GetLatestVersion() + 2];
        IIDs.put(paramClass, arrayOfnsID);
      }
      arrayOfnsID[paramInt] = paramnsID;
    }
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/internal/mozilla/IIDStore.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */