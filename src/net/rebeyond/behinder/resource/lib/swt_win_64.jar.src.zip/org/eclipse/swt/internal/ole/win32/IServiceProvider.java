package org.eclipse.swt.internal.ole.win32;

public class IServiceProvider
  extends IUnknown
{
  public IServiceProvider(long paramLong)
  {
    super(paramLong);
  }
  
  public int QueryService(GUID paramGUID1, GUID paramGUID2, long[] paramArrayOfLong)
  {
    return COM.VtblCall(3, this.address, paramGUID1, paramGUID2, paramArrayOfLong);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/internal/ole/win32/IServiceProvider.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */