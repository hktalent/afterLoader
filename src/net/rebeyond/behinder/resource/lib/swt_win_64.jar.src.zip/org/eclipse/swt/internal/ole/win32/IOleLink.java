package org.eclipse.swt.internal.ole.win32;

public class IOleLink
  extends IUnknown
{
  public IOleLink(long paramLong)
  {
    super(paramLong);
  }
  
  public int BindIfRunning()
  {
    return COM.VtblCall(10, this.address);
  }
  
  public int GetSourceMoniker(long[] paramArrayOfLong)
  {
    return COM.VtblCall(6, this.address, paramArrayOfLong);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/internal/ole/win32/IOleLink.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */