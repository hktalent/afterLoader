package org.eclipse.swt.internal.mozilla;

public class nsIX509CertValidity
  extends nsISupports
{
  static final int LAST_METHOD_ID = nsISupports.LAST_METHOD_ID + 8;
  static final String NS_IX509CERTVALIDITY_IID_STR = "e701dfd8-1dd1-11b2-a172-ffa6cc6156ad";
  
  public nsIX509CertValidity(long paramLong)
  {
    super(paramLong);
  }
  
  public int GetNotBeforeGMT(long paramLong)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 4, getAddress(), paramLong);
  }
  
  public int GetNotAfterGMT(long paramLong)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 8, getAddress(), paramLong);
  }
  
  static
  {
    IIDStore.RegisterIID(nsIX509CertValidity.class, 0, new nsID("e701dfd8-1dd1-11b2-a172-ffa6cc6156ad"));
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/internal/mozilla/nsIX509CertValidity.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */