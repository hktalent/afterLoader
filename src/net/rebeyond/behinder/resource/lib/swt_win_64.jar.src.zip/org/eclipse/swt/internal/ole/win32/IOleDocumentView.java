package org.eclipse.swt.internal.ole.win32;

import org.eclipse.swt.internal.win32.RECT;

public class IOleDocumentView
  extends IUnknown
{
  public IOleDocumentView(long paramLong)
  {
    super(paramLong);
  }
  
  public int SetInPlaceSite(long paramLong)
  {
    return COM.VtblCall(3, this.address, paramLong);
  }
  
  public int SetRect(RECT paramRECT)
  {
    return COM.VtblCall(6, this.address, paramRECT);
  }
  
  public int Show(int paramInt)
  {
    return COM.VtblCall(9, this.address, paramInt);
  }
  
  public int UIActivate(int paramInt)
  {
    return COM.VtblCall(10, this.address, paramInt);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/internal/ole/win32/IOleDocumentView.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */