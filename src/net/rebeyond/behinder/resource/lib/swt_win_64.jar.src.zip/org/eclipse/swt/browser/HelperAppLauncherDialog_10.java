package org.eclipse.swt.browser;

import org.eclipse.swt.internal.C;
import org.eclipse.swt.internal.mozilla.XPCOM;
import org.eclipse.swt.internal.mozilla.XPCOMObject;
import org.eclipse.swt.internal.mozilla.nsEmbedString;
import org.eclipse.swt.internal.mozilla.nsIHelperAppLauncher_1_8;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Shell;

class HelperAppLauncherDialog_10
  extends HelperAppLauncherDialog_1_9
{
  XPCOMObject supports;
  XPCOMObject helperAppLauncherDialog;
  int refCount = 0;
  
  HelperAppLauncherDialog_10()
  {
    createCOMInterfaces();
  }
  
  int Show(long paramLong1, long paramLong2, int paramInt)
  {
    nsIHelperAppLauncher_1_8 localnsIHelperAppLauncher_1_8 = new nsIHelperAppLauncher_1_8(paramLong1);
    return localnsIHelperAppLauncher_1_8.SaveToDisk(0L, 0);
  }
  
  int PromptForSaveToFile(long paramLong1, long paramLong2, long paramLong3, long paramLong4, int paramInt, long paramLong5)
  {
    int i = XPCOM.strlen_PRUnichar(paramLong3);
    char[] arrayOfChar = new char[i];
    XPCOM.memmove(arrayOfChar, paramLong3, i * 2);
    String str1 = new String(arrayOfChar);
    i = XPCOM.strlen_PRUnichar(paramLong4);
    arrayOfChar = new char[i];
    XPCOM.memmove(arrayOfChar, paramLong4, i * 2);
    String str2 = new String(arrayOfChar);
    Shell localShell = new Shell();
    FileDialog localFileDialog = new FileDialog(localShell, 8192);
    localFileDialog.setFileName(str1);
    localFileDialog.setFilterExtensions(new String[] { str2 });
    String str3 = localFileDialog.open();
    localShell.close();
    if (str3 == null)
    {
      localObject = new nsIHelperAppLauncher_1_8(paramLong1);
      int j = ((nsIHelperAppLauncher_1_8)localObject).Cancel(-2142568446);
      if (j != 0) {
        Mozilla.error(j);
      }
      return -2147467259;
    }
    Object localObject = new nsEmbedString(str3);
    long[] arrayOfLong = new long[1];
    int k = XPCOM.NS_NewLocalFile(((nsEmbedString)localObject).getAddress(), 1, arrayOfLong);
    ((nsEmbedString)localObject).dispose();
    if (k != 0) {
      Mozilla.error(k);
    }
    if (arrayOfLong[0] == 0L) {
      Mozilla.error(-2147467261);
    }
    XPCOM.memmove(paramLong5, arrayOfLong, C.PTR_SIZEOF);
    return 0;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/browser/HelperAppLauncherDialog_10.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */