package org.eclipse.swt.internal.gdip;

import org.eclipse.swt.internal.Library;
import org.eclipse.swt.internal.Platform;

public class Gdip
  extends Platform
{
  public static final float FlatnessDefault = 0.25F;
  public static final int BrushTypeSolidColor = 0;
  public static final int BrushTypeHatchFill = 1;
  public static final int BrushTypeTextureFill = 2;
  public static final int BrushTypePathGradient = 3;
  public static final int BrushTypeLinearGradient = 4;
  public static final int ColorAdjustTypeBitmap = 1;
  public static final int ColorMatrixFlagsDefault = 0;
  public static final int CombineModeReplace = 0;
  public static final int CombineModeIntersect = 1;
  public static final int CombineModeUnion = 2;
  public static final int CombineModeXor = 3;
  public static final int CombineModeExclude = 4;
  public static final int CombineModeComplement = 5;
  public static final int FillModeAlternate = 0;
  public static final int FillModeWinding = 1;
  public static final int DashCapFlat = 0;
  public static final int DashCapRound = 2;
  public static final int DashCapTriangle = 3;
  public static final int DashStyleSolid = 0;
  public static final int DashStyleDash = 1;
  public static final int DashStyleDot = 2;
  public static final int DashStyleDashDot = 3;
  public static final int DashStyleDashDotDot = 4;
  public static final int DashStyleCustom = 5;
  public static final int DriverStringOptionsRealizedAdvance = 4;
  public static final int FontStyleRegular = 0;
  public static final int FontStyleBold = 1;
  public static final int FontStyleItalic = 2;
  public static final int FontStyleBoldItalic = 3;
  public static final int FontStyleUnderline = 4;
  public static final int FontStyleStrikeout = 8;
  public static final int PaletteFlagsHasAlpha = 1;
  public static final int FlushIntentionFlush = 0;
  public static final int FlushIntentionSync = 1;
  public static final int HotkeyPrefixNone = 0;
  public static final int HotkeyPrefixShow = 1;
  public static final int HotkeyPrefixHide = 2;
  public static final int LineJoinMiter = 0;
  public static final int LineJoinBevel = 1;
  public static final int LineJoinRound = 2;
  public static final int LineCapFlat = 0;
  public static final int LineCapSquare = 1;
  public static final int LineCapRound = 2;
  public static final int MatrixOrderPrepend = 0;
  public static final int MatrixOrderAppend = 1;
  public static final int QualityModeDefault = 0;
  public static final int QualityModeLow = 1;
  public static final int QualityModeHigh = 2;
  public static final int InterpolationModeDefault = 0;
  public static final int InterpolationModeLowQuality = 1;
  public static final int InterpolationModeHighQuality = 2;
  public static final int InterpolationModeBilinear = 3;
  public static final int InterpolationModeBicubic = 4;
  public static final int InterpolationModeNearestNeighbor = 5;
  public static final int InterpolationModeHighQualityBilinear = 6;
  public static final int InterpolationModeHighQualityBicubic = 7;
  public static final int PathPointTypeStart = 0;
  public static final int PathPointTypeLine = 1;
  public static final int PathPointTypeBezier = 3;
  public static final int PathPointTypePathTypeMask = 7;
  public static final int PathPointTypePathDashMode = 16;
  public static final int PathPointTypePathMarker = 32;
  public static final int PathPointTypeCloseSubpath = 128;
  public static final int PathPointTypeBezier3 = 3;
  public static final int PixelFormatIndexed = 65536;
  public static final int PixelFormatGDI = 131072;
  public static final int PixelFormatAlpha = 262144;
  public static final int PixelFormatPAlpha = 524288;
  public static final int PixelFormatExtended = 1048576;
  public static final int PixelFormatCanonical = 2097152;
  public static final int PixelFormat1bppIndexed = 196865;
  public static final int PixelFormat4bppIndexed = 197634;
  public static final int PixelFormat8bppIndexed = 198659;
  public static final int PixelFormat16bppGrayScale = 1052676;
  public static final int PixelFormat16bppRGB555 = 135173;
  public static final int PixelFormat16bppRGB565 = 135174;
  public static final int PixelFormat16bppARGB1555 = 397319;
  public static final int PixelFormat24bppRGB = 137224;
  public static final int PixelFormat32bppRGB = 139273;
  public static final int PixelFormat32bppARGB = 2498570;
  public static final int PixelFormat32bppPARGB = 925707;
  public static final int PixelFormat48bppRGB = 1060876;
  public static final int PixelFormat64bppARGB = 3424269;
  public static final int PixelFormat64bppPARGB = 1851406;
  public static final int PixelFormat32bppCMYK = 8207;
  public static final int PixelFormatMax = 16;
  public static final int PixelOffsetModeNone = 3;
  public static final int PixelOffsetModeHalf = 4;
  public static final int SmoothingModeDefault = 0;
  public static final int SmoothingModeHighSpeed = 1;
  public static final int SmoothingModeHighQuality = 2;
  public static final int SmoothingModeNone = 3;
  public static final int SmoothingModeAntiAlias8x4 = 4;
  public static final int SmoothingModeAntiAlias = 4;
  public static final int SmoothingModeAntiAlias8x8 = 5;
  public static final int StringFormatFlagsDirectionRightToLeft = 1;
  public static final int StringFormatFlagsDirectionVertical = 2;
  public static final int StringFormatFlagsNoFitBlackBox = 4;
  public static final int StringFormatFlagsDisplayFormatControl = 32;
  public static final int StringFormatFlagsNoFontFallback = 1024;
  public static final int StringFormatFlagsMeasureTrailingSpaces = 2048;
  public static final int StringFormatFlagsNoWrap = 4096;
  public static final int StringFormatFlagsLineLimit = 8192;
  public static final int StringFormatFlagsNoClip = 16384;
  public static final int TextRenderingHintSystemDefault = 0;
  public static final int TextRenderingHintSingleBitPerPixelGridFit = 1;
  public static final int TextRenderingHintSingleBitPerPixel = 2;
  public static final int TextRenderingHintAntiAliasGridFit = 3;
  public static final int TextRenderingHintAntiAlias = 4;
  public static final int TextRenderingHintClearTypeGridFit = 5;
  public static final int UnitPixel = 2;
  public static final int WrapModeTile = 0;
  public static final int WrapModeTileFlipX = 1;
  public static final int WrapModeTileFlipY = 2;
  public static final int WrapModeTileFlipXY = 3;
  public static final int WrapModeClamp = 4;
  
  public static final native int ColorPalette_sizeof();
  
  public static final native int GdiplusStartupInput_sizeof();
  
  public static final native int GdiplusStartup(long[] paramArrayOfLong, GdiplusStartupInput paramGdiplusStartupInput, long paramLong);
  
  public static final native void GdiplusShutdown(long paramLong);
  
  public static final native long Bitmap_new(long paramLong1, long paramLong2);
  
  public static final native long Bitmap_new(long paramLong);
  
  public static final native long Bitmap_new(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong);
  
  public static final native long Bitmap_new(char[] paramArrayOfChar, boolean paramBoolean);
  
  public static final native void Bitmap_delete(long paramLong);
  
  public static final native int Bitmap_GetHBITMAP(long paramLong1, long paramLong2, long[] paramArrayOfLong);
  
  public static final native int Bitmap_GetHICON(long paramLong, long[] paramArrayOfLong);
  
  public static final native long BitmapData_new();
  
  public static final native void BitmapData_delete(long paramLong);
  
  public static final native int Bitmap_LockBits(long paramLong1, long paramLong2, int paramInt1, int paramInt2, long paramLong3);
  
  public static final native int Bitmap_UnlockBits(long paramLong1, long paramLong2);
  
  public static final native long Brush_Clone(long paramLong);
  
  public static final native int Brush_GetType(long paramLong);
  
  public static final native long Color_new(int paramInt);
  
  public static final native void Color_delete(long paramLong);
  
  public static final native long PrivateFontCollection_new();
  
  public static final native void PrivateFontCollection_delete(long paramLong);
  
  public static final native int PrivateFontCollection_AddFontFile(long paramLong, char[] paramArrayOfChar);
  
  public static final native long Font_new(long paramLong1, long paramLong2);
  
  public static final native long Font_new(long paramLong, float paramFloat, int paramInt1, int paramInt2);
  
  public static final native long Font_new(char[] paramArrayOfChar, float paramFloat, int paramInt1, int paramInt2, long paramLong);
  
  public static final native void Font_delete(long paramLong);
  
  public static final native int Font_GetFamily(long paramLong1, long paramLong2);
  
  public static final native float Font_GetSize(long paramLong);
  
  public static final native int Font_GetStyle(long paramLong);
  
  public static final native int Font_GetLogFontW(long paramLong1, long paramLong2, long paramLong3);
  
  public static final native boolean Font_IsAvailable(long paramLong);
  
  public static final native long FontFamily_new();
  
  public static final native long FontFamily_new(char[] paramArrayOfChar, long paramLong);
  
  public static final native void FontFamily_delete(long paramLong);
  
  public static final native int FontFamily_GetFamilyName(long paramLong, char[] paramArrayOfChar, char paramChar);
  
  public static final native boolean FontFamily_IsAvailable(long paramLong);
  
  public static final native long Graphics_new(long paramLong);
  
  public static final native void Graphics_delete(long paramLong);
  
  public static final native int Graphics_DrawArc(long paramLong1, long paramLong2, int paramInt1, int paramInt2, int paramInt3, int paramInt4, float paramFloat1, float paramFloat2);
  
  public static final native int Graphics_DrawDriverString(long paramLong1, long paramLong2, int paramInt1, long paramLong3, long paramLong4, PointF paramPointF, int paramInt2, long paramLong5);
  
  public static final native int Graphics_DrawDriverString(long paramLong1, long paramLong2, int paramInt1, long paramLong3, long paramLong4, float[] paramArrayOfFloat, int paramInt2, long paramLong5);
  
  public static final native int Graphics_DrawEllipse(long paramLong1, long paramLong2, int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  public static final native int Graphics_DrawImage(long paramLong1, long paramLong2, int paramInt1, int paramInt2);
  
  public static final native int Graphics_DrawImage(long paramLong1, long paramLong2, Rect paramRect, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, long paramLong3, long paramLong4, long paramLong5);
  
  public static final native int Graphics_DrawLine(long paramLong1, long paramLong2, int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  public static final native int Graphics_DrawLines(long paramLong1, long paramLong2, int[] paramArrayOfInt, int paramInt);
  
  public static final native int Graphics_DrawPath(long paramLong1, long paramLong2, long paramLong3);
  
  public static final native int Graphics_DrawPolygon(long paramLong1, long paramLong2, int[] paramArrayOfInt, int paramInt);
  
  public static final native int Graphics_DrawRectangle(long paramLong1, long paramLong2, int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  public static final native int Graphics_DrawString(long paramLong1, char[] paramArrayOfChar, int paramInt, long paramLong2, PointF paramPointF, long paramLong3);
  
  public static final native int Graphics_DrawString(long paramLong1, char[] paramArrayOfChar, int paramInt, long paramLong2, PointF paramPointF, long paramLong3, long paramLong4);
  
  public static final native int Graphics_FillEllipse(long paramLong1, long paramLong2, int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  public static final native int Graphics_FillPath(long paramLong1, long paramLong2, long paramLong3);
  
  public static final native void Graphics_Flush(long paramLong, int paramInt);
  
  public static final native int Graphics_FillPie(long paramLong1, long paramLong2, int paramInt1, int paramInt2, int paramInt3, int paramInt4, float paramFloat1, float paramFloat2);
  
  public static final native int Graphics_FillPolygon(long paramLong1, long paramLong2, int[] paramArrayOfInt, int paramInt1, int paramInt2);
  
  public static final native int Graphics_FillRectangle(long paramLong1, long paramLong2, int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  public static final native int Graphics_GetClipBounds(long paramLong, RectF paramRectF);
  
  public static final native int Graphics_GetClipBounds(long paramLong, Rect paramRect);
  
  public static final native int Graphics_GetClip(long paramLong1, long paramLong2);
  
  public static final native long Graphics_GetHDC(long paramLong);
  
  public static final native void Graphics_ReleaseHDC(long paramLong1, long paramLong2);
  
  public static final native int Graphics_GetInterpolationMode(long paramLong);
  
  public static final native int Graphics_GetSmoothingMode(long paramLong);
  
  public static final native int Graphics_GetTextRenderingHint(long paramLong);
  
  public static final native int Graphics_GetTransform(long paramLong1, long paramLong2);
  
  public static final native int Graphics_GetVisibleClipBounds(long paramLong, Rect paramRect);
  
  public static final native int Graphics_MeasureDriverString(long paramLong1, long paramLong2, int paramInt1, long paramLong3, float[] paramArrayOfFloat, int paramInt2, long paramLong4, RectF paramRectF);
  
  public static final native int Graphics_MeasureString(long paramLong1, char[] paramArrayOfChar, int paramInt, long paramLong2, PointF paramPointF, RectF paramRectF);
  
  public static final native int Graphics_MeasureString(long paramLong1, char[] paramArrayOfChar, int paramInt, long paramLong2, PointF paramPointF, long paramLong3, RectF paramRectF);
  
  public static final native int Graphics_ResetClip(long paramLong);
  
  public static final native int Graphics_Restore(long paramLong, int paramInt);
  
  public static final native int Graphics_Save(long paramLong);
  
  public static final native int Graphics_ScaleTransform(long paramLong, float paramFloat1, float paramFloat2, int paramInt);
  
  public static final native int Graphics_SetClip(long paramLong1, long paramLong2, int paramInt);
  
  public static final native int Graphics_SetClip(long paramLong, Rect paramRect, int paramInt);
  
  public static final native int Graphics_SetClipPath(long paramLong1, long paramLong2);
  
  public static final native int Graphics_SetClipPath(long paramLong1, long paramLong2, int paramInt);
  
  public static final native int Graphics_SetCompositingQuality(long paramLong, int paramInt);
  
  public static final native int Graphics_SetPageUnit(long paramLong, int paramInt);
  
  public static final native int Graphics_SetPixelOffsetMode(long paramLong, int paramInt);
  
  public static final native int Graphics_SetSmoothingMode(long paramLong, int paramInt);
  
  public static final native int Graphics_SetTransform(long paramLong1, long paramLong2);
  
  public static final native int Graphics_SetInterpolationMode(long paramLong, int paramInt);
  
  public static final native int Graphics_SetTextRenderingHint(long paramLong, int paramInt);
  
  public static final native int Graphics_TranslateTransform(long paramLong, float paramFloat1, float paramFloat2, int paramInt);
  
  public static final native long GraphicsPath_new(int paramInt);
  
  public static final native long GraphicsPath_new(int[] paramArrayOfInt, byte[] paramArrayOfByte, int paramInt1, int paramInt2);
  
  public static final native void GraphicsPath_delete(long paramLong);
  
  public static final native int GraphicsPath_AddArc(long paramLong, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6);
  
  public static final native int GraphicsPath_AddBezier(long paramLong, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8);
  
  public static final native int GraphicsPath_AddLine(long paramLong, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4);
  
  public static final native int GraphicsPath_AddPath(long paramLong1, long paramLong2, boolean paramBoolean);
  
  public static final native int GraphicsPath_AddRectangle(long paramLong, RectF paramRectF);
  
  public static final native int GraphicsPath_AddString(long paramLong1, char[] paramArrayOfChar, int paramInt1, long paramLong2, int paramInt2, float paramFloat, PointF paramPointF, long paramLong3);
  
  public static final native int GraphicsPath_CloseFigure(long paramLong);
  
  public static final native long GraphicsPath_Clone(long paramLong);
  
  public static final native int GraphicsPath_Flatten(long paramLong1, long paramLong2, float paramFloat);
  
  public static final native int GraphicsPath_GetBounds(long paramLong1, RectF paramRectF, long paramLong2, long paramLong3);
  
  public static final native int GraphicsPath_GetLastPoint(long paramLong, PointF paramPointF);
  
  public static final native int GraphicsPath_GetPathPoints(long paramLong, float[] paramArrayOfFloat, int paramInt);
  
  public static final native int GraphicsPath_GetPathTypes(long paramLong, byte[] paramArrayOfByte, int paramInt);
  
  public static final native int GraphicsPath_GetPointCount(long paramLong);
  
  public static final native boolean GraphicsPath_IsOutlineVisible(long paramLong1, float paramFloat1, float paramFloat2, long paramLong2, long paramLong3);
  
  public static final native boolean GraphicsPath_IsVisible(long paramLong1, float paramFloat1, float paramFloat2, long paramLong2);
  
  public static final native int GraphicsPath_SetFillMode(long paramLong, int paramInt);
  
  public static final native int GraphicsPath_StartFigure(long paramLong);
  
  public static final native int GraphicsPath_Transform(long paramLong1, long paramLong2);
  
  public static final native long HatchBrush_new(int paramInt, long paramLong1, long paramLong2);
  
  public static final native int Image_GetLastStatus(long paramLong);
  
  public static final native int Image_GetPixelFormat(long paramLong);
  
  public static final native int Image_GetWidth(long paramLong);
  
  public static final native int Image_GetHeight(long paramLong);
  
  public static final native int Image_GetPalette(long paramLong1, long paramLong2, int paramInt);
  
  public static final native int Image_GetPaletteSize(long paramLong);
  
  public static final native long ImageAttributes_new();
  
  public static final native void ImageAttributes_delete(long paramLong);
  
  public static final native int ImageAttributes_SetWrapMode(long paramLong, int paramInt);
  
  public static final native int ImageAttributes_SetColorMatrix(long paramLong, float[] paramArrayOfFloat, int paramInt1, int paramInt2);
  
  public static final native void HatchBrush_delete(long paramLong);
  
  public static final native long LinearGradientBrush_new(PointF paramPointF1, PointF paramPointF2, long paramLong1, long paramLong2);
  
  public static final native void LinearGradientBrush_delete(long paramLong);
  
  public static final native int LinearGradientBrush_SetInterpolationColors(long paramLong, long[] paramArrayOfLong, float[] paramArrayOfFloat, int paramInt);
  
  public static final native int LinearGradientBrush_SetWrapMode(long paramLong, int paramInt);
  
  public static final native int LinearGradientBrush_ResetTransform(long paramLong);
  
  public static final native int LinearGradientBrush_ScaleTransform(long paramLong, float paramFloat1, float paramFloat2, int paramInt);
  
  public static final native int LinearGradientBrush_TranslateTransform(long paramLong, float paramFloat1, float paramFloat2, int paramInt);
  
  public static final native long Matrix_new(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6);
  
  public static final native void Matrix_delete(long paramLong);
  
  public static final native int Matrix_GetElements(long paramLong, float[] paramArrayOfFloat);
  
  public static final native int Matrix_Invert(long paramLong);
  
  public static final native boolean Matrix_IsIdentity(long paramLong);
  
  public static final native int Matrix_Multiply(long paramLong1, long paramLong2, int paramInt);
  
  public static final native int Matrix_Rotate(long paramLong, float paramFloat, int paramInt);
  
  public static final native int Matrix_Scale(long paramLong, float paramFloat1, float paramFloat2, int paramInt);
  
  public static final native int Matrix_Shear(long paramLong, float paramFloat1, float paramFloat2, int paramInt);
  
  public static final native int Matrix_TransformPoints(long paramLong, PointF paramPointF, int paramInt);
  
  public static final native int Matrix_TransformPoints(long paramLong, float[] paramArrayOfFloat, int paramInt);
  
  public static final native int Matrix_TransformVectors(long paramLong, PointF paramPointF, int paramInt);
  
  public static final native int Matrix_Translate(long paramLong, float paramFloat1, float paramFloat2, int paramInt);
  
  public static final native int Matrix_SetElements(long paramLong, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6);
  
  public static final native void MoveMemory(ColorPalette paramColorPalette, long paramLong, int paramInt);
  
  public static final native void MoveMemory(BitmapData paramBitmapData, long paramLong);
  
  public static final native long PathGradientBrush_new(long paramLong);
  
  public static final native void PathGradientBrush_delete(long paramLong);
  
  public static final native int PathGradientBrush_SetCenterColor(long paramLong1, long paramLong2);
  
  public static final native int PathGradientBrush_SetCenterPoint(long paramLong, PointF paramPointF);
  
  public static final native int PathGradientBrush_SetInterpolationColors(long paramLong, long[] paramArrayOfLong, float[] paramArrayOfFloat, int paramInt);
  
  public static final native int PathGradientBrush_SetSurroundColors(long paramLong, long[] paramArrayOfLong, int[] paramArrayOfInt);
  
  public static final native int PathGradientBrush_SetGraphicsPath(long paramLong1, long paramLong2);
  
  public static final native int PathGradientBrush_SetWrapMode(long paramLong, int paramInt);
  
  public static final native long Pen_new(long paramLong, float paramFloat);
  
  public static final native void Pen_delete(long paramLong);
  
  public static final native long Pen_GetBrush(long paramLong);
  
  public static final native int Pen_SetBrush(long paramLong1, long paramLong2);
  
  public static final native int Pen_SetDashOffset(long paramLong, float paramFloat);
  
  public static final native int Pen_SetDashPattern(long paramLong, float[] paramArrayOfFloat, int paramInt);
  
  public static final native int Pen_SetDashStyle(long paramLong, int paramInt);
  
  public static final native int Pen_SetLineCap(long paramLong, int paramInt1, int paramInt2, int paramInt3);
  
  public static final native int Pen_SetLineJoin(long paramLong, int paramInt);
  
  public static final native int Pen_SetMiterLimit(long paramLong, float paramFloat);
  
  public static final native int Pen_SetWidth(long paramLong, float paramFloat);
  
  public static final native long Point_new(int paramInt1, int paramInt2);
  
  public static final native void Point_delete(long paramLong);
  
  public static final native long Region_new(long paramLong);
  
  public static final native long Region_newGraphicsPath(long paramLong);
  
  public static final native long Region_new();
  
  public static final native void Region_delete(long paramLong);
  
  public static final native long Region_GetHRGN(long paramLong1, long paramLong2);
  
  public static final native boolean Region_IsInfinite(long paramLong1, long paramLong2);
  
  public static final native long SolidBrush_new(long paramLong);
  
  public static final native void SolidBrush_delete(long paramLong);
  
  public static final native void StringFormat_delete(long paramLong);
  
  public static final native long StringFormat_Clone(long paramLong);
  
  public static final native long StringFormat_GenericDefault();
  
  public static final native long StringFormat_GenericTypographic();
  
  public static final native int StringFormat_GetFormatFlags(long paramLong);
  
  public static final native int StringFormat_SetHotkeyPrefix(long paramLong, int paramInt);
  
  public static final native int StringFormat_SetFormatFlags(long paramLong, int paramInt);
  
  public static final native int StringFormat_SetTabStops(long paramLong, float paramFloat, int paramInt, float[] paramArrayOfFloat);
  
  public static final native long TextureBrush_new(long paramLong, int paramInt, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4);
  
  public static final native void TextureBrush_delete(long paramLong);
  
  public static final native int TextureBrush_SetTransform(long paramLong1, long paramLong2);
  
  public static final native int TextureBrush_ResetTransform(long paramLong);
  
  public static final native int TextureBrush_ScaleTransform(long paramLong, float paramFloat1, float paramFloat2, int paramInt);
  
  public static final native int TextureBrush_TranslateTransform(long paramLong, float paramFloat1, float paramFloat2, int paramInt);
  
  static
  {
    Library.loadLibrary("swt-gdip");
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/internal/gdip/Gdip.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */