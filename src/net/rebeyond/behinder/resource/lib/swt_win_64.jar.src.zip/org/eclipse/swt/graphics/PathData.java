package org.eclipse.swt.graphics;

public final class PathData
{
  public byte[] types;
  public float[] points;
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/graphics/PathData.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */