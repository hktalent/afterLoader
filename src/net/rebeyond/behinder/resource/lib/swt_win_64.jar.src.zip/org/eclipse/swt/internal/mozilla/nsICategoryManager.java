package org.eclipse.swt.internal.mozilla;

public class nsICategoryManager
  extends nsISupports
{
  static final int LAST_METHOD_ID = nsISupports.LAST_METHOD_ID + 6;
  static final String NS_ICATEGORYMANAGER_IID_STR = "3275b2cd-af6d-429a-80d7-f0c5120342ac";
  
  public nsICategoryManager(long paramLong)
  {
    super(paramLong);
  }
  
  public int GetCategoryEntry(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, long[] paramArrayOfLong)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 1, getAddress(), paramArrayOfByte1, paramArrayOfByte2, paramArrayOfLong);
  }
  
  public int AddCategoryEntry(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3, int paramInt1, int paramInt2, long[] paramArrayOfLong)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 2, getAddress(), paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte3, paramInt1, paramInt2, paramArrayOfLong);
  }
  
  static
  {
    IIDStore.RegisterIID(nsICategoryManager.class, 0, new nsID("3275b2cd-af6d-429a-80d7-f0c5120342ac"));
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/internal/mozilla/nsICategoryManager.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */