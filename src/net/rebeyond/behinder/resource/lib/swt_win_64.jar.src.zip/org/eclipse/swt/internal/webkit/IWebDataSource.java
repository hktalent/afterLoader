package org.eclipse.swt.internal.webkit;

import org.eclipse.swt.internal.ole.win32.COM;
import org.eclipse.swt.internal.ole.win32.IUnknown;

public class IWebDataSource
  extends IUnknown
{
  public IWebDataSource(long paramLong)
  {
    super(paramLong);
  }
  
  public int representation(long[] paramArrayOfLong)
  {
    return COM.VtblCall(5, getAddress(), paramArrayOfLong);
  }
  
  public int webFrame(long[] paramArrayOfLong)
  {
    return COM.VtblCall(6, getAddress(), paramArrayOfLong);
  }
  
  public int request(long[] paramArrayOfLong)
  {
    return COM.VtblCall(8, getAddress(), paramArrayOfLong);
  }
  
  public int pageTitle(long[] paramArrayOfLong)
  {
    return COM.VtblCall(12, getAddress(), paramArrayOfLong);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/internal/webkit/IWebDataSource.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */