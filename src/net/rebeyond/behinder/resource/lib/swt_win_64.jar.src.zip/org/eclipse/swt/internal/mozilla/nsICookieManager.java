package org.eclipse.swt.internal.mozilla;

public class nsICookieManager
  extends nsISupports
{
  static final int LAST_METHOD_ID = nsISupports.LAST_METHOD_ID + 3;
  static final String NS_ICOOKIEMANAGER_IID_STR = "aaab6710-0f2c-11d5-a53b-0010a401eb10";
  
  public nsICookieManager(long paramLong)
  {
    super(paramLong);
  }
  
  public int GetEnumerator(long[] paramArrayOfLong)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 2, getAddress(), paramArrayOfLong);
  }
  
  public int Remove(long paramLong1, long paramLong2, long paramLong3, int paramInt)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 3, getAddress(), paramLong1, paramLong2, paramLong3, paramInt);
  }
  
  static
  {
    IIDStore.RegisterIID(nsICookieManager.class, 0, new nsID("aaab6710-0f2c-11d5-a53b-0010a401eb10"));
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/internal/mozilla/nsICookieManager.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */