package org.eclipse.swt.browser;

import java.util.Hashtable;
import org.eclipse.swt.SWT;
import org.eclipse.swt.SWTException;
import org.eclipse.swt.internal.C;
import org.eclipse.swt.internal.ole.win32.COM;
import org.eclipse.swt.internal.ole.win32.COMObject;
import org.eclipse.swt.internal.ole.win32.DISPPARAMS;
import org.eclipse.swt.internal.ole.win32.GUID;
import org.eclipse.swt.internal.ole.win32.IDispatch;
import org.eclipse.swt.internal.ole.win32.IDispatchEx;
import org.eclipse.swt.internal.ole.win32.TYPEATTR;
import org.eclipse.swt.internal.ole.win32.VARIANT;
import org.eclipse.swt.internal.win32.DOCHOSTUIINFO;
import org.eclipse.swt.internal.win32.MSG;
import org.eclipse.swt.internal.win32.OS;
import org.eclipse.swt.internal.win32.POINT;
import org.eclipse.swt.internal.win32.TCHAR;
import org.eclipse.swt.ole.win32.OleAutomation;
import org.eclipse.swt.ole.win32.OleControlSite;
import org.eclipse.swt.ole.win32.OleFrame;
import org.eclipse.swt.ole.win32.Variant;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.Shell;

class WebSite
  extends OleControlSite
{
  COMObject iDocHostUIHandler;
  COMObject iDocHostShowUI;
  COMObject iServiceProvider;
  COMObject iInternetSecurityManager;
  COMObject iOleCommandTarget;
  COMObject iAuthenticate;
  COMObject iDispatch;
  boolean ignoreNextMessage;
  boolean ignoreAllMessages;
  Boolean canExecuteApplets;
  static final int OLECMDID_SHOWSCRIPTERROR = 40;
  static final short[] ACCENTS = { 126, 96, 39, 94, 34 };
  static final String CONSUME_KEY = "org.eclipse.swt.OleFrame.ConsumeKey";
  
  public WebSite(Composite paramComposite, int paramInt, String paramString)
  {
    super(paramComposite, paramInt, paramString);
  }
  
  protected void createCOMInterfaces()
  {
    super.createCOMInterfaces();
    this.iDocHostUIHandler = new COMObject(new int[] { 2, 0, 0, 4, 1, 5, 0, 0, 1, 1, 1, 3, 3, 2, 2, 1, 3, 2 })
    {
      public long method0(long[] paramAnonymousArrayOfLong)
      {
        return WebSite.this.QueryInterface(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method1(long[] paramAnonymousArrayOfLong)
      {
        return WebSite.this.AddRef();
      }
      
      public long method2(long[] paramAnonymousArrayOfLong)
      {
        return WebSite.this.Release();
      }
      
      public long method3(long[] paramAnonymousArrayOfLong)
      {
        return WebSite.this.ShowContextMenu((int)paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2], paramAnonymousArrayOfLong[3]);
      }
      
      public long method4(long[] paramAnonymousArrayOfLong)
      {
        return WebSite.this.GetHostInfo(paramAnonymousArrayOfLong[0]);
      }
      
      public long method5(long[] paramAnonymousArrayOfLong)
      {
        return WebSite.this.ShowUI((int)paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2], paramAnonymousArrayOfLong[3], paramAnonymousArrayOfLong[4]);
      }
      
      public long method6(long[] paramAnonymousArrayOfLong)
      {
        return WebSite.this.HideUI();
      }
      
      public long method7(long[] paramAnonymousArrayOfLong)
      {
        return WebSite.this.UpdateUI();
      }
      
      public long method8(long[] paramAnonymousArrayOfLong)
      {
        return WebSite.this.EnableModeless((int)paramAnonymousArrayOfLong[0]);
      }
      
      public long method9(long[] paramAnonymousArrayOfLong)
      {
        return WebSite.this.OnDocWindowActivate((int)paramAnonymousArrayOfLong[0]);
      }
      
      public long method10(long[] paramAnonymousArrayOfLong)
      {
        return WebSite.this.OnFrameWindowActivate((int)paramAnonymousArrayOfLong[0]);
      }
      
      public long method11(long[] paramAnonymousArrayOfLong)
      {
        return WebSite.this.ResizeBorder(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], (int)paramAnonymousArrayOfLong[2]);
      }
      
      public long method12(long[] paramAnonymousArrayOfLong)
      {
        return WebSite.this.TranslateAccelerator(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], (int)paramAnonymousArrayOfLong[2]);
      }
      
      public long method13(long[] paramAnonymousArrayOfLong)
      {
        return WebSite.this.GetOptionKeyPath(paramAnonymousArrayOfLong[0], (int)paramAnonymousArrayOfLong[1]);
      }
      
      public long method14(long[] paramAnonymousArrayOfLong)
      {
        return WebSite.this.GetDropTarget(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method15(long[] paramAnonymousArrayOfLong)
      {
        return WebSite.this.GetExternal(paramAnonymousArrayOfLong[0]);
      }
      
      public long method16(long[] paramAnonymousArrayOfLong)
      {
        return WebSite.this.TranslateUrl((int)paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2]);
      }
      
      public long method17(long[] paramAnonymousArrayOfLong)
      {
        return WebSite.this.FilterDataObject(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
    };
    this.iDocHostShowUI = new COMObject(new int[] { 2, 0, 0, 7, C.PTR_SIZEOF == 4 ? 7 : 6 })
    {
      public long method0(long[] paramAnonymousArrayOfLong)
      {
        return WebSite.this.QueryInterface(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method1(long[] paramAnonymousArrayOfLong)
      {
        return WebSite.this.AddRef();
      }
      
      public long method2(long[] paramAnonymousArrayOfLong)
      {
        return WebSite.this.Release();
      }
      
      public long method3(long[] paramAnonymousArrayOfLong)
      {
        return WebSite.this.ShowMessage(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2], (int)paramAnonymousArrayOfLong[3], paramAnonymousArrayOfLong[4], (int)paramAnonymousArrayOfLong[5], paramAnonymousArrayOfLong[6]);
      }
      
      public long method4(long[] paramAnonymousArrayOfLong)
      {
        if (paramAnonymousArrayOfLong.length == 7) {
          return WebSite.this.ShowHelp(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], (int)paramAnonymousArrayOfLong[2], (int)paramAnonymousArrayOfLong[3], (int)paramAnonymousArrayOfLong[4], (int)paramAnonymousArrayOfLong[5], paramAnonymousArrayOfLong[6]);
        }
        return WebSite.this.ShowHelp_64(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], (int)paramAnonymousArrayOfLong[2], (int)paramAnonymousArrayOfLong[3], paramAnonymousArrayOfLong[4], paramAnonymousArrayOfLong[5]);
      }
    };
    this.iServiceProvider = new COMObject(new int[] { 2, 0, 0, 3 })
    {
      public long method0(long[] paramAnonymousArrayOfLong)
      {
        return WebSite.this.QueryInterface(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method1(long[] paramAnonymousArrayOfLong)
      {
        return WebSite.this.AddRef();
      }
      
      public long method2(long[] paramAnonymousArrayOfLong)
      {
        return WebSite.this.Release();
      }
      
      public long method3(long[] paramAnonymousArrayOfLong)
      {
        return WebSite.this.QueryService(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2]);
      }
    };
    this.iInternetSecurityManager = new COMObject(new int[] { 2, 0, 0, 1, 1, 3, 4, 8, 7, 3, 3 })
    {
      public long method0(long[] paramAnonymousArrayOfLong)
      {
        return WebSite.this.QueryInterface(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method1(long[] paramAnonymousArrayOfLong)
      {
        return WebSite.this.AddRef();
      }
      
      public long method2(long[] paramAnonymousArrayOfLong)
      {
        return WebSite.this.Release();
      }
      
      public long method3(long[] paramAnonymousArrayOfLong)
      {
        return WebSite.this.SetSecuritySite(paramAnonymousArrayOfLong[0]);
      }
      
      public long method4(long[] paramAnonymousArrayOfLong)
      {
        return WebSite.this.GetSecuritySite(paramAnonymousArrayOfLong[0]);
      }
      
      public long method5(long[] paramAnonymousArrayOfLong)
      {
        return WebSite.this.MapUrlToZone(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], (int)paramAnonymousArrayOfLong[2]);
      }
      
      public long method6(long[] paramAnonymousArrayOfLong)
      {
        return WebSite.this.GetSecurityId(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2], paramAnonymousArrayOfLong[3]);
      }
      
      public long method7(long[] paramAnonymousArrayOfLong)
      {
        return WebSite.this.ProcessUrlAction(paramAnonymousArrayOfLong[0], (int)paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2], (int)paramAnonymousArrayOfLong[3], paramAnonymousArrayOfLong[4], (int)paramAnonymousArrayOfLong[5], (int)paramAnonymousArrayOfLong[6], (int)paramAnonymousArrayOfLong[7]);
      }
      
      public long method8(long[] paramAnonymousArrayOfLong)
      {
        return WebSite.this.QueryCustomPolicy(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2], paramAnonymousArrayOfLong[3], paramAnonymousArrayOfLong[4], (int)paramAnonymousArrayOfLong[5], (int)paramAnonymousArrayOfLong[6]);
      }
      
      public long method9(long[] paramAnonymousArrayOfLong)
      {
        return WebSite.this.SetZoneMapping((int)paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], (int)paramAnonymousArrayOfLong[2]);
      }
      
      public long method10(long[] paramAnonymousArrayOfLong)
      {
        return WebSite.this.GetZoneMappings((int)paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], (int)paramAnonymousArrayOfLong[2]);
      }
    };
    this.iOleCommandTarget = new COMObject(new int[] { 2, 0, 0, 4, 5 })
    {
      public long method0(long[] paramAnonymousArrayOfLong)
      {
        return WebSite.this.QueryInterface(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method1(long[] paramAnonymousArrayOfLong)
      {
        return WebSite.this.AddRef();
      }
      
      public long method2(long[] paramAnonymousArrayOfLong)
      {
        return WebSite.this.Release();
      }
      
      public long method3(long[] paramAnonymousArrayOfLong)
      {
        return WebSite.this.QueryStatus(paramAnonymousArrayOfLong[0], (int)paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2], paramAnonymousArrayOfLong[3]);
      }
      
      public long method4(long[] paramAnonymousArrayOfLong)
      {
        return WebSite.this.Exec(paramAnonymousArrayOfLong[0], (int)paramAnonymousArrayOfLong[1], (int)paramAnonymousArrayOfLong[2], paramAnonymousArrayOfLong[3], paramAnonymousArrayOfLong[4]);
      }
    };
    this.iAuthenticate = new COMObject(new int[] { 2, 0, 0, 3 })
    {
      public long method0(long[] paramAnonymousArrayOfLong)
      {
        return WebSite.this.QueryInterface(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method1(long[] paramAnonymousArrayOfLong)
      {
        return WebSite.this.AddRef();
      }
      
      public long method2(long[] paramAnonymousArrayOfLong)
      {
        return WebSite.this.Release();
      }
      
      public long method3(long[] paramAnonymousArrayOfLong)
      {
        return WebSite.this.Authenticate(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2]);
      }
    };
    this.iDispatch = new COMObject(new int[] { 2, 0, 0, 1, 3, 5, 8 })
    {
      public long method0(long[] paramAnonymousArrayOfLong)
      {
        GUID localGUID = new GUID();
        COM.MoveMemory(localGUID, paramAnonymousArrayOfLong[0], GUID.sizeof);
        if (COM.IsEqualGUID(localGUID, COM.IIDIDispatch))
        {
          COM.MoveMemory(paramAnonymousArrayOfLong[1], new long[] { WebSite.this.iDispatch.getAddress() }, OS.PTR_SIZEOF);
          WebSite.this.AddRef();
          return 0L;
        }
        return WebSite.this.QueryInterface(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method1(long[] paramAnonymousArrayOfLong)
      {
        return WebSite.this.AddRef();
      }
      
      public long method2(long[] paramAnonymousArrayOfLong)
      {
        return WebSite.this.Release();
      }
      
      public long method3(long[] paramAnonymousArrayOfLong)
      {
        return WebSite.this.GetTypeInfoCount(paramAnonymousArrayOfLong[0]);
      }
      
      public long method4(long[] paramAnonymousArrayOfLong)
      {
        return WebSite.this.GetTypeInfo((int)paramAnonymousArrayOfLong[0], (int)paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2]);
      }
      
      public long method5(long[] paramAnonymousArrayOfLong)
      {
        return WebSite.this.GetIDsOfNames((int)paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], (int)paramAnonymousArrayOfLong[2], (int)paramAnonymousArrayOfLong[3], paramAnonymousArrayOfLong[4]);
      }
      
      public long method6(long[] paramAnonymousArrayOfLong)
      {
        return WebSite.this.Invoke((int)paramAnonymousArrayOfLong[0], (int)paramAnonymousArrayOfLong[1], (int)paramAnonymousArrayOfLong[2], (int)paramAnonymousArrayOfLong[3], paramAnonymousArrayOfLong[4], paramAnonymousArrayOfLong[5], paramAnonymousArrayOfLong[6], paramAnonymousArrayOfLong[7]);
      }
    };
  }
  
  protected void disposeCOMInterfaces()
  {
    super.disposeCOMInterfaces();
    if (this.iDocHostUIHandler != null)
    {
      this.iDocHostUIHandler.dispose();
      this.iDocHostUIHandler = null;
    }
    if (this.iDocHostShowUI != null)
    {
      this.iDocHostShowUI.dispose();
      this.iDocHostShowUI = null;
    }
    if (this.iServiceProvider != null)
    {
      this.iServiceProvider.dispose();
      this.iServiceProvider = null;
    }
    if (this.iInternetSecurityManager != null)
    {
      this.iInternetSecurityManager.dispose();
      this.iInternetSecurityManager = null;
    }
    if (this.iOleCommandTarget != null)
    {
      this.iOleCommandTarget.dispose();
      this.iOleCommandTarget = null;
    }
    if (this.iAuthenticate != null)
    {
      this.iAuthenticate.dispose();
      this.iAuthenticate = null;
    }
    if (this.iDispatch != null)
    {
      this.iDispatch.dispose();
      this.iDispatch = null;
    }
  }
  
  protected int AddRef()
  {
    return super.AddRef();
  }
  
  protected int QueryInterface(long paramLong1, long paramLong2)
  {
    int i = super.QueryInterface(paramLong1, paramLong2);
    if (i == 0) {
      return i;
    }
    if ((paramLong1 == 0L) || (paramLong2 == 0L)) {
      return -2147024809;
    }
    GUID localGUID = new GUID();
    COM.MoveMemory(localGUID, paramLong1, GUID.sizeof);
    if (COM.IsEqualGUID(localGUID, COM.IIDIDocHostUIHandler))
    {
      COM.MoveMemory(paramLong2, new long[] { this.iDocHostUIHandler.getAddress() }, OS.PTR_SIZEOF);
      AddRef();
      return 0;
    }
    if (COM.IsEqualGUID(localGUID, COM.IIDIDocHostShowUI))
    {
      COM.MoveMemory(paramLong2, new long[] { this.iDocHostShowUI.getAddress() }, OS.PTR_SIZEOF);
      AddRef();
      return 0;
    }
    if (COM.IsEqualGUID(localGUID, COM.IIDIServiceProvider))
    {
      COM.MoveMemory(paramLong2, new long[] { this.iServiceProvider.getAddress() }, OS.PTR_SIZEOF);
      AddRef();
      return 0;
    }
    if (COM.IsEqualGUID(localGUID, COM.IIDIInternetSecurityManager))
    {
      COM.MoveMemory(paramLong2, new long[] { this.iInternetSecurityManager.getAddress() }, OS.PTR_SIZEOF);
      AddRef();
      return 0;
    }
    if (COM.IsEqualGUID(localGUID, COM.IIDIOleCommandTarget))
    {
      COM.MoveMemory(paramLong2, new long[] { this.iOleCommandTarget.getAddress() }, OS.PTR_SIZEOF);
      AddRef();
      return 0;
    }
    COM.MoveMemory(paramLong2, new long[] { 0L }, OS.PTR_SIZEOF);
    return -2147467262;
  }
  
  int EnableModeless(int paramInt)
  {
    return -2147467263;
  }
  
  int FilterDataObject(long paramLong1, long paramLong2)
  {
    return -2147467263;
  }
  
  int GetDropTarget(long paramLong1, long paramLong2)
  {
    return -2147467263;
  }
  
  int GetExternal(long paramLong)
  {
    OS.MoveMemory(paramLong, new long[] { this.iDispatch.getAddress() }, C.PTR_SIZEOF);
    AddRef();
    return 0;
  }
  
  int GetHostInfo(long paramLong)
  {
    int i = 67371008;
    IE localIE = (IE)((Browser)getParent().getParent()).webBrowser;
    if ((localIE.style & 0x800) == 0) {
      i |= 0x200000;
    }
    DOCHOSTUIINFO localDOCHOSTUIINFO = new DOCHOSTUIINFO();
    OS.MoveMemory(localDOCHOSTUIINFO, paramLong, DOCHOSTUIINFO.sizeof);
    localDOCHOSTUIINFO.dwFlags = i;
    OS.MoveMemory(paramLong, localDOCHOSTUIINFO, DOCHOSTUIINFO.sizeof);
    return 0;
  }
  
  int GetOptionKeyPath(long paramLong, int paramInt)
  {
    return -2147467263;
  }
  
  int HideUI()
  {
    return -2147467263;
  }
  
  int OnDocWindowActivate(int paramInt)
  {
    return -2147467263;
  }
  
  int OnFrameWindowActivate(int paramInt)
  {
    return -2147467263;
  }
  
  protected int Release()
  {
    return super.Release();
  }
  
  int ResizeBorder(long paramLong1, long paramLong2, int paramInt)
  {
    return -2147467263;
  }
  
  int ShowContextMenu(int paramInt, long paramLong1, long paramLong2, long paramLong3)
  {
    Browser localBrowser = (Browser)getParent().getParent();
    Event localEvent = new Event();
    POINT localPOINT = new POINT();
    OS.MoveMemory(localPOINT, paramLong1, POINT.sizeof);
    localEvent.x = localPOINT.x;
    localEvent.y = localPOINT.y;
    localBrowser.notifyListeners(35, localEvent);
    if (!localEvent.doit) {
      return 0;
    }
    Menu localMenu = localBrowser.getMenu();
    if ((localMenu != null) && (!localMenu.isDisposed()))
    {
      if ((localPOINT.x != localEvent.x) || (localPOINT.y != localEvent.y)) {
        localMenu.setLocation(localEvent.x, localEvent.y);
      }
      localMenu.setVisible(true);
      return 0;
    }
    return 1;
  }
  
  int ShowUI(int paramInt, long paramLong1, long paramLong2, long paramLong3, long paramLong4)
  {
    return 1;
  }
  
  int TranslateAccelerator(long paramLong1, long paramLong2, int paramInt)
  {
    Menu localMenu = getShell().getMenuBar();
    Object localObject;
    if ((localMenu != null) && (!localMenu.isDisposed()) && (localMenu.isEnabled()))
    {
      Shell localShell = localMenu.getShell();
      long l1 = localShell.handle;
      long l2 = OS.SendMessage(l1, 32769, 0L, 0L);
      if (l2 != 0L)
      {
        localObject = new MSG();
        OS.MoveMemory((MSG)localObject, paramLong1, MSG.sizeof);
        if (OS.TranslateAccelerator(l1, l2, (MSG)localObject) != 0) {
          return 0;
        }
      }
    }
    int i = 1;
    MSG localMSG = new MSG();
    OS.MoveMemory(localMSG, paramLong1, MSG.sizeof);
    if (localMSG.message == 256)
    {
      switch ((int)localMSG.wParam)
      {
      case 116: 
        OleAutomation localOleAutomation = new OleAutomation(this);
        int[] arrayOfInt = localOleAutomation.getIDsOfNames(new String[] { "LocationURL" });
        Variant localVariant = localOleAutomation.getProperty(arrayOfInt[0]);
        localOleAutomation.dispose();
        if (localVariant == null) {
          break label436;
        }
        if (localVariant.getType() == 8)
        {
          localObject = localVariant.getString();
          if (((String)localObject).equals("about:blank")) {
            i = 0;
          }
        }
        localVariant.dispose();
        break;
      case 9: 
        break;
      case 33: 
      case 34: 
      case 35: 
      case 36: 
      case 37: 
      case 38: 
      case 39: 
      case 40: 
        break;
      case 8: 
      case 13: 
        break;
      case 76: 
      case 78: 
      case 79: 
        if ((OS.GetKeyState(17) < 0) && (OS.GetKeyState(18) >= 0) && (OS.GetKeyState(16) >= 0) && ((localMSG.wParam == 78L) || (IE.IEVersion >= 8)))
        {
          this.frame.setData("org.eclipse.swt.OleFrame.ConsumeKey", "false");
          i = 0;
        }
        break;
      }
      OS.TranslateMessage(localMSG);
      this.frame.setData("org.eclipse.swt.OleFrame.ConsumeKey", "true");
    }
    label436:
    switch (localMSG.message)
    {
    case 256: 
    case 257: 
      if (!OS.IsWinCE)
      {
        int j = 0;
        switch ((int)localMSG.wParam)
        {
        case 16: 
        case 17: 
        case 18: 
        case 20: 
        case 144: 
        case 145: 
          break;
        default: 
          int k = OS.MapVirtualKey((int)localMSG.wParam, 2);
          if (k != 0)
          {
            j = (k & (OS.IsWinNT ? Integer.MIN_VALUE : 32768)) != 0 ? 1 : 0;
            if (j == 0) {
              for (int m = 0; m < ACCENTS.length; m++)
              {
                int n = OS.VkKeyScan(ACCENTS[m]);
                if ((n != -1) && ((n & 0xFF) == localMSG.wParam))
                {
                  int i1 = n >> 8;
                  if ((OS.GetKeyState(16) < 0 ? 1 : 0) == ((i1 & 0x1) != 0 ? 1 : 0)) {
                    if ((OS.GetKeyState(17) < 0 ? 1 : 0) == ((i1 & 0x2) != 0 ? 1 : 0)) {
                      if ((OS.GetKeyState(18) < 0 ? 1 : 0) == ((i1 & 0x4) != 0 ? 1 : 0))
                      {
                        if ((i1 & 0x7) == 0) {
                          break;
                        }
                        j = 1;
                        break;
                      }
                    }
                  }
                }
              }
            }
          }
          break;
        }
        if (j != 0) {
          i = 0;
        }
      }
      break;
    }
    return i;
  }
  
  int TranslateUrl(int paramInt, long paramLong1, long paramLong2)
  {
    return -2147467263;
  }
  
  int UpdateUI()
  {
    return -2147467263;
  }
  
  int ShowMessage(long paramLong1, long paramLong2, long paramLong3, int paramInt1, long paramLong4, int paramInt2, long paramLong5)
  {
    int i = (this.ignoreNextMessage) || (this.ignoreAllMessages) ? 1 : 0;
    this.ignoreNextMessage = false;
    return i != 0 ? 0 : 1;
  }
  
  int ShowHelp_64(long paramLong1, long paramLong2, int paramInt1, int paramInt2, long paramLong3, long paramLong4)
  {
    POINT localPOINT = new POINT();
    OS.MoveMemory(localPOINT, new long[] { paramLong3 }, 8);
    return ShowHelp(paramLong1, paramLong2, paramInt1, paramInt2, localPOINT.x, localPOINT.y, paramLong4);
  }
  
  int ShowHelp(long paramLong1, long paramLong2, int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong3)
  {
    Browser localBrowser = (Browser)getParent().getParent();
    Event localEvent = new Event();
    localEvent.type = 28;
    localEvent.display = getDisplay();
    localEvent.widget = localBrowser;
    Shell localShell = localBrowser.getShell();
    for (Object localObject = localBrowser;; localObject = ((Control)localObject).getParent()) {
      if (((Control)localObject).isListening(28)) {
        ((Control)localObject).notifyListeners(28, localEvent);
      } else {
        if (localObject == localShell) {
          break;
        }
      }
    }
    return 0;
  }
  
  int QueryService(long paramLong1, long paramLong2, long paramLong3)
  {
    if ((paramLong2 == 0L) || (paramLong3 == 0L)) {
      return -2147024809;
    }
    GUID localGUID = new GUID();
    COM.MoveMemory(localGUID, paramLong2, GUID.sizeof);
    if (COM.IsEqualGUID(localGUID, COM.IIDIInternetSecurityManager))
    {
      COM.MoveMemory(paramLong3, new long[] { this.iInternetSecurityManager.getAddress() }, OS.PTR_SIZEOF);
      AddRef();
      return 0;
    }
    if (COM.IsEqualGUID(localGUID, COM.IIDIAuthenticate))
    {
      COM.MoveMemory(paramLong3, new long[] { this.iAuthenticate.getAddress() }, OS.PTR_SIZEOF);
      AddRef();
      return 0;
    }
    COM.MoveMemory(paramLong3, new long[] { 0L }, OS.PTR_SIZEOF);
    return -2147467262;
  }
  
  int SetSecuritySite(long paramLong)
  {
    return -2146697199;
  }
  
  int GetSecuritySite(long paramLong)
  {
    return -2146697199;
  }
  
  int MapUrlToZone(long paramLong1, long paramLong2, int paramInt)
  {
    IE localIE = (IE)((Browser)getParent().getParent()).webBrowser;
    if ((localIE.auto != null) && (localIE.isAboutBlank) && (!localIE.untrustedText))
    {
      COM.MoveMemory(paramLong2, new int[] { 1 }, 4);
      return 0;
    }
    return -2146697199;
  }
  
  int GetSecurityId(long paramLong1, long paramLong2, long paramLong3, long paramLong4)
  {
    return -2146697199;
  }
  
  int ProcessUrlAction(long paramLong1, int paramInt1, long paramLong2, int paramInt2, long paramLong3, int paramInt3, int paramInt4, int paramInt5)
  {
    this.ignoreNextMessage = false;
    if (paramInt1 == 8449)
    {
      IE localIE = (IE)((Browser)getParent().getParent()).webBrowser;
      if ((localIE.auto != null) && (localIE._getUrl().startsWith("about:blank")) && (!localIE.untrustedText))
      {
        if (paramInt2 >= 4) {
          COM.MoveMemory(paramLong2, new int[] { 0 }, 4);
        }
        return 0;
      }
    }
    int i = -2146697199;
    if ((paramInt1 >= 7168) && (paramInt1 <= 7423)) {
      if (canExecuteApplets())
      {
        i = 196608;
      }
      else
      {
        i = 0;
        this.ignoreNextMessage = true;
      }
    }
    Object localObject;
    if (paramInt1 == 4608)
    {
      localObject = new GUID();
      COM.MoveMemory((GUID)localObject, paramLong3, GUID.sizeof);
      if ((COM.IsEqualGUID((GUID)localObject, COM.IIDJavaBeansBridge)) && (!canExecuteApplets()))
      {
        i = 3;
        this.ignoreNextMessage = true;
      }
      if (COM.IsEqualGUID((GUID)localObject, COM.IIDShockwaveActiveXControl))
      {
        i = 3;
        this.ignoreNextMessage = true;
      }
    }
    if (paramInt1 == 5120)
    {
      localObject = (IE)((Browser)getParent().getParent()).webBrowser;
      i = ((IE)localObject).jsEnabled ? 0 : 3;
    }
    if (i == -2146697199) {
      return -2146697199;
    }
    if (paramInt2 >= 4) {
      COM.MoveMemory(paramLong2, new int[] { i }, 4);
    }
    return i == 0 ? 0 : 1;
  }
  
  boolean canExecuteApplets()
  {
    if (IE.IEVersion < 7) {
      return false;
    }
    if (this.canExecuteApplets == null)
    {
      WebBrowser localWebBrowser = ((Browser)getParent().getParent()).webBrowser;
      String str = "try {var element = document.createElement('object');element.classid='clsid:CAFEEFAC-DEC7-0000-0000-ABCDEFFEDCBA';return element.object.isPlugin2();} catch (err) {};return false;";
      this.canExecuteApplets = ((Boolean)localWebBrowser.evaluate(str));
      if (this.canExecuteApplets.booleanValue()) {
        try
        {
          Class.forName("sun.plugin2.main.server.IExplorerPlugin");
          Class.forName("com.sun.deploy.services.Service");
          Class.forName("com.sun.javaws.Globals");
        }
        catch (ClassNotFoundException localClassNotFoundException)
        {
          this.canExecuteApplets = Boolean.FALSE;
        }
      }
    }
    return this.canExecuteApplets.booleanValue();
  }
  
  int QueryCustomPolicy(long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5, int paramInt1, int paramInt2)
  {
    return -2146697199;
  }
  
  int SetZoneMapping(int paramInt1, long paramLong, int paramInt2)
  {
    return -2146697199;
  }
  
  int GetZoneMappings(int paramInt1, long paramLong, int paramInt2)
  {
    return -2147467263;
  }
  
  int QueryStatus(long paramLong1, int paramInt, long paramLong2, long paramLong3)
  {
    return -2147221248;
  }
  
  int Exec(long paramLong1, int paramInt1, int paramInt2, long paramLong2, long paramLong3)
  {
    if (paramLong1 != 0L)
    {
      GUID localGUID = new GUID();
      COM.MoveMemory(localGUID, paramLong1, GUID.sizeof);
      if ((COM.IsEqualGUID(localGUID, COM.CGID_DocHostCommandHandler)) && (paramInt1 == 40)) {
        return 0;
      }
      if ((paramInt1 == 1) && (COM.IsEqualGUID(localGUID, COM.CGID_Explorer)) && ((paramInt2 & 0xFFFF) == 10))
      {
        IE localIE = (IE)((Browser)getParent().getParent()).webBrowser;
        localIE.toolBar = ((paramInt2 & 0xFFFF0000) != 0);
      }
    }
    return -2147221248;
  }
  
  int Authenticate(long paramLong1, long paramLong2, long paramLong3)
  {
    IE localIE = (IE)((Browser)getParent().getParent()).webBrowser;
    for (int i = 0; i < localIE.authenticationListeners.length; i++)
    {
      AuthenticationEvent localAuthenticationEvent = new AuthenticationEvent(localIE.browser);
      localAuthenticationEvent.location = localIE.lastNavigateURL;
      localIE.authenticationListeners[i].authenticate(localAuthenticationEvent);
      if (!localAuthenticationEvent.doit) {
        return -2147024891;
      }
      if ((localAuthenticationEvent.user != null) && (localAuthenticationEvent.password != null))
      {
        TCHAR localTCHAR1 = new TCHAR(0, localAuthenticationEvent.user, true);
        int j = localTCHAR1.length() * TCHAR.sizeof;
        long l1 = COM.CoTaskMemAlloc(j);
        OS.MoveMemory(l1, localTCHAR1, j);
        TCHAR localTCHAR2 = new TCHAR(0, localAuthenticationEvent.password, true);
        j = localTCHAR2.length() * TCHAR.sizeof;
        long l2 = COM.CoTaskMemAlloc(j);
        OS.MoveMemory(l2, localTCHAR2, j);
        C.memmove(paramLong1, new long[] { 0L }, C.PTR_SIZEOF);
        C.memmove(paramLong2, new long[] { l1 }, C.PTR_SIZEOF);
        C.memmove(paramLong3, new long[] { l2 }, C.PTR_SIZEOF);
        return 0;
      }
    }
    C.memmove(paramLong1, new long[] { getShell().handle }, C.PTR_SIZEOF);
    return 0;
  }
  
  int GetTypeInfoCount(long paramLong)
  {
    C.memmove(paramLong, new int[] { 0 }, 4L);
    return 0;
  }
  
  int GetTypeInfo(int paramInt1, int paramInt2, long paramLong)
  {
    return 0;
  }
  
  int GetIDsOfNames(int paramInt1, long paramLong1, int paramInt2, int paramInt3, long paramLong2)
  {
    long[] arrayOfLong = new long[1];
    OS.MoveMemory(arrayOfLong, paramLong1, C.PTR_SIZEOF);
    int i = OS.wcslen(arrayOfLong[0]);
    char[] arrayOfChar = new char[i];
    OS.MoveMemory(arrayOfChar, arrayOfLong[0], i * 2);
    String str = String.valueOf(arrayOfChar);
    int j = 0;
    int[] arrayOfInt = new int[paramInt2];
    int k;
    if (str.equals("callJava"))
    {
      for (k = 0; k < paramInt2; k++) {
        arrayOfInt[k] = (k + 1);
      }
    }
    else
    {
      j = -2147352570;
      for (k = 0; k < paramInt2; k++) {
        arrayOfInt[k] = -1;
      }
    }
    OS.MoveMemory(paramLong2, arrayOfInt, paramInt2 * 4);
    return j;
  }
  
  int Invoke(int paramInt1, long paramLong1, int paramInt2, int paramInt3, long paramLong2, long paramLong3, long paramLong4, long paramLong5)
  {
    IE localIE = (IE)((Browser)getParent().getParent()).webBrowser;
    Hashtable localHashtable = localIE.functions;
    if (localHashtable == null)
    {
      if (paramLong3 != 0L) {
        COM.MoveMemory(paramLong3, new long[] { 0L }, C.PTR_SIZEOF);
      }
      return 0;
    }
    DISPPARAMS localDISPPARAMS = new DISPPARAMS();
    COM.MoveMemory(localDISPPARAMS, paramLong2, DISPPARAMS.sizeof);
    if (localDISPPARAMS.cArgs != 3)
    {
      if (paramLong3 != 0L) {
        COM.MoveMemory(paramLong3, new long[] { 0L }, C.PTR_SIZEOF);
      }
      return 0;
    }
    long l = localDISPPARAMS.rgvarg + 2 * Variant.sizeof;
    Variant localVariant = Variant.win32_new(l);
    if (localVariant.getType() != 3)
    {
      localVariant.dispose();
      if (paramLong3 != 0L) {
        COM.MoveMemory(paramLong3, new long[] { 0L }, C.PTR_SIZEOF);
      }
      return 0;
    }
    int i = localVariant.getInt();
    localVariant.dispose();
    if (i <= 0)
    {
      if (paramLong3 != 0L) {
        COM.MoveMemory(paramLong3, new long[] { 0L }, C.PTR_SIZEOF);
      }
      return 0;
    }
    l = localDISPPARAMS.rgvarg + Variant.sizeof;
    localVariant = Variant.win32_new(l);
    int j = localVariant.getType();
    if (j != 8)
    {
      localVariant.dispose();
      if (paramLong3 != 0L) {
        COM.MoveMemory(paramLong3, new long[] { 0L }, C.PTR_SIZEOF);
      }
      return 0;
    }
    String str = localVariant.getString();
    localVariant.dispose();
    localVariant = Variant.win32_new(localDISPPARAMS.rgvarg);
    Integer localInteger = new Integer(i);
    BrowserFunction localBrowserFunction = (BrowserFunction)localHashtable.get(localInteger);
    Object localObject1 = null;
    if ((localBrowserFunction != null) && (str.equals(localBrowserFunction.token))) {
      try
      {
        Object localObject2 = convertToJava(localVariant);
        if ((localObject2 instanceof Object[]))
        {
          Object[] arrayOfObject = (Object[])localObject2;
          try
          {
            localObject1 = localBrowserFunction.function(arrayOfObject);
          }
          catch (Exception localException)
          {
            localObject1 = WebBrowser.CreateErrorString(localException.getLocalizedMessage());
          }
        }
      }
      catch (IllegalArgumentException localIllegalArgumentException)
      {
        if (localBrowserFunction.isEvaluate) {
          localBrowserFunction.function(new String[] { WebBrowser.CreateErrorString(new SWTException(51).getLocalizedMessage()) });
        }
        localObject1 = WebBrowser.CreateErrorString(localIllegalArgumentException.getLocalizedMessage());
      }
    }
    localVariant.dispose();
    if (paramLong3 != 0L)
    {
      try
      {
        localVariant = convertToJS(localObject1);
      }
      catch (SWTException localSWTException)
      {
        localVariant = convertToJS(WebBrowser.CreateErrorString(localSWTException.getLocalizedMessage()));
      }
      Variant.win32_copy(paramLong3, localVariant);
      localVariant.dispose();
    }
    return 0;
  }
  
  Object convertToJava(Variant paramVariant)
  {
    switch (paramVariant.getType())
    {
    case 0: 
    case 1: 
      return null;
    case 8: 
      return paramVariant.getString();
    case 11: 
      return new Boolean(paramVariant.getBoolean());
    case 2: 
    case 3: 
    case 4: 
    case 5: 
    case 20: 
      return new Double(paramVariant.getDouble());
    case 9: 
      Object[] arrayOfObject = null;
      OleAutomation localOleAutomation = paramVariant.getAutomation();
      TYPEATTR localTYPEATTR = localOleAutomation.getTypeInfoAttributes();
      if (localTYPEATTR != null)
      {
        GUID localGUID = new GUID();
        localGUID.Data1 = localTYPEATTR.guid_Data1;
        localGUID.Data2 = localTYPEATTR.guid_Data2;
        localGUID.Data3 = localTYPEATTR.guid_Data3;
        localGUID.Data4 = localTYPEATTR.guid_Data4;
        if (COM.IsEqualGUID(localGUID, COM.IIDIJScriptTypeInfo))
        {
          int[] arrayOfInt = localOleAutomation.getIDsOfNames(new String[] { "length" });
          if (arrayOfInt != null)
          {
            Variant localVariant1 = localOleAutomation.getProperty(arrayOfInt[0]);
            int i = localVariant1.getInt();
            localVariant1.dispose();
            arrayOfObject = new Object[i];
            for (int j = 0; j < i; j++)
            {
              arrayOfInt = localOleAutomation.getIDsOfNames(new String[] { String.valueOf(j) });
              if (arrayOfInt != null)
              {
                Variant localVariant2 = localOleAutomation.getProperty(arrayOfInt[0]);
                try
                {
                  arrayOfObject[j] = convertToJava(localVariant2);
                  localVariant2.dispose();
                }
                catch (IllegalArgumentException localIllegalArgumentException)
                {
                  localVariant2.dispose();
                  localOleAutomation.dispose();
                  throw localIllegalArgumentException;
                }
              }
            }
          }
        }
        else
        {
          localOleAutomation.dispose();
          SWT.error(5);
        }
      }
      localOleAutomation.dispose();
      return arrayOfObject;
    }
    SWT.error(5);
    return null;
  }
  
  Variant convertToJS(Object paramObject)
  {
    if (paramObject == null) {
      return Variant.NULL;
    }
    if ((paramObject instanceof String)) {
      return new Variant((String)paramObject);
    }
    if ((paramObject instanceof Boolean)) {
      return new Variant(((Boolean)paramObject).booleanValue());
    }
    if ((paramObject instanceof Number)) {
      return new Variant(((Number)paramObject).doubleValue());
    }
    if ((paramObject instanceof Object[]))
    {
      IE localIE = (IE)((Browser)getParent().getParent()).webBrowser;
      OleAutomation localOleAutomation1 = localIE.auto;
      int[] arrayOfInt1 = localOleAutomation1.getIDsOfNames(new String[] { "Document" });
      if (arrayOfInt1 == null) {
        return new Variant();
      }
      Variant localVariant1 = localOleAutomation1.getProperty(arrayOfInt1[0]);
      if (localVariant1 == null) {
        return new Variant();
      }
      if (localVariant1.getType() == 0)
      {
        localVariant1.dispose();
        return new Variant();
      }
      OleAutomation localOleAutomation2 = localVariant1.getAutomation();
      localVariant1.dispose();
      arrayOfInt1 = localOleAutomation2.getIDsOfNames(new String[] { "parentWindow" });
      if (arrayOfInt1 == null)
      {
        localOleAutomation2.dispose();
        return new Variant();
      }
      localVariant1 = localOleAutomation2.getProperty(arrayOfInt1[0]);
      if ((localVariant1 == null) || (localVariant1.getType() == 0))
      {
        if (localVariant1 != null) {
          localVariant1.dispose();
        }
        localOleAutomation2.dispose();
        return new Variant();
      }
      OleAutomation localOleAutomation3 = localVariant1.getAutomation();
      localVariant1.dispose();
      localOleAutomation2.dispose();
      arrayOfInt1 = localOleAutomation3.getIDsOfNames(new String[] { "Array" });
      if (arrayOfInt1 == null)
      {
        localOleAutomation3.dispose();
        return new Variant();
      }
      Variant localVariant2 = localOleAutomation3.getProperty(arrayOfInt1[0]);
      localOleAutomation3.dispose();
      IDispatch localIDispatch = localVariant2.getDispatch();
      long[] arrayOfLong = new long[1];
      int i = localIDispatch.QueryInterface(COM.IIDIDispatchEx, arrayOfLong);
      localVariant2.dispose();
      if (i != 0) {
        return new Variant();
      }
      IDispatchEx localIDispatchEx = new IDispatchEx(arrayOfLong[0]);
      arrayOfLong[0] = 0L;
      long l = OS.GlobalAlloc(64, VARIANT.sizeof);
      DISPPARAMS localDISPPARAMS = new DISPPARAMS();
      i = localIDispatchEx.InvokeEx(0, 2048, 16384, localDISPPARAMS, l, null, 0L);
      if (i != 0)
      {
        OS.GlobalFree(l);
        return new Variant();
      }
      Variant localVariant3 = Variant.win32_new(l);
      OS.GlobalFree(l);
      Object[] arrayOfObject = (Object[])paramObject;
      int j = arrayOfObject.length;
      localOleAutomation1 = localVariant3.getAutomation();
      int[] arrayOfInt2 = localOleAutomation1.getIDsOfNames(new String[] { "push" });
      if (arrayOfInt2 != null) {
        for (int k = 0; k < j; k++)
        {
          Object localObject = arrayOfObject[k];
          try
          {
            Variant localVariant4 = convertToJS(localObject);
            localOleAutomation1.invoke(arrayOfInt2[0], new Variant[] { localVariant4 });
            localVariant4.dispose();
          }
          catch (SWTException localSWTException)
          {
            localOleAutomation1.dispose();
            localVariant3.dispose();
            throw localSWTException;
          }
        }
      }
      localOleAutomation1.dispose();
      return localVariant3;
    }
    SWT.error(51);
    return null;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/browser/WebSite.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */