package org.eclipse.swt.graphics;

import org.eclipse.swt.SWT;
import org.eclipse.swt.internal.win32.BITMAP;
import org.eclipse.swt.internal.win32.ICONINFO;
import org.eclipse.swt.internal.win32.OS;

public final class Cursor
  extends Resource
{
  public long handle;
  boolean isIcon;
  static final byte[] HAND_SOURCE = { -7, -1, -1, -1, -16, -1, -1, -1, -16, -1, -1, -1, -16, -1, -1, -1, -16, 63, -1, -1, -16, 7, -1, -1, -16, 3, -1, -1, -16, 0, -1, -1, 16, 0, Byte.MAX_VALUE, -1, 0, 0, Byte.MAX_VALUE, -1, Byte.MIN_VALUE, 0, Byte.MAX_VALUE, -1, -64, 0, Byte.MAX_VALUE, -1, -32, 0, Byte.MAX_VALUE, -1, -16, 0, Byte.MAX_VALUE, -1, -8, 0, -1, -1, -4, 1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1 };
  static final byte[] HAND_MASK = { 0, 0, 0, 0, 6, 0, 0, 0, 6, 0, 0, 0, 6, 0, 0, 0, 6, 0, 0, 0, 6, -64, 0, 0, 6, -40, 0, 0, 6, -40, 0, 0, 7, -37, 0, 0, 103, -5, 0, 0, 63, -1, 0, 0, 31, -1, 0, 0, 15, -1, 0, 0, 7, -1, 0, 0, 3, -2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
  
  Cursor(Device paramDevice)
  {
    super(paramDevice);
  }
  
  public Cursor(Device paramDevice, int paramInt)
  {
    super(paramDevice);
    long l1 = 0L;
    switch (paramInt)
    {
    case 21: 
      l1 = 32649L;
      break;
    case 0: 
      l1 = 32512L;
      break;
    case 1: 
      l1 = 32514L;
      break;
    case 2: 
      l1 = 32515L;
      break;
    case 3: 
      l1 = 32650L;
      break;
    case 4: 
      l1 = 32651L;
      break;
    case 5: 
      l1 = 32646L;
      break;
    case 6: 
      l1 = 32643L;
      break;
    case 7: 
      l1 = 32645L;
      break;
    case 8: 
      l1 = 32642L;
      break;
    case 9: 
      l1 = 32644L;
      break;
    case 10: 
      l1 = 32645L;
      break;
    case 11: 
      l1 = 32645L;
      break;
    case 12: 
      l1 = 32644L;
      break;
    case 13: 
      l1 = 32644L;
      break;
    case 14: 
      l1 = 32643L;
      break;
    case 15: 
      l1 = 32642L;
      break;
    case 16: 
      l1 = 32643L;
      break;
    case 17: 
      l1 = 32642L;
      break;
    case 18: 
      l1 = 32516L;
      break;
    case 19: 
      l1 = 32513L;
      break;
    case 20: 
      l1 = 32648L;
      break;
    default: 
      SWT.error(5);
    }
    this.handle = OS.LoadCursor(0L, l1);
    if ((this.handle == 0L) && (paramInt == 21))
    {
      int i = OS.GetSystemMetrics(13);
      int j = OS.GetSystemMetrics(14);
      if ((i == 32) && (j == 32))
      {
        long l2 = OS.GetModuleHandle(null);
        if (OS.IsWinCE) {
          SWT.error(20);
        }
        this.handle = OS.CreateCursor(l2, 5, 0, 32, 32, HAND_SOURCE, HAND_MASK);
      }
    }
    if (this.handle == 0L) {
      SWT.error(2);
    }
    init();
  }
  
  public Cursor(Device paramDevice, ImageData paramImageData1, ImageData paramImageData2, int paramInt1, int paramInt2)
  {
    super(paramDevice);
    if (paramImageData1 == null) {
      SWT.error(4);
    }
    if (paramImageData2 == null)
    {
      if (paramImageData1.getTransparencyType() != 2) {
        SWT.error(4);
      }
      paramImageData2 = paramImageData1.getTransparencyMask();
    }
    if ((paramImageData2.width != paramImageData1.width) || (paramImageData2.height != paramImageData1.height)) {
      SWT.error(5);
    }
    if ((paramInt1 >= paramImageData1.width) || (paramInt1 < 0) || (paramInt2 >= paramImageData1.height) || (paramInt2 < 0)) {
      SWT.error(5);
    }
    paramImageData2 = ImageData.convertMask(paramImageData2);
    paramImageData1 = ImageData.convertMask(paramImageData1);
    byte[] arrayOfByte1 = ImageData.convertPad(paramImageData1.data, paramImageData1.width, paramImageData1.height, paramImageData1.depth, paramImageData1.scanlinePad, 2);
    byte[] arrayOfByte2 = ImageData.convertPad(paramImageData2.data, paramImageData2.width, paramImageData2.height, paramImageData2.depth, paramImageData2.scanlinePad, 2);
    long l = OS.GetModuleHandle(null);
    if (OS.IsWinCE) {
      SWT.error(20);
    }
    this.handle = OS.CreateCursor(l, paramInt1, paramInt2, paramImageData1.width, paramImageData1.height, arrayOfByte1, arrayOfByte2);
    if (this.handle == 0L) {
      SWT.error(2);
    }
    init();
  }
  
  public Cursor(Device paramDevice, ImageData paramImageData, int paramInt1, int paramInt2)
  {
    super(paramDevice);
    if (paramImageData == null) {
      SWT.error(4);
    }
    if ((paramInt1 >= paramImageData.width) || (paramInt1 < 0) || (paramInt2 >= paramImageData.height) || (paramInt2 < 0)) {
      SWT.error(5);
    }
    long l1 = 0L;
    long l2 = 0L;
    Object localObject2;
    if ((paramImageData.maskData == null) && (paramImageData.transparentPixel == -1) && ((paramImageData.alpha != -1) || (paramImageData.alphaData != null)))
    {
      localObject1 = paramImageData.palette;
      localObject2 = new PaletteData(65280, 16711680, -16777216);
      ImageData localImageData = new ImageData(paramImageData.width, paramImageData.height, 32, (PaletteData)localObject2);
      if (((PaletteData)localObject1).isDirect)
      {
        ImageData.blit(1, paramImageData.data, paramImageData.depth, paramImageData.bytesPerLine, paramImageData.getByteOrder(), 0, 0, paramImageData.width, paramImageData.height, ((PaletteData)localObject1).redMask, ((PaletteData)localObject1).greenMask, ((PaletteData)localObject1).blueMask, 255, null, 0, 0, 0, localImageData.data, localImageData.depth, localImageData.bytesPerLine, localImageData.getByteOrder(), 0, 0, localImageData.width, localImageData.height, ((PaletteData)localObject2).redMask, ((PaletteData)localObject2).greenMask, ((PaletteData)localObject2).blueMask, false, false);
      }
      else
      {
        localObject3 = ((PaletteData)localObject1).getRGBs();
        int i = localObject3.length;
        byte[] arrayOfByte2 = new byte[i];
        byte[] arrayOfByte3 = new byte[i];
        byte[] arrayOfByte4 = new byte[i];
        for (int m = 0; m < localObject3.length; m++)
        {
          Object localObject4 = localObject3[m];
          if (localObject4 != null)
          {
            arrayOfByte2[m] = ((byte)((RGB)localObject4).red);
            arrayOfByte3[m] = ((byte)((RGB)localObject4).green);
            arrayOfByte4[m] = ((byte)((RGB)localObject4).blue);
          }
        }
        ImageData.blit(1, paramImageData.data, paramImageData.depth, paramImageData.bytesPerLine, paramImageData.getByteOrder(), 0, 0, paramImageData.width, paramImageData.height, arrayOfByte2, arrayOfByte3, arrayOfByte4, 255, null, 0, 0, 0, localImageData.data, localImageData.depth, localImageData.bytesPerLine, localImageData.getByteOrder(), 0, 0, localImageData.width, localImageData.height, ((PaletteData)localObject2).redMask, ((PaletteData)localObject2).greenMask, ((PaletteData)localObject2).blueMask, false, false);
      }
      l1 = Image.createDIB(paramImageData.width, paramImageData.height, 32);
      if (l1 == 0L) {
        SWT.error(2);
      }
      Object localObject3 = new BITMAP();
      OS.GetObject(l1, BITMAP.sizeof, (BITMAP)localObject3);
      byte[] arrayOfByte1 = localImageData.data;
      int j;
      if (paramImageData.alpha != -1)
      {
        for (j = 3; j < arrayOfByte1.length; j += 4) {
          arrayOfByte1[j] = ((byte)paramImageData.alpha);
        }
      }
      else if (paramImageData.alphaData != null)
      {
        j = 3;
        for (int k = 0; j < arrayOfByte1.length; k++)
        {
          arrayOfByte1[j] = paramImageData.alphaData[k];
          j += 4;
        }
      }
      OS.MoveMemory(((BITMAP)localObject3).bmBits, arrayOfByte1, arrayOfByte1.length);
      l2 = OS.CreateBitmap(paramImageData.width, paramImageData.height, 1, 1, new byte[((paramImageData.width + 7) / 8 + 3) / 4 * 4 * paramImageData.height]);
      if (l2 == 0L) {
        SWT.error(2);
      }
    }
    else
    {
      localObject1 = paramImageData.getTransparencyMask();
      localObject2 = Image.init(this.device, null, paramImageData, (ImageData)localObject1);
      l1 = localObject2[0];
      l2 = localObject2[1];
    }
    Object localObject1 = new ICONINFO();
    ((ICONINFO)localObject1).fIcon = false;
    ((ICONINFO)localObject1).hbmColor = l1;
    ((ICONINFO)localObject1).hbmMask = l2;
    ((ICONINFO)localObject1).xHotspot = paramInt1;
    ((ICONINFO)localObject1).yHotspot = paramInt2;
    this.handle = OS.CreateIconIndirect((ICONINFO)localObject1);
    OS.DeleteObject(l1);
    OS.DeleteObject(l2);
    if (this.handle == 0L) {
      SWT.error(2);
    }
    this.isIcon = true;
    init();
  }
  
  void destroy()
  {
    if (this.isIcon) {
      OS.DestroyIcon(this.handle);
    } else if (!OS.IsWinCE) {
      OS.DestroyCursor(this.handle);
    }
    this.handle = 0L;
  }
  
  public boolean equals(Object paramObject)
  {
    if (paramObject == this) {
      return true;
    }
    if (!(paramObject instanceof Cursor)) {
      return false;
    }
    Cursor localCursor = (Cursor)paramObject;
    return (this.device == localCursor.device) && (this.handle == localCursor.handle);
  }
  
  public int hashCode()
  {
    return (int)this.handle;
  }
  
  public boolean isDisposed()
  {
    return this.handle == 0L;
  }
  
  public String toString()
  {
    if (isDisposed()) {
      return "Cursor {*DISPOSED*}";
    }
    return "Cursor {" + this.handle + "}";
  }
  
  public static Cursor win32_new(Device paramDevice, int paramInt)
  {
    Cursor localCursor = new Cursor(paramDevice);
    localCursor.handle = paramInt;
    return localCursor;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/graphics/Cursor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */