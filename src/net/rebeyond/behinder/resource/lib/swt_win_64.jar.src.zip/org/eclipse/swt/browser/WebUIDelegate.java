package org.eclipse.swt.browser;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.internal.C;
import org.eclipse.swt.internal.Compatibility;
import org.eclipse.swt.internal.ole.win32.COM;
import org.eclipse.swt.internal.ole.win32.COMObject;
import org.eclipse.swt.internal.ole.win32.GUID;
import org.eclipse.swt.internal.ole.win32.IPropertyBag;
import org.eclipse.swt.internal.ole.win32.IUnknown;
import org.eclipse.swt.internal.ole.win32.VARIANT;
import org.eclipse.swt.internal.webkit.IWebDataSource;
import org.eclipse.swt.internal.webkit.IWebFrame;
import org.eclipse.swt.internal.webkit.IWebFramePrivate;
import org.eclipse.swt.internal.webkit.IWebOpenPanelResultListener;
import org.eclipse.swt.internal.webkit.IWebURLRequest;
import org.eclipse.swt.internal.webkit.IWebView;
import org.eclipse.swt.internal.webkit.WebKit_win32;
import org.eclipse.swt.internal.win32.DOCINFO;
import org.eclipse.swt.internal.win32.OS;
import org.eclipse.swt.internal.win32.PRINTDLG;
import org.eclipse.swt.internal.win32.RECT;
import org.eclipse.swt.internal.win32.TCHAR;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.Monitor;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

class WebUIDelegate
{
  COMObject iWebUIDelegate;
  int refCount = 0;
  String lastHoveredLinkURL;
  Browser browser;
  Point size;
  Point location;
  boolean menuBar = true;
  boolean toolBar = true;
  boolean statusBar = true;
  boolean prompt = true;
  
  WebUIDelegate(Browser paramBrowser)
  {
    createCOMInterfaces();
    this.browser = paramBrowser;
  }
  
  int AddRef()
  {
    this.refCount += 1;
    return this.refCount;
  }
  
  int canTakeFocus(long paramLong1, int paramInt, long paramLong2)
  {
    OS.MoveMemory(paramLong2, new int[] { 1 }, 4);
    return 0;
  }
  
  int contextMenuItemsForElement(long paramLong1, long paramLong2, long paramLong3, long paramLong4)
  {
    Point localPoint = this.browser.getDisplay().getCursorLocation();
    Event localEvent = new Event();
    localEvent.x = localPoint.x;
    localEvent.y = localPoint.y;
    this.browser.notifyListeners(35, localEvent);
    if (localEvent.doit)
    {
      Menu localMenu = this.browser.getMenu();
      if ((localMenu != null) && (!localMenu.isDisposed()))
      {
        if ((localEvent.x != localPoint.x) || (localEvent.y != localPoint.y)) {
          localMenu.setLocation(localEvent.x, localEvent.y);
        }
        localMenu.setVisible(true);
      }
      else
      {
        OS.MoveMemory(paramLong4, new long[] { paramLong3 }, C.PTR_SIZEOF);
        return 0;
      }
    }
    OS.MoveMemory(paramLong4, new long[] { 0L }, C.PTR_SIZEOF);
    return 0;
  }
  
  void createCOMInterfaces()
  {
    this.iWebUIDelegate = new COMObject(new int[] { 2, 0, 0, 3, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 3, 4, 4, 2, 3, 4, 4, 3, 3, 3, 3, 5, 3, 1, 3, 2, 2, 2, 2, 3, 2, 3, 1, 1, 0, 0, 1, 1, 2, 2, 2, 2, 3, 5, 2, 2, 3, 1, 2, 2, 4, 10, 3 })
    {
      public long method0(long[] paramAnonymousArrayOfLong)
      {
        return WebUIDelegate.this.QueryInterface(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method1(long[] paramAnonymousArrayOfLong)
      {
        return WebUIDelegate.this.AddRef();
      }
      
      public long method2(long[] paramAnonymousArrayOfLong)
      {
        return WebUIDelegate.this.Release();
      }
      
      public long method3(long[] paramAnonymousArrayOfLong)
      {
        return WebUIDelegate.this.createWebViewWithRequest(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2]);
      }
      
      public long method4(long[] paramAnonymousArrayOfLong)
      {
        return WebUIDelegate.this.webViewShow(paramAnonymousArrayOfLong[0]);
      }
      
      public long method5(long[] paramAnonymousArrayOfLong)
      {
        return WebUIDelegate.this.webViewClose(paramAnonymousArrayOfLong[0]);
      }
      
      public long method6(long[] paramAnonymousArrayOfLong)
      {
        return -2147467263L;
      }
      
      public long method7(long[] paramAnonymousArrayOfLong)
      {
        return -2147467263L;
      }
      
      public long method8(long[] paramAnonymousArrayOfLong)
      {
        return -2147467263L;
      }
      
      public long method9(long[] paramAnonymousArrayOfLong)
      {
        return -2147467263L;
      }
      
      public long method10(long[] paramAnonymousArrayOfLong)
      {
        return WebUIDelegate.this.setStatusText(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method11(long[] paramAnonymousArrayOfLong)
      {
        return -2147467263L;
      }
      
      public long method12(long[] paramAnonymousArrayOfLong)
      {
        return -2147467263L;
      }
      
      public long method13(long[] paramAnonymousArrayOfLong)
      {
        return WebUIDelegate.this.setToolbarsVisible(paramAnonymousArrayOfLong[0], (int)paramAnonymousArrayOfLong[1]);
      }
      
      public long method14(long[] paramAnonymousArrayOfLong)
      {
        return -2147467263L;
      }
      
      public long method15(long[] paramAnonymousArrayOfLong)
      {
        return WebUIDelegate.this.setStatusBarVisible(paramAnonymousArrayOfLong[0], (int)paramAnonymousArrayOfLong[1]);
      }
      
      public long method16(long[] paramAnonymousArrayOfLong)
      {
        return -2147467263L;
      }
      
      public long method17(long[] paramAnonymousArrayOfLong)
      {
        return -2147467263L;
      }
      
      public long method18(long[] paramAnonymousArrayOfLong)
      {
        return WebUIDelegate.this.setFrame(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method19(long[] paramAnonymousArrayOfLong)
      {
        return -2147467263L;
      }
      
      public long method20(long[] paramAnonymousArrayOfLong)
      {
        return -2147467263L;
      }
      
      public long method21(long[] paramAnonymousArrayOfLong)
      {
        return -2147467263L;
      }
      
      public long method22(long[] paramAnonymousArrayOfLong)
      {
        return WebUIDelegate.this.runJavaScriptAlertPanelWithMessage(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method23(long[] paramAnonymousArrayOfLong)
      {
        return WebUIDelegate.this.runJavaScriptConfirmPanelWithMessage(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2]);
      }
      
      public long method24(long[] paramAnonymousArrayOfLong)
      {
        return WebUIDelegate.this.runJavaScriptTextInputPanelWithPrompt(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2], paramAnonymousArrayOfLong[3]);
      }
      
      public long method25(long[] paramAnonymousArrayOfLong)
      {
        return WebUIDelegate.this.runBeforeUnloadConfirmPanelWithMessage(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2], paramAnonymousArrayOfLong[3]);
      }
      
      public long method26(long[] paramAnonymousArrayOfLong)
      {
        return WebUIDelegate.this.runOpenPanelForFileButtonWithResultListener(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method27(long[] paramAnonymousArrayOfLong)
      {
        return WebUIDelegate.this.mouseDidMoveOverElement(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], (int)paramAnonymousArrayOfLong[2]);
      }
      
      public long method28(long[] paramAnonymousArrayOfLong)
      {
        return WebUIDelegate.this.contextMenuItemsForElement(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2], paramAnonymousArrayOfLong[3]);
      }
      
      public long method29(long[] paramAnonymousArrayOfLong)
      {
        return -2147467263L;
      }
      
      public long method30(long[] paramAnonymousArrayOfLong)
      {
        return -2147467263L;
      }
      
      public long method31(long[] paramAnonymousArrayOfLong)
      {
        return -2147467263L;
      }
      
      public long method32(long[] paramAnonymousArrayOfLong)
      {
        return -2147467263L;
      }
      
      public long method33(long[] paramAnonymousArrayOfLong)
      {
        return -2147467263L;
      }
      
      public long method34(long[] paramAnonymousArrayOfLong)
      {
        return -2147467263L;
      }
      
      public long method35(long[] paramAnonymousArrayOfLong)
      {
        return -2147467263L;
      }
      
      public long method36(long[] paramAnonymousArrayOfLong)
      {
        return -2147467263L;
      }
      
      public long method37(long[] paramAnonymousArrayOfLong)
      {
        return -2147467263L;
      }
      
      public long method38(long[] paramAnonymousArrayOfLong)
      {
        return -2147467263L;
      }
      
      public long method39(long[] paramAnonymousArrayOfLong)
      {
        return -2147467263L;
      }
      
      public long method40(long[] paramAnonymousArrayOfLong)
      {
        return -2147467263L;
      }
      
      public long method41(long[] paramAnonymousArrayOfLong)
      {
        return -2147467263L;
      }
      
      public long method42(long[] paramAnonymousArrayOfLong)
      {
        return WebUIDelegate.this.canTakeFocus(paramAnonymousArrayOfLong[0], (int)paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2]);
      }
      
      public long method43(long[] paramAnonymousArrayOfLong)
      {
        return WebUIDelegate.this.takeFocus(paramAnonymousArrayOfLong[0], (int)paramAnonymousArrayOfLong[1]);
      }
      
      public long method44(long[] paramAnonymousArrayOfLong)
      {
        return -2147467263L;
      }
      
      public long method45(long[] paramAnonymousArrayOfLong)
      {
        return 0L;
      }
      
      public long method46(long[] paramAnonymousArrayOfLong)
      {
        return -2147467263L;
      }
      
      public long method47(long[] paramAnonymousArrayOfLong)
      {
        return -2147467263L;
      }
      
      public long method48(long[] paramAnonymousArrayOfLong)
      {
        return -2147467263L;
      }
      
      public long method49(long[] paramAnonymousArrayOfLong)
      {
        return -2147467263L;
      }
      
      public long method50(long[] paramAnonymousArrayOfLong)
      {
        return -2147467263L;
      }
      
      public long method51(long[] paramAnonymousArrayOfLong)
      {
        return WebUIDelegate.this.printFrame(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method52(long[] paramAnonymousArrayOfLong)
      {
        return -2147467263L;
      }
      
      public long method53(long[] paramAnonymousArrayOfLong)
      {
        return -2147467263L;
      }
      
      public long method54(long[] paramAnonymousArrayOfLong)
      {
        return -2147467263L;
      }
      
      public long method55(long[] paramAnonymousArrayOfLong)
      {
        return -2147467263L;
      }
      
      public long method56(long[] paramAnonymousArrayOfLong)
      {
        return -2147467263L;
      }
      
      public long method57(long[] paramAnonymousArrayOfLong)
      {
        return -2147467263L;
      }
      
      public long method58(long[] paramAnonymousArrayOfLong)
      {
        return -2147467263L;
      }
      
      public long method59(long[] paramAnonymousArrayOfLong)
      {
        return -2147467263L;
      }
      
      public long method60(long[] paramAnonymousArrayOfLong)
      {
        return -2147467263L;
      }
      
      public long method61(long[] paramAnonymousArrayOfLong)
      {
        return -2147467263L;
      }
      
      public long method62(long[] paramAnonymousArrayOfLong)
      {
        return WebUIDelegate.this.setMenuBarVisible(paramAnonymousArrayOfLong[0], (int)paramAnonymousArrayOfLong[1]);
      }
      
      public long method63(long[] paramAnonymousArrayOfLong)
      {
        return -2147467263L;
      }
      
      public long method64(long[] paramAnonymousArrayOfLong)
      {
        return -2147467263L;
      }
      
      public long method65(long[] paramAnonymousArrayOfLong)
      {
        return -2147467263L;
      }
    };
  }
  
  int createWebViewWithRequest(long paramLong1, long paramLong2, long paramLong3)
  {
    WindowEvent localWindowEvent = new WindowEvent(this.browser);
    localWindowEvent.display = this.browser.getDisplay();
    localWindowEvent.widget = this.browser;
    localWindowEvent.required = true;
    OpenWindowListener[] arrayOfOpenWindowListener = this.browser.webBrowser.openWindowListeners;
    for (int i = 0; i < arrayOfOpenWindowListener.length; i++) {
      arrayOfOpenWindowListener[i].open(localWindowEvent);
    }
    IWebView localIWebView = null;
    Browser localBrowser = null;
    if ((localWindowEvent.browser != null) && ((localWindowEvent.browser.webBrowser instanceof WebKit))) {
      localBrowser = localWindowEvent.browser;
    }
    if ((localBrowser != null) && (!localBrowser.isDisposed()))
    {
      localIWebView = ((WebKit)localBrowser.webBrowser).webView;
      OS.MoveMemory(paramLong3, new long[] { localIWebView.getAddress() }, OS.PTR_SIZEOF);
      if (paramLong2 != 0L)
      {
        IWebURLRequest localIWebURLRequest = new IWebURLRequest(paramLong2);
        long[] arrayOfLong = new long[1];
        int j = localIWebURLRequest.URL(arrayOfLong);
        if ((j != 0) || (arrayOfLong[0] == 0L)) {
          return 0;
        }
        String str = WebKit.extractBSTR(arrayOfLong[0]);
        COM.SysFreeString(arrayOfLong[0]);
        if (str.length() != 0)
        {
          arrayOfLong[0] = 0L;
          j = localIWebView.mainFrame(arrayOfLong);
          if ((j != 0) || (arrayOfLong[0] == 0L)) {
            return 0;
          }
          IWebFrame localIWebFrame = new IWebFrame(arrayOfLong[0]);
          localIWebFrame.loadRequest(localIWebURLRequest.getAddress());
          localIWebFrame.Release();
        }
      }
      return 0;
    }
    return -2147467263;
  }
  
  protected void disposeCOMInterfaces()
  {
    if (this.iWebUIDelegate != null)
    {
      this.iWebUIDelegate.dispose();
      this.iWebUIDelegate = null;
    }
  }
  
  long getAddress()
  {
    return this.iWebUIDelegate.getAddress();
  }
  
  int mouseDidMoveOverElement(long paramLong1, long paramLong2, int paramInt)
  {
    if (paramLong2 == 0L) {
      return 0;
    }
    IPropertyBag localIPropertyBag = new IPropertyBag(paramLong2);
    long l1 = WebKit.createBSTR("WebElementLinkURLKey");
    long l2 = OS.GetProcessHeap();
    long l3 = OS.HeapAlloc(l2, 8, VARIANT.sizeof);
    int i = localIPropertyBag.Read(l1, l3, null);
    if ((i != 0) || (l3 == 0L)) {
      return 0;
    }
    String str = null;
    VARIANT localVARIANT = new VARIANT();
    COM.MoveMemory(localVARIANT, l3, VARIANT.sizeof);
    if (localVARIANT.vt == 8) {
      str = WebKit.extractBSTR(localVARIANT.lVal);
    }
    OS.HeapFree(l2, 0, l3);
    StatusTextListener[] arrayOfStatusTextListener = this.browser.webBrowser.statusTextListeners;
    if ((str == null) || (str.length() == 0))
    {
      if (this.lastHoveredLinkURL == null) {
        return 0;
      }
      this.lastHoveredLinkURL = null;
      localStatusTextEvent = new StatusTextEvent(this.browser);
      localStatusTextEvent.display = this.browser.getDisplay();
      localStatusTextEvent.widget = this.browser;
      localStatusTextEvent.text = "";
      for (j = 0; j < arrayOfStatusTextListener.length; j++) {
        arrayOfStatusTextListener[j].changed(localStatusTextEvent);
      }
      return 0;
    }
    if (str.equals(this.lastHoveredLinkURL)) {
      return 0;
    }
    this.lastHoveredLinkURL = str;
    StatusTextEvent localStatusTextEvent = new StatusTextEvent(this.browser);
    localStatusTextEvent.display = this.browser.getDisplay();
    localStatusTextEvent.widget = this.browser;
    localStatusTextEvent.text = str;
    for (int j = 0; j < arrayOfStatusTextListener.length; j++) {
      arrayOfStatusTextListener[j].changed(localStatusTextEvent);
    }
    return 0;
  }
  
  int printFrame(long paramLong1, long paramLong2)
  {
    IWebFrame localIWebFrame = new IWebFrame(paramLong2);
    PRINTDLG localPRINTDLG = new PRINTDLG();
    localPRINTDLG.lStructSize = PRINTDLG.sizeof;
    localPRINTDLG.Flags = 256;
    if (!OS.PrintDlg(localPRINTDLG)) {
      return 0;
    }
    long l1 = localPRINTDLG.hDC;
    long[] arrayOfLong = new long[1];
    int i = localIWebFrame.QueryInterface(WebKit_win32.IID_IWebFramePrivate, arrayOfLong);
    if ((i != 0) || (arrayOfLong[0] == 0L)) {
      return 0;
    }
    IWebFramePrivate localIWebFramePrivate = new IWebFramePrivate(arrayOfLong[0]);
    localIWebFramePrivate.setInPrintingMode(1, l1);
    int[] arrayOfInt = new int[1];
    i = localIWebFramePrivate.getPrintedPageCount(l1, arrayOfInt);
    if ((i != 0) || (arrayOfInt[0] == 0))
    {
      localIWebFramePrivate.Release();
      return 0;
    }
    int j = arrayOfInt[0];
    String str = null;
    arrayOfLong[0] = 0L;
    i = localIWebFrame.dataSource(arrayOfLong);
    if ((i == 0) && (arrayOfLong[0] != 0L))
    {
      localObject = new IWebDataSource(arrayOfLong[0]);
      arrayOfLong[0] = 0L;
      i = ((IWebDataSource)localObject).pageTitle(arrayOfLong);
      ((IWebDataSource)localObject).Release();
      if ((i == 0) && (arrayOfLong[0] != 0L))
      {
        str = WebKit.extractBSTR(arrayOfLong[0]);
        COM.SysFreeString(arrayOfLong[0]);
      }
    }
    Object localObject = new DOCINFO();
    ((DOCINFO)localObject).cbSize = DOCINFO.sizeof;
    long l2 = OS.GetProcessHeap();
    long l3 = 0L;
    int m;
    if ((str != null) && (str.length() != 0))
    {
      TCHAR localTCHAR = new TCHAR(0, str, true);
      m = localTCHAR.length() * TCHAR.sizeof;
      l3 = OS.HeapAlloc(l2, 8, m);
      OS.MoveMemory(l3, localTCHAR, m);
      ((DOCINFO)localObject).lpszDocName = l3;
    }
    int k = OS.StartDoc(l1, (DOCINFO)localObject);
    if (l3 != 0L) {
      OS.HeapFree(l2, 0, l3);
    }
    if (k >= 0)
    {
      for (m = 0; m < j; m++)
      {
        OS.StartPage(l1);
        localIWebFramePrivate.spoolPages(l1, m, m, null);
        OS.EndPage(l1);
      }
      localIWebFramePrivate.setInPrintingMode(0, l1);
      OS.EndDoc(l1);
    }
    localIWebFramePrivate.Release();
    return 0;
  }
  
  int QueryInterface(long paramLong1, long paramLong2)
  {
    if ((paramLong1 == 0L) || (paramLong2 == 0L)) {
      return -2147024809;
    }
    GUID localGUID = new GUID();
    COM.MoveMemory(localGUID, paramLong1, GUID.sizeof);
    if (COM.IsEqualGUID(localGUID, COM.IIDIUnknown))
    {
      COM.MoveMemory(paramLong2, new long[] { this.iWebUIDelegate.getAddress() }, OS.PTR_SIZEOF);
      new IUnknown(this.iWebUIDelegate.getAddress()).AddRef();
      return 0;
    }
    if (COM.IsEqualGUID(localGUID, WebKit_win32.IID_IWebUIDelegate))
    {
      COM.MoveMemory(paramLong2, new long[] { this.iWebUIDelegate.getAddress() }, OS.PTR_SIZEOF);
      new IUnknown(this.iWebUIDelegate.getAddress()).AddRef();
      return 0;
    }
    COM.MoveMemory(paramLong2, new long[] { 0L }, OS.PTR_SIZEOF);
    return -2147467262;
  }
  
  int Release()
  {
    this.refCount -= 1;
    if (this.refCount == 0) {
      disposeCOMInterfaces();
    }
    return this.refCount;
  }
  
  int runBeforeUnloadConfirmPanelWithMessage(long paramLong1, long paramLong2, long paramLong3, long paramLong4)
  {
    if (!this.prompt) {
      return 0;
    }
    Shell localShell = this.browser.getShell();
    String str = WebKit.extractBSTR(paramLong2);
    StringBuffer localStringBuffer = new StringBuffer(Compatibility.getMessage("SWT_OnBeforeUnload_Message1"));
    localStringBuffer.append("\n\n");
    localStringBuffer.append(str);
    localStringBuffer.append("\n\n");
    localStringBuffer.append(Compatibility.getMessage("SWT_OnBeforeUnload_Message2"));
    MessageBox localMessageBox = new MessageBox(localShell, 292);
    localMessageBox.setMessage(localStringBuffer.toString());
    int[] arrayOfInt = new int[1];
    arrayOfInt[0] = (localMessageBox.open() == 32 ? 1 : 0);
    OS.MoveMemory(paramLong4, arrayOfInt, 4);
    return 0;
  }
  
  int runJavaScriptAlertPanelWithMessage(long paramLong1, long paramLong2)
  {
    String str = WebKit.extractBSTR(paramLong2);
    showAlertMessage("Javascript", str);
    return 0;
  }
  
  int runJavaScriptConfirmPanelWithMessage(long paramLong1, long paramLong2, long paramLong3)
  {
    String str = WebKit.extractBSTR(paramLong2);
    int[] arrayOfInt = new int[1];
    arrayOfInt[0] = (showConfirmPanel("Javascript", str) == 32 ? 1 : 0);
    OS.MoveMemory(paramLong3, arrayOfInt, 4);
    return 0;
  }
  
  int runJavaScriptTextInputPanelWithPrompt(long paramLong1, long paramLong2, long paramLong3, long paramLong4)
  {
    String str1 = WebKit.extractBSTR(paramLong2);
    String str2 = WebKit.extractBSTR(paramLong3);
    String str3 = showTextPrompter("Javascript", str1, str2);
    long[] arrayOfLong = new long[1];
    if (str3 != null) {
      arrayOfLong[0] = WebKit.createBSTR(str3);
    }
    OS.MoveMemory(paramLong4, arrayOfLong, C.PTR_SIZEOF);
    return 0;
  }
  
  int runOpenPanelForFileButtonWithResultListener(long paramLong1, long paramLong2)
  {
    Shell localShell = this.browser.getShell();
    FileDialog localFileDialog = new FileDialog(localShell, 0);
    String str = localFileDialog.open();
    IWebOpenPanelResultListener localIWebOpenPanelResultListener = new IWebOpenPanelResultListener(paramLong2);
    if (str == null) {
      localIWebOpenPanelResultListener.cancel();
    } else {
      localIWebOpenPanelResultListener.chooseFilename(WebKit.createBSTR(str));
    }
    return 0;
  }
  
  int setFrame(long paramLong1, long paramLong2)
  {
    RECT localRECT = new RECT();
    COM.MoveMemory(localRECT, paramLong2, RECT.sizeof);
    this.location = this.browser.getDisplay().map(this.browser, null, localRECT.left, localRECT.top);
    int i = localRECT.right - localRECT.left;
    int j = localRECT.bottom - localRECT.top;
    if ((j < 0) || (i < 0) || ((i == 0) && (j == 0))) {
      return 0;
    }
    this.size = new Point(i, j);
    return 0;
  }
  
  int setMenuBarVisible(long paramLong, int paramInt)
  {
    this.menuBar = (paramInt == 1);
    return 0;
  }
  
  int setStatusBarVisible(long paramLong, int paramInt)
  {
    this.statusBar = (paramInt == 1);
    return 0;
  }
  
  int setStatusText(long paramLong1, long paramLong2)
  {
    String str = WebKit.extractBSTR(paramLong2);
    if (str.length() == 0) {
      return 0;
    }
    StatusTextEvent localStatusTextEvent = new StatusTextEvent(this.browser);
    localStatusTextEvent.display = this.browser.getDisplay();
    localStatusTextEvent.widget = this.browser;
    localStatusTextEvent.text = str;
    StatusTextListener[] arrayOfStatusTextListener = this.browser.webBrowser.statusTextListeners;
    for (int i = 0; i < arrayOfStatusTextListener.length; i++) {
      arrayOfStatusTextListener[i].changed(localStatusTextEvent);
    }
    return 0;
  }
  
  int setToolbarsVisible(long paramLong, int paramInt)
  {
    this.toolBar = (paramInt == 1);
    return 0;
  }
  
  void showAlertMessage(String paramString1, String paramString2)
  {
    Shell localShell1 = this.browser.getShell();
    final Shell localShell2 = new Shell(localShell1, 67680);
    GridLayout localGridLayout = new GridLayout(2, false);
    localGridLayout.horizontalSpacing = 10;
    localGridLayout.verticalSpacing = 20;
    localGridLayout.marginWidth = (localGridLayout.marginHeight = 10);
    localShell2.setLayout(localGridLayout);
    localShell2.setText(paramString1);
    Label localLabel = new Label(localShell2, 0);
    Image localImage = localShell2.getDisplay().getSystemImage(8);
    localLabel.setImage(localImage);
    localLabel = new Label(localShell2, 64);
    localLabel.setText(paramString2);
    Monitor localMonitor = localShell1.getMonitor();
    int i = localMonitor.getBounds().width * 2 / 3;
    int j = localLabel.computeSize(-1, -1).x;
    GridData localGridData1 = new GridData(4, 16777216, true, false);
    localGridData1.widthHint = Math.min(j, i);
    localLabel.setLayoutData(localGridData1);
    Button localButton = new Button(localShell2, 8);
    localButton.setText(SWT.getMessage("SWT_OK"));
    j = localButton.computeSize(-1, -1).x;
    GridData localGridData2 = new GridData();
    localGridData2.horizontalAlignment = 16777216;
    localGridData2.verticalAlignment = 16777216;
    localGridData2.horizontalSpan = 2;
    localGridData2.widthHint = Math.max(j, 75);
    localButton.setLayoutData(localGridData2);
    localButton.addSelectionListener(new SelectionAdapter()
    {
      public void widgetSelected(SelectionEvent paramAnonymousSelectionEvent)
      {
        localShell2.dispose();
      }
    });
    localShell2.setDefaultButton(localButton);
    localShell2.pack();
    Rectangle localRectangle1 = localShell1.getBounds();
    Rectangle localRectangle2 = localShell2.getBounds();
    int k = localShell1.getLocation().x + (localRectangle1.width - localRectangle2.width) / 2;
    int m = localShell1.getLocation().y + (localRectangle1.height - localRectangle2.height) / 2;
    localShell2.setLocation(k, m);
    localShell2.open();
    Display localDisplay = this.browser.getDisplay();
    while (!localShell2.isDisposed()) {
      if (!localDisplay.readAndDispatch()) {
        localDisplay.sleep();
      }
    }
  }
  
  int showConfirmPanel(String paramString1, String paramString2)
  {
    Shell localShell1 = this.browser.getShell();
    final Shell localShell2 = new Shell(localShell1, 67680);
    GridLayout localGridLayout = new GridLayout(2, false);
    localGridLayout.horizontalSpacing = 10;
    localGridLayout.verticalSpacing = 20;
    localGridLayout.marginWidth = (localGridLayout.marginHeight = 10);
    localShell2.setLayout(localGridLayout);
    localShell2.setText(paramString1);
    Label localLabel = new Label(localShell2, 0);
    Image localImage = localShell2.getDisplay().getSystemImage(4);
    localLabel.setImage(localImage);
    localLabel.setLayoutData(new GridData());
    localLabel = new Label(localShell2, 64);
    localLabel.setText(paramString2);
    Monitor localMonitor = localShell1.getMonitor();
    int i = localMonitor.getBounds().width * 2 / 3;
    int j = localLabel.computeSize(-1, -1).x;
    GridData localGridData1 = new GridData(4, 16777216, true, false);
    localGridData1.widthHint = Math.min(j, i);
    localLabel.setLayoutData(localGridData1);
    Composite localComposite = new Composite(localShell2, 0);
    localGridData1 = new GridData(16777216, 16777216, true, true, 2, 1);
    localComposite.setLayoutData(localGridData1);
    localComposite.setLayout(new GridLayout(2, true));
    Button localButton1 = new Button(localComposite, 8);
    localButton1.setText(SWT.getMessage("SWT_OK"));
    GridData localGridData2 = new GridData();
    localGridData2.horizontalAlignment = 16777216;
    localGridData2.verticalAlignment = 16777216;
    localButton1.setLayoutData(localGridData2);
    Button localButton2 = new Button(localComposite, 8);
    localButton2.setText(SWT.getMessage("SWT_Cancel"));
    localButton2.setLayoutData(localGridData2);
    j = localButton2.computeSize(-1, -1).x;
    localGridData2.widthHint = Math.max(j, 75);
    final int[] arrayOfInt = new int[1];
    localButton1.addSelectionListener(new SelectionAdapter()
    {
      public void widgetSelected(SelectionEvent paramAnonymousSelectionEvent)
      {
        arrayOfInt[0] = 32;
        localShell2.dispose();
      }
    });
    localButton2.addSelectionListener(new SelectionAdapter()
    {
      public void widgetSelected(SelectionEvent paramAnonymousSelectionEvent)
      {
        arrayOfInt[0] = 256;
        localShell2.dispose();
      }
    });
    localShell2.setDefaultButton(localButton1);
    localShell2.pack();
    Rectangle localRectangle1 = localShell1.getBounds();
    Rectangle localRectangle2 = localShell2.getBounds();
    int k = localShell1.getLocation().x + (localRectangle1.width - localRectangle2.width) / 2;
    int m = localShell1.getLocation().y + (localRectangle1.height - localRectangle2.height) / 2;
    localShell2.setLocation(k, m);
    localShell2.open();
    Display localDisplay = this.browser.getDisplay();
    while (!localShell2.isDisposed()) {
      if (!localDisplay.readAndDispatch()) {
        localDisplay.sleep();
      }
    }
    return arrayOfInt[0];
  }
  
  String showTextPrompter(String paramString1, String paramString2, String paramString3)
  {
    Shell localShell1 = this.browser.getShell();
    final Shell localShell2 = new Shell(localShell1, 67680);
    localShell2.setLayout(new GridLayout());
    localShell2.setText(paramString1);
    Label localLabel = new Label(localShell2, 0);
    localLabel.setLayoutData(new GridData(768));
    localLabel.setText(paramString2);
    final Text localText = new Text(localShell2, 2052);
    GridData localGridData = new GridData(768);
    localGridData.widthHint = 300;
    localText.setLayoutData(localGridData);
    localText.setText(paramString3);
    Composite localComposite = new Composite(localShell2, 0);
    localComposite.setLayout(new GridLayout(2, true));
    localComposite.setLayoutData(new GridData(64));
    Button localButton1 = new Button(localComposite, 8);
    localButton1.setText(SWT.getMessage("SWT_OK"));
    localButton1.setLayoutData(new GridData(768));
    final String[] arrayOfString = new String[1];
    localButton1.addSelectionListener(new SelectionAdapter()
    {
      public void widgetSelected(SelectionEvent paramAnonymousSelectionEvent)
      {
        arrayOfString[0] = localText.getText();
        localShell2.dispose();
      }
    });
    Button localButton2 = new Button(localComposite, 8);
    localButton2.setText(SWT.getMessage("SWT_Cancel"));
    localButton2.setLayoutData(new GridData(768));
    localButton2.addSelectionListener(new SelectionAdapter()
    {
      public void widgetSelected(SelectionEvent paramAnonymousSelectionEvent)
      {
        localShell2.dispose();
      }
    });
    localShell2.setDefaultButton(localButton1);
    localShell2.pack();
    Rectangle localRectangle1 = localShell1.getBounds();
    Rectangle localRectangle2 = localShell2.getBounds();
    int i = localShell1.getLocation().x + (localRectangle1.width - localRectangle2.width) / 2;
    int j = localShell1.getLocation().y + (localRectangle1.height - localRectangle2.height) / 2;
    localShell2.setLocation(i, j);
    localShell2.open();
    Display localDisplay = this.browser.getDisplay();
    while (!localShell2.isDisposed()) {
      if (!localDisplay.readAndDispatch()) {
        localDisplay.sleep();
      }
    }
    return arrayOfString[0];
  }
  
  int takeFocus(long paramLong, int paramInt)
  {
    int i = paramInt == 0 ? 8 : 16;
    ((WebKit)this.browser.webBrowser).traverseOut = true;
    this.browser.traverse(i);
    return 0;
  }
  
  int webViewClose(long paramLong)
  {
    WindowEvent localWindowEvent = new WindowEvent(this.browser);
    localWindowEvent.display = this.browser.getDisplay();
    localWindowEvent.widget = this.browser;
    CloseWindowListener[] arrayOfCloseWindowListener = this.browser.webBrowser.closeWindowListeners;
    for (int i = 0; i < arrayOfCloseWindowListener.length; i++) {
      arrayOfCloseWindowListener[i].close(localWindowEvent);
    }
    this.browser.dispose();
    return 0;
  }
  
  int webViewFrame(long paramLong1, long paramLong2)
  {
    RECT localRECT = new RECT();
    OS.MoveMemory(paramLong2, localRECT, RECT.sizeof);
    return 0;
  }
  
  int webViewShow(long paramLong)
  {
    WindowEvent localWindowEvent = new WindowEvent(this.browser);
    localWindowEvent.display = this.browser.getDisplay();
    localWindowEvent.widget = this.browser;
    if (this.location != null) {
      localWindowEvent.location = this.location;
    }
    if (this.size != null) {
      localWindowEvent.size = this.size;
    }
    localWindowEvent.addressBar = this.toolBar;
    localWindowEvent.menuBar = this.menuBar;
    localWindowEvent.statusBar = this.statusBar;
    localWindowEvent.toolBar = this.toolBar;
    VisibilityWindowListener[] arrayOfVisibilityWindowListener = this.browser.webBrowser.visibilityWindowListeners;
    for (int i = 0; i < arrayOfVisibilityWindowListener.length; i++) {
      arrayOfVisibilityWindowListener[i].show(localWindowEvent);
    }
    this.location = null;
    this.size = null;
    return 0;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/browser/WebUIDelegate.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */