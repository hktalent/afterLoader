package org.eclipse.swt.internal.mozilla;

import java.util.Hashtable;
import org.eclipse.swt.SWT;
import org.eclipse.swt.internal.C;
import org.eclipse.swt.internal.Callback;
import org.eclipse.swt.internal.LONG;

public class XPCOMObject
{
  static boolean IsSolaris;
  long ppVtable;
  private static final int MAX_ARG_COUNT = 12;
  private static final int MAX_VTABLE_LENGTH = 80;
  static final int OS_OFFSET = IsSolaris ? 2 : 0;
  private static Callback[][] Callbacks = new Callback[80 + OS_OFFSET][12];
  private static Hashtable ObjectMap = new Hashtable();
  
  public XPCOMObject(int[] paramArrayOfInt)
  {
    long[] arrayOfLong = new long[paramArrayOfInt.length + OS_OFFSET];
    synchronized (Callbacks)
    {
      int i = 0;
      int j = paramArrayOfInt.length;
      while (i < j)
      {
        if (Callbacks[(i + OS_OFFSET)][paramArrayOfInt[i]] == null) {
          Callbacks[(i + OS_OFFSET)][paramArrayOfInt[i]] = new Callback(getClass(), "callback" + i, paramArrayOfInt[i] + 1, true, -2147467259L);
        }
        arrayOfLong[(i + OS_OFFSET)] = Callbacks[(i + OS_OFFSET)][paramArrayOfInt[i]].getAddress();
        if (arrayOfLong[(i + OS_OFFSET)] == 0L) {
          SWT.error(3);
        }
        i++;
      }
    }
    long l = C.malloc(C.PTR_SIZEOF * (paramArrayOfInt.length + OS_OFFSET));
    XPCOM.memmove(l, arrayOfLong, C.PTR_SIZEOF * (paramArrayOfInt.length + OS_OFFSET));
    this.ppVtable = C.malloc(C.PTR_SIZEOF);
    XPCOM.memmove(this.ppVtable, new long[] { l }, C.PTR_SIZEOF);
    ObjectMap.put(new LONG(this.ppVtable), this);
  }
  
  public long getVtable()
  {
    return this.ppVtable;
  }
  
  static long callback0(long[] paramArrayOfLong)
  {
    long l = paramArrayOfLong[0];
    Object localObject = ObjectMap.get(new LONG(l));
    if (localObject == null) {
      return -2147467259L;
    }
    long[] arrayOfLong = new long[paramArrayOfLong.length - 1];
    System.arraycopy(paramArrayOfLong, 1, arrayOfLong, 0, arrayOfLong.length);
    return ((XPCOMObject)localObject).method0(arrayOfLong);
  }
  
  static long callback1(long[] paramArrayOfLong)
  {
    long l = paramArrayOfLong[0];
    Object localObject = ObjectMap.get(new LONG(l));
    if (localObject == null) {
      return -2147467259L;
    }
    long[] arrayOfLong = new long[paramArrayOfLong.length - 1];
    System.arraycopy(paramArrayOfLong, 1, arrayOfLong, 0, arrayOfLong.length);
    return ((XPCOMObject)localObject).method1(arrayOfLong);
  }
  
  static long callback10(long[] paramArrayOfLong)
  {
    long l = paramArrayOfLong[0];
    Object localObject = ObjectMap.get(new LONG(l));
    if (localObject == null) {
      return -2147467259L;
    }
    long[] arrayOfLong = new long[paramArrayOfLong.length - 1];
    System.arraycopy(paramArrayOfLong, 1, arrayOfLong, 0, arrayOfLong.length);
    return ((XPCOMObject)localObject).method10(arrayOfLong);
  }
  
  static long callback11(long[] paramArrayOfLong)
  {
    long l = paramArrayOfLong[0];
    Object localObject = ObjectMap.get(new LONG(l));
    if (localObject == null) {
      return -2147467259L;
    }
    long[] arrayOfLong = new long[paramArrayOfLong.length - 1];
    System.arraycopy(paramArrayOfLong, 1, arrayOfLong, 0, arrayOfLong.length);
    return ((XPCOMObject)localObject).method11(arrayOfLong);
  }
  
  static long callback12(long[] paramArrayOfLong)
  {
    long l = paramArrayOfLong[0];
    Object localObject = ObjectMap.get(new LONG(l));
    if (localObject == null) {
      return -2147467259L;
    }
    long[] arrayOfLong = new long[paramArrayOfLong.length - 1];
    System.arraycopy(paramArrayOfLong, 1, arrayOfLong, 0, arrayOfLong.length);
    return ((XPCOMObject)localObject).method12(arrayOfLong);
  }
  
  static long callback13(long[] paramArrayOfLong)
  {
    long l = paramArrayOfLong[0];
    Object localObject = ObjectMap.get(new LONG(l));
    if (localObject == null) {
      return -2147467259L;
    }
    long[] arrayOfLong = new long[paramArrayOfLong.length - 1];
    System.arraycopy(paramArrayOfLong, 1, arrayOfLong, 0, arrayOfLong.length);
    return ((XPCOMObject)localObject).method13(arrayOfLong);
  }
  
  static long callback14(long[] paramArrayOfLong)
  {
    long l = paramArrayOfLong[0];
    Object localObject = ObjectMap.get(new LONG(l));
    if (localObject == null) {
      return -2147467259L;
    }
    long[] arrayOfLong = new long[paramArrayOfLong.length - 1];
    System.arraycopy(paramArrayOfLong, 1, arrayOfLong, 0, arrayOfLong.length);
    return ((XPCOMObject)localObject).method14(arrayOfLong);
  }
  
  static long callback15(long[] paramArrayOfLong)
  {
    long l = paramArrayOfLong[0];
    Object localObject = ObjectMap.get(new LONG(l));
    if (localObject == null) {
      return -2147467259L;
    }
    long[] arrayOfLong = new long[paramArrayOfLong.length - 1];
    System.arraycopy(paramArrayOfLong, 1, arrayOfLong, 0, arrayOfLong.length);
    return ((XPCOMObject)localObject).method15(arrayOfLong);
  }
  
  static long callback16(long[] paramArrayOfLong)
  {
    long l = paramArrayOfLong[0];
    Object localObject = ObjectMap.get(new LONG(l));
    if (localObject == null) {
      return -2147467259L;
    }
    long[] arrayOfLong = new long[paramArrayOfLong.length - 1];
    System.arraycopy(paramArrayOfLong, 1, arrayOfLong, 0, arrayOfLong.length);
    return ((XPCOMObject)localObject).method16(arrayOfLong);
  }
  
  static long callback17(long[] paramArrayOfLong)
  {
    long l = paramArrayOfLong[0];
    Object localObject = ObjectMap.get(new LONG(l));
    if (localObject == null) {
      return -2147467259L;
    }
    long[] arrayOfLong = new long[paramArrayOfLong.length - 1];
    System.arraycopy(paramArrayOfLong, 1, arrayOfLong, 0, arrayOfLong.length);
    return ((XPCOMObject)localObject).method17(arrayOfLong);
  }
  
  static long callback18(long[] paramArrayOfLong)
  {
    long l = paramArrayOfLong[0];
    Object localObject = ObjectMap.get(new LONG(l));
    if (localObject == null) {
      return -2147467259L;
    }
    long[] arrayOfLong = new long[paramArrayOfLong.length - 1];
    System.arraycopy(paramArrayOfLong, 1, arrayOfLong, 0, arrayOfLong.length);
    return ((XPCOMObject)localObject).method18(arrayOfLong);
  }
  
  static long callback19(long[] paramArrayOfLong)
  {
    long l = paramArrayOfLong[0];
    Object localObject = ObjectMap.get(new LONG(l));
    if (localObject == null) {
      return -2147467259L;
    }
    long[] arrayOfLong = new long[paramArrayOfLong.length - 1];
    System.arraycopy(paramArrayOfLong, 1, arrayOfLong, 0, arrayOfLong.length);
    return ((XPCOMObject)localObject).method19(arrayOfLong);
  }
  
  static long callback2(long[] paramArrayOfLong)
  {
    long l = paramArrayOfLong[0];
    Object localObject = ObjectMap.get(new LONG(l));
    if (localObject == null) {
      return -2147467259L;
    }
    long[] arrayOfLong = new long[paramArrayOfLong.length - 1];
    System.arraycopy(paramArrayOfLong, 1, arrayOfLong, 0, arrayOfLong.length);
    return ((XPCOMObject)localObject).method2(arrayOfLong);
  }
  
  static long callback20(long[] paramArrayOfLong)
  {
    long l = paramArrayOfLong[0];
    Object localObject = ObjectMap.get(new LONG(l));
    if (localObject == null) {
      return -2147467259L;
    }
    long[] arrayOfLong = new long[paramArrayOfLong.length - 1];
    System.arraycopy(paramArrayOfLong, 1, arrayOfLong, 0, arrayOfLong.length);
    return ((XPCOMObject)localObject).method20(arrayOfLong);
  }
  
  static long callback21(long[] paramArrayOfLong)
  {
    long l = paramArrayOfLong[0];
    Object localObject = ObjectMap.get(new LONG(l));
    if (localObject == null) {
      return -2147467259L;
    }
    long[] arrayOfLong = new long[paramArrayOfLong.length - 1];
    System.arraycopy(paramArrayOfLong, 1, arrayOfLong, 0, arrayOfLong.length);
    return ((XPCOMObject)localObject).method21(arrayOfLong);
  }
  
  static long callback22(long[] paramArrayOfLong)
  {
    long l = paramArrayOfLong[0];
    Object localObject = ObjectMap.get(new LONG(l));
    if (localObject == null) {
      return -2147467259L;
    }
    long[] arrayOfLong = new long[paramArrayOfLong.length - 1];
    System.arraycopy(paramArrayOfLong, 1, arrayOfLong, 0, arrayOfLong.length);
    return ((XPCOMObject)localObject).method22(arrayOfLong);
  }
  
  static long callback23(long[] paramArrayOfLong)
  {
    long l = paramArrayOfLong[0];
    Object localObject = ObjectMap.get(new LONG(l));
    if (localObject == null) {
      return -2147467259L;
    }
    long[] arrayOfLong = new long[paramArrayOfLong.length - 1];
    System.arraycopy(paramArrayOfLong, 1, arrayOfLong, 0, arrayOfLong.length);
    return ((XPCOMObject)localObject).method23(arrayOfLong);
  }
  
  static long callback24(long[] paramArrayOfLong)
  {
    long l = paramArrayOfLong[0];
    Object localObject = ObjectMap.get(new LONG(l));
    if (localObject == null) {
      return -2147467259L;
    }
    long[] arrayOfLong = new long[paramArrayOfLong.length - 1];
    System.arraycopy(paramArrayOfLong, 1, arrayOfLong, 0, arrayOfLong.length);
    return ((XPCOMObject)localObject).method24(arrayOfLong);
  }
  
  static long callback25(long[] paramArrayOfLong)
  {
    long l = paramArrayOfLong[0];
    Object localObject = ObjectMap.get(new LONG(l));
    if (localObject == null) {
      return -2147467259L;
    }
    long[] arrayOfLong = new long[paramArrayOfLong.length - 1];
    System.arraycopy(paramArrayOfLong, 1, arrayOfLong, 0, arrayOfLong.length);
    return ((XPCOMObject)localObject).method25(arrayOfLong);
  }
  
  static long callback26(long[] paramArrayOfLong)
  {
    long l = paramArrayOfLong[0];
    Object localObject = ObjectMap.get(new LONG(l));
    if (localObject == null) {
      return -2147467259L;
    }
    long[] arrayOfLong = new long[paramArrayOfLong.length - 1];
    System.arraycopy(paramArrayOfLong, 1, arrayOfLong, 0, arrayOfLong.length);
    return ((XPCOMObject)localObject).method26(arrayOfLong);
  }
  
  static long callback27(long[] paramArrayOfLong)
  {
    long l = paramArrayOfLong[0];
    Object localObject = ObjectMap.get(new LONG(l));
    if (localObject == null) {
      return -2147467259L;
    }
    long[] arrayOfLong = new long[paramArrayOfLong.length - 1];
    System.arraycopy(paramArrayOfLong, 1, arrayOfLong, 0, arrayOfLong.length);
    return ((XPCOMObject)localObject).method27(arrayOfLong);
  }
  
  static long callback28(long[] paramArrayOfLong)
  {
    long l = paramArrayOfLong[0];
    Object localObject = ObjectMap.get(new LONG(l));
    if (localObject == null) {
      return -2147467259L;
    }
    long[] arrayOfLong = new long[paramArrayOfLong.length - 1];
    System.arraycopy(paramArrayOfLong, 1, arrayOfLong, 0, arrayOfLong.length);
    return ((XPCOMObject)localObject).method28(arrayOfLong);
  }
  
  static long callback29(long[] paramArrayOfLong)
  {
    long l = paramArrayOfLong[0];
    Object localObject = ObjectMap.get(new LONG(l));
    if (localObject == null) {
      return -2147467259L;
    }
    long[] arrayOfLong = new long[paramArrayOfLong.length - 1];
    System.arraycopy(paramArrayOfLong, 1, arrayOfLong, 0, arrayOfLong.length);
    return ((XPCOMObject)localObject).method29(arrayOfLong);
  }
  
  static long callback3(long[] paramArrayOfLong)
  {
    long l = paramArrayOfLong[0];
    Object localObject = ObjectMap.get(new LONG(l));
    if (localObject == null) {
      return -2147467259L;
    }
    long[] arrayOfLong = new long[paramArrayOfLong.length - 1];
    System.arraycopy(paramArrayOfLong, 1, arrayOfLong, 0, arrayOfLong.length);
    return ((XPCOMObject)localObject).method3(arrayOfLong);
  }
  
  static long callback30(long[] paramArrayOfLong)
  {
    long l = paramArrayOfLong[0];
    Object localObject = ObjectMap.get(new LONG(l));
    if (localObject == null) {
      return -2147467259L;
    }
    long[] arrayOfLong = new long[paramArrayOfLong.length - 1];
    System.arraycopy(paramArrayOfLong, 1, arrayOfLong, 0, arrayOfLong.length);
    return ((XPCOMObject)localObject).method30(arrayOfLong);
  }
  
  static long callback31(long[] paramArrayOfLong)
  {
    long l = paramArrayOfLong[0];
    Object localObject = ObjectMap.get(new LONG(l));
    if (localObject == null) {
      return -2147467259L;
    }
    long[] arrayOfLong = new long[paramArrayOfLong.length - 1];
    System.arraycopy(paramArrayOfLong, 1, arrayOfLong, 0, arrayOfLong.length);
    return ((XPCOMObject)localObject).method31(arrayOfLong);
  }
  
  static long callback32(long[] paramArrayOfLong)
  {
    long l = paramArrayOfLong[0];
    Object localObject = ObjectMap.get(new LONG(l));
    if (localObject == null) {
      return -2147467259L;
    }
    long[] arrayOfLong = new long[paramArrayOfLong.length - 1];
    System.arraycopy(paramArrayOfLong, 1, arrayOfLong, 0, arrayOfLong.length);
    return ((XPCOMObject)localObject).method32(arrayOfLong);
  }
  
  static long callback33(long[] paramArrayOfLong)
  {
    long l = paramArrayOfLong[0];
    Object localObject = ObjectMap.get(new LONG(l));
    if (localObject == null) {
      return -2147467259L;
    }
    long[] arrayOfLong = new long[paramArrayOfLong.length - 1];
    System.arraycopy(paramArrayOfLong, 1, arrayOfLong, 0, arrayOfLong.length);
    return ((XPCOMObject)localObject).method33(arrayOfLong);
  }
  
  static long callback34(long[] paramArrayOfLong)
  {
    long l = paramArrayOfLong[0];
    Object localObject = ObjectMap.get(new LONG(l));
    if (localObject == null) {
      return -2147467259L;
    }
    long[] arrayOfLong = new long[paramArrayOfLong.length - 1];
    System.arraycopy(paramArrayOfLong, 1, arrayOfLong, 0, arrayOfLong.length);
    return ((XPCOMObject)localObject).method34(arrayOfLong);
  }
  
  static long callback35(long[] paramArrayOfLong)
  {
    long l = paramArrayOfLong[0];
    Object localObject = ObjectMap.get(new LONG(l));
    if (localObject == null) {
      return -2147467259L;
    }
    long[] arrayOfLong = new long[paramArrayOfLong.length - 1];
    System.arraycopy(paramArrayOfLong, 1, arrayOfLong, 0, arrayOfLong.length);
    return ((XPCOMObject)localObject).method35(arrayOfLong);
  }
  
  static long callback36(long[] paramArrayOfLong)
  {
    long l = paramArrayOfLong[0];
    Object localObject = ObjectMap.get(new LONG(l));
    if (localObject == null) {
      return -2147467259L;
    }
    long[] arrayOfLong = new long[paramArrayOfLong.length - 1];
    System.arraycopy(paramArrayOfLong, 1, arrayOfLong, 0, arrayOfLong.length);
    return ((XPCOMObject)localObject).method36(arrayOfLong);
  }
  
  static long callback37(long[] paramArrayOfLong)
  {
    long l = paramArrayOfLong[0];
    Object localObject = ObjectMap.get(new LONG(l));
    if (localObject == null) {
      return -2147467259L;
    }
    long[] arrayOfLong = new long[paramArrayOfLong.length - 1];
    System.arraycopy(paramArrayOfLong, 1, arrayOfLong, 0, arrayOfLong.length);
    return ((XPCOMObject)localObject).method37(arrayOfLong);
  }
  
  static long callback38(long[] paramArrayOfLong)
  {
    long l = paramArrayOfLong[0];
    Object localObject = ObjectMap.get(new LONG(l));
    if (localObject == null) {
      return -2147467259L;
    }
    long[] arrayOfLong = new long[paramArrayOfLong.length - 1];
    System.arraycopy(paramArrayOfLong, 1, arrayOfLong, 0, arrayOfLong.length);
    return ((XPCOMObject)localObject).method38(arrayOfLong);
  }
  
  static long callback39(long[] paramArrayOfLong)
  {
    long l = paramArrayOfLong[0];
    Object localObject = ObjectMap.get(new LONG(l));
    if (localObject == null) {
      return -2147467259L;
    }
    long[] arrayOfLong = new long[paramArrayOfLong.length - 1];
    System.arraycopy(paramArrayOfLong, 1, arrayOfLong, 0, arrayOfLong.length);
    return ((XPCOMObject)localObject).method39(arrayOfLong);
  }
  
  static long callback4(long[] paramArrayOfLong)
  {
    long l = paramArrayOfLong[0];
    Object localObject = ObjectMap.get(new LONG(l));
    if (localObject == null) {
      return -2147467259L;
    }
    long[] arrayOfLong = new long[paramArrayOfLong.length - 1];
    System.arraycopy(paramArrayOfLong, 1, arrayOfLong, 0, arrayOfLong.length);
    return ((XPCOMObject)localObject).method4(arrayOfLong);
  }
  
  static long callback40(long[] paramArrayOfLong)
  {
    long l = paramArrayOfLong[0];
    Object localObject = ObjectMap.get(new LONG(l));
    if (localObject == null) {
      return -2147467259L;
    }
    long[] arrayOfLong = new long[paramArrayOfLong.length - 1];
    System.arraycopy(paramArrayOfLong, 1, arrayOfLong, 0, arrayOfLong.length);
    return ((XPCOMObject)localObject).method40(arrayOfLong);
  }
  
  static long callback41(long[] paramArrayOfLong)
  {
    long l = paramArrayOfLong[0];
    Object localObject = ObjectMap.get(new LONG(l));
    if (localObject == null) {
      return -2147467259L;
    }
    long[] arrayOfLong = new long[paramArrayOfLong.length - 1];
    System.arraycopy(paramArrayOfLong, 1, arrayOfLong, 0, arrayOfLong.length);
    return ((XPCOMObject)localObject).method41(arrayOfLong);
  }
  
  static long callback42(long[] paramArrayOfLong)
  {
    long l = paramArrayOfLong[0];
    Object localObject = ObjectMap.get(new LONG(l));
    if (localObject == null) {
      return -2147467259L;
    }
    long[] arrayOfLong = new long[paramArrayOfLong.length - 1];
    System.arraycopy(paramArrayOfLong, 1, arrayOfLong, 0, arrayOfLong.length);
    return ((XPCOMObject)localObject).method42(arrayOfLong);
  }
  
  static long callback43(long[] paramArrayOfLong)
  {
    long l = paramArrayOfLong[0];
    Object localObject = ObjectMap.get(new LONG(l));
    if (localObject == null) {
      return -2147467259L;
    }
    long[] arrayOfLong = new long[paramArrayOfLong.length - 1];
    System.arraycopy(paramArrayOfLong, 1, arrayOfLong, 0, arrayOfLong.length);
    return ((XPCOMObject)localObject).method43(arrayOfLong);
  }
  
  static long callback44(long[] paramArrayOfLong)
  {
    long l = paramArrayOfLong[0];
    Object localObject = ObjectMap.get(new LONG(l));
    if (localObject == null) {
      return -2147467259L;
    }
    long[] arrayOfLong = new long[paramArrayOfLong.length - 1];
    System.arraycopy(paramArrayOfLong, 1, arrayOfLong, 0, arrayOfLong.length);
    return ((XPCOMObject)localObject).method44(arrayOfLong);
  }
  
  static long callback45(long[] paramArrayOfLong)
  {
    long l = paramArrayOfLong[0];
    Object localObject = ObjectMap.get(new LONG(l));
    if (localObject == null) {
      return -2147467259L;
    }
    long[] arrayOfLong = new long[paramArrayOfLong.length - 1];
    System.arraycopy(paramArrayOfLong, 1, arrayOfLong, 0, arrayOfLong.length);
    return ((XPCOMObject)localObject).method45(arrayOfLong);
  }
  
  static long callback46(long[] paramArrayOfLong)
  {
    long l = paramArrayOfLong[0];
    Object localObject = ObjectMap.get(new LONG(l));
    if (localObject == null) {
      return -2147467259L;
    }
    long[] arrayOfLong = new long[paramArrayOfLong.length - 1];
    System.arraycopy(paramArrayOfLong, 1, arrayOfLong, 0, arrayOfLong.length);
    return ((XPCOMObject)localObject).method46(arrayOfLong);
  }
  
  static long callback47(long[] paramArrayOfLong)
  {
    long l = paramArrayOfLong[0];
    Object localObject = ObjectMap.get(new LONG(l));
    if (localObject == null) {
      return -2147467259L;
    }
    long[] arrayOfLong = new long[paramArrayOfLong.length - 1];
    System.arraycopy(paramArrayOfLong, 1, arrayOfLong, 0, arrayOfLong.length);
    return ((XPCOMObject)localObject).method47(arrayOfLong);
  }
  
  static long callback48(long[] paramArrayOfLong)
  {
    long l = paramArrayOfLong[0];
    Object localObject = ObjectMap.get(new LONG(l));
    if (localObject == null) {
      return -2147467259L;
    }
    long[] arrayOfLong = new long[paramArrayOfLong.length - 1];
    System.arraycopy(paramArrayOfLong, 1, arrayOfLong, 0, arrayOfLong.length);
    return ((XPCOMObject)localObject).method48(arrayOfLong);
  }
  
  static long callback49(long[] paramArrayOfLong)
  {
    long l = paramArrayOfLong[0];
    Object localObject = ObjectMap.get(new LONG(l));
    if (localObject == null) {
      return -2147467259L;
    }
    long[] arrayOfLong = new long[paramArrayOfLong.length - 1];
    System.arraycopy(paramArrayOfLong, 1, arrayOfLong, 0, arrayOfLong.length);
    return ((XPCOMObject)localObject).method49(arrayOfLong);
  }
  
  static long callback5(long[] paramArrayOfLong)
  {
    long l = paramArrayOfLong[0];
    Object localObject = ObjectMap.get(new LONG(l));
    if (localObject == null) {
      return -2147467259L;
    }
    long[] arrayOfLong = new long[paramArrayOfLong.length - 1];
    System.arraycopy(paramArrayOfLong, 1, arrayOfLong, 0, arrayOfLong.length);
    return ((XPCOMObject)localObject).method5(arrayOfLong);
  }
  
  static long callback50(long[] paramArrayOfLong)
  {
    long l = paramArrayOfLong[0];
    Object localObject = ObjectMap.get(new LONG(l));
    if (localObject == null) {
      return -2147467259L;
    }
    long[] arrayOfLong = new long[paramArrayOfLong.length - 1];
    System.arraycopy(paramArrayOfLong, 1, arrayOfLong, 0, arrayOfLong.length);
    return ((XPCOMObject)localObject).method50(arrayOfLong);
  }
  
  static long callback51(long[] paramArrayOfLong)
  {
    long l = paramArrayOfLong[0];
    Object localObject = ObjectMap.get(new LONG(l));
    if (localObject == null) {
      return -2147467259L;
    }
    long[] arrayOfLong = new long[paramArrayOfLong.length - 1];
    System.arraycopy(paramArrayOfLong, 1, arrayOfLong, 0, arrayOfLong.length);
    return ((XPCOMObject)localObject).method51(arrayOfLong);
  }
  
  static long callback52(long[] paramArrayOfLong)
  {
    long l = paramArrayOfLong[0];
    Object localObject = ObjectMap.get(new LONG(l));
    if (localObject == null) {
      return -2147467259L;
    }
    long[] arrayOfLong = new long[paramArrayOfLong.length - 1];
    System.arraycopy(paramArrayOfLong, 1, arrayOfLong, 0, arrayOfLong.length);
    return ((XPCOMObject)localObject).method52(arrayOfLong);
  }
  
  static long callback53(long[] paramArrayOfLong)
  {
    long l = paramArrayOfLong[0];
    Object localObject = ObjectMap.get(new LONG(l));
    if (localObject == null) {
      return -2147467259L;
    }
    long[] arrayOfLong = new long[paramArrayOfLong.length - 1];
    System.arraycopy(paramArrayOfLong, 1, arrayOfLong, 0, arrayOfLong.length);
    return ((XPCOMObject)localObject).method53(arrayOfLong);
  }
  
  static long callback54(long[] paramArrayOfLong)
  {
    long l = paramArrayOfLong[0];
    Object localObject = ObjectMap.get(new LONG(l));
    if (localObject == null) {
      return -2147467259L;
    }
    long[] arrayOfLong = new long[paramArrayOfLong.length - 1];
    System.arraycopy(paramArrayOfLong, 1, arrayOfLong, 0, arrayOfLong.length);
    return ((XPCOMObject)localObject).method54(arrayOfLong);
  }
  
  static long callback55(long[] paramArrayOfLong)
  {
    long l = paramArrayOfLong[0];
    Object localObject = ObjectMap.get(new LONG(l));
    if (localObject == null) {
      return -2147467259L;
    }
    long[] arrayOfLong = new long[paramArrayOfLong.length - 1];
    System.arraycopy(paramArrayOfLong, 1, arrayOfLong, 0, arrayOfLong.length);
    return ((XPCOMObject)localObject).method55(arrayOfLong);
  }
  
  static long callback56(long[] paramArrayOfLong)
  {
    long l = paramArrayOfLong[0];
    Object localObject = ObjectMap.get(new LONG(l));
    if (localObject == null) {
      return -2147467259L;
    }
    long[] arrayOfLong = new long[paramArrayOfLong.length - 1];
    System.arraycopy(paramArrayOfLong, 1, arrayOfLong, 0, arrayOfLong.length);
    return ((XPCOMObject)localObject).method56(arrayOfLong);
  }
  
  static long callback57(long[] paramArrayOfLong)
  {
    long l = paramArrayOfLong[0];
    Object localObject = ObjectMap.get(new LONG(l));
    if (localObject == null) {
      return -2147467259L;
    }
    long[] arrayOfLong = new long[paramArrayOfLong.length - 1];
    System.arraycopy(paramArrayOfLong, 1, arrayOfLong, 0, arrayOfLong.length);
    return ((XPCOMObject)localObject).method57(arrayOfLong);
  }
  
  static long callback58(long[] paramArrayOfLong)
  {
    long l = paramArrayOfLong[0];
    Object localObject = ObjectMap.get(new LONG(l));
    if (localObject == null) {
      return -2147467259L;
    }
    long[] arrayOfLong = new long[paramArrayOfLong.length - 1];
    System.arraycopy(paramArrayOfLong, 1, arrayOfLong, 0, arrayOfLong.length);
    return ((XPCOMObject)localObject).method58(arrayOfLong);
  }
  
  static long callback59(long[] paramArrayOfLong)
  {
    long l = paramArrayOfLong[0];
    Object localObject = ObjectMap.get(new LONG(l));
    if (localObject == null) {
      return -2147467259L;
    }
    long[] arrayOfLong = new long[paramArrayOfLong.length - 1];
    System.arraycopy(paramArrayOfLong, 1, arrayOfLong, 0, arrayOfLong.length);
    return ((XPCOMObject)localObject).method59(arrayOfLong);
  }
  
  static long callback6(long[] paramArrayOfLong)
  {
    long l = paramArrayOfLong[0];
    Object localObject = ObjectMap.get(new LONG(l));
    if (localObject == null) {
      return -2147467259L;
    }
    long[] arrayOfLong = new long[paramArrayOfLong.length - 1];
    System.arraycopy(paramArrayOfLong, 1, arrayOfLong, 0, arrayOfLong.length);
    return ((XPCOMObject)localObject).method6(arrayOfLong);
  }
  
  static long callback60(long[] paramArrayOfLong)
  {
    long l = paramArrayOfLong[0];
    Object localObject = ObjectMap.get(new LONG(l));
    if (localObject == null) {
      return -2147467259L;
    }
    long[] arrayOfLong = new long[paramArrayOfLong.length - 1];
    System.arraycopy(paramArrayOfLong, 1, arrayOfLong, 0, arrayOfLong.length);
    return ((XPCOMObject)localObject).method60(arrayOfLong);
  }
  
  static long callback61(long[] paramArrayOfLong)
  {
    long l = paramArrayOfLong[0];
    Object localObject = ObjectMap.get(new LONG(l));
    if (localObject == null) {
      return -2147467259L;
    }
    long[] arrayOfLong = new long[paramArrayOfLong.length - 1];
    System.arraycopy(paramArrayOfLong, 1, arrayOfLong, 0, arrayOfLong.length);
    return ((XPCOMObject)localObject).method61(arrayOfLong);
  }
  
  static long callback62(long[] paramArrayOfLong)
  {
    long l = paramArrayOfLong[0];
    Object localObject = ObjectMap.get(new LONG(l));
    if (localObject == null) {
      return -2147467259L;
    }
    long[] arrayOfLong = new long[paramArrayOfLong.length - 1];
    System.arraycopy(paramArrayOfLong, 1, arrayOfLong, 0, arrayOfLong.length);
    return ((XPCOMObject)localObject).method62(arrayOfLong);
  }
  
  static long callback63(long[] paramArrayOfLong)
  {
    long l = paramArrayOfLong[0];
    Object localObject = ObjectMap.get(new LONG(l));
    if (localObject == null) {
      return -2147467259L;
    }
    long[] arrayOfLong = new long[paramArrayOfLong.length - 1];
    System.arraycopy(paramArrayOfLong, 1, arrayOfLong, 0, arrayOfLong.length);
    return ((XPCOMObject)localObject).method63(arrayOfLong);
  }
  
  static long callback64(long[] paramArrayOfLong)
  {
    long l = paramArrayOfLong[0];
    Object localObject = ObjectMap.get(new LONG(l));
    if (localObject == null) {
      return -2147467259L;
    }
    long[] arrayOfLong = new long[paramArrayOfLong.length - 1];
    System.arraycopy(paramArrayOfLong, 1, arrayOfLong, 0, arrayOfLong.length);
    return ((XPCOMObject)localObject).method64(arrayOfLong);
  }
  
  static long callback65(long[] paramArrayOfLong)
  {
    long l = paramArrayOfLong[0];
    Object localObject = ObjectMap.get(new LONG(l));
    if (localObject == null) {
      return -2147467259L;
    }
    long[] arrayOfLong = new long[paramArrayOfLong.length - 1];
    System.arraycopy(paramArrayOfLong, 1, arrayOfLong, 0, arrayOfLong.length);
    return ((XPCOMObject)localObject).method65(arrayOfLong);
  }
  
  static long callback66(long[] paramArrayOfLong)
  {
    long l = paramArrayOfLong[0];
    Object localObject = ObjectMap.get(new LONG(l));
    if (localObject == null) {
      return -2147467259L;
    }
    long[] arrayOfLong = new long[paramArrayOfLong.length - 1];
    System.arraycopy(paramArrayOfLong, 1, arrayOfLong, 0, arrayOfLong.length);
    return ((XPCOMObject)localObject).method66(arrayOfLong);
  }
  
  static long callback67(long[] paramArrayOfLong)
  {
    long l = paramArrayOfLong[0];
    Object localObject = ObjectMap.get(new LONG(l));
    if (localObject == null) {
      return -2147467259L;
    }
    long[] arrayOfLong = new long[paramArrayOfLong.length - 1];
    System.arraycopy(paramArrayOfLong, 1, arrayOfLong, 0, arrayOfLong.length);
    return ((XPCOMObject)localObject).method67(arrayOfLong);
  }
  
  static long callback68(long[] paramArrayOfLong)
  {
    long l = paramArrayOfLong[0];
    Object localObject = ObjectMap.get(new LONG(l));
    if (localObject == null) {
      return -2147467259L;
    }
    long[] arrayOfLong = new long[paramArrayOfLong.length - 1];
    System.arraycopy(paramArrayOfLong, 1, arrayOfLong, 0, arrayOfLong.length);
    return ((XPCOMObject)localObject).method68(arrayOfLong);
  }
  
  static long callback69(long[] paramArrayOfLong)
  {
    long l = paramArrayOfLong[0];
    Object localObject = ObjectMap.get(new LONG(l));
    if (localObject == null) {
      return -2147467259L;
    }
    long[] arrayOfLong = new long[paramArrayOfLong.length - 1];
    System.arraycopy(paramArrayOfLong, 1, arrayOfLong, 0, arrayOfLong.length);
    return ((XPCOMObject)localObject).method69(arrayOfLong);
  }
  
  static long callback7(long[] paramArrayOfLong)
  {
    long l = paramArrayOfLong[0];
    Object localObject = ObjectMap.get(new LONG(l));
    if (localObject == null) {
      return -2147467259L;
    }
    long[] arrayOfLong = new long[paramArrayOfLong.length - 1];
    System.arraycopy(paramArrayOfLong, 1, arrayOfLong, 0, arrayOfLong.length);
    return ((XPCOMObject)localObject).method7(arrayOfLong);
  }
  
  static long callback70(long[] paramArrayOfLong)
  {
    long l = paramArrayOfLong[0];
    Object localObject = ObjectMap.get(new LONG(l));
    if (localObject == null) {
      return -2147467259L;
    }
    long[] arrayOfLong = new long[paramArrayOfLong.length - 1];
    System.arraycopy(paramArrayOfLong, 1, arrayOfLong, 0, arrayOfLong.length);
    return ((XPCOMObject)localObject).method70(arrayOfLong);
  }
  
  static long callback71(long[] paramArrayOfLong)
  {
    long l = paramArrayOfLong[0];
    Object localObject = ObjectMap.get(new LONG(l));
    if (localObject == null) {
      return -2147467259L;
    }
    long[] arrayOfLong = new long[paramArrayOfLong.length - 1];
    System.arraycopy(paramArrayOfLong, 1, arrayOfLong, 0, arrayOfLong.length);
    return ((XPCOMObject)localObject).method71(arrayOfLong);
  }
  
  static long callback72(long[] paramArrayOfLong)
  {
    long l = paramArrayOfLong[0];
    Object localObject = ObjectMap.get(new LONG(l));
    if (localObject == null) {
      return -2147467259L;
    }
    long[] arrayOfLong = new long[paramArrayOfLong.length - 1];
    System.arraycopy(paramArrayOfLong, 1, arrayOfLong, 0, arrayOfLong.length);
    return ((XPCOMObject)localObject).method72(arrayOfLong);
  }
  
  static long callback73(long[] paramArrayOfLong)
  {
    long l = paramArrayOfLong[0];
    Object localObject = ObjectMap.get(new LONG(l));
    if (localObject == null) {
      return -2147467259L;
    }
    long[] arrayOfLong = new long[paramArrayOfLong.length - 1];
    System.arraycopy(paramArrayOfLong, 1, arrayOfLong, 0, arrayOfLong.length);
    return ((XPCOMObject)localObject).method73(arrayOfLong);
  }
  
  static long callback74(long[] paramArrayOfLong)
  {
    long l = paramArrayOfLong[0];
    Object localObject = ObjectMap.get(new LONG(l));
    if (localObject == null) {
      return -2147467259L;
    }
    long[] arrayOfLong = new long[paramArrayOfLong.length - 1];
    System.arraycopy(paramArrayOfLong, 1, arrayOfLong, 0, arrayOfLong.length);
    return ((XPCOMObject)localObject).method74(arrayOfLong);
  }
  
  static long callback75(long[] paramArrayOfLong)
  {
    long l = paramArrayOfLong[0];
    Object localObject = ObjectMap.get(new LONG(l));
    if (localObject == null) {
      return -2147467259L;
    }
    long[] arrayOfLong = new long[paramArrayOfLong.length - 1];
    System.arraycopy(paramArrayOfLong, 1, arrayOfLong, 0, arrayOfLong.length);
    return ((XPCOMObject)localObject).method75(arrayOfLong);
  }
  
  static long callback76(long[] paramArrayOfLong)
  {
    long l = paramArrayOfLong[0];
    Object localObject = ObjectMap.get(new LONG(l));
    if (localObject == null) {
      return -2147467259L;
    }
    long[] arrayOfLong = new long[paramArrayOfLong.length - 1];
    System.arraycopy(paramArrayOfLong, 1, arrayOfLong, 0, arrayOfLong.length);
    return ((XPCOMObject)localObject).method76(arrayOfLong);
  }
  
  static long callback77(long[] paramArrayOfLong)
  {
    long l = paramArrayOfLong[0];
    Object localObject = ObjectMap.get(new LONG(l));
    if (localObject == null) {
      return -2147467259L;
    }
    long[] arrayOfLong = new long[paramArrayOfLong.length - 1];
    System.arraycopy(paramArrayOfLong, 1, arrayOfLong, 0, arrayOfLong.length);
    return ((XPCOMObject)localObject).method77(arrayOfLong);
  }
  
  static long callback78(long[] paramArrayOfLong)
  {
    long l = paramArrayOfLong[0];
    Object localObject = ObjectMap.get(new LONG(l));
    if (localObject == null) {
      return -2147467259L;
    }
    long[] arrayOfLong = new long[paramArrayOfLong.length - 1];
    System.arraycopy(paramArrayOfLong, 1, arrayOfLong, 0, arrayOfLong.length);
    return ((XPCOMObject)localObject).method78(arrayOfLong);
  }
  
  static long callback79(long[] paramArrayOfLong)
  {
    long l = paramArrayOfLong[0];
    Object localObject = ObjectMap.get(new LONG(l));
    if (localObject == null) {
      return -2147467259L;
    }
    long[] arrayOfLong = new long[paramArrayOfLong.length - 1];
    System.arraycopy(paramArrayOfLong, 1, arrayOfLong, 0, arrayOfLong.length);
    return ((XPCOMObject)localObject).method79(arrayOfLong);
  }
  
  static long callback8(long[] paramArrayOfLong)
  {
    long l = paramArrayOfLong[0];
    Object localObject = ObjectMap.get(new LONG(l));
    if (localObject == null) {
      return -2147467259L;
    }
    long[] arrayOfLong = new long[paramArrayOfLong.length - 1];
    System.arraycopy(paramArrayOfLong, 1, arrayOfLong, 0, arrayOfLong.length);
    return ((XPCOMObject)localObject).method8(arrayOfLong);
  }
  
  static long callback9(long[] paramArrayOfLong)
  {
    long l = paramArrayOfLong[0];
    Object localObject = ObjectMap.get(new LONG(l));
    if (localObject == null) {
      return -2147467259L;
    }
    long[] arrayOfLong = new long[paramArrayOfLong.length - 1];
    System.arraycopy(paramArrayOfLong, 1, arrayOfLong, 0, arrayOfLong.length);
    return ((XPCOMObject)localObject).method9(arrayOfLong);
  }
  
  public void dispose()
  {
    long[] arrayOfLong = new long[1];
    XPCOM.memmove(arrayOfLong, this.ppVtable, C.PTR_SIZEOF);
    C.free(arrayOfLong[0]);
    C.free(this.ppVtable);
    ObjectMap.remove(new LONG(this.ppVtable));
    this.ppVtable = 0L;
  }
  
  public long getAddress()
  {
    return this.ppVtable;
  }
  
  public long method0(long[] paramArrayOfLong)
  {
    return -2147467263L;
  }
  
  public long method1(long[] paramArrayOfLong)
  {
    return -2147467263L;
  }
  
  public long method10(long[] paramArrayOfLong)
  {
    return -2147467263L;
  }
  
  public long method11(long[] paramArrayOfLong)
  {
    return -2147467263L;
  }
  
  public long method12(long[] paramArrayOfLong)
  {
    return -2147467263L;
  }
  
  public long method13(long[] paramArrayOfLong)
  {
    return -2147467263L;
  }
  
  public long method14(long[] paramArrayOfLong)
  {
    return -2147467263L;
  }
  
  public long method15(long[] paramArrayOfLong)
  {
    return -2147467263L;
  }
  
  public long method16(long[] paramArrayOfLong)
  {
    return -2147467263L;
  }
  
  public long method17(long[] paramArrayOfLong)
  {
    return -2147467263L;
  }
  
  public long method18(long[] paramArrayOfLong)
  {
    return -2147467263L;
  }
  
  public long method19(long[] paramArrayOfLong)
  {
    return -2147467263L;
  }
  
  public long method2(long[] paramArrayOfLong)
  {
    return -2147467263L;
  }
  
  public long method20(long[] paramArrayOfLong)
  {
    return -2147467263L;
  }
  
  public long method21(long[] paramArrayOfLong)
  {
    return -2147467263L;
  }
  
  public long method22(long[] paramArrayOfLong)
  {
    return -2147467263L;
  }
  
  public long method23(long[] paramArrayOfLong)
  {
    return -2147467263L;
  }
  
  public long method24(long[] paramArrayOfLong)
  {
    return -2147467263L;
  }
  
  public long method25(long[] paramArrayOfLong)
  {
    return -2147467263L;
  }
  
  public long method26(long[] paramArrayOfLong)
  {
    return -2147467263L;
  }
  
  public long method27(long[] paramArrayOfLong)
  {
    return -2147467263L;
  }
  
  public long method28(long[] paramArrayOfLong)
  {
    return -2147467263L;
  }
  
  public long method29(long[] paramArrayOfLong)
  {
    return -2147467263L;
  }
  
  public long method3(long[] paramArrayOfLong)
  {
    return -2147467263L;
  }
  
  public long method30(long[] paramArrayOfLong)
  {
    return -2147467263L;
  }
  
  public long method31(long[] paramArrayOfLong)
  {
    return -2147467263L;
  }
  
  public long method32(long[] paramArrayOfLong)
  {
    return -2147467263L;
  }
  
  public long method33(long[] paramArrayOfLong)
  {
    return -2147467263L;
  }
  
  public long method34(long[] paramArrayOfLong)
  {
    return -2147467263L;
  }
  
  public long method35(long[] paramArrayOfLong)
  {
    return -2147467263L;
  }
  
  public long method36(long[] paramArrayOfLong)
  {
    return -2147467263L;
  }
  
  public long method37(long[] paramArrayOfLong)
  {
    return -2147467263L;
  }
  
  public long method38(long[] paramArrayOfLong)
  {
    return -2147467263L;
  }
  
  public long method39(long[] paramArrayOfLong)
  {
    return -2147467263L;
  }
  
  public long method4(long[] paramArrayOfLong)
  {
    return -2147467263L;
  }
  
  public long method40(long[] paramArrayOfLong)
  {
    return -2147467263L;
  }
  
  public long method41(long[] paramArrayOfLong)
  {
    return -2147467263L;
  }
  
  public long method42(long[] paramArrayOfLong)
  {
    return -2147467263L;
  }
  
  public long method43(long[] paramArrayOfLong)
  {
    return -2147467263L;
  }
  
  public long method44(long[] paramArrayOfLong)
  {
    return -2147467263L;
  }
  
  public long method45(long[] paramArrayOfLong)
  {
    return -2147467263L;
  }
  
  public long method46(long[] paramArrayOfLong)
  {
    return -2147467263L;
  }
  
  public long method47(long[] paramArrayOfLong)
  {
    return -2147467263L;
  }
  
  public long method48(long[] paramArrayOfLong)
  {
    return -2147467263L;
  }
  
  public long method49(long[] paramArrayOfLong)
  {
    return -2147467263L;
  }
  
  public long method5(long[] paramArrayOfLong)
  {
    return -2147467263L;
  }
  
  public long method50(long[] paramArrayOfLong)
  {
    return -2147467263L;
  }
  
  public long method51(long[] paramArrayOfLong)
  {
    return -2147467263L;
  }
  
  public long method52(long[] paramArrayOfLong)
  {
    return -2147467263L;
  }
  
  public long method53(long[] paramArrayOfLong)
  {
    return -2147467263L;
  }
  
  public long method54(long[] paramArrayOfLong)
  {
    return -2147467263L;
  }
  
  public long method55(long[] paramArrayOfLong)
  {
    return -2147467263L;
  }
  
  public long method56(long[] paramArrayOfLong)
  {
    return -2147467263L;
  }
  
  public long method57(long[] paramArrayOfLong)
  {
    return -2147467263L;
  }
  
  public long method58(long[] paramArrayOfLong)
  {
    return -2147467263L;
  }
  
  public long method59(long[] paramArrayOfLong)
  {
    return -2147467263L;
  }
  
  public long method6(long[] paramArrayOfLong)
  {
    return -2147467263L;
  }
  
  public long method60(long[] paramArrayOfLong)
  {
    return -2147467263L;
  }
  
  public long method61(long[] paramArrayOfLong)
  {
    return -2147467263L;
  }
  
  public long method62(long[] paramArrayOfLong)
  {
    return -2147467263L;
  }
  
  public long method63(long[] paramArrayOfLong)
  {
    return -2147467263L;
  }
  
  public long method64(long[] paramArrayOfLong)
  {
    return -2147467263L;
  }
  
  public long method65(long[] paramArrayOfLong)
  {
    return -2147467263L;
  }
  
  public long method66(long[] paramArrayOfLong)
  {
    return -2147467263L;
  }
  
  public long method67(long[] paramArrayOfLong)
  {
    return -2147467263L;
  }
  
  public long method68(long[] paramArrayOfLong)
  {
    return -2147467263L;
  }
  
  public long method69(long[] paramArrayOfLong)
  {
    return -2147467263L;
  }
  
  public long method7(long[] paramArrayOfLong)
  {
    return -2147467263L;
  }
  
  public long method70(long[] paramArrayOfLong)
  {
    return -2147467263L;
  }
  
  public long method71(long[] paramArrayOfLong)
  {
    return -2147467263L;
  }
  
  public long method72(long[] paramArrayOfLong)
  {
    return -2147467263L;
  }
  
  public long method73(long[] paramArrayOfLong)
  {
    return -2147467263L;
  }
  
  public long method74(long[] paramArrayOfLong)
  {
    return -2147467263L;
  }
  
  public long method75(long[] paramArrayOfLong)
  {
    return -2147467263L;
  }
  
  public long method76(long[] paramArrayOfLong)
  {
    return -2147467263L;
  }
  
  public long method77(long[] paramArrayOfLong)
  {
    return -2147467263L;
  }
  
  public long method78(long[] paramArrayOfLong)
  {
    return -2147467263L;
  }
  
  public long method79(long[] paramArrayOfLong)
  {
    return -2147467263L;
  }
  
  public long method8(long[] paramArrayOfLong)
  {
    return -2147467263L;
  }
  
  public long method9(long[] paramArrayOfLong)
  {
    return -2147467263L;
  }
  
  static
  {
    String str = System.getProperty("os.name").toLowerCase();
    IsSolaris = (str.startsWith("sunos")) || (str.startsWith("solaris"));
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/internal/mozilla/XPCOMObject.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */