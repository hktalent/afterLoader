package org.eclipse.swt.internal.mozilla;

public class nsIWebBrowserFocus
  extends nsISupports
{
  static final int LAST_METHOD_ID = nsISupports.LAST_METHOD_ID + 8;
  static final String NS_IWEBBROWSERFOCUS_IID_STR = "9c5d3c58-1dd1-11b2-a1c9-f3699284657a";
  
  public nsIWebBrowserFocus(long paramLong)
  {
    super(paramLong);
  }
  
  public int Activate()
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 1, getAddress());
  }
  
  public int Deactivate()
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 2, getAddress());
  }
  
  static
  {
    IIDStore.RegisterIID(nsIWebBrowserFocus.class, 0, new nsID("9c5d3c58-1dd1-11b2-a1c9-f3699284657a"));
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/internal/mozilla/nsIWebBrowserFocus.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */