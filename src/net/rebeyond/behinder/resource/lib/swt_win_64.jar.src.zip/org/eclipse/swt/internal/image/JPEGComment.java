package org.eclipse.swt.internal.image;

final class JPEGComment
  extends JPEGVariableSizeSegment
{
  public JPEGComment(byte[] paramArrayOfByte)
  {
    super(paramArrayOfByte);
  }
  
  public JPEGComment(LEDataInputStream paramLEDataInputStream)
  {
    super(paramLEDataInputStream);
  }
  
  public int signature()
  {
    return 65534;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/internal/image/JPEGComment.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */