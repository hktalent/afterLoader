package org.eclipse.swt.browser;

import org.eclipse.swt.internal.C;
import org.eclipse.swt.internal.mozilla.IIDStore;
import org.eclipse.swt.internal.mozilla.XPCOM;
import org.eclipse.swt.internal.mozilla.XPCOMObject;
import org.eclipse.swt.internal.mozilla.nsEmbedString;
import org.eclipse.swt.internal.mozilla.nsID;
import org.eclipse.swt.internal.mozilla.nsIFilePicker;
import org.eclipse.swt.internal.mozilla.nsILocalFile;
import org.eclipse.swt.internal.mozilla.nsISupports;
import org.eclipse.swt.widgets.DirectoryDialog;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Shell;

class FilePicker
{
  XPCOMObject supports;
  XPCOMObject filePicker;
  int refCount = 0;
  short mode;
  long parentHandle;
  String[] files;
  String[] masks;
  String defaultFilename;
  String directory;
  String title;
  static final String SEPARATOR = System.getProperty("file.separator");
  
  FilePicker()
  {
    createCOMInterfaces();
  }
  
  int AddRef()
  {
    this.refCount += 1;
    return this.refCount;
  }
  
  void createCOMInterfaces()
  {
    this.supports = new XPCOMObject(new int[] { 2, 0, 0 })
    {
      public long method0(long[] paramAnonymousArrayOfLong)
      {
        return FilePicker.this.QueryInterface(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method1(long[] paramAnonymousArrayOfLong)
      {
        return FilePicker.this.AddRef();
      }
      
      public long method2(long[] paramAnonymousArrayOfLong)
      {
        return FilePicker.this.Release();
      }
    };
    this.filePicker = new XPCOMObject(new int[] { 2, 0, 0, 3, 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 })
    {
      public long method0(long[] paramAnonymousArrayOfLong)
      {
        return FilePicker.this.QueryInterface(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method1(long[] paramAnonymousArrayOfLong)
      {
        return FilePicker.this.AddRef();
      }
      
      public long method2(long[] paramAnonymousArrayOfLong)
      {
        return FilePicker.this.Release();
      }
      
      public long method3(long[] paramAnonymousArrayOfLong)
      {
        return FilePicker.this.Init(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], (short)(int)paramAnonymousArrayOfLong[2]);
      }
      
      public long method4(long[] paramAnonymousArrayOfLong)
      {
        return FilePicker.this.AppendFilters((int)paramAnonymousArrayOfLong[0]);
      }
      
      public long method5(long[] paramAnonymousArrayOfLong)
      {
        return FilePicker.this.AppendFilter(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method6(long[] paramAnonymousArrayOfLong)
      {
        return FilePicker.this.GetDefaultString(paramAnonymousArrayOfLong[0]);
      }
      
      public long method7(long[] paramAnonymousArrayOfLong)
      {
        return FilePicker.this.SetDefaultString(paramAnonymousArrayOfLong[0]);
      }
      
      public long method8(long[] paramAnonymousArrayOfLong)
      {
        return FilePicker.this.GetDefaultExtension(paramAnonymousArrayOfLong[0]);
      }
      
      public long method9(long[] paramAnonymousArrayOfLong)
      {
        return FilePicker.this.SetDefaultExtension(paramAnonymousArrayOfLong[0]);
      }
      
      public long method10(long[] paramAnonymousArrayOfLong)
      {
        return FilePicker.this.GetFilterIndex(paramAnonymousArrayOfLong[0]);
      }
      
      public long method11(long[] paramAnonymousArrayOfLong)
      {
        return FilePicker.this.SetFilterIndex((int)paramAnonymousArrayOfLong[0]);
      }
      
      public long method12(long[] paramAnonymousArrayOfLong)
      {
        return FilePicker.this.GetDisplayDirectory(paramAnonymousArrayOfLong[0]);
      }
      
      public long method13(long[] paramAnonymousArrayOfLong)
      {
        return FilePicker.this.SetDisplayDirectory(paramAnonymousArrayOfLong[0]);
      }
      
      public long method14(long[] paramAnonymousArrayOfLong)
      {
        return FilePicker.this.GetFile(paramAnonymousArrayOfLong[0]);
      }
      
      public long method15(long[] paramAnonymousArrayOfLong)
      {
        return FilePicker.this.GetFileURL(paramAnonymousArrayOfLong[0]);
      }
      
      public long method16(long[] paramAnonymousArrayOfLong)
      {
        return FilePicker.this.GetFiles(paramAnonymousArrayOfLong[0]);
      }
      
      public long method17(long[] paramAnonymousArrayOfLong)
      {
        return FilePicker.this.Show(paramAnonymousArrayOfLong[0]);
      }
    };
  }
  
  void disposeCOMInterfaces()
  {
    if (this.supports != null)
    {
      this.supports.dispose();
      this.supports = null;
    }
    if (this.filePicker != null)
    {
      this.filePicker.dispose();
      this.filePicker = null;
    }
  }
  
  long getAddress()
  {
    return this.filePicker.getAddress();
  }
  
  int QueryInterface(long paramLong1, long paramLong2)
  {
    if ((paramLong1 == 0L) || (paramLong2 == 0L)) {
      return -2147467262;
    }
    nsID localnsID = new nsID();
    XPCOM.memmove(localnsID, paramLong1, 16);
    if (localnsID.Equals(IIDStore.GetIID(nsISupports.class)))
    {
      XPCOM.memmove(paramLong2, new long[] { this.supports.getAddress() }, C.PTR_SIZEOF);
      AddRef();
      return 0;
    }
    if (localnsID.Equals(IIDStore.GetIID(nsIFilePicker.class)))
    {
      XPCOM.memmove(paramLong2, new long[] { this.filePicker.getAddress() }, C.PTR_SIZEOF);
      AddRef();
      return 0;
    }
    XPCOM.memmove(paramLong2, new long[] { 0L }, C.PTR_SIZEOF);
    return -2147467262;
  }
  
  int Release()
  {
    this.refCount -= 1;
    if (this.refCount == 0) {
      disposeCOMInterfaces();
    }
    return this.refCount;
  }
  
  Browser getBrowser(long paramLong)
  {
    if (paramLong == 0L) {
      return null;
    }
    return Mozilla.getBrowser(paramLong);
  }
  
  String parseAString(long paramLong)
  {
    return null;
  }
  
  int Init(long paramLong1, long paramLong2, short paramShort)
  {
    this.parentHandle = paramLong1;
    this.mode = paramShort;
    this.title = parseAString(paramLong2);
    return 0;
  }
  
  int Show(long paramLong)
  {
    if (this.mode == 2)
    {
      i = showDirectoryPicker();
      XPCOM.memmove(paramLong, new short[] { (short)i }, 2L);
      return 0;
    }
    int i = this.mode == 1 ? 8192 : 4096;
    if (this.mode == 3) {
      i |= 0x2;
    }
    Browser localBrowser = getBrowser(this.parentHandle);
    Shell localShell = null;
    if (localBrowser != null) {
      localShell = localBrowser.getShell();
    } else {
      localShell = new Shell();
    }
    FileDialog localFileDialog = new FileDialog(localShell, i);
    if (this.title != null) {
      localFileDialog.setText(this.title);
    }
    if (this.directory != null) {
      localFileDialog.setFilterPath(this.directory);
    }
    if (this.masks != null) {
      localFileDialog.setFilterExtensions(this.masks);
    }
    if (this.defaultFilename != null) {
      localFileDialog.setFileName(this.defaultFilename);
    }
    String str = localFileDialog.open();
    this.files = localFileDialog.getFileNames();
    this.directory = localFileDialog.getFilterPath();
    this.title = (this.defaultFilename = null);
    this.masks = null;
    int j = str == null ? 1 : 0;
    XPCOM.memmove(paramLong, new short[] { (short)j }, 2L);
    return 0;
  }
  
  int showDirectoryPicker()
  {
    Browser localBrowser = getBrowser(this.parentHandle);
    Shell localShell = null;
    if (localBrowser != null) {
      localShell = localBrowser.getShell();
    } else {
      localShell = new Shell();
    }
    DirectoryDialog localDirectoryDialog = new DirectoryDialog(localShell, 0);
    if (this.title != null) {
      localDirectoryDialog.setText(this.title);
    }
    if (this.directory != null) {
      localDirectoryDialog.setFilterPath(this.directory);
    }
    this.directory = localDirectoryDialog.open();
    this.title = (this.defaultFilename = null);
    this.files = (this.masks = null);
    return this.directory == null ? 1 : 0;
  }
  
  int GetFiles(long paramLong)
  {
    return -2147467263;
  }
  
  int GetFileURL(long paramLong)
  {
    return -2147467263;
  }
  
  int GetFile(long paramLong)
  {
    String str = "";
    if (this.directory != null) {
      str = str + this.directory + SEPARATOR;
    }
    if ((this.files != null) && (this.files.length > 0)) {
      str = str + this.files[0];
    }
    nsEmbedString localnsEmbedString = new nsEmbedString(str);
    long[] arrayOfLong = new long[1];
    int i = XPCOM.NS_NewLocalFile(localnsEmbedString.getAddress(), 1, arrayOfLong);
    localnsEmbedString.dispose();
    if (i != 0) {
      Mozilla.error(i);
    }
    if (arrayOfLong[0] == 0L) {
      Mozilla.error(-2147467261);
    }
    XPCOM.memmove(paramLong, arrayOfLong, C.PTR_SIZEOF);
    return 0;
  }
  
  int SetDisplayDirectory(long paramLong)
  {
    if (paramLong == 0L) {
      return 0;
    }
    nsILocalFile localnsILocalFile = new nsILocalFile(paramLong);
    long l1 = XPCOM.nsEmbedString_new();
    int i = localnsILocalFile.GetPath(l1);
    if (i != 0) {
      Mozilla.error(i);
    }
    int j = XPCOM.nsEmbedString_Length(l1);
    long l2 = XPCOM.nsEmbedString_get(l1);
    char[] arrayOfChar = new char[j];
    XPCOM.memmove(arrayOfChar, l2, j * 2);
    XPCOM.nsEmbedString_delete(l1);
    this.directory = new String(arrayOfChar);
    return 0;
  }
  
  int GetDisplayDirectory(long paramLong)
  {
    String str = this.directory != null ? this.directory : "";
    nsEmbedString localnsEmbedString = new nsEmbedString(str);
    long[] arrayOfLong = new long[1];
    int i = XPCOM.NS_NewLocalFile(localnsEmbedString.getAddress(), 1, arrayOfLong);
    localnsEmbedString.dispose();
    if (i != 0) {
      Mozilla.error(i);
    }
    if (arrayOfLong[0] == 0L) {
      Mozilla.error(-2147467261);
    }
    XPCOM.memmove(paramLong, arrayOfLong, C.PTR_SIZEOF);
    return 0;
  }
  
  int SetFilterIndex(int paramInt)
  {
    return -2147467263;
  }
  
  int GetFilterIndex(long paramLong)
  {
    return -2147467263;
  }
  
  int SetDefaultExtension(long paramLong)
  {
    return -2147467263;
  }
  
  int GetDefaultExtension(long paramLong)
  {
    return -2147467263;
  }
  
  int SetDefaultString(long paramLong)
  {
    this.defaultFilename = parseAString(paramLong);
    return 0;
  }
  
  int GetDefaultString(long paramLong)
  {
    return -2147467263;
  }
  
  int AppendFilter(long paramLong1, long paramLong2)
  {
    return -2147467263;
  }
  
  int AppendFilters(int paramInt)
  {
    String[] arrayOfString1 = null;
    switch (paramInt)
    {
    case 1: 
    case 64: 
      this.masks = null;
      break;
    case 2: 
      arrayOfString1 = new String[] { "*.htm;*.html" };
      break;
    case 8: 
      arrayOfString1 = new String[] { "*.gif;*.jpeg;*.jpg;*.png" };
      break;
    case 4: 
      arrayOfString1 = new String[] { "*.txt" };
      break;
    case 16: 
      arrayOfString1 = new String[] { "*.xml" };
      break;
    case 32: 
      arrayOfString1 = new String[] { "*.xul" };
    }
    if (this.masks == null)
    {
      this.masks = arrayOfString1;
    }
    else if (arrayOfString1 != null)
    {
      String[] arrayOfString2 = new String[this.masks.length + arrayOfString1.length];
      System.arraycopy(this.masks, 0, arrayOfString2, 0, this.masks.length);
      System.arraycopy(arrayOfString1, 0, arrayOfString2, this.masks.length, arrayOfString1.length);
      this.masks = arrayOfString2;
    }
    return 0;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/browser/FilePicker.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */