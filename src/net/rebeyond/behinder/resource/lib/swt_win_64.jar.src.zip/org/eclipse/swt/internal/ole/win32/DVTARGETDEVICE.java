package org.eclipse.swt.internal.ole.win32;

public final class DVTARGETDEVICE
{
  public int tdSize;
  public short tdDriverNameOffset;
  public short tdDeviceNameOffset;
  public short tdPortNameOffset;
  public short tdExtDevmodeOffset;
  public byte[] tdData = new byte[1];
  public static final int sizeof = ;
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/internal/ole/win32/DVTARGETDEVICE.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */