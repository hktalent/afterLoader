package org.eclipse.swt.internal.mozilla;

public class nsIFilePicker
  extends nsISupports
{
  static final String NS_IFILEPICKER_IID_STR = "c47de916-1dd1-11b2-8141-82507fa02b21";
  static final String NS_IFILEPICKER_1_8_IID_STR = "80faf095-c807-4558-a2cc-185ed70754ea";
  static final String NS_IFILEPICKER_10_IID_STR = "f2c0e216-5d07-4df4-bbcb-37683077ae7e";
  static final String NS_IFILEPICKER_24_IID_STR = "a6a24df3-d20a-4b6a-96d4-4736b10a51b7";
  public static final int modeOpen = 0;
  public static final int modeSave = 1;
  public static final int modeGetFolder = 2;
  public static final int modeOpenMultiple = 3;
  public static final int returnOK = 0;
  public static final int returnCancel = 1;
  public static final int returnReplace = 2;
  public static final int filterAll = 1;
  public static final int filterHTML = 2;
  public static final int filterText = 4;
  public static final int filterImages = 8;
  public static final int filterXML = 16;
  public static final int filterXUL = 32;
  public static final int filterApps = 64;
  public static final int filterAllowURLs = 128;
  public static final int filterAudio = 256;
  public static final int filterVideo = 512;
  
  public nsIFilePicker(long paramLong)
  {
    super(paramLong);
  }
  
  static
  {
    IIDStore.RegisterIID(nsIFilePicker.class, 0, new nsID("c47de916-1dd1-11b2-8141-82507fa02b21"));
    IIDStore.RegisterIID(nsIFilePicker.class, 1, new nsID("80faf095-c807-4558-a2cc-185ed70754ea"));
    IIDStore.RegisterIID(nsIFilePicker.class, 5, new nsID("f2c0e216-5d07-4df4-bbcb-37683077ae7e"));
    IIDStore.RegisterIID(nsIFilePicker.class, 6, new nsID("a6a24df3-d20a-4b6a-96d4-4736b10a51b7"));
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/internal/mozilla/nsIFilePicker.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */