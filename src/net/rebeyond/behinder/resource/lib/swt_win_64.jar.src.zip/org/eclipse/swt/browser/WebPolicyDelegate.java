package org.eclipse.swt.browser;

import org.eclipse.swt.internal.Compatibility;
import org.eclipse.swt.internal.ole.win32.COM;
import org.eclipse.swt.internal.ole.win32.COMObject;
import org.eclipse.swt.internal.ole.win32.GUID;
import org.eclipse.swt.internal.ole.win32.IUnknown;
import org.eclipse.swt.internal.webkit.IWebError;
import org.eclipse.swt.internal.webkit.IWebPolicyDecisionListener;
import org.eclipse.swt.internal.webkit.IWebPreferences;
import org.eclipse.swt.internal.webkit.IWebURLRequest;
import org.eclipse.swt.internal.webkit.IWebView;
import org.eclipse.swt.internal.webkit.WebKit_win32;
import org.eclipse.swt.internal.win32.OS;
import org.eclipse.swt.widgets.MessageBox;

class WebPolicyDelegate
{
  COMObject iWebPolicyDelegate;
  int refCount = 0;
  Browser browser;
  
  WebPolicyDelegate(Browser paramBrowser)
  {
    createCOMInterfaces();
    this.browser = paramBrowser;
  }
  
  int AddRef()
  {
    this.refCount += 1;
    return this.refCount;
  }
  
  void createCOMInterfaces()
  {
    this.iWebPolicyDelegate = new COMObject(new int[] { 2, 0, 0, 5, 5, 5, 3 })
    {
      public long method0(long[] paramAnonymousArrayOfLong)
      {
        return WebPolicyDelegate.this.QueryInterface(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method1(long[] paramAnonymousArrayOfLong)
      {
        return WebPolicyDelegate.this.AddRef();
      }
      
      public long method2(long[] paramAnonymousArrayOfLong)
      {
        return WebPolicyDelegate.this.Release();
      }
      
      public long method3(long[] paramAnonymousArrayOfLong)
      {
        return WebPolicyDelegate.this.decidePolicyForNavigationAction(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2], paramAnonymousArrayOfLong[3], paramAnonymousArrayOfLong[4]);
      }
      
      public long method4(long[] paramAnonymousArrayOfLong)
      {
        return WebPolicyDelegate.this.decidePolicyForNewWindowAction(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2], paramAnonymousArrayOfLong[3], paramAnonymousArrayOfLong[4]);
      }
      
      public long method5(long[] paramAnonymousArrayOfLong)
      {
        return WebPolicyDelegate.this.decidePolicyForMIMEType(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2], paramAnonymousArrayOfLong[3], paramAnonymousArrayOfLong[4]);
      }
      
      public long method6(long[] paramAnonymousArrayOfLong)
      {
        return WebPolicyDelegate.this.unableToImplementPolicyWithError(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2]);
      }
    };
  }
  
  int decidePolicyForMIMEType(long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5)
  {
    IWebView localIWebView = new IWebView(paramLong1);
    int[] arrayOfInt = new int[1];
    localIWebView.canShowMIMEType(paramLong2, arrayOfInt);
    IWebPolicyDecisionListener localIWebPolicyDecisionListener = new IWebPolicyDecisionListener(paramLong5);
    if (arrayOfInt[0] != 0) {
      localIWebPolicyDecisionListener.use();
    } else {
      localIWebPolicyDecisionListener.download();
    }
    return 0;
  }
  
  int decidePolicyForNavigationAction(long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5)
  {
    IWebURLRequest localIWebURLRequest = new IWebURLRequest(paramLong3);
    long[] arrayOfLong = new long[1];
    int i = localIWebURLRequest.URL(arrayOfLong);
    if ((i != 0) || (arrayOfLong[0] == 0L)) {
      return 0;
    }
    String str = WebKit.extractBSTR(arrayOfLong[0]);
    COM.SysFreeString(arrayOfLong[0]);
    IWebPolicyDecisionListener localIWebPolicyDecisionListener = new IWebPolicyDecisionListener(paramLong5);
    WebKit localWebKit = (WebKit)this.browser.webBrowser;
    if (localWebKit.loadingText)
    {
      localIWebPolicyDecisionListener.use();
      return 0;
    }
    if (str.length() == 0)
    {
      localIWebPolicyDecisionListener.ignore();
      return 0;
    }
    if ((str.startsWith("file://")) && (localWebKit.getUrl().startsWith("about:blank")) && (localWebKit.untrustedText))
    {
      localIWebPolicyDecisionListener.ignore();
      return 0;
    }
    if (str.equals("file:///"))
    {
      str = "about:blank";
    }
    else
    {
      int j = "file:///".length();
      if ((str.startsWith("file:///")) && (str.charAt(j) == '#')) {
        str = "about:blank" + str.substring(j);
      }
    }
    LocationEvent localLocationEvent = new LocationEvent(this.browser);
    localLocationEvent.display = this.browser.getDisplay();
    localLocationEvent.widget = this.browser;
    localLocationEvent.location = str;
    localLocationEvent.doit = true;
    LocationListener[] arrayOfLocationListener = localWebKit.locationListeners;
    if (arrayOfLocationListener != null) {
      for (int k = 0; k < arrayOfLocationListener.length; k++) {
        arrayOfLocationListener[k].changing(localLocationEvent);
      }
    }
    if (localLocationEvent.doit)
    {
      if (localWebKit.jsEnabled != localWebKit.jsEnabledOnNextPage)
      {
        localWebKit.jsEnabled = localWebKit.jsEnabledOnNextPage;
        IWebView localIWebView = new IWebView(paramLong1);
        arrayOfLong[0] = 0L;
        i = localIWebView.preferences(arrayOfLong);
        if ((i == 0) && (arrayOfLong[0] != 0L))
        {
          IWebPreferences localIWebPreferences = new IWebPreferences(arrayOfLong[0]);
          i = localIWebPreferences.setJavaScriptEnabled(localWebKit.jsEnabled ? 1 : 0);
          localIWebView.setPreferences(localIWebPreferences.getAddress());
          localIWebPreferences.Release();
        }
      }
      localIWebPolicyDecisionListener.use();
      localWebKit.lastNavigateURL = str;
    }
    else
    {
      localIWebPolicyDecisionListener.ignore();
    }
    return 0;
  }
  
  int decidePolicyForNewWindowAction(long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5)
  {
    IWebPolicyDecisionListener localIWebPolicyDecisionListener = new IWebPolicyDecisionListener(paramLong5);
    localIWebPolicyDecisionListener.use();
    return 0;
  }
  
  protected void disposeCOMInterfaces()
  {
    if (this.iWebPolicyDelegate != null)
    {
      this.iWebPolicyDelegate.dispose();
      this.iWebPolicyDelegate = null;
    }
  }
  
  long getAddress()
  {
    return this.iWebPolicyDelegate.getAddress();
  }
  
  int QueryInterface(long paramLong1, long paramLong2)
  {
    if ((paramLong1 == 0L) || (paramLong2 == 0L)) {
      return -2147024809;
    }
    GUID localGUID = new GUID();
    COM.MoveMemory(localGUID, paramLong1, GUID.sizeof);
    if (COM.IsEqualGUID(localGUID, COM.IIDIUnknown))
    {
      COM.MoveMemory(paramLong2, new long[] { this.iWebPolicyDelegate.getAddress() }, OS.PTR_SIZEOF);
      new IUnknown(this.iWebPolicyDelegate.getAddress()).AddRef();
      return 0;
    }
    if (COM.IsEqualGUID(localGUID, WebKit_win32.IID_IWebPolicyDelegate))
    {
      COM.MoveMemory(paramLong2, new long[] { this.iWebPolicyDelegate.getAddress() }, OS.PTR_SIZEOF);
      new IUnknown(this.iWebPolicyDelegate.getAddress()).AddRef();
      return 0;
    }
    COM.MoveMemory(paramLong2, new long[] { 0L }, OS.PTR_SIZEOF);
    return -2147467262;
  }
  
  int Release()
  {
    this.refCount -= 1;
    if (this.refCount == 0) {
      disposeCOMInterfaces();
    }
    return this.refCount;
  }
  
  int unableToImplementPolicyWithError(long paramLong1, long paramLong2, long paramLong3)
  {
    if (this.browser.isDisposed()) {
      return 0;
    }
    IWebError localIWebError = new IWebError(paramLong2);
    String str1 = null;
    long[] arrayOfLong = new long[1];
    int i = localIWebError.failingURL(arrayOfLong);
    if ((i == 0) && (arrayOfLong[0] != 0L))
    {
      str1 = WebKit.extractBSTR(arrayOfLong[0]);
      COM.SysFreeString(arrayOfLong[0]);
    }
    arrayOfLong[0] = 0L;
    i = localIWebError.localizedDescription(arrayOfLong);
    if ((i != 0) || (arrayOfLong[0] == 0L)) {
      return 0;
    }
    String str2 = WebKit.extractBSTR(arrayOfLong[0]);
    COM.SysFreeString(arrayOfLong[0]);
    String str3 = str1 != null ? str1 + "\n\n" : "";
    str3 = str3 + Compatibility.getMessage("SWT_Page_Load_Failed", new Object[] { str2 });
    MessageBox localMessageBox = new MessageBox(this.browser.getShell(), 33);
    localMessageBox.setMessage(str3);
    localMessageBox.open();
    return 0;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/browser/WebPolicyDelegate.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */