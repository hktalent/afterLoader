package org.eclipse.swt.events;

import org.eclipse.swt.widgets.Event;

public final class ShellEvent
  extends TypedEvent
{
  public boolean doit;
  static final long serialVersionUID = 3257569490479888441L;
  
  public ShellEvent(Event paramEvent)
  {
    super(paramEvent);
    this.doit = paramEvent.doit;
  }
  
  public String toString()
  {
    String str = super.toString();
    return str.substring(0, str.length() - 1) + " doit=" + this.doit + "}";
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/events/ShellEvent.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */