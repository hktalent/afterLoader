package org.eclipse.swt.internal.ole.win32;

import org.eclipse.swt.internal.win32.POINT;
import org.eclipse.swt.internal.win32.SHDRAGIMAGE;

public class IDragSourceHelper
  extends IUnknown
{
  public IDragSourceHelper(long paramLong)
  {
    super(paramLong);
  }
  
  public int InitializeFromBitmap(SHDRAGIMAGE paramSHDRAGIMAGE, long paramLong)
  {
    return COM.VtblCall(3, this.address, paramSHDRAGIMAGE, paramLong);
  }
  
  public int InitializeFromWindow(long paramLong1, POINT paramPOINT, long paramLong2)
  {
    return COM.VtblCall(4, this.address, paramLong1, paramPOINT, paramLong2);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/internal/ole/win32/IDragSourceHelper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */