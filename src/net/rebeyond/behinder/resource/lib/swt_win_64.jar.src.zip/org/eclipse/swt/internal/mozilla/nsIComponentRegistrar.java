package org.eclipse.swt.internal.mozilla;

public class nsIComponentRegistrar
  extends nsISupports
{
  static final int LAST_METHOD_ID = nsISupports.LAST_METHOD_ID + 12;
  static final String NS_ICOMPONENTREGISTRAR_IID_STR = "2417cbfe-65ad-48a6-b4b6-eb84db174392";
  
  public nsIComponentRegistrar(long paramLong)
  {
    super(paramLong);
  }
  
  public int AutoRegister(long paramLong)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 1, getAddress(), paramLong);
  }
  
  public int RegisterFactory(nsID paramnsID, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, long paramLong)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 3, getAddress(), paramnsID, paramArrayOfByte1, paramArrayOfByte2, paramLong);
  }
  
  static
  {
    IIDStore.RegisterIID(nsIComponentRegistrar.class, 0, new nsID("2417cbfe-65ad-48a6-b4b6-eb84db174392"));
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/internal/mozilla/nsIComponentRegistrar.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */