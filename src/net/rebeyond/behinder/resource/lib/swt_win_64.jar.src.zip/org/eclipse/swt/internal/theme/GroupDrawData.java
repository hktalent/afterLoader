package org.eclipse.swt.internal.theme;

import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.internal.win32.OS;
import org.eclipse.swt.internal.win32.RECT;

public class GroupDrawData
  extends DrawData
{
  public int headerWidth;
  public int headerHeight;
  public Rectangle headerArea;
  static final int GROUP_HEADER_X = 9;
  static final int GROUP_HEADER_PAD = 2;
  
  public GroupDrawData()
  {
    this.state = new int[1];
  }
  
  void draw(Theme paramTheme, GC paramGC, Rectangle paramRectangle)
  {
    if ((OS.COMCTL32_MAJOR >= 6) && (OS.IsAppThemed()))
    {
      long l = OS.OpenThemeData(0L, getClassId());
      RECT localRECT1 = new RECT();
      localRECT1.left = paramRectangle.x;
      localRECT1.right = (paramRectangle.x + paramRectangle.width);
      localRECT1.top = (paramRectangle.y + this.headerHeight / 2);
      localRECT1.bottom = (paramRectangle.y + paramRectangle.height);
      int i = paramRectangle.x + 9;
      int j = paramRectangle.y;
      int k = OS.SaveDC(paramGC.handle);
      OS.ExcludeClipRect(paramGC.handle, i - 2, j, i + this.headerWidth + 2, j + this.headerHeight);
      int[] arrayOfInt = getPartId(0);
      OS.DrawThemeBackground(l, paramGC.handle, arrayOfInt[0], arrayOfInt[1], localRECT1, null);
      OS.RestoreDC(paramGC.handle, k);
      Rectangle localRectangle1 = this.headerArea;
      if (localRectangle1 != null)
      {
        localRectangle1.x = i;
        localRectangle1.y = j;
        localRectangle1.width = this.headerWidth;
        localRectangle1.height = this.headerHeight;
      }
      Rectangle localRectangle2 = this.clientArea;
      if (localRectangle2 != null)
      {
        RECT localRECT2 = new RECT();
        OS.GetThemeBackgroundContentRect(l, paramGC.handle, arrayOfInt[0], arrayOfInt[1], localRECT1, localRECT2);
        localRectangle2.x = localRECT2.left;
        localRectangle2.y = localRECT2.top;
        localRectangle2.width = (localRECT2.right - localRECT2.left);
        localRectangle2.height = (localRECT2.bottom - localRECT2.top);
      }
      OS.CloseThemeData(l);
    }
  }
  
  int[] getPartId(int paramInt)
  {
    int i = this.state[paramInt];
    int j = 4;
    int k = 1;
    if ((i & 0x20) != 0) {
      k = 2;
    }
    return new int[] { j, k };
  }
  
  int hit(Theme paramTheme, Point paramPoint, Rectangle paramRectangle)
  {
    return paramRectangle.contains(paramPoint) ? 0 : -1;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/internal/theme/GroupDrawData.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */