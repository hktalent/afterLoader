package org.eclipse.swt.internal.mozilla.init;

import org.eclipse.swt.internal.Lock;
import org.eclipse.swt.internal.Platform;

public class XPCOMInit
  extends Platform
{
  public static final int PATH_MAX = 4096;
  
  public static final native int GREProperty_sizeof();
  
  public static final native int GREVersionRange_sizeof();
  
  public static final native int _GRE_GetGREPathWithProperties(GREVersionRange paramGREVersionRange, int paramInt1, GREProperty paramGREProperty, int paramInt2, long paramLong, int paramInt3);
  
  public static final int GRE_GetGREPathWithProperties(GREVersionRange paramGREVersionRange, int paramInt1, GREProperty paramGREProperty, int paramInt2, long paramLong, int paramInt3)
  {
    lock.lock();
    try
    {
      int i = _GRE_GetGREPathWithProperties(paramGREVersionRange, paramInt1, paramGREProperty, paramInt2, paramLong, paramInt3);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _XPCOMGlueStartup(byte[] paramArrayOfByte);
  
  public static final int XPCOMGlueStartup(byte[] paramArrayOfByte)
  {
    lock.lock();
    try
    {
      int i = _XPCOMGlueStartup(paramArrayOfByte);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _XPCOMGlueShutdown();
  
  public static final int XPCOMGlueShutdown()
  {
    lock.lock();
    try
    {
      int i = _XPCOMGlueShutdown();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/internal/mozilla/init/XPCOMInit.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */