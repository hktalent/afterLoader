package org.eclipse.swt.internal.ole.win32;

import org.eclipse.swt.internal.win32.MSG;
import org.eclipse.swt.internal.win32.RECT;

public class IOleInPlaceActiveObject
  extends IOleWindow
{
  public IOleInPlaceActiveObject(long paramLong)
  {
    super(paramLong);
  }
  
  public int TranslateAccelerator(MSG paramMSG)
  {
    return COM.VtblCall(5, this.address, paramMSG);
  }
  
  public void OnFrameWindowActivate(boolean paramBoolean)
  {
    COM.VtblCall(6, getAddress(), paramBoolean);
  }
  
  public void OnDocWindowActivate(boolean paramBoolean)
  {
    COM.VtblCall(7, getAddress(), paramBoolean);
  }
  
  public int ResizeBorder(RECT paramRECT, long paramLong, boolean paramBoolean)
  {
    return COM.VtblCall(8, this.address, paramRECT, paramLong, paramBoolean);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/internal/ole/win32/IOleInPlaceActiveObject.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */