package org.eclipse.swt.internal.theme;

import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.internal.win32.OS;
import org.eclipse.swt.internal.win32.POINT;
import org.eclipse.swt.internal.win32.RECT;

public class ScrollBarDrawData
  extends RangeDrawData
{
  public int thumb;
  public int increment;
  public int pageIncrement;
  
  public ScrollBarDrawData()
  {
    this.state = new int[6];
  }
  
  void draw(Theme paramTheme, GC paramGC, Rectangle paramRectangle)
  {
    if ((OS.COMCTL32_MAJOR >= 6) && (OS.IsAppThemed()))
    {
      long l = OS.OpenThemeData(0L, getClassId());
      RECT localRECT = new RECT();
      int i;
      int[] arrayOfInt;
      int j;
      int k;
      int m;
      if ((this.style & 0x200) != 0)
      {
        i = OS.GetThemeSysSize(l, 2);
        localRECT.left = paramRectangle.x;
        localRECT.right = (localRECT.left + paramRectangle.width);
        localRECT.top = paramRectangle.y;
        localRECT.bottom = (localRECT.top + i);
        arrayOfInt = getPartId(1);
        OS.DrawThemeBackground(l, paramGC.handle, arrayOfInt[0], arrayOfInt[1], localRECT, null);
        localRECT.bottom = (paramRectangle.y + paramRectangle.height);
        localRECT.top = (localRECT.bottom - i);
        arrayOfInt = getPartId(2);
        OS.DrawThemeBackground(l, paramGC.handle, arrayOfInt[0], arrayOfInt[1], localRECT, null);
        j = paramRectangle.height - 2 * i;
        k = Math.max(i / 2, j * this.thumb / Math.max(1, this.maximum - this.minimum));
        m = paramRectangle.y + i + Math.max(0, j * this.selection / Math.max(1, this.maximum - this.minimum));
        localRECT.top = (paramRectangle.y + i);
        localRECT.bottom = m;
        arrayOfInt = getPartId(3);
        OS.DrawThemeBackground(l, paramGC.handle, arrayOfInt[0], arrayOfInt[1], localRECT, null);
        localRECT.top = localRECT.bottom;
        localRECT.bottom = (localRECT.top + k);
        arrayOfInt = getPartId(5);
        OS.DrawThemeBackground(l, paramGC.handle, arrayOfInt[0], arrayOfInt[1], localRECT, null);
        OS.DrawThemeBackground(l, paramGC.handle, 9, arrayOfInt[1], localRECT, null);
        localRECT.top = localRECT.bottom;
        localRECT.bottom = (paramRectangle.y + paramRectangle.height - i);
        arrayOfInt = getPartId(4);
        OS.DrawThemeBackground(l, paramGC.handle, arrayOfInt[0], arrayOfInt[1], localRECT, null);
      }
      else
      {
        i = OS.GetThemeSysSize(l, 2);
        localRECT.top = paramRectangle.y;
        localRECT.bottom = (localRECT.top + paramRectangle.height);
        localRECT.left = paramRectangle.x;
        localRECT.right = (localRECT.left + i);
        arrayOfInt = getPartId(1);
        OS.DrawThemeBackground(l, paramGC.handle, arrayOfInt[0], arrayOfInt[1], localRECT, null);
        localRECT.right = (paramRectangle.x + paramRectangle.width);
        localRECT.left = (localRECT.right - i);
        arrayOfInt = getPartId(2);
        OS.DrawThemeBackground(l, paramGC.handle, arrayOfInt[0], arrayOfInt[1], localRECT, null);
        j = paramRectangle.width - 2 * i;
        k = Math.max(i / 2, j * this.thumb / (this.maximum - this.minimum));
        m = paramRectangle.x + i + Math.max(0, j * this.selection / Math.max(1, this.maximum - this.minimum));
        localRECT.left = (paramRectangle.x + i);
        localRECT.right = m;
        arrayOfInt = getPartId(3);
        OS.DrawThemeBackground(l, paramGC.handle, arrayOfInt[0], arrayOfInt[1], localRECT, null);
        localRECT.left = localRECT.right;
        localRECT.right = (localRECT.left + k);
        arrayOfInt = getPartId(5);
        OS.DrawThemeBackground(l, paramGC.handle, arrayOfInt[0], arrayOfInt[1], localRECT, null);
        OS.DrawThemeBackground(l, paramGC.handle, 8, arrayOfInt[1], localRECT, null);
        localRECT.left = localRECT.right;
        localRECT.right = (paramRectangle.x + paramRectangle.width - i);
        arrayOfInt = getPartId(4);
        OS.DrawThemeBackground(l, paramGC.handle, arrayOfInt[0], arrayOfInt[1], localRECT, null);
      }
      OS.CloseThemeData(l);
    }
  }
  
  char[] getClassId()
  {
    return SCROLLBAR;
  }
  
  int[] getPartId(int paramInt)
  {
    int i = 0;
    int j = 0;
    int k = this.state[paramInt];
    switch (paramInt)
    {
    case 1: 
      i = 1;
      if ((this.style & 0x200) != 0)
      {
        j = 1;
        if ((k & 0x40) != 0) {
          j = 2;
        }
        if ((k & 0x8) != 0) {
          j = 3;
        }
        if ((k & 0x20) != 0) {
          j = 4;
        }
      }
      else
      {
        j = 9;
        if ((k & 0x40) != 0) {
          j = 10;
        }
        if ((k & 0x8) != 0) {
          j = 11;
        }
        if ((k & 0x20) != 0) {
          j = 12;
        }
      }
      break;
    case 2: 
      i = 1;
      if ((this.style & 0x200) != 0)
      {
        j = 5;
        if ((k & 0x40) != 0) {
          j = 6;
        }
        if ((k & 0x8) != 0) {
          j = 7;
        }
        if ((k & 0x20) != 0) {
          j = 8;
        }
      }
      else
      {
        j = 13;
        if ((k & 0x40) != 0) {
          j = 14;
        }
        if ((k & 0x8) != 0) {
          j = 15;
        }
        if ((k & 0x20) != 0) {
          j = 16;
        }
      }
      break;
    case 0: 
    case 5: 
      if ((this.style & 0x200) != 0) {
        i = 3;
      } else {
        i = 2;
      }
      break;
    case 3: 
      if ((this.style & 0x200) != 0) {
        i = 7;
      } else {
        i = 5;
      }
      break;
    case 4: 
      if ((this.style & 0x200) != 0) {
        i = 6;
      } else {
        i = 4;
      }
      break;
    }
    if ((paramInt != 2) && (paramInt != 1))
    {
      j = 1;
      if ((k & 0x40) != 0) {
        j = 2;
      }
      if ((k & 0x8) != 0) {
        j = 3;
      }
      if ((k & 0x20) != 0) {
        j = 4;
      }
    }
    return new int[] { i, j };
  }
  
  Rectangle getBounds(int paramInt, Rectangle paramRectangle)
  {
    if ((OS.COMCTL32_MAJOR >= 6) && (OS.IsAppThemed()))
    {
      long l = OS.OpenThemeData(0L, getClassId());
      if ((this.style & 0x200) != 0)
      {
        int i = OS.GetThemeSysSize(l, 2);
        int j = paramRectangle.height - 2 * i;
        int k = Math.max(i / 2, j * this.thumb / Math.max(1, this.maximum - this.minimum));
        int m = paramRectangle.y + i + Math.max(0, j * this.selection / Math.max(1, this.maximum - this.minimum));
        switch (paramInt)
        {
        case 2: 
          return new Rectangle(paramRectangle.x, paramRectangle.y + paramRectangle.height - i, paramRectangle.width, i);
        case 1: 
          return new Rectangle(paramRectangle.x, paramRectangle.y, paramRectangle.width, i);
        case 3: 
          return new Rectangle(paramRectangle.x, paramRectangle.y + i, paramRectangle.width, m - paramRectangle.y - i);
        case 5: 
          return new Rectangle(paramRectangle.x, m, paramRectangle.width, k);
        case 4: 
          return new Rectangle(paramRectangle.x, m + k, paramRectangle.width, paramRectangle.y + paramRectangle.height - i - m - k);
        }
      }
      OS.CloseThemeData(l);
    }
    return super.getBounds(paramInt, paramRectangle);
  }
  
  int getSelection(Point paramPoint, Rectangle paramRectangle)
  {
    if ((OS.COMCTL32_MAJOR >= 6) && (OS.IsAppThemed()))
    {
      long l = OS.OpenThemeData(0L, getClassId());
      if ((this.style & 0x200) != 0)
      {
        int i = OS.GetThemeSysSize(l, 2);
        int j = paramRectangle.height - 2 * i;
        int k = paramRectangle.y + i + Math.max(0, j * this.selection / Math.max(1, this.maximum - this.minimum));
        k += paramPoint.y;
        int m = (k - paramRectangle.y - i) * (this.maximum - this.minimum) / j;
        return Math.max(0, Math.min(m, this.maximum - this.thumb));
      }
      OS.CloseThemeData(l);
    }
    return 0;
  }
  
  int hit(Theme paramTheme, Point paramPoint, Rectangle paramRectangle)
  {
    if ((OS.COMCTL32_MAJOR < 6) || (!OS.IsAppThemed())) {
      return -1;
    }
    long l = OS.OpenThemeData(0L, getClassId());
    int i = 0;
    RECT localRECT = new RECT();
    POINT localPOINT = new POINT();
    localPOINT.x = paramPoint.x;
    localPOINT.y = paramPoint.y;
    short[] arrayOfShort = new short[1];
    try
    {
      int j;
      int[] arrayOfInt;
      int k;
      int m;
      int n;
      int i1;
      if ((this.style & 0x200) != 0)
      {
        j = OS.GetThemeSysSize(l, 2);
        localRECT.left = paramRectangle.x;
        localRECT.right = (localRECT.left + paramRectangle.width);
        localRECT.top = paramRectangle.y;
        localRECT.bottom = (localRECT.top + j);
        arrayOfInt = getPartId(1);
        OS.HitTestThemeBackground(l, i, arrayOfInt[0], arrayOfInt[1], 0, localRECT, 0L, localPOINT, arrayOfShort);
        if (arrayOfShort[0] != 0)
        {
          k = 1;
          return k;
        }
        localRECT.bottom = (paramRectangle.y + paramRectangle.height);
        localRECT.top = (localRECT.bottom - j);
        arrayOfInt = getPartId(2);
        OS.HitTestThemeBackground(l, i, arrayOfInt[0], arrayOfInt[1], 0, localRECT, 0L, localPOINT, arrayOfShort);
        if (arrayOfShort[0] != 0)
        {
          k = 2;
          return k;
        }
        k = paramRectangle.height - 2 * j;
        m = Math.max(j / 2, k * this.thumb / Math.max(1, this.maximum - this.minimum));
        n = paramRectangle.y + j + Math.max(0, k * this.selection / Math.max(1, this.maximum - this.minimum));
        localRECT.top = (paramRectangle.y + j);
        localRECT.bottom = n;
        arrayOfInt = getPartId(5);
        OS.HitTestThemeBackground(l, i, arrayOfInt[0], arrayOfInt[1], 0, localRECT, 0L, localPOINT, arrayOfShort);
        if (arrayOfShort[0] != 0)
        {
          i1 = 3;
          return i1;
        }
        localRECT.top = localRECT.bottom;
        localRECT.bottom = (localRECT.top + m);
        arrayOfInt = getPartId(3);
        OS.HitTestThemeBackground(l, i, arrayOfInt[0], arrayOfInt[1], 0, localRECT, 0L, localPOINT, arrayOfShort);
        if (arrayOfShort[0] != 0)
        {
          i1 = 5;
          return i1;
        }
        localRECT.top = localRECT.bottom;
        localRECT.bottom = (paramRectangle.y + paramRectangle.height - j);
        arrayOfInt = getPartId(4);
        OS.HitTestThemeBackground(l, i, arrayOfInt[0], arrayOfInt[1], 0, localRECT, 0L, localPOINT, arrayOfShort);
        if (arrayOfShort[0] != 0)
        {
          i1 = 4;
          return i1;
        }
      }
      else
      {
        j = OS.GetThemeSysSize(l, 2);
        localRECT.top = paramRectangle.y;
        localRECT.bottom = (localRECT.top + paramRectangle.height);
        localRECT.left = paramRectangle.x;
        localRECT.right = (localRECT.left + j);
        arrayOfInt = getPartId(1);
        OS.HitTestThemeBackground(l, i, arrayOfInt[0], arrayOfInt[1], 0, localRECT, 0L, localPOINT, arrayOfShort);
        if (arrayOfShort[0] != 0)
        {
          k = 1;
          return k;
        }
        localRECT.right = (paramRectangle.x + paramRectangle.width);
        localRECT.left = (localRECT.right - j);
        arrayOfInt = getPartId(2);
        OS.HitTestThemeBackground(l, i, arrayOfInt[0], arrayOfInt[1], 0, localRECT, 0L, localPOINT, arrayOfShort);
        if (arrayOfShort[0] != 0)
        {
          k = 2;
          return k;
        }
        k = paramRectangle.width - 2 * j;
        m = Math.max(j / 2, k * this.thumb / (this.maximum - this.minimum));
        n = paramRectangle.x + j + Math.max(0, k * this.selection / Math.max(1, this.maximum - this.minimum));
        localRECT.left = (paramRectangle.x + j);
        localRECT.right = n;
        arrayOfInt = getPartId(3);
        OS.HitTestThemeBackground(l, i, arrayOfInt[0], arrayOfInt[1], 0, localRECT, 0L, localPOINT, arrayOfShort);
        if (arrayOfShort[0] != 0)
        {
          i1 = 3;
          return i1;
        }
        localRECT.left = localRECT.right;
        localRECT.right = (localRECT.left + m);
        arrayOfInt = getPartId(5);
        OS.HitTestThemeBackground(l, i, arrayOfInt[0], arrayOfInt[1], 0, localRECT, 0L, localPOINT, arrayOfShort);
        if (arrayOfShort[0] != 0)
        {
          i1 = 5;
          return i1;
        }
        localRECT.left = localRECT.right;
        localRECT.right = (paramRectangle.x + paramRectangle.width - j);
        arrayOfInt = getPartId(4);
        OS.HitTestThemeBackground(l, i, arrayOfInt[0], arrayOfInt[1], 0, localRECT, 0L, localPOINT, arrayOfShort);
        if (arrayOfShort[0] != 0)
        {
          i1 = 4;
          return i1;
        }
      }
    }
    finally
    {
      OS.CloseThemeData(l);
    }
    return -1;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/internal/theme/ScrollBarDrawData.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */