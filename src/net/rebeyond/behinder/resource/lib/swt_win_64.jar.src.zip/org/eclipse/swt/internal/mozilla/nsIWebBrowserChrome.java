package org.eclipse.swt.internal.mozilla;

public class nsIWebBrowserChrome
  extends nsISupports
{
  static final int LAST_METHOD_ID = nsISupports.LAST_METHOD_ID + 10;
  static final String NS_IWEBBROWSERCHROME_IID_STR = "ba434c60-9d52-11d3-afb0-00a024ffc08c";
  static final String NS_IWEBBROWSERCHROME_24_IID_STR = "e8c414c4-dc38-4ba3-ab4e-ec4cbbe22907";
  public static final int STATUS_SCRIPT = 1;
  public static final int STATUS_SCRIPT_DEFAULT = 2;
  public static final int STATUS_LINK = 3;
  public static final int CHROME_DEFAULT = 1;
  public static final int CHROME_WINDOW_BORDERS = 2;
  public static final int CHROME_WINDOW_CLOSE = 4;
  public static final int CHROME_WINDOW_RESIZE = 8;
  public static final int CHROME_MENUBAR = 16;
  public static final int CHROME_TOOLBAR = 32;
  public static final int CHROME_LOCATIONBAR = 64;
  public static final int CHROME_STATUSBAR = 128;
  public static final int CHROME_PERSONAL_TOOLBAR = 256;
  public static final int CHROME_SCROLLBARS = 512;
  public static final int CHROME_TITLEBAR = 1024;
  public static final int CHROME_EXTRA = 2048;
  public static final int CHROME_WITH_SIZE = 4096;
  public static final int CHROME_WITH_POSITION = 8192;
  public static final int CHROME_WINDOW_MIN = 16384;
  public static final int CHROME_WINDOW_POPUP = 32768;
  public static final int CHROME_WINDOW_RAISED = 33554432;
  public static final int CHROME_WINDOW_LOWERED = 67108864;
  public static final int CHROME_CENTER_SCREEN = 134217728;
  public static final int CHROME_DEPENDENT = 268435456;
  public static final int CHROME_MODAL = 536870912;
  public static final int CHROME_OPENAS_DIALOG = 1073741824;
  public static final int CHROME_OPENAS_CHROME = Integer.MIN_VALUE;
  public static final int CHROME_ALL = 4094;
  
  public nsIWebBrowserChrome(long paramLong)
  {
    super(paramLong);
  }
  
  public int GetWebBrowser(long[] paramArrayOfLong)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 2, getAddress(), paramArrayOfLong);
  }
  
  public int SetChromeFlags(int paramInt)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 5, getAddress(), paramInt);
  }
  
  static
  {
    IIDStore.RegisterIID(nsIWebBrowserChrome.class, 0, new nsID("ba434c60-9d52-11d3-afb0-00a024ffc08c"));
    IIDStore.RegisterIID(nsIWebBrowserChrome.class, 6, new nsID("e8c414c4-dc38-4ba3-ab4e-ec4cbbe22907"));
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/internal/mozilla/nsIWebBrowserChrome.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */