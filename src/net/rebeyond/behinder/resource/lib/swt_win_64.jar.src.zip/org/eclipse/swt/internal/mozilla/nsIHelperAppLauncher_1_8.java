package org.eclipse.swt.internal.mozilla;

public class nsIHelperAppLauncher_1_8
  extends nsICancelable
{
  static final int LAST_METHOD_ID = nsICancelable.LAST_METHOD_ID + (MozillaVersion.CheckVersion(2) ? 10 : 9);
  static final String NS_IHELPERAPPLAUNCHER_IID_STR = "99a0882d-2ff9-4659-9952-9ac531ba5592";
  static final String NS_IHELPERAPPLAUNCHER_1_9_IID_STR = "cc75c21a-0a79-4f68-90e1-563253d0c555";
  
  public nsIHelperAppLauncher_1_8(long paramLong)
  {
    super(paramLong);
  }
  
  public int SaveToDisk(long paramLong, int paramInt)
  {
    return XPCOM.VtblCall(nsICancelable.LAST_METHOD_ID + 4, getAddress(), paramLong, paramInt);
  }
  
  static
  {
    IIDStore.RegisterIID(nsIHelperAppLauncher_1_8.class, 0, new nsID("99a0882d-2ff9-4659-9952-9ac531ba5592"));
    IIDStore.RegisterIID(nsIHelperAppLauncher_1_8.class, 2, new nsID("cc75c21a-0a79-4f68-90e1-563253d0c555"));
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_win_64.jar!/org/eclipse/swt/internal/mozilla/nsIHelperAppLauncher_1_8.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */