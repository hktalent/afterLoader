package org.eclipse.swt.graphics;

import org.eclipse.swt.SWT;

public final class Color
  extends Resource
{
  public double[] handle;
  
  Color(Device paramDevice)
  {
    super(paramDevice);
  }
  
  public Color(Device paramDevice, int paramInt1, int paramInt2, int paramInt3)
  {
    super(paramDevice);
    init(paramInt1, paramInt2, paramInt3);
    init();
  }
  
  public Color(Device paramDevice, RGB paramRGB)
  {
    super(paramDevice);
    if (paramRGB == null) {
      SWT.error(4);
    }
    init(paramRGB.red, paramRGB.green, paramRGB.blue);
    init();
  }
  
  void destroy()
  {
    this.handle = null;
  }
  
  public boolean equals(Object paramObject)
  {
    if (paramObject == this) {
      return true;
    }
    if (!(paramObject instanceof Color)) {
      return false;
    }
    Color localColor = (Color)paramObject;
    double[] arrayOfDouble = localColor.handle;
    if (this.handle == arrayOfDouble) {
      return true;
    }
    return (this.device == localColor.device) && ((int)(this.handle[0] * 255.0D) == (int)(arrayOfDouble[0] * 255.0D)) && ((int)(this.handle[1] * 255.0D) == (int)(arrayOfDouble[1] * 255.0D)) && ((int)(this.handle[2] * 255.0D) == (int)(arrayOfDouble[2] * 255.0D));
  }
  
  public int getBlue()
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    return (int)(this.handle[2] * 255.0D);
  }
  
  public int getGreen()
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    return (int)(this.handle[1] * 255.0D);
  }
  
  public int getRed()
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    return (int)(this.handle[0] * 255.0D);
  }
  
  public int hashCode()
  {
    if (isDisposed()) {
      return 0;
    }
    return (int)(this.handle[0] * 255.0D) ^ (int)(this.handle[1] * 255.0D) ^ (int)(this.handle[2] * 255.0D);
  }
  
  public RGB getRGB()
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    return new RGB(getRed(), getGreen(), getBlue());
  }
  
  public static Color cocoa_new(Device paramDevice, double[] paramArrayOfDouble)
  {
    double[] arrayOfDouble = paramArrayOfDouble;
    Color localColor = new Color(paramDevice);
    localColor.handle = arrayOfDouble;
    return localColor;
  }
  
  void init(int paramInt1, int paramInt2, int paramInt3)
  {
    if ((paramInt1 > 255) || (paramInt1 < 0) || (paramInt2 > 255) || (paramInt2 < 0) || (paramInt3 > 255) || (paramInt3 < 0)) {
      SWT.error(5);
    }
    double[] arrayOfDouble = new double[4];
    arrayOfDouble[0] = (paramInt1 / 255.0F);
    arrayOfDouble[1] = (paramInt2 / 255.0F);
    arrayOfDouble[2] = (paramInt3 / 255.0F);
    arrayOfDouble[3] = 1.0D;
    this.handle = arrayOfDouble;
  }
  
  public boolean isDisposed()
  {
    return this.handle == null;
  }
  
  public String toString()
  {
    if (isDisposed()) {
      return "Color {*DISPOSED*}";
    }
    return "Color {" + getRed() + ", " + getGreen() + ", " + getBlue() + "}";
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/graphics/Color.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */