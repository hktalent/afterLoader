package org.eclipse.swt.internal.cocoa;

public class NSMenu
  extends NSObject
{
  public NSMenu() {}
  
  public NSMenu(long paramLong)
  {
    super(paramLong);
  }
  
  public NSMenu(id paramid)
  {
    super(paramid);
  }
  
  public void addItem(NSMenuItem paramNSMenuItem)
  {
    OS.objc_msgSend(this.id, OS.sel_addItem_, paramNSMenuItem != null ? paramNSMenuItem.id : 0L);
  }
  
  public NSMenuItem addItemWithTitle(NSString paramNSString1, long paramLong, NSString paramNSString2)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_addItemWithTitle_action_keyEquivalent_, paramNSString1 != null ? paramNSString1.id : 0L, paramLong, paramNSString2 != null ? paramNSString2.id : 0L);
    return l != 0L ? new NSMenuItem(l) : null;
  }
  
  public void cancelTracking()
  {
    OS.objc_msgSend(this.id, OS.sel_cancelTracking);
  }
  
  public long indexOfItemWithTarget(id paramid, long paramLong)
  {
    return OS.objc_msgSend(this.id, OS.sel_indexOfItemWithTarget_andAction_, paramid != null ? paramid.id : 0L, paramLong);
  }
  
  public NSMenu initWithTitle(NSString paramNSString)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_initWithTitle_, paramNSString != null ? paramNSString.id : 0L);
    return l != 0L ? new NSMenu(l) : l == this.id ? this : null;
  }
  
  public void insertItem(NSMenuItem paramNSMenuItem, long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_insertItem_atIndex_, paramNSMenuItem != null ? paramNSMenuItem.id : 0L, paramLong);
  }
  
  public NSArray itemArray()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_itemArray);
    return l != 0L ? new NSArray(l) : null;
  }
  
  public NSMenuItem itemAtIndex(long paramLong)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_itemAtIndex_, paramLong);
    return l != 0L ? new NSMenuItem(l) : null;
  }
  
  public NSMenuItem itemWithTag(long paramLong)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_itemWithTag_, paramLong);
    return l != 0L ? new NSMenuItem(l) : null;
  }
  
  public long numberOfItems()
  {
    return OS.objc_msgSend(this.id, OS.sel_numberOfItems);
  }
  
  public boolean performKeyEquivalent(NSEvent paramNSEvent)
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_performKeyEquivalent_, paramNSEvent != null ? paramNSEvent.id : 0L);
  }
  
  public static void popUpContextMenu(NSMenu paramNSMenu, NSEvent paramNSEvent, NSView paramNSView)
  {
    OS.objc_msgSend(OS.class_NSMenu, OS.sel_popUpContextMenu_withEvent_forView_, paramNSMenu != null ? paramNSMenu.id : 0L, paramNSEvent != null ? paramNSEvent.id : 0L, paramNSView != null ? paramNSView.id : 0L);
  }
  
  public void removeItem(NSMenuItem paramNSMenuItem)
  {
    OS.objc_msgSend(this.id, OS.sel_removeItem_, paramNSMenuItem != null ? paramNSMenuItem.id : 0L);
  }
  
  public void removeItemAtIndex(long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_removeItemAtIndex_, paramLong);
  }
  
  public void setAutoenablesItems(boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_setAutoenablesItems_, paramBoolean);
  }
  
  public void setDelegate(id paramid)
  {
    OS.objc_msgSend(this.id, OS.sel_setDelegate_, paramid != null ? paramid.id : 0L);
  }
  
  public void setSubmenu(NSMenu paramNSMenu, NSMenuItem paramNSMenuItem)
  {
    OS.objc_msgSend(this.id, OS.sel_setSubmenu_forItem_, paramNSMenu != null ? paramNSMenu.id : 0L, paramNSMenuItem != null ? paramNSMenuItem.id : 0L);
  }
  
  public void setTitle(NSString paramNSString)
  {
    OS.objc_msgSend(this.id, OS.sel_setTitle_, paramNSString != null ? paramNSString.id : 0L);
  }
  
  public NSString title()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_title);
    return l != 0L ? new NSString(l) : null;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSMenu.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */