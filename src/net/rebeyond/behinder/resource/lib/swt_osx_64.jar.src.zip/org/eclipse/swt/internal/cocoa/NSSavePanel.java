package org.eclipse.swt.internal.cocoa;

public class NSSavePanel
  extends NSPanel
{
  public NSSavePanel() {}
  
  public NSSavePanel(long paramLong)
  {
    super(paramLong);
  }
  
  public NSSavePanel(id paramid)
  {
    super(paramid);
  }
  
  public NSString filename()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_filename);
    return l != 0L ? new NSString(l) : null;
  }
  
  public long runModal()
  {
    return OS.objc_msgSend(this.id, OS.sel_runModal);
  }
  
  public long runModalForDirectory(NSString paramNSString1, NSString paramNSString2)
  {
    return OS.objc_msgSend(this.id, OS.sel_runModalForDirectory_file_, paramNSString1 != null ? paramNSString1.id : 0L, paramNSString2 != null ? paramNSString2.id : 0L);
  }
  
  public static NSSavePanel savePanel()
  {
    long l = OS.objc_msgSend(OS.class_NSSavePanel, OS.sel_savePanel);
    return l != 0L ? new NSSavePanel(l) : null;
  }
  
  public void setAccessoryView(NSView paramNSView)
  {
    OS.objc_msgSend(this.id, OS.sel_setAccessoryView_, paramNSView != null ? paramNSView.id : 0L);
  }
  
  public void setAllowedFileTypes(NSArray paramNSArray)
  {
    OS.objc_msgSend(this.id, OS.sel_setAllowedFileTypes_, paramNSArray != null ? paramNSArray.id : 0L);
  }
  
  public void setAllowsOtherFileTypes(boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_setAllowsOtherFileTypes_, paramBoolean);
  }
  
  public void setCanCreateDirectories(boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_setCanCreateDirectories_, paramBoolean);
  }
  
  public void setDirectory(NSString paramNSString)
  {
    OS.objc_msgSend(this.id, OS.sel_setDirectory_, paramNSString != null ? paramNSString.id : 0L);
  }
  
  public void setMessage(NSString paramNSString)
  {
    OS.objc_msgSend(this.id, OS.sel_setMessage_, paramNSString != null ? paramNSString.id : 0L);
  }
  
  public void setTitle(NSString paramNSString)
  {
    OS.objc_msgSend(this.id, OS.sel_setTitle_, paramNSString != null ? paramNSString.id : 0L);
  }
  
  public void validateVisibleColumns()
  {
    OS.objc_msgSend(this.id, OS.sel_validateVisibleColumns);
  }
  
  public static double minFrameWidthWithTitle(NSString paramNSString, long paramLong)
  {
    return OS.objc_msgSend_fpret(OS.class_NSSavePanel, OS.sel_minFrameWidthWithTitle_styleMask_, paramNSString != null ? paramNSString.id : 0L, paramLong);
  }
  
  public static long windowNumberAtPoint(NSPoint paramNSPoint, long paramLong)
  {
    return OS.objc_msgSend(OS.class_NSSavePanel, OS.sel_windowNumberAtPoint_belowWindowWithWindowNumber_, paramNSPoint, paramLong);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSSavePanel.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */