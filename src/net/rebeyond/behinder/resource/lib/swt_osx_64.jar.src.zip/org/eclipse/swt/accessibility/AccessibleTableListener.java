package org.eclipse.swt.accessibility;

import org.eclipse.swt.internal.SWTEventListener;

public abstract interface AccessibleTableListener
  extends SWTEventListener
{
  public abstract void deselectColumn(AccessibleTableEvent paramAccessibleTableEvent);
  
  public abstract void deselectRow(AccessibleTableEvent paramAccessibleTableEvent);
  
  public abstract void getCaption(AccessibleTableEvent paramAccessibleTableEvent);
  
  public abstract void getCell(AccessibleTableEvent paramAccessibleTableEvent);
  
  public abstract void getColumn(AccessibleTableEvent paramAccessibleTableEvent);
  
  public abstract void getColumnCount(AccessibleTableEvent paramAccessibleTableEvent);
  
  public abstract void getColumnDescription(AccessibleTableEvent paramAccessibleTableEvent);
  
  public abstract void getColumnHeader(AccessibleTableEvent paramAccessibleTableEvent);
  
  public abstract void getColumnHeaderCells(AccessibleTableEvent paramAccessibleTableEvent);
  
  public abstract void getColumns(AccessibleTableEvent paramAccessibleTableEvent);
  
  public abstract void getRow(AccessibleTableEvent paramAccessibleTableEvent);
  
  public abstract void getRowCount(AccessibleTableEvent paramAccessibleTableEvent);
  
  public abstract void getRowDescription(AccessibleTableEvent paramAccessibleTableEvent);
  
  public abstract void getRowHeader(AccessibleTableEvent paramAccessibleTableEvent);
  
  public abstract void getRowHeaderCells(AccessibleTableEvent paramAccessibleTableEvent);
  
  public abstract void getRows(AccessibleTableEvent paramAccessibleTableEvent);
  
  public abstract void getSelectedCellCount(AccessibleTableEvent paramAccessibleTableEvent);
  
  public abstract void getSelectedCells(AccessibleTableEvent paramAccessibleTableEvent);
  
  public abstract void getSelectedColumnCount(AccessibleTableEvent paramAccessibleTableEvent);
  
  public abstract void getSelectedColumns(AccessibleTableEvent paramAccessibleTableEvent);
  
  public abstract void getSelectedRowCount(AccessibleTableEvent paramAccessibleTableEvent);
  
  public abstract void getSelectedRows(AccessibleTableEvent paramAccessibleTableEvent);
  
  public abstract void getSummary(AccessibleTableEvent paramAccessibleTableEvent);
  
  public abstract void getVisibleColumns(AccessibleTableEvent paramAccessibleTableEvent);
  
  public abstract void getVisibleRows(AccessibleTableEvent paramAccessibleTableEvent);
  
  public abstract void isColumnSelected(AccessibleTableEvent paramAccessibleTableEvent);
  
  public abstract void isRowSelected(AccessibleTableEvent paramAccessibleTableEvent);
  
  public abstract void selectColumn(AccessibleTableEvent paramAccessibleTableEvent);
  
  public abstract void selectRow(AccessibleTableEvent paramAccessibleTableEvent);
  
  public abstract void setSelectedColumn(AccessibleTableEvent paramAccessibleTableEvent);
  
  public abstract void setSelectedRow(AccessibleTableEvent paramAccessibleTableEvent);
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/accessibility/AccessibleTableListener.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */