package org.eclipse.swt.internal.cocoa;

public class NSScrollView
  extends NSView
{
  public NSScrollView() {}
  
  public NSScrollView(long paramLong)
  {
    super(paramLong);
  }
  
  public NSScrollView(id paramid)
  {
    super(paramid);
  }
  
  public NSSize contentSize()
  {
    NSSize localNSSize = new NSSize();
    OS.objc_msgSend_stret(localNSSize, this.id, OS.sel_contentSize);
    return localNSSize;
  }
  
  public static NSSize contentSizeForFrameSize(NSSize paramNSSize, boolean paramBoolean1, boolean paramBoolean2, long paramLong)
  {
    NSSize localNSSize = new NSSize();
    OS.objc_msgSend_stret(localNSSize, OS.class_NSScrollView, OS.sel_contentSizeForFrameSize_hasHorizontalScroller_hasVerticalScroller_borderType_, paramNSSize, paramBoolean1, paramBoolean2, paramLong);
    return localNSSize;
  }
  
  public NSClipView contentView()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_contentView);
    return l != 0L ? new NSClipView(l) : null;
  }
  
  public NSView documentView()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_documentView);
    return l != 0L ? new NSView(l) : null;
  }
  
  public NSRect documentVisibleRect()
  {
    NSRect localNSRect = new NSRect();
    OS.objc_msgSend_stret(localNSRect, this.id, OS.sel_documentVisibleRect);
    return localNSRect;
  }
  
  public static NSSize frameSizeForContentSize(NSSize paramNSSize, boolean paramBoolean1, boolean paramBoolean2, long paramLong)
  {
    NSSize localNSSize = new NSSize();
    OS.objc_msgSend_stret(localNSSize, OS.class_NSScrollView, OS.sel_frameSizeForContentSize_hasHorizontalScroller_hasVerticalScroller_borderType_, paramNSSize, paramBoolean1, paramBoolean2, paramLong);
    return localNSSize;
  }
  
  public void reflectScrolledClipView(NSClipView paramNSClipView)
  {
    OS.objc_msgSend(this.id, OS.sel_reflectScrolledClipView_, paramNSClipView != null ? paramNSClipView.id : 0L);
  }
  
  public void setAutohidesScrollers(boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_setAutohidesScrollers_, paramBoolean);
  }
  
  public void setBorderType(long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_setBorderType_, paramLong);
  }
  
  public void setDocumentView(NSView paramNSView)
  {
    OS.objc_msgSend(this.id, OS.sel_setDocumentView_, paramNSView != null ? paramNSView.id : 0L);
  }
  
  public void setDrawsBackground(boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_setDrawsBackground_, paramBoolean);
  }
  
  public void setHasHorizontalScroller(boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_setHasHorizontalScroller_, paramBoolean);
  }
  
  public void setHasVerticalScroller(boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_setHasVerticalScroller_, paramBoolean);
  }
  
  public void setHorizontalScroller(NSScroller paramNSScroller)
  {
    OS.objc_msgSend(this.id, OS.sel_setHorizontalScroller_, paramNSScroller != null ? paramNSScroller.id : 0L);
  }
  
  public void setVerticalScroller(NSScroller paramNSScroller)
  {
    OS.objc_msgSend(this.id, OS.sel_setVerticalScroller_, paramNSScroller != null ? paramNSScroller.id : 0L);
  }
  
  public void tile()
  {
    OS.objc_msgSend(this.id, OS.sel_tile);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSScrollView.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */