package org.eclipse.swt.internal.cocoa;

public class WebView
  extends NSView
{
  public WebView() {}
  
  public WebView(long paramLong)
  {
    super(paramLong);
  }
  
  public WebView(id paramid)
  {
    super(paramid);
  }
  
  public boolean canGoBack()
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_canGoBack);
  }
  
  public boolean canGoForward()
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_canGoForward);
  }
  
  public static boolean canShowMIMEType(NSString paramNSString)
  {
    return OS.objc_msgSend_bool(OS.class_WebView, OS.sel_canShowMIMEType_, paramNSString != null ? paramNSString.id : 0L);
  }
  
  public void copy(id paramid)
  {
    OS.objc_msgSend(this.id, OS.sel_copy_, paramid != null ? paramid.id : 0L);
  }
  
  public void cut(id paramid)
  {
    OS.objc_msgSend(this.id, OS.sel_cut_, paramid != null ? paramid.id : 0L);
  }
  
  public boolean goBack()
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_goBack);
  }
  
  public boolean goForward()
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_goForward);
  }
  
  public WebView initWithFrame(NSRect paramNSRect, NSString paramNSString1, NSString paramNSString2)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_initWithFrame_frameName_groupName_, paramNSRect, paramNSString1 != null ? paramNSString1.id : 0L, paramNSString2 != null ? paramNSString2.id : 0L);
    return l != 0L ? new WebView(l) : l == this.id ? this : null;
  }
  
  public WebFrame mainFrame()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_mainFrame);
    return l != 0L ? new WebFrame(l) : null;
  }
  
  public void paste(id paramid)
  {
    OS.objc_msgSend(this.id, OS.sel_paste_, paramid != null ? paramid.id : 0L);
  }
  
  public void reload(id paramid)
  {
    OS.objc_msgSend(this.id, OS.sel_reload_, paramid != null ? paramid.id : 0L);
  }
  
  public void setApplicationNameForUserAgent(NSString paramNSString)
  {
    OS.objc_msgSend(this.id, OS.sel_setApplicationNameForUserAgent_, paramNSString != null ? paramNSString.id : 0L);
  }
  
  public void setCustomUserAgent(NSString paramNSString)
  {
    OS.objc_msgSend(this.id, OS.sel_setCustomUserAgent_, paramNSString != null ? paramNSString.id : 0L);
  }
  
  public void setDownloadDelegate(id paramid)
  {
    OS.objc_msgSend(this.id, OS.sel_setDownloadDelegate_, paramid != null ? paramid.id : 0L);
  }
  
  public void setFrameLoadDelegate(id paramid)
  {
    OS.objc_msgSend(this.id, OS.sel_setFrameLoadDelegate_, paramid != null ? paramid.id : 0L);
  }
  
  public void setPolicyDelegate(id paramid)
  {
    OS.objc_msgSend(this.id, OS.sel_setPolicyDelegate_, paramid != null ? paramid.id : 0L);
  }
  
  public void setPreferences(WebPreferences paramWebPreferences)
  {
    OS.objc_msgSend(this.id, OS.sel_setPreferences_, paramWebPreferences != null ? paramWebPreferences.id : 0L);
  }
  
  public void setResourceLoadDelegate(id paramid)
  {
    OS.objc_msgSend(this.id, OS.sel_setResourceLoadDelegate_, paramid != null ? paramid.id : 0L);
  }
  
  public void setUIDelegate(id paramid)
  {
    OS.objc_msgSend(this.id, OS.sel_setUIDelegate_, paramid != null ? paramid.id : 0L);
  }
  
  public void stopLoading(id paramid)
  {
    OS.objc_msgSend(this.id, OS.sel_stopLoading_, paramid != null ? paramid.id : 0L);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/WebView.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */