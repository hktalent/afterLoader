package org.eclipse.swt.graphics;

import org.eclipse.swt.SWT;
import org.eclipse.swt.internal.cocoa.NSAutoreleasePool;
import org.eclipse.swt.internal.cocoa.NSColor;
import org.eclipse.swt.internal.cocoa.NSGradient;
import org.eclipse.swt.internal.cocoa.NSObject;
import org.eclipse.swt.internal.cocoa.NSPoint;
import org.eclipse.swt.internal.cocoa.NSThread;

public class Pattern
  extends Resource
{
  NSColor color;
  NSGradient gradient;
  NSPoint pt1;
  NSPoint pt2;
  Image image;
  double[] color1;
  double[] color2;
  int alpha1;
  int alpha2;
  
  public Pattern(Device paramDevice, Image paramImage)
  {
    super(paramDevice);
    if (paramImage == null) {
      SWT.error(4);
    }
    if (paramImage.isDisposed()) {
      SWT.error(5);
    }
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      this.image = paramImage;
      this.color = NSColor.colorWithPatternImage(paramImage.handle);
      this.color.retain();
      init();
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  public Pattern(Device paramDevice, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, Color paramColor1, Color paramColor2)
  {
    this(paramDevice, paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramColor1, 255, paramColor2, 255);
  }
  
  public Pattern(Device paramDevice, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, Color paramColor1, int paramInt1, Color paramColor2, int paramInt2)
  {
    super(paramDevice);
    if (paramColor1 == null) {
      SWT.error(4);
    }
    if (paramColor1.isDisposed()) {
      SWT.error(5);
    }
    if (paramColor2 == null) {
      SWT.error(4);
    }
    if (paramColor2.isDisposed()) {
      SWT.error(5);
    }
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      this.pt1 = new NSPoint();
      this.pt2 = new NSPoint();
      this.pt1.x = paramFloat1;
      this.pt1.y = paramFloat2;
      this.pt2.x = paramFloat3;
      this.pt2.y = paramFloat4;
      this.color1 = paramColor1.handle;
      this.color2 = paramColor2.handle;
      this.alpha1 = paramInt1;
      this.alpha2 = paramInt2;
      NSColor localNSColor1 = NSColor.colorWithDeviceRed(paramColor1.handle[0], paramColor1.handle[1], paramColor1.handle[2], paramInt1 / 255.0F);
      NSColor localNSColor2 = NSColor.colorWithDeviceRed(paramColor2.handle[0], paramColor2.handle[1], paramColor2.handle[2], paramInt2 / 255.0F);
      this.gradient = ((NSGradient)new NSGradient().alloc()).initWithStartingColor(localNSColor1, localNSColor2);
      init();
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  void destroy()
  {
    if (this.color != null) {
      this.color.release();
    }
    this.color = null;
    if (this.gradient != null) {
      this.gradient.release();
    }
    this.gradient = null;
    this.image = null;
    this.color1 = (this.color2 = null);
  }
  
  public boolean isDisposed()
  {
    return this.device == null;
  }
  
  public String toString()
  {
    if (isDisposed()) {
      return "Pattern {*DISPOSED*}";
    }
    return "Pattern {" + (this.color != null ? this.color.id : this.gradient.id) + "}";
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/graphics/Pattern.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */