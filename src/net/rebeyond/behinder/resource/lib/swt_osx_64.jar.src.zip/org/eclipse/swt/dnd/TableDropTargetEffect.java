package org.eclipse.swt.dnd;

import org.eclipse.swt.internal.cocoa.NSView;
import org.eclipse.swt.internal.cocoa.OS;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Table;

public class TableDropTargetEffect
  extends DropTargetEffect
{
  boolean shouldEnableScrolling;
  
  public TableDropTargetEffect(Table paramTable)
  {
    super(paramTable);
  }
  
  int checkEffect(int paramInt)
  {
    if ((paramInt & 0x1) != 0) {
      paramInt = paramInt & 0xFFFFFFFB & 0xFFFFFFFD;
    }
    if ((paramInt & 0x2) != 0) {
      paramInt &= 0xFFFFFFFB;
    }
    return paramInt;
  }
  
  public void dragEnter(DropTargetEvent paramDropTargetEvent) {}
  
  public void dragLeave(DropTargetEvent paramDropTargetEvent)
  {
    if (this.shouldEnableScrolling)
    {
      this.shouldEnableScrolling = false;
      OS.objc_msgSend(this.control.view.id, OS.sel_setShouldScrollClipView_, 1);
      this.control.redraw();
    }
  }
  
  public void dragOver(DropTargetEvent paramDropTargetEvent)
  {
    int i = checkEffect(paramDropTargetEvent.feedback);
    ((DropTarget)paramDropTargetEvent.widget).feedback = i;
    if ((i & 0x8) == 0)
    {
      this.shouldEnableScrolling = true;
      OS.objc_msgSend(this.control.view.id, OS.sel_setShouldScrollClipView_, 0);
    }
    else
    {
      OS.objc_msgSend(this.control.view.id, OS.sel_setShouldScrollClipView_, 1);
    }
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/dnd/TableDropTargetEffect.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */