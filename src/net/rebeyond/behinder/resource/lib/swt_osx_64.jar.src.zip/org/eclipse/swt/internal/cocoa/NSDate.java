package org.eclipse.swt.internal.cocoa;

public class NSDate
  extends NSObject
{
  public NSDate() {}
  
  public NSDate(long paramLong)
  {
    super(paramLong);
  }
  
  public NSDate(id paramid)
  {
    super(paramid);
  }
  
  public NSCalendarDate dateWithCalendarFormat(NSString paramNSString, NSTimeZone paramNSTimeZone)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_dateWithCalendarFormat_timeZone_, paramNSString != null ? paramNSString.id : 0L, paramNSTimeZone != null ? paramNSTimeZone.id : 0L);
    return l != 0L ? new NSCalendarDate(l) : null;
  }
  
  public static NSDate dateWithTimeIntervalSinceNow(double paramDouble)
  {
    long l = OS.objc_msgSend(OS.class_NSDate, OS.sel_dateWithTimeIntervalSinceNow_, paramDouble);
    return l != 0L ? new NSDate(l) : null;
  }
  
  public static NSDate distantFuture()
  {
    long l = OS.objc_msgSend(OS.class_NSDate, OS.sel_distantFuture);
    return l != 0L ? new NSDate(l) : null;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSDate.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */