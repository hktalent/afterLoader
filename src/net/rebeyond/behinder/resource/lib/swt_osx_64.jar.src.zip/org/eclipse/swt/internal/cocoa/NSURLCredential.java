package org.eclipse.swt.internal.cocoa;

public class NSURLCredential
  extends NSObject
{
  public NSURLCredential() {}
  
  public NSURLCredential(long paramLong)
  {
    super(paramLong);
  }
  
  public NSURLCredential(id paramid)
  {
    super(paramid);
  }
  
  public static NSURLCredential credentialWithUser(NSString paramNSString1, NSString paramNSString2, long paramLong)
  {
    long l = OS.objc_msgSend(OS.class_NSURLCredential, OS.sel_credentialWithUser_password_persistence_, paramNSString1 != null ? paramNSString1.id : 0L, paramNSString2 != null ? paramNSString2.id : 0L, paramLong);
    return l != 0L ? new NSURLCredential(l) : null;
  }
  
  public boolean hasPassword()
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_hasPassword);
  }
  
  public NSString password()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_password);
    return l != 0L ? new NSString(l) : null;
  }
  
  public NSString user()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_user);
    return l != 0L ? new NSString(l) : null;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSURLCredential.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */