package org.eclipse.swt.internal.cocoa;

public class DOMUIEvent
  extends DOMEvent
{
  public DOMUIEvent() {}
  
  public DOMUIEvent(long paramLong)
  {
    super(paramLong);
  }
  
  public DOMUIEvent(id paramid)
  {
    super(paramid);
  }
  
  public int detail()
  {
    return (int)OS.objc_msgSend(this.id, OS.sel_detail);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/DOMUIEvent.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */