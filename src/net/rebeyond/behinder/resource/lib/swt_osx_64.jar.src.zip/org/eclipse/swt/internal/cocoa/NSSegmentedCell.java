package org.eclipse.swt.internal.cocoa;

public class NSSegmentedCell
  extends NSActionCell
{
  public NSSegmentedCell() {}
  
  public NSSegmentedCell(long paramLong)
  {
    super(paramLong);
  }
  
  public NSSegmentedCell(id paramid)
  {
    super(paramid);
  }
  
  public void setEnabled(boolean paramBoolean, long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_setEnabled_forSegment_, paramBoolean, paramLong);
  }
  
  public void setImage(NSImage paramNSImage, long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_setImage_forSegment_, paramNSImage != null ? paramNSImage.id : 0L, paramLong);
  }
  
  public void setLabel(NSString paramNSString, long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_setLabel_forSegment_, paramNSString != null ? paramNSString.id : 0L, paramLong);
  }
  
  public void setMenu(NSMenu paramNSMenu, long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_setMenu_forSegment_, paramNSMenu != null ? paramNSMenu.id : 0L, paramLong);
  }
  
  public void setSegmentCount(long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_setSegmentCount_, paramLong);
  }
  
  public void setSegmentStyle(long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_setSegmentStyle_, paramLong);
  }
  
  public void setSelected(boolean paramBoolean, long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_setSelected_forSegment_, paramBoolean, paramLong);
  }
  
  public void setSelectedSegment(long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_setSelectedSegment_, paramLong);
  }
  
  public void setTag(long paramLong1, long paramLong2)
  {
    OS.objc_msgSend(this.id, OS.sel_setTag_forSegment_, paramLong1, paramLong2);
  }
  
  public void setToolTip(NSString paramNSString, long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_setToolTip_forSegment_, paramNSString != null ? paramNSString.id : 0L, paramLong);
  }
  
  public void setTrackingMode(long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_setTrackingMode_, paramLong);
  }
  
  public void setWidth(double paramDouble, long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_setWidth_forSegment_, paramDouble, paramLong);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSSegmentedCell.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */