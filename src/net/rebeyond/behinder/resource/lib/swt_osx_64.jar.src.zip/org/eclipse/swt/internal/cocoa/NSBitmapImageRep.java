package org.eclipse.swt.internal.cocoa;

public class NSBitmapImageRep
  extends NSImageRep
{
  public NSBitmapImageRep() {}
  
  public NSBitmapImageRep(long paramLong)
  {
    super(paramLong);
  }
  
  public NSBitmapImageRep(id paramid)
  {
    super(paramid);
  }
  
  public NSData TIFFRepresentation()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_TIFFRepresentation);
    return l != 0L ? new NSData(l) : null;
  }
  
  public long bitmapData()
  {
    return OS.objc_msgSend(this.id, OS.sel_bitmapData);
  }
  
  public long bitmapFormat()
  {
    return OS.objc_msgSend(this.id, OS.sel_bitmapFormat);
  }
  
  public long bitsPerPixel()
  {
    return OS.objc_msgSend(this.id, OS.sel_bitsPerPixel);
  }
  
  public long bytesPerPlane()
  {
    return OS.objc_msgSend(this.id, OS.sel_bytesPerPlane);
  }
  
  public long bytesPerRow()
  {
    return OS.objc_msgSend(this.id, OS.sel_bytesPerRow);
  }
  
  public NSColor colorAtX(long paramLong1, long paramLong2)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_colorAtX_y_, paramLong1, paramLong2);
    return l != 0L ? new NSColor(l) : null;
  }
  
  public void getBitmapDataPlanes(long[] paramArrayOfLong)
  {
    OS.objc_msgSend(this.id, OS.sel_getBitmapDataPlanes_, paramArrayOfLong);
  }
  
  public static id imageRepWithData(NSData paramNSData)
  {
    long l = OS.objc_msgSend(OS.class_NSBitmapImageRep, OS.sel_imageRepWithData_, paramNSData != null ? paramNSData.id : 0L);
    return l != 0L ? new id(l) : null;
  }
  
  public NSBitmapImageRep initWithBitmapDataPlanes(long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5, boolean paramBoolean1, boolean paramBoolean2, NSString paramNSString, long paramLong6, long paramLong7, long paramLong8)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_initWithBitmapDataPlanes_pixelsWide_pixelsHigh_bitsPerSample_samplesPerPixel_hasAlpha_isPlanar_colorSpaceName_bitmapFormat_bytesPerRow_bitsPerPixel_, paramLong1, paramLong2, paramLong3, paramLong4, paramLong5, paramBoolean1, paramBoolean2, paramNSString != null ? paramNSString.id : 0L, paramLong6, paramLong7, paramLong8);
    return l != 0L ? new NSBitmapImageRep(l) : l == this.id ? this : null;
  }
  
  public NSBitmapImageRep initWithBitmapDataPlanes(long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5, boolean paramBoolean1, boolean paramBoolean2, NSString paramNSString, long paramLong6, long paramLong7)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_initWithBitmapDataPlanes_pixelsWide_pixelsHigh_bitsPerSample_samplesPerPixel_hasAlpha_isPlanar_colorSpaceName_bytesPerRow_bitsPerPixel_, paramLong1, paramLong2, paramLong3, paramLong4, paramLong5, paramBoolean1, paramBoolean2, paramNSString != null ? paramNSString.id : 0L, paramLong6, paramLong7);
    return l != 0L ? new NSBitmapImageRep(l) : l == this.id ? this : null;
  }
  
  public NSBitmapImageRep initWithData(NSData paramNSData)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_initWithData_, paramNSData != null ? paramNSData.id : 0L);
    return l != 0L ? new NSBitmapImageRep(l) : l == this.id ? this : null;
  }
  
  public NSBitmapImageRep initWithFocusedViewRect(NSRect paramNSRect)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_initWithFocusedViewRect_, paramNSRect);
    return l != 0L ? new NSBitmapImageRep(l) : l == this.id ? this : null;
  }
  
  public boolean isPlanar()
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_isPlanar);
  }
  
  public long numberOfPlanes()
  {
    return OS.objc_msgSend(this.id, OS.sel_numberOfPlanes);
  }
  
  public long samplesPerPixel()
  {
    return OS.objc_msgSend(this.id, OS.sel_samplesPerPixel);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSBitmapImageRep.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */