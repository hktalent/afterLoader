package org.eclipse.swt.graphics;

public final class FontMetrics
{
  int ascent;
  int descent;
  int averageCharWidth;
  int leading;
  int height;
  
  public static FontMetrics cocoa_new(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
  {
    FontMetrics localFontMetrics = new FontMetrics();
    localFontMetrics.ascent = paramInt1;
    localFontMetrics.descent = paramInt2;
    localFontMetrics.averageCharWidth = paramInt3;
    localFontMetrics.leading = paramInt4;
    localFontMetrics.height = paramInt5;
    return localFontMetrics;
  }
  
  public boolean equals(Object paramObject)
  {
    if (paramObject == this) {
      return true;
    }
    if (!(paramObject instanceof FontMetrics)) {
      return false;
    }
    FontMetrics localFontMetrics = (FontMetrics)paramObject;
    return (this.ascent == localFontMetrics.ascent) && (this.descent == localFontMetrics.descent) && (this.averageCharWidth == localFontMetrics.averageCharWidth) && (this.leading == localFontMetrics.leading) && (this.height == localFontMetrics.height);
  }
  
  public int getAscent()
  {
    return this.ascent;
  }
  
  public int getAverageCharWidth()
  {
    return this.averageCharWidth;
  }
  
  public int getDescent()
  {
    return this.descent;
  }
  
  public int getHeight()
  {
    return this.height;
  }
  
  public int getLeading()
  {
    return this.leading;
  }
  
  public int hashCode()
  {
    return this.ascent ^ this.descent ^ this.averageCharWidth ^ this.leading ^ this.height;
  }
  
  String getName()
  {
    String str = getClass().getName();
    int i = str.lastIndexOf('.');
    if (i == -1) {
      return str;
    }
    return str.substring(i + 1, str.length());
  }
  
  public String toString()
  {
    return getName() + "{" + " ascent=" + this.ascent + " descent=" + this.descent + " averageCharWidth=" + this.averageCharWidth + " leading=" + this.leading + " height=" + this.height + "}";
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/graphics/FontMetrics.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */