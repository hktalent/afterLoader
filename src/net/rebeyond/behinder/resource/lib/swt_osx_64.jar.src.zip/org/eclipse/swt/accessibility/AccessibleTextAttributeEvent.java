package org.eclipse.swt.accessibility;

import org.eclipse.swt.graphics.TextStyle;
import org.eclipse.swt.internal.SWTEventObject;

public class AccessibleTextAttributeEvent
  extends SWTEventObject
{
  public int offset;
  public int start;
  public int end;
  public TextStyle textStyle;
  public String[] attributes;
  public String result;
  static final long serialVersionUID = 7131825608864332802L;
  
  public AccessibleTextAttributeEvent(Object paramObject)
  {
    super(paramObject);
  }
  
  public String toString()
  {
    return "AccessibleAttributeEvent { offset=" + this.offset + " start=" + this.start + " end=" + this.end + " textStyle=" + this.textStyle + " attributes=" + toAttributeString(this.attributes) + " result=" + this.result + "}";
  }
  
  String toAttributeString(String[] paramArrayOfString)
  {
    if ((paramArrayOfString == null) || (paramArrayOfString.length == 0)) {
      return "" + paramArrayOfString;
    }
    StringBuffer localStringBuffer = new StringBuffer();
    for (int i = 0; i < paramArrayOfString.length; i++)
    {
      localStringBuffer.append(paramArrayOfString[i]);
      localStringBuffer.append(i % 2 == 0 ? ":" : ";");
    }
    return localStringBuffer.toString();
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/accessibility/AccessibleTextAttributeEvent.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */