package org.eclipse.swt.internal.cocoa;

public class NSFont
  extends NSObject
{
  public NSFont() {}
  
  public NSFont(long paramLong)
  {
    super(paramLong);
  }
  
  public NSFont(id paramid)
  {
    super(paramid);
  }
  
  public double ascender()
  {
    return OS.objc_msgSend_fpret(this.id, OS.sel_ascender);
  }
  
  public static NSFont controlContentFontOfSize(double paramDouble)
  {
    long l = OS.objc_msgSend(OS.class_NSFont, OS.sel_controlContentFontOfSize_, paramDouble);
    return l != 0L ? new NSFont(l) : null;
  }
  
  public double descender()
  {
    return OS.objc_msgSend_fpret(this.id, OS.sel_descender);
  }
  
  public NSString displayName()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_displayName);
    return l != 0L ? new NSString(l) : null;
  }
  
  public NSString familyName()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_familyName);
    return l != 0L ? new NSString(l) : null;
  }
  
  public NSString fontName()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_fontName);
    return l != 0L ? new NSString(l) : null;
  }
  
  public static NSFont fontWithName(NSString paramNSString, double paramDouble)
  {
    long l = OS.objc_msgSend(OS.class_NSFont, OS.sel_fontWithName_size_, paramNSString != null ? paramNSString.id : 0L, paramDouble);
    return l != 0L ? new NSFont(l) : null;
  }
  
  public double leading()
  {
    return OS.objc_msgSend_fpret(this.id, OS.sel_leading);
  }
  
  public static NSFont menuBarFontOfSize(double paramDouble)
  {
    long l = OS.objc_msgSend(OS.class_NSFont, OS.sel_menuBarFontOfSize_, paramDouble);
    return l != 0L ? new NSFont(l) : null;
  }
  
  public static NSFont menuFontOfSize(double paramDouble)
  {
    long l = OS.objc_msgSend(OS.class_NSFont, OS.sel_menuFontOfSize_, paramDouble);
    return l != 0L ? new NSFont(l) : null;
  }
  
  public double pointSize()
  {
    return OS.objc_msgSend_fpret(this.id, OS.sel_pointSize);
  }
  
  public static double smallSystemFontSize()
  {
    return OS.objc_msgSend_fpret(OS.class_NSFont, OS.sel_smallSystemFontSize);
  }
  
  public static NSFont systemFontOfSize(double paramDouble)
  {
    long l = OS.objc_msgSend(OS.class_NSFont, OS.sel_systemFontOfSize_, paramDouble);
    return l != 0L ? new NSFont(l) : null;
  }
  
  public static double systemFontSize()
  {
    return OS.objc_msgSend_fpret(OS.class_NSFont, OS.sel_systemFontSize);
  }
  
  public static double systemFontSizeForControlSize(long paramLong)
  {
    return OS.objc_msgSend_fpret(OS.class_NSFont, OS.sel_systemFontSizeForControlSize_, paramLong);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSFont.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */