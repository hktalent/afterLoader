package org.eclipse.swt.internal.cocoa;

public class NSAssertionHandler
  extends NSObject
{
  public NSAssertionHandler() {}
  
  public NSAssertionHandler(long paramLong)
  {
    super(paramLong);
  }
  
  public NSAssertionHandler(id paramid)
  {
    super(paramid);
  }
  
  public static NSAssertionHandler currentHandler()
  {
    long l = OS.objc_msgSend(OS.class_NSAssertionHandler, OS.sel_currentHandler);
    return l != 0L ? new NSAssertionHandler(l) : null;
  }
  
  public void handleFailureInFunction(NSString paramNSString1, NSString paramNSString2, long paramLong, NSString paramNSString3)
  {
    OS.objc_msgSend(this.id, OS.sel_handleFailureInFunction_file_lineNumber_description_, paramNSString1 != null ? paramNSString1.id : 0L, paramNSString2 != null ? paramNSString2.id : 0L, paramLong, paramNSString3 != null ? paramNSString3.id : 0L);
  }
  
  public void handleFailureInMethod(long paramLong1, id paramid, NSString paramNSString1, long paramLong2, NSString paramNSString2)
  {
    OS.objc_msgSend(this.id, OS.sel_handleFailureInMethod_object_file_lineNumber_description_, paramLong1, paramid != null ? paramid.id : 0L, paramNSString1 != null ? paramNSString1.id : 0L, paramLong2, paramNSString2 != null ? paramNSString2.id : 0L);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSAssertionHandler.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */