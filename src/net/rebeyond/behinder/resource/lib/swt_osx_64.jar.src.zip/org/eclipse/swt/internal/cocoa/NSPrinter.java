package org.eclipse.swt.internal.cocoa;

public class NSPrinter
  extends NSObject
{
  public NSPrinter() {}
  
  public NSPrinter(long paramLong)
  {
    super(paramLong);
  }
  
  public NSPrinter(id paramid)
  {
    super(paramid);
  }
  
  public NSString name()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_name);
    return l != 0L ? new NSString(l) : null;
  }
  
  public static NSArray printerNames()
  {
    long l = OS.objc_msgSend(OS.class_NSPrinter, OS.sel_printerNames);
    return l != 0L ? new NSArray(l) : null;
  }
  
  public static NSPrinter printerWithName(NSString paramNSString)
  {
    long l = OS.objc_msgSend(OS.class_NSPrinter, OS.sel_printerWithName_, paramNSString != null ? paramNSString.id : 0L);
    return l != 0L ? new NSPrinter(l) : null;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSPrinter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */