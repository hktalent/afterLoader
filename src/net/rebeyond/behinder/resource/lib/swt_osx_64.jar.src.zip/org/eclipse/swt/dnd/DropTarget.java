package org.eclipse.swt.dnd;

import java.util.ArrayList;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.internal.Callback;
import org.eclipse.swt.internal.cocoa.NSApplication;
import org.eclipse.swt.internal.cocoa.NSArray;
import org.eclipse.swt.internal.cocoa.NSCursor;
import org.eclipse.swt.internal.cocoa.NSEvent;
import org.eclipse.swt.internal.cocoa.NSMutableArray;
import org.eclipse.swt.internal.cocoa.NSObject;
import org.eclipse.swt.internal.cocoa.NSOutlineView;
import org.eclipse.swt.internal.cocoa.NSPasteboard;
import org.eclipse.swt.internal.cocoa.NSPoint;
import org.eclipse.swt.internal.cocoa.NSRect;
import org.eclipse.swt.internal.cocoa.NSScreen;
import org.eclipse.swt.internal.cocoa.NSString;
import org.eclipse.swt.internal.cocoa.NSTableView;
import org.eclipse.swt.internal.cocoa.NSURL;
import org.eclipse.swt.internal.cocoa.NSView;
import org.eclipse.swt.internal.cocoa.NSWindow;
import org.eclipse.swt.internal.cocoa.OS;
import org.eclipse.swt.internal.cocoa.SWTTreeItem;
import org.eclipse.swt.internal.cocoa.id;
import org.eclipse.swt.internal.cocoa.objc_super;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.Tree;
import org.eclipse.swt.widgets.TreeItem;
import org.eclipse.swt.widgets.Widget;

public class DropTarget
  extends Widget
{
  static Callback dropTarget2Args;
  static Callback dropTarget3Args;
  static Callback dropTarget6Args;
  static long proc2Args;
  static long proc3Args;
  static long proc6Args;
  static final String LOCK_CURSOR = "org.eclipse.swt.internal.lockCursor";
  static boolean dropNotAllowed = false;
  Control control;
  Listener controlListener;
  Transfer[] transferAgents = new Transfer[0];
  DropTargetEffect dropEffect;
  int feedback = 0;
  TransferData selectedDataType;
  int selectedOperation;
  int keyOperation = -1;
  static final String DEFAULT_DROP_TARGET_EFFECT = "DEFAULT_DROP_TARGET_EFFECT";
  static final String IS_ACTIVE = "org.eclipse.swt.internal.isActive";
  
  void addDragHandlers()
  {
    long l1 = OS.object_getClass(this.control.view.id);
    if (l1 == 0L) {
      DND.error(2001);
    }
    long l2 = OS.class_getMethodImplementation(l1, OS.sel_draggingEntered_);
    if (l2 == proc3Args) {
      return;
    }
    addDragHandlers(l1);
    long l3 = 0L;
    if ((l3 = OS.objc_msgSend(this.control.view.id, OS.sel_getImageView)) != 0L)
    {
      l1 = OS.object_getClass(l3);
      addDragHandlers(l1);
    }
  }
  
  void addDragHandlers(long paramLong)
  {
    OS.class_addMethod(paramLong, OS.sel_draggingEntered_, proc3Args, "@:@");
    OS.class_addMethod(paramLong, OS.sel_draggingUpdated_, proc3Args, "@:@");
    OS.class_addMethod(paramLong, OS.sel_draggingExited_, proc3Args, "@:@");
    OS.class_addMethod(paramLong, OS.sel_performDragOperation_, proc3Args, "@:@");
    OS.class_addMethod(paramLong, OS.sel_wantsPeriodicDraggingUpdates, proc2Args, "@:");
    if (OS.class_getSuperclass(paramLong) == OS.class_NSOutlineView)
    {
      OS.class_addMethod(paramLong, OS.sel_outlineView_acceptDrop_item_childIndex_, proc6Args, "@:@@@i");
      OS.class_addMethod(paramLong, OS.sel_outlineView_validateDrop_proposedItem_proposedChildIndex_, proc6Args, "@:@@@i");
    }
    else if (OS.class_getSuperclass(paramLong) == OS.class_NSTableView)
    {
      OS.class_addMethod(paramLong, OS.sel_tableView_acceptDrop_row_dropOperation_, proc6Args, "@:@@@i");
      OS.class_addMethod(paramLong, OS.sel_tableView_validateDrop_proposedRow_proposedDropOperation_, proc6Args, "@:@@@i");
    }
  }
  
  public void addDropListener(DropTargetListener paramDropTargetListener)
  {
    if (paramDropTargetListener == null) {
      DND.error(4);
    }
    DNDListener localDNDListener = new DNDListener(paramDropTargetListener);
    localDNDListener.dndWidget = this;
    addListener(2002, localDNDListener);
    addListener(2003, localDNDListener);
    addListener(2004, localDNDListener);
    addListener(2005, localDNDListener);
    addListener(2006, localDNDListener);
    addListener(2007, localDNDListener);
  }
  
  long dndCallSuper(long paramLong1, long paramLong2, long paramLong3)
  {
    objc_super localobjc_super = new objc_super();
    localobjc_super.receiver = paramLong1;
    localobjc_super.super_class = OS.objc_msgSend(paramLong1, OS.sel_superclass);
    return OS.objc_msgSendSuper(localobjc_super, paramLong2, paramLong3);
  }
  
  static int checkStyle(int paramInt)
  {
    if (paramInt == 0) {
      return 2;
    }
    return paramInt;
  }
  
  protected void checkSubclass()
  {
    String str1 = getClass().getName();
    String str2 = DropTarget.class.getName();
    if (!str2.equals(str1)) {
      DND.error(43);
    }
  }
  
  int draggingEntered(long paramLong1, long paramLong2, NSObject paramNSObject)
  {
    if (paramNSObject == null) {
      return 0;
    }
    DNDEvent localDNDEvent = new DNDEvent();
    if (!setEventData(paramNSObject, localDNDEvent))
    {
      this.keyOperation = -1;
      setDropNotAllowed();
      return 0;
    }
    int i = localDNDEvent.operations;
    TransferData[] arrayOfTransferData = new TransferData[localDNDEvent.dataTypes.length];
    System.arraycopy(localDNDEvent.dataTypes, 0, arrayOfTransferData, 0, arrayOfTransferData.length);
    this.selectedDataType = null;
    this.selectedOperation = 0;
    notifyListeners(2002, localDNDEvent);
    if (localDNDEvent.detail == 16) {
      localDNDEvent.detail = ((i & 0x2) != 0 ? 2 : 0);
    }
    if (localDNDEvent.dataType != null) {
      for (int j = 0; j < arrayOfTransferData.length; j++) {
        if (arrayOfTransferData[j].type == localDNDEvent.dataType.type)
        {
          this.selectedDataType = arrayOfTransferData[j];
          break;
        }
      }
    }
    if ((this.selectedDataType != null) && ((i & localDNDEvent.detail) != 0)) {
      this.selectedOperation = localDNDEvent.detail;
    }
    if (this.selectedOperation == 0) {
      setDropNotAllowed();
    } else if (!((Boolean)this.control.getData("org.eclipse.swt.internal.isActive")).booleanValue()) {
      setDropNotAllowed();
    } else {
      clearDropNotAllowed();
    }
    if (new NSObject(paramLong1).isKindOfClass(OS.class_NSTableView)) {
      return (int)dndCallSuper(paramLong1, paramLong2, paramNSObject.id);
    }
    return opToOsOp(this.selectedOperation);
  }
  
  void draggingExited(long paramLong1, long paramLong2, NSObject paramNSObject)
  {
    clearDropNotAllowed();
    if (this.keyOperation == -1) {
      return;
    }
    this.keyOperation = -1;
    DNDEvent localDNDEvent = new DNDEvent();
    localDNDEvent.widget = this;
    localDNDEvent.time = ((int)System.currentTimeMillis());
    localDNDEvent.detail = 0;
    notifyListeners(2003, localDNDEvent);
    if (new NSObject(paramLong1).isKindOfClass(OS.class_NSTableView)) {
      dndCallSuper(paramLong1, paramLong2, paramNSObject.id);
    }
  }
  
  int draggingUpdated(long paramLong1, long paramLong2, NSObject paramNSObject)
  {
    if (paramNSObject == null) {
      return 0;
    }
    int i = this.keyOperation;
    DNDEvent localDNDEvent = new DNDEvent();
    if (!setEventData(paramNSObject, localDNDEvent))
    {
      this.keyOperation = -1;
      setDropNotAllowed();
      return 0;
    }
    int j = localDNDEvent.operations;
    TransferData[] arrayOfTransferData = new TransferData[localDNDEvent.dataTypes.length];
    System.arraycopy(localDNDEvent.dataTypes, 0, arrayOfTransferData, 0, arrayOfTransferData.length);
    if (this.keyOperation == i)
    {
      localDNDEvent.type = 2004;
      localDNDEvent.dataType = this.selectedDataType;
      localDNDEvent.detail = this.selectedOperation;
    }
    else
    {
      localDNDEvent.type = 2005;
      localDNDEvent.dataType = this.selectedDataType;
    }
    this.selectedDataType = null;
    this.selectedOperation = 0;
    notifyListeners(localDNDEvent.type, localDNDEvent);
    if (localDNDEvent.detail == 16) {
      localDNDEvent.detail = ((j & 0x2) != 0 ? 2 : 0);
    }
    if (localDNDEvent.dataType != null) {
      for (int k = 0; k < arrayOfTransferData.length; k++) {
        if (arrayOfTransferData[k].type == localDNDEvent.dataType.type)
        {
          this.selectedDataType = arrayOfTransferData[k];
          break;
        }
      }
    }
    if ((this.selectedDataType != null) && ((localDNDEvent.detail & j) != 0)) {
      this.selectedOperation = localDNDEvent.detail;
    }
    if (this.selectedOperation == 0) {
      setDropNotAllowed();
    } else if (!((Boolean)this.control.getData("org.eclipse.swt.internal.isActive")).booleanValue()) {
      setDropNotAllowed();
    } else {
      clearDropNotAllowed();
    }
    if (new NSObject(paramLong1).isKindOfClass(OS.class_NSTableView)) {
      return (int)dndCallSuper(paramLong1, paramLong2, paramNSObject.id);
    }
    return opToOsOp(this.selectedOperation);
  }
  
  public DropTarget(Control paramControl, int paramInt)
  {
    super(paramControl, checkStyle(paramInt));
    this.control = paramControl;
    if (paramControl.getData("DropTarget") != null) {
      DND.error(2001);
    }
    paramControl.setData("DropTarget", this);
    this.controlListener = new Listener()
    {
      public void handleEvent(Event paramAnonymousEvent)
      {
        if (!DropTarget.this.isDisposed()) {
          DropTarget.this.dispose();
        }
      }
    };
    paramControl.addListener(12, this.controlListener);
    addListener(12, new Listener()
    {
      public void handleEvent(Event paramAnonymousEvent)
      {
        DropTarget.this.onDispose();
      }
    });
    Object localObject = paramControl.getData("DEFAULT_DROP_TARGET_EFFECT");
    if ((localObject instanceof DropTargetEffect)) {
      this.dropEffect = ((DropTargetEffect)localObject);
    } else if ((paramControl instanceof Table)) {
      this.dropEffect = new TableDropTargetEffect((Table)paramControl);
    } else if ((paramControl instanceof Tree)) {
      this.dropEffect = new TreeDropTargetEffect((Tree)paramControl);
    }
    addDragHandlers();
  }
  
  static long dropTargetProc(long paramLong1, long paramLong2)
  {
    Display localDisplay = Display.findDisplay(Thread.currentThread());
    if ((localDisplay == null) || (localDisplay.isDisposed())) {
      return 0L;
    }
    Widget localWidget = localDisplay.findWidget(paramLong1);
    if (localWidget == null) {
      return 0L;
    }
    DropTarget localDropTarget = (DropTarget)localWidget.getData("DropTarget");
    if (localDropTarget == null) {
      return 0L;
    }
    if (paramLong2 == OS.sel_wantsPeriodicDraggingUpdates) {
      return localDropTarget.wantsPeriodicDraggingUpdates(paramLong1, paramLong2) ? 1L : 0L;
    }
    return 0L;
  }
  
  static long dropTargetProc(long paramLong1, long paramLong2, long paramLong3)
  {
    Display localDisplay = Display.findDisplay(Thread.currentThread());
    if ((localDisplay == null) || (localDisplay.isDisposed())) {
      return 0L;
    }
    Widget localWidget = localDisplay.findWidget(paramLong1);
    if (localWidget == null) {
      return 0L;
    }
    DropTarget localDropTarget = (DropTarget)localWidget.getData("DropTarget");
    if (localDropTarget == null) {
      return 0L;
    }
    NSObject localNSObject = new NSObject(paramLong3);
    if (paramLong2 == OS.sel_draggingEntered_) {
      return localDropTarget.draggingEntered(paramLong1, paramLong2, localNSObject);
    }
    if (paramLong2 == OS.sel_draggingUpdated_) {
      return localDropTarget.draggingUpdated(paramLong1, paramLong2, localNSObject);
    }
    if (paramLong2 == OS.sel_draggingExited_) {
      localDropTarget.draggingExited(paramLong1, paramLong2, localNSObject);
    } else if (paramLong2 == OS.sel_performDragOperation_) {
      return localDropTarget.performDragOperation(paramLong1, paramLong2, localNSObject) ? 1L : 0L;
    }
    return 0L;
  }
  
  static long dropTargetProc(long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5, long paramLong6)
  {
    Display localDisplay = Display.findDisplay(Thread.currentThread());
    if ((localDisplay == null) || (localDisplay.isDisposed())) {
      return 0L;
    }
    Widget localWidget = localDisplay.findWidget(paramLong1);
    if (localWidget == null) {
      return 0L;
    }
    DropTarget localDropTarget = (DropTarget)localWidget.getData("DropTarget");
    if (localDropTarget == null) {
      return 0L;
    }
    if (paramLong2 == OS.sel_outlineView_acceptDrop_item_childIndex_) {
      return localDropTarget.outlineView_acceptDrop_item_childIndex(paramLong1, paramLong2, paramLong3, paramLong4, paramLong5, paramLong6) ? 1L : 0L;
    }
    if (paramLong2 == OS.sel_outlineView_validateDrop_proposedItem_proposedChildIndex_) {
      return localDropTarget.outlineView_validateDrop_proposedItem_proposedChildIndex(paramLong1, paramLong2, paramLong3, paramLong4, paramLong5, paramLong6);
    }
    if (paramLong2 == OS.sel_tableView_acceptDrop_row_dropOperation_) {
      return localDropTarget.tableView_acceptDrop_row_dropOperation(paramLong1, paramLong2, paramLong3, paramLong4, paramLong5, paramLong6) ? 1L : 0L;
    }
    if (paramLong2 == OS.sel_tableView_validateDrop_proposedRow_proposedDropOperation_) {
      return localDropTarget.tableView_validateDrop_proposedRow_proposedDropOperation(paramLong1, paramLong2, paramLong3, paramLong4, paramLong5, paramLong6);
    }
    return 0L;
  }
  
  public Control getControl()
  {
    return this.control;
  }
  
  public DropTargetListener[] getDropListeners()
  {
    Listener[] arrayOfListener = getListeners(2002);
    int i = arrayOfListener.length;
    DropTargetListener[] arrayOfDropTargetListener1 = new DropTargetListener[i];
    int j = 0;
    for (int k = 0; k < i; k++)
    {
      Listener localListener = arrayOfListener[k];
      if ((localListener instanceof DNDListener))
      {
        arrayOfDropTargetListener1[j] = ((DropTargetListener)((DNDListener)localListener).getEventListener());
        j++;
      }
    }
    if (j == i) {
      return arrayOfDropTargetListener1;
    }
    DropTargetListener[] arrayOfDropTargetListener2 = new DropTargetListener[j];
    System.arraycopy(arrayOfDropTargetListener1, 0, arrayOfDropTargetListener2, 0, j);
    return arrayOfDropTargetListener2;
  }
  
  public DropTargetEffect getDropTargetEffect()
  {
    return this.dropEffect;
  }
  
  int getOperationFromKeyState()
  {
    NSEvent localNSEvent = NSApplication.sharedApplication().currentEvent();
    long l = localNSEvent.modifierFlags();
    int i = (l & 0x80000) == 524288L ? 1 : 0;
    int j = (l & 0x40000) == 262144L ? 1 : 0;
    if ((j != 0) && (i != 0)) {
      return 16;
    }
    if (j != 0) {
      return 4;
    }
    if (i != 0) {
      return 1;
    }
    return 16;
  }
  
  public Transfer[] getTransfer()
  {
    return this.transferAgents;
  }
  
  void onDispose()
  {
    if (this.control == null) {
      return;
    }
    if (this.controlListener != null) {
      this.control.removeListener(12, this.controlListener);
    }
    this.controlListener = null;
    this.control.setData("DropTarget", null);
    this.transferAgents = null;
    this.control.view.unregisterDraggedTypes();
    this.control = null;
  }
  
  int opToOsOp(int paramInt)
  {
    int i = 0;
    if ((paramInt & 0x1) != 0) {
      i |= 0x1;
    }
    if ((paramInt & 0x4) != 0) {
      i |= 0x2;
    }
    if ((paramInt & 0x2) != 0) {
      i |= 0x10;
    }
    if ((paramInt & 0x8) != 0) {
      i |= 0x20;
    }
    return i;
  }
  
  int osOpToOp(long paramLong)
  {
    int i = 0;
    if ((paramLong & 1L) != 0L) {
      i |= 0x1;
    }
    if ((paramLong & 0x2) != 0L) {
      i |= 0x4;
    }
    if ((paramLong & 0x20) != 0L) {
      i |= 0x8;
    }
    if ((paramLong & 0x10) != 0L) {
      i |= 0x2;
    }
    if (paramLong == -1L) {
      i = 7;
    }
    return i;
  }
  
  boolean drop(NSObject paramNSObject)
  {
    clearDropNotAllowed();
    DNDEvent localDNDEvent = new DNDEvent();
    localDNDEvent.widget = this;
    localDNDEvent.time = ((int)System.currentTimeMillis());
    if (this.dropEffect != null)
    {
      NSPoint localNSPoint = paramNSObject.draggingLocation();
      localObject1 = paramNSObject.draggingDestinationWindow().convertBaseToScreen(localNSPoint);
      localDNDEvent.item = this.dropEffect.getItem((int)((NSPoint)localObject1).x, (int)((NSPoint)localObject1).y);
    }
    localDNDEvent.detail = 0;
    notifyListeners(2003, localDNDEvent);
    localDNDEvent = new DNDEvent();
    if ((!setEventData(paramNSObject, localDNDEvent)) || (!((Boolean)this.control.getData("org.eclipse.swt.internal.isActive")).booleanValue())) {
      return false;
    }
    this.keyOperation = -1;
    int i = localDNDEvent.operations;
    Object localObject1 = new TransferData[localDNDEvent.dataTypes.length];
    System.arraycopy(localDNDEvent.dataTypes, 0, localObject1, 0, localDNDEvent.dataTypes.length);
    localDNDEvent.dataType = this.selectedDataType;
    localDNDEvent.detail = this.selectedOperation;
    notifyListeners(2007, localDNDEvent);
    this.selectedDataType = null;
    if (localDNDEvent.dataType != null) {
      for (int j = 0; j < localObject1.length; j++) {
        if (localObject1[j].type == localDNDEvent.dataType.type)
        {
          this.selectedDataType = localObject1[j];
          break;
        }
      }
    }
    this.selectedOperation = 0;
    if ((this.selectedDataType != null) && ((localDNDEvent.detail & i) != 0)) {
      this.selectedOperation = localDNDEvent.detail;
    }
    if (this.selectedOperation == 0) {
      return false;
    }
    NSPasteboard localNSPasteboard = paramNSObject.draggingPasteboard();
    NSObject localNSObject = null;
    NSMutableArray localNSMutableArray = NSMutableArray.arrayWithCapacity(10L);
    for (int k = 0; k < this.transferAgents.length; k++)
    {
      localObject2 = this.transferAgents[k];
      localObject3 = ((Transfer)localObject2).getTypeNames();
      int[] arrayOfInt = ((Transfer)localObject2).getTypeIds();
      for (int n = 0; n < localObject3.length; n++) {
        if (this.selectedDataType.type == arrayOfInt[n])
        {
          localNSMutableArray.addObject(NSString.stringWith(localObject3[n]));
          break;
        }
      }
    }
    NSString localNSString = localNSPasteboard.availableTypeFromArray(localNSMutableArray);
    Object localObject2 = new TransferData();
    if (localNSString != null)
    {
      ((TransferData)localObject2).type = Transfer.registerType(localNSString.getString());
      if ((localNSString.isEqual(OS.NSStringPboardType)) || (localNSString.isEqual(OS.NSHTMLPboardType)) || (localNSString.isEqual(OS.NSRTFPboardType))) {
        ((TransferData)localObject2).data = localNSPasteboard.stringForType(localNSString);
      } else if ((localNSString.isEqual(OS.NSURLPboardType)) || (localNSString.isEqual(OS.kUTTypeURL))) {
        ((TransferData)localObject2).data = NSURL.URLFromPasteboard(localNSPasteboard);
      } else if ((localNSString.isEqual(OS.NSFilenamesPboardType)) || (localNSString.isEqual(OS.kUTTypeFileURL))) {
        ((TransferData)localObject2).data = new NSArray(localNSPasteboard.propertyListForType(OS.NSFilenamesPboardType).id);
      } else {
        ((TransferData)localObject2).data = localNSPasteboard.dataForType(localNSString);
      }
    }
    if (((TransferData)localObject2).data != null) {
      localNSObject = ((TransferData)localObject2).data;
    }
    Object localObject3 = null;
    for (int m = 0; m < this.transferAgents.length; m++)
    {
      Transfer localTransfer = this.transferAgents[m];
      if ((localTransfer != null) && (localTransfer.isSupportedType(this.selectedDataType)))
      {
        this.selectedDataType.data = localNSObject;
        localObject3 = localTransfer.nativeToJava(this.selectedDataType);
        break;
      }
    }
    if (localObject3 == null) {
      this.selectedOperation = 0;
    }
    localDNDEvent.dataType = this.selectedDataType;
    localDNDEvent.detail = this.selectedOperation;
    localDNDEvent.data = localObject3;
    notifyListeners(2006, localDNDEvent);
    this.selectedOperation = 0;
    if ((i & localDNDEvent.detail) == localDNDEvent.detail) {
      this.selectedOperation = localDNDEvent.detail;
    }
    return this.selectedOperation != 0;
  }
  
  boolean performDragOperation(long paramLong1, long paramLong2, NSObject paramNSObject)
  {
    if (new NSObject(paramLong1).isKindOfClass(OS.class_NSTableView)) {
      return dndCallSuper(paramLong1, paramLong2, paramNSObject.id) != 0L;
    }
    return drop(paramNSObject);
  }
  
  boolean outlineView_acceptDrop_item_childIndex(long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5, long paramLong6)
  {
    return drop(new NSObject(paramLong4));
  }
  
  long outlineView_validateDrop_proposedItem_proposedChildIndex(long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5, long paramLong6)
  {
    NSOutlineView localNSOutlineView = new NSOutlineView(paramLong3);
    NSObject localNSObject = new NSObject(paramLong4);
    NSPoint localNSPoint = localNSObject.draggingLocation();
    localNSPoint = localNSOutlineView.convertPoint_fromView_(localNSPoint, null);
    Tree localTree = (Tree)getControl();
    TreeItem localTreeItem1 = localTree.getItem(new Point((int)localNSPoint.x, (int)localNSPoint.y));
    if ((this.feedback == 0) || (localTreeItem1 == null))
    {
      localNSOutlineView.setDropItem(null, -1L);
    }
    else if ((this.feedback & 0x1) != 0)
    {
      localNSOutlineView.setDropItem(localTreeItem1.handle, -1L);
    }
    else
    {
      TreeItem localTreeItem2 = localTreeItem1.getParentItem();
      SWTTreeItem localSWTTreeItem = null;
      int i;
      if (localTreeItem2 != null)
      {
        localSWTTreeItem = localTreeItem2.handle;
        i = localTreeItem2.indexOf(localTreeItem1);
      }
      else
      {
        i = ((Tree)getControl()).indexOf(localTreeItem1);
      }
      if ((this.feedback & 0x4) != 0) {
        localNSOutlineView.setDropItem(localSWTTreeItem, i + 1);
      }
      if ((this.feedback & 0x2) != 0) {
        localNSOutlineView.setDropItem(localSWTTreeItem, i);
      }
    }
    return opToOsOp(this.selectedOperation);
  }
  
  public void removeDropListener(DropTargetListener paramDropTargetListener)
  {
    if (paramDropTargetListener == null) {
      DND.error(4);
    }
    removeListener(2002, paramDropTargetListener);
    removeListener(2003, paramDropTargetListener);
    removeListener(2004, paramDropTargetListener);
    removeListener(2005, paramDropTargetListener);
    removeListener(2006, paramDropTargetListener);
    removeListener(2007, paramDropTargetListener);
  }
  
  public void setDropTargetEffect(DropTargetEffect paramDropTargetEffect)
  {
    this.dropEffect = paramDropTargetEffect;
  }
  
  boolean setEventData(NSObject paramNSObject, DNDEvent paramDNDEvent)
  {
    if (paramNSObject == null) {
      return false;
    }
    int i = getStyle();
    long l1 = paramNSObject.draggingSourceOperationMask();
    int j = osOpToOp(l1) & i;
    if (j == 0) {
      return false;
    }
    int k = getOperationFromKeyState();
    this.keyOperation = k;
    if (k == 16)
    {
      if ((i & 0x10) == 0) {
        k = (j & 0x2) != 0 ? 2 : 0;
      }
    }
    else if ((k & j) == 0) {
      k = 0;
    }
    NSPasteboard localNSPasteboard = paramNSObject.draggingPasteboard();
    NSArray localNSArray = localNSPasteboard.types();
    if (localNSArray == null) {
      return false;
    }
    long l2 = localNSArray.count();
    Object localObject1 = new TransferData[(int)l2];
    int m = -1;
    for (int n = 0; n < l2; n++)
    {
      localObject3 = localNSArray.objectAtIndex(n);
      localObject4 = new NSString((id)localObject3);
      localObject5 = new TransferData();
      ((TransferData)localObject5).type = Transfer.registerType(((NSString)localObject4).getString());
      for (int i1 = 0; i1 < this.transferAgents.length; i1++)
      {
        Transfer localTransfer = this.transferAgents[i1];
        if ((localTransfer != null) && (localTransfer.isSupportedType((TransferData)localObject5)))
        {
          localObject1[(++m)] = localObject5;
          break;
        }
      }
    }
    if (m == -1) {
      return false;
    }
    if (m < localObject1.length - 1)
    {
      localObject2 = new TransferData[m + 1];
      System.arraycopy(localObject1, 0, localObject2, 0, m + 1);
      localObject1 = localObject2;
    }
    Object localObject2 = paramNSObject.draggingLocation();
    Object localObject3 = paramNSObject.draggingDestinationWindow().convertBaseToScreen((NSPoint)localObject2);
    Object localObject4 = NSScreen.screens();
    Object localObject5 = new NSScreen(((NSArray)localObject4).objectAtIndex(0L)).frame();
    ((NSPoint)localObject3).y = (((NSRect)localObject5).height - ((NSPoint)localObject3).y);
    paramDNDEvent.widget = this;
    paramDNDEvent.x = ((int)((NSPoint)localObject3).x);
    paramDNDEvent.y = ((int)((NSPoint)localObject3).y);
    paramDNDEvent.time = ((int)System.currentTimeMillis());
    paramDNDEvent.feedback = 1;
    paramDNDEvent.dataTypes = ((TransferData[])localObject1);
    paramDNDEvent.dataType = localObject1[0];
    paramDNDEvent.operations = j;
    paramDNDEvent.detail = k;
    if (this.dropEffect != null) {
      paramDNDEvent.item = this.dropEffect.getItem(paramDNDEvent.x, paramDNDEvent.y);
    }
    return true;
  }
  
  public void setTransfer(Transfer[] paramArrayOfTransfer)
  {
    if (paramArrayOfTransfer == null) {
      DND.error(4);
    }
    this.transferAgents = paramArrayOfTransfer;
    ArrayList localArrayList = new ArrayList();
    for (int i = 0; i < this.transferAgents.length; i++)
    {
      localObject = paramArrayOfTransfer[i].getTypeNames();
      for (j = 0; j < localObject.length; j++) {
        localArrayList.add(localObject[j]);
      }
    }
    i = localArrayList.size();
    Object localObject = NSMutableArray.arrayWithCapacity(i);
    for (int j = 0; j < i; j++) {
      ((NSMutableArray)localObject).addObject(NSString.stringWith((String)localArrayList.get(j)));
    }
    this.control.view.registerForDraggedTypes((NSArray)localObject);
  }
  
  void setDropNotAllowed()
  {
    if (!dropNotAllowed)
    {
      NSCursor.currentCursor().push();
      Display localDisplay = getDisplay();
      localDisplay.setData("org.eclipse.swt.internal.lockCursor", Boolean.FALSE);
      NSCursor.operationNotAllowedCursor().push();
      localDisplay.setData("org.eclipse.swt.internal.lockCursor", Boolean.TRUE);
      dropNotAllowed = true;
    }
  }
  
  void clearDropNotAllowed()
  {
    if (dropNotAllowed)
    {
      Display localDisplay = getDisplay();
      localDisplay.setData("org.eclipse.swt.internal.lockCursor", Boolean.FALSE);
      NSCursor.pop();
      localDisplay.setData("org.eclipse.swt.internal.lockCursor", Boolean.TRUE);
      NSCursor.pop();
      dropNotAllowed = false;
    }
  }
  
  boolean tableView_acceptDrop_row_dropOperation(long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5, long paramLong6)
  {
    return drop(new NSObject(paramLong4));
  }
  
  int tableView_validateDrop_proposedRow_proposedDropOperation(long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5, long paramLong6)
  {
    NSTableView localNSTableView = new NSTableView(paramLong3);
    NSObject localNSObject = new NSObject(paramLong4);
    NSPoint localNSPoint = localNSObject.draggingLocation();
    localNSPoint = localNSTableView.convertPoint_fromView_(localNSPoint, null);
    long l = localNSTableView.rowAtPoint(localNSPoint);
    if ((0L <= l) && (l < localNSTableView.numberOfRows())) {
      if (this.feedback == 0)
      {
        localNSTableView.setDropRow(-1L, 0L);
      }
      else if ((this.feedback & 0x1) != 0)
      {
        localNSTableView.setDropRow(l, 0L);
      }
      else
      {
        if ((this.feedback & 0x4) != 0) {
          localNSTableView.setDropRow(l + 1L, 1L);
        }
        if ((this.feedback & 0x2) != 0) {
          localNSTableView.setDropRow(l, 1L);
        }
      }
    }
    return opToOsOp(this.selectedOperation);
  }
  
  boolean wantsPeriodicDraggingUpdates(long paramLong1, long paramLong2)
  {
    return true;
  }
  
  static
  {
    Class localClass = DropTarget.class;
    dropTarget2Args = new Callback(localClass, "dropTargetProc", 2);
    proc2Args = dropTarget2Args.getAddress();
    if (proc2Args == 0L) {
      SWT.error(3);
    }
    dropTarget3Args = new Callback(localClass, "dropTargetProc", 3);
    proc3Args = dropTarget3Args.getAddress();
    if (proc3Args == 0L) {
      SWT.error(3);
    }
    dropTarget6Args = new Callback(localClass, "dropTargetProc", 6);
    proc6Args = dropTarget6Args.getAddress();
    if (proc6Args == 0L) {
      SWT.error(3);
    }
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/dnd/DropTarget.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */