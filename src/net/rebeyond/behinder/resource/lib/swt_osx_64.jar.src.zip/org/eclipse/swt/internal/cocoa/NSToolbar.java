package org.eclipse.swt.internal.cocoa;

public class NSToolbar
  extends NSObject
{
  public NSToolbar() {}
  
  public NSToolbar(long paramLong)
  {
    super(paramLong);
  }
  
  public NSToolbar(id paramid)
  {
    super(paramid);
  }
  
  public NSToolbar initWithIdentifier(NSString paramNSString)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_initWithIdentifier_, paramNSString != null ? paramNSString.id : 0L);
    return l != 0L ? new NSToolbar(l) : l == this.id ? this : null;
  }
  
  public void insertItemWithItemIdentifier(NSString paramNSString, long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_insertItemWithItemIdentifier_atIndex_, paramNSString != null ? paramNSString.id : 0L, paramLong);
  }
  
  public boolean isVisible()
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_isVisible);
  }
  
  public void removeItemAtIndex(long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_removeItemAtIndex_, paramLong);
  }
  
  public void setAllowsUserCustomization(boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_setAllowsUserCustomization_, paramBoolean);
  }
  
  public void setDelegate(id paramid)
  {
    OS.objc_msgSend(this.id, OS.sel_setDelegate_, paramid != null ? paramid.id : 0L);
  }
  
  public void setDisplayMode(long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_setDisplayMode_, paramLong);
  }
  
  public void setSelectedItemIdentifier(NSString paramNSString)
  {
    OS.objc_msgSend(this.id, OS.sel_setSelectedItemIdentifier_, paramNSString != null ? paramNSString.id : 0L);
  }
  
  public void setVisible(boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_setVisible_, paramBoolean);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSToolbar.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */