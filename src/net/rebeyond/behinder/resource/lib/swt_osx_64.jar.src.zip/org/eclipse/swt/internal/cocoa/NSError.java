package org.eclipse.swt.internal.cocoa;

public class NSError
  extends NSObject
{
  public NSError() {}
  
  public NSError(long paramLong)
  {
    super(paramLong);
  }
  
  public NSError(id paramid)
  {
    super(paramid);
  }
  
  public long code()
  {
    return OS.objc_msgSend(this.id, OS.sel_code);
  }
  
  public NSString localizedDescription()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_localizedDescription);
    return l != 0L ? new NSString(l) : null;
  }
  
  public NSDictionary userInfo()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_userInfo);
    return l != 0L ? new NSDictionary(l) : null;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSError.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */