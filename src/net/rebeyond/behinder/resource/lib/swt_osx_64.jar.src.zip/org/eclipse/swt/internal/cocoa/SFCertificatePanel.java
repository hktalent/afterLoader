package org.eclipse.swt.internal.cocoa;

public class SFCertificatePanel
  extends NSPanel
{
  public SFCertificatePanel() {}
  
  public SFCertificatePanel(long paramLong)
  {
    super(paramLong);
  }
  
  public SFCertificatePanel(id paramid)
  {
    super(paramid);
  }
  
  public void setAlternateButtonTitle(NSString paramNSString)
  {
    OS.objc_msgSend(this.id, OS.sel_setAlternateButtonTitle_, paramNSString != null ? paramNSString.id : 0L);
  }
  
  public void setShowsHelp(boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_setShowsHelp_, paramBoolean);
  }
  
  public static double minFrameWidthWithTitle(NSString paramNSString, long paramLong)
  {
    return OS.objc_msgSend_fpret(OS.class_SFCertificatePanel, OS.sel_minFrameWidthWithTitle_styleMask_, paramNSString != null ? paramNSString.id : 0L, paramLong);
  }
  
  public static long windowNumberAtPoint(NSPoint paramNSPoint, long paramLong)
  {
    return OS.objc_msgSend(OS.class_SFCertificatePanel, OS.sel_windowNumberAtPoint_belowWindowWithWindowNumber_, paramNSPoint, paramLong);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/SFCertificatePanel.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */