package org.eclipse.swt.graphics;

import org.eclipse.swt.SWT;
import org.eclipse.swt.internal.cocoa.NSAutoreleasePool;
import org.eclipse.swt.internal.cocoa.NSBitmapImageRep;
import org.eclipse.swt.internal.cocoa.NSCursor;
import org.eclipse.swt.internal.cocoa.NSImage;
import org.eclipse.swt.internal.cocoa.NSObject;
import org.eclipse.swt.internal.cocoa.NSPoint;
import org.eclipse.swt.internal.cocoa.NSSize;
import org.eclipse.swt.internal.cocoa.NSThread;
import org.eclipse.swt.internal.cocoa.OS;

public final class Cursor
  extends Resource
{
  static final byte[] WAIT_SOURCE = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
  static final byte[] SHADOWED_IBEAM_SOURCE = { 85, -1, -1, -1, -1, 85, 85, 85, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -86, -1, -1, -1, -1, 85, 85, 85, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -86, -1, -1, -1, -1, 0, 0, 0, -86, -1, -1, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -86, -1, -1, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -86, -1, -1, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -86, -1, -1, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -86, -1, -1, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -86, -1, -1, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -86, -1, -1, -1, -1, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -86, -1, -1, -1, -1, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -86, -1, -1, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -86, -1, -1, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -86, -1, -1, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -86, -1, -1, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -86, -1, -1, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -86, -1, -1, -1, -1, 0, 0, 0, -86, -1, -1, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 85, -1, -1, -1, -1, 85, 85, 85, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -86, -1, -1, -1, -1, 85, 85, 85, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
  public NSCursor handle;
  
  Cursor(Device paramDevice)
  {
    super(paramDevice);
  }
  
  public Cursor(Device paramDevice, int paramInt)
  {
    super(paramDevice);
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    int i = 0;
    try
    {
      switch (paramInt)
      {
      case 21: 
        this.handle = NSCursor.pointingHandCursor();
        break;
      case 0: 
        this.handle = NSCursor.arrowCursor();
        break;
      case 1: 
        i = 1;
        break;
      case 2: 
        this.handle = NSCursor.crosshairCursor();
        break;
      case 3: 
        this.handle = NSCursor.arrowCursor();
        break;
      case 4: 
        this.handle = NSCursor.crosshairCursor();
        break;
      case 5: 
        this.handle = NSCursor.crosshairCursor();
        break;
      case 6: 
        this.handle = NSCursor.crosshairCursor();
        break;
      case 7: 
        this.handle = NSCursor.resizeUpDownCursor();
        break;
      case 8: 
        this.handle = NSCursor.crosshairCursor();
        break;
      case 9: 
        this.handle = NSCursor.resizeLeftRightCursor();
        break;
      case 10: 
        this.handle = NSCursor.resizeUpCursor();
        break;
      case 11: 
        this.handle = NSCursor.resizeDownCursor();
        break;
      case 12: 
        this.handle = NSCursor.resizeRightCursor();
        break;
      case 13: 
        this.handle = NSCursor.resizeLeftCursor();
        break;
      case 14: 
        this.handle = NSCursor.crosshairCursor();
        break;
      case 15: 
        this.handle = NSCursor.crosshairCursor();
        break;
      case 16: 
        this.handle = NSCursor.crosshairCursor();
        break;
      case 17: 
        this.handle = NSCursor.crosshairCursor();
        break;
      case 18: 
        this.handle = NSCursor.crosshairCursor();
        break;
      case 19: 
        i = 1;
        break;
      case 20: 
        this.handle = NSCursor.operationNotAllowedCursor();
        break;
      default: 
        SWT.error(5);
      }
      if ((this.handle == null) && (i != 0))
      {
        NSImage localNSImage = (NSImage)new NSImage().alloc();
        NSBitmapImageRep localNSBitmapImageRep = (NSBitmapImageRep)new NSBitmapImageRep().alloc();
        this.handle = ((NSCursor)new NSCursor().alloc());
        int j = 16;
        int k = 16;
        NSSize localNSSize = new NSSize();
        localNSSize.width = j;
        localNSSize.height = k;
        localNSImage = localNSImage.initWithSize(localNSSize);
        localNSBitmapImageRep = localNSBitmapImageRep.initWithBitmapDataPlanes(0L, j, k, 8L, 4L, true, false, OS.NSDeviceRGBColorSpace, 3L, j * 4, 32L);
        NSPoint localNSPoint = new NSPoint();
        if (paramInt == 1)
        {
          OS.memmove(localNSBitmapImageRep.bitmapData(), WAIT_SOURCE, WAIT_SOURCE.length);
        }
        else
        {
          OS.memmove(localNSBitmapImageRep.bitmapData(), SHADOWED_IBEAM_SOURCE, SHADOWED_IBEAM_SOURCE.length);
          localNSPoint.x = 4.0D;
          localNSPoint.y = 8.0D;
        }
        localNSImage.addRepresentation(localNSBitmapImageRep);
        this.handle = this.handle.initWithImage(localNSImage, localNSPoint);
        localNSBitmapImageRep.release();
        localNSImage.release();
      }
      else
      {
        this.handle.retain();
      }
      this.handle.setOnMouseEntered(true);
      init();
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  public Cursor(Device paramDevice, ImageData paramImageData1, ImageData paramImageData2, int paramInt1, int paramInt2)
  {
    super(paramDevice);
    if (paramImageData1 == null) {
      SWT.error(4);
    }
    if (paramImageData2 == null)
    {
      if (paramImageData1.getTransparencyType() != 2) {
        SWT.error(4);
      }
      paramImageData2 = paramImageData1.getTransparencyMask();
    }
    if ((paramImageData2.width != paramImageData1.width) || (paramImageData2.height != paramImageData1.height)) {
      SWT.error(5);
    }
    if ((paramInt1 >= paramImageData1.width) || (paramInt1 < 0) || (paramInt2 >= paramImageData1.height) || (paramInt2 < 0)) {
      SWT.error(5);
    }
    byte[] arrayOfByte = new byte[paramImageData1.width * paramImageData1.height * 4];
    for (int i = 0; i < paramImageData1.height; i++)
    {
      int j = i * paramImageData1.width * 4;
      for (int k = 0; k < paramImageData1.width; k++)
      {
        int m = paramImageData1.getPixel(k, i);
        int n = paramImageData2.getPixel(k, i);
        if ((m == 0) && (n == 0)) {
          arrayOfByte[j] = -1;
        } else if ((m == 0) && (n == 1)) {
          arrayOfByte[j] = (arrayOfByte[(j + 1)] = arrayOfByte[(j + 2)] = arrayOfByte[(j + 3)] = -1);
        } else if ((m != 1) || (n != 0)) {}
        j += 4;
      }
    }
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      createNSCursor(paramInt1, paramInt2, arrayOfByte, paramImageData1.width, paramImageData1.height);
      init();
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  void createNSCursor(int paramInt1, int paramInt2, byte[] paramArrayOfByte, int paramInt3, int paramInt4)
  {
    NSImage localNSImage = (NSImage)new NSImage().alloc();
    NSBitmapImageRep localNSBitmapImageRep = (NSBitmapImageRep)new NSBitmapImageRep().alloc();
    this.handle = ((NSCursor)new NSCursor().alloc());
    NSSize localNSSize = new NSSize();
    localNSSize.width = paramInt3;
    localNSSize.height = paramInt4;
    localNSImage = localNSImage.initWithSize(localNSSize);
    localNSBitmapImageRep = localNSBitmapImageRep.initWithBitmapDataPlanes(0L, paramInt3, paramInt4, 8L, 4L, true, false, OS.NSDeviceRGBColorSpace, 3L, paramInt3 * 4, 32L);
    OS.memmove(localNSBitmapImageRep.bitmapData(), paramArrayOfByte, paramArrayOfByte.length);
    localNSImage.addRepresentation(localNSBitmapImageRep);
    NSPoint localNSPoint = new NSPoint();
    localNSPoint.x = paramInt1;
    localNSPoint.y = paramInt2;
    this.handle = this.handle.initWithImage(localNSImage, localNSPoint);
    localNSBitmapImageRep.release();
    localNSImage.release();
  }
  
  public Cursor(Device paramDevice, ImageData paramImageData, int paramInt1, int paramInt2)
  {
    super(paramDevice);
    if (paramImageData == null) {
      SWT.error(4);
    }
    if ((paramInt1 >= paramImageData.width) || (paramInt1 < 0) || (paramInt2 >= paramImageData.height) || (paramInt2 < 0)) {
      SWT.error(5);
    }
    byte[] arrayOfByte1 = new byte[paramImageData.width * paramImageData.height * 4];
    PaletteData localPaletteData = paramImageData.palette;
    Object localObject1;
    int i2;
    if (localPaletteData.isDirect)
    {
      ImageData.blit(1, paramImageData.data, paramImageData.depth, paramImageData.bytesPerLine, paramImageData.getByteOrder(), 0, 0, paramImageData.width, paramImageData.height, localPaletteData.redMask, localPaletteData.greenMask, localPaletteData.blueMask, 255, null, 0, 0, 0, arrayOfByte1, 32, paramImageData.width * 4, 1, 0, 0, paramImageData.width, paramImageData.height, 16711680, 65280, 255, false, false);
    }
    else
    {
      localObject1 = localPaletteData.getRGBs();
      int j = localObject1.length;
      byte[] arrayOfByte3 = new byte[j];
      byte[] arrayOfByte4 = new byte[j];
      byte[] arrayOfByte5 = new byte[j];
      for (i2 = 0; i2 < localObject1.length; i2++)
      {
        Object localObject3 = localObject1[i2];
        if (localObject3 != null)
        {
          arrayOfByte3[i2] = ((byte)((RGB)localObject3).red);
          arrayOfByte4[i2] = ((byte)((RGB)localObject3).green);
          arrayOfByte5[i2] = ((byte)((RGB)localObject3).blue);
        }
      }
      ImageData.blit(1, paramImageData.data, paramImageData.depth, paramImageData.bytesPerLine, paramImageData.getByteOrder(), 0, 0, paramImageData.width, paramImageData.height, arrayOfByte3, arrayOfByte4, arrayOfByte5, 255, null, 0, 0, 0, arrayOfByte1, 32, paramImageData.width * 4, 1, 0, 0, paramImageData.width, paramImageData.height, 16711680, 65280, 255, false, false);
    }
    if ((paramImageData.maskData != null) || (paramImageData.transparentPixel != -1))
    {
      localObject1 = paramImageData.getTransparencyMask();
      byte[] arrayOfByte2 = ((ImageData)localObject1).data;
      int m = ((ImageData)localObject1).bytesPerLine;
      int n = 0;
      int i1 = 0;
      for (i2 = 0; i2 < paramImageData.height; i2++)
      {
        for (int i3 = 0; i3 < paramImageData.width; i3++)
        {
          arrayOfByte1[n] = ((arrayOfByte2[(i1 + (i3 >> 3))] & 1 << 7 - (i3 & 0x7)) != 0 ? -1 : 0);
          n += 4;
        }
        i1 += m;
      }
    }
    else
    {
      int k;
      if (paramImageData.alpha != -1)
      {
        int i = (byte)paramImageData.alpha;
        for (k = 0; k < arrayOfByte1.length; k += 4) {
          arrayOfByte1[k] = i;
        }
      }
      else if (paramImageData.alphaData != null)
      {
        localObject2 = paramImageData.alphaData;
        for (k = 0; k < arrayOfByte1.length; k += 4) {
          arrayOfByte1[k] = localObject2[(k / 4)];
        }
      }
    }
    Object localObject2 = null;
    if (!NSThread.isMainThread()) {
      localObject2 = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      createNSCursor(paramInt1, paramInt2, arrayOfByte1, paramImageData.width, paramImageData.height);
      init();
    }
    finally
    {
      if (localObject2 != null) {
        ((NSAutoreleasePool)localObject2).release();
      }
    }
  }
  
  void destroy()
  {
    this.handle.release();
    this.handle = null;
  }
  
  public boolean equals(Object paramObject)
  {
    if (paramObject == this) {
      return true;
    }
    if (!(paramObject instanceof Cursor)) {
      return false;
    }
    Cursor localCursor = (Cursor)paramObject;
    return (this.device == localCursor.device) && (this.handle == localCursor.handle);
  }
  
  public int hashCode()
  {
    return this.handle != null ? (int)this.handle.id : 0;
  }
  
  public boolean isDisposed()
  {
    return this.handle == null;
  }
  
  public String toString()
  {
    if (isDisposed()) {
      return "Cursor {*DISPOSED*}";
    }
    return "Cursor {" + this.handle + "}";
  }
  
  public static Cursor cocoa_new(Device paramDevice, NSCursor paramNSCursor)
  {
    Cursor localCursor = new Cursor(paramDevice);
    localCursor.handle = paramNSCursor;
    return localCursor;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/graphics/Cursor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */