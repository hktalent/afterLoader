package org.eclipse.swt.graphics;

import org.eclipse.swt.internal.cocoa.NSAffineTransform;
import org.eclipse.swt.internal.cocoa.NSBezierPath;
import org.eclipse.swt.internal.cocoa.NSColor;
import org.eclipse.swt.internal.cocoa.NSGraphicsContext;
import org.eclipse.swt.internal.cocoa.NSLayoutManager;
import org.eclipse.swt.internal.cocoa.NSRect;
import org.eclipse.swt.internal.cocoa.NSSize;
import org.eclipse.swt.internal.cocoa.NSTextContainer;
import org.eclipse.swt.internal.cocoa.NSTextStorage;
import org.eclipse.swt.internal.cocoa.NSView;

public final class GCData
{
  public Device device;
  public int style;
  public int state = -1;
  public double[] foreground;
  public double[] background;
  public Pattern foregroundPattern;
  public Pattern backgroundPattern;
  public Font font;
  public int alpha = 255;
  public float lineWidth;
  public int lineStyle = 1;
  public int lineCap = 1;
  public int lineJoin = 1;
  public float lineDashesOffset;
  public float[] lineDashes;
  public float lineMiterLimit = 10.0F;
  public boolean xorMode;
  public int antialias = -1;
  public int textAntialias = -1;
  public int fillRule = 1;
  public Image image;
  public NSTextStorage textStorage;
  public NSLayoutManager layoutManager;
  public NSTextContainer textContainer;
  public NSColor fg;
  public NSColor bg;
  public double drawXOffset;
  public double drawYOffset;
  public NSRect paintRect;
  public NSBezierPath path;
  public NSAffineTransform transform;
  public NSAffineTransform inverseTransform;
  public NSBezierPath clipPath;
  public NSBezierPath visiblePath;
  public long visibleRgn;
  public NSView view;
  public NSSize size;
  public Thread thread;
  public NSGraphicsContext flippedContext;
  public boolean restoreContext;
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/graphics/GCData.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */