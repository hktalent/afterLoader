package org.eclipse.swt.events;

public abstract class MouseTrackAdapter
  implements MouseTrackListener
{
  public void mouseEnter(MouseEvent paramMouseEvent) {}
  
  public void mouseExit(MouseEvent paramMouseEvent) {}
  
  public void mouseHover(MouseEvent paramMouseEvent) {}
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/events/MouseTrackAdapter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */