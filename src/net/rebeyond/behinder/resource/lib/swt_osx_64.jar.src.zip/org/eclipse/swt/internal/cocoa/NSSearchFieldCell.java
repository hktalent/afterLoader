package org.eclipse.swt.internal.cocoa;

public class NSSearchFieldCell
  extends NSTextFieldCell
{
  public NSSearchFieldCell() {}
  
  public NSSearchFieldCell(long paramLong)
  {
    super(paramLong);
  }
  
  public NSSearchFieldCell(id paramid)
  {
    super(paramid);
  }
  
  public NSButtonCell cancelButtonCell()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_cancelButtonCell);
    return l != 0L ? new NSButtonCell(l) : null;
  }
  
  public NSButtonCell searchButtonCell()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_searchButtonCell);
    return l != 0L ? new NSButtonCell(l) : null;
  }
  
  public NSRect searchTextRectForBounds(NSRect paramNSRect)
  {
    NSRect localNSRect = new NSRect();
    OS.objc_msgSend_stret(localNSRect, this.id, OS.sel_searchTextRectForBounds_, paramNSRect);
    return localNSRect;
  }
  
  public void setCancelButtonCell(NSButtonCell paramNSButtonCell)
  {
    OS.objc_msgSend(this.id, OS.sel_setCancelButtonCell_, paramNSButtonCell != null ? paramNSButtonCell.id : 0L);
  }
  
  public void setSearchButtonCell(NSButtonCell paramNSButtonCell)
  {
    OS.objc_msgSend(this.id, OS.sel_setSearchButtonCell_, paramNSButtonCell != null ? paramNSButtonCell.id : 0L);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSSearchFieldCell.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */