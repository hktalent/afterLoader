package org.eclipse.swt.internal.cocoa;

public class SWTScrollView
  extends NSScrollView
{
  public SWTScrollView()
  {
    super(0L);
  }
  
  public SWTScrollView(long paramLong)
  {
    super(paramLong);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/SWTScrollView.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */