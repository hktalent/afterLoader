package org.eclipse.swt.internal.cocoa;

public class NSButtonCell
  extends NSActionCell
{
  public NSButtonCell() {}
  
  public NSButtonCell(long paramLong)
  {
    super(paramLong);
  }
  
  public NSButtonCell(id paramid)
  {
    super(paramid);
  }
  
  public NSColor backgroundColor()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_backgroundColor);
    return l != 0L ? new NSColor(l) : null;
  }
  
  public void drawImage(NSImage paramNSImage, NSRect paramNSRect, NSView paramNSView)
  {
    OS.objc_msgSend(this.id, OS.sel_drawImage_withFrame_inView_, paramNSImage != null ? paramNSImage.id : 0L, paramNSRect, paramNSView != null ? paramNSView.id : 0L);
  }
  
  public NSRect drawTitle(NSAttributedString paramNSAttributedString, NSRect paramNSRect, NSView paramNSView)
  {
    NSRect localNSRect = new NSRect();
    OS.objc_msgSend_stret(localNSRect, this.id, OS.sel_drawTitle_withFrame_inView_, paramNSAttributedString != null ? paramNSAttributedString.id : 0L, paramNSRect, paramNSView != null ? paramNSView.id : 0L);
    return localNSRect;
  }
  
  public void setBackgroundColor(NSColor paramNSColor)
  {
    OS.objc_msgSend(this.id, OS.sel_setBackgroundColor_, paramNSColor != null ? paramNSColor.id : 0L);
  }
  
  public void setButtonType(long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_setButtonType_, paramLong);
  }
  
  public void setHighlightsBy(long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_setHighlightsBy_, paramLong);
  }
  
  public void setImagePosition(long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_setImagePosition_, paramLong);
  }
  
  public NSString title()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_title);
    return l != 0L ? new NSString(l) : null;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSButtonCell.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */