package org.eclipse.swt.dnd;

import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.ImageData;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.internal.C;
import org.eclipse.swt.internal.Callback;
import org.eclipse.swt.internal.cocoa.NSApplication;
import org.eclipse.swt.internal.cocoa.NSArray;
import org.eclipse.swt.internal.cocoa.NSData;
import org.eclipse.swt.internal.cocoa.NSEvent;
import org.eclipse.swt.internal.cocoa.NSFileManager;
import org.eclipse.swt.internal.cocoa.NSImage;
import org.eclipse.swt.internal.cocoa.NSMutableArray;
import org.eclipse.swt.internal.cocoa.NSObject;
import org.eclipse.swt.internal.cocoa.NSPasteboard;
import org.eclipse.swt.internal.cocoa.NSPoint;
import org.eclipse.swt.internal.cocoa.NSSize;
import org.eclipse.swt.internal.cocoa.NSString;
import org.eclipse.swt.internal.cocoa.NSURL;
import org.eclipse.swt.internal.cocoa.NSView;
import org.eclipse.swt.internal.cocoa.OS;
import org.eclipse.swt.internal.cocoa.SWTDragSourceDelegate;
import org.eclipse.swt.internal.cocoa.objc_super;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.Tree;
import org.eclipse.swt.widgets.Widget;

public class DragSource
  extends Widget
{
  static byte[] types = { 42, 0 };
  static int size = C.PTR_SIZEOF;
  static int align = C.PTR_SIZEOF == 4 ? 2 : 3;
  static Callback dragSource2Args;
  static Callback dragSource3Args;
  static Callback dragSource4Args;
  static Callback dragSource5Args;
  static Callback dragSource6Args;
  static final byte[] SWT_OBJECT = { 83, 87, 84, 95, 79, 66, 74, 69, 67, 84, 0 };
  static long proc2 = 0L;
  static long proc3 = 0L;
  static long proc4 = 0L;
  static long proc5 = 0L;
  static long proc6 = 0L;
  String[] paths;
  boolean[] exist;
  Control control;
  Listener controlListener;
  Transfer[] transferAgents = new Transfer[0];
  DragSourceEffect dragEffect;
  Image dragImageFromListener;
  private int dragOperations;
  SWTDragSourceDelegate dragSourceDelegate;
  static final String DEFAULT_DRAG_SOURCE_EFFECT = "DEFAULT_DRAG_SOURCE_EFFECT";
  private long delegateJniRef;
  private Point dragOffset;
  
  public DragSource(Control paramControl, int paramInt)
  {
    super(paramControl, checkStyle(paramInt));
    this.control = paramControl;
    if (paramControl.getData("DragSource") != null) {
      DND.error(2000);
    }
    paramControl.setData("DragSource", this);
    this.controlListener = new Listener()
    {
      public void handleEvent(Event paramAnonymousEvent)
      {
        if ((paramAnonymousEvent.type == 12) && (!DragSource.this.isDisposed())) {
          DragSource.this.dispose();
        }
        if ((paramAnonymousEvent.type == 29) && (!DragSource.this.isDisposed())) {
          if (((paramAnonymousEvent.widget instanceof Table)) || ((paramAnonymousEvent.widget instanceof Tree))) {
            DragSource.this.dragOutlineViewStart(paramAnonymousEvent);
          } else {
            DragSource.this.drag(paramAnonymousEvent);
          }
        }
      }
    };
    paramControl.addListener(12, this.controlListener);
    paramControl.addListener(29, this.controlListener);
    addListener(12, new Listener()
    {
      public void handleEvent(Event paramAnonymousEvent)
      {
        DragSource.this.onDispose();
      }
    });
    Object localObject = paramControl.getData("DEFAULT_DRAG_SOURCE_EFFECT");
    if ((localObject instanceof DragSourceEffect)) {
      this.dragEffect = ((DragSourceEffect)localObject);
    } else if ((paramControl instanceof Tree)) {
      this.dragEffect = new TreeDragSourceEffect((Tree)paramControl);
    } else if ((paramControl instanceof Table)) {
      this.dragEffect = new TableDragSourceEffect((Table)paramControl);
    }
    this.delegateJniRef = OS.NewGlobalRef(this);
    if (this.delegateJniRef == 0L) {
      SWT.error(2);
    }
    this.dragSourceDelegate = ((SWTDragSourceDelegate)new SWTDragSourceDelegate().alloc().init());
    OS.object_setInstanceVariable(this.dragSourceDelegate.id, SWT_OBJECT, this.delegateJniRef);
    if (((paramControl instanceof Tree)) || ((paramControl instanceof Table)))
    {
      long l1 = OS.object_getClass(paramControl.view.id);
      if (l1 == 0L) {
        DND.error(2000);
      }
      long l2 = OS.class_getMethodImplementation(l1, OS.sel_draggingSourceOperationMaskForLocal_);
      if (l2 == proc3) {
        return;
      }
      long l3 = OS.CALLBACK_draggedImage_endedAt_operation_(proc5);
      OS.class_addMethod(l1, OS.sel_draggingSourceOperationMaskForLocal_, proc3, "@:I");
      OS.class_addMethod(l1, OS.sel_draggedImage_beganAt_, proc4, "@:@{NSPoint=ff}");
      OS.class_addMethod(l1, OS.sel_draggedImage_endedAt_operation_, l3, "@:@{NSPoint=ff}I");
      OS.class_addMethod(l1, OS.sel_ignoreModifierKeysWhileDragging, proc3, "@:");
      OS.class_addMethod(l1, OS.sel_dragImageForRowsWithIndexes_tableColumns_event_offset_, proc6, "@:@@@^NSPoint");
    }
  }
  
  public void addDragListener(DragSourceListener paramDragSourceListener)
  {
    if (paramDragSourceListener == null) {
      DND.error(4);
    }
    DNDListener localDNDListener = new DNDListener(paramDragSourceListener);
    localDNDListener.dndWidget = this;
    addListener(2008, localDNDListener);
    addListener(2001, localDNDListener);
    addListener(2000, localDNDListener);
  }
  
  void dndCallSuper(long paramLong1, long paramLong2, long paramLong3, NSPoint paramNSPoint, long paramLong4)
  {
    objc_super localobjc_super = new objc_super();
    localobjc_super.receiver = paramLong1;
    localobjc_super.super_class = OS.objc_msgSend(paramLong1, OS.sel_superclass);
    OS.objc_msgSendSuper(localobjc_super, paramLong2, paramLong3, paramNSPoint, paramLong4);
  }
  
  void dndCallSuper(long paramLong1, long paramLong2, long paramLong3, long paramLong4)
  {
    objc_super localobjc_super = new objc_super();
    localobjc_super.receiver = paramLong1;
    localobjc_super.super_class = OS.objc_msgSend(paramLong1, OS.sel_superclass);
    OS.objc_msgSendSuper(localobjc_super, paramLong2, paramLong3, paramLong4);
  }
  
  long dndCallSuperObject(long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5, long paramLong6)
  {
    objc_super localobjc_super = new objc_super();
    localobjc_super.receiver = paramLong1;
    localobjc_super.super_class = OS.objc_msgSend(paramLong1, OS.sel_superclass);
    return OS.objc_msgSendSuper(localobjc_super, paramLong2, paramLong3, paramLong4, paramLong5, paramLong6);
  }
  
  protected void checkSubclass()
  {
    String str1 = getClass().getName();
    String str2 = DragSource.class.getName();
    if (!str2.equals(str1)) {
      DND.error(43);
    }
  }
  
  static int checkStyle(int paramInt)
  {
    if (paramInt == 0) {
      return 2;
    }
    return paramInt;
  }
  
  void drag(Event paramEvent)
  {
    DNDEvent localDNDEvent = startDrag(paramEvent);
    if (localDNDEvent == null) {
      return;
    }
    NSEvent localNSEvent = NSApplication.sharedApplication().currentEvent();
    NSPoint localNSPoint1 = localNSEvent.locationInWindow();
    NSPoint localNSPoint2 = this.control.view.convertPoint_fromView_(localNSPoint1, null);
    NSImage localNSImage = null;
    Image localImage1 = null;
    try
    {
      Image localImage2 = localDNDEvent.image;
      if (localImage2 == null)
      {
        int i = 20;
        int j = 20;
        Image localImage3 = new Image(Display.getCurrent(), i, j);
        GC localGC = new GC(localImage3);
        Color localColor = new Color(Display.getCurrent(), 50, 50, 50);
        localGC.setForeground(localColor);
        localGC.drawRectangle(0, 0, 19, 19);
        localGC.dispose();
        ImageData localImageData = localImage3.getImageData();
        localImageData.alpha = 102;
        localImage1 = new Image(Display.getCurrent(), localImageData);
        localImage3.dispose();
        localColor.dispose();
        localImage2 = localImage1;
        localDNDEvent.offsetX = (i / 2);
        localDNDEvent.offsetY = (j / 2);
      }
      localNSImage = localImage2.handle;
      NSSize localNSSize1 = localNSImage.size();
      localNSPoint2.x -= localDNDEvent.offsetX;
      if (this.control.view.isFlipped()) {
        localNSPoint2.y += localNSSize1.height - localDNDEvent.offsetY;
      } else {
        localNSPoint2.y -= localDNDEvent.offsetY;
      }
      NSSize localNSSize2 = new NSSize();
      this.control.view.dragImage(localNSImage, localNSPoint2, localNSSize2, NSApplication.sharedApplication().currentEvent(), NSPasteboard.pasteboardWithName(OS.NSDragPboard), this.dragSourceDelegate, true);
    }
    finally
    {
      if (localImage1 != null) {
        localImage1.dispose();
      }
    }
  }
  
  void dragOutlineViewStart(Event paramEvent)
  {
    DNDEvent localDNDEvent = startDrag(paramEvent);
    if (localDNDEvent == null) {
      return;
    }
    this.dragImageFromListener = localDNDEvent.image;
    this.dragOffset = new Point(localDNDEvent.offsetX, localDNDEvent.offsetY);
  }
  
  void draggedImage_beganAt(long paramLong1, long paramLong2, long paramLong3, long paramLong4)
  {
    if (new NSObject(paramLong1).isKindOfClass(OS.class_NSTableView)) {
      dndCallSuper(paramLong1, paramLong2, paramLong3, paramLong4);
    }
  }
  
  void draggedImage_endedAt_operation(long paramLong1, long paramLong2, long paramLong3, NSPoint paramNSPoint, long paramLong4)
  {
    int i = osOpToOp(paramLong4);
    Object localObject1;
    if (this.paths != null)
    {
      localObject1 = NSFileManager.defaultManager();
      for (int j = 0; j < this.paths.length; j++) {
        if ((this.paths[j] != null) && (this.exist[j] != 0) && (!((NSFileManager)localObject1).fileExistsAtPath(NSString.stringWith(this.paths[j]))))
        {
          i &= 0xFFFFFFFD;
          i |= 0x8;
        }
      }
      this.paths = null;
      this.exist = null;
    }
    OS.objc_msgSend(paramLong1, OS.sel_retain);
    try
    {
      localObject1 = new DNDEvent();
      ((Event)localObject1).widget = this;
      ((Event)localObject1).time = ((int)System.currentTimeMillis());
      ((Event)localObject1).doit = (i != 0);
      ((Event)localObject1).detail = i;
      notifyListeners(2000, (Event)localObject1);
      this.dragImageFromListener = null;
      if (new NSObject(paramLong1).isKindOfClass(OS.class_NSTableView)) {
        dndCallSuper(paramLong1, paramLong2, paramLong3, paramNSPoint, paramLong4);
      }
    }
    finally
    {
      OS.objc_msgSend(paramLong1, OS.sel_release);
    }
  }
  
  long dragImageForRowsWithIndexes_tableColumns_event_offset(long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5, long paramLong6)
  {
    if (this.dragImageFromListener != null)
    {
      NSPoint localNSPoint = new NSPoint();
      localNSPoint.x = this.dragOffset.x;
      localNSPoint.y = this.dragOffset.y;
      OS.memmove(paramLong6, localNSPoint, NSPoint.sizeof);
      return this.dragImageFromListener.handle.id;
    }
    return dndCallSuperObject(paramLong1, paramLong2, paramLong3, paramLong4, paramLong5, paramLong6);
  }
  
  long draggingSourceOperationMaskForLocal(long paramLong1, long paramLong2, long paramLong3)
  {
    return this.dragOperations;
  }
  
  static long dragSourceProc(long paramLong1, long paramLong2)
  {
    Display localDisplay = Display.findDisplay(Thread.currentThread());
    if ((localDisplay == null) || (localDisplay.isDisposed())) {
      return 0L;
    }
    Widget localWidget = localDisplay.findWidget(paramLong1);
    if (localWidget == null) {
      return 0L;
    }
    DragSource localDragSource = null;
    if ((localWidget instanceof DragSource)) {
      localDragSource = (DragSource)localWidget;
    } else {
      localDragSource = (DragSource)localWidget.getData("DragSource");
    }
    if (localDragSource == null) {
      return 0L;
    }
    if (paramLong2 == OS.sel_ignoreModifierKeysWhileDragging) {
      return localDragSource.ignoreModifierKeysWhileDragging(paramLong1, paramLong2) ? 1 : 0;
    }
    return 0L;
  }
  
  static long dragSourceProc(long paramLong1, long paramLong2, long paramLong3)
  {
    Display localDisplay = Display.findDisplay(Thread.currentThread());
    if ((localDisplay == null) || (localDisplay.isDisposed())) {
      return 0L;
    }
    Widget localWidget = localDisplay.findWidget(paramLong1);
    if (localWidget == null) {
      return 0L;
    }
    DragSource localDragSource = null;
    if ((localWidget instanceof DragSource)) {
      localDragSource = (DragSource)localWidget;
    } else {
      localDragSource = (DragSource)localWidget.getData("DragSource");
    }
    if (localDragSource == null) {
      return 0L;
    }
    if (paramLong2 == OS.sel_draggingSourceOperationMaskForLocal_) {
      return localDragSource.draggingSourceOperationMaskForLocal(paramLong1, paramLong2, paramLong3);
    }
    return 0L;
  }
  
  static long dragSourceProc(long paramLong1, long paramLong2, long paramLong3, long paramLong4)
  {
    Display localDisplay = Display.findDisplay(Thread.currentThread());
    if ((localDisplay == null) || (localDisplay.isDisposed())) {
      return 0L;
    }
    Widget localWidget = localDisplay.findWidget(paramLong1);
    if (localWidget == null) {
      return 0L;
    }
    DragSource localDragSource = null;
    if ((localWidget instanceof DragSource)) {
      localDragSource = (DragSource)localWidget;
    } else {
      localDragSource = (DragSource)localWidget.getData("DragSource");
    }
    if (localDragSource == null) {
      return 0L;
    }
    if (paramLong2 == OS.sel_draggedImage_beganAt_) {
      localDragSource.draggedImage_beganAt(paramLong1, paramLong2, paramLong3, paramLong4);
    } else if (paramLong2 == OS.sel_pasteboard_provideDataForType_) {
      localDragSource.pasteboard_provideDataForType(paramLong1, paramLong2, paramLong3, paramLong4);
    }
    return 0L;
  }
  
  static long dragSourceProc(long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5)
  {
    Display localDisplay = Display.findDisplay(Thread.currentThread());
    if ((localDisplay == null) || (localDisplay.isDisposed())) {
      return 0L;
    }
    Widget localWidget = localDisplay.findWidget(paramLong1);
    if (localWidget == null) {
      return 0L;
    }
    DragSource localDragSource = null;
    if ((localWidget instanceof DragSource)) {
      localDragSource = (DragSource)localWidget;
    } else {
      localDragSource = (DragSource)localWidget.getData("DragSource");
    }
    if (localDragSource == null) {
      return 0L;
    }
    if (paramLong2 == OS.sel_draggedImage_endedAt_operation_)
    {
      NSPoint localNSPoint = new NSPoint();
      OS.memmove(localNSPoint, paramLong4, NSPoint.sizeof);
      localDragSource.draggedImage_endedAt_operation(paramLong1, paramLong2, paramLong3, localNSPoint, paramLong5);
    }
    return 0L;
  }
  
  static long dragSourceProc(long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5, long paramLong6)
  {
    Display localDisplay = Display.findDisplay(Thread.currentThread());
    if ((localDisplay == null) || (localDisplay.isDisposed())) {
      return 0L;
    }
    Widget localWidget = localDisplay.findWidget(paramLong1);
    if (localWidget == null) {
      return 0L;
    }
    DragSource localDragSource = null;
    if ((localWidget instanceof DragSource)) {
      localDragSource = (DragSource)localWidget;
    } else {
      localDragSource = (DragSource)localWidget.getData("DragSource");
    }
    if (localDragSource == null) {
      return 0L;
    }
    if (paramLong2 == OS.sel_dragImageForRowsWithIndexes_tableColumns_event_offset_) {
      return localDragSource.dragImageForRowsWithIndexes_tableColumns_event_offset(paramLong1, paramLong2, paramLong3, paramLong4, paramLong5, paramLong6);
    }
    return 0L;
  }
  
  public Control getControl()
  {
    return this.control;
  }
  
  public DragSourceListener[] getDragListeners()
  {
    Listener[] arrayOfListener = getListeners(2008);
    int i = arrayOfListener.length;
    DragSourceListener[] arrayOfDragSourceListener1 = new DragSourceListener[i];
    int j = 0;
    for (int k = 0; k < i; k++)
    {
      Listener localListener = arrayOfListener[k];
      if ((localListener instanceof DNDListener))
      {
        arrayOfDragSourceListener1[j] = ((DragSourceListener)((DNDListener)localListener).getEventListener());
        j++;
      }
    }
    if (j == i) {
      return arrayOfDragSourceListener1;
    }
    DragSourceListener[] arrayOfDragSourceListener2 = new DragSourceListener[j];
    System.arraycopy(arrayOfDragSourceListener1, 0, arrayOfDragSourceListener2, 0, j);
    return arrayOfDragSourceListener2;
  }
  
  public DragSourceEffect getDragSourceEffect()
  {
    return this.dragEffect;
  }
  
  public Transfer[] getTransfer()
  {
    return this.transferAgents;
  }
  
  boolean ignoreModifierKeysWhileDragging(long paramLong1, long paramLong2)
  {
    return false;
  }
  
  void onDispose()
  {
    if (this.control == null) {
      return;
    }
    if (this.controlListener != null)
    {
      this.control.removeListener(12, this.controlListener);
      this.control.removeListener(29, this.controlListener);
    }
    this.controlListener = null;
    this.control.setData("DragSource", null);
    this.control = null;
    this.transferAgents = null;
    if (this.delegateJniRef != 0L) {
      OS.DeleteGlobalRef(this.delegateJniRef);
    }
    this.delegateJniRef = 0L;
    if (this.dragSourceDelegate != null)
    {
      OS.object_setInstanceVariable(this.dragSourceDelegate.id, SWT_OBJECT, 0L);
      this.dragSourceDelegate.release();
    }
  }
  
  int opToOsOp(int paramInt)
  {
    int i = 0;
    if ((paramInt & 0x1) != 0) {
      i |= 0x1;
    }
    if ((paramInt & 0x4) != 0) {
      i |= 0x2;
    }
    if ((paramInt & 0x2) != 0) {
      i |= 0x10;
    }
    if ((paramInt & 0x8) != 0) {
      i |= 0x20;
    }
    return i;
  }
  
  int osOpToOp(long paramLong)
  {
    int i = 0;
    if ((paramLong & 1L) != 0L) {
      i |= 0x1;
    }
    if ((paramLong & 0x2) != 0L) {
      i |= 0x4;
    }
    if ((paramLong & 0x20) != 0L) {
      i |= 0x8;
    }
    if ((paramLong & 0x10) != 0L) {
      i |= 0x2;
    }
    if (paramLong == -1L) {
      i = 7;
    }
    return i;
  }
  
  void pasteboard_provideDataForType(long paramLong1, long paramLong2, long paramLong3, long paramLong4)
  {
    NSPasteboard localNSPasteboard = new NSPasteboard(paramLong3);
    NSString localNSString1 = new NSString(paramLong4);
    if ((localNSPasteboard == null) || (localNSString1 == null)) {
      return;
    }
    TransferData localTransferData = new TransferData();
    localTransferData.type = Transfer.registerType(localNSString1.getString());
    DNDEvent localDNDEvent = new DNDEvent();
    localDNDEvent.widget = this;
    localDNDEvent.time = ((int)System.currentTimeMillis());
    localDNDEvent.dataType = localTransferData;
    notifyListeners(2001, localDNDEvent);
    if (!localDNDEvent.doit) {
      return;
    }
    Object localObject1 = null;
    Object localObject2;
    for (int i = 0; i < this.transferAgents.length; i++)
    {
      localObject2 = this.transferAgents[i];
      if ((localObject2 != null) && (((Transfer)localObject2).isSupportedType(localTransferData)))
      {
        localObject1 = localObject2;
        break;
      }
    }
    if (localObject1 == null) {
      return;
    }
    ((Transfer)localObject1).javaToNative(localDNDEvent.data, localTransferData);
    if (localTransferData.data == null) {
      return;
    }
    NSObject localNSObject = localTransferData.data;
    if ((localNSString1.isEqual(OS.NSStringPboardType)) || (localNSString1.isEqual(OS.NSHTMLPboardType)) || (localNSString1.isEqual(OS.NSRTFPboardType)))
    {
      localNSPasteboard.setString((NSString)localNSObject, localNSString1);
    }
    else if ((localNSString1.isEqual(OS.NSURLPboardType)) || (localNSString1.isEqual(OS.kUTTypeURL)))
    {
      localObject2 = (NSURL)localNSObject;
      ((NSURL)localObject2).writeToPasteboard(localNSPasteboard);
    }
    else if ((localNSString1.isEqual(OS.NSFilenamesPboardType)) || (localNSString1.isEqual(OS.kUTTypeFileURL)))
    {
      localObject2 = (NSArray)localTransferData.data;
      int j = (int)((NSArray)localObject2).count();
      this.paths = new String[j];
      this.exist = new boolean[j];
      NSFileManager localNSFileManager = NSFileManager.defaultManager();
      for (int k = 0; k < j; k++)
      {
        NSString localNSString2 = new NSString(((NSArray)localObject2).objectAtIndex(k));
        this.paths[k] = localNSString2.getString();
        this.exist[k] = localNSFileManager.fileExistsAtPath(localNSString2);
      }
      localNSPasteboard.setPropertyList((NSArray)localNSObject, OS.NSFilenamesPboardType);
    }
    else
    {
      localNSPasteboard.setData((NSData)localNSObject, localNSString1);
    }
  }
  
  public void removeDragListener(DragSourceListener paramDragSourceListener)
  {
    if (paramDragSourceListener == null) {
      DND.error(4);
    }
    removeListener(2008, paramDragSourceListener);
    removeListener(2001, paramDragSourceListener);
    removeListener(2000, paramDragSourceListener);
  }
  
  public void setDragSourceEffect(DragSourceEffect paramDragSourceEffect)
  {
    this.dragEffect = paramDragSourceEffect;
  }
  
  public void setTransfer(Transfer[] paramArrayOfTransfer)
  {
    this.transferAgents = paramArrayOfTransfer;
  }
  
  DNDEvent startDrag(Event paramEvent)
  {
    DNDEvent localDNDEvent = new DNDEvent();
    localDNDEvent.widget = this;
    localDNDEvent.x = paramEvent.x;
    localDNDEvent.y = paramEvent.y;
    localDNDEvent.time = paramEvent.time;
    localDNDEvent.doit = true;
    notifyListeners(2008, localDNDEvent);
    if ((!localDNDEvent.doit) || (this.transferAgents == null) || (this.transferAgents.length == 0)) {
      return null;
    }
    NSPasteboard localNSPasteboard = NSPasteboard.pasteboardWithName(OS.NSDragPboard);
    NSMutableArray localNSMutableArray = NSMutableArray.arrayWithCapacity(10L);
    for (int i = 0; i < this.transferAgents.length; i++)
    {
      Transfer localTransfer = this.transferAgents[i];
      if (localTransfer != null)
      {
        String[] arrayOfString = localTransfer.getTypeNames();
        for (int j = 0; j < arrayOfString.length; j++) {
          localNSMutableArray.addObject(NSString.stringWith(arrayOfString[j]));
        }
      }
    }
    localNSPasteboard.declareTypes(localNSMutableArray, this.dragSourceDelegate);
    this.dragOperations = opToOsOp(getStyle());
    return localDNDEvent;
  }
  
  static
  {
    String str = "SWTDragSourceDelegate";
    Class localClass = DragSource.class;
    dragSource2Args = new Callback(localClass, "dragSourceProc", 2);
    proc2 = dragSource2Args.getAddress();
    if (proc2 == 0L) {
      SWT.error(3);
    }
    dragSource3Args = new Callback(localClass, "dragSourceProc", 3);
    proc3 = dragSource3Args.getAddress();
    if (proc3 == 0L) {
      SWT.error(3);
    }
    dragSource4Args = new Callback(localClass, "dragSourceProc", 4);
    proc4 = dragSource4Args.getAddress();
    if (proc4 == 0L) {
      SWT.error(3);
    }
    dragSource5Args = new Callback(localClass, "dragSourceProc", 5);
    proc5 = dragSource5Args.getAddress();
    if (proc5 == 0L) {
      SWT.error(3);
    }
    dragSource6Args = new Callback(localClass, "dragSourceProc", 6);
    proc6 = dragSource6Args.getAddress();
    if (proc6 == 0L) {
      SWT.error(3);
    }
    long l1 = OS.objc_allocateClassPair(OS.class_NSObject, str, 0L);
    OS.class_addIvar(l1, SWT_OBJECT, size, (byte)align, types);
    long l2 = OS.CALLBACK_draggedImage_endedAt_operation_(proc5);
    OS.class_addMethod(l1, OS.sel_draggingSourceOperationMaskForLocal_, proc3, "@:I");
    OS.class_addMethod(l1, OS.sel_draggedImage_beganAt_, proc4, "@:@{NSPoint=ff}");
    OS.class_addMethod(l1, OS.sel_draggedImage_endedAt_operation_, l2, "@:@{NSPoint=ff}I");
    OS.class_addMethod(l1, OS.sel_ignoreModifierKeysWhileDragging, proc3, "@:");
    OS.class_addMethod(l1, OS.sel_pasteboard_provideDataForType_, proc4, "@:@@");
    OS.objc_registerClassPair(l1);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/dnd/DragSource.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */