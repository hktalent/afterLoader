package org.eclipse.swt.internal.cocoa;

public class NSComboBox
  extends NSTextField
{
  public NSComboBox() {}
  
  public NSComboBox(long paramLong)
  {
    super(paramLong);
  }
  
  public NSComboBox(id paramid)
  {
    super(paramid);
  }
  
  public void addItemWithObjectValue(id paramid)
  {
    OS.objc_msgSend(this.id, OS.sel_addItemWithObjectValue_, paramid != null ? paramid.id : 0L);
  }
  
  public void deselectItemAtIndex(long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_deselectItemAtIndex_, paramLong);
  }
  
  public long indexOfSelectedItem()
  {
    return OS.objc_msgSend(this.id, OS.sel_indexOfSelectedItem);
  }
  
  public void insertItemWithObjectValue(id paramid, long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_insertItemWithObjectValue_atIndex_, paramid != null ? paramid.id : 0L, paramLong);
  }
  
  public double itemHeight()
  {
    return OS.objc_msgSend_fpret(this.id, OS.sel_itemHeight);
  }
  
  public id itemObjectValueAtIndex(long paramLong)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_itemObjectValueAtIndex_, paramLong);
    return l != 0L ? new id(l) : null;
  }
  
  public long numberOfItems()
  {
    return OS.objc_msgSend(this.id, OS.sel_numberOfItems);
  }
  
  public long numberOfVisibleItems()
  {
    return OS.objc_msgSend(this.id, OS.sel_numberOfVisibleItems);
  }
  
  public void removeAllItems()
  {
    OS.objc_msgSend(this.id, OS.sel_removeAllItems);
  }
  
  public void removeItemAtIndex(long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_removeItemAtIndex_, paramLong);
  }
  
  public void selectItemAtIndex(long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_selectItemAtIndex_, paramLong);
  }
  
  public void setNumberOfVisibleItems(long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_setNumberOfVisibleItems_, paramLong);
  }
  
  public static long cellClass()
  {
    return OS.objc_msgSend(OS.class_NSComboBox, OS.sel_cellClass);
  }
  
  public static void setCellClass(long paramLong)
  {
    OS.objc_msgSend(OS.class_NSComboBox, OS.sel_setCellClass_, paramLong);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSComboBox.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */