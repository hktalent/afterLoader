package org.eclipse.swt.internal.cocoa;

public class NSTextContainer
  extends NSObject
{
  public NSTextContainer() {}
  
  public NSTextContainer(long paramLong)
  {
    super(paramLong);
  }
  
  public NSTextContainer(id paramid)
  {
    super(paramid);
  }
  
  public NSSize containerSize()
  {
    NSSize localNSSize = new NSSize();
    OS.objc_msgSend_stret(localNSSize, this.id, OS.sel_containerSize);
    return localNSSize;
  }
  
  public NSTextContainer initWithContainerSize(NSSize paramNSSize)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_initWithContainerSize_, paramNSSize);
    return l != 0L ? new NSTextContainer(l) : l == this.id ? this : null;
  }
  
  public void setContainerSize(NSSize paramNSSize)
  {
    OS.objc_msgSend(this.id, OS.sel_setContainerSize_, paramNSSize);
  }
  
  public void setLineFragmentPadding(double paramDouble)
  {
    OS.objc_msgSend(this.id, OS.sel_setLineFragmentPadding_, paramDouble);
  }
  
  public void setWidthTracksTextView(boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_setWidthTracksTextView_, paramBoolean);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSTextContainer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */