package org.eclipse.swt.graphics;

public class LineAttributes
{
  public float width;
  public int style;
  public int cap;
  public int join;
  public float[] dash;
  public float dashOffset;
  public float miterLimit;
  
  public LineAttributes(float paramFloat)
  {
    this(paramFloat, 1, 1, 1, null, 0.0F, 10.0F);
  }
  
  public LineAttributes(float paramFloat, int paramInt1, int paramInt2)
  {
    this(paramFloat, paramInt1, paramInt2, 1, null, 0.0F, 10.0F);
  }
  
  public LineAttributes(float paramFloat1, int paramInt1, int paramInt2, int paramInt3, float[] paramArrayOfFloat, float paramFloat2, float paramFloat3)
  {
    this.width = paramFloat1;
    this.cap = paramInt1;
    this.join = paramInt2;
    this.style = paramInt3;
    this.dash = paramArrayOfFloat;
    this.dashOffset = paramFloat2;
    this.miterLimit = paramFloat3;
  }
  
  public boolean equals(Object paramObject)
  {
    if (paramObject == this) {
      return true;
    }
    if (!(paramObject instanceof LineAttributes)) {
      return false;
    }
    LineAttributes localLineAttributes = (LineAttributes)paramObject;
    if (localLineAttributes.width != this.width) {
      return false;
    }
    if (localLineAttributes.cap != this.cap) {
      return false;
    }
    if (localLineAttributes.join != this.join) {
      return false;
    }
    if (localLineAttributes.style != this.style) {
      return false;
    }
    if (localLineAttributes.dashOffset != this.dashOffset) {
      return false;
    }
    if (localLineAttributes.miterLimit != this.miterLimit) {
      return false;
    }
    if ((localLineAttributes.dash != null) && (this.dash != null))
    {
      if (localLineAttributes.dash.length != this.dash.length) {
        return false;
      }
      for (int i = 0; i < this.dash.length; i++) {
        if (localLineAttributes.dash[i] != this.dash[i]) {
          return false;
        }
      }
    }
    else if ((localLineAttributes.dash != null) || (this.dash != null))
    {
      return false;
    }
    return true;
  }
  
  public int hashCode()
  {
    int i = Float.floatToIntBits(this.width);
    i = 31 * i + this.cap;
    i = 31 * i + this.join;
    i = 31 * i + this.style;
    i = 31 * i + Float.floatToIntBits(this.dashOffset);
    i = 31 * i + Float.floatToIntBits(this.miterLimit);
    if (this.dash != null) {
      for (int j = 0; j < this.dash.length; j++) {
        i = 31 * i + Float.floatToIntBits(this.dash[j]);
      }
    }
    return i;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/graphics/LineAttributes.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */