package org.eclipse.swt.internal.cocoa;

public class NSTouch
  extends NSObject
{
  public NSTouch() {}
  
  public NSTouch(long paramLong)
  {
    super(paramLong);
  }
  
  public NSTouch(id paramid)
  {
    super(paramid);
  }
  
  public id device()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_device);
    return l != 0L ? new id(l) : null;
  }
  
  public NSSize deviceSize()
  {
    NSSize localNSSize = new NSSize();
    OS.objc_msgSend_stret(localNSSize, this.id, OS.sel_deviceSize);
    return localNSSize;
  }
  
  public boolean isResting()
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_isResting);
  }
  
  public NSPoint normalizedPosition()
  {
    NSPoint localNSPoint = new NSPoint();
    OS.objc_msgSend_stret(localNSPoint, this.id, OS.sel_normalizedPosition);
    return localNSPoint;
  }
  
  public long phase()
  {
    return OS.objc_msgSend(this.id, OS.sel_phase);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSTouch.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */