package org.eclipse.swt.internal.cocoa;

public class NSOpenGLPixelFormat
  extends NSObject
{
  public NSOpenGLPixelFormat() {}
  
  public NSOpenGLPixelFormat(long paramLong)
  {
    super(paramLong);
  }
  
  public NSOpenGLPixelFormat(id paramid)
  {
    super(paramid);
  }
  
  public void getValues(long[] paramArrayOfLong, int paramInt1, int paramInt2)
  {
    OS.objc_msgSend(this.id, OS.sel_getValues_forAttribute_forVirtualScreen_, paramArrayOfLong, paramInt1, paramInt2);
  }
  
  public id initWithAttributes(int[] paramArrayOfInt)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_initWithAttributes_, paramArrayOfInt);
    return l != 0L ? new id(l) : null;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSOpenGLPixelFormat.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */