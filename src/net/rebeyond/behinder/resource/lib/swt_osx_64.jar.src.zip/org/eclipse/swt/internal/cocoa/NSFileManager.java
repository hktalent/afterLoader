package org.eclipse.swt.internal.cocoa;

public class NSFileManager
  extends NSObject
{
  public NSFileManager() {}
  
  public NSFileManager(long paramLong)
  {
    super(paramLong);
  }
  
  public NSFileManager(id paramid)
  {
    super(paramid);
  }
  
  public NSArray URLsForDirectory(long paramLong1, long paramLong2)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_URLsForDirectory_inDomains_, paramLong1, paramLong2);
    return l != 0L ? new NSArray(l) : null;
  }
  
  public boolean createFileAtPath(NSString paramNSString, NSData paramNSData, NSDictionary paramNSDictionary)
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_createFileAtPath_contents_attributes_, paramNSString != null ? paramNSString.id : 0L, paramNSData != null ? paramNSData.id : 0L, paramNSDictionary != null ? paramNSDictionary.id : 0L);
  }
  
  public static NSFileManager defaultManager()
  {
    long l = OS.objc_msgSend(OS.class_NSFileManager, OS.sel_defaultManager);
    return l != 0L ? new NSFileManager(l) : null;
  }
  
  public NSDirectoryEnumerator enumeratorAtPath(NSString paramNSString)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_enumeratorAtPath_, paramNSString != null ? paramNSString.id : 0L);
    return l != 0L ? new NSDirectoryEnumerator(l) : null;
  }
  
  public boolean fileExistsAtPath(NSString paramNSString)
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_fileExistsAtPath_, paramNSString != null ? paramNSString.id : 0L);
  }
  
  public boolean fileExistsAtPath(NSString paramNSString, long paramLong)
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_fileExistsAtPath_isDirectory_, paramNSString != null ? paramNSString.id : 0L, paramLong);
  }
  
  public boolean isExecutableFileAtPath(NSString paramNSString)
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_isExecutableFileAtPath_, paramNSString != null ? paramNSString.id : 0L);
  }
  
  public boolean removeItemAtPath(NSString paramNSString, long paramLong)
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_removeItemAtPath_error_, paramNSString != null ? paramNSString.id : 0L, paramLong);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSFileManager.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */