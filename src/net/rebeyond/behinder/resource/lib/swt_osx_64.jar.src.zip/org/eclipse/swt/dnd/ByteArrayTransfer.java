package org.eclipse.swt.dnd;

import org.eclipse.swt.internal.cocoa.NSData;

public abstract class ByteArrayTransfer
  extends Transfer
{
  public TransferData[] getSupportedTypes()
  {
    int[] arrayOfInt = getTypeIds();
    TransferData[] arrayOfTransferData = new TransferData[arrayOfInt.length];
    for (int i = 0; i < arrayOfInt.length; i++)
    {
      arrayOfTransferData[i] = new TransferData();
      arrayOfTransferData[i].type = arrayOfInt[i];
    }
    return arrayOfTransferData;
  }
  
  public boolean isSupportedType(TransferData paramTransferData)
  {
    if (paramTransferData == null) {
      return false;
    }
    int[] arrayOfInt = getTypeIds();
    for (int i = 0; i < arrayOfInt.length; i++) {
      if (paramTransferData.type == arrayOfInt[i]) {
        return true;
      }
    }
    return false;
  }
  
  protected void javaToNative(Object paramObject, TransferData paramTransferData)
  {
    if ((!checkByteArray(paramObject)) && (!isSupportedType(paramTransferData))) {
      DND.error(2003);
    }
    byte[] arrayOfByte = (byte[])paramObject;
    NSData localNSData = NSData.dataWithBytes(arrayOfByte, arrayOfByte.length);
    paramTransferData.data = localNSData;
  }
  
  protected Object nativeToJava(TransferData paramTransferData)
  {
    if ((!isSupportedType(paramTransferData)) || (paramTransferData.data == null)) {
      return null;
    }
    if (paramTransferData.data == null) {
      return null;
    }
    NSData localNSData = (NSData)paramTransferData.data;
    if (localNSData.length() == 0L) {
      return null;
    }
    byte[] arrayOfByte = new byte[(int)localNSData.length()];
    localNSData.getBytes(arrayOfByte);
    return arrayOfByte;
  }
  
  boolean checkByteArray(Object paramObject)
  {
    return (paramObject != null) && ((paramObject instanceof byte[])) && (((byte[])paramObject).length > 0);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/dnd/ByteArrayTransfer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */