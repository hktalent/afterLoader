package org.eclipse.swt.internal.cocoa;

public class NSImage
  extends NSObject
{
  public NSImage() {}
  
  public NSImage(long paramLong)
  {
    super(paramLong);
  }
  
  public NSImage(id paramid)
  {
    super(paramid);
  }
  
  public NSData TIFFRepresentation()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_TIFFRepresentation);
    return l != 0L ? new NSData(l) : null;
  }
  
  public void addRepresentation(NSImageRep paramNSImageRep)
  {
    OS.objc_msgSend(this.id, OS.sel_addRepresentation_, paramNSImageRep != null ? paramNSImageRep.id : 0L);
  }
  
  public NSImageRep bestRepresentationForDevice(NSDictionary paramNSDictionary)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_bestRepresentationForDevice_, paramNSDictionary != null ? paramNSDictionary.id : 0L);
    return l != 0L ? new NSImageRep(l) : null;
  }
  
  public void drawAtPoint(NSPoint paramNSPoint, NSRect paramNSRect, long paramLong, double paramDouble)
  {
    OS.objc_msgSend(this.id, OS.sel_drawAtPoint_fromRect_operation_fraction_, paramNSPoint, paramNSRect, paramLong, paramDouble);
  }
  
  public void drawInRect(NSRect paramNSRect1, NSRect paramNSRect2, long paramLong, double paramDouble)
  {
    OS.objc_msgSend(this.id, OS.sel_drawInRect_fromRect_operation_fraction_, paramNSRect1, paramNSRect2, paramLong, paramDouble);
  }
  
  public static NSImage imageNamed(NSString paramNSString)
  {
    long l = OS.objc_msgSend(OS.class_NSImage, OS.sel_imageNamed_, paramNSString != null ? paramNSString.id : 0L);
    return l != 0L ? new NSImage(l) : null;
  }
  
  public NSImage initByReferencingFile(NSString paramNSString)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_initByReferencingFile_, paramNSString != null ? paramNSString.id : 0L);
    return l != 0L ? new NSImage(l) : l == this.id ? this : null;
  }
  
  public NSImage initWithContentsOfFile(NSString paramNSString)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_initWithContentsOfFile_, paramNSString != null ? paramNSString.id : 0L);
    return l != 0L ? new NSImage(l) : l == this.id ? this : null;
  }
  
  public id initWithData(NSData paramNSData)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_initWithData_, paramNSData != null ? paramNSData.id : 0L);
    return l != 0L ? new id(l) : null;
  }
  
  public NSImage initWithIconRef(long paramLong)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_initWithIconRef_, paramLong);
    return l != 0L ? new NSImage(l) : l == this.id ? this : null;
  }
  
  public NSImage initWithSize(NSSize paramNSSize)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_initWithSize_, paramNSSize);
    return l != 0L ? new NSImage(l) : l == this.id ? this : null;
  }
  
  public void lockFocus()
  {
    OS.objc_msgSend(this.id, OS.sel_lockFocus);
  }
  
  public void removeRepresentation(NSImageRep paramNSImageRep)
  {
    OS.objc_msgSend(this.id, OS.sel_removeRepresentation_, paramNSImageRep != null ? paramNSImageRep.id : 0L);
  }
  
  public NSArray representations()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_representations);
    return l != 0L ? new NSArray(l) : null;
  }
  
  public void setCacheMode(long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_setCacheMode_, paramLong);
  }
  
  public void setScalesWhenResized(boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_setScalesWhenResized_, paramBoolean);
  }
  
  public void setSize(NSSize paramNSSize)
  {
    OS.objc_msgSend(this.id, OS.sel_setSize_, paramNSSize);
  }
  
  public NSSize size()
  {
    NSSize localNSSize = new NSSize();
    OS.objc_msgSend_stret(localNSSize, this.id, OS.sel_size);
    return localNSSize;
  }
  
  public void unlockFocus()
  {
    OS.objc_msgSend(this.id, OS.sel_unlockFocus);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSImage.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */