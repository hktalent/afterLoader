package org.eclipse.swt.internal.cocoa;

public class NSMenuItem
  extends NSObject
{
  public NSMenuItem() {}
  
  public NSMenuItem(long paramLong)
  {
    super(paramLong);
  }
  
  public NSMenuItem(id paramid)
  {
    super(paramid);
  }
  
  public long action()
  {
    return OS.objc_msgSend(this.id, OS.sel_action);
  }
  
  public NSAttributedString attributedTitle()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_attributedTitle);
    return l != 0L ? new NSAttributedString(l) : null;
  }
  
  public NSImage image()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_image);
    return l != 0L ? new NSImage(l) : null;
  }
  
  public NSMenuItem initWithTitle(NSString paramNSString1, long paramLong, NSString paramNSString2)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_initWithTitle_action_keyEquivalent_, paramNSString1 != null ? paramNSString1.id : 0L, paramLong, paramNSString2 != null ? paramNSString2.id : 0L);
    return l != 0L ? new NSMenuItem(l) : l == this.id ? this : null;
  }
  
  public boolean isHidden()
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_isHidden);
  }
  
  public boolean isSeparatorItem()
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_isSeparatorItem);
  }
  
  public NSString keyEquivalent()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_keyEquivalent);
    return l != 0L ? new NSString(l) : null;
  }
  
  public long keyEquivalentModifierMask()
  {
    return OS.objc_msgSend(this.id, OS.sel_keyEquivalentModifierMask);
  }
  
  public static NSMenuItem separatorItem()
  {
    long l = OS.objc_msgSend(OS.class_NSMenuItem, OS.sel_separatorItem);
    return l != 0L ? new NSMenuItem(l) : null;
  }
  
  public void setAction(long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_setAction_, paramLong);
  }
  
  public void setAttributedTitle(NSAttributedString paramNSAttributedString)
  {
    OS.objc_msgSend(this.id, OS.sel_setAttributedTitle_, paramNSAttributedString != null ? paramNSAttributedString.id : 0L);
  }
  
  public void setEnabled(boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_setEnabled_, paramBoolean);
  }
  
  public void setHidden(boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_setHidden_, paramBoolean);
  }
  
  public void setImage(NSImage paramNSImage)
  {
    OS.objc_msgSend(this.id, OS.sel_setImage_, paramNSImage != null ? paramNSImage.id : 0L);
  }
  
  public void setKeyEquivalent(NSString paramNSString)
  {
    OS.objc_msgSend(this.id, OS.sel_setKeyEquivalent_, paramNSString != null ? paramNSString.id : 0L);
  }
  
  public void setKeyEquivalentModifierMask(long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_setKeyEquivalentModifierMask_, paramLong);
  }
  
  public void setMenu(NSMenu paramNSMenu)
  {
    OS.objc_msgSend(this.id, OS.sel_setMenu_, paramNSMenu != null ? paramNSMenu.id : 0L);
  }
  
  public void setState(long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_setState_, paramLong);
  }
  
  public void setSubmenu(NSMenu paramNSMenu)
  {
    OS.objc_msgSend(this.id, OS.sel_setSubmenu_, paramNSMenu != null ? paramNSMenu.id : 0L);
  }
  
  public void setTag(long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_setTag_, paramLong);
  }
  
  public void setTarget(id paramid)
  {
    OS.objc_msgSend(this.id, OS.sel_setTarget_, paramid != null ? paramid.id : 0L);
  }
  
  public void setTitle(NSString paramNSString)
  {
    OS.objc_msgSend(this.id, OS.sel_setTitle_, paramNSString != null ? paramNSString.id : 0L);
  }
  
  public long state()
  {
    return OS.objc_msgSend(this.id, OS.sel_state);
  }
  
  public NSMenu submenu()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_submenu);
    return l != 0L ? new NSMenu(l) : null;
  }
  
  public long tag()
  {
    return OS.objc_msgSend(this.id, OS.sel_tag);
  }
  
  public id target()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_target);
    return l != 0L ? new id(l) : null;
  }
  
  public NSString title()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_title);
    return l != 0L ? new NSString(l) : null;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSMenuItem.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */