package org.eclipse.swt.internal.cocoa;

public class NSRunLoop
  extends NSObject
{
  public NSRunLoop() {}
  
  public NSRunLoop(long paramLong)
  {
    super(paramLong);
  }
  
  public NSRunLoop(id paramid)
  {
    super(paramid);
  }
  
  public void addTimer(NSTimer paramNSTimer, NSString paramNSString)
  {
    OS.objc_msgSend(this.id, OS.sel_addTimer_forMode_, paramNSTimer != null ? paramNSTimer.id : 0L, paramNSString != null ? paramNSString.id : 0L);
  }
  
  public static NSRunLoop currentRunLoop()
  {
    long l = OS.objc_msgSend(OS.class_NSRunLoop, OS.sel_currentRunLoop);
    return l != 0L ? new NSRunLoop(l) : null;
  }
  
  public static NSRunLoop mainRunLoop()
  {
    long l = OS.objc_msgSend(OS.class_NSRunLoop, OS.sel_mainRunLoop);
    return l != 0L ? new NSRunLoop(l) : null;
  }
  
  public boolean runMode(NSString paramNSString, NSDate paramNSDate)
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_runMode_beforeDate_, paramNSString != null ? paramNSString.id : 0L, paramNSDate != null ? paramNSDate.id : 0L);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSRunLoop.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */