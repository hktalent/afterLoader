package org.eclipse.swt.events;

import org.eclipse.swt.widgets.Event;

public final class HelpEvent
  extends TypedEvent
{
  static final long serialVersionUID = 3257001038606251315L;
  
  public HelpEvent(Event paramEvent)
  {
    super(paramEvent);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/events/HelpEvent.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */