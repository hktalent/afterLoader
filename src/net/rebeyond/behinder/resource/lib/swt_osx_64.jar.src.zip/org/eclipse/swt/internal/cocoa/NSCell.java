package org.eclipse.swt.internal.cocoa;

public class NSCell
  extends NSObject
{
  public NSCell() {}
  
  public NSCell(long paramLong)
  {
    super(paramLong);
  }
  
  public NSCell(id paramid)
  {
    super(paramid);
  }
  
  public NSAttributedString attributedStringValue()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_attributedStringValue);
    return l != 0L ? new NSAttributedString(l) : null;
  }
  
  public NSSize cellSize()
  {
    NSSize localNSSize = new NSSize();
    OS.objc_msgSend_stret(localNSSize, this.id, OS.sel_cellSize);
    return localNSSize;
  }
  
  public NSSize cellSizeForBounds(NSRect paramNSRect)
  {
    NSSize localNSSize = new NSSize();
    OS.objc_msgSend_stret(localNSSize, this.id, OS.sel_cellSizeForBounds_, paramNSRect);
    return localNSSize;
  }
  
  public long controlSize()
  {
    return OS.objc_msgSend(this.id, OS.sel_controlSize);
  }
  
  public void drawInteriorWithFrame(NSRect paramNSRect, NSView paramNSView)
  {
    OS.objc_msgSend(this.id, OS.sel_drawInteriorWithFrame_inView_, paramNSRect, paramNSView != null ? paramNSView.id : 0L);
  }
  
  public void drawWithExpansionFrame(NSRect paramNSRect, NSView paramNSView)
  {
    OS.objc_msgSend(this.id, OS.sel_drawWithExpansionFrame_inView_, paramNSRect, paramNSView != null ? paramNSView.id : 0L);
  }
  
  public NSRect drawingRectForBounds(NSRect paramNSRect)
  {
    NSRect localNSRect = new NSRect();
    OS.objc_msgSend_stret(localNSRect, this.id, OS.sel_drawingRectForBounds_, paramNSRect);
    return localNSRect;
  }
  
  public NSRect expansionFrameWithFrame(NSRect paramNSRect, NSView paramNSView)
  {
    NSRect localNSRect = new NSRect();
    OS.objc_msgSend_stret(localNSRect, this.id, OS.sel_expansionFrameWithFrame_inView_, paramNSRect, paramNSView != null ? paramNSView.id : 0L);
    return localNSRect;
  }
  
  public NSFont font()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_font);
    return l != 0L ? new NSFont(l) : null;
  }
  
  public NSColor highlightColorWithFrame(NSRect paramNSRect, NSView paramNSView)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_highlightColorWithFrame_inView_, paramNSRect, paramNSView != null ? paramNSView.id : 0L);
    return l != 0L ? new NSColor(l) : null;
  }
  
  public long hitTestForEvent(NSEvent paramNSEvent, NSRect paramNSRect, NSView paramNSView)
  {
    return OS.objc_msgSend(this.id, OS.sel_hitTestForEvent_inRect_ofView_, paramNSEvent != null ? paramNSEvent.id : 0L, paramNSRect, paramNSView != null ? paramNSView.id : 0L);
  }
  
  public NSImage image()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_image);
    return l != 0L ? new NSImage(l) : null;
  }
  
  public NSRect imageRectForBounds(NSRect paramNSRect)
  {
    NSRect localNSRect = new NSRect();
    OS.objc_msgSend_stret(localNSRect, this.id, OS.sel_imageRectForBounds_, paramNSRect);
    return localNSRect;
  }
  
  public boolean isEnabled()
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_isEnabled);
  }
  
  public boolean isHighlighted()
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_isHighlighted);
  }
  
  public long nextState()
  {
    return OS.objc_msgSend(this.id, OS.sel_nextState);
  }
  
  public void setAlignment(long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_setAlignment_, paramLong);
  }
  
  public void setAllowsMixedState(boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_setAllowsMixedState_, paramBoolean);
  }
  
  public void setAttributedStringValue(NSAttributedString paramNSAttributedString)
  {
    OS.objc_msgSend(this.id, OS.sel_setAttributedStringValue_, paramNSAttributedString != null ? paramNSAttributedString.id : 0L);
  }
  
  public void setBackgroundStyle(long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_setBackgroundStyle_, paramLong);
  }
  
  public void setBaseWritingDirection(long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_setBaseWritingDirection_, paramLong);
  }
  
  public void setControlSize(long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_setControlSize_, paramLong);
  }
  
  public void setEnabled(boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_setEnabled_, paramBoolean);
  }
  
  public void setFont(NSFont paramNSFont)
  {
    OS.objc_msgSend(this.id, OS.sel_setFont_, paramNSFont != null ? paramNSFont.id : 0L);
  }
  
  public void setFormatter(NSFormatter paramNSFormatter)
  {
    OS.objc_msgSend(this.id, OS.sel_setFormatter_, paramNSFormatter != null ? paramNSFormatter.id : 0L);
  }
  
  public void setHighlighted(boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_setHighlighted_, paramBoolean);
  }
  
  public void setImage(NSImage paramNSImage)
  {
    OS.objc_msgSend(this.id, OS.sel_setImage_, paramNSImage != null ? paramNSImage.id : 0L);
  }
  
  public void setLineBreakMode(long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_setLineBreakMode_, paramLong);
  }
  
  public void setObjectValue(id paramid)
  {
    OS.objc_msgSend(this.id, OS.sel_setObjectValue_, paramid != null ? paramid.id : 0L);
  }
  
  public void setScrollable(boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_setScrollable_, paramBoolean);
  }
  
  public void setTitle(NSString paramNSString)
  {
    OS.objc_msgSend(this.id, OS.sel_setTitle_, paramNSString != null ? paramNSString.id : 0L);
  }
  
  public void setUsesSingleLineMode(boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_setUsesSingleLineMode_, paramBoolean);
  }
  
  public void setWraps(boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_setWraps_, paramBoolean);
  }
  
  public NSString title()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_title);
    return l != 0L ? new NSString(l) : null;
  }
  
  public NSRect titleRectForBounds(NSRect paramNSRect)
  {
    NSRect localNSRect = new NSRect();
    OS.objc_msgSend_stret(localNSRect, this.id, OS.sel_titleRectForBounds_, paramNSRect);
    return localNSRect;
  }
  
  public boolean wraps()
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_wraps);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSCell.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */