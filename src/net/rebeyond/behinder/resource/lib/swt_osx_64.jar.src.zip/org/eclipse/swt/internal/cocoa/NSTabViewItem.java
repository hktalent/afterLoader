package org.eclipse.swt.internal.cocoa;

public class NSTabViewItem
  extends NSObject
{
  public NSTabViewItem() {}
  
  public NSTabViewItem(long paramLong)
  {
    super(paramLong);
  }
  
  public NSTabViewItem(id paramid)
  {
    super(paramid);
  }
  
  public void drawLabel(boolean paramBoolean, NSRect paramNSRect)
  {
    OS.objc_msgSend(this.id, OS.sel_drawLabel_inRect_, paramBoolean, paramNSRect);
  }
  
  public id initWithIdentifier(id paramid)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_initWithIdentifier_, paramid != null ? paramid.id : 0L);
    return l != 0L ? new id(l) : null;
  }
  
  public void setLabel(NSString paramNSString)
  {
    OS.objc_msgSend(this.id, OS.sel_setLabel_, paramNSString != null ? paramNSString.id : 0L);
  }
  
  public void setView(NSView paramNSView)
  {
    OS.objc_msgSend(this.id, OS.sel_setView_, paramNSView != null ? paramNSView.id : 0L);
  }
  
  public NSSize sizeOfLabel(boolean paramBoolean)
  {
    NSSize localNSSize = new NSSize();
    OS.objc_msgSend_stret(localNSSize, this.id, OS.sel_sizeOfLabel_, paramBoolean);
    return localNSSize;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSTabViewItem.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */