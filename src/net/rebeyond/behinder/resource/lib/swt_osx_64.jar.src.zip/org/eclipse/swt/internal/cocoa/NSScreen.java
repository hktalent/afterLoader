package org.eclipse.swt.internal.cocoa;

public class NSScreen
  extends NSObject
{
  public NSScreen() {}
  
  public NSScreen(long paramLong)
  {
    super(paramLong);
  }
  
  public NSScreen(id paramid)
  {
    super(paramid);
  }
  
  public double backingScaleFactor()
  {
    return OS.objc_msgSend_fpret(this.id, OS.sel_backingScaleFactor);
  }
  
  public int depth()
  {
    return (int)OS.objc_msgSend(this.id, OS.sel_depth);
  }
  
  public NSDictionary deviceDescription()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_deviceDescription);
    return l != 0L ? new NSDictionary(l) : null;
  }
  
  public NSRect frame()
  {
    NSRect localNSRect = new NSRect();
    OS.objc_msgSend_stret(localNSRect, this.id, OS.sel_frame);
    return localNSRect;
  }
  
  public static NSScreen mainScreen()
  {
    long l = OS.objc_msgSend(OS.class_NSScreen, OS.sel_mainScreen);
    return l != 0L ? new NSScreen(l) : null;
  }
  
  public static NSArray screens()
  {
    long l = OS.objc_msgSend(OS.class_NSScreen, OS.sel_screens);
    return l != 0L ? new NSArray(l) : null;
  }
  
  public double userSpaceScaleFactor()
  {
    return OS.objc_msgSend_fpret(this.id, OS.sel_userSpaceScaleFactor);
  }
  
  public NSRect visibleFrame()
  {
    NSRect localNSRect = new NSRect();
    OS.objc_msgSend_stret(localNSRect, this.id, OS.sel_visibleFrame);
    return localNSRect;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSScreen.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */