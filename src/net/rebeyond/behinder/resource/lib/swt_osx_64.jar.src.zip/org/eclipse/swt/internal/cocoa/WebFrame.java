package org.eclipse.swt.internal.cocoa;

public class WebFrame
  extends NSObject
{
  public WebFrame() {}
  
  public WebFrame(long paramLong)
  {
    super(paramLong);
  }
  
  public WebFrame(id paramid)
  {
    super(paramid);
  }
  
  public DOMDocument DOMDocument()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_DOMDocument);
    return l != 0L ? new DOMDocument(l) : null;
  }
  
  public WebDataSource dataSource()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_dataSource);
    return l != 0L ? new WebDataSource(l) : null;
  }
  
  public long globalContext()
  {
    return OS.objc_msgSend(this.id, OS.sel_globalContext);
  }
  
  public void loadHTMLString(NSString paramNSString, NSURL paramNSURL)
  {
    OS.objc_msgSend(this.id, OS.sel_loadHTMLString_baseURL_, paramNSString != null ? paramNSString.id : 0L, paramNSURL != null ? paramNSURL.id : 0L);
  }
  
  public void loadRequest(NSURLRequest paramNSURLRequest)
  {
    OS.objc_msgSend(this.id, OS.sel_loadRequest_, paramNSURLRequest != null ? paramNSURLRequest.id : 0L);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/WebFrame.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */