package org.eclipse.swt.internal.cocoa;

public class id
{
  public long id;
  
  public id() {}
  
  public id(long paramLong)
  {
    this.id = paramLong;
  }
  
  public id(id paramid)
  {
    this.id = (paramid != null ? paramid.id : 0L);
  }
  
  public int hashCode()
  {
    return (int)this.id;
  }
  
  public boolean equals(Object paramObject)
  {
    return this.id == ((id)paramObject).id;
  }
  
  public long objc_getClass()
  {
    String str = getClass().getName();
    int i = str.lastIndexOf('.');
    if (i != -1) {
      str = str.substring(i + 1);
    }
    return OS.objc_getClass(str);
  }
  
  public String toString()
  {
    return getClass().getName() + "{" + this.id + "}";
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/id.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */