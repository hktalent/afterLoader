package org.eclipse.swt.internal.cocoa;

public class NSProgressIndicator
  extends NSView
{
  public NSProgressIndicator() {}
  
  public NSProgressIndicator(long paramLong)
  {
    super(paramLong);
  }
  
  public NSProgressIndicator(id paramid)
  {
    super(paramid);
  }
  
  public long controlSize()
  {
    return OS.objc_msgSend(this.id, OS.sel_controlSize);
  }
  
  public double doubleValue()
  {
    return OS.objc_msgSend_fpret(this.id, OS.sel_doubleValue);
  }
  
  public double maxValue()
  {
    return OS.objc_msgSend_fpret(this.id, OS.sel_maxValue);
  }
  
  public double minValue()
  {
    return OS.objc_msgSend_fpret(this.id, OS.sel_minValue);
  }
  
  public void setControlSize(long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_setControlSize_, paramLong);
  }
  
  public void setDoubleValue(double paramDouble)
  {
    OS.objc_msgSend(this.id, OS.sel_setDoubleValue_, paramDouble);
  }
  
  public void setIndeterminate(boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_setIndeterminate_, paramBoolean);
  }
  
  public void setMaxValue(double paramDouble)
  {
    OS.objc_msgSend(this.id, OS.sel_setMaxValue_, paramDouble);
  }
  
  public void setMinValue(double paramDouble)
  {
    OS.objc_msgSend(this.id, OS.sel_setMinValue_, paramDouble);
  }
  
  public void setUsesThreadedAnimation(boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_setUsesThreadedAnimation_, paramBoolean);
  }
  
  public void sizeToFit()
  {
    OS.objc_msgSend(this.id, OS.sel_sizeToFit);
  }
  
  public void startAnimation(id paramid)
  {
    OS.objc_msgSend(this.id, OS.sel_startAnimation_, paramid != null ? paramid.id : 0L);
  }
  
  public void stopAnimation(id paramid)
  {
    OS.objc_msgSend(this.id, OS.sel_stopAnimation_, paramid != null ? paramid.id : 0L);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSProgressIndicator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */