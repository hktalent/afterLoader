package org.eclipse.swt.dnd;

import org.eclipse.swt.internal.cocoa.NSString;
import org.eclipse.swt.internal.cocoa.NSURL;
import org.eclipse.swt.internal.cocoa.OS;

public class URLTransfer
  extends ByteArrayTransfer
{
  static URLTransfer _instance = new URLTransfer();
  static final String URL = OS.NSURLPboardType.getString();
  static final String URL1 = OS.kUTTypeURL.getString();
  static final int URL_ID = registerType(URL);
  static final int URL_ID1 = registerType(URL1);
  
  public static URLTransfer getInstance()
  {
    return _instance;
  }
  
  public void javaToNative(Object paramObject, TransferData paramTransferData)
  {
    if ((!checkURL(paramObject)) || (!isSupportedType(paramTransferData))) {
      DND.error(2003);
    }
    String str = (String)paramObject;
    NSString localNSString1 = NSString.stringWith(str);
    NSString localNSString2 = localNSString1.stringByAddingPercentEscapesUsingEncoding(4L);
    paramTransferData.data = NSURL.URLWithString(localNSString2);
  }
  
  public Object nativeToJava(TransferData paramTransferData)
  {
    if ((!isSupportedType(paramTransferData)) || (paramTransferData.data == null)) {
      return null;
    }
    NSURL localNSURL = (NSURL)paramTransferData.data;
    NSString localNSString = localNSURL.absoluteString();
    localNSString = localNSString.stringByReplacingPercentEscapesUsingEncoding(4L);
    return localNSString.getString();
  }
  
  protected int[] getTypeIds()
  {
    if (OS.VERSION >= 4192) {
      return new int[] { URL_ID, URL_ID1 };
    }
    return new int[] { URL_ID };
  }
  
  protected String[] getTypeNames()
  {
    if (OS.VERSION >= 4192) {
      return new String[] { URL, URL1 };
    }
    return new String[] { URL };
  }
  
  boolean checkURL(Object paramObject)
  {
    return (paramObject != null) && ((paramObject instanceof String)) && (((String)paramObject).length() > 0);
  }
  
  protected boolean validate(Object paramObject)
  {
    return checkURL(paramObject);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/dnd/URLTransfer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */