package org.eclipse.swt.internal.cocoa;

public class NSPasteboard
  extends NSObject
{
  public NSPasteboard() {}
  
  public NSPasteboard(long paramLong)
  {
    super(paramLong);
  }
  
  public NSPasteboard(id paramid)
  {
    super(paramid);
  }
  
  public long addTypes(NSArray paramNSArray, id paramid)
  {
    return OS.objc_msgSend(this.id, OS.sel_addTypes_owner_, paramNSArray != null ? paramNSArray.id : 0L, paramid != null ? paramid.id : 0L);
  }
  
  public NSString availableTypeFromArray(NSArray paramNSArray)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_availableTypeFromArray_, paramNSArray != null ? paramNSArray.id : 0L);
    return l != 0L ? new NSString(l) : null;
  }
  
  public NSData dataForType(NSString paramNSString)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_dataForType_, paramNSString != null ? paramNSString.id : 0L);
    return l != 0L ? new NSData(l) : null;
  }
  
  public long declareTypes(NSArray paramNSArray, id paramid)
  {
    return OS.objc_msgSend(this.id, OS.sel_declareTypes_owner_, paramNSArray != null ? paramNSArray.id : 0L, paramid != null ? paramid.id : 0L);
  }
  
  public static NSPasteboard generalPasteboard()
  {
    long l = OS.objc_msgSend(OS.class_NSPasteboard, OS.sel_generalPasteboard);
    return l != 0L ? new NSPasteboard(l) : null;
  }
  
  public static NSPasteboard pasteboardWithName(NSString paramNSString)
  {
    long l = OS.objc_msgSend(OS.class_NSPasteboard, OS.sel_pasteboardWithName_, paramNSString != null ? paramNSString.id : 0L);
    return l != 0L ? new NSPasteboard(l) : null;
  }
  
  public id propertyListForType(NSString paramNSString)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_propertyListForType_, paramNSString != null ? paramNSString.id : 0L);
    return l != 0L ? new id(l) : null;
  }
  
  public boolean setData(NSData paramNSData, NSString paramNSString)
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_setData_forType_, paramNSData != null ? paramNSData.id : 0L, paramNSString != null ? paramNSString.id : 0L);
  }
  
  public boolean setPropertyList(id paramid, NSString paramNSString)
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_setPropertyList_forType_, paramid != null ? paramid.id : 0L, paramNSString != null ? paramNSString.id : 0L);
  }
  
  public boolean setString(NSString paramNSString1, NSString paramNSString2)
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_setString_forType_, paramNSString1 != null ? paramNSString1.id : 0L, paramNSString2 != null ? paramNSString2.id : 0L);
  }
  
  public NSString stringForType(NSString paramNSString)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_stringForType_, paramNSString != null ? paramNSString.id : 0L);
    return l != 0L ? new NSString(l) : null;
  }
  
  public NSArray types()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_types);
    return l != 0L ? new NSArray(l) : null;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSPasteboard.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */