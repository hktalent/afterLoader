package org.eclipse.swt.internal.cocoa;

public class NSImageRep
  extends NSObject
{
  public NSImageRep() {}
  
  public NSImageRep(long paramLong)
  {
    super(paramLong);
  }
  
  public NSImageRep(id paramid)
  {
    super(paramid);
  }
  
  public long bitsPerSample()
  {
    return OS.objc_msgSend(this.id, OS.sel_bitsPerSample);
  }
  
  public NSString colorSpaceName()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_colorSpaceName);
    return l != 0L ? new NSString(l) : null;
  }
  
  public boolean drawInRect(NSRect paramNSRect)
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_drawInRect_, paramNSRect);
  }
  
  public boolean hasAlpha()
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_hasAlpha);
  }
  
  public long pixelsHigh()
  {
    return OS.objc_msgSend(this.id, OS.sel_pixelsHigh);
  }
  
  public long pixelsWide()
  {
    return OS.objc_msgSend(this.id, OS.sel_pixelsWide);
  }
  
  public void setAlpha(boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_setAlpha_, paramBoolean);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSImageRep.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */