package org.eclipse.swt.internal.cocoa;

public class NSTextAttachment
  extends NSObject
{
  public NSTextAttachment() {}
  
  public NSTextAttachment(long paramLong)
  {
    super(paramLong);
  }
  
  public NSTextAttachment(id paramid)
  {
    super(paramid);
  }
  
  public NSTextAttachment initWithFileWrapper(NSFileWrapper paramNSFileWrapper)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_initWithFileWrapper_, paramNSFileWrapper != null ? paramNSFileWrapper.id : 0L);
    return l != 0L ? new NSTextAttachment(l) : l == this.id ? this : null;
  }
  
  public void setAttachmentCell(id paramid)
  {
    OS.objc_msgSend(this.id, OS.sel_setAttachmentCell_, paramid != null ? paramid.id : 0L);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSTextAttachment.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */