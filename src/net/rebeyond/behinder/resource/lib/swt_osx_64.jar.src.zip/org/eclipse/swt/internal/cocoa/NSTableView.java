package org.eclipse.swt.internal.cocoa;

public class NSTableView
  extends NSControl
{
  public NSTableView() {}
  
  public NSTableView(long paramLong)
  {
    super(paramLong);
  }
  
  public NSTableView(id paramid)
  {
    super(paramid);
  }
  
  public void addTableColumn(NSTableColumn paramNSTableColumn)
  {
    OS.objc_msgSend(this.id, OS.sel_addTableColumn_, paramNSTableColumn != null ? paramNSTableColumn.id : 0L);
  }
  
  public boolean allowsColumnReordering()
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_allowsColumnReordering);
  }
  
  public boolean canDragRowsWithIndexes(NSIndexSet paramNSIndexSet, NSPoint paramNSPoint)
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_canDragRowsWithIndexes_atPoint_, paramNSIndexSet != null ? paramNSIndexSet.id : 0L, paramNSPoint);
  }
  
  public long clickedColumn()
  {
    return OS.objc_msgSend(this.id, OS.sel_clickedColumn);
  }
  
  public long clickedRow()
  {
    return OS.objc_msgSend(this.id, OS.sel_clickedRow);
  }
  
  public long columnAtPoint(NSPoint paramNSPoint)
  {
    return OS.objc_msgSend(this.id, OS.sel_columnAtPoint_, paramNSPoint);
  }
  
  public NSIndexSet columnIndexesInRect(NSRect paramNSRect)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_columnIndexesInRect_, paramNSRect);
    return l != 0L ? new NSIndexSet(l) : null;
  }
  
  public long columnWithIdentifier(NSString paramNSString)
  {
    return OS.objc_msgSend(this.id, OS.sel_columnWithIdentifier_, paramNSString != null ? paramNSString.id : 0L);
  }
  
  public void deselectAll(id paramid)
  {
    OS.objc_msgSend(this.id, OS.sel_deselectAll_, paramid != null ? paramid.id : 0L);
  }
  
  public void deselectRow(long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_deselectRow_, paramLong);
  }
  
  public NSImage dragImageForRowsWithIndexes(NSIndexSet paramNSIndexSet, NSArray paramNSArray, NSEvent paramNSEvent, long paramLong)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_dragImageForRowsWithIndexes_tableColumns_event_offset_, paramNSIndexSet != null ? paramNSIndexSet.id : 0L, paramNSArray != null ? paramNSArray.id : 0L, paramNSEvent != null ? paramNSEvent.id : 0L, paramLong);
    return l != 0L ? new NSImage(l) : null;
  }
  
  public void drawBackgroundInClipRect(NSRect paramNSRect)
  {
    OS.objc_msgSend(this.id, OS.sel_drawBackgroundInClipRect_, paramNSRect);
  }
  
  public NSRect frameOfCellAtColumn(long paramLong1, long paramLong2)
  {
    NSRect localNSRect = new NSRect();
    OS.objc_msgSend_stret(localNSRect, this.id, OS.sel_frameOfCellAtColumn_row_, paramLong1, paramLong2);
    return localNSRect;
  }
  
  public NSTableHeaderView headerView()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_headerView);
    return l != 0L ? new NSTableHeaderView(l) : null;
  }
  
  public void highlightSelectionInClipRect(NSRect paramNSRect)
  {
    OS.objc_msgSend(this.id, OS.sel_highlightSelectionInClipRect_, paramNSRect);
  }
  
  public NSSize intercellSpacing()
  {
    NSSize localNSSize = new NSSize();
    OS.objc_msgSend_stret(localNSSize, this.id, OS.sel_intercellSpacing);
    return localNSSize;
  }
  
  public boolean isRowSelected(long paramLong)
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_isRowSelected_, paramLong);
  }
  
  public void moveColumn(long paramLong1, long paramLong2)
  {
    OS.objc_msgSend(this.id, OS.sel_moveColumn_toColumn_, paramLong1, paramLong2);
  }
  
  public void noteNumberOfRowsChanged()
  {
    OS.objc_msgSend(this.id, OS.sel_noteNumberOfRowsChanged);
  }
  
  public long numberOfColumns()
  {
    return OS.objc_msgSend(this.id, OS.sel_numberOfColumns);
  }
  
  public long numberOfRows()
  {
    return OS.objc_msgSend(this.id, OS.sel_numberOfRows);
  }
  
  public long numberOfSelectedRows()
  {
    return OS.objc_msgSend(this.id, OS.sel_numberOfSelectedRows);
  }
  
  public NSCell preparedCellAtColumn(long paramLong1, long paramLong2)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_preparedCellAtColumn_row_, paramLong1, paramLong2);
    return l != 0L ? new NSCell(l) : null;
  }
  
  public NSRect rectOfColumn(long paramLong)
  {
    NSRect localNSRect = new NSRect();
    OS.objc_msgSend_stret(localNSRect, this.id, OS.sel_rectOfColumn_, paramLong);
    return localNSRect;
  }
  
  public NSRect rectOfRow(long paramLong)
  {
    NSRect localNSRect = new NSRect();
    OS.objc_msgSend_stret(localNSRect, this.id, OS.sel_rectOfRow_, paramLong);
    return localNSRect;
  }
  
  public void reloadData()
  {
    OS.objc_msgSend(this.id, OS.sel_reloadData);
  }
  
  public void removeTableColumn(NSTableColumn paramNSTableColumn)
  {
    OS.objc_msgSend(this.id, OS.sel_removeTableColumn_, paramNSTableColumn != null ? paramNSTableColumn.id : 0L);
  }
  
  public long rowAtPoint(NSPoint paramNSPoint)
  {
    return OS.objc_msgSend(this.id, OS.sel_rowAtPoint_, paramNSPoint);
  }
  
  public double rowHeight()
  {
    return OS.objc_msgSend_fpret(this.id, OS.sel_rowHeight);
  }
  
  public NSRange rowsInRect(NSRect paramNSRect)
  {
    NSRange localNSRange = new NSRange();
    OS.objc_msgSend_stret(localNSRange, this.id, OS.sel_rowsInRect_, paramNSRect);
    return localNSRange;
  }
  
  public void scrollColumnToVisible(long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_scrollColumnToVisible_, paramLong);
  }
  
  public void scrollRowToVisible(long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_scrollRowToVisible_, paramLong);
  }
  
  public void selectAll(id paramid)
  {
    OS.objc_msgSend(this.id, OS.sel_selectAll_, paramid != null ? paramid.id : 0L);
  }
  
  public void selectRowIndexes(NSIndexSet paramNSIndexSet, boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_selectRowIndexes_byExtendingSelection_, paramNSIndexSet != null ? paramNSIndexSet.id : 0L, paramBoolean);
  }
  
  public long selectedRow()
  {
    return OS.objc_msgSend(this.id, OS.sel_selectedRow);
  }
  
  public NSIndexSet selectedRowIndexes()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_selectedRowIndexes);
    return l != 0L ? new NSIndexSet(l) : null;
  }
  
  public void setAllowsColumnReordering(boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_setAllowsColumnReordering_, paramBoolean);
  }
  
  public void setAllowsMultipleSelection(boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_setAllowsMultipleSelection_, paramBoolean);
  }
  
  public void setBackgroundColor(NSColor paramNSColor)
  {
    OS.objc_msgSend(this.id, OS.sel_setBackgroundColor_, paramNSColor != null ? paramNSColor.id : 0L);
  }
  
  public void setColumnAutoresizingStyle(long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_setColumnAutoresizingStyle_, paramLong);
  }
  
  public void setDataSource(id paramid)
  {
    OS.objc_msgSend(this.id, OS.sel_setDataSource_, paramid != null ? paramid.id : 0L);
  }
  
  public void setDelegate(id paramid)
  {
    OS.objc_msgSend(this.id, OS.sel_setDelegate_, paramid != null ? paramid.id : 0L);
  }
  
  public void setDoubleAction(long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_setDoubleAction_, paramLong);
  }
  
  public void setDropRow(long paramLong1, long paramLong2)
  {
    OS.objc_msgSend(this.id, OS.sel_setDropRow_dropOperation_, paramLong1, paramLong2);
  }
  
  public void setGridStyleMask(long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_setGridStyleMask_, paramLong);
  }
  
  public void setHeaderView(NSTableHeaderView paramNSTableHeaderView)
  {
    OS.objc_msgSend(this.id, OS.sel_setHeaderView_, paramNSTableHeaderView != null ? paramNSTableHeaderView.id : 0L);
  }
  
  public void setHighlightedTableColumn(NSTableColumn paramNSTableColumn)
  {
    OS.objc_msgSend(this.id, OS.sel_setHighlightedTableColumn_, paramNSTableColumn != null ? paramNSTableColumn.id : 0L);
  }
  
  public void setIndicatorImage(NSImage paramNSImage, NSTableColumn paramNSTableColumn)
  {
    OS.objc_msgSend(this.id, OS.sel_setIndicatorImage_inTableColumn_, paramNSImage != null ? paramNSImage.id : 0L, paramNSTableColumn != null ? paramNSTableColumn.id : 0L);
  }
  
  public void setIntercellSpacing(NSSize paramNSSize)
  {
    OS.objc_msgSend(this.id, OS.sel_setIntercellSpacing_, paramNSSize);
  }
  
  public void setRowHeight(double paramDouble)
  {
    OS.objc_msgSend(this.id, OS.sel_setRowHeight_, paramDouble);
  }
  
  public void setUsesAlternatingRowBackgroundColors(boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_setUsesAlternatingRowBackgroundColors_, paramBoolean);
  }
  
  public NSArray tableColumns()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_tableColumns);
    return l != 0L ? new NSArray(l) : null;
  }
  
  public void tile()
  {
    OS.objc_msgSend(this.id, OS.sel_tile);
  }
  
  public boolean usesAlternatingRowBackgroundColors()
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_usesAlternatingRowBackgroundColors);
  }
  
  public static long cellClass()
  {
    return OS.objc_msgSend(OS.class_NSTableView, OS.sel_cellClass);
  }
  
  public static void setCellClass(long paramLong)
  {
    OS.objc_msgSend(OS.class_NSTableView, OS.sel_setCellClass_, paramLong);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSTableView.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */