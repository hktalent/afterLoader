package org.eclipse.swt.internal.cocoa;

public class NSTrackingArea
  extends NSObject
{
  public NSTrackingArea() {}
  
  public NSTrackingArea(long paramLong)
  {
    super(paramLong);
  }
  
  public NSTrackingArea(id paramid)
  {
    super(paramid);
  }
  
  public NSTrackingArea initWithRect(NSRect paramNSRect, long paramLong, id paramid, NSDictionary paramNSDictionary)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_initWithRect_options_owner_userInfo_, paramNSRect, paramLong, paramid != null ? paramid.id : 0L, paramNSDictionary != null ? paramNSDictionary.id : 0L);
    return l != 0L ? new NSTrackingArea(l) : l == this.id ? this : null;
  }
  
  public id owner()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_owner);
    return l != 0L ? new id(l) : null;
  }
  
  public NSDictionary userInfo()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_userInfo);
    return l != 0L ? new NSDictionary(l) : null;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSTrackingArea.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */