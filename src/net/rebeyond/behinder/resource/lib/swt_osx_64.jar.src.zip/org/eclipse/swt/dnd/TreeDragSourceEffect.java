package org.eclipse.swt.dnd;

import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.internal.cocoa.NSApplication;
import org.eclipse.swt.internal.cocoa.NSEvent;
import org.eclipse.swt.internal.cocoa.NSImage;
import org.eclipse.swt.internal.cocoa.NSPoint;
import org.eclipse.swt.internal.cocoa.NSTableView;
import org.eclipse.swt.internal.cocoa.OS;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Tree;

public class TreeDragSourceEffect
  extends DragSourceEffect
{
  Image dragSourceImage = null;
  
  public TreeDragSourceEffect(Tree paramTree)
  {
    super(paramTree);
  }
  
  public void dragFinished(DragSourceEvent paramDragSourceEvent)
  {
    if (this.dragSourceImage != null) {
      this.dragSourceImage.dispose();
    }
    this.dragSourceImage = null;
  }
  
  public void dragStart(DragSourceEvent paramDragSourceEvent)
  {
    paramDragSourceEvent.image = getDragSourceImage(paramDragSourceEvent);
  }
  
  Image getDragSourceImage(DragSourceEvent paramDragSourceEvent)
  {
    if (this.dragSourceImage != null) {
      this.dragSourceImage.dispose();
    }
    this.dragSourceImage = null;
    NSPoint localNSPoint = new NSPoint();
    long l = OS.malloc(NSPoint.sizeof);
    OS.memmove(l, localNSPoint, NSPoint.sizeof);
    NSEvent localNSEvent = NSApplication.sharedApplication().currentEvent();
    NSTableView localNSTableView = (NSTableView)this.control.view;
    NSImage localNSImage = localNSTableView.dragImageForRowsWithIndexes(localNSTableView.selectedRowIndexes(), localNSTableView.tableColumns(), localNSEvent, l);
    OS.memmove(localNSPoint, l, NSPoint.sizeof);
    OS.free(l);
    Image localImage = Image.cocoa_new(this.control.getDisplay(), 0, localNSImage);
    this.dragSourceImage = localImage;
    localNSImage.retain();
    paramDragSourceEvent.offsetX = ((int)localNSPoint.x);
    paramDragSourceEvent.offsetY = ((int)localNSPoint.y);
    return localImage;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/dnd/TreeDragSourceEffect.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */