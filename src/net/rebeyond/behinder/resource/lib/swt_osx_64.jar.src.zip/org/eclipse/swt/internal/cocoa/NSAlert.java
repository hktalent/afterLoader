package org.eclipse.swt.internal.cocoa;

public class NSAlert
  extends NSObject
{
  public NSAlert() {}
  
  public NSAlert(long paramLong)
  {
    super(paramLong);
  }
  
  public NSAlert(id paramid)
  {
    super(paramid);
  }
  
  public NSButton addButtonWithTitle(NSString paramNSString)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_addButtonWithTitle_, paramNSString != null ? paramNSString.id : 0L);
    return l != 0L ? new NSButton(l) : null;
  }
  
  public void beginSheetModalForWindow(NSWindow paramNSWindow, id paramid, long paramLong1, long paramLong2)
  {
    OS.objc_msgSend(this.id, OS.sel_beginSheetModalForWindow_modalDelegate_didEndSelector_contextInfo_, paramNSWindow != null ? paramNSWindow.id : 0L, paramid != null ? paramid.id : 0L, paramLong1, paramLong2);
  }
  
  public long runModal()
  {
    return OS.objc_msgSend(this.id, OS.sel_runModal);
  }
  
  public void setAlertStyle(long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_setAlertStyle_, paramLong);
  }
  
  public void setMessageText(NSString paramNSString)
  {
    OS.objc_msgSend(this.id, OS.sel_setMessageText_, paramNSString != null ? paramNSString.id : 0L);
  }
  
  public NSPanel window()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_window);
    return l != 0L ? new NSPanel(l) : null;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSAlert.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */