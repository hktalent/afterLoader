package org.eclipse.swt.accessibility;

public class AccessibleHyperlinkAdapter
  implements AccessibleHyperlinkListener
{
  public void getAnchor(AccessibleHyperlinkEvent paramAccessibleHyperlinkEvent) {}
  
  public void getAnchorTarget(AccessibleHyperlinkEvent paramAccessibleHyperlinkEvent) {}
  
  public void getStartIndex(AccessibleHyperlinkEvent paramAccessibleHyperlinkEvent) {}
  
  public void getEndIndex(AccessibleHyperlinkEvent paramAccessibleHyperlinkEvent) {}
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/accessibility/AccessibleHyperlinkAdapter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */