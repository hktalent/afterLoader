package org.eclipse.swt.internal.cocoa;

public class NSTableHeaderView
  extends NSView
{
  public NSTableHeaderView() {}
  
  public NSTableHeaderView(long paramLong)
  {
    super(paramLong);
  }
  
  public NSTableHeaderView(id paramid)
  {
    super(paramid);
  }
  
  public long columnAtPoint(NSPoint paramNSPoint)
  {
    return OS.objc_msgSend(this.id, OS.sel_columnAtPoint_, paramNSPoint);
  }
  
  public NSRect headerRectOfColumn(long paramLong)
  {
    NSRect localNSRect = new NSRect();
    OS.objc_msgSend_stret(localNSRect, this.id, OS.sel_headerRectOfColumn_, paramLong);
    return localNSRect;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSTableHeaderView.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */