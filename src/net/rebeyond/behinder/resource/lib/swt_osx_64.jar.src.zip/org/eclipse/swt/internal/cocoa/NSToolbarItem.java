package org.eclipse.swt.internal.cocoa;

public class NSToolbarItem
  extends NSObject
{
  public NSToolbarItem() {}
  
  public NSToolbarItem(long paramLong)
  {
    super(paramLong);
  }
  
  public NSToolbarItem(id paramid)
  {
    super(paramid);
  }
  
  public NSToolbarItem initWithItemIdentifier(NSString paramNSString)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_initWithItemIdentifier_, paramNSString != null ? paramNSString.id : 0L);
    return l != 0L ? new NSToolbarItem(l) : l == this.id ? this : null;
  }
  
  public NSString itemIdentifier()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_itemIdentifier);
    return l != 0L ? new NSString(l) : null;
  }
  
  public void setAction(long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_setAction_, paramLong);
  }
  
  public void setEnabled(boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_setEnabled_, paramBoolean);
  }
  
  public void setImage(NSImage paramNSImage)
  {
    OS.objc_msgSend(this.id, OS.sel_setImage_, paramNSImage != null ? paramNSImage.id : 0L);
  }
  
  public void setLabel(NSString paramNSString)
  {
    OS.objc_msgSend(this.id, OS.sel_setLabel_, paramNSString != null ? paramNSString.id : 0L);
  }
  
  public void setMaxSize(NSSize paramNSSize)
  {
    OS.objc_msgSend(this.id, OS.sel_setMaxSize_, paramNSSize);
  }
  
  public void setMenuFormRepresentation(NSMenuItem paramNSMenuItem)
  {
    OS.objc_msgSend(this.id, OS.sel_setMenuFormRepresentation_, paramNSMenuItem != null ? paramNSMenuItem.id : 0L);
  }
  
  public void setMinSize(NSSize paramNSSize)
  {
    OS.objc_msgSend(this.id, OS.sel_setMinSize_, paramNSSize);
  }
  
  public void setPaletteLabel(NSString paramNSString)
  {
    OS.objc_msgSend(this.id, OS.sel_setPaletteLabel_, paramNSString != null ? paramNSString.id : 0L);
  }
  
  public void setTarget(id paramid)
  {
    OS.objc_msgSend(this.id, OS.sel_setTarget_, paramid != null ? paramid.id : 0L);
  }
  
  public void setToolTip(NSString paramNSString)
  {
    OS.objc_msgSend(this.id, OS.sel_setToolTip_, paramNSString != null ? paramNSString.id : 0L);
  }
  
  public void setView(NSView paramNSView)
  {
    OS.objc_msgSend(this.id, OS.sel_setView_, paramNSView != null ? paramNSView.id : 0L);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSToolbarItem.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */