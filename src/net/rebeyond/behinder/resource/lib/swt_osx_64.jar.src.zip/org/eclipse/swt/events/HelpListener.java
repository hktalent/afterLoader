package org.eclipse.swt.events;

import org.eclipse.swt.internal.SWTEventListener;

public abstract interface HelpListener
  extends SWTEventListener
{
  public abstract void helpRequested(HelpEvent paramHelpEvent);
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/events/HelpListener.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */