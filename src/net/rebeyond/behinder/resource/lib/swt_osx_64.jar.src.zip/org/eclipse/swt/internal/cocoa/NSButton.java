package org.eclipse.swt.internal.cocoa;

public class NSButton
  extends NSControl
{
  public NSButton() {}
  
  public NSButton(long paramLong)
  {
    super(paramLong);
  }
  
  public NSButton(id paramid)
  {
    super(paramid);
  }
  
  public NSAttributedString attributedTitle()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_attributedTitle);
    return l != 0L ? new NSAttributedString(l) : null;
  }
  
  public void setAllowsMixedState(boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_setAllowsMixedState_, paramBoolean);
  }
  
  public void setAttributedTitle(NSAttributedString paramNSAttributedString)
  {
    OS.objc_msgSend(this.id, OS.sel_setAttributedTitle_, paramNSAttributedString != null ? paramNSAttributedString.id : 0L);
  }
  
  public void setBezelStyle(long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_setBezelStyle_, paramLong);
  }
  
  public void setBordered(boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_setBordered_, paramBoolean);
  }
  
  public void setButtonType(long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_setButtonType_, paramLong);
  }
  
  public void setImage(NSImage paramNSImage)
  {
    OS.objc_msgSend(this.id, OS.sel_setImage_, paramNSImage != null ? paramNSImage.id : 0L);
  }
  
  public void setImagePosition(long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_setImagePosition_, paramLong);
  }
  
  public void setKeyEquivalent(NSString paramNSString)
  {
    OS.objc_msgSend(this.id, OS.sel_setKeyEquivalent_, paramNSString != null ? paramNSString.id : 0L);
  }
  
  public void setState(long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_setState_, paramLong);
  }
  
  public void setTitle(NSString paramNSString)
  {
    OS.objc_msgSend(this.id, OS.sel_setTitle_, paramNSString != null ? paramNSString.id : 0L);
  }
  
  public long state()
  {
    return OS.objc_msgSend(this.id, OS.sel_state);
  }
  
  public static long cellClass()
  {
    return OS.objc_msgSend(OS.class_NSButton, OS.sel_cellClass);
  }
  
  public static void setCellClass(long paramLong)
  {
    OS.objc_msgSend(OS.class_NSButton, OS.sel_setCellClass_, paramLong);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSButton.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */