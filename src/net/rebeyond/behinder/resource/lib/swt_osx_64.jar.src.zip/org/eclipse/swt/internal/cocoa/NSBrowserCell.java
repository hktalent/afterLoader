package org.eclipse.swt.internal.cocoa;

public class NSBrowserCell
  extends NSCell
{
  public NSBrowserCell() {}
  
  public NSBrowserCell(long paramLong)
  {
    super(paramLong);
  }
  
  public NSBrowserCell(id paramid)
  {
    super(paramid);
  }
  
  public NSColor highlightColorInView(NSView paramNSView)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_highlightColorInView_, paramNSView != null ? paramNSView.id : 0L);
    return l != 0L ? new NSColor(l) : null;
  }
  
  public void setLeaf(boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_setLeaf_, paramBoolean);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSBrowserCell.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */