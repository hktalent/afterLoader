package org.eclipse.swt.internal.cocoa;

public class NSMutableParagraphStyle
  extends NSParagraphStyle
{
  public NSMutableParagraphStyle() {}
  
  public NSMutableParagraphStyle(long paramLong)
  {
    super(paramLong);
  }
  
  public NSMutableParagraphStyle(id paramid)
  {
    super(paramid);
  }
  
  public void addTabStop(NSTextTab paramNSTextTab)
  {
    OS.objc_msgSend(this.id, OS.sel_addTabStop_, paramNSTextTab != null ? paramNSTextTab.id : 0L);
  }
  
  public void setAlignment(long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_setAlignment_, paramLong);
  }
  
  public void setBaseWritingDirection(long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_setBaseWritingDirection_, paramLong);
  }
  
  public void setDefaultTabInterval(double paramDouble)
  {
    OS.objc_msgSend(this.id, OS.sel_setDefaultTabInterval_, paramDouble);
  }
  
  public void setFirstLineHeadIndent(double paramDouble)
  {
    OS.objc_msgSend(this.id, OS.sel_setFirstLineHeadIndent_, paramDouble);
  }
  
  public void setHeadIndent(double paramDouble)
  {
    OS.objc_msgSend(this.id, OS.sel_setHeadIndent_, paramDouble);
  }
  
  public void setLineBreakMode(long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_setLineBreakMode_, paramLong);
  }
  
  public void setLineSpacing(double paramDouble)
  {
    OS.objc_msgSend(this.id, OS.sel_setLineSpacing_, paramDouble);
  }
  
  public void setTabStops(NSArray paramNSArray)
  {
    OS.objc_msgSend(this.id, OS.sel_setTabStops_, paramNSArray != null ? paramNSArray.id : 0L);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSMutableParagraphStyle.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */