package org.eclipse.swt.events;

import org.eclipse.swt.widgets.Event;

public final class TreeEvent
  extends SelectionEvent
{
  static final long serialVersionUID = 3257282548009677109L;
  
  public TreeEvent(Event paramEvent)
  {
    super(paramEvent);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/events/TreeEvent.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */