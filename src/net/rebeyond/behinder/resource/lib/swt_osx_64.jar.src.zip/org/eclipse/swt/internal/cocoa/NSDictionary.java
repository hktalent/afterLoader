package org.eclipse.swt.internal.cocoa;

public class NSDictionary
  extends NSObject
{
  public NSDictionary() {}
  
  public NSDictionary(long paramLong)
  {
    super(paramLong);
  }
  
  public NSDictionary(id paramid)
  {
    super(paramid);
  }
  
  public NSArray allKeys()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_allKeys);
    return l != 0L ? new NSArray(l) : null;
  }
  
  public long count()
  {
    return OS.objc_msgSend(this.id, OS.sel_count);
  }
  
  public static NSDictionary dictionaryWithObject(id paramid1, id paramid2)
  {
    long l = OS.objc_msgSend(OS.class_NSDictionary, OS.sel_dictionaryWithObject_forKey_, paramid1 != null ? paramid1.id : 0L, paramid2 != null ? paramid2.id : 0L);
    return l != 0L ? new NSDictionary(l) : null;
  }
  
  public NSEnumerator objectEnumerator()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_objectEnumerator);
    return l != 0L ? new NSEnumerator(l) : null;
  }
  
  public id objectForKey(id paramid)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_objectForKey_, paramid != null ? paramid.id : 0L);
    return l != 0L ? new id(l) : null;
  }
  
  public id valueForKey(NSString paramNSString)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_valueForKey_, paramNSString != null ? paramNSString.id : 0L);
    return l != 0L ? new id(l) : null;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSDictionary.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */