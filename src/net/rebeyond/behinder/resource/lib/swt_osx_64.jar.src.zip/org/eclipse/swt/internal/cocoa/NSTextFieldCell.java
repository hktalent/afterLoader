package org.eclipse.swt.internal.cocoa;

public class NSTextFieldCell
  extends NSActionCell
{
  public NSTextFieldCell() {}
  
  public NSTextFieldCell(long paramLong)
  {
    super(paramLong);
  }
  
  public NSTextFieldCell(id paramid)
  {
    super(paramid);
  }
  
  public void setPlaceholderString(NSString paramNSString)
  {
    OS.objc_msgSend(this.id, OS.sel_setPlaceholderString_, paramNSString != null ? paramNSString.id : 0L);
  }
  
  public void setTextColor(NSColor paramNSColor)
  {
    OS.objc_msgSend(this.id, OS.sel_setTextColor_, paramNSColor != null ? paramNSColor.id : 0L);
  }
  
  public NSColor textColor()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_textColor);
    return l != 0L ? new NSColor(l) : null;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSTextFieldCell.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */