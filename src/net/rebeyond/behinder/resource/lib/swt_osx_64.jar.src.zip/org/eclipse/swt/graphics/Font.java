package org.eclipse.swt.graphics;

import org.eclipse.swt.SWT;
import org.eclipse.swt.internal.cocoa.NSAutoreleasePool;
import org.eclipse.swt.internal.cocoa.NSFont;
import org.eclipse.swt.internal.cocoa.NSFontManager;
import org.eclipse.swt.internal.cocoa.NSMutableAttributedString;
import org.eclipse.swt.internal.cocoa.NSMutableDictionary;
import org.eclipse.swt.internal.cocoa.NSNumber;
import org.eclipse.swt.internal.cocoa.NSObject;
import org.eclipse.swt.internal.cocoa.NSRange;
import org.eclipse.swt.internal.cocoa.NSString;
import org.eclipse.swt.internal.cocoa.NSThread;
import org.eclipse.swt.internal.cocoa.OS;

public final class Font
  extends Resource
{
  public NSFont handle;
  public int extraTraits;
  FontMetrics metrics = null;
  static final double SYNTHETIC_BOLD = -2.5D;
  static final double SYNTHETIC_ITALIC = 0.2D;
  
  Font(Device paramDevice)
  {
    super(paramDevice);
  }
  
  public Font(Device paramDevice, FontData paramFontData)
  {
    super(paramDevice);
    if (paramFontData == null) {
      SWT.error(4);
    }
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      init(paramFontData.getName(), paramFontData.getHeightF(), paramFontData.getStyle(), paramFontData.nsName);
      init();
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  public Font(Device paramDevice, FontData[] paramArrayOfFontData)
  {
    super(paramDevice);
    if (paramArrayOfFontData == null) {
      SWT.error(4);
    }
    if (paramArrayOfFontData.length == 0) {
      SWT.error(5);
    }
    for (int i = 0; i < paramArrayOfFontData.length; i++) {
      if (paramArrayOfFontData[i] == null) {
        SWT.error(5);
      }
    }
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      FontData localFontData = paramArrayOfFontData[0];
      init(localFontData.getName(), localFontData.getHeightF(), localFontData.getStyle(), localFontData.nsName);
      init();
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  public Font(Device paramDevice, String paramString, int paramInt1, int paramInt2)
  {
    super(paramDevice);
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      init(paramString, paramInt1, paramInt2, null);
      init();
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  Font(Device paramDevice, String paramString, float paramFloat, int paramInt)
  {
    super(paramDevice);
    init(paramString, paramFloat, paramInt, null);
    init();
  }
  
  void addTraits(NSMutableAttributedString paramNSMutableAttributedString, NSRange paramNSRange)
  {
    if ((this.extraTraits & 0x2) != 0) {
      paramNSMutableAttributedString.addAttribute(OS.NSStrokeWidthAttributeName, NSNumber.numberWithDouble(-2.5D), paramNSRange);
    }
    if ((this.extraTraits & 0x1) != 0) {
      paramNSMutableAttributedString.addAttribute(OS.NSObliquenessAttributeName, NSNumber.numberWithDouble(0.2D), paramNSRange);
    }
  }
  
  void addTraits(NSMutableDictionary paramNSMutableDictionary)
  {
    if ((this.extraTraits & 0x2) != 0) {
      paramNSMutableDictionary.setObject(NSNumber.numberWithDouble(-2.5D), OS.NSStrokeWidthAttributeName);
    }
    if ((this.extraTraits & 0x1) != 0) {
      paramNSMutableDictionary.setObject(NSNumber.numberWithDouble(0.2D), OS.NSObliquenessAttributeName);
    }
  }
  
  void destroy()
  {
    this.handle.release();
    this.handle = null;
    this.metrics = null;
  }
  
  public boolean equals(Object paramObject)
  {
    if (paramObject == this) {
      return true;
    }
    if (!(paramObject instanceof Font)) {
      return false;
    }
    Font localFont = (Font)paramObject;
    return this.handle == localFont.handle;
  }
  
  public FontData[] getFontData()
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      NSString localNSString1 = this.handle.familyName();
      String str1 = localNSString1.getString();
      NSString localNSString2 = this.handle.fontName();
      String str2 = localNSString2.getString();
      NSFontManager localNSFontManager = NSFontManager.sharedFontManager();
      long l = localNSFontManager.traitsOfFont(this.handle);
      int i = 0;
      if ((l & 1L) != 0L) {
        i |= 0x2;
      }
      if ((l & 0x2) != 0L) {
        i |= 0x1;
      }
      if ((this.extraTraits & 0x1) != 0) {
        i |= 0x2;
      }
      if ((this.extraTraits & 0x2) != 0) {
        i |= 0x1;
      }
      Point localPoint1 = this.device.dpi;
      Point localPoint2 = this.device.getScreenDPI();
      FontData localFontData = new FontData(str1, (float)this.handle.pointSize() * localPoint2.y / localPoint1.y, i);
      localFontData.nsName = str2;
      FontData[] arrayOfFontData = { localFontData };
      return arrayOfFontData;
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  public static Font cocoa_new(Device paramDevice, NSFont paramNSFont)
  {
    Font localFont = new Font(paramDevice);
    localFont.handle = paramNSFont;
    return localFont;
  }
  
  public int hashCode()
  {
    return this.handle != null ? (int)this.handle.id : 0;
  }
  
  void init(String paramString1, float paramFloat, int paramInt, String paramString2)
  {
    if (paramString1 == null) {
      SWT.error(4);
    }
    if (paramFloat < 0.0F) {
      SWT.error(5);
    }
    Point localPoint1 = this.device.dpi;
    Point localPoint2 = this.device.getScreenDPI();
    float f = paramFloat * localPoint1.y / localPoint2.y;
    if (paramString2 != null)
    {
      this.handle = NSFont.fontWithName(NSString.stringWith(paramString2), f);
    }
    else
    {
      NSString localNSString = NSString.stringWith(paramString1);
      NSFont localNSFont = NSFont.fontWithName(localNSString, f);
      if (localNSFont == null) {
        localNSFont = NSFont.systemFontOfSize(f);
      }
      NSFontManager localNSFontManager = NSFontManager.sharedFontManager();
      if (localNSFont != null) {
        if ((paramInt & 0x3) == 0)
        {
          this.handle = localNSFont;
        }
        else
        {
          int i = 0;
          if ((paramInt & 0x2) != 0) {
            i |= 0x1;
          }
          if ((paramInt & 0x1) != 0) {
            i |= 0x2;
          }
          this.handle = localNSFontManager.convertFont(localNSFont, i);
          if (((paramInt & 0x2) != 0) && ((this.handle == null) || ((localNSFontManager.traitsOfFont(this.handle) & 1L) == 0L)))
          {
            i &= 0xFFFFFFFE;
            this.handle = null;
            if ((paramInt & 0x1) != 0) {
              this.handle = localNSFontManager.convertFont(localNSFont, i);
            }
          }
          if (((paramInt & 0x1) != 0) && (this.handle == null))
          {
            i &= 0xFFFFFFFD;
            if ((paramInt & 0x2) != 0)
            {
              i |= 0x1;
              this.handle = localNSFontManager.convertFont(localNSFont, i);
            }
          }
          if (this.handle == null) {
            this.handle = localNSFont;
          }
        }
      }
      if (this.handle == null) {
        this.handle = NSFont.systemFontOfSize(f);
      }
      if (((paramInt & 0x2) != 0) && ((localNSFontManager.traitsOfFont(this.handle) & 1L) == 0L)) {
        this.extraTraits |= 0x1;
      }
      if (((paramInt & 0x1) != 0) && ((localNSFontManager.traitsOfFont(this.handle) & 0x2) == 0L)) {
        this.extraTraits |= 0x2;
      }
    }
    if (this.handle == null) {
      this.handle = this.device.systemFont.handle;
    }
    this.handle.retain();
  }
  
  public boolean isDisposed()
  {
    return this.handle == null;
  }
  
  public String toString()
  {
    if (isDisposed()) {
      return "Font {*DISPOSED*}";
    }
    return "Font {" + this.handle + "}";
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/graphics/Font.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */