package org.eclipse.swt.graphics;

import java.io.PrintStream;
import org.eclipse.swt.SWT;
import org.eclipse.swt.internal.Compatibility;
import org.eclipse.swt.internal.cocoa.NSArray;
import org.eclipse.swt.internal.cocoa.NSAutoreleasePool;
import org.eclipse.swt.internal.cocoa.NSDictionary;
import org.eclipse.swt.internal.cocoa.NSFont;
import org.eclipse.swt.internal.cocoa.NSFontManager;
import org.eclipse.swt.internal.cocoa.NSMutableDictionary;
import org.eclipse.swt.internal.cocoa.NSMutableParagraphStyle;
import org.eclipse.swt.internal.cocoa.NSNumber;
import org.eclipse.swt.internal.cocoa.NSObject;
import org.eclipse.swt.internal.cocoa.NSRect;
import org.eclipse.swt.internal.cocoa.NSScreen;
import org.eclipse.swt.internal.cocoa.NSSize;
import org.eclipse.swt.internal.cocoa.NSString;
import org.eclipse.swt.internal.cocoa.NSThread;
import org.eclipse.swt.internal.cocoa.NSValue;
import org.eclipse.swt.internal.cocoa.OS;
import org.eclipse.swt.internal.cocoa.id;

public abstract class Device
  implements Drawable
{
  public static boolean DEBUG;
  boolean debug = DEBUG;
  boolean tracking = DEBUG;
  Error[] errors;
  Object[] objects;
  Object trackingLock;
  boolean disposed;
  boolean warnings;
  Color COLOR_BLACK;
  Color COLOR_DARK_RED;
  Color COLOR_DARK_GREEN;
  Color COLOR_DARK_YELLOW;
  Color COLOR_DARK_BLUE;
  Color COLOR_DARK_MAGENTA;
  Color COLOR_DARK_CYAN;
  Color COLOR_GRAY;
  Color COLOR_DARK_GRAY;
  Color COLOR_RED;
  Color COLOR_GREEN;
  Color COLOR_YELLOW;
  Color COLOR_BLUE;
  Color COLOR_MAGENTA;
  Color COLOR_CYAN;
  Color COLOR_WHITE;
  Font systemFont;
  NSMutableParagraphStyle paragraphStyle;
  Point dpi;
  protected static Device CurrentDevice;
  protected static Runnable DeviceFinder;
  
  static synchronized Device getDevice()
  {
    if (DeviceFinder != null) {
      DeviceFinder.run();
    }
    Device localDevice = CurrentDevice;
    CurrentDevice = null;
    return localDevice;
  }
  
  public Device()
  {
    this(null);
  }
  
  public Device(DeviceData paramDeviceData)
  {
    synchronized (Device.class)
    {
      if (paramDeviceData != null)
      {
        this.debug = paramDeviceData.debug;
        this.tracking = paramDeviceData.tracking;
      }
      if (this.tracking)
      {
        this.errors = new Error[''];
        this.objects = new Object[''];
        this.trackingLock = new Object();
      }
      if (NSThread.isMainThread())
      {
        NSAutoreleasePool localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
        NSThread localNSThread = NSThread.currentThread();
        NSMutableDictionary localNSMutableDictionary = localNSThread.threadDictionary();
        NSString localNSString = NSString.stringWith("SWT_NSAutoreleasePool");
        id localid = localNSMutableDictionary.objectForKey(localNSString);
        if (localid == null)
        {
          NSNumber localNSNumber = NSNumber.numberWithInteger(localNSAutoreleasePool.id);
          localNSMutableDictionary.setObject(localNSNumber, localNSString);
        }
        else
        {
          localNSAutoreleasePool.release();
        }
      }
      create(paramDeviceData);
      init();
    }
  }
  
  protected void checkDevice()
  {
    if (this.disposed) {
      SWT.error(45);
    }
  }
  
  protected void create(DeviceData paramDeviceData) {}
  
  public void dispose()
  {
    synchronized (Device.class)
    {
      if (isDisposed()) {
        return;
      }
      checkDevice();
      release();
      destroy();
      this.disposed = true;
      if (this.tracking) {
        synchronized (this.trackingLock)
        {
          printErrors();
          this.objects = null;
          this.errors = null;
          this.trackingLock = null;
        }
      }
    }
  }
  
  void dispose_Object(Object paramObject)
  {
    synchronized (this.trackingLock)
    {
      for (int i = 0; i < this.objects.length; i++) {
        if (this.objects[i] == paramObject)
        {
          this.objects[i] = null;
          this.errors[i] = null;
          return;
        }
      }
    }
  }
  
  protected void destroy() {}
  
  public Rectangle getBounds()
  {
    checkDevice();
    NSScreen localNSScreen = getPrimaryScreen();
    NSRect localNSRect = localNSScreen.frame();
    double d = localNSScreen.userSpaceScaleFactor();
    localNSRect.x /= d;
    localNSRect.y /= d;
    localNSRect.width /= d;
    localNSRect.height /= d;
    return new Rectangle((int)localNSRect.x, (int)localNSRect.y, (int)localNSRect.width, (int)localNSRect.height);
  }
  
  public DeviceData getDeviceData()
  {
    checkDevice();
    DeviceData localDeviceData = new DeviceData();
    localDeviceData.debug = this.debug;
    localDeviceData.tracking = this.tracking;
    if (this.tracking)
    {
      synchronized (this.trackingLock)
      {
        int i = 0;
        int j = this.objects.length;
        for (int k = 0; k < j; k++) {
          if (this.objects[k] != null) {
            i++;
          }
        }
        k = 0;
        localDeviceData.objects = new Object[i];
        localDeviceData.errors = new Error[i];
        for (int m = 0; m < j; m++) {
          if (this.objects[m] != null)
          {
            localDeviceData.objects[k] = this.objects[m];
            localDeviceData.errors[k] = this.errors[m];
            k++;
          }
        }
      }
    }
    else
    {
      localDeviceData.objects = new Object[0];
      localDeviceData.errors = new Error[0];
    }
    return localDeviceData;
  }
  
  public Rectangle getClientArea()
  {
    checkDevice();
    return getBounds();
  }
  
  public int getDepth()
  {
    checkDevice();
    return (int)OS.NSBitsPerPixelFromDepth(getPrimaryScreen().depth());
  }
  
  public Point getDPI()
  {
    checkDevice();
    return getScreenDPI();
  }
  
  NSScreen getPrimaryScreen()
  {
    NSArray localNSArray = NSScreen.screens();
    return new NSScreen(localNSArray.objectAtIndex(0L));
  }
  
  public FontData[] getFontList(String paramString, boolean paramBoolean)
  {
    checkDevice();
    if (!paramBoolean) {
      return new FontData[0];
    }
    int i = 0;
    NSArray localNSArray1 = NSFontManager.sharedFontManager().availableFontFamilies();
    Object localObject = new FontData[100];
    if (localNSArray1 != null)
    {
      long l1 = localNSArray1.count();
      for (int j = 0; j < l1; j++)
      {
        NSString localNSString = new NSString(localNSArray1.objectAtIndex(j));
        String str1 = localNSString.getString();
        NSArray localNSArray2 = NSFontManager.sharedFontManager().availableMembersOfFontFamily(localNSString);
        if (localNSArray2 != null)
        {
          int k = (int)localNSArray2.count();
          for (int m = 0; m < k; m++)
          {
            NSArray localNSArray3 = new NSArray(localNSArray2.objectAtIndex(m));
            String str2 = new NSString(localNSArray3.objectAtIndex(0L)).getString();
            long l2 = new NSNumber(localNSArray3.objectAtIndex(2L)).integerValue();
            long l3 = new NSNumber(localNSArray3.objectAtIndex(3L)).integerValue();
            int n = 0;
            if ((l3 & 1L) != 0L) {
              n |= 0x2;
            }
            if (l2 == 9L) {
              n |= 0x1;
            }
            if ((paramString == null) || (Compatibility.equalsIgnoreCase(paramString, str1)))
            {
              FontData localFontData = new FontData(str1, 0, n);
              localFontData.nsName = str2;
              if (i == localObject.length)
              {
                FontData[] arrayOfFontData2 = new FontData[localObject.length + 100];
                System.arraycopy(localObject, 0, arrayOfFontData2, 0, localObject.length);
                localObject = arrayOfFontData2;
              }
              localObject[(i++)] = localFontData;
            }
          }
        }
      }
    }
    if (i == localObject.length) {
      return (FontData[])localObject;
    }
    FontData[] arrayOfFontData1 = new FontData[i];
    System.arraycopy(localObject, 0, arrayOfFontData1, 0, i);
    return arrayOfFontData1;
  }
  
  Point getScreenDPI()
  {
    NSScreen localNSScreen = getPrimaryScreen();
    NSDictionary localNSDictionary = localNSScreen.deviceDescription();
    NSValue localNSValue = new NSValue(localNSDictionary.objectForKey(new id(OS.NSDeviceResolution())).id);
    NSSize localNSSize = localNSValue.sizeValue();
    double d = 1.0D;
    if (OS.VERSION >= 4208) {
      d = localNSScreen.backingScaleFactor();
    }
    return new Point((int)(localNSSize.width / d), (int)(localNSSize.height / d));
  }
  
  public Color getSystemColor(int paramInt)
  {
    checkDevice();
    switch (paramInt)
    {
    case 2: 
      return this.COLOR_BLACK;
    case 4: 
      return this.COLOR_DARK_RED;
    case 6: 
      return this.COLOR_DARK_GREEN;
    case 8: 
      return this.COLOR_DARK_YELLOW;
    case 10: 
      return this.COLOR_DARK_BLUE;
    case 12: 
      return this.COLOR_DARK_MAGENTA;
    case 14: 
      return this.COLOR_DARK_CYAN;
    case 15: 
      return this.COLOR_GRAY;
    case 16: 
      return this.COLOR_DARK_GRAY;
    case 3: 
      return this.COLOR_RED;
    case 5: 
      return this.COLOR_GREEN;
    case 7: 
      return this.COLOR_YELLOW;
    case 9: 
      return this.COLOR_BLUE;
    case 11: 
      return this.COLOR_MAGENTA;
    case 13: 
      return this.COLOR_CYAN;
    case 1: 
      return this.COLOR_WHITE;
    }
    return this.COLOR_BLACK;
  }
  
  public Font getSystemFont()
  {
    checkDevice();
    return this.systemFont;
  }
  
  public boolean getWarnings()
  {
    checkDevice();
    return this.warnings;
  }
  
  protected void init()
  {
    this.COLOR_BLACK = new Color(this, 0, 0, 0);
    this.COLOR_DARK_RED = new Color(this, 128, 0, 0);
    this.COLOR_DARK_GREEN = new Color(this, 0, 128, 0);
    this.COLOR_DARK_YELLOW = new Color(this, 128, 128, 0);
    this.COLOR_DARK_BLUE = new Color(this, 0, 0, 128);
    this.COLOR_DARK_MAGENTA = new Color(this, 128, 0, 128);
    this.COLOR_DARK_CYAN = new Color(this, 0, 128, 128);
    this.COLOR_GRAY = new Color(this, 192, 192, 192);
    this.COLOR_DARK_GRAY = new Color(this, 128, 128, 128);
    this.COLOR_RED = new Color(this, 255, 0, 0);
    this.COLOR_GREEN = new Color(this, 0, 255, 0);
    this.COLOR_YELLOW = new Color(this, 255, 255, 0);
    this.COLOR_BLUE = new Color(this, 0, 0, 255);
    this.COLOR_MAGENTA = new Color(this, 255, 0, 255);
    this.COLOR_CYAN = new Color(this, 0, 255, 255);
    this.COLOR_WHITE = new Color(this, 255, 255, 255);
    this.paragraphStyle = ((NSMutableParagraphStyle)new NSMutableParagraphStyle().alloc().init());
    this.paragraphStyle.setAlignment(0L);
    this.paragraphStyle.setLineBreakMode(2L);
    NSArray localNSArray = new NSArray(new NSArray().alloc().init());
    this.paragraphStyle.setTabStops(localNSArray);
    localNSArray.release();
    int i = System.getProperty("org.eclipse.swt.internal.carbon.smallFonts") != null ? 1 : 0;
    double d = i != 0 ? NSFont.smallSystemFontSize() : NSFont.systemFontSize();
    Point localPoint1 = this.dpi = getDPI();
    Point localPoint2 = getScreenDPI();
    NSFont localNSFont = NSFont.systemFontOfSize(d * localPoint1.y / localPoint2.y);
    localNSFont.retain();
    this.systemFont = Font.cocoa_new(this, localNSFont);
  }
  
  public abstract long internal_new_GC(GCData paramGCData);
  
  public abstract void internal_dispose_GC(long paramLong, GCData paramGCData);
  
  /* Error */
  public boolean isDisposed()
  {
    // Byte code:
    //   0: ldc_w 9
    //   3: dup
    //   4: astore_1
    //   5: monitorenter
    //   6: aload_0
    //   7: getfield 33	org/eclipse/swt/graphics/Device:disposed	Z
    //   10: aload_1
    //   11: monitorexit
    //   12: ireturn
    //   13: astore_2
    //   14: aload_1
    //   15: monitorexit
    //   16: aload_2
    //   17: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	18	0	this	Device
    //   4	11	1	Ljava/lang/Object;	Object
    //   13	4	2	localObject1	Object
    // Exception table:
    //   from	to	target	type
    //   6	12	13	finally
    //   13	16	13	finally
  }
  
  public boolean loadFont(String paramString)
  {
    checkDevice();
    if (paramString == null) {
      SWT.error(4);
    }
    boolean bool = false;
    NSString localNSString = NSString.stringWith(paramString);
    long l = localNSString.fileSystemRepresentation();
    if (l != 0L)
    {
      byte[] arrayOfByte = new byte[80];
      boolean[] arrayOfBoolean = new boolean[1];
      if (OS.FSPathMakeRef(l, arrayOfByte, arrayOfBoolean) == 0) {
        bool = OS.ATSFontActivateFromFileReference(arrayOfByte, 2, 0, 0L, 0, null) == 0;
      }
    }
    return bool;
  }
  
  void new_Object(Object paramObject)
  {
    synchronized (this.trackingLock)
    {
      for (int i = 0; i < this.objects.length; i++) {
        if (this.objects[i] == null)
        {
          this.objects[i] = paramObject;
          this.errors[i] = new Error();
          return;
        }
      }
      Object[] arrayOfObject = new Object[this.objects.length + 128];
      System.arraycopy(this.objects, 0, arrayOfObject, 0, this.objects.length);
      arrayOfObject[this.objects.length] = paramObject;
      this.objects = arrayOfObject;
      Error[] arrayOfError = new Error[this.errors.length + 128];
      System.arraycopy(this.errors, 0, arrayOfError, 0, this.errors.length);
      arrayOfError[this.errors.length] = new Error();
      this.errors = arrayOfError;
    }
  }
  
  void printErrors()
  {
    if (!DEBUG) {
      return;
    }
    if (this.tracking) {
      synchronized (this.trackingLock)
      {
        if ((this.objects == null) || (this.errors == null)) {
          return;
        }
        int i = 0;
        int j = 0;
        int k = 0;
        int m = 0;
        int n = 0;
        int i1 = 0;
        int i2 = 0;
        int i3 = 0;
        int i4 = 0;
        int i5 = 0;
        int i6 = 0;
        for (int i7 = 0; i7 < this.objects.length; i7++)
        {
          Object localObject1 = this.objects[i7];
          if (localObject1 != null)
          {
            i++;
            if ((localObject1 instanceof Color)) {
              j++;
            }
            if ((localObject1 instanceof Cursor)) {
              k++;
            }
            if ((localObject1 instanceof Font)) {
              m++;
            }
            if ((localObject1 instanceof GC)) {
              n++;
            }
            if ((localObject1 instanceof Image)) {
              i1++;
            }
            if ((localObject1 instanceof Path)) {
              i2++;
            }
            if ((localObject1 instanceof Pattern)) {
              i3++;
            }
            if ((localObject1 instanceof Region)) {
              i4++;
            }
            if ((localObject1 instanceof TextLayout)) {
              i5++;
            }
            if ((localObject1 instanceof Transform)) {
              i6++;
            }
          }
        }
        if (i != 0)
        {
          String str = "Summary: ";
          if (j != 0) {
            str = str + j + " Color(s), ";
          }
          if (k != 0) {
            str = str + k + " Cursor(s), ";
          }
          if (m != 0) {
            str = str + m + " Font(s), ";
          }
          if (n != 0) {
            str = str + n + " GC(s), ";
          }
          if (i1 != 0) {
            str = str + i1 + " Image(s), ";
          }
          if (i2 != 0) {
            str = str + i2 + " Path(s), ";
          }
          if (i3 != 0) {
            str = str + i3 + " Pattern(s), ";
          }
          if (i4 != 0) {
            str = str + i4 + " Region(s), ";
          }
          if (i5 != 0) {
            str = str + i5 + " TextLayout(s), ";
          }
          if (i6 != 0) {
            str = str + i6 + " Transforms(s), ";
          }
          if (str.length() != 0)
          {
            str = str.substring(0, str.length() - 2);
            System.out.println(str);
          }
          for (int i8 = 0; i8 < this.errors.length; i8++) {
            if (this.errors[i8] != null) {
              this.errors[i8].printStackTrace(System.out);
            }
          }
        }
      }
    }
  }
  
  protected void release()
  {
    if (this.paragraphStyle != null) {
      this.paragraphStyle.release();
    }
    this.paragraphStyle = null;
    if (this.systemFont != null) {
      this.systemFont.dispose();
    }
    this.systemFont = null;
    if (this.COLOR_BLACK != null) {
      this.COLOR_BLACK.dispose();
    }
    if (this.COLOR_DARK_RED != null) {
      this.COLOR_DARK_RED.dispose();
    }
    if (this.COLOR_DARK_GREEN != null) {
      this.COLOR_DARK_GREEN.dispose();
    }
    if (this.COLOR_DARK_YELLOW != null) {
      this.COLOR_DARK_YELLOW.dispose();
    }
    if (this.COLOR_DARK_BLUE != null) {
      this.COLOR_DARK_BLUE.dispose();
    }
    if (this.COLOR_DARK_MAGENTA != null) {
      this.COLOR_DARK_MAGENTA.dispose();
    }
    if (this.COLOR_DARK_CYAN != null) {
      this.COLOR_DARK_CYAN.dispose();
    }
    if (this.COLOR_GRAY != null) {
      this.COLOR_GRAY.dispose();
    }
    if (this.COLOR_DARK_GRAY != null) {
      this.COLOR_DARK_GRAY.dispose();
    }
    if (this.COLOR_RED != null) {
      this.COLOR_RED.dispose();
    }
    if (this.COLOR_GREEN != null) {
      this.COLOR_GREEN.dispose();
    }
    if (this.COLOR_YELLOW != null) {
      this.COLOR_YELLOW.dispose();
    }
    if (this.COLOR_BLUE != null) {
      this.COLOR_BLUE.dispose();
    }
    if (this.COLOR_MAGENTA != null) {
      this.COLOR_MAGENTA.dispose();
    }
    if (this.COLOR_CYAN != null) {
      this.COLOR_CYAN.dispose();
    }
    if (this.COLOR_WHITE != null) {
      this.COLOR_WHITE.dispose();
    }
    this.COLOR_BLACK = (this.COLOR_DARK_RED = this.COLOR_DARK_GREEN = this.COLOR_DARK_YELLOW = this.COLOR_DARK_BLUE = this.COLOR_DARK_MAGENTA = this.COLOR_DARK_CYAN = this.COLOR_GRAY = this.COLOR_DARK_GRAY = this.COLOR_RED = this.COLOR_GREEN = this.COLOR_YELLOW = this.COLOR_BLUE = this.COLOR_MAGENTA = this.COLOR_CYAN = this.COLOR_WHITE = null);
  }
  
  public void setWarnings(boolean paramBoolean)
  {
    checkDevice();
    this.warnings = paramBoolean;
  }
  
  static
  {
    try
    {
      Class.forName("org.eclipse.swt.widgets.Display");
    }
    catch (ClassNotFoundException localClassNotFoundException) {}
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/graphics/Device.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */