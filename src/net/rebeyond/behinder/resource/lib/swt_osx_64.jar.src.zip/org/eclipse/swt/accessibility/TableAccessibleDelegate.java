package org.eclipse.swt.accessibility;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Vector;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.internal.cocoa.NSNumber;
import org.eclipse.swt.internal.cocoa.NSPoint;
import org.eclipse.swt.internal.cocoa.NSSize;
import org.eclipse.swt.internal.cocoa.NSValue;
import org.eclipse.swt.internal.cocoa.id;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Monitor;

class TableAccessibleDelegate
{
  Map childColumnToIdMap = new HashMap();
  Map childRowToIdMap = new HashMap();
  Accessible tableAccessible;
  AccessibleTableHeader headerAccessible;
  
  public TableAccessibleDelegate(Accessible paramAccessible)
  {
    this.tableAccessible = paramAccessible;
    this.tableAccessible.addAccessibleControlListener(new AccessibleControlAdapter()
    {
      public void getChildCount(AccessibleControlEvent paramAnonymousAccessibleControlEvent)
      {
        paramAnonymousAccessibleControlEvent.detail = (TableAccessibleDelegate.this.childColumnToIdMap.size() + TableAccessibleDelegate.this.childRowToIdMap.size());
        if (TableAccessibleDelegate.this.childColumnToIdMap.size() > 1) {
          paramAnonymousAccessibleControlEvent.detail += 1;
        }
      }
      
      public void getChildren(AccessibleControlEvent paramAnonymousAccessibleControlEvent)
      {
        int i = TableAccessibleDelegate.this.childColumnToIdMap.size() + TableAccessibleDelegate.this.childRowToIdMap.size();
        if (TableAccessibleDelegate.this.childColumnToIdMap.size() > 1) {
          i++;
        }
        Accessible[] arrayOfAccessible = new Accessible[i];
        int j = 0;
        Iterator localIterator = TableAccessibleDelegate.this.childRowToIdMap.values().iterator();
        Object localObject;
        while (localIterator.hasNext())
        {
          localObject = (AccessibleTableRow)localIterator.next();
          arrayOfAccessible[(j++)] = localObject;
        }
        localIterator = TableAccessibleDelegate.this.childColumnToIdMap.values().iterator();
        while (localIterator.hasNext())
        {
          localObject = (AccessibleTableColumn)localIterator.next();
          arrayOfAccessible[(j++)] = localObject;
        }
        if (TableAccessibleDelegate.this.childColumnToIdMap.size() > 1) {
          arrayOfAccessible[j] = TableAccessibleDelegate.this.headerAccessible();
        }
        paramAnonymousAccessibleControlEvent.children = arrayOfAccessible;
      }
      
      public void getChildAtPoint(AccessibleControlEvent paramAnonymousAccessibleControlEvent)
      {
        NSPoint localNSPoint1 = new NSPoint();
        localNSPoint1.x = paramAnonymousAccessibleControlEvent.x;
        Monitor localMonitor = Display.getCurrent().getPrimaryMonitor();
        localNSPoint1.y = (localMonitor.getBounds().height - paramAnonymousAccessibleControlEvent.y);
        Iterator localIterator = TableAccessibleDelegate.this.childRowToIdMap.values().iterator();
        while (localIterator.hasNext())
        {
          AccessibleTableRow localAccessibleTableRow = (AccessibleTableRow)localIterator.next();
          NSValue localNSValue1 = new NSValue(localAccessibleTableRow.getPositionAttribute(-1).id);
          NSPoint localNSPoint2 = localNSValue1.pointValue();
          NSValue localNSValue2 = new NSValue(localAccessibleTableRow.getSizeAttribute(-1));
          NSSize localNSSize = localNSValue2.sizeValue();
          if ((localNSPoint2.y < localNSPoint1.y) && (localNSPoint1.y < localNSPoint2.y + localNSSize.height))
          {
            AccessibleControlEvent localAccessibleControlEvent = new AccessibleControlEvent(paramAnonymousAccessibleControlEvent.getSource());
            localAccessibleControlEvent.x = ((int)localNSPoint1.x);
            localAccessibleControlEvent.y = ((int)localNSPoint1.y);
            localAccessibleTableRow.getChildAtPoint(paramAnonymousAccessibleControlEvent);
            break;
          }
        }
      }
      
      public void getState(AccessibleControlEvent paramAnonymousAccessibleControlEvent)
      {
        int i = 3145728;
        AccessibleTableEvent localAccessibleTableEvent = new AccessibleTableEvent(this);
        for (int j = 0; j < TableAccessibleDelegate.this.tableAccessible.accessibleTableListeners.size(); j++)
        {
          AccessibleTableListener localAccessibleTableListener = (AccessibleTableListener)TableAccessibleDelegate.this.tableAccessible.accessibleTableListeners.elementAt(j);
          localAccessibleTableListener.getSelectedRows(localAccessibleTableEvent);
        }
        if (localAccessibleTableEvent.selected != null)
        {
          localObject = (int[])localAccessibleTableEvent.selected;
          for (int k = 0; k < localObject.length; k++) {
            if (localObject[k] == TableAccessibleDelegate.this.tableAccessible.index)
            {
              i |= 0x2;
              break;
            }
          }
        }
        Object localObject = (NSNumber)TableAccessibleDelegate.this.tableAccessible.getFocusedAttribute(-1);
        if (((NSNumber)localObject).boolValue()) {
          i |= 0x4;
        }
        paramAnonymousAccessibleControlEvent.detail = i;
      }
    });
    this.tableAccessible.addAccessibleTableListener(new AccessibleTableAdapter()
    {
      public void getColumnCount(AccessibleTableEvent paramAnonymousAccessibleTableEvent)
      {
        AccessibleTableEvent localAccessibleTableEvent = new AccessibleTableEvent(this);
        for (int i = 0; i < TableAccessibleDelegate.this.tableAccessible.accessibleTableListeners.size(); i++)
        {
          AccessibleTableListener localAccessibleTableListener = (AccessibleTableListener)TableAccessibleDelegate.this.tableAccessible.accessibleTableListeners.elementAt(i);
          if (localAccessibleTableListener != this) {
            localAccessibleTableListener.getColumnCount(localAccessibleTableEvent);
          }
        }
        paramAnonymousAccessibleTableEvent.count = localAccessibleTableEvent.count;
      }
      
      public void getColumn(AccessibleTableEvent paramAnonymousAccessibleTableEvent)
      {
        AccessibleTableEvent localAccessibleTableEvent = new AccessibleTableEvent(this);
        getColumns(localAccessibleTableEvent);
        paramAnonymousAccessibleTableEvent.accessible = localAccessibleTableEvent.accessibles[paramAnonymousAccessibleTableEvent.column];
      }
      
      public void getColumns(AccessibleTableEvent paramAnonymousAccessibleTableEvent)
      {
        AccessibleTableEvent localAccessibleTableEvent = new AccessibleTableEvent(this);
        getColumnCount(localAccessibleTableEvent);
        if (localAccessibleTableEvent.count != TableAccessibleDelegate.this.childColumnToIdMap.size()) {
          TableAccessibleDelegate.this.childColumnToIdMap.clear();
        }
        Accessible[] arrayOfAccessible1 = new Accessible[localAccessibleTableEvent.count];
        for (int i = 0; i < localAccessibleTableEvent.count; i++) {
          arrayOfAccessible1[i] = TableAccessibleDelegate.this.childColumnToOs(i);
        }
        i = TableAccessibleDelegate.this.childColumnToIdMap.size() > 0 ? TableAccessibleDelegate.this.childColumnToIdMap.size() : 1;
        Accessible[] arrayOfAccessible2 = new Accessible[i];
        for (int j = 0; j < i; j++) {
          arrayOfAccessible2[j] = ((Accessible)TableAccessibleDelegate.this.childColumnToIdMap.get(new Integer(j)));
        }
        paramAnonymousAccessibleTableEvent.accessibles = arrayOfAccessible2;
      }
      
      public void getColumnHeader(AccessibleTableEvent paramAnonymousAccessibleTableEvent)
      {
        paramAnonymousAccessibleTableEvent.accessible = (TableAccessibleDelegate.this.childColumnToIdMap.size() > 1 ? TableAccessibleDelegate.this.headerAccessible() : null);
      }
      
      public void getRowCount(AccessibleTableEvent paramAnonymousAccessibleTableEvent)
      {
        AccessibleTableEvent localAccessibleTableEvent = new AccessibleTableEvent(this);
        for (int i = 0; i < TableAccessibleDelegate.this.tableAccessible.accessibleTableListeners.size(); i++)
        {
          AccessibleTableListener localAccessibleTableListener = (AccessibleTableListener)TableAccessibleDelegate.this.tableAccessible.accessibleTableListeners.elementAt(i);
          if (localAccessibleTableListener != this) {
            localAccessibleTableListener.getRowCount(localAccessibleTableEvent);
          }
        }
        paramAnonymousAccessibleTableEvent.count = localAccessibleTableEvent.count;
      }
      
      public void getRow(AccessibleTableEvent paramAnonymousAccessibleTableEvent)
      {
        AccessibleTableEvent localAccessibleTableEvent = new AccessibleTableEvent(this);
        getRows(localAccessibleTableEvent);
        paramAnonymousAccessibleTableEvent.accessible = localAccessibleTableEvent.accessibles[paramAnonymousAccessibleTableEvent.row];
      }
      
      public void getRows(AccessibleTableEvent paramAnonymousAccessibleTableEvent)
      {
        AccessibleTableEvent localAccessibleTableEvent = new AccessibleTableEvent(this);
        getRowCount(localAccessibleTableEvent);
        if (localAccessibleTableEvent.count != TableAccessibleDelegate.this.childRowToIdMap.size()) {
          TableAccessibleDelegate.this.childRowToIdMap.clear();
        }
        Accessible[] arrayOfAccessible1 = new Accessible[localAccessibleTableEvent.count];
        for (int i = 0; i < localAccessibleTableEvent.count; i++) {
          arrayOfAccessible1[i] = TableAccessibleDelegate.this.childRowToOs(i);
        }
        i = TableAccessibleDelegate.this.childRowToIdMap.size() > 0 ? TableAccessibleDelegate.this.childRowToIdMap.size() : 1;
        Accessible[] arrayOfAccessible2 = new Accessible[i];
        for (int j = 0; j < i; j++) {
          arrayOfAccessible2[j] = ((Accessible)TableAccessibleDelegate.this.childRowToIdMap.get(new Integer(j)));
        }
        paramAnonymousAccessibleTableEvent.accessibles = arrayOfAccessible2;
      }
    });
  }
  
  Accessible childColumnToOs(int paramInt)
  {
    if (paramInt == -1) {
      return this.tableAccessible;
    }
    AccessibleTableColumn localAccessibleTableColumn = (AccessibleTableColumn)this.childColumnToIdMap.get(new Integer(paramInt));
    if (localAccessibleTableColumn == null)
    {
      localAccessibleTableColumn = new AccessibleTableColumn(this.tableAccessible, paramInt);
      this.childColumnToIdMap.put(new Integer(paramInt), localAccessibleTableColumn);
    }
    return localAccessibleTableColumn;
  }
  
  Accessible childRowToOs(int paramInt)
  {
    if (paramInt == -1) {
      return this.tableAccessible;
    }
    AccessibleTableRow localAccessibleTableRow = (AccessibleTableRow)this.childRowToIdMap.get(new Integer(paramInt));
    if (localAccessibleTableRow == null)
    {
      localAccessibleTableRow = new AccessibleTableRow(this.tableAccessible, paramInt);
      this.childRowToIdMap.put(new Integer(paramInt), localAccessibleTableRow);
    }
    return localAccessibleTableRow;
  }
  
  AccessibleTableHeader headerAccessible()
  {
    if (this.headerAccessible == null) {
      this.headerAccessible = new AccessibleTableHeader(this.tableAccessible, -1);
    }
    return this.headerAccessible;
  }
  
  void release()
  {
    Collection localCollection;
    Iterator localIterator;
    SWTAccessibleDelegate localSWTAccessibleDelegate;
    if (this.childRowToIdMap != null)
    {
      localCollection = this.childRowToIdMap.values();
      localIterator = localCollection.iterator();
      while (localIterator.hasNext())
      {
        localSWTAccessibleDelegate = ((Accessible)localIterator.next()).delegate;
        if (localSWTAccessibleDelegate != null)
        {
          localSWTAccessibleDelegate.internal_dispose_SWTAccessibleDelegate();
          localSWTAccessibleDelegate.release();
        }
      }
      this.childRowToIdMap.clear();
      this.childRowToIdMap = null;
    }
    if (this.childColumnToIdMap != null)
    {
      localCollection = this.childColumnToIdMap.values();
      localIterator = localCollection.iterator();
      while (localIterator.hasNext())
      {
        localSWTAccessibleDelegate = ((Accessible)localIterator.next()).delegate;
        if (localSWTAccessibleDelegate != null)
        {
          localSWTAccessibleDelegate.internal_dispose_SWTAccessibleDelegate();
          localSWTAccessibleDelegate.release();
        }
      }
      this.childColumnToIdMap.clear();
      this.childColumnToIdMap = null;
    }
  }
  
  void reset()
  {
    release();
    this.childColumnToIdMap = new HashMap();
    this.childRowToIdMap = new HashMap();
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/accessibility/TableAccessibleDelegate.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */