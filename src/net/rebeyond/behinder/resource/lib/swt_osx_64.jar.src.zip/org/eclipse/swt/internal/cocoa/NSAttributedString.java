package org.eclipse.swt.internal.cocoa;

public class NSAttributedString
  extends NSObject
{
  public NSAttributedString() {}
  
  public NSAttributedString(long paramLong)
  {
    super(paramLong);
  }
  
  public NSAttributedString(id paramid)
  {
    super(paramid);
  }
  
  public static NSAttributedString attributedStringWithAttachment(NSTextAttachment paramNSTextAttachment)
  {
    long l = OS.objc_msgSend(OS.class_NSAttributedString, OS.sel_attributedStringWithAttachment_, paramNSTextAttachment != null ? paramNSTextAttachment.id : 0L);
    return l != 0L ? new NSAttributedString(l) : null;
  }
  
  public NSRect boundingRectWithSize(NSSize paramNSSize, long paramLong)
  {
    NSRect localNSRect = new NSRect();
    OS.objc_msgSend_stret(localNSRect, this.id, OS.sel_boundingRectWithSize_options_, paramNSSize, paramLong);
    return localNSRect;
  }
  
  public NSRange doubleClickAtIndex(long paramLong)
  {
    NSRange localNSRange = new NSRange();
    OS.objc_msgSend_stret(localNSRange, this.id, OS.sel_doubleClickAtIndex_, paramLong);
    return localNSRange;
  }
  
  public void drawAtPoint(NSPoint paramNSPoint)
  {
    OS.objc_msgSend(this.id, OS.sel_drawAtPoint_, paramNSPoint);
  }
  
  public void drawInRect(NSRect paramNSRect)
  {
    OS.objc_msgSend(this.id, OS.sel_drawInRect_, paramNSRect);
  }
  
  public long nextWordFromIndex(long paramLong, boolean paramBoolean)
  {
    return OS.objc_msgSend(this.id, OS.sel_nextWordFromIndex_forward_, paramLong, paramBoolean);
  }
  
  public NSSize size()
  {
    NSSize localNSSize = new NSSize();
    OS.objc_msgSend_stret(localNSSize, this.id, OS.sel_size);
    return localNSSize;
  }
  
  public id attribute(NSString paramNSString, long paramLong1, long paramLong2)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_attribute_atIndex_effectiveRange_, paramNSString != null ? paramNSString.id : 0L, paramLong1, paramLong2);
    return l != 0L ? new id(l) : null;
  }
  
  public NSAttributedString attributedSubstringFromRange(NSRange paramNSRange)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_attributedSubstringFromRange_, paramNSRange);
    return l != 0L ? new NSAttributedString(l) : l == this.id ? this : null;
  }
  
  public NSDictionary attributesAtIndex(long paramLong1, long paramLong2, NSRange paramNSRange)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_attributesAtIndex_longestEffectiveRange_inRange_, paramLong1, paramLong2, paramNSRange);
    return l != 0L ? new NSDictionary(l) : null;
  }
  
  public NSAttributedString initWithString(NSString paramNSString)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_initWithString_, paramNSString != null ? paramNSString.id : 0L);
    return l != 0L ? new NSAttributedString(l) : l == this.id ? this : null;
  }
  
  public NSAttributedString initWithString(NSString paramNSString, NSDictionary paramNSDictionary)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_initWithString_attributes_, paramNSString != null ? paramNSString.id : 0L, paramNSDictionary != null ? paramNSDictionary.id : 0L);
    return l != 0L ? new NSAttributedString(l) : l == this.id ? this : null;
  }
  
  public long length()
  {
    return OS.objc_msgSend(this.id, OS.sel_length);
  }
  
  public NSString string()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_string);
    return l != 0L ? new NSString(l) : null;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSAttributedString.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */