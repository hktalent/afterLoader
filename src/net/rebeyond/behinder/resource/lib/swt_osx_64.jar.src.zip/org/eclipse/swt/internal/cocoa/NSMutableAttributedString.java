package org.eclipse.swt.internal.cocoa;

public class NSMutableAttributedString
  extends NSAttributedString
{
  public NSMutableAttributedString() {}
  
  public NSMutableAttributedString(long paramLong)
  {
    super(paramLong);
  }
  
  public NSMutableAttributedString(id paramid)
  {
    super(paramid);
  }
  
  public void setBaseWritingDirection(long paramLong, NSRange paramNSRange)
  {
    OS.objc_msgSend(this.id, OS.sel_setBaseWritingDirection_range_, paramLong, paramNSRange);
  }
  
  public void addAttribute(NSString paramNSString, id paramid, NSRange paramNSRange)
  {
    OS.objc_msgSend(this.id, OS.sel_addAttribute_value_range_, paramNSString != null ? paramNSString.id : 0L, paramid != null ? paramid.id : 0L, paramNSRange);
  }
  
  public void appendAttributedString(NSAttributedString paramNSAttributedString)
  {
    OS.objc_msgSend(this.id, OS.sel_appendAttributedString_, paramNSAttributedString != null ? paramNSAttributedString.id : 0L);
  }
  
  public void beginEditing()
  {
    OS.objc_msgSend(this.id, OS.sel_beginEditing);
  }
  
  public void endEditing()
  {
    OS.objc_msgSend(this.id, OS.sel_endEditing);
  }
  
  public NSMutableString mutableString()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_mutableString);
    return l != 0L ? new NSMutableString(l) : null;
  }
  
  public void removeAttribute(NSString paramNSString, NSRange paramNSRange)
  {
    OS.objc_msgSend(this.id, OS.sel_removeAttribute_range_, paramNSString != null ? paramNSString.id : 0L, paramNSRange);
  }
  
  public void replaceCharactersInRange(NSRange paramNSRange, NSString paramNSString)
  {
    OS.objc_msgSend(this.id, OS.sel_replaceCharactersInRange_withString_, paramNSRange, paramNSString != null ? paramNSString.id : 0L);
  }
  
  public void setAttributedString(NSAttributedString paramNSAttributedString)
  {
    OS.objc_msgSend(this.id, OS.sel_setAttributedString_, paramNSAttributedString != null ? paramNSAttributedString.id : 0L);
  }
  
  public static NSAttributedString attributedStringWithAttachment(NSTextAttachment paramNSTextAttachment)
  {
    long l = OS.objc_msgSend(OS.class_NSMutableAttributedString, OS.sel_attributedStringWithAttachment_, paramNSTextAttachment != null ? paramNSTextAttachment.id : 0L);
    return l != 0L ? new NSAttributedString(l) : null;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSMutableAttributedString.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */