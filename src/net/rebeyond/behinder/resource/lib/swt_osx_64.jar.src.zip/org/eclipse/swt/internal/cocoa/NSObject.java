package org.eclipse.swt.internal.cocoa;

public class NSObject
  extends id
{
  public NSObject() {}
  
  public NSObject(long paramLong)
  {
    super(paramLong);
  }
  
  public NSObject(id paramid)
  {
    super(paramid);
  }
  
  public NSObject alloc()
  {
    this.id = OS.objc_msgSend(objc_getClass(), OS.sel_alloc);
    return this;
  }
  
  public id accessibilityAttributeValue(NSString paramNSString, id paramid)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_accessibilityAttributeValue_forParameter_, paramNSString != null ? paramNSString.id : 0L, paramid != null ? paramid.id : 0L);
    return l != 0L ? new id(l) : null;
  }
  
  public boolean accessibilitySetOverrideValue(id paramid, NSString paramNSString)
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_accessibilitySetOverrideValue_forAttribute_, paramid != null ? paramid.id : 0L, paramNSString != null ? paramNSString.id : 0L);
  }
  
  public void draggedImage(NSImage paramNSImage, NSPoint paramNSPoint, long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_draggedImage_endedAt_operation_, paramNSImage != null ? paramNSImage.id : 0L, paramNSPoint, paramLong);
  }
  
  public NSWindow draggingDestinationWindow()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_draggingDestinationWindow);
    return l != 0L ? new NSWindow(l) : null;
  }
  
  public NSPoint draggingLocation()
  {
    NSPoint localNSPoint = new NSPoint();
    OS.objc_msgSend_stret(localNSPoint, this.id, OS.sel_draggingLocation);
    return localNSPoint;
  }
  
  public NSPasteboard draggingPasteboard()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_draggingPasteboard);
    return l != 0L ? new NSPasteboard(l) : null;
  }
  
  public long draggingSourceOperationMask()
  {
    return OS.objc_msgSend(this.id, OS.sel_draggingSourceOperationMask);
  }
  
  public boolean outlineView(NSOutlineView paramNSOutlineView, NSTableColumn paramNSTableColumn, id paramid)
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_outlineView_shouldEditTableColumn_item_, paramNSOutlineView != null ? paramNSOutlineView.id : 0L, paramNSTableColumn != null ? paramNSTableColumn.id : 0L, paramid != null ? paramid.id : 0L);
  }
  
  public boolean outlineView(NSOutlineView paramNSOutlineView, long paramLong1, long paramLong2)
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_outlineView_shouldReorderColumn_toColumn_, paramNSOutlineView != null ? paramNSOutlineView.id : 0L, paramLong1, paramLong2);
  }
  
  public boolean outlineView(NSOutlineView paramNSOutlineView, id paramid)
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_outlineView_shouldSelectItem_, paramNSOutlineView != null ? paramNSOutlineView.id : 0L, paramid != null ? paramid.id : 0L);
  }
  
  public boolean outlineView(NSOutlineView paramNSOutlineView, NSCell paramNSCell, NSTableColumn paramNSTableColumn, id paramid)
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_outlineView_shouldTrackCell_forTableColumn_item_, paramNSOutlineView != null ? paramNSOutlineView.id : 0L, paramNSCell != null ? paramNSCell.id : 0L, paramNSTableColumn != null ? paramNSTableColumn.id : 0L, paramid != null ? paramid.id : 0L);
  }
  
  public boolean readSelectionFromPasteboard(NSPasteboard paramNSPasteboard)
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_readSelectionFromPasteboard_, paramNSPasteboard != null ? paramNSPasteboard.id : 0L);
  }
  
  public boolean tableView(NSTableView paramNSTableView, long paramLong1, long paramLong2)
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_tableView_shouldReorderColumn_toColumn_, paramNSTableView != null ? paramNSTableView.id : 0L, paramLong1, paramLong2);
  }
  
  public boolean tableView(NSTableView paramNSTableView, long paramLong)
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_tableView_shouldSelectRow_, paramNSTableView != null ? paramNSTableView.id : 0L, paramLong);
  }
  
  public boolean tableView(NSTableView paramNSTableView, NSCell paramNSCell, NSTableColumn paramNSTableColumn, long paramLong)
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_tableView_shouldTrackCell_forTableColumn_row_, paramNSTableView != null ? paramNSTableView.id : 0L, paramNSCell != null ? paramNSCell.id : 0L, paramNSTableColumn != null ? paramNSTableColumn.id : 0L, paramLong);
  }
  
  public boolean writeSelectionToPasteboard(NSPasteboard paramNSPasteboard, NSArray paramNSArray)
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_writeSelectionToPasteboard_types_, paramNSPasteboard != null ? paramNSPasteboard.id : 0L, paramNSArray != null ? paramNSArray.id : 0L);
  }
  
  public NSObject autorelease()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_autorelease);
    return l != 0L ? new NSObject(l) : l == this.id ? this : null;
  }
  
  public void cancelAuthenticationChallenge(NSURLAuthenticationChallenge paramNSURLAuthenticationChallenge)
  {
    OS.objc_msgSend(this.id, OS.sel_cancelAuthenticationChallenge_, paramNSURLAuthenticationChallenge != null ? paramNSURLAuthenticationChallenge.id : 0L);
  }
  
  public NSString className()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_className);
    return l != 0L ? new NSString(l) : null;
  }
  
  public boolean conformsToProtocol(Protocol paramProtocol)
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_conformsToProtocol_, paramProtocol != null ? paramProtocol.id : 0L);
  }
  
  public id copy()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_copy);
    return l != 0L ? new id(l) : null;
  }
  
  public void dealloc()
  {
    OS.objc_msgSend(this.id, OS.sel_dealloc);
  }
  
  public NSString description()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_description);
    return l != 0L ? new NSString(l) : null;
  }
  
  public NSObject init()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_init);
    return l != 0L ? new NSObject(l) : l == this.id ? this : null;
  }
  
  public boolean isEqual(id paramid)
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_isEqual_, paramid != null ? paramid.id : 0L);
  }
  
  public boolean isEqualTo(id paramid)
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_isEqualTo_, paramid != null ? paramid.id : 0L);
  }
  
  public boolean isKindOfClass(long paramLong)
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_isKindOfClass_, paramLong);
  }
  
  public id mutableCopy()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_mutableCopy);
    return l != 0L ? new id(l) : null;
  }
  
  public void performSelector(long paramLong, id paramid, double paramDouble, NSArray paramNSArray)
  {
    OS.objc_msgSend(this.id, OS.sel_performSelector_withObject_afterDelay_inModes_, paramLong, paramid != null ? paramid.id : 0L, paramDouble, paramNSArray != null ? paramNSArray.id : 0L);
  }
  
  public void performSelectorOnMainThread(long paramLong, id paramid, boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_performSelectorOnMainThread_withObject_waitUntilDone_, paramLong, paramid != null ? paramid.id : 0L, paramBoolean);
  }
  
  public void release()
  {
    OS.objc_msgSend(this.id, OS.sel_release);
  }
  
  public boolean respondsToSelector(long paramLong)
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_respondsToSelector_, paramLong);
  }
  
  public id retain()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_retain);
    return l != 0L ? new id(l) : null;
  }
  
  public long retainCount()
  {
    return OS.objc_msgSend(this.id, OS.sel_retainCount);
  }
  
  public void setValue(id paramid, NSString paramNSString)
  {
    OS.objc_msgSend(this.id, OS.sel_setValue_forKey_, paramid != null ? paramid.id : 0L, paramNSString != null ? paramNSString.id : 0L);
  }
  
  public long superclass()
  {
    return OS.objc_msgSend(this.id, OS.sel_superclass);
  }
  
  public void useCredential(NSURLCredential paramNSURLCredential, NSURLAuthenticationChallenge paramNSURLAuthenticationChallenge)
  {
    OS.objc_msgSend(this.id, OS.sel_useCredential_forAuthenticationChallenge_, paramNSURLCredential != null ? paramNSURLCredential.id : 0L, paramNSURLAuthenticationChallenge != null ? paramNSURLAuthenticationChallenge.id : 0L);
  }
  
  public id valueForKey(NSString paramNSString)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_valueForKey_, paramNSString != null ? paramNSString.id : 0L);
    return l != 0L ? new id(l) : null;
  }
  
  public void addEventListener(NSString paramNSString, id paramid, boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_addEventListener_listener_useCapture_, paramNSString != null ? paramNSString.id : 0L, paramid != null ? paramid.id : 0L, paramBoolean);
  }
  
  public void handleEvent(DOMEvent paramDOMEvent)
  {
    OS.objc_msgSend(this.id, OS.sel_handleEvent_, paramDOMEvent != null ? paramDOMEvent.id : 0L);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSObject.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */