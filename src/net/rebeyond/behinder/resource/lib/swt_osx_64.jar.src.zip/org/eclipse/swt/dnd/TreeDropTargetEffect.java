package org.eclipse.swt.dnd;

import org.eclipse.swt.internal.cocoa.NSView;
import org.eclipse.swt.internal.cocoa.OS;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Tree;

public class TreeDropTargetEffect
  extends DropTargetEffect
{
  boolean shouldEnableScrolling;
  
  public TreeDropTargetEffect(Tree paramTree)
  {
    super(paramTree);
  }
  
  int checkEffect(int paramInt)
  {
    if ((paramInt & 0x1) != 0) {
      paramInt = paramInt & 0xFFFFFFFB & 0xFFFFFFFD;
    }
    if ((paramInt & 0x2) != 0) {
      paramInt &= 0xFFFFFFFB;
    }
    return paramInt;
  }
  
  public void dragEnter(DropTargetEvent paramDropTargetEvent) {}
  
  public void dragLeave(DropTargetEvent paramDropTargetEvent)
  {
    OS.objc_msgSend(this.control.view.id, OS.sel_setShouldExpandItem_, 1);
    if (this.shouldEnableScrolling)
    {
      this.shouldEnableScrolling = false;
      OS.objc_msgSend(this.control.view.id, OS.sel_setShouldScrollClipView_, 1);
      this.control.redraw();
    }
  }
  
  public void dragOver(DropTargetEvent paramDropTargetEvent)
  {
    int i = checkEffect(paramDropTargetEvent.feedback);
    ((DropTarget)paramDropTargetEvent.widget).feedback = i;
    OS.objc_msgSend(this.control.view.id, OS.sel_setShouldExpandItem_, (i & 0x10) == 0 ? 0 : 1);
    if ((i & 0x8) == 0)
    {
      this.shouldEnableScrolling = true;
      OS.objc_msgSend(this.control.view.id, OS.sel_setShouldScrollClipView_, 0);
    }
    else
    {
      OS.objc_msgSend(this.control.view.id, OS.sel_setShouldScrollClipView_, 1);
    }
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/dnd/TreeDropTargetEffect.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */