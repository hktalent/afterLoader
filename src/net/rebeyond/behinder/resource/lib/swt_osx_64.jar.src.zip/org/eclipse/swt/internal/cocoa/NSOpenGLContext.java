package org.eclipse.swt.internal.cocoa;

public class NSOpenGLContext
  extends NSObject
{
  public NSOpenGLContext() {}
  
  public NSOpenGLContext(long paramLong)
  {
    super(paramLong);
  }
  
  public NSOpenGLContext(id paramid)
  {
    super(paramid);
  }
  
  public static void clearCurrentContext()
  {
    OS.objc_msgSend(OS.class_NSOpenGLContext, OS.sel_clearCurrentContext);
  }
  
  public void clearDrawable()
  {
    OS.objc_msgSend(this.id, OS.sel_clearDrawable);
  }
  
  public static NSOpenGLContext currentContext()
  {
    long l = OS.objc_msgSend(OS.class_NSOpenGLContext, OS.sel_currentContext);
    return l != 0L ? new NSOpenGLContext(l) : null;
  }
  
  public void flushBuffer()
  {
    OS.objc_msgSend(this.id, OS.sel_flushBuffer);
  }
  
  public NSOpenGLContext initWithFormat(NSOpenGLPixelFormat paramNSOpenGLPixelFormat, NSOpenGLContext paramNSOpenGLContext)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_initWithFormat_shareContext_, paramNSOpenGLPixelFormat != null ? paramNSOpenGLPixelFormat.id : 0L, paramNSOpenGLContext != null ? paramNSOpenGLContext.id : 0L);
    return l != 0L ? new NSOpenGLContext(l) : l == this.id ? this : null;
  }
  
  public void makeCurrentContext()
  {
    OS.objc_msgSend(this.id, OS.sel_makeCurrentContext);
  }
  
  public void setValues(int[] paramArrayOfInt, int paramInt)
  {
    OS.objc_msgSend(this.id, OS.sel_setValues_forParameter_, paramArrayOfInt, paramInt);
  }
  
  public void setView(NSView paramNSView)
  {
    OS.objc_msgSend(this.id, OS.sel_setView_, paramNSView != null ? paramNSView.id : 0L);
  }
  
  public void update()
  {
    OS.objc_msgSend(this.id, OS.sel_update);
  }
  
  public NSView view()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_view);
    return l != 0L ? new NSView(l) : null;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSOpenGLContext.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */