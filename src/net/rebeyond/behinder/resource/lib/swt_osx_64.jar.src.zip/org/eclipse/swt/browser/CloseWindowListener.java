package org.eclipse.swt.browser;

import org.eclipse.swt.internal.SWTEventListener;

public abstract interface CloseWindowListener
  extends SWTEventListener
{
  public abstract void close(WindowEvent paramWindowEvent);
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/browser/CloseWindowListener.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */