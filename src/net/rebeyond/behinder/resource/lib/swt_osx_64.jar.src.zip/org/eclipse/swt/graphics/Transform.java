package org.eclipse.swt.graphics;

import org.eclipse.swt.SWT;
import org.eclipse.swt.internal.cocoa.NSAffineTransform;
import org.eclipse.swt.internal.cocoa.NSAffineTransformStruct;
import org.eclipse.swt.internal.cocoa.NSAutoreleasePool;
import org.eclipse.swt.internal.cocoa.NSObject;
import org.eclipse.swt.internal.cocoa.NSPoint;
import org.eclipse.swt.internal.cocoa.NSThread;

public class Transform
  extends Resource
{
  public NSAffineTransform handle;
  
  public Transform(Device paramDevice)
  {
    this(paramDevice, 1.0F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F);
  }
  
  public Transform(Device paramDevice, float[] paramArrayOfFloat)
  {
    this(paramDevice, checkTransform(paramArrayOfFloat)[0], paramArrayOfFloat[1], paramArrayOfFloat[2], paramArrayOfFloat[3], paramArrayOfFloat[4], paramArrayOfFloat[5]);
  }
  
  public Transform(Device paramDevice, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6)
  {
    super(paramDevice);
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      this.handle = NSAffineTransform.transform();
      if (this.handle == null) {
        SWT.error(2);
      }
      this.handle.retain();
      setElements(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6);
      init();
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  static float[] checkTransform(float[] paramArrayOfFloat)
  {
    if (paramArrayOfFloat == null) {
      SWT.error(4);
    }
    if (paramArrayOfFloat.length < 6) {
      SWT.error(5);
    }
    return paramArrayOfFloat;
  }
  
  void destroy()
  {
    this.handle.release();
    this.handle = null;
  }
  
  public void getElements(float[] paramArrayOfFloat)
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    if (paramArrayOfFloat == null) {
      SWT.error(4);
    }
    if (paramArrayOfFloat.length < 6) {
      SWT.error(5);
    }
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      NSAffineTransformStruct localNSAffineTransformStruct = this.handle.transformStruct();
      paramArrayOfFloat[0] = ((float)localNSAffineTransformStruct.m11);
      paramArrayOfFloat[1] = ((float)localNSAffineTransformStruct.m12);
      paramArrayOfFloat[2] = ((float)localNSAffineTransformStruct.m21);
      paramArrayOfFloat[3] = ((float)localNSAffineTransformStruct.m22);
      paramArrayOfFloat[4] = ((float)localNSAffineTransformStruct.tX);
      paramArrayOfFloat[5] = ((float)localNSAffineTransformStruct.tY);
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  public void identity()
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      NSAffineTransformStruct localNSAffineTransformStruct = new NSAffineTransformStruct();
      localNSAffineTransformStruct.m11 = 1.0D;
      localNSAffineTransformStruct.m22 = 1.0D;
      this.handle.setTransformStruct(localNSAffineTransformStruct);
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  public void invert()
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      NSAffineTransformStruct localNSAffineTransformStruct = this.handle.transformStruct();
      if (localNSAffineTransformStruct.m11 * localNSAffineTransformStruct.m22 - localNSAffineTransformStruct.m12 * localNSAffineTransformStruct.m21 == 0.0D) {
        SWT.error(10);
      }
      this.handle.invert();
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  public boolean isDisposed()
  {
    return this.handle == null;
  }
  
  public boolean isIdentity()
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      NSAffineTransformStruct localNSAffineTransformStruct = this.handle.transformStruct();
      boolean bool = (localNSAffineTransformStruct.m11 == 1.0D) && (localNSAffineTransformStruct.m12 == 0.0D) && (localNSAffineTransformStruct.m21 == 0.0D) && (localNSAffineTransformStruct.m22 == 1.0D) && (localNSAffineTransformStruct.tX == 0.0D) && (localNSAffineTransformStruct.tY == 0.0D);
      return bool;
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  public void multiply(Transform paramTransform)
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    if (paramTransform == null) {
      SWT.error(4);
    }
    if (paramTransform.isDisposed()) {
      SWT.error(5);
    }
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      this.handle.prependTransform(paramTransform.handle);
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  public void rotate(float paramFloat)
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      this.handle.rotateByDegrees(paramFloat);
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  public void scale(float paramFloat1, float paramFloat2)
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      this.handle.scaleXBy(paramFloat1, paramFloat2);
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  public void setElements(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6)
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      NSAffineTransformStruct localNSAffineTransformStruct = new NSAffineTransformStruct();
      localNSAffineTransformStruct.m11 = paramFloat1;
      localNSAffineTransformStruct.m12 = paramFloat2;
      localNSAffineTransformStruct.m21 = paramFloat3;
      localNSAffineTransformStruct.m22 = paramFloat4;
      localNSAffineTransformStruct.tX = paramFloat5;
      localNSAffineTransformStruct.tY = paramFloat6;
      this.handle.setTransformStruct(localNSAffineTransformStruct);
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  public void shear(float paramFloat1, float paramFloat2)
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      NSAffineTransformStruct localNSAffineTransformStruct = new NSAffineTransformStruct();
      localNSAffineTransformStruct.m11 = 1.0D;
      localNSAffineTransformStruct.m12 = paramFloat1;
      localNSAffineTransformStruct.m21 = paramFloat2;
      localNSAffineTransformStruct.m22 = 1.0D;
      NSAffineTransform localNSAffineTransform = NSAffineTransform.transform();
      localNSAffineTransform.setTransformStruct(localNSAffineTransformStruct);
      this.handle.prependTransform(localNSAffineTransform);
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  public void transform(float[] paramArrayOfFloat)
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    if (paramArrayOfFloat == null) {
      SWT.error(4);
    }
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      NSPoint localNSPoint = new NSPoint();
      int i = paramArrayOfFloat.length / 2;
      int j = 0;
      for (int k = 0; j < i; k += 2)
      {
        localNSPoint.x = paramArrayOfFloat[k];
        localNSPoint.y = paramArrayOfFloat[(k + 1)];
        localNSPoint = this.handle.transformPoint(localNSPoint);
        paramArrayOfFloat[k] = ((float)localNSPoint.x);
        paramArrayOfFloat[(k + 1)] = ((float)localNSPoint.y);
        j++;
      }
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  public void translate(float paramFloat1, float paramFloat2)
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      this.handle.translateXBy(paramFloat1, paramFloat2);
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  public String toString()
  {
    if (isDisposed()) {
      return "Transform {*DISPOSED*}";
    }
    float[] arrayOfFloat = new float[6];
    getElements(arrayOfFloat);
    return "Transform {" + arrayOfFloat[0] + ", " + arrayOfFloat[1] + ", " + arrayOfFloat[2] + ", " + arrayOfFloat[3] + ", " + arrayOfFloat[4] + ", " + arrayOfFloat[5] + "}";
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/graphics/Transform.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */