package org.eclipse.swt.internal.cocoa;

public class NSApplication
  extends NSResponder
{
  public NSApplication() {}
  
  public NSApplication(long paramLong)
  {
    super(paramLong);
  }
  
  public NSApplication(id paramid)
  {
    super(paramid);
  }
  
  public void activateIgnoringOtherApps(boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_activateIgnoringOtherApps_, paramBoolean);
  }
  
  public NSImage applicationIconImage()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_applicationIconImage);
    return l != 0L ? new NSImage(l) : null;
  }
  
  public void arrangeInFront(id paramid)
  {
    OS.objc_msgSend(this.id, OS.sel_arrangeInFront_, paramid != null ? paramid.id : 0L);
  }
  
  public void beginSheet(NSWindow paramNSWindow1, NSWindow paramNSWindow2, id paramid, long paramLong1, long paramLong2)
  {
    OS.objc_msgSend(this.id, OS.sel_beginSheet_modalForWindow_modalDelegate_didEndSelector_contextInfo_, paramNSWindow1 != null ? paramNSWindow1.id : 0L, paramNSWindow2 != null ? paramNSWindow2.id : 0L, paramid != null ? paramid.id : 0L, paramLong1, paramLong2);
  }
  
  public NSEvent currentEvent()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_currentEvent);
    return l != 0L ? new NSEvent(l) : null;
  }
  
  public NSDockTile dockTile()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_dockTile);
    return l != 0L ? new NSDockTile(l) : null;
  }
  
  public void endSheet(NSWindow paramNSWindow, long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_endSheet_returnCode_, paramNSWindow != null ? paramNSWindow.id : 0L, paramLong);
  }
  
  public void finishLaunching()
  {
    OS.objc_msgSend(this.id, OS.sel_finishLaunching);
  }
  
  public void hide(id paramid)
  {
    OS.objc_msgSend(this.id, OS.sel_hide_, paramid != null ? paramid.id : 0L);
  }
  
  public void hideOtherApplications(id paramid)
  {
    OS.objc_msgSend(this.id, OS.sel_hideOtherApplications_, paramid != null ? paramid.id : 0L);
  }
  
  public boolean isActive()
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_isActive);
  }
  
  public boolean isRunning()
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_isRunning);
  }
  
  public NSWindow keyWindow()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_keyWindow);
    return l != 0L ? new NSWindow(l) : null;
  }
  
  public NSMenu mainMenu()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_mainMenu);
    return l != 0L ? new NSMenu(l) : null;
  }
  
  public NSWindow mainWindow()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_mainWindow);
    return l != 0L ? new NSWindow(l) : null;
  }
  
  public NSEvent nextEventMatchingMask(long paramLong, NSDate paramNSDate, NSString paramNSString, boolean paramBoolean)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_nextEventMatchingMask_untilDate_inMode_dequeue_, paramLong, paramNSDate != null ? paramNSDate.id : 0L, paramNSString != null ? paramNSString.id : 0L, paramBoolean);
    return l != 0L ? new NSEvent(l) : null;
  }
  
  public void orderFrontStandardAboutPanel(id paramid)
  {
    OS.objc_msgSend(this.id, OS.sel_orderFrontStandardAboutPanel_, paramid != null ? paramid.id : 0L);
  }
  
  public NSArray orderedWindows()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_orderedWindows);
    return l != 0L ? new NSArray(l) : null;
  }
  
  public void postEvent(NSEvent paramNSEvent, boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_postEvent_atStart_, paramNSEvent != null ? paramNSEvent.id : 0L, paramBoolean);
  }
  
  public void replyToOpenOrPrint(long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_replyToOpenOrPrint_, paramLong);
  }
  
  public void run()
  {
    OS.objc_msgSend(this.id, OS.sel_run);
  }
  
  public long runModalForWindow(NSWindow paramNSWindow)
  {
    return OS.objc_msgSend(this.id, OS.sel_runModalForWindow_, paramNSWindow != null ? paramNSWindow.id : 0L);
  }
  
  public boolean sendAction(long paramLong, id paramid1, id paramid2)
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_sendAction_to_from_, paramLong, paramid1 != null ? paramid1.id : 0L, paramid2 != null ? paramid2.id : 0L);
  }
  
  public void sendEvent(NSEvent paramNSEvent)
  {
    OS.objc_msgSend(this.id, OS.sel_sendEvent_, paramNSEvent != null ? paramNSEvent.id : 0L);
  }
  
  public void setApplicationIconImage(NSImage paramNSImage)
  {
    OS.objc_msgSend(this.id, OS.sel_setApplicationIconImage_, paramNSImage != null ? paramNSImage.id : 0L);
  }
  
  public void setDelegate(id paramid)
  {
    OS.objc_msgSend(this.id, OS.sel_setDelegate_, paramid != null ? paramid.id : 0L);
  }
  
  public void setHelpMenu(NSMenu paramNSMenu)
  {
    OS.objc_msgSend(this.id, OS.sel_setHelpMenu_, paramNSMenu != null ? paramNSMenu.id : 0L);
  }
  
  public void setMainMenu(NSMenu paramNSMenu)
  {
    OS.objc_msgSend(this.id, OS.sel_setMainMenu_, paramNSMenu != null ? paramNSMenu.id : 0L);
  }
  
  public void setServicesMenu(NSMenu paramNSMenu)
  {
    OS.objc_msgSend(this.id, OS.sel_setServicesMenu_, paramNSMenu != null ? paramNSMenu.id : 0L);
  }
  
  public static NSApplication sharedApplication()
  {
    long l = OS.objc_msgSend(OS.class_NSApplication, OS.sel_sharedApplication);
    return l != 0L ? new NSApplication(l) : null;
  }
  
  public void stop(id paramid)
  {
    OS.objc_msgSend(this.id, OS.sel_stop_, paramid != null ? paramid.id : 0L);
  }
  
  public void terminate(id paramid)
  {
    OS.objc_msgSend(this.id, OS.sel_terminate_, paramid != null ? paramid.id : 0L);
  }
  
  public void unhideAllApplications(id paramid)
  {
    OS.objc_msgSend(this.id, OS.sel_unhideAllApplications_, paramid != null ? paramid.id : 0L);
  }
  
  public NSWindow windowWithWindowNumber(long paramLong)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_windowWithWindowNumber_, paramLong);
    return l != 0L ? new NSWindow(l) : null;
  }
  
  public NSArray windows()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_windows);
    return l != 0L ? new NSArray(l) : null;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSApplication.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */