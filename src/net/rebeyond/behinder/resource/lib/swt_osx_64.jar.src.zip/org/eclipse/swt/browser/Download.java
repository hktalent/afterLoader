package org.eclipse.swt.browser;

import org.eclipse.swt.SWT;
import org.eclipse.swt.internal.C;
import org.eclipse.swt.internal.Compatibility;
import org.eclipse.swt.internal.mozilla.IIDStore;
import org.eclipse.swt.internal.mozilla.XPCOM;
import org.eclipse.swt.internal.mozilla.XPCOMObject;
import org.eclipse.swt.internal.mozilla.nsID;
import org.eclipse.swt.internal.mozilla.nsIHelperAppLauncher;
import org.eclipse.swt.internal.mozilla.nsILocalFile;
import org.eclipse.swt.internal.mozilla.nsISupports;
import org.eclipse.swt.internal.mozilla.nsIURI;
import org.eclipse.swt.internal.mozilla.nsIWebProgressListener;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Shell;

class Download
{
  XPCOMObject supports;
  XPCOMObject download;
  XPCOMObject progressDialog;
  XPCOMObject webProgressListener;
  nsIHelperAppLauncher helperAppLauncher;
  int refCount = 0;
  Shell shell;
  Label status;
  Button cancel;
  
  Download()
  {
    createCOMInterfaces();
  }
  
  int AddRef()
  {
    this.refCount += 1;
    return this.refCount;
  }
  
  void createCOMInterfaces()
  {
    this.supports = new XPCOMObject(new int[] { 2, 0, 0 })
    {
      public long method0(long[] paramAnonymousArrayOfLong)
      {
        return Download.this.QueryInterface(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method1(long[] paramAnonymousArrayOfLong)
      {
        return Download.this.AddRef();
      }
      
      public long method2(long[] paramAnonymousArrayOfLong)
      {
        return Download.this.Release();
      }
    };
    this.download = new XPCOMObject(new int[] { 2, 0, 0, 7, 1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1 })
    {
      public long method0(long[] paramAnonymousArrayOfLong)
      {
        return Download.this.QueryInterface(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method1(long[] paramAnonymousArrayOfLong)
      {
        return Download.this.AddRef();
      }
      
      public long method2(long[] paramAnonymousArrayOfLong)
      {
        return Download.this.Release();
      }
      
      public long method3(long[] paramAnonymousArrayOfLong)
      {
        return Download.this.Init(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2], paramAnonymousArrayOfLong[3], paramAnonymousArrayOfLong[4], paramAnonymousArrayOfLong[5], paramAnonymousArrayOfLong[6]);
      }
      
      public long method4(long[] paramAnonymousArrayOfLong)
      {
        return Download.this.GetSource(paramAnonymousArrayOfLong[0]);
      }
      
      public long method5(long[] paramAnonymousArrayOfLong)
      {
        return Download.this.GetTarget(paramAnonymousArrayOfLong[0]);
      }
      
      public long method6(long[] paramAnonymousArrayOfLong)
      {
        return Download.this.GetPersist(paramAnonymousArrayOfLong[0]);
      }
      
      public long method7(long[] paramAnonymousArrayOfLong)
      {
        return Download.this.GetPercentComplete(paramAnonymousArrayOfLong[0]);
      }
      
      public long method8(long[] paramAnonymousArrayOfLong)
      {
        return Download.this.GetDisplayName(paramAnonymousArrayOfLong[0]);
      }
      
      public long method9(long[] paramAnonymousArrayOfLong)
      {
        return Download.this.SetDisplayName(paramAnonymousArrayOfLong[0]);
      }
      
      public long method10(long[] paramAnonymousArrayOfLong)
      {
        return Download.this.GetStartTime(paramAnonymousArrayOfLong[0]);
      }
      
      public long method11(long[] paramAnonymousArrayOfLong)
      {
        return Download.this.GetMIMEInfo(paramAnonymousArrayOfLong[0]);
      }
      
      public long method12(long[] paramAnonymousArrayOfLong)
      {
        return Download.this.GetListener(paramAnonymousArrayOfLong[0]);
      }
      
      public long method13(long[] paramAnonymousArrayOfLong)
      {
        return Download.this.SetListener(paramAnonymousArrayOfLong[0]);
      }
      
      public long method14(long[] paramAnonymousArrayOfLong)
      {
        return Download.this.GetObserver(paramAnonymousArrayOfLong[0]);
      }
      
      public long method15(long[] paramAnonymousArrayOfLong)
      {
        return Download.this.SetObserver(paramAnonymousArrayOfLong[0]);
      }
    };
    this.progressDialog = new XPCOMObject(new int[] { 2, 0, 0, 7, 1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 })
    {
      public long method0(long[] paramAnonymousArrayOfLong)
      {
        return Download.this.QueryInterface(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method1(long[] paramAnonymousArrayOfLong)
      {
        return Download.this.AddRef();
      }
      
      public long method2(long[] paramAnonymousArrayOfLong)
      {
        return Download.this.Release();
      }
      
      public long method3(long[] paramAnonymousArrayOfLong)
      {
        return Download.this.Init(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2], paramAnonymousArrayOfLong[3], paramAnonymousArrayOfLong[4], paramAnonymousArrayOfLong[5], paramAnonymousArrayOfLong[6]);
      }
      
      public long method4(long[] paramAnonymousArrayOfLong)
      {
        return Download.this.GetSource(paramAnonymousArrayOfLong[0]);
      }
      
      public long method5(long[] paramAnonymousArrayOfLong)
      {
        return Download.this.GetTarget(paramAnonymousArrayOfLong[0]);
      }
      
      public long method6(long[] paramAnonymousArrayOfLong)
      {
        return Download.this.GetPersist(paramAnonymousArrayOfLong[0]);
      }
      
      public long method7(long[] paramAnonymousArrayOfLong)
      {
        return Download.this.GetPercentComplete(paramAnonymousArrayOfLong[0]);
      }
      
      public long method8(long[] paramAnonymousArrayOfLong)
      {
        return Download.this.GetDisplayName(paramAnonymousArrayOfLong[0]);
      }
      
      public long method9(long[] paramAnonymousArrayOfLong)
      {
        return Download.this.SetDisplayName(paramAnonymousArrayOfLong[0]);
      }
      
      public long method10(long[] paramAnonymousArrayOfLong)
      {
        return Download.this.GetStartTime(paramAnonymousArrayOfLong[0]);
      }
      
      public long method11(long[] paramAnonymousArrayOfLong)
      {
        return Download.this.GetMIMEInfo(paramAnonymousArrayOfLong[0]);
      }
      
      public long method12(long[] paramAnonymousArrayOfLong)
      {
        return Download.this.GetListener(paramAnonymousArrayOfLong[0]);
      }
      
      public long method13(long[] paramAnonymousArrayOfLong)
      {
        return Download.this.SetListener(paramAnonymousArrayOfLong[0]);
      }
      
      public long method14(long[] paramAnonymousArrayOfLong)
      {
        return Download.this.GetObserver(paramAnonymousArrayOfLong[0]);
      }
      
      public long method15(long[] paramAnonymousArrayOfLong)
      {
        return Download.this.SetObserver(paramAnonymousArrayOfLong[0]);
      }
      
      public long method16(long[] paramAnonymousArrayOfLong)
      {
        return Download.this.Open(paramAnonymousArrayOfLong[0]);
      }
      
      public long method17(long[] paramAnonymousArrayOfLong)
      {
        return Download.this.GetCancelDownloadOnClose(paramAnonymousArrayOfLong[0]);
      }
      
      public long method18(long[] paramAnonymousArrayOfLong)
      {
        return Download.this.SetCancelDownloadOnClose((int)paramAnonymousArrayOfLong[0]);
      }
      
      public long method19(long[] paramAnonymousArrayOfLong)
      {
        return Download.this.GetDialog(paramAnonymousArrayOfLong[0]);
      }
      
      public long method20(long[] paramAnonymousArrayOfLong)
      {
        return Download.this.SetDialog(paramAnonymousArrayOfLong[0]);
      }
    };
    this.webProgressListener = new XPCOMObject(new int[] { 2, 0, 0, 4, 6, 3, 4, 3 })
    {
      public long method0(long[] paramAnonymousArrayOfLong)
      {
        return Download.this.QueryInterface(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method1(long[] paramAnonymousArrayOfLong)
      {
        return Download.this.AddRef();
      }
      
      public long method2(long[] paramAnonymousArrayOfLong)
      {
        return Download.this.Release();
      }
      
      public long method3(long[] paramAnonymousArrayOfLong)
      {
        return Download.this.OnStateChange(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], (int)paramAnonymousArrayOfLong[2], (int)paramAnonymousArrayOfLong[3]);
      }
      
      public long method4(long[] paramAnonymousArrayOfLong)
      {
        return Download.this.OnProgressChange(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], (int)paramAnonymousArrayOfLong[2], (int)paramAnonymousArrayOfLong[3], (int)paramAnonymousArrayOfLong[4], (int)paramAnonymousArrayOfLong[5]);
      }
      
      public long method5(long[] paramAnonymousArrayOfLong)
      {
        return Download.this.OnLocationChange(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2]);
      }
      
      public long method6(long[] paramAnonymousArrayOfLong)
      {
        return Download.this.OnStatusChange(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], (int)paramAnonymousArrayOfLong[2], paramAnonymousArrayOfLong[3]);
      }
      
      public long method7(long[] paramAnonymousArrayOfLong)
      {
        return Download.this.OnSecurityChange(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], (int)paramAnonymousArrayOfLong[2]);
      }
    };
  }
  
  void disposeCOMInterfaces()
  {
    if (this.supports != null)
    {
      this.supports.dispose();
      this.supports = null;
    }
    if (this.download != null)
    {
      this.download.dispose();
      this.download = null;
    }
    if (this.progressDialog != null)
    {
      this.progressDialog.dispose();
      this.progressDialog = null;
    }
    if (this.webProgressListener != null)
    {
      this.webProgressListener.dispose();
      this.webProgressListener = null;
    }
  }
  
  long getAddress()
  {
    return this.progressDialog.getAddress();
  }
  
  int QueryInterface(long paramLong1, long paramLong2)
  {
    if ((paramLong1 == 0L) || (paramLong2 == 0L)) {
      return -2147467262;
    }
    nsID localnsID = new nsID();
    XPCOM.memmove(localnsID, paramLong1, 16);
    if (localnsID.Equals(IIDStore.GetIID(nsISupports.class)))
    {
      XPCOM.memmove(paramLong2, new long[] { this.supports.getAddress() }, C.PTR_SIZEOF);
      AddRef();
      return 0;
    }
    if (localnsID.Equals(XPCOM.NS_IDOWNLOAD_IID))
    {
      XPCOM.memmove(paramLong2, new long[] { this.download.getAddress() }, C.PTR_SIZEOF);
      AddRef();
      return 0;
    }
    if (localnsID.Equals(XPCOM.NS_IPROGRESSDIALOG_IID))
    {
      XPCOM.memmove(paramLong2, new long[] { this.progressDialog.getAddress() }, C.PTR_SIZEOF);
      AddRef();
      return 0;
    }
    if (localnsID.Equals(IIDStore.GetIID(nsIWebProgressListener.class)))
    {
      XPCOM.memmove(paramLong2, new long[] { this.webProgressListener.getAddress() }, C.PTR_SIZEOF);
      AddRef();
      return 0;
    }
    XPCOM.memmove(paramLong2, new long[] { 0L }, C.PTR_SIZEOF);
    return -2147467262;
  }
  
  int Release()
  {
    this.refCount -= 1;
    if (this.refCount == 0) {
      disposeCOMInterfaces();
    }
    return this.refCount;
  }
  
  int Init(long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5, long paramLong6, long paramLong7)
  {
    nsIURI localnsIURI = new nsIURI(paramLong1);
    long l1 = XPCOM.nsEmbedCString_new();
    int i = localnsIURI.GetHost(l1);
    if (i != 0) {
      Mozilla.error(i);
    }
    int j = XPCOM.nsEmbedCString_Length(l1);
    long l2 = XPCOM.nsEmbedCString_get(l1);
    byte[] arrayOfByte = new byte[j];
    XPCOM.memmove(arrayOfByte, l2, j);
    XPCOM.nsEmbedCString_delete(l1);
    String str1 = new String(arrayOfByte);
    String str2 = null;
    nsISupports localnsISupports = new nsISupports(paramLong2);
    long[] arrayOfLong = new long[1];
    i = localnsISupports.QueryInterface(IIDStore.GetIID(nsIURI.class), arrayOfLong);
    long l3;
    if (i == 0)
    {
      localObject1 = new nsIURI(arrayOfLong[0]);
      arrayOfLong[0] = 0L;
      l3 = XPCOM.nsEmbedCString_new();
      i = ((nsIURI)localObject1).GetPath(l3);
      if (i != 0) {
        Mozilla.error(i);
      }
      j = XPCOM.nsEmbedCString_Length(l3);
      l2 = XPCOM.nsEmbedCString_get(l3);
      arrayOfByte = new byte[j];
      XPCOM.memmove(arrayOfByte, l2, j);
      XPCOM.nsEmbedCString_delete(l3);
      str2 = new String(arrayOfByte);
      int k = str2.lastIndexOf(System.getProperty("file.separator"));
      str2 = str2.substring(k + 1);
      ((nsIURI)localObject1).Release();
    }
    else
    {
      localObject1 = new nsILocalFile(paramLong2);
      l3 = XPCOM.nsEmbedString_new();
      i = ((nsILocalFile)localObject1).GetLeafName(l3);
      if (i != 0) {
        Mozilla.error(i);
      }
      j = XPCOM.nsEmbedString_Length(l3);
      l2 = XPCOM.nsEmbedString_get(l3);
      localObject2 = new char[j];
      XPCOM.memmove((char[])localObject2, l2, j * 2);
      XPCOM.nsEmbedString_delete(l3);
      str2 = new String((char[])localObject2);
    }
    Object localObject1 = new Listener()
    {
      public void handleEvent(Event paramAnonymousEvent)
      {
        if (paramAnonymousEvent.widget == Download.this.cancel) {
          Download.this.shell.close();
        }
        if (Download.this.helperAppLauncher != null)
        {
          Download.this.helperAppLauncher.Cancel();
          Download.this.helperAppLauncher.Release();
        }
        Download.this.shell = null;
        Download.this.helperAppLauncher = null;
      }
    };
    this.shell = new Shell(2144);
    String str3 = Compatibility.getMessage("SWT_Download_File", new Object[] { str2 });
    this.shell.setText(str3);
    GridLayout localGridLayout = new GridLayout();
    localGridLayout.marginHeight = 15;
    localGridLayout.marginWidth = 15;
    localGridLayout.verticalSpacing = 20;
    this.shell.setLayout(localGridLayout);
    str3 = Compatibility.getMessage("SWT_Download_Location", new Object[] { str2, str1 });
    new Label(this.shell, 64).setText(str3);
    this.status = new Label(this.shell, 64);
    str3 = Compatibility.getMessage("SWT_Download_Started");
    this.status.setText(str3);
    Object localObject2 = new GridData();
    ((GridData)localObject2).grabExcessHorizontalSpace = true;
    ((GridData)localObject2).grabExcessVerticalSpace = true;
    this.status.setLayoutData(localObject2);
    this.cancel = new Button(this.shell, 8);
    this.cancel.setText(SWT.getMessage("SWT_Cancel"));
    localObject2 = new GridData();
    ((GridData)localObject2).horizontalAlignment = 2;
    this.cancel.setLayoutData(localObject2);
    this.cancel.addListener(13, (Listener)localObject1);
    this.shell.addListener(21, (Listener)localObject1);
    this.shell.pack();
    this.shell.open();
    return 0;
  }
  
  int GetSource(long paramLong)
  {
    return -2147467263;
  }
  
  int GetTarget(long paramLong)
  {
    return -2147467263;
  }
  
  int GetPersist(long paramLong)
  {
    return -2147467263;
  }
  
  int GetPercentComplete(long paramLong)
  {
    return -2147467263;
  }
  
  int GetDisplayName(long paramLong)
  {
    return -2147467263;
  }
  
  int SetDisplayName(long paramLong)
  {
    return -2147467263;
  }
  
  int GetStartTime(long paramLong)
  {
    return -2147467263;
  }
  
  int GetMIMEInfo(long paramLong)
  {
    return -2147467263;
  }
  
  int GetListener(long paramLong)
  {
    return -2147467263;
  }
  
  int SetListener(long paramLong)
  {
    return -2147467263;
  }
  
  int GetObserver(long paramLong)
  {
    return -2147467263;
  }
  
  int SetObserver(long paramLong)
  {
    if (paramLong != 0L)
    {
      nsISupports localnsISupports = new nsISupports(paramLong);
      long[] arrayOfLong = new long[1];
      int i = localnsISupports.QueryInterface(IIDStore.GetIID(nsIHelperAppLauncher.class), arrayOfLong);
      if (i != 0) {
        Mozilla.error(i);
      }
      if (arrayOfLong[0] == 0L) {
        Mozilla.error(-2147467262);
      }
      this.helperAppLauncher = new nsIHelperAppLauncher(arrayOfLong[0]);
    }
    return 0;
  }
  
  int Open(long paramLong)
  {
    return -2147467263;
  }
  
  int GetCancelDownloadOnClose(long paramLong)
  {
    return -2147467263;
  }
  
  int SetCancelDownloadOnClose(int paramInt)
  {
    return -2147467263;
  }
  
  int GetDialog(long paramLong)
  {
    return -2147467263;
  }
  
  int SetDialog(long paramLong)
  {
    return -2147467263;
  }
  
  int OnStateChange(long paramLong1, long paramLong2, int paramInt1, int paramInt2)
  {
    if ((paramInt1 & 0x10) != 0)
    {
      if (this.helperAppLauncher != null) {
        this.helperAppLauncher.Release();
      }
      this.helperAppLauncher = null;
      if ((this.shell != null) && (!this.shell.isDisposed())) {
        this.shell.dispose();
      }
      this.shell = null;
    }
    return 0;
  }
  
  int OnProgressChange(long paramLong1, long paramLong2, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    int i = paramInt3 / 1024;
    int j = paramInt4 / 1024;
    if ((this.shell != null) && (!this.shell.isDisposed()))
    {
      Object[] arrayOfObject = { new Integer(i), new Integer(j) };
      String str = Compatibility.getMessage("SWT_Download_Status", arrayOfObject);
      this.status.setText(str);
      this.shell.layout(true);
      this.shell.getDisplay().update();
    }
    return 0;
  }
  
  int OnLocationChange(long paramLong1, long paramLong2, long paramLong3)
  {
    return 0;
  }
  
  int OnStatusChange(long paramLong1, long paramLong2, int paramInt, long paramLong3)
  {
    return 0;
  }
  
  int OnSecurityChange(long paramLong1, long paramLong2, int paramInt)
  {
    return 0;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/browser/Download.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */