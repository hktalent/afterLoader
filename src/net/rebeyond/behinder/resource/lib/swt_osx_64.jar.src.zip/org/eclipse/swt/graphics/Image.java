package org.eclipse.swt.graphics;

import java.io.InputStream;
import org.eclipse.swt.SWT;
import org.eclipse.swt.internal.cocoa.NSAffineTransform;
import org.eclipse.swt.internal.cocoa.NSArray;
import org.eclipse.swt.internal.cocoa.NSAutoreleasePool;
import org.eclipse.swt.internal.cocoa.NSBitmapImageRep;
import org.eclipse.swt.internal.cocoa.NSColor;
import org.eclipse.swt.internal.cocoa.NSGraphicsContext;
import org.eclipse.swt.internal.cocoa.NSImage;
import org.eclipse.swt.internal.cocoa.NSImageRep;
import org.eclipse.swt.internal.cocoa.NSObject;
import org.eclipse.swt.internal.cocoa.NSRect;
import org.eclipse.swt.internal.cocoa.NSSize;
import org.eclipse.swt.internal.cocoa.NSString;
import org.eclipse.swt.internal.cocoa.NSThread;
import org.eclipse.swt.internal.cocoa.OS;

public final class Image
  extends Resource
  implements Drawable
{
  public int type;
  public NSImage handle;
  int transparentPixel = -1;
  GC memGC;
  byte[] alphaData;
  int alpha = -1;
  int width = -1;
  int height = -1;
  static final int DEFAULT_SCANLINE_PAD = 4;
  
  Image(Device paramDevice)
  {
    super(paramDevice);
  }
  
  public Image(Device paramDevice, int paramInt1, int paramInt2)
  {
    super(paramDevice);
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      init(paramInt1, paramInt2);
      init();
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  public Image(Device paramDevice, Image paramImage, int paramInt)
  {
    super(paramDevice);
    if (paramImage == null) {
      SWT.error(4);
    }
    if (paramImage.isDisposed()) {
      SWT.error(5);
    }
    switch (paramInt)
    {
    case 0: 
    case 1: 
    case 2: 
      break;
    default: 
      SWT.error(5);
    }
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      paramDevice = this.device;
      this.type = paramImage.type;
      NSSize localNSSize = paramImage.handle.size();
      int i = (int)localNSSize.width;
      int j = (int)localNSSize.height;
      NSBitmapImageRep localNSBitmapImageRep1 = paramImage.getRepresentation();
      long l1 = localNSBitmapImageRep1.bytesPerRow();
      this.transparentPixel = paramImage.transparentPixel;
      this.alpha = paramImage.alpha;
      if (paramImage.alphaData != null)
      {
        this.alphaData = new byte[paramImage.alphaData.length];
        System.arraycopy(paramImage.alphaData, 0, this.alphaData, 0, this.alphaData.length);
      }
      long l2 = localNSBitmapImageRep1.bitmapData();
      long l3 = localNSBitmapImageRep1.bitmapFormat();
      long l4 = localNSBitmapImageRep1.bitsPerPixel();
      this.handle = ((NSImage)new NSImage().alloc());
      this.handle = this.handle.initWithSize(localNSSize);
      NSBitmapImageRep localNSBitmapImageRep2 = (NSBitmapImageRep)new NSBitmapImageRep().alloc();
      localNSBitmapImageRep2 = localNSBitmapImageRep2.initWithBitmapDataPlanes(0L, i, j, localNSBitmapImageRep1.bitsPerSample(), localNSBitmapImageRep1.samplesPerPixel(), localNSBitmapImageRep1.hasAlpha(), localNSBitmapImageRep1.isPlanar(), OS.NSDeviceRGBColorSpace, l3, localNSBitmapImageRep1.bytesPerRow(), l4);
      this.handle.addRepresentation(localNSBitmapImageRep2);
      localNSBitmapImageRep2.release();
      this.handle.setCacheMode(3L);
      long l5 = localNSBitmapImageRep2.bitmapData();
      OS.memmove(l5, l2, i * j * 4);
      if (paramInt != 0)
      {
        int k;
        int m;
        int n;
        if ((l4 == 32L) && ((l3 & 1L) == 0L))
        {
          k = 0;
          m = 1;
          n = 2;
        }
        else
        {
          k = 1;
          m = 2;
          n = 3;
        }
        Object localObject1;
        int i2;
        int i3;
        int i4;
        int i7;
        switch (paramInt)
        {
        case 1: 
          localObject1 = paramDevice.getSystemColor(18);
          RGB localRGB1 = ((Color)localObject1).getRGB();
          i2 = (byte)localRGB1.red;
          i3 = (byte)localRGB1.green;
          i4 = (byte)localRGB1.blue;
          Color localColor = paramDevice.getSystemColor(22);
          RGB localRGB2 = localColor.getRGB();
          i7 = (byte)localRGB2.red;
          int i8 = (byte)localRGB2.green;
          int i9 = (byte)localRGB2.blue;
          byte[] arrayOfByte = new byte[(int)l1];
          for (int i10 = 0; i10 < j; i10++)
          {
            OS.memmove(arrayOfByte, l5 + i10 * l1, l1);
            int i11 = 0;
            for (int i12 = 0; i12 < i; i12++)
            {
              int i13 = arrayOfByte[(i11 + k)] & 0xFF;
              int i14 = arrayOfByte[(i11 + m)] & 0xFF;
              int i15 = arrayOfByte[(i11 + n)] & 0xFF;
              int i16 = i13 * i13 + i14 * i14 + i15 * i15;
              if (i16 < 98304)
              {
                arrayOfByte[(i11 + k)] = i2;
                arrayOfByte[(i11 + m)] = i3;
                arrayOfByte[(i11 + n)] = i4;
              }
              else
              {
                arrayOfByte[(i11 + k)] = i7;
                arrayOfByte[(i11 + m)] = i8;
                arrayOfByte[(i11 + n)] = i9;
              }
              i11 += 4;
            }
            OS.memmove(l5 + i10 * l1, arrayOfByte, l1);
          }
          break;
        case 2: 
          localObject1 = new byte[(int)l1];
          for (int i1 = 0; i1 < j; i1++)
          {
            OS.memmove((byte[])localObject1, l5 + i1 * l1, l1);
            i2 = 0;
            for (i3 = 0; i3 < i; i3++)
            {
              i4 = localObject1[(i2 + k)] & 0xFF;
              int i5 = localObject1[(i2 + m)] & 0xFF;
              int i6 = localObject1[(i2 + n)] & 0xFF;
              i7 = (byte)(i4 + i4 + i5 + i5 + i5 + i5 + i5 + i6 >> 3);
              localObject1[(i2 + k)] = (localObject1[(i2 + m)] = localObject1[(i2 + n)] = i7);
              i2 += 4;
            }
            OS.memmove(l5 + i1 * l1, (byte[])localObject1, l1);
          }
          break;
        }
      }
      init();
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  public Image(Device paramDevice, Rectangle paramRectangle)
  {
    super(paramDevice);
    if (paramRectangle == null) {
      SWT.error(4);
    }
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      init(paramRectangle.width, paramRectangle.height);
      init();
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  public Image(Device paramDevice, ImageData paramImageData)
  {
    super(paramDevice);
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      init(paramImageData);
      init();
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  public Image(Device paramDevice, ImageData paramImageData1, ImageData paramImageData2)
  {
    super(paramDevice);
    if (paramImageData1 == null) {
      SWT.error(4);
    }
    if (paramImageData2 == null) {
      SWT.error(4);
    }
    if ((paramImageData1.width != paramImageData2.width) || (paramImageData1.height != paramImageData2.height)) {
      SWT.error(5);
    }
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      paramImageData2 = ImageData.convertMask(paramImageData2);
      ImageData localImageData = new ImageData(paramImageData1.width, paramImageData1.height, paramImageData1.depth, paramImageData1.palette, paramImageData1.scanlinePad, paramImageData1.data);
      localImageData.maskPad = paramImageData2.scanlinePad;
      localImageData.maskData = paramImageData2.data;
      init(localImageData);
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  public Image(Device paramDevice, InputStream paramInputStream)
  {
    super(paramDevice);
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      init(new ImageData(paramInputStream));
      init();
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  public Image(Device paramDevice, String paramString)
  {
    super(paramDevice);
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      if (paramString == null) {
        SWT.error(4);
      }
      initNative(paramString);
      if (this.handle == null) {
        init(new ImageData(paramString));
      }
      init();
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  void createAlpha()
  {
    if ((this.transparentPixel == -1) && (this.alpha == -1) && (this.alphaData == null)) {
      return;
    }
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      NSBitmapImageRep localNSBitmapImageRep = getRepresentation();
      long l1 = localNSBitmapImageRep.pixelsHigh();
      long l2 = localNSBitmapImageRep.bytesPerRow();
      long l3 = localNSBitmapImageRep.bitmapData();
      long l4 = localNSBitmapImageRep.bitmapFormat();
      long l5 = l1 * l2;
      byte[] arrayOfByte = new byte[(int)l5];
      OS.memmove(arrayOfByte, l3, l5);
      int i;
      int j;
      if (this.transparentPixel != -1)
      {
        if ((l4 & 1L) != 0L) {
          for (i = 0; i < l5; i += 4)
          {
            j = (arrayOfByte[(i + 1)] & 0xFF) << 16 | (arrayOfByte[(i + 2)] & 0xFF) << 8 | arrayOfByte[(i + 3)] & 0xFF;
            arrayOfByte[i] = ((byte)(j == this.transparentPixel ? 0 : 'ÿ'));
          }
        } else {
          for (i = 0; i < l5; i += 4)
          {
            j = (arrayOfByte[(i + 0)] & 0xFF) << 16 | (arrayOfByte[(i + 1)] & 0xFF) << 8 | arrayOfByte[(i + 2)] & 0xFF;
            arrayOfByte[i] = ((byte)(j == this.transparentPixel ? 0 : 'ÿ'));
          }
        }
      }
      else if (this.alpha != -1)
      {
        i = (byte)this.alpha;
        for (j = (l4 & 1L) != 0L ? 0 : 3; j < l5; j += 4) {
          arrayOfByte[j] = i;
        }
      }
      else
      {
        long l6 = localNSBitmapImageRep.pixelsWide();
        int k = 0;
        int m = (l4 & 1L) != 0L ? 0 : 3;
        for (int n = 0; n < l1; n++) {
          for (int i1 = 0; i1 < l6; i1++)
          {
            arrayOfByte[k] = this.alphaData[m];
            k += 4;
            m++;
          }
        }
      }
      localNSBitmapImageRep.setAlpha(true);
      OS.memmove(l3, arrayOfByte, l5);
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  void destroy()
  {
    if (this.memGC != null) {
      this.memGC.dispose();
    }
    this.handle.release();
    this.handle = null;
    this.memGC = null;
  }
  
  public boolean equals(Object paramObject)
  {
    if (paramObject == this) {
      return true;
    }
    if (!(paramObject instanceof Image)) {
      return false;
    }
    Image localImage = (Image)paramObject;
    return (this.device == localImage.device) && (this.handle == localImage.handle) && (this.transparentPixel == localImage.transparentPixel);
  }
  
  public Color getBackground()
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    if (this.transparentPixel == -1) {
      return null;
    }
    int i = this.transparentPixel >> 16 & 0xFF;
    int j = this.transparentPixel >> 8 & 0xFF;
    int k = this.transparentPixel >> 0 & 0xFF;
    return Color.cocoa_new(this.device, new double[] { i / 255.0F, j / 255.0F, k / 255.0F, 1.0D });
  }
  
  public Rectangle getBounds()
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      if ((this.width != -1) && (this.height != -1))
      {
        localObject1 = new Rectangle(0, 0, this.width, this.height);
        return (Rectangle)localObject1;
      }
      Object localObject1 = this.handle.size();
      Rectangle localRectangle = new Rectangle(0, 0, this.width = (int)((NSSize)localObject1).width, this.height = (int)((NSSize)localObject1).height);
      return localRectangle;
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  public ImageData getImageData()
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      NSBitmapImageRep localNSBitmapImageRep = getRepresentation();
      long l1 = localNSBitmapImageRep.pixelsWide();
      long l2 = localNSBitmapImageRep.pixelsHigh();
      long l3 = localNSBitmapImageRep.bytesPerRow();
      long l4 = localNSBitmapImageRep.bitsPerPixel();
      long l5 = localNSBitmapImageRep.bitmapData();
      long l6 = localNSBitmapImageRep.bitmapFormat();
      long l7 = l2 * l3;
      byte[] arrayOfByte1 = new byte[(int)l7];
      OS.memmove(arrayOfByte1, l5, l7);
      PaletteData localPaletteData;
      if ((l4 == 32L) && ((l6 & 1L) == 0L)) {
        localPaletteData = new PaletteData(-16777216, 16711680, 65280);
      } else {
        localPaletteData = new PaletteData(16711680, 65280, 255);
      }
      ImageData localImageData1 = new ImageData((int)l1, (int)l2, (int)l4, localPaletteData, 1, arrayOfByte1);
      localImageData1.bytesPerLine = ((int)l3);
      long l8;
      long l9;
      if ((localNSBitmapImageRep.hasAlpha()) && (this.transparentPixel == -1) && (this.alpha == -1) && (this.alphaData == null))
      {
        byte[] arrayOfByte2 = new byte[(int)(l1 * l2)];
        int i = (l6 & 1L) != 0L ? 0 : 3;
        int j = 0;
        for (int k = i; k < arrayOfByte1.length; k += 4) {
          arrayOfByte2[(j++)] = arrayOfByte1[k];
        }
        localImageData1.alphaData = arrayOfByte2;
      }
      else
      {
        localImageData1.transparentPixel = this.transparentPixel;
        if ((this.transparentPixel == -1) && (this.type == 1))
        {
          l8 = 2;
          l9 = ((l1 + 7L) / 8L + (l8 - 1)) / l8 * l8;
          byte[] arrayOfByte3 = new byte[(int)(l2 * l9)];
          int m = 0;
          int n = 0;
          for (int i1 = 0; i1 < l2; tmp390_389++)
          {
            for (int i2 = 0; i2 < l1; tmp390_381++)
            {
              if (arrayOfByte1[m] != 0)
              {
                int tmp390_389 = (n + (i2 >> 3));
                byte[] tmp390_381 = arrayOfByte3;
                tmp390_381[tmp390_389] = ((byte)(tmp390_381[tmp390_389] | 1 << 7 - (tmp390_381 & 0x7)));
              }
              else
              {
                int tmp417_416 = (n + (tmp390_381 >> 3));
                byte[] tmp417_408 = arrayOfByte3;
                tmp417_408[tmp417_416] = ((byte)(tmp417_408[tmp417_416] & (1 << 7 - (tmp390_381 & 0x7) ^ 0xFFFFFFFF)));
              }
              m += 4;
            }
            n = (int)(n + l9);
          }
          localImageData1.maskData = arrayOfByte3;
          localImageData1.maskPad = l8;
        }
        localImageData1.alpha = this.alpha;
        if ((this.alpha == -1) && (this.alphaData != null))
        {
          localImageData1.alphaData = new byte[this.alphaData.length];
          System.arraycopy(this.alphaData, 0, localImageData1.alphaData, 0, this.alphaData.length);
        }
      }
      if (l4 == 32L)
      {
        l8 = (l6 & 1L) != 0L ? 0 : 3;
        for (l9 = l8; l9 < arrayOfByte1.length; l9 += 4) {
          arrayOfByte1[l9] = 0;
        }
      }
      ImageData localImageData2 = localImageData1;
      return localImageData2;
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  public static Image cocoa_new(Device paramDevice, int paramInt, NSImage paramNSImage)
  {
    Image localImage = new Image(paramDevice);
    localImage.type = paramInt;
    localImage.handle = paramNSImage;
    return localImage;
  }
  
  NSBitmapImageRep getRepresentation()
  {
    NSBitmapImageRep localNSBitmapImageRep1 = new NSBitmapImageRep(this.handle.bestRepresentationForDevice(null));
    if (localNSBitmapImageRep1.isKindOfClass(OS.class_NSBitmapImageRep)) {
      return localNSBitmapImageRep1;
    }
    NSArray localNSArray = this.handle.representations();
    NSSize localNSSize = this.handle.size();
    long l = localNSArray.count();
    NSBitmapImageRep localNSBitmapImageRep2 = null;
    for (int i = 0; i < l; i++)
    {
      localNSBitmapImageRep1 = new NSBitmapImageRep(localNSArray.objectAtIndex(i));
      if (localNSBitmapImageRep1.isKindOfClass(OS.class_NSBitmapImageRep)) {
        return localNSBitmapImageRep1;
      }
      if ((localNSBitmapImageRep2 == null) || (((int)localNSSize.width == localNSBitmapImageRep1.pixelsWide()) && ((int)localNSSize.height == localNSBitmapImageRep1.pixelsHigh()))) {
        localNSBitmapImageRep2 = localNSBitmapImageRep1;
      }
    }
    localNSBitmapImageRep2.retain();
    for (i = 0; i < l; i++) {
      this.handle.removeRepresentation(new NSImageRep(this.handle.representations().objectAtIndex(0L)));
    }
    this.handle.addRepresentation(localNSBitmapImageRep2);
    NSBitmapImageRep localNSBitmapImageRep3 = (NSBitmapImageRep)new NSBitmapImageRep().alloc();
    localNSBitmapImageRep3 = localNSBitmapImageRep3.initWithData(this.handle.TIFFRepresentation());
    this.handle.addRepresentation(localNSBitmapImageRep3);
    this.handle.removeRepresentation(localNSBitmapImageRep2);
    localNSBitmapImageRep2.release();
    localNSBitmapImageRep3.release();
    return localNSBitmapImageRep3;
  }
  
  public int hashCode()
  {
    return this.handle != null ? (int)this.handle.id : 0;
  }
  
  void init(int paramInt1, int paramInt2)
  {
    if ((paramInt1 <= 0) || (paramInt2 <= 0)) {
      SWT.error(5);
    }
    this.type = 0;
    this.width = paramInt1;
    this.height = paramInt2;
    this.handle = ((NSImage)new NSImage().alloc());
    NSSize localNSSize = new NSSize();
    localNSSize.width = paramInt1;
    localNSSize.height = paramInt2;
    this.handle = this.handle.initWithSize(localNSSize);
    NSBitmapImageRep localNSBitmapImageRep = (NSBitmapImageRep)new NSBitmapImageRep().alloc();
    localNSBitmapImageRep = localNSBitmapImageRep.initWithBitmapDataPlanes(0L, paramInt1, paramInt2, 8L, 3L, false, false, OS.NSDeviceRGBColorSpace, 3L, paramInt1 * 4, 32L);
    OS.memset(localNSBitmapImageRep.bitmapData(), 255, paramInt1 * paramInt2 * 4);
    this.handle.addRepresentation(localNSBitmapImageRep);
    localNSBitmapImageRep.release();
    this.handle.setCacheMode(3L);
  }
  
  void init(ImageData paramImageData)
  {
    if (paramImageData == null) {
      SWT.error(4);
    }
    this.width = paramImageData.width;
    this.height = paramImageData.height;
    PaletteData localPaletteData = paramImageData.palette;
    if (((paramImageData.depth != 1) && (paramImageData.depth != 2) && (paramImageData.depth != 4) && (paramImageData.depth != 8)) || ((localPaletteData.isDirect) && (paramImageData.depth != 8) && (((paramImageData.depth != 16) && (paramImageData.depth != 24) && (paramImageData.depth != 32)) || (!localPaletteData.isDirect)))) {
      SWT.error(38);
    }
    int i = this.width * this.height * 4;
    int j = this.width * 4;
    byte[] arrayOfByte1 = new byte[i];
    RGB localRGB;
    if (localPaletteData.isDirect)
    {
      ImageData.blit(1, paramImageData.data, paramImageData.depth, paramImageData.bytesPerLine, paramImageData.getByteOrder(), 0, 0, this.width, this.height, localPaletteData.redMask, localPaletteData.greenMask, localPaletteData.blueMask, 255, null, 0, 0, 0, arrayOfByte1, 32, j, 1, 0, 0, this.width, this.height, 16711680, 65280, 255, false, false);
    }
    else
    {
      RGB[] arrayOfRGB = localPaletteData.getRGBs();
      m = arrayOfRGB.length;
      byte[] arrayOfByte2 = new byte[m];
      byte[] arrayOfByte3 = new byte[m];
      byte[] arrayOfByte5 = new byte[m];
      for (int i5 = 0; i5 < arrayOfRGB.length; i5++)
      {
        localRGB = arrayOfRGB[i5];
        if (localRGB != null)
        {
          arrayOfByte2[i5] = ((byte)localRGB.red);
          arrayOfByte3[i5] = ((byte)localRGB.green);
          arrayOfByte5[i5] = ((byte)localRGB.blue);
        }
      }
      ImageData.blit(1, paramImageData.data, paramImageData.depth, paramImageData.bytesPerLine, paramImageData.getByteOrder(), 0, 0, this.width, this.height, arrayOfByte2, arrayOfByte3, arrayOfByte5, 255, null, 0, 0, 0, arrayOfByte1, 32, j, 1, 0, 0, this.width, this.height, 16711680, 65280, 255, false, false);
    }
    int k = paramImageData.getTransparencyType();
    int m = k != 0 ? 1 : 0;
    int i4;
    int i6;
    if ((k == 2) || (paramImageData.transparentPixel != -1))
    {
      this.type = (paramImageData.transparentPixel != -1 ? 0 : 1);
      if (paramImageData.transparentPixel != -1)
      {
        int n = 0;
        int i2 = 0;
        i4 = 0;
        Object localObject;
        if (localPaletteData.isDirect)
        {
          localObject = localPaletteData.getRGB(paramImageData.transparentPixel);
          n = ((RGB)localObject).red;
          i2 = ((RGB)localObject).green;
          i4 = ((RGB)localObject).blue;
        }
        else
        {
          localObject = localPaletteData.getRGBs();
          if (paramImageData.transparentPixel < localObject.length)
          {
            localRGB = localObject[paramImageData.transparentPixel];
            n = localRGB.red;
            i2 = localRGB.green;
            i4 = localRGB.blue;
          }
        }
        this.transparentPixel = (n << 16 | i2 << 8 | i4);
      }
      ImageData localImageData = paramImageData.getTransparencyMask();
      byte[] arrayOfByte4 = localImageData.data;
      i4 = localImageData.bytesPerLine;
      i6 = 0;
      int i7 = 0;
      for (int i8 = 0; i8 < this.height; i8++)
      {
        for (int i9 = 0; i9 < this.width; i9++)
        {
          arrayOfByte1[i6] = ((arrayOfByte4[(i7 + (i9 >> 3))] & 1 << 7 - (i9 & 0x7)) != 0 ? -1 : 0);
          i6 += 4;
        }
        i7 += i4;
      }
    }
    else
    {
      this.type = 0;
      int i1;
      int i3;
      if (paramImageData.alpha != -1)
      {
        m = 1;
        this.alpha = paramImageData.alpha;
        i1 = (byte)this.alpha;
        for (i3 = 0; i3 < arrayOfByte1.length; i3 += 4) {
          arrayOfByte1[i3] = i1;
        }
      }
      else if (paramImageData.alphaData != null)
      {
        m = 1;
        this.alphaData = new byte[paramImageData.alphaData.length];
        System.arraycopy(paramImageData.alphaData, 0, this.alphaData, 0, this.alphaData.length);
        i1 = 0;
        i3 = 0;
        for (i4 = 0; i4 < this.height; i4++) {
          for (i6 = 0; i6 < this.width; i6++)
          {
            arrayOfByte1[i1] = this.alphaData[i3];
            i1 += 4;
            i3++;
          }
        }
      }
    }
    if (this.handle != null) {
      this.handle.release();
    }
    this.handle = ((NSImage)new NSImage().alloc());
    NSSize localNSSize = new NSSize();
    localNSSize.width = this.width;
    localNSSize.height = this.height;
    this.handle = this.handle.initWithSize(localNSSize);
    NSBitmapImageRep localNSBitmapImageRep = (NSBitmapImageRep)new NSBitmapImageRep().alloc();
    localNSBitmapImageRep = localNSBitmapImageRep.initWithBitmapDataPlanes(0L, this.width, this.height, 8L, m != 0 ? 4L : 3L, m, false, OS.NSDeviceRGBColorSpace, 3L, j, 32L);
    OS.memmove(localNSBitmapImageRep.bitmapData(), arrayOfByte1, i);
    this.handle.addRepresentation(localNSBitmapImageRep);
    localNSBitmapImageRep.release();
    this.handle.setCacheMode(3L);
  }
  
  void initNative(String paramString)
  {
    NSAutoreleasePool localNSAutoreleasePool = null;
    NSImage localNSImage = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      localNSImage = new NSImage();
      localNSImage.alloc();
      localNSImage = localNSImage.initWithContentsOfFile(NSString.stringWith(paramString));
      if (localNSImage == null) {
        return;
      }
      NSImageRep localNSImageRep = localNSImage.bestRepresentationForDevice(null);
      if (!localNSImageRep.isKindOfClass(OS.class_NSBitmapImageRep)) {
        return;
      }
      this.width = ((int)localNSImageRep.pixelsWide());
      this.height = ((int)localNSImageRep.pixelsHigh());
      boolean bool = localNSImageRep.hasAlpha();
      int i = this.width * 4;
      this.handle = ((NSImage)new NSImage().alloc());
      NSSize localNSSize = new NSSize();
      localNSSize.width = this.width;
      localNSSize.height = this.height;
      this.handle = this.handle.initWithSize(localNSSize);
      NSBitmapImageRep localNSBitmapImageRep = (NSBitmapImageRep)new NSBitmapImageRep().alloc();
      localNSBitmapImageRep = localNSBitmapImageRep.initWithBitmapDataPlanes(0L, this.width, this.height, 8L, bool ? 4L : 3L, bool, false, OS.NSDeviceRGBColorSpace, 3L, i, 32L);
      this.handle.addRepresentation(localNSBitmapImageRep);
      localNSBitmapImageRep.release();
      this.handle.setCacheMode(3L);
      NSRect localNSRect = new NSRect();
      localNSRect.width = this.width;
      localNSRect.height = this.height;
      long l1 = OS.CGColorSpaceCreateDeviceRGB();
      long l2 = OS.CGBitmapContextCreate(localNSBitmapImageRep.bitmapData(), this.width, this.height, 8L, i, l1, 6);
      OS.CGColorSpaceRelease(l1);
      NSGraphicsContext.static_saveGraphicsState();
      NSGraphicsContext.setCurrentContext(NSGraphicsContext.graphicsContextWithGraphicsPort(l2, false));
      localNSImageRep.drawInRect(localNSRect);
      NSGraphicsContext.static_restoreGraphicsState();
      OS.CGContextRelease(l2);
      if (bool)
      {
        long l3 = this.width;
        long l4 = l3 * this.height;
        long l5 = OS.malloc(l4);
        long l6 = OS.CGBitmapContextCreate(l5, this.width, this.height, 8L, l3, 0L, 7);
        NSGraphicsContext.static_saveGraphicsState();
        NSGraphicsContext.setCurrentContext(NSGraphicsContext.graphicsContextWithGraphicsPort(l6, false));
        localNSImageRep.drawInRect(localNSRect);
        NSGraphicsContext.static_restoreGraphicsState();
        byte[] arrayOfByte1 = new byte[(int)l4];
        OS.memmove(arrayOfByte1, l5, l4);
        OS.free(l5);
        OS.CGContextRelease(l6);
        byte[] arrayOfByte2 = new byte[this.height * i];
        OS.memmove(arrayOfByte2, localNSBitmapImageRep.bitmapData(), arrayOfByte2.length);
        int j = 0;
        for (int k = 0; j < arrayOfByte1.length; k += 4)
        {
          arrayOfByte2[k] = arrayOfByte1[j];
          float f = arrayOfByte1[j] & 0xFF;
          if (f != 0.0F)
          {
            arrayOfByte2[(k + 1)] = ((byte)(int)((arrayOfByte2[(k + 1)] & 0xFF) / f * 255.0F));
            arrayOfByte2[(k + 2)] = ((byte)(int)((arrayOfByte2[(k + 2)] & 0xFF) / f * 255.0F));
            arrayOfByte2[(k + 3)] = ((byte)(int)((arrayOfByte2[(k + 3)] & 0xFF) / f * 255.0F));
          }
          j++;
        }
        OS.memmove(localNSBitmapImageRep.bitmapData(), arrayOfByte2, arrayOfByte2.length);
        j = -1;
        k = 0;
        for (k = 0; k < arrayOfByte1.length; k++)
        {
          int m = arrayOfByte1[k];
          if ((j == -1) && (m == 0)) {
            j = k;
          }
          if ((m != 0) && (m != -1)) {
            break;
          }
        }
        this.alpha = -1;
        if ((k == arrayOfByte1.length) && (j != -1))
        {
          NSColor localNSColor = localNSBitmapImageRep.colorAtX(j % this.width, j / this.width);
          int n = (int)(localNSColor.redComponent() * 255.0D);
          int i1 = (int)(localNSColor.greenComponent() * 255.0D);
          int i2 = (int)(localNSColor.blueComponent() * 255.0D);
          this.transparentPixel = (n << 16 | i1 << 8 | i2);
          for (int i3 = 0; i3 < arrayOfByte2.length; i3 += 4) {
            if (arrayOfByte2[i3] != 0)
            {
              int i4 = (arrayOfByte2[(i3 + 1)] & 0xFF) << 16 | (arrayOfByte2[(i3 + 2)] & 0xFF) << 8 | arrayOfByte2[(i3 + 3)] & 0xFF;
              if (i4 == this.transparentPixel)
              {
                this.transparentPixel = -1;
                break;
              }
            }
          }
        }
        if (this.transparentPixel == -1) {
          this.alphaData = arrayOfByte1;
        }
      }
      if (paramString.toLowerCase().endsWith(".ico")) {
        this.type = 1;
      } else {
        this.type = 0;
      }
    }
    finally
    {
      if (localNSImage != null) {
        localNSImage.release();
      }
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  public long internal_new_GC(GCData paramGCData)
  {
    if (this.handle == null) {
      SWT.error(44);
    }
    if ((this.type != 0) || (this.memGC != null)) {
      SWT.error(5);
    }
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      NSBitmapImageRep localNSBitmapImageRep = getRepresentation();
      localNSBitmapImageRep.setAlpha(false);
      Object localObject1 = NSGraphicsContext.graphicsContextWithBitmapImageRep(localNSBitmapImageRep);
      NSGraphicsContext localNSGraphicsContext = NSGraphicsContext.graphicsContextWithGraphicsPort(((NSGraphicsContext)localObject1).graphicsPort(), true);
      localObject1 = localNSGraphicsContext;
      ((NSGraphicsContext)localObject1).retain();
      if (paramGCData != null) {
        paramGCData.flippedContext = localNSGraphicsContext;
      }
      NSGraphicsContext.static_saveGraphicsState();
      NSGraphicsContext.setCurrentContext((NSGraphicsContext)localObject1);
      NSAffineTransform localNSAffineTransform = NSAffineTransform.transform();
      NSSize localNSSize = this.handle.size();
      localNSAffineTransform.translateXBy(0.0D, localNSSize.height);
      localNSAffineTransform.scaleXBy(1.0D, -1.0D);
      localNSAffineTransform.set();
      NSGraphicsContext.static_restoreGraphicsState();
      if (paramGCData != null)
      {
        int i = 100663296;
        if ((paramGCData.style & i) == 0) {
          paramGCData.style |= 0x2000000;
        }
        paramGCData.device = this.device;
        paramGCData.background = this.device.COLOR_WHITE.handle;
        paramGCData.foreground = this.device.COLOR_BLACK.handle;
        paramGCData.font = this.device.systemFont;
        paramGCData.image = this;
      }
      long l = ((NSGraphicsContext)localObject1).id;
      return l;
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  public void internal_dispose_GC(long paramLong, GCData paramGCData)
  {
    long l = paramLong;
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      if (l != 0L)
      {
        NSBitmapImageRep localNSBitmapImageRep = getRepresentation();
        localNSBitmapImageRep.bitmapData();
        NSGraphicsContext localNSGraphicsContext = new NSGraphicsContext(l);
        localNSGraphicsContext.release();
      }
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  public boolean isDisposed()
  {
    return this.handle == null;
  }
  
  public void setBackground(Color paramColor)
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    if (paramColor == null) {
      SWT.error(4);
    }
    if (paramColor.isDisposed()) {
      SWT.error(5);
    }
    if (this.transparentPixel == -1) {
      return;
    }
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      int i = (byte)(this.transparentPixel >> 16 & 0xFF);
      int j = (byte)(this.transparentPixel >> 8 & 0xFF);
      int k = (byte)(this.transparentPixel >> 0 & 0xFF);
      int m = (byte)((int)(paramColor.handle[0] * 255.0D) & 0xFF);
      int n = (byte)((int)(paramColor.handle[1] * 255.0D) & 0xFF);
      int i1 = (byte)((int)(paramColor.handle[2] * 255.0D) & 0xFF);
      NSBitmapImageRep localNSBitmapImageRep = getRepresentation();
      long l1 = localNSBitmapImageRep.bytesPerRow();
      long l2 = localNSBitmapImageRep.bitmapData();
      long l3 = localNSBitmapImageRep.bitmapFormat();
      long l4 = localNSBitmapImageRep.bitsPerPixel();
      int i2;
      int i3;
      int i4;
      if ((l4 == 32L) && ((l3 & 1L) == 0L))
      {
        i2 = 0;
        i3 = 1;
        i4 = 2;
      }
      else
      {
        i2 = 1;
        i3 = 2;
        i4 = 3;
      }
      byte[] arrayOfByte = new byte[(int)l1];
      int i5 = 0;
      for (int i6 = 0; i5 < this.height; i6 = (int)(i6 + l1))
      {
        OS.memmove(arrayOfByte, l2 + i6, l1);
        for (int i7 = 0; i7 < arrayOfByte.length; i7 += 4) {
          if ((arrayOfByte[(i7 + i2)] == i) && (arrayOfByte[(i7 + i3)] == j) && (arrayOfByte[(i7 + i4)] == k))
          {
            arrayOfByte[(i7 + i2)] = m;
            arrayOfByte[(i7 + i3)] = n;
            arrayOfByte[(i7 + i4)] = i1;
          }
        }
        OS.memmove(l2 + i6, arrayOfByte, l1);
        i5++;
      }
      this.transparentPixel = ((m & 0xFF) << 16 | (n & 0xFF) << 8 | i1 & 0xFF);
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  public String toString()
  {
    if (isDisposed()) {
      return "Image {*DISPOSED*}";
    }
    return "Image {" + this.handle + "}";
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/graphics/Image.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */