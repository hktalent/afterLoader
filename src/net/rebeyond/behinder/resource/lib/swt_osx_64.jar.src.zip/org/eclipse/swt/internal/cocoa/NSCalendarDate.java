package org.eclipse.swt.internal.cocoa;

public class NSCalendarDate
  extends NSDate
{
  public NSCalendarDate() {}
  
  public NSCalendarDate(long paramLong)
  {
    super(paramLong);
  }
  
  public NSCalendarDate(id paramid)
  {
    super(paramid);
  }
  
  public static NSCalendarDate calendarDate()
  {
    long l = OS.objc_msgSend(OS.class_NSCalendarDate, OS.sel_calendarDate);
    return l != 0L ? new NSCalendarDate(l) : null;
  }
  
  public static NSCalendarDate dateWithYear(long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5, long paramLong6, NSTimeZone paramNSTimeZone)
  {
    long l = OS.objc_msgSend(OS.class_NSCalendarDate, OS.sel_dateWithYear_month_day_hour_minute_second_timeZone_, paramLong1, paramLong2, paramLong3, paramLong4, paramLong5, paramLong6, paramNSTimeZone != null ? paramNSTimeZone.id : 0L);
    return l != 0L ? new NSCalendarDate(l) : null;
  }
  
  public long dayOfMonth()
  {
    return OS.objc_msgSend(this.id, OS.sel_dayOfMonth);
  }
  
  public long hourOfDay()
  {
    return OS.objc_msgSend(this.id, OS.sel_hourOfDay);
  }
  
  public long minuteOfHour()
  {
    return OS.objc_msgSend(this.id, OS.sel_minuteOfHour);
  }
  
  public long monthOfYear()
  {
    return OS.objc_msgSend(this.id, OS.sel_monthOfYear);
  }
  
  public long secondOfMinute()
  {
    return OS.objc_msgSend(this.id, OS.sel_secondOfMinute);
  }
  
  public NSTimeZone timeZone()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_timeZone);
    return l != 0L ? new NSTimeZone(l) : null;
  }
  
  public long yearOfCommonEra()
  {
    return OS.objc_msgSend(this.id, OS.sel_yearOfCommonEra);
  }
  
  public static NSDate dateWithTimeIntervalSinceNow(double paramDouble)
  {
    long l = OS.objc_msgSend(OS.class_NSCalendarDate, OS.sel_dateWithTimeIntervalSinceNow_, paramDouble);
    return l != 0L ? new NSCalendarDate(l) : null;
  }
  
  public static NSDate distantFuture()
  {
    long l = OS.objc_msgSend(OS.class_NSCalendarDate, OS.sel_distantFuture);
    return l != 0L ? new NSCalendarDate(l) : null;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSCalendarDate.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */