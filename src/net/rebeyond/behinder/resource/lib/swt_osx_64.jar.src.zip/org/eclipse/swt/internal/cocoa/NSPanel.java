package org.eclipse.swt.internal.cocoa;

public class NSPanel
  extends NSWindow
{
  public NSPanel() {}
  
  public NSPanel(long paramLong)
  {
    super(paramLong);
  }
  
  public NSPanel(id paramid)
  {
    super(paramid);
  }
  
  public void setBecomesKeyOnlyIfNeeded(boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_setBecomesKeyOnlyIfNeeded_, paramBoolean);
  }
  
  public void setFloatingPanel(boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_setFloatingPanel_, paramBoolean);
  }
  
  public void setWorksWhenModal(boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_setWorksWhenModal_, paramBoolean);
  }
  
  public boolean worksWhenModal()
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_worksWhenModal);
  }
  
  public static double minFrameWidthWithTitle(NSString paramNSString, long paramLong)
  {
    return OS.objc_msgSend_fpret(OS.class_NSPanel, OS.sel_minFrameWidthWithTitle_styleMask_, paramNSString != null ? paramNSString.id : 0L, paramLong);
  }
  
  public static long windowNumberAtPoint(NSPoint paramNSPoint, long paramLong)
  {
    return OS.objc_msgSend(OS.class_NSPanel, OS.sel_windowNumberAtPoint_belowWindowWithWindowNumber_, paramNSPoint, paramLong);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSPanel.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */