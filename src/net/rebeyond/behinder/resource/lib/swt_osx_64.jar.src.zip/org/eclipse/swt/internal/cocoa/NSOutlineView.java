package org.eclipse.swt.internal.cocoa;

public class NSOutlineView
  extends NSTableView
{
  public NSOutlineView() {}
  
  public NSOutlineView(long paramLong)
  {
    super(paramLong);
  }
  
  public NSOutlineView(id paramid)
  {
    super(paramid);
  }
  
  public void collapseItem(id paramid)
  {
    OS.objc_msgSend(this.id, OS.sel_collapseItem_, paramid != null ? paramid.id : 0L);
  }
  
  public void collapseItem(id paramid, boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_collapseItem_collapseChildren_, paramid != null ? paramid.id : 0L, paramBoolean);
  }
  
  public void expandItem(id paramid)
  {
    OS.objc_msgSend(this.id, OS.sel_expandItem_, paramid != null ? paramid.id : 0L);
  }
  
  public void expandItem(id paramid, boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_expandItem_expandChildren_, paramid != null ? paramid.id : 0L, paramBoolean);
  }
  
  public NSRect frameOfOutlineCellAtRow(long paramLong)
  {
    NSRect localNSRect = new NSRect();
    OS.objc_msgSend_stret(localNSRect, this.id, OS.sel_frameOfOutlineCellAtRow_, paramLong);
    return localNSRect;
  }
  
  public double indentationPerLevel()
  {
    return OS.objc_msgSend_fpret(this.id, OS.sel_indentationPerLevel);
  }
  
  public boolean isItemExpanded(id paramid)
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_isItemExpanded_, paramid != null ? paramid.id : 0L);
  }
  
  public id itemAtRow(long paramLong)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_itemAtRow_, paramLong);
    return l != 0L ? new id(l) : null;
  }
  
  public long levelForItem(id paramid)
  {
    return OS.objc_msgSend(this.id, OS.sel_levelForItem_, paramid != null ? paramid.id : 0L);
  }
  
  public NSTableColumn outlineTableColumn()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_outlineTableColumn);
    return l != 0L ? new NSTableColumn(l) : null;
  }
  
  public void reloadItem(id paramid, boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_reloadItem_reloadChildren_, paramid != null ? paramid.id : 0L, paramBoolean);
  }
  
  public long rowForItem(id paramid)
  {
    return OS.objc_msgSend(this.id, OS.sel_rowForItem_, paramid != null ? paramid.id : 0L);
  }
  
  public void setAutoresizesOutlineColumn(boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_setAutoresizesOutlineColumn_, paramBoolean);
  }
  
  public void setAutosaveExpandedItems(boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_setAutosaveExpandedItems_, paramBoolean);
  }
  
  public void setDropItem(id paramid, long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_setDropItem_dropChildIndex_, paramid != null ? paramid.id : 0L, paramLong);
  }
  
  public void setOutlineTableColumn(NSTableColumn paramNSTableColumn)
  {
    OS.objc_msgSend(this.id, OS.sel_setOutlineTableColumn_, paramNSTableColumn != null ? paramNSTableColumn.id : 0L);
  }
  
  public static long cellClass()
  {
    return OS.objc_msgSend(OS.class_NSOutlineView, OS.sel_cellClass);
  }
  
  public static void setCellClass(long paramLong)
  {
    OS.objc_msgSend(OS.class_NSOutlineView, OS.sel_setCellClass_, paramLong);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSOutlineView.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */