package org.eclipse.swt.internal.cocoa;

public class NSAffineTransformStruct
{
  public double m11;
  public double m12;
  public double m21;
  public double m22;
  public double tX;
  public double tY;
  public static final int sizeof = ;
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSAffineTransformStruct.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */