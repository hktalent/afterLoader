package org.eclipse.swt.internal.cocoa;

public class NSText
  extends NSView
{
  public NSText() {}
  
  public NSText(long paramLong)
  {
    super(paramLong);
  }
  
  public NSText(id paramid)
  {
    super(paramid);
  }
  
  public void copy(id paramid)
  {
    OS.objc_msgSend(this.id, OS.sel_copy_, paramid != null ? paramid.id : 0L);
  }
  
  public void cut(id paramid)
  {
    OS.objc_msgSend(this.id, OS.sel_cut_, paramid != null ? paramid.id : 0L);
  }
  
  public id delegate()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_delegate);
    return l != 0L ? new id(l) : null;
  }
  
  public NSFont font()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_font);
    return l != 0L ? new NSFont(l) : null;
  }
  
  public boolean isFieldEditor()
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_isFieldEditor);
  }
  
  public void paste(id paramid)
  {
    OS.objc_msgSend(this.id, OS.sel_paste_, paramid != null ? paramid.id : 0L);
  }
  
  public void replaceCharactersInRange(NSRange paramNSRange, NSString paramNSString)
  {
    OS.objc_msgSend(this.id, OS.sel_replaceCharactersInRange_withString_, paramNSRange, paramNSString != null ? paramNSString.id : 0L);
  }
  
  public void scrollRangeToVisible(NSRange paramNSRange)
  {
    OS.objc_msgSend(this.id, OS.sel_scrollRangeToVisible_, paramNSRange);
  }
  
  public void selectAll(id paramid)
  {
    OS.objc_msgSend(this.id, OS.sel_selectAll_, paramid != null ? paramid.id : 0L);
  }
  
  public NSRange selectedRange()
  {
    NSRange localNSRange = new NSRange();
    OS.objc_msgSend_stret(localNSRange, this.id, OS.sel_selectedRange);
    return localNSRange;
  }
  
  public void setAlignment(long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_setAlignment_, paramLong);
  }
  
  public void setBackgroundColor(NSColor paramNSColor)
  {
    OS.objc_msgSend(this.id, OS.sel_setBackgroundColor_, paramNSColor != null ? paramNSColor.id : 0L);
  }
  
  public void setBaseWritingDirection(long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_setBaseWritingDirection_, paramLong);
  }
  
  public void setDelegate(id paramid)
  {
    OS.objc_msgSend(this.id, OS.sel_setDelegate_, paramid != null ? paramid.id : 0L);
  }
  
  public void setDrawsBackground(boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_setDrawsBackground_, paramBoolean);
  }
  
  public void setEditable(boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_setEditable_, paramBoolean);
  }
  
  public void setFont(NSFont paramNSFont)
  {
    OS.objc_msgSend(this.id, OS.sel_setFont_, paramNSFont != null ? paramNSFont.id : 0L);
  }
  
  public void setHorizontallyResizable(boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_setHorizontallyResizable_, paramBoolean);
  }
  
  public void setMaxSize(NSSize paramNSSize)
  {
    OS.objc_msgSend(this.id, OS.sel_setMaxSize_, paramNSSize);
  }
  
  public void setMinSize(NSSize paramNSSize)
  {
    OS.objc_msgSend(this.id, OS.sel_setMinSize_, paramNSSize);
  }
  
  public void setSelectable(boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_setSelectable_, paramBoolean);
  }
  
  public void setSelectedRange(NSRange paramNSRange)
  {
    OS.objc_msgSend(this.id, OS.sel_setSelectedRange_, paramNSRange);
  }
  
  public void setString(NSString paramNSString)
  {
    OS.objc_msgSend(this.id, OS.sel_setString_, paramNSString != null ? paramNSString.id : 0L);
  }
  
  public void setTextColor(NSColor paramNSColor)
  {
    OS.objc_msgSend(this.id, OS.sel_setTextColor_, paramNSColor != null ? paramNSColor.id : 0L);
  }
  
  public void sizeToFit()
  {
    OS.objc_msgSend(this.id, OS.sel_sizeToFit);
  }
  
  public NSString string()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_string);
    return l != 0L ? new NSString(l) : null;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSText.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */