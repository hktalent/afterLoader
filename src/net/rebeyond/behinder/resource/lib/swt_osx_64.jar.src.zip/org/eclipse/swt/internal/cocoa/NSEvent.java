package org.eclipse.swt.internal.cocoa;

public class NSEvent
  extends NSObject
{
  public NSEvent() {}
  
  public NSEvent(long paramLong)
  {
    super(paramLong);
  }
  
  public NSEvent(id paramid)
  {
    super(paramid);
  }
  
  public long CGEvent()
  {
    return OS.objc_msgSend(this.id, OS.sel_CGEvent);
  }
  
  public long buttonNumber()
  {
    return OS.objc_msgSend(this.id, OS.sel_buttonNumber);
  }
  
  public NSString characters()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_characters);
    return l != 0L ? new NSString(l) : null;
  }
  
  public NSString charactersIgnoringModifiers()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_charactersIgnoringModifiers);
    return l != 0L ? new NSString(l) : null;
  }
  
  public long clickCount()
  {
    return OS.objc_msgSend(this.id, OS.sel_clickCount);
  }
  
  public double deltaX()
  {
    return OS.objc_msgSend_fpret(this.id, OS.sel_deltaX);
  }
  
  public double deltaY()
  {
    return OS.objc_msgSend_fpret(this.id, OS.sel_deltaY);
  }
  
  public static NSEvent enterExitEventWithType(long paramLong1, NSPoint paramNSPoint, long paramLong2, double paramDouble, long paramLong3, NSGraphicsContext paramNSGraphicsContext, long paramLong4, long paramLong5, long paramLong6)
  {
    long l = OS.objc_msgSend(OS.class_NSEvent, OS.sel_enterExitEventWithType_location_modifierFlags_timestamp_windowNumber_context_eventNumber_trackingNumber_userData_, paramLong1, paramNSPoint, paramLong2, paramDouble, paramLong3, paramNSGraphicsContext != null ? paramNSGraphicsContext.id : 0L, paramLong4, paramLong5, paramLong6);
    return l != 0L ? new NSEvent(l) : null;
  }
  
  public short keyCode()
  {
    return (short)(int)OS.objc_msgSend(this.id, OS.sel_keyCode);
  }
  
  public NSPoint locationInWindow()
  {
    NSPoint localNSPoint = new NSPoint();
    OS.objc_msgSend_stret(localNSPoint, this.id, OS.sel_locationInWindow);
    return localNSPoint;
  }
  
  public double magnification()
  {
    return OS.objc_msgSend_fpret(this.id, OS.sel_magnification);
  }
  
  public long modifierFlags()
  {
    return OS.objc_msgSend(this.id, OS.sel_modifierFlags);
  }
  
  public static NSPoint mouseLocation()
  {
    NSPoint localNSPoint = new NSPoint();
    OS.objc_msgSend_stret(localNSPoint, OS.class_NSEvent, OS.sel_mouseLocation);
    return localNSPoint;
  }
  
  public static NSEvent otherEventWithType(long paramLong1, NSPoint paramNSPoint, long paramLong2, double paramDouble, long paramLong3, NSGraphicsContext paramNSGraphicsContext, short paramShort, long paramLong4, long paramLong5)
  {
    long l = OS.objc_msgSend(OS.class_NSEvent, OS.sel_otherEventWithType_location_modifierFlags_timestamp_windowNumber_context_subtype_data1_data2_, paramLong1, paramNSPoint, paramLong2, paramDouble, paramLong3, paramNSGraphicsContext != null ? paramNSGraphicsContext.id : 0L, paramShort, paramLong4, paramLong5);
    return l != 0L ? new NSEvent(l) : null;
  }
  
  public float rotation()
  {
    return OS.objc_msgSend_floatret(this.id, OS.sel_rotation);
  }
  
  public double timestamp()
  {
    return OS.objc_msgSend_fpret(this.id, OS.sel_timestamp);
  }
  
  public NSSet touchesMatchingPhase(long paramLong, NSView paramNSView)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_touchesMatchingPhase_inView_, paramLong, paramNSView != null ? paramNSView.id : 0L);
    return l != 0L ? new NSSet(l) : null;
  }
  
  public long type()
  {
    return OS.objc_msgSend(this.id, OS.sel_type);
  }
  
  public NSWindow window()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_window);
    return l != 0L ? new NSWindow(l) : null;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSEvent.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */