package org.eclipse.swt.internal.cocoa;

public class DOMKeyboardEvent
  extends DOMUIEvent
{
  public DOMKeyboardEvent() {}
  
  public DOMKeyboardEvent(long paramLong)
  {
    super(paramLong);
  }
  
  public DOMKeyboardEvent(id paramid)
  {
    super(paramid);
  }
  
  public boolean altKey()
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_altKey);
  }
  
  public int charCode()
  {
    return (int)OS.objc_msgSend(this.id, OS.sel_charCode);
  }
  
  public boolean ctrlKey()
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_ctrlKey);
  }
  
  public int keyCode()
  {
    return (int)OS.objc_msgSend(this.id, OS.sel_keyCode);
  }
  
  public boolean metaKey()
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_metaKey);
  }
  
  public boolean shiftKey()
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_shiftKey);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/DOMKeyboardEvent.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */