package org.eclipse.swt.awt;

import java.awt.Canvas;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Frame;
import java.awt.Toolkit;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.awt.event.WindowEvent;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.internal.Library;
import org.eclipse.swt.internal.cocoa.NSView;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Shell;

public class SWT_AWT
{
  public static String embeddedFrameClass;
  static String EMBEDDED_FRAME_KEY = "org.eclipse.swt.awt.SWT_AWT.embeddedFrame";
  static final String RUN_AWT_INVOKE_LATER_KEY = "org.eclipse.swt.internal.runAWTInvokeLater";
  static final String JDK16_FRAME = "apple.awt.CEmbeddedFrame";
  static final String JDK17_FRAME = "sun.lwawt.macosx.CViewEmbeddedFrame";
  static boolean loaded;
  static boolean swingInitialized;
  
  static final native long getAWTHandle(Canvas paramCanvas);
  
  static synchronized void loadLibrary()
  {
    if (loaded) {
      return;
    }
    loaded = true;
    Toolkit.getDefaultToolkit();
    try
    {
      System.loadLibrary("jawt");
    }
    catch (Throwable localThrowable) {}
    Library.loadLibrary("swt-awt");
  }
  
  static synchronized void initializeSwing()
  {
    if (swingInitialized) {
      return;
    }
    swingInitialized = true;
    try
    {
      Class[] arrayOfClass = new Class[0];
      Object[] arrayOfObject = new Object[0];
      Class localClass = Class.forName("javax.swing.UIManager");
      Method localMethod = localClass.getMethod("getDefaults", arrayOfClass);
      if (localMethod != null) {
        localMethod.invoke(localClass, arrayOfObject);
      }
    }
    catch (Throwable localThrowable) {}
  }
  
  public static Frame getFrame(Composite paramComposite)
  {
    if (paramComposite == null) {
      SWT.error(4);
    }
    if ((paramComposite.getStyle() & 0x1000000) == 0) {
      return null;
    }
    return (Frame)paramComposite.getData(EMBEDDED_FRAME_KEY);
  }
  
  public static Frame new_Frame(Composite paramComposite)
  {
    if (paramComposite == null) {
      SWT.error(4);
    }
    if ((paramComposite.getStyle() & 0x1000000) == 0) {
      SWT.error(5);
    }
    final long l = paramComposite.view.id;
    Class[] arrayOfClass = new Class[1];
    try
    {
      String str = embeddedFrameClass != null ? embeddedFrameClass : "apple.awt.CEmbeddedFrame";
      if (embeddedFrameClass == null) {
        arrayOfClass[0] = Class.forName(str, true, ClassLoader.getSystemClassLoader());
      } else {
        arrayOfClass[0] = Class.forName(str);
      }
    }
    catch (ClassNotFoundException localClassNotFoundException1)
    {
      try
      {
        arrayOfClass[0] = Class.forName("sun.lwawt.macosx.CViewEmbeddedFrame");
      }
      catch (ClassNotFoundException localClassNotFoundException2)
      {
        SWT.error(20, localClassNotFoundException2);
      }
    }
    catch (Throwable localThrowable)
    {
      SWT.error(1, localThrowable, " [Error while starting AWT]");
    }
    initializeSwing();
    final Frame[] arrayOfFrame = new Frame[1];
    Throwable[] arrayOfThrowable = new Throwable[1];
    Runnable local1 = new Runnable()
    {
      boolean run;
      
      public void run()
      {
        if (this.run) {
          return;
        }
        this.run = true;
        Constructor localConstructor = null;
        try
        {
          localConstructor = this.val$clazz[0].getConstructor(new Class[] { Long.TYPE });
          arrayOfFrame[0] = ((Frame)(Frame)localConstructor.newInstance(new Object[] { new Long(l) }));
          arrayOfFrame[0].addNotify();
        }
        catch (Throwable localThrowable)
        {
          this.val$exception[0] = localThrowable;
        }
      }
    };
    if ((EventQueue.isDispatchThread()) || (paramComposite.getDisplay().getSyncThread() != null))
    {
      local1.run();
    }
    else
    {
      EventQueue.invokeLater(local1);
      localObject = paramComposite.getDisplay();
      while ((arrayOfFrame[0] == null) && (arrayOfThrowable[0] == null))
      {
        ((Display)localObject).setData("org.eclipse.swt.internal.runAWTInvokeLater", new Boolean(true));
        Boolean localBoolean = (Boolean)((Display)localObject).getData("org.eclipse.swt.internal.runAWTInvokeLater");
        if ((localBoolean != null) && (!localBoolean.booleanValue())) {
          local1.run();
        }
      }
    }
    if (arrayOfThrowable[0] != null) {
      SWT.error(20, arrayOfThrowable[0]);
    }
    final Object localObject = arrayOfFrame[0];
    final boolean bool = "sun.lwawt.macosx.CViewEmbeddedFrame".equals(localObject.getClass().getName());
    paramComposite.setData(EMBEDDED_FRAME_KEY, localObject);
    final Listener local2 = new Listener()
    {
      public void handleEvent(Event paramAnonymousEvent)
      {
        switch (paramAnonymousEvent.type)
        {
        case 20: 
          EventQueue.invokeLater(new Runnable()
          {
            public void run()
            {
              SWT_AWT.2.this.val$frame.dispatchEvent(new WindowEvent(SWT_AWT.2.this.val$frame, 204));
            }
          });
          break;
        case 19: 
          EventQueue.invokeLater(new Runnable()
          {
            public void run()
            {
              SWT_AWT.2.this.val$frame.dispatchEvent(new WindowEvent(SWT_AWT.2.this.val$frame, 203));
            }
          });
        }
      }
    };
    Shell localShell = paramComposite.getShell();
    localShell.addListener(20, local2);
    localShell.addListener(19, local2);
    final Display localDisplay = paramComposite.getDisplay();
    localDisplay.addListener(12, new Listener()
    {
      public void handleEvent(Event paramAnonymousEvent)
      {
        while ((this.val$frame.isDisplayable()) && (!localDisplay.isDisposed())) {
          if (!localDisplay.readAndDispatch()) {
            localDisplay.sleep();
          }
        }
        if (!localDisplay.isDisposed()) {
          localDisplay.removeListener(12, this);
        }
      }
    });
    Listener local4 = new Listener()
    {
      public void handleEvent(Event paramAnonymousEvent)
      {
        switch (paramAnonymousEvent.type)
        {
        case 12: 
          Shell localShell = this.val$parent.getShell();
          localShell.removeListener(20, local2);
          localShell.removeListener(19, local2);
          if (bool)
          {
            localShell.removeListener(26, this);
            localShell.removeListener(27, this);
          }
          this.val$parent.setVisible(false);
          EventQueue.invokeLater(new Runnable()
          {
            public void run()
            {
              try
              {
                SWT_AWT.4.this.val$frame.dispose();
              }
              catch (Throwable localThrowable) {}
            }
          });
          break;
        case 26: 
          if (!this.val$parent.isFocusControl()) {
            return;
          }
        case 15: 
          EventQueue.invokeLater(new Runnable()
          {
            public void run()
            {
              if (SWT_AWT.4.this.val$frame.isActive()) {
                return;
              }
              try
              {
                Class localClass = SWT_AWT.4.this.val$frame.getClass();
                Method localMethod = localClass.getMethod("synthesizeWindowActivation", new Class[] { Boolean.TYPE });
                if (localMethod != null) {
                  localMethod.invoke(SWT_AWT.4.this.val$frame, new Object[] { new Boolean(true) });
                }
              }
              catch (Throwable localThrowable)
              {
                localThrowable.printStackTrace();
              }
            }
          });
          break;
        case 16: 
        case 27: 
          EventQueue.invokeLater(new Runnable()
          {
            public void run()
            {
              if (!SWT_AWT.4.this.val$frame.isActive()) {
                return;
              }
              try
              {
                Class localClass = SWT_AWT.4.this.val$frame.getClass();
                Method localMethod = localClass.getMethod("synthesizeWindowActivation", new Class[] { Boolean.TYPE });
                if (localMethod != null) {
                  localMethod.invoke(SWT_AWT.4.this.val$frame, new Object[] { new Boolean(false) });
                }
              }
              catch (Throwable localThrowable)
              {
                localThrowable.printStackTrace();
              }
            }
          });
        }
      }
    };
    paramComposite.addListener(15, local4);
    if (bool)
    {
      paramComposite.addListener(16, local4);
      localShell.addListener(26, local4);
      localShell.addListener(27, local4);
    }
    else
    {
      paramComposite.addListener(27, local4);
    }
    paramComposite.addListener(12, local4);
    localDisplay.asyncExec(new Runnable()
    {
      public void run()
      {
        if (this.val$parent.isDisposed()) {
          return;
        }
        final Rectangle localRectangle = this.val$parent.getClientArea();
        if (bool) {
          try
          {
            Method localMethod = localObject.getClass().getMethod("validateWithBounds", new Class[] { Integer.TYPE, Integer.TYPE, Integer.TYPE, Integer.TYPE });
            if (localMethod != null) {
              localMethod.invoke(localObject, new Object[] { new Integer(localRectangle.x), new Integer(localRectangle.y), new Integer(localRectangle.width), new Integer(localRectangle.height) });
            }
          }
          catch (Throwable localThrowable)
          {
            localThrowable.printStackTrace();
          }
        } else {
          EventQueue.invokeLater(new Runnable()
          {
            public void run()
            {
              SWT_AWT.5.this.val$frame.setSize(localRectangle.width, localRectangle.height);
              SWT_AWT.5.this.val$frame.validate();
              SWT_AWT.5.this.val$frame.setVisible(false);
              SWT_AWT.5.this.val$frame.setVisible(true);
            }
          });
        }
      }
    });
    return (Frame)localObject;
  }
  
  public static Shell new_Shell(Display paramDisplay, final Canvas paramCanvas)
  {
    if (paramDisplay == null) {
      SWT.error(4);
    }
    if (paramCanvas == null) {
      SWT.error(4);
    }
    long l = 0L;
    try
    {
      loadLibrary();
      l = getAWTHandle(paramCanvas);
    }
    catch (Throwable localThrowable)
    {
      SWT.error(20, localThrowable);
    }
    if (l == 0L) {
      SWT.error(5, null, " [peer not created]");
    }
    final Shell localShell = Shell.cocoa_new(paramDisplay, l);
    final ComponentAdapter local6 = new ComponentAdapter()
    {
      public void componentResized(ComponentEvent paramAnonymousComponentEvent)
      {
        this.val$display.asyncExec(new Runnable()
        {
          public void run()
          {
            if (SWT_AWT.6.this.val$shell.isDisposed()) {
              return;
            }
            Dimension localDimension = SWT_AWT.6.this.val$parent.getSize();
            SWT_AWT.6.this.val$shell.setSize(localDimension.width, localDimension.height);
          }
        });
      }
    };
    paramCanvas.addComponentListener(local6);
    localShell.addListener(12, new Listener()
    {
      public void handleEvent(Event paramAnonymousEvent)
      {
        this.val$parent.removeComponentListener(local6);
      }
    });
    localShell.setVisible(true);
    return localShell;
  }
  
  static
  {
    System.setProperty("apple.awt.usingSWT", "true");
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/awt/SWT_AWT.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */