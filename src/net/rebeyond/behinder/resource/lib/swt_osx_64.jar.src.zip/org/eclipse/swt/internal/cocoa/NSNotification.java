package org.eclipse.swt.internal.cocoa;

public class NSNotification
  extends NSObject
{
  public NSNotification() {}
  
  public NSNotification(long paramLong)
  {
    super(paramLong);
  }
  
  public NSNotification(id paramid)
  {
    super(paramid);
  }
  
  public id object()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_object);
    return l != 0L ? new id(l) : null;
  }
  
  public NSDictionary userInfo()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_userInfo);
    return l != 0L ? new NSDictionary(l) : null;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSNotification.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */