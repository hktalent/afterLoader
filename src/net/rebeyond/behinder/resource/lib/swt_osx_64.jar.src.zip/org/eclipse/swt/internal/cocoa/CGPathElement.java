package org.eclipse.swt.internal.cocoa;

public class CGPathElement
{
  public int type;
  public long points;
  public static final int sizeof = ;
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/CGPathElement.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */