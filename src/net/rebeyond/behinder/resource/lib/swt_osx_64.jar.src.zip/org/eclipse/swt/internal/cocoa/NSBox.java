package org.eclipse.swt.internal.cocoa;

public class NSBox
  extends NSView
{
  public NSBox() {}
  
  public NSBox(long paramLong)
  {
    super(paramLong);
  }
  
  public NSBox(id paramid)
  {
    super(paramid);
  }
  
  public double borderWidth()
  {
    return OS.objc_msgSend_fpret(this.id, OS.sel_borderWidth);
  }
  
  public NSView contentView()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_contentView);
    return l != 0L ? new NSView(l) : null;
  }
  
  public NSSize contentViewMargins()
  {
    NSSize localNSSize = new NSSize();
    OS.objc_msgSend_stret(localNSSize, this.id, OS.sel_contentViewMargins);
    return localNSSize;
  }
  
  public void setBorderType(long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_setBorderType_, paramLong);
  }
  
  public void setBorderWidth(double paramDouble)
  {
    OS.objc_msgSend(this.id, OS.sel_setBorderWidth_, paramDouble);
  }
  
  public void setBoxType(long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_setBoxType_, paramLong);
  }
  
  public void setContentView(NSView paramNSView)
  {
    OS.objc_msgSend(this.id, OS.sel_setContentView_, paramNSView != null ? paramNSView.id : 0L);
  }
  
  public void setContentViewMargins(NSSize paramNSSize)
  {
    OS.objc_msgSend(this.id, OS.sel_setContentViewMargins_, paramNSSize);
  }
  
  public void setFillColor(NSColor paramNSColor)
  {
    OS.objc_msgSend(this.id, OS.sel_setFillColor_, paramNSColor != null ? paramNSColor.id : 0L);
  }
  
  public void setFrameFromContentFrame(NSRect paramNSRect)
  {
    OS.objc_msgSend(this.id, OS.sel_setFrameFromContentFrame_, paramNSRect);
  }
  
  public void setTitle(NSString paramNSString)
  {
    OS.objc_msgSend(this.id, OS.sel_setTitle_, paramNSString != null ? paramNSString.id : 0L);
  }
  
  public void setTitleFont(NSFont paramNSFont)
  {
    OS.objc_msgSend(this.id, OS.sel_setTitleFont_, paramNSFont != null ? paramNSFont.id : 0L);
  }
  
  public void setTitlePosition(long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_setTitlePosition_, paramLong);
  }
  
  public void sizeToFit()
  {
    OS.objc_msgSend(this.id, OS.sel_sizeToFit);
  }
  
  public NSCell titleCell()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_titleCell);
    return l != 0L ? new NSCell(l) : null;
  }
  
  public NSFont titleFont()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_titleFont);
    return l != 0L ? new NSFont(l) : null;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSBox.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */