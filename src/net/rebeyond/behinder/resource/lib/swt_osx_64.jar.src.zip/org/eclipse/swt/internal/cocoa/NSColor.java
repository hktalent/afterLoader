package org.eclipse.swt.internal.cocoa;

public class NSColor
  extends NSObject
{
  public NSColor() {}
  
  public NSColor(long paramLong)
  {
    super(paramLong);
  }
  
  public NSColor(id paramid)
  {
    super(paramid);
  }
  
  public double alphaComponent()
  {
    return OS.objc_msgSend_fpret(this.id, OS.sel_alphaComponent);
  }
  
  public static NSColor alternateSelectedControlColor()
  {
    long l = OS.objc_msgSend(OS.class_NSColor, OS.sel_alternateSelectedControlColor);
    return l != 0L ? new NSColor(l) : null;
  }
  
  public static NSColor alternateSelectedControlTextColor()
  {
    long l = OS.objc_msgSend(OS.class_NSColor, OS.sel_alternateSelectedControlTextColor);
    return l != 0L ? new NSColor(l) : null;
  }
  
  public static NSColor blackColor()
  {
    long l = OS.objc_msgSend(OS.class_NSColor, OS.sel_blackColor);
    return l != 0L ? new NSColor(l) : null;
  }
  
  public double blueComponent()
  {
    return OS.objc_msgSend_fpret(this.id, OS.sel_blueComponent);
  }
  
  public static NSColor clearColor()
  {
    long l = OS.objc_msgSend(OS.class_NSColor, OS.sel_clearColor);
    return l != 0L ? new NSColor(l) : null;
  }
  
  public NSColorSpace colorSpace()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_colorSpace);
    return l != 0L ? new NSColorSpace(l) : null;
  }
  
  public NSColor colorUsingColorSpaceName(NSString paramNSString)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_colorUsingColorSpaceName_, paramNSString != null ? paramNSString.id : 0L);
    return l != 0L ? new NSColor(l) : l == this.id ? this : null;
  }
  
  public static NSColor colorWithCalibratedRed(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4)
  {
    long l = OS.objc_msgSend(OS.class_NSColor, OS.sel_colorWithCalibratedRed_green_blue_alpha_, paramDouble1, paramDouble2, paramDouble3, paramDouble4);
    return l != 0L ? new NSColor(l) : null;
  }
  
  public static NSColor colorWithDeviceRed(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4)
  {
    long l = OS.objc_msgSend(OS.class_NSColor, OS.sel_colorWithDeviceRed_green_blue_alpha_, paramDouble1, paramDouble2, paramDouble3, paramDouble4);
    return l != 0L ? new NSColor(l) : null;
  }
  
  public static NSColor colorWithPatternImage(NSImage paramNSImage)
  {
    long l = OS.objc_msgSend(OS.class_NSColor, OS.sel_colorWithPatternImage_, paramNSImage != null ? paramNSImage.id : 0L);
    return l != 0L ? new NSColor(l) : null;
  }
  
  public static NSColor controlBackgroundColor()
  {
    long l = OS.objc_msgSend(OS.class_NSColor, OS.sel_controlBackgroundColor);
    return l != 0L ? new NSColor(l) : null;
  }
  
  public static NSColor controlDarkShadowColor()
  {
    long l = OS.objc_msgSend(OS.class_NSColor, OS.sel_controlDarkShadowColor);
    return l != 0L ? new NSColor(l) : null;
  }
  
  public static NSColor controlHighlightColor()
  {
    long l = OS.objc_msgSend(OS.class_NSColor, OS.sel_controlHighlightColor);
    return l != 0L ? new NSColor(l) : null;
  }
  
  public static NSColor controlLightHighlightColor()
  {
    long l = OS.objc_msgSend(OS.class_NSColor, OS.sel_controlLightHighlightColor);
    return l != 0L ? new NSColor(l) : null;
  }
  
  public static NSColor controlShadowColor()
  {
    long l = OS.objc_msgSend(OS.class_NSColor, OS.sel_controlShadowColor);
    return l != 0L ? new NSColor(l) : null;
  }
  
  public static NSColor controlTextColor()
  {
    long l = OS.objc_msgSend(OS.class_NSColor, OS.sel_controlTextColor);
    return l != 0L ? new NSColor(l) : null;
  }
  
  public static NSColor disabledControlTextColor()
  {
    long l = OS.objc_msgSend(OS.class_NSColor, OS.sel_disabledControlTextColor);
    return l != 0L ? new NSColor(l) : null;
  }
  
  public void getComponents(double[] paramArrayOfDouble)
  {
    OS.objc_msgSend(this.id, OS.sel_getComponents_, paramArrayOfDouble);
  }
  
  public double greenComponent()
  {
    return OS.objc_msgSend_fpret(this.id, OS.sel_greenComponent);
  }
  
  public long numberOfComponents()
  {
    return OS.objc_msgSend(this.id, OS.sel_numberOfComponents);
  }
  
  public double redComponent()
  {
    return OS.objc_msgSend_fpret(this.id, OS.sel_redComponent);
  }
  
  public static NSColor secondarySelectedControlColor()
  {
    long l = OS.objc_msgSend(OS.class_NSColor, OS.sel_secondarySelectedControlColor);
    return l != 0L ? new NSColor(l) : null;
  }
  
  public static NSColor selectedControlColor()
  {
    long l = OS.objc_msgSend(OS.class_NSColor, OS.sel_selectedControlColor);
    return l != 0L ? new NSColor(l) : null;
  }
  
  public static NSColor selectedControlTextColor()
  {
    long l = OS.objc_msgSend(OS.class_NSColor, OS.sel_selectedControlTextColor);
    return l != 0L ? new NSColor(l) : null;
  }
  
  public static NSColor selectedTextBackgroundColor()
  {
    long l = OS.objc_msgSend(OS.class_NSColor, OS.sel_selectedTextBackgroundColor);
    return l != 0L ? new NSColor(l) : null;
  }
  
  public static NSColor selectedTextColor()
  {
    long l = OS.objc_msgSend(OS.class_NSColor, OS.sel_selectedTextColor);
    return l != 0L ? new NSColor(l) : null;
  }
  
  public void set()
  {
    OS.objc_msgSend(this.id, OS.sel_set);
  }
  
  public void setFill()
  {
    OS.objc_msgSend(this.id, OS.sel_setFill);
  }
  
  public void setStroke()
  {
    OS.objc_msgSend(this.id, OS.sel_setStroke);
  }
  
  public static NSColor textBackgroundColor()
  {
    long l = OS.objc_msgSend(OS.class_NSColor, OS.sel_textBackgroundColor);
    return l != 0L ? new NSColor(l) : null;
  }
  
  public static NSColor textColor()
  {
    long l = OS.objc_msgSend(OS.class_NSColor, OS.sel_textColor);
    return l != 0L ? new NSColor(l) : null;
  }
  
  public static NSColor windowBackgroundColor()
  {
    long l = OS.objc_msgSend(OS.class_NSColor, OS.sel_windowBackgroundColor);
    return l != 0L ? new NSColor(l) : null;
  }
  
  public static NSColor windowFrameColor()
  {
    long l = OS.objc_msgSend(OS.class_NSColor, OS.sel_windowFrameColor);
    return l != 0L ? new NSColor(l) : null;
  }
  
  public static NSColor windowFrameTextColor()
  {
    long l = OS.objc_msgSend(OS.class_NSColor, OS.sel_windowFrameTextColor);
    return l != 0L ? new NSColor(l) : null;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSColor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */