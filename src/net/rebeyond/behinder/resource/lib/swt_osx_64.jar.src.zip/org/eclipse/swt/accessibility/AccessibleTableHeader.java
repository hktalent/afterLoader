package org.eclipse.swt.accessibility;

import java.util.Vector;
import org.eclipse.swt.internal.cocoa.NSArray;
import org.eclipse.swt.internal.cocoa.NSPoint;
import org.eclipse.swt.internal.cocoa.NSRect;
import org.eclipse.swt.internal.cocoa.NSScreen;
import org.eclipse.swt.internal.cocoa.NSSize;
import org.eclipse.swt.internal.cocoa.NSValue;

class AccessibleTableHeader
  extends Accessible
{
  public AccessibleTableHeader(Accessible paramAccessible, int paramInt)
  {
    super(paramAccessible);
    this.index = paramInt;
    addAccessibleControlListener(new AccessibleControlAdapter()
    {
      public void getChildren(AccessibleControlEvent paramAnonymousAccessibleControlEvent)
      {
        int i = Math.max(1, AccessibleTableHeader.this.parent.getColumnCount());
        Accessible[] arrayOfAccessible = new Accessible[i];
        AccessibleControlEvent localAccessibleControlEvent = new AccessibleControlEvent(this);
        for (int j = 0; j < i; j++)
        {
          localAccessibleControlEvent.childID = j;
          localAccessibleControlEvent.detail = -4;
          for (int k = 0; k < AccessibleTableHeader.this.parent.accessibleControlListeners.size(); k++)
          {
            AccessibleControlListener localAccessibleControlListener = (AccessibleControlListener)AccessibleTableHeader.this.parent.accessibleControlListeners.elementAt(k);
            localAccessibleControlListener.getChild(localAccessibleControlEvent);
          }
          localAccessibleControlEvent.accessible.parent = AccessibleTableHeader.this;
          arrayOfAccessible[j] = localAccessibleControlEvent.accessible;
        }
        paramAnonymousAccessibleControlEvent.children = arrayOfAccessible;
      }
      
      public void getChildCount(AccessibleControlEvent paramAnonymousAccessibleControlEvent)
      {
        paramAnonymousAccessibleControlEvent.detail = Math.max(1, AccessibleTableHeader.this.parent.getColumnCount());
      }
      
      public void getLocation(AccessibleControlEvent paramAnonymousAccessibleControlEvent)
      {
        int i = Math.max(1, AccessibleTableHeader.this.parent.getColumnCount());
        Accessible[] arrayOfAccessible = new Accessible[i];
        AccessibleControlEvent localAccessibleControlEvent = new AccessibleControlEvent(this);
        for (int j = 0; j < i; j++)
        {
          localAccessibleControlEvent.childID = j;
          localAccessibleControlEvent.detail = -4;
          for (int k = 0; k < AccessibleTableHeader.this.parent.accessibleControlListeners.size(); k++)
          {
            AccessibleControlListener localAccessibleControlListener = (AccessibleControlListener)AccessibleTableHeader.this.parent.accessibleControlListeners.elementAt(k);
            localAccessibleControlListener.getChild(localAccessibleControlEvent);
          }
          localAccessibleControlEvent.accessible.parent = AccessibleTableHeader.this;
          arrayOfAccessible[j] = localAccessibleControlEvent.accessible;
        }
        NSValue localNSValue = (NSValue)arrayOfAccessible[0].getPositionAttribute(-1);
        NSPoint localNSPoint = localNSValue.pointValue();
        int m = 0;
        int n = 0;
        for (int i1 = 0; i1 < arrayOfAccessible.length; i1++)
        {
          localObject1 = (NSValue)arrayOfAccessible[i1].getSizeAttribute(-1);
          localObject2 = ((NSValue)localObject1).sizeValue();
          if (((NSSize)localObject2).height > m) {
            m = (int)((NSSize)localObject2).height;
          }
          n = (int)(n + ((NSSize)localObject2).width);
        }
        paramAnonymousAccessibleControlEvent.x = ((int)localNSPoint.x);
        NSArray localNSArray = NSScreen.screens();
        Object localObject1 = new NSScreen(localNSArray.objectAtIndex(0L));
        Object localObject2 = ((NSScreen)localObject1).frame();
        paramAnonymousAccessibleControlEvent.y = ((int)(((NSRect)localObject2).height - localNSPoint.y - m));
        paramAnonymousAccessibleControlEvent.width = n;
        paramAnonymousAccessibleControlEvent.height = m;
      }
      
      public void getRole(AccessibleControlEvent paramAnonymousAccessibleControlEvent)
      {
        paramAnonymousAccessibleControlEvent.detail = 25;
      }
    });
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/accessibility/AccessibleTableHeader.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */