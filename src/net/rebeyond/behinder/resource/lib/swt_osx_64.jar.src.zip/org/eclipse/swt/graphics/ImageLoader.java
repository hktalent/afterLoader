package org.eclipse.swt.graphics;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Vector;
import org.eclipse.swt.SWT;
import org.eclipse.swt.internal.Compatibility;
import org.eclipse.swt.internal.image.FileFormat;

public class ImageLoader
{
  public ImageData[] data;
  public int logicalScreenWidth;
  public int logicalScreenHeight;
  public int backgroundPixel;
  public int repeatCount;
  public int compression;
  Vector imageLoaderListeners;
  
  public ImageLoader()
  {
    reset();
  }
  
  void reset()
  {
    this.data = null;
    this.logicalScreenWidth = 0;
    this.logicalScreenHeight = 0;
    this.backgroundPixel = -1;
    this.repeatCount = 1;
    this.compression = -1;
  }
  
  public ImageData[] load(InputStream paramInputStream)
  {
    if (paramInputStream == null) {
      SWT.error(4);
    }
    reset();
    this.data = FileFormat.load(paramInputStream, this);
    return this.data;
  }
  
  public ImageData[] load(String paramString)
  {
    if (paramString == null) {
      SWT.error(4);
    }
    InputStream localInputStream = null;
    try
    {
      localInputStream = Compatibility.newFileInputStream(paramString);
      ImageData[] arrayOfImageData = load(localInputStream);
      return arrayOfImageData;
    }
    catch (IOException localIOException1)
    {
      SWT.error(39, localIOException1);
    }
    finally
    {
      try
      {
        if (localInputStream != null) {
          localInputStream.close();
        }
      }
      catch (IOException localIOException2) {}
    }
    return null;
  }
  
  public void save(OutputStream paramOutputStream, int paramInt)
  {
    if (paramOutputStream == null) {
      SWT.error(4);
    }
    FileFormat.save(paramOutputStream, paramInt, this);
  }
  
  public void save(String paramString, int paramInt)
  {
    if (paramString == null) {
      SWT.error(4);
    }
    OutputStream localOutputStream = null;
    try
    {
      localOutputStream = Compatibility.newFileOutputStream(paramString);
    }
    catch (IOException localIOException1)
    {
      SWT.error(39, localIOException1);
    }
    save(localOutputStream, paramInt);
    try
    {
      localOutputStream.close();
    }
    catch (IOException localIOException2) {}
  }
  
  public void addImageLoaderListener(ImageLoaderListener paramImageLoaderListener)
  {
    if (paramImageLoaderListener == null) {
      SWT.error(4);
    }
    if (this.imageLoaderListeners == null) {
      this.imageLoaderListeners = new Vector();
    }
    this.imageLoaderListeners.addElement(paramImageLoaderListener);
  }
  
  public void removeImageLoaderListener(ImageLoaderListener paramImageLoaderListener)
  {
    if (paramImageLoaderListener == null) {
      SWT.error(4);
    }
    if (this.imageLoaderListeners == null) {
      return;
    }
    this.imageLoaderListeners.removeElement(paramImageLoaderListener);
  }
  
  public boolean hasListeners()
  {
    return (this.imageLoaderListeners != null) && (this.imageLoaderListeners.size() > 0);
  }
  
  public void notifyListeners(ImageLoaderEvent paramImageLoaderEvent)
  {
    if (!hasListeners()) {
      return;
    }
    int i = this.imageLoaderListeners.size();
    for (int j = 0; j < i; j++)
    {
      ImageLoaderListener localImageLoaderListener = (ImageLoaderListener)this.imageLoaderListeners.elementAt(j);
      localImageLoaderListener.imageDataLoaded(paramImageLoaderEvent);
    }
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/graphics/ImageLoader.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */