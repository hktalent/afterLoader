package org.eclipse.swt.internal.cocoa;

public class NSWindow
  extends NSResponder
{
  public NSWindow() {}
  
  public NSWindow(long paramLong)
  {
    super(paramLong);
  }
  
  public NSWindow(id paramid)
  {
    super(paramid);
  }
  
  public void addChildWindow(NSWindow paramNSWindow, long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_addChildWindow_ordered_, paramNSWindow != null ? paramNSWindow.id : 0L, paramLong);
  }
  
  public double alphaValue()
  {
    return OS.objc_msgSend_fpret(this.id, OS.sel_alphaValue);
  }
  
  public boolean areCursorRectsEnabled()
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_areCursorRectsEnabled);
  }
  
  public void becomeKeyWindow()
  {
    OS.objc_msgSend(this.id, OS.sel_becomeKeyWindow);
  }
  
  public boolean canBecomeKeyWindow()
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_canBecomeKeyWindow);
  }
  
  public NSPoint cascadeTopLeftFromPoint(NSPoint paramNSPoint)
  {
    NSPoint localNSPoint = new NSPoint();
    OS.objc_msgSend_stret(localNSPoint, this.id, OS.sel_cascadeTopLeftFromPoint_, paramNSPoint);
    return localNSPoint;
  }
  
  public void close()
  {
    OS.objc_msgSend(this.id, OS.sel_close);
  }
  
  public long collectionBehavior()
  {
    return OS.objc_msgSend(this.id, OS.sel_collectionBehavior);
  }
  
  public NSView contentView()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_contentView);
    return l != 0L ? new NSView(l) : null;
  }
  
  public NSPoint convertBaseToScreen(NSPoint paramNSPoint)
  {
    NSPoint localNSPoint = new NSPoint();
    OS.objc_msgSend_stret(localNSPoint, this.id, OS.sel_convertBaseToScreen_, paramNSPoint);
    return localNSPoint;
  }
  
  public NSPoint convertScreenToBase(NSPoint paramNSPoint)
  {
    NSPoint localNSPoint = new NSPoint();
    OS.objc_msgSend_stret(localNSPoint, this.id, OS.sel_convertScreenToBase_, paramNSPoint);
    return localNSPoint;
  }
  
  public NSButtonCell defaultButtonCell()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_defaultButtonCell);
    return l != 0L ? new NSButtonCell(l) : null;
  }
  
  public id delegate()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_delegate);
    return l != 0L ? new id(l) : null;
  }
  
  public void deminiaturize(id paramid)
  {
    OS.objc_msgSend(this.id, OS.sel_deminiaturize_, paramid != null ? paramid.id : 0L);
  }
  
  public void disableCursorRects()
  {
    OS.objc_msgSend(this.id, OS.sel_disableCursorRects);
  }
  
  public void disableFlushWindow()
  {
    OS.objc_msgSend(this.id, OS.sel_disableFlushWindow);
  }
  
  public void display()
  {
    OS.objc_msgSend(this.id, OS.sel_display);
  }
  
  public void enableCursorRects()
  {
    OS.objc_msgSend(this.id, OS.sel_enableCursorRects);
  }
  
  public void enableFlushWindow()
  {
    OS.objc_msgSend(this.id, OS.sel_enableFlushWindow);
  }
  
  public void endEditingFor(id paramid)
  {
    OS.objc_msgSend(this.id, OS.sel_endEditingFor_, paramid != null ? paramid.id : 0L);
  }
  
  public NSText fieldEditor(boolean paramBoolean, id paramid)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_fieldEditor_forObject_, paramBoolean, paramid != null ? paramid.id : 0L);
    return l != 0L ? new NSText(l) : null;
  }
  
  public NSResponder firstResponder()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_firstResponder);
    return l != 0L ? new NSResponder(l) : null;
  }
  
  public void flushWindowIfNeeded()
  {
    OS.objc_msgSend(this.id, OS.sel_flushWindowIfNeeded);
  }
  
  public NSRect frame()
  {
    NSRect localNSRect = new NSRect();
    OS.objc_msgSend_stret(localNSRect, this.id, OS.sel_frame);
    return localNSRect;
  }
  
  public NSRect frameRectForContentRect(NSRect paramNSRect)
  {
    NSRect localNSRect = new NSRect();
    OS.objc_msgSend_stret(localNSRect, this.id, OS.sel_frameRectForContentRect_, paramNSRect);
    return localNSRect;
  }
  
  public NSGraphicsContext graphicsContext()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_graphicsContext);
    return l != 0L ? new NSGraphicsContext(l) : null;
  }
  
  public boolean hasShadow()
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_hasShadow);
  }
  
  public NSWindow initWithContentRect(NSRect paramNSRect, long paramLong1, long paramLong2, boolean paramBoolean)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_initWithContentRect_styleMask_backing_defer_, paramNSRect, paramLong1, paramLong2, paramBoolean);
    return l != 0L ? new NSWindow(l) : l == this.id ? this : null;
  }
  
  public NSWindow initWithContentRect(NSRect paramNSRect, long paramLong1, long paramLong2, boolean paramBoolean, NSScreen paramNSScreen)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_initWithContentRect_styleMask_backing_defer_screen_, paramNSRect, paramLong1, paramLong2, paramBoolean, paramNSScreen != null ? paramNSScreen.id : 0L);
    return l != 0L ? new NSWindow(l) : l == this.id ? this : null;
  }
  
  public void invalidateShadow()
  {
    OS.objc_msgSend(this.id, OS.sel_invalidateShadow);
  }
  
  public boolean isDocumentEdited()
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_isDocumentEdited);
  }
  
  public boolean isKeyWindow()
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_isKeyWindow);
  }
  
  public boolean isMainWindow()
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_isMainWindow);
  }
  
  public boolean isMiniaturized()
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_isMiniaturized);
  }
  
  public boolean isSheet()
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_isSheet);
  }
  
  public boolean isVisible()
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_isVisible);
  }
  
  public boolean isZoomed()
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_isZoomed);
  }
  
  public long level()
  {
    return OS.objc_msgSend(this.id, OS.sel_level);
  }
  
  public boolean makeFirstResponder(NSResponder paramNSResponder)
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_makeFirstResponder_, paramNSResponder != null ? paramNSResponder.id : 0L);
  }
  
  public void makeKeyAndOrderFront(id paramid)
  {
    OS.objc_msgSend(this.id, OS.sel_makeKeyAndOrderFront_, paramid != null ? paramid.id : 0L);
  }
  
  public static double minFrameWidthWithTitle(NSString paramNSString, long paramLong)
  {
    return OS.objc_msgSend_fpret(OS.class_NSWindow, OS.sel_minFrameWidthWithTitle_styleMask_, paramNSString != null ? paramNSString.id : 0L, paramLong);
  }
  
  public NSSize minSize()
  {
    NSSize localNSSize = new NSSize();
    OS.objc_msgSend_stret(localNSSize, this.id, OS.sel_minSize);
    return localNSSize;
  }
  
  public void miniaturize(id paramid)
  {
    OS.objc_msgSend(this.id, OS.sel_miniaturize_, paramid != null ? paramid.id : 0L);
  }
  
  public NSPoint mouseLocationOutsideOfEventStream()
  {
    NSPoint localNSPoint = new NSPoint();
    OS.objc_msgSend_stret(localNSPoint, this.id, OS.sel_mouseLocationOutsideOfEventStream);
    return localNSPoint;
  }
  
  public void orderBack(id paramid)
  {
    OS.objc_msgSend(this.id, OS.sel_orderBack_, paramid != null ? paramid.id : 0L);
  }
  
  public void orderFront(id paramid)
  {
    OS.objc_msgSend(this.id, OS.sel_orderFront_, paramid != null ? paramid.id : 0L);
  }
  
  public void orderFrontRegardless()
  {
    OS.objc_msgSend(this.id, OS.sel_orderFrontRegardless);
  }
  
  public void orderOut(id paramid)
  {
    OS.objc_msgSend(this.id, OS.sel_orderOut_, paramid != null ? paramid.id : 0L);
  }
  
  public void orderWindow(long paramLong1, long paramLong2)
  {
    OS.objc_msgSend(this.id, OS.sel_orderWindow_relativeTo_, paramLong1, paramLong2);
  }
  
  public NSWindow parentWindow()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_parentWindow);
    return l != 0L ? new NSWindow(l) : l == this.id ? this : null;
  }
  
  public void removeChildWindow(NSWindow paramNSWindow)
  {
    OS.objc_msgSend(this.id, OS.sel_removeChildWindow_, paramNSWindow != null ? paramNSWindow.id : 0L);
  }
  
  public NSScreen screen()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_screen);
    return l != 0L ? new NSScreen(l) : null;
  }
  
  public void sendEvent(NSEvent paramNSEvent)
  {
    OS.objc_msgSend(this.id, OS.sel_sendEvent_, paramNSEvent != null ? paramNSEvent.id : 0L);
  }
  
  public void setAcceptsMouseMovedEvents(boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_setAcceptsMouseMovedEvents_, paramBoolean);
  }
  
  public void setAlphaValue(double paramDouble)
  {
    OS.objc_msgSend(this.id, OS.sel_setAlphaValue_, paramDouble);
  }
  
  public void setBackgroundColor(NSColor paramNSColor)
  {
    OS.objc_msgSend(this.id, OS.sel_setBackgroundColor_, paramNSColor != null ? paramNSColor.id : 0L);
  }
  
  public void setCollectionBehavior(long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_setCollectionBehavior_, paramLong);
  }
  
  public void setContentView(NSView paramNSView)
  {
    OS.objc_msgSend(this.id, OS.sel_setContentView_, paramNSView != null ? paramNSView.id : 0L);
  }
  
  public void setDefaultButtonCell(NSButtonCell paramNSButtonCell)
  {
    OS.objc_msgSend(this.id, OS.sel_setDefaultButtonCell_, paramNSButtonCell != null ? paramNSButtonCell.id : 0L);
  }
  
  public void setDelegate(id paramid)
  {
    OS.objc_msgSend(this.id, OS.sel_setDelegate_, paramid != null ? paramid.id : 0L);
  }
  
  public void setDocumentEdited(boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_setDocumentEdited_, paramBoolean);
  }
  
  public void setFrame(NSRect paramNSRect, boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_setFrame_display_, paramNSRect, paramBoolean);
  }
  
  public void setFrame(NSRect paramNSRect, boolean paramBoolean1, boolean paramBoolean2)
  {
    OS.objc_msgSend(this.id, OS.sel_setFrame_display_animate_, paramNSRect, paramBoolean1, paramBoolean2);
  }
  
  public void setHasShadow(boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_setHasShadow_, paramBoolean);
  }
  
  public void setHidesOnDeactivate(boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_setHidesOnDeactivate_, paramBoolean);
  }
  
  public void setLevel(long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_setLevel_, paramLong);
  }
  
  public void setMinSize(NSSize paramNSSize)
  {
    OS.objc_msgSend(this.id, OS.sel_setMinSize_, paramNSSize);
  }
  
  public void setOpaque(boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_setOpaque_, paramBoolean);
  }
  
  public void setReleasedWhenClosed(boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_setReleasedWhenClosed_, paramBoolean);
  }
  
  public void setRepresentedFilename(NSString paramNSString)
  {
    OS.objc_msgSend(this.id, OS.sel_setRepresentedFilename_, paramNSString != null ? paramNSString.id : 0L);
  }
  
  public void setRepresentedURL(NSURL paramNSURL)
  {
    OS.objc_msgSend(this.id, OS.sel_setRepresentedURL_, paramNSURL != null ? paramNSURL.id : 0L);
  }
  
  public void setShowsResizeIndicator(boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_setShowsResizeIndicator_, paramBoolean);
  }
  
  public void setShowsToolbarButton(boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_setShowsToolbarButton_, paramBoolean);
  }
  
  public void setTitle(NSString paramNSString)
  {
    OS.objc_msgSend(this.id, OS.sel_setTitle_, paramNSString != null ? paramNSString.id : 0L);
  }
  
  public void setToolbar(NSToolbar paramNSToolbar)
  {
    OS.objc_msgSend(this.id, OS.sel_setToolbar_, paramNSToolbar != null ? paramNSToolbar.id : 0L);
  }
  
  public NSButton standardWindowButton(long paramLong)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_standardWindowButton_, paramLong);
    return l != 0L ? new NSButton(l) : null;
  }
  
  public long styleMask()
  {
    return OS.objc_msgSend(this.id, OS.sel_styleMask);
  }
  
  public void toggleToolbarShown(id paramid)
  {
    OS.objc_msgSend(this.id, OS.sel_toggleToolbarShown_, paramid != null ? paramid.id : 0L);
  }
  
  public NSToolbar toolbar()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_toolbar);
    return l != 0L ? new NSToolbar(l) : null;
  }
  
  public double userSpaceScaleFactor()
  {
    return OS.objc_msgSend_fpret(this.id, OS.sel_userSpaceScaleFactor);
  }
  
  public long windowNumber()
  {
    return OS.objc_msgSend(this.id, OS.sel_windowNumber);
  }
  
  public static long windowNumberAtPoint(NSPoint paramNSPoint, long paramLong)
  {
    return OS.objc_msgSend(OS.class_NSWindow, OS.sel_windowNumberAtPoint_belowWindowWithWindowNumber_, paramNSPoint, paramLong);
  }
  
  public long windowRef()
  {
    return OS.objc_msgSend(this.id, OS.sel_windowRef);
  }
  
  public void zoom(id paramid)
  {
    OS.objc_msgSend(this.id, OS.sel_zoom_, paramid != null ? paramid.id : 0L);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSWindow.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */