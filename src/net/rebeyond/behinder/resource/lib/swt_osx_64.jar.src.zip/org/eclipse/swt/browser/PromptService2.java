package org.eclipse.swt.browser;

import org.eclipse.swt.SWT;
import org.eclipse.swt.internal.C;
import org.eclipse.swt.internal.Compatibility;
import org.eclipse.swt.internal.mozilla.IIDStore;
import org.eclipse.swt.internal.mozilla.XPCOM;
import org.eclipse.swt.internal.mozilla.XPCOMObject;
import org.eclipse.swt.internal.mozilla.nsEmbedString;
import org.eclipse.swt.internal.mozilla.nsIAuthInformation;
import org.eclipse.swt.internal.mozilla.nsIChannel;
import org.eclipse.swt.internal.mozilla.nsID;
import org.eclipse.swt.internal.mozilla.nsIMemory;
import org.eclipse.swt.internal.mozilla.nsIPromptService;
import org.eclipse.swt.internal.mozilla.nsIServiceManager;
import org.eclipse.swt.internal.mozilla.nsISupports;
import org.eclipse.swt.internal.mozilla.nsIURI;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.Shell;

class PromptService2
{
  XPCOMObject supports;
  XPCOMObject promptService;
  XPCOMObject promptService2;
  int refCount = 0;
  
  PromptService2()
  {
    createCOMInterfaces();
  }
  
  int AddRef()
  {
    this.refCount += 1;
    return this.refCount;
  }
  
  void createCOMInterfaces()
  {
    this.supports = new XPCOMObject(new int[] { 2, 0, 0 })
    {
      public long method0(long[] paramAnonymousArrayOfLong)
      {
        return PromptService2.this.QueryInterface(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method1(long[] paramAnonymousArrayOfLong)
      {
        return PromptService2.this.AddRef();
      }
      
      public long method2(long[] paramAnonymousArrayOfLong)
      {
        return PromptService2.this.Release();
      }
    };
    this.promptService = new XPCOMObject(new int[] { 2, 0, 0, 3, 5, 4, 6, 10, 7, 8, 7, 7 })
    {
      public long method0(long[] paramAnonymousArrayOfLong)
      {
        return PromptService2.this.QueryInterface(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method1(long[] paramAnonymousArrayOfLong)
      {
        return PromptService2.this.AddRef();
      }
      
      public long method2(long[] paramAnonymousArrayOfLong)
      {
        return PromptService2.this.Release();
      }
      
      public long method3(long[] paramAnonymousArrayOfLong)
      {
        return PromptService2.this.Alert(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2]);
      }
      
      public long method4(long[] paramAnonymousArrayOfLong)
      {
        return PromptService2.this.AlertCheck(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2], paramAnonymousArrayOfLong[3], paramAnonymousArrayOfLong[4]);
      }
      
      public long method5(long[] paramAnonymousArrayOfLong)
      {
        return PromptService2.this.Confirm(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2], paramAnonymousArrayOfLong[3]);
      }
      
      public long method6(long[] paramAnonymousArrayOfLong)
      {
        return PromptService2.this.ConfirmCheck(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2], paramAnonymousArrayOfLong[3], paramAnonymousArrayOfLong[4], paramAnonymousArrayOfLong[5]);
      }
      
      public long method7(long[] paramAnonymousArrayOfLong)
      {
        return PromptService2.this.ConfirmEx(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2], (int)paramAnonymousArrayOfLong[3], paramAnonymousArrayOfLong[4], paramAnonymousArrayOfLong[5], paramAnonymousArrayOfLong[6], paramAnonymousArrayOfLong[7], paramAnonymousArrayOfLong[8], paramAnonymousArrayOfLong[9]);
      }
      
      public long method8(long[] paramAnonymousArrayOfLong)
      {
        return PromptService2.this.Prompt(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2], paramAnonymousArrayOfLong[3], paramAnonymousArrayOfLong[4], paramAnonymousArrayOfLong[5], paramAnonymousArrayOfLong[6]);
      }
      
      public long method9(long[] paramAnonymousArrayOfLong)
      {
        return PromptService2.this.PromptUsernameAndPassword(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2], paramAnonymousArrayOfLong[3], paramAnonymousArrayOfLong[4], paramAnonymousArrayOfLong[5], paramAnonymousArrayOfLong[6], paramAnonymousArrayOfLong[7]);
      }
      
      public long method10(long[] paramAnonymousArrayOfLong)
      {
        return PromptService2.this.PromptPassword(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2], paramAnonymousArrayOfLong[3], paramAnonymousArrayOfLong[4], paramAnonymousArrayOfLong[5], paramAnonymousArrayOfLong[6]);
      }
      
      public long method11(long[] paramAnonymousArrayOfLong)
      {
        return PromptService2.this.Select(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2], (int)paramAnonymousArrayOfLong[3], paramAnonymousArrayOfLong[4], paramAnonymousArrayOfLong[5], paramAnonymousArrayOfLong[6]);
      }
    };
    this.promptService2 = new XPCOMObject(new int[] { 2, 0, 0, 3, 5, 4, 6, 10, 7, 8, 7, 7, 7, 9 })
    {
      public long method0(long[] paramAnonymousArrayOfLong)
      {
        return PromptService2.this.QueryInterface(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method1(long[] paramAnonymousArrayOfLong)
      {
        return PromptService2.this.AddRef();
      }
      
      public long method2(long[] paramAnonymousArrayOfLong)
      {
        return PromptService2.this.Release();
      }
      
      public long method3(long[] paramAnonymousArrayOfLong)
      {
        return PromptService2.this.Alert(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2]);
      }
      
      public long method4(long[] paramAnonymousArrayOfLong)
      {
        return PromptService2.this.AlertCheck(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2], paramAnonymousArrayOfLong[3], paramAnonymousArrayOfLong[4]);
      }
      
      public long method5(long[] paramAnonymousArrayOfLong)
      {
        return PromptService2.this.Confirm(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2], paramAnonymousArrayOfLong[3]);
      }
      
      public long method6(long[] paramAnonymousArrayOfLong)
      {
        return PromptService2.this.ConfirmCheck(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2], paramAnonymousArrayOfLong[3], paramAnonymousArrayOfLong[4], paramAnonymousArrayOfLong[5]);
      }
      
      public long method7(long[] paramAnonymousArrayOfLong)
      {
        return PromptService2.this.ConfirmEx(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2], (int)paramAnonymousArrayOfLong[3], paramAnonymousArrayOfLong[4], paramAnonymousArrayOfLong[5], paramAnonymousArrayOfLong[6], paramAnonymousArrayOfLong[7], paramAnonymousArrayOfLong[8], paramAnonymousArrayOfLong[9]);
      }
      
      public long method8(long[] paramAnonymousArrayOfLong)
      {
        return PromptService2.this.Prompt(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2], paramAnonymousArrayOfLong[3], paramAnonymousArrayOfLong[4], paramAnonymousArrayOfLong[5], paramAnonymousArrayOfLong[6]);
      }
      
      public long method9(long[] paramAnonymousArrayOfLong)
      {
        return PromptService2.this.PromptUsernameAndPassword(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2], paramAnonymousArrayOfLong[3], paramAnonymousArrayOfLong[4], paramAnonymousArrayOfLong[5], paramAnonymousArrayOfLong[6], paramAnonymousArrayOfLong[7]);
      }
      
      public long method10(long[] paramAnonymousArrayOfLong)
      {
        return PromptService2.this.PromptPassword(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2], paramAnonymousArrayOfLong[3], paramAnonymousArrayOfLong[4], paramAnonymousArrayOfLong[5], paramAnonymousArrayOfLong[6]);
      }
      
      public long method11(long[] paramAnonymousArrayOfLong)
      {
        return PromptService2.this.Select(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2], (int)paramAnonymousArrayOfLong[3], paramAnonymousArrayOfLong[4], paramAnonymousArrayOfLong[5], paramAnonymousArrayOfLong[6]);
      }
      
      public long method12(long[] paramAnonymousArrayOfLong)
      {
        return PromptService2.this.PromptAuth(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], (int)paramAnonymousArrayOfLong[2], paramAnonymousArrayOfLong[3], paramAnonymousArrayOfLong[4], paramAnonymousArrayOfLong[5], paramAnonymousArrayOfLong[6]);
      }
      
      public long method13(long[] paramAnonymousArrayOfLong)
      {
        return PromptService2.this.AsyncPromptAuth(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2], paramAnonymousArrayOfLong[3], (int)paramAnonymousArrayOfLong[4], paramAnonymousArrayOfLong[5], paramAnonymousArrayOfLong[6], paramAnonymousArrayOfLong[7], paramAnonymousArrayOfLong[8]);
      }
    };
  }
  
  void disposeCOMInterfaces()
  {
    if (this.supports != null)
    {
      this.supports.dispose();
      this.supports = null;
    }
    if (this.promptService != null)
    {
      this.promptService.dispose();
      this.promptService = null;
    }
    if (this.promptService2 != null)
    {
      this.promptService2.dispose();
      this.promptService2 = null;
    }
  }
  
  long getAddress()
  {
    return this.promptService2.getAddress();
  }
  
  int QueryInterface(long paramLong1, long paramLong2)
  {
    if ((paramLong1 == 0L) || (paramLong2 == 0L)) {
      return -2147467262;
    }
    nsID localnsID = new nsID();
    XPCOM.memmove(localnsID, paramLong1, 16);
    if (localnsID.Equals(IIDStore.GetIID(nsISupports.class)))
    {
      XPCOM.memmove(paramLong2, new long[] { this.supports.getAddress() }, C.PTR_SIZEOF);
      AddRef();
      return 0;
    }
    if (localnsID.Equals(IIDStore.GetIID(nsIPromptService.class)))
    {
      XPCOM.memmove(paramLong2, new long[] { this.promptService.getAddress() }, C.PTR_SIZEOF);
      AddRef();
      return 0;
    }
    if (localnsID.Equals(XPCOM.NS_IPROMPTSERVICE2_IID))
    {
      XPCOM.memmove(paramLong2, new long[] { this.promptService2.getAddress() }, C.PTR_SIZEOF);
      AddRef();
      return 0;
    }
    XPCOM.memmove(paramLong2, new long[] { 0L }, C.PTR_SIZEOF);
    return -2147467262;
  }
  
  int Release()
  {
    this.refCount -= 1;
    if (this.refCount == 0) {
      disposeCOMInterfaces();
    }
    return this.refCount;
  }
  
  Browser getBrowser(long paramLong)
  {
    if (paramLong == 0L) {
      return null;
    }
    return Mozilla.getBrowser(paramLong);
  }
  
  String getLabel(int paramInt1, int paramInt2, long paramLong)
  {
    String str = null;
    int i = (paramInt1 & 255 * paramInt2) / paramInt2;
    switch (i)
    {
    case 2: 
      str = SWT.getMessage("SWT_Cancel");
      break;
    case 4: 
      str = SWT.getMessage("SWT_No");
      break;
    case 1: 
      str = SWT.getMessage("SWT_OK");
      break;
    case 5: 
      str = SWT.getMessage("SWT_Save");
      break;
    case 3: 
      str = SWT.getMessage("SWT_Yes");
      break;
    case 127: 
      int j = XPCOM.strlen_PRUnichar(paramLong);
      char[] arrayOfChar = new char[j];
      XPCOM.memmove(arrayOfChar, paramLong, j * 2);
      str = new String(arrayOfChar);
    }
    return str;
  }
  
  int Alert(long paramLong1, long paramLong2, long paramLong3)
  {
    Browser localBrowser = getBrowser(paramLong1);
    int i = XPCOM.strlen_PRUnichar(paramLong2);
    char[] arrayOfChar = new char[i];
    XPCOM.memmove(arrayOfChar, paramLong2, i * 2);
    String str1 = new String(arrayOfChar);
    i = XPCOM.strlen_PRUnichar(paramLong3);
    arrayOfChar = new char[i];
    XPCOM.memmove(arrayOfChar, paramLong3, i * 2);
    String str2 = new String(arrayOfChar);
    if (localBrowser != null)
    {
      localObject = (Mozilla)localBrowser.webBrowser;
      if (((Mozilla)localObject).isRetrievingBadCert) {
        return 0;
      }
    }
    Object localObject = localBrowser == null ? new Shell() : localBrowser.getShell();
    MessageBox localMessageBox = new MessageBox((Shell)localObject, 40);
    localMessageBox.setText(str1);
    localMessageBox.setMessage(str2);
    localMessageBox.open();
    return 0;
  }
  
  int AlertCheck(long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5)
  {
    Browser localBrowser = getBrowser(paramLong1);
    int i = XPCOM.strlen_PRUnichar(paramLong2);
    char[] arrayOfChar = new char[i];
    XPCOM.memmove(arrayOfChar, paramLong2, i * 2);
    String str1 = new String(arrayOfChar);
    i = XPCOM.strlen_PRUnichar(paramLong3);
    arrayOfChar = new char[i];
    XPCOM.memmove(arrayOfChar, paramLong3, i * 2);
    String str2 = new String(arrayOfChar);
    i = XPCOM.strlen_PRUnichar(paramLong4);
    arrayOfChar = new char[i];
    XPCOM.memmove(arrayOfChar, paramLong4, i * 2);
    String str3 = new String(arrayOfChar);
    Shell localShell = localBrowser == null ? new Shell() : localBrowser.getShell();
    PromptDialog localPromptDialog = new PromptDialog(localShell);
    boolean[] arrayOfBoolean = new boolean[1];
    if (paramLong5 != 0L) {
      XPCOM.memmove(arrayOfBoolean, paramLong5);
    }
    localPromptDialog.alertCheck(str1, str2, str3, arrayOfBoolean);
    if (paramLong5 != 0L) {
      XPCOM.memmove(paramLong5, arrayOfBoolean);
    }
    return 0;
  }
  
  int AsyncPromptAuth(long paramLong1, long paramLong2, long paramLong3, long paramLong4, int paramInt, long paramLong5, long paramLong6, long paramLong7, long paramLong8)
  {
    return -2147467263;
  }
  
  int Confirm(long paramLong1, long paramLong2, long paramLong3, long paramLong4)
  {
    Browser localBrowser = getBrowser(paramLong1);
    if ((localBrowser != null) && (((Mozilla)localBrowser.webBrowser).ignoreAllMessages))
    {
      XPCOM.memmove(paramLong4, new boolean[] { true });
      return 0;
    }
    int i = XPCOM.strlen_PRUnichar(paramLong2);
    char[] arrayOfChar = new char[i];
    XPCOM.memmove(arrayOfChar, paramLong2, i * 2);
    String str1 = new String(arrayOfChar);
    i = XPCOM.strlen_PRUnichar(paramLong3);
    arrayOfChar = new char[i];
    XPCOM.memmove(arrayOfChar, paramLong3, i * 2);
    String str2 = new String(arrayOfChar);
    Shell localShell = localBrowser == null ? new Shell() : localBrowser.getShell();
    MessageBox localMessageBox = new MessageBox(localShell, 292);
    localMessageBox.setText(str1);
    localMessageBox.setMessage(str2);
    int j = localMessageBox.open();
    boolean[] arrayOfBoolean = { j == 32 ? 1 : 0 };
    XPCOM.memmove(paramLong4, arrayOfBoolean);
    return 0;
  }
  
  int ConfirmCheck(long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5, long paramLong6)
  {
    return -2147467263;
  }
  
  int ConfirmEx(long paramLong1, long paramLong2, long paramLong3, int paramInt, long paramLong4, long paramLong5, long paramLong6, long paramLong7, long paramLong8, long paramLong9)
  {
    Browser localBrowser = getBrowser(paramLong1);
    int i = XPCOM.strlen_PRUnichar(paramLong2);
    char[] arrayOfChar = new char[i];
    XPCOM.memmove(arrayOfChar, paramLong2, i * 2);
    String str1 = new String(arrayOfChar);
    i = XPCOM.strlen_PRUnichar(paramLong3);
    arrayOfChar = new char[i];
    XPCOM.memmove(arrayOfChar, paramLong3, i * 2);
    String str2 = new String(arrayOfChar);
    String str3 = null;
    if (paramLong7 != 0L)
    {
      i = XPCOM.strlen_PRUnichar(paramLong7);
      arrayOfChar = new char[i];
      XPCOM.memmove(arrayOfChar, paramLong7, i * 2);
      str3 = new String(arrayOfChar);
    }
    String str4 = getLabel(paramInt, 1, paramLong4);
    String str5 = getLabel(paramInt, 256, paramLong5);
    String str6 = getLabel(paramInt, 65536, paramLong6);
    int j = 0;
    if ((paramInt & 0x1000000) != 0) {
      j = 1;
    } else if ((paramInt & 0x2000000) != 0) {
      j = 2;
    }
    Shell localShell = localBrowser == null ? new Shell() : localBrowser.getShell();
    PromptDialog localPromptDialog = new PromptDialog(localShell);
    boolean[] arrayOfBoolean = new boolean[1];
    int[] arrayOfInt = new int[1];
    if (paramLong8 != 0L) {
      XPCOM.memmove(arrayOfBoolean, paramLong8);
    }
    localPromptDialog.confirmEx(str1, str2, str3, str4, str5, str6, j, arrayOfBoolean, arrayOfInt);
    if (paramLong8 != 0L) {
      XPCOM.memmove(paramLong8, arrayOfBoolean);
    }
    XPCOM.memmove(paramLong9, arrayOfInt, 4L);
    return 0;
  }
  
  int Prompt(long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5, long paramLong6, long paramLong7)
  {
    Browser localBrowser = getBrowser(paramLong1);
    String str1 = null;
    String str3 = null;
    String[] arrayOfString = new String[1];
    if (paramLong2 != 0L)
    {
      i = XPCOM.strlen_PRUnichar(paramLong2);
      arrayOfChar1 = new char[i];
      XPCOM.memmove(arrayOfChar1, paramLong2, i * 2);
      str1 = new String(arrayOfChar1);
    }
    int i = XPCOM.strlen_PRUnichar(paramLong3);
    char[] arrayOfChar1 = new char[i];
    XPCOM.memmove(arrayOfChar1, paramLong3, i * 2);
    String str2 = new String(arrayOfChar1);
    long[] arrayOfLong1 = new long[1];
    XPCOM.memmove(arrayOfLong1, paramLong4, C.PTR_SIZEOF);
    if (arrayOfLong1[0] != 0L)
    {
      i = XPCOM.strlen_PRUnichar(arrayOfLong1[0]);
      arrayOfChar1 = new char[i];
      XPCOM.memmove(arrayOfChar1, arrayOfLong1[0], i * 2);
      arrayOfString[0] = new String(arrayOfChar1);
    }
    if (paramLong5 != 0L)
    {
      i = XPCOM.strlen_PRUnichar(paramLong5);
      if (i > 0)
      {
        arrayOfChar1 = new char[i];
        XPCOM.memmove(arrayOfChar1, paramLong5, i * 2);
        str3 = new String(arrayOfChar1);
      }
    }
    Shell localShell = localBrowser == null ? new Shell() : localBrowser.getShell();
    PromptDialog localPromptDialog = new PromptDialog(localShell);
    boolean[] arrayOfBoolean1 = new boolean[1];
    boolean[] arrayOfBoolean2 = new boolean[1];
    if (paramLong6 != 0L) {
      XPCOM.memmove(arrayOfBoolean1, paramLong6);
    }
    localPromptDialog.prompt(str1, str2, str3, arrayOfString, arrayOfBoolean1, arrayOfBoolean2);
    XPCOM.memmove(paramLong7, arrayOfBoolean2);
    if ((arrayOfBoolean2[0] != 0) && (arrayOfString[0] != null))
    {
      long[] arrayOfLong2 = new long[1];
      int j = XPCOM.NS_GetServiceManager(arrayOfLong2);
      if (j != 0) {
        SWT.error(j);
      }
      if (arrayOfLong2[0] == 0L) {
        SWT.error(-2147467262);
      }
      nsIServiceManager localnsIServiceManager = new nsIServiceManager(arrayOfLong2[0]);
      arrayOfLong2[0] = 0L;
      byte[] arrayOfByte = MozillaDelegate.wcsToMbcs(null, "@mozilla.org/xpcom/memory-service;1", true);
      j = localnsIServiceManager.GetServiceByContractID(arrayOfByte, IIDStore.GetIID(nsIMemory.class), arrayOfLong2);
      if (j != 0) {
        SWT.error(j);
      }
      if (arrayOfLong2[0] == 0L) {
        SWT.error(-2147467262);
      }
      localnsIServiceManager.Release();
      nsIMemory localnsIMemory = new nsIMemory(arrayOfLong2[0]);
      arrayOfLong2[0] = 0L;
      int k = arrayOfString[0].length();
      char[] arrayOfChar2 = new char[k + 1];
      arrayOfString[0].getChars(0, k, arrayOfChar2, 0);
      int m = arrayOfChar2.length * 2;
      long l = localnsIMemory.Alloc(m);
      XPCOM.memmove(l, arrayOfChar2, m);
      XPCOM.memmove(paramLong4, new long[] { l }, C.PTR_SIZEOF);
      if (arrayOfLong1[0] != 0L) {
        localnsIMemory.Free(arrayOfLong1[0]);
      }
      localnsIMemory.Release();
    }
    if (paramLong6 != 0L) {
      XPCOM.memmove(paramLong6, arrayOfBoolean1);
    }
    return 0;
  }
  
  int PromptAuth(long paramLong1, long paramLong2, int paramInt, long paramLong3, long paramLong4, long paramLong5, long paramLong6)
  {
    nsIAuthInformation localnsIAuthInformation = new nsIAuthInformation(paramLong3);
    Browser localBrowser = getBrowser(paramLong1);
    if (localBrowser != null)
    {
      localObject1 = (Mozilla)localBrowser.webBrowser;
      if (localObject1.authCount++ < 3) {
        for (int i = 0; i < ((Mozilla)localObject1).authenticationListeners.length; i++)
        {
          localObject2 = new AuthenticationEvent(localBrowser);
          ((AuthenticationEvent)localObject2).location = ((Mozilla)localObject1).lastNavigateURL;
          localObject1.authenticationListeners[i].authenticate((AuthenticationEvent)localObject2);
          if (!((AuthenticationEvent)localObject2).doit)
          {
            XPCOM.memmove(paramLong6, new boolean[] { false });
            return 0;
          }
          if ((((AuthenticationEvent)localObject2).user != null) && (((AuthenticationEvent)localObject2).password != null))
          {
            localObject3 = new nsEmbedString(((AuthenticationEvent)localObject2).user);
            int j = localnsIAuthInformation.SetUsername(((nsEmbedString)localObject3).getAddress());
            if (j != 0) {
              SWT.error(j);
            }
            ((nsEmbedString)localObject3).dispose();
            localObject3 = new nsEmbedString(((AuthenticationEvent)localObject2).password);
            j = localnsIAuthInformation.SetPassword(((nsEmbedString)localObject3).getAddress());
            if (j != 0) {
              SWT.error(j);
            }
            ((nsEmbedString)localObject3).dispose();
            XPCOM.memmove(paramLong6, new boolean[] { true });
            return 0;
          }
        }
      }
    }
    Object localObject1 = null;
    boolean[] arrayOfBoolean1 = new boolean[1];
    Object localObject2 = new String[1];
    Object localObject3 = new String[1];
    String str1 = SWT.getMessage("SWT_Authentication_Required");
    if ((paramLong4 != 0L) && (paramLong5 != 0L))
    {
      int k = XPCOM.strlen_PRUnichar(paramLong4);
      char[] arrayOfChar1 = new char[k];
      XPCOM.memmove(arrayOfChar1, paramLong4, k * 2);
      localObject1 = new String(arrayOfChar1);
      XPCOM.memmove(arrayOfBoolean1, paramLong5);
    }
    long l1 = XPCOM.nsEmbedString_new();
    int m = localnsIAuthInformation.GetUsername(l1);
    if (m != 0) {
      SWT.error(m);
    }
    int n = XPCOM.nsEmbedString_Length(l1);
    long l2 = XPCOM.nsEmbedString_get(l1);
    char[] arrayOfChar2 = new char[n];
    XPCOM.memmove(arrayOfChar2, l2, n * 2);
    localObject2[0] = new String(arrayOfChar2);
    XPCOM.nsEmbedString_delete(l1);
    l1 = XPCOM.nsEmbedString_new();
    m = localnsIAuthInformation.GetPassword(l1);
    if (m != 0) {
      SWT.error(m);
    }
    n = XPCOM.nsEmbedString_Length(l1);
    l2 = XPCOM.nsEmbedString_get(l1);
    arrayOfChar2 = new char[n];
    XPCOM.memmove(arrayOfChar2, l2, n * 2);
    localObject3[0] = new String(arrayOfChar2);
    XPCOM.nsEmbedString_delete(l1);
    l1 = XPCOM.nsEmbedString_new();
    m = localnsIAuthInformation.GetRealm(l1);
    if (m != 0) {
      SWT.error(m);
    }
    n = XPCOM.nsEmbedString_Length(l1);
    l2 = XPCOM.nsEmbedString_get(l1);
    arrayOfChar2 = new char[n];
    XPCOM.memmove(arrayOfChar2, l2, n * 2);
    String str2 = new String(arrayOfChar2);
    XPCOM.nsEmbedString_delete(l1);
    nsIChannel localnsIChannel = new nsIChannel(paramLong2);
    long[] arrayOfLong = new long[1];
    m = localnsIChannel.GetURI(arrayOfLong);
    if (m != 0) {
      SWT.error(m);
    }
    if (arrayOfLong[0] == 0L) {
      Mozilla.error(-2147467262);
    }
    nsIURI localnsIURI = new nsIURI(arrayOfLong[0]);
    long l3 = XPCOM.nsEmbedCString_new();
    m = localnsIURI.GetHost(l3);
    if (m != 0) {
      SWT.error(m);
    }
    n = XPCOM.nsEmbedCString_Length(l3);
    l2 = XPCOM.nsEmbedCString_get(l3);
    byte[] arrayOfByte = new byte[n];
    XPCOM.memmove(arrayOfByte, l2, n);
    String str3 = new String(arrayOfByte);
    XPCOM.nsEmbedCString_delete(l3);
    localnsIURI.Release();
    String str4;
    if ((str2.length() > 0) && (str3.length() > 0)) {
      str4 = Compatibility.getMessage("SWT_Enter_Username_and_Password", new String[] { str2, str3 });
    } else {
      str4 = "";
    }
    Shell localShell = localBrowser == null ? new Shell() : localBrowser.getShell();
    PromptDialog localPromptDialog = new PromptDialog(localShell);
    boolean[] arrayOfBoolean2 = new boolean[1];
    localPromptDialog.promptUsernameAndPassword(str1, str4, (String)localObject1, (String[])localObject2, (String[])localObject3, arrayOfBoolean1, arrayOfBoolean2);
    XPCOM.memmove(paramLong6, arrayOfBoolean2);
    if (arrayOfBoolean2[0] != 0)
    {
      nsEmbedString localnsEmbedString = new nsEmbedString(localObject2[0]);
      m = localnsIAuthInformation.SetUsername(localnsEmbedString.getAddress());
      if (m != 0) {
        SWT.error(m);
      }
      localnsEmbedString.dispose();
      localnsEmbedString = new nsEmbedString(localObject3[0]);
      m = localnsIAuthInformation.SetPassword(localnsEmbedString.getAddress());
      if (m != 0) {
        SWT.error(m);
      }
      localnsEmbedString.dispose();
    }
    if (paramLong5 != 0L) {
      XPCOM.memmove(paramLong5, arrayOfBoolean1);
    }
    return 0;
  }
  
  int PromptUsernameAndPassword(long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5, long paramLong6, long paramLong7, long paramLong8)
  {
    Browser localBrowser = getBrowser(paramLong1);
    String str1 = null;
    String str2 = null;
    Object localObject1;
    Object localObject3;
    if (localBrowser != null)
    {
      localObject1 = (Mozilla)localBrowser.webBrowser;
      if (localObject1.authCount++ < 3) {
        for (int i = 0; i < ((Mozilla)localObject1).authenticationListeners.length; i++)
        {
          localObject3 = new AuthenticationEvent(localBrowser);
          ((AuthenticationEvent)localObject3).location = ((Mozilla)localObject1).lastNavigateURL;
          localObject1.authenticationListeners[i].authenticate((AuthenticationEvent)localObject3);
          if (!((AuthenticationEvent)localObject3).doit)
          {
            XPCOM.memmove(paramLong8, new boolean[] { false });
            return 0;
          }
          if ((((AuthenticationEvent)localObject3).user != null) && (((AuthenticationEvent)localObject3).password != null))
          {
            str1 = ((AuthenticationEvent)localObject3).user;
            str2 = ((AuthenticationEvent)localObject3).password;
            XPCOM.memmove(paramLong8, new boolean[] { true });
            break;
          }
        }
      }
    }
    Object localObject4;
    Object localObject5;
    Object localObject2;
    Object localObject6;
    if (str1 == null)
    {
      localObject3 = null;
      String[] arrayOfString = new String[1];
      localObject4 = new String[1];
      if (paramLong2 != 0L)
      {
        k = XPCOM.strlen_PRUnichar(paramLong2);
        localObject5 = new char[k];
        XPCOM.memmove((char[])localObject5, paramLong2, k * 2);
        localObject1 = new String((char[])localObject5);
      }
      else
      {
        localObject1 = SWT.getMessage("SWT_Authentication_Required");
      }
      int k = XPCOM.strlen_PRUnichar(paramLong3);
      localObject5 = new char[k];
      XPCOM.memmove((char[])localObject5, paramLong3, k * 2);
      localObject2 = new String((char[])localObject5);
      long[] arrayOfLong = new long[1];
      XPCOM.memmove(arrayOfLong, paramLong4, C.PTR_SIZEOF);
      if (arrayOfLong[0] != 0L)
      {
        k = XPCOM.strlen_PRUnichar(arrayOfLong[0]);
        localObject5 = new char[k];
        XPCOM.memmove((char[])localObject5, arrayOfLong[0], k * 2);
        arrayOfString[0] = new String((char[])localObject5);
      }
      localObject6 = new long[1];
      XPCOM.memmove((long[])localObject6, paramLong5, C.PTR_SIZEOF);
      if (localObject6[0] != 0L)
      {
        k = XPCOM.strlen_PRUnichar(localObject6[0]);
        localObject5 = new char[k];
        XPCOM.memmove((char[])localObject5, localObject6[0], k * 2);
        localObject4[0] = new String((char[])localObject5);
      }
      if (paramLong6 != 0L)
      {
        k = XPCOM.strlen_PRUnichar(paramLong6);
        if (k > 0)
        {
          localObject5 = new char[k];
          XPCOM.memmove((char[])localObject5, paramLong6, k * 2);
          localObject3 = new String((char[])localObject5);
        }
      }
      Shell localShell = localBrowser == null ? new Shell() : localBrowser.getShell();
      PromptDialog localPromptDialog = new PromptDialog(localShell);
      boolean[] arrayOfBoolean1 = new boolean[1];
      boolean[] arrayOfBoolean2 = new boolean[1];
      if (paramLong7 != 0L) {
        XPCOM.memmove(arrayOfBoolean1, paramLong7);
      }
      localPromptDialog.promptUsernameAndPassword((String)localObject1, (String)localObject2, (String)localObject3, arrayOfString, (String[])localObject4, arrayOfBoolean1, arrayOfBoolean2);
      XPCOM.memmove(paramLong8, arrayOfBoolean2);
      if (arrayOfBoolean2[0] != 0)
      {
        str1 = arrayOfString[0];
        str2 = localObject4[0];
      }
      if (paramLong7 != 0L) {
        XPCOM.memmove(paramLong7, arrayOfBoolean1);
      }
    }
    if (str1 != null)
    {
      localObject1 = new long[1];
      XPCOM.memmove((long[])localObject1, paramLong4, C.PTR_SIZEOF);
      localObject2 = new long[1];
      XPCOM.memmove((long[])localObject2, paramLong5, C.PTR_SIZEOF);
      localObject3 = new long[1];
      int j = XPCOM.NS_GetServiceManager((long[])localObject3);
      if (j != 0) {
        SWT.error(j);
      }
      if (localObject3[0] == 0L) {
        SWT.error(-2147467262);
      }
      localObject4 = new nsIServiceManager(localObject3[0]);
      localObject3[0] = 0L;
      localObject5 = MozillaDelegate.wcsToMbcs(null, "@mozilla.org/xpcom/memory-service;1", true);
      j = ((nsIServiceManager)localObject4).GetServiceByContractID((byte[])localObject5, IIDStore.GetIID(nsIMemory.class), (long[])localObject3);
      if (j != 0) {
        SWT.error(j);
      }
      if (localObject3[0] == 0L) {
        SWT.error(-2147467262);
      }
      ((nsIServiceManager)localObject4).Release();
      nsIMemory localnsIMemory = new nsIMemory(localObject3[0]);
      localObject3[0] = 0L;
      if (localObject1[0] != 0L) {
        localnsIMemory.Free(localObject1[0]);
      }
      if (localObject2[0] != 0L) {
        localnsIMemory.Free(localObject2[0]);
      }
      localnsIMemory.Release();
      int m = str1.length();
      localObject6 = new char[m + 1];
      str1.getChars(0, m, (char[])localObject6, 0);
      int n = localObject6.length * 2;
      long l = C.malloc(n);
      XPCOM.memmove(l, (char[])localObject6, n);
      XPCOM.memmove(paramLong4, new long[] { l }, C.PTR_SIZEOF);
      m = str2.length();
      localObject6 = new char[m + 1];
      str2.getChars(0, m, (char[])localObject6, 0);
      n = localObject6.length * 2;
      l = C.malloc(n);
      XPCOM.memmove(l, (char[])localObject6, n);
      XPCOM.memmove(paramLong5, new long[] { l }, C.PTR_SIZEOF);
    }
    return 0;
  }
  
  int PromptPassword(long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5, long paramLong6, long paramLong7)
  {
    return -2147467263;
  }
  
  int Select(long paramLong1, long paramLong2, long paramLong3, int paramInt, long paramLong4, long paramLong5, long paramLong6)
  {
    return -2147467263;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/browser/PromptService2.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */