package org.eclipse.swt.internal.cocoa;

public class NSMutableString
  extends NSString
{
  public NSMutableString() {}
  
  public NSMutableString(long paramLong)
  {
    super(paramLong);
  }
  
  public NSMutableString(id paramid)
  {
    super(paramid);
  }
  
  public void appendString(NSString paramNSString)
  {
    OS.objc_msgSend(this.id, OS.sel_appendString_, paramNSString != null ? paramNSString.id : 0L);
  }
  
  public void replaceCharactersInRange(NSRange paramNSRange, NSString paramNSString)
  {
    OS.objc_msgSend(this.id, OS.sel_replaceCharactersInRange_withString_, paramNSRange, paramNSString != null ? paramNSString.id : 0L);
  }
  
  public void setString(NSString paramNSString)
  {
    OS.objc_msgSend(this.id, OS.sel_setString_, paramNSString != null ? paramNSString.id : 0L);
  }
  
  public static NSString string()
  {
    long l = OS.objc_msgSend(OS.class_NSMutableString, OS.sel_string);
    return l != 0L ? new NSString(l) : null;
  }
  
  public static NSString stringWithCharacters(char[] paramArrayOfChar, long paramLong)
  {
    long l = OS.objc_msgSend(OS.class_NSMutableString, OS.sel_stringWithCharacters_length_, paramArrayOfChar, paramLong);
    return l != 0L ? new NSMutableString(l) : null;
  }
  
  public static NSString stringWithFormat(NSString paramNSString)
  {
    long l = OS.objc_msgSend(OS.class_NSMutableString, OS.sel_stringWithFormat_, paramNSString != null ? paramNSString.id : 0L);
    return l != 0L ? new NSString(l) : null;
  }
  
  public static NSString stringWithUTF8String(long paramLong)
  {
    long l = OS.objc_msgSend(OS.class_NSMutableString, OS.sel_stringWithUTF8String_, paramLong);
    return l != 0L ? new NSString(l) : null;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSMutableString.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */