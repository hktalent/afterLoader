package org.eclipse.swt.internal.cocoa;

public class NSHTTPCookie
  extends NSObject
{
  public NSHTTPCookie() {}
  
  public NSHTTPCookie(long paramLong)
  {
    super(paramLong);
  }
  
  public NSHTTPCookie(id paramid)
  {
    super(paramid);
  }
  
  public static NSArray cookiesWithResponseHeaderFields(NSDictionary paramNSDictionary, NSURL paramNSURL)
  {
    long l = OS.objc_msgSend(OS.class_NSHTTPCookie, OS.sel_cookiesWithResponseHeaderFields_forURL_, paramNSDictionary != null ? paramNSDictionary.id : 0L, paramNSURL != null ? paramNSURL.id : 0L);
    return l != 0L ? new NSArray(l) : null;
  }
  
  public boolean isSessionOnly()
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_isSessionOnly);
  }
  
  public NSString name()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_name);
    return l != 0L ? new NSString(l) : null;
  }
  
  public NSString value()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_value);
    return l != 0L ? new NSString(l) : null;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSHTTPCookie.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */