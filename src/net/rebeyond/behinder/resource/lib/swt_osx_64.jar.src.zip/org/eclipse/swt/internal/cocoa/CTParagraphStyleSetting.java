package org.eclipse.swt.internal.cocoa;

public class CTParagraphStyleSetting
{
  public int spec;
  public long valueSize;
  public long value;
  public static final int sizeof = ;
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/CTParagraphStyleSetting.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */