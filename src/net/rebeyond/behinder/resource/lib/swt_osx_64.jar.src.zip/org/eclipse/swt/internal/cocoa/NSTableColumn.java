package org.eclipse.swt.internal.cocoa;

public class NSTableColumn
  extends NSObject
{
  public NSTableColumn() {}
  
  public NSTableColumn(long paramLong)
  {
    super(paramLong);
  }
  
  public NSTableColumn(id paramid)
  {
    super(paramid);
  }
  
  public NSCell dataCell()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_dataCell);
    return l != 0L ? new NSCell(l) : null;
  }
  
  public NSTableHeaderCell headerCell()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_headerCell);
    return l != 0L ? new NSTableHeaderCell(l) : null;
  }
  
  public NSTableColumn initWithIdentifier(NSString paramNSString)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_initWithIdentifier_, paramNSString != null ? paramNSString.id : 0L);
    return l != 0L ? new NSTableColumn(l) : l == this.id ? this : null;
  }
  
  public long resizingMask()
  {
    return OS.objc_msgSend(this.id, OS.sel_resizingMask);
  }
  
  public void setDataCell(NSCell paramNSCell)
  {
    OS.objc_msgSend(this.id, OS.sel_setDataCell_, paramNSCell != null ? paramNSCell.id : 0L);
  }
  
  public void setEditable(boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_setEditable_, paramBoolean);
  }
  
  public void setHeaderCell(NSCell paramNSCell)
  {
    OS.objc_msgSend(this.id, OS.sel_setHeaderCell_, paramNSCell != null ? paramNSCell.id : 0L);
  }
  
  public void setIdentifier(NSString paramNSString)
  {
    OS.objc_msgSend(this.id, OS.sel_setIdentifier_, paramNSString != null ? paramNSString.id : 0L);
  }
  
  public void setMinWidth(double paramDouble)
  {
    OS.objc_msgSend(this.id, OS.sel_setMinWidth_, paramDouble);
  }
  
  public void setResizingMask(long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_setResizingMask_, paramLong);
  }
  
  public void setWidth(double paramDouble)
  {
    OS.objc_msgSend(this.id, OS.sel_setWidth_, paramDouble);
  }
  
  public double width()
  {
    return OS.objc_msgSend_fpret(this.id, OS.sel_width);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSTableColumn.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */