package org.eclipse.swt.internal.cocoa;

public class NSColorPanel
  extends NSPanel
{
  public NSColorPanel() {}
  
  public NSColorPanel(long paramLong)
  {
    super(paramLong);
  }
  
  public NSColorPanel(id paramid)
  {
    super(paramid);
  }
  
  public void attachColorList(NSColorList paramNSColorList)
  {
    OS.objc_msgSend(this.id, OS.sel_attachColorList_, paramNSColorList != null ? paramNSColorList.id : 0L);
  }
  
  public NSColor color()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_color);
    return l != 0L ? new NSColor(l) : null;
  }
  
  public void setColor(NSColor paramNSColor)
  {
    OS.objc_msgSend(this.id, OS.sel_setColor_, paramNSColor != null ? paramNSColor.id : 0L);
  }
  
  public static NSColorPanel sharedColorPanel()
  {
    long l = OS.objc_msgSend(OS.class_NSColorPanel, OS.sel_sharedColorPanel);
    return l != 0L ? new NSColorPanel(l) : null;
  }
  
  public static double minFrameWidthWithTitle(NSString paramNSString, long paramLong)
  {
    return OS.objc_msgSend_fpret(OS.class_NSColorPanel, OS.sel_minFrameWidthWithTitle_styleMask_, paramNSString != null ? paramNSString.id : 0L, paramLong);
  }
  
  public static long windowNumberAtPoint(NSPoint paramNSPoint, long paramLong)
  {
    return OS.objc_msgSend(OS.class_NSColorPanel, OS.sel_windowNumberAtPoint_belowWindowWithWindowNumber_, paramNSPoint, paramLong);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSColorPanel.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */