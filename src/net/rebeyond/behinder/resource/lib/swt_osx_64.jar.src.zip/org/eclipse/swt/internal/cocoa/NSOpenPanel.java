package org.eclipse.swt.internal.cocoa;

public class NSOpenPanel
  extends NSSavePanel
{
  public NSOpenPanel() {}
  
  public NSOpenPanel(long paramLong)
  {
    super(paramLong);
  }
  
  public NSOpenPanel(id paramid)
  {
    super(paramid);
  }
  
  public NSArray filenames()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_filenames);
    return l != 0L ? new NSArray(l) : null;
  }
  
  public static NSOpenPanel openPanel()
  {
    long l = OS.objc_msgSend(OS.class_NSOpenPanel, OS.sel_openPanel);
    return l != 0L ? new NSOpenPanel(l) : null;
  }
  
  public void setAllowsMultipleSelection(boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_setAllowsMultipleSelection_, paramBoolean);
  }
  
  public void setCanChooseDirectories(boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_setCanChooseDirectories_, paramBoolean);
  }
  
  public void setCanChooseFiles(boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_setCanChooseFiles_, paramBoolean);
  }
  
  public static NSSavePanel savePanel()
  {
    long l = OS.objc_msgSend(OS.class_NSOpenPanel, OS.sel_savePanel);
    return l != 0L ? new NSSavePanel(l) : null;
  }
  
  public static double minFrameWidthWithTitle(NSString paramNSString, long paramLong)
  {
    return OS.objc_msgSend_fpret(OS.class_NSOpenPanel, OS.sel_minFrameWidthWithTitle_styleMask_, paramNSString != null ? paramNSString.id : 0L, paramLong);
  }
  
  public static long windowNumberAtPoint(NSPoint paramNSPoint, long paramLong)
  {
    return OS.objc_msgSend(OS.class_NSOpenPanel, OS.sel_windowNumberAtPoint_belowWindowWithWindowNumber_, paramNSPoint, paramLong);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSOpenPanel.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */