package org.eclipse.swt.internal.cocoa;

public class NSSecureTextField
  extends NSTextField
{
  public NSSecureTextField() {}
  
  public NSSecureTextField(long paramLong)
  {
    super(paramLong);
  }
  
  public NSSecureTextField(id paramid)
  {
    super(paramid);
  }
  
  public static long cellClass()
  {
    return OS.objc_msgSend(OS.class_NSSecureTextField, OS.sel_cellClass);
  }
  
  public static void setCellClass(long paramLong)
  {
    OS.objc_msgSend(OS.class_NSSecureTextField, OS.sel_setCellClass_, paramLong);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSSecureTextField.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */