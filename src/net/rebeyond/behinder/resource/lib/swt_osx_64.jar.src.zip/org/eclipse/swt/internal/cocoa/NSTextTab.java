package org.eclipse.swt.internal.cocoa;

public class NSTextTab
  extends NSObject
{
  public NSTextTab() {}
  
  public NSTextTab(long paramLong)
  {
    super(paramLong);
  }
  
  public NSTextTab(id paramid)
  {
    super(paramid);
  }
  
  public NSTextTab initWithType(long paramLong, double paramDouble)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_initWithType_location_, paramLong, paramDouble);
    return l != 0L ? new NSTextTab(l) : l == this.id ? this : null;
  }
  
  public double location()
  {
    return OS.objc_msgSend_fpret(this.id, OS.sel_location);
  }
  
  public long tabStopType()
  {
    return OS.objc_msgSend(this.id, OS.sel_tabStopType);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSTextTab.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */