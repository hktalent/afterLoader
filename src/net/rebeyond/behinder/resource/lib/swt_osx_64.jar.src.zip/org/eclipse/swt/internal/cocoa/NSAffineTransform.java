package org.eclipse.swt.internal.cocoa;

public class NSAffineTransform
  extends NSObject
{
  public NSAffineTransform() {}
  
  public NSAffineTransform(long paramLong)
  {
    super(paramLong);
  }
  
  public NSAffineTransform(id paramid)
  {
    super(paramid);
  }
  
  public void concat()
  {
    OS.objc_msgSend(this.id, OS.sel_concat);
  }
  
  public void set()
  {
    OS.objc_msgSend(this.id, OS.sel_set);
  }
  
  public NSAffineTransform initWithTransform(NSAffineTransform paramNSAffineTransform)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_initWithTransform_, paramNSAffineTransform != null ? paramNSAffineTransform.id : 0L);
    return l != 0L ? new NSAffineTransform(l) : l == this.id ? this : null;
  }
  
  public void invert()
  {
    OS.objc_msgSend(this.id, OS.sel_invert);
  }
  
  public void prependTransform(NSAffineTransform paramNSAffineTransform)
  {
    OS.objc_msgSend(this.id, OS.sel_prependTransform_, paramNSAffineTransform != null ? paramNSAffineTransform.id : 0L);
  }
  
  public void rotateByDegrees(double paramDouble)
  {
    OS.objc_msgSend(this.id, OS.sel_rotateByDegrees_, paramDouble);
  }
  
  public void scaleXBy(double paramDouble1, double paramDouble2)
  {
    OS.objc_msgSend(this.id, OS.sel_scaleXBy_yBy_, paramDouble1, paramDouble2);
  }
  
  public void setTransformStruct(NSAffineTransformStruct paramNSAffineTransformStruct)
  {
    OS.objc_msgSend(this.id, OS.sel_setTransformStruct_, paramNSAffineTransformStruct);
  }
  
  public static NSAffineTransform transform()
  {
    long l = OS.objc_msgSend(OS.class_NSAffineTransform, OS.sel_transform);
    return l != 0L ? new NSAffineTransform(l) : null;
  }
  
  public NSPoint transformPoint(NSPoint paramNSPoint)
  {
    NSPoint localNSPoint = new NSPoint();
    OS.objc_msgSend_stret(localNSPoint, this.id, OS.sel_transformPoint_, paramNSPoint);
    return localNSPoint;
  }
  
  public NSSize transformSize(NSSize paramNSSize)
  {
    NSSize localNSSize = new NSSize();
    OS.objc_msgSend_stret(localNSSize, this.id, OS.sel_transformSize_, paramNSSize);
    return localNSSize;
  }
  
  public NSAffineTransformStruct transformStruct()
  {
    NSAffineTransformStruct localNSAffineTransformStruct = new NSAffineTransformStruct();
    OS.objc_msgSend_stret(localNSAffineTransformStruct, this.id, OS.sel_transformStruct);
    return localNSAffineTransformStruct;
  }
  
  public void translateXBy(double paramDouble1, double paramDouble2)
  {
    OS.objc_msgSend(this.id, OS.sel_translateXBy_yBy_, paramDouble1, paramDouble2);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSAffineTransform.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */