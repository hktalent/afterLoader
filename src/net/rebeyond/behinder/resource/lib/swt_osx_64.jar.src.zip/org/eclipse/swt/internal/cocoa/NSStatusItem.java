package org.eclipse.swt.internal.cocoa;

public class NSStatusItem
  extends NSObject
{
  public NSStatusItem() {}
  
  public NSStatusItem(long paramLong)
  {
    super(paramLong);
  }
  
  public NSStatusItem(id paramid)
  {
    super(paramid);
  }
  
  public void drawStatusBarBackgroundInRect(NSRect paramNSRect, boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_drawStatusBarBackgroundInRect_withHighlight_, paramNSRect, paramBoolean);
  }
  
  public void popUpStatusItemMenu(NSMenu paramNSMenu)
  {
    OS.objc_msgSend(this.id, OS.sel_popUpStatusItemMenu_, paramNSMenu != null ? paramNSMenu.id : 0L);
  }
  
  public void setHighlightMode(boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_setHighlightMode_, paramBoolean);
  }
  
  public void setLength(double paramDouble)
  {
    OS.objc_msgSend(this.id, OS.sel_setLength_, paramDouble);
  }
  
  public void setView(NSView paramNSView)
  {
    OS.objc_msgSend(this.id, OS.sel_setView_, paramNSView != null ? paramNSView.id : 0L);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSStatusItem.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */