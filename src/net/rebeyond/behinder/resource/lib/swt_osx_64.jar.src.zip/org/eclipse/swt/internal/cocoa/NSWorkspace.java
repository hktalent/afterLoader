package org.eclipse.swt.internal.cocoa;

public class NSWorkspace
  extends NSObject
{
  public NSWorkspace() {}
  
  public NSWorkspace(long paramLong)
  {
    super(paramLong);
  }
  
  public NSWorkspace(id paramid)
  {
    super(paramid);
  }
  
  public NSString fullPathForApplication(NSString paramNSString)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_fullPathForApplication_, paramNSString != null ? paramNSString.id : 0L);
    return l != 0L ? new NSString(l) : null;
  }
  
  public boolean getInfoForFile(NSString paramNSString, long paramLong1, long paramLong2)
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_getInfoForFile_application_type_, paramNSString != null ? paramNSString.id : 0L, paramLong1, paramLong2);
  }
  
  public NSImage iconForFile(NSString paramNSString)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_iconForFile_, paramNSString != null ? paramNSString.id : 0L);
    return l != 0L ? new NSImage(l) : null;
  }
  
  public NSImage iconForFileType(NSString paramNSString)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_iconForFileType_, paramNSString != null ? paramNSString.id : 0L);
    return l != 0L ? new NSImage(l) : null;
  }
  
  public boolean isFilePackageAtPath(NSString paramNSString)
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_isFilePackageAtPath_, paramNSString != null ? paramNSString.id : 0L);
  }
  
  public boolean openFile(NSString paramNSString1, NSString paramNSString2)
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_openFile_withApplication_, paramNSString1 != null ? paramNSString1.id : 0L, paramNSString2 != null ? paramNSString2.id : 0L);
  }
  
  public boolean openURL(NSURL paramNSURL)
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_openURL_, paramNSURL != null ? paramNSURL.id : 0L);
  }
  
  public boolean openURLs(NSArray paramNSArray, NSString paramNSString, long paramLong1, NSAppleEventDescriptor paramNSAppleEventDescriptor, long paramLong2)
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_openURLs_withAppBundleIdentifier_options_additionalEventParamDescriptor_launchIdentifiers_, paramNSArray != null ? paramNSArray.id : 0L, paramNSString != null ? paramNSString.id : 0L, paramLong1, paramNSAppleEventDescriptor != null ? paramNSAppleEventDescriptor.id : 0L, paramLong2);
  }
  
  public static NSWorkspace sharedWorkspace()
  {
    long l = OS.objc_msgSend(OS.class_NSWorkspace, OS.sel_sharedWorkspace);
    return l != 0L ? new NSWorkspace(l) : null;
  }
  
  public boolean type(NSString paramNSString1, NSString paramNSString2)
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_type_conformsToType_, paramNSString1 != null ? paramNSString1.id : 0L, paramNSString2 != null ? paramNSString2.id : 0L);
  }
  
  public NSString typeOfFile(NSString paramNSString, long paramLong)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_typeOfFile_error_, paramNSString != null ? paramNSString.id : 0L, paramLong);
    return l != 0L ? new NSString(l) : null;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSWorkspace.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */