package org.eclipse.swt.internal.cocoa;

public class NSPopUpButton
  extends NSButton
{
  public NSPopUpButton() {}
  
  public NSPopUpButton(long paramLong)
  {
    super(paramLong);
  }
  
  public NSPopUpButton(id paramid)
  {
    super(paramid);
  }
  
  public long indexOfSelectedItem()
  {
    return OS.objc_msgSend(this.id, OS.sel_indexOfSelectedItem);
  }
  
  public NSPopUpButton initWithFrame(NSRect paramNSRect, boolean paramBoolean)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_initWithFrame_pullsDown_, paramNSRect, paramBoolean);
    return l != 0L ? new NSPopUpButton(l) : l == this.id ? this : null;
  }
  
  public NSMenuItem itemAtIndex(long paramLong)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_itemAtIndex_, paramLong);
    return l != 0L ? new NSMenuItem(l) : null;
  }
  
  public NSString itemTitleAtIndex(long paramLong)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_itemTitleAtIndex_, paramLong);
    return l != 0L ? new NSString(l) : null;
  }
  
  public NSMenu menu()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_menu);
    return l != 0L ? new NSMenu(l) : null;
  }
  
  public long numberOfItems()
  {
    return OS.objc_msgSend(this.id, OS.sel_numberOfItems);
  }
  
  public void removeAllItems()
  {
    OS.objc_msgSend(this.id, OS.sel_removeAllItems);
  }
  
  public void removeItemAtIndex(long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_removeItemAtIndex_, paramLong);
  }
  
  public void selectItem(NSMenuItem paramNSMenuItem)
  {
    OS.objc_msgSend(this.id, OS.sel_selectItem_, paramNSMenuItem != null ? paramNSMenuItem.id : 0L);
  }
  
  public void selectItemAtIndex(long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_selectItemAtIndex_, paramLong);
  }
  
  public void setAutoenablesItems(boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_setAutoenablesItems_, paramBoolean);
  }
  
  public void setPullsDown(boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_setPullsDown_, paramBoolean);
  }
  
  public NSString titleOfSelectedItem()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_titleOfSelectedItem);
    return l != 0L ? new NSString(l) : null;
  }
  
  public static long cellClass()
  {
    return OS.objc_msgSend(OS.class_NSPopUpButton, OS.sel_cellClass);
  }
  
  public static void setCellClass(long paramLong)
  {
    OS.objc_msgSend(OS.class_NSPopUpButton, OS.sel_setCellClass_, paramLong);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSPopUpButton.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */