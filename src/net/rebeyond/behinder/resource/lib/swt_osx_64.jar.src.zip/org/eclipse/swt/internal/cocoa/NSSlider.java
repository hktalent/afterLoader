package org.eclipse.swt.internal.cocoa;

public class NSSlider
  extends NSControl
{
  public NSSlider() {}
  
  public NSSlider(long paramLong)
  {
    super(paramLong);
  }
  
  public NSSlider(id paramid)
  {
    super(paramid);
  }
  
  public double knobThickness()
  {
    return OS.objc_msgSend_fpret(this.id, OS.sel_knobThickness);
  }
  
  public double maxValue()
  {
    return OS.objc_msgSend_fpret(this.id, OS.sel_maxValue);
  }
  
  public double minValue()
  {
    return OS.objc_msgSend_fpret(this.id, OS.sel_minValue);
  }
  
  public void setMaxValue(double paramDouble)
  {
    OS.objc_msgSend(this.id, OS.sel_setMaxValue_, paramDouble);
  }
  
  public void setMinValue(double paramDouble)
  {
    OS.objc_msgSend(this.id, OS.sel_setMinValue_, paramDouble);
  }
  
  public static long cellClass()
  {
    return OS.objc_msgSend(OS.class_NSSlider, OS.sel_cellClass);
  }
  
  public static void setCellClass(long paramLong)
  {
    OS.objc_msgSend(OS.class_NSSlider, OS.sel_setCellClass_, paramLong);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSSlider.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */