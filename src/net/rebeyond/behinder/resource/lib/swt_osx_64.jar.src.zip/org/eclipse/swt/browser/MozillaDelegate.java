package org.eclipse.swt.browser;

import java.io.File;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.internal.cocoa.NSApplication;
import org.eclipse.swt.internal.cocoa.NSArray;
import org.eclipse.swt.internal.cocoa.NSFileManager;
import org.eclipse.swt.internal.cocoa.NSMenu;
import org.eclipse.swt.internal.cocoa.NSScreen;
import org.eclipse.swt.internal.cocoa.NSString;
import org.eclipse.swt.internal.cocoa.NSURL;
import org.eclipse.swt.internal.cocoa.NSView;
import org.eclipse.swt.internal.cocoa.NSWindow;
import org.eclipse.swt.internal.cocoa.OS;
import org.eclipse.swt.internal.mozilla.nsIBaseWindow;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Shell;

class MozillaDelegate
{
  Browser browser;
  Shell eventShell;
  Listener listener;
  boolean hasFocus;
  static Boolean IsXULRunner24;
  static final String LIB_XPCOM = "libxpcom.dylib";
  static final String LIB_XUL = "XUL";
  static final String MOZILLA_RUNNING = "org.eclipse.swt.internal.mozillaRunning";
  
  MozillaDelegate(Browser paramBrowser)
  {
    this.browser = paramBrowser;
  }
  
  static Browser findBrowser(long paramLong)
  {
    Display localDisplay = Display.getCurrent();
    return (Browser)localDisplay.findWidget(paramLong);
  }
  
  static String getCacheParentPath()
  {
    if (OS.VERSION >= 4192)
    {
      localObject = NSFileManager.defaultManager().URLsForDirectory(13L, 1L);
      if (((NSArray)localObject).count() > 0L)
      {
        NSURL localNSURL = new NSURL(((NSArray)localObject).objectAtIndex(0L));
        return localNSURL.path().getString() + Mozilla.SEPARATOR_OS + "eclipse";
      }
    }
    Object localObject = System.getProperty("user.home");
    return (String)localObject + "/Library/Caches/eclipse";
  }
  
  static String[] getJSLibraryNames()
  {
    return new String[] { "libxpcom.dylib" };
  }
  
  static String getJSLibraryName_Pre10()
  {
    return "libmozjs.dylib";
  }
  
  static String getLibraryName(String paramString)
  {
    if (IsXULRunner24 == null) {
      IsXULRunner24 = new File(paramString, "libxpcom.dylib").exists() ? Boolean.FALSE : Boolean.TRUE;
    }
    return IsXULRunner24.booleanValue() ? "XUL" : "libxpcom.dylib";
  }
  
  static String getProfilePath()
  {
    String str = System.getProperty("user.home");
    return str + Mozilla.SEPARATOR_OS + ".mozilla" + Mozilla.SEPARATOR_OS + "eclipse";
  }
  
  static String getSWTInitLibraryName()
  {
    return "swt-xulrunner";
  }
  
  static void loadAdditionalLibraries(String paramString, boolean paramBoolean)
  {
    if (!paramBoolean)
    {
      String str = paramString + Mozilla.SEPARATOR_OS + "libmozutils.dylib";
      byte[] arrayOfByte = wcsToMbcs(null, str, true);
      OS.NSAddImage(arrayOfByte, 9);
    }
  }
  
  static char[] mbcsToWcs(String paramString, byte[] paramArrayOfByte)
  {
    return new String(paramArrayOfByte).toCharArray();
  }
  
  static boolean needsSpinup()
  {
    return false;
  }
  
  static byte[] wcsToMbcs(String paramString1, String paramString2, boolean paramBoolean)
  {
    if (paramBoolean) {
      paramString2 = paramString2 + "\000";
    }
    return paramString2.getBytes();
  }
  
  void addWindowSubclass() {}
  
  int createBaseWindow(nsIBaseWindow paramnsIBaseWindow)
  {
    this.browser.getDisplay().setData("org.eclipse.swt.internal.mozillaRunning", Boolean.TRUE);
    NSApplication localNSApplication = NSApplication.sharedApplication();
    NSMenu localNSMenu = localNSApplication.mainMenu();
    if (localNSMenu != null) {
      localNSMenu.retain();
    }
    int i = paramnsIBaseWindow.Create();
    localNSApplication.setMainMenu(localNSMenu);
    if (localNSMenu != null) {
      localNSMenu.release();
    }
    ((Mozilla)this.browser.webBrowser).Activate();
    return i;
  }
  
  long getHandle()
  {
    return this.browser.view.id;
  }
  
  Point getNativeSize(int paramInt1, int paramInt2)
  {
    if (IsXULRunner24.booleanValue())
    {
      NSScreen localNSScreen = this.browser.view.window().screen();
      double d = localNSScreen.backingScaleFactor();
      return new Point((int)(paramInt1 * d), (int)(paramInt2 * d));
    }
    return new Point(paramInt1, paramInt2);
  }
  
  long getSiteWindow()
  {
    return this.browser.view.id;
  }
  
  void handleFocus()
  {
    if (this.hasFocus) {
      return;
    }
    this.hasFocus = true;
    ((Mozilla)this.browser.webBrowser).Activate();
    this.browser.setFocus();
    this.listener = new Listener()
    {
      public void handleEvent(Event paramAnonymousEvent)
      {
        if (paramAnonymousEvent.widget == MozillaDelegate.this.browser) {
          return;
        }
        if (paramAnonymousEvent.type != 12)
        {
          ((Mozilla)MozillaDelegate.this.browser.webBrowser).Deactivate();
          MozillaDelegate.this.hasFocus = false;
        }
        MozillaDelegate.this.eventShell.getDisplay().removeFilter(15, this);
        MozillaDelegate.this.eventShell.removeListener(27, this);
        MozillaDelegate.this.eventShell.removeListener(12, this);
        MozillaDelegate.this.eventShell = null;
        MozillaDelegate.this.listener = null;
      }
    };
    this.eventShell = this.browser.getShell();
    this.eventShell.getDisplay().addFilter(15, this.listener);
    this.eventShell.addListener(27, this.listener);
    this.eventShell.addListener(12, this.listener);
  }
  
  void handleMouseDown()
  {
    Mozilla localMozilla = (Mozilla)this.browser.webBrowser;
    if (!localMozilla.isActive) {
      localMozilla.Activate();
    }
  }
  
  boolean hookEnterExit()
  {
    return true;
  }
  
  void init() {}
  
  void onDispose(long paramLong)
  {
    if (this.listener != null)
    {
      this.eventShell.getDisplay().removeFilter(15, this.listener);
      this.eventShell.removeListener(27, this.listener);
      this.eventShell.removeListener(12, this.listener);
      this.eventShell = null;
      this.listener = null;
    }
    this.browser = null;
  }
  
  void removeWindowSubclass() {}
  
  boolean sendTraverse()
  {
    return true;
  }
  
  void setSize(long paramLong, int paramInt1, int paramInt2) {}
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/browser/MozillaDelegate.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */