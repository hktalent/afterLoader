package org.eclipse.swt.internal.cocoa;

public class NSResponder
  extends NSObject
{
  public NSResponder() {}
  
  public NSResponder(long paramLong)
  {
    super(paramLong);
  }
  
  public NSResponder(id paramid)
  {
    super(paramid);
  }
  
  public boolean acceptsFirstResponder()
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_acceptsFirstResponder);
  }
  
  public boolean becomeFirstResponder()
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_becomeFirstResponder);
  }
  
  public void beginGestureWithEvent(NSEvent paramNSEvent)
  {
    OS.objc_msgSend(this.id, OS.sel_beginGestureWithEvent_, paramNSEvent != null ? paramNSEvent.id : 0L);
  }
  
  public void cancelOperation(id paramid)
  {
    OS.objc_msgSend(this.id, OS.sel_cancelOperation_, paramid != null ? paramid.id : 0L);
  }
  
  public void cursorUpdate(NSEvent paramNSEvent)
  {
    OS.objc_msgSend(this.id, OS.sel_cursorUpdate_, paramNSEvent != null ? paramNSEvent.id : 0L);
  }
  
  public void doCommandBySelector(long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_doCommandBySelector_, paramLong);
  }
  
  public void endGestureWithEvent(NSEvent paramNSEvent)
  {
    OS.objc_msgSend(this.id, OS.sel_endGestureWithEvent_, paramNSEvent != null ? paramNSEvent.id : 0L);
  }
  
  public void flagsChanged(NSEvent paramNSEvent)
  {
    OS.objc_msgSend(this.id, OS.sel_flagsChanged_, paramNSEvent != null ? paramNSEvent.id : 0L);
  }
  
  public void helpRequested(NSEvent paramNSEvent)
  {
    OS.objc_msgSend(this.id, OS.sel_helpRequested_, paramNSEvent != null ? paramNSEvent.id : 0L);
  }
  
  public void insertText(id paramid)
  {
    OS.objc_msgSend(this.id, OS.sel_insertText_, paramid != null ? paramid.id : 0L);
  }
  
  public void interpretKeyEvents(NSArray paramNSArray)
  {
    OS.objc_msgSend(this.id, OS.sel_interpretKeyEvents_, paramNSArray != null ? paramNSArray.id : 0L);
  }
  
  public void keyDown(NSEvent paramNSEvent)
  {
    OS.objc_msgSend(this.id, OS.sel_keyDown_, paramNSEvent != null ? paramNSEvent.id : 0L);
  }
  
  public void keyUp(NSEvent paramNSEvent)
  {
    OS.objc_msgSend(this.id, OS.sel_keyUp_, paramNSEvent != null ? paramNSEvent.id : 0L);
  }
  
  public void magnifyWithEvent(NSEvent paramNSEvent)
  {
    OS.objc_msgSend(this.id, OS.sel_magnifyWithEvent_, paramNSEvent != null ? paramNSEvent.id : 0L);
  }
  
  public void mouseDown(NSEvent paramNSEvent)
  {
    OS.objc_msgSend(this.id, OS.sel_mouseDown_, paramNSEvent != null ? paramNSEvent.id : 0L);
  }
  
  public void mouseDragged(NSEvent paramNSEvent)
  {
    OS.objc_msgSend(this.id, OS.sel_mouseDragged_, paramNSEvent != null ? paramNSEvent.id : 0L);
  }
  
  public void mouseEntered(NSEvent paramNSEvent)
  {
    OS.objc_msgSend(this.id, OS.sel_mouseEntered_, paramNSEvent != null ? paramNSEvent.id : 0L);
  }
  
  public void mouseExited(NSEvent paramNSEvent)
  {
    OS.objc_msgSend(this.id, OS.sel_mouseExited_, paramNSEvent != null ? paramNSEvent.id : 0L);
  }
  
  public void mouseMoved(NSEvent paramNSEvent)
  {
    OS.objc_msgSend(this.id, OS.sel_mouseMoved_, paramNSEvent != null ? paramNSEvent.id : 0L);
  }
  
  public void mouseUp(NSEvent paramNSEvent)
  {
    OS.objc_msgSend(this.id, OS.sel_mouseUp_, paramNSEvent != null ? paramNSEvent.id : 0L);
  }
  
  public void moveToBeginningOfParagraph(id paramid)
  {
    OS.objc_msgSend(this.id, OS.sel_moveToBeginningOfParagraph_, paramid != null ? paramid.id : 0L);
  }
  
  public void moveToEndOfParagraph(id paramid)
  {
    OS.objc_msgSend(this.id, OS.sel_moveToEndOfParagraph_, paramid != null ? paramid.id : 0L);
  }
  
  public void moveUp(id paramid)
  {
    OS.objc_msgSend(this.id, OS.sel_moveUp_, paramid != null ? paramid.id : 0L);
  }
  
  public void noResponderFor(long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_noResponderFor_, paramLong);
  }
  
  public void otherMouseDown(NSEvent paramNSEvent)
  {
    OS.objc_msgSend(this.id, OS.sel_otherMouseDown_, paramNSEvent != null ? paramNSEvent.id : 0L);
  }
  
  public void otherMouseDragged(NSEvent paramNSEvent)
  {
    OS.objc_msgSend(this.id, OS.sel_otherMouseDragged_, paramNSEvent != null ? paramNSEvent.id : 0L);
  }
  
  public void otherMouseUp(NSEvent paramNSEvent)
  {
    OS.objc_msgSend(this.id, OS.sel_otherMouseUp_, paramNSEvent != null ? paramNSEvent.id : 0L);
  }
  
  public void pageDown(id paramid)
  {
    OS.objc_msgSend(this.id, OS.sel_pageDown_, paramid != null ? paramid.id : 0L);
  }
  
  public void pageUp(id paramid)
  {
    OS.objc_msgSend(this.id, OS.sel_pageUp_, paramid != null ? paramid.id : 0L);
  }
  
  public boolean performKeyEquivalent(NSEvent paramNSEvent)
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_performKeyEquivalent_, paramNSEvent != null ? paramNSEvent.id : 0L);
  }
  
  public boolean resignFirstResponder()
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_resignFirstResponder);
  }
  
  public void rightMouseDown(NSEvent paramNSEvent)
  {
    OS.objc_msgSend(this.id, OS.sel_rightMouseDown_, paramNSEvent != null ? paramNSEvent.id : 0L);
  }
  
  public void rightMouseDragged(NSEvent paramNSEvent)
  {
    OS.objc_msgSend(this.id, OS.sel_rightMouseDragged_, paramNSEvent != null ? paramNSEvent.id : 0L);
  }
  
  public void rightMouseUp(NSEvent paramNSEvent)
  {
    OS.objc_msgSend(this.id, OS.sel_rightMouseUp_, paramNSEvent != null ? paramNSEvent.id : 0L);
  }
  
  public void rotateWithEvent(NSEvent paramNSEvent)
  {
    OS.objc_msgSend(this.id, OS.sel_rotateWithEvent_, paramNSEvent != null ? paramNSEvent.id : 0L);
  }
  
  public void scrollWheel(NSEvent paramNSEvent)
  {
    OS.objc_msgSend(this.id, OS.sel_scrollWheel_, paramNSEvent != null ? paramNSEvent.id : 0L);
  }
  
  public void swipeWithEvent(NSEvent paramNSEvent)
  {
    OS.objc_msgSend(this.id, OS.sel_swipeWithEvent_, paramNSEvent != null ? paramNSEvent.id : 0L);
  }
  
  public void touchesBeganWithEvent(NSEvent paramNSEvent)
  {
    OS.objc_msgSend(this.id, OS.sel_touchesBeganWithEvent_, paramNSEvent != null ? paramNSEvent.id : 0L);
  }
  
  public void touchesCancelledWithEvent(NSEvent paramNSEvent)
  {
    OS.objc_msgSend(this.id, OS.sel_touchesCancelledWithEvent_, paramNSEvent != null ? paramNSEvent.id : 0L);
  }
  
  public void touchesEndedWithEvent(NSEvent paramNSEvent)
  {
    OS.objc_msgSend(this.id, OS.sel_touchesEndedWithEvent_, paramNSEvent != null ? paramNSEvent.id : 0L);
  }
  
  public void touchesMovedWithEvent(NSEvent paramNSEvent)
  {
    OS.objc_msgSend(this.id, OS.sel_touchesMovedWithEvent_, paramNSEvent != null ? paramNSEvent.id : 0L);
  }
  
  public NSUndoManager undoManager()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_undoManager);
    return l != 0L ? new NSUndoManager(l) : null;
  }
  
  public id validRequestorForSendType(NSString paramNSString1, NSString paramNSString2)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_validRequestorForSendType_returnType_, paramNSString1 != null ? paramNSString1.id : 0L, paramNSString2 != null ? paramNSString2.id : 0L);
    return l != 0L ? new id(l) : null;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSResponder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */