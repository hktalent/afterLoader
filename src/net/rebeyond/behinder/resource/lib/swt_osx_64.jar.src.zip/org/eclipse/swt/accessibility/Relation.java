package org.eclipse.swt.accessibility;

import org.eclipse.swt.internal.cocoa.NSMutableArray;
import org.eclipse.swt.internal.cocoa.id;

class Relation
{
  Accessible accessible;
  Accessible[] targets;
  int type;
  
  Relation(Accessible paramAccessible, int paramInt)
  {
    this.accessible = paramAccessible;
    this.type = paramInt;
    this.targets = new Accessible[0];
  }
  
  void addTarget(Accessible paramAccessible)
  {
    if (containsTarget(paramAccessible)) {
      return;
    }
    Accessible[] arrayOfAccessible = new Accessible[this.targets.length + 1];
    System.arraycopy(this.targets, 0, arrayOfAccessible, 0, this.targets.length);
    arrayOfAccessible[this.targets.length] = paramAccessible;
    this.targets = arrayOfAccessible;
  }
  
  boolean containsTarget(Accessible paramAccessible)
  {
    for (int i = 0; i < this.targets.length; i++) {
      if (this.targets[i] == paramAccessible) {
        return true;
      }
    }
    return false;
  }
  
  void removeTarget(Accessible paramAccessible)
  {
    if (!containsTarget(paramAccessible)) {
      return;
    }
    Accessible[] arrayOfAccessible = new Accessible[this.targets.length - 1];
    int i = 0;
    for (int j = 0; j < this.targets.length; j++) {
      if (this.targets[j] != paramAccessible) {
        arrayOfAccessible[(i++)] = this.targets[j];
      }
    }
    this.targets = arrayOfAccessible;
  }
  
  id getTitleUIElement()
  {
    id localid = null;
    for (int i = 0; i < this.targets.length; i++)
    {
      Accessible localAccessible = this.targets[i];
      localid = localAccessible.accessibleHandle(localAccessible);
    }
    return localid;
  }
  
  id getServesAsTitleForUIElements()
  {
    NSMutableArray localNSMutableArray = NSMutableArray.arrayWithCapacity(this.targets.length);
    for (int i = 0; i < this.targets.length; i++)
    {
      Accessible localAccessible = this.targets[i];
      id localid = localAccessible.accessibleHandle(localAccessible);
      localNSMutableArray.addObject(localid);
    }
    return localNSMutableArray;
  }
  
  id getLinkedUIElements()
  {
    NSMutableArray localNSMutableArray = NSMutableArray.arrayWithCapacity(this.targets.length);
    for (int i = 0; i < this.targets.length; i++)
    {
      Accessible localAccessible = this.targets[i];
      id localid = localAccessible.accessibleHandle(localAccessible);
      localNSMutableArray.addObject(localid);
    }
    return localNSMutableArray;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/accessibility/Relation.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */