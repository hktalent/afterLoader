package org.eclipse.swt.custom;

public class CTabFolder2Adapter
  implements CTabFolder2Listener
{
  public void close(CTabFolderEvent paramCTabFolderEvent) {}
  
  public void minimize(CTabFolderEvent paramCTabFolderEvent) {}
  
  public void maximize(CTabFolderEvent paramCTabFolderEvent) {}
  
  public void restore(CTabFolderEvent paramCTabFolderEvent) {}
  
  public void showList(CTabFolderEvent paramCTabFolderEvent) {}
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/custom/CTabFolder2Adapter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */