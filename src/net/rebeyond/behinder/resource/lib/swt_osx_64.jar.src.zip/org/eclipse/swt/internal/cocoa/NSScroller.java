package org.eclipse.swt.internal.cocoa;

public class NSScroller
  extends NSControl
{
  public NSScroller() {}
  
  public NSScroller(long paramLong)
  {
    super(paramLong);
  }
  
  public NSScroller(id paramid)
  {
    super(paramid);
  }
  
  public long controlSize()
  {
    return OS.objc_msgSend(this.id, OS.sel_controlSize);
  }
  
  public long hitPart()
  {
    return OS.objc_msgSend(this.id, OS.sel_hitPart);
  }
  
  public double knobProportion()
  {
    return OS.objc_msgSend_fpret(this.id, OS.sel_knobProportion);
  }
  
  public NSRect rectForPart(long paramLong)
  {
    NSRect localNSRect = new NSRect();
    OS.objc_msgSend_stret(localNSRect, this.id, OS.sel_rectForPart_, paramLong);
    return localNSRect;
  }
  
  public static double scrollerWidth()
  {
    return OS.objc_msgSend_fpret(OS.class_NSScroller, OS.sel_scrollerWidth);
  }
  
  public static double scrollerWidthForControlSize(long paramLong)
  {
    return OS.objc_msgSend_fpret(OS.class_NSScroller, OS.sel_scrollerWidthForControlSize_, paramLong);
  }
  
  public void setControlSize(long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_setControlSize_, paramLong);
  }
  
  public void setKnobProportion(double paramDouble)
  {
    OS.objc_msgSend(this.id, OS.sel_setKnobProportion_, paramDouble);
  }
  
  public long testPart(NSPoint paramNSPoint)
  {
    return OS.objc_msgSend(this.id, OS.sel_testPart_, paramNSPoint);
  }
  
  public static long cellClass()
  {
    return OS.objc_msgSend(OS.class_NSScroller, OS.sel_cellClass);
  }
  
  public static void setCellClass(long paramLong)
  {
    OS.objc_msgSend(OS.class_NSScroller, OS.sel_setCellClass_, paramLong);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSScroller.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */