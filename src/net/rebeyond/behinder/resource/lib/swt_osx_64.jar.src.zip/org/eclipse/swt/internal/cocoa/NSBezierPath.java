package org.eclipse.swt.internal.cocoa;

public class NSBezierPath
  extends NSObject
{
  public NSBezierPath() {}
  
  public NSBezierPath(long paramLong)
  {
    super(paramLong);
  }
  
  public NSBezierPath(id paramid)
  {
    super(paramid);
  }
  
  public void addClip()
  {
    OS.objc_msgSend(this.id, OS.sel_addClip);
  }
  
  public void appendBezierPath(NSBezierPath paramNSBezierPath)
  {
    OS.objc_msgSend(this.id, OS.sel_appendBezierPath_, paramNSBezierPath != null ? paramNSBezierPath.id : 0L);
  }
  
  public void appendBezierPathWithArcWithCenter(NSPoint paramNSPoint, double paramDouble1, double paramDouble2, double paramDouble3)
  {
    OS.objc_msgSend(this.id, OS.sel_appendBezierPathWithArcWithCenter_radius_startAngle_endAngle_, paramNSPoint, paramDouble1, paramDouble2, paramDouble3);
  }
  
  public void appendBezierPathWithArcWithCenter(NSPoint paramNSPoint, double paramDouble1, double paramDouble2, double paramDouble3, boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_appendBezierPathWithArcWithCenter_radius_startAngle_endAngle_clockwise_, paramNSPoint, paramDouble1, paramDouble2, paramDouble3, paramBoolean);
  }
  
  public void appendBezierPathWithGlyphs(long paramLong1, long paramLong2, NSFont paramNSFont)
  {
    OS.objc_msgSend(this.id, OS.sel_appendBezierPathWithGlyphs_count_inFont_, paramLong1, paramLong2, paramNSFont != null ? paramNSFont.id : 0L);
  }
  
  public void appendBezierPathWithOvalInRect(NSRect paramNSRect)
  {
    OS.objc_msgSend(this.id, OS.sel_appendBezierPathWithOvalInRect_, paramNSRect);
  }
  
  public void appendBezierPathWithRect(NSRect paramNSRect)
  {
    OS.objc_msgSend(this.id, OS.sel_appendBezierPathWithRect_, paramNSRect);
  }
  
  public void appendBezierPathWithRoundedRect(NSRect paramNSRect, double paramDouble1, double paramDouble2)
  {
    OS.objc_msgSend(this.id, OS.sel_appendBezierPathWithRoundedRect_xRadius_yRadius_, paramNSRect, paramDouble1, paramDouble2);
  }
  
  public static NSBezierPath bezierPath()
  {
    long l = OS.objc_msgSend(OS.class_NSBezierPath, OS.sel_bezierPath);
    return l != 0L ? new NSBezierPath(l) : null;
  }
  
  public NSBezierPath bezierPathByFlatteningPath()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_bezierPathByFlatteningPath);
    return l != 0L ? new NSBezierPath(l) : l == this.id ? this : null;
  }
  
  public static NSBezierPath bezierPathWithRect(NSRect paramNSRect)
  {
    long l = OS.objc_msgSend(OS.class_NSBezierPath, OS.sel_bezierPathWithRect_, paramNSRect);
    return l != 0L ? new NSBezierPath(l) : null;
  }
  
  public NSRect bounds()
  {
    NSRect localNSRect = new NSRect();
    OS.objc_msgSend_stret(localNSRect, this.id, OS.sel_bounds);
    return localNSRect;
  }
  
  public void closePath()
  {
    OS.objc_msgSend(this.id, OS.sel_closePath);
  }
  
  public boolean containsPoint(NSPoint paramNSPoint)
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_containsPoint_, paramNSPoint);
  }
  
  public NSRect controlPointBounds()
  {
    NSRect localNSRect = new NSRect();
    OS.objc_msgSend_stret(localNSRect, this.id, OS.sel_controlPointBounds);
    return localNSRect;
  }
  
  public NSPoint currentPoint()
  {
    NSPoint localNSPoint = new NSPoint();
    OS.objc_msgSend_stret(localNSPoint, this.id, OS.sel_currentPoint);
    return localNSPoint;
  }
  
  public void curveToPoint(NSPoint paramNSPoint1, NSPoint paramNSPoint2, NSPoint paramNSPoint3)
  {
    OS.objc_msgSend(this.id, OS.sel_curveToPoint_controlPoint1_controlPoint2_, paramNSPoint1, paramNSPoint2, paramNSPoint3);
  }
  
  public static double defaultFlatness()
  {
    return OS.objc_msgSend_fpret(OS.class_NSBezierPath, OS.sel_defaultFlatness);
  }
  
  public long elementAtIndex(long paramLong1, long paramLong2)
  {
    return OS.objc_msgSend(this.id, OS.sel_elementAtIndex_associatedPoints_, paramLong1, paramLong2);
  }
  
  public long elementCount()
  {
    return OS.objc_msgSend(this.id, OS.sel_elementCount);
  }
  
  public void fill()
  {
    OS.objc_msgSend(this.id, OS.sel_fill);
  }
  
  public static void fillRect(NSRect paramNSRect)
  {
    OS.objc_msgSend(OS.class_NSBezierPath, OS.sel_fillRect_, paramNSRect);
  }
  
  public boolean isEmpty()
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_isEmpty);
  }
  
  public void lineToPoint(NSPoint paramNSPoint)
  {
    OS.objc_msgSend(this.id, OS.sel_lineToPoint_, paramNSPoint);
  }
  
  public void moveToPoint(NSPoint paramNSPoint)
  {
    OS.objc_msgSend(this.id, OS.sel_moveToPoint_, paramNSPoint);
  }
  
  public void removeAllPoints()
  {
    OS.objc_msgSend(this.id, OS.sel_removeAllPoints);
  }
  
  public void setClip()
  {
    OS.objc_msgSend(this.id, OS.sel_setClip);
  }
  
  public static void setDefaultFlatness(double paramDouble)
  {
    OS.objc_msgSend(OS.class_NSBezierPath, OS.sel_setDefaultFlatness_, paramDouble);
  }
  
  public void setLineCapStyle(long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_setLineCapStyle_, paramLong);
  }
  
  public void setLineDash(double[] paramArrayOfDouble, long paramLong, double paramDouble)
  {
    OS.objc_msgSend(this.id, OS.sel_setLineDash_count_phase_, paramArrayOfDouble, paramLong, paramDouble);
  }
  
  public void setLineJoinStyle(long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_setLineJoinStyle_, paramLong);
  }
  
  public void setLineWidth(double paramDouble)
  {
    OS.objc_msgSend(this.id, OS.sel_setLineWidth_, paramDouble);
  }
  
  public void setMiterLimit(double paramDouble)
  {
    OS.objc_msgSend(this.id, OS.sel_setMiterLimit_, paramDouble);
  }
  
  public void setWindingRule(long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_setWindingRule_, paramLong);
  }
  
  public void stroke()
  {
    OS.objc_msgSend(this.id, OS.sel_stroke);
  }
  
  public static void strokeRect(NSRect paramNSRect)
  {
    OS.objc_msgSend(OS.class_NSBezierPath, OS.sel_strokeRect_, paramNSRect);
  }
  
  public void transformUsingAffineTransform(NSAffineTransform paramNSAffineTransform)
  {
    OS.objc_msgSend(this.id, OS.sel_transformUsingAffineTransform_, paramNSAffineTransform != null ? paramNSAffineTransform.id : 0L);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSBezierPath.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */