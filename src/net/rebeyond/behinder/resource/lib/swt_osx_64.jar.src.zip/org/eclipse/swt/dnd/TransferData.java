package org.eclipse.swt.dnd;

import org.eclipse.swt.internal.cocoa.NSObject;

public class TransferData
{
  public int type;
  public NSObject data;
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/dnd/TransferData.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */