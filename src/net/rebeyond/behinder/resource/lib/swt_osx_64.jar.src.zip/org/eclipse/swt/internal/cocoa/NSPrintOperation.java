package org.eclipse.swt.internal.cocoa;

public class NSPrintOperation
  extends NSObject
{
  public NSPrintOperation() {}
  
  public NSPrintOperation(long paramLong)
  {
    super(paramLong);
  }
  
  public NSPrintOperation(id paramid)
  {
    super(paramid);
  }
  
  public void cleanUpOperation()
  {
    OS.objc_msgSend(this.id, OS.sel_cleanUpOperation);
  }
  
  public NSGraphicsContext context()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_context);
    return l != 0L ? new NSGraphicsContext(l) : null;
  }
  
  public NSGraphicsContext createContext()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_createContext);
    return l != 0L ? new NSGraphicsContext(l) : null;
  }
  
  public boolean deliverResult()
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_deliverResult);
  }
  
  public void destroyContext()
  {
    OS.objc_msgSend(this.id, OS.sel_destroyContext);
  }
  
  public static NSPrintOperation printOperationWithView(NSView paramNSView, NSPrintInfo paramNSPrintInfo)
  {
    long l = OS.objc_msgSend(OS.class_NSPrintOperation, OS.sel_printOperationWithView_printInfo_, paramNSView != null ? paramNSView.id : 0L, paramNSPrintInfo != null ? paramNSPrintInfo.id : 0L);
    return l != 0L ? new NSPrintOperation(l) : null;
  }
  
  public boolean runOperation()
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_runOperation);
  }
  
  public static void setCurrentOperation(NSPrintOperation paramNSPrintOperation)
  {
    OS.objc_msgSend(OS.class_NSPrintOperation, OS.sel_setCurrentOperation_, paramNSPrintOperation != null ? paramNSPrintOperation.id : 0L);
  }
  
  public void setJobTitle(NSString paramNSString)
  {
    OS.objc_msgSend(this.id, OS.sel_setJobTitle_, paramNSString != null ? paramNSString.id : 0L);
  }
  
  public void setShowsPrintPanel(boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_setShowsPrintPanel_, paramBoolean);
  }
  
  public void setShowsProgressPanel(boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_setShowsProgressPanel_, paramBoolean);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSPrintOperation.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */