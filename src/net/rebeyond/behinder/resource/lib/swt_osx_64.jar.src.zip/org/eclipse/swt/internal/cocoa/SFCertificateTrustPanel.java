package org.eclipse.swt.internal.cocoa;

public class SFCertificateTrustPanel
  extends SFCertificatePanel
{
  public SFCertificateTrustPanel() {}
  
  public SFCertificateTrustPanel(long paramLong)
  {
    super(paramLong);
  }
  
  public SFCertificateTrustPanel(id paramid)
  {
    super(paramid);
  }
  
  public void beginSheetForWindow(NSWindow paramNSWindow, id paramid, long paramLong1, long paramLong2, long paramLong3, NSString paramNSString)
  {
    OS.objc_msgSend(this.id, OS.sel_beginSheetForWindow_modalDelegate_didEndSelector_contextInfo_trust_message_, paramNSWindow != null ? paramNSWindow.id : 0L, paramid != null ? paramid.id : 0L, paramLong1, paramLong2, paramLong3, paramNSString != null ? paramNSString.id : 0L);
  }
  
  public static SFCertificateTrustPanel sharedCertificateTrustPanel()
  {
    long l = OS.objc_msgSend(OS.class_SFCertificateTrustPanel, OS.sel_sharedCertificateTrustPanel);
    return l != 0L ? new SFCertificateTrustPanel(l) : null;
  }
  
  public static double minFrameWidthWithTitle(NSString paramNSString, long paramLong)
  {
    return OS.objc_msgSend_fpret(OS.class_SFCertificateTrustPanel, OS.sel_minFrameWidthWithTitle_styleMask_, paramNSString != null ? paramNSString.id : 0L, paramLong);
  }
  
  public static long windowNumberAtPoint(NSPoint paramNSPoint, long paramLong)
  {
    return OS.objc_msgSend(OS.class_SFCertificateTrustPanel, OS.sel_windowNumberAtPoint_belowWindowWithWindowNumber_, paramNSPoint, paramLong);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/SFCertificateTrustPanel.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */