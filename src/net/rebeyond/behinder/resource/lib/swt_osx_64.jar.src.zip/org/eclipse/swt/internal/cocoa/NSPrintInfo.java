package org.eclipse.swt.internal.cocoa;

public class NSPrintInfo
  extends NSObject
{
  public NSPrintInfo() {}
  
  public NSPrintInfo(long paramLong)
  {
    super(paramLong);
  }
  
  public NSPrintInfo(id paramid)
  {
    super(paramid);
  }
  
  public long PMPrintSession()
  {
    return OS.objc_msgSend(this.id, OS.sel_PMPrintSession);
  }
  
  public long PMPrintSettings()
  {
    return OS.objc_msgSend(this.id, OS.sel_PMPrintSettings);
  }
  
  public static NSPrinter defaultPrinter()
  {
    long l = OS.objc_msgSend(OS.class_NSPrintInfo, OS.sel_defaultPrinter);
    return l != 0L ? new NSPrinter(l) : null;
  }
  
  public NSMutableDictionary dictionary()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_dictionary);
    return l != 0L ? new NSMutableDictionary(l) : null;
  }
  
  public NSRect imageablePageBounds()
  {
    NSRect localNSRect = new NSRect();
    OS.objc_msgSend_stret(localNSRect, this.id, OS.sel_imageablePageBounds);
    return localNSRect;
  }
  
  public NSPrintInfo initWithDictionary(NSDictionary paramNSDictionary)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_initWithDictionary_, paramNSDictionary != null ? paramNSDictionary.id : 0L);
    return l != 0L ? new NSPrintInfo(l) : l == this.id ? this : null;
  }
  
  public NSString jobDisposition()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_jobDisposition);
    return l != 0L ? new NSString(l) : null;
  }
  
  public NSSize paperSize()
  {
    NSSize localNSSize = new NSSize();
    OS.objc_msgSend_stret(localNSSize, this.id, OS.sel_paperSize);
    return localNSSize;
  }
  
  public NSMutableDictionary printSettings()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_printSettings);
    return l != 0L ? new NSMutableDictionary(l) : null;
  }
  
  public NSPrinter printer()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_printer);
    return l != 0L ? new NSPrinter(l) : null;
  }
  
  public void setJobDisposition(NSString paramNSString)
  {
    OS.objc_msgSend(this.id, OS.sel_setJobDisposition_, paramNSString != null ? paramNSString.id : 0L);
  }
  
  public void setPrinter(NSPrinter paramNSPrinter)
  {
    OS.objc_msgSend(this.id, OS.sel_setPrinter_, paramNSPrinter != null ? paramNSPrinter.id : 0L);
  }
  
  public void setUpPrintOperationDefaultValues()
  {
    OS.objc_msgSend(this.id, OS.sel_setUpPrintOperationDefaultValues);
  }
  
  public static NSPrintInfo sharedPrintInfo()
  {
    long l = OS.objc_msgSend(OS.class_NSPrintInfo, OS.sel_sharedPrintInfo);
    return l != 0L ? new NSPrintInfo(l) : null;
  }
  
  public void updateFromPMPrintSettings()
  {
    OS.objc_msgSend(this.id, OS.sel_updateFromPMPrintSettings);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSPrintInfo.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */