package org.eclipse.swt.browser;

import org.eclipse.swt.internal.mozilla.XPCOM;
import org.eclipse.swt.internal.mozilla.XPCOMObject;

class FilePicker_1_8
  extends FilePicker
{
  void createCOMInterfaces()
  {
    this.supports = new XPCOMObject(new int[] { 2, 0, 0 })
    {
      public long method0(long[] paramAnonymousArrayOfLong)
      {
        return FilePicker_1_8.this.QueryInterface(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method1(long[] paramAnonymousArrayOfLong)
      {
        return FilePicker_1_8.this.AddRef();
      }
      
      public long method2(long[] paramAnonymousArrayOfLong)
      {
        return FilePicker_1_8.this.Release();
      }
    };
    this.filePicker = new XPCOMObject(new int[] { 2, 0, 0, 3, 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 })
    {
      public long method0(long[] paramAnonymousArrayOfLong)
      {
        return FilePicker_1_8.this.QueryInterface(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method1(long[] paramAnonymousArrayOfLong)
      {
        return FilePicker_1_8.this.AddRef();
      }
      
      public long method2(long[] paramAnonymousArrayOfLong)
      {
        return FilePicker_1_8.this.Release();
      }
      
      public long method3(long[] paramAnonymousArrayOfLong)
      {
        return FilePicker_1_8.this.Init(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], (short)(int)paramAnonymousArrayOfLong[2]);
      }
      
      public long method4(long[] paramAnonymousArrayOfLong)
      {
        return FilePicker_1_8.this.AppendFilters((int)paramAnonymousArrayOfLong[0]);
      }
      
      public long method5(long[] paramAnonymousArrayOfLong)
      {
        return FilePicker_1_8.this.AppendFilter(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method6(long[] paramAnonymousArrayOfLong)
      {
        return FilePicker_1_8.this.GetDefaultString(paramAnonymousArrayOfLong[0]);
      }
      
      public long method7(long[] paramAnonymousArrayOfLong)
      {
        return FilePicker_1_8.this.SetDefaultString(paramAnonymousArrayOfLong[0]);
      }
      
      public long method8(long[] paramAnonymousArrayOfLong)
      {
        return FilePicker_1_8.this.GetDefaultExtension(paramAnonymousArrayOfLong[0]);
      }
      
      public long method9(long[] paramAnonymousArrayOfLong)
      {
        return FilePicker_1_8.this.SetDefaultExtension(paramAnonymousArrayOfLong[0]);
      }
      
      public long method10(long[] paramAnonymousArrayOfLong)
      {
        return FilePicker_1_8.this.GetFilterIndex(paramAnonymousArrayOfLong[0]);
      }
      
      public long method11(long[] paramAnonymousArrayOfLong)
      {
        return FilePicker_1_8.this.SetFilterIndex((int)paramAnonymousArrayOfLong[0]);
      }
      
      public long method12(long[] paramAnonymousArrayOfLong)
      {
        return FilePicker_1_8.this.GetDisplayDirectory(paramAnonymousArrayOfLong[0]);
      }
      
      public long method13(long[] paramAnonymousArrayOfLong)
      {
        return FilePicker_1_8.this.SetDisplayDirectory(paramAnonymousArrayOfLong[0]);
      }
      
      public long method14(long[] paramAnonymousArrayOfLong)
      {
        return FilePicker_1_8.this.GetFile(paramAnonymousArrayOfLong[0]);
      }
      
      public long method15(long[] paramAnonymousArrayOfLong)
      {
        return FilePicker_1_8.this.GetFileURL(paramAnonymousArrayOfLong[0]);
      }
      
      public long method16(long[] paramAnonymousArrayOfLong)
      {
        return FilePicker_1_8.this.GetFiles(paramAnonymousArrayOfLong[0]);
      }
      
      public long method17(long[] paramAnonymousArrayOfLong)
      {
        return FilePicker_1_8.this.Show(paramAnonymousArrayOfLong[0]);
      }
    };
  }
  
  String parseAString(long paramLong)
  {
    if (paramLong == 0L) {
      return null;
    }
    int i = XPCOM.nsEmbedString_Length(paramLong);
    long l = XPCOM.nsEmbedString_get(paramLong);
    char[] arrayOfChar = new char[i];
    XPCOM.memmove(arrayOfChar, l, i * 2);
    return new String(arrayOfChar);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/browser/FilePicker_1_8.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */