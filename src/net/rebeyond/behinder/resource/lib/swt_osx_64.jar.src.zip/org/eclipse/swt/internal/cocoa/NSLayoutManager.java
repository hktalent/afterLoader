package org.eclipse.swt.internal.cocoa;

public class NSLayoutManager
  extends NSObject
{
  public NSLayoutManager() {}
  
  public NSLayoutManager(long paramLong)
  {
    super(paramLong);
  }
  
  public NSLayoutManager(id paramid)
  {
    super(paramid);
  }
  
  public void addTemporaryAttribute(NSString paramNSString, id paramid, NSRange paramNSRange)
  {
    OS.objc_msgSend(this.id, OS.sel_addTemporaryAttribute_value_forCharacterRange_, paramNSString != null ? paramNSString.id : 0L, paramid != null ? paramid.id : 0L, paramNSRange);
  }
  
  public void addTextContainer(NSTextContainer paramNSTextContainer)
  {
    OS.objc_msgSend(this.id, OS.sel_addTextContainer_, paramNSTextContainer != null ? paramNSTextContainer.id : 0L);
  }
  
  public NSRect boundingRectForGlyphRange(NSRange paramNSRange, NSTextContainer paramNSTextContainer)
  {
    NSRect localNSRect = new NSRect();
    OS.objc_msgSend_stret(localNSRect, this.id, OS.sel_boundingRectForGlyphRange_inTextContainer_, paramNSRange, paramNSTextContainer != null ? paramNSTextContainer.id : 0L);
    return localNSRect;
  }
  
  public long characterIndexForGlyphAtIndex(long paramLong)
  {
    return OS.objc_msgSend(this.id, OS.sel_characterIndexForGlyphAtIndex_, paramLong);
  }
  
  public double defaultBaselineOffsetForFont(NSFont paramNSFont)
  {
    return OS.objc_msgSend_fpret(this.id, OS.sel_defaultBaselineOffsetForFont_, paramNSFont != null ? paramNSFont.id : 0L);
  }
  
  public double defaultLineHeightForFont(NSFont paramNSFont)
  {
    return OS.objc_msgSend_fpret(this.id, OS.sel_defaultLineHeightForFont_, paramNSFont != null ? paramNSFont.id : 0L);
  }
  
  public void drawBackgroundForGlyphRange(NSRange paramNSRange, NSPoint paramNSPoint)
  {
    OS.objc_msgSend(this.id, OS.sel_drawBackgroundForGlyphRange_atPoint_, paramNSRange, paramNSPoint);
  }
  
  public void drawGlyphsForGlyphRange(NSRange paramNSRange, NSPoint paramNSPoint)
  {
    OS.objc_msgSend(this.id, OS.sel_drawGlyphsForGlyphRange_atPoint_, paramNSRange, paramNSPoint);
  }
  
  public long getGlyphs(long paramLong, NSRange paramNSRange)
  {
    return OS.objc_msgSend(this.id, OS.sel_getGlyphs_range_, paramLong, paramNSRange);
  }
  
  public long getGlyphsInRange(NSRange paramNSRange, long paramLong1, long paramLong2, long paramLong3, long paramLong4, byte[] paramArrayOfByte)
  {
    return OS.objc_msgSend(this.id, OS.sel_getGlyphsInRange_glyphs_characterIndexes_glyphInscriptions_elasticBits_bidiLevels_, paramNSRange, paramLong1, paramLong2, paramLong3, paramLong4, paramArrayOfByte);
  }
  
  public long glyphIndexForCharacterAtIndex(long paramLong)
  {
    return OS.objc_msgSend(this.id, OS.sel_glyphIndexForCharacterAtIndex_, paramLong);
  }
  
  public long glyphIndexForPoint(NSPoint paramNSPoint, NSTextContainer paramNSTextContainer, double[] paramArrayOfDouble)
  {
    return OS.objc_msgSend(this.id, OS.sel_glyphIndexForPoint_inTextContainer_fractionOfDistanceThroughGlyph_, paramNSPoint, paramNSTextContainer != null ? paramNSTextContainer.id : 0L, paramArrayOfDouble);
  }
  
  public NSRange glyphRangeForCharacterRange(NSRange paramNSRange, long paramLong)
  {
    NSRange localNSRange = new NSRange();
    OS.objc_msgSend_stret(localNSRange, this.id, OS.sel_glyphRangeForCharacterRange_actualCharacterRange_, paramNSRange, paramLong);
    return localNSRange;
  }
  
  public NSRange glyphRangeForTextContainer(NSTextContainer paramNSTextContainer)
  {
    NSRange localNSRange = new NSRange();
    OS.objc_msgSend_stret(localNSRange, this.id, OS.sel_glyphRangeForTextContainer_, paramNSTextContainer != null ? paramNSTextContainer.id : 0L);
    return localNSRange;
  }
  
  public NSRect lineFragmentUsedRectForGlyphAtIndex(long paramLong1, long paramLong2)
  {
    NSRect localNSRect = new NSRect();
    OS.objc_msgSend_stret(localNSRect, this.id, OS.sel_lineFragmentUsedRectForGlyphAtIndex_effectiveRange_, paramLong1, paramLong2);
    return localNSRect;
  }
  
  public NSRect lineFragmentUsedRectForGlyphAtIndex(long paramLong1, long paramLong2, boolean paramBoolean)
  {
    NSRect localNSRect = new NSRect();
    OS.objc_msgSend_stret(localNSRect, this.id, OS.sel_lineFragmentUsedRectForGlyphAtIndex_effectiveRange_withoutAdditionalLayout_, paramLong1, paramLong2, paramBoolean);
    return localNSRect;
  }
  
  public NSPoint locationForGlyphAtIndex(long paramLong)
  {
    NSPoint localNSPoint = new NSPoint();
    OS.objc_msgSend_stret(localNSPoint, this.id, OS.sel_locationForGlyphAtIndex_, paramLong);
    return localNSPoint;
  }
  
  public long numberOfGlyphs()
  {
    return OS.objc_msgSend(this.id, OS.sel_numberOfGlyphs);
  }
  
  public long rectArrayForCharacterRange(NSRange paramNSRange1, NSRange paramNSRange2, NSTextContainer paramNSTextContainer, long[] paramArrayOfLong)
  {
    return OS.objc_msgSend(this.id, OS.sel_rectArrayForCharacterRange_withinSelectedCharacterRange_inTextContainer_rectCount_, paramNSRange1, paramNSRange2, paramNSTextContainer != null ? paramNSTextContainer.id : 0L, paramArrayOfLong);
  }
  
  public long rectArrayForGlyphRange(NSRange paramNSRange1, NSRange paramNSRange2, NSTextContainer paramNSTextContainer, long[] paramArrayOfLong)
  {
    return OS.objc_msgSend(this.id, OS.sel_rectArrayForGlyphRange_withinSelectedGlyphRange_inTextContainer_rectCount_, paramNSRange1, paramNSRange2, paramNSTextContainer != null ? paramNSTextContainer.id : 0L, paramArrayOfLong);
  }
  
  public void removeTemporaryAttribute(NSString paramNSString, NSRange paramNSRange)
  {
    OS.objc_msgSend(this.id, OS.sel_removeTemporaryAttribute_forCharacterRange_, paramNSString != null ? paramNSString.id : 0L, paramNSRange);
  }
  
  public void setBackgroundLayoutEnabled(boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_setBackgroundLayoutEnabled_, paramBoolean);
  }
  
  public void setLineFragmentRect(NSRect paramNSRect1, NSRange paramNSRange, NSRect paramNSRect2)
  {
    OS.objc_msgSend(this.id, OS.sel_setLineFragmentRect_forGlyphRange_usedRect_, paramNSRect1, paramNSRange, paramNSRect2);
  }
  
  public void setTextStorage(NSTextStorage paramNSTextStorage)
  {
    OS.objc_msgSend(this.id, OS.sel_setTextStorage_, paramNSTextStorage != null ? paramNSTextStorage.id : 0L);
  }
  
  public void setUsesScreenFonts(boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_setUsesScreenFonts_, paramBoolean);
  }
  
  public NSTypesetter typesetter()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_typesetter);
    return l != 0L ? new NSTypesetter(l) : null;
  }
  
  public NSRect usedRectForTextContainer(NSTextContainer paramNSTextContainer)
  {
    NSRect localNSRect = new NSRect();
    OS.objc_msgSend_stret(localNSRect, this.id, OS.sel_usedRectForTextContainer_, paramNSTextContainer != null ? paramNSTextContainer.id : 0L);
    return localNSRect;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSLayoutManager.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */