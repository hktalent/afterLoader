package org.eclipse.swt.internal.cocoa;

public class NSTextStorage
  extends NSMutableAttributedString
{
  public NSTextStorage() {}
  
  public NSTextStorage(long paramLong)
  {
    super(paramLong);
  }
  
  public NSTextStorage(id paramid)
  {
    super(paramid);
  }
  
  public void addLayoutManager(NSLayoutManager paramNSLayoutManager)
  {
    OS.objc_msgSend(this.id, OS.sel_addLayoutManager_, paramNSLayoutManager != null ? paramNSLayoutManager.id : 0L);
  }
  
  public NSArray paragraphs()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_paragraphs);
    return l != 0L ? new NSArray(l) : null;
  }
  
  public static NSAttributedString attributedStringWithAttachment(NSTextAttachment paramNSTextAttachment)
  {
    long l = OS.objc_msgSend(OS.class_NSTextStorage, OS.sel_attributedStringWithAttachment_, paramNSTextAttachment != null ? paramNSTextAttachment.id : 0L);
    return l != 0L ? new NSAttributedString(l) : null;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSTextStorage.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */