package org.eclipse.swt.custom;

import org.eclipse.swt.events.TypedEvent;

public class MovementEvent
  extends TypedEvent
{
  public int lineOffset;
  public String lineText;
  public int offset;
  public int newOffset;
  public int movement;
  static final long serialVersionUID = 3978765487853324342L;
  
  public MovementEvent(StyledTextEvent paramStyledTextEvent)
  {
    super(paramStyledTextEvent);
    this.lineOffset = paramStyledTextEvent.detail;
    this.lineText = paramStyledTextEvent.text;
    this.movement = paramStyledTextEvent.count;
    this.offset = paramStyledTextEvent.start;
    this.newOffset = paramStyledTextEvent.end;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/custom/MovementEvent.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */