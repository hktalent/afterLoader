package org.eclipse.swt.internal.cocoa;

public class NSColorSpace
  extends NSObject
{
  public NSColorSpace() {}
  
  public NSColorSpace(long paramLong)
  {
    super(paramLong);
  }
  
  public NSColorSpace(id paramid)
  {
    super(paramid);
  }
  
  public long colorSpaceModel()
  {
    return OS.objc_msgSend(this.id, OS.sel_colorSpaceModel);
  }
  
  public static NSColorSpace genericRGBColorSpace()
  {
    long l = OS.objc_msgSend(OS.class_NSColorSpace, OS.sel_genericRGBColorSpace);
    return l != 0L ? new NSColorSpace(l) : null;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSColorSpace.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */