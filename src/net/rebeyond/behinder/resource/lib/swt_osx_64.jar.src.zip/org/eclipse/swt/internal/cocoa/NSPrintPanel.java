package org.eclipse.swt.internal.cocoa;

public class NSPrintPanel
  extends NSObject
{
  public NSPrintPanel() {}
  
  public NSPrintPanel(long paramLong)
  {
    super(paramLong);
  }
  
  public NSPrintPanel(id paramid)
  {
    super(paramid);
  }
  
  public void beginSheetWithPrintInfo(NSPrintInfo paramNSPrintInfo, NSWindow paramNSWindow, id paramid, long paramLong1, long paramLong2)
  {
    OS.objc_msgSend(this.id, OS.sel_beginSheetWithPrintInfo_modalForWindow_delegate_didEndSelector_contextInfo_, paramNSPrintInfo != null ? paramNSPrintInfo.id : 0L, paramNSWindow != null ? paramNSWindow.id : 0L, paramid != null ? paramid.id : 0L, paramLong1, paramLong2);
  }
  
  public long options()
  {
    return OS.objc_msgSend(this.id, OS.sel_options);
  }
  
  public static NSPrintPanel printPanel()
  {
    long l = OS.objc_msgSend(OS.class_NSPrintPanel, OS.sel_printPanel);
    return l != 0L ? new NSPrintPanel(l) : null;
  }
  
  public long runModalWithPrintInfo(NSPrintInfo paramNSPrintInfo)
  {
    return OS.objc_msgSend(this.id, OS.sel_runModalWithPrintInfo_, paramNSPrintInfo != null ? paramNSPrintInfo.id : 0L);
  }
  
  public void setOptions(long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_setOptions_, paramLong);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSPrintPanel.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */