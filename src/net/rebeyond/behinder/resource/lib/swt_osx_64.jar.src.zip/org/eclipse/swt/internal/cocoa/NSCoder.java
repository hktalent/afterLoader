package org.eclipse.swt.internal.cocoa;

public class NSCoder
  extends NSObject
{
  public NSCoder() {}
  
  public NSCoder(long paramLong)
  {
    super(paramLong);
  }
  
  public NSCoder(id paramid)
  {
    super(paramid);
  }
  
  public int systemVersion()
  {
    return (int)OS.objc_msgSend(this.id, OS.sel_systemVersion);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSCoder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */