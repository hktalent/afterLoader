package org.eclipse.swt.internal.cocoa;

public class WebUndefined
  extends NSObject
{
  public WebUndefined() {}
  
  public WebUndefined(long paramLong)
  {
    super(paramLong);
  }
  
  public WebUndefined(id paramid)
  {
    super(paramid);
  }
  
  public static WebUndefined undefined()
  {
    long l = OS.objc_msgSend(OS.class_WebUndefined, OS.sel_undefined);
    return l != 0L ? new WebUndefined(l) : null;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/WebUndefined.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */