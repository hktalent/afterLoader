package org.eclipse.swt.internal.cocoa;

public class NSNotificationCenter
  extends NSObject
{
  public NSNotificationCenter() {}
  
  public NSNotificationCenter(long paramLong)
  {
    super(paramLong);
  }
  
  public NSNotificationCenter(id paramid)
  {
    super(paramid);
  }
  
  public void addObserver(id paramid1, long paramLong, NSString paramNSString, id paramid2)
  {
    OS.objc_msgSend(this.id, OS.sel_addObserver_selector_name_object_, paramid1 != null ? paramid1.id : 0L, paramLong, paramNSString != null ? paramNSString.id : 0L, paramid2 != null ? paramid2.id : 0L);
  }
  
  public static NSNotificationCenter defaultCenter()
  {
    long l = OS.objc_msgSend(OS.class_NSNotificationCenter, OS.sel_defaultCenter);
    return l != 0L ? new NSNotificationCenter(l) : null;
  }
  
  public void removeObserver(id paramid)
  {
    OS.objc_msgSend(this.id, OS.sel_removeObserver_, paramid != null ? paramid.id : 0L);
  }
  
  public void removeObserver(id paramid1, NSString paramNSString, id paramid2)
  {
    OS.objc_msgSend(this.id, OS.sel_removeObserver_name_object_, paramid1 != null ? paramid1.id : 0L, paramNSString != null ? paramNSString.id : 0L, paramid2 != null ? paramid2.id : 0L);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSNotificationCenter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */