package org.eclipse.swt.internal.cocoa;

public class NSControl
  extends NSView
{
  public NSControl() {}
  
  public NSControl(long paramLong)
  {
    super(paramLong);
  }
  
  public NSControl(id paramid)
  {
    super(paramid);
  }
  
  public boolean abortEditing()
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_abortEditing);
  }
  
  public long action()
  {
    return OS.objc_msgSend(this.id, OS.sel_action);
  }
  
  public NSCell cell()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_cell);
    return l != 0L ? new NSCell(l) : null;
  }
  
  public static long cellClass()
  {
    return OS.objc_msgSend(OS.class_NSControl, OS.sel_cellClass);
  }
  
  public NSText currentEditor()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_currentEditor);
    return l != 0L ? new NSText(l) : null;
  }
  
  public double doubleValue()
  {
    return OS.objc_msgSend_fpret(this.id, OS.sel_doubleValue);
  }
  
  public NSFont font()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_font);
    return l != 0L ? new NSFont(l) : null;
  }
  
  public boolean isEnabled()
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_isEnabled);
  }
  
  public boolean sendAction(long paramLong, id paramid)
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_sendAction_to_, paramLong, paramid != null ? paramid.id : 0L);
  }
  
  public void setAction(long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_setAction_, paramLong);
  }
  
  public void setAlignment(long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_setAlignment_, paramLong);
  }
  
  public void setBaseWritingDirection(long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_setBaseWritingDirection_, paramLong);
  }
  
  public void setCell(NSCell paramNSCell)
  {
    OS.objc_msgSend(this.id, OS.sel_setCell_, paramNSCell != null ? paramNSCell.id : 0L);
  }
  
  public static void setCellClass(long paramLong)
  {
    OS.objc_msgSend(OS.class_NSControl, OS.sel_setCellClass_, paramLong);
  }
  
  public void setDoubleValue(double paramDouble)
  {
    OS.objc_msgSend(this.id, OS.sel_setDoubleValue_, paramDouble);
  }
  
  public void setEnabled(boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_setEnabled_, paramBoolean);
  }
  
  public void setFont(NSFont paramNSFont)
  {
    OS.objc_msgSend(this.id, OS.sel_setFont_, paramNSFont != null ? paramNSFont.id : 0L);
  }
  
  public void setFormatter(NSFormatter paramNSFormatter)
  {
    OS.objc_msgSend(this.id, OS.sel_setFormatter_, paramNSFormatter != null ? paramNSFormatter.id : 0L);
  }
  
  public void setStringValue(NSString paramNSString)
  {
    OS.objc_msgSend(this.id, OS.sel_setStringValue_, paramNSString != null ? paramNSString.id : 0L);
  }
  
  public void setTarget(id paramid)
  {
    OS.objc_msgSend(this.id, OS.sel_setTarget_, paramid != null ? paramid.id : 0L);
  }
  
  public void sizeToFit()
  {
    OS.objc_msgSend(this.id, OS.sel_sizeToFit);
  }
  
  public NSString stringValue()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_stringValue);
    return l != 0L ? new NSString(l) : null;
  }
  
  public id target()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_target);
    return l != 0L ? new id(l) : null;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSControl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */