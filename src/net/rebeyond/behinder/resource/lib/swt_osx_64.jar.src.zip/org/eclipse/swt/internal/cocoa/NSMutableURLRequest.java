package org.eclipse.swt.internal.cocoa;

public class NSMutableURLRequest
  extends NSURLRequest
{
  public NSMutableURLRequest() {}
  
  public NSMutableURLRequest(long paramLong)
  {
    super(paramLong);
  }
  
  public NSMutableURLRequest(id paramid)
  {
    super(paramid);
  }
  
  public void setCachePolicy(long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_setCachePolicy_, paramLong);
  }
  
  public void setHTTPBody(NSData paramNSData)
  {
    OS.objc_msgSend(this.id, OS.sel_setHTTPBody_, paramNSData != null ? paramNSData.id : 0L);
  }
  
  public void setHTTPMethod(NSString paramNSString)
  {
    OS.objc_msgSend(this.id, OS.sel_setHTTPMethod_, paramNSString != null ? paramNSString.id : 0L);
  }
  
  public void setURL(NSURL paramNSURL)
  {
    OS.objc_msgSend(this.id, OS.sel_setURL_, paramNSURL != null ? paramNSURL.id : 0L);
  }
  
  public void setValue(NSString paramNSString1, NSString paramNSString2)
  {
    OS.objc_msgSend(this.id, OS.sel_setValue_forHTTPHeaderField_, paramNSString1 != null ? paramNSString1.id : 0L, paramNSString2 != null ? paramNSString2.id : 0L);
  }
  
  public static NSURLRequest requestWithURL(NSURL paramNSURL)
  {
    long l = OS.objc_msgSend(OS.class_NSMutableURLRequest, OS.sel_requestWithURL_, paramNSURL != null ? paramNSURL.id : 0L);
    return l != 0L ? new NSMutableURLRequest(l) : null;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSMutableURLRequest.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */