package org.eclipse.swt.browser;

import java.io.UnsupportedEncodingException;
import java.util.Enumeration;
import java.util.Hashtable;
import org.eclipse.swt.SWT;
import org.eclipse.swt.SWTException;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.internal.C;
import org.eclipse.swt.internal.Callback;
import org.eclipse.swt.internal.Compatibility;
import org.eclipse.swt.internal.cocoa.DOMDocument;
import org.eclipse.swt.internal.cocoa.DOMKeyboardEvent;
import org.eclipse.swt.internal.cocoa.DOMMouseEvent;
import org.eclipse.swt.internal.cocoa.DOMWheelEvent;
import org.eclipse.swt.internal.cocoa.NSArray;
import org.eclipse.swt.internal.cocoa.NSData;
import org.eclipse.swt.internal.cocoa.NSDictionary;
import org.eclipse.swt.internal.cocoa.NSError;
import org.eclipse.swt.internal.cocoa.NSHTTPCookie;
import org.eclipse.swt.internal.cocoa.NSHTTPCookieStorage;
import org.eclipse.swt.internal.cocoa.NSMutableArray;
import org.eclipse.swt.internal.cocoa.NSMutableDictionary;
import org.eclipse.swt.internal.cocoa.NSMutableURLRequest;
import org.eclipse.swt.internal.cocoa.NSNumber;
import org.eclipse.swt.internal.cocoa.NSObject;
import org.eclipse.swt.internal.cocoa.NSPrintInfo;
import org.eclipse.swt.internal.cocoa.NSPrintOperation;
import org.eclipse.swt.internal.cocoa.NSRect;
import org.eclipse.swt.internal.cocoa.NSString;
import org.eclipse.swt.internal.cocoa.NSURL;
import org.eclipse.swt.internal.cocoa.NSURLAuthenticationChallenge;
import org.eclipse.swt.internal.cocoa.NSURLCredential;
import org.eclipse.swt.internal.cocoa.NSURLDownload;
import org.eclipse.swt.internal.cocoa.NSURLProtectionSpace;
import org.eclipse.swt.internal.cocoa.NSURLRequest;
import org.eclipse.swt.internal.cocoa.NSView;
import org.eclipse.swt.internal.cocoa.NSWindow;
import org.eclipse.swt.internal.cocoa.OS;
import org.eclipse.swt.internal.cocoa.SFCertificateTrustPanel;
import org.eclipse.swt.internal.cocoa.SWTWebViewDelegate;
import org.eclipse.swt.internal.cocoa.WebDataSource;
import org.eclipse.swt.internal.cocoa.WebDocumentRepresentation;
import org.eclipse.swt.internal.cocoa.WebFrame;
import org.eclipse.swt.internal.cocoa.WebFrameView;
import org.eclipse.swt.internal.cocoa.WebOpenPanelResultListener;
import org.eclipse.swt.internal.cocoa.WebPolicyDecisionListener;
import org.eclipse.swt.internal.cocoa.WebPreferences;
import org.eclipse.swt.internal.cocoa.WebScriptObject;
import org.eclipse.swt.internal.cocoa.WebView;
import org.eclipse.swt.internal.cocoa.id;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.Monitor;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Widget;

class WebKit
  extends WebBrowser
{
  WebView webView;
  WebPreferences preferences;
  SWTWebViewDelegate delegate;
  boolean loadingText;
  boolean untrustedText;
  String lastHoveredLinkURL;
  String lastNavigateURL;
  String html;
  long identifier;
  int resourceCount;
  String url = "";
  Point location;
  Point size;
  boolean statusBar = true;
  boolean toolBar = true;
  boolean ignoreDispose;
  int lastMouseMoveX;
  int lastMouseMoveY;
  static long delegateClass;
  static boolean Initialized;
  static Callback Callback3;
  static Callback Callback4;
  static Callback Callback5;
  static Callback Callback6;
  static Callback Callback7;
  static final int MIN_SIZE = 16;
  static final int MAX_PROGRESS = 100;
  static final String WebElementLinkURLKey = "WebElementLinkURL";
  static final String AGENT_STRING = "Safari/522.0";
  static final String URI_FILEROOT = "file:///";
  static final String PROTOCOL_FILE = "file://";
  static final String PROTOCOL_HTTP = "http://";
  static final String ABOUT_BLANK = "about:blank";
  static final String HEADER_SETCOOKIE = "Set-Cookie";
  static final String POST = "POST";
  static final String USER_AGENT = "user-agent";
  static final String ADD_WIDGET_KEY = "org.eclipse.swt.internal.addWidget";
  static final String WEBKIT_EVENTS_FIX_KEY = "org.eclipse.swt.internal.webKitEventsFix";
  static final byte[] SWT_OBJECT = { 83, 87, 84, 95, 79, 66, 74, 69, 67, 84, 0 };
  static final String DOMEVENT_KEYUP = "keyup";
  static final String DOMEVENT_KEYDOWN = "keydown";
  static final String DOMEVENT_MOUSEDOWN = "mousedown";
  static final String DOMEVENT_MOUSEUP = "mouseup";
  static final String DOMEVENT_MOUSEMOVE = "mousemove";
  static final String DOMEVENT_MOUSEWHEEL = "mousewheel";
  
  public void create(Composite paramComposite, int paramInt)
  {
    if (delegateClass == 0L)
    {
      localObject = getClass();
      Callback3 = new Callback(localObject, "browserProc", 3);
      long l1 = Callback3.getAddress();
      if (l1 == 0L) {
        SWT.error(3);
      }
      Callback4 = new Callback(localObject, "browserProc", 4);
      long l2 = Callback4.getAddress();
      if (l2 == 0L) {
        SWT.error(3);
      }
      Callback5 = new Callback(localObject, "browserProc", 5);
      long l3 = Callback5.getAddress();
      if (l3 == 0L) {
        SWT.error(3);
      }
      Callback6 = new Callback(localObject, "browserProc", 6);
      long l4 = Callback6.getAddress();
      if (l4 == 0L) {
        SWT.error(3);
      }
      Callback7 = new Callback(localObject, "browserProc", 7);
      long l5 = Callback7.getAddress();
      if (l5 == 0L) {
        SWT.error(3);
      }
      long l6 = OS.CALLBACK_webView_setFrame_(l2);
      if (l6 == 0L) {
        SWT.error(3);
      }
      String str = "SWTWebViewDelegate";
      byte[] arrayOfByte = { 42, 0 };
      int i = C.PTR_SIZEOF;
      int j = C.PTR_SIZEOF == 4 ? 2 : 3;
      delegateClass = OS.objc_allocateClassPair(OS.class_NSObject, str, 0L);
      OS.class_addIvar(delegateClass, SWT_OBJECT, i, (byte)j, arrayOfByte);
      OS.class_addMethod(delegateClass, OS.sel_webView_didChangeLocationWithinPageForFrame_, l2, "@:@@");
      OS.class_addMethod(delegateClass, OS.sel_webView_didFailProvisionalLoadWithError_forFrame_, l3, "@:@@@");
      OS.class_addMethod(delegateClass, OS.sel_webView_didFinishLoadForFrame_, l2, "@:@@");
      OS.class_addMethod(delegateClass, OS.sel_webView_didReceiveTitle_forFrame_, l3, "@:@@@");
      OS.class_addMethod(delegateClass, OS.sel_webView_didStartProvisionalLoadForFrame_, l2, "@:@@");
      OS.class_addMethod(delegateClass, OS.sel_webView_didCommitLoadForFrame_, l2, "@:@@");
      OS.class_addMethod(delegateClass, OS.sel_webView_resource_didFinishLoadingFromDataSource_, l3, "@:@@@");
      OS.class_addMethod(delegateClass, OS.sel_webView_resource_didReceiveAuthenticationChallenge_fromDataSource_, l4, "@:@@@@");
      OS.class_addMethod(delegateClass, OS.sel_webView_resource_didFailLoadingWithError_fromDataSource_, l4, "@:@@@@");
      OS.class_addMethod(delegateClass, OS.sel_webView_identifierForInitialRequest_fromDataSource_, l3, "@:@@@");
      OS.class_addMethod(delegateClass, OS.sel_webView_resource_willSendRequest_redirectResponse_fromDataSource_, l5, "@:@@@@@");
      OS.class_addMethod(delegateClass, OS.sel_webView_createWebViewWithRequest_, l2, "@:@@");
      OS.class_addMethod(delegateClass, OS.sel_webViewShow_, l1, "@:@");
      OS.class_addMethod(delegateClass, OS.sel_webViewClose_, l1, "@:@");
      OS.class_addMethod(delegateClass, OS.sel_webView_contextMenuItemsForElement_defaultMenuItems_, l3, "@:@@@");
      OS.class_addMethod(delegateClass, OS.sel_webView_setStatusBarVisible_, l2, "@:@B");
      OS.class_addMethod(delegateClass, OS.sel_webView_setResizable_, l2, "@:@B");
      OS.class_addMethod(delegateClass, OS.sel_webView_setToolbarsVisible_, l2, "@:@B");
      OS.class_addMethod(delegateClass, OS.sel_webView_setStatusText_, l2, "@:@@");
      OS.class_addMethod(delegateClass, OS.sel_webViewFocus_, l1, "@:@");
      OS.class_addMethod(delegateClass, OS.sel_webViewUnfocus_, l1, "@:@");
      OS.class_addMethod(delegateClass, OS.sel_webView_runBeforeUnloadConfirmPanelWithMessage_initiatedByFrame_, l3, "@:@@@");
      OS.class_addMethod(delegateClass, OS.sel_webView_runJavaScriptAlertPanelWithMessage_, l2, "@:@@");
      OS.class_addMethod(delegateClass, OS.sel_webView_runJavaScriptAlertPanelWithMessage_initiatedByFrame_, l3, "@:@@@");
      OS.class_addMethod(delegateClass, OS.sel_webView_runJavaScriptConfirmPanelWithMessage_, l2, "@:@@");
      OS.class_addMethod(delegateClass, OS.sel_webView_runJavaScriptConfirmPanelWithMessage_initiatedByFrame_, l3, "@:@@@");
      OS.class_addMethod(delegateClass, OS.sel_webView_runOpenPanelForFileButtonWithResultListener_, l2, "@:@@");
      OS.class_addMethod(delegateClass, OS.sel_webView_mouseDidMoveOverElement_modifierFlags_, l3, "@:@@I");
      OS.class_addMethod(delegateClass, OS.sel_webView_printFrameView_, l2, "@:@@");
      OS.class_addMethod(delegateClass, OS.sel_webView_decidePolicyForMIMEType_request_frame_decisionListener_, l5, "@:@@@@@");
      OS.class_addMethod(delegateClass, OS.sel_webView_decidePolicyForNavigationAction_request_frame_decisionListener_, l5, "@:@@@@@");
      OS.class_addMethod(delegateClass, OS.sel_webView_decidePolicyForNewWindowAction_request_newFrameName_decisionListener_, l5, "@:@@@@@");
      OS.class_addMethod(delegateClass, OS.sel_webView_unableToImplementPolicyWithError_frame_, l3, "@:@@@");
      OS.class_addMethod(delegateClass, OS.sel_download_decideDestinationWithSuggestedFilename_, l2, "@:@@");
      OS.class_addMethod(delegateClass, OS.sel_handleEvent_, l1, "@:@");
      OS.class_addMethod(delegateClass, OS.sel_webView_setFrame_, l6, "@:@{NSRect}");
      OS.class_addMethod(delegateClass, OS.sel_webView_windowScriptObjectAvailable_, l2, "@:@@");
      OS.class_addMethod(delegateClass, OS.sel_callJava, l4, "@:@@@@");
      OS.class_addMethod(delegateClass, OS.sel_callRunBeforeUnloadConfirmPanelWithMessage, l2, "@:@@");
      OS.class_addMethod(delegateClass, OS.sel_createPanelDidEnd, l3, "@:@@@");
      OS.objc_registerClassPair(delegateClass);
      long l7 = OS.objc_getMetaClass(str);
      OS.class_addMethod(l7, OS.sel_isSelectorExcludedFromWebScript_, l1, "@:@");
      OS.class_addMethod(l7, OS.sel_webScriptNameForSelector_, l1, "@:@");
    }
    this.browser.setData("org.eclipse.swt.internal.webKitEventsFix");
    Object localObject = (WebView)new WebView().alloc();
    if (localObject == null) {
      SWT.error(2);
    }
    ((WebView)localObject).initWithFrame(this.browser.view.frame(), null, null);
    ((WebView)localObject).setAutoresizingMask(18L);
    if (((WebView)localObject).respondsToSelector(OS.sel__setDashboardBehavior)) {
      OS.objc_msgSend(((WebView)localObject).id, OS.sel__setDashboardBehavior, 2L, 1L);
    }
    final SWTWebViewDelegate localSWTWebViewDelegate = (SWTWebViewDelegate)new SWTWebViewDelegate().alloc().init();
    Display localDisplay = this.browser.getDisplay();
    localDisplay.setData("org.eclipse.swt.internal.addWidget", new Object[] { localSWTWebViewDelegate, this.browser });
    this.delegate = localSWTWebViewDelegate;
    this.webView = ((WebView)localObject);
    this.browser.view.addSubview((NSView)localObject);
    Listener local4 = new Listener()
    {
      public void handleEvent(Event paramAnonymousEvent)
      {
        switch (paramAnonymousEvent.type)
        {
        case 15: 
          WebKit.this.webView.window().makeFirstResponder(WebKit.this.webView);
          break;
        case 12: 
          if (WebKit.this.ignoreDispose)
          {
            WebKit.this.ignoreDispose = false;
          }
          else
          {
            WebKit.this.ignoreDispose = true;
            WebKit.this.browser.notifyListeners(paramAnonymousEvent.type, paramAnonymousEvent);
            paramAnonymousEvent.type = 0;
            if (!WebKit.this.browser.isDisposed())
            {
              if (!WebKit.this.browser.isClosing) {
                WebKit.this.close(false);
              }
              paramAnonymousEvent.display.setData("org.eclipse.swt.internal.addWidget", new Object[] { localSWTWebViewDelegate, null });
            }
            WebKit.this.webView.setFrameLoadDelegate(null);
            WebKit.this.webView.setResourceLoadDelegate(null);
            WebKit.this.webView.setUIDelegate(null);
            WebKit.this.webView.setPolicyDelegate(null);
            WebKit.this.webView.setDownloadDelegate(null);
            WebKit.this.webView.release();
            WebKit.this.webView = null;
            WebKit.this.delegate.release();
            WebKit.this.delegate = null;
            WebKit.this.html = null;
            WebKit.this.lastHoveredLinkURL = (WebKit.this.lastNavigateURL = null);
            Enumeration localEnumeration = WebKit.this.functions.elements();
            while (localEnumeration.hasMoreElements()) {
              ((BrowserFunction)localEnumeration.nextElement()).dispose(false);
            }
            WebKit.this.functions = null;
            if (WebKit.this.preferences != null) {
              WebKit.this.preferences.release();
            }
            WebKit.this.preferences = null;
          }
          break;
        }
      }
    };
    this.browser.addListener(12, local4);
    this.browser.addListener(1, local4);
    this.browser.addListener(15, local4);
    ((WebView)localObject).setFrameLoadDelegate(localSWTWebViewDelegate);
    ((WebView)localObject).setResourceLoadDelegate(localSWTWebViewDelegate);
    ((WebView)localObject).setUIDelegate(localSWTWebViewDelegate);
    ((WebView)localObject).setPolicyDelegate(localSWTWebViewDelegate);
    ((WebView)localObject).setDownloadDelegate(localSWTWebViewDelegate);
    ((WebView)localObject).setApplicationNameForUserAgent(NSString.stringWith("Safari/522.0"));
    if (!Initialized)
    {
      Initialized = true;
      WebPreferences.standardPreferences().setJavaEnabled(false);
    }
  }
  
  public boolean back()
  {
    this.html = null;
    return this.webView.goBack();
  }
  
  static long browserProc(long paramLong1, long paramLong2, long paramLong3)
  {
    if (paramLong1 == delegateClass)
    {
      if (paramLong2 == OS.sel_isSelectorExcludedFromWebScript_) {
        return isSelectorExcludedFromWebScript(paramLong3) ? 1L : 0L;
      }
      if (paramLong2 == OS.sel_webScriptNameForSelector_) {
        return webScriptNameForSelector(paramLong3);
      }
    }
    Display localDisplay = Display.getCurrent();
    if ((localDisplay == null) || (localDisplay.isDisposed())) {
      return 0L;
    }
    Widget localWidget = localDisplay.findWidget(paramLong1);
    if (localWidget == null) {
      return 0L;
    }
    WebKit localWebKit = (WebKit)((Browser)localWidget).webBrowser;
    if (paramLong2 == OS.sel_webViewShow_) {
      localWebKit.webViewShow(paramLong3);
    } else if (paramLong2 == OS.sel_webViewClose_) {
      localWebKit.webViewClose(paramLong3);
    } else if (paramLong2 == OS.sel_webViewFocus_) {
      localWebKit.webViewFocus(paramLong3);
    } else if (paramLong2 == OS.sel_webViewUnfocus_) {
      localWebKit.webViewUnfocus(paramLong3);
    } else if (paramLong2 == OS.sel_handleEvent_) {
      localWebKit.handleEvent(paramLong3);
    }
    return 0L;
  }
  
  static long browserProc(long paramLong1, long paramLong2, long paramLong3, long paramLong4)
  {
    Display localDisplay = Display.getCurrent();
    if ((localDisplay == null) || (localDisplay.isDisposed())) {
      return 0L;
    }
    Widget localWidget = localDisplay.findWidget(paramLong1);
    if (localWidget == null) {
      return 0L;
    }
    WebKit localWebKit = (WebKit)((Browser)localWidget).webBrowser;
    if (paramLong2 == OS.sel_webView_didChangeLocationWithinPageForFrame_)
    {
      localWebKit.webView_didChangeLocationWithinPageForFrame(paramLong3, paramLong4);
    }
    else if (paramLong2 == OS.sel_webView_didFinishLoadForFrame_)
    {
      localWebKit.webView_didFinishLoadForFrame(paramLong3, paramLong4);
    }
    else if (paramLong2 == OS.sel_webView_didStartProvisionalLoadForFrame_)
    {
      localWebKit.webView_didStartProvisionalLoadForFrame(paramLong3, paramLong4);
    }
    else if (paramLong2 == OS.sel_webView_didCommitLoadForFrame_)
    {
      localWebKit.webView_didCommitLoadForFrame(paramLong3, paramLong4);
    }
    else if (paramLong2 == OS.sel_webView_setFrame_)
    {
      localWebKit.webView_setFrame(paramLong3, paramLong4);
    }
    else
    {
      if (paramLong2 == OS.sel_webView_createWebViewWithRequest_) {
        return localWebKit.webView_createWebViewWithRequest(paramLong3, paramLong4);
      }
      if (paramLong2 == OS.sel_webView_setStatusBarVisible_)
      {
        localWebKit.webView_setStatusBarVisible(paramLong3, paramLong4 != 0L);
      }
      else if (paramLong2 == OS.sel_webView_setResizable_)
      {
        localWebKit.webView_setResizable(paramLong3, paramLong4 != 0L);
      }
      else if (paramLong2 == OS.sel_webView_setStatusText_)
      {
        localWebKit.webView_setStatusText(paramLong3, paramLong4);
      }
      else if (paramLong2 == OS.sel_webView_setToolbarsVisible_)
      {
        localWebKit.webView_setToolbarsVisible(paramLong3, paramLong4 != 0L);
      }
      else if (paramLong2 == OS.sel_webView_runJavaScriptAlertPanelWithMessage_)
      {
        localWebKit.webView_runJavaScriptAlertPanelWithMessage(paramLong3, paramLong4);
      }
      else
      {
        if (paramLong2 == OS.sel_webView_runJavaScriptConfirmPanelWithMessage_) {
          return localWebKit.webView_runJavaScriptConfirmPanelWithMessage(paramLong3, paramLong4);
        }
        if (paramLong2 == OS.sel_webView_runOpenPanelForFileButtonWithResultListener_) {
          localWebKit.webView_runOpenPanelForFileButtonWithResultListener(paramLong3, paramLong4);
        } else if (paramLong2 == OS.sel_download_decideDestinationWithSuggestedFilename_) {
          localWebKit.download_decideDestinationWithSuggestedFilename(paramLong3, paramLong4);
        } else if (paramLong2 == OS.sel_webView_printFrameView_) {
          localWebKit.webView_printFrameView(paramLong3, paramLong4);
        } else if (paramLong2 == OS.sel_webView_windowScriptObjectAvailable_) {
          localWebKit.webView_windowScriptObjectAvailable(paramLong3, paramLong4);
        } else if (paramLong2 == OS.sel_callRunBeforeUnloadConfirmPanelWithMessage) {
          return localWebKit.callRunBeforeUnloadConfirmPanelWithMessage(paramLong3, paramLong4).id;
        }
      }
    }
    return 0L;
  }
  
  static long browserProc(long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5)
  {
    Display localDisplay = Display.getCurrent();
    if ((localDisplay == null) || (localDisplay.isDisposed())) {
      return 0L;
    }
    Widget localWidget = localDisplay.findWidget(paramLong1);
    if (localWidget == null) {
      return 0L;
    }
    WebKit localWebKit = (WebKit)((Browser)localWidget).webBrowser;
    if (paramLong2 == OS.sel_webView_didFailProvisionalLoadWithError_forFrame_)
    {
      localWebKit.webView_didFailProvisionalLoadWithError_forFrame(paramLong3, paramLong4, paramLong5);
    }
    else if (paramLong2 == OS.sel_webView_didReceiveTitle_forFrame_)
    {
      localWebKit.webView_didReceiveTitle_forFrame(paramLong3, paramLong4, paramLong5);
    }
    else if (paramLong2 == OS.sel_webView_resource_didFinishLoadingFromDataSource_)
    {
      localWebKit.webView_resource_didFinishLoadingFromDataSource(paramLong3, paramLong4, paramLong5);
    }
    else
    {
      if (paramLong2 == OS.sel_webView_identifierForInitialRequest_fromDataSource_) {
        return localWebKit.webView_identifierForInitialRequest_fromDataSource(paramLong3, paramLong4, paramLong5);
      }
      if (paramLong2 == OS.sel_webView_contextMenuItemsForElement_defaultMenuItems_) {
        return localWebKit.webView_contextMenuItemsForElement_defaultMenuItems(paramLong3, paramLong4, paramLong5);
      }
      if (paramLong2 == OS.sel_webView_mouseDidMoveOverElement_modifierFlags_)
      {
        localWebKit.webView_mouseDidMoveOverElement_modifierFlags(paramLong3, paramLong4, paramLong5);
      }
      else if (paramLong2 == OS.sel_webView_unableToImplementPolicyWithError_frame_)
      {
        localWebKit.webView_unableToImplementPolicyWithError_frame(paramLong3, paramLong4, paramLong5);
      }
      else
      {
        if (paramLong2 == OS.sel_webView_runBeforeUnloadConfirmPanelWithMessage_initiatedByFrame_) {
          return localWebKit.webView_runBeforeUnloadConfirmPanelWithMessage_initiatedByFrame(paramLong3, paramLong4, paramLong5) ? 1L : 0L;
        }
        if (paramLong2 == OS.sel_webView_runJavaScriptAlertPanelWithMessage_initiatedByFrame_)
        {
          localWebKit.webView_runJavaScriptAlertPanelWithMessage(paramLong3, paramLong4);
        }
        else
        {
          if (paramLong2 == OS.sel_webView_runJavaScriptConfirmPanelWithMessage_initiatedByFrame_) {
            return localWebKit.webView_runJavaScriptConfirmPanelWithMessage(paramLong3, paramLong4);
          }
          if (paramLong2 == OS.sel_createPanelDidEnd) {
            localWebKit.createPanelDidEnd(paramLong3, paramLong4, paramLong5);
          }
        }
      }
    }
    return 0L;
  }
  
  static long browserProc(long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5, long paramLong6)
  {
    Display localDisplay = Display.getCurrent();
    if ((localDisplay == null) || (localDisplay.isDisposed())) {
      return 0L;
    }
    Widget localWidget = localDisplay.findWidget(paramLong1);
    if (localWidget == null) {
      return 0L;
    }
    WebKit localWebKit = (WebKit)((Browser)localWidget).webBrowser;
    if (paramLong2 == OS.sel_webView_resource_didFailLoadingWithError_fromDataSource_)
    {
      localWebKit.webView_resource_didFailLoadingWithError_fromDataSource(paramLong3, paramLong4, paramLong5, paramLong6);
    }
    else if (paramLong2 == OS.sel_webView_resource_didReceiveAuthenticationChallenge_fromDataSource_)
    {
      localWebKit.webView_resource_didReceiveAuthenticationChallenge_fromDataSource(paramLong3, paramLong4, paramLong5, paramLong6);
    }
    else if (paramLong2 == OS.sel_callJava)
    {
      NSObject localNSObject = localWebKit.callJava(paramLong3, paramLong4, paramLong5, paramLong6);
      return localNSObject == null ? 0L : localNSObject.id;
    }
    return 0L;
  }
  
  static long browserProc(long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5, long paramLong6, long paramLong7)
  {
    Display localDisplay = Display.getCurrent();
    if ((localDisplay == null) || (localDisplay.isDisposed())) {
      return 0L;
    }
    Widget localWidget = localDisplay.findWidget(paramLong1);
    if (localWidget == null) {
      return 0L;
    }
    WebKit localWebKit = (WebKit)((Browser)localWidget).webBrowser;
    if (paramLong2 == OS.sel_webView_resource_willSendRequest_redirectResponse_fromDataSource_) {
      return localWebKit.webView_resource_willSendRequest_redirectResponse_fromDataSource(paramLong3, paramLong4, paramLong5, paramLong6, paramLong7);
    }
    if (paramLong2 == OS.sel_webView_decidePolicyForMIMEType_request_frame_decisionListener_) {
      localWebKit.webView_decidePolicyForMIMEType_request_frame_decisionListener(paramLong3, paramLong4, paramLong5, paramLong6, paramLong7);
    } else if (paramLong2 == OS.sel_webView_decidePolicyForNavigationAction_request_frame_decisionListener_) {
      localWebKit.webView_decidePolicyForNavigationAction_request_frame_decisionListener(paramLong3, paramLong4, paramLong5, paramLong6, paramLong7);
    } else if (paramLong2 == OS.sel_webView_decidePolicyForNewWindowAction_request_newFrameName_decisionListener_) {
      localWebKit.webView_decidePolicyForNewWindowAction_request_newFrameName_decisionListener(paramLong3, paramLong4, paramLong5, paramLong6, paramLong7);
    }
    return 0L;
  }
  
  static boolean isSelectorExcludedFromWebScript(long paramLong)
  {
    return (paramLong != OS.sel_callJava) && (paramLong != OS.sel_callRunBeforeUnloadConfirmPanelWithMessage);
  }
  
  static long webScriptNameForSelector(long paramLong)
  {
    if (paramLong == OS.sel_callJava) {
      return NSString.stringWith("callJava").id;
    }
    if (paramLong == OS.sel_callRunBeforeUnloadConfirmPanelWithMessage) {
      return NSString.stringWith("callRunBeforeUnloadConfirmPanelWithMessage").id;
    }
    return 0L;
  }
  
  public boolean close()
  {
    return close(true);
  }
  
  boolean close(boolean paramBoolean)
  {
    if (!this.jsEnabled) {
      return true;
    }
    String str = "SWTExecuteTemporaryFunctionCLOSE";
    StringBuffer localStringBuffer = new StringBuffer("function ");
    localStringBuffer.append(str);
    localStringBuffer.append("(win) {\n");
    localStringBuffer.append("var fn = win.onbeforeunload; if (fn != null) {try {var str = fn(); ");
    if (paramBoolean)
    {
      localStringBuffer.append("if (str != null) { ");
      localStringBuffer.append("var result = window.external.callRunBeforeUnloadConfirmPanelWithMessage(str);");
      localStringBuffer.append("if (!result) return false;}");
    }
    localStringBuffer.append("} catch (e) {}}");
    localStringBuffer.append("try {for (var i = 0; i < win.frames.length; i++) {var result = ");
    localStringBuffer.append(str);
    localStringBuffer.append("(win.frames[i]); if (!result) return false;}} catch (e) {} return true;");
    localStringBuffer.append("\n};");
    execute(localStringBuffer.toString());
    Boolean localBoolean = (Boolean)evaluate("return " + str + "(window);");
    if (localBoolean == null) {
      return false;
    }
    return localBoolean.booleanValue();
  }
  
  public boolean execute(String paramString)
  {
    WebFrame localWebFrame = this.webView.mainFrame();
    long l1 = localWebFrame.globalContext();
    byte[] arrayOfByte = null;
    try
    {
      arrayOfByte = (paramString + '\000').getBytes("UTF-8");
    }
    catch (UnsupportedEncodingException localUnsupportedEncodingException1)
    {
      arrayOfByte = (paramString + '\000').getBytes();
    }
    long l2 = OS.JSStringCreateWithUTF8CString(arrayOfByte);
    try
    {
      arrayOfByte = (getUrl() + '\000').getBytes("UTF-8");
    }
    catch (UnsupportedEncodingException localUnsupportedEncodingException2)
    {
      arrayOfByte = (getUrl() + '\000').getBytes();
    }
    long l3 = OS.JSStringCreateWithUTF8CString(arrayOfByte);
    long l4 = OS.JSEvaluateScript(l1, l2, 0L, l3, 0, null);
    OS.JSStringRelease(l3);
    OS.JSStringRelease(l2);
    return l4 != 0L;
  }
  
  public boolean forward()
  {
    this.html = null;
    return this.webView.goForward();
  }
  
  public String getBrowserType()
  {
    return "webkit";
  }
  
  public String getText()
  {
    WebFrame localWebFrame = this.webView.mainFrame();
    WebDataSource localWebDataSource = localWebFrame.dataSource();
    if (localWebDataSource == null) {
      return "";
    }
    WebDocumentRepresentation localWebDocumentRepresentation = localWebDataSource.representation();
    if (localWebDocumentRepresentation == null) {
      return "";
    }
    NSString localNSString = localWebDocumentRepresentation.documentSource();
    if (localNSString == null) {
      return "";
    }
    return localNSString.getString();
  }
  
  public String getUrl()
  {
    if (this.url.length() == 0) {
      return "about:blank";
    }
    return this.url;
  }
  
  public boolean isBackEnabled()
  {
    return this.webView.canGoBack();
  }
  
  public boolean isForwardEnabled()
  {
    return this.webView.canGoForward();
  }
  
  public void refresh()
  {
    this.html = null;
    this.webView.reload(null);
  }
  
  public boolean setText(String paramString, boolean paramBoolean)
  {
    int i = this.html != null ? 1 : 0;
    this.html = paramString;
    this.untrustedText = (!paramBoolean);
    if (i != 0) {
      return true;
    }
    NSURL localNSURL = NSURL.URLWithString(NSString.stringWith("about:blank"));
    NSURLRequest localNSURLRequest = NSURLRequest.requestWithURL(localNSURL);
    WebFrame localWebFrame = this.webView.mainFrame();
    localWebFrame.loadRequest(localNSURLRequest);
    return true;
  }
  
  public boolean setUrl(String paramString1, String paramString2, String[] paramArrayOfString)
  {
    this.html = null;
    this.lastNavigateURL = paramString1;
    if (paramString1.indexOf('/') == 0) {
      paramString1 = "file://" + paramString1;
    } else if (paramString1.indexOf(':') == -1) {
      paramString1 = "http://" + paramString1;
    }
    NSString localNSString1 = NSString.stringWith(paramString1);
    NSString localNSString2 = NSString.stringWith("%#");
    long l = OS.CFURLCreateStringByAddingPercentEscapes(0L, localNSString1.id, localNSString2.id, 0L, 134217984);
    NSString localNSString3 = new NSString(l);
    NSURL localNSURL = NSURL.URLWithString(localNSString3);
    OS.CFRelease(l);
    NSMutableURLRequest localNSMutableURLRequest = (NSMutableURLRequest)NSMutableURLRequest.requestWithURL(localNSURL);
    Object localObject;
    if (paramString2 != null)
    {
      localNSMutableURLRequest.setHTTPMethod(NSString.stringWith("POST"));
      byte[] arrayOfByte = paramString2.getBytes();
      localObject = NSData.dataWithBytes(arrayOfByte, arrayOfByte.length);
      localNSMutableURLRequest.setHTTPBody((NSData)localObject);
    }
    if (paramArrayOfString != null) {
      for (int i = 0; i < paramArrayOfString.length; i++)
      {
        localObject = paramArrayOfString[i];
        if (localObject != null)
        {
          int j = ((String)localObject).indexOf(':');
          if (j != -1)
          {
            String str1 = ((String)localObject).substring(0, j).trim();
            String str2 = ((String)localObject).substring(j + 1).trim();
            if ((str1.length() > 0) && (str2.length() > 0)) {
              if (str1.equalsIgnoreCase("user-agent")) {
                this.webView.setCustomUserAgent(NSString.stringWith(str2));
              } else {
                localNSMutableURLRequest.setValue(NSString.stringWith(str2), NSString.stringWith(str1));
              }
            }
          }
        }
      }
    }
    WebFrame localWebFrame = this.webView.mainFrame();
    localWebFrame.loadRequest(localNSMutableURLRequest);
    this.webView.setCustomUserAgent(null);
    return true;
  }
  
  public void stop()
  {
    this.html = null;
    this.webView.stopLoading(null);
  }
  
  boolean translateMnemonics()
  {
    return false;
  }
  
  void webView_didChangeLocationWithinPageForFrame(long paramLong1, long paramLong2)
  {
    WebFrame localWebFrame = new WebFrame(paramLong2);
    WebDataSource localWebDataSource = localWebFrame.dataSource();
    NSMutableURLRequest localNSMutableURLRequest = localWebDataSource.request();
    NSURL localNSURL = localNSMutableURLRequest.URL();
    NSString localNSString = localNSURL.absoluteString();
    int i = (int)localNSString.length();
    if (i == 0) {
      return;
    }
    String str = localNSString.getString();
    if (str.equals("file:///"))
    {
      str = "about:blank";
    }
    else
    {
      i = "file:///".length();
      if ((str.startsWith("file:///")) && (str.charAt(i) == '#')) {
        str = "about:blank" + str.substring(i);
      }
    }
    Display localDisplay = this.browser.getDisplay();
    boolean bool = paramLong2 == this.webView.mainFrame().id;
    if (bool)
    {
      localObject = new StatusTextEvent(this.browser);
      ((StatusTextEvent)localObject).display = localDisplay;
      ((StatusTextEvent)localObject).widget = this.browser;
      ((StatusTextEvent)localObject).text = str;
      for (j = 0; j < this.statusTextListeners.length; j++) {
        this.statusTextListeners[j].changed((StatusTextEvent)localObject);
      }
    }
    Object localObject = new LocationEvent(this.browser);
    ((LocationEvent)localObject).display = localDisplay;
    ((LocationEvent)localObject).widget = this.browser;
    ((LocationEvent)localObject).location = str;
    ((LocationEvent)localObject).top = bool;
    for (int j = 0; j < this.locationListeners.length; j++) {
      this.locationListeners[j].changed((LocationEvent)localObject);
    }
  }
  
  void webView_didFailProvisionalLoadWithError_forFrame(long paramLong1, long paramLong2, long paramLong3)
  {
    if (paramLong3 == this.webView.mainFrame().id) {
      this.identifier = 0L;
    }
    NSError localNSError = new NSError(paramLong2);
    long l = localNSError.code();
    if (-1000L < l) {
      return;
    }
    NSURL localNSURL = null;
    NSDictionary localNSDictionary = localNSError.userInfo();
    if (localNSDictionary != null)
    {
      localObject1 = localNSDictionary.valueForKey(NSString.stringWith("NSErrorFailingURLKey"));
      if (localObject1 != null) {
        localNSURL = new NSURL((id)localObject1);
      }
    }
    Object localObject2;
    Object localObject3;
    Object localObject4;
    if ((localNSURL != null) && (-1204L <= l) && (l <= -1200L))
    {
      localObject1 = localNSDictionary.objectForKey(NSString.stringWith("NSErrorPeerCertificateChainKey"));
      localObject2 = new long[1];
      localObject3 = new long[1];
      localObject4 = new long[1];
      int i = 0;
      int j = OS.SecPolicySearchCreate(3L, 0L, 0L, (long[])localObject2);
      if ((j == 0) && (localObject2[0] != 0L))
      {
        j = OS.SecPolicySearchCopyNext(localObject2[0], (long[])localObject3);
        if ((j == 0) && (localObject3[0] != 0L))
        {
          j = OS.SecTrustCreateWithCertificates(((id)localObject1).id, localObject3[0], (long[])localObject4);
          if ((j == 0) && (localObject4[0] != 0L))
          {
            SFCertificateTrustPanel localSFCertificateTrustPanel = SFCertificateTrustPanel.sharedCertificateTrustPanel();
            String str1 = localNSURL.absoluteString().getString();
            String str2 = Compatibility.getMessage("SWT_InvalidCert_Message", new Object[] { str1 });
            localSFCertificateTrustPanel.setAlternateButtonTitle(NSString.stringWith(Compatibility.getMessage("SWT_Cancel")));
            localSFCertificateTrustPanel.setShowsHelp(true);
            localNSURL.retain();
            NSWindow localNSWindow = this.browser.getShell().view.window();
            localSFCertificateTrustPanel.beginSheetForWindow(localNSWindow, this.delegate, OS.sel_createPanelDidEnd, localNSURL.id, localObject4[0], NSString.stringWith(str2));
            i = 1;
          }
        }
      }
      if (localObject4[0] != 0L) {
        OS.CFRelease(localObject4[0]);
      }
      if (localObject3[0] != 0L) {
        OS.CFRelease(localObject3[0]);
      }
      if (localObject2[0] != 0L) {
        OS.CFRelease(localObject2[0]);
      }
      if (i != 0) {
        return;
      }
    }
    Object localObject1 = localNSError.localizedDescription();
    if (localObject1 != null)
    {
      localObject2 = ((NSString)localObject1).getString();
      localObject3 = localNSURL != null ? localNSURL.absoluteString().getString() + "\n\n" : "";
      localObject3 = (String)localObject3 + Compatibility.getMessage("SWT_Page_Load_Failed", new Object[] { localObject2 });
      localObject4 = new MessageBox(this.browser.getShell(), 33);
      ((MessageBox)localObject4).setMessage((String)localObject3);
      ((MessageBox)localObject4).open();
    }
  }
  
  void createPanelDidEnd(long paramLong1, long paramLong2, long paramLong3)
  {
    NSURL localNSURL = new NSURL(paramLong3);
    localNSURL.autorelease();
    if (paramLong2 != 1L) {
      return;
    }
    long l = OS.class_getClassMethod(OS.class_NSURLRequest, OS.sel_setAllowsAnyHTTPSCertificate);
    if (l != 0L)
    {
      OS.objc_msgSend(OS.class_NSURLRequest, OS.sel_setAllowsAnyHTTPSCertificate, 1L, localNSURL.host().id);
      setUrl(localNSURL.absoluteString().getString(), null, null);
    }
  }
  
  void webView_didFinishLoadForFrame(long paramLong1, long paramLong2)
  {
    if (paramLong2 == this.webView.mainFrame().id)
    {
      Object localObject1;
      Object localObject2;
      Object localObject3;
      Object localObject4;
      if ((this.html != null) && (getUrl().startsWith("about:blank")))
      {
        this.loadingText = true;
        localObject1 = NSString.stringWith(this.html);
        if (this.untrustedText) {
          localObject2 = NSString.stringWith("about:blank");
        } else {
          localObject2 = NSString.stringWith("file:///");
        }
        localObject3 = NSURL.URLWithString((NSString)localObject2);
        localObject4 = this.webView.mainFrame();
        ((WebFrame)localObject4).loadHTMLString((NSString)localObject1, (NSURL)localObject3);
        this.html = null;
      }
      if (!this.loadingText)
      {
        localObject1 = this.browser.getDisplay();
        localObject2 = new WebFrame(paramLong2);
        localObject3 = ((WebFrame)localObject2).dataSource();
        if (localObject3 != null)
        {
          localObject4 = ((WebDataSource)localObject3).pageTitle();
          if (localObject4 == null)
          {
            TitleEvent localTitleEvent = new TitleEvent(this.browser);
            localTitleEvent.display = ((Display)localObject1);
            localTitleEvent.widget = this.browser;
            localTitleEvent.title = getUrl();
            for (int j = 0; j < this.titleListeners.length; j++) {
              this.titleListeners[j].changed(localTitleEvent);
            }
            if (this.browser.isDisposed()) {
              return;
            }
          }
        }
        localObject4 = new ProgressEvent(this.browser);
        ((ProgressEvent)localObject4).display = ((Display)localObject1);
        ((ProgressEvent)localObject4).widget = this.browser;
        ((ProgressEvent)localObject4).current = 100;
        ((ProgressEvent)localObject4).total = 100;
        for (int i = 0; i < this.progressListeners.length; i++) {
          this.progressListeners[i].completed((ProgressEvent)localObject4);
        }
      }
      this.loadingText = false;
      if (this.browser.isDisposed()) {
        return;
      }
      this.identifier = 0L;
    }
  }
  
  void hookDOMKeyListeners(long paramLong)
  {
    WebFrame localWebFrame = new WebFrame(paramLong);
    DOMDocument localDOMDocument = localWebFrame.DOMDocument();
    if (localDOMDocument == null) {
      return;
    }
    NSString localNSString = NSString.stringWith("keydown");
    localDOMDocument.addEventListener(localNSString, this.delegate, false);
    localNSString = NSString.stringWith("keyup");
    localDOMDocument.addEventListener(localNSString, this.delegate, false);
  }
  
  void hookDOMMouseListeners(long paramLong)
  {
    WebFrame localWebFrame = new WebFrame(paramLong);
    DOMDocument localDOMDocument = localWebFrame.DOMDocument();
    if (localDOMDocument == null) {
      return;
    }
    NSString localNSString = NSString.stringWith("mousedown");
    localDOMDocument.addEventListener(localNSString, this.delegate, false);
    localNSString = NSString.stringWith("mouseup");
    localDOMDocument.addEventListener(localNSString, this.delegate, false);
    localNSString = NSString.stringWith("mousemove");
    localDOMDocument.addEventListener(localNSString, this.delegate, false);
    localNSString = NSString.stringWith("mousewheel");
    localDOMDocument.addEventListener(localNSString, this.delegate, false);
  }
  
  void webView_didReceiveTitle_forFrame(long paramLong1, long paramLong2, long paramLong3)
  {
    if (paramLong3 == this.webView.mainFrame().id)
    {
      NSString localNSString = new NSString(paramLong2);
      String str = localNSString.getString();
      TitleEvent localTitleEvent = new TitleEvent(this.browser);
      localTitleEvent.display = this.browser.getDisplay();
      localTitleEvent.widget = this.browser;
      localTitleEvent.title = str;
      for (int i = 0; i < this.titleListeners.length; i++) {
        this.titleListeners[i].changed(localTitleEvent);
      }
    }
  }
  
  void webView_didStartProvisionalLoadForFrame(long paramLong1, long paramLong2) {}
  
  void webView_didCommitLoadForFrame(long paramLong1, long paramLong2)
  {
    WebFrame localWebFrame = new WebFrame(paramLong2);
    WebDataSource localWebDataSource = localWebFrame.dataSource();
    NSMutableURLRequest localNSMutableURLRequest = localWebDataSource.request();
    NSURL localNSURL = localNSMutableURLRequest.URL();
    NSString localNSString = localNSURL.absoluteString();
    int i = (int)localNSString.length();
    if (i == 0) {
      return;
    }
    String str = localNSString.getString();
    if (str.equals("file:///"))
    {
      str = "about:blank";
    }
    else
    {
      i = "file:///".length();
      if ((str.startsWith("file:///")) && (str.charAt(i) == '#')) {
        str = "about:blank" + str.substring(i);
      }
    }
    Display localDisplay = this.browser.getDisplay();
    boolean bool = paramLong2 == this.webView.mainFrame().id;
    if (bool)
    {
      this.resourceCount = 0;
      this.url = str;
      if ((str.startsWith("about:blank")) && (this.html != null)) {
        return;
      }
      localObject1 = this.functions.elements();
      while (((Enumeration)localObject1).hasMoreElements())
      {
        localObject2 = (BrowserFunction)((Enumeration)localObject1).nextElement();
        execute(((BrowserFunction)localObject2).functionString);
      }
      Object localObject2 = new ProgressEvent(this.browser);
      ((ProgressEvent)localObject2).display = localDisplay;
      ((ProgressEvent)localObject2).widget = this.browser;
      ((ProgressEvent)localObject2).current = 1;
      ((ProgressEvent)localObject2).total = 100;
      for (int k = 0; k < this.progressListeners.length; k++) {
        this.progressListeners[k].changed((ProgressEvent)localObject2);
      }
      if (this.browser.isDisposed()) {
        return;
      }
      StatusTextEvent localStatusTextEvent = new StatusTextEvent(this.browser);
      localStatusTextEvent.display = localDisplay;
      localStatusTextEvent.widget = this.browser;
      localStatusTextEvent.text = str;
      for (int m = 0; m < this.statusTextListeners.length; m++) {
        this.statusTextListeners[m].changed(localStatusTextEvent);
      }
      if (this.browser.isDisposed()) {
        return;
      }
      hookDOMKeyListeners(paramLong2);
    }
    hookDOMMouseListeners(paramLong2);
    Object localObject1 = new LocationEvent(this.browser);
    ((LocationEvent)localObject1).display = localDisplay;
    ((LocationEvent)localObject1).widget = this.browser;
    ((LocationEvent)localObject1).location = str;
    ((LocationEvent)localObject1).top = bool;
    for (int j = 0; j < this.locationListeners.length; j++) {
      this.locationListeners[j].changed((LocationEvent)localObject1);
    }
  }
  
  void webView_windowScriptObjectAvailable(long paramLong1, long paramLong2)
  {
    NSObject localNSObject = new NSObject(paramLong2);
    NSString localNSString = NSString.stringWith("external");
    localNSObject.setValue(this.delegate, localNSString);
  }
  
  void webView_resource_didFinishLoadingFromDataSource(long paramLong1, long paramLong2, long paramLong3) {}
  
  void webView_resource_didFailLoadingWithError_fromDataSource(long paramLong1, long paramLong2, long paramLong3, long paramLong4) {}
  
  void webView_resource_didReceiveAuthenticationChallenge_fromDataSource(long paramLong1, long paramLong2, long paramLong3, long paramLong4)
  {
    NSURLAuthenticationChallenge localNSURLAuthenticationChallenge = new NSURLAuthenticationChallenge(paramLong3);
    if (localNSURLAuthenticationChallenge.previousFailureCount() < 3L) {
      for (int i = 0; i < this.authenticationListeners.length; i++)
      {
        AuthenticationEvent localAuthenticationEvent = new AuthenticationEvent(this.browser);
        localAuthenticationEvent.location = this.lastNavigateURL;
        this.authenticationListeners[i].authenticate(localAuthenticationEvent);
        id localid1;
        if (!localAuthenticationEvent.doit)
        {
          localid1 = localNSURLAuthenticationChallenge.sender();
          OS.objc_msgSend(localid1.id, OS.sel_cancelAuthenticationChallenge_, paramLong3);
          return;
        }
        if ((localAuthenticationEvent.user != null) && (localAuthenticationEvent.password != null))
        {
          localid1 = localNSURLAuthenticationChallenge.sender();
          localObject1 = NSString.stringWith(localAuthenticationEvent.user);
          NSString localNSString1 = NSString.stringWith(localAuthenticationEvent.password);
          localObject2 = NSURLCredential.credentialWithUser((NSString)localObject1, localNSString1, 1L);
          OS.objc_msgSend(localid1.id, OS.sel_useCredential_forAuthenticationChallenge_, ((NSURLCredential)localObject2).id, paramLong3);
          return;
        }
      }
    }
    long l1 = OS.class_WebPanelAuthenticationHandler;
    if (l1 != 0L)
    {
      long l2 = OS.class_getClassMethod(l1, OS.sel_sharedHandler);
      if (l2 != 0L)
      {
        long l3 = OS.objc_msgSend(l1, OS.sel_sharedHandler);
        if (l3 != 0L)
        {
          OS.objc_msgSend(l3, OS.sel_startAuthentication, paramLong3, this.webView.window().id);
          return;
        }
      }
    }
    String[] arrayOfString = new String[1];
    Object localObject1 = new String[1];
    NSURLCredential localNSURLCredential1 = localNSURLAuthenticationChallenge.proposedCredential();
    if (localNSURLCredential1 != null)
    {
      arrayOfString[0] = localNSURLCredential1.user().getString();
      if (localNSURLCredential1.hasPassword()) {
        localObject1[0] = localNSURLCredential1.password().getString();
      }
    }
    Object localObject2 = localNSURLAuthenticationChallenge.protectionSpace();
    String str1 = ((NSURLProtectionSpace)localObject2).host().getString() + ':' + ((NSURLProtectionSpace)localObject2).port();
    String str2 = ((NSURLProtectionSpace)localObject2).realm().getString();
    boolean bool = showAuthenticationDialog(arrayOfString, (String[])localObject1, str1, str2);
    if (!bool)
    {
      localid2 = localNSURLAuthenticationChallenge.sender();
      OS.objc_msgSend(localid2.id, OS.sel_cancelAuthenticationChallenge_, paramLong3);
      return;
    }
    id localid2 = localNSURLAuthenticationChallenge.sender();
    NSString localNSString2 = NSString.stringWith(arrayOfString[0]);
    NSString localNSString3 = NSString.stringWith(localObject1[0]);
    NSURLCredential localNSURLCredential2 = NSURLCredential.credentialWithUser(localNSString2, localNSString3, 1L);
    OS.objc_msgSend(localid2.id, OS.sel_useCredential_forAuthenticationChallenge_, localNSURLCredential2.id, paramLong3);
  }
  
  boolean showAuthenticationDialog(final String[] paramArrayOfString1, final String[] paramArrayOfString2, String paramString1, String paramString2)
  {
    final Shell localShell = new Shell(this.browser.getShell());
    localShell.setLayout(new GridLayout());
    String str = SWT.getMessage("SWT_Authentication_Required");
    localShell.setText(str);
    Label localLabel1 = new Label(localShell, 64);
    localLabel1.setText(Compatibility.getMessage("SWT_Enter_Username_and_Password", new String[] { paramString2, paramString1 }));
    GridData localGridData = new GridData();
    Monitor localMonitor = this.browser.getMonitor();
    int i = localMonitor.getBounds().width * 2 / 3;
    int j = localLabel1.computeSize(-1, -1).x;
    localGridData.widthHint = Math.min(j, i);
    localGridData.horizontalAlignment = 4;
    localGridData.grabExcessHorizontalSpace = true;
    localLabel1.setLayoutData(localGridData);
    Label localLabel2 = new Label(localShell, 0);
    localLabel2.setText(SWT.getMessage("SWT_Username"));
    final Text localText1 = new Text(localShell, 2048);
    if (paramArrayOfString1[0] != null) {
      localText1.setText(paramArrayOfString1[0]);
    }
    localGridData = new GridData();
    localGridData.horizontalAlignment = 4;
    localGridData.grabExcessHorizontalSpace = true;
    localText1.setLayoutData(localGridData);
    Label localLabel3 = new Label(localShell, 0);
    localLabel3.setText(SWT.getMessage("SWT_Password"));
    final Text localText2 = new Text(localShell, 4196352);
    if (paramArrayOfString2[0] != null) {
      localText2.setText(paramArrayOfString2[0]);
    }
    localGridData = new GridData();
    localGridData.horizontalAlignment = 4;
    localGridData.grabExcessHorizontalSpace = true;
    localText2.setLayoutData(localGridData);
    final boolean[] arrayOfBoolean = new boolean[1];
    final Button[] arrayOfButton = new Button[2];
    Listener local5 = new Listener()
    {
      public void handleEvent(Event paramAnonymousEvent)
      {
        paramArrayOfString1[0] = localText1.getText();
        paramArrayOfString2[0] = localText2.getText();
        arrayOfBoolean[0] = (paramAnonymousEvent.widget == arrayOfButton[1] ? 1 : false);
        localShell.close();
      }
    };
    Composite localComposite = new Composite(localShell, 0);
    localGridData = new GridData();
    localGridData.horizontalAlignment = 3;
    localComposite.setLayoutData(localGridData);
    localComposite.setLayout(new GridLayout(2, true));
    arrayOfButton[0] = new Button(localComposite, 8);
    arrayOfButton[0].setText(SWT.getMessage("SWT_Cancel"));
    arrayOfButton[0].setLayoutData(new GridData(768));
    arrayOfButton[0].addListener(13, local5);
    arrayOfButton[1] = new Button(localComposite, 8);
    arrayOfButton[1].setText(SWT.getMessage("SWT_OK"));
    arrayOfButton[1].setLayoutData(new GridData(768));
    arrayOfButton[1].addListener(13, local5);
    localShell.setDefaultButton(arrayOfButton[1]);
    localShell.pack();
    localShell.open();
    Display localDisplay = this.browser.getDisplay();
    while (!localShell.isDisposed()) {
      if (!localDisplay.readAndDispatch()) {
        localDisplay.sleep();
      }
    }
    return arrayOfBoolean[0];
  }
  
  long webView_identifierForInitialRequest_fromDataSource(long paramLong1, long paramLong2, long paramLong3)
  {
    ProgressEvent localProgressEvent = new ProgressEvent(this.browser);
    localProgressEvent.display = this.browser.getDisplay();
    localProgressEvent.widget = this.browser;
    localProgressEvent.current = this.resourceCount;
    localProgressEvent.total = Math.max(this.resourceCount, 100);
    for (int i = 0; i < this.progressListeners.length; i++) {
      this.progressListeners[i].changed(localProgressEvent);
    }
    if (this.browser.isDisposed()) {
      return 0L;
    }
    NSNumber localNSNumber = NSNumber.numberWithInt(this.resourceCount++);
    if (this.identifier == 0L)
    {
      WebDataSource localWebDataSource = new WebDataSource(paramLong3);
      WebFrame localWebFrame = localWebDataSource.webFrame();
      if (localWebFrame.id == this.webView.mainFrame().id) {
        this.identifier = localNSNumber.id;
      }
    }
    return localNSNumber.id;
  }
  
  long webView_resource_willSendRequest_redirectResponse_fromDataSource(long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5)
  {
    NSURLRequest localNSURLRequest = new NSURLRequest(paramLong3);
    NSURL localNSURL = localNSURLRequest.URL();
    if (localNSURL.isFileURL())
    {
      NSMutableURLRequest localNSMutableURLRequest = new NSMutableURLRequest(localNSURLRequest.mutableCopy());
      localNSMutableURLRequest.autorelease();
      localNSMutableURLRequest.setCachePolicy(1L);
      return localNSMutableURLRequest.id;
    }
    return paramLong3;
  }
  
  long webView_createWebViewWithRequest(long paramLong1, long paramLong2)
  {
    WindowEvent localWindowEvent = new WindowEvent(this.browser);
    localWindowEvent.display = this.browser.getDisplay();
    localWindowEvent.widget = this.browser;
    localWindowEvent.required = true;
    if (this.openWindowListeners != null) {
      for (int i = 0; i < this.openWindowListeners.length; i++) {
        this.openWindowListeners[i].open(localWindowEvent);
      }
    }
    WebView localWebView = null;
    Browser localBrowser = null;
    if ((localWindowEvent.browser != null) && ((localWindowEvent.browser.webBrowser instanceof WebKit))) {
      localBrowser = localWindowEvent.browser;
    }
    if ((localBrowser != null) && (!localBrowser.isDisposed()))
    {
      localWebView = ((WebKit)localBrowser.webBrowser).webView;
      if (paramLong2 != 0L)
      {
        WebFrame localWebFrame = localWebView.mainFrame();
        localWebFrame.loadRequest(new NSURLRequest(paramLong2));
      }
    }
    return localWebView != null ? localWebView.id : 0L;
  }
  
  void webViewShow(long paramLong)
  {
    Shell localShell = this.browser.getShell();
    Point localPoint = localShell.getSize();
    localShell.setSize(localPoint.x + 1, localPoint.y);
    localShell.setSize(localPoint.x, localPoint.y);
    WindowEvent localWindowEvent = new WindowEvent(this.browser);
    localWindowEvent.display = this.browser.getDisplay();
    localWindowEvent.widget = this.browser;
    if (this.location != null) {
      localWindowEvent.location = this.location;
    }
    if (this.size != null) {
      localWindowEvent.size = this.size;
    }
    localWindowEvent.addressBar = this.toolBar;
    localWindowEvent.menuBar = true;
    localWindowEvent.statusBar = this.statusBar;
    localWindowEvent.toolBar = this.toolBar;
    for (int i = 0; i < this.visibilityWindowListeners.length; i++) {
      this.visibilityWindowListeners[i].show(localWindowEvent);
    }
    this.location = null;
    this.size = null;
  }
  
  void webView_setFrame(long paramLong1, long paramLong2)
  {
    NSRect localNSRect = new NSRect();
    OS.memmove(localNSRect, paramLong2, NSRect.sizeof);
    Rectangle localRectangle = this.browser.getDisplay().getBounds();
    this.location = new Point((int)localNSRect.x, localRectangle.height - (int)localNSRect.y - (int)localNSRect.height);
    this.size = new Point((int)localNSRect.width, (int)localNSRect.height);
  }
  
  void webViewFocus(long paramLong) {}
  
  void webViewUnfocus(long paramLong) {}
  
  NSNumber callRunBeforeUnloadConfirmPanelWithMessage(long paramLong1, long paramLong2)
  {
    boolean bool = webView_runBeforeUnloadConfirmPanelWithMessage_initiatedByFrame(0L, paramLong1, 0L);
    return NSNumber.numberWithBool(bool);
  }
  
  boolean webView_runBeforeUnloadConfirmPanelWithMessage_initiatedByFrame(long paramLong1, long paramLong2, long paramLong3)
  {
    NSString localNSString = new NSString(paramLong2);
    StringBuffer localStringBuffer = new StringBuffer(Compatibility.getMessage("SWT_OnBeforeUnload_Message1"));
    localStringBuffer.append("\n\n");
    localStringBuffer.append(localNSString.getString());
    localStringBuffer.append("\n\n");
    localStringBuffer.append(Compatibility.getMessage("SWT_OnBeforeUnload_Message2"));
    MessageBox localMessageBox = new MessageBox(this.browser.getShell(), 268435748);
    localMessageBox.setMessage(localStringBuffer.toString());
    return localMessageBox.open() == 32;
  }
  
  void webView_runJavaScriptAlertPanelWithMessage(long paramLong1, long paramLong2)
  {
    NSString localNSString = new NSString(paramLong2);
    String str = localNSString.getString();
    MessageBox localMessageBox = new MessageBox(this.browser.getShell(), 40);
    localMessageBox.setText("Javascript");
    localMessageBox.setMessage(str);
    localMessageBox.open();
  }
  
  int webView_runJavaScriptConfirmPanelWithMessage(long paramLong1, long paramLong2)
  {
    NSString localNSString = new NSString(paramLong2);
    String str = localNSString.getString();
    MessageBox localMessageBox = new MessageBox(this.browser.getShell(), 292);
    localMessageBox.setText("Javascript");
    localMessageBox.setMessage(str);
    return localMessageBox.open() == 32 ? 1 : 0;
  }
  
  void webView_runOpenPanelForFileButtonWithResultListener(long paramLong1, long paramLong2)
  {
    FileDialog localFileDialog = new FileDialog(this.browser.getShell(), 0);
    String str = localFileDialog.open();
    WebOpenPanelResultListener localWebOpenPanelResultListener = new WebOpenPanelResultListener(paramLong2);
    if (str == null)
    {
      localWebOpenPanelResultListener.cancel();
      return;
    }
    localWebOpenPanelResultListener.chooseFilename(NSString.stringWith(str));
  }
  
  void webViewClose(long paramLong)
  {
    Shell localShell = this.browser.getShell();
    WindowEvent localWindowEvent = new WindowEvent(this.browser);
    localWindowEvent.display = this.browser.getDisplay();
    localWindowEvent.widget = this.browser;
    for (int i = 0; i < this.closeWindowListeners.length; i++) {
      this.closeWindowListeners[i].close(localWindowEvent);
    }
    this.browser.dispose();
    if (localShell.isDisposed()) {
      return;
    }
    Point localPoint = localShell.getSize();
    localShell.setSize(localPoint.x + 1, localPoint.y);
    localShell.setSize(localPoint.x, localPoint.y);
  }
  
  long webView_contextMenuItemsForElement_defaultMenuItems(long paramLong1, long paramLong2, long paramLong3)
  {
    Point localPoint = this.browser.getDisplay().getCursorLocation();
    Event localEvent = new Event();
    localEvent.x = localPoint.x;
    localEvent.y = localPoint.y;
    this.browser.notifyListeners(35, localEvent);
    Menu localMenu = this.browser.getMenu();
    if (!localEvent.doit) {
      return 0L;
    }
    if ((localMenu != null) && (!localMenu.isDisposed()))
    {
      if ((localEvent.x != localPoint.x) || (localEvent.y != localPoint.y)) {
        localMenu.setLocation(localEvent.x, localEvent.y);
      }
      localMenu.setVisible(true);
      return 0L;
    }
    return paramLong3;
  }
  
  void webView_setStatusBarVisible(long paramLong, boolean paramBoolean)
  {
    this.statusBar = paramBoolean;
  }
  
  void webView_setStatusText(long paramLong1, long paramLong2)
  {
    NSString localNSString = new NSString(paramLong2);
    int i = (int)localNSString.length();
    if (i == 0) {
      return;
    }
    StatusTextEvent localStatusTextEvent = new StatusTextEvent(this.browser);
    localStatusTextEvent.display = this.browser.getDisplay();
    localStatusTextEvent.widget = this.browser;
    localStatusTextEvent.text = localNSString.getString();
    for (int j = 0; j < this.statusTextListeners.length; j++) {
      this.statusTextListeners[j].changed(localStatusTextEvent);
    }
  }
  
  void webView_setResizable(long paramLong, boolean paramBoolean) {}
  
  void webView_setToolbarsVisible(long paramLong, boolean paramBoolean)
  {
    this.toolBar = paramBoolean;
  }
  
  void webView_mouseDidMoveOverElement_modifierFlags(long paramLong1, long paramLong2, long paramLong3)
  {
    if (paramLong2 == 0L) {
      return;
    }
    NSString localNSString = NSString.stringWith("WebElementLinkURL");
    NSDictionary localNSDictionary = new NSDictionary(paramLong2);
    id localid = localNSDictionary.valueForKey(localNSString);
    if (localid == null)
    {
      if (this.lastHoveredLinkURL == null) {
        return;
      }
      this.lastHoveredLinkURL = null;
      localObject = new StatusTextEvent(this.browser);
      ((StatusTextEvent)localObject).display = this.browser.getDisplay();
      ((StatusTextEvent)localObject).widget = this.browser;
      ((StatusTextEvent)localObject).text = "";
      for (i = 0; i < this.statusTextListeners.length; i++) {
        this.statusTextListeners[i].changed((StatusTextEvent)localObject);
      }
      return;
    }
    Object localObject = new NSURL(localid.id).absoluteString();
    int i = (int)((NSString)localObject).length();
    String str;
    if (i == 0) {
      str = "";
    } else {
      str = ((NSString)localObject).getString();
    }
    if (str.equals(this.lastHoveredLinkURL)) {
      return;
    }
    this.lastHoveredLinkURL = str;
    StatusTextEvent localStatusTextEvent = new StatusTextEvent(this.browser);
    localStatusTextEvent.display = this.browser.getDisplay();
    localStatusTextEvent.widget = this.browser;
    localStatusTextEvent.text = str;
    for (int j = 0; j < this.statusTextListeners.length; j++) {
      this.statusTextListeners[j].changed(localStatusTextEvent);
    }
  }
  
  void webView_printFrameView(long paramLong1, long paramLong2)
  {
    WebFrameView localWebFrameView = new WebFrameView(paramLong2);
    boolean bool = localWebFrameView.documentViewShouldHandlePrint();
    if (bool)
    {
      localWebFrameView.printDocumentView();
      return;
    }
    NSPrintInfo localNSPrintInfo = NSPrintInfo.sharedPrintInfo();
    NSPrintOperation localNSPrintOperation = localWebFrameView.printOperationWithPrintInfo(localNSPrintInfo);
    if (localNSPrintOperation != null) {
      localNSPrintOperation.runOperation();
    }
  }
  
  void webView_decidePolicyForMIMEType_request_frame_decisionListener(long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5)
  {
    boolean bool = WebView.canShowMIMEType(new NSString(paramLong2));
    WebPolicyDecisionListener localWebPolicyDecisionListener = new WebPolicyDecisionListener(paramLong5);
    if (bool) {
      localWebPolicyDecisionListener.use();
    } else {
      localWebPolicyDecisionListener.download();
    }
  }
  
  void webView_decidePolicyForNavigationAction_request_frame_decisionListener(long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5)
  {
    NSURL localNSURL = new NSURLRequest(paramLong3).URL();
    WebPolicyDecisionListener localWebPolicyDecisionListener = new WebPolicyDecisionListener(paramLong5);
    if (this.loadingText)
    {
      localWebPolicyDecisionListener.use();
      return;
    }
    if (localNSURL == null)
    {
      localWebPolicyDecisionListener.ignore();
      return;
    }
    if ((localNSURL.isFileURL()) && (getUrl().startsWith("about:blank")) && (this.untrustedText))
    {
      localWebPolicyDecisionListener.ignore();
      return;
    }
    NSString localNSString = localNSURL.absoluteString();
    String str = localNSString.getString();
    if (str.equals("file:///"))
    {
      str = "about:blank";
    }
    else
    {
      int i = "file:///".length();
      if ((str.startsWith("file:///")) && (str.charAt(i) == '#')) {
        str = "about:blank" + str.substring(i);
      }
    }
    LocationEvent localLocationEvent = new LocationEvent(this.browser);
    localLocationEvent.display = this.browser.getDisplay();
    localLocationEvent.widget = this.browser;
    localLocationEvent.location = str;
    localLocationEvent.doit = true;
    if (this.locationListeners != null) {
      for (int j = 0; j < this.locationListeners.length; j++) {
        this.locationListeners[j].changing(localLocationEvent);
      }
    }
    if (localLocationEvent.doit)
    {
      if (this.jsEnabled != this.jsEnabledOnNextPage)
      {
        this.jsEnabled = this.jsEnabledOnNextPage;
        if (this.preferences == null)
        {
          this.preferences = ((WebPreferences)new WebPreferences().alloc().init());
          this.webView.setPreferences(this.preferences);
        }
        this.preferences.setJavaScriptEnabled(this.jsEnabled);
      }
      localWebPolicyDecisionListener.use();
      this.lastNavigateURL = str;
    }
    else
    {
      localWebPolicyDecisionListener.ignore();
    }
  }
  
  void webView_decidePolicyForNewWindowAction_request_newFrameName_decisionListener(long paramLong1, long paramLong2, long paramLong3, long paramLong4, long paramLong5)
  {
    WebPolicyDecisionListener localWebPolicyDecisionListener = new WebPolicyDecisionListener(paramLong5);
    localWebPolicyDecisionListener.use();
  }
  
  void webView_unableToImplementPolicyWithError_frame(long paramLong1, long paramLong2, long paramLong3) {}
  
  void download_decideDestinationWithSuggestedFilename(long paramLong1, long paramLong2)
  {
    NSString localNSString = new NSString(paramLong2);
    String str1 = localNSString.getString();
    FileDialog localFileDialog = new FileDialog(this.browser.getShell(), 8192);
    localFileDialog.setText(SWT.getMessage("SWT_FileDownload"));
    localFileDialog.setFileName(str1);
    String str2 = localFileDialog.open();
    NSURLDownload localNSURLDownload = new NSURLDownload(paramLong1);
    if (str2 == null)
    {
      localNSURLDownload.cancel();
      return;
    }
    localNSURLDownload.setDestination(NSString.stringWith(str2), true);
  }
  
  void handleEvent(long paramLong)
  {
    NSString localNSString = new NSString(OS.objc_msgSend(paramLong, OS.sel_type));
    String str = localNSString.getString();
    if (("keydown".equals(str)) || ("keyup".equals(str)))
    {
      localObject = new DOMKeyboardEvent(paramLong);
      boolean bool1 = ((DOMKeyboardEvent)localObject).ctrlKey();
      boolean bool2 = ((DOMKeyboardEvent)localObject).shiftKey();
      boolean bool3 = ((DOMKeyboardEvent)localObject).altKey();
      boolean bool4 = ((DOMKeyboardEvent)localObject).metaKey();
      int m = ((DOMKeyboardEvent)localObject).keyCode();
      int i1 = ((DOMKeyboardEvent)localObject).charCode();
      Event localEvent1 = new Event();
      localEvent1.widget = this.browser;
      int i2 = "keydown".equals(str) ? 1 : 2;
      localEvent1.type = i2;
      int i3 = translateKey(m);
      localEvent1.keyCode = i3;
      localEvent1.character = ((char)i1);
      int i4 = (bool3 ? 65536 : 0) | (bool1 ? 262144 : 0) | (bool2 ? 131072 : 0) | (bool4 ? 4194304 : 0);
      localEvent1.stateMask = i4;
      boolean bool10 = true;
      if (localEvent1.type == 1)
      {
        bool10 = sendKeyEvent(localEvent1);
      }
      else
      {
        this.browser.notifyListeners(localEvent1.type, localEvent1);
        bool10 = localEvent1.doit;
      }
      if (!bool10) {
        ((DOMKeyboardEvent)localObject).preventDefault();
      } else if ((i2 == 1) && (i4 == 4194304)) {
        if (i3 == 118)
        {
          this.webView.paste(this.webView);
          ((DOMKeyboardEvent)localObject).preventDefault();
        }
        else if (i3 == 99)
        {
          this.webView.copy(this.webView);
          ((DOMKeyboardEvent)localObject).preventDefault();
        }
        else if (i3 == 120)
        {
          this.webView.cut(this.webView);
          ((DOMKeyboardEvent)localObject).preventDefault();
        }
      }
      return;
    }
    if ("mousewheel".equals(str))
    {
      localObject = new DOMWheelEvent(paramLong);
      i = ((DOMWheelEvent)localObject).screenX();
      j = ((DOMWheelEvent)localObject).screenY();
      localPoint = new Point(i, j);
      localPoint = this.browser.getDisplay().map(null, this.browser, localPoint);
      k = ((DOMWheelEvent)localObject).wheelDelta();
      boolean bool5 = ((DOMWheelEvent)localObject).ctrlKey();
      bool6 = ((DOMWheelEvent)localObject).shiftKey();
      bool7 = ((DOMWheelEvent)localObject).altKey();
      bool8 = ((DOMWheelEvent)localObject).metaKey();
      Event localEvent2 = new Event();
      localEvent2.type = 37;
      localEvent2.widget = this.browser;
      localEvent2.x = localPoint.x;
      localEvent2.y = localPoint.y;
      localEvent2.count = (k / 120);
      localEvent2.stateMask = ((bool7 ? 65536 : 0) | (bool5 ? 262144 : 0) | (bool6 ? 131072 : 0) | (bool8 ? 4194304 : 0));
      this.browser.notifyListeners(localEvent2.type, localEvent2);
      return;
    }
    Object localObject = new DOMMouseEvent(paramLong);
    int i = ((DOMMouseEvent)localObject).screenX();
    int j = ((DOMMouseEvent)localObject).screenY();
    Point localPoint = new Point(i, j);
    localPoint = this.browser.getDisplay().map(null, this.browser, localPoint);
    int k = ((DOMMouseEvent)localObject).detail();
    int n = ((DOMMouseEvent)localObject).button();
    boolean bool6 = ((DOMMouseEvent)localObject).ctrlKey();
    boolean bool7 = ((DOMMouseEvent)localObject).shiftKey();
    boolean bool8 = ((DOMMouseEvent)localObject).altKey();
    boolean bool9 = ((DOMMouseEvent)localObject).metaKey();
    Event localEvent3 = new Event();
    localEvent3.widget = this.browser;
    localEvent3.x = localPoint.x;
    localEvent3.y = localPoint.y;
    localEvent3.stateMask = ((bool8 ? 65536 : 0) | (bool6 ? 262144 : 0) | (bool7 ? 131072 : 0) | (bool9 ? 4194304 : 0));
    if ("mousedown".equals(str))
    {
      localEvent3.type = 3;
      localEvent3.button = (n + 1);
      localEvent3.count = k;
    }
    else if ("mouseup".equals(str))
    {
      localEvent3.type = 4;
      localEvent3.button = (n + 1);
      localEvent3.count = k;
      switch (localEvent3.button)
      {
      case 1: 
        localEvent3.stateMask |= 0x80000;
        break;
      case 2: 
        localEvent3.stateMask |= 0x100000;
        break;
      case 3: 
        localEvent3.stateMask |= 0x200000;
        break;
      case 4: 
        localEvent3.stateMask |= 0x800000;
        break;
      case 5: 
        localEvent3.stateMask |= 0x2000000;
      }
    }
    else if ("mousemove".equals(str))
    {
      if ((localEvent3.x == this.lastMouseMoveX) && (localEvent3.y == this.lastMouseMoveY)) {
        return;
      }
      localEvent3.type = 5;
      this.lastMouseMoveX = localEvent3.x;
      this.lastMouseMoveY = localEvent3.y;
    }
    this.browser.notifyListeners(localEvent3.type, localEvent3);
    if ((k == 2) && ("mousedown".equals(str)))
    {
      localEvent3 = new Event();
      localEvent3.widget = this.browser;
      localEvent3.x = localPoint.x;
      localEvent3.y = localPoint.y;
      localEvent3.stateMask = ((bool8 ? 65536 : 0) | (bool6 ? 262144 : 0) | (bool7 ? 131072 : 0) | (bool9 ? 4194304 : 0));
      localEvent3.type = 8;
      localEvent3.button = (n + 1);
      localEvent3.count = k;
      this.browser.notifyListeners(localEvent3.type, localEvent3);
    }
  }
  
  Object convertToJava(long paramLong)
  {
    NSObject localNSObject = new NSObject(paramLong);
    long l1 = OS.objc_lookUpClass("NSString");
    Object localObject1;
    if (localNSObject.isKindOfClass(l1))
    {
      localObject1 = new NSString(paramLong);
      return ((NSString)localObject1).getString();
    }
    l1 = OS.objc_lookUpClass("NSNumber");
    Object localObject2;
    if (localNSObject.isKindOfClass(l1))
    {
      localObject1 = new NSNumber(paramLong);
      long l2 = ((NSNumber)localObject1).objCType();
      localObject2 = new byte[1];
      OS.memmove((byte[])localObject2, l2, 1L);
      if ((localObject2[0] == 99) || (localObject2[0] == 66)) {
        return new Boolean(((NSNumber)localObject1).boolValue());
      }
      if ("islqISLQfd".indexOf(localObject2[0]) != -1) {
        return new Double(((NSNumber)localObject1).doubleValue());
      }
    }
    l1 = OS.objc_lookUpClass("WebScriptObject");
    if (localNSObject.isKindOfClass(l1))
    {
      localObject1 = new WebScriptObject(paramLong);
      id localid1 = ((WebScriptObject)localObject1).valueForKey(NSString.stringWith("length"));
      if (localid1 == null) {
        SWT.error(5);
      }
      int i = new NSNumber(localid1).intValue();
      localObject2 = new Object[i];
      for (int j = 0; j < i; j++)
      {
        id localid2 = ((WebScriptObject)localObject1).webScriptValueAtIndex(j);
        if (localid2 != null) {
          localObject2[j] = convertToJava(localid2.id);
        }
      }
      return localObject2;
    }
    l1 = OS.objc_lookUpClass("WebUndefined");
    if (localNSObject.isKindOfClass(l1)) {
      return null;
    }
    SWT.error(5);
    return null;
  }
  
  NSObject convertToJS(Object paramObject)
  {
    if (paramObject == null)
    {
      long l = OS.objc_msgSend(OS.class_NSNull, OS.sel_null);
      return l != 0L ? new NSObject(l) : null;
    }
    if ((paramObject instanceof String)) {
      return NSString.stringWith((String)paramObject);
    }
    if ((paramObject instanceof Boolean)) {
      return NSNumber.numberWithBool(((Boolean)paramObject).booleanValue());
    }
    if ((paramObject instanceof Number)) {
      return NSNumber.numberWithDouble(((Number)paramObject).doubleValue());
    }
    if ((paramObject instanceof Object[]))
    {
      Object[] arrayOfObject = (Object[])paramObject;
      int i = arrayOfObject.length;
      NSMutableArray localNSMutableArray = NSMutableArray.arrayWithCapacity(i);
      for (int j = 0; j < i; j++)
      {
        Object localObject = arrayOfObject[j];
        localNSMutableArray.addObject(convertToJS(localObject));
      }
      return localNSMutableArray;
    }
    SWT.error(51);
    return null;
  }
  
  NSObject callJava(long paramLong1, long paramLong2, long paramLong3, long paramLong4)
  {
    Object localObject1 = null;
    NSObject localNSObject = new NSObject(paramLong1);
    long l = OS.objc_lookUpClass("NSNumber");
    if (localNSObject.isKindOfClass(l))
    {
      NSNumber localNSNumber = new NSNumber(paramLong1);
      Integer localInteger = new Integer(localNSNumber.intValue());
      localNSObject = new NSObject(paramLong2);
      l = OS.objc_lookUpClass("NSString");
      if (localNSObject.isKindOfClass(l))
      {
        NSString localNSString = new NSString(paramLong2);
        BrowserFunction localBrowserFunction = (BrowserFunction)this.functions.get(localInteger);
        if ((localBrowserFunction != null) && (localNSString.getString().equals(localBrowserFunction.token))) {
          try
          {
            Object localObject2 = convertToJava(paramLong3);
            if ((localObject2 instanceof Object[]))
            {
              Object[] arrayOfObject = (Object[])localObject2;
              try
              {
                localObject1 = localBrowserFunction.function(arrayOfObject);
              }
              catch (Exception localException)
              {
                localObject1 = WebBrowser.CreateErrorString(localException.getLocalizedMessage());
              }
            }
          }
          catch (IllegalArgumentException localIllegalArgumentException)
          {
            if (localBrowserFunction.isEvaluate) {
              localBrowserFunction.function(new String[] { WebBrowser.CreateErrorString(new SWTException(51).getLocalizedMessage()) });
            }
            localObject1 = WebBrowser.CreateErrorString(localIllegalArgumentException.getLocalizedMessage());
          }
        }
      }
    }
    try
    {
      return convertToJS(localObject1);
    }
    catch (SWTException localSWTException)
    {
      return convertToJS(WebBrowser.CreateErrorString(localSWTException.getLocalizedMessage()));
    }
  }
  
  static
  {
    NativeClearSessions = new Runnable()
    {
      public void run()
      {
        NSHTTPCookieStorage localNSHTTPCookieStorage = NSHTTPCookieStorage.sharedHTTPCookieStorage();
        NSArray localNSArray = localNSHTTPCookieStorage.cookies();
        int i = (int)localNSArray.count();
        for (int j = 0; j < i; j++)
        {
          NSHTTPCookie localNSHTTPCookie = new NSHTTPCookie(localNSArray.objectAtIndex(j));
          if (localNSHTTPCookie.isSessionOnly()) {
            localNSHTTPCookieStorage.deleteCookie(localNSHTTPCookie);
          }
        }
      }
    };
    NativeGetCookie = new Runnable()
    {
      public void run()
      {
        NSHTTPCookieStorage localNSHTTPCookieStorage = NSHTTPCookieStorage.sharedHTTPCookieStorage();
        NSURL localNSURL = NSURL.URLWithString(NSString.stringWith(WebBrowser.CookieUrl));
        NSArray localNSArray = localNSHTTPCookieStorage.cookiesForURL(localNSURL);
        int i = (int)localNSArray.count();
        if (i == 0) {
          return;
        }
        NSString localNSString = NSString.stringWith(WebBrowser.CookieName);
        for (int j = 0; j < i; j++)
        {
          NSHTTPCookie localNSHTTPCookie = new NSHTTPCookie(localNSArray.objectAtIndex(j));
          if (localNSHTTPCookie.name().compare(localNSString) == 0L)
          {
            WebBrowser.CookieValue = localNSHTTPCookie.value().getString();
            return;
          }
        }
      }
    };
    NativeSetCookie = new Runnable()
    {
      public void run()
      {
        NSURL localNSURL = NSURL.URLWithString(NSString.stringWith(WebBrowser.CookieUrl));
        NSMutableDictionary localNSMutableDictionary = NSMutableDictionary.dictionaryWithCapacity(1L);
        localNSMutableDictionary.setValue(NSString.stringWith(WebBrowser.CookieValue), NSString.stringWith("Set-Cookie"));
        NSArray localNSArray = NSHTTPCookie.cookiesWithResponseHeaderFields(localNSMutableDictionary, localNSURL);
        if (localNSArray.count() == 0L) {
          return;
        }
        NSHTTPCookieStorage localNSHTTPCookieStorage = NSHTTPCookieStorage.sharedHTTPCookieStorage();
        NSHTTPCookie localNSHTTPCookie = new NSHTTPCookie(localNSArray.objectAtIndex(0L));
        localNSHTTPCookieStorage.setCookie(localNSHTTPCookie);
        WebBrowser.CookieResult = true;
      }
    };
    if (NativePendingCookies != null) {
      SetPendingCookies(NativePendingCookies);
    }
    NativePendingCookies = null;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/browser/WebKit.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */