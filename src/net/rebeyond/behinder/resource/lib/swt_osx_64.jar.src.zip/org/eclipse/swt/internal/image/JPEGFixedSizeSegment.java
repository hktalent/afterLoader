package org.eclipse.swt.internal.image;

import org.eclipse.swt.SWT;

abstract class JPEGFixedSizeSegment
  extends JPEGSegment
{
  public JPEGFixedSizeSegment()
  {
    this.reference = new byte[fixedSize()];
    setSegmentMarker(signature());
  }
  
  public JPEGFixedSizeSegment(byte[] paramArrayOfByte)
  {
    super(paramArrayOfByte);
  }
  
  public JPEGFixedSizeSegment(LEDataInputStream paramLEDataInputStream)
  {
    this.reference = new byte[fixedSize()];
    try
    {
      paramLEDataInputStream.read(this.reference);
    }
    catch (Exception localException)
    {
      SWT.error(39, localException);
    }
  }
  
  public abstract int fixedSize();
  
  public int getSegmentLength()
  {
    return fixedSize() - 2;
  }
  
  public void setSegmentLength(int paramInt) {}
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/image/JPEGFixedSizeSegment.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */