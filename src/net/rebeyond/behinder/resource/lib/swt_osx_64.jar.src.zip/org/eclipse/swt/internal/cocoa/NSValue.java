package org.eclipse.swt.internal.cocoa;

public class NSValue
  extends NSObject
{
  public NSValue() {}
  
  public NSValue(long paramLong)
  {
    super(paramLong);
  }
  
  public NSValue(id paramid)
  {
    super(paramid);
  }
  
  public long objCType()
  {
    return OS.objc_msgSend(this.id, OS.sel_objCType);
  }
  
  public NSPoint pointValue()
  {
    NSPoint localNSPoint = new NSPoint();
    OS.objc_msgSend_stret(localNSPoint, this.id, OS.sel_pointValue);
    return localNSPoint;
  }
  
  public NSRange rangeValue()
  {
    NSRange localNSRange = new NSRange();
    OS.objc_msgSend_stret(localNSRange, this.id, OS.sel_rangeValue);
    return localNSRange;
  }
  
  public NSRect rectValue()
  {
    NSRect localNSRect = new NSRect();
    OS.objc_msgSend_stret(localNSRect, this.id, OS.sel_rectValue);
    return localNSRect;
  }
  
  public NSSize sizeValue()
  {
    NSSize localNSSize = new NSSize();
    OS.objc_msgSend_stret(localNSSize, this.id, OS.sel_sizeValue);
    return localNSSize;
  }
  
  public static NSValue valueWithPoint(NSPoint paramNSPoint)
  {
    long l = OS.objc_msgSend(OS.class_NSValue, OS.sel_valueWithPoint_, paramNSPoint);
    return l != 0L ? new NSValue(l) : null;
  }
  
  public static NSValue valueWithRange(NSRange paramNSRange)
  {
    long l = OS.objc_msgSend(OS.class_NSValue, OS.sel_valueWithRange_, paramNSRange);
    return l != 0L ? new NSValue(l) : null;
  }
  
  public static NSValue valueWithRect(NSRect paramNSRect)
  {
    long l = OS.objc_msgSend(OS.class_NSValue, OS.sel_valueWithRect_, paramNSRect);
    return l != 0L ? new NSValue(l) : null;
  }
  
  public static NSValue valueWithSize(NSSize paramNSSize)
  {
    long l = OS.objc_msgSend(OS.class_NSValue, OS.sel_valueWithSize_, paramNSSize);
    return l != 0L ? new NSValue(l) : null;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSValue.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */