package org.eclipse.swt.graphics;

import org.eclipse.swt.SWT;
import org.eclipse.swt.internal.C;
import org.eclipse.swt.internal.Callback;
import org.eclipse.swt.internal.Compatibility;
import org.eclipse.swt.internal.cocoa.NSArray;
import org.eclipse.swt.internal.cocoa.NSAttributedString;
import org.eclipse.swt.internal.cocoa.NSAutoreleasePool;
import org.eclipse.swt.internal.cocoa.NSBezierPath;
import org.eclipse.swt.internal.cocoa.NSCell;
import org.eclipse.swt.internal.cocoa.NSColor;
import org.eclipse.swt.internal.cocoa.NSFont;
import org.eclipse.swt.internal.cocoa.NSGraphicsContext;
import org.eclipse.swt.internal.cocoa.NSLayoutManager;
import org.eclipse.swt.internal.cocoa.NSMutableAttributedString;
import org.eclipse.swt.internal.cocoa.NSMutableParagraphStyle;
import org.eclipse.swt.internal.cocoa.NSNumber;
import org.eclipse.swt.internal.cocoa.NSObject;
import org.eclipse.swt.internal.cocoa.NSPoint;
import org.eclipse.swt.internal.cocoa.NSRange;
import org.eclipse.swt.internal.cocoa.NSRect;
import org.eclipse.swt.internal.cocoa.NSSize;
import org.eclipse.swt.internal.cocoa.NSString;
import org.eclipse.swt.internal.cocoa.NSTextAttachment;
import org.eclipse.swt.internal.cocoa.NSTextContainer;
import org.eclipse.swt.internal.cocoa.NSTextStorage;
import org.eclipse.swt.internal.cocoa.NSTextTab;
import org.eclipse.swt.internal.cocoa.NSThread;
import org.eclipse.swt.internal.cocoa.NSTypesetter;
import org.eclipse.swt.internal.cocoa.OS;
import org.eclipse.swt.internal.cocoa.SWTTextAttachmentCell;
import org.eclipse.swt.internal.cocoa.id;

public final class TextLayout
  extends Resource
{
  NSTextStorage textStorage;
  NSLayoutManager layoutManager;
  NSTextContainer textContainer;
  Font font;
  String text = "";
  StyleItem[] styles = new StyleItem[2];
  int stylesCount;
  int spacing;
  int ascent;
  int descent;
  int indent;
  int wrapIndent;
  boolean justify;
  int alignment = 16384;
  int[] tabs;
  int[] segments;
  char[] segmentsChars;
  int wrapWidth = this.ascent = this.descent = -1;
  int orientation = 33554432;
  int[] lineOffsets;
  NSRect[] lineBounds;
  static Callback textLayoutCallback2;
  static final byte[] SWT_OBJECT = { 83, 87, 84, 95, 79, 66, 74, 69, 67, 84, 0 };
  static final int TAB_COUNT = 32;
  static final int UNDERLINE_THICK = 65536;
  static final RGB LINK_FOREGROUND = new RGB(0, 51, 153);
  int[] invalidOffsets;
  static final char LTR_MARK = '‎';
  static final char RTL_MARK = '‏';
  
  public TextLayout(Device paramDevice)
  {
    super(paramDevice);
    this.styles[0] = new StyleItem();
    this.styles[1] = new StyleItem();
    this.stylesCount = 2;
    init();
  }
  
  void checkLayout()
  {
    if (isDisposed()) {
      SWT.error(44);
    }
  }
  
  float[] computePolyline(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    int i = paramInt4 - paramInt2;
    int j = 2 * i;
    int k = Compatibility.ceil(paramInt3 - paramInt1, j);
    if ((k == 0) && (paramInt3 - paramInt1 > 2)) {
      k = 1;
    }
    int m = (2 * k + 1) * 2;
    if (m < 0) {
      return new float[0];
    }
    float[] arrayOfFloat = new float[m];
    for (int n = 0; n < k; n++)
    {
      int i1 = 4 * n;
      arrayOfFloat[i1] = (paramInt1 + j * n);
      arrayOfFloat[(i1 + 1)] = paramInt4;
      arrayOfFloat[(i1 + 2)] = (arrayOfFloat[i1] + j / 2);
      arrayOfFloat[(i1 + 3)] = paramInt2;
    }
    arrayOfFloat[(m - 2)] = (paramInt1 + j * k);
    arrayOfFloat[(m - 1)] = paramInt4;
    return arrayOfFloat;
  }
  
  void computeRuns()
  {
    if (this.lineBounds != null) {
      return;
    }
    String str = getSegmentsText();
    char[] arrayOfChar1 = new char[str.length()];
    str.getChars(0, arrayOfChar1.length, arrayOfChar1, 0);
    NSString localNSString1 = (NSString)new NSString().alloc();
    localNSString1 = localNSString1.initWithCharacters(arrayOfChar1, arrayOfChar1.length);
    NSMutableAttributedString localNSMutableAttributedString = (NSMutableAttributedString)new NSMutableAttributedString().alloc();
    localNSMutableAttributedString.id = localNSMutableAttributedString.initWithString(localNSString1).id;
    localNSString1.release();
    localNSMutableAttributedString.beginEditing();
    Font localFont1 = this.font != null ? this.font : this.device.systemFont;
    NSRange localNSRange = new NSRange();
    localNSRange.length = localNSMutableAttributedString.length();
    localNSMutableAttributedString.addAttribute(OS.NSFontAttributeName, localFont1.handle, localNSRange);
    localNSMutableAttributedString.addAttribute(OS.NSLigatureAttributeName, NSNumber.numberWithInt(0), localNSRange);
    localFont1.addTraits(localNSMutableAttributedString, localNSRange);
    NSMutableParagraphStyle localNSMutableParagraphStyle = (NSMutableParagraphStyle)new NSMutableParagraphStyle().alloc().init();
    int i = 0;
    if (this.wrapWidth != -1) {
      if (this.justify) {
        i = 3;
      } else {
        switch (this.alignment)
        {
        case 16777216: 
          i = 2;
          break;
        case 131072: 
          i = 1;
        }
      }
    }
    if ((this.orientation & 0x4000000) != 0) {
      localNSMutableParagraphStyle.setBaseWritingDirection(1L);
    } else {
      localNSMutableParagraphStyle.setBaseWritingDirection(0L);
    }
    localNSMutableParagraphStyle.setAlignment(i);
    localNSMutableParagraphStyle.setLineSpacing(this.spacing);
    localNSMutableParagraphStyle.setFirstLineHeadIndent(this.indent);
    localNSMutableParagraphStyle.setHeadIndent(this.wrapIndent);
    localNSMutableParagraphStyle.setLineBreakMode(this.wrapWidth != -1 ? 0L : 2L);
    localNSMutableParagraphStyle.setTabStops(NSArray.array());
    Object localObject1;
    if ((this.tabs != null) && (this.tabs.length > 0))
    {
      int j = this.tabs.length;
      if (j == 1)
      {
        localNSMutableParagraphStyle.setDefaultTabInterval(this.tabs[0]);
      }
      else
      {
        m = 0;
        for (int k = 0; k < j; k++)
        {
          m = this.tabs[k];
          NSTextTab localNSTextTab = (NSTextTab)new NSTextTab().alloc();
          localNSTextTab = localNSTextTab.initWithType(0L, m);
          localNSMutableParagraphStyle.addTabStop(localNSTextTab);
          localNSTextTab.release();
        }
        int n = this.tabs[(j - 1)] - this.tabs[(j - 2)];
        while (k < 32)
        {
          m += n;
          localObject1 = (NSTextTab)new NSTextTab().alloc();
          localObject1 = ((NSTextTab)localObject1).initWithType(0L, m);
          localNSMutableParagraphStyle.addTabStop((NSTextTab)localObject1);
          ((NSTextTab)localObject1).release();
          k++;
        }
      }
    }
    localNSMutableAttributedString.addAttribute(OS.NSParagraphStyleAttributeName, localNSMutableParagraphStyle, localNSRange);
    localNSMutableParagraphStyle.release();
    long l1 = localNSMutableAttributedString.length();
    for (int m = 0; m < this.stylesCount - 1; m++)
    {
      StyleItem localStyleItem = this.styles[m];
      if (localStyleItem.style != null)
      {
        localObject1 = localStyleItem.style;
        localNSRange.location = (l1 != 0L ? translateOffset(localStyleItem.start) : 0L);
        localNSRange.length = (translateOffset(this.styles[(m + 1)].start) - localNSRange.location);
        Font localFont2 = ((TextStyle)localObject1).font;
        if (localFont2 != null)
        {
          localNSMutableAttributedString.addAttribute(OS.NSFontAttributeName, localFont2.handle, localNSRange);
          localFont2.addTraits(localNSMutableAttributedString, localNSRange);
        }
        Color localColor = ((TextStyle)localObject1).foreground;
        if (localColor != null)
        {
          localObject2 = NSColor.colorWithDeviceRed(localColor.handle[0], localColor.handle[1], localColor.handle[2], 1.0D);
          localNSMutableAttributedString.addAttribute(OS.NSForegroundColorAttributeName, (id)localObject2, localNSRange);
        }
        Object localObject2 = ((TextStyle)localObject1).background;
        Object localObject3;
        if (localObject2 != null)
        {
          localObject3 = NSColor.colorWithDeviceRed(localObject2.handle[0], localObject2.handle[1], localObject2.handle[2], 1.0D);
          localNSMutableAttributedString.addAttribute(OS.NSBackgroundColorAttributeName, (id)localObject3, localNSRange);
        }
        Object localObject4;
        if (((TextStyle)localObject1).strikeout)
        {
          localNSMutableAttributedString.addAttribute(OS.NSStrikethroughStyleAttributeName, NSNumber.numberWithInt(1), localNSRange);
          localObject3 = ((TextStyle)localObject1).strikeoutColor;
          if (localObject3 != null)
          {
            localObject4 = NSColor.colorWithDeviceRed(localObject3.handle[0], localObject3.handle[1], localObject3.handle[2], 1.0D);
            localNSMutableAttributedString.addAttribute(OS.NSStrikethroughColorAttributeName, (id)localObject4, localNSRange);
          }
        }
        if (isUnderlineSupported((TextStyle)localObject1))
        {
          int i2 = 0;
          switch (((TextStyle)localObject1).underlineStyle)
          {
          case 0: 
            i2 = 1;
            break;
          case 1: 
            i2 = 9;
            break;
          case 65536: 
            i2 = 2;
            break;
          case 4: 
            i2 = 1;
            if (localColor == null)
            {
              localObject4 = NSColor.colorWithDeviceRed(LINK_FOREGROUND.red / 255.0F, LINK_FOREGROUND.green / 255.0F, LINK_FOREGROUND.blue / 255.0F, 1.0D);
              localNSMutableAttributedString.addAttribute(OS.NSForegroundColorAttributeName, (id)localObject4, localNSRange);
            }
            break;
          }
          if (i2 != 0)
          {
            localNSMutableAttributedString.addAttribute(OS.NSUnderlineStyleAttributeName, NSNumber.numberWithInt(i2), localNSRange);
            localObject4 = ((TextStyle)localObject1).underlineColor;
            if (localObject4 != null)
            {
              localObject5 = NSColor.colorWithDeviceRed(localObject4.handle[0], localObject4.handle[1], localObject4.handle[2], 1.0D);
              localNSMutableAttributedString.addAttribute(OS.NSUnderlineColorAttributeName, (id)localObject5, localNSRange);
            }
          }
        }
        if (((TextStyle)localObject1).rise != 0) {
          localNSMutableAttributedString.addAttribute(OS.NSBaselineOffsetAttributeName, NSNumber.numberWithInt(((TextStyle)localObject1).rise), localNSRange);
        }
        if (((TextStyle)localObject1).metrics != null)
        {
          initClasses();
          char[] arrayOfChar2 = new char[(int)localNSRange.length];
          for (int i3 = 0; i3 < arrayOfChar2.length; i3++) {
            arrayOfChar2[i3] = 65532;
          }
          NSString localNSString2 = (NSString)new NSString().alloc();
          localNSString2 = localNSString2.initWithCharacters(arrayOfChar2, arrayOfChar2.length);
          localNSMutableAttributedString.replaceCharactersInRange(localNSRange, localNSString2);
          localNSString2.release();
          localStyleItem.jniRef = OS.NewGlobalRef(localStyleItem);
          if (localStyleItem.jniRef == 0L) {
            SWT.error(2);
          }
          localStyleItem.cell = ((SWTTextAttachmentCell)new SWTTextAttachmentCell().alloc().init());
          OS.object_setInstanceVariable(localStyleItem.cell.id, SWT_OBJECT, localStyleItem.jniRef);
          localObject5 = ((NSTextAttachment)new NSTextAttachment().alloc()).initWithFileWrapper(null);
          ((NSTextAttachment)localObject5).setAttachmentCell(localStyleItem.cell);
          localNSMutableAttributedString.addAttribute(OS.NSAttachmentAttributeName, (id)localObject5, localNSRange);
          ((NSTextAttachment)localObject5).release();
        }
      }
    }
    localNSMutableAttributedString.endEditing();
    NSSize localNSSize = new NSSize();
    localNSSize.width = (this.wrapWidth != -1 ? this.wrapWidth : 5000000.0D);
    localNSSize.height = 5000000.0D;
    if (this.textStorage == null)
    {
      this.textStorage = ((NSTextStorage)new NSTextStorage().alloc().init());
      this.layoutManager = ((NSLayoutManager)new NSLayoutManager().alloc().init());
      this.layoutManager.setBackgroundLayoutEnabled(NSThread.isMainThread());
      this.textContainer = ((NSTextContainer)new NSTextContainer().alloc());
      this.textContainer = this.textContainer.initWithContainerSize(localNSSize);
      this.textContainer.setLineFragmentPadding(0.0D);
      this.textStorage.addLayoutManager(this.layoutManager);
      this.layoutManager.addTextContainer(this.textContainer);
      this.layoutManager.release();
      this.textContainer.release();
    }
    else
    {
      this.textContainer.setContainerSize(localNSSize);
    }
    this.textStorage.setAttributedString(localNSMutableAttributedString);
    localNSMutableAttributedString.release();
    this.layoutManager.glyphRangeForTextContainer(this.textContainer);
    long l2 = this.layoutManager.numberOfGlyphs();
    long l4 = OS.malloc(NSRange.sizeof);
    Object localObject5 = new NSRange();
    int i1 = 0;
    long l3 = 0L;
    while (l3 < l2)
    {
      this.layoutManager.lineFragmentUsedRectForGlyphAtIndex(l3, l4, true);
      OS.memmove((NSRange)localObject5, l4, NSRange.sizeof);
      l3 = ((NSRange)localObject5).location + ((NSRange)localObject5).length;
      i1++;
    }
    if (i1 == 0) {
      i1++;
    }
    int[] arrayOfInt = new int[i1 + 1];
    NSRect[] arrayOfNSRect = new NSRect[i1];
    i1 = 0;
    l3 = 0L;
    while (l3 < l2)
    {
      arrayOfNSRect[i1] = this.layoutManager.lineFragmentUsedRectForGlyphAtIndex(l3, l4, true);
      if (i1 < arrayOfNSRect.length - 1) {
        arrayOfNSRect[i1].height -= this.spacing;
      }
      OS.memmove((NSRange)localObject5, l4, NSRange.sizeof);
      arrayOfInt[i1] = ((int)((NSRange)localObject5).location);
      l3 = ((NSRange)localObject5).location + ((NSRange)localObject5).length;
      i1++;
    }
    if (i1 == 0)
    {
      Font localFont3 = this.font != null ? this.font : this.device.systemFont;
      NSFont localNSFont = localFont3.handle;
      arrayOfNSRect[0] = new NSRect();
      arrayOfNSRect[0].height = Math.max(this.layoutManager.defaultLineHeightForFont(localNSFont), this.ascent + this.descent);
    }
    OS.free(l4);
    arrayOfInt[i1] = ((int)this.textStorage.length());
    this.lineOffsets = arrayOfInt;
    this.lineBounds = arrayOfNSRect;
  }
  
  void destroy()
  {
    freeRuns();
    if (this.textStorage != null) {
      this.textStorage.release();
    }
    this.textStorage = null;
    this.layoutManager = null;
    this.textContainer = null;
    this.font = null;
    this.text = null;
    this.styles = null;
    this.segments = null;
    this.segmentsChars = null;
  }
  
  public void draw(GC paramGC, int paramInt1, int paramInt2)
  {
    draw(paramGC, paramInt1, paramInt2, -1, -1, null, null);
  }
  
  public void draw(GC paramGC, int paramInt1, int paramInt2, int paramInt3, int paramInt4, Color paramColor1, Color paramColor2)
  {
    draw(paramGC, paramInt1, paramInt2, paramInt3, paramInt4, paramColor1, paramColor2, 0);
  }
  
  public void draw(GC paramGC, int paramInt1, int paramInt2, int paramInt3, int paramInt4, Color paramColor1, Color paramColor2, int paramInt5)
  {
    checkLayout();
    if (paramGC == null) {
      SWT.error(4);
    }
    if (paramGC.isDisposed()) {
      SWT.error(5);
    }
    if ((paramColor1 != null) && (paramColor1.isDisposed())) {
      SWT.error(5);
    }
    if ((paramColor2 != null) && (paramColor2.isDisposed())) {
      SWT.error(5);
    }
    NSAutoreleasePool localNSAutoreleasePool = paramGC.checkGC(3073);
    try
    {
      computeRuns();
      int i = translateOffset(this.text.length());
      if ((i == 0) && (paramInt5 == 0)) {
        return;
      }
      paramGC.handle.saveGraphicsState();
      NSPoint localNSPoint1 = new NSPoint();
      localNSPoint1.x = paramInt1;
      localNSPoint1.y = paramInt2;
      NSRange localNSRange = new NSRange();
      long l1 = this.layoutManager.numberOfGlyphs();
      if (l1 > 0L)
      {
        localNSRange.location = 0L;
        localNSRange.length = l1;
        this.layoutManager.drawBackgroundForGlyphRange(localNSRange, localNSPoint1);
      }
      int j = (paramInt3 <= paramInt4) && (paramInt3 != -1) && (paramInt4 != -1) ? 1 : 0;
      Object localObject1;
      Object localObject2;
      int n;
      if ((j != 0) || (((paramInt5 & 0x100000) != 0) && ((paramInt5 & 0x30000) != 0)))
      {
        if (paramColor2 == null) {
          paramColor2 = this.device.getSystemColor(26);
        }
        localObject1 = NSColor.colorWithDeviceRed(paramColor2.handle[0], paramColor2.handle[1], paramColor2.handle[2], paramColor2.handle[3]);
        NSBezierPath localNSBezierPath1 = NSBezierPath.bezierPath();
        NSRect localNSRect1 = new NSRect();
        if (j != 0)
        {
          localNSRange.location = translateOffset(paramInt3);
          localNSRange.length = translateOffset(paramInt4 - paramInt3 + 1);
          localObject2 = new long[1];
          long l2 = this.layoutManager.rectArrayForCharacterRange(localNSRange, localNSRange, this.textContainer, (long[])localObject2);
          n = 0;
          while (n < localObject2[0])
          {
            OS.memmove(localNSRect1, l2, NSRect.sizeof);
            fixRect(localNSRect1);
            localNSRect1.x += localNSPoint1.x;
            localNSRect1.y += localNSPoint1.y;
            localNSRect1.height = Math.max(localNSRect1.height, this.ascent + this.descent);
            localNSBezierPath1.appendBezierPathWithRect(localNSRect1);
            n++;
            l2 += NSRect.sizeof;
          }
        }
        if (((paramInt5 & 0x30000) != 0) && ((paramInt5 & 0x100000) != 0))
        {
          localObject2 = this.lineBounds[(this.lineBounds.length - 1)];
          localNSRect1.x = (localNSPoint1.x + ((NSRect)localObject2).x + ((NSRect)localObject2).width);
          localNSRect1.y = (paramInt2 + ((NSRect)localObject2).y);
          localNSRect1.width = ((paramInt5 & 0x10000) != 0 ? 2.147483647E9D : ((NSRect)localObject2).height / 3.0D);
          localNSRect1.height = Math.max(((NSRect)localObject2).height, this.ascent + this.descent);
          localNSBezierPath1.appendBezierPathWithRect(localNSRect1);
        }
        ((NSColor)localObject1).setFill();
        localNSBezierPath1.fill();
      }
      if (l1 > 0L)
      {
        localNSRange.location = 0L;
        localNSRange.length = l1;
        localObject1 = paramGC.data.foreground;
        int k = (localObject1[0] == 0.0D) && (localObject1[1] == 0.0D) && (localObject1[2] == 0.0D) && (localObject1[3] == 1.0D) && (paramGC.data.alpha == 255) ? 1 : 0;
        if (k == 0) {
          for (int m = 0; m < this.stylesCount - 1; m++)
          {
            localObject2 = this.styles[m];
            if (((((StyleItem)localObject2).style == null) || (((StyleItem)localObject2).style.foreground == null)) && ((((StyleItem)localObject2).style == null) || (!((StyleItem)localObject2).style.underline) || (((StyleItem)localObject2).style.underlineStyle != 4)))
            {
              localNSRange.location = (i != 0 ? translateOffset(((StyleItem)localObject2).start) : 0L);
              localNSRange.length = (translateOffset(this.styles[(m + 1)].start) - localNSRange.location);
              this.layoutManager.addTemporaryAttribute(OS.NSForegroundColorAttributeName, paramGC.data.fg, localNSRange);
            }
          }
        }
        localNSRange.location = 0L;
        localNSRange.length = l1;
        this.layoutManager.drawGlyphsForGlyphRange(localNSRange, localNSPoint1);
        if (k == 0)
        {
          localNSRange.location = 0L;
          localNSRange.length = i;
          this.layoutManager.removeTemporaryAttribute(OS.NSForegroundColorAttributeName, localNSRange);
        }
        NSPoint localNSPoint2 = new NSPoint();
        for (long[] arrayOfLong1 = 0; arrayOfLong1 < this.stylesCount; arrayOfLong1++)
        {
          StyleItem localStyleItem = this.styles[arrayOfLong1];
          TextStyle localTextStyle = localStyleItem.style;
          if (localTextStyle != null)
          {
            n = (localTextStyle.underline) && (!isUnderlineSupported(localTextStyle)) ? 1 : 0;
            n = (n != 0) && ((arrayOfLong1 + 1 == this.stylesCount) || (!localTextStyle.isAdherentUnderline(this.styles[(arrayOfLong1 + 1)].style))) ? 1 : 0;
            int i1 = localTextStyle.borderStyle != 0 ? 1 : 0;
            i1 = (i1 != 0) && ((arrayOfLong1 + 1 == this.stylesCount) || (!localTextStyle.isAdherentBorder(this.styles[(arrayOfLong1 + 1)].style))) ? 1 : 0;
            if ((n != 0) || (i1 != 0))
            {
              int i2 = arrayOfLong1 + 1 < this.stylesCount ? translateOffset(this.styles[(arrayOfLong1 + 1)].start - 1) : i;
              for (int i3 = 0; i3 < this.lineOffsets.length - 1; i3++)
              {
                int i4 = untranslateOffset(this.lineOffsets[i3]);
                int i5 = untranslateOffset(this.lineOffsets[(i3 + 1)] - 1);
                int i6;
                long[] arrayOfLong2;
                long l3;
                NSRect localNSRect2;
                Object localObject3;
                if (n != 0)
                {
                  i6 = localStyleItem.start;
                  for (int i7 = arrayOfLong1; (i7 > 0) && (localTextStyle.isAdherentUnderline(this.styles[(i7 - 1)].style)); i7--) {
                    i6 = this.styles[(i7 - 1)].start;
                  }
                  i6 = translateOffset(i6);
                  if ((i6 <= i5) && (i2 >= i4))
                  {
                    localNSRange.location = Math.max(i4, i6);
                    localNSRange.length = (Math.min(i5, i2) + 1 - localNSRange.location);
                    if (localNSRange.length > 0L)
                    {
                      arrayOfLong2 = new long[1];
                      l3 = this.layoutManager.rectArrayForCharacterRange(localNSRange, localNSRange, this.textContainer, arrayOfLong2);
                      localNSRect2 = new NSRect();
                      paramGC.handle.saveGraphicsState();
                      double d1 = this.layoutManager.typesetter().baselineOffsetInLayoutManager(this.layoutManager, i4);
                      localObject3 = null;
                      if (localTextStyle.underlineColor != null) {
                        localObject3 = localTextStyle.underlineColor.handle;
                      }
                      if ((localObject3 == null) && (localTextStyle.foreground != null)) {
                        localObject3 = localTextStyle.foreground.handle;
                      }
                      if (localObject3 != null) {
                        NSColor.colorWithDeviceRed(localObject3[0], localObject3[1], localObject3[2], localObject3[3]).setStroke();
                      }
                      int i9 = 0;
                      while (i9 < arrayOfLong2[0])
                      {
                        OS.memmove(localNSRect2, l3, NSRect.sizeof);
                        fixRect(localNSRect2);
                        double d2 = localNSPoint1.x + localNSRect2.x;
                        double d3 = localNSPoint1.y + localNSRect2.y + localNSRect2.height - d1 + 1.0D;
                        NSBezierPath localNSBezierPath3 = NSBezierPath.bezierPath();
                        switch (localTextStyle.underlineStyle)
                        {
                        case 2: 
                          localNSBezierPath3.setLineWidth(2.0D);
                          localNSBezierPath3.setLineCapStyle(1L);
                          localNSBezierPath3.setLineJoinStyle(1L);
                          localNSBezierPath3.setLineDash(new double[] { 1.0D, 3.0D }, 2L, 0.0D);
                          localNSPoint2.x = d2;
                          localNSPoint2.y = (d3 + 0.5D);
                          localNSBezierPath3.moveToPoint(localNSPoint2);
                          localNSPoint2.x = (d2 + localNSRect2.width);
                          localNSPoint2.y = (d3 + 0.5D);
                          localNSBezierPath3.lineToPoint(localNSPoint2);
                          break;
                        case 3: 
                          paramGC.handle.setShouldAntialias(false);
                          localNSBezierPath3.setLineWidth(1.0D);
                          localNSBezierPath3.setLineCapStyle(0L);
                          localNSBezierPath3.setLineJoinStyle(0L);
                          double d4 = localNSPoint1.y + localNSRect2.y + localNSRect2.height;
                          float f1 = 1.0F;
                          float f2 = 2.0F * f1;
                          double d5 = Math.min(d3 - f2 / 2.0F, d4 - f2 - 1.0D);
                          float[] arrayOfFloat = computePolyline((int)d2, (int)d5, (int)(d2 + localNSRect2.width), (int)(d5 + f2));
                          localNSPoint2.x = (arrayOfFloat[0] + 0.5F);
                          localNSPoint2.y = (arrayOfFloat[1] + 0.5F);
                          localNSBezierPath3.moveToPoint(localNSPoint2);
                          for (int i11 = 2; i11 < arrayOfFloat.length; i11 += 2)
                          {
                            localNSPoint2.x = (arrayOfFloat[i11] + 0.5F);
                            localNSPoint2.y = (arrayOfFloat[(i11 + 1)] + 0.5F);
                            localNSBezierPath3.lineToPoint(localNSPoint2);
                          }
                          break;
                        }
                        localNSBezierPath3.stroke();
                        i9++;
                        l3 += NSRect.sizeof;
                      }
                      paramGC.handle.restoreGraphicsState();
                    }
                  }
                }
                if (i1 != 0)
                {
                  i6 = localStyleItem.start;
                  for (arrayOfLong2 = arrayOfLong1; (arrayOfLong2 > 0) && (localTextStyle.isAdherentBorder(this.styles[(arrayOfLong2 - 1)].style)); arrayOfLong2--) {
                    i6 = this.styles[(arrayOfLong2 - 1)].start;
                  }
                  i6 = translateOffset(i6);
                  if ((i6 <= i5) && (i2 >= i4))
                  {
                    localNSRange.location = Math.max(i4, i6);
                    localNSRange.length = (Math.min(i5, i2) + 1 - localNSRange.location);
                    if (localNSRange.length > 0L)
                    {
                      arrayOfLong2 = new long[1];
                      l3 = this.layoutManager.rectArrayForCharacterRange(localNSRange, localNSRange, this.textContainer, arrayOfLong2);
                      localNSRect2 = new NSRect();
                      paramGC.handle.saveGraphicsState();
                      double[] arrayOfDouble1 = null;
                      if (localTextStyle.borderColor != null) {
                        arrayOfDouble1 = localTextStyle.borderColor.handle;
                      }
                      if ((arrayOfDouble1 == null) && (localTextStyle.foreground != null)) {
                        arrayOfDouble1 = localTextStyle.foreground.handle;
                      }
                      if (arrayOfDouble1 != null) {
                        NSColor.colorWithDeviceRed(arrayOfDouble1[0], arrayOfDouble1[1], arrayOfDouble1[2], arrayOfDouble1[3]).setStroke();
                      }
                      int i8 = 1;
                      localObject3 = null;
                      switch (localTextStyle.borderStyle)
                      {
                      case 1: 
                        break;
                      case 2: 
                        localObject3 = i8 != 0 ? GC.LINE_DASH : GC.LINE_DASH_ZERO;
                        break;
                      case 4: 
                        localObject3 = i8 != 0 ? GC.LINE_DOT : GC.LINE_DOT_ZERO;
                      }
                      double[] arrayOfDouble2 = null;
                      if (localObject3 != null)
                      {
                        arrayOfDouble2 = new double[localObject3.length];
                        for (i10 = 0; i10 < arrayOfDouble2.length; i10++) {
                          arrayOfDouble2[i10] = (i8 == 0 ? localObject3[i10] : localObject3[i10] * i8);
                        }
                      }
                      int i10 = 0;
                      while (i10 < arrayOfLong2[0])
                      {
                        OS.memmove(localNSRect2, l3, NSRect.sizeof);
                        fixRect(localNSRect2);
                        localNSRect2.x += localNSPoint1.x + 0.5D;
                        localNSRect2.y += localNSPoint1.y + 0.5D;
                        localNSRect2.width -= 0.5D;
                        localNSRect2.height -= 0.5D;
                        NSBezierPath localNSBezierPath2 = NSBezierPath.bezierPath();
                        localNSBezierPath2.setLineDash(arrayOfDouble2, arrayOfDouble2 != null ? arrayOfDouble2.length : 0L, 0.0D);
                        localNSBezierPath2.appendBezierPathWithRect(localNSRect2);
                        localNSBezierPath2.stroke();
                        i10++;
                        l3 += NSRect.sizeof;
                      }
                      paramGC.handle.restoreGraphicsState();
                    }
                  }
                }
              }
            }
          }
        }
      }
      paramGC.handle.restoreGraphicsState();
    }
    finally
    {
      paramGC.uncheckGC(localNSAutoreleasePool);
    }
  }
  
  void fixRect(NSRect paramNSRect)
  {
    double d = -1.0D;
    for (int i = 0; i < this.lineBounds.length; i++)
    {
      NSRect localNSRect = this.lineBounds[i];
      if ((paramNSRect.y <= localNSRect.y) && (localNSRect.y <= paramNSRect.y + paramNSRect.height)) {
        d = Math.max(d, localNSRect.x + localNSRect.width);
      }
    }
    if ((d != -1.0D) && (paramNSRect.x + paramNSRect.width > d)) {
      paramNSRect.width = (d - paramNSRect.x);
    }
  }
  
  void freeRuns()
  {
    this.lineBounds = null;
    this.lineOffsets = null;
    for (int i = 0; i < this.stylesCount - 1; i++)
    {
      StyleItem localStyleItem = this.styles[i];
      if (localStyleItem.cell != null)
      {
        OS.object_setInstanceVariable(localStyleItem.cell.id, SWT_OBJECT, 0L);
        localStyleItem.cell.release();
        localStyleItem.cell = null;
        OS.DeleteGlobalRef(localStyleItem.jniRef);
        localStyleItem.jniRef = 0L;
      }
    }
  }
  
  public int getAlignment()
  {
    checkLayout();
    return this.alignment;
  }
  
  public int getAscent()
  {
    checkLayout();
    return this.ascent;
  }
  
  public Rectangle getBounds()
  {
    checkLayout();
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      computeRuns();
      NSRect localNSRect = this.layoutManager.usedRectForTextContainer(this.textContainer);
      if (this.wrapWidth != -1) {
        localNSRect.width = this.wrapWidth;
      }
      if (this.text.length() == 0)
      {
        localObject1 = this.font != null ? this.font : this.device.systemFont;
        NSFont localNSFont = ((Font)localObject1).handle;
        localNSRect.height = this.layoutManager.defaultLineHeightForFont(localNSFont);
      }
      localNSRect.height = (Math.max(localNSRect.height, this.ascent + this.descent) + this.spacing);
      Object localObject1 = new Rectangle(0, 0, (int)Math.ceil(localNSRect.width), (int)Math.ceil(localNSRect.height));
      return (Rectangle)localObject1;
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  public Rectangle getBounds(int paramInt1, int paramInt2)
  {
    checkLayout();
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      computeRuns();
      int i = this.text.length();
      if (i == 0)
      {
        localObject1 = new Rectangle(0, 0, 0, 0);
        return (Rectangle)localObject1;
      }
      if (paramInt1 > paramInt2)
      {
        localObject1 = new Rectangle(0, 0, 0, 0);
        return (Rectangle)localObject1;
      }
      paramInt1 = Math.min(Math.max(0, paramInt1), i - 1);
      paramInt2 = Math.min(Math.max(0, paramInt2), i - 1);
      paramInt1 = translateOffset(paramInt1);
      paramInt2 = translateOffset(paramInt2);
      Object localObject1 = new NSRange();
      ((NSRange)localObject1).location = paramInt1;
      ((NSRange)localObject1).length = (paramInt2 - paramInt1 + 1);
      long[] arrayOfLong = new long[1];
      long l = this.layoutManager.rectArrayForCharacterRange((NSRange)localObject1, (NSRange)localObject1, this.textContainer, arrayOfLong);
      NSRect localNSRect = new NSRect();
      int j = Integer.MAX_VALUE;
      int k = 0;
      int m = Integer.MAX_VALUE;
      int n = 0;
      int i1 = 0;
      while (i1 < arrayOfLong[0])
      {
        OS.memmove(localNSRect, l, NSRect.sizeof);
        fixRect(localNSRect);
        j = Math.min(j, (int)localNSRect.x);
        k = Math.max(k, (int)Math.ceil(localNSRect.x + localNSRect.width));
        m = Math.min(m, (int)localNSRect.y);
        n = Math.max(n, (int)Math.ceil(localNSRect.y + localNSRect.height));
        i1++;
        l += NSRect.sizeof;
      }
      Rectangle localRectangle = new Rectangle(j, m, k - j, n - m);
      return localRectangle;
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  public int getDescent()
  {
    checkLayout();
    return this.descent;
  }
  
  public Font getFont()
  {
    checkLayout();
    return this.font;
  }
  
  public int getIndent()
  {
    checkLayout();
    return this.indent;
  }
  
  public boolean getJustify()
  {
    checkLayout();
    return this.justify;
  }
  
  public int getLevel(int paramInt)
  {
    checkLayout();
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      computeRuns();
      int i = this.text.length();
      if ((0 > paramInt) || (paramInt > i)) {
        SWT.error(6);
      }
      paramInt = translateOffset(paramInt);
      long l = this.layoutManager.glyphIndexForCharacterAtIndex(paramInt);
      NSRange localNSRange = new NSRange();
      localNSRange.location = l;
      localNSRange.length = 1L;
      byte[] arrayOfByte = new byte[1];
      this.layoutManager.getGlyphsInRange(localNSRange, 0L, 0L, 0L, 0L, arrayOfByte);
      int j = arrayOfByte[0];
      return j;
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  public int[] getLineOffsets()
  {
    checkLayout();
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      computeRuns();
      int[] arrayOfInt1 = new int[this.lineOffsets.length];
      for (int i = 0; i < arrayOfInt1.length; i++) {
        arrayOfInt1[i] = untranslateOffset(this.lineOffsets[i]);
      }
      int[] arrayOfInt2 = arrayOfInt1;
      return arrayOfInt2;
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  public int getLineIndex(int paramInt)
  {
    checkLayout();
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      computeRuns();
      int i = this.text.length();
      if ((0 > paramInt) || (paramInt > i)) {
        SWT.error(6);
      }
      paramInt = translateOffset(paramInt);
      for (int j = 0; j < this.lineOffsets.length - 1; j++) {
        if (this.lineOffsets[(j + 1)] > paramInt)
        {
          int k = j;
          return k;
        }
      }
      j = this.lineBounds.length - 1;
      return j;
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  public Rectangle getLineBounds(int paramInt)
  {
    checkLayout();
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      computeRuns();
      if ((0 > paramInt) || (paramInt >= this.lineBounds.length)) {
        SWT.error(6);
      }
      NSRect localNSRect = this.lineBounds[paramInt];
      int i = Math.max((int)Math.ceil(localNSRect.height), this.ascent + this.descent);
      Rectangle localRectangle = new Rectangle((int)localNSRect.x, (int)localNSRect.y, (int)Math.ceil(localNSRect.width), i);
      return localRectangle;
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  public int getLineCount()
  {
    checkLayout();
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      computeRuns();
      int i = this.lineOffsets.length - 1;
      return i;
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  public FontMetrics getLineMetrics(int paramInt)
  {
    checkLayout();
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      computeRuns();
      int i = getLineCount();
      if ((0 > paramInt) || (paramInt >= i)) {
        SWT.error(6);
      }
      int j = this.text.length();
      if (j == 0)
      {
        localObject1 = this.font != null ? this.font : this.device.systemFont;
        k = (int)this.layoutManager.defaultBaselineOffsetForFont(((Font)localObject1).handle);
        int m = (int)this.layoutManager.defaultLineHeightForFont(((Font)localObject1).handle) - k;
        k = Math.max(k, this.ascent);
        m = Math.max(m, this.descent);
        FontMetrics localFontMetrics2 = FontMetrics.cocoa_new(k, m, 0, 0, k + m);
        return localFontMetrics2;
      }
      Object localObject1 = getLineBounds(paramInt);
      int k = (int)this.layoutManager.typesetter().baselineOffsetInLayoutManager(this.layoutManager, getLineOffsets()[paramInt]);
      FontMetrics localFontMetrics1 = FontMetrics.cocoa_new(((Rectangle)localObject1).height - k, k, 0, 0, ((Rectangle)localObject1).height);
      return localFontMetrics1;
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  public Point getLocation(int paramInt, boolean paramBoolean)
  {
    checkLayout();
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      computeRuns();
      int i = this.text.length();
      if ((0 > paramInt) || (paramInt > i)) {
        SWT.error(6);
      }
      Object localObject1;
      if (i == 0)
      {
        localObject1 = new Point(0, 0);
        return (Point)localObject1;
      }
      if (paramInt == i)
      {
        localObject1 = this.lineBounds[(this.lineBounds.length - 1)];
        Point localPoint = new Point((int)(((NSRect)localObject1).x + ((NSRect)localObject1).width), (int)((NSRect)localObject1).y);
        return localPoint;
      }
      paramInt = translateOffset(paramInt);
      long l1 = this.layoutManager.glyphIndexForCharacterAtIndex(paramInt);
      NSRect localNSRect1 = this.layoutManager.lineFragmentUsedRectForGlyphAtIndex(l1, 0L);
      NSPoint localNSPoint = this.layoutManager.locationForGlyphAtIndex(l1);
      boolean bool = false;
      NSRange localNSRange = new NSRange();
      localNSRange.location = l1;
      localNSRange.length = 1L;
      byte[] arrayOfByte = new byte[1];
      long l2 = this.layoutManager.getGlyphsInRange(localNSRange, 0L, 0L, 0L, 0L, arrayOfByte);
      if (l2 > 0L) {
        bool = (arrayOfByte[0] & 0x1) != 0;
      }
      if (paramBoolean != bool)
      {
        localObject2 = new long[1];
        long l3 = this.layoutManager.rectArrayForGlyphRange(localNSRange, localNSRange, this.textContainer, (long[])localObject2);
        if (localObject2[0] > 0L)
        {
          NSRect localNSRect2 = new NSRect();
          OS.memmove(localNSRect2, l3, NSRect.sizeof);
          fixRect(localNSRect2);
          localNSPoint.x += localNSRect2.width;
        }
      }
      Object localObject2 = new Point((int)localNSPoint.x, (int)localNSRect1.y);
      return (Point)localObject2;
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  public int getNextOffset(int paramInt1, int paramInt2)
  {
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      int i = _getOffset(paramInt1, paramInt2, true);
      return i;
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  int _getOffset(int paramInt1, int paramInt2, boolean paramBoolean)
  {
    checkLayout();
    computeRuns();
    int i = this.text.length();
    if ((0 > paramInt1) || (paramInt1 > i)) {
      SWT.error(6);
    }
    if ((paramBoolean) && (paramInt1 == i)) {
      return i;
    }
    if ((!paramBoolean) && (paramInt1 == 0)) {
      return 0;
    }
    int j = paramBoolean ? 1 : -1;
    if ((paramInt2 & 0x1) != 0) {
      return paramInt1 + j;
    }
    int k;
    int m;
    switch (paramInt2)
    {
    case 2: 
      paramInt1 += j;
      if ((0 <= paramInt1) && (paramInt1 < i))
      {
        k = this.text.charAt(paramInt1);
        if ((56320 <= k) && (k <= 57343) && (paramInt1 > 0))
        {
          k = this.text.charAt(paramInt1 - 1);
          if ((55296 <= k) && (k <= 56319)) {
            paramInt1 += j;
          }
        }
      }
      break;
    case 4: 
      paramInt1 = translateOffset(paramInt1);
      paramInt1 = (int)this.textStorage.nextWordFromIndex(paramInt1, paramBoolean);
      return untranslateOffset(paramInt1);
    case 8: 
      paramInt1 = translateOffset(paramInt1);
      if (paramBoolean)
      {
        paramInt1 = (int)this.textStorage.nextWordFromIndex(paramInt1, true);
      }
      else
      {
        i = translateOffset(i);
        for (k = 0; k < i; k = m)
        {
          m = (int)this.textStorage.nextWordFromIndex(k, true);
          if (m >= paramInt1)
          {
            paramInt1 = k;
            break;
          }
        }
      }
      return untranslateOffset(paramInt1);
    case 16: 
      paramInt1 = translateOffset(paramInt1);
      if (paramBoolean) {
        for (k = translateOffset(i); k > 0; k = m)
        {
          m = (int)this.textStorage.nextWordFromIndex(k, false);
          if (m <= paramInt1)
          {
            paramInt1 = k;
            break;
          }
        }
      } else {
        paramInt1 = (int)this.textStorage.nextWordFromIndex(paramInt1, false);
      }
      return untranslateOffset(paramInt1);
    }
    return paramInt1;
  }
  
  public int getOffset(Point paramPoint, int[] paramArrayOfInt)
  {
    checkLayout();
    if (paramPoint == null) {
      SWT.error(4);
    }
    return getOffset(paramPoint.x, paramPoint.y, paramArrayOfInt);
  }
  
  public int getOffset(int paramInt1, int paramInt2, int[] paramArrayOfInt)
  {
    checkLayout();
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      computeRuns();
      if ((paramArrayOfInt != null) && (paramArrayOfInt.length < 1)) {
        SWT.error(5);
      }
      int i = this.text.length();
      if (i == 0)
      {
        int j = 0;
        return j;
      }
      NSPoint localNSPoint = new NSPoint();
      localNSPoint.x = paramInt1;
      localNSPoint.y = paramInt2;
      double[] arrayOfDouble = new double[1];
      long l = this.layoutManager.glyphIndexForPoint(localNSPoint, this.textContainer, arrayOfDouble);
      int k = (int)this.layoutManager.characterIndexForGlyphAtIndex(l);
      k = Math.min(untranslateOffset(k), i - 1);
      if (paramArrayOfInt != null)
      {
        paramArrayOfInt[0] = Math.round((float)arrayOfDouble[0]);
        if (arrayOfDouble[0] >= 0.5D)
        {
          m = this.text.charAt(k);
          if ((55296 <= m) && (m <= 56319) && (k + 1 < i))
          {
            m = this.text.charAt(k + 1);
            if ((56320 <= m) && (m <= 57343)) {
              paramArrayOfInt[0] += 1;
            }
          }
        }
      }
      int m = k;
      return m;
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  public int getOrientation()
  {
    checkLayout();
    return this.orientation;
  }
  
  public int getPreviousOffset(int paramInt1, int paramInt2)
  {
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      int i = _getOffset(paramInt1, paramInt2, false);
      return i;
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  public int[] getRanges()
  {
    checkLayout();
    Object localObject = new int[this.stylesCount * 2];
    int i = 0;
    for (int j = 0; j < this.stylesCount - 1; j++) {
      if (this.styles[j].style != null)
      {
        localObject[(i++)] = this.styles[j].start;
        localObject[(i++)] = (this.styles[(j + 1)].start - 1);
      }
    }
    if (i != localObject.length)
    {
      int[] arrayOfInt = new int[i];
      System.arraycopy(localObject, 0, arrayOfInt, 0, i);
      localObject = arrayOfInt;
    }
    return (int[])localObject;
  }
  
  public int[] getSegments()
  {
    checkLayout();
    return this.segments;
  }
  
  public char[] getSegmentsChars()
  {
    checkLayout();
    return this.segmentsChars;
  }
  
  String getSegmentsText()
  {
    int i = this.text.length();
    if (i == 0) {
      return this.text;
    }
    if (this.segments == null) {
      return this.text;
    }
    int j = this.segments.length;
    if (j == 0) {
      return this.text;
    }
    if (this.segmentsChars == null)
    {
      if (j == 1) {
        return this.text;
      }
      if ((j == 2) && (this.segments[0] == 0) && (this.segments[1] == i)) {
        return this.text;
      }
    }
    char[] arrayOfChar1 = new char[i];
    this.text.getChars(0, i, arrayOfChar1, 0);
    char[] arrayOfChar2 = new char[i + j];
    int k = 0;
    int m = 0;
    int n = this.orientation == 67108864 ? 8207 : 8206;
    int i1;
    while (k < i) {
      if ((m < j) && (k == this.segments[m]))
      {
        i1 = (this.segmentsChars != null) && (this.segmentsChars.length > m) ? this.segmentsChars[m] : n;
        arrayOfChar2[(k + m++)] = i1;
      }
      else
      {
        arrayOfChar2[(k + m)] = arrayOfChar1[(k++)];
      }
    }
    while (m < j)
    {
      this.segments[m] = k;
      i1 = (this.segmentsChars != null) && (this.segmentsChars.length > m) ? this.segmentsChars[m] : n;
      arrayOfChar2[(k + m++)] = i1;
    }
    return new String(arrayOfChar2, 0, arrayOfChar2.length);
  }
  
  public int getSpacing()
  {
    checkLayout();
    return this.spacing;
  }
  
  public TextStyle getStyle(int paramInt)
  {
    checkLayout();
    int i = this.text.length();
    if ((0 > paramInt) || (paramInt >= i)) {
      SWT.error(6);
    }
    for (int j = 1; j < this.stylesCount; j++)
    {
      StyleItem localStyleItem = this.styles[j];
      if (localStyleItem.start > paramInt) {
        return this.styles[(j - 1)].style;
      }
    }
    return null;
  }
  
  public TextStyle[] getStyles()
  {
    checkLayout();
    Object localObject = new TextStyle[this.stylesCount];
    int i = 0;
    for (int j = 0; j < this.stylesCount; j++) {
      if (this.styles[j].style != null) {
        localObject[(i++)] = this.styles[j].style;
      }
    }
    if (i != localObject.length)
    {
      TextStyle[] arrayOfTextStyle = new TextStyle[i];
      System.arraycopy(localObject, 0, arrayOfTextStyle, 0, i);
      localObject = arrayOfTextStyle;
    }
    return (TextStyle[])localObject;
  }
  
  public int[] getTabs()
  {
    checkLayout();
    return this.tabs;
  }
  
  public String getText()
  {
    checkLayout();
    return this.text;
  }
  
  public int getTextDirection()
  {
    checkLayout();
    return this.orientation;
  }
  
  public int getWidth()
  {
    checkLayout();
    return this.wrapWidth;
  }
  
  public int getWrapIndent()
  {
    checkLayout();
    return this.wrapIndent;
  }
  
  void initClasses()
  {
    String str = "SWTTextAttachmentCell";
    if (OS.objc_lookUpClass(str) != 0L) {
      return;
    }
    textLayoutCallback2 = new Callback(getClass(), "textLayoutProc", 2);
    long l1 = textLayoutCallback2.getAddress();
    if (l1 == 0L) {
      SWT.error(3);
    }
    long l2 = OS.CALLBACK_cellBaselineOffset(l1);
    long l3 = OS.CALLBACK_NSTextAttachmentCell_cellSize(l1);
    byte[] arrayOfByte = { 42, 0 };
    int i = C.PTR_SIZEOF;
    int j = C.PTR_SIZEOF == 4 ? 2 : 3;
    long l4 = OS.objc_allocateClassPair(OS.class_NSCell, str, 0L);
    OS.class_addIvar(l4, SWT_OBJECT, i, (byte)j, arrayOfByte);
    OS.class_addProtocol(l4, OS.protocol_NSTextAttachmentCell);
    OS.class_addMethod(l4, OS.sel_cellSize, l3, "@:");
    OS.class_addMethod(l4, OS.sel_cellBaselineOffset, l2, "@:");
    OS.objc_registerClassPair(l4);
  }
  
  public boolean isDisposed()
  {
    return this.device == null;
  }
  
  boolean isUnderlineSupported(TextStyle paramTextStyle)
  {
    if ((paramTextStyle != null) && (paramTextStyle.underline))
    {
      int i = paramTextStyle.underlineStyle;
      return (i == 0) || (i == 1) || (i == 4) || (i == 65536);
    }
    return false;
  }
  
  public void setAlignment(int paramInt)
  {
    checkLayout();
    int i = 16924672;
    paramInt &= i;
    if (paramInt == 0) {
      return;
    }
    if ((paramInt & 0x4000) != 0) {
      paramInt = 16384;
    }
    if ((paramInt & 0x20000) != 0) {
      paramInt = 131072;
    }
    if (this.alignment == paramInt) {
      return;
    }
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      freeRuns();
      this.alignment = paramInt;
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  public void setAscent(int paramInt)
  {
    checkLayout();
    if (paramInt < -1) {
      SWT.error(5);
    }
    if (this.ascent == paramInt) {
      return;
    }
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      freeRuns();
      this.ascent = paramInt;
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  public void setDescent(int paramInt)
  {
    checkLayout();
    if (paramInt < -1) {
      SWT.error(5);
    }
    if (this.descent == paramInt) {
      return;
    }
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      freeRuns();
      this.descent = paramInt;
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  public void setFont(Font paramFont)
  {
    checkLayout();
    if ((paramFont != null) && (paramFont.isDisposed())) {
      SWT.error(5);
    }
    Font localFont = this.font;
    if (localFont == paramFont) {
      return;
    }
    this.font = paramFont;
    if ((localFont != null) && (localFont.equals(paramFont))) {
      return;
    }
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      freeRuns();
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  public void setIndent(int paramInt)
  {
    checkLayout();
    if (paramInt < 0) {
      return;
    }
    if (this.indent == paramInt) {
      return;
    }
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      freeRuns();
      this.indent = paramInt;
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  public void setWrapIndent(int paramInt)
  {
    checkLayout();
    if (paramInt < 0) {
      return;
    }
    if (this.wrapIndent == paramInt) {
      return;
    }
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      freeRuns();
      this.wrapIndent = paramInt;
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  public void setJustify(boolean paramBoolean)
  {
    checkLayout();
    if (paramBoolean == this.justify) {
      return;
    }
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      freeRuns();
      this.justify = paramBoolean;
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  public void setOrientation(int paramInt)
  {
    checkLayout();
    int i = 100663296;
    paramInt &= i;
    if (paramInt == 0) {
      return;
    }
    if ((paramInt & 0x2000000) != 0) {
      paramInt = 33554432;
    }
    if (this.orientation == paramInt) {
      return;
    }
    this.orientation = paramInt;
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      freeRuns();
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  public void setSegments(int[] paramArrayOfInt)
  {
    checkLayout();
    if ((this.segments == null) && (paramArrayOfInt == null)) {
      return;
    }
    if ((this.segments != null) && (paramArrayOfInt != null) && (this.segments.length == paramArrayOfInt.length))
    {
      for (int i = 0; (i < paramArrayOfInt.length) && (this.segments[i] == paramArrayOfInt[i]); i++) {}
      if (i == paramArrayOfInt.length) {
        return;
      }
    }
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      freeRuns();
      this.segments = paramArrayOfInt;
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  public void setSegmentsChars(char[] paramArrayOfChar)
  {
    checkLayout();
    if ((this.segmentsChars == null) && (paramArrayOfChar == null)) {
      return;
    }
    if ((this.segmentsChars != null) && (paramArrayOfChar != null) && (this.segmentsChars.length == paramArrayOfChar.length))
    {
      for (int i = 0; (i < paramArrayOfChar.length) && (this.segmentsChars[i] == paramArrayOfChar[i]); i++) {}
      if (i == paramArrayOfChar.length) {
        return;
      }
    }
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      freeRuns();
      this.segmentsChars = paramArrayOfChar;
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  public void setSpacing(int paramInt)
  {
    checkLayout();
    if (paramInt < 0) {
      SWT.error(5);
    }
    if (this.spacing == paramInt) {
      return;
    }
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      freeRuns();
      this.spacing = paramInt;
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  public void setStyle(TextStyle paramTextStyle, int paramInt1, int paramInt2)
  {
    checkLayout();
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      int i = this.text.length();
      if (i == 0) {
        return;
      }
      if (paramInt1 > paramInt2) {
        return;
      }
      paramInt1 = Math.min(Math.max(0, paramInt1), i - 1);
      paramInt2 = Math.min(Math.max(0, paramInt2), i - 1);
      int j = -1;
      StyleItem localStyleItem1 = this.stylesCount;
      while (localStyleItem1 - j > 1)
      {
        StyleItem localStyleItem2 = (localStyleItem1 + j) / 2;
        if (this.styles[(localStyleItem2 + 1)].start > paramInt1) {
          localStyleItem1 = localStyleItem2;
        } else {
          j = localStyleItem2;
        }
      }
      if ((0 <= localStyleItem1) && (localStyleItem1 < this.stylesCount))
      {
        localStyleItem3 = this.styles[localStyleItem1];
        if ((localStyleItem3.start == paramInt1) && (this.styles[(localStyleItem1 + 1)].start - 1 == paramInt2)) {
          if (paramTextStyle == null)
          {
            if (localStyleItem3.style != null) {}
          }
          else if (paramTextStyle.equals(localStyleItem3.style)) {
            return;
          }
        }
      }
      freeRuns();
      StyleItem localStyleItem3 = localStyleItem1;
      for (StyleItem localStyleItem4 = localStyleItem3; (localStyleItem4 < this.stylesCount) && (this.styles[(localStyleItem4 + 1)].start <= paramInt2); localStyleItem4++) {}
      int m;
      if (localStyleItem3 == localStyleItem4)
      {
        k = this.styles[localStyleItem3].start;
        m = this.styles[(localStyleItem4 + 1)].start - 1;
        if ((k == paramInt1) && (m == paramInt2))
        {
          this.styles[localStyleItem3].style = paramTextStyle;
          return;
        }
        if ((k != paramInt1) && (m != paramInt2))
        {
          int n = this.stylesCount + 2;
          if (n > this.styles.length)
          {
            int i1 = Math.min(n + 1024, Math.max(64, n * 2));
            StyleItem[] arrayOfStyleItem2 = new StyleItem[i1];
            System.arraycopy(this.styles, 0, arrayOfStyleItem2, 0, this.stylesCount);
            this.styles = arrayOfStyleItem2;
          }
          System.arraycopy(this.styles, localStyleItem4 + 1, this.styles, localStyleItem4 + 3, this.stylesCount - localStyleItem4 - 1);
          StyleItem localStyleItem6 = new StyleItem();
          localStyleItem6.start = paramInt1;
          localStyleItem6.style = paramTextStyle;
          this.styles[(localStyleItem3 + 1)] = localStyleItem6;
          localStyleItem6 = new StyleItem();
          localStyleItem6.start = (paramInt2 + 1);
          localStyleItem6.style = this.styles[localStyleItem3].style;
          this.styles[(localStyleItem3 + 2)] = localStyleItem6;
          this.stylesCount = n;
          return;
        }
      }
      if (paramInt1 == this.styles[localStyleItem3].start) {
        localStyleItem3--;
      }
      if (paramInt2 == this.styles[(localStyleItem4 + 1)].start - 1) {
        localStyleItem4++;
      }
      int k = this.stylesCount + 1 - (localStyleItem4 - localStyleItem3 - 1);
      if (k > this.styles.length)
      {
        m = Math.min(k + 1024, Math.max(64, k * 2));
        StyleItem[] arrayOfStyleItem1 = new StyleItem[m];
        System.arraycopy(this.styles, 0, arrayOfStyleItem1, 0, this.stylesCount);
        this.styles = arrayOfStyleItem1;
      }
      System.arraycopy(this.styles, localStyleItem4, this.styles, localStyleItem3 + 2, this.stylesCount - localStyleItem4);
      StyleItem localStyleItem5 = new StyleItem();
      localStyleItem5.start = paramInt1;
      localStyleItem5.style = paramTextStyle;
      this.styles[(localStyleItem3 + 1)] = localStyleItem5;
      this.styles[(localStyleItem3 + 2)].start = (paramInt2 + 1);
      this.stylesCount = k;
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  public void setTabs(int[] paramArrayOfInt)
  {
    checkLayout();
    if ((this.tabs == null) && (paramArrayOfInt == null)) {
      return;
    }
    if ((this.tabs != null) && (paramArrayOfInt != null) && (this.tabs.length == paramArrayOfInt.length))
    {
      for (int i = 0; (i < paramArrayOfInt.length) && (this.tabs[i] == paramArrayOfInt[i]); i++) {}
      if (i == paramArrayOfInt.length) {
        return;
      }
    }
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      freeRuns();
      this.tabs = paramArrayOfInt;
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  public void setText(String paramString)
  {
    checkLayout();
    if (paramString == null) {
      SWT.error(4);
    }
    if (paramString.equals(this.text)) {
      return;
    }
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      freeRuns();
      this.text = paramString;
      this.styles = new StyleItem[2];
      this.styles[0] = new StyleItem();
      this.styles[1] = new StyleItem();
      this.styles[1].start = paramString.length();
      this.stylesCount = 2;
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  public void setTextDirection(int paramInt)
  {
    checkLayout();
  }
  
  public void setWidth(int paramInt)
  {
    checkLayout();
    if ((paramInt < -1) || (paramInt == 0)) {
      SWT.error(5);
    }
    if (this.wrapWidth == paramInt) {
      return;
    }
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      freeRuns();
      this.wrapWidth = paramInt;
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  public String toString()
  {
    if (isDisposed()) {
      return "TextLayout {*DISPOSED*}";
    }
    return "TextLayout {" + this.text + "}";
  }
  
  static long textLayoutProc(long paramLong1, long paramLong2)
  {
    long[] arrayOfLong = new long[1];
    OS.object_getInstanceVariable(paramLong1, SWT_OBJECT, arrayOfLong);
    if (arrayOfLong[0] == 0L) {
      return 0L;
    }
    StyleItem localStyleItem = (StyleItem)OS.JNIGetObject(arrayOfLong[0]);
    if (localStyleItem == null) {
      return 0L;
    }
    TextStyle localTextStyle = localStyleItem.style;
    if (localTextStyle == null) {
      return 0L;
    }
    GlyphMetrics localGlyphMetrics = localTextStyle.metrics;
    if (localGlyphMetrics == null) {
      return 0L;
    }
    Object localObject;
    long l;
    if (paramLong2 == OS.sel_cellSize)
    {
      localObject = new NSSize();
      ((NSSize)localObject).width = localGlyphMetrics.width;
      ((NSSize)localObject).height = (localGlyphMetrics.ascent + localGlyphMetrics.descent);
      l = OS.malloc(NSSize.sizeof);
      OS.memmove(l, (NSSize)localObject, NSSize.sizeof);
      return l;
    }
    if (paramLong2 == OS.sel_cellBaselineOffset)
    {
      localObject = new NSPoint();
      ((NSPoint)localObject).y = (-localGlyphMetrics.descent);
      l = OS.malloc(NSPoint.sizeof);
      OS.memmove(l, (NSPoint)localObject, NSPoint.sizeof);
      return l;
    }
    return 0L;
  }
  
  int translateOffset(int paramInt)
  {
    int i = this.text.length();
    if (i == 0) {
      return paramInt;
    }
    if (this.segments == null) {
      return paramInt;
    }
    int j = this.segments.length;
    if (j == 0) {
      return paramInt;
    }
    if (this.segmentsChars == null)
    {
      if (j == 1) {
        return paramInt;
      }
      if ((j == 2) && (this.segments[0] == 0) && (this.segments[1] == i)) {
        return paramInt;
      }
    }
    for (int k = 0; (k < j) && (paramInt - k >= this.segments[k]); k++) {
      paramInt++;
    }
    return paramInt;
  }
  
  int untranslateOffset(int paramInt)
  {
    int i = this.text.length();
    if (i == 0) {
      return paramInt;
    }
    if (this.segments == null) {
      return paramInt;
    }
    int j = this.segments.length;
    if (j == 0) {
      return paramInt;
    }
    if (this.segmentsChars == null)
    {
      if (j == 1) {
        return paramInt;
      }
      if ((j == 2) && (this.segments[0] == 0) && (this.segments[1] == i)) {
        return paramInt;
      }
    }
    for (int k = 0; (k < j) && (paramInt > this.segments[k]); k++) {
      paramInt--;
    }
    return paramInt;
  }
  
  static class StyleItem
  {
    TextStyle style;
    int start;
    long jniRef;
    NSCell cell;
    
    public String toString()
    {
      return "StyleItem {" + this.start + ", " + this.style + "}";
    }
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/graphics/TextLayout.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */