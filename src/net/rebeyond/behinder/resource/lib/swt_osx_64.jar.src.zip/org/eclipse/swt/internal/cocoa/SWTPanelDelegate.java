package org.eclipse.swt.internal.cocoa;

public class SWTPanelDelegate
  extends NSObject
{
  public SWTPanelDelegate()
  {
    super(0L);
  }
  
  public SWTPanelDelegate(long paramLong)
  {
    super(paramLong);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/SWTPanelDelegate.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */