package org.eclipse.swt.internal.cocoa;

public class NSClipView
  extends NSView
{
  public NSClipView() {}
  
  public NSClipView(long paramLong)
  {
    super(paramLong);
  }
  
  public NSClipView(id paramid)
  {
    super(paramid);
  }
  
  public boolean copiesOnScroll()
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_copiesOnScroll);
  }
  
  public NSCursor documentCursor()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_documentCursor);
    return l != 0L ? new NSCursor(l) : null;
  }
  
  public void scrollToPoint(NSPoint paramNSPoint)
  {
    OS.objc_msgSend(this.id, OS.sel_scrollToPoint_, paramNSPoint);
  }
  
  public void setCopiesOnScroll(boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_setCopiesOnScroll_, paramBoolean);
  }
  
  public void setDocumentCursor(NSCursor paramNSCursor)
  {
    OS.objc_msgSend(this.id, OS.sel_setDocumentCursor_, paramNSCursor != null ? paramNSCursor.id : 0L);
  }
  
  public void setDrawsBackground(boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_setDrawsBackground_, paramBoolean);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSClipView.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */