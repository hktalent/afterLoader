package org.eclipse.swt.internal.cocoa;

public class NSTableHeaderCell
  extends NSTextFieldCell
{
  public NSTableHeaderCell() {}
  
  public NSTableHeaderCell(long paramLong)
  {
    super(paramLong);
  }
  
  public NSTableHeaderCell(id paramid)
  {
    super(paramid);
  }
  
  public void drawSortIndicatorWithFrame(NSRect paramNSRect, NSView paramNSView, boolean paramBoolean, long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_drawSortIndicatorWithFrame_inView_ascending_priority_, paramNSRect, paramNSView != null ? paramNSView.id : 0L, paramBoolean, paramLong);
  }
  
  public NSRect sortIndicatorRectForBounds(NSRect paramNSRect)
  {
    NSRect localNSRect = new NSRect();
    OS.objc_msgSend_stret(localNSRect, this.id, OS.sel_sortIndicatorRectForBounds_, paramNSRect);
    return localNSRect;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSTableHeaderCell.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */