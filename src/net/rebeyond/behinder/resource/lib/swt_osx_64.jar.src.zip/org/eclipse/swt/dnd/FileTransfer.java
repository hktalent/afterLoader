package org.eclipse.swt.dnd;

import org.eclipse.swt.internal.cocoa.NSArray;
import org.eclipse.swt.internal.cocoa.NSMutableArray;
import org.eclipse.swt.internal.cocoa.NSString;
import org.eclipse.swt.internal.cocoa.OS;

public class FileTransfer
  extends ByteArrayTransfer
{
  static FileTransfer _instance = new FileTransfer();
  static final String ID_NAME = OS.NSFilenamesPboardType.getString();
  static final int ID = registerType(ID_NAME);
  static final String ID1_NAME = OS.kUTTypeFileURL.getString();
  static final int ID1 = registerType(ID1_NAME);
  
  public static FileTransfer getInstance()
  {
    return _instance;
  }
  
  public void javaToNative(Object paramObject, TransferData paramTransferData)
  {
    if ((!checkFile(paramObject)) || (!isSupportedType(paramTransferData))) {
      DND.error(2003);
    }
    String[] arrayOfString = (String[])paramObject;
    int i = arrayOfString.length;
    NSMutableArray localNSMutableArray = NSMutableArray.arrayWithCapacity(i);
    for (int j = 0; j < i; j++)
    {
      String str = arrayOfString[j];
      NSString localNSString = NSString.stringWith(str);
      localNSMutableArray.addObject(localNSString);
    }
    paramTransferData.data = localNSMutableArray;
  }
  
  public Object nativeToJava(TransferData paramTransferData)
  {
    if ((!isSupportedType(paramTransferData)) || (paramTransferData.data == null)) {
      return null;
    }
    NSArray localNSArray = (NSArray)paramTransferData.data;
    if (localNSArray.count() == 0L) {
      return null;
    }
    int i = (int)localNSArray.count();
    String[] arrayOfString = new String[i];
    for (int j = 0; j < i; j++)
    {
      NSString localNSString = new NSString(localNSArray.objectAtIndex(j));
      arrayOfString[j] = localNSString.getString();
    }
    return arrayOfString;
  }
  
  protected int[] getTypeIds()
  {
    if (OS.VERSION >= 4192) {
      return new int[] { ID, ID1 };
    }
    return new int[] { ID };
  }
  
  protected String[] getTypeNames()
  {
    if (OS.VERSION >= 4192) {
      return new String[] { ID_NAME, ID1_NAME };
    }
    return new String[] { ID_NAME };
  }
  
  boolean checkFile(Object paramObject)
  {
    if ((paramObject == null) || (!(paramObject instanceof String[])) || (((String[])paramObject).length == 0)) {
      return false;
    }
    String[] arrayOfString = (String[])paramObject;
    for (int i = 0; i < arrayOfString.length; i++) {
      if ((arrayOfString[i] == null) || (arrayOfString[i].length() == 0)) {
        return false;
      }
    }
    return true;
  }
  
  protected boolean validate(Object paramObject)
  {
    return checkFile(paramObject);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/dnd/FileTransfer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */