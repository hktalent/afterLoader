package org.eclipse.swt.graphics;

import org.eclipse.swt.SWT;
import org.eclipse.swt.internal.cocoa.NSAffineTransform;
import org.eclipse.swt.internal.cocoa.NSAttributedString;
import org.eclipse.swt.internal.cocoa.NSAutoreleasePool;
import org.eclipse.swt.internal.cocoa.NSBezierPath;
import org.eclipse.swt.internal.cocoa.NSFont;
import org.eclipse.swt.internal.cocoa.NSLayoutManager;
import org.eclipse.swt.internal.cocoa.NSMutableAttributedString;
import org.eclipse.swt.internal.cocoa.NSObject;
import org.eclipse.swt.internal.cocoa.NSPoint;
import org.eclipse.swt.internal.cocoa.NSRange;
import org.eclipse.swt.internal.cocoa.NSRect;
import org.eclipse.swt.internal.cocoa.NSSize;
import org.eclipse.swt.internal.cocoa.NSString;
import org.eclipse.swt.internal.cocoa.NSTextContainer;
import org.eclipse.swt.internal.cocoa.NSTextStorage;
import org.eclipse.swt.internal.cocoa.NSThread;
import org.eclipse.swt.internal.cocoa.OS;
import org.eclipse.swt.internal.cocoa.id;

public class Path
  extends Resource
{
  public NSBezierPath handle;
  boolean closed = true;
  
  public Path(Device paramDevice)
  {
    super(paramDevice);
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      this.handle = NSBezierPath.bezierPath();
      if (this.handle == null) {
        SWT.error(2);
      }
      this.handle.retain();
      this.handle.moveToPoint(new NSPoint());
      init();
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  public Path(Device paramDevice, Path paramPath, float paramFloat)
  {
    super(paramDevice);
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      if (paramPath == null) {
        SWT.error(4);
      }
      if (paramPath.isDisposed()) {
        SWT.error(5);
      }
      paramFloat = Math.max(0.0F, paramFloat);
      if (paramFloat == 0.0F)
      {
        this.handle = new NSBezierPath(paramPath.handle.copy().id);
      }
      else
      {
        double d = NSBezierPath.defaultFlatness();
        NSBezierPath.setDefaultFlatness(paramFloat);
        this.handle = paramPath.handle.bezierPathByFlatteningPath();
        this.handle.retain();
        NSBezierPath.setDefaultFlatness(d);
      }
      if (this.handle == null) {
        SWT.error(2);
      }
      init();
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  public Path(Device paramDevice, PathData paramPathData)
  {
    this(paramDevice);
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      if (paramPathData == null) {
        SWT.error(4);
      }
      init(paramPathData);
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  public void addArc(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6)
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      NSAffineTransform localNSAffineTransform = NSAffineTransform.transform();
      localNSAffineTransform.translateXBy(paramFloat1 + paramFloat3 / 2.0F, paramFloat2 + paramFloat4 / 2.0F);
      localNSAffineTransform.scaleXBy(paramFloat3 / 2.0F, paramFloat4 / 2.0F);
      NSBezierPath localNSBezierPath = NSBezierPath.bezierPath();
      NSPoint localNSPoint = new NSPoint();
      float f1 = -paramFloat5;
      float f2 = -(paramFloat5 + paramFloat6);
      localNSBezierPath.appendBezierPathWithArcWithCenter(localNSPoint, 1.0D, f1, f2, paramFloat6 > 0.0F);
      localNSBezierPath.transformUsingAffineTransform(localNSAffineTransform);
      appendBezierPath(localNSBezierPath);
      if ((this.closed = Math.abs(paramFloat6) >= 360.0F ? 1 : 0) != 0) {
        this.handle.closePath();
      }
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  void appendBezierPath(NSBezierPath paramNSBezierPath)
  {
    int i = (int)paramNSBezierPath.elementCount();
    long l = OS.malloc(3 * NSPoint.sizeof);
    if (l == 0L) {
      SWT.error(2);
    }
    NSPoint localNSPoint1 = new NSPoint();
    NSPoint localNSPoint2 = new NSPoint();
    NSPoint localNSPoint3 = new NSPoint();
    for (int j = 0; j < i; j++)
    {
      int k = (int)paramNSBezierPath.elementAtIndex(j, l);
      switch (k)
      {
      case 0: 
        OS.memmove(localNSPoint1, l, NSPoint.sizeof);
        if (this.closed) {
          this.handle.moveToPoint(localNSPoint1);
        } else {
          this.handle.lineToPoint(localNSPoint1);
        }
        break;
      case 1: 
        OS.memmove(localNSPoint1, l, NSPoint.sizeof);
        this.handle.lineToPoint(localNSPoint1);
        this.closed = false;
        break;
      case 2: 
        OS.memmove(localNSPoint1, l, NSPoint.sizeof);
        OS.memmove(localNSPoint2, l + NSPoint.sizeof, NSPoint.sizeof);
        OS.memmove(localNSPoint3, l + NSPoint.sizeof + NSPoint.sizeof, NSPoint.sizeof);
        this.handle.curveToPoint(localNSPoint3, localNSPoint1, localNSPoint2);
        this.closed = false;
        break;
      case 3: 
        this.handle.closePath();
        this.closed = true;
      }
    }
    OS.free(l);
  }
  
  public void addPath(Path paramPath)
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    if (paramPath == null) {
      SWT.error(4);
    }
    if (paramPath.isDisposed()) {
      SWT.error(5);
    }
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      this.handle.appendBezierPath(paramPath.handle);
      this.closed = paramPath.closed;
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  public void addRectangle(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4)
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    NSRect localNSRect = new NSRect();
    localNSRect.x = paramFloat1;
    localNSRect.y = paramFloat2;
    localNSRect.width = paramFloat3;
    localNSRect.height = paramFloat4;
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      this.handle.appendBezierPathWithRect(localNSRect);
      this.closed = true;
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  public void addString(String paramString, float paramFloat1, float paramFloat2, Font paramFont)
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    if (paramFont == null) {
      SWT.error(4);
    }
    if (paramFont.isDisposed()) {
      SWT.error(5);
    }
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      this.closed = true;
      NSString localNSString = NSString.stringWith(paramString);
      NSTextStorage localNSTextStorage = (NSTextStorage)new NSTextStorage().alloc().init();
      NSLayoutManager localNSLayoutManager = (NSLayoutManager)new NSLayoutManager().alloc().init();
      NSTextContainer localNSTextContainer = (NSTextContainer)new NSTextContainer().alloc();
      NSSize localNSSize = new NSSize();
      localNSSize.width = 5000000.0D;
      localNSSize.height = 5000000.0D;
      localNSTextContainer.initWithContainerSize(localNSSize);
      localNSTextContainer.setLineFragmentPadding(0.0D);
      localNSTextStorage.addLayoutManager(localNSLayoutManager);
      localNSLayoutManager.addTextContainer(localNSTextContainer);
      NSRange localNSRange = new NSRange();
      localNSRange.length = localNSString.length();
      NSMutableAttributedString localNSMutableAttributedString = (NSMutableAttributedString)new NSMutableAttributedString().alloc();
      localNSMutableAttributedString.id = localNSMutableAttributedString.initWithString(localNSString).id;
      localNSMutableAttributedString.beginEditing();
      localNSMutableAttributedString.addAttribute(OS.NSFontAttributeName, paramFont.handle, localNSRange);
      paramFont.addTraits(localNSMutableAttributedString, localNSRange);
      localNSMutableAttributedString.endEditing();
      localNSTextStorage.setAttributedString(localNSMutableAttributedString);
      localNSMutableAttributedString.release();
      localNSRange = localNSLayoutManager.glyphRangeForTextContainer(localNSTextContainer);
      if (localNSRange.length != 0L)
      {
        long l1 = OS.malloc((localNSRange.length + 1L) * 4L);
        long l2 = localNSLayoutManager.getGlyphs(l1, localNSRange);
        NSBezierPath localNSBezierPath = NSBezierPath.bezierPath();
        for (int i = 0; i < l2; i++)
        {
          NSPoint localNSPoint = localNSLayoutManager.locationForGlyphAtIndex(i);
          NSRect localNSRect = localNSLayoutManager.lineFragmentUsedRectForGlyphAtIndex(i, 0L);
          NSFont localNSFont = new NSFont(localNSTextStorage.attribute(OS.NSFontAttributeName, localNSLayoutManager.characterIndexForGlyphAtIndex(i), 0L));
          localNSPoint.x = (localNSPoint.x + paramFloat1 + localNSRect.x);
          localNSPoint.y = (-localNSPoint.y - paramFloat2 - localNSRect.y);
          localNSBezierPath.moveToPoint(localNSPoint);
          localNSBezierPath.appendBezierPathWithGlyphs(l1 + i * 4, 1L, localNSFont);
        }
        OS.free(l1);
        NSAffineTransform localNSAffineTransform = NSAffineTransform.transform();
        localNSAffineTransform.scaleXBy(1.0D, -1.0D);
        localNSBezierPath.transformUsingAffineTransform(localNSAffineTransform);
        this.handle.appendBezierPath(localNSBezierPath);
      }
      localNSTextContainer.release();
      localNSLayoutManager.release();
      localNSTextStorage.release();
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  public void close()
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      this.handle.closePath();
      this.closed = true;
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  public boolean contains(float paramFloat1, float paramFloat2, GC paramGC, boolean paramBoolean)
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    if (paramGC == null) {
      SWT.error(4);
    }
    if (paramGC.isDisposed()) {
      SWT.error(5);
    }
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      if (paramBoolean)
      {
        long l1 = OS.malloc(4L);
        if (l1 == 0L) {
          SWT.error(2);
        }
        int[] arrayOfInt = { -1 };
        OS.memmove(l1, arrayOfInt, 4L);
        long l2 = OS.CGColorSpaceCreateDeviceRGB();
        long l3 = OS.CGBitmapContextCreate(l1, 1L, 1L, 8L, 4L, l2, 6);
        OS.CGColorSpaceRelease(l2);
        if (l3 == 0L)
        {
          OS.free(l1);
          SWT.error(2);
        }
        GCData localGCData = paramGC.data;
        int i = 0;
        switch (localGCData.lineCap)
        {
        case 2: 
          i = 1;
          break;
        case 1: 
          i = 0;
          break;
        case 3: 
          i = 2;
        }
        OS.CGContextSetLineCap(l3, i);
        int j = 0;
        switch (localGCData.lineJoin)
        {
        case 1: 
          j = 0;
          break;
        case 2: 
          j = 1;
          break;
        case 3: 
          j = 2;
        }
        OS.CGContextSetLineJoin(l3, j);
        OS.CGContextSetLineWidth(l3, localGCData.lineWidth);
        OS.CGContextTranslateCTM(l3, -paramFloat1 + 0.5F, -paramFloat2 + 0.5F);
        long l4 = GC.createCGPathRef(this.handle);
        OS.CGContextAddPath(l3, l4);
        OS.CGPathRelease(l4);
        OS.CGContextStrokePath(l3);
        OS.CGContextRelease(l3);
        OS.memmove(arrayOfInt, l1, 4L);
        OS.free(l1);
        boolean bool2 = arrayOfInt[0] != -1;
        return bool2;
      }
      NSPoint localNSPoint = new NSPoint();
      localNSPoint.x = paramFloat1;
      localNSPoint.y = paramFloat2;
      boolean bool1 = this.handle.containsPoint(localNSPoint);
      return bool1;
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  public void cubicTo(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6)
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      NSPoint localNSPoint1 = new NSPoint();
      localNSPoint1.x = paramFloat5;
      localNSPoint1.y = paramFloat6;
      NSPoint localNSPoint2 = new NSPoint();
      localNSPoint2.x = paramFloat1;
      localNSPoint2.y = paramFloat2;
      NSPoint localNSPoint3 = new NSPoint();
      localNSPoint3.x = paramFloat3;
      localNSPoint3.y = paramFloat4;
      this.handle.curveToPoint(localNSPoint1, localNSPoint2, localNSPoint3);
      this.closed = false;
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  void destroy()
  {
    this.handle.release();
    this.handle = null;
  }
  
  public void getBounds(float[] paramArrayOfFloat)
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    if (paramArrayOfFloat == null) {
      SWT.error(4);
    }
    if (paramArrayOfFloat.length < 4) {
      SWT.error(5);
    }
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      NSRect localNSRect = this.handle.controlPointBounds();
      paramArrayOfFloat[0] = ((float)localNSRect.x);
      paramArrayOfFloat[1] = ((float)localNSRect.y);
      paramArrayOfFloat[2] = ((float)localNSRect.width);
      paramArrayOfFloat[3] = ((float)localNSRect.height);
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  public void getCurrentPoint(float[] paramArrayOfFloat)
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    if (paramArrayOfFloat == null) {
      SWT.error(4);
    }
    if (paramArrayOfFloat.length < 2) {
      SWT.error(5);
    }
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      NSPoint localNSPoint = this.handle.currentPoint();
      paramArrayOfFloat[0] = ((float)localNSPoint.x);
      paramArrayOfFloat[1] = ((float)localNSPoint.y);
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  public PathData getPathData()
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      int i = (int)this.handle.elementCount();
      int j = 0;
      int k = 0;
      byte[] arrayOfByte = new byte[i];
      Object localObject1 = new float[i * 6];
      long l = OS.malloc(3 * NSPoint.sizeof);
      if (l == 0L) {
        SWT.error(2);
      }
      NSPoint localNSPoint = new NSPoint();
      for (int m = 0; m < i; m++)
      {
        int n = (int)this.handle.elementAtIndex(m, l);
        switch (n)
        {
        case 0: 
          arrayOfByte[(k++)] = 1;
          OS.memmove(localNSPoint, l, NSPoint.sizeof);
          localObject1[(j++)] = ((float)localNSPoint.x);
          localObject1[(j++)] = ((float)localNSPoint.y);
          break;
        case 1: 
          arrayOfByte[(k++)] = 2;
          OS.memmove(localNSPoint, l, NSPoint.sizeof);
          localObject1[(j++)] = ((float)localNSPoint.x);
          localObject1[(j++)] = ((float)localNSPoint.y);
          break;
        case 2: 
          arrayOfByte[(k++)] = 4;
          OS.memmove(localNSPoint, l, NSPoint.sizeof);
          localObject1[(j++)] = ((float)localNSPoint.x);
          localObject1[(j++)] = ((float)localNSPoint.y);
          OS.memmove(localNSPoint, l + NSPoint.sizeof, NSPoint.sizeof);
          localObject1[(j++)] = ((float)localNSPoint.x);
          localObject1[(j++)] = ((float)localNSPoint.y);
          OS.memmove(localNSPoint, l + NSPoint.sizeof + NSPoint.sizeof, NSPoint.sizeof);
          localObject1[(j++)] = ((float)localNSPoint.x);
          localObject1[(j++)] = ((float)localNSPoint.y);
          break;
        case 3: 
          arrayOfByte[(k++)] = 5;
        }
      }
      OS.free(l);
      if (j != localObject1.length)
      {
        localObject2 = new float[j];
        System.arraycopy(localObject1, 0, localObject2, 0, j);
        localObject1 = localObject2;
      }
      Object localObject2 = new PathData();
      ((PathData)localObject2).types = arrayOfByte;
      ((PathData)localObject2).points = ((float[])localObject1);
      Object localObject3 = localObject2;
      return (PathData)localObject3;
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  void init(PathData paramPathData)
  {
    byte[] arrayOfByte = paramPathData.types;
    float[] arrayOfFloat = paramPathData.points;
    int i = 0;
    int j = 0;
    while (i < arrayOfByte.length)
    {
      switch (arrayOfByte[i])
      {
      case 1: 
        moveTo(arrayOfFloat[(j++)], arrayOfFloat[(j++)]);
        break;
      case 2: 
        lineTo(arrayOfFloat[(j++)], arrayOfFloat[(j++)]);
        break;
      case 4: 
        cubicTo(arrayOfFloat[(j++)], arrayOfFloat[(j++)], arrayOfFloat[(j++)], arrayOfFloat[(j++)], arrayOfFloat[(j++)], arrayOfFloat[(j++)]);
        break;
      case 3: 
        quadTo(arrayOfFloat[(j++)], arrayOfFloat[(j++)], arrayOfFloat[(j++)], arrayOfFloat[(j++)]);
        break;
      case 5: 
        close();
        break;
      default: 
        dispose();
        SWT.error(5);
      }
      i++;
    }
  }
  
  public boolean isDisposed()
  {
    return this.handle == null;
  }
  
  public void lineTo(float paramFloat1, float paramFloat2)
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      NSPoint localNSPoint = new NSPoint();
      localNSPoint.x = paramFloat1;
      localNSPoint.y = paramFloat2;
      this.handle.lineToPoint(localNSPoint);
      this.closed = false;
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  public void moveTo(float paramFloat1, float paramFloat2)
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      NSPoint localNSPoint = new NSPoint();
      localNSPoint.x = paramFloat1;
      localNSPoint.y = paramFloat2;
      this.handle.moveToPoint(localNSPoint);
      this.closed = true;
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  public void quadTo(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4)
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      NSPoint localNSPoint1 = this.handle.isEmpty() ? new NSPoint() : this.handle.currentPoint();
      NSPoint localNSPoint2 = new NSPoint();
      localNSPoint1.x += 2.0D * (paramFloat1 - localNSPoint1.x) / 3.0D;
      localNSPoint1.y += 2.0D * (paramFloat2 - localNSPoint1.y) / 3.0D;
      NSPoint localNSPoint3 = new NSPoint();
      localNSPoint2.x += (paramFloat3 - localNSPoint1.x) / 3.0D;
      localNSPoint2.y += (paramFloat4 - localNSPoint1.y) / 3.0D;
      NSPoint localNSPoint4 = new NSPoint();
      localNSPoint4.x = paramFloat3;
      localNSPoint4.y = paramFloat4;
      this.handle.curveToPoint(localNSPoint4, localNSPoint2, localNSPoint3);
      this.closed = false;
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  public String toString()
  {
    if (isDisposed()) {
      return "Path {*DISPOSED*}";
    }
    return "Path {" + this.handle + "}";
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/graphics/Path.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */