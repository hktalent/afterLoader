package org.eclipse.swt.internal.cocoa;

public class NSTypesetter
  extends NSObject
{
  public NSTypesetter() {}
  
  public NSTypesetter(long paramLong)
  {
    super(paramLong);
  }
  
  public NSTypesetter(id paramid)
  {
    super(paramid);
  }
  
  public double baselineOffsetInLayoutManager(NSLayoutManager paramNSLayoutManager, long paramLong)
  {
    return OS.objc_msgSend_fpret(this.id, OS.sel_baselineOffsetInLayoutManager_glyphIndex_, paramNSLayoutManager != null ? paramNSLayoutManager.id : 0L, paramLong);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSTypesetter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */