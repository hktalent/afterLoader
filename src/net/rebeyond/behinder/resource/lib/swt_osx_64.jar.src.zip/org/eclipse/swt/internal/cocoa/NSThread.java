package org.eclipse.swt.internal.cocoa;

public class NSThread
  extends NSObject
{
  public NSThread() {}
  
  public NSThread(long paramLong)
  {
    super(paramLong);
  }
  
  public NSThread(id paramid)
  {
    super(paramid);
  }
  
  public static NSThread currentThread()
  {
    long l = OS.objc_msgSend(OS.class_NSThread, OS.sel_currentThread);
    return l != 0L ? new NSThread(l) : null;
  }
  
  public static boolean isMainThread()
  {
    return OS.objc_msgSend_bool(OS.class_NSThread, OS.sel_isMainThread);
  }
  
  public NSMutableDictionary threadDictionary()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_threadDictionary);
    return l != 0L ? new NSMutableDictionary(l) : null;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSThread.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */