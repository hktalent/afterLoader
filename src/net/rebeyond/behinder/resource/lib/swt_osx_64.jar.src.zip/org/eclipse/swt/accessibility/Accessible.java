package org.eclipse.swt.accessibility;

import java.io.PrintStream;
import java.net.URL;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Vector;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.graphics.TextStyle;
import org.eclipse.swt.internal.cocoa.NSArray;
import org.eclipse.swt.internal.cocoa.NSFont;
import org.eclipse.swt.internal.cocoa.NSMutableArray;
import org.eclipse.swt.internal.cocoa.NSMutableAttributedString;
import org.eclipse.swt.internal.cocoa.NSMutableDictionary;
import org.eclipse.swt.internal.cocoa.NSNumber;
import org.eclipse.swt.internal.cocoa.NSObject;
import org.eclipse.swt.internal.cocoa.NSPoint;
import org.eclipse.swt.internal.cocoa.NSRange;
import org.eclipse.swt.internal.cocoa.NSRect;
import org.eclipse.swt.internal.cocoa.NSScreen;
import org.eclipse.swt.internal.cocoa.NSSize;
import org.eclipse.swt.internal.cocoa.NSString;
import org.eclipse.swt.internal.cocoa.NSURL;
import org.eclipse.swt.internal.cocoa.NSValue;
import org.eclipse.swt.internal.cocoa.NSView;
import org.eclipse.swt.internal.cocoa.OS;
import org.eclipse.swt.internal.cocoa.id;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Monitor;
import org.eclipse.swt.widgets.Shell;

public class Accessible
{
  static boolean DEBUG = false;
  static final int MAX_RELATION_TYPES = 15;
  static NSString[] baseAttributes = { OS.NSAccessibilityRoleAttribute, OS.NSAccessibilitySubroleAttribute, OS.NSAccessibilityRoleDescriptionAttribute, OS.NSAccessibilityHelpAttribute, OS.NSAccessibilityFocusedAttribute, OS.NSAccessibilityParentAttribute, OS.NSAccessibilityChildrenAttribute, OS.NSAccessibilityPositionAttribute, OS.NSAccessibilitySizeAttribute, OS.NSAccessibilityWindowAttribute, OS.NSAccessibilityTopLevelUIElementAttribute };
  NSMutableArray attributeNames = null;
  NSMutableArray parameterizedAttributeNames = null;
  NSMutableArray actionNames = null;
  Vector accessibleListeners;
  Vector accessibleControlListeners;
  Vector accessibleTextListeners;
  Vector accessibleActionListeners;
  Vector accessibleEditableTextListeners;
  Vector accessibleHyperlinkListeners;
  Vector accessibleTableListeners;
  Vector accessibleTableCellListeners;
  Vector accessibleTextExtendedListeners;
  Vector accessibleValueListeners;
  Vector accessibleAttributeListeners;
  Relation[] relations = new Relation[15];
  Accessible parent;
  Control control;
  int currentRole = -1;
  Map childToIdMap = new HashMap();
  SWTAccessibleDelegate delegate;
  int index = -1;
  TableAccessibleDelegate tableDelegate;
  
  public Accessible(Accessible paramAccessible)
  {
    if (paramAccessible == null) {
      SWT.error(4);
    }
    this.parent = paramAccessible;
    this.control = paramAccessible.control;
    this.delegate = new SWTAccessibleDelegate(this, -1);
  }
  
  /**
   * @deprecated
   */
  protected Accessible() {}
  
  Accessible(Control paramControl)
  {
    this.control = paramControl;
  }
  
  public static Accessible internal_new_Accessible(Control paramControl)
  {
    return new Accessible(paramControl);
  }
  
  id accessibleHandle(Accessible paramAccessible)
  {
    if (paramAccessible.delegate != null) {
      return paramAccessible.delegate;
    }
    if (paramAccessible.control != null)
    {
      NSView localNSView = paramAccessible.control.view;
      long l = OS.objc_msgSend(localNSView.id, OS.sel_accessibleHandle);
      return new id(l);
    }
    return null;
  }
  
  public void addAccessibleListener(AccessibleListener paramAccessibleListener)
  {
    checkWidget();
    if (paramAccessibleListener == null) {
      SWT.error(4);
    }
    if (this.accessibleListeners == null) {
      this.accessibleListeners = new Vector();
    }
    this.accessibleListeners.addElement(paramAccessibleListener);
  }
  
  public void addAccessibleControlListener(AccessibleControlListener paramAccessibleControlListener)
  {
    checkWidget();
    if (paramAccessibleControlListener == null) {
      SWT.error(4);
    }
    if (this.accessibleControlListeners == null) {
      this.accessibleControlListeners = new Vector();
    }
    this.accessibleControlListeners.addElement(paramAccessibleControlListener);
  }
  
  public void addAccessibleTextListener(AccessibleTextListener paramAccessibleTextListener)
  {
    checkWidget();
    if (paramAccessibleTextListener == null) {
      SWT.error(4);
    }
    if ((paramAccessibleTextListener instanceof AccessibleTextExtendedListener))
    {
      if (this.accessibleTextExtendedListeners == null) {
        this.accessibleTextExtendedListeners = new Vector();
      }
      this.accessibleTextExtendedListeners.addElement(paramAccessibleTextListener);
    }
    else
    {
      if (this.accessibleTextListeners == null) {
        this.accessibleTextListeners = new Vector();
      }
      this.accessibleTextListeners.addElement(paramAccessibleTextListener);
    }
  }
  
  public void addAccessibleActionListener(AccessibleActionListener paramAccessibleActionListener)
  {
    checkWidget();
    if (paramAccessibleActionListener == null) {
      SWT.error(4);
    }
    if (this.accessibleActionListeners == null) {
      this.accessibleActionListeners = new Vector();
    }
    this.accessibleActionListeners.addElement(paramAccessibleActionListener);
  }
  
  public void addAccessibleEditableTextListener(AccessibleEditableTextListener paramAccessibleEditableTextListener)
  {
    checkWidget();
    if (paramAccessibleEditableTextListener == null) {
      SWT.error(4);
    }
    if (this.accessibleEditableTextListeners == null) {
      this.accessibleEditableTextListeners = new Vector();
    }
    this.accessibleEditableTextListeners.addElement(paramAccessibleEditableTextListener);
  }
  
  public void addAccessibleHyperlinkListener(AccessibleHyperlinkListener paramAccessibleHyperlinkListener)
  {
    checkWidget();
    if (paramAccessibleHyperlinkListener == null) {
      SWT.error(4);
    }
    if (this.accessibleHyperlinkListeners == null) {
      this.accessibleHyperlinkListeners = new Vector();
    }
    this.accessibleHyperlinkListeners.addElement(paramAccessibleHyperlinkListener);
  }
  
  public void addAccessibleTableListener(AccessibleTableListener paramAccessibleTableListener)
  {
    checkWidget();
    if (paramAccessibleTableListener == null) {
      SWT.error(4);
    }
    if (this.accessibleTableListeners == null) {
      this.accessibleTableListeners = new Vector();
    }
    this.accessibleTableListeners.addElement(paramAccessibleTableListener);
  }
  
  public void addAccessibleTableCellListener(AccessibleTableCellListener paramAccessibleTableCellListener)
  {
    checkWidget();
    if (paramAccessibleTableCellListener == null) {
      SWT.error(4);
    }
    if (this.accessibleTableCellListeners == null) {
      this.accessibleTableCellListeners = new Vector();
    }
    this.accessibleTableCellListeners.addElement(paramAccessibleTableCellListener);
  }
  
  public void addAccessibleValueListener(AccessibleValueListener paramAccessibleValueListener)
  {
    checkWidget();
    if (paramAccessibleValueListener == null) {
      SWT.error(4);
    }
    if (this.accessibleValueListeners == null) {
      this.accessibleValueListeners = new Vector();
    }
    this.accessibleValueListeners.addElement(paramAccessibleValueListener);
  }
  
  public void addAccessibleAttributeListener(AccessibleAttributeListener paramAccessibleAttributeListener)
  {
    checkWidget();
    if (paramAccessibleAttributeListener == null) {
      SWT.error(4);
    }
    if (this.accessibleAttributeListeners == null) {
      this.accessibleAttributeListeners = new Vector();
    }
    this.accessibleAttributeListeners.addElement(paramAccessibleAttributeListener);
  }
  
  void addCGColor(double[] paramArrayOfDouble, NSMutableAttributedString paramNSMutableAttributedString, NSString paramNSString, NSRange paramNSRange)
  {
    long l1 = OS.CGColorSpaceCreateDeviceRGB();
    long l2 = OS.CGColorCreate(l1, paramArrayOfDouble);
    OS.CGColorSpaceRelease(l1);
    paramNSMutableAttributedString.addAttribute(paramNSString, new id(l2), paramNSRange);
    OS.CGColorRelease(l2);
  }
  
  public void addRelation(int paramInt, Accessible paramAccessible)
  {
    checkWidget();
    if (this.relations[paramInt] == null) {
      this.relations[paramInt] = new Relation(this, paramInt);
    }
    this.relations[paramInt].addTarget(paramAccessible);
  }
  
  int accessibleListenersSize()
  {
    return this.accessibleListeners == null ? 0 : this.accessibleListeners.size();
  }
  
  int accessibleControlListenersSize()
  {
    return this.accessibleControlListeners == null ? 0 : this.accessibleControlListeners.size();
  }
  
  int accessibleValueListenersSize()
  {
    return this.accessibleValueListeners == null ? 0 : this.accessibleValueListeners.size();
  }
  
  int accessibleTextExtendedListenersSize()
  {
    return this.accessibleTextExtendedListeners == null ? 0 : this.accessibleTextExtendedListeners.size();
  }
  
  int accessibleTextListenersSize()
  {
    return this.accessibleTextListeners == null ? 0 : this.accessibleTextListeners.size();
  }
  
  int accessibleTableCellListenersSize()
  {
    return this.accessibleTableCellListeners == null ? 0 : this.accessibleTableCellListeners.size();
  }
  
  int accessibleTableListenersSize()
  {
    return this.accessibleTableListeners == null ? 0 : this.accessibleTableListeners.size();
  }
  
  int accessibleHyperlinkListenersSize()
  {
    return this.accessibleHyperlinkListeners == null ? 0 : this.accessibleHyperlinkListeners.size();
  }
  
  int accessibleEditableTextListenersSize()
  {
    return this.accessibleEditableTextListeners == null ? 0 : this.accessibleEditableTextListeners.size();
  }
  
  int accessibleAttributeListenersSize()
  {
    return this.accessibleAttributeListeners == null ? 0 : this.accessibleAttributeListeners.size();
  }
  
  int accessibleActionListenersSize()
  {
    return this.accessibleActionListeners == null ? 0 : this.accessibleActionListeners.size();
  }
  
  void checkRole(int paramInt)
  {
    if (paramInt != this.currentRole)
    {
      this.currentRole = paramInt;
      if (this.attributeNames != null)
      {
        this.attributeNames.release();
        this.attributeNames = null;
      }
      if (this.parameterizedAttributeNames != null)
      {
        this.parameterizedAttributeNames.release();
        this.parameterizedAttributeNames = null;
      }
      if (this.actionNames != null)
      {
        this.actionNames.release();
        this.actionNames = null;
      }
    }
  }
  
  void createTableDelegate()
  {
    if (this.tableDelegate == null) {
      this.tableDelegate = new TableAccessibleDelegate(this);
    }
  }
  
  id getColumnIndexRangeAttribute(int paramInt)
  {
    AccessibleTableCellEvent localAccessibleTableCellEvent = new AccessibleTableCellEvent(this);
    for (int i = 0; i < accessibleTableCellListenersSize(); i++)
    {
      AccessibleTableCellListener localAccessibleTableCellListener = (AccessibleTableCellListener)this.accessibleTableCellListeners.elementAt(i);
      localAccessibleTableCellListener.getColumnIndex(localAccessibleTableCellEvent);
      localAccessibleTableCellListener.getColumnSpan(localAccessibleTableCellEvent);
    }
    NSRange localNSRange = new NSRange();
    localNSRange.location = localAccessibleTableCellEvent.index;
    localNSRange.length = localAccessibleTableCellEvent.count;
    return NSValue.valueWithRange(localNSRange);
  }
  
  id getRowIndexRangeAttribute(int paramInt)
  {
    AccessibleTableCellEvent localAccessibleTableCellEvent = new AccessibleTableCellEvent(this);
    for (int i = 0; i < accessibleTableCellListenersSize(); i++)
    {
      AccessibleTableCellListener localAccessibleTableCellListener = (AccessibleTableCellListener)this.accessibleTableCellListeners.elementAt(i);
      localAccessibleTableCellListener.getRowIndex(localAccessibleTableCellEvent);
      localAccessibleTableCellListener.getRowSpan(localAccessibleTableCellEvent);
    }
    NSRange localNSRange = new NSRange();
    localNSRange.location = localAccessibleTableCellEvent.index;
    localNSRange.length = localAccessibleTableCellEvent.count;
    return NSValue.valueWithRange(localNSRange);
  }
  
  id getSelectedAttribute(int paramInt)
  {
    if (accessibleTableListenersSize() > 0)
    {
      AccessibleTableEvent localAccessibleTableEvent = new AccessibleTableEvent(this);
      localAccessibleTableEvent.row = this.index;
      for (int i = 0; i < accessibleTableListenersSize(); i++)
      {
        AccessibleTableListener localAccessibleTableListener = (AccessibleTableListener)this.accessibleTableListeners.elementAt(i);
        if (this.currentRole == 28) {
          localAccessibleTableListener.isRowSelected(localAccessibleTableEvent);
        } else {
          localAccessibleTableListener.isColumnSelected(localAccessibleTableEvent);
        }
      }
      return NSNumber.numberWithBool(localAccessibleTableEvent.isSelected);
    }
    return NSNumber.numberWithBool(false);
  }
  
  id getIndexAttribute(int paramInt)
  {
    return NSNumber.numberWithInt(this.index);
  }
  
  id getHeaderAttribute(int paramInt)
  {
    SWTAccessibleDelegate localSWTAccessibleDelegate = null;
    AccessibleTableEvent localAccessibleTableEvent = new AccessibleTableEvent(this);
    for (int i = 0; i < accessibleTableListenersSize(); i++)
    {
      AccessibleTableListener localAccessibleTableListener = (AccessibleTableListener)this.accessibleTableListeners.elementAt(i);
      localAccessibleTableListener.getColumnHeader(localAccessibleTableEvent);
    }
    if (localAccessibleTableEvent.accessible != null) {
      localSWTAccessibleDelegate = localAccessibleTableEvent.accessible.delegate;
    }
    return localSWTAccessibleDelegate;
  }
  
  id getVisibleColumnsAttribute(int paramInt)
  {
    if (accessibleTableListenersSize() == 0) {
      return null;
    }
    Object localObject1 = null;
    AccessibleTableEvent localAccessibleTableEvent = new AccessibleTableEvent(this);
    Object localObject2;
    for (int i = 0; i < accessibleTableListenersSize(); i++)
    {
      localObject2 = (AccessibleTableListener)this.accessibleTableListeners.elementAt(i);
      ((AccessibleTableListener)localObject2).getVisibleColumns(localAccessibleTableEvent);
    }
    if (localAccessibleTableEvent.accessibles != null)
    {
      NSMutableArray localNSMutableArray = NSMutableArray.arrayWithCapacity(localAccessibleTableEvent.accessibles.length);
      localObject2 = localAccessibleTableEvent.accessibles;
      for (int j = 0; j < localObject2.length; j++)
      {
        Object localObject3 = localObject2[j];
        localNSMutableArray.addObject(((Accessible)localObject3).delegate);
      }
      localObject1 = localNSMutableArray;
    }
    return localObject1 == null ? NSArray.array() : localObject1;
  }
  
  id getVisibleRowsAttribute(int paramInt)
  {
    if (accessibleTableListenersSize() == 0) {
      return null;
    }
    Object localObject1 = null;
    AccessibleTableEvent localAccessibleTableEvent = new AccessibleTableEvent(this);
    Object localObject2;
    for (int i = 0; i < accessibleTableListenersSize(); i++)
    {
      localObject2 = (AccessibleTableListener)this.accessibleTableListeners.elementAt(i);
      ((AccessibleTableListener)localObject2).getVisibleRows(localAccessibleTableEvent);
    }
    if (localAccessibleTableEvent.accessibles != null)
    {
      NSMutableArray localNSMutableArray = NSMutableArray.arrayWithCapacity(localAccessibleTableEvent.accessibles.length);
      localObject2 = localAccessibleTableEvent.accessibles;
      for (int j = 0; j < localObject2.length; j++)
      {
        Object localObject3 = localObject2[j];
        localNSMutableArray.addObject(((Accessible)localObject3).delegate);
      }
      localObject1 = localNSMutableArray;
    }
    return localObject1 == null ? NSArray.array() : localObject1;
  }
  
  id getSelectedRowsAttribute(int paramInt)
  {
    if (accessibleTableListenersSize() == 0) {
      return null;
    }
    Object localObject1 = null;
    AccessibleTableEvent localAccessibleTableEvent = new AccessibleTableEvent(this);
    Object localObject2;
    for (int i = 0; i < accessibleTableListenersSize(); i++)
    {
      localObject2 = (AccessibleTableListener)this.accessibleTableListeners.elementAt(i);
      ((AccessibleTableListener)localObject2).getSelectedRows(localAccessibleTableEvent);
    }
    if (localAccessibleTableEvent.selected != null)
    {
      int[] arrayOfInt = (int[])localAccessibleTableEvent.selected;
      localObject2 = NSMutableArray.arrayWithCapacity(arrayOfInt.length);
      for (int j = 0; j < arrayOfInt.length; j++)
      {
        localAccessibleTableEvent.row = arrayOfInt[j];
        for (int k = 0; k < accessibleTableListenersSize(); k++)
        {
          AccessibleTableListener localAccessibleTableListener = (AccessibleTableListener)this.accessibleTableListeners.elementAt(k);
          localAccessibleTableListener.getRow(localAccessibleTableEvent);
        }
        if (localAccessibleTableEvent.accessible != null) {
          ((NSMutableArray)localObject2).addObject(localAccessibleTableEvent.accessible.delegate);
        }
      }
      localObject1 = localObject2;
    }
    return localObject1 == null ? NSArray.array() : localObject1;
  }
  
  int getRowCount()
  {
    AccessibleTableEvent localAccessibleTableEvent = new AccessibleTableEvent(this);
    for (int i = 0; i < accessibleTableListenersSize(); i++)
    {
      AccessibleTableListener localAccessibleTableListener = (AccessibleTableListener)this.accessibleTableListeners.elementAt(i);
      localAccessibleTableListener.getRowCount(localAccessibleTableEvent);
    }
    return localAccessibleTableEvent.count;
  }
  
  id getRowsAttribute(int paramInt)
  {
    if (accessibleTableListenersSize() == 0) {
      return null;
    }
    AccessibleTableEvent localAccessibleTableEvent = new AccessibleTableEvent(this);
    for (int i = 0; i < accessibleTableListenersSize(); i++)
    {
      localObject = (AccessibleTableListener)this.accessibleTableListeners.elementAt(i);
      ((AccessibleTableListener)localObject).getRowCount(localAccessibleTableEvent);
      ((AccessibleTableListener)localObject).getRows(localAccessibleTableEvent);
    }
    if (localAccessibleTableEvent.accessibles == null) {
      localAccessibleTableEvent.accessibles = new Accessible[0];
    }
    if (localAccessibleTableEvent.count != localAccessibleTableEvent.accessibles.length)
    {
      createTableDelegate();
      for (i = 0; i < accessibleTableListenersSize(); i++)
      {
        localObject = (AccessibleTableListener)this.accessibleTableListeners.elementAt(i);
        ((AccessibleTableListener)localObject).getRowCount(localAccessibleTableEvent);
        ((AccessibleTableListener)localObject).getRows(localAccessibleTableEvent);
      }
    }
    NSMutableArray localNSMutableArray = NSMutableArray.arrayWithCapacity(localAccessibleTableEvent.accessibles.length);
    Object localObject = localAccessibleTableEvent.accessibles;
    for (int j = 0; j < localObject.length; j++)
    {
      Accessible localAccessible = (Accessible)localObject[j];
      localAccessible.index = j;
      localNSMutableArray.addObject(localAccessible.delegate);
    }
    return localNSMutableArray;
  }
  
  id getSelectedColumnsAttribute(int paramInt)
  {
    if (accessibleTableListenersSize() == 0) {
      return null;
    }
    Object localObject1 = null;
    AccessibleTableEvent localAccessibleTableEvent = new AccessibleTableEvent(this);
    Object localObject2;
    for (int i = 0; i < accessibleTableListenersSize(); i++)
    {
      localObject2 = (AccessibleTableListener)this.accessibleTableListeners.elementAt(i);
      ((AccessibleTableListener)localObject2).getSelectedColumns(localAccessibleTableEvent);
    }
    if (localAccessibleTableEvent.selected != null)
    {
      int[] arrayOfInt = (int[])localAccessibleTableEvent.selected;
      localObject2 = NSMutableArray.arrayWithCapacity(arrayOfInt.length);
      for (int j = 0; j < arrayOfInt.length; j++)
      {
        localAccessibleTableEvent.column = arrayOfInt[j];
        for (int k = 0; k < accessibleTableListenersSize(); k++)
        {
          AccessibleTableListener localAccessibleTableListener = (AccessibleTableListener)this.accessibleTableListeners.elementAt(k);
          localAccessibleTableListener.getColumn(localAccessibleTableEvent);
        }
        if (localAccessibleTableEvent.accessible != null) {
          ((NSMutableArray)localObject2).addObject(localAccessibleTableEvent.accessible.delegate);
        }
      }
      localObject1 = localObject2;
    }
    return localObject1 == null ? NSArray.array() : localObject1;
  }
  
  int getColumnCount()
  {
    AccessibleTableEvent localAccessibleTableEvent = new AccessibleTableEvent(this);
    for (int i = 0; i < accessibleTableListenersSize(); i++)
    {
      AccessibleTableListener localAccessibleTableListener = (AccessibleTableListener)this.accessibleTableListeners.elementAt(i);
      localAccessibleTableListener.getColumnCount(localAccessibleTableEvent);
    }
    return localAccessibleTableEvent.count;
  }
  
  id getColumnsAttribute(int paramInt)
  {
    if (accessibleTableListenersSize() == 0) {
      return null;
    }
    AccessibleTableEvent localAccessibleTableEvent = new AccessibleTableEvent(this);
    for (int i = 0; i < accessibleTableListenersSize(); i++)
    {
      localObject1 = (AccessibleTableListener)this.accessibleTableListeners.elementAt(i);
      ((AccessibleTableListener)localObject1).getColumnCount(localAccessibleTableEvent);
      ((AccessibleTableListener)localObject1).getColumns(localAccessibleTableEvent);
    }
    if (localAccessibleTableEvent.accessibles == null) {
      localAccessibleTableEvent.accessibles = new Accessible[0];
    }
    if (localAccessibleTableEvent.count != localAccessibleTableEvent.accessibles.length)
    {
      createTableDelegate();
      for (i = 0; i < accessibleTableListenersSize(); i++)
      {
        localObject1 = (AccessibleTableListener)this.accessibleTableListeners.elementAt(i);
        ((AccessibleTableListener)localObject1).getColumnCount(localAccessibleTableEvent);
        ((AccessibleTableListener)localObject1).getColumns(localAccessibleTableEvent);
      }
    }
    NSMutableArray localNSMutableArray = NSMutableArray.arrayWithCapacity(localAccessibleTableEvent.accessibles.length);
    Object localObject1 = localAccessibleTableEvent.accessibles;
    for (int j = 0; j < localObject1.length; j++)
    {
      Object localObject2 = localObject1[j];
      ((Accessible)localObject2).index = j;
      localNSMutableArray.addObject(((Accessible)localObject2).delegate);
    }
    return localNSMutableArray;
  }
  
  public id internal_accessibilityActionDescription(NSString paramNSString, int paramInt)
  {
    NSString localNSString = NSString.string();
    String str = paramNSString.getString();
    if (accessibleActionListenersSize() > 0)
    {
      AccessibleActionEvent localAccessibleActionEvent = new AccessibleActionEvent(this);
      for (int i = 0; i < accessibleActionListenersSize(); i++)
      {
        AccessibleActionListener localAccessibleActionListener1 = (AccessibleActionListener)this.accessibleActionListeners.elementAt(i);
        localAccessibleActionListener1.getActionCount(localAccessibleActionEvent);
      }
      i = -1;
      for (int j = 0; j < localAccessibleActionEvent.count; j++)
      {
        localAccessibleActionEvent.index = j;
        for (int k = 0; k < accessibleActionListenersSize(); k++)
        {
          AccessibleActionListener localAccessibleActionListener3 = (AccessibleActionListener)this.accessibleActionListeners.elementAt(k);
          localAccessibleActionListener3.getName(localAccessibleActionEvent);
        }
        if (str.equals(localAccessibleActionEvent.result))
        {
          i = j;
          break;
        }
      }
      if (i != -1)
      {
        localAccessibleActionEvent.index = i;
        localAccessibleActionEvent.result = null;
        for (j = 0; j < accessibleActionListenersSize(); j++)
        {
          AccessibleActionListener localAccessibleActionListener2 = (AccessibleActionListener)this.accessibleActionListeners.elementAt(j);
          localAccessibleActionListener2.getDescription(localAccessibleActionEvent);
        }
        if (localAccessibleActionEvent.result != null) {
          localNSString = NSString.stringWith(localAccessibleActionEvent.result);
        }
      }
    }
    return localNSString;
  }
  
  public NSArray internal_accessibilityActionNames(int paramInt)
  {
    if (accessibleActionListenersSize() > 0)
    {
      localObject = new AccessibleActionEvent(this);
      for (int i = 0; i < accessibleActionListenersSize(); i++)
      {
        AccessibleActionListener localAccessibleActionListener1 = (AccessibleActionListener)this.accessibleActionListeners.elementAt(i);
        localAccessibleActionListener1.getActionCount((AccessibleActionEvent)localObject);
      }
      NSMutableArray localNSMutableArray1 = NSMutableArray.arrayWithCapacity(((AccessibleActionEvent)localObject).count);
      for (int k = 0; k < ((AccessibleActionEvent)localObject).count; k++)
      {
        ((AccessibleActionEvent)localObject).index = k;
        for (int m = 0; m < accessibleActionListenersSize(); m++)
        {
          AccessibleActionListener localAccessibleActionListener2 = (AccessibleActionListener)this.accessibleActionListeners.elementAt(m);
          localAccessibleActionListener2.getName((AccessibleActionEvent)localObject);
        }
        localNSMutableArray1.addObject(NSString.stringWith(((AccessibleActionEvent)localObject).result));
      }
      return localNSMutableArray1;
    }
    Object localObject = new AccessibleControlEvent(this);
    ((AccessibleControlEvent)localObject).childID = paramInt;
    ((AccessibleControlEvent)localObject).detail = -1;
    for (int j = 0; j < accessibleControlListenersSize(); j++)
    {
      AccessibleControlListener localAccessibleControlListener = (AccessibleControlListener)this.accessibleControlListeners.elementAt(j);
      localAccessibleControlListener.getRole((AccessibleControlEvent)localObject);
    }
    if (((AccessibleControlEvent)localObject).detail == -1) {
      return null;
    }
    checkRole(((AccessibleControlEvent)localObject).detail);
    if ((paramInt == -1) && (this.actionNames != null)) {
      return retainedAutoreleased(this.actionNames);
    }
    NSMutableArray localNSMutableArray2 = NSMutableArray.arrayWithCapacity(5L);
    switch (((AccessibleControlEvent)localObject).detail)
    {
    case 30: 
    case 37: 
    case 43: 
    case 44: 
    case 45: 
    case 62: 
    case 1027: 
    case 1073: 
      localNSMutableArray2.addObject(OS.NSAccessibilityPressAction);
      break;
    case 46: 
      localNSMutableArray2.addObject(OS.NSAccessibilityConfirmAction);
      break;
    }
    if (paramInt == -1)
    {
      this.actionNames = localNSMutableArray2;
      this.actionNames.retain();
      return retainedAutoreleased(this.actionNames);
    }
    return localNSMutableArray2;
  }
  
  public boolean internal_accessibilityIsAttributeSettable(NSString paramNSString, int paramInt)
  {
    if (accessibleTextExtendedListenersSize() > 0)
    {
      if (paramNSString.isEqualToString(OS.NSAccessibilitySelectedTextRangeAttribute)) {
        return true;
      }
      if (paramNSString.isEqualToString(OS.NSAccessibilityVisibleCharacterRangeAttribute)) {
        return true;
      }
    }
    if ((accessibleEditableTextListenersSize() > 0) && (paramNSString.isEqualToString(OS.NSAccessibilitySelectedTextAttribute))) {
      return true;
    }
    return (accessibleValueListenersSize() > 0) && (paramNSString.isEqualToString(OS.NSAccessibilityValueAttribute));
  }
  
  public NSArray internal_accessibilityAttributeNames(int paramInt)
  {
    AccessibleControlEvent localAccessibleControlEvent = new AccessibleControlEvent(this);
    localAccessibleControlEvent.childID = paramInt;
    localAccessibleControlEvent.detail = -1;
    for (int i = 0; i < accessibleControlListenersSize(); i++)
    {
      AccessibleControlListener localAccessibleControlListener = (AccessibleControlListener)this.accessibleControlListeners.elementAt(i);
      localAccessibleControlListener.getRole(localAccessibleControlEvent);
    }
    if (localAccessibleControlEvent.detail == -1) {
      return null;
    }
    checkRole(localAccessibleControlEvent.detail);
    if (this.attributeNames != null) {
      return retainedAutoreleased(this.attributeNames);
    }
    NSMutableArray localNSMutableArray = NSMutableArray.arrayWithCapacity(baseAttributes.length);
    for (int j = 0; j < baseAttributes.length; j++) {
      localNSMutableArray.addObject(baseAttributes[j]);
    }
    switch (localAccessibleControlEvent.detail)
    {
    case 10: 
      break;
    case 9: 
      localNSMutableArray.addObject(OS.NSAccessibilityTitleAttribute);
      break;
    case 2: 
      localNSMutableArray.addObject(OS.NSAccessibilitySelectedChildrenAttribute);
      localNSMutableArray.addObject(OS.NSAccessibilityVisibleChildrenAttribute);
      break;
    case 11: 
      localNSMutableArray.addObject(OS.NSAccessibilityEnabledAttribute);
      localNSMutableArray.addObject(OS.NSAccessibilitySelectedChildrenAttribute);
      localNSMutableArray.addObject(OS.NSAccessibilityVisibleChildrenAttribute);
      break;
    case 12: 
      localNSMutableArray.addObject(OS.NSAccessibilityEnabledAttribute);
      break;
    case 21: 
      localNSMutableArray.addObject(OS.NSAccessibilityMaxValueAttribute);
      localNSMutableArray.addObject(OS.NSAccessibilityMinValueAttribute);
      localNSMutableArray.addObject(OS.NSAccessibilityValueAttribute);
      break;
    case 13: 
      localNSMutableArray.addObject(OS.NSAccessibilityTitleAttribute);
      break;
    case 3: 
      localNSMutableArray.addObject(OS.NSAccessibilityValueAttribute);
      break;
    case 18: 
      localNSMutableArray.addObject(OS.NSAccessibilityTitleAttribute);
      break;
    case 41: 
      localNSMutableArray.addObject(OS.NSAccessibilityEnabledAttribute);
      localNSMutableArray.addObject(OS.NSAccessibilityValueAttribute);
      break;
    case 43: 
      localNSMutableArray.addObject(OS.NSAccessibilityEnabledAttribute);
      localNSMutableArray.addObject(OS.NSAccessibilityTitleAttribute);
      break;
    case 44: 
    case 45: 
      localNSMutableArray.addObject(OS.NSAccessibilityEnabledAttribute);
      localNSMutableArray.addObject(OS.NSAccessibilityValueAttribute);
      localNSMutableArray.addObject(OS.NSAccessibilityTitleAttribute);
      break;
    case 62: 
      break;
    case 46: 
      localNSMutableArray.addObject(OS.NSAccessibilityEnabledAttribute);
      localNSMutableArray.addObject(OS.NSAccessibilityExpandedAttribute);
      localNSMutableArray.addObject(OS.NSAccessibilityNumberOfCharactersAttribute);
      localNSMutableArray.addObject(OS.NSAccessibilitySelectedTextAttribute);
      localNSMutableArray.addObject(OS.NSAccessibilitySelectedTextRangeAttribute);
      localNSMutableArray.addObject(OS.NSAccessibilityVisibleCharacterRangeAttribute);
      localNSMutableArray.addObject(OS.NSAccessibilityValueAttribute);
      break;
    case 42: 
    case 1044: 
    case 1054: 
      localNSMutableArray.addObject(OS.NSAccessibilityEnabledAttribute);
      localNSMutableArray.addObject(OS.NSAccessibilityNumberOfCharactersAttribute);
      localNSMutableArray.addObject(OS.NSAccessibilitySelectedTextAttribute);
      localNSMutableArray.addObject(OS.NSAccessibilitySelectedTextRangeAttribute);
      localNSMutableArray.addObject(OS.NSAccessibilityInsertionPointLineNumberAttribute);
      localNSMutableArray.addObject(OS.NSAccessibilitySelectedTextRangesAttribute);
      localNSMutableArray.addObject(OS.NSAccessibilityVisibleCharacterRangeAttribute);
      localNSMutableArray.addObject(OS.NSAccessibilityValueAttribute);
      break;
    case 22: 
      break;
    case 33: 
      localNSMutableArray.addObject(OS.NSAccessibilityEnabledAttribute);
      localNSMutableArray.addObject(OS.NSAccessibilityColumnsAttribute);
      localNSMutableArray.addObject(OS.NSAccessibilitySelectedColumnsAttribute);
      localNSMutableArray.addObject(OS.NSAccessibilityRowsAttribute);
      localNSMutableArray.addObject(OS.NSAccessibilitySelectedRowsAttribute);
      localNSMutableArray.addObject(OS.NSAccessibilityHeaderAttribute);
      localNSMutableArray.addObject(OS.NSAccessibilityVisibleRowsAttribute);
      localNSMutableArray.addObject(OS.NSAccessibilityVisibleColumnsAttribute);
      localNSMutableArray.addObject(OS.NSAccessibilityVisibleChildrenAttribute);
      break;
    case 34: 
      localNSMutableArray.addObject(OS.NSAccessibilityValueAttribute);
      break;
    case 24: 
      localNSMutableArray.addObject(OS.NSAccessibilityEnabledAttribute);
      localNSMutableArray.addObject(OS.NSAccessibilityColumnsAttribute);
      localNSMutableArray.addObject(OS.NSAccessibilitySelectedColumnsAttribute);
      localNSMutableArray.addObject(OS.NSAccessibilityVisibleColumnsAttribute);
      localNSMutableArray.addObject(OS.NSAccessibilityRowsAttribute);
      localNSMutableArray.addObject(OS.NSAccessibilitySelectedRowsAttribute);
      localNSMutableArray.addObject(OS.NSAccessibilityVisibleRowsAttribute);
      localNSMutableArray.addObject(OS.NSAccessibilityHeaderAttribute);
      break;
    case 29: 
      localNSMutableArray.addObject(OS.NSAccessibilityEnabledAttribute);
      localNSMutableArray.addObject(OS.NSAccessibilityValueAttribute);
      break;
    case 35: 
      localNSMutableArray.addObject(OS.NSAccessibilityColumnsAttribute);
      localNSMutableArray.addObject(OS.NSAccessibilitySelectedColumnsAttribute);
      localNSMutableArray.addObject(OS.NSAccessibilityRowsAttribute);
      localNSMutableArray.addObject(OS.NSAccessibilitySelectedRowsAttribute);
      localNSMutableArray.addObject(OS.NSAccessibilityHeaderAttribute);
      localNSMutableArray.addObject(OS.NSAccessibilityVisibleRowsAttribute);
      localNSMutableArray.addObject(OS.NSAccessibilityVisibleColumnsAttribute);
      break;
    case 36: 
      localNSMutableArray.addObject(OS.NSAccessibilityColumnsAttribute);
      localNSMutableArray.addObject(OS.NSAccessibilitySelectedColumnsAttribute);
      localNSMutableArray.addObject(OS.NSAccessibilityRowsAttribute);
      localNSMutableArray.addObject(OS.NSAccessibilitySelectedRowsAttribute);
      localNSMutableArray.addObject(OS.NSAccessibilityHeaderAttribute);
      localNSMutableArray.addObject(OS.NSAccessibilityVisibleRowsAttribute);
      localNSMutableArray.addObject(OS.NSAccessibilityVisibleColumnsAttribute);
    case 60: 
      localNSMutableArray.addObject(OS.NSAccessibilityValueAttribute);
      localNSMutableArray.addObject(OS.NSAccessibilityContentsAttribute);
      localNSMutableArray.addObject(OS.NSAccessibilityTabsAttribute);
      break;
    case 37: 
      localNSMutableArray.addObject(OS.NSAccessibilityEnabledAttribute);
      localNSMutableArray.addObject(OS.NSAccessibilityValueAttribute);
      localNSMutableArray.addObject(OS.NSAccessibilityTitleAttribute);
      break;
    case 48: 
      localNSMutableArray.addObject(OS.NSAccessibilityEnabledAttribute);
      localNSMutableArray.addObject(OS.NSAccessibilityMaxValueAttribute);
      localNSMutableArray.addObject(OS.NSAccessibilityMinValueAttribute);
      localNSMutableArray.addObject(OS.NSAccessibilityValueAttribute);
      break;
    case 51: 
      localNSMutableArray.addObject(OS.NSAccessibilityEnabledAttribute);
      localNSMutableArray.addObject(OS.NSAccessibilityMaxValueAttribute);
      localNSMutableArray.addObject(OS.NSAccessibilityMinValueAttribute);
      localNSMutableArray.addObject(OS.NSAccessibilityValueAttribute);
      break;
    case 30: 
      localNSMutableArray.addObject(OS.NSAccessibilityEnabledAttribute);
      break;
    case 8: 
      break;
    case 54: 
      break;
    case 1025: 
      break;
    case 27: 
      localNSMutableArray.removeObject(OS.NSAccessibilityChildrenAttribute);
      localNSMutableArray.removeObject(OS.NSAccessibilityFocusedAttribute);
      localNSMutableArray.addObject(OS.NSAccessibilityIndexAttribute);
      localNSMutableArray.addObject(OS.NSAccessibilitySelectedAttribute);
      localNSMutableArray.addObject(OS.NSAccessibilityRowsAttribute);
      localNSMutableArray.addObject(OS.NSAccessibilityVisibleRowsAttribute);
      localNSMutableArray.addObject(OS.NSAccessibilityHeaderAttribute);
      break;
    case 15: 
      break;
    case 40: 
      localNSMutableArray.addObject(OS.NSAccessibilityEnabledAttribute);
      localNSMutableArray.addObject(OS.NSAccessibilityTitleAttribute);
      localNSMutableArray.addObject(OS.NSAccessibilityDescriptionAttribute);
      break;
    case 20: 
      break;
    case 28: 
      localNSMutableArray.addObject(OS.NSAccessibilityVisibleChildrenAttribute);
      localNSMutableArray.addObject(OS.NSAccessibilityIndexAttribute);
      localNSMutableArray.addObject(OS.NSAccessibilitySelectedAttribute);
      break;
    case 52: 
      break;
    case 23: 
      break;
    case 1027: 
      break;
    case 1073: 
      break;
    case 61: 
      break;
    case 1029: 
      break;
    case 47: 
      break;
    case 1038: 
      break;
    case 1043: 
      break;
    case 1040: 
      break;
    case 1053: 
      break;
    }
    if (localAccessibleControlEvent.detail != -1)
    {
      String str = roleToOs(localAccessibleControlEvent.detail);
      if (str.indexOf(':') == -1) {
        localNSMutableArray.removeObject(OS.NSAccessibilitySubroleAttribute);
      }
    }
    if (paramInt != -1) {
      localNSMutableArray.removeObject(OS.NSAccessibilityChildrenAttribute);
    }
    if (paramInt == -1)
    {
      this.attributeNames = localNSMutableArray;
      this.attributeNames.retain();
      return retainedAutoreleased(this.attributeNames);
    }
    return localNSMutableArray;
  }
  
  public id internal_accessibilityAttributeValue(NSString paramNSString, int paramInt)
  {
    if (paramNSString.isEqualToString(OS.NSAccessibilityRoleAttribute)) {
      return getRoleAttribute(paramInt);
    }
    if (paramNSString.isEqualToString(OS.NSAccessibilitySubroleAttribute)) {
      return getSubroleAttribute(paramInt);
    }
    if (paramNSString.isEqualToString(OS.NSAccessibilityRoleDescriptionAttribute)) {
      return getRoleDescriptionAttribute(paramInt);
    }
    if (paramNSString.isEqualToString(OS.NSAccessibilityExpandedAttribute)) {
      return getExpandedAttribute(paramInt);
    }
    if (paramNSString.isEqualToString(OS.NSAccessibilityHelpAttribute)) {
      return getHelpAttribute(paramInt);
    }
    if (paramNSString.isEqualToString(OS.NSAccessibilityTitleAttribute)) {
      return getTitleAttribute(paramInt);
    }
    if (paramNSString.isEqualToString(OS.NSAccessibilityValueAttribute)) {
      return getValueAttribute(paramInt);
    }
    if (paramNSString.isEqualToString(OS.NSAccessibilityMaxValueAttribute)) {
      return getMaxValueAttribute(paramInt);
    }
    if (paramNSString.isEqualToString(OS.NSAccessibilityMinValueAttribute)) {
      return getMinValueAttribute(paramInt);
    }
    if (paramNSString.isEqualToString(OS.NSAccessibilityEnabledAttribute)) {
      return getEnabledAttribute(paramInt);
    }
    if (paramNSString.isEqualToString(OS.NSAccessibilityFocusedAttribute)) {
      return getFocusedAttribute(paramInt);
    }
    if (paramNSString.isEqualToString(OS.NSAccessibilityParentAttribute)) {
      return getParentAttribute(paramInt);
    }
    if (paramNSString.isEqualToString(OS.NSAccessibilityChildrenAttribute)) {
      return getChildrenAttribute(paramInt, false);
    }
    if (paramNSString.isEqualToString(OS.NSAccessibilityVisibleChildrenAttribute)) {
      return getChildrenAttribute(paramInt, true);
    }
    if (paramNSString.isEqualToString(OS.NSAccessibilityContentsAttribute)) {
      return getChildrenAttribute(paramInt, false);
    }
    if (paramNSString.isEqualToString(OS.NSAccessibilityTabsAttribute)) {
      return getTabsAttribute(paramInt);
    }
    if (paramNSString.isEqualToString(OS.NSAccessibilityWindowAttribute)) {
      return getWindowAttribute(paramInt);
    }
    if (paramNSString.isEqualToString(OS.NSAccessibilityTopLevelUIElementAttribute)) {
      return getTopLevelUIElementAttribute(paramInt);
    }
    if (paramNSString.isEqualToString(OS.NSAccessibilityPositionAttribute)) {
      return getPositionAttribute(paramInt);
    }
    if (paramNSString.isEqualToString(OS.NSAccessibilitySizeAttribute)) {
      return getSizeAttribute(paramInt);
    }
    if (paramNSString.isEqualToString(OS.NSAccessibilityDescriptionAttribute)) {
      return getDescriptionAttribute(paramInt);
    }
    if (paramNSString.isEqualToString(OS.NSAccessibilityNumberOfCharactersAttribute)) {
      return getNumberOfCharactersAttribute(paramInt);
    }
    if (paramNSString.isEqualToString(OS.NSAccessibilitySelectedTextAttribute)) {
      return getSelectedTextAttribute(paramInt);
    }
    if (paramNSString.isEqualToString(OS.NSAccessibilitySelectedTextRangeAttribute)) {
      return getSelectedTextRangeAttribute(paramInt);
    }
    if (paramNSString.isEqualToString(OS.NSAccessibilityInsertionPointLineNumberAttribute)) {
      return getInsertionPointLineNumberAttribute(paramInt);
    }
    if (paramNSString.isEqualToString(OS.NSAccessibilitySelectedTextRangesAttribute)) {
      return getSelectedTextRangesAttribute(paramInt);
    }
    if (paramNSString.isEqualToString(OS.NSAccessibilityVisibleCharacterRangeAttribute)) {
      return getVisibleCharacterRangeAttribute(paramInt);
    }
    if (paramNSString.isEqualToString(OS.NSAccessibilityServesAsTitleForUIElementsAttribute)) {
      return getServesAsTitleForUIElementsAttribute(paramInt);
    }
    if (paramNSString.isEqualToString(OS.NSAccessibilityTitleUIElementAttribute)) {
      return getTitleUIElementAttribute(paramInt);
    }
    if (paramNSString.isEqualToString(OS.NSAccessibilityColumnsAttribute)) {
      return getColumnsAttribute(paramInt);
    }
    if (paramNSString.isEqualToString(OS.NSAccessibilitySelectedColumnsAttribute)) {
      return getSelectedColumnsAttribute(paramInt);
    }
    if (paramNSString.isEqualToString(OS.NSAccessibilityRowsAttribute)) {
      return getRowsAttribute(paramInt);
    }
    if (paramNSString.isEqualToString(OS.NSAccessibilitySelectedRowsAttribute)) {
      return getSelectedRowsAttribute(paramInt);
    }
    if (paramNSString.isEqualToString(OS.NSAccessibilityVisibleRowsAttribute)) {
      return getVisibleRowsAttribute(paramInt);
    }
    if (paramNSString.isEqualToString(OS.NSAccessibilityVisibleColumnsAttribute)) {
      return getVisibleColumnsAttribute(paramInt);
    }
    if (paramNSString.isEqualToString(OS.NSAccessibilityHeaderAttribute)) {
      return getHeaderAttribute(paramInt);
    }
    if (paramNSString.isEqualToString(OS.NSAccessibilityIndexAttribute)) {
      return getIndexAttribute(paramInt);
    }
    if (paramNSString.isEqualToString(OS.NSAccessibilitySelectedAttribute)) {
      return getSelectedAttribute(paramInt);
    }
    if ((OS.VERSION >= 4192) && (paramNSString.isEqualToString(OS.NSAccessibilityRowIndexRangeAttribute))) {
      return getRowIndexRangeAttribute(paramInt);
    }
    if ((OS.VERSION >= 4192) && (paramNSString.isEqualToString(OS.NSAccessibilityColumnIndexRangeAttribute))) {
      return getColumnIndexRangeAttribute(paramInt);
    }
    return null;
  }
  
  public id internal_accessibilityAttributeValue_forParameter(NSString paramNSString, id paramid, int paramInt)
  {
    if (paramNSString.isEqualToString(OS.NSAccessibilityStringForRangeParameterizedAttribute)) {
      return getStringForRangeParameterizedAttribute(paramid, paramInt);
    }
    if (paramNSString.isEqualToString(OS.NSAccessibilityRangeForLineParameterizedAttribute)) {
      return getRangeForLineParameterizedAttribute(paramid, paramInt);
    }
    if (paramNSString.isEqualToString(OS.NSAccessibilityRangeForIndexParameterizedAttribute)) {
      return getRangeForIndexParameterizedAttribute(paramid, paramInt);
    }
    if (paramNSString.isEqualToString(OS.NSAccessibilityLineForIndexParameterizedAttribute)) {
      return getLineForIndexParameterizedAttribute(paramid, paramInt);
    }
    if (paramNSString.isEqualToString(OS.NSAccessibilityBoundsForRangeParameterizedAttribute)) {
      return getBoundsForRangeParameterizedAttribute(paramid, paramInt);
    }
    if (paramNSString.isEqualToString(OS.NSAccessibilityRangeForPositionParameterizedAttribute)) {
      return getRangeForPositionParameterizedAttribute(paramid, paramInt);
    }
    if (paramNSString.isEqualToString(OS.NSAccessibilityAttributedStringForRangeParameterizedAttribute)) {
      return getAttributedStringForRangeParameterizedAttribute(paramid, paramInt);
    }
    if (paramNSString.isEqualToString(OS.NSAccessibilityStyleRangeForIndexParameterizedAttribute)) {
      return getStyleRangeForIndexAttribute(paramid, paramInt);
    }
    if ((OS.VERSION >= 4192) && (paramNSString.isEqualToString(OS.NSAccessibilityCellForColumnAndRowParameterizedAttribute))) {
      return getCellForColumnAndRowParameter(paramid, paramInt);
    }
    return null;
  }
  
  public id internal_accessibilityFocusedUIElement(int paramInt)
  {
    AccessibleControlEvent localAccessibleControlEvent = new AccessibleControlEvent(this);
    localAccessibleControlEvent.childID = -3;
    localAccessibleControlEvent.accessible = null;
    for (int i = 0; i < accessibleControlListenersSize(); i++)
    {
      AccessibleControlListener localAccessibleControlListener = (AccessibleControlListener)this.accessibleControlListeners.elementAt(i);
      localAccessibleControlListener.getFocus(localAccessibleControlEvent);
    }
    if (localAccessibleControlEvent.childID == -3) {
      return null;
    }
    if (localAccessibleControlEvent.accessible != null) {
      return new id(OS.NSAccessibilityUnignoredAncestor(localAccessibleControlEvent.accessible.control.view.id));
    }
    if ((localAccessibleControlEvent.childID == -1) || (localAccessibleControlEvent.childID == -2)) {
      return new id(OS.NSAccessibilityUnignoredAncestor(this.control.view.id));
    }
    return new id(OS.NSAccessibilityUnignoredAncestor(childIDToOs(localAccessibleControlEvent.childID).id));
  }
  
  public id internal_accessibilityHitTest(NSPoint paramNSPoint, int paramInt)
  {
    AccessibleControlEvent localAccessibleControlEvent = new AccessibleControlEvent(this);
    localAccessibleControlEvent.x = ((int)paramNSPoint.x);
    Monitor localMonitor = Display.getCurrent().getPrimaryMonitor();
    localAccessibleControlEvent.y = ((int)(localMonitor.getBounds().height - paramNSPoint.y));
    localAccessibleControlEvent.childID = -3;
    for (int i = 0; i < accessibleControlListenersSize(); i++)
    {
      AccessibleControlListener localAccessibleControlListener = (AccessibleControlListener)this.accessibleControlListeners.elementAt(i);
      localAccessibleControlListener.getChildAtPoint(localAccessibleControlEvent);
    }
    if ((localAccessibleControlEvent.childID == -3) && (localAccessibleControlEvent.accessible == null)) {
      return null;
    }
    if (localAccessibleControlEvent.accessible != null) {
      return new id(OS.NSAccessibilityUnignoredAncestor(localAccessibleControlEvent.accessible.delegate.id));
    }
    if ((localAccessibleControlEvent.childID == -1) || (localAccessibleControlEvent.childID == -2)) {
      return new id(OS.NSAccessibilityUnignoredAncestor(this.control.view.id));
    }
    return new id(OS.NSAccessibilityUnignoredAncestor(childIDToOs(localAccessibleControlEvent.childID).id));
  }
  
  public boolean internal_accessibilityIsIgnored(int paramInt)
  {
    AccessibleControlEvent localAccessibleControlEvent = new AccessibleControlEvent(this);
    localAccessibleControlEvent.childID = paramInt;
    localAccessibleControlEvent.detail = -1;
    for (int i = 0; i < accessibleControlListenersSize(); i++)
    {
      AccessibleControlListener localAccessibleControlListener = (AccessibleControlListener)this.accessibleControlListeners.elementAt(i);
      localAccessibleControlListener.getRole(localAccessibleControlEvent);
    }
    i = localAccessibleControlEvent.detail == -1 ? 1 : 0;
    if (i != 0) {
      i = (getTitleAttribute(paramInt) == null) && (getHelpAttribute(paramInt) == null) && (getDescriptionAttribute(paramInt) == null) ? 1 : 0;
    }
    return i;
  }
  
  public NSArray internal_accessibilityParameterizedAttributeNames(int paramInt)
  {
    AccessibleControlEvent localAccessibleControlEvent = new AccessibleControlEvent(this);
    localAccessibleControlEvent.childID = paramInt;
    localAccessibleControlEvent.detail = -1;
    for (int i = 0; i < accessibleControlListenersSize(); i++)
    {
      AccessibleControlListener localAccessibleControlListener = (AccessibleControlListener)this.accessibleControlListeners.elementAt(i);
      localAccessibleControlListener.getRole(localAccessibleControlEvent);
    }
    if (localAccessibleControlEvent.detail == -1) {
      return null;
    }
    checkRole(localAccessibleControlEvent.detail);
    if ((paramInt == -1) && (this.parameterizedAttributeNames != null)) {
      return retainedAutoreleased(this.parameterizedAttributeNames);
    }
    NSMutableArray localNSMutableArray = NSMutableArray.arrayWithCapacity(4L);
    switch (localAccessibleControlEvent.detail)
    {
    case 42: 
    case 1044: 
    case 1054: 
      localNSMutableArray.addObject(OS.NSAccessibilityStringForRangeParameterizedAttribute);
      localNSMutableArray.addObject(OS.NSAccessibilityRangeForLineParameterizedAttribute);
      localNSMutableArray.addObject(OS.NSAccessibilityRangeForIndexParameterizedAttribute);
      localNSMutableArray.addObject(OS.NSAccessibilityLineForIndexParameterizedAttribute);
      localNSMutableArray.addObject(OS.NSAccessibilityBoundsForRangeParameterizedAttribute);
      localNSMutableArray.addObject(OS.NSAccessibilityRangeForPositionParameterizedAttribute);
      localNSMutableArray.addObject(OS.NSAccessibilityAttributedStringForRangeParameterizedAttribute);
      localNSMutableArray.addObject(OS.NSAccessibilityStyleRangeForIndexParameterizedAttribute);
      break;
    case 24: 
      if (OS.VERSION >= 4192) {
        localNSMutableArray.addObject(OS.NSAccessibilityCellForColumnAndRowParameterizedAttribute);
      }
      break;
    }
    if (paramInt == -1)
    {
      this.parameterizedAttributeNames = localNSMutableArray;
      this.parameterizedAttributeNames.retain();
      return retainedAutoreleased(this.parameterizedAttributeNames);
    }
    return localNSMutableArray;
  }
  
  public boolean internal_accessibilityPerformAction(NSString paramNSString, int paramInt)
  {
    String str = paramNSString.getString();
    if (accessibleActionListenersSize() > 0)
    {
      AccessibleActionEvent localAccessibleActionEvent = new AccessibleActionEvent(this);
      for (int i = 0; i < accessibleActionListenersSize(); i++)
      {
        AccessibleActionListener localAccessibleActionListener1 = (AccessibleActionListener)this.accessibleActionListeners.elementAt(i);
        localAccessibleActionListener1.getActionCount(localAccessibleActionEvent);
      }
      i = -1;
      for (int j = 0; j < localAccessibleActionEvent.count; j++)
      {
        localAccessibleActionEvent.index = j;
        for (int k = 0; k < accessibleActionListenersSize(); k++)
        {
          AccessibleActionListener localAccessibleActionListener3 = (AccessibleActionListener)this.accessibleActionListeners.elementAt(k);
          localAccessibleActionListener3.getName(localAccessibleActionEvent);
        }
        if (str.equals(localAccessibleActionEvent.result))
        {
          i = j;
          break;
        }
      }
      if (i != -1)
      {
        localAccessibleActionEvent.index = i;
        localAccessibleActionEvent.result = null;
        for (j = 0; j < accessibleActionListenersSize(); j++)
        {
          AccessibleActionListener localAccessibleActionListener2 = (AccessibleActionListener)this.accessibleActionListeners.elementAt(j);
          localAccessibleActionListener2.doAction(localAccessibleActionEvent);
        }
        return "OK".equals(localAccessibleActionEvent.result);
      }
    }
    return false;
  }
  
  public void internal_accessibilitySetValue_forAttribute(id paramid, NSString paramNSString, int paramInt)
  {
    if (paramNSString.isEqualToString(OS.NSAccessibilitySelectedTextRangeAttribute)) {
      setSelectedTextRangeAttribute(paramid, paramInt);
    }
    if (paramNSString.isEqualToString(OS.NSAccessibilitySelectedTextAttribute)) {
      setSelectedTextAttribute(paramid, paramInt);
    }
    if (paramNSString.isEqualToString(OS.NSAccessibilityVisibleCharacterRangeAttribute)) {
      setVisibleCharacterRangeAttribute(paramid, paramInt);
    }
    if (accessibleValueListenersSize() > 0)
    {
      AccessibleValueEvent localAccessibleValueEvent = new AccessibleValueEvent(this);
      NSNumber localNSNumber = new NSNumber(paramid);
      localAccessibleValueEvent.value = new Double(localNSNumber.doubleValue());
      for (int i = 0; i < accessibleValueListenersSize(); i++)
      {
        AccessibleValueListener localAccessibleValueListener = (AccessibleValueListener)this.accessibleValueListeners.elementAt(i);
        localAccessibleValueListener.setCurrentValue(localAccessibleValueEvent);
      }
    }
  }
  
  public void dispose()
  {
    if (this.parent == null) {
      return;
    }
    release(true);
    this.parent = null;
  }
  
  public Control getControl()
  {
    return this.control;
  }
  
  public void internal_dispose_Accessible()
  {
    release(true);
  }
  
  id getAttributedStringForRangeParameterizedAttribute(id paramid, int paramInt)
  {
    if (accessibleAttributeListenersSize() == 0) {
      return null;
    }
    id localid = getStringForRangeParameterizedAttribute(paramid, paramInt);
    NSMutableAttributedString localNSMutableAttributedString = (NSMutableAttributedString)new NSMutableAttributedString().alloc();
    localNSMutableAttributedString.initWithString(new NSString(localid), null);
    localNSMutableAttributedString.autorelease();
    NSValue localNSValue = new NSValue(paramid.id);
    NSRange localNSRange1 = localNSValue.rangeValue();
    AccessibleTextAttributeEvent localAccessibleTextAttributeEvent = new AccessibleTextAttributeEvent(this);
    localAccessibleTextAttributeEvent.offset = ((int)localNSRange1.location);
    localAccessibleTextAttributeEvent.start = (localAccessibleTextAttributeEvent.end = -1);
    NSRange localNSRange2 = new NSRange();
    Object localObject3;
    while (localAccessibleTextAttributeEvent.offset < localNSRange1.location + localNSRange1.length)
    {
      Object localObject2;
      for (int i = 0; i < accessibleAttributeListenersSize(); i++)
      {
        localObject2 = (AccessibleAttributeListener)this.accessibleAttributeListeners.elementAt(i);
        ((AccessibleAttributeListener)localObject2).getTextAttributes(localAccessibleTextAttributeEvent);
      }
      if ((localAccessibleTextAttributeEvent.start == -1) && (localAccessibleTextAttributeEvent.end == -1)) {
        return localid;
      }
      localNSRange2.location = (localAccessibleTextAttributeEvent.start - localNSRange1.location);
      localNSRange2.length = (localAccessibleTextAttributeEvent.end - localAccessibleTextAttributeEvent.start);
      if (localNSRange2.location < 0L)
      {
        localNSRange2.length -= -localNSRange2.location;
        localNSRange2.location = 0L;
      }
      if (localNSRange2.location + localNSRange2.length > localNSRange1.length) {
        localNSRange1.length -= localNSRange2.location;
      }
      localAccessibleTextAttributeEvent.offset = localAccessibleTextAttributeEvent.end;
      if (localAccessibleTextAttributeEvent.textStyle != null)
      {
        localObject1 = localAccessibleTextAttributeEvent.textStyle;
        Object localObject4;
        if (((TextStyle)localObject1).font != null)
        {
          localObject2 = NSMutableDictionary.dictionaryWithCapacity(4L);
          localObject3 = ((TextStyle)localObject1).font.handle;
          localObject4 = ((NSFont)localObject3).fontName();
          ((NSMutableDictionary)localObject2).setValue((id)localObject4, OS.NSAccessibilityFontNameKey);
          NSString localNSString1 = ((NSFont)localObject3).familyName();
          ((NSMutableDictionary)localObject2).setValue(localNSString1, OS.NSAccessibilityFontFamilyKey);
          NSString localNSString2 = ((NSFont)localObject3).displayName();
          ((NSMutableDictionary)localObject2).setValue(localNSString2, OS.NSAccessibilityVisibleNameKey);
          double d = ((NSFont)localObject3).pointSize();
          ((NSMutableDictionary)localObject2).setValue(NSNumber.numberWithDouble(d), OS.NSAccessibilityFontSizeKey);
          localNSMutableAttributedString.addAttribute(OS.NSAccessibilityFontTextAttribute, (id)localObject2, localNSRange2);
        }
        if (((TextStyle)localObject1).foreground != null) {
          addCGColor(((TextStyle)localObject1).foreground.handle, localNSMutableAttributedString, OS.NSAccessibilityForegroundColorTextAttribute, localNSRange2);
        }
        if (((TextStyle)localObject1).background != null) {
          addCGColor(((TextStyle)localObject1).background.handle, localNSMutableAttributedString, OS.NSAccessibilityBackgroundColorTextAttribute, localNSRange2);
        }
        if (((TextStyle)localObject1).underline)
        {
          int j = ((TextStyle)localObject1).underlineStyle;
          localObject3 = OS.NSAccessibilityUnderlineTextAttribute;
          localObject4 = null;
          switch (j)
          {
          case 0: 
            localObject4 = NSNumber.numberWithInt(1);
            break;
          case 1: 
            localObject4 = NSNumber.numberWithInt(9);
            break;
          case 3: 
            localObject3 = OS.NSAccessibilityMisspelledTextAttribute;
            localObject4 = NSNumber.numberWithBool(true);
            break;
          case 2: 
          default: 
            localObject4 = NSNumber.numberWithInt(0);
          }
          localNSMutableAttributedString.addAttribute((NSString)localObject3, (id)localObject4, localNSRange2);
        }
        if (((TextStyle)localObject1).underlineColor != null) {
          addCGColor(((TextStyle)localObject1).underlineColor.handle, localNSMutableAttributedString, OS.NSAccessibilityUnderlineColorTextAttribute, localNSRange2);
        }
        if (((TextStyle)localObject1).strikeout)
        {
          localNSMutableAttributedString.addAttribute(OS.NSAccessibilityStrikethroughTextAttribute, NSNumber.numberWithBool(true), localNSRange2);
          if (((TextStyle)localObject1).strikeoutColor != null) {
            addCGColor(((TextStyle)localObject1).strikeoutColor.handle, localNSMutableAttributedString, OS.NSAccessibilityStrikethroughColorTextAttribute, localNSRange2);
          }
        }
        if ((((TextStyle)localObject1).data != null) && ((((TextStyle)localObject1).data instanceof URL)))
        {
          URL localURL = (URL)((TextStyle)localObject1).data;
          localObject3 = NSURL.URLWithString(NSString.stringWith(localURL.toExternalForm()));
          localNSMutableAttributedString.addAttribute(OS.NSAccessibilityLinkTextAttribute, (id)localObject3, localNSRange2);
        }
      }
    }
    Object localObject1 = new AccessibleAttributeEvent(this);
    ((AccessibleAttributeEvent)localObject1).indent = Integer.MAX_VALUE;
    for (int k = 0; k < accessibleAttributeListenersSize(); k++)
    {
      localObject3 = (AccessibleAttributeListener)this.accessibleAttributeListeners.elementAt(k);
      ((AccessibleAttributeListener)localObject3).getAttributes((AccessibleAttributeEvent)localObject1);
    }
    if (((AccessibleAttributeEvent)localObject1).indent != Integer.MAX_VALUE)
    {
      NSMutableDictionary localNSMutableDictionary = NSMutableDictionary.dictionaryWithCapacity(3L);
      int m = 0;
      switch (((AccessibleAttributeEvent)localObject1).alignment)
      {
      case 16777216: 
        m = 2;
        break;
      case 131072: 
        m = 1;
        break;
      case 16384: 
      default: 
        m = 0;
      }
      localNSMutableDictionary.setValue(NSNumber.numberWithInt(m), NSString.stringWith("AXTextAlignment"));
      localNSRange1.location = 0L;
      localNSMutableAttributedString.addAttribute(NSString.stringWith("AXParagraphStyle"), localNSMutableDictionary, localNSRange1);
    }
    return localNSMutableAttributedString;
  }
  
  id getBoundsForRangeParameterizedAttribute(id paramid, int paramInt)
  {
    if (accessibleTextExtendedListenersSize() == 0) {
      return null;
    }
    NSValue localNSValue1 = null;
    NSValue localNSValue2 = new NSValue(paramid.id);
    NSRange localNSRange = localNSValue2.rangeValue();
    NSRect localNSRect1 = new NSRect();
    if (accessibleTextExtendedListenersSize() > 0)
    {
      AccessibleTextEvent localAccessibleTextEvent = new AccessibleTextEvent(this);
      localAccessibleTextEvent.childID = paramInt;
      localAccessibleTextEvent.start = ((int)localNSRange.location);
      localAccessibleTextEvent.end = ((int)(localNSRange.location + localNSRange.length));
      for (int i = 0; i < accessibleTextExtendedListenersSize(); i++)
      {
        localObject = (AccessibleTextExtendedListener)this.accessibleTextExtendedListeners.elementAt(i);
        ((AccessibleTextExtendedListener)localObject).getTextBounds(localAccessibleTextEvent);
      }
      localNSRect1.x = localAccessibleTextEvent.x;
      NSArray localNSArray = NSScreen.screens();
      Object localObject = new NSScreen(localNSArray.objectAtIndex(0L));
      NSRect localNSRect2 = ((NSScreen)localObject).frame();
      localNSRect1.y = (localNSRect2.height - localAccessibleTextEvent.y - localAccessibleTextEvent.height);
      localNSRect1.width = localAccessibleTextEvent.width;
      localNSRect1.height = localAccessibleTextEvent.height;
      localNSValue1 = NSValue.valueWithRect(localNSRect1);
    }
    return localNSValue1;
  }
  
  id getExpandedAttribute(int paramInt)
  {
    return NSNumber.numberWithBool(false);
  }
  
  id getHelpAttribute(int paramInt)
  {
    NSString localNSString = null;
    AccessibleEvent localAccessibleEvent = new AccessibleEvent(this);
    localAccessibleEvent.childID = paramInt;
    for (int i = 0; i < accessibleListenersSize(); i++)
    {
      AccessibleListener localAccessibleListener = (AccessibleListener)this.accessibleListeners.elementAt(i);
      localAccessibleListener.getHelp(localAccessibleEvent);
    }
    if (localAccessibleEvent.result != null) {
      localNSString = NSString.stringWith(localAccessibleEvent.result);
    }
    return localNSString;
  }
  
  id getRangeForPositionParameterizedAttribute(id paramid, int paramInt)
  {
    NSValue localNSValue1 = null;
    NSValue localNSValue2 = new NSValue(paramid.id);
    NSPoint localNSPoint = localNSValue2.pointValue();
    NSRange localNSRange = new NSRange();
    if (accessibleTextExtendedListenersSize() > 0)
    {
      NSArray localNSArray = NSScreen.screens();
      NSScreen localNSScreen = new NSScreen(localNSArray.objectAtIndex(0L));
      NSRect localNSRect = localNSScreen.frame();
      localNSPoint.y = (localNSRect.height - localNSPoint.y);
      AccessibleTextEvent localAccessibleTextEvent = new AccessibleTextEvent(this);
      localAccessibleTextEvent.childID = paramInt;
      localAccessibleTextEvent.x = ((int)localNSPoint.x);
      localAccessibleTextEvent.y = ((int)localNSPoint.y);
      for (int i = 0; i < accessibleTextExtendedListenersSize(); i++)
      {
        AccessibleTextExtendedListener localAccessibleTextExtendedListener = (AccessibleTextExtendedListener)this.accessibleTextExtendedListeners.elementAt(i);
        localAccessibleTextExtendedListener.getOffsetAtPoint(localAccessibleTextEvent);
      }
      localNSRange.location = localAccessibleTextEvent.offset;
      localNSRange.length = 1L;
    }
    localNSValue1 = NSValue.valueWithRange(localNSRange);
    return localNSValue1;
  }
  
  NSString getRoleAttribute(int paramInt)
  {
    NSString localNSString = null;
    AccessibleControlEvent localAccessibleControlEvent = new AccessibleControlEvent(this);
    localAccessibleControlEvent.childID = paramInt;
    localAccessibleControlEvent.detail = -1;
    for (int i = 0; i < accessibleControlListenersSize(); i++)
    {
      AccessibleControlListener localAccessibleControlListener = (AccessibleControlListener)this.accessibleControlListeners.elementAt(i);
      localAccessibleControlListener.getRole(localAccessibleControlEvent);
    }
    if (localAccessibleControlEvent.detail != -1)
    {
      String str = roleToOs(localAccessibleControlEvent.detail);
      int j = str.indexOf(':');
      if (j != -1) {
        str = str.substring(0, j);
      }
      localNSString = NSString.stringWith(str);
    }
    return localNSString;
  }
  
  id getSubroleAttribute(int paramInt)
  {
    NSString localNSString = null;
    AccessibleControlEvent localAccessibleControlEvent = new AccessibleControlEvent(this);
    localAccessibleControlEvent.childID = paramInt;
    localAccessibleControlEvent.detail = -1;
    for (int i = 0; i < accessibleControlListenersSize(); i++)
    {
      AccessibleControlListener localAccessibleControlListener = (AccessibleControlListener)this.accessibleControlListeners.elementAt(i);
      localAccessibleControlListener.getRole(localAccessibleControlEvent);
    }
    if (localAccessibleControlEvent.detail != -1)
    {
      String str = roleToOs(localAccessibleControlEvent.detail);
      int j = str.indexOf(':');
      if (j != -1)
      {
        str = str.substring(j + 1);
        localNSString = NSString.stringWith(str);
      }
    }
    return localNSString;
  }
  
  id getRoleDescriptionAttribute(int paramInt)
  {
    NSString localNSString1 = null;
    AccessibleControlEvent localAccessibleControlEvent = new AccessibleControlEvent(this);
    localAccessibleControlEvent.childID = paramInt;
    localAccessibleControlEvent.detail = -1;
    Object localObject;
    for (int i = 0; i < accessibleControlListenersSize(); i++)
    {
      localObject = (AccessibleControlListener)this.accessibleControlListeners.elementAt(i);
      ((AccessibleControlListener)localObject).getRole(localAccessibleControlEvent);
    }
    if (localAccessibleControlEvent.detail != -1) {
      if (localAccessibleControlEvent.detail == 37)
      {
        localNSString1 = new NSString(OS.NSAccessibilityRoleDescription(NSString.stringWith("AXTab").id, 0L));
      }
      else
      {
        String str = roleToOs(localAccessibleControlEvent.detail);
        localObject = null;
        int j = str.indexOf(':');
        if (j != -1)
        {
          localObject = str.substring(j + 1);
          str = str.substring(0, j);
        }
        NSString localNSString2 = NSString.stringWith(str);
        NSString localNSString3 = null;
        if (localObject != null) {
          localNSString3 = NSString.stringWith((String)localObject);
        }
        localNSString1 = new NSString(OS.NSAccessibilityRoleDescription(localNSString2 != null ? localNSString2.id : 0L, localNSString3 != null ? localNSString3.id : 0L));
      }
    }
    return localNSString1;
  }
  
  id getTitleAttribute(int paramInt)
  {
    NSString localNSString = null;
    AccessibleControlEvent localAccessibleControlEvent = new AccessibleControlEvent(this);
    localAccessibleControlEvent.childID = paramInt;
    localAccessibleControlEvent.detail = -1;
    for (int i = 0; i < accessibleControlListenersSize(); i++)
    {
      AccessibleControlListener localAccessibleControlListener = (AccessibleControlListener)this.accessibleControlListeners.elementAt(i);
      localAccessibleControlListener.getRole(localAccessibleControlEvent);
    }
    if (localAccessibleControlEvent.detail != 41)
    {
      AccessibleEvent localAccessibleEvent = new AccessibleEvent(this);
      localAccessibleEvent.childID = paramInt;
      localAccessibleEvent.result = null;
      for (int j = 0; j < accessibleListenersSize(); j++)
      {
        AccessibleListener localAccessibleListener = (AccessibleListener)this.accessibleListeners.elementAt(j);
        localAccessibleListener.getName(localAccessibleEvent);
      }
      if (localAccessibleEvent.result != null) {
        localNSString = NSString.stringWith(localAccessibleEvent.result);
      }
    }
    return localNSString;
  }
  
  id getTitleUIElementAttribute(int paramInt)
  {
    id localid = null;
    Relation localRelation = this.relations[9];
    if (localRelation != null) {
      localid = localRelation.getTitleUIElement();
    }
    return localid;
  }
  
  id getValueAttribute(int paramInt)
  {
    Object localObject1 = null;
    Object localObject2;
    int i;
    Object localObject3;
    if (accessibleValueListenersSize() > 0)
    {
      localObject2 = new AccessibleValueEvent(this);
      for (i = 0; i < accessibleValueListenersSize(); i++)
      {
        localObject3 = (AccessibleValueListener)this.accessibleValueListeners.elementAt(i);
        ((AccessibleValueListener)localObject3).getCurrentValue((AccessibleValueEvent)localObject2);
      }
      localObject1 = NSNumber.numberWithDouble(((AccessibleValueEvent)localObject2).value.doubleValue());
    }
    else
    {
      localObject2 = new AccessibleControlEvent(this);
      ((AccessibleControlEvent)localObject2).childID = paramInt;
      ((AccessibleControlEvent)localObject2).detail = -1;
      ((AccessibleControlEvent)localObject2).result = null;
      for (i = 0; i < accessibleControlListenersSize(); i++)
      {
        localObject3 = (AccessibleControlListener)this.accessibleControlListeners.elementAt(i);
        ((AccessibleControlListener)localObject3).getRole((AccessibleControlEvent)localObject2);
        ((AccessibleControlListener)localObject3).getValue((AccessibleControlEvent)localObject2);
      }
      i = ((AccessibleControlEvent)localObject2).detail;
      localObject3 = ((AccessibleControlEvent)localObject2).result;
      switch (i)
      {
      case 3: 
      case 44: 
      case 45: 
      case 48: 
      case 51: 
        if (localObject3 != null) {
          try
          {
            int j = Integer.parseInt((String)localObject3);
            localObject1 = NSNumber.numberWithBool(j != 0);
          }
          catch (NumberFormatException localNumberFormatException)
          {
            if (((String)localObject3).equalsIgnoreCase("true")) {
              localObject1 = NSNumber.numberWithBool(true);
            } else if (((String)localObject3).equalsIgnoreCase("false")) {
              localObject1 = NSNumber.numberWithBool(false);
            }
          }
        } else {
          localObject1 = NSNumber.numberWithBool(false);
        }
        break;
      case 37: 
      case 60: 
        AccessibleControlEvent localAccessibleControlEvent = new AccessibleControlEvent(this);
        localAccessibleControlEvent.childID = -4;
        for (int k = 0; k < accessibleControlListenersSize(); k++)
        {
          AccessibleControlListener localAccessibleControlListener = (AccessibleControlListener)this.accessibleControlListeners.elementAt(k);
          localAccessibleControlListener.getSelection(localAccessibleControlEvent);
        }
        if (localAccessibleControlEvent.childID >= -1)
        {
          if (i == 37) {
            localObject1 = NSNumber.numberWithBool(localAccessibleControlEvent.childID == paramInt);
          } else {
            localObject1 = new id(OS.NSAccessibilityUnignoredAncestor(childIDToOs(localAccessibleControlEvent.childID).id));
          }
        }
        else {
          localObject1 = NSNumber.numberWithBool(false);
        }
        break;
      case 42: 
      case 46: 
      case 1044: 
      case 1054: 
        if (localObject3 != null) {
          localObject1 = NSString.stringWith((String)localObject3);
        }
        break;
      case 29: 
      case 41: 
        AccessibleEvent localAccessibleEvent = new AccessibleEvent(this);
        localAccessibleEvent.childID = paramInt;
        localAccessibleEvent.result = null;
        for (int m = 0; m < accessibleListenersSize(); m++)
        {
          AccessibleListener localAccessibleListener = (AccessibleListener)this.accessibleListeners.elementAt(m);
          localAccessibleListener.getName(localAccessibleEvent);
        }
        if (localAccessibleEvent.result != null) {
          localObject1 = NSString.stringWith(localAccessibleEvent.result);
        } else if (localObject3 != null) {
          localObject1 = NSString.stringWith((String)localObject3);
        }
        localObject1 = localObject1 == null ? NSString.string() : localObject1;
      }
    }
    return (id)localObject1;
  }
  
  id getEnabledAttribute(int paramInt)
  {
    AccessibleControlEvent localAccessibleControlEvent = new AccessibleControlEvent(this);
    localAccessibleControlEvent.detail = 0;
    localAccessibleControlEvent.childID = paramInt;
    for (int i = 0; i < accessibleControlListenersSize(); i++)
    {
      AccessibleControlListener localAccessibleControlListener = (AccessibleControlListener)this.accessibleControlListeners.elementAt(i);
      localAccessibleControlListener.getState(localAccessibleControlEvent);
    }
    i = (localAccessibleControlEvent.detail & 0x1) == 0 ? 1 : 0;
    boolean bool;
    if ((i == 0) && (this.delegate == null)) {
      bool = this.control.isEnabled();
    }
    return NSNumber.numberWithBool(bool);
  }
  
  id getFocusedAttribute(int paramInt)
  {
    AccessibleControlEvent localAccessibleControlEvent = new AccessibleControlEvent(this);
    localAccessibleControlEvent.childID = -3;
    for (int i = 0; i < accessibleControlListenersSize(); i++)
    {
      AccessibleControlListener localAccessibleControlListener = (AccessibleControlListener)this.accessibleControlListeners.elementAt(i);
      localAccessibleControlListener.getFocus(localAccessibleControlEvent);
    }
    if (localAccessibleControlEvent.accessible != null)
    {
      i = (localAccessibleControlEvent.accessible.index == paramInt) && (localAccessibleControlEvent.accessible.control == this.control) ? 1 : 0;
      return NSNumber.numberWithBool(i);
    }
    if (localAccessibleControlEvent.childID == -1) {
      return NSNumber.numberWithBool(true);
    }
    if (localAccessibleControlEvent.childID == -2) {
      return NSNumber.numberWithBool(false);
    }
    if (localAccessibleControlEvent.childID != -3) {
      return NSNumber.numberWithBool(localAccessibleControlEvent.childID == paramInt);
    }
    return null;
  }
  
  id getParentAttribute(int paramInt)
  {
    Object localObject = null;
    if (paramInt == -1)
    {
      if (this.parent != null)
      {
        if (this.parent.delegate != null) {
          localObject = this.parent.delegate;
        } else {
          localObject = new id(OS.NSAccessibilityUnignoredAncestor(accessibleHandle(this.parent).id));
        }
      }
      else {
        localObject = null;
      }
    }
    else {
      localObject = new id(OS.NSAccessibilityUnignoredAncestor(accessibleHandle(this).id));
    }
    return (id)localObject;
  }
  
  id getChildrenAttribute(int paramInt, boolean paramBoolean)
  {
    Object localObject1 = null;
    if (paramInt == -1)
    {
      if (this.currentRole == 24)
      {
        getRowsAttribute(paramInt);
        getColumnsAttribute(paramInt);
      }
      AccessibleControlEvent localAccessibleControlEvent = new AccessibleControlEvent(this);
      localAccessibleControlEvent.childID = paramInt;
      localAccessibleControlEvent.detail = -1;
      for (int i = 0; i < accessibleControlListenersSize(); i++)
      {
        AccessibleControlListener localAccessibleControlListener = (AccessibleControlListener)this.accessibleControlListeners.elementAt(i);
        localAccessibleControlListener.getChildCount(localAccessibleControlEvent);
      }
      i = localAccessibleControlEvent.detail;
      localAccessibleControlEvent.detail = (paramBoolean ? 1 : 0);
      if (i >= 0)
      {
        for (int j = 0; j < accessibleControlListenersSize(); j++)
        {
          localObject2 = (AccessibleControlListener)this.accessibleControlListeners.elementAt(j);
          ((AccessibleControlListener)localObject2).getChildren(localAccessibleControlEvent);
        }
        Object[] arrayOfObject = localAccessibleControlEvent.children;
        i = arrayOfObject != null ? arrayOfObject.length : 0;
        Object localObject2 = NSMutableArray.arrayWithCapacity(i);
        for (int k = 0; k < i; k++)
        {
          Object localObject3 = arrayOfObject[k];
          Object localObject4;
          if ((localObject3 instanceof Accessible))
          {
            localObject4 = (Accessible)localObject3;
            if (((Accessible)localObject4).delegate != null) {
              ((NSMutableArray)localObject2).addObject(((Accessible)localObject4).delegate);
            } else {
              ((NSMutableArray)localObject2).addObject(accessibleHandle((Accessible)localObject4));
            }
          }
          else if ((localObject3 instanceof Integer))
          {
            localObject4 = childIDToOs(((Integer)localObject3).intValue());
            ((NSMutableArray)localObject2).addObject((id)localObject4);
          }
        }
        localObject1 = new id(OS.NSAccessibilityUnignoredChildren(((NSMutableArray)localObject2).id));
      }
    }
    else
    {
      localObject1 = NSArray.array();
    }
    return (id)localObject1;
  }
  
  id getTabsAttribute(int paramInt)
  {
    Object localObject1 = null;
    if (paramInt == -1)
    {
      AccessibleControlEvent localAccessibleControlEvent = new AccessibleControlEvent(this);
      localAccessibleControlEvent.childID = paramInt;
      localAccessibleControlEvent.detail = -1;
      Object localObject2;
      for (int i = 0; i < accessibleControlListenersSize(); i++)
      {
        localObject2 = (AccessibleControlListener)this.accessibleControlListeners.elementAt(i);
        ((AccessibleControlListener)localObject2).getChildCount(localAccessibleControlEvent);
      }
      if (localAccessibleControlEvent.detail > 0)
      {
        for (i = 0; i < accessibleControlListenersSize(); i++)
        {
          localObject2 = (AccessibleControlListener)this.accessibleControlListeners.elementAt(i);
          ((AccessibleControlListener)localObject2).getChildren(localAccessibleControlEvent);
        }
        Object[] arrayOfObject = localAccessibleControlEvent.children;
        if ((arrayOfObject != null) && (arrayOfObject.length > 0))
        {
          localObject2 = NSMutableArray.arrayWithCapacity(arrayOfObject.length);
          for (int j = 0; j < arrayOfObject.length; j++)
          {
            Object localObject3 = arrayOfObject[j];
            if ((localObject3 instanceof Integer))
            {
              int k = ((Integer)localObject3).intValue();
              localAccessibleControlEvent.childID = k;
              localAccessibleControlEvent.detail = -1;
              for (int m = 0; m < accessibleControlListenersSize(); m++)
              {
                AccessibleControlListener localAccessibleControlListener = (AccessibleControlListener)this.accessibleControlListeners.elementAt(m);
                localAccessibleControlListener.getRole(localAccessibleControlEvent);
              }
              if (localAccessibleControlEvent.detail == 37)
              {
                id localid = childIDToOs(((Integer)localObject3).intValue());
                ((NSMutableArray)localObject2).addObject(localid);
              }
            }
            else
            {
              ((NSMutableArray)localObject2).addObject(((Accessible)localObject3).control.view);
            }
          }
          localObject1 = new id(OS.NSAccessibilityUnignoredChildren(((NSMutableArray)localObject2).id));
        }
      }
    }
    else
    {
      localObject1 = NSArray.array();
    }
    return (id)localObject1;
  }
  
  id getWindowAttribute(int paramInt)
  {
    return this.control.view.window();
  }
  
  id getTopLevelUIElementAttribute(int paramInt)
  {
    return this.control.view.window();
  }
  
  id getPositionAttribute(int paramInt)
  {
    NSValue localNSValue = null;
    AccessibleControlEvent localAccessibleControlEvent = new AccessibleControlEvent(this);
    localAccessibleControlEvent.childID = paramInt;
    localAccessibleControlEvent.width = -1;
    for (int i = 0; i < accessibleControlListenersSize(); i++)
    {
      localObject = (AccessibleControlListener)this.accessibleControlListeners.elementAt(i);
      ((AccessibleControlListener)localObject).getLocation(localAccessibleControlEvent);
    }
    Monitor localMonitor = Display.getCurrent().getPrimaryMonitor();
    Object localObject = new NSPoint();
    if (localAccessibleControlEvent.width != -1)
    {
      ((NSPoint)localObject).x = localAccessibleControlEvent.x;
      ((NSPoint)localObject).y = (localMonitor.getBounds().height - localAccessibleControlEvent.y - localAccessibleControlEvent.height);
      localNSValue = NSValue.valueWithPoint((NSPoint)localObject);
    }
    else if (paramInt != -1)
    {
      Point localPoint = null;
      Rectangle localRectangle = this.control.getBounds();
      if (this.control.getParent() != null) {
        localPoint = this.control.getParent().toDisplay(localRectangle.x, localRectangle.y);
      } else {
        localPoint = ((Shell)this.control).toDisplay(localRectangle.x, localRectangle.y);
      }
      ((NSPoint)localObject).x = localPoint.x;
      ((NSPoint)localObject).y = localPoint.y;
      localNSValue = NSValue.valueWithPoint((NSPoint)localObject);
    }
    return localNSValue;
  }
  
  id getSizeAttribute(int paramInt)
  {
    NSValue localNSValue = null;
    AccessibleControlEvent localAccessibleControlEvent = new AccessibleControlEvent(this);
    localAccessibleControlEvent.childID = paramInt;
    localAccessibleControlEvent.width = -1;
    for (int i = 0; i < accessibleControlListenersSize(); i++)
    {
      AccessibleControlListener localAccessibleControlListener = (AccessibleControlListener)this.accessibleControlListeners.elementAt(i);
      localAccessibleControlListener.getLocation(localAccessibleControlEvent);
    }
    NSSize localNSSize = new NSSize();
    if (localAccessibleControlEvent.width != -1)
    {
      localNSSize.width = localAccessibleControlEvent.width;
      localNSSize.height = localAccessibleControlEvent.height;
      localNSValue = NSValue.valueWithSize(localNSSize);
    }
    else if (paramInt != -1)
    {
      localNSSize.width = (localNSSize.height = 0.0D);
      localNSValue = NSValue.valueWithSize(localNSSize);
    }
    return localNSValue;
  }
  
  id getCellForColumnAndRowParameter(id paramid, int paramInt)
  {
    SWTAccessibleDelegate localSWTAccessibleDelegate = null;
    NSArray localNSArray = new NSArray(paramid.id);
    if (localNSArray.count() == 2L)
    {
      AccessibleTableEvent localAccessibleTableEvent = new AccessibleTableEvent(this);
      localAccessibleTableEvent.column = new NSNumber(localNSArray.objectAtIndex(0L)).intValue();
      localAccessibleTableEvent.row = new NSNumber(localNSArray.objectAtIndex(1L)).intValue();
      for (int i = 0; i < accessibleTableListenersSize(); i++)
      {
        AccessibleTableListener localAccessibleTableListener = (AccessibleTableListener)this.accessibleTableListeners.elementAt(i);
        localAccessibleTableListener.getCell(localAccessibleTableEvent);
        localSWTAccessibleDelegate = localAccessibleTableEvent.accessible.delegate;
      }
    }
    return localSWTAccessibleDelegate;
  }
  
  id getDescriptionAttribute(int paramInt)
  {
    AccessibleEvent localAccessibleEvent = new AccessibleEvent(this);
    localAccessibleEvent.childID = paramInt;
    localAccessibleEvent.result = null;
    NSString localNSString = null;
    for (int i = 0; i < accessibleListenersSize(); i++)
    {
      AccessibleListener localAccessibleListener = (AccessibleListener)this.accessibleListeners.elementAt(i);
      localAccessibleListener.getDescription(localAccessibleEvent);
    }
    localNSString = localAccessibleEvent.result != null ? NSString.stringWith(localAccessibleEvent.result) : null;
    if ((localNSString == null) && ((this.control instanceof Composite))) {
      localNSString = NSString.string();
    }
    return localNSString;
  }
  
  id getInsertionPointLineNumberAttribute(int paramInt)
  {
    NSNumber localNSNumber = null;
    Object localObject1;
    int i;
    Object localObject2;
    if (accessibleTextExtendedListenersSize() > 0)
    {
      localObject1 = new AccessibleTextEvent(this);
      ((AccessibleTextEvent)localObject1).childID = paramInt;
      for (i = 0; i < accessibleTextExtendedListenersSize(); i++)
      {
        AccessibleTextExtendedListener localAccessibleTextExtendedListener = (AccessibleTextExtendedListener)this.accessibleTextExtendedListeners.elementAt(i);
        localAccessibleTextExtendedListener.getCaretOffset((AccessibleTextEvent)localObject1);
      }
      i = ((AccessibleTextEvent)localObject1).offset;
      ((AccessibleTextEvent)localObject1).start = i;
      ((AccessibleTextEvent)localObject1).end = i;
      ((AccessibleTextEvent)localObject1).count = Integer.MIN_VALUE;
      ((AccessibleTextEvent)localObject1).type = 4;
      for (int j = 0; j < accessibleTextExtendedListenersSize(); j++)
      {
        localObject2 = (AccessibleTextExtendedListener)this.accessibleTextExtendedListeners.elementAt(j);
        ((AccessibleTextExtendedListener)localObject2).getText((AccessibleTextEvent)localObject1);
      }
      localNSNumber = NSNumber.numberWithInt(Math.max(0, -((AccessibleTextEvent)localObject1).count));
    }
    else
    {
      localObject1 = new AccessibleControlEvent(this);
      ((AccessibleControlEvent)localObject1).childID = paramInt;
      ((AccessibleControlEvent)localObject1).result = null;
      for (i = 0; i < accessibleControlListenersSize(); i++)
      {
        AccessibleControlListener localAccessibleControlListener = (AccessibleControlListener)this.accessibleControlListeners.elementAt(i);
        localAccessibleControlListener.getValue((AccessibleControlEvent)localObject1);
      }
      AccessibleTextEvent localAccessibleTextEvent = new AccessibleTextEvent(this);
      localAccessibleTextEvent.childID = paramInt;
      localAccessibleTextEvent.offset = -1;
      for (int k = 0; k < accessibleTextListenersSize(); k++)
      {
        localObject2 = (AccessibleTextListener)this.accessibleTextListeners.elementAt(k);
        ((AccessibleTextListener)localObject2).getCaretOffset(localAccessibleTextEvent);
      }
      if ((((AccessibleControlEvent)localObject1).result != null) && (localAccessibleTextEvent.offset != -1))
      {
        k = lineNumberForOffset(((AccessibleControlEvent)localObject1).result, localAccessibleTextEvent.offset);
        localNSNumber = NSNumber.numberWithInt(k);
      }
    }
    return localNSNumber;
  }
  
  id getLineForIndexParameterizedAttribute(id paramid, int paramInt)
  {
    NSNumber localNSNumber1 = null;
    NSNumber localNSNumber2 = new NSNumber(paramid.id);
    int i = localNSNumber2.intValue();
    Object localObject1;
    int j;
    Object localObject2;
    if (accessibleTextExtendedListenersSize() > 0)
    {
      localObject1 = new AccessibleTextEvent(this);
      ((AccessibleTextEvent)localObject1).childID = paramInt;
      ((AccessibleTextEvent)localObject1).start = i;
      ((AccessibleTextEvent)localObject1).end = i;
      ((AccessibleTextEvent)localObject1).count = Integer.MIN_VALUE;
      ((AccessibleTextEvent)localObject1).type = 4;
      for (j = 0; j < accessibleTextExtendedListenersSize(); j++)
      {
        localObject2 = (AccessibleTextExtendedListener)this.accessibleTextExtendedListeners.elementAt(j);
        ((AccessibleTextExtendedListener)localObject2).getText((AccessibleTextEvent)localObject1);
      }
      localNSNumber1 = NSNumber.numberWithInt(Math.max(0, -((AccessibleTextEvent)localObject1).count));
    }
    else
    {
      localObject1 = new AccessibleControlEvent(this);
      ((AccessibleControlEvent)localObject1).childID = paramInt;
      ((AccessibleControlEvent)localObject1).result = null;
      for (j = 0; j < accessibleControlListenersSize(); j++)
      {
        localObject2 = (AccessibleControlListener)this.accessibleControlListeners.elementAt(j);
        ((AccessibleControlListener)localObject2).getValue((AccessibleControlEvent)localObject1);
      }
      String str = ((AccessibleControlEvent)localObject1).result;
      if (str != null) {
        localNSNumber1 = NSNumber.numberWithInt(lineNumberForOffset(str, i));
      }
    }
    return localNSNumber1;
  }
  
  id getMaxValueAttribute(int paramInt)
  {
    NSNumber localNSNumber = null;
    if (accessibleValueListenersSize() > 0)
    {
      AccessibleValueEvent localAccessibleValueEvent = new AccessibleValueEvent(this);
      for (int i = 0; i < accessibleValueListenersSize(); i++)
      {
        AccessibleValueListener localAccessibleValueListener = (AccessibleValueListener)this.accessibleValueListeners.elementAt(i);
        localAccessibleValueListener.getMaximumValue(localAccessibleValueEvent);
      }
      localNSNumber = NSNumber.numberWithDouble(localAccessibleValueEvent.value.doubleValue());
    }
    return localNSNumber;
  }
  
  id getMinValueAttribute(int paramInt)
  {
    NSNumber localNSNumber = null;
    if (accessibleValueListenersSize() > 0)
    {
      AccessibleValueEvent localAccessibleValueEvent = new AccessibleValueEvent(this);
      for (int i = 0; i < accessibleValueListenersSize(); i++)
      {
        AccessibleValueListener localAccessibleValueListener = (AccessibleValueListener)this.accessibleValueListeners.elementAt(i);
        localAccessibleValueListener.getMinimumValue(localAccessibleValueEvent);
      }
      localNSNumber = NSNumber.numberWithDouble(localAccessibleValueEvent.value.doubleValue());
    }
    return localNSNumber;
  }
  
  id getNumberOfCharactersAttribute(int paramInt)
  {
    NSNumber localNSNumber = null;
    AccessibleTextEvent localAccessibleTextEvent = new AccessibleTextEvent(this);
    localAccessibleTextEvent.count = -1;
    for (int i = 0; i < accessibleTextExtendedListenersSize(); i++)
    {
      AccessibleTextExtendedListener localAccessibleTextExtendedListener = (AccessibleTextExtendedListener)this.accessibleTextExtendedListeners.elementAt(i);
      localAccessibleTextExtendedListener.getCharacterCount(localAccessibleTextEvent);
    }
    if (localAccessibleTextEvent.count != -1)
    {
      AccessibleControlEvent localAccessibleControlEvent = new AccessibleControlEvent(this);
      localAccessibleControlEvent.childID = -1;
      for (int j = 0; j < accessibleControlListenersSize(); j++)
      {
        AccessibleControlListener localAccessibleControlListener = (AccessibleControlListener)this.accessibleControlListeners.elementAt(j);
        localAccessibleControlListener.getRole(localAccessibleControlEvent);
        localAccessibleControlListener.getValue(localAccessibleControlEvent);
      }
      localAccessibleTextEvent.count = ((localAccessibleControlEvent.detail == 42) && (localAccessibleControlEvent.result != null) ? localAccessibleControlEvent.result.length() : 0);
      localNSNumber = NSNumber.numberWithInt(localAccessibleTextEvent.count);
    }
    return localNSNumber;
  }
  
  id getRangeForLineParameterizedAttribute(id paramid, int paramInt)
  {
    NSValue localNSValue = null;
    NSNumber localNSNumber = new NSNumber(paramid.id);
    int i = localNSNumber.intValue();
    Object localObject1;
    Object localObject2;
    if (accessibleTextExtendedListenersSize() > 0)
    {
      localObject1 = new AccessibleTextEvent(this);
      ((AccessibleTextEvent)localObject1).childID = paramInt;
      ((AccessibleTextEvent)localObject1).start = (((AccessibleTextEvent)localObject1).end = 0);
      ((AccessibleTextEvent)localObject1).count = i;
      ((AccessibleTextEvent)localObject1).type = 4;
      for (int j = 0; j < accessibleTextExtendedListenersSize(); j++)
      {
        localObject2 = (AccessibleTextExtendedListener)this.accessibleTextExtendedListeners.elementAt(j);
        ((AccessibleTextExtendedListener)localObject2).getText((AccessibleTextEvent)localObject1);
      }
      NSRange localNSRange1 = new NSRange();
      localNSRange1.location = ((AccessibleTextEvent)localObject1).start;
      localNSRange1.length = (((AccessibleTextEvent)localObject1).end - ((AccessibleTextEvent)localObject1).start);
      localNSValue = NSValue.valueWithRange(localNSRange1);
    }
    else if (accessibleControlListenersSize() > 0)
    {
      localObject1 = new AccessibleControlEvent(this);
      ((AccessibleControlEvent)localObject1).childID = paramInt;
      ((AccessibleControlEvent)localObject1).result = null;
      for (int k = 0; k < accessibleControlListenersSize(); k++)
      {
        localObject2 = (AccessibleControlListener)this.accessibleControlListeners.elementAt(k);
        ((AccessibleControlListener)localObject2).getValue((AccessibleControlEvent)localObject1);
      }
      if (((AccessibleControlEvent)localObject1).result != null)
      {
        NSRange localNSRange2 = rangeForLineNumber(i, ((AccessibleControlEvent)localObject1).result);
        if (localNSRange2.location != -1L) {
          localNSValue = NSValue.valueWithRange(localNSRange2);
        }
      }
    }
    return localNSValue;
  }
  
  id getRangeForIndexParameterizedAttribute(id paramid, int paramInt)
  {
    NSValue localNSValue = null;
    NSNumber localNSNumber = new NSNumber(paramid.id);
    int i = localNSNumber.intValue();
    if (accessibleTextExtendedListenersSize() > 0)
    {
      AccessibleTextEvent localAccessibleTextEvent = new AccessibleTextEvent(this);
      localAccessibleTextEvent.childID = paramInt;
      localAccessibleTextEvent.start = (localAccessibleTextEvent.end = 0);
      localAccessibleTextEvent.count = i;
      localAccessibleTextEvent.type = 0;
      for (int j = 0; j < accessibleTextExtendedListenersSize(); j++)
      {
        AccessibleTextExtendedListener localAccessibleTextExtendedListener = (AccessibleTextExtendedListener)this.accessibleTextExtendedListeners.elementAt(j);
        localAccessibleTextExtendedListener.getText(localAccessibleTextEvent);
      }
      NSRange localNSRange = new NSRange();
      localNSRange.location = localAccessibleTextEvent.start;
      localNSRange.length = (localAccessibleTextEvent.end - localAccessibleTextEvent.start);
      localNSValue = NSValue.valueWithRange(localNSRange);
    }
    else if (accessibleControlListenersSize() <= 0) {}
    return localNSValue;
  }
  
  id getSelectedTextAttribute(int paramInt)
  {
    NSString localNSString = NSString.string();
    AccessibleTextEvent localAccessibleTextEvent;
    int i;
    Object localObject;
    if (accessibleTextExtendedListenersSize() > 0)
    {
      localAccessibleTextEvent = new AccessibleTextEvent(this);
      localAccessibleTextEvent.childID = paramInt;
      localAccessibleTextEvent.index = 0;
      for (i = 0; i < accessibleTextExtendedListenersSize(); i++)
      {
        AccessibleTextExtendedListener localAccessibleTextExtendedListener1 = (AccessibleTextExtendedListener)this.accessibleTextExtendedListeners.elementAt(i);
        localAccessibleTextExtendedListener1.getSelection(localAccessibleTextEvent);
      }
      i = localAccessibleTextEvent.start;
      int j = localAccessibleTextEvent.end;
      if (i != j)
      {
        localAccessibleTextEvent.type = 5;
        for (int m = 0; m < accessibleTextExtendedListenersSize(); m++)
        {
          AccessibleTextExtendedListener localAccessibleTextExtendedListener2 = (AccessibleTextExtendedListener)this.accessibleTextExtendedListeners.elementAt(m);
          localAccessibleTextExtendedListener2.getText(localAccessibleTextEvent);
        }
      }
      localObject = localAccessibleTextEvent.result;
      if (localObject != null) {
        localNSString = NSString.stringWith((String)localObject);
      }
    }
    else if (accessibleTextListenersSize() > 0)
    {
      localAccessibleTextEvent = new AccessibleTextEvent(this);
      localAccessibleTextEvent.childID = paramInt;
      localAccessibleTextEvent.offset = -1;
      localAccessibleTextEvent.length = -1;
      for (i = 0; i < accessibleTextListenersSize(); i++)
      {
        AccessibleTextListener localAccessibleTextListener = (AccessibleTextListener)this.accessibleTextListeners.elementAt(i);
        localAccessibleTextListener.getSelectionRange(localAccessibleTextEvent);
      }
      i = localAccessibleTextEvent.offset;
      int k = localAccessibleTextEvent.length;
      if ((i != -1) && (k != -1) && (k != 0))
      {
        localObject = new AccessibleControlEvent(this);
        ((AccessibleControlEvent)localObject).childID = localAccessibleTextEvent.childID;
        ((AccessibleControlEvent)localObject).result = null;
        for (int n = 0; n < accessibleControlListenersSize(); n++)
        {
          AccessibleControlListener localAccessibleControlListener = (AccessibleControlListener)this.accessibleControlListeners.elementAt(n);
          localAccessibleControlListener.getValue((AccessibleControlEvent)localObject);
        }
        String str = ((AccessibleControlEvent)localObject).result;
        if (str != null) {
          localNSString = NSString.stringWith(str.substring(i, i + k));
        }
      }
    }
    return localNSString;
  }
  
  id getSelectedTextRangeAttribute(int paramInt)
  {
    NSValue localNSValue = null;
    AccessibleTextEvent localAccessibleTextEvent;
    Object localObject;
    if (accessibleTextExtendedListenersSize() > 0)
    {
      localAccessibleTextEvent = new AccessibleTextEvent(this);
      localAccessibleTextEvent.childID = paramInt;
      localAccessibleTextEvent.index = 0;
      for (int i = 0; i < accessibleTextExtendedListenersSize(); i++)
      {
        localObject = (AccessibleTextExtendedListener)this.accessibleTextExtendedListeners.elementAt(i);
        ((AccessibleTextExtendedListener)localObject).getSelection(localAccessibleTextEvent);
      }
      NSRange localNSRange1 = new NSRange();
      localNSRange1.location = localAccessibleTextEvent.start;
      localNSRange1.length = (localAccessibleTextEvent.end - localAccessibleTextEvent.start);
      localNSValue = NSValue.valueWithRange(localNSRange1);
    }
    else if (accessibleTextExtendedListenersSize() > 0)
    {
      localAccessibleTextEvent = new AccessibleTextEvent(this);
      localAccessibleTextEvent.childID = paramInt;
      localAccessibleTextEvent.offset = -1;
      localAccessibleTextEvent.length = 0;
      for (int j = 0; j < accessibleTextListenersSize(); j++)
      {
        localObject = (AccessibleTextListener)this.accessibleTextListeners.elementAt(j);
        ((AccessibleTextListener)localObject).getSelectionRange(localAccessibleTextEvent);
      }
      if (localAccessibleTextEvent.offset != -1)
      {
        NSRange localNSRange2 = new NSRange();
        localNSRange2.location = localAccessibleTextEvent.offset;
        localNSRange2.length = localAccessibleTextEvent.length;
        localNSValue = NSValue.valueWithRange(localNSRange2);
      }
    }
    return localNSValue;
  }
  
  id getServesAsTitleForUIElementsAttribute(int paramInt)
  {
    id localid = null;
    Relation localRelation = this.relations[8];
    if (localRelation != null) {
      localid = localRelation.getServesAsTitleForUIElements();
    }
    return localid;
  }
  
  id getStringForRangeParameterizedAttribute(id paramid, int paramInt)
  {
    NSString localNSString = null;
    NSValue localNSValue = new NSValue(paramid.id);
    NSRange localNSRange = localNSValue.rangeValue();
    Object localObject1;
    int i;
    Object localObject2;
    if (accessibleTextExtendedListenersSize() > 0)
    {
      localObject1 = new AccessibleTextEvent(this);
      ((AccessibleTextEvent)localObject1).childID = paramInt;
      ((AccessibleTextEvent)localObject1).start = ((int)localNSRange.location);
      ((AccessibleTextEvent)localObject1).end = ((int)(localNSRange.location + localNSRange.length));
      ((AccessibleTextEvent)localObject1).type = 5;
      for (i = 0; i < accessibleTextExtendedListenersSize(); i++)
      {
        localObject2 = (AccessibleTextExtendedListener)this.accessibleTextExtendedListeners.elementAt(i);
        ((AccessibleTextExtendedListener)localObject2).getText((AccessibleTextEvent)localObject1);
      }
      if (((AccessibleTextEvent)localObject1).result != null) {
        localNSString = NSString.stringWith(((AccessibleTextEvent)localObject1).result);
      }
    }
    else if (accessibleControlListenersSize() > 0)
    {
      localObject1 = new AccessibleControlEvent(this);
      ((AccessibleControlEvent)localObject1).childID = paramInt;
      ((AccessibleControlEvent)localObject1).result = null;
      for (i = 0; i < accessibleControlListenersSize(); i++)
      {
        localObject2 = (AccessibleControlListener)this.accessibleControlListeners.elementAt(i);
        ((AccessibleControlListener)localObject2).getValue((AccessibleControlEvent)localObject1);
      }
      String str = ((AccessibleControlEvent)localObject1).result;
      if (str != null) {
        localNSString = NSString.stringWith(str.substring((int)localNSRange.location, (int)(localNSRange.location + localNSRange.length)));
      }
    }
    return localNSString;
  }
  
  id getSelectedTextRangesAttribute(int paramInt)
  {
    NSMutableArray localNSMutableArray = NSMutableArray.arrayWithCapacity(3L);
    AccessibleTextEvent localAccessibleTextEvent;
    int i;
    Object localObject;
    if (accessibleTextExtendedListenersSize() > 0)
    {
      localAccessibleTextEvent = new AccessibleTextEvent(this);
      localAccessibleTextEvent.childID = paramInt;
      for (i = 0; i < accessibleTextExtendedListenersSize(); i++)
      {
        AccessibleTextExtendedListener localAccessibleTextExtendedListener1 = (AccessibleTextExtendedListener)this.accessibleTextExtendedListeners.elementAt(i);
        localAccessibleTextExtendedListener1.getSelectionCount(localAccessibleTextEvent);
      }
      if (localAccessibleTextEvent.count > 0) {
        for (i = 0; i < localAccessibleTextEvent.count; i++)
        {
          localAccessibleTextEvent.index = i;
          for (int j = 0; j < accessibleTextExtendedListenersSize(); j++)
          {
            AccessibleTextExtendedListener localAccessibleTextExtendedListener2 = (AccessibleTextExtendedListener)this.accessibleTextExtendedListeners.elementAt(j);
            localAccessibleTextExtendedListener2.getSelection(localAccessibleTextEvent);
          }
          localObject = new NSRange();
          ((NSRange)localObject).location = localAccessibleTextEvent.start;
          ((NSRange)localObject).length = (localAccessibleTextEvent.end - localAccessibleTextEvent.start);
          localNSMutableArray.addObject(NSValue.valueWithRange((NSRange)localObject));
        }
      }
    }
    else if (accessibleTextListenersSize() > 0)
    {
      localAccessibleTextEvent = new AccessibleTextEvent(this);
      localAccessibleTextEvent.childID = paramInt;
      localAccessibleTextEvent.offset = -1;
      localAccessibleTextEvent.length = 0;
      for (i = 0; i < accessibleTextListenersSize(); i++)
      {
        localObject = (AccessibleTextListener)this.accessibleTextListeners.elementAt(i);
        ((AccessibleTextListener)localObject).getSelectionRange(localAccessibleTextEvent);
      }
      if (localAccessibleTextEvent.offset != -1)
      {
        NSRange localNSRange = new NSRange();
        localNSRange.location = localAccessibleTextEvent.offset;
        localNSRange.length = localAccessibleTextEvent.length;
        localNSMutableArray.addObject(NSValue.valueWithRange(localNSRange));
      }
    }
    if (localNSMutableArray.count() == 0L) {
      localNSMutableArray.addObject(NSValue.valueWithRange(new NSRange()));
    }
    return localNSMutableArray;
  }
  
  id getStyleRangeForIndexAttribute(id paramid, int paramInt)
  {
    if (accessibleAttributeListenersSize() == 0) {
      return null;
    }
    NSNumber localNSNumber = new NSNumber(paramid.id);
    int i = localNSNumber.intValue();
    AccessibleTextAttributeEvent localAccessibleTextAttributeEvent = new AccessibleTextAttributeEvent(this);
    localAccessibleTextAttributeEvent.offset = i;
    localAccessibleTextAttributeEvent.start = (localAccessibleTextAttributeEvent.end = -1);
    for (int j = 0; j < accessibleAttributeListenersSize(); j++)
    {
      AccessibleAttributeListener localAccessibleAttributeListener = (AccessibleAttributeListener)this.accessibleAttributeListeners.elementAt(j);
      localAccessibleAttributeListener.getTextAttributes(localAccessibleTextAttributeEvent);
    }
    NSRange localNSRange = new NSRange();
    if ((localAccessibleTextAttributeEvent.start == -1) && (localAccessibleTextAttributeEvent.end == -1))
    {
      localNSRange.location = i;
      localNSRange.length = 0L;
    }
    else
    {
      localNSRange.location = localAccessibleTextAttributeEvent.start;
      localNSRange.length = (localAccessibleTextAttributeEvent.end - localAccessibleTextAttributeEvent.start);
    }
    return NSValue.valueWithRange(localNSRange);
  }
  
  id getVisibleCharacterRangeAttribute(int paramInt)
  {
    NSRange localNSRange = null;
    Object localObject1;
    int i;
    Object localObject2;
    if (accessibleTextExtendedListenersSize() > 0)
    {
      localObject1 = new AccessibleTextEvent(this);
      ((AccessibleTextEvent)localObject1).childID = paramInt;
      for (i = 0; i < accessibleTextExtendedListenersSize(); i++)
      {
        localObject2 = (AccessibleTextExtendedListener)this.accessibleTextExtendedListeners.elementAt(i);
        ((AccessibleTextExtendedListener)localObject2).getVisibleRanges((AccessibleTextEvent)localObject1);
      }
      localNSRange = new NSRange();
      localNSRange.location = ((AccessibleTextEvent)localObject1).start;
      localNSRange.length = (((AccessibleTextEvent)localObject1).end - ((AccessibleTextEvent)localObject1).start);
    }
    else if (accessibleControlListenersSize() > 0)
    {
      localObject1 = new AccessibleControlEvent(this);
      ((AccessibleControlEvent)localObject1).childID = paramInt;
      ((AccessibleControlEvent)localObject1).result = null;
      for (i = 0; i < accessibleControlListenersSize(); i++)
      {
        localObject2 = (AccessibleControlListener)this.accessibleControlListeners.elementAt(i);
        ((AccessibleControlListener)localObject2).getValue((AccessibleControlEvent)localObject1);
      }
      if (((AccessibleControlEvent)localObject1).result != null)
      {
        localNSRange = new NSRange();
        localNSRange.location = 0L;
        localNSRange.length = ((AccessibleControlEvent)localObject1).result.length();
      }
    }
    return localNSRange != null ? NSValue.valueWithRange(localNSRange) : null;
  }
  
  int lineNumberForOffset(String paramString, int paramInt)
  {
    int i = 1;
    int j = paramString.length();
    for (int k = 0; k < paramInt; k++) {
      switch (paramString.charAt(k))
      {
      case '\r': 
        if ((k + 1 < j) && (paramString.charAt(k + 1) == '\n')) {
          k++;
        }
      case '\n': 
        i++;
      }
    }
    return i;
  }
  
  NSRange rangeForLineNumber(int paramInt, String paramString)
  {
    NSRange localNSRange = new NSRange();
    localNSRange.location = -1L;
    int i = 1;
    int j = 0;
    int k = paramString.length();
    for (int m = 0; m < k; m++)
    {
      if (i == paramInt)
      {
        if (j == 0) {
          localNSRange.location = m;
        }
        j++;
      }
      if (i > paramInt) {
        break;
      }
      switch (paramString.charAt(m))
      {
      case '\r': 
        if ((m + 1 < k) && (paramString.charAt(m + 1) == '\n')) {
          m++;
        }
      case '\n': 
        i++;
      }
    }
    localNSRange.length = j;
    return localNSRange;
  }
  
  public void removeAccessibleListener(AccessibleListener paramAccessibleListener)
  {
    checkWidget();
    if (paramAccessibleListener == null) {
      SWT.error(4);
    }
    if (this.accessibleListeners != null)
    {
      this.accessibleListeners.removeElement(paramAccessibleListener);
      if (this.accessibleListeners.isEmpty()) {
        this.accessibleListeners = null;
      }
    }
  }
  
  public void removeAccessibleControlListener(AccessibleControlListener paramAccessibleControlListener)
  {
    checkWidget();
    if (paramAccessibleControlListener == null) {
      SWT.error(4);
    }
    if (this.accessibleControlListeners != null)
    {
      this.accessibleControlListeners.removeElement(paramAccessibleControlListener);
      if (this.accessibleControlListeners.isEmpty()) {
        this.accessibleControlListeners = null;
      }
    }
  }
  
  public void removeAccessibleTextListener(AccessibleTextListener paramAccessibleTextListener)
  {
    checkWidget();
    if (paramAccessibleTextListener == null) {
      SWT.error(4);
    }
    if ((paramAccessibleTextListener instanceof AccessibleTextExtendedListener))
    {
      if (this.accessibleTextExtendedListeners != null)
      {
        this.accessibleTextExtendedListeners.removeElement(paramAccessibleTextListener);
        if (this.accessibleTextExtendedListeners.isEmpty()) {
          this.accessibleTextExtendedListeners = null;
        }
      }
    }
    else if (this.accessibleTextListeners != null)
    {
      this.accessibleTextListeners.removeElement(paramAccessibleTextListener);
      if (this.accessibleTextListeners.isEmpty()) {
        this.accessibleTextListeners = null;
      }
    }
  }
  
  public void removeAccessibleActionListener(AccessibleActionListener paramAccessibleActionListener)
  {
    checkWidget();
    if (paramAccessibleActionListener == null) {
      SWT.error(4);
    }
    if (this.accessibleActionListeners != null)
    {
      this.accessibleActionListeners.removeElement(paramAccessibleActionListener);
      if (this.accessibleActionListeners.isEmpty()) {
        this.accessibleActionListeners = null;
      }
    }
  }
  
  public void removeAccessibleEditableTextListener(AccessibleEditableTextListener paramAccessibleEditableTextListener)
  {
    checkWidget();
    if (paramAccessibleEditableTextListener == null) {
      SWT.error(4);
    }
    if (this.accessibleEditableTextListeners != null)
    {
      this.accessibleEditableTextListeners.removeElement(paramAccessibleEditableTextListener);
      if (this.accessibleEditableTextListeners.isEmpty()) {
        this.accessibleEditableTextListeners = null;
      }
    }
  }
  
  public void removeAccessibleHyperlinkListener(AccessibleHyperlinkListener paramAccessibleHyperlinkListener)
  {
    checkWidget();
    if (paramAccessibleHyperlinkListener == null) {
      SWT.error(4);
    }
    if (this.accessibleHyperlinkListeners != null)
    {
      this.accessibleHyperlinkListeners.removeElement(paramAccessibleHyperlinkListener);
      if (this.accessibleHyperlinkListeners.isEmpty()) {
        this.accessibleHyperlinkListeners = null;
      }
    }
  }
  
  public void removeAccessibleTableListener(AccessibleTableListener paramAccessibleTableListener)
  {
    checkWidget();
    if (paramAccessibleTableListener == null) {
      SWT.error(4);
    }
    if (this.accessibleTableListeners != null)
    {
      this.accessibleTableListeners.removeElement(paramAccessibleTableListener);
      if (this.accessibleTableListeners.isEmpty()) {
        this.accessibleTableListeners = null;
      }
    }
  }
  
  public void removeAccessibleTableCellListener(AccessibleTableCellListener paramAccessibleTableCellListener)
  {
    checkWidget();
    if (paramAccessibleTableCellListener == null) {
      SWT.error(4);
    }
    if (this.accessibleTableCellListeners != null)
    {
      this.accessibleTableCellListeners.removeElement(paramAccessibleTableCellListener);
      if (this.accessibleTableCellListeners.isEmpty()) {
        this.accessibleTableCellListeners = null;
      }
    }
  }
  
  public void removeAccessibleValueListener(AccessibleValueListener paramAccessibleValueListener)
  {
    checkWidget();
    if (paramAccessibleValueListener == null) {
      SWT.error(4);
    }
    if (this.accessibleValueListeners != null)
    {
      this.accessibleValueListeners.removeElement(paramAccessibleValueListener);
      if (this.accessibleValueListeners.isEmpty()) {
        this.accessibleValueListeners = null;
      }
    }
  }
  
  public void removeAccessibleAttributeListener(AccessibleAttributeListener paramAccessibleAttributeListener)
  {
    checkWidget();
    if (paramAccessibleAttributeListener == null) {
      SWT.error(4);
    }
    if (this.accessibleAttributeListeners != null)
    {
      this.accessibleAttributeListeners.removeElement(paramAccessibleAttributeListener);
      if (this.accessibleAttributeListeners.isEmpty()) {
        this.accessibleAttributeListeners = null;
      }
    }
  }
  
  public void removeRelation(int paramInt, Accessible paramAccessible)
  {
    checkWidget();
    if (this.relations[paramInt] != null) {
      this.relations[paramInt].removeTarget(paramAccessible);
    }
  }
  
  void release(boolean paramBoolean)
  {
    if (this.actionNames != null) {
      this.actionNames.release();
    }
    this.actionNames = null;
    if (this.attributeNames != null) {
      this.attributeNames.release();
    }
    this.attributeNames = null;
    if (this.parameterizedAttributeNames != null) {
      this.parameterizedAttributeNames.release();
    }
    this.parameterizedAttributeNames = null;
    if (this.delegate != null)
    {
      this.delegate.internal_dispose_SWTAccessibleDelegate();
      this.delegate.release();
    }
    this.delegate = null;
    this.relations = null;
    if (this.childToIdMap != null)
    {
      Collection localCollection = this.childToIdMap.values();
      Iterator localIterator = localCollection.iterator();
      while (localIterator.hasNext())
      {
        SWTAccessibleDelegate localSWTAccessibleDelegate = (SWTAccessibleDelegate)localIterator.next();
        localSWTAccessibleDelegate.internal_dispose_SWTAccessibleDelegate();
        localSWTAccessibleDelegate.release();
      }
      this.childToIdMap.clear();
      this.childToIdMap = null;
    }
    if (this.tableDelegate != null) {
      this.tableDelegate.release();
    }
  }
  
  static NSArray retainedAutoreleased(NSArray paramNSArray)
  {
    id localid = paramNSArray.retain();
    NSObject localNSObject = new NSObject(localid.id).autorelease();
    return new NSArray(localNSObject.id);
  }
  
  public void sendEvent(int paramInt, Object paramObject)
  {
    checkWidget();
    id localid = accessibleHandle(this);
    if (DEBUG) {
      System.out.println("sendEvent: 0x" + Integer.toHexString(paramInt) + ", data = " + paramObject + ", source = " + localid);
    }
    switch (paramInt)
    {
    case 256: 
    case 264: 
    case 265: 
    case 266: 
    case 267: 
    case 269: 
    case 271: 
    case 273: 
    case 274: 
    case 285: 
    case 512: 
    case 515: 
    case 516: 
    case 517: 
    case 519: 
    case 520: 
    case 521: 
    case 522: 
    case 524: 
    case 32778: 
    case 32782: 
      OS.NSAccessibilityPostNotification(localid.id, OS.NSAccessibilityValueChangedNotification.id);
      break;
    case 32777: 
      OS.NSAccessibilityPostNotification(localid.id, OS.NSAccessibilitySelectedChildrenChangedNotification.id);
      break;
    case 32788: 
      OS.NSAccessibilityPostNotification(localid.id, OS.NSAccessibilitySelectedTextChangedNotification.id);
      break;
    case 32779: 
      OS.NSAccessibilityPostNotification(localid.id, OS.NSAccessibilityMovedNotification.id);
      break;
    case 32780: 
    case 32781: 
      OS.NSAccessibilityPostNotification(localid.id, OS.NSAccessibilityTitleChangedNotification.id);
      break;
    case 283: 
      OS.NSAccessibilityPostNotification(localid.id, OS.NSAccessibilitySelectedTextChangedNotification.id);
      break;
    case 518: 
      if (this.tableDelegate != null)
      {
        this.tableDelegate.reset();
        getRowsAttribute(-1);
        getColumnsAttribute(-1);
      }
      if (paramObject != null)
      {
        int[] arrayOfInt = (int[])paramObject;
        if (arrayOfInt[2] != 0) {
          OS.NSAccessibilityPostNotification(localid.id, OS.NSAccessibilityRowCountChangedNotification.id);
        }
      }
      break;
    }
  }
  
  public void sendEvent(int paramInt1, Object paramObject, int paramInt2)
  {
    checkWidget();
    id localid = childIDToOs(paramInt2);
    if (DEBUG) {
      System.out.println("sendEvent: 0x" + Integer.toHexString(paramInt1) + ", data = " + paramObject + ", source = " + localid);
    }
    switch (paramInt1)
    {
    case 32777: 
    case 32778: 
    case 32782: 
      OS.NSAccessibilityPostNotification(localid.id, OS.NSAccessibilitySelectedChildrenChangedNotification.id);
      break;
    case 32788: 
      OS.NSAccessibilityPostNotification(localid.id, OS.NSAccessibilitySelectedTextChangedNotification.id);
      break;
    case 32779: 
      OS.NSAccessibilityPostNotification(localid.id, OS.NSAccessibilityMovedNotification.id);
      break;
    case 32780: 
    case 32781: 
      OS.NSAccessibilityPostNotification(localid.id, OS.NSAccessibilityTitleChangedNotification.id);
    }
  }
  
  public void selectionChanged()
  {
    checkWidget();
    id localid = accessibleHandle(this);
    if (DEBUG) {
      System.out.println("selectionChanged on " + localid);
    }
    if (this.currentRole == 24) {
      OS.NSAccessibilityPostNotification(localid.id, OS.NSAccessibilitySelectedRowsChangedNotification.id);
    } else {
      OS.NSAccessibilityPostNotification(localid.id, OS.NSAccessibilitySelectedChildrenChangedNotification.id);
    }
  }
  
  public void setFocus(int paramInt)
  {
    checkWidget();
    id localid = childIDToOs(paramInt);
    if (DEBUG) {
      System.out.println("setFocus on " + localid);
    }
    OS.NSAccessibilityPostNotification(localid.id, OS.NSAccessibilityFocusedUIElementChangedNotification.id);
  }
  
  void setSelectedTextAttribute(id paramid, int paramInt)
  {
    NSString localNSString = new NSString(paramid.id);
    int i = 0;
    id localid1 = getNumberOfCharactersAttribute(paramInt);
    int j = new NSNumber(localid1).intValue();
    id localid2 = getSelectedTextRangeAttribute(paramInt);
    Object localObject;
    if (localid2 != null)
    {
      localObject = new NSValue(localid2).rangeValue();
      i = (int)((NSRange)localObject).location;
      j = (int)(((NSRange)localObject).location + ((NSRange)localObject).length);
    }
    if (accessibleEditableTextListenersSize() > 0)
    {
      localObject = new AccessibleEditableTextEvent(this);
      ((AccessibleEditableTextEvent)localObject).start = i;
      ((AccessibleEditableTextEvent)localObject).end = j;
      ((AccessibleEditableTextEvent)localObject).string = localNSString.getString();
      for (int k = 0; k < accessibleEditableTextListenersSize(); k++)
      {
        AccessibleEditableTextListener localAccessibleEditableTextListener = (AccessibleEditableTextListener)this.accessibleEditableTextListeners.elementAt(k);
        localAccessibleEditableTextListener.replaceText((AccessibleEditableTextEvent)localObject);
      }
    }
  }
  
  void setSelectedTextRangeAttribute(id paramid, int paramInt)
  {
    NSRange localNSRange = new NSValue(paramid.id).rangeValue();
    if (accessibleTextExtendedListenersSize() > 0)
    {
      AccessibleTextEvent localAccessibleTextEvent = new AccessibleTextEvent(this);
      localAccessibleTextEvent.index = 0;
      localAccessibleTextEvent.start = ((int)localNSRange.location);
      localAccessibleTextEvent.end = ((int)(localNSRange.location + localNSRange.length));
      for (int i = 0; i < accessibleTextExtendedListenersSize(); i++)
      {
        AccessibleTextExtendedListener localAccessibleTextExtendedListener = (AccessibleTextExtendedListener)this.accessibleTextExtendedListeners.elementAt(i);
        localAccessibleTextExtendedListener.removeSelection(localAccessibleTextEvent);
        localAccessibleTextExtendedListener.addSelection(localAccessibleTextEvent);
      }
    }
  }
  
  void setVisibleCharacterRangeAttribute(id paramid, int paramInt)
  {
    NSRange localNSRange = new NSValue(paramid.id).rangeValue();
    if (accessibleTextExtendedListenersSize() > 0)
    {
      AccessibleTextEvent localAccessibleTextEvent = new AccessibleTextEvent(this);
      localAccessibleTextEvent.type = 0;
      localAccessibleTextEvent.start = ((int)localNSRange.location);
      localAccessibleTextEvent.end = ((int)(localNSRange.location + localNSRange.length));
      for (int i = 0; i < accessibleTextExtendedListenersSize(); i++)
      {
        AccessibleTextExtendedListener localAccessibleTextExtendedListener = (AccessibleTextExtendedListener)this.accessibleTextExtendedListeners.elementAt(i);
        localAccessibleTextExtendedListener.scrollText(localAccessibleTextEvent);
      }
    }
  }
  
  public void textCaretMoved(int paramInt)
  {
    checkWidget();
    OS.NSAccessibilityPostNotification(this.control.view.id, OS.NSAccessibilitySelectedTextChangedNotification.id);
  }
  
  public void textChanged(int paramInt1, int paramInt2, int paramInt3)
  {
    checkWidget();
    OS.NSAccessibilityPostNotification(this.control.view.id, OS.NSAccessibilityValueChangedNotification.id);
  }
  
  public void textSelectionChanged()
  {
    checkWidget();
    OS.NSAccessibilityPostNotification(this.control.view.id, OS.NSAccessibilitySelectedTextChangedNotification.id);
  }
  
  id childIDToOs(int paramInt)
  {
    if (paramInt == -1) {
      return this.control.view;
    }
    SWTAccessibleDelegate localSWTAccessibleDelegate = (SWTAccessibleDelegate)this.childToIdMap.get(new Integer(paramInt));
    if (localSWTAccessibleDelegate == null)
    {
      localSWTAccessibleDelegate = new SWTAccessibleDelegate(this, paramInt);
      this.childToIdMap.put(new Integer(paramInt), localSWTAccessibleDelegate);
    }
    return localSWTAccessibleDelegate;
  }
  
  NSString concatStringsAsRole(NSString paramNSString1, NSString paramNSString2)
  {
    NSString localNSString = paramNSString1;
    localNSString = localNSString.stringByAppendingString(NSString.stringWith(":"));
    localNSString = localNSString.stringByAppendingString(paramNSString2);
    return localNSString;
  }
  
  String roleToOs(int paramInt)
  {
    NSString localNSString = null;
    switch (paramInt)
    {
    case 10: 
      localNSString = OS.NSAccessibilityGroupRole;
      break;
    case 9: 
      localNSString = OS.NSAccessibilityWindowRole;
      break;
    case 2: 
      localNSString = OS.NSAccessibilityMenuBarRole;
      break;
    case 11: 
      localNSString = OS.NSAccessibilityMenuRole;
      break;
    case 12: 
      localNSString = OS.NSAccessibilityMenuItemRole;
      break;
    case 21: 
      localNSString = OS.NSAccessibilitySplitterRole;
      break;
    case 13: 
      localNSString = OS.NSAccessibilityHelpTagRole;
      break;
    case 3: 
      localNSString = OS.NSAccessibilityScrollBarRole;
      break;
    case 18: 
      localNSString = concatStringsAsRole(OS.NSAccessibilityWindowRole, OS.NSAccessibilityDialogSubrole);
      break;
    case 41: 
      localNSString = OS.NSAccessibilityStaticTextRole;
      break;
    case 43: 
      localNSString = OS.NSAccessibilityButtonRole;
      break;
    case 44: 
      localNSString = OS.NSAccessibilityCheckBoxRole;
      break;
    case 45: 
      localNSString = OS.NSAccessibilityRadioButtonRole;
      break;
    case 62: 
      localNSString = OS.NSAccessibilityMenuButtonRole;
      break;
    case 46: 
      localNSString = OS.NSAccessibilityComboBoxRole;
      break;
    case 42: 
      int i = this.control.getStyle();
      if ((i & 0x2) != 0) {
        localNSString = OS.NSAccessibilityTextAreaRole;
      } else {
        localNSString = OS.NSAccessibilityTextFieldRole;
      }
      break;
    case 22: 
      localNSString = OS.NSAccessibilityToolbarRole;
      break;
    case 33: 
      localNSString = OS.NSAccessibilityOutlineRole;
      break;
    case 34: 
      localNSString = OS.NSAccessibilityStaticTextRole;
      break;
    case 27: 
      localNSString = OS.NSAccessibilityColumnRole;
      break;
    case 28: 
      localNSString = concatStringsAsRole(OS.NSAccessibilityRowRole, OS.NSAccessibilityTableRowSubrole);
      break;
    case 24: 
      localNSString = OS.NSAccessibilityTableRole;
      break;
    case 29: 
      localNSString = OS.NSAccessibilityStaticTextRole;
      break;
    case 25: 
      localNSString = OS.NSAccessibilityGroupRole;
      break;
    case 26: 
      localNSString = OS.NSAccessibilityGroupRole;
      break;
    case 35: 
      localNSString = OS.NSAccessibilityOutlineRole;
      break;
    case 36: 
      localNSString = concatStringsAsRole(OS.NSAccessibilityOutlineRole, OS.NSAccessibilityOutlineRowSubrole);
      break;
    case 60: 
      localNSString = OS.NSAccessibilityTabGroupRole;
      break;
    case 37: 
      localNSString = OS.NSAccessibilityRadioButtonRole;
      break;
    case 48: 
      localNSString = OS.NSAccessibilityProgressIndicatorRole;
      break;
    case 51: 
      localNSString = OS.NSAccessibilitySliderRole;
      break;
    case 30: 
      localNSString = OS.NSAccessibilityLinkRole;
      break;
    case 1025: 
      localNSString = OS.NSAccessibilityGroupRole;
      break;
    case 40: 
      localNSString = OS.NSAccessibilityImageRole;
      break;
    case 20: 
      localNSString = OS.NSAccessibilityGroupRole;
      break;
    case 1027: 
      localNSString = OS.NSAccessibilityMenuButtonRole;
      break;
    case 1073: 
      localNSString = OS.NSAccessibilityMenuButtonRole;
      break;
    case 1038: 
    case 1040: 
    case 1043: 
    case 1053: 
    case 1060: 
      localNSString = OS.NSAccessibilityGroupRole;
      break;
    case 1044: 
    case 1054: 
      localNSString = OS.NSAccessibilityTextAreaRole;
      break;
    case 8: 
    case 15: 
    case 23: 
    case 47: 
    case 52: 
    case 54: 
    case 61: 
    case 1029: 
      localNSString = OS.NSAccessibilityUnknownRole;
    }
    return localNSString.getString();
  }
  
  void checkWidget()
  {
    if (!isValidThread()) {
      SWT.error(22);
    }
    if (this.control.isDisposed()) {
      SWT.error(24);
    }
  }
  
  boolean isValidThread()
  {
    return this.control.getDisplay().getThread() == Thread.currentThread();
  }
  
  public long internal_addRelationAttributes(long paramLong)
  {
    NSArray localNSArray = new NSArray(paramLong);
    NSMutableArray localNSMutableArray = NSMutableArray.arrayWithCapacity(localNSArray.count());
    localNSMutableArray.addObjectsFromArray(localNSArray);
    if ((getTitleAttribute(-1) != null) && (!localNSMutableArray.containsObject(OS.NSAccessibilityTitleAttribute))) {
      localNSMutableArray.addObject(OS.NSAccessibilityTitleAttribute);
    }
    if ((getDescriptionAttribute(-1) != null) && (!localNSMutableArray.containsObject(OS.NSAccessibilityDescriptionAttribute))) {
      localNSMutableArray.addObject(OS.NSAccessibilityDescriptionAttribute);
    }
    if (this.relations[8] != null)
    {
      if (!localNSMutableArray.containsObject(OS.NSAccessibilityServesAsTitleForUIElementsAttribute)) {
        localNSMutableArray.addObject(OS.NSAccessibilityServesAsTitleForUIElementsAttribute);
      }
      if (!localNSMutableArray.containsObject(OS.NSAccessibilityTitleAttribute)) {
        localNSMutableArray.addObject(OS.NSAccessibilityTitleAttribute);
      }
    }
    else
    {
      localNSMutableArray.removeObject(OS.NSAccessibilityServesAsTitleForUIElementsAttribute);
    }
    if (this.relations[9] != null)
    {
      if (!localNSMutableArray.containsObject(OS.NSAccessibilityTitleUIElementAttribute)) {
        localNSMutableArray.addObject(OS.NSAccessibilityTitleUIElementAttribute);
      }
    }
    else {
      localNSMutableArray.removeObject(OS.NSAccessibilityTitleUIElementAttribute);
    }
    return localNSMutableArray.id;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/accessibility/Accessible.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */