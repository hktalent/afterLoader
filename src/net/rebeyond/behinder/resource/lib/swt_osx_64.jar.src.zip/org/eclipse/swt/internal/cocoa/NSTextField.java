package org.eclipse.swt.internal.cocoa;

public class NSTextField
  extends NSControl
{
  public NSTextField() {}
  
  public NSTextField(long paramLong)
  {
    super(paramLong);
  }
  
  public NSTextField(id paramid)
  {
    super(paramid);
  }
  
  public void selectText(id paramid)
  {
    OS.objc_msgSend(this.id, OS.sel_selectText_, paramid != null ? paramid.id : 0L);
  }
  
  public void setBackgroundColor(NSColor paramNSColor)
  {
    OS.objc_msgSend(this.id, OS.sel_setBackgroundColor_, paramNSColor != null ? paramNSColor.id : 0L);
  }
  
  public void setBordered(boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_setBordered_, paramBoolean);
  }
  
  public void setDelegate(id paramid)
  {
    OS.objc_msgSend(this.id, OS.sel_setDelegate_, paramid != null ? paramid.id : 0L);
  }
  
  public void setDrawsBackground(boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_setDrawsBackground_, paramBoolean);
  }
  
  public void setEditable(boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_setEditable_, paramBoolean);
  }
  
  public void setSelectable(boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_setSelectable_, paramBoolean);
  }
  
  public void setTextColor(NSColor paramNSColor)
  {
    OS.objc_msgSend(this.id, OS.sel_setTextColor_, paramNSColor != null ? paramNSColor.id : 0L);
  }
  
  public static long cellClass()
  {
    return OS.objc_msgSend(OS.class_NSTextField, OS.sel_cellClass);
  }
  
  public static void setCellClass(long paramLong)
  {
    OS.objc_msgSend(OS.class_NSTextField, OS.sel_setCellClass_, paramLong);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSTextField.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */