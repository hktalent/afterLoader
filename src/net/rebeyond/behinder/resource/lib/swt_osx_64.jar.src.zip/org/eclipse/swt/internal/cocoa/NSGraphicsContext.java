package org.eclipse.swt.internal.cocoa;

public class NSGraphicsContext
  extends NSObject
{
  public NSGraphicsContext() {}
  
  public NSGraphicsContext(long paramLong)
  {
    super(paramLong);
  }
  
  public NSGraphicsContext(id paramid)
  {
    super(paramid);
  }
  
  public static NSGraphicsContext currentContext()
  {
    long l = OS.objc_msgSend(OS.class_NSGraphicsContext, OS.sel_currentContext);
    return l != 0L ? new NSGraphicsContext(l) : null;
  }
  
  public void flushGraphics()
  {
    OS.objc_msgSend(this.id, OS.sel_flushGraphics);
  }
  
  public static NSGraphicsContext graphicsContextWithBitmapImageRep(NSBitmapImageRep paramNSBitmapImageRep)
  {
    long l = OS.objc_msgSend(OS.class_NSGraphicsContext, OS.sel_graphicsContextWithBitmapImageRep_, paramNSBitmapImageRep != null ? paramNSBitmapImageRep.id : 0L);
    return l != 0L ? new NSGraphicsContext(l) : null;
  }
  
  public static NSGraphicsContext graphicsContextWithGraphicsPort(long paramLong, boolean paramBoolean)
  {
    long l = OS.objc_msgSend(OS.class_NSGraphicsContext, OS.sel_graphicsContextWithGraphicsPort_flipped_, paramLong, paramBoolean);
    return l != 0L ? new NSGraphicsContext(l) : null;
  }
  
  public static NSGraphicsContext graphicsContextWithWindow(NSWindow paramNSWindow)
  {
    long l = OS.objc_msgSend(OS.class_NSGraphicsContext, OS.sel_graphicsContextWithWindow_, paramNSWindow != null ? paramNSWindow.id : 0L);
    return l != 0L ? new NSGraphicsContext(l) : null;
  }
  
  public long graphicsPort()
  {
    return OS.objc_msgSend(this.id, OS.sel_graphicsPort);
  }
  
  public long imageInterpolation()
  {
    return OS.objc_msgSend(this.id, OS.sel_imageInterpolation);
  }
  
  public boolean isDrawingToScreen()
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_isDrawingToScreen);
  }
  
  public boolean isFlipped()
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_isFlipped);
  }
  
  public static void static_restoreGraphicsState()
  {
    OS.objc_msgSend(OS.class_NSGraphicsContext, OS.sel_restoreGraphicsState);
  }
  
  public void restoreGraphicsState()
  {
    OS.objc_msgSend(this.id, OS.sel_restoreGraphicsState);
  }
  
  public static void static_saveGraphicsState()
  {
    OS.objc_msgSend(OS.class_NSGraphicsContext, OS.sel_saveGraphicsState);
  }
  
  public void saveGraphicsState()
  {
    OS.objc_msgSend(this.id, OS.sel_saveGraphicsState);
  }
  
  public void setCompositingOperation(long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_setCompositingOperation_, paramLong);
  }
  
  public static void setCurrentContext(NSGraphicsContext paramNSGraphicsContext)
  {
    OS.objc_msgSend(OS.class_NSGraphicsContext, OS.sel_setCurrentContext_, paramNSGraphicsContext != null ? paramNSGraphicsContext.id : 0L);
  }
  
  public void setImageInterpolation(long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_setImageInterpolation_, paramLong);
  }
  
  public void setPatternPhase(NSPoint paramNSPoint)
  {
    OS.objc_msgSend(this.id, OS.sel_setPatternPhase_, paramNSPoint);
  }
  
  public void setShouldAntialias(boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_setShouldAntialias_, paramBoolean);
  }
  
  public boolean shouldAntialias()
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_shouldAntialias);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSGraphicsContext.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */