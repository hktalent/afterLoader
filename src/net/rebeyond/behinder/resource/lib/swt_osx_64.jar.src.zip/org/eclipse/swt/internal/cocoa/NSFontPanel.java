package org.eclipse.swt.internal.cocoa;

public class NSFontPanel
  extends NSPanel
{
  public NSFontPanel() {}
  
  public NSFontPanel(long paramLong)
  {
    super(paramLong);
  }
  
  public NSFontPanel(id paramid)
  {
    super(paramid);
  }
  
  public NSFont panelConvertFont(NSFont paramNSFont)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_panelConvertFont_, paramNSFont != null ? paramNSFont.id : 0L);
    return l != 0L ? new NSFont(l) : null;
  }
  
  public void setPanelFont(NSFont paramNSFont, boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_setPanelFont_isMultiple_, paramNSFont != null ? paramNSFont.id : 0L, paramBoolean);
  }
  
  public static NSFontPanel sharedFontPanel()
  {
    long l = OS.objc_msgSend(OS.class_NSFontPanel, OS.sel_sharedFontPanel);
    return l != 0L ? new NSFontPanel(l) : null;
  }
  
  public static double minFrameWidthWithTitle(NSString paramNSString, long paramLong)
  {
    return OS.objc_msgSend_fpret(OS.class_NSFontPanel, OS.sel_minFrameWidthWithTitle_styleMask_, paramNSString != null ? paramNSString.id : 0L, paramLong);
  }
  
  public static long windowNumberAtPoint(NSPoint paramNSPoint, long paramLong)
  {
    return OS.objc_msgSend(OS.class_NSFontPanel, OS.sel_windowNumberAtPoint_belowWindowWithWindowNumber_, paramNSPoint, paramLong);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSFontPanel.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */