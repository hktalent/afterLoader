package org.eclipse.swt.internal.cocoa;

public class NSArray
  extends NSObject
{
  public NSArray() {}
  
  public NSArray(long paramLong)
  {
    super(paramLong);
  }
  
  public NSArray(id paramid)
  {
    super(paramid);
  }
  
  public static NSArray array()
  {
    long l = OS.objc_msgSend(OS.class_NSArray, OS.sel_array);
    return l != 0L ? new NSArray(l) : null;
  }
  
  public static NSArray arrayWithObject(id paramid)
  {
    long l = OS.objc_msgSend(OS.class_NSArray, OS.sel_arrayWithObject_, paramid != null ? paramid.id : 0L);
    return l != 0L ? new NSArray(l) : null;
  }
  
  public boolean containsObject(id paramid)
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_containsObject_, paramid != null ? paramid.id : 0L);
  }
  
  public long count()
  {
    return OS.objc_msgSend(this.id, OS.sel_count);
  }
  
  public long indexOfObjectIdenticalTo(id paramid)
  {
    return OS.objc_msgSend(this.id, OS.sel_indexOfObjectIdenticalTo_, paramid != null ? paramid.id : 0L);
  }
  
  public id objectAtIndex(long paramLong)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_objectAtIndex_, paramLong);
    return l != 0L ? new id(l) : null;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSArray.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */