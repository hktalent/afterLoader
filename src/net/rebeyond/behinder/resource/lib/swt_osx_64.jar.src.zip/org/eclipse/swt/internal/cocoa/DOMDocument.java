package org.eclipse.swt.internal.cocoa;

public class DOMDocument
  extends NSObject
{
  public DOMDocument() {}
  
  public DOMDocument(long paramLong)
  {
    super(paramLong);
  }
  
  public DOMDocument(id paramid)
  {
    super(paramid);
  }
  
  public WebFrame webFrame()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_webFrame);
    return l != 0L ? new WebFrame(l) : null;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/DOMDocument.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */