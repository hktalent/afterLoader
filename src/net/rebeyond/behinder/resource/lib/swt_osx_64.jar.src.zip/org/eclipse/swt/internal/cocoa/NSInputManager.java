package org.eclipse.swt.internal.cocoa;

public class NSInputManager
  extends NSObject
{
  public NSInputManager() {}
  
  public NSInputManager(long paramLong)
  {
    super(paramLong);
  }
  
  public NSInputManager(id paramid)
  {
    super(paramid);
  }
  
  public static NSInputManager currentInputManager()
  {
    long l = OS.objc_msgSend(OS.class_NSInputManager, OS.sel_currentInputManager);
    return l != 0L ? new NSInputManager(l) : null;
  }
  
  public boolean handleMouseEvent(NSEvent paramNSEvent)
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_handleMouseEvent_, paramNSEvent != null ? paramNSEvent.id : 0L);
  }
  
  public boolean wantsToHandleMouseEvents()
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_wantsToHandleMouseEvents);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSInputManager.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */