package org.eclipse.swt.accessibility;

import org.eclipse.swt.SWT;
import org.eclipse.swt.internal.C;
import org.eclipse.swt.internal.Callback;
import org.eclipse.swt.internal.cocoa.NSArray;
import org.eclipse.swt.internal.cocoa.NSObject;
import org.eclipse.swt.internal.cocoa.NSPoint;
import org.eclipse.swt.internal.cocoa.NSString;
import org.eclipse.swt.internal.cocoa.OS;
import org.eclipse.swt.internal.cocoa.id;

class SWTAccessibleDelegate
  extends NSObject
{
  static final String ACCESSIBLE_KEY = "Accessible";
  static final byte[] SWT_OBJECT = { 83, 87, 84, 95, 79, 66, 74, 69, 67, 84, 0 };
  static Callback accessible2Args;
  static Callback accessible3Args;
  static Callback accessible4Args;
  static long proc2Args;
  static long proc3Args;
  static long proc4Args;
  Accessible accessible;
  long delegateJniRef;
  int childID;
  NSArray attributeNames = null;
  NSArray parameterizedAttributeNames = null;
  NSArray actionNames = null;
  
  public SWTAccessibleDelegate(Accessible paramAccessible, int paramInt)
  {
    super(0L);
    this.accessible = paramAccessible;
    this.childID = paramInt;
    alloc().init();
    this.delegateJniRef = OS.NewGlobalRef(this);
    if (this.delegateJniRef == 0L) {
      SWT.error(2);
    }
    OS.object_setInstanceVariable(this.id, SWT_OBJECT, this.delegateJniRef);
  }
  
  NSArray accessibilityActionNames()
  {
    if (this.actionNames != null) {
      return retainedAutoreleased(this.actionNames);
    }
    this.actionNames = this.accessible.internal_accessibilityActionNames(this.childID);
    this.actionNames.retain();
    return retainedAutoreleased(this.actionNames);
  }
  
  NSArray accessibilityAttributeNames()
  {
    if (this.attributeNames != null) {
      return retainedAutoreleased(this.attributeNames);
    }
    this.attributeNames = this.accessible.internal_accessibilityAttributeNames(this.childID);
    this.attributeNames.retain();
    return retainedAutoreleased(this.attributeNames);
  }
  
  id accessibilityAttributeValue(NSString paramNSString)
  {
    return this.accessible.internal_accessibilityAttributeValue(paramNSString, this.childID);
  }
  
  NSArray accessibilityParameterizedAttributeNames()
  {
    if (this.parameterizedAttributeNames != null) {
      return retainedAutoreleased(this.parameterizedAttributeNames);
    }
    this.parameterizedAttributeNames = this.accessible.internal_accessibilityParameterizedAttributeNames(this.childID);
    this.parameterizedAttributeNames.retain();
    return retainedAutoreleased(this.parameterizedAttributeNames);
  }
  
  id accessibilityAttributeValue_forParameter(NSString paramNSString, id paramid)
  {
    return this.accessible.internal_accessibilityAttributeValue_forParameter(paramNSString, paramid, this.childID);
  }
  
  boolean accessibilityIsIgnored()
  {
    return this.accessible.internal_accessibilityIsIgnored(this.childID);
  }
  
  boolean accessibilityIsAttributeSettable(NSString paramNSString)
  {
    return this.accessible.internal_accessibilityIsAttributeSettable(paramNSString, this.childID);
  }
  
  id accessibilityHitTest(NSPoint paramNSPoint)
  {
    return this.accessible.internal_accessibilityHitTest(paramNSPoint, this.childID);
  }
  
  id accessibilityFocusedUIElement()
  {
    return this.accessible.internal_accessibilityFocusedUIElement(this.childID);
  }
  
  void accessibilityPerformAction(NSString paramNSString)
  {
    this.accessible.internal_accessibilityPerformAction(paramNSString, this.childID);
  }
  
  id accessibilityActionDescription(NSString paramNSString)
  {
    return this.accessible.internal_accessibilityActionDescription(paramNSString, this.childID);
  }
  
  void accessibilitySetValue_forAttribute(id paramid, NSString paramNSString)
  {
    this.accessible.internal_accessibilitySetValue_forAttribute(paramid, paramNSString, this.childID);
  }
  
  static NSArray retainedAutoreleased(NSArray paramNSArray)
  {
    id localid = paramNSArray.retain();
    NSObject localNSObject = new NSObject(localid.id).autorelease();
    return new NSArray(localNSObject.id);
  }
  
  static long accessibleProc(long paramLong1, long paramLong2)
  {
    SWTAccessibleDelegate localSWTAccessibleDelegate = getAccessibleDelegate(paramLong1);
    if (localSWTAccessibleDelegate == null) {
      return 0L;
    }
    NSArray localNSArray;
    if (paramLong2 == OS.sel_accessibilityAttributeNames)
    {
      localNSArray = localSWTAccessibleDelegate.accessibilityAttributeNames();
      return localNSArray == null ? 0L : localNSArray.id;
    }
    if (paramLong2 == OS.sel_accessibilityActionNames)
    {
      localNSArray = localSWTAccessibleDelegate.accessibilityActionNames();
      return localNSArray == null ? 0L : localNSArray.id;
    }
    if (paramLong2 == OS.sel_accessibilityParameterizedAttributeNames)
    {
      localNSArray = localSWTAccessibleDelegate.accessibilityParameterizedAttributeNames();
      return localNSArray == null ? 0L : localNSArray.id;
    }
    if (paramLong2 == OS.sel_accessibilityIsIgnored)
    {
      boolean bool = localSWTAccessibleDelegate.accessibilityIsIgnored();
      return bool ? 1 : 0;
    }
    if (paramLong2 == OS.sel_accessibilityFocusedUIElement)
    {
      id localid = localSWTAccessibleDelegate.accessibilityFocusedUIElement();
      return localid == null ? 0L : localid.id;
    }
    return 0L;
  }
  
  static long accessibleProc(long paramLong1, long paramLong2, long paramLong3)
  {
    SWTAccessibleDelegate localSWTAccessibleDelegate = getAccessibleDelegate(paramLong1);
    if (localSWTAccessibleDelegate == null) {
      return 0L;
    }
    Object localObject;
    id localid;
    if (paramLong2 == OS.sel_accessibilityAttributeValue_)
    {
      localObject = new NSString(paramLong3);
      localid = localSWTAccessibleDelegate.accessibilityAttributeValue((NSString)localObject);
      return localid == null ? 0L : localid.id;
    }
    if (paramLong2 == OS.sel_accessibilityHitTest_)
    {
      localObject = new NSPoint();
      OS.memmove((NSPoint)localObject, paramLong3, NSPoint.sizeof);
      localid = localSWTAccessibleDelegate.accessibilityHitTest((NSPoint)localObject);
      return localid == null ? 0L : localid.id;
    }
    if (paramLong2 == OS.sel_accessibilityIsAttributeSettable_)
    {
      localObject = new NSString(paramLong3);
      return localSWTAccessibleDelegate.accessibilityIsAttributeSettable((NSString)localObject) ? 1 : 0;
    }
    if (paramLong2 == OS.sel_accessibilityActionDescription_)
    {
      localObject = new NSString(paramLong3);
      localid = localSWTAccessibleDelegate.accessibilityActionDescription((NSString)localObject);
      return localid == null ? 0L : localid.id;
    }
    if (paramLong2 == OS.sel_accessibilityPerformAction_)
    {
      localObject = new NSString(paramLong3);
      localSWTAccessibleDelegate.accessibilityPerformAction((NSString)localObject);
    }
    return 0L;
  }
  
  static long accessibleProc(long paramLong1, long paramLong2, long paramLong3, long paramLong4)
  {
    SWTAccessibleDelegate localSWTAccessibleDelegate = getAccessibleDelegate(paramLong1);
    if (localSWTAccessibleDelegate == null) {
      return 0L;
    }
    Object localObject1;
    Object localObject2;
    if (paramLong2 == OS.sel_accessibilityAttributeValue_forParameter_)
    {
      localObject1 = new NSString(paramLong3);
      localObject2 = new id(paramLong4);
      id localid = localSWTAccessibleDelegate.accessibilityAttributeValue_forParameter((NSString)localObject1, (id)localObject2);
      return localid == null ? 0L : localid.id;
    }
    if (paramLong2 == OS.sel_accessibilitySetValue_forAttribute_)
    {
      localObject1 = new id(paramLong3);
      localObject2 = new NSString(paramLong4);
      localSWTAccessibleDelegate.accessibilitySetValue_forAttribute((id)localObject1, (NSString)localObject2);
    }
    return 0L;
  }
  
  static SWTAccessibleDelegate getAccessibleDelegate(long paramLong)
  {
    if (paramLong == 0L) {
      return null;
    }
    long[] arrayOfLong = new long[1];
    OS.object_getInstanceVariable(paramLong, SWT_OBJECT, arrayOfLong);
    if (arrayOfLong[0] == 0L) {
      return null;
    }
    return (SWTAccessibleDelegate)OS.JNIGetObject(arrayOfLong[0]);
  }
  
  public void internal_dispose_SWTAccessibleDelegate()
  {
    if (this.actionNames != null) {
      this.actionNames.release();
    }
    this.actionNames = null;
    if (this.attributeNames != null) {
      this.attributeNames.release();
    }
    this.attributeNames = null;
    if (this.parameterizedAttributeNames != null) {
      this.parameterizedAttributeNames.release();
    }
    this.parameterizedAttributeNames = null;
    if (this.delegateJniRef != 0L) {
      OS.DeleteGlobalRef(this.delegateJniRef);
    }
    this.delegateJniRef = 0L;
    OS.object_setInstanceVariable(this.id, SWT_OBJECT, 0L);
  }
  
  static
  {
    Class localClass = SWTAccessibleDelegate.class;
    accessible2Args = new Callback(localClass, "accessibleProc", 2);
    proc2Args = accessible2Args.getAddress();
    if (proc2Args == 0L) {
      SWT.error(3);
    }
    accessible3Args = new Callback(localClass, "accessibleProc", 3);
    proc3Args = accessible3Args.getAddress();
    if (proc3Args == 0L) {
      SWT.error(3);
    }
    accessible4Args = new Callback(localClass, "accessibleProc", 4);
    proc4Args = accessible3Args.getAddress();
    if (proc4Args == 0L) {
      SWT.error(3);
    }
    String str = "SWTAccessibleDelegate";
    byte[] arrayOfByte = { 42, 0 };
    int i = C.PTR_SIZEOF;
    int j = C.PTR_SIZEOF == 4 ? 2 : 3;
    long l = OS.objc_allocateClassPair(OS.class_NSObject, str, 0L);
    OS.class_addIvar(l, SWT_OBJECT, i, (byte)j, arrayOfByte);
    OS.class_addMethod(l, OS.sel_accessibilityActionNames, proc2Args, "@:");
    OS.class_addMethod(l, OS.sel_accessibilityAttributeNames, proc2Args, "@:");
    OS.class_addMethod(l, OS.sel_accessibilityParameterizedAttributeNames, proc2Args, "@:");
    OS.class_addMethod(l, OS.sel_accessibilityIsIgnored, proc2Args, "@:");
    OS.class_addMethod(l, OS.sel_accessibilityFocusedUIElement, proc2Args, "@:");
    OS.class_addMethod(l, OS.sel_accessibilityAttributeValue_, proc3Args, "@:@");
    OS.class_addMethod(l, OS.sel_accessibilityHitTest_, proc3Args, "@:{NSPoint}");
    OS.class_addMethod(l, OS.sel_accessibilityIsAttributeSettable_, proc3Args, "@:@");
    OS.class_addMethod(l, OS.sel_accessibilityActionDescription_, proc3Args, "@:@");
    OS.class_addMethod(l, OS.sel_accessibilityPerformAction_, proc3Args, "@:@");
    OS.class_addMethod(l, OS.sel_accessibilityAttributeValue_forParameter_, proc4Args, "@:@@");
    OS.class_addMethod(l, OS.sel_accessibilitySetValue_forAttribute_, proc4Args, "@:@@");
    OS.objc_registerClassPair(l);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/accessibility/SWTAccessibleDelegate.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */