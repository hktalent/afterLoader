package org.eclipse.swt.internal.cocoa;

public class NSURL
  extends NSObject
{
  public NSURL() {}
  
  public NSURL(long paramLong)
  {
    super(paramLong);
  }
  
  public NSURL(id paramid)
  {
    super(paramid);
  }
  
  public static NSURL URLFromPasteboard(NSPasteboard paramNSPasteboard)
  {
    long l = OS.objc_msgSend(OS.class_NSURL, OS.sel_URLFromPasteboard_, paramNSPasteboard != null ? paramNSPasteboard.id : 0L);
    return l != 0L ? new NSURL(l) : null;
  }
  
  public void writeToPasteboard(NSPasteboard paramNSPasteboard)
  {
    OS.objc_msgSend(this.id, OS.sel_writeToPasteboard_, paramNSPasteboard != null ? paramNSPasteboard.id : 0L);
  }
  
  public static NSURL URLWithString(NSString paramNSString)
  {
    long l = OS.objc_msgSend(OS.class_NSURL, OS.sel_URLWithString_, paramNSString != null ? paramNSString.id : 0L);
    return l != 0L ? new NSURL(l) : null;
  }
  
  public NSString absoluteString()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_absoluteString);
    return l != 0L ? new NSString(l) : null;
  }
  
  public static NSURL fileURLWithPath(NSString paramNSString)
  {
    long l = OS.objc_msgSend(OS.class_NSURL, OS.sel_fileURLWithPath_, paramNSString != null ? paramNSString.id : 0L);
    return l != 0L ? new NSURL(l) : null;
  }
  
  public NSString host()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_host);
    return l != 0L ? new NSString(l) : null;
  }
  
  public boolean isFileURL()
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_isFileURL);
  }
  
  public NSString path()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_path);
    return l != 0L ? new NSString(l) : null;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSURL.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */