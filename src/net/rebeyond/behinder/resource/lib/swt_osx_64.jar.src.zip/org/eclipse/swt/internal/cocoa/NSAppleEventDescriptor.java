package org.eclipse.swt.internal.cocoa;

public class NSAppleEventDescriptor
  extends NSObject
{
  public NSAppleEventDescriptor() {}
  
  public NSAppleEventDescriptor(long paramLong)
  {
    super(paramLong);
  }
  
  public NSAppleEventDescriptor(id paramid)
  {
    super(paramid);
  }
  
  public NSAppleEventDescriptor initListDescriptor()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_initListDescriptor);
    return l != 0L ? new NSAppleEventDescriptor(l) : l == this.id ? this : null;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSAppleEventDescriptor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */