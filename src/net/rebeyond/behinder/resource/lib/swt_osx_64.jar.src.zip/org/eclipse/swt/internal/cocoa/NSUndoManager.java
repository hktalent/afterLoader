package org.eclipse.swt.internal.cocoa;

public class NSUndoManager
  extends NSObject
{
  public NSUndoManager() {}
  
  public NSUndoManager(long paramLong)
  {
    super(paramLong);
  }
  
  public NSUndoManager(id paramid)
  {
    super(paramid);
  }
  
  public boolean canRedo()
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_canRedo);
  }
  
  public boolean canUndo()
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_canUndo);
  }
  
  public void redo()
  {
    OS.objc_msgSend(this.id, OS.sel_redo);
  }
  
  public void undo()
  {
    OS.objc_msgSend(this.id, OS.sel_undo);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSUndoManager.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */