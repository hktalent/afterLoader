package org.eclipse.swt.internal.cocoa;

public class NSParagraphStyle
  extends NSObject
{
  public NSParagraphStyle() {}
  
  public NSParagraphStyle(long paramLong)
  {
    super(paramLong);
  }
  
  public NSParagraphStyle(id paramid)
  {
    super(paramid);
  }
  
  public long alignment()
  {
    return OS.objc_msgSend(this.id, OS.sel_alignment);
  }
  
  public NSArray tabStops()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_tabStops);
    return l != 0L ? new NSArray(l) : null;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSParagraphStyle.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */