package org.eclipse.swt.graphics;

import org.eclipse.swt.SWT;
import org.eclipse.swt.internal.C;
import org.eclipse.swt.internal.Callback;
import org.eclipse.swt.internal.cocoa.NSAffineTransform;
import org.eclipse.swt.internal.cocoa.NSAutoreleasePool;
import org.eclipse.swt.internal.cocoa.NSBezierPath;
import org.eclipse.swt.internal.cocoa.NSObject;
import org.eclipse.swt.internal.cocoa.NSPoint;
import org.eclipse.swt.internal.cocoa.NSRect;
import org.eclipse.swt.internal.cocoa.NSThread;
import org.eclipse.swt.internal.cocoa.OS;

public final class Region
  extends Resource
{
  public long handle;
  NSAffineTransform transform;
  NSPoint pt = new NSPoint();
  short[] rect = new short[4];
  
  public Region()
  {
    this(null);
  }
  
  public Region(Device paramDevice)
  {
    super(paramDevice);
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      this.handle = OS.NewRgn();
      if (this.handle == 0L) {
        SWT.error(2);
      }
      init();
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  Region(Device paramDevice, long paramLong)
  {
    super(paramDevice);
    this.handle = paramLong;
  }
  
  public static Region cocoa_new(Device paramDevice, long paramLong)
  {
    return new Region(paramDevice, paramLong);
  }
  
  static long polyToRgn(int[] paramArrayOfInt, int paramInt)
  {
    short[] arrayOfShort = new short[4];
    long l1 = OS.NewRgn();
    long l2 = OS.NewRgn();
    int i = paramArrayOfInt[1];
    int j = paramArrayOfInt[1];
    for (int k = 3; k < paramInt; k += 2)
    {
      if (paramArrayOfInt[k] < i) {
        i = paramArrayOfInt[k];
      }
      if (paramArrayOfInt[k] > j) {
        j = paramArrayOfInt[k];
      }
    }
    int[] arrayOfInt = new int[paramInt + 1];
    for (int m = i; m <= j; m++)
    {
      int n = 0;
      int i1 = paramArrayOfInt[0];
      int i2 = paramArrayOfInt[1];
      for (int i3 = 2; i3 < paramInt; i3 += 2)
      {
        i4 = paramArrayOfInt[i3];
        i5 = paramArrayOfInt[(i3 + 1)];
        if ((i2 != i5) && (((i2 <= m) && (m < i5)) || ((i5 <= m) && (m < i2)))) {
          arrayOfInt[(n++)] = ((int)((m - i2) / (i5 - i2) * (i4 - i1) + i1 + 0.5F));
        }
        i1 = i4;
        i2 = i5;
      }
      i3 = paramArrayOfInt[0];
      int i4 = paramArrayOfInt[1];
      if ((i2 != i4) && (((i2 <= m) && (m < i4)) || ((i4 <= m) && (m < i2)))) {
        arrayOfInt[(n++)] = ((int)((m - i2) / (i4 - i2) * (i3 - i1) + i1 + 0.5F));
      }
      int i5 = n / 2;
      while (i5 > 0)
      {
        for (int i6 = i5; i6 < n; i6++)
        {
          int i7 = i6 - i5;
          while ((i7 >= 0) && (arrayOfInt[i7] - arrayOfInt[(i7 + i5)] > 0))
          {
            int i8 = arrayOfInt[i7];
            arrayOfInt[i7] = arrayOfInt[(i7 + i5)];
            arrayOfInt[(i7 + i5)] = i8;
            i7 -= i5;
          }
        }
        i5 /= 2;
      }
      for (i5 = 0; i5 < n; i5 += 2)
      {
        OS.SetRect(arrayOfShort, (short)arrayOfInt[i5], (short)m, (short)arrayOfInt[(i5 + 1)], (short)(m + 1));
        OS.RectRgn(l2, arrayOfShort);
        OS.UnionRgn(l1, l2, l1);
      }
    }
    OS.DisposeRgn(l2);
    return l1;
  }
  
  static long polyRgn(int[] paramArrayOfInt, int paramInt)
  {
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      long l1;
      if (C.PTR_SIZEOF == 4)
      {
        l1 = OS.NewRgn();
        OS.OpenRgn();
        OS.MoveTo((short)paramArrayOfInt[0], (short)paramArrayOfInt[1]);
        for (int i = 1; i < paramInt / 2; i++) {
          OS.LineTo((short)paramArrayOfInt[(2 * i)], (short)paramArrayOfInt[(2 * i + 1)]);
        }
        OS.LineTo((short)paramArrayOfInt[0], (short)paramArrayOfInt[1]);
        OS.CloseRgn(l1);
      }
      else
      {
        l1 = polyToRgn(paramArrayOfInt, paramInt);
      }
      long l2 = l1;
      return l2;
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  public void add(int[] paramArrayOfInt)
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    if (paramArrayOfInt == null) {
      SWT.error(4);
    }
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      add(paramArrayOfInt, paramArrayOfInt.length);
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  void add(int[] paramArrayOfInt, int paramInt)
  {
    paramInt = paramInt / 2 * 2;
    if (paramInt <= 2) {
      return;
    }
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      long l = polyRgn(paramArrayOfInt, paramInt);
      OS.UnionRgn(this.handle, l, this.handle);
      OS.DisposeRgn(l);
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  public void add(Rectangle paramRectangle)
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    if (paramRectangle == null) {
      SWT.error(4);
    }
    if ((paramRectangle.width < 0) || (paramRectangle.height < 0)) {
      SWT.error(5);
    }
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      add(paramRectangle.x, paramRectangle.y, paramRectangle.width, paramRectangle.height);
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  public void add(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    if ((paramInt3 < 0) || (paramInt4 < 0)) {
      SWT.error(5);
    }
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      long l = OS.NewRgn();
      short[] arrayOfShort = new short[4];
      OS.SetRect(arrayOfShort, (short)paramInt1, (short)paramInt2, (short)(paramInt1 + paramInt3), (short)(paramInt2 + paramInt4));
      OS.RectRgn(l, arrayOfShort);
      OS.UnionRgn(this.handle, l, this.handle);
      OS.DisposeRgn(l);
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  public void add(Region paramRegion)
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    if (paramRegion == null) {
      SWT.error(4);
    }
    if (paramRegion.isDisposed()) {
      SWT.error(5);
    }
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      OS.UnionRgn(this.handle, paramRegion.handle, this.handle);
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  public boolean contains(int paramInt1, int paramInt2)
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      short[] arrayOfShort = { (short)paramInt2, (short)paramInt1 };
      boolean bool = OS.PtInRgn(arrayOfShort, this.handle);
      return bool;
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  public boolean contains(Point paramPoint)
  {
    if (paramPoint == null) {
      SWT.error(4);
    }
    return contains(paramPoint.x, paramPoint.y);
  }
  
  void convertRgn(NSAffineTransform paramNSAffineTransform)
  {
    long l1 = OS.NewRgn();
    Callback localCallback = new Callback(this, "convertRgn", 4);
    long l2 = localCallback.getAddress();
    if (l2 == 0L) {
      SWT.error(3);
    }
    this.transform = paramNSAffineTransform;
    OS.QDRegionToRects(this.handle, 5, l2, l1);
    this.transform = null;
    localCallback.dispose();
    OS.CopyRgn(l1, this.handle);
    OS.DisposeRgn(l1);
  }
  
  long convertRgn(long paramLong1, long paramLong2, long paramLong3, long paramLong4)
  {
    if (paramLong1 == 2L)
    {
      short[] arrayOfShort = new short[4];
      OS.memmove(arrayOfShort, paramLong3, arrayOfShort.length * 2);
      int i = 0;
      NSPoint localNSPoint = new NSPoint();
      int[] arrayOfInt = new int[10];
      localNSPoint.x = arrayOfShort[1];
      localNSPoint.y = arrayOfShort[0];
      localNSPoint = this.transform.transformPoint(localNSPoint);
      int j;
      arrayOfInt[(i++)] = (j = (short)(int)localNSPoint.x);
      int k;
      arrayOfInt[(i++)] = (k = (short)(int)localNSPoint.y);
      localNSPoint.x = arrayOfShort[3];
      localNSPoint.y = arrayOfShort[0];
      localNSPoint = this.transform.transformPoint(localNSPoint);
      arrayOfInt[(i++)] = ((short)(int)Math.round(localNSPoint.x));
      arrayOfInt[(i++)] = ((short)(int)localNSPoint.y);
      localNSPoint.x = arrayOfShort[3];
      localNSPoint.y = arrayOfShort[2];
      localNSPoint = this.transform.transformPoint(localNSPoint);
      arrayOfInt[(i++)] = ((short)(int)Math.round(localNSPoint.x));
      arrayOfInt[(i++)] = ((short)(int)Math.round(localNSPoint.y));
      localNSPoint.x = arrayOfShort[1];
      localNSPoint.y = arrayOfShort[2];
      localNSPoint = this.transform.transformPoint(localNSPoint);
      arrayOfInt[(i++)] = ((short)(int)localNSPoint.x);
      arrayOfInt[(i++)] = ((short)(int)Math.round(localNSPoint.y));
      arrayOfInt[(i++)] = j;
      arrayOfInt[(i++)] = k;
      long l = polyRgn(arrayOfInt, arrayOfInt.length);
      OS.UnionRgn(paramLong4, l, paramLong4);
      OS.DisposeRgn(l);
    }
    return 0L;
  }
  
  void destroy()
  {
    OS.DisposeRgn(this.handle);
    this.handle = 0L;
  }
  
  public boolean equals(Object paramObject)
  {
    if (this == paramObject) {
      return true;
    }
    if (!(paramObject instanceof Region)) {
      return false;
    }
    Region localRegion = (Region)paramObject;
    return this.handle == localRegion.handle;
  }
  
  public Rectangle getBounds()
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      short[] arrayOfShort = new short[4];
      OS.GetRegionBounds(this.handle, arrayOfShort);
      int i = arrayOfShort[3] - arrayOfShort[1];
      int j = arrayOfShort[2] - arrayOfShort[0];
      Rectangle localRectangle = new Rectangle(arrayOfShort[1], arrayOfShort[0], i, j);
      return localRectangle;
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  NSBezierPath getPath()
  {
    Callback localCallback = new Callback(this, "regionToRects", 4);
    if (localCallback.getAddress() == 0L) {
      SWT.error(3);
    }
    NSBezierPath localNSBezierPath = NSBezierPath.bezierPath();
    localNSBezierPath.retain();
    OS.QDRegionToRects(this.handle, 5, localCallback.getAddress(), localNSBezierPath.id);
    localCallback.dispose();
    if (localNSBezierPath.isEmpty()) {
      localNSBezierPath.appendBezierPathWithRect(new NSRect());
    }
    return localNSBezierPath;
  }
  
  long regionToRects(long paramLong1, long paramLong2, long paramLong3, long paramLong4)
  {
    if (paramLong1 == 2L)
    {
      OS.memmove(this.rect, paramLong3, this.rect.length * 2);
      this.pt.x = this.rect[1];
      this.pt.y = this.rect[0];
      OS.objc_msgSend(paramLong4, OS.sel_moveToPoint_, this.pt);
      this.pt.x = this.rect[3];
      OS.objc_msgSend(paramLong4, OS.sel_lineToPoint_, this.pt);
      this.pt.x = this.rect[3];
      this.pt.y = this.rect[2];
      OS.objc_msgSend(paramLong4, OS.sel_lineToPoint_, this.pt);
      this.pt.x = this.rect[1];
      OS.objc_msgSend(paramLong4, OS.sel_lineToPoint_, this.pt);
      OS.objc_msgSend(paramLong4, OS.sel_closePath);
    }
    return 0L;
  }
  
  public int hashCode()
  {
    return (int)this.handle;
  }
  
  public void intersect(Rectangle paramRectangle)
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    if (paramRectangle == null) {
      SWT.error(4);
    }
    intersect(paramRectangle.x, paramRectangle.y, paramRectangle.width, paramRectangle.height);
  }
  
  public void intersect(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    if ((paramInt3 < 0) || (paramInt4 < 0)) {
      SWT.error(5);
    }
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      long l = OS.NewRgn();
      short[] arrayOfShort = new short[4];
      OS.SetRect(arrayOfShort, (short)paramInt1, (short)paramInt2, (short)(paramInt1 + paramInt3), (short)(paramInt2 + paramInt4));
      OS.RectRgn(l, arrayOfShort);
      OS.SectRgn(this.handle, l, this.handle);
      OS.DisposeRgn(l);
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  public void intersect(Region paramRegion)
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    if (paramRegion == null) {
      SWT.error(4);
    }
    if (paramRegion.isDisposed()) {
      SWT.error(5);
    }
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      OS.SectRgn(this.handle, paramRegion.handle, this.handle);
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  public boolean intersects(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      short[] arrayOfShort = new short[4];
      OS.SetRect(arrayOfShort, (short)paramInt1, (short)paramInt2, (short)(paramInt1 + paramInt3), (short)(paramInt2 + paramInt4));
      boolean bool = OS.RectInRgn(arrayOfShort, this.handle);
      return bool;
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  public boolean intersects(Rectangle paramRectangle)
  {
    if (paramRectangle == null) {
      SWT.error(4);
    }
    return intersects(paramRectangle.x, paramRectangle.y, paramRectangle.width, paramRectangle.height);
  }
  
  public boolean isDisposed()
  {
    return this.handle == 0L;
  }
  
  public boolean isEmpty()
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      boolean bool = OS.EmptyRgn(this.handle);
      return bool;
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  public void subtract(int[] paramArrayOfInt)
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    if (paramArrayOfInt == null) {
      SWT.error(4);
    }
    if (paramArrayOfInt.length < 2) {
      return;
    }
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      long l = polyRgn(paramArrayOfInt, paramArrayOfInt.length);
      OS.DiffRgn(this.handle, l, this.handle);
      OS.DisposeRgn(l);
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  public void subtract(Rectangle paramRectangle)
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    if (paramRectangle == null) {
      SWT.error(4);
    }
    subtract(paramRectangle.x, paramRectangle.y, paramRectangle.width, paramRectangle.height);
  }
  
  public void subtract(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    if ((paramInt3 < 0) || (paramInt4 < 0)) {
      SWT.error(5);
    }
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      long l = OS.NewRgn();
      short[] arrayOfShort = new short[4];
      OS.SetRect(arrayOfShort, (short)paramInt1, (short)paramInt2, (short)(paramInt1 + paramInt3), (short)(paramInt2 + paramInt4));
      OS.RectRgn(l, arrayOfShort);
      OS.DiffRgn(this.handle, l, this.handle);
      OS.DisposeRgn(l);
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  public void subtract(Region paramRegion)
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    if (paramRegion == null) {
      SWT.error(4);
    }
    if (paramRegion.isDisposed()) {
      SWT.error(5);
    }
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      OS.DiffRgn(this.handle, paramRegion.handle, this.handle);
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  public void translate(int paramInt1, int paramInt2)
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      OS.OffsetRgn(this.handle, (short)paramInt1, (short)paramInt2);
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  public void translate(Point paramPoint)
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    if (paramPoint == null) {
      SWT.error(4);
    }
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      translate(paramPoint.x, paramPoint.y);
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  public String toString()
  {
    if (isDisposed()) {
      return "Region {*DISPOSED*}";
    }
    return "Region {" + this.handle + "}";
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/graphics/Region.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */