package org.eclipse.swt.internal.cocoa;

public class DOMEvent
  extends NSObject
{
  public DOMEvent() {}
  
  public DOMEvent(long paramLong)
  {
    super(paramLong);
  }
  
  public DOMEvent(id paramid)
  {
    super(paramid);
  }
  
  public void preventDefault()
  {
    OS.objc_msgSend(this.id, OS.sel_preventDefault);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/DOMEvent.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */