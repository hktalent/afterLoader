package org.eclipse.swt.internal.cocoa;

public class NSFontManager
  extends NSObject
{
  public NSFontManager() {}
  
  public NSFontManager(long paramLong)
  {
    super(paramLong);
  }
  
  public NSFontManager(id paramid)
  {
    super(paramid);
  }
  
  public NSArray availableFontFamilies()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_availableFontFamilies);
    return l != 0L ? new NSArray(l) : null;
  }
  
  public NSArray availableFonts()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_availableFonts);
    return l != 0L ? new NSArray(l) : null;
  }
  
  public NSArray availableMembersOfFontFamily(NSString paramNSString)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_availableMembersOfFontFamily_, paramNSString != null ? paramNSString.id : 0L);
    return l != 0L ? new NSArray(l) : null;
  }
  
  public NSFont convertFont(NSFont paramNSFont, long paramLong)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_convertFont_toHaveTrait_, paramNSFont != null ? paramNSFont.id : 0L, paramLong);
    return l != 0L ? new NSFont(l) : null;
  }
  
  public NSFont fontWithFamily(NSString paramNSString, long paramLong1, long paramLong2, double paramDouble)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_fontWithFamily_traits_weight_size_, paramNSString != null ? paramNSString.id : 0L, paramLong1, paramLong2, paramDouble);
    return l != 0L ? new NSFont(l) : null;
  }
  
  public static NSFontManager sharedFontManager()
  {
    long l = OS.objc_msgSend(OS.class_NSFontManager, OS.sel_sharedFontManager);
    return l != 0L ? new NSFontManager(l) : null;
  }
  
  public long traitsOfFont(NSFont paramNSFont)
  {
    return OS.objc_msgSend(this.id, OS.sel_traitsOfFont_, paramNSFont != null ? paramNSFont.id : 0L);
  }
  
  public long weightOfFont(NSFont paramNSFont)
  {
    return OS.objc_msgSend(this.id, OS.sel_weightOfFont_, paramNSFont != null ? paramNSFont.id : 0L);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSFontManager.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */