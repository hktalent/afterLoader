package org.eclipse.swt.internal.cocoa;

public class NSColorList
  extends NSObject
{
  public NSColorList() {}
  
  public NSColorList(long paramLong)
  {
    super(paramLong);
  }
  
  public NSColorList(id paramid)
  {
    super(paramid);
  }
  
  public NSArray allKeys()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_allKeys);
    return l != 0L ? new NSArray(l) : null;
  }
  
  public static NSColorList colorListNamed(NSString paramNSString)
  {
    long l = OS.objc_msgSend(OS.class_NSColorList, OS.sel_colorListNamed_, paramNSString != null ? paramNSString.id : 0L);
    return l != 0L ? new NSColorList(l) : null;
  }
  
  public NSColor colorWithKey(NSString paramNSString)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_colorWithKey_, paramNSString != null ? paramNSString.id : 0L);
    return l != 0L ? new NSColor(l) : null;
  }
  
  public id initWithName(NSString paramNSString)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_initWithName_, paramNSString != null ? paramNSString.id : 0L);
    return l != 0L ? new id(l) : null;
  }
  
  public void insertColor(NSColor paramNSColor, NSString paramNSString, long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_insertColor_key_atIndex_, paramNSColor != null ? paramNSColor.id : 0L, paramNSString != null ? paramNSString.id : 0L, paramLong);
  }
  
  public void removeColorWithKey(NSString paramNSString)
  {
    OS.objc_msgSend(this.id, OS.sel_removeColorWithKey_, paramNSString != null ? paramNSString.id : 0L);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSColorList.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */