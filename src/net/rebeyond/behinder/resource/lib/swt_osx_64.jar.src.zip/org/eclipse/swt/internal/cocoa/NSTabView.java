package org.eclipse.swt.internal.cocoa;

public class NSTabView
  extends NSView
{
  public NSTabView() {}
  
  public NSTabView(long paramLong)
  {
    super(paramLong);
  }
  
  public NSTabView(id paramid)
  {
    super(paramid);
  }
  
  public void addTabViewItem(NSTabViewItem paramNSTabViewItem)
  {
    OS.objc_msgSend(this.id, OS.sel_addTabViewItem_, paramNSTabViewItem != null ? paramNSTabViewItem.id : 0L);
  }
  
  public NSRect contentRect()
  {
    NSRect localNSRect = new NSRect();
    OS.objc_msgSend_stret(localNSRect, this.id, OS.sel_contentRect);
    return localNSRect;
  }
  
  public void insertTabViewItem(NSTabViewItem paramNSTabViewItem, long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_insertTabViewItem_atIndex_, paramNSTabViewItem != null ? paramNSTabViewItem.id : 0L, paramLong);
  }
  
  public NSSize minimumSize()
  {
    NSSize localNSSize = new NSSize();
    OS.objc_msgSend_stret(localNSSize, this.id, OS.sel_minimumSize);
    return localNSSize;
  }
  
  public void removeTabViewItem(NSTabViewItem paramNSTabViewItem)
  {
    OS.objc_msgSend(this.id, OS.sel_removeTabViewItem_, paramNSTabViewItem != null ? paramNSTabViewItem.id : 0L);
  }
  
  public void selectTabViewItemAtIndex(long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_selectTabViewItemAtIndex_, paramLong);
  }
  
  public NSTabViewItem selectedTabViewItem()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_selectedTabViewItem);
    return l != 0L ? new NSTabViewItem(l) : null;
  }
  
  public void setControlSize(long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_setControlSize_, paramLong);
  }
  
  public void setDelegate(id paramid)
  {
    OS.objc_msgSend(this.id, OS.sel_setDelegate_, paramid != null ? paramid.id : 0L);
  }
  
  public void setFont(NSFont paramNSFont)
  {
    OS.objc_msgSend(this.id, OS.sel_setFont_, paramNSFont != null ? paramNSFont.id : 0L);
  }
  
  public void setTabViewType(long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_setTabViewType_, paramLong);
  }
  
  public NSTabViewItem tabViewItemAtPoint(NSPoint paramNSPoint)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_tabViewItemAtPoint_, paramNSPoint);
    return l != 0L ? new NSTabViewItem(l) : null;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSTabView.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */