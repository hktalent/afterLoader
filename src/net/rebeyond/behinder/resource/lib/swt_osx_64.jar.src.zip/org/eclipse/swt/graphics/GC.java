package org.eclipse.swt.graphics;

import org.eclipse.swt.SWT;
import org.eclipse.swt.internal.Callback;
import org.eclipse.swt.internal.cocoa.CGPathElement;
import org.eclipse.swt.internal.cocoa.CGPoint;
import org.eclipse.swt.internal.cocoa.CGRect;
import org.eclipse.swt.internal.cocoa.CGSize;
import org.eclipse.swt.internal.cocoa.NSAffineTransform;
import org.eclipse.swt.internal.cocoa.NSAffineTransformStruct;
import org.eclipse.swt.internal.cocoa.NSApplication;
import org.eclipse.swt.internal.cocoa.NSArray;
import org.eclipse.swt.internal.cocoa.NSAttributedString;
import org.eclipse.swt.internal.cocoa.NSAutoreleasePool;
import org.eclipse.swt.internal.cocoa.NSBezierPath;
import org.eclipse.swt.internal.cocoa.NSBitmapImageRep;
import org.eclipse.swt.internal.cocoa.NSColor;
import org.eclipse.swt.internal.cocoa.NSDictionary;
import org.eclipse.swt.internal.cocoa.NSGradient;
import org.eclipse.swt.internal.cocoa.NSGraphicsContext;
import org.eclipse.swt.internal.cocoa.NSImage;
import org.eclipse.swt.internal.cocoa.NSLayoutManager;
import org.eclipse.swt.internal.cocoa.NSMutableDictionary;
import org.eclipse.swt.internal.cocoa.NSNumber;
import org.eclipse.swt.internal.cocoa.NSObject;
import org.eclipse.swt.internal.cocoa.NSPoint;
import org.eclipse.swt.internal.cocoa.NSRange;
import org.eclipse.swt.internal.cocoa.NSRect;
import org.eclipse.swt.internal.cocoa.NSScreen;
import org.eclipse.swt.internal.cocoa.NSSize;
import org.eclipse.swt.internal.cocoa.NSString;
import org.eclipse.swt.internal.cocoa.NSTextContainer;
import org.eclipse.swt.internal.cocoa.NSTextStorage;
import org.eclipse.swt.internal.cocoa.NSThread;
import org.eclipse.swt.internal.cocoa.NSView;
import org.eclipse.swt.internal.cocoa.NSWindow;
import org.eclipse.swt.internal.cocoa.OS;
import org.eclipse.swt.internal.cocoa.id;

public final class GC
  extends Resource
{
  public NSGraphicsContext handle;
  Drawable drawable;
  GCData data;
  CGPathElement element;
  int count;
  int typeCount;
  byte[] types;
  double[] points;
  double[] point;
  static final int TAB_COUNT = 32;
  static final int FOREGROUND = 1;
  static final int BACKGROUND = 2;
  static final int FONT = 4;
  static final int LINE_STYLE = 8;
  static final int LINE_CAP = 16;
  static final int LINE_JOIN = 32;
  static final int LINE_WIDTH = 64;
  static final int LINE_MITERLIMIT = 128;
  static final int FOREGROUND_FILL = 256;
  static final int DRAW_OFFSET = 512;
  static final int CLIPPING = 1024;
  static final int TRANSFORM = 2048;
  static final int VISIBLE_REGION = 4096;
  static final int DRAW = 3833;
  static final int FILL = 3074;
  static final float[] LINE_DOT = { 1.0F, 1.0F };
  static final float[] LINE_DASH = { 3.0F, 1.0F };
  static final float[] LINE_DASHDOT = { 3.0F, 1.0F, 1.0F, 1.0F };
  static final float[] LINE_DASHDOTDOT = { 3.0F, 1.0F, 1.0F, 1.0F, 1.0F, 1.0F };
  static final float[] LINE_DOT_ZERO = { 3.0F, 3.0F };
  static final float[] LINE_DASH_ZERO = { 18.0F, 6.0F };
  static final float[] LINE_DASHDOT_ZERO = { 9.0F, 6.0F, 3.0F, 6.0F };
  static final float[] LINE_DASHDOTDOT_ZERO = { 9.0F, 3.0F, 3.0F, 3.0F, 3.0F, 3.0F };
  
  GC() {}
  
  public GC(Drawable paramDrawable)
  {
    this(paramDrawable, 0);
  }
  
  public GC(Drawable paramDrawable, int paramInt)
  {
    if (paramDrawable == null) {
      SWT.error(4);
    }
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      GCData localGCData = new GCData();
      localGCData.style = checkStyle(paramInt);
      long l = paramDrawable.internal_new_GC(localGCData);
      Device localDevice = localGCData.device;
      if (localDevice == null) {
        localDevice = Device.getDevice();
      }
      if (localDevice == null) {
        SWT.error(4);
      }
      this.device = (localGCData.device = localDevice);
      init(paramDrawable, localGCData, l);
      init();
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  static int checkStyle(int paramInt)
  {
    if ((paramInt & 0x2000000) != 0) {
      paramInt &= 0xFBFFFFFF;
    }
    return paramInt & 0x6000000;
  }
  
  public static GC cocoa_new(Drawable paramDrawable, GCData paramGCData)
  {
    GC localGC = new GC();
    long l = paramDrawable.internal_new_GC(paramGCData);
    localGC.device = paramGCData.device;
    localGC.init(paramDrawable, paramGCData, l);
    return localGC;
  }
  
  long applierFunc(long paramLong1, long paramLong2)
  {
    OS.memmove(this.element, paramLong2, CGPathElement.sizeof);
    int i = 0;
    int j = 1;
    switch (this.element.type)
    {
    case 0: 
      i = 1;
      break;
    case 1: 
      i = 2;
      break;
    case 2: 
      i = 3;
      j = 2;
      break;
    case 3: 
      i = 4;
      j = 3;
      break;
    case 4: 
      i = 5;
      j = 0;
    }
    if (this.types != null)
    {
      this.types[this.typeCount] = ((byte)i);
      if (j > 0)
      {
        OS.memmove(this.point, this.element.points, j * CGPoint.sizeof);
        System.arraycopy(this.point, 0, this.points, this.count, j * 2);
      }
    }
    this.typeCount += 1;
    this.count += j * 2;
    return 0L;
  }
  
  NSAutoreleasePool checkGC(int paramInt)
  {
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    if ((this.data.flippedContext != null) && (!this.handle.isEqual(NSGraphicsContext.currentContext())))
    {
      this.data.restoreContext = true;
      NSGraphicsContext.static_saveGraphicsState();
      NSGraphicsContext.setCurrentContext(this.handle);
    }
    Object localObject2;
    Object localObject3;
    if ((paramInt & 0xC00) != 0)
    {
      NSView localNSView = this.data.view;
      if (((this.data.state & 0x400) == 0) || ((this.data.state & 0x800) == 0) || ((this.data.state & 0x1000) == 0))
      {
        boolean bool = this.handle.shouldAntialias();
        this.handle.restoreGraphicsState();
        this.handle.saveGraphicsState();
        this.handle.setShouldAntialias(bool);
        if ((localNSView != null) && ((this.data.paintRect == null) || (!localNSView.isFlipped())))
        {
          localObject2 = NSAffineTransform.transform();
          localObject3 = localNSView.convertRect_toView_(localNSView.bounds(), null);
          if (this.data.paintRect == null)
          {
            ((NSAffineTransform)localObject2).translateXBy(((NSRect)localObject3).x, ((NSRect)localObject3).y + ((NSRect)localObject3).height);
            double d2 = localNSView.window().userSpaceScaleFactor();
            ((NSAffineTransform)localObject2).scaleXBy(d2, d2);
          }
          else
          {
            ((NSAffineTransform)localObject2).translateXBy(0.0D, ((NSRect)localObject3).height);
          }
          ((NSAffineTransform)localObject2).scaleXBy(1.0D, -1.0D);
          ((NSAffineTransform)localObject2).concat();
          if (this.data.visibleRgn != 0L)
          {
            if ((this.data.visiblePath == null) || ((this.data.state & 0x1000) == 0))
            {
              if (this.data.visiblePath != null) {
                this.data.visiblePath.release();
              }
              this.data.visiblePath = Region.cocoa_new(this.device, this.data.visibleRgn).getPath();
            }
            this.data.visiblePath.addClip();
            this.data.state |= 0x1000;
          }
        }
        if (this.data.clipPath != null) {
          this.data.clipPath.addClip();
        }
        if (this.data.transform != null) {
          this.data.transform.concat();
        }
        paramInt &= 0xF3FF;
        this.data.state |= 0xC00;
        this.data.state &= 0xFFFFFFFC;
      }
    }
    OS.CGContextSetBlendMode(this.handle.graphicsPort(), this.data.xorMode ? 10 : 0);
    int i = this.data.state;
    if ((i & paramInt) == paramInt) {
      return localNSAutoreleasePool;
    }
    i = (i ^ paramInt) & paramInt;
    this.data.state |= paramInt;
    if ((i & 0x1) != 0)
    {
      localObject1 = this.data.foregroundPattern;
      if (localObject1 != null)
      {
        if (((Pattern)localObject1).color != null) {
          ((Pattern)localObject1).color.setStroke();
        }
      }
      else
      {
        localObject2 = this.data.foreground;
        if (this.data.fg != null) {
          this.data.fg.release();
        }
        localObject3 = this.data.fg = NSColor.colorWithDeviceRed(localObject2[0], localObject2[1], localObject2[2], this.data.alpha / 255.0F);
        ((NSColor)localObject3).retain();
        ((NSColor)localObject3).setStroke();
      }
    }
    if ((i & 0x100) != 0)
    {
      localObject1 = this.data.foregroundPattern;
      if (localObject1 != null)
      {
        if (((Pattern)localObject1).color != null) {
          ((Pattern)localObject1).color.setFill();
        }
      }
      else
      {
        localObject2 = this.data.foreground;
        if (this.data.fg != null) {
          this.data.fg.release();
        }
        localObject3 = this.data.fg = NSColor.colorWithDeviceRed(localObject2[0], localObject2[1], localObject2[2], this.data.alpha / 255.0F);
        ((NSColor)localObject3).retain();
        ((NSColor)localObject3).setFill();
      }
      this.data.state &= 0xFFFFFFFD;
    }
    if ((i & 0x2) != 0)
    {
      localObject1 = this.data.backgroundPattern;
      if (localObject1 != null)
      {
        if (((Pattern)localObject1).color != null) {
          ((Pattern)localObject1).color.setFill();
        }
      }
      else
      {
        localObject2 = this.data.background;
        if (this.data.bg != null) {
          this.data.bg.release();
        }
        localObject3 = this.data.bg = NSColor.colorWithDeviceRed(localObject2[0], localObject2[1], localObject2[2], this.data.alpha / 255.0F);
        ((NSColor)localObject3).retain();
        ((NSColor)localObject3).setFill();
      }
      this.data.state &= 0xFEFF;
    }
    Object localObject1 = this.data.path;
    if ((i & 0x40) != 0)
    {
      ((NSBezierPath)localObject1).setLineWidth(this.data.lineWidth == 0.0F ? 1.0D : this.data.lineWidth);
      switch (this.data.lineStyle)
      {
      case 2: 
      case 3: 
      case 4: 
      case 5: 
        i |= 0x8;
      }
    }
    if ((i & 0x8) != 0)
    {
      localObject2 = null;
      float f = this.data.lineWidth;
      switch (this.data.lineStyle)
      {
      case 1: 
        break;
      case 2: 
        localObject2 = f != 0.0F ? LINE_DASH : LINE_DASH_ZERO;
        break;
      case 3: 
        localObject2 = f != 0.0F ? LINE_DOT : LINE_DOT_ZERO;
        break;
      case 4: 
        localObject2 = f != 0.0F ? LINE_DASHDOT : LINE_DASHDOT_ZERO;
        break;
      case 5: 
        localObject2 = f != 0.0F ? LINE_DASHDOTDOT : LINE_DASHDOTDOT_ZERO;
        break;
      case 6: 
        localObject2 = this.data.lineDashes;
      }
      if (localObject2 != null)
      {
        double[] arrayOfDouble = new double[localObject2.length];
        for (int k = 0; k < arrayOfDouble.length; k++) {
          arrayOfDouble[k] = ((f == 0.0F) || (this.data.lineStyle == 6) ? localObject2[k] : localObject2[k] * f);
        }
        ((NSBezierPath)localObject1).setLineDash(arrayOfDouble, arrayOfDouble.length, this.data.lineDashesOffset);
      }
      else
      {
        ((NSBezierPath)localObject1).setLineDash(null, 0L, 0.0D);
      }
    }
    if ((i & 0x80) != 0) {
      ((NSBezierPath)localObject1).setMiterLimit(this.data.lineMiterLimit);
    }
    int j;
    if ((i & 0x20) != 0)
    {
      j = 0;
      switch (this.data.lineJoin)
      {
      case 1: 
        j = 0;
        break;
      case 2: 
        j = 1;
        break;
      case 3: 
        j = 2;
      }
      ((NSBezierPath)localObject1).setLineJoinStyle(j);
    }
    if ((i & 0x10) != 0)
    {
      j = 0;
      switch (this.data.lineCap)
      {
      case 2: 
        j = 1;
        break;
      case 1: 
        j = 0;
        break;
      case 3: 
        j = 2;
      }
      ((NSBezierPath)localObject1).setLineCapStyle(j);
    }
    if ((i & 0x200) != 0)
    {
      this.data.drawXOffset = (this.data.drawYOffset = 0.0D);
      NSSize localNSSize = new NSSize();
      localNSSize.width = (localNSSize.height = 1.0D);
      if (this.data.transform != null) {
        localNSSize = this.data.transform.transformSize(localNSSize);
      }
      double d1 = localNSSize.width;
      if (d1 < 0.0D) {
        d1 = -d1;
      }
      double d3 = this.data.lineWidth * d1;
      if ((d3 == 0.0D) || ((int)d3 % 2 == 1)) {
        this.data.drawXOffset = (0.5D / d1);
      }
      d1 = localNSSize.height;
      if (d1 < 0.0D) {
        d1 = -d1;
      }
      d3 = this.data.lineWidth * d1;
      if ((d3 == 0.0D) || ((int)d3 % 2 == 1)) {
        this.data.drawYOffset = (0.5D / d1);
      }
    }
    return localNSAutoreleasePool;
  }
  
  public void copyArea(Image paramImage, int paramInt1, int paramInt2)
  {
    if (this.handle == null) {
      SWT.error(44);
    }
    if (paramImage == null) {
      SWT.error(4);
    }
    if ((paramImage.type != 0) || (paramImage.isDisposed())) {
      SWT.error(5);
    }
    NSAutoreleasePool localNSAutoreleasePool = checkGC(3072);
    try
    {
      Object localObject5;
      Object localObject6;
      Object localObject7;
      if (this.data.image != null)
      {
        int i = paramInt1;
        int j = paramInt2;
        int k = 0;
        int m = 0;
        localObject5 = this.data.image.handle.size();
        int n = (int)((NSSize)localObject5).height;
        int i2 = (int)((NSSize)localObject5).width - paramInt1;
        int i3 = (int)((NSSize)localObject5).height - paramInt2;
        int i4 = i2;
        int i5 = i3;
        localObject6 = NSGraphicsContext.graphicsContextWithBitmapImageRep(paramImage.getRepresentation());
        NSGraphicsContext.static_saveGraphicsState();
        NSGraphicsContext.setCurrentContext((NSGraphicsContext)localObject6);
        localObject7 = NSAffineTransform.transform();
        NSSize localNSSize = paramImage.handle.size();
        ((NSAffineTransform)localObject7).translateXBy(0.0D, localNSSize.height - (i3 + 2 * m));
        ((NSAffineTransform)localObject7).concat();
        NSRect localNSRect1 = new NSRect();
        localNSRect1.x = i;
        localNSRect1.y = (n - (j + i5));
        localNSRect1.width = i4;
        localNSRect1.height = i5;
        NSRect localNSRect2 = new NSRect();
        localNSRect2.x = k;
        localNSRect2.y = m;
        localNSRect2.width = i2;
        localNSRect2.height = i3;
        this.data.image.handle.drawInRect(localNSRect2, localNSRect1, 1L, 1.0D);
        NSGraphicsContext.static_restoreGraphicsState();
        return;
      }
      Object localObject1;
      Object localObject2;
      Object localObject3;
      Object localObject4;
      long l2;
      if (this.data.view != null)
      {
        localObject1 = new NSPoint();
        ((NSPoint)localObject1).x = paramInt1;
        ((NSPoint)localObject1).y = paramInt2;
        localObject2 = this.data.view.window();
        localObject1 = this.data.view.convertPoint_toView_((NSPoint)localObject1, ((NSWindow)localObject2).contentView().superview());
        localObject3 = ((NSWindow)localObject2).frame();
        ((NSPoint)localObject1).y = (((NSRect)localObject3).height - ((NSPoint)localObject1).y);
        localObject4 = paramImage.handle.size();
        localObject5 = new CGRect();
        ((CGRect)localObject5).size.width = ((NSSize)localObject4).width;
        ((CGRect)localObject5).size.height = ((NSSize)localObject4).height;
        CGRect localCGRect = new CGRect();
        localCGRect.origin.x = ((NSPoint)localObject1).x;
        localCGRect.origin.y = ((NSPoint)localObject1).y;
        localCGRect.size.width = ((NSSize)localObject4).width;
        localCGRect.size.height = ((NSSize)localObject4).height;
        NSBitmapImageRep localNSBitmapImageRep = paramImage.getRepresentation();
        NSGraphicsContext localNSGraphicsContext = NSGraphicsContext.graphicsContextWithBitmapImageRep(localNSBitmapImageRep);
        NSGraphicsContext.static_saveGraphicsState();
        NSGraphicsContext.setCurrentContext(localNSGraphicsContext);
        l2 = OS.objc_msgSend(NSApplication.sharedApplication().id, OS.sel_contextID);
        OS.CGContextCopyWindowContentsToRect(localNSGraphicsContext.graphicsPort(), (CGRect)localObject5, l2, ((NSWindow)localObject2).windowNumber(), localCGRect);
        NSGraphicsContext.static_restoreGraphicsState();
        return;
      }
      if (this.handle.isDrawingToScreen())
      {
        localObject1 = paramImage.handle;
        localObject2 = ((NSImage)localObject1).size();
        localObject3 = null;
        localObject4 = null;
        if (OS.VERSION >= 4208)
        {
          localObject3 = NSScreen.screens();
          localObject4 = NSString.stringWith("NSScreenNumber");
        }
        localObject5 = new CGRect();
        ((CGRect)localObject5).origin.x = paramInt1;
        ((CGRect)localObject5).origin.y = paramInt2;
        ((CGRect)localObject5).size.width = ((NSSize)localObject2).width;
        ((CGRect)localObject5).size.height = ((NSSize)localObject2).height;
        int i1 = 16;
        long l1 = OS.malloc(4 * i1);
        l2 = OS.malloc(4L);
        if (OS.CGGetDisplaysWithRect((CGRect)localObject5, i1, l1, l2) != 0) {
          return;
        }
        localObject6 = new int[1];
        localObject7 = new int[1];
        OS.memmove((int[])localObject6, l2, OS.PTR_SIZEOF);
        for (int i6 = 0; i6 < localObject6[0]; i6++)
        {
          OS.memmove((int[])localObject7, l1 + i6 * 4, 4L);
          OS.CGDisplayBounds(localObject7[0], (CGRect)localObject5);
          double d = 1.0D;
          if (OS.VERSION >= 4208) {
            for (int i7 = 0; i7 < ((NSArray)localObject3).count(); i7++)
            {
              NSScreen localNSScreen = new NSScreen(((NSArray)localObject3).objectAtIndex(i7));
              if (localObject7[0] == new NSNumber(localNSScreen.deviceDescription().objectForKey((id)localObject4)).intValue())
              {
                d = localNSScreen.backingScaleFactor();
                break;
              }
            }
          }
          long l3 = 0L;
          long l4 = OS.VERSION >= 4208 ? 0L : OS.CGDisplayBaseAddress(localObject7[0]);
          if (l4 != 0L)
          {
            long l5 = OS.CGDisplayPixelsWide(localObject7[0]);
            long l6 = OS.CGDisplayPixelsHigh(localObject7[0]);
            long l7 = OS.CGDisplayBytesPerRow(localObject7[0]);
            long l8 = OS.CGDisplayBitsPerPixel(localObject7[0]);
            long l9 = OS.CGDisplayBitsPerSample(localObject7[0]);
            int i8 = 6;
            switch ((int)l8)
            {
            case 16: 
              i8 |= OS.kCGBitmapByteOrder16Host;
              break;
            case 32: 
              i8 |= OS.kCGBitmapByteOrder32Host;
            }
            long l10;
            long l11;
            if ((OS.__BIG_ENDIAN__()) && (OS.VERSION >= 4160))
            {
              l10 = OS.CGColorSpaceCreateDeviceRGB();
              l11 = OS.CGBitmapContextCreate(l4, l5, l6, l9, l7, l10, i8);
              OS.CGColorSpaceRelease(l10);
              l3 = OS.CGBitmapContextCreateImage(l11);
              OS.CGContextRelease(l11);
            }
            else
            {
              l10 = OS.CGDataProviderCreateWithData(0L, l4, l7 * l6, 0L);
              l11 = OS.CGColorSpaceCreateDeviceRGB();
              l3 = OS.CGImageCreate(l5, l6, l9, l8, l7, l11, i8, l10, 0L, true, 0);
              OS.CGColorSpaceRelease(l11);
              OS.CGDataProviderRelease(l10);
            }
          }
          else if (OS.VERSION >= 4192)
          {
            l3 = OS.CGDisplayCreateImage(localObject7[0]);
          }
          if (l3 != 0L)
          {
            copyArea(paramImage, (int)(paramInt1 * d - ((CGRect)localObject5).origin.x), (int)(paramInt2 * d - ((CGRect)localObject5).origin.y), l3, d);
            OS.CGImageRelease(l3);
          }
        }
        OS.free(l1);
        OS.free(l2);
      }
    }
    finally
    {
      uncheckGC(localNSAutoreleasePool);
    }
  }
  
  void copyArea(Image paramImage, int paramInt1, int paramInt2, long paramLong, double paramDouble)
  {
    if (paramLong == 0L) {
      return;
    }
    NSBitmapImageRep localNSBitmapImageRep = paramImage.getRepresentation();
    long l1 = localNSBitmapImageRep.bitsPerSample();
    long l2 = localNSBitmapImageRep.pixelsWide();
    long l3 = localNSBitmapImageRep.pixelsHigh();
    long l4 = localNSBitmapImageRep.bytesPerRow();
    long l5 = localNSBitmapImageRep.bitmapData();
    long l6 = localNSBitmapImageRep.bitmapFormat();
    int i;
    if (localNSBitmapImageRep.hasAlpha()) {
      i = (l6 & 1L) != 0L ? 4 : 3;
    } else {
      i = (l6 & 1L) != 0L ? 6 : 5;
    }
    long l7 = OS.CGColorSpaceCreateDeviceRGB();
    long l8 = OS.CGBitmapContextCreate(l5, l2, l3, l1, l4, l7, i);
    OS.CGColorSpaceRelease(l7);
    if (l8 != 0L)
    {
      CGRect localCGRect = new CGRect();
      localCGRect.origin.x = (-paramInt1 / paramDouble);
      localCGRect.origin.y = (paramInt2 / paramDouble);
      localCGRect.size.width = (OS.CGImageGetWidth(paramLong) / paramDouble);
      localCGRect.size.height = (OS.CGImageGetHeight(paramLong) / paramDouble);
      OS.CGContextTranslateCTM(l8, 0.0D, -(localCGRect.size.height - l3));
      OS.CGContextDrawImage(l8, localCGRect, paramLong);
      OS.CGContextRelease(l8);
    }
  }
  
  public void copyArea(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6)
  {
    copyArea(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, true);
  }
  
  public void copyArea(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, boolean paramBoolean)
  {
    if (this.handle == null) {
      SWT.error(44);
    }
    if ((paramInt3 <= 0) || (paramInt4 <= 0)) {
      return;
    }
    int i = paramInt5 - paramInt1;
    int j = paramInt6 - paramInt2;
    if ((i == 0) && (j == 0)) {
      return;
    }
    NSAutoreleasePool localNSAutoreleasePool = checkGC(3072);
    try
    {
      Image localImage = this.data.image;
      Object localObject1;
      Object localObject2;
      Object localObject3;
      if (localImage != null)
      {
        localObject1 = localImage.handle;
        localObject2 = ((NSImage)localObject1).size();
        int k = (int)((NSSize)localObject2).height;
        this.handle.saveGraphicsState();
        localObject3 = NSAffineTransform.transform();
        ((NSAffineTransform)localObject3).scaleXBy(1.0D, -1.0D);
        ((NSAffineTransform)localObject3).translateXBy(0.0D, -(paramInt4 + 2 * paramInt6));
        ((NSAffineTransform)localObject3).concat();
        NSRect localNSRect2 = new NSRect();
        localNSRect2.x = paramInt1;
        localNSRect2.y = (k - (paramInt2 + paramInt4));
        localNSRect2.width = paramInt3;
        localNSRect2.height = paramInt4;
        NSRect localNSRect3 = new NSRect();
        localNSRect3.x = paramInt5;
        localNSRect3.y = paramInt6;
        localNSRect3.width = paramInt3;
        localNSRect3.height = paramInt4;
        ((NSImage)localObject1).drawInRect(localNSRect3, localNSRect2, 1L, 1.0D);
        this.handle.restoreGraphicsState();
        return;
      }
      if (this.data.view != null)
      {
        localObject1 = this.data.view;
        localObject2 = ((NSView)localObject1).visibleRect();
        if ((((NSRect)localObject2).width <= 0.0D) || (((NSRect)localObject2).height <= 0.0D)) {
          return;
        }
        NSRect localNSRect1 = new NSRect();
        localNSRect1.x = paramInt1;
        localNSRect1.y = paramInt2;
        localNSRect1.width = paramInt3;
        localNSRect1.height = paramInt4;
        localObject3 = new NSPoint();
        ((NSPoint)localObject3).x = paramInt5;
        ((NSPoint)localObject3).y = paramInt6;
        ((NSView)localObject1).lockFocus();
        OS.NSCopyBits(0L, localNSRect1, (NSPoint)localObject3);
        ((NSView)localObject1).unlockFocus();
        if (paramBoolean)
        {
          int m = (paramInt5 + paramInt3 < paramInt1) || (paramInt1 + paramInt3 < paramInt5) || (paramInt6 + paramInt4 < paramInt2) || (paramInt2 + paramInt4 < paramInt6) ? 1 : 0;
          if (m != 0)
          {
            ((NSView)localObject1).setNeedsDisplayInRect(localNSRect1);
          }
          else
          {
            int n;
            if (i != 0)
            {
              n = paramInt5 - i;
              if (i < 0) {
                n = paramInt5 + paramInt3;
              }
              localNSRect1.x = n;
              localNSRect1.width = Math.abs(i);
              ((NSView)localObject1).setNeedsDisplayInRect(localNSRect1);
            }
            if (j != 0)
            {
              n = paramInt6 - j;
              if (j < 0) {
                n = paramInt6 + paramInt4;
              }
              localNSRect1.x = paramInt1;
              localNSRect1.y = n;
              localNSRect1.width = paramInt3;
              localNSRect1.height = Math.abs(j);
              ((NSView)localObject1).setNeedsDisplayInRect(localNSRect1);
            }
          }
          NSRect localNSRect4 = new NSRect();
          localNSRect4.x = paramInt1;
          localNSRect4.y = paramInt2;
          localNSRect4.width = paramInt3;
          localNSRect4.height = paramInt4;
          OS.NSIntersectionRect((NSRect)localObject2, (NSRect)localObject2, localNSRect4);
          if (!OS.NSEqualRects((NSRect)localObject2, localNSRect4))
          {
            if (localNSRect4.x != ((NSRect)localObject2).x)
            {
              localNSRect4.x += i;
              localNSRect4.y += j;
              localNSRect1.width = (((NSRect)localObject2).x - localNSRect4.x);
              localNSRect1.height = localNSRect4.height;
              ((NSView)localObject1).setNeedsDisplayInRect(localNSRect1);
            }
            if (((NSRect)localObject2).x + ((NSRect)localObject2).width != localNSRect4.x + localNSRect4.width)
            {
              localNSRect1.x = (localNSRect4.x + ((NSRect)localObject2).width + i);
              localNSRect4.y += j;
              localNSRect4.width -= ((NSRect)localObject2).width;
              localNSRect1.height = localNSRect4.height;
              ((NSView)localObject1).setNeedsDisplayInRect(localNSRect1);
            }
            if (((NSRect)localObject2).y != localNSRect4.y)
            {
              localNSRect1.x = (((NSRect)localObject2).x + i);
              localNSRect4.y += j;
              localNSRect1.width = ((NSRect)localObject2).width;
              localNSRect1.height = (((NSRect)localObject2).y - localNSRect4.y);
              ((NSView)localObject1).setNeedsDisplayInRect(localNSRect1);
            }
            if (((NSRect)localObject2).y + ((NSRect)localObject2).height != localNSRect4.y + localNSRect4.height)
            {
              localNSRect1.x = (((NSRect)localObject2).x + i);
              localNSRect1.y = (((NSRect)localObject2).y + ((NSRect)localObject2).height + j);
              localNSRect1.width = ((NSRect)localObject2).width;
              localNSRect1.height = (localNSRect4.y + localNSRect4.height - (((NSRect)localObject2).y + ((NSRect)localObject2).height));
              ((NSView)localObject1).setNeedsDisplayInRect(localNSRect1);
            }
          }
        }
        return;
      }
    }
    finally
    {
      uncheckGC(localNSAutoreleasePool);
    }
  }
  
  static long createCGPathRef(NSBezierPath paramNSBezierPath)
  {
    long l1 = paramNSBezierPath.elementCount();
    if (l1 > 0L)
    {
      long l2 = OS.CGPathCreateMutable();
      if (l2 == 0L) {
        SWT.error(2);
      }
      long l3 = OS.malloc(NSPoint.sizeof * 3);
      if (l3 == 0L) {
        SWT.error(2);
      }
      double[] arrayOfDouble = new double[6];
      for (int i = 0; i < l1; i++)
      {
        int j = (int)paramNSBezierPath.elementAtIndex(i, l3);
        switch (j)
        {
        case 0: 
          OS.memmove(arrayOfDouble, l3, NSPoint.sizeof);
          OS.CGPathMoveToPoint(l2, 0L, arrayOfDouble[0], arrayOfDouble[1]);
          break;
        case 1: 
          OS.memmove(arrayOfDouble, l3, NSPoint.sizeof);
          OS.CGPathAddLineToPoint(l2, 0L, arrayOfDouble[0], arrayOfDouble[1]);
          break;
        case 2: 
          OS.memmove(arrayOfDouble, l3, NSPoint.sizeof * 3);
          OS.CGPathAddCurveToPoint(l2, 0L, arrayOfDouble[0], arrayOfDouble[1], arrayOfDouble[2], arrayOfDouble[3], arrayOfDouble[4], arrayOfDouble[5]);
          break;
        case 3: 
          OS.CGPathCloseSubpath(l2);
        }
      }
      OS.free(l3);
      return l2;
    }
    return 0L;
  }
  
  void createLayout()
  {
    NSSize localNSSize = new NSSize();
    localNSSize.width = 5000000.0D;
    localNSSize.height = 5000000.0D;
    NSTextStorage localNSTextStorage = (NSTextStorage)new NSTextStorage().alloc().init();
    NSLayoutManager localNSLayoutManager = (NSLayoutManager)new NSLayoutManager().alloc().init();
    localNSLayoutManager.setBackgroundLayoutEnabled(NSThread.isMainThread());
    NSTextContainer localNSTextContainer = (NSTextContainer)new NSTextContainer().alloc();
    localNSTextContainer = localNSTextContainer.initWithContainerSize(localNSSize);
    localNSTextContainer.setLineFragmentPadding(0.0D);
    localNSTextStorage.addLayoutManager(localNSLayoutManager);
    localNSLayoutManager.addTextContainer(localNSTextContainer);
    localNSLayoutManager.release();
    localNSTextContainer.release();
    this.data.textContainer = localNSTextContainer;
    this.data.layoutManager = localNSLayoutManager;
    this.data.textStorage = localNSTextStorage;
  }
  
  NSAttributedString createString(String paramString, int paramInt, boolean paramBoolean)
  {
    NSMutableDictionary localNSMutableDictionary = ((NSMutableDictionary)new NSMutableDictionary().alloc()).initWithCapacity(5L);
    Font localFont = this.data.font;
    localNSMutableDictionary.setObject(localFont.handle, OS.NSFontAttributeName);
    localFont.addTraits(localNSMutableDictionary);
    if (paramBoolean)
    {
      Pattern localPattern = this.data.foregroundPattern;
      if (localPattern != null)
      {
        if (localPattern.color != null) {
          localNSMutableDictionary.setObject(localPattern.color, OS.NSForegroundColorAttributeName);
        }
      }
      else
      {
        localObject = this.data.fg;
        if (localObject == null)
        {
          double[] arrayOfDouble = this.data.foreground;
          localObject = this.data.fg = NSColor.colorWithDeviceRed(arrayOfDouble[0], arrayOfDouble[1], arrayOfDouble[2], this.data.alpha / 255.0F);
          ((NSColor)localObject).retain();
        }
        localNSMutableDictionary.setObject((id)localObject, OS.NSForegroundColorAttributeName);
      }
    }
    if ((paramInt & 0x4) == 0) {
      localNSMutableDictionary.setObject(this.device.paragraphStyle, OS.NSParagraphStyleAttributeName);
    }
    int i = paramString.length();
    Object localObject = new char[i];
    paramString.getChars(0, i, (char[])localObject, 0);
    if (((paramInt & 0x8) != 0) || ((paramInt & 0x2) == 0))
    {
      int j = 0;
      int k = 0;
      while (j < localObject.length)
      {
        int m = localObject[(k++)] = localObject[(j++)];
        switch (m)
        {
        case 38: 
          if ((paramInt & 0x8) != 0) {
            if (j != localObject.length) {
              if (localObject[j] == '&') {
                j++;
              } else {
                k--;
              }
            }
          }
          break;
        case 10: 
        case 13: 
          if ((paramInt & 0x2) == 0)
          {
            if ((m == 13) && (j != localObject.length) && (localObject[j] == '\n')) {
              j++;
            }
            k--;
          }
          break;
        }
      }
      i = k;
    }
    NSString localNSString = ((NSString)new NSString().alloc()).initWithCharacters((char[])localObject, i);
    NSAttributedString localNSAttributedString = ((NSAttributedString)new NSAttributedString().alloc()).initWithString(localNSString, localNSMutableDictionary);
    localNSMutableDictionary.release();
    localNSString.release();
    return localNSAttributedString;
  }
  
  NSBezierPath createNSBezierPath(long paramLong)
  {
    Callback localCallback = new Callback(this, "applierFunc", 2);
    long l = localCallback.getAddress();
    if (l == 0L) {
      SWT.error(3);
    }
    this.count = (this.typeCount = 0);
    this.element = new CGPathElement();
    OS.CGPathApply(paramLong, 0L, l);
    this.types = new byte[this.typeCount];
    this.points = new double[this.count];
    this.point = new double[6];
    this.count = (this.typeCount = 0);
    OS.CGPathApply(paramLong, 0L, l);
    localCallback.dispose();
    NSBezierPath localNSBezierPath = NSBezierPath.bezierPath();
    NSPoint localNSPoint1 = new NSPoint();
    NSPoint localNSPoint2 = new NSPoint();
    NSPoint localNSPoint3 = new NSPoint();
    int i = 0;
    int j = 0;
    while (i < this.types.length)
    {
      switch (this.types[i])
      {
      case 1: 
        localNSPoint1.x = this.points[(j++)];
        localNSPoint1.y = this.points[(j++)];
        localNSBezierPath.moveToPoint(localNSPoint1);
        break;
      case 2: 
        localNSPoint1.x = this.points[(j++)];
        localNSPoint1.y = this.points[(j++)];
        localNSBezierPath.lineToPoint(localNSPoint1);
        break;
      case 4: 
        localNSPoint2.x = this.points[(j++)];
        localNSPoint2.y = this.points[(j++)];
        localNSPoint3.x = this.points[(j++)];
        localNSPoint3.y = this.points[(j++)];
        localNSPoint1.x = this.points[(j++)];
        localNSPoint1.y = this.points[(j++)];
        localNSBezierPath.curveToPoint(localNSPoint1, localNSPoint2, localNSPoint3);
        break;
      case 3: 
        double d1 = localNSPoint1.x;
        double d2 = localNSPoint1.y;
        localNSPoint2.x = this.points[(j++)];
        localNSPoint2.y = this.points[(j++)];
        localNSPoint1.x = this.points[(j++)];
        localNSPoint1.y = this.points[(j++)];
        double d3 = d1;
        double d4 = d2;
        double d5 = d3 + 2.0D * (localNSPoint2.x - d3) / 3.0D;
        double d6 = d4 + 2.0D * (localNSPoint2.y - d4) / 3.0D;
        double d7 = d5 + (localNSPoint1.x - d3) / 3.0D;
        double d8 = d6 + (localNSPoint1.y - d4) / 3.0D;
        localNSPoint2.x = d5;
        localNSPoint2.y = d6;
        localNSPoint3.x = d7;
        localNSPoint3.y = d8;
        localNSBezierPath.curveToPoint(localNSPoint1, localNSPoint2, localNSPoint3);
        break;
      case 5: 
        localNSBezierPath.closePath();
        break;
      default: 
        dispose();
        SWT.error(5);
      }
      i++;
    }
    this.element = null;
    this.types = null;
    this.points = null;
    localNSPoint1 = null;
    return localNSBezierPath;
  }
  
  void destroy()
  {
    Image localImage = this.data.image;
    if (localImage != null)
    {
      localImage.memGC = null;
      localImage.createAlpha();
    }
    if (this.data.textStorage != null) {
      this.data.textStorage.release();
    }
    this.data.textStorage = null;
    this.data.layoutManager = null;
    this.data.textContainer = null;
    if (this.data.fg != null) {
      this.data.fg.release();
    }
    if (this.data.bg != null) {
      this.data.bg.release();
    }
    if (this.data.path != null) {
      this.data.path.release();
    }
    if (this.data.clipPath != null) {
      this.data.clipPath.release();
    }
    if (this.data.visiblePath != null) {
      this.data.visiblePath.release();
    }
    if (this.data.transform != null) {
      this.data.transform.release();
    }
    if (this.data.inverseTransform != null) {
      this.data.inverseTransform.release();
    }
    this.data.path = (this.data.clipPath = this.data.visiblePath = null);
    this.data.transform = (this.data.inverseTransform = null);
    this.data.fg = (this.data.bg = null);
    if (this.drawable != null) {
      this.drawable.internal_dispose_GC(this.handle.id, this.data);
    }
    this.handle.restoreGraphicsState();
    this.handle.release();
    this.drawable = null;
    this.data.image = null;
    this.data = null;
    this.handle = null;
  }
  
  public void drawArc(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6)
  {
    if (this.handle == null) {
      SWT.error(44);
    }
    if (paramInt3 < 0)
    {
      paramInt1 += paramInt3;
      paramInt3 = -paramInt3;
    }
    if (paramInt4 < 0)
    {
      paramInt2 += paramInt4;
      paramInt4 = -paramInt4;
    }
    if ((paramInt3 == 0) || (paramInt4 == 0) || (paramInt6 == 0)) {
      return;
    }
    NSAutoreleasePool localNSAutoreleasePool = checkGC(3833);
    try
    {
      this.handle.saveGraphicsState();
      NSAffineTransform localNSAffineTransform = NSAffineTransform.transform();
      double d1 = this.data.drawXOffset;
      double d2 = this.data.drawYOffset;
      localNSAffineTransform.translateXBy(paramInt1 + d1 + paramInt3 / 2.0F, paramInt2 + d2 + paramInt4 / 2.0F);
      localNSAffineTransform.scaleXBy(paramInt3 / 2.0F, paramInt4 / 2.0F);
      NSBezierPath localNSBezierPath = this.data.path;
      NSPoint localNSPoint = new NSPoint();
      float f1 = -paramInt5;
      float f2 = -(paramInt5 + paramInt6);
      localNSBezierPath.appendBezierPathWithArcWithCenter(localNSPoint, 1.0D, f1, f2, paramInt6 > 0);
      localNSBezierPath.transformUsingAffineTransform(localNSAffineTransform);
      Pattern localPattern = this.data.foregroundPattern;
      if (localPattern != null) {
        setPatternPhase(localPattern);
      }
      if ((localPattern != null) && (localPattern.gradient != null)) {
        strokePattern(localNSBezierPath, localPattern);
      } else {
        localNSBezierPath.stroke();
      }
      localNSBezierPath.removeAllPoints();
      this.handle.restoreGraphicsState();
    }
    finally
    {
      uncheckGC(localNSAutoreleasePool);
    }
  }
  
  public void drawFocus(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    if (this.handle == null) {
      SWT.error(44);
    }
    NSAutoreleasePool localNSAutoreleasePool = checkGC(3072);
    try
    {
      int[] arrayOfInt = new int[1];
      OS.GetThemeMetric(7, arrayOfInt);
      CGRect localCGRect = new CGRect();
      localCGRect.origin.x = (paramInt1 + arrayOfInt[0]);
      localCGRect.origin.y = (paramInt2 + arrayOfInt[0]);
      localCGRect.size.width = (paramInt3 - arrayOfInt[0] * 2);
      localCGRect.size.height = (paramInt4 - arrayOfInt[0] * 2);
      OS.HIThemeDrawFocusRect(localCGRect, true, this.handle.graphicsPort(), 0);
    }
    finally
    {
      uncheckGC(localNSAutoreleasePool);
    }
  }
  
  public void drawImage(Image paramImage, int paramInt1, int paramInt2)
  {
    if (this.handle == null) {
      SWT.error(44);
    }
    if (paramImage == null) {
      SWT.error(4);
    }
    if (paramImage.isDisposed()) {
      SWT.error(5);
    }
    drawImage(paramImage, 0, 0, -1, -1, paramInt1, paramInt2, -1, -1, true);
  }
  
  public void drawImage(Image paramImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8)
  {
    if (this.handle == null) {
      SWT.error(44);
    }
    if ((paramInt3 == 0) || (paramInt4 == 0) || (paramInt7 == 0) || (paramInt8 == 0)) {
      return;
    }
    if ((paramInt1 < 0) || (paramInt2 < 0) || (paramInt3 < 0) || (paramInt4 < 0) || (paramInt7 < 0) || (paramInt8 < 0)) {
      SWT.error(5);
    }
    if (paramImage == null) {
      SWT.error(4);
    }
    if (paramImage.isDisposed()) {
      SWT.error(5);
    }
    drawImage(paramImage, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8, false);
  }
  
  void drawImage(Image paramImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, boolean paramBoolean)
  {
    NSImage localNSImage = paramImage.handle;
    NSSize localNSSize = localNSImage.size();
    int i = (int)localNSSize.width;
    int j = (int)localNSSize.height;
    if (paramBoolean)
    {
      paramInt3 = paramInt7 = i;
      paramInt4 = paramInt8 = j;
    }
    else
    {
      paramBoolean = (paramInt1 == 0) && (paramInt2 == 0) && (paramInt3 == paramInt7) && (paramInt7 == i) && (paramInt4 == paramInt8) && (paramInt8 == j);
      if ((paramInt1 + paramInt3 > i) || (paramInt2 + paramInt4 > j)) {
        SWT.error(5);
      }
    }
    NSAutoreleasePool localNSAutoreleasePool = checkGC(3072);
    try
    {
      if (paramImage.memGC != null) {
        paramImage.createAlpha();
      }
      this.handle.saveGraphicsState();
      NSAffineTransform localNSAffineTransform = NSAffineTransform.transform();
      localNSAffineTransform.scaleXBy(1.0D, -1.0D);
      localNSAffineTransform.translateXBy(0.0D, -(paramInt8 + 2 * paramInt6));
      localNSAffineTransform.concat();
      NSRect localNSRect1 = new NSRect();
      localNSRect1.x = paramInt1;
      localNSRect1.y = (j - (paramInt2 + paramInt4));
      localNSRect1.width = paramInt3;
      localNSRect1.height = paramInt4;
      NSRect localNSRect2 = new NSRect();
      localNSRect2.x = paramInt5;
      localNSRect2.y = paramInt6;
      localNSRect2.width = paramInt7;
      localNSRect2.height = paramInt8;
      localNSImage.drawInRect(localNSRect2, localNSRect1, 2L, this.data.alpha / 255.0F);
      this.handle.restoreGraphicsState();
    }
    finally
    {
      uncheckGC(localNSAutoreleasePool);
    }
  }
  
  public void drawLine(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    if (this.handle == null) {
      SWT.error(44);
    }
    if ((paramInt1 == paramInt3) && (paramInt2 == paramInt4) && (this.data.lineWidth <= 1.0F))
    {
      drawPoint(paramInt1, paramInt2);
      return;
    }
    NSAutoreleasePool localNSAutoreleasePool = checkGC(3833);
    try
    {
      NSBezierPath localNSBezierPath = this.data.path;
      NSPoint localNSPoint = new NSPoint();
      localNSPoint.x = (paramInt1 + this.data.drawXOffset);
      localNSPoint.y = (paramInt2 + this.data.drawYOffset);
      localNSBezierPath.moveToPoint(localNSPoint);
      localNSPoint.x = (paramInt3 + this.data.drawXOffset);
      localNSPoint.y = (paramInt4 + this.data.drawYOffset);
      localNSBezierPath.lineToPoint(localNSPoint);
      Pattern localPattern = this.data.foregroundPattern;
      if (localPattern != null) {
        setPatternPhase(localPattern);
      }
      if ((localPattern != null) && (localPattern.gradient != null)) {
        strokePattern(localNSBezierPath, localPattern);
      } else {
        localNSBezierPath.stroke();
      }
      localNSBezierPath.removeAllPoints();
    }
    finally
    {
      uncheckGC(localNSAutoreleasePool);
    }
  }
  
  public void drawOval(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    if (this.handle == null) {
      SWT.error(44);
    }
    NSAutoreleasePool localNSAutoreleasePool = checkGC(3833);
    try
    {
      if (paramInt3 < 0)
      {
        paramInt1 += paramInt3;
        paramInt3 = -paramInt3;
      }
      if (paramInt4 < 0)
      {
        paramInt2 += paramInt4;
        paramInt4 = -paramInt4;
      }
      NSBezierPath localNSBezierPath = this.data.path;
      NSRect localNSRect = new NSRect();
      localNSRect.x = (paramInt1 + this.data.drawXOffset);
      localNSRect.y = (paramInt2 + this.data.drawXOffset);
      localNSRect.width = paramInt3;
      localNSRect.height = paramInt4;
      localNSBezierPath.appendBezierPathWithOvalInRect(localNSRect);
      Pattern localPattern = this.data.foregroundPattern;
      if (localPattern != null) {
        setPatternPhase(localPattern);
      }
      if ((localPattern != null) && (localPattern.gradient != null)) {
        strokePattern(localNSBezierPath, localPattern);
      } else {
        localNSBezierPath.stroke();
      }
      localNSBezierPath.removeAllPoints();
    }
    finally
    {
      uncheckGC(localNSAutoreleasePool);
    }
  }
  
  public void drawPath(Path paramPath)
  {
    if (this.handle == null) {
      SWT.error(44);
    }
    if (paramPath == null) {
      SWT.error(4);
    }
    if (paramPath.handle == null) {
      SWT.error(5);
    }
    NSAutoreleasePool localNSAutoreleasePool = checkGC(3833);
    try
    {
      this.handle.saveGraphicsState();
      NSAffineTransform localNSAffineTransform = NSAffineTransform.transform();
      localNSAffineTransform.translateXBy(this.data.drawXOffset, this.data.drawYOffset);
      localNSAffineTransform.concat();
      NSBezierPath localNSBezierPath = this.data.path;
      localNSBezierPath.appendBezierPath(paramPath.handle);
      Pattern localPattern = this.data.foregroundPattern;
      if (localPattern != null) {
        setPatternPhase(localPattern);
      }
      if ((localPattern != null) && (localPattern.gradient != null)) {
        strokePattern(localNSBezierPath, localPattern);
      } else {
        localNSBezierPath.stroke();
      }
      localNSBezierPath.removeAllPoints();
      this.handle.restoreGraphicsState();
    }
    finally
    {
      uncheckGC(localNSAutoreleasePool);
    }
  }
  
  public void drawPoint(int paramInt1, int paramInt2)
  {
    if (this.handle == null) {
      SWT.error(44);
    }
    NSAutoreleasePool localNSAutoreleasePool = checkGC(3328);
    try
    {
      NSRect localNSRect = new NSRect();
      localNSRect.x = paramInt1;
      localNSRect.y = paramInt2;
      localNSRect.width = 1.0D;
      localNSRect.height = 1.0D;
      NSBezierPath localNSBezierPath = this.data.path;
      localNSBezierPath.appendBezierPathWithRect(localNSRect);
      localNSBezierPath.fill();
      localNSBezierPath.removeAllPoints();
    }
    finally
    {
      uncheckGC(localNSAutoreleasePool);
    }
  }
  
  public void drawPolygon(int[] paramArrayOfInt)
  {
    if (this.handle == null) {
      SWT.error(44);
    }
    if (paramArrayOfInt == null) {
      SWT.error(4);
    }
    if (paramArrayOfInt.length < 4) {
      return;
    }
    NSAutoreleasePool localNSAutoreleasePool = checkGC(3833);
    try
    {
      double d1 = this.data.drawXOffset;
      double d2 = this.data.drawYOffset;
      NSBezierPath localNSBezierPath = this.data.path;
      NSPoint localNSPoint = new NSPoint();
      localNSPoint.x = (paramArrayOfInt[0] + d1);
      localNSPoint.y = (paramArrayOfInt[1] + d2);
      localNSBezierPath.moveToPoint(localNSPoint);
      int i = paramArrayOfInt.length / 2 * 2;
      for (int j = 2; j < i; j += 2)
      {
        localNSPoint.x = (paramArrayOfInt[j] + d1);
        localNSPoint.y = (paramArrayOfInt[(j + 1)] + d2);
        localNSBezierPath.lineToPoint(localNSPoint);
      }
      localNSBezierPath.closePath();
      Pattern localPattern = this.data.foregroundPattern;
      if (localPattern != null) {
        setPatternPhase(localPattern);
      }
      if ((localPattern != null) && (localPattern.gradient != null)) {
        strokePattern(localNSBezierPath, localPattern);
      } else {
        localNSBezierPath.stroke();
      }
      localNSBezierPath.removeAllPoints();
    }
    finally
    {
      uncheckGC(localNSAutoreleasePool);
    }
  }
  
  public void drawPolyline(int[] paramArrayOfInt)
  {
    if (this.handle == null) {
      SWT.error(44);
    }
    if (paramArrayOfInt == null) {
      SWT.error(4);
    }
    if (paramArrayOfInt.length < 4) {
      return;
    }
    NSAutoreleasePool localNSAutoreleasePool = checkGC(3833);
    try
    {
      double d1 = this.data.drawXOffset;
      double d2 = this.data.drawYOffset;
      NSBezierPath localNSBezierPath = this.data.path;
      NSPoint localNSPoint = new NSPoint();
      localNSPoint.x = (paramArrayOfInt[0] + d1);
      localNSPoint.y = (paramArrayOfInt[1] + d2);
      localNSBezierPath.moveToPoint(localNSPoint);
      int i = paramArrayOfInt.length / 2 * 2;
      for (int j = 2; j < i; j += 2)
      {
        localNSPoint.x = (paramArrayOfInt[j] + d1);
        localNSPoint.y = (paramArrayOfInt[(j + 1)] + d2);
        localNSBezierPath.lineToPoint(localNSPoint);
      }
      Pattern localPattern = this.data.foregroundPattern;
      if (localPattern != null) {
        setPatternPhase(localPattern);
      }
      if ((localPattern != null) && (localPattern.gradient != null)) {
        strokePattern(localNSBezierPath, localPattern);
      } else {
        localNSBezierPath.stroke();
      }
      localNSBezierPath.removeAllPoints();
    }
    finally
    {
      uncheckGC(localNSAutoreleasePool);
    }
  }
  
  public void drawRectangle(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    if (this.handle == null) {
      SWT.error(44);
    }
    NSAutoreleasePool localNSAutoreleasePool = checkGC(3833);
    try
    {
      if (paramInt3 < 0)
      {
        paramInt1 += paramInt3;
        paramInt3 = -paramInt3;
      }
      if (paramInt4 < 0)
      {
        paramInt2 += paramInt4;
        paramInt4 = -paramInt4;
      }
      NSRect localNSRect = new NSRect();
      localNSRect.x = (paramInt1 + this.data.drawXOffset);
      localNSRect.y = (paramInt2 + this.data.drawYOffset);
      localNSRect.width = paramInt3;
      localNSRect.height = paramInt4;
      NSBezierPath localNSBezierPath = this.data.path;
      localNSBezierPath.appendBezierPathWithRect(localNSRect);
      Pattern localPattern = this.data.foregroundPattern;
      if (localPattern != null) {
        setPatternPhase(localPattern);
      }
      if ((localPattern != null) && (localPattern.gradient != null)) {
        strokePattern(localNSBezierPath, localPattern);
      } else {
        localNSBezierPath.stroke();
      }
      localNSBezierPath.removeAllPoints();
    }
    finally
    {
      uncheckGC(localNSAutoreleasePool);
    }
  }
  
  public void drawRectangle(Rectangle paramRectangle)
  {
    if (this.handle == null) {
      SWT.error(44);
    }
    if (paramRectangle == null) {
      SWT.error(4);
    }
    drawRectangle(paramRectangle.x, paramRectangle.y, paramRectangle.width, paramRectangle.height);
  }
  
  public void drawRoundRectangle(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6)
  {
    if (this.handle == null) {
      SWT.error(44);
    }
    if ((paramInt5 == 0) || (paramInt6 == 0))
    {
      drawRectangle(paramInt1, paramInt2, paramInt3, paramInt4);
      return;
    }
    NSAutoreleasePool localNSAutoreleasePool = checkGC(3833);
    try
    {
      NSBezierPath localNSBezierPath = this.data.path;
      NSRect localNSRect = new NSRect();
      localNSRect.x = (paramInt1 + this.data.drawXOffset);
      localNSRect.y = (paramInt2 + this.data.drawYOffset);
      localNSRect.width = paramInt3;
      localNSRect.height = paramInt4;
      localNSBezierPath.appendBezierPathWithRoundedRect(localNSRect, paramInt5 / 2.0F, paramInt6 / 2.0F);
      Pattern localPattern = this.data.foregroundPattern;
      if (localPattern != null) {
        setPatternPhase(localPattern);
      }
      if ((localPattern != null) && (localPattern.gradient != null)) {
        strokePattern(localNSBezierPath, localPattern);
      } else {
        localNSBezierPath.stroke();
      }
      localNSBezierPath.removeAllPoints();
    }
    finally
    {
      uncheckGC(localNSAutoreleasePool);
    }
  }
  
  public void drawString(String paramString, int paramInt1, int paramInt2)
  {
    drawString(paramString, paramInt1, paramInt2, false);
  }
  
  public void drawString(String paramString, int paramInt1, int paramInt2, boolean paramBoolean)
  {
    drawText(paramString, paramInt1, paramInt2, paramBoolean ? 1 : 0);
  }
  
  public void drawText(String paramString, int paramInt1, int paramInt2)
  {
    drawText(paramString, paramInt1, paramInt2, 6);
  }
  
  public void drawText(String paramString, int paramInt1, int paramInt2, boolean paramBoolean)
  {
    int i = 6;
    if (paramBoolean) {
      i |= 0x1;
    }
    drawText(paramString, paramInt1, paramInt2, i);
  }
  
  public void drawText(String paramString, int paramInt1, int paramInt2, int paramInt3)
  {
    if (this.handle == null) {
      SWT.error(44);
    }
    if (paramString == null) {
      SWT.error(4);
    }
    NSAutoreleasePool localNSAutoreleasePool = checkGC(3332);
    try
    {
      int i = paramString.length();
      if (i == 0) {
        return;
      }
      boolean bool = true;
      switch (this.data.textAntialias)
      {
      case -1: 
        if (!this.handle.isDrawingToScreen()) {
          bool = false;
        }
        break;
      case 0: 
        bool = false;
        break;
      case 1: 
        bool = true;
      }
      this.handle.saveGraphicsState();
      this.handle.setShouldAntialias(bool);
      if (this.data.textStorage == null) {
        createLayout();
      }
      NSAttributedString localNSAttributedString = createString(paramString, paramInt3, true);
      this.data.textStorage.setAttributedString(localNSAttributedString);
      localNSAttributedString.release();
      NSPoint localNSPoint = new NSPoint();
      localNSPoint.x = paramInt1;
      localNSPoint.y = paramInt2;
      NSRange localNSRange = this.data.layoutManager.glyphRangeForTextContainer(this.data.textContainer);
      if ((paramInt3 & 0x1) == 0)
      {
        NSRect localNSRect = this.data.layoutManager.usedRectForTextContainer(this.data.textContainer);
        localNSRect.x = paramInt1;
        localNSRect.y = paramInt2;
        Pattern localPattern = this.data.backgroundPattern;
        if (localPattern != null) {
          setPatternPhase(localPattern);
        }
        Object localObject1;
        if ((localPattern != null) && (localPattern.gradient != null))
        {
          localObject1 = NSBezierPath.bezierPathWithRect(localNSRect);
          fillPattern((NSBezierPath)localObject1, localPattern);
        }
        else
        {
          localObject1 = this.data.bg;
          if (localObject1 == null)
          {
            double[] arrayOfDouble = this.data.background;
            localObject1 = this.data.bg = NSColor.colorWithDeviceRed(arrayOfDouble[0], arrayOfDouble[1], arrayOfDouble[2], this.data.alpha / 255.0F);
            ((NSColor)localObject1).retain();
          }
          ((NSColor)localObject1).setFill();
          NSBezierPath.fillRect(localNSRect);
        }
      }
      this.data.layoutManager.drawGlyphsForGlyphRange(localNSRange, localNSPoint);
      this.handle.restoreGraphicsState();
    }
    finally
    {
      uncheckGC(localNSAutoreleasePool);
    }
  }
  
  public boolean equals(Object paramObject)
  {
    if (paramObject == this) {
      return true;
    }
    if (!(paramObject instanceof GC)) {
      return false;
    }
    return this.handle == ((GC)paramObject).handle;
  }
  
  public void fillArc(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6)
  {
    if (this.handle == null) {
      SWT.error(44);
    }
    if (paramInt3 < 0)
    {
      paramInt1 += paramInt3;
      paramInt3 = -paramInt3;
    }
    if (paramInt4 < 0)
    {
      paramInt2 += paramInt4;
      paramInt4 = -paramInt4;
    }
    if ((paramInt3 == 0) || (paramInt4 == 0) || (paramInt6 == 0)) {
      return;
    }
    NSAutoreleasePool localNSAutoreleasePool = checkGC(3074);
    try
    {
      this.handle.saveGraphicsState();
      NSAffineTransform localNSAffineTransform = NSAffineTransform.transform();
      double d1 = this.data.drawXOffset;
      double d2 = this.data.drawYOffset;
      localNSAffineTransform.translateXBy(paramInt1 + d1 + paramInt3 / 2.0F, paramInt2 + d2 + paramInt4 / 2.0F);
      localNSAffineTransform.scaleXBy(paramInt3 / 2.0F, paramInt4 / 2.0F);
      NSBezierPath localNSBezierPath = this.data.path;
      NSPoint localNSPoint = new NSPoint();
      localNSBezierPath.moveToPoint(localNSPoint);
      float f1 = -paramInt5;
      float f2 = -(paramInt5 + paramInt6);
      localNSBezierPath.appendBezierPathWithArcWithCenter(localNSPoint, 1.0D, f1, f2, paramInt6 > 0);
      localNSBezierPath.closePath();
      localNSBezierPath.transformUsingAffineTransform(localNSAffineTransform);
      Pattern localPattern = this.data.backgroundPattern;
      if (localPattern != null) {
        setPatternPhase(localPattern);
      }
      if ((localPattern != null) && (localPattern.gradient != null)) {
        fillPattern(localNSBezierPath, localPattern);
      } else {
        localNSBezierPath.fill();
      }
      localNSBezierPath.removeAllPoints();
      this.handle.restoreGraphicsState();
    }
    finally
    {
      uncheckGC(localNSAutoreleasePool);
    }
  }
  
  public void fillGradientRectangle(int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean)
  {
    if (this.handle == null) {
      SWT.error(44);
    }
    if ((paramInt3 == 0) || (paramInt4 == 0)) {
      return;
    }
    NSAutoreleasePool localNSAutoreleasePool = checkGC(3072);
    try
    {
      RGB localRGB1 = getBackground().getRGB();
      RGB localRGB2 = getForeground().getRGB();
      RGB localRGB3 = localRGB2;
      RGB localRGB4 = localRGB1;
      int i = 0;
      if (paramInt3 < 0)
      {
        paramInt1 += paramInt3;
        paramInt3 = -paramInt3;
        if (!paramBoolean) {
          i = 1;
        }
      }
      if (paramInt4 < 0)
      {
        paramInt2 += paramInt4;
        paramInt4 = -paramInt4;
        if (paramBoolean) {
          i = 1;
        }
      }
      if (i != 0)
      {
        localRGB3 = localRGB1;
        localRGB4 = localRGB2;
      }
      if (localRGB3.equals(localRGB4))
      {
        fillRectangle(paramInt1, paramInt2, paramInt3, paramInt4);
      }
      else
      {
        NSColor localNSColor1 = NSColor.colorWithDeviceRed(localRGB3.red / 255.0F, localRGB3.green / 255.0F, localRGB3.blue / 255.0F, this.data.alpha / 255.0F);
        NSColor localNSColor2 = NSColor.colorWithDeviceRed(localRGB4.red / 255.0F, localRGB4.green / 255.0F, localRGB4.blue / 255.0F, this.data.alpha / 255.0F);
        NSGradient localNSGradient = ((NSGradient)new NSGradient().alloc()).initWithStartingColor(localNSColor1, localNSColor2);
        NSRect localNSRect = new NSRect();
        localNSRect.x = paramInt1;
        localNSRect.y = paramInt2;
        localNSRect.width = paramInt3;
        localNSRect.height = paramInt4;
        localNSGradient.drawInRect(localNSRect, paramBoolean ? 90.0D : 0.0D);
        localNSGradient.release();
      }
    }
    finally
    {
      uncheckGC(localNSAutoreleasePool);
    }
  }
  
  public void fillOval(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    if (this.handle == null) {
      SWT.error(44);
    }
    NSAutoreleasePool localNSAutoreleasePool = checkGC(3074);
    try
    {
      if (paramInt3 < 0)
      {
        paramInt1 += paramInt3;
        paramInt3 = -paramInt3;
      }
      if (paramInt4 < 0)
      {
        paramInt2 += paramInt4;
        paramInt4 = -paramInt4;
      }
      NSBezierPath localNSBezierPath = this.data.path;
      NSRect localNSRect = new NSRect();
      localNSRect.x = paramInt1;
      localNSRect.y = paramInt2;
      localNSRect.width = paramInt3;
      localNSRect.height = paramInt4;
      localNSBezierPath.appendBezierPathWithOvalInRect(localNSRect);
      Pattern localPattern = this.data.backgroundPattern;
      if (localPattern != null) {
        setPatternPhase(localPattern);
      }
      if ((localPattern != null) && (localPattern.gradient != null)) {
        fillPattern(localNSBezierPath, localPattern);
      } else {
        localNSBezierPath.fill();
      }
      localNSBezierPath.removeAllPoints();
    }
    finally
    {
      uncheckGC(localNSAutoreleasePool);
    }
  }
  
  void fillPattern(NSBezierPath paramNSBezierPath, Pattern paramPattern)
  {
    this.handle.saveGraphicsState();
    paramNSBezierPath.addClip();
    NSRect localNSRect = paramNSBezierPath.bounds();
    NSPoint localNSPoint1 = new NSPoint();
    localNSPoint1.x = paramPattern.pt1.x;
    localNSPoint1.y = paramPattern.pt1.y;
    NSPoint localNSPoint2 = new NSPoint();
    localNSPoint2.x = paramPattern.pt2.x;
    localNSPoint2.y = paramPattern.pt2.y;
    double d1 = localNSPoint2.x - localNSPoint1.x;
    double d2 = localNSPoint2.y - localNSPoint1.y;
    if ((d1 == 0.0D) && (d2 == 0.0D))
    {
      double[] arrayOfDouble = paramPattern.color1;
      NSColor.colorWithDeviceRed(arrayOfDouble[0], arrayOfDouble[1], arrayOfDouble[2], this.data.alpha / 255.0F).setFill();
      paramNSBezierPath.fill();
      this.handle.restoreGraphicsState();
      return;
    }
    double d3;
    double d4;
    double d5;
    double d6;
    if ((d1 == 0.0D) || (d2 == 0.0D))
    {
      d3 = localNSRect.x;
      d4 = localNSRect.y;
      d5 = localNSRect.x + localNSRect.width;
      d6 = localNSRect.y + localNSRect.height;
      if ((d1 < 0.0D) || (d2 < 0.0D))
      {
        d3 = d5;
        d4 = d6;
        d5 = localNSRect.x;
        d6 = localNSRect.y;
      }
    }
    else
    {
      double d7 = (localNSPoint2.y - localNSPoint1.y) / (localNSPoint2.x - localNSPoint1.x);
      double d8 = localNSPoint2.y - d7 * localNSPoint2.x;
      double d9 = -1.0D / d7;
      double d10 = localNSRect.y - d9 * localNSRect.x;
      d3 = d5 = (d8 - d10) / (d9 - d7);
      d10 = localNSRect.y + localNSRect.height - d9 * localNSRect.x;
      double d11 = (d8 - d10) / (d9 - d7);
      d3 = d1 > 0.0D ? Math.min(d3, d11) : Math.max(d3, d11);
      d5 = d1 < 0.0D ? Math.min(d5, d11) : Math.max(d5, d11);
      d10 = localNSRect.y - d9 * (localNSRect.x + localNSRect.width);
      d11 = (d8 - d10) / (d9 - d7);
      d3 = d1 > 0.0D ? Math.min(d3, d11) : Math.max(d3, d11);
      d5 = d1 < 0.0D ? Math.min(d5, d11) : Math.max(d5, d11);
      d10 = localNSRect.y + localNSRect.height - d9 * (localNSRect.x + localNSRect.width);
      d11 = (d8 - d10) / (d9 - d7);
      d3 = d1 > 0.0D ? Math.min(d3, d11) : Math.max(d3, d11);
      d5 = d1 < 0.0D ? Math.min(d5, d11) : Math.max(d5, d11);
      d4 = d7 * d3 + d8;
      d6 = d7 * d5 + d8;
    }
    if (d1 != 0.0D) {
      while (((d1 > 0.0D) && (localNSPoint1.x >= d3)) || ((d1 < 0.0D) && (localNSPoint1.x <= d3)))
      {
        localNSPoint1.x -= d1;
        localNSPoint1.y -= d2;
      }
    }
    while (((d2 > 0.0D) && (localNSPoint1.y >= d4)) || ((d2 < 0.0D) && (localNSPoint1.y <= d4)))
    {
      localNSPoint1.x -= d1;
      localNSPoint1.y -= d2;
    }
    localNSPoint2.x = localNSPoint1.x;
    localNSPoint2.y = localNSPoint1.y;
    do
    {
      localNSPoint2.x += d1;
      localNSPoint2.y += d2;
      paramPattern.gradient.drawFromPoint(localNSPoint1, localNSPoint2, 0L);
      localNSPoint1.x = localNSPoint2.x;
      localNSPoint1.y = localNSPoint2.y;
    } while (((d1 > 0.0D) && (localNSPoint2.x <= d5)) || ((d1 < 0.0D) && (localNSPoint2.x >= d5)) || ((d1 == 0.0D) && (((d2 > 0.0D) && (localNSPoint2.y <= d6)) || ((d2 < 0.0D) && (localNSPoint2.y >= d6)))));
    this.handle.restoreGraphicsState();
  }
  
  public void fillPath(Path paramPath)
  {
    if (this.handle == null) {
      SWT.error(44);
    }
    if (paramPath == null) {
      SWT.error(4);
    }
    if (paramPath.handle == null) {
      SWT.error(5);
    }
    NSAutoreleasePool localNSAutoreleasePool = checkGC(3074);
    try
    {
      NSBezierPath localNSBezierPath = this.data.path;
      localNSBezierPath.appendBezierPath(paramPath.handle);
      Pattern localPattern = this.data.backgroundPattern;
      if (localPattern != null) {
        setPatternPhase(localPattern);
      }
      if ((localPattern != null) && (localPattern.gradient != null)) {
        fillPattern(localNSBezierPath, localPattern);
      } else {
        localNSBezierPath.fill();
      }
      localNSBezierPath.removeAllPoints();
    }
    finally
    {
      uncheckGC(localNSAutoreleasePool);
    }
  }
  
  public void fillPolygon(int[] paramArrayOfInt)
  {
    if (this.handle == null) {
      SWT.error(44);
    }
    if (paramArrayOfInt == null) {
      SWT.error(4);
    }
    if (paramArrayOfInt.length < 4) {
      return;
    }
    NSAutoreleasePool localNSAutoreleasePool = checkGC(3074);
    try
    {
      NSBezierPath localNSBezierPath = this.data.path;
      NSPoint localNSPoint = new NSPoint();
      localNSPoint.x = paramArrayOfInt[0];
      localNSPoint.y = paramArrayOfInt[1];
      localNSBezierPath.moveToPoint(localNSPoint);
      int i = paramArrayOfInt.length / 2 * 2;
      for (int j = 2; j < i; j += 2)
      {
        localNSPoint.x = paramArrayOfInt[j];
        localNSPoint.y = paramArrayOfInt[(j + 1)];
        localNSBezierPath.lineToPoint(localNSPoint);
      }
      localNSBezierPath.closePath();
      Pattern localPattern = this.data.backgroundPattern;
      if (localPattern != null) {
        setPatternPhase(localPattern);
      }
      if ((localPattern != null) && (localPattern.gradient != null)) {
        fillPattern(localNSBezierPath, localPattern);
      } else {
        localNSBezierPath.fill();
      }
      localNSBezierPath.removeAllPoints();
    }
    finally
    {
      uncheckGC(localNSAutoreleasePool);
    }
  }
  
  public void fillRectangle(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    if (this.handle == null) {
      SWT.error(44);
    }
    NSAutoreleasePool localNSAutoreleasePool = checkGC(3074);
    try
    {
      if (paramInt3 < 0)
      {
        paramInt1 += paramInt3;
        paramInt3 = -paramInt3;
      }
      if (paramInt4 < 0)
      {
        paramInt2 += paramInt4;
        paramInt4 = -paramInt4;
      }
      NSRect localNSRect = new NSRect();
      localNSRect.x = paramInt1;
      localNSRect.y = paramInt2;
      localNSRect.width = paramInt3;
      localNSRect.height = paramInt4;
      NSBezierPath localNSBezierPath = this.data.path;
      localNSBezierPath.appendBezierPathWithRect(localNSRect);
      Pattern localPattern = this.data.backgroundPattern;
      if (localPattern != null) {
        setPatternPhase(localPattern);
      }
      if ((localPattern != null) && (localPattern.gradient != null)) {
        fillPattern(localNSBezierPath, localPattern);
      } else {
        localNSBezierPath.fill();
      }
      localNSBezierPath.removeAllPoints();
    }
    finally
    {
      uncheckGC(localNSAutoreleasePool);
    }
  }
  
  public void fillRectangle(Rectangle paramRectangle)
  {
    if (this.handle == null) {
      SWT.error(44);
    }
    if (paramRectangle == null) {
      SWT.error(4);
    }
    fillRectangle(paramRectangle.x, paramRectangle.y, paramRectangle.width, paramRectangle.height);
  }
  
  public void fillRoundRectangle(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6)
  {
    if (this.handle == null) {
      SWT.error(44);
    }
    if ((paramInt5 == 0) || (paramInt6 == 0))
    {
      fillRectangle(paramInt1, paramInt2, paramInt3, paramInt4);
      return;
    }
    NSAutoreleasePool localNSAutoreleasePool = checkGC(3074);
    try
    {
      NSBezierPath localNSBezierPath = this.data.path;
      NSRect localNSRect = new NSRect();
      localNSRect.x = paramInt1;
      localNSRect.y = paramInt2;
      localNSRect.width = paramInt3;
      localNSRect.height = paramInt4;
      localNSBezierPath.appendBezierPathWithRoundedRect(localNSRect, paramInt5 / 2.0F, paramInt6 / 2.0F);
      Pattern localPattern = this.data.backgroundPattern;
      if (localPattern != null) {
        setPatternPhase(localPattern);
      }
      if ((localPattern != null) && (localPattern.gradient != null)) {
        fillPattern(localNSBezierPath, localPattern);
      } else {
        localNSBezierPath.fill();
      }
      localNSBezierPath.removeAllPoints();
    }
    finally
    {
      uncheckGC(localNSAutoreleasePool);
    }
  }
  
  void strokePattern(NSBezierPath paramNSBezierPath, Pattern paramPattern)
  {
    this.handle.saveGraphicsState();
    long l1 = createCGPathRef(paramNSBezierPath);
    long l2 = this.handle.graphicsPort();
    OS.CGContextSaveGState(l2);
    initCGContext(l2);
    OS.CGContextAddPath(l2, l1);
    OS.CGContextReplacePathWithStrokedPath(l2);
    OS.CGPathRelease(l1);
    l1 = 0L;
    l1 = OS.CGContextCopyPath(l2);
    if (l1 == 0L) {
      SWT.error(2);
    }
    OS.CGContextRestoreGState(l2);
    NSBezierPath localNSBezierPath = createNSBezierPath(l1);
    OS.CGPathRelease(l1);
    fillPattern(localNSBezierPath, paramPattern);
    this.handle.restoreGraphicsState();
  }
  
  void flush()
  {
    this.handle.flushGraphics();
  }
  
  public int getAdvanceWidth(char paramChar)
  {
    if (this.handle == null) {
      SWT.error(44);
    }
    return stringExtent(new String(new char[] { paramChar })).x;
  }
  
  public Color getBackground()
  {
    if (this.handle == null) {
      SWT.error(44);
    }
    return Color.cocoa_new(this.data.device, this.data.background);
  }
  
  public Pattern getBackgroundPattern()
  {
    if (this.handle == null) {
      SWT.error(24);
    }
    return this.data.backgroundPattern;
  }
  
  public boolean getAdvanced()
  {
    if (this.handle == null) {
      SWT.error(44);
    }
    return true;
  }
  
  public int getAlpha()
  {
    if (this.handle == null) {
      SWT.error(44);
    }
    return this.data.alpha;
  }
  
  public int getAntialias()
  {
    if (this.handle == null) {
      SWT.error(44);
    }
    return this.data.antialias;
  }
  
  public int getCharWidth(char paramChar)
  {
    if (this.handle == null) {
      SWT.error(44);
    }
    return stringExtent(new String(new char[] { paramChar })).x;
  }
  
  public Rectangle getClipping()
  {
    if (this.handle == null) {
      SWT.error(44);
    }
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      NSRect localNSRect = null;
      if (this.data.view != null)
      {
        localNSRect = this.data.view.visibleRect();
      }
      else
      {
        localNSRect = new NSRect();
        if (this.data.image != null)
        {
          localObject1 = this.data.image.handle.size();
          localNSRect.width = ((NSSize)localObject1).width;
          localNSRect.height = ((NSSize)localObject1).height;
        }
        else if (this.data.size != null)
        {
          localNSRect.width = this.data.size.width;
          localNSRect.height = this.data.size.height;
        }
      }
      if ((this.data.paintRect != null) || (this.data.clipPath != null) || (this.data.inverseTransform != null))
      {
        if (this.data.paintRect != null) {
          OS.NSIntersectionRect(localNSRect, localNSRect, this.data.paintRect);
        }
        if (this.data.clipPath != null)
        {
          localObject1 = this.data.clipPath.bounds();
          ((NSRect)localObject1).x = ((int)((NSRect)localObject1).x);
          ((NSRect)localObject1).y = ((int)((NSRect)localObject1).y);
          OS.NSIntersectionRect(localNSRect, localNSRect, (NSRect)localObject1);
        }
        if ((this.data.inverseTransform != null) && (localNSRect.width > 0.0D) && (localNSRect.height > 0.0D))
        {
          localObject1 = new NSPoint();
          ((NSPoint)localObject1).x = localNSRect.x;
          ((NSPoint)localObject1).y = localNSRect.y;
          NSSize localNSSize = new NSSize();
          localNSSize.width = localNSRect.width;
          localNSSize.height = localNSRect.height;
          localObject1 = this.data.inverseTransform.transformPoint((NSPoint)localObject1);
          localNSSize = this.data.inverseTransform.transformSize(localNSSize);
          localNSRect.x = ((NSPoint)localObject1).x;
          localNSRect.y = ((NSPoint)localObject1).y;
          localNSRect.width = localNSSize.width;
          localNSRect.height = localNSSize.height;
        }
      }
      Object localObject1 = new Rectangle((int)localNSRect.x, (int)localNSRect.y, (int)localNSRect.width, (int)localNSRect.height);
      return (Rectangle)localObject1;
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  public void getClipping(Region paramRegion)
  {
    if (this.handle == null) {
      SWT.error(44);
    }
    if (paramRegion == null) {
      SWT.error(4);
    }
    if (paramRegion.isDisposed()) {
      SWT.error(5);
    }
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      paramRegion.subtract(paramRegion);
      NSRect localNSRect = null;
      if (this.data.view != null)
      {
        localNSRect = this.data.view.visibleRect();
      }
      else
      {
        localNSRect = new NSRect();
        if (this.data.image != null)
        {
          localObject1 = this.data.image.handle.size();
          localNSRect.width = ((NSSize)localObject1).width;
          localNSRect.height = ((NSSize)localObject1).height;
        }
        else if (this.data.size != null)
        {
          localNSRect.width = this.data.size.width;
          localNSRect.height = this.data.size.height;
        }
      }
      paramRegion.add((int)localNSRect.x, (int)localNSRect.y, (int)localNSRect.width, (int)localNSRect.height);
      Object localObject1 = this.data.paintRect;
      if (localObject1 != null) {
        paramRegion.intersect((int)((NSRect)localObject1).x, (int)((NSRect)localObject1).y, (int)((NSRect)localObject1).width, (int)((NSRect)localObject1).height);
      }
      if (this.data.clipPath != null)
      {
        NSBezierPath localNSBezierPath = this.data.clipPath.bezierPathByFlatteningPath();
        int i = (int)localNSBezierPath.elementCount();
        int j = 0;
        Region localRegion = new Region(this.device);
        int[] arrayOfInt = new int[i * 2];
        long l = OS.malloc(NSPoint.sizeof);
        if (l == 0L) {
          SWT.error(2);
        }
        NSPoint localNSPoint = new NSPoint();
        for (int k = 0; k < i; k++)
        {
          int m = (int)localNSBezierPath.elementAtIndex(k, l);
          switch (m)
          {
          case 0: 
            if (j != 0) {
              localRegion.add(arrayOfInt, j);
            }
            j = 0;
            OS.memmove(localNSPoint, l, NSPoint.sizeof);
            arrayOfInt[(j++)] = ((int)localNSPoint.x);
            arrayOfInt[(j++)] = ((int)localNSPoint.y);
            break;
          case 1: 
            OS.memmove(localNSPoint, l, NSPoint.sizeof);
            arrayOfInt[(j++)] = ((int)localNSPoint.x);
            arrayOfInt[(j++)] = ((int)localNSPoint.y);
            break;
          case 3: 
            if (j != 0) {
              localRegion.add(arrayOfInt, j);
            }
            j = 0;
          }
        }
        if (j != 0) {
          localRegion.add(arrayOfInt, j);
        }
        OS.free(l);
        paramRegion.intersect(localRegion);
        localRegion.dispose();
      }
      if (this.data.inverseTransform != null) {
        paramRegion.convertRgn(this.data.inverseTransform);
      }
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  public int getFillRule()
  {
    if (this.handle == null) {
      SWT.error(44);
    }
    return this.data.fillRule;
  }
  
  public Font getFont()
  {
    if (this.handle == null) {
      SWT.error(44);
    }
    return this.data.font;
  }
  
  public FontMetrics getFontMetrics()
  {
    if (this.handle == null) {
      SWT.error(44);
    }
    NSAutoreleasePool localNSAutoreleasePool = checkGC(4);
    try
    {
      if (this.data.textStorage == null) {
        createLayout();
      }
      if (this.data.font.metrics == null)
      {
        localObject1 = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        NSMutableDictionary localNSMutableDictionary = ((NSMutableDictionary)new NSMutableDictionary().alloc()).initWithCapacity(3L);
        localNSMutableDictionary.setObject(this.data.font.handle, OS.NSFontAttributeName);
        this.data.font.addTraits(localNSMutableDictionary);
        NSAttributedString localNSAttributedString = ((NSAttributedString)new NSAttributedString().alloc()).initWithString(NSString.stringWith((String)localObject1), localNSMutableDictionary);
        this.data.textStorage.setAttributedString(localNSAttributedString);
        localNSAttributedString.release();
        localNSMutableDictionary.release();
        NSLayoutManager localNSLayoutManager = this.data.layoutManager;
        localNSLayoutManager.glyphRangeForTextContainer(this.data.textContainer);
        NSRect localNSRect = localNSLayoutManager.usedRectForTextContainer(this.data.textContainer);
        int i = (int)Math.ceil(localNSRect.width) / ((String)localObject1).length();
        int j = (int)localNSLayoutManager.defaultBaselineOffsetForFont(this.data.font.handle);
        int k = (int)localNSLayoutManager.defaultLineHeightForFont(this.data.font.handle);
        this.data.font.metrics = FontMetrics.cocoa_new(j, k - j, i, 0, k);
      }
      Object localObject1 = this.data.font.metrics;
      return (FontMetrics)localObject1;
    }
    finally
    {
      uncheckGC(localNSAutoreleasePool);
    }
  }
  
  public Color getForeground()
  {
    if (this.handle == null) {
      SWT.error(24);
    }
    return Color.cocoa_new(this.data.device, this.data.foreground);
  }
  
  public Pattern getForegroundPattern()
  {
    if (this.handle == null) {
      SWT.error(24);
    }
    return this.data.foregroundPattern;
  }
  
  public GCData getGCData()
  {
    if (this.handle == null) {
      SWT.error(24);
    }
    NSAutoreleasePool localNSAutoreleasePool = checkGC(3072);
    uncheckGC(localNSAutoreleasePool);
    return this.data;
  }
  
  public int getInterpolation()
  {
    if (this.handle == null) {
      SWT.error(44);
    }
    int i = (int)this.handle.imageInterpolation();
    switch (i)
    {
    case 0: 
      return -1;
    case 1: 
      return 0;
    case 2: 
      return 1;
    case 3: 
      return 2;
    }
    return -1;
  }
  
  public LineAttributes getLineAttributes()
  {
    if (this.handle == null) {
      SWT.error(44);
    }
    float[] arrayOfFloat = null;
    if (this.data.lineDashes != null)
    {
      arrayOfFloat = new float[this.data.lineDashes.length];
      System.arraycopy(this.data.lineDashes, 0, arrayOfFloat, 0, arrayOfFloat.length);
    }
    return new LineAttributes(this.data.lineWidth, this.data.lineCap, this.data.lineJoin, this.data.lineStyle, arrayOfFloat, this.data.lineDashesOffset, this.data.lineMiterLimit);
  }
  
  public int getLineCap()
  {
    if (this.handle == null) {
      SWT.error(44);
    }
    return this.data.lineCap;
  }
  
  public int[] getLineDash()
  {
    if (this.handle == null) {
      SWT.error(44);
    }
    if (this.data.lineDashes == null) {
      return null;
    }
    int[] arrayOfInt = new int[this.data.lineDashes.length];
    for (int i = 0; i < arrayOfInt.length; i++) {
      arrayOfInt[i] = ((int)this.data.lineDashes[i]);
    }
    return arrayOfInt;
  }
  
  public int getLineJoin()
  {
    if (this.handle == null) {
      SWT.error(44);
    }
    return this.data.lineJoin;
  }
  
  public int getLineStyle()
  {
    if (this.handle == null) {
      SWT.error(44);
    }
    return this.data.lineStyle;
  }
  
  public int getLineWidth()
  {
    if (this.handle == null) {
      SWT.error(44);
    }
    return (int)this.data.lineWidth;
  }
  
  public int getStyle()
  {
    if (this.handle == null) {
      SWT.error(44);
    }
    return this.data.style;
  }
  
  public int getTextAntialias()
  {
    if (this.handle == null) {
      SWT.error(44);
    }
    return this.data.textAntialias;
  }
  
  public void getTransform(Transform paramTransform)
  {
    if (this.handle == null) {
      SWT.error(44);
    }
    if (paramTransform == null) {
      SWT.error(4);
    }
    if (paramTransform.isDisposed()) {
      SWT.error(5);
    }
    NSAffineTransform localNSAffineTransform = this.data.transform;
    if (localNSAffineTransform != null)
    {
      NSAffineTransformStruct localNSAffineTransformStruct = localNSAffineTransform.transformStruct();
      paramTransform.handle.setTransformStruct(localNSAffineTransformStruct);
    }
    else
    {
      paramTransform.setElements(1.0F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F);
    }
  }
  
  public boolean getXORMode()
  {
    if (this.handle == null) {
      SWT.error(44);
    }
    return this.data.xorMode;
  }
  
  public int hashCode()
  {
    return this.handle != null ? (int)this.handle.id : 0;
  }
  
  void init(Drawable paramDrawable, GCData paramGCData, long paramLong)
  {
    if (paramGCData.foreground != null) {
      paramGCData.state &= 0xFEFE;
    }
    if (paramGCData.background != null) {
      paramGCData.state &= 0xFFFFFFFD;
    }
    if (paramGCData.font != null) {
      paramGCData.state &= 0xFFFFFFFB;
    }
    paramGCData.state &= 0xFDFF;
    Image localImage = paramGCData.image;
    if (localImage != null) {
      localImage.memGC = this;
    }
    this.drawable = paramDrawable;
    this.data = paramGCData;
    this.handle = new NSGraphicsContext(paramLong);
    this.handle.retain();
    this.handle.saveGraphicsState();
    paramGCData.path = NSBezierPath.bezierPath();
    paramGCData.path.setWindingRule(paramGCData.fillRule == 2 ? 0L : 1L);
    paramGCData.path.retain();
  }
  
  void initCGContext(long paramLong)
  {
    int i = this.data.state;
    if ((i & 0x40) != 0)
    {
      OS.CGContextSetLineWidth(paramLong, this.data.lineWidth == 0.0F ? 1.0D : this.data.lineWidth);
      switch (this.data.lineStyle)
      {
      case 2: 
      case 3: 
      case 4: 
      case 5: 
        i |= 0x8;
      }
    }
    if ((i & 0x8) != 0)
    {
      float[] arrayOfFloat1 = null;
      float f = this.data.lineWidth;
      switch (this.data.lineStyle)
      {
      case 1: 
        break;
      case 2: 
        arrayOfFloat1 = f != 0.0F ? LINE_DASH : LINE_DASH_ZERO;
        break;
      case 3: 
        arrayOfFloat1 = f != 0.0F ? LINE_DOT : LINE_DOT_ZERO;
        break;
      case 4: 
        arrayOfFloat1 = f != 0.0F ? LINE_DASHDOT : LINE_DASHDOT_ZERO;
        break;
      case 5: 
        arrayOfFloat1 = f != 0.0F ? LINE_DASHDOTDOT : LINE_DASHDOTDOT_ZERO;
        break;
      case 6: 
        arrayOfFloat1 = this.data.lineDashes;
      }
      if (arrayOfFloat1 != null)
      {
        float[] arrayOfFloat2 = new float[arrayOfFloat1.length];
        for (int k = 0; k < arrayOfFloat2.length; k++) {
          arrayOfFloat2[k] = ((f == 0.0F) || (this.data.lineStyle == 6) ? arrayOfFloat1[k] : arrayOfFloat1[k] * f);
        }
        OS.CGContextSetLineDash(paramLong, this.data.lineDashesOffset, arrayOfFloat2, arrayOfFloat2.length);
      }
      else
      {
        OS.CGContextSetLineDash(paramLong, 0.0D, null, 0L);
      }
    }
    if ((i & 0x80) != 0) {
      OS.CGContextSetMiterLimit(paramLong, this.data.lineMiterLimit);
    }
    int j;
    if ((i & 0x20) != 0)
    {
      j = 0;
      switch (this.data.lineJoin)
      {
      case 1: 
        j = 0;
        break;
      case 2: 
        j = 1;
        break;
      case 3: 
        j = 2;
      }
      OS.CGContextSetLineJoin(paramLong, j);
    }
    if ((i & 0x10) != 0)
    {
      j = 0;
      switch (this.data.lineCap)
      {
      case 2: 
        j = 1;
        break;
      case 1: 
        j = 0;
        break;
      case 3: 
        j = 2;
      }
      OS.CGContextSetLineCap(paramLong, j);
    }
  }
  
  public boolean isClipped()
  {
    if (this.handle == null) {
      SWT.error(44);
    }
    return this.data.clipPath != null;
  }
  
  public boolean isDisposed()
  {
    return this.handle == null;
  }
  
  boolean isIdentity(float[] paramArrayOfFloat)
  {
    return (paramArrayOfFloat[0] == 1.0F) && (paramArrayOfFloat[1] == 0.0F) && (paramArrayOfFloat[2] == 0.0F) && (paramArrayOfFloat[3] == 1.0F) && (paramArrayOfFloat[4] == 0.0F) && (paramArrayOfFloat[5] == 0.0F);
  }
  
  public void setAdvanced(boolean paramBoolean)
  {
    if (this.handle == null) {
      SWT.error(44);
    }
    if (!paramBoolean)
    {
      setAlpha(255);
      setAntialias(-1);
      setBackgroundPattern(null);
      setClipping((Rectangle)null);
      setForegroundPattern(null);
      setInterpolation(-1);
      setTextAntialias(-1);
      setTransform(null);
    }
  }
  
  public void setAlpha(int paramInt)
  {
    if (this.handle == null) {
      SWT.error(44);
    }
    this.data.alpha = (paramInt & 0xFF);
    this.data.state &= 0xFEFC;
  }
  
  public void setAntialias(int paramInt)
  {
    if (this.handle == null) {
      SWT.error(44);
    }
    boolean bool = true;
    switch (paramInt)
    {
    case -1: 
      if (!this.handle.isDrawingToScreen()) {
        bool = false;
      }
      break;
    case 0: 
      bool = false;
      break;
    case 1: 
      bool = true;
      break;
    default: 
      SWT.error(5);
    }
    this.data.antialias = paramInt;
    this.handle.setShouldAntialias(bool);
  }
  
  public void setBackground(Color paramColor)
  {
    if (this.handle == null) {
      SWT.error(44);
    }
    if (paramColor == null) {
      SWT.error(4);
    }
    if (paramColor.isDisposed()) {
      SWT.error(5);
    }
    this.data.background = paramColor.handle;
    this.data.backgroundPattern = null;
    if (this.data.bg != null) {
      this.data.bg.release();
    }
    this.data.bg = null;
    this.data.state &= 0xFFFFFFFD;
  }
  
  public void setBackgroundPattern(Pattern paramPattern)
  {
    if (this.handle == null) {
      SWT.error(44);
    }
    if ((paramPattern != null) && (paramPattern.isDisposed())) {
      SWT.error(5);
    }
    if (this.data.backgroundPattern == paramPattern) {
      return;
    }
    this.data.backgroundPattern = paramPattern;
    this.data.state &= 0xFFFFFFFD;
  }
  
  public void setClipping(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    if (this.handle == null) {
      SWT.error(44);
    }
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      if (paramInt3 < 0)
      {
        paramInt1 += paramInt3;
        paramInt3 = -paramInt3;
      }
      if (paramInt4 < 0)
      {
        paramInt2 += paramInt4;
        paramInt4 = -paramInt4;
      }
      NSRect localNSRect = new NSRect();
      localNSRect.x = paramInt1;
      localNSRect.y = paramInt2;
      localNSRect.width = paramInt3;
      localNSRect.height = paramInt4;
      NSBezierPath localNSBezierPath = NSBezierPath.bezierPathWithRect(localNSRect);
      localNSBezierPath.retain();
      setClipping(localNSBezierPath);
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  public void setClipping(Path paramPath)
  {
    if (this.handle == null) {
      SWT.error(44);
    }
    if ((paramPath != null) && (paramPath.isDisposed())) {
      SWT.error(5);
    }
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      setClipping(new NSBezierPath(paramPath.handle.copy().id));
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  public void setClipping(Rectangle paramRectangle)
  {
    if (this.handle == null) {
      SWT.error(44);
    }
    if (paramRectangle == null) {
      setClipping((NSBezierPath)null);
    } else {
      setClipping(paramRectangle.x, paramRectangle.y, paramRectangle.width, paramRectangle.height);
    }
  }
  
  public void setClipping(Region paramRegion)
  {
    if (this.handle == null) {
      SWT.error(44);
    }
    if ((paramRegion != null) && (paramRegion.isDisposed())) {
      SWT.error(5);
    }
    NSAutoreleasePool localNSAutoreleasePool = null;
    if (!NSThread.isMainThread()) {
      localNSAutoreleasePool = (NSAutoreleasePool)new NSAutoreleasePool().alloc().init();
    }
    try
    {
      setClipping(paramRegion != null ? paramRegion.getPath() : null);
    }
    finally
    {
      if (localNSAutoreleasePool != null) {
        localNSAutoreleasePool.release();
      }
    }
  }
  
  void setClipping(NSBezierPath paramNSBezierPath)
  {
    if (this.data.clipPath != null)
    {
      this.data.clipPath.release();
      this.data.clipPath = null;
    }
    if (paramNSBezierPath != null)
    {
      this.data.clipPath = paramNSBezierPath;
      if (this.data.transform != null) {
        this.data.clipPath.transformUsingAffineTransform(this.data.transform);
      }
    }
    this.data.state &= 0xFBFF;
  }
  
  public void setFillRule(int paramInt)
  {
    if (this.handle == null) {
      SWT.error(44);
    }
    switch (paramInt)
    {
    case 1: 
    case 2: 
      break;
    default: 
      SWT.error(5);
    }
    this.data.fillRule = paramInt;
    this.data.path.setWindingRule(paramInt == 2 ? 0L : 1L);
  }
  
  public void setFont(Font paramFont)
  {
    if (this.handle == null) {
      SWT.error(44);
    }
    if ((paramFont != null) && (paramFont.isDisposed())) {
      SWT.error(5);
    }
    this.data.font = (paramFont != null ? paramFont : this.data.device.systemFont);
    this.data.state &= 0xFFFFFFFB;
  }
  
  public void setForeground(Color paramColor)
  {
    if (this.handle == null) {
      SWT.error(44);
    }
    if (paramColor == null) {
      SWT.error(4);
    }
    if (paramColor.isDisposed()) {
      SWT.error(5);
    }
    this.data.foreground = paramColor.handle;
    this.data.foregroundPattern = null;
    if (this.data.fg != null) {
      this.data.fg.release();
    }
    this.data.fg = null;
    this.data.state &= 0xFEFE;
  }
  
  public void setForegroundPattern(Pattern paramPattern)
  {
    if (this.handle == null) {
      SWT.error(44);
    }
    if ((paramPattern != null) && (paramPattern.isDisposed())) {
      SWT.error(5);
    }
    if (this.data.foregroundPattern == paramPattern) {
      return;
    }
    this.data.foregroundPattern = paramPattern;
    this.data.state &= 0xFEFE;
  }
  
  public void setInterpolation(int paramInt)
  {
    if (this.handle == null) {
      SWT.error(44);
    }
    int i = 0;
    switch (paramInt)
    {
    case -1: 
      i = 0;
      break;
    case 0: 
      i = 1;
      break;
    case 1: 
      i = 2;
      break;
    case 2: 
      i = 3;
      break;
    default: 
      SWT.error(5);
    }
    this.handle.setImageInterpolation(i);
  }
  
  public void setLineAttributes(LineAttributes paramLineAttributes)
  {
    if (this.handle == null) {
      SWT.error(44);
    }
    if (paramLineAttributes == null) {
      SWT.error(4);
    }
    int i = 0;
    float f1 = paramLineAttributes.width;
    if (f1 != this.data.lineWidth) {
      i |= 0x240;
    }
    int j = paramLineAttributes.style;
    if (j != this.data.lineStyle)
    {
      i |= 0x8;
      switch (j)
      {
      case 1: 
      case 2: 
      case 3: 
      case 4: 
      case 5: 
        break;
      case 6: 
        if (paramLineAttributes.dash == null) {
          j = 1;
        }
        break;
      default: 
        SWT.error(5);
      }
    }
    int k = paramLineAttributes.join;
    if (k != this.data.lineJoin)
    {
      i |= 0x20;
      switch (k)
      {
      case 1: 
      case 2: 
      case 3: 
        break;
      default: 
        SWT.error(5);
      }
    }
    int m = paramLineAttributes.cap;
    if (m != this.data.lineCap)
    {
      i |= 0x10;
      switch (m)
      {
      case 1: 
      case 2: 
      case 3: 
        break;
      default: 
        SWT.error(5);
      }
    }
    Object localObject = paramLineAttributes.dash;
    float[] arrayOfFloat1 = this.data.lineDashes;
    if ((localObject != null) && (localObject.length > 0))
    {
      int n = (arrayOfFloat1 == null) || (arrayOfFloat1.length != localObject.length) ? 1 : 0;
      for (int i1 = 0; i1 < localObject.length; i1++)
      {
        float f4 = localObject[i1];
        if (f4 <= 0.0F) {
          SWT.error(5);
        }
        if ((n == 0) && (arrayOfFloat1[i1] != f4)) {
          n = 1;
        }
      }
      if (n != 0)
      {
        float[] arrayOfFloat2 = new float[localObject.length];
        System.arraycopy(localObject, 0, arrayOfFloat2, 0, localObject.length);
        localObject = arrayOfFloat2;
        i |= 0x8;
      }
      else
      {
        localObject = arrayOfFloat1;
      }
    }
    else if ((arrayOfFloat1 != null) && (arrayOfFloat1.length > 0))
    {
      i |= 0x8;
    }
    else
    {
      localObject = arrayOfFloat1;
    }
    float f2 = paramLineAttributes.dashOffset;
    if (f2 != this.data.lineDashesOffset) {
      i |= 0x8;
    }
    float f3 = paramLineAttributes.miterLimit;
    if (f3 != this.data.lineMiterLimit) {
      i |= 0x80;
    }
    if (i == 0) {
      return;
    }
    this.data.lineWidth = f1;
    this.data.lineStyle = j;
    this.data.lineCap = m;
    this.data.lineJoin = k;
    this.data.lineDashes = ((float[])localObject);
    this.data.lineDashesOffset = f2;
    this.data.lineMiterLimit = f3;
    this.data.state &= (i ^ 0xFFFFFFFF);
  }
  
  public void setLineCap(int paramInt)
  {
    if (this.handle == null) {
      SWT.error(44);
    }
    if (this.data.lineCap == paramInt) {
      return;
    }
    switch (paramInt)
    {
    case 1: 
    case 2: 
    case 3: 
      break;
    default: 
      SWT.error(5);
    }
    this.data.lineCap = paramInt;
    this.data.state &= 0xFFFFFFEF;
  }
  
  public void setLineDash(int[] paramArrayOfInt)
  {
    if (this.handle == null) {
      SWT.error(44);
    }
    float[] arrayOfFloat = this.data.lineDashes;
    if ((paramArrayOfInt != null) && (paramArrayOfInt.length > 0))
    {
      int i = (this.data.lineStyle != 6) || (arrayOfFloat == null) || (arrayOfFloat.length != paramArrayOfInt.length) ? 1 : 0;
      for (int j = 0; j < paramArrayOfInt.length; j++)
      {
        int k = paramArrayOfInt[j];
        if (k <= 0) {
          SWT.error(5);
        }
        if ((i == 0) && (arrayOfFloat[j] != k)) {
          i = 1;
        }
      }
      if (i == 0) {
        return;
      }
      this.data.lineDashes = new float[paramArrayOfInt.length];
      for (j = 0; j < paramArrayOfInt.length; j++) {
        this.data.lineDashes[j] = paramArrayOfInt[j];
      }
      this.data.lineStyle = 6;
    }
    else
    {
      if ((this.data.lineStyle == 1) && ((arrayOfFloat == null) || (arrayOfFloat.length == 0))) {
        return;
      }
      this.data.lineDashes = null;
      this.data.lineStyle = 1;
    }
    this.data.state &= 0xFFFFFFF7;
  }
  
  public void setLineJoin(int paramInt)
  {
    if (this.handle == null) {
      SWT.error(44);
    }
    if (this.data.lineJoin == paramInt) {
      return;
    }
    switch (paramInt)
    {
    case 1: 
    case 2: 
    case 3: 
      break;
    default: 
      SWT.error(5);
    }
    this.data.lineJoin = paramInt;
    this.data.state &= 0xFFFFFFDF;
  }
  
  public void setLineStyle(int paramInt)
  {
    if (this.handle == null) {
      SWT.error(44);
    }
    if (this.data.lineStyle == paramInt) {
      return;
    }
    switch (paramInt)
    {
    case 1: 
    case 2: 
    case 3: 
    case 4: 
    case 5: 
      break;
    case 6: 
      if (this.data.lineDashes == null) {
        paramInt = 1;
      }
      break;
    default: 
      SWT.error(5);
    }
    this.data.lineStyle = paramInt;
    this.data.state &= 0xFFFFFFF7;
  }
  
  public void setLineWidth(int paramInt)
  {
    if (this.handle == null) {
      SWT.error(44);
    }
    if (this.data.lineWidth == paramInt) {
      return;
    }
    this.data.lineWidth = paramInt;
    this.data.state &= 0xFDBF;
  }
  
  void setPatternPhase(Pattern paramPattern)
  {
    if (paramPattern.image == null) {
      return;
    }
    NSPoint localNSPoint = new NSPoint();
    if (this.data.image != null)
    {
      localNSPoint.y += this.data.image.handle.size().height - paramPattern.image.handle.size().height;
    }
    else if (this.data.view != null)
    {
      NSView localNSView1 = this.data.view;
      if (!localNSView1.isFlipped()) {
        localNSPoint.y = localNSView1.bounds().height;
      }
      NSView localNSView2 = localNSView1.window().contentView();
      localNSPoint = localNSView1.convertPoint_toView_(localNSPoint, localNSView2);
      localNSPoint.y = (localNSView2.bounds().height - localNSPoint.y);
    }
    else if (this.data.size != null)
    {
      localNSPoint.y += this.data.size.height - paramPattern.image.handle.size().height;
    }
    this.handle.setPatternPhase(localNSPoint);
  }
  
  /**
   * @deprecated
   */
  public void setXORMode(boolean paramBoolean)
  {
    if (this.handle == null) {
      SWT.error(44);
    }
    this.data.xorMode = paramBoolean;
  }
  
  public void setTextAntialias(int paramInt)
  {
    if (this.handle == null) {
      SWT.error(44);
    }
    switch (paramInt)
    {
    case -1: 
    case 0: 
    case 1: 
      break;
    default: 
      SWT.error(5);
    }
    this.data.textAntialias = paramInt;
  }
  
  public void setTransform(Transform paramTransform)
  {
    if (this.handle == null) {
      SWT.error(44);
    }
    if ((paramTransform != null) && (paramTransform.isDisposed())) {
      SWT.error(5);
    }
    if (paramTransform != null)
    {
      if (this.data.transform != null) {
        this.data.transform.release();
      }
      if (this.data.inverseTransform != null) {
        this.data.inverseTransform.release();
      }
      this.data.transform = ((NSAffineTransform)new NSAffineTransform().alloc()).initWithTransform(paramTransform.handle);
      this.data.inverseTransform = ((NSAffineTransform)new NSAffineTransform().alloc()).initWithTransform(paramTransform.handle);
      NSAffineTransformStruct localNSAffineTransformStruct = this.data.inverseTransform.transformStruct();
      if (localNSAffineTransformStruct.m11 * localNSAffineTransformStruct.m22 - localNSAffineTransformStruct.m12 * localNSAffineTransformStruct.m21 != 0.0D) {
        this.data.inverseTransform.invert();
      }
    }
    else
    {
      this.data.transform = (this.data.inverseTransform = null);
    }
    this.data.state &= 0xF5FF;
  }
  
  public Point stringExtent(String paramString)
  {
    return textExtent(paramString, 0);
  }
  
  public Point textExtent(String paramString)
  {
    return textExtent(paramString, 6);
  }
  
  public Point textExtent(String paramString, int paramInt)
  {
    if (this.handle == null) {
      SWT.error(44);
    }
    if (paramString == null) {
      SWT.error(4);
    }
    NSAutoreleasePool localNSAutoreleasePool = checkGC(4);
    try
    {
      int i = paramString.length();
      if (this.data.textStorage == null) {
        createLayout();
      }
      NSAttributedString localNSAttributedString = createString(i == 0 ? " " : paramString, paramInt, false);
      this.data.textStorage.setAttributedString(localNSAttributedString);
      localNSAttributedString.release();
      this.data.layoutManager.glyphRangeForTextContainer(this.data.textContainer);
      NSRect localNSRect = this.data.layoutManager.usedRectForTextContainer(this.data.textContainer);
      Point localPoint = new Point(i == 0 ? 0 : (int)Math.ceil(localNSRect.width), (int)Math.ceil(localNSRect.height));
      return localPoint;
    }
    finally
    {
      uncheckGC(localNSAutoreleasePool);
    }
  }
  
  public String toString()
  {
    if (isDisposed()) {
      return "GC {*DISPOSED*}";
    }
    return "GC {" + this.handle + "}";
  }
  
  void uncheckGC(NSAutoreleasePool paramNSAutoreleasePool)
  {
    if ((this.data.flippedContext != null) && (this.data.restoreContext))
    {
      NSGraphicsContext.static_restoreGraphicsState();
      this.data.restoreContext = false;
    }
    NSView localNSView = this.data.view;
    if ((localNSView != null) && (this.data.paintRect == null) && (this.data.thread != Thread.currentThread())) {
      flush();
    }
    if (paramNSAutoreleasePool != null) {
      paramNSAutoreleasePool.release();
    }
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/graphics/GC.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */