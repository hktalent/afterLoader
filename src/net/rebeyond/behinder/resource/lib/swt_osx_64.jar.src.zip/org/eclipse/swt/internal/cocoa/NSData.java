package org.eclipse.swt.internal.cocoa;

public class NSData
  extends NSObject
{
  public NSData() {}
  
  public NSData(long paramLong)
  {
    super(paramLong);
  }
  
  public NSData(id paramid)
  {
    super(paramid);
  }
  
  public long bytes()
  {
    return OS.objc_msgSend(this.id, OS.sel_bytes);
  }
  
  public static NSData dataWithBytes(byte[] paramArrayOfByte, long paramLong)
  {
    long l = OS.objc_msgSend(OS.class_NSData, OS.sel_dataWithBytes_length_, paramArrayOfByte, paramLong);
    return l != 0L ? new NSData(l) : null;
  }
  
  public void getBytes(byte[] paramArrayOfByte)
  {
    OS.objc_msgSend(this.id, OS.sel_getBytes_, paramArrayOfByte);
  }
  
  public void getBytes(long paramLong1, long paramLong2)
  {
    OS.objc_msgSend(this.id, OS.sel_getBytes_length_, paramLong1, paramLong2);
  }
  
  public long length()
  {
    return OS.objc_msgSend(this.id, OS.sel_length);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSData.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */