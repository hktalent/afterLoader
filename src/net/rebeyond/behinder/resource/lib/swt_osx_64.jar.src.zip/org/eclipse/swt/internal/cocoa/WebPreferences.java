package org.eclipse.swt.internal.cocoa;

public class WebPreferences
  extends NSObject
{
  public WebPreferences() {}
  
  public WebPreferences(long paramLong)
  {
    super(paramLong);
  }
  
  public WebPreferences(id paramid)
  {
    super(paramid);
  }
  
  public void setJavaEnabled(boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_setJavaEnabled_, paramBoolean);
  }
  
  public void setJavaScriptEnabled(boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_setJavaScriptEnabled_, paramBoolean);
  }
  
  public static WebPreferences standardPreferences()
  {
    long l = OS.objc_msgSend(OS.class_WebPreferences, OS.sel_standardPreferences);
    return l != 0L ? new WebPreferences(l) : null;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/WebPreferences.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */