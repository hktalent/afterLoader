package org.eclipse.swt.browser;

import java.util.Hashtable;
import org.eclipse.swt.SWT;
import org.eclipse.swt.SWTException;
import org.eclipse.swt.internal.C;
import org.eclipse.swt.internal.Callback;
import org.eclipse.swt.internal.mozilla.IIDStore;
import org.eclipse.swt.internal.mozilla.MozillaVersion;
import org.eclipse.swt.internal.mozilla.XPCOM;
import org.eclipse.swt.internal.mozilla.XPCOMObject;
import org.eclipse.swt.internal.mozilla.nsIClassInfo;
import org.eclipse.swt.internal.mozilla.nsIComponentManager;
import org.eclipse.swt.internal.mozilla.nsID;
import org.eclipse.swt.internal.mozilla.nsIMemory;
import org.eclipse.swt.internal.mozilla.nsIServiceManager;
import org.eclipse.swt.internal.mozilla.nsISupports;
import org.eclipse.swt.internal.mozilla.nsIVariant;
import org.eclipse.swt.internal.mozilla.nsIWritableVariant;
import org.eclipse.swt.internal.mozilla.nsIXPConnect;

class External
{
  public static final String EXTERNAL_IID_STR = "ded01d20-ba6f-11dd-ad8b-0800200c9a66";
  public static final nsID EXTERNAL_IID = new nsID("ded01d20-ba6f-11dd-ad8b-0800200c9a66");
  XPCOMObject supports;
  XPCOMObject external;
  XPCOMObject classInfo;
  XPCOMObject securityCheckedComponent;
  XPCOMObject scriptObjectOwner;
  XPCOMObject xpcScriptable;
  int refCount = 0;
  static final String CALLJAVA = "callJava";
  static Callback CallJavaProc;
  static Callback GetScriptableFlags24Proc = null;
  
  External()
  {
    createCOMInterfaces();
  }
  
  static long callJava(long paramLong1, long paramLong2, long paramLong3)
  {
    int i = 8;
    long l1 = paramLong3 + 2 * i;
    nsIVariant localnsIVariant = null;
    long[] arrayOfLong = new long[1];
    int j = XPCOM.NS_GetServiceManager(arrayOfLong);
    if (j != 0) {
      Mozilla.error(j);
    }
    if (arrayOfLong[0] == 0L) {
      Mozilla.error(-2147467262);
    }
    nsIServiceManager localnsIServiceManager = new nsIServiceManager(arrayOfLong[0]);
    arrayOfLong[0] = 0L;
    j = localnsIServiceManager.GetService(XPCOM.NS_IXPCONNECT_CID, IIDStore.GetIID(nsIXPConnect.class), arrayOfLong);
    if (j != 0) {
      Mozilla.error(j);
    }
    if (arrayOfLong[0] == 0L) {
      Mozilla.error(-2147467262);
    }
    nsIXPConnect localnsIXPConnect = new nsIXPConnect(arrayOfLong[0]);
    arrayOfLong[0] = 0L;
    j = localnsIXPConnect.JSValToVariant(paramLong1, l1, arrayOfLong);
    if ((j == 0) && (arrayOfLong[0] != 0L))
    {
      localObject1 = new nsIVariant(arrayOfLong[0]);
      arrayOfLong[0] = 0L;
      localObject2 = new short[1];
      j = ((nsIVariant)localObject1).GetDataType((short[])localObject2);
      if ((j == 0) && (localObject2[0] == 2))
      {
        int[] arrayOfInt = new int[1];
        j = ((nsIVariant)localObject1).GetAsInt32(arrayOfInt);
        if (j == 0)
        {
          int k = arrayOfInt[0];
          l1 += i;
          j = localnsIXPConnect.JSValToVariant(paramLong1, l1, arrayOfLong);
          if ((j == 0) && (arrayOfLong[0] != 0L))
          {
            l3 = arrayOfLong[0];
            arrayOfLong[0] = 0L;
            l1 += i;
            j = localnsIXPConnect.JSValToVariant(paramLong1, l1, arrayOfLong);
            if ((j == 0) && (arrayOfLong[0] != 0L))
            {
              l4 = arrayOfLong[0];
              arrayOfLong[0] = 0L;
              localnsIVariant = new nsIVariant(invokeFunction(k, l3, l4));
              new nsISupports(l4).Release();
            }
            new nsISupports(l3).Release();
          }
        }
      }
      ((nsIVariant)localObject1).Release();
    }
    arrayOfLong[0] = 0L;
    if (localnsIVariant == null)
    {
      j = XPCOM.NS_GetComponentManager(arrayOfLong);
      if (j != 0) {
        Mozilla.error(j);
      }
      if (arrayOfLong[0] == 0L) {
        Mozilla.error(-2147467262);
      }
      localObject1 = new nsIComponentManager(arrayOfLong[0]);
      arrayOfLong[0] = 0L;
      localnsIVariant = convertToJS(null, (nsIComponentManager)localObject1);
      ((nsIComponentManager)localObject1).Release();
    }
    Object localObject1 = MozillaDelegate.wcsToMbcs(null, "@mozilla.org/xpcom/memory-service;1", true);
    j = localnsIServiceManager.GetServiceByContractID((byte[])localObject1, IIDStore.GetIID(nsIMemory.class), arrayOfLong);
    if (j != 0) {
      Mozilla.error(j);
    }
    if (arrayOfLong[0] == 0L) {
      Mozilla.error(-2147467262);
    }
    localnsIServiceManager.Release();
    Object localObject2 = new nsIMemory(arrayOfLong[0]);
    arrayOfLong[0] = 0L;
    long l2 = ((nsIMemory)localObject2).Alloc(i);
    C.memset(l2, 0, i);
    long l3 = 0L;
    if (MozillaVersion.CheckVersion(6)) {
      l3 = XPCOM.JS_GetGlobalForScopeChain24(paramLong1);
    } else {
      l3 = XPCOM.JS_GetGlobalObject(Mozilla.getJSLibPathBytes(), paramLong1);
    }
    j = localnsIXPConnect.VariantToJS(paramLong1, l3, localnsIVariant.getAddress(), l2);
    localnsIVariant.Release();
    localnsIXPConnect.Release();
    long l4 = 0L;
    if (j == 0)
    {
      C.memmove(paramLong3, l2, i);
      l4 = 1L;
    }
    ((nsIMemory)localObject2).Free(l2);
    ((nsIMemory)localObject2).Release();
    return l4;
  }
  
  static int callJava(int paramInt, long paramLong1, long paramLong2, long paramLong3)
  {
    long l = invokeFunction(paramInt, paramLong1, paramLong2);
    C.memmove(paramLong3, new long[] { l }, C.PTR_SIZEOF);
    return 0;
  }
  
  static Object convertToJava(nsIVariant paramnsIVariant, short paramShort)
  {
    int i;
    switch (paramShort)
    {
    case 13: 
    case 255: 
      return null;
    case 254: 
      return new Object[0];
    case 10: 
      int[] arrayOfInt1 = new int[1];
      i = paramnsIVariant.GetAsBool(arrayOfInt1);
      if (i != 0) {
        Mozilla.error(i);
      }
      return new Boolean(arrayOfInt1[0] != 0);
    case 2: 
      int[] arrayOfInt2 = new int[1];
      i = paramnsIVariant.GetAsInt32(arrayOfInt2);
      if (i != 0) {
        Mozilla.error(i);
      }
      return new Double(arrayOfInt2[0]);
    case 9: 
      long l1 = C.malloc(8L);
      i = paramnsIVariant.GetAsDouble(l1);
      if (i != 0) {
        Mozilla.error(i);
      }
      double[] arrayOfDouble = new double[1];
      C.memmove(arrayOfDouble, l1, 8L);
      C.free(l1);
      return new Double(arrayOfDouble[0]);
    case 22: 
      int[] arrayOfInt3 = new int[1];
      long[] arrayOfLong1 = new long[1];
      i = paramnsIVariant.GetAsWStringWithSize(arrayOfInt3, arrayOfLong1);
      if (i != 0) {
        Mozilla.error(i);
      }
      char[] arrayOfChar1 = new char[arrayOfInt3[0]];
      C.memmove(arrayOfChar1, arrayOfLong1[0], arrayOfInt3[0] * 2);
      return new String(arrayOfChar1);
    case 20: 
      Object[] arrayOfObject = new Object[0];
      long l2 = C.malloc(16L);
      C.memset(l2, 0, 16L);
      int[] arrayOfInt4 = new int[1];
      short[] arrayOfShort = new short[1];
      long[] arrayOfLong2 = new long[1];
      i = paramnsIVariant.GetAsArray(arrayOfShort, l2, arrayOfInt4, arrayOfLong2);
      if (i != 0) {
        Mozilla.error(i);
      }
      if (arrayOfLong2[0] == 0L) {
        Mozilla.error(-2147467261);
      }
      nsID localnsID = new nsID();
      XPCOM.memmove(localnsID, l2, 16);
      C.free(l2);
      long[] arrayOfLong3 = new long[1];
      i = XPCOM.NS_GetServiceManager(arrayOfLong3);
      if (i != 0) {
        Mozilla.error(i);
      }
      if (arrayOfLong3[0] == 0L) {
        Mozilla.error(-2147467262);
      }
      nsIServiceManager localnsIServiceManager = new nsIServiceManager(arrayOfLong3[0]);
      arrayOfLong3[0] = 0L;
      byte[] arrayOfByte = MozillaDelegate.wcsToMbcs(null, "@mozilla.org/xpcom/memory-service;1", true);
      i = localnsIServiceManager.GetServiceByContractID(arrayOfByte, IIDStore.GetIID(nsIMemory.class), arrayOfLong3);
      if (i != 0) {
        Mozilla.error(i);
      }
      if (arrayOfLong3[0] == 0L) {
        Mozilla.error(-2147467262);
      }
      localnsIServiceManager.Release();
      nsIMemory localnsIMemory = new nsIMemory(arrayOfLong3[0]);
      arrayOfLong3[0] = 0L;
      int j;
      Object localObject1;
      Object localObject2;
      if (localnsID.Equals(IIDStore.GetIID(nsIVariant.class)))
      {
        arrayOfObject = new Object[arrayOfInt4[0]];
        for (j = 0; j < arrayOfInt4[0]; j++)
        {
          localObject1 = new long[1];
          C.memmove((long[])localObject1, arrayOfLong2[0] + j * C.PTR_SIZEOF, C.PTR_SIZEOF);
          nsISupports localnsISupports = new nsISupports(localObject1[0]);
          i = localnsISupports.QueryInterface(localnsID, arrayOfLong3);
          if (i != 0) {
            Mozilla.error(i);
          }
          if (arrayOfLong3[0] == 0L) {
            Mozilla.error(-2147467262);
          }
          localObject2 = new nsIVariant(arrayOfLong3[0]);
          arrayOfLong3[0] = 0L;
          arrayOfShort[0] = 0;
          i = ((nsIVariant)localObject2).GetDataType(arrayOfShort);
          if (i != 0) {
            Mozilla.error(i);
          }
          try
          {
            arrayOfObject[j] = convertToJava((nsIVariant)localObject2, arrayOfShort[0]);
            ((nsIVariant)localObject2).Release();
          }
          catch (IllegalArgumentException localIllegalArgumentException)
          {
            ((nsIVariant)localObject2).Release();
            localnsIMemory.Free(arrayOfLong2[0]);
            localnsIMemory.Release();
            throw localIllegalArgumentException;
          }
        }
      }
      else
      {
        switch (arrayOfShort[0])
        {
        case 9: 
          arrayOfObject = new Object[arrayOfInt4[0]];
          for (j = 0; j < arrayOfInt4[0]; j++)
          {
            localObject1 = new double[1];
            C.memmove((double[])localObject1, arrayOfLong2[0] + j * 8, 8L);
            arrayOfObject[j] = new Double(localObject1[0]);
          }
          break;
        case 10: 
          arrayOfObject = new Object[arrayOfInt4[0]];
          for (j = 0; j < arrayOfInt4[0]; j++) {
            if (MozillaVersion.CheckVersion(5))
            {
              localObject1 = new byte[1];
              C.memmove((byte[])localObject1, arrayOfLong2[0] + j, 1L);
              arrayOfObject[j] = new Boolean(localObject1[0] != 0);
            }
            else
            {
              localObject1 = new int[1];
              C.memmove((int[])localObject1, arrayOfLong2[0] + j * 4, 4L);
              arrayOfObject[j] = new Boolean(localObject1[0] != 0);
            }
          }
          break;
        case 2: 
          arrayOfObject = new Object[arrayOfInt4[0]];
          for (j = 0; j < arrayOfInt4[0]; j++)
          {
            localObject1 = new int[1];
            C.memmove((int[])localObject1, arrayOfLong2[0] + j * 4, 4L);
            arrayOfObject[j] = new Double(localObject1[0]);
          }
          break;
        case 17: 
          arrayOfObject = new Object[arrayOfInt4[0]];
          for (j = 0; j < arrayOfInt4[0]; j++)
          {
            long l3 = arrayOfLong2[0] + j * C.PTR_SIZEOF;
            localObject2 = new long[1];
            C.memmove((long[])localObject2, l3, C.PTR_SIZEOF);
            int k = XPCOM.strlen_PRUnichar(localObject2[0]);
            char[] arrayOfChar2 = new char[k];
            XPCOM.memmove(arrayOfChar2, localObject2[0], k * 2);
            arrayOfObject[j] = new String(arrayOfChar2);
          }
          break;
        default: 
          localnsIMemory.Free(arrayOfLong2[0]);
          localnsIMemory.Release();
          SWT.error(5);
        }
      }
      localnsIMemory.Free(arrayOfLong2[0]);
      localnsIMemory.Release();
      return arrayOfObject;
    }
    SWT.error(5);
    return null;
  }
  
  static nsIVariant convertToJS(Object paramObject, nsIComponentManager paramnsIComponentManager)
  {
    long[] arrayOfLong1 = new long[1];
    byte[] arrayOfByte = MozillaDelegate.wcsToMbcs(null, "@mozilla.org/variant;1", true);
    int i = paramnsIComponentManager.CreateInstanceByContractID(arrayOfByte, 0L, IIDStore.GetIID(nsIWritableVariant.class), arrayOfLong1);
    nsIWritableVariant localnsIWritableVariant = new nsIWritableVariant(arrayOfLong1[0]);
    arrayOfLong1[0] = 0L;
    if (paramObject == null)
    {
      i = localnsIWritableVariant.SetAsEmpty();
      if (i != 0) {
        Mozilla.error(i);
      }
      return localnsIWritableVariant;
    }
    Object localObject1;
    int j;
    if ((paramObject instanceof String))
    {
      localObject1 = (String)paramObject;
      j = ((String)localObject1).length();
      char[] arrayOfChar = new char[j];
      ((String)localObject1).getChars(0, j, arrayOfChar, 0);
      i = localnsIWritableVariant.SetAsWStringWithSize(j, arrayOfChar);
      if (i != 0) {
        Mozilla.error(i);
      }
      return localnsIWritableVariant;
    }
    if ((paramObject instanceof Boolean))
    {
      localObject1 = (Boolean)paramObject;
      i = localnsIWritableVariant.SetAsBool(((Boolean)localObject1).booleanValue() ? 1 : 0);
      if (i != 0) {
        Mozilla.error(i);
      }
      return localnsIWritableVariant;
    }
    if ((paramObject instanceof Number))
    {
      localObject1 = (Number)paramObject;
      i = localnsIWritableVariant.SetAsDouble(((Number)localObject1).doubleValue());
      if (i != 0) {
        Mozilla.error(i);
      }
      return localnsIWritableVariant;
    }
    if ((paramObject instanceof Object[]))
    {
      localObject1 = (Object[])paramObject;
      j = localObject1.length;
      if (j == 0)
      {
        i = localnsIWritableVariant.SetAsEmptyArray();
        if (i != 0) {
          Mozilla.error(i);
        }
      }
      else
      {
        long l1 = C.malloc(C.PTR_SIZEOF * j);
        for (int k = 0; k < j; k++)
        {
          Object localObject2 = localObject1[k];
          try
          {
            nsIVariant localnsIVariant = convertToJS(localObject2, paramnsIComponentManager);
            C.memmove(l1 + C.PTR_SIZEOF * k, new long[] { localnsIVariant.getAddress() }, C.PTR_SIZEOF);
          }
          catch (SWTException localSWTException)
          {
            C.free(l1);
            localnsIWritableVariant.Release();
            for (int m = 0; m < k; m++)
            {
              long[] arrayOfLong2 = new long[1];
              C.memmove(arrayOfLong2, l1 + C.PTR_SIZEOF * m, C.PTR_SIZEOF);
              new nsISupports(arrayOfLong2[0]).Release();
            }
            throw localSWTException;
          }
        }
        long l2 = C.malloc(16L);
        XPCOM.memmove(l2, IIDStore.GetIID(nsIVariant.class), 16);
        i = localnsIWritableVariant.SetAsArray((short)19, l2, j, l1);
        C.free(l2);
        C.free(l1);
        if (i != 0) {
          Mozilla.error(i);
        }
      }
      return localnsIWritableVariant;
    }
    localnsIWritableVariant.Release();
    SWT.error(51);
    return null;
  }
  
  static long invokeFunction(int paramInt, long paramLong1, long paramLong2)
  {
    Integer localInteger = new Integer(paramInt);
    BrowserFunction localBrowserFunction = (BrowserFunction)Mozilla.AllFunctions.get(localInteger);
    Object localObject1 = null;
    Object localObject2;
    if (localBrowserFunction != null) {
      try
      {
        short[] arrayOfShort = new short[1];
        nsIVariant localnsIVariant = new nsIVariant(paramLong1);
        int j = localnsIVariant.GetDataType(arrayOfShort);
        if (j != 0) {
          Mozilla.error(j);
        }
        localObject2 = convertToJava(localnsIVariant, arrayOfShort[0]);
        arrayOfShort[0] = 0;
        if ((localObject2 instanceof String))
        {
          String str = (String)localObject2;
          if (str.equals(localBrowserFunction.token))
          {
            localnsIVariant = new nsIVariant(paramLong2);
            j = localnsIVariant.GetDataType(arrayOfShort);
            if (j != 0) {
              Mozilla.error(j);
            }
            localObject2 = convertToJava(localnsIVariant, arrayOfShort[0]);
            if ((localObject2 instanceof Object[]))
            {
              Object[] arrayOfObject = (Object[])localObject2;
              try
              {
                localObject1 = localBrowserFunction.function(arrayOfObject);
              }
              catch (Exception localException)
              {
                localObject1 = WebBrowser.CreateErrorString(localException.getLocalizedMessage());
              }
            }
          }
        }
      }
      catch (IllegalArgumentException localIllegalArgumentException)
      {
        if (localBrowserFunction.isEvaluate) {
          localBrowserFunction.function(new String[] { WebBrowser.CreateErrorString(new SWTException(51).getLocalizedMessage()) });
        }
        localObject1 = WebBrowser.CreateErrorString(localIllegalArgumentException.getLocalizedMessage());
      }
    }
    long[] arrayOfLong = new long[1];
    int i = XPCOM.NS_GetComponentManager(arrayOfLong);
    if (i != 0) {
      Mozilla.error(i);
    }
    if (arrayOfLong[0] == 0L) {
      Mozilla.error(-2147467262);
    }
    nsIComponentManager localnsIComponentManager = new nsIComponentManager(arrayOfLong[0]);
    arrayOfLong[0] = 0L;
    try
    {
      localObject2 = convertToJS(localObject1, localnsIComponentManager);
    }
    catch (SWTException localSWTException)
    {
      localObject2 = convertToJS(WebBrowser.CreateErrorString(localSWTException.getLocalizedMessage()), localnsIComponentManager);
    }
    localnsIComponentManager.Release();
    return ((nsIVariant)localObject2).getAddress();
  }
  
  int AddRef()
  {
    this.refCount += 1;
    return this.refCount;
  }
  
  void createCOMInterfaces()
  {
    this.supports = new XPCOMObject(new int[] { 2, 0, 0 })
    {
      public long method0(long[] paramAnonymousArrayOfLong)
      {
        return External.this.QueryInterface(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method1(long[] paramAnonymousArrayOfLong)
      {
        return External.this.AddRef();
      }
      
      public long method2(long[] paramAnonymousArrayOfLong)
      {
        return External.this.Release();
      }
    };
    this.classInfo = new XPCOMObject(new int[] { 2, 0, 0, 2, 2, 1, 1, 1, 1, 1, 1 })
    {
      public long method0(long[] paramAnonymousArrayOfLong)
      {
        return External.this.QueryInterface(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method1(long[] paramAnonymousArrayOfLong)
      {
        return External.this.AddRef();
      }
      
      public long method2(long[] paramAnonymousArrayOfLong)
      {
        return External.this.Release();
      }
      
      public long method3(long[] paramAnonymousArrayOfLong)
      {
        return External.this.getInterfaces(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method4(long[] paramAnonymousArrayOfLong)
      {
        return External.this.getHelperForLanguage((int)paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method5(long[] paramAnonymousArrayOfLong)
      {
        return External.this.getContractID(paramAnonymousArrayOfLong[0]);
      }
      
      public long method6(long[] paramAnonymousArrayOfLong)
      {
        return External.this.getClassDescription(paramAnonymousArrayOfLong[0]);
      }
      
      public long method7(long[] paramAnonymousArrayOfLong)
      {
        return External.this.getClassID(paramAnonymousArrayOfLong[0]);
      }
      
      public long method8(long[] paramAnonymousArrayOfLong)
      {
        return External.this.getImplementationLanguage(paramAnonymousArrayOfLong[0]);
      }
      
      public long method9(long[] paramAnonymousArrayOfLong)
      {
        return External.this.getFlags(paramAnonymousArrayOfLong[0]);
      }
      
      public long method10(long[] paramAnonymousArrayOfLong)
      {
        return External.this.getClassIDNoAlloc(paramAnonymousArrayOfLong[0]);
      }
    };
    this.securityCheckedComponent = new XPCOMObject(new int[] { 2, 0, 0, 2, 3, 3, 3 })
    {
      public long method0(long[] paramAnonymousArrayOfLong)
      {
        return External.this.QueryInterface(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method1(long[] paramAnonymousArrayOfLong)
      {
        return External.this.AddRef();
      }
      
      public long method2(long[] paramAnonymousArrayOfLong)
      {
        return External.this.Release();
      }
      
      public long method3(long[] paramAnonymousArrayOfLong)
      {
        return External.this.canCreateWrapper(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method4(long[] paramAnonymousArrayOfLong)
      {
        return External.this.canCallMethod(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2]);
      }
      
      public long method5(long[] paramAnonymousArrayOfLong)
      {
        return External.this.canGetProperty(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2]);
      }
      
      public long method6(long[] paramAnonymousArrayOfLong)
      {
        return External.this.canSetProperty(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2]);
      }
    };
    this.external = new XPCOMObject(new int[] { 2, 0, 0, 4 })
    {
      public long method0(long[] paramAnonymousArrayOfLong)
      {
        return External.this.QueryInterface(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method1(long[] paramAnonymousArrayOfLong)
      {
        return External.this.AddRef();
      }
      
      public long method2(long[] paramAnonymousArrayOfLong)
      {
        return External.this.Release();
      }
      
      public long method3(long[] paramAnonymousArrayOfLong)
      {
        return External.callJava((int)paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2], paramAnonymousArrayOfLong[3]);
      }
    };
    this.scriptObjectOwner = new XPCOMObject(new int[] { 2, 0, 0, 2, 1 })
    {
      public long method0(long[] paramAnonymousArrayOfLong)
      {
        return External.this.QueryInterface(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method1(long[] paramAnonymousArrayOfLong)
      {
        return External.this.AddRef();
      }
      
      public long method2(long[] paramAnonymousArrayOfLong)
      {
        return External.this.Release();
      }
      
      public long method3(long[] paramAnonymousArrayOfLong)
      {
        return External.this.getScriptObject(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method4(long[] paramAnonymousArrayOfLong)
      {
        return External.this.setScriptObject(paramAnonymousArrayOfLong[0]);
      }
    };
    this.xpcScriptable = new XPCOMObject(new int[] { 2, 0, 0, 1, 0, 4, 3, 3, 3, 6, 5, 6, 6, 4, 7, 7, 6, 3, 7, 5, 5, 6, 4, 2 })
    {
      public long method0(long[] paramAnonymousArrayOfLong)
      {
        return External.this.QueryInterface(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1]);
      }
      
      public long method1(long[] paramAnonymousArrayOfLong)
      {
        return External.this.AddRef();
      }
      
      public long method2(long[] paramAnonymousArrayOfLong)
      {
        return External.this.Release();
      }
      
      public long method3(long[] paramAnonymousArrayOfLong)
      {
        return External.this.getClassName(paramAnonymousArrayOfLong[0]);
      }
      
      public long method4(long[] paramAnonymousArrayOfLong)
      {
        return External.getScriptableFlags();
      }
      
      public long method7(long[] paramAnonymousArrayOfLong)
      {
        return External.this.postCreate(paramAnonymousArrayOfLong[0], paramAnonymousArrayOfLong[1], paramAnonymousArrayOfLong[2]);
      }
    };
    if (GetScriptableFlags24Proc != null)
    {
      long l = this.xpcScriptable.getVtable();
      long[] arrayOfLong1 = new long[1];
      C.memmove(arrayOfLong1, l, C.PTR_SIZEOF);
      long[] arrayOfLong2 = new long[24];
      C.memmove(arrayOfLong2, arrayOfLong1[0], C.PTR_SIZEOF * arrayOfLong2.length);
      arrayOfLong2[4] = XPCOM.CALLBACK_GetScriptableFlags24(GetScriptableFlags24Proc.getAddress());
      C.memmove(arrayOfLong1[0], arrayOfLong2, C.PTR_SIZEOF * arrayOfLong2.length);
    }
  }
  
  void disposeCOMInterfaces()
  {
    if (this.supports != null)
    {
      this.supports.dispose();
      this.supports = null;
    }
    if (this.classInfo != null)
    {
      this.classInfo.dispose();
      this.classInfo = null;
    }
    if (this.securityCheckedComponent != null)
    {
      this.securityCheckedComponent.dispose();
      this.securityCheckedComponent = null;
    }
    if (this.external != null)
    {
      this.external.dispose();
      this.external = null;
    }
    if (this.scriptObjectOwner != null)
    {
      this.scriptObjectOwner.dispose();
      this.scriptObjectOwner = null;
    }
    if (this.xpcScriptable != null)
    {
      this.xpcScriptable.dispose();
      this.xpcScriptable = null;
    }
  }
  
  long getAddress()
  {
    return this.external.getAddress();
  }
  
  int QueryInterface(long paramLong1, long paramLong2)
  {
    if ((paramLong1 == 0L) || (paramLong2 == 0L)) {
      return -2147467262;
    }
    nsID localnsID = new nsID();
    XPCOM.memmove(localnsID, paramLong1, 16);
    if (localnsID.Equals(IIDStore.GetIID(nsISupports.class)))
    {
      XPCOM.memmove(paramLong2, new long[] { this.supports.getAddress() }, C.PTR_SIZEOF);
      AddRef();
      return 0;
    }
    if (localnsID.Equals(IIDStore.GetIID(nsIClassInfo.class)))
    {
      XPCOM.memmove(paramLong2, new long[] { this.classInfo.getAddress() }, C.PTR_SIZEOF);
      AddRef();
      return 0;
    }
    if (localnsID.Equals(XPCOM.NS_ISECURITYCHECKEDCOMPONENT_IID))
    {
      XPCOM.memmove(paramLong2, new long[] { this.securityCheckedComponent.getAddress() }, C.PTR_SIZEOF);
      AddRef();
      return 0;
    }
    if (localnsID.Equals(EXTERNAL_IID))
    {
      XPCOM.memmove(paramLong2, new long[] { this.external.getAddress() }, C.PTR_SIZEOF);
      AddRef();
      return 0;
    }
    if (MozillaVersion.CheckVersion(5))
    {
      if (localnsID.Equals(XPCOM.NS_ISCRIPTOBJECTOWNER_IID))
      {
        XPCOM.memmove(paramLong2, new long[] { this.scriptObjectOwner.getAddress() }, C.PTR_SIZEOF);
        AddRef();
        return 0;
      }
      if ((MozillaVersion.CheckVersion(6)) && (localnsID.Equals(XPCOM.NS_IXPCSCRIPTABLE_IID)))
      {
        XPCOM.memmove(paramLong2, new long[] { this.xpcScriptable.getAddress() }, C.PTR_SIZEOF);
        AddRef();
        return 0;
      }
    }
    XPCOM.memmove(paramLong2, new long[] { 0L }, C.PTR_SIZEOF);
    return -2147467262;
  }
  
  int Release()
  {
    this.refCount -= 1;
    if (this.refCount == 0) {
      disposeCOMInterfaces();
    }
    return this.refCount;
  }
  
  int getClassDescription(long paramLong)
  {
    long[] arrayOfLong = new long[1];
    int i = XPCOM.NS_GetServiceManager(arrayOfLong);
    if (i != 0) {
      Mozilla.error(i);
    }
    if (arrayOfLong[0] == 0L) {
      Mozilla.error(-2147467262);
    }
    nsIServiceManager localnsIServiceManager = new nsIServiceManager(arrayOfLong[0]);
    arrayOfLong[0] = 0L;
    byte[] arrayOfByte1 = MozillaDelegate.wcsToMbcs(null, "@mozilla.org/xpcom/memory-service;1", true);
    i = localnsIServiceManager.GetServiceByContractID(arrayOfByte1, IIDStore.GetIID(nsIMemory.class), arrayOfLong);
    if (i != 0) {
      Mozilla.error(i);
    }
    if (arrayOfLong[0] == 0L) {
      Mozilla.error(-2147467262);
    }
    localnsIServiceManager.Release();
    nsIMemory localnsIMemory = new nsIMemory(arrayOfLong[0]);
    arrayOfLong[0] = 0L;
    byte[] arrayOfByte2 = MozillaDelegate.wcsToMbcs(null, "external", true);
    long l = localnsIMemory.Alloc(arrayOfByte2.length);
    C.memmove(l, arrayOfByte2, arrayOfByte2.length);
    C.memmove(paramLong, new long[] { l }, C.PTR_SIZEOF);
    localnsIMemory.Release();
    return 0;
  }
  
  int getClassID(long paramLong)
  {
    return 0;
  }
  
  int getClassIDNoAlloc(long paramLong)
  {
    return 0;
  }
  
  int getContractID(long paramLong)
  {
    return 0;
  }
  
  int getFlags(long paramLong)
  {
    C.memmove(paramLong, new int[] { 4 }, 4L);
    return 0;
  }
  
  int getHelperForLanguage(int paramInt, long paramLong)
  {
    C.memmove(paramLong, new long[] { 0L }, C.PTR_SIZEOF);
    return 0;
  }
  
  int getImplementationLanguage(long paramLong)
  {
    C.memmove(paramLong, new int[] { 5 }, 4L);
    return 0;
  }
  
  int getInterfaces(long paramLong1, long paramLong2)
  {
    long[] arrayOfLong = new long[1];
    int i = XPCOM.NS_GetServiceManager(arrayOfLong);
    if (i != 0) {
      Mozilla.error(i);
    }
    if (arrayOfLong[0] == 0L) {
      Mozilla.error(-2147467262);
    }
    nsIServiceManager localnsIServiceManager = new nsIServiceManager(arrayOfLong[0]);
    arrayOfLong[0] = 0L;
    byte[] arrayOfByte = MozillaDelegate.wcsToMbcs(null, "@mozilla.org/xpcom/memory-service;1", true);
    i = localnsIServiceManager.GetServiceByContractID(arrayOfByte, IIDStore.GetIID(nsIMemory.class), arrayOfLong);
    if (i != 0) {
      Mozilla.error(i);
    }
    if (arrayOfLong[0] == 0L) {
      Mozilla.error(-2147467262);
    }
    localnsIServiceManager.Release();
    nsIMemory localnsIMemory = new nsIMemory(arrayOfLong[0]);
    arrayOfLong[0] = 0L;
    long l1 = localnsIMemory.Alloc(16);
    XPCOM.memmove(l1, XPCOM.NS_ISECURITYCHECKEDCOMPONENT_IID, 16);
    long l2 = localnsIMemory.Alloc(16);
    XPCOM.memmove(l2, EXTERNAL_IID, 16);
    long l3 = localnsIMemory.Alloc(3 * C.PTR_SIZEOF);
    C.memmove(l3, new long[] { l1 }, C.PTR_SIZEOF);
    C.memmove(l3 + C.PTR_SIZEOF, new long[] { l2 }, C.PTR_SIZEOF);
    C.memmove(paramLong2, new long[] { l3 }, C.PTR_SIZEOF);
    localnsIMemory.Release();
    C.memmove(paramLong1, new int[] { 2 }, 4L);
    return 0;
  }
  
  int getScriptObject(long paramLong1, long paramLong2)
  {
    byte[] arrayOfByte1 = Mozilla.getJSLibPathBytes();
    long l1 = XPCOM.nsIScriptContext_GetNativeContext(paramLong1);
    long l2 = XPCOM.JS_GetGlobalObject(arrayOfByte1, l1);
    long l3 = XPCOM.JS_NewObject(arrayOfByte1, l1, 0L, 0L, l2);
    byte[] arrayOfByte2 = MozillaDelegate.wcsToMbcs(null, "callJava", true);
    int i = 7;
    XPCOM.JS_DefineFunction(arrayOfByte1, l1, l3, arrayOfByte2, XPCOM.CALLBACK_JSNative(CallJavaProc.getAddress()), 3, i);
    XPCOM.memmove(paramLong2, new long[] { l3 }, C.PTR_SIZEOF);
    return 0;
  }
  
  int setScriptObject(long paramLong)
  {
    return 1;
  }
  
  int canCreateWrapper(long paramLong1, long paramLong2)
  {
    long[] arrayOfLong = new long[1];
    int i = XPCOM.NS_GetServiceManager(arrayOfLong);
    if (i != 0) {
      Mozilla.error(i);
    }
    if (arrayOfLong[0] == 0L) {
      Mozilla.error(-2147467262);
    }
    nsIServiceManager localnsIServiceManager = new nsIServiceManager(arrayOfLong[0]);
    arrayOfLong[0] = 0L;
    byte[] arrayOfByte1 = MozillaDelegate.wcsToMbcs(null, "@mozilla.org/xpcom/memory-service;1", true);
    i = localnsIServiceManager.GetServiceByContractID(arrayOfByte1, IIDStore.GetIID(nsIMemory.class), arrayOfLong);
    if (i != 0) {
      Mozilla.error(i);
    }
    if (arrayOfLong[0] == 0L) {
      Mozilla.error(-2147467262);
    }
    localnsIServiceManager.Release();
    nsIMemory localnsIMemory = new nsIMemory(arrayOfLong[0]);
    arrayOfLong[0] = 0L;
    byte[] arrayOfByte2 = MozillaDelegate.wcsToMbcs(null, "allAccess", true);
    long l = localnsIMemory.Alloc(arrayOfByte2.length);
    C.memmove(l, arrayOfByte2, arrayOfByte2.length);
    C.memmove(paramLong2, new long[] { l }, C.PTR_SIZEOF);
    localnsIMemory.Release();
    return 0;
  }
  
  int canCallMethod(long paramLong1, long paramLong2, long paramLong3)
  {
    long[] arrayOfLong = new long[1];
    int i = XPCOM.NS_GetServiceManager(arrayOfLong);
    if (i != 0) {
      Mozilla.error(i);
    }
    if (arrayOfLong[0] == 0L) {
      Mozilla.error(-2147467262);
    }
    nsIServiceManager localnsIServiceManager = new nsIServiceManager(arrayOfLong[0]);
    arrayOfLong[0] = 0L;
    byte[] arrayOfByte1 = MozillaDelegate.wcsToMbcs(null, "@mozilla.org/xpcom/memory-service;1", true);
    i = localnsIServiceManager.GetServiceByContractID(arrayOfByte1, IIDStore.GetIID(nsIMemory.class), arrayOfLong);
    if (i != 0) {
      Mozilla.error(i);
    }
    if (arrayOfLong[0] == 0L) {
      Mozilla.error(-2147467262);
    }
    localnsIServiceManager.Release();
    nsIMemory localnsIMemory = new nsIMemory(arrayOfLong[0]);
    arrayOfLong[0] = 0L;
    int j = XPCOM.strlen_PRUnichar(paramLong2);
    char[] arrayOfChar = new char[j];
    XPCOM.memmove(arrayOfChar, paramLong2, j * 2);
    String str = new String(arrayOfChar);
    byte[] arrayOfByte2;
    if (str.equals("callJava")) {
      arrayOfByte2 = MozillaDelegate.wcsToMbcs(null, "allAccess", true);
    } else {
      arrayOfByte2 = MozillaDelegate.wcsToMbcs(null, "noAccess", true);
    }
    long l = localnsIMemory.Alloc(arrayOfByte2.length);
    C.memmove(l, arrayOfByte2, arrayOfByte2.length);
    C.memmove(paramLong3, new long[] { l }, C.PTR_SIZEOF);
    localnsIMemory.Release();
    return 0;
  }
  
  int canGetProperty(long paramLong1, long paramLong2, long paramLong3)
  {
    long[] arrayOfLong = new long[1];
    int i = XPCOM.NS_GetServiceManager(arrayOfLong);
    if (i != 0) {
      Mozilla.error(i);
    }
    if (arrayOfLong[0] == 0L) {
      Mozilla.error(-2147467262);
    }
    nsIServiceManager localnsIServiceManager = new nsIServiceManager(arrayOfLong[0]);
    arrayOfLong[0] = 0L;
    byte[] arrayOfByte1 = MozillaDelegate.wcsToMbcs(null, "@mozilla.org/xpcom/memory-service;1", true);
    i = localnsIServiceManager.GetServiceByContractID(arrayOfByte1, IIDStore.GetIID(nsIMemory.class), arrayOfLong);
    if (i != 0) {
      Mozilla.error(i);
    }
    if (arrayOfLong[0] == 0L) {
      Mozilla.error(-2147467262);
    }
    localnsIServiceManager.Release();
    nsIMemory localnsIMemory = new nsIMemory(arrayOfLong[0]);
    arrayOfLong[0] = 0L;
    byte[] arrayOfByte2 = MozillaDelegate.wcsToMbcs(null, "noAccess", true);
    long l = localnsIMemory.Alloc(arrayOfByte2.length);
    C.memmove(l, arrayOfByte2, arrayOfByte2.length);
    C.memmove(paramLong3, new long[] { l }, C.PTR_SIZEOF);
    localnsIMemory.Release();
    return 0;
  }
  
  int canSetProperty(long paramLong1, long paramLong2, long paramLong3)
  {
    long[] arrayOfLong = new long[1];
    int i = XPCOM.NS_GetServiceManager(arrayOfLong);
    if (i != 0) {
      Mozilla.error(i);
    }
    if (arrayOfLong[0] == 0L) {
      Mozilla.error(-2147467262);
    }
    nsIServiceManager localnsIServiceManager = new nsIServiceManager(arrayOfLong[0]);
    arrayOfLong[0] = 0L;
    byte[] arrayOfByte1 = MozillaDelegate.wcsToMbcs(null, "@mozilla.org/xpcom/memory-service;1", true);
    i = localnsIServiceManager.GetServiceByContractID(arrayOfByte1, IIDStore.GetIID(nsIMemory.class), arrayOfLong);
    if (i != 0) {
      Mozilla.error(i);
    }
    if (arrayOfLong[0] == 0L) {
      Mozilla.error(-2147467262);
    }
    localnsIServiceManager.Release();
    nsIMemory localnsIMemory = new nsIMemory(arrayOfLong[0]);
    arrayOfLong[0] = 0L;
    byte[] arrayOfByte2 = MozillaDelegate.wcsToMbcs(null, "noAccess", true);
    long l = localnsIMemory.Alloc(arrayOfByte2.length);
    C.memmove(l, arrayOfByte2, arrayOfByte2.length);
    C.memmove(paramLong3, new long[] { l }, C.PTR_SIZEOF);
    localnsIMemory.Release();
    return 0;
  }
  
  long getClassName(long paramLong)
  {
    long[] arrayOfLong = new long[1];
    int i = XPCOM.NS_GetServiceManager(arrayOfLong);
    if (i != 0) {
      Mozilla.error(i);
    }
    if (arrayOfLong[0] == 0L) {
      Mozilla.error(-2147467262);
    }
    nsIServiceManager localnsIServiceManager = new nsIServiceManager(arrayOfLong[0]);
    arrayOfLong[0] = 0L;
    byte[] arrayOfByte1 = MozillaDelegate.wcsToMbcs(null, "@mozilla.org/xpcom/memory-service;1", true);
    i = localnsIServiceManager.GetServiceByContractID(arrayOfByte1, IIDStore.GetIID(nsIMemory.class), arrayOfLong);
    if (i != 0) {
      Mozilla.error(i);
    }
    if (arrayOfLong[0] == 0L) {
      Mozilla.error(-2147467262);
    }
    localnsIServiceManager.Release();
    nsIMemory localnsIMemory = new nsIMemory(arrayOfLong[0]);
    arrayOfLong[0] = 0L;
    byte[] arrayOfByte2 = MozillaDelegate.wcsToMbcs(null, "external", true);
    long l = localnsIMemory.Alloc(arrayOfByte2.length);
    C.memmove(l, arrayOfByte2, arrayOfByte2.length);
    C.memmove(paramLong, new long[] { l }, C.PTR_SIZEOF);
    localnsIMemory.Release();
    return 0L;
  }
  
  static long getScriptableFlags()
  {
    return 131076L;
  }
  
  int postCreate(long paramLong1, long paramLong2, long paramLong3)
  {
    byte[] arrayOfByte = MozillaDelegate.wcsToMbcs(null, "callJava", true);
    int i = 7;
    XPCOM.JS_DefineFunction24(paramLong2, paramLong3, arrayOfByte, XPCOM.CALLBACK_JSNative(CallJavaProc.getAddress()), 3, i);
    return 0;
  }
  
  static
  {
    CallJavaProc = new Callback(External.class, "callJava", 3);
    if (CallJavaProc.getAddress() == 0L) {
      SWT.error(3);
    }
    if ((MozillaVersion.CheckVersion(6)) && (SWT.getPlatform().equals("win32")))
    {
      GetScriptableFlags24Proc = new Callback(External.class, "getScriptableFlags", 0);
      if (GetScriptableFlags24Proc.getAddress() == 0L) {
        SWT.error(3);
      }
    }
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/browser/External.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */