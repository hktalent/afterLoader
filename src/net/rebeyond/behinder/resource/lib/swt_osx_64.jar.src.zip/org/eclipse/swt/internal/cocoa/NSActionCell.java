package org.eclipse.swt.internal.cocoa;

public class NSActionCell
  extends NSCell
{
  public NSActionCell() {}
  
  public NSActionCell(long paramLong)
  {
    super(paramLong);
  }
  
  public NSActionCell(id paramid)
  {
    super(paramid);
  }
  
  public long action()
  {
    return OS.objc_msgSend(this.id, OS.sel_action);
  }
  
  public void setAction(long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_setAction_, paramLong);
  }
  
  public void setTarget(id paramid)
  {
    OS.objc_msgSend(this.id, OS.sel_setTarget_, paramid != null ? paramid.id : 0L);
  }
  
  public id target()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_target);
    return l != 0L ? new id(l) : null;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSActionCell.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */