package org.eclipse.swt.internal.cocoa;

public class NSGradient
  extends NSObject
{
  public NSGradient() {}
  
  public NSGradient(long paramLong)
  {
    super(paramLong);
  }
  
  public NSGradient(id paramid)
  {
    super(paramid);
  }
  
  public void drawFromPoint(NSPoint paramNSPoint1, NSPoint paramNSPoint2, long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_drawFromPoint_toPoint_options_, paramNSPoint1, paramNSPoint2, paramLong);
  }
  
  public void drawInRect(NSRect paramNSRect, double paramDouble)
  {
    OS.objc_msgSend(this.id, OS.sel_drawInRect_angle_, paramNSRect, paramDouble);
  }
  
  public NSGradient initWithStartingColor(NSColor paramNSColor1, NSColor paramNSColor2)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_initWithStartingColor_endingColor_, paramNSColor1 != null ? paramNSColor1.id : 0L, paramNSColor2 != null ? paramNSColor2.id : 0L);
    return l != 0L ? new NSGradient(l) : l == this.id ? this : null;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSGradient.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */