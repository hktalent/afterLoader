package org.eclipse.swt.accessibility;

public class AccessibleTableAdapter
  implements AccessibleTableListener
{
  public void deselectColumn(AccessibleTableEvent paramAccessibleTableEvent) {}
  
  public void deselectRow(AccessibleTableEvent paramAccessibleTableEvent) {}
  
  public void getCaption(AccessibleTableEvent paramAccessibleTableEvent) {}
  
  public void getCell(AccessibleTableEvent paramAccessibleTableEvent) {}
  
  public void getColumn(AccessibleTableEvent paramAccessibleTableEvent) {}
  
  public void getColumnCount(AccessibleTableEvent paramAccessibleTableEvent) {}
  
  public void getColumnDescription(AccessibleTableEvent paramAccessibleTableEvent) {}
  
  public void getColumnHeader(AccessibleTableEvent paramAccessibleTableEvent) {}
  
  public void getColumnHeaderCells(AccessibleTableEvent paramAccessibleTableEvent) {}
  
  public void getColumns(AccessibleTableEvent paramAccessibleTableEvent) {}
  
  public void getRow(AccessibleTableEvent paramAccessibleTableEvent) {}
  
  public void getRowCount(AccessibleTableEvent paramAccessibleTableEvent) {}
  
  public void getRowDescription(AccessibleTableEvent paramAccessibleTableEvent) {}
  
  public void getRowHeader(AccessibleTableEvent paramAccessibleTableEvent) {}
  
  public void getRowHeaderCells(AccessibleTableEvent paramAccessibleTableEvent) {}
  
  public void getRows(AccessibleTableEvent paramAccessibleTableEvent) {}
  
  public void getSelectedCellCount(AccessibleTableEvent paramAccessibleTableEvent) {}
  
  public void getSelectedCells(AccessibleTableEvent paramAccessibleTableEvent) {}
  
  public void getSelectedColumnCount(AccessibleTableEvent paramAccessibleTableEvent) {}
  
  public void getSelectedColumns(AccessibleTableEvent paramAccessibleTableEvent) {}
  
  public void getSelectedRowCount(AccessibleTableEvent paramAccessibleTableEvent) {}
  
  public void getSelectedRows(AccessibleTableEvent paramAccessibleTableEvent) {}
  
  public void getSummary(AccessibleTableEvent paramAccessibleTableEvent) {}
  
  public void getVisibleColumns(AccessibleTableEvent paramAccessibleTableEvent) {}
  
  public void getVisibleRows(AccessibleTableEvent paramAccessibleTableEvent) {}
  
  public void isColumnSelected(AccessibleTableEvent paramAccessibleTableEvent) {}
  
  public void isRowSelected(AccessibleTableEvent paramAccessibleTableEvent) {}
  
  public void selectColumn(AccessibleTableEvent paramAccessibleTableEvent) {}
  
  public void selectRow(AccessibleTableEvent paramAccessibleTableEvent) {}
  
  public void setSelectedColumn(AccessibleTableEvent paramAccessibleTableEvent) {}
  
  public void setSelectedRow(AccessibleTableEvent paramAccessibleTableEvent) {}
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/accessibility/AccessibleTableAdapter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */