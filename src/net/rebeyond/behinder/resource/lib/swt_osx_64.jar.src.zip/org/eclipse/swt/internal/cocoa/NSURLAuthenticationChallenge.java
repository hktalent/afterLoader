package org.eclipse.swt.internal.cocoa;

public class NSURLAuthenticationChallenge
  extends NSObject
{
  public NSURLAuthenticationChallenge() {}
  
  public NSURLAuthenticationChallenge(long paramLong)
  {
    super(paramLong);
  }
  
  public NSURLAuthenticationChallenge(id paramid)
  {
    super(paramid);
  }
  
  public long previousFailureCount()
  {
    return OS.objc_msgSend(this.id, OS.sel_previousFailureCount);
  }
  
  public NSURLCredential proposedCredential()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_proposedCredential);
    return l != 0L ? new NSURLCredential(l) : null;
  }
  
  public NSURLProtectionSpace protectionSpace()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_protectionSpace);
    return l != 0L ? new NSURLProtectionSpace(l) : null;
  }
  
  public id sender()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_sender);
    return l != 0L ? new id(l) : null;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSURLAuthenticationChallenge.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */