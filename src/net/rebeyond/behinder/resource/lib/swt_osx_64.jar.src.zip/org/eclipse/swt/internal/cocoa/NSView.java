package org.eclipse.swt.internal.cocoa;

public class NSView
  extends NSResponder
{
  public NSView() {}
  
  public NSView(long paramLong)
  {
    super(paramLong);
  }
  
  public NSView(id paramid)
  {
    super(paramid);
  }
  
  public boolean acceptsFirstMouse(NSEvent paramNSEvent)
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_acceptsFirstMouse_, paramNSEvent != null ? paramNSEvent.id : 0L);
  }
  
  public void addSubview(NSView paramNSView)
  {
    OS.objc_msgSend(this.id, OS.sel_addSubview_, paramNSView != null ? paramNSView.id : 0L);
  }
  
  public void addSubview(NSView paramNSView1, long paramLong, NSView paramNSView2)
  {
    OS.objc_msgSend(this.id, OS.sel_addSubview_positioned_relativeTo_, paramNSView1 != null ? paramNSView1.id : 0L, paramLong, paramNSView2 != null ? paramNSView2.id : 0L);
  }
  
  public long addToolTipRect(NSRect paramNSRect, id paramid, long paramLong)
  {
    return OS.objc_msgSend(this.id, OS.sel_addToolTipRect_owner_userData_, paramNSRect, paramid != null ? paramid.id : 0L, paramLong);
  }
  
  public void beginDocument()
  {
    OS.objc_msgSend(this.id, OS.sel_beginDocument);
  }
  
  public void beginPageInRect(NSRect paramNSRect, NSPoint paramNSPoint)
  {
    OS.objc_msgSend(this.id, OS.sel_beginPageInRect_atPlacement_, paramNSRect, paramNSPoint);
  }
  
  public NSRect bounds()
  {
    NSRect localNSRect = new NSRect();
    OS.objc_msgSend_stret(localNSRect, this.id, OS.sel_bounds);
    return localNSRect;
  }
  
  public boolean canBecomeKeyView()
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_canBecomeKeyView);
  }
  
  public NSPoint convertPoint_fromView_(NSPoint paramNSPoint, NSView paramNSView)
  {
    NSPoint localNSPoint = new NSPoint();
    OS.objc_msgSend_stret(localNSPoint, this.id, OS.sel_convertPoint_fromView_, paramNSPoint, paramNSView != null ? paramNSView.id : 0L);
    return localNSPoint;
  }
  
  public NSPoint convertPoint_toView_(NSPoint paramNSPoint, NSView paramNSView)
  {
    NSPoint localNSPoint = new NSPoint();
    OS.objc_msgSend_stret(localNSPoint, this.id, OS.sel_convertPoint_toView_, paramNSPoint, paramNSView != null ? paramNSView.id : 0L);
    return localNSPoint;
  }
  
  public NSPoint convertPointFromBase(NSPoint paramNSPoint)
  {
    NSPoint localNSPoint = new NSPoint();
    OS.objc_msgSend_stret(localNSPoint, this.id, OS.sel_convertPointFromBase_, paramNSPoint);
    return localNSPoint;
  }
  
  public NSPoint convertPointToBase(NSPoint paramNSPoint)
  {
    NSPoint localNSPoint = new NSPoint();
    OS.objc_msgSend_stret(localNSPoint, this.id, OS.sel_convertPointToBase_, paramNSPoint);
    return localNSPoint;
  }
  
  public NSRect convertRect_fromView_(NSRect paramNSRect, NSView paramNSView)
  {
    NSRect localNSRect = new NSRect();
    OS.objc_msgSend_stret(localNSRect, this.id, OS.sel_convertRect_fromView_, paramNSRect, paramNSView != null ? paramNSView.id : 0L);
    return localNSRect;
  }
  
  public NSRect convertRect_toView_(NSRect paramNSRect, NSView paramNSView)
  {
    NSRect localNSRect = new NSRect();
    OS.objc_msgSend_stret(localNSRect, this.id, OS.sel_convertRect_toView_, paramNSRect, paramNSView != null ? paramNSView.id : 0L);
    return localNSRect;
  }
  
  public NSRect convertRectFromBase(NSRect paramNSRect)
  {
    NSRect localNSRect = new NSRect();
    OS.objc_msgSend_stret(localNSRect, this.id, OS.sel_convertRectFromBase_, paramNSRect);
    return localNSRect;
  }
  
  public NSRect convertRectToBase(NSRect paramNSRect)
  {
    NSRect localNSRect = new NSRect();
    OS.objc_msgSend_stret(localNSRect, this.id, OS.sel_convertRectToBase_, paramNSRect);
    return localNSRect;
  }
  
  public NSSize convertSize_fromView_(NSSize paramNSSize, NSView paramNSView)
  {
    NSSize localNSSize = new NSSize();
    OS.objc_msgSend_stret(localNSSize, this.id, OS.sel_convertSize_fromView_, paramNSSize, paramNSView != null ? paramNSView.id : 0L);
    return localNSSize;
  }
  
  public NSSize convertSize_toView_(NSSize paramNSSize, NSView paramNSView)
  {
    NSSize localNSSize = new NSSize();
    OS.objc_msgSend_stret(localNSSize, this.id, OS.sel_convertSize_toView_, paramNSSize, paramNSView != null ? paramNSView.id : 0L);
    return localNSSize;
  }
  
  public NSSize convertSizeFromBase(NSSize paramNSSize)
  {
    NSSize localNSSize = new NSSize();
    OS.objc_msgSend_stret(localNSSize, this.id, OS.sel_convertSizeFromBase_, paramNSSize);
    return localNSSize;
  }
  
  public NSSize convertSizeToBase(NSSize paramNSSize)
  {
    NSSize localNSSize = new NSSize();
    OS.objc_msgSend_stret(localNSSize, this.id, OS.sel_convertSizeToBase_, paramNSSize);
    return localNSSize;
  }
  
  public void discardCursorRects()
  {
    OS.objc_msgSend(this.id, OS.sel_discardCursorRects);
  }
  
  public void display()
  {
    OS.objc_msgSend(this.id, OS.sel_display);
  }
  
  public void displayIfNeeded()
  {
    OS.objc_msgSend(this.id, OS.sel_displayIfNeeded);
  }
  
  public void displayRectIgnoringOpacity(NSRect paramNSRect, NSGraphicsContext paramNSGraphicsContext)
  {
    OS.objc_msgSend(this.id, OS.sel_displayRectIgnoringOpacity_inContext_, paramNSRect, paramNSGraphicsContext != null ? paramNSGraphicsContext.id : 0L);
  }
  
  public void dragImage(NSImage paramNSImage, NSPoint paramNSPoint, NSSize paramNSSize, NSEvent paramNSEvent, NSPasteboard paramNSPasteboard, id paramid, boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_dragImage_at_offset_event_pasteboard_source_slideBack_, paramNSImage != null ? paramNSImage.id : 0L, paramNSPoint, paramNSSize, paramNSEvent != null ? paramNSEvent.id : 0L, paramNSPasteboard != null ? paramNSPasteboard.id : 0L, paramid != null ? paramid.id : 0L, paramBoolean);
  }
  
  public void drawRect(NSRect paramNSRect)
  {
    OS.objc_msgSend(this.id, OS.sel_drawRect_, paramNSRect);
  }
  
  public void endDocument()
  {
    OS.objc_msgSend(this.id, OS.sel_endDocument);
  }
  
  public void endPage()
  {
    OS.objc_msgSend(this.id, OS.sel_endPage);
  }
  
  public NSRect frame()
  {
    NSRect localNSRect = new NSRect();
    OS.objc_msgSend_stret(localNSRect, this.id, OS.sel_frame);
    return localNSRect;
  }
  
  public NSView hitTest(NSPoint paramNSPoint)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_hitTest_, paramNSPoint);
    return l != 0L ? new NSView(l) : l == this.id ? this : null;
  }
  
  public NSView initWithFrame(NSRect paramNSRect)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_initWithFrame_, paramNSRect);
    return l != 0L ? new NSView(l) : l == this.id ? this : null;
  }
  
  public boolean isDescendantOf(NSView paramNSView)
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_isDescendantOf_, paramNSView != null ? paramNSView.id : 0L);
  }
  
  public boolean isFlipped()
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_isFlipped);
  }
  
  public boolean isHidden()
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_isHidden);
  }
  
  public boolean isHiddenOrHasHiddenAncestor()
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_isHiddenOrHasHiddenAncestor);
  }
  
  public boolean isOpaque()
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_isOpaque);
  }
  
  public void lockFocus()
  {
    OS.objc_msgSend(this.id, OS.sel_lockFocus);
  }
  
  public NSMenu menuForEvent(NSEvent paramNSEvent)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_menuForEvent_, paramNSEvent != null ? paramNSEvent.id : 0L);
    return l != 0L ? new NSMenu(l) : null;
  }
  
  public boolean mouse(NSPoint paramNSPoint, NSRect paramNSRect)
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_mouse_inRect_, paramNSPoint, paramNSRect);
  }
  
  public boolean mouseDownCanMoveWindow()
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_mouseDownCanMoveWindow);
  }
  
  public boolean needsPanelToBecomeKey()
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_needsPanelToBecomeKey);
  }
  
  public void registerForDraggedTypes(NSArray paramNSArray)
  {
    OS.objc_msgSend(this.id, OS.sel_registerForDraggedTypes_, paramNSArray != null ? paramNSArray.id : 0L);
  }
  
  public void removeFromSuperview()
  {
    OS.objc_msgSend(this.id, OS.sel_removeFromSuperview);
  }
  
  public void removeToolTip(long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_removeToolTip_, paramLong);
  }
  
  public void removeTrackingArea(NSTrackingArea paramNSTrackingArea)
  {
    OS.objc_msgSend(this.id, OS.sel_removeTrackingArea_, paramNSTrackingArea != null ? paramNSTrackingArea.id : 0L);
  }
  
  public void resetCursorRects()
  {
    OS.objc_msgSend(this.id, OS.sel_resetCursorRects);
  }
  
  public void scrollClipView(NSClipView paramNSClipView, NSPoint paramNSPoint)
  {
    OS.objc_msgSend(this.id, OS.sel_scrollClipView_toPoint_, paramNSClipView != null ? paramNSClipView.id : 0L, paramNSPoint);
  }
  
  public void scrollPoint(NSPoint paramNSPoint)
  {
    OS.objc_msgSend(this.id, OS.sel_scrollPoint_, paramNSPoint);
  }
  
  public boolean scrollRectToVisible(NSRect paramNSRect)
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_scrollRectToVisible_, paramNSRect);
  }
  
  public void setAcceptsTouchEvents(boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_setAcceptsTouchEvents_, paramBoolean);
  }
  
  public void setAutoresizesSubviews(boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_setAutoresizesSubviews_, paramBoolean);
  }
  
  public void setAutoresizingMask(long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_setAutoresizingMask_, paramLong);
  }
  
  public void setBoundsRotation(double paramDouble)
  {
    OS.objc_msgSend(this.id, OS.sel_setBoundsRotation_, paramDouble);
  }
  
  public void setFocusRingType(long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_setFocusRingType_, paramLong);
  }
  
  public void setFrame(NSRect paramNSRect)
  {
    OS.objc_msgSend(this.id, OS.sel_setFrame_, paramNSRect);
  }
  
  public void setFrameOrigin(NSPoint paramNSPoint)
  {
    OS.objc_msgSend(this.id, OS.sel_setFrameOrigin_, paramNSPoint);
  }
  
  public void setFrameSize(NSSize paramNSSize)
  {
    OS.objc_msgSend(this.id, OS.sel_setFrameSize_, paramNSSize);
  }
  
  public void setHidden(boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_setHidden_, paramBoolean);
  }
  
  public void setNeedsDisplay(boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_setNeedsDisplay_, paramBoolean);
  }
  
  public void setNeedsDisplayInRect(NSRect paramNSRect)
  {
    OS.objc_msgSend(this.id, OS.sel_setNeedsDisplayInRect_, paramNSRect);
  }
  
  public void setToolTip(NSString paramNSString)
  {
    OS.objc_msgSend(this.id, OS.sel_setToolTip_, paramNSString != null ? paramNSString.id : 0L);
  }
  
  public void setWantsRestingTouches(boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_setWantsRestingTouches_, paramBoolean);
  }
  
  public boolean shouldDelayWindowOrderingForEvent(NSEvent paramNSEvent)
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_shouldDelayWindowOrderingForEvent_, paramNSEvent != null ? paramNSEvent.id : 0L);
  }
  
  public NSArray subviews()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_subviews);
    return l != 0L ? new NSArray(l) : null;
  }
  
  public NSView superview()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_superview);
    return l != 0L ? new NSView(l) : l == this.id ? this : null;
  }
  
  public NSArray trackingAreas()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_trackingAreas);
    return l != 0L ? new NSArray(l) : null;
  }
  
  public void unlockFocus()
  {
    OS.objc_msgSend(this.id, OS.sel_unlockFocus);
  }
  
  public void unregisterDraggedTypes()
  {
    OS.objc_msgSend(this.id, OS.sel_unregisterDraggedTypes);
  }
  
  public void updateTrackingAreas()
  {
    OS.objc_msgSend(this.id, OS.sel_updateTrackingAreas);
  }
  
  public void viewDidMoveToWindow()
  {
    OS.objc_msgSend(this.id, OS.sel_viewDidMoveToWindow);
  }
  
  public void viewWillMoveToWindow(NSWindow paramNSWindow)
  {
    OS.objc_msgSend(this.id, OS.sel_viewWillMoveToWindow_, paramNSWindow != null ? paramNSWindow.id : 0L);
  }
  
  public NSRect visibleRect()
  {
    NSRect localNSRect = new NSRect();
    OS.objc_msgSend_stret(localNSRect, this.id, OS.sel_visibleRect);
    return localNSRect;
  }
  
  public NSWindow window()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_window);
    return l != 0L ? new NSWindow(l) : null;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSView.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */