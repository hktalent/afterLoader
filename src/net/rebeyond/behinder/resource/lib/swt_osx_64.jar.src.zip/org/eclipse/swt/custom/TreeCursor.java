package org.eclipse.swt.custom;

import org.eclipse.swt.SWT;
import org.eclipse.swt.accessibility.Accessible;
import org.eclipse.swt.accessibility.AccessibleAdapter;
import org.eclipse.swt.accessibility.AccessibleControlAdapter;
import org.eclipse.swt.accessibility.AccessibleControlEvent;
import org.eclipse.swt.accessibility.AccessibleEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Canvas;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.ScrollBar;
import org.eclipse.swt.widgets.Tree;
import org.eclipse.swt.widgets.TreeColumn;
import org.eclipse.swt.widgets.TreeItem;
import org.eclipse.swt.widgets.TypedListener;

public class TreeCursor
  extends Canvas
{
  Tree tree;
  TreeItem row;
  TreeColumn column;
  Listener listener;
  Listener treeListener;
  Listener resizeListener;
  Listener disposeItemListener;
  Listener disposeColumnListener;
  Color background = null;
  Color foreground = null;
  static final int BACKGROUND = 27;
  static final int FOREGROUND = 26;
  
  public TreeCursor(Tree paramTree, int paramInt)
  {
    super(paramTree, paramInt);
    this.tree = paramTree;
    setBackground(null);
    setForeground(null);
    this.listener = new Listener()
    {
      public void handleEvent(Event paramAnonymousEvent)
      {
        if (TreeCursor.this.row != null)
        {
          if (TreeCursor.this.row.isDisposed())
          {
            TreeCursor.this.unhookRowColumnListeners();
            TreeCursor.this._resize();
            TreeCursor.this.tree.setFocus();
            return;
          }
          Object localObject = TreeCursor.this.row;
          for (TreeItem localTreeItem = TreeCursor.this.row.getParentItem(); (localTreeItem != null) && (!localTreeItem.getExpanded()); localTreeItem = ((TreeItem)localObject).getParentItem()) {
            localObject = localTreeItem;
          }
          if (localObject != TreeCursor.this.row) {
            TreeCursor.this.setRowColumn((TreeItem)localObject, TreeCursor.this.column, false);
          }
        }
        switch (paramAnonymousEvent.type)
        {
        case 12: 
          TreeCursor.this.onDispose(paramAnonymousEvent);
          break;
        case 15: 
        case 16: 
          TreeCursor.this.redraw();
          break;
        case 1: 
          TreeCursor.this.keyDown(paramAnonymousEvent);
          break;
        case 9: 
          TreeCursor.this.paint(paramAnonymousEvent);
          break;
        case 31: 
          paramAnonymousEvent.doit = true;
          switch (paramAnonymousEvent.detail)
          {
          case 4: 
          case 32: 
          case 64: 
            paramAnonymousEvent.doit = false;
          }
          break;
        }
      }
    };
    int[] arrayOfInt = { 12, 15, 16, 1, 9, 31 };
    for (int i = 0; i < arrayOfInt.length; i++) {
      addListener(arrayOfInt[i], this.listener);
    }
    this.treeListener = new Listener()
    {
      public void handleEvent(Event paramAnonymousEvent)
      {
        switch (paramAnonymousEvent.type)
        {
        case 18: 
          TreeCursor.this.treeCollapse(paramAnonymousEvent);
          break;
        case 17: 
          TreeCursor.this.treeExpand(paramAnonymousEvent);
          break;
        case 15: 
          TreeCursor.this.treeFocusIn(paramAnonymousEvent);
          break;
        case 3: 
          TreeCursor.this.treeMouseDown(paramAnonymousEvent);
        }
      }
    };
    this.tree.addListener(18, this.treeListener);
    this.tree.addListener(17, this.treeListener);
    this.tree.addListener(15, this.treeListener);
    this.tree.addListener(3, this.treeListener);
    this.disposeItemListener = new Listener()
    {
      public void handleEvent(Event paramAnonymousEvent)
      {
        for (TreeItem localTreeItem1 = TreeCursor.this.row; localTreeItem1 != null; localTreeItem1 = localTreeItem1.getParentItem()) {
          localTreeItem1.removeListener(12, TreeCursor.this.disposeItemListener);
        }
        TreeItem localTreeItem2 = (TreeItem)paramAnonymousEvent.widget;
        TreeItem localTreeItem3 = localTreeItem2.getParentItem();
        if (localTreeItem3 != null)
        {
          TreeCursor.this.setRowColumn(localTreeItem3, TreeCursor.this.column, true);
        }
        else if (TreeCursor.this.tree.getItemCount() == 1)
        {
          TreeCursor.this.unhookRowColumnListeners();
        }
        else
        {
          Object localObject = null;
          int i = TreeCursor.this.tree.indexOf(localTreeItem2);
          TreeItem localTreeItem4;
          if (i != 0)
          {
            localTreeItem4 = TreeCursor.this.tree.getItem(i - 1);
            if (!localTreeItem4.isDisposed()) {
              localObject = localTreeItem4;
            }
          }
          if ((localObject == null) && (i + 1 < TreeCursor.this.tree.getItemCount()))
          {
            localTreeItem4 = TreeCursor.this.tree.getItem(i + 1);
            if (!localTreeItem4.isDisposed()) {
              localObject = localTreeItem4;
            }
          }
          if (localObject != null) {
            TreeCursor.this.setRowColumn((TreeItem)localObject, TreeCursor.this.column, true);
          } else {
            TreeCursor.this.unhookRowColumnListeners();
          }
        }
        TreeCursor.this._resize();
      }
    };
    this.disposeColumnListener = new Listener()
    {
      public void handleEvent(Event paramAnonymousEvent)
      {
        if (TreeCursor.this.column != null) {
          if (TreeCursor.this.tree.getColumnCount() == 1)
          {
            TreeCursor.this.column = null;
          }
          else
          {
            int i = TreeCursor.this.tree.indexOf(TreeCursor.this.column);
            int j = i;
            int[] arrayOfInt = TreeCursor.this.tree.getColumnOrder();
            for (int k = 0; k < arrayOfInt.length; k++) {
              if (arrayOfInt[k] == i)
              {
                j = k;
                break;
              }
            }
            if (j == arrayOfInt.length - 1) {
              TreeCursor.this.setRowColumn(TreeCursor.this.row, TreeCursor.this.tree.getColumn(arrayOfInt[(j - 1)]), true);
            } else {
              TreeCursor.this.setRowColumn(TreeCursor.this.row, TreeCursor.this.tree.getColumn(arrayOfInt[(j + 1)]), true);
            }
          }
        }
        TreeCursor.this._resize();
      }
    };
    this.resizeListener = new Listener()
    {
      public void handleEvent(Event paramAnonymousEvent)
      {
        TreeCursor.this._resize();
      }
    };
    ScrollBar localScrollBar1 = this.tree.getHorizontalBar();
    if (localScrollBar1 != null) {
      localScrollBar1.addListener(13, this.resizeListener);
    }
    ScrollBar localScrollBar2 = this.tree.getVerticalBar();
    if (localScrollBar2 != null) {
      localScrollBar2.addListener(13, this.resizeListener);
    }
    getAccessible().addAccessibleControlListener(new AccessibleControlAdapter()
    {
      public void getRole(AccessibleControlEvent paramAnonymousAccessibleControlEvent)
      {
        paramAnonymousAccessibleControlEvent.detail = 29;
      }
    });
    getAccessible().addAccessibleListener(new AccessibleAdapter()
    {
      public void getName(AccessibleEvent paramAnonymousAccessibleEvent)
      {
        if (TreeCursor.this.row == null) {
          return;
        }
        int i = TreeCursor.this.column == null ? 0 : TreeCursor.this.tree.indexOf(TreeCursor.this.column);
        paramAnonymousAccessibleEvent.result = TreeCursor.this.row.getText(i);
      }
    });
  }
  
  public void addSelectionListener(SelectionListener paramSelectionListener)
  {
    checkWidget();
    if (paramSelectionListener == null) {
      SWT.error(4);
    }
    TypedListener localTypedListener = new TypedListener(paramSelectionListener);
    addListener(13, localTypedListener);
    addListener(14, localTypedListener);
  }
  
  int countSubTreePages(TreeItem paramTreeItem)
  {
    int i = 1;
    if (paramTreeItem == null) {
      return 0;
    }
    if (paramTreeItem.getItemCount() == 0) {
      return 1;
    }
    if (!paramTreeItem.getExpanded()) {
      return 1;
    }
    TreeItem[] arrayOfTreeItem = paramTreeItem.getItems();
    for (int j = 0; j < arrayOfTreeItem.length; j++) {
      i += countSubTreePages(arrayOfTreeItem[j]);
    }
    return i;
  }
  
  int findIndex(TreeItem[] paramArrayOfTreeItem, TreeItem paramTreeItem)
  {
    if ((paramArrayOfTreeItem == null) || (paramTreeItem == null)) {
      return -1;
    }
    Rectangle localRectangle1 = paramTreeItem.getBounds();
    int i = 0;
    for (int j = 0; j < paramArrayOfTreeItem.length; j++)
    {
      TreeItem localTreeItem1 = null;
      TreeItem localTreeItem2 = paramArrayOfTreeItem[j];
      if (j > 0) {
        localTreeItem1 = paramArrayOfTreeItem[(j - 1)];
      }
      Rectangle localRectangle2 = localTreeItem2.getBounds();
      if (localRectangle1.y == localRectangle2.y) {
        return i;
      }
      if (localRectangle1.y < localRectangle2.y) {
        return i - 1 + findIndex(localTreeItem1.getItems(), paramTreeItem);
      }
      if ((localRectangle1.y > localRectangle2.y) && (j == paramArrayOfTreeItem.length - 1)) {
        return i + findIndex(localTreeItem2.getItems(), paramTreeItem);
      }
      if ((localRectangle1.y >= localRectangle2.y + (1 + localTreeItem2.getItemCount()) * this.tree.getItemHeight()) && (localTreeItem2.getExpanded())) {
        i += countSubTreePages(localTreeItem2);
      } else {
        i++;
      }
    }
    return -1;
  }
  
  TreeItem findItem(TreeItem[] paramArrayOfTreeItem, Point paramPoint)
  {
    int i = 0;
    int j = paramArrayOfTreeItem.length - 1;
    int k = j / 2;
    while (j - i > 1)
    {
      localObject1 = paramArrayOfTreeItem[k];
      localObject2 = ((TreeItem)localObject1).getBounds();
      if (paramPoint.y < ((Rectangle)localObject2).y)
      {
        j = k;
        k = (j - i) / 2;
      }
      else
      {
        i = k;
        k = i + (j - i) / 2;
      }
    }
    Object localObject1 = paramArrayOfTreeItem[j].getBounds();
    Rectangle localRectangle2;
    if (((Rectangle)localObject1).y < paramPoint.y)
    {
      if (((Rectangle)localObject1).y + ((Rectangle)localObject1).height < paramPoint.y)
      {
        if (!paramArrayOfTreeItem[j].getExpanded()) {
          return null;
        }
        return findItem(paramArrayOfTreeItem[j].getItems(), paramPoint);
      }
      localObject2 = this.tree.getColumnOrder();
      localObject3 = null;
      if (localObject2.length > 0)
      {
        localRectangle1 = paramArrayOfTreeItem[j].getBounds(localObject2[0]);
        localRectangle2 = paramArrayOfTreeItem[j].getBounds(localObject2[(localObject2.length - 1)]);
        localObject3 = localRectangle1.union(localRectangle2);
        localObject3.height += (this.tree.getLinesVisible() ? this.tree.getGridLineWidth() : 0);
      }
      else
      {
        localObject3 = paramArrayOfTreeItem[j].getBounds();
      }
      return ((Rectangle)localObject3).contains(paramPoint) ? paramArrayOfTreeItem[j] : null;
    }
    Object localObject2 = paramArrayOfTreeItem[i].getBounds();
    if (((Rectangle)localObject2).y + ((Rectangle)localObject2).height < paramPoint.y) {
      return findItem(paramArrayOfTreeItem[i].getItems(), paramPoint);
    }
    Object localObject3 = this.tree.getColumnOrder();
    Rectangle localRectangle1 = null;
    if (localObject3.length > 0)
    {
      localRectangle2 = paramArrayOfTreeItem[i].getBounds(localObject3[0]);
      Rectangle localRectangle3 = paramArrayOfTreeItem[i].getBounds(localObject3[(localObject3.length - 1)]);
      localRectangle1 = localRectangle2.union(localRectangle3);
      localRectangle1.height += (this.tree.getLinesVisible() ? this.tree.getGridLineWidth() : 0);
    }
    else
    {
      localRectangle1 = paramArrayOfTreeItem[i].getBounds();
    }
    return localRectangle1.contains(paramPoint) ? paramArrayOfTreeItem[i] : null;
  }
  
  public Color getBackground()
  {
    checkWidget();
    if (this.background == null) {
      return getDisplay().getSystemColor(27);
    }
    return this.background;
  }
  
  public int getColumn()
  {
    checkWidget();
    return this.column == null ? 0 : this.tree.indexOf(this.column);
  }
  
  public Color getForeground()
  {
    checkWidget();
    if (this.foreground == null) {
      return getDisplay().getSystemColor(26);
    }
    return this.foreground;
  }
  
  TreeItem getLastVisibleItem(TreeItem[] paramArrayOfTreeItem)
  {
    if (paramArrayOfTreeItem == null) {
      return null;
    }
    TreeItem localTreeItem = paramArrayOfTreeItem[(paramArrayOfTreeItem.length - 1)];
    if ((localTreeItem.getExpanded()) && (localTreeItem.getItemCount() > 0)) {
      return getLastVisibleItem(localTreeItem.getItems());
    }
    return localTreeItem;
  }
  
  TreeItem getNextItem(TreeItem paramTreeItem)
  {
    if (paramTreeItem == null) {
      return null;
    }
    if ((paramTreeItem.getExpanded()) && (paramTreeItem.getItemCount() > 0)) {
      return paramTreeItem.getItem(0);
    }
    for (TreeItem localTreeItem = paramTreeItem.getParentItem(); localTreeItem != null; localTreeItem = paramTreeItem.getParentItem())
    {
      i = localTreeItem.indexOf(paramTreeItem);
      if (i == -1) {
        return null;
      }
      if (i < localTreeItem.getItemCount() - 1) {
        return localTreeItem.getItem(i + 1);
      }
      paramTreeItem = localTreeItem;
    }
    int i = this.tree.indexOf(paramTreeItem);
    if (i == -1) {
      return null;
    }
    if (i == this.tree.getItemCount() - 1) {
      return null;
    }
    return this.tree.getItem(i + 1);
  }
  
  TreeItem getPreviousItem(TreeItem paramTreeItem)
  {
    if (paramTreeItem == null) {
      return null;
    }
    TreeItem localTreeItem = paramTreeItem.getParentItem();
    if (localTreeItem == null)
    {
      i = this.tree.indexOf(paramTreeItem);
      if ((i == -1) || (i == 0)) {
        return null;
      }
      paramTreeItem = this.tree.getItem(i - 1);
      if ((paramTreeItem.getExpanded()) && (paramTreeItem.getItemCount() > 0)) {
        return getLastVisibleItem(paramTreeItem.getItems());
      }
      return paramTreeItem;
    }
    int i = localTreeItem.indexOf(paramTreeItem);
    if (i == -1) {
      return null;
    }
    if (i == 0) {
      return localTreeItem;
    }
    paramTreeItem = localTreeItem.getItem(i - 1);
    if ((paramTreeItem.getExpanded()) && (paramTreeItem.getItemCount() > 0)) {
      return getLastVisibleItem(paramTreeItem.getItems());
    }
    return paramTreeItem;
  }
  
  public TreeItem getRow()
  {
    checkWidget();
    return this.row;
  }
  
  void keyDown(Event paramEvent)
  {
    if (this.row == null) {
      return;
    }
    switch (paramEvent.character)
    {
    case '\r': 
      notifyListeners(14, new Event());
      return;
    }
    int i;
    Object localObject2;
    int m;
    int i1;
    Object localObject1;
    TreeItem localTreeItem3;
    int n;
    int i2;
    switch (paramEvent.keyCode)
    {
    case 16777217: 
      TreeItem localTreeItem1 = getPreviousItem(this.row);
      if (localTreeItem1 != null) {
        setRowColumn(localTreeItem1, this.column, true);
      }
      break;
    case 16777218: 
      TreeItem localTreeItem2 = getNextItem(this.row);
      if (localTreeItem2 != null) {
        setRowColumn(localTreeItem2, this.column, true);
      }
      break;
    case 16777219: 
    case 16777220: 
      if ((paramEvent.stateMask & SWT.MOD1) != 0)
      {
        this.row.setExpanded(paramEvent.keyCode == 16777220);
      }
      else
      {
        i = this.tree.getColumnCount();
        if (i != 0)
        {
          int j = this.column == null ? 0 : this.tree.indexOf(this.column);
          localObject2 = this.tree.getColumnOrder();
          for (int k = 0; (k < localObject2.length) && (localObject2[k] != j); k++) {}
          if (k == localObject2.length) {
            k = 0;
          }
          m = (getStyle() & 0x4000000) != 0 ? 16777220 : 16777219;
          TreeItem localTreeItem4 = this.row.getParentItem();
          i1 = this.tree.indexOf(this.row);
          if (paramEvent.keyCode == m)
          {
            if (localTreeItem4 != null) {
              setRowColumn(this.row, this.tree.getColumn(localObject2[Math.max(0, k - 1)]), true);
            } else {
              setRowColumn(i1, localObject2[Math.max(0, k - 1)], true);
            }
          }
          else if (localTreeItem4 != null) {
            setRowColumn(this.row, this.tree.getColumn(localObject2[Math.min(i - 1, k + 1)]), true);
          } else {
            setRowColumn(i1, localObject2[Math.min(i - 1, k + 1)], true);
          }
        }
      }
      break;
    case 16777223: 
      i = this.column == null ? 0 : this.tree.indexOf(this.column);
      setRowColumn(0, i, true);
      break;
    case 16777224: 
      localObject1 = this.tree.getItems();
      setRowColumn(getLastVisibleItem((TreeItem[])localObject1), this.column, true);
      break;
    case 16777221: 
      localObject1 = this.tree.getClientArea();
      localObject2 = this.tree.getTopItem().getBounds();
      localTreeItem3 = this.row;
      m = findIndex(this.tree.getItems(), localTreeItem3);
      n = this.tree.getItemHeight();
      localObject1.height -= ((Rectangle)localObject2).y;
      i1 = Math.max(1, ((Rectangle)localObject1).height / n);
      if (m - i1 <= 0)
      {
        TreeItem localTreeItem6 = this.tree.getItem(0);
        setRowColumn(localTreeItem6, this.column, true);
      }
      else
      {
        for (i2 = 0; i2 < i1; i2++) {
          localTreeItem3 = getPreviousItem(localTreeItem3);
        }
        setRowColumn(localTreeItem3, this.column, true);
      }
      break;
    case 16777222: 
      localObject1 = this.tree.getClientArea();
      localObject2 = this.tree.getTopItem().getBounds();
      localTreeItem3 = this.row;
      m = findIndex(this.tree.getItems(), localTreeItem3);
      n = this.tree.getItemHeight();
      localObject1.height -= ((Rectangle)localObject2).y;
      TreeItem localTreeItem5 = getLastVisibleItem(this.tree.getItems());
      i2 = Math.max(1, ((Rectangle)localObject1).height / n);
      int i3 = findIndex(this.tree.getItems(), localTreeItem5);
      if (i3 <= m + i2)
      {
        setRowColumn(localTreeItem5, this.column, true);
      }
      else
      {
        for (int i4 = 0; i4 < i2; i4++) {
          localTreeItem3 = getNextItem(localTreeItem3);
        }
        setRowColumn(localTreeItem3, this.column, true);
      }
      break;
    }
  }
  
  void onDispose(Event paramEvent)
  {
    removeListener(12, this.listener);
    notifyListeners(12, paramEvent);
    paramEvent.type = 0;
    this.tree.removeListener(18, this.treeListener);
    this.tree.removeListener(17, this.treeListener);
    this.tree.removeListener(15, this.treeListener);
    this.tree.removeListener(3, this.treeListener);
    unhookRowColumnListeners();
    ScrollBar localScrollBar1 = this.tree.getHorizontalBar();
    if (localScrollBar1 != null) {
      localScrollBar1.removeListener(13, this.resizeListener);
    }
    ScrollBar localScrollBar2 = this.tree.getVerticalBar();
    if (localScrollBar2 != null) {
      localScrollBar2.removeListener(13, this.resizeListener);
    }
  }
  
  void paint(Event paramEvent)
  {
    if (this.row == null) {
      return;
    }
    int i = this.column == null ? 0 : this.tree.indexOf(this.column);
    int j = i;
    int[] arrayOfInt = this.tree.getColumnOrder();
    for (int k = 0; k < arrayOfInt.length; k++) {
      if (arrayOfInt[k] == i)
      {
        j = k;
        break;
      }
    }
    GC localGC = paramEvent.gc;
    localGC.setBackground(getBackground());
    localGC.setForeground(getForeground());
    localGC.fillRectangle(paramEvent.x, paramEvent.y, paramEvent.width, paramEvent.height);
    Image localImage = this.row.getImage(i);
    int m = 0;
    String str = SWT.getPlatform();
    if (localImage != null) {
      if ("win32".equals(str))
      {
        if (j > 0) {
          m += 2;
        }
      }
      else {
        m += 2;
      }
    }
    Point localPoint1 = getSize();
    if (localImage != null)
    {
      localObject1 = localImage.getBounds();
      int n = (localPoint1.y - ((Rectangle)localObject1).height) / 2;
      localGC.drawImage(localImage, m, n);
      m += ((Rectangle)localObject1).width;
    }
    Object localObject1 = this.row.getText(i);
    Object localObject2;
    if (((String)localObject1).length() > 0)
    {
      localObject2 = this.row.getBounds(i);
      Point localPoint2 = localGC.stringExtent((String)localObject1);
      if ("win32".equals(str))
      {
        if ((this.tree.getColumnCount() == 0) || (j == 0))
        {
          m += (localImage == null ? 2 : 5);
        }
        else
        {
          i1 = this.column.getAlignment();
          switch (i1)
          {
          case 16384: 
            m += (localImage == null ? 5 : 3);
            break;
          case 131072: 
            m = ((Rectangle)localObject2).width - localPoint2.x - 2;
            break;
          case 16777216: 
            m = (int)(m + Math.ceil((((Rectangle)localObject2).width - m - localPoint2.x) / 2.0D));
          }
        }
      }
      else if (this.tree.getColumnCount() == 0)
      {
        m += (localImage == null ? 4 : 3);
      }
      else
      {
        i1 = this.column.getAlignment();
        switch (i1)
        {
        case 16384: 
          m += (localImage == null ? 5 : 3);
          break;
        case 131072: 
          m = ((Rectangle)localObject2).width - localPoint2.x - 2;
          break;
        case 16777216: 
          m += (((Rectangle)localObject2).width - m - localPoint2.x) / 2 + 2;
        }
      }
      int i1 = (localPoint1.y - localPoint2.y) / 2;
      localGC.drawString((String)localObject1, m, i1);
    }
    if (isFocusControl())
    {
      localObject2 = getDisplay();
      localGC.setBackground(((Display)localObject2).getSystemColor(2));
      localGC.setForeground(((Display)localObject2).getSystemColor(1));
      localGC.drawFocus(0, 0, localPoint1.x, localPoint1.y);
    }
  }
  
  public void removeSelectionListener(SelectionListener paramSelectionListener)
  {
    checkWidget();
    if (paramSelectionListener == null) {
      SWT.error(4);
    }
    removeListener(13, paramSelectionListener);
    removeListener(14, paramSelectionListener);
  }
  
  void _resize()
  {
    if (this.row == null)
    {
      setBounds(65336, 65336, 0, 0);
    }
    else
    {
      int i = this.column == null ? 0 : this.tree.indexOf(this.column);
      setBounds(this.row.getBounds(i));
    }
  }
  
  public void setBackground(Color paramColor)
  {
    this.background = paramColor;
    super.setBackground(getBackground());
    redraw();
  }
  
  public void setForeground(Color paramColor)
  {
    this.foreground = paramColor;
    super.setForeground(getForeground());
    redraw();
  }
  
  void setRowColumn(int paramInt1, int paramInt2, boolean paramBoolean)
  {
    TreeItem localTreeItem = paramInt1 == -1 ? null : this.tree.getItem(paramInt1);
    TreeColumn localTreeColumn = (paramInt2 == -1) || (this.tree.getColumnCount() == 0) ? null : this.tree.getColumn(paramInt2);
    setRowColumn(localTreeItem, localTreeColumn, paramBoolean);
  }
  
  void setRowColumn(TreeItem paramTreeItem, TreeColumn paramTreeColumn, boolean paramBoolean)
  {
    TreeItem localTreeItem;
    if ((this.row != null) && (this.row != paramTreeItem))
    {
      for (localTreeItem = this.row; localTreeItem != null; localTreeItem = localTreeItem.getParentItem()) {
        localTreeItem.removeListener(12, this.disposeItemListener);
      }
      this.row = null;
    }
    if ((this.column != null) && (this.column != paramTreeColumn))
    {
      this.column.removeListener(12, this.disposeColumnListener);
      this.column.removeListener(10, this.resizeListener);
      this.column.removeListener(11, this.resizeListener);
      this.column = null;
    }
    if (paramTreeItem != null)
    {
      if (this.row != paramTreeItem)
      {
        this.row = paramTreeItem;
        for (localTreeItem = paramTreeItem; localTreeItem != null; localTreeItem = localTreeItem.getParentItem()) {
          localTreeItem.addListener(12, this.disposeItemListener);
        }
        this.tree.showItem(paramTreeItem);
      }
      if ((this.column != paramTreeColumn) && (paramTreeColumn != null))
      {
        this.column = paramTreeColumn;
        paramTreeColumn.addListener(12, this.disposeColumnListener);
        paramTreeColumn.addListener(10, this.resizeListener);
        paramTreeColumn.addListener(11, this.resizeListener);
        this.tree.showColumn(paramTreeColumn);
      }
      int i = paramTreeColumn == null ? 0 : this.tree.indexOf(paramTreeColumn);
      setBounds(paramTreeItem.getBounds(i));
      redraw();
      if (paramBoolean) {
        notifyListeners(13, new Event());
      }
    }
  }
  
  public void setSelection(int paramInt1, int paramInt2)
  {
    checkWidget();
    int i = this.tree.getColumnCount();
    int j = i == 0 ? 0 : i - 1;
    if ((paramInt1 < 0) || (paramInt1 >= this.tree.getItemCount()) || (paramInt2 < 0) || (paramInt2 > j)) {
      SWT.error(5);
    }
    setRowColumn(paramInt1, paramInt2, false);
  }
  
  public void setSelection(TreeItem paramTreeItem, int paramInt)
  {
    checkWidget();
    int i = this.tree.getColumnCount();
    int j = i == 0 ? 0 : i - 1;
    if ((paramTreeItem == null) || (paramTreeItem.isDisposed()) || (paramInt < 0) || (paramInt > j)) {
      SWT.error(5);
    }
    TreeColumn localTreeColumn = this.tree.getColumnCount() == 0 ? null : this.tree.getColumn(paramInt);
    setRowColumn(paramTreeItem, localTreeColumn, false);
  }
  
  public void setVisible(boolean paramBoolean)
  {
    checkWidget();
    if (paramBoolean) {
      _resize();
    }
    super.setVisible(paramBoolean);
  }
  
  void treeCollapse(Event paramEvent)
  {
    if (this.row == null) {
      return;
    }
    TreeItem localTreeItem1 = (TreeItem)paramEvent.item;
    for (TreeItem localTreeItem2 = this.row.getParentItem(); localTreeItem2 != null; localTreeItem2 = localTreeItem2.getParentItem()) {
      if (localTreeItem2 == localTreeItem1)
      {
        setRowColumn(localTreeItem1, this.column, true);
        return;
      }
    }
    getDisplay().asyncExec(new Runnable()
    {
      public void run()
      {
        if (TreeCursor.this.isDisposed()) {
          return;
        }
        TreeCursor.this.setRowColumn(TreeCursor.this.row, TreeCursor.this.column, true);
      }
    });
  }
  
  void treeExpand(Event paramEvent)
  {
    getDisplay().asyncExec(new Runnable()
    {
      public void run()
      {
        if (TreeCursor.this.isDisposed()) {
          return;
        }
        TreeCursor.this.setRowColumn(TreeCursor.this.row, TreeCursor.this.column, true);
      }
    });
  }
  
  void treeFocusIn(Event paramEvent)
  {
    if (isVisible())
    {
      if ((this.row == null) && (this.column == null)) {
        return;
      }
      setFocus();
    }
  }
  
  void treeMouseDown(Event paramEvent)
  {
    if (this.tree.getItemCount() == 0) {
      return;
    }
    Point localPoint = new Point(paramEvent.x, paramEvent.y);
    TreeItem localTreeItem1 = this.tree.getItem(localPoint);
    int k;
    if ((localTreeItem1 == null) && ((this.tree.getStyle() & 0x10000) == 0))
    {
      localObject = this.tree.getTopItem();
      for (TreeItem localTreeItem2 = ((TreeItem)localObject).getParentItem(); localTreeItem2 != null; localTreeItem2 = ((TreeItem)localObject).getParentItem()) {
        localObject = localTreeItem2;
      }
      j = this.tree.indexOf((TreeItem)localObject);
      k = this.tree.getClientArea().height / this.tree.getItemHeight();
      int m = Math.min(j + k, this.tree.getItemCount() - 1);
      TreeItem[] arrayOfTreeItem1 = this.tree.getItems();
      TreeItem[] arrayOfTreeItem2 = new TreeItem[m - j + 1];
      System.arraycopy(arrayOfTreeItem1, j, arrayOfTreeItem2, 0, m - j + 1);
      localTreeItem1 = findItem(arrayOfTreeItem2, localPoint);
    }
    if (localTreeItem1 == null) {
      return;
    }
    Object localObject = null;
    int i = this.tree.getLinesVisible() ? this.tree.getGridLineWidth() : 0;
    int j = this.tree.getColumnCount();
    if (j > 0)
    {
      for (k = 0; k < j; k++)
      {
        Rectangle localRectangle = localTreeItem1.getBounds(k);
        localRectangle.width += i;
        localRectangle.height += i;
        if (localRectangle.contains(localPoint))
        {
          localObject = this.tree.getColumn(k);
          break;
        }
      }
      if (localObject == null) {
        localObject = this.tree.getColumn(0);
      }
    }
    setRowColumn(localTreeItem1, (TreeColumn)localObject, true);
    setFocus();
  }
  
  void unhookRowColumnListeners()
  {
    if ((this.column != null) && (!this.column.isDisposed()))
    {
      this.column.removeListener(12, this.disposeColumnListener);
      this.column.removeListener(10, this.resizeListener);
      this.column.removeListener(11, this.resizeListener);
    }
    this.column = null;
    if ((this.row != null) && (!this.row.isDisposed())) {
      for (TreeItem localTreeItem = this.row; localTreeItem != null; localTreeItem = localTreeItem.getParentItem()) {
        localTreeItem.removeListener(12, this.disposeItemListener);
      }
    }
    this.row = null;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/custom/TreeCursor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */