package org.eclipse.swt.dnd;

import org.eclipse.swt.internal.cocoa.NSArray;
import org.eclipse.swt.internal.cocoa.NSData;
import org.eclipse.swt.internal.cocoa.NSMutableArray;
import org.eclipse.swt.internal.cocoa.NSObject;
import org.eclipse.swt.internal.cocoa.NSPasteboard;
import org.eclipse.swt.internal.cocoa.NSString;
import org.eclipse.swt.internal.cocoa.NSURL;
import org.eclipse.swt.internal.cocoa.OS;
import org.eclipse.swt.internal.cocoa.id;
import org.eclipse.swt.widgets.Display;

public class Clipboard
{
  Display display;
  
  public Clipboard(Display paramDisplay)
  {
    checkSubclass();
    if (paramDisplay == null)
    {
      paramDisplay = Display.getCurrent();
      if (paramDisplay == null) {
        paramDisplay = Display.getDefault();
      }
    }
    if (paramDisplay.getThread() != Thread.currentThread()) {
      DND.error(22);
    }
    this.display = paramDisplay;
  }
  
  protected void checkSubclass()
  {
    String str1 = getClass().getName();
    String str2 = Clipboard.class.getName();
    if (!str2.equals(str1)) {
      DND.error(43);
    }
  }
  
  protected void checkWidget()
  {
    Display localDisplay = this.display;
    if (localDisplay == null) {
      DND.error(24);
    }
    if (localDisplay.getThread() != Thread.currentThread()) {
      DND.error(22);
    }
    if (localDisplay.isDisposed()) {
      DND.error(24);
    }
  }
  
  public void clearContents()
  {
    clearContents(1);
  }
  
  public void clearContents(int paramInt)
  {
    checkWidget();
    if ((paramInt & 0x1) == 0) {
      return;
    }
    NSPasteboard localNSPasteboard = NSPasteboard.generalPasteboard();
    if (localNSPasteboard != null) {
      localNSPasteboard.declareTypes(NSMutableArray.arrayWithCapacity(0L), null);
    }
  }
  
  public void dispose()
  {
    if (isDisposed()) {
      return;
    }
    if (this.display.getThread() != Thread.currentThread()) {
      DND.error(22);
    }
    this.display = null;
  }
  
  public Object getContents(Transfer paramTransfer)
  {
    return getContents(paramTransfer, 1);
  }
  
  public Object getContents(Transfer paramTransfer, int paramInt)
  {
    checkWidget();
    if (paramTransfer == null) {
      DND.error(4);
    }
    if ((paramInt & 0x1) == 0) {
      return null;
    }
    NSPasteboard localNSPasteboard = NSPasteboard.generalPasteboard();
    if (localNSPasteboard == null) {
      return null;
    }
    String[] arrayOfString = paramTransfer.getTypeNames();
    NSMutableArray localNSMutableArray = NSMutableArray.arrayWithCapacity(arrayOfString.length);
    for (int i = 0; i < arrayOfString.length; i++) {
      localNSMutableArray.addObject(NSString.stringWith(arrayOfString[i]));
    }
    NSString localNSString = localNSPasteboard.availableTypeFromArray(localNSMutableArray);
    if (localNSString != null)
    {
      TransferData localTransferData = new TransferData();
      localTransferData.type = Transfer.registerType(localNSString.getString());
      if ((localNSString.isEqual(OS.NSStringPboardType)) || (localNSString.isEqual(OS.NSRTFPboardType)) || (localNSString.isEqual(OS.NSHTMLPboardType))) {
        localTransferData.data = localNSPasteboard.stringForType(localNSString);
      } else if ((localNSString.isEqual(OS.NSFilenamesPboardType)) || (localNSString.isEqual(OS.kUTTypeFileURL))) {
        localTransferData.data = new NSArray(localNSPasteboard.propertyListForType(OS.NSFilenamesPboardType).id);
      } else if ((localNSString.isEqual(OS.NSURLPboardType)) || (localNSString.isEqual(OS.kUTTypeURL))) {
        localTransferData.data = NSURL.URLFromPasteboard(localNSPasteboard);
      } else {
        localTransferData.data = localNSPasteboard.dataForType(localNSString);
      }
      if (localTransferData.data != null) {
        return paramTransfer.nativeToJava(localTransferData);
      }
    }
    return null;
  }
  
  public boolean isDisposed()
  {
    return this.display == null;
  }
  
  public void setContents(Object[] paramArrayOfObject, Transfer[] paramArrayOfTransfer)
  {
    setContents(paramArrayOfObject, paramArrayOfTransfer, 1);
  }
  
  public void setContents(Object[] paramArrayOfObject, Transfer[] paramArrayOfTransfer, int paramInt)
  {
    checkWidget();
    if ((paramArrayOfObject == null) || (paramArrayOfTransfer == null) || (paramArrayOfObject.length != paramArrayOfTransfer.length) || (paramArrayOfObject.length == 0)) {
      DND.error(5);
    }
    for (int i = 0; i < paramArrayOfObject.length; i++) {
      if ((paramArrayOfObject[i] == null) || (paramArrayOfTransfer[i] == null) || (!paramArrayOfTransfer[i].validate(paramArrayOfObject[i]))) {
        DND.error(5);
      }
    }
    if ((paramInt & 0x1) == 0) {
      return;
    }
    NSPasteboard localNSPasteboard = NSPasteboard.generalPasteboard();
    if (localNSPasteboard == null) {
      DND.error(2002);
    }
    localNSPasteboard.declareTypes(NSMutableArray.arrayWithCapacity(0L), null);
    for (int j = 0; j < paramArrayOfTransfer.length; j++)
    {
      String[] arrayOfString = paramArrayOfTransfer[j].getTypeNames();
      for (int k = 0; k < arrayOfString.length; k++)
      {
        TransferData localTransferData = new TransferData();
        localTransferData.type = Transfer.registerType(arrayOfString[k]);
        paramArrayOfTransfer[j].javaToNative(paramArrayOfObject[j], localTransferData);
        NSObject localNSObject = localTransferData.data;
        NSString localNSString = NSString.stringWith(arrayOfString[k]);
        localNSPasteboard.addTypes(NSArray.arrayWithObject(localNSString), null);
        if ((localNSString.isEqual(OS.NSStringPboardType)) || (localNSString.isEqual(OS.NSRTFPboardType)) || (localNSString.isEqual(OS.NSHTMLPboardType)))
        {
          localNSPasteboard.setString((NSString)localNSObject, localNSString);
        }
        else if ((localNSString.isEqual(OS.NSURLPboardType)) || (localNSString.isEqual(OS.kUTTypeURL)))
        {
          NSURL localNSURL = (NSURL)localNSObject;
          localNSURL.writeToPasteboard(localNSPasteboard);
        }
        else if ((localNSString.isEqual(OS.NSFilenamesPboardType)) || (localNSString.isEqual(OS.kUTTypeFileURL)))
        {
          localNSPasteboard.setPropertyList((NSArray)localNSObject, OS.NSFilenamesPboardType);
        }
        else
        {
          localNSPasteboard.setData((NSData)localNSObject, localNSString);
        }
      }
    }
  }
  
  public TransferData[] getAvailableTypes()
  {
    return getAvailableTypes(1);
  }
  
  public TransferData[] getAvailableTypes(int paramInt)
  {
    checkWidget();
    if ((paramInt & 0x1) == 0) {
      return new TransferData[0];
    }
    NSPasteboard localNSPasteboard = NSPasteboard.generalPasteboard();
    if (localNSPasteboard == null) {
      return new TransferData[0];
    }
    NSArray localNSArray = localNSPasteboard.types();
    if (localNSArray == null) {
      return new TransferData[0];
    }
    int i = (int)localNSArray.count();
    TransferData[] arrayOfTransferData = new TransferData[i];
    for (int j = 0; j < i; j++)
    {
      arrayOfTransferData[j] = new TransferData();
      arrayOfTransferData[j].type = Transfer.registerType(new NSString(localNSArray.objectAtIndex(j)).getString());
    }
    return arrayOfTransferData;
  }
  
  public String[] getAvailableTypeNames()
  {
    checkWidget();
    NSPasteboard localNSPasteboard = NSPasteboard.generalPasteboard();
    if (localNSPasteboard == null) {
      return new String[0];
    }
    NSArray localNSArray = localNSPasteboard.types();
    if (localNSArray == null) {
      return new String[0];
    }
    int i = (int)localNSArray.count();
    String[] arrayOfString = new String[i];
    for (int j = 0; j < i; j++) {
      arrayOfString[j] = new NSString(localNSArray.objectAtIndex(j)).getString();
    }
    return arrayOfString;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/dnd/Clipboard.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */