package org.eclipse.swt.internal.cocoa;

public class NSCursor
  extends NSObject
{
  public NSCursor() {}
  
  public NSCursor(long paramLong)
  {
    super(paramLong);
  }
  
  public NSCursor(id paramid)
  {
    super(paramid);
  }
  
  public static NSCursor IBeamCursor()
  {
    long l = OS.objc_msgSend(OS.class_NSCursor, OS.sel_IBeamCursor);
    return l != 0L ? new NSCursor(l) : null;
  }
  
  public static NSCursor arrowCursor()
  {
    long l = OS.objc_msgSend(OS.class_NSCursor, OS.sel_arrowCursor);
    return l != 0L ? new NSCursor(l) : null;
  }
  
  public static NSCursor crosshairCursor()
  {
    long l = OS.objc_msgSend(OS.class_NSCursor, OS.sel_crosshairCursor);
    return l != 0L ? new NSCursor(l) : null;
  }
  
  public static NSCursor currentCursor()
  {
    long l = OS.objc_msgSend(OS.class_NSCursor, OS.sel_currentCursor);
    return l != 0L ? new NSCursor(l) : null;
  }
  
  public NSPoint hotSpot()
  {
    NSPoint localNSPoint = new NSPoint();
    OS.objc_msgSend_stret(localNSPoint, this.id, OS.sel_hotSpot);
    return localNSPoint;
  }
  
  public NSCursor initWithImage(NSImage paramNSImage, NSPoint paramNSPoint)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_initWithImage_hotSpot_, paramNSImage != null ? paramNSImage.id : 0L, paramNSPoint);
    return l != 0L ? new NSCursor(l) : l == this.id ? this : null;
  }
  
  public static NSCursor operationNotAllowedCursor()
  {
    long l = OS.objc_msgSend(OS.class_NSCursor, OS.sel_operationNotAllowedCursor);
    return l != 0L ? new NSCursor(l) : null;
  }
  
  public static NSCursor pointingHandCursor()
  {
    long l = OS.objc_msgSend(OS.class_NSCursor, OS.sel_pointingHandCursor);
    return l != 0L ? new NSCursor(l) : null;
  }
  
  public static void pop()
  {
    OS.objc_msgSend(OS.class_NSCursor, OS.sel_pop);
  }
  
  public void push()
  {
    OS.objc_msgSend(this.id, OS.sel_push);
  }
  
  public static NSCursor resizeDownCursor()
  {
    long l = OS.objc_msgSend(OS.class_NSCursor, OS.sel_resizeDownCursor);
    return l != 0L ? new NSCursor(l) : null;
  }
  
  public static NSCursor resizeLeftCursor()
  {
    long l = OS.objc_msgSend(OS.class_NSCursor, OS.sel_resizeLeftCursor);
    return l != 0L ? new NSCursor(l) : null;
  }
  
  public static NSCursor resizeLeftRightCursor()
  {
    long l = OS.objc_msgSend(OS.class_NSCursor, OS.sel_resizeLeftRightCursor);
    return l != 0L ? new NSCursor(l) : null;
  }
  
  public static NSCursor resizeRightCursor()
  {
    long l = OS.objc_msgSend(OS.class_NSCursor, OS.sel_resizeRightCursor);
    return l != 0L ? new NSCursor(l) : null;
  }
  
  public static NSCursor resizeUpCursor()
  {
    long l = OS.objc_msgSend(OS.class_NSCursor, OS.sel_resizeUpCursor);
    return l != 0L ? new NSCursor(l) : null;
  }
  
  public static NSCursor resizeUpDownCursor()
  {
    long l = OS.objc_msgSend(OS.class_NSCursor, OS.sel_resizeUpDownCursor);
    return l != 0L ? new NSCursor(l) : null;
  }
  
  public void set()
  {
    OS.objc_msgSend(this.id, OS.sel_set);
  }
  
  public static void setHiddenUntilMouseMoves(boolean paramBoolean)
  {
    OS.objc_msgSend(OS.class_NSCursor, OS.sel_setHiddenUntilMouseMoves_, paramBoolean);
  }
  
  public void setOnMouseEntered(boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_setOnMouseEntered_, paramBoolean);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSCursor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */