package org.eclipse.swt.internal.cocoa;

public class NSMutableSet
  extends NSSet
{
  public NSMutableSet() {}
  
  public NSMutableSet(long paramLong)
  {
    super(paramLong);
  }
  
  public NSMutableSet(id paramid)
  {
    super(paramid);
  }
  
  public void addObjectsFromArray(NSArray paramNSArray)
  {
    OS.objc_msgSend(this.id, OS.sel_addObjectsFromArray_, paramNSArray != null ? paramNSArray.id : 0L);
  }
  
  public static NSSet set()
  {
    long l = OS.objc_msgSend(OS.class_NSMutableSet, OS.sel_set);
    return l != 0L ? new NSMutableSet(l) : null;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSMutableSet.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */