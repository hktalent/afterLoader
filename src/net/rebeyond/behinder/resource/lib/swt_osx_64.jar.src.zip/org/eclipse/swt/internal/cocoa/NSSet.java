package org.eclipse.swt.internal.cocoa;

public class NSSet
  extends NSObject
{
  public NSSet() {}
  
  public NSSet(long paramLong)
  {
    super(paramLong);
  }
  
  public NSSet(id paramid)
  {
    super(paramid);
  }
  
  public NSArray allObjects()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_allObjects);
    return l != 0L ? new NSArray(l) : null;
  }
  
  public long count()
  {
    return OS.objc_msgSend(this.id, OS.sel_count);
  }
  
  public NSEnumerator objectEnumerator()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_objectEnumerator);
    return l != 0L ? new NSEnumerator(l) : null;
  }
  
  public static NSSet set()
  {
    long l = OS.objc_msgSend(OS.class_NSSet, OS.sel_set);
    return l != 0L ? new NSSet(l) : null;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSSet.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */