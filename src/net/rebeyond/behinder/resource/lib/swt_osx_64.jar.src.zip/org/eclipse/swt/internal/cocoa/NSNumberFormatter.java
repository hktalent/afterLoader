package org.eclipse.swt.internal.cocoa;

public class NSNumberFormatter
  extends NSFormatter
{
  public NSNumberFormatter() {}
  
  public NSNumberFormatter(long paramLong)
  {
    super(paramLong);
  }
  
  public NSNumberFormatter(id paramid)
  {
    super(paramid);
  }
  
  public boolean allowsFloats()
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_allowsFloats);
  }
  
  public boolean alwaysShowsDecimalSeparator()
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_alwaysShowsDecimalSeparator);
  }
  
  public NSString decimalSeparator()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_decimalSeparator);
    return l != 0L ? new NSString(l) : null;
  }
  
  public NSNumber maximum()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_maximum);
    return l != 0L ? new NSNumber(l) : null;
  }
  
  public long maximumFractionDigits()
  {
    return OS.objc_msgSend(this.id, OS.sel_maximumFractionDigits);
  }
  
  public long maximumIntegerDigits()
  {
    return OS.objc_msgSend(this.id, OS.sel_maximumIntegerDigits);
  }
  
  public NSNumber minimum()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_minimum);
    return l != 0L ? new NSNumber(l) : null;
  }
  
  public void setAllowsFloats(boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_setAllowsFloats_, paramBoolean);
  }
  
  public void setMaximum(NSNumber paramNSNumber)
  {
    OS.objc_msgSend(this.id, OS.sel_setMaximum_, paramNSNumber != null ? paramNSNumber.id : 0L);
  }
  
  public void setMaximumFractionDigits(long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_setMaximumFractionDigits_, paramLong);
  }
  
  public void setMaximumIntegerDigits(long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_setMaximumIntegerDigits_, paramLong);
  }
  
  public void setMinimum(NSNumber paramNSNumber)
  {
    OS.objc_msgSend(this.id, OS.sel_setMinimum_, paramNSNumber != null ? paramNSNumber.id : 0L);
  }
  
  public void setMinimumFractionDigits(long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_setMinimumFractionDigits_, paramLong);
  }
  
  public void setMinimumIntegerDigits(long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_setMinimumIntegerDigits_, paramLong);
  }
  
  public void setNumberStyle(long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_setNumberStyle_, paramLong);
  }
  
  public void setPartialStringValidationEnabled(boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_setPartialStringValidationEnabled_, paramBoolean);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSNumberFormatter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */