package org.eclipse.swt.internal.cocoa;

public class NSMutableDictionary
  extends NSDictionary
{
  public NSMutableDictionary() {}
  
  public NSMutableDictionary(long paramLong)
  {
    super(paramLong);
  }
  
  public NSMutableDictionary(id paramid)
  {
    super(paramid);
  }
  
  public static NSMutableDictionary dictionaryWithCapacity(long paramLong)
  {
    long l = OS.objc_msgSend(OS.class_NSMutableDictionary, OS.sel_dictionaryWithCapacity_, paramLong);
    return l != 0L ? new NSMutableDictionary(l) : null;
  }
  
  public NSMutableDictionary initWithCapacity(long paramLong)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_initWithCapacity_, paramLong);
    return l != 0L ? new NSMutableDictionary(l) : l == this.id ? this : null;
  }
  
  public void removeObjectForKey(id paramid)
  {
    OS.objc_msgSend(this.id, OS.sel_removeObjectForKey_, paramid != null ? paramid.id : 0L);
  }
  
  public void setDictionary(NSDictionary paramNSDictionary)
  {
    OS.objc_msgSend(this.id, OS.sel_setDictionary_, paramNSDictionary != null ? paramNSDictionary.id : 0L);
  }
  
  public void setObject(id paramid1, id paramid2)
  {
    OS.objc_msgSend(this.id, OS.sel_setObject_forKey_, paramid1 != null ? paramid1.id : 0L, paramid2 != null ? paramid2.id : 0L);
  }
  
  public void setValue(id paramid, NSString paramNSString)
  {
    OS.objc_msgSend(this.id, OS.sel_setValue_forKey_, paramid != null ? paramid.id : 0L, paramNSString != null ? paramNSString.id : 0L);
  }
  
  public static NSDictionary dictionaryWithObject(id paramid1, id paramid2)
  {
    long l = OS.objc_msgSend(OS.class_NSMutableDictionary, OS.sel_dictionaryWithObject_forKey_, paramid1 != null ? paramid1.id : 0L, paramid2 != null ? paramid2.id : 0L);
    return l != 0L ? new NSMutableDictionary(l) : null;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSMutableDictionary.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */