package org.eclipse.swt.accessibility;

import java.util.Vector;
import org.eclipse.swt.internal.cocoa.NSSize;
import org.eclipse.swt.internal.cocoa.NSValue;

class AccessibleTableColumn
  extends Accessible
{
  public AccessibleTableColumn(Accessible paramAccessible, int paramInt)
  {
    super(paramAccessible);
    this.index = paramInt;
    addAccessibleControlListener(new AccessibleControlAdapter()
    {
      public void getLocation(AccessibleControlEvent paramAnonymousAccessibleControlEvent)
      {
        Accessible[] arrayOfAccessible = AccessibleTableColumn.this.getColumnCells();
        AccessibleControlEvent localAccessibleControlEvent = new AccessibleControlEvent(this);
        localAccessibleControlEvent.childID = -1;
        localAccessibleControlEvent.width = -1;
        Accessible localAccessible = arrayOfAccessible[0];
        for (int i = 0; i < localAccessible.accessibleControlListeners.size(); i++)
        {
          AccessibleControlListener localAccessibleControlListener = (AccessibleControlListener)localAccessible.accessibleControlListeners.elementAt(i);
          localAccessibleControlListener.getLocation(localAccessibleControlEvent);
        }
        i = 0;
        int j = 0;
        for (int k = 0; k < arrayOfAccessible.length; k++)
        {
          NSValue localNSValue = (NSValue)arrayOfAccessible[k].getSizeAttribute(-1);
          NSSize localNSSize = localNSValue.sizeValue();
          if (localNSSize.width > j) {
            j = (int)localNSSize.width;
          }
          i = (int)(i + localNSSize.height);
        }
        paramAnonymousAccessibleControlEvent.x = localAccessibleControlEvent.x;
        paramAnonymousAccessibleControlEvent.y = localAccessibleControlEvent.y;
        paramAnonymousAccessibleControlEvent.width = j;
        paramAnonymousAccessibleControlEvent.height = i;
      }
      
      public void getRole(AccessibleControlEvent paramAnonymousAccessibleControlEvent)
      {
        paramAnonymousAccessibleControlEvent.detail = 27;
      }
    });
    addAccessibleTableListener(new AccessibleTableAdapter()
    {
      public void getRowCount(AccessibleTableEvent paramAnonymousAccessibleTableEvent)
      {
        paramAnonymousAccessibleTableEvent.count = AccessibleTableColumn.this.getColumnCells().length;
      }
      
      public void getRow(AccessibleTableEvent paramAnonymousAccessibleTableEvent)
      {
        int i = paramAnonymousAccessibleTableEvent.row;
        Accessible[] arrayOfAccessible = AccessibleTableColumn.this.getColumnCells();
        int j = arrayOfAccessible.length;
        if ((0 <= i) && (i < j)) {
          paramAnonymousAccessibleTableEvent.accessible = arrayOfAccessible[i];
        }
      }
      
      public void getRows(AccessibleTableEvent paramAnonymousAccessibleTableEvent)
      {
        paramAnonymousAccessibleTableEvent.accessibles = AccessibleTableColumn.this.getColumnCells();
      }
    });
  }
  
  private Accessible[] getColumnCells()
  {
    int i = Math.max(1, this.parent.getRowCount());
    Accessible[] arrayOfAccessible = new Accessible[i];
    AccessibleTableEvent localAccessibleTableEvent = new AccessibleTableEvent(this);
    for (int j = 0; j < i; j++)
    {
      localAccessibleTableEvent.column = this.index;
      localAccessibleTableEvent.row = j;
      for (int k = 0; k < this.parent.accessibleTableListeners.size(); k++)
      {
        AccessibleTableListener localAccessibleTableListener = (AccessibleTableListener)this.parent.accessibleTableListeners.elementAt(k);
        localAccessibleTableListener.getCell(localAccessibleTableEvent);
      }
      arrayOfAccessible[j] = localAccessibleTableEvent.accessible;
    }
    return arrayOfAccessible;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/accessibility/AccessibleTableColumn.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */