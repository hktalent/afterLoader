package org.eclipse.swt.accessibility;

public class AccessibleActionAdapter
  implements AccessibleActionListener
{
  public void getActionCount(AccessibleActionEvent paramAccessibleActionEvent) {}
  
  public void doAction(AccessibleActionEvent paramAccessibleActionEvent) {}
  
  public void getDescription(AccessibleActionEvent paramAccessibleActionEvent) {}
  
  public void getKeyBinding(AccessibleActionEvent paramAccessibleActionEvent) {}
  
  public void getName(AccessibleActionEvent paramAccessibleActionEvent) {}
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/accessibility/AccessibleActionAdapter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */