package org.eclipse.swt.internal.cocoa;

public class NSURLDownload
  extends NSObject
{
  public NSURLDownload() {}
  
  public NSURLDownload(long paramLong)
  {
    super(paramLong);
  }
  
  public NSURLDownload(id paramid)
  {
    super(paramid);
  }
  
  public void cancel()
  {
    OS.objc_msgSend(this.id, OS.sel_cancel);
  }
  
  public void setDestination(NSString paramNSString, boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_setDestination_allowOverwrite_, paramNSString != null ? paramNSString.id : 0L, paramBoolean);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSURLDownload.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */