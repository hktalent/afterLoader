package org.eclipse.swt.internal.cocoa;

public class NSBundle
  extends NSObject
{
  public NSBundle() {}
  
  public NSBundle(long paramLong)
  {
    super(paramLong);
  }
  
  public NSBundle(id paramid)
  {
    super(paramid);
  }
  
  public static boolean loadNibFile(NSString paramNSString, NSDictionary paramNSDictionary, long paramLong)
  {
    return OS.objc_msgSend_bool(OS.class_NSBundle, OS.sel_loadNibFile_externalNameTable_withZone_, paramNSString != null ? paramNSString.id : 0L, paramNSDictionary != null ? paramNSDictionary.id : 0L, paramLong);
  }
  
  public NSString bundleIdentifier()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_bundleIdentifier);
    return l != 0L ? new NSString(l) : null;
  }
  
  public NSString bundlePath()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_bundlePath);
    return l != 0L ? new NSString(l) : null;
  }
  
  public static NSBundle bundleWithIdentifier(NSString paramNSString)
  {
    long l = OS.objc_msgSend(OS.class_NSBundle, OS.sel_bundleWithIdentifier_, paramNSString != null ? paramNSString.id : 0L);
    return l != 0L ? new NSBundle(l) : null;
  }
  
  public static NSBundle bundleWithPath(NSString paramNSString)
  {
    long l = OS.objc_msgSend(OS.class_NSBundle, OS.sel_bundleWithPath_, paramNSString != null ? paramNSString.id : 0L);
    return l != 0L ? new NSBundle(l) : null;
  }
  
  public NSDictionary infoDictionary()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_infoDictionary);
    return l != 0L ? new NSDictionary(l) : null;
  }
  
  public static NSBundle mainBundle()
  {
    long l = OS.objc_msgSend(OS.class_NSBundle, OS.sel_mainBundle);
    return l != 0L ? new NSBundle(l) : null;
  }
  
  public id objectForInfoDictionaryKey(NSString paramNSString)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_objectForInfoDictionaryKey_, paramNSString != null ? paramNSString.id : 0L);
    return l != 0L ? new id(l) : null;
  }
  
  public NSString pathForResource(NSString paramNSString1, NSString paramNSString2)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_pathForResource_ofType_, paramNSString1 != null ? paramNSString1.id : 0L, paramNSString2 != null ? paramNSString2.id : 0L);
    return l != 0L ? new NSString(l) : null;
  }
  
  public NSString pathForResource(NSString paramNSString1, NSString paramNSString2, NSString paramNSString3, NSString paramNSString4)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_pathForResource_ofType_inDirectory_forLocalization_, paramNSString1 != null ? paramNSString1.id : 0L, paramNSString2 != null ? paramNSString2.id : 0L, paramNSString3 != null ? paramNSString3.id : 0L, paramNSString4 != null ? paramNSString4.id : 0L);
    return l != 0L ? new NSString(l) : null;
  }
  
  public NSString resourcePath()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_resourcePath);
    return l != 0L ? new NSString(l) : null;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSBundle.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */