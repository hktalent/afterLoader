package org.eclipse.swt.internal.cocoa;

public class NSStatusBar
  extends NSObject
{
  public NSStatusBar() {}
  
  public NSStatusBar(long paramLong)
  {
    super(paramLong);
  }
  
  public NSStatusBar(id paramid)
  {
    super(paramid);
  }
  
  public void removeStatusItem(NSStatusItem paramNSStatusItem)
  {
    OS.objc_msgSend(this.id, OS.sel_removeStatusItem_, paramNSStatusItem != null ? paramNSStatusItem.id : 0L);
  }
  
  public NSStatusItem statusItemWithLength(double paramDouble)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_statusItemWithLength_, paramDouble);
    return l != 0L ? new NSStatusItem(l) : null;
  }
  
  public static NSStatusBar systemStatusBar()
  {
    long l = OS.objc_msgSend(OS.class_NSStatusBar, OS.sel_systemStatusBar);
    return l != 0L ? new NSStatusBar(l) : null;
  }
  
  public double thickness()
  {
    return OS.objc_msgSend_fpret(this.id, OS.sel_thickness);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSStatusBar.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */