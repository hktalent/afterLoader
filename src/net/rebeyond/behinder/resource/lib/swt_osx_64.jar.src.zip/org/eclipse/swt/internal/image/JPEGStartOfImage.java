package org.eclipse.swt.internal.image;

final class JPEGStartOfImage
  extends JPEGFixedSizeSegment
{
  public JPEGStartOfImage() {}
  
  public JPEGStartOfImage(byte[] paramArrayOfByte)
  {
    super(paramArrayOfByte);
  }
  
  public JPEGStartOfImage(LEDataInputStream paramLEDataInputStream)
  {
    super(paramLEDataInputStream);
  }
  
  public int signature()
  {
    return 65496;
  }
  
  public int fixedSize()
  {
    return 2;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/image/JPEGStartOfImage.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */