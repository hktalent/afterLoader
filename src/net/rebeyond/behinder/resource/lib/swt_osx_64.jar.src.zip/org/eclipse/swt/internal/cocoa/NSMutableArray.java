package org.eclipse.swt.internal.cocoa;

public class NSMutableArray
  extends NSArray
{
  public NSMutableArray() {}
  
  public NSMutableArray(long paramLong)
  {
    super(paramLong);
  }
  
  public NSMutableArray(id paramid)
  {
    super(paramid);
  }
  
  public void addObject(id paramid)
  {
    OS.objc_msgSend(this.id, OS.sel_addObject_, paramid != null ? paramid.id : 0L);
  }
  
  public void addObjectsFromArray(NSArray paramNSArray)
  {
    OS.objc_msgSend(this.id, OS.sel_addObjectsFromArray_, paramNSArray != null ? paramNSArray.id : 0L);
  }
  
  public static NSMutableArray arrayWithCapacity(long paramLong)
  {
    long l = OS.objc_msgSend(OS.class_NSMutableArray, OS.sel_arrayWithCapacity_, paramLong);
    return l != 0L ? new NSMutableArray(l) : null;
  }
  
  public NSMutableArray initWithCapacity(long paramLong)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_initWithCapacity_, paramLong);
    return l != 0L ? new NSMutableArray(l) : l == this.id ? this : null;
  }
  
  public void removeLastObject()
  {
    OS.objc_msgSend(this.id, OS.sel_removeLastObject);
  }
  
  public void removeObject(id paramid)
  {
    OS.objc_msgSend(this.id, OS.sel_removeObject_, paramid != null ? paramid.id : 0L);
  }
  
  public void removeObjectAtIndex(long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_removeObjectAtIndex_, paramLong);
  }
  
  public void removeObjectIdenticalTo(id paramid)
  {
    OS.objc_msgSend(this.id, OS.sel_removeObjectIdenticalTo_, paramid != null ? paramid.id : 0L);
  }
  
  public static NSArray array()
  {
    long l = OS.objc_msgSend(OS.class_NSMutableArray, OS.sel_array);
    return l != 0L ? new NSArray(l) : null;
  }
  
  public static NSArray arrayWithObject(id paramid)
  {
    long l = OS.objc_msgSend(OS.class_NSMutableArray, OS.sel_arrayWithObject_, paramid != null ? paramid.id : 0L);
    return l != 0L ? new NSMutableArray(l) : null;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSMutableArray.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */