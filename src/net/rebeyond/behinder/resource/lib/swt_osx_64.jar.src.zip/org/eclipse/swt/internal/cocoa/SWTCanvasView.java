package org.eclipse.swt.internal.cocoa;

public class SWTCanvasView
  extends NSView
{
  public SWTCanvasView()
  {
    super(0L);
  }
  
  public SWTCanvasView(long paramLong)
  {
    super(paramLong);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/SWTCanvasView.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */