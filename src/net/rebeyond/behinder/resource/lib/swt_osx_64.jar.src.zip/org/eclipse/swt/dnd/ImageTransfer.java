package org.eclipse.swt.dnd;

import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.ImageData;
import org.eclipse.swt.internal.cocoa.NSData;
import org.eclipse.swt.internal.cocoa.NSImage;
import org.eclipse.swt.internal.cocoa.NSImageRep;
import org.eclipse.swt.internal.cocoa.NSRect;
import org.eclipse.swt.internal.cocoa.NSSize;
import org.eclipse.swt.internal.cocoa.NSString;
import org.eclipse.swt.internal.cocoa.OS;
import org.eclipse.swt.widgets.Display;

public class ImageTransfer
  extends ByteArrayTransfer
{
  static ImageTransfer _instance = new ImageTransfer();
  static final String TIFF = OS.NSTIFFPboardType.getString();
  static final int TIFFID = registerType(TIFF);
  
  public static ImageTransfer getInstance()
  {
    return _instance;
  }
  
  public void javaToNative(Object paramObject, TransferData paramTransferData)
  {
    if ((!checkImage(paramObject)) || (!isSupportedType(paramTransferData))) {
      DND.error(2003);
    }
    ImageData localImageData = (ImageData)paramObject;
    Image localImage = new Image(Display.getCurrent(), localImageData);
    NSImage localNSImage = localImage.handle;
    paramTransferData.data = localNSImage.TIFFRepresentation();
    localImage.dispose();
  }
  
  public Object nativeToJava(TransferData paramTransferData)
  {
    if ((!isSupportedType(paramTransferData)) || (paramTransferData.data == null)) {
      return null;
    }
    NSData localNSData = (NSData)paramTransferData.data;
    if (localNSData.length() == 0L) {
      return null;
    }
    Object localObject1 = (NSImage)new NSImage().alloc();
    ((NSImage)localObject1).initWithData(localNSData);
    NSSize localNSSize = ((NSImage)localObject1).size();
    NSImageRep localNSImageRep = ((NSImage)localObject1).bestRepresentationForDevice(null);
    if ((localNSSize.width != localNSImageRep.pixelsWide()) || (localNSSize.height != localNSImageRep.pixelsHigh()))
    {
      localNSSize.width /= localNSImageRep.pixelsWide() / localNSSize.width;
      localNSSize.height /= localNSImageRep.pixelsHigh() / localNSSize.height;
      localObject2 = ((NSImage)new NSImage().alloc()).initWithSize(localNSSize);
      ((NSImage)localObject2).lockFocus();
      localObject3 = new NSRect();
      ((NSRect)localObject3).width = localNSSize.width;
      ((NSRect)localObject3).height = localNSSize.height;
      ((NSImage)localObject1).drawInRect((NSRect)localObject3, new NSRect(), 1L, 1.0D);
      ((NSImage)localObject2).unlockFocus();
      ((NSImage)localObject1).release();
      localObject1 = localObject2;
    }
    Object localObject2 = Image.cocoa_new(Display.getCurrent(), 0, (NSImage)localObject1);
    Object localObject3 = ((Image)localObject2).getImageData();
    ((Image)localObject2).dispose();
    return localObject3;
  }
  
  protected int[] getTypeIds()
  {
    return new int[] { TIFFID };
  }
  
  protected String[] getTypeNames()
  {
    return new String[] { TIFF };
  }
  
  boolean checkImage(Object paramObject)
  {
    return (paramObject != null) && ((paramObject instanceof ImageData));
  }
  
  protected boolean validate(Object paramObject)
  {
    return checkImage(paramObject);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/dnd/ImageTransfer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */