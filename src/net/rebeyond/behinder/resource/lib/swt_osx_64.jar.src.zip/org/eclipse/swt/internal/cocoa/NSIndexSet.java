package org.eclipse.swt.internal.cocoa;

public class NSIndexSet
  extends NSObject
{
  public NSIndexSet() {}
  
  public NSIndexSet(long paramLong)
  {
    super(paramLong);
  }
  
  public NSIndexSet(id paramid)
  {
    super(paramid);
  }
  
  public boolean containsIndex(long paramLong)
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_containsIndex_, paramLong);
  }
  
  public long count()
  {
    return OS.objc_msgSend(this.id, OS.sel_count);
  }
  
  public long firstIndex()
  {
    return OS.objc_msgSend(this.id, OS.sel_firstIndex);
  }
  
  public long getIndexes(long[] paramArrayOfLong, long paramLong1, long paramLong2)
  {
    return OS.objc_msgSend(this.id, OS.sel_getIndexes_maxCount_inIndexRange_, paramArrayOfLong, paramLong1, paramLong2);
  }
  
  public static id indexSetWithIndex(long paramLong)
  {
    long l = OS.objc_msgSend(OS.class_NSIndexSet, OS.sel_indexSetWithIndex_, paramLong);
    return l != 0L ? new id(l) : null;
  }
  
  public NSIndexSet initWithIndex(long paramLong)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_initWithIndex_, paramLong);
    return l != 0L ? new NSIndexSet(l) : l == this.id ? this : null;
  }
  
  public id initWithIndexSet(NSIndexSet paramNSIndexSet)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_initWithIndexSet_, paramNSIndexSet != null ? paramNSIndexSet.id : 0L);
    return l != 0L ? new id(l) : null;
  }
  
  public NSIndexSet initWithIndexesInRange(NSRange paramNSRange)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_initWithIndexesInRange_, paramNSRange);
    return l != 0L ? new NSIndexSet(l) : l == this.id ? this : null;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSIndexSet.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */