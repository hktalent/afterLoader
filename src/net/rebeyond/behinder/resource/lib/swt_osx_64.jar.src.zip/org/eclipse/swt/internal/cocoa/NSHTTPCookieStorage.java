package org.eclipse.swt.internal.cocoa;

public class NSHTTPCookieStorage
  extends NSObject
{
  public NSHTTPCookieStorage() {}
  
  public NSHTTPCookieStorage(long paramLong)
  {
    super(paramLong);
  }
  
  public NSHTTPCookieStorage(id paramid)
  {
    super(paramid);
  }
  
  public NSArray cookies()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_cookies);
    return l != 0L ? new NSArray(l) : null;
  }
  
  public NSArray cookiesForURL(NSURL paramNSURL)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_cookiesForURL_, paramNSURL != null ? paramNSURL.id : 0L);
    return l != 0L ? new NSArray(l) : null;
  }
  
  public void deleteCookie(NSHTTPCookie paramNSHTTPCookie)
  {
    OS.objc_msgSend(this.id, OS.sel_deleteCookie_, paramNSHTTPCookie != null ? paramNSHTTPCookie.id : 0L);
  }
  
  public void setCookie(NSHTTPCookie paramNSHTTPCookie)
  {
    OS.objc_msgSend(this.id, OS.sel_setCookie_, paramNSHTTPCookie != null ? paramNSHTTPCookie.id : 0L);
  }
  
  public static NSHTTPCookieStorage sharedHTTPCookieStorage()
  {
    long l = OS.objc_msgSend(OS.class_NSHTTPCookieStorage, OS.sel_sharedHTTPCookieStorage);
    return l != 0L ? new NSHTTPCookieStorage(l) : null;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSHTTPCookieStorage.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */