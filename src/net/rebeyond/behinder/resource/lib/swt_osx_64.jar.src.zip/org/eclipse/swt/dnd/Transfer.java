package org.eclipse.swt.dnd;

public abstract class Transfer
{
  static String[] TYPES = new String[4];
  
  public abstract TransferData[] getSupportedTypes();
  
  public abstract boolean isSupportedType(TransferData paramTransferData);
  
  protected abstract int[] getTypeIds();
  
  protected abstract String[] getTypeNames();
  
  protected abstract void javaToNative(Object paramObject, TransferData paramTransferData);
  
  protected abstract Object nativeToJava(TransferData paramTransferData);
  
  public static int registerType(String paramString)
  {
    Object localObject;
    for (int i = 1; i < TYPES.length; i++)
    {
      localObject = TYPES[i];
      if ((localObject != null) && (paramString.equals(localObject))) {
        return i;
      }
    }
    if (i == TYPES.length)
    {
      localObject = new String[TYPES.length + 4];
      System.arraycopy(TYPES, 0, localObject, 0, TYPES.length);
      TYPES = (String[])localObject;
    }
    TYPES[i] = paramString;
    return i;
  }
  
  protected boolean validate(Object paramObject)
  {
    return true;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/dnd/Transfer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */