package org.eclipse.swt.internal.cocoa;

public class NSUserDefaults
  extends NSObject
{
  public NSUserDefaults() {}
  
  public NSUserDefaults(long paramLong)
  {
    super(paramLong);
  }
  
  public NSUserDefaults(id paramid)
  {
    super(paramid);
  }
  
  public id objectForKey(NSString paramNSString)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_objectForKey_, paramNSString != null ? paramNSString.id : 0L);
    return l != 0L ? new id(l) : null;
  }
  
  public void setInteger(long paramLong, NSString paramNSString)
  {
    OS.objc_msgSend(this.id, OS.sel_setInteger_forKey_, paramLong, paramNSString != null ? paramNSString.id : 0L);
  }
  
  public static NSUserDefaults standardUserDefaults()
  {
    long l = OS.objc_msgSend(OS.class_NSUserDefaults, OS.sel_standardUserDefaults);
    return l != 0L ? new NSUserDefaults(l) : null;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSUserDefaults.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */