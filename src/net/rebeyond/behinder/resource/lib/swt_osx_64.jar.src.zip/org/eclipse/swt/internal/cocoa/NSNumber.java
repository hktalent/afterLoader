package org.eclipse.swt.internal.cocoa;

public class NSNumber
  extends NSValue
{
  public NSNumber() {}
  
  public NSNumber(long paramLong)
  {
    super(paramLong);
  }
  
  public NSNumber(id paramid)
  {
    super(paramid);
  }
  
  public boolean boolValue()
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_boolValue);
  }
  
  public double doubleValue()
  {
    return OS.objc_msgSend_fpret(this.id, OS.sel_doubleValue);
  }
  
  public float floatValue()
  {
    return OS.objc_msgSend_floatret(this.id, OS.sel_floatValue);
  }
  
  public int intValue()
  {
    return (int)OS.objc_msgSend(this.id, OS.sel_intValue);
  }
  
  public long integerValue()
  {
    return OS.objc_msgSend(this.id, OS.sel_integerValue);
  }
  
  public static NSNumber numberWithBool(boolean paramBoolean)
  {
    long l = OS.objc_msgSend(OS.class_NSNumber, OS.sel_numberWithBool_, paramBoolean);
    return l != 0L ? new NSNumber(l) : null;
  }
  
  public static NSNumber numberWithDouble(double paramDouble)
  {
    long l = OS.objc_msgSend(OS.class_NSNumber, OS.sel_numberWithDouble_, paramDouble);
    return l != 0L ? new NSNumber(l) : null;
  }
  
  public static NSNumber numberWithInt(int paramInt)
  {
    long l = OS.objc_msgSend(OS.class_NSNumber, OS.sel_numberWithInt_, paramInt);
    return l != 0L ? new NSNumber(l) : null;
  }
  
  public static NSNumber numberWithInteger(long paramLong)
  {
    long l = OS.objc_msgSend(OS.class_NSNumber, OS.sel_numberWithInteger_, paramLong);
    return l != 0L ? new NSNumber(l) : null;
  }
  
  public static NSValue valueWithPoint(NSPoint paramNSPoint)
  {
    long l = OS.objc_msgSend(OS.class_NSNumber, OS.sel_valueWithPoint_, paramNSPoint);
    return l != 0L ? new NSValue(l) : null;
  }
  
  public static NSValue valueWithRange(NSRange paramNSRange)
  {
    long l = OS.objc_msgSend(OS.class_NSNumber, OS.sel_valueWithRange_, paramNSRange);
    return l != 0L ? new NSValue(l) : null;
  }
  
  public static NSValue valueWithRect(NSRect paramNSRect)
  {
    long l = OS.objc_msgSend(OS.class_NSNumber, OS.sel_valueWithRect_, paramNSRect);
    return l != 0L ? new NSValue(l) : null;
  }
  
  public static NSValue valueWithSize(NSSize paramNSSize)
  {
    long l = OS.objc_msgSend(OS.class_NSNumber, OS.sel_valueWithSize_, paramNSSize);
    return l != 0L ? new NSValue(l) : null;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSNumber.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */