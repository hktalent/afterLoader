package org.eclipse.swt.internal.cocoa;

public class NSImageView
  extends NSControl
{
  public NSImageView() {}
  
  public NSImageView(long paramLong)
  {
    super(paramLong);
  }
  
  public NSImageView(id paramid)
  {
    super(paramid);
  }
  
  public NSImage image()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_image);
    return l != 0L ? new NSImage(l) : null;
  }
  
  public void setImage(NSImage paramNSImage)
  {
    OS.objc_msgSend(this.id, OS.sel_setImage_, paramNSImage != null ? paramNSImage.id : 0L);
  }
  
  public void setImageAlignment(long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_setImageAlignment_, paramLong);
  }
  
  public void setImageScaling(long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_setImageScaling_, paramLong);
  }
  
  public static long cellClass()
  {
    return OS.objc_msgSend(OS.class_NSImageView, OS.sel_cellClass);
  }
  
  public static void setCellClass(long paramLong)
  {
    OS.objc_msgSend(OS.class_NSImageView, OS.sel_setCellClass_, paramLong);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSImageView.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */