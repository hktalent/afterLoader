package org.eclipse.swt.internal.cocoa;

public class NSTextView
  extends NSText
{
  public NSTextView() {}
  
  public NSTextView(long paramLong)
  {
    super(paramLong);
  }
  
  public NSTextView(id paramid)
  {
    super(paramid);
  }
  
  public long characterIndexForInsertionAtPoint(NSPoint paramNSPoint)
  {
    return OS.objc_msgSend(this.id, OS.sel_characterIndexForInsertionAtPoint_, paramNSPoint);
  }
  
  public NSParagraphStyle defaultParagraphStyle()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_defaultParagraphStyle);
    return l != 0L ? new NSParagraphStyle(l) : null;
  }
  
  public boolean dragSelectionWithEvent(NSEvent paramNSEvent, NSSize paramNSSize, boolean paramBoolean)
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_dragSelectionWithEvent_offset_slideBack_, paramNSEvent != null ? paramNSEvent.id : 0L, paramNSSize, paramBoolean);
  }
  
  public void drawViewBackgroundInRect(NSRect paramNSRect)
  {
    OS.objc_msgSend(this.id, OS.sel_drawViewBackgroundInRect_, paramNSRect);
  }
  
  public NSLayoutManager layoutManager()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_layoutManager);
    return l != 0L ? new NSLayoutManager(l) : null;
  }
  
  public NSDictionary linkTextAttributes()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_linkTextAttributes);
    return l != 0L ? new NSDictionary(l) : null;
  }
  
  public NSDictionary markedTextAttributes()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_markedTextAttributes);
    return l != 0L ? new NSDictionary(l) : null;
  }
  
  public NSDictionary selectedTextAttributes()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_selectedTextAttributes);
    return l != 0L ? new NSDictionary(l) : null;
  }
  
  public void setAllowsUndo(boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_setAllowsUndo_, paramBoolean);
  }
  
  public void setBaseWritingDirection(long paramLong, NSRange paramNSRange)
  {
    OS.objc_msgSend(this.id, OS.sel_setBaseWritingDirection_range_, paramLong, paramNSRange);
  }
  
  public void setDefaultParagraphStyle(NSParagraphStyle paramNSParagraphStyle)
  {
    OS.objc_msgSend(this.id, OS.sel_setDefaultParagraphStyle_, paramNSParagraphStyle != null ? paramNSParagraphStyle.id : 0L);
  }
  
  public void setDisplaysLinkToolTips(boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_setDisplaysLinkToolTips_, paramBoolean);
  }
  
  public void setLinkTextAttributes(NSDictionary paramNSDictionary)
  {
    OS.objc_msgSend(this.id, OS.sel_setLinkTextAttributes_, paramNSDictionary != null ? paramNSDictionary.id : 0L);
  }
  
  public void setRichText(boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_setRichText_, paramBoolean);
  }
  
  public void setSelectedTextAttributes(NSDictionary paramNSDictionary)
  {
    OS.objc_msgSend(this.id, OS.sel_setSelectedTextAttributes_, paramNSDictionary != null ? paramNSDictionary.id : 0L);
  }
  
  public void setUsesFontPanel(boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_setUsesFontPanel_, paramBoolean);
  }
  
  public boolean shouldChangeTextInRange(NSRange paramNSRange, NSString paramNSString)
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_shouldChangeTextInRange_replacementString_, paramNSRange, paramNSString != null ? paramNSString.id : 0L);
  }
  
  public boolean shouldDrawInsertionPoint()
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_shouldDrawInsertionPoint);
  }
  
  public NSTextContainer textContainer()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_textContainer);
    return l != 0L ? new NSTextContainer(l) : null;
  }
  
  public NSTextStorage textStorage()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_textStorage);
    return l != 0L ? new NSTextStorage(l) : null;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSTextView.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */