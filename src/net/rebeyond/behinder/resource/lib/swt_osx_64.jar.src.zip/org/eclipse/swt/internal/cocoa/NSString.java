package org.eclipse.swt.internal.cocoa;

public class NSString
  extends NSObject
{
  public NSString() {}
  
  public NSString(long paramLong)
  {
    super(paramLong);
  }
  
  public NSString(id paramid)
  {
    super(paramid);
  }
  
  public String getString()
  {
    char[] arrayOfChar = new char[(int)length()];
    getCharacters(arrayOfChar);
    return new String(arrayOfChar);
  }
  
  public NSString initWithString(String paramString)
  {
    char[] arrayOfChar = new char[paramString.length()];
    paramString.getChars(0, arrayOfChar.length, arrayOfChar, 0);
    return initWithCharacters(arrayOfChar, arrayOfChar.length);
  }
  
  public static NSString stringWith(String paramString)
  {
    char[] arrayOfChar = new char[paramString.length()];
    paramString.getChars(0, arrayOfChar.length, arrayOfChar, 0);
    return stringWithCharacters(arrayOfChar, arrayOfChar.length);
  }
  
  public long UTF8String()
  {
    return OS.objc_msgSend(this.id, OS.sel_UTF8String);
  }
  
  public long characterAtIndex(long paramLong)
  {
    return OS.objc_msgSend(this.id, OS.sel_characterAtIndex_, paramLong);
  }
  
  public long compare(NSString paramNSString)
  {
    return OS.objc_msgSend(this.id, OS.sel_compare_, paramNSString != null ? paramNSString.id : 0L);
  }
  
  public long fileSystemRepresentation()
  {
    return OS.objc_msgSend(this.id, OS.sel_fileSystemRepresentation);
  }
  
  public void getCharacters(char[] paramArrayOfChar)
  {
    OS.objc_msgSend(this.id, OS.sel_getCharacters_, paramArrayOfChar);
  }
  
  public void getCharacters(char[] paramArrayOfChar, NSRange paramNSRange)
  {
    OS.objc_msgSend(this.id, OS.sel_getCharacters_range_, paramArrayOfChar, paramNSRange);
  }
  
  public NSString initWithCharacters(char[] paramArrayOfChar, long paramLong)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_initWithCharacters_length_, paramArrayOfChar, paramLong);
    return l != 0L ? new NSString(l) : l == this.id ? this : null;
  }
  
  public boolean isEqualToString(NSString paramNSString)
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_isEqualToString_, paramNSString != null ? paramNSString.id : 0L);
  }
  
  public NSString lastPathComponent()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_lastPathComponent);
    return l != 0L ? new NSString(l) : l == this.id ? this : null;
  }
  
  public long length()
  {
    return OS.objc_msgSend(this.id, OS.sel_length);
  }
  
  public NSString lowercaseString()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_lowercaseString);
    return l != 0L ? new NSString(l) : l == this.id ? this : null;
  }
  
  public NSString pathExtension()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_pathExtension);
    return l != 0L ? new NSString(l) : l == this.id ? this : null;
  }
  
  public static NSString string()
  {
    long l = OS.objc_msgSend(OS.class_NSString, OS.sel_string);
    return l != 0L ? new NSString(l) : null;
  }
  
  public NSString stringByAddingPercentEscapesUsingEncoding(long paramLong)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_stringByAddingPercentEscapesUsingEncoding_, paramLong);
    return l != 0L ? new NSString(l) : l == this.id ? this : null;
  }
  
  public NSString stringByAppendingPathComponent(NSString paramNSString)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_stringByAppendingPathComponent_, paramNSString != null ? paramNSString.id : 0L);
    return l != 0L ? new NSString(l) : l == this.id ? this : null;
  }
  
  public NSString stringByAppendingPathExtension(NSString paramNSString)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_stringByAppendingPathExtension_, paramNSString != null ? paramNSString.id : 0L);
    return l != 0L ? new NSString(l) : l == this.id ? this : null;
  }
  
  public NSString stringByAppendingString(NSString paramNSString)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_stringByAppendingString_, paramNSString != null ? paramNSString.id : 0L);
    return l != 0L ? new NSString(l) : l == this.id ? this : null;
  }
  
  public NSString stringByDeletingLastPathComponent()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_stringByDeletingLastPathComponent);
    return l != 0L ? new NSString(l) : l == this.id ? this : null;
  }
  
  public NSString stringByDeletingPathExtension()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_stringByDeletingPathExtension);
    return l != 0L ? new NSString(l) : l == this.id ? this : null;
  }
  
  public NSString stringByReplacingOccurrencesOfString(NSString paramNSString1, NSString paramNSString2)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_stringByReplacingOccurrencesOfString_withString_, paramNSString1 != null ? paramNSString1.id : 0L, paramNSString2 != null ? paramNSString2.id : 0L);
    return l != 0L ? new NSString(l) : l == this.id ? this : null;
  }
  
  public NSString stringByReplacingPercentEscapesUsingEncoding(long paramLong)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_stringByReplacingPercentEscapesUsingEncoding_, paramLong);
    return l != 0L ? new NSString(l) : l == this.id ? this : null;
  }
  
  public static NSString stringWithCharacters(char[] paramArrayOfChar, long paramLong)
  {
    long l = OS.objc_msgSend(OS.class_NSString, OS.sel_stringWithCharacters_length_, paramArrayOfChar, paramLong);
    return l != 0L ? new NSString(l) : null;
  }
  
  public static NSString stringWithFormat(NSString paramNSString)
  {
    long l = OS.objc_msgSend(OS.class_NSString, OS.sel_stringWithFormat_, paramNSString != null ? paramNSString.id : 0L);
    return l != 0L ? new NSString(l) : null;
  }
  
  public static NSString stringWithUTF8String(long paramLong)
  {
    long l = OS.objc_msgSend(OS.class_NSString, OS.sel_stringWithUTF8String_, paramLong);
    return l != 0L ? new NSString(l) : null;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSString.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */