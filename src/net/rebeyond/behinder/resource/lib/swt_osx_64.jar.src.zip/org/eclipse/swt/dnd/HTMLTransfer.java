package org.eclipse.swt.dnd;

import org.eclipse.swt.internal.cocoa.NSString;
import org.eclipse.swt.internal.cocoa.OS;

public class HTMLTransfer
  extends ByteArrayTransfer
{
  static HTMLTransfer _instance = new HTMLTransfer();
  static final String HTML = OS.NSHTMLPboardType.getString();
  static final int HTMLID = registerType(HTML);
  
  public static HTMLTransfer getInstance()
  {
    return _instance;
  }
  
  public void javaToNative(Object paramObject, TransferData paramTransferData)
  {
    if ((!checkHTML(paramObject)) || (!isSupportedType(paramTransferData))) {
      DND.error(2003);
    }
    paramTransferData.data = NSString.stringWith((String)paramObject);
  }
  
  public Object nativeToJava(TransferData paramTransferData)
  {
    if ((!isSupportedType(paramTransferData)) || (paramTransferData.data == null)) {
      return null;
    }
    NSString localNSString = (NSString)paramTransferData.data;
    return localNSString.getString();
  }
  
  protected int[] getTypeIds()
  {
    return new int[] { HTMLID };
  }
  
  protected String[] getTypeNames()
  {
    return new String[] { HTML };
  }
  
  boolean checkHTML(Object paramObject)
  {
    return (paramObject != null) && ((paramObject instanceof String)) && (((String)paramObject).length() > 0);
  }
  
  protected boolean validate(Object paramObject)
  {
    return checkHTML(paramObject);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/dnd/HTMLTransfer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */