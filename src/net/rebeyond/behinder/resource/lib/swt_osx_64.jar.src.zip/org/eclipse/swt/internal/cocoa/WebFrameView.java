package org.eclipse.swt.internal.cocoa;

public class WebFrameView
  extends NSObject
{
  public WebFrameView() {}
  
  public WebFrameView(long paramLong)
  {
    super(paramLong);
  }
  
  public WebFrameView(id paramid)
  {
    super(paramid);
  }
  
  public boolean documentViewShouldHandlePrint()
  {
    return OS.objc_msgSend_bool(this.id, OS.sel_documentViewShouldHandlePrint);
  }
  
  public void printDocumentView()
  {
    OS.objc_msgSend(this.id, OS.sel_printDocumentView);
  }
  
  public NSPrintOperation printOperationWithPrintInfo(NSPrintInfo paramNSPrintInfo)
  {
    long l = OS.objc_msgSend(this.id, OS.sel_printOperationWithPrintInfo_, paramNSPrintInfo != null ? paramNSPrintInfo.id : 0L);
    return l != 0L ? new NSPrintOperation(l) : null;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/WebFrameView.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */