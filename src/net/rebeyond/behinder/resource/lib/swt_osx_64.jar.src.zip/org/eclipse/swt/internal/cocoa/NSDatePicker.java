package org.eclipse.swt.internal.cocoa;

public class NSDatePicker
  extends NSControl
{
  public NSDatePicker() {}
  
  public NSDatePicker(long paramLong)
  {
    super(paramLong);
  }
  
  public NSDatePicker(id paramid)
  {
    super(paramid);
  }
  
  public NSDate dateValue()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_dateValue);
    return l != 0L ? new NSDate(l) : null;
  }
  
  public void setBackgroundColor(NSColor paramNSColor)
  {
    OS.objc_msgSend(this.id, OS.sel_setBackgroundColor_, paramNSColor != null ? paramNSColor.id : 0L);
  }
  
  public void setBezeled(boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_setBezeled_, paramBoolean);
  }
  
  public void setBordered(boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_setBordered_, paramBoolean);
  }
  
  public void setDatePickerElements(long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_setDatePickerElements_, paramLong);
  }
  
  public void setDatePickerStyle(long paramLong)
  {
    OS.objc_msgSend(this.id, OS.sel_setDatePickerStyle_, paramLong);
  }
  
  public void setDateValue(NSDate paramNSDate)
  {
    OS.objc_msgSend(this.id, OS.sel_setDateValue_, paramNSDate != null ? paramNSDate.id : 0L);
  }
  
  public void setDrawsBackground(boolean paramBoolean)
  {
    OS.objc_msgSend(this.id, OS.sel_setDrawsBackground_, paramBoolean);
  }
  
  public void setTextColor(NSColor paramNSColor)
  {
    OS.objc_msgSend(this.id, OS.sel_setTextColor_, paramNSColor != null ? paramNSColor.id : 0L);
  }
  
  public static long cellClass()
  {
    return OS.objc_msgSend(OS.class_NSDatePicker, OS.sel_cellClass);
  }
  
  public static void setCellClass(long paramLong)
  {
    OS.objc_msgSend(OS.class_NSDatePicker, OS.sel_setCellClass_, paramLong);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSDatePicker.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */