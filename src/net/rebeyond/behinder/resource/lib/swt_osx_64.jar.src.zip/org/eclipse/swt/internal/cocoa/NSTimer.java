package org.eclipse.swt.internal.cocoa;

public class NSTimer
  extends NSObject
{
  public NSTimer() {}
  
  public NSTimer(long paramLong)
  {
    super(paramLong);
  }
  
  public NSTimer(id paramid)
  {
    super(paramid);
  }
  
  public void invalidate()
  {
    OS.objc_msgSend(this.id, OS.sel_invalidate);
  }
  
  public static NSTimer scheduledTimerWithTimeInterval(double paramDouble, id paramid1, long paramLong, id paramid2, boolean paramBoolean)
  {
    long l = OS.objc_msgSend(OS.class_NSTimer, OS.sel_scheduledTimerWithTimeInterval_target_selector_userInfo_repeats_, paramDouble, paramid1 != null ? paramid1.id : 0L, paramLong, paramid2 != null ? paramid2.id : 0L, paramBoolean);
    return l != 0L ? new NSTimer(l) : null;
  }
  
  public void setFireDate(NSDate paramNSDate)
  {
    OS.objc_msgSend(this.id, OS.sel_setFireDate_, paramNSDate != null ? paramNSDate.id : 0L);
  }
  
  public id userInfo()
  {
    long l = OS.objc_msgSend(this.id, OS.sel_userInfo);
    return l != 0L ? new id(l) : null;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/internal/cocoa/NSTimer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */