package org.eclipse.swt.browser;

import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.Bullet;
import org.eclipse.swt.custom.StyleRange;
import org.eclipse.swt.custom.StyledText;
import org.eclipse.swt.graphics.GlyphMetrics;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.internal.Compatibility;
import org.eclipse.swt.internal.mozilla.IIDStore;
import org.eclipse.swt.internal.mozilla.XPCOM;
import org.eclipse.swt.internal.mozilla.nsICertificateDialogs;
import org.eclipse.swt.internal.mozilla.nsIDOMWindow;
import org.eclipse.swt.internal.mozilla.nsIServiceManager;
import org.eclipse.swt.internal.mozilla.nsIWebBrowser;
import org.eclipse.swt.internal.mozilla.nsIX509Cert;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Dialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Monitor;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Widget;

class PromptDialog
  extends Dialog
{
  PromptDialog(Shell paramShell, int paramInt)
  {
    super(paramShell, paramInt);
  }
  
  PromptDialog(Shell paramShell)
  {
    this(paramShell, 0);
  }
  
  void alertCheck(String paramString1, String paramString2, String paramString3, final boolean[] paramArrayOfBoolean)
  {
    Shell localShell1 = getParent();
    final Shell localShell2 = new Shell(localShell1, 67680);
    if (paramString1 != null) {
      localShell2.setText(paramString1);
    }
    GridLayout localGridLayout = new GridLayout();
    localShell2.setLayout(localGridLayout);
    Label localLabel = new Label(localShell2, 64);
    localLabel.setText(paramString2);
    GridData localGridData = new GridData();
    Monitor localMonitor = localShell1.getMonitor();
    int i = localMonitor.getBounds().width * 2 / 3;
    int j = localLabel.computeSize(-1, -1).x;
    localGridData.widthHint = Math.min(j, i);
    localGridData.horizontalAlignment = 4;
    localGridData.grabExcessHorizontalSpace = true;
    localLabel.setLayoutData(localGridData);
    final Button localButton1 = paramString3 != null ? new Button(localShell2, 32) : null;
    if (localButton1 != null)
    {
      localButton1.setText(paramString3);
      localButton1.setSelection(paramArrayOfBoolean[0]);
      localGridData = new GridData();
      localGridData.horizontalAlignment = 1;
      localButton1.setLayoutData(localGridData);
    }
    Button localButton2 = new Button(localShell2, 8);
    localButton2.setText(SWT.getMessage("SWT_OK"));
    localGridData = new GridData();
    localGridData.horizontalAlignment = 2;
    localButton2.setLayoutData(localGridData);
    localButton2.addListener(13, new Listener()
    {
      public void handleEvent(Event paramAnonymousEvent)
      {
        if (localButton1 != null) {
          paramArrayOfBoolean[0] = localButton1.getSelection();
        }
        localShell2.close();
      }
    });
    localShell2.pack();
    localShell2.open();
    Display localDisplay = localShell1.getDisplay();
    while (!localShell2.isDisposed()) {
      if (!localDisplay.readAndDispatch()) {
        localDisplay.sleep();
      }
    }
  }
  
  boolean invalidCert(final Browser paramBrowser, String paramString, String[] paramArrayOfString, final nsIX509Cert paramnsIX509Cert)
  {
    Shell localShell1 = getParent();
    Display localDisplay = localShell1.getDisplay();
    Monitor localMonitor = localShell1.getMonitor();
    int i = localMonitor.getBounds().width * 2 / 3;
    final Shell localShell2 = new Shell(localShell1, 67680);
    localShell2.setText(Compatibility.getMessage("SWT_InvalidCert_Title"));
    localShell2.setLayout(new GridLayout());
    Composite localComposite1 = new Composite(localShell2, 0);
    localComposite1.setLayout(new GridLayout(2, false));
    Image localImage = localDisplay.getSystemImage(8);
    new Label(localComposite1, 0).setImage(localImage);
    Text localText = new Text(localComposite1, 64);
    localText.setLayoutData(new GridData(4, 16777216, true, false));
    localText.setEditable(false);
    localText.setBackground(localShell2.getBackground());
    localText.setText(paramString);
    int j = localComposite1.computeSize(-1, -1).x;
    GridData localGridData = new GridData();
    localGridData.widthHint = Math.min(j, i);
    localGridData.horizontalAlignment = 4;
    localGridData.grabExcessHorizontalSpace = true;
    localComposite1.setLayoutData(localGridData);
    StyledText localStyledText = new StyledText(localShell2, 64);
    localStyledText.setMargins(30, 0, 30, 0);
    localStyledText.setEditable(false);
    localStyledText.setBackground(localShell2.getBackground());
    for (int k = 0; k < paramArrayOfString.length; k++) {
      localStyledText.append(paramArrayOfString[k] + '\n');
    }
    StyleRange localStyleRange = new StyleRange();
    localStyleRange.metrics = new GlyphMetrics(0, 0, 30);
    Bullet localBullet = new Bullet(localStyleRange);
    localStyledText.setLineBullet(0, paramArrayOfString.length, localBullet);
    j = localStyledText.computeSize(-1, -1).x;
    localGridData = new GridData();
    localGridData.widthHint = Math.min(j, i);
    localGridData.horizontalAlignment = 4;
    localGridData.grabExcessHorizontalSpace = true;
    localStyledText.setLayoutData(localGridData);
    localText = new Text(localShell2, 4);
    localText.setEditable(false);
    localText.setBackground(localShell2.getBackground());
    localText.setText(Compatibility.getMessage("SWT_InvalidCert_Connect"));
    new Label(localShell2, 0);
    final Browser localBrowser = new Browser(localShell2, paramBrowser.getStyle());
    localGridData = new GridData();
    localGridData.exclude = true;
    localBrowser.setLayoutData(localGridData);
    Composite localComposite2 = new Composite(localShell2, 0);
    localComposite2.setLayout(new GridLayout(3, true));
    localComposite2.setLayoutData(new GridData(16777216, 16777216, false, false));
    Button localButton1 = new Button(localComposite2, 8);
    localButton1.setLayoutData(new GridData(4, 4, false, false));
    localButton1.setText(Compatibility.getMessage("SWT_ViewCertificate"));
    localButton1.addListener(13, new Listener()
    {
      public void handleEvent(Event paramAnonymousEvent)
      {
        long[] arrayOfLong = new long[1];
        int i = XPCOM.NS_GetServiceManager(arrayOfLong);
        if (i != 0) {
          Mozilla.error(i);
        }
        if (arrayOfLong[0] == 0L) {
          Mozilla.error(-2147467262);
        }
        nsIServiceManager localnsIServiceManager = new nsIServiceManager(arrayOfLong[0]);
        arrayOfLong[0] = 0L;
        byte[] arrayOfByte = MozillaDelegate.wcsToMbcs(null, "@mozilla.org/nsCertificateDialogs;1", true);
        i = localnsIServiceManager.GetServiceByContractID(arrayOfByte, IIDStore.GetIID(nsICertificateDialogs.class), arrayOfLong);
        if (i != 0) {
          Mozilla.error(i);
        }
        if (arrayOfLong[0] == 0L) {
          Mozilla.error(-2147467262);
        }
        localnsIServiceManager.Release();
        nsICertificateDialogs localnsICertificateDialogs = new nsICertificateDialogs(arrayOfLong[0]);
        arrayOfLong[0] = 0L;
        Runnable local1 = new Runnable()
        {
          public void run()
          {
            PromptDialog.2.this.val$browser.getDisplay().timerExec(1000, this);
          }
        };
        local1.run();
        i = ((Mozilla)localBrowser.webBrowser).webBrowser.GetContentDOMWindow(arrayOfLong);
        if (i != 0) {
          Mozilla.error(i);
        }
        if (arrayOfLong[0] == 0L) {
          Mozilla.error(-2147467262);
        }
        nsIDOMWindow localnsIDOMWindow = new nsIDOMWindow(arrayOfLong[0]);
        arrayOfLong[0] = 0L;
        i = localnsICertificateDialogs.ViewCert(localnsIDOMWindow.getAddress(), paramnsIX509Cert.getAddress());
        paramBrowser.getDisplay().timerExec(-1, local1);
        localnsIDOMWindow.Release();
        localnsICertificateDialogs.Release();
      }
    });
    final Button localButton2 = new Button(localComposite2, 8);
    localButton2.setLayoutData(new GridData(4, 4, false, false));
    localButton2.setText(Compatibility.getMessage("SWT_OK"));
    Button localButton3 = new Button(localComposite2, 8);
    localButton3.setLayoutData(new GridData(4, 4, false, false));
    localButton3.setText(Compatibility.getMessage("SWT_Cancel"));
    final boolean[] arrayOfBoolean = new boolean[1];
    Listener local3 = new Listener()
    {
      public void handleEvent(Event paramAnonymousEvent)
      {
        localShell2.dispose();
        arrayOfBoolean[0] = (paramAnonymousEvent.widget == localButton2 ? 1 : false);
      }
    };
    localButton2.addListener(13, local3);
    localButton3.addListener(13, local3);
    localButton3.setFocus();
    localShell2.setDefaultButton(localButton3);
    localShell2.pack();
    localShell2.open();
    while (!localShell2.isDisposed()) {
      if (!localDisplay.readAndDispatch()) {
        localDisplay.sleep();
      }
    }
    return arrayOfBoolean[0];
  }
  
  void confirmEx(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, int paramInt, final boolean[] paramArrayOfBoolean, final int[] paramArrayOfInt)
  {
    Shell localShell1 = getParent();
    final Shell localShell2 = new Shell(localShell1, 67680);
    localShell2.setText(paramString1);
    GridLayout localGridLayout1 = new GridLayout();
    localShell2.setLayout(localGridLayout1);
    Label localLabel = new Label(localShell2, 64);
    localLabel.setText(paramString2);
    GridData localGridData = new GridData();
    Monitor localMonitor = localShell1.getMonitor();
    int i = localMonitor.getBounds().width * 2 / 3;
    int j = localLabel.computeSize(-1, -1).x;
    localGridData.widthHint = Math.min(j, i);
    localGridData.horizontalAlignment = 4;
    localGridData.grabExcessHorizontalSpace = true;
    localLabel.setLayoutData(localGridData);
    final Button[] arrayOfButton = new Button[4];
    Listener local4 = new Listener()
    {
      public void handleEvent(Event paramAnonymousEvent)
      {
        if (arrayOfButton[0] != null) {
          paramArrayOfBoolean[0] = arrayOfButton[0].getSelection();
        }
        Widget localWidget = paramAnonymousEvent.widget;
        for (int i = 1; i < arrayOfButton.length; i++) {
          if (localWidget == arrayOfButton[i])
          {
            paramArrayOfInt[0] = (i - 1);
            break;
          }
        }
        localShell2.close();
      }
    };
    if (paramString3 != null)
    {
      arrayOfButton[0] = new Button(localShell2, 32);
      arrayOfButton[0].setText(paramString3);
      arrayOfButton[0].setSelection(paramArrayOfBoolean[0]);
      localGridData = new GridData();
      localGridData.horizontalAlignment = 1;
      arrayOfButton[0].setLayoutData(localGridData);
    }
    Composite localComposite = new Composite(localShell2, 0);
    localGridData = new GridData();
    localGridData.horizontalAlignment = 2;
    localComposite.setLayoutData(localGridData);
    GridLayout localGridLayout2 = new GridLayout();
    localGridLayout2.makeColumnsEqualWidth = true;
    localComposite.setLayout(localGridLayout2);
    int k = 0;
    if (paramString4 != null)
    {
      arrayOfButton[1] = new Button(localComposite, 8);
      arrayOfButton[1].setText(paramString4);
      arrayOfButton[1].addListener(13, local4);
      arrayOfButton[1].setLayoutData(new GridData(768));
      k++;
    }
    if (paramString5 != null)
    {
      arrayOfButton[2] = new Button(localComposite, 8);
      arrayOfButton[2].setText(paramString5);
      arrayOfButton[2].addListener(13, local4);
      arrayOfButton[2].setLayoutData(new GridData(768));
      k++;
    }
    if (paramString6 != null)
    {
      arrayOfButton[3] = new Button(localComposite, 8);
      arrayOfButton[3].setText(paramString6);
      arrayOfButton[3].addListener(13, local4);
      arrayOfButton[3].setLayoutData(new GridData(768));
      k++;
    }
    localGridLayout2.numColumns = k;
    Button localButton = arrayOfButton[(paramInt + 1)];
    if (localButton != null) {
      localShell2.setDefaultButton(localButton);
    }
    localShell2.pack();
    localShell2.open();
    Display localDisplay = localShell1.getDisplay();
    while (!localShell2.isDisposed()) {
      if (!localDisplay.readAndDispatch()) {
        localDisplay.sleep();
      }
    }
  }
  
  void prompt(String paramString1, String paramString2, String paramString3, final String[] paramArrayOfString, final boolean[] paramArrayOfBoolean1, final boolean[] paramArrayOfBoolean2)
  {
    Shell localShell1 = getParent();
    final Shell localShell2 = new Shell(localShell1, 67680);
    if (paramString1 != null) {
      localShell2.setText(paramString1);
    }
    GridLayout localGridLayout = new GridLayout();
    localShell2.setLayout(localGridLayout);
    Label localLabel = new Label(localShell2, 64);
    localLabel.setText(paramString2);
    GridData localGridData = new GridData();
    Monitor localMonitor = localShell1.getMonitor();
    int i = localMonitor.getBounds().width * 2 / 3;
    int j = localLabel.computeSize(-1, -1).x;
    localGridData.widthHint = Math.min(j, i);
    localGridData.horizontalAlignment = 4;
    localGridData.grabExcessHorizontalSpace = true;
    localLabel.setLayoutData(localGridData);
    final Text localText = new Text(localShell2, 2048);
    if (paramArrayOfString[0] != null) {
      localText.setText(paramArrayOfString[0]);
    }
    localGridData = new GridData();
    j = localText.computeSize(-1, -1).x;
    if (j > i) {
      localGridData.widthHint = i;
    }
    localGridData.horizontalAlignment = 4;
    localGridData.grabExcessHorizontalSpace = true;
    localText.setLayoutData(localGridData);
    final Button[] arrayOfButton = new Button[3];
    Listener local5 = new Listener()
    {
      public void handleEvent(Event paramAnonymousEvent)
      {
        if (arrayOfButton[0] != null) {
          paramArrayOfBoolean1[0] = arrayOfButton[0].getSelection();
        }
        paramArrayOfString[0] = localText.getText();
        paramArrayOfBoolean2[0] = (paramAnonymousEvent.widget == arrayOfButton[1] ? 1 : false);
        localShell2.close();
      }
    };
    if (paramString3 != null)
    {
      arrayOfButton[0] = new Button(localShell2, 32);
      arrayOfButton[0].setText(paramString3);
      arrayOfButton[0].setSelection(paramArrayOfBoolean1[0]);
      localGridData = new GridData();
      localGridData.horizontalAlignment = 1;
      arrayOfButton[0].setLayoutData(localGridData);
    }
    Composite localComposite = new Composite(localShell2, 0);
    localGridData = new GridData();
    localGridData.horizontalAlignment = 2;
    localComposite.setLayoutData(localGridData);
    localComposite.setLayout(new GridLayout(2, true));
    arrayOfButton[1] = new Button(localComposite, 8);
    arrayOfButton[1].setText(SWT.getMessage("SWT_OK"));
    arrayOfButton[1].setLayoutData(new GridData(768));
    arrayOfButton[1].addListener(13, local5);
    arrayOfButton[2] = new Button(localComposite, 8);
    arrayOfButton[2].setText(SWT.getMessage("SWT_Cancel"));
    arrayOfButton[2].setLayoutData(new GridData(768));
    arrayOfButton[2].addListener(13, local5);
    localShell2.pack();
    localShell2.open();
    Display localDisplay = localShell1.getDisplay();
    while (!localShell2.isDisposed()) {
      if (!localDisplay.readAndDispatch()) {
        localDisplay.sleep();
      }
    }
  }
  
  void promptUsernameAndPassword(String paramString1, String paramString2, String paramString3, final String[] paramArrayOfString1, final String[] paramArrayOfString2, final boolean[] paramArrayOfBoolean1, final boolean[] paramArrayOfBoolean2)
  {
    Shell localShell1 = getParent();
    final Shell localShell2 = new Shell(localShell1, 67680);
    localShell2.setText(paramString1);
    GridLayout localGridLayout = new GridLayout();
    localShell2.setLayout(localGridLayout);
    Label localLabel1 = new Label(localShell2, 64);
    localLabel1.setText(paramString2);
    GridData localGridData = new GridData();
    Monitor localMonitor = localShell1.getMonitor();
    int i = localMonitor.getBounds().width * 2 / 3;
    int j = localLabel1.computeSize(-1, -1).x;
    localGridData.widthHint = Math.min(j, i);
    localGridData.horizontalAlignment = 4;
    localGridData.grabExcessHorizontalSpace = true;
    localLabel1.setLayoutData(localGridData);
    Label localLabel2 = new Label(localShell2, 0);
    localLabel2.setText(SWT.getMessage("SWT_Username"));
    final Text localText1 = new Text(localShell2, 2048);
    if (paramArrayOfString1[0] != null) {
      localText1.setText(paramArrayOfString1[0]);
    }
    localGridData = new GridData();
    localGridData.horizontalAlignment = 4;
    localGridData.grabExcessHorizontalSpace = true;
    localText1.setLayoutData(localGridData);
    Label localLabel3 = new Label(localShell2, 0);
    localLabel3.setText(SWT.getMessage("SWT_Password"));
    final Text localText2 = new Text(localShell2, 4196352);
    if (paramArrayOfString2[0] != null) {
      localText2.setText(paramArrayOfString2[0]);
    }
    localGridData = new GridData();
    localGridData.horizontalAlignment = 4;
    localGridData.grabExcessHorizontalSpace = true;
    localText2.setLayoutData(localGridData);
    final Button[] arrayOfButton = new Button[3];
    Listener local6 = new Listener()
    {
      public void handleEvent(Event paramAnonymousEvent)
      {
        if (arrayOfButton[0] != null) {
          paramArrayOfBoolean1[0] = arrayOfButton[0].getSelection();
        }
        paramArrayOfString1[0] = localText1.getText();
        paramArrayOfString2[0] = localText2.getText();
        paramArrayOfBoolean2[0] = (paramAnonymousEvent.widget == arrayOfButton[1] ? 1 : false);
        localShell2.close();
      }
    };
    if (paramString3 != null)
    {
      arrayOfButton[0] = new Button(localShell2, 32);
      arrayOfButton[0].setText(paramString3);
      arrayOfButton[0].setSelection(paramArrayOfBoolean1[0]);
      localGridData = new GridData();
      localGridData.horizontalAlignment = 1;
      arrayOfButton[0].setLayoutData(localGridData);
    }
    Composite localComposite = new Composite(localShell2, 0);
    localGridData = new GridData();
    localGridData.horizontalAlignment = 2;
    localComposite.setLayoutData(localGridData);
    localComposite.setLayout(new GridLayout(2, true));
    arrayOfButton[1] = new Button(localComposite, 8);
    arrayOfButton[1].setText(SWT.getMessage("SWT_OK"));
    arrayOfButton[1].setLayoutData(new GridData(768));
    arrayOfButton[1].addListener(13, local6);
    arrayOfButton[2] = new Button(localComposite, 8);
    arrayOfButton[2].setText(SWT.getMessage("SWT_Cancel"));
    arrayOfButton[2].setLayoutData(new GridData(768));
    arrayOfButton[2].addListener(13, local6);
    localShell2.setDefaultButton(arrayOfButton[1]);
    localShell2.pack();
    localShell2.open();
    Display localDisplay = localShell1.getDisplay();
    while (!localShell2.isDisposed()) {
      if (!localDisplay.readAndDispatch()) {
        localDisplay.sleep();
      }
    }
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/browser/PromptDialog.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */