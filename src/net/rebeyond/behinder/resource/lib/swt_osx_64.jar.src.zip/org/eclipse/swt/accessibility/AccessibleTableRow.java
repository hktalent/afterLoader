package org.eclipse.swt.accessibility;

import java.util.Vector;
import org.eclipse.swt.internal.cocoa.NSArray;
import org.eclipse.swt.internal.cocoa.NSNumber;
import org.eclipse.swt.internal.cocoa.NSPoint;
import org.eclipse.swt.internal.cocoa.NSRect;
import org.eclipse.swt.internal.cocoa.NSScreen;
import org.eclipse.swt.internal.cocoa.NSSize;
import org.eclipse.swt.internal.cocoa.NSValue;

class AccessibleTableRow
  extends Accessible
{
  public AccessibleTableRow(Accessible paramAccessible, int paramInt)
  {
    super(paramAccessible);
    this.index = paramInt;
    addAccessibleControlListener(new AccessibleControlAdapter()
    {
      public void getChildCount(AccessibleControlEvent paramAnonymousAccessibleControlEvent)
      {
        paramAnonymousAccessibleControlEvent.detail = Math.max(1, AccessibleTableRow.this.parent.getColumnCount());
      }
      
      public void getChildren(AccessibleControlEvent paramAnonymousAccessibleControlEvent)
      {
        int i = Math.max(1, AccessibleTableRow.this.parent.getColumnCount());
        Object[] arrayOfObject = new Object[i];
        AccessibleTableEvent localAccessibleTableEvent = new AccessibleTableEvent(this);
        for (int j = 0; j < i; j++)
        {
          localAccessibleTableEvent.column = j;
          localAccessibleTableEvent.row = AccessibleTableRow.this.index;
          for (int k = 0; k < AccessibleTableRow.this.parent.accessibleTableListeners.size(); k++)
          {
            AccessibleTableListener localAccessibleTableListener = (AccessibleTableListener)AccessibleTableRow.this.parent.accessibleTableListeners.elementAt(k);
            localAccessibleTableListener.getCell(localAccessibleTableEvent);
          }
          if (localAccessibleTableEvent.accessible != null) {
            localAccessibleTableEvent.accessible.parent = AccessibleTableRow.this;
          }
          arrayOfObject[j] = localAccessibleTableEvent.accessible;
        }
        paramAnonymousAccessibleControlEvent.children = arrayOfObject;
      }
      
      public void getLocation(AccessibleControlEvent paramAnonymousAccessibleControlEvent)
      {
        int i = Math.max(1, AccessibleTableRow.this.parent.getColumnCount());
        Accessible[] arrayOfAccessible = new Accessible[i];
        AccessibleTableEvent localAccessibleTableEvent = new AccessibleTableEvent(this);
        for (int j = 0; j < i; j++)
        {
          localAccessibleTableEvent.column = j;
          localAccessibleTableEvent.row = AccessibleTableRow.this.index;
          for (int k = 0; k < AccessibleTableRow.this.parent.accessibleTableListeners.size(); k++)
          {
            AccessibleTableListener localAccessibleTableListener = (AccessibleTableListener)AccessibleTableRow.this.parent.accessibleTableListeners.elementAt(k);
            localAccessibleTableListener.getCell(localAccessibleTableEvent);
          }
          arrayOfAccessible[j] = localAccessibleTableEvent.accessible;
        }
        NSValue localNSValue = (NSValue)arrayOfAccessible[0].getPositionAttribute(-1);
        NSPoint localNSPoint = localNSValue.pointValue();
        int m = 0;
        int n = 0;
        for (int i1 = 0; i1 < arrayOfAccessible.length; i1++)
        {
          localObject1 = (NSValue)arrayOfAccessible[i1].getSizeAttribute(-1);
          localObject2 = ((NSValue)localObject1).sizeValue();
          if (((NSSize)localObject2).height > m) {
            m = (int)((NSSize)localObject2).height;
          }
          n = (int)(n + ((NSSize)localObject2).width);
        }
        paramAnonymousAccessibleControlEvent.x = ((int)localNSPoint.x);
        NSArray localNSArray = NSScreen.screens();
        Object localObject1 = new NSScreen(localNSArray.objectAtIndex(0L));
        Object localObject2 = ((NSScreen)localObject1).frame();
        paramAnonymousAccessibleControlEvent.y = ((int)(((NSRect)localObject2).height - localNSPoint.y - m));
        paramAnonymousAccessibleControlEvent.width = n;
        paramAnonymousAccessibleControlEvent.height = m;
      }
      
      public void getRole(AccessibleControlEvent paramAnonymousAccessibleControlEvent)
      {
        int i = paramAnonymousAccessibleControlEvent.childID;
        if (i == -1) {
          paramAnonymousAccessibleControlEvent.detail = 28;
        } else {
          paramAnonymousAccessibleControlEvent.detail = 29;
        }
      }
      
      public void getFocus(AccessibleControlEvent paramAnonymousAccessibleControlEvent)
      {
        AccessibleTableEvent localAccessibleTableEvent = new AccessibleTableEvent(this);
        localAccessibleTableEvent.column = 0;
        localAccessibleTableEvent.row = AccessibleTableRow.this.index;
        for (int i = 0; i < AccessibleTableRow.this.parent.accessibleTableListeners.size(); i++)
        {
          AccessibleTableListener localAccessibleTableListener = (AccessibleTableListener)AccessibleTableRow.this.parent.accessibleTableListeners.elementAt(i);
          localAccessibleTableListener.getCell(localAccessibleTableEvent);
        }
        if (localAccessibleTableEvent.accessible != null)
        {
          NSNumber localNSNumber = (NSNumber)localAccessibleTableEvent.accessible.getFocusedAttribute(-1);
          paramAnonymousAccessibleControlEvent.childID = (localNSNumber.boolValue() ? -1 : -2);
        }
        else
        {
          paramAnonymousAccessibleControlEvent.childID = -2;
        }
      }
    });
    addAccessibleTableListener(new AccessibleTableAdapter()
    {
      public void isColumnSelected(AccessibleTableEvent paramAnonymousAccessibleTableEvent)
      {
        paramAnonymousAccessibleTableEvent.isSelected = false;
      }
      
      public void isRowSelected(AccessibleTableEvent paramAnonymousAccessibleTableEvent)
      {
        AccessibleTableEvent localAccessibleTableEvent = new AccessibleTableEvent(this);
        localAccessibleTableEvent.row = paramAnonymousAccessibleTableEvent.row;
        for (int i = 0; i < AccessibleTableRow.this.parent.accessibleTableListeners.size(); i++)
        {
          AccessibleTableListener localAccessibleTableListener = (AccessibleTableListener)AccessibleTableRow.this.parent.accessibleTableListeners.elementAt(i);
          localAccessibleTableListener.isRowSelected(localAccessibleTableEvent);
        }
        paramAnonymousAccessibleTableEvent.isSelected = localAccessibleTableEvent.isSelected;
      }
    });
  }
  
  void getChildAtPoint(AccessibleControlEvent paramAccessibleControlEvent)
  {
    int i = Math.max(1, this.parent.getColumnCount());
    Accessible[] arrayOfAccessible = new Accessible[i];
    AccessibleTableEvent localAccessibleTableEvent = new AccessibleTableEvent(this);
    Object localObject;
    for (int j = 0; j < i; j++)
    {
      localAccessibleTableEvent.column = j;
      localAccessibleTableEvent.row = this.index;
      for (int k = 0; k < this.parent.accessibleTableListeners.size(); k++)
      {
        localObject = (AccessibleTableListener)this.parent.accessibleTableListeners.elementAt(k);
        ((AccessibleTableListener)localObject).getCell(localAccessibleTableEvent);
      }
      arrayOfAccessible[j] = localAccessibleTableEvent.accessible;
    }
    for (j = 0; j < arrayOfAccessible.length; j++)
    {
      NSValue localNSValue1 = (NSValue)arrayOfAccessible[j].getPositionAttribute(this.index);
      localObject = localNSValue1.pointValue();
      NSValue localNSValue2 = (NSValue)arrayOfAccessible[j].getSizeAttribute(this.index);
      NSSize localNSSize = localNSValue2.sizeValue();
      if ((((NSPoint)localObject).x <= paramAccessibleControlEvent.x) && (paramAccessibleControlEvent.x <= ((NSPoint)localObject).x + localNSSize.width))
      {
        arrayOfAccessible[j].parent = this;
        paramAccessibleControlEvent.accessible = arrayOfAccessible[j];
        break;
      }
    }
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_osx_64.jar!/org/eclipse/swt/accessibility/AccessibleTableRow.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */