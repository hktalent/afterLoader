package org.eclipse.swt.browser;

import java.util.Random;
import org.eclipse.swt.SWT;

public class BrowserFunction
{
  Browser browser;
  String name;
  String functionString;
  int index;
  boolean isEvaluate;
  boolean top;
  String token;
  String[] frameNames;
  
  public BrowserFunction(Browser paramBrowser, String paramString)
  {
    this(paramBrowser, paramString, true, null, true);
  }
  
  public BrowserFunction(Browser paramBrowser, String paramString, boolean paramBoolean, String[] paramArrayOfString)
  {
    this(paramBrowser, paramString, paramBoolean, paramArrayOfString, true);
  }
  
  BrowserFunction(Browser paramBrowser, String paramString, boolean paramBoolean1, String[] paramArrayOfString, boolean paramBoolean2)
  {
    if (paramBrowser == null) {
      SWT.error(4);
    }
    if (paramString == null) {
      SWT.error(4);
    }
    if (paramBrowser.isDisposed()) {
      SWT.error(24);
    }
    paramBrowser.checkWidget();
    this.browser = paramBrowser;
    this.name = paramString;
    this.top = paramBoolean1;
    this.frameNames = paramArrayOfString;
    Random localRandom = new Random();
    byte[] arrayOfByte = new byte[16];
    localRandom.nextBytes(arrayOfByte);
    StringBuffer localStringBuffer = new StringBuffer();
    for (int i = 0; i < arrayOfByte.length; i++) {
      localStringBuffer.append(Integer.toHexString(arrayOfByte[i] & 0xFF));
    }
    this.token = localStringBuffer.toString();
    if (paramBoolean2) {
      paramBrowser.webBrowser.createFunction(this);
    }
  }
  
  public void dispose()
  {
    dispose(true);
  }
  
  void dispose(boolean paramBoolean)
  {
    if (this.index < 0) {
      return;
    }
    if (paramBoolean) {
      this.browser.webBrowser.destroyFunction(this);
    }
    this.browser = null;
    this.name = (this.functionString = null);
    this.index = -1;
  }
  
  public Object function(Object[] paramArrayOfObject)
  {
    if (this.index < 0) {
      SWT.error(49);
    }
    this.browser.checkWidget();
    return null;
  }
  
  public Browser getBrowser()
  {
    if (this.index < 0) {
      SWT.error(49);
    }
    this.browser.checkWidget();
    return this.browser;
  }
  
  public String getName()
  {
    if (this.index < 0) {
      SWT.error(49);
    }
    this.browser.checkWidget();
    return this.name;
  }
  
  public boolean isDisposed()
  {
    return this.index < 0;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/browser/BrowserFunction.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */