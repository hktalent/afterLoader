package org.eclipse.swt.graphics;

import org.eclipse.swt.SWT;
import org.eclipse.swt.SWTError;
import org.eclipse.swt.internal.Callback;
import org.eclipse.swt.internal.Compatibility;
import org.eclipse.swt.internal.Converter;
import org.eclipse.swt.internal.gtk.GdkColor;
import org.eclipse.swt.internal.gtk.OS;

public abstract class Device
  implements Drawable
{
  protected int xDisplay;
  int shellHandle;
  public static boolean DEBUG;
  boolean debug = DEBUG;
  boolean tracking = DEBUG;
  Error[] errors;
  Object[] objects;
  Object trackingLock;
  GdkColor[] gdkColors;
  int[] colorRefCount;
  boolean disposed;
  int logProc;
  Callback logCallback;
  String[] log_domains = { "", "GLib-GObject", "GLib", "GObject", "Pango", "ATK", "GdkPixbuf", "Gdk", "Gtk", "GnomeVFS", "GIO" };
  int[] handler_ids = new int[this.log_domains.length];
  int warningLevel;
  static Callback XErrorCallback;
  static Callback XIOErrorCallback;
  static int XErrorProc;
  static int XIOErrorProc;
  static int XNullErrorProc;
  static int XNullIOErrorProc;
  static Device[] Devices = new Device[4];
  Color COLOR_BLACK;
  Color COLOR_DARK_RED;
  Color COLOR_DARK_GREEN;
  Color COLOR_DARK_YELLOW;
  Color COLOR_DARK_BLUE;
  Color COLOR_DARK_MAGENTA;
  Color COLOR_DARK_CYAN;
  Color COLOR_GRAY;
  Color COLOR_DARK_GRAY;
  Color COLOR_RED;
  Color COLOR_GREEN;
  Color COLOR_YELLOW;
  Color COLOR_BLUE;
  Color COLOR_MAGENTA;
  Color COLOR_CYAN;
  Color COLOR_WHITE;
  Font systemFont;
  Point dpi;
  int emptyTab;
  boolean useXRender;
  static boolean CAIRO_LOADED;
  protected static Device CurrentDevice;
  protected static Runnable DeviceFinder;
  
  static synchronized Device getDevice()
  {
    if (DeviceFinder != null) {
      DeviceFinder.run();
    }
    Device localDevice = CurrentDevice;
    CurrentDevice = null;
    return localDevice;
  }
  
  public Device()
  {
    this(null);
  }
  
  public Device(DeviceData paramDeviceData)
  {
    synchronized (Device.class)
    {
      if (paramDeviceData != null)
      {
        this.debug = paramDeviceData.debug;
        this.tracking = paramDeviceData.tracking;
      }
      if (this.tracking)
      {
        this.errors = new Error[''];
        this.objects = new Object[''];
        this.trackingLock = new Object();
      }
      create(paramDeviceData);
      init();
      register(this);
    }
  }
  
  void checkCairo()
  {
    if (CAIRO_LOADED) {
      return;
    }
    try
    {
      int i = OS.RTLD_LAZY;
      byte[] arrayOfByte;
      if (OS.IsAIX)
      {
        arrayOfByte = Converter.wcsToMbcs(null, "libcairo.a(libcairo.so.2)", true);
        i |= 0x40000;
      }
      else if (OS.IsHPUX)
      {
        arrayOfByte = Converter.wcsToMbcs(null, "libcairo.so", true);
      }
      else
      {
        arrayOfByte = Converter.wcsToMbcs(null, "libcairo.so.2", true);
      }
      int j = OS.dlopen(arrayOfByte, i);
      if (j != 0) {
        OS.dlclose(j);
      } else {
        try
        {
          System.loadLibrary("cairo-swt");
        }
        catch (UnsatisfiedLinkError localUnsatisfiedLinkError) {}
      }
      Class.forName("org.eclipse.swt.internal.cairo.Cairo");
      CAIRO_LOADED = true;
    }
    catch (Throwable localThrowable)
    {
      SWT.error(16, localThrowable, " [Cairo is required]");
    }
  }
  
  protected void checkDevice()
  {
    if (this.disposed) {
      SWT.error(45);
    }
  }
  
  protected void create(DeviceData paramDeviceData) {}
  
  public void dispose()
  {
    synchronized (Device.class)
    {
      if (isDisposed()) {
        return;
      }
      checkDevice();
      release();
      destroy();
      deregister(this);
      this.xDisplay = 0;
      this.disposed = true;
      if (this.tracking) {
        synchronized (this.trackingLock)
        {
          this.objects = null;
          this.errors = null;
          this.trackingLock = null;
        }
      }
    }
  }
  
  void dispose_Object(Object paramObject)
  {
    synchronized (this.trackingLock)
    {
      for (int i = 0; i < this.objects.length; i++) {
        if (this.objects[i] == paramObject)
        {
          this.objects[i] = null;
          this.errors[i] = null;
          return;
        }
      }
    }
  }
  
  static synchronized Device findDevice(int paramInt)
  {
    for (int i = 0; i < Devices.length; i++)
    {
      Device localDevice = Devices[i];
      if ((localDevice != null) && (localDevice.xDisplay == paramInt)) {
        return localDevice;
      }
    }
    return null;
  }
  
  static synchronized void deregister(Device paramDevice)
  {
    for (int i = 0; i < Devices.length; i++) {
      if (paramDevice == Devices[i]) {
        Devices[i] = null;
      }
    }
  }
  
  protected void destroy() {}
  
  public Rectangle getBounds()
  {
    checkDevice();
    return new Rectangle(0, 0, 0, 0);
  }
  
  public DeviceData getDeviceData()
  {
    checkDevice();
    DeviceData localDeviceData = new DeviceData();
    localDeviceData.debug = this.debug;
    localDeviceData.tracking = this.tracking;
    if (this.tracking)
    {
      synchronized (this.trackingLock)
      {
        int i = 0;
        int j = this.objects.length;
        for (int k = 0; k < j; k++) {
          if (this.objects[k] != null) {
            i++;
          }
        }
        k = 0;
        localDeviceData.objects = new Object[i];
        localDeviceData.errors = new Error[i];
        for (int m = 0; m < j; m++) {
          if (this.objects[m] != null)
          {
            localDeviceData.objects[k] = this.objects[m];
            localDeviceData.errors[k] = this.errors[m];
            k++;
          }
        }
      }
    }
    else
    {
      localDeviceData.objects = new Object[0];
      localDeviceData.errors = new Error[0];
    }
    return localDeviceData;
  }
  
  public Rectangle getClientArea()
  {
    checkDevice();
    return getBounds();
  }
  
  public int getDepth()
  {
    checkDevice();
    return 0;
  }
  
  public Point getDPI()
  {
    checkDevice();
    return getScreenDPI();
  }
  
  public FontData[] getFontList(String paramString, boolean paramBoolean)
  {
    checkDevice();
    if (!paramBoolean) {
      return new FontData[0];
    }
    int[] arrayOfInt1 = new int[1];
    int[] arrayOfInt2 = new int[1];
    int[] arrayOfInt3 = new int[1];
    int[] arrayOfInt4 = new int[1];
    int[] arrayOfInt5 = new int[1];
    int[] arrayOfInt6 = new int[1];
    int i = OS.gdk_pango_context_get();
    OS.pango_context_list_families(i, arrayOfInt3, arrayOfInt4);
    int j = 0;
    Object localObject1 = new FontData[paramString != null ? 4 : arrayOfInt4[0]];
    for (int k = 0; k < arrayOfInt4[0]; k++)
    {
      OS.memmove(arrayOfInt1, arrayOfInt3[0] + k * OS.PTR_SIZEOF, OS.PTR_SIZEOF);
      boolean bool = true;
      int m;
      int n;
      Object localObject2;
      Object localObject3;
      if (paramString != null)
      {
        m = OS.pango_font_family_get_name(arrayOfInt1[0]);
        n = OS.strlen(m);
        localObject2 = new byte[n];
        OS.memmove((byte[])localObject2, m, n);
        localObject3 = new String(Converter.mbcsToWcs(null, (byte[])localObject2));
        bool = Compatibility.equalsIgnoreCase(paramString, (String)localObject3);
      }
      if (bool)
      {
        OS.pango_font_family_list_faces(arrayOfInt1[0], arrayOfInt5, arrayOfInt6);
        for (m = 0; m < arrayOfInt6[0]; m++)
        {
          OS.memmove(arrayOfInt2, arrayOfInt5[0] + m * OS.PTR_SIZEOF, OS.PTR_SIZEOF);
          n = OS.pango_font_face_describe(arrayOfInt2[0]);
          localObject2 = Font.gtk_new(this, n);
          localObject3 = localObject2.getFontData()[0];
          if (j == localObject1.length)
          {
            FontData[] arrayOfFontData2 = new FontData[localObject1.length + arrayOfInt4[0]];
            System.arraycopy(localObject1, 0, arrayOfFontData2, 0, j);
            localObject1 = arrayOfFontData2;
          }
          localObject1[(j++)] = localObject3;
          OS.pango_font_description_free(n);
        }
        OS.g_free(arrayOfInt5[0]);
        if (paramString != null) {
          break;
        }
      }
    }
    OS.g_free(arrayOfInt3[0]);
    OS.g_object_unref(i);
    if (j == localObject1.length) {
      return (FontData[])localObject1;
    }
    FontData[] arrayOfFontData1 = new FontData[j];
    System.arraycopy(localObject1, 0, arrayOfFontData1, 0, j);
    return arrayOfFontData1;
  }
  
  Point getScreenDPI()
  {
    int i = OS.gdk_screen_width_mm();
    int j = OS.gdk_screen_width();
    int k = Compatibility.round(254 * j, i * 10);
    return new Point(k, k);
  }
  
  public Color getSystemColor(int paramInt)
  {
    checkDevice();
    switch (paramInt)
    {
    case 2: 
      return this.COLOR_BLACK;
    case 4: 
      return this.COLOR_DARK_RED;
    case 6: 
      return this.COLOR_DARK_GREEN;
    case 8: 
      return this.COLOR_DARK_YELLOW;
    case 10: 
      return this.COLOR_DARK_BLUE;
    case 12: 
      return this.COLOR_DARK_MAGENTA;
    case 14: 
      return this.COLOR_DARK_CYAN;
    case 15: 
      return this.COLOR_GRAY;
    case 16: 
      return this.COLOR_DARK_GRAY;
    case 3: 
      return this.COLOR_RED;
    case 5: 
      return this.COLOR_GREEN;
    case 7: 
      return this.COLOR_YELLOW;
    case 9: 
      return this.COLOR_BLUE;
    case 11: 
      return this.COLOR_MAGENTA;
    case 13: 
      return this.COLOR_CYAN;
    case 1: 
      return this.COLOR_WHITE;
    }
    return this.COLOR_BLACK;
  }
  
  public Font getSystemFont()
  {
    checkDevice();
    return this.systemFont;
  }
  
  public boolean getWarnings()
  {
    checkDevice();
    return this.warningLevel == 0;
  }
  
  protected void init()
  {
    this.dpi = getDPI();
    Object localObject1;
    if ((this.xDisplay != 0) && (!OS.USE_CAIRO))
    {
      int[] arrayOfInt1 = new int[1];
      localObject1 = new int[1];
      if (OS.XRenderQueryExtension(this.xDisplay, arrayOfInt1, (int[])localObject1))
      {
        int[] arrayOfInt2 = new int[1];
        int[] arrayOfInt3 = new int[1];
        OS.XRenderQueryVersion(this.xDisplay, arrayOfInt2, arrayOfInt3);
        this.useXRender = ((arrayOfInt2[0] > 0) || ((arrayOfInt2[0] == 0) && (arrayOfInt3[0] >= 8)));
      }
    }
    int i = (OS.IsAIX) && (OS.PTR_SIZEOF == 8) ? 1 : 0;
    if (((this.debug) || (i != 0)) && (this.xDisplay != 0))
    {
      localObject1 = getClass();
      synchronized (localObject1)
      {
        for (int m = 0; (m < Devices.length) && (Devices[m] == null); m++) {}
        if (m == Devices.length)
        {
          XErrorCallback = new Callback(localObject1, "XErrorProc", 2);
          XNullErrorProc = XErrorCallback.getAddress();
          if (XNullErrorProc == 0) {
            SWT.error(3);
          }
          XIOErrorCallback = new Callback(localObject1, "XIOErrorProc", 1);
          XNullIOErrorProc = XIOErrorCallback.getAddress();
          if (XNullIOErrorProc == 0) {
            SWT.error(3);
          }
          XErrorProc = OS.XSetErrorHandler(XNullErrorProc);
          XIOErrorProc = OS.XSetIOErrorHandler(XNullIOErrorProc);
        }
      }
      if (this.debug) {
        OS.XSynchronize(this.xDisplay, true);
      }
    }
    int k;
    if (this.xDisplay != 0)
    {
      this.logCallback = new Callback(this, "logProc", 4);
      this.logProc = this.logCallback.getAddress();
      if (this.logProc == 0) {
        SWT.error(3);
      }
      if (this.debug)
      {
        j = -1;
        for (k = 0; k < this.log_domains.length; k++)
        {
          localObject2 = Converter.wcsToMbcs(null, this.log_domains[k], true);
          this.handler_ids[k] = OS.g_log_set_handler((byte[])localObject2, j, this.logProc, 0);
        }
      }
    }
    this.COLOR_BLACK = new Color(this, 0, 0, 0);
    this.COLOR_DARK_RED = new Color(this, 128, 0, 0);
    this.COLOR_DARK_GREEN = new Color(this, 0, 128, 0);
    this.COLOR_DARK_YELLOW = new Color(this, 128, 128, 0);
    this.COLOR_DARK_BLUE = new Color(this, 0, 0, 128);
    this.COLOR_DARK_MAGENTA = new Color(this, 128, 0, 128);
    this.COLOR_DARK_CYAN = new Color(this, 0, 128, 128);
    this.COLOR_GRAY = new Color(this, 192, 192, 192);
    this.COLOR_DARK_GRAY = new Color(this, 128, 128, 128);
    this.COLOR_RED = new Color(this, 255, 0, 0);
    this.COLOR_GREEN = new Color(this, 0, 255, 0);
    this.COLOR_YELLOW = new Color(this, 255, 255, 0);
    this.COLOR_BLUE = new Color(this, 0, 0, 255);
    this.COLOR_MAGENTA = new Color(this, 255, 0, 255);
    this.COLOR_CYAN = new Color(this, 0, 255, 255);
    this.COLOR_WHITE = new Color(this, 255, 255, 255);
    this.emptyTab = OS.pango_tab_array_new(1, false);
    if (this.emptyTab == 0) {
      SWT.error(2);
    }
    OS.pango_tab_array_set_tab(this.emptyTab, 0, 0, 1);
    this.shellHandle = OS.gtk_window_new(0);
    if (this.shellHandle == 0) {
      SWT.error(2);
    }
    OS.gtk_widget_realize(this.shellHandle);
    if (OS.GTK3)
    {
      k = OS.gtk_widget_get_style_context(this.shellHandle);
      j = OS.gtk_style_context_get_font(k, 0);
    }
    else
    {
      k = OS.gtk_widget_get_style(this.shellHandle);
      j = OS.gtk_style_get_font_desc(k);
    }
    int j = OS.pango_font_description_copy(j);
    Point localPoint = getDPI();
    Object localObject2 = getScreenDPI();
    if (localPoint.y != ((Point)localObject2).y)
    {
      int n = OS.pango_font_description_get_size(j);
      OS.pango_font_description_set_size(j, n * localPoint.y / ((Point)localObject2).y);
    }
    this.systemFont = Font.gtk_new(this, j);
  }
  
  public abstract int internal_new_GC(GCData paramGCData);
  
  public abstract void internal_dispose_GC(int paramInt, GCData paramGCData);
  
  /* Error */
  public boolean isDisposed()
  {
    // Byte code:
    //   0: ldc_w 23
    //   3: dup
    //   4: astore_1
    //   5: monitorenter
    //   6: aload_0
    //   7: getfield 53	org/eclipse/swt/graphics/Device:disposed	Z
    //   10: aload_1
    //   11: monitorexit
    //   12: ireturn
    //   13: astore_2
    //   14: aload_1
    //   15: monitorexit
    //   16: aload_2
    //   17: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	18	0	this	Device
    //   4	11	1	Ljava/lang/Object;	Object
    //   13	4	2	localObject1	Object
    // Exception table:
    //   from	to	target	type
    //   6	12	13	finally
    //   13	16	13	finally
  }
  
  public boolean loadFont(String paramString)
  {
    checkDevice();
    if (paramString == null) {
      SWT.error(4);
    }
    byte[] arrayOfByte = Converter.wcsToMbcs(null, paramString, true);
    return OS.FcConfigAppFontAddFile(0, arrayOfByte);
  }
  
  int logProc(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    if (DEBUG) {
      new Error().printStackTrace();
    }
    if (this.warningLevel == 0)
    {
      if ((DEBUG) || (this.debug)) {
        new Error().printStackTrace();
      }
      OS.g_log_default_handler(paramInt1, paramInt2, paramInt3, 0);
    }
    return 0;
  }
  
  void new_Object(Object paramObject)
  {
    synchronized (this.trackingLock)
    {
      for (int i = 0; i < this.objects.length; i++) {
        if (this.objects[i] == null)
        {
          this.objects[i] = paramObject;
          this.errors[i] = new Error();
          return;
        }
      }
      Object[] arrayOfObject = new Object[this.objects.length + 128];
      System.arraycopy(this.objects, 0, arrayOfObject, 0, this.objects.length);
      arrayOfObject[this.objects.length] = paramObject;
      this.objects = arrayOfObject;
      Error[] arrayOfError = new Error[this.errors.length + 128];
      System.arraycopy(this.errors, 0, arrayOfError, 0, this.errors.length);
      arrayOfError[this.errors.length] = new Error();
      this.errors = arrayOfError;
    }
  }
  
  static synchronized void register(Device paramDevice)
  {
    for (int i = 0; i < Devices.length; i++) {
      if (Devices[i] == null)
      {
        Devices[i] = paramDevice;
        return;
      }
    }
    Device[] arrayOfDevice = new Device[Devices.length + 4];
    System.arraycopy(Devices, 0, arrayOfDevice, 0, Devices.length);
    arrayOfDevice[Devices.length] = paramDevice;
    Devices = arrayOfDevice;
  }
  
  protected void release()
  {
    if (this.shellHandle != 0) {
      OS.gtk_widget_destroy(this.shellHandle);
    }
    this.shellHandle = 0;
    if (this.systemFont != null) {
      this.systemFont.dispose();
    }
    this.systemFont = null;
    int i;
    if ((this.gdkColors != null) && (!OS.GTK3))
    {
      i = OS.gdk_colormap_get_system();
      for (int j = 0; j < this.gdkColors.length; j++)
      {
        GdkColor localGdkColor = this.gdkColors[j];
        if (localGdkColor != null) {
          while (this.colorRefCount[j] > 0)
          {
            OS.gdk_colormap_free_colors(i, localGdkColor, 1);
            this.colorRefCount[j] -= 1;
          }
        }
      }
    }
    this.gdkColors = null;
    this.colorRefCount = null;
    if (this.COLOR_BLACK != null) {
      this.COLOR_BLACK.dispose();
    }
    if (this.COLOR_DARK_RED != null) {
      this.COLOR_DARK_RED.dispose();
    }
    if (this.COLOR_DARK_GREEN != null) {
      this.COLOR_DARK_GREEN.dispose();
    }
    if (this.COLOR_DARK_YELLOW != null) {
      this.COLOR_DARK_YELLOW.dispose();
    }
    if (this.COLOR_DARK_BLUE != null) {
      this.COLOR_DARK_BLUE.dispose();
    }
    if (this.COLOR_DARK_MAGENTA != null) {
      this.COLOR_DARK_MAGENTA.dispose();
    }
    if (this.COLOR_DARK_CYAN != null) {
      this.COLOR_DARK_CYAN.dispose();
    }
    if (this.COLOR_GRAY != null) {
      this.COLOR_GRAY.dispose();
    }
    if (this.COLOR_DARK_GRAY != null) {
      this.COLOR_DARK_GRAY.dispose();
    }
    if (this.COLOR_RED != null) {
      this.COLOR_RED.dispose();
    }
    if (this.COLOR_GREEN != null) {
      this.COLOR_GREEN.dispose();
    }
    if (this.COLOR_YELLOW != null) {
      this.COLOR_YELLOW.dispose();
    }
    if (this.COLOR_BLUE != null) {
      this.COLOR_BLUE.dispose();
    }
    if (this.COLOR_MAGENTA != null) {
      this.COLOR_MAGENTA.dispose();
    }
    if (this.COLOR_CYAN != null) {
      this.COLOR_CYAN.dispose();
    }
    if (this.COLOR_WHITE != null) {
      this.COLOR_WHITE.dispose();
    }
    this.COLOR_BLACK = (this.COLOR_DARK_RED = this.COLOR_DARK_GREEN = this.COLOR_DARK_YELLOW = this.COLOR_DARK_BLUE = this.COLOR_DARK_MAGENTA = this.COLOR_DARK_CYAN = this.COLOR_GRAY = this.COLOR_DARK_GRAY = this.COLOR_RED = this.COLOR_GREEN = this.COLOR_YELLOW = this.COLOR_BLUE = this.COLOR_MAGENTA = this.COLOR_CYAN = this.COLOR_WHITE = null);
    if (this.emptyTab != 0) {
      OS.pango_tab_array_free(this.emptyTab);
    }
    this.emptyTab = 0;
    if (this.xDisplay != 0)
    {
      for (i = 0; i < this.handler_ids.length; i++) {
        if (this.handler_ids[i] != 0)
        {
          byte[] arrayOfByte = Converter.wcsToMbcs(null, this.log_domains[i], true);
          OS.g_log_remove_handler(arrayOfByte, this.handler_ids[i]);
          this.handler_ids[i] = 0;
        }
      }
      this.logCallback.dispose();
      this.logCallback = null;
      this.handler_ids = null;
      this.log_domains = null;
      this.logProc = 0;
    }
  }
  
  public void setWarnings(boolean paramBoolean)
  {
    checkDevice();
    int i;
    if (paramBoolean)
    {
      if (--this.warningLevel == 0)
      {
        if (this.debug) {
          return;
        }
        if (this.logProc != 0) {
          for (i = 0; i < this.handler_ids.length; i++) {
            if (this.handler_ids[i] != 0)
            {
              byte[] arrayOfByte1 = Converter.wcsToMbcs(null, this.log_domains[i], true);
              OS.g_log_remove_handler(arrayOfByte1, this.handler_ids[i]);
              this.handler_ids[i] = 0;
            }
          }
        }
      }
    }
    else if (this.warningLevel++ == 0)
    {
      if (this.debug) {
        return;
      }
      if (this.logProc != 0)
      {
        i = -1;
        for (int j = 0; j < this.log_domains.length; j++)
        {
          byte[] arrayOfByte2 = Converter.wcsToMbcs(null, this.log_domains[j], true);
          this.handler_ids[j] = OS.g_log_set_handler(arrayOfByte2, i, this.logProc, 0);
        }
      }
    }
  }
  
  static int XErrorProc(int paramInt1, int paramInt2)
  {
    Device localDevice = findDevice(paramInt1);
    if (localDevice != null)
    {
      if (localDevice.warningLevel == 0)
      {
        if ((DEBUG) || (localDevice.debug)) {
          new SWTError().printStackTrace();
        }
        int i = (OS.IsAIX) && (OS.PTR_SIZEOF == 8) ? 1 : 0;
        if (i == 0) {
          OS.Call(XErrorProc, paramInt1, paramInt2);
        }
      }
    }
    else
    {
      if (DEBUG) {
        new SWTError().printStackTrace();
      }
      OS.Call(XErrorProc, paramInt1, paramInt2);
    }
    return 0;
  }
  
  static int XIOErrorProc(int paramInt)
  {
    Device localDevice = findDevice(paramInt);
    if (localDevice != null)
    {
      if ((DEBUG) || (localDevice.debug)) {
        new SWTError().printStackTrace();
      }
    }
    else if (DEBUG) {
      new SWTError().printStackTrace();
    }
    OS.Call(XIOErrorProc, paramInt, 0);
    return 0;
  }
  
  static
  {
    try
    {
      Class.forName("org.eclipse.swt.widgets.Display");
    }
    catch (ClassNotFoundException localClassNotFoundException) {}
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/graphics/Device.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */