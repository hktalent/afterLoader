package org.eclipse.swt.graphics;

import org.eclipse.swt.SWT;
import org.eclipse.swt.internal.cairo.Cairo;

public class Pattern
  extends Resource
{
  public int handle;
  int surface;
  
  public Pattern(Device paramDevice, Image paramImage)
  {
    super(paramDevice);
    if (paramImage == null) {
      SWT.error(4);
    }
    if (paramImage.isDisposed()) {
      SWT.error(5);
    }
    this.device.checkCairo();
    paramImage.createSurface();
    this.handle = Cairo.cairo_pattern_create_for_surface(paramImage.surface);
    if (this.handle == 0) {
      SWT.error(2);
    }
    Cairo.cairo_pattern_set_extend(this.handle, 1);
    this.surface = paramImage.surface;
    init();
  }
  
  public Pattern(Device paramDevice, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, Color paramColor1, Color paramColor2)
  {
    this(paramDevice, paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramColor1, 255, paramColor2, 255);
  }
  
  public Pattern(Device paramDevice, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, Color paramColor1, int paramInt1, Color paramColor2, int paramInt2)
  {
    super(paramDevice);
    if (paramColor1 == null) {
      SWT.error(4);
    }
    if (paramColor1.isDisposed()) {
      SWT.error(5);
    }
    if (paramColor2 == null) {
      SWT.error(4);
    }
    if (paramColor2.isDisposed()) {
      SWT.error(5);
    }
    this.device.checkCairo();
    this.handle = Cairo.cairo_pattern_create_linear(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
    if (this.handle == 0) {
      SWT.error(2);
    }
    GC.setCairoPatternColor(this.handle, 0, paramColor1, paramInt1);
    GC.setCairoPatternColor(this.handle, 1, paramColor2, paramInt2);
    Cairo.cairo_pattern_set_extend(this.handle, 1);
    init();
  }
  
  void destroy()
  {
    Cairo.cairo_pattern_destroy(this.handle);
    this.handle = (this.surface = 0);
  }
  
  public boolean isDisposed()
  {
    return this.handle == 0;
  }
  
  public String toString()
  {
    if (isDisposed()) {
      return "Pattern {*DISPOSED*}";
    }
    return "Pattern {" + this.handle + "}";
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/graphics/Pattern.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */