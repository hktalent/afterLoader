package org.eclipse.swt.graphics;

import org.eclipse.swt.SWT;

public final class FontData
{
  public String name;
  public float height;
  public int style;
  public byte[] string;
  String lang;
  String country;
  String variant;
  
  public FontData()
  {
    this("", 12, 0);
  }
  
  public FontData(String paramString)
  {
    if (paramString == null) {
      SWT.error(4);
    }
    int i = 0;
    int j = paramString.indexOf('|');
    if (j == -1) {
      SWT.error(5);
    }
    String str1 = paramString.substring(i, j);
    try
    {
      if (Integer.parseInt(str1) != 1) {
        SWT.error(5);
      }
    }
    catch (NumberFormatException localNumberFormatException1)
    {
      SWT.error(5);
    }
    i = j + 1;
    j = paramString.indexOf('|', i);
    if (j == -1) {
      SWT.error(5);
    }
    String str2 = paramString.substring(i, j);
    i = j + 1;
    j = paramString.indexOf('|', i);
    if (j == -1) {
      SWT.error(5);
    }
    float f = 0.0F;
    try
    {
      f = Float.parseFloat(paramString.substring(i, j));
    }
    catch (NumberFormatException localNumberFormatException2)
    {
      SWT.error(5);
    }
    i = j + 1;
    j = paramString.indexOf('|', i);
    if (j == -1) {
      SWT.error(5);
    }
    int k = 0;
    try
    {
      k = Integer.parseInt(paramString.substring(i, j));
    }
    catch (NumberFormatException localNumberFormatException3)
    {
      SWT.error(5);
    }
    i = j + 1;
    j = paramString.indexOf('|', i);
    setName(str2);
    setHeight(f);
    setStyle(k);
    if (j == -1) {
      return;
    }
    String str3 = paramString.substring(i, j);
    i = j + 1;
    j = paramString.indexOf('|', i);
    if (j == -1) {
      return;
    }
    String str4 = paramString.substring(i, j);
    if ((str3.equals("GTK")) && (str4.equals("1"))) {}
  }
  
  public FontData(String paramString, int paramInt1, int paramInt2)
  {
    setName(paramString);
    setHeight(paramInt1);
    setStyle(paramInt2);
  }
  
  FontData(String paramString, float paramFloat, int paramInt)
  {
    setName(paramString);
    setHeight(paramFloat);
    setStyle(paramInt);
  }
  
  public boolean equals(Object paramObject)
  {
    if (paramObject == this) {
      return true;
    }
    if (!(paramObject instanceof FontData)) {
      return false;
    }
    FontData localFontData = (FontData)paramObject;
    return (this.name.equals(localFontData.name)) && (this.height == localFontData.height) && (this.style == localFontData.style);
  }
  
  public int getHeight()
  {
    return (int)(0.5F + this.height);
  }
  
  float getHeightF()
  {
    return this.height;
  }
  
  public String getLocale()
  {
    StringBuffer localStringBuffer = new StringBuffer();
    char c = '_';
    if (this.lang != null)
    {
      localStringBuffer.append(this.lang);
      localStringBuffer.append(c);
    }
    if (this.country != null)
    {
      localStringBuffer.append(this.country);
      localStringBuffer.append(c);
    }
    if (this.variant != null) {
      localStringBuffer.append(this.variant);
    }
    String str = localStringBuffer.toString();
    int i = str.length();
    if ((i > 0) && (str.charAt(i - 1) == c)) {
      str = str.substring(0, i - 1);
    }
    return str;
  }
  
  public String getName()
  {
    return this.name;
  }
  
  public int getStyle()
  {
    return this.style;
  }
  
  public int hashCode()
  {
    return this.name.hashCode() ^ getHeight() << 8 ^ this.style;
  }
  
  public void setHeight(int paramInt)
  {
    if (paramInt < 0) {
      SWT.error(5);
    }
    this.height = paramInt;
    this.string = null;
  }
  
  void setHeight(float paramFloat)
  {
    if (paramFloat < 0.0F) {
      SWT.error(5);
    }
    this.height = paramFloat;
    this.string = null;
  }
  
  public void setLocale(String paramString)
  {
    this.lang = (this.country = this.variant = null);
    if (paramString != null)
    {
      int i = 95;
      int j = paramString.length();
      int k = paramString.indexOf(i);
      int m;
      if (k == -1)
      {
        k = m = j;
      }
      else
      {
        m = paramString.indexOf(i, k + 1);
        if (m == -1) {
          m = j;
        }
      }
      if (k > 0) {
        this.lang = paramString.substring(0, k);
      }
      if (m > k + 1) {
        this.country = paramString.substring(k + 1, m);
      }
      if (j > m + 1) {
        this.variant = paramString.substring(m + 1);
      }
    }
  }
  
  public void setName(String paramString)
  {
    if (paramString == null) {
      SWT.error(4);
    }
    this.name = paramString;
    this.string = null;
  }
  
  public void setStyle(int paramInt)
  {
    this.style = paramInt;
    this.string = null;
  }
  
  public String toString()
  {
    StringBuffer localStringBuffer = new StringBuffer(128);
    localStringBuffer.append("1|");
    localStringBuffer.append(getName());
    localStringBuffer.append("|");
    localStringBuffer.append(getHeightF());
    localStringBuffer.append("|");
    localStringBuffer.append(getStyle());
    localStringBuffer.append("|");
    localStringBuffer.append("GTK|1|");
    return localStringBuffer.toString();
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/graphics/FontData.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */