package org.eclipse.swt.dnd;

import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.internal.Callback;
import org.eclipse.swt.internal.Converter;
import org.eclipse.swt.internal.ImageList;
import org.eclipse.swt.internal.gtk.GdkDragContext;
import org.eclipse.swt.internal.gtk.GtkSelectionData;
import org.eclipse.swt.internal.gtk.GtkTargetEntry;
import org.eclipse.swt.internal.gtk.OS;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.Tree;
import org.eclipse.swt.widgets.Widget;

public class DragSource
  extends Widget
{
  Control control;
  Listener controlListener;
  Transfer[] transferAgents = new Transfer[0];
  DragSourceEffect dragEffect;
  int targetList;
  boolean moveData = false;
  static final String DEFAULT_DRAG_SOURCE_EFFECT = "DEFAULT_DRAG_SOURCE_EFFECT";
  static Callback DragGetData = new Callback(DragSource.class, "DragGetData", 5);
  static Callback DragEnd;
  static Callback DragDataDelete;
  
  public DragSource(Control paramControl, int paramInt)
  {
    super(paramControl, checkStyle(paramInt));
    this.control = paramControl;
    if ((DragGetData == null) || (DragEnd == null) || (DragDataDelete == null)) {
      DND.error(2000);
    }
    if (paramControl.getData("DragSource") != null) {
      DND.error(2000);
    }
    paramControl.setData("DragSource", this);
    OS.g_signal_connect(paramControl.handle, OS.drag_data_get, DragGetData.getAddress(), 0);
    OS.g_signal_connect(paramControl.handle, OS.drag_end, DragEnd.getAddress(), 0);
    OS.g_signal_connect(paramControl.handle, OS.drag_data_delete, DragDataDelete.getAddress(), 0);
    this.controlListener = new Listener()
    {
      public void handleEvent(Event paramAnonymousEvent)
      {
        if ((paramAnonymousEvent.type == 12) && (!DragSource.this.isDisposed())) {
          DragSource.this.dispose();
        }
        if ((paramAnonymousEvent.type == 29) && (!DragSource.this.isDisposed())) {
          DragSource.this.drag(paramAnonymousEvent);
        }
      }
    };
    paramControl.addListener(12, this.controlListener);
    paramControl.addListener(29, this.controlListener);
    Object localObject = paramControl.getData("DEFAULT_DRAG_SOURCE_EFFECT");
    if ((localObject instanceof DragSourceEffect)) {
      this.dragEffect = ((DragSourceEffect)localObject);
    } else if ((paramControl instanceof Tree)) {
      this.dragEffect = new TreeDragSourceEffect((Tree)paramControl);
    } else if ((paramControl instanceof Table)) {
      this.dragEffect = new TableDragSourceEffect((Table)paramControl);
    }
    addListener(12, new Listener()
    {
      public void handleEvent(Event paramAnonymousEvent)
      {
        DragSource.this.onDispose();
      }
    });
  }
  
  static int checkStyle(int paramInt)
  {
    if (paramInt == 0) {
      return 2;
    }
    return paramInt;
  }
  
  static int DragDataDelete(int paramInt1, int paramInt2)
  {
    DragSource localDragSource = FindDragSource(paramInt1);
    if (localDragSource == null) {
      return 0;
    }
    localDragSource.dragDataDelete(paramInt1, paramInt2);
    return 0;
  }
  
  static int DragEnd(int paramInt1, int paramInt2)
  {
    DragSource localDragSource = FindDragSource(paramInt1);
    if (localDragSource == null) {
      return 0;
    }
    localDragSource.dragEnd(paramInt1, paramInt2);
    return 0;
  }
  
  static int DragGetData(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
  {
    DragSource localDragSource = FindDragSource(paramInt1);
    if (localDragSource == null) {
      return 0;
    }
    localDragSource.dragGetData(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
    return 0;
  }
  
  static DragSource FindDragSource(int paramInt)
  {
    Display localDisplay = Display.findDisplay(Thread.currentThread());
    if ((localDisplay == null) || (localDisplay.isDisposed())) {
      return null;
    }
    Widget localWidget = localDisplay.findWidget(paramInt);
    if (localWidget == null) {
      return null;
    }
    return (DragSource)localWidget.getData("DragSource");
  }
  
  public void addDragListener(DragSourceListener paramDragSourceListener)
  {
    if (paramDragSourceListener == null) {
      DND.error(4);
    }
    DNDListener localDNDListener = new DNDListener(paramDragSourceListener);
    localDNDListener.dndWidget = this;
    addListener(2008, localDNDListener);
    addListener(2001, localDNDListener);
    addListener(2000, localDNDListener);
  }
  
  protected void checkSubclass()
  {
    String str1 = getClass().getName();
    String str2 = DragSource.class.getName();
    if (!str2.equals(str1)) {
      DND.error(43);
    }
  }
  
  void drag(Event paramEvent)
  {
    this.moveData = false;
    DNDEvent localDNDEvent = new DNDEvent();
    localDNDEvent.widget = this;
    localDNDEvent.x = paramEvent.x;
    localDNDEvent.y = paramEvent.y;
    localDNDEvent.time = paramEvent.time;
    localDNDEvent.doit = true;
    notifyListeners(2008, localDNDEvent);
    if ((!localDNDEvent.doit) || (this.transferAgents == null) || (this.transferAgents.length == 0)) {
      return;
    }
    if (this.targetList == 0) {
      return;
    }
    int i = opToOsOp(getStyle());
    Image localImage = localDNDEvent.image;
    int j = OS.gtk_drag_begin(this.control.handle, this.targetList, i, 1, 0);
    if ((j != 0) && (localImage != null)) {
      if (OS.GTK3)
      {
        OS.gtk_drag_set_icon_surface(j, localImage.surface);
      }
      else
      {
        int k = ImageList.createPixbuf(localImage);
        OS.gtk_drag_set_icon_pixbuf(j, k, 0, 0);
        OS.g_object_unref(k);
      }
    }
  }
  
  void dragEnd(int paramInt1, int paramInt2)
  {
    int j;
    int k;
    if (OS.GTK3)
    {
      i = OS.gdk_window_get_display(OS.gtk_widget_get_window(paramInt1));
      j = OS.gdk_display_get_device_manager(i);
      k = OS.gdk_device_manager_get_client_pointer(j);
      int m = OS.gdk_device_get_associated_device(k);
      OS.gdk_device_ungrab(k, 0);
      OS.gdk_device_ungrab(m, 0);
    }
    else
    {
      OS.gdk_pointer_ungrab(0);
      OS.gdk_keyboard_ungrab(0);
    }
    int i = 0;
    if (paramInt2 != 0)
    {
      j = 0;
      k = 0;
      if (OS.GTK3)
      {
        j = OS.gdk_drag_context_get_dest_window(paramInt2);
        k = OS.gdk_drag_context_get_selected_action(paramInt2);
      }
      else
      {
        GdkDragContext localGdkDragContext = new GdkDragContext();
        OS.memmove(localGdkDragContext, paramInt2, GdkDragContext.sizeof);
        j = localGdkDragContext.dest_window;
        k = localGdkDragContext.action;
      }
      if (j != 0) {
        if (this.moveData)
        {
          i = 2;
        }
        else
        {
          i = osOpToOp(k);
          if (i == 2) {
            i = 0;
          }
        }
      }
    }
    DNDEvent localDNDEvent = new DNDEvent();
    localDNDEvent.widget = this;
    localDNDEvent.doit = (i != 0);
    localDNDEvent.detail = i;
    notifyListeners(2000, localDNDEvent);
    this.moveData = false;
  }
  
  void dragGetData(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
  {
    if (paramInt3 == 0) {
      return;
    }
    int i;
    int j;
    int k;
    int m;
    if (OS.GTK_VERSION >= OS.VERSION(2, 14, 0))
    {
      i = OS.gtk_selection_data_get_length(paramInt3);
      j = OS.gtk_selection_data_get_format(paramInt3);
      k = OS.gtk_selection_data_get_data(paramInt3);
      m = OS.gtk_selection_data_get_target(paramInt3);
    }
    else
    {
      localObject1 = new GtkSelectionData();
      OS.memmove((GtkSelectionData)localObject1, paramInt3, GtkSelectionData.sizeof);
      i = ((GtkSelectionData)localObject1).length;
      j = ((GtkSelectionData)localObject1).format;
      k = ((GtkSelectionData)localObject1).data;
      m = ((GtkSelectionData)localObject1).target;
    }
    if (m == 0) {
      return;
    }
    Object localObject1 = new TransferData();
    ((TransferData)localObject1).type = m;
    ((TransferData)localObject1).pValue = k;
    ((TransferData)localObject1).length = i;
    ((TransferData)localObject1).format = j;
    DNDEvent localDNDEvent = new DNDEvent();
    localDNDEvent.widget = this;
    localDNDEvent.time = paramInt5;
    localDNDEvent.dataType = ((TransferData)localObject1);
    notifyListeners(2001, localDNDEvent);
    if (!localDNDEvent.doit) {
      return;
    }
    Object localObject2 = null;
    for (int n = 0; n < this.transferAgents.length; n++)
    {
      Transfer localTransfer = this.transferAgents[n];
      if ((localTransfer != null) && (localTransfer.isSupportedType((TransferData)localObject1)))
      {
        localObject2 = localTransfer;
        break;
      }
    }
    if (localObject2 == null) {
      return;
    }
    ((Transfer)localObject2).javaToNative(localDNDEvent.data, (TransferData)localObject1);
    if (((TransferData)localObject1).result != 1) {
      return;
    }
    OS.gtk_selection_data_set(paramInt3, ((TransferData)localObject1).type, ((TransferData)localObject1).format, ((TransferData)localObject1).pValue, ((TransferData)localObject1).length);
    OS.g_free(((TransferData)localObject1).pValue);
  }
  
  void dragDataDelete(int paramInt1, int paramInt2)
  {
    this.moveData = true;
  }
  
  public Control getControl()
  {
    return this.control;
  }
  
  public DragSourceListener[] getDragListeners()
  {
    Listener[] arrayOfListener = getListeners(2008);
    int i = arrayOfListener.length;
    DragSourceListener[] arrayOfDragSourceListener1 = new DragSourceListener[i];
    int j = 0;
    for (int k = 0; k < i; k++)
    {
      Listener localListener = arrayOfListener[k];
      if ((localListener instanceof DNDListener))
      {
        arrayOfDragSourceListener1[j] = ((DragSourceListener)((DNDListener)localListener).getEventListener());
        j++;
      }
    }
    if (j == i) {
      return arrayOfDragSourceListener1;
    }
    DragSourceListener[] arrayOfDragSourceListener2 = new DragSourceListener[j];
    System.arraycopy(arrayOfDragSourceListener1, 0, arrayOfDragSourceListener2, 0, j);
    return arrayOfDragSourceListener2;
  }
  
  public DragSourceEffect getDragSourceEffect()
  {
    return this.dragEffect;
  }
  
  public Transfer[] getTransfer()
  {
    return this.transferAgents;
  }
  
  void onDispose()
  {
    if (this.control == null) {
      return;
    }
    if (this.targetList != 0) {
      OS.gtk_target_list_unref(this.targetList);
    }
    this.targetList = 0;
    if (this.controlListener != null)
    {
      this.control.removeListener(12, this.controlListener);
      this.control.removeListener(29, this.controlListener);
    }
    this.controlListener = null;
    this.control.setData("DragSource", null);
    this.control = null;
    this.transferAgents = null;
  }
  
  int opToOsOp(int paramInt)
  {
    int i = 0;
    if ((paramInt & 0x1) == 1) {
      i |= 0x2;
    }
    if ((paramInt & 0x2) == 2) {
      i |= 0x4;
    }
    if ((paramInt & 0x4) == 4) {
      i |= 0x8;
    }
    return i;
  }
  
  int osOpToOp(int paramInt)
  {
    int i = 0;
    if ((paramInt & 0x2) == 2) {
      i |= 0x1;
    }
    if ((paramInt & 0x4) == 4) {
      i |= 0x2;
    }
    if ((paramInt & 0x8) == 8) {
      i |= 0x4;
    }
    return i;
  }
  
  public void removeDragListener(DragSourceListener paramDragSourceListener)
  {
    if (paramDragSourceListener == null) {
      DND.error(4);
    }
    removeListener(2008, paramDragSourceListener);
    removeListener(2001, paramDragSourceListener);
    removeListener(2000, paramDragSourceListener);
  }
  
  public void setDragSourceEffect(DragSourceEffect paramDragSourceEffect)
  {
    this.dragEffect = paramDragSourceEffect;
  }
  
  public void setTransfer(Transfer[] paramArrayOfTransfer)
  {
    if (this.targetList != 0)
    {
      OS.gtk_target_list_unref(this.targetList);
      this.targetList = 0;
    }
    this.transferAgents = paramArrayOfTransfer;
    if ((paramArrayOfTransfer == null) || (paramArrayOfTransfer.length == 0)) {
      return;
    }
    Object localObject = new GtkTargetEntry[0];
    for (int i = 0; i < paramArrayOfTransfer.length; i++)
    {
      Transfer localTransfer = paramArrayOfTransfer[i];
      if (localTransfer != null)
      {
        int[] arrayOfInt = localTransfer.getTypeIds();
        String[] arrayOfString = localTransfer.getTypeNames();
        for (int k = 0; k < arrayOfInt.length; k++)
        {
          GtkTargetEntry localGtkTargetEntry = new GtkTargetEntry();
          byte[] arrayOfByte = Converter.wcsToMbcs(null, arrayOfString[k], true);
          localGtkTargetEntry.target = OS.g_malloc(arrayOfByte.length);
          OS.memmove(localGtkTargetEntry.target, arrayOfByte, arrayOfByte.length);
          localGtkTargetEntry.info = arrayOfInt[k];
          GtkTargetEntry[] arrayOfGtkTargetEntry = new GtkTargetEntry[localObject.length + 1];
          System.arraycopy(localObject, 0, arrayOfGtkTargetEntry, 0, localObject.length);
          arrayOfGtkTargetEntry[localObject.length] = localGtkTargetEntry;
          localObject = arrayOfGtkTargetEntry;
        }
      }
    }
    i = OS.g_malloc(localObject.length * GtkTargetEntry.sizeof);
    for (int j = 0; j < localObject.length; j++) {
      OS.memmove(i + j * GtkTargetEntry.sizeof, localObject[j], GtkTargetEntry.sizeof);
    }
    this.targetList = OS.gtk_target_list_new(i, localObject.length);
    for (j = 0; j < localObject.length; j++) {
      OS.g_free(localObject[j].target);
    }
  }
  
  static
  {
    if (DragGetData.getAddress() == 0) {
      SWT.error(3);
    }
    DragEnd = new Callback(DragSource.class, "DragEnd", 2);
    if (DragEnd.getAddress() == 0) {
      SWT.error(3);
    }
    DragDataDelete = new Callback(DragSource.class, "DragDataDelete", 2);
    if (DragDataDelete.getAddress() == 0) {
      SWT.error(3);
    }
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/dnd/DragSource.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */