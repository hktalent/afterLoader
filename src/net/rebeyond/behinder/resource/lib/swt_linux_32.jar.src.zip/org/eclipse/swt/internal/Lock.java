package org.eclipse.swt.internal;

public class Lock
{
  int count;
  int waitCount;
  Thread owner;
  
  public int lock()
  {
    synchronized (this)
    {
      Thread localThread = Thread.currentThread();
      if (this.owner != localThread)
      {
        this.waitCount += 1;
        while (this.count > 0) {
          try
          {
            wait();
          }
          catch (InterruptedException localInterruptedException) {}
        }
        this.waitCount -= 1;
        this.owner = localThread;
      }
      return ++this.count;
    }
  }
  
  public void unlock()
  {
    synchronized (this)
    {
      Thread localThread = Thread.currentThread();
      if ((this.owner == localThread) && (--this.count == 0))
      {
        this.owner = null;
        if (this.waitCount > 0) {
          notifyAll();
        }
      }
    }
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/internal/Lock.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */