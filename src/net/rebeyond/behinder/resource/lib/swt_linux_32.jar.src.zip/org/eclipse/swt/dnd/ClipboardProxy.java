package org.eclipse.swt.dnd;

import org.eclipse.swt.SWT;
import org.eclipse.swt.internal.Callback;
import org.eclipse.swt.internal.Converter;
import org.eclipse.swt.internal.gtk.GtkSelectionData;
import org.eclipse.swt.internal.gtk.GtkTargetEntry;
import org.eclipse.swt.internal.gtk.OS;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Listener;

class ClipboardProxy
{
  Object[] clipboardData;
  Transfer[] clipboardDataTypes;
  Object[] primaryClipboardData;
  Transfer[] primaryClipboardDataTypes;
  int clipboardOwner = OS.gtk_window_new(0);
  Display display;
  Clipboard activeClipboard = null;
  Clipboard activePrimaryClipboard = null;
  Callback getFunc;
  Callback clearFunc;
  static String ID = "CLIPBOARD PROXY OBJECT";
  
  static ClipboardProxy _getInstance(Display paramDisplay)
  {
    ClipboardProxy localClipboardProxy = (ClipboardProxy)paramDisplay.getData(ID);
    if (localClipboardProxy != null) {
      return localClipboardProxy;
    }
    localClipboardProxy = new ClipboardProxy(paramDisplay);
    paramDisplay.setData(ID, localClipboardProxy);
    paramDisplay.addListener(12, new Listener()
    {
      public void handleEvent(Event paramAnonymousEvent)
      {
        ClipboardProxy localClipboardProxy = (ClipboardProxy)this.val$display.getData(ClipboardProxy.ID);
        if (localClipboardProxy == null) {
          return;
        }
        this.val$display.setData(ClipboardProxy.ID, null);
        localClipboardProxy.dispose();
      }
    });
    return localClipboardProxy;
  }
  
  ClipboardProxy(Display paramDisplay)
  {
    this.display = paramDisplay;
    this.getFunc = new Callback(this, "getFunc", 4);
    if (this.getFunc.getAddress() == 0) {
      SWT.error(3);
    }
    this.clearFunc = new Callback(this, "clearFunc", 2);
    if (this.clearFunc.getAddress() == 0) {
      SWT.error(3);
    }
  }
  
  void clear(Clipboard paramClipboard, int paramInt)
  {
    if (((paramInt & 0x1) != 0) && (this.activeClipboard == paramClipboard)) {
      OS.gtk_clipboard_clear(Clipboard.GTKCLIPBOARD);
    }
    if (((paramInt & 0x2) != 0) && (this.activePrimaryClipboard == paramClipboard)) {
      OS.gtk_clipboard_clear(Clipboard.GTKPRIMARYCLIPBOARD);
    }
  }
  
  int clearFunc(int paramInt1, int paramInt2)
  {
    if (paramInt1 == Clipboard.GTKCLIPBOARD)
    {
      this.activeClipboard = null;
      this.clipboardData = null;
      this.clipboardDataTypes = null;
    }
    if (paramInt1 == Clipboard.GTKPRIMARYCLIPBOARD)
    {
      this.activePrimaryClipboard = null;
      this.primaryClipboardData = null;
      this.primaryClipboardDataTypes = null;
    }
    return 1;
  }
  
  void dispose()
  {
    if (this.display == null) {
      return;
    }
    if (this.activeClipboard != null) {
      OS.gtk_clipboard_store(Clipboard.GTKCLIPBOARD);
    }
    if (this.activePrimaryClipboard != null) {
      OS.gtk_clipboard_store(Clipboard.GTKPRIMARYCLIPBOARD);
    }
    this.display = null;
    if (this.getFunc != null) {
      this.getFunc.dispose();
    }
    this.getFunc = null;
    if (this.clearFunc != null) {
      this.clearFunc.dispose();
    }
    this.clearFunc = null;
    this.clipboardData = null;
    this.clipboardDataTypes = null;
    this.primaryClipboardData = null;
    this.primaryClipboardDataTypes = null;
    if (this.clipboardOwner != 0) {
      OS.gtk_widget_destroy(this.clipboardOwner);
    }
    this.clipboardOwner = 0;
  }
  
  int getFunc(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    if (paramInt2 == 0) {
      return 0;
    }
    int i;
    if (OS.GTK_VERSION >= OS.VERSION(2, 14, 0))
    {
      i = OS.gtk_selection_data_get_target(paramInt2);
    }
    else
    {
      localObject = new GtkSelectionData();
      OS.memmove((GtkSelectionData)localObject, paramInt2, GtkSelectionData.sizeof);
      i = ((GtkSelectionData)localObject).target;
    }
    Object localObject = new TransferData();
    ((TransferData)localObject).type = i;
    Transfer[] arrayOfTransfer = paramInt1 == Clipboard.GTKCLIPBOARD ? this.clipboardDataTypes : this.primaryClipboardDataTypes;
    int j = -1;
    for (int k = 0; k < arrayOfTransfer.length; k++) {
      if (arrayOfTransfer[k].isSupportedType((TransferData)localObject))
      {
        j = k;
        break;
      }
    }
    if (j == -1) {
      return 0;
    }
    Object[] arrayOfObject = paramInt1 == Clipboard.GTKCLIPBOARD ? this.clipboardData : this.primaryClipboardData;
    arrayOfTransfer[j].javaToNative(arrayOfObject[j], (TransferData)localObject);
    if ((((TransferData)localObject).format < 8) || (((TransferData)localObject).format % 8 != 0)) {
      return 0;
    }
    OS.gtk_selection_data_set(paramInt2, ((TransferData)localObject).type, ((TransferData)localObject).format, ((TransferData)localObject).pValue, ((TransferData)localObject).length);
    OS.g_free(((TransferData)localObject).pValue);
    return 1;
  }
  
  boolean setData(Clipboard paramClipboard, Object[] paramArrayOfObject, Transfer[] paramArrayOfTransfer, int paramInt)
  {
    Object localObject1 = new GtkTargetEntry[0];
    int i = 0;
    try
    {
      for (int j = 0; j < paramArrayOfTransfer.length; j++)
      {
        Transfer localTransfer = paramArrayOfTransfer[j];
        int[] arrayOfInt = localTransfer.getTypeIds();
        String[] arrayOfString = localTransfer.getTypeNames();
        for (int n = 0; n < arrayOfInt.length; n++)
        {
          GtkTargetEntry localGtkTargetEntry = new GtkTargetEntry();
          localGtkTargetEntry.info = arrayOfInt[n];
          byte[] arrayOfByte = Converter.wcsToMbcs(null, arrayOfString[n], true);
          int i1 = OS.g_malloc(arrayOfByte.length);
          OS.memmove(i1, arrayOfByte, arrayOfByte.length);
          localGtkTargetEntry.target = i1;
          GtkTargetEntry[] arrayOfGtkTargetEntry = new GtkTargetEntry[localObject1.length + 1];
          System.arraycopy(localObject1, 0, arrayOfGtkTargetEntry, 0, localObject1.length);
          arrayOfGtkTargetEntry[localObject1.length] = localGtkTargetEntry;
          localObject1 = arrayOfGtkTargetEntry;
        }
      }
      i = OS.g_malloc(GtkTargetEntry.sizeof * localObject1.length);
      j = 0;
      for (int k = 0; k < localObject1.length; k++)
      {
        OS.memmove(i + j, localObject1[k], GtkTargetEntry.sizeof);
        j += GtkTargetEntry.sizeof;
      }
      int m;
      boolean bool;
      if ((paramInt & 0x1) != 0)
      {
        this.clipboardData = paramArrayOfObject;
        this.clipboardDataTypes = paramArrayOfTransfer;
        k = this.getFunc.getAddress();
        m = this.clearFunc.getAddress();
        if (!OS.gtk_clipboard_set_with_owner(Clipboard.GTKCLIPBOARD, i, localObject1.length, k, m, this.clipboardOwner))
        {
          bool = false;
          return bool;
        }
        OS.gtk_clipboard_set_can_store(Clipboard.GTKCLIPBOARD, 0, 0);
        this.activeClipboard = paramClipboard;
      }
      if ((paramInt & 0x2) != 0)
      {
        this.primaryClipboardData = paramArrayOfObject;
        this.primaryClipboardDataTypes = paramArrayOfTransfer;
        k = this.getFunc.getAddress();
        m = this.clearFunc.getAddress();
        if (!OS.gtk_clipboard_set_with_owner(Clipboard.GTKPRIMARYCLIPBOARD, i, localObject1.length, k, m, this.clipboardOwner))
        {
          bool = false;
          return bool;
        }
        OS.gtk_clipboard_set_can_store(Clipboard.GTKPRIMARYCLIPBOARD, 0, 0);
        this.activePrimaryClipboard = paramClipboard;
      }
      k = 1;
      return k;
    }
    finally
    {
      for (int i2 = 0; i2 < localObject1.length; i2++)
      {
        Object localObject4 = localObject1[i2];
        if (((GtkTargetEntry)localObject4).target != 0) {
          OS.g_free(((GtkTargetEntry)localObject4).target);
        }
      }
      if (i != 0) {
        OS.g_free(i);
      }
    }
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/dnd/ClipboardProxy.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */