package org.eclipse.swt.internal.mozilla;

public class nsIWritableVariant
  extends nsIVariant
{
  static final int LAST_METHOD_ID = nsIVariant.LAST_METHOD_ID + 31;
  static final String NS_IWRITABLEVARIANT_IID_STR = "5586a590-8c82-11d5-90f3-0010a4e73d9a";
  
  public nsIWritableVariant(int paramInt)
  {
    super(paramInt);
  }
  
  public int SetAsDouble(double paramDouble)
  {
    return XPCOM.VtblCall(nsIVariant.LAST_METHOD_ID + 12, getAddress(), paramDouble);
  }
  
  public int SetAsBool(int paramInt)
  {
    if ((IsXULRunner10()) || (IsXULRunner24())) {
      return XPCOM.VtblCall(nsIVariant.LAST_METHOD_ID + 13, getAddress(), (byte)paramInt);
    }
    return XPCOM.VtblCall(nsIVariant.LAST_METHOD_ID + 13, getAddress(), paramInt);
  }
  
  public int SetAsArray(short paramShort, int paramInt1, int paramInt2, int paramInt3)
  {
    return XPCOM.VtblCall(nsIVariant.LAST_METHOD_ID + 25, getAddress(), paramShort, paramInt1, paramInt2, paramInt3);
  }
  
  public int SetAsWStringWithSize(int paramInt, char[] paramArrayOfChar)
  {
    return XPCOM.VtblCall(nsIVariant.LAST_METHOD_ID + 27, getAddress(), paramInt, paramArrayOfChar);
  }
  
  public int SetAsEmpty()
  {
    return XPCOM.VtblCall(nsIVariant.LAST_METHOD_ID + 29, getAddress());
  }
  
  public int SetAsEmptyArray()
  {
    return XPCOM.VtblCall(nsIVariant.LAST_METHOD_ID + 30, getAddress());
  }
  
  static
  {
    IIDStore.RegisterIID(nsIWritableVariant.class, 0, new nsID("5586a590-8c82-11d5-90f3-0010a4e73d9a"));
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/internal/mozilla/nsIWritableVariant.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */