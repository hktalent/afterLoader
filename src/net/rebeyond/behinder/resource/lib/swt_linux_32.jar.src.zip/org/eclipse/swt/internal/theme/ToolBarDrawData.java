package org.eclipse.swt.internal.theme;

import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.GCData;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.internal.Converter;
import org.eclipse.swt.internal.gtk.OS;

public class ToolBarDrawData
  extends DrawData
{
  public ToolBarDrawData()
  {
    this.state = new int[1];
  }
  
  void draw(Theme paramTheme, GC paramGC, Rectangle paramRectangle)
  {
    int i = paramTheme.toolbarHandle;
    int j = OS.gtk_widget_get_style(i);
    int k = paramGC.getGCData().drawable;
    paramTheme.transferClipping(paramGC, j);
    int m = paramRectangle.x;
    int n = paramRectangle.y;
    int i1 = paramRectangle.width;
    int i2 = paramRectangle.height;
    byte[] arrayOfByte = Converter.wcsToMbcs(null, "toolbar", true);
    gtk_render_box(j, k, getStateType(0), 0, null, i, arrayOfByte, m, n, i1, i2);
    if (this.clientArea != null)
    {
      this.clientArea.x = paramRectangle.x;
      this.clientArea.y = paramRectangle.y;
      this.clientArea.width = paramRectangle.width;
      this.clientArea.height = paramRectangle.height;
    }
  }
  
  int getStateType(int paramInt)
  {
    return 0;
  }
  
  int hit(Theme paramTheme, Point paramPoint, Rectangle paramRectangle)
  {
    return paramRectangle.contains(paramPoint) ? 0 : -1;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/internal/theme/ToolBarDrawData.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */