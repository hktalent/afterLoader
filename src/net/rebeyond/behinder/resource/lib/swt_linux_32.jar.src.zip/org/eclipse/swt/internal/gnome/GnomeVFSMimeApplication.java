package org.eclipse.swt.internal.gnome;

public class GnomeVFSMimeApplication
{
  public int id;
  public int name;
  public int command;
  public boolean can_open_multiple_files;
  public int expects_uris;
  public int supported_uri_schemes;
  public boolean requires_terminal;
  public static final int sizeof = ;
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/internal/gnome/GnomeVFSMimeApplication.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */