package org.eclipse.swt.graphics;

import org.eclipse.swt.SWT;
import org.eclipse.swt.internal.gtk.GdkColor;
import org.eclipse.swt.internal.gtk.OS;

public final class Cursor
  extends Resource
{
  public int handle;
  static final byte[] APPSTARTING_SRC = { 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 0, 0, 12, 0, 0, 0, 28, 0, 0, 0, 60, 0, 0, 0, 124, 0, 0, 0, -4, 0, 0, 0, -4, 1, 0, 0, -4, 59, 0, 0, 124, 56, 0, 0, 108, 84, 0, 0, -60, -36, 0, 0, -64, 68, 0, 0, Byte.MIN_VALUE, 57, 0, 0, Byte.MIN_VALUE, 57, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
  static final byte[] APPSTARTING_MASK = { 0, 0, 0, 0, 6, 0, 0, 0, 14, 0, 0, 0, 30, 0, 0, 0, 62, 0, 0, 0, 126, 0, 0, 0, -2, 0, 0, 0, -2, 1, 0, 0, -2, 59, 0, 0, -2, Byte.MAX_VALUE, 0, 0, -2, Byte.MAX_VALUE, 0, 0, -2, -2, 0, 0, -18, -1, 1, 0, -28, -1, 0, 0, -64, Byte.MAX_VALUE, 0, 0, -64, Byte.MAX_VALUE, 0, 0, Byte.MIN_VALUE, 57, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
  
  Cursor(Device paramDevice)
  {
    super(paramDevice);
  }
  
  public Cursor(Device paramDevice, int paramInt)
  {
    super(paramDevice);
    int i = 0;
    switch (paramInt)
    {
    case 3: 
      break;
    case 0: 
      i = 68;
      break;
    case 1: 
      i = 150;
      break;
    case 2: 
      i = 30;
      break;
    case 21: 
      i = 60;
      break;
    case 4: 
      i = 92;
      break;
    case 5: 
      i = 52;
      break;
    case 6: 
      i = 120;
      break;
    case 7: 
      i = 42;
      break;
    case 8: 
      i = 120;
      break;
    case 9: 
      i = 108;
      break;
    case 10: 
      i = 138;
      break;
    case 11: 
      i = 16;
      break;
    case 12: 
      i = 96;
      break;
    case 13: 
      i = 70;
      break;
    case 14: 
      i = 136;
      break;
    case 15: 
      i = 14;
      break;
    case 16: 
      i = 12;
      break;
    case 17: 
      i = 134;
      break;
    case 18: 
      i = 114;
      break;
    case 19: 
      i = 152;
      break;
    case 20: 
      i = 0;
      break;
    default: 
      SWT.error(5);
    }
    if ((i == 0) && (paramInt == 3))
    {
      byte[] arrayOfByte1 = new byte[APPSTARTING_SRC.length];
      System.arraycopy(APPSTARTING_SRC, 0, arrayOfByte1, 0, arrayOfByte1.length);
      byte[] arrayOfByte2 = new byte[APPSTARTING_MASK.length];
      System.arraycopy(APPSTARTING_MASK, 0, arrayOfByte2, 0, arrayOfByte2.length);
      this.handle = createCursor(arrayOfByte1, arrayOfByte2, 32, 32, 2, 2, true);
    }
    else
    {
      this.handle = OS.gdk_cursor_new(i);
    }
    if (this.handle == 0) {
      SWT.error(2);
    }
    init();
  }
  
  public Cursor(Device paramDevice, ImageData paramImageData1, ImageData paramImageData2, int paramInt1, int paramInt2)
  {
    super(paramDevice);
    if (paramImageData1 == null) {
      SWT.error(4);
    }
    if (paramImageData2 == null)
    {
      if (paramImageData1.getTransparencyType() != 2) {
        SWT.error(4);
      }
      paramImageData2 = paramImageData1.getTransparencyMask();
    }
    if ((paramImageData2.width != paramImageData1.width) || (paramImageData2.height != paramImageData1.height)) {
      SWT.error(5);
    }
    if ((paramInt1 >= paramImageData1.width) || (paramInt1 < 0) || (paramInt2 >= paramImageData1.height) || (paramInt2 < 0)) {
      SWT.error(5);
    }
    paramImageData1 = ImageData.convertMask(paramImageData1);
    paramImageData2 = ImageData.convertMask(paramImageData2);
    byte[] arrayOfByte1 = new byte[paramImageData1.data.length];
    byte[] arrayOfByte2 = new byte[paramImageData2.data.length];
    byte[] arrayOfByte3 = paramImageData1.data;
    int j;
    for (int i = 0; i < arrayOfByte3.length; i++)
    {
      j = arrayOfByte3[i];
      arrayOfByte1[i] = ((byte)((j & 0x80) >> 7 | (j & 0x40) >> 5 | (j & 0x20) >> 3 | (j & 0x10) >> 1 | (j & 0x8) << 1 | (j & 0x4) << 3 | (j & 0x2) << 5 | (j & 0x1) << 7));
      arrayOfByte1[i] = ((byte)(arrayOfByte1[i] ^ 0xFFFFFFFF));
    }
    arrayOfByte1 = ImageData.convertPad(arrayOfByte1, paramImageData1.width, paramImageData1.height, paramImageData1.depth, paramImageData1.scanlinePad, 1);
    arrayOfByte3 = paramImageData2.data;
    for (i = 0; i < arrayOfByte3.length; i++)
    {
      j = arrayOfByte3[i];
      arrayOfByte2[i] = ((byte)((j & 0x80) >> 7 | (j & 0x40) >> 5 | (j & 0x20) >> 3 | (j & 0x10) >> 1 | (j & 0x8) << 1 | (j & 0x4) << 3 | (j & 0x2) << 5 | (j & 0x1) << 7));
      arrayOfByte2[i] = ((byte)(arrayOfByte2[i] ^ 0xFFFFFFFF));
    }
    arrayOfByte2 = ImageData.convertPad(arrayOfByte2, paramImageData2.width, paramImageData2.height, paramImageData2.depth, paramImageData2.scanlinePad, 1);
    this.handle = createCursor(arrayOfByte2, arrayOfByte1, paramImageData1.width, paramImageData1.height, paramInt1, paramInt2, true);
    if (this.handle == 0) {
      SWT.error(2);
    }
    init();
  }
  
  public Cursor(Device paramDevice, ImageData paramImageData, int paramInt1, int paramInt2)
  {
    super(paramDevice);
    if (paramImageData == null) {
      SWT.error(4);
    }
    if ((paramInt1 >= paramImageData.width) || (paramInt1 < 0) || (paramInt2 >= paramImageData.height) || (paramInt2 < 0)) {
      SWT.error(5);
    }
    int i = 0;
    Object localObject2;
    Object localObject5;
    int i10;
    if (OS.gdk_display_supports_cursor_color(i = OS.gdk_display_get_default()))
    {
      int j = paramImageData.width;
      int k = paramImageData.height;
      localObject2 = paramImageData.palette;
      int m = OS.gdk_pixbuf_new(0, true, 8, j, k);
      if (m == 0) {
        SWT.error(2);
      }
      int n = OS.gdk_pixbuf_get_rowstride(m);
      int i2 = OS.gdk_pixbuf_get_pixels(m);
      localObject5 = paramImageData.data;
      if ((!((PaletteData)localObject2).isDirect) || (paramImageData.depth != 24) || (n != paramImageData.bytesPerLine) || (((PaletteData)localObject2).redMask != -16777216) || (((PaletteData)localObject2).greenMask != 16711680) || (((PaletteData)localObject2).blueMask != 65280))
      {
        localObject5 = new byte[paramImageData.width * paramImageData.height * 4];
        Object localObject6;
        int i11;
        if (((PaletteData)localObject2).isDirect)
        {
          ImageData.blit(1, paramImageData.data, paramImageData.depth, paramImageData.bytesPerLine, paramImageData.getByteOrder(), 0, 0, paramImageData.width, paramImageData.height, ((PaletteData)localObject2).redMask, ((PaletteData)localObject2).greenMask, ((PaletteData)localObject2).blueMask, 255, null, 0, 0, 0, (byte[])localObject5, 32, paramImageData.width * 4, 1, 0, 0, paramImageData.width, paramImageData.height, -16777216, 16711680, 65280, false, false);
        }
        else
        {
          localObject6 = ((PaletteData)localObject2).getRGBs();
          int i6 = localObject6.length;
          byte[] arrayOfByte4 = new byte[i6];
          byte[] arrayOfByte6 = new byte[i6];
          byte[] arrayOfByte8 = new byte[i6];
          for (i11 = 0; i11 < localObject6.length; i11++)
          {
            Object localObject8 = localObject6[i11];
            if (localObject8 != null)
            {
              arrayOfByte4[i11] = ((byte)((RGB)localObject8).red);
              arrayOfByte6[i11] = ((byte)((RGB)localObject8).green);
              arrayOfByte8[i11] = ((byte)((RGB)localObject8).blue);
            }
          }
          ImageData.blit(1, paramImageData.data, paramImageData.depth, paramImageData.bytesPerLine, paramImageData.getByteOrder(), 0, 0, paramImageData.width, paramImageData.height, arrayOfByte4, arrayOfByte6, arrayOfByte8, 255, null, 0, 0, 0, (byte[])localObject5, 32, paramImageData.width * 4, 1, 0, 0, paramImageData.width, paramImageData.height, -16777216, 16711680, 65280, false, false);
        }
        if ((paramImageData.maskData != null) || (paramImageData.transparentPixel != -1))
        {
          localObject6 = paramImageData.getTransparencyMask();
          byte[] arrayOfByte2 = ((ImageData)localObject6).data;
          int i8 = ((ImageData)localObject6).bytesPerLine;
          int i9 = 3;
          i10 = 0;
          for (i11 = 0; i11 < paramImageData.height; i11++)
          {
            for (int i12 = 0; i12 < paramImageData.width; i12++)
            {
              localObject5[i9] = ((arrayOfByte2[(i10 + (i12 >> 3))] & 1 << 7 - (i12 & 0x7)) != 0 ? -1 : 0);
              i9 += 4;
            }
            i10 += i8;
          }
        }
        else
        {
          int i7;
          if (paramImageData.alpha != -1)
          {
            int i4 = (byte)paramImageData.alpha;
            for (i7 = 3; i7 < localObject5.length; i7 += 4) {
              localObject5[i7] = i4;
            }
          }
          else if (paramImageData.alphaData != null)
          {
            byte[] arrayOfByte1 = paramImageData.alphaData;
            for (i7 = 3; i7 < localObject5.length; i7 += 4) {
              localObject5[i7] = arrayOfByte1[(i7 / 4)];
            }
          }
        }
      }
      OS.memmove(i2, (byte[])localObject5, n * k);
      this.handle = OS.gdk_cursor_new_from_pixbuf(i, m, paramInt1, paramInt2);
      OS.g_object_unref(m);
    }
    else
    {
      ImageData localImageData = paramImageData.getTransparencyMask();
      if (paramImageData.depth > 1)
      {
        localObject1 = new ImageData(paramImageData.width, paramImageData.height, 1, ImageData.bwPalette(), 1, null, 0, null, null, -1, -1, 0, 0, 0, 0, 0);
        localObject2 = new byte[] { 0, -1 };
        localObject3 = localObject2;
        Object localObject4 = localObject2;
        PaletteData localPaletteData = paramImageData.palette;
        if (localPaletteData.isDirect)
        {
          ImageData.blit(1, paramImageData.data, paramImageData.depth, paramImageData.bytesPerLine, paramImageData.getByteOrder(), 0, 0, paramImageData.width, paramImageData.height, localPaletteData.redMask, localPaletteData.greenMask, localPaletteData.blueMask, 255, null, 0, 0, 0, ((ImageData)localObject1).data, ((ImageData)localObject1).depth, ((ImageData)localObject1).bytesPerLine, ((ImageData)localObject1).getByteOrder(), 0, 0, ((ImageData)localObject1).width, ((ImageData)localObject1).height, (byte[])localObject2, (byte[])localObject3, (byte[])localObject4, false, false);
        }
        else
        {
          localObject5 = localPaletteData.getRGBs();
          int i5 = localObject5.length;
          byte[] arrayOfByte3 = new byte[i5];
          byte[] arrayOfByte5 = new byte[i5];
          byte[] arrayOfByte7 = new byte[i5];
          for (i10 = 0; i10 < localObject5.length; i10++)
          {
            Object localObject7 = localObject5[i10];
            if (localObject7 != null)
            {
              arrayOfByte3[i10] = ((byte)((RGB)localObject7).red);
              arrayOfByte5[i10] = ((byte)((RGB)localObject7).green);
              arrayOfByte7[i10] = ((byte)((RGB)localObject7).blue);
            }
          }
          ImageData.blit(1, paramImageData.data, paramImageData.depth, paramImageData.bytesPerLine, paramImageData.getByteOrder(), 0, 0, paramImageData.width, paramImageData.height, arrayOfByte3, arrayOfByte5, arrayOfByte7, 255, null, 0, 0, 0, ((ImageData)localObject1).data, ((ImageData)localObject1).depth, ((ImageData)localObject1).bytesPerLine, ((ImageData)localObject1).getByteOrder(), 0, 0, ((ImageData)localObject1).width, ((ImageData)localObject1).height, (byte[])localObject2, (byte[])localObject3, (byte[])localObject4, false, false);
        }
        paramImageData = (ImageData)localObject1;
      }
      Object localObject1 = new byte[paramImageData.data.length];
      localObject2 = new byte[localImageData.data.length];
      Object localObject3 = paramImageData.data;
      int i3;
      for (int i1 = 0; i1 < localObject3.length; i1++)
      {
        i3 = localObject3[i1];
        localObject1[i1] = ((byte)((i3 & 0x80) >> 7 | (i3 & 0x40) >> 5 | (i3 & 0x20) >> 3 | (i3 & 0x10) >> 1 | (i3 & 0x8) << 1 | (i3 & 0x4) << 3 | (i3 & 0x2) << 5 | (i3 & 0x1) << 7));
      }
      localObject1 = ImageData.convertPad((byte[])localObject1, paramImageData.width, paramImageData.height, paramImageData.depth, paramImageData.scanlinePad, 1);
      localObject3 = localImageData.data;
      for (i1 = 0; i1 < localObject3.length; i1++)
      {
        i3 = localObject3[i1];
        localObject2[i1] = ((byte)((i3 & 0x80) >> 7 | (i3 & 0x40) >> 5 | (i3 & 0x20) >> 3 | (i3 & 0x10) >> 1 | (i3 & 0x8) << 1 | (i3 & 0x4) << 3 | (i3 & 0x2) << 5 | (i3 & 0x1) << 7));
      }
      localObject2 = ImageData.convertPad((byte[])localObject2, localImageData.width, localImageData.height, localImageData.depth, localImageData.scanlinePad, 1);
      this.handle = createCursor((byte[])localObject1, (byte[])localObject2, paramImageData.width, paramImageData.height, paramInt1, paramInt2, false);
    }
    if (this.handle == 0) {
      SWT.error(2);
    }
    init();
  }
  
  int createCursor(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean)
  {
    Object localObject;
    if (OS.GTK3)
    {
      int k;
      for (int i = 0; i < paramArrayOfByte1.length; i++)
      {
        k = paramArrayOfByte1[i];
        paramArrayOfByte1[i] = ((byte)((k & 0x80) >> 7 | (k & 0x40) >> 5 | (k & 0x20) >> 3 | (k & 0x10) >> 1 | (k & 0x8) << 1 | (k & 0x4) << 3 | (k & 0x2) << 5 | (k & 0x1) << 7));
        paramArrayOfByte1[i] = ((byte)(paramArrayOfByte1[i] ^ 0xFFFFFFFF));
      }
      for (i = 0; i < paramArrayOfByte2.length; i++)
      {
        k = paramArrayOfByte2[i];
        paramArrayOfByte2[i] = ((byte)((k & 0x80) >> 7 | (k & 0x40) >> 5 | (k & 0x20) >> 3 | (k & 0x10) >> 1 | (k & 0x8) << 1 | (k & 0x4) << 3 | (k & 0x2) << 5 | (k & 0x1) << 7));
        paramArrayOfByte2[i] = ((byte)(paramArrayOfByte2[i] ^ 0xFFFFFFFF));
      }
      PaletteData localPaletteData = new PaletteData(new RGB[] { new RGB(0, 0, 0), new RGB(255, 255, 255) });
      ImageData localImageData1 = new ImageData(paramInt1, paramInt2, 1, localPaletteData, 1, paramArrayOfByte1);
      ImageData localImageData2 = new ImageData(paramInt1, paramInt2, 1, localPaletteData, 1, paramArrayOfByte2);
      localObject = new byte[localImageData1.width * localImageData1.height * 4];
      for (int i1 = 0; i1 < localImageData1.height; i1++)
      {
        i2 = i1 * localImageData1.width * 4;
        for (i3 = 0; i3 < localImageData1.width; i3++)
        {
          i4 = localImageData1.getPixel(i3, i1);
          int i5 = localImageData2.getPixel(i3, i1);
          if ((i4 == 0) && (i5 == 0)) {
            localObject[(i2 + 3)] = -1;
          } else if ((i4 == 0) && (i5 == 1)) {
            localObject[i2] = (localObject[(i2 + 1)] = localObject[(i2 + 2)] = localObject[(i2 + 3)] = -1);
          } else if ((i4 != 1) || (i5 != 0)) {}
          i2 += 4;
        }
      }
      i1 = OS.gdk_pixbuf_new(0, true, 8, paramInt1, paramInt2);
      if (i1 == 0) {
        SWT.error(2);
      }
      int i2 = OS.gdk_pixbuf_get_rowstride(i1);
      int i3 = OS.gdk_pixbuf_get_pixels(i1);
      OS.memmove(i3, (byte[])localObject, i2 * paramInt2);
      int i4 = OS.gdk_cursor_new_from_pixbuf(OS.gdk_display_get_default(), i1, paramInt3, paramInt4);
      OS.g_object_unref(i1);
      return i4;
    }
    int j = OS.gdk_bitmap_create_from_data(0, paramArrayOfByte1, paramInt1, paramInt2);
    int m = OS.gdk_bitmap_create_from_data(0, paramArrayOfByte2, paramInt1, paramInt2);
    int n = 0;
    if ((j != 0) && (m != 0))
    {
      localObject = new GdkColor();
      if (!paramBoolean) {
        ((GdkColor)localObject).red = (((GdkColor)localObject).green = ((GdkColor)localObject).blue = -1);
      }
      GdkColor localGdkColor = new GdkColor();
      if (paramBoolean) {
        localGdkColor.red = (localGdkColor.green = localGdkColor.blue = -1);
      }
      n = OS.gdk_cursor_new_from_pixmap(j, m, (GdkColor)localObject, localGdkColor, paramInt3, paramInt4);
    }
    if (j != 0) {
      OS.g_object_unref(j);
    }
    if (m != 0) {
      OS.g_object_unref(m);
    }
    return n;
  }
  
  void destroy()
  {
    gdk_cursor_unref(this.handle);
    this.handle = 0;
  }
  
  public boolean equals(Object paramObject)
  {
    if (paramObject == this) {
      return true;
    }
    if (!(paramObject instanceof Cursor)) {
      return false;
    }
    Cursor localCursor = (Cursor)paramObject;
    return (this.device == localCursor.device) && (this.handle == localCursor.handle);
  }
  
  public static Cursor gtk_new(Device paramDevice, int paramInt)
  {
    Cursor localCursor = new Cursor(paramDevice);
    localCursor.handle = paramInt;
    return localCursor;
  }
  
  public int hashCode()
  {
    return this.handle;
  }
  
  public boolean isDisposed()
  {
    return this.handle == 0;
  }
  
  public String toString()
  {
    if (isDisposed()) {
      return "Cursor {*DISPOSED*}";
    }
    return "Cursor {" + this.handle + "}";
  }
  
  void gdk_cursor_unref(int paramInt)
  {
    if (OS.GTK3) {
      OS.g_object_unref(paramInt);
    } else {
      OS.gdk_cursor_unref(paramInt);
    }
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/graphics/Cursor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */