package org.eclipse.swt.dnd;

import org.eclipse.swt.internal.gtk.OS;

public class URLTransfer
  extends ByteArrayTransfer
{
  static URLTransfer _instance = new URLTransfer();
  private static final String TEXT_UNICODE = "text/unicode";
  private static final String TEXT_XMOZURL = "text/x-moz-url";
  private static final int TEXT_UNICODE_ID = registerType("text/unicode");
  private static final int TEXT_XMOZURL_ID = registerType("text/x-moz-url");
  
  public static URLTransfer getInstance()
  {
    return _instance;
  }
  
  public void javaToNative(Object paramObject, TransferData paramTransferData)
  {
    paramTransferData.result = 0;
    if ((!checkURL(paramObject)) || (!isSupportedType(paramTransferData))) {
      DND.error(2003);
    }
    String str = (String)paramObject;
    int i = str.length();
    char[] arrayOfChar = new char[i + 1];
    str.getChars(0, i, arrayOfChar, 0);
    int j = arrayOfChar.length * 2;
    int k = OS.g_malloc(j);
    if (k == 0) {
      return;
    }
    OS.memmove(k, arrayOfChar, j);
    paramTransferData.length = j;
    paramTransferData.format = 8;
    paramTransferData.pValue = k;
    paramTransferData.result = 1;
  }
  
  public Object nativeToJava(TransferData paramTransferData)
  {
    if ((!isSupportedType(paramTransferData)) || (paramTransferData.pValue == 0)) {
      return null;
    }
    int i = paramTransferData.format * paramTransferData.length / 8 / 2 * 2;
    if (i <= 0) {
      return null;
    }
    char[] arrayOfChar = new char[i / 2];
    OS.memmove(arrayOfChar, paramTransferData.pValue, i);
    String str = new String(arrayOfChar);
    int j = str.indexOf(0);
    return j == -1 ? str : str.substring(0, j);
  }
  
  protected int[] getTypeIds()
  {
    return new int[] { TEXT_XMOZURL_ID, TEXT_UNICODE_ID };
  }
  
  protected String[] getTypeNames()
  {
    return new String[] { "text/x-moz-url", "text/unicode" };
  }
  
  boolean checkURL(Object paramObject)
  {
    return (paramObject != null) && ((paramObject instanceof String)) && (((String)paramObject).length() > 0);
  }
  
  protected boolean validate(Object paramObject)
  {
    return checkURL(paramObject);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/dnd/URLTransfer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */