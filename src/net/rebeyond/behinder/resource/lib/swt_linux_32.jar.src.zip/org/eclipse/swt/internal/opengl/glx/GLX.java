package org.eclipse.swt.internal.opengl.glx;

import org.eclipse.swt.internal.Library;
import org.eclipse.swt.internal.Lock;
import org.eclipse.swt.internal.Platform;

public class GLX
  extends Platform
{
  public static final int GLX_USE_GL = 1;
  public static final int GLX_BUFFER_SIZE = 2;
  public static final int GLX_LEVEL = 3;
  public static final int GLX_RGBA = 4;
  public static final int GLX_DOUBLEBUFFER = 5;
  public static final int GLX_STEREO = 6;
  public static final int GLX_AUX_BUFFERS = 7;
  public static final int GLX_RED_SIZE = 8;
  public static final int GLX_GREEN_SIZE = 9;
  public static final int GLX_BLUE_SIZE = 10;
  public static final int GLX_ALPHA_SIZE = 11;
  public static final int GLX_DEPTH_SIZE = 12;
  public static final int GLX_STENCIL_SIZE = 13;
  public static final int GLX_ACCUM_RED_SIZE = 14;
  public static final int GLX_ACCUM_GREEN_SIZE = 15;
  public static final int GLX_ACCUM_BLUE_SIZE = 16;
  public static final int GLX_ACCUM_ALPHA_SIZE = 17;
  public static final int GLX_X_VISUAL_TYPE = 34;
  public static final int GLX_CONFIG_CAVEAT = 32;
  public static final int GLX_TRANSPARENT_TYPE = 35;
  public static final int GLX_TRANSPARENT_INDEX_VALUE = 36;
  public static final int GLX_TRANSPARENT_RED_VALUE = 37;
  public static final int GLX_TRANSPARENT_GREEN_VALUE = 38;
  public static final int GLX_TRANSPARENT_BLUE_VALUE = 39;
  public static final int GLX_TRANSPARENT_ALPHA_VALUE = 40;
  public static final int GLX_DRAWABLE_TYPE = 32784;
  public static final int GLX_RENDER_TYPE = 32785;
  public static final int GLX_X_RENDERABLE = 32786;
  public static final int GLX_FBCONFIG_ID = 32787;
  public static final int GLX_MAX_PBUFFER_WIDTH = 32790;
  public static final int GLX_MAX_PBUFFER_HEIGHT = 32791;
  public static final int GLX_MAX_PBUFFER_PIXELS = 32792;
  public static final int GLX_VISUAL_ID = 32779;
  public static final int GLX_BAD_SCREEN = 1;
  public static final int GLX_BAD_ATTRIBUTE = 2;
  public static final int GLX_NO_EXTENSION = 3;
  public static final int GLX_BAD_VISUAL = 4;
  public static final int GLX_BAD_CONTEXT = 5;
  public static final int GLX_BAD_VALUE = 6;
  public static final int GLX_BAD_ENUM = 7;
  public static final int GLX_DONT_CARE = -1;
  public static final int GLX_RGBA_BIT = 1;
  public static final int GLX_COLOR_INDEX_BIT = 2;
  public static final int GLX_WINDOW_BIT = 1;
  public static final int GLX_PIXMAP_BIT = 2;
  public static final int GLX_PBUFFER_BIT = 4;
  public static final int GLX_NONE = 32768;
  public static final int GLX_SLOW_CONFIG = 32769;
  public static final int GLX_NON_CONFORMANT_CONFIG = 32781;
  public static final int GLX_TRUE_COLOR = 32770;
  public static final int GLX_DIRECT_COLOR = 32771;
  public static final int GLX_PSEUDO_COLOR = 32772;
  public static final int GLX_STATIC_COLOR = 32773;
  public static final int GLX_GRAY_SCALE = 32774;
  public static final int GLX_STATIC_GRAY = 32775;
  public static final int GLX_TRANSPARENT_RGB = 32776;
  public static final int GLX_TRANSPARENT_INDEX = 32777;
  public static final int GLX_PRESERVED_CONTENTS = 32795;
  public static final int GLX_LARGEST_PBUFFER = 32796;
  public static final int GLX_PBUFFER_HEIGHT = 32832;
  public static final int GLX_PBUFFER_WIDTH = 32833;
  public static final int GLX_WIDTH = 32797;
  public static final int GLX_HEIGHT = 32798;
  public static final int GLX_EVENT_MASK = 32799;
  public static final int GLX_RGBA_TYPE = 32788;
  public static final int GLX_COLOR_INDEX_TYPE = 32789;
  public static final int GLX_SCREEN = 32780;
  public static final int GLX_PBUFFER_CLOBBER_MASK = 134217728;
  public static final int GLX_DAMAGED = 32800;
  public static final int GLX_SAVED = 32801;
  public static final int GLX_WINDOW = 32802;
  public static final int GLX_PBUFFER = 32803;
  public static final int GLX_FRONT_LEFT_BUFFER_BIT = 1;
  public static final int GLX_FRONT_RIGHT_BUFFER_BIT = 2;
  public static final int GLX_BACK_LEFT_BUFFER_BIT = 4;
  public static final int GLX_BACK_RIGHT_BUFFER_BIT = 8;
  public static final int GLX_AUX_BUFFERS_BIT = 16;
  public static final int GLX_DEPTH_BUFFER_BIT = 32;
  public static final int GLX_STENCIL_BUFFER_BIT = 64;
  public static final int GLX_ACCUM_BUFFER_BIT = 128;
  public static final int GLX_X_VISUAL_TYPE_EXT = 34;
  public static final int GLX_TRANSPARENT_TYPE_EXT = 35;
  public static final int GLX_TRANSPARENT_INDEX_VALUE_EXT = 36;
  public static final int GLX_TRANSPARENT_RED_VALUE_EXT = 37;
  public static final int GLX_TRANSPARENT_GREEN_VALUE_EXT = 38;
  public static final int GLX_TRANSPARENT_BLUE_VALUE_EXT = 39;
  public static final int GLX_TRANSPARENT_ALPHA_VALUE_EXT = 40;
  public static final int GLX_TRUE_COLOR_EXT = 32770;
  public static final int GLX_DIRECT_COLOR_EXT = 32771;
  public static final int GLX_PSEUDO_COLOR_EXT = 32772;
  public static final int GLX_STATIC_COLOR_EXT = 32773;
  public static final int GLX_GRAY_SCALE_EXT = 32774;
  public static final int GLX_STATIC_GRAY_EXT = 32775;
  public static final int GLX_NONE_EXT = 32768;
  public static final int GLX_TRANSPARENT_RGB_EXT = 32776;
  public static final int GLX_TRANSPARENT_INDEX_EXT = 32777;
  public static final int GLX_VISUAL_CAVEAT_EXT = 32;
  public static final int GLX_SLOW_VISUAL_EXT = 32769;
  public static final int GLX_NON_CONFORMANT_VISUAL_EXT = 32781;
  public static final int GLX_VENDOR = 1;
  public static final int GLX_VERSION = 2;
  public static final int GLX_EXTENSIONS = 3;
  public static final int GLX_SHARE_CONTEXT_EXT = 32778;
  public static final int GLX_VISUAL_ID_EXT = 32779;
  public static final int GLX_SCREEN_EXT = 32780;
  public static final int GLX_SAMPLE_BUFFERS = 100000;
  public static final int GLX_SAMPLES = 100001;
  public static final int GL_VIEWPORT = 2978;
  
  public static final native int XVisualInfo_sizeof();
  
  public static final native void _glGetIntegerv(int paramInt, int[] paramArrayOfInt);
  
  public static final void glGetIntegerv(int paramInt, int[] paramArrayOfInt)
  {
    lock.lock();
    try
    {
      _glGetIntegerv(paramInt, paramArrayOfInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _glViewport(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  public static final void glViewport(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    lock.lock();
    try
    {
      _glViewport(paramInt1, paramInt2, paramInt3, paramInt4);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _glXChooseVisual(int paramInt1, int paramInt2, int[] paramArrayOfInt);
  
  public static final int glXChooseVisual(int paramInt1, int paramInt2, int[] paramArrayOfInt)
  {
    lock.lock();
    try
    {
      int i = _glXChooseVisual(paramInt1, paramInt2, paramArrayOfInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _glXCopyContext(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  public static final void glXCopyContext(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    lock.lock();
    try
    {
      _glXCopyContext(paramInt1, paramInt2, paramInt3, paramInt4);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _glXCreateContext(int paramInt1, XVisualInfo paramXVisualInfo, int paramInt2, boolean paramBoolean);
  
  public static final int glXCreateContext(int paramInt1, XVisualInfo paramXVisualInfo, int paramInt2, boolean paramBoolean)
  {
    lock.lock();
    try
    {
      int i = _glXCreateContext(paramInt1, paramXVisualInfo, paramInt2, paramBoolean);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _glXCreateGLXPixmap(int paramInt1, XVisualInfo paramXVisualInfo, int paramInt2);
  
  public static final int glXCreateGLXPixmap(int paramInt1, XVisualInfo paramXVisualInfo, int paramInt2)
  {
    lock.lock();
    try
    {
      int i = _glXCreateGLXPixmap(paramInt1, paramXVisualInfo, paramInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _glXDestroyContext(int paramInt1, int paramInt2);
  
  public static final void glXDestroyContext(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _glXDestroyContext(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _glXDestroyGLXPixmap(int paramInt1, int paramInt2);
  
  public static final void glXDestroyGLXPixmap(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _glXDestroyGLXPixmap(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _glXGetClientString(int paramInt1, int paramInt2);
  
  public static final int glXGetClientString(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      int i = _glXGetClientString(paramInt1, paramInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _glXGetConfig(int paramInt1, XVisualInfo paramXVisualInfo, int paramInt2, int[] paramArrayOfInt);
  
  public static final int glXGetConfig(int paramInt1, XVisualInfo paramXVisualInfo, int paramInt2, int[] paramArrayOfInt)
  {
    lock.lock();
    try
    {
      int i = _glXGetConfig(paramInt1, paramXVisualInfo, paramInt2, paramArrayOfInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _glXGetCurrentContext();
  
  public static final int glXGetCurrentContext()
  {
    lock.lock();
    try
    {
      int i = _glXGetCurrentContext();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _glXGetCurrentDrawable();
  
  public static final int glXGetCurrentDrawable()
  {
    lock.lock();
    try
    {
      int i = _glXGetCurrentDrawable();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _glXIsDirect(int paramInt1, int paramInt2);
  
  public static final boolean glXIsDirect(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      boolean bool = _glXIsDirect(paramInt1, paramInt2);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _glXMakeCurrent(int paramInt1, int paramInt2, int paramInt3);
  
  public static final boolean glXMakeCurrent(int paramInt1, int paramInt2, int paramInt3)
  {
    lock.lock();
    try
    {
      boolean bool = _glXMakeCurrent(paramInt1, paramInt2, paramInt3);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _glXQueryExtension(int paramInt, int[] paramArrayOfInt1, int[] paramArrayOfInt2);
  
  public static final boolean glXQueryExtension(int paramInt, int[] paramArrayOfInt1, int[] paramArrayOfInt2)
  {
    lock.lock();
    try
    {
      boolean bool = _glXQueryExtension(paramInt, paramArrayOfInt1, paramArrayOfInt2);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _glXQueryExtensionsString(int paramInt1, int paramInt2);
  
  public static final int glXQueryExtensionsString(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      int i = _glXQueryExtensionsString(paramInt1, paramInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _glXQueryServerString(int paramInt1, int paramInt2, int paramInt3);
  
  public static final int glXQueryServerString(int paramInt1, int paramInt2, int paramInt3)
  {
    lock.lock();
    try
    {
      int i = _glXQueryServerString(paramInt1, paramInt2, paramInt3);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _glXQueryVersion(int paramInt, int[] paramArrayOfInt1, int[] paramArrayOfInt2);
  
  public static final boolean glXQueryVersion(int paramInt, int[] paramArrayOfInt1, int[] paramArrayOfInt2)
  {
    lock.lock();
    try
    {
      boolean bool = _glXQueryVersion(paramInt, paramArrayOfInt1, paramArrayOfInt2);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _glXSwapBuffers(int paramInt1, int paramInt2);
  
  public static final void glXSwapBuffers(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _glXSwapBuffers(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _glXWaitGL();
  
  public static final void glXWaitGL()
  {
    lock.lock();
    try
    {
      _glXWaitGL();
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _glXWaitX();
  
  public static final void glXWaitX()
  {
    lock.lock();
    try
    {
      _glXWaitX();
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void memmove(XVisualInfo paramXVisualInfo, int paramInt1, int paramInt2);
  
  static
  {
    Library.loadLibrary("swt-glx");
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/internal/opengl/glx/GLX.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */