package org.eclipse.swt.internal.mozilla;

public class nsIWebNavigation
  extends nsISupports
{
  static final int LAST_METHOD_ID = nsISupports.LAST_METHOD_ID + 13;
  static final String NS_IWEBNAVIGATION_IID_STR = "f5d9e7b0-d930-11d3-b057-00a024ffc08c";
  static final String NS_IWEBNAVIGATION_24_IID_STR = "28404f7e-0f17-4dc3-a21a-2074d8659b02";
  public static final int LOAD_FLAGS_MASK = 65535;
  public static final int LOAD_FLAGS_NONE = 0;
  public static final int LOAD_FLAGS_IS_REFRESH = 16;
  public static final int LOAD_FLAGS_IS_LINK = 32;
  public static final int LOAD_FLAGS_BYPASS_HISTORY = 64;
  public static final int LOAD_FLAGS_REPLACE_HISTORY = 128;
  public static final int LOAD_FLAGS_BYPASS_CACHE = 256;
  public static final int LOAD_FLAGS_BYPASS_PROXY = 512;
  public static final int LOAD_FLAGS_CHARSET_CHANGE = 1024;
  public static final int STOP_NETWORK = 1;
  public static final int STOP_CONTENT = 2;
  public static final int STOP_ALL = 3;
  
  public nsIWebNavigation(int paramInt)
  {
    super(paramInt);
  }
  
  public int GetCanGoBack(int[] paramArrayOfInt)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 1, getAddress(), paramArrayOfInt);
  }
  
  public int GetCanGoForward(int[] paramArrayOfInt)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 2, getAddress(), paramArrayOfInt);
  }
  
  public int GoBack()
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 3, getAddress());
  }
  
  public int GoForward()
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 4, getAddress());
  }
  
  public int LoadURI(char[] paramArrayOfChar, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 6, getAddress(), paramArrayOfChar, paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  public int Reload(int paramInt)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 7, getAddress(), paramInt);
  }
  
  public int Stop(int paramInt)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 8, getAddress(), paramInt);
  }
  
  public int GetCurrentURI(int[] paramArrayOfInt)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 10, getAddress(), paramArrayOfInt);
  }
  
  static
  {
    IIDStore.RegisterIID(nsIWebNavigation.class, 0, new nsID("f5d9e7b0-d930-11d3-b057-00a024ffc08c"));
    IIDStore.RegisterIID(nsIWebNavigation.class, 6, new nsID("28404f7e-0f17-4dc3-a21a-2074d8659b02"));
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/internal/mozilla/nsIWebNavigation.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */