package org.eclipse.swt.accessibility;

import java.util.Hashtable;
import java.util.Vector;
import org.eclipse.swt.SWT;
import org.eclipse.swt.internal.Callback;
import org.eclipse.swt.internal.Converter;
import org.eclipse.swt.internal.LONG;
import org.eclipse.swt.internal.accessibility.gtk.ATK;
import org.eclipse.swt.internal.accessibility.gtk.AtkActionIface;
import org.eclipse.swt.internal.accessibility.gtk.AtkComponentIface;
import org.eclipse.swt.internal.accessibility.gtk.AtkEditableTextIface;
import org.eclipse.swt.internal.accessibility.gtk.AtkHypertextIface;
import org.eclipse.swt.internal.accessibility.gtk.AtkObjectClass;
import org.eclipse.swt.internal.accessibility.gtk.AtkObjectFactoryClass;
import org.eclipse.swt.internal.accessibility.gtk.AtkSelectionIface;
import org.eclipse.swt.internal.accessibility.gtk.AtkTableIface;
import org.eclipse.swt.internal.accessibility.gtk.AtkTextIface;
import org.eclipse.swt.internal.accessibility.gtk.AtkValueIface;
import org.eclipse.swt.internal.gtk.GInterfaceInfo;
import org.eclipse.swt.internal.gtk.GObjectClass;
import org.eclipse.swt.internal.gtk.GTypeInfo;
import org.eclipse.swt.internal.gtk.GTypeQuery;
import org.eclipse.swt.internal.gtk.OS;

class AccessibleFactory
{
  static final Hashtable Accessibles = new Hashtable(9);
  static final Hashtable Factories = new Hashtable(9);
  static final String SWT_TYPE_PREFIX = "SWTAccessible";
  static final String CHILD_TYPENAME = "Child";
  static final String FACTORY_TYPENAME = "SWTFactory";
  static final int[] actionRoles = { 44, 46, 30, 12, 43, 45, 62, 52, 1027, 1073 };
  static final int[] editableTextRoles = { 42, 46, 1054, 15 };
  static final int[] hypertextRoles = { 42, 30, 1054 };
  static final int[] selectionRoles = { 33, 60, 24, 35 };
  static final int[] textRoles = { 46, 30, 41, 42, 23, 1054, 15 };
  static final int[] tableRoles = { 24, 35 };
  static final int[] valueRoles = { 3, 52, 48 };
  static final Callback AtkActionCB_do_action = newCallback(AccessibleObject.class, "atkAction_do_action", 2);
  static final Callback AtkActionCB_get_n_actions = newCallback(AccessibleObject.class, "atkAction_get_n_actions", 1);
  static final Callback AtkActionCB_get_description = newCallback(AccessibleObject.class, "atkAction_get_description", 2);
  static final Callback AtkActionCB_get_keybinding = newCallback(AccessibleObject.class, "atkAction_get_keybinding", 2);
  static final Callback AtkActionCB_get_name = newCallback(AccessibleObject.class, "atkAction_get_name", 2);
  static final Callback AtkComponentCB_get_extents = newCallback(AccessibleObject.class, "atkComponent_get_extents", 6);
  static final Callback AtkComponentCB_get_position = newCallback(AccessibleObject.class, "atkComponent_get_position", 4);
  static final Callback AtkComponentCB_get_size = newCallback(AccessibleObject.class, "atkComponent_get_size", 4);
  static final Callback AtkComponentCB_ref_accessible_at_point = newCallback(AccessibleObject.class, "atkComponent_ref_accessible_at_point", 4);
  static final Callback AtkEditableTextCB_set_run_attributes = newCallback(AccessibleObject.class, "atkEditableText_set_run_attributes", 4);
  static final Callback AtkEditableTextCB_set_text_contents = newCallback(AccessibleObject.class, "atkEditableText_set_text_contents", 2);
  static final Callback AtkEditableTextCB_insert_text = newCallback(AccessibleObject.class, "atkEditableText_insert_text", 4);
  static final Callback AtkEditableTextCB_copy_text = newCallback(AccessibleObject.class, "atkEditableText_copy_text", 3);
  static final Callback AtkEditableTextCB_cut_text = newCallback(AccessibleObject.class, "atkEditableText_cut_text", 3);
  static final Callback AtkEditableTextCB_delete_text = newCallback(AccessibleObject.class, "atkEditableText_delete_text", 3);
  static final Callback AtkEditableTextCB_paste_text = newCallback(AccessibleObject.class, "atkEditableText_paste_text", 2);
  static final Callback AtkHypertextCB_get_link = newCallback(AccessibleObject.class, "atkHypertext_get_link", 2);
  static final Callback AtkHypertextCB_get_n_links = newCallback(AccessibleObject.class, "atkHypertext_get_n_links", 1);
  static final Callback AtkHypertextCB_get_link_index = newCallback(AccessibleObject.class, "atkHypertext_get_link_index", 2);
  static final Callback AtkObjectCB_get_description;
  static final Callback AtkObjectCB_get_index_in_parent;
  static final Callback AtkObjectCB_get_n_children;
  static final Callback AtkObjectCB_get_name = newCallback(AccessibleObject.class, "atkObject_get_name", 1);
  static final Callback AtkObjectCB_get_parent;
  static final Callback AtkObjectCB_get_role;
  static final Callback AtkObjectCB_ref_child;
  static final Callback AtkObjectCB_ref_state_set;
  static final Callback AtkObjectCB_get_attributes;
  static final Callback AtkSelectionCB_is_child_selected;
  static final Callback AtkSelectionCB_ref_selection;
  static final Callback AtkTableCB_ref_at;
  static final Callback AtkTableCB_get_index_at;
  static final Callback AtkTableCB_get_column_at_index;
  static final Callback AtkTableCB_get_row_at_index;
  static final Callback AtkTableCB_get_n_columns;
  static final Callback AtkTableCB_get_n_rows;
  static final Callback AtkTableCB_get_column_extent_at;
  static final Callback AtkTableCB_get_row_extent_at;
  static final Callback AtkTableCB_get_summary;
  static final Callback AtkTableCB_get_caption;
  static final Callback AtkTableCB_get_column_description;
  static final Callback AtkTableCB_get_row_description;
  static final Callback AtkTableCB_get_column_header;
  static final Callback AtkTableCB_get_row_header;
  static final Callback AtkTableCB_get_selected_columns;
  static final Callback AtkTableCB_get_selected_rows;
  static final Callback AtkTableCB_is_column_selected;
  static final Callback AtkTableCB_is_row_selected;
  static final Callback AtkTableCB_is_selected;
  static final Callback AtkTableCB_add_column_selection;
  static final Callback AtkTableCB_add_row_selection;
  static final Callback AtkTableCB_remove_column_selection;
  static final Callback AtkTableCB_remove_row_selection;
  static final Callback AtkTextCB_get_character_extents;
  static final Callback AtkTextCB_get_range_extents;
  static final Callback AtkTextCB_get_run_attributes;
  static final Callback AtkTextCB_get_offset_at_point;
  static final Callback AtkTextCB_add_selection;
  static final Callback AtkTextCB_remove_selection;
  static final Callback AtkTextCB_set_selection;
  static final Callback AtkTextCB_get_caret_offset;
  static final Callback AtkTextCB_set_caret_offset;
  static final Callback AtkTextCB_get_n_selections;
  static final Callback AtkTextCB_get_selection;
  static final Callback AtkTextCB_get_text;
  static final Callback AtkTextCB_get_text_after_offset;
  static final Callback AtkTextCB_get_text_at_offset;
  static final Callback AtkTextCB_get_text_before_offset;
  static final Callback AtkTextCB_get_character_at_offset;
  static final Callback AtkTextCB_get_character_count;
  static final Callback AtkTextCB_get_bounded_ranges;
  static final Callback AtkValueCB_get_current_value;
  static final Callback AtkValueCB_get_maximum_value;
  static final Callback AtkValueCB_get_minimum_value;
  static final Callback AtkValueCB_set_current_value;
  static final Callback GObjectClass_finalize;
  static final Callback AtkObjectFactoryCB_create_accessible;
  static final Callback InitActionIfaceCB;
  static final Callback InitComponentIfaceCB;
  static final Callback InitEditableTextIfaceCB;
  static final Callback InitHypertextIfaceCB;
  static final Callback GTypeInfo_base_init_type;
  static final Callback InitSelectionIfaceCB;
  static final Callback InitTableIfaceCB;
  static final Callback InitTextIfaceCB;
  static final Callback InitValueIfaceCB;
  static final Callback GTypeInfo_base_init_factory;
  static final int ActionIfaceDefinition;
  static final int ComponentIfaceDefinition;
  static final int EditableTextIfaceDefinition;
  static final int HypertextIfaceDefinition;
  static final int SelectionIfaceDefinition;
  static final int TableIfaceDefinition;
  static final int TextIfaceDefinition;
  static final int ValueIfaceDefinition;
  
  private static Callback newCallback(Object paramObject, String paramString, int paramInt)
  {
    Callback localCallback = new Callback(paramObject, paramString, paramInt);
    if (localCallback.getAddress() == 0) {
      SWT.error(3);
    }
    return localCallback;
  }
  
  static String getTypeName(int paramInt)
  {
    int i = OS.g_type_name(paramInt);
    int j = OS.strlen(i);
    byte[] arrayOfByte = new byte[j];
    OS.memmove(arrayOfByte, i, j);
    return new String(Converter.mbcsToWcs(null, arrayOfByte));
  }
  
  static int getParentType(int paramInt)
  {
    LONG localLONG = null;
    while ((paramInt != 0) && ((localLONG = (LONG)Factories.get(new LONG(paramInt))) == null)) {
      paramInt = OS.g_type_parent(paramInt);
    }
    if (localLONG == null) {
      return 0;
    }
    return localLONG.value;
  }
  
  static int atkObjectFactory_create_accessible(int paramInt)
  {
    Accessible localAccessible = (Accessible)Accessibles.get(new LONG(paramInt));
    if (localAccessible == null)
    {
      i = OS.g_object_new(getParentType(OS.G_OBJECT_TYPE(paramInt)), 0);
      ATK.atk_object_initialize(i, paramInt);
      return i;
    }
    if (localAccessible.accessibleObject != null) {
      return localAccessible.accessibleObject.handle;
    }
    int i = OS.G_OBJECT_TYPE(paramInt);
    int j = getParentType(i);
    if (j == 0) {
      j = ATK.GTK_TYPE_ACCESSIBLE();
    }
    int k = getType(getTypeName(i), localAccessible, j, -1);
    AccessibleObject localAccessibleObject = new AccessibleObject(k, paramInt, localAccessible, false);
    localAccessible.accessibleObject = localAccessibleObject;
    localAccessible.addRelations();
    return localAccessibleObject.handle;
  }
  
  static AccessibleObject createChildAccessible(Accessible paramAccessible, int paramInt)
  {
    int i = getType("Child", paramAccessible, ATK.GTK_TYPE_ACCESSIBLE(), paramInt);
    return new AccessibleObject(i, 0, paramAccessible, true);
  }
  
  static void createAccessible(Accessible paramAccessible)
  {
    int i = paramAccessible.getControlHandle();
    OS.gtk_widget_get_accessible(i);
  }
  
  static int getType(String paramString, Accessible paramAccessible, int paramInt1, int paramInt2)
  {
    AccessibleControlEvent localAccessibleControlEvent = new AccessibleControlEvent(paramAccessible);
    localAccessibleControlEvent.childID = paramInt2;
    Vector localVector = paramAccessible.accessibleControlListeners;
    int i = 0;
    int j = localVector == null ? 0 : localVector.size();
    while (i < j)
    {
      AccessibleControlListener localAccessibleControlListener = (AccessibleControlListener)localVector.elementAt(i);
      localAccessibleControlListener.getRole(localAccessibleControlEvent);
      i++;
    }
    i = 0;
    j = 0;
    int k = 0;
    int m = 0;
    int n = 0;
    int i1 = 0;
    int i2 = 0;
    if (localAccessibleControlEvent.detail != 0)
    {
      for (int i3 = 0; i3 < actionRoles.length; i3++) {
        if (localAccessibleControlEvent.detail == actionRoles[i3])
        {
          i = 1;
          break;
        }
      }
      for (i3 = 0; i3 < editableTextRoles.length; i3++) {
        if (localAccessibleControlEvent.detail == editableTextRoles[i3])
        {
          j = 1;
          break;
        }
      }
      for (i3 = 0; i3 < hypertextRoles.length; i3++) {
        if (localAccessibleControlEvent.detail == hypertextRoles[i3])
        {
          k = 1;
          break;
        }
      }
      for (i3 = 0; i3 < selectionRoles.length; i3++) {
        if (localAccessibleControlEvent.detail == selectionRoles[i3])
        {
          m = 1;
          break;
        }
      }
      for (i3 = 0; i3 < tableRoles.length; i3++) {
        if (localAccessibleControlEvent.detail == tableRoles[i3])
        {
          n = 1;
          break;
        }
      }
      for (i3 = 0; i3 < textRoles.length; i3++) {
        if (localAccessibleControlEvent.detail == textRoles[i3])
        {
          i1 = 1;
          break;
        }
      }
      for (i3 = 0; i3 < valueRoles.length; i3++) {
        if (localAccessibleControlEvent.detail == valueRoles[i3])
        {
          i2 = 1;
          break;
        }
      }
    }
    else
    {
      i = j = k = m = n = i1 = i2 = 1;
    }
    String str = "SWTAccessible" + paramString;
    if (i != 0) {
      str = str + "Action";
    }
    if (j != 0) {
      str = str + "EditableText";
    }
    if (k != 0) {
      str = str + "Hypertext";
    }
    if (m != 0) {
      str = str + "Selection";
    }
    if (n != 0) {
      str = str + "Table";
    }
    if (i1 != 0) {
      str = str + "Text";
    }
    if (i2 != 0) {
      str = str + "Value";
    }
    byte[] arrayOfByte = Converter.wcsToMbcs(null, str, true);
    int i4 = OS.g_type_from_name(arrayOfByte);
    if (i4 == 0)
    {
      if (AccessibleObject.DEBUG) {
        AccessibleObject.print("-->New Type=" + str);
      }
      int i5 = OS.g_malloc(GTypeQuery.sizeof);
      OS.g_type_query(paramInt1, i5);
      GTypeQuery localGTypeQuery = new GTypeQuery();
      OS.memmove(localGTypeQuery, i5, GTypeQuery.sizeof);
      OS.g_free(i5);
      GTypeInfo localGTypeInfo = new GTypeInfo();
      localGTypeInfo.base_init = GTypeInfo_base_init_type.getAddress();
      localGTypeInfo.class_size = ((short)localGTypeQuery.class_size);
      localGTypeInfo.instance_size = ((short)localGTypeQuery.instance_size);
      int i6 = OS.g_malloc(GTypeInfo.sizeof);
      OS.memmove(i6, localGTypeInfo, GTypeInfo.sizeof);
      i4 = OS.g_type_register_static(paramInt1, arrayOfByte, i6, 0);
      OS.g_type_add_interface_static(i4, ATK.ATK_TYPE_COMPONENT(), ComponentIfaceDefinition);
      if (i != 0) {
        OS.g_type_add_interface_static(i4, ATK.ATK_TYPE_ACTION(), ActionIfaceDefinition);
      }
      if (j != 0) {
        OS.g_type_add_interface_static(i4, ATK.ATK_TYPE_EDITABLE_TEXT(), EditableTextIfaceDefinition);
      }
      if (k != 0) {
        OS.g_type_add_interface_static(i4, ATK.ATK_TYPE_HYPERTEXT(), HypertextIfaceDefinition);
      }
      if (m != 0) {
        OS.g_type_add_interface_static(i4, ATK.ATK_TYPE_SELECTION(), SelectionIfaceDefinition);
      }
      if (n != 0) {
        OS.g_type_add_interface_static(i4, ATK.ATK_TYPE_TABLE(), TableIfaceDefinition);
      }
      if (i1 != 0) {
        OS.g_type_add_interface_static(i4, ATK.ATK_TYPE_TEXT(), TextIfaceDefinition);
      }
      if (i2 != 0) {
        OS.g_type_add_interface_static(i4, ATK.ATK_TYPE_VALUE(), ValueIfaceDefinition);
      }
    }
    return i4;
  }
  
  static int gTypeInfo_base_init_factory(int paramInt)
  {
    AtkObjectFactoryClass localAtkObjectFactoryClass = new AtkObjectFactoryClass();
    ATK.memmove(localAtkObjectFactoryClass, paramInt);
    localAtkObjectFactoryClass.create_accessible = AtkObjectFactoryCB_create_accessible.getAddress();
    ATK.memmove(paramInt, localAtkObjectFactoryClass);
    return 0;
  }
  
  static int gTypeInfo_base_init_type(int paramInt)
  {
    AtkObjectClass localAtkObjectClass = new AtkObjectClass();
    ATK.memmove(localAtkObjectClass, paramInt);
    localAtkObjectClass.get_name = AtkObjectCB_get_name.getAddress();
    localAtkObjectClass.get_description = AtkObjectCB_get_description.getAddress();
    localAtkObjectClass.get_n_children = AtkObjectCB_get_n_children.getAddress();
    localAtkObjectClass.get_role = AtkObjectCB_get_role.getAddress();
    localAtkObjectClass.get_parent = AtkObjectCB_get_parent.getAddress();
    localAtkObjectClass.ref_state_set = AtkObjectCB_ref_state_set.getAddress();
    localAtkObjectClass.get_index_in_parent = AtkObjectCB_get_index_in_parent.getAddress();
    localAtkObjectClass.ref_child = AtkObjectCB_ref_child.getAddress();
    localAtkObjectClass.get_attributes = AtkObjectCB_get_attributes.getAddress();
    int i = OS.G_OBJECT_CLASS(paramInt);
    GObjectClass localGObjectClass = new GObjectClass();
    OS.memmove(localGObjectClass, i);
    localGObjectClass.finalize = GObjectClass_finalize.getAddress();
    OS.memmove(i, localGObjectClass);
    ATK.memmove(paramInt, localAtkObjectClass);
    return 0;
  }
  
  static int initActionIfaceCB(int paramInt)
  {
    AtkActionIface localAtkActionIface = new AtkActionIface();
    ATK.memmove(localAtkActionIface, paramInt);
    localAtkActionIface.do_action = AtkActionCB_do_action.getAddress();
    localAtkActionIface.get_n_actions = AtkActionCB_get_n_actions.getAddress();
    localAtkActionIface.get_description = AtkActionCB_get_description.getAddress();
    localAtkActionIface.get_keybinding = AtkActionCB_get_keybinding.getAddress();
    localAtkActionIface.get_name = AtkActionCB_get_name.getAddress();
    ATK.memmove(paramInt, localAtkActionIface);
    return 0;
  }
  
  static int initComponentIfaceCB(int paramInt)
  {
    AtkComponentIface localAtkComponentIface = new AtkComponentIface();
    ATK.memmove(localAtkComponentIface, paramInt);
    localAtkComponentIface.get_extents = AtkComponentCB_get_extents.getAddress();
    localAtkComponentIface.get_position = AtkComponentCB_get_position.getAddress();
    localAtkComponentIface.get_size = AtkComponentCB_get_size.getAddress();
    localAtkComponentIface.ref_accessible_at_point = AtkComponentCB_ref_accessible_at_point.getAddress();
    ATK.memmove(paramInt, localAtkComponentIface);
    return 0;
  }
  
  static int initEditableTextIfaceCB(int paramInt)
  {
    AtkEditableTextIface localAtkEditableTextIface = new AtkEditableTextIface();
    ATK.memmove(localAtkEditableTextIface, paramInt);
    localAtkEditableTextIface.set_run_attributes = AtkEditableTextCB_set_run_attributes.getAddress();
    localAtkEditableTextIface.set_text_contents = AtkEditableTextCB_set_text_contents.getAddress();
    localAtkEditableTextIface.insert_text = AtkEditableTextCB_insert_text.getAddress();
    localAtkEditableTextIface.copy_text = AtkEditableTextCB_copy_text.getAddress();
    localAtkEditableTextIface.cut_text = AtkEditableTextCB_cut_text.getAddress();
    localAtkEditableTextIface.delete_text = AtkEditableTextCB_delete_text.getAddress();
    localAtkEditableTextIface.paste_text = AtkEditableTextCB_paste_text.getAddress();
    ATK.memmove(paramInt, localAtkEditableTextIface);
    return 0;
  }
  
  static int initHypertextIfaceCB(int paramInt)
  {
    AtkHypertextIface localAtkHypertextIface = new AtkHypertextIface();
    ATK.memmove(localAtkHypertextIface, paramInt);
    localAtkHypertextIface.get_link = AtkHypertextCB_get_link.getAddress();
    localAtkHypertextIface.get_link_index = AtkHypertextCB_get_link_index.getAddress();
    localAtkHypertextIface.get_n_links = AtkHypertextCB_get_n_links.getAddress();
    ATK.memmove(paramInt, localAtkHypertextIface);
    return 0;
  }
  
  static int initSelectionIfaceCB(int paramInt)
  {
    AtkSelectionIface localAtkSelectionIface = new AtkSelectionIface();
    ATK.memmove(localAtkSelectionIface, paramInt);
    localAtkSelectionIface.is_child_selected = AtkSelectionCB_is_child_selected.getAddress();
    localAtkSelectionIface.ref_selection = AtkSelectionCB_ref_selection.getAddress();
    ATK.memmove(paramInt, localAtkSelectionIface);
    return 0;
  }
  
  static int initTableIfaceCB(int paramInt)
  {
    AtkTableIface localAtkTableIface = new AtkTableIface();
    ATK.memmove(localAtkTableIface, paramInt);
    localAtkTableIface.ref_at = AtkTableCB_ref_at.getAddress();
    localAtkTableIface.get_index_at = AtkTableCB_get_index_at.getAddress();
    localAtkTableIface.get_column_at_index = AtkTableCB_get_column_at_index.getAddress();
    localAtkTableIface.get_row_at_index = AtkTableCB_get_row_at_index.getAddress();
    localAtkTableIface.get_n_columns = AtkTableCB_get_n_columns.getAddress();
    localAtkTableIface.get_n_rows = AtkTableCB_get_n_rows.getAddress();
    localAtkTableIface.get_column_extent_at = AtkTableCB_get_column_extent_at.getAddress();
    localAtkTableIface.get_row_extent_at = AtkTableCB_get_row_extent_at.getAddress();
    localAtkTableIface.get_caption = AtkTableCB_get_caption.getAddress();
    localAtkTableIface.get_summary = AtkTableCB_get_summary.getAddress();
    localAtkTableIface.get_column_description = AtkTableCB_get_column_description.getAddress();
    localAtkTableIface.get_row_description = AtkTableCB_get_row_description.getAddress();
    localAtkTableIface.get_column_header = AtkTableCB_get_column_header.getAddress();
    localAtkTableIface.get_row_header = AtkTableCB_get_row_header.getAddress();
    localAtkTableIface.get_selected_columns = AtkTableCB_get_selected_columns.getAddress();
    localAtkTableIface.get_selected_rows = AtkTableCB_get_selected_rows.getAddress();
    localAtkTableIface.is_column_selected = AtkTableCB_is_column_selected.getAddress();
    localAtkTableIface.is_row_selected = AtkTableCB_is_row_selected.getAddress();
    localAtkTableIface.is_selected = AtkTableCB_is_selected.getAddress();
    localAtkTableIface.add_column_selection = AtkTableCB_add_column_selection.getAddress();
    localAtkTableIface.add_row_selection = AtkTableCB_add_row_selection.getAddress();
    localAtkTableIface.remove_column_selection = AtkTableCB_remove_column_selection.getAddress();
    localAtkTableIface.remove_row_selection = AtkTableCB_remove_row_selection.getAddress();
    ATK.memmove(paramInt, localAtkTableIface);
    return 0;
  }
  
  static int initTextIfaceCB(int paramInt)
  {
    AtkTextIface localAtkTextIface = new AtkTextIface();
    ATK.memmove(localAtkTextIface, paramInt);
    localAtkTextIface.get_range_extents = AtkTextCB_get_range_extents.getAddress();
    localAtkTextIface.get_character_extents = AtkTextCB_get_character_extents.getAddress();
    localAtkTextIface.get_run_attributes = AtkTextCB_get_run_attributes.getAddress();
    localAtkTextIface.get_offset_at_point = AtkTextCB_get_offset_at_point.getAddress();
    localAtkTextIface.add_selection = AtkTextCB_add_selection.getAddress();
    localAtkTextIface.remove_selection = AtkTextCB_remove_selection.getAddress();
    localAtkTextIface.set_selection = AtkTextCB_set_selection.getAddress();
    localAtkTextIface.get_caret_offset = AtkTextCB_get_caret_offset.getAddress();
    localAtkTextIface.set_caret_offset = AtkTextCB_set_caret_offset.getAddress();
    localAtkTextIface.get_character_at_offset = AtkTextCB_get_character_at_offset.getAddress();
    localAtkTextIface.get_character_count = AtkTextCB_get_character_count.getAddress();
    localAtkTextIface.get_n_selections = AtkTextCB_get_n_selections.getAddress();
    localAtkTextIface.get_selection = AtkTextCB_get_selection.getAddress();
    localAtkTextIface.get_text = AtkTextCB_get_text.getAddress();
    localAtkTextIface.get_text_after_offset = AtkTextCB_get_text_after_offset.getAddress();
    localAtkTextIface.get_text_at_offset = AtkTextCB_get_text_at_offset.getAddress();
    localAtkTextIface.get_text_before_offset = AtkTextCB_get_text_before_offset.getAddress();
    localAtkTextIface.get_bounded_ranges = AtkTextCB_get_bounded_ranges.getAddress();
    ATK.memmove(paramInt, localAtkTextIface);
    return 0;
  }
  
  static int initValueIfaceCB(int paramInt)
  {
    AtkValueIface localAtkValueIface = new AtkValueIface();
    ATK.memmove(localAtkValueIface, paramInt);
    localAtkValueIface.get_current_value = AtkValueCB_get_current_value.getAddress();
    localAtkValueIface.get_maximum_value = AtkValueCB_get_maximum_value.getAddress();
    localAtkValueIface.get_minimum_value = AtkValueCB_get_minimum_value.getAddress();
    localAtkValueIface.set_current_value = AtkValueCB_set_current_value.getAddress();
    ATK.memmove(paramInt, localAtkValueIface);
    return 0;
  }
  
  static void registerAccessible(Accessible paramAccessible)
  {
    int i = paramAccessible.getControlHandle();
    int j = OS.G_OBJECT_TYPE(i);
    int k = ATK.atk_get_default_registry();
    int m = ATK.atk_registry_get_factory(k, j);
    if (ATK.ATK_IS_NO_OP_OBJECT_FACTORY(m)) {
      return;
    }
    String str = "SWTFactory" + getTypeName(j);
    byte[] arrayOfByte = Converter.wcsToMbcs(null, str, true);
    if (OS.g_type_from_name(arrayOfByte) == 0)
    {
      if (AccessibleObject.DEBUG) {
        AccessibleObject.print("-->New Factory=" + str);
      }
      GTypeInfo localGTypeInfo = new GTypeInfo();
      localGTypeInfo.base_init = GTypeInfo_base_init_factory.getAddress();
      localGTypeInfo.class_size = ((short)ATK.AtkObjectFactoryClass_sizeof());
      localGTypeInfo.instance_size = ((short)ATK.AtkObjectFactory_sizeof());
      int n = OS.g_malloc(GTypeInfo.sizeof);
      OS.memmove(n, localGTypeInfo, GTypeInfo.sizeof);
      int i1 = OS.g_type_register_static(ATK.ATK_TYPE_OBJECT_FACTORY(), arrayOfByte, n, 0);
      int i2 = ATK.atk_object_factory_get_accessible_type(m);
      ATK.atk_registry_set_factory_type(k, j, i1);
      Factories.put(new LONG(j), new LONG(i2));
    }
    if (AccessibleObject.DEBUG) {
      AccessibleObject.print("-->Register=" + paramAccessible.control + " " + i);
    }
    Accessibles.put(new LONG(i), paramAccessible);
  }
  
  static void unregisterAccessible(Accessible paramAccessible)
  {
    int i = paramAccessible.getControlHandle();
    Accessibles.remove(new LONG(i));
    if (AccessibleObject.DEBUG) {
      AccessibleObject.print("-->Deregister=" + paramAccessible.control + " " + i);
    }
  }
  
  static
  {
    AtkObjectCB_get_description = newCallback(AccessibleObject.class, "atkObject_get_description", 1);
    AtkObjectCB_get_n_children = newCallback(AccessibleObject.class, "atkObject_get_n_children", 1);
    AtkObjectCB_get_role = newCallback(AccessibleObject.class, "atkObject_get_role", 1);
    AtkObjectCB_get_parent = newCallback(AccessibleObject.class, "atkObject_get_parent", 1);
    AtkObjectCB_ref_state_set = newCallback(AccessibleObject.class, "atkObject_ref_state_set", 1);
    AtkObjectCB_get_index_in_parent = newCallback(AccessibleObject.class, "atkObject_get_index_in_parent", 1);
    AtkObjectCB_ref_child = newCallback(AccessibleObject.class, "atkObject_ref_child", 2);
    AtkObjectCB_get_attributes = newCallback(AccessibleObject.class, "atkObject_get_attributes", 1);
    AtkSelectionCB_is_child_selected = newCallback(AccessibleObject.class, "atkSelection_is_child_selected", 2);
    AtkSelectionCB_ref_selection = newCallback(AccessibleObject.class, "atkSelection_ref_selection", 2);
    AtkTableCB_ref_at = newCallback(AccessibleObject.class, "atkTable_ref_at", 3);
    AtkTableCB_get_index_at = newCallback(AccessibleObject.class, "atkTable_get_index_at", 3);
    AtkTableCB_get_column_at_index = newCallback(AccessibleObject.class, "atkTable_get_column_at_index", 2);
    AtkTableCB_get_row_at_index = newCallback(AccessibleObject.class, "atkTable_get_row_at_index", 2);
    AtkTableCB_get_n_columns = newCallback(AccessibleObject.class, "atkTable_get_n_columns", 1);
    AtkTableCB_get_n_rows = newCallback(AccessibleObject.class, "atkTable_get_n_rows", 1);
    AtkTableCB_get_column_extent_at = newCallback(AccessibleObject.class, "atkTable_get_column_extent_at", 3);
    AtkTableCB_get_row_extent_at = newCallback(AccessibleObject.class, "atkTable_get_row_extent_at", 3);
    AtkTableCB_get_caption = newCallback(AccessibleObject.class, "atkTable_get_caption", 1);
    AtkTableCB_get_summary = newCallback(AccessibleObject.class, "atkTable_get_summary", 1);
    AtkTableCB_get_column_description = newCallback(AccessibleObject.class, "atkTable_get_column_description", 2);
    AtkTableCB_get_row_description = newCallback(AccessibleObject.class, "atkTable_get_row_description", 2);
    AtkTableCB_get_column_header = newCallback(AccessibleObject.class, "atkTable_get_column_header", 2);
    AtkTableCB_get_row_header = newCallback(AccessibleObject.class, "atkTable_get_row_header", 2);
    AtkTableCB_get_selected_columns = newCallback(AccessibleObject.class, "atkTable_get_selected_columns", 2);
    AtkTableCB_get_selected_rows = newCallback(AccessibleObject.class, "atkTable_get_selected_rows", 2);
    AtkTableCB_is_column_selected = newCallback(AccessibleObject.class, "atkTable_is_column_selected", 2);
    AtkTableCB_is_row_selected = newCallback(AccessibleObject.class, "atkTable_is_row_selected", 2);
    AtkTableCB_is_selected = newCallback(AccessibleObject.class, "atkTable_is_selected", 3);
    AtkTableCB_add_column_selection = newCallback(AccessibleObject.class, "atkTable_add_column_selection", 2);
    AtkTableCB_add_row_selection = newCallback(AccessibleObject.class, "atkTable_add_row_selection", 2);
    AtkTableCB_remove_column_selection = newCallback(AccessibleObject.class, "atkTable_remove_column_selection", 2);
    AtkTableCB_remove_row_selection = newCallback(AccessibleObject.class, "atkTable_remove_row_selection", 2);
    AtkTextCB_get_character_extents = newCallback(AccessibleObject.class, "atkText_get_character_extents", 7);
    AtkTextCB_get_range_extents = newCallback(AccessibleObject.class, "atkText_get_range_extents", 5);
    AtkTextCB_get_run_attributes = newCallback(AccessibleObject.class, "atkText_get_run_attributes", 4);
    AtkTextCB_get_offset_at_point = newCallback(AccessibleObject.class, "atkText_get_offset_at_point", 4);
    AtkTextCB_add_selection = newCallback(AccessibleObject.class, "atkText_add_selection", 3);
    AtkTextCB_remove_selection = newCallback(AccessibleObject.class, "atkText_remove_selection", 2);
    AtkTextCB_set_selection = newCallback(AccessibleObject.class, "atkText_set_selection", 4);
    AtkTextCB_get_caret_offset = newCallback(AccessibleObject.class, "atkText_get_caret_offset", 1);
    AtkTextCB_set_caret_offset = newCallback(AccessibleObject.class, "atkText_set_caret_offset", 2);
    AtkTextCB_get_n_selections = newCallback(AccessibleObject.class, "atkText_get_n_selections", 1);
    AtkTextCB_get_selection = newCallback(AccessibleObject.class, "atkText_get_selection", 4);
    AtkTextCB_get_text = newCallback(AccessibleObject.class, "atkText_get_text", 3);
    AtkTextCB_get_text_after_offset = newCallback(AccessibleObject.class, "atkText_get_text_after_offset", 5);
    AtkTextCB_get_text_at_offset = newCallback(AccessibleObject.class, "atkText_get_text_at_offset", 5);
    AtkTextCB_get_text_before_offset = newCallback(AccessibleObject.class, "atkText_get_text_before_offset", 5);
    AtkTextCB_get_character_at_offset = newCallback(AccessibleObject.class, "atkText_get_character_at_offset", 2);
    AtkTextCB_get_character_count = newCallback(AccessibleObject.class, "atkText_get_character_count", 1);
    AtkTextCB_get_bounded_ranges = newCallback(AccessibleObject.class, "atkText_get_bounded_ranges", 5);
    AtkValueCB_get_current_value = newCallback(AccessibleObject.class, "atkValue_get_current_value", 2);
    AtkValueCB_get_maximum_value = newCallback(AccessibleObject.class, "atkValue_get_maximum_value", 2);
    AtkValueCB_get_minimum_value = newCallback(AccessibleObject.class, "atkValue_get_minimum_value", 2);
    AtkValueCB_set_current_value = newCallback(AccessibleObject.class, "atkValue_set_current_value", 2);
    GObjectClass_finalize = newCallback(AccessibleObject.class, "gObjectClass_finalize", 1);
    GTypeInfo_base_init_type = newCallback(AccessibleFactory.class, "gTypeInfo_base_init_type", 1);
    GTypeInfo_base_init_factory = newCallback(AccessibleFactory.class, "gTypeInfo_base_init_factory", 1);
    AtkObjectFactoryCB_create_accessible = newCallback(AccessibleFactory.class, "atkObjectFactory_create_accessible", 1);
    InitActionIfaceCB = newCallback(AccessibleFactory.class, "initActionIfaceCB", 1);
    GInterfaceInfo localGInterfaceInfo = new GInterfaceInfo();
    localGInterfaceInfo.interface_init = InitActionIfaceCB.getAddress();
    ActionIfaceDefinition = OS.g_malloc(GInterfaceInfo.sizeof);
    OS.memmove(ActionIfaceDefinition, localGInterfaceInfo, GInterfaceInfo.sizeof);
    InitComponentIfaceCB = newCallback(AccessibleFactory.class, "initComponentIfaceCB", 1);
    localGInterfaceInfo = new GInterfaceInfo();
    localGInterfaceInfo.interface_init = InitComponentIfaceCB.getAddress();
    ComponentIfaceDefinition = OS.g_malloc(GInterfaceInfo.sizeof);
    OS.memmove(ComponentIfaceDefinition, localGInterfaceInfo, GInterfaceInfo.sizeof);
    InitEditableTextIfaceCB = newCallback(AccessibleFactory.class, "initEditableTextIfaceCB", 1);
    localGInterfaceInfo = new GInterfaceInfo();
    localGInterfaceInfo.interface_init = InitEditableTextIfaceCB.getAddress();
    EditableTextIfaceDefinition = OS.g_malloc(GInterfaceInfo.sizeof);
    OS.memmove(EditableTextIfaceDefinition, localGInterfaceInfo, GInterfaceInfo.sizeof);
    InitHypertextIfaceCB = newCallback(AccessibleFactory.class, "initHypertextIfaceCB", 1);
    localGInterfaceInfo = new GInterfaceInfo();
    localGInterfaceInfo.interface_init = InitHypertextIfaceCB.getAddress();
    HypertextIfaceDefinition = OS.g_malloc(GInterfaceInfo.sizeof);
    OS.memmove(HypertextIfaceDefinition, localGInterfaceInfo, GInterfaceInfo.sizeof);
    InitSelectionIfaceCB = newCallback(AccessibleFactory.class, "initSelectionIfaceCB", 1);
    localGInterfaceInfo = new GInterfaceInfo();
    localGInterfaceInfo.interface_init = InitSelectionIfaceCB.getAddress();
    SelectionIfaceDefinition = OS.g_malloc(GInterfaceInfo.sizeof);
    OS.memmove(SelectionIfaceDefinition, localGInterfaceInfo, GInterfaceInfo.sizeof);
    InitTableIfaceCB = newCallback(AccessibleFactory.class, "initTableIfaceCB", 1);
    localGInterfaceInfo = new GInterfaceInfo();
    localGInterfaceInfo.interface_init = InitTableIfaceCB.getAddress();
    TableIfaceDefinition = OS.g_malloc(GInterfaceInfo.sizeof);
    OS.memmove(TableIfaceDefinition, localGInterfaceInfo, GInterfaceInfo.sizeof);
    InitTextIfaceCB = newCallback(AccessibleFactory.class, "initTextIfaceCB", 1);
    localGInterfaceInfo = new GInterfaceInfo();
    localGInterfaceInfo.interface_init = InitTextIfaceCB.getAddress();
    TextIfaceDefinition = OS.g_malloc(GInterfaceInfo.sizeof);
    OS.memmove(TextIfaceDefinition, localGInterfaceInfo, GInterfaceInfo.sizeof);
    InitValueIfaceCB = newCallback(AccessibleFactory.class, "initValueIfaceCB", 1);
    localGInterfaceInfo = new GInterfaceInfo();
    localGInterfaceInfo.interface_init = InitValueIfaceCB.getAddress();
    ValueIfaceDefinition = OS.g_malloc(GInterfaceInfo.sizeof);
    OS.memmove(ValueIfaceDefinition, localGInterfaceInfo, GInterfaceInfo.sizeof);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/accessibility/AccessibleFactory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */