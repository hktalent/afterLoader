package org.eclipse.swt.internal;

import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.ImageData;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.internal.cairo.Cairo;
import org.eclipse.swt.internal.gtk.OS;

public class ImageList
{
  int[] pixbufs = new int[4];
  int width = -1;
  int height = -1;
  Image[] images = new Image[4];
  
  public static int convertSurface(Image paramImage)
  {
    int i = paramImage.surface;
    int j = Cairo.cairo_surface_get_type(i);
    if (j != 0)
    {
      Rectangle localRectangle = paramImage.getBounds();
      int k = Cairo.cairo_surface_get_content(i) == 4096 ? 1 : 0;
      i = Cairo.cairo_image_surface_create(k, localRectangle.width, localRectangle.height);
      if (i == 0) {
        SWT.error(2);
      }
      int m = Cairo.cairo_create(i);
      if (m == 0) {
        SWT.error(2);
      }
      Cairo.cairo_set_operator(m, 1);
      Cairo.cairo_set_source_surface(m, paramImage.surface, 0.0D, 0.0D);
      Cairo.cairo_paint(m);
      Cairo.cairo_destroy(m);
    }
    else
    {
      Cairo.cairo_surface_reference(i);
    }
    return i;
  }
  
  public static int createPixbuf(Image paramImage)
  {
    int m;
    int n;
    int i;
    int i2;
    int i3;
    int i6;
    int i7;
    int i12;
    int i14;
    if (OS.USE_CAIRO)
    {
      int j = convertSurface(paramImage);
      int k = Cairo.cairo_image_surface_get_format(j);
      m = Cairo.cairo_image_surface_get_width(j);
      n = Cairo.cairo_image_surface_get_height(j);
      boolean bool = k == 0;
      i = OS.gdk_pixbuf_new(0, bool, 8, m, n);
      if (i == 0) {
        SWT.error(2);
      }
      i2 = OS.gdk_pixbuf_get_rowstride(i);
      i3 = OS.gdk_pixbuf_get_pixels(i);
      int i4;
      int i8;
      if (OS.BIG_ENDIAN)
      {
        i4 = 0;
        i6 = 1;
        i7 = 2;
        i8 = 3;
      }
      else
      {
        i4 = 3;
        i6 = 2;
        i7 = 1;
        i8 = 0;
      }
      byte[] arrayOfByte5 = new byte[i2];
      i12 = Cairo.cairo_image_surface_get_data(j);
      int i19;
      int i20;
      int i21;
      int i22;
      if (bool)
      {
        for (int i13 = 0; i13 < n; i13++)
        {
          OS.memmove(arrayOfByte5, i12 + i13 * i2, i2);
          int i15 = 0;
          for (int i17 = 0; i15 < m; i17 += 4)
          {
            i19 = arrayOfByte5[(i17 + i4)] & 0xFF;
            i20 = arrayOfByte5[(i17 + i6)] & 0xFF;
            i21 = arrayOfByte5[(i17 + i7)] & 0xFF;
            i22 = arrayOfByte5[(i17 + i8)] & 0xFF;
            arrayOfByte5[(i17 + 3)] = ((byte)i19);
            if (i19 != 0)
            {
              arrayOfByte5[(i17 + 0)] = ((byte)((i20 * 255 + i19 / 2) / i19));
              arrayOfByte5[(i17 + 1)] = ((byte)((i21 * 255 + i19 / 2) / i19));
              arrayOfByte5[(i17 + 2)] = ((byte)((i22 * 255 + i19 / 2) / i19));
            }
            i15++;
          }
          OS.memmove(i3 + i13 * i2, arrayOfByte5, i2);
        }
      }
      else
      {
        i14 = Cairo.cairo_image_surface_get_stride(j);
        byte[] arrayOfByte6 = new byte[i14];
        for (int i18 = 0; i18 < n; i18++)
        {
          OS.memmove(arrayOfByte6, i12 + i18 * i14, i14);
          i19 = 0;
          i20 = 0;
          for (i21 = 0; i19 < m; i21 += 4)
          {
            i22 = arrayOfByte6[(i21 + i6)];
            int i23 = arrayOfByte6[(i21 + i7)];
            int i24 = arrayOfByte6[(i21 + i8)];
            arrayOfByte5[(i20 + 0)] = i22;
            arrayOfByte5[(i20 + 1)] = i23;
            arrayOfByte5[(i20 + 2)] = i24;
            i19++;
            i20 += 3;
          }
          OS.memmove(i3 + i18 * i2, arrayOfByte5, i2);
        }
      }
      Cairo.cairo_surface_destroy(j);
    }
    else
    {
      int[] arrayOfInt1 = new int[1];
      int[] arrayOfInt2 = new int[1];
      if (OS.GTK_VERSION >= OS.VERSION(2, 24, 0)) {
        OS.gdk_pixmap_get_size(paramImage.pixmap, arrayOfInt1, arrayOfInt2);
      } else {
        OS.gdk_drawable_get_size(paramImage.pixmap, arrayOfInt1, arrayOfInt2);
      }
      m = OS.gdk_colormap_get_system();
      n = (paramImage.mask != 0) && (OS.gdk_drawable_get_depth(paramImage.mask) == 1) ? 1 : 0;
      if (n != 0)
      {
        i = OS.gdk_pixbuf_new(0, true, 8, arrayOfInt1[0], arrayOfInt2[0]);
        if (i == 0) {
          SWT.error(2);
        }
        OS.gdk_pixbuf_get_from_drawable(i, paramImage.pixmap, m, 0, 0, 0, 0, arrayOfInt1[0], arrayOfInt2[0]);
        int i1 = OS.gdk_pixbuf_new(0, false, 8, arrayOfInt1[0], arrayOfInt2[0]);
        if (i1 == 0) {
          SWT.error(2);
        }
        OS.gdk_pixbuf_get_from_drawable(i1, paramImage.mask, 0, 0, 0, 0, 0, arrayOfInt1[0], arrayOfInt2[0]);
        i2 = OS.gdk_pixbuf_get_rowstride(i);
        i3 = OS.gdk_pixbuf_get_pixels(i);
        byte[] arrayOfByte2 = new byte[i2];
        i6 = OS.gdk_pixbuf_get_rowstride(i1);
        i7 = OS.gdk_pixbuf_get_pixels(i1);
        byte[] arrayOfByte4 = new byte[i6];
        for (int i10 = 0; i10 < arrayOfInt2[0]; i10++)
        {
          i12 = i3 + i10 * i2;
          OS.memmove(arrayOfByte2, i12, i2);
          i14 = i7 + i10 * i6;
          OS.memmove(arrayOfByte4, i14, i6);
          for (int i16 = 0; i16 < arrayOfInt1[0]; i16++) {
            if (arrayOfByte4[(i16 * 3)] == 0) {
              arrayOfByte2[(i16 * 4 + 3)] = 0;
            }
          }
          OS.memmove(i12, arrayOfByte2, i2);
        }
        OS.g_object_unref(i1);
      }
      else
      {
        ImageData localImageData = paramImage.getImageData();
        i2 = localImageData.getTransparencyType() == 1 ? 1 : 0;
        i = OS.gdk_pixbuf_new(0, i2, 8, arrayOfInt1[0], arrayOfInt2[0]);
        if (i == 0) {
          SWT.error(2);
        }
        OS.gdk_pixbuf_get_from_drawable(i, paramImage.pixmap, m, 0, 0, 0, 0, arrayOfInt1[0], arrayOfInt2[0]);
        if (i2 != 0)
        {
          byte[] arrayOfByte1 = localImageData.alphaData;
          int i5 = OS.gdk_pixbuf_get_rowstride(i);
          i6 = OS.gdk_pixbuf_get_pixels(i);
          byte[] arrayOfByte3 = new byte[i5];
          for (int i9 = 0; i9 < arrayOfInt2[0]; i9++)
          {
            int i11 = i6 + i9 * i5;
            OS.memmove(arrayOfByte3, i11, i5);
            for (i12 = 0; i12 < arrayOfInt1[0]; i12++) {
              arrayOfByte3[(i12 * 4 + 3)] = arrayOfByte1[(i9 * arrayOfInt1[0] + i12)];
            }
            OS.memmove(i11, arrayOfByte3, i5);
          }
        }
      }
    }
    return i;
  }
  
  public int add(Image paramImage)
  {
    for (int i = 0; i < this.images.length; i++)
    {
      if ((this.images[i] != null) && (this.images[i].isDisposed()))
      {
        OS.g_object_unref(this.pixbufs[i]);
        this.images[i] = null;
        this.pixbufs[i] = 0;
      }
      if (this.images[i] == null) {
        break;
      }
    }
    if (i == this.images.length)
    {
      Image[] arrayOfImage = new Image[this.images.length + 4];
      System.arraycopy(this.images, 0, arrayOfImage, 0, this.images.length);
      this.images = arrayOfImage;
      int[] arrayOfInt = new int[this.pixbufs.length + 4];
      System.arraycopy(this.pixbufs, 0, arrayOfInt, 0, this.pixbufs.length);
      this.pixbufs = arrayOfInt;
    }
    set(i, paramImage);
    return i;
  }
  
  public void dispose()
  {
    if (this.pixbufs == null) {
      return;
    }
    for (int i = 0; i < this.pixbufs.length; i++) {
      if (this.pixbufs[i] != 0) {
        OS.g_object_unref(this.pixbufs[i]);
      }
    }
    this.images = null;
    this.pixbufs = null;
  }
  
  public Image get(int paramInt)
  {
    return this.images[paramInt];
  }
  
  public int getPixbuf(int paramInt)
  {
    return this.pixbufs[paramInt];
  }
  
  public int indexOf(Image paramImage)
  {
    if (paramImage == null) {
      return -1;
    }
    for (int i = 0; i < this.images.length; i++) {
      if (paramImage == this.images[i]) {
        return i;
      }
    }
    return -1;
  }
  
  public int indexOf(int paramInt)
  {
    if (paramInt == 0) {
      return -1;
    }
    for (int i = 0; i < this.images.length; i++) {
      if (paramInt == this.pixbufs[i]) {
        return i;
      }
    }
    return -1;
  }
  
  public boolean isDisposed()
  {
    return this.images == null;
  }
  
  public void put(int paramInt, Image paramImage)
  {
    int i = this.images.length;
    if ((0 > paramInt) || (paramInt >= i)) {
      return;
    }
    if (paramImage != null)
    {
      set(paramInt, paramImage);
    }
    else
    {
      this.images[paramInt] = null;
      if (this.pixbufs[paramInt] != 0) {
        OS.g_object_unref(this.pixbufs[paramInt]);
      }
      this.pixbufs[paramInt] = 0;
    }
  }
  
  public void remove(Image paramImage)
  {
    if (paramImage == null) {
      return;
    }
    for (int i = 0; i < this.images.length; i++) {
      if (paramImage == this.images[i])
      {
        OS.g_object_unref(this.pixbufs[i]);
        this.images[i] = null;
        this.pixbufs[i] = 0;
      }
    }
  }
  
  void set(int paramInt, Image paramImage)
  {
    int i = createPixbuf(paramImage);
    int j = OS.gdk_pixbuf_get_width(i);
    int k = OS.gdk_pixbuf_get_height(i);
    if ((this.width == -1) || (this.height == -1))
    {
      this.width = j;
      this.height = k;
    }
    if ((j != this.width) || (k != this.height))
    {
      m = OS.gdk_pixbuf_scale_simple(i, this.width, this.height, 2);
      OS.g_object_unref(i);
      i = m;
    }
    int m = this.pixbufs[paramInt];
    if (m != 0) {
      if (this.images[paramInt] == paramImage)
      {
        OS.gdk_pixbuf_copy_area(i, 0, 0, this.width, this.height, m, 0, 0);
        OS.g_object_unref(i);
        i = m;
      }
      else
      {
        OS.g_object_unref(m);
      }
    }
    this.pixbufs[paramInt] = i;
    this.images[paramInt] = paramImage;
  }
  
  public int size()
  {
    int i = 0;
    for (int j = 0; j < this.images.length; j++) {
      if (this.images[j] != null)
      {
        if (this.images[j].isDisposed())
        {
          OS.g_object_unref(this.pixbufs[j]);
          this.images[j] = null;
          this.pixbufs[j] = 0;
        }
        if (this.images[j] != null) {
          i++;
        }
      }
    }
    return i;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/internal/ImageList.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */