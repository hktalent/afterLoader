package org.eclipse.swt.graphics;

import org.eclipse.swt.SWT;
import org.eclipse.swt.internal.Compatibility;
import org.eclipse.swt.internal.Converter;
import org.eclipse.swt.internal.cairo.Cairo;
import org.eclipse.swt.internal.gtk.GdkColor;
import org.eclipse.swt.internal.gtk.GdkGCValues;
import org.eclipse.swt.internal.gtk.GdkRectangle;
import org.eclipse.swt.internal.gtk.OS;
import org.eclipse.swt.internal.gtk.PangoAttribute;
import org.eclipse.swt.internal.gtk.PangoItem;
import org.eclipse.swt.internal.gtk.PangoLayoutLine;
import org.eclipse.swt.internal.gtk.PangoLayoutRun;
import org.eclipse.swt.internal.gtk.PangoLogAttr;
import org.eclipse.swt.internal.gtk.PangoRectangle;

public final class TextLayout
  extends Resource
{
  Font font;
  String text;
  int ascent;
  int descent;
  int indent;
  int wrapIndent;
  int wrapWidth;
  int[] segments;
  char[] segmentsChars;
  int[] tabs;
  StyleItem[] styles;
  int stylesCount;
  int layout;
  int context;
  int attrList;
  int selAttrList;
  int[] invalidOffsets;
  static final char LTR_MARK = '‎';
  static final char RTL_MARK = '‏';
  static final char ZWS = '​';
  static final char ZWNBS = '﻿';
  
  public TextLayout(Device paramDevice)
  {
    super(paramDevice);
    paramDevice = this.device;
    this.context = OS.gdk_pango_context_get();
    if (this.context == 0) {
      SWT.error(2);
    }
    OS.pango_context_set_language(this.context, OS.gtk_get_default_language());
    OS.pango_context_set_base_dir(this.context, 0);
    this.layout = OS.pango_layout_new(this.context);
    if (this.layout == 0) {
      SWT.error(2);
    }
    OS.pango_layout_set_font_description(this.layout, paramDevice.systemFont.handle);
    OS.pango_layout_set_wrap(this.layout, 2);
    OS.pango_layout_set_tabs(this.layout, paramDevice.emptyTab);
    OS.pango_layout_set_auto_dir(this.layout, false);
    this.text = "";
    this.wrapWidth = (this.ascent = this.descent = -1);
    this.styles = new StyleItem[2];
    this.styles[0] = new StyleItem();
    this.styles[1] = new StyleItem();
    this.stylesCount = 2;
    init();
  }
  
  void checkLayout()
  {
    if (isDisposed()) {
      SWT.error(44);
    }
  }
  
  void computeRuns()
  {
    if (this.attrList != 0) {
      return;
    }
    String str = getSegmentsText();
    byte[] arrayOfByte = Converter.wcsToMbcs(null, str, false);
    OS.pango_layout_set_text(this.layout, arrayOfByte, arrayOfByte.length);
    if ((this.stylesCount == 2) && (this.styles[0].style == null) && (this.ascent == -1) && (this.descent == -1) && (this.segments == null)) {
      return;
    }
    int i = OS.pango_layout_get_text(this.layout);
    this.attrList = OS.pango_attr_list_new();
    this.selAttrList = OS.pango_attr_list_new();
    PangoAttribute localPangoAttribute = new PangoAttribute();
    char[] arrayOfChar = null;
    int j = str.length();
    int k = j - this.text.length();
    int m = k;
    int[] arrayOfInt = null;
    int i1;
    int i3;
    Object localObject1;
    int i4;
    int i5;
    int i6;
    int i7;
    if (((this.ascent != -1) || (this.descent != -1)) && (j > 0))
    {
      PangoRectangle localPangoRectangle1 = new PangoRectangle();
      if (this.ascent != -1) {
        localPangoRectangle1.y = (-(this.ascent * 1024));
      }
      localPangoRectangle1.height = ((Math.max(0, this.ascent) + Math.max(0, this.descent)) * 1024);
      i1 = OS.pango_layout_get_line_count(this.layout);
      arrayOfChar = new char[j + i1 * 2];
      arrayOfInt = new int[i1];
      i2 = 0;
      i3 = 0;
      localObject1 = new PangoLayoutLine();
      while (i3 < i1)
      {
        i4 = OS.pango_layout_get_line(this.layout, i3);
        OS.memmove((PangoLayoutLine)localObject1, i4, PangoLayoutLine.sizeof);
        i5 = ((PangoLayoutLine)localObject1).start_index;
        i6 = i3 * 6;
        i7 = OS.pango_attr_shape_new(localPangoRectangle1, localPangoRectangle1);
        OS.memmove(localPangoAttribute, i7, PangoAttribute.sizeof);
        localPangoAttribute.start_index = (i5 + i6);
        localPangoAttribute.end_index = (i5 + i6 + 3);
        OS.memmove(i7, localPangoAttribute, PangoAttribute.sizeof);
        OS.pango_attr_list_insert(this.attrList, i7);
        OS.pango_attr_list_insert(this.selAttrList, OS.pango_attribute_copy(i7));
        i7 = OS.pango_attr_shape_new(localPangoRectangle1, localPangoRectangle1);
        OS.memmove(localPangoAttribute, i7, PangoAttribute.sizeof);
        localPangoAttribute.start_index = (i5 + i6 + 3);
        localPangoAttribute.end_index = (i5 + i6 + 6);
        OS.memmove(i7, localPangoAttribute, PangoAttribute.sizeof);
        OS.pango_attr_list_insert(this.attrList, i7);
        OS.pango_attr_list_insert(this.selAttrList, OS.pango_attribute_copy(i7));
        int i8 = OS.g_utf16_pointer_to_offset(i, i + i5);
        arrayOfChar[(i8 + i3 * 2)] = '​';
        arrayOfChar[(i8 + i3 * 2 + 1)] = 65279;
        str.getChars(i2, i8, arrayOfChar, i2 + i3 * 2);
        arrayOfInt[i3] = (i8 + i3 * 2);
        i2 = i8;
        i3++;
      }
      str.getChars(i2, j, arrayOfChar, i2 + i3 * 2);
      arrayOfByte = Converter.wcsToMbcs(null, arrayOfChar, false);
      OS.pango_layout_set_text(this.layout, arrayOfByte, arrayOfByte.length);
      i = OS.pango_layout_get_text(this.layout);
      m += 2 * i1;
    }
    else
    {
      arrayOfChar = new char[j];
      str.getChars(0, j, arrayOfChar, 0);
    }
    this.invalidOffsets = new int[m];
    if (m > 0)
    {
      m = 0;
      n = 0;
      i1 = 0;
      for (i2 = 0; i2 < arrayOfChar.length; i2++)
      {
        i3 = arrayOfChar[i2];
        if ((i3 == 8203) && (arrayOfInt != null) && (n < arrayOfInt.length) && (i2 == arrayOfInt[n]))
        {
          this.invalidOffsets[(m++)] = i2;
          this.invalidOffsets[(m++)] = (++i2);
          n++;
        }
        else if ((i1 < k) && (i2 - m == this.segments[i1]))
        {
          this.invalidOffsets[(m++)] = i2;
          i1++;
        }
      }
    }
    int n = OS.strlen(i);
    Font localFont1 = this.font != null ? this.font : this.device.systemFont;
    for (int i2 = 0; i2 < this.stylesCount - 1; i2++)
    {
      StyleItem localStyleItem = this.styles[i2];
      localObject1 = localStyleItem.style;
      if (localObject1 != null)
      {
        i4 = translateOffset(localStyleItem.start);
        i5 = translateOffset(this.styles[(i2 + 1)].start - 1);
        i6 = OS.g_utf16_offset_to_pointer(i, i4) - i;
        i7 = OS.g_utf16_offset_to_pointer(i, i5 + 1) - i;
        i6 = Math.min(i6, n);
        i7 = Math.min(i7, n);
        Font localFont2 = ((TextStyle)localObject1).font;
        int i9;
        if ((localFont2 != null) && (!localFont2.isDisposed()) && (!localFont1.equals(localFont2)))
        {
          i9 = OS.pango_attr_font_desc_new(localFont2.handle);
          OS.memmove(localPangoAttribute, i9, PangoAttribute.sizeof);
          localPangoAttribute.start_index = i6;
          localPangoAttribute.end_index = i7;
          OS.memmove(i9, localPangoAttribute, PangoAttribute.sizeof);
          OS.pango_attr_list_insert(this.attrList, i9);
          OS.pango_attr_list_insert(this.selAttrList, OS.pango_attribute_copy(i9));
        }
        if (((TextStyle)localObject1).underline)
        {
          i9 = 0;
          switch (((TextStyle)localObject1).underlineStyle)
          {
          case 0: 
            i9 = 1;
            break;
          case 1: 
            i9 = 2;
            break;
          case 2: 
          case 3: 
            i9 = 4;
            break;
          case 4: 
            if (((TextStyle)localObject1).foreground == null)
            {
              i10 = OS.pango_attr_foreground_new((short)0, (short)13107, (short)39321);
              OS.memmove(localPangoAttribute, i10, PangoAttribute.sizeof);
              localPangoAttribute.start_index = i6;
              localPangoAttribute.end_index = i7;
              OS.memmove(i10, localPangoAttribute, PangoAttribute.sizeof);
              OS.pango_attr_list_insert(this.attrList, i10);
            }
            i9 = 1;
          }
          int i10 = OS.pango_attr_underline_new(i9);
          OS.memmove(localPangoAttribute, i10, PangoAttribute.sizeof);
          localPangoAttribute.start_index = i6;
          localPangoAttribute.end_index = i7;
          OS.memmove(i10, localPangoAttribute, PangoAttribute.sizeof);
          OS.pango_attr_list_insert(this.attrList, i10);
          OS.pango_attr_list_insert(this.selAttrList, OS.pango_attribute_copy(i10));
          if (((TextStyle)localObject1).underlineColor != null)
          {
            GdkColor localGdkColor = ((TextStyle)localObject1).underlineColor.handle;
            i10 = OS.pango_attr_underline_color_new(localGdkColor.red, localGdkColor.green, localGdkColor.blue);
            if (i10 != 0)
            {
              OS.memmove(localPangoAttribute, i10, PangoAttribute.sizeof);
              localPangoAttribute.start_index = i6;
              localPangoAttribute.end_index = i7;
              OS.memmove(i10, localPangoAttribute, PangoAttribute.sizeof);
              OS.pango_attr_list_insert(this.attrList, i10);
              OS.pango_attr_list_insert(this.selAttrList, OS.pango_attribute_copy(i10));
            }
          }
        }
        if (((TextStyle)localObject1).strikeout)
        {
          i9 = OS.pango_attr_strikethrough_new(true);
          OS.memmove(localPangoAttribute, i9, PangoAttribute.sizeof);
          localPangoAttribute.start_index = i6;
          localPangoAttribute.end_index = i7;
          OS.memmove(i9, localPangoAttribute, PangoAttribute.sizeof);
          OS.pango_attr_list_insert(this.attrList, i9);
          OS.pango_attr_list_insert(this.selAttrList, OS.pango_attribute_copy(i9));
          if (((TextStyle)localObject1).strikeoutColor != null)
          {
            localObject2 = ((TextStyle)localObject1).strikeoutColor.handle;
            i9 = OS.pango_attr_strikethrough_color_new(((GdkColor)localObject2).red, ((GdkColor)localObject2).green, ((GdkColor)localObject2).blue);
            if (i9 != 0)
            {
              OS.memmove(localPangoAttribute, i9, PangoAttribute.sizeof);
              localPangoAttribute.start_index = i6;
              localPangoAttribute.end_index = i7;
              OS.memmove(i9, localPangoAttribute, PangoAttribute.sizeof);
              OS.pango_attr_list_insert(this.attrList, i9);
              OS.pango_attr_list_insert(this.selAttrList, OS.pango_attribute_copy(i9));
            }
          }
        }
        Color localColor = ((TextStyle)localObject1).foreground;
        if ((localColor != null) && (!localColor.isDisposed()))
        {
          localObject2 = localColor.handle;
          int i11 = OS.pango_attr_foreground_new(((GdkColor)localObject2).red, ((GdkColor)localObject2).green, ((GdkColor)localObject2).blue);
          OS.memmove(localPangoAttribute, i11, PangoAttribute.sizeof);
          localPangoAttribute.start_index = i6;
          localPangoAttribute.end_index = i7;
          OS.memmove(i11, localPangoAttribute, PangoAttribute.sizeof);
          OS.pango_attr_list_insert(this.attrList, i11);
        }
        Object localObject2 = ((TextStyle)localObject1).background;
        if ((localObject2 != null) && (!((Color)localObject2).isDisposed()))
        {
          localObject3 = ((Color)localObject2).handle;
          int i12 = OS.pango_attr_background_new(((GdkColor)localObject3).red, ((GdkColor)localObject3).green, ((GdkColor)localObject3).blue);
          OS.memmove(localPangoAttribute, i12, PangoAttribute.sizeof);
          localPangoAttribute.start_index = i6;
          localPangoAttribute.end_index = i7;
          OS.memmove(i12, localPangoAttribute, PangoAttribute.sizeof);
          OS.pango_attr_list_insert(this.attrList, i12);
        }
        Object localObject3 = ((TextStyle)localObject1).metrics;
        int i14;
        if (localObject3 != null)
        {
          PangoRectangle localPangoRectangle2 = new PangoRectangle();
          localPangoRectangle2.y = (-(((GlyphMetrics)localObject3).ascent * 1024));
          localPangoRectangle2.height = ((((GlyphMetrics)localObject3).ascent + ((GlyphMetrics)localObject3).descent) * 1024);
          localPangoRectangle2.width = (((GlyphMetrics)localObject3).width * 1024);
          i14 = OS.pango_attr_shape_new(localPangoRectangle2, localPangoRectangle2);
          OS.memmove(localPangoAttribute, i14, PangoAttribute.sizeof);
          localPangoAttribute.start_index = i6;
          localPangoAttribute.end_index = i7;
          OS.memmove(i14, localPangoAttribute, PangoAttribute.sizeof);
          OS.pango_attr_list_insert(this.attrList, i14);
          OS.pango_attr_list_insert(this.selAttrList, OS.pango_attribute_copy(i14));
        }
        int i13 = ((TextStyle)localObject1).rise;
        if (i13 != 0)
        {
          i14 = OS.pango_attr_rise_new(i13 * 1024);
          OS.memmove(localPangoAttribute, i14, PangoAttribute.sizeof);
          localPangoAttribute.start_index = i6;
          localPangoAttribute.end_index = i7;
          OS.memmove(i14, localPangoAttribute, PangoAttribute.sizeof);
          OS.pango_attr_list_insert(this.attrList, i14);
          OS.pango_attr_list_insert(this.selAttrList, OS.pango_attribute_copy(i14));
        }
      }
    }
    OS.pango_layout_set_attributes(this.layout, this.attrList);
  }
  
  int[] computePolyline(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    int i = paramInt4 - paramInt2;
    int j = 2 * i;
    int k = Compatibility.ceil(paramInt3 - paramInt1, j);
    if ((k == 0) && (paramInt3 - paramInt1 > 2)) {
      k = 1;
    }
    int m = (2 * k + 1) * 2;
    if (m < 0) {
      return new int[0];
    }
    int[] arrayOfInt = new int[m];
    for (int n = 0; n < k; n++)
    {
      int i1 = 4 * n;
      arrayOfInt[i1] = (paramInt1 + j * n);
      arrayOfInt[(i1 + 1)] = paramInt4;
      arrayOfInt[(i1 + 2)] = (arrayOfInt[i1] + j / 2);
      arrayOfInt[(i1 + 3)] = paramInt2;
    }
    arrayOfInt[(m - 2)] = (paramInt1 + j * k);
    arrayOfInt[(m - 1)] = paramInt4;
    return arrayOfInt;
  }
  
  void destroy()
  {
    this.font = null;
    this.text = null;
    this.styles = null;
    freeRuns();
    this.segments = null;
    this.segmentsChars = null;
    if (this.layout != 0) {
      OS.g_object_unref(this.layout);
    }
    this.layout = 0;
    if (this.context != 0) {
      OS.g_object_unref(this.context);
    }
    this.context = 0;
  }
  
  public void draw(GC paramGC, int paramInt1, int paramInt2)
  {
    draw(paramGC, paramInt1, paramInt2, -1, -1, null, null);
  }
  
  public void draw(GC paramGC, int paramInt1, int paramInt2, int paramInt3, int paramInt4, Color paramColor1, Color paramColor2)
  {
    draw(paramGC, paramInt1, paramInt2, paramInt3, paramInt4, paramColor1, paramColor2, 0);
  }
  
  public void draw(GC paramGC, int paramInt1, int paramInt2, int paramInt3, int paramInt4, Color paramColor1, Color paramColor2, int paramInt5)
  {
    checkLayout();
    computeRuns();
    if (paramGC == null) {
      SWT.error(4);
    }
    if (paramGC.isDisposed()) {
      SWT.error(5);
    }
    if ((paramColor1 != null) && (paramColor1.isDisposed())) {
      SWT.error(5);
    }
    if ((paramColor2 != null) && (paramColor2.isDisposed())) {
      SWT.error(5);
    }
    paramGC.checkGC(1);
    int i = this.text.length();
    paramInt1 += Math.min(this.indent, this.wrapIndent);
    int j = (paramInt3 <= paramInt4) && (paramInt3 != -1) && (paramInt4 != -1) ? 1 : 0;
    GCData localGCData = paramGC.data;
    int k = localGCData.cairo;
    int i2;
    int i5;
    if (((paramInt5 & 0x30000) != 0) && ((j != 0) || ((paramInt5 & 0x100000) != 0)))
    {
      int[] arrayOfInt1 = new int[1];
      int[] arrayOfInt2 = new int[1];
      PangoLogAttr localPangoLogAttr = new PangoLogAttr();
      PangoRectangle localPangoRectangle = new PangoRectangle();
      i2 = OS.pango_layout_get_line_count(this.layout);
      int i3 = OS.pango_layout_get_text(this.layout);
      int i4 = OS.pango_layout_get_iter(this.layout);
      if (paramColor2 == null) {
        paramColor2 = this.device.getSystemColor(26);
      }
      if (k != 0)
      {
        Cairo.cairo_save(k);
        GdkColor localGdkColor = paramColor2.handle;
        Cairo.cairo_set_source_rgba(k, (localGdkColor.red & 0xFFFF) / 65535.0F, (localGdkColor.green & 0xFFFF) / 65535.0F, (localGdkColor.blue & 0xFFFF) / 65535.0F, localGCData.alpha / 255.0F);
      }
      else
      {
        OS.gdk_gc_set_foreground(paramGC.handle, paramColor2.handle);
      }
      i5 = 0;
      do
      {
        OS.pango_layout_iter_get_line_extents(i4, null, localPangoRectangle);
        int i6;
        if (OS.pango_layout_iter_next_line(i4))
        {
          i7 = OS.pango_layout_iter_get_index(i4);
          i6 = OS.g_utf16_pointer_to_offset(i3, i3 + i7);
        }
        else
        {
          i6 = OS.g_utf16_strlen(i3, -1);
        }
        int i7 = 0;
        if ((i5 == i2 - 1) && ((paramInt5 & 0x100000) != 0))
        {
          i7 = 1;
        }
        else
        {
          if (arrayOfInt1[0] == 0) {
            OS.pango_layout_get_log_attrs(this.layout, arrayOfInt1, arrayOfInt2);
          }
          OS.memmove(localPangoLogAttr, arrayOfInt1[0] + i6 * PangoLogAttr.sizeof, PangoLogAttr.sizeof);
          if (!localPangoLogAttr.is_line_break)
          {
            if ((paramInt3 <= i6) && (i6 <= paramInt4)) {
              i7 = 1;
            }
          }
          else if ((paramInt3 <= i6) && (i6 < paramInt4) && ((paramInt5 & 0x10000) != 0)) {
            i7 = 1;
          }
        }
        if (i7 != 0)
        {
          int i8 = paramInt1 + OS.PANGO_PIXELS(localPangoRectangle.x) + OS.PANGO_PIXELS(localPangoRectangle.width);
          int i9 = paramInt2 + OS.PANGO_PIXELS(localPangoRectangle.y);
          int i10 = OS.PANGO_PIXELS(localPangoRectangle.height);
          if ((this.ascent != -1) && (this.descent != -1)) {
            i10 = Math.max(i10, this.ascent + this.descent);
          }
          int i11 = (paramInt5 & 0x10000) != 0 ? 32767 : i10 / 3;
          if (k != 0)
          {
            Cairo.cairo_rectangle(k, i8, i9, i11, i10);
            Cairo.cairo_fill(k);
          }
          else
          {
            OS.gdk_draw_rectangle(localGCData.drawable, paramGC.handle, 1, i8, i9, i11, i10);
          }
        }
        i5++;
      } while (i5 < i2);
      OS.pango_layout_iter_free(i4);
      if (arrayOfInt1[0] != 0) {
        OS.g_free(arrayOfInt1[0]);
      }
      if (k != 0) {
        Cairo.cairo_restore(k);
      } else {
        OS.gdk_gc_set_foreground(paramGC.handle, localGCData.foreground);
      }
    }
    if (i == 0) {
      return;
    }
    if (j == 0)
    {
      if (k != 0)
      {
        if ((localGCData.style & 0x8000000) != 0)
        {
          Cairo.cairo_save(k);
          Cairo.cairo_scale(k, -1.0D, 1.0D);
          Cairo.cairo_translate(k, -2 * paramInt1 - width(), 0.0D);
        }
        Cairo.cairo_move_to(k, paramInt1, paramInt2);
        OS.pango_cairo_show_layout(k, this.layout);
        drawBorder(paramGC, paramInt1, paramInt2, null);
        if ((localGCData.style & 0x8000000) != 0) {
          Cairo.cairo_restore(k);
        }
      }
      else
      {
        OS.gdk_draw_layout(localGCData.drawable, paramGC.handle, paramInt1, paramInt2, this.layout);
        drawBorder(paramGC, paramInt1, paramInt2, null);
      }
    }
    else
    {
      paramInt3 = Math.min(Math.max(0, paramInt3), i - 1);
      paramInt4 = Math.min(Math.max(0, paramInt4), i - 1);
      i = OS.g_utf16_strlen(OS.pango_layout_get_text(this.layout), -1);
      paramInt3 = translateOffset(paramInt3);
      paramInt4 = translateOffset(paramInt4);
      if (paramColor1 == null) {
        paramColor1 = this.device.getSystemColor(27);
      }
      if (paramColor2 == null) {
        paramColor2 = this.device.getSystemColor(26);
      }
      boolean bool = (paramInt3 == 0) && (paramInt4 == i - 1);
      int m;
      if (bool)
      {
        if (k != 0)
        {
          m = OS.pango_layout_get_text(this.layout);
          if ((localGCData.style & 0x8000000) != 0)
          {
            Cairo.cairo_save(k);
            Cairo.cairo_scale(k, -1.0D, 1.0D);
            Cairo.cairo_translate(k, -2 * paramInt1 - width(), 0.0D);
          }
          drawWithCairo(paramGC, paramInt1, paramInt2, 0, OS.strlen(m), bool, paramColor1.handle, paramColor2.handle);
          if ((localGCData.style & 0x8000000) != 0) {
            Cairo.cairo_restore(k);
          }
        }
        else
        {
          OS.gdk_draw_layout_with_colors(localGCData.drawable, paramGC.handle, paramInt1, paramInt2, this.layout, paramColor1.handle, paramColor2.handle);
          drawBorder(paramGC, paramInt1, paramInt2, paramColor1.handle);
        }
      }
      else
      {
        m = OS.pango_layout_get_text(this.layout);
        int n = OS.g_utf16_offset_to_pointer(m, paramInt3) - m;
        int i1 = OS.g_utf16_offset_to_pointer(m, paramInt4 + 1) - m;
        i2 = OS.strlen(m);
        n = Math.min(n, i2);
        i1 = Math.min(i1, i2);
        if (k != 0)
        {
          if ((localGCData.style & 0x8000000) != 0)
          {
            Cairo.cairo_save(k);
            Cairo.cairo_scale(k, -1.0D, 1.0D);
            Cairo.cairo_translate(k, -2 * paramInt1 - width(), 0.0D);
          }
          drawWithCairo(paramGC, paramInt1, paramInt2, n, i1, bool, paramColor1.handle, paramColor2.handle);
          if ((localGCData.style & 0x8000000) != 0) {
            Cairo.cairo_restore(k);
          }
        }
        else
        {
          Region localRegion = new Region();
          paramGC.getClipping(localRegion);
          OS.gdk_draw_layout(localGCData.drawable, paramGC.handle, paramInt1, paramInt2, this.layout);
          drawBorder(paramGC, paramInt1, paramInt2, null);
          int[] arrayOfInt3 = { n, i1 };
          i5 = OS.gdk_pango_layout_get_clip_region(this.layout, paramInt1, paramInt2, arrayOfInt3, arrayOfInt3.length / 2);
          if (i5 != 0)
          {
            OS.gdk_gc_set_clip_region(paramGC.handle, i5);
            OS.gdk_region_destroy(i5);
          }
          OS.gdk_draw_layout_with_colors(localGCData.drawable, paramGC.handle, paramInt1, paramInt2, this.layout, paramColor1.handle, paramColor2.handle);
          drawBorder(paramGC, paramInt1, paramInt2, paramColor1.handle);
          paramGC.setClipping(localRegion);
          localRegion.dispose();
        }
      }
    }
    if (k != 0) {
      Cairo.cairo_new_path(k);
    }
  }
  
  void drawWithCairo(GC paramGC, int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean, GdkColor paramGdkColor1, GdkColor paramGdkColor2)
  {
    GCData localGCData = paramGC.data;
    int i = localGCData.cairo;
    Cairo.cairo_save(i);
    if (!paramBoolean)
    {
      Cairo.cairo_move_to(i, paramInt1, paramInt2);
      OS.pango_cairo_show_layout(i, this.layout);
      drawBorder(paramGC, paramInt1, paramInt2, null);
    }
    int[] arrayOfInt = { paramInt3, paramInt4 };
    int j = OS.gdk_pango_layout_get_clip_region(this.layout, paramInt1, paramInt2, arrayOfInt, arrayOfInt.length / 2);
    if (j != 0)
    {
      OS.gdk_cairo_region(i, j);
      Cairo.cairo_clip(i);
      Cairo.cairo_set_source_rgba(i, (paramGdkColor2.red & 0xFFFF) / 65535.0F, (paramGdkColor2.green & 0xFFFF) / 65535.0F, (paramGdkColor2.blue & 0xFFFF) / 65535.0F, localGCData.alpha / 255.0F);
      Cairo.cairo_paint(i);
      OS.gdk_region_destroy(j);
    }
    Cairo.cairo_set_source_rgba(i, (paramGdkColor1.red & 0xFFFF) / 65535.0F, (paramGdkColor1.green & 0xFFFF) / 65535.0F, (paramGdkColor1.blue & 0xFFFF) / 65535.0F, localGCData.alpha / 255.0F);
    Cairo.cairo_move_to(i, paramInt1, paramInt2);
    OS.pango_layout_set_attributes(this.layout, this.selAttrList);
    OS.pango_cairo_show_layout(i, this.layout);
    OS.pango_layout_set_attributes(this.layout, this.attrList);
    drawBorder(paramGC, paramInt1, paramInt2, paramGdkColor1);
    Cairo.cairo_restore(i);
  }
  
  void drawBorder(GC paramGC, int paramInt1, int paramInt2, GdkColor paramGdkColor)
  {
    GCData localGCData = paramGC.data;
    int i = localGCData.cairo;
    int j = paramGC.handle;
    int k = OS.pango_layout_get_text(this.layout);
    GdkGCValues localGdkGCValues = null;
    if (i != 0) {
      Cairo.cairo_save(i);
    }
    for (int m = 0; m < this.stylesCount - 1; m++)
    {
      TextStyle localTextStyle = this.styles[m].style;
      if (localTextStyle != null)
      {
        int n = localTextStyle.borderStyle != 0 ? 1 : 0;
        if ((n != 0) && (!localTextStyle.isAdherentBorder(this.styles[(m + 1)].style)))
        {
          int i1 = this.styles[m].start;
          for (int i2 = m; (i2 > 0) && (localTextStyle.isAdherentBorder(this.styles[(i2 - 1)].style)); i2--) {
            i1 = this.styles[(i2 - 1)].start;
          }
          i1 = translateOffset(i1);
          i2 = translateOffset(this.styles[(m + 1)].start - 1);
          int i3 = OS.g_utf16_offset_to_pointer(k, i1) - k;
          int i4 = OS.g_utf16_offset_to_pointer(k, i2 + 1) - k;
          int[] arrayOfInt1 = { i3, i4 };
          int i5 = OS.gdk_pango_layout_get_clip_region(this.layout, paramInt1, paramInt2, arrayOfInt1, arrayOfInt1.length / 2);
          if (i5 != 0)
          {
            int[] arrayOfInt2 = new int[1];
            int[] arrayOfInt3 = new int[1];
            Region.gdk_region_get_rectangles(i5, arrayOfInt3, arrayOfInt2);
            GdkRectangle localGdkRectangle = new GdkRectangle();
            GdkColor localGdkColor = null;
            if ((localGdkColor == null) && (localTextStyle.borderColor != null)) {
              localGdkColor = localTextStyle.borderColor.handle;
            }
            if ((localGdkColor == null) && (paramGdkColor != null)) {
              localGdkColor = paramGdkColor;
            }
            if ((localGdkColor == null) && (localTextStyle.foreground != null)) {
              localGdkColor = localTextStyle.foreground.handle;
            }
            if (localGdkColor == null) {
              localGdkColor = localGCData.foreground;
            }
            int i6 = 1;
            float[] arrayOfFloat = null;
            switch (localTextStyle.borderStyle)
            {
            case 1: 
              break;
            case 2: 
              arrayOfFloat = i6 != 0 ? GC.LINE_DASH : GC.LINE_DASH_ZERO;
              break;
            case 4: 
              arrayOfFloat = i6 != 0 ? GC.LINE_DOT : GC.LINE_DOT_ZERO;
            }
            int i8;
            int i7;
            if (i != 0)
            {
              Cairo.cairo_set_source_rgba(i, (localGdkColor.red & 0xFFFF) / 65535.0F, (localGdkColor.green & 0xFFFF) / 65535.0F, (localGdkColor.blue & 0xFFFF) / 65535.0F, localGCData.alpha / 255.0F);
              Cairo.cairo_set_line_width(i, i6);
              if (arrayOfFloat != null)
              {
                double[] arrayOfDouble = new double[arrayOfFloat.length];
                for (i8 = 0; i8 < arrayOfDouble.length; i8++) {
                  arrayOfDouble[i8] = ((i6 == 0) || (localGCData.lineStyle == 6) ? arrayOfFloat[i8] : arrayOfFloat[i8] * i6);
                }
                Cairo.cairo_set_dash(i, arrayOfDouble, arrayOfDouble.length, 0.0D);
              }
              else
              {
                Cairo.cairo_set_dash(i, null, 0, 0.0D);
              }
              for (i7 = 0; i7 < arrayOfInt2[0]; i7++)
              {
                OS.memmove(localGdkRectangle, arrayOfInt3[0] + i7 * GdkRectangle.sizeof, GdkRectangle.sizeof);
                Cairo.cairo_rectangle(i, localGdkRectangle.x + 0.5D, localGdkRectangle.y + 0.5D, localGdkRectangle.width - 1, localGdkRectangle.height - 1);
              }
              Cairo.cairo_stroke(i);
            }
            else
            {
              if (localGdkGCValues == null)
              {
                localGdkGCValues = new GdkGCValues();
                OS.gdk_gc_get_values(j, localGdkGCValues);
              }
              OS.gdk_gc_set_foreground(j, localGdkColor);
              i7 = 1;
              i8 = 0;
              int i9 = 0;
              if (arrayOfFloat != null)
              {
                byte[] arrayOfByte = new byte[arrayOfFloat.length];
                for (int i11 = 0; i11 < arrayOfByte.length; i11++) {
                  arrayOfByte[i11] = ((byte)(int)((i6 == 0) || (localGCData.lineStyle == 6) ? arrayOfFloat[i11] : arrayOfFloat[i11] * i6));
                }
                OS.gdk_gc_set_dashes(j, 0, arrayOfByte, arrayOfByte.length);
                i9 = 1;
              }
              else
              {
                i9 = 0;
              }
              OS.gdk_gc_set_line_attributes(j, i6, i9, i7, i8);
              for (int i10 = 0; i10 < arrayOfInt2[0]; i10++)
              {
                OS.memmove(localGdkRectangle, arrayOfInt3[0] + i10 * GdkRectangle.sizeof, GdkRectangle.sizeof);
                OS.gdk_draw_rectangle(localGCData.drawable, j, 0, localGdkRectangle.x, localGdkRectangle.y, localGdkRectangle.width - 1, localGdkRectangle.height - 1);
              }
            }
            if (arrayOfInt3[0] != 0) {
              OS.g_free(arrayOfInt3[0]);
            }
            OS.gdk_region_destroy(i5);
          }
        }
      }
    }
    if (localGdkGCValues != null)
    {
      m = 245761;
      OS.gdk_gc_set_values(j, localGdkGCValues, m);
      localGCData.state &= 0xFFFFFFF7;
    }
    if (i != 0) {
      Cairo.cairo_restore(i);
    }
  }
  
  void freeRuns()
  {
    if (this.attrList == 0) {
      return;
    }
    OS.pango_layout_set_attributes(this.layout, 0);
    OS.pango_attr_list_unref(this.attrList);
    this.attrList = 0;
    if (this.selAttrList != 0)
    {
      OS.pango_attr_list_unref(this.selAttrList);
      this.selAttrList = 0;
    }
    this.invalidOffsets = null;
  }
  
  public int getAlignment()
  {
    checkLayout();
    int i = OS.pango_layout_get_alignment(this.layout);
    int j = OS.pango_context_get_base_dir(this.context) == 1 ? 1 : 0;
    switch (i)
    {
    case 0: 
      return j != 0 ? 131072 : 16384;
    case 2: 
      return j != 0 ? 16384 : 131072;
    }
    return 16777216;
  }
  
  public int getAscent()
  {
    checkLayout();
    return this.ascent;
  }
  
  public Rectangle getBounds()
  {
    checkLayout();
    computeRuns();
    int[] arrayOfInt1 = new int[1];
    int[] arrayOfInt2 = new int[1];
    OS.pango_layout_get_size(this.layout, arrayOfInt1, arrayOfInt2);
    int i = OS.pango_layout_get_width(this.layout);
    arrayOfInt1[0] = (i != -1 ? i : arrayOfInt1[0] + OS.pango_layout_get_indent(this.layout));
    int j = OS.PANGO_PIXELS(arrayOfInt1[0]);
    int k = OS.PANGO_PIXELS(arrayOfInt2[0]);
    if ((this.ascent != -1) && (this.descent != -1)) {
      k = Math.max(k, this.ascent + this.descent);
    }
    k += OS.PANGO_PIXELS(OS.pango_layout_get_spacing(this.layout));
    return new Rectangle(0, 0, j, k);
  }
  
  public Rectangle getBounds(int paramInt1, int paramInt2)
  {
    checkLayout();
    computeRuns();
    int i = this.text.length();
    if (i == 0) {
      return new Rectangle(0, 0, 0, 0);
    }
    if (paramInt1 > paramInt2) {
      return new Rectangle(0, 0, 0, 0);
    }
    paramInt1 = Math.min(Math.max(0, paramInt1), i - 1);
    paramInt2 = Math.min(Math.max(0, paramInt2), i - 1);
    paramInt1 = translateOffset(paramInt1);
    paramInt2 = translateOffset(paramInt2);
    int j = OS.pango_layout_get_text(this.layout);
    int k = OS.g_utf16_offset_to_pointer(j, paramInt1) - j;
    int m = OS.g_utf16_offset_to_pointer(j, paramInt2 + 1) - j;
    int n = OS.strlen(j);
    k = Math.min(k, n);
    m = Math.min(m, n);
    int[] arrayOfInt = { k, m };
    int i1 = OS.gdk_pango_layout_get_clip_region(this.layout, 0, 0, arrayOfInt, 1);
    if (i1 == 0) {
      return new Rectangle(0, 0, 0, 0);
    }
    GdkRectangle localGdkRectangle = new GdkRectangle();
    PangoRectangle localPangoRectangle = new PangoRectangle();
    int i2 = OS.pango_layout_get_iter(this.layout);
    if (i2 == 0) {
      SWT.error(2);
    }
    int i3 = OS.gdk_region_new();
    if (i3 == 0) {
      SWT.error(2);
    }
    int i4 = 0;
    do
    {
      OS.pango_layout_iter_get_line_extents(i2, null, localPangoRectangle);
      if (OS.pango_layout_iter_next_line(i2)) {
        i4 = OS.pango_layout_iter_get_index(i2) - 1;
      } else {
        i4 = n;
      }
      if (k <= i4)
      {
        localGdkRectangle.x = OS.PANGO_PIXELS(localPangoRectangle.x);
        localGdkRectangle.y = OS.PANGO_PIXELS(localPangoRectangle.y);
        localGdkRectangle.width = OS.PANGO_PIXELS(localPangoRectangle.width);
        localGdkRectangle.height = OS.PANGO_PIXELS(localPangoRectangle.height);
        OS.gdk_region_union_with_rect(i3, localGdkRectangle);
      }
    } while (i4 + 1 <= m);
    OS.gdk_region_intersect(i1, i3);
    OS.gdk_region_destroy(i3);
    OS.pango_layout_iter_free(i2);
    OS.gdk_region_get_clipbox(i1, localGdkRectangle);
    OS.gdk_region_destroy(i1);
    if (OS.pango_context_get_base_dir(this.context) == 1) {
      localGdkRectangle.x = (width() - localGdkRectangle.x - localGdkRectangle.width);
    }
    localGdkRectangle.x += Math.min(this.indent, this.wrapIndent);
    return new Rectangle(localGdkRectangle.x, localGdkRectangle.y, localGdkRectangle.width, localGdkRectangle.height);
  }
  
  public int getDescent()
  {
    checkLayout();
    return this.descent;
  }
  
  public Font getFont()
  {
    checkLayout();
    return this.font;
  }
  
  public int getIndent()
  {
    checkLayout();
    return this.indent;
  }
  
  public boolean getJustify()
  {
    checkLayout();
    return OS.pango_layout_get_justify(this.layout);
  }
  
  public int getLevel(int paramInt)
  {
    checkLayout();
    computeRuns();
    int i = this.text.length();
    if ((0 > paramInt) || (paramInt > i)) {
      SWT.error(6);
    }
    paramInt = translateOffset(paramInt);
    int j = OS.pango_layout_get_iter(this.layout);
    if (j == 0) {
      SWT.error(2);
    }
    int k = 0;
    PangoItem localPangoItem = new PangoItem();
    PangoLayoutRun localPangoLayoutRun = new PangoLayoutRun();
    int m = OS.pango_layout_get_text(this.layout);
    int n = OS.g_utf16_offset_to_pointer(m, paramInt) - m;
    int i1 = OS.strlen(m);
    n = Math.min(n, i1);
    do
    {
      int i2 = OS.pango_layout_iter_get_run(j);
      if (i2 != 0)
      {
        OS.memmove(localPangoLayoutRun, i2, PangoLayoutRun.sizeof);
        OS.memmove(localPangoItem, localPangoLayoutRun.item, PangoItem.sizeof);
        if ((localPangoItem.offset <= n) && (n < localPangoItem.offset + localPangoItem.length))
        {
          k = localPangoItem.analysis_level;
          break;
        }
      }
    } while (OS.pango_layout_iter_next_run(j));
    OS.pango_layout_iter_free(j);
    return k;
  }
  
  public Rectangle getLineBounds(int paramInt)
  {
    checkLayout();
    computeRuns();
    int i = OS.pango_layout_get_line_count(this.layout);
    if ((0 > paramInt) || (paramInt >= i)) {
      SWT.error(6);
    }
    int j = OS.pango_layout_get_iter(this.layout);
    if (j == 0) {
      SWT.error(2);
    }
    for (int k = 0; k < paramInt; k++) {
      OS.pango_layout_iter_next_line(j);
    }
    PangoRectangle localPangoRectangle = new PangoRectangle();
    OS.pango_layout_iter_get_line_extents(j, null, localPangoRectangle);
    OS.pango_layout_iter_free(j);
    int m = OS.PANGO_PIXELS(localPangoRectangle.x);
    int n = OS.PANGO_PIXELS(localPangoRectangle.y);
    int i1 = OS.PANGO_PIXELS(localPangoRectangle.width);
    int i2 = OS.PANGO_PIXELS(localPangoRectangle.height);
    if ((this.ascent != -1) && (this.descent != -1)) {
      i2 = Math.max(i2, this.ascent + this.descent);
    }
    if (OS.pango_context_get_base_dir(this.context) == 1) {
      m = width() - m - i1;
    }
    m += Math.min(this.indent, this.wrapIndent);
    return new Rectangle(m, n, i1, i2);
  }
  
  public int getLineCount()
  {
    checkLayout();
    computeRuns();
    return OS.pango_layout_get_line_count(this.layout);
  }
  
  public int getLineIndex(int paramInt)
  {
    checkLayout();
    computeRuns();
    int i = this.text.length();
    if ((0 > paramInt) || (paramInt > i)) {
      SWT.error(5);
    }
    paramInt = translateOffset(paramInt);
    int j = 0;
    int k = OS.pango_layout_get_text(this.layout);
    int m = OS.g_utf16_offset_to_pointer(k, paramInt) - k;
    int n = OS.strlen(k);
    m = Math.min(m, n);
    int i1 = OS.pango_layout_get_iter(this.layout);
    if (i1 == 0) {
      SWT.error(2);
    }
    while ((OS.pango_layout_iter_next_line(i1)) && (OS.pango_layout_iter_get_index(i1) <= m)) {
      j++;
    }
    OS.pango_layout_iter_free(i1);
    return j;
  }
  
  public FontMetrics getLineMetrics(int paramInt)
  {
    checkLayout();
    computeRuns();
    int i = OS.pango_layout_get_line_count(this.layout);
    if ((0 > paramInt) || (paramInt >= i)) {
      SWT.error(6);
    }
    int j = 0;
    int k = 0;
    PangoLayoutLine localPangoLayoutLine = new PangoLayoutLine();
    OS.memmove(localPangoLayoutLine, OS.pango_layout_get_line(this.layout, paramInt), PangoLayoutLine.sizeof);
    if (localPangoLayoutLine.runs == 0)
    {
      int m = this.font != null ? this.font.handle : this.device.systemFont.handle;
      int n = OS.pango_context_get_language(this.context);
      int i1 = OS.pango_context_get_metrics(this.context, m, n);
      j = OS.pango_font_metrics_get_ascent(i1);
      k = OS.pango_font_metrics_get_descent(i1);
      OS.pango_font_metrics_unref(i1);
    }
    else
    {
      PangoRectangle localPangoRectangle = new PangoRectangle();
      OS.pango_layout_line_get_extents(OS.pango_layout_get_line(this.layout, paramInt), null, localPangoRectangle);
      j = -localPangoRectangle.y;
      k = localPangoRectangle.height - j;
    }
    j = Math.max(this.ascent, OS.PANGO_PIXELS(j));
    k = Math.max(this.descent, OS.PANGO_PIXELS(k));
    return FontMetrics.gtk_new(j, k, 0, 0, j + k);
  }
  
  public int[] getLineOffsets()
  {
    checkLayout();
    computeRuns();
    int i = OS.pango_layout_get_line_count(this.layout);
    int[] arrayOfInt = new int[i + 1];
    int j = OS.pango_layout_get_text(this.layout);
    PangoLayoutLine localPangoLayoutLine = new PangoLayoutLine();
    for (int k = 0; k < i; k++)
    {
      int m = OS.pango_layout_get_line(this.layout, k);
      OS.memmove(localPangoLayoutLine, m, PangoLayoutLine.sizeof);
      int n = OS.g_utf16_pointer_to_offset(j, j + localPangoLayoutLine.start_index);
      arrayOfInt[k] = untranslateOffset(n);
    }
    arrayOfInt[i] = this.text.length();
    return arrayOfInt;
  }
  
  public Point getLocation(int paramInt, boolean paramBoolean)
  {
    checkLayout();
    computeRuns();
    int i = this.text.length();
    if ((0 > paramInt) || (paramInt > i)) {
      SWT.error(6);
    }
    paramInt = translateOffset(paramInt);
    int j = OS.pango_layout_get_text(this.layout);
    int k = OS.g_utf16_offset_to_pointer(j, paramInt) - j;
    int m = OS.strlen(j);
    k = Math.min(k, m);
    PangoRectangle localPangoRectangle = new PangoRectangle();
    OS.pango_layout_index_to_pos(this.layout, k, localPangoRectangle);
    int n = paramBoolean ? localPangoRectangle.x + localPangoRectangle.width : localPangoRectangle.x;
    int i1 = localPangoRectangle.y;
    n = OS.PANGO_PIXELS(n);
    if (OS.pango_context_get_base_dir(this.context) == 1) {
      n = width() - n;
    }
    n += Math.min(this.indent, this.wrapIndent);
    return new Point(n, OS.PANGO_PIXELS(i1));
  }
  
  public int getNextOffset(int paramInt1, int paramInt2)
  {
    return _getOffset(paramInt1, paramInt2, true);
  }
  
  int _getOffset(int paramInt1, int paramInt2, boolean paramBoolean)
  {
    checkLayout();
    computeRuns();
    int i = this.text.length();
    if ((0 > paramInt1) || (paramInt1 > i)) {
      SWT.error(6);
    }
    if (paramBoolean)
    {
      if (paramInt1 == i) {
        return i;
      }
    }
    else if (paramInt1 == 0) {
      return 0;
    }
    int j = paramBoolean ? 1 : -1;
    if ((paramInt2 & 0x1) != 0) {
      return paramInt1 + j;
    }
    int[] arrayOfInt1 = new int[1];
    int[] arrayOfInt2 = new int[1];
    OS.pango_layout_get_log_attrs(this.layout, arrayOfInt1, arrayOfInt2);
    if (arrayOfInt1[0] == 0) {
      return paramInt1 + j;
    }
    int k = OS.pango_layout_get_text(this.layout);
    int m = OS.g_utf16_offset_to_utf8_offset(k, translateOffset(paramInt1));
    int n = OS.g_utf8_strlen(k, -1);
    m += j;
    PangoLogAttr localPangoLogAttr = new PangoLogAttr();
    while ((0 <= m) && (m <= n))
    {
      OS.memmove(localPangoLogAttr, arrayOfInt1[0] + m * PangoLogAttr.sizeof, PangoLogAttr.sizeof);
      int i1 = 0;
      int i2 = 0;
      if (((paramInt2 & 0x2) != 0) && (localPangoLogAttr.is_cursor_position)) {
        i1 = 1;
      }
      if ((paramInt2 & 0x4) != 0) {
        if (paramBoolean)
        {
          if (localPangoLogAttr.is_word_end) {
            i1 = 1;
          }
        }
        else if (localPangoLogAttr.is_word_start) {
          i1 = 1;
        }
      }
      if ((paramInt2 & 0x10) != 0)
      {
        if (localPangoLogAttr.is_word_start) {
          i1 = 1;
        }
        if (localPangoLogAttr.is_sentence_end) {
          i1 = 1;
        }
      }
      if ((paramInt2 & 0x8) != 0)
      {
        if (localPangoLogAttr.is_word_end) {
          i1 = 1;
        }
        if (localPangoLogAttr.is_sentence_start) {
          i1 = 1;
        }
      }
      if (paramBoolean)
      {
        if (m == n) {
          i2 = 1;
        }
      }
      else if (m == 0) {
        i2 = 1;
      }
      if ((i1 != 0) || (i2 != 0))
      {
        int i3 = OS.g_utf8_offset_to_utf16_offset(k, m);
        if ((i1 != 0) && (this.invalidOffsets != null)) {
          for (int i4 = 0; i4 < this.invalidOffsets.length; i4++) {
            if (i3 == this.invalidOffsets[i4])
            {
              i1 = 0;
              break;
            }
          }
        }
        if ((i1 != 0) || (i2 != 0))
        {
          paramInt1 = untranslateOffset(i3);
          break;
        }
      }
      m += j;
    }
    OS.g_free(arrayOfInt1[0]);
    return Math.min(Math.max(0, paramInt1), i);
  }
  
  public int getOffset(Point paramPoint, int[] paramArrayOfInt)
  {
    checkLayout();
    if (paramPoint == null) {
      SWT.error(4);
    }
    return getOffset(paramPoint.x, paramPoint.y, paramArrayOfInt);
  }
  
  public int getOffset(int paramInt1, int paramInt2, int[] paramArrayOfInt)
  {
    checkLayout();
    computeRuns();
    if ((paramArrayOfInt != null) && (paramArrayOfInt.length < 1)) {
      SWT.error(5);
    }
    paramInt1 -= Math.min(this.indent, this.wrapIndent);
    if (OS.pango_context_get_base_dir(this.context) == 1) {
      paramInt1 = width() - paramInt1;
    }
    int i = OS.pango_layout_get_iter(this.layout);
    if (i == 0) {
      SWT.error(2);
    }
    PangoRectangle localPangoRectangle = new PangoRectangle();
    do
    {
      OS.pango_layout_iter_get_line_extents(i, null, localPangoRectangle);
      localPangoRectangle.y = OS.PANGO_PIXELS(localPangoRectangle.y);
      localPangoRectangle.height = OS.PANGO_PIXELS(localPangoRectangle.height);
      if ((localPangoRectangle.y <= paramInt2) && (paramInt2 < localPangoRectangle.y + localPangoRectangle.height))
      {
        localPangoRectangle.x = OS.PANGO_PIXELS(localPangoRectangle.x);
        localPangoRectangle.width = OS.PANGO_PIXELS(localPangoRectangle.width);
        if (paramInt1 >= localPangoRectangle.x + localPangoRectangle.width) {
          paramInt1 = localPangoRectangle.x + localPangoRectangle.width - 1;
        }
        if (paramInt1 >= localPangoRectangle.x) {
          break;
        }
        paramInt1 = localPangoRectangle.x;
        break;
      }
    } while (OS.pango_layout_iter_next_line(i));
    OS.pango_layout_iter_free(i);
    int[] arrayOfInt1 = new int[1];
    int[] arrayOfInt2 = new int[1];
    OS.pango_layout_xy_to_index(this.layout, paramInt1 * 1024, paramInt2 * 1024, arrayOfInt1, arrayOfInt2);
    int j = OS.pango_layout_get_text(this.layout);
    int k = OS.g_utf16_pointer_to_offset(j, j + arrayOfInt1[0]);
    if (paramArrayOfInt != null)
    {
      paramArrayOfInt[0] = arrayOfInt2[0];
      if (arrayOfInt2[0] != 0) {
        paramArrayOfInt[0] = (OS.g_utf8_offset_to_utf16_offset(j, OS.g_utf8_pointer_to_offset(j, j + arrayOfInt1[0]) + arrayOfInt2[0]) - k);
      }
    }
    return untranslateOffset(k);
  }
  
  public int getOrientation()
  {
    checkLayout();
    int i = OS.pango_context_get_base_dir(this.context);
    return i == 1 ? 67108864 : 33554432;
  }
  
  public int getPreviousOffset(int paramInt1, int paramInt2)
  {
    return _getOffset(paramInt1, paramInt2, false);
  }
  
  public int[] getRanges()
  {
    checkLayout();
    Object localObject = new int[this.stylesCount * 2];
    int i = 0;
    for (int j = 0; j < this.stylesCount - 1; j++) {
      if (this.styles[j].style != null)
      {
        localObject[(i++)] = this.styles[j].start;
        localObject[(i++)] = (this.styles[(j + 1)].start - 1);
      }
    }
    if (i != localObject.length)
    {
      int[] arrayOfInt = new int[i];
      System.arraycopy(localObject, 0, arrayOfInt, 0, i);
      localObject = arrayOfInt;
    }
    return (int[])localObject;
  }
  
  public int[] getSegments()
  {
    checkLayout();
    return this.segments;
  }
  
  public char[] getSegmentsChars()
  {
    checkLayout();
    return this.segmentsChars;
  }
  
  String getSegmentsText()
  {
    int i = this.text.length();
    if (i == 0) {
      return this.text;
    }
    if (this.segments == null) {
      return this.text;
    }
    int j = this.segments.length;
    if (j == 0) {
      return this.text;
    }
    if (this.segmentsChars == null)
    {
      if (j == 1) {
        return this.text;
      }
      if ((j == 2) && (this.segments[0] == 0) && (this.segments[1] == i)) {
        return this.text;
      }
    }
    char[] arrayOfChar1 = new char[i];
    this.text.getChars(0, i, arrayOfChar1, 0);
    char[] arrayOfChar2 = new char[i + j];
    int k = 0;
    int m = 0;
    int n = getOrientation() == 67108864 ? 8207 : 8206;
    int i1;
    while (k < i) {
      if ((m < j) && (k == this.segments[m]))
      {
        i1 = (this.segmentsChars != null) && (this.segmentsChars.length > m) ? this.segmentsChars[m] : n;
        arrayOfChar2[(k + m++)] = i1;
      }
      else
      {
        arrayOfChar2[(k + m)] = arrayOfChar1[(k++)];
      }
    }
    while (m < j)
    {
      this.segments[m] = k;
      i1 = (this.segmentsChars != null) && (this.segmentsChars.length > m) ? this.segmentsChars[m] : n;
      arrayOfChar2[(k + m++)] = i1;
    }
    return new String(arrayOfChar2, 0, arrayOfChar2.length);
  }
  
  public int getSpacing()
  {
    checkLayout();
    return OS.PANGO_PIXELS(OS.pango_layout_get_spacing(this.layout));
  }
  
  public TextStyle getStyle(int paramInt)
  {
    checkLayout();
    int i = this.text.length();
    if ((0 > paramInt) || (paramInt >= i)) {
      SWT.error(6);
    }
    for (int j = 1; j < this.stylesCount; j++)
    {
      StyleItem localStyleItem = this.styles[j];
      if (localStyleItem.start > paramInt) {
        return this.styles[(j - 1)].style;
      }
    }
    return null;
  }
  
  public TextStyle[] getStyles()
  {
    checkLayout();
    Object localObject = new TextStyle[this.stylesCount];
    int i = 0;
    for (int j = 0; j < this.stylesCount; j++) {
      if (this.styles[j].style != null) {
        localObject[(i++)] = this.styles[j].style;
      }
    }
    if (i != localObject.length)
    {
      TextStyle[] arrayOfTextStyle = new TextStyle[i];
      System.arraycopy(localObject, 0, arrayOfTextStyle, 0, i);
      localObject = arrayOfTextStyle;
    }
    return (TextStyle[])localObject;
  }
  
  public int[] getTabs()
  {
    checkLayout();
    return this.tabs;
  }
  
  public String getText()
  {
    checkLayout();
    return this.text;
  }
  
  public int getTextDirection()
  {
    return getOrientation();
  }
  
  public int getWidth()
  {
    checkLayout();
    return this.wrapWidth;
  }
  
  public int getWrapIndent()
  {
    checkLayout();
    return this.wrapIndent;
  }
  
  public boolean isDisposed()
  {
    return this.layout == 0;
  }
  
  public void setAlignment(int paramInt)
  {
    checkLayout();
    int i = 16924672;
    paramInt &= i;
    if (paramInt == 0) {
      return;
    }
    if ((paramInt & 0x4000) != 0) {
      paramInt = 16384;
    }
    if ((paramInt & 0x20000) != 0) {
      paramInt = 131072;
    }
    int j = OS.pango_context_get_base_dir(this.context) == 1 ? 1 : 0;
    int k = 1;
    switch (paramInt)
    {
    case 16384: 
      k = j != 0 ? 2 : 0;
      break;
    case 131072: 
      k = j != 0 ? 0 : 2;
    }
    OS.pango_layout_set_alignment(this.layout, k);
  }
  
  public void setAscent(int paramInt)
  {
    checkLayout();
    if (paramInt < -1) {
      SWT.error(5);
    }
    if (this.ascent == paramInt) {
      return;
    }
    freeRuns();
    this.ascent = paramInt;
  }
  
  public void setDescent(int paramInt)
  {
    checkLayout();
    if (paramInt < -1) {
      SWT.error(5);
    }
    if (this.descent == paramInt) {
      return;
    }
    freeRuns();
    this.descent = paramInt;
  }
  
  public void setFont(Font paramFont)
  {
    checkLayout();
    if ((paramFont != null) && (paramFont.isDisposed())) {
      SWT.error(5);
    }
    Font localFont = this.font;
    if (localFont == paramFont) {
      return;
    }
    freeRuns();
    this.font = paramFont;
    if ((localFont != null) && (localFont.equals(paramFont))) {
      return;
    }
    OS.pango_layout_set_font_description(this.layout, paramFont != null ? paramFont.handle : this.device.systemFont.handle);
  }
  
  public void setIndent(int paramInt)
  {
    checkLayout();
    if (paramInt < 0) {
      return;
    }
    if (this.indent == paramInt) {
      return;
    }
    this.indent = paramInt;
    OS.pango_layout_set_indent(this.layout, (paramInt - this.wrapIndent) * 1024);
    if (this.wrapWidth != -1) {
      setWidth();
    }
  }
  
  public void setJustify(boolean paramBoolean)
  {
    checkLayout();
    OS.pango_layout_set_justify(this.layout, paramBoolean);
  }
  
  public void setOrientation(int paramInt)
  {
    checkLayout();
    int i = 100663296;
    paramInt &= i;
    if (paramInt == 0) {
      return;
    }
    if ((paramInt & 0x2000000) != 0) {
      paramInt = 33554432;
    }
    int j = paramInt == 67108864 ? 1 : 0;
    if (OS.pango_context_get_base_dir(this.context) == j) {
      return;
    }
    freeRuns();
    OS.pango_context_set_base_dir(this.context, j);
    OS.pango_layout_context_changed(this.layout);
    int k = OS.pango_layout_get_alignment(this.layout);
    if (k != 1)
    {
      k = k == 0 ? 2 : 0;
      OS.pango_layout_set_alignment(this.layout, k);
    }
  }
  
  public void setSpacing(int paramInt)
  {
    checkLayout();
    if (paramInt < 0) {
      SWT.error(5);
    }
    OS.pango_layout_set_spacing(this.layout, paramInt * 1024);
  }
  
  public void setSegments(int[] paramArrayOfInt)
  {
    checkLayout();
    if ((this.segments == null) && (paramArrayOfInt == null)) {
      return;
    }
    if ((this.segments != null) && (paramArrayOfInt != null) && (this.segments.length == paramArrayOfInt.length))
    {
      for (int i = 0; (i < paramArrayOfInt.length) && (this.segments[i] == paramArrayOfInt[i]); i++) {}
      if (i == paramArrayOfInt.length) {
        return;
      }
    }
    freeRuns();
    this.segments = paramArrayOfInt;
  }
  
  public void setSegmentsChars(char[] paramArrayOfChar)
  {
    checkLayout();
    if ((this.segmentsChars == null) && (paramArrayOfChar == null)) {
      return;
    }
    if ((this.segmentsChars != null) && (paramArrayOfChar != null) && (this.segmentsChars.length == paramArrayOfChar.length))
    {
      for (int i = 0; (i < paramArrayOfChar.length) && (this.segmentsChars[i] == paramArrayOfChar[i]); i++) {}
      if (i == paramArrayOfChar.length) {
        return;
      }
    }
    freeRuns();
    this.segmentsChars = paramArrayOfChar;
  }
  
  public void setStyle(TextStyle paramTextStyle, int paramInt1, int paramInt2)
  {
    checkLayout();
    int i = this.text.length();
    if (i == 0) {
      return;
    }
    if (paramInt1 > paramInt2) {
      return;
    }
    paramInt1 = Math.min(Math.max(0, paramInt1), i - 1);
    paramInt2 = Math.min(Math.max(0, paramInt2), i - 1);
    if ((paramInt1 > 0) && (isAlef(this.text.charAt(paramInt1))) && (isLam(this.text.charAt(paramInt1 - 1)))) {
      paramInt1--;
    }
    if ((paramInt2 < i - 1) && (isLam(this.text.charAt(paramInt2))) && (isAlef(this.text.charAt(paramInt2 + 1)))) {
      paramInt2++;
    }
    int j = -1;
    StyleItem localStyleItem1 = this.stylesCount;
    while (localStyleItem1 - j > 1)
    {
      StyleItem localStyleItem2 = (localStyleItem1 + j) / 2;
      if (this.styles[(localStyleItem2 + 1)].start > paramInt1) {
        localStyleItem1 = localStyleItem2;
      } else {
        j = localStyleItem2;
      }
    }
    if ((0 <= localStyleItem1) && (localStyleItem1 < this.stylesCount))
    {
      localStyleItem3 = this.styles[localStyleItem1];
      if ((localStyleItem3.start == paramInt1) && (this.styles[(localStyleItem1 + 1)].start - 1 == paramInt2)) {
        if (paramTextStyle == null)
        {
          if (localStyleItem3.style != null) {}
        }
        else if (paramTextStyle.equals(localStyleItem3.style)) {
          return;
        }
      }
    }
    freeRuns();
    StyleItem localStyleItem3 = localStyleItem1;
    for (StyleItem localStyleItem4 = localStyleItem3; (localStyleItem4 < this.stylesCount) && (this.styles[(localStyleItem4 + 1)].start <= paramInt2); localStyleItem4++) {}
    int m;
    if (localStyleItem3 == localStyleItem4)
    {
      k = this.styles[localStyleItem3].start;
      m = this.styles[(localStyleItem4 + 1)].start - 1;
      if ((k == paramInt1) && (m == paramInt2))
      {
        this.styles[localStyleItem3].style = paramTextStyle;
        return;
      }
      if ((k != paramInt1) && (m != paramInt2))
      {
        int n = this.stylesCount + 2;
        if (n > this.styles.length)
        {
          int i1 = Math.min(n + 1024, Math.max(64, n * 2));
          StyleItem[] arrayOfStyleItem2 = new StyleItem[i1];
          System.arraycopy(this.styles, 0, arrayOfStyleItem2, 0, this.stylesCount);
          this.styles = arrayOfStyleItem2;
        }
        System.arraycopy(this.styles, localStyleItem4 + 1, this.styles, localStyleItem4 + 3, this.stylesCount - localStyleItem4 - 1);
        StyleItem localStyleItem6 = new StyleItem();
        localStyleItem6.start = paramInt1;
        localStyleItem6.style = paramTextStyle;
        this.styles[(localStyleItem3 + 1)] = localStyleItem6;
        localStyleItem6 = new StyleItem();
        localStyleItem6.start = (paramInt2 + 1);
        localStyleItem6.style = this.styles[localStyleItem3].style;
        this.styles[(localStyleItem3 + 2)] = localStyleItem6;
        this.stylesCount = n;
        return;
      }
    }
    if (paramInt1 == this.styles[localStyleItem3].start) {
      localStyleItem3--;
    }
    if (paramInt2 == this.styles[(localStyleItem4 + 1)].start - 1) {
      localStyleItem4++;
    }
    int k = this.stylesCount + 1 - (localStyleItem4 - localStyleItem3 - 1);
    if (k > this.styles.length)
    {
      m = Math.min(k + 1024, Math.max(64, k * 2));
      StyleItem[] arrayOfStyleItem1 = new StyleItem[m];
      System.arraycopy(this.styles, 0, arrayOfStyleItem1, 0, this.stylesCount);
      this.styles = arrayOfStyleItem1;
    }
    System.arraycopy(this.styles, localStyleItem4, this.styles, localStyleItem3 + 2, this.stylesCount - localStyleItem4);
    StyleItem localStyleItem5 = new StyleItem();
    localStyleItem5.start = paramInt1;
    localStyleItem5.style = paramTextStyle;
    this.styles[(localStyleItem3 + 1)] = localStyleItem5;
    this.styles[(localStyleItem3 + 2)].start = (paramInt2 + 1);
    this.stylesCount = k;
  }
  
  public void setTabs(int[] paramArrayOfInt)
  {
    checkLayout();
    if ((this.tabs == null) && (paramArrayOfInt == null)) {
      return;
    }
    int i;
    if ((this.tabs != null) && (paramArrayOfInt != null) && (this.tabs.length == paramArrayOfInt.length))
    {
      for (i = 0; (i < paramArrayOfInt.length) && (this.tabs[i] == paramArrayOfInt[i]); i++) {}
      if (i == paramArrayOfInt.length) {
        return;
      }
    }
    this.tabs = paramArrayOfInt;
    if (paramArrayOfInt == null)
    {
      OS.pango_layout_set_tabs(this.layout, this.device.emptyTab);
    }
    else
    {
      i = OS.pango_tab_array_new(paramArrayOfInt.length, true);
      if (i != 0)
      {
        for (int j = 0; j < paramArrayOfInt.length; j++) {
          OS.pango_tab_array_set_tab(i, j, 0, paramArrayOfInt[j]);
        }
        OS.pango_layout_set_tabs(this.layout, i);
        OS.pango_tab_array_free(i);
      }
    }
    OS.pango_layout_context_changed(this.layout);
  }
  
  public void setText(String paramString)
  {
    checkLayout();
    if (paramString == null) {
      SWT.error(4);
    }
    if (paramString.equals(this.text)) {
      return;
    }
    freeRuns();
    this.text = paramString;
    this.styles = new StyleItem[2];
    this.styles[0] = new StyleItem();
    this.styles[1] = new StyleItem();
    this.styles[1].start = paramString.length();
    this.stylesCount = 2;
  }
  
  public void setTextDirection(int paramInt)
  {
    checkLayout();
  }
  
  public void setWidth(int paramInt)
  {
    checkLayout();
    if ((paramInt < -1) || (paramInt == 0)) {
      SWT.error(5);
    }
    if (this.wrapWidth == paramInt) {
      return;
    }
    freeRuns();
    this.wrapWidth = paramInt;
    setWidth();
  }
  
  void setWidth()
  {
    int i;
    if (this.wrapWidth == -1)
    {
      OS.pango_layout_set_width(this.layout, -1);
      i = OS.pango_context_get_base_dir(this.context) == 1 ? 1 : 0;
      OS.pango_layout_set_alignment(this.layout, i != 0 ? 2 : 0);
    }
    else
    {
      i = Math.min(this.indent, this.wrapIndent);
      OS.pango_layout_set_width(this.layout, (this.wrapWidth - i) * 1024);
    }
  }
  
  public void setWrapIndent(int paramInt)
  {
    checkLayout();
    if (paramInt < 0) {
      return;
    }
    if (this.wrapIndent == paramInt) {
      return;
    }
    this.wrapIndent = paramInt;
    OS.pango_layout_set_indent(this.layout, (this.indent - paramInt) * 1024);
    if (this.wrapWidth != -1) {
      setWidth();
    }
  }
  
  static final boolean isLam(int paramInt)
  {
    return paramInt == 1604;
  }
  
  static final boolean isAlef(int paramInt)
  {
    switch (paramInt)
    {
    case 1570: 
    case 1571: 
    case 1573: 
    case 1575: 
    case 1609: 
    case 1648: 
    case 1649: 
    case 1650: 
    case 1651: 
    case 1653: 
      return true;
    }
    return false;
  }
  
  public String toString()
  {
    if (isDisposed()) {
      return "TextLayout {*DISPOSED*}";
    }
    return "TextLayout {" + this.layout + "}";
  }
  
  int translateOffset(int paramInt)
  {
    int i = this.text.length();
    if (i == 0) {
      return paramInt;
    }
    if (this.invalidOffsets == null) {
      return paramInt;
    }
    for (int j = 0; (j < this.invalidOffsets.length) && (paramInt >= this.invalidOffsets[j]); j++) {
      paramInt++;
    }
    return paramInt;
  }
  
  int untranslateOffset(int paramInt)
  {
    int i = this.text.length();
    if (i == 0) {
      return paramInt;
    }
    if (this.invalidOffsets == null) {
      return paramInt;
    }
    for (int j = 0; (j < this.invalidOffsets.length) && (paramInt > this.invalidOffsets[j]); j++) {}
    return paramInt - j;
  }
  
  int width()
  {
    int i = OS.pango_layout_get_width(this.layout);
    if (i != -1) {
      return OS.PANGO_PIXELS(i);
    }
    int[] arrayOfInt1 = new int[1];
    int[] arrayOfInt2 = new int[1];
    OS.pango_layout_get_pixel_size(this.layout, arrayOfInt1, arrayOfInt2);
    return arrayOfInt1[0];
  }
  
  static class StyleItem
  {
    TextStyle style;
    int start;
    
    public String toString()
    {
      return "StyleItem {" + this.start + ", " + this.style + "}";
    }
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/graphics/TextLayout.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */