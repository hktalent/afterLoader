package org.eclipse.swt.internal;

import java.util.EventObject;

public class SWTEventObject
  extends EventObject
{
  static final long serialVersionUID = 3258125873411470903L;
  
  public SWTEventObject(Object paramObject)
  {
    super(paramObject);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/internal/SWTEventObject.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */