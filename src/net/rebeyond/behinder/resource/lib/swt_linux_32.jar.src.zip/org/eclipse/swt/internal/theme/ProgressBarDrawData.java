package org.eclipse.swt.internal.theme;

import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.GCData;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.internal.Converter;
import org.eclipse.swt.internal.gtk.OS;

public class ProgressBarDrawData
  extends RangeDrawData
{
  public ProgressBarDrawData()
  {
    this.state = new int[1];
  }
  
  void draw(Theme paramTheme, GC paramGC, Rectangle paramRectangle)
  {
    int i = paramTheme.progressHandle;
    int j = OS.gtk_widget_get_style(i);
    int k = paramGC.getGCData().drawable;
    paramTheme.transferClipping(paramGC, j);
    byte[] arrayOfByte = Converter.wcsToMbcs(null, "trough", true);
    int m = paramRectangle.x;
    int n = paramRectangle.y;
    int i1 = paramRectangle.width;
    int i2 = paramRectangle.height;
    gtk_render_box(j, k, getStateType(0), 1, null, i, arrayOfByte, m, n, i1, i2);
    int i3 = OS.gtk_style_get_xthickness(j);
    int i4 = OS.gtk_style_get_ythickness(j);
    if ((this.style & 0x200) != 0)
    {
      gtk_orientable_set_orientation(i, 2);
      m += i3;
      i1 -= i3 * 2;
      i2 -= i4 * 2;
      i2 = (int)(i2 * (this.selection / Math.max(1, this.maximum - this.minimum)));
      n += paramRectangle.height - i4 - i2;
    }
    else
    {
      gtk_orientable_set_orientation(i, 0);
      m += i3;
      n += i4;
      i1 -= i3 * 2;
      i2 -= i4 * 2;
      i1 = (int)(i1 * (this.selection / Math.max(1, this.maximum - this.minimum)));
    }
    arrayOfByte = Converter.wcsToMbcs(null, "bar", true);
    gtk_render_box(j, k, 2, 2, null, i, arrayOfByte, m, n, i1, i2);
  }
  
  int getStateType(int paramInt)
  {
    return 0;
  }
  
  int hit(Theme paramTheme, Point paramPoint, Rectangle paramRectangle)
  {
    return paramRectangle.contains(paramPoint) ? 0 : -1;
  }
  
  void gtk_orientable_set_orientation(int paramInt1, int paramInt2)
  {
    if (OS.GTK3) {
      switch (paramInt2)
      {
      case 2: 
        OS.gtk_orientable_set_orientation(paramInt1, 1);
        OS.gtk_progress_bar_set_inverted(paramInt1, true);
        break;
      case 0: 
        OS.gtk_orientable_set_orientation(paramInt1, 0);
        OS.gtk_progress_bar_set_inverted(paramInt1, false);
      }
    } else {
      OS.gtk_progress_bar_set_orientation(paramInt1, paramInt2);
    }
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/internal/theme/ProgressBarDrawData.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */