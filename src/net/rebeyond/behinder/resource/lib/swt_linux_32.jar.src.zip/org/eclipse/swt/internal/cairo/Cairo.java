package org.eclipse.swt.internal.cairo;

import org.eclipse.swt.internal.Library;
import org.eclipse.swt.internal.Lock;
import org.eclipse.swt.internal.Platform;

public class Cairo
  extends Platform
{
  public static final int CAIRO_ANTIALIAS_DEFAULT = 0;
  public static final int CAIRO_ANTIALIAS_NONE = 1;
  public static final int CAIRO_ANTIALIAS_GRAY = 2;
  public static final int CAIRO_ANTIALIAS_SUBPIXEL = 3;
  public static final int CAIRO_CONTENT_COLOR = 4096;
  public static final int CAIRO_CONTENT_ALPHA = 8192;
  public static final int CAIRO_CONTENT_COLOR_ALPHA = 12288;
  public static final int CAIRO_FORMAT_ARGB32 = 0;
  public static final int CAIRO_FORMAT_RGB24 = 1;
  public static final int CAIRO_FORMAT_A8 = 2;
  public static final int CAIRO_FORMAT_A1 = 3;
  public static final int CAIRO_OPERATOR_SOURCE = 1;
  public static final int CAIRO_OPERATOR_OVER = 2;
  public static final int CAIRO_OPERATOR_DIFFERENCE = 23;
  public static final int CAIRO_FILL_RULE_WINDING = 0;
  public static final int CAIRO_FILL_RULE_EVEN_ODD = 1;
  public static final int CAIRO_LINE_CAP_BUTT = 0;
  public static final int CAIRO_LINE_CAP_ROUND = 1;
  public static final int CAIRO_LINE_CAP_SQUARE = 2;
  public static final int CAIRO_LINE_JOIN_MITER = 0;
  public static final int CAIRO_LINE_JOIN_ROUND = 1;
  public static final int CAIRO_LINE_JOIN_BEVEL = 2;
  public static final int CAIRO_FONT_SLANT_NORMAL = 0;
  public static final int CAIRO_FONT_SLANT_ITALIC = 1;
  public static final int CAIRO_FONT_SLANT_OBLIQUE = 2;
  public static final int CAIRO_FONT_WEIGHT_NORMAL = 0;
  public static final int CAIRO_FONT_WEIGHT_BOLD = 1;
  public static final int CAIRO_STATUS_SUCCESS = 0;
  public static final int CAIRO_STATUS_NO_MEMORY = 1;
  public static final int CAIRO_STATUS_INVALID_RESTORE = 2;
  public static final int CAIRO_STATUS_INVALID_POP_GROUP = 3;
  public static final int CAIRO_STATUS_NO_CURRENT_POINT = 4;
  public static final int CAIRO_STATUS_INVALID_MATRIX = 5;
  public static final int CAIRO_STATUS_NO_TARGET_SURFACE = 6;
  public static final int CAIRO_STATUS_NULL_POINTER = 7;
  public static final int CAIRO_SURFACE_TYPE_IMAGE = 0;
  public static final int CAIRO_SURFACE_TYPE_PDF = 1;
  public static final int CAIRO_SURFACE_TYPE_PS = 2;
  public static final int CAIRO_SURFACE_TYPE_XLIB = 3;
  public static final int CAIRO_SURFACE_TYPE_XCB = 4;
  public static final int CAIRO_SURFACE_TYPE_GLITZ = 5;
  public static final int CAIRO_SURFACE_TYPE_QUARTZ = 6;
  public static final int CAIRO_SURFACE_TYPE_WIN32 = 7;
  public static final int CAIRO_SURFACE_TYPE_BEOS = 8;
  public static final int CAIRO_SURFACE_TYPE_DIRECTFB = 9;
  public static final int CAIRO_SURFACE_TYPE_SVG = 10;
  public static final int CAIRO_FILTER_FAST = 0;
  public static final int CAIRO_FILTER_GOOD = 1;
  public static final int CAIRO_FILTER_BEST = 2;
  public static final int CAIRO_FILTER_NEAREST = 3;
  public static final int CAIRO_FILTER_BILINEAR = 4;
  public static final int CAIRO_FILTER_GAUSSIAN = 5;
  public static final int CAIRO_EXTEND_NONE = 0;
  public static final int CAIRO_EXTEND_REPEAT = 1;
  public static final int CAIRO_EXTEND_REFLECT = 2;
  public static final int CAIRO_EXTEND_PAD = 3;
  public static final int CAIRO_PATH_MOVE_TO = 0;
  public static final int CAIRO_PATH_LINE_TO = 1;
  public static final int CAIRO_PATH_CURVE_TO = 2;
  public static final int CAIRO_PATH_CLOSE_PATH = 3;
  
  public static final native int cairo_path_data_t_sizeof();
  
  public static final native int cairo_path_t_sizeof();
  
  public static final native int CAIRO_VERSION_ENCODE(int paramInt1, int paramInt2, int paramInt3);
  
  public static final native void _cairo_append_path(int paramInt1, int paramInt2);
  
  public static final void cairo_append_path(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _cairo_append_path(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _cairo_arc(int paramInt, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5);
  
  public static final void cairo_arc(int paramInt, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5)
  {
    lock.lock();
    try
    {
      _cairo_arc(paramInt, paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramDouble5);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _cairo_arc_negative(int paramInt, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5);
  
  public static final void cairo_arc_negative(int paramInt, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5)
  {
    lock.lock();
    try
    {
      _cairo_arc_negative(paramInt, paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramDouble5);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _cairo_clip(int paramInt);
  
  public static final void cairo_clip(int paramInt)
  {
    lock.lock();
    try
    {
      _cairo_clip(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _cairo_close_path(int paramInt);
  
  public static final void cairo_close_path(int paramInt)
  {
    lock.lock();
    try
    {
      _cairo_close_path(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _cairo_copy_page(int paramInt);
  
  public static final void cairo_copy_page(int paramInt)
  {
    lock.lock();
    try
    {
      _cairo_copy_page(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _cairo_copy_path(int paramInt);
  
  public static final int cairo_copy_path(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _cairo_copy_path(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _cairo_copy_path_flat(int paramInt);
  
  public static final int cairo_copy_path_flat(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _cairo_copy_path_flat(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _cairo_create(int paramInt);
  
  public static final int cairo_create(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _cairo_create(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _cairo_curve_to(int paramInt, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6);
  
  public static final void cairo_curve_to(int paramInt, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6)
  {
    lock.lock();
    try
    {
      _cairo_curve_to(paramInt, paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramDouble5, paramDouble6);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _cairo_destroy(int paramInt);
  
  public static final void cairo_destroy(int paramInt)
  {
    lock.lock();
    try
    {
      _cairo_destroy(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _cairo_fill(int paramInt);
  
  public static final void cairo_fill(int paramInt)
  {
    lock.lock();
    try
    {
      _cairo_fill(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _cairo_font_options_create();
  
  public static final int cairo_font_options_create()
  {
    lock.lock();
    try
    {
      int i = _cairo_font_options_create();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _cairo_font_options_destroy(int paramInt);
  
  public static final void cairo_font_options_destroy(int paramInt)
  {
    lock.lock();
    try
    {
      _cairo_font_options_destroy(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _cairo_font_options_get_antialias(int paramInt);
  
  public static final int cairo_font_options_get_antialias(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _cairo_font_options_get_antialias(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _cairo_font_options_set_antialias(int paramInt1, int paramInt2);
  
  public static final void cairo_font_options_set_antialias(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _cairo_font_options_set_antialias(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _cairo_get_antialias(int paramInt);
  
  public static final int cairo_get_antialias(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _cairo_get_antialias(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _cairo_get_current_point(int paramInt, double[] paramArrayOfDouble1, double[] paramArrayOfDouble2);
  
  public static final void cairo_get_current_point(int paramInt, double[] paramArrayOfDouble1, double[] paramArrayOfDouble2)
  {
    lock.lock();
    try
    {
      _cairo_get_current_point(paramInt, paramArrayOfDouble1, paramArrayOfDouble2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _cairo_get_fill_rule(int paramInt);
  
  public static final int cairo_get_fill_rule(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _cairo_get_fill_rule(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _cairo_get_font_face(int paramInt);
  
  public static final int cairo_get_font_face(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _cairo_get_font_face(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _cairo_get_matrix(int paramInt, double[] paramArrayOfDouble);
  
  public static final void cairo_get_matrix(int paramInt, double[] paramArrayOfDouble)
  {
    lock.lock();
    try
    {
      _cairo_get_matrix(paramInt, paramArrayOfDouble);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _cairo_get_operator(int paramInt);
  
  public static final int cairo_get_operator(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _cairo_get_operator(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _cairo_get_source(int paramInt);
  
  public static final int cairo_get_source(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _cairo_get_source(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _cairo_get_target(int paramInt);
  
  public static final int cairo_get_target(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _cairo_get_target(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native double _cairo_get_tolerance(int paramInt);
  
  public static final double cairo_get_tolerance(int paramInt)
  {
    lock.lock();
    try
    {
      double d = _cairo_get_tolerance(paramInt);
      return d;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _cairo_identity_matrix(int paramInt);
  
  public static final void cairo_identity_matrix(int paramInt)
  {
    lock.lock();
    try
    {
      _cairo_identity_matrix(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _cairo_image_surface_create(int paramInt1, int paramInt2, int paramInt3);
  
  public static final int cairo_image_surface_create(int paramInt1, int paramInt2, int paramInt3)
  {
    lock.lock();
    try
    {
      int i = _cairo_image_surface_create(paramInt1, paramInt2, paramInt3);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _cairo_image_surface_get_data(int paramInt);
  
  public static final int cairo_image_surface_get_data(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _cairo_image_surface_get_data(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _cairo_image_surface_get_format(int paramInt);
  
  public static final int cairo_image_surface_get_format(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _cairo_image_surface_get_format(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _cairo_image_surface_get_height(int paramInt);
  
  public static final int cairo_image_surface_get_height(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _cairo_image_surface_get_height(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _cairo_image_surface_get_width(int paramInt);
  
  public static final int cairo_image_surface_get_width(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _cairo_image_surface_get_width(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _cairo_image_surface_get_stride(int paramInt);
  
  public static final int cairo_image_surface_get_stride(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _cairo_image_surface_get_stride(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _cairo_in_fill(int paramInt, double paramDouble1, double paramDouble2);
  
  public static final int cairo_in_fill(int paramInt, double paramDouble1, double paramDouble2)
  {
    lock.lock();
    try
    {
      int i = _cairo_in_fill(paramInt, paramDouble1, paramDouble2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _cairo_in_stroke(int paramInt, double paramDouble1, double paramDouble2);
  
  public static final int cairo_in_stroke(int paramInt, double paramDouble1, double paramDouble2)
  {
    lock.lock();
    try
    {
      int i = _cairo_in_stroke(paramInt, paramDouble1, paramDouble2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _cairo_line_to(int paramInt, double paramDouble1, double paramDouble2);
  
  public static final void cairo_line_to(int paramInt, double paramDouble1, double paramDouble2)
  {
    lock.lock();
    try
    {
      _cairo_line_to(paramInt, paramDouble1, paramDouble2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _cairo_mask(int paramInt1, int paramInt2);
  
  public static final void cairo_mask(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _cairo_mask(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _cairo_mask_surface(int paramInt1, int paramInt2, double paramDouble1, double paramDouble2);
  
  public static final void cairo_mask_surface(int paramInt1, int paramInt2, double paramDouble1, double paramDouble2)
  {
    lock.lock();
    try
    {
      _cairo_mask_surface(paramInt1, paramInt2, paramDouble1, paramDouble2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _cairo_matrix_init(double[] paramArrayOfDouble, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6);
  
  public static final void cairo_matrix_init(double[] paramArrayOfDouble, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6)
  {
    lock.lock();
    try
    {
      _cairo_matrix_init(paramArrayOfDouble, paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramDouble5, paramDouble6);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _cairo_matrix_init_identity(double[] paramArrayOfDouble);
  
  public static final void cairo_matrix_init_identity(double[] paramArrayOfDouble)
  {
    lock.lock();
    try
    {
      _cairo_matrix_init_identity(paramArrayOfDouble);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _cairo_matrix_init_rotate(double[] paramArrayOfDouble, double paramDouble);
  
  public static final void cairo_matrix_init_rotate(double[] paramArrayOfDouble, double paramDouble)
  {
    lock.lock();
    try
    {
      _cairo_matrix_init_rotate(paramArrayOfDouble, paramDouble);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _cairo_matrix_init_scale(double[] paramArrayOfDouble, double paramDouble1, double paramDouble2);
  
  public static final void cairo_matrix_init_scale(double[] paramArrayOfDouble, double paramDouble1, double paramDouble2)
  {
    lock.lock();
    try
    {
      _cairo_matrix_init_scale(paramArrayOfDouble, paramDouble1, paramDouble2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _cairo_matrix_init_translate(double[] paramArrayOfDouble, double paramDouble1, double paramDouble2);
  
  public static final void cairo_matrix_init_translate(double[] paramArrayOfDouble, double paramDouble1, double paramDouble2)
  {
    lock.lock();
    try
    {
      _cairo_matrix_init_translate(paramArrayOfDouble, paramDouble1, paramDouble2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _cairo_matrix_invert(double[] paramArrayOfDouble);
  
  public static final int cairo_matrix_invert(double[] paramArrayOfDouble)
  {
    lock.lock();
    try
    {
      int i = _cairo_matrix_invert(paramArrayOfDouble);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _cairo_matrix_multiply(double[] paramArrayOfDouble1, double[] paramArrayOfDouble2, double[] paramArrayOfDouble3);
  
  public static final void cairo_matrix_multiply(double[] paramArrayOfDouble1, double[] paramArrayOfDouble2, double[] paramArrayOfDouble3)
  {
    lock.lock();
    try
    {
      _cairo_matrix_multiply(paramArrayOfDouble1, paramArrayOfDouble2, paramArrayOfDouble3);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _cairo_matrix_rotate(double[] paramArrayOfDouble, double paramDouble);
  
  public static final void cairo_matrix_rotate(double[] paramArrayOfDouble, double paramDouble)
  {
    lock.lock();
    try
    {
      _cairo_matrix_rotate(paramArrayOfDouble, paramDouble);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _cairo_matrix_scale(double[] paramArrayOfDouble, double paramDouble1, double paramDouble2);
  
  public static final void cairo_matrix_scale(double[] paramArrayOfDouble, double paramDouble1, double paramDouble2)
  {
    lock.lock();
    try
    {
      _cairo_matrix_scale(paramArrayOfDouble, paramDouble1, paramDouble2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _cairo_matrix_transform_distance(double[] paramArrayOfDouble1, double[] paramArrayOfDouble2, double[] paramArrayOfDouble3);
  
  public static final void cairo_matrix_transform_distance(double[] paramArrayOfDouble1, double[] paramArrayOfDouble2, double[] paramArrayOfDouble3)
  {
    lock.lock();
    try
    {
      _cairo_matrix_transform_distance(paramArrayOfDouble1, paramArrayOfDouble2, paramArrayOfDouble3);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _cairo_matrix_transform_point(double[] paramArrayOfDouble1, double[] paramArrayOfDouble2, double[] paramArrayOfDouble3);
  
  public static final void cairo_matrix_transform_point(double[] paramArrayOfDouble1, double[] paramArrayOfDouble2, double[] paramArrayOfDouble3)
  {
    lock.lock();
    try
    {
      _cairo_matrix_transform_point(paramArrayOfDouble1, paramArrayOfDouble2, paramArrayOfDouble3);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _cairo_matrix_translate(double[] paramArrayOfDouble, double paramDouble1, double paramDouble2);
  
  public static final void cairo_matrix_translate(double[] paramArrayOfDouble, double paramDouble1, double paramDouble2)
  {
    lock.lock();
    try
    {
      _cairo_matrix_translate(paramArrayOfDouble, paramDouble1, paramDouble2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _cairo_move_to(int paramInt, double paramDouble1, double paramDouble2);
  
  public static final void cairo_move_to(int paramInt, double paramDouble1, double paramDouble2)
  {
    lock.lock();
    try
    {
      _cairo_move_to(paramInt, paramDouble1, paramDouble2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _cairo_new_path(int paramInt);
  
  public static final void cairo_new_path(int paramInt)
  {
    lock.lock();
    try
    {
      _cairo_new_path(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _cairo_paint(int paramInt);
  
  public static final void cairo_paint(int paramInt)
  {
    lock.lock();
    try
    {
      _cairo_paint(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _cairo_paint_with_alpha(int paramInt, double paramDouble);
  
  public static final void cairo_paint_with_alpha(int paramInt, double paramDouble)
  {
    lock.lock();
    try
    {
      _cairo_paint_with_alpha(paramInt, paramDouble);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _cairo_path_destroy(int paramInt);
  
  public static final void cairo_path_destroy(int paramInt)
  {
    lock.lock();
    try
    {
      _cairo_path_destroy(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _cairo_pattern_add_color_stop_rgba(int paramInt, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5);
  
  public static final void cairo_pattern_add_color_stop_rgba(int paramInt, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5)
  {
    lock.lock();
    try
    {
      _cairo_pattern_add_color_stop_rgba(paramInt, paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramDouble5);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _cairo_pattern_create_for_surface(int paramInt);
  
  public static final int cairo_pattern_create_for_surface(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _cairo_pattern_create_for_surface(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _cairo_pattern_create_linear(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4);
  
  public static final int cairo_pattern_create_linear(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4)
  {
    lock.lock();
    try
    {
      int i = _cairo_pattern_create_linear(paramDouble1, paramDouble2, paramDouble3, paramDouble4);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _cairo_pattern_destroy(int paramInt);
  
  public static final void cairo_pattern_destroy(int paramInt)
  {
    lock.lock();
    try
    {
      _cairo_pattern_destroy(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _cairo_pattern_get_extend(int paramInt);
  
  public static final int cairo_pattern_get_extend(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _cairo_pattern_get_extend(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _cairo_pattern_set_extend(int paramInt1, int paramInt2);
  
  public static final void cairo_pattern_set_extend(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _cairo_pattern_set_extend(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _cairo_pattern_set_filter(int paramInt1, int paramInt2);
  
  public static final void cairo_pattern_set_filter(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _cairo_pattern_set_filter(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _cairo_pattern_set_matrix(int paramInt, double[] paramArrayOfDouble);
  
  public static final void cairo_pattern_set_matrix(int paramInt, double[] paramArrayOfDouble)
  {
    lock.lock();
    try
    {
      _cairo_pattern_set_matrix(paramInt, paramArrayOfDouble);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _cairo_pdf_surface_set_size(int paramInt, double paramDouble1, double paramDouble2);
  
  public static final void cairo_pdf_surface_set_size(int paramInt, double paramDouble1, double paramDouble2)
  {
    lock.lock();
    try
    {
      _cairo_pdf_surface_set_size(paramInt, paramDouble1, paramDouble2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _cairo_push_group(int paramInt);
  
  public static final void cairo_push_group(int paramInt)
  {
    lock.lock();
    try
    {
      _cairo_push_group(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _cairo_pop_group_to_source(int paramInt);
  
  public static final void cairo_pop_group_to_source(int paramInt)
  {
    lock.lock();
    try
    {
      _cairo_pop_group_to_source(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _cairo_ps_surface_set_size(int paramInt, double paramDouble1, double paramDouble2);
  
  public static final void cairo_ps_surface_set_size(int paramInt, double paramDouble1, double paramDouble2)
  {
    lock.lock();
    try
    {
      _cairo_ps_surface_set_size(paramInt, paramDouble1, paramDouble2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _cairo_rectangle(int paramInt, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4);
  
  public static final void cairo_rectangle(int paramInt, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4)
  {
    lock.lock();
    try
    {
      _cairo_rectangle(paramInt, paramDouble1, paramDouble2, paramDouble3, paramDouble4);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _cairo_reference(int paramInt);
  
  public static final int cairo_reference(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _cairo_reference(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _cairo_reset_clip(int paramInt);
  
  public static final void cairo_reset_clip(int paramInt)
  {
    lock.lock();
    try
    {
      _cairo_reset_clip(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _cairo_restore(int paramInt);
  
  public static final void cairo_restore(int paramInt)
  {
    lock.lock();
    try
    {
      _cairo_restore(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _cairo_rotate(int paramInt, double paramDouble);
  
  public static final void cairo_rotate(int paramInt, double paramDouble)
  {
    lock.lock();
    try
    {
      _cairo_rotate(paramInt, paramDouble);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _cairo_save(int paramInt);
  
  public static final void cairo_save(int paramInt)
  {
    lock.lock();
    try
    {
      _cairo_save(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _cairo_scale(int paramInt, double paramDouble1, double paramDouble2);
  
  public static final void cairo_scale(int paramInt, double paramDouble1, double paramDouble2)
  {
    lock.lock();
    try
    {
      _cairo_scale(paramInt, paramDouble1, paramDouble2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _cairo_select_font_face(int paramInt1, byte[] paramArrayOfByte, int paramInt2, int paramInt3);
  
  public static final void cairo_select_font_face(int paramInt1, byte[] paramArrayOfByte, int paramInt2, int paramInt3)
  {
    lock.lock();
    try
    {
      _cairo_select_font_face(paramInt1, paramArrayOfByte, paramInt2, paramInt3);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _cairo_set_antialias(int paramInt1, int paramInt2);
  
  public static final void cairo_set_antialias(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _cairo_set_antialias(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _cairo_set_dash(int paramInt1, double[] paramArrayOfDouble, int paramInt2, double paramDouble);
  
  public static final void cairo_set_dash(int paramInt1, double[] paramArrayOfDouble, int paramInt2, double paramDouble)
  {
    lock.lock();
    try
    {
      _cairo_set_dash(paramInt1, paramArrayOfDouble, paramInt2, paramDouble);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _cairo_set_fill_rule(int paramInt1, int paramInt2);
  
  public static final void cairo_set_fill_rule(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _cairo_set_fill_rule(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _cairo_set_font_face(int paramInt1, int paramInt2);
  
  public static final void cairo_set_font_face(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _cairo_set_font_face(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _cairo_set_font_size(int paramInt, double paramDouble);
  
  public static final void cairo_set_font_size(int paramInt, double paramDouble)
  {
    lock.lock();
    try
    {
      _cairo_set_font_size(paramInt, paramDouble);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _cairo_set_line_cap(int paramInt1, int paramInt2);
  
  public static final void cairo_set_line_cap(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _cairo_set_line_cap(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _cairo_set_line_join(int paramInt1, int paramInt2);
  
  public static final void cairo_set_line_join(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _cairo_set_line_join(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _cairo_set_line_width(int paramInt, double paramDouble);
  
  public static final void cairo_set_line_width(int paramInt, double paramDouble)
  {
    lock.lock();
    try
    {
      _cairo_set_line_width(paramInt, paramDouble);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _cairo_set_matrix(int paramInt, double[] paramArrayOfDouble);
  
  public static final void cairo_set_matrix(int paramInt, double[] paramArrayOfDouble)
  {
    lock.lock();
    try
    {
      _cairo_set_matrix(paramInt, paramArrayOfDouble);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _cairo_set_miter_limit(int paramInt, double paramDouble);
  
  public static final void cairo_set_miter_limit(int paramInt, double paramDouble)
  {
    lock.lock();
    try
    {
      _cairo_set_miter_limit(paramInt, paramDouble);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _cairo_set_operator(int paramInt1, int paramInt2);
  
  public static final void cairo_set_operator(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _cairo_set_operator(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _cairo_set_source(int paramInt1, int paramInt2);
  
  public static final void cairo_set_source(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _cairo_set_source(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _cairo_set_source_rgb(int paramInt, double paramDouble1, double paramDouble2, double paramDouble3);
  
  public static final void cairo_set_source_rgb(int paramInt, double paramDouble1, double paramDouble2, double paramDouble3)
  {
    lock.lock();
    try
    {
      _cairo_set_source_rgb(paramInt, paramDouble1, paramDouble2, paramDouble3);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _cairo_set_source_rgba(int paramInt, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4);
  
  public static final void cairo_set_source_rgba(int paramInt, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4)
  {
    lock.lock();
    try
    {
      _cairo_set_source_rgba(paramInt, paramDouble1, paramDouble2, paramDouble3, paramDouble4);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _cairo_set_source_surface(int paramInt1, int paramInt2, double paramDouble1, double paramDouble2);
  
  public static final void cairo_set_source_surface(int paramInt1, int paramInt2, double paramDouble1, double paramDouble2)
  {
    lock.lock();
    try
    {
      _cairo_set_source_surface(paramInt1, paramInt2, paramDouble1, paramDouble2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _cairo_set_tolerance(int paramInt, double paramDouble);
  
  public static final void cairo_set_tolerance(int paramInt, double paramDouble)
  {
    lock.lock();
    try
    {
      _cairo_set_tolerance(paramInt, paramDouble);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _cairo_show_page(int paramInt);
  
  public static final void cairo_show_page(int paramInt)
  {
    lock.lock();
    try
    {
      _cairo_show_page(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _cairo_stroke(int paramInt);
  
  public static final void cairo_stroke(int paramInt)
  {
    lock.lock();
    try
    {
      _cairo_stroke(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _cairo_surface_create_similar(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  public static final int cairo_surface_create_similar(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    lock.lock();
    try
    {
      int i = _cairo_surface_create_similar(paramInt1, paramInt2, paramInt3, paramInt4);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _cairo_surface_destroy(int paramInt);
  
  public static final void cairo_surface_destroy(int paramInt)
  {
    lock.lock();
    try
    {
      _cairo_surface_destroy(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _cairo_surface_flush(int paramInt);
  
  public static final void cairo_surface_flush(int paramInt)
  {
    lock.lock();
    try
    {
      _cairo_surface_flush(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _cairo_surface_finish(int paramInt);
  
  public static final void cairo_surface_finish(int paramInt)
  {
    lock.lock();
    try
    {
      _cairo_surface_finish(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _cairo_surface_get_type(int paramInt);
  
  public static final int cairo_surface_get_type(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _cairo_surface_get_type(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _cairo_surface_get_content(int paramInt);
  
  public static final int cairo_surface_get_content(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _cairo_surface_get_content(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _cairo_surface_get_user_data(int paramInt1, int paramInt2);
  
  public static final int cairo_surface_get_user_data(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      int i = _cairo_surface_get_user_data(paramInt1, paramInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _cairo_surface_mark_dirty(int paramInt);
  
  public static final void cairo_surface_mark_dirty(int paramInt)
  {
    lock.lock();
    try
    {
      _cairo_surface_mark_dirty(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _cairo_surface_reference(int paramInt);
  
  public static final void cairo_surface_reference(int paramInt)
  {
    lock.lock();
    try
    {
      _cairo_surface_reference(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _cairo_surface_set_device_offset(int paramInt, double paramDouble1, double paramDouble2);
  
  public static final void cairo_surface_set_device_offset(int paramInt, double paramDouble1, double paramDouble2)
  {
    lock.lock();
    try
    {
      _cairo_surface_set_device_offset(paramInt, paramDouble1, paramDouble2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _cairo_transform(int paramInt, double[] paramArrayOfDouble);
  
  public static final void cairo_transform(int paramInt, double[] paramArrayOfDouble)
  {
    lock.lock();
    try
    {
      _cairo_transform(paramInt, paramArrayOfDouble);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _cairo_translate(int paramInt, double paramDouble1, double paramDouble2);
  
  public static final void cairo_translate(int paramInt, double paramDouble1, double paramDouble2)
  {
    lock.lock();
    try
    {
      _cairo_translate(paramInt, paramDouble1, paramDouble2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _cairo_user_to_device_distance(int paramInt, double[] paramArrayOfDouble1, double[] paramArrayOfDouble2);
  
  public static final void cairo_user_to_device_distance(int paramInt, double[] paramArrayOfDouble1, double[] paramArrayOfDouble2)
  {
    lock.lock();
    try
    {
      _cairo_user_to_device_distance(paramInt, paramArrayOfDouble1, paramArrayOfDouble2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int cairo_version();
  
  public static final native int _cairo_xlib_surface_create(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5);
  
  public static final int cairo_xlib_surface_create(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
  {
    lock.lock();
    try
    {
      int i = _cairo_xlib_surface_create(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _cairo_xlib_surface_get_height(int paramInt);
  
  public static final int cairo_xlib_surface_get_height(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _cairo_xlib_surface_get_height(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _cairo_xlib_surface_get_width(int paramInt);
  
  public static final int cairo_xlib_surface_get_width(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _cairo_xlib_surface_get_width(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _cairo_region_num_rectangles(int paramInt);
  
  public static final int cairo_region_num_rectangles(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _cairo_region_num_rectangles(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _cairo_region_get_rectangle(int paramInt1, int paramInt2, int paramInt3);
  
  public static final void cairo_region_get_rectangle(int paramInt1, int paramInt2, int paramInt3)
  {
    lock.lock();
    try
    {
      _cairo_region_get_rectangle(paramInt1, paramInt2, paramInt3);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void memmove(cairo_path_t paramcairo_path_t, int paramInt1, int paramInt2);
  
  public static final native void memmove(cairo_path_data_t paramcairo_path_data_t, int paramInt1, int paramInt2);
  
  public static final native void memmove(double[] paramArrayOfDouble, int paramInt1, int paramInt2);
  
  static
  {
    Library.loadLibrary("swt-cairo");
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/internal/cairo/Cairo.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */