package org.eclipse.swt.accessibility;

import java.io.PrintStream;
import java.util.Hashtable;
import java.util.Vector;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Device;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.TextStyle;
import org.eclipse.swt.internal.C;
import org.eclipse.swt.internal.Converter;
import org.eclipse.swt.internal.LONG;
import org.eclipse.swt.internal.accessibility.gtk.ATK;
import org.eclipse.swt.internal.accessibility.gtk.AtkActionIface;
import org.eclipse.swt.internal.accessibility.gtk.AtkAttribute;
import org.eclipse.swt.internal.accessibility.gtk.AtkComponentIface;
import org.eclipse.swt.internal.accessibility.gtk.AtkEditableTextIface;
import org.eclipse.swt.internal.accessibility.gtk.AtkHypertextIface;
import org.eclipse.swt.internal.accessibility.gtk.AtkObjectClass;
import org.eclipse.swt.internal.accessibility.gtk.AtkSelectionIface;
import org.eclipse.swt.internal.accessibility.gtk.AtkTableIface;
import org.eclipse.swt.internal.accessibility.gtk.AtkTextIface;
import org.eclipse.swt.internal.accessibility.gtk.AtkTextRange;
import org.eclipse.swt.internal.accessibility.gtk.AtkTextRectangle;
import org.eclipse.swt.internal.accessibility.gtk.AtkValueIface;
import org.eclipse.swt.internal.accessibility.gtk.GtkAccessible;
import org.eclipse.swt.internal.gtk.GObjectClass;
import org.eclipse.swt.internal.gtk.GdkColor;
import org.eclipse.swt.internal.gtk.GdkRectangle;
import org.eclipse.swt.internal.gtk.OS;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Display;

class AccessibleObject
{
  int handle;
  int index = -1;
  int id = -1;
  Accessible accessible;
  AccessibleObject parent;
  AccessibleObject[] children;
  boolean isLightweight = false;
  static int actionNamePtr = -1;
  static int descriptionPtr = -1;
  static int keybindingPtr = -1;
  static int namePtr = -1;
  static final Hashtable AccessibleObjects = new Hashtable(9);
  static final boolean DEBUG = Device.DEBUG;
  static final int ROW_ROLE = ATK.atk_role_register(Converter.wcsToMbcs(null, "row", true));
  static final int COLUMN_ROLE = ATK.atk_role_register(Converter.wcsToMbcs(null, "column", true));
  
  AccessibleObject(int paramInt1, int paramInt2, Accessible paramAccessible, boolean paramBoolean)
  {
    this.handle = ATK.g_object_new(paramInt1, 0);
    ATK.atk_object_initialize(this.handle, paramInt2);
    this.accessible = paramAccessible;
    this.isLightweight = paramBoolean;
    AccessibleObjects.put(new LONG(this.handle), this);
    if (DEBUG) {
      print("new AccessibleObject: " + this.handle + " control=" + paramAccessible.control + " lw=" + paramBoolean);
    }
  }
  
  static void print(String paramString)
  {
    System.out.println(paramString);
  }
  
  static int size(Vector paramVector)
  {
    return paramVector == null ? 0 : paramVector.size();
  }
  
  static AtkActionIface getActionIface(int paramInt)
  {
    if (ATK.g_type_is_a(OS.g_type_parent(OS.G_OBJECT_TYPE(paramInt)), ATK.ATK_TYPE_ACTION()))
    {
      AtkActionIface localAtkActionIface = new AtkActionIface();
      ATK.memmove(localAtkActionIface, ATK.g_type_interface_peek_parent(ATK.ATK_ACTION_GET_IFACE(paramInt)));
      return localAtkActionIface;
    }
    return null;
  }
  
  static int atkAction_do_action(int paramInt1, int paramInt2)
  {
    if (DEBUG) {
      print("-->atkAction_do_action");
    }
    AccessibleObject localAccessibleObject = getAccessibleObject(paramInt1);
    if (localAccessibleObject != null)
    {
      Accessible localAccessible = localAccessibleObject.accessible;
      localObject = localAccessible.accessibleActionListeners;
      int j = size((Vector)localObject);
      if (j > 0)
      {
        AccessibleActionEvent localAccessibleActionEvent = new AccessibleActionEvent(localAccessible);
        localAccessibleActionEvent.index = paramInt2;
        for (int k = 0; k < j; k++)
        {
          AccessibleActionListener localAccessibleActionListener = (AccessibleActionListener)((Vector)localObject).elementAt(k);
          localAccessibleActionListener.doAction(localAccessibleActionEvent);
        }
        return "OK".equals(localAccessibleActionEvent.result) ? 1 : 0;
      }
    }
    int i = 0;
    Object localObject = getActionIface(paramInt1);
    if ((localObject != null) && (((AtkActionIface)localObject).do_action != 0)) {
      i = ATK.call(((AtkActionIface)localObject).do_action, paramInt1, paramInt2);
    }
    return i;
  }
  
  static int atkAction_get_n_actions(int paramInt)
  {
    if (DEBUG) {
      print("-->atkAction_get_n_actions");
    }
    AccessibleObject localAccessibleObject = getAccessibleObject(paramInt);
    if (localAccessibleObject != null)
    {
      Accessible localAccessible = localAccessibleObject.accessible;
      localObject = localAccessible.accessibleActionListeners;
      int j = size((Vector)localObject);
      if (j > 0)
      {
        AccessibleActionEvent localAccessibleActionEvent = new AccessibleActionEvent(localAccessible);
        for (int k = 0; k < j; k++)
        {
          AccessibleActionListener localAccessibleActionListener = (AccessibleActionListener)((Vector)localObject).elementAt(k);
          localAccessibleActionListener.getActionCount(localAccessibleActionEvent);
        }
        return localAccessibleActionEvent.count;
      }
    }
    int i = 0;
    Object localObject = getActionIface(paramInt);
    if ((localObject != null) && (((AtkActionIface)localObject).get_n_actions != 0)) {
      i = ATK.call(((AtkActionIface)localObject).get_n_actions, paramInt);
    }
    return i;
  }
  
  static int atkAction_get_description(int paramInt1, int paramInt2)
  {
    if (DEBUG) {
      print("-->atkAction_get_description");
    }
    AccessibleObject localAccessibleObject = getAccessibleObject(paramInt1);
    if (localAccessibleObject != null)
    {
      Accessible localAccessible = localAccessibleObject.accessible;
      localObject = localAccessible.accessibleActionListeners;
      int j = size((Vector)localObject);
      if (j > 0)
      {
        AccessibleActionEvent localAccessibleActionEvent = new AccessibleActionEvent(localAccessible);
        localAccessibleActionEvent.index = paramInt2;
        for (int k = 0; k < j; k++)
        {
          AccessibleActionListener localAccessibleActionListener = (AccessibleActionListener)((Vector)localObject).elementAt(k);
          localAccessibleActionListener.getDescription(localAccessibleActionEvent);
        }
        if (localAccessibleActionEvent.result == null) {
          return 0;
        }
        if (descriptionPtr != -1) {
          OS.g_free(descriptionPtr);
        }
        return descriptionPtr = getStringPtr(localAccessibleActionEvent.result);
      }
    }
    int i = 0;
    Object localObject = getActionIface(paramInt1);
    if ((localObject != null) && (((AtkActionIface)localObject).get_description != 0)) {
      i = ATK.call(((AtkActionIface)localObject).get_description, paramInt1, paramInt2);
    }
    return i;
  }
  
  static int atkAction_get_keybinding(int paramInt1, int paramInt2)
  {
    if (DEBUG) {
      print("-->atkAction_get_keybinding");
    }
    AccessibleObject localAccessibleObject = getAccessibleObject(paramInt1);
    int i = 0;
    AtkActionIface localAtkActionIface = getActionIface(paramInt1);
    if ((localAtkActionIface != null) && (localAtkActionIface.get_keybinding != 0)) {
      i = ATK.call(localAtkActionIface.get_keybinding, paramInt1, paramInt2);
    }
    if (localAccessibleObject != null)
    {
      Accessible localAccessible = localAccessibleObject.accessible;
      Vector localVector = localAccessible.accessibleActionListeners;
      int j = size(localVector);
      Object localObject1;
      int k;
      Object localObject2;
      if (j > 0)
      {
        localObject1 = new AccessibleActionEvent(localAccessible);
        ((AccessibleActionEvent)localObject1).index = paramInt2;
        for (k = 0; k < j; k++)
        {
          localObject2 = (AccessibleActionListener)localVector.elementAt(k);
          ((AccessibleActionListener)localObject2).getKeyBinding((AccessibleActionEvent)localObject1);
        }
        if (((AccessibleActionEvent)localObject1).result != null)
        {
          if (keybindingPtr != -1) {
            OS.g_free(keybindingPtr);
          }
          return keybindingPtr = getStringPtr(((AccessibleActionEvent)localObject1).result);
        }
      }
      localVector = localAccessible.accessibleListeners;
      j = size(localVector);
      if (j > 0)
      {
        localObject1 = new AccessibleEvent(localAccessible);
        ((AccessibleEvent)localObject1).childID = localAccessibleObject.id;
        if (i != 0) {
          ((AccessibleEvent)localObject1).result = getString(i);
        }
        for (k = 0; k < j; k++)
        {
          localObject2 = (AccessibleListener)localVector.elementAt(k);
          ((AccessibleListener)localObject2).getKeyboardShortcut((AccessibleEvent)localObject1);
        }
        if (((AccessibleEvent)localObject1).result != null)
        {
          if (keybindingPtr != -1) {
            OS.g_free(keybindingPtr);
          }
          return keybindingPtr = getStringPtr(((AccessibleEvent)localObject1).result);
        }
      }
    }
    return i;
  }
  
  static int atkAction_get_name(int paramInt1, int paramInt2)
  {
    if (DEBUG) {
      print("-->atkAction_get_name");
    }
    AccessibleObject localAccessibleObject = getAccessibleObject(paramInt1);
    int i = 0;
    AtkActionIface localAtkActionIface = getActionIface(paramInt1);
    if ((localAtkActionIface != null) && (localAtkActionIface.get_name != 0)) {
      i = ATK.call(localAtkActionIface.get_name, paramInt1, paramInt2);
    }
    if (localAccessibleObject != null)
    {
      Accessible localAccessible = localAccessibleObject.accessible;
      Vector localVector = localAccessible.accessibleActionListeners;
      int j = size(localVector);
      Object localObject1;
      int k;
      Object localObject2;
      if (j > 0)
      {
        localObject1 = new AccessibleActionEvent(localAccessible);
        ((AccessibleActionEvent)localObject1).index = paramInt2;
        for (k = 0; k < j; k++)
        {
          localObject2 = (AccessibleActionListener)localVector.elementAt(k);
          ((AccessibleActionListener)localObject2).getName((AccessibleActionEvent)localObject1);
        }
        if (((AccessibleActionEvent)localObject1).result != null)
        {
          if (actionNamePtr != -1) {
            OS.g_free(actionNamePtr);
          }
          return actionNamePtr = getStringPtr(((AccessibleActionEvent)localObject1).result);
        }
      }
      if (paramInt2 == 0)
      {
        localVector = localAccessible.accessibleControlListeners;
        j = size(localVector);
        if (j > 0)
        {
          localObject1 = new AccessibleControlEvent(localAccessible);
          ((AccessibleControlEvent)localObject1).childID = localAccessibleObject.id;
          if (i != 0) {
            ((AccessibleControlEvent)localObject1).result = getString(i);
          }
          for (k = 0; k < j; k++)
          {
            localObject2 = (AccessibleControlListener)localVector.elementAt(k);
            ((AccessibleControlListener)localObject2).getDefaultAction((AccessibleControlEvent)localObject1);
          }
          if (((AccessibleControlEvent)localObject1).result != null)
          {
            if (actionNamePtr != -1) {
              OS.g_free(actionNamePtr);
            }
            return actionNamePtr = getStringPtr(((AccessibleControlEvent)localObject1).result);
          }
        }
      }
    }
    return i;
  }
  
  static AtkComponentIface getComponentIface(int paramInt)
  {
    if (ATK.g_type_is_a(OS.g_type_parent(OS.G_OBJECT_TYPE(paramInt)), ATK.ATK_TYPE_COMPONENT()))
    {
      AtkComponentIface localAtkComponentIface = new AtkComponentIface();
      ATK.memmove(localAtkComponentIface, ATK.g_type_interface_peek_parent(ATK.ATK_COMPONENT_GET_IFACE(paramInt)));
      return localAtkComponentIface;
    }
    return null;
  }
  
  static int atkComponent_get_extents(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6)
  {
    if (DEBUG) {
      print("-->atkComponent_get_extents: " + paramInt1);
    }
    AccessibleObject localAccessibleObject = getAccessibleObject(paramInt1);
    OS.memmove(paramInt2, new int[] { 0 }, 4);
    OS.memmove(paramInt3, new int[] { 0 }, 4);
    OS.memmove(paramInt4, new int[] { 0 }, 4);
    OS.memmove(paramInt5, new int[] { 0 }, 4);
    AtkComponentIface localAtkComponentIface = getComponentIface(paramInt1);
    if ((localAtkComponentIface != null) && (localAtkComponentIface.get_extents != 0)) {
      ATK.call(localAtkComponentIface.get_extents, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6);
    }
    if (localAccessibleObject != null)
    {
      Accessible localAccessible = localAccessibleObject.accessible;
      Vector localVector = localAccessible.accessibleControlListeners;
      int i = size(localVector);
      if (i > 0)
      {
        int[] arrayOfInt1 = new int[1];
        int[] arrayOfInt2 = new int[1];
        int[] arrayOfInt3 = new int[1];
        int[] arrayOfInt4 = new int[1];
        OS.memmove(arrayOfInt1, paramInt2, 4);
        OS.memmove(arrayOfInt2, paramInt3, 4);
        OS.memmove(arrayOfInt3, paramInt4, 4);
        OS.memmove(arrayOfInt4, paramInt5, 4);
        AccessibleControlEvent localAccessibleControlEvent = new AccessibleControlEvent(localAccessible);
        localAccessibleControlEvent.childID = localAccessibleObject.id;
        localAccessibleControlEvent.x = arrayOfInt1[0];
        localAccessibleControlEvent.y = arrayOfInt2[0];
        localAccessibleControlEvent.width = arrayOfInt3[0];
        localAccessibleControlEvent.height = arrayOfInt4[0];
        int[] arrayOfInt5 = new int[1];
        int[] arrayOfInt6 = new int[1];
        if (paramInt6 == 1)
        {
          windowPoint(localAccessibleObject, arrayOfInt5, arrayOfInt6);
          localAccessibleControlEvent.x += arrayOfInt5[0];
          localAccessibleControlEvent.y += arrayOfInt6[0];
        }
        for (int j = 0; j < i; j++)
        {
          AccessibleControlListener localAccessibleControlListener = (AccessibleControlListener)localVector.elementAt(j);
          localAccessibleControlListener.getLocation(localAccessibleControlEvent);
        }
        if (paramInt6 == 1)
        {
          localAccessibleControlEvent.x -= arrayOfInt5[0];
          localAccessibleControlEvent.y -= arrayOfInt6[0];
        }
        OS.memmove(paramInt2, new int[] { localAccessibleControlEvent.x }, 4);
        OS.memmove(paramInt3, new int[] { localAccessibleControlEvent.y }, 4);
        OS.memmove(paramInt4, new int[] { localAccessibleControlEvent.width }, 4);
        OS.memmove(paramInt5, new int[] { localAccessibleControlEvent.height }, 4);
        if (DEBUG) {
          print("--->" + localAccessibleControlEvent.x + "," + localAccessibleControlEvent.y + "," + localAccessibleControlEvent.width + "x" + localAccessibleControlEvent.height);
        }
      }
    }
    return 0;
  }
  
  static int atkComponent_get_position(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    if (DEBUG) {
      print("-->atkComponent_get_position, object: " + paramInt1 + " x: " + paramInt2 + " y: " + paramInt3 + " coord: " + paramInt4);
    }
    AccessibleObject localAccessibleObject = getAccessibleObject(paramInt1);
    OS.memmove(paramInt2, new int[] { 0 }, 4);
    OS.memmove(paramInt3, new int[] { 0 }, 4);
    AtkComponentIface localAtkComponentIface = getComponentIface(paramInt1);
    if ((localAtkComponentIface != null) && (localAtkComponentIface.get_position != 0)) {
      ATK.call(localAtkComponentIface.get_position, paramInt1, paramInt2, paramInt3, paramInt4);
    }
    if (localAccessibleObject != null)
    {
      Accessible localAccessible = localAccessibleObject.accessible;
      Vector localVector = localAccessible.accessibleControlListeners;
      int i = size(localVector);
      if (i > 0)
      {
        int[] arrayOfInt1 = new int[1];
        int[] arrayOfInt2 = new int[1];
        OS.memmove(arrayOfInt1, paramInt2, 4);
        OS.memmove(arrayOfInt2, paramInt3, 4);
        AccessibleControlEvent localAccessibleControlEvent = new AccessibleControlEvent(localAccessible);
        localAccessibleControlEvent.childID = localAccessibleObject.id;
        localAccessibleControlEvent.x = arrayOfInt1[0];
        localAccessibleControlEvent.y = arrayOfInt2[0];
        int[] arrayOfInt3 = new int[1];
        int[] arrayOfInt4 = new int[1];
        if (paramInt4 == 1)
        {
          windowPoint(localAccessibleObject, arrayOfInt3, arrayOfInt4);
          localAccessibleControlEvent.x += arrayOfInt3[0];
          localAccessibleControlEvent.y += arrayOfInt4[0];
        }
        for (int j = 0; j < i; j++)
        {
          AccessibleControlListener localAccessibleControlListener = (AccessibleControlListener)localVector.elementAt(j);
          localAccessibleControlListener.getLocation(localAccessibleControlEvent);
        }
        if (paramInt4 == 1)
        {
          localAccessibleControlEvent.x -= arrayOfInt3[0];
          localAccessibleControlEvent.y -= arrayOfInt4[0];
        }
        OS.memmove(paramInt2, new int[] { localAccessibleControlEvent.x }, 4);
        OS.memmove(paramInt3, new int[] { localAccessibleControlEvent.y }, 4);
      }
    }
    return 0;
  }
  
  static int atkComponent_get_size(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    if (DEBUG) {
      print("-->atkComponent_get_size");
    }
    AccessibleObject localAccessibleObject = getAccessibleObject(paramInt1);
    OS.memmove(paramInt2, new int[] { 0 }, 4);
    OS.memmove(paramInt3, new int[] { 0 }, 4);
    AtkComponentIface localAtkComponentIface = getComponentIface(paramInt1);
    if ((localAtkComponentIface != null) && (localAtkComponentIface.get_size != 0)) {
      ATK.call(localAtkComponentIface.get_size, paramInt1, paramInt2, paramInt3, paramInt4);
    }
    if (localAccessibleObject != null)
    {
      Accessible localAccessible = localAccessibleObject.accessible;
      Vector localVector = localAccessible.accessibleControlListeners;
      int i = size(localVector);
      if (i > 0)
      {
        int[] arrayOfInt1 = new int[1];
        int[] arrayOfInt2 = new int[1];
        OS.memmove(arrayOfInt1, paramInt2, 4);
        OS.memmove(arrayOfInt2, paramInt3, 4);
        AccessibleControlEvent localAccessibleControlEvent = new AccessibleControlEvent(localAccessible);
        localAccessibleControlEvent.childID = localAccessibleObject.id;
        localAccessibleControlEvent.width = arrayOfInt1[0];
        localAccessibleControlEvent.height = arrayOfInt2[0];
        for (int j = 0; j < i; j++)
        {
          AccessibleControlListener localAccessibleControlListener = (AccessibleControlListener)localVector.elementAt(j);
          localAccessibleControlListener.getLocation(localAccessibleControlEvent);
        }
        OS.memmove(paramInt2, new int[] { localAccessibleControlEvent.width }, 4);
        OS.memmove(paramInt3, new int[] { localAccessibleControlEvent.height }, 4);
      }
    }
    return 0;
  }
  
  static int atkComponent_ref_accessible_at_point(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    if (DEBUG) {
      print("-->atkComponent_ref_accessible_at_point: " + paramInt1 + " " + paramInt2 + "," + paramInt3);
    }
    AccessibleObject localAccessibleObject = getAccessibleObject(paramInt1);
    if (localAccessibleObject != null)
    {
      Accessible localAccessible1 = localAccessibleObject.accessible;
      localObject1 = localAccessible1.accessibleControlListeners;
      int j = size((Vector)localObject1);
      if (j > 0)
      {
        AccessibleControlEvent localAccessibleControlEvent = new AccessibleControlEvent(localAccessible1);
        localAccessibleControlEvent.childID = localAccessibleObject.id;
        localAccessibleControlEvent.x = paramInt2;
        localAccessibleControlEvent.y = paramInt3;
        int[] arrayOfInt1 = new int[1];
        int[] arrayOfInt2 = new int[1];
        if (paramInt4 == 1)
        {
          windowPoint(localAccessibleObject, arrayOfInt1, arrayOfInt2);
          localAccessibleControlEvent.x += arrayOfInt1[0];
          localAccessibleControlEvent.y += arrayOfInt2[0];
        }
        for (int k = 0; k < j; k++)
        {
          localObject2 = (AccessibleControlListener)((Vector)localObject1).elementAt(k);
          ((AccessibleControlListener)localObject2).getChildAtPoint(localAccessibleControlEvent);
        }
        if (localAccessibleControlEvent.childID == localAccessibleObject.id) {
          localAccessibleControlEvent.childID = -1;
        }
        Accessible localAccessible2 = localAccessibleControlEvent.accessible;
        Object localObject2 = localAccessible2 != null ? localAccessible2.getAccessibleObject() : localAccessibleObject.getChildByID(localAccessibleControlEvent.childID);
        if (localObject2 != null) {
          return OS.g_object_ref(((AccessibleObject)localObject2).handle);
        }
      }
    }
    int i = 0;
    Object localObject1 = getComponentIface(paramInt1);
    if ((localObject1 != null) && (((AtkComponentIface)localObject1).ref_accessible_at_point != 0)) {
      i = ATK.call(((AtkComponentIface)localObject1).ref_accessible_at_point, paramInt1, paramInt2, paramInt3, paramInt4);
    }
    return i;
  }
  
  static AtkEditableTextIface getEditableTextIface(int paramInt)
  {
    if (ATK.g_type_is_a(OS.g_type_parent(OS.G_OBJECT_TYPE(paramInt)), ATK.ATK_TYPE_EDITABLE_TEXT()))
    {
      AtkEditableTextIface localAtkEditableTextIface = new AtkEditableTextIface();
      ATK.memmove(localAtkEditableTextIface, ATK.g_type_interface_peek_parent(ATK.ATK_EDITABLE_TEXT_GET_IFACE(paramInt)));
      return localAtkEditableTextIface;
    }
    return null;
  }
  
  static int atkEditableText_set_run_attributes(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    if (DEBUG) {
      print("-->atkEditableText_set_run_attributes");
    }
    AccessibleObject localAccessibleObject = getAccessibleObject(paramInt1);
    if (localAccessibleObject != null)
    {
      Accessible localAccessible = localAccessibleObject.accessible;
      localObject1 = localAccessible.accessibleEditableTextListeners;
      int j = size((Vector)localObject1);
      if (j > 0)
      {
        Display localDisplay = localAccessible.control.getDisplay();
        int k = OS.pango_font_description_new();
        int m = 0;
        TextStyle localTextStyle = new TextStyle();
        Object localObject2 = new String[0];
        int n = paramInt2;
        int i1 = OS.g_slist_length(paramInt2);
        Object localObject3;
        for (int i2 = 0; i2 < i1; i2++)
        {
          i3 = OS.g_slist_data(n);
          if (i3 != 0)
          {
            localObject3 = new AtkAttribute();
            ATK.memmove((AtkAttribute)localObject3, i3, AtkAttribute.sizeof);
            String str1 = getString(((AtkAttribute)localObject3).name);
            String str2 = getString(((AtkAttribute)localObject3).value);
            OS.g_free(i3);
            if (DEBUG) {
              print("name=" + str1 + ", value=" + str2);
            }
            String[] arrayOfString = new String[localObject2.length + 2];
            System.arraycopy(localObject2, 0, arrayOfString, 0, localObject2.length);
            arrayOfString[localObject2.length] = str1;
            arrayOfString[(localObject2.length + 1)] = str2;
            localObject2 = arrayOfString;
            try
            {
              if (str1.equals(getString(ATK.atk_text_attribute_get_name(10))))
              {
                localTextStyle.rise = Integer.parseInt(str2);
              }
              else if (str1.equals(getString(ATK.atk_text_attribute_get_name(11))))
              {
                if ((str2.equals("single")) || (str2.equals("low")))
                {
                  localTextStyle.underline = true;
                  localTextStyle.underlineStyle = 0;
                }
                else if (str2.equals("double"))
                {
                  localTextStyle.underline = true;
                  localTextStyle.underlineStyle = 1;
                }
                else if (str2.equals("error"))
                {
                  localTextStyle.underline = true;
                  localTextStyle.underlineStyle = 2;
                }
                else if (str2.equals("squiggle"))
                {
                  localTextStyle.underline = true;
                  localTextStyle.underlineStyle = 3;
                }
              }
              else if (str1.equals(getString(ATK.atk_text_attribute_get_name(12))))
              {
                if ((str2.equals("true")) || (str2.equals("1")) || (str2.equals("single"))) {
                  localTextStyle.strikeout = true;
                }
              }
              else if (str1.equals(getString(ATK.atk_text_attribute_get_name(17))))
              {
                byte[] arrayOfByte = Converter.wcsToMbcs(null, str2, true);
                OS.pango_font_description_set_family(k, arrayOfByte);
                m = 1;
              }
              else if (str1.equals(getString(ATK.atk_text_attribute_get_name(13))))
              {
                float f = Float.parseFloat(str2);
                OS.pango_font_description_set_size(k, (int)(f * 1024.0F));
                m = 1;
              }
              else
              {
                int i4;
                if (str1.equals(getString(ATK.atk_text_attribute_get_name(27))))
                {
                  i4 = -1;
                  if (str2.equals("normal")) {
                    i4 = 0;
                  } else if (str2.equals("italic")) {
                    i4 = 2;
                  } else if (str2.equals("oblique")) {
                    i4 = 1;
                  }
                  if (i4 != -1)
                  {
                    OS.pango_font_description_set_style(k, i4);
                    m = 1;
                  }
                }
                else if (str1.equals(getString(ATK.atk_text_attribute_get_name(26))))
                {
                  i4 = -1;
                  if (str2.equals("normal")) {
                    i4 = 0;
                  } else if (str2.equals("small_caps")) {
                    i4 = 1;
                  }
                  if (i4 != -1)
                  {
                    OS.pango_font_description_set_variant(k, i4);
                    m = 1;
                  }
                }
                else if (str1.equals(getString(ATK.atk_text_attribute_get_name(25))))
                {
                  i4 = -1;
                  if (str2.equals("ultra_condensed")) {
                    i4 = 0;
                  } else if (str2.equals("extra_condensed")) {
                    i4 = 1;
                  } else if (str2.equals("condensed")) {
                    i4 = 2;
                  } else if (str2.equals("semi_condensed")) {
                    i4 = 3;
                  } else if (str2.equals("normal")) {
                    i4 = 4;
                  } else if (str2.equals("semi_expanded")) {
                    i4 = 5;
                  } else if (str2.equals("expanded")) {
                    i4 = 6;
                  } else if (str2.equals("extra_expanded")) {
                    i4 = 7;
                  } else if (str2.equals("ultra_expanded")) {
                    i4 = 8;
                  }
                  if (i4 != -1)
                  {
                    OS.pango_font_description_set_stretch(k, i4);
                    m = 1;
                  }
                }
                else if (str1.equals(getString(ATK.atk_text_attribute_get_name(15))))
                {
                  i4 = Integer.parseInt(str2);
                  OS.pango_font_description_set_weight(k, i4);
                  m = 1;
                }
                else if (str1.equals(getString(ATK.atk_text_attribute_get_name(19))))
                {
                  localTextStyle.foreground = colorFromString(localDisplay, str2);
                }
                else if (str1.equals(getString(ATK.atk_text_attribute_get_name(18))))
                {
                  localTextStyle.background = colorFromString(localDisplay, str2);
                }
              }
            }
            catch (NumberFormatException localNumberFormatException) {}
          }
          n = OS.g_slist_next(n);
        }
        if (m != 0) {
          localTextStyle.font = Font.gtk_new(localDisplay, k);
        }
        AccessibleTextAttributeEvent localAccessibleTextAttributeEvent = new AccessibleTextAttributeEvent(localAccessible);
        localAccessibleTextAttributeEvent.start = paramInt3;
        localAccessibleTextAttributeEvent.end = paramInt4;
        localAccessibleTextAttributeEvent.textStyle = localTextStyle;
        localAccessibleTextAttributeEvent.attributes = ((String[])localObject2);
        for (int i3 = 0; i3 < j; i3++)
        {
          localObject3 = (AccessibleEditableTextListener)((Vector)localObject1).elementAt(i3);
          ((AccessibleEditableTextListener)localObject3).setTextAttributes(localAccessibleTextAttributeEvent);
        }
        if (localTextStyle.font != null) {
          localTextStyle.font.dispose();
        }
        if (localTextStyle.foreground != null) {
          localTextStyle.foreground.dispose();
        }
        if (localTextStyle.background != null) {
          localTextStyle.background.dispose();
        }
        return "OK".equals(localAccessibleTextAttributeEvent.result) ? 1 : 0;
      }
    }
    int i = 0;
    Object localObject1 = getEditableTextIface(paramInt1);
    if ((localObject1 != null) && (((AtkEditableTextIface)localObject1).set_run_attributes != 0)) {
      i = ATK.call(((AtkEditableTextIface)localObject1).set_run_attributes, paramInt1, paramInt2, paramInt3, paramInt4);
    }
    return i;
  }
  
  static Color colorFromString(Display paramDisplay, String paramString)
  {
    try
    {
      int i = paramString.indexOf(',');
      int j = paramString.indexOf(',', i + 1);
      int k = Integer.parseInt(paramString.substring(0, i));
      int m = Integer.parseInt(paramString.substring(i + 1, j));
      int n = Integer.parseInt(paramString.substring(j + 1, paramString.length()));
      return new Color(paramDisplay, k, m, n);
    }
    catch (NumberFormatException localNumberFormatException) {}
    return null;
  }
  
  static int atkEditableText_set_text_contents(int paramInt1, int paramInt2)
  {
    if (DEBUG) {
      print("-->atkEditableText_set_text_contents");
    }
    AccessibleObject localAccessibleObject = getAccessibleObject(paramInt1);
    if (localAccessibleObject != null)
    {
      Accessible localAccessible = localAccessibleObject.accessible;
      localObject = localAccessible.accessibleEditableTextListeners;
      int j = size((Vector)localObject);
      if (j > 0)
      {
        AccessibleEditableTextEvent localAccessibleEditableTextEvent = new AccessibleEditableTextEvent(localAccessible);
        localAccessibleEditableTextEvent.start = 0;
        String str = localAccessibleObject.getText();
        localAccessibleEditableTextEvent.end = (str == null ? 0 : str.length());
        localAccessibleEditableTextEvent.string = getString(paramInt2);
        for (int k = 0; k < j; k++)
        {
          AccessibleEditableTextListener localAccessibleEditableTextListener = (AccessibleEditableTextListener)((Vector)localObject).elementAt(k);
          localAccessibleEditableTextListener.replaceText(localAccessibleEditableTextEvent);
        }
        return "OK".equals(localAccessibleEditableTextEvent.result) ? 1 : 0;
      }
    }
    int i = 0;
    Object localObject = getEditableTextIface(paramInt1);
    if ((localObject != null) && (((AtkEditableTextIface)localObject).set_text_contents != 0)) {
      i = ATK.call(((AtkEditableTextIface)localObject).set_text_contents, paramInt1, paramInt2);
    }
    return i;
  }
  
  static int atkEditableText_insert_text(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    if (DEBUG) {
      print("-->atkEditableText_insert_text");
    }
    AccessibleObject localAccessibleObject = getAccessibleObject(paramInt1);
    if (localAccessibleObject != null)
    {
      Accessible localAccessible = localAccessibleObject.accessible;
      localObject = localAccessible.accessibleEditableTextListeners;
      int j = size((Vector)localObject);
      if (j > 0)
      {
        AccessibleEditableTextEvent localAccessibleEditableTextEvent = new AccessibleEditableTextEvent(localAccessible);
        int[] arrayOfInt = new int[1];
        OS.memmove(arrayOfInt, paramInt4, OS.PTR_SIZEOF);
        localAccessibleEditableTextEvent.start = (localAccessibleEditableTextEvent.end = arrayOfInt[0]);
        localAccessibleEditableTextEvent.string = getString(paramInt2);
        for (int k = 0; k < j; k++)
        {
          AccessibleEditableTextListener localAccessibleEditableTextListener = (AccessibleEditableTextListener)((Vector)localObject).elementAt(k);
          localAccessibleEditableTextListener.replaceText(localAccessibleEditableTextEvent);
        }
        return "OK".equals(localAccessibleEditableTextEvent.result) ? 1 : 0;
      }
    }
    int i = 0;
    Object localObject = getEditableTextIface(paramInt1);
    if ((localObject != null) && (((AtkEditableTextIface)localObject).insert_text != 0)) {
      i = ATK.call(((AtkEditableTextIface)localObject).insert_text, paramInt1, paramInt2, paramInt3, paramInt4);
    }
    return i;
  }
  
  static int atkEditableText_copy_text(int paramInt1, int paramInt2, int paramInt3)
  {
    if (DEBUG) {
      print("-->atkEditableText_copy_text");
    }
    AccessibleObject localAccessibleObject = getAccessibleObject(paramInt1);
    if (localAccessibleObject != null)
    {
      Accessible localAccessible = localAccessibleObject.accessible;
      localObject = localAccessible.accessibleEditableTextListeners;
      int j = size((Vector)localObject);
      if (j > 0)
      {
        AccessibleEditableTextEvent localAccessibleEditableTextEvent = new AccessibleEditableTextEvent(localAccessible);
        localAccessibleEditableTextEvent.start = paramInt2;
        localAccessibleEditableTextEvent.end = paramInt3;
        for (int k = 0; k < j; k++)
        {
          AccessibleEditableTextListener localAccessibleEditableTextListener = (AccessibleEditableTextListener)((Vector)localObject).elementAt(k);
          localAccessibleEditableTextListener.copyText(localAccessibleEditableTextEvent);
        }
        return "OK".equals(localAccessibleEditableTextEvent.result) ? 1 : 0;
      }
    }
    int i = 0;
    Object localObject = getEditableTextIface(paramInt1);
    if ((localObject != null) && (((AtkEditableTextIface)localObject).copy_text != 0)) {
      i = ATK.call(((AtkEditableTextIface)localObject).copy_text, paramInt1, paramInt2, paramInt3);
    }
    return i;
  }
  
  static int atkEditableText_cut_text(int paramInt1, int paramInt2, int paramInt3)
  {
    if (DEBUG) {
      print("-->atkEditableText_cut_text");
    }
    AccessibleObject localAccessibleObject = getAccessibleObject(paramInt1);
    if (localAccessibleObject != null)
    {
      Accessible localAccessible = localAccessibleObject.accessible;
      localObject = localAccessible.accessibleEditableTextListeners;
      int j = size((Vector)localObject);
      if (j > 0)
      {
        AccessibleEditableTextEvent localAccessibleEditableTextEvent = new AccessibleEditableTextEvent(localAccessible);
        localAccessibleEditableTextEvent.start = paramInt2;
        localAccessibleEditableTextEvent.end = paramInt3;
        for (int k = 0; k < j; k++)
        {
          AccessibleEditableTextListener localAccessibleEditableTextListener = (AccessibleEditableTextListener)((Vector)localObject).elementAt(k);
          localAccessibleEditableTextListener.cutText(localAccessibleEditableTextEvent);
        }
        return "OK".equals(localAccessibleEditableTextEvent.result) ? 1 : 0;
      }
    }
    int i = 0;
    Object localObject = getEditableTextIface(paramInt1);
    if ((localObject != null) && (((AtkEditableTextIface)localObject).cut_text != 0)) {
      i = ATK.call(((AtkEditableTextIface)localObject).cut_text, paramInt1, paramInt2, paramInt3);
    }
    return i;
  }
  
  static int atkEditableText_delete_text(int paramInt1, int paramInt2, int paramInt3)
  {
    if (DEBUG) {
      print("-->atkEditableText_delete_text");
    }
    AccessibleObject localAccessibleObject = getAccessibleObject(paramInt1);
    if (localAccessibleObject != null)
    {
      Accessible localAccessible = localAccessibleObject.accessible;
      localObject = localAccessible.accessibleEditableTextListeners;
      int j = size((Vector)localObject);
      if (j > 0)
      {
        AccessibleEditableTextEvent localAccessibleEditableTextEvent = new AccessibleEditableTextEvent(localAccessible);
        localAccessibleEditableTextEvent.start = paramInt2;
        localAccessibleEditableTextEvent.end = paramInt3;
        localAccessibleEditableTextEvent.string = "";
        for (int k = 0; k < j; k++)
        {
          AccessibleEditableTextListener localAccessibleEditableTextListener = (AccessibleEditableTextListener)((Vector)localObject).elementAt(k);
          localAccessibleEditableTextListener.replaceText(localAccessibleEditableTextEvent);
        }
        return "OK".equals(localAccessibleEditableTextEvent.result) ? 1 : 0;
      }
    }
    int i = 0;
    Object localObject = getEditableTextIface(paramInt1);
    if ((localObject != null) && (((AtkEditableTextIface)localObject).delete_text != 0)) {
      i = ATK.call(((AtkEditableTextIface)localObject).delete_text, paramInt1, paramInt2, paramInt3);
    }
    return i;
  }
  
  static int atkEditableText_paste_text(int paramInt1, int paramInt2)
  {
    if (DEBUG) {
      print("-->atkEditableText_paste_text");
    }
    AccessibleObject localAccessibleObject = getAccessibleObject(paramInt1);
    if (localAccessibleObject != null)
    {
      Accessible localAccessible = localAccessibleObject.accessible;
      localObject = localAccessible.accessibleEditableTextListeners;
      int j = size((Vector)localObject);
      if (j > 0)
      {
        AccessibleEditableTextEvent localAccessibleEditableTextEvent = new AccessibleEditableTextEvent(localAccessible);
        localAccessibleEditableTextEvent.start = paramInt2;
        for (int k = 0; k < j; k++)
        {
          AccessibleEditableTextListener localAccessibleEditableTextListener = (AccessibleEditableTextListener)((Vector)localObject).elementAt(k);
          localAccessibleEditableTextListener.pasteText(localAccessibleEditableTextEvent);
        }
        return "OK".equals(localAccessibleEditableTextEvent.result) ? 1 : 0;
      }
    }
    int i = 0;
    Object localObject = getEditableTextIface(paramInt1);
    if ((localObject != null) && (((AtkEditableTextIface)localObject).paste_text != 0)) {
      i = ATK.call(((AtkEditableTextIface)localObject).paste_text, paramInt1, paramInt2);
    }
    return i;
  }
  
  static AtkHypertextIface getHypertextIface(int paramInt)
  {
    if (ATK.g_type_is_a(OS.g_type_parent(OS.G_OBJECT_TYPE(paramInt)), ATK.ATK_TYPE_HYPERTEXT()))
    {
      AtkHypertextIface localAtkHypertextIface = new AtkHypertextIface();
      ATK.memmove(localAtkHypertextIface, ATK.g_type_interface_peek_parent(ATK.ATK_HYPERTEXT_GET_IFACE(paramInt)));
      return localAtkHypertextIface;
    }
    return null;
  }
  
  static int atkHypertext_get_link(int paramInt1, int paramInt2)
  {
    if (DEBUG) {
      print("-->atkHypertext_get_link");
    }
    AccessibleObject localAccessibleObject = getAccessibleObject(paramInt1);
    if (localAccessibleObject != null)
    {
      Accessible localAccessible1 = localAccessibleObject.accessible;
      localObject = localAccessible1.accessibleTextExtendedListeners;
      int j = size((Vector)localObject);
      if (j > 0)
      {
        AccessibleTextEvent localAccessibleTextEvent = new AccessibleTextEvent(localAccessible1);
        localAccessibleTextEvent.index = paramInt2;
        for (int k = 0; k < j; k++)
        {
          AccessibleTextExtendedListener localAccessibleTextExtendedListener = (AccessibleTextExtendedListener)((Vector)localObject).elementAt(k);
          localAccessibleTextExtendedListener.getHyperlink(localAccessibleTextEvent);
        }
        Accessible localAccessible2 = localAccessibleTextEvent.accessible;
        return localAccessible2 != null ? localAccessible2.getAccessibleObject().handle : 0;
      }
    }
    int i = 0;
    Object localObject = getHypertextIface(paramInt1);
    if ((localObject != null) && (((AtkHypertextIface)localObject).get_link != 0)) {
      i = ATK.call(((AtkHypertextIface)localObject).get_link, paramInt1, paramInt2);
    }
    return i;
  }
  
  static int atkHypertext_get_n_links(int paramInt)
  {
    if (DEBUG) {
      print("-->atkHypertext_get_n_links");
    }
    AccessibleObject localAccessibleObject = getAccessibleObject(paramInt);
    if (localAccessibleObject != null)
    {
      Accessible localAccessible = localAccessibleObject.accessible;
      localObject = localAccessible.accessibleTextExtendedListeners;
      int j = size((Vector)localObject);
      if (j > 0)
      {
        AccessibleTextEvent localAccessibleTextEvent = new AccessibleTextEvent(localAccessible);
        for (int k = 0; k < j; k++)
        {
          AccessibleTextExtendedListener localAccessibleTextExtendedListener = (AccessibleTextExtendedListener)((Vector)localObject).elementAt(k);
          localAccessibleTextExtendedListener.getHyperlinkCount(localAccessibleTextEvent);
        }
        return localAccessibleTextEvent.count;
      }
    }
    int i = 0;
    Object localObject = getHypertextIface(paramInt);
    if ((localObject != null) && (((AtkHypertextIface)localObject).get_n_links != 0)) {
      i = ATK.call(((AtkHypertextIface)localObject).get_n_links, paramInt);
    }
    return i;
  }
  
  static int atkHypertext_get_link_index(int paramInt1, int paramInt2)
  {
    if (DEBUG) {
      print("-->atkHypertext_get_link_index");
    }
    AccessibleObject localAccessibleObject = getAccessibleObject(paramInt1);
    if (localAccessibleObject != null)
    {
      Accessible localAccessible = localAccessibleObject.accessible;
      localObject = localAccessible.accessibleTextExtendedListeners;
      int j = size((Vector)localObject);
      if (j > 0)
      {
        AccessibleTextEvent localAccessibleTextEvent = new AccessibleTextEvent(localAccessible);
        localAccessibleTextEvent.offset = paramInt2;
        localAccessibleTextEvent.index = -1;
        for (int k = 0; k < j; k++)
        {
          AccessibleTextExtendedListener localAccessibleTextExtendedListener = (AccessibleTextExtendedListener)((Vector)localObject).elementAt(k);
          localAccessibleTextExtendedListener.getHyperlinkIndex(localAccessibleTextEvent);
        }
        return localAccessibleTextEvent.index;
      }
    }
    int i = 0;
    Object localObject = getHypertextIface(paramInt1);
    if ((localObject != null) && (((AtkHypertextIface)localObject).get_link_index != 0)) {
      i = ATK.call(((AtkHypertextIface)localObject).get_link_index, paramInt1, paramInt2);
    }
    return i;
  }
  
  static AtkObjectClass getObjectClass(int paramInt)
  {
    AtkObjectClass localAtkObjectClass = new AtkObjectClass();
    ATK.memmove(localAtkObjectClass, ATK.g_type_class_peek(OS.g_type_parent(OS.G_OBJECT_TYPE(paramInt))));
    return localAtkObjectClass;
  }
  
  static int atkObject_get_description(int paramInt)
  {
    if (DEBUG) {
      print("-->atkObject_get_description: " + paramInt);
    }
    AccessibleObject localAccessibleObject = getAccessibleObject(paramInt);
    int i = 0;
    AtkObjectClass localAtkObjectClass = getObjectClass(paramInt);
    if (localAtkObjectClass.get_description != 0) {
      i = ATK.call(localAtkObjectClass.get_description, paramInt);
    }
    if (localAccessibleObject != null)
    {
      Accessible localAccessible = localAccessibleObject.accessible;
      Vector localVector = localAccessible.accessibleListeners;
      int j = size(localVector);
      if (j > 0)
      {
        AccessibleEvent localAccessibleEvent = new AccessibleEvent(localAccessible);
        localAccessibleEvent.childID = localAccessibleObject.id;
        if (i != 0) {
          localAccessibleEvent.result = getString(i);
        }
        for (int k = 0; k < j; k++)
        {
          AccessibleListener localAccessibleListener = (AccessibleListener)localVector.elementAt(k);
          localAccessibleListener.getDescription(localAccessibleEvent);
        }
        if (DEBUG) {
          print("---> " + localAccessibleEvent.result);
        }
        if (localAccessibleEvent.result == null) {
          return i;
        }
        if (descriptionPtr != -1) {
          OS.g_free(descriptionPtr);
        }
        return descriptionPtr = getStringPtr(localAccessibleEvent.result);
      }
    }
    return i;
  }
  
  static int atkObject_get_attributes(int paramInt)
  {
    if (DEBUG) {
      print("-->atkObject_get_attributes: " + paramInt);
    }
    AccessibleObject localAccessibleObject = getAccessibleObject(paramInt);
    int i = 0;
    AtkObjectClass localAtkObjectClass = getObjectClass(paramInt);
    if (localAtkObjectClass.get_attributes != 0) {
      i = ATK.call(localAtkObjectClass.get_attributes, paramInt);
    }
    if (localAccessibleObject != null)
    {
      Accessible localAccessible = localAccessibleObject.accessible;
      Vector localVector = localAccessible.accessibleAttributeListeners;
      int j = size(localVector);
      if (j > 0)
      {
        AccessibleAttributeEvent localAccessibleAttributeEvent = new AccessibleAttributeEvent(localAccessible);
        localAccessibleAttributeEvent.topMargin = (localAccessibleAttributeEvent.bottomMargin = localAccessibleAttributeEvent.leftMargin = localAccessibleAttributeEvent.rightMargin = localAccessibleAttributeEvent.alignment = localAccessibleAttributeEvent.indent = localAccessibleAttributeEvent.groupLevel = localAccessibleAttributeEvent.groupCount = localAccessibleAttributeEvent.groupIndex = -1);
        for (int k = 0; k < j; k++)
        {
          AccessibleAttributeListener localAccessibleAttributeListener = (AccessibleAttributeListener)localVector.elementAt(k);
          localAccessibleAttributeListener.getAttributes(localAccessibleAttributeEvent);
        }
        AtkAttribute localAtkAttribute = new AtkAttribute();
        if (localAccessibleAttributeEvent.leftMargin != -1)
        {
          m = OS.g_malloc(AtkAttribute.sizeof);
          localAtkAttribute.name = ATK.g_strdup(ATK.atk_text_attribute_get_name(1));
          localAtkAttribute.value = getStringPtr(String.valueOf(localAccessibleAttributeEvent.leftMargin));
          ATK.memmove(m, localAtkAttribute, AtkAttribute.sizeof);
          i = OS.g_slist_append(i, m);
        }
        if (localAccessibleAttributeEvent.rightMargin != -1)
        {
          m = OS.g_malloc(AtkAttribute.sizeof);
          localAtkAttribute.name = ATK.g_strdup(ATK.atk_text_attribute_get_name(2));
          localAtkAttribute.value = getStringPtr(String.valueOf(localAccessibleAttributeEvent.rightMargin));
          ATK.memmove(m, localAtkAttribute, AtkAttribute.sizeof);
          i = OS.g_slist_append(i, m);
        }
        if (localAccessibleAttributeEvent.topMargin != -1)
        {
          m = OS.g_malloc(AtkAttribute.sizeof);
          localAtkAttribute.name = getStringPtr("top-margin");
          localAtkAttribute.value = getStringPtr(String.valueOf(localAccessibleAttributeEvent.topMargin));
          ATK.memmove(m, localAtkAttribute, AtkAttribute.sizeof);
          i = OS.g_slist_append(i, m);
        }
        if (localAccessibleAttributeEvent.bottomMargin != -1)
        {
          m = OS.g_malloc(AtkAttribute.sizeof);
          localAtkAttribute.name = getStringPtr("bottom-margin");
          localAtkAttribute.value = getStringPtr(String.valueOf(localAccessibleAttributeEvent.bottomMargin));
          ATK.memmove(m, localAtkAttribute, AtkAttribute.sizeof);
          i = OS.g_slist_append(i, m);
        }
        if (localAccessibleAttributeEvent.indent != -1)
        {
          m = OS.g_malloc(AtkAttribute.sizeof);
          localAtkAttribute.name = ATK.g_strdup(ATK.atk_text_attribute_get_name(3));
          localAtkAttribute.value = getStringPtr(String.valueOf(localAccessibleAttributeEvent.indent));
          ATK.memmove(m, localAtkAttribute, AtkAttribute.sizeof);
          i = OS.g_slist_append(i, m);
        }
        if (localAccessibleAttributeEvent.justify)
        {
          m = OS.g_malloc(AtkAttribute.sizeof);
          localAtkAttribute.name = ATK.g_strdup(ATK.atk_text_attribute_get_name(24));
          localAtkAttribute.value = getStringPtr("fill");
          ATK.memmove(m, localAtkAttribute, AtkAttribute.sizeof);
          i = OS.g_slist_append(i, m);
        }
        else if (localAccessibleAttributeEvent.alignment != -1)
        {
          m = OS.g_malloc(AtkAttribute.sizeof);
          localAtkAttribute.name = ATK.g_strdup(ATK.atk_text_attribute_get_name(24));
          String str = "left";
          switch (localAccessibleAttributeEvent.alignment)
          {
          case 16384: 
            str = "left";
            break;
          case 131072: 
            str = "right";
            break;
          case 16777216: 
            str = "center";
          }
          localAtkAttribute.value = getStringPtr(str);
          ATK.memmove(m, localAtkAttribute, AtkAttribute.sizeof);
          i = OS.g_slist_append(i, m);
        }
        int m = localAccessibleAttributeEvent.groupLevel != -1 ? localAccessibleAttributeEvent.groupLevel : 0;
        int n = localAccessibleAttributeEvent.groupCount != -1 ? localAccessibleAttributeEvent.groupCount : 0;
        int i1 = localAccessibleAttributeEvent.groupIndex != -1 ? localAccessibleAttributeEvent.groupIndex : 0;
        int i4;
        if ((n == 0) && (i1 == 0))
        {
          Control localControl1 = localAccessible.control;
          if (((localControl1 instanceof Button)) && ((localControl1.getStyle() & 0x10) != 0))
          {
            Control[] arrayOfControl = localControl1.getParent().getChildren();
            i1 = 1;
            n = 1;
            for (i4 = 0; i4 < arrayOfControl.length; i4++)
            {
              Control localControl2 = arrayOfControl[i4];
              if (((localControl2 instanceof Button)) && ((localControl2.getStyle() & 0x10) != 0)) {
                if (localControl2 == localControl1) {
                  i1 = n;
                } else {
                  n++;
                }
              }
            }
          }
        }
        int i2;
        if (m != 0)
        {
          i2 = OS.g_malloc(AtkAttribute.sizeof);
          localAtkAttribute.name = getStringPtr("level");
          localAtkAttribute.value = getStringPtr(String.valueOf(m));
          ATK.memmove(i2, localAtkAttribute, AtkAttribute.sizeof);
          i = OS.g_slist_append(i, i2);
        }
        if (n != 0)
        {
          i2 = OS.g_malloc(AtkAttribute.sizeof);
          localAtkAttribute.name = getStringPtr("setsize");
          localAtkAttribute.value = getStringPtr(String.valueOf(n));
          ATK.memmove(i2, localAtkAttribute, AtkAttribute.sizeof);
          i = OS.g_slist_append(i, i2);
        }
        if (i1 != 0)
        {
          i2 = OS.g_malloc(AtkAttribute.sizeof);
          localAtkAttribute.name = getStringPtr("posinset");
          localAtkAttribute.value = getStringPtr(String.valueOf(i1));
          ATK.memmove(i2, localAtkAttribute, AtkAttribute.sizeof);
          i = OS.g_slist_append(i, i2);
        }
        if (localAccessibleAttributeEvent.attributes != null)
        {
          i2 = localAccessibleAttributeEvent.attributes.length / 2 * 2;
          for (int i3 = 0; i3 < i2; i3 += 2)
          {
            i4 = OS.g_malloc(AtkAttribute.sizeof);
            localAtkAttribute.name = getStringPtr(localAccessibleAttributeEvent.attributes[i3]);
            localAtkAttribute.value = getStringPtr(localAccessibleAttributeEvent.attributes[(i3 + 1)]);
            ATK.memmove(i4, localAtkAttribute, AtkAttribute.sizeof);
            i = OS.g_slist_append(i, i4);
          }
        }
      }
    }
    return i;
  }
  
  static int atkObject_get_name(int paramInt)
  {
    if (DEBUG) {
      print("-->atkObject_get_name: " + paramInt);
    }
    AccessibleObject localAccessibleObject = getAccessibleObject(paramInt);
    int i = 0;
    AtkObjectClass localAtkObjectClass = getObjectClass(paramInt);
    if (localAtkObjectClass.get_name != 0) {
      i = ATK.call(localAtkObjectClass.get_name, paramInt);
    }
    if (localAccessibleObject != null)
    {
      Accessible localAccessible = localAccessibleObject.accessible;
      Vector localVector = localAccessible.accessibleListeners;
      int j = size(localVector);
      if (j > 0)
      {
        AccessibleEvent localAccessibleEvent = new AccessibleEvent(localAccessible);
        localAccessibleEvent.childID = localAccessibleObject.id;
        if (i != 0) {
          localAccessibleEvent.result = getString(i);
        }
        for (int k = 0; k < j; k++)
        {
          AccessibleListener localAccessibleListener = (AccessibleListener)localVector.elementAt(k);
          localAccessibleListener.getName(localAccessibleEvent);
        }
        if (DEBUG) {
          print("---> " + localAccessibleEvent.result);
        }
        if (localAccessibleEvent.result == null) {
          return i;
        }
        if (namePtr != -1) {
          OS.g_free(namePtr);
        }
        return namePtr = getStringPtr(localAccessibleEvent.result);
      }
    }
    return i;
  }
  
  static int atkObject_get_n_children(int paramInt)
  {
    if (DEBUG) {
      print("-->atkObject_get_n_children: " + paramInt);
    }
    AccessibleObject localAccessibleObject = getAccessibleObject(paramInt);
    int i = 0;
    AtkObjectClass localAtkObjectClass = getObjectClass(paramInt);
    if (localAtkObjectClass.get_n_children != 0) {
      i = ATK.call(localAtkObjectClass.get_n_children, paramInt);
    }
    if ((localAccessibleObject != null) && (localAccessibleObject.id == -1))
    {
      Accessible localAccessible = localAccessibleObject.accessible;
      Vector localVector = localAccessible.accessibleControlListeners;
      int j = size(localVector);
      if (j > 0)
      {
        AccessibleControlEvent localAccessibleControlEvent = new AccessibleControlEvent(localAccessible);
        localAccessibleControlEvent.childID = localAccessibleObject.id;
        localAccessibleControlEvent.detail = i;
        for (int k = 0; k < j; k++)
        {
          AccessibleControlListener localAccessibleControlListener = (AccessibleControlListener)localVector.elementAt(k);
          localAccessibleControlListener.getChildCount(localAccessibleControlEvent);
        }
        if (DEBUG) {
          print("--->" + localAccessibleControlEvent.detail);
        }
        return localAccessibleControlEvent.detail;
      }
    }
    return i;
  }
  
  static int atkObject_get_index_in_parent(int paramInt)
  {
    if (DEBUG) {
      print("-->atkObject_get_index_in_parent: " + paramInt);
    }
    AccessibleObject localAccessibleObject = getAccessibleObject(paramInt);
    if (localAccessibleObject != null)
    {
      localObject = localAccessibleObject.accessible;
      Vector localVector = ((Accessible)localObject).accessibleControlListeners;
      AccessibleControlEvent localAccessibleControlEvent = new AccessibleControlEvent(localObject);
      localAccessibleControlEvent.childID = -5;
      localAccessibleControlEvent.detail = -1;
      for (int j = 0; j < size(localVector); j++)
      {
        AccessibleControlListener localAccessibleControlListener = (AccessibleControlListener)localVector.elementAt(j);
        localAccessibleControlListener.getChild(localAccessibleControlEvent);
      }
      if (localAccessibleControlEvent.detail != -1)
      {
        if (DEBUG) {
          print("---> " + localAccessibleObject.index);
        }
        return localAccessibleControlEvent.detail;
      }
      if (localAccessibleObject.index != -1)
      {
        if (DEBUG) {
          print("---> " + localAccessibleObject.index);
        }
        return localAccessibleObject.index;
      }
    }
    Object localObject = getObjectClass(paramInt);
    if (((AtkObjectClass)localObject).get_index_in_parent == 0) {
      return 0;
    }
    int i = ATK.call(((AtkObjectClass)localObject).get_index_in_parent, paramInt);
    if (DEBUG) {
      print("---*> " + i);
    }
    return i;
  }
  
  static int atkObject_get_parent(int paramInt)
  {
    if (DEBUG) {
      print("-->atkObject_get_parent: " + paramInt);
    }
    AccessibleObject localAccessibleObject = getAccessibleObject(paramInt);
    if ((localAccessibleObject != null) && (localAccessibleObject.parent != null))
    {
      if (DEBUG) {
        print("---> " + localAccessibleObject.parent.accessible.accessibleObject.handle);
      }
      return localAccessibleObject.parent.handle;
    }
    AtkObjectClass localAtkObjectClass = getObjectClass(paramInt);
    if (localAtkObjectClass.get_parent == 0) {
      return 0;
    }
    int i = ATK.call(localAtkObjectClass.get_parent, paramInt);
    if (DEBUG) {
      print("---> " + i);
    }
    return i;
  }
  
  static int atkObject_get_role(int paramInt)
  {
    if (DEBUG) {
      print("-->atkObject_get_role: " + paramInt);
    }
    AccessibleObject localAccessibleObject = getAccessibleObject(paramInt);
    if (localAccessibleObject != null)
    {
      localObject = localAccessibleObject.accessible;
      Vector localVector = ((Accessible)localObject).accessibleControlListeners;
      int i = size(localVector);
      if (i > 0)
      {
        AccessibleControlEvent localAccessibleControlEvent = new AccessibleControlEvent(localObject);
        localAccessibleControlEvent.childID = localAccessibleObject.id;
        localAccessibleControlEvent.detail = -1;
        for (int j = 0; j < i; j++)
        {
          AccessibleControlListener localAccessibleControlListener = (AccessibleControlListener)localVector.elementAt(j);
          localAccessibleControlListener.getRole(localAccessibleControlEvent);
        }
        if (DEBUG) {
          print("---> " + localAccessibleControlEvent.detail);
        }
        if (localAccessibleControlEvent.detail != -1) {
          switch (localAccessibleControlEvent.detail)
          {
          case 44: 
            return 7;
          case 10: 
            return 18;
          case 46: 
            return 11;
          case 18: 
            return 16;
          case 41: 
            return 28;
          case 30: 
            return 60;
          case 33: 
            return 30;
          case 34: 
            return 31;
          case 11: 
            return 32;
          case 2: 
            return 33;
          case 12: 
            return 34;
          case 48: 
            return 41;
          case 43: 
            return 42;
          case 3: 
            return 47;
          case 21: 
            return 49;
          case 51: 
            return 50;
          case 24: 
            return 54;
          case 29: 
            return 55;
          case 25: 
            return 56;
          case 26: 
            return 57;
          case 60: 
            return 37;
          case 37: 
            return 36;
          case 42: 
            return 60;
          case 22: 
            return 62;
          case 13: 
            return 63;
          case 35: 
            return 64;
          case 36: 
            return 31;
          case 45: 
            return 43;
          case 62: 
            return 42;
          case 9: 
            return 68;
          case 28: 
            return ROW_ROLE;
          case 27: 
            return COLUMN_ROLE;
          case 8: 
            return 2;
          case 54: 
            return 3;
          case 1025: 
            return 6;
          case 20: 
            return 38;
          case 52: 
            return 52;
          case 23: 
            return 53;
          case 1027: 
            return 8;
          case 1073: 
            return 44;
          case 61: 
            return 66;
          case 47: 
            return 4;
          case 1029: 
            return 12;
          case 1038: 
            return 70;
          case 1040: 
            return 85;
          case 1043: 
            return 69;
          case 1044: 
            return 81;
          case 1053: 
            return 82;
          case 1054: 
            return 71;
          case 1060: 
            return 83;
          case 15: 
            return 80;
          case 40: 
            return 26;
          }
        }
      }
    }
    Object localObject = getObjectClass(paramInt);
    if (((AtkObjectClass)localObject).get_role == 0) {
      return 0;
    }
    return ATK.call(((AtkObjectClass)localObject).get_role, paramInt);
  }
  
  static int atkObject_ref_child(int paramInt1, int paramInt2)
  {
    if (DEBUG) {
      print("-->atkObject_ref_child: " + paramInt2 + " of: " + paramInt1);
    }
    AccessibleObject localAccessibleObject1 = getAccessibleObject(paramInt1);
    if ((localAccessibleObject1 != null) && (localAccessibleObject1.id == -1))
    {
      localObject1 = localAccessibleObject1.accessible;
      Vector localVector = ((Accessible)localObject1).accessibleControlListeners;
      int i = size(localVector);
      if (i > 0)
      {
        localObject2 = new AccessibleControlEvent(localObject1);
        ((AccessibleControlEvent)localObject2).childID = -4;
        ((AccessibleControlEvent)localObject2).detail = paramInt2;
        for (int j = 0; j < i; j++)
        {
          AccessibleControlListener localAccessibleControlListener = (AccessibleControlListener)localVector.elementAt(j);
          localAccessibleControlListener.getChild((AccessibleControlEvent)localObject2);
        }
        if (((AccessibleControlEvent)localObject2).accessible != null)
        {
          AccessibleObject localAccessibleObject2 = ((AccessibleControlEvent)localObject2).accessible.getAccessibleObject();
          if (localAccessibleObject2 != null) {
            return OS.g_object_ref(localAccessibleObject2.handle);
          }
        }
      }
      localAccessibleObject1.updateChildren();
      Object localObject2 = localAccessibleObject1.getChildByIndex(paramInt2);
      if (localObject2 != null) {
        return OS.g_object_ref(((AccessibleObject)localObject2).handle);
      }
    }
    Object localObject1 = getObjectClass(paramInt1);
    if (((AtkObjectClass)localObject1).ref_child == 0) {
      return 0;
    }
    return ATK.call(((AtkObjectClass)localObject1).ref_child, paramInt1, paramInt2);
  }
  
  static int atkObject_ref_state_set(int paramInt)
  {
    if (DEBUG) {
      print("-->atkObject_ref_state_set: " + paramInt);
    }
    AccessibleObject localAccessibleObject = getAccessibleObject(paramInt);
    int i = 0;
    AtkObjectClass localAtkObjectClass = getObjectClass(paramInt);
    if (localAtkObjectClass.ref_state_set != 0) {
      i = ATK.call(localAtkObjectClass.ref_state_set, paramInt);
    }
    if (localAccessibleObject != null)
    {
      Accessible localAccessible = localAccessibleObject.accessible;
      Vector localVector = localAccessible.accessibleControlListeners;
      int j = size(localVector);
      if (j > 0)
      {
        int k = i;
        AccessibleControlEvent localAccessibleControlEvent = new AccessibleControlEvent(localAccessible);
        localAccessibleControlEvent.childID = localAccessibleObject.id;
        localAccessibleControlEvent.detail = -1;
        for (int m = 0; m < j; m++)
        {
          AccessibleControlListener localAccessibleControlListener = (AccessibleControlListener)localVector.elementAt(m);
          localAccessibleControlListener.getState(localAccessibleControlEvent);
        }
        if (localAccessibleControlEvent.detail != -1)
        {
          m = localAccessibleControlEvent.detail;
          if ((m & 0x800) != 0) {
            ATK.atk_state_set_add_state(k, 3);
          }
          if ((m & 0x10) != 0) {
            ATK.atk_state_set_add_state(k, 4);
          }
          if ((m & 0x200) != 0) {
            ATK.atk_state_set_add_state(k, 9);
          }
          if ((m & 0x100000) != 0) {
            ATK.atk_state_set_add_state(k, 10);
          }
          if ((m & 0x4) != 0) {
            ATK.atk_state_set_add_state(k, 11);
          }
          if ((m & 0x80) != 0) {
            ATK.atk_state_set_add_state(k, 2);
          }
          if ((m & 0x8000) == 0) {
            ATK.atk_state_set_add_state(k, 28);
          }
          if ((m & 0x1000000) != 0) {
            ATK.atk_state_set_add_state(k, 16);
          }
          if ((m & 0x10000) == 0) {
            ATK.atk_state_set_add_state(k, 23);
          }
          if ((m & 0x8) != 0) {
            ATK.atk_state_set_add_state(k, 18);
          }
          if ((m & 0x40) == 0) {
            ATK.atk_state_set_add_state(k, 6);
          }
          if ((m & 0x200000) != 0) {
            ATK.atk_state_set_add_state(k, 20);
          }
          if ((m & 0x2) != 0) {
            ATK.atk_state_set_add_state(k, 21);
          }
          if ((m & 0x20000) != 0) {
            ATK.atk_state_set_add_state(k, 19);
          }
          if ((m & 0x1) == 0) {
            ATK.atk_state_set_add_state(k, 7);
          }
          if ((m & 0x4000000) != 0) {
            ATK.atk_state_set_add_state(k, 1);
          }
          if ((m & 0x8000000) != 0) {
            ATK.atk_state_set_add_state(k, 24);
          }
          if ((m & 0x10000000) != 0) {
            ATK.atk_state_set_add_state(k, 15);
          }
          if ((m & 0x2000000) != 0) {
            ATK.atk_state_set_add_state(k, 32);
          }
          if ((m & 0x20000000) != 0) {
            ATK.atk_state_set_add_state(k, 33);
          }
          if ((m & 0x40000000) != 0) {
            ATK.atk_state_set_add_state(k, 34);
          }
        }
        return k;
      }
    }
    return i;
  }
  
  static AtkSelectionIface getSelectionIface(int paramInt)
  {
    if (ATK.g_type_is_a(OS.g_type_parent(OS.G_OBJECT_TYPE(paramInt)), ATK.ATK_TYPE_SELECTION()))
    {
      AtkSelectionIface localAtkSelectionIface = new AtkSelectionIface();
      ATK.memmove(localAtkSelectionIface, ATK.g_type_interface_peek_parent(ATK.ATK_SELECTION_GET_IFACE(paramInt)));
      return localAtkSelectionIface;
    }
    return null;
  }
  
  static int atkSelection_is_child_selected(int paramInt1, int paramInt2)
  {
    if (DEBUG) {
      print("-->atkSelection_is_child_selected");
    }
    AccessibleObject localAccessibleObject = getAccessibleObject(paramInt1);
    int i = 0;
    AtkSelectionIface localAtkSelectionIface = getSelectionIface(paramInt1);
    if ((localAtkSelectionIface != null) && (localAtkSelectionIface.is_child_selected != 0)) {
      i = ATK.call(localAtkSelectionIface.is_child_selected, paramInt1, paramInt2);
    }
    if (localAccessibleObject != null)
    {
      Accessible localAccessible1 = localAccessibleObject.accessible;
      Vector localVector = localAccessible1.accessibleControlListeners;
      int j = size(localVector);
      if (j > 0)
      {
        AccessibleControlEvent localAccessibleControlEvent = new AccessibleControlEvent(localAccessible1);
        localAccessibleControlEvent.childID = localAccessibleObject.id;
        for (int k = 0; k < j; k++)
        {
          localObject = (AccessibleControlListener)localVector.elementAt(k);
          ((AccessibleControlListener)localObject).getSelection(localAccessibleControlEvent);
        }
        Accessible localAccessible2 = localAccessibleControlEvent.accessible;
        Object localObject = localAccessible2 != null ? localAccessible2.getAccessibleObject() : localAccessibleObject.getChildByID(localAccessibleControlEvent.childID);
        if (localObject != null) {
          return ((AccessibleObject)localObject).index == paramInt2 ? 1 : 0;
        }
      }
    }
    return i;
  }
  
  static int atkSelection_ref_selection(int paramInt1, int paramInt2)
  {
    if (DEBUG) {
      print("-->atkSelection_ref_selection");
    }
    AccessibleObject localAccessibleObject1 = getAccessibleObject(paramInt1);
    int i = 0;
    AtkSelectionIface localAtkSelectionIface = getSelectionIface(paramInt1);
    if ((localAtkSelectionIface != null) && (localAtkSelectionIface.ref_selection != 0)) {
      i = ATK.call(localAtkSelectionIface.ref_selection, paramInt1, paramInt2);
    }
    if (localAccessibleObject1 != null)
    {
      Accessible localAccessible = localAccessibleObject1.accessible;
      Vector localVector = localAccessible.accessibleControlListeners;
      int j = size(localVector);
      if (j > 0)
      {
        AccessibleControlEvent localAccessibleControlEvent = new AccessibleControlEvent(localAccessible);
        localAccessibleControlEvent.childID = localAccessibleObject1.id;
        for (int k = 0; k < j; k++)
        {
          AccessibleControlListener localAccessibleControlListener = (AccessibleControlListener)localVector.elementAt(k);
          localAccessibleControlListener.getSelection(localAccessibleControlEvent);
        }
        AccessibleObject localAccessibleObject2 = localAccessibleObject1.getChildByID(localAccessibleControlEvent.childID);
        if (localAccessibleObject2 != null)
        {
          if (i != 0) {
            OS.g_object_unref(i);
          }
          OS.g_object_ref(localAccessibleObject2.handle);
          return localAccessibleObject2.handle;
        }
      }
    }
    return i;
  }
  
  static AtkTableIface getTableIface(int paramInt)
  {
    if (ATK.g_type_is_a(OS.g_type_parent(OS.G_OBJECT_TYPE(paramInt)), ATK.ATK_TYPE_TABLE()))
    {
      AtkTableIface localAtkTableIface = new AtkTableIface();
      ATK.memmove(localAtkTableIface, ATK.g_type_interface_peek_parent(ATK.ATK_TABLE_GET_IFACE(paramInt)));
      return localAtkTableIface;
    }
    return null;
  }
  
  static int atkTable_ref_at(int paramInt1, int paramInt2, int paramInt3)
  {
    if (DEBUG) {
      print("-->atkTable_ref_at");
    }
    AccessibleObject localAccessibleObject = getAccessibleObject(paramInt1);
    if (localAccessibleObject != null)
    {
      Accessible localAccessible1 = localAccessibleObject.accessible;
      localObject1 = localAccessible1.accessibleTableListeners;
      int j = size((Vector)localObject1);
      if (j > 0)
      {
        AccessibleTableEvent localAccessibleTableEvent = new AccessibleTableEvent(localAccessible1);
        localAccessibleTableEvent.row = paramInt2;
        localAccessibleTableEvent.column = paramInt3;
        Object localObject2;
        for (int k = 0; k < j; k++)
        {
          localObject2 = (AccessibleTableListener)((Vector)localObject1).elementAt(k);
          ((AccessibleTableListener)localObject2).getCell(localAccessibleTableEvent);
        }
        Accessible localAccessible2 = localAccessibleTableEvent.accessible;
        if (localAccessible2 != null)
        {
          localObject2 = localAccessible2.getAccessibleObject();
          OS.g_object_ref(((AccessibleObject)localObject2).handle);
          return ((AccessibleObject)localObject2).handle;
        }
      }
    }
    int i = 0;
    Object localObject1 = getTableIface(paramInt1);
    if ((localObject1 != null) && (((AtkTableIface)localObject1).ref_at != 0)) {
      i = ATK.call(((AtkTableIface)localObject1).ref_at, paramInt1, paramInt2, paramInt3);
    }
    return i;
  }
  
  static int atkTable_get_index_at(int paramInt1, int paramInt2, int paramInt3)
  {
    if (DEBUG) {
      print("-->atkTable_get_index_at");
    }
    AccessibleObject localAccessibleObject = getAccessibleObject(paramInt1);
    if (localAccessibleObject != null)
    {
      Accessible localAccessible1 = localAccessibleObject.accessible;
      localObject = localAccessible1.accessibleTableListeners;
      int j = size((Vector)localObject);
      if (j > 0)
      {
        AccessibleTableEvent localAccessibleTableEvent = new AccessibleTableEvent(localAccessible1);
        localAccessibleTableEvent.row = paramInt2;
        localAccessibleTableEvent.column = paramInt3;
        for (int k = 0; k < j; k++)
        {
          AccessibleTableListener localAccessibleTableListener1 = (AccessibleTableListener)((Vector)localObject).elementAt(k);
          localAccessibleTableListener1.getCell(localAccessibleTableEvent);
        }
        Accessible localAccessible2 = localAccessibleTableEvent.accessible;
        if (localAccessible2 == null) {
          return -1;
        }
        localAccessibleTableEvent = new AccessibleTableEvent(localAccessible1);
        for (int m = 0; m < j; m++)
        {
          AccessibleTableListener localAccessibleTableListener2 = (AccessibleTableListener)((Vector)localObject).elementAt(m);
          localAccessibleTableListener2.getColumnCount(localAccessibleTableEvent);
        }
        return paramInt2 * localAccessibleTableEvent.count + paramInt3;
      }
    }
    int i = 0;
    Object localObject = getTableIface(paramInt1);
    if ((localObject != null) && (((AtkTableIface)localObject).get_index_at != 0)) {
      i = ATK.call(((AtkTableIface)localObject).get_index_at, paramInt1, paramInt2, paramInt3);
    }
    return i;
  }
  
  static int atkTable_get_column_at_index(int paramInt1, int paramInt2)
  {
    if (DEBUG) {
      print("-->atkTable_get_column_at_index: " + paramInt1 + " " + paramInt2);
    }
    AccessibleObject localAccessibleObject = getAccessibleObject(paramInt1);
    if (localAccessibleObject != null)
    {
      Accessible localAccessible = localAccessibleObject.accessible;
      localObject = localAccessible.accessibleTableListeners;
      int j = size((Vector)localObject);
      if (j > 0)
      {
        AccessibleTableEvent localAccessibleTableEvent = new AccessibleTableEvent(localAccessible);
        for (int k = 0; k < j; k++)
        {
          AccessibleTableListener localAccessibleTableListener = (AccessibleTableListener)((Vector)localObject).elementAt(k);
          localAccessibleTableListener.getColumnCount(localAccessibleTableEvent);
        }
        k = localAccessibleTableEvent.count == 0 ? -1 : paramInt2 % localAccessibleTableEvent.count;
        if (DEBUG) {
          print("---> " + k);
        }
        return k;
      }
    }
    int i = 0;
    Object localObject = getTableIface(paramInt1);
    if ((localObject != null) && (((AtkTableIface)localObject).get_column_at_index != 0)) {
      i = ATK.call(((AtkTableIface)localObject).get_column_at_index, paramInt1, paramInt2);
    }
    return i;
  }
  
  static int atkTable_get_row_at_index(int paramInt1, int paramInt2)
  {
    if (DEBUG) {
      print("-->atkTable_get_row_at_index: " + paramInt1 + " " + paramInt2);
    }
    AccessibleObject localAccessibleObject = getAccessibleObject(paramInt1);
    if (localAccessibleObject != null)
    {
      Accessible localAccessible = localAccessibleObject.accessible;
      localObject = localAccessible.accessibleTableListeners;
      int j = size((Vector)localObject);
      if (j > 0)
      {
        AccessibleTableEvent localAccessibleTableEvent = new AccessibleTableEvent(localAccessible);
        for (int k = 0; k < j; k++)
        {
          AccessibleTableListener localAccessibleTableListener = (AccessibleTableListener)((Vector)localObject).elementAt(k);
          localAccessibleTableListener.getColumnCount(localAccessibleTableEvent);
        }
        k = localAccessibleTableEvent.count == 0 ? -1 : paramInt2 / localAccessibleTableEvent.count;
        if (DEBUG) {
          print("---> " + k);
        }
        return k;
      }
    }
    int i = 0;
    Object localObject = getTableIface(paramInt1);
    if ((localObject != null) && (((AtkTableIface)localObject).get_row_at_index != 0)) {
      i = ATK.call(((AtkTableIface)localObject).get_row_at_index, paramInt1, paramInt2);
    }
    return i;
  }
  
  static int atkTable_get_n_columns(int paramInt)
  {
    if (DEBUG) {
      print("-->atkTable_get_n_columns");
    }
    AccessibleObject localAccessibleObject = getAccessibleObject(paramInt);
    int i = 0;
    AtkTableIface localAtkTableIface = getTableIface(paramInt);
    if ((localAtkTableIface != null) && (localAtkTableIface.get_n_columns != 0)) {
      i = ATK.call(localAtkTableIface.get_n_columns, paramInt);
    }
    if (localAccessibleObject != null)
    {
      Accessible localAccessible = localAccessibleObject.accessible;
      Vector localVector = localAccessible.accessibleTableListeners;
      int j = size(localVector);
      if (j > 0)
      {
        AccessibleTableEvent localAccessibleTableEvent = new AccessibleTableEvent(localAccessible);
        localAccessibleTableEvent.count = i;
        for (int k = 0; k < j; k++)
        {
          AccessibleTableListener localAccessibleTableListener = (AccessibleTableListener)localVector.elementAt(k);
          localAccessibleTableListener.getColumnCount(localAccessibleTableEvent);
          i = localAccessibleTableEvent.count;
        }
      }
    }
    return i;
  }
  
  static int atkTable_get_n_rows(int paramInt)
  {
    if (DEBUG) {
      print("-->atkTable_get_n_rows");
    }
    AccessibleObject localAccessibleObject = getAccessibleObject(paramInt);
    int i = 0;
    AtkTableIface localAtkTableIface = getTableIface(paramInt);
    if ((localAtkTableIface != null) && (localAtkTableIface.get_n_rows != 0)) {
      i = ATK.call(localAtkTableIface.get_n_rows, paramInt);
    }
    if (localAccessibleObject != null)
    {
      Accessible localAccessible = localAccessibleObject.accessible;
      Vector localVector = localAccessible.accessibleTableListeners;
      int j = size(localVector);
      if (j > 0)
      {
        AccessibleTableEvent localAccessibleTableEvent = new AccessibleTableEvent(localAccessible);
        localAccessibleTableEvent.count = i;
        for (int k = 0; k < j; k++)
        {
          AccessibleTableListener localAccessibleTableListener = (AccessibleTableListener)localVector.elementAt(k);
          localAccessibleTableListener.getRowCount(localAccessibleTableEvent);
          i = localAccessibleTableEvent.count;
        }
      }
    }
    return i;
  }
  
  static int atkTable_get_column_extent_at(int paramInt1, int paramInt2, int paramInt3)
  {
    if (DEBUG) {
      print("-->atkTable_get_column_extent_at");
    }
    AccessibleObject localAccessibleObject = getAccessibleObject(paramInt1);
    int i = 0;
    AtkTableIface localAtkTableIface = getTableIface(paramInt1);
    if ((localAtkTableIface != null) && (localAtkTableIface.get_column_extent_at != 0)) {
      i = ATK.call(localAtkTableIface.get_column_extent_at, paramInt1, paramInt2, paramInt3);
    }
    if (localAccessibleObject != null)
    {
      Accessible localAccessible1 = localAccessibleObject.accessible;
      Vector localVector = localAccessible1.accessibleTableListeners;
      int j = size(localVector);
      if (j > 0)
      {
        AccessibleTableEvent localAccessibleTableEvent = new AccessibleTableEvent(localAccessible1);
        localAccessibleTableEvent.row = paramInt2;
        localAccessibleTableEvent.column = paramInt3;
        Object localObject;
        for (int k = 0; k < j; k++)
        {
          localObject = (AccessibleTableListener)localVector.elementAt(k);
          ((AccessibleTableListener)localObject).getCell(localAccessibleTableEvent);
        }
        Accessible localAccessible2 = localAccessibleTableEvent.accessible;
        if (localAccessible2 != null)
        {
          localVector = localAccessible2.accessibleTableCellListeners;
          j = size(localVector);
          if (j > 0)
          {
            localObject = new AccessibleTableCellEvent(localAccessible2);
            ((AccessibleTableCellEvent)localObject).count = i;
            for (int m = 0; m < j; m++)
            {
              AccessibleTableCellListener localAccessibleTableCellListener = (AccessibleTableCellListener)localVector.elementAt(m);
              localAccessibleTableCellListener.getColumnSpan((AccessibleTableCellEvent)localObject);
            }
            return ((AccessibleTableCellEvent)localObject).count;
          }
        }
      }
    }
    return i;
  }
  
  static int atkTable_get_row_extent_at(int paramInt1, int paramInt2, int paramInt3)
  {
    if (DEBUG) {
      print("-->atkTable_get_row_extent_at");
    }
    AccessibleObject localAccessibleObject = getAccessibleObject(paramInt1);
    int i = 0;
    AtkTableIface localAtkTableIface = getTableIface(paramInt1);
    if ((localAtkTableIface != null) && (localAtkTableIface.get_row_extent_at != 0)) {
      i = ATK.call(localAtkTableIface.get_row_extent_at, paramInt1, paramInt2, paramInt3);
    }
    if (localAccessibleObject != null)
    {
      Accessible localAccessible1 = localAccessibleObject.accessible;
      Vector localVector = localAccessible1.accessibleTableListeners;
      int j = size(localVector);
      if (j > 0)
      {
        AccessibleTableEvent localAccessibleTableEvent = new AccessibleTableEvent(localAccessible1);
        localAccessibleTableEvent.row = paramInt2;
        localAccessibleTableEvent.column = paramInt3;
        Object localObject;
        for (int k = 0; k < j; k++)
        {
          localObject = (AccessibleTableListener)localVector.elementAt(k);
          ((AccessibleTableListener)localObject).getCell(localAccessibleTableEvent);
        }
        Accessible localAccessible2 = localAccessibleTableEvent.accessible;
        if (localAccessible2 != null)
        {
          localVector = localAccessible2.accessibleTableCellListeners;
          j = size(localVector);
          if (j > 0)
          {
            localObject = new AccessibleTableCellEvent(localAccessible2);
            ((AccessibleTableCellEvent)localObject).count = i;
            for (int m = 0; m < j; m++)
            {
              AccessibleTableCellListener localAccessibleTableCellListener = (AccessibleTableCellListener)localVector.elementAt(m);
              localAccessibleTableCellListener.getRowSpan((AccessibleTableCellEvent)localObject);
            }
            return ((AccessibleTableCellEvent)localObject).count;
          }
        }
      }
    }
    return i;
  }
  
  static int atkTable_get_caption(int paramInt)
  {
    if (DEBUG) {
      print("-->atkTable_get_caption");
    }
    AccessibleObject localAccessibleObject = getAccessibleObject(paramInt);
    if (localAccessibleObject != null)
    {
      Accessible localAccessible1 = localAccessibleObject.accessible;
      localObject = localAccessible1.accessibleTableListeners;
      int j = size((Vector)localObject);
      if (j > 0)
      {
        AccessibleTableEvent localAccessibleTableEvent = new AccessibleTableEvent(localAccessible1);
        for (int k = 0; k < j; k++)
        {
          AccessibleTableListener localAccessibleTableListener = (AccessibleTableListener)((Vector)localObject).elementAt(k);
          localAccessibleTableListener.getCaption(localAccessibleTableEvent);
        }
        Accessible localAccessible2 = localAccessibleTableEvent.accessible;
        if (localAccessible2 != null) {
          return localAccessible2.getAccessibleObject().handle;
        }
      }
    }
    int i = 0;
    Object localObject = getTableIface(paramInt);
    if ((localObject != null) && (((AtkTableIface)localObject).get_caption != 0)) {
      i = ATK.call(((AtkTableIface)localObject).get_caption, paramInt);
    }
    return i;
  }
  
  static int atkTable_get_summary(int paramInt)
  {
    if (DEBUG) {
      print("-->atkTable_get_summary");
    }
    AccessibleObject localAccessibleObject = getAccessibleObject(paramInt);
    if (localAccessibleObject != null)
    {
      Accessible localAccessible1 = localAccessibleObject.accessible;
      localObject = localAccessible1.accessibleTableListeners;
      int j = size((Vector)localObject);
      if (j > 0)
      {
        AccessibleTableEvent localAccessibleTableEvent = new AccessibleTableEvent(localAccessible1);
        for (int k = 0; k < j; k++)
        {
          AccessibleTableListener localAccessibleTableListener = (AccessibleTableListener)((Vector)localObject).elementAt(k);
          localAccessibleTableListener.getSummary(localAccessibleTableEvent);
        }
        Accessible localAccessible2 = localAccessibleTableEvent.accessible;
        if (localAccessible2 != null) {
          return localAccessible2.getAccessibleObject().handle;
        }
      }
    }
    int i = 0;
    Object localObject = getTableIface(paramInt);
    if ((localObject != null) && (((AtkTableIface)localObject).get_summary != 0)) {
      i = ATK.call(((AtkTableIface)localObject).get_summary, paramInt);
    }
    return i;
  }
  
  static int atkTable_get_column_description(int paramInt1, int paramInt2)
  {
    if (DEBUG) {
      print("-->atkTable_get_column_description");
    }
    AccessibleObject localAccessibleObject = getAccessibleObject(paramInt1);
    int i = 0;
    AtkTableIface localAtkTableIface = getTableIface(paramInt1);
    if ((localAtkTableIface != null) && (localAtkTableIface.get_column_description != 0)) {
      i = ATK.call(localAtkTableIface.get_column_description, paramInt1, paramInt2);
    }
    if (localAccessibleObject != null)
    {
      Accessible localAccessible = localAccessibleObject.accessible;
      Vector localVector = localAccessible.accessibleTableListeners;
      int j = size(localVector);
      if (j > 0)
      {
        AccessibleTableEvent localAccessibleTableEvent = new AccessibleTableEvent(localAccessible);
        localAccessibleTableEvent.column = paramInt2;
        if (i != 0) {
          localAccessibleTableEvent.result = getString(i);
        }
        for (int k = 0; k < j; k++)
        {
          AccessibleTableListener localAccessibleTableListener = (AccessibleTableListener)localVector.elementAt(k);
          localAccessibleTableListener.getColumnDescription(localAccessibleTableEvent);
        }
        if (localAccessibleTableEvent.result == null) {
          return i;
        }
        if (descriptionPtr != -1) {
          OS.g_free(descriptionPtr);
        }
        return descriptionPtr = getStringPtr(localAccessibleTableEvent.result);
      }
    }
    return i;
  }
  
  static int atkTable_get_column_header(int paramInt1, int paramInt2)
  {
    if (DEBUG) {
      print("-->atkTable_get_column_header");
    }
    AccessibleObject localAccessibleObject = getAccessibleObject(paramInt1);
    if (localAccessibleObject != null)
    {
      Accessible localAccessible = localAccessibleObject.accessible;
      localObject = localAccessible.accessibleTableListeners;
      int j = size((Vector)localObject);
      if (j > 0)
      {
        AccessibleTableEvent localAccessibleTableEvent = new AccessibleTableEvent(localAccessible);
        for (int k = 0; k < j; k++)
        {
          AccessibleTableListener localAccessibleTableListener = (AccessibleTableListener)((Vector)localObject).elementAt(k);
          localAccessibleTableListener.getRowHeaderCells(localAccessibleTableEvent);
        }
        Accessible[] arrayOfAccessible = localAccessibleTableEvent.accessibles;
        if ((arrayOfAccessible != null) && (0 <= paramInt2) && (paramInt2 < arrayOfAccessible.length)) {
          return arrayOfAccessible[paramInt2].getAccessibleObject().handle;
        }
      }
    }
    int i = 0;
    Object localObject = getTableIface(paramInt1);
    if ((localObject != null) && (((AtkTableIface)localObject).get_column_header != 0)) {
      i = ATK.call(((AtkTableIface)localObject).get_column_header, paramInt1, paramInt2);
    }
    return i;
  }
  
  static int atkTable_get_row_description(int paramInt1, int paramInt2)
  {
    if (DEBUG) {
      print("-->atkTable_get_row_description");
    }
    AccessibleObject localAccessibleObject = getAccessibleObject(paramInt1);
    int i = 0;
    AtkTableIface localAtkTableIface = getTableIface(paramInt1);
    if ((localAtkTableIface != null) && (localAtkTableIface.get_row_description != 0)) {
      i = ATK.call(localAtkTableIface.get_row_description, paramInt1, paramInt2);
    }
    if (localAccessibleObject != null)
    {
      Accessible localAccessible = localAccessibleObject.accessible;
      Vector localVector = localAccessible.accessibleTableListeners;
      int j = size(localVector);
      if (j > 0)
      {
        AccessibleTableEvent localAccessibleTableEvent = new AccessibleTableEvent(localAccessible);
        localAccessibleTableEvent.row = paramInt2;
        if (i != 0) {
          localAccessibleTableEvent.result = getString(i);
        }
        for (int k = 0; k < j; k++)
        {
          AccessibleTableListener localAccessibleTableListener = (AccessibleTableListener)localVector.elementAt(k);
          localAccessibleTableListener.getRowDescription(localAccessibleTableEvent);
        }
        if (localAccessibleTableEvent.result == null) {
          return i;
        }
        if (descriptionPtr != -1) {
          OS.g_free(descriptionPtr);
        }
        return descriptionPtr = getStringPtr(localAccessibleTableEvent.result);
      }
    }
    return i;
  }
  
  static int atkTable_get_row_header(int paramInt1, int paramInt2)
  {
    if (DEBUG) {
      print("-->atkTable_get_row_header");
    }
    AccessibleObject localAccessibleObject = getAccessibleObject(paramInt1);
    if (localAccessibleObject != null)
    {
      Accessible localAccessible = localAccessibleObject.accessible;
      localObject = localAccessible.accessibleTableListeners;
      int j = size((Vector)localObject);
      if (j > 0)
      {
        AccessibleTableEvent localAccessibleTableEvent = new AccessibleTableEvent(localAccessible);
        for (int k = 0; k < j; k++)
        {
          AccessibleTableListener localAccessibleTableListener = (AccessibleTableListener)((Vector)localObject).elementAt(k);
          localAccessibleTableListener.getRowHeaderCells(localAccessibleTableEvent);
        }
        Accessible[] arrayOfAccessible = localAccessibleTableEvent.accessibles;
        if ((arrayOfAccessible != null) && (0 <= paramInt2) && (paramInt2 < arrayOfAccessible.length)) {
          return arrayOfAccessible[paramInt2].getAccessibleObject().handle;
        }
      }
    }
    int i = 0;
    Object localObject = getTableIface(paramInt1);
    if ((localObject != null) && (((AtkTableIface)localObject).get_row_header != 0)) {
      i = ATK.call(((AtkTableIface)localObject).get_row_header, paramInt1, paramInt2);
    }
    return i;
  }
  
  static int atkTable_get_selected_columns(int paramInt1, int paramInt2)
  {
    if (DEBUG) {
      print("-->atkTable_get_selected_columns");
    }
    AccessibleObject localAccessibleObject = getAccessibleObject(paramInt1);
    if (localAccessibleObject != null)
    {
      Accessible localAccessible = localAccessibleObject.accessible;
      localObject = localAccessible.accessibleTableListeners;
      int j = size((Vector)localObject);
      if (j > 0)
      {
        AccessibleTableEvent localAccessibleTableEvent = new AccessibleTableEvent(localAccessible);
        for (int k = 0; k < j; k++)
        {
          AccessibleTableListener localAccessibleTableListener = (AccessibleTableListener)((Vector)localObject).elementAt(k);
          localAccessibleTableListener.getSelectedColumns(localAccessibleTableEvent);
        }
        k = localAccessibleTableEvent.selected != null ? localAccessibleTableEvent.selected.length : 0;
        int m = OS.g_malloc(k * 4);
        if (localAccessibleTableEvent.selected != null) {
          OS.memmove(m, localAccessibleTableEvent.selected, k * 4);
        }
        if (paramInt2 != 0) {
          OS.memmove(paramInt2, new int[] { m }, C.PTR_SIZEOF);
        }
        return k;
      }
    }
    int i = 0;
    Object localObject = getTableIface(paramInt1);
    if ((localObject != null) && (((AtkTableIface)localObject).get_selected_columns != 0)) {
      i = ATK.call(((AtkTableIface)localObject).get_selected_columns, paramInt1, paramInt2);
    }
    return i;
  }
  
  static int atkTable_get_selected_rows(int paramInt1, int paramInt2)
  {
    if (DEBUG) {
      print("-->atkTable_get_selected_rows");
    }
    AccessibleObject localAccessibleObject = getAccessibleObject(paramInt1);
    if (localAccessibleObject != null)
    {
      Accessible localAccessible = localAccessibleObject.accessible;
      localObject = localAccessible.accessibleTableListeners;
      int j = size((Vector)localObject);
      if (j > 0)
      {
        AccessibleTableEvent localAccessibleTableEvent = new AccessibleTableEvent(localAccessible);
        for (int k = 0; k < j; k++)
        {
          AccessibleTableListener localAccessibleTableListener = (AccessibleTableListener)((Vector)localObject).elementAt(k);
          localAccessibleTableListener.getSelectedRows(localAccessibleTableEvent);
        }
        k = localAccessibleTableEvent.selected != null ? localAccessibleTableEvent.selected.length : 0;
        int m = OS.g_malloc(k * 4);
        if (localAccessibleTableEvent.selected != null) {
          OS.memmove(m, localAccessibleTableEvent.selected, k * 4);
        }
        if (paramInt2 != 0) {
          OS.memmove(paramInt2, new int[] { m }, C.PTR_SIZEOF);
        }
        return k;
      }
    }
    int i = 0;
    Object localObject = getTableIface(paramInt1);
    if ((localObject != null) && (((AtkTableIface)localObject).get_selected_rows != 0)) {
      i = ATK.call(((AtkTableIface)localObject).get_selected_rows, paramInt1, paramInt2);
    }
    return i;
  }
  
  static int atkTable_is_column_selected(int paramInt1, int paramInt2)
  {
    if (DEBUG) {
      print("-->atkTable_is_column_selected");
    }
    AccessibleObject localAccessibleObject = getAccessibleObject(paramInt1);
    int i = 0;
    AtkTableIface localAtkTableIface = getTableIface(paramInt1);
    if ((localAtkTableIface != null) && (localAtkTableIface.is_column_selected != 0)) {
      i = ATK.call(localAtkTableIface.is_column_selected, paramInt1, paramInt2);
    }
    if (localAccessibleObject != null)
    {
      Accessible localAccessible = localAccessibleObject.accessible;
      Vector localVector = localAccessible.accessibleTableListeners;
      int j = size(localVector);
      if (j > 0)
      {
        AccessibleTableEvent localAccessibleTableEvent = new AccessibleTableEvent(localAccessible);
        localAccessibleTableEvent.isSelected = (i != 0);
        localAccessibleTableEvent.column = paramInt2;
        for (int k = 0; k < j; k++)
        {
          AccessibleTableListener localAccessibleTableListener = (AccessibleTableListener)localVector.elementAt(k);
          localAccessibleTableListener.isColumnSelected(localAccessibleTableEvent);
        }
        return localAccessibleTableEvent.isSelected ? 1 : 0;
      }
    }
    return i;
  }
  
  static int atkTable_is_row_selected(int paramInt1, int paramInt2)
  {
    if (DEBUG) {
      print("-->atkTable_is_row_selected");
    }
    AccessibleObject localAccessibleObject = getAccessibleObject(paramInt1);
    int i = 0;
    AtkTableIface localAtkTableIface = getTableIface(paramInt1);
    if ((localAtkTableIface != null) && (localAtkTableIface.is_row_selected != 0)) {
      i = ATK.call(localAtkTableIface.is_row_selected, paramInt1, paramInt2);
    }
    if (localAccessibleObject != null)
    {
      Accessible localAccessible = localAccessibleObject.accessible;
      Vector localVector = localAccessible.accessibleTableListeners;
      int j = size(localVector);
      if (j > 0)
      {
        AccessibleTableEvent localAccessibleTableEvent = new AccessibleTableEvent(localAccessible);
        localAccessibleTableEvent.isSelected = (i != 0);
        localAccessibleTableEvent.row = paramInt2;
        for (int k = 0; k < j; k++)
        {
          AccessibleTableListener localAccessibleTableListener = (AccessibleTableListener)localVector.elementAt(k);
          localAccessibleTableListener.isRowSelected(localAccessibleTableEvent);
        }
        return localAccessibleTableEvent.isSelected ? 1 : 0;
      }
    }
    return i;
  }
  
  static int atkTable_is_selected(int paramInt1, int paramInt2, int paramInt3)
  {
    if (DEBUG) {
      print("-->atkTable_is_selected");
    }
    AccessibleObject localAccessibleObject = getAccessibleObject(paramInt1);
    int i = 0;
    AtkTableIface localAtkTableIface = getTableIface(paramInt1);
    if ((localAtkTableIface != null) && (localAtkTableIface.is_selected != 0)) {
      i = ATK.call(localAtkTableIface.is_selected, paramInt1, paramInt2, paramInt3);
    }
    if (localAccessibleObject != null)
    {
      Accessible localAccessible1 = localAccessibleObject.accessible;
      Vector localVector = localAccessible1.accessibleTableListeners;
      int j = size(localVector);
      if (j > 0)
      {
        AccessibleTableEvent localAccessibleTableEvent = new AccessibleTableEvent(localAccessible1);
        localAccessibleTableEvent.row = paramInt2;
        localAccessibleTableEvent.column = paramInt3;
        Object localObject;
        for (int k = 0; k < j; k++)
        {
          localObject = (AccessibleTableListener)localVector.elementAt(k);
          ((AccessibleTableListener)localObject).getCell(localAccessibleTableEvent);
        }
        Accessible localAccessible2 = localAccessibleTableEvent.accessible;
        if (localAccessible2 != null)
        {
          localVector = localAccessible2.accessibleTableCellListeners;
          j = size(localVector);
          if (j > 0)
          {
            localObject = new AccessibleTableCellEvent(localAccessible2);
            ((AccessibleTableCellEvent)localObject).isSelected = (i != 0);
            for (int m = 0; m < j; m++)
            {
              AccessibleTableCellListener localAccessibleTableCellListener = (AccessibleTableCellListener)localVector.elementAt(m);
              localAccessibleTableCellListener.isSelected((AccessibleTableCellEvent)localObject);
            }
            return ((AccessibleTableCellEvent)localObject).isSelected ? 1 : 0;
          }
        }
      }
    }
    return i;
  }
  
  static int atkTable_add_row_selection(int paramInt1, int paramInt2)
  {
    if (DEBUG) {
      print("-->atkTable_add_row_selection");
    }
    AccessibleObject localAccessibleObject = getAccessibleObject(paramInt1);
    if (localAccessibleObject != null)
    {
      Accessible localAccessible = localAccessibleObject.accessible;
      localObject = localAccessible.accessibleTableListeners;
      int j = size((Vector)localObject);
      if (j > 0)
      {
        AccessibleTableEvent localAccessibleTableEvent = new AccessibleTableEvent(localAccessible);
        localAccessibleTableEvent.row = paramInt2;
        for (int k = 0; k < j; k++)
        {
          AccessibleTableListener localAccessibleTableListener = (AccessibleTableListener)((Vector)localObject).elementAt(k);
          localAccessibleTableListener.selectRow(localAccessibleTableEvent);
        }
        return "OK".equals(localAccessibleTableEvent.result) ? 1 : 0;
      }
    }
    int i = 0;
    Object localObject = getTableIface(paramInt1);
    if ((localObject != null) && (((AtkTableIface)localObject).add_row_selection != 0)) {
      i = ATK.call(((AtkTableIface)localObject).add_row_selection, paramInt1, paramInt2);
    }
    return i;
  }
  
  static int atkTable_remove_row_selection(int paramInt1, int paramInt2)
  {
    if (DEBUG) {
      print("-->atkTable_remove_row_selection");
    }
    AccessibleObject localAccessibleObject = getAccessibleObject(paramInt1);
    if (localAccessibleObject != null)
    {
      Accessible localAccessible = localAccessibleObject.accessible;
      localObject = localAccessible.accessibleTableListeners;
      int j = size((Vector)localObject);
      if (j > 0)
      {
        AccessibleTableEvent localAccessibleTableEvent = new AccessibleTableEvent(localAccessible);
        localAccessibleTableEvent.row = paramInt2;
        for (int k = 0; k < j; k++)
        {
          AccessibleTableListener localAccessibleTableListener = (AccessibleTableListener)((Vector)localObject).elementAt(k);
          localAccessibleTableListener.deselectRow(localAccessibleTableEvent);
        }
        return "OK".equals(localAccessibleTableEvent.result) ? 1 : 0;
      }
    }
    int i = 0;
    Object localObject = getTableIface(paramInt1);
    if ((localObject != null) && (((AtkTableIface)localObject).remove_row_selection != 0)) {
      i = ATK.call(((AtkTableIface)localObject).remove_row_selection, paramInt1, paramInt2);
    }
    return i;
  }
  
  static int atkTable_add_column_selection(int paramInt1, int paramInt2)
  {
    if (DEBUG) {
      print("-->atkTable_add_column_selection");
    }
    AccessibleObject localAccessibleObject = getAccessibleObject(paramInt1);
    if (localAccessibleObject != null)
    {
      Accessible localAccessible = localAccessibleObject.accessible;
      localObject = localAccessible.accessibleTableListeners;
      int j = size((Vector)localObject);
      if (j > 0)
      {
        AccessibleTableEvent localAccessibleTableEvent = new AccessibleTableEvent(localAccessible);
        localAccessibleTableEvent.column = paramInt2;
        for (int k = 0; k < j; k++)
        {
          AccessibleTableListener localAccessibleTableListener = (AccessibleTableListener)((Vector)localObject).elementAt(k);
          localAccessibleTableListener.selectColumn(localAccessibleTableEvent);
        }
        return "OK".equals(localAccessibleTableEvent.result) ? 1 : 0;
      }
    }
    int i = 0;
    Object localObject = getTableIface(paramInt1);
    if ((localObject != null) && (((AtkTableIface)localObject).add_column_selection != 0)) {
      i = ATK.call(((AtkTableIface)localObject).add_column_selection, paramInt1, paramInt2);
    }
    return i;
  }
  
  static int atkTable_remove_column_selection(int paramInt1, int paramInt2)
  {
    if (DEBUG) {
      print("-->atkTable_remove_column_selection");
    }
    AccessibleObject localAccessibleObject = getAccessibleObject(paramInt1);
    if (localAccessibleObject != null)
    {
      Accessible localAccessible = localAccessibleObject.accessible;
      localObject = localAccessible.accessibleTableListeners;
      int j = size((Vector)localObject);
      if (j > 0)
      {
        AccessibleTableEvent localAccessibleTableEvent = new AccessibleTableEvent(localAccessible);
        localAccessibleTableEvent.column = paramInt2;
        for (int k = 0; k < j; k++)
        {
          AccessibleTableListener localAccessibleTableListener = (AccessibleTableListener)((Vector)localObject).elementAt(k);
          localAccessibleTableListener.deselectColumn(localAccessibleTableEvent);
        }
        return "OK".equals(localAccessibleTableEvent.result) ? 1 : 0;
      }
    }
    int i = 0;
    Object localObject = getTableIface(paramInt1);
    if ((localObject != null) && (((AtkTableIface)localObject).remove_column_selection != 0)) {
      i = ATK.call(((AtkTableIface)localObject).remove_column_selection, paramInt1, paramInt2);
    }
    return i;
  }
  
  static AtkTextIface getTextIface(int paramInt)
  {
    if (ATK.g_type_is_a(OS.g_type_parent(OS.G_OBJECT_TYPE(paramInt)), ATK.ATK_TYPE_TEXT()))
    {
      AtkTextIface localAtkTextIface = new AtkTextIface();
      ATK.memmove(localAtkTextIface, ATK.g_type_interface_peek_parent(ATK.ATK_TEXT_GET_IFACE(paramInt)));
      return localAtkTextIface;
    }
    return null;
  }
  
  static int atkText_get_character_extents(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7)
  {
    if (DEBUG) {
      print("-->atkText_get_character_extents");
    }
    AccessibleObject localAccessibleObject = getAccessibleObject(paramInt1);
    if (localAccessibleObject != null)
    {
      localObject1 = localAccessibleObject.accessible;
      Vector localVector = ((Accessible)localObject1).accessibleTextExtendedListeners;
      int i = size(localVector);
      if (i > 0)
      {
        AccessibleTextEvent localAccessibleTextEvent = new AccessibleTextEvent(localObject1);
        localAccessibleTextEvent.start = paramInt2;
        localAccessibleTextEvent.end = (paramInt2 + 1);
        for (int j = 0; j < i; j++)
        {
          localObject2 = (AccessibleTextExtendedListener)localVector.elementAt(j);
          ((AccessibleTextExtendedListener)localObject2).getTextBounds(localAccessibleTextEvent);
        }
        int[] arrayOfInt = new int[1];
        Object localObject2 = new int[1];
        if (paramInt7 == 1)
        {
          windowPoint(localAccessibleObject, arrayOfInt, (int[])localObject2);
          localAccessibleTextEvent.x -= arrayOfInt[0];
          localAccessibleTextEvent.y -= localObject2[0];
        }
        OS.memmove(paramInt3, new int[] { localAccessibleTextEvent.x }, 4);
        OS.memmove(paramInt4, new int[] { localAccessibleTextEvent.y }, 4);
        OS.memmove(paramInt5, new int[] { localAccessibleTextEvent.width }, 4);
        OS.memmove(paramInt6, new int[] { localAccessibleTextEvent.height }, 4);
        return 0;
      }
    }
    Object localObject1 = getTextIface(paramInt1);
    if ((localObject1 != null) && (((AtkTextIface)localObject1).get_character_extents != 0)) {
      ATK.call(((AtkTextIface)localObject1).get_character_extents, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7);
    }
    return 0;
  }
  
  static String getString(int paramInt)
  {
    int i = OS.strlen(paramInt);
    byte[] arrayOfByte = new byte[i];
    OS.memmove(arrayOfByte, paramInt, i);
    return new String(Converter.mbcsToWcs(null, arrayOfByte));
  }
  
  static int getStringPtr(String paramString)
  {
    byte[] arrayOfByte = Converter.wcsToMbcs(null, paramString != null ? paramString : "", true);
    int i = OS.g_malloc(arrayOfByte.length);
    OS.memmove(i, arrayOfByte, arrayOfByte.length);
    return i;
  }
  
  static int atkText_get_range_extents(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
  {
    if (DEBUG) {
      print("-->atkText_get_range_extents");
    }
    AccessibleObject localAccessibleObject = getAccessibleObject(paramInt1);
    if (localAccessibleObject != null)
    {
      localObject1 = localAccessibleObject.accessible;
      Vector localVector = ((Accessible)localObject1).accessibleTextExtendedListeners;
      int i = size(localVector);
      if (i > 0)
      {
        AccessibleTextEvent localAccessibleTextEvent = new AccessibleTextEvent(localObject1);
        localAccessibleTextEvent.start = paramInt2;
        localAccessibleTextEvent.end = paramInt3;
        for (int j = 0; j < i; j++)
        {
          localObject2 = (AccessibleTextExtendedListener)localVector.elementAt(j);
          ((AccessibleTextExtendedListener)localObject2).getTextBounds(localAccessibleTextEvent);
        }
        int[] arrayOfInt = new int[1];
        Object localObject2 = new int[1];
        if (paramInt4 == 1)
        {
          windowPoint(localAccessibleObject, arrayOfInt, (int[])localObject2);
          localAccessibleTextEvent.x -= arrayOfInt[0];
          localAccessibleTextEvent.y -= localObject2[0];
        }
        AtkTextRectangle localAtkTextRectangle = new AtkTextRectangle();
        localAtkTextRectangle.x = localAccessibleTextEvent.x;
        localAtkTextRectangle.y = localAccessibleTextEvent.y;
        localAtkTextRectangle.width = localAccessibleTextEvent.width;
        localAtkTextRectangle.height = localAccessibleTextEvent.height;
        ATK.memmove(paramInt5, localAtkTextRectangle, AtkTextRectangle.sizeof);
        return 0;
      }
    }
    Object localObject1 = getTextIface(paramInt1);
    if ((localObject1 != null) && (((AtkTextIface)localObject1).get_range_extents != 0)) {
      ATK.call(((AtkTextIface)localObject1).get_range_extents, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
    }
    return 0;
  }
  
  static int atkText_get_run_attributes(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    if (DEBUG) {
      print("-->atkText_get_run_attributes");
    }
    AccessibleObject localAccessibleObject = getAccessibleObject(paramInt1);
    if (localAccessibleObject != null)
    {
      Accessible localAccessible = localAccessibleObject.accessible;
      localObject = localAccessible.accessibleAttributeListeners;
      int j = size((Vector)localObject);
      if (j > 0)
      {
        AccessibleTextAttributeEvent localAccessibleTextAttributeEvent = new AccessibleTextAttributeEvent(localAccessible);
        localAccessibleTextAttributeEvent.offset = paramInt2;
        for (int k = 0; k < j; k++)
        {
          AccessibleAttributeListener localAccessibleAttributeListener = (AccessibleAttributeListener)((Vector)localObject).elementAt(k);
          localAccessibleAttributeListener.getTextAttributes(localAccessibleTextAttributeEvent);
        }
        OS.memmove(paramInt3, new int[] { localAccessibleTextAttributeEvent.start }, 4);
        OS.memmove(paramInt4, new int[] { localAccessibleTextAttributeEvent.end }, 4);
        TextStyle localTextStyle = localAccessibleTextAttributeEvent.textStyle;
        int m = 0;
        AtkAttribute localAtkAttribute = new AtkAttribute();
        int i4;
        if (localTextStyle != null)
        {
          int n;
          if (localTextStyle.rise != 0)
          {
            n = OS.g_malloc(AtkAttribute.sizeof);
            localAtkAttribute.name = ATK.g_strdup(ATK.atk_text_attribute_get_name(10));
            localAtkAttribute.value = getStringPtr(String.valueOf(localTextStyle.rise));
            ATK.memmove(n, localAtkAttribute, AtkAttribute.sizeof);
            m = OS.g_slist_append(m, n);
          }
          if (localTextStyle.underline)
          {
            n = OS.g_malloc(AtkAttribute.sizeof);
            localAtkAttribute.name = ATK.g_strdup(ATK.atk_text_attribute_get_name(11));
            String str = "none";
            switch (localTextStyle.underlineStyle)
            {
            case 1: 
              str = "double";
              break;
            case 0: 
              str = "single";
              break;
            case 2: 
              str = "error";
              break;
            case 3: 
              str = "squiggle";
            }
            localAtkAttribute.value = getStringPtr(str);
            ATK.memmove(n, localAtkAttribute, AtkAttribute.sizeof);
            m = OS.g_slist_append(m, n);
          }
          if (localTextStyle.strikeout)
          {
            n = OS.g_malloc(AtkAttribute.sizeof);
            localAtkAttribute.name = ATK.g_strdup(ATK.atk_text_attribute_get_name(12));
            localAtkAttribute.value = getStringPtr("1");
            ATK.memmove(n, localAtkAttribute, AtkAttribute.sizeof);
            m = OS.g_slist_append(m, n);
          }
          Font localFont = localTextStyle.font;
          if ((localFont != null) && (!localFont.isDisposed()))
          {
            int i2 = OS.g_malloc(AtkAttribute.sizeof);
            localAtkAttribute.name = ATK.g_strdup(ATK.atk_text_attribute_get_name(17));
            localAtkAttribute.value = ATK.g_strdup(OS.pango_font_description_get_family(localFont.handle));
            ATK.memmove(i2, localAtkAttribute, AtkAttribute.sizeof);
            m = OS.g_slist_append(m, i2);
            i2 = OS.g_malloc(AtkAttribute.sizeof);
            localAtkAttribute.name = ATK.g_strdup(ATK.atk_text_attribute_get_name(13));
            localAtkAttribute.value = getStringPtr(String.valueOf(OS.pango_font_description_get_size(localFont.handle) / 1024));
            ATK.memmove(i2, localAtkAttribute, AtkAttribute.sizeof);
            m = OS.g_slist_append(m, i2);
            i2 = OS.g_malloc(AtkAttribute.sizeof);
            localAtkAttribute.name = ATK.g_strdup(ATK.atk_text_attribute_get_name(27));
            localAtkAttribute.value = ATK.g_strdup(ATK.atk_text_attribute_get_value(27, OS.pango_font_description_get_style(localFont.handle)));
            ATK.memmove(i2, localAtkAttribute, AtkAttribute.sizeof);
            m = OS.g_slist_append(m, i2);
            i2 = OS.g_malloc(AtkAttribute.sizeof);
            localAtkAttribute.name = ATK.g_strdup(ATK.atk_text_attribute_get_name(26));
            localAtkAttribute.value = ATK.g_strdup(ATK.atk_text_attribute_get_value(26, OS.pango_font_description_get_variant(localFont.handle)));
            ATK.memmove(i2, localAtkAttribute, AtkAttribute.sizeof);
            m = OS.g_slist_append(m, i2);
            i2 = OS.g_malloc(AtkAttribute.sizeof);
            localAtkAttribute.name = ATK.g_strdup(ATK.atk_text_attribute_get_name(25));
            localAtkAttribute.value = ATK.g_strdup(ATK.atk_text_attribute_get_value(25, OS.pango_font_description_get_stretch(localFont.handle)));
            ATK.memmove(i2, localAtkAttribute, AtkAttribute.sizeof);
            m = OS.g_slist_append(m, i2);
            i2 = OS.g_malloc(AtkAttribute.sizeof);
            localAtkAttribute.name = ATK.g_strdup(ATK.atk_text_attribute_get_name(15));
            localAtkAttribute.value = getStringPtr(String.valueOf(OS.pango_font_description_get_weight(localFont.handle)));
            ATK.memmove(i2, localAtkAttribute, AtkAttribute.sizeof);
            m = OS.g_slist_append(m, i2);
          }
          Color localColor = localTextStyle.foreground;
          if ((localColor != null) && (!localColor.isDisposed()))
          {
            i4 = OS.g_malloc(AtkAttribute.sizeof);
            localAtkAttribute.name = ATK.g_strdup(ATK.atk_text_attribute_get_name(19));
            localAtkAttribute.value = getStringPtr((localColor.handle.red & 0xFFFF) + "," + (localColor.handle.blue & 0xFFFF) + "," + (localColor.handle.blue & 0xFFFF));
            ATK.memmove(i4, localAtkAttribute, AtkAttribute.sizeof);
            m = OS.g_slist_append(m, i4);
          }
          localColor = localTextStyle.background;
          if ((localColor != null) && (!localColor.isDisposed()))
          {
            i4 = OS.g_malloc(AtkAttribute.sizeof);
            localAtkAttribute.name = ATK.g_strdup(ATK.atk_text_attribute_get_name(18));
            localAtkAttribute.value = getStringPtr((localColor.handle.red & 0xFFFF) + "," + (localColor.handle.blue & 0xFFFF) + "," + (localColor.handle.blue & 0xFFFF));
            ATK.memmove(i4, localAtkAttribute, AtkAttribute.sizeof);
            m = OS.g_slist_append(m, i4);
          }
        }
        if (localAccessibleTextAttributeEvent.attributes != null)
        {
          int i1 = localAccessibleTextAttributeEvent.attributes.length / 2 * 2;
          for (int i3 = 0; i3 < i1; i3 += 2)
          {
            i4 = OS.g_malloc(AtkAttribute.sizeof);
            localAtkAttribute.name = getStringPtr(localAccessibleTextAttributeEvent.attributes[i3]);
            localAtkAttribute.value = getStringPtr(localAccessibleTextAttributeEvent.attributes[(i3 + 1)]);
            ATK.memmove(i4, localAtkAttribute, AtkAttribute.sizeof);
            m = OS.g_slist_append(m, i4);
          }
        }
        return m;
      }
    }
    int i = 0;
    Object localObject = getTextIface(paramInt1);
    if ((localObject != null) && (((AtkTextIface)localObject).get_run_attributes != 0)) {
      i = ATK.call(((AtkTextIface)localObject).get_run_attributes, paramInt1, paramInt2, paramInt3, paramInt4);
    }
    return i;
  }
  
  static int atkText_get_offset_at_point(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    if (DEBUG) {
      print("-->atkText_get_offset_at_point");
    }
    AccessibleObject localAccessibleObject = getAccessibleObject(paramInt1);
    if (localAccessibleObject != null)
    {
      Accessible localAccessible = localAccessibleObject.accessible;
      localObject = localAccessible.accessibleTextExtendedListeners;
      int j = size((Vector)localObject);
      if (j > 0)
      {
        AccessibleTextEvent localAccessibleTextEvent = new AccessibleTextEvent(localAccessible);
        localAccessibleTextEvent.x = paramInt2;
        localAccessibleTextEvent.y = paramInt3;
        int[] arrayOfInt1 = new int[1];
        int[] arrayOfInt2 = new int[1];
        if (paramInt4 == 1)
        {
          windowPoint(localAccessibleObject, arrayOfInt1, arrayOfInt2);
          localAccessibleTextEvent.x += arrayOfInt1[0];
          localAccessibleTextEvent.y += arrayOfInt2[0];
        }
        for (int k = 0; k < j; k++)
        {
          AccessibleTextExtendedListener localAccessibleTextExtendedListener = (AccessibleTextExtendedListener)((Vector)localObject).elementAt(k);
          localAccessibleTextExtendedListener.getOffsetAtPoint(localAccessibleTextEvent);
        }
        return localAccessibleTextEvent.offset;
      }
    }
    int i = 0;
    Object localObject = getTextIface(paramInt1);
    if ((localObject != null) && (((AtkTextIface)localObject).get_offset_at_point != 0)) {
      i = ATK.call(((AtkTextIface)localObject).get_offset_at_point, paramInt1, paramInt2, paramInt3, paramInt4);
    }
    return i;
  }
  
  static int atkText_add_selection(int paramInt1, int paramInt2, int paramInt3)
  {
    if (DEBUG) {
      print("-->atkText_add_selection");
    }
    AccessibleObject localAccessibleObject = getAccessibleObject(paramInt1);
    if (localAccessibleObject != null)
    {
      Accessible localAccessible = localAccessibleObject.accessible;
      localObject = localAccessible.accessibleTextExtendedListeners;
      int j = size((Vector)localObject);
      if (j > 0)
      {
        AccessibleTextEvent localAccessibleTextEvent = new AccessibleTextEvent(localAccessible);
        localAccessibleTextEvent.start = paramInt2;
        localAccessibleTextEvent.end = paramInt3;
        for (int k = 0; k < j; k++)
        {
          AccessibleTextExtendedListener localAccessibleTextExtendedListener = (AccessibleTextExtendedListener)((Vector)localObject).elementAt(k);
          localAccessibleTextExtendedListener.addSelection(localAccessibleTextEvent);
        }
        return "OK".equals(localAccessibleTextEvent.result) ? 1 : 0;
      }
    }
    int i = 0;
    Object localObject = getTextIface(paramInt1);
    if ((localObject != null) && (((AtkTextIface)localObject).add_selection != 0)) {
      i = ATK.call(((AtkTextIface)localObject).add_selection, paramInt1, paramInt2, paramInt3);
    }
    return i;
  }
  
  static int atkText_remove_selection(int paramInt1, int paramInt2)
  {
    if (DEBUG) {
      print("-->atkText_remove_selection");
    }
    AccessibleObject localAccessibleObject = getAccessibleObject(paramInt1);
    if (localAccessibleObject != null)
    {
      Accessible localAccessible = localAccessibleObject.accessible;
      localObject = localAccessible.accessibleTextExtendedListeners;
      int j = size((Vector)localObject);
      if (j > 0)
      {
        AccessibleTextEvent localAccessibleTextEvent = new AccessibleTextEvent(localAccessible);
        localAccessibleTextEvent.index = paramInt2;
        for (int k = 0; k < j; k++)
        {
          AccessibleTextExtendedListener localAccessibleTextExtendedListener = (AccessibleTextExtendedListener)((Vector)localObject).elementAt(k);
          localAccessibleTextExtendedListener.removeSelection(localAccessibleTextEvent);
        }
        return "OK".equals(localAccessibleTextEvent.result) ? 1 : 0;
      }
    }
    int i = 0;
    Object localObject = getTextIface(paramInt1);
    if ((localObject != null) && (((AtkTextIface)localObject).remove_selection != 0)) {
      i = ATK.call(((AtkTextIface)localObject).remove_selection, paramInt1, paramInt2);
    }
    return i;
  }
  
  static int atkText_set_caret_offset(int paramInt1, int paramInt2)
  {
    if (DEBUG) {
      print("-->atkText_set_caret_offset");
    }
    AccessibleObject localAccessibleObject = getAccessibleObject(paramInt1);
    if (localAccessibleObject != null)
    {
      localObject = localAccessibleObject.accessible;
      Vector localVector = ((Accessible)localObject).accessibleTextExtendedListeners;
      int i = size(localVector);
      if (i > 0)
      {
        AccessibleTextEvent localAccessibleTextEvent = new AccessibleTextEvent(localObject);
        localAccessibleTextEvent.offset = paramInt2;
        for (int j = 0; j < i; j++)
        {
          AccessibleTextExtendedListener localAccessibleTextExtendedListener = (AccessibleTextExtendedListener)localVector.elementAt(j);
          localAccessibleTextExtendedListener.setCaretOffset(localAccessibleTextEvent);
        }
        return "OK".equals(localAccessibleTextEvent.result) ? 1 : 0;
      }
    }
    Object localObject = getTextIface(paramInt1);
    if ((localObject != null) && (((AtkTextIface)localObject).set_caret_offset != 0)) {
      return ATK.call(((AtkTextIface)localObject).set_caret_offset, paramInt1, paramInt2);
    }
    return 0;
  }
  
  static int atkText_set_selection(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    if (DEBUG) {
      print("-->atkText_set_selection");
    }
    AccessibleObject localAccessibleObject = getAccessibleObject(paramInt1);
    if (localAccessibleObject != null)
    {
      Accessible localAccessible = localAccessibleObject.accessible;
      localObject = localAccessible.accessibleTextExtendedListeners;
      int j = size((Vector)localObject);
      if (j > 0)
      {
        AccessibleTextEvent localAccessibleTextEvent = new AccessibleTextEvent(localAccessible);
        localAccessibleTextEvent.index = paramInt2;
        localAccessibleTextEvent.start = paramInt3;
        localAccessibleTextEvent.end = paramInt4;
        for (int k = 0; k < j; k++)
        {
          AccessibleTextExtendedListener localAccessibleTextExtendedListener = (AccessibleTextExtendedListener)((Vector)localObject).elementAt(k);
          localAccessibleTextExtendedListener.setSelection(localAccessibleTextEvent);
        }
        return "OK".equals(localAccessibleTextEvent.result) ? 1 : 0;
      }
    }
    int i = 0;
    Object localObject = getTextIface(paramInt1);
    if ((localObject != null) && (((AtkTextIface)localObject).set_selection != 0)) {
      i = ATK.call(((AtkTextIface)localObject).set_selection, paramInt1, paramInt2, paramInt3, paramInt4);
    }
    return i;
  }
  
  static int atkText_get_caret_offset(int paramInt)
  {
    if (DEBUG) {
      print("-->atkText_get_caret_offset");
    }
    AccessibleObject localAccessibleObject = getAccessibleObject(paramInt);
    int i = 0;
    AtkTextIface localAtkTextIface = getTextIface(paramInt);
    if ((localAtkTextIface != null) && (localAtkTextIface.get_caret_offset != 0)) {
      i = ATK.call(localAtkTextIface.get_caret_offset, paramInt);
    }
    if (localAccessibleObject != null)
    {
      Accessible localAccessible = localAccessibleObject.accessible;
      Vector localVector = localAccessible.accessibleTextExtendedListeners;
      int j = size(localVector);
      AccessibleTextEvent localAccessibleTextEvent;
      int k;
      Object localObject;
      if (j > 0)
      {
        localAccessibleTextEvent = new AccessibleTextEvent(localAccessible);
        for (k = 0; k < j; k++)
        {
          localObject = (AccessibleTextExtendedListener)localVector.elementAt(k);
          ((AccessibleTextExtendedListener)localObject).getCaretOffset(localAccessibleTextEvent);
        }
        return localAccessibleTextEvent.offset;
      }
      localVector = localAccessible.accessibleTextListeners;
      j = size(localVector);
      if (j > 0)
      {
        localAccessibleTextEvent = new AccessibleTextEvent(localAccessibleObject.accessible);
        localAccessibleTextEvent.childID = localAccessibleObject.id;
        localAccessibleTextEvent.offset = i;
        for (k = 0; k < j; k++)
        {
          localObject = (AccessibleTextListener)localVector.elementAt(k);
          ((AccessibleTextListener)localObject).getCaretOffset(localAccessibleTextEvent);
        }
        return localAccessibleTextEvent.offset;
      }
    }
    return i;
  }
  
  static int atkText_get_bounded_ranges(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
  {
    if (DEBUG) {
      print("-->atkText_get_bounded_ranges");
    }
    AccessibleObject localAccessibleObject = getAccessibleObject(paramInt1);
    if (localAccessibleObject != null)
    {
      Accessible localAccessible = localAccessibleObject.accessible;
      localObject = localAccessible.accessibleTextExtendedListeners;
      int j = size((Vector)localObject);
      if (j > 0)
      {
        AccessibleTextEvent localAccessibleTextEvent = new AccessibleTextEvent(localAccessible);
        AtkTextRectangle localAtkTextRectangle = new AtkTextRectangle();
        ATK.memmove(localAtkTextRectangle, paramInt2, AtkTextRectangle.sizeof);
        localAccessibleTextEvent.x = localAtkTextRectangle.x;
        localAccessibleTextEvent.y = localAtkTextRectangle.y;
        localAccessibleTextEvent.width = localAtkTextRectangle.width;
        localAccessibleTextEvent.height = localAtkTextRectangle.height;
        for (int k = 0; k < j; k++)
        {
          AccessibleTextExtendedListener localAccessibleTextExtendedListener1 = (AccessibleTextExtendedListener)((Vector)localObject).elementAt(k);
          localAccessibleTextExtendedListener1.getRanges(localAccessibleTextEvent);
        }
        int[] arrayOfInt = localAccessibleTextEvent.ranges;
        int m = arrayOfInt == null ? 1 : arrayOfInt.length / 2;
        int n = OS.malloc(m * AtkTextRange.sizeof);
        AtkTextRange localAtkTextRange = new AtkTextRange();
        int i1 = 0;
        int i2 = arrayOfInt != null ? arrayOfInt.length / 2 : 1;
        while (i1 < i2)
        {
          if (arrayOfInt != null)
          {
            i3 = i1 * 2;
            localAccessibleTextEvent.start = arrayOfInt[i3];
            localAccessibleTextEvent.end = arrayOfInt[(i3 + 1)];
          }
          localAccessibleTextEvent.count = 0;
          localAccessibleTextEvent.type = 5;
          AccessibleTextExtendedListener localAccessibleTextExtendedListener2;
          for (int i3 = 0; i3 < j; i3++)
          {
            localAccessibleTextExtendedListener2 = (AccessibleTextExtendedListener)((Vector)localObject).elementAt(i3);
            localAccessibleTextExtendedListener2.getText(localAccessibleTextEvent);
          }
          localAtkTextRange.start_offset = localAccessibleTextEvent.start;
          localAtkTextRange.end_offset = localAccessibleTextEvent.end;
          localAtkTextRange.content = getStringPtr(localAccessibleTextEvent.result);
          localAccessibleTextEvent.result = null;
          localAccessibleTextEvent.count = (localAccessibleTextEvent.type = localAccessibleTextEvent.x = localAccessibleTextEvent.y = localAccessibleTextEvent.width = localAccessibleTextEvent.height = 0);
          for (i3 = 0; i3 < j; i3++)
          {
            localAccessibleTextExtendedListener2 = (AccessibleTextExtendedListener)((Vector)localObject).elementAt(i3);
            localAccessibleTextExtendedListener2.getTextBounds(localAccessibleTextEvent);
          }
          localAtkTextRange.bounds.x = localAccessibleTextEvent.x;
          localAtkTextRange.bounds.y = localAccessibleTextEvent.y;
          localAtkTextRange.bounds.width = localAccessibleTextEvent.width;
          localAtkTextRange.bounds.height = localAccessibleTextEvent.height;
          ATK.memmove(n + i1 * AtkTextRange.sizeof, localAtkTextRange, AtkTextRange.sizeof);
          i1++;
        }
        return n;
      }
    }
    int i = 0;
    Object localObject = getTextIface(paramInt1);
    if ((localObject != null) && (((AtkTextIface)localObject).get_bounded_ranges != 0)) {
      i = ATK.call(((AtkTextIface)localObject).get_bounded_ranges, paramInt1);
    }
    return i;
  }
  
  static int atkText_get_character_at_offset(int paramInt1, int paramInt2)
  {
    if (DEBUG) {
      print("-->atkText_get_character_at_offset");
    }
    AccessibleObject localAccessibleObject = getAccessibleObject(paramInt1);
    if (localAccessibleObject != null)
    {
      localObject1 = localAccessibleObject.accessible;
      Vector localVector = ((Accessible)localObject1).accessibleTextExtendedListeners;
      int i = size(localVector);
      if (i > 0)
      {
        localObject2 = new AccessibleTextEvent(localObject1);
        ((AccessibleTextEvent)localObject2).start = paramInt2;
        ((AccessibleTextEvent)localObject2).end = (paramInt2 + 1);
        ((AccessibleTextEvent)localObject2).type = 0;
        for (int j = 0; j < i; j++)
        {
          AccessibleTextExtendedListener localAccessibleTextExtendedListener = (AccessibleTextExtendedListener)localVector.elementAt(j);
          localAccessibleTextExtendedListener.getText((AccessibleTextEvent)localObject2);
        }
        String str = ((AccessibleTextEvent)localObject2).result;
        return (str != null) && (str.length() > 0) ? str.charAt(0) : 0;
      }
      Object localObject2 = localAccessibleObject.getText();
      if ((localObject2 != null) && (((String)localObject2).length() > paramInt2)) {
        return ((String)localObject2).charAt(paramInt2);
      }
    }
    Object localObject1 = getTextIface(paramInt1);
    if ((localObject1 != null) && (((AtkTextIface)localObject1).get_character_at_offset != 0)) {
      return ATK.call(((AtkTextIface)localObject1).get_character_at_offset, paramInt1, paramInt2);
    }
    return 0;
  }
  
  static int atkText_get_character_count(int paramInt)
  {
    if (DEBUG) {
      print("-->atkText_get_character_count");
    }
    AccessibleObject localAccessibleObject = getAccessibleObject(paramInt);
    if (localAccessibleObject != null)
    {
      localObject1 = localAccessibleObject.accessible;
      Vector localVector = ((Accessible)localObject1).accessibleTextExtendedListeners;
      int i = size(localVector);
      if (i > 0)
      {
        localObject2 = new AccessibleTextEvent(localObject1);
        for (int j = 0; j < i; j++)
        {
          AccessibleTextExtendedListener localAccessibleTextExtendedListener = (AccessibleTextExtendedListener)localVector.elementAt(j);
          localAccessibleTextExtendedListener.getCharacterCount((AccessibleTextEvent)localObject2);
        }
        return ((AccessibleTextEvent)localObject2).count;
      }
      Object localObject2 = localAccessibleObject.getText();
      if (localObject2 != null) {
        return ((String)localObject2).length();
      }
    }
    Object localObject1 = getTextIface(paramInt);
    if ((localObject1 != null) && (((AtkTextIface)localObject1).get_character_count != 0)) {
      return ATK.call(((AtkTextIface)localObject1).get_character_count, paramInt);
    }
    return 0;
  }
  
  static int atkText_get_n_selections(int paramInt)
  {
    if (DEBUG) {
      print("-->atkText_get_n_selections");
    }
    AccessibleObject localAccessibleObject = getAccessibleObject(paramInt);
    if (localAccessibleObject != null)
    {
      Accessible localAccessible = localAccessibleObject.accessible;
      localObject1 = localAccessible.accessibleTextExtendedListeners;
      int j = size((Vector)localObject1);
      AccessibleTextEvent localAccessibleTextEvent;
      int k;
      Object localObject2;
      if (j > 0)
      {
        localAccessibleTextEvent = new AccessibleTextEvent(localAccessible);
        for (k = 0; k < j; k++)
        {
          localObject2 = (AccessibleTextExtendedListener)((Vector)localObject1).elementAt(k);
          ((AccessibleTextExtendedListener)localObject2).getSelectionCount(localAccessibleTextEvent);
        }
        return localAccessibleTextEvent.count;
      }
      localObject1 = localAccessible.accessibleTextListeners;
      j = size((Vector)localObject1);
      if (j > 0)
      {
        localAccessibleTextEvent = new AccessibleTextEvent(localAccessibleObject.accessible);
        localAccessibleTextEvent.childID = localAccessibleObject.id;
        for (k = 0; k < j; k++)
        {
          localObject2 = (AccessibleTextListener)((Vector)localObject1).elementAt(k);
          ((AccessibleTextListener)localObject2).getSelectionRange(localAccessibleTextEvent);
        }
        if (localAccessibleTextEvent.length > 0) {
          return 1;
        }
      }
    }
    int i = 0;
    Object localObject1 = getTextIface(paramInt);
    if ((localObject1 != null) && (((AtkTextIface)localObject1).get_n_selections != 0)) {
      i = ATK.call(((AtkTextIface)localObject1).get_n_selections, paramInt);
    }
    return i;
  }
  
  static int atkText_get_selection(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    if (DEBUG) {
      print("-->atkText_get_selection");
    }
    AccessibleObject localAccessibleObject = getAccessibleObject(paramInt1);
    int i = 0;
    OS.memmove(paramInt3, new int[] { 0 }, 4);
    OS.memmove(paramInt4, new int[] { 0 }, 4);
    AtkTextIface localAtkTextIface = getTextIface(paramInt1);
    if ((localAtkTextIface != null) && (localAtkTextIface.get_selection != 0)) {
      i = ATK.call(localAtkTextIface.get_selection, paramInt1, paramInt2, paramInt3, paramInt4);
    }
    if (localAccessibleObject != null)
    {
      int[] arrayOfInt1 = new int[1];
      int[] arrayOfInt2 = new int[1];
      OS.memmove(arrayOfInt1, paramInt3, 4);
      OS.memmove(arrayOfInt2, paramInt4, 4);
      Accessible localAccessible = localAccessibleObject.accessible;
      Vector localVector = localAccessible.accessibleTextExtendedListeners;
      int j = size(localVector);
      AccessibleTextEvent localAccessibleTextEvent;
      int k;
      Object localObject;
      if (j > 0)
      {
        localAccessibleTextEvent = new AccessibleTextEvent(localAccessible);
        localAccessibleTextEvent.index = paramInt2;
        localAccessibleTextEvent.start = arrayOfInt1[0];
        localAccessibleTextEvent.end = arrayOfInt2[0];
        for (k = 0; k < j; k++)
        {
          localObject = (AccessibleTextExtendedListener)localVector.elementAt(k);
          ((AccessibleTextExtendedListener)localObject).getSelection(localAccessibleTextEvent);
        }
        arrayOfInt1[0] = localAccessibleTextEvent.start;
        arrayOfInt2[0] = localAccessibleTextEvent.end;
        OS.memmove(paramInt3, arrayOfInt1, 4);
        OS.memmove(paramInt4, arrayOfInt2, 4);
        localAccessibleTextEvent.count = (localAccessibleTextEvent.index = 0);
        localAccessibleTextEvent.type = 5;
        for (k = 0; k < j; k++)
        {
          localObject = (AccessibleTextExtendedListener)localVector.elementAt(k);
          ((AccessibleTextExtendedListener)localObject).getText(localAccessibleTextEvent);
        }
        if (i != 0) {
          OS.g_free(i);
        }
        return getStringPtr(localAccessibleTextEvent.result);
      }
      if (paramInt2 == 0)
      {
        localVector = localAccessible.accessibleTextListeners;
        j = size(localVector);
        if (j > 0)
        {
          localAccessibleTextEvent = new AccessibleTextEvent(localAccessible);
          localAccessibleTextEvent.childID = localAccessibleObject.id;
          localAccessibleTextEvent.offset = arrayOfInt1[0];
          localAccessibleTextEvent.length = (arrayOfInt2[0] - arrayOfInt1[0]);
          for (k = 0; k < j; k++)
          {
            localObject = (AccessibleTextListener)localVector.elementAt(k);
            ((AccessibleTextListener)localObject).getSelectionRange(localAccessibleTextEvent);
          }
          OS.memmove(paramInt3, new int[] { localAccessibleTextEvent.offset }, 4);
          OS.memmove(paramInt4, new int[] { localAccessibleTextEvent.offset + localAccessibleTextEvent.length }, 4);
          if (i != 0) {
            OS.g_free(i);
          }
          String str = localAccessibleObject.getText();
          if ((str != null) && (str.length() > localAccessibleTextEvent.offset) && (str.length() >= localAccessibleTextEvent.offset + localAccessibleTextEvent.length)) {
            return getStringPtr(str.substring(localAccessibleTextEvent.offset, localAccessibleTextEvent.offset + localAccessibleTextEvent.length));
          }
          if ((localAtkTextIface != null) && (localAtkTextIface.get_text != 0)) {
            return ATK.call(localAtkTextIface.get_text, paramInt1, localAccessibleTextEvent.offset, localAccessibleTextEvent.offset + localAccessibleTextEvent.length);
          }
          return 0;
        }
      }
    }
    return i;
  }
  
  static int atkText_get_text(int paramInt1, int paramInt2, int paramInt3)
  {
    if (DEBUG) {
      print("-->atkText_get_text: " + paramInt1 + " " + paramInt2 + "," + paramInt3);
    }
    AccessibleObject localAccessibleObject = getAccessibleObject(paramInt1);
    if (localAccessibleObject != null)
    {
      localObject1 = localAccessibleObject.accessible;
      Vector localVector = ((Accessible)localObject1).accessibleTextExtendedListeners;
      int i = size(localVector);
      if (i > 0)
      {
        localObject2 = new AccessibleTextEvent(localObject1);
        ((AccessibleTextEvent)localObject2).start = paramInt2;
        ((AccessibleTextEvent)localObject2).end = paramInt3;
        ((AccessibleTextEvent)localObject2).type = 5;
        for (int j = 0; j < i; j++)
        {
          AccessibleTextExtendedListener localAccessibleTextExtendedListener = (AccessibleTextExtendedListener)localVector.elementAt(j);
          localAccessibleTextExtendedListener.getText((AccessibleTextEvent)localObject2);
        }
        return getStringPtr(((AccessibleTextEvent)localObject2).result);
      }
      Object localObject2 = localAccessibleObject.getText();
      if ((localObject2 != null) && (((String)localObject2).length() > 0))
      {
        if (paramInt3 == -1) {
          paramInt3 = ((String)localObject2).length();
        } else {
          paramInt3 = Math.min(paramInt3, ((String)localObject2).length());
        }
        paramInt2 = Math.min(paramInt2, paramInt3);
        localObject2 = ((String)localObject2).substring(paramInt2, paramInt3);
        return getStringPtr((String)localObject2);
      }
    }
    Object localObject1 = getTextIface(paramInt1);
    if ((localObject1 != null) && (((AtkTextIface)localObject1).get_text != 0)) {
      return ATK.call(((AtkTextIface)localObject1).get_text, paramInt1, paramInt2, paramInt3);
    }
    return 0;
  }
  
  static int atkText_get_text_after_offset(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
  {
    if (DEBUG) {
      print("-->atkText_get_text_after_offset");
    }
    AccessibleObject localAccessibleObject = getAccessibleObject(paramInt1);
    if (localAccessibleObject != null)
    {
      localObject1 = localAccessibleObject.accessible;
      Vector localVector = ((Accessible)localObject1).accessibleTextExtendedListeners;
      int i = size(localVector);
      int k;
      int m;
      int n;
      int i1;
      if (i > 0)
      {
        j = atkText_get_character_count(paramInt1);
        localObject2 = new AccessibleTextEvent(localObject1);
        ((AccessibleTextEvent)localObject2).start = (((AccessibleTextEvent)localObject2).end = paramInt2);
        ((AccessibleTextEvent)localObject2).count = 1;
        switch (paramInt3)
        {
        case 0: 
          ((AccessibleTextEvent)localObject2).type = 0;
          break;
        case 1: 
          ((AccessibleTextEvent)localObject2).type = 1;
          break;
        case 2: 
          ((AccessibleTextEvent)localObject2).type = 1;
          break;
        case 3: 
          ((AccessibleTextEvent)localObject2).type = 2;
          break;
        case 4: 
          ((AccessibleTextEvent)localObject2).type = 2;
          break;
        case 5: 
          ((AccessibleTextEvent)localObject2).type = 4;
          break;
        case 6: 
          ((AccessibleTextEvent)localObject2).type = 4;
        }
        k = ((AccessibleTextEvent)localObject2).start;
        m = ((AccessibleTextEvent)localObject2).end;
        for (n = 0; n < i; n++)
        {
          AccessibleTextExtendedListener localAccessibleTextExtendedListener1 = (AccessibleTextExtendedListener)localVector.elementAt(n);
          localAccessibleTextExtendedListener1.getText((AccessibleTextEvent)localObject2);
        }
        AccessibleTextExtendedListener localAccessibleTextExtendedListener2;
        switch (paramInt3)
        {
        case 1: 
        case 3: 
        case 5: 
          if (((AccessibleTextEvent)localObject2).end < j)
          {
            n = ((AccessibleTextEvent)localObject2).start;
            ((AccessibleTextEvent)localObject2).start = k;
            ((AccessibleTextEvent)localObject2).end = m;
            ((AccessibleTextEvent)localObject2).count = 2;
            for (i1 = 0; i1 < i; i1++)
            {
              localAccessibleTextExtendedListener2 = (AccessibleTextExtendedListener)localVector.elementAt(i1);
              localAccessibleTextExtendedListener2.getText((AccessibleTextEvent)localObject2);
            }
            ((AccessibleTextEvent)localObject2).end = ((AccessibleTextEvent)localObject2).start;
            ((AccessibleTextEvent)localObject2).start = n;
            ((AccessibleTextEvent)localObject2).type = 5;
            ((AccessibleTextEvent)localObject2).count = 0;
            for (i1 = 0; i1 < i; i1++)
            {
              localAccessibleTextExtendedListener2 = (AccessibleTextExtendedListener)localVector.elementAt(i1);
              localAccessibleTextExtendedListener2.getText((AccessibleTextEvent)localObject2);
            }
          }
          break;
        case 2: 
        case 4: 
        case 6: 
          if (0 < ((AccessibleTextEvent)localObject2).start)
          {
            n = ((AccessibleTextEvent)localObject2).end;
            ((AccessibleTextEvent)localObject2).start = k;
            ((AccessibleTextEvent)localObject2).end = m;
            ((AccessibleTextEvent)localObject2).count = 0;
            for (i1 = 0; i1 < i; i1++)
            {
              localAccessibleTextExtendedListener2 = (AccessibleTextExtendedListener)localVector.elementAt(i1);
              localAccessibleTextExtendedListener2.getText((AccessibleTextEvent)localObject2);
            }
            ((AccessibleTextEvent)localObject2).start = ((AccessibleTextEvent)localObject2).end;
            ((AccessibleTextEvent)localObject2).end = n;
            ((AccessibleTextEvent)localObject2).type = 5;
            ((AccessibleTextEvent)localObject2).count = 0;
            for (i1 = 0; i1 < i; i1++)
            {
              localAccessibleTextExtendedListener2 = (AccessibleTextExtendedListener)localVector.elementAt(i1);
              localAccessibleTextExtendedListener2.getText((AccessibleTextEvent)localObject2);
            }
          }
          break;
        }
        OS.memmove(paramInt4, new int[] { ((AccessibleTextEvent)localObject2).start }, 4);
        OS.memmove(paramInt5, new int[] { ((AccessibleTextEvent)localObject2).end }, 4);
        return getStringPtr(((AccessibleTextEvent)localObject2).result);
      }
      int j = paramInt2;
      Object localObject2 = localAccessibleObject.getText();
      if ((localObject2 != null) && (((String)localObject2).length() > 0))
      {
        i = ((String)localObject2).length();
        j = Math.min(j, i - 1);
        k = j;
        m = j;
        int i2;
        switch (paramInt3)
        {
        case 0: 
          if (i > j) {
            m++;
          }
          break;
        case 1: 
          n = nextIndexOfChar((String)localObject2, " !?.\n", j - 1);
          if (n == -1)
          {
            k = m = i;
          }
          else
          {
            n = nextIndexOfNotChar((String)localObject2, " !?.\n", n);
            if (n == i)
            {
              k = m = i;
            }
            else
            {
              k = n;
              i1 = nextIndexOfChar((String)localObject2, " !?.\n", n);
              if (i1 == -1) {
                m = i;
              } else {
                m = nextIndexOfNotChar((String)localObject2, " !?.\n", i1);
              }
            }
          }
          break;
        case 2: 
          n = previousIndexOfNotChar((String)localObject2, " \n", j);
          if ((n == -1) || (n != j - 1)) {
            j = nextIndexOfNotChar((String)localObject2, " \n", j);
          }
          if (j == -1)
          {
            k = m = i;
          }
          else
          {
            i1 = nextIndexOfChar((String)localObject2, " !?.\n", j);
            if (i1 == -1)
            {
              k = m = i;
            }
            else
            {
              i1 = nextIndexOfNotChar((String)localObject2, "!?.", i1);
              if (i1 == i)
              {
                k = m = i;
              }
              else
              {
                k = i1;
                i2 = nextIndexOfNotChar((String)localObject2, " \n", i1);
                if (i2 == i)
                {
                  k = m = i;
                }
                else
                {
                  i2 = nextIndexOfChar((String)localObject2, " !?.\n", i2);
                  if (i2 == -1) {
                    m = i;
                  } else {
                    m = nextIndexOfNotChar((String)localObject2, "!?.", i2);
                  }
                }
              }
            }
          }
          break;
        case 3: 
          n = previousIndexOfChar((String)localObject2, "!?.", j);
          i1 = previousIndexOfNotChar((String)localObject2, " !?.\n", j);
          i2 = 0;
          if (n >= i1)
          {
            i2 = nextIndexOfNotChar((String)localObject2, " !?.\n", j);
          }
          else
          {
            i2 = nextIndexOfChar((String)localObject2, "!?.", j);
            if (i2 == -1)
            {
              k = m = i;
              break;
            }
            i2 = nextIndexOfNotChar((String)localObject2, " !?.\n", i2);
          }
          if (i2 == i)
          {
            k = m = i;
          }
          else
          {
            k = i2;
            int i3 = nextIndexOfChar((String)localObject2, "!?.", i2);
            if (i3 == -1) {
              m = i;
            } else {
              m = nextIndexOfNotChar((String)localObject2, " !?.\n", i3);
            }
          }
          break;
        case 4: 
          n = nextIndexOfChar((String)localObject2, "!?.", j);
          if (n == -1)
          {
            k = m = i;
          }
          else
          {
            n = nextIndexOfNotChar((String)localObject2, "!?.", n);
            if (n == i)
            {
              k = m = i;
            }
            else
            {
              k = n;
              i1 = nextIndexOfNotChar((String)localObject2, " \n", n);
              if (i1 == i)
              {
                k = m = i;
              }
              else
              {
                i1 = nextIndexOfChar((String)localObject2, "!?.", i1);
                if (i1 == -1) {
                  m = i;
                } else {
                  m = nextIndexOfNotChar((String)localObject2, "!?.", i1);
                }
              }
            }
          }
          break;
        case 5: 
          n = ((String)localObject2).indexOf('\n', j - 1);
          if (n == -1)
          {
            k = m = i;
          }
          else
          {
            n = nextIndexOfNotChar((String)localObject2, "\n", n);
            if (n == i)
            {
              k = m = i;
            }
            else
            {
              k = n;
              i1 = ((String)localObject2).indexOf('\n', n);
              if (i1 == -1)
              {
                m = i;
              }
              else
              {
                i1 = nextIndexOfNotChar((String)localObject2, "\n", i1);
                m = i1;
              }
            }
          }
          break;
        case 6: 
          n = nextIndexOfChar((String)localObject2, "\n", j);
          if (n == -1)
          {
            k = m = i;
          }
          else
          {
            k = n;
            if (k == i)
            {
              m = i;
            }
            else
            {
              i1 = nextIndexOfChar((String)localObject2, "\n", n + 1);
              if (i1 == -1) {
                m = i;
              } else {
                m = i1;
              }
            }
          }
          break;
        }
        OS.memmove(paramInt4, new int[] { k }, 4);
        OS.memmove(paramInt5, new int[] { m }, 4);
        localObject2 = ((String)localObject2).substring(k, m);
        return getStringPtr((String)localObject2);
      }
    }
    Object localObject1 = getTextIface(paramInt1);
    if ((localObject1 != null) && (((AtkTextIface)localObject1).get_text_after_offset != 0)) {
      return ATK.call(((AtkTextIface)localObject1).get_text_after_offset, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
    }
    return 0;
  }
  
  static int atkText_get_text_at_offset(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
  {
    if (DEBUG) {
      print("-->atkText_get_text_at_offset: " + paramInt2 + " start: " + paramInt4 + " end: " + paramInt5);
    }
    AccessibleObject localAccessibleObject = getAccessibleObject(paramInt1);
    if (localAccessibleObject != null)
    {
      localObject1 = localAccessibleObject.accessible;
      Vector localVector = ((Accessible)localObject1).accessibleTextExtendedListeners;
      int i = size(localVector);
      int k;
      int m;
      int n;
      int i1;
      if (i > 0)
      {
        j = atkText_get_character_count(paramInt1);
        localObject2 = new AccessibleTextEvent(localObject1);
        ((AccessibleTextEvent)localObject2).start = (((AccessibleTextEvent)localObject2).end = paramInt2);
        ((AccessibleTextEvent)localObject2).count = 0;
        switch (paramInt3)
        {
        case 0: 
          ((AccessibleTextEvent)localObject2).type = 0;
          break;
        case 1: 
          ((AccessibleTextEvent)localObject2).type = 1;
          break;
        case 2: 
          ((AccessibleTextEvent)localObject2).type = 1;
          break;
        case 3: 
          ((AccessibleTextEvent)localObject2).type = 2;
          break;
        case 4: 
          ((AccessibleTextEvent)localObject2).type = 2;
          break;
        case 5: 
          ((AccessibleTextEvent)localObject2).type = 4;
          break;
        case 6: 
          ((AccessibleTextEvent)localObject2).type = 4;
        }
        k = ((AccessibleTextEvent)localObject2).start;
        m = ((AccessibleTextEvent)localObject2).end;
        for (n = 0; n < i; n++)
        {
          AccessibleTextExtendedListener localAccessibleTextExtendedListener1 = (AccessibleTextExtendedListener)localVector.elementAt(n);
          localAccessibleTextExtendedListener1.getText((AccessibleTextEvent)localObject2);
        }
        AccessibleTextExtendedListener localAccessibleTextExtendedListener2;
        switch (paramInt3)
        {
        case 1: 
        case 3: 
        case 5: 
          if (((AccessibleTextEvent)localObject2).end < j)
          {
            n = ((AccessibleTextEvent)localObject2).start;
            ((AccessibleTextEvent)localObject2).start = k;
            ((AccessibleTextEvent)localObject2).end = m;
            ((AccessibleTextEvent)localObject2).count = 1;
            for (i1 = 0; i1 < i; i1++)
            {
              localAccessibleTextExtendedListener2 = (AccessibleTextExtendedListener)localVector.elementAt(i1);
              localAccessibleTextExtendedListener2.getText((AccessibleTextEvent)localObject2);
            }
            ((AccessibleTextEvent)localObject2).end = ((AccessibleTextEvent)localObject2).start;
            ((AccessibleTextEvent)localObject2).start = n;
            ((AccessibleTextEvent)localObject2).type = 5;
            ((AccessibleTextEvent)localObject2).count = 0;
            for (i1 = 0; i1 < i; i1++)
            {
              localAccessibleTextExtendedListener2 = (AccessibleTextExtendedListener)localVector.elementAt(i1);
              localAccessibleTextExtendedListener2.getText((AccessibleTextEvent)localObject2);
            }
          }
          break;
        case 2: 
        case 4: 
        case 6: 
          if (0 < ((AccessibleTextEvent)localObject2).start)
          {
            n = ((AccessibleTextEvent)localObject2).end;
            ((AccessibleTextEvent)localObject2).start = k;
            ((AccessibleTextEvent)localObject2).end = m;
            ((AccessibleTextEvent)localObject2).count = -1;
            for (i1 = 0; i1 < i; i1++)
            {
              localAccessibleTextExtendedListener2 = (AccessibleTextExtendedListener)localVector.elementAt(i1);
              localAccessibleTextExtendedListener2.getText((AccessibleTextEvent)localObject2);
            }
            ((AccessibleTextEvent)localObject2).start = ((AccessibleTextEvent)localObject2).end;
            ((AccessibleTextEvent)localObject2).end = n;
            ((AccessibleTextEvent)localObject2).type = 5;
            ((AccessibleTextEvent)localObject2).count = 0;
            for (i1 = 0; i1 < i; i1++)
            {
              localAccessibleTextExtendedListener2 = (AccessibleTextExtendedListener)localVector.elementAt(i1);
              localAccessibleTextExtendedListener2.getText((AccessibleTextEvent)localObject2);
            }
          }
          break;
        }
        OS.memmove(paramInt4, new int[] { ((AccessibleTextEvent)localObject2).start }, 4);
        OS.memmove(paramInt5, new int[] { ((AccessibleTextEvent)localObject2).end }, 4);
        return getStringPtr(((AccessibleTextEvent)localObject2).result);
      }
      int j = paramInt2;
      Object localObject2 = localAccessibleObject.getText();
      if ((localObject2 != null) && (((String)localObject2).length() > 0))
      {
        i = ((String)localObject2).length();
        j = Math.min(j, i - 1);
        k = j;
        m = j;
        switch (paramInt3)
        {
        case 0: 
          if (i > j) {
            m++;
          }
          break;
        case 1: 
          n = previousIndexOfNotChar((String)localObject2, " !?.\n", j);
          if (n == -1)
          {
            k = m = 0;
          }
          else
          {
            n = previousIndexOfChar((String)localObject2, " !?.\n", n) + 1;
            if (n == -1)
            {
              k = 0;
            }
            else
            {
              k = n;
              i1 = nextIndexOfChar((String)localObject2, " !?.\n", n);
              m = nextIndexOfNotChar((String)localObject2, " !?.\n", i1);
            }
          }
          break;
        case 2: 
          n = previousIndexOfNotChar((String)localObject2, "!?.", j + 1);
          n = previousIndexOfChar((String)localObject2, " !?.\n", n);
          n = previousIndexOfNotChar((String)localObject2, " \n", n + 1);
          if (n == -1)
          {
            k = m = 0;
          }
          else
          {
            k = n + 1;
            i1 = nextIndexOfNotChar((String)localObject2, " \n", k);
            if (i1 == i)
            {
              m = k;
            }
            else
            {
              i1 = nextIndexOfChar((String)localObject2, " !?.\n", i1);
              if (i1 == -1) {
                m = k;
              } else {
                m = nextIndexOfNotChar((String)localObject2, "!?.", i1);
              }
            }
          }
          break;
        case 3: 
          n = previousIndexOfNotChar((String)localObject2, " !?.\n", j + 1);
          if (n == -1)
          {
            k = m = 0;
          }
          else
          {
            n = previousIndexOfChar((String)localObject2, "!?.", n) + 1;
            k = nextIndexOfNotChar((String)localObject2, " \n", n);
            i1 = nextIndexOfChar((String)localObject2, "!?.", k);
            m = nextIndexOfNotChar((String)localObject2, " !?.\n", i1);
          }
          break;
        case 4: 
          n = previousIndexOfNotChar((String)localObject2, "!?.", j + 1);
          n = previousIndexOfChar((String)localObject2, "!?.", n);
          n = previousIndexOfNotChar((String)localObject2, " \n", n + 1);
          if (n == -1)
          {
            k = m = 0;
          }
          else
          {
            k = n + 1;
            i1 = nextIndexOfNotChar((String)localObject2, " \n", k);
            if (i1 == i)
            {
              m = k;
            }
            else
            {
              i1 = nextIndexOfChar((String)localObject2, "!?.", i1);
              if (i1 == -1) {
                m = k;
              } else {
                m = nextIndexOfNotChar((String)localObject2, "!?.", i1);
              }
            }
          }
          break;
        case 5: 
          k = previousIndexOfChar((String)localObject2, "\n", j) + 1;
          n = nextIndexOfChar((String)localObject2, "\n", k);
          if (n < i) {
            n++;
          }
          m = n;
          break;
        case 6: 
          n = previousIndexOfChar((String)localObject2, "\n", j);
          if (n == -1)
          {
            k = m = 0;
          }
          else
          {
            k = n;
            m = nextIndexOfChar((String)localObject2, "\n", n + 1);
          }
          break;
        }
        OS.memmove(paramInt4, new int[] { k }, 4);
        OS.memmove(paramInt5, new int[] { m }, 4);
        localObject2 = ((String)localObject2).substring(k, m);
        return getStringPtr((String)localObject2);
      }
    }
    Object localObject1 = getTextIface(paramInt1);
    if ((localObject1 != null) && (((AtkTextIface)localObject1).get_text_at_offset != 0)) {
      return ATK.call(((AtkTextIface)localObject1).get_text_at_offset, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
    }
    return 0;
  }
  
  static int atkText_get_text_before_offset(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
  {
    if (DEBUG) {
      print("-->atkText_get_text_before_offset");
    }
    AccessibleObject localAccessibleObject = getAccessibleObject(paramInt1);
    if (localAccessibleObject != null)
    {
      localObject1 = localAccessibleObject.accessible;
      Vector localVector = ((Accessible)localObject1).accessibleTextExtendedListeners;
      int i = size(localVector);
      int k;
      int m;
      int n;
      int i1;
      if (i > 0)
      {
        j = atkText_get_character_count(paramInt1);
        localObject2 = new AccessibleTextEvent(localObject1);
        ((AccessibleTextEvent)localObject2).start = (((AccessibleTextEvent)localObject2).end = paramInt2);
        ((AccessibleTextEvent)localObject2).count = -1;
        switch (paramInt3)
        {
        case 0: 
          ((AccessibleTextEvent)localObject2).type = 0;
          break;
        case 1: 
          ((AccessibleTextEvent)localObject2).type = 1;
          break;
        case 2: 
          ((AccessibleTextEvent)localObject2).type = 1;
          break;
        case 3: 
          ((AccessibleTextEvent)localObject2).type = 2;
          break;
        case 4: 
          ((AccessibleTextEvent)localObject2).type = 2;
          break;
        case 5: 
          ((AccessibleTextEvent)localObject2).type = 4;
          break;
        case 6: 
          ((AccessibleTextEvent)localObject2).type = 4;
        }
        k = ((AccessibleTextEvent)localObject2).start;
        m = ((AccessibleTextEvent)localObject2).end;
        for (n = 0; n < i; n++)
        {
          AccessibleTextExtendedListener localAccessibleTextExtendedListener1 = (AccessibleTextExtendedListener)localVector.elementAt(n);
          localAccessibleTextExtendedListener1.getText((AccessibleTextEvent)localObject2);
        }
        OS.memmove(paramInt4, new int[] { ((AccessibleTextEvent)localObject2).start }, 4);
        OS.memmove(paramInt5, new int[] { ((AccessibleTextEvent)localObject2).end }, 4);
        AccessibleTextExtendedListener localAccessibleTextExtendedListener2;
        switch (paramInt3)
        {
        case 1: 
        case 3: 
        case 5: 
          if (((AccessibleTextEvent)localObject2).end < j)
          {
            n = ((AccessibleTextEvent)localObject2).start;
            ((AccessibleTextEvent)localObject2).start = k;
            ((AccessibleTextEvent)localObject2).end = m;
            ((AccessibleTextEvent)localObject2).count = 0;
            for (i1 = 0; i1 < i; i1++)
            {
              localAccessibleTextExtendedListener2 = (AccessibleTextExtendedListener)localVector.elementAt(i1);
              localAccessibleTextExtendedListener2.getText((AccessibleTextEvent)localObject2);
            }
            ((AccessibleTextEvent)localObject2).end = ((AccessibleTextEvent)localObject2).start;
            ((AccessibleTextEvent)localObject2).start = n;
            ((AccessibleTextEvent)localObject2).type = 5;
            ((AccessibleTextEvent)localObject2).count = 0;
            for (i1 = 0; i1 < i; i1++)
            {
              localAccessibleTextExtendedListener2 = (AccessibleTextExtendedListener)localVector.elementAt(i1);
              localAccessibleTextExtendedListener2.getText((AccessibleTextEvent)localObject2);
            }
          }
          break;
        case 2: 
        case 4: 
        case 6: 
          if (0 < ((AccessibleTextEvent)localObject2).start)
          {
            n = ((AccessibleTextEvent)localObject2).end;
            ((AccessibleTextEvent)localObject2).start = k;
            ((AccessibleTextEvent)localObject2).end = m;
            ((AccessibleTextEvent)localObject2).count = -2;
            for (i1 = 0; i1 < i; i1++)
            {
              localAccessibleTextExtendedListener2 = (AccessibleTextExtendedListener)localVector.elementAt(i1);
              localAccessibleTextExtendedListener2.getText((AccessibleTextEvent)localObject2);
            }
            ((AccessibleTextEvent)localObject2).start = ((AccessibleTextEvent)localObject2).end;
            ((AccessibleTextEvent)localObject2).end = n;
            ((AccessibleTextEvent)localObject2).type = 5;
            ((AccessibleTextEvent)localObject2).count = 0;
            for (i1 = 0; i1 < i; i1++)
            {
              localAccessibleTextExtendedListener2 = (AccessibleTextExtendedListener)localVector.elementAt(i1);
              localAccessibleTextExtendedListener2.getText((AccessibleTextEvent)localObject2);
            }
          }
          break;
        }
        return getStringPtr(((AccessibleTextEvent)localObject2).result);
      }
      int j = paramInt2;
      Object localObject2 = localAccessibleObject.getText();
      if ((localObject2 != null) && (((String)localObject2).length() > 0))
      {
        i = ((String)localObject2).length();
        j = Math.min(j, i - 1);
        k = j;
        m = j;
        switch (paramInt3)
        {
        case 0: 
          if ((i >= j) && (j > 0)) {
            k--;
          }
          break;
        case 1: 
          n = previousIndexOfChar((String)localObject2, " !?.\n", j - 1);
          if (n == -1)
          {
            k = m = 0;
          }
          else
          {
            i1 = previousIndexOfNotChar((String)localObject2, " !?.\n", n);
            if (i1 == -1)
            {
              k = m = 0;
            }
            else
            {
              m = n + 1;
              k = previousIndexOfChar((String)localObject2, " !?.\n", i1) + 1;
            }
          }
          break;
        case 2: 
          n = previousIndexOfChar((String)localObject2, " !?.\n", j);
          if (n == -1)
          {
            k = m = 0;
          }
          else
          {
            n = previousIndexOfNotChar((String)localObject2, " \n", n + 1);
            if (n == -1)
            {
              k = m = 0;
            }
            else
            {
              m = n + 1;
              i1 = previousIndexOfNotChar((String)localObject2, " !?.\n", m);
              i1 = previousIndexOfChar((String)localObject2, " !?.\n", i1);
              if (i1 == -1) {
                k = 0;
              } else {
                k = previousIndexOfNotChar((String)localObject2, " \n", i1 + 1) + 1;
              }
            }
          }
          break;
        case 3: 
          n = previousIndexOfChar((String)localObject2, "!?.", j);
          if (n == -1)
          {
            k = m = 0;
          }
          else
          {
            i1 = previousIndexOfNotChar((String)localObject2, "!?.", n);
            if (i1 == -1)
            {
              k = m = 0;
            }
            else
            {
              m = n + 1;
              k = previousIndexOfChar((String)localObject2, "!?.", i1) + 1;
            }
          }
          break;
        case 4: 
          n = previousIndexOfChar((String)localObject2, "!?.", j);
          if (n == -1)
          {
            k = m = 0;
          }
          else
          {
            n = previousIndexOfNotChar((String)localObject2, " \n", n + 1);
            if (n == -1)
            {
              k = m = 0;
            }
            else
            {
              m = n + 1;
              i1 = previousIndexOfNotChar((String)localObject2, "!?.", m);
              i1 = previousIndexOfChar((String)localObject2, "!?.", i1);
              if (i1 == -1) {
                k = 0;
              } else {
                k = previousIndexOfNotChar((String)localObject2, " \n", i1 + 1) + 1;
              }
            }
          }
          break;
        case 5: 
          n = previousIndexOfChar((String)localObject2, "\n", j);
          if (n == -1)
          {
            k = m = 0;
          }
          else
          {
            m = n + 1;
            k = previousIndexOfChar((String)localObject2, "\n", n) + 1;
          }
          break;
        case 6: 
          n = previousIndexOfChar((String)localObject2, "\n", j);
          if (n == -1)
          {
            k = m = 0;
          }
          else
          {
            m = n;
            k = previousIndexOfChar((String)localObject2, "\n", n);
            if (k == -1) {
              k = 0;
            }
          }
          break;
        }
        OS.memmove(paramInt4, new int[] { k }, 4);
        OS.memmove(paramInt5, new int[] { m }, 4);
        localObject2 = ((String)localObject2).substring(k, m);
        return getStringPtr((String)localObject2);
      }
    }
    Object localObject1 = getTextIface(paramInt1);
    if ((localObject1 != null) && (((AtkTextIface)localObject1).get_text_before_offset != 0)) {
      return ATK.call(((AtkTextIface)localObject1).get_text_before_offset, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
    }
    return 0;
  }
  
  static void setGValue(int paramInt, Number paramNumber)
  {
    if (paramNumber == null) {
      return;
    }
    if (OS.G_VALUE_TYPE(paramInt) != 0) {
      OS.g_value_unset(paramInt);
    }
    if ((paramNumber instanceof Double))
    {
      OS.g_value_init(paramInt, OS.G_TYPE_DOUBLE());
      OS.g_value_set_double(paramInt, paramNumber.doubleValue());
    }
    else if ((paramNumber instanceof Float))
    {
      OS.g_value_init(paramInt, OS.G_TYPE_FLOAT());
      OS.g_value_set_float(paramInt, paramNumber.floatValue());
    }
    else if ((paramNumber instanceof Long))
    {
      OS.g_value_init(paramInt, OS.G_TYPE_INT64());
      OS.g_value_set_int64(paramInt, paramNumber.longValue());
    }
    else
    {
      OS.g_value_init(paramInt, OS.G_TYPE_INT());
      OS.g_value_set_int(paramInt, paramNumber.intValue());
    }
  }
  
  static Number getGValue(int paramInt)
  {
    int i = OS.G_VALUE_TYPE(paramInt);
    if (i == 0) {
      return null;
    }
    if (i == OS.G_TYPE_DOUBLE()) {
      return new Double(OS.g_value_get_double(paramInt));
    }
    if (i == OS.G_TYPE_FLOAT()) {
      return new Float(OS.g_value_get_float(paramInt));
    }
    if (i == OS.G_TYPE_INT64()) {
      return new Long(OS.g_value_get_int64(paramInt));
    }
    return new Integer(OS.g_value_get_int(paramInt));
  }
  
  static AtkValueIface getValueIface(int paramInt)
  {
    if (ATK.g_type_is_a(OS.g_type_parent(OS.G_OBJECT_TYPE(paramInt)), ATK.ATK_TYPE_VALUE()))
    {
      AtkValueIface localAtkValueIface = new AtkValueIface();
      ATK.memmove(localAtkValueIface, ATK.g_type_interface_peek_parent(ATK.ATK_VALUE_GET_IFACE(paramInt)));
      return localAtkValueIface;
    }
    return null;
  }
  
  static int atkValue_get_current_value(int paramInt1, int paramInt2)
  {
    if (DEBUG) {
      print("-->atkValue_get_current_value");
    }
    AccessibleObject localAccessibleObject = getAccessibleObject(paramInt1);
    AtkValueIface localAtkValueIface = getValueIface(paramInt1);
    if ((localAtkValueIface != null) && (localAtkValueIface.get_current_value != 0)) {
      ATK.call(localAtkValueIface.get_current_value, paramInt1, paramInt2);
    }
    if (localAccessibleObject != null)
    {
      Accessible localAccessible = localAccessibleObject.accessible;
      Vector localVector = localAccessible.accessibleValueListeners;
      int i = size(localVector);
      if (i > 0)
      {
        AccessibleValueEvent localAccessibleValueEvent = new AccessibleValueEvent(localAccessible);
        localAccessibleValueEvent.value = getGValue(paramInt2);
        for (int j = 0; j < i; j++)
        {
          AccessibleValueListener localAccessibleValueListener = (AccessibleValueListener)localVector.elementAt(j);
          localAccessibleValueListener.getCurrentValue(localAccessibleValueEvent);
        }
        setGValue(paramInt2, localAccessibleValueEvent.value);
      }
    }
    return 0;
  }
  
  static int atkValue_get_maximum_value(int paramInt1, int paramInt2)
  {
    if (DEBUG) {
      print("-->atkValue_get_maximum_value");
    }
    AccessibleObject localAccessibleObject = getAccessibleObject(paramInt1);
    AtkValueIface localAtkValueIface = getValueIface(paramInt1);
    if ((localAtkValueIface != null) && (localAtkValueIface.get_maximum_value != 0)) {
      ATK.call(localAtkValueIface.get_maximum_value, paramInt1, paramInt2);
    }
    if (localAccessibleObject != null)
    {
      Accessible localAccessible = localAccessibleObject.accessible;
      Vector localVector = localAccessible.accessibleValueListeners;
      int i = size(localVector);
      if (i > 0)
      {
        AccessibleValueEvent localAccessibleValueEvent = new AccessibleValueEvent(localAccessible);
        localAccessibleValueEvent.value = getGValue(paramInt2);
        for (int j = 0; j < i; j++)
        {
          AccessibleValueListener localAccessibleValueListener = (AccessibleValueListener)localVector.elementAt(j);
          localAccessibleValueListener.getMaximumValue(localAccessibleValueEvent);
        }
        setGValue(paramInt2, localAccessibleValueEvent.value);
      }
    }
    return 0;
  }
  
  static int atkValue_get_minimum_value(int paramInt1, int paramInt2)
  {
    if (DEBUG) {
      print("-->atkValue_get_minimum_value");
    }
    AccessibleObject localAccessibleObject = getAccessibleObject(paramInt1);
    AtkValueIface localAtkValueIface = getValueIface(paramInt1);
    if ((localAtkValueIface != null) && (localAtkValueIface.get_minimum_value != 0)) {
      ATK.call(localAtkValueIface.get_minimum_value, paramInt1, paramInt2);
    }
    if (localAccessibleObject != null)
    {
      Accessible localAccessible = localAccessibleObject.accessible;
      Vector localVector = localAccessible.accessibleValueListeners;
      int i = size(localVector);
      if (i > 0)
      {
        AccessibleValueEvent localAccessibleValueEvent = new AccessibleValueEvent(localAccessible);
        localAccessibleValueEvent.value = getGValue(paramInt2);
        for (int j = 0; j < i; j++)
        {
          AccessibleValueListener localAccessibleValueListener = (AccessibleValueListener)localVector.elementAt(j);
          localAccessibleValueListener.getMinimumValue(localAccessibleValueEvent);
        }
        setGValue(paramInt2, localAccessibleValueEvent.value);
      }
    }
    return 0;
  }
  
  static int atkValue_set_current_value(int paramInt1, int paramInt2)
  {
    if (DEBUG) {
      print("-->atkValue_set_current_value");
    }
    AccessibleObject localAccessibleObject = getAccessibleObject(paramInt1);
    if (localAccessibleObject != null)
    {
      Accessible localAccessible = localAccessibleObject.accessible;
      localObject = localAccessible.accessibleValueListeners;
      int j = size((Vector)localObject);
      if (j > 0)
      {
        AccessibleValueEvent localAccessibleValueEvent = new AccessibleValueEvent(localAccessible);
        localAccessibleValueEvent.value = getGValue(paramInt2);
        for (int k = 0; k < j; k++)
        {
          AccessibleValueListener localAccessibleValueListener = (AccessibleValueListener)((Vector)localObject).elementAt(k);
          localAccessibleValueListener.setCurrentValue(localAccessibleValueEvent);
        }
        return localAccessibleValueEvent.value != null ? 1 : 0;
      }
    }
    int i = 0;
    Object localObject = getValueIface(paramInt1);
    if ((localObject != null) && (((AtkValueIface)localObject).set_current_value != 0)) {
      i = ATK.call(((AtkValueIface)localObject).set_current_value, paramInt1, paramInt2);
    }
    return i;
  }
  
  static AccessibleObject getAccessibleObject(int paramInt)
  {
    AccessibleObject localAccessibleObject = (AccessibleObject)AccessibleObjects.get(new LONG(paramInt));
    if (localAccessibleObject == null) {
      return null;
    }
    if (localAccessibleObject.accessible == null) {
      return null;
    }
    Control localControl = localAccessibleObject.accessible.control;
    if ((localControl == null) || (localControl.isDisposed())) {
      return null;
    }
    return localAccessibleObject;
  }
  
  AccessibleObject getChildByID(int paramInt)
  {
    if (paramInt == -1) {
      return this;
    }
    if ((paramInt == -2) || (paramInt == -3)) {
      return null;
    }
    if (this.children != null) {
      for (int i = 0; i < this.children.length; i++)
      {
        AccessibleObject localAccessibleObject = this.children[i];
        if ((localAccessibleObject != null) && (localAccessibleObject.id == paramInt)) {
          return localAccessibleObject;
        }
      }
    }
    return null;
  }
  
  AccessibleObject getChildByIndex(int paramInt)
  {
    if ((this.children != null) && (paramInt < this.children.length)) {
      return this.children[paramInt];
    }
    return null;
  }
  
  String getText()
  {
    Vector localVector = this.accessible.accessibleControlListeners;
    int i = size(localVector);
    if (i > 0)
    {
      String str = "";
      AtkTextIface localAtkTextIface = getTextIface(this.handle);
      if ((localAtkTextIface != null) && (localAtkTextIface.get_character_count != 0))
      {
        int j = ATK.call(localAtkTextIface.get_character_count, this.handle);
        if ((j > 0) && (localAtkTextIface.get_text != 0))
        {
          k = ATK.call(localAtkTextIface.get_text, this.handle, 0, j);
          if (k != 0)
          {
            str = getString(k);
            OS.g_free(k);
          }
        }
      }
      AccessibleControlEvent localAccessibleControlEvent = new AccessibleControlEvent(this.accessible);
      localAccessibleControlEvent.childID = this.id;
      localAccessibleControlEvent.result = str;
      for (int k = 0; k < i; k++)
      {
        AccessibleControlListener localAccessibleControlListener = (AccessibleControlListener)localVector.elementAt(k);
        localAccessibleControlListener.getValue(localAccessibleControlEvent);
      }
      return localAccessibleControlEvent.result;
    }
    return null;
  }
  
  static int gObjectClass_finalize(int paramInt)
  {
    if (DEBUG) {
      print("-->gObjectClass_finalize: " + paramInt);
    }
    int i = ATK.g_type_class_peek_parent(ATK.G_OBJECT_GET_CLASS(paramInt));
    int j = ATK.G_OBJECT_CLASS(i);
    GObjectClass localGObjectClass = new GObjectClass();
    ATK.memmove(localGObjectClass, j);
    ATK.call(localGObjectClass.finalize, paramInt);
    AccessibleObject localAccessibleObject = (AccessibleObject)AccessibleObjects.get(new LONG(paramInt));
    if (localAccessibleObject != null) {
      AccessibleObjects.remove(new LONG(paramInt));
    }
    return 0;
  }
  
  static int toATKRelation(int paramInt)
  {
    switch (paramInt)
    {
    case 0: 
      return 1;
    case 1: 
      return 2;
    case 2: 
      return 14;
    case 3: 
      return 15;
    case 4: 
      return 11;
    case 5: 
      return 10;
    case 6: 
      return 8;
    case 7: 
      return 7;
    case 8: 
      return 3;
    case 9: 
      return 4;
    case 10: 
      return 5;
    case 11: 
      return 6;
    case 12: 
      return 13;
    case 13: 
      return 12;
    case 14: 
      return 9;
    }
    return 0;
  }
  
  static void windowPoint(AccessibleObject paramAccessibleObject, int[] paramArrayOfInt1, int[] paramArrayOfInt2)
  {
    int i;
    GtkAccessible localGtkAccessible;
    if (OS.GTK_VERSION >= OS.VERSION(2, 22, 0))
    {
      i = OS.gtk_accessible_get_widget(paramAccessibleObject.handle);
    }
    else
    {
      localGtkAccessible = new GtkAccessible();
      ATK.memmove(localGtkAccessible, paramAccessibleObject.handle);
      i = localGtkAccessible.widget;
    }
    while ((i == 0) && (paramAccessibleObject.parent != null))
    {
      paramAccessibleObject = paramAccessibleObject.parent;
      if (OS.GTK_VERSION >= OS.VERSION(2, 22, 0))
      {
        i = OS.gtk_accessible_get_widget(paramAccessibleObject.handle);
      }
      else
      {
        localGtkAccessible = new GtkAccessible();
        ATK.memmove(localGtkAccessible, paramAccessibleObject.handle);
        i = localGtkAccessible.widget;
      }
    }
    if (i == 0) {
      return;
    }
    int j = ATK.gtk_widget_get_toplevel(i);
    int k;
    if (OS.GTK_VERSION >= OS.VERSION(2, 14, 0)) {
      k = OS.gtk_widget_get_window(j);
    } else {
      k = OS.GTK_WIDGET_WINDOW(j);
    }
    OS.gdk_window_get_origin(k, paramArrayOfInt1, paramArrayOfInt2);
  }
  
  static int nextIndexOfChar(String paramString1, String paramString2, int paramInt)
  {
    int i = paramString1.length();
    for (int j = 0; j < paramString2.length(); j++)
    {
      int k = paramString2.charAt(j);
      int m = paramString1.indexOf(k, paramInt);
      if (m != -1) {
        i = Math.min(i, m);
      }
    }
    return i;
  }
  
  static int nextIndexOfNotChar(String paramString1, String paramString2, int paramInt)
  {
    int i = paramString1.length();
    for (int j = paramInt; j < i; j++)
    {
      int k = paramString1.charAt(j);
      if (paramString2.indexOf(k) == -1) {
        break;
      }
    }
    return j;
  }
  
  static int previousIndexOfChar(String paramString1, String paramString2, int paramInt)
  {
    int i = -1;
    if (paramInt < 0) {
      return i;
    }
    paramString1 = paramString1.substring(0, paramInt);
    for (int j = 0; j < paramString2.length(); j++)
    {
      int k = paramString2.charAt(j);
      int m = paramString1.lastIndexOf(k);
      if (m != -1) {
        i = Math.max(i, m);
      }
    }
    return i;
  }
  
  static int previousIndexOfNotChar(String paramString1, String paramString2, int paramInt)
  {
    if (paramInt < 0) {
      return -1;
    }
    for (int i = paramInt - 1; i >= 0; i--)
    {
      int j = paramString1.charAt(i);
      if (paramString2.indexOf(j) == -1) {
        break;
      }
    }
    return i;
  }
  
  void addRelation(int paramInt, Accessible paramAccessible)
  {
    OS.atk_object_add_relationship(this.handle, toATKRelation(paramInt), paramAccessible.getAccessibleObject().handle);
  }
  
  void release()
  {
    if (DEBUG) {
      print("AccessibleObject.release: " + this.handle);
    }
    this.accessible = null;
    if (this.children != null)
    {
      for (int i = 0; i < this.children.length; i++)
      {
        AccessibleObject localAccessibleObject = this.children[i];
        if (localAccessibleObject != null) {
          OS.g_object_unref(localAccessibleObject.handle);
        }
      }
      this.children = null;
    }
    if (this.isLightweight) {
      OS.g_object_unref(this.handle);
    }
  }
  
  void removeRelation(int paramInt, Accessible paramAccessible)
  {
    OS.atk_object_remove_relationship(this.handle, toATKRelation(paramInt), paramAccessible.getAccessibleObject().handle);
  }
  
  void selectionChanged()
  {
    OS.g_signal_emit_by_name(this.handle, ATK.selection_changed);
  }
  
  void sendEvent(int paramInt, Object paramObject)
  {
    Object localObject;
    int j;
    int i4;
    int i3;
    int i6;
    switch (paramInt)
    {
    case 32777: 
      OS.g_signal_emit_by_name(this.handle, ATK.selection_changed);
      break;
    case 32788: 
      OS.g_signal_emit_by_name(this.handle, ATK.text_selection_changed);
      break;
    case 32778: 
      if ((paramObject instanceof int[]))
      {
        localObject = (int[])paramObject;
        j = localObject[0];
        int m = localObject[1];
        int i2 = -1;
        switch (j)
        {
        case 2: 
          i2 = 21;
          break;
        case 2097152: 
          i2 = 20;
          break;
        case 16777216: 
          i2 = 16;
          break;
        case 4: 
          i2 = 11;
          break;
        case 1048576: 
          i2 = 10;
          break;
        case 8: 
          i2 = 18;
          break;
        case 16: 
          i2 = 4;
          break;
        case 512: 
          i2 = 9;
          break;
        case 1024: 
          i2 = 9;
          break;
        case 128: 
          i2 = 2;
          break;
        case 2048: 
          i2 = 3;
          break;
        case 64: 
          i2 = 6;
          break;
        case 32768: 
          i2 = 28;
          break;
        case 65536: 
          i2 = 23;
          break;
        case 131072: 
          i2 = 19;
          break;
        case 4194304: 
          break;
        case 1: 
          i2 = 7;
          break;
        case 67108864: 
          i2 = 1;
          break;
        case 134217728: 
          i2 = 24;
          break;
        case 268435456: 
          i2 = 15;
          break;
        case 33554432: 
          i2 = 32;
          break;
        case 536870912: 
          i2 = 33;
          break;
        case 1073741824: 
          i2 = 34;
        }
        if (i2 != -1) {
          ATK.atk_object_notify_state_change(this.handle, i2, m != 0);
        }
      }
      break;
    case 32779: 
      localObject = this.accessible.accessibleControlListeners;
      j = size((Vector)localObject);
      GdkRectangle localGdkRectangle = new GdkRectangle();
      if (j > 0)
      {
        AccessibleControlEvent localAccessibleControlEvent = new AccessibleControlEvent(this.accessible);
        localAccessibleControlEvent.childID = this.id;
        for (i4 = 0; i4 < j; i4++)
        {
          AccessibleControlListener localAccessibleControlListener = (AccessibleControlListener)((Vector)localObject).elementAt(i4);
          localAccessibleControlListener.getLocation(localAccessibleControlEvent);
        }
        localGdkRectangle.x = localAccessibleControlEvent.x;
        localGdkRectangle.y = localAccessibleControlEvent.y;
        localGdkRectangle.width = localAccessibleControlEvent.width;
        localGdkRectangle.height = localAccessibleControlEvent.height;
      }
      OS.g_signal_emit_by_name(this.handle, ATK.bounds_changed, localGdkRectangle);
      break;
    case 32780: 
      OS.g_object_notify(this.handle, ATK.accessible_name);
      break;
    case 32781: 
      OS.g_object_notify(this.handle, ATK.accessible_description);
      break;
    case 32782: 
      OS.g_object_notify(this.handle, ATK.accessible_value);
      break;
    case 261: 
      OS.g_signal_emit_by_name(this.handle, ATK.load_complete);
      break;
    case 262: 
      OS.g_signal_emit_by_name(this.handle, ATK.load_stopped);
      break;
    case 263: 
      OS.g_signal_emit_by_name(this.handle, ATK.reload);
      break;
    case 273: 
      break;
    case 274: 
      break;
    case 256: 
      break;
    case 264: 
      OS.g_object_notify(this.handle, ATK.end_index);
      break;
    case 265: 
      OS.g_object_notify(this.handle, ATK.number_of_anchors);
      break;
    case 266: 
      OS.g_object_notify(this.handle, ATK.selected_link);
      break;
    case 269: 
      OS.g_object_notify(this.handle, ATK.start_index);
      break;
    case 267: 
      OS.g_signal_emit_by_name(this.handle, ATK.link_activated);
      break;
    case 268: 
      if ((paramObject instanceof Integer))
      {
        int i = ((Integer)paramObject).intValue();
        OS.g_signal_emit_by_name(this.handle, ATK.link_selected, i);
      }
      break;
    case 271: 
      OS.g_object_notify(this.handle, ATK.accessible_hypertext_nlinks);
      break;
    case 512: 
      OS.g_signal_emit_by_name(this.handle, ATK.attributes_changed);
      break;
    case 515: 
      OS.g_object_notify(this.handle, ATK.accessible_table_caption_object);
      break;
    case 516: 
      OS.g_object_notify(this.handle, ATK.accessible_table_column_description);
      break;
    case 517: 
      OS.g_object_notify(this.handle, ATK.accessible_table_column_header);
      break;
    case 518: 
      if ((paramObject instanceof int[]))
      {
        int[] arrayOfInt = (int[])paramObject;
        int n = arrayOfInt[0];
        i3 = arrayOfInt[1];
        i4 = arrayOfInt[2];
        i6 = arrayOfInt[3];
        int i7 = arrayOfInt[4];
        switch (n)
        {
        case 1: 
          if (i4 > 0) {
            OS.g_signal_emit_by_name(this.handle, ATK.row_deleted, i3, i4);
          }
          if (i7 > 0) {
            OS.g_signal_emit_by_name(this.handle, ATK.column_deleted, i6, i7);
          }
          break;
        case 0: 
          if (i4 > 0) {
            OS.g_signal_emit_by_name(this.handle, ATK.row_inserted, i3, i4);
          }
          if (i7 > 0) {
            OS.g_signal_emit_by_name(this.handle, ATK.column_inserted, i6, i7);
          }
          break;
        }
      }
      break;
    case 519: 
      OS.g_object_notify(this.handle, ATK.accessible_table_row_description);
      break;
    case 520: 
      OS.g_object_notify(this.handle, ATK.accessible_table_row_header);
      break;
    case 521: 
      OS.g_object_notify(this.handle, ATK.accessible_table_summary);
      break;
    case 522: 
      OS.g_signal_emit_by_name(this.handle, ATK.text_attributes_changed);
      break;
    case 283: 
    case 285: 
      int k = 0;
      Vector localVector = this.accessible.accessibleTextExtendedListeners;
      i3 = size(localVector);
      AccessibleTextEvent localAccessibleTextEvent = new AccessibleTextEvent(this.accessible);
      AccessibleTextListener localAccessibleTextListener;
      if (i3 > 0)
      {
        for (i6 = 0; i6 < i3; i6++)
        {
          localAccessibleTextListener = (AccessibleTextListener)localVector.elementAt(i6);
          localAccessibleTextListener.getCaretOffset(localAccessibleTextEvent);
        }
      }
      else
      {
        localVector = this.accessible.accessibleTextListeners;
        i3 = size(localVector);
        if (i3 > 0)
        {
          localAccessibleTextEvent.childID = this.id;
          for (i6 = 0; i6 < i3; i6++)
          {
            localAccessibleTextListener = (AccessibleTextListener)localVector.elementAt(i6);
            localAccessibleTextListener.getCaretOffset(localAccessibleTextEvent);
          }
        }
      }
      k = localAccessibleTextEvent.offset;
      OS.g_signal_emit_by_name(this.handle, ATK.text_caret_moved, k);
      break;
    case 524: 
      if ((paramObject instanceof Object[]))
      {
        Object[] arrayOfObject = (Object[])paramObject;
        int i1 = ((Integer)arrayOfObject[0]).intValue();
        i3 = ((Integer)arrayOfObject[1]).intValue();
        int i5 = ((Integer)arrayOfObject[2]).intValue();
        switch (i1)
        {
        case 1: 
          OS.g_signal_emit_by_name(this.handle, ATK.text_changed_delete, i3, i5 - i3);
          break;
        case 0: 
          OS.g_signal_emit_by_name(this.handle, ATK.text_changed_insert, i3, i5 - i3);
        }
      }
      break;
    }
  }
  
  void sendEvent(int paramInt1, Object paramObject, int paramInt2)
  {
    updateChildren();
    AccessibleObject localAccessibleObject = getChildByID(paramInt2);
    if (localAccessibleObject != null) {
      localAccessibleObject.sendEvent(paramInt1, paramObject);
    }
  }
  
  void setFocus(int paramInt)
  {
    updateChildren();
    AccessibleObject localAccessibleObject = getChildByID(paramInt);
    if (localAccessibleObject != null)
    {
      OS.g_signal_emit_by_name(localAccessibleObject.handle, ATK.focus_event, 1, 0);
      ATK.atk_object_notify_state_change(localAccessibleObject.handle, 11, true);
    }
  }
  
  void textCaretMoved(int paramInt)
  {
    OS.g_signal_emit_by_name(this.handle, ATK.text_caret_moved, paramInt);
  }
  
  void textChanged(int paramInt1, int paramInt2, int paramInt3)
  {
    if (paramInt1 == 1) {
      OS.g_signal_emit_by_name(this.handle, ATK.text_changed_delete, paramInt2, paramInt3);
    } else {
      OS.g_signal_emit_by_name(this.handle, ATK.text_changed_insert, paramInt2, paramInt3);
    }
  }
  
  void textSelectionChanged()
  {
    OS.g_signal_emit_by_name(this.handle, ATK.text_selection_changed);
  }
  
  void updateChildren()
  {
    Vector localVector = this.accessible.accessibleControlListeners;
    int i = size(localVector);
    AccessibleControlEvent localAccessibleControlEvent = new AccessibleControlEvent(this.accessible);
    localAccessibleControlEvent.childID = this.id;
    for (int j = 0; j < i; j++)
    {
      localObject1 = (AccessibleControlListener)localVector.elementAt(j);
      ((AccessibleControlListener)localObject1).getChildren(localAccessibleControlEvent);
    }
    Object[] arrayOfObject = localAccessibleControlEvent.children;
    Object localObject1 = this.children;
    int k = arrayOfObject != null ? arrayOfObject.length : 0;
    AccessibleObject[] arrayOfAccessibleObject = new AccessibleObject[k];
    Object localObject2;
    for (int m = 0; m < k; m++)
    {
      localObject2 = arrayOfObject[m];
      AccessibleObject localAccessibleObject = null;
      if ((localObject2 instanceof Integer))
      {
        int n = ((Integer)localObject2).intValue();
        localAccessibleObject = (localObject1 != null) && (m < localObject1.length) ? localObject1[m] : null;
        if ((localAccessibleObject == null) || (localAccessibleObject.id != n))
        {
          localAccessibleControlEvent = new AccessibleControlEvent(this.accessible);
          localAccessibleControlEvent.childID = n;
          for (int i1 = 0; i1 < i; i1++)
          {
            AccessibleControlListener localAccessibleControlListener = (AccessibleControlListener)localVector.elementAt(i1);
            localAccessibleControlListener.getChild(localAccessibleControlEvent);
          }
          if (localAccessibleControlEvent.accessible != null)
          {
            localAccessibleObject = localAccessibleControlEvent.accessible.getAccessibleObject();
            if (localAccessibleObject != null) {
              OS.g_object_ref(localAccessibleObject.handle);
            }
          }
          else
          {
            localAccessibleObject = AccessibleFactory.createChildAccessible(this.accessible, n);
          }
          localAccessibleObject.id = n;
        }
        else
        {
          OS.g_object_ref(localAccessibleObject.handle);
        }
      }
      else if ((localObject2 instanceof Accessible))
      {
        localAccessibleObject = ((Accessible)localObject2).getAccessibleObject();
        if (localAccessibleObject != null) {
          OS.g_object_ref(localAccessibleObject.handle);
        }
      }
      if (localAccessibleObject != null)
      {
        localAccessibleObject.index = m;
        localAccessibleObject.parent = this;
        arrayOfAccessibleObject[m] = localAccessibleObject;
      }
    }
    if (localObject1 != null) {
      for (m = 0; m < localObject1.length; m++)
      {
        localObject2 = localObject1[m];
        if (localObject2 != null) {
          OS.g_object_unref(((AccessibleObject)localObject2).handle);
        }
      }
    }
    this.children = arrayOfAccessibleObject;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/accessibility/AccessibleObject.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */