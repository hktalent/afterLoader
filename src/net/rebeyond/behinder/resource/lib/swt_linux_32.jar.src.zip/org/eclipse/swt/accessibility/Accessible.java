package org.eclipse.swt.accessibility;

import java.util.Vector;
import org.eclipse.swt.SWT;
import org.eclipse.swt.internal.gtk.OS;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;

public class Accessible
{
  Vector accessibleListeners;
  Vector accessibleControlListeners;
  Vector accessibleTextListeners;
  Vector accessibleActionListeners;
  Vector accessibleEditableTextListeners;
  Vector accessibleHyperlinkListeners;
  Vector accessibleTableListeners;
  Vector accessibleTableCellListeners;
  Vector accessibleTextExtendedListeners;
  Vector accessibleValueListeners;
  Vector accessibleAttributeListeners;
  Accessible parent;
  AccessibleObject accessibleObject;
  Control control;
  Vector relations;
  Vector children;
  
  public Accessible(Accessible paramAccessible)
  {
    this.parent = checkNull(paramAccessible);
    this.control = paramAccessible.control;
    if (paramAccessible.children == null) {
      paramAccessible.children = new Vector();
    }
    paramAccessible.children.addElement(this);
  }
  
  @Deprecated
  protected Accessible() {}
  
  static Accessible checkNull(Accessible paramAccessible)
  {
    if (paramAccessible == null) {
      SWT.error(4);
    }
    return paramAccessible;
  }
  
  Accessible(Control paramControl)
  {
    this.control = paramControl;
    AccessibleFactory.registerAccessible(this);
  }
  
  public void addAccessibleListener(AccessibleListener paramAccessibleListener)
  {
    checkWidget();
    if (paramAccessibleListener == null) {
      SWT.error(4);
    }
    if (this.accessibleListeners == null) {
      this.accessibleListeners = new Vector();
    }
    this.accessibleListeners.addElement(paramAccessibleListener);
  }
  
  public void addAccessibleControlListener(AccessibleControlListener paramAccessibleControlListener)
  {
    checkWidget();
    if (paramAccessibleControlListener == null) {
      SWT.error(4);
    }
    if (this.accessibleControlListeners == null) {
      this.accessibleControlListeners = new Vector();
    }
    this.accessibleControlListeners.addElement(paramAccessibleControlListener);
  }
  
  public void addAccessibleTextListener(AccessibleTextListener paramAccessibleTextListener)
  {
    checkWidget();
    if (paramAccessibleTextListener == null) {
      SWT.error(4);
    }
    if ((paramAccessibleTextListener instanceof AccessibleTextExtendedListener))
    {
      if (this.accessibleTextExtendedListeners == null) {
        this.accessibleTextExtendedListeners = new Vector();
      }
      this.accessibleTextExtendedListeners.addElement(paramAccessibleTextListener);
    }
    else
    {
      if (this.accessibleTextListeners == null) {
        this.accessibleTextListeners = new Vector();
      }
      this.accessibleTextListeners.addElement(paramAccessibleTextListener);
    }
  }
  
  public void addAccessibleActionListener(AccessibleActionListener paramAccessibleActionListener)
  {
    checkWidget();
    if (paramAccessibleActionListener == null) {
      SWT.error(4);
    }
    if (this.accessibleActionListeners == null) {
      this.accessibleActionListeners = new Vector();
    }
    this.accessibleActionListeners.addElement(paramAccessibleActionListener);
  }
  
  public void addAccessibleEditableTextListener(AccessibleEditableTextListener paramAccessibleEditableTextListener)
  {
    checkWidget();
    if (paramAccessibleEditableTextListener == null) {
      SWT.error(4);
    }
    if (this.accessibleEditableTextListeners == null) {
      this.accessibleEditableTextListeners = new Vector();
    }
    this.accessibleEditableTextListeners.addElement(paramAccessibleEditableTextListener);
  }
  
  public void addAccessibleHyperlinkListener(AccessibleHyperlinkListener paramAccessibleHyperlinkListener)
  {
    checkWidget();
    if (paramAccessibleHyperlinkListener == null) {
      SWT.error(4);
    }
    if (this.accessibleHyperlinkListeners == null) {
      this.accessibleHyperlinkListeners = new Vector();
    }
    this.accessibleHyperlinkListeners.addElement(paramAccessibleHyperlinkListener);
  }
  
  public void addAccessibleTableListener(AccessibleTableListener paramAccessibleTableListener)
  {
    checkWidget();
    if (paramAccessibleTableListener == null) {
      SWT.error(4);
    }
    if (this.accessibleTableListeners == null) {
      this.accessibleTableListeners = new Vector();
    }
    this.accessibleTableListeners.addElement(paramAccessibleTableListener);
  }
  
  public void addAccessibleTableCellListener(AccessibleTableCellListener paramAccessibleTableCellListener)
  {
    checkWidget();
    if (paramAccessibleTableCellListener == null) {
      SWT.error(4);
    }
    if (this.accessibleTableCellListeners == null) {
      this.accessibleTableCellListeners = new Vector();
    }
    this.accessibleTableCellListeners.addElement(paramAccessibleTableCellListener);
  }
  
  public void addAccessibleValueListener(AccessibleValueListener paramAccessibleValueListener)
  {
    checkWidget();
    if (paramAccessibleValueListener == null) {
      SWT.error(4);
    }
    if (this.accessibleValueListeners == null) {
      this.accessibleValueListeners = new Vector();
    }
    this.accessibleValueListeners.addElement(paramAccessibleValueListener);
  }
  
  public void addAccessibleAttributeListener(AccessibleAttributeListener paramAccessibleAttributeListener)
  {
    checkWidget();
    if (paramAccessibleAttributeListener == null) {
      SWT.error(4);
    }
    if (this.accessibleAttributeListeners == null) {
      this.accessibleAttributeListeners = new Vector();
    }
    this.accessibleAttributeListeners.addElement(paramAccessibleAttributeListener);
  }
  
  public void addRelation(int paramInt, Accessible paramAccessible)
  {
    checkWidget();
    if (this.relations == null) {
      this.relations = new Vector();
    }
    Relation localRelation = new Relation(paramInt, paramAccessible);
    if (this.relations.indexOf(localRelation) != -1) {
      return;
    }
    this.relations.add(localRelation);
    if (this.accessibleObject != null) {
      this.accessibleObject.addRelation(paramInt, paramAccessible);
    }
  }
  
  void addRelations()
  {
    if (this.relations == null) {
      return;
    }
    if (this.accessibleObject == null) {
      return;
    }
    for (int i = 0; i < this.relations.size(); i++)
    {
      Relation localRelation = (Relation)this.relations.elementAt(i);
      this.accessibleObject.addRelation(localRelation.type, localRelation.target);
    }
  }
  
  public void dispose()
  {
    if (this.parent == null) {
      return;
    }
    release();
    this.parent.children.removeElement(this);
    this.parent = null;
  }
  
  public Control getControl()
  {
    return this.control;
  }
  
  void checkWidget()
  {
    if (!isValidThread()) {
      SWT.error(22);
    }
    if (this.control.isDisposed()) {
      SWT.error(24);
    }
  }
  
  AccessibleObject getAccessibleObject()
  {
    if (this.accessibleObject == null) {
      if (this.parent == null)
      {
        AccessibleFactory.createAccessible(this);
      }
      else
      {
        this.accessibleObject = AccessibleFactory.createChildAccessible(this, -1);
        this.accessibleObject.parent = this.parent.getAccessibleObject();
      }
    }
    return this.accessibleObject;
  }
  
  int getControlHandle()
  {
    int i = this.control.handle;
    if ((this.control instanceof Label))
    {
      int j = OS.gtk_container_get_children(i);
      if (j != 0)
      {
        for (int k = j; k != 0; k = OS.g_list_next(k))
        {
          int m = OS.g_list_data(k);
          if (OS.GTK_VERSION >= OS.VERSION(2, 18, 0) ? OS.gtk_widget_get_visible(m) : OS.GTK_WIDGET_VISIBLE(m))
          {
            i = m;
            break;
          }
        }
        OS.g_list_free(j);
      }
    }
    return i;
  }
  
  public void internal_dispose_Accessible()
  {
    AccessibleFactory.unregisterAccessible(this);
    release();
  }
  
  public static Accessible internal_new_Accessible(Control paramControl)
  {
    return new Accessible(paramControl);
  }
  
  boolean isValidThread()
  {
    return this.control.getDisplay().getThread() == Thread.currentThread();
  }
  
  void release()
  {
    if (this.children != null) {
      for (int i = 0; i < this.children.size(); i++)
      {
        Accessible localAccessible = (Accessible)this.children.elementAt(i);
        localAccessible.dispose();
      }
    }
    if (this.accessibleObject != null)
    {
      this.accessibleObject.release();
      this.accessibleObject = null;
    }
  }
  
  public void removeAccessibleControlListener(AccessibleControlListener paramAccessibleControlListener)
  {
    checkWidget();
    if (paramAccessibleControlListener == null) {
      SWT.error(4);
    }
    if (this.accessibleControlListeners != null)
    {
      this.accessibleControlListeners.removeElement(paramAccessibleControlListener);
      if (this.accessibleControlListeners.isEmpty()) {
        this.accessibleControlListeners = null;
      }
    }
  }
  
  public void removeAccessibleListener(AccessibleListener paramAccessibleListener)
  {
    checkWidget();
    if (paramAccessibleListener == null) {
      SWT.error(4);
    }
    if (this.accessibleListeners != null)
    {
      this.accessibleListeners.removeElement(paramAccessibleListener);
      if (this.accessibleListeners.isEmpty()) {
        this.accessibleListeners = null;
      }
    }
  }
  
  public void removeAccessibleTextListener(AccessibleTextListener paramAccessibleTextListener)
  {
    checkWidget();
    if (paramAccessibleTextListener == null) {
      SWT.error(4);
    }
    if ((paramAccessibleTextListener instanceof AccessibleTextExtendedListener))
    {
      if (this.accessibleTextExtendedListeners != null)
      {
        this.accessibleTextExtendedListeners.removeElement(paramAccessibleTextListener);
        if (this.accessibleTextExtendedListeners.isEmpty()) {
          this.accessibleTextExtendedListeners = null;
        }
      }
    }
    else if (this.accessibleTextListeners != null)
    {
      this.accessibleTextListeners.removeElement(paramAccessibleTextListener);
      if (this.accessibleTextListeners.isEmpty()) {
        this.accessibleTextListeners = null;
      }
    }
  }
  
  public void removeAccessibleActionListener(AccessibleActionListener paramAccessibleActionListener)
  {
    checkWidget();
    if (paramAccessibleActionListener == null) {
      SWT.error(4);
    }
    if (this.accessibleActionListeners != null)
    {
      this.accessibleActionListeners.removeElement(paramAccessibleActionListener);
      if (this.accessibleActionListeners.isEmpty()) {
        this.accessibleActionListeners = null;
      }
    }
  }
  
  public void removeAccessibleEditableTextListener(AccessibleEditableTextListener paramAccessibleEditableTextListener)
  {
    checkWidget();
    if (paramAccessibleEditableTextListener == null) {
      SWT.error(4);
    }
    if (this.accessibleEditableTextListeners != null)
    {
      this.accessibleEditableTextListeners.removeElement(paramAccessibleEditableTextListener);
      if (this.accessibleEditableTextListeners.isEmpty()) {
        this.accessibleEditableTextListeners = null;
      }
    }
  }
  
  public void removeAccessibleHyperlinkListener(AccessibleHyperlinkListener paramAccessibleHyperlinkListener)
  {
    checkWidget();
    if (paramAccessibleHyperlinkListener == null) {
      SWT.error(4);
    }
    if (this.accessibleHyperlinkListeners != null)
    {
      this.accessibleHyperlinkListeners.removeElement(paramAccessibleHyperlinkListener);
      if (this.accessibleHyperlinkListeners.isEmpty()) {
        this.accessibleHyperlinkListeners = null;
      }
    }
  }
  
  public void removeAccessibleTableListener(AccessibleTableListener paramAccessibleTableListener)
  {
    checkWidget();
    if (paramAccessibleTableListener == null) {
      SWT.error(4);
    }
    if (this.accessibleTableListeners != null)
    {
      this.accessibleTableListeners.removeElement(paramAccessibleTableListener);
      if (this.accessibleTableListeners.isEmpty()) {
        this.accessibleTableListeners = null;
      }
    }
  }
  
  public void removeAccessibleTableCellListener(AccessibleTableCellListener paramAccessibleTableCellListener)
  {
    checkWidget();
    if (paramAccessibleTableCellListener == null) {
      SWT.error(4);
    }
    if (this.accessibleTableCellListeners != null)
    {
      this.accessibleTableCellListeners.removeElement(paramAccessibleTableCellListener);
      if (this.accessibleTableCellListeners.isEmpty()) {
        this.accessibleTableCellListeners = null;
      }
    }
  }
  
  public void removeAccessibleValueListener(AccessibleValueListener paramAccessibleValueListener)
  {
    checkWidget();
    if (paramAccessibleValueListener == null) {
      SWT.error(4);
    }
    if (this.accessibleValueListeners != null)
    {
      this.accessibleValueListeners.removeElement(paramAccessibleValueListener);
      if (this.accessibleValueListeners.isEmpty()) {
        this.accessibleValueListeners = null;
      }
    }
  }
  
  public void removeAccessibleAttributeListener(AccessibleAttributeListener paramAccessibleAttributeListener)
  {
    checkWidget();
    if (paramAccessibleAttributeListener == null) {
      SWT.error(4);
    }
    if (this.accessibleAttributeListeners != null)
    {
      this.accessibleAttributeListeners.removeElement(paramAccessibleAttributeListener);
      if (this.accessibleAttributeListeners.isEmpty()) {
        this.accessibleAttributeListeners = null;
      }
    }
  }
  
  public void removeRelation(int paramInt, Accessible paramAccessible)
  {
    checkWidget();
    if (this.relations == null) {
      return;
    }
    Relation localRelation = new Relation(paramInt, paramAccessible);
    int i = this.relations.indexOf(localRelation);
    if (i == -1) {
      return;
    }
    this.relations.remove(i);
    if (this.accessibleObject != null) {
      this.accessibleObject.removeRelation(paramInt, paramAccessible);
    }
  }
  
  public void sendEvent(int paramInt, Object paramObject)
  {
    checkWidget();
    if (this.accessibleObject != null) {
      this.accessibleObject.sendEvent(paramInt, paramObject);
    }
  }
  
  public void sendEvent(int paramInt1, Object paramObject, int paramInt2)
  {
    checkWidget();
    if (this.accessibleObject != null) {
      switch (paramInt1)
      {
      case 32777: 
      case 32778: 
      case 32779: 
      case 32780: 
      case 32781: 
      case 32782: 
      case 32788: 
        this.accessibleObject.sendEvent(paramInt1, paramObject, paramInt2);
      }
    }
  }
  
  public void selectionChanged()
  {
    checkWidget();
    if (this.accessibleObject != null) {
      this.accessibleObject.selectionChanged();
    }
  }
  
  public void setFocus(int paramInt)
  {
    checkWidget();
    if (this.accessibleObject != null) {
      this.accessibleObject.setFocus(paramInt);
    }
  }
  
  public void textCaretMoved(int paramInt)
  {
    checkWidget();
    if (this.accessibleObject != null) {
      this.accessibleObject.textCaretMoved(paramInt);
    }
  }
  
  public void textChanged(int paramInt1, int paramInt2, int paramInt3)
  {
    checkWidget();
    if (this.accessibleObject != null) {
      this.accessibleObject.textChanged(paramInt1, paramInt2, paramInt3);
    }
  }
  
  public void textSelectionChanged()
  {
    checkWidget();
    if (this.accessibleObject != null) {
      this.accessibleObject.textSelectionChanged();
    }
  }
  
  static class Relation
  {
    int type;
    Accessible target;
    
    public Relation(int paramInt, Accessible paramAccessible)
    {
      this.type = paramInt;
      this.target = paramAccessible;
    }
    
    public boolean equals(Object paramObject)
    {
      if (paramObject == this) {
        return true;
      }
      if (!(paramObject instanceof Relation)) {
        return false;
      }
      Relation localRelation = (Relation)paramObject;
      return (localRelation.type == this.type) && (localRelation.target == this.target);
    }
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/accessibility/Accessible.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */