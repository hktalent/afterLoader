package org.eclipse.swt.internal.mozilla;

public class nsIPrefLocalizedString
  extends nsISupports
{
  static final int LAST_METHOD_ID = nsISupports.LAST_METHOD_ID + 4;
  static final String NS_IPREFLOCALIZEDSTRING_IID_STR = "ae419e24-1dd1-11b2-b39a-d3e5e7073802";
  
  public nsIPrefLocalizedString(int paramInt)
  {
    super(paramInt);
  }
  
  public int ToString(int[] paramArrayOfInt)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 3, getAddress(), paramArrayOfInt);
  }
  
  public int SetDataWithLength(int paramInt, char[] paramArrayOfChar)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 4, getAddress(), paramInt, paramArrayOfChar);
  }
  
  static
  {
    IIDStore.RegisterIID(nsIPrefLocalizedString.class, 0, new nsID("ae419e24-1dd1-11b2-b39a-d3e5e7073802"));
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/internal/mozilla/nsIPrefLocalizedString.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */