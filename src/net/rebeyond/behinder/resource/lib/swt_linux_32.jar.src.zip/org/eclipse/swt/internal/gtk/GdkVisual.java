package org.eclipse.swt.internal.gtk;

public class GdkVisual
{
  public int type;
  public int depth;
  public int byte_order;
  public int colormap_size;
  public int bits_per_rgb;
  public int red_mask;
  public int red_shift;
  public int red_prec;
  public int green_mask;
  public int green_shift;
  public int green_prec;
  public int blue_mask;
  public int blue_shift;
  public int blue_prec;
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/internal/gtk/GdkVisual.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */