package org.eclipse.swt.internal.accessibility.gtk;

public class AtkComponentIface
{
  public int add_focus_handler;
  public int contains;
  public int ref_accessible_at_point;
  public int get_extents;
  public int get_position;
  public int get_size;
  public int grab_focus;
  public int remove_focus_handler;
  public int set_extents;
  public int set_position;
  public int set_size;
  public int get_layer;
  public int get_mdi_zorder;
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/internal/accessibility/gtk/AtkComponentIface.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */