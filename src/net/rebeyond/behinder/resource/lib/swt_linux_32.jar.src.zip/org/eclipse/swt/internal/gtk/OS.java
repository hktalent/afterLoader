package org.eclipse.swt.internal.gtk;

import org.eclipse.swt.internal.C;
import org.eclipse.swt.internal.Library;
import org.eclipse.swt.internal.Lock;
import org.eclipse.swt.internal.cairo.Cairo;

public class OS
  extends C
{
  public static final boolean IsAIX;
  public static final boolean IsSunOS;
  public static final boolean IsLinux;
  public static final boolean IsHPUX;
  public static final boolean BIG_ENDIAN;
  public static final int AnyPropertyType = 0;
  public static final int G_FILE_TEST_IS_DIR = 4;
  public static final int G_FILE_TEST_IS_EXECUTABLE = 8;
  public static final int G_SIGNAL_MATCH_FUNC = 8;
  public static final int G_SIGNAL_MATCH_DATA = 16;
  public static final int G_SIGNAL_MATCH_ID = 1;
  public static final int GDK_2BUTTON_PRESS = 5;
  public static final int GDK_3BUTTON_PRESS = 6;
  public static final int GDK_ACTION_COPY = 2;
  public static final int GDK_ACTION_MOVE = 4;
  public static final int GDK_ACTION_LINK = 8;
  public static final int GDK_Alt_L = 65513;
  public static final int GDK_Alt_R = 65514;
  public static final int GDK_AND = 4;
  public static final int GDK_BackSpace = 65288;
  public static final int GDK_BOTTOM_LEFT_CORNER = 12;
  public static final int GDK_BOTTOM_RIGHT_CORNER = 14;
  public static final int GDK_BOTTOM_SIDE = 16;
  public static final int GDK_BUTTON1_MASK = 256;
  public static final int GDK_BUTTON2_MASK = 512;
  public static final int GDK_BUTTON3_MASK = 1024;
  public static final int GDK_BUTTON_MOTION_MASK = 16;
  public static final int GDK_BUTTON1_MOTION_MASK = 32;
  public static final int GDK_BUTTON2_MOTION_MASK = 64;
  public static final int GDK_BUTTON3_MOTION_MASK = 128;
  public static final int GDK_BUTTON_PRESS = 4;
  public static final int GDK_BUTTON_PRESS_MASK = 256;
  public static final int GDK_BUTTON_RELEASE = 7;
  public static final int GDK_BUTTON_RELEASE_MASK = 512;
  public static final int GDK_CAP_BUTT = 1;
  public static final int GDK_CAP_PROJECTING = 3;
  public static final int GDK_CAP_ROUND = 2;
  public static final int GDK_COLORSPACE_RGB = 0;
  public static final int GDK_CONFIGURE = 13;
  public static final int GDK_CONTROL_MASK = 4;
  public static final int GDK_COPY = 0;
  public static final int GDK_CROSS = 30;
  public static final int GDK_CROSSING_NORMAL = 0;
  public static final int GDK_CROSSING_GRAB = 1;
  public static final int GDK_CROSSING_UNGRAB = 2;
  public static final int GDK_Break = 65387;
  public static final int GDK_Cancel = 65385;
  public static final int GDK_Caps_Lock = 65509;
  public static final int GDK_Clear = 65291;
  public static final int GDK_Control_L = 65507;
  public static final int GDK_Control_R = 65508;
  public static final int GDK_CURRENT_TIME = 0;
  public static final int GDK_DECOR_BORDER = 2;
  public static final int GDK_DECOR_MAXIMIZE = 64;
  public static final int GDK_DECOR_MENU = 16;
  public static final int GDK_DECOR_MINIMIZE = 32;
  public static final int GDK_DECOR_RESIZEH = 4;
  public static final int GDK_DECOR_TITLE = 8;
  public static final int GDK_DOUBLE_ARROW = 42;
  public static final int GDK_Delete = 65535;
  public static final int GDK_Down = 65364;
  public static final int GDK_ENTER_NOTIFY_MASK = 4096;
  public static final int GDK_ENTER_NOTIFY = 10;
  public static final int GDK_EVEN_ODD_RULE = 0;
  public static final int GTK_EXPANDER_COLAPSED = 0;
  public static final int GTK_EXPANDER_SEMI_COLLAPSED = 1;
  public static final int GTK_EXPANDER_SEMI_EXPANDED = 2;
  public static final int GTK_EXPANDER_EXPANDED = 3;
  public static final int GDK_EXPOSE = 2;
  public static final int GDK_EXPOSURE_MASK = 2;
  public static final int GDK_End = 65367;
  public static final int GDK_Escape = 65307;
  public static final int GDK_ISO_Enter = 65076;
  public static final int GDK_F1 = 65470;
  public static final int GDK_F10 = 65479;
  public static final int GDK_F11 = 65480;
  public static final int GDK_F12 = 65481;
  public static final int GDK_F13 = 65482;
  public static final int GDK_F14 = 65483;
  public static final int GDK_F15 = 65484;
  public static final int GDK_F16 = 65485;
  public static final int GDK_F17 = 65486;
  public static final int GDK_F18 = 65487;
  public static final int GDK_F19 = 65488;
  public static final int GDK_F20 = 65489;
  public static final int GDK_F2 = 65471;
  public static final int GDK_F3 = 65472;
  public static final int GDK_F4 = 65473;
  public static final int GDK_F5 = 65474;
  public static final int GDK_F6 = 65475;
  public static final int GDK_F7 = 65476;
  public static final int GDK_F8 = 65477;
  public static final int GDK_F9 = 65478;
  public static final int GDK_FLEUR = 52;
  public static final int GDK_FOCUS_CHANGE = 12;
  public static final int GDK_FOCUS_CHANGE_MASK = 16384;
  public static final int GDK_GC_FOREGROUND = 1;
  public static final int GDK_GC_CLIP_MASK = 128;
  public static final int GDK_GC_CLIP_X_ORIGIN = 2048;
  public static final int GDK_GC_CLIP_Y_ORIGIN = 4096;
  public static final int GDK_GC_LINE_WIDTH = 16384;
  public static final int GDK_GC_LINE_STYLE = 32768;
  public static final int GDK_GC_CAP_STYLE = 65536;
  public static final int GDK_GC_JOIN_STYLE = 131072;
  public static final int GDK_GRAB_SUCCESS = 0;
  public static final int GDK_HAND2 = 60;
  public static final int GDK_Help = 65386;
  public static final int GDK_HINT_MIN_SIZE = 2;
  public static final int GDK_Home = 65360;
  public static final int GDK_INCLUDE_INFERIORS = 1;
  public static final int GDK_INPUT_ONLY = 1;
  public static final int GDK_INTERP_BILINEAR = 2;
  public static final int GDK_Insert = 65379;
  public static final int GDK_ISO_Left_Tab = 65056;
  public static final int GDK_JOIN_MITER = 0;
  public static final int GDK_JOIN_ROUND = 1;
  public static final int GDK_JOIN_BEVEL = 2;
  public static final int GDK_KEY_PRESS = 8;
  public static final int GDK_KEY_PRESS_MASK = 1024;
  public static final int GDK_KEY_RELEASE = 9;
  public static final int GDK_KEY_RELEASE_MASK = 2048;
  public static final int GDK_KP_0 = 65456;
  public static final int GDK_KP_1 = 65457;
  public static final int GDK_KP_2 = 65458;
  public static final int GDK_KP_3 = 65459;
  public static final int GDK_KP_4 = 65460;
  public static final int GDK_KP_5 = 65461;
  public static final int GDK_KP_6 = 65462;
  public static final int GDK_KP_7 = 65463;
  public static final int GDK_KP_8 = 65464;
  public static final int GDK_KP_9 = 65465;
  public static final int GDK_KP_Add = 65451;
  public static final int GDK_KP_Decimal = 65454;
  public static final int GDK_KP_Delete = 65439;
  public static final int GDK_KP_Divide = 65455;
  public static final int GDK_KP_Down = 65433;
  public static final int GDK_KP_End = 65436;
  public static final int GDK_KP_Enter = 65421;
  public static final int GDK_KP_Equal = 65469;
  public static final int GDK_KP_Home = 65429;
  public static final int GDK_KP_Insert = 65438;
  public static final int GDK_KP_Left = 65430;
  public static final int GDK_KP_Multiply = 65450;
  public static final int GDK_KP_Page_Down = 65435;
  public static final int GDK_KP_Page_Up = 65434;
  public static final int GDK_KP_Right = 65432;
  public static final int GDK_KP_Subtract = 65453;
  public static final int GDK_KP_Up = 65431;
  public static final int GDK_LEAVE_NOTIFY = 11;
  public static final int GDK_LEAVE_NOTIFY_MASK = 8192;
  public static final int GDK_LEFT_PTR = 68;
  public static final int GDK_LEFT_SIDE = 70;
  public static final int GDK_LINE_ON_OFF_DASH = 1;
  public static final int GDK_LINE_SOLID = 0;
  public static final int GDK_Linefeed = 65290;
  public static final int GDK_LSB_FIRST = 0;
  public static final int GDK_Left = 65361;
  public static final int GDK_Meta_L = 65511;
  public static final int GDK_Meta_R = 65512;
  public static final int GDK_MAP = 14;
  public static final int GDK_MOD1_MASK = 8;
  public static final int GDK_MOTION_NOTIFY = 3;
  public static final int GDK_NO_EXPOSE = 30;
  public static final int GDK_NONE = 0;
  public static final int GDK_NOTIFY_INFERIOR = 2;
  public static final int GDK_Num_Lock = 65407;
  public static final int GDK_OVERLAP_RECTANGLE_OUT = 1;
  public static final int GDK_OWNERSHIP_NONE = 0;
  public static final int GDK_PIXBUF_ALPHA_BILEVEL = 0;
  public static final int GDK_POINTER_MOTION_HINT_MASK = 8;
  public static final int GDK_POINTER_MOTION_MASK = 4;
  public static final int GDK_PROPERTY_NOTIFY = 16;
  public static final int GDK_PROPERTY_CHANGE_MASK = 65536;
  public static final int GDK_Page_Down = 65366;
  public static final int GDK_Page_Up = 65365;
  public static final int GDK_Pause = 65299;
  public static final int GDK_Print = 65377;
  public static final int GDK_QUESTION_ARROW = 92;
  public static final int GDK_RGB_DITHER_NORMAL = 1;
  public static final int GDK_RIGHT_SIDE = 96;
  public static final int GDK_Return = 65293;
  public static final int GDK_Right = 65363;
  public static final int GDK_space = 32;
  public static final int GDK_SB_H_DOUBLE_ARROW = 108;
  public static final int GDK_SB_UP_ARROW = 114;
  public static final int GDK_SB_V_DOUBLE_ARROW = 116;
  public static final int GDK_SCROLL_UP = 0;
  public static final int GDK_SCROLL_DOWN = 1;
  public static final int GDK_SCROLL_LEFT = 2;
  public static final int GDK_SCROLL_RIGHT = 3;
  public static final int GDK_SCROLL_SMOOTH = 4;
  public static final int GDK_SCROLL_MASK = 2097152;
  public static final int GDK_SMOOTH_SCROLL_MASK = 8388608;
  public static final int GDK_SELECTION_CLEAR = 17;
  public static final int GDK_SELECTION_NOTIFY = 19;
  public static final int GDK_SELECTION_REQUEST = 18;
  public static final int GDK_SHIFT_MASK = 1;
  public static final int GDK_SIZING = 120;
  public static final int GDK_STIPPLED = 2;
  public static final int GDK_TILED = 1;
  public static final int GDK_Shift_L = 65505;
  public static final int GDK_Shift_R = 65506;
  public static final int GDK_SCROLL = 31;
  public static final int GDK_Scroll_Lock = 65300;
  public static final int GDK_TOP_LEFT_CORNER = 134;
  public static final int GDK_TOP_RIGHT_CORNER = 136;
  public static final int GDK_TOP_SIDE = 138;
  public static final int GDK_Tab = 65289;
  public static final int GDK_Up = 65362;
  public static final int GDK_WATCH = 150;
  public static final int GDK_XOR = 2;
  public static final int GDK_XTERM = 152;
  public static final int GDK_X_CURSOR = 0;
  public static final int GDK_VISIBILITY_NOTIFY = 29;
  public static final int GDK_VISIBILITY_FULLY_OBSCURED = 2;
  public static final int GDK_VISIBILITY_NOTIFY_MASK = 131072;
  public static final int GDK_WINDOW_CHILD = 2;
  public static final int GDK_WINDOW_STATE = 32;
  public static final int GDK_WINDOW_STATE_ICONIFIED = 2;
  public static final int GDK_WINDOW_STATE_MAXIMIZED = 4;
  public static final int GDK_WINDOW_STATE_FULLSCREEN = 16;
  public static final int GTK_ACCEL_VISIBLE = 1;
  public static final int GTK_ARROW_DOWN = 1;
  public static final int GTK_ARROW_LEFT = 2;
  public static final int GTK_ARROW_RIGHT = 3;
  public static final int GTK_ARROW_UP = 0;
  public static final int GTK_CALENDAR_SHOW_HEADING = 1;
  public static final int GTK_CALENDAR_SHOW_DAY_NAMES = 2;
  public static final int GTK_CALENDAR_NO_MONTH_CHANGE = 4;
  public static final int GTK_CALENDAR_SHOW_WEEK_NUMBERS = 8;
  public static final int GTK_CALENDAR_WEEK_START_MONDAY = 16;
  public static final int GTK_CAN_DEFAULT = 8192;
  public static final int GTK_CAN_FOCUS = 2048;
  public static final int GTK_CELL_RENDERER_MODE_ACTIVATABLE = 1;
  public static final int GTK_CELL_RENDERER_SELECTED = 1;
  public static final int GTK_CELL_RENDERER_FOCUSED = 16;
  public static final int GTK_CLIST_SHOW_TITLES = 4;
  public static final int GTK_CORNER_TOP_LEFT = 0;
  public static final int GTK_CORNER_TOP_RIGHT = 2;
  public static final int GTK_DIALOG_DESTROY_WITH_PARENT = 2;
  public static final int GTK_DIALOG_MODAL = 1;
  public static final int GTK_DIR_TAB_FORWARD = 0;
  public static final int GTK_DIR_TAB_BACKWARD = 1;
  public static final int GTK_ENTRY_ICON_PRIMARY = 0;
  public static final int GTK_ENTRY_ICON_SECONDARY = 1;
  public static final int GTK_FILE_CHOOSER_ACTION_OPEN = 0;
  public static final int GTK_FILE_CHOOSER_ACTION_SAVE = 1;
  public static final int GTK_FILE_CHOOSER_ACTION_SELECT_FOLDER = 2;
  public static final int GTK_HAS_FOCUS = 4096;
  public static final int GTK_ICON_SIZE_MENU = 1;
  public static final int GTK_ICON_SIZE_SMALL_TOOLBAR = 2;
  public static final int GTK_ICON_SIZE_LARGE_TOOLBAR = 3;
  public static final int GTK_ICON_SIZE_DIALOG = 6;
  public static final int GTK_JUSTIFY_CENTER = 2;
  public static final int GTK_JUSTIFY_LEFT = 0;
  public static final int GTK_JUSTIFY_RIGHT = 1;
  public static final int GTK_MAPPED = 128;
  public static final int GTK_MESSAGE_INFO = 0;
  public static final int GTK_MESSAGE_WARNING = 1;
  public static final int GTK_MESSAGE_QUESTION = 2;
  public static final int GTK_MESSAGE_ERROR = 3;
  public static final int GTK_MOVEMENT_VISUAL_POSITIONS = 1;
  public static final int GTK_NO_WINDOW = 32;
  public static final int GTK_ORIENTATION_HORIZONTAL = 0;
  public static final int GTK_ORIENTATION_VERTICAL = 1;
  public static final int GTK_PACK_END = 1;
  public static final int GTK_PACK_START = 0;
  public static final int GTK_PAGE_ORIENTATION_PORTRAIT = 0;
  public static final int GTK_PAGE_ORIENTATION_LANDSCAPE = 1;
  public static final int GTK_POLICY_ALWAYS = 0;
  public static final int GTK_POLICY_AUTOMATIC = 1;
  public static final int GTK_POLICY_NEVER = 2;
  public static final int GTK_POS_TOP = 2;
  public static final int GTK_POS_BOTTOM = 3;
  public static final int GTK_PRINT_CAPABILITY_PAGE_SET = 1;
  public static final int GTK_PRINT_CAPABILITY_COPIES = 2;
  public static final int GTK_PRINT_CAPABILITY_COLLATE = 4;
  public static final int GTK_PRINT_CAPABILITY_REVERSE = 8;
  public static final int GTK_PRINT_CAPABILITY_SCALE = 16;
  public static final int GTK_PRINT_CAPABILITY_GENERATE_PDF = 32;
  public static final int GTK_PRINT_CAPABILITY_GENERATE_PS = 64;
  public static final int GTK_PRINT_CAPABILITY_PREVIEW = 128;
  public static final int GTK_PRINT_PAGES_ALL = 0;
  public static final int GTK_PRINT_PAGES_CURRENT = 1;
  public static final int GTK_PRINT_PAGES_RANGES = 2;
  public static final int GTK_PRINT_DUPLEX_SIMPLEX = 0;
  public static final int GTK_PRINT_DUPLEX_HORIZONTAL = 1;
  public static final int GTK_PRINT_DUPLEX_VERTICAL = 2;
  public static final int GTK_PROGRESS_CONTINUOUS = 0;
  public static final int GTK_PROGRESS_DISCRETE = 1;
  public static final int GTK_PROGRESS_LEFT_TO_RIGHT = 0;
  public static final int GTK_PROGRESS_BOTTOM_TO_TOP = 2;
  public static final int GTK_REALIZED = 64;
  public static final int GTK_RECEIVES_DEFAULT = 1048576;
  public static final int GTK_RELIEF_NONE = 2;
  public static final int GTK_RELIEF_NORMAL = 0;
  public static final int GTK_RC_BG = 2;
  public static final int GTK_RC_FG = 1;
  public static final int GTK_RC_TEXT = 4;
  public static final int GTK_RC_BASE = 8;
  public static final int GTK_RESPONSE_APPLY = -10;
  public static final int GTK_RESPONSE_CANCEL = -6;
  public static final int GTK_RESPONSE_OK = -5;
  public static final int GTK_SCROLL_NONE = 0;
  public static final int GTK_SCROLL_JUMP = 1;
  public static final int GTK_SCROLL_STEP_BACKWARD = 2;
  public static final int GTK_SCROLL_STEP_FORWARD = 3;
  public static final int GTK_SCROLL_PAGE_BACKWARD = 4;
  public static final int GTK_SCROLL_PAGE_FORWARD = 5;
  public static final int GTK_SCROLL_STEP_UP = 6;
  public static final int GTK_SCROLL_STEP_DOWN = 7;
  public static final int GTK_SCROLL_PAGE_UP = 8;
  public static final int GTK_SCROLL_PAGE_DOWN = 9;
  public static final int GTK_SCROLL_STEP_LEFT = 10;
  public static final int GTK_SCROLL_STEP_RIGHT = 11;
  public static final int GTK_SCROLL_PAGE_LEFT = 12;
  public static final int GTK_SCROLL_PAGE_RIGHT = 13;
  public static final int GTK_SCROLL_START = 14;
  public static final int GTK_SCROLL_END = 15;
  public static final int GTK_SELECTION_BROWSE = 2;
  public static final int GTK_SELECTION_MULTIPLE = 3;
  public static final int GTK_SENSITIVE = 512;
  public static final int GTK_SHADOW_ETCHED_IN = 3;
  public static final int GTK_SHADOW_ETCHED_OUT = 4;
  public static final int GTK_SHADOW_IN = 1;
  public static final int GTK_SHADOW_NONE = 0;
  public static final int GTK_SHADOW_OUT = 2;
  public static final int GTK_STATE_ACTIVE = 1;
  public static final int GTK_STATE_INSENSITIVE = 4;
  public static final int GTK_STATE_NORMAL = 0;
  public static final int GTK_STATE_PRELIGHT = 2;
  public static final int GTK_STATE_SELECTED = 3;
  public static final int GTK_STATE_FLAG_NORMAL = 0;
  public static final int GTK_STATE_FLAG_ACTIVE = 1;
  public static final int GTK_STATE_FLAG_PRELIGHT = 2;
  public static final int GTK_STATE_FLAG_SELECTED = 4;
  public static final int GTK_STATE_FLAG_INSENSITIVE = 8;
  public static final int GTK_STATE_FLAG_INCONSISTENT = 16;
  public static final int GTK_STATE_FLAG_FOCUSED = 32;
  public static final int GTK_STATE_FLAG_BACKDROP = 64;
  public static final int GTK_TEXT_DIR_LTR = 1;
  public static final int GTK_TEXT_DIR_NONE = 0;
  public static final int GTK_TEXT_DIR_RTL = 2;
  public static final int GTK_TEXT_WINDOW_TEXT = 2;
  public static final int GTK_TOOLBAR_CHILD_BUTTON = 1;
  public static final int GTK_TOOLBAR_CHILD_RADIOBUTTON = 3;
  public static final int GTK_TOOLBAR_CHILD_TOGGLEBUTTON = 2;
  public static final int GTK_TOOLBAR_ICONS = 0;
  public static final int GTK_TOOLBAR_TEXT = 1;
  public static final int GTK_TOOLBAR_BOTH = 2;
  public static final int GTK_TOOLBAR_BOTH_HORIZ = 3;
  public static final int GTK_TREE_VIEW_COLUMN_GROW_ONLY = 0;
  public static final int GTK_TREE_VIEW_COLUMN_AUTOSIZE = 1;
  public static final int GTK_TREE_VIEW_COLUMN_FIXED = 2;
  public static final int GTK_TREE_VIEW_DROP_BEFORE = 0;
  public static final int GTK_TREE_VIEW_DROP_AFTER = 1;
  public static final int GTK_TREE_VIEW_DROP_INTO_OR_BEFORE = 2;
  public static final int GTK_TREE_VIEW_DROP_INTO_OR_AFTER = 3;
  public static final int GTK_TREE_VIEW_GRID_LINES_NONE = 0;
  public static final int GTK_TREE_VIEW_GRID_LINES_HORIZONTAL = 1;
  public static final int GTK_TREE_VIEW_GRID_LINES_VERTICAL = 2;
  public static final int GTK_TREE_VIEW_GRID_LINES_BOTH = 3;
  public static final int GTK_STYLE_PROVIDER_PRIORITY_APPLICATION = 600;
  public static final int GDK_UNMAP = 15;
  public static final int GTK_UNIT_PIXEL = 0;
  public static final int GTK_UNIT_POINTS = 1;
  public static final int GTK_UNIT_INCH = 2;
  public static final int GTK_UNIT_MM = 3;
  public static final int GTK_VISIBILITY_FULL = 2;
  public static final int GTK_VISIBILITY_NONE = 0;
  public static final int GTK_VISIBLE = 256;
  public static final int GDK_WA_X = 4;
  public static final int GDK_WA_Y = 8;
  public static final int GDK_WA_VISUAL = 64;
  public static final int GTK_WINDOW_POPUP = 1;
  public static final int GTK_WINDOW_TOPLEVEL = 0;
  public static final int GDK_WINDOW_TYPE_HINT_DIALOG = 1;
  public static final int GDK_WINDOW_TYPE_HINT_TOOLTIP = 10;
  public static final int GTK_WRAP_NONE = 0;
  public static final int GTK_WRAP_WORD = 2;
  public static final int GTK_WRAP_WORD_CHAR = 3;
  public static final int G_BUS_NAME_OWNER_FLAGS_NONE = 0;
  public static final int G_BUS_NAME_OWNER_FLAGS_ALLOW_REPLACEMENT = 1;
  public static final int G_BUS_NAME_OWNER_FLAGS_REPLACE = 2;
  public static final int G_BUS_TYPE_STARTER = -1;
  public static final int G_BUS_TYPE_NONE = 0;
  public static final int G_BUS_TYPE_SYSTEM = 1;
  public static final int G_BUS_TYPE_SESSION = 2;
  public static final int G_DBUS_CALL_FLAGS_NONE = 0;
  public static final int G_DBUS_CALL_FLAGS_NO_AUTO_START = 1;
  public static final int G_DBUS_PROXY_FLAGS_NONE = 0;
  public static final int G_DBUS_PROXY_FLAGS_DO_NOT_LOAD_PROPERTIES = 1;
  public static final int G_DBUS_PROXY_FLAGS_DO_NOT_CONNECT_SIGNALS = 2;
  public static final int G_DBUS_PROXY_FLAGS_DO_NOT_AUTO_START = 4;
  public static final int G_DBUS_PROXY_FLAGS_GET_INVALIDATED_PROPERTIES = 8;
  public static final int G_LOG_FLAG_FATAL = 2;
  public static final int G_LOG_FLAG_RECURSION = 1;
  public static final int G_LOG_LEVEL_MASK = -4;
  public static final int G_APP_INFO_CREATE_NONE = 0;
  public static final int G_APP_INFO_CREATE_NEEDS_TERMINAL = 1;
  public static final int G_APP_INFO_CREATE_SUPPORTS_URIS = 2;
  public static final int None = 0;
  public static final int PANGO_ALIGN_LEFT = 0;
  public static final int PANGO_ALIGN_CENTER = 1;
  public static final int PANGO_ALIGN_RIGHT = 2;
  public static final int PANGO_ATTR_FOREGROUND = 9;
  public static final int PANGO_ATTR_BACKGROUND = 10;
  public static final int PANGO_ATTR_UNDERLINE = 11;
  public static final int PANGO_ATTR_UNDERLINE_COLOR = 18;
  public static final int PANGO_DIRECTION_LTR = 0;
  public static final int PANGO_DIRECTION_RTL = 1;
  public static final int PANGO_SCALE = 1024;
  public static final int PANGO_STRETCH_ULTRA_CONDENSED = 0;
  public static final int PANGO_STRETCH_EXTRA_CONDENSED = 1;
  public static final int PANGO_STRETCH_CONDENSED = 2;
  public static final int PANGO_STRETCH_SEMI_CONDENSED = 3;
  public static final int PANGO_STRETCH_NORMAL = 4;
  public static final int PANGO_STRETCH_SEMI_EXPANDED = 5;
  public static final int PANGO_STRETCH_EXPANDED = 6;
  public static final int PANGO_STRETCH_EXTRA_EXPANDED = 7;
  public static final int PANGO_STRETCH_ULTRA_EXPANDED = 8;
  public static final int PANGO_STYLE_ITALIC = 2;
  public static final int PANGO_STYLE_NORMAL = 0;
  public static final int PANGO_STYLE_OBLIQUE = 1;
  public static final int PANGO_TAB_LEFT = 0;
  public static final int PANGO_UNDERLINE_NONE = 0;
  public static final int PANGO_UNDERLINE_SINGLE = 1;
  public static final int PANGO_UNDERLINE_DOUBLE = 2;
  public static final int PANGO_UNDERLINE_LOW = 3;
  public static final int PANGO_UNDERLINE_ERROR = 4;
  public static final int PANGO_VARIANT_NORMAL = 0;
  public static final int PANGO_VARIANT_SMALL_CAPS = 1;
  public static final int PANGO_WEIGHT_BOLD = 700;
  public static final int PANGO_WEIGHT_NORMAL = 400;
  public static final int PANGO_WRAP_WORD = 0;
  public static final int PANGO_WRAP_WORD_CHAR = 2;
  public static final int RTLD_GLOBAL;
  public static final int RTLD_LAZY;
  public static final int RTLD_MEMBER = 262144;
  public static final int RTLD_NOW;
  public static final int X_OK = 1;
  public static final int XA_CARDINAL = 6;
  public static final int XA_WINDOW = 33;
  public static final byte[] accel_closures_changed;
  public static final byte[] activate;
  public static final byte[] backspace;
  public static final byte[] button_press_event;
  public static final byte[] button_release_event;
  public static final byte[] changed;
  public static final byte[] change_current_page;
  public static final byte[] change_value;
  public static final byte[] clicked;
  public static final byte[] commit;
  public static final byte[] configure_event;
  public static final byte[] copy_clipboard;
  public static final byte[] cut_clipboard;
  public static final byte[] create_menu_proxy;
  public static final byte[] delete_event;
  public static final byte[] delete_from_cursor;
  public static final byte[] day_selected;
  public static final byte[] day_selected_double_click;
  public static final byte[] delete_range;
  public static final byte[] delete_text;
  public static final byte[] direction_changed;
  public static final byte[] drag_data_delete;
  public static final byte[] drag_data_get;
  public static final byte[] drag_data_received;
  public static final byte[] drag_drop;
  public static final byte[] drag_end;
  public static final byte[] drag_leave;
  public static final byte[] drag_motion;
  public static final byte[] draw;
  public static final byte[] enter_notify_event;
  public static final byte[] event;
  public static final byte[] event_after;
  public static final byte[] expand_collapse_cursor_row;
  public static final byte[] expose_event;
  public static final byte[] focus;
  public static final byte[] focus_in_event;
  public static final byte[] focus_out_event;
  public static final byte[] grab_focus;
  public static final byte[] hide;
  public static final byte[] icon_release;
  public static final byte[] input;
  public static final byte[] insert_text;
  public static final byte[] key_press_event;
  public static final byte[] key_release_event;
  public static final byte[] leave_notify_event;
  public static final byte[] link_color;
  public static final byte[] map;
  public static final byte[] map_event;
  public static final byte[] mnemonic_activate;
  public static final byte[] month_changed;
  public static final byte[] motion_notify_event;
  public static final byte[] move_cursor;
  public static final byte[] move_focus;
  public static final byte[] output;
  public static final byte[] paste_clipboard;
  public static final byte[] popup_menu;
  public static final byte[] populate_popup;
  public static final byte[] preedit_changed;
  public static final byte[] property_notify_event;
  public static final byte[] realize;
  public static final byte[] row_activated;
  public static final byte[] row_changed;
  public static final byte[] row_inserted;
  public static final byte[] row_deleted;
  public static final byte[] scroll_child;
  public static final byte[] scroll_event;
  public static final byte[] select;
  public static final byte[] selection_done;
  public static final byte[] show;
  public static final byte[] show_help;
  public static final byte[] size_allocate;
  public static final byte[] size_request;
  public static final byte[] start_interactive_search;
  public static final byte[] style_set;
  public static final byte[] switch_page;
  public static final byte[] test_collapse_row;
  public static final byte[] test_expand_row;
  public static final byte[] toggled;
  public static final byte[] unmap;
  public static final byte[] unmap_event;
  public static final byte[] unrealize;
  public static final byte[] value_changed;
  public static final byte[] visibility_notify_event;
  public static final byte[] window_state_event;
  public static final byte[] GTK_STYLE_CLASS_TOOLTIP;
  public static final byte[] GTK_STYLE_CLASS_VIEW;
  public static final byte[] GTK_STYLE_CLASS_CELL;
  public static final byte[] GTK_STYLE_CLASS_PANE_SEPARATOR;
  public static final byte[] GTK_STYLE_CLASS_FRAME;
  public static final byte[] active;
  public static final byte[] background_gdk;
  public static final byte[] button_relief;
  public static final byte[] cell_background_gdk;
  public static final byte[] default_border;
  public static final byte[] expander_size;
  public static final byte[] fixed_height_mode;
  public static final byte[] focus_line_width;
  public static final byte[] focus_padding;
  public static final byte[] font_desc;
  public static final byte[] foreground_gdk;
  public static final byte[] grid_line_width;
  public static final byte[] gtk_alternative_button_order;
  public static final byte[] gtk_color_palette;
  public static final byte[] gtk_cursor_blink;
  public static final byte[] gtk_cursor_blink_time;
  public static final byte[] gtk_double_click_time;
  public static final byte[] gtk_entry_select_on_focus;
  public static final byte[] gtk_show_input_method_menu;
  public static final byte[] gtk_menu_bar_accel;
  public static final byte[] gtk_menu_images;
  public static final byte[] inner_border;
  public static final byte[] has_backward_stepper;
  public static final byte[] has_secondary_backward_stepper;
  public static final byte[] has_forward_stepper;
  public static final byte[] has_secondary_forward_stepper;
  public static final byte[] horizontal_separator;
  public static final byte[] inconsistent;
  public static final byte[] indicator_size;
  public static final byte[] indicator_spacing;
  public static final byte[] initial_gap;
  public static final byte[] interior_focus;
  public static final byte[] mode;
  public static final byte[] model;
  public static final byte[] spacing;
  public static final byte[] pixbuf;
  public static final byte[] gicon;
  public static final byte[] text;
  public static final byte[] xalign;
  public static final byte[] ypad;
  public static final byte[] GTK_PRINT_SETTINGS_OUTPUT_URI;
  public static final byte[] GTK_STOCK_FIND;
  public static final byte[] GTK_STOCK_CANCEL;
  public static final byte[] GTK_STOCK_CLEAR;
  public static final byte[] G_VARIANT_TYPE_BOOLEAN;
  public static final byte[] G_VARIANT_TYPE_DOUBLE;
  public static final byte[] G_VARIANT_TYPE_STRING;
  public static final byte[] G_VARIANT_TYPE_TUPLE;
  public static final byte[] G_VARIANT_TYPE_UINT64;
  public static final int GTK_VERSION;
  public static final int GLIB_VERSION;
  public static final boolean GTK3;
  public static final boolean USE_CAIRO;
  public static final boolean INIT_CAIRO;
  public static final int Above = 0;
  public static final int Below = 1;
  public static final int ButtonRelease = 5;
  public static final int CurrentTime = 0;
  public static final int CWSibling = 32;
  public static final int CWStackMode = 64;
  public static final int EnterNotify = 7;
  public static final int Expose = 12;
  public static final int FocusChangeMask = 2097152;
  public static final int FocusIn = 9;
  public static final int FocusOut = 10;
  public static final int GraphicsExpose = 13;
  public static final int NoExpose = 14;
  public static final int ExposureMask = 32768;
  public static final int NoEventMask = 0;
  public static final int NotifyNormal = 0;
  public static final int NotifyGrab = 1;
  public static final int NotifyHint = 1;
  public static final int NotifyUngrab = 2;
  public static final int NotifyWhileGrabbed = 3;
  public static final int NotifyAncestor = 0;
  public static final int NotifyVirtual = 1;
  public static final int NotifyNonlinear = 3;
  public static final int NotifyNonlinearVirtual = 4;
  public static final int NotifyPointer = 5;
  public static final int RevertToParent = 2;
  public static final int VisibilityChangeMask = 65536;
  public static final int VisibilityFullyObscured = 2;
  public static final int VisibilityNotify = 15;
  public static final int PictStandardARGB32 = 0;
  public static final int PictStandardRGB24 = 1;
  public static final int PictStandardA8 = 2;
  public static final int PictStandardA4 = 3;
  public static final int PictStandardA1 = 4;
  public static final int PictOpSrc = 1;
  public static final int PictOpOver = 3;
  
  protected static byte[] ascii(String paramString)
  {
    int i = paramString.length();
    char[] arrayOfChar = new char[i];
    paramString.getChars(0, i, arrayOfChar, 0);
    byte[] arrayOfByte = new byte[i + 1];
    for (int j = 0; j < i; j++) {
      arrayOfByte[j] = ((byte)arrayOfChar[j]);
    }
    return arrayOfByte;
  }
  
  public static int VERSION(int paramInt1, int paramInt2, int paramInt3)
  {
    return (paramInt1 << 16) + (paramInt2 << 8) + paramInt3;
  }
  
  public static final native int GInterfaceInfo_sizeof();
  
  public static final native int GPollFD_sizeof();
  
  public static final native int GTypeInfo_sizeof();
  
  public static final native int GTypeQuery_sizeof();
  
  public static final native int GdkColor_sizeof();
  
  public static final native int GdkRGBA_sizeof();
  
  public static final native int GdkDragContext_sizeof();
  
  public static final native int GdkEvent_sizeof();
  
  public static final native int GdkEventAny_sizeof();
  
  public static final native int GdkEventButton_sizeof();
  
  public static final native int GdkEventCrossing_sizeof();
  
  public static final native int GdkEventExpose_sizeof();
  
  public static final native int GdkEventFocus_sizeof();
  
  public static final native int GdkEventKey_sizeof();
  
  public static final native int GdkEventMotion_sizeof();
  
  public static final native int GdkEventProperty_sizeof();
  
  public static final native int GdkEventScroll_sizeof();
  
  public static final native int GdkEventVisibility_sizeof();
  
  public static final native int GdkEventWindowState_sizeof();
  
  public static final native int GdkGeometry_sizeof();
  
  public static final native int GdkRectangle_sizeof();
  
  public static final native int GdkWindowAttr_sizeof();
  
  public static final native int GtkAdjustment_sizeof();
  
  public static final native int GtkAllocation_sizeof();
  
  public static final native int GtkBorder_sizeof();
  
  public static final native int GtkColorSelectionDialog_sizeof();
  
  public static final native int GtkRequisition_sizeof();
  
  public static final native int GtkSelectionData_sizeof();
  
  public static final native int GtkTargetEntry_sizeof();
  
  public static final native int GtkTextIter_sizeof();
  
  public static final native int GtkCellRendererText_sizeof();
  
  public static final native int GtkCellRendererTextClass_sizeof();
  
  public static final native int GtkCellRendererPixbuf_sizeof();
  
  public static final native int GtkCellRendererPixbufClass_sizeof();
  
  public static final native int GtkCellRendererToggle_sizeof();
  
  public static final native int GtkCellRendererToggleClass_sizeof();
  
  public static final native int GtkTreeIter_sizeof();
  
  public static final native int PangoAttribute_sizeof();
  
  public static final native int PangoAttrColor_sizeof();
  
  public static final native int PangoAttrInt_sizeof();
  
  public static final native int PangoItem_sizeof();
  
  public static final native int PangoLayoutLine_sizeof();
  
  public static final native int PangoLayoutRun_sizeof();
  
  public static final native int PangoLogAttr_sizeof();
  
  public static final native int PangoRectangle_sizeof();
  
  public static final native int XAnyEvent_sizeof();
  
  public static final native int XEvent_sizeof();
  
  public static final native int XExposeEvent_sizeof();
  
  public static final native int XFocusChangeEvent_sizeof();
  
  public static final native int XVisibilityEvent_sizeof();
  
  public static final native int XWindowChanges_sizeof();
  
  public static final native int localeconv_decimal_point();
  
  public static final native int realpath(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2);
  
  public static final native int G_OBJECT_CLASS_CONSTRUCTOR(int paramInt);
  
  public static final native void G_OBJECT_CLASS_SET_CONSTRUCTOR(int paramInt1, int paramInt2);
  
  public static final native int GTK_WIDGET_HEIGHT(int paramInt);
  
  public static final native int GTK_WIDGET_WIDTH(int paramInt);
  
  public static final native int GTK_WIDGET_WINDOW(int paramInt);
  
  public static final native int GTK_WIDGET_X(int paramInt);
  
  public static final native int GTK_WIDGET_Y(int paramInt);
  
  public static final native int GTK_RANGE_SLIDER_START(int paramInt);
  
  public static final native int GTK_RANGE_SLIDER_END(int paramInt);
  
  public static final native int GTK_SCROLLED_WINDOW_SCROLLBAR_SPACING(int paramInt);
  
  public static final native void GTK_ACCEL_LABEL_SET_ACCEL_STRING(int paramInt1, int paramInt2);
  
  public static final native int GTK_ACCEL_LABEL_GET_ACCEL_STRING(int paramInt);
  
  public static final native int GTK_ENTRY_IM_CONTEXT(int paramInt);
  
  public static final native int GTK_TEXTVIEW_IM_CONTEXT(int paramInt);
  
  public static final native int GTK_TOOLTIPS_TIP_WINDOW(int paramInt);
  
  public static final native void GTK_TOOLTIPS_SET_ACTIVE(int paramInt1, int paramInt2);
  
  public static final native int GTK_TOOLTIPS_GET_TIP_TEXT(int paramInt);
  
  public static final native void GTK_WIDGET_SET_X(int paramInt1, int paramInt2);
  
  public static final native void GTK_WIDGET_SET_Y(int paramInt1, int paramInt2);
  
  public static final native int GTK_WIDGET_REQUISITION_WIDTH(int paramInt);
  
  public static final native int GTK_WIDGET_REQUISITION_HEIGHT(int paramInt);
  
  public static final native int GDK_EVENT_TYPE(int paramInt);
  
  public static final native int GDK_EVENT_WINDOW(int paramInt);
  
  public static final native int X_EVENT_TYPE(int paramInt);
  
  public static final native int X_EVENT_WINDOW(int paramInt);
  
  public static final native int _Call(int paramInt1, int paramInt2, int paramInt3);
  
  public static final int Call(int paramInt1, int paramInt2, int paramInt3)
  {
    lock.lock();
    try
    {
      int i = _Call(paramInt1, paramInt2, paramInt3);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _call(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8);
  
  public static final int call(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8)
  {
    lock.lock();
    try
    {
      int i = _call(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _call(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5);
  
  public static final int call(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
  {
    lock.lock();
    try
    {
      int i = _call(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _call(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7);
  
  public static final int call(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7)
  {
    lock.lock();
    try
    {
      int i = _call(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _call_get_size(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8);
  
  public static final void call_get_size(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8)
  {
    lock.lock();
    try
    {
      _call_get_size(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean GDK_WINDOWING_X11();
  
  public static final native int _GDK_PIXMAP_XID(int paramInt);
  
  public static final int GDK_PIXMAP_XID(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _GDK_PIXMAP_XID(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _XCheckIfEvent(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  public static final boolean XCheckIfEvent(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    lock.lock();
    try
    {
      boolean bool = _XCheckIfEvent(paramInt1, paramInt2, paramInt3, paramInt4);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _XDefaultScreen(int paramInt);
  
  public static final int XDefaultScreen(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _XDefaultScreen(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _XDefaultRootWindow(int paramInt);
  
  public static final int XDefaultRootWindow(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _XDefaultRootWindow(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _XFlush(int paramInt);
  
  public static final void XFlush(int paramInt)
  {
    lock.lock();
    try
    {
      _XFlush(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _XFree(int paramInt);
  
  public static final void XFree(int paramInt)
  {
    lock.lock();
    try
    {
      _XFree(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _XSetSelectionOwner(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  public static final int XSetSelectionOwner(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    lock.lock();
    try
    {
      int i = _XSetSelectionOwner(paramInt1, paramInt2, paramInt3, paramInt4);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _XGetSelectionOwner(int paramInt1, int paramInt2);
  
  public static final int XGetSelectionOwner(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      int i = _XGetSelectionOwner(paramInt1, paramInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _XGetWindowProperty(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, boolean paramBoolean, int paramInt6, int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3, int[] paramArrayOfInt4, int[] paramArrayOfInt5);
  
  public static final int XGetWindowProperty(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, boolean paramBoolean, int paramInt6, int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3, int[] paramArrayOfInt4, int[] paramArrayOfInt5)
  {
    lock.lock();
    try
    {
      int i = _XGetWindowProperty(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramBoolean, paramInt6, paramArrayOfInt1, paramArrayOfInt2, paramArrayOfInt3, paramArrayOfInt4, paramArrayOfInt5);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _XInternAtom(int paramInt, byte[] paramArrayOfByte, boolean paramBoolean);
  
  public static final int XInternAtom(int paramInt, byte[] paramArrayOfByte, boolean paramBoolean)
  {
    lock.lock();
    try
    {
      int i = _XInternAtom(paramInt, paramArrayOfByte, paramBoolean);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _XQueryPointer(int paramInt1, int paramInt2, int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3, int[] paramArrayOfInt4, int[] paramArrayOfInt5, int[] paramArrayOfInt6, int[] paramArrayOfInt7);
  
  public static final int XQueryPointer(int paramInt1, int paramInt2, int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3, int[] paramArrayOfInt4, int[] paramArrayOfInt5, int[] paramArrayOfInt6, int[] paramArrayOfInt7)
  {
    lock.lock();
    try
    {
      int i = _XQueryPointer(paramInt1, paramInt2, paramArrayOfInt1, paramArrayOfInt2, paramArrayOfInt3, paramArrayOfInt4, paramArrayOfInt5, paramArrayOfInt6, paramArrayOfInt7);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _XKeysymToKeycode(int paramInt1, int paramInt2);
  
  public static final int XKeysymToKeycode(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      int i = _XKeysymToKeycode(paramInt1, paramInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _XListProperties(int paramInt1, int paramInt2, int[] paramArrayOfInt);
  
  public static final int XListProperties(int paramInt1, int paramInt2, int[] paramArrayOfInt)
  {
    lock.lock();
    try
    {
      int i = _XListProperties(paramInt1, paramInt2, paramArrayOfInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _XReconfigureWMWindow(int paramInt1, int paramInt2, int paramInt3, int paramInt4, XWindowChanges paramXWindowChanges);
  
  public static final int XReconfigureWMWindow(int paramInt1, int paramInt2, int paramInt3, int paramInt4, XWindowChanges paramXWindowChanges)
  {
    lock.lock();
    try
    {
      int i = _XReconfigureWMWindow(paramInt1, paramInt2, paramInt3, paramInt4, paramXWindowChanges);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _XSetIOErrorHandler(int paramInt);
  
  public static final int XSetIOErrorHandler(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _XSetIOErrorHandler(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _XSetErrorHandler(int paramInt);
  
  public static final int XSetErrorHandler(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _XSetErrorHandler(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _XSetInputFocus(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  public static final int XSetInputFocus(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    lock.lock();
    try
    {
      int i = _XSetInputFocus(paramInt1, paramInt2, paramInt3, paramInt4);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _XSetTransientForHint(int paramInt1, int paramInt2, int paramInt3);
  
  public static final int XSetTransientForHint(int paramInt1, int paramInt2, int paramInt3)
  {
    lock.lock();
    try
    {
      int i = _XSetTransientForHint(paramInt1, paramInt2, paramInt3);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _XSynchronize(int paramInt, boolean paramBoolean);
  
  public static final int XSynchronize(int paramInt, boolean paramBoolean)
  {
    lock.lock();
    try
    {
      int i = _XSynchronize(paramInt, paramBoolean);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _XTestFakeButtonEvent(int paramInt1, int paramInt2, boolean paramBoolean, int paramInt3);
  
  public static final void XTestFakeButtonEvent(int paramInt1, int paramInt2, boolean paramBoolean, int paramInt3)
  {
    lock.lock();
    try
    {
      _XTestFakeButtonEvent(paramInt1, paramInt2, paramBoolean, paramInt3);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _XTestFakeKeyEvent(int paramInt1, int paramInt2, boolean paramBoolean, int paramInt3);
  
  public static final void XTestFakeKeyEvent(int paramInt1, int paramInt2, boolean paramBoolean, int paramInt3)
  {
    lock.lock();
    try
    {
      _XTestFakeKeyEvent(paramInt1, paramInt2, paramBoolean, paramInt3);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _XTestFakeMotionEvent(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5);
  
  public static final void XTestFakeMotionEvent(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
  {
    lock.lock();
    try
    {
      _XTestFakeMotionEvent(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _XWarpPointer(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9);
  
  public static final int XWarpPointer(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9)
  {
    lock.lock();
    try
    {
      int i = _XWarpPointer(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8, paramInt9);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gdk_x11_atom_to_xatom(int paramInt);
  
  public static final int gdk_x11_atom_to_xatom(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gdk_x11_atom_to_xatom(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gdk_x11_display_get_xdisplay(int paramInt);
  
  public static final int gdk_x11_display_get_xdisplay(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gdk_x11_display_get_xdisplay(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gdk_x11_drawable_get_xdisplay(int paramInt);
  
  public static final int gdk_x11_drawable_get_xdisplay(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gdk_x11_drawable_get_xdisplay(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gdk_x11_drawable_get_xid(int paramInt);
  
  public static final int gdk_x11_drawable_get_xid(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gdk_x11_drawable_get_xid(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gdk_x11_get_default_xdisplay();
  
  public static final int gdk_x11_get_default_xdisplay()
  {
    lock.lock();
    try
    {
      int i = _gdk_x11_get_default_xdisplay();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gdk_x11_screen_lookup_visual(int paramInt1, int paramInt2);
  
  public static final int gdk_x11_screen_lookup_visual(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      int i = _gdk_x11_screen_lookup_visual(paramInt1, paramInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gdk_x11_screen_get_window_manager_name(int paramInt);
  
  public static final int gdk_x11_screen_get_window_manager_name(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gdk_x11_screen_get_window_manager_name(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gdk_x11_visual_get_xvisual(int paramInt);
  
  public static final int gdk_x11_visual_get_xvisual(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gdk_x11_visual_get_xvisual(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gdk_x11_window_get_xid(int paramInt);
  
  public static final int gdk_x11_window_get_xid(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gdk_x11_window_get_xid(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gdk_x11_window_lookup_for_display(int paramInt1, int paramInt2);
  
  public static final int gdk_x11_window_lookup_for_display(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      int i = _gdk_x11_window_lookup_for_display(paramInt1, paramInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gdk_window_lookup(int paramInt);
  
  public static final int gdk_window_lookup(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gdk_window_lookup(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_window_add_filter(int paramInt1, int paramInt2, int paramInt3);
  
  public static final void gdk_window_add_filter(int paramInt1, int paramInt2, int paramInt3)
  {
    lock.lock();
    try
    {
      _gdk_window_add_filter(paramInt1, paramInt2, paramInt3);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_window_remove_filter(int paramInt1, int paramInt2, int paramInt3);
  
  public static final void gdk_window_remove_filter(int paramInt1, int paramInt2, int paramInt3)
  {
    lock.lock();
    try
    {
      _gdk_window_remove_filter(paramInt1, paramInt2, paramInt3);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void memmove(int paramInt1, XExposeEvent paramXExposeEvent, int paramInt2);
  
  public static final native void memmove(XExposeEvent paramXExposeEvent, int paramInt1, int paramInt2);
  
  public static final native void memmove(XFocusChangeEvent paramXFocusChangeEvent, int paramInt1, int paramInt2);
  
  public static final native void memmove(XVisibilityEvent paramXVisibilityEvent, int paramInt1, int paramInt2);
  
  public static final native int RTLD_GLOBAL();
  
  public static final native int RTLD_NOW();
  
  public static final native int RTLD_LAZY();
  
  public static final native int XRenderPictureAttributes_sizeof();
  
  public static final native boolean _XRenderQueryExtension(int paramInt, int[] paramArrayOfInt1, int[] paramArrayOfInt2);
  
  public static final boolean XRenderQueryExtension(int paramInt, int[] paramArrayOfInt1, int[] paramArrayOfInt2)
  {
    lock.lock();
    try
    {
      boolean bool = _XRenderQueryExtension(paramInt, paramArrayOfInt1, paramArrayOfInt2);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _XRenderQueryVersion(int paramInt, int[] paramArrayOfInt1, int[] paramArrayOfInt2);
  
  public static final int XRenderQueryVersion(int paramInt, int[] paramArrayOfInt1, int[] paramArrayOfInt2)
  {
    lock.lock();
    try
    {
      int i = _XRenderQueryVersion(paramInt, paramArrayOfInt1, paramArrayOfInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _XRenderCreatePicture(int paramInt1, int paramInt2, int paramInt3, int paramInt4, XRenderPictureAttributes paramXRenderPictureAttributes);
  
  public static final int XRenderCreatePicture(int paramInt1, int paramInt2, int paramInt3, int paramInt4, XRenderPictureAttributes paramXRenderPictureAttributes)
  {
    lock.lock();
    try
    {
      int i = _XRenderCreatePicture(paramInt1, paramInt2, paramInt3, paramInt4, paramXRenderPictureAttributes);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _XRenderSetPictureClipRectangles(int paramInt1, int paramInt2, int paramInt3, int paramInt4, short[] paramArrayOfShort, int paramInt5);
  
  public static final void XRenderSetPictureClipRectangles(int paramInt1, int paramInt2, int paramInt3, int paramInt4, short[] paramArrayOfShort, int paramInt5)
  {
    lock.lock();
    try
    {
      _XRenderSetPictureClipRectangles(paramInt1, paramInt2, paramInt3, paramInt4, paramArrayOfShort, paramInt5);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _XRenderSetPictureTransform(int paramInt1, int paramInt2, int[] paramArrayOfInt);
  
  public static final void XRenderSetPictureTransform(int paramInt1, int paramInt2, int[] paramArrayOfInt)
  {
    lock.lock();
    try
    {
      _XRenderSetPictureTransform(paramInt1, paramInt2, paramArrayOfInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _XRenderFreePicture(int paramInt1, int paramInt2);
  
  public static final void XRenderFreePicture(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _XRenderFreePicture(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _XRenderComposite(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, int paramInt10, int paramInt11, int paramInt12, int paramInt13);
  
  public static final void XRenderComposite(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, int paramInt10, int paramInt11, int paramInt12, int paramInt13)
  {
    lock.lock();
    try
    {
      _XRenderComposite(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8, paramInt9, paramInt10, paramInt11, paramInt12, paramInt13);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _XRenderFindStandardFormat(int paramInt1, int paramInt2);
  
  public static final int XRenderFindStandardFormat(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      int i = _XRenderFindStandardFormat(paramInt1, paramInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _XRenderFindVisualFormat(int paramInt1, int paramInt2);
  
  public static final int XRenderFindVisualFormat(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      int i = _XRenderFindVisualFormat(paramInt1, paramInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int pangoLayoutNewProc_CALLBACK(int paramInt);
  
  public static final native int pangoFontFamilyNewProc_CALLBACK(int paramInt);
  
  public static final native int pangoFontFaceNewProc_CALLBACK(int paramInt);
  
  public static final native int printerOptionWidgetNewProc_CALLBACK(int paramInt);
  
  public static final native int imContextNewProc_CALLBACK(int paramInt);
  
  public static final native int imContextLast();
  
  public static final native int Call(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  public static final native long Call(int paramInt1, int paramInt2, int paramInt3, long paramLong);
  
  public static final native int _GDK_TYPE_COLOR();
  
  public static final int GDK_TYPE_COLOR()
  {
    lock.lock();
    try
    {
      int i = _GDK_TYPE_COLOR();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _GDK_TYPE_PIXBUF();
  
  public static final int GDK_TYPE_PIXBUF()
  {
    lock.lock();
    try
    {
      int i = _GDK_TYPE_PIXBUF();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int GTK_TYPE_ACCESSIBLE();
  
  public static final native int _GTK_ACCESSIBLE(int paramInt);
  
  public static final native boolean _GTK_IS_ACCEL_LABEL(int paramInt);
  
  public static final boolean GTK_IS_ACCEL_LABEL(int paramInt)
  {
    lock.lock();
    try
    {
      boolean bool = _GTK_IS_ACCEL_LABEL(paramInt);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _GTK_IS_BUTTON(int paramInt);
  
  public static final boolean GTK_IS_BUTTON(int paramInt)
  {
    lock.lock();
    try
    {
      boolean bool = _GTK_IS_BUTTON(paramInt);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _GTK_IS_LABEL(int paramInt);
  
  public static final boolean GTK_IS_LABEL(int paramInt)
  {
    lock.lock();
    try
    {
      boolean bool = _GTK_IS_LABEL(paramInt);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _GTK_IS_SCROLLED_WINDOW(int paramInt);
  
  public static final boolean GTK_IS_SCROLLED_WINDOW(int paramInt)
  {
    lock.lock();
    try
    {
      boolean bool = _GTK_IS_SCROLLED_WINDOW(paramInt);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _GTK_IS_WINDOW(int paramInt);
  
  public static final boolean GTK_IS_WINDOW(int paramInt)
  {
    lock.lock();
    try
    {
      boolean bool = _GTK_IS_WINDOW(paramInt);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _GTK_IS_CELL_RENDERER_PIXBUF(int paramInt);
  
  public static final boolean GTK_IS_CELL_RENDERER_PIXBUF(int paramInt)
  {
    lock.lock();
    try
    {
      boolean bool = _GTK_IS_CELL_RENDERER_PIXBUF(paramInt);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _GTK_IS_CELL_RENDERER_TEXT(int paramInt);
  
  public static final boolean GTK_IS_CELL_RENDERER_TEXT(int paramInt)
  {
    lock.lock();
    try
    {
      boolean bool = _GTK_IS_CELL_RENDERER_TEXT(paramInt);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _GTK_IS_CELL_RENDERER_TOGGLE(int paramInt);
  
  public static final boolean GTK_IS_CELL_RENDERER_TOGGLE(int paramInt)
  {
    lock.lock();
    try
    {
      boolean bool = _GTK_IS_CELL_RENDERER_TOGGLE(paramInt);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _GTK_IS_CONTAINER(int paramInt);
  
  public static final boolean GTK_IS_CONTAINER(int paramInt)
  {
    lock.lock();
    try
    {
      boolean bool = _GTK_IS_CONTAINER(paramInt);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _GTK_IS_IMAGE_MENU_ITEM(int paramInt);
  
  public static final boolean GTK_IS_IMAGE_MENU_ITEM(int paramInt)
  {
    lock.lock();
    try
    {
      boolean bool = _GTK_IS_IMAGE_MENU_ITEM(paramInt);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _GTK_IS_MENU_ITEM(int paramInt);
  
  public static final boolean GTK_IS_MENU_ITEM(int paramInt)
  {
    lock.lock();
    try
    {
      boolean bool = _GTK_IS_MENU_ITEM(paramInt);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _GTK_IS_PLUG(int paramInt);
  
  public static final boolean GTK_IS_PLUG(int paramInt)
  {
    lock.lock();
    try
    {
      boolean bool = _GTK_IS_PLUG(paramInt);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _GTK_IS_SOCKET(int paramInt);
  
  public static final boolean GTK_IS_SOCKET(int paramInt)
  {
    lock.lock();
    try
    {
      boolean bool = _GTK_IS_SOCKET(paramInt);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _GTK_STOCK_CANCEL();
  
  public static final int GTK_STOCK_CANCEL()
  {
    lock.lock();
    try
    {
      int i = _GTK_STOCK_CANCEL();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _GTK_STOCK_OK();
  
  public static final int GTK_STOCK_OK()
  {
    lock.lock();
    try
    {
      int i = _GTK_STOCK_OK();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _GTK_TYPE_CELL_RENDERER_TEXT();
  
  public static final int GTK_TYPE_CELL_RENDERER_TEXT()
  {
    lock.lock();
    try
    {
      int i = _GTK_TYPE_CELL_RENDERER_TEXT();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _GTK_TYPE_CELL_RENDERER_PIXBUF();
  
  public static final int GTK_TYPE_CELL_RENDERER_PIXBUF()
  {
    lock.lock();
    try
    {
      int i = _GTK_TYPE_CELL_RENDERER_PIXBUF();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _GTK_TYPE_CELL_RENDERER_TOGGLE();
  
  public static final int GTK_TYPE_CELL_RENDERER_TOGGLE()
  {
    lock.lock();
    try
    {
      int i = _GTK_TYPE_CELL_RENDERER_TOGGLE();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _GTK_TYPE_IM_MULTICONTEXT();
  
  public static final int GTK_TYPE_IM_MULTICONTEXT()
  {
    lock.lock();
    try
    {
      int i = _GTK_TYPE_IM_MULTICONTEXT();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _GTK_TYPE_FIXED();
  
  public static final int GTK_TYPE_FIXED()
  {
    lock.lock();
    try
    {
      int i = _GTK_TYPE_FIXED();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _GTK_TYPE_MENU();
  
  public static final int GTK_TYPE_MENU()
  {
    lock.lock();
    try
    {
      int i = _GTK_TYPE_MENU();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _GTK_TYPE_WIDGET();
  
  public static final int GTK_TYPE_WIDGET()
  {
    lock.lock();
    try
    {
      int i = _GTK_TYPE_WIDGET();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _GTK_WIDGET_FLAGS(int paramInt);
  
  public static final int GTK_WIDGET_FLAGS(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _GTK_WIDGET_FLAGS(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _GTK_WIDGET_HAS_DEFAULT(int paramInt);
  
  public static final boolean GTK_WIDGET_HAS_DEFAULT(int paramInt)
  {
    lock.lock();
    try
    {
      boolean bool = _GTK_WIDGET_HAS_DEFAULT(paramInt);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _gtk_widget_has_default(int paramInt);
  
  public static final boolean gtk_widget_has_default(int paramInt)
  {
    lock.lock();
    try
    {
      boolean bool = _gtk_widget_has_default(paramInt);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _GTK_WIDGET_HAS_FOCUS(int paramInt);
  
  public static final boolean GTK_WIDGET_HAS_FOCUS(int paramInt)
  {
    lock.lock();
    try
    {
      boolean bool = _GTK_WIDGET_HAS_FOCUS(paramInt);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _GTK_WIDGET_MAPPED(int paramInt);
  
  public static final boolean GTK_WIDGET_MAPPED(int paramInt)
  {
    lock.lock();
    try
    {
      boolean bool = _GTK_WIDGET_MAPPED(paramInt);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _GTK_WIDGET_SENSITIVE(int paramInt);
  
  public static final boolean GTK_WIDGET_SENSITIVE(int paramInt)
  {
    lock.lock();
    try
    {
      boolean bool = _GTK_WIDGET_SENSITIVE(paramInt);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _gtk_widget_get_sensitive(int paramInt);
  
  public static final boolean gtk_widget_get_sensitive(int paramInt)
  {
    lock.lock();
    try
    {
      boolean bool = _gtk_widget_get_sensitive(paramInt);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _GTK_WIDGET_SET_FLAGS(int paramInt1, int paramInt2);
  
  public static final void GTK_WIDGET_SET_FLAGS(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _GTK_WIDGET_SET_FLAGS(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _GTK_WIDGET_UNSET_FLAGS(int paramInt1, int paramInt2);
  
  public static final void GTK_WIDGET_UNSET_FLAGS(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _GTK_WIDGET_UNSET_FLAGS(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _GTK_WIDGET_VISIBLE(int paramInt);
  
  public static final boolean GTK_WIDGET_VISIBLE(int paramInt)
  {
    lock.lock();
    try
    {
      boolean bool = _GTK_WIDGET_VISIBLE(paramInt);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _G_OBJECT_CLASS(int paramInt);
  
  public static final int G_OBJECT_CLASS(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _G_OBJECT_CLASS(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _G_OBJECT_GET_CLASS(int paramInt);
  
  public static final int G_OBJECT_GET_CLASS(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _G_OBJECT_GET_CLASS(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _G_OBJECT_TYPE_NAME(int paramInt);
  
  public static final int G_OBJECT_TYPE_NAME(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _G_OBJECT_TYPE_NAME(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _G_TYPE_CHECK_INSTANCE_TYPE(int paramInt1, int paramInt2);
  
  public static final boolean G_TYPE_CHECK_INSTANCE_TYPE(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      boolean bool = _G_TYPE_CHECK_INSTANCE_TYPE(paramInt1, paramInt2);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int G_TYPE_BOOLEAN();
  
  public static final native int G_TYPE_DOUBLE();
  
  public static final native int G_TYPE_FLOAT();
  
  public static final native int G_TYPE_INT();
  
  public static final native int G_TYPE_INT64();
  
  public static final native int G_VALUE_TYPE(int paramInt);
  
  public static final native int _G_OBJECT_TYPE(int paramInt);
  
  public static final int G_OBJECT_TYPE(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _G_OBJECT_TYPE(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _G_TYPE_STRING();
  
  public static final int G_TYPE_STRING()
  {
    lock.lock();
    try
    {
      int i = _G_TYPE_STRING();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _PANGO_PIXELS(int paramInt);
  
  public static final int PANGO_PIXELS(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _PANGO_PIXELS(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _PANGO_TYPE_FONT_DESCRIPTION();
  
  public static final int PANGO_TYPE_FONT_DESCRIPTION()
  {
    lock.lock();
    try
    {
      int i = _PANGO_TYPE_FONT_DESCRIPTION();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _PANGO_TYPE_FONT_FAMILY();
  
  public static final int PANGO_TYPE_FONT_FAMILY()
  {
    lock.lock();
    try
    {
      int i = _PANGO_TYPE_FONT_FAMILY();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _PANGO_TYPE_FONT_FACE();
  
  public static final int PANGO_TYPE_FONT_FACE()
  {
    lock.lock();
    try
    {
      int i = _PANGO_TYPE_FONT_FACE();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_printer_option_widget_get_type();
  
  public static final int gtk_printer_option_widget_get_type()
  {
    lock.lock();
    try
    {
      int i = _gtk_printer_option_widget_get_type();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _PANGO_TYPE_LAYOUT();
  
  public static final int PANGO_TYPE_LAYOUT()
  {
    lock.lock();
    try
    {
      int i = _PANGO_TYPE_LAYOUT();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _dlclose(int paramInt);
  
  public static final int dlclose(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _dlclose(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _dlopen(byte[] paramArrayOfByte, int paramInt);
  
  public static final int dlopen(byte[] paramArrayOfByte, int paramInt)
  {
    lock.lock();
    try
    {
      int i = _dlopen(paramArrayOfByte, paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _dlsym(int paramInt, byte[] paramArrayOfByte);
  
  public static final int dlsym(int paramInt, byte[] paramArrayOfByte)
  {
    lock.lock();
    try
    {
      int i = _dlsym(paramInt, paramArrayOfByte);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_app_info_create_from_commandline(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, int paramInt1, int paramInt2);
  
  public static final int g_app_info_create_from_commandline(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      int i = _g_app_info_create_from_commandline(paramArrayOfByte1, paramArrayOfByte2, paramInt1, paramInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_app_info_get_all();
  
  public static final int g_app_info_get_all()
  {
    lock.lock();
    try
    {
      int i = _g_app_info_get_all();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_app_info_get_executable(int paramInt);
  
  public static final int g_app_info_get_executable(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _g_app_info_get_executable(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_app_info_get_icon(int paramInt);
  
  public static final int g_app_info_get_icon(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _g_app_info_get_icon(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_app_info_get_name(int paramInt);
  
  public static final int g_app_info_get_name(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _g_app_info_get_name(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _g_app_info_launch(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  public static final boolean g_app_info_launch(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    lock.lock();
    try
    {
      boolean bool = _g_app_info_launch(paramInt1, paramInt2, paramInt3, paramInt4);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_app_info_get_default_for_type(byte[] paramArrayOfByte, boolean paramBoolean);
  
  public static final int g_app_info_get_default_for_type(byte[] paramArrayOfByte, boolean paramBoolean)
  {
    lock.lock();
    try
    {
      int i = _g_app_info_get_default_for_type(paramArrayOfByte, paramBoolean);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _g_app_info_launch_default_for_uri(int paramInt1, int paramInt2, int paramInt3);
  
  public static final boolean g_app_info_launch_default_for_uri(int paramInt1, int paramInt2, int paramInt3)
  {
    lock.lock();
    try
    {
      boolean bool = _g_app_info_launch_default_for_uri(paramInt1, paramInt2, paramInt3);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _g_app_info_should_show(int paramInt);
  
  public static final boolean g_app_info_should_show(int paramInt)
  {
    lock.lock();
    try
    {
      boolean bool = _g_app_info_should_show(paramInt);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _g_app_info_supports_uris(int paramInt);
  
  public static final boolean g_app_info_supports_uris(int paramInt)
  {
    lock.lock();
    try
    {
      boolean bool = _g_app_info_supports_uris(paramInt);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_bus_get_sync(int paramInt1, int paramInt2, int paramInt3);
  
  public static final int g_bus_get_sync(int paramInt1, int paramInt2, int paramInt3)
  {
    lock.lock();
    try
    {
      int i = _g_bus_get_sync(paramInt1, paramInt2, paramInt3);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_bus_own_name(int paramInt1, byte[] paramArrayOfByte, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7);
  
  public static final int g_bus_own_name(int paramInt1, byte[] paramArrayOfByte, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7)
  {
    lock.lock();
    try
    {
      int i = _g_bus_own_name(paramInt1, paramArrayOfByte, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_dbus_connection_register_object(int paramInt1, byte[] paramArrayOfByte, int paramInt2, int[] paramArrayOfInt1, int paramInt3, int paramInt4, int[] paramArrayOfInt2);
  
  public static final int g_dbus_connection_register_object(int paramInt1, byte[] paramArrayOfByte, int paramInt2, int[] paramArrayOfInt1, int paramInt3, int paramInt4, int[] paramArrayOfInt2)
  {
    lock.lock();
    try
    {
      int i = _g_dbus_connection_register_object(paramInt1, paramArrayOfByte, paramInt2, paramArrayOfInt1, paramInt3, paramInt4, paramArrayOfInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_dbus_node_info_lookup_interface(int paramInt, byte[] paramArrayOfByte);
  
  public static final int g_dbus_node_info_lookup_interface(int paramInt, byte[] paramArrayOfByte)
  {
    lock.lock();
    try
    {
      int i = _g_dbus_node_info_lookup_interface(paramInt, paramArrayOfByte);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_dbus_node_info_new_for_xml(byte[] paramArrayOfByte, int[] paramArrayOfInt);
  
  public static final int g_dbus_node_info_new_for_xml(byte[] paramArrayOfByte, int[] paramArrayOfInt)
  {
    lock.lock();
    try
    {
      int i = _g_dbus_node_info_new_for_xml(paramArrayOfByte, paramArrayOfInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _g_dbus_method_invocation_return_value(int paramInt1, int paramInt2);
  
  public static final void g_dbus_method_invocation_return_value(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _g_dbus_method_invocation_return_value(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _g_dbus_proxy_call(int paramInt1, byte[] paramArrayOfByte, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7);
  
  public static final void g_dbus_proxy_call(int paramInt1, byte[] paramArrayOfByte, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7)
  {
    lock.lock();
    try
    {
      _g_dbus_proxy_call(paramInt1, paramArrayOfByte, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_dbus_proxy_call_finish(int paramInt1, int paramInt2, int[] paramArrayOfInt);
  
  public static final int g_dbus_proxy_call_finish(int paramInt1, int paramInt2, int[] paramArrayOfInt)
  {
    lock.lock();
    try
    {
      int i = _g_dbus_proxy_call_finish(paramInt1, paramInt2, paramArrayOfInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_dbus_proxy_call_sync(int paramInt1, byte[] paramArrayOfByte, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int[] paramArrayOfInt);
  
  public static final int g_dbus_proxy_call_sync(int paramInt1, byte[] paramArrayOfByte, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int[] paramArrayOfInt)
  {
    lock.lock();
    try
    {
      int i = _g_dbus_proxy_call_sync(paramInt1, paramArrayOfByte, paramInt2, paramInt3, paramInt4, paramInt5, paramArrayOfInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _g_dbus_proxy_new(int paramInt1, int paramInt2, int paramInt3, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3, int paramInt4, int paramInt5, int paramInt6);
  
  public static final void g_dbus_proxy_new(int paramInt1, int paramInt2, int paramInt3, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3, int paramInt4, int paramInt5, int paramInt6)
  {
    lock.lock();
    try
    {
      _g_dbus_proxy_new(paramInt1, paramInt2, paramInt3, paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte3, paramInt4, paramInt5, paramInt6);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_dbus_proxy_new_finish(int paramInt, int[] paramArrayOfInt);
  
  public static final int g_dbus_proxy_new_finish(int paramInt, int[] paramArrayOfInt)
  {
    lock.lock();
    try
    {
      int i = _g_dbus_proxy_new_finish(paramInt, paramArrayOfInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_dbus_proxy_new_sync(int paramInt1, int paramInt2, int paramInt3, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3, int paramInt4, int[] paramArrayOfInt);
  
  public static final int g_dbus_proxy_new_sync(int paramInt1, int paramInt2, int paramInt3, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3, int paramInt4, int[] paramArrayOfInt)
  {
    lock.lock();
    try
    {
      int i = _g_dbus_proxy_new_sync(paramInt1, paramInt2, paramInt3, paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte3, paramInt4, paramArrayOfInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_data_input_stream_new(int paramInt);
  
  public static final int g_data_input_stream_new(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _g_data_input_stream_new(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_error_get_message(int paramInt);
  
  public static final int g_error_get_message(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _g_error_get_message(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_data_input_stream_read_line(int paramInt1, int[] paramArrayOfInt, int paramInt2, int paramInt3);
  
  public static final int g_data_input_stream_read_line(int paramInt1, int[] paramArrayOfInt, int paramInt2, int paramInt3)
  {
    lock.lock();
    try
    {
      int i = _g_data_input_stream_read_line(paramInt1, paramArrayOfInt, paramInt2, paramInt3);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _g_content_type_equals(int paramInt, byte[] paramArrayOfByte);
  
  public static final boolean g_content_type_equals(int paramInt, byte[] paramArrayOfByte)
  {
    lock.lock();
    try
    {
      boolean bool = _g_content_type_equals(paramInt, paramArrayOfByte);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _g_content_type_is_a(int paramInt, byte[] paramArrayOfByte);
  
  public static final boolean g_content_type_is_a(int paramInt, byte[] paramArrayOfByte)
  {
    lock.lock();
    try
    {
      boolean bool = _g_content_type_is_a(paramInt, paramArrayOfByte);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_file_info_get_content_type(int paramInt);
  
  public static final int g_file_info_get_content_type(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _g_file_info_get_content_type(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_file_get_uri(int paramInt);
  
  public static final int g_file_get_uri(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _g_file_get_uri(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _g_file_info_get_modification_time(int paramInt, int[] paramArrayOfInt);
  
  public static final void g_file_info_get_modification_time(int paramInt, int[] paramArrayOfInt)
  {
    lock.lock();
    try
    {
      _g_file_info_get_modification_time(paramInt, paramArrayOfInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_file_new_for_path(byte[] paramArrayOfByte);
  
  public static final int g_file_new_for_path(byte[] paramArrayOfByte)
  {
    lock.lock();
    try
    {
      int i = _g_file_new_for_path(paramArrayOfByte);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_file_new_for_commandline_arg(byte[] paramArrayOfByte);
  
  public static final int g_file_new_for_commandline_arg(byte[] paramArrayOfByte)
  {
    lock.lock();
    try
    {
      int i = _g_file_new_for_commandline_arg(paramArrayOfByte);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_file_new_for_uri(byte[] paramArrayOfByte);
  
  public static final int g_file_new_for_uri(byte[] paramArrayOfByte)
  {
    lock.lock();
    try
    {
      int i = _g_file_new_for_uri(paramArrayOfByte);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_file_query_info(int paramInt1, byte[] paramArrayOfByte, int paramInt2, int paramInt3, int paramInt4);
  
  public static final int g_file_query_info(int paramInt1, byte[] paramArrayOfByte, int paramInt2, int paramInt3, int paramInt4)
  {
    lock.lock();
    try
    {
      int i = _g_file_query_info(paramInt1, paramArrayOfByte, paramInt2, paramInt3, paramInt4);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_file_read(int paramInt1, int paramInt2, int paramInt3);
  
  public static final int g_file_read(int paramInt1, int paramInt2, int paramInt3)
  {
    lock.lock();
    try
    {
      int i = _g_file_read(paramInt1, paramInt2, paramInt3);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _g_file_test(byte[] paramArrayOfByte, int paramInt);
  
  public static final boolean g_file_test(byte[] paramArrayOfByte, int paramInt)
  {
    lock.lock();
    try
    {
      boolean bool = _g_file_test(paramArrayOfByte, paramInt);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_icon_to_string(int paramInt);
  
  public static final int g_icon_to_string(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _g_icon_to_string(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_icon_new_for_string(byte[] paramArrayOfByte, int[] paramArrayOfInt);
  
  public static final int g_icon_new_for_string(byte[] paramArrayOfByte, int[] paramArrayOfInt)
  {
    lock.lock();
    try
    {
      int i = _g_icon_new_for_string(paramArrayOfByte, paramArrayOfInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_signal_add_emission_hook(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5);
  
  public static final int g_signal_add_emission_hook(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
  {
    lock.lock();
    try
    {
      int i = _g_signal_add_emission_hook(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _g_signal_remove_emission_hook(int paramInt1, int paramInt2);
  
  public static final void g_signal_remove_emission_hook(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _g_signal_remove_emission_hook(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_cclosure_new(int paramInt1, int paramInt2, int paramInt3);
  
  public static final int g_cclosure_new(int paramInt1, int paramInt2, int paramInt3)
  {
    lock.lock();
    try
    {
      int i = _g_cclosure_new(paramInt1, paramInt2, paramInt3);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_closure_ref(int paramInt);
  
  public static final int g_closure_ref(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _g_closure_ref(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _g_closure_sink(int paramInt);
  
  public static final void g_closure_sink(int paramInt)
  {
    lock.lock();
    try
    {
      _g_closure_sink(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _g_closure_unref(int paramInt);
  
  public static final void g_closure_unref(int paramInt)
  {
    lock.lock();
    try
    {
      _g_closure_unref(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _g_main_context_acquire(int paramInt);
  
  public static final boolean g_main_context_acquire(int paramInt)
  {
    lock.lock();
    try
    {
      boolean bool = _g_main_context_acquire(paramInt);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_main_context_check(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  public static final int g_main_context_check(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    lock.lock();
    try
    {
      int i = _g_main_context_check(paramInt1, paramInt2, paramInt3, paramInt4);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_main_context_default();
  
  public static final int g_main_context_default()
  {
    lock.lock();
    try
    {
      int i = _g_main_context_default();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _g_main_context_iteration(int paramInt, boolean paramBoolean);
  
  public static final boolean g_main_context_iteration(int paramInt, boolean paramBoolean)
  {
    lock.lock();
    try
    {
      boolean bool = _g_main_context_iteration(paramInt, paramBoolean);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_main_context_get_poll_func(int paramInt);
  
  public static final int g_main_context_get_poll_func(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _g_main_context_get_poll_func(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _g_main_context_prepare(int paramInt, int[] paramArrayOfInt);
  
  public static final boolean g_main_context_prepare(int paramInt, int[] paramArrayOfInt)
  {
    lock.lock();
    try
    {
      boolean bool = _g_main_context_prepare(paramInt, paramArrayOfInt);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_main_context_query(int paramInt1, int paramInt2, int[] paramArrayOfInt, int paramInt3, int paramInt4);
  
  public static final int g_main_context_query(int paramInt1, int paramInt2, int[] paramArrayOfInt, int paramInt3, int paramInt4)
  {
    lock.lock();
    try
    {
      int i = _g_main_context_query(paramInt1, paramInt2, paramArrayOfInt, paramInt3, paramInt4);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _g_main_context_release(int paramInt);
  
  public static final void g_main_context_release(int paramInt)
  {
    lock.lock();
    try
    {
      _g_main_context_release(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void g_main_context_wakeup(int paramInt);
  
  public static final native int _g_filename_to_utf8(int paramInt1, int paramInt2, int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3);
  
  public static final int g_filename_to_utf8(int paramInt1, int paramInt2, int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3)
  {
    lock.lock();
    try
    {
      int i = _g_filename_to_utf8(paramInt1, paramInt2, paramArrayOfInt1, paramArrayOfInt2, paramArrayOfInt3);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_filename_display_name(int paramInt);
  
  public static final int g_filename_display_name(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _g_filename_display_name(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_filename_to_uri(int paramInt1, int paramInt2, int[] paramArrayOfInt);
  
  public static final int g_filename_to_uri(int paramInt1, int paramInt2, int[] paramArrayOfInt)
  {
    lock.lock();
    try
    {
      int i = _g_filename_to_uri(paramInt1, paramInt2, paramArrayOfInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_filename_from_utf8(int paramInt1, int paramInt2, int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3);
  
  public static final int g_filename_from_utf8(int paramInt1, int paramInt2, int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3)
  {
    lock.lock();
    try
    {
      int i = _g_filename_from_utf8(paramInt1, paramInt2, paramArrayOfInt1, paramArrayOfInt2, paramArrayOfInt3);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_filename_from_uri(int paramInt, int[] paramArrayOfInt1, int[] paramArrayOfInt2);
  
  public static final int g_filename_from_uri(int paramInt, int[] paramArrayOfInt1, int[] paramArrayOfInt2)
  {
    lock.lock();
    try
    {
      int i = _g_filename_from_uri(paramInt, paramArrayOfInt1, paramArrayOfInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _g_free(int paramInt);
  
  public static final void g_free(int paramInt)
  {
    lock.lock();
    try
    {
      _g_free(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_idle_add(int paramInt1, int paramInt2);
  
  public static final int g_idle_add(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      int i = _g_idle_add(paramInt1, paramInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_list_append(int paramInt1, int paramInt2);
  
  public static final int g_list_append(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      int i = _g_list_append(paramInt1, paramInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_list_data(int paramInt);
  
  public static final int g_list_data(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _g_list_data(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _g_list_free(int paramInt);
  
  public static final void g_list_free(int paramInt)
  {
    lock.lock();
    try
    {
      _g_list_free(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _g_list_free_1(int paramInt);
  
  public static final void g_list_free_1(int paramInt)
  {
    lock.lock();
    try
    {
      _g_list_free_1(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_list_last(int paramInt);
  
  public static final int g_list_last(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _g_list_last(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_list_length(int paramInt);
  
  public static final int g_list_length(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _g_list_length(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _g_list_set_next(int paramInt1, int paramInt2);
  
  public static final void g_list_set_next(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _g_list_set_next(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_list_next(int paramInt);
  
  public static final int g_list_next(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _g_list_next(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_list_nth(int paramInt1, int paramInt2);
  
  public static final int g_list_nth(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      int i = _g_list_nth(paramInt1, paramInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_list_nth_data(int paramInt1, int paramInt2);
  
  public static final int g_list_nth_data(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      int i = _g_list_nth_data(paramInt1, paramInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_list_prepend(int paramInt1, int paramInt2);
  
  public static final int g_list_prepend(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      int i = _g_list_prepend(paramInt1, paramInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _g_list_set_previous(int paramInt1, int paramInt2);
  
  public static final void g_list_set_previous(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _g_list_set_previous(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_list_previous(int paramInt);
  
  public static final int g_list_previous(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _g_list_previous(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_list_remove_link(int paramInt1, int paramInt2);
  
  public static final int g_list_remove_link(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      int i = _g_list_remove_link(paramInt1, paramInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _g_log_default_handler(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  public static final void g_log_default_handler(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    lock.lock();
    try
    {
      _g_log_default_handler(paramInt1, paramInt2, paramInt3, paramInt4);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _g_log_remove_handler(byte[] paramArrayOfByte, int paramInt);
  
  public static final void g_log_remove_handler(byte[] paramArrayOfByte, int paramInt)
  {
    lock.lock();
    try
    {
      _g_log_remove_handler(paramArrayOfByte, paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_log_set_handler(byte[] paramArrayOfByte, int paramInt1, int paramInt2, int paramInt3);
  
  public static final int g_log_set_handler(byte[] paramArrayOfByte, int paramInt1, int paramInt2, int paramInt3)
  {
    lock.lock();
    try
    {
      int i = _g_log_set_handler(paramArrayOfByte, paramInt1, paramInt2, paramInt3);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_malloc(int paramInt);
  
  public static final int g_malloc(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _g_malloc(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_object_class_find_property(int paramInt, byte[] paramArrayOfByte);
  
  public static final int g_object_class_find_property(int paramInt, byte[] paramArrayOfByte)
  {
    lock.lock();
    try
    {
      int i = _g_object_class_find_property(paramInt, paramArrayOfByte);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _g_object_get(int paramInt1, byte[] paramArrayOfByte, int[] paramArrayOfInt, int paramInt2);
  
  public static final void g_object_get(int paramInt1, byte[] paramArrayOfByte, int[] paramArrayOfInt, int paramInt2)
  {
    lock.lock();
    try
    {
      _g_object_get(paramInt1, paramArrayOfByte, paramArrayOfInt, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _g_object_get(int paramInt1, byte[] paramArrayOfByte, long[] paramArrayOfLong, int paramInt2);
  
  public static final void g_object_get(int paramInt1, byte[] paramArrayOfByte, long[] paramArrayOfLong, int paramInt2)
  {
    lock.lock();
    try
    {
      _g_object_get(paramInt1, paramArrayOfByte, paramArrayOfLong, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_object_get_qdata(int paramInt1, int paramInt2);
  
  public static final int g_object_get_qdata(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      int i = _g_object_get_qdata(paramInt1, paramInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_object_new(int paramInt1, int paramInt2);
  
  public static final int g_object_new(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      int i = _g_object_new(paramInt1, paramInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _g_object_notify(int paramInt, byte[] paramArrayOfByte);
  
  public static final void g_object_notify(int paramInt, byte[] paramArrayOfByte)
  {
    lock.lock();
    try
    {
      _g_object_notify(paramInt, paramArrayOfByte);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_object_ref(int paramInt);
  
  public static final int g_object_ref(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _g_object_ref(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _g_object_set(int paramInt1, byte[] paramArrayOfByte, boolean paramBoolean, int paramInt2);
  
  public static final void g_object_set(int paramInt1, byte[] paramArrayOfByte, boolean paramBoolean, int paramInt2)
  {
    lock.lock();
    try
    {
      _g_object_set(paramInt1, paramArrayOfByte, paramBoolean, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _g_object_set(int paramInt1, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, int paramInt2);
  
  public static final void g_object_set(int paramInt1, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, int paramInt2)
  {
    lock.lock();
    try
    {
      _g_object_set(paramInt1, paramArrayOfByte1, paramArrayOfByte2, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _g_object_set(int paramInt1, byte[] paramArrayOfByte, GdkColor paramGdkColor, int paramInt2);
  
  public static final void g_object_set(int paramInt1, byte[] paramArrayOfByte, GdkColor paramGdkColor, int paramInt2)
  {
    lock.lock();
    try
    {
      _g_object_set(paramInt1, paramArrayOfByte, paramGdkColor, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _g_object_set(int paramInt1, byte[] paramArrayOfByte, int paramInt2, int paramInt3);
  
  public static final void g_object_set(int paramInt1, byte[] paramArrayOfByte, int paramInt2, int paramInt3)
  {
    lock.lock();
    try
    {
      _g_object_set(paramInt1, paramArrayOfByte, paramInt2, paramInt3);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _g_object_set(int paramInt1, byte[] paramArrayOfByte, float paramFloat, int paramInt2);
  
  public static final void g_object_set(int paramInt1, byte[] paramArrayOfByte, float paramFloat, int paramInt2)
  {
    lock.lock();
    try
    {
      _g_object_set(paramInt1, paramArrayOfByte, paramFloat, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _g_object_set(int paramInt1, byte[] paramArrayOfByte, long paramLong, int paramInt2);
  
  public static final void g_object_set(int paramInt1, byte[] paramArrayOfByte, long paramLong, int paramInt2)
  {
    lock.lock();
    try
    {
      _g_object_set(paramInt1, paramArrayOfByte, paramLong, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _g_object_set_qdata(int paramInt1, int paramInt2, int paramInt3);
  
  public static final void g_object_set_qdata(int paramInt1, int paramInt2, int paramInt3)
  {
    lock.lock();
    try
    {
      _g_object_set_qdata(paramInt1, paramInt2, paramInt3);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _g_object_unref(int paramInt);
  
  public static final void g_object_unref(int paramInt)
  {
    lock.lock();
    try
    {
      _g_object_unref(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_quark_from_string(byte[] paramArrayOfByte);
  
  public static final int g_quark_from_string(byte[] paramArrayOfByte)
  {
    lock.lock();
    try
    {
      int i = _g_quark_from_string(paramArrayOfByte);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _g_set_prgname(byte[] paramArrayOfByte);
  
  public static final void g_set_prgname(byte[] paramArrayOfByte)
  {
    lock.lock();
    try
    {
      _g_set_prgname(paramArrayOfByte);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_signal_connect(int paramInt1, byte[] paramArrayOfByte, int paramInt2, int paramInt3);
  
  public static final int g_signal_connect(int paramInt1, byte[] paramArrayOfByte, int paramInt2, int paramInt3)
  {
    lock.lock();
    try
    {
      int i = _g_signal_connect(paramInt1, paramArrayOfByte, paramInt2, paramInt3);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_signal_connect_closure(int paramInt1, byte[] paramArrayOfByte, int paramInt2, boolean paramBoolean);
  
  public static final int g_signal_connect_closure(int paramInt1, byte[] paramArrayOfByte, int paramInt2, boolean paramBoolean)
  {
    lock.lock();
    try
    {
      int i = _g_signal_connect_closure(paramInt1, paramArrayOfByte, paramInt2, paramBoolean);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_signal_connect_closure_by_id(int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean);
  
  public static final int g_signal_connect_closure_by_id(int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean)
  {
    lock.lock();
    try
    {
      int i = _g_signal_connect_closure_by_id(paramInt1, paramInt2, paramInt3, paramInt4, paramBoolean);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _g_signal_emit_by_name(int paramInt, byte[] paramArrayOfByte);
  
  public static final void g_signal_emit_by_name(int paramInt, byte[] paramArrayOfByte)
  {
    lock.lock();
    try
    {
      _g_signal_emit_by_name(paramInt, paramArrayOfByte);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _g_signal_emit_by_name(int paramInt1, byte[] paramArrayOfByte, int paramInt2);
  
  public static final void g_signal_emit_by_name(int paramInt1, byte[] paramArrayOfByte, int paramInt2)
  {
    lock.lock();
    try
    {
      _g_signal_emit_by_name(paramInt1, paramArrayOfByte, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _g_signal_emit_by_name(int paramInt, byte[] paramArrayOfByte, GdkRectangle paramGdkRectangle);
  
  public static final void g_signal_emit_by_name(int paramInt, byte[] paramArrayOfByte, GdkRectangle paramGdkRectangle)
  {
    lock.lock();
    try
    {
      _g_signal_emit_by_name(paramInt, paramArrayOfByte, paramGdkRectangle);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _g_signal_emit_by_name(int paramInt1, byte[] paramArrayOfByte, int paramInt2, int paramInt3);
  
  public static final void g_signal_emit_by_name(int paramInt1, byte[] paramArrayOfByte, int paramInt2, int paramInt3)
  {
    lock.lock();
    try
    {
      _g_signal_emit_by_name(paramInt1, paramArrayOfByte, paramInt2, paramInt3);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _g_signal_emit_by_name(int paramInt, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2);
  
  public static final void g_signal_emit_by_name(int paramInt, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    lock.lock();
    try
    {
      _g_signal_emit_by_name(paramInt, paramArrayOfByte1, paramArrayOfByte2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _g_signal_handler_disconnect(int paramInt1, int paramInt2);
  
  public static final void g_signal_handler_disconnect(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _g_signal_handler_disconnect(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_signal_handler_find(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7);
  
  public static final int g_signal_handler_find(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7)
  {
    lock.lock();
    try
    {
      int i = _g_signal_handler_find(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_signal_handlers_block_matched(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7);
  
  public static final int g_signal_handlers_block_matched(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7)
  {
    lock.lock();
    try
    {
      int i = _g_signal_handlers_block_matched(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_signal_handlers_unblock_matched(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7);
  
  public static final int g_signal_handlers_unblock_matched(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7)
  {
    lock.lock();
    try
    {
      int i = _g_signal_handlers_unblock_matched(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_signal_lookup(byte[] paramArrayOfByte, int paramInt);
  
  public static final int g_signal_lookup(byte[] paramArrayOfByte, int paramInt)
  {
    lock.lock();
    try
    {
      int i = _g_signal_lookup(paramArrayOfByte, paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _g_signal_stop_emission_by_name(int paramInt, byte[] paramArrayOfByte);
  
  public static final void g_signal_stop_emission_by_name(int paramInt, byte[] paramArrayOfByte)
  {
    lock.lock();
    try
    {
      _g_signal_stop_emission_by_name(paramInt, paramArrayOfByte);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _g_source_remove(int paramInt);
  
  public static final boolean g_source_remove(int paramInt)
  {
    lock.lock();
    try
    {
      boolean bool = _g_source_remove(paramInt);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_slist_append(int paramInt1, int paramInt2);
  
  public static final int g_slist_append(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      int i = _g_slist_append(paramInt1, paramInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_slist_data(int paramInt);
  
  public static final int g_slist_data(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _g_slist_data(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _g_slist_free(int paramInt);
  
  public static final void g_slist_free(int paramInt)
  {
    lock.lock();
    try
    {
      _g_slist_free(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_slist_next(int paramInt);
  
  public static final int g_slist_next(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _g_slist_next(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_slist_length(int paramInt);
  
  public static final int g_slist_length(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _g_slist_length(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _g_strfreev(int paramInt);
  
  public static final void g_strfreev(int paramInt)
  {
    lock.lock();
    try
    {
      _g_strfreev(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _GString_len(int paramInt);
  
  public static final int GString_len(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _GString_len(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _GString_str(int paramInt);
  
  public static final int GString_str(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _GString_str(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native double _g_strtod(int paramInt, int[] paramArrayOfInt);
  
  public static final double g_strtod(int paramInt, int[] paramArrayOfInt)
  {
    lock.lock();
    try
    {
      double d = _g_strtod(paramInt, paramArrayOfInt);
      return d;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _g_type_add_interface_static(int paramInt1, int paramInt2, int paramInt3);
  
  public static final void g_type_add_interface_static(int paramInt1, int paramInt2, int paramInt3)
  {
    lock.lock();
    try
    {
      _g_type_add_interface_static(paramInt1, paramInt2, paramInt3);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_type_class_peek(int paramInt);
  
  public static final int g_type_class_peek(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _g_type_class_peek(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_type_class_peek_parent(int paramInt);
  
  public static final int g_type_class_peek_parent(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _g_type_class_peek_parent(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_type_class_ref(int paramInt);
  
  public static final int g_type_class_ref(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _g_type_class_ref(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _g_type_class_unref(int paramInt);
  
  public static final void g_type_class_unref(int paramInt)
  {
    lock.lock();
    try
    {
      _g_type_class_unref(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_type_from_name(byte[] paramArrayOfByte);
  
  public static final int g_type_from_name(byte[] paramArrayOfByte)
  {
    lock.lock();
    try
    {
      int i = _g_type_from_name(paramArrayOfByte);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_type_interface_peek_parent(int paramInt);
  
  public static final int g_type_interface_peek_parent(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _g_type_interface_peek_parent(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _g_type_is_a(int paramInt1, int paramInt2);
  
  public static final boolean g_type_is_a(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      boolean bool = _g_type_is_a(paramInt1, paramInt2);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_type_name(int paramInt);
  
  public static final int g_type_name(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _g_type_name(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_type_parent(int paramInt);
  
  public static final int g_type_parent(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _g_type_parent(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _g_type_query(int paramInt1, int paramInt2);
  
  public static final void g_type_query(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _g_type_query(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_type_register_static(int paramInt1, byte[] paramArrayOfByte, int paramInt2, int paramInt3);
  
  public static final int g_type_register_static(int paramInt1, byte[] paramArrayOfByte, int paramInt2, int paramInt3)
  {
    lock.lock();
    try
    {
      int i = _g_type_register_static(paramInt1, paramArrayOfByte, paramInt2, paramInt3);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _g_thread_init(int paramInt);
  
  public static final void g_thread_init(int paramInt)
  {
    lock.lock();
    try
    {
      _g_thread_init(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _g_thread_supported();
  
  public static final boolean g_thread_supported()
  {
    lock.lock();
    try
    {
      boolean bool = _g_thread_supported();
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_utf16_to_utf8(char[] paramArrayOfChar, int paramInt, int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3);
  
  public static final int g_utf16_to_utf8(char[] paramArrayOfChar, int paramInt, int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3)
  {
    lock.lock();
    try
    {
      int i = _g_utf16_to_utf8(paramArrayOfChar, paramInt, paramArrayOfInt1, paramArrayOfInt2, paramArrayOfInt3);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_utf8_pointer_to_offset(int paramInt1, int paramInt2);
  
  public static final int g_utf8_pointer_to_offset(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      int i = _g_utf8_pointer_to_offset(paramInt1, paramInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_utf16_offset_to_pointer(int paramInt1, int paramInt2);
  
  public static final int g_utf16_offset_to_pointer(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      int i = _g_utf16_offset_to_pointer(paramInt1, paramInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_utf16_pointer_to_offset(int paramInt1, int paramInt2);
  
  public static final int g_utf16_pointer_to_offset(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      int i = _g_utf16_pointer_to_offset(paramInt1, paramInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_utf16_strlen(int paramInt1, int paramInt2);
  
  public static final int g_utf16_strlen(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      int i = _g_utf16_strlen(paramInt1, paramInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_utf8_offset_to_utf16_offset(int paramInt1, int paramInt2);
  
  public static final int g_utf8_offset_to_utf16_offset(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      int i = _g_utf8_offset_to_utf16_offset(paramInt1, paramInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_utf16_offset_to_utf8_offset(int paramInt1, int paramInt2);
  
  public static final int g_utf16_offset_to_utf8_offset(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      int i = _g_utf16_offset_to_utf8_offset(paramInt1, paramInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_utf8_strlen(int paramInt1, int paramInt2);
  
  public static final int g_utf8_strlen(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      int i = _g_utf8_strlen(paramInt1, paramInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_utf8_to_utf16(byte[] paramArrayOfByte, int paramInt, int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3);
  
  public static final int g_utf8_to_utf16(byte[] paramArrayOfByte, int paramInt, int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3)
  {
    lock.lock();
    try
    {
      int i = _g_utf8_to_utf16(paramArrayOfByte, paramInt, paramArrayOfInt1, paramArrayOfInt2, paramArrayOfInt3);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_utf8_to_utf16(int paramInt1, int paramInt2, int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3);
  
  public static final int g_utf8_to_utf16(int paramInt1, int paramInt2, int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3)
  {
    lock.lock();
    try
    {
      int i = _g_utf8_to_utf16(paramInt1, paramInt2, paramArrayOfInt1, paramArrayOfInt2, paramArrayOfInt3);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int g_value_init(int paramInt1, int paramInt2);
  
  public static final native int g_value_get_int(int paramInt);
  
  public static final native void g_value_set_int(int paramInt1, int paramInt2);
  
  public static final native double g_value_get_double(int paramInt);
  
  public static final native void g_value_set_double(int paramInt, double paramDouble);
  
  public static final native float g_value_get_float(int paramInt);
  
  public static final native void g_value_set_float(int paramInt, float paramFloat);
  
  public static final native long g_value_get_int64(int paramInt);
  
  public static final native void g_value_set_int64(int paramInt, long paramLong);
  
  public static final native void g_value_unset(int paramInt);
  
  public static final native int _g_value_peek_pointer(int paramInt);
  
  public static final int g_value_peek_pointer(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _g_value_peek_pointer(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _g_variant_get_boolean(int paramInt);
  
  public static final boolean g_variant_get_boolean(int paramInt)
  {
    lock.lock();
    try
    {
      boolean bool = _g_variant_get_boolean(paramInt);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_variant_get_child_value(int paramInt1, int paramInt2);
  
  public static final int g_variant_get_child_value(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      int i = _g_variant_get_child_value(paramInt1, paramInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native double _g_variant_get_double(int paramInt);
  
  public static final double g_variant_get_double(int paramInt)
  {
    lock.lock();
    try
    {
      double d = _g_variant_get_double(paramInt);
      return d;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_variant_get_string(int paramInt, long[] paramArrayOfLong);
  
  public static final int g_variant_get_string(int paramInt, long[] paramArrayOfLong)
  {
    lock.lock();
    try
    {
      int i = _g_variant_get_string(paramInt, paramArrayOfLong);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_variant_get_type(int paramInt);
  
  public static final int g_variant_get_type(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _g_variant_get_type(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_variant_get_type_string(int paramInt);
  
  public static final int g_variant_get_type_string(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _g_variant_get_type_string(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native long _g_variant_get_uint64(int paramInt);
  
  public static final long g_variant_get_uint64(int paramInt)
  {
    lock.lock();
    try
    {
      long l = _g_variant_get_uint64(paramInt);
      return l;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _g_variant_is_of_type(int paramInt, byte[] paramArrayOfByte);
  
  public static final boolean g_variant_is_of_type(int paramInt, byte[] paramArrayOfByte)
  {
    lock.lock();
    try
    {
      boolean bool = _g_variant_is_of_type(paramInt, paramArrayOfByte);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_variant_new_boolean(boolean paramBoolean);
  
  public static final int g_variant_new_boolean(boolean paramBoolean)
  {
    lock.lock();
    try
    {
      int i = _g_variant_new_boolean(paramBoolean);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_variant_new_double(double paramDouble);
  
  public static final int g_variant_new_double(double paramDouble)
  {
    lock.lock();
    try
    {
      int i = _g_variant_new_double(paramDouble);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_variant_new_byte(byte paramByte);
  
  public static final int g_variant_new_byte(byte paramByte)
  {
    lock.lock();
    try
    {
      int i = _g_variant_new_byte(paramByte);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_variant_new_int64(long paramLong);
  
  public static final int g_variant_new_int64(long paramLong)
  {
    lock.lock();
    try
    {
      int i = _g_variant_new_int64(paramLong);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_variant_new_maybe(byte[] paramArrayOfByte, int paramInt);
  
  public static final int g_variant_new_maybe(byte[] paramArrayOfByte, int paramInt)
  {
    lock.lock();
    try
    {
      int i = _g_variant_new_maybe(paramArrayOfByte, paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_variant_new_tuple(int[] paramArrayOfInt, long paramLong);
  
  public static final int g_variant_new_tuple(int[] paramArrayOfInt, long paramLong)
  {
    lock.lock();
    try
    {
      int i = _g_variant_new_tuple(paramArrayOfInt, paramLong);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_variant_new_string(byte[] paramArrayOfByte);
  
  public static final int g_variant_new_string(byte[] paramArrayOfByte)
  {
    lock.lock();
    try
    {
      int i = _g_variant_new_string(paramArrayOfByte);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_variant_new_uint64(long paramLong);
  
  public static final int g_variant_new_uint64(long paramLong)
  {
    lock.lock();
    try
    {
      int i = _g_variant_new_uint64(paramLong);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native long _g_variant_n_children(long paramLong);
  
  public static final long g_variant_n_children(long paramLong)
  {
    lock.lock();
    try
    {
      long l = _g_variant_n_children(paramLong);
      return l;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gdk_atom_intern(byte[] paramArrayOfByte, boolean paramBoolean);
  
  public static final int gdk_atom_intern(byte[] paramArrayOfByte, boolean paramBoolean)
  {
    lock.lock();
    try
    {
      int i = _gdk_atom_intern(paramArrayOfByte, paramBoolean);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gdk_atom_name(int paramInt);
  
  public static final int gdk_atom_name(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gdk_atom_name(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_beep();
  
  public static final void gdk_beep()
  {
    lock.lock();
    try
    {
      _gdk_beep();
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gdk_bitmap_create_from_data(int paramInt1, byte[] paramArrayOfByte, int paramInt2, int paramInt3);
  
  public static final int gdk_bitmap_create_from_data(int paramInt1, byte[] paramArrayOfByte, int paramInt2, int paramInt3)
  {
    lock.lock();
    try
    {
      int i = _gdk_bitmap_create_from_data(paramInt1, paramArrayOfByte, paramInt2, paramInt3);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gdk_cairo_create(int paramInt);
  
  public static final int gdk_cairo_create(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gdk_cairo_create(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _gdk_cairo_get_clip_rectangle(int paramInt, GdkRectangle paramGdkRectangle);
  
  public static final boolean gdk_cairo_get_clip_rectangle(int paramInt, GdkRectangle paramGdkRectangle)
  {
    lock.lock();
    try
    {
      boolean bool = _gdk_cairo_get_clip_rectangle(paramInt, paramGdkRectangle);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_cairo_region(int paramInt1, int paramInt2);
  
  public static final void gdk_cairo_region(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gdk_cairo_region(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_cairo_reset_clip(int paramInt1, int paramInt2);
  
  public static final void gdk_cairo_reset_clip(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gdk_cairo_reset_clip(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_cairo_set_source_color(int paramInt, GdkColor paramGdkColor);
  
  public static final void gdk_cairo_set_source_color(int paramInt, GdkColor paramGdkColor)
  {
    lock.lock();
    try
    {
      _gdk_cairo_set_source_color(paramInt, paramGdkColor);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gdk_window_get_width(int paramInt);
  
  public static final int gdk_window_get_width(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gdk_window_get_width(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gdk_window_get_visible_region(int paramInt);
  
  public static final int gdk_window_get_visible_region(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gdk_window_get_visible_region(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gdk_window_get_height(int paramInt);
  
  public static final int gdk_window_get_height(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gdk_window_get_height(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_cairo_set_source_pixbuf(int paramInt1, int paramInt2, double paramDouble1, double paramDouble2);
  
  public static final void gdk_cairo_set_source_pixbuf(int paramInt1, int paramInt2, double paramDouble1, double paramDouble2)
  {
    lock.lock();
    try
    {
      _gdk_cairo_set_source_pixbuf(paramInt1, paramInt2, paramDouble1, paramDouble2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_cairo_set_source_window(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  public static final void gdk_cairo_set_source_window(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    lock.lock();
    try
    {
      _gdk_cairo_set_source_window(paramInt1, paramInt2, paramInt3, paramInt4);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_color_free(int paramInt);
  
  public static final void gdk_color_free(int paramInt)
  {
    lock.lock();
    try
    {
      _gdk_color_free(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _gdk_color_parse(byte[] paramArrayOfByte, GdkColor paramGdkColor);
  
  public static final boolean gdk_color_parse(byte[] paramArrayOfByte, GdkColor paramGdkColor)
  {
    lock.lock();
    try
    {
      boolean bool = _gdk_color_parse(paramArrayOfByte, paramGdkColor);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _gdk_color_white(int paramInt, GdkColor paramGdkColor);
  
  public static final boolean gdk_color_white(int paramInt, GdkColor paramGdkColor)
  {
    lock.lock();
    try
    {
      boolean bool = _gdk_color_white(paramInt, paramGdkColor);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _gdk_colormap_alloc_color(int paramInt, GdkColor paramGdkColor, boolean paramBoolean1, boolean paramBoolean2);
  
  public static final boolean gdk_colormap_alloc_color(int paramInt, GdkColor paramGdkColor, boolean paramBoolean1, boolean paramBoolean2)
  {
    lock.lock();
    try
    {
      boolean bool = _gdk_colormap_alloc_color(paramInt, paramGdkColor, paramBoolean1, paramBoolean2);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_colormap_free_colors(int paramInt1, GdkColor paramGdkColor, int paramInt2);
  
  public static final void gdk_colormap_free_colors(int paramInt1, GdkColor paramGdkColor, int paramInt2)
  {
    lock.lock();
    try
    {
      _gdk_colormap_free_colors(paramInt1, paramGdkColor, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gdk_colormap_get_system();
  
  public static final int gdk_colormap_get_system()
  {
    lock.lock();
    try
    {
      int i = _gdk_colormap_get_system();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_cursor_unref(int paramInt);
  
  public static final void gdk_cursor_unref(int paramInt)
  {
    lock.lock();
    try
    {
      _gdk_cursor_unref(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gdk_cursor_new(int paramInt);
  
  public static final int gdk_cursor_new(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gdk_cursor_new(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gdk_cursor_new_from_pixmap(int paramInt1, int paramInt2, GdkColor paramGdkColor1, GdkColor paramGdkColor2, int paramInt3, int paramInt4);
  
  public static final int gdk_cursor_new_from_pixmap(int paramInt1, int paramInt2, GdkColor paramGdkColor1, GdkColor paramGdkColor2, int paramInt3, int paramInt4)
  {
    lock.lock();
    try
    {
      int i = _gdk_cursor_new_from_pixmap(paramInt1, paramInt2, paramGdkColor1, paramGdkColor2, paramInt3, paramInt4);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gdk_cursor_new_from_pixbuf(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  public static final int gdk_cursor_new_from_pixbuf(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    lock.lock();
    try
    {
      int i = _gdk_cursor_new_from_pixbuf(paramInt1, paramInt2, paramInt3, paramInt4);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gdk_display_get_default();
  
  public static final int gdk_display_get_default()
  {
    lock.lock();
    try
    {
      int i = _gdk_display_get_default();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gdk_window_get_display(int paramInt);
  
  public static final int gdk_window_get_display(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gdk_window_get_display(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gdk_display_get_device_manager(int paramInt);
  
  public static final int gdk_display_get_device_manager(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gdk_display_get_device_manager(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gdk_device_manager_get_client_pointer(int paramInt);
  
  public static final int gdk_device_manager_get_client_pointer(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gdk_device_manager_get_client_pointer(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gdk_device_get_window_at_position(int paramInt, int[] paramArrayOfInt1, int[] paramArrayOfInt2);
  
  public static final int gdk_device_get_window_at_position(int paramInt, int[] paramArrayOfInt1, int[] paramArrayOfInt2)
  {
    lock.lock();
    try
    {
      int i = _gdk_device_get_window_at_position(paramInt, paramArrayOfInt1, paramArrayOfInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _gdk_display_supports_cursor_color(int paramInt);
  
  public static final boolean gdk_display_supports_cursor_color(int paramInt)
  {
    lock.lock();
    try
    {
      boolean bool = _gdk_display_supports_cursor_color(paramInt);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gdk_drag_context_get_actions(int paramInt);
  
  public static final int gdk_drag_context_get_actions(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gdk_drag_context_get_actions(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gdk_drag_context_get_dest_window(int paramInt);
  
  public static final int gdk_drag_context_get_dest_window(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gdk_drag_context_get_dest_window(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gdk_drag_context_get_selected_action(int paramInt);
  
  public static final int gdk_drag_context_get_selected_action(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gdk_drag_context_get_selected_action(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gdk_drag_context_list_targets(int paramInt);
  
  public static final int gdk_drag_context_list_targets(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gdk_drag_context_list_targets(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_drag_status(int paramInt1, int paramInt2, int paramInt3);
  
  public static final void gdk_drag_status(int paramInt1, int paramInt2, int paramInt3)
  {
    lock.lock();
    try
    {
      _gdk_drag_status(paramInt1, paramInt2, paramInt3);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_draw_arc(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9);
  
  public static final void gdk_draw_arc(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9)
  {
    lock.lock();
    try
    {
      _gdk_draw_arc(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8, paramInt9);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_draw_drawable(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9);
  
  public static final void gdk_draw_drawable(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9)
  {
    lock.lock();
    try
    {
      _gdk_draw_drawable(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8, paramInt9);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_draw_image(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9);
  
  public static final void gdk_draw_image(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9)
  {
    lock.lock();
    try
    {
      _gdk_draw_image(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8, paramInt9);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_draw_layout(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5);
  
  public static final void gdk_draw_layout(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
  {
    lock.lock();
    try
    {
      _gdk_draw_layout(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_draw_layout_with_colors(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, GdkColor paramGdkColor1, GdkColor paramGdkColor2);
  
  public static final void gdk_draw_layout_with_colors(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, GdkColor paramGdkColor1, GdkColor paramGdkColor2)
  {
    lock.lock();
    try
    {
      _gdk_draw_layout_with_colors(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramGdkColor1, paramGdkColor2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_draw_line(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6);
  
  public static final void gdk_draw_line(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6)
  {
    lock.lock();
    try
    {
      _gdk_draw_line(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_draw_lines(int paramInt1, int paramInt2, int[] paramArrayOfInt, int paramInt3);
  
  public static final void gdk_draw_lines(int paramInt1, int paramInt2, int[] paramArrayOfInt, int paramInt3)
  {
    lock.lock();
    try
    {
      _gdk_draw_lines(paramInt1, paramInt2, paramArrayOfInt, paramInt3);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_draw_pixbuf(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, int paramInt10, int paramInt11, int paramInt12);
  
  public static final void gdk_draw_pixbuf(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, int paramInt10, int paramInt11, int paramInt12)
  {
    lock.lock();
    try
    {
      _gdk_draw_pixbuf(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8, paramInt9, paramInt10, paramInt11, paramInt12);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_draw_point(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  public static final void gdk_draw_point(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    lock.lock();
    try
    {
      _gdk_draw_point(paramInt1, paramInt2, paramInt3, paramInt4);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_draw_polygon(int paramInt1, int paramInt2, int paramInt3, int[] paramArrayOfInt, int paramInt4);
  
  public static final void gdk_draw_polygon(int paramInt1, int paramInt2, int paramInt3, int[] paramArrayOfInt, int paramInt4)
  {
    lock.lock();
    try
    {
      _gdk_draw_polygon(paramInt1, paramInt2, paramInt3, paramArrayOfInt, paramInt4);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_draw_rectangle(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7);
  
  public static final void gdk_draw_rectangle(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7)
  {
    lock.lock();
    try
    {
      _gdk_draw_rectangle(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gdk_drawable_get_depth(int paramInt);
  
  public static final int gdk_drawable_get_depth(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gdk_drawable_get_depth(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_pixmap_get_size(int paramInt, int[] paramArrayOfInt1, int[] paramArrayOfInt2);
  
  public static final void gdk_pixmap_get_size(int paramInt, int[] paramArrayOfInt1, int[] paramArrayOfInt2)
  {
    lock.lock();
    try
    {
      _gdk_pixmap_get_size(paramInt, paramArrayOfInt1, paramArrayOfInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gdk_drawable_get_image(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5);
  
  public static final int gdk_drawable_get_image(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
  {
    lock.lock();
    try
    {
      int i = _gdk_drawable_get_image(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_drawable_get_size(int paramInt, int[] paramArrayOfInt1, int[] paramArrayOfInt2);
  
  public static final void gdk_drawable_get_size(int paramInt, int[] paramArrayOfInt1, int[] paramArrayOfInt2)
  {
    lock.lock();
    try
    {
      _gdk_drawable_get_size(paramInt, paramArrayOfInt1, paramArrayOfInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gdk_drawable_get_visible_region(int paramInt);
  
  public static final int gdk_drawable_get_visible_region(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gdk_drawable_get_visible_region(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gdk_event_copy(int paramInt);
  
  public static final int gdk_event_copy(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gdk_event_copy(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_event_free(int paramInt);
  
  public static final void gdk_event_free(int paramInt)
  {
    lock.lock();
    try
    {
      _gdk_event_free(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gdk_event_get();
  
  public static final int gdk_event_get()
  {
    lock.lock();
    try
    {
      int i = _gdk_event_get();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _gdk_event_get_coords(int paramInt, double[] paramArrayOfDouble1, double[] paramArrayOfDouble2);
  
  public static final boolean gdk_event_get_coords(int paramInt, double[] paramArrayOfDouble1, double[] paramArrayOfDouble2)
  {
    lock.lock();
    try
    {
      boolean bool = _gdk_event_get_coords(paramInt, paramArrayOfDouble1, paramArrayOfDouble2);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _gdk_event_get_state(int paramInt, int[] paramArrayOfInt);
  
  public static final boolean gdk_event_get_state(int paramInt, int[] paramArrayOfInt)
  {
    lock.lock();
    try
    {
      boolean bool = _gdk_event_get_state(paramInt, paramArrayOfInt);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _gdk_event_get_scroll_deltas(int paramInt, double[] paramArrayOfDouble1, double[] paramArrayOfDouble2);
  
  public static final boolean gdk_event_get_scroll_deltas(int paramInt, double[] paramArrayOfDouble1, double[] paramArrayOfDouble2)
  {
    lock.lock();
    try
    {
      boolean bool = _gdk_event_get_scroll_deltas(paramInt, paramArrayOfDouble1, paramArrayOfDouble2);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gdk_event_get_time(int paramInt);
  
  public static final int gdk_event_get_time(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gdk_event_get_time(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_event_handler_set(int paramInt1, int paramInt2, int paramInt3);
  
  public static final void gdk_event_handler_set(int paramInt1, int paramInt2, int paramInt3)
  {
    lock.lock();
    try
    {
      _gdk_event_handler_set(paramInt1, paramInt2, paramInt3);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gdk_event_new(int paramInt);
  
  public static final int gdk_event_new(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gdk_event_new(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gdk_event_peek();
  
  public static final int gdk_event_peek()
  {
    lock.lock();
    try
    {
      int i = _gdk_event_peek();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_event_put(int paramInt);
  
  public static final void gdk_event_put(int paramInt)
  {
    lock.lock();
    try
    {
      _gdk_event_put(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_error_trap_push();
  
  public static final void gdk_error_trap_push()
  {
    lock.lock();
    try
    {
      _gdk_error_trap_push();
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gdk_error_trap_pop();
  
  public static final int gdk_error_trap_pop()
  {
    lock.lock();
    try
    {
      int i = _gdk_error_trap_pop();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_flush();
  
  public static final void gdk_flush()
  {
    lock.lock();
    try
    {
      _gdk_flush();
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_gc_get_values(int paramInt, GdkGCValues paramGdkGCValues);
  
  public static final void gdk_gc_get_values(int paramInt, GdkGCValues paramGdkGCValues)
  {
    lock.lock();
    try
    {
      _gdk_gc_get_values(paramInt, paramGdkGCValues);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gdk_gc_new(int paramInt);
  
  public static final int gdk_gc_new(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gdk_gc_new(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_gc_set_background(int paramInt, GdkColor paramGdkColor);
  
  public static final void gdk_gc_set_background(int paramInt, GdkColor paramGdkColor)
  {
    lock.lock();
    try
    {
      _gdk_gc_set_background(paramInt, paramGdkColor);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_gc_set_clip_mask(int paramInt1, int paramInt2);
  
  public static final void gdk_gc_set_clip_mask(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gdk_gc_set_clip_mask(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_gc_set_clip_origin(int paramInt1, int paramInt2, int paramInt3);
  
  public static final void gdk_gc_set_clip_origin(int paramInt1, int paramInt2, int paramInt3)
  {
    lock.lock();
    try
    {
      _gdk_gc_set_clip_origin(paramInt1, paramInt2, paramInt3);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_gc_set_clip_region(int paramInt1, int paramInt2);
  
  public static final void gdk_gc_set_clip_region(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gdk_gc_set_clip_region(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_gc_set_dashes(int paramInt1, int paramInt2, byte[] paramArrayOfByte, int paramInt3);
  
  public static final void gdk_gc_set_dashes(int paramInt1, int paramInt2, byte[] paramArrayOfByte, int paramInt3)
  {
    lock.lock();
    try
    {
      _gdk_gc_set_dashes(paramInt1, paramInt2, paramArrayOfByte, paramInt3);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_gc_set_exposures(int paramInt, boolean paramBoolean);
  
  public static final void gdk_gc_set_exposures(int paramInt, boolean paramBoolean)
  {
    lock.lock();
    try
    {
      _gdk_gc_set_exposures(paramInt, paramBoolean);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_gc_set_fill(int paramInt1, int paramInt2);
  
  public static final void gdk_gc_set_fill(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gdk_gc_set_fill(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_gc_set_foreground(int paramInt, GdkColor paramGdkColor);
  
  public static final void gdk_gc_set_foreground(int paramInt, GdkColor paramGdkColor)
  {
    lock.lock();
    try
    {
      _gdk_gc_set_foreground(paramInt, paramGdkColor);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_gc_set_function(int paramInt1, int paramInt2);
  
  public static final void gdk_gc_set_function(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gdk_gc_set_function(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_gc_set_line_attributes(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5);
  
  public static final void gdk_gc_set_line_attributes(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
  {
    lock.lock();
    try
    {
      _gdk_gc_set_line_attributes(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_gc_set_stipple(int paramInt1, int paramInt2);
  
  public static final void gdk_gc_set_stipple(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gdk_gc_set_stipple(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_gc_set_subwindow(int paramInt1, int paramInt2);
  
  public static final void gdk_gc_set_subwindow(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gdk_gc_set_subwindow(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_gc_set_tile(int paramInt1, int paramInt2);
  
  public static final void gdk_gc_set_tile(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gdk_gc_set_tile(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_gc_set_ts_origin(int paramInt1, int paramInt2, int paramInt3);
  
  public static final void gdk_gc_set_ts_origin(int paramInt1, int paramInt2, int paramInt3)
  {
    lock.lock();
    try
    {
      _gdk_gc_set_ts_origin(paramInt1, paramInt2, paramInt3);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_gc_set_values(int paramInt1, GdkGCValues paramGdkGCValues, int paramInt2);
  
  public static final void gdk_gc_set_values(int paramInt1, GdkGCValues paramGdkGCValues, int paramInt2)
  {
    lock.lock();
    try
    {
      _gdk_gc_set_values(paramInt1, paramGdkGCValues, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gdk_get_default_root_window();
  
  public static final int gdk_get_default_root_window()
  {
    lock.lock();
    try
    {
      int i = _gdk_get_default_root_window();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_keyboard_ungrab(int paramInt);
  
  public static final void gdk_keyboard_ungrab(int paramInt)
  {
    lock.lock();
    try
    {
      _gdk_keyboard_ungrab(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gdk_keymap_get_default();
  
  public static final int gdk_keymap_get_default()
  {
    lock.lock();
    try
    {
      int i = _gdk_keymap_get_default();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _gdk_keymap_translate_keyboard_state(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3, int[] paramArrayOfInt4);
  
  public static final boolean gdk_keymap_translate_keyboard_state(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3, int[] paramArrayOfInt4)
  {
    lock.lock();
    try
    {
      boolean bool = _gdk_keymap_translate_keyboard_state(paramInt1, paramInt2, paramInt3, paramInt4, paramArrayOfInt1, paramArrayOfInt2, paramArrayOfInt3, paramArrayOfInt4);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gdk_keyval_to_lower(int paramInt);
  
  public static final int gdk_keyval_to_lower(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gdk_keyval_to_lower(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gdk_keyval_to_unicode(int paramInt);
  
  public static final int gdk_keyval_to_unicode(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gdk_keyval_to_unicode(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gdk_pango_context_get();
  
  public static final int gdk_pango_context_get()
  {
    lock.lock();
    try
    {
      int i = _gdk_pango_context_get();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gdk_pango_layout_get_clip_region(int paramInt1, int paramInt2, int paramInt3, int[] paramArrayOfInt, int paramInt4);
  
  public static final int gdk_pango_layout_get_clip_region(int paramInt1, int paramInt2, int paramInt3, int[] paramArrayOfInt, int paramInt4)
  {
    lock.lock();
    try
    {
      int i = _gdk_pango_layout_get_clip_region(paramInt1, paramInt2, paramInt3, paramArrayOfInt, paramInt4);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_pixbuf_copy_area(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8);
  
  public static final void gdk_pixbuf_copy_area(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8)
  {
    lock.lock();
    try
    {
      _gdk_pixbuf_copy_area(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gdk_pixbuf_get_from_drawable(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9);
  
  public static final int gdk_pixbuf_get_from_drawable(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9)
  {
    lock.lock();
    try
    {
      int i = _gdk_pixbuf_get_from_drawable(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8, paramInt9);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gdk_pixbuf_get_from_window(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5);
  
  public static final int gdk_pixbuf_get_from_window(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
  {
    lock.lock();
    try
    {
      int i = _gdk_pixbuf_get_from_window(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _gdk_pixbuf_get_has_alpha(int paramInt);
  
  public static final boolean gdk_pixbuf_get_has_alpha(int paramInt)
  {
    lock.lock();
    try
    {
      boolean bool = _gdk_pixbuf_get_has_alpha(paramInt);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gdk_pixbuf_get_height(int paramInt);
  
  public static final int gdk_pixbuf_get_height(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gdk_pixbuf_get_height(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gdk_pixbuf_get_pixels(int paramInt);
  
  public static final int gdk_pixbuf_get_pixels(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gdk_pixbuf_get_pixels(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gdk_pixbuf_get_rowstride(int paramInt);
  
  public static final int gdk_pixbuf_get_rowstride(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gdk_pixbuf_get_rowstride(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gdk_pixbuf_get_width(int paramInt);
  
  public static final int gdk_pixbuf_get_width(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gdk_pixbuf_get_width(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gdk_pixbuf_loader_new();
  
  public static final int gdk_pixbuf_loader_new()
  {
    lock.lock();
    try
    {
      int i = _gdk_pixbuf_loader_new();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _gdk_pixbuf_loader_close(int paramInt, int[] paramArrayOfInt);
  
  public static final boolean gdk_pixbuf_loader_close(int paramInt, int[] paramArrayOfInt)
  {
    lock.lock();
    try
    {
      boolean bool = _gdk_pixbuf_loader_close(paramInt, paramArrayOfInt);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gdk_pixbuf_loader_get_pixbuf(int paramInt);
  
  public static final int gdk_pixbuf_loader_get_pixbuf(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gdk_pixbuf_loader_get_pixbuf(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _gdk_pixbuf_loader_write(int paramInt1, int paramInt2, int paramInt3, int[] paramArrayOfInt);
  
  public static final boolean gdk_pixbuf_loader_write(int paramInt1, int paramInt2, int paramInt3, int[] paramArrayOfInt)
  {
    lock.lock();
    try
    {
      boolean bool = _gdk_pixbuf_loader_write(paramInt1, paramInt2, paramInt3, paramArrayOfInt);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gdk_pixbuf_new(int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, int paramInt4);
  
  public static final int gdk_pixbuf_new(int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, int paramInt4)
  {
    lock.lock();
    try
    {
      int i = _gdk_pixbuf_new(paramInt1, paramBoolean, paramInt2, paramInt3, paramInt4);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gdk_pixbuf_new_from_file(byte[] paramArrayOfByte, int[] paramArrayOfInt);
  
  public static final int gdk_pixbuf_new_from_file(byte[] paramArrayOfByte, int[] paramArrayOfInt)
  {
    lock.lock();
    try
    {
      int i = _gdk_pixbuf_new_from_file(paramArrayOfByte, paramArrayOfInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_pixbuf_render_to_drawable(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, int paramInt10, int paramInt11, int paramInt12);
  
  public static final void gdk_pixbuf_render_to_drawable(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, int paramInt10, int paramInt11, int paramInt12)
  {
    lock.lock();
    try
    {
      _gdk_pixbuf_render_to_drawable(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8, paramInt9, paramInt10, paramInt11, paramInt12);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_pixbuf_render_pixmap_and_mask(int paramInt1, int[] paramArrayOfInt1, int[] paramArrayOfInt2, int paramInt2);
  
  public static final void gdk_pixbuf_render_pixmap_and_mask(int paramInt1, int[] paramArrayOfInt1, int[] paramArrayOfInt2, int paramInt2)
  {
    lock.lock();
    try
    {
      _gdk_pixbuf_render_pixmap_and_mask(paramInt1, paramArrayOfInt1, paramArrayOfInt2, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _gdk_pixbuf_save_to_bufferv(int paramInt, int[] paramArrayOfInt1, int[] paramArrayOfInt2, byte[] paramArrayOfByte, int[] paramArrayOfInt3, int[] paramArrayOfInt4, int[] paramArrayOfInt5);
  
  public static final boolean gdk_pixbuf_save_to_bufferv(int paramInt, int[] paramArrayOfInt1, int[] paramArrayOfInt2, byte[] paramArrayOfByte, int[] paramArrayOfInt3, int[] paramArrayOfInt4, int[] paramArrayOfInt5)
  {
    lock.lock();
    try
    {
      boolean bool = _gdk_pixbuf_save_to_bufferv(paramInt, paramArrayOfInt1, paramArrayOfInt2, paramArrayOfByte, paramArrayOfInt3, paramArrayOfInt4, paramArrayOfInt5);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gdk_pixbuf_scale_simple(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  public static final int gdk_pixbuf_scale_simple(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    lock.lock();
    try
    {
      int i = _gdk_pixbuf_scale_simple(paramInt1, paramInt2, paramInt3, paramInt4);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gdk_pixmap_new(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  public static final int gdk_pixmap_new(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    lock.lock();
    try
    {
      int i = _gdk_pixmap_new(paramInt1, paramInt2, paramInt3, paramInt4);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gdk_pointer_grab(int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, int paramInt4, int paramInt5);
  
  public static final int gdk_pointer_grab(int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
  {
    lock.lock();
    try
    {
      int i = _gdk_pointer_grab(paramInt1, paramBoolean, paramInt2, paramInt3, paramInt4, paramInt5);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gdk_device_grab(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean, int paramInt4, int paramInt5, int paramInt6);
  
  public static final int gdk_device_grab(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean, int paramInt4, int paramInt5, int paramInt6)
  {
    lock.lock();
    try
    {
      int i = _gdk_device_grab(paramInt1, paramInt2, paramInt3, paramBoolean, paramInt4, paramInt5, paramInt6);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_pointer_ungrab(int paramInt);
  
  public static final void gdk_pointer_ungrab(int paramInt)
  {
    lock.lock();
    try
    {
      _gdk_pointer_ungrab(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_device_ungrab(int paramInt1, int paramInt2);
  
  public static final void gdk_device_ungrab(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gdk_device_ungrab(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gdk_device_get_associated_device(int paramInt);
  
  public static final int gdk_device_get_associated_device(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gdk_device_get_associated_device(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _gdk_property_get(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3, int[] paramArrayOfInt4);
  
  public static final boolean gdk_property_get(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3, int[] paramArrayOfInt4)
  {
    lock.lock();
    try
    {
      boolean bool = _gdk_property_get(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramArrayOfInt1, paramArrayOfInt2, paramArrayOfInt3, paramArrayOfInt4);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_region_destroy(int paramInt);
  
  public static final void gdk_region_destroy(int paramInt)
  {
    lock.lock();
    try
    {
      _gdk_region_destroy(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _gdk_region_empty(int paramInt);
  
  public static final boolean gdk_region_empty(int paramInt)
  {
    lock.lock();
    try
    {
      boolean bool = _gdk_region_empty(paramInt);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_region_get_clipbox(int paramInt, GdkRectangle paramGdkRectangle);
  
  public static final void gdk_region_get_clipbox(int paramInt, GdkRectangle paramGdkRectangle)
  {
    lock.lock();
    try
    {
      _gdk_region_get_clipbox(paramInt, paramGdkRectangle);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_region_get_rectangles(int paramInt, int[] paramArrayOfInt1, int[] paramArrayOfInt2);
  
  public static final void gdk_region_get_rectangles(int paramInt, int[] paramArrayOfInt1, int[] paramArrayOfInt2)
  {
    lock.lock();
    try
    {
      _gdk_region_get_rectangles(paramInt, paramArrayOfInt1, paramArrayOfInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_region_intersect(int paramInt1, int paramInt2);
  
  public static final void gdk_region_intersect(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gdk_region_intersect(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gdk_cairo_region_create_from_surface(int paramInt);
  
  public static final int gdk_cairo_region_create_from_surface(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gdk_cairo_region_create_from_surface(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_widget_shape_combine_region(int paramInt1, int paramInt2);
  
  public static final void gtk_widget_shape_combine_region(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_widget_shape_combine_region(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gdk_region_new();
  
  public static final int gdk_region_new()
  {
    lock.lock();
    try
    {
      int i = _gdk_region_new();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_region_offset(int paramInt1, int paramInt2, int paramInt3);
  
  public static final void gdk_region_offset(int paramInt1, int paramInt2, int paramInt3)
  {
    lock.lock();
    try
    {
      _gdk_region_offset(paramInt1, paramInt2, paramInt3);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _gdk_region_point_in(int paramInt1, int paramInt2, int paramInt3);
  
  public static final boolean gdk_region_point_in(int paramInt1, int paramInt2, int paramInt3)
  {
    lock.lock();
    try
    {
      boolean bool = _gdk_region_point_in(paramInt1, paramInt2, paramInt3);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gdk_region_polygon(int[] paramArrayOfInt, int paramInt1, int paramInt2);
  
  public static final int gdk_region_polygon(int[] paramArrayOfInt, int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      int i = _gdk_region_polygon(paramArrayOfInt, paramInt1, paramInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gdk_region_rectangle(GdkRectangle paramGdkRectangle);
  
  public static final int gdk_region_rectangle(GdkRectangle paramGdkRectangle)
  {
    lock.lock();
    try
    {
      int i = _gdk_region_rectangle(paramGdkRectangle);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gdk_region_rect_in(int paramInt, GdkRectangle paramGdkRectangle);
  
  public static final int gdk_region_rect_in(int paramInt, GdkRectangle paramGdkRectangle)
  {
    lock.lock();
    try
    {
      int i = _gdk_region_rect_in(paramInt, paramGdkRectangle);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_region_subtract(int paramInt1, int paramInt2);
  
  public static final void gdk_region_subtract(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gdk_region_subtract(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_region_union(int paramInt1, int paramInt2);
  
  public static final void gdk_region_union(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gdk_region_union(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_region_union_with_rect(int paramInt, GdkRectangle paramGdkRectangle);
  
  public static final void gdk_region_union_with_rect(int paramInt, GdkRectangle paramGdkRectangle)
  {
    lock.lock();
    try
    {
      _gdk_region_union_with_rect(paramInt, paramGdkRectangle);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gdk_screen_get_default();
  
  public static final int gdk_screen_get_default()
  {
    lock.lock();
    try
    {
      int i = _gdk_screen_get_default();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gdk_screen_get_monitor_at_point(int paramInt1, int paramInt2, int paramInt3);
  
  public static final int gdk_screen_get_monitor_at_point(int paramInt1, int paramInt2, int paramInt3)
  {
    lock.lock();
    try
    {
      int i = _gdk_screen_get_monitor_at_point(paramInt1, paramInt2, paramInt3);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gdk_screen_get_monitor_at_window(int paramInt1, int paramInt2);
  
  public static final int gdk_screen_get_monitor_at_window(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      int i = _gdk_screen_get_monitor_at_window(paramInt1, paramInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_screen_get_monitor_geometry(int paramInt1, int paramInt2, GdkRectangle paramGdkRectangle);
  
  public static final void gdk_screen_get_monitor_geometry(int paramInt1, int paramInt2, GdkRectangle paramGdkRectangle)
  {
    lock.lock();
    try
    {
      _gdk_screen_get_monitor_geometry(paramInt1, paramInt2, paramGdkRectangle);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gdk_screen_get_n_monitors(int paramInt);
  
  public static final int gdk_screen_get_n_monitors(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gdk_screen_get_n_monitors(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gdk_screen_height();
  
  public static final int gdk_screen_height()
  {
    lock.lock();
    try
    {
      int i = _gdk_screen_height();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gdk_screen_width();
  
  public static final int gdk_screen_width()
  {
    lock.lock();
    try
    {
      int i = _gdk_screen_width();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gdk_screen_width_mm();
  
  public static final int gdk_screen_width_mm()
  {
    lock.lock();
    try
    {
      int i = _gdk_screen_width_mm();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_set_program_class(byte[] paramArrayOfByte);
  
  public static final void gdk_set_program_class(byte[] paramArrayOfByte)
  {
    lock.lock();
    try
    {
      _gdk_set_program_class(paramArrayOfByte);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _gdk_utf8_to_compound_text(byte[] paramArrayOfByte, int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3, int[] paramArrayOfInt4);
  
  public static final boolean gdk_utf8_to_compound_text(byte[] paramArrayOfByte, int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3, int[] paramArrayOfInt4)
  {
    lock.lock();
    try
    {
      boolean bool = _gdk_utf8_to_compound_text(paramArrayOfByte, paramArrayOfInt1, paramArrayOfInt2, paramArrayOfInt3, paramArrayOfInt4);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _gdk_x11_display_utf8_to_compound_text(int paramInt, byte[] paramArrayOfByte, int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3, int[] paramArrayOfInt4);
  
  public static final boolean gdk_x11_display_utf8_to_compound_text(int paramInt, byte[] paramArrayOfByte, int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3, int[] paramArrayOfInt4)
  {
    lock.lock();
    try
    {
      boolean bool = _gdk_x11_display_utf8_to_compound_text(paramInt, paramArrayOfByte, paramArrayOfInt1, paramArrayOfInt2, paramArrayOfInt3, paramArrayOfInt4);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gdk_utf8_to_string_target(byte[] paramArrayOfByte);
  
  public static final int gdk_utf8_to_string_target(byte[] paramArrayOfByte)
  {
    lock.lock();
    try
    {
      int i = _gdk_utf8_to_string_target(paramArrayOfByte);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gdk_text_property_to_utf8_list_for_display(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int[] paramArrayOfInt);
  
  public static final int gdk_text_property_to_utf8_list_for_display(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int[] paramArrayOfInt)
  {
    lock.lock();
    try
    {
      int i = _gdk_text_property_to_utf8_list_for_display(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramArrayOfInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void gdk_threads_leave();
  
  public static final native void gdk_threads_set_lock_functions(int paramInt1, int paramInt2);
  
  public static final native int _gdk_unicode_to_keyval(int paramInt);
  
  public static final int gdk_unicode_to_keyval(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gdk_unicode_to_keyval(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gdk_visual_get_depth(int paramInt);
  
  public static final int gdk_visual_get_depth(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gdk_visual_get_depth(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gdk_visual_get_system();
  
  public static final int gdk_visual_get_system()
  {
    lock.lock();
    try
    {
      int i = _gdk_visual_get_system();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gdk_window_at_pointer(int[] paramArrayOfInt1, int[] paramArrayOfInt2);
  
  public static final int gdk_window_at_pointer(int[] paramArrayOfInt1, int[] paramArrayOfInt2)
  {
    lock.lock();
    try
    {
      int i = _gdk_window_at_pointer(paramArrayOfInt1, paramArrayOfInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_window_begin_paint_rect(int paramInt, GdkRectangle paramGdkRectangle);
  
  public static final void gdk_window_begin_paint_rect(int paramInt, GdkRectangle paramGdkRectangle)
  {
    lock.lock();
    try
    {
      _gdk_window_begin_paint_rect(paramInt, paramGdkRectangle);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gdk_window_create_similar_surface(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  public static final int gdk_window_create_similar_surface(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    lock.lock();
    try
    {
      int i = _gdk_window_create_similar_surface(paramInt1, paramInt2, paramInt3, paramInt4);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_window_destroy(int paramInt);
  
  public static final void gdk_window_destroy(int paramInt)
  {
    lock.lock();
    try
    {
      _gdk_window_destroy(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_window_end_paint(int paramInt);
  
  public static final void gdk_window_end_paint(int paramInt)
  {
    lock.lock();
    try
    {
      _gdk_window_end_paint(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gdk_window_get_children(int paramInt);
  
  public static final int gdk_window_get_children(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gdk_window_get_children(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gdk_window_get_events(int paramInt);
  
  public static final int gdk_window_get_events(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gdk_window_get_events(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_window_focus(int paramInt1, int paramInt2);
  
  public static final void gdk_window_focus(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gdk_window_focus(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_window_get_frame_extents(int paramInt, GdkRectangle paramGdkRectangle);
  
  public static final void gdk_window_get_frame_extents(int paramInt, GdkRectangle paramGdkRectangle)
  {
    lock.lock();
    try
    {
      _gdk_window_get_frame_extents(paramInt, paramGdkRectangle);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_window_get_internal_paint_info(int paramInt, int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3);
  
  public static final void gdk_window_get_internal_paint_info(int paramInt, int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3)
  {
    lock.lock();
    try
    {
      _gdk_window_get_internal_paint_info(paramInt, paramArrayOfInt1, paramArrayOfInt2, paramArrayOfInt3);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gdk_window_get_origin(int paramInt, int[] paramArrayOfInt1, int[] paramArrayOfInt2);
  
  public static final int gdk_window_get_origin(int paramInt, int[] paramArrayOfInt1, int[] paramArrayOfInt2)
  {
    lock.lock();
    try
    {
      int i = _gdk_window_get_origin(paramInt, paramArrayOfInt1, paramArrayOfInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gdk_window_get_device_position(int paramInt1, int paramInt2, int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3);
  
  public static final int gdk_window_get_device_position(int paramInt1, int paramInt2, int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3)
  {
    lock.lock();
    try
    {
      int i = _gdk_window_get_device_position(paramInt1, paramInt2, paramArrayOfInt1, paramArrayOfInt2, paramArrayOfInt3);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gdk_window_get_parent(int paramInt);
  
  public static final int gdk_window_get_parent(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gdk_window_get_parent(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gdk_window_get_pointer(int paramInt, int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3);
  
  public static final int gdk_window_get_pointer(int paramInt, int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3)
  {
    lock.lock();
    try
    {
      int i = _gdk_window_get_pointer(paramInt, paramArrayOfInt1, paramArrayOfInt2, paramArrayOfInt3);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_window_get_position(int paramInt, int[] paramArrayOfInt1, int[] paramArrayOfInt2);
  
  public static final void gdk_window_get_position(int paramInt, int[] paramArrayOfInt1, int[] paramArrayOfInt2)
  {
    lock.lock();
    try
    {
      _gdk_window_get_position(paramInt, paramArrayOfInt1, paramArrayOfInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_window_get_user_data(int paramInt, int[] paramArrayOfInt);
  
  public static final void gdk_window_get_user_data(int paramInt, int[] paramArrayOfInt)
  {
    lock.lock();
    try
    {
      _gdk_window_get_user_data(paramInt, paramArrayOfInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_window_hide(int paramInt);
  
  public static final void gdk_window_hide(int paramInt)
  {
    lock.lock();
    try
    {
      _gdk_window_hide(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_window_invalidate_rect(int paramInt, GdkRectangle paramGdkRectangle, boolean paramBoolean);
  
  public static final void gdk_window_invalidate_rect(int paramInt, GdkRectangle paramGdkRectangle, boolean paramBoolean)
  {
    lock.lock();
    try
    {
      _gdk_window_invalidate_rect(paramInt, paramGdkRectangle, paramBoolean);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_window_invalidate_region(int paramInt1, int paramInt2, boolean paramBoolean);
  
  public static final void gdk_window_invalidate_region(int paramInt1, int paramInt2, boolean paramBoolean)
  {
    lock.lock();
    try
    {
      _gdk_window_invalidate_region(paramInt1, paramInt2, paramBoolean);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _gdk_window_is_visible(int paramInt);
  
  public static final boolean gdk_window_is_visible(int paramInt)
  {
    lock.lock();
    try
    {
      boolean bool = _gdk_window_is_visible(paramInt);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_window_move(int paramInt1, int paramInt2, int paramInt3);
  
  public static final void gdk_window_move(int paramInt1, int paramInt2, int paramInt3)
  {
    lock.lock();
    try
    {
      _gdk_window_move(paramInt1, paramInt2, paramInt3);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_window_move_resize(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5);
  
  public static final void gdk_window_move_resize(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
  {
    lock.lock();
    try
    {
      _gdk_window_move_resize(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gdk_window_new(int paramInt1, GdkWindowAttr paramGdkWindowAttr, int paramInt2);
  
  public static final int gdk_window_new(int paramInt1, GdkWindowAttr paramGdkWindowAttr, int paramInt2)
  {
    lock.lock();
    try
    {
      int i = _gdk_window_new(paramInt1, paramGdkWindowAttr, paramInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_window_lower(int paramInt);
  
  public static final void gdk_window_lower(int paramInt)
  {
    lock.lock();
    try
    {
      _gdk_window_lower(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_window_process_all_updates();
  
  public static final void gdk_window_process_all_updates()
  {
    lock.lock();
    try
    {
      _gdk_window_process_all_updates();
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_window_process_updates(int paramInt, boolean paramBoolean);
  
  public static final void gdk_window_process_updates(int paramInt, boolean paramBoolean)
  {
    lock.lock();
    try
    {
      _gdk_window_process_updates(paramInt, paramBoolean);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_window_raise(int paramInt);
  
  public static final void gdk_window_raise(int paramInt)
  {
    lock.lock();
    try
    {
      _gdk_window_raise(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_window_resize(int paramInt1, int paramInt2, int paramInt3);
  
  public static final void gdk_window_resize(int paramInt1, int paramInt2, int paramInt3)
  {
    lock.lock();
    try
    {
      _gdk_window_resize(paramInt1, paramInt2, paramInt3);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_window_restack(int paramInt1, int paramInt2, boolean paramBoolean);
  
  public static final void gdk_window_restack(int paramInt1, int paramInt2, boolean paramBoolean)
  {
    lock.lock();
    try
    {
      _gdk_window_restack(paramInt1, paramInt2, paramBoolean);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_window_scroll(int paramInt1, int paramInt2, int paramInt3);
  
  public static final void gdk_window_scroll(int paramInt1, int paramInt2, int paramInt3)
  {
    lock.lock();
    try
    {
      _gdk_window_scroll(paramInt1, paramInt2, paramInt3);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_window_set_background_pattern(int paramInt1, int paramInt2);
  
  public static final void gdk_window_set_background_pattern(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gdk_window_set_background_pattern(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_window_set_back_pixmap(int paramInt1, int paramInt2, boolean paramBoolean);
  
  public static final void gdk_window_set_back_pixmap(int paramInt1, int paramInt2, boolean paramBoolean)
  {
    lock.lock();
    try
    {
      _gdk_window_set_back_pixmap(paramInt1, paramInt2, paramBoolean);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_window_set_cursor(int paramInt1, int paramInt2);
  
  public static final void gdk_window_set_cursor(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gdk_window_set_cursor(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_window_set_debug_updates(boolean paramBoolean);
  
  public static final void gdk_window_set_debug_updates(boolean paramBoolean)
  {
    lock.lock();
    try
    {
      _gdk_window_set_debug_updates(paramBoolean);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_window_set_decorations(int paramInt1, int paramInt2);
  
  public static final void gdk_window_set_decorations(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gdk_window_set_decorations(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_window_set_events(int paramInt1, int paramInt2);
  
  public static final void gdk_window_set_events(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gdk_window_set_events(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_window_set_override_redirect(int paramInt, boolean paramBoolean);
  
  public static final void gdk_window_set_override_redirect(int paramInt, boolean paramBoolean)
  {
    lock.lock();
    try
    {
      _gdk_window_set_override_redirect(paramInt, paramBoolean);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_window_set_user_data(int paramInt1, int paramInt2);
  
  public static final void gdk_window_set_user_data(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gdk_window_set_user_data(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_window_shape_combine_region(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  public static final void gdk_window_shape_combine_region(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    lock.lock();
    try
    {
      _gdk_window_shape_combine_region(paramInt1, paramInt2, paramInt3, paramInt4);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_window_show(int paramInt);
  
  public static final void gdk_window_show(int paramInt)
  {
    lock.lock();
    try
    {
      _gdk_window_show(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gdk_window_show_unraised(int paramInt);
  
  public static final void gdk_window_show_unraised(int paramInt)
  {
    lock.lock();
    try
    {
      _gdk_window_show_unraised(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_accelerator_get_default_mod_mask();
  
  public static final int gtk_accelerator_get_default_mod_mask()
  {
    lock.lock();
    try
    {
      int i = _gtk_accelerator_get_default_mod_mask();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_accelerator_parse(int paramInt, int[] paramArrayOfInt1, int[] paramArrayOfInt2);
  
  public static final void gtk_accelerator_parse(int paramInt, int[] paramArrayOfInt1, int[] paramArrayOfInt2)
  {
    lock.lock();
    try
    {
      _gtk_accelerator_parse(paramInt, paramArrayOfInt1, paramArrayOfInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_accel_group_new();
  
  public static final int gtk_accel_group_new()
  {
    lock.lock();
    try
    {
      int i = _gtk_accel_group_new();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_accel_label_set_accel_widget(int paramInt1, int paramInt2);
  
  public static final void gtk_accel_label_set_accel_widget(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_accel_label_set_accel_widget(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_accel_label_set_accel(int paramInt1, int paramInt2, int paramInt3);
  
  public static final void gtk_accel_label_set_accel(int paramInt1, int paramInt2, int paramInt3)
  {
    lock.lock();
    try
    {
      _gtk_accel_label_set_accel(paramInt1, paramInt2, paramInt3);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_accessible_get_widget(int paramInt);
  
  public static final int gtk_accessible_get_widget(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_accessible_get_widget(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_adjustment_changed(int paramInt);
  
  public static final void gtk_adjustment_changed(int paramInt)
  {
    lock.lock();
    try
    {
      _gtk_adjustment_changed(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_adjustment_configure(int paramInt, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6);
  
  public static final void gtk_adjustment_configure(int paramInt, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6)
  {
    lock.lock();
    try
    {
      _gtk_adjustment_configure(paramInt, paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramDouble5, paramDouble6);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_adjustment_new(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6);
  
  public static final int gtk_adjustment_new(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6)
  {
    lock.lock();
    try
    {
      int i = _gtk_adjustment_new(paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramDouble5, paramDouble6);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native double _gtk_adjustment_get_lower(int paramInt);
  
  public static final double gtk_adjustment_get_lower(int paramInt)
  {
    lock.lock();
    try
    {
      double d = _gtk_adjustment_get_lower(paramInt);
      return d;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native double _gtk_adjustment_get_page_increment(int paramInt);
  
  public static final double gtk_adjustment_get_page_increment(int paramInt)
  {
    lock.lock();
    try
    {
      double d = _gtk_adjustment_get_page_increment(paramInt);
      return d;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native double _gtk_adjustment_get_page_size(int paramInt);
  
  public static final double gtk_adjustment_get_page_size(int paramInt)
  {
    lock.lock();
    try
    {
      double d = _gtk_adjustment_get_page_size(paramInt);
      return d;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native double _gtk_adjustment_get_step_increment(int paramInt);
  
  public static final double gtk_adjustment_get_step_increment(int paramInt)
  {
    lock.lock();
    try
    {
      double d = _gtk_adjustment_get_step_increment(paramInt);
      return d;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native double _gtk_adjustment_get_upper(int paramInt);
  
  public static final double gtk_adjustment_get_upper(int paramInt)
  {
    lock.lock();
    try
    {
      double d = _gtk_adjustment_get_upper(paramInt);
      return d;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native double _gtk_adjustment_get_value(int paramInt);
  
  public static final double gtk_adjustment_get_value(int paramInt)
  {
    lock.lock();
    try
    {
      double d = _gtk_adjustment_get_value(paramInt);
      return d;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_adjustment_set_value(int paramInt, double paramDouble);
  
  public static final void gtk_adjustment_set_value(int paramInt, double paramDouble)
  {
    lock.lock();
    try
    {
      _gtk_adjustment_set_value(paramInt, paramDouble);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_adjustment_set_step_increment(int paramInt, double paramDouble);
  
  public static final void gtk_adjustment_set_step_increment(int paramInt, double paramDouble)
  {
    lock.lock();
    try
    {
      _gtk_adjustment_set_step_increment(paramInt, paramDouble);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_adjustment_set_page_increment(int paramInt, double paramDouble);
  
  public static final void gtk_adjustment_set_page_increment(int paramInt, double paramDouble)
  {
    lock.lock();
    try
    {
      _gtk_adjustment_set_page_increment(paramInt, paramDouble);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_adjustment_value_changed(int paramInt);
  
  public static final void gtk_adjustment_value_changed(int paramInt)
  {
    lock.lock();
    try
    {
      _gtk_adjustment_value_changed(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_arrow_new(int paramInt1, int paramInt2);
  
  public static final int gtk_arrow_new(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      int i = _gtk_arrow_new(paramInt1, paramInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_arrow_set(int paramInt1, int paramInt2, int paramInt3);
  
  public static final void gtk_arrow_set(int paramInt1, int paramInt2, int paramInt3)
  {
    lock.lock();
    try
    {
      _gtk_arrow_set(paramInt1, paramInt2, paramInt3);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_bin_get_child(int paramInt);
  
  public static final int gtk_bin_get_child(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_bin_get_child(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_border_free(int paramInt);
  
  public static final void gtk_border_free(int paramInt)
  {
    lock.lock();
    try
    {
      _gtk_border_free(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_box_set_spacing(int paramInt1, int paramInt2);
  
  public static final void gtk_box_set_spacing(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_box_set_spacing(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_box_set_child_packing(int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2, int paramInt3, int paramInt4);
  
  public static final void gtk_box_set_child_packing(int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2, int paramInt3, int paramInt4)
  {
    lock.lock();
    try
    {
      _gtk_box_set_child_packing(paramInt1, paramInt2, paramBoolean1, paramBoolean2, paramInt3, paramInt4);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_button_clicked(int paramInt);
  
  public static final void gtk_button_clicked(int paramInt)
  {
    lock.lock();
    try
    {
      _gtk_button_clicked(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_button_get_relief(int paramInt);
  
  public static final int gtk_button_get_relief(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_button_get_relief(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_button_new();
  
  public static final int gtk_button_new()
  {
    lock.lock();
    try
    {
      int i = _gtk_button_new();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_button_set_relief(int paramInt1, int paramInt2);
  
  public static final void gtk_button_set_relief(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_button_set_relief(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_calendar_new();
  
  public static final int gtk_calendar_new()
  {
    lock.lock();
    try
    {
      int i = _gtk_calendar_new();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _gtk_calendar_select_month(int paramInt1, int paramInt2, int paramInt3);
  
  public static final boolean gtk_calendar_select_month(int paramInt1, int paramInt2, int paramInt3)
  {
    lock.lock();
    try
    {
      boolean bool = _gtk_calendar_select_month(paramInt1, paramInt2, paramInt3);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_calendar_select_day(int paramInt1, int paramInt2);
  
  public static final void gtk_calendar_select_day(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_calendar_select_day(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_calendar_mark_day(int paramInt1, int paramInt2);
  
  public static final void gtk_calendar_mark_day(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_calendar_mark_day(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_calendar_clear_marks(int paramInt);
  
  public static final void gtk_calendar_clear_marks(int paramInt)
  {
    lock.lock();
    try
    {
      _gtk_calendar_clear_marks(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_calendar_set_display_options(int paramInt1, int paramInt2);
  
  public static final void gtk_calendar_set_display_options(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_calendar_set_display_options(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_calendar_get_date(int paramInt, int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3);
  
  public static final void gtk_calendar_get_date(int paramInt, int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3)
  {
    lock.lock();
    try
    {
      _gtk_calendar_get_date(paramInt, paramArrayOfInt1, paramArrayOfInt2, paramArrayOfInt3);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_cell_layout_clear(int paramInt);
  
  public static final void gtk_cell_layout_clear(int paramInt)
  {
    lock.lock();
    try
    {
      _gtk_cell_layout_clear(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_cell_layout_get_cells(int paramInt);
  
  public static final int gtk_cell_layout_get_cells(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_cell_layout_get_cells(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_cell_layout_set_attributes(int paramInt1, int paramInt2, byte[] paramArrayOfByte, int paramInt3, int paramInt4);
  
  public static final void gtk_cell_layout_set_attributes(int paramInt1, int paramInt2, byte[] paramArrayOfByte, int paramInt3, int paramInt4)
  {
    lock.lock();
    try
    {
      _gtk_cell_layout_set_attributes(paramInt1, paramInt2, paramArrayOfByte, paramInt3, paramInt4);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_cell_layout_pack_start(int paramInt1, int paramInt2, boolean paramBoolean);
  
  public static final void gtk_cell_layout_pack_start(int paramInt1, int paramInt2, boolean paramBoolean)
  {
    lock.lock();
    try
    {
      _gtk_cell_layout_pack_start(paramInt1, paramInt2, paramBoolean);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_cell_renderer_get_size(int paramInt1, int paramInt2, GdkRectangle paramGdkRectangle, int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3, int[] paramArrayOfInt4);
  
  public static final void gtk_cell_renderer_get_size(int paramInt1, int paramInt2, GdkRectangle paramGdkRectangle, int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3, int[] paramArrayOfInt4)
  {
    lock.lock();
    try
    {
      _gtk_cell_renderer_get_size(paramInt1, paramInt2, paramGdkRectangle, paramArrayOfInt1, paramArrayOfInt2, paramArrayOfInt3, paramArrayOfInt4);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_cell_renderer_get_preferred_size(int paramInt1, int paramInt2, GtkRequisition paramGtkRequisition1, GtkRequisition paramGtkRequisition2);
  
  public static final void gtk_cell_renderer_get_preferred_size(int paramInt1, int paramInt2, GtkRequisition paramGtkRequisition1, GtkRequisition paramGtkRequisition2)
  {
    lock.lock();
    try
    {
      _gtk_cell_renderer_get_preferred_size(paramInt1, paramInt2, paramGtkRequisition1, paramGtkRequisition2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_cell_renderer_get_preferred_height_for_width(int paramInt1, int paramInt2, int paramInt3, int[] paramArrayOfInt1, int[] paramArrayOfInt2);
  
  public static final void gtk_cell_renderer_get_preferred_height_for_width(int paramInt1, int paramInt2, int paramInt3, int[] paramArrayOfInt1, int[] paramArrayOfInt2)
  {
    lock.lock();
    try
    {
      _gtk_cell_renderer_get_preferred_height_for_width(paramInt1, paramInt2, paramInt3, paramArrayOfInt1, paramArrayOfInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_cell_renderer_set_fixed_size(int paramInt1, int paramInt2, int paramInt3);
  
  public static final void gtk_cell_renderer_set_fixed_size(int paramInt1, int paramInt2, int paramInt3)
  {
    lock.lock();
    try
    {
      _gtk_cell_renderer_set_fixed_size(paramInt1, paramInt2, paramInt3);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_widget_get_preferred_size(int paramInt, GtkRequisition paramGtkRequisition1, GtkRequisition paramGtkRequisition2);
  
  public static final void gtk_widget_get_preferred_size(int paramInt, GtkRequisition paramGtkRequisition1, GtkRequisition paramGtkRequisition2)
  {
    lock.lock();
    try
    {
      _gtk_widget_get_preferred_size(paramInt, paramGtkRequisition1, paramGtkRequisition2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_widget_get_preferred_height_for_width(int paramInt1, int paramInt2, int[] paramArrayOfInt1, int[] paramArrayOfInt2);
  
  public static final void gtk_widget_get_preferred_height_for_width(int paramInt1, int paramInt2, int[] paramArrayOfInt1, int[] paramArrayOfInt2)
  {
    lock.lock();
    try
    {
      _gtk_widget_get_preferred_height_for_width(paramInt1, paramInt2, paramArrayOfInt1, paramArrayOfInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_widget_get_preferred_width_for_height(int paramInt1, int paramInt2, int[] paramArrayOfInt1, int[] paramArrayOfInt2);
  
  public static final void gtk_widget_get_preferred_width_for_height(int paramInt1, int paramInt2, int[] paramArrayOfInt1, int[] paramArrayOfInt2)
  {
    lock.lock();
    try
    {
      _gtk_widget_get_preferred_width_for_height(paramInt1, paramInt2, paramArrayOfInt1, paramArrayOfInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_cell_renderer_pixbuf_new();
  
  public static final int gtk_cell_renderer_pixbuf_new()
  {
    lock.lock();
    try
    {
      int i = _gtk_cell_renderer_pixbuf_new();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_cell_renderer_text_new();
  
  public static final int gtk_cell_renderer_text_new()
  {
    lock.lock();
    try
    {
      int i = _gtk_cell_renderer_text_new();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_cell_renderer_toggle_new();
  
  public static final int gtk_cell_renderer_toggle_new()
  {
    lock.lock();
    try
    {
      int i = _gtk_cell_renderer_toggle_new();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_check_button_new();
  
  public static final int gtk_check_button_new()
  {
    lock.lock();
    try
    {
      int i = _gtk_check_button_new();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _gtk_check_menu_item_get_active(int paramInt);
  
  public static final boolean gtk_check_menu_item_get_active(int paramInt)
  {
    lock.lock();
    try
    {
      boolean bool = _gtk_check_menu_item_get_active(paramInt);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_check_menu_item_new_with_label(byte[] paramArrayOfByte);
  
  public static final int gtk_check_menu_item_new_with_label(byte[] paramArrayOfByte)
  {
    lock.lock();
    try
    {
      int i = _gtk_check_menu_item_new_with_label(paramArrayOfByte);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_check_menu_item_set_active(int paramInt, boolean paramBoolean);
  
  public static final void gtk_check_menu_item_set_active(int paramInt, boolean paramBoolean)
  {
    lock.lock();
    try
    {
      _gtk_check_menu_item_set_active(paramInt, paramBoolean);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_check_version(int paramInt1, int paramInt2, int paramInt3);
  
  public static final int gtk_check_version(int paramInt1, int paramInt2, int paramInt3)
  {
    lock.lock();
    try
    {
      int i = _gtk_check_version(paramInt1, paramInt2, paramInt3);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_clipboard_clear(int paramInt);
  
  public static final void gtk_clipboard_clear(int paramInt)
  {
    lock.lock();
    try
    {
      _gtk_clipboard_clear(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_clipboard_get(int paramInt);
  
  public static final int gtk_clipboard_get(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_clipboard_get(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _gtk_clipboard_set_with_owner(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6);
  
  public static final boolean gtk_clipboard_set_with_owner(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6)
  {
    lock.lock();
    try
    {
      boolean bool = _gtk_clipboard_set_with_owner(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_clipboard_set_can_store(int paramInt1, int paramInt2, int paramInt3);
  
  public static final void gtk_clipboard_set_can_store(int paramInt1, int paramInt2, int paramInt3)
  {
    lock.lock();
    try
    {
      _gtk_clipboard_set_can_store(paramInt1, paramInt2, paramInt3);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_clipboard_store(int paramInt);
  
  public static final void gtk_clipboard_store(int paramInt)
  {
    lock.lock();
    try
    {
      _gtk_clipboard_store(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_clipboard_wait_for_contents(int paramInt1, int paramInt2);
  
  public static final int gtk_clipboard_wait_for_contents(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      int i = _gtk_clipboard_wait_for_contents(paramInt1, paramInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_color_selection_dialog_new(byte[] paramArrayOfByte);
  
  public static final int gtk_color_selection_dialog_new(byte[] paramArrayOfByte)
  {
    lock.lock();
    try
    {
      int i = _gtk_color_selection_dialog_new(paramArrayOfByte);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_color_chooser_dialog_new(byte[] paramArrayOfByte, int paramInt);
  
  public static final int gtk_color_chooser_dialog_new(byte[] paramArrayOfByte, int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_color_chooser_dialog_new(paramArrayOfByte, paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_color_chooser_set_use_alpha(int paramInt, boolean paramBoolean);
  
  public static final void gtk_color_chooser_set_use_alpha(int paramInt, boolean paramBoolean)
  {
    lock.lock();
    try
    {
      _gtk_color_chooser_set_use_alpha(paramInt, paramBoolean);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_color_selection_dialog_get_color_selection(int paramInt);
  
  public static final int gtk_color_selection_dialog_get_color_selection(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_color_selection_dialog_get_color_selection(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_color_chooser_set_rgba(int paramInt, GdkRGBA paramGdkRGBA);
  
  public static final void gtk_color_chooser_get_rgba(int paramInt, GdkRGBA paramGdkRGBA)
  {
    lock.lock();
    try
    {
      _gtk_color_chooser_get_rgba(paramInt, paramGdkRGBA);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_color_chooser_get_rgba(int paramInt, GdkRGBA paramGdkRGBA);
  
  public static final void gtk_color_chooser_set_rgba(int paramInt, GdkRGBA paramGdkRGBA)
  {
    lock.lock();
    try
    {
      _gtk_color_chooser_set_rgba(paramInt, paramGdkRGBA);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_color_selection_get_current_color(int paramInt, GdkColor paramGdkColor);
  
  public static final void gtk_color_selection_get_current_color(int paramInt, GdkColor paramGdkColor)
  {
    lock.lock();
    try
    {
      _gtk_color_selection_get_current_color(paramInt, paramGdkColor);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_color_selection_palette_to_string(int paramInt1, int paramInt2);
  
  public static final int gtk_color_selection_palette_to_string(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      int i = _gtk_color_selection_palette_to_string(paramInt1, paramInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_color_selection_set_current_color(int paramInt, GdkColor paramGdkColor);
  
  public static final void gtk_color_selection_set_current_color(int paramInt, GdkColor paramGdkColor)
  {
    lock.lock();
    try
    {
      _gtk_color_selection_set_current_color(paramInt, paramGdkColor);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_color_selection_set_has_palette(int paramInt, boolean paramBoolean);
  
  public static final void gtk_color_selection_set_has_palette(int paramInt, boolean paramBoolean)
  {
    lock.lock();
    try
    {
      _gtk_color_selection_set_has_palette(paramInt, paramBoolean);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_combo_box_set_focus_on_click(int paramInt, boolean paramBoolean);
  
  public static final void gtk_combo_box_set_focus_on_click(int paramInt, boolean paramBoolean)
  {
    lock.lock();
    try
    {
      _gtk_combo_box_set_focus_on_click(paramInt, paramBoolean);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_combo_box_entry_new_text();
  
  public static final int gtk_combo_box_entry_new_text()
  {
    lock.lock();
    try
    {
      int i = _gtk_combo_box_entry_new_text();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_combo_box_new_text();
  
  public static final int gtk_combo_box_new_text()
  {
    lock.lock();
    try
    {
      int i = _gtk_combo_box_new_text();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_combo_box_text_new();
  
  public static final int gtk_combo_box_text_new()
  {
    lock.lock();
    try
    {
      int i = _gtk_combo_box_text_new();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_combo_box_text_new_with_entry();
  
  public static final int gtk_combo_box_text_new_with_entry()
  {
    lock.lock();
    try
    {
      int i = _gtk_combo_box_text_new_with_entry();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_combo_box_text_insert(int paramInt1, int paramInt2, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2);
  
  public static final void gtk_combo_box_text_insert(int paramInt1, int paramInt2, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    lock.lock();
    try
    {
      _gtk_combo_box_text_insert(paramInt1, paramInt2, paramArrayOfByte1, paramArrayOfByte2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_combo_box_insert_text(int paramInt1, int paramInt2, byte[] paramArrayOfByte);
  
  public static final void gtk_combo_box_insert_text(int paramInt1, int paramInt2, byte[] paramArrayOfByte)
  {
    lock.lock();
    try
    {
      _gtk_combo_box_insert_text(paramInt1, paramInt2, paramArrayOfByte);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_combo_box_remove_text(int paramInt1, int paramInt2);
  
  public static final void gtk_combo_box_remove_text(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_combo_box_remove_text(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_combo_box_text_remove(int paramInt1, int paramInt2);
  
  public static final void gtk_combo_box_text_remove(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_combo_box_text_remove(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_combo_box_text_remove_all(int paramInt);
  
  public static final void gtk_combo_box_text_remove_all(int paramInt)
  {
    lock.lock();
    try
    {
      _gtk_combo_box_text_remove_all(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_combo_box_get_active(int paramInt);
  
  public static final int gtk_combo_box_get_active(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_combo_box_get_active(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_combo_box_get_model(int paramInt);
  
  public static final int gtk_combo_box_get_model(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_combo_box_get_model(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_combo_box_set_active(int paramInt1, int paramInt2);
  
  public static final void gtk_combo_box_set_active(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_combo_box_set_active(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_combo_box_set_wrap_width(int paramInt1, int paramInt2);
  
  public static final void gtk_combo_box_set_wrap_width(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_combo_box_set_wrap_width(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_combo_box_popup(int paramInt);
  
  public static final void gtk_combo_box_popup(int paramInt)
  {
    lock.lock();
    try
    {
      _gtk_combo_box_popup(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_combo_box_popdown(int paramInt);
  
  public static final void gtk_combo_box_popdown(int paramInt)
  {
    lock.lock();
    try
    {
      _gtk_combo_box_popdown(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_container_add(int paramInt1, int paramInt2);
  
  public static final void gtk_container_add(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_container_add(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_container_forall(int paramInt1, int paramInt2, int paramInt3);
  
  public static final void gtk_container_forall(int paramInt1, int paramInt2, int paramInt3)
  {
    lock.lock();
    try
    {
      _gtk_container_forall(paramInt1, paramInt2, paramInt3);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_container_get_border_width(int paramInt);
  
  public static final int gtk_container_get_border_width(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_container_get_border_width(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_container_get_children(int paramInt);
  
  public static final int gtk_container_get_children(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_container_get_children(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_container_remove(int paramInt1, int paramInt2);
  
  public static final void gtk_container_remove(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_container_remove(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_container_resize_children(int paramInt);
  
  public static final void gtk_container_resize_children(int paramInt)
  {
    lock.lock();
    try
    {
      _gtk_container_resize_children(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_container_set_border_width(int paramInt1, int paramInt2);
  
  public static final void gtk_container_set_border_width(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_container_set_border_width(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_dialog_add_button(int paramInt1, byte[] paramArrayOfByte, int paramInt2);
  
  public static final int gtk_dialog_add_button(int paramInt1, byte[] paramArrayOfByte, int paramInt2)
  {
    lock.lock();
    try
    {
      int i = _gtk_dialog_add_button(paramInt1, paramArrayOfByte, paramInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_dialog_run(int paramInt);
  
  public static final int gtk_dialog_run(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_dialog_run(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_drag_begin(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5);
  
  public static final int gtk_drag_begin(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
  {
    lock.lock();
    try
    {
      int i = _gtk_drag_begin(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _gtk_drag_check_threshold(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5);
  
  public static final boolean gtk_drag_check_threshold(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
  {
    lock.lock();
    try
    {
      boolean bool = _gtk_drag_check_threshold(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_drag_dest_find_target(int paramInt1, int paramInt2, int paramInt3);
  
  public static final int gtk_drag_dest_find_target(int paramInt1, int paramInt2, int paramInt3)
  {
    lock.lock();
    try
    {
      int i = _gtk_drag_dest_find_target(paramInt1, paramInt2, paramInt3);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_drag_dest_set(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5);
  
  public static final void gtk_drag_dest_set(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
  {
    lock.lock();
    try
    {
      _gtk_drag_dest_set(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_drag_dest_unset(int paramInt);
  
  public static final void gtk_drag_dest_unset(int paramInt)
  {
    lock.lock();
    try
    {
      _gtk_drag_dest_unset(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_drag_finish(int paramInt1, boolean paramBoolean1, boolean paramBoolean2, int paramInt2);
  
  public static final void gtk_drag_finish(int paramInt1, boolean paramBoolean1, boolean paramBoolean2, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_drag_finish(paramInt1, paramBoolean1, paramBoolean2, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_drag_get_data(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  public static final void gtk_drag_get_data(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    lock.lock();
    try
    {
      _gtk_drag_get_data(paramInt1, paramInt2, paramInt3, paramInt4);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_drag_set_icon_pixbuf(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  public static final void gtk_drag_set_icon_pixbuf(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    lock.lock();
    try
    {
      _gtk_drag_set_icon_pixbuf(paramInt1, paramInt2, paramInt3, paramInt4);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_drag_set_icon_surface(int paramInt1, int paramInt2);
  
  public static final void gtk_drag_set_icon_surface(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_drag_set_icon_surface(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_editable_copy_clipboard(int paramInt);
  
  public static final void gtk_editable_copy_clipboard(int paramInt)
  {
    lock.lock();
    try
    {
      _gtk_editable_copy_clipboard(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_editable_cut_clipboard(int paramInt);
  
  public static final void gtk_editable_cut_clipboard(int paramInt)
  {
    lock.lock();
    try
    {
      _gtk_editable_cut_clipboard(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_editable_delete_selection(int paramInt);
  
  public static final void gtk_editable_delete_selection(int paramInt)
  {
    lock.lock();
    try
    {
      _gtk_editable_delete_selection(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_editable_delete_text(int paramInt1, int paramInt2, int paramInt3);
  
  public static final void gtk_editable_delete_text(int paramInt1, int paramInt2, int paramInt3)
  {
    lock.lock();
    try
    {
      _gtk_editable_delete_text(paramInt1, paramInt2, paramInt3);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _gtk_editable_get_editable(int paramInt);
  
  public static final boolean gtk_editable_get_editable(int paramInt)
  {
    lock.lock();
    try
    {
      boolean bool = _gtk_editable_get_editable(paramInt);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_editable_get_position(int paramInt);
  
  public static final int gtk_editable_get_position(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_editable_get_position(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _gtk_editable_get_selection_bounds(int paramInt, int[] paramArrayOfInt1, int[] paramArrayOfInt2);
  
  public static final boolean gtk_editable_get_selection_bounds(int paramInt, int[] paramArrayOfInt1, int[] paramArrayOfInt2)
  {
    lock.lock();
    try
    {
      boolean bool = _gtk_editable_get_selection_bounds(paramInt, paramArrayOfInt1, paramArrayOfInt2);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_editable_insert_text(int paramInt1, byte[] paramArrayOfByte, int paramInt2, int[] paramArrayOfInt);
  
  public static final void gtk_editable_insert_text(int paramInt1, byte[] paramArrayOfByte, int paramInt2, int[] paramArrayOfInt)
  {
    lock.lock();
    try
    {
      _gtk_editable_insert_text(paramInt1, paramArrayOfByte, paramInt2, paramArrayOfInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_editable_paste_clipboard(int paramInt);
  
  public static final void gtk_editable_paste_clipboard(int paramInt)
  {
    lock.lock();
    try
    {
      _gtk_editable_paste_clipboard(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_editable_select_region(int paramInt1, int paramInt2, int paramInt3);
  
  public static final void gtk_editable_select_region(int paramInt1, int paramInt2, int paramInt3)
  {
    lock.lock();
    try
    {
      _gtk_editable_select_region(paramInt1, paramInt2, paramInt3);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_editable_set_editable(int paramInt, boolean paramBoolean);
  
  public static final void gtk_editable_set_editable(int paramInt, boolean paramBoolean)
  {
    lock.lock();
    try
    {
      _gtk_editable_set_editable(paramInt, paramBoolean);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_editable_set_position(int paramInt1, int paramInt2);
  
  public static final void gtk_editable_set_position(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_editable_set_position(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_entry_get_inner_border(int paramInt);
  
  public static final int gtk_entry_get_inner_border(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_entry_get_inner_border(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_entry_set_width_chars(int paramInt1, int paramInt2);
  
  public static final void gtk_entry_set_width_chars(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_entry_set_width_chars(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native char _gtk_entry_get_invisible_char(int paramInt);
  
  public static final char gtk_entry_get_invisible_char(int paramInt)
  {
    lock.lock();
    try
    {
      char c = _gtk_entry_get_invisible_char(paramInt);
      return c;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_entry_get_layout(int paramInt);
  
  public static final int gtk_entry_get_layout(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_entry_get_layout(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_entry_get_layout_offsets(int paramInt, int[] paramArrayOfInt1, int[] paramArrayOfInt2);
  
  public static final void gtk_entry_get_layout_offsets(int paramInt, int[] paramArrayOfInt1, int[] paramArrayOfInt2)
  {
    lock.lock();
    try
    {
      _gtk_entry_get_layout_offsets(paramInt, paramArrayOfInt1, paramArrayOfInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_entry_text_index_to_layout_index(int paramInt1, int paramInt2);
  
  public static final int gtk_entry_text_index_to_layout_index(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      int i = _gtk_entry_text_index_to_layout_index(paramInt1, paramInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_entry_get_icon_area(int paramInt1, int paramInt2, GdkRectangle paramGdkRectangle);
  
  public static final int gtk_entry_get_icon_area(int paramInt1, int paramInt2, GdkRectangle paramGdkRectangle)
  {
    lock.lock();
    try
    {
      int i = _gtk_entry_get_icon_area(paramInt1, paramInt2, paramGdkRectangle);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_entry_get_max_length(int paramInt);
  
  public static final int gtk_entry_get_max_length(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_entry_get_max_length(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_entry_get_text(int paramInt);
  
  public static final int gtk_entry_get_text(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_entry_get_text(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _FcConfigAppFontAddFile(int paramInt, byte[] paramArrayOfByte);
  
  public static final boolean FcConfigAppFontAddFile(int paramInt, byte[] paramArrayOfByte)
  {
    lock.lock();
    try
    {
      boolean bool = _FcConfigAppFontAddFile(paramInt, paramArrayOfByte);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _gtk_entry_get_visibility(int paramInt);
  
  public static final boolean gtk_entry_get_visibility(int paramInt)
  {
    lock.lock();
    try
    {
      boolean bool = _gtk_entry_get_visibility(paramInt);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_entry_new();
  
  public static final int gtk_entry_new()
  {
    lock.lock();
    try
    {
      int i = _gtk_entry_new();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_entry_set_alignment(int paramInt, float paramFloat);
  
  public static final void gtk_entry_set_alignment(int paramInt, float paramFloat)
  {
    lock.lock();
    try
    {
      _gtk_entry_set_alignment(paramInt, paramFloat);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_entry_set_has_frame(int paramInt, boolean paramBoolean);
  
  public static final void gtk_entry_set_has_frame(int paramInt, boolean paramBoolean)
  {
    lock.lock();
    try
    {
      _gtk_entry_set_has_frame(paramInt, paramBoolean);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_entry_set_icon_from_stock(int paramInt1, int paramInt2, byte[] paramArrayOfByte);
  
  public static final void gtk_entry_set_icon_from_stock(int paramInt1, int paramInt2, byte[] paramArrayOfByte)
  {
    lock.lock();
    try
    {
      _gtk_entry_set_icon_from_stock(paramInt1, paramInt2, paramArrayOfByte);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_entry_set_icon_sensitive(int paramInt1, int paramInt2, boolean paramBoolean);
  
  public static final void gtk_entry_set_icon_sensitive(int paramInt1, int paramInt2, boolean paramBoolean)
  {
    lock.lock();
    try
    {
      _gtk_entry_set_icon_sensitive(paramInt1, paramInt2, paramBoolean);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_entry_set_invisible_char(int paramInt, char paramChar);
  
  public static final void gtk_entry_set_invisible_char(int paramInt, char paramChar)
  {
    lock.lock();
    try
    {
      _gtk_entry_set_invisible_char(paramInt, paramChar);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_entry_set_max_length(int paramInt1, int paramInt2);
  
  public static final void gtk_entry_set_max_length(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_entry_set_max_length(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_entry_set_text(int paramInt, byte[] paramArrayOfByte);
  
  public static final void gtk_entry_set_text(int paramInt, byte[] paramArrayOfByte)
  {
    lock.lock();
    try
    {
      _gtk_entry_set_text(paramInt, paramArrayOfByte);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_entry_set_placeholder_text(int paramInt, byte[] paramArrayOfByte);
  
  public static final void gtk_entry_set_placeholder_text(int paramInt, byte[] paramArrayOfByte)
  {
    lock.lock();
    try
    {
      _gtk_entry_set_placeholder_text(paramInt, paramArrayOfByte);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_entry_set_visibility(int paramInt, boolean paramBoolean);
  
  public static final void gtk_entry_set_visibility(int paramInt, boolean paramBoolean)
  {
    lock.lock();
    try
    {
      _gtk_entry_set_visibility(paramInt, paramBoolean);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _gtk_expander_get_expanded(int paramInt);
  
  public static final boolean gtk_expander_get_expanded(int paramInt)
  {
    lock.lock();
    try
    {
      boolean bool = _gtk_expander_get_expanded(paramInt);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_expander_new(byte[] paramArrayOfByte);
  
  public static final int gtk_expander_new(byte[] paramArrayOfByte)
  {
    lock.lock();
    try
    {
      int i = _gtk_expander_new(paramArrayOfByte);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_expander_set_expanded(int paramInt, boolean paramBoolean);
  
  public static final void gtk_expander_set_expanded(int paramInt, boolean paramBoolean)
  {
    lock.lock();
    try
    {
      _gtk_expander_set_expanded(paramInt, paramBoolean);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_expander_set_label_widget(int paramInt1, int paramInt2);
  
  public static final void gtk_expander_set_label_widget(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_expander_set_label_widget(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_file_chooser_add_filter(int paramInt1, int paramInt2);
  
  public static final void gtk_file_chooser_add_filter(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_file_chooser_add_filter(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_file_chooser_dialog_new(byte[] paramArrayOfByte, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7);
  
  public static final int gtk_file_chooser_dialog_new(byte[] paramArrayOfByte, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7)
  {
    lock.lock();
    try
    {
      int i = _gtk_file_chooser_dialog_new(paramArrayOfByte, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_file_chooser_get_filename(int paramInt);
  
  public static final int gtk_file_chooser_get_filename(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_file_chooser_get_filename(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_file_chooser_get_filenames(int paramInt);
  
  public static final int gtk_file_chooser_get_filenames(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_file_chooser_get_filenames(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_file_chooser_get_uri(int paramInt);
  
  public static final int gtk_file_chooser_get_uri(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_file_chooser_get_uri(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_file_chooser_get_uris(int paramInt);
  
  public static final int gtk_file_chooser_get_uris(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_file_chooser_get_uris(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_file_chooser_get_filter(int paramInt);
  
  public static final int gtk_file_chooser_get_filter(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_file_chooser_get_filter(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_file_chooser_set_current_folder(int paramInt1, int paramInt2);
  
  public static final void gtk_file_chooser_set_current_folder(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_file_chooser_set_current_folder(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_file_chooser_set_current_folder_uri(int paramInt, byte[] paramArrayOfByte);
  
  public static final void gtk_file_chooser_set_current_folder_uri(int paramInt, byte[] paramArrayOfByte)
  {
    lock.lock();
    try
    {
      _gtk_file_chooser_set_current_folder_uri(paramInt, paramArrayOfByte);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_file_chooser_set_current_name(int paramInt, byte[] paramArrayOfByte);
  
  public static final void gtk_file_chooser_set_current_name(int paramInt, byte[] paramArrayOfByte)
  {
    lock.lock();
    try
    {
      _gtk_file_chooser_set_current_name(paramInt, paramArrayOfByte);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_file_chooser_set_local_only(int paramInt, boolean paramBoolean);
  
  public static final void gtk_file_chooser_set_local_only(int paramInt, boolean paramBoolean)
  {
    lock.lock();
    try
    {
      _gtk_file_chooser_set_local_only(paramInt, paramBoolean);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_file_chooser_set_do_overwrite_confirmation(int paramInt, boolean paramBoolean);
  
  public static final void gtk_file_chooser_set_do_overwrite_confirmation(int paramInt, boolean paramBoolean)
  {
    lock.lock();
    try
    {
      _gtk_file_chooser_set_do_overwrite_confirmation(paramInt, paramBoolean);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_file_chooser_set_extra_widget(int paramInt1, int paramInt2);
  
  public static final void gtk_file_chooser_set_extra_widget(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_file_chooser_set_extra_widget(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_file_chooser_set_filename(int paramInt1, int paramInt2);
  
  public static final void gtk_file_chooser_set_filename(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_file_chooser_set_filename(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_file_chooser_set_filter(int paramInt1, int paramInt2);
  
  public static final void gtk_file_chooser_set_filter(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_file_chooser_set_filter(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_file_chooser_set_uri(int paramInt, byte[] paramArrayOfByte);
  
  public static final void gtk_file_chooser_set_uri(int paramInt, byte[] paramArrayOfByte)
  {
    lock.lock();
    try
    {
      _gtk_file_chooser_set_uri(paramInt, paramArrayOfByte);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_file_chooser_set_select_multiple(int paramInt, boolean paramBoolean);
  
  public static final void gtk_file_chooser_set_select_multiple(int paramInt, boolean paramBoolean)
  {
    lock.lock();
    try
    {
      _gtk_file_chooser_set_select_multiple(paramInt, paramBoolean);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_file_filter_add_pattern(int paramInt, byte[] paramArrayOfByte);
  
  public static final void gtk_file_filter_add_pattern(int paramInt, byte[] paramArrayOfByte)
  {
    lock.lock();
    try
    {
      _gtk_file_filter_add_pattern(paramInt, paramArrayOfByte);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_file_filter_new();
  
  public static final int gtk_file_filter_new()
  {
    lock.lock();
    try
    {
      int i = _gtk_file_filter_new();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_file_filter_get_name(int paramInt);
  
  public static final int gtk_file_filter_get_name(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_file_filter_get_name(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_file_filter_set_name(int paramInt, byte[] paramArrayOfByte);
  
  public static final void gtk_file_filter_set_name(int paramInt, byte[] paramArrayOfByte)
  {
    lock.lock();
    try
    {
      _gtk_file_filter_set_name(paramInt, paramArrayOfByte);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_fixed_move(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  public static final void gtk_fixed_move(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    lock.lock();
    try
    {
      _gtk_fixed_move(paramInt1, paramInt2, paramInt3, paramInt4);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_fixed_new();
  
  public static final int gtk_fixed_new()
  {
    lock.lock();
    try
    {
      int i = _gtk_fixed_new();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_fixed_set_has_window(int paramInt, boolean paramBoolean);
  
  public static final void gtk_fixed_set_has_window(int paramInt, boolean paramBoolean)
  {
    lock.lock();
    try
    {
      _gtk_fixed_set_has_window(paramInt, paramBoolean);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_widget_set_has_window(int paramInt, boolean paramBoolean);
  
  public static final void gtk_widget_set_has_window(int paramInt, boolean paramBoolean)
  {
    lock.lock();
    try
    {
      _gtk_widget_set_has_window(paramInt, paramBoolean);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_font_selection_dialog_get_font_name(int paramInt);
  
  public static final int gtk_font_selection_dialog_get_font_name(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_font_selection_dialog_get_font_name(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_font_chooser_dialog_new(byte[] paramArrayOfByte, int paramInt);
  
  public static final int gtk_font_chooser_dialog_new(byte[] paramArrayOfByte, int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_font_chooser_dialog_new(paramArrayOfByte, paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_font_chooser_get_font(int paramInt);
  
  public static final int gtk_font_chooser_get_font(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_font_chooser_get_font(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_font_chooser_set_font(int paramInt, byte[] paramArrayOfByte);
  
  public static final void gtk_font_chooser_set_font(int paramInt, byte[] paramArrayOfByte)
  {
    lock.lock();
    try
    {
      _gtk_font_chooser_set_font(paramInt, paramArrayOfByte);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_font_selection_dialog_new(byte[] paramArrayOfByte);
  
  public static final int gtk_font_selection_dialog_new(byte[] paramArrayOfByte)
  {
    lock.lock();
    try
    {
      int i = _gtk_font_selection_dialog_new(paramArrayOfByte);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _gtk_font_selection_dialog_set_font_name(int paramInt, byte[] paramArrayOfByte);
  
  public static final boolean gtk_font_selection_dialog_set_font_name(int paramInt, byte[] paramArrayOfByte)
  {
    lock.lock();
    try
    {
      boolean bool = _gtk_font_selection_dialog_set_font_name(paramInt, paramArrayOfByte);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_frame_new(byte[] paramArrayOfByte);
  
  public static final int gtk_frame_new(byte[] paramArrayOfByte)
  {
    lock.lock();
    try
    {
      int i = _gtk_frame_new(paramArrayOfByte);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_frame_get_label_widget(int paramInt);
  
  public static final int gtk_frame_get_label_widget(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_frame_get_label_widget(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_frame_set_label_widget(int paramInt1, int paramInt2);
  
  public static final void gtk_frame_set_label_widget(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_frame_set_label_widget(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_frame_set_shadow_type(int paramInt1, int paramInt2);
  
  public static final void gtk_frame_set_shadow_type(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_frame_set_shadow_type(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_get_current_event();
  
  public static final int gtk_get_current_event()
  {
    lock.lock();
    try
    {
      int i = _gtk_get_current_event();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _gtk_get_current_event_state(int[] paramArrayOfInt);
  
  public static final boolean gtk_get_current_event_state(int[] paramArrayOfInt)
  {
    lock.lock();
    try
    {
      boolean bool = _gtk_get_current_event_state(paramArrayOfInt);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_get_default_language();
  
  public static final int gtk_get_default_language()
  {
    lock.lock();
    try
    {
      int i = _gtk_get_default_language();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_get_event_widget(int paramInt);
  
  public static final int gtk_get_event_widget(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_get_event_widget(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_grab_get_current();
  
  public static final int gtk_grab_get_current()
  {
    lock.lock();
    try
    {
      int i = _gtk_grab_get_current();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_hbox_new(boolean paramBoolean, int paramInt);
  
  public static final int gtk_hbox_new(boolean paramBoolean, int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_hbox_new(paramBoolean, paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_hsv_to_rgb(double paramDouble1, double paramDouble2, double paramDouble3, double[] paramArrayOfDouble1, double[] paramArrayOfDouble2, double[] paramArrayOfDouble3);
  
  public static final int gtk_hsv_to_rgb(double paramDouble1, double paramDouble2, double paramDouble3, double[] paramArrayOfDouble1, double[] paramArrayOfDouble2, double[] paramArrayOfDouble3)
  {
    lock.lock();
    try
    {
      int i = _gtk_hsv_to_rgb(paramDouble1, paramDouble2, paramDouble3, paramArrayOfDouble1, paramArrayOfDouble2, paramArrayOfDouble3);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_rgb_to_hsv(double paramDouble1, double paramDouble2, double paramDouble3, double[] paramArrayOfDouble1, double[] paramArrayOfDouble2, double[] paramArrayOfDouble3);
  
  public static final int gtk_rgb_to_hsv(double paramDouble1, double paramDouble2, double paramDouble3, double[] paramArrayOfDouble1, double[] paramArrayOfDouble2, double[] paramArrayOfDouble3)
  {
    lock.lock();
    try
    {
      int i = _gtk_rgb_to_hsv(paramDouble1, paramDouble2, paramDouble3, paramArrayOfDouble1, paramArrayOfDouble2, paramArrayOfDouble3);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_box_new(int paramInt1, int paramInt2);
  
  public static final int gtk_box_new(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      int i = _gtk_box_new(paramInt1, paramInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_box_set_homogeneous(int paramInt, boolean paramBoolean);
  
  public static final void gtk_box_set_homogeneous(int paramInt, boolean paramBoolean)
  {
    lock.lock();
    try
    {
      _gtk_box_set_homogeneous(paramInt, paramBoolean);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_hscale_new(int paramInt);
  
  public static final int gtk_hscale_new(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_hscale_new(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_scale_new(int paramInt1, int paramInt2);
  
  public static final int gtk_scale_new(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      int i = _gtk_scale_new(paramInt1, paramInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_hscrollbar_new(int paramInt);
  
  public static final int gtk_hscrollbar_new(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_hscrollbar_new(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_scrollbar_new(int paramInt1, int paramInt2);
  
  public static final int gtk_scrollbar_new(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      int i = _gtk_scrollbar_new(paramInt1, paramInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_hseparator_new();
  
  public static final int gtk_hseparator_new()
  {
    lock.lock();
    try
    {
      int i = _gtk_hseparator_new();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_separator_new(int paramInt);
  
  public static final int gtk_separator_new(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_separator_new(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_status_icon_position_menu_func();
  
  public static final int gtk_status_icon_position_menu_func()
  {
    lock.lock();
    try
    {
      int i = _gtk_status_icon_position_menu_func();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_icon_info_free(int paramInt);
  
  public static final void gtk_icon_info_free(int paramInt)
  {
    lock.lock();
    try
    {
      _gtk_icon_info_free(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_icon_factory_lookup_default(byte[] paramArrayOfByte);
  
  public static final int gtk_icon_factory_lookup_default(byte[] paramArrayOfByte)
  {
    lock.lock();
    try
    {
      int i = _gtk_icon_factory_lookup_default(paramArrayOfByte);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_icon_source_free(int paramInt);
  
  public static final void gtk_icon_source_free(int paramInt)
  {
    lock.lock();
    try
    {
      _gtk_icon_source_free(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_icon_source_new();
  
  public static final int gtk_icon_source_new()
  {
    lock.lock();
    try
    {
      int i = _gtk_icon_source_new();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_icon_source_set_pixbuf(int paramInt1, int paramInt2);
  
  public static final void gtk_icon_source_set_pixbuf(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_icon_source_set_pixbuf(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_icon_set_render_icon(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7);
  
  public static final int gtk_icon_set_render_icon(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7)
  {
    lock.lock();
    try
    {
      int i = _gtk_icon_set_render_icon(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_icon_set_render_icon_pixbuf(int paramInt1, int paramInt2, int paramInt3);
  
  public static final int gtk_icon_set_render_icon_pixbuf(int paramInt1, int paramInt2, int paramInt3)
  {
    lock.lock();
    try
    {
      int i = _gtk_icon_set_render_icon_pixbuf(paramInt1, paramInt2, paramInt3);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_icon_theme_get_default();
  
  public static final int gtk_icon_theme_get_default()
  {
    lock.lock();
    try
    {
      int i = _gtk_icon_theme_get_default();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_icon_theme_lookup_by_gicon(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  public static final int gtk_icon_theme_lookup_by_gicon(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    lock.lock();
    try
    {
      int i = _gtk_icon_theme_lookup_by_gicon(paramInt1, paramInt2, paramInt3, paramInt4);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_icon_info_load_icon(int paramInt, int[] paramArrayOfInt);
  
  public static final int gtk_icon_info_load_icon(int paramInt, int[] paramArrayOfInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_icon_info_load_icon(paramInt, paramArrayOfInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _gtk_im_context_filter_keypress(int paramInt1, int paramInt2);
  
  public static final boolean gtk_im_context_filter_keypress(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      boolean bool = _gtk_im_context_filter_keypress(paramInt1, paramInt2);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_im_context_focus_in(int paramInt);
  
  public static final void gtk_im_context_focus_in(int paramInt)
  {
    lock.lock();
    try
    {
      _gtk_im_context_focus_in(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_im_context_focus_out(int paramInt);
  
  public static final void gtk_im_context_focus_out(int paramInt)
  {
    lock.lock();
    try
    {
      _gtk_im_context_focus_out(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_im_context_get_preedit_string(int paramInt, int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3);
  
  public static final void gtk_im_context_get_preedit_string(int paramInt, int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3)
  {
    lock.lock();
    try
    {
      _gtk_im_context_get_preedit_string(paramInt, paramArrayOfInt1, paramArrayOfInt2, paramArrayOfInt3);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_im_context_get_type();
  
  public static final int gtk_im_context_get_type()
  {
    lock.lock();
    try
    {
      int i = _gtk_im_context_get_type();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_im_context_reset(int paramInt);
  
  public static final void gtk_im_context_reset(int paramInt)
  {
    lock.lock();
    try
    {
      _gtk_im_context_reset(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_im_context_set_client_window(int paramInt1, int paramInt2);
  
  public static final void gtk_im_context_set_client_window(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_im_context_set_client_window(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_im_context_set_cursor_location(int paramInt, GdkRectangle paramGdkRectangle);
  
  public static final void gtk_im_context_set_cursor_location(int paramInt, GdkRectangle paramGdkRectangle)
  {
    lock.lock();
    try
    {
      _gtk_im_context_set_cursor_location(paramInt, paramGdkRectangle);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_im_multicontext_append_menuitems(int paramInt1, int paramInt2);
  
  public static final void gtk_im_multicontext_append_menuitems(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_im_multicontext_append_menuitems(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_im_multicontext_new();
  
  public static final int gtk_im_multicontext_new()
  {
    lock.lock();
    try
    {
      int i = _gtk_im_multicontext_new();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_image_menu_item_new_with_label(byte[] paramArrayOfByte);
  
  public static final int gtk_image_menu_item_new_with_label(byte[] paramArrayOfByte)
  {
    lock.lock();
    try
    {
      int i = _gtk_image_menu_item_new_with_label(paramArrayOfByte);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_image_menu_item_set_image(int paramInt1, int paramInt2);
  
  public static final void gtk_image_menu_item_set_image(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_image_menu_item_set_image(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_image_new();
  
  public static final int gtk_image_new()
  {
    lock.lock();
    try
    {
      int i = _gtk_image_new();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_image_new_from_pixbuf(int paramInt);
  
  public static final int gtk_image_new_from_pixbuf(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_image_new_from_pixbuf(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_image_set_from_pixbuf(int paramInt1, int paramInt2);
  
  public static final void gtk_image_set_from_pixbuf(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_image_set_from_pixbuf(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_image_set_from_gicon(int paramInt1, int paramInt2, int paramInt3);
  
  public static final void gtk_image_set_from_gicon(int paramInt1, int paramInt2, int paramInt3)
  {
    lock.lock();
    try
    {
      _gtk_image_set_from_gicon(paramInt1, paramInt2, paramInt3);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _gtk_init_check(int[] paramArrayOfInt1, int[] paramArrayOfInt2);
  
  public static final boolean gtk_init_check(int[] paramArrayOfInt1, int[] paramArrayOfInt2)
  {
    lock.lock();
    try
    {
      boolean bool = _gtk_init_check(paramArrayOfInt1, paramArrayOfInt2);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_label_get_layout(int paramInt);
  
  public static final int gtk_label_get_layout(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_label_get_layout(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_label_get_mnemonic_keyval(int paramInt);
  
  public static final int gtk_label_get_mnemonic_keyval(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_label_get_mnemonic_keyval(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_label_new(byte[] paramArrayOfByte);
  
  public static final int gtk_label_new(byte[] paramArrayOfByte)
  {
    lock.lock();
    try
    {
      int i = _gtk_label_new(paramArrayOfByte);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_label_new_with_mnemonic(byte[] paramArrayOfByte);
  
  public static final int gtk_label_new_with_mnemonic(byte[] paramArrayOfByte)
  {
    lock.lock();
    try
    {
      int i = _gtk_label_new_with_mnemonic(paramArrayOfByte);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_label_set_attributes(int paramInt1, int paramInt2);
  
  public static final void gtk_label_set_attributes(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_label_set_attributes(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_label_set_justify(int paramInt1, int paramInt2);
  
  public static final void gtk_label_set_justify(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_label_set_justify(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_label_set_line_wrap(int paramInt, boolean paramBoolean);
  
  public static final void gtk_label_set_line_wrap(int paramInt, boolean paramBoolean)
  {
    lock.lock();
    try
    {
      _gtk_label_set_line_wrap(paramInt, paramBoolean);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_label_set_line_wrap_mode(int paramInt1, int paramInt2);
  
  public static final void gtk_label_set_line_wrap_mode(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_label_set_line_wrap_mode(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_label_set_text(int paramInt1, int paramInt2);
  
  public static final void gtk_label_set_text(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_label_set_text(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_label_set_text(int paramInt, byte[] paramArrayOfByte);
  
  public static final void gtk_label_set_text(int paramInt, byte[] paramArrayOfByte)
  {
    lock.lock();
    try
    {
      _gtk_label_set_text(paramInt, paramArrayOfByte);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_label_set_text_with_mnemonic(int paramInt, byte[] paramArrayOfByte);
  
  public static final void gtk_label_set_text_with_mnemonic(int paramInt, byte[] paramArrayOfByte)
  {
    lock.lock();
    try
    {
      _gtk_label_set_text_with_mnemonic(paramInt, paramArrayOfByte);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_list_store_append(int paramInt1, int paramInt2);
  
  public static final void gtk_list_store_append(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_list_store_append(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_list_store_clear(int paramInt);
  
  public static final void gtk_list_store_clear(int paramInt)
  {
    lock.lock();
    try
    {
      _gtk_list_store_clear(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_list_store_insert(int paramInt1, int paramInt2, int paramInt3);
  
  public static final void gtk_list_store_insert(int paramInt1, int paramInt2, int paramInt3)
  {
    lock.lock();
    try
    {
      _gtk_list_store_insert(paramInt1, paramInt2, paramInt3);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_list_store_newv(int paramInt, int[] paramArrayOfInt);
  
  public static final int gtk_list_store_newv(int paramInt, int[] paramArrayOfInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_list_store_newv(paramInt, paramArrayOfInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _gtk_css_provider_load_from_data(int paramInt1, byte[] paramArrayOfByte, int paramInt2, int[] paramArrayOfInt);
  
  public static final boolean gtk_css_provider_load_from_data(int paramInt1, byte[] paramArrayOfByte, int paramInt2, int[] paramArrayOfInt)
  {
    lock.lock();
    try
    {
      boolean bool = _gtk_css_provider_load_from_data(paramInt1, paramArrayOfByte, paramInt2, paramArrayOfInt);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_css_provider_new();
  
  public static final int gtk_css_provider_new()
  {
    lock.lock();
    try
    {
      int i = _gtk_css_provider_new();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_style_context_add_provider_for_screen(int paramInt1, int paramInt2, int paramInt3);
  
  public static final void gtk_style_context_add_provider_for_screen(int paramInt1, int paramInt2, int paramInt3)
  {
    lock.lock();
    try
    {
      _gtk_style_context_add_provider_for_screen(paramInt1, paramInt2, paramInt3);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_style_context_add_provider(int paramInt1, int paramInt2, int paramInt3);
  
  public static final void gtk_style_context_add_provider(int paramInt1, int paramInt2, int paramInt3)
  {
    lock.lock();
    try
    {
      _gtk_style_context_add_provider(paramInt1, paramInt2, paramInt3);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_list_store_remove(int paramInt1, int paramInt2);
  
  public static final void gtk_list_store_remove(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_list_store_remove(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_list_store_set(int paramInt1, int paramInt2, int paramInt3, byte[] paramArrayOfByte, int paramInt4);
  
  public static final void gtk_list_store_set(int paramInt1, int paramInt2, int paramInt3, byte[] paramArrayOfByte, int paramInt4)
  {
    lock.lock();
    try
    {
      _gtk_list_store_set(paramInt1, paramInt2, paramInt3, paramArrayOfByte, paramInt4);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_list_store_set(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5);
  
  public static final void gtk_list_store_set(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
  {
    lock.lock();
    try
    {
      _gtk_list_store_set(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_list_store_set(int paramInt1, int paramInt2, int paramInt3, long paramLong, int paramInt4);
  
  public static final void gtk_list_store_set(int paramInt1, int paramInt2, int paramInt3, long paramLong, int paramInt4)
  {
    lock.lock();
    try
    {
      _gtk_list_store_set(paramInt1, paramInt2, paramInt3, paramLong, paramInt4);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_list_store_set(int paramInt1, int paramInt2, int paramInt3, GdkColor paramGdkColor, int paramInt4);
  
  public static final void gtk_list_store_set(int paramInt1, int paramInt2, int paramInt3, GdkColor paramGdkColor, int paramInt4)
  {
    lock.lock();
    try
    {
      _gtk_list_store_set(paramInt1, paramInt2, paramInt3, paramGdkColor, paramInt4);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_list_store_set(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean, int paramInt4);
  
  public static final void gtk_list_store_set(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean, int paramInt4)
  {
    lock.lock();
    try
    {
      _gtk_list_store_set(paramInt1, paramInt2, paramInt3, paramBoolean, paramInt4);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_major_version();
  
  public static final int gtk_major_version()
  {
    lock.lock();
    try
    {
      int i = _gtk_major_version();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_minor_version();
  
  public static final int gtk_minor_version()
  {
    lock.lock();
    try
    {
      int i = _gtk_minor_version();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_micro_version();
  
  public static final int gtk_micro_version()
  {
    lock.lock();
    try
    {
      int i = _gtk_micro_version();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _glib_major_version();
  
  public static final int glib_major_version()
  {
    lock.lock();
    try
    {
      int i = _glib_major_version();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _glib_minor_version();
  
  public static final int glib_minor_version()
  {
    lock.lock();
    try
    {
      int i = _glib_minor_version();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _glib_micro_version();
  
  public static final int glib_micro_version()
  {
    lock.lock();
    try
    {
      int i = _glib_micro_version();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_main();
  
  public static final void gtk_main()
  {
    lock.lock();
    try
    {
      _gtk_main();
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_main_do_event(int paramInt);
  
  public static final void gtk_main_do_event(int paramInt)
  {
    lock.lock();
    try
    {
      _gtk_main_do_event(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_menu_bar_new();
  
  public static final int gtk_menu_bar_new()
  {
    lock.lock();
    try
    {
      int i = _gtk_menu_bar_new();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_menu_item_remove_submenu(int paramInt);
  
  public static final void gtk_menu_item_remove_submenu(int paramInt)
  {
    lock.lock();
    try
    {
      _gtk_menu_item_remove_submenu(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_menu_item_get_submenu(int paramInt);
  
  public static final int gtk_menu_item_get_submenu(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_menu_item_get_submenu(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_menu_item_set_submenu(int paramInt1, int paramInt2);
  
  public static final void gtk_menu_item_set_submenu(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_menu_item_set_submenu(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_menu_new();
  
  public static final int gtk_menu_new()
  {
    lock.lock();
    try
    {
      int i = _gtk_menu_new();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_menu_popdown(int paramInt);
  
  public static final void gtk_menu_popdown(int paramInt)
  {
    lock.lock();
    try
    {
      _gtk_menu_popdown(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_menu_popup(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7);
  
  public static final void gtk_menu_popup(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7)
  {
    lock.lock();
    try
    {
      _gtk_menu_popup(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_menu_shell_deactivate(int paramInt);
  
  public static final void gtk_menu_shell_deactivate(int paramInt)
  {
    lock.lock();
    try
    {
      _gtk_menu_shell_deactivate(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_menu_shell_insert(int paramInt1, int paramInt2, int paramInt3);
  
  public static final void gtk_menu_shell_insert(int paramInt1, int paramInt2, int paramInt3)
  {
    lock.lock();
    try
    {
      _gtk_menu_shell_insert(paramInt1, paramInt2, paramInt3);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_menu_shell_set_take_focus(int paramInt, boolean paramBoolean);
  
  public static final void gtk_menu_shell_set_take_focus(int paramInt, boolean paramBoolean)
  {
    lock.lock();
    try
    {
      _gtk_menu_shell_set_take_focus(paramInt, paramBoolean);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_menu_tool_button_new(int paramInt, byte[] paramArrayOfByte);
  
  public static final int gtk_menu_tool_button_new(int paramInt, byte[] paramArrayOfByte)
  {
    lock.lock();
    try
    {
      int i = _gtk_menu_tool_button_new(paramInt, paramArrayOfByte);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_message_dialog_new(int paramInt1, int paramInt2, int paramInt3, int paramInt4, byte[] paramArrayOfByte);
  
  public static final int gtk_message_dialog_new(int paramInt1, int paramInt2, int paramInt3, int paramInt4, byte[] paramArrayOfByte)
  {
    lock.lock();
    try
    {
      int i = _gtk_message_dialog_new(paramInt1, paramInt2, paramInt3, paramInt4, paramArrayOfByte);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_misc_set_alignment(int paramInt, float paramFloat1, float paramFloat2);
  
  public static final void gtk_misc_set_alignment(int paramInt, float paramFloat1, float paramFloat2)
  {
    lock.lock();
    try
    {
      _gtk_misc_set_alignment(paramInt, paramFloat1, paramFloat2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_notebook_get_current_page(int paramInt);
  
  public static final int gtk_notebook_get_current_page(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_notebook_get_current_page(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _gtk_notebook_get_scrollable(int paramInt);
  
  public static final boolean gtk_notebook_get_scrollable(int paramInt)
  {
    lock.lock();
    try
    {
      boolean bool = _gtk_notebook_get_scrollable(paramInt);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_notebook_insert_page(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  public static final void gtk_notebook_insert_page(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    lock.lock();
    try
    {
      _gtk_notebook_insert_page(paramInt1, paramInt2, paramInt3, paramInt4);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_notebook_new();
  
  public static final int gtk_notebook_new()
  {
    lock.lock();
    try
    {
      int i = _gtk_notebook_new();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_notebook_next_page(int paramInt);
  
  public static final void gtk_notebook_next_page(int paramInt)
  {
    lock.lock();
    try
    {
      _gtk_notebook_next_page(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_notebook_prev_page(int paramInt);
  
  public static final void gtk_notebook_prev_page(int paramInt)
  {
    lock.lock();
    try
    {
      _gtk_notebook_prev_page(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_notebook_remove_page(int paramInt1, int paramInt2);
  
  public static final void gtk_notebook_remove_page(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_notebook_remove_page(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_notebook_set_current_page(int paramInt1, int paramInt2);
  
  public static final void gtk_notebook_set_current_page(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_notebook_set_current_page(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_notebook_set_scrollable(int paramInt, boolean paramBoolean);
  
  public static final void gtk_notebook_set_scrollable(int paramInt, boolean paramBoolean)
  {
    lock.lock();
    try
    {
      _gtk_notebook_set_scrollable(paramInt, paramBoolean);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_notebook_set_show_tabs(int paramInt, boolean paramBoolean);
  
  public static final void gtk_notebook_set_show_tabs(int paramInt, boolean paramBoolean)
  {
    lock.lock();
    try
    {
      _gtk_notebook_set_show_tabs(paramInt, paramBoolean);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_notebook_set_tab_pos(int paramInt1, int paramInt2);
  
  public static final void gtk_notebook_set_tab_pos(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_notebook_set_tab_pos(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_object_ref_sink(int paramInt);
  
  public static final int g_object_ref_sink(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _g_object_ref_sink(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_orientable_set_orientation(int paramInt1, int paramInt2);
  
  public static final void gtk_orientable_set_orientation(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_orientable_set_orientation(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_page_setup_new();
  
  public static final int gtk_page_setup_new()
  {
    lock.lock();
    try
    {
      int i = _gtk_page_setup_new();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_page_setup_get_orientation(int paramInt);
  
  public static final int gtk_page_setup_get_orientation(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_page_setup_get_orientation(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_page_setup_set_orientation(int paramInt1, int paramInt2);
  
  public static final void gtk_page_setup_set_orientation(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_page_setup_set_orientation(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_page_setup_get_paper_size(int paramInt);
  
  public static final int gtk_page_setup_get_paper_size(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_page_setup_get_paper_size(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_page_setup_set_paper_size(int paramInt1, int paramInt2);
  
  public static final void gtk_page_setup_set_paper_size(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_page_setup_set_paper_size(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native double _gtk_page_setup_get_top_margin(int paramInt1, int paramInt2);
  
  public static final double gtk_page_setup_get_top_margin(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      double d = _gtk_page_setup_get_top_margin(paramInt1, paramInt2);
      return d;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_page_setup_set_top_margin(int paramInt1, double paramDouble, int paramInt2);
  
  public static final void gtk_page_setup_set_top_margin(int paramInt1, double paramDouble, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_page_setup_set_top_margin(paramInt1, paramDouble, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native double _gtk_page_setup_get_bottom_margin(int paramInt1, int paramInt2);
  
  public static final double gtk_page_setup_get_bottom_margin(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      double d = _gtk_page_setup_get_bottom_margin(paramInt1, paramInt2);
      return d;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_page_setup_set_bottom_margin(int paramInt1, double paramDouble, int paramInt2);
  
  public static final void gtk_page_setup_set_bottom_margin(int paramInt1, double paramDouble, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_page_setup_set_bottom_margin(paramInt1, paramDouble, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native double _gtk_page_setup_get_left_margin(int paramInt1, int paramInt2);
  
  public static final double gtk_page_setup_get_left_margin(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      double d = _gtk_page_setup_get_left_margin(paramInt1, paramInt2);
      return d;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_page_setup_set_left_margin(int paramInt1, double paramDouble, int paramInt2);
  
  public static final void gtk_page_setup_set_left_margin(int paramInt1, double paramDouble, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_page_setup_set_left_margin(paramInt1, paramDouble, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native double _gtk_page_setup_get_right_margin(int paramInt1, int paramInt2);
  
  public static final double gtk_page_setup_get_right_margin(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      double d = _gtk_page_setup_get_right_margin(paramInt1, paramInt2);
      return d;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_page_setup_set_right_margin(int paramInt1, double paramDouble, int paramInt2);
  
  public static final void gtk_page_setup_set_right_margin(int paramInt1, double paramDouble, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_page_setup_set_right_margin(paramInt1, paramDouble, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native double _gtk_page_setup_get_paper_width(int paramInt1, int paramInt2);
  
  public static final double gtk_page_setup_get_paper_width(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      double d = _gtk_page_setup_get_paper_width(paramInt1, paramInt2);
      return d;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native double _gtk_page_setup_get_paper_height(int paramInt1, int paramInt2);
  
  public static final double gtk_page_setup_get_paper_height(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      double d = _gtk_page_setup_get_paper_height(paramInt1, paramInt2);
      return d;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native double _gtk_page_setup_get_page_width(int paramInt1, int paramInt2);
  
  public static final double gtk_page_setup_get_page_width(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      double d = _gtk_page_setup_get_page_width(paramInt1, paramInt2);
      return d;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native double _gtk_page_setup_get_page_height(int paramInt1, int paramInt2);
  
  public static final double gtk_page_setup_get_page_height(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      double d = _gtk_page_setup_get_page_height(paramInt1, paramInt2);
      return d;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_paint_handle(int paramInt1, int paramInt2, int paramInt3, int paramInt4, GdkRectangle paramGdkRectangle, int paramInt5, byte[] paramArrayOfByte, int paramInt6, int paramInt7, int paramInt8, int paramInt9, int paramInt10);
  
  public static final void gtk_paint_handle(int paramInt1, int paramInt2, int paramInt3, int paramInt4, GdkRectangle paramGdkRectangle, int paramInt5, byte[] paramArrayOfByte, int paramInt6, int paramInt7, int paramInt8, int paramInt9, int paramInt10)
  {
    lock.lock();
    try
    {
      _gtk_paint_handle(paramInt1, paramInt2, paramInt3, paramInt4, paramGdkRectangle, paramInt5, paramArrayOfByte, paramInt6, paramInt7, paramInt8, paramInt9, paramInt10);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_render_frame(int paramInt1, int paramInt2, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4);
  
  public static final void gtk_render_frame(int paramInt1, int paramInt2, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4)
  {
    lock.lock();
    try
    {
      _gtk_render_frame(paramInt1, paramInt2, paramDouble1, paramDouble2, paramDouble3, paramDouble4);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_render_arrow(int paramInt1, int paramInt2, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4);
  
  public static final void gtk_render_arrow(int paramInt1, int paramInt2, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4)
  {
    lock.lock();
    try
    {
      _gtk_render_arrow(paramInt1, paramInt2, paramDouble1, paramDouble2, paramDouble3, paramDouble4);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_render_expander(int paramInt1, int paramInt2, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4);
  
  public static final void gtk_render_expander(int paramInt1, int paramInt2, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4)
  {
    lock.lock();
    try
    {
      _gtk_render_expander(paramInt1, paramInt2, paramDouble1, paramDouble2, paramDouble3, paramDouble4);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_render_frame_gap(int paramInt1, int paramInt2, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, int paramInt3, double paramDouble5, double paramDouble6);
  
  public static final void gtk_render_frame_gap(int paramInt1, int paramInt2, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, int paramInt3, double paramDouble5, double paramDouble6)
  {
    lock.lock();
    try
    {
      _gtk_render_frame_gap(paramInt1, paramInt2, paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramInt3, paramDouble5, paramDouble6);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_render_extension(int paramInt1, int paramInt2, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, int paramInt3);
  
  public static final void gtk_render_extension(int paramInt1, int paramInt2, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, int paramInt3)
  {
    lock.lock();
    try
    {
      _gtk_render_extension(paramInt1, paramInt2, paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramInt3);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_render_layout(int paramInt1, int paramInt2, double paramDouble1, double paramDouble2, int paramInt3);
  
  public static final void gtk_render_layout(int paramInt1, int paramInt2, double paramDouble1, double paramDouble2, int paramInt3)
  {
    lock.lock();
    try
    {
      _gtk_render_layout(paramInt1, paramInt2, paramDouble1, paramDouble2, paramInt3);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_render_background(int paramInt1, int paramInt2, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4);
  
  public static final void gtk_render_background(int paramInt1, int paramInt2, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4)
  {
    lock.lock();
    try
    {
      _gtk_render_background(paramInt1, paramInt2, paramDouble1, paramDouble2, paramDouble3, paramDouble4);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_render_option(int paramInt1, int paramInt2, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4);
  
  public static final void gtk_render_option(int paramInt1, int paramInt2, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4)
  {
    lock.lock();
    try
    {
      _gtk_render_option(paramInt1, paramInt2, paramDouble1, paramDouble2, paramDouble3, paramDouble4);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_paint_flat_box(int paramInt1, int paramInt2, int paramInt3, int paramInt4, GdkRectangle paramGdkRectangle, int paramInt5, byte[] paramArrayOfByte, int paramInt6, int paramInt7, int paramInt8, int paramInt9);
  
  public static final void gtk_paint_flat_box(int paramInt1, int paramInt2, int paramInt3, int paramInt4, GdkRectangle paramGdkRectangle, int paramInt5, byte[] paramArrayOfByte, int paramInt6, int paramInt7, int paramInt8, int paramInt9)
  {
    lock.lock();
    try
    {
      _gtk_paint_flat_box(paramInt1, paramInt2, paramInt3, paramInt4, paramGdkRectangle, paramInt5, paramArrayOfByte, paramInt6, paramInt7, paramInt8, paramInt9);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_paint_focus(int paramInt1, int paramInt2, int paramInt3, GdkRectangle paramGdkRectangle, int paramInt4, byte[] paramArrayOfByte, int paramInt5, int paramInt6, int paramInt7, int paramInt8);
  
  public static final void gtk_paint_focus(int paramInt1, int paramInt2, int paramInt3, GdkRectangle paramGdkRectangle, int paramInt4, byte[] paramArrayOfByte, int paramInt5, int paramInt6, int paramInt7, int paramInt8)
  {
    lock.lock();
    try
    {
      _gtk_paint_focus(paramInt1, paramInt2, paramInt3, paramGdkRectangle, paramInt4, paramArrayOfByte, paramInt5, paramInt6, paramInt7, paramInt8);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_render_focus(int paramInt1, int paramInt2, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4);
  
  public static final void gtk_render_focus(int paramInt1, int paramInt2, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4)
  {
    lock.lock();
    try
    {
      _gtk_render_focus(paramInt1, paramInt2, paramDouble1, paramDouble2, paramDouble3, paramDouble4);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_paint_option(int paramInt1, int paramInt2, int paramInt3, int paramInt4, GdkRectangle paramGdkRectangle, int paramInt5, byte[] paramArrayOfByte, int paramInt6, int paramInt7, int paramInt8, int paramInt9);
  
  public static final void gtk_paint_option(int paramInt1, int paramInt2, int paramInt3, int paramInt4, GdkRectangle paramGdkRectangle, int paramInt5, byte[] paramArrayOfByte, int paramInt6, int paramInt7, int paramInt8, int paramInt9)
  {
    lock.lock();
    try
    {
      _gtk_paint_option(paramInt1, paramInt2, paramInt3, paramInt4, paramGdkRectangle, paramInt5, paramArrayOfByte, paramInt6, paramInt7, paramInt8, paramInt9);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_paint_arrow(int paramInt1, int paramInt2, int paramInt3, int paramInt4, GdkRectangle paramGdkRectangle, int paramInt5, byte[] paramArrayOfByte, int paramInt6, boolean paramBoolean, int paramInt7, int paramInt8, int paramInt9, int paramInt10);
  
  public static final void gtk_paint_arrow(int paramInt1, int paramInt2, int paramInt3, int paramInt4, GdkRectangle paramGdkRectangle, int paramInt5, byte[] paramArrayOfByte, int paramInt6, boolean paramBoolean, int paramInt7, int paramInt8, int paramInt9, int paramInt10)
  {
    lock.lock();
    try
    {
      _gtk_paint_arrow(paramInt1, paramInt2, paramInt3, paramInt4, paramGdkRectangle, paramInt5, paramArrayOfByte, paramInt6, paramBoolean, paramInt7, paramInt8, paramInt9, paramInt10);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_paint_box(int paramInt1, int paramInt2, int paramInt3, int paramInt4, GdkRectangle paramGdkRectangle, int paramInt5, byte[] paramArrayOfByte, int paramInt6, int paramInt7, int paramInt8, int paramInt9);
  
  public static final void gtk_paint_box(int paramInt1, int paramInt2, int paramInt3, int paramInt4, GdkRectangle paramGdkRectangle, int paramInt5, byte[] paramArrayOfByte, int paramInt6, int paramInt7, int paramInt8, int paramInt9)
  {
    lock.lock();
    try
    {
      _gtk_paint_box(paramInt1, paramInt2, paramInt3, paramInt4, paramGdkRectangle, paramInt5, paramArrayOfByte, paramInt6, paramInt7, paramInt8, paramInt9);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_paint_box_gap(int paramInt1, int paramInt2, int paramInt3, int paramInt4, GdkRectangle paramGdkRectangle, int paramInt5, byte[] paramArrayOfByte, int paramInt6, int paramInt7, int paramInt8, int paramInt9, int paramInt10, int paramInt11, int paramInt12);
  
  public static final void gtk_paint_box_gap(int paramInt1, int paramInt2, int paramInt3, int paramInt4, GdkRectangle paramGdkRectangle, int paramInt5, byte[] paramArrayOfByte, int paramInt6, int paramInt7, int paramInt8, int paramInt9, int paramInt10, int paramInt11, int paramInt12)
  {
    lock.lock();
    try
    {
      _gtk_paint_box_gap(paramInt1, paramInt2, paramInt3, paramInt4, paramGdkRectangle, paramInt5, paramArrayOfByte, paramInt6, paramInt7, paramInt8, paramInt9, paramInt10, paramInt11, paramInt12);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_paint_check(int paramInt1, int paramInt2, int paramInt3, int paramInt4, GdkRectangle paramGdkRectangle, int paramInt5, byte[] paramArrayOfByte, int paramInt6, int paramInt7, int paramInt8, int paramInt9);
  
  public static final void gtk_paint_check(int paramInt1, int paramInt2, int paramInt3, int paramInt4, GdkRectangle paramGdkRectangle, int paramInt5, byte[] paramArrayOfByte, int paramInt6, int paramInt7, int paramInt8, int paramInt9)
  {
    lock.lock();
    try
    {
      _gtk_paint_check(paramInt1, paramInt2, paramInt3, paramInt4, paramGdkRectangle, paramInt5, paramArrayOfByte, paramInt6, paramInt7, paramInt8, paramInt9);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_render_check(int paramInt1, int paramInt2, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4);
  
  public static final void gtk_render_check(int paramInt1, int paramInt2, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4)
  {
    lock.lock();
    try
    {
      _gtk_render_check(paramInt1, paramInt2, paramDouble1, paramDouble2, paramDouble3, paramDouble4);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_paint_expander(int paramInt1, int paramInt2, int paramInt3, GdkRectangle paramGdkRectangle, int paramInt4, byte[] paramArrayOfByte, int paramInt5, int paramInt6, int paramInt7);
  
  public static final void gtk_paint_expander(int paramInt1, int paramInt2, int paramInt3, GdkRectangle paramGdkRectangle, int paramInt4, byte[] paramArrayOfByte, int paramInt5, int paramInt6, int paramInt7)
  {
    lock.lock();
    try
    {
      _gtk_paint_expander(paramInt1, paramInt2, paramInt3, paramGdkRectangle, paramInt4, paramArrayOfByte, paramInt5, paramInt6, paramInt7);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_paint_extension(int paramInt1, int paramInt2, int paramInt3, int paramInt4, GdkRectangle paramGdkRectangle, int paramInt5, byte[] paramArrayOfByte, int paramInt6, int paramInt7, int paramInt8, int paramInt9, int paramInt10);
  
  public static final void gtk_paint_extension(int paramInt1, int paramInt2, int paramInt3, int paramInt4, GdkRectangle paramGdkRectangle, int paramInt5, byte[] paramArrayOfByte, int paramInt6, int paramInt7, int paramInt8, int paramInt9, int paramInt10)
  {
    lock.lock();
    try
    {
      _gtk_paint_extension(paramInt1, paramInt2, paramInt3, paramInt4, paramGdkRectangle, paramInt5, paramArrayOfByte, paramInt6, paramInt7, paramInt8, paramInt9, paramInt10);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_paint_hline(int paramInt1, int paramInt2, int paramInt3, GdkRectangle paramGdkRectangle, int paramInt4, byte[] paramArrayOfByte, int paramInt5, int paramInt6, int paramInt7);
  
  public static final void gtk_paint_hline(int paramInt1, int paramInt2, int paramInt3, GdkRectangle paramGdkRectangle, int paramInt4, byte[] paramArrayOfByte, int paramInt5, int paramInt6, int paramInt7)
  {
    lock.lock();
    try
    {
      _gtk_paint_hline(paramInt1, paramInt2, paramInt3, paramGdkRectangle, paramInt4, paramArrayOfByte, paramInt5, paramInt6, paramInt7);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_paint_layout(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean, GdkRectangle paramGdkRectangle, int paramInt4, byte[] paramArrayOfByte, int paramInt5, int paramInt6, int paramInt7);
  
  public static final void gtk_paint_layout(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean, GdkRectangle paramGdkRectangle, int paramInt4, byte[] paramArrayOfByte, int paramInt5, int paramInt6, int paramInt7)
  {
    lock.lock();
    try
    {
      _gtk_paint_layout(paramInt1, paramInt2, paramInt3, paramBoolean, paramGdkRectangle, paramInt4, paramArrayOfByte, paramInt5, paramInt6, paramInt7);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_paint_shadow_gap(int paramInt1, int paramInt2, int paramInt3, int paramInt4, GdkRectangle paramGdkRectangle, int paramInt5, byte[] paramArrayOfByte, int paramInt6, int paramInt7, int paramInt8, int paramInt9, int paramInt10, int paramInt11, int paramInt12);
  
  public static final void gtk_paint_shadow_gap(int paramInt1, int paramInt2, int paramInt3, int paramInt4, GdkRectangle paramGdkRectangle, int paramInt5, byte[] paramArrayOfByte, int paramInt6, int paramInt7, int paramInt8, int paramInt9, int paramInt10, int paramInt11, int paramInt12)
  {
    lock.lock();
    try
    {
      _gtk_paint_shadow_gap(paramInt1, paramInt2, paramInt3, paramInt4, paramGdkRectangle, paramInt5, paramArrayOfByte, paramInt6, paramInt7, paramInt8, paramInt9, paramInt10, paramInt11, paramInt12);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_paint_shadow(int paramInt1, int paramInt2, int paramInt3, int paramInt4, GdkRectangle paramGdkRectangle, int paramInt5, byte[] paramArrayOfByte, int paramInt6, int paramInt7, int paramInt8, int paramInt9);
  
  public static final void gtk_paint_shadow(int paramInt1, int paramInt2, int paramInt3, int paramInt4, GdkRectangle paramGdkRectangle, int paramInt5, byte[] paramArrayOfByte, int paramInt6, int paramInt7, int paramInt8, int paramInt9)
  {
    lock.lock();
    try
    {
      _gtk_paint_shadow(paramInt1, paramInt2, paramInt3, paramInt4, paramGdkRectangle, paramInt5, paramArrayOfByte, paramInt6, paramInt7, paramInt8, paramInt9);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_paint_vline(int paramInt1, int paramInt2, int paramInt3, GdkRectangle paramGdkRectangle, int paramInt4, byte[] paramArrayOfByte, int paramInt5, int paramInt6, int paramInt7);
  
  public static final void gtk_paint_vline(int paramInt1, int paramInt2, int paramInt3, GdkRectangle paramGdkRectangle, int paramInt4, byte[] paramArrayOfByte, int paramInt5, int paramInt6, int paramInt7)
  {
    lock.lock();
    try
    {
      _gtk_paint_vline(paramInt1, paramInt2, paramInt3, paramGdkRectangle, paramInt4, paramArrayOfByte, paramInt5, paramInt6, paramInt7);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_render_line(int paramInt1, int paramInt2, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4);
  
  public static final void gtk_render_line(int paramInt1, int paramInt2, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4)
  {
    lock.lock();
    try
    {
      _gtk_render_line(paramInt1, paramInt2, paramDouble1, paramDouble2, paramDouble3, paramDouble4);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_paper_size_free(int paramInt);
  
  public static final void gtk_paper_size_free(int paramInt)
  {
    lock.lock();
    try
    {
      _gtk_paper_size_free(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_paper_size_new(byte[] paramArrayOfByte);
  
  public static final int gtk_paper_size_new(byte[] paramArrayOfByte)
  {
    lock.lock();
    try
    {
      int i = _gtk_paper_size_new(paramArrayOfByte);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_paper_size_new_from_ppd(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, double paramDouble1, double paramDouble2);
  
  public static final int gtk_paper_size_new_from_ppd(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, double paramDouble1, double paramDouble2)
  {
    lock.lock();
    try
    {
      int i = _gtk_paper_size_new_from_ppd(paramArrayOfByte1, paramArrayOfByte2, paramDouble1, paramDouble2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_paper_size_new_custom(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, double paramDouble1, double paramDouble2, int paramInt);
  
  public static final int gtk_paper_size_new_custom(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, double paramDouble1, double paramDouble2, int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_paper_size_new_custom(paramArrayOfByte1, paramArrayOfByte2, paramDouble1, paramDouble2, paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_paper_size_get_name(int paramInt);
  
  public static final int gtk_paper_size_get_name(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_paper_size_get_name(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_paper_size_get_display_name(int paramInt);
  
  public static final int gtk_paper_size_get_display_name(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_paper_size_get_display_name(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_paper_size_get_ppd_name(int paramInt);
  
  public static final int gtk_paper_size_get_ppd_name(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_paper_size_get_ppd_name(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native double _gtk_paper_size_get_width(int paramInt1, int paramInt2);
  
  public static final double gtk_paper_size_get_width(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      double d = _gtk_paper_size_get_width(paramInt1, paramInt2);
      return d;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native double _gtk_paper_size_get_height(int paramInt1, int paramInt2);
  
  public static final double gtk_paper_size_get_height(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      double d = _gtk_paper_size_get_height(paramInt1, paramInt2);
      return d;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _gtk_paper_size_is_custom(int paramInt);
  
  public static final boolean gtk_paper_size_is_custom(int paramInt)
  {
    lock.lock();
    try
    {
      boolean bool = _gtk_paper_size_is_custom(paramInt);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_plug_new(int paramInt);
  
  public static final int gtk_plug_new(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_plug_new(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_printer_get_backend(int paramInt);
  
  public static final int gtk_printer_get_backend(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_printer_get_backend(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_printer_get_name(int paramInt);
  
  public static final int gtk_printer_get_name(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_printer_get_name(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _gtk_printer_is_default(int paramInt);
  
  public static final boolean gtk_printer_is_default(int paramInt)
  {
    lock.lock();
    try
    {
      boolean bool = _gtk_printer_is_default(paramInt);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_enumerate_printers(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean);
  
  public static final void gtk_enumerate_printers(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean)
  {
    lock.lock();
    try
    {
      _gtk_enumerate_printers(paramInt1, paramInt2, paramInt3, paramBoolean);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_print_job_new(byte[] paramArrayOfByte, int paramInt1, int paramInt2, int paramInt3);
  
  public static final int gtk_print_job_new(byte[] paramArrayOfByte, int paramInt1, int paramInt2, int paramInt3)
  {
    lock.lock();
    try
    {
      int i = _gtk_print_job_new(paramArrayOfByte, paramInt1, paramInt2, paramInt3);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_print_job_get_surface(int paramInt, int[] paramArrayOfInt);
  
  public static final int gtk_print_job_get_surface(int paramInt, int[] paramArrayOfInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_print_job_get_surface(paramInt, paramArrayOfInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_print_job_send(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  public static final void gtk_print_job_send(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    lock.lock();
    try
    {
      _gtk_print_job_send(paramInt1, paramInt2, paramInt3, paramInt4);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_print_settings_new();
  
  public static final int gtk_print_settings_new()
  {
    lock.lock();
    try
    {
      int i = _gtk_print_settings_new();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_print_settings_foreach(int paramInt1, int paramInt2, int paramInt3);
  
  public static final void gtk_print_settings_foreach(int paramInt1, int paramInt2, int paramInt3)
  {
    lock.lock();
    try
    {
      _gtk_print_settings_foreach(paramInt1, paramInt2, paramInt3);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_print_settings_get(int paramInt, byte[] paramArrayOfByte);
  
  public static final int gtk_print_settings_get(int paramInt, byte[] paramArrayOfByte)
  {
    lock.lock();
    try
    {
      int i = _gtk_print_settings_get(paramInt, paramArrayOfByte);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_print_settings_set(int paramInt, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2);
  
  public static final void gtk_print_settings_set(int paramInt, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    lock.lock();
    try
    {
      _gtk_print_settings_set(paramInt, paramArrayOfByte1, paramArrayOfByte2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_print_settings_set_printer(int paramInt, byte[] paramArrayOfByte);
  
  public static final void gtk_print_settings_set_printer(int paramInt, byte[] paramArrayOfByte)
  {
    lock.lock();
    try
    {
      _gtk_print_settings_set_printer(paramInt, paramArrayOfByte);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_print_settings_set_orientation(int paramInt1, int paramInt2);
  
  public static final void gtk_print_settings_set_orientation(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_print_settings_set_orientation(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _gtk_print_settings_get_collate(int paramInt);
  
  public static final boolean gtk_print_settings_get_collate(int paramInt)
  {
    lock.lock();
    try
    {
      boolean bool = _gtk_print_settings_get_collate(paramInt);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_print_settings_set_collate(int paramInt, boolean paramBoolean);
  
  public static final void gtk_print_settings_set_collate(int paramInt, boolean paramBoolean)
  {
    lock.lock();
    try
    {
      _gtk_print_settings_set_collate(paramInt, paramBoolean);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_print_settings_get_duplex(int paramInt);
  
  public static final int gtk_print_settings_get_duplex(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_print_settings_get_duplex(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_print_settings_set_duplex(int paramInt1, int paramInt2);
  
  public static final void gtk_print_settings_set_duplex(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_print_settings_set_duplex(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_print_settings_get_n_copies(int paramInt);
  
  public static final int gtk_print_settings_get_n_copies(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_print_settings_get_n_copies(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_print_settings_set_n_copies(int paramInt1, int paramInt2);
  
  public static final void gtk_print_settings_set_n_copies(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_print_settings_set_n_copies(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_print_settings_get_print_pages(int paramInt);
  
  public static final int gtk_print_settings_get_print_pages(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_print_settings_get_print_pages(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_print_settings_set_print_pages(int paramInt1, int paramInt2);
  
  public static final void gtk_print_settings_set_print_pages(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_print_settings_set_print_pages(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_print_settings_get_page_ranges(int paramInt, int[] paramArrayOfInt);
  
  public static final int gtk_print_settings_get_page_ranges(int paramInt, int[] paramArrayOfInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_print_settings_get_page_ranges(paramInt, paramArrayOfInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_print_settings_set_page_ranges(int paramInt1, int[] paramArrayOfInt, int paramInt2);
  
  public static final void gtk_print_settings_set_page_ranges(int paramInt1, int[] paramArrayOfInt, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_print_settings_set_page_ranges(paramInt1, paramArrayOfInt, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_print_settings_get_resolution(int paramInt);
  
  public static final int gtk_print_settings_get_resolution(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_print_settings_get_resolution(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_print_unix_dialog_new(byte[] paramArrayOfByte, int paramInt);
  
  public static final int gtk_print_unix_dialog_new(byte[] paramArrayOfByte, int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_print_unix_dialog_new(paramArrayOfByte, paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_print_unix_dialog_set_embed_page_setup(int paramInt, boolean paramBoolean);
  
  public static final void gtk_print_unix_dialog_set_embed_page_setup(int paramInt, boolean paramBoolean)
  {
    lock.lock();
    try
    {
      _gtk_print_unix_dialog_set_embed_page_setup(paramInt, paramBoolean);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_print_unix_dialog_set_page_setup(int paramInt1, int paramInt2);
  
  public static final void gtk_print_unix_dialog_set_page_setup(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_print_unix_dialog_set_page_setup(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_print_unix_dialog_get_page_setup(int paramInt);
  
  public static final int gtk_print_unix_dialog_get_page_setup(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_print_unix_dialog_get_page_setup(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_print_unix_dialog_set_current_page(int paramInt1, int paramInt2);
  
  public static final void gtk_print_unix_dialog_set_current_page(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_print_unix_dialog_set_current_page(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_print_unix_dialog_get_current_page(int paramInt);
  
  public static final int gtk_print_unix_dialog_get_current_page(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_print_unix_dialog_get_current_page(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_print_unix_dialog_set_settings(int paramInt1, int paramInt2);
  
  public static final void gtk_print_unix_dialog_set_settings(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_print_unix_dialog_set_settings(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_print_unix_dialog_get_settings(int paramInt);
  
  public static final int gtk_print_unix_dialog_get_settings(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_print_unix_dialog_get_settings(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_print_unix_dialog_get_selected_printer(int paramInt);
  
  public static final int gtk_print_unix_dialog_get_selected_printer(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_print_unix_dialog_get_selected_printer(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_print_unix_dialog_set_manual_capabilities(int paramInt1, int paramInt2);
  
  public static final void gtk_print_unix_dialog_set_manual_capabilities(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_print_unix_dialog_set_manual_capabilities(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_progress_bar_new();
  
  public static final int gtk_progress_bar_new()
  {
    lock.lock();
    try
    {
      int i = _gtk_progress_bar_new();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_progress_bar_pulse(int paramInt);
  
  public static final void gtk_progress_bar_pulse(int paramInt)
  {
    lock.lock();
    try
    {
      _gtk_progress_bar_pulse(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_progress_bar_set_fraction(int paramInt, double paramDouble);
  
  public static final void gtk_progress_bar_set_fraction(int paramInt, double paramDouble)
  {
    lock.lock();
    try
    {
      _gtk_progress_bar_set_fraction(paramInt, paramDouble);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_progress_bar_set_inverted(int paramInt, boolean paramBoolean);
  
  public static final void gtk_progress_bar_set_inverted(int paramInt, boolean paramBoolean)
  {
    lock.lock();
    try
    {
      _gtk_progress_bar_set_inverted(paramInt, paramBoolean);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_progress_bar_set_orientation(int paramInt1, int paramInt2);
  
  public static final void gtk_progress_bar_set_orientation(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_progress_bar_set_orientation(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_radio_button_get_group(int paramInt);
  
  public static final int gtk_radio_button_get_group(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_radio_button_get_group(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_radio_button_new(int paramInt);
  
  public static final int gtk_radio_button_new(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_radio_button_new(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_radio_menu_item_get_group(int paramInt);
  
  public static final int gtk_radio_menu_item_get_group(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_radio_menu_item_get_group(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_radio_menu_item_new(int paramInt);
  
  public static final int gtk_radio_menu_item_new(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_radio_menu_item_new(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_radio_menu_item_new_with_label(int paramInt, byte[] paramArrayOfByte);
  
  public static final int gtk_radio_menu_item_new_with_label(int paramInt, byte[] paramArrayOfByte)
  {
    lock.lock();
    try
    {
      int i = _gtk_radio_menu_item_new_with_label(paramInt, paramArrayOfByte);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_range_get_adjustment(int paramInt);
  
  public static final int gtk_range_get_adjustment(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_range_get_adjustment(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_range_set_increments(int paramInt, double paramDouble1, double paramDouble2);
  
  public static final void gtk_range_set_increments(int paramInt, double paramDouble1, double paramDouble2)
  {
    lock.lock();
    try
    {
      _gtk_range_set_increments(paramInt, paramDouble1, paramDouble2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_range_set_inverted(int paramInt, boolean paramBoolean);
  
  public static final void gtk_range_set_inverted(int paramInt, boolean paramBoolean)
  {
    lock.lock();
    try
    {
      _gtk_range_set_inverted(paramInt, paramBoolean);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_range_set_range(int paramInt, double paramDouble1, double paramDouble2);
  
  public static final void gtk_range_set_range(int paramInt, double paramDouble1, double paramDouble2)
  {
    lock.lock();
    try
    {
      _gtk_range_set_range(paramInt, paramDouble1, paramDouble2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_range_set_value(int paramInt, double paramDouble);
  
  public static final void gtk_range_set_value(int paramInt, double paramDouble)
  {
    lock.lock();
    try
    {
      _gtk_range_set_value(paramInt, paramDouble);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_range_get_slider_range(int paramInt, int[] paramArrayOfInt1, int[] paramArrayOfInt2);
  
  public static final void gtk_range_get_slider_range(int paramInt, int[] paramArrayOfInt1, int[] paramArrayOfInt2)
  {
    lock.lock();
    try
    {
      _gtk_range_get_slider_range(paramInt, paramArrayOfInt1, paramArrayOfInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_rc_parse_string(byte[] paramArrayOfByte);
  
  public static final void gtk_rc_parse_string(byte[] paramArrayOfByte)
  {
    lock.lock();
    try
    {
      _gtk_rc_parse_string(paramArrayOfByte);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_rc_style_get_bg_pixmap_name(int paramInt1, int paramInt2);
  
  public static final int gtk_rc_style_get_bg_pixmap_name(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      int i = _gtk_rc_style_get_bg_pixmap_name(paramInt1, paramInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_rc_style_get_color_flags(int paramInt1, int paramInt2);
  
  public static final int gtk_rc_style_get_color_flags(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      int i = _gtk_rc_style_get_color_flags(paramInt1, paramInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_rc_style_set_bg(int paramInt1, int paramInt2, GdkColor paramGdkColor);
  
  public static final void gtk_rc_style_set_bg(int paramInt1, int paramInt2, GdkColor paramGdkColor)
  {
    lock.lock();
    try
    {
      _gtk_rc_style_set_bg(paramInt1, paramInt2, paramGdkColor);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_rc_style_set_bg_pixmap_name(int paramInt1, int paramInt2, int paramInt3);
  
  public static final void gtk_rc_style_set_bg_pixmap_name(int paramInt1, int paramInt2, int paramInt3)
  {
    lock.lock();
    try
    {
      _gtk_rc_style_set_bg_pixmap_name(paramInt1, paramInt2, paramInt3);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_rc_style_set_color_flags(int paramInt1, int paramInt2, int paramInt3);
  
  public static final void gtk_rc_style_set_color_flags(int paramInt1, int paramInt2, int paramInt3)
  {
    lock.lock();
    try
    {
      _gtk_rc_style_set_color_flags(paramInt1, paramInt2, paramInt3);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_scale_set_digits(int paramInt1, int paramInt2);
  
  public static final void gtk_scale_set_digits(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_scale_set_digits(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_scale_set_draw_value(int paramInt, boolean paramBoolean);
  
  public static final void gtk_scale_set_draw_value(int paramInt, boolean paramBoolean)
  {
    lock.lock();
    try
    {
      _gtk_scale_set_draw_value(paramInt, paramBoolean);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_rc_style_set_fg(int paramInt1, int paramInt2, GdkColor paramGdkColor);
  
  public static final void gtk_rc_style_set_fg(int paramInt1, int paramInt2, GdkColor paramGdkColor)
  {
    lock.lock();
    try
    {
      _gtk_rc_style_set_fg(paramInt1, paramInt2, paramGdkColor);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_rc_style_set_text(int paramInt1, int paramInt2, GdkColor paramGdkColor);
  
  public static final void gtk_rc_style_set_text(int paramInt1, int paramInt2, GdkColor paramGdkColor)
  {
    lock.lock();
    try
    {
      _gtk_rc_style_set_text(paramInt1, paramInt2, paramGdkColor);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_scrolled_window_add_with_viewport(int paramInt1, int paramInt2);
  
  public static final void gtk_scrolled_window_add_with_viewport(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_scrolled_window_add_with_viewport(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_scrolled_window_get_hadjustment(int paramInt);
  
  public static final int gtk_scrolled_window_get_hadjustment(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_scrolled_window_get_hadjustment(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_scrolled_window_get_hscrollbar(int paramInt);
  
  public static final int gtk_scrolled_window_get_hscrollbar(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_scrolled_window_get_hscrollbar(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_scrolled_window_get_policy(int paramInt, int[] paramArrayOfInt1, int[] paramArrayOfInt2);
  
  public static final void gtk_scrolled_window_get_policy(int paramInt, int[] paramArrayOfInt1, int[] paramArrayOfInt2)
  {
    lock.lock();
    try
    {
      _gtk_scrolled_window_get_policy(paramInt, paramArrayOfInt1, paramArrayOfInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_scrolled_window_get_shadow_type(int paramInt);
  
  public static final int gtk_scrolled_window_get_shadow_type(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_scrolled_window_get_shadow_type(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_scrolled_window_get_vadjustment(int paramInt);
  
  public static final int gtk_scrolled_window_get_vadjustment(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_scrolled_window_get_vadjustment(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_scrolled_window_get_vscrollbar(int paramInt);
  
  public static final int gtk_scrolled_window_get_vscrollbar(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_scrolled_window_get_vscrollbar(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_scrolled_window_new(int paramInt1, int paramInt2);
  
  public static final int gtk_scrolled_window_new(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      int i = _gtk_scrolled_window_new(paramInt1, paramInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_scrolled_window_set_policy(int paramInt1, int paramInt2, int paramInt3);
  
  public static final void gtk_scrolled_window_set_policy(int paramInt1, int paramInt2, int paramInt3)
  {
    lock.lock();
    try
    {
      _gtk_scrolled_window_set_policy(paramInt1, paramInt2, paramInt3);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_scrolled_window_set_shadow_type(int paramInt1, int paramInt2);
  
  public static final void gtk_scrolled_window_set_shadow_type(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_scrolled_window_set_shadow_type(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_settings_get_default();
  
  public static final int gtk_settings_get_default()
  {
    lock.lock();
    try
    {
      int i = _gtk_settings_get_default();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_settings_set_string_property(int paramInt, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3);
  
  public static final void gtk_settings_set_string_property(int paramInt, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3)
  {
    lock.lock();
    try
    {
      _gtk_settings_set_string_property(paramInt, paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte3);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_selection_data_free(int paramInt);
  
  public static final void gtk_selection_data_free(int paramInt)
  {
    lock.lock();
    try
    {
      _gtk_selection_data_free(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_selection_data_get_data(int paramInt);
  
  public static final int gtk_selection_data_get_data(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_selection_data_get_data(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_selection_data_get_format(int paramInt);
  
  public static final int gtk_selection_data_get_format(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_selection_data_get_format(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_selection_data_get_length(int paramInt);
  
  public static final int gtk_selection_data_get_length(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_selection_data_get_length(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_selection_data_get_target(int paramInt);
  
  public static final int gtk_selection_data_get_target(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_selection_data_get_target(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_selection_data_get_data_type(int paramInt);
  
  public static final int gtk_selection_data_get_data_type(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_selection_data_get_data_type(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_selection_data_set(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5);
  
  public static final void gtk_selection_data_set(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
  {
    lock.lock();
    try
    {
      _gtk_selection_data_set(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_separator_menu_item_new();
  
  public static final int gtk_separator_menu_item_new()
  {
    lock.lock();
    try
    {
      int i = _gtk_separator_menu_item_new();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_separator_tool_item_new();
  
  public static final int gtk_separator_tool_item_new()
  {
    lock.lock();
    try
    {
      int i = _gtk_separator_tool_item_new();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_separator_tool_item_set_draw(int paramInt, boolean paramBoolean);
  
  public static final void gtk_separator_tool_item_set_draw(int paramInt, boolean paramBoolean)
  {
    lock.lock();
    try
    {
      _gtk_separator_tool_item_set_draw(paramInt, paramBoolean);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_set_locale();
  
  public static final int gtk_set_locale()
  {
    lock.lock();
    try
    {
      int i = _gtk_set_locale();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_socket_get_id(int paramInt);
  
  public static final int gtk_socket_get_id(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_socket_get_id(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_socket_new();
  
  public static final int gtk_socket_new()
  {
    lock.lock();
    try
    {
      int i = _gtk_socket_new();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_spin_button_new(int paramInt1, double paramDouble, int paramInt2);
  
  public static final int gtk_spin_button_new(int paramInt1, double paramDouble, int paramInt2)
  {
    lock.lock();
    try
    {
      int i = _gtk_spin_button_new(paramInt1, paramDouble, paramInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_spin_button_configure(int paramInt1, int paramInt2, double paramDouble, int paramInt3);
  
  public static final void gtk_spin_button_configure(int paramInt1, int paramInt2, double paramDouble, int paramInt3)
  {
    lock.lock();
    try
    {
      _gtk_spin_button_configure(paramInt1, paramInt2, paramDouble, paramInt3);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_spin_button_get_adjustment(int paramInt);
  
  public static final int gtk_spin_button_get_adjustment(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_spin_button_get_adjustment(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_spin_button_get_digits(int paramInt);
  
  public static final int gtk_spin_button_get_digits(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_spin_button_get_digits(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_spin_button_set_digits(int paramInt1, int paramInt2);
  
  public static final void gtk_spin_button_set_digits(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_spin_button_set_digits(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_spin_button_set_increments(int paramInt, double paramDouble1, double paramDouble2);
  
  public static final void gtk_spin_button_set_increments(int paramInt, double paramDouble1, double paramDouble2)
  {
    lock.lock();
    try
    {
      _gtk_spin_button_set_increments(paramInt, paramDouble1, paramDouble2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_spin_button_set_range(int paramInt, double paramDouble1, double paramDouble2);
  
  public static final void gtk_spin_button_set_range(int paramInt, double paramDouble1, double paramDouble2)
  {
    lock.lock();
    try
    {
      _gtk_spin_button_set_range(paramInt, paramDouble1, paramDouble2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_spin_button_set_value(int paramInt, double paramDouble);
  
  public static final void gtk_spin_button_set_value(int paramInt, double paramDouble)
  {
    lock.lock();
    try
    {
      _gtk_spin_button_set_value(paramInt, paramDouble);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_spin_button_set_wrap(int paramInt, boolean paramBoolean);
  
  public static final void gtk_spin_button_set_wrap(int paramInt, boolean paramBoolean)
  {
    lock.lock();
    try
    {
      _gtk_spin_button_set_wrap(paramInt, paramBoolean);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_spin_button_update(int paramInt);
  
  public static final void gtk_spin_button_update(int paramInt)
  {
    lock.lock();
    try
    {
      _gtk_spin_button_update(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _gtk_status_icon_get_geometry(int paramInt1, int paramInt2, GdkRectangle paramGdkRectangle, int paramInt3);
  
  public static final boolean gtk_status_icon_get_geometry(int paramInt1, int paramInt2, GdkRectangle paramGdkRectangle, int paramInt3)
  {
    lock.lock();
    try
    {
      boolean bool = _gtk_status_icon_get_geometry(paramInt1, paramInt2, paramGdkRectangle, paramInt3);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _gtk_status_icon_get_visible(int paramInt);
  
  public static final boolean gtk_status_icon_get_visible(int paramInt)
  {
    lock.lock();
    try
    {
      boolean bool = _gtk_status_icon_get_visible(paramInt);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_status_icon_new();
  
  public static final int gtk_status_icon_new()
  {
    lock.lock();
    try
    {
      int i = _gtk_status_icon_new();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_status_icon_set_from_pixbuf(int paramInt1, int paramInt2);
  
  public static final void gtk_status_icon_set_from_pixbuf(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_status_icon_set_from_pixbuf(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_status_icon_set_visible(int paramInt, boolean paramBoolean);
  
  public static final void gtk_status_icon_set_visible(int paramInt, boolean paramBoolean)
  {
    lock.lock();
    try
    {
      _gtk_status_icon_set_visible(paramInt, paramBoolean);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_status_icon_set_tooltip(int paramInt, byte[] paramArrayOfByte);
  
  public static final void gtk_status_icon_set_tooltip(int paramInt, byte[] paramArrayOfByte)
  {
    lock.lock();
    try
    {
      _gtk_status_icon_set_tooltip(paramInt, paramArrayOfByte);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_style_get_base(int paramInt1, int paramInt2, GdkColor paramGdkColor);
  
  public static final void gtk_style_get_base(int paramInt1, int paramInt2, GdkColor paramGdkColor)
  {
    lock.lock();
    try
    {
      _gtk_style_get_base(paramInt1, paramInt2, paramGdkColor);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_style_context_add_class(int paramInt, byte[] paramArrayOfByte);
  
  public static final void gtk_style_context_add_class(int paramInt, byte[] paramArrayOfByte)
  {
    lock.lock();
    try
    {
      _gtk_style_context_add_class(paramInt, paramArrayOfByte);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_style_context_get_background_color(int paramInt1, int paramInt2, GdkRGBA paramGdkRGBA);
  
  public static final void gtk_style_context_get_background_color(int paramInt1, int paramInt2, GdkRGBA paramGdkRGBA)
  {
    lock.lock();
    try
    {
      _gtk_style_context_get_background_color(paramInt1, paramInt2, paramGdkRGBA);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_style_context_get_border_color(int paramInt1, int paramInt2, GdkRGBA paramGdkRGBA);
  
  public static final void gtk_style_context_get_border_color(int paramInt1, int paramInt2, GdkRGBA paramGdkRGBA)
  {
    lock.lock();
    try
    {
      _gtk_style_context_get_border_color(paramInt1, paramInt2, paramGdkRGBA);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_style_context_get_color(int paramInt1, int paramInt2, GdkRGBA paramGdkRGBA);
  
  public static final void gtk_style_context_get_color(int paramInt1, int paramInt2, GdkRGBA paramGdkRGBA)
  {
    lock.lock();
    try
    {
      _gtk_style_context_get_color(paramInt1, paramInt2, paramGdkRGBA);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_style_context_get_font(int paramInt1, int paramInt2);
  
  public static final int gtk_style_context_get_font(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      int i = _gtk_style_context_get_font(paramInt1, paramInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_style_context_get_padding(int paramInt1, int paramInt2, GtkBorder paramGtkBorder);
  
  public static final void gtk_style_context_get_padding(int paramInt1, int paramInt2, GtkBorder paramGtkBorder)
  {
    lock.lock();
    try
    {
      _gtk_style_context_get_padding(paramInt1, paramInt2, paramGtkBorder);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_style_context_get_border(int paramInt1, int paramInt2, GtkBorder paramGtkBorder);
  
  public static final void gtk_style_context_get_border(int paramInt1, int paramInt2, GtkBorder paramGtkBorder)
  {
    lock.lock();
    try
    {
      _gtk_style_context_get_border(paramInt1, paramInt2, paramGtkBorder);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_style_context_invalidate(int paramInt);
  
  public static final void gtk_style_context_invalidate(int paramInt)
  {
    lock.lock();
    try
    {
      _gtk_style_context_invalidate(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_style_context_save(int paramInt);
  
  public static final void gtk_style_context_save(int paramInt)
  {
    lock.lock();
    try
    {
      _gtk_style_context_save(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_style_context_restore(int paramInt);
  
  public static final void gtk_style_context_restore(int paramInt)
  {
    lock.lock();
    try
    {
      _gtk_style_context_restore(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_widget_get_state_flags(int paramInt);
  
  public static final int gtk_widget_get_state_flags(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_widget_get_state_flags(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_style_context_set_state(int paramInt1, int paramInt2);
  
  public static final void gtk_style_context_set_state(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_style_context_set_state(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_style_get_black(int paramInt, GdkColor paramGdkColor);
  
  public static final void gtk_style_get_black(int paramInt, GdkColor paramGdkColor)
  {
    lock.lock();
    try
    {
      _gtk_style_get_black(paramInt, paramGdkColor);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_style_get_bg(int paramInt1, int paramInt2, GdkColor paramGdkColor);
  
  public static final void gtk_style_get_bg(int paramInt1, int paramInt2, GdkColor paramGdkColor)
  {
    lock.lock();
    try
    {
      _gtk_style_get_bg(paramInt1, paramInt2, paramGdkColor);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_style_get_dark(int paramInt1, int paramInt2, GdkColor paramGdkColor);
  
  public static final void gtk_style_get_dark(int paramInt1, int paramInt2, GdkColor paramGdkColor)
  {
    lock.lock();
    try
    {
      _gtk_style_get_dark(paramInt1, paramInt2, paramGdkColor);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_style_get_fg(int paramInt1, int paramInt2, GdkColor paramGdkColor);
  
  public static final void gtk_style_get_fg(int paramInt1, int paramInt2, GdkColor paramGdkColor)
  {
    lock.lock();
    try
    {
      _gtk_style_get_fg(paramInt1, paramInt2, paramGdkColor);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_style_get_fg_gc(int paramInt1, int paramInt2, int[] paramArrayOfInt);
  
  public static final void gtk_style_get_fg_gc(int paramInt1, int paramInt2, int[] paramArrayOfInt)
  {
    lock.lock();
    try
    {
      _gtk_style_get_fg_gc(paramInt1, paramInt2, paramArrayOfInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_style_get_bg_gc(int paramInt1, int paramInt2, int[] paramArrayOfInt);
  
  public static final void gtk_style_get_bg_gc(int paramInt1, int paramInt2, int[] paramArrayOfInt)
  {
    lock.lock();
    try
    {
      _gtk_style_get_bg_gc(paramInt1, paramInt2, paramArrayOfInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_style_get_light_gc(int paramInt1, int paramInt2, int[] paramArrayOfInt);
  
  public static final void gtk_style_get_light_gc(int paramInt1, int paramInt2, int[] paramArrayOfInt)
  {
    lock.lock();
    try
    {
      _gtk_style_get_light_gc(paramInt1, paramInt2, paramArrayOfInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_style_get_dark_gc(int paramInt1, int paramInt2, int[] paramArrayOfInt);
  
  public static final void gtk_style_get_dark_gc(int paramInt1, int paramInt2, int[] paramArrayOfInt)
  {
    lock.lock();
    try
    {
      _gtk_style_get_dark_gc(paramInt1, paramInt2, paramArrayOfInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_style_get_mid_gc(int paramInt1, int paramInt2, int[] paramArrayOfInt);
  
  public static final void gtk_style_get_mid_gc(int paramInt1, int paramInt2, int[] paramArrayOfInt)
  {
    lock.lock();
    try
    {
      _gtk_style_get_mid_gc(paramInt1, paramInt2, paramArrayOfInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_style_get_text_gc(int paramInt1, int paramInt2, int[] paramArrayOfInt);
  
  public static final void gtk_style_get_text_gc(int paramInt1, int paramInt2, int[] paramArrayOfInt)
  {
    lock.lock();
    try
    {
      _gtk_style_get_text_gc(paramInt1, paramInt2, paramArrayOfInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_style_get_text_aa_gc(int paramInt1, int paramInt2, int[] paramArrayOfInt);
  
  public static final void gtk_style_get_text_aa_gc(int paramInt1, int paramInt2, int[] paramArrayOfInt)
  {
    lock.lock();
    try
    {
      _gtk_style_get_text_aa_gc(paramInt1, paramInt2, paramArrayOfInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_style_get_black_gc(int paramInt, int[] paramArrayOfInt);
  
  public static final void gtk_style_get_black_gc(int paramInt, int[] paramArrayOfInt)
  {
    lock.lock();
    try
    {
      _gtk_style_get_black_gc(paramInt, paramArrayOfInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_style_get_white_gc(int paramInt, int[] paramArrayOfInt);
  
  public static final void gtk_style_get_white_gc(int paramInt, int[] paramArrayOfInt)
  {
    lock.lock();
    try
    {
      _gtk_style_get_white_gc(paramInt, paramArrayOfInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_style_get_font_desc(int paramInt);
  
  public static final int gtk_style_get_font_desc(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_style_get_font_desc(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_style_get_light(int paramInt1, int paramInt2, GdkColor paramGdkColor);
  
  public static final void gtk_style_get_light(int paramInt1, int paramInt2, GdkColor paramGdkColor)
  {
    lock.lock();
    try
    {
      _gtk_style_get_light(paramInt1, paramInt2, paramGdkColor);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_style_get_text(int paramInt1, int paramInt2, GdkColor paramGdkColor);
  
  public static final void gtk_style_get_text(int paramInt1, int paramInt2, GdkColor paramGdkColor)
  {
    lock.lock();
    try
    {
      _gtk_style_get_text(paramInt1, paramInt2, paramGdkColor);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_style_get_xthickness(int paramInt);
  
  public static final int gtk_style_get_xthickness(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_style_get_xthickness(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_style_get_ythickness(int paramInt);
  
  public static final int gtk_style_get_ythickness(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_style_get_ythickness(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_style_render_icon(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, byte[] paramArrayOfByte);
  
  public static final int gtk_style_render_icon(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, byte[] paramArrayOfByte)
  {
    lock.lock();
    try
    {
      int i = _gtk_style_render_icon(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramArrayOfByte);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_target_list_new(int paramInt1, int paramInt2);
  
  public static final int gtk_target_list_new(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      int i = _gtk_target_list_new(paramInt1, paramInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_target_list_unref(int paramInt);
  
  public static final void gtk_target_list_unref(int paramInt)
  {
    lock.lock();
    try
    {
      _gtk_target_list_unref(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_text_buffer_copy_clipboard(int paramInt1, int paramInt2);
  
  public static final void gtk_text_buffer_copy_clipboard(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_text_buffer_copy_clipboard(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_text_buffer_cut_clipboard(int paramInt1, int paramInt2, boolean paramBoolean);
  
  public static final void gtk_text_buffer_cut_clipboard(int paramInt1, int paramInt2, boolean paramBoolean)
  {
    lock.lock();
    try
    {
      _gtk_text_buffer_cut_clipboard(paramInt1, paramInt2, paramBoolean);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_text_buffer_delete(int paramInt, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2);
  
  public static final void gtk_text_buffer_delete(int paramInt, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    lock.lock();
    try
    {
      _gtk_text_buffer_delete(paramInt, paramArrayOfByte1, paramArrayOfByte2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_text_buffer_get_bounds(int paramInt, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2);
  
  public static final void gtk_text_buffer_get_bounds(int paramInt, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    lock.lock();
    try
    {
      _gtk_text_buffer_get_bounds(paramInt, paramArrayOfByte1, paramArrayOfByte2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_text_buffer_get_end_iter(int paramInt, byte[] paramArrayOfByte);
  
  public static final void gtk_text_buffer_get_end_iter(int paramInt, byte[] paramArrayOfByte)
  {
    lock.lock();
    try
    {
      _gtk_text_buffer_get_end_iter(paramInt, paramArrayOfByte);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_text_buffer_get_insert(int paramInt);
  
  public static final int gtk_text_buffer_get_insert(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_text_buffer_get_insert(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_text_buffer_get_iter_at_line(int paramInt1, byte[] paramArrayOfByte, int paramInt2);
  
  public static final void gtk_text_buffer_get_iter_at_line(int paramInt1, byte[] paramArrayOfByte, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_text_buffer_get_iter_at_line(paramInt1, paramArrayOfByte, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_text_buffer_get_iter_at_mark(int paramInt1, byte[] paramArrayOfByte, int paramInt2);
  
  public static final void gtk_text_buffer_get_iter_at_mark(int paramInt1, byte[] paramArrayOfByte, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_text_buffer_get_iter_at_mark(paramInt1, paramArrayOfByte, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_text_buffer_get_iter_at_offset(int paramInt1, byte[] paramArrayOfByte, int paramInt2);
  
  public static final void gtk_text_buffer_get_iter_at_offset(int paramInt1, byte[] paramArrayOfByte, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_text_buffer_get_iter_at_offset(paramInt1, paramArrayOfByte, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_text_buffer_get_line_count(int paramInt);
  
  public static final int gtk_text_buffer_get_line_count(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_text_buffer_get_line_count(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_text_buffer_get_selection_bound(int paramInt);
  
  public static final int gtk_text_buffer_get_selection_bound(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_text_buffer_get_selection_bound(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _gtk_text_buffer_get_selection_bounds(int paramInt, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2);
  
  public static final boolean gtk_text_buffer_get_selection_bounds(int paramInt, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    lock.lock();
    try
    {
      boolean bool = _gtk_text_buffer_get_selection_bounds(paramInt, paramArrayOfByte1, paramArrayOfByte2);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_text_buffer_get_text(int paramInt, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, boolean paramBoolean);
  
  public static final int gtk_text_buffer_get_text(int paramInt, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, boolean paramBoolean)
  {
    lock.lock();
    try
    {
      int i = _gtk_text_buffer_get_text(paramInt, paramArrayOfByte1, paramArrayOfByte2, paramBoolean);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_text_buffer_insert(int paramInt1, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, int paramInt2);
  
  public static final void gtk_text_buffer_insert(int paramInt1, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_text_buffer_insert(paramInt1, paramArrayOfByte1, paramArrayOfByte2, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_text_buffer_insert(int paramInt1, int paramInt2, byte[] paramArrayOfByte, int paramInt3);
  
  public static final void gtk_text_buffer_insert(int paramInt1, int paramInt2, byte[] paramArrayOfByte, int paramInt3)
  {
    lock.lock();
    try
    {
      _gtk_text_buffer_insert(paramInt1, paramInt2, paramArrayOfByte, paramInt3);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_text_buffer_select_range(int paramInt, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2);
  
  public static final void gtk_text_buffer_select_range(int paramInt, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    lock.lock();
    try
    {
      _gtk_text_buffer_select_range(paramInt, paramArrayOfByte1, paramArrayOfByte2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_text_buffer_paste_clipboard(int paramInt1, int paramInt2, byte[] paramArrayOfByte, boolean paramBoolean);
  
  public static final void gtk_text_buffer_paste_clipboard(int paramInt1, int paramInt2, byte[] paramArrayOfByte, boolean paramBoolean)
  {
    lock.lock();
    try
    {
      _gtk_text_buffer_paste_clipboard(paramInt1, paramInt2, paramArrayOfByte, paramBoolean);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_text_buffer_place_cursor(int paramInt, byte[] paramArrayOfByte);
  
  public static final void gtk_text_buffer_place_cursor(int paramInt, byte[] paramArrayOfByte)
  {
    lock.lock();
    try
    {
      _gtk_text_buffer_place_cursor(paramInt, paramArrayOfByte);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_text_buffer_set_text(int paramInt1, byte[] paramArrayOfByte, int paramInt2);
  
  public static final void gtk_text_buffer_set_text(int paramInt1, byte[] paramArrayOfByte, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_text_buffer_set_text(paramInt1, paramArrayOfByte, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_text_iter_get_line(byte[] paramArrayOfByte);
  
  public static final int gtk_text_iter_get_line(byte[] paramArrayOfByte)
  {
    lock.lock();
    try
    {
      int i = _gtk_text_iter_get_line(paramArrayOfByte);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_text_iter_get_offset(byte[] paramArrayOfByte);
  
  public static final int gtk_text_iter_get_offset(byte[] paramArrayOfByte)
  {
    lock.lock();
    try
    {
      int i = _gtk_text_iter_get_offset(paramArrayOfByte);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_text_view_buffer_to_window_coords(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int[] paramArrayOfInt1, int[] paramArrayOfInt2);
  
  public static final void gtk_text_view_buffer_to_window_coords(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int[] paramArrayOfInt1, int[] paramArrayOfInt2)
  {
    lock.lock();
    try
    {
      _gtk_text_view_buffer_to_window_coords(paramInt1, paramInt2, paramInt3, paramInt4, paramArrayOfInt1, paramArrayOfInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_text_view_get_buffer(int paramInt);
  
  public static final int gtk_text_view_get_buffer(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_text_view_get_buffer(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _gtk_text_view_get_editable(int paramInt);
  
  public static final boolean gtk_text_view_get_editable(int paramInt)
  {
    lock.lock();
    try
    {
      boolean bool = _gtk_text_view_get_editable(paramInt);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_text_view_get_iter_at_location(int paramInt1, byte[] paramArrayOfByte, int paramInt2, int paramInt3);
  
  public static final void gtk_text_view_get_iter_at_location(int paramInt1, byte[] paramArrayOfByte, int paramInt2, int paramInt3)
  {
    lock.lock();
    try
    {
      _gtk_text_view_get_iter_at_location(paramInt1, paramArrayOfByte, paramInt2, paramInt3);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_text_view_get_iter_location(int paramInt, byte[] paramArrayOfByte, GdkRectangle paramGdkRectangle);
  
  public static final void gtk_text_view_get_iter_location(int paramInt, byte[] paramArrayOfByte, GdkRectangle paramGdkRectangle)
  {
    lock.lock();
    try
    {
      _gtk_text_view_get_iter_location(paramInt, paramArrayOfByte, paramGdkRectangle);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_text_view_get_line_at_y(int paramInt1, byte[] paramArrayOfByte, int paramInt2, int[] paramArrayOfInt);
  
  public static final void gtk_text_view_get_line_at_y(int paramInt1, byte[] paramArrayOfByte, int paramInt2, int[] paramArrayOfInt)
  {
    lock.lock();
    try
    {
      _gtk_text_view_get_line_at_y(paramInt1, paramArrayOfByte, paramInt2, paramArrayOfInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_text_view_get_visible_rect(int paramInt, GdkRectangle paramGdkRectangle);
  
  public static final void gtk_text_view_get_visible_rect(int paramInt, GdkRectangle paramGdkRectangle)
  {
    lock.lock();
    try
    {
      _gtk_text_view_get_visible_rect(paramInt, paramGdkRectangle);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_text_view_get_window(int paramInt1, int paramInt2);
  
  public static final int gtk_text_view_get_window(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      int i = _gtk_text_view_get_window(paramInt1, paramInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_text_view_new();
  
  public static final int gtk_text_view_new()
  {
    lock.lock();
    try
    {
      int i = _gtk_text_view_new();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_text_view_scroll_mark_onscreen(int paramInt1, int paramInt2);
  
  public static final void gtk_text_view_scroll_mark_onscreen(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_text_view_scroll_mark_onscreen(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _gtk_text_view_scroll_to_iter(int paramInt, byte[] paramArrayOfByte, double paramDouble1, boolean paramBoolean, double paramDouble2, double paramDouble3);
  
  public static final boolean gtk_text_view_scroll_to_iter(int paramInt, byte[] paramArrayOfByte, double paramDouble1, boolean paramBoolean, double paramDouble2, double paramDouble3)
  {
    lock.lock();
    try
    {
      boolean bool = _gtk_text_view_scroll_to_iter(paramInt, paramArrayOfByte, paramDouble1, paramBoolean, paramDouble2, paramDouble3);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_text_view_set_editable(int paramInt, boolean paramBoolean);
  
  public static final void gtk_text_view_set_editable(int paramInt, boolean paramBoolean)
  {
    lock.lock();
    try
    {
      _gtk_text_view_set_editable(paramInt, paramBoolean);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_text_view_set_justification(int paramInt1, int paramInt2);
  
  public static final void gtk_text_view_set_justification(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_text_view_set_justification(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_text_view_set_tabs(int paramInt1, int paramInt2);
  
  public static final void gtk_text_view_set_tabs(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_text_view_set_tabs(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_text_view_set_wrap_mode(int paramInt1, int paramInt2);
  
  public static final void gtk_text_view_set_wrap_mode(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_text_view_set_wrap_mode(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _g_timeout_add(int paramInt1, int paramInt2, int paramInt3);
  
  public static final int g_timeout_add(int paramInt1, int paramInt2, int paramInt3)
  {
    lock.lock();
    try
    {
      int i = _g_timeout_add(paramInt1, paramInt2, paramInt3);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _gtk_toggle_button_get_active(int paramInt);
  
  public static final boolean gtk_toggle_button_get_active(int paramInt)
  {
    lock.lock();
    try
    {
      boolean bool = _gtk_toggle_button_get_active(paramInt);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_toggle_button_new();
  
  public static final int gtk_toggle_button_new()
  {
    lock.lock();
    try
    {
      int i = _gtk_toggle_button_new();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_toggle_button_set_active(int paramInt, boolean paramBoolean);
  
  public static final void gtk_toggle_button_set_active(int paramInt, boolean paramBoolean)
  {
    lock.lock();
    try
    {
      _gtk_toggle_button_set_active(paramInt, paramBoolean);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_toggle_button_set_inconsistent(int paramInt, boolean paramBoolean);
  
  public static final void gtk_toggle_button_set_inconsistent(int paramInt, boolean paramBoolean)
  {
    lock.lock();
    try
    {
      _gtk_toggle_button_set_inconsistent(paramInt, paramBoolean);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_toggle_button_set_mode(int paramInt, boolean paramBoolean);
  
  public static final void gtk_toggle_button_set_mode(int paramInt, boolean paramBoolean)
  {
    lock.lock();
    try
    {
      _gtk_toggle_button_set_mode(paramInt, paramBoolean);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _gtk_toggle_tool_button_get_active(int paramInt);
  
  public static final boolean gtk_toggle_tool_button_get_active(int paramInt)
  {
    lock.lock();
    try
    {
      boolean bool = _gtk_toggle_tool_button_get_active(paramInt);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_toggle_tool_button_new();
  
  public static final int gtk_toggle_tool_button_new()
  {
    lock.lock();
    try
    {
      int i = _gtk_toggle_tool_button_new();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_toggle_tool_button_set_active(int paramInt, boolean paramBoolean);
  
  public static final void gtk_toggle_tool_button_set_active(int paramInt, boolean paramBoolean)
  {
    lock.lock();
    try
    {
      _gtk_toggle_tool_button_set_active(paramInt, paramBoolean);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_tool_button_new(int paramInt, byte[] paramArrayOfByte);
  
  public static final int gtk_tool_button_new(int paramInt, byte[] paramArrayOfByte)
  {
    lock.lock();
    try
    {
      int i = _gtk_tool_button_new(paramInt, paramArrayOfByte);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_tool_button_set_icon_widget(int paramInt1, int paramInt2);
  
  public static final void gtk_tool_button_set_icon_widget(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_tool_button_set_icon_widget(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_tool_button_set_label(int paramInt, byte[] paramArrayOfByte);
  
  public static final void gtk_tool_button_set_label(int paramInt, byte[] paramArrayOfByte)
  {
    lock.lock();
    try
    {
      _gtk_tool_button_set_label(paramInt, paramArrayOfByte);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_tool_button_set_label_widget(int paramInt1, int paramInt2);
  
  public static final void gtk_tool_button_set_label_widget(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_tool_button_set_label_widget(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_tool_button_set_use_underline(int paramInt, boolean paramBoolean);
  
  public static final void gtk_tool_button_set_use_underline(int paramInt, boolean paramBoolean)
  {
    lock.lock();
    try
    {
      _gtk_tool_button_set_use_underline(paramInt, paramBoolean);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_tool_item_get_proxy_menu_item(int paramInt, byte[] paramArrayOfByte);
  
  public static final int gtk_tool_item_get_proxy_menu_item(int paramInt, byte[] paramArrayOfByte)
  {
    lock.lock();
    try
    {
      int i = _gtk_tool_item_get_proxy_menu_item(paramInt, paramArrayOfByte);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_tool_item_retrieve_proxy_menu_item(int paramInt);
  
  public static final int gtk_tool_item_retrieve_proxy_menu_item(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_tool_item_retrieve_proxy_menu_item(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_tool_item_set_is_important(int paramInt, boolean paramBoolean);
  
  public static final void gtk_tool_item_set_is_important(int paramInt, boolean paramBoolean)
  {
    lock.lock();
    try
    {
      _gtk_tool_item_set_is_important(paramInt, paramBoolean);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_tool_item_set_proxy_menu_item(int paramInt1, byte[] paramArrayOfByte, int paramInt2);
  
  public static final void gtk_tool_item_set_proxy_menu_item(int paramInt1, byte[] paramArrayOfByte, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_tool_item_set_proxy_menu_item(paramInt1, paramArrayOfByte, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_toolbar_insert(int paramInt1, int paramInt2, int paramInt3);
  
  public static final void gtk_toolbar_insert(int paramInt1, int paramInt2, int paramInt3)
  {
    lock.lock();
    try
    {
      _gtk_toolbar_insert(paramInt1, paramInt2, paramInt3);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_toolbar_new();
  
  public static final int gtk_toolbar_new()
  {
    lock.lock();
    try
    {
      int i = _gtk_toolbar_new();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_toolbar_set_orientation(int paramInt1, int paramInt2);
  
  public static final void gtk_toolbar_set_orientation(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_toolbar_set_orientation(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_toolbar_set_show_arrow(int paramInt, boolean paramBoolean);
  
  public static final void gtk_toolbar_set_show_arrow(int paramInt, boolean paramBoolean)
  {
    lock.lock();
    try
    {
      _gtk_toolbar_set_show_arrow(paramInt, paramBoolean);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_toolbar_set_style(int paramInt1, int paramInt2);
  
  public static final void gtk_toolbar_set_style(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_toolbar_set_style(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_toolbar_set_icon_size(int paramInt1, int paramInt2);
  
  public static final void gtk_toolbar_set_icon_size(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_toolbar_set_icon_size(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_tooltips_data_get(int paramInt);
  
  public static final int gtk_tooltips_data_get(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_tooltips_data_get(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_tooltips_disable(int paramInt);
  
  public static final void gtk_tooltips_disable(int paramInt)
  {
    lock.lock();
    try
    {
      _gtk_tooltips_disable(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_tooltips_enable(int paramInt);
  
  public static final void gtk_tooltips_enable(int paramInt)
  {
    lock.lock();
    try
    {
      _gtk_tooltips_enable(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_tooltips_new();
  
  public static final int gtk_tooltips_new()
  {
    lock.lock();
    try
    {
      int i = _gtk_tooltips_new();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_tooltips_force_window(int paramInt);
  
  public static final void gtk_tooltips_force_window(int paramInt)
  {
    lock.lock();
    try
    {
      _gtk_tooltips_force_window(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_tooltips_set_tip(int paramInt1, int paramInt2, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2);
  
  public static final void gtk_tooltips_set_tip(int paramInt1, int paramInt2, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    lock.lock();
    try
    {
      _gtk_tooltips_set_tip(paramInt1, paramInt2, paramArrayOfByte1, paramArrayOfByte2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_tree_model_get(int paramInt1, int paramInt2, int paramInt3, long[] paramArrayOfLong, int paramInt4);
  
  public static final void gtk_tree_model_get(int paramInt1, int paramInt2, int paramInt3, long[] paramArrayOfLong, int paramInt4)
  {
    lock.lock();
    try
    {
      _gtk_tree_model_get(paramInt1, paramInt2, paramInt3, paramArrayOfLong, paramInt4);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_tree_model_get(int paramInt1, int paramInt2, int paramInt3, int[] paramArrayOfInt, int paramInt4);
  
  public static final void gtk_tree_model_get(int paramInt1, int paramInt2, int paramInt3, int[] paramArrayOfInt, int paramInt4)
  {
    lock.lock();
    try
    {
      _gtk_tree_model_get(paramInt1, paramInt2, paramInt3, paramArrayOfInt, paramInt4);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _gtk_tree_model_get_iter(int paramInt1, int paramInt2, int paramInt3);
  
  public static final boolean gtk_tree_model_get_iter(int paramInt1, int paramInt2, int paramInt3)
  {
    lock.lock();
    try
    {
      boolean bool = _gtk_tree_model_get_iter(paramInt1, paramInt2, paramInt3);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _gtk_tree_model_get_iter_first(int paramInt1, int paramInt2);
  
  public static final boolean gtk_tree_model_get_iter_first(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      boolean bool = _gtk_tree_model_get_iter_first(paramInt1, paramInt2);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_tree_model_get_n_columns(int paramInt);
  
  public static final int gtk_tree_model_get_n_columns(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_tree_model_get_n_columns(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_tree_model_get_path(int paramInt1, int paramInt2);
  
  public static final int gtk_tree_model_get_path(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      int i = _gtk_tree_model_get_path(paramInt1, paramInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_tree_model_get_type();
  
  public static final int gtk_tree_model_get_type()
  {
    lock.lock();
    try
    {
      int i = _gtk_tree_model_get_type();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _gtk_tree_model_iter_children(int paramInt1, int paramInt2, int paramInt3);
  
  public static final boolean gtk_tree_model_iter_children(int paramInt1, int paramInt2, int paramInt3)
  {
    lock.lock();
    try
    {
      boolean bool = _gtk_tree_model_iter_children(paramInt1, paramInt2, paramInt3);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_tree_model_iter_n_children(int paramInt1, int paramInt2);
  
  public static final int gtk_tree_model_iter_n_children(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      int i = _gtk_tree_model_iter_n_children(paramInt1, paramInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _gtk_tree_model_iter_next(int paramInt1, int paramInt2);
  
  public static final boolean gtk_tree_model_iter_next(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      boolean bool = _gtk_tree_model_iter_next(paramInt1, paramInt2);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _gtk_tree_model_iter_nth_child(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  public static final boolean gtk_tree_model_iter_nth_child(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    lock.lock();
    try
    {
      boolean bool = _gtk_tree_model_iter_nth_child(paramInt1, paramInt2, paramInt3, paramInt4);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_tree_path_append_index(int paramInt1, int paramInt2);
  
  public static final void gtk_tree_path_append_index(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_tree_path_append_index(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_tree_path_compare(int paramInt1, int paramInt2);
  
  public static final int gtk_tree_path_compare(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      int i = _gtk_tree_path_compare(paramInt1, paramInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_tree_path_free(int paramInt);
  
  public static final void gtk_tree_path_free(int paramInt)
  {
    lock.lock();
    try
    {
      _gtk_tree_path_free(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_tree_path_get_depth(int paramInt);
  
  public static final int gtk_tree_path_get_depth(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_tree_path_get_depth(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_tree_path_get_indices(int paramInt);
  
  public static final int gtk_tree_path_get_indices(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_tree_path_get_indices(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_tree_path_new();
  
  public static final int gtk_tree_path_new()
  {
    lock.lock();
    try
    {
      int i = _gtk_tree_path_new();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_tree_path_new_from_string(byte[] paramArrayOfByte);
  
  public static final int gtk_tree_path_new_from_string(byte[] paramArrayOfByte)
  {
    lock.lock();
    try
    {
      int i = _gtk_tree_path_new_from_string(paramArrayOfByte);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_tree_path_new_from_string(int paramInt);
  
  public static final int gtk_tree_path_new_from_string(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_tree_path_new_from_string(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_tree_path_next(int paramInt);
  
  public static final void gtk_tree_path_next(int paramInt)
  {
    lock.lock();
    try
    {
      _gtk_tree_path_next(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _gtk_tree_path_prev(int paramInt);
  
  public static final boolean gtk_tree_path_prev(int paramInt)
  {
    lock.lock();
    try
    {
      boolean bool = _gtk_tree_path_prev(paramInt);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _gtk_tree_path_up(int paramInt);
  
  public static final boolean gtk_tree_path_up(int paramInt)
  {
    lock.lock();
    try
    {
      boolean bool = _gtk_tree_path_up(paramInt);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_tree_selection_count_selected_rows(int paramInt);
  
  public static final int gtk_tree_selection_count_selected_rows(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_tree_selection_count_selected_rows(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_tree_selection_get_selected_rows(int paramInt, int[] paramArrayOfInt);
  
  public static final int gtk_tree_selection_get_selected_rows(int paramInt, int[] paramArrayOfInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_tree_selection_get_selected_rows(paramInt, paramArrayOfInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _gtk_tree_selection_path_is_selected(int paramInt1, int paramInt2);
  
  public static final boolean gtk_tree_selection_path_is_selected(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      boolean bool = _gtk_tree_selection_path_is_selected(paramInt1, paramInt2);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_tree_selection_select_all(int paramInt);
  
  public static final void gtk_tree_selection_select_all(int paramInt)
  {
    lock.lock();
    try
    {
      _gtk_tree_selection_select_all(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_tree_selection_select_iter(int paramInt1, int paramInt2);
  
  public static final void gtk_tree_selection_select_iter(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_tree_selection_select_iter(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_tree_selection_set_mode(int paramInt1, int paramInt2);
  
  public static final void gtk_tree_selection_set_mode(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_tree_selection_set_mode(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_tree_selection_unselect_all(int paramInt);
  
  public static final void gtk_tree_selection_unselect_all(int paramInt)
  {
    lock.lock();
    try
    {
      _gtk_tree_selection_unselect_all(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_tree_selection_unselect_iter(int paramInt1, int paramInt2);
  
  public static final void gtk_tree_selection_unselect_iter(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_tree_selection_unselect_iter(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_tree_store_append(int paramInt1, int paramInt2, int paramInt3);
  
  public static final void gtk_tree_store_append(int paramInt1, int paramInt2, int paramInt3)
  {
    lock.lock();
    try
    {
      _gtk_tree_store_append(paramInt1, paramInt2, paramInt3);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_tree_store_clear(int paramInt);
  
  public static final void gtk_tree_store_clear(int paramInt)
  {
    lock.lock();
    try
    {
      _gtk_tree_store_clear(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_tree_store_insert(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  public static final void gtk_tree_store_insert(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    lock.lock();
    try
    {
      _gtk_tree_store_insert(paramInt1, paramInt2, paramInt3, paramInt4);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_tree_store_newv(int paramInt, int[] paramArrayOfInt);
  
  public static final int gtk_tree_store_newv(int paramInt, int[] paramArrayOfInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_tree_store_newv(paramInt, paramArrayOfInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_tree_store_remove(int paramInt1, int paramInt2);
  
  public static final void gtk_tree_store_remove(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_tree_store_remove(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_tree_store_set(int paramInt1, int paramInt2, int paramInt3, byte[] paramArrayOfByte, int paramInt4);
  
  public static final void gtk_tree_store_set(int paramInt1, int paramInt2, int paramInt3, byte[] paramArrayOfByte, int paramInt4)
  {
    lock.lock();
    try
    {
      _gtk_tree_store_set(paramInt1, paramInt2, paramInt3, paramArrayOfByte, paramInt4);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_tree_store_set(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5);
  
  public static final void gtk_tree_store_set(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
  {
    lock.lock();
    try
    {
      _gtk_tree_store_set(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_tree_store_set(int paramInt1, int paramInt2, int paramInt3, long paramLong, int paramInt4);
  
  public static final void gtk_tree_store_set(int paramInt1, int paramInt2, int paramInt3, long paramLong, int paramInt4)
  {
    lock.lock();
    try
    {
      _gtk_tree_store_set(paramInt1, paramInt2, paramInt3, paramLong, paramInt4);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_tree_store_set(int paramInt1, int paramInt2, int paramInt3, GdkColor paramGdkColor, int paramInt4);
  
  public static final void gtk_tree_store_set(int paramInt1, int paramInt2, int paramInt3, GdkColor paramGdkColor, int paramInt4)
  {
    lock.lock();
    try
    {
      _gtk_tree_store_set(paramInt1, paramInt2, paramInt3, paramGdkColor, paramInt4);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_tree_store_set(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean, int paramInt4);
  
  public static final void gtk_tree_store_set(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean, int paramInt4)
  {
    lock.lock();
    try
    {
      _gtk_tree_store_set(paramInt1, paramInt2, paramInt3, paramBoolean, paramInt4);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_tree_view_create_row_drag_icon(int paramInt1, int paramInt2);
  
  public static final int gtk_tree_view_create_row_drag_icon(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      int i = _gtk_tree_view_create_row_drag_icon(paramInt1, paramInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _gtk_tree_view_collapse_row(int paramInt1, int paramInt2);
  
  public static final boolean gtk_tree_view_collapse_row(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      boolean bool = _gtk_tree_view_collapse_row(paramInt1, paramInt2);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_tree_view_column_add_attribute(int paramInt1, int paramInt2, byte[] paramArrayOfByte, int paramInt3);
  
  public static final void gtk_tree_view_column_add_attribute(int paramInt1, int paramInt2, byte[] paramArrayOfByte, int paramInt3)
  {
    lock.lock();
    try
    {
      _gtk_tree_view_column_add_attribute(paramInt1, paramInt2, paramArrayOfByte, paramInt3);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _gtk_tree_view_column_cell_get_position(int paramInt1, int paramInt2, int[] paramArrayOfInt1, int[] paramArrayOfInt2);
  
  public static final boolean gtk_tree_view_column_cell_get_position(int paramInt1, int paramInt2, int[] paramArrayOfInt1, int[] paramArrayOfInt2)
  {
    lock.lock();
    try
    {
      boolean bool = _gtk_tree_view_column_cell_get_position(paramInt1, paramInt2, paramArrayOfInt1, paramArrayOfInt2);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_tree_view_column_cell_get_size(int paramInt, GdkRectangle paramGdkRectangle, int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3, int[] paramArrayOfInt4);
  
  public static final void gtk_tree_view_column_cell_get_size(int paramInt, GdkRectangle paramGdkRectangle, int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3, int[] paramArrayOfInt4)
  {
    lock.lock();
    try
    {
      _gtk_tree_view_column_cell_get_size(paramInt, paramGdkRectangle, paramArrayOfInt1, paramArrayOfInt2, paramArrayOfInt3, paramArrayOfInt4);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_tree_view_column_cell_set_cell_data(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean1, boolean paramBoolean2);
  
  public static final void gtk_tree_view_column_cell_set_cell_data(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean1, boolean paramBoolean2)
  {
    lock.lock();
    try
    {
      _gtk_tree_view_column_cell_set_cell_data(paramInt1, paramInt2, paramInt3, paramBoolean1, paramBoolean2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_tree_view_column_clear(int paramInt);
  
  public static final void gtk_tree_view_column_clear(int paramInt)
  {
    lock.lock();
    try
    {
      _gtk_tree_view_column_clear(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_tree_view_column_get_button(int paramInt);
  
  public static final int gtk_tree_view_column_get_button(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_tree_view_column_get_button(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_tree_view_column_get_cell_renderers(int paramInt);
  
  public static final int gtk_tree_view_column_get_cell_renderers(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_tree_view_column_get_cell_renderers(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_tree_view_column_get_fixed_width(int paramInt);
  
  public static final int gtk_tree_view_column_get_fixed_width(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_tree_view_column_get_fixed_width(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _gtk_tree_view_column_get_reorderable(int paramInt);
  
  public static final boolean gtk_tree_view_column_get_reorderable(int paramInt)
  {
    lock.lock();
    try
    {
      boolean bool = _gtk_tree_view_column_get_reorderable(paramInt);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _gtk_tree_view_column_get_resizable(int paramInt);
  
  public static final boolean gtk_tree_view_column_get_resizable(int paramInt)
  {
    lock.lock();
    try
    {
      boolean bool = _gtk_tree_view_column_get_resizable(paramInt);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _gtk_tree_view_column_get_visible(int paramInt);
  
  public static final boolean gtk_tree_view_column_get_visible(int paramInt)
  {
    lock.lock();
    try
    {
      boolean bool = _gtk_tree_view_column_get_visible(paramInt);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_tree_view_column_get_width(int paramInt);
  
  public static final int gtk_tree_view_column_get_width(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_tree_view_column_get_width(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_tree_view_column_new();
  
  public static final int gtk_tree_view_column_new()
  {
    lock.lock();
    try
    {
      int i = _gtk_tree_view_column_new();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_tree_view_column_pack_start(int paramInt1, int paramInt2, boolean paramBoolean);
  
  public static final void gtk_tree_view_column_pack_start(int paramInt1, int paramInt2, boolean paramBoolean)
  {
    lock.lock();
    try
    {
      _gtk_tree_view_column_pack_start(paramInt1, paramInt2, paramBoolean);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_tree_view_column_pack_end(int paramInt1, int paramInt2, boolean paramBoolean);
  
  public static final void gtk_tree_view_column_pack_end(int paramInt1, int paramInt2, boolean paramBoolean)
  {
    lock.lock();
    try
    {
      _gtk_tree_view_column_pack_end(paramInt1, paramInt2, paramBoolean);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_tree_view_column_set_alignment(int paramInt, float paramFloat);
  
  public static final void gtk_tree_view_column_set_alignment(int paramInt, float paramFloat)
  {
    lock.lock();
    try
    {
      _gtk_tree_view_column_set_alignment(paramInt, paramFloat);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_tree_view_column_set_cell_data_func(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5);
  
  public static final void gtk_tree_view_column_set_cell_data_func(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
  {
    lock.lock();
    try
    {
      _gtk_tree_view_column_set_cell_data_func(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_tree_view_column_set_clickable(int paramInt, boolean paramBoolean);
  
  public static final void gtk_tree_view_column_set_clickable(int paramInt, boolean paramBoolean)
  {
    lock.lock();
    try
    {
      _gtk_tree_view_column_set_clickable(paramInt, paramBoolean);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_tree_view_column_set_fixed_width(int paramInt1, int paramInt2);
  
  public static final void gtk_tree_view_column_set_fixed_width(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_tree_view_column_set_fixed_width(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_tree_view_column_set_min_width(int paramInt1, int paramInt2);
  
  public static final void gtk_tree_view_column_set_min_width(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_tree_view_column_set_min_width(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_tree_view_column_set_reorderable(int paramInt, boolean paramBoolean);
  
  public static final void gtk_tree_view_column_set_reorderable(int paramInt, boolean paramBoolean)
  {
    lock.lock();
    try
    {
      _gtk_tree_view_column_set_reorderable(paramInt, paramBoolean);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_tree_view_column_set_resizable(int paramInt, boolean paramBoolean);
  
  public static final void gtk_tree_view_column_set_resizable(int paramInt, boolean paramBoolean)
  {
    lock.lock();
    try
    {
      _gtk_tree_view_column_set_resizable(paramInt, paramBoolean);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_tree_view_column_set_sizing(int paramInt1, int paramInt2);
  
  public static final void gtk_tree_view_column_set_sizing(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_tree_view_column_set_sizing(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_tree_view_column_set_sort_indicator(int paramInt, boolean paramBoolean);
  
  public static final void gtk_tree_view_column_set_sort_indicator(int paramInt, boolean paramBoolean)
  {
    lock.lock();
    try
    {
      _gtk_tree_view_column_set_sort_indicator(paramInt, paramBoolean);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_tree_view_column_set_sort_order(int paramInt1, int paramInt2);
  
  public static final void gtk_tree_view_column_set_sort_order(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_tree_view_column_set_sort_order(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_tree_view_column_set_visible(int paramInt, boolean paramBoolean);
  
  public static final void gtk_tree_view_column_set_visible(int paramInt, boolean paramBoolean)
  {
    lock.lock();
    try
    {
      _gtk_tree_view_column_set_visible(paramInt, paramBoolean);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_tree_view_column_set_widget(int paramInt1, int paramInt2);
  
  public static final void gtk_tree_view_column_set_widget(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_tree_view_column_set_widget(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_tree_view_set_drag_dest_row(int paramInt1, int paramInt2, int paramInt3);
  
  public static final void gtk_tree_view_set_drag_dest_row(int paramInt1, int paramInt2, int paramInt3)
  {
    lock.lock();
    try
    {
      _gtk_tree_view_set_drag_dest_row(paramInt1, paramInt2, paramInt3);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _gtk_tree_view_expand_row(int paramInt1, int paramInt2, boolean paramBoolean);
  
  public static final boolean gtk_tree_view_expand_row(int paramInt1, int paramInt2, boolean paramBoolean)
  {
    lock.lock();
    try
    {
      boolean bool = _gtk_tree_view_expand_row(paramInt1, paramInt2, paramBoolean);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_tree_view_get_background_area(int paramInt1, int paramInt2, int paramInt3, GdkRectangle paramGdkRectangle);
  
  public static final void gtk_tree_view_get_background_area(int paramInt1, int paramInt2, int paramInt3, GdkRectangle paramGdkRectangle)
  {
    lock.lock();
    try
    {
      _gtk_tree_view_get_background_area(paramInt1, paramInt2, paramInt3, paramGdkRectangle);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_tree_view_get_bin_window(int paramInt);
  
  public static final int gtk_tree_view_get_bin_window(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_tree_view_get_bin_window(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_tree_view_get_cell_area(int paramInt1, int paramInt2, int paramInt3, GdkRectangle paramGdkRectangle);
  
  public static final void gtk_tree_view_get_cell_area(int paramInt1, int paramInt2, int paramInt3, GdkRectangle paramGdkRectangle)
  {
    lock.lock();
    try
    {
      _gtk_tree_view_get_cell_area(paramInt1, paramInt2, paramInt3, paramGdkRectangle);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_tree_view_get_expander_column(int paramInt);
  
  public static final int gtk_tree_view_get_expander_column(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_tree_view_get_expander_column(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_tree_view_get_column(int paramInt1, int paramInt2);
  
  public static final int gtk_tree_view_get_column(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      int i = _gtk_tree_view_get_column(paramInt1, paramInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_tree_view_get_columns(int paramInt);
  
  public static final int gtk_tree_view_get_columns(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_tree_view_get_columns(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_tree_view_get_cursor(int paramInt, int[] paramArrayOfInt1, int[] paramArrayOfInt2);
  
  public static final void gtk_tree_view_get_cursor(int paramInt, int[] paramArrayOfInt1, int[] paramArrayOfInt2)
  {
    lock.lock();
    try
    {
      _gtk_tree_view_get_cursor(paramInt, paramArrayOfInt1, paramArrayOfInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _gtk_tree_view_get_headers_visible(int paramInt);
  
  public static final boolean gtk_tree_view_get_headers_visible(int paramInt)
  {
    lock.lock();
    try
    {
      boolean bool = _gtk_tree_view_get_headers_visible(paramInt);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _gtk_tree_view_get_path_at_pos(int paramInt1, int paramInt2, int paramInt3, int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3, int[] paramArrayOfInt4);
  
  public static final boolean gtk_tree_view_get_path_at_pos(int paramInt1, int paramInt2, int paramInt3, int[] paramArrayOfInt1, int[] paramArrayOfInt2, int[] paramArrayOfInt3, int[] paramArrayOfInt4)
  {
    lock.lock();
    try
    {
      boolean bool = _gtk_tree_view_get_path_at_pos(paramInt1, paramInt2, paramInt3, paramArrayOfInt1, paramArrayOfInt2, paramArrayOfInt3, paramArrayOfInt4);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _gtk_tree_view_get_rules_hint(int paramInt);
  
  public static final boolean gtk_tree_view_get_rules_hint(int paramInt)
  {
    lock.lock();
    try
    {
      boolean bool = _gtk_tree_view_get_rules_hint(paramInt);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_tree_view_get_selection(int paramInt);
  
  public static final int gtk_tree_view_get_selection(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_tree_view_get_selection(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_tree_view_get_visible_rect(int paramInt, GdkRectangle paramGdkRectangle);
  
  public static final void gtk_tree_view_get_visible_rect(int paramInt, GdkRectangle paramGdkRectangle)
  {
    lock.lock();
    try
    {
      _gtk_tree_view_get_visible_rect(paramInt, paramGdkRectangle);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_tree_view_insert_column(int paramInt1, int paramInt2, int paramInt3);
  
  public static final int gtk_tree_view_insert_column(int paramInt1, int paramInt2, int paramInt3)
  {
    lock.lock();
    try
    {
      int i = _gtk_tree_view_insert_column(paramInt1, paramInt2, paramInt3);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_tree_view_move_column_after(int paramInt1, int paramInt2, int paramInt3);
  
  public static final void gtk_tree_view_move_column_after(int paramInt1, int paramInt2, int paramInt3)
  {
    lock.lock();
    try
    {
      _gtk_tree_view_move_column_after(paramInt1, paramInt2, paramInt3);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_tree_view_new_with_model(int paramInt);
  
  public static final int gtk_tree_view_new_with_model(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_tree_view_new_with_model(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_tree_view_remove_column(int paramInt1, int paramInt2);
  
  public static final void gtk_tree_view_remove_column(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_tree_view_remove_column(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _gtk_tree_view_row_expanded(int paramInt1, int paramInt2);
  
  public static final boolean gtk_tree_view_row_expanded(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      boolean bool = _gtk_tree_view_row_expanded(paramInt1, paramInt2);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_tree_view_scroll_to_cell(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean, float paramFloat1, float paramFloat2);
  
  public static final void gtk_tree_view_scroll_to_cell(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean, float paramFloat1, float paramFloat2)
  {
    lock.lock();
    try
    {
      _gtk_tree_view_scroll_to_cell(paramInt1, paramInt2, paramInt3, paramBoolean, paramFloat1, paramFloat2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_tree_view_scroll_to_point(int paramInt1, int paramInt2, int paramInt3);
  
  public static final void gtk_tree_view_scroll_to_point(int paramInt1, int paramInt2, int paramInt3)
  {
    lock.lock();
    try
    {
      _gtk_tree_view_scroll_to_point(paramInt1, paramInt2, paramInt3);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_tree_view_set_cursor(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean);
  
  public static final void gtk_tree_view_set_cursor(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean)
  {
    lock.lock();
    try
    {
      _gtk_tree_view_set_cursor(paramInt1, paramInt2, paramInt3, paramBoolean);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_tree_view_set_grid_lines(int paramInt1, int paramInt2);
  
  public static final void gtk_tree_view_set_grid_lines(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_tree_view_set_grid_lines(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_tree_view_set_headers_visible(int paramInt, boolean paramBoolean);
  
  public static final void gtk_tree_view_set_headers_visible(int paramInt, boolean paramBoolean)
  {
    lock.lock();
    try
    {
      _gtk_tree_view_set_headers_visible(paramInt, paramBoolean);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_tree_view_set_model(int paramInt1, int paramInt2);
  
  public static final void gtk_tree_view_set_model(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_tree_view_set_model(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_tree_view_set_rules_hint(int paramInt, boolean paramBoolean);
  
  public static final void gtk_tree_view_set_rules_hint(int paramInt, boolean paramBoolean)
  {
    lock.lock();
    try
    {
      _gtk_tree_view_set_rules_hint(paramInt, paramBoolean);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_tree_view_set_search_column(int paramInt1, int paramInt2);
  
  public static final void gtk_tree_view_set_search_column(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_tree_view_set_search_column(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_tree_view_unset_rows_drag_dest(int paramInt);
  
  public static final void gtk_tree_view_unset_rows_drag_dest(int paramInt)
  {
    lock.lock();
    try
    {
      _gtk_tree_view_unset_rows_drag_dest(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_tree_view_widget_to_tree_coords(int paramInt1, int paramInt2, int paramInt3, int[] paramArrayOfInt1, int[] paramArrayOfInt2);
  
  public static final void gtk_tree_view_widget_to_tree_coords(int paramInt1, int paramInt2, int paramInt3, int[] paramArrayOfInt1, int[] paramArrayOfInt2)
  {
    lock.lock();
    try
    {
      _gtk_tree_view_widget_to_tree_coords(paramInt1, paramInt2, paramInt3, paramArrayOfInt1, paramArrayOfInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_tree_view_convert_bin_window_to_tree_coords(int paramInt1, int paramInt2, int paramInt3, int[] paramArrayOfInt1, int[] paramArrayOfInt2);
  
  public static final void gtk_tree_view_convert_bin_window_to_tree_coords(int paramInt1, int paramInt2, int paramInt3, int[] paramArrayOfInt1, int[] paramArrayOfInt2)
  {
    lock.lock();
    try
    {
      _gtk_tree_view_convert_bin_window_to_tree_coords(paramInt1, paramInt2, paramInt3, paramArrayOfInt1, paramArrayOfInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_vbox_new(boolean paramBoolean, int paramInt);
  
  public static final int gtk_vbox_new(boolean paramBoolean, int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_vbox_new(paramBoolean, paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_viewport_set_shadow_type(int paramInt1, int paramInt2);
  
  public static final void gtk_viewport_set_shadow_type(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_viewport_set_shadow_type(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_vscale_new(int paramInt);
  
  public static final int gtk_vscale_new(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_vscale_new(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_vscrollbar_new(int paramInt);
  
  public static final int gtk_vscrollbar_new(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_vscrollbar_new(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_vseparator_new();
  
  public static final int gtk_vseparator_new()
  {
    lock.lock();
    try
    {
      int i = _gtk_vseparator_new();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_widget_add_accelerator(int paramInt1, byte[] paramArrayOfByte, int paramInt2, int paramInt3, int paramInt4, int paramInt5);
  
  public static final void gtk_widget_add_accelerator(int paramInt1, byte[] paramArrayOfByte, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
  {
    lock.lock();
    try
    {
      _gtk_widget_add_accelerator(paramInt1, paramArrayOfByte, paramInt2, paramInt3, paramInt4, paramInt5);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_widget_add_events(int paramInt1, int paramInt2);
  
  public static final void gtk_widget_add_events(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_widget_add_events(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _gtk_widget_child_focus(int paramInt1, int paramInt2);
  
  public static final boolean gtk_widget_child_focus(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      boolean bool = _gtk_widget_child_focus(paramInt1, paramInt2);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_widget_create_pango_layout(int paramInt, byte[] paramArrayOfByte);
  
  public static final int gtk_widget_create_pango_layout(int paramInt, byte[] paramArrayOfByte)
  {
    lock.lock();
    try
    {
      int i = _gtk_widget_create_pango_layout(paramInt, paramArrayOfByte);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_widget_create_pango_layout(int paramInt1, int paramInt2);
  
  public static final int gtk_widget_create_pango_layout(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      int i = _gtk_widget_create_pango_layout(paramInt1, paramInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_widget_destroy(int paramInt);
  
  public static final void gtk_widget_destroy(int paramInt)
  {
    lock.lock();
    try
    {
      _gtk_widget_destroy(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_widget_draw(int paramInt1, int paramInt2);
  
  public static final void gtk_widget_draw(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_widget_draw(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _gtk_widget_event(int paramInt1, int paramInt2);
  
  public static final boolean gtk_widget_event(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      boolean bool = _gtk_widget_event(paramInt1, paramInt2);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_widget_get_accessible(int paramInt);
  
  public static final int gtk_widget_get_accessible(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_widget_get_accessible(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _gtk_widget_get_visible(int paramInt);
  
  public static final boolean gtk_widget_get_visible(int paramInt)
  {
    lock.lock();
    try
    {
      boolean bool = _gtk_widget_get_visible(paramInt);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _gtk_widget_get_realized(int paramInt);
  
  public static final boolean gtk_widget_get_realized(int paramInt)
  {
    lock.lock();
    try
    {
      boolean bool = _gtk_widget_get_realized(paramInt);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _gtk_widget_get_has_window(int paramInt);
  
  public static final boolean gtk_widget_get_has_window(int paramInt)
  {
    lock.lock();
    try
    {
      boolean bool = _gtk_widget_get_has_window(paramInt);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _gtk_widget_get_can_default(int paramInt);
  
  public static final boolean gtk_widget_get_can_default(int paramInt)
  {
    lock.lock();
    try
    {
      boolean bool = _gtk_widget_get_can_default(paramInt);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _gtk_widget_get_child_visible(int paramInt);
  
  public static final boolean gtk_widget_get_child_visible(int paramInt)
  {
    lock.lock();
    try
    {
      boolean bool = _gtk_widget_get_child_visible(paramInt);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_widget_get_default_style();
  
  public static final int gtk_widget_get_default_style()
  {
    lock.lock();
    try
    {
      int i = _gtk_widget_get_default_style();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_widget_get_events(int paramInt);
  
  public static final int gtk_widget_get_events(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_widget_get_events(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_widget_get_window(int paramInt);
  
  public static final int gtk_widget_get_window(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_widget_get_window(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_widget_get_modifier_style(int paramInt);
  
  public static final int gtk_widget_get_modifier_style(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_widget_get_modifier_style(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _gtk_widget_get_mapped(int paramInt);
  
  public static final boolean gtk_widget_get_mapped(int paramInt)
  {
    lock.lock();
    try
    {
      boolean bool = _gtk_widget_get_mapped(paramInt);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_widget_get_pango_context(int paramInt);
  
  public static final int gtk_widget_get_pango_context(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_widget_get_pango_context(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_widget_get_parent(int paramInt);
  
  public static final int gtk_widget_get_parent(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_widget_get_parent(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_widget_get_parent_window(int paramInt);
  
  public static final int gtk_widget_get_parent_window(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_widget_get_parent_window(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_widget_get_allocation(int paramInt, GtkAllocation paramGtkAllocation);
  
  public static final void gtk_widget_get_allocation(int paramInt, GtkAllocation paramGtkAllocation)
  {
    lock.lock();
    try
    {
      _gtk_widget_get_allocation(paramInt, paramGtkAllocation);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_render_handle(int paramInt1, int paramInt2, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4);
  
  public static final void gtk_render_handle(int paramInt1, int paramInt2, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4)
  {
    lock.lock();
    try
    {
      _gtk_render_handle(paramInt1, paramInt2, paramDouble1, paramDouble2, paramDouble3, paramDouble4);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_widget_get_style_context(int paramInt);
  
  public static final int gtk_widget_get_style_context(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_widget_get_style_context(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_widget_get_style(int paramInt);
  
  public static final int gtk_widget_get_style(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_widget_get_style(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_widget_get_size_request(int paramInt, int[] paramArrayOfInt1, int[] paramArrayOfInt2);
  
  public static final void gtk_widget_get_size_request(int paramInt, int[] paramArrayOfInt1, int[] paramArrayOfInt2)
  {
    lock.lock();
    try
    {
      _gtk_widget_get_size_request(paramInt, paramArrayOfInt1, paramArrayOfInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_widget_get_toplevel(int paramInt);
  
  public static final int gtk_widget_get_toplevel(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_widget_get_toplevel(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_widget_get_tooltip_text(int paramInt);
  
  public static final int gtk_widget_get_tooltip_text(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_widget_get_tooltip_text(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_widget_grab_focus(int paramInt);
  
  public static final void gtk_widget_grab_focus(int paramInt)
  {
    lock.lock();
    try
    {
      _gtk_widget_grab_focus(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _gtk_widget_has_focus(int paramInt);
  
  public static final boolean gtk_widget_has_focus(int paramInt)
  {
    lock.lock();
    try
    {
      boolean bool = _gtk_widget_has_focus(paramInt);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_widget_hide(int paramInt);
  
  public static final void gtk_widget_hide(int paramInt)
  {
    lock.lock();
    try
    {
      _gtk_widget_hide(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_widget_input_shape_combine_region(int paramInt1, int paramInt2);
  
  public static final void gtk_widget_input_shape_combine_region(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_widget_input_shape_combine_region(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _gtk_widget_is_composited(int paramInt);
  
  public static final boolean gtk_widget_is_composited(int paramInt)
  {
    lock.lock();
    try
    {
      boolean bool = _gtk_widget_is_composited(paramInt);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _gtk_widget_is_focus(int paramInt);
  
  public static final boolean gtk_widget_is_focus(int paramInt)
  {
    lock.lock();
    try
    {
      boolean bool = _gtk_widget_is_focus(paramInt);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_widget_map(int paramInt);
  
  public static final void gtk_widget_map(int paramInt)
  {
    lock.lock();
    try
    {
      _gtk_widget_map(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _gtk_widget_mnemonic_activate(int paramInt, boolean paramBoolean);
  
  public static final boolean gtk_widget_mnemonic_activate(int paramInt, boolean paramBoolean)
  {
    lock.lock();
    try
    {
      boolean bool = _gtk_widget_mnemonic_activate(paramInt, paramBoolean);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_widget_modify_base(int paramInt1, int paramInt2, GdkColor paramGdkColor);
  
  public static final void gtk_widget_modify_base(int paramInt1, int paramInt2, GdkColor paramGdkColor)
  {
    lock.lock();
    try
    {
      _gtk_widget_modify_base(paramInt1, paramInt2, paramGdkColor);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_widget_modify_bg(int paramInt1, int paramInt2, GdkColor paramGdkColor);
  
  public static final void gtk_widget_modify_bg(int paramInt1, int paramInt2, GdkColor paramGdkColor)
  {
    lock.lock();
    try
    {
      _gtk_widget_modify_bg(paramInt1, paramInt2, paramGdkColor);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_widget_modify_font(int paramInt1, int paramInt2);
  
  public static final void gtk_widget_modify_font(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_widget_modify_font(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_widget_modify_style(int paramInt1, int paramInt2);
  
  public static final void gtk_widget_modify_style(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_widget_modify_style(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_widget_override_color(int paramInt1, int paramInt2, GdkRGBA paramGdkRGBA);
  
  public static final void gtk_widget_override_color(int paramInt1, int paramInt2, GdkRGBA paramGdkRGBA)
  {
    lock.lock();
    try
    {
      _gtk_widget_override_color(paramInt1, paramInt2, paramGdkRGBA);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_widget_override_background_color(int paramInt1, int paramInt2, GdkRGBA paramGdkRGBA);
  
  public static final void gtk_widget_override_background_color(int paramInt1, int paramInt2, GdkRGBA paramGdkRGBA)
  {
    lock.lock();
    try
    {
      _gtk_widget_override_background_color(paramInt1, paramInt2, paramGdkRGBA);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_widget_override_font(int paramInt1, int paramInt2);
  
  public static final void gtk_widget_override_font(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_widget_override_font(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_widget_queue_resize(int paramInt);
  
  public static final void gtk_widget_queue_resize(int paramInt)
  {
    lock.lock();
    try
    {
      _gtk_widget_queue_resize(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_widget_realize(int paramInt);
  
  public static final void gtk_widget_realize(int paramInt)
  {
    lock.lock();
    try
    {
      _gtk_widget_realize(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_widget_remove_accelerator(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  public static final void gtk_widget_remove_accelerator(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    lock.lock();
    try
    {
      _gtk_widget_remove_accelerator(paramInt1, paramInt2, paramInt3, paramInt4);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_widget_reparent(int paramInt1, int paramInt2);
  
  public static final void gtk_widget_reparent(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_widget_reparent(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_widget_send_expose(int paramInt1, int paramInt2);
  
  public static final int gtk_widget_send_expose(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      int i = _gtk_widget_send_expose(paramInt1, paramInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_widget_set_app_paintable(int paramInt, boolean paramBoolean);
  
  public static final void gtk_widget_set_app_paintable(int paramInt, boolean paramBoolean)
  {
    lock.lock();
    try
    {
      _gtk_widget_set_app_paintable(paramInt, paramBoolean);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_widget_set_default_direction(int paramInt);
  
  public static final void gtk_widget_set_default_direction(int paramInt)
  {
    lock.lock();
    try
    {
      _gtk_widget_set_default_direction(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_widget_set_can_default(int paramInt, boolean paramBoolean);
  
  public static final void gtk_widget_set_can_default(int paramInt, boolean paramBoolean)
  {
    lock.lock();
    try
    {
      _gtk_widget_set_can_default(paramInt, paramBoolean);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _gtk_widget_set_can_focus(int paramInt, boolean paramBoolean);
  
  public static final boolean gtk_widget_set_can_focus(int paramInt, boolean paramBoolean)
  {
    lock.lock();
    try
    {
      boolean bool = _gtk_widget_set_can_focus(paramInt, paramBoolean);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_widget_set_mapped(int paramInt, boolean paramBoolean);
  
  public static final void gtk_widget_set_mapped(int paramInt, boolean paramBoolean)
  {
    lock.lock();
    try
    {
      _gtk_widget_set_mapped(paramInt, paramBoolean);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_widget_set_visible(int paramInt, boolean paramBoolean);
  
  public static final void gtk_widget_set_visible(int paramInt, boolean paramBoolean)
  {
    lock.lock();
    try
    {
      _gtk_widget_set_visible(paramInt, paramBoolean);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_widget_set_direction(int paramInt1, int paramInt2);
  
  public static final void gtk_widget_set_direction(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_widget_set_direction(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_widget_set_receives_default(int paramInt, boolean paramBoolean);
  
  public static final void gtk_widget_set_receives_default(int paramInt, boolean paramBoolean)
  {
    lock.lock();
    try
    {
      _gtk_widget_set_receives_default(paramInt, paramBoolean);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_widget_set_double_buffered(int paramInt, boolean paramBoolean);
  
  public static final void gtk_widget_set_double_buffered(int paramInt, boolean paramBoolean)
  {
    lock.lock();
    try
    {
      _gtk_widget_set_double_buffered(paramInt, paramBoolean);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_widget_set_name(int paramInt, byte[] paramArrayOfByte);
  
  public static final void gtk_widget_set_name(int paramInt, byte[] paramArrayOfByte)
  {
    lock.lock();
    try
    {
      _gtk_widget_set_name(paramInt, paramArrayOfByte);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_widget_set_redraw_on_allocate(int paramInt, boolean paramBoolean);
  
  public static final void gtk_widget_set_redraw_on_allocate(int paramInt, boolean paramBoolean)
  {
    lock.lock();
    try
    {
      _gtk_widget_set_redraw_on_allocate(paramInt, paramBoolean);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_widget_set_sensitive(int paramInt, boolean paramBoolean);
  
  public static final void gtk_widget_set_sensitive(int paramInt, boolean paramBoolean)
  {
    lock.lock();
    try
    {
      _gtk_widget_set_sensitive(paramInt, paramBoolean);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_widget_set_size_request(int paramInt1, int paramInt2, int paramInt3);
  
  public static final void gtk_widget_set_size_request(int paramInt1, int paramInt2, int paramInt3)
  {
    lock.lock();
    try
    {
      _gtk_widget_set_size_request(paramInt1, paramInt2, paramInt3);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_widget_set_state(int paramInt1, int paramInt2);
  
  public static final void gtk_widget_set_state(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_widget_set_state(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_widget_show(int paramInt);
  
  public static final void gtk_widget_show(int paramInt)
  {
    lock.lock();
    try
    {
      _gtk_widget_show(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_widget_size_allocate(int paramInt, GtkAllocation paramGtkAllocation);
  
  public static final void gtk_widget_size_allocate(int paramInt, GtkAllocation paramGtkAllocation)
  {
    lock.lock();
    try
    {
      _gtk_widget_size_allocate(paramInt, paramGtkAllocation);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_widget_size_request(int paramInt, GtkRequisition paramGtkRequisition);
  
  public static final void gtk_widget_size_request(int paramInt, GtkRequisition paramGtkRequisition)
  {
    lock.lock();
    try
    {
      _gtk_widget_size_request(paramInt, paramGtkRequisition);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_widget_set_allocation(int paramInt, GtkAllocation paramGtkAllocation);
  
  public static final void gtk_widget_set_allocation(int paramInt, GtkAllocation paramGtkAllocation)
  {
    lock.lock();
    try
    {
      _gtk_widget_set_allocation(paramInt, paramGtkAllocation);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_widget_style_get(int paramInt1, byte[] paramArrayOfByte, int[] paramArrayOfInt, int paramInt2);
  
  public static final void gtk_widget_style_get(int paramInt1, byte[] paramArrayOfByte, int[] paramArrayOfInt, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_widget_style_get(paramInt1, paramArrayOfByte, paramArrayOfInt, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_widget_style_get(int paramInt1, byte[] paramArrayOfByte, long[] paramArrayOfLong, int paramInt2);
  
  public static final void gtk_widget_style_get(int paramInt1, byte[] paramArrayOfByte, long[] paramArrayOfLong, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_widget_style_get(paramInt1, paramArrayOfByte, paramArrayOfLong, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _gtk_widget_translate_coordinates(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int[] paramArrayOfInt1, int[] paramArrayOfInt2);
  
  public static final boolean gtk_widget_translate_coordinates(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int[] paramArrayOfInt1, int[] paramArrayOfInt2)
  {
    lock.lock();
    try
    {
      boolean bool = _gtk_widget_translate_coordinates(paramInt1, paramInt2, paramInt3, paramInt4, paramArrayOfInt1, paramArrayOfInt2);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _gtk_window_activate_default(int paramInt);
  
  public static final boolean gtk_window_activate_default(int paramInt)
  {
    lock.lock();
    try
    {
      boolean bool = _gtk_window_activate_default(paramInt);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_window_add_accel_group(int paramInt1, int paramInt2);
  
  public static final void gtk_window_add_accel_group(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_window_add_accel_group(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_window_deiconify(int paramInt);
  
  public static final void gtk_window_deiconify(int paramInt)
  {
    lock.lock();
    try
    {
      _gtk_window_deiconify(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_window_get_focus(int paramInt);
  
  public static final int gtk_window_get_focus(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_window_get_focus(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_window_get_group(int paramInt);
  
  public static final int gtk_window_get_group(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_window_get_group(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_window_get_icon_list(int paramInt);
  
  public static final int gtk_window_get_icon_list(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_window_get_icon_list(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _gtk_window_get_modal(int paramInt);
  
  public static final boolean gtk_window_get_modal(int paramInt)
  {
    lock.lock();
    try
    {
      boolean bool = _gtk_window_get_modal(paramInt);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_window_get_mnemonic_modifier(int paramInt);
  
  public static final int gtk_window_get_mnemonic_modifier(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_window_get_mnemonic_modifier(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native double _gtk_window_get_opacity(int paramInt);
  
  public static final double gtk_window_get_opacity(int paramInt)
  {
    lock.lock();
    try
    {
      double d = _gtk_window_get_opacity(paramInt);
      return d;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_window_get_position(int paramInt, int[] paramArrayOfInt1, int[] paramArrayOfInt2);
  
  public static final void gtk_window_get_position(int paramInt, int[] paramArrayOfInt1, int[] paramArrayOfInt2)
  {
    lock.lock();
    try
    {
      _gtk_window_get_position(paramInt, paramArrayOfInt1, paramArrayOfInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_window_group_add_window(int paramInt1, int paramInt2);
  
  public static final void gtk_window_group_add_window(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_window_group_add_window(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_window_group_remove_window(int paramInt1, int paramInt2);
  
  public static final void gtk_window_group_remove_window(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_window_group_remove_window(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_window_group_new();
  
  public static final int gtk_window_group_new()
  {
    lock.lock();
    try
    {
      int i = _gtk_window_group_new();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _gtk_window_is_active(int paramInt);
  
  public static final boolean gtk_window_is_active(int paramInt)
  {
    lock.lock();
    try
    {
      boolean bool = _gtk_window_is_active(paramInt);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_window_iconify(int paramInt);
  
  public static final void gtk_window_iconify(int paramInt)
  {
    lock.lock();
    try
    {
      _gtk_window_iconify(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_window_list_toplevels();
  
  public static final int gtk_window_list_toplevels()
  {
    lock.lock();
    try
    {
      int i = _gtk_window_list_toplevels();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_window_maximize(int paramInt);
  
  public static final void gtk_window_maximize(int paramInt)
  {
    lock.lock();
    try
    {
      _gtk_window_maximize(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_window_fullscreen(int paramInt);
  
  public static final void gtk_window_fullscreen(int paramInt)
  {
    lock.lock();
    try
    {
      _gtk_window_fullscreen(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_window_unfullscreen(int paramInt);
  
  public static final void gtk_window_unfullscreen(int paramInt)
  {
    lock.lock();
    try
    {
      _gtk_window_unfullscreen(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_window_move(int paramInt1, int paramInt2, int paramInt3);
  
  public static final void gtk_window_move(int paramInt1, int paramInt2, int paramInt3)
  {
    lock.lock();
    try
    {
      _gtk_window_move(paramInt1, paramInt2, paramInt3);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gtk_window_new(int paramInt);
  
  public static final int gtk_window_new(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gtk_window_new(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_window_remove_accel_group(int paramInt1, int paramInt2);
  
  public static final void gtk_window_remove_accel_group(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_window_remove_accel_group(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_window_resize(int paramInt1, int paramInt2, int paramInt3);
  
  public static final void gtk_window_resize(int paramInt1, int paramInt2, int paramInt3)
  {
    lock.lock();
    try
    {
      _gtk_window_resize(paramInt1, paramInt2, paramInt3);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_window_set_default(int paramInt1, int paramInt2);
  
  public static final void gtk_window_set_default(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_window_set_default(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_window_set_destroy_with_parent(int paramInt, boolean paramBoolean);
  
  public static final void gtk_window_set_destroy_with_parent(int paramInt, boolean paramBoolean)
  {
    lock.lock();
    try
    {
      _gtk_window_set_destroy_with_parent(paramInt, paramBoolean);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_window_set_geometry_hints(int paramInt1, int paramInt2, GdkGeometry paramGdkGeometry, int paramInt3);
  
  public static final void gtk_window_set_geometry_hints(int paramInt1, int paramInt2, GdkGeometry paramGdkGeometry, int paramInt3)
  {
    lock.lock();
    try
    {
      _gtk_window_set_geometry_hints(paramInt1, paramInt2, paramGdkGeometry, paramInt3);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_window_set_icon_list(int paramInt1, int paramInt2);
  
  public static final void gtk_window_set_icon_list(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_window_set_icon_list(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_window_set_modal(int paramInt, boolean paramBoolean);
  
  public static final void gtk_window_set_modal(int paramInt, boolean paramBoolean)
  {
    lock.lock();
    try
    {
      _gtk_window_set_modal(paramInt, paramBoolean);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_window_set_opacity(int paramInt, double paramDouble);
  
  public static final void gtk_window_set_opacity(int paramInt, double paramDouble)
  {
    lock.lock();
    try
    {
      _gtk_window_set_opacity(paramInt, paramDouble);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_widget_set_tooltip_text(int paramInt, byte[] paramArrayOfByte);
  
  public static final void gtk_widget_set_tooltip_text(int paramInt, byte[] paramArrayOfByte)
  {
    lock.lock();
    try
    {
      _gtk_widget_set_tooltip_text(paramInt, paramArrayOfByte);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_widget_set_parent_window(int paramInt1, int paramInt2);
  
  public static final void gtk_widget_set_parent_window(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_widget_set_parent_window(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_window_set_resizable(int paramInt, boolean paramBoolean);
  
  public static final void gtk_window_set_resizable(int paramInt, boolean paramBoolean)
  {
    lock.lock();
    try
    {
      _gtk_window_set_resizable(paramInt, paramBoolean);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_window_set_title(int paramInt, byte[] paramArrayOfByte);
  
  public static final void gtk_window_set_title(int paramInt, byte[] paramArrayOfByte)
  {
    lock.lock();
    try
    {
      _gtk_window_set_title(paramInt, paramArrayOfByte);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_window_set_skip_taskbar_hint(int paramInt, boolean paramBoolean);
  
  public static final void gtk_window_set_skip_taskbar_hint(int paramInt, boolean paramBoolean)
  {
    lock.lock();
    try
    {
      _gtk_window_set_skip_taskbar_hint(paramInt, paramBoolean);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_window_set_type_hint(int paramInt1, int paramInt2);
  
  public static final void gtk_window_set_type_hint(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_window_set_type_hint(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_window_set_transient_for(int paramInt1, int paramInt2);
  
  public static final void gtk_window_set_transient_for(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _gtk_window_set_transient_for(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gtk_window_unmaximize(int paramInt);
  
  public static final void gtk_window_unmaximize(int paramInt)
  {
    lock.lock();
    try
    {
      _gtk_window_unmaximize(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void memmove(int paramInt1, GInterfaceInfo paramGInterfaceInfo, int paramInt2);
  
  public static final native void memmove(int paramInt, GObjectClass paramGObjectClass);
  
  public static final native void memmove(int paramInt1, GTypeInfo paramGTypeInfo, int paramInt2);
  
  public static final native void memmove(int paramInt1, GtkTargetEntry paramGtkTargetEntry, int paramInt2);
  
  public static final native void memmove(int paramInt, GtkAdjustment paramGtkAdjustment);
  
  public static final native void memmove(int paramInt1, GdkColor paramGdkColor, int paramInt2);
  
  public static final native void memmove(int paramInt1, GdkEventButton paramGdkEventButton, int paramInt2);
  
  public static final native void memmove(int paramInt1, GdkEventExpose paramGdkEventExpose, int paramInt2);
  
  public static final native void memmove(int paramInt1, GdkEventMotion paramGdkEventMotion, int paramInt2);
  
  public static final native void memmove(int paramInt, GtkWidgetClass paramGtkWidgetClass);
  
  public static final native void memmove(int paramInt1, PangoAttribute paramPangoAttribute, int paramInt2);
  
  public static final native void memmove(GObjectClass paramGObjectClass, int paramInt);
  
  public static final native void memmove(GTypeQuery paramGTypeQuery, int paramInt1, int paramInt2);
  
  public static final native void memmove(GtkColorSelectionDialog paramGtkColorSelectionDialog, int paramInt);
  
  public static final native void memmove(GdkEventProperty paramGdkEventProperty, int paramInt);
  
  public static final native void memmove(GdkDragContext paramGdkDragContext, int paramInt1, int paramInt2);
  
  public static final native void memmove(GtkSelectionData paramGtkSelectionData, int paramInt1, int paramInt2);
  
  public static final native void memmove(GtkWidgetClass paramGtkWidgetClass, int paramInt);
  
  public static final native void memmove(GtkAdjustment paramGtkAdjustment, int paramInt);
  
  public static final native void memmove(GtkBorder paramGtkBorder, int paramInt1, int paramInt2);
  
  public static final native void memmove(GdkColor paramGdkColor, int paramInt1, int paramInt2);
  
  public static final native void memmove(GdkEvent paramGdkEvent, int paramInt1, int paramInt2);
  
  public static final native void memmove(GdkEventAny paramGdkEventAny, int paramInt1, int paramInt2);
  
  public static final native void memmove(GdkEventButton paramGdkEventButton, int paramInt1, int paramInt2);
  
  public static final native void memmove(GdkEventCrossing paramGdkEventCrossing, int paramInt1, int paramInt2);
  
  public static final native void memmove(GdkEventExpose paramGdkEventExpose, int paramInt1, int paramInt2);
  
  public static final native void memmove(GdkEventFocus paramGdkEventFocus, int paramInt1, int paramInt2);
  
  public static final native void memmove(GdkEventKey paramGdkEventKey, int paramInt1, int paramInt2);
  
  public static final native void memmove(GdkEventMotion paramGdkEventMotion, int paramInt1, int paramInt2);
  
  public static final native void memmove(GdkEventScroll paramGdkEventScroll, int paramInt1, int paramInt2);
  
  public static final native void memmove(GdkEventVisibility paramGdkEventVisibility, int paramInt1, int paramInt2);
  
  public static final native void memmove(GdkEventWindowState paramGdkEventWindowState, int paramInt1, int paramInt2);
  
  public static final native void memmove(int paramInt, GtkCellRendererClass paramGtkCellRendererClass);
  
  public static final native void memmove(GtkCellRendererClass paramGtkCellRendererClass, int paramInt);
  
  public static final native void memmove(GtkFixed paramGtkFixed, int paramInt);
  
  public static final native void memmove(int paramInt, GtkFixed paramGtkFixed);
  
  public static final native void memmove(GdkVisual paramGdkVisual, int paramInt);
  
  public static final native void memmove(GdkImage paramGdkImage, int paramInt);
  
  public static final native void memmove(GdkRectangle paramGdkRectangle, int paramInt1, int paramInt2);
  
  public static final native void memmove(PangoAttribute paramPangoAttribute, int paramInt1, int paramInt2);
  
  public static final native void memmove(PangoAttrColor paramPangoAttrColor, int paramInt1, int paramInt2);
  
  public static final native void memmove(PangoAttrInt paramPangoAttrInt, int paramInt1, int paramInt2);
  
  public static final native void memmove(PangoItem paramPangoItem, int paramInt1, int paramInt2);
  
  public static final native void memmove(PangoLayoutLine paramPangoLayoutLine, int paramInt1, int paramInt2);
  
  public static final native void memmove(PangoLayoutRun paramPangoLayoutRun, int paramInt1, int paramInt2);
  
  public static final native void memmove(PangoLogAttr paramPangoLogAttr, int paramInt1, int paramInt2);
  
  public static final native int _pango_attribute_copy(int paramInt);
  
  public static final int pango_attribute_copy(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _pango_attribute_copy(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _pango_attr_background_new(short paramShort1, short paramShort2, short paramShort3);
  
  public static final int pango_attr_background_new(short paramShort1, short paramShort2, short paramShort3)
  {
    lock.lock();
    try
    {
      int i = _pango_attr_background_new(paramShort1, paramShort2, paramShort3);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _pango_attr_font_desc_new(int paramInt);
  
  public static final int pango_attr_font_desc_new(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _pango_attr_font_desc_new(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _pango_attr_foreground_new(short paramShort1, short paramShort2, short paramShort3);
  
  public static final int pango_attr_foreground_new(short paramShort1, short paramShort2, short paramShort3)
  {
    lock.lock();
    try
    {
      int i = _pango_attr_foreground_new(paramShort1, paramShort2, paramShort3);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _pango_attr_rise_new(int paramInt);
  
  public static final int pango_attr_rise_new(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _pango_attr_rise_new(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _pango_attr_shape_new(PangoRectangle paramPangoRectangle1, PangoRectangle paramPangoRectangle2);
  
  public static final int pango_attr_shape_new(PangoRectangle paramPangoRectangle1, PangoRectangle paramPangoRectangle2)
  {
    lock.lock();
    try
    {
      int i = _pango_attr_shape_new(paramPangoRectangle1, paramPangoRectangle2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _pango_attr_list_insert(int paramInt1, int paramInt2);
  
  public static final void pango_attr_list_insert(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _pango_attr_list_insert(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _pango_attr_list_change(int paramInt1, int paramInt2);
  
  public static final void pango_attr_list_change(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _pango_attr_list_change(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _pango_attr_list_get_iterator(int paramInt);
  
  public static final int pango_attr_list_get_iterator(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _pango_attr_list_get_iterator(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _pango_attr_iterator_next(int paramInt);
  
  public static final boolean pango_attr_iterator_next(int paramInt)
  {
    lock.lock();
    try
    {
      boolean bool = _pango_attr_iterator_next(paramInt);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _pango_attr_iterator_range(int paramInt, int[] paramArrayOfInt1, int[] paramArrayOfInt2);
  
  public static final void pango_attr_iterator_range(int paramInt, int[] paramArrayOfInt1, int[] paramArrayOfInt2)
  {
    lock.lock();
    try
    {
      _pango_attr_iterator_range(paramInt, paramArrayOfInt1, paramArrayOfInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _pango_attr_iterator_get(int paramInt1, int paramInt2);
  
  public static final int pango_attr_iterator_get(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      int i = _pango_attr_iterator_get(paramInt1, paramInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _pango_attr_iterator_get_attrs(int paramInt);
  
  public static final int pango_attr_iterator_get_attrs(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _pango_attr_iterator_get_attrs(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _pango_attr_iterator_destroy(int paramInt);
  
  public static final void pango_attr_iterator_destroy(int paramInt)
  {
    lock.lock();
    try
    {
      _pango_attr_iterator_destroy(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _pango_attr_list_new();
  
  public static final int pango_attr_list_new()
  {
    lock.lock();
    try
    {
      int i = _pango_attr_list_new();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _pango_attr_list_unref(int paramInt);
  
  public static final void pango_attr_list_unref(int paramInt)
  {
    lock.lock();
    try
    {
      _pango_attr_list_unref(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _pango_attr_strikethrough_color_new(short paramShort1, short paramShort2, short paramShort3);
  
  public static final int pango_attr_strikethrough_color_new(short paramShort1, short paramShort2, short paramShort3)
  {
    lock.lock();
    try
    {
      int i = _pango_attr_strikethrough_color_new(paramShort1, paramShort2, paramShort3);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _pango_attr_strikethrough_new(boolean paramBoolean);
  
  public static final int pango_attr_strikethrough_new(boolean paramBoolean)
  {
    lock.lock();
    try
    {
      int i = _pango_attr_strikethrough_new(paramBoolean);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _pango_attr_underline_color_new(short paramShort1, short paramShort2, short paramShort3);
  
  public static final int pango_attr_underline_color_new(short paramShort1, short paramShort2, short paramShort3)
  {
    lock.lock();
    try
    {
      int i = _pango_attr_underline_color_new(paramShort1, paramShort2, paramShort3);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _pango_attr_underline_new(int paramInt);
  
  public static final int pango_attr_underline_new(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _pango_attr_underline_new(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _pango_attr_weight_new(int paramInt);
  
  public static final int pango_attr_weight_new(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _pango_attr_weight_new(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _pango_cairo_font_map_get_default();
  
  public static final int pango_cairo_font_map_get_default()
  {
    lock.lock();
    try
    {
      int i = _pango_cairo_font_map_get_default();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _pango_cairo_font_map_new();
  
  public static final int pango_cairo_font_map_new()
  {
    lock.lock();
    try
    {
      int i = _pango_cairo_font_map_new();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _pango_cairo_font_map_create_context(int paramInt);
  
  public static final int pango_cairo_font_map_create_context(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _pango_cairo_font_map_create_context(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _pango_cairo_create_layout(int paramInt);
  
  public static final int pango_cairo_create_layout(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _pango_cairo_create_layout(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _pango_cairo_context_get_font_options(int paramInt);
  
  public static final int pango_cairo_context_get_font_options(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _pango_cairo_context_get_font_options(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _pango_cairo_context_set_font_options(int paramInt1, int paramInt2);
  
  public static final void pango_cairo_context_set_font_options(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _pango_cairo_context_set_font_options(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _pango_cairo_font_map_set_resolution(int paramInt, double paramDouble);
  
  public static final void pango_cairo_font_map_set_resolution(int paramInt, double paramDouble)
  {
    lock.lock();
    try
    {
      _pango_cairo_font_map_set_resolution(paramInt, paramDouble);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _pango_cairo_layout_path(int paramInt1, int paramInt2);
  
  public static final void pango_cairo_layout_path(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _pango_cairo_layout_path(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _pango_cairo_show_layout(int paramInt1, int paramInt2);
  
  public static final void pango_cairo_show_layout(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _pango_cairo_show_layout(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _pango_context_get_base_dir(int paramInt);
  
  public static final int pango_context_get_base_dir(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _pango_context_get_base_dir(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _pango_context_get_language(int paramInt);
  
  public static final int pango_context_get_language(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _pango_context_get_language(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _pango_context_get_metrics(int paramInt1, int paramInt2, int paramInt3);
  
  public static final int pango_context_get_metrics(int paramInt1, int paramInt2, int paramInt3)
  {
    lock.lock();
    try
    {
      int i = _pango_context_get_metrics(paramInt1, paramInt2, paramInt3);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _pango_context_list_families(int paramInt, int[] paramArrayOfInt1, int[] paramArrayOfInt2);
  
  public static final void pango_context_list_families(int paramInt, int[] paramArrayOfInt1, int[] paramArrayOfInt2)
  {
    lock.lock();
    try
    {
      _pango_context_list_families(paramInt, paramArrayOfInt1, paramArrayOfInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _pango_context_set_base_dir(int paramInt1, int paramInt2);
  
  public static final void pango_context_set_base_dir(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _pango_context_set_base_dir(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _pango_context_set_language(int paramInt1, int paramInt2);
  
  public static final void pango_context_set_language(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _pango_context_set_language(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _pango_font_description_copy(int paramInt);
  
  public static final int pango_font_description_copy(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _pango_font_description_copy(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _pango_font_description_free(int paramInt);
  
  public static final void pango_font_description_free(int paramInt)
  {
    lock.lock();
    try
    {
      _pango_font_description_free(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _pango_font_description_from_string(byte[] paramArrayOfByte);
  
  public static final int pango_font_description_from_string(byte[] paramArrayOfByte)
  {
    lock.lock();
    try
    {
      int i = _pango_font_description_from_string(paramArrayOfByte);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _pango_font_description_get_family(int paramInt);
  
  public static final int pango_font_description_get_family(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _pango_font_description_get_family(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _pango_font_description_get_size(int paramInt);
  
  public static final int pango_font_description_get_size(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _pango_font_description_get_size(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _pango_font_description_get_stretch(int paramInt);
  
  public static final int pango_font_description_get_stretch(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _pango_font_description_get_stretch(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _pango_font_description_get_variant(int paramInt);
  
  public static final int pango_font_description_get_variant(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _pango_font_description_get_variant(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _pango_font_description_get_style(int paramInt);
  
  public static final int pango_font_description_get_style(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _pango_font_description_get_style(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _pango_font_description_get_weight(int paramInt);
  
  public static final int pango_font_description_get_weight(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _pango_font_description_get_weight(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _pango_font_description_new();
  
  public static final int pango_font_description_new()
  {
    lock.lock();
    try
    {
      int i = _pango_font_description_new();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _pango_font_description_set_family(int paramInt, byte[] paramArrayOfByte);
  
  public static final void pango_font_description_set_family(int paramInt, byte[] paramArrayOfByte)
  {
    lock.lock();
    try
    {
      _pango_font_description_set_family(paramInt, paramArrayOfByte);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _pango_font_description_set_size(int paramInt1, int paramInt2);
  
  public static final void pango_font_description_set_size(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _pango_font_description_set_size(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _pango_font_description_set_stretch(int paramInt1, int paramInt2);
  
  public static final void pango_font_description_set_stretch(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _pango_font_description_set_stretch(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _pango_font_description_set_style(int paramInt1, int paramInt2);
  
  public static final void pango_font_description_set_style(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _pango_font_description_set_style(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _pango_font_description_set_weight(int paramInt1, int paramInt2);
  
  public static final void pango_font_description_set_weight(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _pango_font_description_set_weight(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _pango_font_description_set_variant(int paramInt1, int paramInt2);
  
  public static final void pango_font_description_set_variant(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _pango_font_description_set_variant(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _pango_font_description_to_string(int paramInt);
  
  public static final int pango_font_description_to_string(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _pango_font_description_to_string(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _pango_font_face_describe(int paramInt);
  
  public static final int pango_font_face_describe(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _pango_font_face_describe(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _pango_font_family_get_name(int paramInt);
  
  public static final int pango_font_family_get_name(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _pango_font_family_get_name(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _pango_font_family_list_faces(int paramInt, int[] paramArrayOfInt1, int[] paramArrayOfInt2);
  
  public static final void pango_font_family_list_faces(int paramInt, int[] paramArrayOfInt1, int[] paramArrayOfInt2)
  {
    lock.lock();
    try
    {
      _pango_font_family_list_faces(paramInt, paramArrayOfInt1, paramArrayOfInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _pango_font_get_metrics(int paramInt1, int paramInt2);
  
  public static final int pango_font_get_metrics(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      int i = _pango_font_get_metrics(paramInt1, paramInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _pango_font_metrics_get_approximate_char_width(int paramInt);
  
  public static final int pango_font_metrics_get_approximate_char_width(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _pango_font_metrics_get_approximate_char_width(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _pango_font_metrics_get_ascent(int paramInt);
  
  public static final int pango_font_metrics_get_ascent(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _pango_font_metrics_get_ascent(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _pango_font_metrics_get_descent(int paramInt);
  
  public static final int pango_font_metrics_get_descent(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _pango_font_metrics_get_descent(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _pango_font_metrics_get_underline_thickness(int paramInt);
  
  public static final int pango_font_metrics_get_underline_thickness(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _pango_font_metrics_get_underline_thickness(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _pango_font_metrics_get_underline_position(int paramInt);
  
  public static final int pango_font_metrics_get_underline_position(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _pango_font_metrics_get_underline_position(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _pango_font_metrics_get_strikethrough_thickness(int paramInt);
  
  public static final int pango_font_metrics_get_strikethrough_thickness(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _pango_font_metrics_get_strikethrough_thickness(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _pango_font_metrics_get_strikethrough_position(int paramInt);
  
  public static final int pango_font_metrics_get_strikethrough_position(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _pango_font_metrics_get_strikethrough_position(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _pango_font_metrics_unref(int paramInt);
  
  public static final void pango_font_metrics_unref(int paramInt)
  {
    lock.lock();
    try
    {
      _pango_font_metrics_unref(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _pango_language_from_string(byte[] paramArrayOfByte);
  
  public static final int pango_language_from_string(byte[] paramArrayOfByte)
  {
    lock.lock();
    try
    {
      int i = _pango_language_from_string(paramArrayOfByte);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _pango_layout_context_changed(int paramInt);
  
  public static final void pango_layout_context_changed(int paramInt)
  {
    lock.lock();
    try
    {
      _pango_layout_context_changed(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _pango_layout_get_alignment(int paramInt);
  
  public static final int pango_layout_get_alignment(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _pango_layout_get_alignment(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _pango_layout_get_context(int paramInt);
  
  public static final int pango_layout_get_context(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _pango_layout_get_context(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _pango_layout_get_attributes(int paramInt);
  
  public static final int pango_layout_get_attributes(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _pango_layout_get_attributes(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _pango_layout_get_indent(int paramInt);
  
  public static final int pango_layout_get_indent(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _pango_layout_get_indent(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _pango_layout_get_iter(int paramInt);
  
  public static final int pango_layout_get_iter(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _pango_layout_get_iter(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _pango_layout_get_justify(int paramInt);
  
  public static final boolean pango_layout_get_justify(int paramInt)
  {
    lock.lock();
    try
    {
      boolean bool = _pango_layout_get_justify(paramInt);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _pango_layout_get_line(int paramInt1, int paramInt2);
  
  public static final int pango_layout_get_line(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      int i = _pango_layout_get_line(paramInt1, paramInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _pango_layout_get_line_count(int paramInt);
  
  public static final int pango_layout_get_line_count(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _pango_layout_get_line_count(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _pango_layout_get_log_attrs(int paramInt, int[] paramArrayOfInt1, int[] paramArrayOfInt2);
  
  public static final void pango_layout_get_log_attrs(int paramInt, int[] paramArrayOfInt1, int[] paramArrayOfInt2)
  {
    lock.lock();
    try
    {
      _pango_layout_get_log_attrs(paramInt, paramArrayOfInt1, paramArrayOfInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _pango_layout_get_size(int paramInt, int[] paramArrayOfInt1, int[] paramArrayOfInt2);
  
  public static final void pango_layout_get_size(int paramInt, int[] paramArrayOfInt1, int[] paramArrayOfInt2)
  {
    lock.lock();
    try
    {
      _pango_layout_get_size(paramInt, paramArrayOfInt1, paramArrayOfInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _pango_layout_get_pixel_size(int paramInt, int[] paramArrayOfInt1, int[] paramArrayOfInt2);
  
  public static final void pango_layout_get_pixel_size(int paramInt, int[] paramArrayOfInt1, int[] paramArrayOfInt2)
  {
    lock.lock();
    try
    {
      _pango_layout_get_pixel_size(paramInt, paramArrayOfInt1, paramArrayOfInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _pango_layout_get_spacing(int paramInt);
  
  public static final int pango_layout_get_spacing(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _pango_layout_get_spacing(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _pango_layout_get_tabs(int paramInt);
  
  public static final int pango_layout_get_tabs(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _pango_layout_get_tabs(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _pango_layout_get_text(int paramInt);
  
  public static final int pango_layout_get_text(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _pango_layout_get_text(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _pango_layout_get_width(int paramInt);
  
  public static final int pango_layout_get_width(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _pango_layout_get_width(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _pango_layout_index_to_pos(int paramInt1, int paramInt2, PangoRectangle paramPangoRectangle);
  
  public static final void pango_layout_index_to_pos(int paramInt1, int paramInt2, PangoRectangle paramPangoRectangle)
  {
    lock.lock();
    try
    {
      _pango_layout_index_to_pos(paramInt1, paramInt2, paramPangoRectangle);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _pango_layout_iter_free(int paramInt);
  
  public static final void pango_layout_iter_free(int paramInt)
  {
    lock.lock();
    try
    {
      _pango_layout_iter_free(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _pango_layout_iter_get_line_extents(int paramInt, PangoRectangle paramPangoRectangle1, PangoRectangle paramPangoRectangle2);
  
  public static final void pango_layout_iter_get_line_extents(int paramInt, PangoRectangle paramPangoRectangle1, PangoRectangle paramPangoRectangle2)
  {
    lock.lock();
    try
    {
      _pango_layout_iter_get_line_extents(paramInt, paramPangoRectangle1, paramPangoRectangle2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _pango_layout_iter_get_index(int paramInt);
  
  public static final int pango_layout_iter_get_index(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _pango_layout_iter_get_index(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _pango_layout_iter_get_run(int paramInt);
  
  public static final int pango_layout_iter_get_run(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _pango_layout_iter_get_run(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _pango_layout_iter_next_line(int paramInt);
  
  public static final boolean pango_layout_iter_next_line(int paramInt)
  {
    lock.lock();
    try
    {
      boolean bool = _pango_layout_iter_next_line(paramInt);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _pango_layout_iter_next_run(int paramInt);
  
  public static final boolean pango_layout_iter_next_run(int paramInt)
  {
    lock.lock();
    try
    {
      boolean bool = _pango_layout_iter_next_run(paramInt);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _pango_layout_line_get_extents(int paramInt, PangoRectangle paramPangoRectangle1, PangoRectangle paramPangoRectangle2);
  
  public static final void pango_layout_line_get_extents(int paramInt, PangoRectangle paramPangoRectangle1, PangoRectangle paramPangoRectangle2)
  {
    lock.lock();
    try
    {
      _pango_layout_line_get_extents(paramInt, paramPangoRectangle1, paramPangoRectangle2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _pango_layout_line_x_to_index(int paramInt1, int paramInt2, int[] paramArrayOfInt1, int[] paramArrayOfInt2);
  
  public static final boolean pango_layout_line_x_to_index(int paramInt1, int paramInt2, int[] paramArrayOfInt1, int[] paramArrayOfInt2)
  {
    lock.lock();
    try
    {
      boolean bool = _pango_layout_line_x_to_index(paramInt1, paramInt2, paramArrayOfInt1, paramArrayOfInt2);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _pango_layout_new(int paramInt);
  
  public static final int pango_layout_new(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _pango_layout_new(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _pango_layout_set_alignment(int paramInt1, int paramInt2);
  
  public static final void pango_layout_set_alignment(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _pango_layout_set_alignment(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _pango_layout_set_attributes(int paramInt1, int paramInt2);
  
  public static final void pango_layout_set_attributes(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _pango_layout_set_attributes(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _pango_layout_set_auto_dir(int paramInt, boolean paramBoolean);
  
  public static final void pango_layout_set_auto_dir(int paramInt, boolean paramBoolean)
  {
    lock.lock();
    try
    {
      _pango_layout_set_auto_dir(paramInt, paramBoolean);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _pango_layout_set_font_description(int paramInt1, int paramInt2);
  
  public static final void pango_layout_set_font_description(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _pango_layout_set_font_description(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _pango_layout_set_indent(int paramInt1, int paramInt2);
  
  public static final void pango_layout_set_indent(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _pango_layout_set_indent(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _pango_layout_set_justify(int paramInt, boolean paramBoolean);
  
  public static final void pango_layout_set_justify(int paramInt, boolean paramBoolean)
  {
    lock.lock();
    try
    {
      _pango_layout_set_justify(paramInt, paramBoolean);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _pango_layout_set_single_paragraph_mode(int paramInt, boolean paramBoolean);
  
  public static final void pango_layout_set_single_paragraph_mode(int paramInt, boolean paramBoolean)
  {
    lock.lock();
    try
    {
      _pango_layout_set_single_paragraph_mode(paramInt, paramBoolean);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _pango_layout_set_spacing(int paramInt1, int paramInt2);
  
  public static final void pango_layout_set_spacing(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _pango_layout_set_spacing(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _pango_layout_set_tabs(int paramInt1, int paramInt2);
  
  public static final void pango_layout_set_tabs(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _pango_layout_set_tabs(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _pango_layout_set_text(int paramInt1, byte[] paramArrayOfByte, int paramInt2);
  
  public static final void pango_layout_set_text(int paramInt1, byte[] paramArrayOfByte, int paramInt2)
  {
    lock.lock();
    try
    {
      _pango_layout_set_text(paramInt1, paramArrayOfByte, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _pango_layout_set_width(int paramInt1, int paramInt2);
  
  public static final void pango_layout_set_width(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _pango_layout_set_width(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _pango_layout_set_wrap(int paramInt1, int paramInt2);
  
  public static final void pango_layout_set_wrap(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _pango_layout_set_wrap(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _pango_layout_xy_to_index(int paramInt1, int paramInt2, int paramInt3, int[] paramArrayOfInt1, int[] paramArrayOfInt2);
  
  public static final boolean pango_layout_xy_to_index(int paramInt1, int paramInt2, int paramInt3, int[] paramArrayOfInt1, int[] paramArrayOfInt2)
  {
    lock.lock();
    try
    {
      boolean bool = _pango_layout_xy_to_index(paramInt1, paramInt2, paramInt3, paramArrayOfInt1, paramArrayOfInt2);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _pango_tab_array_get_size(int paramInt);
  
  public static final int pango_tab_array_get_size(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _pango_tab_array_get_size(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _pango_tab_array_get_tabs(int paramInt, int[] paramArrayOfInt1, int[] paramArrayOfInt2);
  
  public static final void pango_tab_array_get_tabs(int paramInt, int[] paramArrayOfInt1, int[] paramArrayOfInt2)
  {
    lock.lock();
    try
    {
      _pango_tab_array_get_tabs(paramInt, paramArrayOfInt1, paramArrayOfInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _pango_tab_array_free(int paramInt);
  
  public static final void pango_tab_array_free(int paramInt)
  {
    lock.lock();
    try
    {
      _pango_tab_array_free(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _pango_tab_array_new(int paramInt, boolean paramBoolean);
  
  public static final int pango_tab_array_new(int paramInt, boolean paramBoolean)
  {
    lock.lock();
    try
    {
      int i = _pango_tab_array_new(paramInt, paramBoolean);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _pango_tab_array_set_tab(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  public static final void pango_tab_array_set_tab(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    lock.lock();
    try
    {
      _pango_tab_array_set_tab(paramInt1, paramInt2, paramInt3, paramInt4);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _ubuntu_menu_proxy_get();
  
  public static final int ubuntu_menu_proxy_get()
  {
    lock.lock();
    try
    {
      int i = _ubuntu_menu_proxy_get();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _atk_object_add_relationship(int paramInt1, int paramInt2, int paramInt3);
  
  public static final boolean atk_object_add_relationship(int paramInt1, int paramInt2, int paramInt3)
  {
    lock.lock();
    try
    {
      boolean bool = _atk_object_add_relationship(paramInt1, paramInt2, paramInt3);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _atk_object_remove_relationship(int paramInt1, int paramInt2, int paramInt3);
  
  public static final boolean atk_object_remove_relationship(int paramInt1, int paramInt2, int paramInt3)
  {
    lock.lock();
    try
    {
      boolean bool = _atk_object_remove_relationship(paramInt1, paramInt2, paramInt3);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _access(byte[] paramArrayOfByte, int paramInt);
  
  public static final int access(byte[] paramArrayOfByte, int paramInt)
  {
    lock.lock();
    try
    {
      int i = _access(paramArrayOfByte, paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int strcmp(int paramInt, byte[] paramArrayOfByte);
  
  public static final native int _swt_fixed_get_type();
  
  public static final int swt_fixed_get_type()
  {
    lock.lock();
    try
    {
      int i = _swt_fixed_get_type();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _swt_fixed_restack(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean);
  
  public static final void swt_fixed_restack(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean)
  {
    lock.lock();
    try
    {
      _swt_fixed_restack(paramInt1, paramInt2, paramInt3, paramBoolean);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _swt_fixed_move(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  public static final void swt_fixed_move(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    lock.lock();
    try
    {
      _swt_fixed_move(paramInt1, paramInt2, paramInt3, paramInt4);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _swt_fixed_resize(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  public static final void swt_fixed_resize(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    lock.lock();
    try
    {
      _swt_fixed_resize(paramInt1, paramInt2, paramInt3, paramInt4);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  static
  {
    String str = System.getProperty("SWT_GTK3");
    if (str == null)
    {
      int j = getenv(ascii("SWT_GTK3"));
      if (j != 0)
      {
        k = strlen(j);
        byte[] arrayOfByte1 = new byte[k];
        memmove(arrayOfByte1, j, k);
        char[] arrayOfChar = new char[arrayOfByte1.length];
        for (int m = 0; m < arrayOfByte1.length; m++) {
          arrayOfChar[m] = ((char)arrayOfByte1[m]);
        }
        str = new String(arrayOfChar);
      }
    }
    if ((str != null) && (str.equals("0"))) {
      Library.loadLibrary("swt-pi");
    } else {
      try
      {
        Library.loadLibrary("swt-pi3");
      }
      catch (Throwable localThrowable)
      {
        Library.loadLibrary("swt-pi");
      }
    }
    str = System.getProperty("os.name");
    boolean bool1 = false;
    int k = 0;
    boolean bool2 = false;
    boolean bool3 = false;
    if (str.equals("Linux")) {
      bool2 = true;
    }
    if (str.equals("AIX")) {
      bool1 = true;
    }
    if (str.equals("Solaris")) {
      k = 1;
    }
    if (str.equals("SunOS")) {
      k = 1;
    }
    if (str.equals("HP-UX")) {
      bool3 = true;
    }
    IsAIX = bool1;
    IsSunOS = k;
    IsLinux = bool2;
    IsHPUX = bool3;
    byte[] arrayOfByte2 = new byte[4];
    int n = malloc(4);
    memmove(n, new int[] { 1 }, 4);
    memmove(arrayOfByte2, n, 1);
    free(n);
    BIG_ENDIAN = arrayOfByte2[0] == 0;
    RTLD_GLOBAL = RTLD_GLOBAL();
    RTLD_LAZY = RTLD_LAZY();
    RTLD_NOW = RTLD_NOW();
    accel_closures_changed = ascii("accel-closures-changed");
    activate = ascii("activate");
    backspace = ascii("backspace");
    button_press_event = ascii("button-press-event");
    button_release_event = ascii("button-release-event");
    changed = ascii("changed");
    change_current_page = ascii("change-current-page");
    change_value = ascii("change-value");
    clicked = ascii("clicked");
    commit = ascii("commit");
    configure_event = ascii("configure-event");
    copy_clipboard = ascii("copy-clipboard");
    cut_clipboard = ascii("cut-clipboard");
    create_menu_proxy = ascii("create-menu-proxy");
    delete_event = ascii("delete-event");
    delete_from_cursor = ascii("delete-from-cursor");
    day_selected = ascii("day-selected");
    day_selected_double_click = ascii("day-selected-double-click");
    delete_range = ascii("delete-range");
    delete_text = ascii("delete-text");
    direction_changed = ascii("direction-changed");
    drag_data_delete = ascii("drag_data_delete");
    drag_data_get = ascii("drag_data_get");
    drag_data_received = ascii("drag_data_received");
    drag_drop = ascii("drag_drop");
    drag_end = ascii("drag_end");
    drag_leave = ascii("drag_leave");
    drag_motion = ascii("drag_motion");
    draw = ascii("draw");
    enter_notify_event = ascii("enter-notify-event");
    event = ascii("event");
    event_after = ascii("event-after");
    expand_collapse_cursor_row = ascii("expand-collapse-cursor-row");
    expose_event = ascii("expose-event");
    focus = ascii("focus");
    focus_in_event = ascii("focus-in-event");
    focus_out_event = ascii("focus-out-event");
    grab_focus = ascii("grab-focus");
    hide = ascii("hide");
    icon_release = ascii("icon-release");
    input = ascii("input");
    insert_text = ascii("insert-text");
    key_press_event = ascii("key-press-event");
    key_release_event = ascii("key-release-event");
    leave_notify_event = ascii("leave-notify-event");
    link_color = ascii("link-color");
    map = ascii("map");
    map_event = ascii("map-event");
    mnemonic_activate = ascii("mnemonic-activate");
    month_changed = ascii("month-changed");
    motion_notify_event = ascii("motion-notify-event");
    move_cursor = ascii("move-cursor");
    move_focus = ascii("move-focus");
    output = ascii("output");
    paste_clipboard = ascii("paste-clipboard");
    popup_menu = ascii("popup-menu");
    populate_popup = ascii("populate-popup");
    preedit_changed = ascii("preedit-changed");
    property_notify_event = ascii("property-notify-event");
    realize = ascii("realize");
    row_activated = ascii("row-activated");
    row_changed = ascii("row-changed");
    row_inserted = ascii("row-inserted");
    row_deleted = ascii("row-deleted");
    scroll_child = ascii("scroll-child");
    scroll_event = ascii("scroll-event");
    select = ascii("select");
    selection_done = ascii("selection-done");
    show = ascii("show");
    show_help = ascii("show-help");
    size_allocate = ascii("size-allocate");
    size_request = ascii("size-request");
    start_interactive_search = ascii("start-interactive-search");
    style_set = ascii("style-set");
    switch_page = ascii("switch-page");
    test_collapse_row = ascii("test-collapse-row");
    test_expand_row = ascii("test-expand-row");
    toggled = ascii("toggled");
    unmap = ascii("unmap");
    unmap_event = ascii("unmap-event");
    unrealize = ascii("unrealize");
    value_changed = ascii("value-changed");
    visibility_notify_event = ascii("visibility-notify-event");
    window_state_event = ascii("window-state-event");
    GTK_STYLE_CLASS_TOOLTIP = ascii("tooltip");
    GTK_STYLE_CLASS_VIEW = ascii("view");
    GTK_STYLE_CLASS_CELL = ascii("cell");
    GTK_STYLE_CLASS_PANE_SEPARATOR = ascii("pane-separator");
    GTK_STYLE_CLASS_FRAME = ascii("frame");
    active = ascii("active");
    background_gdk = ascii("background-gdk");
    button_relief = ascii("button-relief");
    cell_background_gdk = ascii("cell-background-gdk");
    default_border = ascii("default-border");
    expander_size = ascii("expander-size");
    fixed_height_mode = ascii("fixed-height-mode");
    focus_line_width = ascii("focus-line-width");
    focus_padding = ascii("focus-padding");
    font_desc = ascii("font-desc");
    foreground_gdk = ascii("foreground-gdk");
    grid_line_width = ascii("grid-line-width");
    gtk_alternative_button_order = ascii("gtk-alternative-button-order");
    gtk_color_palette = ascii("gtk-color-palette");
    gtk_cursor_blink = ascii("gtk-cursor-blink");
    gtk_cursor_blink_time = ascii("gtk-cursor-blink-time");
    gtk_double_click_time = ascii("gtk-double-click-time");
    gtk_entry_select_on_focus = ascii("gtk-entry-select-on-focus");
    gtk_show_input_method_menu = ascii("gtk-show-input-method-menu");
    gtk_menu_bar_accel = ascii("gtk-menu-bar-accel");
    gtk_menu_images = ascii("gtk-menu-images");
    inner_border = ascii("inner-border");
    has_backward_stepper = ascii("has-backward-stepper");
    has_secondary_backward_stepper = ascii("has-secondary-backward-stepper");
    has_forward_stepper = ascii("has-forward-stepper");
    has_secondary_forward_stepper = ascii("has-secondary-forward-stepper");
    horizontal_separator = ascii("horizontal-separator");
    inconsistent = ascii("inconsistent");
    indicator_size = ascii("indicator-size");
    indicator_spacing = ascii("indicator-spacing");
    initial_gap = ascii("initial-gap");
    interior_focus = ascii("interior-focus");
    mode = ascii("mode");
    model = ascii("model");
    spacing = ascii("spacing");
    pixbuf = ascii("pixbuf");
    gicon = ascii("gicon");
    text = ascii("text");
    xalign = ascii("xalign");
    ypad = ascii("ypad");
    GTK_PRINT_SETTINGS_OUTPUT_URI = ascii("output-uri");
    GTK_STOCK_FIND = ascii("gtk-find");
    GTK_STOCK_CANCEL = ascii("gtk-cancel");
    GTK_STOCK_CLEAR = ascii("gtk-clear");
    G_VARIANT_TYPE_BOOLEAN = ascii("b");
    G_VARIANT_TYPE_DOUBLE = ascii("d");
    G_VARIANT_TYPE_STRING = ascii("s");
    G_VARIANT_TYPE_TUPLE = ascii("r");
    G_VARIANT_TYPE_UINT64 = ascii("t");
    GTK_VERSION = VERSION(gtk_major_version(), gtk_minor_version(), gtk_micro_version());
    GLIB_VERSION = VERSION(glib_major_version(), glib_minor_version(), glib_micro_version());
    GTK3 = GTK_VERSION >= VERSION(3, 0, 0);
    int i = 0;
    if (!"false".equals(System.getProperty("org.eclipse.swt.internal.gtk.cairoGraphics"))) {
      i = (GTK_VERSION >= VERSION(2, 24, 0)) && (Cairo.cairo_version() >= Cairo.CAIRO_VERSION_ENCODE(1, 9, 4)) ? 1 : 0;
    }
    USE_CAIRO = (i != 0) || (GTK3);
    bool1 = false;
    if (!"false".equals(System.getProperty("org.eclipse.swt.internal.gtk.useCairo"))) {
      bool1 = GTK_VERSION >= VERSION(2, 17, 0);
    }
    INIT_CAIRO = bool1;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/internal/gtk/OS.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */