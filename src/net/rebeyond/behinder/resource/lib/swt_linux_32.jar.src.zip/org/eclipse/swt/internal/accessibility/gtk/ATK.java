package org.eclipse.swt.internal.accessibility.gtk;

import org.eclipse.swt.internal.Library;
import org.eclipse.swt.internal.Lock;
import org.eclipse.swt.internal.gtk.OS;

public class ATK
  extends OS
{
  public static final int ATK_RELATION_NULL = 0;
  public static final int ATK_RELATION_CONTROLLED_BY = 1;
  public static final int ATK_RELATION_CONTROLLER_FOR = 2;
  public static final int ATK_RELATION_LABEL_FOR = 3;
  public static final int ATK_RELATION_LABELLED_BY = 4;
  public static final int ATK_RELATION_MEMBER_OF = 5;
  public static final int ATK_RELATION_NODE_CHILD_OF = 6;
  public static final int ATK_RELATION_FLOWS_TO = 7;
  public static final int ATK_RELATION_FLOWS_FROM = 8;
  public static final int ATK_RELATION_SUBWINDOW_OF = 9;
  public static final int ATK_RELATION_EMBEDS = 10;
  public static final int ATK_RELATION_EMBEDDED_BY = 11;
  public static final int ATK_RELATION_POPUP_FOR = 12;
  public static final int ATK_RELATION_PARENT_WINDOW_OF = 13;
  public static final int ATK_RELATION_DESCRIBED_BY = 14;
  public static final int ATK_RELATION_DESCRIPTION_FOR = 15;
  public static final int ATK_ROLE_ALERT = 2;
  public static final int ATK_ROLE_ANIMATION = 3;
  public static final int ATK_ROLE_CALENDAR = 4;
  public static final int ATK_ROLE_CANVAS = 6;
  public static final int ATK_ROLE_CHECK_BOX = 7;
  public static final int ATK_ROLE_CHECK_MENU_ITEM = 8;
  public static final int ATK_ROLE_COMBO_BOX = 11;
  public static final int ATK_ROLE_DATE_EDITOR = 12;
  public static final int ATK_ROLE_DIALOG = 16;
  public static final int ATK_ROLE_DRAWING_AREA = 18;
  public static final int ATK_ROLE_WINDOW = 68;
  public static final int ATK_ROLE_LABEL = 28;
  public static final int ATK_ROLE_LIST = 30;
  public static final int ATK_ROLE_LIST_ITEM = 31;
  public static final int ATK_ROLE_MENU = 32;
  public static final int ATK_ROLE_MENU_BAR = 33;
  public static final int ATK_ROLE_MENU_ITEM = 34;
  public static final int ATK_ROLE_PAGE_TAB = 36;
  public static final int ATK_ROLE_PAGE_TAB_LIST = 37;
  public static final int ATK_ROLE_PANEL = 38;
  public static final int ATK_ROLE_PROGRESS_BAR = 41;
  public static final int ATK_ROLE_PUSH_BUTTON = 42;
  public static final int ATK_ROLE_RADIO_BUTTON = 43;
  public static final int ATK_ROLE_RADIO_MENU_ITEM = 44;
  public static final int ATK_ROLE_SCROLL_BAR = 47;
  public static final int ATK_ROLE_SEPARATOR = 49;
  public static final int ATK_ROLE_SLIDER = 50;
  public static final int ATK_ROLE_SPIN_BUTTON = 52;
  public static final int ATK_ROLE_STATUSBAR = 53;
  public static final int ATK_ROLE_TABLE = 54;
  public static final int ATK_ROLE_TABLE_CELL = 55;
  public static final int ATK_ROLE_TABLE_COLUMN_HEADER = 56;
  public static final int ATK_ROLE_TABLE_ROW_HEADER = 57;
  public static final int ATK_ROLE_TEXT = 60;
  public static final int ATK_ROLE_TOOL_BAR = 62;
  public static final int ATK_ROLE_TOOL_TIP = 63;
  public static final int ATK_ROLE_TREE = 64;
  public static final int ATK_ROLE_HEADER = 69;
  public static final int ATK_ROLE_FOOTER = 70;
  public static final int ATK_ROLE_PARAGRAPH = 71;
  public static final int ATK_ROLE_FORM = 85;
  public static final int ATK_ROLE_HEADING = 81;
  public static final int ATK_ROLE_DOCUMENT_FRAME = 80;
  public static final int ATK_ROLE_IMAGE = 26;
  public static final int ATK_ROLE_PAGE = 82;
  public static final int ATK_ROLE_SECTION = 83;
  public static final int ATK_ROLE_UNKNOWN = 66;
  public static final int ATK_STATE_ACTIVE = 1;
  public static final int ATK_STATE_ARMED = 2;
  public static final int ATK_STATE_BUSY = 3;
  public static final int ATK_STATE_CHECKED = 4;
  public static final int ATK_STATE_DEFUNCT = 5;
  public static final int ATK_STATE_EDITABLE = 6;
  public static final int ATK_STATE_ENABLED = 7;
  public static final int ATK_STATE_EXPANDED = 9;
  public static final int ATK_STATE_FOCUSABLE = 10;
  public static final int ATK_STATE_FOCUSED = 11;
  public static final int ATK_STATE_MULTI_LINE = 15;
  public static final int ATK_STATE_MULTISELECTABLE = 16;
  public static final int ATK_STATE_PRESSED = 18;
  public static final int ATK_STATE_RESIZABLE = 19;
  public static final int ATK_STATE_SELECTABLE = 20;
  public static final int ATK_STATE_SELECTED = 21;
  public static final int ATK_STATE_SHOWING = 23;
  public static final int ATK_STATE_SINGLE_LINE = 24;
  public static final int ATK_STATE_TRANSIENT = 26;
  public static final int ATK_STATE_REQUIRED = 32;
  public static final int ATK_STATE_INVALID_ENTRY = 33;
  public static final int ATK_STATE_SUPPORTS_AUTOCOMPLETION = 34;
  public static final int ATK_STATE_VISIBLE = 28;
  public static final int ATK_TEXT_BOUNDARY_CHAR = 0;
  public static final int ATK_TEXT_BOUNDARY_WORD_START = 1;
  public static final int ATK_TEXT_BOUNDARY_WORD_END = 2;
  public static final int ATK_TEXT_BOUNDARY_SENTENCE_START = 3;
  public static final int ATK_TEXT_BOUNDARY_SENTENCE_END = 4;
  public static final int ATK_TEXT_BOUNDARY_LINE_START = 5;
  public static final int ATK_TEXT_BOUNDARY_LINE_END = 6;
  public static final int ATK_TEXT_CLIP_NONE = 0;
  public static final int ATK_TEXT_CLIP_MIN = 1;
  public static final int ATK_TEXT_CLIP_MAX = 2;
  public static final int ATK_TEXT_CLIP_BOTH = 3;
  public static final int ATK_TEXT_ATTR_LEFT_MARGIN = 1;
  public static final int ATK_TEXT_ATTR_RIGHT_MARGIN = 2;
  public static final int ATK_TEXT_ATTR_INDENT = 3;
  public static final int ATK_TEXT_ATTR_INVISIBLE = 4;
  public static final int ATK_TEXT_ATTR_EDITABLE = 5;
  public static final int ATK_TEXT_ATTR_PIXELS_ABOVE_LINES = 6;
  public static final int ATK_TEXT_ATTR_PIXELS_BELOW_LINES = 7;
  public static final int ATK_TEXT_ATTR_PIXELS_INSIDE_WRAP = 8;
  public static final int ATK_TEXT_ATTR_BG_FULL_HEIGHT = 9;
  public static final int ATK_TEXT_ATTR_RISE = 10;
  public static final int ATK_TEXT_ATTR_UNDERLINE = 11;
  public static final int ATK_TEXT_ATTR_STRIKETHROUGH = 12;
  public static final int ATK_TEXT_ATTR_SIZE = 13;
  public static final int ATK_TEXT_ATTR_SCALE = 14;
  public static final int ATK_TEXT_ATTR_WEIGHT = 15;
  public static final int ATK_TEXT_ATTR_LANGUAGE = 16;
  public static final int ATK_TEXT_ATTR_FAMILY_NAME = 17;
  public static final int ATK_TEXT_ATTR_BG_COLOR = 18;
  public static final int ATK_TEXT_ATTR_FG_COLOR = 19;
  public static final int ATK_TEXT_ATTR_BG_STIPPLE = 20;
  public static final int ATK_TEXT_ATTR_FG_STIPPLE = 21;
  public static final int ATK_TEXT_ATTR_WRAP_MODE = 22;
  public static final int ATK__TEXT_ATTR_DIRECTION = 23;
  public static final int ATK_TEXT_ATTR_JUSTIFICATION = 24;
  public static final int ATK_TEXT_ATTR_STRETCH = 25;
  public static final int ATK_TEXT_ATTR_VARIANT = 26;
  public static final int ATK_TEXT_ATTR_STYLE = 27;
  public static final int ATK_XY_WINDOW = 1;
  public static final byte[] selection_changed = OS.ascii("selection_changed");
  public static final byte[] active_descendant_changed = OS.ascii("active_descendant_changed");
  public static final byte[] text_changed_insert = OS.ascii("text_changed::insert");
  public static final byte[] text_changed_delete = OS.ascii("text_changed::delete");
  public static final byte[] text_caret_moved = OS.ascii("text_caret_moved");
  public static final byte[] text_selection_changed = OS.ascii("text_selection_changed");
  public static final byte[] load_complete = OS.ascii("load-complete");
  public static final byte[] load_stopped = OS.ascii("load-stopped");
  public static final byte[] reload = OS.ascii("reload");
  public static final byte[] state_change = OS.ascii("state-change");
  public static final byte[] bounds_changed = OS.ascii("bounds-changed");
  public static final byte[] link_activated = OS.ascii("link-activated");
  public static final byte[] link_selected = OS.ascii("link-selected");
  public static final byte[] attributes_changed = OS.ascii("attributes-changed");
  public static final byte[] text_attributes_changed = OS.ascii("text-attributes-changed");
  public static final byte[] column_deleted = OS.ascii("column-deleted");
  public static final byte[] column_inserted = OS.ascii("column-inserted");
  public static final byte[] row_deleted = OS.ascii("row-deleted");
  public static final byte[] row_inserted = OS.ascii("row-inserted");
  public static final byte[] focus_event = OS.ascii("focus-event");
  public static final byte[] accessible_name = OS.ascii("accessible-name");
  public static final byte[] accessible_description = OS.ascii("accessible-description");
  public static final byte[] accessible_value = OS.ascii("accessible-value");
  public static final byte[] end_index = OS.ascii("end-index");
  public static final byte[] number_of_anchors = OS.ascii("number-of-anchors");
  public static final byte[] selected_link = OS.ascii("selected-link");
  public static final byte[] start_index = OS.ascii("start-index");
  public static final byte[] accessible_hypertext_nlinks = OS.ascii("accessible-hypertext-nlinks");
  public static final byte[] accessible_table_caption_object = OS.ascii("accessible-table-caption-object");
  public static final byte[] accessible_table_column_description = OS.ascii("accessible-table-column-description");
  public static final byte[] accessible_table_column_header = OS.ascii("accessible-table-column-header");
  public static final byte[] accessible_table_row_description = OS.ascii("accessible-table-row-description");
  public static final byte[] accessible_table_row_header = OS.ascii("accessible-table-row-header");
  public static final byte[] accessible_table_summary = OS.ascii("accessible-table-summary");
  
  public static final native int AtkObjectFactory_sizeof();
  
  public static final native int AtkObjectFactoryClass_sizeof();
  
  public static final native int AtkAttribute_sizeof();
  
  public static final native int AtkTextRange_sizeof();
  
  public static final native int AtkTextRectangle_sizeof();
  
  public static final native int ATK_TYPE_ACTION();
  
  public static final native int ATK_TYPE_COMPONENT();
  
  public static final native int ATK_TYPE_EDITABLE_TEXT();
  
  public static final native int ATK_TYPE_HYPERTEXT();
  
  public static final native int ATK_TYPE_SELECTION();
  
  public static final native int ATK_TYPE_TABLE();
  
  public static final native int ATK_TYPE_TEXT();
  
  public static final native int ATK_TYPE_VALUE();
  
  public static final native int ATK_TYPE_OBJECT_FACTORY();
  
  public static final native boolean ATK_IS_NO_OP_OBJECT_FACTORY(int paramInt);
  
  public static final native int _ATK_ACTION_GET_IFACE(int paramInt);
  
  public static final int ATK_ACTION_GET_IFACE(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _ATK_ACTION_GET_IFACE(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _ATK_COMPONENT_GET_IFACE(int paramInt);
  
  public static final int ATK_COMPONENT_GET_IFACE(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _ATK_COMPONENT_GET_IFACE(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _ATK_OBJECT_FACTORY_CLASS(int paramInt);
  
  public static final native int _ATK_SELECTION_GET_IFACE(int paramInt);
  
  public static final int ATK_SELECTION_GET_IFACE(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _ATK_SELECTION_GET_IFACE(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _ATK_EDITABLE_TEXT_GET_IFACE(int paramInt);
  
  public static final int ATK_EDITABLE_TEXT_GET_IFACE(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _ATK_EDITABLE_TEXT_GET_IFACE(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _ATK_HYPERTEXT_GET_IFACE(int paramInt);
  
  public static final int ATK_HYPERTEXT_GET_IFACE(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _ATK_HYPERTEXT_GET_IFACE(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _ATK_TABLE_GET_IFACE(int paramInt);
  
  public static final int ATK_TABLE_GET_IFACE(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _ATK_TABLE_GET_IFACE(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _ATK_TEXT_GET_IFACE(int paramInt);
  
  public static final int ATK_TEXT_GET_IFACE(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _ATK_TEXT_GET_IFACE(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _ATK_VALUE_GET_IFACE(int paramInt);
  
  public static final int ATK_VALUE_GET_IFACE(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _ATK_VALUE_GET_IFACE(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _atk_get_default_registry();
  
  public static final int atk_get_default_registry()
  {
    lock.lock();
    try
    {
      int i = _atk_get_default_registry();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _atk_object_factory_get_accessible_type(int paramInt);
  
  public static final int atk_object_factory_get_accessible_type(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _atk_object_factory_get_accessible_type(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _atk_object_initialize(int paramInt1, int paramInt2);
  
  public static final void atk_object_initialize(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _atk_object_initialize(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _atk_object_notify_state_change(int paramInt1, int paramInt2, boolean paramBoolean);
  
  public static final void atk_object_notify_state_change(int paramInt1, int paramInt2, boolean paramBoolean)
  {
    lock.lock();
    try
    {
      _atk_object_notify_state_change(paramInt1, paramInt2, paramBoolean);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _atk_role_register(byte[] paramArrayOfByte);
  
  public static final int atk_role_register(byte[] paramArrayOfByte)
  {
    lock.lock();
    try
    {
      int i = _atk_role_register(paramArrayOfByte);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _atk_registry_get_factory(int paramInt1, int paramInt2);
  
  public static final int atk_registry_get_factory(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      int i = _atk_registry_get_factory(paramInt1, paramInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _atk_registry_set_factory_type(int paramInt1, int paramInt2, int paramInt3);
  
  public static final void atk_registry_set_factory_type(int paramInt1, int paramInt2, int paramInt3)
  {
    lock.lock();
    try
    {
      _atk_registry_set_factory_type(paramInt1, paramInt2, paramInt3);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _atk_state_set_add_state(int paramInt1, int paramInt2);
  
  public static final boolean atk_state_set_add_state(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      boolean bool = _atk_state_set_add_state(paramInt1, paramInt2);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _atk_text_attribute_get_name(int paramInt);
  
  public static final int atk_text_attribute_get_name(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _atk_text_attribute_get_name(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _atk_text_attribute_get_value(int paramInt1, int paramInt2);
  
  public static final int atk_text_attribute_get_value(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      int i = _atk_text_attribute_get_value(paramInt1, paramInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _call(int paramInt1, int paramInt2);
  
  public static final int call(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      int i = _call(paramInt1, paramInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _call(int paramInt1, int paramInt2, int paramInt3);
  
  public static final int call(int paramInt1, int paramInt2, int paramInt3)
  {
    lock.lock();
    try
    {
      int i = _call(paramInt1, paramInt2, paramInt3);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _call(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  public static final int call(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    lock.lock();
    try
    {
      int i = _call(paramInt1, paramInt2, paramInt3, paramInt4);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _call(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6);
  
  public static final int call(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6)
  {
    lock.lock();
    try
    {
      int i = _call(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int g_strdup(int paramInt);
  
  public static final native void memmove(AtkActionIface paramAtkActionIface, int paramInt);
  
  public static final native void memmove(AtkComponentIface paramAtkComponentIface, int paramInt);
  
  public static final native void memmove(AtkEditableTextIface paramAtkEditableTextIface, int paramInt);
  
  public static final native void memmove(AtkHypertextIface paramAtkHypertextIface, int paramInt);
  
  public static final native void memmove(AtkObjectClass paramAtkObjectClass, int paramInt);
  
  public static final native void memmove(AtkObjectFactoryClass paramAtkObjectFactoryClass, int paramInt);
  
  public static final native void memmove(AtkSelectionIface paramAtkSelectionIface, int paramInt);
  
  public static final native void memmove(AtkTableIface paramAtkTableIface, int paramInt);
  
  public static final native void memmove(AtkTextIface paramAtkTextIface, int paramInt);
  
  public static final native void memmove(AtkValueIface paramAtkValueIface, int paramInt);
  
  public static final native void memmove(GtkAccessible paramGtkAccessible, int paramInt);
  
  public static final native void memmove(int paramInt, AtkActionIface paramAtkActionIface);
  
  public static final native void memmove(int paramInt, AtkComponentIface paramAtkComponentIface);
  
  public static final native void memmove(int paramInt, AtkEditableTextIface paramAtkEditableTextIface);
  
  public static final native void memmove(int paramInt, AtkHypertextIface paramAtkHypertextIface);
  
  public static final native void memmove(int paramInt, AtkObjectClass paramAtkObjectClass);
  
  public static final native void memmove(int paramInt, AtkObjectFactoryClass paramAtkObjectFactoryClass);
  
  public static final native void memmove(int paramInt, AtkSelectionIface paramAtkSelectionIface);
  
  public static final native void memmove(int paramInt, AtkTableIface paramAtkTableIface);
  
  public static final native void memmove(int paramInt, AtkTextIface paramAtkTextIface);
  
  public static final native void memmove(int paramInt, AtkValueIface paramAtkValueIface);
  
  public static final native void memmove(int paramInt1, AtkTextRectangle paramAtkTextRectangle, int paramInt2);
  
  public static final native void memmove(AtkTextRectangle paramAtkTextRectangle, int paramInt1, int paramInt2);
  
  public static final native void memmove(int paramInt1, AtkTextRange paramAtkTextRange, int paramInt2);
  
  public static final native void memmove(AtkTextRange paramAtkTextRange, int paramInt1, int paramInt2);
  
  public static final native void memmove(int paramInt1, AtkAttribute paramAtkAttribute, int paramInt2);
  
  public static final native void memmove(AtkAttribute paramAtkAttribute, int paramInt1, int paramInt2);
  
  static
  {
    Library.loadLibrary("swt-atk");
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/internal/accessibility/gtk/ATK.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */