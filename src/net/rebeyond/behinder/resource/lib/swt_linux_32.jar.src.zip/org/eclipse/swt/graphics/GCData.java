package org.eclipse.swt.graphics;

import org.eclipse.swt.internal.gtk.GdkColor;

public final class GCData
{
  public Device device;
  public int style;
  public int state = -1;
  public GdkColor foreground;
  public GdkColor background;
  public Font font;
  public Pattern foregroundPattern;
  public Pattern backgroundPattern;
  public float lineWidth;
  public int lineStyle = 1;
  public float[] lineDashes;
  public float lineDashesOffset;
  public float lineMiterLimit = 10.0F;
  public int lineCap = 1;
  public int lineJoin = 1;
  public boolean xorMode;
  public int alpha = 255;
  public int interpolation = -1;
  public Image image;
  public int clipRgn;
  public int context;
  public int layout;
  public int damageRgn;
  public int drawable;
  public int cairo;
  public double cairoXoffset;
  public double cairoYoffset;
  public boolean disposeCairo;
  public double[] identity;
  public double[] clippingTransform;
  public String string;
  public int stringWidth = -1;
  public int stringHeight = -1;
  public int drawFlags;
  public boolean realDrawable;
  public int width = -1;
  public int height = -1;
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/graphics/GCData.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */