package org.eclipse.swt.dnd;

import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.internal.gtk.GdkRectangle;
import org.eclipse.swt.internal.gtk.OS;
import org.eclipse.swt.widgets.Tree;

public class TreeDropTargetEffect
  extends DropTargetEffect
{
  static final int SCROLL_HYSTERESIS = 150;
  static final int EXPAND_HYSTERESIS = 1000;
  int scrollIndex = -1;
  long scrollBeginTime;
  int expandIndex = -1;
  long expandBeginTime;
  
  public TreeDropTargetEffect(Tree paramTree)
  {
    super(paramTree);
  }
  
  int checkEffect(int paramInt)
  {
    if ((paramInt & 0x1) != 0) {
      paramInt = paramInt & 0xFFFFFFFB & 0xFFFFFFFD;
    }
    if ((paramInt & 0x2) != 0) {
      paramInt &= 0xFFFFFFFB;
    }
    return paramInt;
  }
  
  public void dragEnter(DropTargetEvent paramDropTargetEvent)
  {
    this.expandBeginTime = 0L;
    this.expandIndex = -1;
    this.scrollBeginTime = 0L;
    this.scrollIndex = -1;
  }
  
  public void dragLeave(DropTargetEvent paramDropTargetEvent)
  {
    Tree localTree = (Tree)this.control;
    int i = localTree.handle;
    OS.gtk_tree_view_set_drag_dest_row(i, 0, 0);
    this.scrollBeginTime = 0L;
    this.scrollIndex = -1;
    this.expandBeginTime = 0L;
    this.expandIndex = -1;
  }
  
  public void dragOver(DropTargetEvent paramDropTargetEvent)
  {
    Tree localTree = (Tree)this.control;
    int i = checkEffect(paramDropTargetEvent.feedback);
    int j = localTree.handle;
    Point localPoint = new Point(paramDropTargetEvent.x, paramDropTargetEvent.y);
    localPoint = localTree.toControl(localPoint);
    int[] arrayOfInt1 = new int[1];
    OS.gtk_tree_view_get_path_at_pos(j, localPoint.x, localPoint.y, arrayOfInt1, null, null, null);
    int k = -1;
    int[] arrayOfInt3;
    if (arrayOfInt1[0] != 0)
    {
      int m = OS.gtk_tree_path_get_indices(arrayOfInt1[0]);
      if (m != 0)
      {
        int i1 = OS.gtk_tree_path_get_depth(arrayOfInt1[0]);
        arrayOfInt3 = new int[i1];
        OS.memmove(arrayOfInt3, m, arrayOfInt3.length * 4);
        k = arrayOfInt3[(arrayOfInt3.length - 1)];
      }
    }
    if ((i & 0x8) == 0)
    {
      this.scrollBeginTime = 0L;
      this.scrollIndex = -1;
    }
    else if ((k != -1) && (this.scrollIndex == k) && (this.scrollBeginTime != 0L))
    {
      if (System.currentTimeMillis() >= this.scrollBeginTime)
      {
        GdkRectangle localGdkRectangle = new GdkRectangle();
        OS.gtk_tree_view_get_cell_area(j, arrayOfInt1[0], 0, localGdkRectangle);
        if (localGdkRectangle.y < localGdkRectangle.height)
        {
          int[] arrayOfInt2 = new int[1];
          arrayOfInt3 = new int[1];
          if (OS.GTK_VERSION >= OS.VERSION(2, 12, 0)) {
            OS.gtk_tree_view_convert_bin_window_to_tree_coords(j, localGdkRectangle.x, localGdkRectangle.y - localGdkRectangle.height, arrayOfInt2, arrayOfInt3);
          } else {
            OS.gtk_tree_view_widget_to_tree_coords(j, localGdkRectangle.x, localGdkRectangle.y - localGdkRectangle.height, arrayOfInt2, arrayOfInt3);
          }
          OS.gtk_tree_view_scroll_to_point(j, -1, arrayOfInt3[0]);
        }
        else
        {
          OS.gtk_tree_view_get_path_at_pos(j, localPoint.x, localPoint.y + localGdkRectangle.height, arrayOfInt1, null, null, null);
          if (arrayOfInt1[0] != 0)
          {
            OS.gtk_tree_view_scroll_to_cell(j, arrayOfInt1[0], 0, false, 0.0F, 0.0F);
            OS.gtk_tree_path_free(arrayOfInt1[0]);
            arrayOfInt1[0] = 0;
          }
          OS.gtk_tree_view_get_path_at_pos(j, localPoint.x, localPoint.y, arrayOfInt1, null, null, null);
        }
        this.scrollBeginTime = 0L;
        this.scrollIndex = -1;
      }
    }
    else
    {
      this.scrollBeginTime = (System.currentTimeMillis() + 150L);
      this.scrollIndex = k;
    }
    if ((i & 0x10) == 0)
    {
      this.expandBeginTime = 0L;
      this.expandIndex = -1;
    }
    else if ((k != -1) && (this.expandIndex == k) && (this.expandBeginTime != 0L))
    {
      if (System.currentTimeMillis() >= this.expandBeginTime)
      {
        OS.gtk_tree_view_expand_row(j, arrayOfInt1[0], false);
        this.expandBeginTime = 0L;
        this.expandIndex = -1;
      }
    }
    else
    {
      this.expandBeginTime = (System.currentTimeMillis() + 1000L);
      this.expandIndex = k;
    }
    if (arrayOfInt1[0] != 0)
    {
      int n = -1;
      if ((i & 0x1) != 0) {
        n = 2;
      }
      if ((i & 0x2) != 0) {
        n = 0;
      }
      if ((i & 0x4) != 0) {
        n = 1;
      }
      if (n != -1) {
        OS.gtk_tree_view_set_drag_dest_row(j, arrayOfInt1[0], n);
      } else {
        OS.gtk_tree_view_set_drag_dest_row(j, 0, 0);
      }
    }
    else
    {
      OS.gtk_tree_view_set_drag_dest_row(j, 0, 0);
    }
    if (arrayOfInt1[0] != 0) {
      OS.gtk_tree_path_free(arrayOfInt1[0]);
    }
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/dnd/TreeDropTargetEffect.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */