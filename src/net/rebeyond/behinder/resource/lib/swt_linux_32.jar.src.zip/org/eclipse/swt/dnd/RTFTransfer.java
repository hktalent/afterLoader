package org.eclipse.swt.dnd;

import org.eclipse.swt.internal.Converter;
import org.eclipse.swt.internal.gtk.OS;

public class RTFTransfer
  extends ByteArrayTransfer
{
  private static RTFTransfer _instance = new RTFTransfer();
  private static final String TEXT_RTF = "text/rtf";
  private static final int TEXT_RTF_ID = registerType("text/rtf");
  private static final String TEXT_RTF2 = "TEXT/RTF";
  private static final int TEXT_RTF2_ID = registerType("TEXT/RTF");
  private static final String APPLICATION_RTF = "application/rtf";
  private static final int APPLICATION_RTF_ID = registerType("application/rtf");
  
  public static RTFTransfer getInstance()
  {
    return _instance;
  }
  
  public void javaToNative(Object paramObject, TransferData paramTransferData)
  {
    paramTransferData.result = 0;
    if ((!checkRTF(paramObject)) || (!isSupportedType(paramTransferData))) {
      DND.error(2003);
    }
    String str = (String)paramObject;
    byte[] arrayOfByte = Converter.wcsToMbcs(null, str, true);
    int i = OS.g_malloc(arrayOfByte.length);
    if (i == 0) {
      return;
    }
    OS.memmove(i, arrayOfByte, arrayOfByte.length);
    paramTransferData.length = (arrayOfByte.length - 1);
    paramTransferData.format = 8;
    paramTransferData.pValue = i;
    paramTransferData.result = 1;
  }
  
  public Object nativeToJava(TransferData paramTransferData)
  {
    if ((!isSupportedType(paramTransferData)) || (paramTransferData.pValue == 0)) {
      return null;
    }
    int i = paramTransferData.format * paramTransferData.length / 8;
    if (i == 0) {
      return null;
    }
    byte[] arrayOfByte = new byte[i];
    OS.memmove(arrayOfByte, paramTransferData.pValue, i);
    char[] arrayOfChar = Converter.mbcsToWcs(null, arrayOfByte);
    String str = new String(arrayOfChar);
    int j = str.indexOf(0);
    return j == -1 ? str : str.substring(0, j);
  }
  
  protected int[] getTypeIds()
  {
    return new int[] { TEXT_RTF_ID, TEXT_RTF2_ID, APPLICATION_RTF_ID };
  }
  
  protected String[] getTypeNames()
  {
    return new String[] { "text/rtf", "TEXT/RTF", "application/rtf" };
  }
  
  boolean checkRTF(Object paramObject)
  {
    return (paramObject != null) && ((paramObject instanceof String)) && (((String)paramObject).length() > 0);
  }
  
  protected boolean validate(Object paramObject)
  {
    return checkRTF(paramObject);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/dnd/RTFTransfer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */