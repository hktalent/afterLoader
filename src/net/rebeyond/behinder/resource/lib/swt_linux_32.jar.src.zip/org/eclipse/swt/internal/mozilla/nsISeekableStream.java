package org.eclipse.swt.internal.mozilla;

public class nsISeekableStream
  extends nsISupports
{
  static final int LAST_METHOD_ID = nsISupports.LAST_METHOD_ID + 3;
  static final String NS_ISEEKABLESTREAM_IID_STR = "8429d350-1040-4661-8b71-f2a6ba455980";
  public static final int NS_SEEK_SET = 0;
  public static final int NS_SEEK_CUR = 1;
  public static final int NS_SEEK_END = 2;
  
  public nsISeekableStream(int paramInt)
  {
    super(paramInt);
  }
  
  public int Seek(int paramInt, long paramLong)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 1, getAddress(), paramInt, paramLong);
  }
  
  public int Tell(long[] paramArrayOfLong)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 2, getAddress(), paramArrayOfLong);
  }
  
  static
  {
    IIDStore.RegisterIID(nsISeekableStream.class, 0, new nsID("8429d350-1040-4661-8b71-f2a6ba455980"));
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/internal/mozilla/nsISeekableStream.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */