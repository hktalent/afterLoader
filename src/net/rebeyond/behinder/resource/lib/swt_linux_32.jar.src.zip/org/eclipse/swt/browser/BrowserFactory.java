package org.eclipse.swt.browser;

class BrowserFactory
{
  WebBrowser createWebBrowser(int paramInt)
  {
    boolean bool = WebKit.IsInstalled();
    if (((paramInt & 0x8000) != 0) || ((!bool) && ((paramInt & 0x10000) == 0))) {
      return new Mozilla();
    }
    if (!bool) {
      return null;
    }
    return new WebKit();
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/browser/BrowserFactory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */