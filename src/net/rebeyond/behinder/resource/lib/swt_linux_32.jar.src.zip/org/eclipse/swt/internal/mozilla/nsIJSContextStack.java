package org.eclipse.swt.internal.mozilla;

public class nsIJSContextStack
  extends nsISupports
{
  static final int LAST_METHOD_ID = nsISupports.LAST_METHOD_ID + 4;
  static final String NS_IJSCONTEXTSTACK_IID_STR = "c67d8270-3189-11d3-9885-006008962422";
  
  public nsIJSContextStack(int paramInt)
  {
    super(paramInt);
  }
  
  public int Pop(int[] paramArrayOfInt)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 3, getAddress(), paramArrayOfInt);
  }
  
  public int Push(int paramInt)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 4, getAddress(), paramInt);
  }
  
  static
  {
    IIDStore.RegisterIID(nsIJSContextStack.class, 0, new nsID("c67d8270-3189-11d3-9885-006008962422"));
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/internal/mozilla/nsIJSContextStack.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */