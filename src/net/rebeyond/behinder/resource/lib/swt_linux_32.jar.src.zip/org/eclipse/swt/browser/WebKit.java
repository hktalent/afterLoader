package org.eclipse.swt.browser;

import java.io.PrintStream;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.StringTokenizer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.SWTException;
import org.eclipse.swt.graphics.Device;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.internal.C;
import org.eclipse.swt.internal.Callback;
import org.eclipse.swt.internal.Compatibility;
import org.eclipse.swt.internal.Converter;
import org.eclipse.swt.internal.LONG;
import org.eclipse.swt.internal.Library;
import org.eclipse.swt.internal.gtk.GdkEventKey;
import org.eclipse.swt.internal.gtk.OS;
import org.eclipse.swt.internal.webkit.JSClassDefinition;
import org.eclipse.swt.internal.webkit.WebKitGTK;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.Monitor;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Widget;

class WebKit
  extends WebBrowser
{
  int webView;
  int webViewData;
  int scrolledWindow;
  int failureCount;
  int lastKeyCode;
  int lastCharCode;
  String postData;
  String[] headers;
  boolean ignoreDispose;
  boolean loadingText;
  boolean untrustedText;
  byte[] htmlBytes;
  BrowserFunction eventFunction;
  static int DisabledJSCount;
  static int ExternalClass;
  static int PostString;
  static int WebViewType;
  static boolean IsWebKit14orNewer;
  static boolean LibraryLoaded;
  static Hashtable WindowMappings = new Hashtable();
  static final String ABOUT_BLANK = "about:blank";
  static final String CHARSET_UTF8 = "UTF-8";
  static final String CLASSNAME_EXTERNAL = "External";
  static final String FUNCTIONNAME_CALLJAVA = "callJava";
  static final String HEADER_CONTENTTYPE = "content-type";
  static final String MIMETYPE_FORMURLENCODED = "application/x-www-form-urlencoded";
  static final String OBJECTNAME_EXTERNAL = "external";
  static final String PROPERTY_LENGTH = "length";
  static final String PROPERTY_PROXYHOST = "network.proxy_host";
  static final String PROPERTY_PROXYPORT = "network.proxy_port";
  static final String PROTOCOL_FILE = "file://";
  static final String PROTOCOL_HTTP = "http://";
  static final String URI_FILEROOT = "file:///";
  static final String USER_AGENT = "user-agent";
  static final int MAX_PORT = 65535;
  static final int MAX_PROGRESS = 100;
  static final int[] MIN_VERSION = { 1, 2, 0 };
  static final int SENTINEL_KEYPRESS = -1;
  static final char SEPARATOR_FILE = System.getProperty("file.separator").charAt(0);
  static final int STOP_PROPOGATE = 1;
  static final String DOMEVENT_DRAGSTART = "dragstart";
  static final String DOMEVENT_KEYDOWN = "keydown";
  static final String DOMEVENT_KEYPRESS = "keypress";
  static final String DOMEVENT_KEYUP = "keyup";
  static final String DOMEVENT_MOUSEDOWN = "mousedown";
  static final String DOMEVENT_MOUSEUP = "mouseup";
  static final String DOMEVENT_MOUSEMOVE = "mousemove";
  static final String DOMEVENT_MOUSEOUT = "mouseout";
  static final String DOMEVENT_MOUSEOVER = "mouseover";
  static final String DOMEVENT_MOUSEWHEEL = "mousewheel";
  static final int HOVERING_OVER_LINK = 1;
  static final int NOTIFY_PROGRESS = 2;
  static final int NAVIGATION_POLICY_DECISION_REQUESTED = 3;
  static final int NOTIFY_TITLE = 4;
  static final int POPULATE_POPUP = 5;
  static final int STATUS_BAR_TEXT_CHANGED = 6;
  static final int CREATE_WEB_VIEW = 7;
  static final int WEB_VIEW_READY = 8;
  static final int NOTIFY_LOAD_STATUS = 9;
  static final int RESOURCE_REQUEST_STARTING = 10;
  static final int DOWNLOAD_REQUESTED = 11;
  static final int MIME_TYPE_POLICY_DECISION_REQUESTED = 12;
  static final int CLOSE_WEB_VIEW = 13;
  static final int WINDOW_OBJECT_CLEARED = 14;
  static final int CONSOLE_MESSAGE = 15;
  static final int LOAD_CHANGED = 16;
  static final int DECIDE_POLICY = 17;
  static final int MOUSE_TARGET_CHANGED = 18;
  static final int CONTEXT_MENU = 19;
  static final int AUTHENTICATE = 20;
  static final String KEY_CHECK_SUBWINDOW = "org.eclipse.swt.internal.control.checksubwindow";
  static Callback Proc2;
  static Callback Proc3;
  static Callback Proc4;
  static Callback Proc5;
  static Callback Proc6;
  static Callback JSObjectHasPropertyProc;
  static Callback JSObjectGetPropertyProc;
  static Callback JSObjectCallAsFunctionProc;
  static Callback JSDOMEventProc;
  static boolean WEBKIT2;
  
  static String getString(int paramInt)
  {
    int i = OS.strlen(paramInt);
    byte[] arrayOfByte = new byte[i];
    OS.memmove(arrayOfByte, paramInt, i);
    return new String(Converter.mbcsToWcs(null, arrayOfByte));
  }
  
  static Browser FindBrowser(int paramInt)
  {
    if (paramInt == 0) {
      return null;
    }
    int i = OS.gtk_widget_get_parent(paramInt);
    if (!WEBKIT2) {
      i = OS.gtk_widget_get_parent(i);
    }
    return (Browser)Display.getCurrent().findWidget(i);
  }
  
  static boolean IsInstalled()
  {
    if (!LibraryLoaded) {
      return false;
    }
    int i;
    int j;
    int k;
    if (WEBKIT2)
    {
      i = WebKitGTK.webkit_get_major_version();
      j = WebKitGTK.webkit_get_minor_version();
      k = WebKitGTK.webkit_get_micro_version();
    }
    else
    {
      i = WebKitGTK.webkit_major_version();
      j = WebKitGTK.webkit_minor_version();
      k = WebKitGTK.webkit_micro_version();
    }
    IsWebKit14orNewer = (i > 1) || ((i == 1) && (j > 4)) || ((i == 1) && (j == 4) && (k >= 0));
    return (i > MIN_VERSION[0]) || ((i == MIN_VERSION[0]) && (j > MIN_VERSION[1])) || ((i == MIN_VERSION[0]) && (j == MIN_VERSION[1]) && (k >= MIN_VERSION[2]));
  }
  
  static int JSObjectCallAsFunctionProc(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6)
  {
    if (WebKitGTK.JSValueIsObjectOfClass(paramInt1, paramInt3, ExternalClass) == 0) {
      return WebKitGTK.JSValueMakeUndefined(paramInt1);
    }
    int i = WebKitGTK.JSObjectGetPrivate(paramInt3);
    int[] arrayOfInt = new int[1];
    C.memmove(arrayOfInt, i, C.PTR_SIZEOF);
    Browser localBrowser = FindBrowser(arrayOfInt[0]);
    if (localBrowser == null) {
      return 0;
    }
    WebKit localWebKit = (WebKit)localBrowser.webBrowser;
    return localWebKit.callJava(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6);
  }
  
  static int JSObjectGetPropertyProc(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    byte[] arrayOfByte = null;
    try
    {
      arrayOfByte = "callJava\000".getBytes("UTF-8");
    }
    catch (UnsupportedEncodingException localUnsupportedEncodingException)
    {
      arrayOfByte = Converter.wcsToMbcs(null, "callJava", true);
    }
    int i = WebKitGTK.JSStringCreateWithUTF8CString(arrayOfByte);
    int j = WebKitGTK.JSObjectMakeFunctionWithCallback(paramInt1, i, JSObjectCallAsFunctionProc.getAddress());
    WebKitGTK.JSStringRelease(i);
    return j;
  }
  
  static int JSObjectHasPropertyProc(int paramInt1, int paramInt2, int paramInt3)
  {
    byte[] arrayOfByte = null;
    try
    {
      arrayOfByte = "callJava\000".getBytes("UTF-8");
    }
    catch (UnsupportedEncodingException localUnsupportedEncodingException)
    {
      arrayOfByte = Converter.wcsToMbcs(null, "callJava", true);
    }
    return WebKitGTK.JSStringIsEqualToUTF8CString(paramInt3, arrayOfByte);
  }
  
  static int JSDOMEventProc(int paramInt1, int paramInt2, int paramInt3)
  {
    if (OS.GTK_IS_SCROLLED_WINDOW(paramInt1)) {
      return paramInt3;
    }
    if (OS.G_TYPE_CHECK_INSTANCE_TYPE(paramInt1, WebViewType))
    {
      if (DisabledJSCount > 0)
      {
        localObject1 = FindBrowser(paramInt1);
        if ((localObject1 != null) && (!((Browser)localObject1).webBrowser.jsEnabled))
        {
          switch (OS.GDK_EVENT_TYPE(paramInt2))
          {
          case 8: 
            if (((Browser)localObject1).isFocusControl())
            {
              localObject2 = new GdkEventKey();
              OS.memmove((GdkEventKey)localObject2, paramInt2, GdkEventKey.sizeof);
              switch (((GdkEventKey)localObject2).keyval)
              {
              case 65056: 
              case 65289: 
                if ((((GdkEventKey)localObject2).state & 0xC) == 0) {
                  ((Browser)localObject1).getDisplay().asyncExec(new Runnable()
                  {
                    public void run()
                    {
                      if (this.val$browser.isDisposed()) {
                        return;
                      }
                      if (this.val$browser.getDisplay().getFocusControl() == null)
                      {
                        int i = (localObject2.state & 0x1) != 0 ? 8 : 16;
                        this.val$browser.traverse(i);
                      }
                    }
                  });
                }
                break;
              case 65307: 
                localObject3 = new Event();
                ((Event)localObject3).widget = ((Widget)localObject1);
                ((Event)localObject3).type = 1;
                ((Event)localObject3).keyCode = (((Event)localObject3).character = 27);
                if ((((GdkEventKey)localObject2).state & 0x8) != 0) {
                  localObject3.stateMask |= 0x10000;
                }
                if ((((GdkEventKey)localObject2).state & 0x1) != 0) {
                  localObject3.stateMask |= 0x20000;
                }
                if ((((GdkEventKey)localObject2).state & 0x4) != 0) {
                  localObject3.stateMask |= 0x40000;
                }
                ((Browser)localObject1).webBrowser.sendKeyEvent((Event)localObject3);
                return 1;
              }
            }
            break;
          }
          OS.gtk_widget_event(((Browser)localObject1).handle, paramInt2);
        }
      }
      return 0;
    }
    Object localObject1 = (LONG)WindowMappings.get(new LONG(paramInt1));
    if (localObject1 == null) {
      return 0;
    }
    final Object localObject2 = FindBrowser(((LONG)localObject1).value);
    if (localObject2 == null) {
      return 0;
    }
    Object localObject3 = (WebKit)((Browser)localObject2).webBrowser;
    return ((WebKit)localObject3).handleDOMEvent(paramInt2, paramInt3) ? 0 : 1;
  }
  
  static int Proc(int paramInt1, int paramInt2)
  {
    Browser localBrowser = FindBrowser(paramInt1);
    if (localBrowser == null) {
      return 0;
    }
    WebKit localWebKit = (WebKit)localBrowser.webBrowser;
    return localWebKit.webViewProc(paramInt1, paramInt2);
  }
  
  static int Proc(int paramInt1, int paramInt2, int paramInt3)
  {
    int i;
    if (OS.G_TYPE_CHECK_INSTANCE_TYPE(paramInt1, WebKitGTK.webkit_web_view_get_type())) {
      i = paramInt1;
    } else if (OS.G_TYPE_CHECK_INSTANCE_TYPE(paramInt1, WebKitGTK.webkit_web_frame_get_type())) {
      i = WebKitGTK.webkit_web_frame_get_web_view(paramInt1);
    } else {
      return 0;
    }
    Browser localBrowser = FindBrowser(i);
    if (localBrowser == null) {
      return 0;
    }
    WebKit localWebKit = (WebKit)localBrowser.webBrowser;
    if (i == paramInt1) {
      return localWebKit.webViewProc(paramInt1, paramInt2, paramInt3);
    }
    return localWebKit.webFrameProc(paramInt1, paramInt2, paramInt3);
  }
  
  static int Proc(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    Browser localBrowser = FindBrowser(paramInt1);
    if (localBrowser == null) {
      return 0;
    }
    WebKit localWebKit = (WebKit)localBrowser.webBrowser;
    return localWebKit.webViewProc(paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  static int Proc(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
  {
    int i;
    if (OS.G_TYPE_CHECK_INSTANCE_TYPE(paramInt1, WebKitGTK.soup_session_get_type())) {
      i = paramInt5;
    } else {
      i = paramInt1;
    }
    Browser localBrowser = FindBrowser(i);
    if (localBrowser == null) {
      return 0;
    }
    WebKit localWebKit = (WebKit)localBrowser.webBrowser;
    if (i == paramInt1) {
      return localWebKit.webViewProc(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
    }
    return localWebKit.sessionProc(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
  }
  
  static int Proc(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6)
  {
    Browser localBrowser = FindBrowser(paramInt1);
    if (localBrowser == null) {
      return 0;
    }
    WebKit localWebKit = (WebKit)localBrowser.webBrowser;
    return localWebKit.webViewProc(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6);
  }
  
  int sessionProc(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
  {
    if (paramInt4 == 0) {
      this.failureCount = 0;
    } else if (++this.failureCount >= 3) {
      return 0;
    }
    int i = WebKitGTK.soup_message_get_uri(paramInt2);
    int j = WebKitGTK.soup_uri_to_string(i, 0);
    int k = C.strlen(j);
    byte[] arrayOfByte1 = new byte[k];
    OS.memmove(arrayOfByte1, j, k);
    OS.g_free(j);
    String str = new String(Converter.mbcsToWcs(null, arrayOfByte1));
    for (int m = 0; m < this.authenticationListeners.length; m++)
    {
      AuthenticationEvent localAuthenticationEvent = new AuthenticationEvent(this.browser);
      localAuthenticationEvent.location = str;
      this.authenticationListeners[m].authenticate(localAuthenticationEvent);
      if (!localAuthenticationEvent.doit)
      {
        OS.g_signal_stop_emission_by_name(paramInt1, WebKitGTK.authenticate);
        return 0;
      }
      if ((localAuthenticationEvent.user != null) && (localAuthenticationEvent.password != null))
      {
        byte[] arrayOfByte2 = Converter.wcsToMbcs(null, localAuthenticationEvent.user, true);
        byte[] arrayOfByte3 = Converter.wcsToMbcs(null, localAuthenticationEvent.password, true);
        WebKitGTK.soup_auth_authenticate(paramInt3, arrayOfByte2, arrayOfByte3);
        OS.g_signal_stop_emission_by_name(paramInt1, WebKitGTK.authenticate);
        return 0;
      }
    }
    return 0;
  }
  
  int webkit_authenticate(int paramInt1, int paramInt2)
  {
    if (!WebKitGTK.webkit_authentication_request_is_retry(paramInt2)) {
      this.failureCount = 0;
    } else if (++this.failureCount >= 3) {
      return 0;
    }
    String str = getUrl();
    for (int i = 0; i < this.authenticationListeners.length; i++)
    {
      AuthenticationEvent localAuthenticationEvent = new AuthenticationEvent(this.browser);
      localAuthenticationEvent.location = str;
      this.authenticationListeners[i].authenticate(localAuthenticationEvent);
      if (!localAuthenticationEvent.doit)
      {
        WebKitGTK.webkit_authentication_request_cancel(paramInt2);
        return 0;
      }
      if ((localAuthenticationEvent.user != null) && (localAuthenticationEvent.password != null))
      {
        byte[] arrayOfByte1 = Converter.wcsToMbcs(null, localAuthenticationEvent.user, true);
        byte[] arrayOfByte2 = Converter.wcsToMbcs(null, localAuthenticationEvent.password, true);
        int j = WebKitGTK.webkit_credential_new(arrayOfByte1, arrayOfByte2, 0);
        WebKitGTK.webkit_authentication_request_authenticate(paramInt2, j);
        WebKitGTK.webkit_credential_free(j);
        return 0;
      }
    }
    return 0;
  }
  
  int webFrameProc(int paramInt1, int paramInt2, int paramInt3)
  {
    switch (paramInt3)
    {
    case 9: 
      return webframe_notify_load_status(paramInt1, paramInt2);
    case 16: 
      return webkit_load_changed(paramInt1, paramInt2, paramInt3);
    }
    return 0;
  }
  
  int webViewProc(int paramInt1, int paramInt2)
  {
    switch (paramInt2)
    {
    case 13: 
      return webkit_close_web_view(paramInt1);
    case 8: 
      return webkit_web_view_ready(paramInt1);
    }
    return 0;
  }
  
  int webViewProc(int paramInt1, int paramInt2, int paramInt3)
  {
    switch (paramInt3)
    {
    case 7: 
      return webkit_create_web_view(paramInt1, paramInt2);
    case 11: 
      return webkit_download_requested(paramInt1, paramInt2);
    case 9: 
      return webkit_notify_load_status(paramInt1, paramInt2);
    case 16: 
      return webkit_load_changed(paramInt1, paramInt2, paramInt3);
    case 2: 
      return webkit_notify_progress(paramInt1, paramInt2);
    case 4: 
      return webkit_notify_title(paramInt1, paramInt2);
    case 5: 
      return webkit_populate_popup(paramInt1, paramInt2);
    case 6: 
      return webkit_status_bar_text_changed(paramInt1, paramInt2);
    case 20: 
      return webkit_authenticate(paramInt1, paramInt2);
    }
    return 0;
  }
  
  int webViewProc(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    switch (paramInt4)
    {
    case 1: 
      return webkit_hovering_over_link(paramInt1, paramInt2, paramInt3);
    case 18: 
      return webkit_mouse_target_changed(paramInt1, paramInt2, paramInt3);
    case 17: 
      return webkit_decide_policy(paramInt1, paramInt2, paramInt3, paramInt4);
    }
    return 0;
  }
  
  int webViewProc(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
  {
    switch (paramInt5)
    {
    case 15: 
      return webkit_console_message(paramInt1, paramInt2, paramInt3, paramInt4);
    case 14: 
      return webkit_window_object_cleared(paramInt1, paramInt2, paramInt3, paramInt4);
    case 19: 
      return webkit_context_menu(paramInt1, paramInt2, paramInt3, paramInt4);
    }
    return 0;
  }
  
  int webViewProc(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6)
  {
    switch (paramInt6)
    {
    case 12: 
      return webkit_mime_type_policy_decision_requested(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
    case 3: 
      return webkit_navigation_policy_decision_requested(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
    case 10: 
      return webkit_resource_request_starting(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
    }
    return 0;
  }
  
  public void create(Composite paramComposite, int paramInt)
  {
    int n;
    if (ExternalClass == 0)
    {
      if (Device.DEBUG)
      {
        int i;
        int j;
        if (WEBKIT2)
        {
          i = WebKitGTK.webkit_get_major_version();
          j = WebKitGTK.webkit_get_minor_version();
          m = WebKitGTK.webkit_get_micro_version();
        }
        else
        {
          i = WebKitGTK.webkit_major_version();
          j = WebKitGTK.webkit_minor_version();
          m = WebKitGTK.webkit_micro_version();
        }
        System.out.println("WebKit version " + i + "." + j + "." + m);
      }
      localObject1 = new JSClassDefinition();
      byte[] arrayOfByte = Converter.wcsToMbcs(null, "External", true);
      ((JSClassDefinition)localObject1).className = C.malloc(arrayOfByte.length);
      OS.memmove(((JSClassDefinition)localObject1).className, arrayOfByte, arrayOfByte.length);
      ((JSClassDefinition)localObject1).hasProperty = JSObjectHasPropertyProc.getAddress();
      ((JSClassDefinition)localObject1).getProperty = JSObjectGetPropertyProc.getAddress();
      int m = C.malloc(JSClassDefinition.sizeof);
      WebKitGTK.memmove(m, (JSClassDefinition)localObject1, JSClassDefinition.sizeof);
      ExternalClass = WebKitGTK.JSClassCreate(m);
      arrayOfByte = Converter.wcsToMbcs(null, "POST", true);
      PostString = C.malloc(arrayOfByte.length);
      C.memmove(PostString, arrayOfByte, arrayOfByte.length);
      if (WEBKIT2)
      {
        WebKitGTK.webkit_web_context_set_favicon_database_directory(WebKitGTK.webkit_web_context_get_default(), 0);
      }
      else
      {
        n = WebKitGTK.webkit_get_favicon_database();
        if (n != 0) {
          WebKitGTK.webkit_favicon_database_set_path(n, 0);
        }
      }
    }
    if (!WEBKIT2)
    {
      this.scrolledWindow = OS.gtk_scrolled_window_new(0, 0);
      OS.gtk_scrolled_window_set_policy(this.scrolledWindow, 1, 1);
    }
    this.webView = WebKitGTK.webkit_web_view_new();
    this.webViewData = C.malloc(C.PTR_SIZEOF);
    C.memmove(this.webViewData, new int[] { this.webView }, C.PTR_SIZEOF);
    if (!WEBKIT2)
    {
      OS.gtk_container_add(this.scrolledWindow, this.webView);
      OS.gtk_container_add(this.browser.handle, this.scrolledWindow);
      OS.gtk_widget_show(this.scrolledWindow);
      OS.g_signal_connect(this.webView, WebKitGTK.close_web_view, Proc2.getAddress(), 13);
      OS.g_signal_connect(this.webView, WebKitGTK.console_message, Proc5.getAddress(), 15);
      OS.g_signal_connect(this.webView, WebKitGTK.create_web_view, Proc3.getAddress(), 7);
      OS.g_signal_connect(this.webView, WebKitGTK.notify_load_status, Proc3.getAddress(), 9);
      OS.g_signal_connect(this.webView, WebKitGTK.web_view_ready, Proc2.getAddress(), 8);
      OS.g_signal_connect(this.webView, WebKitGTK.navigation_policy_decision_requested, Proc6.getAddress(), 3);
      OS.g_signal_connect(this.webView, WebKitGTK.mime_type_policy_decision_requested, Proc6.getAddress(), 12);
      OS.g_signal_connect(this.webView, WebKitGTK.resource_request_starting, Proc6.getAddress(), 10);
      OS.g_signal_connect(this.webView, WebKitGTK.download_requested, Proc3.getAddress(), 11);
      OS.g_signal_connect(this.webView, WebKitGTK.hovering_over_link, Proc4.getAddress(), 1);
      OS.g_signal_connect(this.webView, WebKitGTK.populate_popup, Proc3.getAddress(), 5);
      OS.g_signal_connect(this.webView, WebKitGTK.notify_progress, Proc3.getAddress(), 2);
      OS.g_signal_connect(this.webView, WebKitGTK.window_object_cleared, Proc5.getAddress(), 14);
      OS.g_signal_connect(this.webView, WebKitGTK.status_bar_text_changed, Proc3.getAddress(), 6);
    }
    else
    {
      OS.gtk_container_add(this.browser.handle, this.webView);
      OS.g_signal_connect(this.webView, WebKitGTK.close, Proc2.getAddress(), 13);
      OS.g_signal_connect(this.webView, WebKitGTK.create, Proc3.getAddress(), 7);
      OS.g_signal_connect(this.webView, WebKitGTK.load_changed, Proc3.getAddress(), 16);
      OS.g_signal_connect(this.webView, WebKitGTK.ready_to_show, Proc2.getAddress(), 8);
      OS.g_signal_connect(this.webView, WebKitGTK.decide_policy, Proc4.getAddress(), 17);
      OS.g_signal_connect(WebKitGTK.webkit_web_context_get_default(), WebKitGTK.download_started, Proc3.getAddress(), 11);
      OS.g_signal_connect(this.webView, WebKitGTK.mouse_target_changed, Proc4.getAddress(), 18);
      OS.g_signal_connect(this.webView, WebKitGTK.context_menu, Proc5.getAddress(), 19);
      OS.g_signal_connect(this.webView, WebKitGTK.notify_estimated_load_progress, Proc3.getAddress(), 2);
      OS.g_signal_connect(this.webView, WebKitGTK.authenticate, Proc3.getAddress(), 20);
    }
    OS.gtk_widget_show(this.webView);
    OS.gtk_widget_show(this.browser.handle);
    OS.g_signal_connect(this.webView, WebKitGTK.notify_title, Proc3.getAddress(), 4);
    OS.g_signal_connect(this.webView, OS.button_press_event, JSDOMEventProc.getAddress(), 0);
    OS.g_signal_connect(this.webView, OS.button_release_event, JSDOMEventProc.getAddress(), 0);
    OS.g_signal_connect(this.webView, OS.key_press_event, JSDOMEventProc.getAddress(), 0);
    OS.g_signal_connect(this.webView, OS.key_release_event, JSDOMEventProc.getAddress(), 0);
    OS.g_signal_connect(this.webView, OS.scroll_event, JSDOMEventProc.getAddress(), 0);
    OS.g_signal_connect(this.webView, OS.motion_notify_event, JSDOMEventProc.getAddress(), 0);
    if (!WEBKIT2)
    {
      OS.g_signal_connect(this.scrolledWindow, OS.button_press_event, JSDOMEventProc.getAddress(), 1);
      OS.g_signal_connect(this.scrolledWindow, OS.button_release_event, JSDOMEventProc.getAddress(), 1);
      OS.g_signal_connect(this.scrolledWindow, OS.key_press_event, JSDOMEventProc.getAddress(), 1);
      OS.g_signal_connect(this.scrolledWindow, OS.key_release_event, JSDOMEventProc.getAddress(), 1);
      OS.g_signal_connect(this.scrolledWindow, OS.scroll_event, JSDOMEventProc.getAddress(), 1);
      OS.g_signal_connect(this.scrolledWindow, OS.motion_notify_event, JSDOMEventProc.getAddress(), 1);
    }
    Object localObject1 = Converter.wcsToMbcs(null, "UTF-8", true);
    int k = WebKitGTK.webkit_web_view_get_settings(this.webView);
    OS.g_object_set(k, WebKitGTK.javascript_can_open_windows_automatically, 1, 0);
    if (WEBKIT2)
    {
      OS.g_object_set(k, WebKitGTK.default_charset, (byte[])localObject1, 0);
    }
    else
    {
      OS.g_object_set(k, WebKitGTK.default_encoding, (byte[])localObject1, 0);
      OS.g_object_set(k, WebKitGTK.enable_universal_access_from_file_uris, 1, 0);
    }
    Listener local5 = new Listener()
    {
      public void handleEvent(Event paramAnonymousEvent)
      {
        switch (paramAnonymousEvent.type)
        {
        case 12: 
          if (WebKit.this.ignoreDispose)
          {
            WebKit.this.ignoreDispose = false;
          }
          else
          {
            WebKit.this.ignoreDispose = true;
            WebKit.this.browser.notifyListeners(paramAnonymousEvent.type, paramAnonymousEvent);
            paramAnonymousEvent.type = 0;
            WebKit.this.onDispose(paramAnonymousEvent);
          }
          break;
        case 15: 
          OS.gtk_widget_grab_focus(WebKit.this.webView);
          break;
        case 11: 
          WebKit.this.onResize(paramAnonymousEvent);
        }
      }
    };
    this.browser.addListener(12, local5);
    this.browser.addListener(15, local5);
    this.browser.addListener(1, local5);
    this.browser.addListener(11, local5);
    int i1;
    Object localObject2;
    Object localObject3;
    if (!WEBKIT2)
    {
      n = WebKitGTK.webkit_get_default_session();
      i1 = WebKitGTK.soup_session_get_feature(n, WebKitGTK.webkit_soup_auth_dialog_get_type());
      if (i1 != 0) {
        WebKitGTK.soup_session_feature_detach(i1, n);
      }
      OS.g_signal_connect(n, WebKitGTK.authenticate, Proc5.getAddress(), this.webView);
      if (i1 != 0) {
        WebKitGTK.soup_session_feature_attach(i1, n);
      }
      localObject2 = System.getProperty("network.proxy_host");
      localObject3 = System.getProperty("network.proxy_port");
      int i2 = -1;
      if (localObject3 != null) {
        try
        {
          int i3 = Integer.valueOf((String)localObject3).intValue();
          if ((0 <= i3) && (i3 <= 65535)) {
            i2 = i3;
          }
        }
        catch (NumberFormatException localNumberFormatException) {}
      }
      if ((localObject2 != null) || (i2 != -1))
      {
        if (!((String)localObject2).startsWith("http://")) {
          localObject2 = "http://" + (String)localObject2;
        }
        localObject2 = (String)localObject2 + ":" + i2;
        localObject1 = Converter.wcsToMbcs(null, (String)localObject2, true);
        int i4 = WebKitGTK.soup_uri_new((byte[])localObject1);
        if (i4 != 0)
        {
          OS.g_object_set(n, WebKitGTK.SOUP_SESSION_PROXY_URI, i4, 0);
          WebKitGTK.soup_uri_free(i4);
        }
      }
    }
    this.eventFunction = new BrowserFunction(this.browser, "HandleWebKitEvent")
    {
      public Object function(Object[] paramAnonymousArrayOfObject)
      {
        return WebKit.this.handleEventFromFunction(paramAnonymousArrayOfObject) ? Boolean.TRUE : Boolean.FALSE;
      }
    };
    this.browser.setData("org.eclipse.swt.internal.control.checksubwindow", Boolean.FALSE);
    if (WEBKIT2)
    {
      n = WebKitGTK.webkit_get_major_version();
      i1 = WebKitGTK.webkit_get_minor_version();
    }
    else
    {
      n = WebKitGTK.webkit_major_version();
      i1 = WebKitGTK.webkit_minor_version();
    }
    if ((n == 1) && (i1 >= 10))
    {
      localObject2 = this.browser.computeTrim(0, 0, 2, 2);
      localObject3 = this.browser.getSize();
      localObject3.x += ((Rectangle)localObject2).width;
      localObject3.y += ((Rectangle)localObject2).height;
      this.browser.setSize((Point)localObject3);
      localObject3.x -= ((Rectangle)localObject2).width;
      localObject3.y -= ((Rectangle)localObject2).height;
      this.browser.setSize((Point)localObject3);
    }
  }
  
  void addEventHandlers(int paramInt, boolean paramBoolean)
  {
    if (!this.jsEnabled) {
      return;
    }
    if ((paramBoolean) && (IsWebKit14orNewer))
    {
      int i = WebKitGTK.webkit_web_view_get_dom_document(paramInt);
      if (i != 0)
      {
        WindowMappings.put(new LONG(i), new LONG(paramInt));
        WebKitGTK.webkit_dom_event_target_add_event_listener(i, WebKitGTK.dragstart, JSDOMEventProc.getAddress(), 0, 29);
        WebKitGTK.webkit_dom_event_target_add_event_listener(i, WebKitGTK.keydown, JSDOMEventProc.getAddress(), 0, 1);
        WebKitGTK.webkit_dom_event_target_add_event_listener(i, WebKitGTK.keypress, JSDOMEventProc.getAddress(), 0, -1);
        WebKitGTK.webkit_dom_event_target_add_event_listener(i, WebKitGTK.keyup, JSDOMEventProc.getAddress(), 0, 2);
        WebKitGTK.webkit_dom_event_target_add_event_listener(i, WebKitGTK.mousedown, JSDOMEventProc.getAddress(), 0, 3);
        WebKitGTK.webkit_dom_event_target_add_event_listener(i, WebKitGTK.mousemove, JSDOMEventProc.getAddress(), 0, 5);
        WebKitGTK.webkit_dom_event_target_add_event_listener(i, WebKitGTK.mouseup, JSDOMEventProc.getAddress(), 0, 4);
        WebKitGTK.webkit_dom_event_target_add_event_listener(i, WebKitGTK.mousewheel, JSDOMEventProc.getAddress(), 0, 37);
      }
      return;
    }
    StringBuffer localStringBuffer = new StringBuffer("window.SWTkeyhandler = function SWTkeyhandler(e) {");
    localStringBuffer.append("try {e.returnValue = HandleWebKitEvent(e.type, e.keyCode, e.charCode, e.altKey, e.ctrlKey, e.shiftKey, e.metaKey);} catch (e) {}};");
    execute(localStringBuffer.toString());
    localStringBuffer = new StringBuffer("window.SWTmousehandler = function SWTmousehandler(e) {");
    localStringBuffer.append("try {e.returnValue = HandleWebKitEvent(e.type, e.screenX, e.screenY, e.detail, e.button, e.altKey, e.ctrlKey, e.shiftKey, e.metaKey, e.relatedTarget != null);} catch (e) {}};");
    execute(localStringBuffer.toString());
    if (paramBoolean)
    {
      localStringBuffer = new StringBuffer("document.addEventListener('keydown', SWTkeyhandler, true);");
      localStringBuffer.append("document.addEventListener('keypress', SWTkeyhandler, true);");
      localStringBuffer.append("document.addEventListener('keyup', SWTkeyhandler, true);");
      localStringBuffer.append("document.addEventListener('mousedown', SWTmousehandler, true);");
      localStringBuffer.append("document.addEventListener('mouseup', SWTmousehandler, true);");
      localStringBuffer.append("document.addEventListener('mousemove', SWTmousehandler, true);");
      localStringBuffer.append("document.addEventListener('mousewheel', SWTmousehandler, true);");
      localStringBuffer.append("document.addEventListener('dragstart', SWTmousehandler, true);");
      execute(localStringBuffer.toString());
      return;
    }
    localStringBuffer = new StringBuffer("for (var i = 0; i < frames.length; i++) {");
    localStringBuffer.append("frames[i].document.addEventListener('keydown', window.SWTkeyhandler, true);");
    localStringBuffer.append("frames[i].document.addEventListener('keypress', window.SWTkeyhandler, true);");
    localStringBuffer.append("frames[i].document.addEventListener('keyup', window.SWTkeyhandler, true);");
    localStringBuffer.append("frames[i].document.addEventListener('mousedown', window.SWTmousehandler, true);");
    localStringBuffer.append("frames[i].document.addEventListener('mouseup', window.SWTmousehandler, true);");
    localStringBuffer.append("frames[i].document.addEventListener('mousemove', window.SWTmousehandler, true);");
    localStringBuffer.append("frames[i].document.addEventListener('mouseover', window.SWTmousehandler, true);");
    localStringBuffer.append("frames[i].document.addEventListener('mouseout', window.SWTmousehandler, true);");
    localStringBuffer.append("frames[i].document.addEventListener('mousewheel', window.SWTmousehandler, true);");
    localStringBuffer.append("frames[i].document.addEventListener('dragstart', window.SWTmousehandler, true);");
    localStringBuffer.append('}');
    execute(localStringBuffer.toString());
  }
  
  public boolean back()
  {
    if (WebKitGTK.webkit_web_view_can_go_back(this.webView) == 0) {
      return false;
    }
    WebKitGTK.webkit_web_view_go_back(this.webView);
    return true;
  }
  
  public boolean close()
  {
    return close(true);
  }
  
  boolean close(boolean paramBoolean)
  {
    if (!this.jsEnabled) {
      return true;
    }
    String str1 = Compatibility.getMessage("SWT_OnBeforeUnload_Message1");
    String str2 = Compatibility.getMessage("SWT_OnBeforeUnload_Message2");
    String str3 = "SWTExecuteTemporaryFunctionCLOSE";
    StringBuffer localStringBuffer = new StringBuffer("function ");
    localStringBuffer.append(str3);
    localStringBuffer.append("(win) {\n");
    localStringBuffer.append("var fn = win.onbeforeunload; if (fn != null) {try {var str = fn(); ");
    if (paramBoolean)
    {
      localStringBuffer.append("if (str != null) { ");
      localStringBuffer.append("var result = confirm('");
      localStringBuffer.append(str1);
      localStringBuffer.append("\\n\\n'+str+'\\n\\n");
      localStringBuffer.append(str2);
      localStringBuffer.append("');");
      localStringBuffer.append("if (!result) return false;}");
    }
    localStringBuffer.append("} catch (e) {}}");
    localStringBuffer.append("try {for (var i = 0; i < win.frames.length; i++) {var result = ");
    localStringBuffer.append(str3);
    localStringBuffer.append("(win.frames[i]); if (!result) return false;}} catch (e) {} return true;");
    localStringBuffer.append("\n};");
    execute(localStringBuffer.toString());
    Boolean localBoolean = (Boolean)evaluate("return " + str3 + "(window);");
    if (localBoolean == null) {
      return false;
    }
    return localBoolean.booleanValue();
  }
  
  public boolean execute(String paramString)
  {
    byte[] arrayOfByte = null;
    try
    {
      arrayOfByte = (paramString + '\000').getBytes("UTF-8");
    }
    catch (UnsupportedEncodingException localUnsupportedEncodingException1)
    {
      arrayOfByte = Converter.wcsToMbcs(null, paramString, true);
    }
    int i = WebKitGTK.JSStringCreateWithUTF8CString(arrayOfByte);
    try
    {
      arrayOfByte = (getUrl() + '\000').getBytes("UTF-8");
    }
    catch (UnsupportedEncodingException localUnsupportedEncodingException2)
    {
      arrayOfByte = Converter.wcsToMbcs(null, getUrl(), true);
    }
    int j = 0;
    if (WEBKIT2)
    {
      WebKitGTK.webkit_web_view_run_javascript(this.webView, i, 0, 0, 0);
    }
    else
    {
      int k = WebKitGTK.JSStringCreateWithUTF8CString(arrayOfByte);
      int m = WebKitGTK.webkit_web_view_get_main_frame(this.webView);
      int n = WebKitGTK.webkit_web_frame_get_global_context(m);
      j = WebKitGTK.JSEvaluateScript(n, i, 0, k, 0, null);
      WebKitGTK.JSStringRelease(k);
    }
    WebKitGTK.JSStringRelease(i);
    return j != 0;
  }
  
  public boolean forward()
  {
    if (WebKitGTK.webkit_web_view_can_go_forward(this.webView) == 0) {
      return false;
    }
    WebKitGTK.webkit_web_view_go_forward(this.webView);
    return true;
  }
  
  public String getBrowserType()
  {
    return "webkit";
  }
  
  public String getText()
  {
    int i = WebKitGTK.webkit_web_view_get_main_frame(this.webView);
    int j = WebKitGTK.webkit_web_frame_get_data_source(i);
    if (j == 0) {
      return "";
    }
    int k = WebKitGTK.webkit_web_data_source_get_data(j);
    if (k == 0) {
      return "";
    }
    int m = WebKitGTK.webkit_web_data_source_get_encoding(j);
    int n = OS.strlen(m);
    byte[] arrayOfByte = new byte[n];
    OS.memmove(arrayOfByte, m, n);
    String str = new String(Converter.mbcsToWcs(null, arrayOfByte));
    n = OS.GString_len(k);
    arrayOfByte = new byte[n];
    int i1 = OS.GString_str(k);
    C.memmove(arrayOfByte, i1, n);
    try
    {
      return new String(arrayOfByte, str);
    }
    catch (UnsupportedEncodingException localUnsupportedEncodingException) {}
    return new String(Converter.mbcsToWcs(null, arrayOfByte));
  }
  
  public String getUrl()
  {
    int i = WebKitGTK.webkit_web_view_get_uri(this.webView);
    if (i == 0) {
      return "about:blank";
    }
    int j = OS.strlen(i);
    byte[] arrayOfByte = new byte[j];
    OS.memmove(arrayOfByte, i, j);
    String str = new String(Converter.mbcsToWcs(null, arrayOfByte));
    if (str.equals("file:///"))
    {
      str = "about:blank";
    }
    else
    {
      j = "file:///".length();
      if ((str.startsWith("file:///")) && (str.charAt(j) == '#')) {
        str = "about:blank" + str.substring(j);
      }
    }
    return str;
  }
  
  boolean handleDOMEvent(int paramInt1, int paramInt2)
  {
    String str = null;
    int i = 0;
    switch (paramInt2)
    {
    case 29: 
      str = "dragstart";
      i = 1;
      break;
    case 3: 
      str = "mousedown";
      i = 1;
      break;
    case 5: 
      str = "mousemove";
      i = 1;
      break;
    case 4: 
      str = "mouseup";
      i = 1;
      break;
    case 37: 
      str = "mousewheel";
      i = 1;
      break;
    case 1: 
      str = "keydown";
      break;
    case 2: 
      str = "keyup";
      break;
    case -1: 
      str = "keypress";
    }
    if (i != 0)
    {
      j = (int)WebKitGTK.webkit_dom_mouse_event_get_screen_x(paramInt1);
      k = (int)WebKitGTK.webkit_dom_mouse_event_get_screen_y(paramInt1);
      int m = WebKitGTK.webkit_dom_mouse_event_get_button(paramInt1) + 1;
      boolean bool1 = WebKitGTK.webkit_dom_mouse_event_get_alt_key(paramInt1) != 0;
      bool2 = WebKitGTK.webkit_dom_mouse_event_get_ctrl_key(paramInt1) != 0;
      bool3 = WebKitGTK.webkit_dom_mouse_event_get_shift_key(paramInt1) != 0;
      bool4 = WebKitGTK.webkit_dom_mouse_event_get_meta_key(paramInt1) != 0;
      int i2 = (int)WebKitGTK.webkit_dom_ui_event_get_detail(paramInt1);
      boolean bool5 = false;
      return handleMouseEvent(str, j, k, i2, m, bool1, bool2, bool3, bool4, bool5);
    }
    int j = 0;
    int k = OS.gtk_get_current_event();
    if (k != 0)
    {
      GdkEventKey localGdkEventKey = new GdkEventKey();
      OS.memmove(localGdkEventKey, k, GdkEventKey.sizeof);
      switch (localGdkEventKey.type)
      {
      case 8: 
      case 9: 
        j = localGdkEventKey.state;
      }
      OS.gdk_event_free(k);
    }
    int n = (int)WebKitGTK.webkit_dom_ui_event_get_key_code(paramInt1);
    int i1 = (int)WebKitGTK.webkit_dom_ui_event_get_char_code(paramInt1);
    boolean bool2 = (j & 0x8) != 0;
    boolean bool3 = (j & 0x4) != 0;
    boolean bool4 = (j & 0x1) != 0;
    return handleKeyEvent(str, n, i1, bool2, bool3, bool4, false);
  }
  
  boolean handleEventFromFunction(Object[] paramArrayOfObject)
  {
    String str = (String)paramArrayOfObject[0];
    if ((str.equals("keydown")) || (str.equals("keypress")) || (str.equals("keyup"))) {
      return handleKeyEvent(str, ((Double)paramArrayOfObject[1]).intValue(), ((Double)paramArrayOfObject[2]).intValue(), ((Boolean)paramArrayOfObject[3]).booleanValue(), ((Boolean)paramArrayOfObject[4]).booleanValue(), ((Boolean)paramArrayOfObject[5]).booleanValue(), ((Boolean)paramArrayOfObject[6]).booleanValue());
    }
    return handleMouseEvent(str, ((Double)paramArrayOfObject[1]).intValue(), ((Double)paramArrayOfObject[2]).intValue(), ((Double)paramArrayOfObject[3]).intValue(), (paramArrayOfObject[4] != null ? ((Double)paramArrayOfObject[4]).intValue() : 0) + 1, ((Boolean)paramArrayOfObject[5]).booleanValue(), ((Boolean)paramArrayOfObject[6]).booleanValue(), ((Boolean)paramArrayOfObject[7]).booleanValue(), ((Boolean)paramArrayOfObject[8]).booleanValue(), ((Boolean)paramArrayOfObject[9]).booleanValue());
  }
  
  boolean handleKeyEvent(String paramString, int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4)
  {
    if (paramString.equals("keydown"))
    {
      paramInt1 = translateKey(paramInt1);
      this.lastKeyCode = paramInt1;
      switch (paramInt1)
      {
      case 8: 
      case 9: 
      case 27: 
      case 127: 
      case 65536: 
      case 131072: 
      case 262144: 
      case 4194304: 
      case 16777217: 
      case 16777218: 
      case 16777219: 
      case 16777220: 
      case 16777221: 
      case 16777222: 
      case 16777223: 
      case 16777224: 
      case 16777225: 
      case 16777226: 
      case 16777227: 
      case 16777228: 
      case 16777229: 
      case 16777230: 
      case 16777231: 
      case 16777232: 
      case 16777233: 
      case 16777234: 
      case 16777235: 
      case 16777236: 
      case 16777237: 
      case 16777298: 
      case 16777299: 
      case 16777300: 
      case 16777301: 
        localEvent = new Event();
        localEvent.widget = this.browser;
        localEvent.type = (paramString.equals("keydown") ? 1 : 2);
        localEvent.keyCode = paramInt1;
        switch (paramInt1)
        {
        case 8: 
          localEvent.character = '\b';
          break;
        case 127: 
          localEvent.character = '';
          break;
        case 27: 
          localEvent.character = '\033';
          break;
        case 9: 
          localEvent.character = '\t';
        }
        this.lastCharCode = localEvent.character;
        localEvent.stateMask = ((paramBoolean1 ? 65536 : 0) | (paramBoolean2 ? 262144 : 0) | (paramBoolean3 ? 131072 : 0) | (paramBoolean4 ? 4194304 : 0));
        localEvent.stateMask &= (paramInt1 ^ 0xFFFFFFFF);
        final int i = localEvent.stateMask;
        if ((!sendKeyEvent(localEvent)) || (this.browser.isDisposed())) {
          return false;
        }
        if ((this.browser.isFocusControl()) && (paramInt1 == 9) && ((i & 0x50000) == 0)) {
          this.browser.getDisplay().asyncExec(new Runnable()
          {
            public void run()
            {
              if (WebKit.this.browser.isDisposed()) {
                return;
              }
              if (WebKit.this.browser.getDisplay().getFocusControl() == null)
              {
                int i = (i & 0x20000) != 0 ? 8 : 16;
                WebKit.this.browser.traverse(i);
              }
            }
          });
        }
        break;
      }
      return true;
    }
    if (paramString.equals("keypress"))
    {
      if (this.lastKeyCode == 0) {
        return true;
      }
      this.lastCharCode = paramInt2;
      if ((paramBoolean2) && (0 <= this.lastCharCode) && (this.lastCharCode <= 127))
      {
        if ((97 <= this.lastCharCode) && (this.lastCharCode <= 122)) {
          this.lastCharCode -= 32;
        }
        if ((64 <= this.lastCharCode) && (this.lastCharCode <= 95)) {
          this.lastCharCode -= 64;
        }
      }
      localEvent = new Event();
      localEvent.widget = this.browser;
      localEvent.type = 1;
      localEvent.keyCode = this.lastKeyCode;
      localEvent.character = ((char)this.lastCharCode);
      localEvent.stateMask = ((paramBoolean1 ? 65536 : 0) | (paramBoolean2 ? 262144 : 0) | (paramBoolean3 ? 131072 : 0) | (paramBoolean4 ? 4194304 : 0));
      return (sendKeyEvent(localEvent)) && (!this.browser.isDisposed());
    }
    paramInt1 = translateKey(paramInt1);
    if (paramInt1 == 0) {
      return true;
    }
    if (paramInt1 != this.lastKeyCode)
    {
      this.lastKeyCode = paramInt1;
      this.lastCharCode = 0;
    }
    Event localEvent = new Event();
    localEvent.widget = this.browser;
    localEvent.type = 2;
    localEvent.keyCode = this.lastKeyCode;
    localEvent.character = ((char)this.lastCharCode);
    localEvent.stateMask = ((paramBoolean1 ? 65536 : 0) | (paramBoolean2 ? 262144 : 0) | (paramBoolean3 ? 131072 : 0) | (paramBoolean4 ? 4194304 : 0));
    switch (this.lastKeyCode)
    {
    case 65536: 
    case 131072: 
    case 262144: 
    case 4194304: 
      localEvent.stateMask |= this.lastKeyCode;
    }
    this.browser.notifyListeners(localEvent.type, localEvent);
    this.lastKeyCode = (this.lastCharCode = 0);
    return (localEvent.doit) && (!this.browser.isDisposed());
  }
  
  boolean handleMouseEvent(String paramString, int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4, boolean paramBoolean5)
  {
    Point localPoint = new Point(paramInt1, paramInt2);
    localPoint = this.browser.getDisplay().map(null, this.browser, localPoint);
    Event localEvent = new Event();
    localEvent.widget = this.browser;
    localEvent.x = localPoint.x;
    localEvent.y = localPoint.y;
    int i = (paramBoolean1 ? 65536 : 0) | (paramBoolean2 ? 262144 : 0) | (paramBoolean3 ? 131072 : 0) | (paramBoolean4 ? 4194304 : 0);
    localEvent.stateMask = i;
    if (paramString.equals("mousedown"))
    {
      localEvent.type = 3;
      localEvent.count = paramInt3;
      localEvent.button = paramInt4;
      this.browser.notifyListeners(localEvent.type, localEvent);
      if (this.browser.isDisposed()) {
        return true;
      }
      if (paramInt3 == 2)
      {
        localEvent = new Event();
        localEvent.type = 8;
        localEvent.widget = this.browser;
        localEvent.x = localPoint.x;
        localEvent.y = localPoint.y;
        localEvent.stateMask = i;
        localEvent.count = paramInt3;
        localEvent.button = paramInt4;
        this.browser.notifyListeners(localEvent.type, localEvent);
      }
      return true;
    }
    if (paramString.equals("mouseup"))
    {
      localEvent.type = 4;
      localEvent.count = paramInt3;
      localEvent.button = paramInt4;
    }
    else if (paramString.equals("mousemove"))
    {
      localEvent.type = 5;
    }
    else if (paramString.equals("mousewheel"))
    {
      localEvent.type = 37;
      localEvent.count = paramInt3;
    }
    else if (paramString.equals("dragstart"))
    {
      localEvent.type = 29;
      localEvent.button = paramInt4;
      switch (localEvent.button)
      {
      case 1: 
        localEvent.stateMask |= 0x80000;
        break;
      case 2: 
        localEvent.stateMask |= 0x100000;
        break;
      case 3: 
        localEvent.stateMask |= 0x200000;
        break;
      case 4: 
        localEvent.stateMask |= 0x800000;
        break;
      case 5: 
        localEvent.stateMask |= 0x2000000;
      }
      if (!IsWebKit14orNewer)
      {
        this.browser.notifyListeners(localEvent.type, localEvent);
        return false;
      }
    }
    this.browser.notifyListeners(localEvent.type, localEvent);
    return true;
  }
  
  int handleLoadCommitted(int paramInt, boolean paramBoolean)
  {
    int i = OS.strlen(paramInt);
    byte[] arrayOfByte = new byte[i];
    OS.memmove(arrayOfByte, paramInt, i);
    String str = new String(Converter.mbcsToWcs(null, arrayOfByte));
    if (str.equals("file:///"))
    {
      str = "about:blank";
    }
    else
    {
      i = "file:///".length();
      if ((str.startsWith("file:///")) && (str.charAt(i) == '#')) {
        str = "about:blank" + str.substring(i);
      }
    }
    if ((paramBoolean) && (str.startsWith("about:blank")) && (this.htmlBytes != null)) {
      return 0;
    }
    LocationEvent localLocationEvent = new LocationEvent(this.browser);
    localLocationEvent.display = this.browser.getDisplay();
    localLocationEvent.widget = this.browser;
    localLocationEvent.location = str;
    localLocationEvent.top = paramBoolean;
    for (int j = 0; j < this.locationListeners.length; j++) {
      this.locationListeners[j].changed(localLocationEvent);
    }
    return 0;
  }
  
  private void fireNewTitleEvent(String paramString)
  {
    TitleEvent localTitleEvent = new TitleEvent(this.browser);
    localTitleEvent.display = this.browser.getDisplay();
    localTitleEvent.widget = this.browser;
    localTitleEvent.title = paramString;
    for (int i = 0; i < this.titleListeners.length; i++) {
      this.titleListeners[i].changed(localTitleEvent);
    }
  }
  
  private void fireProgressCompletedEvent()
  {
    ProgressEvent localProgressEvent = new ProgressEvent(this.browser);
    localProgressEvent.display = this.browser.getDisplay();
    localProgressEvent.widget = this.browser;
    localProgressEvent.current = 100;
    localProgressEvent.total = 100;
    for (int i = 0; i < this.progressListeners.length; i++) {
      this.progressListeners[i].completed(localProgressEvent);
    }
  }
  
  int handleLoadFinished(int paramInt, boolean paramBoolean)
  {
    int i = OS.strlen(paramInt);
    byte[] arrayOfByte1 = new byte[i];
    OS.memmove(arrayOfByte1, paramInt, i);
    String str = new String(Converter.mbcsToWcs(null, arrayOfByte1));
    if (str.equals("file:///"))
    {
      str = "about:blank";
    }
    else
    {
      i = "file:///".length();
      if ((str.startsWith("file:///")) && (str.charAt(i) == '#')) {
        str = "about:blank" + str.substring(i);
      }
    }
    if ((paramBoolean) && (this.htmlBytes != null) && (str.startsWith("about:blank")))
    {
      this.loadingText = true;
      byte[] arrayOfByte2 = Converter.wcsToMbcs(null, "text/html", true);
      byte[] arrayOfByte3 = Converter.wcsToMbcs(null, "UTF-8", true);
      byte[] arrayOfByte4;
      if (this.untrustedText) {
        arrayOfByte4 = Converter.wcsToMbcs(null, "about:blank", true);
      } else {
        arrayOfByte4 = Converter.wcsToMbcs(null, "file:///", true);
      }
      WebKitGTK.webkit_web_view_load_string(this.webView, this.htmlBytes, arrayOfByte2, arrayOfByte3, arrayOfByte4);
      this.htmlBytes = null;
    }
    if (!this.loadingText)
    {
      if (paramBoolean)
      {
        int j = WebKitGTK.webkit_web_view_get_main_frame(this.webView);
        int k = WebKitGTK.webkit_web_frame_get_title(j);
        if (k == 0)
        {
          fireNewTitleEvent(str);
          if (this.browser.isDisposed()) {
            return 0;
          }
        }
      }
      fireProgressCompletedEvent();
    }
    this.loadingText = false;
    return 0;
  }
  
  public boolean isBackEnabled()
  {
    return WebKitGTK.webkit_web_view_can_go_back(this.webView) != 0;
  }
  
  public boolean isForwardEnabled()
  {
    return WebKitGTK.webkit_web_view_can_go_forward(this.webView) != 0;
  }
  
  void onDispose(Event paramEvent)
  {
    if ((!this.browser.isDisposed()) && (!this.browser.isClosing)) {
      close(false);
    }
    Enumeration localEnumeration = this.functions.elements();
    while (localEnumeration.hasMoreElements()) {
      ((BrowserFunction)localEnumeration.nextElement()).dispose(false);
    }
    this.functions = null;
    if (this.eventFunction != null)
    {
      this.eventFunction.dispose(false);
      this.eventFunction = null;
    }
    C.free(this.webViewData);
    this.postData = null;
    this.headers = null;
    this.htmlBytes = null;
  }
  
  void onResize(Event paramEvent)
  {
    Rectangle localRectangle = this.browser.getClientArea();
    if (WEBKIT2) {
      OS.gtk_widget_set_size_request(this.webView, localRectangle.width, localRectangle.height);
    } else {
      OS.gtk_widget_set_size_request(this.scrolledWindow, localRectangle.width, localRectangle.height);
    }
  }
  
  void openDownloadWindow(final int paramInt)
  {
    final Shell localShell = new Shell();
    String str1 = Compatibility.getMessage("SWT_FileDownload");
    localShell.setText(str1);
    GridLayout localGridLayout = new GridLayout();
    localGridLayout.marginHeight = 15;
    localGridLayout.marginWidth = 15;
    localGridLayout.verticalSpacing = 20;
    localShell.setLayout(localGridLayout);
    int i = WebKitGTK.webkit_download_get_suggested_filename(paramInt);
    int j = OS.strlen(i);
    byte[] arrayOfByte = new byte[j];
    OS.memmove(arrayOfByte, i, j);
    String str2 = new String(Converter.mbcsToWcs(null, arrayOfByte));
    int k = WebKitGTK.webkit_download_get_uri(paramInt);
    j = OS.strlen(k);
    arrayOfByte = new byte[j];
    OS.memmove(arrayOfByte, k, j);
    String str3 = new String(Converter.mbcsToWcs(null, arrayOfByte));
    str1 = Compatibility.getMessage("SWT_Download_Location", new Object[] { str2, str3 });
    Label localLabel1 = new Label(localShell, 64);
    localLabel1.setText(str1);
    GridData localGridData = new GridData();
    Monitor localMonitor = this.browser.getMonitor();
    int m = localMonitor.getBounds().width / 2;
    int n = localLabel1.computeSize(-1, -1).x;
    localGridData.widthHint = Math.min(n, m);
    localGridData.horizontalAlignment = 4;
    localGridData.grabExcessHorizontalSpace = true;
    localLabel1.setLayoutData(localGridData);
    final Label localLabel2 = new Label(localShell, 0);
    localLabel2.setText(Compatibility.getMessage("SWT_Download_Started"));
    localGridData = new GridData(1808);
    localLabel2.setLayoutData(localGridData);
    final Button localButton = new Button(localShell, 8);
    localButton.setText(Compatibility.getMessage("SWT_Cancel"));
    localGridData = new GridData();
    localGridData.horizontalAlignment = 2;
    localButton.setLayoutData(localGridData);
    final Listener local8 = new Listener()
    {
      public void handleEvent(Event paramAnonymousEvent)
      {
        WebKitGTK.webkit_download_cancel(paramInt);
      }
    };
    localButton.addListener(13, local8);
    OS.g_object_ref(paramInt);
    final Display localDisplay = this.browser.getDisplay();
    localDisplay.timerExec(500, new Runnable()
    {
      public void run()
      {
        int i = WebKitGTK.webkit_download_get_status(paramInt);
        if ((localShell.isDisposed()) || (i == 3) || (i == 2))
        {
          localShell.dispose();
          localDisplay.timerExec(-1, this);
          OS.g_object_unref(paramInt);
          return;
        }
        if (i == -1)
        {
          localLabel2.setText(Compatibility.getMessage("SWT_Download_Error"));
          localDisplay.timerExec(-1, this);
          OS.g_object_unref(paramInt);
          localButton.removeListener(13, local8);
          localButton.addListener(13, new Listener()
          {
            public void handleEvent(Event paramAnonymous2Event)
            {
              WebKit.9.this.val$shell.dispose();
            }
          });
          return;
        }
        long l1 = WebKitGTK.webkit_download_get_current_size(paramInt) / 1024L;
        long l2 = WebKitGTK.webkit_download_get_total_size(paramInt) / 1024L;
        String str = Compatibility.getMessage("SWT_Download_Status", new Object[] { new Long(l1), new Long(l2) });
        localLabel2.setText(str);
        localDisplay.timerExec(500, this);
      }
    });
    localShell.pack();
    localShell.open();
  }
  
  public void refresh()
  {
    WebKitGTK.webkit_web_view_reload(this.webView);
  }
  
  public boolean setText(String paramString, boolean paramBoolean)
  {
    byte[] arrayOfByte1 = null;
    try
    {
      arrayOfByte1 = (paramString + '\000').getBytes("UTF-8");
    }
    catch (UnsupportedEncodingException localUnsupportedEncodingException)
    {
      arrayOfByte1 = Converter.wcsToMbcs(null, paramString, true);
    }
    int i = this.htmlBytes != null ? 1 : 0;
    this.htmlBytes = arrayOfByte1;
    this.untrustedText = (!paramBoolean);
    byte[] arrayOfByte2;
    if (WEBKIT2)
    {
      if (this.untrustedText) {
        arrayOfByte2 = Converter.wcsToMbcs(null, "about:blank", true);
      } else {
        arrayOfByte2 = Converter.wcsToMbcs(null, "file:///", true);
      }
      WebKitGTK.webkit_web_view_load_html(this.webView, this.htmlBytes, arrayOfByte2);
    }
    else
    {
      if (i != 0) {
        return true;
      }
      arrayOfByte2 = Converter.wcsToMbcs(null, "about:blank", true);
      WebKitGTK.webkit_web_view_load_uri(this.webView, arrayOfByte2);
    }
    return true;
  }
  
  public boolean setUrl(String paramString1, String paramString2, String[] paramArrayOfString)
  {
    this.postData = paramString2;
    this.headers = paramArrayOfString;
    try
    {
      new URL(paramString1);
    }
    catch (MalformedURLException localMalformedURLException1)
    {
      String str1 = null;
      if (paramString1.charAt(0) == SEPARATOR_FILE) {
        str1 = "file://" + paramString1;
      } else {
        str1 = "http://" + paramString1;
      }
      try
      {
        new URL(str1);
        paramString1 = str1;
      }
      catch (MalformedURLException localMalformedURLException2) {}
    }
    int i = WebKitGTK.webkit_web_view_get_settings(this.webView);
    int m;
    if (paramArrayOfString != null) {
      for (int j = 0; j < paramArrayOfString.length; j++)
      {
        String str2 = paramArrayOfString[j];
        if (str2 != null)
        {
          m = str2.indexOf(':');
          if (m != -1)
          {
            String str3 = str2.substring(0, m).trim();
            String str4 = str2.substring(m + 1).trim();
            if ((str3.length() > 0) && (str4.length() > 0) && (str3.equalsIgnoreCase("user-agent")))
            {
              byte[] arrayOfByte2 = Converter.wcsToMbcs(null, str4, true);
              OS.g_object_set(i, WebKitGTK.user_agent, arrayOfByte2, 0);
            }
          }
        }
      }
    }
    byte[] arrayOfByte1 = Converter.wcsToMbcs(null, paramString1, true);
    if ((WEBKIT2) && (paramArrayOfString != null))
    {
      int k = WebKitGTK.webkit_uri_request_new(arrayOfByte1);
      m = WebKitGTK.webkit_uri_request_get_http_headers(k);
      addRequestHeaders(m, paramArrayOfString);
      WebKitGTK.webkit_web_view_load_request(this.webView, k);
      return true;
    }
    WebKitGTK.webkit_web_view_load_uri(this.webView, arrayOfByte1);
    OS.g_object_set(i, WebKitGTK.user_agent, 0, 0);
    return true;
  }
  
  public void stop()
  {
    WebKitGTK.webkit_web_view_stop_loading(this.webView);
  }
  
  int webframe_notify_load_status(int paramInt1, int paramInt2)
  {
    int i = WebKitGTK.webkit_web_frame_get_load_status(paramInt1);
    int j;
    switch (i)
    {
    case 1: 
      j = WebKitGTK.webkit_web_frame_get_uri(paramInt1);
      return handleLoadCommitted(j, false);
    case 2: 
      j = WebKitGTK.webkit_web_frame_get_parent(paramInt1);
      if (WebKitGTK.webkit_web_frame_get_load_status(j) == 2)
      {
        int k = WebKitGTK.webkit_web_frame_get_uri(paramInt1);
        return handleLoadFinished(k, false);
      }
      break;
    }
    return 0;
  }
  
  int webkit_close_web_view(int paramInt)
  {
    WindowEvent localWindowEvent = new WindowEvent(this.browser);
    localWindowEvent.display = this.browser.getDisplay();
    localWindowEvent.widget = this.browser;
    for (int i = 0; i < this.closeWindowListeners.length; i++) {
      this.closeWindowListeners[i].close(localWindowEvent);
    }
    this.browser.dispose();
    return 0;
  }
  
  int webkit_console_message(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    return 1;
  }
  
  int webkit_create_web_view(int paramInt1, int paramInt2)
  {
    WindowEvent localWindowEvent = new WindowEvent(this.browser);
    localWindowEvent.display = this.browser.getDisplay();
    localWindowEvent.widget = this.browser;
    localWindowEvent.required = true;
    if (this.openWindowListeners != null) {
      for (int i = 0; i < this.openWindowListeners.length; i++) {
        this.openWindowListeners[i].open(localWindowEvent);
      }
    }
    Browser localBrowser = null;
    if ((localWindowEvent.browser != null) && ((localWindowEvent.browser.webBrowser instanceof WebKit))) {
      localBrowser = localWindowEvent.browser;
    }
    if ((localBrowser != null) && (!localBrowser.isDisposed())) {
      return ((WebKit)localBrowser.webBrowser).webView;
    }
    return 0;
  }
  
  int webkit_download_requested(int paramInt1, int paramInt2)
  {
    int i = WebKitGTK.webkit_download_get_suggested_filename(paramInt2);
    int j = OS.strlen(i);
    byte[] arrayOfByte = new byte[j];
    OS.memmove(arrayOfByte, i, j);
    final String str = new String(Converter.mbcsToWcs(null, arrayOfByte));
    final int k = WebKitGTK.webkit_download_get_network_request(paramInt2);
    OS.g_object_ref(k);
    this.browser.getDisplay().asyncExec(new Runnable()
    {
      public void run()
      {
        if (!WebKit.this.browser.isDisposed())
        {
          FileDialog localFileDialog = new FileDialog(WebKit.this.browser.getShell(), 8192);
          localFileDialog.setFileName(str);
          String str1 = Compatibility.getMessage("SWT_FileDownload");
          localFileDialog.setText(str1);
          String str2 = localFileDialog.open();
          if (str2 != null)
          {
            str2 = "file:///" + str2;
            int i = WebKitGTK.webkit_download_new(k);
            byte[] arrayOfByte = Converter.wcsToMbcs(null, str2, true);
            WebKitGTK.webkit_download_set_destination_uri(i, arrayOfByte);
            WebKit.this.openDownloadWindow(i);
            WebKitGTK.webkit_download_start(i);
            OS.g_object_unref(i);
          }
        }
        OS.g_object_unref(k);
      }
    });
    return 1;
  }
  
  int webkit_mouse_target_changed(int paramInt1, int paramInt2, int paramInt3)
  {
    if (WebKitGTK.webkit_hit_test_result_context_is_link(paramInt2))
    {
      int i = WebKitGTK.webkit_hit_test_result_get_link_uri(paramInt2);
      int j = WebKitGTK.webkit_hit_test_result_get_link_title(paramInt2);
      return webkit_hovering_over_link(paramInt1, j, i);
    }
    return 0;
  }
  
  int webkit_hovering_over_link(int paramInt1, int paramInt2, int paramInt3)
  {
    if (paramInt3 != 0)
    {
      int i = OS.strlen(paramInt3);
      byte[] arrayOfByte = new byte[i];
      OS.memmove(arrayOfByte, paramInt3, i);
      String str = new String(Converter.mbcsToWcs(null, arrayOfByte));
      StatusTextEvent localStatusTextEvent = new StatusTextEvent(this.browser);
      localStatusTextEvent.display = this.browser.getDisplay();
      localStatusTextEvent.widget = this.browser;
      localStatusTextEvent.text = str;
      for (int j = 0; j < this.statusTextListeners.length; j++) {
        this.statusTextListeners[j].changed(localStatusTextEvent);
      }
    }
    return 0;
  }
  
  int webkit_mime_type_policy_decision_requested(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
  {
    int i = WebKitGTK.webkit_web_view_can_show_mime_type(this.webView, paramInt4) != 0 ? 1 : 0;
    if (i == 0)
    {
      WebKitGTK.webkit_web_policy_decision_download(paramInt5);
      return 1;
    }
    return 0;
  }
  
  int webkit_navigation_policy_decision_requested(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
  {
    if (this.loadingText) {
      return 0;
    }
    int i = WebKitGTK.webkit_network_request_get_uri(paramInt3);
    int j = OS.strlen(i);
    byte[] arrayOfByte = new byte[j];
    OS.memmove(arrayOfByte, i, j);
    String str = new String(Converter.mbcsToWcs(null, arrayOfByte));
    if (str.equals("file:///"))
    {
      str = "about:blank";
    }
    else
    {
      j = "file:///".length();
      if ((str.startsWith("file:///")) && (str.charAt(j) == '#')) {
        str = "about:blank" + str.substring(j);
      }
    }
    LocationEvent localLocationEvent = new LocationEvent(this.browser);
    localLocationEvent.display = this.browser.getDisplay();
    localLocationEvent.widget = this.browser;
    localLocationEvent.location = str;
    localLocationEvent.doit = true;
    int k;
    if (this.locationListeners != null) {
      for (k = 0; k < this.locationListeners.length; k++) {
        this.locationListeners[k].changing(localLocationEvent);
      }
    }
    if ((localLocationEvent.doit) && (!this.browser.isDisposed()))
    {
      if (this.jsEnabled != this.jsEnabledOnNextPage)
      {
        this.jsEnabled = this.jsEnabledOnNextPage;
        DisabledJSCount += (!this.jsEnabled ? 1 : -1);
        k = WebKitGTK.webkit_web_view_get_settings(this.webView);
        OS.g_object_set(k, WebKitGTK.enable_scripts, this.jsEnabled ? 1 : 0, 0);
      }
      k = WebKitGTK.webkit_web_view_get_main_frame(this.webView);
      if (paramInt2 != k)
      {
        int m = OS.g_signal_handler_find(paramInt2, 24, 0, 0, 0, Proc3.getAddress(), 9);
        if (m == 0) {
          OS.g_signal_connect(paramInt2, WebKitGTK.notify_load_status, Proc3.getAddress(), 9);
        }
      }
    }
    else
    {
      WebKitGTK.webkit_web_policy_decision_ignore(paramInt5);
    }
    return 0;
  }
  
  int webkit_decide_policy(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    int m;
    switch (paramInt3)
    {
    case 0: 
      int i = WebKitGTK.webkit_navigation_policy_decision_get_request(paramInt2);
      if (i == 0) {
        return 0;
      }
      int j = WebKitGTK.webkit_uri_request_get_uri(i);
      String str = getString(j);
      if (str.equals("file:///"))
      {
        str = "about:blank";
      }
      else
      {
        int k = "file:///".length();
        if ((str.startsWith("file:///")) && (str.charAt(k) == '#')) {
          str = "about:blank" + str.substring(k);
        }
      }
      LocationEvent localLocationEvent = new LocationEvent(this.browser);
      localLocationEvent.display = this.browser.getDisplay();
      localLocationEvent.widget = this.browser;
      localLocationEvent.location = str;
      localLocationEvent.doit = true;
      if (this.locationListeners != null) {
        for (m = 0; m < this.locationListeners.length; m++) {
          this.locationListeners[m].changing(localLocationEvent);
        }
      }
      if ((localLocationEvent.doit) && (!this.browser.isDisposed()) && (this.jsEnabled != this.jsEnabledOnNextPage))
      {
        this.jsEnabled = this.jsEnabledOnNextPage;
        DisabledJSCount += (!this.jsEnabled ? 1 : -1);
        m = WebKitGTK.webkit_web_view_get_settings(this.webView);
        OS.g_object_set(m, WebKitGTK.enable_scripts, this.jsEnabled ? 1 : 0, 0);
      }
      if (!localLocationEvent.doit) {
        WebKitGTK.webkit_policy_decision_ignore(paramInt2);
      }
      break;
    case 1: 
      break;
    case 2: 
      m = WebKitGTK.webkit_response_policy_decision_get_response(paramInt2);
      int n = WebKitGTK.webkit_uri_response_get_mime_type(m);
      int i1 = WebKitGTK.webkit_web_view_can_show_mime_type(this.webView, n) != 0 ? 1 : 0;
      if (i1 == 0)
      {
        WebKitGTK.webkit_policy_decision_download(paramInt2);
        return 1;
      }
      break;
    default: 
      return 0;
    }
    return 0;
  }
  
  int webkit_notify_load_status(int paramInt1, int paramInt2)
  {
    int i = WebKitGTK.webkit_web_view_get_load_status(this.webView);
    int j;
    switch (i)
    {
    case 1: 
      j = WebKitGTK.webkit_web_view_get_uri(this.webView);
      return handleLoadCommitted(j, true);
    case 2: 
      j = WebKitGTK.webkit_web_view_get_uri(this.webView);
      return handleLoadFinished(j, true);
    }
    return 0;
  }
  
  int webkit_load_changed(int paramInt1, int paramInt2, long paramLong)
  {
    int i;
    switch (paramInt2)
    {
    case 2: 
      i = WebKitGTK.webkit_web_view_get_uri(this.webView);
      return handleLoadCommitted(i, true);
    case 3: 
      i = WebKitGTK.webkit_web_view_get_title(this.webView);
      if (i == 0)
      {
        int j = WebKitGTK.webkit_web_view_get_uri(this.webView);
        fireNewTitleEvent(getString(j));
      }
      fireProgressCompletedEvent();
      return 0;
    }
    return 0;
  }
  
  int webkit_notify_progress(int paramInt1, int paramInt2)
  {
    ProgressEvent localProgressEvent = new ProgressEvent(this.browser);
    localProgressEvent.display = this.browser.getDisplay();
    localProgressEvent.widget = this.browser;
    double d = 0.0D;
    if (WEBKIT2) {
      d = WebKitGTK.webkit_web_view_get_estimated_load_progress(this.webView);
    } else {
      d = WebKitGTK.webkit_web_view_get_progress(this.webView);
    }
    localProgressEvent.current = ((int)(d * 100.0D));
    localProgressEvent.total = 100;
    for (int i = 0; i < this.progressListeners.length; i++) {
      this.progressListeners[i].changed(localProgressEvent);
    }
    return 0;
  }
  
  int webkit_notify_title(int paramInt1, int paramInt2)
  {
    int i = WebKitGTK.webkit_web_view_get_title(this.webView);
    String str;
    if (i == 0)
    {
      str = "";
    }
    else
    {
      int j = OS.strlen(i);
      byte[] arrayOfByte = new byte[j];
      OS.memmove(arrayOfByte, i, j);
      str = new String(Converter.mbcsToWcs(null, arrayOfByte));
    }
    TitleEvent localTitleEvent = new TitleEvent(this.browser);
    localTitleEvent.display = this.browser.getDisplay();
    localTitleEvent.widget = this.browser;
    localTitleEvent.title = str;
    for (int k = 0; k < this.titleListeners.length; k++) {
      this.titleListeners[k].changed(localTitleEvent);
    }
    return 0;
  }
  
  int webkit_context_menu(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    Point localPoint = this.browser.getDisplay().getCursorLocation();
    Event localEvent = new Event();
    localEvent.x = localPoint.x;
    localEvent.y = localPoint.y;
    this.browser.notifyListeners(35, localEvent);
    if (!localEvent.doit) {
      return 1;
    }
    Menu localMenu = this.browser.getMenu();
    if ((localMenu != null) && (!localMenu.isDisposed()))
    {
      if ((localPoint.x != localEvent.x) || (localPoint.y != localEvent.y)) {
        localMenu.setLocation(localEvent.x, localEvent.y);
      }
      localMenu.setVisible(true);
      return 1;
    }
    return 0;
  }
  
  int webkit_populate_popup(int paramInt1, int paramInt2)
  {
    Point localPoint = this.browser.getDisplay().getCursorLocation();
    Event localEvent = new Event();
    localEvent.x = localPoint.x;
    localEvent.y = localPoint.y;
    this.browser.notifyListeners(35, localEvent);
    int j;
    int k;
    if (!localEvent.doit)
    {
      int i = OS.gtk_container_get_children(paramInt2);
      for (j = i; j != 0; j = OS.g_list_next(j))
      {
        k = OS.g_list_data(j);
        OS.gtk_container_remove(paramInt2, k);
      }
      OS.g_list_free(i);
      return 0;
    }
    Menu localMenu = this.browser.getMenu();
    if ((localMenu != null) && (!localMenu.isDisposed()))
    {
      if ((localPoint.x != localEvent.x) || (localPoint.y != localEvent.y)) {
        localMenu.setLocation(localEvent.x, localEvent.y);
      }
      localMenu.setVisible(true);
      j = OS.gtk_container_get_children(paramInt2);
      for (k = j; k != 0; k = OS.g_list_next(k))
      {
        int m = OS.g_list_data(k);
        OS.gtk_container_remove(paramInt2, m);
      }
      OS.g_list_free(j);
    }
    return 0;
  }
  
  private void addRequestHeaders(int paramInt, String[] paramArrayOfString)
  {
    for (int i = 0; i < paramArrayOfString.length; i++)
    {
      String str1 = paramArrayOfString[i];
      if (str1 != null)
      {
        int j = str1.indexOf(':');
        if (j != -1)
        {
          String str2 = str1.substring(0, j).trim();
          String str3 = str1.substring(j + 1).trim();
          if ((str2.length() > 0) && (str3.length() > 0))
          {
            byte[] arrayOfByte1 = Converter.wcsToMbcs(null, str2, true);
            byte[] arrayOfByte2 = Converter.wcsToMbcs(null, str3, true);
            WebKitGTK.soup_message_headers_append(paramInt, arrayOfByte1, arrayOfByte2);
          }
        }
      }
    }
  }
  
  int webkit_resource_request_starting(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
  {
    if ((this.postData != null) || (this.headers != null))
    {
      int i = WebKitGTK.webkit_network_request_get_message(paramInt4);
      if (i == 0)
      {
        this.headers = null;
        this.postData = null;
      }
      else
      {
        if (this.postData != null)
        {
          WebKitGTK.SoupMessage_method(i, PostString);
          j = WebKitGTK.SoupMessage_request_body(i);
          byte[] arrayOfByte = Converter.wcsToMbcs(null, this.postData, false);
          int k = C.malloc(arrayOfByte.length);
          C.memmove(k, arrayOfByte, arrayOfByte.length);
          WebKitGTK.soup_message_body_append(j, 1, k, arrayOfByte.length);
          WebKitGTK.soup_message_body_flatten(j);
          if (this.headers == null) {
            this.headers = new String[0];
          }
          int m = 0;
          for (int n = 0; n < this.headers.length; n++)
          {
            int i1 = this.headers[n].indexOf(':');
            if (i1 != -1)
            {
              String str = this.headers[n].substring(0, i1).trim().toLowerCase();
              if (str.equals("content-type"))
              {
                m = 1;
                break;
              }
            }
          }
          if (m == 0)
          {
            String[] arrayOfString = new String[this.headers.length + 1];
            System.arraycopy(this.headers, 0, arrayOfString, 0, this.headers.length);
            arrayOfString[this.headers.length] = "content-type:application/x-www-form-urlencoded";
            this.headers = arrayOfString;
          }
          this.postData = null;
        }
        int j = WebKitGTK.SoupMessage_request_headers(i);
        addRequestHeaders(j, this.headers);
        this.headers = null;
      }
    }
    return 0;
  }
  
  int webkit_status_bar_text_changed(int paramInt1, int paramInt2)
  {
    int i = OS.strlen(paramInt2);
    byte[] arrayOfByte = new byte[i];
    OS.memmove(arrayOfByte, paramInt2, i);
    StatusTextEvent localStatusTextEvent = new StatusTextEvent(this.browser);
    localStatusTextEvent.display = this.browser.getDisplay();
    localStatusTextEvent.widget = this.browser;
    localStatusTextEvent.text = new String(Converter.mbcsToWcs(null, arrayOfByte));
    for (int j = 0; j < this.statusTextListeners.length; j++) {
      this.statusTextListeners[j].changed(localStatusTextEvent);
    }
    return 0;
  }
  
  int webkit_web_view_ready(int paramInt)
  {
    WindowEvent localWindowEvent = new WindowEvent(this.browser);
    localWindowEvent.display = this.browser.getDisplay();
    localWindowEvent.widget = this.browser;
    int i = WebKitGTK.webkit_web_view_get_window_features(this.webView);
    int[] arrayOfInt = new int[1];
    OS.g_object_get(i, WebKitGTK.locationbar_visible, arrayOfInt, 0);
    localWindowEvent.addressBar = (arrayOfInt[0] != 0);
    arrayOfInt[0] = 0;
    OS.g_object_get(i, WebKitGTK.menubar_visible, arrayOfInt, 0);
    localWindowEvent.menuBar = (arrayOfInt[0] != 0);
    arrayOfInt[0] = 0;
    OS.g_object_get(i, WebKitGTK.statusbar_visible, arrayOfInt, 0);
    localWindowEvent.statusBar = (arrayOfInt[0] != 0);
    arrayOfInt[0] = 0;
    OS.g_object_get(i, WebKitGTK.toolbar_visible, arrayOfInt, 0);
    localWindowEvent.toolBar = (arrayOfInt[0] != 0);
    arrayOfInt[0] = 0;
    OS.g_object_get(i, WebKitGTK.x, arrayOfInt, 0);
    int j = arrayOfInt[0];
    arrayOfInt[0] = 0;
    OS.g_object_get(i, WebKitGTK.y, arrayOfInt, 0);
    int k = arrayOfInt[0];
    arrayOfInt[0] = 0;
    OS.g_object_get(i, WebKitGTK.width, arrayOfInt, 0);
    int m = arrayOfInt[0];
    arrayOfInt[0] = 0;
    OS.g_object_get(i, WebKitGTK.height, arrayOfInt, 0);
    int n = arrayOfInt[0];
    arrayOfInt[0] = 0;
    if ((j != -1) && (k != -1)) {
      localWindowEvent.location = new Point(j, k);
    }
    if ((m != -1) && (n != -1)) {
      localWindowEvent.size = new Point(m, n);
    }
    for (int i1 = 0; i1 < this.visibilityWindowListeners.length; i1++) {
      this.visibilityWindowListeners[i1].show(localWindowEvent);
    }
    return 0;
  }
  
  int webkit_window_object_cleared(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    int i = WebKitGTK.JSContextGetGlobalObject(paramInt3);
    int j = WebKitGTK.JSObjectMake(paramInt3, ExternalClass, this.webViewData);
    byte[] arrayOfByte = null;
    try
    {
      arrayOfByte = "external\000".getBytes("UTF-8");
    }
    catch (UnsupportedEncodingException localUnsupportedEncodingException)
    {
      arrayOfByte = Converter.wcsToMbcs(null, "external", true);
    }
    int k = WebKitGTK.JSStringCreateWithUTF8CString(arrayOfByte);
    WebKitGTK.JSObjectSetProperty(paramInt3, i, k, j, 0, null);
    WebKitGTK.JSStringRelease(k);
    Enumeration localEnumeration = this.functions.elements();
    while (localEnumeration.hasMoreElements())
    {
      BrowserFunction localBrowserFunction = (BrowserFunction)localEnumeration.nextElement();
      execute(localBrowserFunction.functionString);
    }
    int m = WebKitGTK.webkit_web_view_get_main_frame(this.webView);
    boolean bool = m == paramInt2;
    addEventHandlers(paramInt1, bool);
    return 0;
  }
  
  int callJava(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6)
  {
    Object localObject1 = null;
    if (paramInt4 == 3)
    {
      int[] arrayOfInt = new int[1];
      C.memmove(arrayOfInt, paramInt5, C.PTR_SIZEOF);
      int i = WebKitGTK.JSValueGetType(paramInt1, arrayOfInt[0]);
      if (i == 3)
      {
        int j = ((Double)convertToJava(paramInt1, arrayOfInt[0])).intValue();
        arrayOfInt[0] = 0;
        Integer localInteger = new Integer(j);
        C.memmove(arrayOfInt, paramInt5 + C.PTR_SIZEOF, C.PTR_SIZEOF);
        i = WebKitGTK.JSValueGetType(paramInt1, arrayOfInt[0]);
        if (i == 4)
        {
          String str = (String)convertToJava(paramInt1, arrayOfInt[0]);
          BrowserFunction localBrowserFunction = (BrowserFunction)this.functions.get(localInteger);
          if ((localBrowserFunction != null) && (str.equals(localBrowserFunction.token))) {
            try
            {
              C.memmove(arrayOfInt, paramInt5 + 2 * C.PTR_SIZEOF, C.PTR_SIZEOF);
              Object localObject2 = convertToJava(paramInt1, arrayOfInt[0]);
              if ((localObject2 instanceof Object[]))
              {
                Object[] arrayOfObject = (Object[])localObject2;
                try
                {
                  localObject1 = localBrowserFunction.function(arrayOfObject);
                }
                catch (Exception localException)
                {
                  localObject1 = WebBrowser.CreateErrorString(localException.getLocalizedMessage());
                }
              }
            }
            catch (IllegalArgumentException localIllegalArgumentException)
            {
              if (localBrowserFunction.isEvaluate) {
                localBrowserFunction.function(new String[] { WebBrowser.CreateErrorString(new SWTException(51).getLocalizedMessage()) });
              }
              localObject1 = WebBrowser.CreateErrorString(localIllegalArgumentException.getLocalizedMessage());
            }
          }
        }
      }
    }
    return convertToJS(paramInt1, localObject1);
  }
  
  int convertToJS(int paramInt, Object paramObject)
  {
    if (paramObject == null) {
      return WebKitGTK.JSValueMakeUndefined(paramInt);
    }
    Object localObject1;
    int i;
    if ((paramObject instanceof String))
    {
      localObject1 = null;
      try
      {
        localObject1 = ((String)paramObject + '\000').getBytes("UTF-8");
      }
      catch (UnsupportedEncodingException localUnsupportedEncodingException)
      {
        localObject1 = Converter.wcsToMbcs(null, (String)paramObject, true);
      }
      i = WebKitGTK.JSStringCreateWithUTF8CString((byte[])localObject1);
      int j = WebKitGTK.JSValueMakeString(paramInt, i);
      WebKitGTK.JSStringRelease(i);
      return j;
    }
    if ((paramObject instanceof Boolean)) {
      return WebKitGTK.JSValueMakeBoolean(paramInt, ((Boolean)paramObject).booleanValue() ? 1 : 0);
    }
    if ((paramObject instanceof Number)) {
      return WebKitGTK.JSValueMakeNumber(paramInt, ((Number)paramObject).doubleValue());
    }
    if ((paramObject instanceof Object[]))
    {
      localObject1 = (Object[])paramObject;
      i = localObject1.length;
      int[] arrayOfInt = new int[i];
      for (int k = 0; k < i; k++)
      {
        Object localObject2 = localObject1[k];
        int m = convertToJS(paramInt, localObject2);
        arrayOfInt[k] = m;
      }
      return WebKitGTK.JSObjectMakeArray(paramInt, i, arrayOfInt, null);
    }
    SWT.error(51);
    return 0;
  }
  
  Object convertToJava(int paramInt1, int paramInt2)
  {
    int i = WebKitGTK.JSValueGetType(paramInt1, paramInt2);
    switch (i)
    {
    case 2: 
      int j = (int)WebKitGTK.JSValueToNumber(paramInt1, paramInt2, null);
      return new Boolean(j != 0);
    case 3: 
      double d = WebKitGTK.JSValueToNumber(paramInt1, paramInt2, null);
      return new Double(d);
    case 4: 
      int k = WebKitGTK.JSValueToStringCopy(paramInt1, paramInt2, null);
      if (k == 0) {
        return "";
      }
      int m = WebKitGTK.JSStringGetMaximumUTF8CStringSize(k);
      byte[] arrayOfByte2 = new byte[m];
      m = WebKitGTK.JSStringGetUTF8CString(k, arrayOfByte2, m);
      WebKitGTK.JSStringRelease(k);
      try
      {
        return new String(arrayOfByte2, 0, m - 1, "UTF-8");
      }
      catch (UnsupportedEncodingException localUnsupportedEncodingException2)
      {
        return new String(Converter.mbcsToWcs(null, arrayOfByte2));
      }
    case 0: 
    case 1: 
      return null;
    case 5: 
      byte[] arrayOfByte1 = null;
      try
      {
        arrayOfByte1 = "length\000".getBytes("UTF-8");
      }
      catch (UnsupportedEncodingException localUnsupportedEncodingException1)
      {
        arrayOfByte1 = Converter.wcsToMbcs(null, "length", true);
      }
      int n = WebKitGTK.JSStringCreateWithUTF8CString(arrayOfByte1);
      int i1 = WebKitGTK.JSObjectGetProperty(paramInt1, paramInt2, n, null);
      WebKitGTK.JSStringRelease(n);
      i = WebKitGTK.JSValueGetType(paramInt1, i1);
      if (i == 3)
      {
        int i2 = (int)WebKitGTK.JSValueToNumber(paramInt1, i1, null);
        Object[] arrayOfObject = new Object[i2];
        for (int i3 = 0; i3 < i2; i3++)
        {
          int i4 = WebKitGTK.JSObjectGetPropertyAtIndex(paramInt1, paramInt2, i3, null);
          if (i4 != 0) {
            arrayOfObject[i3] = convertToJava(paramInt1, i4);
          }
        }
        return arrayOfObject;
      }
      break;
    }
    SWT.error(5);
    return null;
  }
  
  static
  {
    try
    {
      Library.loadLibrary("swt-webkit");
      LibraryLoaded = true;
    }
    catch (Throwable localThrowable) {}
    if (LibraryLoaded)
    {
      String str = System.getenv("SWT_WEBKIT2");
      WEBKIT2 = (str != null) && (str.equals("1")) && (OS.GTK3);
      WebViewType = WebKitGTK.webkit_web_view_get_type();
      Proc2 = new Callback(WebKit.class, "Proc", 2);
      if (Proc2.getAddress() == 0) {
        SWT.error(3);
      }
      Proc3 = new Callback(WebKit.class, "Proc", 3);
      if (Proc3.getAddress() == 0) {
        SWT.error(3);
      }
      Proc4 = new Callback(WebKit.class, "Proc", 4);
      if (Proc4.getAddress() == 0) {
        SWT.error(3);
      }
      Proc5 = new Callback(WebKit.class, "Proc", 5);
      if (Proc5.getAddress() == 0) {
        SWT.error(3);
      }
      Proc6 = new Callback(WebKit.class, "Proc", 6);
      if (Proc6.getAddress() == 0) {
        SWT.error(3);
      }
      JSObjectHasPropertyProc = new Callback(WebKit.class, "JSObjectHasPropertyProc", 3);
      if (JSObjectHasPropertyProc.getAddress() == 0) {
        SWT.error(3);
      }
      JSObjectGetPropertyProc = new Callback(WebKit.class, "JSObjectGetPropertyProc", 4);
      if (JSObjectGetPropertyProc.getAddress() == 0) {
        SWT.error(3);
      }
      JSObjectCallAsFunctionProc = new Callback(WebKit.class, "JSObjectCallAsFunctionProc", 6);
      if (JSObjectCallAsFunctionProc.getAddress() == 0) {
        SWT.error(3);
      }
      JSDOMEventProc = new Callback(WebKit.class, "JSDOMEventProc", 3);
      if (JSDOMEventProc.getAddress() == 0) {
        SWT.error(3);
      }
      NativeClearSessions = new Runnable()
      {
        public void run()
        {
          if (!WebKit.LibraryLoaded) {
            return;
          }
          int i = WebKitGTK.webkit_get_default_session();
          int j = WebKitGTK.soup_cookie_jar_get_type();
          int k = WebKitGTK.soup_session_get_feature(i, j);
          if (k == 0) {
            return;
          }
          int m = WebKitGTK.soup_cookie_jar_all_cookies(k);
          int n = OS.g_slist_length(m);
          int i1 = m;
          for (int i2 = 0; i2 < n; i2++)
          {
            int i3 = OS.g_slist_data(i1);
            int i4 = WebKitGTK.SoupCookie_expires(i3);
            if (i4 == 0) {
              WebKitGTK.soup_cookie_jar_delete_cookie(k, i3);
            }
            WebKitGTK.soup_cookie_free(i3);
            i1 = OS.g_slist_next(i1);
          }
          OS.g_slist_free(m);
        }
      };
      NativeGetCookie = new Runnable()
      {
        public void run()
        {
          if (!WebKit.LibraryLoaded) {
            return;
          }
          int i = WebKitGTK.webkit_get_default_session();
          int j = WebKitGTK.soup_cookie_jar_get_type();
          int k = WebKitGTK.soup_session_get_feature(i, j);
          if (k == 0) {
            return;
          }
          byte[] arrayOfByte = Converter.wcsToMbcs(null, WebBrowser.CookieUrl, true);
          int m = WebKitGTK.soup_uri_new(arrayOfByte);
          if (m == 0) {
            return;
          }
          int n = WebKitGTK.soup_cookie_jar_get_cookies(k, m, 0);
          WebKitGTK.soup_uri_free(m);
          if (n == 0) {
            return;
          }
          int i1 = OS.strlen(n);
          arrayOfByte = new byte[i1];
          C.memmove(arrayOfByte, n, i1);
          OS.g_free(n);
          String str1 = new String(Converter.mbcsToWcs(null, arrayOfByte));
          StringTokenizer localStringTokenizer = new StringTokenizer(str1, ";");
          while (localStringTokenizer.hasMoreTokens())
          {
            String str2 = localStringTokenizer.nextToken();
            int i2 = str2.indexOf('=');
            if (i2 != -1)
            {
              String str3 = str2.substring(0, i2).trim();
              if (str3.equals(WebBrowser.CookieName))
              {
                WebBrowser.CookieValue = str2.substring(i2 + 1).trim();
                return;
              }
            }
          }
        }
      };
      NativeSetCookie = new Runnable()
      {
        public void run()
        {
          if (!WebKit.LibraryLoaded) {
            return;
          }
          int i = WebKitGTK.webkit_get_default_session();
          int j = WebKitGTK.soup_cookie_jar_get_type();
          int k = WebKitGTK.soup_session_get_feature(i, j);
          if (k == 0)
          {
            WebKitGTK.soup_session_add_feature_by_type(i, j);
            k = WebKitGTK.soup_session_get_feature(i, j);
          }
          if (k == 0) {
            return;
          }
          byte[] arrayOfByte = Converter.wcsToMbcs(null, WebBrowser.CookieUrl, true);
          int m = WebKitGTK.soup_uri_new(arrayOfByte);
          if (m == 0) {
            return;
          }
          arrayOfByte = Converter.wcsToMbcs(null, WebBrowser.CookieValue, true);
          int n = WebKitGTK.soup_cookie_parse(arrayOfByte, m);
          if (n != 0)
          {
            WebKitGTK.soup_cookie_jar_add_cookie(k, n);
            WebBrowser.CookieResult = true;
          }
          WebKitGTK.soup_uri_free(m);
        }
      };
      if (NativePendingCookies != null)
      {
        SetPendingCookies(NativePendingCookies);
        NativePendingCookies = null;
      }
    }
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/browser/WebKit.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */