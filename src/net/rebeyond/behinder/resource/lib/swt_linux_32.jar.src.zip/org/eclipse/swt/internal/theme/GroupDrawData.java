package org.eclipse.swt.internal.theme;

import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.GCData;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.internal.Converter;
import org.eclipse.swt.internal.cairo.Cairo;
import org.eclipse.swt.internal.gtk.GdkRectangle;
import org.eclipse.swt.internal.gtk.OS;

public class GroupDrawData
  extends DrawData
{
  public int headerWidth;
  public int headerHeight;
  public Rectangle headerArea;
  static final int GROUP_X = 2;
  static final int GROUP_PAD = 1;
  static final int GROUP_HEADER_X = 9;
  static final int GROUP_HEADER_PAD = 2;
  
  public GroupDrawData()
  {
    this.state = new int[1];
  }
  
  void draw(Theme paramTheme, GC paramGC, Rectangle paramRectangle)
  {
    int i = paramTheme.frameHandle;
    int j = OS.gtk_widget_get_style(i);
    int k = paramGC.getGCData().drawable;
    paramTheme.transferClipping(paramGC, j);
    int m = OS.gtk_style_get_xthickness(j);
    int n = OS.gtk_style_get_ythickness(j);
    int i1 = paramRectangle.x;
    int i2 = paramRectangle.y + this.headerHeight / 2;
    int i3 = paramRectangle.width;
    int i4 = paramRectangle.height - this.headerHeight / 2;
    byte[] arrayOfByte = Converter.wcsToMbcs(null, "frame", true);
    int i5 = m + 2;
    int i6 = this.headerWidth + 2;
    int i7 = 2;
    int i8 = getStateType(0);
    gtk_render_shadow_gap(j, k, i8, 3, null, i, arrayOfByte, i1, i2, i3, i4, i7, i5, i6);
    if (this.headerArea != null)
    {
      this.headerArea.x = (paramRectangle.x + i5 + 1);
      this.headerArea.y = paramRectangle.y;
      this.headerArea.width = this.headerWidth;
      this.headerArea.height = this.headerHeight;
    }
    if (this.clientArea != null)
    {
      this.clientArea.x = (paramRectangle.x + m);
      this.clientArea.y = (paramRectangle.y + n + this.headerHeight);
      this.clientArea.width = (paramRectangle.width - 2 * m);
      this.clientArea.height = (paramRectangle.height - 2 * n - this.headerHeight);
    }
  }
  
  int getStateType(int paramInt)
  {
    int i = this.state[paramInt];
    int j = 0;
    if ((i & 0x20) != 0) {
      j = 4;
    }
    return j;
  }
  
  int hit(Theme paramTheme, Point paramPoint, Rectangle paramRectangle)
  {
    return paramRectangle.contains(paramPoint) ? 0 : -1;
  }
  
  void gtk_render_shadow_gap(int paramInt1, int paramInt2, int paramInt3, int paramInt4, GdkRectangle paramGdkRectangle, int paramInt5, byte[] paramArrayOfByte, int paramInt6, int paramInt7, int paramInt8, int paramInt9, int paramInt10, int paramInt11, int paramInt12)
  {
    if (OS.GTK3)
    {
      int i = OS.gdk_cairo_create(paramInt2);
      int j = OS.gtk_widget_get_style_context(paramInt1);
      OS.gtk_style_context_save(j);
      OS.gtk_style_context_set_state(j, paramInt3);
      OS.gtk_render_frame_gap(j, i, j, paramInt7, paramInt12, paramInt9, paramInt10, paramInt11, paramInt11 + paramInt12);
      Cairo.cairo_destroy(i);
    }
    else
    {
      OS.gtk_paint_shadow_gap(paramInt1, paramInt2, paramInt3, paramInt4, paramGdkRectangle, paramInt5, paramArrayOfByte, paramInt6, paramInt7, paramInt8, paramInt9, paramInt10, paramInt11, paramInt12);
    }
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/internal/theme/GroupDrawData.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */