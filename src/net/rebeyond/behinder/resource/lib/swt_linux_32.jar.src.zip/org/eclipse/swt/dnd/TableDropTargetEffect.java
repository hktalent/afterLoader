package org.eclipse.swt.dnd;

import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.internal.gtk.OS;
import org.eclipse.swt.widgets.Table;

public class TableDropTargetEffect
  extends DropTargetEffect
{
  static final int SCROLL_HYSTERESIS = 150;
  int scrollIndex;
  long scrollBeginTime;
  
  public TableDropTargetEffect(Table paramTable)
  {
    super(paramTable);
  }
  
  int checkEffect(int paramInt)
  {
    if ((paramInt & 0x1) != 0) {
      paramInt = paramInt & 0xFFFFFFFB & 0xFFFFFFFD;
    }
    if ((paramInt & 0x2) != 0) {
      paramInt &= 0xFFFFFFFB;
    }
    return paramInt;
  }
  
  public void dragEnter(DropTargetEvent paramDropTargetEvent)
  {
    this.scrollBeginTime = 0L;
    this.scrollIndex = -1;
  }
  
  public void dragLeave(DropTargetEvent paramDropTargetEvent)
  {
    Table localTable = (Table)this.control;
    int i = localTable.handle;
    OS.gtk_tree_view_set_drag_dest_row(i, 0, 0);
    this.scrollBeginTime = 0L;
    this.scrollIndex = -1;
  }
  
  public void dragOver(DropTargetEvent paramDropTargetEvent)
  {
    Table localTable = (Table)this.control;
    int i = localTable.handle;
    int j = checkEffect(paramDropTargetEvent.feedback);
    Point localPoint = new Point(paramDropTargetEvent.x, paramDropTargetEvent.y);
    localPoint = localTable.toControl(localPoint);
    int[] arrayOfInt1 = new int[1];
    OS.gtk_tree_view_get_path_at_pos(i, localPoint.x, localPoint.y, arrayOfInt1, null, null, null);
    int k = -1;
    int m;
    if (arrayOfInt1[0] != 0)
    {
      m = OS.gtk_tree_path_get_indices(arrayOfInt1[0]);
      if (m != 0)
      {
        int[] arrayOfInt2 = new int[1];
        OS.memmove(arrayOfInt2, m, 4);
        k = arrayOfInt2[0];
      }
    }
    if ((j & 0x8) == 0)
    {
      this.scrollBeginTime = 0L;
      this.scrollIndex = -1;
    }
    else if ((k != -1) && (this.scrollIndex == k) && (this.scrollBeginTime != 0L))
    {
      if (System.currentTimeMillis() >= this.scrollBeginTime)
      {
        if (localPoint.y < localTable.getItemHeight()) {
          OS.gtk_tree_path_prev(arrayOfInt1[0]);
        } else {
          OS.gtk_tree_path_next(arrayOfInt1[0]);
        }
        if (arrayOfInt1[0] != 0)
        {
          OS.gtk_tree_view_scroll_to_cell(i, arrayOfInt1[0], 0, false, 0.0F, 0.0F);
          OS.gtk_tree_path_free(arrayOfInt1[0]);
          arrayOfInt1[0] = 0;
          OS.gtk_tree_view_get_path_at_pos(i, localPoint.x, localPoint.y, arrayOfInt1, null, null, null);
        }
        this.scrollBeginTime = 0L;
        this.scrollIndex = -1;
      }
    }
    else
    {
      this.scrollBeginTime = (System.currentTimeMillis() + 150L);
      this.scrollIndex = k;
    }
    if (arrayOfInt1[0] != 0)
    {
      m = -1;
      if ((j & 0x1) != 0) {
        m = 2;
      }
      if ((j & 0x2) != 0) {
        m = 0;
      }
      if ((j & 0x4) != 0) {
        m = 1;
      }
      if (m != -1) {
        OS.gtk_tree_view_set_drag_dest_row(i, arrayOfInt1[0], m);
      } else {
        OS.gtk_tree_view_set_drag_dest_row(i, 0, 0);
      }
    }
    else
    {
      OS.gtk_tree_view_set_drag_dest_row(i, 0, 0);
    }
    if (arrayOfInt1[0] != 0) {
      OS.gtk_tree_path_free(arrayOfInt1[0]);
    }
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/dnd/TableDropTargetEffect.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */