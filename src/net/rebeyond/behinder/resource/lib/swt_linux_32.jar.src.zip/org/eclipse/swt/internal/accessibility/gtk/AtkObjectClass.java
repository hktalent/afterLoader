package org.eclipse.swt.internal.accessibility.gtk;

public class AtkObjectClass
{
  public int get_name;
  public int get_description;
  public int get_parent;
  public int get_n_children;
  public int ref_child;
  public int get_index_in_parent;
  public int ref_relation_set;
  public int get_role;
  public int get_layer;
  public int get_mdi_zorder;
  public int ref_state_set;
  public int set_name;
  public int set_description;
  public int set_parent;
  public int set_role;
  public int connect_property_change_handler;
  public int remove_property_change_handler;
  public int initialize;
  public int children_changed;
  public int focus_event;
  public int property_change;
  public int state_change;
  public int visible_data_changed;
  public int get_attributes;
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/internal/accessibility/gtk/AtkObjectClass.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */