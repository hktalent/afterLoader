package org.eclipse.swt.internal.accessibility.gtk;

public class AtkValueIface
{
  public int get_current_value;
  public int get_maximum_value;
  public int get_minimum_value;
  public int set_current_value;
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/internal/accessibility/gtk/AtkValueIface.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */