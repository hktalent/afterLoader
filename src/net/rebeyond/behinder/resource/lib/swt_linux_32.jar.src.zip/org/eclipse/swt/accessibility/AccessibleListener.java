package org.eclipse.swt.accessibility;

import org.eclipse.swt.internal.SWTEventListener;

public abstract interface AccessibleListener
  extends SWTEventListener
{
  public abstract void getName(AccessibleEvent paramAccessibleEvent);
  
  public abstract void getHelp(AccessibleEvent paramAccessibleEvent);
  
  public abstract void getKeyboardShortcut(AccessibleEvent paramAccessibleEvent);
  
  public abstract void getDescription(AccessibleEvent paramAccessibleEvent);
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/accessibility/AccessibleListener.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */