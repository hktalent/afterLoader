package org.eclipse.swt.accessibility;

public class AccessibleTableCellAdapter
  implements AccessibleTableCellListener
{
  public void getColumnSpan(AccessibleTableCellEvent paramAccessibleTableCellEvent) {}
  
  public void getColumnHeaders(AccessibleTableCellEvent paramAccessibleTableCellEvent) {}
  
  public void getColumnIndex(AccessibleTableCellEvent paramAccessibleTableCellEvent) {}
  
  public void getRowSpan(AccessibleTableCellEvent paramAccessibleTableCellEvent) {}
  
  public void getRowHeaders(AccessibleTableCellEvent paramAccessibleTableCellEvent) {}
  
  public void getRowIndex(AccessibleTableCellEvent paramAccessibleTableCellEvent) {}
  
  public void getTable(AccessibleTableCellEvent paramAccessibleTableCellEvent) {}
  
  public void isSelected(AccessibleTableCellEvent paramAccessibleTableCellEvent) {}
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/accessibility/AccessibleTableCellAdapter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */