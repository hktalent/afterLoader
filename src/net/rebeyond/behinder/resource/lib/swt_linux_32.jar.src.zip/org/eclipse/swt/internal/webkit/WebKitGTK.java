package org.eclipse.swt.internal.webkit;

import org.eclipse.swt.internal.C;
import org.eclipse.swt.internal.Lock;

public class WebKitGTK
  extends C
{
  public static final int kJSTypeUndefined = 0;
  public static final int kJSTypeNull = 1;
  public static final int kJSTypeBoolean = 2;
  public static final int kJSTypeNumber = 3;
  public static final int kJSTypeString = 4;
  public static final int kJSTypeObject = 5;
  public static final int SOUP_MEMORY_TAKE = 1;
  public static final int WEBKIT_DOWNLOAD_STATUS_ERROR = -1;
  public static final int WEBKIT_DOWNLOAD_STATUS_CANCELLED = 2;
  public static final int WEBKIT_DOWNLOAD_STATUS_FINISHED = 3;
  public static final int WEBKIT_LOAD_COMMITTED = 1;
  public static final int WEBKIT_LOAD_FINISHED = 2;
  public static final int WEBKIT2_LOAD_STARTED = 0;
  public static final int WEBKIT2_LOAD_REDIRECTED = 1;
  public static final int WEBKIT2_LOAD_COMMITTED = 2;
  public static final int WEBKIT2_LOAD_FINISHED = 3;
  public static final int WEBKIT_POLICY_DECISION_TYPE_NAVIGATION_ACTION = 0;
  public static final int WEBKIT_POLICY_DECISION_TYPE_NEW_WINDOW_ACTION = 1;
  public static final int WEBKIT_POLICY_DECISION_TYPE_RESPONSE = 2;
  public static final int WEBKIT_CREDENTIAL_PERSISTENCE_NONE = 0;
  public static final int WEBKIT_CREDENTIAL_PERSISTENCE_FOR_SESSION = 1;
  public static final int WEBKIT_CREDENTIAL_PERSISTENCE_PERMANENT = 2;
  public static final byte[] authenticate = ascii("authenticate");
  public static final byte[] close_web_view = ascii("close-web-view");
  public static final byte[] console_message = ascii("console-message");
  public static final byte[] context_menu = ascii("context-menu");
  public static final byte[] close = ascii("close");
  public static final byte[] create = ascii("create");
  public static final byte[] create_web_view = ascii("create-web-view");
  public static final byte[] decide_policy = ascii("decide-policy");
  public static final byte[] download_requested = ascii("download-requested");
  public static final byte[] download_started = ascii("download-started");
  public static final byte[] hovering_over_link = ascii("hovering-over-link");
  public static final byte[] load_changed = ascii("load-changed");
  public static final byte[] mime_type_policy_decision_requested = ascii("mime-type-policy-decision-requested");
  public static final byte[] mouse_target_changed = ascii("mouse-target-changed");
  public static final byte[] navigation_policy_decision_requested = ascii("navigation-policy-decision-requested");
  public static final byte[] notify_load_status = ascii("notify::load-status");
  public static final byte[] notify_progress = ascii("notify::progress");
  public static final byte[] notify_estimated_load_progress = ascii("notify::estimated-load-progress");
  public static final byte[] notify_title = ascii("notify::title");
  public static final byte[] populate_popup = ascii("populate-popup");
  public static final byte[] resource_request_starting = ascii("resource-request-starting");
  public static final byte[] resource_load_started = ascii("resource-load-started");
  public static final byte[] status_bar_text_changed = ascii("status-bar-text-changed");
  public static final byte[] web_view_ready = ascii("web-view-ready");
  public static final byte[] ready_to_show = ascii("ready-to-show");
  public static final byte[] window_object_cleared = ascii("window-object-cleared");
  public static final byte[] default_encoding = ascii("default-encoding");
  public static final byte[] default_charset = ascii("default-charset");
  public static final byte[] enable_scripts = ascii("enable-scripts");
  public static final byte[] enable_plugins = ascii("enable-plugins");
  public static final byte[] enable_universal_access_from_file_uris = ascii("enable-universal-access-from-file-uris");
  public static final byte[] height = ascii("height");
  public static final byte[] javascript_can_open_windows_automatically = ascii("javascript-can-open-windows-automatically");
  public static final byte[] locationbar_visible = ascii("locationbar-visible");
  public static final byte[] menubar_visible = ascii("menubar-visible");
  public static final byte[] SOUP_SESSION_PROXY_URI = ascii("proxy-uri");
  public static final byte[] statusbar_visible = ascii("statusbar-visible");
  public static final byte[] toolbar_visible = ascii("toolbar-visible");
  public static final byte[] user_agent = ascii("user-agent");
  public static final byte[] width = ascii("width");
  public static final byte[] x = ascii("x");
  public static final byte[] y = ascii("y");
  public static final byte[] dragstart = ascii("dragstart");
  public static final byte[] keydown = ascii("keydown");
  public static final byte[] keypress = ascii("keypress");
  public static final byte[] keyup = ascii("keyup");
  public static final byte[] mousedown = ascii("mousedown");
  public static final byte[] mousemove = ascii("mousemove");
  public static final byte[] mouseup = ascii("mouseup");
  public static final byte[] mousewheel = ascii("mousewheel");
  
  protected static byte[] ascii(String paramString)
  {
    int i = paramString.length();
    char[] arrayOfChar = new char[i];
    paramString.getChars(0, i, arrayOfChar, 0);
    byte[] arrayOfByte = new byte[i + 1];
    for (int j = 0; j < i; j++) {
      arrayOfByte[j] = ((byte)arrayOfChar[j]);
    }
    return arrayOfByte;
  }
  
  public static final native int _JSClassCreate(int paramInt);
  
  public static final int JSClassCreate(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _JSClassCreate(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _JSContextGetGlobalObject(int paramInt);
  
  public static final int JSContextGetGlobalObject(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _JSContextGetGlobalObject(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _JSEvaluateScript(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int[] paramArrayOfInt);
  
  public static final int JSEvaluateScript(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int[] paramArrayOfInt)
  {
    lock.lock();
    try
    {
      int i = _JSEvaluateScript(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramArrayOfInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _JSObjectGetPrivate(int paramInt);
  
  public static final int JSObjectGetPrivate(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _JSObjectGetPrivate(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _JSObjectGetProperty(int paramInt1, int paramInt2, int paramInt3, int[] paramArrayOfInt);
  
  public static final int JSObjectGetProperty(int paramInt1, int paramInt2, int paramInt3, int[] paramArrayOfInt)
  {
    lock.lock();
    try
    {
      int i = _JSObjectGetProperty(paramInt1, paramInt2, paramInt3, paramArrayOfInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _JSObjectGetPropertyAtIndex(int paramInt1, int paramInt2, int paramInt3, int[] paramArrayOfInt);
  
  public static final int JSObjectGetPropertyAtIndex(int paramInt1, int paramInt2, int paramInt3, int[] paramArrayOfInt)
  {
    lock.lock();
    try
    {
      int i = _JSObjectGetPropertyAtIndex(paramInt1, paramInt2, paramInt3, paramArrayOfInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _JSObjectMake(int paramInt1, int paramInt2, int paramInt3);
  
  public static final int JSObjectMake(int paramInt1, int paramInt2, int paramInt3)
  {
    lock.lock();
    try
    {
      int i = _JSObjectMake(paramInt1, paramInt2, paramInt3);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _JSObjectMakeArray(int paramInt1, int paramInt2, int[] paramArrayOfInt1, int[] paramArrayOfInt2);
  
  public static final int JSObjectMakeArray(int paramInt1, int paramInt2, int[] paramArrayOfInt1, int[] paramArrayOfInt2)
  {
    lock.lock();
    try
    {
      int i = _JSObjectMakeArray(paramInt1, paramInt2, paramArrayOfInt1, paramArrayOfInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _JSObjectMakeFunctionWithCallback(int paramInt1, int paramInt2, int paramInt3);
  
  public static final int JSObjectMakeFunctionWithCallback(int paramInt1, int paramInt2, int paramInt3)
  {
    lock.lock();
    try
    {
      int i = _JSObjectMakeFunctionWithCallback(paramInt1, paramInt2, paramInt3);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _JSObjectSetProperty(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int[] paramArrayOfInt);
  
  public static final void JSObjectSetProperty(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int[] paramArrayOfInt)
  {
    lock.lock();
    try
    {
      _JSObjectSetProperty(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramArrayOfInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _JSStringCreateWithUTF8CString(byte[] paramArrayOfByte);
  
  public static final int JSStringCreateWithUTF8CString(byte[] paramArrayOfByte)
  {
    lock.lock();
    try
    {
      int i = _JSStringCreateWithUTF8CString(paramArrayOfByte);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _JSStringGetLength(int paramInt);
  
  public static final int JSStringGetLength(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _JSStringGetLength(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _JSStringGetMaximumUTF8CStringSize(int paramInt);
  
  public static final int JSStringGetMaximumUTF8CStringSize(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _JSStringGetMaximumUTF8CStringSize(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _JSStringGetUTF8CString(int paramInt1, byte[] paramArrayOfByte, int paramInt2);
  
  public static final int JSStringGetUTF8CString(int paramInt1, byte[] paramArrayOfByte, int paramInt2)
  {
    lock.lock();
    try
    {
      int i = _JSStringGetUTF8CString(paramInt1, paramArrayOfByte, paramInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _JSStringIsEqualToUTF8CString(int paramInt, byte[] paramArrayOfByte);
  
  public static final int JSStringIsEqualToUTF8CString(int paramInt, byte[] paramArrayOfByte)
  {
    lock.lock();
    try
    {
      int i = _JSStringIsEqualToUTF8CString(paramInt, paramArrayOfByte);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _JSStringRelease(int paramInt);
  
  public static final void JSStringRelease(int paramInt)
  {
    lock.lock();
    try
    {
      _JSStringRelease(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _JSValueGetType(int paramInt1, int paramInt2);
  
  public static final int JSValueGetType(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      int i = _JSValueGetType(paramInt1, paramInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _JSValueIsObjectOfClass(int paramInt1, int paramInt2, int paramInt3);
  
  public static final int JSValueIsObjectOfClass(int paramInt1, int paramInt2, int paramInt3)
  {
    lock.lock();
    try
    {
      int i = _JSValueIsObjectOfClass(paramInt1, paramInt2, paramInt3);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _JSValueMakeBoolean(int paramInt1, int paramInt2);
  
  public static final int JSValueMakeBoolean(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      int i = _JSValueMakeBoolean(paramInt1, paramInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _JSValueMakeNumber(int paramInt, double paramDouble);
  
  public static final int JSValueMakeNumber(int paramInt, double paramDouble)
  {
    lock.lock();
    try
    {
      int i = _JSValueMakeNumber(paramInt, paramDouble);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _JSValueMakeString(int paramInt1, int paramInt2);
  
  public static final int JSValueMakeString(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      int i = _JSValueMakeString(paramInt1, paramInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _JSValueMakeUndefined(int paramInt);
  
  public static final int JSValueMakeUndefined(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _JSValueMakeUndefined(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native double _JSValueToNumber(int paramInt1, int paramInt2, int[] paramArrayOfInt);
  
  public static final double JSValueToNumber(int paramInt1, int paramInt2, int[] paramArrayOfInt)
  {
    lock.lock();
    try
    {
      double d = _JSValueToNumber(paramInt1, paramInt2, paramArrayOfInt);
      return d;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _JSValueToStringCopy(int paramInt1, int paramInt2, int[] paramArrayOfInt);
  
  public static final int JSValueToStringCopy(int paramInt1, int paramInt2, int[] paramArrayOfInt)
  {
    lock.lock();
    try
    {
      int i = _JSValueToStringCopy(paramInt1, paramInt2, paramArrayOfInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _soup_auth_authenticate(int paramInt, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2);
  
  public static final void soup_auth_authenticate(int paramInt, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    lock.lock();
    try
    {
      _soup_auth_authenticate(paramInt, paramArrayOfByte1, paramArrayOfByte2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _soup_auth_get_host(int paramInt);
  
  public static final int soup_auth_get_host(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _soup_auth_get_host(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _soup_auth_get_scheme_name(int paramInt);
  
  public static final int soup_auth_get_scheme_name(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _soup_auth_get_scheme_name(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _soup_cookie_free(int paramInt);
  
  public static final void soup_cookie_free(int paramInt)
  {
    lock.lock();
    try
    {
      _soup_cookie_free(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _soup_cookie_jar_add_cookie(int paramInt1, int paramInt2);
  
  public static final void soup_cookie_jar_add_cookie(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _soup_cookie_jar_add_cookie(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _soup_cookie_jar_all_cookies(int paramInt);
  
  public static final int soup_cookie_jar_all_cookies(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _soup_cookie_jar_all_cookies(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _soup_cookie_jar_delete_cookie(int paramInt1, int paramInt2);
  
  public static final void soup_cookie_jar_delete_cookie(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _soup_cookie_jar_delete_cookie(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _soup_cookie_jar_get_cookies(int paramInt1, int paramInt2, int paramInt3);
  
  public static final int soup_cookie_jar_get_cookies(int paramInt1, int paramInt2, int paramInt3)
  {
    lock.lock();
    try
    {
      int i = _soup_cookie_jar_get_cookies(paramInt1, paramInt2, paramInt3);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _soup_cookie_jar_get_type();
  
  public static final int soup_cookie_jar_get_type()
  {
    lock.lock();
    try
    {
      int i = _soup_cookie_jar_get_type();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _soup_cookie_parse(byte[] paramArrayOfByte, int paramInt);
  
  public static final int soup_cookie_parse(byte[] paramArrayOfByte, int paramInt)
  {
    lock.lock();
    try
    {
      int i = _soup_cookie_parse(paramArrayOfByte, paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _soup_message_body_append(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  public static final void soup_message_body_append(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    lock.lock();
    try
    {
      _soup_message_body_append(paramInt1, paramInt2, paramInt3, paramInt4);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _soup_message_body_flatten(int paramInt);
  
  public static final void soup_message_body_flatten(int paramInt)
  {
    lock.lock();
    try
    {
      _soup_message_body_flatten(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _soup_message_get_uri(int paramInt);
  
  public static final int soup_message_get_uri(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _soup_message_get_uri(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _soup_message_headers_append(int paramInt, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2);
  
  public static final void soup_message_headers_append(int paramInt, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    lock.lock();
    try
    {
      _soup_message_headers_append(paramInt, paramArrayOfByte1, paramArrayOfByte2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _soup_session_add_feature_by_type(int paramInt1, int paramInt2);
  
  public static final void soup_session_add_feature_by_type(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _soup_session_add_feature_by_type(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _soup_session_get_feature(int paramInt1, int paramInt2);
  
  public static final int soup_session_get_feature(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      int i = _soup_session_get_feature(paramInt1, paramInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _soup_session_feature_attach(int paramInt1, int paramInt2);
  
  public static final void soup_session_feature_attach(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _soup_session_feature_attach(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _soup_session_get_type();
  
  public static final int soup_session_get_type()
  {
    lock.lock();
    try
    {
      int i = _soup_session_get_type();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _soup_session_feature_detach(int paramInt1, int paramInt2);
  
  public static final void soup_session_feature_detach(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _soup_session_feature_detach(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _soup_uri_free(int paramInt);
  
  public static final void soup_uri_free(int paramInt)
  {
    lock.lock();
    try
    {
      _soup_uri_free(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _soup_uri_new(byte[] paramArrayOfByte);
  
  public static final int soup_uri_new(byte[] paramArrayOfByte)
  {
    lock.lock();
    try
    {
      int i = _soup_uri_new(paramArrayOfByte);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _soup_uri_to_string(int paramInt1, int paramInt2);
  
  public static final int soup_uri_to_string(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      int i = _soup_uri_to_string(paramInt1, paramInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _webkit_authentication_request_authenticate(int paramInt1, int paramInt2);
  
  public static final void webkit_authentication_request_authenticate(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _webkit_authentication_request_authenticate(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _webkit_authentication_request_cancel(int paramInt);
  
  public static final void webkit_authentication_request_cancel(int paramInt)
  {
    lock.lock();
    try
    {
      _webkit_authentication_request_cancel(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _webkit_authentication_request_is_retry(int paramInt);
  
  public static final boolean webkit_authentication_request_is_retry(int paramInt)
  {
    lock.lock();
    try
    {
      boolean bool = _webkit_authentication_request_is_retry(paramInt);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _webkit_credential_free(int paramInt);
  
  public static final void webkit_credential_free(int paramInt)
  {
    lock.lock();
    try
    {
      _webkit_credential_free(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _webkit_credential_new(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, int paramInt);
  
  public static final int webkit_credential_new(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, int paramInt)
  {
    lock.lock();
    try
    {
      int i = _webkit_credential_new(paramArrayOfByte1, paramArrayOfByte2, paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _webkit_dom_event_target_add_event_listener(int paramInt1, byte[] paramArrayOfByte, int paramInt2, int paramInt3, int paramInt4);
  
  public static final int webkit_dom_event_target_add_event_listener(int paramInt1, byte[] paramArrayOfByte, int paramInt2, int paramInt3, int paramInt4)
  {
    lock.lock();
    try
    {
      int i = _webkit_dom_event_target_add_event_listener(paramInt1, paramArrayOfByte, paramInt2, paramInt3, paramInt4);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _webkit_dom_mouse_event_get_alt_key(int paramInt);
  
  public static final int webkit_dom_mouse_event_get_alt_key(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _webkit_dom_mouse_event_get_alt_key(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native short _webkit_dom_mouse_event_get_button(int paramInt);
  
  public static final short webkit_dom_mouse_event_get_button(int paramInt)
  {
    lock.lock();
    try
    {
      short s = _webkit_dom_mouse_event_get_button(paramInt);
      return s;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _webkit_dom_mouse_event_get_ctrl_key(int paramInt);
  
  public static final int webkit_dom_mouse_event_get_ctrl_key(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _webkit_dom_mouse_event_get_ctrl_key(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _webkit_dom_mouse_event_get_meta_key(int paramInt);
  
  public static final int webkit_dom_mouse_event_get_meta_key(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _webkit_dom_mouse_event_get_meta_key(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native long _webkit_dom_mouse_event_get_screen_x(int paramInt);
  
  public static final long webkit_dom_mouse_event_get_screen_x(int paramInt)
  {
    lock.lock();
    try
    {
      long l = _webkit_dom_mouse_event_get_screen_x(paramInt);
      return l;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native long _webkit_dom_mouse_event_get_screen_y(int paramInt);
  
  public static final long webkit_dom_mouse_event_get_screen_y(int paramInt)
  {
    lock.lock();
    try
    {
      long l = _webkit_dom_mouse_event_get_screen_y(paramInt);
      return l;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _webkit_dom_mouse_event_get_shift_key(int paramInt);
  
  public static final int webkit_dom_mouse_event_get_shift_key(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _webkit_dom_mouse_event_get_shift_key(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native long _webkit_dom_ui_event_get_char_code(int paramInt);
  
  public static final long webkit_dom_ui_event_get_char_code(int paramInt)
  {
    lock.lock();
    try
    {
      long l = _webkit_dom_ui_event_get_char_code(paramInt);
      return l;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native long _webkit_dom_ui_event_get_detail(int paramInt);
  
  public static final long webkit_dom_ui_event_get_detail(int paramInt)
  {
    lock.lock();
    try
    {
      long l = _webkit_dom_ui_event_get_detail(paramInt);
      return l;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native long _webkit_dom_ui_event_get_key_code(int paramInt);
  
  public static final long webkit_dom_ui_event_get_key_code(int paramInt)
  {
    lock.lock();
    try
    {
      long l = _webkit_dom_ui_event_get_key_code(paramInt);
      return l;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _webkit_download_cancel(int paramInt);
  
  public static final void webkit_download_cancel(int paramInt)
  {
    lock.lock();
    try
    {
      _webkit_download_cancel(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native long _webkit_download_get_current_size(int paramInt);
  
  public static final long webkit_download_get_current_size(int paramInt)
  {
    lock.lock();
    try
    {
      long l = _webkit_download_get_current_size(paramInt);
      return l;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _webkit_download_get_network_request(int paramInt);
  
  public static final int webkit_download_get_network_request(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _webkit_download_get_network_request(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _webkit_download_get_status(int paramInt);
  
  public static final int webkit_download_get_status(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _webkit_download_get_status(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _webkit_download_get_suggested_filename(int paramInt);
  
  public static final int webkit_download_get_suggested_filename(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _webkit_download_get_suggested_filename(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native long _webkit_download_get_total_size(int paramInt);
  
  public static final long webkit_download_get_total_size(int paramInt)
  {
    lock.lock();
    try
    {
      long l = _webkit_download_get_total_size(paramInt);
      return l;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _webkit_download_get_uri(int paramInt);
  
  public static final int webkit_download_get_uri(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _webkit_download_get_uri(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _webkit_download_new(int paramInt);
  
  public static final int webkit_download_new(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _webkit_download_new(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _webkit_download_set_destination_uri(int paramInt, byte[] paramArrayOfByte);
  
  public static final void webkit_download_set_destination_uri(int paramInt, byte[] paramArrayOfByte)
  {
    lock.lock();
    try
    {
      _webkit_download_set_destination_uri(paramInt, paramArrayOfByte);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _webkit_download_start(int paramInt);
  
  public static final void webkit_download_start(int paramInt)
  {
    lock.lock();
    try
    {
      _webkit_download_start(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _webkit_favicon_database_set_path(int paramInt1, int paramInt2);
  
  public static final void webkit_favicon_database_set_path(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _webkit_favicon_database_set_path(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _webkit_get_default_session();
  
  public static final int webkit_get_default_session()
  {
    lock.lock();
    try
    {
      int i = _webkit_get_default_session();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _webkit_get_favicon_database();
  
  public static final int webkit_get_favicon_database()
  {
    lock.lock();
    try
    {
      int i = _webkit_get_favicon_database();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _webkit_hit_test_result_context_is_link(int paramInt);
  
  public static final boolean webkit_hit_test_result_context_is_link(int paramInt)
  {
    lock.lock();
    try
    {
      boolean bool = _webkit_hit_test_result_context_is_link(paramInt);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _webkit_hit_test_result_get_link_uri(int paramInt);
  
  public static final int webkit_hit_test_result_get_link_uri(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _webkit_hit_test_result_get_link_uri(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _webkit_hit_test_result_get_link_title(int paramInt);
  
  public static final int webkit_hit_test_result_get_link_title(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _webkit_hit_test_result_get_link_title(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _webkit_major_version();
  
  public static final int webkit_major_version()
  {
    lock.lock();
    try
    {
      int i = _webkit_major_version();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _webkit_get_major_version();
  
  public static final int webkit_get_major_version()
  {
    lock.lock();
    try
    {
      int i = _webkit_get_major_version();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _webkit_micro_version();
  
  public static final int webkit_micro_version()
  {
    lock.lock();
    try
    {
      int i = _webkit_micro_version();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _webkit_get_micro_version();
  
  public static final int webkit_get_micro_version()
  {
    lock.lock();
    try
    {
      int i = _webkit_get_micro_version();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _webkit_minor_version();
  
  public static final int webkit_minor_version()
  {
    lock.lock();
    try
    {
      int i = _webkit_minor_version();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _webkit_get_minor_version();
  
  public static final int webkit_get_minor_version()
  {
    lock.lock();
    try
    {
      int i = _webkit_get_minor_version();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _webkit_navigation_policy_decision_get_request(int paramInt);
  
  public static final int webkit_navigation_policy_decision_get_request(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _webkit_navigation_policy_decision_get_request(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _webkit_network_request_get_message(int paramInt);
  
  public static final int webkit_network_request_get_message(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _webkit_network_request_get_message(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _webkit_network_request_get_uri(int paramInt);
  
  public static final int webkit_network_request_get_uri(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _webkit_network_request_get_uri(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _webkit_network_request_new(byte[] paramArrayOfByte);
  
  public static final int webkit_network_request_new(byte[] paramArrayOfByte)
  {
    lock.lock();
    try
    {
      int i = _webkit_network_request_new(paramArrayOfByte);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _webkit_policy_decision_download(int paramInt);
  
  public static final void webkit_policy_decision_download(int paramInt)
  {
    lock.lock();
    try
    {
      _webkit_policy_decision_download(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _webkit_policy_decision_ignore(int paramInt);
  
  public static final void webkit_policy_decision_ignore(int paramInt)
  {
    lock.lock();
    try
    {
      _webkit_policy_decision_ignore(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _webkit_soup_auth_dialog_get_type();
  
  public static final int webkit_soup_auth_dialog_get_type()
  {
    lock.lock();
    try
    {
      int i = _webkit_soup_auth_dialog_get_type();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _webkit_web_context_get_default();
  
  public static final int webkit_web_context_get_default()
  {
    lock.lock();
    try
    {
      int i = _webkit_web_context_get_default();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _webkit_web_context_set_favicon_database_directory(int paramInt1, int paramInt2);
  
  public static final int webkit_web_context_set_favicon_database_directory(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      int i = _webkit_web_context_set_favicon_database_directory(paramInt1, paramInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _webkit_web_data_source_get_data(int paramInt);
  
  public static final int webkit_web_data_source_get_data(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _webkit_web_data_source_get_data(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _webkit_web_data_source_get_encoding(int paramInt);
  
  public static final int webkit_web_data_source_get_encoding(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _webkit_web_data_source_get_encoding(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _webkit_web_frame_get_data_source(int paramInt);
  
  public static final int webkit_web_frame_get_data_source(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _webkit_web_frame_get_data_source(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _webkit_web_frame_get_global_context(int paramInt);
  
  public static final int webkit_web_frame_get_global_context(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _webkit_web_frame_get_global_context(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _webkit_web_frame_get_load_status(int paramInt);
  
  public static final int webkit_web_frame_get_load_status(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _webkit_web_frame_get_load_status(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _webkit_web_frame_get_parent(int paramInt);
  
  public static final int webkit_web_frame_get_parent(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _webkit_web_frame_get_parent(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _webkit_web_frame_get_title(int paramInt);
  
  public static final int webkit_web_frame_get_title(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _webkit_web_frame_get_title(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _webkit_web_frame_get_type();
  
  public static final int webkit_web_frame_get_type()
  {
    lock.lock();
    try
    {
      int i = _webkit_web_frame_get_type();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _webkit_web_frame_get_uri(int paramInt);
  
  public static final int webkit_web_frame_get_uri(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _webkit_web_frame_get_uri(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _webkit_web_frame_get_web_view(int paramInt);
  
  public static final int webkit_web_frame_get_web_view(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _webkit_web_frame_get_web_view(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _webkit_web_policy_decision_download(int paramInt);
  
  public static final void webkit_web_policy_decision_download(int paramInt)
  {
    lock.lock();
    try
    {
      _webkit_web_policy_decision_download(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _webkit_web_policy_decision_ignore(int paramInt);
  
  public static final void webkit_web_policy_decision_ignore(int paramInt)
  {
    lock.lock();
    try
    {
      _webkit_web_policy_decision_ignore(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _webkit_web_view_can_go_back(int paramInt);
  
  public static final int webkit_web_view_can_go_back(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _webkit_web_view_can_go_back(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _webkit_web_view_can_go_forward(int paramInt);
  
  public static final int webkit_web_view_can_go_forward(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _webkit_web_view_can_go_forward(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _webkit_web_view_can_show_mime_type(int paramInt1, int paramInt2);
  
  public static final int webkit_web_view_can_show_mime_type(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      int i = _webkit_web_view_can_show_mime_type(paramInt1, paramInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _webkit_web_view_execute_script(int paramInt, byte[] paramArrayOfByte);
  
  public static final void webkit_web_view_execute_script(int paramInt, byte[] paramArrayOfByte)
  {
    lock.lock();
    try
    {
      _webkit_web_view_execute_script(paramInt, paramArrayOfByte);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _webkit_web_view_get_dom_document(int paramInt);
  
  public static final int webkit_web_view_get_dom_document(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _webkit_web_view_get_dom_document(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native double _webkit_web_view_get_estimated_load_progress(int paramInt);
  
  public static final double webkit_web_view_get_estimated_load_progress(int paramInt)
  {
    lock.lock();
    try
    {
      double d = _webkit_web_view_get_estimated_load_progress(paramInt);
      return d;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _webkit_web_view_get_load_status(int paramInt);
  
  public static final int webkit_web_view_get_load_status(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _webkit_web_view_get_load_status(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _webkit_web_view_get_main_frame(int paramInt);
  
  public static final int webkit_web_view_get_main_frame(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _webkit_web_view_get_main_frame(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native double _webkit_web_view_get_progress(int paramInt);
  
  public static final double webkit_web_view_get_progress(int paramInt)
  {
    lock.lock();
    try
    {
      double d = _webkit_web_view_get_progress(paramInt);
      return d;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _webkit_web_view_get_settings(int paramInt);
  
  public static final int webkit_web_view_get_settings(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _webkit_web_view_get_settings(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _webkit_web_view_get_title(int paramInt);
  
  public static final int webkit_web_view_get_title(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _webkit_web_view_get_title(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _webkit_web_view_get_type();
  
  public static final int webkit_web_view_get_type()
  {
    lock.lock();
    try
    {
      int i = _webkit_web_view_get_type();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _webkit_web_view_get_uri(int paramInt);
  
  public static final int webkit_web_view_get_uri(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _webkit_web_view_get_uri(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _webkit_web_view_get_window_features(int paramInt);
  
  public static final int webkit_web_view_get_window_features(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _webkit_web_view_get_window_features(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _webkit_web_view_go_back(int paramInt);
  
  public static final void webkit_web_view_go_back(int paramInt)
  {
    lock.lock();
    try
    {
      _webkit_web_view_go_back(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _webkit_web_view_go_forward(int paramInt);
  
  public static final void webkit_web_view_go_forward(int paramInt)
  {
    lock.lock();
    try
    {
      _webkit_web_view_go_forward(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _webkit_web_view_load_html(int paramInt, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2);
  
  public static final void webkit_web_view_load_html(int paramInt, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    lock.lock();
    try
    {
      _webkit_web_view_load_html(paramInt, paramArrayOfByte1, paramArrayOfByte2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _webkit_web_view_load_string(int paramInt, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3, byte[] paramArrayOfByte4);
  
  public static final void webkit_web_view_load_string(int paramInt, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3, byte[] paramArrayOfByte4)
  {
    lock.lock();
    try
    {
      _webkit_web_view_load_string(paramInt, paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte3, paramArrayOfByte4);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _webkit_web_view_load_request(int paramInt1, int paramInt2);
  
  public static final void webkit_web_view_load_request(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _webkit_web_view_load_request(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _webkit_web_view_load_uri(int paramInt, byte[] paramArrayOfByte);
  
  public static final void webkit_web_view_load_uri(int paramInt, byte[] paramArrayOfByte)
  {
    lock.lock();
    try
    {
      _webkit_web_view_load_uri(paramInt, paramArrayOfByte);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _webkit_web_view_new();
  
  public static final int webkit_web_view_new()
  {
    lock.lock();
    try
    {
      int i = _webkit_web_view_new();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _webkit_web_view_reload(int paramInt);
  
  public static final void webkit_web_view_reload(int paramInt)
  {
    lock.lock();
    try
    {
      _webkit_web_view_reload(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _webkit_web_view_run_javascript(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5);
  
  public static final void webkit_web_view_run_javascript(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
  {
    lock.lock();
    try
    {
      _webkit_web_view_run_javascript(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _webkit_web_view_stop_loading(int paramInt);
  
  public static final void webkit_web_view_stop_loading(int paramInt)
  {
    lock.lock();
    try
    {
      _webkit_web_view_stop_loading(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _webkit_response_policy_decision_get_request(int paramInt);
  
  public static final int webkit_response_policy_decision_get_request(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _webkit_response_policy_decision_get_request(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _webkit_response_policy_decision_get_response(int paramInt);
  
  public static final int webkit_response_policy_decision_get_response(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _webkit_response_policy_decision_get_response(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _webkit_uri_request_new(byte[] paramArrayOfByte);
  
  public static final int webkit_uri_request_new(byte[] paramArrayOfByte)
  {
    lock.lock();
    try
    {
      int i = _webkit_uri_request_new(paramArrayOfByte);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _webkit_uri_request_get_http_headers(int paramInt);
  
  public static final int webkit_uri_request_get_http_headers(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _webkit_uri_request_get_http_headers(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _webkit_uri_request_get_uri(int paramInt);
  
  public static final int webkit_uri_request_get_uri(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _webkit_uri_request_get_uri(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _webkit_uri_response_get_mime_type(int paramInt);
  
  public static final int webkit_uri_response_get_mime_type(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _webkit_uri_response_get_mime_type(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int JSClassDefinition_sizeof();
  
  public static final native void memmove(int paramInt1, JSClassDefinition paramJSClassDefinition, int paramInt2);
  
  public static final native int _SoupCookie_expires(int paramInt);
  
  public static final int SoupCookie_expires(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _SoupCookie_expires(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _SoupMessage_method(int paramInt1, int paramInt2);
  
  public static final void SoupMessage_method(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      _SoupMessage_method(paramInt1, paramInt2);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _SoupMessage_request_body(int paramInt);
  
  public static final int SoupMessage_request_body(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _SoupMessage_request_body(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _SoupMessage_request_headers(int paramInt);
  
  public static final int SoupMessage_request_headers(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _SoupMessage_request_headers(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/internal/webkit/WebKitGTK.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */