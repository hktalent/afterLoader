package org.eclipse.swt.internal.mozilla;

public class nsISSLStatus
  extends nsISupports
{
  static final int LAST_METHOD_ID = nsISupports.LAST_METHOD_ID + ((IsXULRunner10()) || (IsXULRunner24()) ? 8 : 7);
  static final String NS_ISSLSTATUS_IID_STR = "cfede939-def1-49be-81ed-d401b3a07d1c";
  static final String NS_ISSLSTATUS_10_IID_STR = "3f1fcd83-c5a9-4cd1-a250-7676ca7c7e34";
  
  public nsISSLStatus(int paramInt)
  {
    super(paramInt);
  }
  
  public int GetServerCert(int[] paramArrayOfInt)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 1, getAddress(), paramArrayOfInt);
  }
  
  public int GetIsDomainMismatch(int[] paramArrayOfInt)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 5, getAddress(), paramArrayOfInt);
  }
  
  public int GetIsNotValidAtThisTime(int[] paramArrayOfInt)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 6, getAddress(), paramArrayOfInt);
  }
  
  public int GetIsUntrusted(int[] paramArrayOfInt)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 7, getAddress(), paramArrayOfInt);
  }
  
  static
  {
    IIDStore.RegisterIID(nsISSLStatus.class, 0, new nsID("cfede939-def1-49be-81ed-d401b3a07d1c"));
    IIDStore.RegisterIID(nsISSLStatus.class, 5, new nsID("3f1fcd83-c5a9-4cd1-a250-7676ca7c7e34"));
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/internal/mozilla/nsISSLStatus.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */