package org.eclipse.swt.awt;

import java.awt.AWTEvent;
import java.awt.Canvas;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Frame;
import java.awt.Toolkit;
import java.awt.Window;
import java.awt.event.AWTEventListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.awt.event.WindowEvent;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Device;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.internal.Library;
import org.eclipse.swt.internal.gtk.OS;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Shell;

public class SWT_AWT
{
  public static String embeddedFrameClass;
  static String EMBEDDED_FRAME_KEY = "org.eclipse.swt.awt.SWT_AWT.embeddedFrame";
  static boolean loaded;
  static boolean swingInitialized;
  
  static final native int getAWTHandle(Object paramObject);
  
  static final native void setDebug(Frame paramFrame, boolean paramBoolean);
  
  static synchronized void loadLibrary()
  {
    if (loaded) {
      return;
    }
    loaded = true;
    try
    {
      System.loadLibrary("jawt");
    }
    catch (Throwable localThrowable) {}
    Library.loadLibrary("swt-awt");
  }
  
  static synchronized void initializeSwing()
  {
    if (swingInitialized) {
      return;
    }
    swingInitialized = true;
    OS.gdk_error_trap_push();
    try
    {
      Class[] arrayOfClass = new Class[0];
      Object[] arrayOfObject = new Object[0];
      Class localClass = Class.forName("javax.swing.UIManager");
      Method localMethod = localClass.getMethod("getDefaults", arrayOfClass);
      if (localMethod != null) {
        localMethod.invoke(localClass, arrayOfObject);
      }
    }
    catch (Throwable localThrowable) {}
  }
  
  public static Frame getFrame(Composite paramComposite)
  {
    if (paramComposite == null) {
      SWT.error(4);
    }
    if ((paramComposite.getStyle() & 0x1000000) == 0) {
      return null;
    }
    return (Frame)paramComposite.getData(EMBEDDED_FRAME_KEY);
  }
  
  public static Frame new_Frame(final Composite paramComposite)
  {
    if (paramComposite == null) {
      SWT.error(4);
    }
    if ((paramComposite.getStyle() & 0x1000000) == 0) {
      SWT.error(5);
    }
    int i = paramComposite.embeddedHandle;
    Class localClass = null;
    try
    {
      String str = embeddedFrameClass != null ? embeddedFrameClass : "sun.awt.X11.XEmbeddedFrame";
      localClass = Class.forName(str);
    }
    catch (Throwable localThrowable1)
    {
      SWT.error(20, localThrowable1, " [need JDK 1.5 or greater]");
    }
    initializeSwing();
    Object localObject = null;
    Constructor localConstructor = null;
    try
    {
      localConstructor = localClass.getConstructor(new Class[] { Integer.TYPE, Boolean.TYPE });
      localObject = localConstructor.newInstance(new Object[] { new Integer(i), Boolean.TRUE });
    }
    catch (Throwable localThrowable2)
    {
      try
      {
        localConstructor = localClass.getConstructor(new Class[] { Long.TYPE, Boolean.TYPE });
        localObject = localConstructor.newInstance(new Object[] { new Long(i), Boolean.TRUE });
      }
      catch (Throwable localThrowable3)
      {
        SWT.error(20, localThrowable3);
      }
    }
    final Frame localFrame = (Frame)localObject;
    paramComposite.setData(EMBEDDED_FRAME_KEY, localFrame);
    if (Device.DEBUG)
    {
      loadLibrary();
      setDebug(localFrame, true);
    }
    try
    {
      Method localMethod = localClass.getMethod("registerListeners", (Class[])null);
      if (localMethod != null) {
        localMethod.invoke(localObject, (Object[])null);
      }
    }
    catch (Throwable localThrowable4) {}
    final AWTEventListener local1 = new AWTEventListener()
    {
      public void eventDispatched(AWTEvent paramAnonymousAWTEvent)
      {
        if (paramAnonymousAWTEvent.getID() == 200)
        {
          final Window localWindow = (Window)paramAnonymousAWTEvent.getSource();
          if (localWindow.getParent() == this.val$frame) {
            paramComposite.getDisplay().asyncExec(new Runnable()
            {
              public void run()
              {
                if (SWT_AWT.1.this.val$parent.isDisposed()) {
                  return;
                }
                Shell localShell = SWT_AWT.1.this.val$parent.getShell();
                SWT_AWT.loadLibrary();
                int i = SWT_AWT.getAWTHandle(localWindow);
                if (i == 0) {
                  return;
                }
                int j;
                if (OS.GTK3) {
                  j = OS.gdk_x11_window_get_xid(OS.gtk_widget_get_window(localShell.handle));
                } else if (OS.GTK_VERSION >= OS.VERSION(2, 14, 0)) {
                  j = OS.gdk_x11_drawable_get_xid(OS.gtk_widget_get_window(OS.gtk_widget_get_toplevel(localShell.handle)));
                } else {
                  j = OS.gdk_x11_drawable_get_xid(OS.GTK_WIDGET_WINDOW(OS.gtk_widget_get_toplevel(localShell.handle)));
                }
                OS.XSetTransientForHint(OS.gdk_x11_display_get_xdisplay(OS.gdk_display_get_default()), i, j);
              }
            });
          }
        }
      }
    };
    localFrame.getToolkit().addAWTEventListener(local1, 64L);
    final Listener local2 = new Listener()
    {
      public void handleEvent(Event paramAnonymousEvent)
      {
        switch (paramAnonymousEvent.type)
        {
        case 20: 
          EventQueue.invokeLater(new Runnable()
          {
            public void run()
            {
              SWT_AWT.2.this.val$frame.dispatchEvent(new WindowEvent(SWT_AWT.2.this.val$frame, 204));
            }
          });
          break;
        case 19: 
          EventQueue.invokeLater(new Runnable()
          {
            public void run()
            {
              SWT_AWT.2.this.val$frame.dispatchEvent(new WindowEvent(SWT_AWT.2.this.val$frame, 203));
            }
          });
        }
      }
    };
    Shell localShell = paramComposite.getShell();
    localShell.addListener(20, local2);
    localShell.addListener(19, local2);
    Listener local3 = new Listener()
    {
      public void handleEvent(Event paramAnonymousEvent)
      {
        switch (paramAnonymousEvent.type)
        {
        case 12: 
          Shell localShell = this.val$parent.getShell();
          localShell.removeListener(20, local2);
          localShell.removeListener(19, local2);
          this.val$parent.setVisible(false);
          EventQueue.invokeLater(new Runnable()
          {
            public void run()
            {
              SWT_AWT.3.this.val$frame.getToolkit().removeAWTEventListener(SWT_AWT.3.this.val$awtListener);
              SWT_AWT.3.this.val$frame.dispose();
            }
          });
          break;
        case 11: 
          if (Library.JAVA_VERSION >= Library.JAVA_VERSION(1, 6, 0))
          {
            final Rectangle localRectangle = this.val$parent.getClientArea();
            EventQueue.invokeLater(new Runnable()
            {
              public void run()
              {
                SWT_AWT.3.this.val$frame.setSize(localRectangle.width, localRectangle.height);
              }
            });
          }
          break;
        }
      }
    };
    paramComposite.addListener(12, local3);
    paramComposite.addListener(11, local3);
    paramComposite.getDisplay().asyncExec(new Runnable()
    {
      public void run()
      {
        if (this.val$parent.isDisposed()) {
          return;
        }
        final Rectangle localRectangle = this.val$parent.getClientArea();
        EventQueue.invokeLater(new Runnable()
        {
          public void run()
          {
            SWT_AWT.4.this.val$frame.setSize(localRectangle.width, localRectangle.height);
            SWT_AWT.4.this.val$frame.validate();
          }
        });
      }
    });
    return localFrame;
  }
  
  public static Shell new_Shell(Display paramDisplay, final Canvas paramCanvas)
  {
    if (paramDisplay == null) {
      SWT.error(4);
    }
    if (paramCanvas == null) {
      SWT.error(4);
    }
    int i = 0;
    try
    {
      loadLibrary();
      i = getAWTHandle(paramCanvas);
    }
    catch (Throwable localThrowable)
    {
      SWT.error(20, localThrowable);
    }
    if (i == 0) {
      SWT.error(5, null, " [peer not created]");
    }
    final Shell localShell = Shell.gtk_new(paramDisplay, i);
    final ComponentAdapter local5 = new ComponentAdapter()
    {
      public void componentResized(ComponentEvent paramAnonymousComponentEvent)
      {
        this.val$display.syncExec(new Runnable()
        {
          public void run()
          {
            if (SWT_AWT.5.this.val$shell.isDisposed()) {
              return;
            }
            Dimension localDimension = SWT_AWT.5.this.val$parent.getSize();
            SWT_AWT.5.this.val$shell.setSize(localDimension.width, localDimension.height);
          }
        });
      }
    };
    paramCanvas.addComponentListener(local5);
    localShell.addListener(12, new Listener()
    {
      public void handleEvent(Event paramAnonymousEvent)
      {
        this.val$parent.removeComponentListener(local5);
      }
    });
    localShell.setVisible(true);
    return localShell;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/awt/SWT_AWT.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */