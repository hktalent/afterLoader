package org.eclipse.swt.dnd;

import org.eclipse.swt.internal.gtk.OS;

public class FileTransfer
  extends ByteArrayTransfer
{
  private static FileTransfer _instance = new FileTransfer();
  private static final String URI_LIST = "text/uri-list";
  private static final int URI_LIST_ID = registerType("text/uri-list");
  private static final String GNOME_LIST = "x-special/gnome-copied-files";
  private static final int GNOME_LIST_ID = registerType("x-special/gnome-copied-files");
  
  public static FileTransfer getInstance()
  {
    return _instance;
  }
  
  public void javaToNative(Object paramObject, TransferData paramTransferData)
  {
    paramTransferData.result = 0;
    if ((!checkFile(paramObject)) || (!isSupportedType(paramTransferData))) {
      DND.error(2003);
    }
    int i = paramTransferData.type == GNOME_LIST_ID ? 1 : 0;
    Object localObject;
    byte[] arrayOfByte1;
    if (i != 0)
    {
      localObject = new byte[] { 99, 111, 112, 121 };
      arrayOfByte1 = new byte[] { 10 };
    }
    else
    {
      localObject = new byte[0];
      arrayOfByte1 = new byte[] { 13, 10 };
    }
    String[] arrayOfString = (String[])paramObject;
    for (int j = 0; j < arrayOfString.length; j++)
    {
      String str = arrayOfString[j];
      if (str != null)
      {
        int k = str.length();
        if (k != 0)
        {
          char[] arrayOfChar = new char[k];
          str.getChars(0, k, arrayOfChar, 0);
          int[] arrayOfInt = new int[1];
          int m = OS.g_utf16_to_utf8(arrayOfChar, arrayOfChar.length, null, null, arrayOfInt);
          if ((arrayOfInt[0] == 0) && (m != 0))
          {
            int n = OS.g_filename_from_utf8(m, -1, null, null, arrayOfInt);
            OS.g_free(m);
            if ((arrayOfInt[0] == 0) && (n != 0))
            {
              int i1 = OS.g_filename_to_uri(n, 0, arrayOfInt);
              OS.g_free(n);
              if ((arrayOfInt[0] == 0) && (i1 != 0))
              {
                k = OS.strlen(i1);
                byte[] arrayOfByte2 = new byte[k];
                OS.memmove(arrayOfByte2, i1, k);
                OS.g_free(i1);
                int i2 = localObject.length > 0 ? localObject.length + arrayOfByte1.length + arrayOfByte2.length : arrayOfByte2.length;
                byte[] arrayOfByte3 = new byte[i2];
                int i3 = 0;
                if (localObject.length > 0)
                {
                  System.arraycopy(localObject, 0, arrayOfByte3, 0, localObject.length);
                  i3 += localObject.length;
                  System.arraycopy(arrayOfByte1, 0, arrayOfByte3, i3, arrayOfByte1.length);
                  i3 += arrayOfByte1.length;
                }
                System.arraycopy(arrayOfByte2, 0, arrayOfByte3, i3, arrayOfByte2.length);
                localObject = arrayOfByte3;
              }
            }
          }
        }
      }
    }
    if (localObject.length == 0) {
      return;
    }
    j = OS.g_malloc(localObject.length + 1);
    OS.memset(j, 0, localObject.length + 1);
    OS.memmove(j, (byte[])localObject, localObject.length);
    paramTransferData.pValue = j;
    paramTransferData.length = localObject.length;
    paramTransferData.format = 8;
    paramTransferData.result = 1;
  }
  
  public Object nativeToJava(TransferData paramTransferData)
  {
    if ((!isSupportedType(paramTransferData)) || (paramTransferData.pValue == 0) || (paramTransferData.length <= 0)) {
      return null;
    }
    int i = paramTransferData.length;
    byte[] arrayOfByte1 = new byte[i];
    OS.memmove(arrayOfByte1, paramTransferData.pValue, i);
    int j = paramTransferData.type == GNOME_LIST_ID ? 1 : 0;
    int k = j != 0 ? 1 : 2;
    Object localObject1 = new int[0];
    int m = 0;
    int[] arrayOfInt2;
    for (int n = 0; n < arrayOfByte1.length - 1; n++)
    {
      i1 = (arrayOfByte1[n] == 13) && (arrayOfByte1[(n + 1)] == 10) ? 1 : j != 0 ? 0 : arrayOfByte1[n] == 10 ? 1 : 0;
      if (i1 != 0)
      {
        if ((j == 0) || (m != 0))
        {
          int i2 = n - m;
          int i3 = OS.g_malloc(i2 + 1);
          byte[] arrayOfByte2 = new byte[i2 + 1];
          System.arraycopy(arrayOfByte1, m, arrayOfByte2, 0, i2);
          OS.memmove(i3, arrayOfByte2, i2 + 1);
          arrayOfInt2 = new int[localObject1.length + 1];
          System.arraycopy(localObject1, 0, arrayOfInt2, 0, localObject1.length);
          arrayOfInt2[localObject1.length] = i3;
          localObject1 = arrayOfInt2;
        }
        m = n + k;
      }
    }
    Object localObject3;
    if (m < arrayOfByte1.length - k)
    {
      n = arrayOfByte1.length - m;
      i1 = OS.g_malloc(n + 1);
      localObject3 = new byte[n + 1];
      System.arraycopy(arrayOfByte1, m, localObject3, 0, n);
      OS.memmove(i1, (byte[])localObject3, n + 1);
      int[] arrayOfInt1 = new int[localObject1.length + 1];
      System.arraycopy(localObject1, 0, arrayOfInt1, 0, localObject1.length);
      arrayOfInt1[localObject1.length] = i1;
      localObject1 = arrayOfInt1;
    }
    Object localObject2 = new String[0];
    for (int i1 = 0; i1 < localObject1.length; i1++)
    {
      localObject3 = new int[1];
      int i4 = OS.g_filename_from_uri(localObject1[i1], null, (int[])localObject3);
      OS.g_free(localObject1[i1]);
      if ((localObject3[0] == 0) && (i4 != 0))
      {
        int i5 = OS.g_filename_to_utf8(i4, -1, null, null, null);
        if (i5 == 0) {
          i5 = OS.g_filename_display_name(i4);
        }
        if (i4 != i5) {
          OS.g_free(i4);
        }
        if (i5 != 0)
        {
          arrayOfInt2 = new int[1];
          int i6 = OS.g_utf8_to_utf16(i5, -1, null, arrayOfInt2, null);
          OS.g_free(i5);
          if (i6 != 0)
          {
            i = arrayOfInt2[0];
            char[] arrayOfChar = new char[i];
            OS.memmove(arrayOfChar, i6, i * 2);
            OS.g_free(i6);
            String str = new String(arrayOfChar);
            String[] arrayOfString = new String[localObject2.length + 1];
            System.arraycopy(localObject2, 0, arrayOfString, 0, localObject2.length);
            arrayOfString[localObject2.length] = str;
            localObject2 = arrayOfString;
          }
        }
      }
    }
    if (localObject2.length == 0) {
      return null;
    }
    return localObject2;
  }
  
  protected int[] getTypeIds()
  {
    return new int[] { URI_LIST_ID, GNOME_LIST_ID };
  }
  
  protected String[] getTypeNames()
  {
    return new String[] { "text/uri-list", "x-special/gnome-copied-files" };
  }
  
  boolean checkFile(Object paramObject)
  {
    if ((paramObject == null) || (!(paramObject instanceof String[])) || (((String[])paramObject).length == 0)) {
      return false;
    }
    String[] arrayOfString = (String[])paramObject;
    for (int i = 0; i < arrayOfString.length; i++) {
      if ((arrayOfString[i] == null) || (arrayOfString[i].length() == 0)) {
        return false;
      }
    }
    return true;
  }
  
  protected boolean validate(Object paramObject)
  {
    return checkFile(paramObject);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/dnd/FileTransfer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */