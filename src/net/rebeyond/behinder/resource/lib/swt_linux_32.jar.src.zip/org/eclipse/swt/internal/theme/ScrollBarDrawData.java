package org.eclipse.swt.internal.theme;

import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;

public class ScrollBarDrawData
  extends RangeDrawData
{
  public int thumb;
  public int increment;
  public int pageIncrement;
  
  public ScrollBarDrawData()
  {
    this.state = new int[6];
  }
  
  void draw(Theme paramTheme, GC paramGC, Rectangle paramRectangle) {}
  
  int hit(Theme paramTheme, Point paramPoint, Rectangle paramRectangle)
  {
    return paramRectangle.contains(paramPoint) ? 0 : -1;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/internal/theme/ScrollBarDrawData.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */