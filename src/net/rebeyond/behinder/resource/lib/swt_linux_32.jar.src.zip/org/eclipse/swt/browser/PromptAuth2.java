package org.eclipse.swt.browser;

import org.eclipse.swt.SWT;
import org.eclipse.swt.internal.C;
import org.eclipse.swt.internal.Compatibility;
import org.eclipse.swt.internal.mozilla.IIDStore;
import org.eclipse.swt.internal.mozilla.XPCOM;
import org.eclipse.swt.internal.mozilla.XPCOMObject;
import org.eclipse.swt.internal.mozilla.nsEmbedString;
import org.eclipse.swt.internal.mozilla.nsIAuthInformation;
import org.eclipse.swt.internal.mozilla.nsIChannel;
import org.eclipse.swt.internal.mozilla.nsID;
import org.eclipse.swt.internal.mozilla.nsISupports;
import org.eclipse.swt.internal.mozilla.nsIURI;
import org.eclipse.swt.widgets.Shell;

class PromptAuth2
{
  XPCOMObject supports;
  XPCOMObject promptAuth;
  int refCount = 0;
  int parent;
  
  PromptAuth2()
  {
    createCOMInterfaces();
  }
  
  int AddRef()
  {
    this.refCount += 1;
    return this.refCount;
  }
  
  void createCOMInterfaces()
  {
    this.supports = new XPCOMObject(new int[] { 2, 0, 0 })
    {
      public int method0(int[] paramAnonymousArrayOfInt)
      {
        return PromptAuth2.this.QueryInterface(paramAnonymousArrayOfInt[0], paramAnonymousArrayOfInt[1]);
      }
      
      public int method1(int[] paramAnonymousArrayOfInt)
      {
        return PromptAuth2.this.AddRef();
      }
      
      public int method2(int[] paramAnonymousArrayOfInt)
      {
        return PromptAuth2.this.Release();
      }
    };
    this.promptAuth = new XPCOMObject(new int[] { 2, 0, 0, 4, 6 })
    {
      public int method0(int[] paramAnonymousArrayOfInt)
      {
        return PromptAuth2.this.QueryInterface(paramAnonymousArrayOfInt[0], paramAnonymousArrayOfInt[1]);
      }
      
      public int method1(int[] paramAnonymousArrayOfInt)
      {
        return PromptAuth2.this.AddRef();
      }
      
      public int method2(int[] paramAnonymousArrayOfInt)
      {
        return PromptAuth2.this.Release();
      }
      
      public int method3(int[] paramAnonymousArrayOfInt)
      {
        return PromptAuth2.this.PromptAuth(paramAnonymousArrayOfInt[0], paramAnonymousArrayOfInt[1], paramAnonymousArrayOfInt[2], paramAnonymousArrayOfInt[3]);
      }
      
      public int method4(int[] paramAnonymousArrayOfInt)
      {
        return PromptAuth2.this.AsyncPromptAuth(paramAnonymousArrayOfInt[0], paramAnonymousArrayOfInt[1], paramAnonymousArrayOfInt[2], paramAnonymousArrayOfInt[3], paramAnonymousArrayOfInt[4], paramAnonymousArrayOfInt[5]);
      }
    };
  }
  
  void disposeCOMInterfaces()
  {
    if (this.supports != null)
    {
      this.supports.dispose();
      this.supports = null;
    }
    if (this.promptAuth != null)
    {
      this.promptAuth.dispose();
      this.promptAuth = null;
    }
  }
  
  int getAddress()
  {
    return this.promptAuth.getAddress();
  }
  
  int QueryInterface(int paramInt1, int paramInt2)
  {
    if ((paramInt1 == 0) || (paramInt2 == 0)) {
      return -2147467262;
    }
    nsID localnsID = new nsID();
    XPCOM.memmove(localnsID, paramInt1, 16);
    if (localnsID.Equals(IIDStore.GetIID(nsISupports.class)))
    {
      XPCOM.memmove(paramInt2, new int[] { this.supports.getAddress() }, C.PTR_SIZEOF);
      AddRef();
      return 0;
    }
    if (localnsID.Equals(XPCOM.NS_IAUTHPROMPT2_IID))
    {
      XPCOM.memmove(paramInt2, new int[] { this.promptAuth.getAddress() }, C.PTR_SIZEOF);
      AddRef();
      return 0;
    }
    XPCOM.memmove(paramInt2, new int[] { 0 }, C.PTR_SIZEOF);
    return -2147467262;
  }
  
  int Release()
  {
    this.refCount -= 1;
    if (this.refCount == 0) {
      disposeCOMInterfaces();
    }
    return this.refCount;
  }
  
  Browser getBrowser()
  {
    if (this.parent == 0) {
      return null;
    }
    return Mozilla.getBrowser(this.parent);
  }
  
  void setParent(int paramInt)
  {
    this.parent = paramInt;
  }
  
  int PromptAuth(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    nsIAuthInformation localnsIAuthInformation = new nsIAuthInformation(paramInt3);
    Browser localBrowser = getBrowser();
    if (localBrowser != null)
    {
      localMozilla = (Mozilla)localBrowser.webBrowser;
      if (localMozilla.authCount++ < 3) {
        for (int i = 0; i < localMozilla.authenticationListeners.length; i++)
        {
          localObject1 = new AuthenticationEvent(localBrowser);
          ((AuthenticationEvent)localObject1).location = localMozilla.lastNavigateURL;
          localMozilla.authenticationListeners[i].authenticate((AuthenticationEvent)localObject1);
          if (!((AuthenticationEvent)localObject1).doit)
          {
            XPCOM.memmove(paramInt4, new boolean[] { false });
            return 0;
          }
          if ((((AuthenticationEvent)localObject1).user != null) && (((AuthenticationEvent)localObject1).password != null))
          {
            localObject2 = new nsEmbedString(((AuthenticationEvent)localObject1).user);
            int j = localnsIAuthInformation.SetUsername(((nsEmbedString)localObject2).getAddress());
            if (j != 0) {
              SWT.error(j);
            }
            ((nsEmbedString)localObject2).dispose();
            localObject2 = new nsEmbedString(((AuthenticationEvent)localObject1).password);
            j = localnsIAuthInformation.SetPassword(((nsEmbedString)localObject2).getAddress());
            if (j != 0) {
              SWT.error(j);
            }
            ((nsEmbedString)localObject2).dispose();
            XPCOM.memmove(paramInt4, new boolean[] { true });
            return 0;
          }
        }
      }
    }
    Mozilla localMozilla = null;
    boolean[] arrayOfBoolean1 = new boolean[1];
    Object localObject1 = new String[1];
    Object localObject2 = new String[1];
    String str1 = SWT.getMessage("SWT_Authentication_Required");
    int k = XPCOM.nsEmbedString_new();
    int m = localnsIAuthInformation.GetUsername(k);
    if (m != 0) {
      SWT.error(m);
    }
    int n = XPCOM.nsEmbedString_Length(k);
    int i1 = XPCOM.nsEmbedString_get(k);
    char[] arrayOfChar = new char[n];
    XPCOM.memmove(arrayOfChar, i1, n * 2);
    localObject1[0] = new String(arrayOfChar);
    XPCOM.nsEmbedString_delete(k);
    k = XPCOM.nsEmbedString_new();
    m = localnsIAuthInformation.GetPassword(k);
    if (m != 0) {
      SWT.error(m);
    }
    n = XPCOM.nsEmbedString_Length(k);
    i1 = XPCOM.nsEmbedString_get(k);
    arrayOfChar = new char[n];
    XPCOM.memmove(arrayOfChar, i1, n * 2);
    localObject2[0] = new String(arrayOfChar);
    XPCOM.nsEmbedString_delete(k);
    k = XPCOM.nsEmbedString_new();
    m = localnsIAuthInformation.GetRealm(k);
    if (m != 0) {
      SWT.error(m);
    }
    n = XPCOM.nsEmbedString_Length(k);
    i1 = XPCOM.nsEmbedString_get(k);
    arrayOfChar = new char[n];
    XPCOM.memmove(arrayOfChar, i1, n * 2);
    String str2 = new String(arrayOfChar);
    XPCOM.nsEmbedString_delete(k);
    nsIChannel localnsIChannel = new nsIChannel(paramInt1);
    int[] arrayOfInt = new int[1];
    m = localnsIChannel.GetURI(arrayOfInt);
    if (m != 0) {
      SWT.error(m);
    }
    if (arrayOfInt[0] == 0) {
      Mozilla.error(-2147467262);
    }
    nsIURI localnsIURI = new nsIURI(arrayOfInt[0]);
    int i2 = XPCOM.nsEmbedCString_new();
    m = localnsIURI.GetHost(i2);
    if (m != 0) {
      SWT.error(m);
    }
    n = XPCOM.nsEmbedCString_Length(i2);
    i1 = XPCOM.nsEmbedCString_get(i2);
    byte[] arrayOfByte = new byte[n];
    XPCOM.memmove(arrayOfByte, i1, n);
    String str3 = new String(arrayOfByte);
    XPCOM.nsEmbedCString_delete(i2);
    localnsIURI.Release();
    String str4;
    if ((str2.length() > 0) && (str3.length() > 0)) {
      str4 = Compatibility.getMessage("SWT_Enter_Username_and_Password", new String[] { str2, str3 });
    } else {
      str4 = "";
    }
    Shell localShell = localBrowser == null ? new Shell() : localBrowser.getShell();
    PromptDialog localPromptDialog = new PromptDialog(localShell);
    boolean[] arrayOfBoolean2 = new boolean[1];
    localPromptDialog.promptUsernameAndPassword(str1, str4, localMozilla, (String[])localObject1, (String[])localObject2, arrayOfBoolean1, arrayOfBoolean2);
    XPCOM.memmove(paramInt4, arrayOfBoolean2);
    if (arrayOfBoolean2[0] != 0)
    {
      nsEmbedString localnsEmbedString = new nsEmbedString(localObject1[0]);
      m = localnsIAuthInformation.SetUsername(localnsEmbedString.getAddress());
      if (m != 0) {
        SWT.error(m);
      }
      localnsEmbedString.dispose();
      localnsEmbedString = new nsEmbedString(localObject2[0]);
      m = localnsIAuthInformation.SetPassword(localnsEmbedString.getAddress());
      if (m != 0) {
        SWT.error(m);
      }
      localnsEmbedString.dispose();
    }
    return 0;
  }
  
  int AsyncPromptAuth(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6)
  {
    return -2147467263;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/browser/PromptAuth2.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */