package org.eclipse.swt.internal.gnome;

import org.eclipse.swt.internal.Library;
import org.eclipse.swt.internal.Lock;
import org.eclipse.swt.internal.Platform;

public class GNOME
  extends Platform
{
  public static final int GNOME_FILE_DOMAIN_PIXMAP = 4;
  public static final int GNOME_ICON_LOOKUP_FLAGS_NONE = 0;
  public static final int GNOME_PARAM_NONE = 0;
  public static final int GNOME_VFS_MIME_APPLICATION_ARGUMENT_TYPE_URIS = 0;
  public static final int GNOME_VFS_MIME_IDENTICAL = 1;
  public static final int GNOME_VFS_MIME_PARENT = 2;
  public static final int GNOME_VFS_MIME_UNRELATED = 0;
  public static final int GNOME_VFS_OK = 0;
  public static final int GNOME_VFS_MAKE_URI_DIR_NONE = 0;
  public static final int GNOME_VFS_MAKE_URI_DIR_HOMEDIR = 1;
  public static final int GNOME_VFS_MAKE_URI_DIR_CURRENT = 2;
  
  public static final native int GnomeVFSMimeApplication_sizeof();
  
  public static final native int _gnome_icon_lookup(int paramInt1, int paramInt2, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, int paramInt3, byte[] paramArrayOfByte3, int paramInt4, int[] paramArrayOfInt);
  
  public static final int gnome_icon_lookup(int paramInt1, int paramInt2, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, int paramInt3, byte[] paramArrayOfByte3, int paramInt4, int[] paramArrayOfInt)
  {
    lock.lock();
    try
    {
      int i = _gnome_icon_lookup(paramInt1, paramInt2, paramArrayOfByte1, paramArrayOfByte2, paramInt3, paramArrayOfByte3, paramInt4, paramArrayOfInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gnome_icon_theme_lookup_icon(int paramInt1, int paramInt2, int paramInt3, int[] paramArrayOfInt1, int[] paramArrayOfInt2);
  
  public static final int gnome_icon_theme_lookup_icon(int paramInt1, int paramInt2, int paramInt3, int[] paramArrayOfInt1, int[] paramArrayOfInt2)
  {
    lock.lock();
    try
    {
      int i = _gnome_icon_theme_lookup_icon(paramInt1, paramInt2, paramInt3, paramArrayOfInt1, paramArrayOfInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gnome_icon_theme_new();
  
  public static final int gnome_icon_theme_new()
  {
    lock.lock();
    try
    {
      int i = _gnome_icon_theme_new();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gnome_vfs_get_mime_type(int paramInt);
  
  public static final int gnome_vfs_get_mime_type(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gnome_vfs_get_mime_type(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _gnome_vfs_init();
  
  public static final boolean gnome_vfs_init()
  {
    lock.lock();
    try
    {
      boolean bool = _gnome_vfs_init();
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gnome_vfs_make_uri_from_input(byte[] paramArrayOfByte);
  
  public static final int gnome_vfs_make_uri_from_input(byte[] paramArrayOfByte)
  {
    lock.lock();
    try
    {
      int i = _gnome_vfs_make_uri_from_input(paramArrayOfByte);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gnome_vfs_make_uri_from_input_with_dirs(byte[] paramArrayOfByte, int paramInt);
  
  public static final int gnome_vfs_make_uri_from_input_with_dirs(byte[] paramArrayOfByte, int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gnome_vfs_make_uri_from_input_with_dirs(paramArrayOfByte, paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _gnome_vfs_mime_application_free(int paramInt);
  
  public static final void gnome_vfs_mime_application_free(int paramInt)
  {
    lock.lock();
    try
    {
      _gnome_vfs_mime_application_free(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _gnome_vfs_is_executable_command_string(byte[] paramArrayOfByte);
  
  public static final boolean gnome_vfs_is_executable_command_string(byte[] paramArrayOfByte)
  {
    lock.lock();
    try
    {
      boolean bool = _gnome_vfs_is_executable_command_string(paramArrayOfByte);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gnome_vfs_mime_application_launch(int paramInt1, int paramInt2);
  
  public static final int gnome_vfs_mime_application_launch(int paramInt1, int paramInt2)
  {
    lock.lock();
    try
    {
      int i = _gnome_vfs_mime_application_launch(paramInt1, paramInt2);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gnome_vfs_mime_get_default_application(byte[] paramArrayOfByte);
  
  public static final int gnome_vfs_mime_get_default_application(byte[] paramArrayOfByte)
  {
    lock.lock();
    try
    {
      int i = _gnome_vfs_mime_get_default_application(paramArrayOfByte);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gnome_vfs_mime_type_from_name(byte[] paramArrayOfByte);
  
  public static final int gnome_vfs_mime_type_from_name(byte[] paramArrayOfByte)
  {
    lock.lock();
    try
    {
      int i = _gnome_vfs_mime_type_from_name(paramArrayOfByte);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gnome_vfs_mime_type_get_equivalence(int paramInt, byte[] paramArrayOfByte);
  
  public static final int gnome_vfs_mime_type_get_equivalence(int paramInt, byte[] paramArrayOfByte)
  {
    lock.lock();
    try
    {
      int i = _gnome_vfs_mime_type_get_equivalence(paramInt, paramArrayOfByte);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _gnome_vfs_url_show(int paramInt);
  
  public static final int gnome_vfs_url_show(int paramInt)
  {
    lock.lock();
    try
    {
      int i = _gnome_vfs_url_show(paramInt);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void memmove(GnomeVFSMimeApplication paramGnomeVFSMimeApplication, int paramInt1, int paramInt2);
  
  static
  {
    Library.loadLibrary("swt-gnome");
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/internal/gnome/GNOME.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */