package org.eclipse.swt.internal.opengl.glx;

public class XVisualInfo
{
  public int visual;
  public int visualid;
  public int screen;
  public int depth;
  public int cclass;
  public int red_mask;
  public int green_mask;
  public int blue_mask;
  public int colormap_size;
  public int bits_per_rgb;
  public static final int sizeof = ;
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/internal/opengl/glx/XVisualInfo.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */