package org.eclipse.swt.internal.mozilla;

public class nsILocalFile
  extends nsIFile
{
  static final int LAST_METHOD_ID = nsIFile.LAST_METHOD_ID + (IsXULRunner24() ? 0 : 17);
  static final String NS_ILOCALFILE_IID_STR = "aa610f20-a889-11d3-8c81-000064657374";
  static final String NS_ILOCALFILE_24_IID_STR = "ce4ef184-7660-445e-9e59-6731bdc65505";
  
  public nsILocalFile(int paramInt)
  {
    super(paramInt);
  }
  
  static
  {
    IIDStore.RegisterIID(nsILocalFile.class, 0, new nsID("aa610f20-a889-11d3-8c81-000064657374"));
    IIDStore.RegisterIID(nsILocalFile.class, 6, new nsID("ce4ef184-7660-445e-9e59-6731bdc65505"));
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/internal/mozilla/nsILocalFile.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */