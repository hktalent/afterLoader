package org.eclipse.swt.internal.mozilla;

public class nsISerializable
  extends nsISupports
{
  static final int LAST_METHOD_ID = nsISupports.LAST_METHOD_ID + 2;
  static final String NS_ISERIALIZABLE_IID_STR = "91cca981-c26d-44a8-bebe-d9ed4891503a";
  
  public nsISerializable(int paramInt)
  {
    super(paramInt);
  }
  
  static
  {
    IIDStore.RegisterIID(nsISerializable.class, 0, new nsID("91cca981-c26d-44a8-bebe-d9ed4891503a"));
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/internal/mozilla/nsISerializable.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */