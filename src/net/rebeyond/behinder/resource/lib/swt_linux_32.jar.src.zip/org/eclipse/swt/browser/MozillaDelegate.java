package org.eclipse.swt.browser;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.internal.C;
import org.eclipse.swt.internal.Callback;
import org.eclipse.swt.internal.Converter;
import org.eclipse.swt.internal.Library;
import org.eclipse.swt.internal.gtk.GdkEvent;
import org.eclipse.swt.internal.gtk.OS;
import org.eclipse.swt.internal.mozilla.MozillaVersion;
import org.eclipse.swt.internal.mozilla.nsIBaseWindow;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Widget;

class MozillaDelegate
{
  Browser browser;
  Shell eventShell;
  int mozillaHandle;
  int embedHandle;
  boolean hasFocus;
  Listener listener;
  static Callback eventCallback;
  static int eventProc;
  static Boolean IsXULRunner24;
  static final int STOP_PROPOGATE = 1;
  static final String LIB_FIX_XULRUNNER10 = "libswt-xulrunner-fix10.so";
  static final String LIB_FIX_XULRUNNER24 = "libswt-xulrunner-fix24.so";
  static final String LIB_XPCOM = "libxpcom.so";
  static final String LIB_XUL = "libxul.so";
  static boolean IsSparc;
  
  MozillaDelegate(Browser paramBrowser)
  {
    Object localObject;
    if (IsSparc)
    {
      localObject = Converter.wcsToMbcs(null, "libCrun.so.1", true);
      OS.dlopen((byte[])localObject, OS.RTLD_NOW | OS.RTLD_GLOBAL);
    }
    if (OS.GTK3)
    {
      localObject = " [Browser style SWT.MOZILLA and Java system property org.eclipse.swt.browser.DefaultType=mozilla are not supported with GTK 3 as XULRunner is not ported for GTK 3 yet]";
      SWT.error(2, null, (String)localObject);
    }
    this.browser = paramBrowser;
  }
  
  static int eventProc(int paramInt1, int paramInt2, int paramInt3)
  {
    int i = OS.gtk_widget_get_parent(paramInt1);
    i = OS.gtk_widget_get_parent(i);
    if (i == 0) {
      return 0;
    }
    Widget localWidget = Display.getCurrent().findWidget(i);
    if ((localWidget != null) && ((localWidget instanceof Browser))) {
      return ((Mozilla)((Browser)localWidget).webBrowser).delegate.gtk_event(paramInt1, paramInt2, paramInt3);
    }
    return 0;
  }
  
  static Browser findBrowser(int paramInt)
  {
    int i = OS.gtk_widget_get_parent(paramInt);
    Display localDisplay = Display.getCurrent();
    return (Browser)localDisplay.findWidget(i);
  }
  
  static String getCacheParentPath()
  {
    return getProfilePath();
  }
  
  static String[] getJSLibraryNames()
  {
    return new String[] { "libxul.so" };
  }
  
  static String getJSLibraryName_Pre10()
  {
    return "libmozjs.so";
  }
  
  static String getLibraryName(String paramString)
  {
    if (IsXULRunner24 == null) {
      IsXULRunner24 = new File(paramString, "libxpcom.so").exists() ? Boolean.FALSE : Boolean.TRUE;
    }
    return IsXULRunner24.booleanValue() ? "libxul.so" : "libxpcom.so";
  }
  
  static String getProfilePath()
  {
    String str = System.getProperty("user.home");
    if (str.equals("?"))
    {
      int i = C.getenv(wcsToMbcs(null, "HOME", true));
      if (i != 0)
      {
        int j = C.strlen(i);
        byte[] arrayOfByte = new byte[j];
        C.memmove(arrayOfByte, i, j);
        str = new String(mbcsToWcs(null, arrayOfByte));
      }
    }
    return str + Mozilla.SEPARATOR_OS + ".mozilla" + Mozilla.SEPARATOR_OS + "eclipse";
  }
  
  static String getSWTInitLibraryName()
  {
    return "swt-xpcominit";
  }
  
  static void loadAdditionalLibraries(String paramString, boolean paramBoolean)
  {
    String str = null;
    if (!paramBoolean)
    {
      if (IsXULRunner24 == null) {
        IsXULRunner24 = new File(paramString, "libxpcom.so").exists() ? Boolean.FALSE : Boolean.TRUE;
      }
      if (IsXULRunner24.booleanValue()) {
        str = "libswt-xulrunner-fix24.so";
      }
    }
    else if (MozillaVersion.CheckVersion(5, true))
    {
      str = "libswt-xulrunner-fix10.so";
    }
    if (str == null) {
      return;
    }
    File localFile1 = new File(getProfilePath() + "/libs/" + Mozilla.OS() + '/' + Mozilla.Arch());
    File localFile2 = new File(localFile1, str);
    Object localObject;
    if (!localFile2.exists())
    {
      localObject = Library.class.getResourceAsStream('/' + str);
      if (localObject != null)
      {
        if (!localFile1.exists()) {
          localFile1.mkdirs();
        }
        byte[] arrayOfByte = new byte['က'];
        try
        {
          FileOutputStream localFileOutputStream = new FileOutputStream(localFile2);
          int i;
          while ((i = ((InputStream)localObject).read(arrayOfByte)) != -1) {
            localFileOutputStream.write(arrayOfByte, 0, i);
          }
          localFileOutputStream.close();
          ((InputStream)localObject).close();
        }
        catch (FileNotFoundException localFileNotFoundException) {}catch (IOException localIOException) {}
      }
    }
    if (localFile2.exists())
    {
      localObject = Converter.wcsToMbcs(null, localFile2.getAbsolutePath(), true);
      OS.dlopen((byte[])localObject, OS.RTLD_NOW | OS.RTLD_GLOBAL);
    }
  }
  
  static char[] mbcsToWcs(String paramString, byte[] paramArrayOfByte)
  {
    return Converter.mbcsToWcs(paramString, paramArrayOfByte);
  }
  
  static boolean needsSpinup()
  {
    return true;
  }
  
  static byte[] wcsToMbcs(String paramString1, String paramString2, boolean paramBoolean)
  {
    return Converter.wcsToMbcs(paramString1, paramString2, paramBoolean);
  }
  
  void addWindowSubclass() {}
  
  int createBaseWindow(nsIBaseWindow paramnsIBaseWindow)
  {
    return paramnsIBaseWindow.Create();
  }
  
  int getHandle()
  {
    if (OS.GTK3)
    {
      this.embedHandle = OS.gtk_box_new(0, 0);
      OS.gtk_box_set_homogeneous(this.embedHandle, false);
    }
    else
    {
      this.embedHandle = OS.gtk_hbox_new(false, 0);
    }
    OS.gtk_container_add(this.browser.handle, this.embedHandle);
    OS.gtk_widget_show(this.embedHandle);
    return this.embedHandle;
  }
  
  Point getNativeSize(int paramInt1, int paramInt2)
  {
    return new Point(paramInt1, paramInt2);
  }
  
  int getSiteWindow()
  {
    return this.embedHandle;
  }
  
  int gtk_event(int paramInt1, int paramInt2, int paramInt3)
  {
    GdkEvent localGdkEvent = new GdkEvent();
    OS.memmove(localGdkEvent, paramInt2, GdkEvent.sizeof);
    if ((localGdkEvent.type == 4) && (!this.hasFocus)) {
      this.browser.setFocus();
    }
    if (paramInt3 == 1) {
      return 1;
    }
    return 0;
  }
  
  void handleFocus()
  {
    if (this.hasFocus) {
      return;
    }
    this.hasFocus = true;
    this.listener = new Listener()
    {
      public void handleEvent(Event paramAnonymousEvent)
      {
        if (paramAnonymousEvent.widget == MozillaDelegate.this.browser) {
          return;
        }
        if (paramAnonymousEvent.type != 12)
        {
          ((Mozilla)MozillaDelegate.this.browser.webBrowser).Deactivate();
          MozillaDelegate.this.hasFocus = false;
        }
        MozillaDelegate.this.eventShell.getDisplay().removeFilter(15, this);
        MozillaDelegate.this.eventShell.removeListener(27, this);
        MozillaDelegate.this.eventShell.removeListener(12, this);
        MozillaDelegate.this.eventShell = null;
        MozillaDelegate.this.listener = null;
      }
    };
    this.eventShell = this.browser.getShell();
    this.eventShell.getDisplay().addFilter(15, this.listener);
    this.eventShell.addListener(27, this.listener);
    this.eventShell.addListener(12, this.listener);
  }
  
  void handleMouseDown()
  {
    int i = this.browser.getShell().getStyle();
    if (((i & 0x4000) != 0) && (((i & 0x80000) == 0) || ((this.browser.getStyle() & 0x80000) == 0))) {
      this.browser.getDisplay().asyncExec(new Runnable()
      {
        public void run()
        {
          if ((MozillaDelegate.this.browser == null) || (MozillaDelegate.this.browser.isDisposed())) {
            return;
          }
          ((Mozilla)MozillaDelegate.this.browser.webBrowser).Activate();
        }
      });
    }
  }
  
  boolean hookEnterExit()
  {
    return false;
  }
  
  void init()
  {
    if (eventCallback == null)
    {
      eventCallback = new Callback(getClass(), "eventProc", 3);
      eventProc = eventCallback.getAddress();
      if (eventProc == 0)
      {
        this.browser.dispose();
        Mozilla.error(3);
      }
    }
    int i = OS.gtk_container_get_children(this.embedHandle);
    if (i != 0)
    {
      this.mozillaHandle = OS.g_list_data(i);
      OS.g_list_free(i);
      if (this.mozillaHandle != 0)
      {
        OS.g_signal_connect(this.mozillaHandle, OS.event, eventProc, 0);
        OS.g_signal_connect(this.mozillaHandle, OS.key_press_event, eventProc, 1);
        OS.g_signal_connect(this.mozillaHandle, OS.key_release_event, eventProc, 1);
        OS.g_signal_connect(this.mozillaHandle, OS.button_press_event, eventProc, 1);
      }
    }
  }
  
  void onDispose(int paramInt)
  {
    if (this.listener != null)
    {
      this.eventShell.getDisplay().removeFilter(15, this.listener);
      this.eventShell.removeListener(27, this.listener);
      this.eventShell.removeListener(12, this.listener);
      this.eventShell = null;
      this.listener = null;
    }
    this.browser = null;
  }
  
  void removeWindowSubclass() {}
  
  boolean sendTraverse()
  {
    return true;
  }
  
  void setSize(int paramInt1, int paramInt2, int paramInt3)
  {
    OS.gtk_widget_set_size_request(paramInt1, paramInt2, paramInt3);
  }
  
  static
  {
    String str1 = System.getProperty("os.name").toLowerCase();
    String str2 = System.getProperty("os.arch").toLowerCase();
    IsSparc = ((str1.startsWith("sunos")) || (str1.startsWith("solaris"))) && (str2.startsWith("sparc"));
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/browser/MozillaDelegate.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */