package org.eclipse.swt.internal.mozilla;

public class nsIHttpChannel
  extends nsIChannel
{
  static final int LAST_METHOD_ID = nsIChannel.LAST_METHOD_ID + (IsXULRunner24() ? 20 : 19);
  static final String NS_IHTTPCHANNEL_IID_STR = "9277fe09-f0cc-4cd9-bbce-581dd94b0260";
  static final String NS_IHTTPCHANNEL_24_IID_STR = "a01362a0-5c45-11e2-bcfd-0800200c9a66";
  
  public nsIHttpChannel(int paramInt)
  {
    super(paramInt);
  }
  
  public int VisitRequestHeaders(int paramInt)
  {
    return XPCOM.VtblCall(nsIChannel.LAST_METHOD_ID + 7, getAddress(), paramInt);
  }
  
  static
  {
    IIDStore.RegisterIID(nsIHttpChannel.class, 0, new nsID("9277fe09-f0cc-4cd9-bbce-581dd94b0260"));
    IIDStore.RegisterIID(nsIHttpChannel.class, 6, new nsID("a01362a0-5c45-11e2-bcfd-0800200c9a66"));
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/internal/mozilla/nsIHttpChannel.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */