package org.eclipse.swt.internal.accessibility.gtk;

public class AtkTextRange
{
  public AtkTextRectangle bounds = new AtkTextRectangle();
  public int start_offset;
  public int end_offset;
  public int content;
  public static final int sizeof = ;
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/internal/accessibility/gtk/AtkTextRange.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */