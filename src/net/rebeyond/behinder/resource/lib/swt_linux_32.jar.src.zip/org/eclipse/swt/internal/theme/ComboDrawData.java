package org.eclipse.swt.internal.theme;

import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.GCData;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.internal.Converter;
import org.eclipse.swt.internal.cairo.Cairo;
import org.eclipse.swt.internal.gtk.GdkRectangle;
import org.eclipse.swt.internal.gtk.OS;

public class ComboDrawData
  extends DrawData
{
  static final int ARROW_HEIGHT = 6;
  static final int MIN_ARROW_SIZE = 15;
  
  public ComboDrawData()
  {
    this.state = new int[2];
  }
  
  void draw(Theme paramTheme, GC paramGC, Rectangle paramRectangle)
  {
    int i = paramTheme.buttonHandle;
    int j = OS.gtk_widget_get_style(i);
    int k = paramGC.getGCData().drawable;
    paramTheme.transferClipping(paramGC, j);
    int m = paramRectangle.x;
    int n = paramRectangle.y;
    int i1 = paramRectangle.width;
    int i2 = paramRectangle.height;
    int i3 = 2;
    if ((this.state[1] & 0x8) != 0) {
      i3 = 1;
    }
    int i4 = getStateType(1);
    int i5 = OS.gtk_button_get_relief(i);
    int i6 = paramTheme.getWidgetProperty(i, "interior-focus");
    int i7 = paramTheme.getWidgetProperty(i, "focus-line-width");
    int i8 = paramTheme.getWidgetProperty(i, "focus-padding");
    int i9 = OS.gtk_style_get_xthickness(j);
    int i10 = OS.gtk_style_get_xthickness(j);
    int i11 = 15;
    int i12 = 6;
    int i13 = i9 + i8;
    if (i6 == 0) {
      i13 += i7;
    }
    int i14 = i11 + i13 * 2;
    int i15 = m + i1 - i14;
    int i16 = i15 + (i14 - i11) / 2;
    int i17 = n + (i2 - i12) / 2 + 1;
    if ((i5 != 2) || ((this.state[1] & 0x48) != 0))
    {
      arrayOfByte1 = Converter.wcsToMbcs(null, "button", true);
      gtk_render_box(j, k, i4, i3, null, i, arrayOfByte1, i15, n, i14, i2);
    }
    byte[] arrayOfByte1 = Converter.wcsToMbcs(null, "arrow", true);
    int i18 = paramTheme.arrowHandle;
    gtk_render_arrow(j, k, i4, 2, null, i18, arrayOfByte1, 1, true, i16, i17, i11, i12);
    int i19 = paramTheme.entryHandle;
    j = OS.gtk_widget_get_style(i19);
    paramTheme.transferClipping(paramGC, j);
    i4 = getStateType(0);
    byte[] arrayOfByte2 = Converter.wcsToMbcs(null, "entry", true);
    gtk_render_shadow(j, k, 0, 1, null, i19, arrayOfByte2, m, n, i1 - i14, i2);
    i9 = OS.gtk_style_get_xthickness(j);
    i10 = OS.gtk_style_get_xthickness(j);
    m += i9;
    n += i10;
    i1 -= 2 * i9;
    i2 -= 2 * i10;
    arrayOfByte2 = Converter.wcsToMbcs(null, "entry_bg", true);
    gtk_render_frame(j, k, i4, 0, null, i19, arrayOfByte2, m, n, i1 - i14, i2);
    if (this.clientArea != null)
    {
      this.clientArea.x = m;
      this.clientArea.y = n;
      this.clientArea.width = (i1 - i14);
      this.clientArea.height = i2;
    }
  }
  
  int getStateType(int paramInt)
  {
    if (paramInt == 0)
    {
      int i = 0;
      if ((this.state[0] & 0x20) != 0) {
        i = 4;
      }
      return i;
    }
    return super.getStateType(paramInt);
  }
  
  int hit(Theme paramTheme, Point paramPoint, Rectangle paramRectangle)
  {
    if (!paramRectangle.contains(paramPoint)) {
      return -1;
    }
    int i = paramTheme.buttonHandle;
    int j = OS.gtk_widget_get_style(i);
    int k = paramTheme.getWidgetProperty(i, "interior-focus");
    int m = paramTheme.getWidgetProperty(i, "focus-line-width");
    int n = paramTheme.getWidgetProperty(i, "focus-padding");
    int i1 = OS.gtk_style_get_xthickness(j);
    int i2 = 15;
    int i3 = i1 + n;
    if (k == 0) {
      i3 += m;
    }
    int i4 = i2 + i3 * 2;
    int i5 = paramRectangle.x + paramRectangle.width - i4;
    Rectangle localRectangle = new Rectangle(i5, paramRectangle.y, i4, paramRectangle.height);
    if (localRectangle.contains(paramPoint)) {
      return 1;
    }
    return 0;
  }
  
  void gtk_render_shadow(int paramInt1, int paramInt2, int paramInt3, int paramInt4, GdkRectangle paramGdkRectangle, int paramInt5, byte[] paramArrayOfByte, int paramInt6, int paramInt7, int paramInt8, int paramInt9)
  {
    if (OS.GTK3)
    {
      int i = OS.gdk_cairo_create(paramInt2);
      int j = OS.gtk_widget_get_style_context(paramInt1);
      OS.gtk_style_context_save(j);
      OS.gtk_style_context_set_state(paramInt1, paramInt3);
      OS.gtk_render_frame(j, i, paramInt6, paramInt7, paramInt8, paramInt9);
      Cairo.cairo_destroy(i);
    }
    else
    {
      OS.gtk_paint_shadow(paramInt1, paramInt2, paramInt3, paramInt4, paramGdkRectangle, paramInt5, paramArrayOfByte, paramInt6, paramInt7, paramInt8, paramInt9);
    }
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/internal/theme/ComboDrawData.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */