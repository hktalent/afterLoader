package org.eclipse.swt.graphics;

import org.eclipse.swt.SWT;
import org.eclipse.swt.internal.Compatibility;
import org.eclipse.swt.internal.cairo.Cairo;
import org.eclipse.swt.internal.cairo.cairo_path_data_t;
import org.eclipse.swt.internal.cairo.cairo_path_t;

public class Path
  extends Resource
{
  public int handle;
  boolean moved;
  boolean closed = true;
  
  public Path(Device paramDevice)
  {
    super(paramDevice);
    this.device.checkCairo();
    int i = Cairo.cairo_image_surface_create(0, 1, 1);
    if (i == 0) {
      SWT.error(2);
    }
    this.handle = Cairo.cairo_create(i);
    Cairo.cairo_surface_destroy(i);
    if (this.handle == 0) {
      SWT.error(2);
    }
    init();
  }
  
  public Path(Device paramDevice, Path paramPath, float paramFloat)
  {
    super(paramDevice);
    if (paramPath == null) {
      SWT.error(4);
    }
    if (paramPath.isDisposed()) {
      SWT.error(5);
    }
    int i = Cairo.cairo_image_surface_create(0, 1, 1);
    if (i == 0) {
      SWT.error(2);
    }
    this.handle = Cairo.cairo_create(i);
    Cairo.cairo_surface_destroy(i);
    if (this.handle == 0) {
      SWT.error(2);
    }
    paramFloat = Math.max(0.0F, paramFloat);
    int j;
    if (paramFloat == 0.0F)
    {
      j = Cairo.cairo_copy_path(paramPath.handle);
    }
    else
    {
      double d = Cairo.cairo_get_tolerance(paramPath.handle);
      Cairo.cairo_set_tolerance(paramPath.handle, paramFloat);
      j = Cairo.cairo_copy_path_flat(paramPath.handle);
      Cairo.cairo_set_tolerance(paramPath.handle, d);
    }
    if (j == 0)
    {
      Cairo.cairo_destroy(this.handle);
      SWT.error(2);
    }
    Cairo.cairo_append_path(this.handle, j);
    Cairo.cairo_path_destroy(j);
    init();
  }
  
  public Path(Device paramDevice, PathData paramPathData)
  {
    this(paramDevice);
    if (paramPathData == null) {
      SWT.error(4);
    }
    init(paramPathData);
  }
  
  public void addArc(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6)
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    this.moved = true;
    float f;
    if (paramFloat3 == paramFloat4)
    {
      f = -paramFloat5 * (float)Compatibility.PI / 180.0F;
      if (this.closed) {
        Cairo.cairo_move_to(this.handle, paramFloat1 + paramFloat3 / 2.0F + paramFloat3 / 2.0F * Math.cos(f), paramFloat2 + paramFloat4 / 2.0F + paramFloat4 / 2.0F * Math.sin(f));
      }
      if (paramFloat6 >= 0.0F) {
        Cairo.cairo_arc_negative(this.handle, paramFloat1 + paramFloat3 / 2.0F, paramFloat2 + paramFloat4 / 2.0F, paramFloat3 / 2.0F, f, -(paramFloat5 + paramFloat6) * (float)Compatibility.PI / 180.0F);
      } else {
        Cairo.cairo_arc(this.handle, paramFloat1 + paramFloat3 / 2.0F, paramFloat2 + paramFloat4 / 2.0F, paramFloat3 / 2.0F, f, -(paramFloat5 + paramFloat6) * (float)Compatibility.PI / 180.0F);
      }
    }
    else
    {
      Cairo.cairo_save(this.handle);
      Cairo.cairo_translate(this.handle, paramFloat1 + paramFloat3 / 2.0F, paramFloat2 + paramFloat4 / 2.0F);
      Cairo.cairo_scale(this.handle, paramFloat3 / 2.0F, paramFloat4 / 2.0F);
      f = -paramFloat5 * (float)Compatibility.PI / 180.0F;
      if (this.closed) {
        Cairo.cairo_move_to(this.handle, Math.cos(f), Math.sin(f));
      }
      if (paramFloat6 >= 0.0F) {
        Cairo.cairo_arc_negative(this.handle, 0.0D, 0.0D, 1.0D, f, -(paramFloat5 + paramFloat6) * (float)Compatibility.PI / 180.0F);
      } else {
        Cairo.cairo_arc(this.handle, 0.0D, 0.0D, 1.0D, f, -(paramFloat5 + paramFloat6) * (float)Compatibility.PI / 180.0F);
      }
      Cairo.cairo_restore(this.handle);
    }
    this.closed = false;
    if (Math.abs(paramFloat6) >= 360.0F) {
      close();
    }
  }
  
  public void addPath(Path paramPath)
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    if (paramPath == null) {
      SWT.error(4);
    }
    if (paramPath.isDisposed()) {
      SWT.error(5);
    }
    this.moved = false;
    int i = Cairo.cairo_copy_path(paramPath.handle);
    if (i == 0) {
      SWT.error(2);
    }
    Cairo.cairo_append_path(this.handle, i);
    Cairo.cairo_path_destroy(i);
    this.closed = paramPath.closed;
  }
  
  public void addRectangle(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4)
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    this.moved = false;
    Cairo.cairo_rectangle(this.handle, paramFloat1, paramFloat2, paramFloat3, paramFloat4);
    this.closed = true;
  }
  
  public void addString(String paramString, float paramFloat1, float paramFloat2, Font paramFont)
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    if (paramFont == null) {
      SWT.error(4);
    }
    if (paramFont.isDisposed()) {
      SWT.error(5);
    }
    this.moved = false;
    GC.addCairoString(this.handle, paramString, paramFloat1, paramFloat2, paramFont);
    this.closed = true;
  }
  
  public void close()
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    Cairo.cairo_close_path(this.handle);
    this.moved = false;
    this.closed = true;
  }
  
  public boolean contains(float paramFloat1, float paramFloat2, GC paramGC, boolean paramBoolean)
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    if (paramGC == null) {
      SWT.error(4);
    }
    if (paramGC.isDisposed()) {
      SWT.error(5);
    }
    paramGC.initCairo();
    paramGC.checkGC(120);
    boolean bool = false;
    int i = paramGC.data.cairo;
    int j = Cairo.cairo_copy_path(this.handle);
    if (j == 0) {
      SWT.error(2);
    }
    Cairo.cairo_append_path(i, j);
    Cairo.cairo_path_destroy(j);
    if (paramBoolean) {
      bool = Cairo.cairo_in_stroke(i, paramFloat1, paramFloat2) != 0;
    } else {
      bool = Cairo.cairo_in_fill(i, paramFloat1, paramFloat2) != 0;
    }
    Cairo.cairo_new_path(i);
    return bool;
  }
  
  public void cubicTo(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6)
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    if (!this.moved)
    {
      double[] arrayOfDouble1 = new double[1];
      double[] arrayOfDouble2 = new double[1];
      Cairo.cairo_get_current_point(this.handle, arrayOfDouble1, arrayOfDouble2);
      Cairo.cairo_move_to(this.handle, arrayOfDouble1[0], arrayOfDouble2[0]);
      this.moved = true;
    }
    Cairo.cairo_curve_to(this.handle, paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6);
    this.closed = false;
  }
  
  public void getBounds(float[] paramArrayOfFloat)
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    if (paramArrayOfFloat == null) {
      SWT.error(4);
    }
    if (paramArrayOfFloat.length < 4) {
      SWT.error(5);
    }
    int i = Cairo.cairo_copy_path(this.handle);
    if (i == 0) {
      SWT.error(2);
    }
    cairo_path_t localcairo_path_t = new cairo_path_t();
    Cairo.memmove(localcairo_path_t, i, cairo_path_t.sizeof);
    double d1 = 0.0D;
    double d2 = 0.0D;
    double d3 = 0.0D;
    double d4 = 0.0D;
    if (localcairo_path_t.num_data > 0)
    {
      d1 = d2 = Double.POSITIVE_INFINITY;
      d3 = d4 = Double.NEGATIVE_INFINITY;
      int j = 0;
      double[] arrayOfDouble = new double[6];
      cairo_path_data_t localcairo_path_data_t = new cairo_path_data_t();
      while (j < localcairo_path_t.num_data)
      {
        int k = localcairo_path_t.data + j * cairo_path_data_t.sizeof;
        Cairo.memmove(localcairo_path_data_t, k, cairo_path_data_t.sizeof);
        switch (localcairo_path_data_t.type)
        {
        case 0: 
          Cairo.memmove(arrayOfDouble, k + cairo_path_data_t.sizeof, cairo_path_data_t.sizeof);
          d1 = Math.min(d1, arrayOfDouble[0]);
          d2 = Math.min(d2, arrayOfDouble[1]);
          d3 = Math.max(d3, arrayOfDouble[0]);
          d4 = Math.max(d4, arrayOfDouble[1]);
          break;
        case 1: 
          Cairo.memmove(arrayOfDouble, k + cairo_path_data_t.sizeof, cairo_path_data_t.sizeof);
          d1 = Math.min(d1, arrayOfDouble[0]);
          d2 = Math.min(d2, arrayOfDouble[1]);
          d3 = Math.max(d3, arrayOfDouble[0]);
          d4 = Math.max(d4, arrayOfDouble[1]);
          break;
        case 2: 
          Cairo.memmove(arrayOfDouble, k + cairo_path_data_t.sizeof, cairo_path_data_t.sizeof * 3);
          d1 = Math.min(d1, arrayOfDouble[0]);
          d2 = Math.min(d2, arrayOfDouble[1]);
          d3 = Math.max(d3, arrayOfDouble[0]);
          d4 = Math.max(d4, arrayOfDouble[1]);
          d1 = Math.min(d1, arrayOfDouble[2]);
          d2 = Math.min(d2, arrayOfDouble[3]);
          d3 = Math.max(d3, arrayOfDouble[2]);
          d4 = Math.max(d4, arrayOfDouble[3]);
          d1 = Math.min(d1, arrayOfDouble[4]);
          d2 = Math.min(d2, arrayOfDouble[5]);
          d3 = Math.max(d3, arrayOfDouble[4]);
          d4 = Math.max(d4, arrayOfDouble[5]);
          break;
        }
        j += localcairo_path_data_t.length;
      }
    }
    paramArrayOfFloat[0] = ((float)d1);
    paramArrayOfFloat[1] = ((float)d2);
    paramArrayOfFloat[2] = ((float)(d3 - d1));
    paramArrayOfFloat[3] = ((float)(d4 - d2));
    Cairo.cairo_path_destroy(i);
  }
  
  public void getCurrentPoint(float[] paramArrayOfFloat)
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    if (paramArrayOfFloat == null) {
      SWT.error(4);
    }
    if (paramArrayOfFloat.length < 2) {
      SWT.error(5);
    }
    double[] arrayOfDouble1 = new double[1];
    double[] arrayOfDouble2 = new double[1];
    Cairo.cairo_get_current_point(this.handle, arrayOfDouble1, arrayOfDouble2);
    paramArrayOfFloat[0] = ((float)arrayOfDouble1[0]);
    paramArrayOfFloat[1] = ((float)arrayOfDouble2[0]);
  }
  
  public PathData getPathData()
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    int i = Cairo.cairo_copy_path(this.handle);
    if (i == 0) {
      SWT.error(2);
    }
    cairo_path_t localcairo_path_t = new cairo_path_t();
    Cairo.memmove(localcairo_path_t, i, cairo_path_t.sizeof);
    Object localObject1 = new byte[localcairo_path_t.num_data];
    Object localObject2 = new float[localcairo_path_t.num_data * 6];
    int j = 0;
    int k = 0;
    if (localcairo_path_t.num_data > 0)
    {
      int m = 0;
      double[] arrayOfDouble = new double[6];
      cairo_path_data_t localcairo_path_data_t = new cairo_path_data_t();
      while (m < localcairo_path_t.num_data)
      {
        int n = localcairo_path_t.data + m * cairo_path_data_t.sizeof;
        Cairo.memmove(localcairo_path_data_t, n, cairo_path_data_t.sizeof);
        switch (localcairo_path_data_t.type)
        {
        case 0: 
          localObject1[(j++)] = 1;
          Cairo.memmove(arrayOfDouble, n + cairo_path_data_t.sizeof, cairo_path_data_t.sizeof);
          localObject2[(k++)] = ((float)arrayOfDouble[0]);
          localObject2[(k++)] = ((float)arrayOfDouble[1]);
          break;
        case 1: 
          localObject1[(j++)] = 2;
          Cairo.memmove(arrayOfDouble, n + cairo_path_data_t.sizeof, cairo_path_data_t.sizeof);
          localObject2[(k++)] = ((float)arrayOfDouble[0]);
          localObject2[(k++)] = ((float)arrayOfDouble[1]);
          break;
        case 2: 
          localObject1[(j++)] = 4;
          Cairo.memmove(arrayOfDouble, n + cairo_path_data_t.sizeof, cairo_path_data_t.sizeof * 3);
          localObject2[(k++)] = ((float)arrayOfDouble[0]);
          localObject2[(k++)] = ((float)arrayOfDouble[1]);
          localObject2[(k++)] = ((float)arrayOfDouble[2]);
          localObject2[(k++)] = ((float)arrayOfDouble[3]);
          localObject2[(k++)] = ((float)arrayOfDouble[4]);
          localObject2[(k++)] = ((float)arrayOfDouble[5]);
          break;
        case 3: 
          localObject1[(j++)] = 5;
        }
        m += localcairo_path_data_t.length;
      }
    }
    if (j != localObject1.length)
    {
      localObject3 = new byte[j];
      System.arraycopy(localObject1, 0, localObject3, 0, j);
      localObject1 = localObject3;
    }
    if (k != localObject2.length)
    {
      localObject3 = new float[k];
      System.arraycopy(localObject2, 0, localObject3, 0, k);
      localObject2 = localObject3;
    }
    Cairo.cairo_path_destroy(i);
    Object localObject3 = new PathData();
    ((PathData)localObject3).types = ((byte[])localObject1);
    ((PathData)localObject3).points = ((float[])localObject2);
    return (PathData)localObject3;
  }
  
  public void lineTo(float paramFloat1, float paramFloat2)
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    if (!this.moved)
    {
      double[] arrayOfDouble1 = new double[1];
      double[] arrayOfDouble2 = new double[1];
      Cairo.cairo_get_current_point(this.handle, arrayOfDouble1, arrayOfDouble2);
      Cairo.cairo_move_to(this.handle, arrayOfDouble1[0], arrayOfDouble2[0]);
      this.moved = true;
    }
    Cairo.cairo_line_to(this.handle, paramFloat1, paramFloat2);
    this.closed = false;
  }
  
  public void moveTo(float paramFloat1, float paramFloat2)
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    this.moved = true;
    Cairo.cairo_move_to(this.handle, paramFloat1, paramFloat2);
    this.closed = true;
  }
  
  public void quadTo(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4)
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    double[] arrayOfDouble1 = new double[1];
    double[] arrayOfDouble2 = new double[1];
    Cairo.cairo_get_current_point(this.handle, arrayOfDouble1, arrayOfDouble2);
    if (!this.moved)
    {
      Cairo.cairo_move_to(this.handle, arrayOfDouble1[0], arrayOfDouble2[0]);
      this.moved = true;
    }
    float f1 = (float)arrayOfDouble1[0];
    float f2 = (float)arrayOfDouble2[0];
    float f3 = f1 + 2.0F * (paramFloat1 - f1) / 3.0F;
    float f4 = f2 + 2.0F * (paramFloat2 - f2) / 3.0F;
    float f5 = f3 + (paramFloat3 - f1) / 3.0F;
    float f6 = f4 + (paramFloat4 - f2) / 3.0F;
    Cairo.cairo_curve_to(this.handle, f3, f4, f5, f6, paramFloat3, paramFloat4);
    this.closed = false;
  }
  
  void destroy()
  {
    Cairo.cairo_destroy(this.handle);
    this.handle = 0;
  }
  
  void init(PathData paramPathData)
  {
    byte[] arrayOfByte = paramPathData.types;
    float[] arrayOfFloat = paramPathData.points;
    int i = 0;
    int j = 0;
    while (i < arrayOfByte.length)
    {
      switch (arrayOfByte[i])
      {
      case 1: 
        moveTo(arrayOfFloat[(j++)], arrayOfFloat[(j++)]);
        break;
      case 2: 
        lineTo(arrayOfFloat[(j++)], arrayOfFloat[(j++)]);
        break;
      case 4: 
        cubicTo(arrayOfFloat[(j++)], arrayOfFloat[(j++)], arrayOfFloat[(j++)], arrayOfFloat[(j++)], arrayOfFloat[(j++)], arrayOfFloat[(j++)]);
        break;
      case 3: 
        quadTo(arrayOfFloat[(j++)], arrayOfFloat[(j++)], arrayOfFloat[(j++)], arrayOfFloat[(j++)]);
        break;
      case 5: 
        close();
        break;
      default: 
        dispose();
        SWT.error(5);
      }
      i++;
    }
  }
  
  public boolean isDisposed()
  {
    return this.handle == 0;
  }
  
  public String toString()
  {
    if (isDisposed()) {
      return "Path {*DISPOSED*}";
    }
    return "Path {" + this.handle + "}";
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/graphics/Path.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */