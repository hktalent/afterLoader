package org.eclipse.swt.graphics;

import org.eclipse.swt.SWT;
import org.eclipse.swt.SWTException;
import org.eclipse.swt.internal.Compatibility;
import org.eclipse.swt.internal.Converter;
import org.eclipse.swt.internal.cairo.Cairo;
import org.eclipse.swt.internal.gtk.GdkColor;
import org.eclipse.swt.internal.gtk.GdkGCValues;
import org.eclipse.swt.internal.gtk.GdkRectangle;
import org.eclipse.swt.internal.gtk.OS;
import org.eclipse.swt.internal.gtk.PangoAttribute;
import org.eclipse.swt.internal.gtk.XRenderPictureAttributes;

public final class GC
  extends Resource
{
  public int handle;
  Drawable drawable;
  GCData data;
  static final int FOREGROUND = 1;
  static final int BACKGROUND = 2;
  static final int FONT = 4;
  static final int LINE_STYLE = 8;
  static final int LINE_CAP = 16;
  static final int LINE_JOIN = 32;
  static final int LINE_WIDTH = 64;
  static final int LINE_MITERLIMIT = 128;
  static final int BACKGROUND_BG = 256;
  static final int DRAW_OFFSET = 512;
  static final int DRAW = 761;
  static final int FILL = 2;
  static final float[] LINE_DOT = { 1.0F, 1.0F };
  static final float[] LINE_DASH = { 3.0F, 1.0F };
  static final float[] LINE_DASHDOT = { 3.0F, 1.0F, 1.0F, 1.0F };
  static final float[] LINE_DASHDOTDOT = { 3.0F, 1.0F, 1.0F, 1.0F, 1.0F, 1.0F };
  static final float[] LINE_DOT_ZERO = { 3.0F, 3.0F };
  static final float[] LINE_DASH_ZERO = { 18.0F, 6.0F };
  static final float[] LINE_DASHDOT_ZERO = { 9.0F, 6.0F, 3.0F, 6.0F };
  static final float[] LINE_DASHDOTDOT_ZERO = { 9.0F, 3.0F, 3.0F, 3.0F, 3.0F, 3.0F };
  
  GC() {}
  
  public GC(Drawable paramDrawable)
  {
    this(paramDrawable, 0);
  }
  
  public GC(Drawable paramDrawable, int paramInt)
  {
    if (paramDrawable == null) {
      SWT.error(4);
    }
    GCData localGCData = new GCData();
    localGCData.style = checkStyle(paramInt);
    int i = paramDrawable.internal_new_GC(localGCData);
    Device localDevice = localGCData.device;
    if (localDevice == null) {
      localDevice = Device.getDevice();
    }
    if (localDevice == null) {
      SWT.error(4);
    }
    this.device = (localGCData.device = localDevice);
    init(paramDrawable, localGCData, i);
    init();
  }
  
  static void addCairoString(int paramInt, String paramString, float paramFloat1, float paramFloat2, Font paramFont)
  {
    byte[] arrayOfByte = Converter.wcsToMbcs(null, paramString, true);
    int i = OS.pango_cairo_create_layout(paramInt);
    if (i == 0) {
      SWT.error(2);
    }
    OS.pango_layout_set_text(i, arrayOfByte, -1);
    OS.pango_layout_set_font_description(i, paramFont.handle);
    double[] arrayOfDouble1 = new double[1];
    double[] arrayOfDouble2 = new double[1];
    Cairo.cairo_get_current_point(paramInt, arrayOfDouble1, arrayOfDouble2);
    if ((arrayOfDouble1[0] != paramFloat1) || (arrayOfDouble2[0] != paramFloat2)) {
      Cairo.cairo_move_to(paramInt, paramFloat1, paramFloat2);
    }
    OS.pango_cairo_layout_path(paramInt, i);
    OS.g_object_unref(i);
  }
  
  static int checkStyle(int paramInt)
  {
    if ((paramInt & 0x2000000) != 0) {
      paramInt &= 0xFBFFFFFF;
    }
    return paramInt & 0x6000000;
  }
  
  public static GC gtk_new(int paramInt, GCData paramGCData)
  {
    GC localGC = new GC();
    localGC.device = paramGCData.device;
    localGC.init(null, paramGCData, paramInt);
    return localGC;
  }
  
  public static GC gtk_new(Drawable paramDrawable, GCData paramGCData)
  {
    GC localGC = new GC();
    int i = paramDrawable.internal_new_GC(paramGCData);
    localGC.device = paramGCData.device;
    localGC.init(paramDrawable, paramGCData, i);
    return localGC;
  }
  
  void checkGC(int paramInt)
  {
    int i = this.data.state;
    if ((i & paramInt) == paramInt) {
      return;
    }
    i = (i ^ paramInt) & paramInt;
    this.data.state |= paramInt;
    int j = this.data.cairo;
    Object localObject2;
    if (j != 0)
    {
      Object localObject1;
      Object localObject3;
      double[] arrayOfDouble2;
      if ((i & 0x3) != 0)
      {
        if ((i & 0x1) != 0)
        {
          localObject1 = this.data.foreground;
          localObject3 = this.data.foregroundPattern;
          this.data.state &= 0xFFFFFFFD;
        }
        else
        {
          localObject1 = this.data.background;
          localObject3 = this.data.backgroundPattern;
          this.data.state &= 0xFFFFFFFE;
        }
        if (localObject3 != null)
        {
          if (((this.data.style & 0x8000000) != 0) && (((Pattern)localObject3).surface != 0))
          {
            int i1 = Cairo.cairo_pattern_create_for_surface(((Pattern)localObject3).surface);
            if (i1 == 0) {
              SWT.error(2);
            }
            Cairo.cairo_pattern_set_extend(i1, 1);
            arrayOfDouble2 = new double[] { -1.0D, 0.0D, 0.0D, 1.0D, 0.0D, 0.0D };
            Cairo.cairo_pattern_set_matrix(i1, arrayOfDouble2);
            Cairo.cairo_set_source(j, i1);
            Cairo.cairo_pattern_destroy(i1);
          }
          else
          {
            Cairo.cairo_set_source(j, ((Pattern)localObject3).handle);
          }
        }
        else {
          Cairo.cairo_set_source_rgba(j, (((GdkColor)localObject1).red & 0xFFFF) / 65535.0F, (((GdkColor)localObject1).green & 0xFFFF) / 65535.0F, (((GdkColor)localObject1).blue & 0xFFFF) / 65535.0F, this.data.alpha / 255.0F);
        }
      }
      if (((i & 0x4) != 0) && (this.data.layout != 0))
      {
        localObject1 = this.data.font;
        OS.pango_layout_set_font_description(this.data.layout, ((Font)localObject1).handle);
      }
      int k;
      if ((i & 0x10) != 0)
      {
        k = 0;
        switch (this.data.lineCap)
        {
        case 2: 
          k = 1;
          break;
        case 1: 
          k = 0;
          break;
        case 3: 
          k = 2;
        }
        Cairo.cairo_set_line_cap(j, k);
      }
      if ((i & 0x20) != 0)
      {
        k = 0;
        switch (this.data.lineJoin)
        {
        case 1: 
          k = 0;
          break;
        case 2: 
          k = 1;
          break;
        case 3: 
          k = 2;
        }
        Cairo.cairo_set_line_join(j, k);
      }
      if ((i & 0x40) != 0)
      {
        Cairo.cairo_set_line_width(j, this.data.lineWidth == 0.0F ? 1.0D : this.data.lineWidth);
        switch (this.data.lineStyle)
        {
        case 2: 
        case 3: 
        case 4: 
        case 5: 
          i |= 0x8;
        }
      }
      if ((i & 0x8) != 0)
      {
        float f1 = 0.0F;
        localObject3 = null;
        float f2 = this.data.lineWidth;
        switch (this.data.lineStyle)
        {
        case 1: 
          break;
        case 2: 
          localObject3 = f2 != 0.0F ? LINE_DASH : LINE_DASH_ZERO;
          break;
        case 3: 
          localObject3 = f2 != 0.0F ? LINE_DOT : LINE_DOT_ZERO;
          break;
        case 4: 
          localObject3 = f2 != 0.0F ? LINE_DASHDOT : LINE_DASHDOT_ZERO;
          break;
        case 5: 
          localObject3 = f2 != 0.0F ? LINE_DASHDOTDOT : LINE_DASHDOTDOT_ZERO;
          break;
        case 6: 
          localObject3 = this.data.lineDashes;
        }
        if (localObject3 != null)
        {
          f1 = this.data.lineDashesOffset;
          arrayOfDouble2 = new double[localObject3.length];
          for (int i4 = 0; i4 < arrayOfDouble2.length; i4++) {
            arrayOfDouble2[i4] = ((f2 == 0.0F) || (this.data.lineStyle == 6) ? localObject3[i4] : localObject3[i4] * f2);
          }
          Cairo.cairo_set_dash(j, arrayOfDouble2, arrayOfDouble2.length, f1);
        }
        else
        {
          Cairo.cairo_set_dash(j, null, 0, 0.0D);
        }
      }
      if ((i & 0x80) != 0) {
        Cairo.cairo_set_miter_limit(j, this.data.lineMiterLimit);
      }
      if ((i & 0x200) != 0)
      {
        this.data.cairoXoffset = (this.data.cairoYoffset = 0.0D);
        localObject2 = new double[6];
        Cairo.cairo_get_matrix(j, (double[])localObject2);
        localObject3 = new double[] { 1.0D };
        double[] arrayOfDouble1 = { 1.0D };
        Cairo.cairo_user_to_device_distance(j, (double[])localObject3, arrayOfDouble1);
        double d1 = localObject3[0];
        if (d1 < 0.0D) {
          d1 = -d1;
        }
        double d2 = this.data.lineWidth * d1;
        if ((d2 == 0.0D) || ((int)d2 % 2 == 1)) {
          this.data.cairoXoffset = (0.5D / d1);
        }
        d1 = arrayOfDouble1[0];
        if (d1 < 0.0D) {
          d1 = -d1;
        }
        d2 = this.data.lineWidth * d1;
        if ((d2 == 0.0D) || ((int)d2 % 2 == 1)) {
          this.data.cairoYoffset = (0.5D / d1);
        }
      }
      return;
    }
    if ((i & 0x3) != 0)
    {
      if ((i & 0x1) != 0)
      {
        localObject2 = this.data.foreground;
        this.data.state &= 0xFFFFFFFD;
      }
      else
      {
        localObject2 = this.data.background;
        this.data.state &= 0xFFFFFFFE;
      }
      OS.gdk_gc_set_foreground(this.handle, (GdkColor)localObject2);
    }
    if ((i & 0x100) != 0)
    {
      localObject2 = this.data.background;
      OS.gdk_gc_set_background(this.handle, (GdkColor)localObject2);
    }
    if (((i & 0x4) != 0) && (this.data.layout != 0))
    {
      localObject2 = this.data.font;
      OS.pango_layout_set_font_description(this.data.layout, ((Font)localObject2).handle);
    }
    if ((i & 0x78) != 0)
    {
      int m = 0;
      int n = 0;
      int i2 = (int)this.data.lineWidth;
      int i3 = 0;
      float[] arrayOfFloat = null;
      switch (this.data.lineCap)
      {
      case 2: 
        m = 2;
        break;
      case 1: 
        m = 1;
        break;
      case 3: 
        m = 3;
      }
      switch (this.data.lineJoin)
      {
      case 2: 
        n = 1;
        break;
      case 1: 
        n = 0;
        break;
      case 3: 
        n = 2;
      }
      switch (this.data.lineStyle)
      {
      case 1: 
        break;
      case 2: 
        arrayOfFloat = i2 != 0 ? LINE_DASH : LINE_DASH_ZERO;
        break;
      case 3: 
        arrayOfFloat = i2 != 0 ? LINE_DOT : LINE_DOT_ZERO;
        break;
      case 4: 
        arrayOfFloat = i2 != 0 ? LINE_DASHDOT : LINE_DASHDOT_ZERO;
        break;
      case 5: 
        arrayOfFloat = i2 != 0 ? LINE_DASHDOTDOT : LINE_DASHDOTDOT_ZERO;
        break;
      case 6: 
        arrayOfFloat = this.data.lineDashes;
      }
      if (arrayOfFloat != null)
      {
        if ((i & 0x8) != 0)
        {
          byte[] arrayOfByte = new byte[arrayOfFloat.length];
          for (int i5 = 0; i5 < arrayOfByte.length; i5++) {
            arrayOfByte[i5] = ((byte)(int)((i2 == 0) || (this.data.lineStyle == 6) ? arrayOfFloat[i5] : arrayOfFloat[i5] * i2));
          }
          OS.gdk_gc_set_dashes(this.handle, 0, arrayOfByte, arrayOfByte.length);
        }
        i3 = 1;
      }
      else
      {
        i3 = 0;
      }
      OS.gdk_gc_set_line_attributes(this.handle, i2, i3, m, n);
    }
  }
  
  int convertRgn(int paramInt, double[] paramArrayOfDouble)
  {
    int i = OS.gdk_region_new();
    if (isIdentity(paramArrayOfDouble))
    {
      OS.gdk_region_union(i, paramInt);
      return i;
    }
    int[] arrayOfInt1 = new int[1];
    int[] arrayOfInt2 = new int[1];
    Region.gdk_region_get_rectangles(paramInt, arrayOfInt2, arrayOfInt1);
    GdkRectangle localGdkRectangle = new GdkRectangle();
    int[] arrayOfInt3 = new int[8];
    double[] arrayOfDouble1 = new double[1];
    double[] arrayOfDouble2 = new double[1];
    for (int j = 0; j < arrayOfInt1[0]; j++)
    {
      OS.memmove(localGdkRectangle, arrayOfInt2[0] + j * GdkRectangle.sizeof, GdkRectangle.sizeof);
      arrayOfDouble1[0] = localGdkRectangle.x;
      arrayOfDouble2[0] = localGdkRectangle.y;
      Cairo.cairo_matrix_transform_point(paramArrayOfDouble, arrayOfDouble1, arrayOfDouble2);
      arrayOfInt3[0] = ((int)arrayOfDouble1[0]);
      arrayOfInt3[1] = ((int)arrayOfDouble2[0]);
      arrayOfDouble1[0] = (localGdkRectangle.x + localGdkRectangle.width);
      arrayOfDouble2[0] = localGdkRectangle.y;
      Cairo.cairo_matrix_transform_point(paramArrayOfDouble, arrayOfDouble1, arrayOfDouble2);
      arrayOfInt3[2] = ((int)Math.round(arrayOfDouble1[0]));
      arrayOfInt3[3] = ((int)arrayOfDouble2[0]);
      arrayOfDouble1[0] = (localGdkRectangle.x + localGdkRectangle.width);
      arrayOfDouble2[0] = (localGdkRectangle.y + localGdkRectangle.height);
      Cairo.cairo_matrix_transform_point(paramArrayOfDouble, arrayOfDouble1, arrayOfDouble2);
      arrayOfInt3[4] = ((int)Math.round(arrayOfDouble1[0]));
      arrayOfInt3[5] = ((int)Math.round(arrayOfDouble2[0]));
      arrayOfDouble1[0] = localGdkRectangle.x;
      arrayOfDouble2[0] = (localGdkRectangle.y + localGdkRectangle.height);
      Cairo.cairo_matrix_transform_point(paramArrayOfDouble, arrayOfDouble1, arrayOfDouble2);
      arrayOfInt3[6] = ((int)arrayOfDouble1[0]);
      arrayOfInt3[7] = ((int)Math.round(arrayOfDouble2[0]));
      int k = Region.gdk_region_polygon(arrayOfInt3, arrayOfInt3.length / 2, 0);
      OS.gdk_region_union(i, k);
      OS.gdk_region_destroy(k);
    }
    if (arrayOfInt2[0] != 0) {
      OS.g_free(arrayOfInt2[0]);
    }
    return i;
  }
  
  public void copyArea(Image paramImage, int paramInt1, int paramInt2)
  {
    if (this.handle == 0) {
      SWT.error(44);
    }
    if (paramImage == null) {
      SWT.error(4);
    }
    if ((paramImage.type != 0) || (paramImage.isDisposed())) {
      SWT.error(5);
    }
    if (OS.USE_CAIRO)
    {
      int i = Cairo.cairo_create(paramImage.surface);
      if (i == 0) {
        SWT.error(2);
      }
      Cairo.cairo_translate(i, -paramInt1, -paramInt2);
      Cairo.cairo_push_group(i);
      if (this.data.image != null)
      {
        Cairo.cairo_set_source_surface(i, this.data.image.surface, 0.0D, 0.0D);
      }
      else if (this.data.drawable != 0)
      {
        if (OS.GTK_VERSION >= OS.VERSION(2, 24, 0))
        {
          OS.gdk_cairo_set_source_window(i, this.data.drawable, 0, 0);
        }
        else
        {
          int[] arrayOfInt1 = new int[1];
          int[] arrayOfInt2 = new int[1];
          OS.gdk_drawable_get_size(this.data.drawable, arrayOfInt1, arrayOfInt2);
          int k = arrayOfInt1[0];
          int m = arrayOfInt2[0];
          int n = OS.gdk_x11_display_get_xdisplay(OS.gdk_display_get_default());
          int i1 = OS.gdk_x11_drawable_get_xid(this.data.drawable);
          int i2 = OS.gdk_x11_visual_get_xvisual(OS.gdk_visual_get_system());
          int i3 = Cairo.cairo_xlib_surface_create(n, i1, i2, k, m);
          Cairo.cairo_set_source_surface(i, i3, 0.0D, 0.0D);
        }
      }
      else
      {
        Cairo.cairo_destroy(i);
        return;
      }
      Cairo.cairo_set_operator(i, 1);
      Cairo.cairo_paint(i);
      Cairo.cairo_pop_group_to_source(i);
      Cairo.cairo_paint(i);
      Cairo.cairo_destroy(i);
      return;
    }
    Rectangle localRectangle = paramImage.getBounds();
    int j = OS.gdk_gc_new(paramImage.pixmap);
    if (j == 0) {
      SWT.error(2);
    }
    OS.gdk_gc_set_subwindow(j, 1);
    OS.gdk_draw_drawable(paramImage.pixmap, j, this.data.drawable, paramInt1, paramInt2, 0, 0, localRectangle.width, localRectangle.height);
    OS.g_object_unref(j);
  }
  
  public void copyArea(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6)
  {
    copyArea(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, true);
  }
  
  public void copyArea(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, boolean paramBoolean)
  {
    if (this.handle == 0) {
      SWT.error(44);
    }
    if ((paramInt3 <= 0) || (paramInt4 <= 0)) {
      return;
    }
    int i = paramInt5 - paramInt1;
    int j = paramInt6 - paramInt2;
    if ((i == 0) && (j == 0)) {
      return;
    }
    int k = this.data.drawable;
    int m;
    GdkRectangle localGdkRectangle;
    int n;
    if (OS.USE_CAIRO)
    {
      if (this.data.image != null)
      {
        Cairo.cairo_set_source_surface(this.handle, this.data.image.surface, i, j);
        Cairo.cairo_rectangle(this.handle, paramInt5, paramInt6, paramInt3, paramInt4);
        Cairo.cairo_set_operator(this.handle, 1);
        Cairo.cairo_fill(this.handle);
      }
      else if (k != 0)
      {
        Cairo.cairo_save(this.handle);
        Cairo.cairo_rectangle(this.handle, paramInt5, paramInt6, paramInt3, paramInt4);
        Cairo.cairo_clip(this.handle);
        Cairo.cairo_translate(this.handle, i, j);
        Cairo.cairo_set_operator(this.handle, 1);
        Cairo.cairo_push_group(this.handle);
        OS.gdk_cairo_set_source_window(this.handle, k, 0, 0);
        Cairo.cairo_paint(this.handle);
        Cairo.cairo_pop_group_to_source(this.handle);
        Cairo.cairo_rectangle(this.handle, paramInt5 - i, paramInt6 - j, paramInt3, paramInt4);
        Cairo.cairo_clip(this.handle);
        Cairo.cairo_paint(this.handle);
        Cairo.cairo_restore(this.handle);
        if (paramBoolean)
        {
          if (OS.GTK3) {
            m = OS.gdk_window_get_visible_region(k);
          } else {
            m = OS.gdk_drawable_get_visible_region(k);
          }
          localGdkRectangle = new GdkRectangle();
          localGdkRectangle.x = paramInt1;
          localGdkRectangle.y = paramInt2;
          localGdkRectangle.width = paramInt3;
          localGdkRectangle.height = paramInt4;
          n = OS.gdk_region_rectangle(localGdkRectangle);
          OS.gdk_region_intersect(n, m);
          int i1 = OS.gdk_region_rectangle(localGdkRectangle);
          OS.gdk_region_subtract(i1, m);
          OS.gdk_region_offset(i1, i, j);
          OS.gdk_window_invalidate_region(k, i1, false);
          OS.gdk_region_destroy(m);
          OS.gdk_region_destroy(n);
          OS.gdk_region_destroy(i1);
        }
      }
    }
    else
    {
      if ((this.data.image == null) && (paramBoolean)) {
        OS.gdk_gc_set_exposures(this.handle, true);
      }
      OS.gdk_draw_drawable(k, this.handle, k, paramInt1, paramInt2, paramInt5, paramInt6, paramInt3, paramInt4);
    }
    if ((this.data.image == null & paramBoolean))
    {
      if (!OS.USE_CAIRO) {
        OS.gdk_gc_set_exposures(this.handle, false);
      }
      m = (paramInt5 + paramInt3 < paramInt1) || (paramInt1 + paramInt3 < paramInt5) || (paramInt6 + paramInt4 < paramInt2) || (paramInt2 + paramInt4 < paramInt6) ? 1 : 0;
      localGdkRectangle = new GdkRectangle();
      if (m != 0)
      {
        localGdkRectangle.x = paramInt1;
        localGdkRectangle.y = paramInt2;
        localGdkRectangle.width = paramInt3;
        localGdkRectangle.height = paramInt4;
        OS.gdk_window_invalidate_rect(k, localGdkRectangle, false);
      }
      else
      {
        if (i != 0)
        {
          n = paramInt5 - i;
          if (i < 0) {
            n = paramInt5 + paramInt3;
          }
          localGdkRectangle.x = n;
          localGdkRectangle.y = paramInt2;
          localGdkRectangle.width = Math.abs(i);
          localGdkRectangle.height = paramInt4;
          OS.gdk_window_invalidate_rect(k, localGdkRectangle, false);
        }
        if (j != 0)
        {
          n = paramInt6 - j;
          if (j < 0) {
            n = paramInt6 + paramInt4;
          }
          localGdkRectangle.x = paramInt1;
          localGdkRectangle.y = n;
          localGdkRectangle.width = paramInt3;
          localGdkRectangle.height = Math.abs(j);
          OS.gdk_window_invalidate_rect(k, localGdkRectangle, false);
        }
      }
    }
  }
  
  void createLayout()
  {
    int i = OS.gdk_pango_context_get();
    if (i == 0) {
      SWT.error(2);
    }
    this.data.context = i;
    int j = OS.pango_layout_new(i);
    if (j == 0) {
      SWT.error(2);
    }
    this.data.layout = j;
    OS.pango_context_set_language(i, OS.gtk_get_default_language());
    OS.pango_context_set_base_dir(i, (this.data.style & 0x8000000) != 0 ? 1 : 0);
    OS.pango_layout_set_auto_dir(j, false);
  }
  
  void disposeLayout()
  {
    this.data.string = null;
    if (this.data.context != 0) {
      OS.g_object_unref(this.data.context);
    }
    if (this.data.layout != 0) {
      OS.g_object_unref(this.data.layout);
    }
    this.data.layout = (this.data.context = 0);
  }
  
  void destroy()
  {
    if (this.data.disposeCairo)
    {
      i = this.data.cairo;
      if (i != 0) {
        Cairo.cairo_destroy(i);
      }
    }
    this.data.cairo = 0;
    int i = this.data.clipRgn;
    if (i != 0) {
      OS.gdk_region_destroy(i);
    }
    Image localImage = this.data.image;
    if (localImage != null)
    {
      localImage.memGC = null;
      if (localImage.transparentPixel != -1) {
        localImage.createMask();
      }
    }
    disposeLayout();
    if (this.drawable != null) {
      this.drawable.internal_dispose_GC(this.handle, this.data);
    }
    this.data.drawable = (this.data.clipRgn = 0);
    this.drawable = null;
    this.handle = 0;
    this.data.image = null;
    this.data.string = null;
    this.data = null;
  }
  
  public void drawArc(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6)
  {
    if (this.handle == 0) {
      SWT.error(44);
    }
    checkGC(761);
    if (paramInt3 < 0)
    {
      paramInt1 += paramInt3;
      paramInt3 = -paramInt3;
    }
    if (paramInt4 < 0)
    {
      paramInt2 += paramInt4;
      paramInt4 = -paramInt4;
    }
    if ((paramInt3 == 0) || (paramInt4 == 0) || (paramInt6 == 0)) {
      return;
    }
    int i = this.data.cairo;
    if (i != 0)
    {
      double d1 = this.data.cairoXoffset;
      double d2 = this.data.cairoYoffset;
      if (paramInt3 == paramInt4)
      {
        if (paramInt6 >= 0) {
          Cairo.cairo_arc_negative(i, paramInt1 + d1 + paramInt3 / 2.0F, paramInt2 + d2 + paramInt4 / 2.0F, paramInt3 / 2.0F, -paramInt5 * (float)Compatibility.PI / 180.0F, -(paramInt5 + paramInt6) * (float)Compatibility.PI / 180.0F);
        } else {
          Cairo.cairo_arc(i, paramInt1 + d1 + paramInt3 / 2.0F, paramInt2 + d2 + paramInt4 / 2.0F, paramInt3 / 2.0F, -paramInt5 * (float)Compatibility.PI / 180.0F, -(paramInt5 + paramInt6) * (float)Compatibility.PI / 180.0F);
        }
      }
      else
      {
        Cairo.cairo_save(i);
        Cairo.cairo_translate(i, paramInt1 + d1 + paramInt3 / 2.0F, paramInt2 + d2 + paramInt4 / 2.0F);
        Cairo.cairo_scale(i, paramInt3 / 2.0F, paramInt4 / 2.0F);
        if (paramInt6 >= 0) {
          Cairo.cairo_arc_negative(i, 0.0D, 0.0D, 1.0D, -paramInt5 * (float)Compatibility.PI / 180.0F, -(paramInt5 + paramInt6) * (float)Compatibility.PI / 180.0F);
        } else {
          Cairo.cairo_arc(i, 0.0D, 0.0D, 1.0D, -paramInt5 * (float)Compatibility.PI / 180.0F, -(paramInt5 + paramInt6) * (float)Compatibility.PI / 180.0F);
        }
        Cairo.cairo_restore(i);
      }
      Cairo.cairo_stroke(i);
      return;
    }
    OS.gdk_draw_arc(this.data.drawable, this.handle, 0, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5 * 64, paramInt6 * 64);
  }
  
  public void drawFocus(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    if (this.handle == 0) {
      SWT.error(44);
    }
    int i = this.data.cairo;
    if (i != 0)
    {
      checkGC(1);
      if (OS.GTK3)
      {
        int j = OS.gtk_widget_get_style_context(this.data.device.shellHandle);
        OS.gtk_render_focus(j, i, paramInt1, paramInt2, paramInt3, paramInt4);
      }
      else
      {
        int[] arrayOfInt = new int[1];
        OS.gtk_widget_style_get(this.data.device.shellHandle, OS.focus_line_width, arrayOfInt, 0);
        Cairo.cairo_save(i);
        Cairo.cairo_set_line_width(i, arrayOfInt[0]);
        double[] arrayOfDouble = { 1.0D, 1.0D };
        for (double d = -arrayOfInt[0] / 2.0F; d < 0.0D; d += 2.0D) {}
        Cairo.cairo_set_dash(i, arrayOfDouble, arrayOfDouble.length, d);
        Cairo.cairo_rectangle(i, paramInt1 + arrayOfInt[0] / 2.0F, paramInt2 + arrayOfInt[0] / 2.0F, paramInt3, paramInt4);
        Cairo.cairo_stroke(i);
        Cairo.cairo_restore(i);
      }
      return;
    }
    int k = OS.gtk_widget_get_style(this.data.device.shellHandle);
    OS.gtk_paint_focus(k, this.data.drawable, 0, null, this.data.device.shellHandle, new byte[1], paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  public void drawImage(Image paramImage, int paramInt1, int paramInt2)
  {
    if (this.handle == 0) {
      SWT.error(44);
    }
    if (paramImage == null) {
      SWT.error(4);
    }
    if (paramImage.isDisposed()) {
      SWT.error(5);
    }
    drawImage(paramImage, 0, 0, -1, -1, paramInt1, paramInt2, -1, -1, true);
  }
  
  public void drawImage(Image paramImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8)
  {
    if (this.handle == 0) {
      SWT.error(44);
    }
    if ((paramInt3 == 0) || (paramInt4 == 0) || (paramInt7 == 0) || (paramInt8 == 0)) {
      return;
    }
    if ((paramInt1 < 0) || (paramInt2 < 0) || (paramInt3 < 0) || (paramInt4 < 0) || (paramInt7 < 0) || (paramInt8 < 0)) {
      SWT.error(5);
    }
    if (paramImage == null) {
      SWT.error(4);
    }
    if (paramImage.isDisposed()) {
      SWT.error(5);
    }
    drawImage(paramImage, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8, false);
  }
  
  void drawImage(Image paramImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, boolean paramBoolean)
  {
    int i;
    int j;
    if (OS.USE_CAIRO)
    {
      i = paramImage.width;
      j = paramImage.height;
    }
    else
    {
      int[] arrayOfInt1 = new int[1];
      int[] arrayOfInt2 = new int[1];
      if (OS.GTK_VERSION >= OS.VERSION(2, 24, 0)) {
        OS.gdk_pixmap_get_size(paramImage.pixmap, arrayOfInt1, arrayOfInt2);
      } else {
        OS.gdk_drawable_get_size(paramImage.pixmap, arrayOfInt1, arrayOfInt2);
      }
      i = arrayOfInt1[0];
      j = arrayOfInt2[0];
    }
    if (paramBoolean)
    {
      paramInt3 = paramInt7 = i;
      paramInt4 = paramInt8 = j;
    }
    else
    {
      paramBoolean = (paramInt1 == 0) && (paramInt2 == 0) && (paramInt3 == paramInt7) && (paramInt7 == i) && (paramInt4 == paramInt8) && (paramInt8 == j);
      if ((paramInt1 + paramInt3 > i) || (paramInt2 + paramInt4 > j)) {
        SWT.error(5);
      }
    }
    int k = this.data.cairo;
    if (k != 0)
    {
      if (this.data.alpha != 0)
      {
        paramImage.createSurface();
        Cairo.cairo_save(k);
        if ((this.data.style & 0x8000000) != 0)
        {
          Cairo.cairo_scale(k, -1.0D, 1.0D);
          Cairo.cairo_translate(k, -2 * paramInt5 - paramInt7, 0.0D);
        }
        Cairo.cairo_rectangle(k, paramInt5, paramInt6, paramInt7, paramInt8);
        Cairo.cairo_clip(k);
        if ((paramInt3 != paramInt7) || (paramInt4 != paramInt8))
        {
          float f1 = paramInt7 / paramInt3;
          float f2 = paramInt8 / paramInt4;
          Cairo.cairo_translate(k, paramInt5 - (int)(paramInt1 * f1), paramInt6 - (int)(paramInt2 * f2));
          Cairo.cairo_scale(k, f1, f2);
        }
        else
        {
          Cairo.cairo_translate(k, paramInt5 - paramInt1, paramInt6 - paramInt2);
        }
        int m = 1;
        switch (this.data.interpolation)
        {
        case -1: 
          m = 1;
          break;
        case 0: 
          m = 3;
          break;
        case 1: 
          m = 0;
          break;
        case 2: 
          m = 2;
        }
        int n = Cairo.cairo_pattern_create_for_surface(paramImage.surface);
        if (n == 0) {
          SWT.error(2);
        }
        if ((paramInt3 != paramInt7) || (paramInt4 != paramInt8))
        {
          int i1 = Cairo.cairo_version();
          if ((i1 >= Cairo.CAIRO_VERSION_ENCODE(1, 4, 0)) && (i1 < Cairo.CAIRO_VERSION_ENCODE(1, 8, 0)))
          {
            int i2 = Cairo.cairo_image_surface_create(0, i * 3, j * 3);
            int i3 = Cairo.cairo_create(i2);
            Cairo.cairo_set_source_surface(i3, paramImage.surface, i, j);
            Cairo.cairo_paint(i3);
            Cairo.cairo_scale(i3, -1.0D, -1.0D);
            Cairo.cairo_set_source_surface(i3, paramImage.surface, -i, -j);
            Cairo.cairo_paint(i3);
            Cairo.cairo_set_source_surface(i3, paramImage.surface, -i * 3, -j);
            Cairo.cairo_paint(i3);
            Cairo.cairo_set_source_surface(i3, paramImage.surface, -i, -j * 3);
            Cairo.cairo_paint(i3);
            Cairo.cairo_set_source_surface(i3, paramImage.surface, -i * 3, -j * 3);
            Cairo.cairo_paint(i3);
            Cairo.cairo_scale(i3, 1.0D, -1.0D);
            Cairo.cairo_set_source_surface(i3, paramImage.surface, -i, j);
            Cairo.cairo_paint(i3);
            Cairo.cairo_set_source_surface(i3, paramImage.surface, -i * 3, j);
            Cairo.cairo_paint(i3);
            Cairo.cairo_scale(i3, -1.0D, -1.0D);
            Cairo.cairo_set_source_surface(i3, paramImage.surface, i, -j);
            Cairo.cairo_paint(i3);
            Cairo.cairo_set_source_surface(i3, paramImage.surface, i, -j * 3);
            Cairo.cairo_paint(i3);
            Cairo.cairo_destroy(i3);
            int i4 = Cairo.cairo_pattern_create_for_surface(i2);
            Cairo.cairo_surface_destroy(i2);
            if (i4 == 0) {
              SWT.error(2);
            }
            Cairo.cairo_pattern_destroy(n);
            n = i4;
            Cairo.cairo_pattern_set_extend(n, 3);
            double[] arrayOfDouble = new double[6];
            Cairo.cairo_matrix_init_translate(arrayOfDouble, i, j);
            Cairo.cairo_pattern_set_matrix(n, arrayOfDouble);
          }
          else if (i1 >= Cairo.CAIRO_VERSION_ENCODE(1, 8, 0))
          {
            Cairo.cairo_pattern_set_extend(n, 3);
          }
        }
        Cairo.cairo_pattern_set_filter(n, m);
        Cairo.cairo_set_source(k, n);
        if (this.data.alpha != 255) {
          Cairo.cairo_paint_with_alpha(k, this.data.alpha / 255.0F);
        } else {
          Cairo.cairo_paint(k);
        }
        Cairo.cairo_restore(k);
        Cairo.cairo_pattern_destroy(n);
      }
      return;
    }
    if ((paramImage.alpha != -1) || (paramImage.alphaData != null)) {
      drawImageAlpha(paramImage, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8, paramBoolean, i, j);
    } else if ((paramImage.transparentPixel != -1) || (paramImage.mask != 0)) {
      drawImageMask(paramImage, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8, paramBoolean, i, j);
    } else {
      drawImage(paramImage, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8, paramBoolean, i, j);
    }
  }
  
  void drawImage(Image paramImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, boolean paramBoolean, int paramInt9, int paramInt10)
  {
    if ((paramInt3 == paramInt7) && (paramInt4 == paramInt8))
    {
      OS.gdk_draw_drawable(this.data.drawable, this.handle, paramImage.pixmap, paramInt1, paramInt2, paramInt5, paramInt6, paramInt7, paramInt8);
    }
    else
    {
      if (this.device.useXRender)
      {
        drawImageXRender(paramImage, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8, paramBoolean, paramInt9, paramInt10, 0, -1);
        return;
      }
      int i = scale(paramImage.pixmap, paramInt1, paramInt2, paramInt3, paramInt4, paramInt7, paramInt8);
      if (i != 0)
      {
        OS.gdk_pixbuf_render_to_drawable(i, this.data.drawable, this.handle, 0, 0, paramInt5, paramInt6, paramInt7, paramInt8, 1, 0, 0);
        OS.g_object_unref(i);
      }
    }
  }
  
  void drawImageAlpha(Image paramImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, boolean paramBoolean, int paramInt9, int paramInt10)
  {
    if (paramImage.alpha == 0) {
      return;
    }
    if (paramImage.alpha == 255)
    {
      drawImage(paramImage, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8, paramBoolean, paramInt9, paramInt10);
      return;
    }
    if (this.device.useXRender)
    {
      drawImageXRender(paramImage, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8, paramBoolean, paramInt9, paramInt10, paramImage.mask, 2);
      return;
    }
    int i = OS.gdk_pixbuf_new(0, true, 8, paramInt3, paramInt4);
    if (i == 0) {
      return;
    }
    int j = OS.gdk_colormap_get_system();
    OS.gdk_pixbuf_get_from_drawable(i, paramImage.pixmap, j, paramInt1, paramInt2, 0, 0, paramInt3, paramInt4);
    int k = OS.gdk_pixbuf_get_rowstride(i);
    int m = OS.gdk_pixbuf_get_pixels(i);
    byte[] arrayOfByte1 = new byte[k];
    int n = (byte)paramImage.alpha;
    byte[] arrayOfByte2 = paramImage.alphaData;
    for (int i1 = 0; i1 < paramInt4; i1++)
    {
      int i2 = (i1 + paramInt2) * paramInt9 + paramInt1;
      OS.memmove(arrayOfByte1, m + i1 * k, k);
      for (int i3 = 3; i3 < k; i3 += 4) {
        arrayOfByte1[i3] = (arrayOfByte2 == null ? n : arrayOfByte2[(i2++)]);
      }
      OS.memmove(m + i1 * k, arrayOfByte1, k);
    }
    if ((paramInt3 != paramInt7) || (paramInt4 != paramInt8))
    {
      i1 = OS.gdk_pixbuf_scale_simple(i, paramInt7, paramInt8, 2);
      OS.g_object_unref(i);
      if (i1 == 0) {
        return;
      }
      i = i1;
    }
    OS.gdk_draw_pixbuf(this.data.drawable, this.handle, i, 0, 0, paramInt5, paramInt6, paramInt7, paramInt8, 1, 0, 0);
    OS.g_object_unref(i);
  }
  
  void drawImageMask(Image paramImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, boolean paramBoolean, int paramInt9, int paramInt10)
  {
    int i = this.data.drawable;
    int j = paramImage.pixmap;
    if (paramImage.transparentPixel != -1) {
      paramImage.createMask();
    }
    int k = paramImage.mask;
    if (this.device.useXRender)
    {
      drawImageXRender(paramImage, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8, paramBoolean, paramInt9, paramInt10, k, 4);
    }
    else
    {
      int m;
      int n;
      int i1;
      int i3;
      if ((paramInt3 != paramInt7) || (paramInt4 != paramInt8))
      {
        m = OS.gdk_pixbuf_new(0, true, 8, paramInt3, paramInt4);
        if (m != 0)
        {
          n = OS.gdk_colormap_get_system();
          OS.gdk_pixbuf_get_from_drawable(m, j, n, paramInt1, paramInt2, 0, 0, paramInt3, paramInt4);
          i1 = OS.gdk_pixbuf_new(0, false, 8, paramInt3, paramInt4);
          if (i1 != 0)
          {
            OS.gdk_pixbuf_get_from_drawable(i1, k, 0, paramInt1, paramInt2, 0, 0, paramInt3, paramInt4);
            int i2 = OS.gdk_pixbuf_get_rowstride(m);
            i3 = OS.gdk_pixbuf_get_pixels(m);
            byte[] arrayOfByte2 = new byte[i2];
            int i5 = OS.gdk_pixbuf_get_rowstride(i1);
            int i6 = OS.gdk_pixbuf_get_pixels(i1);
            byte[] arrayOfByte3 = new byte[i5];
            for (int i7 = 0; i7 < paramInt4; i7++)
            {
              int i8 = i3 + i7 * i2;
              OS.memmove(arrayOfByte2, i8, i2);
              int i9 = i6 + i7 * i5;
              OS.memmove(arrayOfByte3, i9, i5);
              for (int i10 = 0; i10 < paramInt3; i10++) {
                if (arrayOfByte3[(i10 * 3)] == 0) {
                  arrayOfByte2[(i10 * 4 + 3)] = 0;
                }
              }
              OS.memmove(i8, arrayOfByte2, i2);
            }
            OS.g_object_unref(i1);
            i7 = OS.gdk_pixbuf_scale_simple(m, paramInt7, paramInt8, 2);
            if (i7 != 0)
            {
              int[] arrayOfInt1 = new int[1];
              int[] arrayOfInt2 = new int[1];
              OS.gdk_pixbuf_render_pixmap_and_mask(i7, arrayOfInt1, arrayOfInt2, 128);
              j = arrayOfInt1[0];
              k = arrayOfInt2[0];
              OS.g_object_unref(i7);
            }
          }
          OS.g_object_unref(m);
        }
        paramInt1 = 0;
        paramInt2 = 0;
        paramInt3 = paramInt7;
        paramInt4 = paramInt8;
      }
      if (this.data.clipRgn != 0)
      {
        m = paramInt1 + paramInt3;
        n = paramInt2 + paramInt4;
        i1 = (m + 7) / 8;
        byte[] arrayOfByte1 = new byte[i1 * n];
        i3 = OS.gdk_bitmap_create_from_data(0, arrayOfByte1, m, n);
        if (i3 != 0)
        {
          int i4 = OS.gdk_gc_new(i3);
          OS.gdk_region_offset(this.data.clipRgn, -paramInt5 + paramInt1, -paramInt6 + paramInt2);
          OS.gdk_gc_set_clip_region(i4, this.data.clipRgn);
          OS.gdk_region_offset(this.data.clipRgn, paramInt5 - paramInt1, paramInt6 - paramInt2);
          GdkColor localGdkColor = new GdkColor();
          localGdkColor.pixel = 1;
          OS.gdk_gc_set_foreground(i4, localGdkColor);
          OS.gdk_draw_rectangle(i3, i4, 1, 0, 0, m, n);
          OS.gdk_gc_set_function(i4, 4);
          OS.gdk_draw_drawable(i3, i4, k, 0, 0, 0, 0, m, n);
          OS.g_object_unref(i4);
          if ((k != 0) && (paramImage.mask != k)) {
            OS.g_object_unref(k);
          }
          k = i3;
        }
      }
      GdkGCValues localGdkGCValues = new GdkGCValues();
      OS.gdk_gc_get_values(this.handle, localGdkGCValues);
      OS.gdk_gc_set_clip_mask(this.handle, k);
      OS.gdk_gc_set_clip_origin(this.handle, paramInt5 - paramInt1, paramInt6 - paramInt2);
      OS.gdk_draw_drawable(i, this.handle, j, paramInt1, paramInt2, paramInt5, paramInt6, paramInt3, paramInt4);
      OS.gdk_gc_set_values(this.handle, localGdkGCValues, 6272);
      if (this.data.clipRgn != 0) {
        OS.gdk_gc_set_clip_region(this.handle, this.data.clipRgn);
      }
    }
    if ((j != 0) && (paramImage.pixmap != j)) {
      OS.g_object_unref(j);
    }
    if ((k != 0) && (paramImage.mask != k)) {
      OS.g_object_unref(k);
    }
    if ((paramImage.transparentPixel != -1) && (paramImage.memGC != null)) {
      paramImage.destroyMask();
    }
  }
  
  void drawImageXRender(Image paramImage, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, boolean paramBoolean, int paramInt9, int paramInt10, int paramInt11, int paramInt12)
  {
    int i = 0;
    int j = 0;
    int k = this.data.drawable;
    if ((this.data.image == null) && (!this.data.realDrawable))
    {
      int[] arrayOfInt1 = new int[1];
      int[] arrayOfInt2 = new int[1];
      int[] arrayOfInt3 = new int[1];
      OS.gdk_window_get_internal_paint_info(k, arrayOfInt3, arrayOfInt1, arrayOfInt2);
      k = arrayOfInt3[0];
      i = -arrayOfInt1[0];
      j = -arrayOfInt2[0];
    }
    int m = OS.gdk_x11_display_get_xdisplay(OS.gdk_display_get_default());
    int n = 0;
    if (paramInt11 != 0)
    {
      i1 = 0;
      XRenderPictureAttributes localXRenderPictureAttributes = null;
      if (paramImage.alpha != -1)
      {
        i1 = 1;
        localXRenderPictureAttributes = new XRenderPictureAttributes();
        localXRenderPictureAttributes.repeat = true;
      }
      n = OS.XRenderCreatePicture(m, OS.gdk_x11_drawable_get_xid(paramInt11), OS.XRenderFindStandardFormat(m, paramInt12), i1, localXRenderPictureAttributes);
      if (n == 0) {
        SWT.error(2);
      }
    }
    int i1 = OS.XRenderFindVisualFormat(m, OS.gdk_x11_visual_get_xvisual(OS.gdk_visual_get_system()));
    int i2 = OS.XRenderCreatePicture(m, OS.gdk_x11_drawable_get_xid(k), i1, 0, null);
    if (i2 == 0) {
      SWT.error(2);
    }
    int i3 = OS.XRenderCreatePicture(m, OS.gdk_x11_drawable_get_xid(paramImage.pixmap), i1, 0, null);
    if (i3 == 0) {
      SWT.error(2);
    }
    if ((paramInt3 != paramInt7) || (paramInt4 != paramInt8))
    {
      int[] arrayOfInt4 = { (int)(paramInt3 / paramInt7 * 65536.0F), 0, 0, 0, (int)(paramInt4 / paramInt8 * 65536.0F), 0, 0, 0, 65536 };
      OS.XRenderSetPictureTransform(m, i3, arrayOfInt4);
      if (n != 0) {
        OS.XRenderSetPictureTransform(m, n, arrayOfInt4);
      }
      paramInt1 = (int)(paramInt1 * (paramInt7 / paramInt3));
      paramInt2 = (int)(paramInt2 * (paramInt8 / paramInt4));
    }
    int i4 = this.data.clipRgn;
    if (this.data.damageRgn != 0) {
      if (i4 == 0)
      {
        i4 = this.data.damageRgn;
      }
      else
      {
        i4 = OS.gdk_region_new();
        OS.gdk_region_union(i4, this.data.clipRgn);
        OS.gdk_region_intersect(i4, this.data.damageRgn);
      }
    }
    if (i4 != 0)
    {
      int[] arrayOfInt5 = new int[1];
      int[] arrayOfInt6 = new int[1];
      OS.gdk_region_get_rectangles(i4, arrayOfInt6, arrayOfInt5);
      GdkRectangle localGdkRectangle = new GdkRectangle();
      short[] arrayOfShort = new short[arrayOfInt5[0] * 4];
      int i5 = 0;
      for (int i6 = 0; i5 < arrayOfInt5[0]; i6 += 4)
      {
        OS.memmove(localGdkRectangle, arrayOfInt6[0] + i5 * GdkRectangle.sizeof, GdkRectangle.sizeof);
        arrayOfShort[i6] = ((short)(i + localGdkRectangle.x));
        arrayOfShort[(i6 + 1)] = ((short)(j + localGdkRectangle.y));
        arrayOfShort[(i6 + 2)] = ((short)localGdkRectangle.width);
        arrayOfShort[(i6 + 3)] = ((short)localGdkRectangle.height);
        i5++;
      }
      OS.XRenderSetPictureClipRectangles(m, i2, 0, 0, arrayOfShort, arrayOfInt5[0]);
      if ((i4 != this.data.clipRgn) && (i4 != this.data.damageRgn)) {
        OS.gdk_region_destroy(i4);
      }
      if (arrayOfInt6[0] != 0) {
        OS.g_free(arrayOfInt6[0]);
      }
    }
    OS.XRenderComposite(m, n != 0 ? 3 : 1, i3, n, i2, paramInt1, paramInt2, paramInt1, paramInt2, paramInt5 + i, paramInt6 + j, paramInt7, paramInt8);
    OS.XRenderFreePicture(m, i2);
    OS.XRenderFreePicture(m, i3);
    if (n != 0) {
      OS.XRenderFreePicture(m, n);
    }
  }
  
  int scale(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7)
  {
    int i = OS.gdk_pixbuf_new(0, false, 8, paramInt4, paramInt5);
    if (i == 0) {
      return 0;
    }
    int j = OS.gdk_colormap_get_system();
    OS.gdk_pixbuf_get_from_drawable(i, paramInt1, j, paramInt2, paramInt3, 0, 0, paramInt4, paramInt5);
    int k = OS.gdk_pixbuf_scale_simple(i, paramInt6, paramInt7, 2);
    OS.g_object_unref(i);
    return k;
  }
  
  public void drawLine(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    if (this.handle == 0) {
      SWT.error(44);
    }
    checkGC(761);
    int i = this.data.cairo;
    if (i != 0)
    {
      double d1 = this.data.cairoXoffset;
      double d2 = this.data.cairoYoffset;
      Cairo.cairo_move_to(i, paramInt1 + d1, paramInt2 + d2);
      Cairo.cairo_line_to(i, paramInt3 + d1, paramInt4 + d2);
      Cairo.cairo_stroke(i);
      return;
    }
    OS.gdk_draw_line(this.data.drawable, this.handle, paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  public void drawOval(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    if (this.handle == 0) {
      SWT.error(44);
    }
    checkGC(761);
    if (paramInt3 < 0)
    {
      paramInt1 += paramInt3;
      paramInt3 = -paramInt3;
    }
    if (paramInt4 < 0)
    {
      paramInt2 += paramInt4;
      paramInt4 = -paramInt4;
    }
    int i = this.data.cairo;
    if (i != 0)
    {
      double d1 = this.data.cairoXoffset;
      double d2 = this.data.cairoYoffset;
      if (paramInt3 == paramInt4)
      {
        Cairo.cairo_arc_negative(i, paramInt1 + d1 + paramInt3 / 2.0F, paramInt2 + d2 + paramInt4 / 2.0F, paramInt3 / 2.0F, 0.0D, -2.0F * (float)Compatibility.PI);
      }
      else
      {
        Cairo.cairo_save(i);
        Cairo.cairo_translate(i, paramInt1 + d1 + paramInt3 / 2.0F, paramInt2 + d2 + paramInt4 / 2.0F);
        Cairo.cairo_scale(i, paramInt3 / 2.0F, paramInt4 / 2.0F);
        Cairo.cairo_arc_negative(i, 0.0D, 0.0D, 1.0D, 0.0D, -2.0F * (float)Compatibility.PI);
        Cairo.cairo_restore(i);
      }
      Cairo.cairo_stroke(i);
      return;
    }
    OS.gdk_draw_arc(this.data.drawable, this.handle, 0, paramInt1, paramInt2, paramInt3, paramInt4, 0, 23040);
  }
  
  public void drawPath(Path paramPath)
  {
    if (this.handle == 0) {
      SWT.error(44);
    }
    if (paramPath == null) {
      SWT.error(4);
    }
    if (paramPath.handle == 0) {
      SWT.error(5);
    }
    initCairo();
    checkGC(761);
    int i = this.data.cairo;
    Cairo.cairo_save(i);
    double d1 = this.data.cairoXoffset;
    double d2 = this.data.cairoYoffset;
    Cairo.cairo_translate(i, d1, d2);
    int j = Cairo.cairo_copy_path(paramPath.handle);
    if (j == 0) {
      SWT.error(2);
    }
    Cairo.cairo_append_path(i, j);
    Cairo.cairo_path_destroy(j);
    Cairo.cairo_stroke(i);
    Cairo.cairo_restore(i);
  }
  
  public void drawPoint(int paramInt1, int paramInt2)
  {
    if (this.handle == 0) {
      SWT.error(44);
    }
    checkGC(761);
    int i = this.data.cairo;
    if (i != 0)
    {
      Cairo.cairo_rectangle(i, paramInt1, paramInt2, 1.0D, 1.0D);
      Cairo.cairo_fill(i);
      return;
    }
    OS.gdk_draw_point(this.data.drawable, this.handle, paramInt1, paramInt2);
  }
  
  public void drawPolygon(int[] paramArrayOfInt)
  {
    if (this.handle == 0) {
      SWT.error(44);
    }
    if (paramArrayOfInt == null) {
      SWT.error(4);
    }
    checkGC(761);
    int i = this.data.cairo;
    if (i != 0)
    {
      drawPolyline(i, paramArrayOfInt, true);
      Cairo.cairo_stroke(i);
      return;
    }
    OS.gdk_draw_polygon(this.data.drawable, this.handle, 0, paramArrayOfInt, paramArrayOfInt.length / 2);
  }
  
  public void drawPolyline(int[] paramArrayOfInt)
  {
    if (this.handle == 0) {
      SWT.error(44);
    }
    if (paramArrayOfInt == null) {
      SWT.error(4);
    }
    checkGC(761);
    int i = this.data.cairo;
    if (i != 0)
    {
      drawPolyline(i, paramArrayOfInt, false);
      Cairo.cairo_stroke(i);
      return;
    }
    OS.gdk_draw_lines(this.data.drawable, this.handle, paramArrayOfInt, paramArrayOfInt.length / 2);
  }
  
  void drawPolyline(int paramInt, int[] paramArrayOfInt, boolean paramBoolean)
  {
    int i = paramArrayOfInt.length / 2;
    if (i == 0) {
      return;
    }
    double d1 = this.data.cairoXoffset;
    double d2 = this.data.cairoYoffset;
    Cairo.cairo_move_to(paramInt, paramArrayOfInt[0] + d1, paramArrayOfInt[1] + d2);
    int j = 1;
    for (int k = 2; j < i; k += 2)
    {
      Cairo.cairo_line_to(paramInt, paramArrayOfInt[k] + d1, paramArrayOfInt[(k + 1)] + d2);
      j++;
    }
    if (paramBoolean) {
      Cairo.cairo_close_path(paramInt);
    }
  }
  
  public void drawRectangle(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    if (this.handle == 0) {
      SWT.error(44);
    }
    checkGC(761);
    if (paramInt3 < 0)
    {
      paramInt1 += paramInt3;
      paramInt3 = -paramInt3;
    }
    if (paramInt4 < 0)
    {
      paramInt2 += paramInt4;
      paramInt4 = -paramInt4;
    }
    int i = this.data.cairo;
    if (i != 0)
    {
      double d1 = this.data.cairoXoffset;
      double d2 = this.data.cairoYoffset;
      Cairo.cairo_rectangle(i, paramInt1 + d1, paramInt2 + d2, paramInt3, paramInt4);
      Cairo.cairo_stroke(i);
      return;
    }
    OS.gdk_draw_rectangle(this.data.drawable, this.handle, 0, paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  public void drawRectangle(Rectangle paramRectangle)
  {
    if (paramRectangle == null) {
      SWT.error(4);
    }
    drawRectangle(paramRectangle.x, paramRectangle.y, paramRectangle.width, paramRectangle.height);
  }
  
  public void drawRoundRectangle(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6)
  {
    if (this.handle == 0) {
      SWT.error(44);
    }
    checkGC(761);
    int i = paramInt1;
    int j = paramInt2;
    int k = paramInt3;
    int m = paramInt4;
    int n = paramInt5;
    int i1 = paramInt6;
    if (k < 0)
    {
      k = 0 - k;
      i -= k;
    }
    if (m < 0)
    {
      m = 0 - m;
      j -= m;
    }
    if (n < 0) {
      n = 0 - n;
    }
    if (i1 < 0) {
      i1 = 0 - i1;
    }
    int i2 = this.data.cairo;
    if (i2 != 0)
    {
      double d1 = this.data.cairoXoffset;
      double d2 = this.data.cairoYoffset;
      if ((n == 0) || (i1 == 0))
      {
        Cairo.cairo_rectangle(i2, paramInt1 + d1, paramInt2 + d2, paramInt3, paramInt4);
      }
      else
      {
        float f1 = n / 2.0F;
        float f2 = i1 / 2.0F;
        float f3 = k / f1;
        float f4 = m / f2;
        Cairo.cairo_save(i2);
        Cairo.cairo_translate(i2, i + d1, j + d2);
        Cairo.cairo_scale(i2, f1, f2);
        Cairo.cairo_move_to(i2, f3 - 1.0F, 0.0D);
        Cairo.cairo_arc(i2, f3 - 1.0F, 1.0D, 1.0D, Compatibility.PI + Compatibility.PI / 2.0D, Compatibility.PI * 2.0D);
        Cairo.cairo_arc(i2, f3 - 1.0F, f4 - 1.0F, 1.0D, 0.0D, Compatibility.PI / 2.0D);
        Cairo.cairo_arc(i2, 1.0D, f4 - 1.0F, 1.0D, Compatibility.PI / 2.0D, Compatibility.PI);
        Cairo.cairo_arc(i2, 1.0D, 1.0D, 1.0D, Compatibility.PI, 270.0D * Compatibility.PI / 180.0D);
        Cairo.cairo_close_path(i2);
        Cairo.cairo_restore(i2);
      }
      Cairo.cairo_stroke(i2);
      return;
    }
    int i3 = n / 2;
    int i4 = i1 / 2;
    int i5 = this.data.drawable;
    if (k > n)
    {
      if (m > i1)
      {
        OS.gdk_draw_arc(i5, this.handle, 0, i, j, n, i1, 5760, 5760);
        OS.gdk_draw_line(i5, this.handle, i + i3, j, i + k - i3, j);
        OS.gdk_draw_arc(i5, this.handle, 0, i + k - n, j, n, i1, 0, 5760);
        OS.gdk_draw_line(i5, this.handle, i + k, j + i4, i + k, j + m - i4);
        OS.gdk_draw_arc(i5, this.handle, 0, i + k - n, j + m - i1, n, i1, 17280, 5760);
        OS.gdk_draw_line(i5, this.handle, i + i3, j + m, i + k - i3, j + m);
        OS.gdk_draw_arc(i5, this.handle, 0, i, j + m - i1, n, i1, 11520, 5760);
        OS.gdk_draw_line(i5, this.handle, i, j + i4, i, j + m - i4);
      }
      else
      {
        OS.gdk_draw_arc(i5, this.handle, 0, i, j, n, m, 5760, 11520);
        OS.gdk_draw_line(i5, this.handle, i + i3, j, i + k - i3, j);
        OS.gdk_draw_arc(i5, this.handle, 0, i + k - n, j, n, m, 17280, 11520);
        OS.gdk_draw_line(i5, this.handle, i + i3, j + m, i + k - i3, j + m);
      }
    }
    else if (m > i1)
    {
      OS.gdk_draw_arc(i5, this.handle, 0, i, j, k, i1, 0, 11520);
      OS.gdk_draw_line(i5, this.handle, i + k, j + i4, i + k, j + m - i4);
      OS.gdk_draw_arc(i5, this.handle, 0, i, j + m - i1, k, i1, 11520, 11520);
      OS.gdk_draw_line(i5, this.handle, i, j + i4, i, j + m - i4);
    }
    else
    {
      OS.gdk_draw_arc(i5, this.handle, 0, i, j, k, m, 0, 23040);
    }
  }
  
  public void drawString(String paramString, int paramInt1, int paramInt2)
  {
    drawString(paramString, paramInt1, paramInt2, false);
  }
  
  public void drawString(String paramString, int paramInt1, int paramInt2, boolean paramBoolean)
  {
    drawText(paramString, paramInt1, paramInt2, paramBoolean ? 1 : 0);
  }
  
  public void drawText(String paramString, int paramInt1, int paramInt2)
  {
    drawText(paramString, paramInt1, paramInt2, 6);
  }
  
  public void drawText(String paramString, int paramInt1, int paramInt2, boolean paramBoolean)
  {
    int i = 6;
    if (paramBoolean) {
      i |= 0x1;
    }
    drawText(paramString, paramInt1, paramInt2, i);
  }
  
  public void drawText(String paramString, int paramInt1, int paramInt2, int paramInt3)
  {
    if (this.handle == 0) {
      SWT.error(44);
    }
    if (paramString == null) {
      SWT.error(4);
    }
    if (paramString.length() == 0) {
      return;
    }
    int i = this.data.cairo;
    setString(paramString, paramInt3);
    if (i != 0)
    {
      checkGC(4);
      if ((paramInt3 & 0x1) == 0)
      {
        checkGC(2);
        if (this.data.stringWidth == -1) {
          computeStringSize();
        }
        Cairo.cairo_rectangle(i, paramInt1, paramInt2, this.data.stringWidth, this.data.stringHeight);
        Cairo.cairo_fill(i);
      }
      checkGC(1);
      if ((this.data.style & 0x8000000) != 0)
      {
        Cairo.cairo_save(i);
        if (this.data.stringWidth == -1) {
          computeStringSize();
        }
        Cairo.cairo_scale(i, -1.0D, 1.0D);
        Cairo.cairo_translate(i, -2 * paramInt1 - this.data.stringWidth, 0.0D);
      }
      Cairo.cairo_move_to(i, paramInt1, paramInt2);
      OS.pango_cairo_show_layout(i, this.data.layout);
      if ((this.data.style & 0x8000000) != 0) {
        Cairo.cairo_restore(i);
      }
      Cairo.cairo_new_path(i);
      return;
    }
    checkGC(261);
    GdkColor localGdkColor1 = null;
    if ((paramInt3 & 0x1) == 0) {
      localGdkColor1 = this.data.background;
    }
    if (!this.data.xorMode)
    {
      OS.gdk_draw_layout_with_colors(this.data.drawable, this.handle, paramInt1, paramInt2, this.data.layout, null, localGdkColor1);
    }
    else
    {
      int j = this.data.layout;
      if (this.data.stringWidth == -1) {
        computeStringSize();
      }
      int k = OS.gdk_pixmap_new(OS.gdk_get_default_root_window(), this.data.stringWidth, this.data.stringHeight, -1);
      if (k == 0) {
        SWT.error(2);
      }
      int m = OS.gdk_gc_new(k);
      if (m == 0) {
        SWT.error(2);
      }
      GdkColor localGdkColor2 = new GdkColor();
      OS.gdk_gc_set_foreground(m, localGdkColor2);
      OS.gdk_draw_rectangle(k, m, 1, 0, 0, this.data.stringWidth, this.data.stringHeight);
      OS.gdk_gc_set_foreground(m, this.data.foreground);
      OS.gdk_draw_layout_with_colors(k, m, 0, 0, j, null, localGdkColor1);
      OS.g_object_unref(m);
      OS.gdk_draw_drawable(this.data.drawable, this.handle, k, 0, 0, paramInt1, paramInt2, this.data.stringWidth, this.data.stringHeight);
      OS.g_object_unref(k);
    }
  }
  
  public boolean equals(Object paramObject)
  {
    if (paramObject == this) {
      return true;
    }
    if (!(paramObject instanceof GC)) {
      return false;
    }
    return this.handle == ((GC)paramObject).handle;
  }
  
  public void fillArc(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6)
  {
    if (this.handle == 0) {
      SWT.error(44);
    }
    checkGC(2);
    if (paramInt3 < 0)
    {
      paramInt1 += paramInt3;
      paramInt3 = -paramInt3;
    }
    if (paramInt4 < 0)
    {
      paramInt2 += paramInt4;
      paramInt4 = -paramInt4;
    }
    if ((paramInt3 == 0) || (paramInt4 == 0) || (paramInt6 == 0)) {
      return;
    }
    int i = this.data.cairo;
    if (i != 0)
    {
      if (paramInt3 == paramInt4)
      {
        if (paramInt6 >= 0) {
          Cairo.cairo_arc_negative(i, paramInt1 + paramInt3 / 2.0F, paramInt2 + paramInt4 / 2.0F, paramInt3 / 2.0F, -paramInt5 * (float)Compatibility.PI / 180.0F, -(paramInt5 + paramInt6) * (float)Compatibility.PI / 180.0F);
        } else {
          Cairo.cairo_arc(i, paramInt1 + paramInt3 / 2.0F, paramInt2 + paramInt4 / 2.0F, paramInt3 / 2.0F, -paramInt5 * (float)Compatibility.PI / 180.0F, -(paramInt5 + paramInt6) * (float)Compatibility.PI / 180.0F);
        }
        Cairo.cairo_line_to(i, paramInt1 + paramInt3 / 2.0F, paramInt2 + paramInt4 / 2.0F);
      }
      else
      {
        Cairo.cairo_save(i);
        Cairo.cairo_translate(i, paramInt1 + paramInt3 / 2.0F, paramInt2 + paramInt4 / 2.0F);
        Cairo.cairo_scale(i, paramInt3 / 2.0F, paramInt4 / 2.0F);
        if (paramInt6 >= 0) {
          Cairo.cairo_arc_negative(i, 0.0D, 0.0D, 1.0D, -paramInt5 * (float)Compatibility.PI / 180.0F, -(paramInt5 + paramInt6) * (float)Compatibility.PI / 180.0F);
        } else {
          Cairo.cairo_arc(i, 0.0D, 0.0D, 1.0D, -paramInt5 * (float)Compatibility.PI / 180.0F, -(paramInt5 + paramInt6) * (float)Compatibility.PI / 180.0F);
        }
        Cairo.cairo_line_to(i, 0.0D, 0.0D);
        Cairo.cairo_restore(i);
      }
      Cairo.cairo_fill(i);
      return;
    }
    OS.gdk_draw_arc(this.data.drawable, this.handle, 1, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5 * 64, paramInt6 * 64);
  }
  
  public void fillGradientRectangle(int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean)
  {
    if (this.handle == 0) {
      SWT.error(44);
    }
    if ((paramInt3 == 0) || (paramInt4 == 0)) {
      return;
    }
    RGB localRGB1 = getBackground().getRGB();
    RGB localRGB2 = getForeground().getRGB();
    RGB localRGB3 = localRGB2;
    RGB localRGB4 = localRGB1;
    int i = 0;
    if (paramInt3 < 0)
    {
      paramInt1 += paramInt3;
      paramInt3 = -paramInt3;
      if (!paramBoolean) {
        i = 1;
      }
    }
    if (paramInt4 < 0)
    {
      paramInt2 += paramInt4;
      paramInt4 = -paramInt4;
      if (paramBoolean) {
        i = 1;
      }
    }
    if (i != 0)
    {
      localRGB3 = localRGB1;
      localRGB4 = localRGB2;
    }
    if (localRGB3.equals(localRGB4))
    {
      fillRectangle(paramInt1, paramInt2, paramInt3, paramInt4);
      return;
    }
    int j = this.data.cairo;
    if (j != 0)
    {
      int k;
      if (paramBoolean) {
        k = Cairo.cairo_pattern_create_linear(0.0D, 0.0D, 0.0D, 1.0D);
      } else {
        k = Cairo.cairo_pattern_create_linear(0.0D, 0.0D, 1.0D, 0.0D);
      }
      Cairo.cairo_pattern_add_color_stop_rgba(k, 0.0D, localRGB3.red / 255.0F, localRGB3.green / 255.0F, localRGB3.blue / 255.0F, this.data.alpha / 255.0F);
      Cairo.cairo_pattern_add_color_stop_rgba(k, 1.0D, localRGB4.red / 255.0F, localRGB4.green / 255.0F, localRGB4.blue / 255.0F, this.data.alpha / 255.0F);
      Cairo.cairo_save(j);
      Cairo.cairo_translate(j, paramInt1, paramInt2);
      Cairo.cairo_scale(j, paramInt3, paramInt4);
      Cairo.cairo_rectangle(j, 0.0D, 0.0D, 1.0D, 1.0D);
      Cairo.cairo_set_source(j, k);
      Cairo.cairo_fill(j);
      Cairo.cairo_restore(j);
      Cairo.cairo_pattern_destroy(k);
      return;
    }
    ImageData.fillGradientRectangle(this, this.data.device, paramInt1, paramInt2, paramInt3, paramInt4, paramBoolean, localRGB3, localRGB4, 8, 8, 8);
  }
  
  public void fillOval(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    if (this.handle == 0) {
      SWT.error(44);
    }
    checkGC(2);
    if (paramInt3 < 0)
    {
      paramInt1 += paramInt3;
      paramInt3 = -paramInt3;
    }
    if (paramInt4 < 0)
    {
      paramInt2 += paramInt4;
      paramInt4 = -paramInt4;
    }
    int i = this.data.cairo;
    if (i != 0)
    {
      if (paramInt3 == paramInt4)
      {
        Cairo.cairo_arc_negative(i, paramInt1 + paramInt3 / 2.0F, paramInt2 + paramInt4 / 2.0F, paramInt3 / 2.0F, 0.0D, 2.0F * (float)Compatibility.PI);
      }
      else
      {
        Cairo.cairo_save(i);
        Cairo.cairo_translate(i, paramInt1 + paramInt3 / 2.0F, paramInt2 + paramInt4 / 2.0F);
        Cairo.cairo_scale(i, paramInt3 / 2.0F, paramInt4 / 2.0F);
        Cairo.cairo_arc_negative(i, 0.0D, 0.0D, 1.0D, 0.0D, 2.0F * (float)Compatibility.PI);
        Cairo.cairo_restore(i);
      }
      Cairo.cairo_fill(i);
      return;
    }
    OS.gdk_draw_arc(this.data.drawable, this.handle, 1, paramInt1, paramInt2, paramInt3, paramInt4, 0, 23040);
  }
  
  public void fillPath(Path paramPath)
  {
    if (this.handle == 0) {
      SWT.error(44);
    }
    if (paramPath == null) {
      SWT.error(4);
    }
    if (paramPath.handle == 0) {
      SWT.error(5);
    }
    initCairo();
    checkGC(2);
    int i = this.data.cairo;
    int j = Cairo.cairo_copy_path(paramPath.handle);
    if (j == 0) {
      SWT.error(2);
    }
    Cairo.cairo_append_path(i, j);
    Cairo.cairo_path_destroy(j);
    Cairo.cairo_fill(i);
  }
  
  public void fillPolygon(int[] paramArrayOfInt)
  {
    if (this.handle == 0) {
      SWT.error(44);
    }
    if (paramArrayOfInt == null) {
      SWT.error(4);
    }
    checkGC(2);
    int i = this.data.cairo;
    if (i != 0)
    {
      drawPolyline(i, paramArrayOfInt, true);
      Cairo.cairo_fill(i);
      return;
    }
    OS.gdk_draw_polygon(this.data.drawable, this.handle, 1, paramArrayOfInt, paramArrayOfInt.length / 2);
  }
  
  public void fillRectangle(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    if (this.handle == 0) {
      SWT.error(44);
    }
    checkGC(2);
    if (paramInt3 < 0)
    {
      paramInt1 += paramInt3;
      paramInt3 = -paramInt3;
    }
    if (paramInt4 < 0)
    {
      paramInt2 += paramInt4;
      paramInt4 = -paramInt4;
    }
    int i = this.data.cairo;
    if (i != 0)
    {
      Cairo.cairo_rectangle(i, paramInt1, paramInt2, paramInt3, paramInt4);
      Cairo.cairo_fill(i);
      return;
    }
    OS.gdk_draw_rectangle(this.data.drawable, this.handle, 1, paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  public void fillRectangle(Rectangle paramRectangle)
  {
    if (this.handle == 0) {
      SWT.error(44);
    }
    if (paramRectangle == null) {
      SWT.error(4);
    }
    fillRectangle(paramRectangle.x, paramRectangle.y, paramRectangle.width, paramRectangle.height);
  }
  
  public void fillRoundRectangle(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6)
  {
    if (this.handle == 0) {
      SWT.error(44);
    }
    checkGC(2);
    int i = paramInt1;
    int j = paramInt2;
    int k = paramInt3;
    int m = paramInt4;
    int n = paramInt5;
    int i1 = paramInt6;
    if (k < 0)
    {
      k = 0 - k;
      i -= k;
    }
    if (m < 0)
    {
      m = 0 - m;
      j -= m;
    }
    if (n < 0) {
      n = 0 - n;
    }
    if (i1 < 0) {
      i1 = 0 - i1;
    }
    int i2 = this.data.cairo;
    if (i2 != 0)
    {
      if ((n == 0) || (i1 == 0))
      {
        Cairo.cairo_rectangle(i2, paramInt1, paramInt2, paramInt3, paramInt4);
      }
      else
      {
        float f1 = n / 2.0F;
        float f2 = i1 / 2.0F;
        float f3 = k / f1;
        float f4 = m / f2;
        Cairo.cairo_save(i2);
        Cairo.cairo_translate(i2, i, j);
        Cairo.cairo_scale(i2, f1, f2);
        Cairo.cairo_move_to(i2, f3 - 1.0F, 0.0D);
        Cairo.cairo_arc(i2, f3 - 1.0F, 1.0D, 1.0D, Compatibility.PI + Compatibility.PI / 2.0D, Compatibility.PI * 2.0D);
        Cairo.cairo_arc(i2, f3 - 1.0F, f4 - 1.0F, 1.0D, 0.0D, Compatibility.PI / 2.0D);
        Cairo.cairo_arc(i2, 1.0D, f4 - 1.0F, 1.0D, Compatibility.PI / 2.0D, Compatibility.PI);
        Cairo.cairo_arc(i2, 1.0D, 1.0D, 1.0D, Compatibility.PI, 270.0D * Compatibility.PI / 180.0D);
        Cairo.cairo_close_path(i2);
        Cairo.cairo_restore(i2);
      }
      Cairo.cairo_fill(i2);
      return;
    }
    int i3 = n / 2;
    int i4 = i1 / 2;
    int i5 = this.data.drawable;
    if (k > n)
    {
      if (m > i1)
      {
        OS.gdk_draw_arc(i5, this.handle, 1, i, j, n, i1, 5760, 5760);
        OS.gdk_draw_rectangle(i5, this.handle, 1, i + i3, j, k - i3 * 2, m);
        OS.gdk_draw_arc(i5, this.handle, 1, i + k - n, j, n, i1, 0, 5760);
        OS.gdk_draw_rectangle(i5, this.handle, 1, i, j + i4, i3, m - i4 * 2);
        OS.gdk_draw_arc(i5, this.handle, 1, i + k - n, j + m - i1, n, i1, 17280, 5760);
        OS.gdk_draw_rectangle(i5, this.handle, 1, i + k - i3, j + i4, i3, m - i4 * 2);
        OS.gdk_draw_arc(i5, this.handle, 1, i, j + m - i1, n, i1, 11520, 5760);
      }
      else
      {
        OS.gdk_draw_arc(i5, this.handle, 1, i, j, n, m, 5760, 11520);
        OS.gdk_draw_rectangle(i5, this.handle, 1, i + i3, j, k - i3 * 2, m);
        OS.gdk_draw_arc(i5, this.handle, 1, i + k - n, j, n, m, 17280, 11520);
      }
    }
    else if (m > i1)
    {
      OS.gdk_draw_arc(i5, this.handle, 1, i, j, k, i1, 0, 11520);
      OS.gdk_draw_rectangle(i5, this.handle, 1, i, j + i4, k, m - i4 * 2);
      OS.gdk_draw_arc(i5, this.handle, 1, i, j + m - i1, k, i1, 11520, 11520);
    }
    else
    {
      OS.gdk_draw_arc(i5, this.handle, 1, i, j, k, m, 0, 23040);
    }
  }
  
  int fixMnemonic(char[] paramArrayOfChar)
  {
    int i = 0;
    int j = 0;
    int k = -1;
    while (i < paramArrayOfChar.length) {
      if (((paramArrayOfChar[(j++)] = paramArrayOfChar[(i++)]) == '&') && (i != paramArrayOfChar.length)) {
        if (paramArrayOfChar[i] == '&')
        {
          i++;
        }
        else
        {
          if (k == -1) {
            k = j;
          }
          j--;
        }
      }
    }
    while (j < paramArrayOfChar.length) {
      paramArrayOfChar[(j++)] = '\000';
    }
    return k;
  }
  
  public int getAdvanceWidth(char paramChar)
  {
    if (this.handle == 0) {
      SWT.error(44);
    }
    return stringExtent(new String(new char[] { paramChar })).x;
  }
  
  public boolean getAdvanced()
  {
    if (this.handle == 0) {
      SWT.error(44);
    }
    return this.data.cairo != 0;
  }
  
  public int getAlpha()
  {
    if (this.handle == 0) {
      SWT.error(44);
    }
    return this.data.alpha;
  }
  
  public int getAntialias()
  {
    if (this.handle == 0) {
      SWT.error(44);
    }
    if (this.data.cairo == 0) {
      return -1;
    }
    int i = Cairo.cairo_get_antialias(this.data.cairo);
    switch (i)
    {
    case 0: 
      return -1;
    case 1: 
      return 0;
    case 2: 
    case 3: 
      return 1;
    }
    return -1;
  }
  
  public Color getBackground()
  {
    if (this.handle == 0) {
      SWT.error(44);
    }
    return Color.gtk_new(this.data.device, this.data.background);
  }
  
  public Pattern getBackgroundPattern()
  {
    if (this.handle == 0) {
      SWT.error(44);
    }
    return this.data.backgroundPattern;
  }
  
  public int getCharWidth(char paramChar)
  {
    if (this.handle == 0) {
      SWT.error(44);
    }
    return stringExtent(new String(new char[] { paramChar })).x;
  }
  
  public Rectangle getClipping()
  {
    if (this.handle == 0) {
      SWT.error(44);
    }
    int i = 0;
    int j = 0;
    int k = 0;
    int m = 0;
    int[] arrayOfInt1 = new int[1];
    int[] arrayOfInt2 = new int[1];
    getSize(arrayOfInt1, arrayOfInt2);
    k = arrayOfInt1[0];
    m = arrayOfInt2[0];
    int n = this.data.cairo;
    int i1 = this.data.clipRgn;
    int i2 = this.data.damageRgn;
    if ((i1 != 0) || (i2 != 0) || (n != 0))
    {
      int i3 = OS.gdk_region_new();
      GdkRectangle localGdkRectangle = new GdkRectangle();
      localGdkRectangle.width = k;
      localGdkRectangle.height = m;
      OS.gdk_region_union_with_rect(i3, localGdkRectangle);
      if (i2 != 0) {
        OS.gdk_region_intersect(i3, i2);
      }
      if (i1 != 0) {
        if (this.data.clippingTransform != null)
        {
          i1 = convertRgn(i1, this.data.clippingTransform);
          OS.gdk_region_intersect(i3, i1);
          OS.gdk_region_destroy(i1);
        }
        else
        {
          OS.gdk_region_intersect(i3, i1);
        }
      }
      if (n != 0)
      {
        double[] arrayOfDouble = new double[6];
        Cairo.cairo_get_matrix(n, arrayOfDouble);
        Cairo.cairo_matrix_invert(arrayOfDouble);
        i1 = convertRgn(i3, arrayOfDouble);
        OS.gdk_region_destroy(i3);
        i3 = i1;
      }
      OS.gdk_region_get_clipbox(i3, localGdkRectangle);
      OS.gdk_region_destroy(i3);
      i = localGdkRectangle.x;
      j = localGdkRectangle.y;
      k = localGdkRectangle.width;
      m = localGdkRectangle.height;
    }
    return new Rectangle(i, j, k, m);
  }
  
  public void getClipping(Region paramRegion)
  {
    if (this.handle == 0) {
      SWT.error(44);
    }
    if (paramRegion == null) {
      SWT.error(4);
    }
    if (paramRegion.isDisposed()) {
      SWT.error(5);
    }
    int i = paramRegion.handle;
    OS.gdk_region_subtract(i, i);
    int j = this.data.cairo;
    int k = this.data.clipRgn;
    if (k == 0)
    {
      GdkRectangle localGdkRectangle = new GdkRectangle();
      int[] arrayOfInt1 = new int[1];
      int[] arrayOfInt2 = new int[1];
      getSize(arrayOfInt1, arrayOfInt2);
      localGdkRectangle.width = arrayOfInt1[0];
      localGdkRectangle.height = arrayOfInt2[0];
      OS.gdk_region_union_with_rect(i, localGdkRectangle);
    }
    else if (this.data.clippingTransform != null)
    {
      int m = convertRgn(k, this.data.clippingTransform);
      OS.gdk_region_union(i, m);
      OS.gdk_region_destroy(m);
    }
    else
    {
      OS.gdk_region_union(i, k);
    }
    if (this.data.damageRgn != 0) {
      OS.gdk_region_intersect(i, this.data.damageRgn);
    }
    if (j != 0)
    {
      double[] arrayOfDouble = new double[6];
      Cairo.cairo_get_matrix(j, arrayOfDouble);
      Cairo.cairo_matrix_invert(arrayOfDouble);
      int n = convertRgn(i, arrayOfDouble);
      OS.gdk_region_subtract(i, i);
      OS.gdk_region_union(i, n);
      OS.gdk_region_destroy(n);
    }
  }
  
  public int getFillRule()
  {
    if (this.handle == 0) {
      SWT.error(44);
    }
    int i = this.data.cairo;
    if (i == 0) {
      return 1;
    }
    return Cairo.cairo_get_fill_rule(i) == 0 ? 2 : 1;
  }
  
  public Font getFont()
  {
    if (this.handle == 0) {
      SWT.error(44);
    }
    return this.data.font;
  }
  
  public FontMetrics getFontMetrics()
  {
    if (this.handle == 0) {
      SWT.error(44);
    }
    if (this.data.context == 0) {
      createLayout();
    }
    checkGC(4);
    Font localFont = this.data.font;
    int i = this.data.context;
    int j = OS.pango_context_get_language(i);
    int k = OS.pango_context_get_metrics(i, localFont.handle, j);
    FontMetrics localFontMetrics = new FontMetrics();
    localFontMetrics.ascent = OS.PANGO_PIXELS(OS.pango_font_metrics_get_ascent(k));
    localFontMetrics.descent = OS.PANGO_PIXELS(OS.pango_font_metrics_get_descent(k));
    localFontMetrics.averageCharWidth = OS.PANGO_PIXELS(OS.pango_font_metrics_get_approximate_char_width(k));
    localFontMetrics.height = (localFontMetrics.ascent + localFontMetrics.descent);
    OS.pango_font_metrics_unref(k);
    return localFontMetrics;
  }
  
  public Color getForeground()
  {
    if (this.handle == 0) {
      SWT.error(24);
    }
    return Color.gtk_new(this.data.device, this.data.foreground);
  }
  
  public Pattern getForegroundPattern()
  {
    if (this.handle == 0) {
      SWT.error(44);
    }
    return this.data.foregroundPattern;
  }
  
  public GCData getGCData()
  {
    if (this.handle == 0) {
      SWT.error(44);
    }
    return this.data;
  }
  
  public int getInterpolation()
  {
    if (this.handle == 0) {
      SWT.error(44);
    }
    return this.data.interpolation;
  }
  
  public LineAttributes getLineAttributes()
  {
    if (this.handle == 0) {
      SWT.error(44);
    }
    float[] arrayOfFloat = null;
    if (this.data.lineDashes != null)
    {
      arrayOfFloat = new float[this.data.lineDashes.length];
      System.arraycopy(this.data.lineDashes, 0, arrayOfFloat, 0, arrayOfFloat.length);
    }
    return new LineAttributes(this.data.lineWidth, this.data.lineCap, this.data.lineJoin, this.data.lineStyle, arrayOfFloat, this.data.lineDashesOffset, this.data.lineMiterLimit);
  }
  
  public int getLineCap()
  {
    if (this.handle == 0) {
      SWT.error(44);
    }
    return this.data.lineCap;
  }
  
  public int[] getLineDash()
  {
    if (this.handle == 0) {
      SWT.error(44);
    }
    if (this.data.lineDashes == null) {
      return null;
    }
    int[] arrayOfInt = new int[this.data.lineDashes.length];
    for (int i = 0; i < arrayOfInt.length; i++) {
      arrayOfInt[i] = ((int)this.data.lineDashes[i]);
    }
    return arrayOfInt;
  }
  
  public int getLineJoin()
  {
    if (this.handle == 0) {
      SWT.error(44);
    }
    return this.data.lineJoin;
  }
  
  public int getLineStyle()
  {
    if (this.handle == 0) {
      SWT.error(44);
    }
    return this.data.lineStyle;
  }
  
  public int getLineWidth()
  {
    if (this.handle == 0) {
      SWT.error(44);
    }
    return (int)this.data.lineWidth;
  }
  
  public int getStyle()
  {
    if (this.handle == 0) {
      SWT.error(44);
    }
    return this.data.style;
  }
  
  void getSize(int[] paramArrayOfInt1, int[] paramArrayOfInt2)
  {
    if ((this.data.width != -1) && (this.data.height != -1))
    {
      paramArrayOfInt1[0] = this.data.width;
      paramArrayOfInt2[0] = this.data.height;
      return;
    }
    if (this.data.drawable != 0)
    {
      if (OS.GTK_VERSION >= OS.VERSION(2, 24, 0))
      {
        paramArrayOfInt1[0] = OS.gdk_window_get_width(this.data.drawable);
        paramArrayOfInt2[0] = OS.gdk_window_get_height(this.data.drawable);
      }
      else
      {
        OS.gdk_drawable_get_size(this.data.drawable, paramArrayOfInt1, paramArrayOfInt2);
      }
      return;
    }
    if (OS.USE_CAIRO)
    {
      int i = Cairo.cairo_get_target(this.handle);
      switch (Cairo.cairo_surface_get_type(i))
      {
      case 0: 
        paramArrayOfInt1[0] = Cairo.cairo_image_surface_get_width(i);
        paramArrayOfInt2[0] = Cairo.cairo_image_surface_get_height(i);
        break;
      case 3: 
        paramArrayOfInt1[0] = Cairo.cairo_xlib_surface_get_width(i);
        paramArrayOfInt2[0] = Cairo.cairo_xlib_surface_get_height(i);
      }
    }
  }
  
  public int getTextAntialias()
  {
    if (this.handle == 0) {
      SWT.error(44);
    }
    if (this.data.cairo == 0) {
      return -1;
    }
    int i = 0;
    if (this.data.context != 0)
    {
      int j = OS.pango_cairo_context_get_font_options(this.data.context);
      if (j != 0) {
        i = Cairo.cairo_font_options_get_antialias(j);
      }
    }
    switch (i)
    {
    case 0: 
      return -1;
    case 1: 
      return 0;
    case 2: 
    case 3: 
      return 1;
    }
    return -1;
  }
  
  public void getTransform(Transform paramTransform)
  {
    if (this.handle == 0) {
      SWT.error(44);
    }
    if (paramTransform == null) {
      SWT.error(4);
    }
    if (paramTransform.isDisposed()) {
      SWT.error(5);
    }
    int i = this.data.cairo;
    if (i != 0)
    {
      Cairo.cairo_get_matrix(i, paramTransform.handle);
      double[] arrayOfDouble = identity();
      Cairo.cairo_matrix_invert(arrayOfDouble);
      Cairo.cairo_matrix_multiply(paramTransform.handle, paramTransform.handle, arrayOfDouble);
    }
    else
    {
      paramTransform.setElements(1.0F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F);
    }
  }
  
  public boolean getXORMode()
  {
    if (this.handle == 0) {
      SWT.error(44);
    }
    return this.data.xorMode;
  }
  
  public int hashCode()
  {
    return this.handle;
  }
  
  double[] identity()
  {
    double[] arrayOfDouble = new double[6];
    if ((this.data.style & 0x8000000) != 0)
    {
      int[] arrayOfInt1 = new int[1];
      int[] arrayOfInt2 = new int[1];
      getSize(arrayOfInt1, arrayOfInt2);
      Cairo.cairo_matrix_init(arrayOfDouble, -1.0D, 0.0D, 0.0D, 1.0D, arrayOfInt1[0], 0.0D);
    }
    else
    {
      Cairo.cairo_matrix_init_identity(arrayOfDouble);
    }
    if (this.data.identity != null) {
      Cairo.cairo_matrix_multiply(arrayOfDouble, this.data.identity, arrayOfDouble);
    }
    return arrayOfDouble;
  }
  
  void init(Drawable paramDrawable, GCData paramGCData, int paramInt)
  {
    if (paramGCData.foreground != null) {
      paramGCData.state &= 0xFFFFFFFE;
    }
    if (paramGCData.background != null) {
      paramGCData.state &= 0xFEFD;
    }
    if (paramGCData.font != null) {
      paramGCData.state &= 0xFFFFFFFB;
    }
    Image localImage = paramGCData.image;
    if (localImage != null)
    {
      localImage.memGC = this;
      if (localImage.transparentPixel != -1) {
        localImage.destroyMask();
      }
    }
    this.drawable = paramDrawable;
    this.data = paramGCData;
    this.handle = paramInt;
    int i;
    if (OS.USE_CAIRO)
    {
      i = paramGCData.cairo = this.handle;
      Cairo.cairo_set_fill_rule(i, 1);
      paramGCData.state &= 0xFD80;
    }
    else if (OS.INIT_CAIRO)
    {
      initCairo();
    }
    setClipping(paramGCData.clipRgn);
    if ((paramGCData.style & 0x8000000) != 0)
    {
      initCairo();
      i = paramGCData.cairo;
      Cairo.cairo_set_matrix(i, identity());
    }
  }
  
  void initCairo()
  {
    this.data.device.checkCairo();
    int i = this.data.cairo;
    if (i != 0) {
      return;
    }
    if (OS.GTK_VERSION < OS.VERSION(2, 17, 0))
    {
      int j = OS.gdk_x11_display_get_xdisplay(OS.gdk_display_get_default());
      int k = OS.gdk_x11_visual_get_xvisual(OS.gdk_visual_get_system());
      int m = 0;
      int n = 0;
      int i1 = 0;
      int i2 = this.data.drawable;
      int[] arrayOfInt3;
      if (this.data.image != null)
      {
        m = OS.GDK_PIXMAP_XID(i2);
      }
      else if (!this.data.realDrawable)
      {
        int[] arrayOfInt1 = new int[1];
        int[] arrayOfInt2 = new int[1];
        arrayOfInt3 = new int[1];
        OS.gdk_window_get_internal_paint_info(i2, arrayOfInt3, arrayOfInt1, arrayOfInt2);
        m = OS.gdk_x11_drawable_get_xid(arrayOfInt3[0]);
        n = -arrayOfInt1[0];
        i1 = -arrayOfInt2[0];
      }
      int i3 = 0;
      int i4 = 0;
      if (OS.GTK_VERSION >= OS.VERSION(2, 24, 0))
      {
        i3 = OS.gdk_window_get_width(this.data.drawable);
        i4 = OS.gdk_window_get_height(this.data.drawable);
      }
      else
      {
        arrayOfInt3 = new int[1];
        int[] arrayOfInt4 = new int[1];
        OS.gdk_drawable_get_size(i2, arrayOfInt3, arrayOfInt4);
        i3 = arrayOfInt3[0];
        i4 = arrayOfInt4[0];
      }
      int i5 = Cairo.cairo_xlib_surface_create(j, m, k, i3, i4);
      if (i5 == 0) {
        SWT.error(2);
      }
      Cairo.cairo_surface_set_device_offset(i5, n, i1);
      this.data.cairo = (i = Cairo.cairo_create(i5));
      Cairo.cairo_surface_destroy(i5);
    }
    else
    {
      this.data.cairo = (i = OS.gdk_cairo_create(this.data.drawable));
    }
    if (i == 0) {
      SWT.error(2);
    }
    this.data.disposeCairo = true;
    Cairo.cairo_set_fill_rule(i, 1);
    this.data.state &= 0xFD80;
    setCairoClip(this.data.damageRgn, this.data.clipRgn);
  }
  
  void computeStringSize()
  {
    int[] arrayOfInt1 = new int[1];
    int[] arrayOfInt2 = new int[1];
    OS.pango_layout_get_pixel_size(this.data.layout, arrayOfInt1, arrayOfInt2);
    this.data.stringHeight = arrayOfInt2[0];
    this.data.stringWidth = arrayOfInt1[0];
  }
  
  public boolean isClipped()
  {
    if (this.handle == 0) {
      SWT.error(44);
    }
    return this.data.clipRgn != 0;
  }
  
  public boolean isDisposed()
  {
    return this.handle == 0;
  }
  
  boolean isIdentity(double[] paramArrayOfDouble)
  {
    if (paramArrayOfDouble == null) {
      return true;
    }
    return (paramArrayOfDouble[0] == 1.0D) && (paramArrayOfDouble[1] == 0.0D) && (paramArrayOfDouble[2] == 0.0D) && (paramArrayOfDouble[3] == 1.0D) && (paramArrayOfDouble[4] == 0.0D) && (paramArrayOfDouble[5] == 0.0D);
  }
  
  public void setAdvanced(boolean paramBoolean)
  {
    if (this.handle == 0) {
      SWT.error(44);
    }
    if (((this.data.style & 0x8000000) != 0) || (OS.USE_CAIRO) || (OS.INIT_CAIRO))
    {
      if (!paramBoolean)
      {
        setAlpha(255);
        setAntialias(-1);
        setBackgroundPattern(null);
        setClipping(0);
        setForegroundPattern(null);
        setInterpolation(-1);
        setTextAntialias(-1);
        setTransform(null);
      }
      return;
    }
    if ((paramBoolean) && (this.data.cairo != 0)) {
      return;
    }
    if (paramBoolean)
    {
      try
      {
        initCairo();
      }
      catch (SWTException localSWTException) {}
    }
    else
    {
      if (!this.data.disposeCairo) {
        return;
      }
      int i = this.data.cairo;
      if (i != 0) {
        Cairo.cairo_destroy(i);
      }
      this.data.cairo = 0;
      this.data.interpolation = -1;
      this.data.alpha = 255;
      this.data.backgroundPattern = (this.data.foregroundPattern = null);
      this.data.state = 0;
      setClipping(0);
    }
  }
  
  public void setAlpha(int paramInt)
  {
    if (this.handle == 0) {
      SWT.error(44);
    }
    if ((this.data.cairo == 0) && ((paramInt & 0xFF) == 255)) {
      return;
    }
    initCairo();
    this.data.alpha = (paramInt & 0xFF);
    this.data.state &= 0xFEFC;
  }
  
  public void setAntialias(int paramInt)
  {
    if (this.handle == 0) {
      SWT.error(44);
    }
    if ((this.data.cairo == 0) && (paramInt == -1)) {
      return;
    }
    int i = 0;
    switch (paramInt)
    {
    case -1: 
      i = 0;
      break;
    case 0: 
      i = 1;
      break;
    case 1: 
      i = 2;
      break;
    default: 
      SWT.error(5);
    }
    initCairo();
    int j = this.data.cairo;
    Cairo.cairo_set_antialias(j, i);
  }
  
  public void setBackground(Color paramColor)
  {
    if (this.handle == 0) {
      SWT.error(44);
    }
    if (paramColor == null) {
      SWT.error(4);
    }
    if (paramColor.isDisposed()) {
      SWT.error(5);
    }
    this.data.background = paramColor.handle;
    this.data.backgroundPattern = null;
    this.data.state &= 0xFEFD;
  }
  
  public void setBackgroundPattern(Pattern paramPattern)
  {
    if (this.handle == 0) {
      SWT.error(44);
    }
    if ((paramPattern != null) && (paramPattern.isDisposed())) {
      SWT.error(5);
    }
    if ((this.data.cairo == 0) && (paramPattern == null)) {
      return;
    }
    initCairo();
    if (this.data.backgroundPattern == paramPattern) {
      return;
    }
    this.data.backgroundPattern = paramPattern;
    this.data.state &= 0xFFFFFFFD;
  }
  
  static void setCairoFont(int paramInt, Font paramFont)
  {
    if ((paramFont == null) || (paramFont.isDisposed())) {
      return;
    }
    setCairoFont(paramInt, paramFont.handle);
  }
  
  static void setCairoFont(int paramInt1, int paramInt2)
  {
    int i = OS.pango_font_description_get_family(paramInt2);
    int j = OS.strlen(i);
    byte[] arrayOfByte = new byte[j + 1];
    OS.memmove(arrayOfByte, i, j);
    double d = OS.PANGO_PIXELS(OS.pango_font_description_get_size(paramInt2)) * 96 / 72;
    int k = OS.pango_font_description_get_style(paramInt2);
    int m = OS.pango_font_description_get_weight(paramInt2);
    int n = 0;
    if (k == 2) {
      n = 1;
    }
    if (k == 1) {
      n = 2;
    }
    int i1 = 0;
    if (m == 700) {
      i1 = 1;
    }
    Cairo.cairo_select_font_face(paramInt1, arrayOfByte, n, i1);
    Cairo.cairo_set_font_size(paramInt1, d);
  }
  
  static void setCairoRegion(int paramInt1, int paramInt2)
  {
    OS.gdk_cairo_region(paramInt1, paramInt2);
  }
  
  static void setCairoPatternColor(int paramInt1, int paramInt2, Color paramColor, int paramInt3)
  {
    GdkColor localGdkColor = paramColor.handle;
    double d1 = (paramInt3 & 0xFF) / 255.0D;
    double d2 = (localGdkColor.red & 0xFFFF) / 65535.0D;
    double d3 = (localGdkColor.green & 0xFFFF) / 65535.0D;
    double d4 = (localGdkColor.blue & 0xFFFF) / 65535.0D;
    Cairo.cairo_pattern_add_color_stop_rgba(paramInt1, paramInt2, d2, d3, d4, d1);
  }
  
  void setCairoClip(int paramInt1, int paramInt2)
  {
    int i = this.data.cairo;
    if ((OS.GTK_VERSION >= OS.VERSION(2, 18, 0)) && (this.data.drawable != 0) && (!OS.GTK3)) {
      OS.gdk_cairo_reset_clip(i, this.data.drawable);
    } else {
      Cairo.cairo_reset_clip(i);
    }
    if (paramInt1 != 0)
    {
      double[] arrayOfDouble1 = new double[6];
      Cairo.cairo_get_matrix(i, arrayOfDouble1);
      double[] arrayOfDouble2 = new double[6];
      Cairo.cairo_matrix_init_identity(arrayOfDouble2);
      Cairo.cairo_set_matrix(i, arrayOfDouble2);
      setCairoRegion(i, paramInt1);
      Cairo.cairo_clip(i);
      Cairo.cairo_set_matrix(i, arrayOfDouble1);
    }
    if (paramInt2 != 0)
    {
      setCairoRegion(i, paramInt2);
      Cairo.cairo_clip(i);
    }
  }
  
  void setClipping(int paramInt)
  {
    int i = this.data.cairo;
    int j;
    if (paramInt == 0)
    {
      if (this.data.clipRgn != 0)
      {
        OS.gdk_region_destroy(this.data.clipRgn);
        this.data.clipRgn = 0;
      }
      if (i != 0)
      {
        this.data.clippingTransform = null;
        setCairoClip(this.data.damageRgn, 0);
      }
      else
      {
        j = this.data.damageRgn != 0 ? this.data.damageRgn : 0;
        OS.gdk_gc_set_clip_region(this.handle, j);
      }
    }
    else
    {
      if (this.data.clipRgn == 0) {
        this.data.clipRgn = OS.gdk_region_new();
      }
      OS.gdk_region_subtract(this.data.clipRgn, this.data.clipRgn);
      OS.gdk_region_union(this.data.clipRgn, paramInt);
      if (i != 0)
      {
        if (this.data.clippingTransform == null) {
          this.data.clippingTransform = new double[6];
        }
        Cairo.cairo_get_matrix(i, this.data.clippingTransform);
        setCairoClip(this.data.damageRgn, paramInt);
      }
      else
      {
        j = paramInt;
        if (this.data.damageRgn != 0)
        {
          j = OS.gdk_region_new();
          OS.gdk_region_union(j, paramInt);
          OS.gdk_region_intersect(j, this.data.damageRgn);
        }
        OS.gdk_gc_set_clip_region(this.handle, j);
        if (j != paramInt) {
          OS.gdk_region_destroy(j);
        }
      }
    }
  }
  
  public void setClipping(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    if (this.handle == 0) {
      SWT.error(44);
    }
    if (paramInt3 < 0)
    {
      paramInt1 += paramInt3;
      paramInt3 = -paramInt3;
    }
    if (paramInt4 < 0)
    {
      paramInt2 += paramInt4;
      paramInt4 = -paramInt4;
    }
    GdkRectangle localGdkRectangle = new GdkRectangle();
    localGdkRectangle.x = paramInt1;
    localGdkRectangle.y = paramInt2;
    localGdkRectangle.width = paramInt3;
    localGdkRectangle.height = paramInt4;
    int i = OS.gdk_region_new();
    OS.gdk_region_union_with_rect(i, localGdkRectangle);
    setClipping(i);
    OS.gdk_region_destroy(i);
  }
  
  public void setClipping(Path paramPath)
  {
    if (this.handle == 0) {
      SWT.error(44);
    }
    if ((paramPath != null) && (paramPath.isDisposed())) {
      SWT.error(44);
    }
    setClipping(0);
    if (paramPath != null)
    {
      initCairo();
      int i = this.data.cairo;
      int j = Cairo.cairo_copy_path(paramPath.handle);
      if (j == 0) {
        SWT.error(2);
      }
      Cairo.cairo_append_path(i, j);
      Cairo.cairo_path_destroy(j);
      Cairo.cairo_clip(i);
    }
  }
  
  public void setClipping(Rectangle paramRectangle)
  {
    if (this.handle == 0) {
      SWT.error(44);
    }
    if (paramRectangle == null) {
      setClipping(0);
    } else {
      setClipping(paramRectangle.x, paramRectangle.y, paramRectangle.width, paramRectangle.height);
    }
  }
  
  public void setClipping(Region paramRegion)
  {
    if (this.handle == 0) {
      SWT.error(44);
    }
    if ((paramRegion != null) && (paramRegion.isDisposed())) {
      SWT.error(5);
    }
    setClipping(paramRegion != null ? paramRegion.handle : 0);
  }
  
  public void setFont(Font paramFont)
  {
    if (this.handle == 0) {
      SWT.error(44);
    }
    if ((paramFont != null) && (paramFont.isDisposed())) {
      SWT.error(5);
    }
    this.data.font = (paramFont != null ? paramFont : this.data.device.systemFont);
    this.data.state &= 0xFFFFFFFB;
    this.data.stringWidth = (this.data.stringHeight = -1);
  }
  
  public void setFillRule(int paramInt)
  {
    if (this.handle == 0) {
      SWT.error(44);
    }
    int i = 1;
    switch (paramInt)
    {
    case 2: 
      i = 0;
      break;
    case 1: 
      i = 1;
      break;
    default: 
      SWT.error(5);
    }
    initCairo();
    int j = this.data.cairo;
    if (j != 0) {
      Cairo.cairo_set_fill_rule(j, i);
    }
  }
  
  public void setForeground(Color paramColor)
  {
    if (this.handle == 0) {
      SWT.error(44);
    }
    if (paramColor == null) {
      SWT.error(4);
    }
    if (paramColor.isDisposed()) {
      SWT.error(5);
    }
    this.data.foreground = paramColor.handle;
    this.data.foregroundPattern = null;
    this.data.state &= 0xFFFFFFFE;
  }
  
  public void setForegroundPattern(Pattern paramPattern)
  {
    if (this.handle == 0) {
      SWT.error(44);
    }
    if ((paramPattern != null) && (paramPattern.isDisposed())) {
      SWT.error(5);
    }
    if ((this.data.cairo == 0) && (paramPattern == null)) {
      return;
    }
    initCairo();
    if (this.data.foregroundPattern == paramPattern) {
      return;
    }
    this.data.foregroundPattern = paramPattern;
    this.data.state &= 0xFFFFFFFE;
  }
  
  public void setInterpolation(int paramInt)
  {
    if (this.handle == 0) {
      SWT.error(44);
    }
    if ((this.data.cairo == 0) && (paramInt == -1)) {
      return;
    }
    switch (paramInt)
    {
    case -1: 
    case 0: 
    case 1: 
    case 2: 
      break;
    default: 
      SWT.error(5);
    }
    initCairo();
    this.data.interpolation = paramInt;
  }
  
  public void setLineAttributes(LineAttributes paramLineAttributes)
  {
    if (this.handle == 0) {
      SWT.error(44);
    }
    if (paramLineAttributes == null) {
      SWT.error(4);
    }
    int i = 0;
    float f1 = paramLineAttributes.width;
    if (f1 != this.data.lineWidth) {
      i |= 0x240;
    }
    int j = paramLineAttributes.style;
    if (j != this.data.lineStyle)
    {
      i |= 0x8;
      switch (j)
      {
      case 1: 
      case 2: 
      case 3: 
      case 4: 
      case 5: 
        break;
      case 6: 
        if (paramLineAttributes.dash == null) {
          j = 1;
        }
        break;
      default: 
        SWT.error(5);
      }
    }
    int k = paramLineAttributes.join;
    if (k != this.data.lineJoin)
    {
      i |= 0x20;
      switch (k)
      {
      case 1: 
      case 2: 
      case 3: 
        break;
      default: 
        SWT.error(5);
      }
    }
    int m = paramLineAttributes.cap;
    if (m != this.data.lineCap)
    {
      i |= 0x10;
      switch (m)
      {
      case 1: 
      case 2: 
      case 3: 
        break;
      default: 
        SWT.error(5);
      }
    }
    Object localObject = paramLineAttributes.dash;
    float[] arrayOfFloat1 = this.data.lineDashes;
    if ((localObject != null) && (localObject.length > 0))
    {
      int n = (arrayOfFloat1 == null) || (arrayOfFloat1.length != localObject.length) ? 1 : 0;
      for (int i1 = 0; i1 < localObject.length; i1++)
      {
        float f4 = localObject[i1];
        if (f4 <= 0.0F) {
          SWT.error(5);
        }
        if ((n == 0) && (arrayOfFloat1[i1] != f4)) {
          n = 1;
        }
      }
      if (n != 0)
      {
        float[] arrayOfFloat2 = new float[localObject.length];
        System.arraycopy(localObject, 0, arrayOfFloat2, 0, localObject.length);
        localObject = arrayOfFloat2;
        i |= 0x8;
      }
      else
      {
        localObject = arrayOfFloat1;
      }
    }
    else if ((arrayOfFloat1 != null) && (arrayOfFloat1.length > 0))
    {
      i |= 0x8;
    }
    else
    {
      localObject = arrayOfFloat1;
    }
    float f2 = paramLineAttributes.dashOffset;
    if (f2 != this.data.lineDashesOffset) {
      i |= 0x8;
    }
    float f3 = paramLineAttributes.miterLimit;
    if (f3 != this.data.lineMiterLimit) {
      i |= 0x80;
    }
    initCairo();
    if (i == 0) {
      return;
    }
    this.data.lineWidth = f1;
    this.data.lineStyle = j;
    this.data.lineCap = m;
    this.data.lineJoin = k;
    this.data.lineDashes = ((float[])localObject);
    this.data.lineDashesOffset = f2;
    this.data.lineMiterLimit = f3;
    this.data.state &= (i ^ 0xFFFFFFFF);
  }
  
  public void setLineCap(int paramInt)
  {
    if (this.handle == 0) {
      SWT.error(44);
    }
    if (this.data.lineCap == paramInt) {
      return;
    }
    switch (paramInt)
    {
    case 1: 
    case 2: 
    case 3: 
      break;
    default: 
      SWT.error(5);
    }
    this.data.lineCap = paramInt;
    this.data.state &= 0xFFFFFFEF;
  }
  
  public void setLineDash(int[] paramArrayOfInt)
  {
    if (this.handle == 0) {
      SWT.error(44);
    }
    float[] arrayOfFloat = this.data.lineDashes;
    if ((paramArrayOfInt != null) && (paramArrayOfInt.length > 0))
    {
      int i = (this.data.lineStyle != 6) || (arrayOfFloat == null) || (arrayOfFloat.length != paramArrayOfInt.length) ? 1 : 0;
      for (int j = 0; j < paramArrayOfInt.length; j++)
      {
        int k = paramArrayOfInt[j];
        if (k <= 0) {
          SWT.error(5);
        }
        if ((i == 0) && (arrayOfFloat[j] != k)) {
          i = 1;
        }
      }
      if (i == 0) {
        return;
      }
      this.data.lineDashes = new float[paramArrayOfInt.length];
      for (j = 0; j < paramArrayOfInt.length; j++) {
        this.data.lineDashes[j] = paramArrayOfInt[j];
      }
      this.data.lineStyle = 6;
    }
    else
    {
      if ((this.data.lineStyle == 1) && ((arrayOfFloat == null) || (arrayOfFloat.length == 0))) {
        return;
      }
      this.data.lineDashes = null;
      this.data.lineStyle = 1;
    }
    this.data.state &= 0xFFFFFFF7;
  }
  
  public void setLineJoin(int paramInt)
  {
    if (this.handle == 0) {
      SWT.error(44);
    }
    if (this.data.lineJoin == paramInt) {
      return;
    }
    switch (paramInt)
    {
    case 1: 
    case 2: 
    case 3: 
      break;
    default: 
      SWT.error(5);
    }
    this.data.lineJoin = paramInt;
    this.data.state &= 0xFFFFFFDF;
  }
  
  public void setLineStyle(int paramInt)
  {
    if (this.handle == 0) {
      SWT.error(44);
    }
    if (this.data.lineStyle == paramInt) {
      return;
    }
    switch (paramInt)
    {
    case 1: 
    case 2: 
    case 3: 
    case 4: 
    case 5: 
      break;
    case 6: 
      if (this.data.lineDashes == null) {
        paramInt = 1;
      }
      break;
    default: 
      SWT.error(5);
    }
    this.data.lineStyle = paramInt;
    this.data.state &= 0xFFFFFFF7;
  }
  
  public void setLineWidth(int paramInt)
  {
    if (this.handle == 0) {
      SWT.error(44);
    }
    if (this.data.lineWidth == paramInt) {
      return;
    }
    this.data.lineWidth = paramInt;
    this.data.state &= 0xFDBF;
  }
  
  void setString(String paramString, int paramInt)
  {
    if (this.data.layout == 0) {
      createLayout();
    }
    if ((paramString == this.data.string) && ((paramInt & 0xFFFFFFFE) == (this.data.drawFlags & 0xFFFFFFFE))) {
      return;
    }
    int j = paramString.length();
    int k = this.data.layout;
    char[] arrayOfChar1 = new char[j];
    paramString.getChars(0, j, arrayOfChar1, 0);
    int i;
    byte[] arrayOfByte1;
    if (((paramInt & 0x8) != 0) && ((i = fixMnemonic(arrayOfChar1)) != -1))
    {
      char[] arrayOfChar2 = new char[i - 1];
      System.arraycopy(arrayOfChar1, 0, arrayOfChar2, 0, arrayOfChar2.length);
      byte[] arrayOfByte2 = Converter.wcsToMbcs(null, arrayOfChar2, false);
      char[] arrayOfChar3 = new char[arrayOfChar1.length - i];
      System.arraycopy(arrayOfChar1, i - 1, arrayOfChar3, 0, arrayOfChar3.length);
      byte[] arrayOfByte3 = Converter.wcsToMbcs(null, arrayOfChar3, false);
      arrayOfByte1 = new byte[arrayOfByte2.length + arrayOfByte3.length];
      System.arraycopy(arrayOfByte2, 0, arrayOfByte1, 0, arrayOfByte2.length);
      System.arraycopy(arrayOfByte3, 0, arrayOfByte1, arrayOfByte2.length, arrayOfByte3.length);
      int m = OS.pango_attr_list_new();
      int n = OS.pango_attr_underline_new(3);
      PangoAttribute localPangoAttribute = new PangoAttribute();
      OS.memmove(localPangoAttribute, n, PangoAttribute.sizeof);
      localPangoAttribute.start_index = arrayOfByte2.length;
      localPangoAttribute.end_index = (arrayOfByte2.length + 1);
      OS.memmove(n, localPangoAttribute, PangoAttribute.sizeof);
      OS.pango_attr_list_insert(m, n);
      OS.pango_layout_set_attributes(k, m);
      OS.pango_attr_list_unref(m);
    }
    else
    {
      arrayOfByte1 = Converter.wcsToMbcs(null, arrayOfChar1, false);
      OS.pango_layout_set_attributes(k, 0);
    }
    OS.pango_layout_set_text(k, arrayOfByte1, arrayOfByte1.length);
    OS.pango_layout_set_single_paragraph_mode(k, (paramInt & 0x2) == 0);
    OS.pango_layout_set_tabs(k, (paramInt & 0x4) != 0 ? 0 : this.data.device.emptyTab);
    this.data.string = paramString;
    this.data.stringWidth = (this.data.stringHeight = -1);
    this.data.drawFlags = paramInt;
  }
  
  public void setTextAntialias(int paramInt)
  {
    if (this.handle == 0) {
      SWT.error(44);
    }
    if ((this.data.cairo == 0) && (paramInt == -1)) {
      return;
    }
    int i = 0;
    switch (paramInt)
    {
    case -1: 
      i = 0;
      break;
    case 0: 
      i = 1;
      break;
    case 1: 
      i = 2;
      break;
    default: 
      SWT.error(5);
    }
    initCairo();
    int j = Cairo.cairo_font_options_create();
    Cairo.cairo_font_options_set_antialias(j, i);
    if (this.data.context == 0) {
      createLayout();
    }
    OS.pango_cairo_context_set_font_options(this.data.context, j);
    Cairo.cairo_font_options_destroy(j);
  }
  
  public void setTransform(Transform paramTransform)
  {
    if (this.handle == 0) {
      SWT.error(44);
    }
    if ((paramTransform != null) && (paramTransform.isDisposed())) {
      SWT.error(5);
    }
    if ((this.data.cairo == 0) && (paramTransform == null)) {
      return;
    }
    initCairo();
    int i = this.data.cairo;
    double[] arrayOfDouble = identity();
    if (paramTransform != null) {
      Cairo.cairo_matrix_multiply(arrayOfDouble, paramTransform.handle, arrayOfDouble);
    }
    Cairo.cairo_set_matrix(i, arrayOfDouble);
    this.data.state &= 0xFDFF;
  }
  
  @Deprecated
  public void setXORMode(boolean paramBoolean)
  {
    if (this.handle == 0) {
      SWT.error(44);
    }
    int i = this.data.cairo;
    if ((i != 0) && (Cairo.cairo_version() >= Cairo.CAIRO_VERSION_ENCODE(1, 10, 0))) {
      Cairo.cairo_set_operator(this.handle, paramBoolean ? 23 : 2);
    }
    if (!OS.USE_CAIRO) {
      OS.gdk_gc_set_function(this.handle, paramBoolean ? 2 : 0);
    }
    this.data.xorMode = paramBoolean;
  }
  
  public Point stringExtent(String paramString)
  {
    return textExtent(paramString, 0);
  }
  
  public Point textExtent(String paramString)
  {
    return textExtent(paramString, 6);
  }
  
  public Point textExtent(String paramString, int paramInt)
  {
    if (this.handle == 0) {
      SWT.error(44);
    }
    if (paramString == null) {
      SWT.error(4);
    }
    setString(paramString, paramInt);
    checkGC(4);
    if (this.data.stringWidth == -1) {
      computeStringSize();
    }
    return new Point(this.data.stringWidth, this.data.stringHeight);
  }
  
  public String toString()
  {
    if (isDisposed()) {
      return "GC {*DISPOSED*}";
    }
    return "GC {" + this.handle + "}";
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/graphics/GC.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */