package org.eclipse.swt.internal.mozilla;

public class nsIAuthInformation
  extends nsISupports
{
  static final int LAST_METHOD_ID = nsISupports.LAST_METHOD_ID + 9;
  static final String NS_IAUTHINFORMATION_IID_STR = "0d73639c-2a92-4518-9f92-28f71fea5f20";
  public static final int AUTH_HOST = 1;
  public static final int AUTH_PROXY = 2;
  public static final int NEED_DOMAIN = 4;
  public static final int ONLY_PASSWORD = 8;
  
  public nsIAuthInformation(int paramInt)
  {
    super(paramInt);
  }
  
  public int GetRealm(int paramInt)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 2, getAddress(), paramInt);
  }
  
  public int GetUsername(int paramInt)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 4, getAddress(), paramInt);
  }
  
  public int SetUsername(int paramInt)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 5, getAddress(), paramInt);
  }
  
  public int GetPassword(int paramInt)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 6, getAddress(), paramInt);
  }
  
  public int SetPassword(int paramInt)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 7, getAddress(), paramInt);
  }
  
  static
  {
    IIDStore.RegisterIID(nsIAuthInformation.class, 0, new nsID("0d73639c-2a92-4518-9f92-28f71fea5f20"));
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/internal/mozilla/nsIAuthInformation.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */