package org.eclipse.swt.internal.gtk;

public class GdkGeometry
{
  public int min_width;
  public int min_height;
  public int max_width;
  public int max_height;
  public int base_width;
  public int base_height;
  public int width_inc;
  public int height_inc;
  public double min_aspect;
  public double max_aspect;
  public int win_gravity;
  public static final int sizeof = ;
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/internal/gtk/GdkGeometry.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */