package org.eclipse.swt.custom;

import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Layout;

class CTabFolderLayout
  extends Layout
{
  protected Point computeSize(Composite paramComposite, int paramInt1, int paramInt2, boolean paramBoolean)
  {
    CTabFolder localCTabFolder = (CTabFolder)paramComposite;
    CTabItem[] arrayOfCTabItem = localCTabFolder.items;
    CTabFolderRenderer localCTabFolderRenderer = localCTabFolder.renderer;
    int i = 0;
    int j = localCTabFolder.selectedIndex;
    if (j == -1) {
      j = 0;
    }
    GC localGC = new GC(localCTabFolder);
    for (int k = 0; k < arrayOfCTabItem.length; k++) {
      if (localCTabFolder.single)
      {
        i = Math.max(i, localCTabFolderRenderer.computeSize(k, 2, localGC, -1, -1).x);
      }
      else
      {
        m = 0;
        if (k == j) {
          m |= 0x2;
        }
        i += localCTabFolderRenderer.computeSize(k, m, localGC, -1, -1).x;
      }
    }
    k = 0;
    int m = 0;
    int n = 0;
    int i1 = 0;
    Object localObject;
    if (paramInt1 == -1)
    {
      for (int i2 = 0; i2 < localCTabFolder.controls.length; i2++)
      {
        localObject = localCTabFolder.controls[i2];
        if ((!((Control)localObject).isDisposed()) && (((Control)localObject).getVisible()))
        {
          if ((localCTabFolder.controlAlignments[i2] & 0x4000) != 0) {
            n = 1;
          } else {
            i1 = 1;
          }
          k += ((Control)localObject).computeSize(-1, -1).x;
        }
      }
    }
    else
    {
      Point localPoint1 = new Point(paramInt1, paramInt2);
      localObject = new boolean[1][];
      Rectangle[] arrayOfRectangle = localCTabFolder.computeControlBounds(localPoint1, (boolean[][])localObject);
      int i6 = Integer.MAX_VALUE;
      int i8 = 0;
      for (int i9 = 0; i9 < arrayOfRectangle.length; i9++) {
        if (localObject[0][i9] != 0)
        {
          i6 = Math.min(i6, arrayOfRectangle[i9].y);
          i8 = Math.max(i8, arrayOfRectangle[i9].y + arrayOfRectangle[i9].height);
          m = i8 - i6;
        }
        else
        {
          if ((localCTabFolder.controlAlignments[i9] & 0x4000) != 0) {
            n = 1;
          } else {
            i1 = 1;
          }
          k += arrayOfRectangle[i9].width;
        }
      }
    }
    if (n != 0) {
      k += 6;
    }
    if (i1 != 0) {
      k += 6;
    }
    i += k;
    localGC.dispose();
    int i3 = 0;
    int i4 = 0;
    for (int i5 = 0; i5 < arrayOfCTabItem.length; i5++)
    {
      Control localControl = arrayOfCTabItem[i5].control;
      if ((localControl != null) && (!localControl.isDisposed()))
      {
        Point localPoint2 = localControl.computeSize(paramInt1, paramInt2, paramBoolean);
        i3 = Math.max(i3, localPoint2.x);
        i4 = Math.max(i4, localPoint2.y);
      }
    }
    i5 = Math.max(i, i3 + localCTabFolder.marginWidth);
    int i7 = localCTabFolder.minimized ? 0 : i4 + m;
    if (i5 == 0) {
      i5 = 64;
    }
    if (i7 == 0) {
      i7 = 64;
    }
    if (paramInt1 != -1) {
      i5 = paramInt1;
    }
    if (paramInt2 != -1) {
      i7 = paramInt2;
    }
    return new Point(i5, i7);
  }
  
  protected boolean flushCache(Control paramControl)
  {
    return true;
  }
  
  protected void layout(Composite paramComposite, boolean paramBoolean)
  {
    CTabFolder localCTabFolder = (CTabFolder)paramComposite;
    if (localCTabFolder.selectedIndex != -1)
    {
      Control localControl = localCTabFolder.items[localCTabFolder.selectedIndex].control;
      if ((localControl != null) && (!localControl.isDisposed())) {
        localControl.setBounds(localCTabFolder.getClientArea());
      }
    }
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/custom/CTabFolderLayout.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */