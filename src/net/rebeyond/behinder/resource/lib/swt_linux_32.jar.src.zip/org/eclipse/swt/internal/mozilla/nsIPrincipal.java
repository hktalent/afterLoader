package org.eclipse.swt.internal.mozilla;

public class nsIPrincipal
  extends nsISerializable
{
  static final int LAST_METHOD_ID = nsISerializable.LAST_METHOD_ID + (IsXULRunner10() ? 26 : IsXULRunner24() ? 21 : 23);
  static final String NS_IPRINCIPAL_IID_STR = "b8268b9a-2403-44ed-81e3-614075c92034";
  static final String NS_IPRINCIPAL_10_IID_STR = "b406a2db-e547-4c95-b8e2-ad09ecb54ce0";
  static final String NS_IPRINCIPAL_24_IID_STR = "dbda8bb0-3023-4aec-ad98-8e9931a29d70";
  public static final int ENABLE_DENIED = 1;
  public static final int ENABLE_UNKNOWN = 2;
  public static final int ENABLE_WITH_USER_PERMISSION = 3;
  public static final int ENABLE_GRANTED = 4;
  
  public nsIPrincipal(int paramInt)
  {
    super(paramInt);
  }
  
  public int GetJSPrincipals(int paramInt, int[] paramArrayOfInt)
  {
    if (IsXULRunner24()) {
      return 1;
    }
    return XPCOM.VtblCall(nsISerializable.LAST_METHOD_ID + (IsXULRunner10() ? 5 : 4), getAddress(), paramInt, paramArrayOfInt);
  }
  
  static
  {
    IIDStore.RegisterIID(nsIPrincipal.class, 0, new nsID("b8268b9a-2403-44ed-81e3-614075c92034"));
    IIDStore.RegisterIID(nsIPrincipal.class, 5, new nsID("b406a2db-e547-4c95-b8e2-ad09ecb54ce0"));
    IIDStore.RegisterIID(nsIPrincipal.class, 6, new nsID("dbda8bb0-3023-4aec-ad98-8e9931a29d70"));
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/internal/mozilla/nsIPrincipal.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */