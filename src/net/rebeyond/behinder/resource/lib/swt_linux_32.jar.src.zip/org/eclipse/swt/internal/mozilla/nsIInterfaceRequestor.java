package org.eclipse.swt.internal.mozilla;

public class nsIInterfaceRequestor
  extends nsISupports
{
  static final int LAST_METHOD_ID = nsISupports.LAST_METHOD_ID + 1;
  static final String NS_IINTERFACEREQUESTOR_IID_STR = "033a1470-8b2a-11d3-af88-00a024ffc08c";
  
  public nsIInterfaceRequestor(int paramInt)
  {
    super(paramInt);
  }
  
  public int GetInterface(nsID paramnsID, int[] paramArrayOfInt)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 1, getAddress(), paramnsID, paramArrayOfInt);
  }
  
  static
  {
    IIDStore.RegisterIID(nsIInterfaceRequestor.class, 0, new nsID("033a1470-8b2a-11d3-af88-00a024ffc08c"));
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/internal/mozilla/nsIInterfaceRequestor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */