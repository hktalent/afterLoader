package org.eclipse.swt.dnd;

import org.eclipse.swt.internal.gtk.OS;

public abstract class ByteArrayTransfer
  extends Transfer
{
  public TransferData[] getSupportedTypes()
  {
    int[] arrayOfInt = getTypeIds();
    TransferData[] arrayOfTransferData = new TransferData[arrayOfInt.length];
    for (int i = 0; i < arrayOfInt.length; i++)
    {
      arrayOfTransferData[i] = new TransferData();
      arrayOfTransferData[i].type = arrayOfInt[i];
    }
    return arrayOfTransferData;
  }
  
  public boolean isSupportedType(TransferData paramTransferData)
  {
    if (paramTransferData == null) {
      return false;
    }
    int[] arrayOfInt = getTypeIds();
    for (int i = 0; i < arrayOfInt.length; i++) {
      if (paramTransferData.type == arrayOfInt[i]) {
        return true;
      }
    }
    return false;
  }
  
  protected void javaToNative(Object paramObject, TransferData paramTransferData)
  {
    paramTransferData.result = 0;
    if ((!checkByteArray(paramObject)) || (!isSupportedType(paramTransferData))) {
      DND.error(2003);
    }
    byte[] arrayOfByte = (byte[])paramObject;
    if (arrayOfByte.length == 0) {
      return;
    }
    int i = OS.g_malloc(arrayOfByte.length);
    if (i == 0) {
      return;
    }
    OS.memmove(i, arrayOfByte, arrayOfByte.length);
    paramTransferData.length = arrayOfByte.length;
    paramTransferData.format = 8;
    paramTransferData.pValue = i;
    paramTransferData.result = 1;
  }
  
  protected Object nativeToJava(TransferData paramTransferData)
  {
    if ((!isSupportedType(paramTransferData)) || (paramTransferData.pValue == 0)) {
      return null;
    }
    int i = paramTransferData.format * paramTransferData.length / 8;
    if (i == 0) {
      return null;
    }
    byte[] arrayOfByte = new byte[i];
    OS.memmove(arrayOfByte, paramTransferData.pValue, i);
    return arrayOfByte;
  }
  
  boolean checkByteArray(Object paramObject)
  {
    return (paramObject != null) && ((paramObject instanceof byte[])) && (((byte[])paramObject).length > 0);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/dnd/ByteArrayTransfer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */