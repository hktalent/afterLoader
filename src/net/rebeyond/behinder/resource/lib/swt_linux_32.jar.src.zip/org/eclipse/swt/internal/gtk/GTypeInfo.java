package org.eclipse.swt.internal.gtk;

public class GTypeInfo
{
  public short class_size;
  public int base_init;
  public int base_finalize;
  public int class_init;
  public int class_finalize;
  public int class_data;
  public short instance_size;
  public short n_preallocs;
  public int instance_init;
  public int value_table;
  public static final int sizeof = ;
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/internal/gtk/GTypeInfo.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */