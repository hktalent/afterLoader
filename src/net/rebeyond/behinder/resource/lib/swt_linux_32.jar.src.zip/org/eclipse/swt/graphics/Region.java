package org.eclipse.swt.graphics;

import org.eclipse.swt.SWT;
import org.eclipse.swt.internal.cairo.Cairo;
import org.eclipse.swt.internal.gtk.GdkRectangle;
import org.eclipse.swt.internal.gtk.OS;

public final class Region
  extends Resource
{
  public int handle;
  
  public Region()
  {
    this(null);
  }
  
  public Region(Device paramDevice)
  {
    super(paramDevice);
    this.handle = OS.gdk_region_new();
    if (this.handle == 0) {
      SWT.error(2);
    }
    init();
  }
  
  Region(Device paramDevice, int paramInt)
  {
    super(paramDevice);
    this.handle = paramInt;
  }
  
  static int gdk_region_polygon(int[] paramArrayOfInt, int paramInt1, int paramInt2)
  {
    if (!OS.GTK3) {
      return OS.gdk_region_polygon(paramArrayOfInt, paramInt1, paramInt2);
    }
    int i = paramArrayOfInt[0];
    int j = i;
    int k = paramArrayOfInt[1];
    int m = k;
    int n = paramInt1 * 2;
    for (int i1 = 2; i1 < n; i1 += 2)
    {
      i2 = paramArrayOfInt[i1];
      i3 = paramArrayOfInt[(i1 + 1)];
      if (i2 < i) {
        i = i2;
      }
      if (i2 > j) {
        j = i2;
      }
      if (i3 < k) {
        k = i3;
      }
      if (i3 > m) {
        m = i3;
      }
    }
    i1 = Cairo.cairo_image_surface_create(0, j - i, m - k);
    if (i1 == 0) {
      SWT.error(2);
    }
    int i2 = Cairo.cairo_create(i1);
    if (i2 == 0) {
      SWT.error(2);
    }
    Cairo.cairo_move_to(i2, paramArrayOfInt[0] - i, paramArrayOfInt[1] - k);
    for (int i3 = 2; i3 < n; i3 += 2) {
      Cairo.cairo_line_to(i2, paramArrayOfInt[i3] - i, paramArrayOfInt[(i3 + 1)] - k);
    }
    Cairo.cairo_close_path(i2);
    Cairo.cairo_set_source_rgb(i2, 1.0D, 1.0D, 1.0D);
    i3 = 0;
    if (paramInt2 == 0) {
      i3 = 1;
    }
    Cairo.cairo_set_fill_rule(i2, i3);
    Cairo.cairo_fill(i2);
    Cairo.cairo_destroy(i2);
    int i4 = OS.gdk_cairo_region_create_from_surface(i1);
    OS.gdk_region_offset(i4, i, k);
    Cairo.cairo_surface_destroy(i1);
    return i4;
  }
  
  static void gdk_region_get_rectangles(int paramInt, int[] paramArrayOfInt1, int[] paramArrayOfInt2)
  {
    if (!OS.GTK3)
    {
      OS.gdk_region_get_rectangles(paramInt, paramArrayOfInt1, paramArrayOfInt2);
      return;
    }
    int i = Cairo.cairo_region_num_rectangles(paramInt);
    if (paramArrayOfInt2 != null) {
      paramArrayOfInt2[0] = i;
    }
    paramArrayOfInt1[0] = OS.g_malloc(GdkRectangle.sizeof * i);
    for (int j = 0; j < i; j++) {
      Cairo.cairo_region_get_rectangle(paramInt, j, paramArrayOfInt1[0] + j * GdkRectangle.sizeof);
    }
  }
  
  public void add(int[] paramArrayOfInt)
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    if (paramArrayOfInt == null) {
      SWT.error(4);
    }
    if (paramArrayOfInt.length < 6) {
      return;
    }
    int i = gdk_region_polygon(paramArrayOfInt, paramArrayOfInt.length / 2, 0);
    OS.gdk_region_union(this.handle, i);
    OS.gdk_region_destroy(i);
  }
  
  public void add(Rectangle paramRectangle)
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    if (paramRectangle == null) {
      SWT.error(4);
    }
    add(paramRectangle.x, paramRectangle.y, paramRectangle.width, paramRectangle.height);
  }
  
  public void add(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    if ((paramInt3 < 0) || (paramInt4 < 0)) {
      SWT.error(5);
    }
    GdkRectangle localGdkRectangle = new GdkRectangle();
    localGdkRectangle.x = paramInt1;
    localGdkRectangle.y = paramInt2;
    localGdkRectangle.width = paramInt3;
    localGdkRectangle.height = paramInt4;
    OS.gdk_region_union_with_rect(this.handle, localGdkRectangle);
  }
  
  public void add(Region paramRegion)
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    if (paramRegion == null) {
      SWT.error(4);
    }
    if (paramRegion.isDisposed()) {
      SWT.error(5);
    }
    OS.gdk_region_union(this.handle, paramRegion.handle);
  }
  
  public boolean contains(int paramInt1, int paramInt2)
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    return OS.gdk_region_point_in(this.handle, paramInt1, paramInt2);
  }
  
  public boolean contains(Point paramPoint)
  {
    if (paramPoint == null) {
      SWT.error(4);
    }
    return contains(paramPoint.x, paramPoint.y);
  }
  
  void destroy()
  {
    OS.gdk_region_destroy(this.handle);
    this.handle = 0;
  }
  
  public boolean equals(Object paramObject)
  {
    if (this == paramObject) {
      return true;
    }
    if (!(paramObject instanceof Region)) {
      return false;
    }
    Region localRegion = (Region)paramObject;
    return this.handle == localRegion.handle;
  }
  
  public Rectangle getBounds()
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    GdkRectangle localGdkRectangle = new GdkRectangle();
    OS.gdk_region_get_clipbox(this.handle, localGdkRectangle);
    return new Rectangle(localGdkRectangle.x, localGdkRectangle.y, localGdkRectangle.width, localGdkRectangle.height);
  }
  
  public static Region gtk_new(Device paramDevice, int paramInt)
  {
    return new Region(paramDevice, paramInt);
  }
  
  public int hashCode()
  {
    return this.handle;
  }
  
  public void intersect(Rectangle paramRectangle)
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    if (paramRectangle == null) {
      SWT.error(4);
    }
    intersect(paramRectangle.x, paramRectangle.y, paramRectangle.width, paramRectangle.height);
  }
  
  public void intersect(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    if ((paramInt3 < 0) || (paramInt4 < 0)) {
      SWT.error(5);
    }
    GdkRectangle localGdkRectangle = new GdkRectangle();
    localGdkRectangle.x = paramInt1;
    localGdkRectangle.y = paramInt2;
    localGdkRectangle.width = paramInt3;
    localGdkRectangle.height = paramInt4;
    int i = OS.gdk_region_rectangle(localGdkRectangle);
    OS.gdk_region_intersect(this.handle, i);
    OS.gdk_region_destroy(i);
  }
  
  public void intersect(Region paramRegion)
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    if (paramRegion == null) {
      SWT.error(4);
    }
    if (paramRegion.isDisposed()) {
      SWT.error(5);
    }
    OS.gdk_region_intersect(this.handle, paramRegion.handle);
  }
  
  public boolean intersects(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    GdkRectangle localGdkRectangle = new GdkRectangle();
    localGdkRectangle.x = paramInt1;
    localGdkRectangle.y = paramInt2;
    localGdkRectangle.width = paramInt3;
    localGdkRectangle.height = paramInt4;
    return OS.gdk_region_rect_in(this.handle, localGdkRectangle) != 1;
  }
  
  public boolean intersects(Rectangle paramRectangle)
  {
    if (paramRectangle == null) {
      SWT.error(4);
    }
    return intersects(paramRectangle.x, paramRectangle.y, paramRectangle.width, paramRectangle.height);
  }
  
  public boolean isDisposed()
  {
    return this.handle == 0;
  }
  
  public boolean isEmpty()
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    return OS.gdk_region_empty(this.handle);
  }
  
  public void subtract(int[] paramArrayOfInt)
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    if (paramArrayOfInt == null) {
      SWT.error(4);
    }
    if (paramArrayOfInt.length < 6) {
      return;
    }
    int i = gdk_region_polygon(paramArrayOfInt, paramArrayOfInt.length / 2, 0);
    OS.gdk_region_subtract(this.handle, i);
    OS.gdk_region_destroy(i);
  }
  
  public void subtract(Rectangle paramRectangle)
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    if (paramRectangle == null) {
      SWT.error(4);
    }
    subtract(paramRectangle.x, paramRectangle.y, paramRectangle.width, paramRectangle.height);
  }
  
  public void subtract(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    if ((paramInt3 < 0) || (paramInt4 < 0)) {
      SWT.error(5);
    }
    GdkRectangle localGdkRectangle = new GdkRectangle();
    localGdkRectangle.x = paramInt1;
    localGdkRectangle.y = paramInt2;
    localGdkRectangle.width = paramInt3;
    localGdkRectangle.height = paramInt4;
    int i = OS.gdk_region_rectangle(localGdkRectangle);
    OS.gdk_region_subtract(this.handle, i);
    OS.gdk_region_destroy(i);
  }
  
  public void subtract(Region paramRegion)
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    if (paramRegion == null) {
      SWT.error(4);
    }
    if (paramRegion.isDisposed()) {
      SWT.error(5);
    }
    OS.gdk_region_subtract(this.handle, paramRegion.handle);
  }
  
  public void translate(int paramInt1, int paramInt2)
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    OS.gdk_region_offset(this.handle, paramInt1, paramInt2);
  }
  
  public void translate(Point paramPoint)
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    if (paramPoint == null) {
      SWT.error(4);
    }
    translate(paramPoint.x, paramPoint.y);
  }
  
  public String toString()
  {
    if (isDisposed()) {
      return "Region {*DISPOSED*}";
    }
    return "Region {" + this.handle + "}";
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/graphics/Region.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */