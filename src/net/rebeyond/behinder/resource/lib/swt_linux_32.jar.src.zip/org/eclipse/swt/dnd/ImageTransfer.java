package org.eclipse.swt.dnd;

import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.ImageData;
import org.eclipse.swt.internal.Converter;
import org.eclipse.swt.internal.ImageList;
import org.eclipse.swt.internal.gtk.OS;
import org.eclipse.swt.widgets.Display;

public class ImageTransfer
  extends ByteArrayTransfer
{
  private static ImageTransfer _instance = new ImageTransfer();
  private static final String JPEG = "image/jpeg";
  private static final int JPEG_ID = registerType("image/jpeg");
  private static final String PNG = "image/png";
  private static final int PNG_ID = registerType("image/png");
  private static final String BMP = "image/bmp";
  private static final int BMP_ID = registerType("image/bmp");
  private static final String EPS = "image/eps";
  private static final int EPS_ID = registerType("image/eps");
  private static final String PCX = "image/pcx";
  private static final int PCX_ID = registerType("image/pcx");
  private static final String PPM = "image/ppm";
  private static final int PPM_ID = registerType("image/ppm");
  private static final String RGB = "image/ppm";
  private static final int RGB_ID = registerType("image/ppm");
  private static final String TGA = "image/tga";
  private static final int TGA_ID = registerType("image/tga");
  private static final String XBM = "image/xbm";
  private static final int XBM_ID = registerType("image/xbm");
  private static final String XPM = "image/xpm";
  private static final int XPM_ID = registerType("image/xpm");
  private static final String XV = "image/xv";
  private static final int XV_ID = registerType("image/xv");
  
  public static ImageTransfer getInstance()
  {
    return _instance;
  }
  
  public void javaToNative(Object paramObject, TransferData paramTransferData)
  {
    if ((!checkImage(paramObject)) || (!isSupportedType(paramTransferData))) {
      DND.error(2003);
    }
    ImageData localImageData = (ImageData)paramObject;
    if (localImageData == null) {
      SWT.error(4);
    }
    Image localImage = new Image(Display.getCurrent(), localImageData);
    int i = ImageList.createPixbuf(localImage);
    if (i != 0)
    {
      String str = "";
      if (paramTransferData.type == JPEG_ID) {
        str = "jpeg";
      } else if (paramTransferData.type == PNG_ID) {
        str = "png";
      } else if (paramTransferData.type == BMP_ID) {
        str = "bmp";
      } else if (paramTransferData.type == EPS_ID) {
        str = "eps";
      } else if (paramTransferData.type == PCX_ID) {
        str = "pcx";
      } else if (paramTransferData.type == PPM_ID) {
        str = "ppm";
      } else if (paramTransferData.type == RGB_ID) {
        str = "rgb";
      } else if (paramTransferData.type == TGA_ID) {
        str = "tga";
      } else if (paramTransferData.type == XBM_ID) {
        str = "xbm";
      } else if (paramTransferData.type == XPM_ID) {
        str = "xpm";
      } else if (paramTransferData.type == XV_ID) {
        str = "xv";
      }
      byte[] arrayOfByte = Converter.wcsToMbcs(null, str, true);
      int[] arrayOfInt1 = new int[1];
      int[] arrayOfInt2 = new int[1];
      if (arrayOfByte == null) {
        return;
      }
      OS.gdk_pixbuf_save_to_bufferv(i, arrayOfInt1, arrayOfInt2, arrayOfByte, null, null, null);
      OS.g_object_unref(i);
      paramTransferData.pValue = arrayOfInt1[0];
      paramTransferData.length = ((arrayOfInt2[0] + 3) / 4 * 4);
      paramTransferData.result = 1;
      paramTransferData.format = 32;
    }
    localImage.dispose();
  }
  
  public Object nativeToJava(TransferData paramTransferData)
  {
    ImageData localImageData = null;
    if (paramTransferData.length > 0)
    {
      int i = OS.gdk_pixbuf_loader_new();
      try
      {
        OS.gdk_pixbuf_loader_write(i, paramTransferData.pValue, paramTransferData.length, null);
        OS.gdk_pixbuf_loader_close(i, null);
        int j = OS.gdk_pixbuf_loader_get_pixbuf(i);
        if (j != 0)
        {
          Image localImage = Image.gtk_new_from_pixbuf(Display.getCurrent(), 0, j);
          localImageData = localImage.getImageData();
          localImage.dispose();
        }
      }
      finally
      {
        OS.g_object_unref(i);
      }
    }
    return localImageData;
  }
  
  protected int[] getTypeIds()
  {
    return new int[] { PNG_ID, BMP_ID, EPS_ID, JPEG_ID, PCX_ID, PPM_ID, RGB_ID, TGA_ID, XBM_ID, XPM_ID, XV_ID };
  }
  
  protected String[] getTypeNames()
  {
    return new String[] { "image/png", "image/bmp", "image/eps", "image/jpeg", "image/pcx", "image/ppm", "image/ppm", "image/tga", "image/xbm", "image/xpm", "image/xv" };
  }
  
  boolean checkImage(Object paramObject)
  {
    return (paramObject != null) && ((paramObject instanceof ImageData));
  }
  
  protected boolean validate(Object paramObject)
  {
    return checkImage(paramObject);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/dnd/ImageTransfer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */