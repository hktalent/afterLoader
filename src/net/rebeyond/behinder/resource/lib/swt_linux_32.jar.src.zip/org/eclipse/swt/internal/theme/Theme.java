package org.eclipse.swt.internal.theme;

import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Device;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.GCData;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.internal.Converter;
import org.eclipse.swt.internal.gtk.OS;

public class Theme
{
  Device device;
  int shellHandle;
  int fixedHandle;
  int buttonHandle;
  int arrowHandle;
  int frameHandle;
  int entryHandle;
  int checkButtonHandle;
  int radioButtonHandle;
  int notebookHandle;
  int treeHandle;
  int progressHandle;
  int toolbarHandle;
  int labelHandle;
  int separatorHandle;
  
  public Theme(Device paramDevice)
  {
    this.device = paramDevice;
    this.shellHandle = OS.gtk_window_new(0);
    this.fixedHandle = OS.gtk_fixed_new();
    this.buttonHandle = OS.gtk_button_new();
    this.arrowHandle = OS.gtk_arrow_new(1, 0);
    this.checkButtonHandle = OS.gtk_check_button_new();
    this.frameHandle = OS.gtk_check_button_new();
    this.entryHandle = OS.gtk_entry_new();
    this.radioButtonHandle = OS.gtk_radio_button_new(0);
    this.notebookHandle = OS.gtk_notebook_new();
    this.progressHandle = OS.gtk_progress_bar_new();
    this.toolbarHandle = OS.gtk_toolbar_new();
    this.treeHandle = OS.gtk_tree_view_new_with_model(0);
    if (OS.GTK3) {
      this.separatorHandle = OS.gtk_separator_new(1);
    } else {
      this.separatorHandle = OS.gtk_vseparator_new();
    }
    this.labelHandle = OS.gtk_label_new(null);
    OS.gtk_container_add(this.fixedHandle, this.labelHandle);
    OS.gtk_container_add(this.fixedHandle, this.frameHandle);
    OS.gtk_container_add(this.fixedHandle, this.entryHandle);
    OS.gtk_container_add(this.fixedHandle, this.separatorHandle);
    OS.gtk_container_add(this.fixedHandle, this.arrowHandle);
    OS.gtk_container_add(this.fixedHandle, this.toolbarHandle);
    OS.gtk_container_add(this.fixedHandle, this.progressHandle);
    OS.gtk_container_add(this.fixedHandle, this.checkButtonHandle);
    OS.gtk_container_add(this.fixedHandle, this.radioButtonHandle);
    OS.gtk_container_add(this.fixedHandle, this.buttonHandle);
    OS.gtk_container_add(this.fixedHandle, this.treeHandle);
    OS.gtk_container_add(this.fixedHandle, this.notebookHandle);
    OS.gtk_container_add(this.shellHandle, this.fixedHandle);
    OS.gtk_widget_realize(this.separatorHandle);
    OS.gtk_widget_realize(this.labelHandle);
    OS.gtk_widget_realize(this.frameHandle);
    OS.gtk_widget_realize(this.entryHandle);
    OS.gtk_widget_realize(this.arrowHandle);
    OS.gtk_widget_realize(this.buttonHandle);
    OS.gtk_widget_realize(this.treeHandle);
    OS.gtk_widget_realize(this.notebookHandle);
    OS.gtk_widget_realize(this.checkButtonHandle);
    OS.gtk_widget_realize(this.radioButtonHandle);
    OS.gtk_widget_realize(this.progressHandle);
    OS.gtk_widget_realize(this.toolbarHandle);
    OS.gtk_widget_realize(this.shellHandle);
  }
  
  void checkTheme()
  {
    if (isDisposed()) {
      SWT.error(44);
    }
  }
  
  public Rectangle computeTrim(GC paramGC, DrawData paramDrawData)
  {
    if (paramGC == null) {
      SWT.error(4);
    }
    if (paramDrawData == null) {
      SWT.error(4);
    }
    if (paramGC.isDisposed()) {
      SWT.error(5);
    }
    return paramDrawData.computeTrim(this, paramGC);
  }
  
  public void dispose()
  {
    if (this.shellHandle == 0) {
      return;
    }
    OS.gtk_widget_destroy(this.shellHandle);
    this.shellHandle = (this.fixedHandle = this.buttonHandle = this.arrowHandle = this.frameHandle = this.entryHandle = this.checkButtonHandle = this.radioButtonHandle = this.notebookHandle = this.treeHandle = this.progressHandle = this.toolbarHandle = this.labelHandle = this.separatorHandle = 0);
  }
  
  public void drawBackground(GC paramGC, Rectangle paramRectangle, DrawData paramDrawData)
  {
    checkTheme();
    if (paramGC == null) {
      SWT.error(4);
    }
    if (paramRectangle == null) {
      SWT.error(4);
    }
    if (paramDrawData == null) {
      SWT.error(4);
    }
    if (paramGC.isDisposed()) {
      SWT.error(5);
    }
    paramDrawData.draw(this, paramGC, paramRectangle);
  }
  
  public void drawFocus(GC paramGC, Rectangle paramRectangle, DrawData paramDrawData)
  {
    checkTheme();
    if (paramGC == null) {
      SWT.error(4);
    }
    if (paramRectangle == null) {
      SWT.error(4);
    }
    if (paramDrawData == null) {
      SWT.error(4);
    }
    if (paramGC.isDisposed()) {
      SWT.error(5);
    }
    paramGC.drawFocus(paramRectangle.x, paramRectangle.y, paramRectangle.width, paramRectangle.height);
  }
  
  public void drawImage(GC paramGC, Rectangle paramRectangle, DrawData paramDrawData, Image paramImage, int paramInt)
  {
    checkTheme();
    if (paramGC == null) {
      SWT.error(4);
    }
    if (paramRectangle == null) {
      SWT.error(4);
    }
    if (paramDrawData == null) {
      SWT.error(4);
    }
    if (paramImage == null) {
      SWT.error(4);
    }
    if (paramGC.isDisposed()) {
      SWT.error(5);
    }
    paramDrawData.drawImage(this, paramImage, paramGC, paramRectangle);
  }
  
  public void drawText(GC paramGC, Rectangle paramRectangle, DrawData paramDrawData, String paramString, int paramInt)
  {
    checkTheme();
    if (paramGC == null) {
      SWT.error(4);
    }
    if (paramRectangle == null) {
      SWT.error(4);
    }
    if (paramDrawData == null) {
      SWT.error(4);
    }
    if (paramString == null) {
      SWT.error(4);
    }
    if (paramGC.isDisposed()) {
      SWT.error(5);
    }
    paramDrawData.drawText(this, paramString, paramInt, paramGC, paramRectangle);
  }
  
  public Rectangle getBounds(int paramInt, Rectangle paramRectangle, DrawData paramDrawData)
  {
    checkTheme();
    if (paramRectangle == null) {
      SWT.error(4);
    }
    if (paramDrawData == null) {
      SWT.error(4);
    }
    return paramDrawData.getBounds(paramInt, paramRectangle);
  }
  
  public int getSelection(Point paramPoint, Rectangle paramRectangle, RangeDrawData paramRangeDrawData)
  {
    checkTheme();
    if (paramPoint == null) {
      SWT.error(4);
    }
    if (paramRectangle == null) {
      SWT.error(4);
    }
    if (paramRangeDrawData == null) {
      SWT.error(4);
    }
    return paramRangeDrawData.getSelection(paramPoint, paramRectangle);
  }
  
  public int hitBackground(Point paramPoint, Rectangle paramRectangle, DrawData paramDrawData)
  {
    checkTheme();
    if (paramPoint == null) {
      SWT.error(4);
    }
    if (paramRectangle == null) {
      SWT.error(4);
    }
    if (paramDrawData == null) {
      SWT.error(4);
    }
    return paramDrawData.hit(this, paramPoint, paramRectangle);
  }
  
  public boolean isDisposed()
  {
    return this.device == null;
  }
  
  public Rectangle measureText(GC paramGC, Rectangle paramRectangle, DrawData paramDrawData, String paramString, int paramInt)
  {
    checkTheme();
    if (paramGC == null) {
      SWT.error(4);
    }
    if (paramDrawData == null) {
      SWT.error(4);
    }
    if (paramString == null) {
      SWT.error(4);
    }
    if (paramGC.isDisposed()) {
      SWT.error(5);
    }
    return paramDrawData.measureText(this, paramString, paramInt, paramGC, paramRectangle);
  }
  
  int getWidgetProperty(int paramInt, String paramString)
  {
    byte[] arrayOfByte = Converter.wcsToMbcs(null, paramString, true);
    int[] arrayOfInt = new int[1];
    OS.gtk_widget_style_get(paramInt, arrayOfByte, arrayOfInt, 0);
    return arrayOfInt[0];
  }
  
  int getBorderProperty(int paramInt, String paramString)
  {
    byte[] arrayOfByte = Converter.wcsToMbcs(null, paramString, true);
    int[] arrayOfInt = new int[1];
    OS.gtk_widget_style_get(paramInt, arrayOfByte, arrayOfInt, 0);
    return arrayOfInt[0];
  }
  
  void transferClipping(GC paramGC, int paramInt)
  {
    GCData localGCData = paramGC.getGCData();
    int i = localGCData.clipRgn;
    int j = localGCData.damageRgn;
    int k = i;
    if (j != 0) {
      if (k != 0)
      {
        k = OS.gdk_region_new();
        OS.gdk_region_union(k, i);
        OS.gdk_region_intersect(k, j);
      }
      else
      {
        k = j;
      }
    }
    if (!OS.GTK3)
    {
      int[] arrayOfInt = new int[1];
      for (int m = 0; m < 5; m++)
      {
        OS.gtk_style_get_fg_gc(paramInt, m, arrayOfInt);
        if (arrayOfInt[0] != 0) {
          OS.gdk_gc_set_clip_region(arrayOfInt[0], k);
        }
        OS.gtk_style_get_bg_gc(paramInt, m, arrayOfInt);
        if (arrayOfInt[0] != 0) {
          OS.gdk_gc_set_clip_region(arrayOfInt[0], k);
        }
        OS.gtk_style_get_light_gc(paramInt, m, arrayOfInt);
        if (arrayOfInt[0] != 0) {
          OS.gdk_gc_set_clip_region(arrayOfInt[0], k);
        }
        OS.gtk_style_get_dark_gc(paramInt, m, arrayOfInt);
        if (arrayOfInt[0] != 0) {
          OS.gdk_gc_set_clip_region(arrayOfInt[0], k);
        }
        OS.gtk_style_get_mid_gc(paramInt, m, arrayOfInt);
        if (arrayOfInt[0] != 0) {
          OS.gdk_gc_set_clip_region(arrayOfInt[0], k);
        }
        OS.gtk_style_get_text_gc(paramInt, m, arrayOfInt);
        if (arrayOfInt[0] != 0) {
          OS.gdk_gc_set_clip_region(arrayOfInt[0], k);
        }
        OS.gtk_style_get_text_aa_gc(paramInt, m, arrayOfInt);
        if (arrayOfInt[0] != 0) {
          OS.gdk_gc_set_clip_region(arrayOfInt[0], k);
        }
      }
      OS.gtk_style_get_black_gc(paramInt, arrayOfInt);
      if (arrayOfInt[0] != 0) {
        OS.gdk_gc_set_clip_region(arrayOfInt[0], k);
      }
      OS.gtk_style_get_white_gc(paramInt, arrayOfInt);
      if (arrayOfInt[0] != 0) {
        OS.gdk_gc_set_clip_region(arrayOfInt[0], k);
      }
    }
    if ((k != i) && (k != j)) {
      OS.gdk_region_destroy(k);
    }
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/internal/theme/Theme.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */