package org.eclipse.swt.internal.gtk;

public class GdkWindowAttr
{
  public int title;
  public int event_mask;
  public int x;
  public int y;
  public int width;
  public int height;
  public int wclass;
  public int visual;
  public int colormap;
  public int window_type;
  public int cursor;
  public int wmclass_name;
  public int wmclass_class;
  public boolean override_redirect;
  public static final int sizeof = ;
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/internal/gtk/GdkWindowAttr.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */