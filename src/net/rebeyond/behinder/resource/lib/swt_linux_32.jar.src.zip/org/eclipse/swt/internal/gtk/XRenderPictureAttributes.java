package org.eclipse.swt.internal.gtk;

public class XRenderPictureAttributes
{
  public boolean repeat;
  public int alpha_map;
  public int alpha_x_origin;
  public int alpha_y_origin;
  public int clip_x_origin;
  public int clip_y_origin;
  public int clip_mask;
  public boolean graphics_exposures;
  public int subwindow_mode;
  public int poly_edge;
  public int poly_mode;
  public int dither;
  public boolean component_alpha;
  public static final int sizeof = ;
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/internal/gtk/XRenderPictureAttributes.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */