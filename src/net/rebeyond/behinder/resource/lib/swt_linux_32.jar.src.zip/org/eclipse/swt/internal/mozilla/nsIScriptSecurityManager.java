package org.eclipse.swt.internal.mozilla;

public class nsIScriptSecurityManager
  extends nsIXPCSecurityManager
{
  static final int LAST_METHOD_ID = nsIXPCSecurityManager.LAST_METHOD_ID + (IsXULRunner10() ? 27 : IsXULRunner24() ? 21 : 26);
  static final String NS_ISCRIPTSECURITYMANAGER_IID_STR = "3fffd8e8-3fea-442e-a0ed-2ba81ae197d5";
  static final String NS_ISCRIPTSECURITYMANAGER_191_IID_STR = "f8e350b9-9f31-451a-8c8f-d10fea26b780";
  static final String NS_ISCRIPTSECURITYMANAGER_10_IID_STR = "50eda256-4dd2-4c7c-baed-96983910af9f";
  static final String NS_ISCRIPTSECURITYMANAGER_24_IID_STR = "ae486501-ec57-4ec8-a565-6880ca4ae6c4";
  public static final int STANDARD = 0;
  public static final int LOAD_IS_AUTOMATIC_DOCUMENT_REPLACEMENT = 1;
  public static final int ALLOW_CHROME = 2;
  public static final int DISALLOW_INHERIT_PRINCIPAL = 4;
  public static final int DISALLOW_SCRIPT_OR_DATA = 4;
  public static final int DISALLOW_SCRIPT = 8;
  
  public nsIScriptSecurityManager(int paramInt)
  {
    super(paramInt);
  }
  
  public int GetSystemPrincipal(int[] paramArrayOfInt)
  {
    return XPCOM.VtblCall(nsIXPCSecurityManager.LAST_METHOD_ID + (IsXULRunner10() ? 10 : IsXULRunner24() ? 8 : 11), getAddress(), paramArrayOfInt);
  }
  
  public int GetSubjectPrincipal(int[] paramArrayOfInt)
  {
    return XPCOM.VtblCall(nsIXPCSecurityManager.LAST_METHOD_ID + (IsXULRunner10() ? 10 : IsXULRunner24() ? 7 : 11), getAddress(), paramArrayOfInt);
  }
  
  public int GetObjectPrincipal(int paramInt1, int paramInt2, int[] paramArrayOfInt)
  {
    return XPCOM.VtblCall(nsIXPCSecurityManager.LAST_METHOD_ID + (IsXULRunner10() ? 10 : IsXULRunner24() ? 14 : 11), getAddress(), paramInt1, paramInt2, paramArrayOfInt);
  }
  
  static
  {
    IIDStore.RegisterIID(nsIScriptSecurityManager.class, 0, new nsID("3fffd8e8-3fea-442e-a0ed-2ba81ae197d5"));
    IIDStore.RegisterIID(nsIScriptSecurityManager.class, 3, new nsID("f8e350b9-9f31-451a-8c8f-d10fea26b780"));
    IIDStore.RegisterIID(nsIScriptSecurityManager.class, 5, new nsID("50eda256-4dd2-4c7c-baed-96983910af9f"));
    IIDStore.RegisterIID(nsIScriptSecurityManager.class, 6, new nsID("ae486501-ec57-4ec8-a565-6880ca4ae6c4"));
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/internal/mozilla/nsIScriptSecurityManager.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */