package org.eclipse.swt.custom;

import org.eclipse.swt.events.TypedEvent;
import org.eclipse.swt.graphics.GC;

public class PaintObjectEvent
  extends TypedEvent
{
  public GC gc;
  public int x;
  public int y;
  public int ascent;
  public int descent;
  public StyleRange style;
  public Bullet bullet;
  public int bulletIndex;
  static final long serialVersionUID = 3906081274027192855L;
  
  public PaintObjectEvent(StyledTextEvent paramStyledTextEvent)
  {
    super(paramStyledTextEvent);
    this.gc = paramStyledTextEvent.gc;
    this.x = paramStyledTextEvent.x;
    this.y = paramStyledTextEvent.y;
    this.ascent = paramStyledTextEvent.ascent;
    this.descent = paramStyledTextEvent.descent;
    this.style = paramStyledTextEvent.style;
    this.bullet = paramStyledTextEvent.bullet;
    this.bulletIndex = paramStyledTextEvent.bulletIndex;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/custom/PaintObjectEvent.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */