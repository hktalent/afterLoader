package org.eclipse.swt.internal.theme;

import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.GCData;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.internal.Converter;
import org.eclipse.swt.internal.ImageList;
import org.eclipse.swt.internal.cairo.Cairo;
import org.eclipse.swt.internal.gtk.GdkRectangle;
import org.eclipse.swt.internal.gtk.OS;

public class DrawData
{
  public int style;
  public int[] state = new int[1];
  public Rectangle clientArea;
  public static final int SELECTED = 2;
  public static final int FOCUSED = 4;
  public static final int PRESSED = 8;
  public static final int ACTIVE = 16;
  public static final int DISABLED = 32;
  public static final int HOT = 64;
  public static final int DEFAULTED = 128;
  public static final int GRAYED = 256;
  public static final int DRAW_LEFT = 16;
  public static final int DRAW_TOP = 32;
  public static final int DRAW_RIGHT = 64;
  public static final int DRAW_BOTTOM = 128;
  public static final int DRAW_HCENTER = 256;
  public static final int DRAW_VCENTER = 512;
  public static final int WIDGET_NOWHERE = -1;
  public static final int WIDGET_WHOLE = 0;
  public static final int SCROLLBAR_UP_ARROW = 1;
  public static final int SCROLLBAR_DOWN_ARROW = 2;
  public static final int SCROLLBAR_LEFT_ARROW = 1;
  public static final int SCROLLBAR_RIGHT_ARROW = 2;
  public static final int SCROLLBAR_UP_TRACK = 3;
  public static final int SCROLLBAR_DOWN_TRACK = 4;
  public static final int SCROLLBAR_LEFT_TRACK = 3;
  public static final int SCROLLBAR_RIGHT_TRACK = 4;
  public static final int SCROLLBAR_THUMB = 5;
  public static final int SCALE_UP_TRACK = 1;
  public static final int SCALE_LEFT_TRACK = 1;
  public static final int SCALE_DOWN_TRACK = 2;
  public static final int SCALE_RIGHT_TRACK = 2;
  public static final int SCALE_THUMB = 3;
  public static final int TOOLITEM_ARROW = 1;
  public static final int COMBO_ARROW = 1;
  
  Rectangle computeTrim(Theme paramTheme, GC paramGC)
  {
    return new Rectangle(this.clientArea.x, this.clientArea.y, this.clientArea.width, this.clientArea.height);
  }
  
  void draw(Theme paramTheme, GC paramGC, Rectangle paramRectangle) {}
  
  void drawImage(Theme paramTheme, Image paramImage, GC paramGC, Rectangle paramRectangle)
  {
    int i = paramGC.getGCData().drawable;
    Rectangle localRectangle = paramImage.getBounds();
    int j = getStateType(0);
    if (j == 0)
    {
      paramGC.drawImage(paramImage, 0, 0, localRectangle.width, localRectangle.height, paramRectangle.x, paramRectangle.y, paramRectangle.width, paramRectangle.height);
    }
    else
    {
      int k = ImageList.createPixbuf(paramImage);
      int m = OS.gtk_icon_source_new();
      if (m != 0)
      {
        OS.gtk_icon_source_set_pixbuf(m, k);
        int n = paramTheme.buttonHandle;
        int i1 = OS.gtk_widget_get_style(n);
        paramTheme.transferClipping(paramGC, i1);
        int i2 = OS.gtk_style_render_icon(i1, m, 0, j, -1, n, null);
        OS.g_object_unref(k);
        if (i2 != 0)
        {
          if (OS.USE_CAIRO)
          {
            int i3 = OS.gdk_cairo_create(i);
            OS.gdk_cairo_set_source_pixbuf(i3, paramGC.handle, 0.0D, 0.0D);
            Cairo.cairo_rectangle(i3, paramRectangle.x, paramRectangle.y, paramRectangle.width, paramRectangle.height);
            Cairo.cairo_fill(i3);
            Cairo.cairo_destroy(i3);
          }
          else
          {
            OS.gdk_draw_pixbuf(i, paramGC.handle, i2, 0, 0, paramRectangle.x, paramRectangle.y, paramRectangle.width, paramRectangle.height, 1, 0, 0);
          }
          OS.g_object_unref(i2);
        }
        OS.gtk_icon_source_free(m);
      }
    }
  }
  
  void drawText(Theme paramTheme, String paramString, int paramInt, GC paramGC, Rectangle paramRectangle)
  {
    int i = getTextHandle(paramTheme);
    int j = OS.gtk_widget_get_style(i);
    int k = paramGC.getGCData().drawable;
    paramTheme.transferClipping(paramGC, j);
    byte[] arrayOfByte1 = Converter.wcsToMbcs(null, paramString, true);
    int m = OS.gtk_widget_create_pango_layout(i, arrayOfByte1);
    int[] arrayOfInt1 = new int[1];
    int[] arrayOfInt2 = new int[1];
    OS.pango_layout_get_pixel_size(m, arrayOfInt1, arrayOfInt2);
    OS.pango_layout_set_width(m, paramRectangle.width * 1024);
    int n = paramRectangle.x;
    int i1 = paramRectangle.y;
    if ((paramInt & 0x10) != 0) {
      OS.pango_layout_set_alignment(m, 0);
    }
    if ((paramInt & 0x100) != 0) {
      OS.pango_layout_set_alignment(m, 1);
    }
    if ((paramInt & 0x40) != 0) {
      OS.pango_layout_set_alignment(m, 2);
    }
    if ((paramInt & 0x200) != 0) {
      i1 += (paramRectangle.height - arrayOfInt2[0]) / 2;
    }
    if ((paramInt & 0x80) != 0) {
      i1 += paramRectangle.height - arrayOfInt2[0];
    }
    int i2 = getStateType(0);
    byte[] arrayOfByte2 = Converter.wcsToMbcs(null, "label", true);
    gtk_render_layout(j, k, i2, false, null, i, arrayOfByte2, n, i1, m);
    OS.g_object_unref(m);
  }
  
  Rectangle getBounds(int paramInt, Rectangle paramRectangle)
  {
    return new Rectangle(paramRectangle.x, paramRectangle.y, paramRectangle.width, paramRectangle.height);
  }
  
  int getStateType(int paramInt)
  {
    int i = this.state[paramInt];
    int j = 0;
    if ((i & 0x20) != 0)
    {
      j = 4;
    }
    else
    {
      if ((i & 0x2) != 0) {
        j = 1;
      }
      if ((i & 0x40) != 0) {
        if ((i & 0x8) != 0) {
          j = 1;
        } else {
          j = 2;
        }
      }
    }
    return j;
  }
  
  int getTextHandle(Theme paramTheme)
  {
    return paramTheme.labelHandle;
  }
  
  int hit(Theme paramTheme, Point paramPoint, Rectangle paramRectangle)
  {
    return -1;
  }
  
  Rectangle measureText(Theme paramTheme, String paramString, int paramInt, GC paramGC, Rectangle paramRectangle)
  {
    int i = getTextHandle(paramTheme);
    byte[] arrayOfByte = Converter.wcsToMbcs(null, paramString, true);
    int j = OS.gtk_widget_create_pango_layout(i, arrayOfByte);
    if (paramRectangle != null) {
      OS.pango_layout_set_width(j, paramRectangle.width);
    }
    if ((paramInt & 0x10) != 0) {
      OS.pango_layout_set_alignment(j, 0);
    }
    if ((paramInt & 0x100) != 0) {
      OS.pango_layout_set_alignment(j, 1);
    }
    if ((paramInt & 0x40) != 0) {
      OS.pango_layout_set_alignment(j, 2);
    }
    int[] arrayOfInt1 = new int[1];
    int[] arrayOfInt2 = new int[1];
    OS.pango_layout_get_pixel_size(j, arrayOfInt1, arrayOfInt2);
    OS.g_object_unref(j);
    return new Rectangle(0, 0, arrayOfInt1[0], arrayOfInt2[0]);
  }
  
  void gtk_render_frame(int paramInt1, int paramInt2, int paramInt3, int paramInt4, GdkRectangle paramGdkRectangle, int paramInt5, byte[] paramArrayOfByte, int paramInt6, int paramInt7, int paramInt8, int paramInt9)
  {
    if (OS.GTK3)
    {
      int i = OS.gdk_cairo_create(paramInt2);
      int j = OS.gtk_widget_get_style_context(paramInt1);
      OS.gtk_render_frame(j, i, paramInt6, paramInt7, paramInt8, paramInt9);
      Cairo.cairo_destroy(i);
    }
    else
    {
      OS.gtk_paint_flat_box(paramInt1, paramInt2, paramInt3, paramInt4, paramGdkRectangle, paramInt5, paramArrayOfByte, paramInt6, paramInt7, paramInt8, paramInt9);
    }
  }
  
  void gtk_render_box(int paramInt1, int paramInt2, int paramInt3, int paramInt4, GdkRectangle paramGdkRectangle, int paramInt5, byte[] paramArrayOfByte, int paramInt6, int paramInt7, int paramInt8, int paramInt9)
  {
    if (OS.GTK3)
    {
      int i = OS.gdk_cairo_create(paramInt2);
      int j = OS.gtk_widget_get_style_context(paramInt1);
      OS.gtk_render_frame(j, i, paramInt6, paramInt7, paramInt8, paramInt9);
      OS.gtk_render_background(j, i, paramInt6, paramInt7, paramInt8, paramInt9);
      Cairo.cairo_destroy(i);
    }
    else
    {
      OS.gtk_paint_box(paramInt1, paramInt2, paramInt3, paramInt4, paramGdkRectangle, paramInt5, paramArrayOfByte, paramInt6, paramInt7, paramInt8, paramInt9);
    }
  }
  
  void gtk_render_layout(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean, GdkRectangle paramGdkRectangle, int paramInt4, byte[] paramArrayOfByte, int paramInt5, int paramInt6, int paramInt7)
  {
    if (OS.GTK3)
    {
      int i = OS.gdk_cairo_create(paramInt2);
      int j = OS.gtk_widget_get_style_context(paramInt1);
      OS.gtk_render_layout(j, i, paramInt5, paramInt6, paramInt7);
      Cairo.cairo_destroy(i);
    }
    else
    {
      OS.gtk_paint_layout(paramInt1, paramInt2, paramInt3, paramBoolean, paramGdkRectangle, paramInt4, paramArrayOfByte, paramInt5, paramInt6, paramInt7);
    }
  }
  
  void gtk_render_focus(int paramInt1, int paramInt2, int paramInt3, GdkRectangle paramGdkRectangle, int paramInt4, byte[] paramArrayOfByte, int paramInt5, int paramInt6, int paramInt7, int paramInt8)
  {
    if (OS.GTK3)
    {
      int i = OS.gdk_cairo_create(paramInt2);
      int j = OS.gtk_widget_get_style_context(paramInt1);
      OS.gtk_style_context_save(j);
      OS.gtk_style_context_set_state(j, OS.gtk_widget_get_state_flags(paramInt4));
      Cairo.cairo_save(i);
      OS.gtk_render_focus(j, i, paramInt5, paramInt6, paramInt7, paramInt8);
      Cairo.cairo_restore(i);
      OS.gtk_style_context_restore(j);
      Cairo.cairo_destroy(i);
    }
    else
    {
      OS.gtk_paint_focus(paramInt1, paramInt2, paramInt3, paramGdkRectangle, paramInt4, paramArrayOfByte, paramInt5, paramInt6, paramInt7, paramInt8);
    }
  }
  
  void gtk_render_arrow(int paramInt1, int paramInt2, int paramInt3, int paramInt4, GdkRectangle paramGdkRectangle, int paramInt5, byte[] paramArrayOfByte, int paramInt6, boolean paramBoolean, int paramInt7, int paramInt8, int paramInt9, int paramInt10)
  {
    if (OS.GTK3)
    {
      double d1 = 0.0D;
      double d2 = 0.0D;
      switch (paramInt6)
      {
      case 0: 
        d1 = 0.0D;
        d2 = paramInt9;
        break;
      case 3: 
        d1 = 1.5707963267948966D;
        d2 = paramInt10;
        break;
      case 1: 
        d1 = 3.141592653589793D;
        d2 = paramInt9;
        break;
      case 2: 
        d1 = 4.71238898038469D;
        d2 = paramInt10;
      }
      int i = OS.gdk_cairo_create(paramInt2);
      int j = OS.gtk_widget_get_style_context(paramInt1);
      OS.gtk_style_context_set_state(j, paramInt3);
      OS.gtk_render_background(j, i, paramInt7, paramInt8, paramInt9, paramInt10);
      OS.gtk_render_frame(j, i, paramInt7, paramInt8, paramInt9, paramInt10);
      OS.gtk_render_arrow(j, i, d1, paramInt7, paramInt8, d2);
      Cairo.cairo_destroy(i);
    }
    else
    {
      OS.gtk_paint_arrow(paramInt1, paramInt2, paramInt3, paramInt4, paramGdkRectangle, paramInt5, paramArrayOfByte, paramInt6, paramBoolean, paramInt7, paramInt8, paramInt9, paramInt10);
    }
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/internal/theme/DrawData.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */