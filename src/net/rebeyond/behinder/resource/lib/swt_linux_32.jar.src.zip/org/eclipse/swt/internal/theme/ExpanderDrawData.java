package org.eclipse.swt.internal.theme;

import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.GCData;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.internal.Converter;
import org.eclipse.swt.internal.cairo.Cairo;
import org.eclipse.swt.internal.gtk.OS;

public class ExpanderDrawData
  extends DrawData
{
  public ExpanderDrawData()
  {
    this.state = new int[1];
  }
  
  void draw(Theme paramTheme, GC paramGC, Rectangle paramRectangle)
  {
    int i = paramTheme.treeHandle;
    int j = OS.gtk_widget_get_style(i);
    int k = paramGC.getGCData().drawable;
    paramTheme.transferClipping(paramGC, j);
    int m = getStateType(0);
    int n = 0;
    if ((this.style & 0x400) != 0) {
      n = 3;
    }
    byte[] arrayOfByte = Converter.wcsToMbcs(null, "treeview", true);
    int i1 = paramTheme.getWidgetProperty(i, "expander-size");
    int i2 = paramRectangle.x + i1 / 2;
    int i3 = paramRectangle.y + i1 / 2;
    if (OS.GTK3)
    {
      int i4 = OS.gdk_cairo_create(k);
      int i5 = OS.gtk_widget_get_style_context(j);
      OS.gtk_render_expander(i5, i4, paramRectangle.x, paramRectangle.y, i1, i1);
      Cairo.cairo_destroy(i4);
    }
    else
    {
      OS.gtk_paint_expander(j, k, m, null, i, arrayOfByte, i2, i3, n);
    }
  }
  
  int hit(Theme paramTheme, Point paramPoint, Rectangle paramRectangle)
  {
    if (!paramRectangle.contains(paramPoint)) {
      return -1;
    }
    int i = paramTheme.treeHandle;
    int j = paramTheme.getWidgetProperty(i, "expander-size");
    if (new Rectangle(paramRectangle.x, paramRectangle.y, j, j).contains(paramPoint)) {
      return 0;
    }
    return -1;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/internal/theme/ExpanderDrawData.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */