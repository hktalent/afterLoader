package org.eclipse.swt.accessibility;

import org.eclipse.swt.internal.SWTEventListener;

public abstract interface AccessibleAttributeListener
  extends SWTEventListener
{
  public abstract void getAttributes(AccessibleAttributeEvent paramAccessibleAttributeEvent);
  
  public abstract void getTextAttributes(AccessibleTextAttributeEvent paramAccessibleTextAttributeEvent);
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/accessibility/AccessibleAttributeListener.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */