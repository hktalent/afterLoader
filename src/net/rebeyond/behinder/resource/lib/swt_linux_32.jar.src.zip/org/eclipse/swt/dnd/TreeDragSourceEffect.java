package org.eclipse.swt.dnd;

import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.internal.cairo.Cairo;
import org.eclipse.swt.internal.gtk.GdkColor;
import org.eclipse.swt.internal.gtk.GdkRectangle;
import org.eclipse.swt.internal.gtk.OS;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Tree;

public class TreeDragSourceEffect
  extends DragSourceEffect
{
  Image dragSourceImage = null;
  
  public TreeDragSourceEffect(Tree paramTree)
  {
    super(paramTree);
  }
  
  public void dragFinished(DragSourceEvent paramDragSourceEvent)
  {
    if (this.dragSourceImage != null) {
      this.dragSourceImage.dispose();
    }
    this.dragSourceImage = null;
  }
  
  public void dragStart(DragSourceEvent paramDragSourceEvent)
  {
    paramDragSourceEvent.image = getDragSourceImage(paramDragSourceEvent);
  }
  
  Image getDragSourceImage(DragSourceEvent paramDragSourceEvent)
  {
    if (this.dragSourceImage != null) {
      this.dragSourceImage.dispose();
    }
    this.dragSourceImage = null;
    Tree localTree = (Tree)this.control;
    if ((localTree.isListening(40)) || (localTree.isListening(42))) {
      return null;
    }
    int i = localTree.handle;
    int j = OS.gtk_tree_view_get_selection(i);
    int[] arrayOfInt1 = null;
    int k = OS.gtk_tree_selection_get_selected_rows(j, arrayOfInt1);
    if (k == 0) {
      return null;
    }
    int m = Math.min(10, OS.g_list_length(k));
    Display localDisplay = localTree.getDisplay();
    int n;
    int i1;
    if (m == 1)
    {
      n = OS.g_list_nth_data(k, 0);
      i1 = OS.gtk_tree_view_create_row_drag_icon(i, n);
      this.dragSourceImage = Image.gtk_new(localDisplay, 1, i1, 0);
      OS.gtk_tree_path_free(n);
    }
    else
    {
      n = 0;
      i1 = 0;
      int[] arrayOfInt2 = new int[1];
      int[] arrayOfInt3 = new int[1];
      int[] arrayOfInt4 = new int[m];
      int[] arrayOfInt5 = new int[m];
      int[] arrayOfInt6 = new int[m];
      GdkRectangle localGdkRectangle = new GdkRectangle();
      int i3;
      for (int i2 = 0; i2 < m; i2++)
      {
        i3 = OS.g_list_nth_data(k, i2);
        OS.gtk_tree_view_get_cell_area(i, i3, 0, localGdkRectangle);
        arrayOfInt6[i2] = OS.gtk_tree_view_create_row_drag_icon(i, i3);
        if (OS.GTK3)
        {
          arrayOfInt2[0] = Cairo.cairo_xlib_surface_get_width(arrayOfInt6[i2]);
          arrayOfInt3[0] = Cairo.cairo_xlib_surface_get_height(arrayOfInt6[i2]);
        }
        else if (OS.GTK_VERSION >= OS.VERSION(2, 24, 0))
        {
          OS.gdk_pixmap_get_size(arrayOfInt6[i2], arrayOfInt2, arrayOfInt3);
        }
        else
        {
          OS.gdk_drawable_get_size(arrayOfInt6[i2], arrayOfInt2, arrayOfInt3);
        }
        n = Math.max(n, arrayOfInt2[0]);
        i1 = localGdkRectangle.y + arrayOfInt3[0] - arrayOfInt4[0];
        arrayOfInt4[i2] = localGdkRectangle.y;
        arrayOfInt5[i2] = arrayOfInt3[0];
        OS.gtk_tree_path_free(i3);
      }
      int i4;
      if (OS.GTK3)
      {
        i2 = Cairo.cairo_image_surface_create(0, n, i1);
        if (i2 == 0) {
          SWT.error(2);
        }
        i3 = Cairo.cairo_create(i2);
        if (i3 == 0) {
          SWT.error(2);
        }
        Cairo.cairo_set_operator(i3, 1);
        for (i4 = 0; i4 < m; i4++)
        {
          Cairo.cairo_set_source_surface(i3, arrayOfInt6[i4], 2.0D, arrayOfInt4[i4] - arrayOfInt4[0] + 2);
          Cairo.cairo_rectangle(i3, 0.0D, arrayOfInt4[i4] - arrayOfInt4[0], n, arrayOfInt5[i4]);
          Cairo.cairo_fill(i3);
          Cairo.cairo_surface_destroy(arrayOfInt6[i4]);
        }
        Cairo.cairo_destroy(i3);
        this.dragSourceImage = Image.gtk_new(localDisplay, 1, i2, 0);
      }
      else
      {
        i2 = OS.gdk_pixmap_new(OS.gdk_get_default_root_window(), n, i1, -1);
        i3 = OS.gdk_gc_new(i2);
        i4 = OS.gdk_pixmap_new(OS.gdk_get_default_root_window(), n, i1, 1);
        int i5 = OS.gdk_gc_new(i4);
        GdkColor localGdkColor = new GdkColor();
        localGdkColor.pixel = 0;
        OS.gdk_gc_set_foreground(i5, localGdkColor);
        OS.gdk_draw_rectangle(i4, i5, 1, 0, 0, n, i1);
        localGdkColor.pixel = 1;
        OS.gdk_gc_set_foreground(i5, localGdkColor);
        for (int i6 = 0; i6 < m; i6++)
        {
          OS.gdk_draw_drawable(i2, i3, arrayOfInt6[i6], 0, 0, 0, arrayOfInt4[i6] - arrayOfInt4[0], -1, -1);
          OS.gdk_draw_rectangle(i4, i5, 1, 0, arrayOfInt4[i6] - arrayOfInt4[0], n, arrayOfInt5[i6]);
          OS.g_object_unref(arrayOfInt6[i6]);
        }
        OS.g_object_unref(i3);
        OS.g_object_unref(i5);
        this.dragSourceImage = Image.gtk_new(localDisplay, 1, i2, i4);
      }
    }
    OS.g_list_free(k);
    return this.dragSourceImage;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/dnd/TreeDragSourceEffect.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */