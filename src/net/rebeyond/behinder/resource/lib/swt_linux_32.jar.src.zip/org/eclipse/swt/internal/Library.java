package org.eclipse.swt.internal;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.JarURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.util.jar.Attributes;

public class Library
{
  static int MAJOR_VERSION = 4;
  static int MINOR_VERSION = 430;
  static int REVISION = 0;
  public static final int JAVA_VERSION = parseVersion(System.getProperty("java.version"));
  public static final int SWT_VERSION = SWT_VERSION(MAJOR_VERSION, MINOR_VERSION);
  static final String SEPARATOR;
  static final String DELIMITER;
  static final boolean IS_64 = longConst() == (int)longConst();
  static final String SUFFIX_64 = "-64";
  static final String SWT_LIB_DIR;
  
  static String arch()
  {
    String str = System.getProperty("os.arch");
    if ((str.equals("i386")) || (str.equals("i686"))) {
      return "x86";
    }
    if (str.equals("amd64")) {
      return "x86_64";
    }
    if (str.equals("IA64N")) {
      return "ia64_32";
    }
    if (str.equals("IA64W")) {
      return "ia64";
    }
    return str;
  }
  
  static String os()
  {
    String str = System.getProperty("os.name");
    if (str.equals("Linux")) {
      return "linux";
    }
    if (str.equals("AIX")) {
      return "aix";
    }
    if ((str.equals("Solaris")) || (str.equals("SunOS"))) {
      return "solaris";
    }
    if (str.equals("HP-UX")) {
      return "hpux";
    }
    if (str.equals("Mac OS X")) {
      return "macosx";
    }
    if (str.startsWith("Win")) {
      return "win32";
    }
    return str;
  }
  
  static void chmod(String paramString1, String paramString2)
  {
    if ("gtk".equals("win32")) {
      return;
    }
    try
    {
      Runtime.getRuntime().exec(new String[] { "chmod", paramString1, paramString2 }).waitFor();
    }
    catch (Throwable localThrowable) {}
  }
  
  static long longConst()
  {
    return 8589934591L;
  }
  
  static int parseVersion(String paramString)
  {
    if (paramString == null) {
      return 0;
    }
    int i = 0;
    int j = 0;
    int k = 0;
    int m = paramString.length();
    int n = 0;
    int i1 = 0;
    while ((n < m) && (Character.isDigit(paramString.charAt(n)))) {
      n++;
    }
    try
    {
      if (i1 < m) {
        i = Integer.parseInt(paramString.substring(i1, n));
      }
    }
    catch (NumberFormatException localNumberFormatException1) {}
    n++;
    i1 = n;
    while ((n < m) && (Character.isDigit(paramString.charAt(n)))) {
      n++;
    }
    try
    {
      if (i1 < m) {
        j = Integer.parseInt(paramString.substring(i1, n));
      }
    }
    catch (NumberFormatException localNumberFormatException2) {}
    n++;
    i1 = n;
    while ((n < m) && (Character.isDigit(paramString.charAt(n)))) {
      n++;
    }
    try
    {
      if (i1 < m) {
        k = Integer.parseInt(paramString.substring(i1, n));
      }
    }
    catch (NumberFormatException localNumberFormatException3) {}
    return JAVA_VERSION(i, j, k);
  }
  
  public static int JAVA_VERSION(int paramInt1, int paramInt2, int paramInt3)
  {
    return (paramInt1 << 16) + (paramInt2 << 8) + paramInt3;
  }
  
  public static int SWT_VERSION(int paramInt1, int paramInt2)
  {
    return paramInt1 * 1000 + paramInt2;
  }
  
  static boolean extract(String paramString1, String paramString2, StringBuffer paramStringBuffer)
  {
    FileOutputStream localFileOutputStream = null;
    InputStream localInputStream = null;
    File localFile = new File(paramString1);
    int i = 0;
    try
    {
      if (!localFile.exists())
      {
        localInputStream = Library.class.getResourceAsStream("/" + paramString2);
        if (localInputStream != null)
        {
          i = 1;
          byte[] arrayOfByte = new byte['က'];
          localFileOutputStream = new FileOutputStream(paramString1);
          int j;
          while ((j = localInputStream.read(arrayOfByte)) != -1) {
            localFileOutputStream.write(arrayOfByte, 0, j);
          }
          localFileOutputStream.close();
          localInputStream.close();
          chmod("755", paramString1);
          if (load(paramString1, paramStringBuffer)) {
            return true;
          }
        }
      }
    }
    catch (Throwable localThrowable)
    {
      try
      {
        if (localFileOutputStream != null) {
          localFileOutputStream.close();
        }
      }
      catch (IOException localIOException1) {}
      try
      {
        if (localInputStream != null) {
          localInputStream.close();
        }
      }
      catch (IOException localIOException2) {}
      if ((i != 0) && (localFile.exists())) {
        localFile.delete();
      }
    }
    return false;
  }
  
  static boolean isLoadable()
  {
    URL localURL = Platform.class.getClassLoader().getResource("org/eclipse/swt/internal/Library.class");
    if (!localURL.getProtocol().equals("jar")) {
      return true;
    }
    Attributes localAttributes = null;
    try
    {
      URLConnection localURLConnection = localURL.openConnection();
      if (!(localURLConnection instanceof JarURLConnection)) {
        return false;
      }
      localObject = (JarURLConnection)localURLConnection;
      localAttributes = ((JarURLConnection)localObject).getMainAttributes();
    }
    catch (IOException localIOException)
    {
      return false;
    }
    String str1 = os();
    Object localObject = arch();
    String str2 = localAttributes.getValue("SWT-OS");
    String str3 = localAttributes.getValue("SWT-Arch");
    if ((((String)localObject).equals(str3)) && (str1.equals(str2))) {
      return true;
    }
    if ((str1.equals("macosx")) && (str1.equals(str2))) {
      return (str3.length() == 0) && ((((String)localObject).equals("ppc")) || (((String)localObject).equals("x86")));
    }
    return false;
  }
  
  static boolean load(String paramString, StringBuffer paramStringBuffer)
  {
    try
    {
      if (paramString.indexOf(SEPARATOR) != -1) {
        System.load(paramString);
      } else {
        System.loadLibrary(paramString);
      }
      return true;
    }
    catch (UnsatisfiedLinkError localUnsatisfiedLinkError)
    {
      if (paramStringBuffer.length() == 0) {
        paramStringBuffer.append(DELIMITER);
      }
      paramStringBuffer.append('\t');
      paramStringBuffer.append(localUnsatisfiedLinkError.getMessage());
      paramStringBuffer.append(DELIMITER);
    }
    return false;
  }
  
  public static void loadLibrary(String paramString)
  {
    loadLibrary(paramString, true);
  }
  
  public static void loadLibrary(String paramString, boolean paramBoolean)
  {
    String str1 = System.getProperty("sun.arch.data.model");
    if (str1 == null) {
      str1 = System.getProperty("com.ibm.vm.bitmode");
    }
    if (str1 != null)
    {
      if (("32".equals(str1)) && (IS_64)) {
        throw new UnsatisfiedLinkError("Cannot load 64-bit SWT libraries on 32-bit JVM");
      }
      if (("64".equals(str1)) && (!IS_64)) {
        throw new UnsatisfiedLinkError("Cannot load 32-bit SWT libraries on 64-bit JVM");
      }
    }
    String str2;
    String str3;
    String str4;
    String str5;
    if (paramBoolean)
    {
      localObject = System.getProperty("swt.version");
      if (localObject == null)
      {
        localObject = "" + MAJOR_VERSION;
        if (MINOR_VERSION < 10) {
          localObject = (String)localObject + "00";
        } else if (MINOR_VERSION < 100) {
          localObject = (String)localObject + "0";
        }
        localObject = (String)localObject + MINOR_VERSION;
        if (REVISION > 0) {
          localObject = (String)localObject + "r" + REVISION;
        }
      }
      str2 = paramString + "-" + "gtk" + "-" + (String)localObject;
      str3 = paramString + "-" + "gtk";
      str4 = mapLibraryName(str2);
      str5 = mapLibraryName(str3);
    }
    else
    {
      str5 = paramString;
      str4 = paramString;
      str3 = paramString;
      str2 = paramString;
    }
    Object localObject = new StringBuffer();
    String str6 = System.getProperty("swt.library.path");
    if (str6 != null)
    {
      str6 = new File(str6).getAbsolutePath();
      if (load(str6 + SEPARATOR + str4, (StringBuffer)localObject)) {
        return;
      }
      if ((paramBoolean) && (load(str6 + SEPARATOR + str5, (StringBuffer)localObject))) {
        return;
      }
    }
    if (load(str2, (StringBuffer)localObject)) {
      return;
    }
    if ((paramBoolean) && (load(str3, (StringBuffer)localObject))) {
      return;
    }
    String str7 = str4;
    String str8 = str5;
    if (str6 == null)
    {
      str6 = System.getProperty("user.home");
      File localFile = new File(str6, SWT_LIB_DIR);
      if (((localFile.exists()) && (localFile.isDirectory())) || (localFile.mkdirs()))
      {
        str6 = localFile.getAbsolutePath();
      }
      else if (IS_64)
      {
        str7 = mapLibraryName(str2 + "-64");
        str8 = mapLibraryName(str3 + "-64");
      }
      if (load(str6 + SEPARATOR + str7, (StringBuffer)localObject)) {
        return;
      }
      if ((paramBoolean) && (load(str6 + SEPARATOR + str8, (StringBuffer)localObject))) {
        return;
      }
    }
    if (str6 != null)
    {
      if (extract(str6 + SEPARATOR + str7, str4, (StringBuffer)localObject)) {
        return;
      }
      if ((paramBoolean) && (extract(str6 + SEPARATOR + str8, str5, (StringBuffer)localObject))) {
        return;
      }
    }
    throw new UnsatisfiedLinkError("Could not load SWT library. Reasons: " + ((StringBuffer)localObject).toString());
  }
  
  static String mapLibraryName(String paramString)
  {
    paramString = System.mapLibraryName(paramString);
    String str = ".dylib";
    if (paramString.endsWith(str)) {
      paramString = paramString.substring(0, paramString.length() - str.length()) + ".jnilib";
    }
    return paramString;
  }
  
  static
  {
    DELIMITER = System.getProperty("line.separator");
    SEPARATOR = System.getProperty("file.separator");
    SWT_LIB_DIR = ".swt" + SEPARATOR + "lib" + SEPARATOR + os() + SEPARATOR + arch();
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/internal/Library.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */