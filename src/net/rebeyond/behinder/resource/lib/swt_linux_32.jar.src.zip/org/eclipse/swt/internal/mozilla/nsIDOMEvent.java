package org.eclipse.swt.internal.mozilla;

public class nsIDOMEvent
  extends nsISupports
{
  static final int LAST_METHOD_ID = nsISupports.LAST_METHOD_ID + (IsXULRunner10() ? 12 : IsXULRunner24() ? 25 : 10);
  static final String NS_IDOMEVENT_IID_STR = "a66b7b80-ff46-bd97-0080-5f8ae38add32";
  static final String NS_IDOMEVENT_10_IID_STR = "e85cff74-951f-45c1-be0c-89442ea2f500";
  static final String NS_IDOMEVENT_24_IID_STR = "02d54f52-a1f5-4ad2-b560-36f14012935e";
  public static final int CAPTURING_PHASE = 1;
  public static final int AT_TARGET = 2;
  public static final int BUBBLING_PHASE = 3;
  
  public nsIDOMEvent(int paramInt)
  {
    super(paramInt);
  }
  
  public int GetType(int paramInt)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 1, getAddress(), paramInt);
  }
  
  public int GetCurrentTarget(int[] paramArrayOfInt)
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 3, getAddress(), paramArrayOfInt);
  }
  
  public int PreventDefault()
  {
    return XPCOM.VtblCall(nsISupports.LAST_METHOD_ID + 9, getAddress());
  }
  
  static
  {
    IIDStore.RegisterIID(nsIDOMEvent.class, 0, new nsID("a66b7b80-ff46-bd97-0080-5f8ae38add32"));
    IIDStore.RegisterIID(nsIDOMEvent.class, 5, new nsID("e85cff74-951f-45c1-be0c-89442ea2f500"));
    IIDStore.RegisterIID(nsIDOMEvent.class, 6, new nsID("02d54f52-a1f5-4ad2-b560-36f14012935e"));
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/internal/mozilla/nsIDOMEvent.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */