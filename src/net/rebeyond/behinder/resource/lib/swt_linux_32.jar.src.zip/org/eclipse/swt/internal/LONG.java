package org.eclipse.swt.internal;

public class LONG
{
  public int value;
  
  public LONG(int paramInt)
  {
    this.value = paramInt;
  }
  
  public boolean equals(Object paramObject)
  {
    if (paramObject == this) {
      return true;
    }
    if (!(paramObject instanceof LONG)) {
      return false;
    }
    LONG localLONG = (LONG)paramObject;
    return localLONG.value == this.value;
  }
  
  public int hashCode()
  {
    return this.value ^ this.value >>> 32;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/internal/LONG.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */