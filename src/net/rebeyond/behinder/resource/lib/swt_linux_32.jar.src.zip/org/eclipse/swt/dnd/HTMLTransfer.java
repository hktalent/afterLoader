package org.eclipse.swt.dnd;

import org.eclipse.swt.internal.Converter;
import org.eclipse.swt.internal.gtk.OS;

public class HTMLTransfer
  extends ByteArrayTransfer
{
  private static HTMLTransfer _instance = new HTMLTransfer();
  private static final String TEXT_HTML = "text/html";
  private static final int TEXT_HTML_ID = registerType("text/html");
  private static final String TEXT_HTML2 = "TEXT/HTML";
  private static final int TEXT_HTML2_ID = registerType("TEXT/HTML");
  
  public static HTMLTransfer getInstance()
  {
    return _instance;
  }
  
  public void javaToNative(Object paramObject, TransferData paramTransferData)
  {
    paramTransferData.result = 0;
    if ((!checkHTML(paramObject)) || (!isSupportedType(paramTransferData))) {
      DND.error(2003);
    }
    String str = (String)paramObject;
    byte[] arrayOfByte = Converter.wcsToMbcs(null, str, true);
    int i = arrayOfByte.length;
    int j = OS.g_malloc(i);
    if (j == 0) {
      return;
    }
    OS.memmove(j, arrayOfByte, i);
    paramTransferData.length = i;
    paramTransferData.format = 8;
    paramTransferData.pValue = j;
    paramTransferData.result = 1;
  }
  
  public Object nativeToJava(TransferData paramTransferData)
  {
    if ((!isSupportedType(paramTransferData)) || (paramTransferData.pValue == 0)) {
      return null;
    }
    int i = paramTransferData.format * paramTransferData.length / 8 / 2 * 2;
    if (i <= 0) {
      return null;
    }
    char[] arrayOfChar1 = new char[1];
    if (i > 1) {
      OS.memmove(arrayOfChar1, paramTransferData.pValue, 2);
    }
    Object localObject;
    String str;
    if ((arrayOfChar1[0] == 65279) || (arrayOfChar1[0] == 65534))
    {
      localObject = new char[i / 2];
      OS.memmove((char[])localObject, paramTransferData.pValue, i);
      str = new String((char[])localObject);
    }
    else
    {
      localObject = new byte[i];
      OS.memmove((byte[])localObject, paramTransferData.pValue, i);
      char[] arrayOfChar2 = Converter.mbcsToWcs(null, (byte[])localObject);
      str = new String(arrayOfChar2);
    }
    int j = str.indexOf(0);
    return j == -1 ? str : str.substring(0, j);
  }
  
  protected int[] getTypeIds()
  {
    return new int[] { TEXT_HTML_ID, TEXT_HTML2_ID };
  }
  
  protected String[] getTypeNames()
  {
    return new String[] { "text/html", "TEXT/HTML" };
  }
  
  boolean checkHTML(Object paramObject)
  {
    return (paramObject != null) && ((paramObject instanceof String)) && (((String)paramObject).length() > 0);
  }
  
  protected boolean validate(Object paramObject)
  {
    return checkHTML(paramObject);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/dnd/HTMLTransfer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */