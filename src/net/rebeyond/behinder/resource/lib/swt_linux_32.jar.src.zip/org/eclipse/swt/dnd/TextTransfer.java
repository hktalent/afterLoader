package org.eclipse.swt.dnd;

import org.eclipse.swt.internal.Converter;
import org.eclipse.swt.internal.gtk.OS;

public class TextTransfer
  extends ByteArrayTransfer
{
  private static TextTransfer _instance = new TextTransfer();
  private static final String COMPOUND_TEXT = "COMPOUND_TEXT";
  private static final String UTF8_STRING = "UTF8_STRING";
  private static final String STRING = "STRING";
  private static final int COMPOUND_TEXT_ID = registerType("COMPOUND_TEXT");
  private static final int UTF8_STRING_ID = registerType("UTF8_STRING");
  private static final int STRING_ID = registerType("STRING");
  
  public static TextTransfer getInstance()
  {
    return _instance;
  }
  
  public void javaToNative(Object paramObject, TransferData paramTransferData)
  {
    paramTransferData.result = 0;
    if ((!checkText(paramObject)) || (!isSupportedType(paramTransferData))) {
      DND.error(2003);
    }
    String str = (String)paramObject;
    byte[] arrayOfByte = Converter.wcsToMbcs(null, str, true);
    if (paramTransferData.type == COMPOUND_TEXT_ID)
    {
      int[] arrayOfInt1 = new int[1];
      int[] arrayOfInt2 = new int[1];
      int[] arrayOfInt3 = new int[1];
      int[] arrayOfInt4 = new int[1];
      boolean bool;
      if (OS.GTK_VERSION >= OS.VERSION(2, 24, 0)) {
        bool = OS.gdk_x11_display_utf8_to_compound_text(OS.gdk_display_get_default(), arrayOfByte, arrayOfInt1, arrayOfInt2, arrayOfInt3, arrayOfInt4);
      } else {
        bool = OS.gdk_utf8_to_compound_text(arrayOfByte, arrayOfInt1, arrayOfInt2, arrayOfInt3, arrayOfInt4);
      }
      if (!bool) {
        return;
      }
      paramTransferData.type = arrayOfInt1[0];
      paramTransferData.format = arrayOfInt2[0];
      paramTransferData.length = arrayOfInt4[0];
      paramTransferData.pValue = arrayOfInt3[0];
      paramTransferData.result = 1;
    }
    int i;
    if (paramTransferData.type == UTF8_STRING_ID)
    {
      i = OS.g_malloc(arrayOfByte.length);
      if (i == 0) {
        return;
      }
      OS.memmove(i, arrayOfByte, arrayOfByte.length);
      paramTransferData.type = UTF8_STRING_ID;
      paramTransferData.format = 8;
      paramTransferData.length = (arrayOfByte.length - 1);
      paramTransferData.pValue = i;
      paramTransferData.result = 1;
    }
    if (paramTransferData.type == STRING_ID)
    {
      i = OS.gdk_utf8_to_string_target(arrayOfByte);
      if (i == 0) {
        return;
      }
      paramTransferData.type = STRING_ID;
      paramTransferData.format = 8;
      paramTransferData.length = OS.strlen(i);
      paramTransferData.pValue = i;
      paramTransferData.result = 1;
    }
  }
  
  public Object nativeToJava(TransferData paramTransferData)
  {
    if ((!isSupportedType(paramTransferData)) || (paramTransferData.pValue == 0)) {
      return null;
    }
    int[] arrayOfInt1 = new int[1];
    int i = OS.gdk_text_property_to_utf8_list_for_display(OS.gdk_display_get_default(), paramTransferData.type, paramTransferData.format, paramTransferData.pValue, paramTransferData.length, arrayOfInt1);
    if (i == 0) {
      return null;
    }
    int[] arrayOfInt2 = new int[1];
    OS.memmove(arrayOfInt2, arrayOfInt1[0], OS.PTR_SIZEOF);
    int j = OS.strlen(arrayOfInt2[0]);
    byte[] arrayOfByte = new byte[j];
    OS.memmove(arrayOfByte, arrayOfInt2[0], j);
    OS.g_strfreev(arrayOfInt1[0]);
    char[] arrayOfChar = Converter.mbcsToWcs(null, arrayOfByte);
    String str = new String(arrayOfChar);
    int k = str.indexOf(0);
    return k == -1 ? str : str.substring(0, k);
  }
  
  protected int[] getTypeIds()
  {
    return new int[] { UTF8_STRING_ID, COMPOUND_TEXT_ID, STRING_ID };
  }
  
  protected String[] getTypeNames()
  {
    return new String[] { "UTF8_STRING", "COMPOUND_TEXT", "STRING" };
  }
  
  boolean checkText(Object paramObject)
  {
    return (paramObject != null) && ((paramObject instanceof String)) && (((String)paramObject).length() > 0);
  }
  
  protected boolean validate(Object paramObject)
  {
    return checkText(paramObject);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/dnd/TextTransfer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */