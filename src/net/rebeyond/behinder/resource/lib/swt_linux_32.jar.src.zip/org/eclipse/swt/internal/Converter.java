package org.eclipse.swt.internal;

import org.eclipse.swt.internal.gtk.OS;

public final class Converter
{
  public static final byte[] NullByteArray = new byte[1];
  public static final byte[] EmptyByteArray = new byte[0];
  public static final char[] EmptyCharArray = new char[0];
  
  public static String defaultCodePage()
  {
    return "UTF8";
  }
  
  public static char[] mbcsToWcs(String paramString, byte[] paramArrayOfByte)
  {
    int[] arrayOfInt = new int[1];
    int i = OS.g_utf8_to_utf16(paramArrayOfByte, paramArrayOfByte.length, null, arrayOfInt, null);
    if (i == 0) {
      return EmptyCharArray;
    }
    int j = arrayOfInt[0];
    char[] arrayOfChar = new char[j];
    OS.memmove(arrayOfChar, i, j * 2);
    OS.g_free(i);
    return arrayOfChar;
  }
  
  public static byte[] wcsToMbcs(String paramString1, String paramString2, boolean paramBoolean)
  {
    int i = paramString2.length();
    char[] arrayOfChar = new char[i];
    paramString2.getChars(0, i, arrayOfChar, 0);
    return wcsToMbcs(paramString1, arrayOfChar, paramBoolean);
  }
  
  public static byte[] wcsToMbcs(String paramString, char[] paramArrayOfChar, boolean paramBoolean)
  {
    int[] arrayOfInt1 = new int[1];
    int[] arrayOfInt2 = new int[1];
    int i = OS.g_utf16_to_utf8(paramArrayOfChar, paramArrayOfChar.length, arrayOfInt1, arrayOfInt2, null);
    if (i == 0) {
      return paramBoolean ? NullByteArray : EmptyByteArray;
    }
    int j = arrayOfInt2[0];
    byte[] arrayOfByte = new byte[j + (paramBoolean ? 1 : 0)];
    OS.memmove(arrayOfByte, i, j);
    OS.g_free(i);
    return arrayOfByte;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/internal/Converter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */