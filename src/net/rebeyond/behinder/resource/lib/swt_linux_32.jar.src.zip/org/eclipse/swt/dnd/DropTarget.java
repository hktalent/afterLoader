package org.eclipse.swt.dnd;

import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.internal.Callback;
import org.eclipse.swt.internal.Converter;
import org.eclipse.swt.internal.gtk.GdkDragContext;
import org.eclipse.swt.internal.gtk.GtkSelectionData;
import org.eclipse.swt.internal.gtk.GtkTargetEntry;
import org.eclipse.swt.internal.gtk.OS;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.Tree;
import org.eclipse.swt.widgets.Widget;

public class DropTarget
  extends Widget
{
  Control control;
  Listener controlListener;
  Transfer[] transferAgents = new Transfer[0];
  DropTargetEffect dropEffect;
  TransferData selectedDataType;
  int selectedOperation;
  int keyOperation = -1;
  long dragOverStart;
  Runnable dragOverHeartbeat;
  DNDEvent dragOverEvent;
  int drag_motion_handler;
  int drag_leave_handler;
  int drag_data_received_handler;
  int drag_drop_handler;
  static final String DEFAULT_DROP_TARGET_EFFECT = "DEFAULT_DROP_TARGET_EFFECT";
  static final String IS_ACTIVE = "org.eclipse.swt.internal.control.isactive";
  static final int DRAGOVER_HYSTERESIS = 50;
  static Callback Drag_Motion = new Callback(DropTarget.class, "Drag_Motion", 5);
  static Callback Drag_Leave;
  static Callback Drag_Data_Received;
  static Callback Drag_Drop;
  
  public DropTarget(Control paramControl, int paramInt)
  {
    super(paramControl, checkStyle(paramInt));
    this.control = paramControl;
    if ((Drag_Motion == null) || (Drag_Leave == null) || (Drag_Data_Received == null) || (Drag_Drop == null)) {
      DND.error(2001);
    }
    if (paramControl.getData("DropTarget") != null) {
      DND.error(2001);
    }
    paramControl.setData("DropTarget", this);
    this.drag_motion_handler = OS.g_signal_connect(paramControl.handle, OS.drag_motion, Drag_Motion.getAddress(), 0);
    this.drag_leave_handler = OS.g_signal_connect(paramControl.handle, OS.drag_leave, Drag_Leave.getAddress(), 0);
    this.drag_data_received_handler = OS.g_signal_connect(paramControl.handle, OS.drag_data_received, Drag_Data_Received.getAddress(), 0);
    this.drag_drop_handler = OS.g_signal_connect(paramControl.handle, OS.drag_drop, Drag_Drop.getAddress(), 0);
    this.controlListener = new Listener()
    {
      public void handleEvent(Event paramAnonymousEvent)
      {
        if (!DropTarget.this.isDisposed()) {
          DropTarget.this.dispose();
        }
      }
    };
    paramControl.addListener(12, this.controlListener);
    addListener(12, new Listener()
    {
      public void handleEvent(Event paramAnonymousEvent)
      {
        DropTarget.this.onDispose();
      }
    });
    Object localObject = paramControl.getData("DEFAULT_DROP_TARGET_EFFECT");
    if ((localObject instanceof DropTargetEffect)) {
      this.dropEffect = ((DropTargetEffect)localObject);
    } else if ((paramControl instanceof Table)) {
      this.dropEffect = new TableDropTargetEffect((Table)paramControl);
    } else if ((paramControl instanceof Tree)) {
      this.dropEffect = new TreeDropTargetEffect((Tree)paramControl);
    }
    this.dragOverHeartbeat = new Runnable()
    {
      public void run()
      {
        Control localControl = DropTarget.this.control;
        if ((localControl == null) || (localControl.isDisposed()) || (DropTarget.this.dragOverStart == 0L)) {
          return;
        }
        long l = System.currentTimeMillis();
        int i = 50;
        if (l < DropTarget.this.dragOverStart)
        {
          i = (int)(DropTarget.this.dragOverStart - l);
        }
        else
        {
          DropTarget.this.dragOverEvent.time += 50;
          int j = DropTarget.this.dragOverEvent.operations;
          TransferData[] arrayOfTransferData1 = DropTarget.this.dragOverEvent.dataTypes;
          TransferData[] arrayOfTransferData2 = new TransferData[arrayOfTransferData1.length];
          System.arraycopy(arrayOfTransferData1, 0, arrayOfTransferData2, 0, arrayOfTransferData2.length);
          DNDEvent localDNDEvent = new DNDEvent();
          localDNDEvent.widget = DropTarget.this.dragOverEvent.widget;
          localDNDEvent.x = DropTarget.this.dragOverEvent.x;
          localDNDEvent.y = DropTarget.this.dragOverEvent.y;
          localDNDEvent.time = DropTarget.this.dragOverEvent.time;
          localDNDEvent.feedback = 1;
          localDNDEvent.dataTypes = arrayOfTransferData2;
          localDNDEvent.dataType = DropTarget.this.selectedDataType;
          localDNDEvent.operations = DropTarget.this.dragOverEvent.operations;
          localDNDEvent.detail = DropTarget.this.selectedOperation;
          if (DropTarget.this.dropEffect != null) {
            localDNDEvent.item = DropTarget.this.dropEffect.getItem(DropTarget.this.dragOverEvent.x, DropTarget.this.dragOverEvent.y);
          }
          DropTarget.this.selectedDataType = null;
          DropTarget.this.selectedOperation = 0;
          DropTarget.this.notifyListeners(2004, localDNDEvent);
          if (localDNDEvent.dataType != null) {
            for (int k = 0; k < arrayOfTransferData1.length; k++) {
              if (arrayOfTransferData1[k].type == localDNDEvent.dataType.type)
              {
                DropTarget.this.selectedDataType = localDNDEvent.dataType;
                break;
              }
            }
          }
          if ((DropTarget.this.selectedDataType != null) && ((localDNDEvent.detail & j) != 0)) {
            DropTarget.this.selectedOperation = localDNDEvent.detail;
          }
        }
        localControl = DropTarget.this.control;
        if ((localControl == null) || (localControl.isDisposed())) {
          return;
        }
        localControl.getDisplay().timerExec(i, DropTarget.this.dragOverHeartbeat);
      }
    };
  }
  
  static int checkStyle(int paramInt)
  {
    if (paramInt == 0) {
      return 2;
    }
    return paramInt;
  }
  
  static int Drag_Data_Received(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7)
  {
    DropTarget localDropTarget = FindDropTarget(paramInt1);
    if (localDropTarget == null) {
      return 0;
    }
    localDropTarget.drag_data_received(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7);
    return 0;
  }
  
  static int Drag_Drop(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
  {
    DropTarget localDropTarget = FindDropTarget(paramInt1);
    if (localDropTarget == null) {
      return 0;
    }
    return localDropTarget.drag_drop(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5) ? 1 : 0;
  }
  
  static int Drag_Leave(int paramInt1, int paramInt2, int paramInt3)
  {
    DropTarget localDropTarget = FindDropTarget(paramInt1);
    if (localDropTarget == null) {
      return 0;
    }
    localDropTarget.drag_leave(paramInt1, paramInt2, paramInt3);
    return 0;
  }
  
  static int Drag_Motion(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
  {
    DropTarget localDropTarget = FindDropTarget(paramInt1);
    if (localDropTarget == null) {
      return 0;
    }
    return localDropTarget.drag_motion(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5) ? 1 : 0;
  }
  
  static DropTarget FindDropTarget(int paramInt)
  {
    Display localDisplay = Display.findDisplay(Thread.currentThread());
    if ((localDisplay == null) || (localDisplay.isDisposed())) {
      return null;
    }
    Widget localWidget = localDisplay.findWidget(paramInt);
    if (localWidget == null) {
      return null;
    }
    return (DropTarget)localWidget.getData("DropTarget");
  }
  
  public void addDropListener(DropTargetListener paramDropTargetListener)
  {
    if (paramDropTargetListener == null) {
      DND.error(4);
    }
    DNDListener localDNDListener = new DNDListener(paramDropTargetListener);
    localDNDListener.dndWidget = this;
    addListener(2002, localDNDListener);
    addListener(2003, localDNDListener);
    addListener(2004, localDNDListener);
    addListener(2005, localDNDListener);
    addListener(2006, localDNDListener);
    addListener(2007, localDNDListener);
  }
  
  protected void checkSubclass()
  {
    String str1 = getClass().getName();
    String str2 = DropTarget.class.getName();
    if (!str2.equals(str1)) {
      DND.error(43);
    }
  }
  
  void drag_data_received(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7)
  {
    DNDEvent localDNDEvent = new DNDEvent();
    if ((paramInt5 == 0) || (!setEventData(paramInt2, paramInt3, paramInt4, paramInt7, localDNDEvent)))
    {
      this.keyOperation = -1;
      return;
    }
    this.keyOperation = -1;
    int i = localDNDEvent.operations;
    Object localObject = null;
    TransferData localTransferData = new TransferData();
    int j;
    int k;
    int m;
    int n;
    if (OS.GTK_VERSION >= OS.VERSION(2, 14, 0))
    {
      j = OS.gtk_selection_data_get_length(paramInt5);
      k = OS.gtk_selection_data_get_format(paramInt5);
      m = OS.gtk_selection_data_get_data(paramInt5);
      n = OS.gtk_selection_data_get_data_type(paramInt5);
    }
    else
    {
      GtkSelectionData localGtkSelectionData = new GtkSelectionData();
      OS.memmove(localGtkSelectionData, paramInt5, GtkSelectionData.sizeof);
      j = localGtkSelectionData.length;
      k = localGtkSelectionData.format;
      m = localGtkSelectionData.data;
      n = localGtkSelectionData.type;
    }
    if (m != 0)
    {
      localTransferData.type = n;
      localTransferData.length = j;
      localTransferData.pValue = m;
      localTransferData.format = k;
      for (int i1 = 0; i1 < this.transferAgents.length; i1++)
      {
        Transfer localTransfer = this.transferAgents[i1];
        if ((localTransfer != null) && (localTransfer.isSupportedType(localTransferData)))
        {
          localObject = localTransfer.nativeToJava(localTransferData);
          break;
        }
      }
    }
    if (localObject == null) {
      this.selectedOperation = 0;
    }
    localDNDEvent.detail = this.selectedOperation;
    localDNDEvent.dataType = localTransferData;
    localDNDEvent.data = localObject;
    this.selectedOperation = 0;
    notifyListeners(2006, localDNDEvent);
    if ((i & localDNDEvent.detail) == localDNDEvent.detail) {
      this.selectedOperation = localDNDEvent.detail;
    }
    OS.g_signal_stop_emission_by_name(paramInt1, OS.drag_data_received);
    OS.gtk_drag_finish(paramInt2, this.selectedOperation != 0, this.selectedOperation == 2, paramInt7);
  }
  
  boolean drag_drop(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
  {
    DNDEvent localDNDEvent = new DNDEvent();
    if (!setEventData(paramInt2, paramInt3, paramInt4, paramInt5, localDNDEvent))
    {
      this.keyOperation = -1;
      return false;
    }
    this.keyOperation = -1;
    int i = localDNDEvent.operations;
    TransferData[] arrayOfTransferData = new TransferData[localDNDEvent.dataTypes.length];
    System.arraycopy(localDNDEvent.dataTypes, 0, arrayOfTransferData, 0, arrayOfTransferData.length);
    localDNDEvent.dataType = this.selectedDataType;
    localDNDEvent.detail = this.selectedOperation;
    this.selectedDataType = null;
    this.selectedOperation = 0;
    notifyListeners(2007, localDNDEvent);
    if (localDNDEvent.dataType != null) {
      for (int j = 0; j < arrayOfTransferData.length; j++) {
        if (arrayOfTransferData[j].type == localDNDEvent.dataType.type)
        {
          this.selectedDataType = arrayOfTransferData[j];
          break;
        }
      }
    }
    if ((this.selectedDataType != null) && ((localDNDEvent.detail & i) == localDNDEvent.detail)) {
      this.selectedOperation = localDNDEvent.detail;
    }
    if (this.selectedOperation == 0) {
      return false;
    }
    OS.gtk_drag_get_data(paramInt1, paramInt2, this.selectedDataType.type, paramInt5);
    return true;
  }
  
  void drag_leave(int paramInt1, int paramInt2, int paramInt3)
  {
    updateDragOverHover(0L, null);
    if (this.keyOperation == -1) {
      return;
    }
    this.keyOperation = -1;
    DNDEvent localDNDEvent = new DNDEvent();
    localDNDEvent.widget = this;
    localDNDEvent.time = paramInt3;
    localDNDEvent.detail = 0;
    notifyListeners(2003, localDNDEvent);
  }
  
  boolean drag_motion(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
  {
    int i = this.keyOperation;
    if ((i == -1) || (!((Boolean)this.control.getData("org.eclipse.swt.internal.control.isactive")).booleanValue()))
    {
      this.selectedDataType = null;
      this.selectedOperation = 0;
    }
    DNDEvent localDNDEvent = new DNDEvent();
    if (!setEventData(paramInt2, paramInt3, paramInt4, paramInt5, localDNDEvent))
    {
      this.keyOperation = -1;
      OS.gdk_drag_status(paramInt2, 0, paramInt5);
      return false;
    }
    int j = localDNDEvent.operations;
    TransferData[] arrayOfTransferData = new TransferData[localDNDEvent.dataTypes.length];
    System.arraycopy(localDNDEvent.dataTypes, 0, arrayOfTransferData, 0, arrayOfTransferData.length);
    if (i == -1)
    {
      localDNDEvent.type = 2002;
    }
    else if (this.keyOperation == i)
    {
      localDNDEvent.type = 2004;
      localDNDEvent.dataType = this.selectedDataType;
      localDNDEvent.detail = this.selectedOperation;
    }
    else
    {
      localDNDEvent.type = 2005;
      localDNDEvent.dataType = this.selectedDataType;
    }
    updateDragOverHover(50L, localDNDEvent);
    this.selectedDataType = null;
    this.selectedOperation = 0;
    notifyListeners(localDNDEvent.type, localDNDEvent);
    if (localDNDEvent.detail == 16) {
      localDNDEvent.detail = ((j & 0x2) != 0 ? 2 : 0);
    }
    if (localDNDEvent.dataType != null) {
      for (int k = 0; k < arrayOfTransferData.length; k++) {
        if (arrayOfTransferData[k].type == localDNDEvent.dataType.type)
        {
          this.selectedDataType = arrayOfTransferData[k];
          break;
        }
      }
    }
    if ((this.selectedDataType != null) && ((j & localDNDEvent.detail) != 0)) {
      this.selectedOperation = localDNDEvent.detail;
    }
    switch (this.selectedOperation)
    {
    case 0: 
      OS.gdk_drag_status(paramInt2, 0, paramInt5);
      break;
    case 1: 
      OS.gdk_drag_status(paramInt2, 2, paramInt5);
      break;
    case 2: 
      OS.gdk_drag_status(paramInt2, 4, paramInt5);
      break;
    case 4: 
      OS.gdk_drag_status(paramInt2, 8, paramInt5);
    }
    if (i == -1) {
      this.dragOverHeartbeat.run();
    }
    return true;
  }
  
  public Control getControl()
  {
    return this.control;
  }
  
  public DropTargetListener[] getDropListeners()
  {
    Listener[] arrayOfListener = getListeners(2002);
    int i = arrayOfListener.length;
    DropTargetListener[] arrayOfDropTargetListener1 = new DropTargetListener[i];
    int j = 0;
    for (int k = 0; k < i; k++)
    {
      Listener localListener = arrayOfListener[k];
      if ((localListener instanceof DNDListener))
      {
        arrayOfDropTargetListener1[j] = ((DropTargetListener)((DNDListener)localListener).getEventListener());
        j++;
      }
    }
    if (j == i) {
      return arrayOfDropTargetListener1;
    }
    DropTargetListener[] arrayOfDropTargetListener2 = new DropTargetListener[j];
    System.arraycopy(arrayOfDropTargetListener1, 0, arrayOfDropTargetListener2, 0, j);
    return arrayOfDropTargetListener2;
  }
  
  public DropTargetEffect getDropTargetEffect()
  {
    return this.dropEffect;
  }
  
  int getOperationFromKeyState()
  {
    int[] arrayOfInt = new int[1];
    if (OS.GTK3)
    {
      i = OS.gdk_get_default_root_window();
      j = OS.gdk_display_get_device_manager(OS.gdk_window_get_display(i));
      int k = OS.gdk_device_manager_get_client_pointer(j);
      OS.gdk_window_get_device_position(i, k, null, null, arrayOfInt);
    }
    else
    {
      OS.gdk_window_get_pointer(0, null, null, arrayOfInt);
    }
    int i = (arrayOfInt[0] & 0x4) != 0 ? 1 : 0;
    int j = (arrayOfInt[0] & 0x1) != 0 ? 1 : 0;
    if ((i != 0) && (j != 0)) {
      return 4;
    }
    if (i != 0) {
      return 1;
    }
    if (j != 0) {
      return 2;
    }
    return 16;
  }
  
  public Transfer[] getTransfer()
  {
    return this.transferAgents;
  }
  
  void onDispose()
  {
    if (this.control == null) {
      return;
    }
    OS.g_signal_handler_disconnect(this.control.handle, this.drag_motion_handler);
    OS.g_signal_handler_disconnect(this.control.handle, this.drag_leave_handler);
    OS.g_signal_handler_disconnect(this.control.handle, this.drag_data_received_handler);
    OS.g_signal_handler_disconnect(this.control.handle, this.drag_drop_handler);
    if (this.transferAgents.length != 0) {
      OS.gtk_drag_dest_unset(this.control.handle);
    }
    this.transferAgents = null;
    if (this.controlListener != null) {
      this.control.removeListener(12, this.controlListener);
    }
    this.control.setData("DropTarget", null);
    this.control = null;
    this.controlListener = null;
  }
  
  int opToOsOp(int paramInt)
  {
    int i = 0;
    if ((paramInt & 0x1) == 1) {
      i |= 0x2;
    }
    if ((paramInt & 0x2) == 2) {
      i |= 0x4;
    }
    if ((paramInt & 0x4) == 4) {
      i |= 0x8;
    }
    return i;
  }
  
  int osOpToOp(int paramInt)
  {
    int i = 0;
    if ((paramInt & 0x2) == 2) {
      i |= 0x1;
    }
    if ((paramInt & 0x4) == 4) {
      i |= 0x2;
    }
    if ((paramInt & 0x8) == 8) {
      i |= 0x4;
    }
    return i;
  }
  
  public void removeDropListener(DropTargetListener paramDropTargetListener)
  {
    if (paramDropTargetListener == null) {
      DND.error(4);
    }
    removeListener(2002, paramDropTargetListener);
    removeListener(2003, paramDropTargetListener);
    removeListener(2004, paramDropTargetListener);
    removeListener(2005, paramDropTargetListener);
    removeListener(2006, paramDropTargetListener);
    removeListener(2007, paramDropTargetListener);
  }
  
  public void setTransfer(Transfer[] paramArrayOfTransfer)
  {
    if (paramArrayOfTransfer == null) {
      DND.error(4);
    }
    if (this.transferAgents.length != 0) {
      OS.gtk_drag_dest_unset(this.control.handle);
    }
    this.transferAgents = paramArrayOfTransfer;
    Object localObject = new GtkTargetEntry[0];
    for (int i = 0; i < paramArrayOfTransfer.length; i++)
    {
      Transfer localTransfer = paramArrayOfTransfer[i];
      if (localTransfer != null)
      {
        int[] arrayOfInt = localTransfer.getTypeIds();
        String[] arrayOfString = localTransfer.getTypeNames();
        for (int m = 0; m < arrayOfInt.length; m++)
        {
          GtkTargetEntry localGtkTargetEntry = new GtkTargetEntry();
          byte[] arrayOfByte = Converter.wcsToMbcs(null, arrayOfString[m], true);
          localGtkTargetEntry.target = OS.g_malloc(arrayOfByte.length);
          OS.memmove(localGtkTargetEntry.target, arrayOfByte, arrayOfByte.length);
          localGtkTargetEntry.info = arrayOfInt[m];
          GtkTargetEntry[] arrayOfGtkTargetEntry = new GtkTargetEntry[localObject.length + 1];
          System.arraycopy(localObject, 0, arrayOfGtkTargetEntry, 0, localObject.length);
          arrayOfGtkTargetEntry[localObject.length] = localGtkTargetEntry;
          localObject = arrayOfGtkTargetEntry;
        }
      }
    }
    i = OS.g_malloc(localObject.length * GtkTargetEntry.sizeof);
    for (int j = 0; j < localObject.length; j++) {
      OS.memmove(i + j * GtkTargetEntry.sizeof, localObject[j], GtkTargetEntry.sizeof);
    }
    j = opToOsOp(getStyle());
    if (((this.control instanceof Combo)) && ((this.control.getStyle() & 0x8) == 0))
    {
      k = OS.gtk_bin_get_child(this.control.handle);
      if (k != 0) {
        OS.gtk_drag_dest_unset(k);
      }
    }
    OS.gtk_drag_dest_set(this.control.handle, 0, i, localObject.length, j);
    for (int k = 0; k < localObject.length; k++) {
      OS.g_free(localObject[k].target);
    }
  }
  
  public void setDropTargetEffect(DropTargetEffect paramDropTargetEffect)
  {
    this.dropEffect = paramDropTargetEffect;
  }
  
  boolean setEventData(int paramInt1, int paramInt2, int paramInt3, int paramInt4, DNDEvent paramDNDEvent)
  {
    if (paramInt1 == 0) {
      return false;
    }
    int i = 0;
    int j = 0;
    if (OS.GTK3)
    {
      i = OS.gdk_drag_context_list_targets(paramInt1);
      j = OS.gdk_drag_context_get_actions(paramInt1);
    }
    else
    {
      GdkDragContext localGdkDragContext = new GdkDragContext();
      OS.memmove(localGdkDragContext, paramInt1, GdkDragContext.sizeof);
      i = localGdkDragContext.targets;
      j = localGdkDragContext.actions;
    }
    if (i == 0) {
      return false;
    }
    int k = getStyle();
    int m = osOpToOp(j) & k;
    if (m == 0) {
      return false;
    }
    int n = getOperationFromKeyState();
    this.keyOperation = n;
    if (n == 16)
    {
      if ((k & 0x10) == 0) {
        n = (m & 0x2) != 0 ? 2 : 0;
      }
    }
    else if ((n & m) == 0) {
      n = 0;
    }
    int i1 = OS.g_list_length(i);
    Object localObject1 = new TransferData[0];
    for (int i2 = 0; i2 < i1; i2++)
    {
      int i3 = OS.g_list_nth_data(i, i2);
      localObject2 = new TransferData();
      ((TransferData)localObject2).type = i3;
      for (int i4 = 0; i4 < this.transferAgents.length; i4++)
      {
        Transfer localTransfer = this.transferAgents[i4];
        if ((localTransfer != null) && (localTransfer.isSupportedType((TransferData)localObject2)))
        {
          TransferData[] arrayOfTransferData = new TransferData[localObject1.length + 1];
          System.arraycopy(localObject1, 0, arrayOfTransferData, 0, localObject1.length);
          arrayOfTransferData[localObject1.length] = localObject2;
          localObject1 = arrayOfTransferData;
          break;
        }
      }
    }
    if (localObject1.length == 0) {
      return false;
    }
    if (OS.GTK_VERSION >= OS.VERSION(2, 14, 0)) {
      i2 = OS.gtk_widget_get_window(this.control.handle);
    } else {
      i2 = OS.GTK_WIDGET_WINDOW(this.control.handle);
    }
    int[] arrayOfInt = new int[1];
    Object localObject2 = new int[1];
    OS.gdk_window_get_origin(i2, arrayOfInt, (int[])localObject2);
    Point localPoint = new Point(arrayOfInt[0] + paramInt2, localObject2[0] + paramInt3);
    paramDNDEvent.widget = this;
    paramDNDEvent.x = localPoint.x;
    paramDNDEvent.y = localPoint.y;
    paramDNDEvent.time = paramInt4;
    paramDNDEvent.feedback = 1;
    paramDNDEvent.dataTypes = ((TransferData[])localObject1);
    paramDNDEvent.dataType = localObject1[0];
    paramDNDEvent.operations = m;
    paramDNDEvent.detail = n;
    if (this.dropEffect != null) {
      paramDNDEvent.item = this.dropEffect.getItem(localPoint.x, localPoint.y);
    }
    return true;
  }
  
  void updateDragOverHover(long paramLong, DNDEvent paramDNDEvent)
  {
    if (paramLong == 0L)
    {
      this.dragOverStart = 0L;
      this.dragOverEvent = null;
      return;
    }
    this.dragOverStart = (System.currentTimeMillis() + paramLong);
    if (this.dragOverEvent == null) {
      this.dragOverEvent = new DNDEvent();
    }
    this.dragOverEvent.x = paramDNDEvent.x;
    this.dragOverEvent.y = paramDNDEvent.y;
    TransferData[] arrayOfTransferData = new TransferData[paramDNDEvent.dataTypes.length];
    System.arraycopy(paramDNDEvent.dataTypes, 0, arrayOfTransferData, 0, arrayOfTransferData.length);
    this.dragOverEvent.dataTypes = arrayOfTransferData;
    this.dragOverEvent.operations = paramDNDEvent.operations;
    this.dragOverEvent.time = paramDNDEvent.time;
  }
  
  static
  {
    if (Drag_Motion.getAddress() == 0) {
      SWT.error(3);
    }
    Drag_Leave = new Callback(DropTarget.class, "Drag_Leave", 3);
    if (Drag_Leave.getAddress() == 0) {
      SWT.error(3);
    }
    Drag_Data_Received = new Callback(DropTarget.class, "Drag_Data_Received", 7);
    if (Drag_Data_Received.getAddress() == 0) {
      SWT.error(3);
    }
    Drag_Drop = new Callback(DropTarget.class, "Drag_Drop", 5);
    if (Drag_Drop.getAddress() == 0) {
      SWT.error(3);
    }
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/dnd/DropTarget.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */