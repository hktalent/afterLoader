package org.eclipse.swt.custom;

class SashFormData
{
  long weight;
  
  String getName()
  {
    String str = getClass().getName();
    int i = str.lastIndexOf('.');
    if (i == -1) {
      return str;
    }
    return str.substring(i + 1, str.length());
  }
  
  public String toString()
  {
    return getName() + " {weight=" + this.weight + "}";
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/custom/SashFormData.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */