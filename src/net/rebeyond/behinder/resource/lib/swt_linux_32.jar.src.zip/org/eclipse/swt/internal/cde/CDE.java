package org.eclipse.swt.internal.cde;

import org.eclipse.swt.internal.Lock;
import org.eclipse.swt.internal.Platform;

public class CDE
  extends Platform
{
  public static final int DtACTION_FILE = 1;
  public static final String DtDTS_DA_ACTION_LIST = "ACTIONS";
  public static final String DtDTS_DA_ICON = "ICON";
  public static final String DtDTS_DA_MIME_TYPE = "MIME_TYPE";
  public static final String DtDTS_DA_NAME_TEMPLATE = "NAME_TEMPLATE";
  
  public static final native int DtActionArg_sizeof();
  
  public static final native boolean _DtAppInitialize(int paramInt1, int paramInt2, int paramInt3, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2);
  
  public static final boolean DtAppInitialize(int paramInt1, int paramInt2, int paramInt3, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
  {
    lock.lock();
    try
    {
      boolean bool = _DtAppInitialize(paramInt1, paramInt2, paramInt3, paramArrayOfByte1, paramArrayOfByte2);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _DtDbLoad();
  
  public static final void DtDbLoad()
  {
    lock.lock();
    try
    {
      _DtDbLoad();
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _DtDtsDataTypeNames();
  
  public static final int DtDtsDataTypeNames()
  {
    lock.lock();
    try
    {
      int i = _DtDtsDataTypeNames();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _DtDtsFileToDataType(byte[] paramArrayOfByte);
  
  public static final int DtDtsFileToDataType(byte[] paramArrayOfByte)
  {
    lock.lock();
    try
    {
      int i = _DtDtsFileToDataType(paramArrayOfByte);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native boolean _DtDtsDataTypeIsAction(byte[] paramArrayOfByte);
  
  public static final boolean DtDtsDataTypeIsAction(byte[] paramArrayOfByte)
  {
    lock.lock();
    try
    {
      boolean bool = _DtDtsDataTypeIsAction(paramArrayOfByte);
      return bool;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _DtDtsDataTypeToAttributeValue(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3);
  
  public static final int DtDtsDataTypeToAttributeValue(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3)
  {
    lock.lock();
    try
    {
      int i = _DtDtsDataTypeToAttributeValue(paramArrayOfByte1, paramArrayOfByte2, paramArrayOfByte3);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _DtDtsFreeDataType(int paramInt);
  
  public static final void DtDtsFreeDataType(int paramInt)
  {
    lock.lock();
    try
    {
      _DtDtsFreeDataType(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _DtDtsFreeDataTypeNames(int paramInt);
  
  public static final void DtDtsFreeDataTypeNames(int paramInt)
  {
    lock.lock();
    try
    {
      _DtDtsFreeDataTypeNames(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _DtDtsFreeAttributeValue(int paramInt);
  
  public static final void DtDtsFreeAttributeValue(int paramInt)
  {
    lock.lock();
    try
    {
      _DtDtsFreeAttributeValue(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native long _DtActionInvoke(int paramInt1, byte[] paramArrayOfByte1, DtActionArg paramDtActionArg, int paramInt2, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3, byte[] paramArrayOfByte4, int paramInt3, int paramInt4, int paramInt5);
  
  public static final long DtActionInvoke(int paramInt1, byte[] paramArrayOfByte1, DtActionArg paramDtActionArg, int paramInt2, byte[] paramArrayOfByte2, byte[] paramArrayOfByte3, byte[] paramArrayOfByte4, int paramInt3, int paramInt4, int paramInt5)
  {
    lock.lock();
    try
    {
      long l = _DtActionInvoke(paramInt1, paramArrayOfByte1, paramDtActionArg, paramInt2, paramArrayOfByte2, paramArrayOfByte3, paramArrayOfByte4, paramInt3, paramInt4, paramInt5);
      return l;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _topLevelShellWidgetClass();
  
  public static final int topLevelShellWidgetClass()
  {
    lock.lock();
    try
    {
      int i = _topLevelShellWidgetClass();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _XtAppCreateShell(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, int paramInt1, int paramInt2, int[] paramArrayOfInt, int paramInt3);
  
  public static final int XtAppCreateShell(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, int paramInt1, int paramInt2, int[] paramArrayOfInt, int paramInt3)
  {
    lock.lock();
    try
    {
      int i = _XtAppCreateShell(paramArrayOfByte1, paramArrayOfByte2, paramInt1, paramInt2, paramArrayOfInt, paramInt3);
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native int _XtCreateApplicationContext();
  
  public static final int XtCreateApplicationContext()
  {
    lock.lock();
    try
    {
      int i = _XtCreateApplicationContext();
      return i;
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _XtDisplayInitialize(int paramInt1, int paramInt2, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, int paramInt3, int paramInt4, int[] paramArrayOfInt, int paramInt5);
  
  public static final void XtDisplayInitialize(int paramInt1, int paramInt2, byte[] paramArrayOfByte1, byte[] paramArrayOfByte2, int paramInt3, int paramInt4, int[] paramArrayOfInt, int paramInt5)
  {
    lock.lock();
    try
    {
      _XtDisplayInitialize(paramInt1, paramInt2, paramArrayOfByte1, paramArrayOfByte2, paramInt3, paramInt4, paramArrayOfInt, paramInt5);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _XtRealizeWidget(int paramInt);
  
  public static final void XtRealizeWidget(int paramInt)
  {
    lock.lock();
    try
    {
      _XtRealizeWidget(paramInt);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _XtResizeWidget(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  public static final void XtResizeWidget(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    lock.lock();
    try
    {
      _XtResizeWidget(paramInt1, paramInt2, paramInt3, paramInt4);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _XtSetMappedWhenManaged(int paramInt, boolean paramBoolean);
  
  public static final void XtSetMappedWhenManaged(int paramInt, boolean paramBoolean)
  {
    lock.lock();
    try
    {
      _XtSetMappedWhenManaged(paramInt, paramBoolean);
    }
    finally
    {
      lock.unlock();
    }
  }
  
  public static final native void _XtToolkitInitialize();
  
  public static final void XtToolkitInitialize()
  {
    lock.lock();
    try
    {
      _XtToolkitInitialize();
    }
    finally
    {
      lock.unlock();
    }
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/internal/cde/CDE.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */