package org.eclipse.swt.graphics;

import org.eclipse.swt.SWT;
import org.eclipse.swt.internal.gtk.GdkColor;
import org.eclipse.swt.internal.gtk.OS;

public final class Color
  extends Resource
{
  public GdkColor handle;
  
  Color(Device paramDevice)
  {
    super(paramDevice);
  }
  
  public Color(Device paramDevice, int paramInt1, int paramInt2, int paramInt3)
  {
    super(paramDevice);
    init(paramInt1, paramInt2, paramInt3);
    init();
  }
  
  public Color(Device paramDevice, RGB paramRGB)
  {
    super(paramDevice);
    if (paramRGB == null) {
      SWT.error(4);
    }
    init(paramRGB.red, paramRGB.green, paramRGB.blue);
    init();
  }
  
  void destroy()
  {
    int i = this.handle.pixel;
    if (this.device.colorRefCount != null) {
      if (this.device.colorRefCount[i] -= 1 == 0) {
        this.device.gdkColors[i] = null;
      }
    }
    if (!OS.GTK3)
    {
      int j = OS.gdk_colormap_get_system();
      OS.gdk_colormap_free_colors(j, this.handle, 1);
    }
    this.handle = null;
  }
  
  public boolean equals(Object paramObject)
  {
    if (paramObject == this) {
      return true;
    }
    if (!(paramObject instanceof Color)) {
      return false;
    }
    Color localColor = (Color)paramObject;
    GdkColor localGdkColor = localColor.handle;
    if (this.handle == localGdkColor) {
      return true;
    }
    return (this.device == localColor.device) && (this.handle.red == localGdkColor.red) && (this.handle.green == localGdkColor.green) && (this.handle.blue == localGdkColor.blue);
  }
  
  public int getBlue()
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    return this.handle.blue >> 8 & 0xFF;
  }
  
  public int getGreen()
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    return this.handle.green >> 8 & 0xFF;
  }
  
  public int getRed()
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    return this.handle.red >> 8 & 0xFF;
  }
  
  public int hashCode()
  {
    if (isDisposed()) {
      return 0;
    }
    return this.handle.red ^ this.handle.green ^ this.handle.blue;
  }
  
  public RGB getRGB()
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    return new RGB(getRed(), getGreen(), getBlue());
  }
  
  public static Color gtk_new(Device paramDevice, GdkColor paramGdkColor)
  {
    Color localColor = new Color(paramDevice);
    localColor.handle = paramGdkColor;
    return localColor;
  }
  
  void init(int paramInt1, int paramInt2, int paramInt3)
  {
    if ((paramInt1 > 255) || (paramInt1 < 0) || (paramInt2 > 255) || (paramInt2 < 0) || (paramInt3 > 255) || (paramInt3 < 0)) {
      SWT.error(5);
    }
    GdkColor localGdkColor1 = new GdkColor();
    localGdkColor1.red = ((short)(paramInt1 & 0xFF | (paramInt1 & 0xFF) << 8));
    localGdkColor1.green = ((short)(paramInt2 & 0xFF | (paramInt2 & 0xFF) << 8));
    localGdkColor1.blue = ((short)(paramInt3 & 0xFF | (paramInt3 & 0xFF) << 8));
    if (!OS.GTK3)
    {
      int i = OS.gdk_colormap_get_system();
      if (!OS.gdk_colormap_alloc_color(i, localGdkColor1, true, true))
      {
        localGdkColor1 = new GdkColor();
        OS.gdk_colormap_alloc_color(i, localGdkColor1, true, true);
      }
    }
    this.handle = localGdkColor1;
    if (this.device.colorRefCount != null)
    {
      GdkColor localGdkColor2 = new GdkColor();
      localGdkColor2.red = this.handle.red;
      localGdkColor2.green = this.handle.green;
      localGdkColor2.blue = this.handle.blue;
      localGdkColor2.pixel = this.handle.pixel;
      this.device.gdkColors[localGdkColor2.pixel] = localGdkColor2;
      this.device.colorRefCount[localGdkColor2.pixel] += 1;
    }
  }
  
  public boolean isDisposed()
  {
    return this.handle == null;
  }
  
  public String toString()
  {
    if (isDisposed()) {
      return "Color {*DISPOSED*}";
    }
    return "Color {" + getRed() + ", " + getGreen() + ", " + getBlue() + "}";
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/graphics/Color.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */