package org.eclipse.swt.internal.image;

final class JPEGAppn
  extends JPEGVariableSizeSegment
{
  public JPEGAppn(byte[] paramArrayOfByte)
  {
    super(paramArrayOfByte);
  }
  
  public JPEGAppn(LEDataInputStream paramLEDataInputStream)
  {
    super(paramLEDataInputStream);
  }
  
  public boolean verify()
  {
    int i = getSegmentMarker();
    return (i >= 65504) && (i <= 65519);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/internal/image/JPEGAppn.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */