package org.eclipse.swt.internal.mozilla;

public class nsIDOMMouseEvent
  extends nsIDOMUIEvent
{
  static final int LAST_METHOD_ID = nsIDOMUIEvent.LAST_METHOD_ID + (IsXULRunner10() ? 14 : IsXULRunner24() ? 18 : 11);
  static final String NS_IDOMMOUSEEVENT_IID_STR = "ff751edc-8b02-aae7-0010-8301838a3123";
  static final String NS_IDOMMOUSEEVENT_10_IID_STR = "7f57aa45-6792-4d8b-ba5b-201533cf0b2f";
  static final String NS_IDOMMOUSEEVENT_24_IID_STR = "afb2e57b-2822-4969-b2a9-0cada6859534";
  public static final int MOZ_SOURCE_UNKNOWN = 0;
  public static final int MOZ_SOURCE_MOUSE = 1;
  public static final int MOZ_SOURCE_PEN = 2;
  public static final int MOZ_SOURCE_ERASER = 3;
  public static final int MOZ_SOURCE_CURSOR = 4;
  public static final int MOZ_SOURCE_TOUCH = 5;
  public static final int MOZ_SOURCE_KEYBOARD = 6;
  
  public nsIDOMMouseEvent(int paramInt)
  {
    super(paramInt);
  }
  
  public int GetScreenX(int[] paramArrayOfInt)
  {
    return XPCOM.VtblCall(nsIDOMUIEvent.LAST_METHOD_ID + 1, getAddress(), paramArrayOfInt);
  }
  
  public int GetScreenY(int[] paramArrayOfInt)
  {
    return XPCOM.VtblCall(nsIDOMUIEvent.LAST_METHOD_ID + 2, getAddress(), paramArrayOfInt);
  }
  
  public int GetCtrlKey(int[] paramArrayOfInt)
  {
    return XPCOM.VtblCall(nsIDOMUIEvent.LAST_METHOD_ID + (IsXULRunner24() ? 7 : 5), getAddress(), paramArrayOfInt);
  }
  
  public int GetShiftKey(int[] paramArrayOfInt)
  {
    return XPCOM.VtblCall(nsIDOMUIEvent.LAST_METHOD_ID + (IsXULRunner24() ? 8 : 6), getAddress(), paramArrayOfInt);
  }
  
  public int GetAltKey(int[] paramArrayOfInt)
  {
    return XPCOM.VtblCall(nsIDOMUIEvent.LAST_METHOD_ID + (IsXULRunner24() ? 9 : 7), getAddress(), paramArrayOfInt);
  }
  
  public int GetMetaKey(int[] paramArrayOfInt)
  {
    return XPCOM.VtblCall(nsIDOMUIEvent.LAST_METHOD_ID + (IsXULRunner24() ? 10 : 8), getAddress(), paramArrayOfInt);
  }
  
  public int GetButton(short[] paramArrayOfShort)
  {
    return XPCOM.VtblCall(nsIDOMUIEvent.LAST_METHOD_ID + (IsXULRunner24() ? 11 : 9), getAddress(), paramArrayOfShort);
  }
  
  public int GetRelatedTarget(int[] paramArrayOfInt)
  {
    return XPCOM.VtblCall(nsIDOMUIEvent.LAST_METHOD_ID + (IsXULRunner24() ? 13 : 10), getAddress(), paramArrayOfInt);
  }
  
  static
  {
    IIDStore.RegisterIID(nsIDOMMouseEvent.class, 0, new nsID("ff751edc-8b02-aae7-0010-8301838a3123"));
    IIDStore.RegisterIID(nsIDOMMouseEvent.class, 5, new nsID("7f57aa45-6792-4d8b-ba5b-201533cf0b2f"));
    IIDStore.RegisterIID(nsIDOMMouseEvent.class, 6, new nsID("afb2e57b-2822-4969-b2a9-0cada6859534"));
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/internal/mozilla/nsIDOMMouseEvent.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */