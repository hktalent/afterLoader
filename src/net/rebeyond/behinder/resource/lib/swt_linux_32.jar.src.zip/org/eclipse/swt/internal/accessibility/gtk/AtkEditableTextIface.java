package org.eclipse.swt.internal.accessibility.gtk;

public class AtkEditableTextIface
{
  public int set_run_attributes;
  public int set_text_contents;
  public int insert_text;
  public int copy_text;
  public int cut_text;
  public int delete_text;
  public int paste_text;
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/internal/accessibility/gtk/AtkEditableTextIface.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */