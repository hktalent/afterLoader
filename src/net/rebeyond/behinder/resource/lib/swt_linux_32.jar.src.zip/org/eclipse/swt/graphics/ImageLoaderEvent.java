package org.eclipse.swt.graphics;

import org.eclipse.swt.internal.SWTEventObject;

public class ImageLoaderEvent
  extends SWTEventObject
{
  public ImageData imageData;
  public int incrementCount;
  public boolean endOfImage;
  static final long serialVersionUID = 3257284738325558065L;
  
  public ImageLoaderEvent(ImageLoader paramImageLoader, ImageData paramImageData, int paramInt, boolean paramBoolean)
  {
    super(paramImageLoader);
    this.imageData = paramImageData;
    this.incrementCount = paramInt;
    this.endOfImage = paramBoolean;
  }
  
  public String toString()
  {
    return "ImageLoaderEvent {source=" + this.source + " imageData=" + this.imageData + " incrementCount=" + this.incrementCount + " endOfImage=" + this.endOfImage + "}";
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/graphics/ImageLoaderEvent.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */