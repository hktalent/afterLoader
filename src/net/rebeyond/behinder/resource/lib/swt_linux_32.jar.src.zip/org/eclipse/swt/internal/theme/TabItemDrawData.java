package org.eclipse.swt.internal.theme;

import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.GCData;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.internal.Converter;
import org.eclipse.swt.internal.cairo.Cairo;
import org.eclipse.swt.internal.gtk.GdkRectangle;
import org.eclipse.swt.internal.gtk.OS;

public class TabItemDrawData
  extends DrawData
{
  public TabFolderDrawData parent;
  public int position;
  static final int TAB_CURVATURE = 1;
  
  public TabItemDrawData()
  {
    this.state = new int[1];
  }
  
  Rectangle computeTrim(Theme paramTheme, GC paramGC)
  {
    int i = paramTheme.notebookHandle;
    int j = OS.gtk_widget_get_style(i);
    int k = paramTheme.getWidgetProperty(i, "tab-hborder");
    int m = paramTheme.getWidgetProperty(i, "tab-vborder");
    int n = paramTheme.getWidgetProperty(i, "focus-line-width");
    int i1 = OS.gtk_style_get_xthickness(j);
    int i2 = OS.gtk_style_get_ythickness(j);
    int i3 = i1 + 1 + n + k;
    int i4 = i2 + 1 + n + m;
    int i5 = this.clientArea.x - i3;
    int i6 = this.clientArea.y - i4;
    int i7 = this.clientArea.width + 2 * i3;
    int i8 = this.clientArea.height + 2 * i4;
    return new Rectangle(i5, i6, i7, i8);
  }
  
  void draw(Theme paramTheme, GC paramGC, Rectangle paramRectangle)
  {
    int i = paramTheme.notebookHandle;
    int j = OS.gtk_widget_get_style(i);
    int k = paramGC.getGCData().drawable;
    paramTheme.transferClipping(paramGC, j);
    int m = paramRectangle.x;
    int n = paramRectangle.y;
    int i1 = paramRectangle.width;
    int i2 = paramRectangle.height;
    if ((this.state[0] & 0x2) == 0)
    {
      if ((this.parent.style & 0x400) == 0) {
        n++;
      }
      i2--;
    }
    int i3 = 3;
    if ((this.parent.style & 0x400) != 0) {
      i3 = 2;
    }
    int i4 = getStateType(0);
    byte[] arrayOfByte = Converter.wcsToMbcs(null, "tab", true);
    gtk_render_extension(j, k, i4, 2, null, i, arrayOfByte, m, n, i1, i2, i3);
    if (this.clientArea != null)
    {
      int i5 = paramTheme.getWidgetProperty(i, "tab-hborder");
      int i6 = paramTheme.getWidgetProperty(i, "tab-vborder");
      int i7 = paramTheme.getWidgetProperty(i, "focus-line-width");
      int i8 = OS.gtk_style_get_xthickness(j);
      int i9 = OS.gtk_style_get_ythickness(j);
      int i10 = i8 + 1 + i7 + i5;
      int i11 = i9 + 1 + i7 + i6;
      this.clientArea.x = (paramRectangle.x + i10);
      this.clientArea.y = (paramRectangle.y + i11);
      this.clientArea.width = (paramRectangle.width - 2 * i10);
      this.clientArea.height = (paramRectangle.height - 2 * i11);
    }
  }
  
  int getStateType(int paramInt)
  {
    int i = this.state[paramInt];
    int j = 1;
    if ((i & 0x2) != 0) {
      j = 0;
    }
    return j;
  }
  
  int hit(Theme paramTheme, Point paramPoint, Rectangle paramRectangle)
  {
    return paramRectangle.contains(paramPoint) ? 0 : -1;
  }
  
  void gtk_render_extension(int paramInt1, int paramInt2, int paramInt3, int paramInt4, GdkRectangle paramGdkRectangle, int paramInt5, byte[] paramArrayOfByte, int paramInt6, int paramInt7, int paramInt8, int paramInt9, int paramInt10)
  {
    if (OS.GTK3)
    {
      int i = OS.gdk_cairo_create(paramInt2);
      int j = OS.gtk_widget_get_style_context(paramInt1);
      OS.gtk_render_extension(j, i, paramInt6, paramInt7, paramInt8, paramInt9, paramInt10);
      Cairo.cairo_destroy(i);
    }
    else
    {
      OS.gtk_paint_extension(paramInt1, paramInt2, paramInt3, paramInt4, paramGdkRectangle, paramInt5, paramArrayOfByte, paramInt6, paramInt7, paramInt8, paramInt9, paramInt10);
    }
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/internal/theme/TabItemDrawData.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */