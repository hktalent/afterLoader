package org.eclipse.swt.internal.gtk;

public class PangoItem
{
  public int offset;
  public int length;
  public int num_chars;
  public int analysis_shape_engine;
  public int analysis_lang_engine;
  public int analysis_font;
  public byte analysis_level;
  public int analysis_language;
  public int analysis_extra_attrs;
  public static final int sizeof = ;
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/internal/gtk/PangoItem.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */