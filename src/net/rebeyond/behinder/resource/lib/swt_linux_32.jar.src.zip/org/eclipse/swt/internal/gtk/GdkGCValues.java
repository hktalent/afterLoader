package org.eclipse.swt.internal.gtk;

public class GdkGCValues
{
  public int foreground_pixel;
  public short foreground_red;
  public short foreground_green;
  public short foreground_blue;
  public int background_pixel;
  public short background_red;
  public short background_green;
  public short background_blue;
  public int font;
  public int function;
  public int fill;
  public int tile;
  public int stipple;
  public int clip_mask;
  public int subwindow_mode;
  public int ts_x_origin;
  public int ts_y_origin;
  public int clip_x_origin;
  public int clip_y_origin;
  public int graphics_exposures;
  public int line_width;
  public int line_style;
  public int cap_style;
  public int join_style;
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/internal/gtk/GdkGCValues.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */