package org.eclipse.swt.internal.theme;

import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.GCData;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.internal.Converter;
import org.eclipse.swt.internal.cairo.Cairo;
import org.eclipse.swt.internal.gtk.GdkRectangle;
import org.eclipse.swt.internal.gtk.GtkBorder;
import org.eclipse.swt.internal.gtk.OS;

public class ButtonDrawData
  extends DrawData
{
  public ButtonDrawData()
  {
    this.state = new int[1];
  }
  
  void draw(Theme paramTheme, GC paramGC, Rectangle paramRectangle)
  {
    int i = this.state[0];
    int j = paramGC.getGCData().drawable;
    int k;
    int m;
    int n;
    int i1;
    int i2;
    int i3;
    int i4;
    int i5;
    int i6;
    int i7;
    int i8;
    byte[] arrayOfByte1;
    int i10;
    int i11;
    int i12;
    int i13;
    if ((this.style & 0x10) != 0)
    {
      k = paramTheme.radioButtonHandle;
      m = OS.gtk_widget_get_style(k);
      paramTheme.transferClipping(paramGC, m);
      n = paramTheme.getWidgetProperty(k, "indicator-size");
      i1 = paramTheme.getWidgetProperty(k, "indicator-spacing");
      i2 = paramTheme.getWidgetProperty(k, "interior-focus");
      i3 = paramTheme.getWidgetProperty(k, "focus-line-width");
      i4 = paramTheme.getWidgetProperty(k, "focus-padding");
      i5 = OS.gtk_container_get_border_width(k);
      i6 = paramRectangle.x + i1 + i5;
      i7 = paramRectangle.y + (paramRectangle.height - n) / 2;
      if (i2 == 0) {
        i6 += i3 + i4;
      }
      if ((i & 0x100) != 0) {
        i8 = 3;
      } else if ((i & 0x2) != 0) {
        i8 = 1;
      } else {
        i8 = 2;
      }
      arrayOfByte1 = Converter.wcsToMbcs(null, "radiobutton", true);
      if ((i & 0x40) != 0)
      {
        i10 = paramRectangle.x + i5;
        i11 = paramRectangle.y + i5;
        i12 = paramRectangle.width - 2 * i5;
        i13 = paramRectangle.height - 2 * i5;
        gtk_render_frame(m, j, 2, 4, null, k, arrayOfByte1, i10, i11, i12, i13);
      }
      i10 = getStateType(0);
      OS.gtk_paint_option(m, j, i10, i8, null, k, arrayOfByte1, i6, i7, n, n);
      if (this.clientArea != null)
      {
        this.clientArea.x = (paramRectangle.x + 2 * i1 + i5 + n);
        this.clientArea.y = (paramRectangle.y + i5);
        this.clientArea.width = (paramRectangle.width - (2 * i1 + 2 * i5 + n));
        this.clientArea.height = (paramRectangle.height - 2 * i5);
      }
      return;
    }
    if ((this.style & 0x20) != 0)
    {
      k = paramTheme.checkButtonHandle;
      m = OS.gtk_widget_get_style(k);
      paramTheme.transferClipping(paramGC, m);
      n = paramTheme.getWidgetProperty(k, "indicator-size");
      i1 = paramTheme.getWidgetProperty(k, "indicator-spacing");
      i2 = paramTheme.getWidgetProperty(k, "interior-focus");
      i3 = paramTheme.getWidgetProperty(k, "focus-line-width");
      i4 = paramTheme.getWidgetProperty(k, "focus-padding");
      i5 = OS.gtk_container_get_border_width(k);
      i6 = paramRectangle.x + i1 + i5;
      i7 = paramRectangle.y + (paramRectangle.height - n) / 2;
      if (i2 == 0) {
        i6 += i3 + i4;
      }
      if ((i & 0x100) != 0) {
        i8 = 3;
      } else if ((i & 0x2) != 0) {
        i8 = 1;
      } else {
        i8 = 2;
      }
      arrayOfByte1 = Converter.wcsToMbcs(null, "checkbutton", true);
      if ((i & 0x40) != 0)
      {
        i10 = paramRectangle.x + i5;
        i11 = paramRectangle.y + i5;
        i12 = paramRectangle.width - 2 * i5;
        i13 = paramRectangle.height - 2 * i5;
        gtk_render_frame(m, j, 2, 4, null, k, arrayOfByte1, i10, i11, i12, i13);
      }
      i10 = getStateType(0);
      gtk_render_check(m, j, i10, i8, k, arrayOfByte1, i6, i7, n, n);
      if (this.clientArea != null)
      {
        this.clientArea.x = (paramRectangle.x + 2 * i1 + i5 + n);
        this.clientArea.y = (paramRectangle.y + i5);
        this.clientArea.width = (paramRectangle.width - (2 * i1 + 2 * i5 + n));
        this.clientArea.height = (paramRectangle.height - 2 * i5);
      }
      return;
    }
    if ((this.style & 0x8) != 0)
    {
      k = paramTheme.buttonHandle;
      m = OS.gtk_widget_get_style(k);
      paramTheme.transferClipping(paramGC, m);
      n = paramTheme.getWidgetProperty(k, "focus-line-width");
      i1 = paramTheme.getWidgetProperty(k, "focus-padding");
      i2 = OS.gtk_container_get_border_width(k);
      GtkBorder localGtkBorder1 = new GtkBorder();
      i4 = paramTheme.getBorderProperty(k, "default-border");
      if (i4 != 0)
      {
        OS.memmove(localGtkBorder1, i4, GtkBorder.sizeof);
        OS.gtk_border_free(i4);
      }
      else
      {
        localGtkBorder1.left = (localGtkBorder1.right = localGtkBorder1.top = localGtkBorder1.bottom = 1);
      }
      GtkBorder localGtkBorder2 = new GtkBorder();
      i6 = paramTheme.getBorderProperty(k, "default-outside-border");
      if (i6 != 0)
      {
        OS.memmove(localGtkBorder2, i6, GtkBorder.sizeof);
        OS.gtk_border_free(i6);
      }
      else
      {
        localGtkBorder2.left = (localGtkBorder2.right = localGtkBorder2.top = localGtkBorder2.bottom = 0);
      }
      i7 = paramRectangle.x + i2;
      i8 = paramRectangle.y + i2;
      int i9 = paramRectangle.width - i2 * 2;
      i10 = paramRectangle.height - i2 * 2;
      i11 = OS.gtk_button_get_relief(k);
      byte[] arrayOfByte2 = Converter.wcsToMbcs(null, (i & 0x80) != 0 ? "buttondefault" : "button", true);
      if (((i & 0x80) != 0) && (i11 == 0))
      {
        gtk_render_box(m, j, 0, 1, null, k, arrayOfByte2, i7, i8, i9, i10);
        i7 += localGtkBorder1.left;
        i8 += localGtkBorder1.top;
        i9 -= localGtkBorder1.left + localGtkBorder1.right;
        i10 -= localGtkBorder1.top + localGtkBorder1.bottom;
      }
      else if ((i & 0x80) != 0)
      {
        i7 += localGtkBorder2.left;
        i8 += localGtkBorder2.top;
        i9 -= localGtkBorder2.left + localGtkBorder2.right;
        i10 -= localGtkBorder2.top + localGtkBorder2.bottom;
      }
      i13 = 2;
      if ((i & 0xA) != 0) {
        i13 = 1;
      }
      int i14 = getStateType(0);
      if ((i11 != 2) || ((i & 0x48) != 0)) {
        gtk_render_box(m, j, i14, i13, null, k, arrayOfByte2, i7, i8, i9, i10);
      }
      if ((i & 0x4) != 0)
      {
        int i15 = paramTheme.getWidgetProperty(k, "child-displacement-y");
        int i16 = paramTheme.getWidgetProperty(k, "child-displacement-x");
        int i17 = paramTheme.getWidgetProperty(k, "displace-focus");
        int i18 = paramTheme.getWidgetProperty(k, "interior-focus");
        if (i18 != 0)
        {
          int i19 = OS.gtk_style_get_xthickness(m);
          int i20 = OS.gtk_style_get_ythickness(m);
          i7 += i19 + i1;
          i8 += i20 + i1;
          i9 -= 2 * (i19 + i1);
          i10 -= 2 * (i20 + i1);
        }
        else
        {
          i7 -= n + i1;
          i8 -= n + i1;
          i9 += 2 * (n + i1);
          i10 += 2 * (n + i1);
        }
        if (((i & 0x8) != 0) && (i17 != 0))
        {
          i7 += i16;
          i8 += i15;
        }
        gtk_render_focus(m, j, i14, null, k, arrayOfByte2, i7, i8, i9, i10);
      }
      if (this.clientArea != null)
      {
        this.clientArea.x = (paramRectangle.x + i2);
        this.clientArea.y = (paramRectangle.y + i2);
        this.clientArea.width = (paramRectangle.width - 2 * i2);
        this.clientArea.height = (paramRectangle.height - 2 * i2);
      }
      return;
    }
  }
  
  int hit(Theme paramTheme, Point paramPoint, Rectangle paramRectangle)
  {
    return paramRectangle.contains(paramPoint) ? 0 : -1;
  }
  
  void gtk_render_option(int paramInt1, int paramInt2, int paramInt3, int paramInt4, GdkRectangle paramGdkRectangle, int paramInt5, byte[] paramArrayOfByte, int paramInt6, int paramInt7, int paramInt8, int paramInt9)
  {
    if (OS.GTK3)
    {
      int i = OS.gdk_cairo_create(paramInt2);
      int j = OS.gtk_widget_get_style_context(paramInt1);
      OS.gtk_render_option(j, i, paramInt6, paramInt7, paramInt8, paramInt9);
      Cairo.cairo_destroy(i);
    }
    else
    {
      OS.gtk_paint_option(paramInt1, paramInt2, paramInt3, paramInt4, paramGdkRectangle, paramInt5, paramArrayOfByte, paramInt6, paramInt7, paramInt8, paramInt9);
    }
  }
  
  void gtk_render_check(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, byte[] paramArrayOfByte, int paramInt6, int paramInt7, int paramInt8, int paramInt9)
  {
    if (OS.GTK3)
    {
      int i = OS.gdk_cairo_create(paramInt2);
      int j = OS.gtk_widget_get_style_context(paramInt1);
      OS.gtk_render_check(j, i, paramInt6, paramInt7, paramInt8, paramInt9);
      Cairo.cairo_destroy(i);
    }
    else
    {
      OS.gtk_paint_check(paramInt1, paramInt2, paramInt3, paramInt4, null, paramInt5, paramArrayOfByte, paramInt6, paramInt7, paramInt8, paramInt9);
    }
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/internal/theme/ButtonDrawData.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */