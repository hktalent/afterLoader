package org.eclipse.swt.internal.theme;

import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.GCData;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.internal.Converter;
import org.eclipse.swt.internal.cairo.Cairo;
import org.eclipse.swt.internal.gtk.GdkRectangle;
import org.eclipse.swt.internal.gtk.OS;

public class TabFolderDrawData
  extends DrawData
{
  public int tabsWidth;
  public int tabsHeight;
  public Rectangle tabsArea;
  public int selectedX;
  public int selectedWidth;
  public int spacing;
  
  public TabFolderDrawData()
  {
    this.state = new int[1];
    if (SWT.getPlatform().equals("gtk")) {
      this.spacing = -2;
    }
  }
  
  void draw(Theme paramTheme, GC paramGC, Rectangle paramRectangle)
  {
    int i = paramTheme.notebookHandle;
    int j = OS.gtk_widget_get_style(i);
    int k = paramGC.getGCData().drawable;
    paramTheme.transferClipping(paramGC, j);
    int m = paramRectangle.x;
    int n = paramRectangle.y;
    int i1 = paramRectangle.width;
    int i2 = paramRectangle.height;
    i2 -= this.tabsHeight;
    int i3 = this.selectedX;
    int i4 = this.selectedWidth;
    int i5 = 2;
    if ((this.style & 0x400) != 0) {
      i5 = 3;
    } else {
      n += this.tabsHeight;
    }
    byte[] arrayOfByte = Converter.wcsToMbcs(null, "notebook", true);
    gtk_render_frame_gap(j, k, getStateType(0), 2, null, i, arrayOfByte, m, n, i1, i2, i5, i3, i4);
    if (this.tabsArea != null)
    {
      this.tabsArea.x = paramRectangle.x;
      this.tabsArea.y = paramRectangle.y;
      this.tabsArea.width = paramRectangle.width;
      this.tabsArea.height = this.tabsHeight;
      if ((this.style & 0x400) != 0) {
        this.tabsArea.y += paramRectangle.height - this.tabsHeight;
      }
    }
  }
  
  int getStateType(int paramInt)
  {
    return 0;
  }
  
  int hit(Theme paramTheme, Point paramPoint, Rectangle paramRectangle)
  {
    return paramRectangle.contains(paramPoint) ? 0 : -1;
  }
  
  void gtk_render_frame_gap(int paramInt1, int paramInt2, int paramInt3, int paramInt4, GdkRectangle paramGdkRectangle, int paramInt5, byte[] paramArrayOfByte, int paramInt6, int paramInt7, int paramInt8, int paramInt9, int paramInt10, int paramInt11, int paramInt12)
  {
    if (OS.GTK3)
    {
      int i = OS.gdk_cairo_create(paramInt2);
      int j = OS.gtk_widget_get_style_context(paramInt1);
      OS.gtk_render_frame_gap(j, i, j, paramInt7, paramInt12, paramInt9, paramInt10, paramInt11, paramInt11 + paramInt12);
      Cairo.cairo_destroy(i);
    }
    else
    {
      OS.gtk_paint_box_gap(paramInt1, paramInt2, paramInt3, paramInt4, paramGdkRectangle, paramInt5, paramArrayOfByte, paramInt6, paramInt7, paramInt8, paramInt9, paramInt10, paramInt11, paramInt12);
    }
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/internal/theme/TabFolderDrawData.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */