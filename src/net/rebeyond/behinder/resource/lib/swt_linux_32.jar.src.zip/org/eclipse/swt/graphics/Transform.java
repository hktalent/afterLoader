package org.eclipse.swt.graphics;

import org.eclipse.swt.SWT;
import org.eclipse.swt.internal.Compatibility;
import org.eclipse.swt.internal.cairo.Cairo;

public class Transform
  extends Resource
{
  public double[] handle;
  
  public Transform(Device paramDevice)
  {
    this(paramDevice, 1.0F, 0.0F, 0.0F, 1.0F, 0.0F, 0.0F);
  }
  
  public Transform(Device paramDevice, float[] paramArrayOfFloat)
  {
    this(paramDevice, checkTransform(paramArrayOfFloat)[0], paramArrayOfFloat[1], paramArrayOfFloat[2], paramArrayOfFloat[3], paramArrayOfFloat[4], paramArrayOfFloat[5]);
  }
  
  public Transform(Device paramDevice, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6)
  {
    super(paramDevice);
    this.device.checkCairo();
    this.handle = new double[6];
    if (this.handle == null) {
      SWT.error(2);
    }
    Cairo.cairo_matrix_init(this.handle, paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6);
    init();
  }
  
  static float[] checkTransform(float[] paramArrayOfFloat)
  {
    if (paramArrayOfFloat == null) {
      SWT.error(4);
    }
    if (paramArrayOfFloat.length < 6) {
      SWT.error(5);
    }
    return paramArrayOfFloat;
  }
  
  void destroy()
  {
    this.handle = null;
  }
  
  public void getElements(float[] paramArrayOfFloat)
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    if (paramArrayOfFloat == null) {
      SWT.error(4);
    }
    if (paramArrayOfFloat.length < 6) {
      SWT.error(5);
    }
    paramArrayOfFloat[0] = ((float)this.handle[0]);
    paramArrayOfFloat[1] = ((float)this.handle[1]);
    paramArrayOfFloat[2] = ((float)this.handle[2]);
    paramArrayOfFloat[3] = ((float)this.handle[3]);
    paramArrayOfFloat[4] = ((float)this.handle[4]);
    paramArrayOfFloat[5] = ((float)this.handle[5]);
  }
  
  public void identity()
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    Cairo.cairo_matrix_init(this.handle, 1.0D, 0.0D, 0.0D, 1.0D, 0.0D, 0.0D);
  }
  
  public void invert()
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    if (Cairo.cairo_matrix_invert(this.handle) != 0) {
      SWT.error(10);
    }
  }
  
  public boolean isDisposed()
  {
    return this.handle == null;
  }
  
  public boolean isIdentity()
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    float[] arrayOfFloat = new float[6];
    getElements(arrayOfFloat);
    return (arrayOfFloat[0] == 1.0F) && (arrayOfFloat[1] == 0.0F) && (arrayOfFloat[2] == 0.0F) && (arrayOfFloat[3] == 1.0F) && (arrayOfFloat[4] == 0.0F) && (arrayOfFloat[5] == 0.0F);
  }
  
  public void multiply(Transform paramTransform)
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    if (paramTransform == null) {
      SWT.error(4);
    }
    if (paramTransform.isDisposed()) {
      SWT.error(5);
    }
    Cairo.cairo_matrix_multiply(this.handle, paramTransform.handle, this.handle);
  }
  
  public void rotate(float paramFloat)
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    Cairo.cairo_matrix_rotate(this.handle, paramFloat * (float)Compatibility.PI / 180.0F);
  }
  
  public void scale(float paramFloat1, float paramFloat2)
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    Cairo.cairo_matrix_scale(this.handle, paramFloat1, paramFloat2);
  }
  
  public void setElements(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6)
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    Cairo.cairo_matrix_init(this.handle, paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6);
  }
  
  public void shear(float paramFloat1, float paramFloat2)
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    double[] arrayOfDouble = { 1.0D, paramFloat1, paramFloat2, 1.0D, 0.0D, 0.0D };
    Cairo.cairo_matrix_multiply(this.handle, arrayOfDouble, this.handle);
  }
  
  public void transform(float[] paramArrayOfFloat)
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    if (paramArrayOfFloat == null) {
      SWT.error(4);
    }
    double[] arrayOfDouble1 = new double[1];
    double[] arrayOfDouble2 = new double[1];
    int i = paramArrayOfFloat.length / 2;
    int j = 0;
    for (int k = 0; j < i; k += 2)
    {
      arrayOfDouble1[0] = paramArrayOfFloat[k];
      arrayOfDouble2[0] = paramArrayOfFloat[(k + 1)];
      Cairo.cairo_matrix_transform_point(this.handle, arrayOfDouble1, arrayOfDouble2);
      paramArrayOfFloat[k] = ((float)arrayOfDouble1[0]);
      paramArrayOfFloat[(k + 1)] = ((float)arrayOfDouble2[0]);
      j++;
    }
  }
  
  public void translate(float paramFloat1, float paramFloat2)
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    Cairo.cairo_matrix_translate(this.handle, paramFloat1, paramFloat2);
  }
  
  public String toString()
  {
    if (isDisposed()) {
      return "Transform {*DISPOSED*}";
    }
    float[] arrayOfFloat = new float[6];
    getElements(arrayOfFloat);
    return "Transform {" + arrayOfFloat[0] + "," + arrayOfFloat[1] + "," + arrayOfFloat[2] + "," + arrayOfFloat[3] + "," + arrayOfFloat[4] + "," + arrayOfFloat[5] + "}";
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/graphics/Transform.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */