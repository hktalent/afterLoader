package org.eclipse.swt.graphics;

import java.io.InputStream;
import org.eclipse.swt.SWT;
import org.eclipse.swt.SWTException;
import org.eclipse.swt.internal.Converter;
import org.eclipse.swt.internal.ImageList;
import org.eclipse.swt.internal.cairo.Cairo;
import org.eclipse.swt.internal.gtk.GdkColor;
import org.eclipse.swt.internal.gtk.GdkImage;
import org.eclipse.swt.internal.gtk.OS;

public final class Image
  extends Resource
  implements Drawable
{
  public int type;
  public int pixmap;
  public int mask;
  public int surface;
  int transparentPixel = -1;
  GC memGC;
  byte[] alphaData;
  int alpha = -1;
  int width = -1;
  int height = -1;
  static final int DEFAULT_SCANLINE_PAD = 4;
  
  Image(Device paramDevice)
  {
    super(paramDevice);
  }
  
  public Image(Device paramDevice, int paramInt1, int paramInt2)
  {
    super(paramDevice);
    init(paramInt1, paramInt2);
    init();
  }
  
  public Image(Device paramDevice, Image paramImage, int paramInt)
  {
    super(paramDevice);
    if (paramImage == null) {
      SWT.error(4);
    }
    if (paramImage.isDisposed()) {
      SWT.error(5);
    }
    switch (paramInt)
    {
    case 0: 
    case 1: 
    case 2: 
      break;
    default: 
      SWT.error(5);
    }
    paramDevice = this.device;
    this.type = paramImage.type;
    int i2;
    int i3;
    int i4;
    int i5;
    int i11;
    int i18;
    int i20;
    int i22;
    int i23;
    int i24;
    int i25;
    int i26;
    int i10;
    int i16;
    int i17;
    if (OS.USE_CAIRO)
    {
      if (paramInt != 1) {
        this.transparentPixel = paramImage.transparentPixel;
      }
      this.alpha = paramImage.alpha;
      if (paramImage.alphaData != null)
      {
        this.alphaData = new byte[paramImage.alphaData.length];
        System.arraycopy(paramImage.alphaData, 0, this.alphaData, 0, this.alphaData.length);
      }
      int i = paramImage.surface;
      int j = this.width = paramImage.width;
      k = this.height = paramImage.height;
      m = Cairo.cairo_surface_get_content(i) == 4096 ? 1 : 0;
      n = m == 0 ? 1 : 0;
      this.surface = Cairo.cairo_image_surface_create(m, j, k);
      if (this.surface == 0) {
        SWT.error(2);
      }
      i1 = Cairo.cairo_create(this.surface);
      if (i1 == 0) {
        SWT.error(2);
      }
      Cairo.cairo_set_operator(i1, 1);
      Cairo.cairo_set_source_surface(i1, i, 0.0D, 0.0D);
      Cairo.cairo_paint(i1);
      Cairo.cairo_destroy(i1);
      if (paramInt != 0)
      {
        i2 = Cairo.cairo_image_surface_get_stride(this.surface);
        i3 = Cairo.cairo_image_surface_get_data(this.surface);
        int i6;
        int i7;
        if (OS.BIG_ENDIAN)
        {
          i4 = 0;
          i5 = 1;
          i6 = 2;
          i7 = 3;
        }
        else
        {
          i4 = 3;
          i5 = 2;
          i6 = 1;
          i7 = 0;
        }
        Object localObject2;
        int i12;
        int i14;
        int i19;
        switch (paramInt)
        {
        case 1: 
          localObject2 = paramDevice.getSystemColor(18);
          RGB localRGB2 = ((Color)localObject2).getRGB();
          i11 = localRGB2.red;
          i12 = localRGB2.green;
          i14 = localRGB2.blue;
          Color localColor2 = paramDevice.getSystemColor(22);
          RGB localRGB4 = localColor2.getRGB();
          i18 = localRGB4.red;
          i19 = localRGB4.green;
          i20 = localRGB4.blue;
          byte[] arrayOfByte2 = new byte[i2];
          for (i22 = 0; i22 < k; i22++)
          {
            OS.memmove(arrayOfByte2, i3 + i22 * i2, i2);
            i23 = 0;
            for (i24 = 0; i23 < j; i24 += 4)
            {
              i25 = arrayOfByte2[(i24 + i4)] & 0xFF;
              i26 = arrayOfByte2[(i24 + i5)] & 0xFF;
              int i27 = arrayOfByte2[(i24 + i6)] & 0xFF;
              int i28 = arrayOfByte2[(i24 + i7)] & 0xFF;
              if ((n != 0) && (i25 != 0))
              {
                i26 = (i26 * 255 + i25 / 2) / i25;
                i27 = (i27 * 255 + i25 / 2) / i25;
                i28 = (i28 * 255 + i25 / 2) / i25;
              }
              int i29 = i26 * i26 + i27 * i27 + i28 * i28;
              if (i29 < 98304)
              {
                i26 = i11;
                i27 = i12;
                i28 = i14;
              }
              else
              {
                i26 = i18;
                i27 = i19;
                i28 = i20;
              }
              if (n != 0)
              {
                i26 = i26 * i25 + 128;
                i26 = i26 + (i26 >> 8) >> 8;
                i27 = i27 * i25 + 128;
                i27 = i27 + (i27 >> 8) >> 8;
                i28 = i28 * i25 + 128;
                i28 = i28 + (i28 >> 8) >> 8;
              }
              arrayOfByte2[(i24 + i5)] = ((byte)i26);
              arrayOfByte2[(i24 + i6)] = ((byte)i27);
              arrayOfByte2[(i24 + i7)] = ((byte)i28);
              i23++;
            }
            OS.memmove(i3 + i22 * i2, arrayOfByte2, i2);
          }
          break;
        case 2: 
          localObject2 = new byte[i2];
          for (i10 = 0; i10 < k; i10++)
          {
            OS.memmove((byte[])localObject2, i3 + i10 * i2, i2);
            i11 = 0;
            for (i12 = 0; i11 < j; i12 += 4)
            {
              i14 = localObject2[(i12 + i4)] & 0xFF;
              i16 = localObject2[(i12 + i5)] & 0xFF;
              i17 = localObject2[(i12 + i6)] & 0xFF;
              i18 = localObject2[(i12 + i7)] & 0xFF;
              if ((n != 0) && (i14 != 0))
              {
                i16 = (i16 * 255 + i14 / 2) / i14;
                i17 = (i17 * 255 + i14 / 2) / i14;
                i18 = (i18 * 255 + i14 / 2) / i14;
              }
              i19 = i16 + i16 + i17 + i17 + i17 + i17 + i17 + i18 >> 3;
              if (n != 0)
              {
                i19 = i19 * i14 + 128;
                i19 = i19 + (i19 >> 8) >> 8;
              }
              localObject2[(i12 + i5)] = (localObject2[(i12 + i6)] = localObject2[(i12 + i7)] = (byte)i19);
              i11++;
            }
            OS.memmove(i3 + i10 * i2, (byte[])localObject2, i2);
          }
          break;
        }
      }
      init();
      return;
    }
    int[] arrayOfInt1 = new int[1];
    int[] arrayOfInt2 = new int[1];
    if (OS.GTK_VERSION >= OS.VERSION(2, 24, 0)) {
      OS.gdk_pixmap_get_size(paramImage.pixmap, arrayOfInt1, arrayOfInt2);
    } else {
      OS.gdk_drawable_get_size(paramImage.pixmap, arrayOfInt1, arrayOfInt2);
    }
    int k = arrayOfInt1[0];
    int m = arrayOfInt2[0];
    if (((paramImage.type == 1) && (paramImage.mask != 0)) || (paramImage.transparentPixel != -1))
    {
      if (paramImage.transparentPixel != -1) {
        paramImage.createMask();
      }
      n = OS.gdk_pixmap_new(0, k, m, 1);
      if (n == 0) {
        SWT.error(2);
      }
      i1 = OS.gdk_gc_new(n);
      if (i1 == 0) {
        SWT.error(2);
      }
      OS.gdk_draw_drawable(n, i1, paramImage.mask, 0, 0, 0, 0, k, m);
      OS.g_object_unref(i1);
      this.mask = n;
      if ((paramImage.transparentPixel != -1) && (paramImage.memGC != null)) {
        paramImage.destroyMask();
      }
    }
    if (paramInt != 1) {
      this.transparentPixel = paramImage.transparentPixel;
    }
    this.alpha = paramImage.alpha;
    if (paramImage.alphaData != null)
    {
      this.alphaData = new byte[paramImage.alphaData.length];
      System.arraycopy(paramImage.alphaData, 0, this.alphaData, 0, this.alphaData.length);
    }
    createAlphaMask(k, m);
    int n = OS.gdk_pixmap_new(OS.gdk_get_default_root_window(), k, m, -1);
    if (n == 0) {
      SWT.error(2);
    }
    int i1 = OS.gdk_gc_new(n);
    if (i1 == 0) {
      SWT.error(2);
    }
    this.pixmap = n;
    if (paramInt == 0)
    {
      OS.gdk_draw_drawable(n, i1, paramImage.pixmap, 0, 0, 0, 0, k, m);
      OS.g_object_unref(i1);
    }
    else
    {
      i2 = OS.gdk_pixbuf_new(0, false, 8, k, m);
      if (i2 == 0) {
        SWT.error(2);
      }
      i3 = OS.gdk_colormap_get_system();
      OS.gdk_pixbuf_get_from_drawable(i2, paramImage.pixmap, i3, 0, 0, 0, 0, k, m);
      i4 = OS.gdk_pixbuf_get_rowstride(i2);
      i5 = OS.gdk_pixbuf_get_pixels(i2);
      Object localObject1;
      int i9;
      switch (paramInt)
      {
      case 1: 
        localObject1 = paramDevice.getSystemColor(18);
        RGB localRGB1 = ((Color)localObject1).getRGB();
        i9 = (byte)localRGB1.red;
        i10 = (byte)localRGB1.green;
        i11 = (byte)localRGB1.blue;
        Color localColor1 = paramDevice.getSystemColor(22);
        RGB localRGB3 = localColor1.getRGB();
        i16 = (byte)localRGB3.red;
        i17 = (byte)localRGB3.green;
        i18 = (byte)localRGB3.blue;
        byte[] arrayOfByte1 = new byte[i4];
        for (i20 = 0; i20 < m; i20++)
        {
          OS.memmove(arrayOfByte1, i5 + i20 * i4, i4);
          for (int i21 = 0; i21 < k; i21++)
          {
            i22 = i21 * 3;
            i23 = arrayOfByte1[i22] & 0xFF;
            i24 = arrayOfByte1[(i22 + 1)] & 0xFF;
            i25 = arrayOfByte1[(i22 + 2)] & 0xFF;
            i26 = i23 * i23 + i24 * i24 + i25 * i25;
            if (i26 < 98304)
            {
              arrayOfByte1[i22] = i9;
              arrayOfByte1[(i22 + 1)] = i10;
              arrayOfByte1[(i22 + 2)] = i11;
            }
            else
            {
              arrayOfByte1[i22] = i16;
              arrayOfByte1[(i22 + 1)] = i17;
              arrayOfByte1[(i22 + 2)] = i18;
            }
          }
          OS.memmove(i5 + i20 * i4, arrayOfByte1, i4);
        }
        break;
      case 2: 
        localObject1 = new byte[i4];
        for (int i8 = 0; i8 < m; i8++)
        {
          OS.memmove((byte[])localObject1, i5 + i8 * i4, i4);
          for (i9 = 0; i9 < k; i9++)
          {
            i10 = i9 * 3;
            i11 = localObject1[i10] & 0xFF;
            int i13 = localObject1[(i10 + 1)] & 0xFF;
            int i15 = localObject1[(i10 + 2)] & 0xFF;
            i16 = (byte)(i11 + i11 + i13 + i13 + i13 + i13 + i13 + i15 >> 3);
            localObject1[i10] = (localObject1[(i10 + 1)] = localObject1[(i10 + 2)] = i16);
          }
          OS.memmove(i5 + i8 * i4, (byte[])localObject1, i4);
        }
        break;
      }
      OS.gdk_pixbuf_render_to_drawable(i2, n, i1, 0, 0, 0, 0, k, m, 1, 0, 0);
      OS.g_object_unref(i2);
      OS.g_object_unref(i1);
    }
    init();
  }
  
  public Image(Device paramDevice, Rectangle paramRectangle)
  {
    super(paramDevice);
    if (paramRectangle == null) {
      SWT.error(4);
    }
    init(paramRectangle.width, paramRectangle.height);
    init();
  }
  
  public Image(Device paramDevice, ImageData paramImageData)
  {
    super(paramDevice);
    init(paramImageData);
    init();
  }
  
  public Image(Device paramDevice, ImageData paramImageData1, ImageData paramImageData2)
  {
    super(paramDevice);
    if (paramImageData1 == null) {
      SWT.error(4);
    }
    if (paramImageData2 == null) {
      SWT.error(4);
    }
    if ((paramImageData1.width != paramImageData2.width) || (paramImageData1.height != paramImageData2.height)) {
      SWT.error(5);
    }
    paramImageData2 = ImageData.convertMask(paramImageData2);
    ImageData localImageData = new ImageData(paramImageData1.width, paramImageData1.height, paramImageData1.depth, paramImageData1.palette, paramImageData1.scanlinePad, paramImageData1.data);
    localImageData.maskPad = paramImageData2.scanlinePad;
    localImageData.maskData = paramImageData2.data;
    init(localImageData);
    init();
  }
  
  public Image(Device paramDevice, InputStream paramInputStream)
  {
    super(paramDevice);
    init(new ImageData(paramInputStream));
    init();
  }
  
  public Image(Device paramDevice, String paramString)
  {
    super(paramDevice);
    if (paramString == null) {
      SWT.error(4);
    }
    initNative(paramString);
    if ((this.pixmap == 0) && (this.surface == 0)) {
      init(new ImageData(paramString));
    }
    init();
  }
  
  void initNative(String paramString)
  {
    try
    {
      int i = paramString.length();
      char[] arrayOfChar = new char[i];
      paramString.getChars(0, i, arrayOfChar, 0);
      byte[] arrayOfByte = Converter.wcsToMbcs(null, arrayOfChar, true);
      int j = OS.gdk_pixbuf_new_from_file(arrayOfByte, null);
      if (j != 0) {
        try
        {
          createFromPixbuf(0, j);
        }
        finally
        {
          if (j != 0) {
            OS.g_object_unref(j);
          }
        }
      }
    }
    catch (SWTException localSWTException) {}
  }
  
  void createAlphaMask(int paramInt1, int paramInt2)
  {
    if ((this.device.useXRender) && ((this.alpha != -1) || (this.alphaData != null)))
    {
      this.mask = OS.gdk_pixmap_new(0, this.alpha != -1 ? 1 : paramInt1, this.alpha != -1 ? 1 : paramInt2, 8);
      if (this.mask == 0) {
        SWT.error(2);
      }
      int i = OS.gdk_gc_new(this.mask);
      if (this.alpha != -1)
      {
        GdkColor localGdkColor = new GdkColor();
        localGdkColor.pixel = ((this.alpha & 0xFF) << 8 | this.alpha & 0xFF);
        OS.gdk_gc_set_foreground(i, localGdkColor);
        OS.gdk_draw_rectangle(this.mask, i, 1, 0, 0, 1, 1);
      }
      else
      {
        int j = OS.gdk_drawable_get_image(this.mask, 0, 0, paramInt1, paramInt2);
        if (j == 0) {
          SWT.error(2);
        }
        GdkImage localGdkImage = new GdkImage();
        OS.memmove(localGdkImage, j);
        if (localGdkImage.bpl == paramInt1)
        {
          OS.memmove(localGdkImage.mem, this.alphaData, this.alphaData.length);
        }
        else
        {
          byte[] arrayOfByte = new byte[localGdkImage.bpl];
          for (int k = 0; k < paramInt2; k++)
          {
            System.arraycopy(this.alphaData, paramInt1 * k, arrayOfByte, 0, paramInt1);
            OS.memmove(localGdkImage.mem + localGdkImage.bpl * k, arrayOfByte, localGdkImage.bpl);
          }
        }
        OS.gdk_draw_image(this.mask, i, j, 0, 0, 0, 0, paramInt1, paramInt2);
        OS.g_object_unref(j);
      }
      OS.g_object_unref(i);
    }
  }
  
  void createFromPixbuf(int paramInt1, int paramInt2)
  {
    this.type = paramInt1;
    boolean bool = OS.gdk_pixbuf_get_has_alpha(paramInt2);
    int i;
    int j;
    int k;
    int m;
    int i1;
    int i2;
    if (OS.USE_CAIRO)
    {
      i = this.width = OS.gdk_pixbuf_get_width(paramInt2);
      j = this.height = OS.gdk_pixbuf_get_height(paramInt2);
      k = OS.gdk_pixbuf_get_rowstride(paramInt2);
      m = OS.gdk_pixbuf_get_pixels(paramInt2);
      int n = bool ? 0 : 1;
      this.surface = Cairo.cairo_image_surface_create(n, i, j);
      if (this.surface == 0) {
        SWT.error(2);
      }
      i1 = Cairo.cairo_image_surface_get_data(this.surface);
      i2 = Cairo.cairo_image_surface_get_stride(this.surface);
      int i3 = 0;
      int i4 = 0;
      int i5 = 0;
      int i6 = 0;
      if (OS.BIG_ENDIAN)
      {
        i3 = 0;
        i4 = 1;
        i5 = 2;
        i6 = 3;
      }
      else
      {
        i3 = 3;
        i4 = 2;
        i5 = 1;
        i6 = 0;
      }
      byte[] arrayOfByte2 = new byte[k];
      int i8;
      int i9;
      int i10;
      int i11;
      int i12;
      int i13;
      int i14;
      if (bool)
      {
        this.alphaData = new byte[i * j];
        int i7 = 0;
        i8 = 0;
        while (i7 < j)
        {
          OS.memmove(arrayOfByte2, m + i7 * k, k);
          i9 = 0;
          for (i10 = 0; i9 < i; i10 += 4)
          {
            i11 = arrayOfByte2[(i10 + 3)] & 0xFF;
            i12 = (arrayOfByte2[(i10 + 0)] & 0xFF) * i11 + 128;
            i12 = i12 + (i12 >> 8) >> 8;
            i13 = (arrayOfByte2[(i10 + 1)] & 0xFF) * i11 + 128;
            i13 = i13 + (i13 >> 8) >> 8;
            i14 = (arrayOfByte2[(i10 + 2)] & 0xFF) * i11 + 128;
            i14 = i14 + (i14 >> 8) >> 8;
            arrayOfByte2[(i10 + i3)] = ((byte)i11);
            arrayOfByte2[(i10 + i4)] = ((byte)i12);
            arrayOfByte2[(i10 + i5)] = ((byte)i13);
            arrayOfByte2[(i10 + i6)] = ((byte)i14);
            this.alphaData[(i8++)] = ((byte)i11);
            i9++;
          }
          OS.memmove(i1 + i7 * k, arrayOfByte2, k);
          i7++;
        }
      }
      else
      {
        byte[] arrayOfByte3 = new byte[i2];
        for (i8 = 0; i8 < j; i8++)
        {
          OS.memmove(arrayOfByte2, m + i8 * k, k);
          i9 = 0;
          i10 = 0;
          for (i11 = 0; i9 < i; i11 += 4)
          {
            i12 = arrayOfByte2[(i10 + 0)] & 0xFF;
            i13 = arrayOfByte2[(i10 + 1)] & 0xFF;
            i14 = arrayOfByte2[(i10 + 2)] & 0xFF;
            arrayOfByte3[(i11 + i4)] = ((byte)i12);
            arrayOfByte3[(i11 + i5)] = ((byte)i13);
            arrayOfByte3[(i11 + i6)] = ((byte)i14);
            i9++;
            i10 += 3;
          }
          OS.memmove(i1 + i8 * i2, arrayOfByte3, i2);
        }
      }
      Cairo.cairo_surface_mark_dirty(this.surface);
    }
    else
    {
      if (bool)
      {
        i = OS.gdk_pixbuf_get_width(paramInt2);
        j = OS.gdk_pixbuf_get_height(paramInt2);
        k = OS.gdk_pixbuf_get_rowstride(paramInt2);
        m = OS.gdk_pixbuf_get_pixels(paramInt2);
        byte[] arrayOfByte1 = new byte[k];
        this.alphaData = new byte[i * j];
        for (i1 = 0; i1 < j; i1++)
        {
          OS.memmove(arrayOfByte1, m + i1 * k, k);
          for (i2 = 0; i2 < i; i2++)
          {
            this.alphaData[(i1 * i + i2)] = arrayOfByte1[(i2 * 4 + 3)];
            arrayOfByte1[(i2 * 4 + 3)] = -1;
          }
          OS.memmove(m + i1 * k, arrayOfByte1, k);
        }
        createAlphaMask(i, j);
      }
      int[] arrayOfInt = new int[1];
      OS.gdk_pixbuf_render_pixmap_and_mask(paramInt2, arrayOfInt, null, 0);
      this.pixmap = arrayOfInt[0];
      if (this.pixmap == 0) {
        SWT.error(2);
      }
    }
  }
  
  void createMask()
  {
    if (OS.USE_CAIRO)
    {
      int i = this.width;
      int j = this.height;
      int k = Cairo.cairo_image_surface_get_stride(this.surface);
      int m = Cairo.cairo_image_surface_get_data(this.surface);
      int n;
      int i1;
      int i2;
      int i3;
      int i4;
      int i5;
      int i6;
      if (OS.BIG_ENDIAN)
      {
        n = 0;
        i1 = 1;
        i2 = 2;
        i3 = 3;
        i4 = this.transparentPixel >> 24 & 0xFF;
        i5 = this.transparentPixel >> 16 & 0xFF;
        i6 = this.transparentPixel >> 8 & 0xFF;
      }
      else
      {
        n = 3;
        i1 = 2;
        i2 = 1;
        i3 = 0;
        i4 = this.transparentPixel >> 16 & 0xFF;
        i5 = this.transparentPixel >> 8 & 0xFF;
        i6 = this.transparentPixel >> 0 & 0xFF;
      }
      byte[] arrayOfByte = new byte[k * j];
      OS.memmove(arrayOfByte, m, arrayOfByte.length);
      int i7 = 0;
      for (int i8 = 0; i8 < j; i8++)
      {
        int i9 = 0;
        while (i9 < i)
        {
          int i10 = arrayOfByte[(i7 + n)] & 0xFF;
          int i11 = arrayOfByte[(i7 + i1)] & 0xFF;
          int i12 = arrayOfByte[(i7 + i2)] & 0xFF;
          int i13 = arrayOfByte[(i7 + i3)] & 0xFF;
          if ((i11 == i4) && (i12 == i5) && (i13 == i6)) {
            i10 = i11 = i12 = i13 = 0;
          } else {
            i10 = 255;
          }
          arrayOfByte[(i7 + n)] = ((byte)i10);
          arrayOfByte[(i7 + i1)] = ((byte)i11);
          arrayOfByte[(i7 + i2)] = ((byte)i12);
          arrayOfByte[(i7 + i3)] = ((byte)i13);
          i9++;
          i7 += 4;
        }
      }
      OS.memmove(m, arrayOfByte, arrayOfByte.length);
      return;
    }
    if (this.mask != 0) {
      return;
    }
    this.mask = createMask(getImageData(), false);
    if (this.mask == 0) {
      SWT.error(2);
    }
  }
  
  int createMask(ImageData paramImageData, boolean paramBoolean)
  {
    ImageData localImageData = paramImageData.getTransparencyMask();
    byte[] arrayOfByte1 = localImageData.data;
    byte[] arrayOfByte2 = paramBoolean ? new byte[arrayOfByte1.length] : arrayOfByte1;
    for (int i = 0; i < arrayOfByte2.length; i++)
    {
      int j = arrayOfByte1[i];
      arrayOfByte2[i] = ((byte)((j & 0x80) >> 7 | (j & 0x40) >> 5 | (j & 0x20) >> 3 | (j & 0x10) >> 1 | (j & 0x8) << 1 | (j & 0x4) << 3 | (j & 0x2) << 5 | (j & 0x1) << 7));
    }
    arrayOfByte2 = ImageData.convertPad(arrayOfByte2, localImageData.width, localImageData.height, localImageData.depth, localImageData.scanlinePad, 1);
    return OS.gdk_bitmap_create_from_data(0, arrayOfByte2, localImageData.width, localImageData.height);
  }
  
  void createSurface()
  {
    if (this.surface != 0) {
      return;
    }
    if (OS.GTK3) {
      return;
    }
    if (this.transparentPixel != -1) {
      createMask();
    }
    int[] arrayOfInt1 = new int[1];
    int[] arrayOfInt2 = new int[1];
    if (OS.GTK_VERSION >= OS.VERSION(2, 24, 0)) {
      OS.gdk_pixmap_get_size(this.pixmap, arrayOfInt1, arrayOfInt2);
    } else {
      OS.gdk_drawable_get_size(this.pixmap, arrayOfInt1, arrayOfInt2);
    }
    int i = arrayOfInt1[0];
    int j = arrayOfInt2[0];
    this.width = i;
    this.height = j;
    int k;
    int m;
    int n;
    if ((this.mask != 0) || (this.alpha != -1) || (this.alphaData != null))
    {
      k = OS.gdk_pixbuf_new(0, true, 8, i, j);
      if (k == 0) {
        SWT.error(2);
      }
      m = OS.gdk_colormap_get_system();
      OS.gdk_pixbuf_get_from_drawable(k, this.pixmap, m, 0, 0, 0, 0, i, j);
      n = OS.gdk_pixbuf_get_rowstride(k);
      int i1 = OS.gdk_pixbuf_get_pixels(k);
      byte[] arrayOfByte1 = new byte[n];
      int i2;
      int i3;
      int i4;
      int i5;
      if (OS.BIG_ENDIAN)
      {
        i2 = 0;
        i3 = 1;
        i4 = 2;
        i5 = 3;
      }
      else
      {
        i2 = 3;
        i3 = 2;
        i4 = 1;
        i5 = 0;
      }
      int i7;
      int i8;
      int i10;
      int i11;
      int i12;
      int i13;
      if ((this.mask != 0) && (OS.gdk_drawable_get_depth(this.mask) == 1))
      {
        i6 = OS.gdk_pixbuf_new(0, false, 8, i, j);
        if (i6 == 0) {
          SWT.error(2);
        }
        OS.gdk_pixbuf_get_from_drawable(i6, this.mask, 0, 0, 0, 0, 0, i, j);
        i7 = OS.gdk_pixbuf_get_rowstride(i6);
        i8 = OS.gdk_pixbuf_get_pixels(i6);
        byte[] arrayOfByte2 = new byte[i7];
        i10 = i1;
        i11 = i8;
        for (i12 = 0; i12 < j; i12++)
        {
          OS.memmove(arrayOfByte1, i10, n);
          OS.memmove(arrayOfByte2, i11, i7);
          i13 = 0;
          for (int i14 = 0; i13 < i; i14 += 4)
          {
            if (arrayOfByte2[(i13 * 3)] == 0)
            {
              arrayOfByte1[(i14 + 0)] = (arrayOfByte1[(i14 + 1)] = arrayOfByte1[(i14 + 2)] = arrayOfByte1[(i14 + 3)] = 0);
            }
            else
            {
              int i15 = arrayOfByte1[(i14 + 0)];
              int i16 = arrayOfByte1[(i14 + 1)];
              int i17 = arrayOfByte1[(i14 + 2)];
              arrayOfByte1[(i14 + i2)] = -1;
              arrayOfByte1[(i14 + i3)] = i15;
              arrayOfByte1[(i14 + i4)] = i16;
              arrayOfByte1[(i14 + i5)] = i17;
            }
            i13++;
          }
          OS.memmove(i10, arrayOfByte1, n);
          i10 += n;
          i11 += i7;
        }
        OS.g_object_unref(i6);
      }
      else
      {
        int i9;
        if (this.alpha != -1)
        {
          i6 = i1;
          for (i7 = 0; i7 < j; i7++)
          {
            OS.memmove(arrayOfByte1, i6, n);
            i8 = 0;
            for (i9 = 0; i8 < i; i9 += 4)
            {
              i10 = (arrayOfByte1[(i9 + 0)] & 0xFF) * this.alpha + 128;
              i10 = i10 + (i10 >> 8) >> 8;
              i11 = (arrayOfByte1[(i9 + 1)] & 0xFF) * this.alpha + 128;
              i11 = i11 + (i11 >> 8) >> 8;
              i12 = (arrayOfByte1[(i9 + 2)] & 0xFF) * this.alpha + 128;
              i12 = i12 + (i12 >> 8) >> 8;
              arrayOfByte1[(i9 + i2)] = ((byte)this.alpha);
              arrayOfByte1[(i9 + i3)] = ((byte)i10);
              arrayOfByte1[(i9 + i4)] = ((byte)i11);
              arrayOfByte1[(i9 + i5)] = ((byte)i12);
              i8++;
            }
            OS.memmove(i6, arrayOfByte1, n);
            i6 += n;
          }
        }
        else if (this.alphaData != null)
        {
          i6 = i1;
          for (i7 = 0; i7 < arrayOfInt2[0]; i7++)
          {
            OS.memmove(arrayOfByte1, i6, n);
            i8 = 0;
            for (i9 = 0; i8 < i; i9 += 4)
            {
              i10 = this.alphaData[(i7 * arrayOfInt1[0] + i8)] & 0xFF;
              i11 = (arrayOfByte1[(i9 + 0)] & 0xFF) * i10 + 128;
              i11 = i11 + (i11 >> 8) >> 8;
              i12 = (arrayOfByte1[(i9 + 1)] & 0xFF) * i10 + 128;
              i12 = i12 + (i12 >> 8) >> 8;
              i13 = (arrayOfByte1[(i9 + 2)] & 0xFF) * i10 + 128;
              i13 = i13 + (i13 >> 8) >> 8;
              arrayOfByte1[(i9 + i2)] = ((byte)i10);
              arrayOfByte1[(i9 + i3)] = ((byte)i11);
              arrayOfByte1[(i9 + i4)] = ((byte)i12);
              arrayOfByte1[(i9 + i5)] = ((byte)i13);
              i8++;
            }
            OS.memmove(i6, arrayOfByte1, n);
            i6 += n;
          }
        }
        else
        {
          i6 = i1;
          for (i7 = 0; i7 < arrayOfInt2[0]; i7++)
          {
            OS.memmove(arrayOfByte1, i6, n);
            i8 = 0;
            for (i9 = 0; i8 < i; i9 += 4)
            {
              i10 = arrayOfByte1[(i9 + 0)];
              i11 = arrayOfByte1[(i9 + 1)];
              i12 = arrayOfByte1[(i9 + 2)];
              arrayOfByte1[(i9 + i2)] = -1;
              arrayOfByte1[(i9 + i3)] = i10;
              arrayOfByte1[(i9 + i4)] = i11;
              arrayOfByte1[(i9 + i5)] = i12;
              i8++;
            }
            OS.memmove(i6, arrayOfByte1, n);
            i6 += n;
          }
        }
      }
      this.surface = Cairo.cairo_image_surface_create(0, i, j);
      int i6 = Cairo.cairo_image_surface_get_data(this.surface);
      OS.memmove(i6, i1, n * j);
      Cairo.cairo_surface_mark_dirty(this.surface);
      OS.g_object_unref(k);
    }
    else
    {
      k = OS.gdk_x11_display_get_xdisplay(OS.gdk_display_get_default());
      m = OS.GDK_PIXMAP_XID(this.pixmap);
      n = OS.gdk_x11_visual_get_xvisual(OS.gdk_visual_get_system());
      this.surface = Cairo.cairo_xlib_surface_create(k, m, n, i, j);
    }
    if ((this.transparentPixel != -1) && (this.memGC != null)) {
      destroyMask();
    }
  }
  
  void destroyMask()
  {
    if (this.mask == 0) {
      return;
    }
    OS.g_object_unref(this.mask);
    this.mask = 0;
  }
  
  void destroy()
  {
    if (this.memGC != null) {
      this.memGC.dispose();
    }
    if (this.pixmap != 0) {
      OS.g_object_unref(this.pixmap);
    }
    if (this.mask != 0) {
      OS.g_object_unref(this.mask);
    }
    if (this.surface != 0) {
      Cairo.cairo_surface_destroy(this.surface);
    }
    this.surface = (this.pixmap = this.mask = 0);
    this.memGC = null;
  }
  
  public boolean equals(Object paramObject)
  {
    if (paramObject == this) {
      return true;
    }
    if (!(paramObject instanceof Image)) {
      return false;
    }
    Image localImage = (Image)paramObject;
    if (OS.USE_CAIRO) {
      return (this.device == localImage.device) && (this.surface == localImage.surface);
    }
    return (this.device == localImage.device) && (this.pixmap == localImage.pixmap);
  }
  
  public Color getBackground()
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    if (this.transparentPixel == -1) {
      return null;
    }
    return null;
  }
  
  public Rectangle getBounds()
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    if ((this.width != -1) && (this.height != -1)) {
      return new Rectangle(0, 0, this.width, this.height);
    }
    int[] arrayOfInt1 = new int[1];
    int[] arrayOfInt2 = new int[1];
    if (OS.GTK_VERSION >= OS.VERSION(2, 24, 0)) {
      OS.gdk_pixmap_get_size(this.pixmap, arrayOfInt1, arrayOfInt2);
    } else {
      OS.gdk_drawable_get_size(this.pixmap, arrayOfInt1, arrayOfInt2);
    }
    return new Rectangle(0, 0, this.width = arrayOfInt1[0], this.height = arrayOfInt2[0]);
  }
  
  public ImageData getImageData()
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    Object localObject1;
    Object localObject2;
    int i9;
    int i10;
    int i8;
    if (OS.USE_CAIRO)
    {
      int i = ImageList.convertSurface(this);
      int j = Cairo.cairo_image_surface_get_format(i);
      k = Cairo.cairo_image_surface_get_width(i);
      m = Cairo.cairo_image_surface_get_height(i);
      n = Cairo.cairo_image_surface_get_stride(i);
      i1 = Cairo.cairo_image_surface_get_data(i);
      i2 = j == 0 ? 1 : 0;
      int i4;
      int i5;
      int i6;
      if (OS.BIG_ENDIAN)
      {
        i3 = 0;
        i4 = 1;
        i5 = 2;
        i6 = 3;
      }
      else
      {
        i3 = 3;
        i4 = 2;
        i5 = 1;
        i6 = 0;
      }
      byte[] arrayOfByte2 = new byte[n * m];
      OS.memmove(arrayOfByte2, i1, arrayOfByte2.length);
      localObject1 = new PaletteData(16711680, 65280, 255);
      localObject2 = new ImageData(k, m, 32, (PaletteData)localObject1, 4, arrayOfByte2);
      int i11;
      int i12;
      int i13;
      if (i2 != 0)
      {
        byte[] arrayOfByte3 = ((ImageData)localObject2).alphaData = new byte[k * m];
        i9 = 0;
        i10 = 0;
        i11 = 0;
        while (i9 < m)
        {
          i12 = 0;
          while (i12 < k)
          {
            i13 = arrayOfByte2[(i10 + i3)] & 0xFF;
            int i14 = arrayOfByte2[(i10 + i4)] & 0xFF;
            int i15 = arrayOfByte2[(i10 + i5)] & 0xFF;
            int i16 = arrayOfByte2[(i10 + i6)] & 0xFF;
            arrayOfByte2[(i10 + 0)] = 0;
            arrayOfByte3[(i11++)] = ((byte)i13);
            if (i13 != 0)
            {
              arrayOfByte2[(i10 + 1)] = ((byte)((i14 * 255 + i13 / 2) / i13));
              arrayOfByte2[(i10 + 2)] = ((byte)((i15 * 255 + i13 / 2) / i13));
              arrayOfByte2[(i10 + 3)] = ((byte)((i16 * 255 + i13 / 2) / i13));
            }
            i12++;
            i10 += 4;
          }
          i9++;
        }
      }
      else
      {
        i8 = 0;
        i9 = 0;
        while (i8 < m)
        {
          i10 = 0;
          while (i10 < k)
          {
            i11 = arrayOfByte2[(i9 + i4)];
            i12 = arrayOfByte2[(i9 + i5)];
            i13 = arrayOfByte2[(i9 + i6)];
            arrayOfByte2[(i9 + 0)] = 0;
            arrayOfByte2[(i9 + 1)] = i11;
            arrayOfByte2[(i9 + 2)] = i12;
            arrayOfByte2[(i9 + 3)] = i13;
            i10++;
            i9 += 4;
          }
          i8++;
        }
      }
      Cairo.cairo_surface_destroy(i);
      return (ImageData)localObject2;
    }
    int[] arrayOfInt1 = new int[1];
    int[] arrayOfInt2 = new int[1];
    if (OS.GTK_VERSION >= OS.VERSION(2, 24, 0)) {
      OS.gdk_pixmap_get_size(this.pixmap, arrayOfInt1, arrayOfInt2);
    } else {
      OS.gdk_drawable_get_size(this.pixmap, arrayOfInt1, arrayOfInt2);
    }
    int k = arrayOfInt1[0];
    int m = arrayOfInt2[0];
    int n = OS.gdk_pixbuf_new(0, false, 8, k, m);
    if (n == 0) {
      SWT.error(2);
    }
    int i1 = OS.gdk_colormap_get_system();
    OS.gdk_pixbuf_get_from_drawable(n, this.pixmap, i1, 0, 0, 0, 0, k, m);
    int i2 = OS.gdk_pixbuf_get_rowstride(n);
    int i3 = OS.gdk_pixbuf_get_pixels(n);
    byte[] arrayOfByte1 = new byte[i2 * m];
    OS.memmove(arrayOfByte1, i3, arrayOfByte1.length);
    OS.g_object_unref(n);
    PaletteData localPaletteData = new PaletteData(16711680, 65280, 255);
    ImageData localImageData = new ImageData(k, m, 24, localPaletteData, 4, arrayOfByte1);
    localImageData.bytesPerLine = i2;
    if ((this.transparentPixel == -1) && (this.type == 1) && (this.mask != 0))
    {
      int i7 = OS.gdk_drawable_get_image(this.mask, 0, 0, k, m);
      if (i7 == 0) {
        SWT.error(2);
      }
      localObject1 = new GdkImage();
      OS.memmove((GdkImage)localObject1, i7);
      localObject2 = new byte[((GdkImage)localObject1).bpl * ((GdkImage)localObject1).height];
      OS.memmove((byte[])localObject2, ((GdkImage)localObject1).mem, localObject2.length);
      OS.g_object_unref(i7);
      for (i8 = 1; i8 < 128; i8++)
      {
        i9 = ((k + 7) / 8 + (i8 - 1)) / i8 * i8;
        if (((GdkImage)localObject1).bpl == i9) {
          break;
        }
      }
      localImageData.maskPad = 2;
      localObject2 = ImageData.convertPad((byte[])localObject2, k, m, 1, i8, localImageData.maskPad);
      if (((GdkImage)localObject1).byte_order == 0) {
        for (i9 = 0; i9 < localObject2.length; i9++)
        {
          i10 = localObject2[i9];
          localObject2[i9] = ((byte)((i10 & 0x1) << 7 | (i10 & 0x2) << 5 | (i10 & 0x4) << 3 | (i10 & 0x8) << 1 | (i10 & 0x10) >> 1 | (i10 & 0x20) >> 3 | (i10 & 0x40) >> 5 | (i10 & 0x80) >> 7));
        }
      }
      localImageData.maskData = ((byte[])localObject2);
    }
    localImageData.transparentPixel = this.transparentPixel;
    localImageData.alpha = this.alpha;
    if ((this.alpha == -1) && (this.alphaData != null))
    {
      localImageData.alphaData = new byte[this.alphaData.length];
      System.arraycopy(this.alphaData, 0, localImageData.alphaData, 0, this.alphaData.length);
    }
    return localImageData;
  }
  
  public static Image gtk_new(Device paramDevice, int paramInt1, int paramInt2, int paramInt3)
  {
    Image localImage = new Image(paramDevice);
    localImage.type = paramInt1;
    if (OS.GTK3)
    {
      localImage.surface = paramInt2;
    }
    else
    {
      localImage.pixmap = paramInt2;
      if (OS.USE_CAIRO) {
        localImage.createSurface();
      }
    }
    localImage.mask = paramInt3;
    return localImage;
  }
  
  public static Image gtk_new_from_pixbuf(Device paramDevice, int paramInt1, int paramInt2)
  {
    Image localImage = new Image(paramDevice);
    localImage.createFromPixbuf(paramInt1, paramInt2);
    localImage.type = paramInt1;
    return localImage;
  }
  
  public int hashCode()
  {
    if (OS.USE_CAIRO) {
      return this.surface;
    }
    return this.pixmap;
  }
  
  void init(int paramInt1, int paramInt2)
  {
    if ((paramInt1 <= 0) || (paramInt2 <= 0)) {
      SWT.error(5);
    }
    this.type = 0;
    if (OS.USE_CAIRO)
    {
      if (OS.GTK_VERSION >= OS.VERSION(2, 22, 0))
      {
        this.surface = OS.gdk_window_create_similar_surface(OS.gdk_get_default_root_window(), 4096, paramInt1, paramInt2);
      }
      else
      {
        i = OS.gdk_x11_display_get_xdisplay(OS.gdk_display_get_default());
        j = OS.gdk_x11_drawable_get_xid(OS.gdk_get_default_root_window());
        k = OS.gdk_x11_visual_get_xvisual(OS.gdk_visual_get_system());
        int m = Cairo.cairo_xlib_surface_create(i, j, k, 1, 1);
        if (m == 0) {
          SWT.error(2);
        }
        this.surface = Cairo.cairo_surface_create_similar(m, 4096, paramInt1, paramInt2);
        Cairo.cairo_surface_destroy(m);
      }
      if (this.surface == 0) {
        SWT.error(2);
      }
      int i = Cairo.cairo_create(this.surface);
      if (i == 0) {
        SWT.error(2);
      }
      Cairo.cairo_set_source_rgb(i, 1.0D, 1.0D, 1.0D);
      Cairo.cairo_rectangle(i, 0.0D, 0.0D, paramInt1, paramInt2);
      Cairo.cairo_fill(i);
      Cairo.cairo_destroy(i);
      this.width = paramInt1;
      this.height = paramInt2;
      return;
    }
    this.pixmap = OS.gdk_pixmap_new(OS.gdk_get_default_root_window(), paramInt1, paramInt2, -1);
    if (this.pixmap == 0) {
      SWT.error(2);
    }
    GdkColor localGdkColor = new GdkColor();
    localGdkColor.red = -1;
    localGdkColor.green = -1;
    localGdkColor.blue = -1;
    int j = OS.gdk_colormap_get_system();
    OS.gdk_colormap_alloc_color(j, localGdkColor, true, true);
    int k = OS.gdk_gc_new(this.pixmap);
    OS.gdk_gc_set_foreground(k, localGdkColor);
    OS.gdk_draw_rectangle(this.pixmap, k, 1, 0, 0, paramInt1, paramInt2);
    OS.g_object_unref(k);
    OS.gdk_colormap_free_colors(j, localGdkColor, 1);
  }
  
  void init(ImageData paramImageData)
  {
    if (paramImageData == null) {
      SWT.error(4);
    }
    int i = this.width = paramImageData.width;
    int j = this.height = paramImageData.height;
    PaletteData localPaletteData = paramImageData.palette;
    if (((paramImageData.depth != 1) && (paramImageData.depth != 2) && (paramImageData.depth != 4) && (paramImageData.depth != 8)) || ((localPaletteData.isDirect) && (paramImageData.depth != 8) && (((paramImageData.depth != 16) && (paramImageData.depth != 24) && (paramImageData.depth != 32)) || (!localPaletteData.isDirect)))) {
      SWT.error(38);
    }
    int i9;
    if (OS.USE_CAIRO)
    {
      k = (paramImageData.transparentPixel != -1) || (paramImageData.alpha != -1) || (paramImageData.maskData != null) || (paramImageData.alphaData != null) ? 1 : 0;
      m = k != 0 ? 0 : 1;
      this.surface = Cairo.cairo_image_surface_create(m, i, j);
      if (this.surface == 0) {
        SWT.error(2);
      }
      n = Cairo.cairo_image_surface_get_stride(this.surface);
      int i1 = Cairo.cairo_image_surface_get_data(this.surface);
      int i2 = 0;
      i4 = 0;
      int i5 = 0;
      int i6 = 0;
      int i11 = 32;
      int i8;
      int i10;
      int i12;
      if (OS.BIG_ENDIAN)
      {
        i2 = 0;
        i4 = 1;
        i5 = 2;
        i6 = 3;
        i8 = 65280;
        i9 = 16711680;
        i10 = -16777216;
        i12 = 1;
      }
      else
      {
        i2 = 3;
        i4 = 2;
        i5 = 1;
        i6 = 0;
        i8 = 16711680;
        i9 = 65280;
        i10 = 255;
        i12 = 0;
      }
      byte[] arrayOfByte4 = paramImageData.data;
      int i19;
      if ((!localPaletteData.isDirect) || (paramImageData.depth != i11) || (n != paramImageData.bytesPerLine) || (localPaletteData.redMask != i8) || (localPaletteData.greenMask != i9) || (localPaletteData.blueMask != i10) || (i12 != paramImageData.getByteOrder()))
      {
        arrayOfByte4 = new byte[n * j];
        if (localPaletteData.isDirect)
        {
          ImageData.blit(1, paramImageData.data, paramImageData.depth, paramImageData.bytesPerLine, paramImageData.getByteOrder(), 0, 0, i, j, localPaletteData.redMask, localPaletteData.greenMask, localPaletteData.blueMask, 255, null, 0, 0, 0, arrayOfByte4, i11, n, i12, 0, 0, i, j, i8, i9, i10, false, false);
        }
        else
        {
          RGB[] arrayOfRGB2 = localPaletteData.getRGBs();
          int i14 = arrayOfRGB2.length;
          byte[] arrayOfByte5 = new byte[i14];
          byte[] arrayOfByte6 = new byte[i14];
          byte[] arrayOfByte7 = new byte[i14];
          for (i19 = 0; i19 < arrayOfRGB2.length; i19++)
          {
            RGB localRGB2 = arrayOfRGB2[i19];
            if (localRGB2 != null)
            {
              arrayOfByte5[i19] = ((byte)localRGB2.red);
              arrayOfByte6[i19] = ((byte)localRGB2.green);
              arrayOfByte7[i19] = ((byte)localRGB2.blue);
            }
          }
          ImageData.blit(1, paramImageData.data, paramImageData.depth, paramImageData.bytesPerLine, paramImageData.getByteOrder(), 0, 0, i, j, arrayOfByte5, arrayOfByte6, arrayOfByte7, 255, null, 0, 0, 0, arrayOfByte4, i11, n, i12, 0, 0, i, j, i8, i9, i10, false, false);
        }
      }
      int i13 = paramImageData.getTransparencyType() == 2 ? 1 : 0;
      this.type = (i13 != 0 ? 1 : 0);
      int i16;
      int i17;
      int i18;
      int i20;
      int i21;
      if ((i13 != 0) || (paramImageData.transparentPixel != -1))
      {
        if (paramImageData.transparentPixel != -1)
        {
          localObject2 = null;
          if (localPaletteData.isDirect) {
            localObject2 = localPaletteData.getRGB(paramImageData.transparentPixel);
          } else if (paramImageData.transparentPixel < localPaletteData.colors.length) {
            localObject2 = localPaletteData.getRGB(paramImageData.transparentPixel);
          }
          if (localObject2 != null) {
            this.transparentPixel = (((RGB)localObject2).red << 16 | ((RGB)localObject2).green << 8 | ((RGB)localObject2).blue);
          }
        }
        Object localObject2 = paramImageData.getTransparencyMask();
        i16 = 0;
        i17 = 0;
        while (i16 < j)
        {
          i18 = 0;
          while (i18 < i)
          {
            i19 = ((ImageData)localObject2).getPixel(i18, i16) == 0 ? 0 : 255;
            i20 = (arrayOfByte4[(i17 + i4)] & 0xFF) * i19 + 128;
            i20 = i20 + (i20 >> 8) >> 8;
            i21 = (arrayOfByte4[(i17 + i5)] & 0xFF) * i19 + 128;
            i21 = i21 + (i21 >> 8) >> 8;
            int i22 = (arrayOfByte4[(i17 + i6)] & 0xFF) * i19 + 128;
            i22 = i22 + (i22 >> 8) >> 8;
            arrayOfByte4[(i17 + i2)] = ((byte)i19);
            arrayOfByte4[(i17 + i4)] = ((byte)i20);
            arrayOfByte4[(i17 + i5)] = ((byte)i21);
            arrayOfByte4[(i17 + i6)] = ((byte)i22);
            i18++;
            i17 += 4;
          }
          i16++;
        }
      }
      else
      {
        this.alpha = paramImageData.alpha;
        if ((paramImageData.alpha == -1) && (paramImageData.alphaData != null))
        {
          this.alphaData = new byte[paramImageData.alphaData.length];
          System.arraycopy(paramImageData.alphaData, 0, this.alphaData, 0, this.alphaData.length);
        }
        int i15;
        if (this.alpha != -1)
        {
          i15 = 0;
          i16 = 0;
          while (i15 < j)
          {
            i17 = 0;
            while (i17 < i)
            {
              i18 = this.alpha;
              i19 = (arrayOfByte4[(i16 + i4)] & 0xFF) * i18 + 128;
              i19 = i19 + (i19 >> 8) >> 8;
              i20 = (arrayOfByte4[(i16 + i5)] & 0xFF) * i18 + 128;
              i20 = i20 + (i20 >> 8) >> 8;
              i21 = (arrayOfByte4[(i16 + i6)] & 0xFF) * i18 + 128;
              i21 = i21 + (i21 >> 8) >> 8;
              arrayOfByte4[(i16 + i2)] = ((byte)i18);
              arrayOfByte4[(i16 + i4)] = ((byte)i19);
              arrayOfByte4[(i16 + i5)] = ((byte)i20);
              arrayOfByte4[(i16 + i6)] = ((byte)i21);
              i17++;
              i16 += 4;
            }
            i15++;
          }
        }
        else if (this.alphaData != null)
        {
          i15 = 0;
          i16 = 0;
          while (i15 < j)
          {
            i17 = 0;
            while (i17 < i)
            {
              i18 = this.alphaData[(i15 * i + i17)] & 0xFF;
              i19 = (arrayOfByte4[(i16 + i4)] & 0xFF) * i18 + 128;
              i19 = i19 + (i19 >> 8) >> 8;
              i20 = (arrayOfByte4[(i16 + i5)] & 0xFF) * i18 + 128;
              i20 = i20 + (i20 >> 8) >> 8;
              i21 = (arrayOfByte4[(i16 + i6)] & 0xFF) * i18 + 128;
              i21 = i21 + (i21 >> 8) >> 8;
              arrayOfByte4[(i16 + i2)] = ((byte)i18);
              arrayOfByte4[(i16 + i4)] = ((byte)i19);
              arrayOfByte4[(i16 + i5)] = ((byte)i20);
              arrayOfByte4[(i16 + i6)] = ((byte)i21);
              i17++;
              i16 += 4;
            }
            i15++;
          }
        }
      }
      OS.memmove(i1, arrayOfByte4, n * j);
      Cairo.cairo_surface_mark_dirty(this.surface);
      return;
    }
    int k = OS.gdk_pixbuf_new(0, false, 8, i, j);
    if (k == 0) {
      SWT.error(2);
    }
    int m = OS.gdk_pixbuf_get_rowstride(k);
    int n = OS.gdk_pixbuf_get_pixels(k);
    byte[] arrayOfByte1 = paramImageData.data;
    Object localObject1;
    if ((!localPaletteData.isDirect) || (paramImageData.depth != 24) || (m != paramImageData.bytesPerLine) || (localPaletteData.redMask != 16711680) || (localPaletteData.greenMask != 65280) || (localPaletteData.blueMask != 255))
    {
      arrayOfByte1 = new byte[m * j];
      if (localPaletteData.isDirect)
      {
        ImageData.blit(1, paramImageData.data, paramImageData.depth, paramImageData.bytesPerLine, paramImageData.getByteOrder(), 0, 0, i, j, localPaletteData.redMask, localPaletteData.greenMask, localPaletteData.blueMask, 255, null, 0, 0, 0, arrayOfByte1, 24, m, 1, 0, 0, i, j, 16711680, 65280, 255, false, false);
      }
      else
      {
        RGB[] arrayOfRGB1 = localPaletteData.getRGBs();
        i4 = arrayOfRGB1.length;
        byte[] arrayOfByte2 = new byte[i4];
        localObject1 = new byte[i4];
        byte[] arrayOfByte3 = new byte[i4];
        for (i9 = 0; i9 < arrayOfRGB1.length; i9++)
        {
          RGB localRGB1 = arrayOfRGB1[i9];
          if (localRGB1 != null)
          {
            arrayOfByte2[i9] = ((byte)localRGB1.red);
            localObject1[i9] = ((byte)localRGB1.green);
            arrayOfByte3[i9] = ((byte)localRGB1.blue);
          }
        }
        ImageData.blit(1, paramImageData.data, paramImageData.depth, paramImageData.bytesPerLine, paramImageData.getByteOrder(), 0, 0, i, j, arrayOfByte2, (byte[])localObject1, arrayOfByte3, 255, null, 0, 0, 0, arrayOfByte1, 24, m, 1, 0, 0, i, j, 16711680, 65280, 255, false, false);
      }
    }
    OS.memmove(n, arrayOfByte1, m * j);
    int i3 = OS.gdk_pixmap_new(OS.gdk_get_default_root_window(), i, j, -1);
    if (i3 == 0) {
      SWT.error(2);
    }
    int i4 = OS.gdk_gc_new(i3);
    if (i4 == 0) {
      SWT.error(2);
    }
    OS.gdk_pixbuf_render_to_drawable(k, i3, i4, 0, 0, 0, 0, i, j, 1, 0, 0);
    OS.g_object_unref(i4);
    OS.g_object_unref(k);
    boolean bool = paramImageData.getTransparencyType() == 2;
    if ((bool) || (paramImageData.transparentPixel != -1))
    {
      if (paramImageData.transparentPixel != -1)
      {
        localObject1 = null;
        if (localPaletteData.isDirect) {
          localObject1 = localPaletteData.getRGB(paramImageData.transparentPixel);
        } else if (paramImageData.transparentPixel < localPaletteData.colors.length) {
          localObject1 = localPaletteData.getRGB(paramImageData.transparentPixel);
        }
        if (localObject1 != null) {
          this.transparentPixel = (((RGB)localObject1).red << 16 | ((RGB)localObject1).green << 8 | ((RGB)localObject1).blue);
        }
      }
      int i7 = createMask(paramImageData, bool);
      if (i7 == 0) {
        SWT.error(2);
      }
      this.mask = i7;
      if (bool) {
        this.type = 1;
      } else {
        this.type = 0;
      }
    }
    else
    {
      this.type = 0;
      this.mask = 0;
      this.alpha = paramImageData.alpha;
      if ((paramImageData.alpha == -1) && (paramImageData.alphaData != null))
      {
        this.alphaData = new byte[paramImageData.alphaData.length];
        System.arraycopy(paramImageData.alphaData, 0, this.alphaData, 0, this.alphaData.length);
      }
      createAlphaMask(i, j);
    }
    this.pixmap = i3;
  }
  
  public int internal_new_GC(GCData paramGCData)
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    if ((this.type != 0) || (this.memGC != null)) {
      SWT.error(5);
    }
    int i;
    if (OS.USE_CAIRO) {
      i = Cairo.cairo_create(this.surface);
    } else {
      i = OS.gdk_gc_new(this.pixmap);
    }
    if (paramGCData != null)
    {
      int j = 100663296;
      if ((paramGCData.style & j) == 0) {
        paramGCData.style |= 0x2000000;
      } else if ((paramGCData.style & 0x4000000) != 0) {
        paramGCData.style |= 0x8000000;
      }
      paramGCData.device = this.device;
      paramGCData.drawable = this.pixmap;
      paramGCData.background = this.device.COLOR_WHITE.handle;
      paramGCData.foreground = this.device.COLOR_BLACK.handle;
      paramGCData.font = this.device.systemFont;
      paramGCData.image = this;
    }
    return i;
  }
  
  public void internal_dispose_GC(int paramInt, GCData paramGCData)
  {
    int i = paramInt;
    if (OS.USE_CAIRO) {
      Cairo.cairo_destroy(i);
    } else {
      OS.g_object_unref(i);
    }
  }
  
  public boolean isDisposed()
  {
    if (OS.USE_CAIRO) {
      return this.surface == 0;
    }
    return this.pixmap == 0;
  }
  
  public void setBackground(Color paramColor)
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    if (paramColor == null) {
      SWT.error(4);
    }
    if (paramColor.isDisposed()) {
      SWT.error(5);
    }
    if (this.transparentPixel == -1) {}
  }
  
  public String toString()
  {
    if (isDisposed()) {
      return "Image {*DISPOSED*}";
    }
    if (OS.USE_CAIRO) {
      return "Image {" + this.surface + "}";
    }
    return "Image {" + this.pixmap + "}";
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/graphics/Image.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */