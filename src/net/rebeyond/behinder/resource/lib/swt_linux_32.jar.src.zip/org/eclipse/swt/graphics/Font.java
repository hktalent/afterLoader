package org.eclipse.swt.graphics;

import org.eclipse.swt.SWT;
import org.eclipse.swt.internal.Converter;
import org.eclipse.swt.internal.gtk.OS;

public final class Font
  extends Resource
{
  public int handle;
  
  Font(Device paramDevice)
  {
    super(paramDevice);
  }
  
  public Font(Device paramDevice, FontData paramFontData)
  {
    super(paramDevice);
    if (paramFontData == null) {
      SWT.error(4);
    }
    init(paramFontData.getName(), paramFontData.getHeightF(), paramFontData.getStyle(), paramFontData.string);
    init();
  }
  
  public Font(Device paramDevice, FontData[] paramArrayOfFontData)
  {
    super(paramDevice);
    if (paramArrayOfFontData == null) {
      SWT.error(4);
    }
    if (paramArrayOfFontData.length == 0) {
      SWT.error(5);
    }
    for (int i = 0; i < paramArrayOfFontData.length; i++) {
      if (paramArrayOfFontData[i] == null) {
        SWT.error(5);
      }
    }
    FontData localFontData = paramArrayOfFontData[0];
    init(localFontData.getName(), localFontData.getHeightF(), localFontData.getStyle(), localFontData.string);
    init();
  }
  
  public Font(Device paramDevice, String paramString, int paramInt1, int paramInt2)
  {
    super(paramDevice);
    init(paramString, paramInt1, paramInt2, null);
    init();
  }
  
  Font(Device paramDevice, String paramString, float paramFloat, int paramInt)
  {
    super(paramDevice);
    init(paramString, paramFloat, paramInt, null);
    init();
  }
  
  void destroy()
  {
    OS.pango_font_description_free(this.handle);
    this.handle = 0;
  }
  
  public boolean equals(Object paramObject)
  {
    if (paramObject == this) {
      return true;
    }
    if (!(paramObject instanceof Font)) {
      return false;
    }
    return this.handle == ((Font)paramObject).handle;
  }
  
  public FontData[] getFontData()
  {
    if (isDisposed()) {
      SWT.error(44);
    }
    int i = OS.pango_font_description_get_family(this.handle);
    int j = OS.strlen(i);
    byte[] arrayOfByte = new byte[j];
    OS.memmove(arrayOfByte, i, j);
    String str = new String(Converter.mbcsToWcs(null, arrayOfByte));
    float f1 = OS.pango_font_description_get_size(this.handle) / 1024.0F;
    Point localPoint1 = this.device.dpi;
    Point localPoint2 = this.device.getScreenDPI();
    float f2 = f1 * localPoint2.y / localPoint1.y;
    int k = OS.pango_font_description_get_style(this.handle);
    int m = OS.pango_font_description_get_weight(this.handle);
    int n = 0;
    if (k == 2) {
      n |= 0x2;
    }
    if (k == 1) {
      n |= 0x20;
    }
    if (m >= 700) {
      n |= 0x1;
    }
    int i1 = OS.pango_font_description_to_string(this.handle);
    j = OS.strlen(i1);
    arrayOfByte = new byte[j + 1];
    OS.memmove(arrayOfByte, i1, j);
    OS.g_free(i1);
    FontData localFontData = new FontData(str, f2, n);
    localFontData.string = arrayOfByte;
    return new FontData[] { localFontData };
  }
  
  public static Font gtk_new(Device paramDevice, int paramInt)
  {
    Font localFont = new Font(paramDevice);
    localFont.handle = paramInt;
    return localFont;
  }
  
  public int hashCode()
  {
    return this.handle;
  }
  
  void init(String paramString, float paramFloat, int paramInt, byte[] paramArrayOfByte)
  {
    if (paramString == null) {
      SWT.error(4);
    }
    if (paramFloat < 0.0F) {
      SWT.error(5);
    }
    Point localPoint1 = this.device.dpi;
    Point localPoint2 = this.device.getScreenDPI();
    float f = paramFloat * localPoint1.y / localPoint2.y;
    if (paramArrayOfByte != null)
    {
      this.handle = OS.pango_font_description_from_string(paramArrayOfByte);
      if (this.handle == 0) {
        SWT.error(2);
      }
    }
    else
    {
      this.handle = OS.pango_font_description_new();
      if (this.handle == 0) {
        SWT.error(2);
      }
      byte[] arrayOfByte = Converter.wcsToMbcs(null, paramString, true);
      OS.pango_font_description_set_family(this.handle, arrayOfByte);
      if (f > 0.0F) {
        OS.pango_font_description_set_size(this.handle, (int)(0.5F + f * 1024.0F));
      }
      OS.pango_font_description_set_stretch(this.handle, 4);
      int i = 0;
      int j = 400;
      if ((paramInt & 0x2) != 0) {
        i = 2;
      }
      if ((paramInt & 0x20) != 0) {
        i = 1;
      }
      if ((paramInt & 0x1) != 0) {
        j = 700;
      }
      OS.pango_font_description_set_style(this.handle, i);
      OS.pango_font_description_set_weight(this.handle, j);
    }
  }
  
  public boolean isDisposed()
  {
    return this.handle == 0;
  }
  
  public String toString()
  {
    if (isDisposed()) {
      return "Font {*DISPOSED*}";
    }
    return "Font {" + this.handle + "}";
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/graphics/Font.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */