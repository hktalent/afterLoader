package org.eclipse.swt.internal;

import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.widgets.Control;

public class BidiUtil
{
  public static final int KEYBOARD_NON_BIDI = 0;
  public static final int KEYBOARD_BIDI = 1;
  public static final int CLASSIN = 1;
  public static final int LINKBEFORE = 2;
  public static final int LINKAFTER = 4;
  public static final int CLASS_HEBREW = 2;
  public static final int CLASS_ARABIC = 2;
  public static final int CLASS_LOCALNUMBER = 4;
  public static final int CLASS_LATINNUMBER = 5;
  public static final int REORDER = 0;
  public static final int LIGATE = 0;
  public static final int GLYPHSHAPE = 0;
  
  public static void addLanguageListener(int paramInt, Runnable paramRunnable) {}
  
  public static void addLanguageListener(Control paramControl, Runnable paramRunnable) {}
  
  public static void drawGlyphs(GC paramGC, char[] paramArrayOfChar, int[] paramArrayOfInt, int paramInt1, int paramInt2) {}
  
  public static boolean isBidiPlatform()
  {
    return false;
  }
  
  public static boolean isKeyboardBidi()
  {
    return false;
  }
  
  public static int getFontBidiAttributes(GC paramGC)
  {
    return 0;
  }
  
  public static void getOrderInfo(GC paramGC, String paramString, int[] paramArrayOfInt1, byte[] paramArrayOfByte, int paramInt, int[] paramArrayOfInt2) {}
  
  public static char[] getRenderInfo(GC paramGC, String paramString, int[] paramArrayOfInt1, byte[] paramArrayOfByte, int[] paramArrayOfInt2, int paramInt, int[] paramArrayOfInt3)
  {
    return null;
  }
  
  public static int getKeyboardLanguage()
  {
    return 0;
  }
  
  public static void removeLanguageListener(int paramInt) {}
  
  public static void removeLanguageListener(Control paramControl) {}
  
  public static void setKeyboardLanguage(int paramInt) {}
  
  public static boolean setOrientation(int paramInt1, int paramInt2)
  {
    return false;
  }
  
  public static boolean setOrientation(Control paramControl, int paramInt)
  {
    return false;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/internal/BidiUtil.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */