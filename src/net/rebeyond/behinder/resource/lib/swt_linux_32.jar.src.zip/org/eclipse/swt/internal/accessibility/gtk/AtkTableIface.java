package org.eclipse.swt.internal.accessibility.gtk;

public class AtkTableIface
{
  public int ref_at;
  public int get_index_at;
  public int get_column_at_index;
  public int get_row_at_index;
  public int get_n_columns;
  public int get_n_rows;
  public int get_column_extent_at;
  public int get_row_extent_at;
  public int get_caption;
  public int get_column_description;
  public int get_column_header;
  public int get_row_description;
  public int get_row_header;
  public int get_summary;
  public int set_caption;
  public int set_column_description;
  public int set_column_header;
  public int set_row_description;
  public int set_row_header;
  public int set_summary;
  public int get_selected_columns;
  public int get_selected_rows;
  public int is_column_selected;
  public int is_row_selected;
  public int is_selected;
  public int add_row_selection;
  public int remove_row_selection;
  public int add_column_selection;
  public int remove_column_selection;
  public int row_inserted;
  public int column_inserted;
  public int row_deleted;
  public int column_deleted;
  public int row_reordered;
  public int column_reordered;
  public int model_changed;
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/internal/accessibility/gtk/AtkTableIface.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */