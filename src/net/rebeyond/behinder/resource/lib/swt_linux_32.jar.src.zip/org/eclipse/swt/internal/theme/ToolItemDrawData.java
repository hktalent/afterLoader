package org.eclipse.swt.internal.theme;

import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.GCData;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.internal.Converter;
import org.eclipse.swt.internal.cairo.Cairo;
import org.eclipse.swt.internal.gtk.OS;

public class ToolItemDrawData
  extends DrawData
{
  public ToolBarDrawData parent;
  static final int ARROW_WIDTH = 8;
  static final int ARROW_HEIGHT = 6;
  
  public ToolItemDrawData()
  {
    this.state = new int[2];
  }
  
  Rectangle computeTrim(Theme paramTheme, GC paramGC)
  {
    int i = paramTheme.buttonHandle;
    int j = OS.gtk_widget_get_style(i);
    int k = paramTheme.getWidgetProperty(i, "focus-line-width");
    int m = paramTheme.getWidgetProperty(i, "focus-padding");
    int n = OS.gtk_style_get_xthickness(j);
    int i1 = OS.gtk_style_get_ythickness(j);
    int i2 = n + k + m;
    int i3 = i1 + k + m;
    int i4 = this.clientArea.x - i2;
    int i5 = this.clientArea.y - i3;
    int i6 = this.clientArea.width + 2 * i2;
    int i7 = this.clientArea.height + 2 * i3;
    if ((this.style & 0x4) != 0) {
      i6 += 8;
    }
    return new Rectangle(i4, i5, i6, i7);
  }
  
  void draw(Theme paramTheme, GC paramGC, Rectangle paramRectangle)
  {
    int i = this.state[0];
    int j = paramGC.getGCData().drawable;
    if ((this.style & 0x2) != 0)
    {
      k = getStateType(0);
      m = paramTheme.separatorHandle;
      byte[] arrayOfByte1 = Converter.wcsToMbcs(null, "vseparator", true);
      i1 = OS.gtk_widget_get_style(m);
      paramTheme.transferClipping(paramGC, i1);
      if ((this.parent.style & 0x200) != 0)
      {
        if (OS.GTK3)
        {
          i2 = OS.gdk_cairo_create(j);
          i3 = OS.gtk_widget_get_style_context(m);
          OS.gtk_render_line(i3, i2, paramRectangle.x, paramRectangle.y + paramRectangle.height / 2, paramRectangle.x + paramRectangle.width, paramRectangle.y + paramRectangle.height / 2);
          Cairo.cairo_destroy(i2);
        }
        else
        {
          OS.gtk_paint_hline(i1, j, k, null, m, arrayOfByte1, paramRectangle.x, paramRectangle.x + paramRectangle.width, paramRectangle.y + paramRectangle.height / 2);
        }
      }
      else if (OS.GTK3)
      {
        i2 = OS.gdk_cairo_create(j);
        i3 = OS.gtk_widget_get_style_context(m);
        OS.gtk_render_line(i3, i2, paramRectangle.x + paramRectangle.width / 2, paramRectangle.y, paramRectangle.x + paramRectangle.width / 2, paramRectangle.y + paramRectangle.height);
        Cairo.cairo_destroy(i2);
      }
      else
      {
        OS.gtk_paint_vline(i1, j, k, null, m, arrayOfByte1, paramRectangle.y, paramRectangle.y + paramRectangle.height, paramRectangle.x + paramRectangle.width / 2);
      }
      return;
    }
    int k = paramTheme.buttonHandle;
    int m = OS.gtk_widget_get_style(k);
    paramTheme.transferClipping(paramGC, m);
    int n = paramTheme.getWidgetProperty(k, "focus-line-width");
    int i1 = paramTheme.getWidgetProperty(k, "focus-padding");
    int i2 = OS.gtk_container_get_border_width(k);
    int i3 = paramRectangle.x + i2;
    int i4 = paramRectangle.y + i2;
    int i5 = paramRectangle.width - i2 * 2;
    int i6 = paramRectangle.height - i2 * 2;
    byte[] arrayOfByte2 = null;
    if ((this.style & 0xC) != 0) {
      arrayOfByte2 = Converter.wcsToMbcs(null, "button", true);
    } else if ((this.style & 0x30) != 0) {
      arrayOfByte2 = Converter.wcsToMbcs(null, "togglebutton", true);
    }
    int[] arrayOfInt = new int[1];
    int i7 = paramTheme.toolbarHandle;
    OS.gtk_widget_style_get(i7, OS.button_relief, arrayOfInt, 0);
    int i8 = 2;
    if ((i & 0xA) != 0) {
      i8 = 1;
    }
    int i9 = getStateType(0);
    if ((arrayOfInt[0] != 2) || ((i & 0x4A) != 0)) {
      gtk_render_box(m, j, i9, i8, null, k, arrayOfByte2, i3, i4, i5, i6);
    }
    if (this.clientArea != null)
    {
      this.clientArea.x = (paramRectangle.x + i2);
      this.clientArea.y = (paramRectangle.y + i2);
      this.clientArea.width = (paramRectangle.width - 2 * i2);
      this.clientArea.height = (paramRectangle.height - 2 * i2);
    }
    int i10 = OS.gtk_style_get_xthickness(m);
    int i11 = paramTheme.getWidgetProperty(k, "interior-focus");
    int i12;
    int i13;
    int i14;
    int i15;
    if ((this.style & 0x4) != 0)
    {
      i12 = 8;
      i13 = 6;
      i14 = i3 + i5 - i12 - i10 - i1;
      if (i11 == 0) {
        i14 -= n;
      }
      i15 = i4 + (i6 - i13) / 2;
      byte[] arrayOfByte3 = Converter.wcsToMbcs(null, "arrow", true);
      gtk_render_arrow(m, j, i9, 0, null, paramTheme.arrowHandle, arrayOfByte3, 1, true, i14, i15, i12, i13);
      if (this.clientArea != null) {
        this.clientArea.width -= paramRectangle.x + paramRectangle.width - i14;
      }
    }
    if ((i & 0x4) != 0)
    {
      i12 = paramTheme.getWidgetProperty(k, "child-displacement-y");
      i13 = paramTheme.getWidgetProperty(k, "child-displacement-x");
      i14 = paramTheme.getWidgetProperty(k, "displace-focus");
      if (i11 != 0)
      {
        i15 = OS.gtk_style_get_ythickness(m);
        i3 += i10 + i1;
        i4 += i15 + i1;
        i5 -= 2 * (i10 + i1);
        i6 -= 2 * (i15 + i1);
      }
      else
      {
        i3 -= n + i1;
        i4 -= n + i1;
        i5 += 2 * (n + i1);
        i6 += 2 * (n + i1);
      }
      if (((i & 0xA) != 0) && (i14 != 0))
      {
        i3 += i13;
        i4 += i12;
      }
      gtk_render_focus(m, j, i9, null, k, arrayOfByte2, i3, i4, i5, i6);
    }
  }
  
  int hit(Theme paramTheme, Point paramPoint, Rectangle paramRectangle)
  {
    if (!paramRectangle.contains(paramPoint)) {
      return -1;
    }
    if ((this.style & 0x4) != 0)
    {
      int i = paramTheme.buttonHandle;
      int j = OS.gtk_widget_get_style(i);
      int k = OS.gtk_style_get_xthickness(j);
      int m = paramTheme.getWidgetProperty(i, "interior-focus");
      int n = paramTheme.getWidgetProperty(i, "focus-line-width");
      int i1 = paramTheme.getWidgetProperty(i, "focus-padding");
      int i2 = 8;
      int i3 = paramRectangle.x + paramRectangle.width - i2 - k - i1;
      if (m == 0) {
        i3 -= n;
      }
      if (i3 <= paramPoint.x) {
        return 1;
      }
    }
    return 0;
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/internal/theme/ToolItemDrawData.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */