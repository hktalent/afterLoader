package org.eclipse.swt.dnd;

import org.eclipse.swt.internal.Converter;
import org.eclipse.swt.internal.gtk.GtkSelectionData;
import org.eclipse.swt.internal.gtk.OS;
import org.eclipse.swt.widgets.Display;

public class Clipboard
{
  private Display display;
  static int GTKCLIPBOARD = OS.gtk_clipboard_get(0);
  static int GTKPRIMARYCLIPBOARD;
  private static int TARGET;
  
  public Clipboard(Display paramDisplay)
  {
    checkSubclass();
    if (paramDisplay == null)
    {
      paramDisplay = Display.getCurrent();
      if (paramDisplay == null) {
        paramDisplay = Display.getDefault();
      }
    }
    if (paramDisplay.getThread() != Thread.currentThread()) {
      DND.error(22);
    }
    this.display = paramDisplay;
  }
  
  protected void checkSubclass()
  {
    String str1 = getClass().getName();
    String str2 = Clipboard.class.getName();
    if (!str2.equals(str1)) {
      DND.error(43);
    }
  }
  
  protected void checkWidget()
  {
    Display localDisplay = this.display;
    if (localDisplay == null) {
      DND.error(24);
    }
    if (localDisplay.getThread() != Thread.currentThread()) {
      DND.error(22);
    }
    if (localDisplay.isDisposed()) {
      DND.error(24);
    }
  }
  
  public void clearContents()
  {
    clearContents(1);
  }
  
  public void clearContents(int paramInt)
  {
    checkWidget();
    ClipboardProxy localClipboardProxy = ClipboardProxy._getInstance(this.display);
    localClipboardProxy.clear(this, paramInt);
  }
  
  public void dispose()
  {
    if (isDisposed()) {
      return;
    }
    if (this.display.getThread() != Thread.currentThread()) {
      DND.error(22);
    }
    this.display = null;
  }
  
  public Object getContents(Transfer paramTransfer)
  {
    return getContents(paramTransfer, 1);
  }
  
  public Object getContents(Transfer paramTransfer, int paramInt)
  {
    checkWidget();
    if (paramTransfer == null) {
      DND.error(4);
    }
    int i = 0;
    int[] arrayOfInt = paramTransfer.getTypeIds();
    for (int j = 0; j < arrayOfInt.length; j++)
    {
      if ((paramInt & 0x1) != 0)
      {
        i = gtk_clipboard_wait_for_contents(GTKCLIPBOARD, arrayOfInt[j]);
        OS.gdk_threads_leave();
      }
      if (i != 0) {
        break;
      }
      if ((paramInt & 0x2) != 0)
      {
        i = gtk_clipboard_wait_for_contents(GTKPRIMARYCLIPBOARD, arrayOfInt[j]);
        OS.gdk_threads_leave();
      }
    }
    if (i == 0) {
      return null;
    }
    TransferData localTransferData = new TransferData();
    if (OS.GTK_VERSION >= OS.VERSION(2, 14, 0))
    {
      localTransferData.type = OS.gtk_selection_data_get_data_type(i);
      localTransferData.pValue = OS.gtk_selection_data_get_data(i);
      localTransferData.length = OS.gtk_selection_data_get_length(i);
      localTransferData.format = OS.gtk_selection_data_get_format(i);
    }
    else
    {
      localObject = new GtkSelectionData();
      OS.memmove((GtkSelectionData)localObject, i, GtkSelectionData.sizeof);
      localTransferData.type = ((GtkSelectionData)localObject).type;
      localTransferData.pValue = ((GtkSelectionData)localObject).data;
      localTransferData.length = ((GtkSelectionData)localObject).length;
      localTransferData.format = ((GtkSelectionData)localObject).format;
    }
    Object localObject = paramTransfer.nativeToJava(localTransferData);
    OS.gtk_selection_data_free(i);
    return localObject;
  }
  
  public boolean isDisposed()
  {
    return this.display == null;
  }
  
  public void setContents(Object[] paramArrayOfObject, Transfer[] paramArrayOfTransfer)
  {
    setContents(paramArrayOfObject, paramArrayOfTransfer, 1);
  }
  
  public void setContents(Object[] paramArrayOfObject, Transfer[] paramArrayOfTransfer, int paramInt)
  {
    checkWidget();
    if ((paramArrayOfObject == null) || (paramArrayOfTransfer == null) || (paramArrayOfObject.length != paramArrayOfTransfer.length) || (paramArrayOfObject.length == 0)) {
      DND.error(5);
    }
    for (int i = 0; i < paramArrayOfObject.length; i++) {
      if ((paramArrayOfObject[i] == null) || (paramArrayOfTransfer[i] == null) || (!paramArrayOfTransfer[i].validate(paramArrayOfObject[i]))) {
        DND.error(5);
      }
    }
    ClipboardProxy localClipboardProxy = ClipboardProxy._getInstance(this.display);
    if (!localClipboardProxy.setData(this, paramArrayOfObject, paramArrayOfTransfer, paramInt)) {
      DND.error(2002);
    }
  }
  
  public TransferData[] getAvailableTypes()
  {
    return getAvailableTypes(1);
  }
  
  public TransferData[] getAvailableTypes(int paramInt)
  {
    checkWidget();
    Object localObject = null;
    int[] arrayOfInt;
    int i;
    if ((paramInt & 0x1) != 0)
    {
      arrayOfInt = getAvailableClipboardTypes();
      localObject = new TransferData[arrayOfInt.length];
      for (i = 0; i < arrayOfInt.length; i++)
      {
        localObject[i] = new TransferData();
        localObject[i].type = arrayOfInt[i];
      }
    }
    if ((paramInt & 0x2) != 0)
    {
      arrayOfInt = getAvailablePrimaryTypes();
      i = 0;
      if (localObject != null)
      {
        TransferData[] arrayOfTransferData = new TransferData[localObject.length + arrayOfInt.length];
        System.arraycopy(localObject, 0, arrayOfTransferData, 0, localObject.length);
        i = localObject.length;
        localObject = arrayOfTransferData;
      }
      else
      {
        localObject = new TransferData[arrayOfInt.length];
      }
      for (int j = 0; j < arrayOfInt.length; j++)
      {
        localObject[(i + j)] = new TransferData();
        localObject[(i + j)].type = arrayOfInt[j];
      }
    }
    return localObject == null ? new TransferData[0] : localObject;
  }
  
  public String[] getAvailableTypeNames()
  {
    checkWidget();
    int[] arrayOfInt1 = getAvailableClipboardTypes();
    int[] arrayOfInt2 = getAvailablePrimaryTypes();
    Object localObject = new String[arrayOfInt1.length + arrayOfInt2.length];
    int i = 0;
    int k;
    byte[] arrayOfByte;
    for (int j = 0; j < arrayOfInt1.length; j++)
    {
      k = OS.gdk_atom_name(arrayOfInt1[j]);
      if (k != 0)
      {
        arrayOfByte = new byte[OS.strlen(k)];
        OS.memmove(arrayOfByte, k, arrayOfByte.length);
        OS.g_free(k);
        localObject[(i++)] = ("GTKCLIPBOARD " + new String(Converter.mbcsToWcs(null, arrayOfByte)));
      }
    }
    for (j = 0; j < arrayOfInt2.length; j++)
    {
      k = OS.gdk_atom_name(arrayOfInt2[j]);
      if (k != 0)
      {
        arrayOfByte = new byte[OS.strlen(k)];
        OS.memmove(arrayOfByte, k, arrayOfByte.length);
        OS.g_free(k);
        localObject[(i++)] = ("GTKPRIMARYCLIPBOARD " + new String(Converter.mbcsToWcs(null, arrayOfByte)));
      }
    }
    if (i < localObject.length)
    {
      String[] arrayOfString = new String[i];
      System.arraycopy(localObject, 0, arrayOfString, 0, i);
      localObject = arrayOfString;
    }
    return (String[])localObject;
  }
  
  private int[] getAvailablePrimaryTypes()
  {
    int[] arrayOfInt = new int[0];
    int i = gtk_clipboard_wait_for_contents(GTKPRIMARYCLIPBOARD, TARGET);
    OS.gdk_threads_leave();
    if (i != 0) {
      try
      {
        int j;
        int k;
        int m;
        if (OS.GTK_VERSION >= OS.VERSION(2, 14, 0))
        {
          j = OS.gtk_selection_data_get_length(i);
          k = OS.gtk_selection_data_get_format(i);
          m = OS.gtk_selection_data_get_data(i);
        }
        else
        {
          GtkSelectionData localGtkSelectionData = new GtkSelectionData();
          OS.memmove(localGtkSelectionData, i, GtkSelectionData.sizeof);
          j = localGtkSelectionData.length;
          k = localGtkSelectionData.format;
          m = localGtkSelectionData.data;
        }
        if (j != 0)
        {
          arrayOfInt = new int[j * 8 / k];
          OS.memmove(arrayOfInt, m, j);
        }
      }
      finally
      {
        OS.gtk_selection_data_free(i);
      }
    }
    return arrayOfInt;
  }
  
  private int[] getAvailableClipboardTypes()
  {
    int[] arrayOfInt = new int[0];
    int i = gtk_clipboard_wait_for_contents(GTKCLIPBOARD, TARGET);
    OS.gdk_threads_leave();
    if (i != 0) {
      try
      {
        int j;
        int k;
        int m;
        if (OS.GTK_VERSION >= OS.VERSION(2, 14, 0))
        {
          j = OS.gtk_selection_data_get_length(i);
          k = OS.gtk_selection_data_get_format(i);
          m = OS.gtk_selection_data_get_data(i);
        }
        else
        {
          GtkSelectionData localGtkSelectionData = new GtkSelectionData();
          OS.memmove(localGtkSelectionData, i, GtkSelectionData.sizeof);
          j = localGtkSelectionData.length;
          k = localGtkSelectionData.format;
          m = localGtkSelectionData.data;
        }
        if (j != 0)
        {
          arrayOfInt = new int[j * 8 / k];
          OS.memmove(arrayOfInt, m, j);
        }
      }
      finally
      {
        OS.gtk_selection_data_free(i);
      }
    }
    return arrayOfInt;
  }
  
  int gtk_clipboard_wait_for_contents(int paramInt1, int paramInt2)
  {
    long l1 = System.currentTimeMillis();
    String str = "org.eclipse.swt.internal.gtk.dispatchEvent";
    Display localDisplay = this.display;
    localDisplay.setData(str, new int[] { 16, 17, 18, 19 });
    int i = OS.gtk_clipboard_wait_for_contents(paramInt1, paramInt2);
    localDisplay.setData(str, null);
    long l2 = System.currentTimeMillis() - l1;
    if ((i == 0) && (l2 > 5000L)) {
      ClipboardProxy._getInstance(localDisplay).setData(this, new String[] { " " }, new Transfer[] { TextTransfer.getInstance() }, paramInt1 == GTKCLIPBOARD ? 1 : 2);
    }
    return i;
  }
  
  static
  {
    byte[] arrayOfByte = Converter.wcsToMbcs(null, "PRIMARY", true);
    int i = OS.gdk_atom_intern(arrayOfByte, false);
    GTKPRIMARYCLIPBOARD = OS.gtk_clipboard_get(i);
    arrayOfByte = Converter.wcsToMbcs(null, "TARGETS", true);
    TARGET = OS.gdk_atom_intern(arrayOfByte, false);
  }
}


/* Location:              /Users/0x101/safe/mytools_10012106/afterLoader/Behinder.jar!/net/rebeyond/behinder/resource/lib/swt_linux_32.jar!/org/eclipse/swt/dnd/Clipboard.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */